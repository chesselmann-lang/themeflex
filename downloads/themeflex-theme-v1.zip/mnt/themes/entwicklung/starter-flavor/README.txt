=== Starter Flavor ===
Contributors: whatsdigital
Tags: blog, e-commerce, portfolio, grid-layout, one-column, two-columns, left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-logo, custom-menu, editor-style, featured-images, footer-widgets, full-width-template, post-formats, theme-options, threaded-comments, translation-ready, block-styles, wide-blocks
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 8.0
Stable tag: 1.1.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The most complete WordPress theme ecosystem — 80+ Elementor widgets, 20 professional skins, 15 one-click demos, native dark mode, and AI-powered features.

== Description ==

Starter Flavor is a premium WordPress theme built for Elementor with everything you need to launch a professional website. It features a comprehensive design system inspired by Elementra's architecture, including a 16-token semantic color system, Elementor Kit auto-sync, and full WooCommerce integration.

**Key Features:**
* 80+ Custom Elementor Widgets
* 20 Professional Skin Presets
* 15 One-Click Demo Sites
* Native Dark Mode (all components)
* 16-Token Semantic Color System
* Elementor Kit Auto-Sync (Customizer → Global Colors/Fonts)
* Full WooCommerce Integration (2,300+ lines of CSS)
* AI Content Assistant (OpenAI integration)
* Interactive Pricing Calculator
* Social Proof Notification Widget
* Particle Background Animations
* Horizontal Scroll Sections
* Isotope Portfolio Filter
* Cookie Consent Builder
* Preloader Screen
* WCAG 2.1 AA Accessible
* 90+ PageSpeed Score
* PHP 8.0+ Compatible
* WordPress 6.0+ Compatible
* GPL v2+ Licensed

== Installation ==

1. Download the theme zip file from ThemeForest
2. Go to WordPress Admin → Appearance → Themes → Add New → Upload Theme
3. Select `starter-flavor.zip` and click Install Now
4. Activate the theme
5. Install the required Starter Flavor Addons plugin when prompted
6. Install Elementor (free version works fully)
7. Go to Appearance → Theme Setup → Demo Importer to import a demo

== Frequently Asked Questions ==

= Do I need Elementor Pro? =
No! All 80+ widgets work with the free version of Elementor.

= How do I switch skins? =
Go to Appearance → Customize → Skin Settings and choose from 20 included skins.

= Is WooCommerce supported? =
Yes, with full CSS for Shop, Product, Cart, Checkout, My Account pages plus dark mode.

= Can I use the AI Content Assistant? =
Yes — set your OpenAI API key in Settings → Starter Flavor → AI Settings.

= How do I import a demo? =
Go to Appearance → Theme Setup → Demo Importer and click Import on your chosen demo.

== Changelog ==

= 1.1.0 =
* Added 80+ Elementor Widgets (up from 51)
* Added 20 professional skins (up from 10)
* Added 15 one-click demo sites (up from 6)
* Added AI Content Assistant Widget (OpenAI integration)
* Added Interactive Pricing Calculator Widget
* Added Social Proof Notification Widget
* Added Particle Background Widget
* Added Horizontal Scroll Section Widget
* Added Isotope Portfolio Filter Widget
* Added Lead Quiz Widget
* Added Feature Showcase Widget
* Added Device Mockup Widget
* Added Cookie Consent Builder Widget
* Added FAQ with Live Search Widget
* Added 16-Token Semantic Color System
* Added Elementor Kit Auto-Sync
* Added Admin Getting-Started Page
* Added Preloader Screen
* Improved WooCommerce CSS (2,300+ lines, dark mode)
* Improved Dark Mode (all components)

= 1.0.0 =
* Initial release

== Credits ==

* Inter Font: SIL Open Font License 1.1 (https://fonts.google.com/specimen/Inter)
* Inter Tight Font: SIL Open Font License 1.1 (https://fonts.google.com/specimen/Inter+Tight)
* Font Awesome Icons: Font Awesome Free 6 (https://fontawesome.com/license/free) — CC BY 4.0 License
* Placeholder images: Generated programmatically — no external images required

== License ==

Starter Flavor WordPress Theme, Copyright 2026 WhatsDigital
Starter Flavor is distributed under the terms of the GNU GPL v2 or later.

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
