<?php
/**
 * Archive Template — Starter Flavor
 * @package Starter_Flavor
 */
get_header(); ?>
<main id="primary" class="site-main" style="padding:60px 0;">
<div class="container" style="max-width:var(--sf-content-width,1290px);margin:0 auto;padding:0 24px;">
    <!-- Header -->
    <header style="margin-bottom:48px;text-align:center;">
        <?php the_archive_title('<h1 style="font-family:\'Inter Tight\',sans-serif;font-size:clamp(32px,5vw,52px);font-weight:900;color:var(--sf-title,#1e293b);margin-bottom:12px;letter-spacing:-.5px;">','</h1>'); ?>
        <?php the_archive_description('<div style="font-size:17px;color:var(--sf-text,#64748b);max-width:560px;margin:0 auto;line-height:1.8;">','</div>'); ?>
    </header>
    <?php if (have_posts()): ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:28px;">
        <?php while (have_posts()): the_post(); ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class('sf-archive-card'); ?> style="background:var(--sf-bg,#fff);border:1px solid var(--sf-border,#e5e7eb);border-radius:14px;overflow:hidden;transition:all .3s;" onmouseover="this.style.transform='translateY(-4px)';this.style.boxShadow='0 12px 40px rgba(0,0,0,.1)';this.style.borderColor='rgba(255,94,46,.3)'" onmouseout="this.style.transform='';this.style.boxShadow='';this.style.borderColor='var(--sf-border,#e5e7eb)'">
            <?php if (has_post_thumbnail()): ?>
            <a href="<?php the_permalink(); ?>" style="display:block;overflow:hidden;aspect-ratio:16/9;">
                <?php the_post_thumbnail('medium_large', ['style'=>'width:100%;height:100%;object-fit:cover;display:block;transition:transform .4s;','onmouseover'=>"this.style.transform='scale(1.04)'",'onmouseout'=>"this.style.transform='scale(1)'"]); ?>
            </a>
            <?php endif; ?>
            <div style="padding:20px 22px;">
                <?php $cat = get_the_category(); if ($cat): ?>
                <a href="<?php echo esc_url(get_category_link($cat[0]->term_id)); ?>" style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--sf-color-primary,#FF5E2E);text-decoration:none;display:block;margin-bottom:8px;"><?php echo esc_html($cat[0]->name); ?></a>
                <?php endif; ?>
                <h2 style="font-size:1.15rem;font-weight:800;color:var(--sf-title,#1e293b);margin:0 0 10px;line-height:1.3;"><a href="<?php the_permalink(); ?>" style="color:inherit;text-decoration:none;"><?php the_title(); ?></a></h2>
                <p style="font-size:14px;color:var(--sf-text,#64748b);line-height:1.7;margin:0 0 16px;"><?php echo wp_trim_words(get_the_excerpt(), 18, '…'); ?></p>
                <div style="display:flex;align-items:center;justify-content:space-between;font-size:12px;color:var(--sf-meta,#94a3b8);">
                    <div style="display:flex;align-items:center;gap:8px;">
                        <?php echo get_avatar(get_the_author_meta('ID'), 22, '', '', ['style'=>'border-radius:50%;']); ?>
                        <span><?php the_author(); ?></span>
                    </div>
                    <span><?php the_date(); ?></span>
                </div>
            </div>
        </article>
        <?php endwhile; ?>
    </div>
    <div style="margin-top:48px;">
        <?php the_posts_pagination(['mid_size'=>2,'prev_text'=>'← '.__('Newer','starter-flavor'),'next_text'=>__('Older','starter-flavor').' →']); ?>
    </div>
    <?php else: ?>
    <div style="text-align:center;padding:80px 0;"><p style="color:var(--sf-meta,#94a3b8);font-size:17px;"><?php esc_html_e('No posts found.','starter-flavor'); ?></p></div>
    <?php endif; ?>
</div>
</main>
<?php get_footer(); ?>
