<?php
/**
 * Comments Template — Starter Flavor
 * @package Starter_Flavor
 */
if (post_password_required()) return;
$comments_num = get_comments_number();
?>
<section id="comments" style="margin-top:0;">
    <?php if (have_comments()): ?>
    <h3 style="font-family:'Inter Tight',sans-serif;font-size:1.3rem;font-weight:800;color:var(--sf-title,#1e293b);margin-bottom:28px;">
        <?php printf(esc_html(_n('%d Comment','%d Comments',$comments_num,'starter-flavor')), (int)$comments_num); ?>
    </h3>
    <ol class="comment-list" style="list-style:none;padding:0;margin:0 0 40px;">
        <?php wp_list_comments(['style'=>'ol','short_ping'=>true,'avatar_size'=>44,'callback'=>function($comment, $args, $depth){
            $author = get_comment_author();
            $url    = get_comment_author_url();
            $avatar = get_avatar($comment, 44, '', '', ['style'=>'width:44px;height:44px;border-radius:50%;object-fit:cover;flex-shrink:0;']);
            $date   = get_comment_date();
            $text   = get_comment_text();
            $pending = '0' == $comment->comment_approved;
            echo '<li id="comment-'.esc_attr(get_comment_ID()).'" '.comment_class('',null,null,false).' style="display:flex;gap:14px;margin-bottom:24px;padding-bottom:24px;border-bottom:1px solid var(--sf-border,#e5e7eb);">';
            echo $avatar;
            echo '<div style="flex:1;min-width:0;">';
            echo '<div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">';
            echo '<strong style="font-size:14px;color:var(--sf-title,#1e293b);">'.esc_html($author).'</strong>';
            echo '<span style="font-size:12px;color:var(--sf-meta,#94a3b8);">'.$date.'</span>';
            if ($pending) echo '<span style="font-size:11px;font-weight:700;padding:2px 6px;border-radius:4px;background:rgba(245,158,11,.1);color:#f59e0b;">'.__('Pending','starter-flavor').'</span>';
            echo '</div>';
            echo '<div style="font-size:14px;color:var(--sf-text,#64748b);line-height:1.8;margin-bottom:8px;">'.wpautop(wp_kses_post($text)).'</div>';
            echo '<div style="font-size:12px;">'.get_comment_reply_link(array_merge($args, ['reply_text'=>__('Reply','starter-flavor'),'depth'=>$depth,'max_depth'=>$args['max_depth']])).'</div>';
            echo '</div></li>';
        }]); ?>
    </ol>
    <?php if (get_comment_pages_count() > 1): ?>
    <nav style="margin-bottom:32px;"><?php paginate_comments_links(); ?></nav>
    <?php endif; ?>
    <?php endif; ?>

    <?php if (!comments_open() && $comments_num): ?>
    <p style="color:var(--sf-meta,#94a3b8);font-size:14px;"><?php esc_html_e('Comments are closed.','starter-flavor'); ?></p>
    <?php endif; ?>

    <?php comment_form([
        'title_reply'         => esc_html__('Leave a Comment','starter-flavor'),
        'title_reply_to'      => esc_html__('Reply to %s','starter-flavor'),
        'cancel_reply_link'   => esc_html__('Cancel reply','starter-flavor'),
        'label_submit'        => esc_html__('Post Comment','starter-flavor'),
        'submit_button'       => '<button name="%1$s" type="submit" id="%2$s" class="%3$s" value="%4$s" style="padding:12px 24px;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;border:none;border-radius:10px;font-weight:700;font-size:14px;cursor:pointer;font-family:inherit;">%4$s</button>',
        'fields'              => [
            'author' => '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;"><div><label style="display:block;font-weight:600;font-size:13px;color:var(--sf-title,#1e293b);margin-bottom:4px;">'.esc_html__('Name','starter-flavor').' <span style="color:#ef4444;">*</span></label><input type="text" name="author" required style="width:100%;padding:10px 14px;border:1px solid var(--sf-border,#e5e7eb);border-radius:8px;font-size:14px;background:var(--sf-bg,#fff);color:var(--sf-title,#1e293b);font-family:inherit;outline:none;" /></div>',
            'email'  => '<div><label style="display:block;font-weight:600;font-size:13px;color:var(--sf-title,#1e293b);margin-bottom:4px;">'.esc_html__('Email','starter-flavor').' <span style="color:#ef4444;">*</span></label><input type="email" name="email" required style="width:100%;padding:10px 14px;border:1px solid var(--sf-border,#e5e7eb);border-radius:8px;font-size:14px;background:var(--sf-bg,#fff);color:var(--sf-title,#1e293b);font-family:inherit;outline:none;" /></div></div>',
            'url'    => '',
            'cookies'=> '',
        ],
        'comment_field' => '<div style="margin-bottom:16px;"><label style="display:block;font-weight:600;font-size:13px;color:var(--sf-title,#1e293b);margin-bottom:4px;">'.esc_html__('Comment','starter-flavor').' <span style="color:#ef4444;">*</span></label><textarea name="comment" rows="5" required style="width:100%;padding:12px 14px;border:1px solid var(--sf-border,#e5e7eb);border-radius:8px;font-size:14px;background:var(--sf-bg,#fff);color:var(--sf-title,#1e293b);font-family:inherit;resize:vertical;outline:none;"></textarea></div>',
        'comment_notes_before' => '',
        'comment_notes_after'  => '',
    ]); ?>
</section>
