<?php
/**
 * Custom Elementor Template Source for Starter Flavor
 *
 * Registers Starter Flavor templates as a custom source in Elementor's template library.
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Elementor\TemplateLibrary\Sources\Base' ) ) {
	return;
}

class Starter_Flavor_Template_Source extends \Elementor\TemplateLibrary\Sources\Base {

	/**
	 * Get template source ID
	 *
	 * @return string
	 */
	public function get_id() {
		return 'starter-flavor';
	}

	/**
	 * Get template source title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Starter Flavor Templates', 'starter-flavor' );
	}

	/**
	 * Get templates by category
	 *
	 * @param string $category Category slug
	 * @return array
	 */
	public function get_items( $category = '' ) {
		$templates = $this->get_all_templates();

		if ( ! empty( $category ) ) {
			$templates = array_filter( $templates, function( $template ) use ( $category ) {
				return ( $template['category'] === $category );
			} );
		}

		return array_values( $templates );
	}

	/**
	 * Get template groups/categories
	 *
	 * @return array
	 */
	public function get_categories() {
		$templates = $this->get_all_templates();
		$categories = array();

		foreach ( $templates as $template ) {
			if ( ! isset( $categories[ $template['category'] ] ) ) {
				$categories[ $template['category'] ] = array(
					'title' => $template['category'],
					'count' => 0,
				);
			}
			$categories[ $template['category'] ]['count']++;
		}

		return array_values( $categories );
	}

	/**
	 * Get all available templates
	 *
	 * @return array
	 */
	private function get_all_templates() {
		$templates_dir = STARTER_FLAVOR_THEME_DIR . '/elementor-templates';
		$templates = array();

		$template_map = array(
			'homepage-corporate.json' => array(
				'id'       => 'homepage-corporate',
				'title'    => 'Corporate Homepage',
				'category' => 'Homepage',
				'thumbnail' => STARTER_FLAVOR_THEME_URL . '/images/templates/homepage-corporate.jpg',
			),
			'homepage-creative.json' => array(
				'id'       => 'homepage-creative',
				'title'    => 'Creative Homepage',
				'category' => 'Homepage',
				'thumbnail' => STARTER_FLAVOR_THEME_URL . '/images/templates/homepage-creative.jpg',
			),
			'homepage-shop.json' => array(
				'id'       => 'homepage-shop',
				'title'    => 'Shop Homepage',
				'category' => 'Homepage',
				'thumbnail' => STARTER_FLAVOR_THEME_URL . '/images/templates/homepage-shop.jpg',
			),
			'about-us.json' => array(
				'id'       => 'about-us',
				'title'    => 'About Us',
				'category' => 'Inner Pages',
				'thumbnail' => STARTER_FLAVOR_THEME_URL . '/images/templates/about-us.jpg',
			),
			'services.json' => array(
				'id'       => 'services',
				'title'    => 'Services',
				'category' => 'Inner Pages',
				'thumbnail' => STARTER_FLAVOR_THEME_URL . '/images/templates/services.jpg',
			),
			'contact.json' => array(
				'id'       => 'contact',
				'title'    => 'Contact',
				'category' => 'Inner Pages',
				'thumbnail' => STARTER_FLAVOR_THEME_URL . '/images/templates/contact.jpg',
			),
			'portfolio-grid.json' => array(
				'id'       => 'portfolio-grid',
				'title'    => 'Portfolio Grid',
				'category' => 'Inner Pages',
				'thumbnail' => STARTER_FLAVOR_THEME_URL . '/images/templates/portfolio-grid.jpg',
			),
			'portfolio-single.json' => array(
				'id'       => 'portfolio-single',
				'title'    => 'Portfolio Single',
				'category' => 'Inner Pages',
				'thumbnail' => STARTER_FLAVOR_THEME_URL . '/images/templates/portfolio-single.jpg',
			),
			'blog-page.json' => array(
				'id'       => 'blog-page',
				'title'    => 'Blog Page',
				'category' => 'Inner Pages',
				'thumbnail' => STARTER_FLAVOR_THEME_URL . '/images/templates/blog-page.jpg',
			),
			'pricing.json' => array(
				'id'       => 'pricing',
				'title'    => 'Pricing',
				'category' => 'Inner Pages',
				'thumbnail' => STARTER_FLAVOR_THEME_URL . '/images/templates/pricing.jpg',
			),
			'faq.json' => array(
				'id'       => 'faq',
				'title'    => 'FAQ',
				'category' => 'Inner Pages',
				'thumbnail' => STARTER_FLAVOR_THEME_URL . '/images/templates/faq.jpg',
			),
			'team.json' => array(
				'id'       => 'team',
				'title'    => 'Team',
				'category' => 'Inner Pages',
				'thumbnail' => STARTER_FLAVOR_THEME_URL . '/images/templates/team.jpg',
			),
			'coming-soon.json' => array(
				'id'       => 'coming-soon',
				'title'    => 'Coming Soon',
				'category' => 'Special Pages',
				'thumbnail' => STARTER_FLAVOR_THEME_URL . '/images/templates/coming-soon.jpg',
			),
			'landing-saas.json' => array(
				'id'       => 'landing-saas',
				'title'    => 'SaaS Landing',
				'category' => 'Landing Pages',
				'thumbnail' => STARTER_FLAVOR_THEME_URL . '/images/templates/landing-saas.jpg',
			),
			'landing-app.json' => array(
				'id'       => 'landing-app',
				'title'    => 'App Landing',
				'category' => 'Landing Pages',
				'thumbnail' => STARTER_FLAVOR_THEME_URL . '/images/templates/landing-app.jpg',
			),
		);

		foreach ( $template_map as $file => $data ) {
			$path = $templates_dir . '/' . $file;

			if ( file_exists( $path ) ) {
				$templates[] = array_merge( $data, array(
					'file' => $file,
					'source' => $this->get_id(),
				) );
			}
		}

		return $templates;
	}

	/**
	 * Get template data/content
	 *
	 * @param string $template_id Template ID
	 * @return array|false
	 */
	public function get_item( $template_id ) {
		$templates_dir = STARTER_FLAVOR_THEME_DIR . '/elementor-templates';
		$template_map = $this->get_template_file_map();

		if ( ! isset( $template_map[ $template_id ] ) ) {
			return false;
		}

		$file = $template_map[ $template_id ];
		$path = $templates_dir . '/' . $file;

		if ( ! file_exists( $path ) ) {
			return false;
		}

		$data = json_decode( file_get_contents( $path ), true );

		if ( ! $data ) {
			return false;
		}

		return array(
			'type' => 'page',
			'content' => isset( $data['content'] ) ? $data['content'] : array(),
		);
	}

	/**
	 * Get template data for preview
	 *
	 * @param string $template_id Template ID
	 * @return bool
	 */
	public function request_template_data( $template_id ) {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return false;
		}

		$data = $this->get_item( $template_id );

		if ( ! $data ) {
			return false;
		}

		return array(
			'type'    => 'page',
			'content' => $data['content'],
		);
	}

	/**
	 * Get template file map
	 *
	 * @return array
	 */
	private function get_template_file_map() {
		return array(
			'homepage-corporate' => 'homepage-corporate.json',
			'homepage-creative'  => 'homepage-creative.json',
			'homepage-shop'      => 'homepage-shop.json',
			'about-us'           => 'about-us.json',
			'services'           => 'services.json',
			'contact'            => 'contact.json',
			'portfolio-grid'     => 'portfolio-grid.json',
			'portfolio-single'   => 'portfolio-single.json',
			'blog-page'          => 'blog-page.json',
			'pricing'            => 'pricing.json',
			'faq'                => 'faq.json',
			'team'               => 'team.json',
			'coming-soon'        => 'coming-soon.json',
			'landing-saas'       => 'landing-saas.json',
			'landing-app'        => 'landing-app.json',
		);
	}

	/**
	 * Save template (not editable in library)
	 *
	 * @return void
	 */
	public function save_item( $template_data ) {
		return false;
	}

	/**
	 * Update template (not editable in library)
	 *
	 * @return void
	 */
	public function update_item( $new_data ) {
		return false;
	}

	/**
	 * Delete template (not editable in library)
	 *
	 * @return void
	 */
	public function delete_template( $template_id ) {
		return false;
	}

	/**
	 * Export template (not supported)
	 *
	 * @return void
	 */
	public function export_template( $template_id ) {
		return false;
	}
}
