<?php
/**
 * Starter Flavor Theme Functions
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ==================================================
 * THEME CONSTANTS
 * ==================================================
 */

if ( ! defined( 'STARTER_FLAVOR_THEME_DIR' ) ) {
	define( 'STARTER_FLAVOR_THEME_DIR', get_template_directory() );
}

if ( ! defined( 'STARTER_FLAVOR_THEME_URL' ) ) {
	define( 'STARTER_FLAVOR_THEME_URL', get_template_directory_uri() );
}

if ( ! defined( 'STARTER_FLAVOR_CHILD_DIR' ) ) {
	define( 'STARTER_FLAVOR_CHILD_DIR', get_stylesheet_directory() );
}

if ( ! defined( 'STARTER_FLAVOR_CHILD_URL' ) ) {
	define( 'STARTER_FLAVOR_CHILD_URL', get_stylesheet_directory_uri() );
}

if ( ! defined( 'STARTER_FLAVOR_VERSION' ) ) {
	define( 'STARTER_FLAVOR_VERSION', '1.0.0' );
}

if ( ! defined( 'STARTER_FLAVOR_ASSETS_DIR' ) ) {
	define( 'STARTER_FLAVOR_ASSETS_DIR', STARTER_FLAVOR_THEME_DIR . '/assets/' );
}

if ( ! defined( 'STARTER_FLAVOR_ASSETS_URL' ) ) {
	define( 'STARTER_FLAVOR_ASSETS_URL', STARTER_FLAVOR_THEME_URL . '/assets/' );
}

/**
 * ==================================================
 * THEME SETUP
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_setup' ) ) {
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_setup() {
		// Add default posts and comments RSS feed links to head
		add_theme_support( 'automatic-feed-links' );

		// Let WordPress manage the document title
		add_theme_support( 'title-tag' );

		// Enable support for Post Thumbnails
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'post-formats', array( 'aside', 'gallery', 'link', 'image', 'quote', 'status', 'video', 'audio', 'chat' ) );

		// Register Custom Logo
		add_theme_support( 'custom-logo', array(
			'height'      => 100,
			'width'       => 200,
			'flex-height' => true,
			'flex-width'  => true,
		) );

		// Register Custom Header
		add_theme_support( 'custom-header', array(
			'default-image' => '',
			'width'         => 1200,
			'height'        => 800,
			'flex-height'   => true,
			'flex-width'    => true,
		) );

		// Register Custom Background
		add_theme_support( 'custom-background', array(
			'default-color' => 'ffffff',
		) );

		// Add support for HTML5 markup
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		) );

		// Register Navigation Menus
		register_nav_menus( array(
			'main-menu'   => esc_html__( 'Main Menu', 'starter-flavor' ),
			'mobile-menu' => esc_html__( 'Mobile Menu', 'starter-flavor' ),
			'footer-menu' => esc_html__( 'Footer Menu', 'starter-flavor' ),
		) );

		// Add Image Sizes
		add_image_size( 'starter-flavor-thumb-big', 1170, 658, true );
		add_image_size( 'starter-flavor-thumb-med', 740, 416, true );
		add_image_size( 'starter-flavor-thumb-small', 370, 208, true );

		// Add Editor Styles
		add_theme_support( 'editor-styles' );
		add_editor_style( 'css/editor-style.css' );

		// Enable Elementor support
		add_theme_support( 'elementor' );

		// Enable responsive embeds (for better performance)
		add_theme_support( 'responsive-embeds' );

		// Enable WordPress block styles
		add_theme_support( 'wp-block-styles' );
	}

	add_action( 'after_setup_theme', 'starter_flavor_setup' );

	// Load textdomain at priority 0 to prevent _load_textdomain_just_in_time notice (WP 6.7+)
	add_action( 'after_setup_theme', function() {
		load_theme_textdomain( 'starter-flavor', STARTER_FLAVOR_THEME_DIR . '/languages' );
	}, 0 );
}

/**
 * ==================================================
 * RESOURCE HINTS
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_resource_hints' ) ) {
	/**
	 * Add preconnect and DNS prefetch hints.
	 *
	 * @since 1.0.0
	 * @param array  $urls URLs to preconnect.
	 * @param string $relation_type Type of relation.
	 * @return array Modified URLs.
	 */
	function starter_flavor_resource_hints( $urls, $relation_type ) {
		if ( 'preconnect' === $relation_type ) {
			$urls[] = array(
				'href'       => 'https://fonts.googleapis.com',
				'crossorigin' => true,
			);
			$urls[] = array(
				'href'       => 'https://fonts.gstatic.com',
				'crossorigin' => true,
			);
		}
		return $urls;
	}

	add_filter( 'wp_resource_hints', 'starter_flavor_resource_hints', 10, 2 );
}

/**
 * ==================================================
 * SCRIPTS & STYLES
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_scripts' ) ) {
	/**
	 * Enqueue scripts and styles.
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_scripts() {
		// Google Fonts
		wp_enqueue_style(
			'starter-flavor-google-fonts',
			'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Inter+Tight:wght@400;500;600;700&display=swap',
			array(),
			null
		);

		// Main Stylesheet
		wp_enqueue_style(
			'starter-flavor-style',
			STARTER_FLAVOR_THEME_URL . '/style.css',
			array(),
			STARTER_FLAVOR_VERSION
		);

		// Responsive Stylesheet
		wp_enqueue_style(
			'starter-flavor-responsive',
			STARTER_FLAVOR_THEME_URL . '/css/responsive.css',
			array( 'starter-flavor-style' ),
			STARTER_FLAVOR_VERSION
		);

		// RTL Stylesheet
		if ( is_rtl() ) {
			wp_enqueue_style(
				'starter-flavor-rtl',
				STARTER_FLAVOR_THEME_URL . '/rtl.css',
				array( 'starter-flavor-style' ),
				STARTER_FLAVOR_VERSION
			);
		}

		// Reduced Motion Stylesheet
		wp_enqueue_style(
			'starter-flavor-reduced-motion',
			STARTER_FLAVOR_THEME_URL . '/assets/css/reduced-motion.css',
			array( 'starter-flavor-style' ),
			STARTER_FLAVOR_VERSION
		);

		// Navigation Script
		wp_enqueue_script(
			'starter-flavor-navigation',
			STARTER_FLAVOR_THEME_URL . '/assets/js/navigation.js',
			array(),
			STARTER_FLAVOR_VERSION,
			true
		);

		// Custom Script
		wp_enqueue_script(
			'starter-flavor-custom',
			STARTER_FLAVOR_THEME_URL . '/assets/js/custom.js',
			array(),
			STARTER_FLAVOR_VERSION,
			true
		);

		// Skip Link Focus Fix
		wp_enqueue_script(
			'starter-flavor-skip-link-focus-fix',
			STARTER_FLAVOR_THEME_URL . '/assets/js/skip-link-focus-fix.js',
			array(),
			STARTER_FLAVOR_VERSION,
			true
		);

		// Performance Utilities Script
		wp_enqueue_script(
			'starter-flavor-performance',
			STARTER_FLAVOR_THEME_URL . '/assets/js/performance.js',
			array(),
			STARTER_FLAVOR_VERSION,
			true
		);

		// Focus Management Script
		wp_enqueue_script(
			'starter-flavor-focus-management',
			STARTER_FLAVOR_THEME_URL . '/assets/js/focus-management.js',
			array(),
			STARTER_FLAVOR_VERSION,
			true
		);

		// Mobile Navigation Accessibility Script
		wp_enqueue_script(
			'starter-flavor-mobile-nav-a11y',
			STARTER_FLAVOR_THEME_URL . '/assets/js/mobile-nav-a11y.js',
			array(),
			STARTER_FLAVOR_VERSION,
			true
		);

		// Mega Menu Styles
		wp_enqueue_style(
			'starter-flavor-mega-menu',
			STARTER_FLAVOR_THEME_URL . '/assets/css/mega-menu.css',
			array(),
			STARTER_FLAVOR_VERSION
		);

		// Mega Menu Script
		wp_enqueue_script(
			'starter-flavor-mega-menu',
			STARTER_FLAVOR_THEME_URL . '/assets/js/mega-menu.js',
			array(),
			STARTER_FLAVOR_VERSION,
			true
		);

		// Localize Scripts
		wp_localize_script(
			'starter-flavor-custom',
			'starterFlavorData',
			array(
				'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
				'themeUrl'  => STARTER_FLAVOR_THEME_URL,
				'nonce'     => wp_create_nonce( 'starter_flavor_nonce' ),
				'isRTL'     => is_rtl(),
			)
		);

		// Comment Script
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
	}

	add_action( 'wp_enqueue_scripts', 'starter_flavor_scripts' );
}

if ( ! function_exists( 'sf_enqueue_front_page_assets' ) ) {
	/**
	 * Enqueue Front Page CSS + JS (only on the front page).
	 *
	 * Loads front-page.css and front-page.js conditionally so they
	 * never add weight to interior pages.  wp_localize_script supplies
	 * the AJAX URL and i18n strings needed by the newsletter form and
	 * FAQ accordion.
	 *
	 * @since 1.1.0
	 */
	function sf_enqueue_front_page_assets() {
		if ( ! is_front_page() ) {
			return;
		}

		wp_enqueue_style(
			'starter-flavor-front-page',
			STARTER_FLAVOR_THEME_URL . '/assets/css/front-page.css',
			array( 'starter-flavor-style' ),
			STARTER_FLAVOR_VERSION
		);

		wp_enqueue_script(
			'starter-flavor-front-page',
			STARTER_FLAVOR_THEME_URL . '/assets/js/front-page.js',
			array(),
			STARTER_FLAVOR_VERSION,
			true
		);

		wp_localize_script(
			'starter-flavor-front-page',
			'sfFrontPage',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'sf_subscribe_nonce' ),
				'i18n'    => array(
					'invalidEmail' => esc_html__( 'Please enter a valid email address.', 'starter-flavor' ),
					'sending'      => esc_html__( 'Subscribing…', 'starter-flavor' ),
					'success'      => esc_html__( 'Thank you for subscribing!', 'starter-flavor' ),
					'error'        => esc_html__( 'Something went wrong. Please try again.', 'starter-flavor' ),
				),
			)
		);
	}

	add_action( 'wp_enqueue_scripts', 'sf_enqueue_front_page_assets' );
}

if ( ! function_exists( 'sf_enqueue_pro_assets' ) ) {
	/**
	 * Enqueue Pro Assets on Frontend
	 *
	 * @since 1.0.0
	 */
	function sf_enqueue_pro_assets() {
		// Enqueue Popup Builder assets only if popups exist
		$popup_builder = class_exists( 'Starter_Flavor_Popup_Builder' ) ? new Starter_Flavor_Popup_Builder() : null;
		$has_popups = $popup_builder && method_exists( $popup_builder, 'has_popups' ) && $popup_builder->has_popups();

		// Popup Builder CSS (frontend only if popups exist)
		if ( $has_popups && file_exists( STARTER_FLAVOR_ASSETS_DIR . 'css/popup-builder.css' ) ) {
			wp_enqueue_style(
				'starter-flavor-popup-builder',
				STARTER_FLAVOR_ASSETS_URL . 'css/popup-builder.css',
				array(),
				STARTER_FLAVOR_VERSION,
				'all'
			);
		}

		// Popup Builder JS (frontend only if popups exist)
		if ( $has_popups && file_exists( STARTER_FLAVOR_ASSETS_DIR . 'js/popup-builder.js' ) ) {
			wp_enqueue_script(
				'starter-flavor-popup-builder',
				STARTER_FLAVOR_ASSETS_URL . 'js/popup-builder.js',
				array(),
				STARTER_FLAVOR_VERSION,
				true
			);
		}

		// Performance Pro JS
		if ( file_exists( STARTER_FLAVOR_ASSETS_DIR . 'js/performance-pro.js' ) ) {
			wp_enqueue_script(
				'starter-flavor-performance-pro',
				STARTER_FLAVOR_ASSETS_URL . 'js/performance-pro.js',
				array(),
				STARTER_FLAVOR_VERSION,
				true
			);
		}

		// Design System Frontend CSS
		if ( file_exists( STARTER_FLAVOR_ASSETS_DIR . 'css/design-system-frontend.css' ) ) {
			wp_enqueue_style(
				'starter-flavor-design-system-frontend',
				STARTER_FLAVOR_ASSETS_URL . 'css/design-system-frontend.css',
				array(),
				STARTER_FLAVOR_VERSION,
				'all'
			);
		}
	}

	add_action( 'wp_enqueue_scripts', 'sf_enqueue_pro_assets' );
}

if ( ! function_exists( 'sf_enqueue_pro_admin_assets' ) ) {
	/**
	 * Enqueue Pro Assets in Admin
	 *
	 * @since 1.0.0
	 */
	function sf_enqueue_pro_admin_assets() {
		// AI Assistant CSS (admin only)
		if ( file_exists( STARTER_FLAVOR_ASSETS_DIR . 'css/ai-assistant.css' ) ) {
			wp_enqueue_style(
				'starter-flavor-ai-assistant',
				STARTER_FLAVOR_ASSETS_URL . 'css/ai-assistant.css',
				array(),
				STARTER_FLAVOR_VERSION,
				'all'
			);
		}

		// AI Assistant JS (admin only when Elementor editor is active)
		if ( file_exists( STARTER_FLAVOR_ASSETS_DIR . 'js/ai-assistant.js' ) ) {
			wp_enqueue_script(
				'starter-flavor-ai-assistant',
				STARTER_FLAVOR_ASSETS_URL . 'js/ai-assistant.js',
				array(),
				STARTER_FLAVOR_VERSION,
				true
			);
		}

		// Design System CSS (admin only)
		if ( file_exists( STARTER_FLAVOR_ASSETS_DIR . 'css/design-system.css' ) ) {
			wp_enqueue_style(
				'starter-flavor-design-system',
				STARTER_FLAVOR_ASSETS_URL . 'css/design-system.css',
				array(),
				STARTER_FLAVOR_VERSION,
				'all'
			);
		}

		// Design System JS (admin only)
		if ( file_exists( STARTER_FLAVOR_ASSETS_DIR . 'js/design-system.js' ) ) {
			wp_enqueue_script(
				'starter-flavor-design-system',
				STARTER_FLAVOR_ASSETS_URL . 'js/design-system.js',
				array(),
				STARTER_FLAVOR_VERSION,
				true
			);
		}

		// Popup Builder Admin CSS
		if ( file_exists( STARTER_FLAVOR_ASSETS_DIR . 'css/popup-builder-admin.css' ) ) {
			wp_enqueue_style(
				'starter-flavor-popup-builder-admin',
				STARTER_FLAVOR_ASSETS_URL . 'css/popup-builder-admin.css',
				array(),
				STARTER_FLAVOR_VERSION,
				'all'
			);
		}

		// Popup Builder Admin JS (only on popup edit screens)
		if ( function_exists( 'get_current_screen' ) ) {
			$screen = get_current_screen();
			if ( $screen && $screen->post_type === 'sf-popup' ) {
				if ( file_exists( STARTER_FLAVOR_ASSETS_DIR . 'js/popup-builder-admin.js' ) ) {
					wp_enqueue_script(
						'starter-flavor-popup-builder-admin',
						STARTER_FLAVOR_ASSETS_URL . 'js/popup-builder-admin.js',
						array(),
						STARTER_FLAVOR_VERSION,
						true
					);
				}
			}
		}

		// Performance Admin CSS
		if ( file_exists( STARTER_FLAVOR_ASSETS_DIR . 'css/performance-admin.css' ) ) {
			wp_enqueue_style(
				'starter-flavor-performance-admin',
				STARTER_FLAVOR_ASSETS_URL . 'css/performance-admin.css',
				array(),
				STARTER_FLAVOR_VERSION,
				'all'
			);
		}
	}

	add_action( 'admin_enqueue_scripts', 'sf_enqueue_pro_admin_assets' );
}

/**
 * ==================================================
 * REGISTER SIDEBARS
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_widgets_init' ) ) {
	/**
	 * Register widget areas.
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_widgets_init() {
		// Main Sidebar
		register_sidebar( array(
			'name'          => esc_html__( 'Main Sidebar', 'starter-flavor' ),
			'id'            => 'main-sidebar',
			'description'   => esc_html__( 'Main sidebar for pages and posts', 'starter-flavor' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );

		// Footer Widget Areas
		for ( $i = 1; $i <= 4; $i++ ) {
			register_sidebar( array(
				'name'          => sprintf( esc_html__( 'Footer Column %d', 'starter-flavor' ), $i ),
				'id'            => 'footer-' . $i,
				'description'   => sprintf( esc_html__( 'Footer column %d widget area', 'starter-flavor' ), $i ),
				'before_widget' => '<div id="%1$s" class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<h4 class="widget-title">',
				'after_title'   => '</h4>',
			) );
		}

		// Widgets Above Page
		register_sidebar( array(
			'name'          => esc_html__( 'Widgets Above Page', 'starter-flavor' ),
			'id'            => 'widgets-above-page',
			'description'   => esc_html__( 'Widgets displayed above the main content', 'starter-flavor' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );

		// Widgets Below Page
		register_sidebar( array(
			'name'          => esc_html__( 'Widgets Below Page', 'starter-flavor' ),
			'id'            => 'widgets-below-page',
			'description'   => esc_html__( 'Widgets displayed below the main content', 'starter-flavor' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );

		// Widgets Above Content
		register_sidebar( array(
			'name'          => esc_html__( 'Widgets Above Content', 'starter-flavor' ),
			'id'            => 'widgets-above-content',
			'description'   => esc_html__( 'Widgets displayed above the post/page content', 'starter-flavor' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );

		// Widgets Below Content
		register_sidebar( array(
			'name'          => esc_html__( 'Widgets Below Content', 'starter-flavor' ),
			'id'            => 'widgets-below-content',
			'description'   => esc_html__( 'Widgets displayed below the post/page content', 'starter-flavor' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );
	}

	add_action( 'widgets_init', 'starter_flavor_widgets_init' );
}

/**
 * ==================================================
 * EXCERPT FILTERS
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_excerpt_length' ) ) {
	/**
	 * Filter the excerpt length.
	 *
	 * @since 1.0.0
	 * @param int $length The excerpt length in words.
	 * @return int The modified excerpt length.
	 */
	function starter_flavor_excerpt_length( $length ) {
		if ( is_admin() ) {
			return $length;
		}
		// Get from customizer, fallback to 20
		$custom_length = get_theme_mod( 'starter_flavor_excerpt_length', 20 );
		return absint( $custom_length );
	}

	add_filter( 'excerpt_length', 'starter_flavor_excerpt_length' );
}

if ( ! function_exists( 'starter_flavor_excerpt_more' ) ) {
	/**
	 * Filter the excerpt "read more" string.
	 *
	 * @since 1.0.0
	 * @param string $more The excerpt "read more" string.
	 * @return string The modified "read more" string.
	 */
	function starter_flavor_excerpt_more( $more ) {
		if ( is_admin() ) {
			return $more;
		}
		return ' ... <a href="' . esc_url( get_permalink() ) . '" class="read-more">' . esc_html__( 'Read More', 'starter-flavor' ) . '</a>';
	}

	add_filter( 'excerpt_more', 'starter_flavor_excerpt_more' );
}

/**
 * ==================================================
 * COMMENT FORM CUSTOMIZATION
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_comment_form_defaults' ) ) {
	/**
	 * Customize comment form defaults.
	 *
	 * @since 1.0.0
	 * @param array $defaults The default comment form arguments.
	 * @return array The modified comment form arguments.
	 */
	function starter_flavor_comment_form_defaults( $defaults ) {
		$defaults['class_form'] = 'comment-form';
		$defaults['title_reply'] = esc_html__( 'Leave a Reply', 'starter-flavor' );
		$defaults['label_submit'] = esc_html__( 'Post Comment', 'starter-flavor' );

		return $defaults;
	}

	add_filter( 'comment_form_defaults', 'starter_flavor_comment_form_defaults' );
}

/**
 * ==================================================
 * BODY CLASS FILTERS
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_body_classes' ) ) {
	/**
	 * Add custom classes to the body element.
	 *
	 * @since 1.0.0
	 * @param array $classes The existing body classes.
	 * @return array The modified body classes.
	 */
	function starter_flavor_body_classes( $classes ) {
		// Add sidebar class if sidebar is present
		if ( starter_flavor_sidebar_present() ) {
			$classes[] = 'with-sidebar';
		} else {
			$classes[] = 'without-sidebar';
		}

		// Add post type class
		if ( is_singular() ) {
			$classes[] = 'singular-' . get_post_type();
		}

		// Add search class
		if ( is_search() ) {
			$classes[] = 'search-results';
		}

		return $classes;
	}

	add_filter( 'body_class', 'starter_flavor_body_classes' );
}

/**
 * ==================================================
 * HELPER FUNCTIONS
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_get_theme_option' ) ) {
	/**
	 * Get theme option.
	 *
	 * @since 1.0.0
	 * @param string $option_name The option name.
	 * @param mixed  $default The default value if option is not set.
	 * @return mixed The option value.
	 */
	function starter_flavor_get_theme_option( $option_name, $default = '' ) {
		$option = get_option( 'starter_flavor_' . $option_name );
		return ! empty( $option ) ? $option : $default;
	}
}

if ( ! function_exists( 'starter_flavor_is_off' ) ) {
	/**
	 * Check if theme option is turned off.
	 *
	 * @since 1.0.0
	 * @param string $option_name The option name.
	 * @return bool True if option is off, false otherwise.
	 */
	function starter_flavor_is_off( $option_name ) {
		return ! starter_flavor_get_theme_option( $option_name );
	}
}

if ( ! function_exists( 'starter_flavor_sidebar_present' ) ) {
	/**
	 * Check if sidebar is present on current page.
	 *
	 * @since 1.0.0
	 * @return bool True if sidebar is present, false otherwise.
	 */
	function starter_flavor_sidebar_present() {
		// Check if we're on a page where sidebar should be shown
		if ( is_singular( 'post' ) || is_archive() || is_search() ) {
			return is_active_sidebar( 'main-sidebar' );
		}

		return false;
	}
}

if ( ! function_exists( 'starter_flavor_get_sidebar_name' ) ) {
	/**
	 * Get the name of the active sidebar.
	 *
	 * @since 1.0.0
	 * @return string The sidebar name.
	 */
	function starter_flavor_get_sidebar_name() {
		$sidebars = wp_get_sidebars_widgets();

		if ( is_active_sidebar( 'main-sidebar' ) ) {
			return 'main-sidebar';
		}

		return '';
	}
}

if ( ! function_exists( 'starter_flavor_create_widgets_area' ) ) {
	/**
	 * Create a widget area dynamically.
	 *
	 * @since 1.0.0
	 * @param string $id The widget area ID.
	 * @param string $name The widget area name.
	 * @param string $description The widget area description.
	 */
	function starter_flavor_create_widgets_area( $id, $name, $description = '' ) {
		register_sidebar( array(
			'name'          => $name,
			'id'            => $id,
			'description'   => $description,
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );
	}
}

if ( ! function_exists( 'starter_flavor_get_header_layout' ) ) {
	/**
	 * Get the header layout from customizer.
	 *
	 * @since 1.0.0
	 * @return string The header layout: 'default', 'centered', or 'transparent'.
	 */
	function starter_flavor_get_header_layout() {
		return starter_flavor_get_theme_option( 'header_layout', 'default' );
	}
}

if ( ! function_exists( 'starter_flavor_get_reading_time' ) ) {
	/**
	 * Calculate reading time in minutes.
	 *
	 * @since 1.0.0
	 * @param string $text The text to calculate reading time for.
	 * @param int    $words_per_minute Average words per minute (default 200).
	 * @return int The estimated reading time in minutes.
	 */
	function starter_flavor_get_reading_time( $text = '', $words_per_minute = 200 ) {
		if ( empty( $text ) ) {
			$text = get_the_content();
		}

		// Remove HTML tags
		$text = wp_strip_all_tags( $text );

		// Count words
		$word_count = str_word_count( $text );

		// Calculate reading time
		$reading_time = ceil( $word_count / $words_per_minute );

		return max( 1, $reading_time );
	}
}

if ( ! function_exists( 'starter_flavor_get_excerpt_by_length' ) ) {
	/**
	 * Get excerpt with custom length.
	 *
	 * @since 1.0.0
	 * @param int    $length The number of words.
	 * @param string $text The text to excerpt (default: current post content).
	 * @param string $suffix The suffix to add (default: '...').
	 * @return string The excerpt.
	 */
	function starter_flavor_get_excerpt_by_length( $length = 20, $text = '', $suffix = '...' ) {
		if ( empty( $text ) ) {
			$text = has_excerpt() ? get_the_excerpt() : get_the_content();
		}

		return wp_trim_words( $text, $length, $suffix );
	}
}

if ( ! function_exists( 'starter_flavor_get_post_categories' ) ) {
	/**
	 * Get post categories as HTML links.
	 *
	 * @since 1.0.0
	 * @param int   $post_id The post ID.
	 * @param bool  $link Whether to wrap in links (default: true).
	 * @return string The HTML string of categories.
	 */
	function starter_flavor_get_post_categories( $post_id = 0, $link = true ) {
		if ( empty( $post_id ) ) {
			$post_id = get_the_ID();
		}

		$categories = get_the_category( $post_id );

		if ( empty( $categories ) ) {
			return '';
		}

		$categories_html = array();

		foreach ( $categories as $category ) {
			if ( $link ) {
				$categories_html[] = sprintf(
					'<a href="%s" class="category-link">%s</a>',
					esc_url( get_category_link( $category->term_id ) ),
					esc_html( $category->name )
				);
			} else {
				$categories_html[] = esc_html( $category->name );
			}
		}

		return implode( ', ', $categories_html );
	}
}

/**
 * ==================================================
 * WP_HEAD META TAGS
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_wp_head' ) ) {
	/**
	 * Add meta tags to wp_head.
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_wp_head() {
		// Viewport Meta Tag
		echo '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">' . "\n";

		// Chrome Color
		echo '<meta name="theme-color" content="#FF5E2E">' . "\n";

		// Remove WordPress version
		echo '<meta name="generator" content="WordPress">' . "\n";
	}

	add_action( 'wp_head', 'starter_flavor_wp_head', 1 );
}

/**
 * ==================================================
 * REMOVE WP VERSION
 * ==================================================
 */

remove_action( 'wp_head', 'wp_generator' );

/**
 * ==================================================
 * INCLUDE ADDITIONAL FILES
 * ==================================================
 */

// Include Customizer
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/customizer.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/customizer.php';
}

// Include Template Tags
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/template-tags.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/template-tags.php';
}

// Include Template Functions
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/template-functions.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/template-functions.php';
}

// Include Elementor Support
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/elementor.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/elementor.php';
}

// Include Navigation Walker
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/walker-nav-menu.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/walker-nav-menu.php';
}

// Include WooCommerce Support
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/woocommerce.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/woocommerce.php';
}

// Include Performance Optimizations
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/performance.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/performance.php';
}

// Include Accessibility Enhancements
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/accessibility.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/accessibility.php';
}

// Include Security Hardening
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/security.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/security.php';
}

// Include RTL Language Support
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/rtl-support.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/rtl-support.php';
}

// Include Header/Footer Builder
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-header-footer-builder.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-header-footer-builder.php';
}

// Include Mega Menu
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-mega-menu.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-mega-menu.php';
}

// Include Blog Layouts
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-blog-layouts.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-blog-layouts.php';
}

// Include Theme Options
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/theme-options.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/theme-options.php';
}

// Include Skin Manager
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-skin-manager.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-skin-manager.php';
}

// Include Front Page Builder
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-front-page.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-front-page.php';
}

// Include Related Posts
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-related-posts.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-related-posts.php';
}

// Include Post Formats
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-post-formats.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-post-formats.php';
}

// Include Single Post Styles
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-single-post-styles.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-single-post-styles.php';
}

// Include Author Pages
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-author-pages.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-author-pages.php';
}

// Include SEO
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-seo.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-seo.php';
}

// Include Blog Filters
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-blog-filters.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-blog-filters.php';
}

// Include AI Assistant
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-ai-assistant.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-ai-assistant.php';
}

// Include Design System
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-design-system.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-design-system.php';
}

// Include Popup Builder
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-popup-builder.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-popup-builder.php';
}

// Include Dynamic Content
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-dynamic-content.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-dynamic-content.php';
}

// Include Performance Pro
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-performance-pro.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-performance-pro.php';
}

/**
 * ==================================================
 * ELEMENTOR FALLBACK & GRACEFUL DEGRADATION
 * ==================================================
 */

// Include Elementor Fallback Handler
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-elementor-fallback.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-elementor-fallback.php';
}

/**
 * ==================================================
 * GDPR/DSGVO COMPLIANCE
 * ==================================================
 */

// Include GDPR Compliance
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-gdpr-compliance.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-gdpr-compliance.php';
}

/**
 * ==================================================
 * STRUCTURED DATA (SCHEMA.ORG JSON-LD)
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_structured_data' ) ) {
	/**
	 * Output structured data (Schema.org JSON-LD) for SEO.
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_structured_data() {
		// Only on frontend
		if ( is_admin() ) {
			return;
		}

		$schema = array(
			'@context' => 'https://schema.org',
		);

		// Article schema for posts
		if ( is_singular( 'post' ) ) {
			$post_id = get_the_ID();
			$post    = get_post( $post_id );

			$schema['@type'] = 'BlogPosting';
			$schema['headline'] = get_the_title();
			$schema['description'] = get_the_excerpt();
			$schema['datePublished'] = get_the_date( 'c' );
			$schema['dateModified'] = get_the_modified_date( 'c' );

			// Author
			if ( get_the_author_meta( 'ID' ) ) {
				$schema['author'] = array(
					'@type' => 'Person',
					'name'  => get_the_author(),
				);
			}

			// Featured image
			if ( has_post_thumbnail() ) {
				$image_id = get_post_thumbnail_id( $post_id );
				$image_url = wp_get_attachment_image_url( $image_id, 'full' );
				$image_meta = wp_get_attachment_metadata( $image_id );

				$schema['image'] = array(
					'@type'  => 'ImageObject',
					'url'    => $image_url,
					'width'  => isset( $image_meta['width'] ) ? (int) $image_meta['width'] : 1200,
					'height' => isset( $image_meta['height'] ) ? (int) $image_meta['height'] : 630,
				);
			}

			// Organization
			$schema['publisher'] = array(
				'@type' => 'Organization',
				'name'  => get_bloginfo( 'name' ),
				'logo'  => array(
					'@type' => 'ImageObject',
					'url'   => get_site_icon_url(),
				),
			);
		} elseif ( is_singular( 'page' ) ) {
			// WebPage schema for pages
			$schema['@type'] = 'WebPage';
			$schema['name'] = get_the_title();
			$schema['description'] = get_the_excerpt();
			$schema['url'] = get_the_permalink();
		} elseif ( is_home() || is_archive() ) {
			// Website schema for home/archive
			$schema['@type'] = 'WebSite';
			$schema['name'] = get_bloginfo( 'name' );
			$schema['description'] = get_bloginfo( 'description' );
			$schema['url'] = home_url();
		} else {
			// Default website schema
			$schema['@type'] = 'WebSite';
			$schema['name'] = get_bloginfo( 'name' );
			$schema['url'] = home_url();
		}

		// Allow custom schema via filter
		$schema = apply_filters( 'starter_flavor_structured_data', $schema );

		if ( ! empty( $schema ) ) {
			echo '<script type="application/ld+json">';
			echo wp_json_encode( $schema, JSON_UNESCAPED_SLASHES );
			echo '</script>' . "\n";
		}
	}

	add_action( 'wp_head', 'starter_flavor_structured_data', 20 );
}

/**
 * ==================================================
 * GUTENBERG/BLOCK EDITOR
 * ==================================================
 */

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/gutenberg.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/gutenberg.php';
}

/**
 * ==================================================
 * PLUGIN INSTALLER
 * ==================================================
 */

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-plugin-installer.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-plugin-installer.php';
}

/**
 * ==================================================
 * PLUGIN INTEGRATIONS
 * ==================================================
 */

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/plugins/tutor-lms.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/plugins/tutor-lms.php';
}

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/plugins/events-calendar.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/plugins/events-calendar.php';
}

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/plugins/wpml.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/plugins/wpml.php';
}

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/plugins/metform.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/plugins/metform.php';
}

/**
 * ==================================================
 * DEMO IMPORTER
 * ==================================================
 */

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-demo-importer.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-demo-importer.php';
}

/**
 * ==================================================
 * ANIMATIONS & PARALLAX
 * ==================================================
 */

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-animations.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-animations.php';
}

/**
 * ==================================================
 * VIDEO BACKGROUND
 * ==================================================
 */

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-video-background.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-video-background.php';
}

/**
 * ==================================================
 * CUSTOM ICON SYSTEM
 * ==================================================
 */

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-icons.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-icons.php';
}

/**
 * ==================================================
 * THEME DASHBOARD
 * ==================================================
 */

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-theme-dashboard.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-theme-dashboard.php';
}

/**
 * ==================================================
 * ELEMENTOR TEMPLATES
 * ==================================================
 */

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-elementor-templates.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-elementor-templates.php';
}

/**
 * ==================================================
 * PORTFOLIO CUSTOM POST TYPE
 * ==================================================
 */

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-portfolio.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-portfolio.php';
}

/**
 * ==================================================
 * MAINTENANCE MODE
 * ==================================================
 */

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-maintenance-mode.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-maintenance-mode.php';
}

/**
 * ==================================================
 * STARTER STUDIO - PREBUILT SECTION LIBRARY
 * ==================================================
 */

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-starter-studio.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-starter-studio.php';
	Starter_Flavor_Starter_Studio::init();
}

/**
 * ==================================================
 * WOOCOMMERCE BUILDER
 * ==================================================
 */

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-woo-builder.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-woo-builder.php';
	Starter_Flavor_Woo_Builder::init();
}

/**
 * ==================================================
 * WOOCOMMERCE ELEMENTOR WIDGETS
 * ==================================================
 */

if ( class_exists( 'Elementor\Plugin' ) ) {
	// Register WooCommerce widget category
	add_action( 'elementor/widgets/register', function() {
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( 
			new \Elementor\Widget_Base()
		);
	});

	// Register Product Grid Widget
	if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/product-grid.php' ) ) {
		require_once STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/product-grid.php';
		
		add_action( 'elementor/widgets/register', function( $widgets_manager ) {
			$widgets_manager->register( new Starter_Flavor_Product_Grid_Widget() );
		});
	}

	// Register Product Categories Widget
	if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/product-categories.php' ) ) {
		require_once STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/product-categories.php';
		
		add_action( 'elementor/widgets/register', function( $widgets_manager ) {
			$widgets_manager->register( new Starter_Flavor_Product_Categories_Widget() );
		});
	}

	// Register SF Form Widget
	if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/sf-form.php' ) ) {
		require_once STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/sf-form.php';

		add_action( 'elementor/widgets/register', function( $widgets_manager ) {
			$widgets_manager->register( new Starter_Flavor_Form_Widget() );
		});
	}

	// Register widget category
	add_action( 'elementor/elements/categories_registered', function( $elements_manager ) {
		$elements_manager->add_category(
			'starter-flavor-woo',
			array(
				'title' => esc_html__( 'WooCommerce', 'starter-flavor' ),
				'icon'  => 'fa fa-shopping-cart',
			)
		);
	});
}

/**
 * ==================================================
 * CONTACT FORM BUILDER
 * ==================================================
 */

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-form-builder.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-form-builder.php';
}

/**
 * ==================================================
 * SETUP WIZARD
 * ==================================================
 */

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-setup-wizard.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-setup-wizard.php';
}

/**
 * ==================================================
 * STARTER STUDIO — PREBUILT SECTIONS LIBRARY
 * ==================================================
 */

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-starter-studio.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-starter-studio.php';
}

/**
 * ==================================================
 * WOOCOMMERCE BUILDER
 * ==================================================
 */

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-woo-builder.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-woo-builder.php';
}

/**
 * ==================================================
 * AI CONTENT ASSISTANT
 * ==================================================
 */

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-ai-assistant.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-ai-assistant.php';
}

/**
 * ==================================================
 * GLOBAL DESIGN SYSTEM
 * ==================================================
 */

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-design-system.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-design-system.php';
}

/**
 * ==================================================
 * PREMIUM FEATURES (POPUP, DYNAMIC CONTENT, PERFORMANCE)
 * ==================================================
 */

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-popup-builder.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-popup-builder.php';
}

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-dynamic-content.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-dynamic-content.php';
}

if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/class-performance-pro.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-performance-pro.php';
}

/**
 * ==================================================
 * PLUGIN REQUIREMENTS (Required + Recommended)
 * ==================================================
 */

if ( is_admin() ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-plugin-requirements.php';
}

/**
 * ==================================================
 * THEME-CHECK COMPLIANCE
 * ==================================================
 */

// Include Theme-Check Compliance Fixes
if ( file_exists( STARTER_FLAVOR_THEME_DIR . '/includes/theme-check-fixes.php' ) ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/theme-check-fixes.php';
}


/**
 * Admin Welcome / Getting-Started Page
 */
if ( is_admin() ) {
	require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-admin-welcome.php';
}

/**
 * Advanced Customizer Panels
 */
require_once STARTER_FLAVOR_THEME_DIR . '/includes/customizer/customizer-advanced.php';

/**
 * Theme Settings Admin Page
 */
require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-theme-settings.php';

/**
 * Gutenberg / Block Editor Support
 */
add_action('after_setup_theme', function() {
    // Block editor styles
    add_theme_support('editor-styles');
    add_editor_style('assets/css/editor-style.css');
    // Wide/Full alignment
    add_theme_support('align-wide');
    // Responsive embeds
    add_theme_support('responsive-embeds');
    // Block color palette (synced with skin)
    add_theme_support('editor-color-palette', [
        ['name'=>__('Primary','starter-flavor'),    'slug'=>'sf-primary',   'color'=>'var(--sf-color-primary,#FF5E2E)'],
        ['name'=>__('Secondary','starter-flavor'),  'slug'=>'sf-secondary', 'color'=>'var(--sf-color-secondary,#1F242E)'],
        ['name'=>__('Accent','starter-flavor'),     'slug'=>'sf-accent',    'color'=>'var(--sf-color-accent,#00D4FF)'],
        ['name'=>__('Background','starter-flavor'), 'slug'=>'sf-bg',        'color'=>'var(--sf-bg,#ffffff)'],
        ['name'=>__('Dark BG','starter-flavor'),    'slug'=>'sf-alt-bg',    'color'=>'var(--sf-alt-bg,#06021D)'],
    ]);
    add_theme_support('disable-custom-colors', false);
    add_theme_support('editor-font-sizes', [
        ['name'=>__('Small','starter-flavor'),   'size'=>13, 'slug'=>'small'],
        ['name'=>__('Normal','starter-flavor'),  'size'=>16, 'slug'=>'normal'],
        ['name'=>__('Large','starter-flavor'),   'size'=>20, 'slug'=>'large'],
        ['name'=>__('Huge','starter-flavor'),    'size'=>28, 'slug'=>'huge'],
    ]);
});

// Gutenberg editor stylesheet
add_action('enqueue_block_editor_assets', function() {
    wp_enqueue_style('sf-block-editor', get_template_directory_uri().'/assets/css/editor-style.css', [], wp_get_theme()->get('Version'));
});

/**
 * Shortcodes Library
 */
require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-shortcodes.php';

/**
 * Custom Login + Coming Soon
 */
require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-custom-pages.php';

/**
 * ═══════════════════════════════════════════════════════
 * STARTER FLAVOR PLATFORM API v2.0
 * ═══════════════════════════════════════════════════════
 * Load order matters:
 * 1. Hook API (foundation) — must be first
 * 2. Design Tokens — output to <head>
 * 3. Module Loader — registers modules, uses Hook API
 * 4. Demo Engine — replaces old demo importer
 */

// 1. Hook & Filter API (Plattform-Herzstück)
require_once STARTER_FLAVOR_THEME_DIR . '/includes/api/class-hook-api.php';

// 2. Design Token System 2.0 (Spacing, Radius, Shadow, Typography Scale)
require_once STARTER_FLAVOR_THEME_DIR . '/includes/api/class-design-tokens.php';

// 3. Module Loader (Feature switches, conditional asset loading)
require_once STARTER_FLAVOR_THEME_DIR . '/includes/api/class-module-loader.php';

// 4. Composable Demo Engine 2.0
require_once STARTER_FLAVOR_THEME_DIR . '/includes/api/class-demo-engine.php';

/**
 * Template Library
 */
require_once STARTER_FLAVOR_THEME_DIR . '/includes/api/class-template-library.php';

/**
 * WooCommerce Pro Features (Quick View, AJAX Cart, Wishlist, Sticky ATC)
 */
if (class_exists('WooCommerce')) {
    require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-woo-pro.php';
}

/**
 * Enqueue Interaction Engine CSS
 */
add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style(
        'sf-interactions',
        STARTER_FLAVOR_THEME_URL . '/assets/css/interactions.css',
        ['starter-flavor-style'],
        STARTER_FLAVOR_VERSION
    );
}, 11);

/**
 * Per-Widget Conditional CSS Loading
 * Loads widget-specific CSS only when that widget is detected on the page.
 */
add_action('wp_enqueue_scripts', function() {
    if (!is_singular() || !defined('ELEMENTOR_VERSION')) return;

    $widget_css_map = [
        'sf_pricing_table' => 'pricing-table',
        'sf_testimonial'   => 'testimonial',
        'sf_services'      => 'services',
    ];

    foreach ($widget_css_map as $widget_name => $css_slug) {
        $css_file = STARTER_FLAVOR_THEME_DIR . "/assets/css/widgets/{$css_slug}.css";
        if (!file_exists($css_file)) continue;

        // Only enqueue if widget is used on current page
        if (sf_is_widget_used($widget_name)) {
            wp_enqueue_style(
                "sf-widget-{$css_slug}",
                STARTER_FLAVOR_THEME_URL . "/assets/css/widgets/{$css_slug}.css",
                ['starter-flavor-style'],
                STARTER_FLAVOR_VERSION
            );
        }
    }
}, 12);

/**
 * Interaction Engine CSS + JS + Per-Widget Asset Loader
 */
add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style('sf-interaction-engine',
        get_template_directory_uri().'/assets/css/interaction-engine.css',
        ['starter-flavor-style'], wp_get_theme()->get('Version')
    );
    wp_enqueue_script('sf-interaction-engine',
        get_template_directory_uri().'/assets/js/interaction-engine.js',
        [], wp_get_theme()->get('Version'), true
    );
});

require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-widget-asset-loader.php';

/**
 * Template Library + Dynamic Content (API)
 */
require_once STARTER_FLAVOR_THEME_DIR . '/includes/api/class-template-library.php';
require_once STARTER_FLAVOR_THEME_DIR . '/includes/api/class-dynamic-content.php';

/**
 * Widget Base Class (Hook API integration)
 */
require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-widget-base.php';

/**
 * Accessibility Enhancements (WCAG 2.1 AA)
 */
require_once STARTER_FLAVOR_THEME_DIR . '/includes/class-accessibility.php';
