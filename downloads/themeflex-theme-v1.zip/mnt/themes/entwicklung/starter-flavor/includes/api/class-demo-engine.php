<?php
/**
 * Composable Demo Engine 2.0
 *
 * Transforms static demo imports into a modular system where users
 * can pick individual components: header, footer, pages, sections.
 *
 * Demo manifest format (JSON):
 * {
 *   "id": "agency",
 *   "name": "Digital Agency",
 *   "skin": "agency",
 *   "components": {
 *     "headers":  ["header-1", "header-2"],
 *     "footers":  ["footer-1"],
 *     "pages":    ["home", "about", "services", "contact"],
 *     "sections": ["hero-a", "services-b", "cta-dark"]
 *   },
 *   "presets": {
 *     "full":    { "headers": ["header-1"], "pages": ["home","about","services","contact"] },
 *     "minimal": { "headers": ["header-1"], "pages": ["home"] }
 *   }
 * }
 *
 * @package Starter_Flavor
 * @since   2.0.0
 */
if (!defined('ABSPATH')) exit;

class Starter_Flavor_Demo_Engine {

    private static ?self $instance = null;
    private array $demos = [];

    public static function instance(): self {
        if (is_null(self::$instance)) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu',                        [$this, 'add_importer_page']);
        add_action('wp_ajax_sf_get_demo_components',   [$this, 'ajax_get_components']);
        add_action('wp_ajax_sf_import_components',     [$this, 'ajax_import_components']);
        add_action('wp_ajax_sf_check_import_status',   [$this, 'ajax_check_status']);
    }

    // ── Demo Discovery ─────────────────────────────────────────────────────

    public function get_all_demos(): array {
        if (!empty($this->demos)) return $this->demos;

        $demos_dir = get_template_directory().'/demos';
        if (!is_dir($demos_dir)) return [];

        foreach (glob($demos_dir.'/*', GLOB_ONLYDIR) as $dir) {
            $manifest_file = $dir.'/manifest.json';
            if (!file_exists($manifest_file)) continue;

            $manifest = json_decode(file_get_contents($manifest_file), true);
            if (!$manifest) continue;

            $manifest['id']            = basename($dir);
            $manifest['dir']           = $dir;
            $manifest['preview_image'] = file_exists($dir.'/preview.jpg')
                ? get_template_directory_uri().'/demos/'.basename($dir).'/preview.jpg'
                : '';

            // Build component list if not in manifest
            if (empty($manifest['components'])) {
                $manifest['components'] = $this->discover_components($dir);
            }

            // Allow extensions to modify manifest
            $manifest = apply_filters('sf_demo_manifest', $manifest, basename($dir));

            $this->demos[$manifest['id']] = $manifest;
        }

        return $this->demos;
    }

    private function discover_components(string $dir): array {
        $components = ['headers'=>[],'footers'=>[],'pages'=>[],'sections'=>[]];

        // Auto-discover from elementor-templates.json
        $templates_file = $dir.'/elementor-templates.json';
        if (file_exists($templates_file)) {
            $templates = json_decode(file_get_contents($templates_file), true) ?: [];
            foreach ($templates as $t) {
                $type = $t['type'] ?? 'page';
                if ($type === 'header')  $components['headers'][]  = $t['title'];
                elseif ($type === 'footer')  $components['footers'][]  = $t['title'];
                elseif ($type === 'section') $components['sections'][] = $t['title'];
                else                         $components['pages'][]    = $t['title'];
            }
        }
        return $components;
    }

    // ── Admin Page ─────────────────────────────────────────────────────────

    public function add_importer_page(): void {
        add_theme_page(
            __('Demo Importer','starter-flavor'),
            __('Demo Importer','starter-flavor'),
            'manage_options',
            'sfa-demo-importer',
            [$this, 'render_importer']
        );
    }

    public function render_importer(): void {
        $demos = $this->get_all_demos();
        $categories = $this->get_categories($demos);
        $nonce = wp_create_nonce('sf_demo_engine_nonce');
        ?>
        <div class="wrap sf-demo-importer" style="font-family:-apple-system,BlinkMacSystemFont,'Inter',sans-serif;">
            <!-- Header -->
            <div style="background:linear-gradient(135deg,#06021D,#1a1f29);border-radius:12px;padding:28px 32px;margin-bottom:24px;display:flex;align-items:center;gap:16px;">
                <div style="font-size:40px;">📦</div>
                <div>
                    <h1 style="margin:0;color:#fff;font-size:1.4rem;font-weight:800;"><?php esc_html_e('Demo Importer — Composable Engine 2.0','starter-flavor'); ?></h1>
                    <p style="margin:0;color:rgba(255,255,255,.55);font-size:13px;"><?php printf(esc_html__('%d demos available · Pick components, not just full demos','starter-flavor'), count($demos)); ?></p>
                </div>
            </div>

            <!-- Category Filter -->
            <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:20px;">
                <button class="sf-demo-cat active" data-cat="all" onclick="sfDemoFilter('all',this)" style="padding:7px 16px;border-radius:20px;border:1px solid #e5e7eb;background:#fff;font-size:13px;font-weight:600;cursor:pointer;"><?php esc_html_e('All','starter-flavor'); ?></button>
                <?php foreach ($categories as $cat): ?>
                <button class="sf-demo-cat" data-cat="<?php echo esc_attr($cat); ?>" onclick="sfDemoFilter('<?php echo esc_js($cat); ?>',this)"
                    style="padding:7px 16px;border-radius:20px;border:1px solid #e5e7eb;background:#f8fafc;font-size:13px;font-weight:600;cursor:pointer;text-transform:capitalize;">
                    <?php echo esc_html($cat); ?>
                </button>
                <?php endforeach; ?>
            </div>

            <!-- Demo Grid -->
            <div id="sf-demo-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:20px;">
                <?php foreach ($demos as $demo): ?>
                <div class="sf-demo-card" data-tags="<?php echo esc_attr(implode(',', $demo['tags'] ?? [])); ?>"
                    style="background:#fff;border:1px solid #e5e7eb;border-radius:12px;overflow:hidden;transition:all .25s;">
                    <!-- Preview Image -->
                    <div style="height:180px;background:linear-gradient(135deg,#06021D,#1a1f29);position:relative;display:flex;align-items:center;justify-content:center;">
                        <?php if ($demo['preview_image']): ?>
                        <img src="<?php echo esc_url($demo['preview_image']); ?>" style="width:100%;height:100%;object-fit:cover;" loading="lazy" />
                        <?php else: ?>
                        <div style="font-size:48px;"><?php echo $this->get_demo_emoji($demo['id']); ?></div>
                        <?php endif; ?>
                        <div style="position:absolute;top:10px;right:10px;background:rgba(0,0,0,.5);color:#fff;font-size:11px;font-weight:700;padding:3px 8px;border-radius:4px;">
                            <?php echo esc_html(ucfirst($demo['skin'] ?? '')); ?>
                        </div>
                    </div>
                    <!-- Info -->
                    <div style="padding:16px;">
                        <h3 style="font-size:15px;font-weight:800;color:#1e293b;margin:0 0 6px;"><?php echo esc_html($demo['name']); ?></h3>
                        <p style="font-size:12px;color:#64748b;margin:0 0 14px;line-height:1.5;"><?php echo esc_html($demo['description'] ?? ''); ?></p>
                        <!-- Component counts -->
                        <div style="display:flex;gap:10px;font-size:11px;color:#94a3b8;margin-bottom:14px;">
                            <?php
                            $comps = $demo['components'] ?? [];
                            if (!empty($comps['pages']))    echo '<span>📄 '.count($comps['pages']).' pages</span>';
                            if (!empty($comps['sections'])) echo '<span>🧩 '.count($comps['sections']).' sections</span>';
                            ?>
                        </div>
                        <!-- Actions -->
                        <div style="display:flex;gap:8px;">
                            <?php if (!empty($demo['preview_url'])): ?>
                            <a href="<?php echo esc_url($demo['preview_url']); ?>" target="_blank" class="button" style="flex:1;text-align:center;font-size:12px;"><?php esc_html_e('Preview','starter-flavor'); ?></a>
                            <?php endif; ?>
                            <button onclick="sfDemoOpen('<?php echo esc_js($demo['id']); ?>')" class="button button-primary"
                                style="flex:1;font-size:12px;font-weight:700;background:linear-gradient(135deg,#FF5E2E,#ED4C1C);border-color:transparent;color:#fff;">
                                <?php esc_html_e('Import…','starter-flavor'); ?>
                            </button>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Import Modal -->
            <div id="sf-demo-modal" style="display:none;position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.6);align-items:center;justify-content:center;">
                <div style="background:#fff;border-radius:16px;width:90%;max-width:640px;padding:32px;position:relative;max-height:90vh;overflow-y:auto;">
                    <button onclick="document.getElementById('sf-demo-modal').style.display='none'" style="position:absolute;top:16px;right:16px;background:none;border:none;font-size:24px;cursor:pointer;color:#94a3b8;">&times;</button>
                    <h2 id="sf-modal-title" style="font-size:1.2rem;font-weight:800;color:#1e293b;margin:0 0 20px;"></h2>

                    <!-- Preset Buttons -->
                    <div style="display:flex;gap:8px;margin-bottom:20px;">
                        <button onclick="sfDemoPreset('full')" class="button" style="font-weight:700;"><?php esc_html_e('Full Demo','starter-flavor'); ?></button>
                        <button onclick="sfDemoPreset('minimal')" class="button"><?php esc_html_e('Minimal (Home only)','starter-flavor'); ?></button>
                        <button onclick="sfDemoPreset('none')" class="button"><?php esc_html_e('Custom','starter-flavor'); ?></button>
                    </div>

                    <!-- Component Selection -->
                    <div id="sf-modal-components"></div>

                    <!-- Options -->
                    <div style="background:#f8fafc;border-radius:10px;padding:16px;margin-top:16px;">
                        <h4 style="margin:0 0 10px;font-size:13px;font-weight:700;color:#1e293b;"><?php esc_html_e('Import Options','starter-flavor'); ?></h4>
                        <label style="display:flex;align-items:center;gap:8px;font-size:13px;margin-bottom:8px;">
                            <input type="checkbox" id="sf-opt-skin" checked> <?php esc_html_e('Apply demo skin','starter-flavor'); ?>
                        </label>
                        <label style="display:flex;align-items:center;gap:8px;font-size:13px;margin-bottom:8px;">
                            <input type="checkbox" id="sf-opt-menus"> <?php esc_html_e('Import menus','starter-flavor'); ?>
                        </label>
                        <label style="display:flex;align-items:center;gap:8px;font-size:13px;">
                            <input type="checkbox" id="sf-opt-overwrite"> <?php esc_html_e('Overwrite existing pages','starter-flavor'); ?>
                        </label>
                    </div>

                    <!-- Progress -->
                    <div id="sf-import-progress" style="display:none;margin-top:16px;">
                        <div style="height:6px;background:#e5e7eb;border-radius:3px;overflow:hidden;margin-bottom:8px;">
                            <div id="sf-progress-bar" style="height:100%;width:0;background:linear-gradient(90deg,#FF5E2E,#00D4FF);transition:width .3s;"></div>
                        </div>
                        <div id="sf-progress-text" style="font-size:13px;color:#64748b;"></div>
                    </div>

                    <div style="display:flex;gap:10px;margin-top:20px;justify-content:flex-end;">
                        <button onclick="document.getElementById('sf-demo-modal').style.display='none'" class="button"><?php esc_html_e('Cancel','starter-flavor'); ?></button>
                        <button id="sf-import-btn" onclick="sfDemoImport()" class="button button-primary"
                            style="font-weight:700;background:linear-gradient(135deg,#FF5E2E,#ED4C1C);border-color:transparent;color:#fff;">
                            <?php esc_html_e('Start Import','starter-flavor'); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <style>
        .sf-demo-cat.active{background:#FF5E2E!important;border-color:#FF5E2E!important;color:#fff!important}
        .sf-demo-card:hover{box-shadow:0 8px 32px rgba(0,0,0,.1);transform:translateY(-2px)}
        .sf-comp-section{margin-bottom:16px}
        .sf-comp-label{font-size:12px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px}
        .sf-comp-grid{display:flex;flex-wrap:wrap;gap:6px}
        .sf-comp-item{display:flex;align-items:center;gap:6px;padding:6px 12px;border:1px solid #e5e7eb;border-radius:6px;background:#f8fafc;font-size:12px;font-weight:600;color:#374151;cursor:pointer;transition:all .15s;user-select:none}
        .sf-comp-item input{pointer-events:none}
        .sf-comp-item:has(input:checked),.sf-comp-item.selected{background:#fff5f2;border-color:#FF5E2E;color:#FF5E2E}
        </style>

        <script>
        var sfCurrentDemo=null;var sfDemoData={};
        var sfNonce='<?php echo esc_js($nonce); ?>';

        function sfDemoFilter(cat,btn){
            document.querySelectorAll('.sf-demo-cat').forEach(b=>b.classList.remove('active'));
            btn.classList.add('active');
            document.querySelectorAll('.sf-demo-card').forEach(card=>{
                var tags=card.dataset.tags||'';
                card.style.display=(cat==='all'||tags.includes(cat))?'':'none';
            });
        }

        function sfDemoOpen(id){
            sfCurrentDemo=id;
            var demos=<?php echo wp_json_encode(array_map(function($d){return ['id'=>$d['id'],'name'=>$d['name'],'components'=>$d['components']??[],'presets'=>$d['presets']??[],'skin'=>$d['skin']??''];}, $demos)); ?>;
            var demo=demos.find(d=>d.id===id);if(!demo)return;
            sfDemoData=demo;
            document.getElementById('sf-modal-title').textContent=demo.name;
            sfRenderComponents(demo.components);
            document.getElementById('sf-demo-modal').style.display='flex';
            document.getElementById('sf-import-progress').style.display='none';
            document.getElementById('sf-import-btn').disabled=false;
            document.getElementById('sf-import-btn').textContent='<?php esc_js_e('Start Import','starter-flavor'); ?>';
        }

        function sfRenderComponents(comps){
            var html='';
            var labels={'pages':'Pages','sections':'Sections','headers':'Headers','footers':'Footers'};
            Object.entries(comps).forEach(([type,items])=>{
                if(!items||!items.length)return;
                html+='<div class="sf-comp-section"><div class="sf-comp-label">'+labels[type]+'</div><div class="sf-comp-grid">';
                items.forEach(item=>{
                    html+='<label class="sf-comp-item selected"><input type="checkbox" name="sf-comp" data-type="'+type+'" value="'+item+'" checked onchange="this.closest(\'.sf-comp-item\').classList.toggle(\'selected\',this.checked)"> '+item+'</label>';
                });
                html+='</div></div>';
            });
            document.getElementById('sf-modal-components').innerHTML=html||'<p style="color:#94a3b8;font-size:13px;"><?php esc_js_e('No components available.','starter-flavor'); ?></p>';
        }

        function sfDemoPreset(preset){
            if(preset==='full'){document.querySelectorAll('#sf-modal-components input[type=checkbox]').forEach(cb=>cb.checked=true&&cb.closest('.sf-comp-item').classList.add('selected'));}
            else if(preset==='none'){document.querySelectorAll('#sf-modal-components input[type=checkbox]').forEach(cb=>{cb.checked=false;cb.closest('.sf-comp-item').classList.remove('selected');});}
            else if(preset==='minimal'){
                document.querySelectorAll('#sf-modal-components input[type=checkbox]').forEach(cb=>{cb.checked=false;cb.closest('.sf-comp-item').classList.remove('selected');});
                var first=document.querySelector('#sf-modal-components input[data-type="pages"]');
                if(first){first.checked=true;first.closest('.sf-comp-item').classList.add('selected');}
            }
        }

        function sfDemoImport(){
            var selected={};
            document.querySelectorAll('#sf-modal-components input[type=checkbox]:checked').forEach(cb=>{
                if(!selected[cb.dataset.type])selected[cb.dataset.type]=[];
                selected[cb.dataset.type].push(cb.value);
            });
            var opts={
                skin:document.getElementById('sf-opt-skin').checked,
                menus:document.getElementById('sf-opt-menus').checked,
                overwrite:document.getElementById('sf-opt-overwrite').checked,
            };
            var btn=document.getElementById('sf-import-btn');
            btn.disabled=true;btn.textContent='<?php esc_js_e('Importing…','starter-flavor'); ?>';
            document.getElementById('sf-import-progress').style.display='block';
            sfUpdateProgress(0,'<?php esc_js_e('Starting import…','starter-flavor'); ?>');

            var fd=new FormData();
            fd.append('action','sf_import_components');
            fd.append('nonce',sfNonce);
            fd.append('demo_id',sfCurrentDemo);
            fd.append('components',JSON.stringify(selected));
            fd.append('options',JSON.stringify(opts));

            fetch(ajaxurl,{method:'POST',body:fd})
            .then(r=>r.json())
            .then(res=>{
                if(res.success){
                    sfUpdateProgress(100,'<?php esc_js_e('Import complete!','starter-flavor'); ?>');
                    btn.textContent='✓ <?php esc_js_e('Done','starter-flavor'); ?>';
                    btn.style.background='#10b981';
                }else{
                    sfUpdateProgress(0,res.data||'Error');
                    btn.disabled=false;btn.textContent='<?php esc_js_e('Try Again','starter-flavor'); ?>';
                }
            })
            .catch(()=>{
                btn.disabled=false;btn.textContent='<?php esc_js_e('Try Again','starter-flavor'); ?>';
            });
        }

        function sfUpdateProgress(pct,text){
            document.getElementById('sf-progress-bar').style.width=pct+'%';
            document.getElementById('sf-progress-text').textContent=text;
        }
        </script>
        <?php
    }

    // ── AJAX Handlers ──────────────────────────────────────────────────────

    public function ajax_get_components(): void {
        check_ajax_referer('sf_demo_engine_nonce', 'nonce');
        $demo_id = sanitize_key($_POST['demo_id'] ?? '');
        $demos   = $this->get_all_demos();
        if (!isset($demos[$demo_id])) wp_send_json_error('Demo not found');
        wp_send_json_success(['components' => $demos[$demo_id]['components'] ?? []]);
    }

    public function ajax_import_components(): void {
        check_ajax_referer('sf_demo_engine_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

        $demo_id    = sanitize_key($_POST['demo_id'] ?? '');
        $components = json_decode(stripslashes($_POST['components'] ?? '{}'), true) ?: [];
        $options    = json_decode(stripslashes($_POST['options']    ?? '{}'), true) ?: [];

        $demos = $this->get_all_demos();
        if (!isset($demos[$demo_id])) wp_send_json_error('Demo not found');

        $demo = $demos[$demo_id];

        /**
         * Fires before demo component import.
         *
         * @param array $demo       Full demo manifest.
         * @param array $components Selected components.
         * @param array $options    Import options.
         */
        do_action('sf_before_demo_import', $demo, $components, $options);

        $imported = 0;

        // Apply skin
        if (!empty($options['skin']) && !empty($demo['skin'])) {
            set_theme_mod('sf_active_skin', $demo['skin']);
            do_action('sf_skin_switched', $demo['skin'], get_theme_mod('sf_active_skin','default'));
        }

        // Import Elementor templates for selected pages/sections
        $templates_file = $demo['dir'].'/elementor-templates.json';
        if (file_exists($templates_file)) {
            $all_templates = json_decode(file_get_contents($templates_file), true) ?: [];
            $selected_all  = array_merge(
                $components['pages']    ?? [],
                $components['sections'] ?? [],
                $components['headers']  ?? [],
                $components['footers']  ?? []
            );

            foreach ($all_templates as $template) {
                if (!in_array($template['title'] ?? '', $selected_all)) continue;
                $this->import_template($template, $options);
                $imported++;
            }
        }

        do_action('sf_after_demo_import', $demo, $components, $imported);

        wp_send_json_success([
            'imported' => $imported,
            'message'  => sprintf(__('%d components imported.', 'starter-flavor'), $imported),
        ]);
    }

    public function ajax_check_status(): void {
        check_ajax_referer('sf_demo_engine_nonce', 'nonce');
        wp_send_json_success(['status' => 'ok']);
    }

    private function import_template(array $template, array $options): void {
        $title    = sanitize_text_field($template['title'] ?? 'Imported Template');
        $type     = sanitize_text_field($template['type'] ?? 'page');
        $content  = $template['content'] ?? [];
        $overwrite = !empty($options['overwrite']);

        // Check existing
        $existing = get_posts(['post_type'=>'elementor_library','title'=>$title,'post_status'=>'publish','numberposts'=>1]);
        if ($existing && !$overwrite) return;

        $post_id = $existing ? $existing[0]->ID : wp_insert_post([
            'post_title'  => $title,
            'post_status' => 'publish',
            'post_type'   => 'elementor_library',
        ]);

        if (is_wp_error($post_id)) return;

        if (!empty($content)) {
            update_post_meta($post_id, '_elementor_data',      wp_slash(wp_json_encode($content)));
            update_post_meta($post_id, '_elementor_edit_mode', 'builder');
            wp_set_object_terms($post_id, $type, 'elementor_library_type');
        }
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private function get_categories(array $demos): array {
        $cats = [];
        foreach ($demos as $demo) {
            foreach ($demo['tags'] ?? [] as $tag) {
                $cats[$tag] = $tag;
            }
        }
        return array_values($cats);
    }

    private function get_demo_emoji(string $id): string {
        $emojis = ['default'=>'🏢','creative'=>'🎨','agency'=>'⚡','saas'=>'🚀','shop'=>'🛒','medical'=>'🏥','restaurant'=>'🍽️','photography'=>'📷','fitness'=>'💪','education'=>'📚','nonprofit'=>'💚','events'=>'🎫','construction'=>'🏗️','realestate'=>'🏡','blog'=>'📰'];
        return $emojis[$id] ?? '📦';
    }
}

Starter_Flavor_Demo_Engine::instance();
