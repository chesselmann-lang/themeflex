<?php
/**
 * Design Token System 2.0
 *
 * Extends the existing color token system with:
 *  - Spacing scale (--sf-space-*)
 *  - Border radius scale (--sf-radius-*)
 *  - Shadow scale (--sf-shadow-*)
 *  - Typography scale (--sf-text-*, --sf-font-*)
 *  - Z-index scale (--sf-z-*)
 *  - Transition presets (--sf-transition-*)
 *  - Breakpoints as custom media queries
 *
 * All tokens are filterable via sf_design_tokens and per-skin overrides.
 *
 * @package Starter_Flavor
 * @since   2.0.0
 */
if (!defined('ABSPATH')) exit;

class Starter_Flavor_Design_Tokens {

    private static ?self $instance = null;

    public static function instance(): self {
        if (is_null(self::$instance)) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('wp_head',              [$this, 'output_global_tokens'], 4);
        add_action('admin_head',           [$this, 'output_global_tokens'], 4);
        add_filter('sf_skin_tokens',       [$this, 'merge_design_tokens'], 10, 2);
    }

    // ── Token Definitions ──────────────────────────────────────────────────

    public function get_tokens(string $skin_id = 'default'): array {
        $base = [

            /* ── SPACING SCALE ── */
            '--sf-space-1'  => '4px',
            '--sf-space-2'  => '8px',
            '--sf-space-3'  => '12px',
            '--sf-space-4'  => '16px',
            '--sf-space-5'  => '24px',
            '--sf-space-6'  => '32px',
            '--sf-space-7'  => '48px',
            '--sf-space-8'  => '64px',
            '--sf-space-9'  => '80px',
            '--sf-space-10' => '96px',
            '--sf-space-11' => '120px',
            '--sf-space-12' => '160px',

            /* ── BORDER RADIUS SCALE ── */
            '--sf-radius-xs' => '4px',
            '--sf-radius-sm' => '6px',
            '--sf-radius-md' => '8px',
            '--sf-radius-lg' => '12px',
            '--sf-radius-xl' => '16px',
            '--sf-radius-2xl'=> '24px',
            '--sf-radius-full'=> '9999px',

            /* ── SHADOW SCALE ── */
            '--sf-shadow-xs'  => '0 1px 2px rgba(0,0,0,0.05)',
            '--sf-shadow-sm'  => '0 2px 8px rgba(0,0,0,0.06)',
            '--sf-shadow-md'  => '0 4px 16px rgba(0,0,0,0.08)',
            '--sf-shadow-lg'  => '0 8px 32px rgba(0,0,0,0.10)',
            '--sf-shadow-xl'  => '0 16px 48px rgba(0,0,0,0.12)',
            '--sf-shadow-2xl' => '0 24px 80px rgba(0,0,0,0.16)',
            '--sf-shadow-inner'=> 'inset 0 2px 4px rgba(0,0,0,0.06)',

            /* ── TYPOGRAPHY SCALE (fluid) ── */
            '--sf-text-xs'  => 'clamp(10px, 1.2vw, 11px)',
            '--sf-text-sm'  => 'clamp(12px, 1.4vw, 13px)',
            '--sf-text-base'=> 'clamp(14px, 1.6vw, 16px)',
            '--sf-text-md'  => 'clamp(15px, 1.8vw, 17px)',
            '--sf-text-lg'  => 'clamp(16px, 2vw, 18px)',
            '--sf-text-xl'  => 'clamp(18px, 2.4vw, 22px)',
            '--sf-text-2xl' => 'clamp(20px, 2.8vw, 26px)',
            '--sf-text-3xl' => 'clamp(24px, 3.2vw, 32px)',
            '--sf-text-4xl' => 'clamp(28px, 4vw, 40px)',
            '--sf-text-5xl' => 'clamp(32px, 5vw, 52px)',
            '--sf-text-6xl' => 'clamp(40px, 6vw, 64px)',
            '--sf-text-7xl' => 'clamp(48px, 7vw, 80px)',

            /* ── FONT WEIGHTS ── */
            '--sf-font-thin'      => '100',
            '--sf-font-light'     => '300',
            '--sf-font-regular'   => '400',
            '--sf-font-medium'    => '500',
            '--sf-font-semibold'  => '600',
            '--sf-font-bold'      => '700',
            '--sf-font-extrabold' => '800',
            '--sf-font-black'     => '900',

            /* ── LINE HEIGHTS ── */
            '--sf-leading-none'   => '1',
            '--sf-leading-tight'  => '1.1',
            '--sf-leading-snug'   => '1.3',
            '--sf-leading-normal' => '1.5',
            '--sf-leading-relaxed'=> '1.7',
            '--sf-leading-loose'  => '2',

            /* ── LETTER SPACING ── */
            '--sf-tracking-tighter'=> '-0.05em',
            '--sf-tracking-tight'  => '-0.025em',
            '--sf-tracking-normal' => '0em',
            '--sf-tracking-wide'   => '0.025em',
            '--sf-tracking-wider'  => '0.05em',
            '--sf-tracking-widest' => '0.1em',

            /* ── Z-INDEX SCALE ── */
            '--sf-z-base'         => '0',
            '--sf-z-raised'       => '10',
            '--sf-z-dropdown'     => '100',
            '--sf-z-sticky'       => '200',
            '--sf-z-overlay'      => '300',
            '--sf-z-modal'        => '400',
            '--sf-z-popover'      => '500',
            '--sf-z-toast'        => '600',
            '--sf-z-tooltip'      => '700',
            '--sf-z-preloader'    => '99999',

            /* ── TRANSITIONS ── */
            '--sf-ease-default'   => 'all 0.2s ease',
            '--sf-ease-fast'      => 'all 0.1s ease',
            '--sf-ease-slow'      => 'all 0.4s ease',
            '--sf-ease-spring'    => 'all 0.35s cubic-bezier(0.34, 1.56, 0.64, 1)',
            '--sf-ease-in'        => 'all 0.2s cubic-bezier(0.4, 0, 1, 1)',
            '--sf-ease-out'       => 'all 0.2s cubic-bezier(0, 0, 0.2, 1)',
            '--sf-ease-in-out'    => 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',

            /* ── CONTENT WIDTHS ── */
            '--sf-w-prose'        => '65ch',
            '--sf-w-content'      => 'var(--sf-content-width, 1290px)',
            '--sf-w-narrow'       => '720px',
            '--sf-w-wide'         => '1440px',

            /* ── COMPONENT SIZES ── */
            '--sf-btn-height-sm'  => '32px',
            '--sf-btn-height-md'  => '44px',
            '--sf-btn-height-lg'  => '52px',
            '--sf-input-height'   => '44px',
            '--sf-header-height'  => '72px',
            '--sf-sidebar-width'  => '360px',

        ];

        /**
         * Filter the complete design token set.
         *
         * @param array  $base     Default token values.
         * @param string $skin_id  Active skin ID.
         */
        return apply_filters('sf_design_tokens', $base, $skin_id);
    }

    // ── Output ─────────────────────────────────────────────────────────────

    public function output_global_tokens(): void {
        $active_skin = function_exists('starter_flavor_skin_manager')
            ? starter_flavor_skin_manager()->get_active_skin()
            : 'default';

        $tokens = $this->get_tokens($active_skin);

        // Skip if no tokens (shouldn't happen)
        if (empty($tokens)) return;

        $css = ':root{';
        foreach ($tokens as $prop => $value) {
            $css .= esc_attr($prop).':'.esc_attr($value).';';
        }
        $css .= '}';

        // Dark mode shadow overrides
        $css .= '[data-theme="dark"]{'
            .'--sf-shadow-xs:0 1px 2px rgba(0,0,0,0.2);'
            .'--sf-shadow-sm:0 2px 8px rgba(0,0,0,0.25);'
            .'--sf-shadow-md:0 4px 16px rgba(0,0,0,0.35);'
            .'--sf-shadow-lg:0 8px 32px rgba(0,0,0,0.45);'
            .'--sf-shadow-xl:0 16px 48px rgba(0,0,0,0.55);'
            .'}';

        echo '<style id="sf-design-tokens">'.$css.'</style>'."\n";
    }

    // ── Merge into skin token output ───────────────────────────────────────

    public function merge_design_tokens(array $tokens, string $skin_id): array {
        // Let skin JSON override specific design tokens
        $skin = function_exists('starter_flavor_skin_manager')
            ? starter_flavor_skin_manager()->get_skin($skin_id)
            : null;

        if (!$skin) return $tokens;

        // Skin can define spacing/radius/shadow overrides
        $skin_tokens = $skin['tokens'] ?? [];
        if (!empty($skin_token_overrides = $skin['token_overrides'] ?? [])) {
            $tokens = array_merge($tokens, $skin_token_overrides);
        }

        return $tokens;
    }
}

Starter_Flavor_Design_Tokens::instance();

// Global shortcut
function sf_token(string $token, string $fallback = ''): string {
    $tokens = Starter_Flavor_Design_Tokens::instance()->get_tokens();
    return $tokens[$token] ?? $fallback;
}
