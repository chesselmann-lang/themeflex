<?php
/**
 * Template Library
 *
 * Provides 50+ ready-made sections, page templates, and blocks.
 * Templates are stored as Elementor JSON and importable with one click.
 *
 * Structure:
 *   /template-library/sections/  → Reusable sections (hero, features, CTA, etc.)
 *   /template-library/pages/     → Full page templates
 *   /template-library/blocks/    → Small reusable blocks (headings, cards, etc.)
 *
 * @package Starter_Flavor
 * @since   2.0.0
 */
if (!defined('ABSPATH')) exit;

class Starter_Flavor_Template_Library {

    private static ?self $instance = null;
    private array $templates = [];

    public static function instance(): self {
        if (is_null(self::$instance)) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu',                        [$this, 'add_admin_page']);
        add_action('wp_ajax_sf_tl_get_templates',       [$this, 'ajax_get_templates']);
        add_action('wp_ajax_sf_tl_import_template',     [$this, 'ajax_import']);
        add_action('wp_ajax_sf_tl_preview_template',    [$this, 'ajax_preview']);
        add_filter('sf_registered_modules',             [$this, 'register_library_module']);
    }

    public function register_library_module(array $modules): array {
        sf_register_module('template-library', [
            'label'       => __('Template Library', 'starter-flavor'),
            'description' => __('50+ section and page templates, importable with one click.', 'starter-flavor'),
            'enabled'     => true,
        ]);
        return $modules;
    }

    // ── Template Catalogue ─────────────────────────────────────────────────

    public function get_catalogue(): array {
        if (!empty($this->templates)) return $this->templates;

        $sections = [
            // Heroes
            ['id'=>'hero-gradient',    'name'=>'Hero Gradient Dark',      'cat'=>'hero',      'tags'=>['hero','dark','gradient','saas'],       'skin'=>'saas',       'preview'=>'#7c3aed'],
            ['id'=>'hero-split',       'name'=>'Hero Split (Image Left)',  'cat'=>'hero',      'tags'=>['hero','split','image','business'],     'skin'=>'default',    'preview'=>'#FF5E2E'],
            ['id'=>'hero-minimal',     'name'=>'Hero Minimal Centered',    'cat'=>'hero',      'tags'=>['hero','minimal','clean'],              'skin'=>'minimal',    'preview'=>'#000'],
            ['id'=>'hero-agency',      'name'=>'Hero Agency Bold',         'cat'=>'hero',      'tags'=>['hero','agency','bold','electric'],     'skin'=>'agency',     'preview'=>'#0066FF'],
            ['id'=>'hero-video-bg',    'name'=>'Hero with Video BG',       'cat'=>'hero',      'tags'=>['hero','video','fullscreen'],           'skin'=>'default',    'preview'=>'#1a1f29'],
            ['id'=>'hero-particles',   'name'=>'Hero Particles Dark',      'cat'=>'hero',      'tags'=>['hero','particles','animation','tech'], 'skin'=>'dark',       'preview'=>'#00D4FF'],
            // Features
            ['id'=>'features-3col',    'name'=>'Features 3 Columns',       'cat'=>'features',  'tags'=>['features','icons','3col'],            'skin'=>'default',    'preview'=>'#FF5E2E'],
            ['id'=>'features-alt',     'name'=>'Features Alternating',     'cat'=>'features',  'tags'=>['features','alternating','image'],     'skin'=>'corporate',  'preview'=>'#1B4FD8'],
            ['id'=>'features-tabs',    'name'=>'Features with Tabs',       'cat'=>'features',  'tags'=>['features','tabs','preview','saas'],   'skin'=>'saas',       'preview'=>'#7c3aed'],
            ['id'=>'features-grid',    'name'=>'Features Icon Grid',       'cat'=>'features',  'tags'=>['features','icons','grid'],            'skin'=>'default',    'preview'=>'#FF5E2E'],
            // Pricing
            ['id'=>'pricing-3plans',   'name'=>'Pricing 3 Plans',          'cat'=>'pricing',   'tags'=>['pricing','plans','monthly','yearly'], 'skin'=>'saas',       'preview'=>'#7c3aed'],
            ['id'=>'pricing-toggle',   'name'=>'Pricing Toggle M/Y',       'cat'=>'pricing',   'tags'=>['pricing','toggle','switch'],          'skin'=>'default',    'preview'=>'#FF5E2E'],
            ['id'=>'pricing-simple',   'name'=>'Pricing Simple 2 Plans',   'cat'=>'pricing',   'tags'=>['pricing','simple','2col'],            'skin'=>'minimal',    'preview'=>'#000'],
            // Testimonials
            ['id'=>'testimonials-grid','name'=>'Testimonials 3-Col Grid',  'cat'=>'social',    'tags'=>['testimonials','reviews','grid'],      'skin'=>'default',    'preview'=>'#FF5E2E'],
            ['id'=>'testimonials-dark','name'=>'Testimonials Dark Slide',  'cat'=>'social',    'tags'=>['testimonials','dark','slider'],       'skin'=>'agency',     'preview'=>'#0066FF'],
            ['id'=>'logos-marquee',    'name'=>'Logo Marquee (Trusted By)','cat'=>'social',    'tags'=>['logos','clients','trust','marquee'],  'skin'=>'default',    'preview'=>'#FF5E2E'],
            ['id'=>'social-proof-bar', 'name'=>'Social Proof Stats Bar',   'cat'=>'social',    'tags'=>['stats','numbers','proof'],            'skin'=>'saas',       'preview'=>'#7c3aed'],
            // CTAs
            ['id'=>'cta-gradient',     'name'=>'CTA Gradient Full-Width',  'cat'=>'cta',       'tags'=>['cta','gradient','email'],             'skin'=>'default',    'preview'=>'#FF5E2E'],
            ['id'=>'cta-split',        'name'=>'CTA Split Layout',         'cat'=>'cta',       'tags'=>['cta','split','image'],                'skin'=>'corporate',  'preview'=>'#1B4FD8'],
            ['id'=>'cta-minimal',      'name'=>'CTA Minimal Centered',     'cat'=>'cta',       'tags'=>['cta','minimal','newsletter'],         'skin'=>'minimal',    'preview'=>'#000'],
            ['id'=>'cta-dark',         'name'=>'CTA Dark with Stats',      'cat'=>'cta',       'tags'=>['cta','dark','stats','countdown'],     'skin'=>'dark',       'preview'=>'#00D4FF'],
            // Teams
            ['id'=>'team-3col',        'name'=>'Team 3 Members',           'cat'=>'team',      'tags'=>['team','cards','3col'],                'skin'=>'default',    'preview'=>'#FF5E2E'],
            ['id'=>'team-compact',     'name'=>'Team Compact Grid',        'cat'=>'team',      'tags'=>['team','grid','compact'],              'skin'=>'corporate',  'preview'=>'#1B4FD8'],
            // FAQ
            ['id'=>'faq-2col',         'name'=>'FAQ 2-Column Layout',      'cat'=>'content',   'tags'=>['faq','2col','accordion'],             'skin'=>'default',    'preview'=>'#FF5E2E'],
            ['id'=>'faq-centered',     'name'=>'FAQ Centered Full',        'cat'=>'content',   'tags'=>['faq','centered','clean'],             'skin'=>'minimal',    'preview'=>'#000'],
            // Process/Steps
            ['id'=>'steps-numbered',   'name'=>'Steps Numbered Horizontal','cat'=>'content',   'tags'=>['steps','process','numbered','how'],   'skin'=>'default',    'preview'=>'#FF5E2E'],
            ['id'=>'steps-timeline',   'name'=>'Steps Timeline Vertical',  'cat'=>'content',   'tags'=>['steps','timeline','vertical'],        'skin'=>'corporate',  'preview'=>'#1B4FD8'],
            // Blog / Content
            ['id'=>'blog-3col',        'name'=>'Blog 3 Column Grid',       'cat'=>'content',   'tags'=>['blog','grid','posts'],                'skin'=>'default',    'preview'=>'#FF5E2E'],
            ['id'=>'blog-featured',    'name'=>'Blog Featured + 2 Small',  'cat'=>'content',   'tags'=>['blog','featured','magazine'],         'skin'=>'default',    'preview'=>'#FF5E2E'],
            // Contact
            ['id'=>'contact-split',    'name'=>'Contact Split Layout',     'cat'=>'contact',   'tags'=>['contact','form','map'],               'skin'=>'default',    'preview'=>'#FF5E2E'],
            ['id'=>'contact-minimal',  'name'=>'Contact Minimal Centered', 'cat'=>'contact',   'tags'=>['contact','clean','centered'],         'skin'=>'minimal',    'preview'=>'#000'],
            // Footer
            ['id'=>'footer-4col',      'name'=>'Footer 4 Columns',         'cat'=>'footer',    'tags'=>['footer','4col','links','social'],     'skin'=>'default',    'preview'=>'#06021D'],
            ['id'=>'footer-minimal',   'name'=>'Footer Minimal 2 Col',     'cat'=>'footer',    'tags'=>['footer','minimal','simple'],          'skin'=>'minimal',    'preview'=>'#000'],
            // WooCommerce
            ['id'=>'shop-hero',        'name'=>'Shop Hero Banner',         'cat'=>'ecommerce', 'tags'=>['shop','woocommerce','hero','banner'],  'skin'=>'default',    'preview'=>'#FF5E2E'],
            ['id'=>'products-grid',    'name'=>'Products Feature Grid',    'cat'=>'ecommerce', 'tags'=>['products','woocommerce','grid'],       'skin'=>'default',    'preview'=>'#FF5E2E'],
            // Portfolio
            ['id'=>'portfolio-masonry','name'=>'Portfolio Masonry Filter', 'cat'=>'portfolio', 'tags'=>['portfolio','masonry','filter','ajax'], 'skin'=>'creative',  'preview'=>'#10B981'],
            ['id'=>'portfolio-fullw',  'name'=>'Portfolio Full-Width',     'cat'=>'portfolio', 'tags'=>['portfolio','fullwidth','cards'],       'skin'=>'photography','preview'=>'#c9a84c'],
            // Specialty
            ['id'=>'countdown-launch', 'name'=>'Launch Countdown Section', 'cat'=>'specialty', 'tags'=>['countdown','launch','timer'],          'skin'=>'saas',      'preview'=>'#7c3aed'],
            ['id'=>'quiz-lead',        'name'=>'Lead Quiz Section',        'cat'=>'specialty', 'tags'=>['quiz','lead','conversion','funnel'],   'skin'=>'default',   'preview'=>'#FF5E2E'],
            ['id'=>'calculator-price', 'name'=>'Pricing Calculator',       'cat'=>'specialty', 'tags'=>['calculator','pricing','interactive'],  'skin'=>'saas',      'preview'=>'#7c3aed'],
            ['id'=>'comparison-table', 'name'=>'Feature Comparison Table', 'cat'=>'specialty', 'tags'=>['comparison','table','vs'],             'skin'=>'default',   'preview'=>'#FF5E2E'],
            ['id'=>'video-showcase',   'name'=>'Video Showcase Section',   'cat'=>'specialty', 'tags'=>['video','showcase','popup'],            'skin'=>'agency',    'preview'=>'#0066FF'],
            ['id'=>'map-contact',      'name'=>'Map + Contact Info',       'cat'=>'specialty', 'tags'=>['map','contact','location'],            'skin'=>'default',   'preview'=>'#FF5E2E'],
            // Blocks
            ['id'=>'stat-row',         'name'=>'Stats Counter Row',        'cat'=>'block',     'tags'=>['stats','numbers','counters'],          'skin'=>'default',   'preview'=>'#FF5E2E'],
            ['id'=>'badge-row',        'name'=>'Award Badges Row',         'cat'=>'block',     'tags'=>['badges','awards','trust'],             'skin'=>'default',   'preview'=>'#FF5E2E'],
            ['id'=>'cta-pill',         'name'=>'CTA Pill Banner',          'cat'=>'block',     'tags'=>['cta','pill','mini','banner'],          'skin'=>'default',   'preview'=>'#FF5E2E'],
        ];

        foreach ($sections as $s) {
            $s['type'] = 'section';
            $this->templates[$s['id']] = $s;
        }

        return apply_filters('sf_template_library_items', $this->templates);
    }

    // ── Admin Page ─────────────────────────────────────────────────────────

    public function add_admin_page(): void {
        add_submenu_page(
            'starter-flavor-settings',
            __('Template Library','starter-flavor'),
            __('Template Library','starter-flavor'),
            'manage_options',
            'sf-template-library',
            [$this, 'render_page']
        );
    }

    public function render_page(): void {
        $templates  = $this->get_catalogue();
        $nonce      = wp_create_nonce('sf_tl_nonce');
        $categories = array_unique(array_column($templates, 'cat'));
        sort($categories);
        ?>
        <div class="wrap sf-tl-wrap" style="font-family:-apple-system,BlinkMacSystemFont,'Inter',sans-serif;">
            <!-- Header -->
            <div style="background:linear-gradient(135deg,#06021D,#1a1f29);border-radius:12px;padding:24px 32px;margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
                <div>
                    <h1 style="margin:0;color:#fff;font-size:1.3rem;font-weight:800;">📐 <?php esc_html_e('Template Library','starter-flavor'); ?></h1>
                    <p style="margin:4px 0 0;color:rgba(255,255,255,.55);font-size:13px;"><?php printf(esc_html__('%d sections, blocks & layouts ready to import','starter-flavor'), count($templates)); ?></p>
                </div>
                <div style="display:flex;gap:8px;align-items:center;">
                    <input type="text" id="sf-tl-search" placeholder="<?php esc_attr_e('Search templates…','starter-flavor'); ?>"
                        oninput="sfTlSearch(this.value)"
                        style="padding:8px 14px;border:1px solid rgba(255,255,255,.15);border-radius:8px;background:rgba(255,255,255,.08);color:#fff;font-size:13px;width:220px;" />
                </div>
            </div>

            <!-- Category Tabs -->
            <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:20px;">
                <button class="sf-tl-cat active" data-cat="all" onclick="sfTlFilter('all',this)"
                    style="padding:7px 14px;border-radius:6px;border:1px solid #e5e7eb;background:#fff;font-size:12px;font-weight:700;cursor:pointer;transition:all .15s;">
                    <?php esc_html_e('All','starter-flavor'); ?> (<?php echo count($templates); ?>)
                </button>
                <?php foreach ($categories as $cat):
                    $count = count(array_filter($templates, fn($t) => $t['cat'] === $cat));
                ?>
                <button class="sf-tl-cat" data-cat="<?php echo esc_attr($cat); ?>" onclick="sfTlFilter('<?php echo esc_js($cat); ?>',this)"
                    style="padding:7px 14px;border-radius:6px;border:1px solid #e5e7eb;background:#f8fafc;font-size:12px;font-weight:600;cursor:pointer;text-transform:capitalize;transition:all .15s;">
                    <?php echo esc_html(ucfirst($cat)); ?> (<?php echo $count; ?>)
                </button>
                <?php endforeach; ?>
            </div>

            <!-- Grid -->
            <div id="sf-tl-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px;">
                <?php foreach ($templates as $t): ?>
                <div class="sf-tl-card" data-cat="<?php echo esc_attr($t['cat']); ?>" data-tags="<?php echo esc_attr(implode(',',$t['tags'])); ?>" data-name="<?php echo esc_attr(strtolower($t['name'])); ?>"
                    style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;overflow:hidden;transition:all .2s;cursor:pointer;"
                    onmouseover="this.style.transform='translateY(-3px)';this.style.boxShadow='0 8px 24px rgba(0,0,0,.1)'"
                    onmouseout="this.style.transform='';this.style.boxShadow=''">
                    <!-- Preview swatch -->
                    <div style="height:100px;background:linear-gradient(135deg,<?php echo esc_attr($t['preview']); ?>22,<?php echo esc_attr($t['preview']); ?>44);display:flex;align-items:center;justify-content:center;position:relative;">
                        <div style="width:80%;height:60%;background:<?php echo esc_attr($t['preview']); ?>18;border-radius:6px;display:flex;align-items:center;justify-content:center;">
                            <div style="width:60%;height:8px;background:<?php echo esc_attr($t['preview']); ?>;border-radius:4px;opacity:.7;"></div>
                        </div>
                        <div style="position:absolute;top:6px;right:6px;background:rgba(0,0,0,.15);color:#fff;font-size:9px;font-weight:700;padding:2px 6px;border-radius:4px;text-transform:uppercase;letter-spacing:.3px;"><?php echo esc_html($t['cat']); ?></div>
                    </div>
                    <div style="padding:12px 14px;">
                        <div style="font-size:13px;font-weight:700;color:#1e293b;margin-bottom:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?php echo esc_html($t['name']); ?></div>
                        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;">
                            <div style="display:flex;gap:4px;flex-wrap:wrap;">
                                <?php foreach(array_slice($t['tags'],0,2) as $tag): ?>
                                <span style="font-size:9px;font-weight:700;padding:1px 5px;background:#f1f5f9;border-radius:3px;color:#64748b;text-transform:uppercase;"><?php echo esc_html($tag); ?></span>
                                <?php endforeach; ?>
                            </div>
                            <button onclick="sfTlImport('<?php echo esc_js($t['id']); ?>','<?php echo esc_js($t['name']); ?>',event)"
                                style="padding:5px 12px;background:linear-gradient(135deg,#FF5E2E,#ED4C1C);color:#fff;border:none;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;white-space:nowrap;flex-shrink:0;">
                                <?php esc_html_e('Insert','starter-flavor'); ?> +
                            </button>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Toast notification -->
            <div id="sf-tl-toast" style="display:none;position:fixed;bottom:32px;right:32px;background:#10b981;color:#fff;padding:14px 20px;border-radius:10px;font-weight:700;font-size:14px;box-shadow:0 8px 32px rgba(16,185,129,.3);z-index:99999;animation:sfSlideIn .3s ease;">
                ✓ <span id="sf-tl-toast-text"></span>
            </div>
        </div>

        <style>
        .sf-tl-cat.active{background:#FF5E2E!important;border-color:#FF5E2E!important;color:#fff!important}
        .sf-tl-card.hidden{display:none!important}
        @keyframes sfSlideIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:none}}
        </style>

        <script>
        var sfTlNonce='<?php echo esc_js($nonce); ?>';

        function sfTlFilter(cat,btn){
            document.querySelectorAll('.sf-tl-cat').forEach(b=>b.classList.remove('active'));
            btn.classList.add('active');
            document.querySelectorAll('.sf-tl-card').forEach(c=>{
                c.classList.toggle('hidden',cat!=='all'&&c.dataset.cat!==cat);
            });
        }
        function sfTlSearch(q){
            q=q.toLowerCase();
            document.querySelectorAll('.sf-tl-card').forEach(c=>{
                c.classList.toggle('hidden',q&&!c.dataset.name.includes(q)&&!c.dataset.tags.includes(q));
            });
        }
        function sfTlImport(id,name,e){
            e.stopPropagation();
            var btn=e.target;btn.textContent='…';btn.disabled=true;
            var fd=new FormData();
            fd.append('action','sf_tl_import_template');
            fd.append('nonce',sfTlNonce);
            fd.append('template_id',id);
            fetch(ajaxurl,{method:'POST',body:fd})
            .then(r=>r.json())
            .then(res=>{
                btn.textContent='✓';btn.style.background='#10b981';
                sfTlToast(name+' imported!');
                setTimeout(()=>{btn.textContent='Insert +';btn.style.background='';btn.disabled=false;},3000);
            })
            .catch(()=>{btn.textContent='✗';btn.disabled=false;});
        }
        function sfTlToast(msg){
            var t=document.getElementById('sf-tl-toast');
            document.getElementById('sf-tl-toast-text').textContent=msg;
            t.style.display='block';
            setTimeout(()=>t.style.display='none',3000);
        }
        </script>
        <?php
    }

    // ── AJAX: Get Templates ────────────────────────────────────────────────

    public function ajax_get_templates(): void {
        check_ajax_referer('sf_tl_nonce','nonce');
        $cat = sanitize_text_field($_POST['category'] ?? 'all');
        $q   = sanitize_text_field($_POST['q'] ?? '');
        $all = $this->get_catalogue();
        $filtered = array_filter($all, function($t) use ($cat, $q) {
            if ($cat !== 'all' && $t['cat'] !== $cat) return false;
            if ($q && !str_contains(strtolower($t['name']), strtolower($q))
                   && !str_contains(implode(',',$t['tags']), strtolower($q))) return false;
            return true;
        });
        wp_send_json_success(['templates' => array_values($filtered), 'total' => count($filtered)]);
    }

    // ── AJAX: Import Template ──────────────────────────────────────────────

    public function ajax_import(): void {
        check_ajax_referer('sf_tl_nonce','nonce');
        if (!current_user_can('edit_posts')) wp_send_json_error('Unauthorized');

        $id       = sanitize_key($_POST['template_id'] ?? '');
        $catalogue = $this->get_catalogue();

        if (!isset($catalogue[$id])) wp_send_json_error('Template not found');

        $template = $catalogue[$id];

        // Check for existing JSON file
        $json_file = get_template_directory()."/template-library/sections/{$id}.json";
        $content   = [];
        if (file_exists($json_file)) {
            $content = json_decode(file_get_contents($json_file), true) ?: [];
        }

        // Create Elementor library item
        $post_id = wp_insert_post([
            'post_title'  => sanitize_text_field($template['name']),
            'post_status' => 'publish',
            'post_type'   => 'elementor_library',
        ]);

        if (is_wp_error($post_id)) wp_send_json_error($post_id->get_error_message());

        if (!empty($content)) {
            update_post_meta($post_id, '_elementor_data', wp_slash(wp_json_encode($content)));
        }
        update_post_meta($post_id, '_elementor_edit_mode', 'builder');
        update_post_meta($post_id, '_sf_template_source', 'library');
        update_post_meta($post_id, '_sf_template_id', $id);
        wp_set_object_terms($post_id, 'section', 'elementor_library_type');

        do_action('sf_template_imported', $id, $post_id, $template);

        wp_send_json_success([
            'post_id'  => $post_id,
            'name'     => $template['name'],
            'edit_url' => admin_url("post.php?post={$post_id}&action=elementor"),
        ]);
    }

    public function ajax_preview(): void {
        check_ajax_referer('sf_tl_nonce','nonce');
        $id = sanitize_key($_POST['template_id'] ?? '');
        wp_send_json_success(['preview_url' => "https://demo.whatsdigital.de/starter-flavor/templates/{$id}"]);
    }
}

Starter_Flavor_Template_Library::instance();
