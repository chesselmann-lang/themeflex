<?php
/**
 * Accessibility Enhancements
 * WCAG 2.1 AA: Skip Links, Focus Styles, ARIA, High Contrast, Touch Targets.
 *
 * @package Starter_Flavor
 * @since   2.0.0
 */
if (!defined('ABSPATH')) exit;

class Starter_Flavor_Accessibility {

    private static ?self $instance = null;

    public static function instance(): self {
        if (is_null(self::$instance)) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('wp_body_open',       [$this, 'skip_link'], 0);
        add_action('wp_head',            [$this, 'accessibility_styles'], 2);
        add_action('wp_footer',          [$this, 'accessibility_js']);
        add_filter('nav_menu_link_attributes', [$this, 'nav_aria'], 10, 4);
        add_filter('the_content',        [$this, 'fix_image_alts']);
        add_filter('wp_get_attachment_image_attributes', [$this, 'ensure_alt'], 10, 2);
        add_action('customize_register', [$this, 'customizer_options']);
    }

    // ── Skip Link ─────────────────────────────────────────────────────────

    public function skip_link(): void {
        echo '<a class="sf-skip-link screen-reader-text" href="#primary">'
            .esc_html__('Skip to main content','starter-flavor')
            .'</a>';
    }

    // ── Inline Accessibility CSS ───────────────────────────────────────────

    public function accessibility_styles(): void {
        $high_contrast = get_theme_mod('sf_high_contrast', false);
        $large_text    = get_theme_mod('sf_large_text', false);
        $reduce_motion = get_theme_mod('sf_reduce_motion', false);
        ?>
        <style id="sf-a11y">
        /* Skip link */
        .sf-skip-link{position:absolute;top:-100px;left:8px;padding:8px 16px;background:var(--sf-color-primary,#FF5E2E);color:#fff;font-weight:700;border-radius:0 0 6px 6px;z-index:999999;text-decoration:none;transition:top .2s}
        .sf-skip-link:focus{top:0!important;outline:3px solid #fff;outline-offset:2px}

        /* Focus ring — visible everywhere */
        :focus-visible{outline:3px solid var(--sf-color-primary,#FF5E2E);outline-offset:3px;border-radius:4px}
        button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:3px solid var(--sf-color-primary,#FF5E2E);outline-offset:3px}

        /* Touch targets — 44×44px minimum */
        button,
        input[type="submit"],
        input[type="button"],
        input[type="reset"],
        .button,
        .sf-btn-primary,
        .sf-btn-secondary,
        [role="button"] {
            min-height: 44px;
            min-width: 44px;
        }
        .sf-nav-link,.menu-item a{min-height:44px;display:inline-flex;align-items:center}

        /* Screen reader utilities */
        .sr-only,.screen-reader-text{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
        .sr-only-focusable:focus,.sr-only-focusable:active{position:static;width:auto;height:auto;overflow:visible;clip:auto;white-space:normal}

        /* High contrast mode */
        <?php if ($high_contrast): ?>
        :root{
            --sf-color-primary:#0000EE;
            --sf-color-secondary:#000;
            --sf-bg:#fff;
            --sf-title:#000;
            --sf-text:#000;
            --sf-border:#000;
        }
        a{color:#0000EE!important}
        a:visited{color:#551A8B!important}
        button,.button{border:2px solid #000!important}
        img{filter:contrast(1.1)}
        <?php endif; ?>

        /* Large text */
        <?php if ($large_text): ?>
        html{font-size:20px}
        <?php endif; ?>

        /* Reduce motion */
        <?php if ($reduce_motion): ?>
        *,*::before,*::after{animation-duration:.001ms!important;animation-iteration-count:1!important;transition-duration:.001ms!important}
        <?php endif; ?>

        /* Auto dark mode (media query fallback) */
        @media (prefers-color-scheme: dark) {
            :root:not([data-theme]):not([data-theme="light"]) {
                --sf-bg: var(--sf-alt-bg, #06021D);
                --sf-bg-2: var(--sf-alt-bg-2, #1a1f29);
                --sf-title: var(--sf-alt-title, #fffefe);
                --sf-text: var(--sf-alt-text, #b8bcc4);
                --sf-border: var(--sf-alt-border, #3c3f47);
            }
        }

        /* Reduced motion system preference */
        @media (prefers-reduced-motion: reduce) {
            *,*::before,*::after{animation-duration:.001ms!important;transition-duration:.001ms!important}
            .sf-motion-float,.sf-motion-bounce,.sf-motion-spin,.sf-motion-heartbeat,.sf-motion-pulse{animation:none!important}
            [data-sf-animate]{opacity:1!important;transform:none!important}
        }

        /* High contrast system preference */
        @media (forced-colors: active) {
            .sf-btn-primary,.sf-btn-secondary{forced-color-adjust:none;border:2px solid ButtonText}
            .sf-feature-card,.sf-service-card{border:1px solid ButtonText}
        }
        </style>
        <?php
    }

    // ── Nav ARIA Enhancement ───────────────────────────────────────────────

    public function nav_aria(array $atts, \WP_Post $item, \stdClass $args, int $depth): array {
        if (0 === $depth && in_array('menu-item-has-children', (array)$item->classes, true)) {
            $atts['aria-haspopup'] = 'true';
            $atts['aria-expanded'] = 'false';
        }
        return $atts;
    }

    // ── Image Alt Text Fix ─────────────────────────────────────────────────

    public function fix_image_alts(string $content): string {
        // Add empty alt to decorative images that lack alt attribute
        return preg_replace('/<img([^>]*?)(?<!alt=")(?<!alt=\')>/i', '<img alt=""$1>', $content);
    }

    public function ensure_alt(array $attr, \WP_Post $attachment): array {
        if (empty($attr['alt'])) {
            $attr['alt'] = get_post_meta($attachment->ID, '_wp_attachment_image_alt', true) ?: '';
        }
        return $attr;
    }

    // ── Accessibility JS ───────────────────────────────────────────────────

    public function accessibility_js(): void {
        ?>
        <script>
        /* A11y enhancements */
        (function(){
            'use strict';

            // Keyboard navigation for dropdowns
            document.querySelectorAll('[aria-haspopup="true"]').forEach(function(trigger){
                trigger.addEventListener('keydown', function(e){
                    if(e.key==='Enter'||e.key===' '){
                        e.preventDefault();
                        var expanded=trigger.getAttribute('aria-expanded')==='true';
                        trigger.setAttribute('aria-expanded',!expanded);
                        var parent=trigger.closest('.menu-item');
                        if(parent)parent.classList.toggle('sf-nav-open',!expanded);
                    }
                    if(e.key==='Escape'){
                        trigger.setAttribute('aria-expanded','false');
                        trigger.closest('.menu-item')?.classList.remove('sf-nav-open');
                        trigger.focus();
                    }
                });
            });

            // Click outside to close dropdowns
            document.addEventListener('click', function(e){
                document.querySelectorAll('[aria-haspopup="true"][aria-expanded="true"]').forEach(function(trigger){
                    if(!trigger.closest('.menu-item').contains(e.target)){
                        trigger.setAttribute('aria-expanded','false');
                        trigger.closest('.menu-item').classList.remove('sf-nav-open');
                    }
                });
            });

            // Add aria-current to active nav links
            var currentUrl = window.location.href;
            document.querySelectorAll('.site-navigation a').forEach(function(a){
                if(a.href === currentUrl) a.setAttribute('aria-current','page');
            });

            // Trap focus in modals
            document.addEventListener('keydown', function(e){
                if(e.key!=='Tab') return;
                var modal = document.querySelector('.sf-popup-modal[aria-hidden="false"], #sf-qv-modal:not([style*="none"])');
                if(!modal) return;
                var focusable = modal.querySelectorAll('button,a,input,select,textarea,[tabindex]:not([tabindex="-1"])');
                if(!focusable.length) return;
                var first = focusable[0], last = focusable[focusable.length-1];
                if(e.shiftKey && document.activeElement===first){ last.focus(); e.preventDefault(); }
                else if(!e.shiftKey && document.activeElement===last){ first.focus(); e.preventDefault(); }
            });

            // Announce dynamic content changes (AJAX) to screen readers
            window.sfAnnounce = function(message, role){
                var el = document.getElementById('sf-sr-announce');
                if(!el){
                    el = document.createElement('div');
                    el.id = 'sf-sr-announce';
                    el.setAttribute('aria-live', role||'polite');
                    el.setAttribute('aria-atomic','true');
                    el.className = 'screen-reader-text';
                    document.body.appendChild(el);
                }
                el.textContent = '';
                setTimeout(function(){ el.textContent = message; }, 100);
            };
        })();
        </script>
        <?php
    }

    // ── Customizer Options ─────────────────────────────────────────────────

    public function customizer_options(WP_Customize_Manager $wp): void {
        $wp->add_section('sf_accessibility', [
            'title'    => __('Accessibility','starter-flavor'),
            'panel'    => 'sf_advanced',
            'priority' => 95,
        ]);
        foreach([
            'sf_high_contrast' => ['High Contrast Mode', 'Increases color contrast for visual impairments.'],
            'sf_large_text'    => ['Large Text Mode',    'Increases base font size to 20px.'],
            'sf_reduce_motion' => ['Reduce Animations',  'Disables all CSS animations and transitions.'],
        ] as $key => [$label, $desc]) {
            $wp->add_setting($key, ['default'=>false,'sanitize_callback'=>'rest_sanitize_boolean']);
            $wp->add_control($key, ['section'=>'sf_accessibility','label'=>__($label,'starter-flavor'),'description'=>__($desc,'starter-flavor'),'type'=>'checkbox']);
        }
    }
}

Starter_Flavor_Accessibility::instance();
