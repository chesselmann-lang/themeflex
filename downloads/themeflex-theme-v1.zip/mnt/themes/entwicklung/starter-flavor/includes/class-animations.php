<?php
/**
 * Parallax & Animation System
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Starter_Flavor_Animations {

	/**
	 * Initialize
	 */
	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_scripts' ) );
		add_action( 'customize_register', array( __CLASS__, 'customize_register' ) );
		add_action( 'wp_footer', array( __CLASS__, 'render_back_to_top_button' ) );
	}

	/**
	 * Enqueue scripts and styles
	 */
	public static function enqueue_scripts() {
		// Only load if animations are enabled
		if ( ! get_theme_mod( 'enable_animations', true ) ) {
			return;
		}

		wp_enqueue_style(
			'sf-animations',
			STARTER_FLAVOR_THEME_URL . '/assets/css/animations.css',
			array(),
			STARTER_FLAVOR_VERSION
		);

		wp_enqueue_script(
			'sf-parallax',
			STARTER_FLAVOR_THEME_URL . '/assets/js/parallax.js',
			array(),
			STARTER_FLAVOR_VERSION,
			true
		);

		wp_enqueue_script(
			'sf-animations',
			STARTER_FLAVOR_THEME_URL . '/assets/js/animations.js',
			array(),
			STARTER_FLAVOR_VERSION,
			true
		);

		wp_localize_script(
			'sf-animations',
			'sfAnimations',
			array(
				'enable' => get_theme_mod( 'enable_animations', true ),
				'smooth_scroll' => get_theme_mod( 'smooth_scroll', true ),
			)
		);
	}

	/**
	 * Customize register
	 */
	public static function customize_register( $wp_customize ) {
		// Animation section
		$wp_customize->add_section(
			'sf_animations',
			array(
				'title' => esc_html__( 'Animations', 'starter-flavor' ),
				'panel' => 'starter_flavor_settings',
			)
		);

		// Enable animations
		$wp_customize->add_setting(
			'enable_animations',
			array(
				'default' => true,
				'sanitize_callback' => 'rest_sanitize_boolean',
				'transport' => 'refresh',
			)
		);

		$wp_customize->add_control(
			'enable_animations',
			array(
				'label' => esc_html__( 'Enable Animations', 'starter-flavor' ),
				'section' => 'sf_animations',
				'type' => 'checkbox',
			)
		);

		// Smooth scroll
		$wp_customize->add_setting(
			'smooth_scroll',
			array(
				'default' => true,
				'sanitize_callback' => 'rest_sanitize_boolean',
				'transport' => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'smooth_scroll',
			array(
				'label' => esc_html__( 'Enable Smooth Scroll', 'starter-flavor' ),
				'section' => 'sf_animations',
				'type' => 'checkbox',
			)
		);

		// Back to top button
		$wp_customize->add_setting(
			'show_back_to_top',
			array(
				'default' => true,
				'sanitize_callback' => 'rest_sanitize_boolean',
				'transport' => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'show_back_to_top',
			array(
				'label' => esc_html__( 'Show Back to Top Button', 'starter-flavor' ),
				'section' => 'sf_animations',
				'type' => 'checkbox',
			)
		);
	}

	/**
	 * Render back to top button
	 */
	public static function render_back_to_top_button() {
		if ( ! get_theme_mod( 'show_back_to_top', true ) ) {
			return;
		}
		?>
		<button id="sf-back-to-top" class="sf-back-to-top" aria-label="<?php esc_attr_e( 'Back to top', 'starter-flavor' ); ?>">
			<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
				<polyline points="18 15 12 9 6 15"></polyline>
			</svg>
		</button>

		<div class="sf-scroll-progress">
			<div class="sf-scroll-progress-bar"></div>
		</div>
		<?php
	}

	/**
	 * Get animation data attributes
	 *
	 * @param string $animation Animation type
	 * @param int $delay Delay in milliseconds
	 * @param int $duration Duration in milliseconds
	 * @return array
	 */
	public static function get_animation_attributes( $animation = 'fade-in', $delay = 0, $duration = 600 ) {
		return array(
			'data-animate' => esc_attr( $animation ),
			'data-animate-delay' => intval( $delay ),
			'data-animate-duration' => intval( $duration ),
		);
	}

	/**
	 * Get parallax data attributes
	 *
	 * @param float $speed Parallax speed (0-1)
	 * @return array
	 */
	public static function get_parallax_attributes( $speed = 0.5 ) {
		return array(
			'data-parallax' => 'true',
			'data-parallax-speed' => floatval( $speed ),
		);
	}

	/**
	 * Get available animations list
	 *
	 * @return array
	 */
	public static function get_animations() {
		return array(
			'fade-in' => esc_html__( 'Fade In', 'starter-flavor' ),
			'slide-up' => esc_html__( 'Slide Up', 'starter-flavor' ),
			'slide-down' => esc_html__( 'Slide Down', 'starter-flavor' ),
			'slide-left' => esc_html__( 'Slide Left', 'starter-flavor' ),
			'slide-right' => esc_html__( 'Slide Right', 'starter-flavor' ),
			'zoom-in' => esc_html__( 'Zoom In', 'starter-flavor' ),
			'flip' => esc_html__( 'Flip', 'starter-flavor' ),
		);
	}
}

// Initialize
Starter_Flavor_Animations::init();
