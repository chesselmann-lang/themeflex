<?php
/**
 * Author Pages Class
 *
 * Manages author pages and bio displays.
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Starter_Flavor_Author_Pages class
 */
class Starter_Flavor_Author_Pages {

	/**
	 * Instance variable
	 *
	 * @var Starter_Flavor_Author_Pages
	 */
	private static $instance = null;

	/**
	 * Get instance
	 *
	 * @return Starter_Flavor_Author_Pages
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'show_user_profile', array( $this, 'add_social_fields' ) );
		add_action( 'edit_user_profile', array( $this, 'add_social_fields' ) );
		add_action( 'personal_options_update', array( $this, 'save_social_fields' ) );
		add_action( 'edit_user_profile_update', array( $this, 'save_social_fields' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/**
	 * Add social fields to user profile
	 *
	 * @param WP_User $user The user object.
	 */
	public function add_social_fields( $user ) {
		if ( ! current_user_can( 'edit_user', $user->ID ) ) {
			return;
		}

		wp_nonce_field( 'starter_flavor_author_social', 'starter_flavor_author_social_nonce' );

		$socials = $this->get_social_fields();

		?>
		<h2><?php esc_html_e( 'Social Media Links', 'starter-flavor' ); ?></h2>
		<table class="form-table">
			<?php foreach ( $socials as $platform => $label ) : ?>
				<tr>
					<th><label for="starter_flavor_<?php echo esc_attr( $platform ); ?>_url"><?php echo esc_html( $label ); ?></label></th>
					<td>
						<input type="url"
							name="starter_flavor_<?php echo esc_attr( $platform ); ?>_url"
							id="starter_flavor_<?php echo esc_attr( $platform ); ?>_url"
							value="<?php echo esc_attr( get_user_meta( $user->ID, 'starter_flavor_' . $platform . '_url', true ) ); ?>"
							class="regular-text" />
						<p class="description"><?php printf( esc_html__( 'Your %s profile URL', 'starter-flavor' ), esc_html( $label ) ); ?></p>
					</td>
				</tr>
			<?php endforeach; ?>
		</table>
		<?php
	}

	/**
	 * Save social fields
	 *
	 * @param int $user_id The user ID.
	 */
	public function save_social_fields( $user_id ) {
		if ( ! isset( $_POST['starter_flavor_author_social_nonce'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( $_POST['starter_flavor_author_social_nonce'], 'starter_flavor_author_social' ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_user', $user_id ) ) {
			return;
		}

		$socials = $this->get_social_fields();

		foreach ( $socials as $platform => $label ) {
			$field_name = 'starter_flavor_' . $platform . '_url';
			if ( isset( $_POST[ $field_name ] ) ) {
				$value = esc_url_raw( $_POST[ $field_name ] );
				update_user_meta( $user_id, $field_name, $value );
			}
		}
	}

	/**
	 * Get social field definitions
	 *
	 * @return array
	 */
	public function get_social_fields() {
		return array(
			'facebook'  => esc_html__( 'Facebook', 'starter-flavor' ),
			'twitter'   => esc_html__( 'Twitter/X', 'starter-flavor' ),
			'instagram' => esc_html__( 'Instagram', 'starter-flavor' ),
			'linkedin'  => esc_html__( 'LinkedIn', 'starter-flavor' ),
			'github'    => esc_html__( 'GitHub', 'starter-flavor' ),
			'website'   => esc_html__( 'Personal Website', 'starter-flavor' ),
		);
	}

	/**
	 * Get author social links
	 *
	 * @param int $user_id Optional user ID.
	 * @return array
	 */
	public function get_author_socials( $user_id = 0 ) {
		if ( 0 === $user_id ) {
			$user_id = get_the_author_meta( 'ID' );
		}

		$socials = $this->get_social_fields();
		$links = array();

		foreach ( $socials as $platform => $label ) {
			$url = get_user_meta( $user_id, 'starter_flavor_' . $platform . '_url', true );
			if ( ! empty( $url ) ) {
				$links[ $platform ] = array(
					'label' => $label,
					'url'   => $url,
				);
			}
		}

		return $links;
	}

	/**
	 * Get social icon class
	 *
	 * @param string $platform The platform name.
	 * @return string
	 */
	public function get_social_icon( $platform ) {
		$icons = array(
			'facebook'  => 'fab fa-facebook-f',
			'twitter'   => 'fab fa-twitter',
			'instagram' => 'fab fa-instagram',
			'linkedin'  => 'fab fa-linkedin-in',
			'github'    => 'fab fa-github',
			'website'   => 'fas fa-globe',
		);

		return isset( $icons[ $platform ] ) ? $icons[ $platform ] : '';
	}

	/**
	 * Get author post count
	 *
	 * @param int $user_id Optional user ID.
	 * @return int
	 */
	public function get_author_post_count( $user_id = 0 ) {
		if ( 0 === $user_id ) {
			$user_id = get_the_author_meta( 'ID' );
		}

		return count_user_posts( $user_id, 'post' );
	}

	/**
	 * Enqueue assets
	 */
	public function enqueue_assets() {
		if ( is_author() || is_singular( 'post' ) ) {
			wp_enqueue_style(
				'starter-flavor-author',
				get_template_directory_uri() . '/assets/css/author.css',
				array(),
				STARTER_FLAVOR_VERSION
			);
		}
	}

	/**
	 * Get author cover image
	 *
	 * @param int $user_id Optional user ID.
	 * @return string
	 */
	public function get_author_cover_image( $user_id = 0 ) {
		if ( 0 === $user_id ) {
			$user_id = get_the_author_meta( 'ID' );
		}

		return get_user_meta( $user_id, 'starter_flavor_author_cover', true );
	}

	/**
	 * Get author stats
	 *
	 * @param int $user_id Optional user ID.
	 * @return array
	 */
	public function get_author_stats( $user_id = 0 ) {
		if ( 0 === $user_id ) {
			$user_id = get_the_author_meta( 'ID' );
		}

		$user = get_user_by( 'ID', $user_id );

		return array(
			'posts'      => $this->get_author_post_count( $user_id ),
			'registered' => $user->user_registered,
		);
	}
}

// Initialize
if ( ! function_exists( 'starter_flavor_author_pages' ) ) {
	/**
	 * Get author pages instance
	 *
	 * @return Starter_Flavor_Author_Pages
	 */
	function starter_flavor_author_pages() {
		return Starter_Flavor_Author_Pages::get_instance();
	}
}

starter_flavor_author_pages();
