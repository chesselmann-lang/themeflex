<?php
/**
 * Custom Login Page + Coming Soon / Maintenance Mode
 *
 * @package Starter_Flavor
 * @since   1.1.0
 */
if (!defined('ABSPATH')) exit;

class Starter_Flavor_Custom_Pages {

    private static ?self $instance = null;

    public static function instance(): self {
        if (is_null(self::$instance)) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        // Custom Login
        if (get_theme_mod('sf_custom_login', true)) {
            add_action('login_head',        [$this, 'login_styles']);
            add_filter('login_headerurl',   fn() => home_url('/'));
            add_filter('login_headertext',  fn() => get_bloginfo('name'));
            add_filter('login_title',       fn($t) => get_bloginfo('name').' — '.__('Login','starter-flavor'));
        }
        // Coming Soon via template page
        add_filter('template_include', [$this, 'coming_soon_template']);
    }

    public function login_styles(): void {
        $logo_id  = get_theme_mod('custom_logo');
        $logo_url = $logo_id ? wp_get_attachment_image_url($logo_id, 'medium') : '';
        $primary  = get_theme_mod('sf_color_primary', '#FF5E2E');
        ?>
        <style>
        body.login {
            background: linear-gradient(135deg, #06021D 0%, #1a1f29 100%);
            font-family: 'Inter', -apple-system, sans-serif;
        }
        #login {
            width: 360px;
            padding: 32px;
            background: rgba(255,255,255,.03);
            border: 1px solid rgba(255,255,255,.08);
            border-radius: 16px;
            backdrop-filter: blur(20px);
        }
        #login h1 a {
            background-image: <?php echo $logo_url ? 'url('.esc_url($logo_url).')' : 'none'; ?>;
            width: 100%;
            height: 60px;
            background-size: contain;
            background-position: center;
            background-repeat: no-repeat;
        }
        .login label { color: rgba(255,255,255,.7); font-size: 13px; }
        .login input[type="text"],
        .login input[type="password"],
        .login input[type="email"] {
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.12);
            border-radius: 8px;
            color: #fff;
            font-size: 14px;
            padding: 10px 14px;
            box-shadow: none;
        }
        .login input[type="text"]:focus,
        .login input[type="password"]:focus {
            border-color: <?php echo esc_attr($primary); ?>;
            box-shadow: 0 0 0 2px <?php echo esc_attr($primary); ?>33;
            outline: none;
        }
        .wp-core-ui .button-primary {
            background: linear-gradient(135deg, <?php echo esc_attr($primary); ?>, #ED4C1C);
            border: none;
            border-radius: 8px;
            font-weight: 700;
            font-size: 14px;
            padding: 10px 20px;
            text-shadow: none;
            box-shadow: 0 4px 16px <?php echo esc_attr($primary); ?>44;
            transition: all .2s;
        }
        .wp-core-ui .button-primary:hover {
            filter: brightness(1.1);
            box-shadow: 0 6px 20px <?php echo esc_attr($primary); ?>66;
        }
        .login .message, .login .success { border-left-color: <?php echo esc_attr($primary); ?>; }
        #backtoblog a, #nav a { color: rgba(255,255,255,.5) !important; font-size: 12px; }
        #backtoblog a:hover, #nav a:hover { color: <?php echo esc_attr($primary); ?> !important; }
        .login form { background: transparent; border: none; box-shadow: none; padding: 0; }
        </style>
        <?php
    }

    public function coming_soon_template(string $template): string {
        $settings = get_option('sf_theme_settings', []);
        $cs_mode  = !empty($settings['coming_soon_mode']);
        if (!$cs_mode || is_user_logged_in() || is_admin()) return $template;
        // Allow wp-login.php
        if (strpos($template, 'wp-login') !== false) return $template;
        $cs_template = locate_template('template-parts/coming-soon.php');
        return $cs_template ?: $template;
    }
}

Starter_Flavor_Custom_Pages::instance();
