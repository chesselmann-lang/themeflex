<?php
/**
 * Elementor Fallback & Graceful Degradation
 *
 * Handles theme functionality when Elementor is not active or outdated
 *
 * @package Starter_Flavor
 * @subpackage Elementor
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Starter_Flavor_Elementor_Fallback' ) ) {
	/**
	 * Elementor Fallback Class
	 *
	 * Provides graceful degradation when Elementor is not available
	 *
	 * @since 1.0.0
	 */
	class Starter_Flavor_Elementor_Fallback {

		/**
		 * Constructor
		 *
		 * @since 1.0.0
		 */
		public function __construct() {
			add_action( 'wp_loaded', array( $this, 'check_elementor_status' ) );
			add_action( 'admin_notices', array( $this, 'show_admin_notices' ) );
			add_filter( 'wp_enqueue_scripts', array( $this, 'conditionally_enqueue_assets' ), 1 );
		}

		/**
		 * Check Elementor Status and Compatibility
		 *
		 * @since 1.0.0
		 */
		public function check_elementor_status() {
			// Store Elementor status as transient for quick checks
			set_transient( 'sf_elementor_active', $this->is_elementor_active(), 60 * 60 );
			set_transient( 'sf_elementor_version', $this->get_elementor_version(), 60 * 60 );
		}

		/**
		 * Check if Elementor is Active
		 *
		 * @since 1.0.0
		 * @return bool
		 */
		private function is_elementor_active() {
			return did_action( 'elementor/loaded' ) || class_exists( 'Elementor\Plugin' );
		}

		/**
		 * Get Elementor Version
		 *
		 * @since 1.0.0
		 * @return string|null
		 */
		private function get_elementor_version() {
			if ( ! $this->is_elementor_active() ) {
				return null;
			}

			if ( defined( 'ELEMENTOR_VERSION' ) ) {
				return ELEMENTOR_VERSION;
			}

			return null;
		}

		/**
		 * Check if Elementor Version is Compatible (3.0+)
		 *
		 * @since 1.0.0
		 * @return bool
		 */
		private function is_elementor_compatible() {
			$version = $this->get_elementor_version();

			if ( ! $version ) {
				return false;
			}

			// Version 3.0.0 or higher required
			return version_compare( $version, '3.0.0', '>=' );
		}

		/**
		 * Show Admin Notices
		 *
		 * @since 1.0.0
		 */
		public function show_admin_notices() {
			// Only show notices to admins
			if ( ! current_user_can( 'manage_options' ) ) {
				return;
			}

			$elementor_active = $this->is_elementor_active();

			// Elementor not installed/active
			if ( ! $elementor_active ) {
				$this->show_elementor_missing_notice();
				return;
			}

			// Elementor is outdated
			if ( ! $this->is_elementor_compatible() ) {
				$this->show_elementor_outdated_notice();
			}
		}

		/**
		 * Show Notice: Elementor Missing
		 *
		 * @since 1.0.0
		 */
		private function show_elementor_missing_notice() {
			?>
			<div class="notice notice-warning is-dismissible">
				<p>
					<strong><?php esc_html_e( 'Starter Flavor:', 'starter-flavor' ); ?></strong>
					<?php esc_html_e( 'This theme is optimized for Elementor Page Builder. Please install and activate Elementor to unlock all theme features.', 'starter-flavor' ); ?>
				</p>
				<p>
					<a href="<?php echo esc_url( admin_url( 'plugin-install.php?tab=search&s=elementor' ) ); ?>" class="button button-primary">
						<?php esc_html_e( 'Install Elementor', 'starter-flavor' ); ?>
					</a>
				</p>
				<p style="font-size: 0.9em; color: #666;">
					<?php esc_html_e( 'You can still use the block editor for basic layouts without Elementor, but advanced customization requires Elementor.', 'starter-flavor' ); ?>
				</p>
			</div>
			<?php
		}

		/**
		 * Show Notice: Elementor Outdated
		 *
		 * @since 1.0.0
		 */
		private function show_elementor_outdated_notice() {
			$current_version = $this->get_elementor_version();
			?>
			<div class="notice notice-error is-dismissible">
				<p>
					<strong><?php esc_html_e( 'Starter Flavor:', 'starter-flavor' ); ?></strong>
					<?php
					echo wp_kses_post(
						sprintf(
							/* translators: %1$s: current version, %2$s: required version */
							__( 'Your Elementor version (%1$s) is outdated. The theme requires Elementor %2$s or higher for full compatibility.', 'starter-flavor' ),
							esc_html( $current_version ),
							'3.0.0'
						)
					);
					?>
				</p>
				<p>
					<a href="<?php echo esc_url( admin_url( 'plugins.php' ) ); ?>" class="button button-primary">
						<?php esc_html_e( 'Update Elementor', 'starter-flavor' ); ?>
					</a>
				</p>
			</div>
			<?php
		}

		/**
		 * Conditionally Enqueue Assets
		 *
		 * Only enqueue Elementor-dependent assets if Elementor is active
		 *
		 * @since 1.0.0
		 */
		public function conditionally_enqueue_assets() {
			// Only enqueue Elementor assets if the plugin is active
			if ( ! $this->is_elementor_active() ) {
				// Enqueue basic fallback styles for block editor
				wp_enqueue_style(
					'starter-flavor-block-fallback',
					STARTER_FLAVOR_ASSETS_URL . 'css/block-editor-fallback.css',
					array( 'wp-block-styles' ),
					STARTER_FLAVOR_VERSION,
					'all'
				);

				return;
			}

			// Elementor is active, proceed with normal enqueuing
			$this->enqueue_elementor_assets();
		}

		/**
		 * Enqueue Elementor Assets
		 *
		 * This is only called if Elementor is active
		 *
		 * @since 1.0.0
		 */
		private function enqueue_elementor_assets() {
			// Elementor widgets CSS
			if ( file_exists( STARTER_FLAVOR_ASSETS_DIR . 'css/elementor-widgets.css' ) ) {
				wp_enqueue_style(
					'starter-flavor-elementor-widgets',
					STARTER_FLAVOR_ASSETS_URL . 'css/elementor-widgets.css',
					array(),
					STARTER_FLAVOR_VERSION,
					'all'
				);
			}

			// Elementor widgets JS
			if ( file_exists( STARTER_FLAVOR_ASSETS_DIR . 'js/elementor-widgets.js' ) ) {
				wp_enqueue_script(
					'starter-flavor-elementor-widgets',
					STARTER_FLAVOR_ASSETS_URL . 'js/elementor-widgets.js',
					array( 'jquery' ),
					STARTER_FLAVOR_VERSION,
					true
				);
			}
		}

		/**
		 * Check if Elementor is Active (Public Helper)
		 *
		 * Used throughout the theme to conditionally load features
		 *
		 * @since 1.0.0
		 * @return bool
		 */
		public static function elementor_is_active() {
			return did_action( 'elementor/loaded' ) || class_exists( 'Elementor\Plugin' );
		}

		/**
		 * Check if Elementor is Compatible (Public Helper)
		 *
		 * Used throughout the theme to conditionally load features
		 *
		 * @since 1.0.0
		 * @return bool
		 */
		public static function elementor_is_compatible() {
			if ( ! self::elementor_is_active() ) {
				return false;
			}

			if ( defined( 'ELEMENTOR_VERSION' ) ) {
				return version_compare( ELEMENTOR_VERSION, '3.0.0', '>=' );
			}

			return false;
		}
	}

	// Instantiate the class
	new Starter_Flavor_Elementor_Fallback();
}

/**
 * Helper Function: Check if Elementor is Active
 *
 * Usage: if ( sf_elementor_active() ) { ... }
 *
 * @since 1.0.0
 * @return bool
 */
function sf_elementor_active() {
	return Starter_Flavor_Elementor_Fallback::elementor_is_active();
}

/**
 * Helper Function: Check if Elementor is Compatible
 *
 * Usage: if ( sf_elementor_compatible() ) { ... }
 *
 * @since 1.0.0
 * @return bool
 */
function sf_elementor_compatible() {
	return Starter_Flavor_Elementor_Fallback::elementor_is_compatible();
}
