<?php
/**
 * Elementor Template Library System
 *
 * Registers and manages pre-built Elementor page templates for Starter Flavor theme.
 * Allows users to import templates with one click from Elementor editor.
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Starter_Flavor_Elementor_Templates {

	/**
	 * Template library directory
	 *
	 * @var string
	 */
	private static $templates_dir = '';

	/**
	 * Available templates
	 *
	 * @var array
	 */
	private static $templates = array();

	/**
	 * Initialize the template system
	 */
	public static function init() {
		// Only initialize if Elementor is active
		if ( ! did_action( 'elementor/loaded' ) ) {
			return;
		}

		self::$templates_dir = STARTER_FLAVOR_THEME_DIR . '/elementor-templates';

		// Register Elementor hooks
		add_action( 'elementor/theme/register_locations', array( __CLASS__, 'register_elementor_locations' ) );
		add_filter( 'elementor/files/css/print_external_css', '__return_false' );

		// Admin hooks
		add_action( 'admin_menu', array( __CLASS__, 'register_admin_page' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_assets' ) );

		// AJAX hooks
		add_action( 'wp_ajax_sf_get_templates', array( __CLASS__, 'ajax_get_templates' ) );
		add_action( 'wp_ajax_sf_import_template', array( __CLASS__, 'ajax_import_template' ) );

		// Elementor template library source
		add_action( 'elementor/template-library/sources/register', array( __CLASS__, 'register_template_source' ) );
	}

	/**
	 * Register Elementor locations for this theme
	 */
	public static function register_elementor_locations() {
		if ( ! function_exists( 'elementor_theme_do_location' ) ) {
			return;
		}

		elementor_theme_register_location( 'header', array(
			'edit_in_elementor' => true,
			'panel_category'    => 'theme',
			'label'             => esc_html__( 'Header', 'starter-flavor' ),
		) );

		elementor_theme_register_location( 'footer', array(
			'edit_in_elementor' => true,
			'panel_category'    => 'theme',
			'label'             => esc_html__( 'Footer', 'starter-flavor' ),
		) );

		elementor_theme_register_location( 'single', array(
			'edit_in_elementor' => true,
			'panel_category'    => 'theme',
			'label'             => esc_html__( 'Single Post', 'starter-flavor' ),
		) );

		elementor_theme_register_location( 'archive', array(
			'edit_in_elementor' => true,
			'panel_category'    => 'theme',
			'label'             => esc_html__( 'Archive', 'starter-flavor' ),
		) );
	}

	/**
	 * Register custom template source for Starter Flavor
	 */
	public static function register_template_source() {
		if ( ! class_exists( '\Elementor\TemplateLibrary\Sources\Base' ) ) {
			return;
		}

		require_once self::$templates_dir . '/class-template-source.php';
		\Elementor\Plugin::$instance->templates_manager->register_source(
			'\Starter_Flavor_Template_Source'
		);
	}

	/**
	 * Register admin page for template management
	 */
	public static function register_admin_page() {
		add_submenu_page(
			'themes.php',
			esc_html__( 'Elementor Templates', 'starter-flavor' ),
			esc_html__( 'Elementor Templates', 'starter-flavor' ),
			'manage_options',
			'starter-flavor-templates',
			array( __CLASS__, 'render_admin_page' )
		);
	}

	/**
	 * Render admin template library page
	 */
	public static function render_admin_page() {
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Starter Flavor - Elementor Templates', 'starter-flavor' ); ?></h1>
			<p><?php esc_html_e( 'Browse and import pre-built page templates. Click "Import" to add a template to your site.', 'starter-flavor' ); ?></p>

			<div id="sf-templates-container" class="sf-templates-grid">
				<div class="sf-loading"><?php esc_html_e( 'Loading templates...', 'starter-flavor' ); ?></div>
			</div>
		</div>

		<!-- Template Card Modal -->
		<div id="sf-template-modal" class="sf-modal" style="display: none;">
			<div class="sf-modal-content">
				<span class="sf-modal-close">&times;</span>
				<div class="sf-modal-body">
					<div class="sf-modal-preview">
						<img id="sf-modal-preview-img" src="" alt="Template preview">
					</div>
					<div class="sf-modal-info">
						<h3 id="sf-modal-title"></h3>
						<p id="sf-modal-description"></p>
						<div class="sf-modal-meta">
							<p><strong><?php esc_html_e( 'Category:', 'starter-flavor' ); ?></strong> <span id="sf-modal-category"></span></p>
							<p><strong><?php esc_html_e( 'Widgets:', 'starter-flavor' ); ?></strong> <span id="sf-modal-widgets"></span></p>
						</div>
						<button id="sf-modal-import-btn" class="button button-primary">
							<?php esc_html_e( 'Import Template', 'starter-flavor' ); ?>
						</button>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Enqueue admin assets
	 */
	public static function enqueue_admin_assets( $hook ) {
		if ( 'appearance_page_starter-flavor-templates' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'sf-elementor-templates-admin',
			STARTER_FLAVOR_THEME_URL . '/assets/css/elementor-templates-admin.css',
			array(),
			STARTER_FLAVOR_VERSION
		);

		wp_enqueue_script(
			'sf-elementor-templates-admin',
			STARTER_FLAVOR_THEME_URL . '/assets/js/elementor-templates-admin.js',
			array( 'jquery' ),
			STARTER_FLAVOR_VERSION,
			true
		);

		wp_localize_script(
			'sf-elementor-templates-admin',
			'sfTemplatesConfig',
			array(
				'ajax_url'  => admin_url( 'admin-ajax.php' ),
				'nonce'     => wp_create_nonce( 'sf_templates_nonce' ),
				'importing' => esc_html__( 'Importing...', 'starter-flavor' ),
				'success'   => esc_html__( 'Template imported successfully!', 'starter-flavor' ),
				'error'     => esc_html__( 'Error importing template', 'starter-flavor' ),
			)
		);
	}

	/**
	 * AJAX: Get all templates
	 */
	public static function ajax_get_templates() {
		check_ajax_referer( 'sf_templates_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized' );
		}

		$templates = self::get_available_templates();
		wp_send_json_success( $templates );
	}

	/**
	 * AJAX: Import template
	 */
	public static function ajax_import_template() {
		check_ajax_referer( 'sf_templates_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized' );
		}

		$template_id = isset( $_POST['template_id'] ) ? sanitize_text_field( $_POST['template_id'] ) : '';

		if ( ! $template_id ) {
			wp_send_json_error( 'Template ID required' );
		}

		$imported = self::import_template( $template_id );

		if ( $imported ) {
			wp_send_json_success( array(
				'message' => esc_html__( 'Template imported successfully!', 'starter-flavor' ),
				'page_id' => $imported,
			) );
		} else {
			wp_send_json_error( esc_html__( 'Failed to import template', 'starter-flavor' ) );
		}
	}

	/**
	 * Get all available templates with metadata
	 *
	 * @return array
	 */
	public static function get_available_templates() {
		if ( ! empty( self::$templates ) ) {
			return self::$templates;
		}

		$templates = array();
		$template_map = self::get_template_map();

		foreach ( $template_map as $file => $config ) {
			$path = self::$templates_dir . '/' . $file;

			if ( ! file_exists( $path ) ) {
				continue;
			}

			$template_data = json_decode( file_get_contents( $path ), true );

			if ( ! $template_data ) {
				continue;
			}

			$templates[ $config['id'] ] = array(
				'id'          => $config['id'],
				'file'        => $file,
				'title'       => $template_data['title'] ?? $config['name'],
				'category'    => $config['category'],
				'description' => $config['description'],
				'preview'     => $config['preview'] ?? STARTER_FLAVOR_THEME_URL . '/images/template-placeholder.png',
				'type'        => $template_data['type'] ?? 'page',
				'widgets'     => $config['widgets'] ?? array(),
			);
		}

		self::$templates = $templates;
		return $templates;
	}

	/**
	 * Template configuration map
	 *
	 * @return array
	 */
	private static function get_template_map() {
		return array(
			// Homepage Templates
			'homepage-corporate.json' => array(
				'id'          => 'homepage-corporate',
				'name'        => 'Corporate Homepage',
				'category'    => 'Homepage',
				'description' => 'Professional corporate homepage with hero, services, team, and testimonials',
				'widgets'     => array( 'heading', 'image', 'button', 'spacer', 'icon-list' ),
			),
			'homepage-creative.json' => array(
				'id'          => 'homepage-creative',
				'name'        => 'Creative Homepage',
				'category'    => 'Homepage',
				'description' => 'Creative agency homepage with portfolio gallery and progress bars',
				'widgets'     => array( 'heading', 'image-gallery', 'progress-bar' ),
			),
			'homepage-shop.json' => array(
				'id'          => 'homepage-shop',
				'name'        => 'Shop Homepage',
				'category'    => 'Homepage',
				'description' => 'E-commerce homepage with products, countdown timer, and newsletter',
				'widgets'     => array( 'slider', 'countdown', 'social-icons' ),
			),
			// About Page
			'about-us.json' => array(
				'id'          => 'about-us',
				'name'        => 'About Us Page',
				'category'    => 'Inner Pages',
				'description' => 'Complete about page with team section and timeline',
				'widgets'     => array( 'heading', 'image', 'text-editor' ),
			),
			// Services
			'services.json' => array(
				'id'          => 'services',
				'name'        => 'Services Page',
				'category'    => 'Inner Pages',
				'description' => 'Services listing with process steps and FAQ',
				'widgets'     => array( 'heading', 'icon-list', 'spacer' ),
			),
			// Contact
			'contact.json' => array(
				'id'          => 'contact',
				'name'        => 'Contact Page',
				'category'    => 'Inner Pages',
				'description' => 'Contact page with map, form, and location info',
				'widgets'     => array( 'heading', 'text-editor', 'button' ),
			),
			// Portfolio
			'portfolio-grid.json' => array(
				'id'          => 'portfolio-grid',
				'name'        => 'Portfolio Grid',
				'category'    => 'Inner Pages',
				'description' => 'Filterable portfolio gallery with masonry layout',
				'widgets'     => array( 'image-gallery', 'button' ),
			),
			'portfolio-single.json' => array(
				'id'          => 'portfolio-single',
				'name'        => 'Portfolio Single',
				'category'    => 'Inner Pages',
				'description' => 'Single project showcase page',
				'widgets'     => array( 'heading', 'image', 'image-gallery' ),
			),
			// Blog
			'blog-page.json' => array(
				'id'          => 'blog-page',
				'name'        => 'Blog Page',
				'category'    => 'Inner Pages',
				'description' => 'Blog listing with carousel and grid layout',
				'widgets'     => array( 'blog-carousel', 'heading', 'button' ),
			),
			// Pricing
			'pricing.json' => array(
				'id'          => 'pricing',
				'name'        => 'Pricing Page',
				'category'    => 'Inner Pages',
				'description' => 'Pricing tables with comparison and FAQ',
				'widgets'     => array( 'heading', 'text-editor', 'button' ),
			),
			// FAQ
			'faq.json' => array(
				'id'          => 'faq',
				'name'        => 'FAQ Page',
				'category'    => 'Inner Pages',
				'description' => 'Accordion-based FAQ page',
				'widgets'     => array( 'heading', 'text-editor' ),
			),
			// Team
			'team.json' => array(
				'id'          => 'team',
				'name'        => 'Team Page',
				'category'    => 'Inner Pages',
				'description' => 'Team member showcase page',
				'widgets'     => array( 'heading', 'image', 'social-icons' ),
			),
			// Coming Soon
			'coming-soon.json' => array(
				'id'          => 'coming-soon',
				'name'        => 'Coming Soon',
				'category'    => 'Special Pages',
				'description' => 'Full-screen coming soon page with countdown',
				'widgets'     => array( 'heading', 'countdown', 'button', 'social-icons' ),
			),
			// SaaS Landing
			'landing-saas.json' => array(
				'id'          => 'landing-saas',
				'name'        => 'SaaS Landing Page',
				'category'    => 'Landing Pages',
				'description' => 'SaaS product landing page with features and pricing',
				'widgets'     => array( 'heading', 'image', 'button', 'icon-list' ),
			),
			// App Landing
			'landing-app.json' => array(
				'id'          => 'landing-app',
				'name'        => 'App Landing Page',
				'category'    => 'Landing Pages',
				'description' => 'Mobile app landing page with screenshots',
				'widgets'     => array( 'heading', 'slider', 'image', 'button' ),
			),
		);
	}

	/**
	 * Import a template and create a new page
	 *
	 * @param string $template_id Template ID to import
	 * @return int|false Page ID or false on failure
	 */
	public static function import_template( $template_id ) {
		$templates = self::get_available_templates();

		if ( ! isset( $templates[ $template_id ] ) ) {
			return false;
		}

		$template = $templates[ $template_id ];
		$file_path = self::$templates_dir . '/' . $template['file'];

		if ( ! file_exists( $file_path ) ) {
			return false;
		}

		$template_data = json_decode( file_get_contents( $file_path ), true );

		if ( ! $template_data ) {
			return false;
		}

		// Create new page
		$page_id = wp_insert_post( array(
			'post_type'    => 'page',
			'post_title'   => $template_data['title'] ?? $template['title'],
			'post_content' => '',
			'post_status'  => 'draft',
		) );

		if ( ! $page_id ) {
			return false;
		}

		// Add Elementor metadata
		if ( function_exists( 'elementor_get_option' ) && class_exists( '\Elementor\Plugin' ) ) {
			$elementor_data = $template_data['content'] ?? array();

			update_post_meta( $page_id, '_elementor_data', wp_json_encode( $elementor_data ) );
			update_post_meta( $page_id, '_elementor_edit_mode', 'builder' );
			update_post_meta( $page_id, '_elementor_template_type', 'page' );
		}

		return $page_id;
	}
}

// Initialize on WordPress load
add_action( 'wp_loaded', array( 'Starter_Flavor_Elementor_Templates', 'init' ) );
