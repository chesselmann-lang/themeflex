<?php
/**
 * DSGVO/GDPR Compliance Module
 *
 * Handles cookie consent, privacy policy, data export/erasure, and GDPR compliance
 *
 * @package Starter_Flavor
 * @subpackage GDPR
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Starter_Flavor_GDPR_Compliance' ) ) {
	/**
	 * Main GDPR Compliance Class
	 *
	 * @since 1.0.0
	 */
	class Starter_Flavor_GDPR_Compliance {

		/**
		 * Constructor
		 *
		 * @since 1.0.0
		 */
		public function __construct() {
			// Cookie Consent Banner
			add_action( 'wp_footer', array( $this, 'render_cookie_banner' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_cookie_assets' ) );

			// Privacy Policy Page
			add_action( 'after_switch_theme', array( $this, 'register_privacy_page' ) );

			// WordPress Privacy API
			add_filter( 'wp_privacy_personal_data_exporters', array( $this, 'register_privacy_exporter' ) );
			add_filter( 'wp_privacy_personal_data_erasers', array( $this, 'register_privacy_eraser' ) );

			// AJAX Handlers
			add_action( 'wp_ajax_nopriv_sf_save_cookie_consent', array( $this, 'save_cookie_consent' ) );
			add_action( 'wp_ajax_sf_save_cookie_consent', array( $this, 'save_cookie_consent' ) );
		}

		/**
		 * Enqueue Cookie Consent Assets
		 *
		 * @since 1.0.0
		 */
		public function enqueue_cookie_assets() {
			// Only load if not already set
			if ( $this->user_has_cookie_consent() ) {
				return;
			}

			wp_enqueue_style(
				'starter-flavor-cookie-consent',
				STARTER_FLAVOR_ASSETS_URL . 'css/cookie-consent.css',
				array(),
				STARTER_FLAVOR_VERSION,
				'all'
			);

			wp_enqueue_script(
				'starter-flavor-cookie-consent',
				STARTER_FLAVOR_ASSETS_URL . 'js/cookie-consent.js',
				array(),
				STARTER_FLAVOR_VERSION,
				true
			);

			wp_localize_script(
				'starter-flavor-cookie-consent',
				'sfCookieConsent',
				array(
					'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
					'nonce'      => wp_create_nonce( 'sf_cookie_consent_nonce' ),
					'hasConsent' => $this->user_has_cookie_consent(),
					'categories' => $this->get_cookie_categories(),
				)
			);
		}

		/**
		 * Render Cookie Consent Banner
		 *
		 * @since 1.0.0
		 */
		public function render_cookie_banner() {
			// Don't show if user already gave consent
			if ( $this->user_has_cookie_consent() ) {
				return;
			}

			$this->output_cookie_banner_html();
		}

		/**
		 * Output Cookie Banner HTML
		 *
		 * @since 1.0.0
		 */
		private function output_cookie_banner_html() {
			?>
			<div id="sf-cookie-consent" class="sf-cookie-consent" role="dialog" aria-labelledby="sf-cookie-title" aria-describedby="sf-cookie-description">
				<div class="sf-cookie-content">
					<div class="sf-cookie-text">
						<h2 id="sf-cookie-title" class="sf-cookie-title">
							<?php esc_html_e( 'Cookie Settings', 'starter-flavor' ); ?>
						</h2>
						<p id="sf-cookie-description" class="sf-cookie-description">
							<?php
							echo wp_kses_post(
								sprintf(
									/* translators: %s: privacy policy link */
									__( 'We use cookies to enhance your browsing experience and analyze our traffic. Please review our %s.', 'starter-flavor' ),
									'<a href="' . esc_url( get_privacy_policy_url() ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Privacy Policy', 'starter-flavor' ) . '</a>'
								)
							);
							?>
						</p>
					</div>

					<div class="sf-cookie-categories">
						<?php foreach ( $this->get_cookie_categories() as $category_key => $category ) : ?>
							<div class="sf-cookie-category">
								<label class="sf-cookie-label">
									<input
										type="checkbox"
										class="sf-cookie-checkbox"
										name="sf-cookie-<?php echo esc_attr( $category_key ); ?>"
										value="<?php echo esc_attr( $category_key ); ?>"
										<?php checked( $category['required'], true ); ?>
										<?php disabled( $category['required'], true ); ?>
									/>
									<span class="sf-cookie-label-text">
										<strong><?php echo esc_html( $category['name'] ); ?></strong>
										<span class="sf-cookie-description-short"><?php echo esc_html( $category['description'] ); ?></span>
									</span>
								</label>
							</div>
						<?php endforeach; ?>
					</div>

					<div class="sf-cookie-actions">
						<button type="button" class="sf-btn sf-btn-secondary" id="sf-cookie-decline">
							<?php esc_html_e( 'Decline Optional', 'starter-flavor' ); ?>
						</button>
						<button type="button" class="sf-btn sf-btn-primary" id="sf-cookie-accept-all">
							<?php esc_html_e( 'Accept All', 'starter-flavor' ); ?>
						</button>
						<button type="button" class="sf-btn sf-btn-link" id="sf-cookie-settings">
							<?php esc_html_e( 'Settings', 'starter-flavor' ); ?>
						</button>
					</div>
				</div>
			</div>

			<div id="sf-cookie-modal" class="sf-cookie-modal" aria-hidden="true">
				<div class="sf-cookie-modal-content">
					<button type="button" class="sf-cookie-modal-close" id="sf-cookie-modal-close" aria-label="<?php esc_attr_e( 'Close cookie settings', 'starter-flavor' ); ?>">&times;</button>
					<h3><?php esc_html_e( 'Cookie Settings', 'starter-flavor' ); ?></h3>
					<div class="sf-cookie-modal-categories">
						<?php foreach ( $this->get_cookie_categories() as $category_key => $category ) : ?>
							<div class="sf-cookie-modal-category">
								<h4><?php echo esc_html( $category['name'] ); ?></h4>
								<p><?php echo esc_html( $category['description'] ); ?></p>
								<label class="sf-cookie-toggle">
									<input
										type="checkbox"
										class="sf-cookie-modal-checkbox"
										name="sf-cookie-<?php echo esc_attr( $category_key ); ?>"
										value="<?php echo esc_attr( $category_key ); ?>"
										<?php checked( $category['required'], true ); ?>
										<?php disabled( $category['required'], true ); ?>
									/>
									<span class="sf-toggle-slider"></span>
								</label>
								<?php if ( $category['required'] ) : ?>
									<span class="sf-cookie-required"><?php esc_html_e( 'Always Required', 'starter-flavor' ); ?></span>
								<?php endif; ?>
							</div>
						<?php endforeach; ?>
					</div>
					<div class="sf-cookie-modal-actions">
						<button type="button" class="sf-btn sf-btn-secondary" id="sf-cookie-modal-cancel">
							<?php esc_html_e( 'Cancel', 'starter-flavor' ); ?>
						</button>
						<button type="button" class="sf-btn sf-btn-primary" id="sf-cookie-modal-save">
							<?php esc_html_e( 'Save Settings', 'starter-flavor' ); ?>
						</button>
					</div>
				</div>
			</div>
			<?php
		}

		/**
		 * Get Cookie Categories Configuration
		 *
		 * @since 1.0.0
		 * @return array Cookie categories
		 */
		private function get_cookie_categories() {
			return array(
				'necessary'   => array(
					'name'        => __( 'Necessary Cookies', 'starter-flavor' ),
					'description' => __( 'Essential cookies for website functionality, security, and user experience.', 'starter-flavor' ),
					'required'    => true,
				),
				'analytics'   => array(
					'name'        => __( 'Analytics Cookies', 'starter-flavor' ),
					'description' => __( 'Help us understand how visitors interact with our site to improve performance.', 'starter-flavor' ),
					'required'    => false,
				),
				'marketing'   => array(
					'name'        => __( 'Marketing Cookies', 'starter-flavor' ),
					'description' => __( 'Enable personalized advertising and marketing content tracking.', 'starter-flavor' ),
					'required'    => false,
				),
				'preferences' => array(
					'name'        => __( 'Preference Cookies', 'starter-flavor' ),
					'description' => __( 'Remember your settings and preferences for a better experience.', 'starter-flavor' ),
					'required'    => false,
				),
			);
		}

		/**
		 * Check if User Has Cookie Consent
		 *
		 * @since 1.0.0
		 * @return bool
		 */
		private function user_has_cookie_consent() {
			return isset( $_COOKIE[ 'sf_cookie_consent' ] );
		}

		/**
		 * Save Cookie Consent via AJAX
		 *
		 * @since 1.0.0
		 */
		public function save_cookie_consent() {
			check_ajax_referer( 'sf_cookie_consent_nonce', 'nonce' );

			$consent_data = isset( $_POST['consent'] ) ? map_deep( wp_unslash( $_POST['consent'] ), 'sanitize_text_field' ) : array();

			// Set cookie with 1 year expiration (31536000 seconds)
			setcookie(
				'sf_cookie_consent',
				wp_json_encode( $consent_data ),
				time() + 31536000,
				COOKIEPATH,
				COOKIE_DOMAIN,
				is_ssl(),
				true // httponly
			);

			// Also set user meta if logged in
			if ( is_user_logged_in() ) {
				update_user_meta( get_current_user_id(), 'sf_cookie_consent', $consent_data );
			}

			wp_send_json_success( array( 'message' => __( 'Cookie preferences saved.', 'starter-flavor' ) ) );
		}

		/**
		 * Register Privacy Data Exporter
		 *
		 * @since 1.0.0
		 * @param array $exporters Array of exporters.
		 * @return array
		 */
		public function register_privacy_exporter( $exporters ) {
			$exporters['starter-flavor-data'] = array(
				'exporter_friendly_name' => __( 'Starter Flavor Theme Data', 'starter-flavor' ),
				'callback'                => array( $this, 'export_user_data' ),
			);

			return $exporters;
		}

		/**
		 * Export User Data for Privacy Request
		 *
		 * @since 1.0.0
		 * @param string $email_address Email address.
		 * @param int    $page Page number.
		 * @return array
		 */
		public function export_user_data( $email_address, $page = 1 ) {
			$number = 500;
			$page   = (int) $page;

			$user = get_user_by( 'email', $email_address );
			if ( ! $user ) {
				return array(
					'data' => array(),
					'done' => true,
				);
			}

			$data_to_export = array();

			// Export cookie consent preferences
			$cookie_consent = get_user_meta( $user->ID, 'sf_cookie_consent', true );
			if ( ! empty( $cookie_consent ) ) {
				$data_to_export[] = array(
					'group_id'    => 'starter-flavor-cookie-consent',
					'group_label' => __( 'Cookie Consent Preferences', 'starter-flavor' ),
					'item_id'     => 'cookie-consent-1',
					'data'        => array(
						array(
							'name'  => __( 'Consent Categories', 'starter-flavor' ),
							'value' => wp_json_encode( $cookie_consent ),
						),
					),
				);
			}

			// Export popup interactions
			$popup_interactions = get_user_meta( $user->ID, 'sf_popup_interactions', true );
			if ( ! empty( $popup_interactions ) ) {
				$data_to_export[] = array(
					'group_id'    => 'starter-flavor-popup-data',
					'group_label' => __( 'Popup Interactions', 'starter-flavor' ),
					'item_id'     => 'popup-interactions-1',
					'data'        => array(
						array(
							'name'  => __( 'Interaction History', 'starter-flavor' ),
							'value' => wp_json_encode( $popup_interactions ),
						),
					),
				);
			}

			// Export form submissions
			$form_data = get_user_meta( $user->ID, 'sf_form_submissions', true );
			if ( ! empty( $form_data ) ) {
				$data_to_export[] = array(
					'group_id'    => 'starter-flavor-form-data',
					'group_label' => __( 'Form Submissions', 'starter-flavor' ),
					'item_id'     => 'form-data-1',
					'data'        => array(
						array(
							'name'  => __( 'Submission Records', 'starter-flavor' ),
							'value' => wp_json_encode( $form_data ),
						),
					),
				);
			}

			// Export AI Assistant usage data
			if ( class_exists( 'Starter_Flavor_AI_Assistant' ) ) {
				$ai_data = get_user_meta( $user->ID, 'sf_ai_assistant_usage', true );
				if ( ! empty( $ai_data ) ) {
					$data_to_export[] = array(
						'group_id'    => 'starter-flavor-ai-data',
						'group_label' => __( 'AI Assistant Usage Data', 'starter-flavor' ),
						'item_id'     => 'ai-data-1',
						'data'        => array(
							array(
								'name'  => __( 'Usage History', 'starter-flavor' ),
								'value' => wp_json_encode( $ai_data ),
							),
						),
					);
				}
			}

			return array(
				'data' => $data_to_export,
				'done' => true,
			);
		}

		/**
		 * Register Privacy Data Eraser
		 *
		 * @since 1.0.0
		 * @param array $erasers Array of erasers.
		 * @return array
		 */
		public function register_privacy_eraser( $erasers ) {
			$erasers['starter-flavor-data'] = array(
				'eraser_friendly_name' => __( 'Starter Flavor Theme Data', 'starter-flavor' ),
				'callback'             => array( $this, 'erase_user_data' ),
			);

			return $erasers;
		}

		/**
		 * Erase User Data for Privacy Request
		 *
		 * @since 1.0.0
		 * @param string $email_address Email address.
		 * @param int    $page Page number.
		 * @return array
		 */
		public function erase_user_data( $email_address, $page = 1 ) {
			$user = get_user_by( 'email', $email_address );
			if ( ! $user ) {
				return array(
					'items_removed'  => false,
					'items_retained' => false,
					'messages'       => array(),
					'done'           => true,
				);
			}

			$items_removed = false;

			// Erase cookie consent
			if ( delete_user_meta( $user->ID, 'sf_cookie_consent' ) ) {
				$items_removed = true;
			}

			// Erase popup interactions
			if ( delete_user_meta( $user->ID, 'sf_popup_interactions' ) ) {
				$items_removed = true;
			}

			// Erase form submissions
			if ( delete_user_meta( $user->ID, 'sf_form_submissions' ) ) {
				$items_removed = true;
			}

			// Erase AI assistant data
			if ( delete_user_meta( $user->ID, 'sf_ai_assistant_usage' ) ) {
				$items_removed = true;
			}

			return array(
				'items_removed'  => $items_removed,
				'items_retained' => false,
				'messages'       => array(),
				'done'           => true,
			);
		}

		/**
		 * Register Privacy Policy Page
		 *
		 * Creates a Privacy Policy page on theme activation if one doesn't exist
		 *
		 * @since 1.0.0
		 */
		public static function register_privacy_page() {
			// Check if privacy policy page already exists
			$privacy_page = get_page_by_path( 'privacy-policy' );
			if ( $privacy_page ) {
				return;
			}

			// Create the privacy policy page
			$page_id = wp_insert_post( array(
				'post_title'     => __( 'Privacy Policy', 'starter-flavor' ),
				'post_name'      => 'privacy-policy',
				'post_content'   => self::get_privacy_policy_content(),
				'post_type'      => 'page',
				'post_status'    => 'publish',
				'comment_status' => 'closed',
			) );

			if ( $page_id ) {
				// Set it as the privacy policy page
				update_option( 'wp_page_for_privacy_policy', $page_id );
			}
		}

		/**
		 * Get Privacy Policy Content
		 *
		 * @since 1.0.0
		 * @return string Privacy policy HTML content
		 */
		private static function get_privacy_policy_content() {
			$site_name = get_bloginfo( 'name' );
			$site_url  = get_home_url();

			ob_start();
			?>
<!-- wp:heading -->
<h2><?php echo esc_html__( 'Privacy Policy for', 'starter-flavor' ) . ' ' . esc_html( $site_name ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php esc_html_e( 'Last updated: ', 'starter-flavor' ); ?><?php echo esc_html( gmdate( 'F j, Y' ) ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3><?php esc_html_e( '1. Data Controller', 'starter-flavor' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php
echo wp_kses_post(
	sprintf(
		/* translators: %1$s: site name, %2$s: site URL */
		__( '%1$s (%2$s) is responsible for processing your personal data.', 'starter-flavor' ),
		esc_html( $site_name ),
		esc_url( $site_url )
	)
);
?></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3><?php esc_html_e( '2. Data Collection & Processing', 'starter-flavor' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php esc_html_e( 'We collect and process the following categories of personal data:', 'starter-flavor' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul>
	<li><?php esc_html_e( 'Contact information (name, email address, phone number)', 'starter-flavor' ); ?></li>
	<li><?php esc_html_e( 'Usage data (IP address, browser type, pages visited)', 'starter-flavor' ); ?></li>
	<li><?php esc_html_e( 'Cookies and similar tracking technologies', 'starter-flavor' ); ?></li>
	<li><?php esc_html_e( 'Form submission data', 'starter-flavor' ); ?></li>
</ul>
<!-- /wp:list -->

<!-- wp:heading {"level":3} -->
<h3><?php esc_html_e( '3. Cookies & Similar Technologies', 'starter-flavor' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php esc_html_e( 'We use cookies to improve your browsing experience. Cookies are categorized as:', 'starter-flavor' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul>
	<li><strong><?php esc_html_e( 'Necessary Cookies:', 'starter-flavor' ); ?></strong> <?php esc_html_e( 'Required for website functionality and security.', 'starter-flavor' ); ?></li>
	<li><strong><?php esc_html_e( 'Analytics Cookies:', 'starter-flavor' ); ?></strong> <?php esc_html_e( 'Help us understand site usage and improve performance.', 'starter-flavor' ); ?></li>
	<li><strong><?php esc_html_e( 'Marketing Cookies:', 'starter-flavor' ); ?></strong> <?php esc_html_e( 'Enable personalized advertising and content.', 'starter-flavor' ); ?></li>
	<li><strong><?php esc_html_e( 'Preference Cookies:', 'starter-flavor' ); ?></strong> <?php esc_html_e( 'Remember your user preferences and settings.', 'starter-flavor' ); ?></li>
</ul>
<!-- /wp:list -->

<!-- wp:heading {"level":3} -->
<h3><?php esc_html_e( '4. Third-Party Services', 'starter-flavor' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php esc_html_e( 'We may use third-party services that collect and process data on our behalf:', 'starter-flavor' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul>
	<li><?php esc_html_e( 'Google Analytics (analytics and website usage)', 'starter-flavor' ); ?></li>
	<li><?php esc_html_e( 'Email service providers (newsletter subscriptions)', 'starter-flavor' ); ?></li>
	<li><?php esc_html_e( 'AI assistance services (where applicable)', 'starter-flavor' ); ?></li>
	<li><?php esc_html_e( 'CDN providers (content delivery)', 'starter-flavor' ); ?></li>
</ul>
<!-- /wp:list -->

<!-- wp:heading {"level":3} -->
<h3><?php esc_html_e( '5. Your Rights', 'starter-flavor' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php esc_html_e( 'You have the right to:', 'starter-flavor' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul>
	<li><?php esc_html_e( 'Access your personal data', 'starter-flavor' ); ?></li>
	<li><?php esc_html_e( 'Rectify inaccurate data', 'starter-flavor' ); ?></li>
	<li><?php esc_html_e( 'Request deletion of your data', 'starter-flavor' ); ?></li>
	<li><?php esc_html_e( 'Withdraw consent to data processing', 'starter-flavor' ); ?></li>
	<li><?php esc_html_e( 'Object to certain processing activities', 'starter-flavor' ); ?></li>
	<li><?php esc_html_e( 'Request data portability', 'starter-flavor' ); ?></li>
</ul>
<!-- /wp:list -->

<!-- wp:heading {"level":3} -->
<h3><?php esc_html_e( '6. Data Retention', 'starter-flavor' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php esc_html_e( 'We retain your personal data only as long as necessary for the purposes outlined in this policy. You can request deletion at any time through the contact information below.', 'starter-flavor' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3><?php esc_html_e( '7. Contact Information', 'starter-flavor' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php esc_html_e( 'If you have questions about this privacy policy or wish to exercise your rights, please contact us at:', 'starter-flavor' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><?php echo esc_html( get_option( 'admin_email' ) ); ?></p>
<!-- /wp:paragraph -->
			<?php
			return ob_get_clean();
		}
	}

	// Instantiate the class
	new Starter_Flavor_GDPR_Compliance();
}
