<?php
/**
 * Header/Footer Builder System
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Starter Flavor Header/Footer Builder Class
 *
 * Manages custom post type for header and footer templates with Elementor support.
 *
 * @since 1.0.0
 */
class Starter_Flavor_Header_Footer_Builder {

	/**
	 * Custom Post Type slug.
	 *
	 * @var string
	 */
	const CPT_SLUG = 'sf_hf_template';

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'register_cpt' ) );
		add_action( 'init', array( $this, 'register_meta' ) );
		add_action( 'init', array( $this, 'register_widget_areas' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
		add_action( 'save_post_' . self::CPT_SLUG, array( $this, 'save_meta' ) );
		add_filter( 'manage_' . self::CPT_SLUG . '_posts_columns', array( $this, 'admin_columns' ) );
		add_action( 'manage_' . self::CPT_SLUG . '_posts_custom_column', array( $this, 'render_admin_columns' ), 10, 2 );
	}

	/**
	 * Register custom post type.
	 *
	 * @since 1.0.0
	 */
	public function register_cpt() {
		register_post_type(
			self::CPT_SLUG,
			array(
				'label'               => esc_html__( 'Header/Footer Templates', 'starter-flavor' ),
				'description'         => esc_html__( 'Custom header and footer templates with Elementor', 'starter-flavor' ),
				'supports'            => array( 'title', 'elementor' ),
				'hierarchical'        => false,
				'public'              => false,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'show_in_nav_menus'   => false,
				'show_in_admin_bar'   => true,
				'show_in_rest'        => true,
				'has_archive'         => false,
				'query_var'           => true,
				'rewrite'             => false,
				'capability_type'     => 'page',
				'menu_icon'           => 'dashicons-layout',
				'menu_position'       => 5,
			)
		);
	}

	/**
	 * Register post meta fields.
	 *
	 * @since 1.0.0
	 */
	public function register_meta() {
		// Template Type (header or footer)
		register_post_meta(
			self::CPT_SLUG,
			'sf_hf_type',
			array(
				'type'              => 'string',
				'description'       => esc_html__( 'Template type: header or footer', 'starter-flavor' ),
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => function() {
					return current_user_can( 'edit_posts' );
				},
			)
		);

		// Display Conditions
		register_post_meta(
			self::CPT_SLUG,
			'sf_hf_display_conditions',
			array(
				'type'          => 'object',
				'description'   => esc_html__( 'Display conditions for template', 'starter-flavor' ),
				'single'        => true,
				'show_in_rest'  => array(
					'schema' => array(
						'type'       => 'object',
						'properties' => array(
							'type'          => array( 'type' => 'string' ),
							'specific_pages' => array( 'type' => 'array' ),
						),
					),
				),
				'auth_callback' => function() {
					return current_user_can( 'edit_posts' );
				},
			)
		);

		// Shortcode
		register_post_meta(
			self::CPT_SLUG,
			'sf_hf_shortcode',
			array(
				'type'          => 'string',
				'description'   => esc_html__( 'Shortcode for displaying template', 'starter-flavor' ),
				'single'        => true,
				'show_in_rest'  => true,
				'auth_callback' => function() {
					return current_user_can( 'edit_posts' );
				},
			)
		);
	}

	/**
	 * Register widget areas for mega menu.
	 *
	 * @since 1.0.0
	 */
	public function register_widget_areas() {
		// Register mega menu widget areas (2-5 columns)
		for ( $i = 1; $i <= 5; $i++ ) {
			register_sidebar(
				array(
					'name'          => sprintf( esc_html__( 'Mega Menu Column %d', 'starter-flavor' ), $i ),
					'id'            => 'mega-menu-col-' . $i,
					'description'   => sprintf( esc_html__( 'Mega menu column %d widget area', 'starter-flavor' ), $i ),
					'before_widget' => '<div id="%1$s" class="mega-menu-widget %2$s">',
					'after_widget'  => '</div>',
					'before_title'  => '<h4 class="widget-title">',
					'after_title'   => '</h4>',
				)
			);
		}
	}

	/**
	 * Add meta boxes.
	 *
	 * @since 1.0.0
	 */
	public function add_meta_boxes() {
		add_meta_box(
			'sf_hf_settings',
			esc_html__( 'Template Settings', 'starter-flavor' ),
			array( $this, 'render_meta_box' ),
			self::CPT_SLUG,
			'normal',
			'high'
		);
	}

	/**
	 * Render meta box.
	 *
	 * @since 1.0.0
	 * @param WP_Post $post The post object.
	 */
	public function render_meta_box( $post ) {
		wp_nonce_field( 'sf_hf_nonce', 'sf_hf_nonce' );

		$template_type = get_post_meta( $post->ID, 'sf_hf_type', true );
		$display_conditions = get_post_meta( $post->ID, 'sf_hf_display_conditions', true );
		$shortcode = get_post_meta( $post->ID, 'sf_hf_shortcode', true );

		if ( empty( $display_conditions ) ) {
			$display_conditions = array(
				'type'           => 'all_pages',
				'specific_pages' => array(),
			);
		}

		if ( empty( $shortcode ) ) {
			$shortcode = '[sf_hf_template id="' . $post->ID . '"]';
		}

		?>
		<div class="sf-hf-meta-box">
			<p>
				<label for="sf_hf_type">
					<strong><?php esc_html_e( 'Template Type:', 'starter-flavor' ); ?></strong>
				</label>
				<select id="sf_hf_type" name="sf_hf_type" style="width: 100%;">
					<option value="header" <?php selected( $template_type, 'header' ); ?>>
						<?php esc_html_e( 'Header', 'starter-flavor' ); ?>
					</option>
					<option value="footer" <?php selected( $template_type, 'footer' ); ?>>
						<?php esc_html_e( 'Footer', 'starter-flavor' ); ?>
					</option>
				</select>
			</p>

			<p>
				<label for="sf_hf_conditions">
					<strong><?php esc_html_e( 'Display Conditions:', 'starter-flavor' ); ?></strong>
				</label>
				<select id="sf_hf_conditions" name="sf_hf_conditions" style="width: 100%;">
					<option value="all_pages" <?php selected( $display_conditions['type'], 'all_pages' ); ?>>
						<?php esc_html_e( 'All Pages', 'starter-flavor' ); ?>
					</option>
					<option value="specific_pages" <?php selected( $display_conditions['type'], 'specific_pages' ); ?>>
						<?php esc_html_e( 'Specific Pages', 'starter-flavor' ); ?>
					</option>
					<option value="404_page" <?php selected( $display_conditions['type'], '404_page' ); ?>>
						<?php esc_html_e( '404 Page', 'starter-flavor' ); ?>
					</option>
					<option value="blog_archive" <?php selected( $display_conditions['type'], 'blog_archive' ); ?>>
						<?php esc_html_e( 'Blog Archive', 'starter-flavor' ); ?>
					</option>
					<option value="single_post" <?php selected( $display_conditions['type'], 'single_post' ); ?>>
						<?php esc_html_e( 'Single Post', 'starter-flavor' ); ?>
					</option>
				</select>
			</p>

			<p id="specific-pages-container" style="display: none;">
				<label for="sf_hf_specific_pages">
					<strong><?php esc_html_e( 'Select Pages:', 'starter-flavor' ); ?></strong>
				</label>
				<select id="sf_hf_specific_pages" name="sf_hf_specific_pages[]" multiple="multiple" style="width: 100%; min-height: 120px;">
					<?php
					$pages = get_pages(
						array(
							'post_status' => 'publish',
						)
					);
					foreach ( $pages as $page ) {
						$selected = isset( $display_conditions['specific_pages'] ) && in_array( $page->ID, $display_conditions['specific_pages'], true ) ? 'selected' : '';
						?>
						<option value="<?php echo absint( $page->ID ); ?>" <?php echo esc_attr( $selected ); ?>>
							<?php echo esc_html( $page->post_title ); ?>
						</option>
						<?php
					}
					?>
				</select>
				<small><?php esc_html_e( 'Hold Ctrl/Cmd to select multiple pages', 'starter-flavor' ); ?></small>
			</p>

			<p>
				<label for="sf_hf_shortcode">
					<strong><?php esc_html_e( 'Shortcode:', 'starter-flavor' ); ?></strong>
				</label>
				<input type="text" id="sf_hf_shortcode" name="sf_hf_shortcode" value="<?php echo esc_attr( $shortcode ); ?>" readonly style="width: 100%;" />
				<small><?php esc_html_e( 'Copy and paste this shortcode to display the template anywhere', 'starter-flavor' ); ?></small>
			</p>
		</div>

		<script>
			(function() {
				const conditionsSelect = document.getElementById( 'sf_hf_conditions' );
				const specificPagesContainer = document.getElementById( 'specific-pages-container' );

				function toggleSpecificPages() {
					if ( 'specific_pages' === conditionsSelect.value ) {
						specificPagesContainer.style.display = 'block';
					} else {
						specificPagesContainer.style.display = 'none';
					}
				}

				conditionsSelect.addEventListener( 'change', toggleSpecificPages );
				toggleSpecificPages();
			})();
		</script>

		<style>
			.sf-hf-meta-box p {
				margin-bottom: 15px;
			}
			.sf-hf-meta-box label {
				display: block;
				margin-bottom: 5px;
			}
			.sf-hf-meta-box select,
			.sf-hf-meta-box input {
				padding: 8px;
				border: 1px solid #ddd;
				border-radius: 4px;
			}
			.sf-hf-meta-box small {
				display: block;
				margin-top: 5px;
				color: #666;
			}
		</style>
		<?php
	}

	/**
	 * Save meta box data.
	 *
	 * @since 1.0.0
	 * @param int $post_id The post ID.
	 */
	public function save_meta( $post_id ) {
		if ( ! isset( $_POST['sf_hf_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['sf_hf_nonce'] ) ), 'sf_hf_nonce' ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// Save template type
		if ( isset( $_POST['sf_hf_type'] ) ) {
			update_post_meta( $post_id, 'sf_hf_type', sanitize_text_field( wp_unslash( $_POST['sf_hf_type'] ) ) );
		}

		// Save display conditions
		$conditions = array(
			'type'           => 'all_pages',
			'specific_pages' => array(),
		);

		if ( isset( $_POST['sf_hf_conditions'] ) ) {
			$conditions['type'] = sanitize_text_field( wp_unslash( $_POST['sf_hf_conditions'] ) );
		}

		if ( isset( $_POST['sf_hf_specific_pages'] ) ) {
			$conditions['specific_pages'] = array_map( 'absint', (array) wp_unslash( $_POST['sf_hf_specific_pages'] ) );
		}

		update_post_meta( $post_id, 'sf_hf_display_conditions', $conditions );

		// Generate and save shortcode
		$shortcode = '[sf_hf_template id="' . $post_id . '"]';
		update_post_meta( $post_id, 'sf_hf_shortcode', $shortcode );
	}

	/**
	 * Add admin columns.
	 *
	 * @since 1.0.0
	 * @param array $columns The admin columns.
	 * @return array The modified columns.
	 */
	public function admin_columns( $columns ) {
		$new_columns = array();

		foreach ( $columns as $key => $value ) {
			if ( 'date' === $key ) {
				$new_columns['sf_hf_type'] = esc_html__( 'Type', 'starter-flavor' );
				$new_columns['sf_hf_conditions'] = esc_html__( 'Display Conditions', 'starter-flavor' );
				$new_columns['sf_hf_shortcode'] = esc_html__( 'Shortcode', 'starter-flavor' );
			}

			$new_columns[ $key ] = $value;
		}

		return $new_columns;
	}

	/**
	 * Render admin columns.
	 *
	 * @since 1.0.0
	 * @param string $column The column name.
	 * @param int    $post_id The post ID.
	 */
	public function render_admin_columns( $column, $post_id ) {
		switch ( $column ) {
			case 'sf_hf_type':
				$type = get_post_meta( $post_id, 'sf_hf_type', true );
				echo $type ? esc_html( ucfirst( $type ) ) : '—';
				break;

			case 'sf_hf_conditions':
				$conditions = get_post_meta( $post_id, 'sf_hf_display_conditions', true );
				if ( $conditions ) {
					echo esc_html( ucwords( str_replace( '_', ' ', $conditions['type'] ) ) );
				} else {
					echo '—';
				}
				break;

			case 'sf_hf_shortcode':
				$shortcode = get_post_meta( $post_id, 'sf_hf_shortcode', true );
				if ( $shortcode ) {
					echo '<code style="background: #f5f5f5; padding: 3px 6px; border-radius: 3px;">' . esc_html( $shortcode ) . '</code>';
				}
				break;
		}
	}
}

// Initialize the class
new Starter_Flavor_Header_Footer_Builder();

/**
 * Get header template based on conditions.
 *
 * @since 1.0.0
 * @param string $location Optional location identifier.
 * @return int|false The template post ID or false if not found.
 */
function starter_flavor_get_header_template( $location = '' ) {
	$templates = get_posts(
		array(
			'post_type'      => 'sf_hf_template',
			'posts_per_page' => -1,
			'post_status'    => 'publish',
			'meta_key'       => 'sf_hf_type',
			'meta_value'     => 'header',
		)
	);

	if ( empty( $templates ) ) {
		return false;
	}

	foreach ( $templates as $template ) {
		if ( starter_flavor_check_display_conditions( $template->ID ) ) {
			return $template->ID;
		}
	}

	return false;
}

/**
 * Get footer template based on conditions.
 *
 * @since 1.0.0
 * @param string $location Optional location identifier.
 * @return int|false The template post ID or false if not found.
 */
function starter_flavor_get_footer_template( $location = '' ) {
	$templates = get_posts(
		array(
			'post_type'      => 'sf_hf_template',
			'posts_per_page' => -1,
			'post_status'    => 'publish',
			'meta_key'       => 'sf_hf_type',
			'meta_value'     => 'footer',
		)
	);

	if ( empty( $templates ) ) {
		return false;
	}

	foreach ( $templates as $template ) {
		if ( starter_flavor_check_display_conditions( $template->ID ) ) {
			return $template->ID;
		}
	}

	return false;
}

/**
 * Check if template should be displayed on current page.
 *
 * @since 1.0.0
 * @param int $template_id The template post ID.
 * @return bool True if template should be displayed.
 */
function starter_flavor_check_display_conditions( $template_id ) {
	$conditions = get_post_meta( $template_id, 'sf_hf_display_conditions', true );

	if ( empty( $conditions ) ) {
		return true;
	}

	$condition_type = isset( $conditions['type'] ) ? $conditions['type'] : 'all_pages';

	switch ( $condition_type ) {
		case 'all_pages':
			return true;

		case 'specific_pages':
			$specific_pages = isset( $conditions['specific_pages'] ) ? $conditions['specific_pages'] : array();
			return is_page( $specific_pages );

		case '404_page':
			return is_404();

		case 'blog_archive':
			return is_archive();

		case 'single_post':
			return is_singular( 'post' );

		default:
			return false;
	}
}

/**
 * Display header template via shortcode.
 *
 * @since 1.0.0
 * @param array $atts Shortcode attributes.
 * @return string The template output.
 */
function starter_flavor_hf_template_shortcode( $atts ) {
	$atts = shortcode_atts(
		array(
			'id' => 0,
		),
		$atts,
		'sf_hf_template'
	);

	$template_id = absint( $atts['id'] );

	if ( ! $template_id ) {
		return '';
	}

	$template = get_post( $template_id );

	if ( ! $template || 'sf_hf_template' !== $template->post_type ) {
		return '';
	}

	// Check if Elementor is active and has content
	if ( class_exists( '\Elementor\Plugin' ) ) {
		$elementor_data = get_post_meta( $template_id, '_elementor_data', true );
		if ( ! empty( $elementor_data ) ) {
			return \Elementor\Plugin::instance()->frontend->get_builder_content( $template_id );
		}
	}

	// Fallback to post content if no Elementor
	return apply_filters( 'the_content', $template->post_content );
}
add_shortcode( 'sf_hf_template', 'starter_flavor_hf_template_shortcode' );
