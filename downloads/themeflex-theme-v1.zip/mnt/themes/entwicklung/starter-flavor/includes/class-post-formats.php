<?php
/**
 * Post Formats Class
 *
 * Implements rich post format support across the theme.
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Starter_Flavor_Post_Formats class
 */
class Starter_Flavor_Post_Formats {

	/**
	 * Instance variable
	 *
	 * @var Starter_Flavor_Post_Formats
	 */
	private static $instance = null;

	/**
	 * Get instance
	 *
	 * @return Starter_Flavor_Post_Formats
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'after_setup_theme', array( $this, 'register_post_formats' ) );
		add_filter( 'theme_mod_starter_flavor_post_format_icons', array( $this, 'get_format_icons' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/**
	 * Register post format support
	 */
	public function register_post_formats() {
		// Post formats are already registered in functions.php
		// This ensures they're available
	}

	/**
	 * Get format icons
	 *
	 * @return array
	 */
	public function get_format_icons() {
		return array(
			'aside'   => 'dashicons-sticky',
			'gallery' => 'dashicons-images-alt',
			'link'    => 'dashicons-admin-links',
			'image'   => 'dashicons-format-image',
			'quote'   => 'dashicons-format-quote',
			'status'  => 'dashicons-format-status',
			'video'   => 'dashicons-format-video',
			'audio'   => 'dashicons-format-audio',
			'chat'    => 'dashicons-format-chat',
		);
	}

	/**
	 * Get format icon class
	 *
	 * @param string $format The post format.
	 * @return string
	 */
	public function get_format_icon( $format = '' ) {
		if ( empty( $format ) ) {
			$format = get_post_format();
		}

		if ( empty( $format ) ) {
			$format = 'standard';
		}

		$icons = $this->get_format_icons();

		return isset( $icons[ $format ] ) ? $icons[ $format ] : '';
	}

	/**
	 * Enqueue assets
	 */
	public function enqueue_assets() {
		wp_enqueue_script(
			'starter-flavor-post-formats',
			get_template_directory_uri() . '/assets/js/post-formats.js',
			array(),
			STARTER_FLAVOR_VERSION,
			true
		);

		wp_enqueue_style(
			'starter-flavor-post-formats',
			get_template_directory_uri() . '/assets/css/post-formats.css',
			array(),
			STARTER_FLAVOR_VERSION
		);
	}

	/**
	 * Display post format specific content
	 *
	 * @param array $args Optional template part arguments.
	 */
	public function display_format_content( $args = array() ) {
		$format = get_post_format();

		if ( empty( $format ) ) {
			$format = 'standard';
		}

		$template = 'template-parts/format/content-' . sanitize_file_name( $format );

		if ( 'standard' !== $format && locate_template( $template . '.php' ) ) {
			get_template_part( $template, null, $args );
		}
	}

	/**
	 * Get gallery posts meta
	 *
	 * @return array
	 */
	public function get_gallery_ids() {
		$gallery_meta = get_post_meta( get_the_ID(), '_starter_flavor_gallery', true );

		if ( empty( $gallery_meta ) ) {
			// Fall back to shortcode
			$gallery_ids = array();
			if ( has_shortcode( get_the_content(), 'gallery' ) ) {
				preg_match( '/\[gallery.*ids=.(.*).\]/', get_the_content(), $matches );
				if ( ! empty( $matches[1] ) ) {
					$gallery_ids = explode( ',', $matches[1] );
				}
			}
			return $gallery_ids;
		}

		return is_array( $gallery_meta ) ? $gallery_meta : explode( ',', $gallery_meta );
	}

	/**
	 * Get video URL
	 *
	 * @return string
	 */
	public function get_video_url() {
		$video_url = get_post_meta( get_the_ID(), '_starter_flavor_video_url', true );

		if ( empty( $video_url ) ) {
			// Try to extract from content
			if ( has_shortcode( get_the_content(), 'video' ) || has_shortcode( get_the_content(), 'embed' ) ) {
				$content = get_the_content();
				if ( preg_match( '/(?:https?:)?\/\/(?:www\.)?(?:youtube|vimeo)\.com\/[^\s]+/', $content, $matches ) ) {
					$video_url = $matches[0];
				}
			}
		}

		return $video_url;
	}

	/**
	 * Get audio URL
	 *
	 * @return string
	 */
	public function get_audio_url() {
		$audio_url = get_post_meta( get_the_ID(), '_starter_flavor_audio_url', true );

		if ( empty( $audio_url ) ) {
			// Try to extract from content
			if ( has_shortcode( get_the_content(), 'audio' ) ) {
				$content = get_the_content();
				if ( preg_match( '/(?:https?:)?\/\/[^\s]+\.(?:mp3|wav|ogg|m4a)/', $content, $matches ) ) {
					$audio_url = $matches[0];
				}
			}
		}

		return $audio_url;
	}

	/**
	 * Get quote text
	 *
	 * @return string
	 */
	public function get_quote_text() {
		return get_post_meta( get_the_ID(), '_starter_flavor_quote_text', true );
	}

	/**
	 * Get quote author
	 *
	 * @return string
	 */
	public function get_quote_author() {
		return get_post_meta( get_the_ID(), '_starter_flavor_quote_author', true );
	}

	/**
	 * Get link URL
	 *
	 * @return string
	 */
	public function get_link_url() {
		$link_url = get_post_meta( get_the_ID(), '_starter_flavor_link_url', true );

		if ( empty( $link_url ) ) {
			// Extract first link from content
			preg_match( '/href=[\'"]?([^\'" >]+)/', get_the_content(), $matches );
			if ( ! empty( $matches[1] ) ) {
				$link_url = $matches[1];
			}
		}

		return $link_url;
	}

	/**
	 * Get link title
	 *
	 * @return string
	 */
	public function get_link_title() {
		return get_post_meta( get_the_ID(), '_starter_flavor_link_title', true );
	}

	/**
	 * Get favicon for URL
	 *
	 * @param string $url The URL.
	 * @return string
	 */
	public function get_favicon( $url ) {
		if ( empty( $url ) ) {
			return '';
		}

		$domain = wp_parse_url( $url, PHP_URL_HOST );
		if ( empty( $domain ) ) {
			return '';
		}

		return 'https://www.google.com/s2/favicons?domain=' . urlencode( $domain ) . '&sz=32';
	}
}

// Initialize
if ( ! function_exists( 'starter_flavor_post_formats' ) ) {
	/**
	 * Get post formats instance
	 *
	 * @return Starter_Flavor_Post_Formats
	 */
	function starter_flavor_post_formats() {
		return Starter_Flavor_Post_Formats::get_instance();
	}
}

starter_flavor_post_formats();
