<?php
/**
 * Related Posts Class
 *
 * Provides intelligent related posts functionality with scoring algorithm.
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Starter_Flavor_Related_Posts class
 */
class Starter_Flavor_Related_Posts {

	/**
	 * Instance variable
	 *
	 * @var Starter_Flavor_Related_Posts
	 */
	private static $instance = null;

	/**
	 * Get instance
	 *
	 * @return Starter_Flavor_Related_Posts
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'customize_register', array( $this, 'register_customizer_settings' ) );
		add_filter( 'starter_flavor_related_posts_args', array( $this, 'filter_related_posts_args' ) );
	}

	/**
	 * Register customizer settings for related posts
	 *
	 * @param WP_Customize_Manager $wp_customize The customizer object.
	 */
	public function register_customizer_settings( $wp_customize ) {
		// Related Posts Panel
		$wp_customize->add_panel(
			'starter_flavor_related_posts',
			array(
				'title'       => esc_html__( 'Related Posts', 'starter-flavor' ),
				'description' => esc_html__( 'Configure related posts display', 'starter-flavor' ),
				'priority'    => 80,
			)
		);

		// Enable/Disable
		$wp_customize->add_setting(
			'starter_flavor_related_posts_enabled',
			array(
				'default'           => true,
				'sanitize_callback' => 'rest_sanitize_boolean',
				'transport'         => 'refresh',
			)
		);

		$wp_customize->add_control(
			'starter_flavor_related_posts_enabled',
			array(
				'type'            => 'checkbox',
				'section'         => 'starter_flavor_related_posts',
				'label'           => esc_html__( 'Enable Related Posts', 'starter-flavor' ),
				'priority'        => 10,
			)
		);

		// Number of posts
		$wp_customize->add_setting(
			'starter_flavor_related_posts_count',
			array(
				'default'           => 3,
				'sanitize_callback' => 'absint',
				'transport'         => 'refresh',
			)
		);

		$wp_customize->add_control(
			'starter_flavor_related_posts_count',
			array(
				'type'            => 'number',
				'section'         => 'starter_flavor_related_posts',
				'label'           => esc_html__( 'Number of Related Posts', 'starter-flavor' ),
				'description'     => esc_html__( 'Between 2-6 posts', 'starter-flavor' ),
				'input_attrs'     => array(
					'min'  => 2,
					'max'  => 6,
					'step' => 1,
				),
				'priority'        => 20,
			)
		);

		// Columns
		$wp_customize->add_setting(
			'starter_flavor_related_posts_columns',
			array(
				'default'           => 3,
				'sanitize_callback' => 'absint',
				'transport'         => 'refresh',
			)
		);

		$wp_customize->add_control(
			'starter_flavor_related_posts_columns',
			array(
				'type'            => 'select',
				'section'         => 'starter_flavor_related_posts',
				'label'           => esc_html__( 'Columns', 'starter-flavor' ),
				'choices'         => array(
					2 => esc_html__( '2 Columns', 'starter-flavor' ),
					3 => esc_html__( '3 Columns', 'starter-flavor' ),
					4 => esc_html__( '4 Columns', 'starter-flavor' ),
				),
				'priority'        => 30,
			)
		);

		// Display style
		$wp_customize->add_setting(
			'starter_flavor_related_posts_style',
			array(
				'default'           => 'grid',
				'sanitize_callback' => array( $this, 'sanitize_style' ),
				'transport'         => 'refresh',
			)
		);

		$wp_customize->add_control(
			'starter_flavor_related_posts_style',
			array(
				'type'            => 'select',
				'section'         => 'starter_flavor_related_posts',
				'label'           => esc_html__( 'Display Style', 'starter-flavor' ),
				'choices'         => array(
					'grid'       => esc_html__( 'Grid Cards', 'starter-flavor' ),
					'horizontal' => esc_html__( 'Horizontal List', 'starter-flavor' ),
				),
				'priority'        => 40,
			)
		);

		// Title text
		$wp_customize->add_setting(
			'starter_flavor_related_posts_title',
			array(
				'default'           => esc_html__( 'Related Posts', 'starter-flavor' ),
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);

		$wp_customize->add_control(
			'starter_flavor_related_posts_title',
			array(
				'type'            => 'text',
				'section'         => 'starter_flavor_related_posts',
				'label'           => esc_html__( 'Section Title', 'starter-flavor' ),
				'priority'        => 50,
			)
		);
	}

	/**
	 * Sanitize style option
	 *
	 * @param string $value The value to sanitize.
	 * @return string
	 */
	public function sanitize_style( $value ) {
		$allowed = array( 'grid', 'horizontal' );
		return in_array( $value, $allowed, true ) ? $value : 'grid';
	}

	/**
	 * Filter related posts arguments with intelligent scoring
	 *
	 * @param array $args The related posts query arguments.
	 * @return array
	 */
	public function filter_related_posts_args( $args ) {
		// Check if enabled
		if ( ! get_theme_mod( 'starter_flavor_related_posts_enabled', true ) ) {
			return array( 'posts_per_page' => 0 );
		}

		$post_id = get_the_ID();
		$count = get_theme_mod( 'starter_flavor_related_posts_count', 3 );

		// Create cache key
		$cache_key = 'starter_flavor_related_posts_' . $post_id;
		$cached_posts = wp_cache_get( $cache_key, 'starter-flavor' );

		if ( false !== $cached_posts ) {
			// Use cached results
			return array(
				'post__in'       => $cached_posts,
				'posts_per_page' => $count,
				'orderby'        => 'post__in',
			);
		}

		// Get related posts using scoring algorithm
		$related_posts = $this->get_related_posts_by_score( $post_id, $count );

		if ( empty( $related_posts ) ) {
			// Fallback to recent posts
			return array(
				'posts_per_page' => $count,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'post__not_in'   => array( $post_id ),
			);
		}

		// Cache the results for 24 hours
		wp_cache_set( $cache_key, $related_posts, 'starter-flavor', DAY_IN_SECONDS );

		return array(
			'post__in'       => $related_posts,
			'posts_per_page' => $count,
			'orderby'        => 'post__in',
		);
	}

	/**
	 * Get related posts by score
	 *
	 * Scoring algorithm:
	 * - Same category: 3 points per post
	 * - Same tag: 2 points per post
	 * - Same author: 1 point per post
	 *
	 * @param int $post_id The current post ID.
	 * @param int $limit The maximum number of posts to return.
	 * @return array Array of post IDs
	 */
	private function get_related_posts_by_score( $post_id, $limit = 3 ) {
		global $wpdb;

		$categories = wp_get_post_categories( $post_id );
		$tags = wp_get_post_tags( $post_id, array( 'fields' => 'ids' ) );
		$author_id = get_post_field( 'post_author', $post_id );

		$scores = array();

		// Score by category (3x weight)
		if ( ! empty( $categories ) ) {
			$cat_posts = get_posts( array(
				'category__in'  => $categories,
				'post__not_in'  => array( $post_id ),
				'numberposts'   => -1,
				'fields'        => 'ids',
				'post_type'     => 'post',
				'post_status'   => 'publish',
			) );

			foreach ( $cat_posts as $cat_post_id ) {
				$scores[ $cat_post_id ] = isset( $scores[ $cat_post_id ] ) ? $scores[ $cat_post_id ] : 0;
				$scores[ $cat_post_id ] += 3;
			}
		}

		// Score by tag (2x weight)
		if ( ! empty( $tags ) ) {
			$tag_posts = get_posts( array(
				'tag__in'       => $tags,
				'post__not_in'  => array( $post_id ),
				'numberposts'   => -1,
				'fields'        => 'ids',
				'post_type'     => 'post',
				'post_status'   => 'publish',
			) );

			foreach ( $tag_posts as $tag_post_id ) {
				$scores[ $tag_post_id ] = isset( $scores[ $tag_post_id ] ) ? $scores[ $tag_post_id ] : 0;
				$scores[ $tag_post_id ] += 2;
			}
		}

		// Score by author (1x weight)
		if ( ! empty( $author_id ) ) {
			$author_posts = get_posts( array(
				'author'        => $author_id,
				'post__not_in'  => array( $post_id ),
				'numberposts'   => -1,
				'fields'        => 'ids',
				'post_type'     => 'post',
				'post_status'   => 'publish',
			) );

			foreach ( $author_posts as $author_post_id ) {
				$scores[ $author_post_id ] = isset( $scores[ $author_post_id ] ) ? $scores[ $author_post_id ] : 0;
				$scores[ $author_post_id ] += 1;
			}
		}

		// Sort by score and get top results
		arsort( $scores );
		$related_posts = array_slice( array_keys( $scores ), 0, $limit );

		return $related_posts;
	}

	/**
	 * Get related posts settings
	 *
	 * @return array
	 */
	public function get_settings() {
		return array(
			'enabled'  => get_theme_mod( 'starter_flavor_related_posts_enabled', true ),
			'count'    => get_theme_mod( 'starter_flavor_related_posts_count', 3 ),
			'columns'  => get_theme_mod( 'starter_flavor_related_posts_columns', 3 ),
			'style'    => get_theme_mod( 'starter_flavor_related_posts_style', 'grid' ),
			'title'    => get_theme_mod( 'starter_flavor_related_posts_title', esc_html__( 'Related Posts', 'starter-flavor' ) ),
		);
	}

	/**
	 * Display related posts
	 */
	public function display() {
		$settings = $this->get_settings();

		if ( ! $settings['enabled'] ) {
			return;
		}

		get_template_part( 'template-parts/related-posts', null, $settings );
	}
}

// Initialize
if ( ! function_exists( 'starter_flavor_related_posts' ) ) {
	/**
	 * Get related posts instance
	 *
	 * @return Starter_Flavor_Related_Posts
	 */
	function starter_flavor_related_posts() {
		return Starter_Flavor_Related_Posts::get_instance();
	}
}

starter_flavor_related_posts();
