<?php
/**
 * Shortcodes Library
 * Theme-provided shortcodes for use in content, widgets, and page builders.
 *
 * Available shortcodes:
 * [sf_button], [sf_alert], [sf_badge], [sf_price_tag],
 * [sf_columns], [sf_col], [sf_divider], [sf_highlight],
 * [sf_stats_row], [sf_icon_feature], [sf_social_follow],
 * [sf_countdown], [sf_progress]
 *
 * @package Starter_Flavor
 * @since   1.1.0
 */
if (!defined('ABSPATH')) exit;

class Starter_Flavor_Shortcodes {

    private static ?self $instance = null;

    public static function instance(): self {
        if (is_null(self::$instance)) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        $shortcodes = [
            'sf_button'       => 'button',
            'sf_alert'        => 'alert',
            'sf_badge'        => 'badge',
            'sf_price_tag'    => 'price_tag',
            'sf_columns'      => 'columns',
            'sf_col'          => 'col',
            'sf_divider'      => 'divider',
            'sf_highlight'    => 'highlight',
            'sf_stats_row'    => 'stats_row',
            'sf_icon_feature' => 'icon_feature',
            'sf_social_follow'=> 'social_follow',
            'sf_progress'     => 'progress',
            'sf_notice'       => 'notice',
        ];
        foreach ($shortcodes as $tag => $method) {
            add_shortcode($tag, [$this, $method]);
        }
    }

    public function button(array $atts, string $content = ''): string {
        $a = shortcode_atts(['url'=>'#','style'=>'primary','size'=>'md','target'=>'_self','icon'=>'','full'=>'no'], $atts, 'sf_button');
        $pad = ['sm'=>'8px 16px','md'=>'12px 24px','lg'=>'16px 32px'][$a['size']] ?? '12px 24px';
        $fs  = ['sm'=>'13px','md'=>'15px','lg'=>'16px'][$a['size']] ?? '15px';
        $css = 'primary' === $a['style']
            ? "background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;"
            : ('ghost' === $a['style']
                ? "background:transparent;border:2px solid var(--sf-color-primary,#FF5E2E);color:var(--sf-color-primary,#FF5E2E);"
                : "background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);color:var(--sf-title,#1e293b);");
        $ext = '_blank' === $a['target'] ? 'target="_blank" rel="noopener noreferrer"' : '';
        $w   = 'yes' === $a['full'] ? 'width:100%;display:block;' : 'display:inline-flex;';
        $icon_html = $a['icon'] ? '<i class="'.esc_attr($a['icon']).'" aria-hidden="true" style="margin-right:6px;"></i>' : '';
        return '<a href="'.esc_url($a['url']).'" '.$ext.' style="'.$css.$w.'align-items:center;justify-content:center;gap:6px;padding:'.$pad.';border-radius:var(--sf-border-radius-button,10px);font-weight:700;font-size:'.$fs.';text-decoration:none;font-family:inherit;">'.$icon_html.wp_kses_post($content).'</a>';
    }

    public function alert(array $atts, string $content = ''): string {
        $a = shortcode_atts(['type'=>'info','title'=>'','dismissible'=>'no'], $atts, 'sf_alert');
        $types = [
            'info'    => ['#eff6ff','#3b82f6','#1e40af','ℹ️'],
            'success' => ['#ecfdf5','#10b981','#065f46','✅'],
            'warning' => ['#fffbeb','#f59e0b','#92400e','⚠️'],
            'error'   => ['#fef2f2','#ef4444','#991b1b','❌'],
        ];
        [$bg, $border, $text, $icon] = $types[$a['type']] ?? $types['info'];
        $uid = 'sf-alert-'.uniqid();
        $dis = 'yes' === $a['dismissible'] ? '<button onclick="document.getElementById(\''.esc_js($uid).'\').remove()" style="background:none;border:none;cursor:pointer;font-size:18px;color:'.$text.';opacity:.6;padding:0;line-height:1;margin-left:auto;">&times;</button>' : '';
        return '<div id="'.esc_attr($uid).'" style="background:'.$bg.';border:1px solid '.$border.';border-left:4px solid '.$border.';border-radius:8px;padding:14px 18px;display:flex;align-items:flex-start;gap:10px;margin-bottom:16px;">
            <span style="flex-shrink:0;font-size:16px;">'.$icon.'</span>
            <div style="flex:1;color:'.$text.';font-size:14px;line-height:1.6;">'.($a['title']?'<strong style="display:block;margin-bottom:3px;">'.esc_html($a['title']).'</strong>':'').wp_kses_post($content).'</div>'.$dis.'</div>';
    }

    public function badge(array $atts, string $content = ''): string {
        $a = shortcode_atts(['color'=>'primary','size'=>'sm','rounded'=>'yes'], $atts, 'sf_badge');
        $colors = ['primary'=>'rgba(255,94,46,.1);color:var(--sf-color-primary,#FF5E2E);','green'=>'rgba(16,185,129,.1);color:#10b981;','blue'=>'rgba(59,130,246,.1);color:#3b82f6;','purple'=>'rgba(124,58,237,.1);color:#7c3aed;','red'=>'rgba(239,68,68,.1);color:#ef4444;','gray'=>'rgba(0,0,0,.08);color:#64748b;'];
        $bg_color = $colors[$a['color']] ?? $colors['primary'];
        $pad  = 'lg' === $a['size'] ? '6px 14px' : '3px 10px';
        $fs   = 'lg' === $a['size'] ? '13px' : '11px';
        $brad = 'yes' === $a['rounded'] ? '20px' : '4px';
        return '<span style="display:inline-block;background:'.$bg_color.';padding:'.$pad.';border-radius:'.$brad.';font-size:'.$fs.';font-weight:700;letter-spacing:.3px;text-transform:uppercase;">'.wp_kses_post($content).'</span>';
    }

    public function price_tag(array $atts, string $content = ''): string {
        $a = shortcode_atts(['currency'=>'$','period'=>'/mo','strike'=>'','size'=>'md'], $atts, 'sf_price_tag');
        $fs = ['sm'=>'1.5rem','md'=>'2.5rem','lg'=>'3.5rem'][$a['size']] ?? '2.5rem';
        $out = '<span style="font-family:\'Inter Tight\',sans-serif;font-weight:900;line-height:1;">';
        $out .= '<span style="font-size:1rem;vertical-align:super;color:var(--sf-color-primary,#FF5E2E);">'.esc_html($a['currency']).'</span>';
        $out .= '<span style="font-size:'.$fs.';color:var(--sf-color-primary,#FF5E2E);">'.wp_kses_post($content).'</span>';
        if ($a['period']) $out .= '<span style="font-size:.9rem;font-weight:400;color:var(--sf-meta,#94a3b8);margin-left:3px;">'.esc_html($a['period']).'</span>';
        if ($a['strike']) $out .= ' <s style="font-size:1rem;font-weight:400;color:var(--sf-meta,#94a3b8);">'.esc_html($a['currency'].$a['strike']).'</s>';
        $out .= '</span>';
        return $out;
    }

    public function columns(array $atts, string $content = ''): string {
        $a = shortcode_atts(['cols'=>'2','gap'=>'32'], $atts, 'sf_columns');
        return '<div style="display:grid;grid-template-columns:repeat('.esc_attr($a['cols']).',1fr);gap:'.esc_attr($a['gap']).'px;flex-wrap:wrap;" class="sf-sc-columns">'.do_shortcode($content).'</div><style>@media(max-width:640px){.sf-sc-columns{grid-template-columns:1fr!important}}</style>';
    }

    public function col(array $atts, string $content = ''): string {
        $a = shortcode_atts(['span'=>'1'], $atts, 'sf_col');
        return '<div style="grid-column:span '.esc_attr($a['span']).';">'.do_shortcode($content).'</div>';
    }

    public function divider(array $atts): string {
        $a = shortcode_atts(['style'=>'line','color'=>'','spacing'=>'32'], $atts, 'sf_divider');
        $color = $a['color'] ?: 'var(--sf-border,#e5e7eb)';
        $s = $a['spacing'].'px';
        if ('dots' === $a['style']) return '<div style="text-align:center;margin:'.$s.' 0;color:'.$color.';letter-spacing:8px;">• • •</div>';
        if ('gradient' === $a['style']) return '<hr style="border:none;height:2px;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#00D4FF));border-radius:2px;margin:'.$s.' 0;" />';
        return '<hr style="border:none;border-top:1px solid '.$color.';margin:'.$s.' 0;" />';
    }

    public function highlight(array $atts, string $content = ''): string {
        $a = shortcode_atts(['color'=>''], $atts, 'sf_highlight');
        $color = $a['color'] ?: 'var(--sf-color-primary,#FF5E2E)';
        return '<mark style="background:color-mix(in srgb,'.$color.' 15%,transparent);color:'.$color.';padding:0 4px;border-radius:3px;">'.wp_kses_post($content).'</mark>';
    }

    public function stats_row(array $atts, string $content = ''): string {
        $a = shortcode_atts(['cols'=>'3'], $atts, 'sf_stats_row');
        return '<div style="display:grid;grid-template-columns:repeat('.esc_attr($a['cols']).',1fr);gap:24px;text-align:center;padding:32px;background:var(--sf-bg-2,#f8fafc);border-radius:16px;border:1px solid var(--sf-border,#e5e7eb);">'.do_shortcode($content).'</div>';
    }

    public function icon_feature(array $atts, string $content = ''): string {
        $a = shortcode_atts(['icon'=>'✓','title'=>'','color'=>''], $atts, 'sf_icon_feature');
        $color = $a['color'] ?: 'var(--sf-color-primary,#FF5E2E)';
        return '<div style="display:flex;align-items:flex-start;gap:14px;padding:16px;background:var(--sf-bg-2,#f8fafc);border-radius:12px;border:1px solid var(--sf-border,#e5e7eb);">
            <div style="width:36px;height:36px;border-radius:8px;background:color-mix(in srgb,'.$color.' 12%,transparent);display:flex;align-items:center;justify-content:center;font-size:18px;color:'.$color.';flex-shrink:0;">'.esc_html($a['icon']).'</div>
            <div><strong style="display:block;font-size:14px;color:var(--sf-title,#1e293b);margin-bottom:4px;">'.esc_html($a['title']).'</strong><span style="font-size:13px;color:var(--sf-text,#64748b);line-height:1.6;">'.wp_kses_post($content).'</span></div>
        </div>';
    }

    public function social_follow(array $atts): string {
        $a = shortcode_atts(['style'=>'icons','size'=>'md'], $atts, 'sf_social_follow');
        $networks = [
            'facebook'  => ['Facebook',   'https://facebook.com',  '#1877F2', '📘'],
            'twitter'   => ['X (Twitter)','https://twitter.com',   '#000',    '𝕏'],
            'instagram' => ['Instagram',  'https://instagram.com', '#E4405F', '📸'],
            'linkedin'  => ['LinkedIn',   'https://linkedin.com',  '#0A66C2', '💼'],
            'youtube'   => ['YouTube',    'https://youtube.com',   '#FF0000', '▶️'],
        ];
        $out = '<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">';
        foreach ($networks as $key => [$name, $default_url, $color, $icon]) {
            $url = get_theme_mod("sf_social_{$key}", '');
            if (!$url) continue;
            if ('icons' === $a['style']) {
                $out .= '<a href="'.esc_url($url).'" target="_blank" rel="noopener noreferrer" title="'.esc_attr($name).'" style="width:36px;height:36px;border-radius:50%;background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);display:flex;align-items:center;justify-content:center;font-size:16px;text-decoration:none;transition:all .2s;" onmouseover="this.style.background=\''.esc_js($color).'\';this.style.border=\'none\'" onmouseout="this.style.background=\'var(--sf-bg-2,#f8fafc)\';this.style.border=\'1px solid var(--sf-border,#e5e7eb)\'">'.$icon.'</a>';
            } else {
                $out .= '<a href="'.esc_url($url).'" target="_blank" rel="noopener noreferrer" style="padding:8px 14px;border-radius:8px;background:'.esc_attr($color).';color:#fff;font-size:12px;font-weight:700;text-decoration:none;display:flex;align-items:center;gap:6px;">'.$icon.' '.esc_html($name).'</a>';
            }
        }
        $out .= '</div>';
        return $out;
    }

    public function progress(array $atts, string $content = ''): string {
        $a = shortcode_atts(['value'=>'50','label'=>'','color'=>''], $atts, 'sf_progress');
        $pct = min(100, max(0, (int)$a['value']));
        $color = $a['color'] ?: 'var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C))';
        return ($a['label'] ? '<div style="display:flex;justify-content:space-between;margin-bottom:6px;font-size:13px;font-weight:600;color:var(--sf-title,#1e293b);"><span>'.esc_html($a['label']).'</span><span>'.esc_html($pct).'%</span></div>' : '').
            '<div style="height:8px;background:var(--sf-border,#e5e7eb);border-radius:4px;overflow:hidden;margin-bottom:12px;"><div style="height:100%;width:'.esc_attr($pct).'%;background:'.$color.';border-radius:4px;transition:width 1s ease;"></div></div>';
    }

    public function notice(array $atts, string $content = ''): string {
        $a = shortcode_atts(['icon'=>'💡','bg'=>'rgba(255,94,46,.06)','border'=>'rgba(255,94,46,.2)'], $atts, 'sf_notice');
        return '<div style="background:'.esc_attr($a['bg']).';border:1px solid '.esc_attr($a['border']).';border-radius:10px;padding:16px 20px;display:flex;gap:12px;margin:20px 0;">
            <span style="font-size:18px;flex-shrink:0;padding-top:1px;">'.esc_html($a['icon']).'</span>
            <div style="font-size:14px;line-height:1.7;color:var(--sf-text,#64748b);">'.wp_kses_post(do_shortcode($content)).'</div>
        </div>';
    }
}

Starter_Flavor_Shortcodes::instance();

// ── Dynamic Shortcodes ──────────────────────────────────────────────────────

// Register dynamic shortcodes in constructor — added as static extension
add_action('init', function() {
    // [sf_if] — conditional content
    add_shortcode('sf_if', function(array $atts, string $content = ''): string {
        $a = shortcode_atts([
            'logged_in'  => '',    // yes|no
            'role'       => '',    // editor,author,subscriber…
            'user_id'    => '',
            'mobile'     => '',    // yes|no
            'page'       => '',    // page slug
        ], $atts, 'sf_if');

        $show = true;

        if ($a['logged_in'] !== '') {
            $want  = 'yes' === $a['logged_in'];
            $show  = $show && ($want === is_user_logged_in());
        }
        if ($a['role'] && is_user_logged_in()) {
            $user  = wp_get_current_user();
            $show  = $show && in_array($a['role'], (array)$user->roles, true);
        }
        if ($a['user_id'] && is_user_logged_in()) {
            $show  = $show && ((int)$a['user_id'] === get_current_user_id());
        }
        if ($a['mobile'] !== '') {
            $is_mobile = wp_is_mobile();
            $show      = $show && ('yes' === $a['mobile']) === $is_mobile;
        }
        if ($a['page'] !== '') {
            $show = $show && is_page($a['page']);
        }

        return $show ? do_shortcode($content) : '';
    });

    // [sf_user_name] — current user display name
    add_shortcode('sf_user_name', function(array $atts): string {
        $a = shortcode_atts(['fallback'=>'Guest'], $atts, 'sf_user_name');
        return is_user_logged_in() ? esc_html(wp_get_current_user()->display_name) : esc_html($a['fallback']);
    });

    // [sf_current_year]
    add_shortcode('sf_current_year', function(): string {
        return date('Y');
    });

    // [sf_site_name]
    add_shortcode('sf_site_name', function(): string {
        return esc_html(get_bloginfo('name'));
    });

    // [sf_site_url]
    add_shortcode('sf_site_url', function(): string {
        return esc_url(home_url('/'));
    });

    // [sf_post_count type="post"] — dynamic count
    add_shortcode('sf_post_count', function(array $atts): string {
        $a = shortcode_atts(['type'=>'post','status'=>'publish'], $atts, 'sf_post_count');
        $count = wp_count_posts(sanitize_text_field($a['type']));
        return (string)(int)($count->{sanitize_text_field($a['status'])} ?? 0);
    });

    // [sf_login_link] / [sf_logout_link]
    add_shortcode('sf_login_link', function(array $atts): string {
        $a = shortcode_atts(['label'=>__('Log In','starter-flavor'),'redirect'=>''], $atts, 'sf_login_link');
        if (is_user_logged_in()) return '';
        return '<a href="'.esc_url(wp_login_url($a['redirect'])).'" class="sf-login-link">'.esc_html($a['label']).'</a>';
    });
    add_shortcode('sf_logout_link', function(array $atts): string {
        $a = shortcode_atts(['label'=>__('Log Out','starter-flavor'),'redirect'=>''], $atts, 'sf_logout_link');
        if (!is_user_logged_in()) return '';
        return '<a href="'.esc_url(wp_logout_url($a['redirect'])).'" class="sf-logout-link">'.esc_html($a['label']).'</a>';
    });

    // [sf_reading_time] — estimated reading time for current post
    add_shortcode('sf_reading_time', function(array $atts): string {
        $a = shortcode_atts(['wpm'=>200,'suffix'=>__('min read','starter-flavor')], $atts, 'sf_reading_time');
        $words  = str_word_count(strip_tags(get_the_content()));
        $mins   = max(1, (int)ceil($words / (int)$a['wpm']));
        return $mins.' '.esc_html($a['suffix']);
    });
}, 10);
