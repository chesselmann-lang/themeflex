<?php
/**
 * Single Post Styles Class
 *
 * Manages multiple single post layout styles.
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Starter_Flavor_Single_Post_Styles class
 */
class Starter_Flavor_Single_Post_Styles {

	/**
	 * Instance variable
	 *
	 * @var Starter_Flavor_Single_Post_Styles
	 */
	private static $instance = null;

	/**
	 * Get instance
	 *
	 * @return Starter_Flavor_Single_Post_Styles
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'customize_register', array( $this, 'register_customizer_settings' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_post_meta_box' ) );
		add_action( 'save_post', array( $this, 'save_post_meta' ) );
	}

	/**
	 * Register customizer settings
	 *
	 * @param WP_Customize_Manager $wp_customize The customizer object.
	 */
	public function register_customizer_settings( $wp_customize ) {
		// Single Post Panel
		$wp_customize->add_panel(
			'starter_flavor_single_post',
			array(
				'title'       => esc_html__( 'Single Post', 'starter-flavor' ),
				'description' => esc_html__( 'Configure single post layout', 'starter-flavor' ),
				'priority'    => 85,
			)
		);

		// Default style
		$wp_customize->add_setting(
			'starter_flavor_single_post_style',
			array(
				'default'           => 'style-1',
				'sanitize_callback' => array( $this, 'sanitize_style' ),
				'transport'         => 'refresh',
			)
		);

		$wp_customize->add_control(
			'starter_flavor_single_post_style',
			array(
				'type'            => 'select',
				'section'         => 'starter_flavor_single_post',
				'label'           => esc_html__( 'Default Layout Style', 'starter-flavor' ),
				'choices'         => array(
					'style-1' => esc_html__( 'Style 1 - Classic', 'starter-flavor' ),
					'style-2' => esc_html__( 'Style 2 - Modern', 'starter-flavor' ),
					'style-3' => esc_html__( 'Style 3 - Minimal', 'starter-flavor' ),
				),
				'priority'        => 10,
			)
		);
	}

	/**
	 * Sanitize style option
	 *
	 * @param string $value The value to sanitize.
	 * @return string
	 */
	public function sanitize_style( $value ) {
		$allowed = array( 'style-1', 'style-2', 'style-3' );
		return in_array( $value, $allowed, true ) ? $value : 'style-1';
	}

	/**
	 * Enqueue assets
	 */
	public function enqueue_assets() {
		if ( is_singular( 'post' ) ) {
			wp_enqueue_style(
				'starter-flavor-single-styles',
				get_template_directory_uri() . '/assets/css/single-styles.css',
				array(),
				STARTER_FLAVOR_VERSION
			);
		}
	}

	/**
	 * Add meta box
	 */
	public function add_post_meta_box() {
		add_meta_box(
			'starter_flavor_single_post_style',
			esc_html__( 'Post Layout Style', 'starter-flavor' ),
			array( $this, 'render_meta_box' ),
			'post',
			'side',
			'default'
		);
	}

	/**
	 * Render meta box
	 *
	 * @param WP_Post $post The post object.
	 */
	public function render_meta_box( $post ) {
		wp_nonce_field( 'starter_flavor_single_post_style', 'starter_flavor_single_post_style_nonce' );

		$style = get_post_meta( $post->ID, '_starter_flavor_post_style', true );
		if ( empty( $style ) ) {
			$style = get_theme_mod( 'starter_flavor_single_post_style', 'style-1' );
		}

		$styles = array(
			'style-1' => esc_html__( 'Classic - Featured image above, sidebar right', 'starter-flavor' ),
			'style-2' => esc_html__( 'Modern - Hero image with overlay, no sidebar', 'starter-flavor' ),
			'style-3' => esc_html__( 'Minimal - Centered content, no featured image', 'starter-flavor' ),
		);

		echo '<select name="starter_flavor_post_style" id="starter_flavor_post_style">';
		echo '<option value="">' . esc_html__( 'Use Default', 'starter-flavor' ) . '</option>';

		foreach ( $styles as $key => $label ) {
			echo '<option value="' . esc_attr( $key ) . '"' . selected( $style, $key ) . '>' . esc_html( $label ) . '</option>';
		}

		echo '</select>';
	}

	/**
	 * Save post meta
	 *
	 * @param int $post_id The post ID.
	 */
	public function save_post_meta( $post_id ) {
		if ( ! isset( $_POST['starter_flavor_single_post_style_nonce'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( $_POST['starter_flavor_single_post_style_nonce'], 'starter_flavor_single_post_style' ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( isset( $_POST['starter_flavor_post_style'] ) ) {
			$style = sanitize_text_field( $_POST['starter_flavor_post_style'] );
			update_post_meta( $post_id, '_starter_flavor_post_style', $style );
		}
	}

	/**
	 * Get the current post style
	 *
	 * @param int $post_id Optional post ID.
	 * @return string
	 */
	public function get_post_style( $post_id = 0 ) {
		if ( 0 === $post_id ) {
			$post_id = get_the_ID();
		}

		// Check for post-specific override
		$style = get_post_meta( $post_id, '_starter_flavor_post_style', true );

		if ( empty( $style ) ) {
			// Use default theme setting
			$style = get_theme_mod( 'starter_flavor_single_post_style', 'style-1' );
		}

		return $style;
	}

	/**
	 * Display single post
	 */
	public function display() {
		$style = $this->get_post_style();
		get_template_part( 'template-parts/single/' . $style );
	}
}

// Initialize
if ( ! function_exists( 'starter_flavor_single_post_styles' ) ) {
	/**
	 * Get single post styles instance
	 *
	 * @return Starter_Flavor_Single_Post_Styles
	 */
	function starter_flavor_single_post_styles() {
		return Starter_Flavor_Single_Post_Styles::get_instance();
	}
}

starter_flavor_single_post_styles();
