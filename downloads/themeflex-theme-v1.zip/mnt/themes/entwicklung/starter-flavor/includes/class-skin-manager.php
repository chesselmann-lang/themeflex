<?php
/**
 * Starter Flavor Skin Manager
 *
 * Manages theme skins with extensible skin system for customization.
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Skin Manager Class
 *
 * @since 1.0.0
 */
class Starter_Flavor_Skin_Manager {

	/**
	 * Available skins
	 *
	 * @var array
	 */
	private $skins = array();

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->load_skins();

		add_action( 'customize_register', array( $this, 'customize_register' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_skin_styles' ) );
		add_action( 'wp_head', array( $this, 'output_skin_css_variables' ) );
	}

	/**
	 * Load all available skins
	 *
	 * @since 1.0.0
	 */
	private function load_skins() {
		$skins_dir = STARTER_FLAVOR_THEME_DIR . '/skins';

		// Load built-in skins
		$this->register_builtin_skins();

		// Allow plugins/child themes to register skins
		do_action( 'sf_register_skin', $this );

		// Load skins from /skins directory
		if ( is_dir( $skins_dir ) ) {
			$skin_folders = array_diff( scandir( $skins_dir ), array( '.', '..' ) );

			foreach ( $skin_folders as $folder ) {
				$skin_path = $skins_dir . '/' . $folder;

				if ( ! is_dir( $skin_path ) ) {
					continue;
				}

				$skin_data_file = $skin_path . '/skin.json';

				if ( file_exists( $skin_data_file ) ) {
					$skin_data = json_decode( file_get_contents( $skin_data_file ), true );

					if ( $skin_data ) {
						$this->skins[ $folder ] = array_merge(
							array(
								'id'        => $folder,
								'path'      => $skin_path,
								'name'      => $skin_data['name'] ?? ucfirst( $folder ),
								'desc'      => $skin_data['description'] ?? '',
								'screenshot' => $skin_path . '/screenshot.jpg',
								'config'    => $skin_path . '/skin.php',
								'css'       => $skin_path . '/skin.css',
							),
							$skin_data
						);
					}
				}
			}
		}
	}

	/**
	 * Register built-in skins
	 *
	 * @since 1.0.0
	 */
	private function register_builtin_skins() {
		$skins_dir = STARTER_FLAVOR_THEME_DIR . '/skins';

		// Default Skin
		$this->skins['default'] = array(
			'id'         => 'default',
			'name'       => esc_html__( 'Default', 'starter-flavor' ),
			'desc'       => esc_html__( 'The current orange design', 'starter-flavor' ),
			'path'       => $skins_dir . '/default',
			'screenshot' => $skins_dir . '/default/screenshot.jpg',
			'colors'     => array(
				'primary'   => '#FF5E2E',
				'secondary' => '#1F242E',
				'accent'    => '#00D4FF',
			),
		);

		// Corporate Skin
		$this->skins['corporate'] = array(
			'id'         => 'corporate',
			'name'       => esc_html__( 'Corporate', 'starter-flavor' ),
			'desc'       => esc_html__( 'Professional blue design with serif headings', 'starter-flavor' ),
			'path'       => $skins_dir . '/corporate',
			'screenshot' => $skins_dir . '/corporate/screenshot.jpg',
			'colors'     => array(
				'primary'   => '#3B82F6',
				'secondary' => '#1e293b',
				'accent'    => '#f59e0b',
			),
			'typography' => array(
				'heading_font_family' => 'Lora',
			),
		);

		// Creative Skin
		$this->skins['creative'] = array(
			'id'         => 'creative',
			'name'       => esc_html__( 'Creative', 'starter-flavor' ),
			'desc'       => esc_html__( 'Modern green design with gradient accents', 'starter-flavor' ),
			'path'       => $skins_dir . '/creative',
			'screenshot' => $skins_dir . '/creative/screenshot.jpg',
			'colors'     => array(
				'primary'   => '#10B981',
				'secondary' => '#065f46',
				'accent'    => '#ec4899',
			),
		);
	}

	/**
	 * Get all registered skins
	 *
	 * @since 1.0.0
	 * @return array List of skins.
	 */
	public function get_skins() {
		return $this->skins;
	}

	/**
	 * Get a specific skin
	 *
	 * @since 1.0.0
	 * @param string $skin_id The skin ID.
	 * @return array|false Skin data or false if not found.
	 */
	public function get_skin( $skin_id ) {
		return isset( $this->skins[ $skin_id ] ) ? $this->skins[ $skin_id ] : false;
	}

	/**
	 * Register a custom skin
	 *
	 * @since 1.0.0
	 * @param string $skin_id The skin ID.
	 * @param array  $skin_args Skin arguments.
	 */
	public function register_skin( $skin_id, $skin_args ) {
		$defaults = array(
			'id'         => $skin_id,
			'name'       => ucfirst( $skin_id ),
			'desc'       => '',
			'path'       => '',
			'screenshot' => '',
			'colors'     => array(),
			'typography' => array(),
		);

		$this->skins[ $skin_id ] = wp_parse_args( $skin_args, $defaults );
	}

	/**
	 * Get active skin ID
	 *
	 * @since 1.0.0
	 * @return string The active skin ID.
	 */
	public function get_active_skin() {
		return get_theme_mod( 'starter_flavor_active_skin', 'default' );
	}

	/**
	 * Set active skin
	 *
	 * @since 1.0.0
	 * @param string $skin_id The skin ID.
	 * @return bool True if set successfully.
	 */
	public function set_active_skin( $skin_id ) {
		if ( ! isset( $this->skins[ $skin_id ] ) ) {
			return false;
		}

		set_theme_mod( 'starter_flavor_active_skin', $skin_id );

		// Load skin config if available
		$skin = $this->get_skin( $skin_id );
		if ( $skin && file_exists( $skin['config'] ) ) {
			include_once $skin['config'];
		}

		return true;
	}

	/**
	 * Register customizer controls
	 *
	 * @since 1.0.0
	 * @param WP_Customize_Manager $wp_customize The customizer object.
	 */
	public function customize_register( $wp_customize ) {
		// Add Skins Section
		$wp_customize->add_section(
			'starter_flavor_skins',
			array(
				'title'       => esc_html__( 'Skins', 'starter-flavor' ),
				'description' => esc_html__( 'Choose a design skin for your site', 'starter-flavor' ),
				'panel'       => 'starter_flavor_colors',
				'priority'    => 5,
			)
		);

		// Add Skin Selector Setting
		$wp_customize->add_setting(
			'starter_flavor_active_skin',
			array(
				'default'           => 'default',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);

		// Add Skin Selector Control
		$wp_customize->add_control(
			'starter_flavor_active_skin',
			array(
				'type'    => 'radio',
				'section' => 'starter_flavor_skins',
				'label'   => esc_html__( 'Select Skin', 'starter-flavor' ),
				'choices' => $this->get_skin_choices(),
			)
		);
	}

	/**
	 * Get skin choices for customizer
	 *
	 * @since 1.0.0
	 * @return array Skin choices.
	 */
	private function get_skin_choices() {
		$choices = array();

		foreach ( $this->skins as $skin ) {
			$choices[ $skin['id'] ] = $skin['name'];
		}

		return $choices;
	}

	/**
	 * Enqueue active skin stylesheet
	 *
	 * @since 1.0.0
	 */
	public function enqueue_skin_styles() {
		$active_skin_id = $this->get_active_skin();
		$skin = $this->get_skin( $active_skin_id );

		if ( ! $skin ) {
			return;
		}

		// Enqueue skin CSS if it exists
		if ( file_exists( $skin['css'] ) ) {
			$relative_path = str_replace( STARTER_FLAVOR_THEME_DIR, '', $skin['css'] );
			wp_enqueue_style(
				'sf-skin-' . $active_skin_id,
				STARTER_FLAVOR_THEME_URL . $relative_path,
				array( 'starter-flavor-style' ),
				STARTER_FLAVOR_VERSION
			);
		}

		// Load skin PHP config if it exists
		if ( file_exists( $skin['config'] ) ) {
			include_once $skin['config'];
		}
	}

	/**
	 * Output skin CSS variables based on active skin
	 *
	 * @since 1.0.0
	 */
	/**
	 * Output all skin CSS custom properties into :root.
	 *
	 * Emits three layers:
	 *  1. Brand color tokens  (--sf-color-primary, --sf-gradient, …)
	 *  2. Semantic surface tokens inspired by Elementra's color-scheme system:
	 *       --sf-bg / --sf-bg-2 / --sf-border / --sf-title / --sf-text / --sf-meta
	 *       --sf-alt-bg / --sf-alt-bg-2 / … (for dark/inverse sections)
	 *       --sf-link / --sf-hover / --sf-alt-link / --sf-alt-hover
	 *  3. Typography tokens  (--sf-body-font / --sf-heading-font)
	 *
	 * Skin CSS files can override any token freely; this gives sane defaults.
	 *
	 * @since 1.1.0
	 */
	public function output_skin_css_variables() {
		if ( is_admin() ) {
			return;
		}

		$skin = $this->get_skin( $this->get_active_skin() );
		if ( ! $skin ) {
			return;
		}

		$c   = isset( $skin['colors'] )     ? $skin['colors']     : array();
		$sch = isset( $skin['scheme'] )     ? $skin['scheme']     : array();
		$typ = isset( $skin['typography'] ) ? $skin['typography'] : array();

		/* ── helpers ─────────────────────────────────────────────────────── */
		$v = static function( array $src, string $key ) {
			return isset( $src[ $key ] ) ? esc_attr( $src[ $key ] ) : '';
		};

		/* ── Brand color tokens ─────────────────────────────────────────── */
		$primary       = $v( $c, 'primary' );
		$primary_dark  = $v( $c, 'primary_dark' );
		$primary_light = $v( $c, 'primary_light' );
		$secondary     = $v( $c, 'secondary' );
		$accent        = $v( $c, 'accent' );
		$accent_light  = $v( $c, 'accent_light' );

		// Derive dark/light if not set explicitly
		$derived_dark  = $primary ? 'color-mix(in srgb,' . $primary . ' 80%,#000)' : '';
		$derived_light = $primary ? 'color-mix(in srgb,' . $primary . ' 70%,#fff)' : '';

		$css = ':root {';

		if ( $primary )                     $css .= '--sf-color-primary:'       . $primary . ';';
		if ( $primary_dark  ?: $derived_dark  ) $css .= '--sf-color-primary-dark:'  . ( $primary_dark  ?: $derived_dark  ) . ';';
		if ( $primary_light ?: $derived_light ) $css .= '--sf-color-primary-light:' . ( $primary_light ?: $derived_light ) . ';';
		if ( $secondary )                   $css .= '--sf-color-secondary:'     . $secondary . ';';
		if ( $accent )                      $css .= '--sf-color-accent:'        . $accent . ';';
		if ( $accent_light )                $css .= '--sf-color-accent-light:'  . $accent_light . ';';

		// Gradient shorthands
		$pd = $primary_dark ?: $derived_dark;
		$pl = $primary_light ?: $derived_light;
		if ( $primary && $pd ) {
			$css .= '--sf-gradient:linear-gradient(135deg,' . $primary . ' 0%,' . $pd . ' 100%);';
			$css .= '--sf-gradient-dark:linear-gradient(135deg,' . $pd . ' 0%,color-mix(in srgb,' . $primary . ' 60%,#000) 100%);';
		}
		if ( $primary ) {
			$css .= '--sf-gradient-soft:linear-gradient(135deg,color-mix(in srgb,' . $primary . ' 12%,#fff) 0%,color-mix(in srgb,' . $primary . ' 6%,#fff) 100%);';
		}

		/* ── Semantic surface tokens (Elementra-style, 16 tokens) ────────── */
		// Main scheme (light sections)
		$bg         = $v( $sch, 'bg' );
		$bg_2       = $v( $sch, 'bg_2' );
		$border     = $v( $sch, 'border' );
		$title      = $v( $sch, 'title' );
		$text       = $v( $sch, 'text' );
		$meta       = $v( $sch, 'meta' );
		// Alt scheme (dark/inverse sections, footer, hero overlays)
		$alt_bg     = $v( $sch, 'alt_bg' );
		$alt_bg_2   = $v( $sch, 'alt_bg_2' );
		$alt_border = $v( $sch, 'alt_border' );
		$alt_title  = $v( $sch, 'alt_title' );
		$alt_text   = $v( $sch, 'alt_text' );
		$alt_meta   = $v( $sch, 'alt_meta' );

		if ( $bg )         $css .= '--sf-bg:'         . $bg . ';';
		if ( $bg_2 )       $css .= '--sf-bg-2:'       . $bg_2 . ';';
		if ( $border )     $css .= '--sf-border:'     . $border . ';';
		if ( $title )      $css .= '--sf-title:'      . $title . ';';
		if ( $text )       $css .= '--sf-text:'       . $text . ';';
		if ( $meta )       $css .= '--sf-meta:'       . $meta . ';';

		if ( $alt_bg )     $css .= '--sf-alt-bg:'     . $alt_bg . ';';
		if ( $alt_bg_2 )   $css .= '--sf-alt-bg-2:'   . $alt_bg_2 . ';';
		if ( $alt_border ) $css .= '--sf-alt-border:' . $alt_border . ';';
		if ( $alt_title )  $css .= '--sf-alt-title:'  . $alt_title . ';';
		if ( $alt_text )   $css .= '--sf-alt-text:'   . $alt_text . ';';
		if ( $alt_meta )   $css .= '--sf-alt-meta:'   . $alt_meta . ';';

		// link / hover always derived from brand colors
		if ( $primary )  $css .= '--sf-link:' . $primary . ';--sf-alt-link:' . $primary . ';';
		if ( $pd )       $css .= '--sf-hover:' . $pd . ';';
		if ( $pl )       $css .= '--sf-alt-hover:' . $pl . ';';

		/* ── Typography ──────────────────────────────────────────────────── */
		$body_font    = $v( $typ, 'body_font_family' );
		$heading_font = $v( $typ, 'heading_font_family' );
		$base_size    = $v( $typ, 'base_font_size' );
		$base_lh      = $v( $typ, 'base_line_height' );

		if ( $body_font )    $css .= "--sf-body-font:'{$body_font}',sans-serif;";
		if ( $heading_font ) $css .= "--sf-heading-font:'{$heading_font}',sans-serif;";
		if ( $base_size )    $css .= "--sf-font-size-base:{$base_size};";
		if ( $base_lh )      $css .= "--sf-line-height-base:{$base_lh};";

		$css .= '}';

		wp_register_style( 'sf-skin-variables', false );
		wp_enqueue_style( 'sf-skin-variables' );
		wp_add_inline_style( 'sf-skin-variables', $css );
	}

	/**
	 * Get screenshot URL for a skin
	 *
	 * @since 1.0.0
	 * @param string $skin_id The skin ID.
	 * @return string|false Screenshot URL or false.
	 */
	public function get_skin_screenshot( $skin_id ) {
		$skin = $this->get_skin( $skin_id );

		if ( ! $skin || ! file_exists( $skin['screenshot'] ) ) {
			return false;
		}

		$relative_path = str_replace( STARTER_FLAVOR_THEME_DIR, '', $skin['screenshot'] );
		return STARTER_FLAVOR_THEME_URL . $relative_path;
	}
}

// Initialize the class
function starter_flavor_skin_manager() {
	static $instance = null;

	if ( is_null( $instance ) ) {
		$instance = new Starter_Flavor_Skin_Manager();
	}

	return $instance;
}

// Get the skin manager instance
starter_flavor_skin_manager();
