<?php
/**
 * Theme Dashboard
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Starter_Flavor_Theme_Dashboard {

	/**
	 * Initialize
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_dashboard_page' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_notices', array( __CLASS__, 'welcome_notice' ) );
		add_action( 'wp_ajax_sf_dismiss_welcome_notice', array( __CLASS__, 'ajax_dismiss_notice' ) );
	}

	/**
	 * Register dashboard page
	 */
	public static function register_dashboard_page() {
		add_menu_page(
			esc_html__( 'Starter Flavor', 'starter-flavor' ),
			esc_html__( 'Starter Flavor', 'starter-flavor' ),
			'manage_options',
			'starter-flavor-dashboard',
			array( __CLASS__, 'render_dashboard' ),
			'dashicons-welcome-learn-more',
			59
		);
	}

	/**
	 * Enqueue dashboard assets
	 */
	public static function enqueue_assets( $hook ) {
		if ( 'toplevel_page_starter-flavor-dashboard' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'sf-dashboard',
			STARTER_FLAVOR_THEME_URL . '/assets/css/dashboard.css',
			array(),
			STARTER_FLAVOR_VERSION
		);

		wp_enqueue_script(
			'sf-dashboard',
			STARTER_FLAVOR_THEME_URL . '/assets/js/dashboard.js',
			array( 'jquery' ),
			STARTER_FLAVOR_VERSION,
			true
		);

		wp_localize_script(
			'sf-dashboard',
			'sfDashboard',
			array(
				'nonce' => wp_create_nonce( 'sf_dashboard_nonce' ),
			)
		);
	}

	/**
	 * Render dashboard
	 */
	public static function render_dashboard() {
		?>
		<div class="wrap sf-dashboard-page">
			<div class="sf-dashboard-header">
				<h1><?php esc_html_e( 'Welcome to Starter Flavor', 'starter-flavor' ); ?></h1>
				<p><?php esc_html_e( 'A powerful WordPress theme for creative professionals', 'starter-flavor' ); ?></p>
			</div>

			<div class="sf-dashboard-content">
				<div class="sf-tabs-nav">
					<button class="sf-tab-btn active" data-tab="welcome"><?php esc_html_e( 'Welcome', 'starter-flavor' ); ?></button>
					<button class="sf-tab-btn" data-tab="getting-started"><?php esc_html_e( 'Getting Started', 'starter-flavor' ); ?></button>
					<button class="sf-tab-btn" data-tab="plugins"><?php esc_html_e( 'Plugins', 'starter-flavor' ); ?></button>
					<button class="sf-tab-btn" data-tab="system"><?php esc_html_e( 'System Info', 'starter-flavor' ); ?></button>
					<button class="sf-tab-btn" data-tab="changelog"><?php esc_html_e( 'Changelog', 'starter-flavor' ); ?></button>
					<button class="sf-tab-btn" data-tab="support"><?php esc_html_e( 'Support', 'starter-flavor' ); ?></button>
				</div>

				<!-- Welcome Tab -->
				<div id="welcome" class="sf-tab-content active">
					<h2><?php esc_html_e( 'Theme Information', 'starter-flavor' ); ?></h2>
					<div class="sf-info-card">
						<p><?php esc_html_e( 'Theme Name:', 'starter-flavor' ); ?> <strong>Starter Flavor</strong></p>
						<p><?php esc_html_e( 'Version:', 'starter-flavor' ); ?> <strong><?php echo esc_html( STARTER_FLAVOR_VERSION ); ?></strong></p>
						<p><?php esc_html_e( 'Author:', 'starter-flavor' ); ?> <strong>Starter Flavor Team</strong></p>
						<p><?php esc_html_e( 'License:', 'starter-flavor' ); ?> <strong>GPL v2 or later</strong></p>
					</div>

					<h3><?php esc_html_e( 'Quick Links', 'starter-flavor' ); ?></h3>
					<ul class="sf-quick-links">
						<li><a href="<?php echo esc_url( admin_url( 'customize.php' ) ); ?>" class="button"><?php esc_html_e( 'Customize Theme', 'starter-flavor' ); ?></a></li>
						<li><a href="<?php echo esc_url( admin_url( 'themes.php?page=starter-flavor-demo-importer' ) ); ?>" class="button"><?php esc_html_e( 'Import Demo', 'starter-flavor' ); ?></a></li>
						<li><a href="<?php echo esc_url( admin_url( 'nav-menus.php' ) ); ?>" class="button"><?php esc_html_e( 'Manage Menus', 'starter-flavor' ); ?></a></li>
						<li><a href="<?php echo esc_url( admin_url( 'widgets.php' ) ); ?>" class="button"><?php esc_html_e( 'Manage Widgets', 'starter-flavor' ); ?></a></li>
					</ul>
				</div>

				<!-- Getting Started Tab -->
				<div id="getting-started" class="sf-tab-content">
					<h2><?php esc_html_e( 'Getting Started Setup Guide', 'starter-flavor' ); ?></h2>

					<div class="sf-setup-steps">
						<div class="sf-setup-step">
							<div class="sf-step-number">1</div>
							<div class="sf-step-content">
								<h3><?php esc_html_e( 'Install Recommended Plugins', 'starter-flavor' ); ?></h3>
								<p><?php esc_html_e( 'Install Elementor and other recommended plugins for the best experience.', 'starter-flavor' ); ?></p>
								<a href="<?php echo esc_url( admin_url( 'admin.php?page=tgmpa-install-plugins' ) ); ?>" class="button"><?php esc_html_e( 'Install Plugins', 'starter-flavor' ); ?></a>
							</div>
						</div>

						<div class="sf-setup-step">
							<div class="sf-step-number">2</div>
							<div class="sf-step-content">
								<h3><?php esc_html_e( 'Import Demo Content', 'starter-flavor' ); ?></h3>
								<p><?php esc_html_e( 'Choose from multiple demo templates to get started quickly.', 'starter-flavor' ); ?></p>
								<a href="<?php echo esc_url( admin_url( 'themes.php?page=starter-flavor-demo-importer' ) ); ?>" class="button"><?php esc_html_e( 'Import Demo', 'starter-flavor' ); ?></a>
							</div>
						</div>

						<div class="sf-setup-step">
							<div class="sf-step-number">3</div>
							<div class="sf-step-content">
								<h3><?php esc_html_e( 'Setup Homepage', 'starter-flavor' ); ?></h3>
								<p><?php esc_html_e( 'Create and set a static homepage for your site.', 'starter-flavor' ); ?></p>
								<a href="<?php echo esc_url( admin_url( 'customize.php?autofocus[section]=static_front_page' ) ); ?>" class="button"><?php esc_html_e( 'Setup Homepage', 'starter-flavor' ); ?></a>
							</div>
						</div>

						<div class="sf-setup-step">
							<div class="sf-step-number">4</div>
							<div class="sf-step-content">
								<h3><?php esc_html_e( 'Customize Theme', 'starter-flavor' ); ?></h3>
								<p><?php esc_html_e( 'Customize colors, fonts, layouts, and more from the Theme Customizer.', 'starter-flavor' ); ?></p>
								<a href="<?php echo esc_url( admin_url( 'customize.php' ) ); ?>" class="button button-primary"><?php esc_html_e( 'Go to Customizer', 'starter-flavor' ); ?></a>
							</div>
						</div>
					</div>
				</div>

				<!-- Plugins Tab -->
				<div id="plugins" class="sf-tab-content">
					<h2><?php esc_html_e( 'Recommended Plugins', 'starter-flavor' ); ?></h2>
					<?php self::render_plugins_status(); ?>
				</div>

				<!-- System Info Tab -->
				<div id="system" class="sf-tab-content">
					<h2><?php esc_html_e( 'System Information', 'starter-flavor' ); ?></h2>
					<?php self::render_system_info(); ?>
				</div>

				<!-- Changelog Tab -->
				<div id="changelog" class="sf-tab-content">
					<h2><?php esc_html_e( 'Changelog', 'starter-flavor' ); ?></h2>
					<?php self::render_changelog(); ?>
				</div>

				<!-- Support Tab -->
				<div id="support" class="sf-tab-content">
					<h2><?php esc_html_e( 'Support & Resources', 'starter-flavor' ); ?></h2>
					<div class="sf-support-grid">
						<div class="sf-support-card">
							<h3><?php esc_html_e( 'Documentation', 'starter-flavor' ); ?></h3>
							<p><?php esc_html_e( 'Read our comprehensive documentation and guides.', 'starter-flavor' ); ?></p>
							<a href="#" target="_blank" class="button"><?php esc_html_e( 'View Docs', 'starter-flavor' ); ?></a>
						</div>
						<div class="sf-support-card">
							<h3><?php esc_html_e( 'Support Forum', 'starter-flavor' ); ?></h3>
							<p><?php esc_html_e( 'Get help from our support community.', 'starter-flavor' ); ?></p>
							<a href="#" target="_blank" class="button"><?php esc_html_e( 'Visit Forum', 'starter-flavor' ); ?></a>
						</div>
						<div class="sf-support-card">
							<h3><?php esc_html_e( 'Video Tutorials', 'starter-flavor' ); ?></h3>
							<p><?php esc_html_e( 'Learn from video tutorials and walkthroughs.', 'starter-flavor' ); ?></p>
							<a href="#" target="_blank" class="button"><?php esc_html_e( 'Watch Videos', 'starter-flavor' ); ?></a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render plugins status
	 */
	private static function render_plugins_status() {
		$recommended = array(
			'elementor' => array(
				'name' => 'Elementor Page Builder',
				'file' => 'elementor/elementor.php',
			),
			'woocommerce' => array(
				'name' => 'WooCommerce',
				'file' => 'woocommerce/woocommerce.php',
			),
			'rank-math-seo' => array(
				'name' => 'Rank Math SEO',
				'file' => 'seo-by-rank-math/rank-math.php',
			),
			'contact-form-7' => array(
				'name' => 'Contact Form 7',
				'file' => 'contact-form-7/wp-contact-form-7.php',
			),
		);

		echo '<table class="wp-list-table striped">';
		echo '<thead><tr><th>' . esc_html__( 'Plugin', 'starter-flavor' ) . '</th><th>' . esc_html__( 'Status', 'starter-flavor' ) . '</th></tr></thead>';
		echo '<tbody>';

		foreach ( $recommended as $slug => $plugin ) {
			$active = is_plugin_active( $plugin['file'] );
			$status = $active ? '<span style="color: green;">✓ ' . esc_html__( 'Active', 'starter-flavor' ) . '</span>' : '<span style="color: orange;">✗ ' . esc_html__( 'Inactive', 'starter-flavor' ) . '</span>';

			echo '<tr>';
			echo '<td>' . esc_html( $plugin['name'] ) . '</td>';
			echo '<td>' . wp_kses_post( $status ) . '</td>';
			echo '</tr>';
		}

		echo '</tbody>';
		echo '</table>';
	}

	/**
	 * Render system info
	 */
	private static function render_system_info() {
		?>
		<table class="wp-list-table striped">
			<tbody>
				<tr>
					<td><?php esc_html_e( 'PHP Version', 'starter-flavor' ); ?></td>
					<td><strong><?php echo esc_html( phpversion() ); ?></strong></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'WordPress Version', 'starter-flavor' ); ?></td>
					<td><strong><?php echo esc_html( get_bloginfo( 'version' ) ); ?></strong></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Theme Version', 'starter-flavor' ); ?></td>
					<td><strong><?php echo esc_html( STARTER_FLAVOR_VERSION ); ?></strong></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Memory Limit', 'starter-flavor' ); ?></td>
					<td><strong><?php echo esc_html( WP_MEMORY_LIMIT ); ?></strong></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Max Upload Size', 'starter-flavor' ); ?></td>
					<td><strong><?php echo esc_html( size_format( wp_max_upload_size() ) ); ?></strong></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Active Plugins', 'starter-flavor' ); ?></td>
					<td><strong><?php echo count( get_option( 'active_plugins' ) ); ?></strong></td>
				</tr>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Render changelog
	 */
	private static function render_changelog() {
		?>
		<div class="sf-changelog">
			<h3>Version 1.0.0</h3>
			<ul>
				<li><?php esc_html_e( 'Initial release', 'starter-flavor' ); ?></li>
				<li><?php esc_html_e( '6 Elementor widgets', 'starter-flavor' ); ?></li>
				<li><?php esc_html_e( 'Parallax and animation system', 'starter-flavor' ); ?></li>
				<li><?php esc_html_e( 'Video background support', 'starter-flavor' ); ?></li>
				<li><?php esc_html_e( 'Custom icon library', 'starter-flavor' ); ?></li>
				<li><?php esc_html_e( 'Advanced header features', 'starter-flavor' ); ?></li>
				<li><?php esc_html_e( 'Demo content importer', 'starter-flavor' ); ?></li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Welcome notice
	 */
	public static function welcome_notice() {
		if ( get_option( 'sf_welcome_notice_dismissed' ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( 'appearance_page_starter-flavor-dashboard' === get_current_screen()->id ) {
			return;
		}

		?>
		<div class="notice notice-info is-dismissible" id="sf-welcome-notice">
			<p>
				<strong><?php esc_html_e( 'Welcome to Starter Flavor!', 'starter-flavor' ); ?></strong>
				<?php esc_html_e( 'Set up your new theme with our quick start guide.', 'starter-flavor' ); ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=starter-flavor-dashboard' ) ); ?>" class="button button-small">
					<?php esc_html_e( 'Get Started', 'starter-flavor' ); ?>
				</a>
			</p>
		</div>

		<script>
			jQuery(document).ready(function($) {
				$('#sf-welcome-notice').on('click', '.notice-dismiss', function() {
					$.post(ajaxurl, {
						action: 'sf_dismiss_welcome_notice',
						nonce: '<?php echo wp_create_nonce( 'sf_dismiss_notice' ); ?>'
					});
				});
			});
		</script>
		<?php
	}

	/**
	 * AJAX dismiss notice
	 */
	public static function ajax_dismiss_notice() {
		check_ajax_referer( 'sf_dismiss_notice', 'nonce' );
		update_option( 'sf_welcome_notice_dismissed', 1 );
		wp_send_json_success();
	}
}

// Initialize
Starter_Flavor_Theme_Dashboard::init();
