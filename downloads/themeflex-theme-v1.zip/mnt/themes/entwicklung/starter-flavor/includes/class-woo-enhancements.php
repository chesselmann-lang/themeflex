<?php
/**
 * WooCommerce Enhancements
 *
 * Additional WooCommerce features for enhanced shopping experience:
 * - Quick view modal for product previews
 * - AJAX add-to-cart on archive pages
 * - Product image zoom functionality
 * - Wishlist support hooks
 * - Size guide modal integration
 * - Cross-sells and upsells styling
 * - Mini-cart in header with AJAX updates
 * - Product badges (new, sale, out of stock)
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Starter_Flavor_Woo_Enhancements {

	/**
	 * Initialize WooCommerce enhancements
	 *
	 * @since 1.0.0
	 */
	public static function init() {
		// Quick view modal
		add_action( 'wp_footer', array( __CLASS__, 'quick_view_modal' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_scripts' ) );

		// AJAX handlers
		add_action( 'wp_ajax_sf_quick_view', array( __CLASS__, 'ajax_quick_view' ) );
		add_action( 'wp_ajax_nopriv_sf_quick_view', array( __CLASS__, 'ajax_quick_view' ) );

		add_action( 'wp_ajax_sf_add_to_cart_archive', array( __CLASS__, 'ajax_add_to_cart_archive' ) );
		add_action( 'wp_ajax_nopriv_sf_add_to_cart_archive', array( __CLASS__, 'ajax_add_to_cart_archive' ) );

		add_action( 'wp_ajax_sf_product_image_zoom', array( __CLASS__, 'ajax_product_image_zoom' ) );
		add_action( 'wp_ajax_nopriv_sf_product_image_zoom', array( __CLASS__, 'ajax_product_image_zoom' ) );

		// Product badges
		add_action( 'woocommerce_before_shop_loop_item', array( __CLASS__, 'render_product_badges' ), 5 );
		add_action( 'woocommerce_before_single_product_summary', array( __CLASS__, 'render_single_product_badges' ), 5 );

		// Size guide modal
		add_action( 'woocommerce_single_product_summary', array( __CLASS__, 'size_guide_button' ), 25 );
		add_action( 'wp_footer', array( __CLASS__, 'size_guide_modal' ) );

		// Cross-sells and upsells
		add_filter( 'woocommerce_cross_sells_columns', array( __CLASS__, 'cross_sells_columns' ) );
		add_filter( 'woocommerce_upsells_columns', array( __CLASS__, 'upsells_columns' ) );

		// Wishlist button
		add_action( 'woocommerce_after_shop_loop_item', array( __CLASS__, 'wishlist_button' ), 14 );
		add_action( 'woocommerce_single_product_summary', array( __CLASS__, 'single_product_wishlist_button' ), 31 );

		// Mini cart update on add to cart
		add_action( 'woocommerce_after_add_to_cart_button', array( __CLASS__, 'mini_cart_update_script' ) );
	}

	/**
	 * Enqueue scripts and styles
	 *
	 * @since 1.0.0
	 */
	public static function enqueue_scripts() {
		if ( ! is_woocommerce() && ! is_cart() && ! is_checkout() ) {
			return;
		}

		wp_enqueue_script(
			'sf-woo-enhancements',
			STARTER_FLAVOR_THEME_URL . '/assets/js/woo-enhancements.js',
			array( 'jquery', 'wp-util' ),
			STARTER_FLAVOR_VERSION,
			true
		);

		wp_localize_script(
			'sf-woo-enhancements',
			'sfWooEnhancements',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'sf-woo-enhancements' ),
			)
		);
	}

	/**
	 * Render quick view modal container
	 *
	 * @since 1.0.0
	 */
	public static function quick_view_modal() {
		if ( ! is_woocommerce() ) {
			return;
		}

		?>
		<div id="sf-quick-view-modal" class="sf-modal sf-quick-view-modal" role="dialog" aria-labelledby="sf-qv-title" aria-hidden="true">
			<div class="sf-modal-content">
				<button type="button" class="sf-modal-close" aria-label="<?php esc_attr_e( 'Close modal', 'starter-flavor' ); ?>">
					<span aria-hidden="true">&times;</span>
				</button>
				<div id="sf-quick-view-body" class="sf-quick-view-body">
					<!-- Content loaded via AJAX -->
					<div class="sf-loading">
						<div class="spinner"></div>
						<?php esc_html_e( 'Loading product...', 'starter-flavor' ); ?>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * AJAX quick view handler
	 *
	 * @since 1.0.0
	 */
	public static function ajax_quick_view() {
		check_ajax_referer( 'sf-woo-enhancements', 'nonce' );

		if ( ! isset( $_POST['product_id'] ) ) {
			wp_send_json_error( array( 'message' => 'No product ID provided' ) );
		}

		$product_id = intval( $_POST['product_id'] );
		$product = wc_get_product( $product_id );

		if ( ! $product ) {
			wp_send_json_error( array( 'message' => 'Product not found' ) );
		}

		ob_start();
		?>
		<div class="sf-qv-wrapper">
			<div class="sf-qv-image">
				<?php
				if ( has_post_thumbnail( $product_id ) ) {
					echo wp_kses_post( get_the_post_thumbnail( $product_id, 'medium' ) );
				} else {
					echo wp_kses_post( wc_placeholder_img( 'medium' ) );
				}
				?>
			</div>
			<div class="sf-qv-content">
				<h2 id="sf-qv-title" class="sf-qv-title"><?php echo esc_html( $product->get_name() ); ?></h2>

				<div class="sf-qv-rating">
					<?php wc_get_template( 'single-product/rating.php' ); ?>
				</div>

				<div class="sf-qv-price">
					<?php echo wp_kses_post( $product->get_price_html() ); ?>
				</div>

				<?php if ( $product->get_short_description() ) : ?>
					<div class="sf-qv-description">
						<?php echo wp_kses_post( wp_trim_words( $product->get_short_description(), 25 ) ); ?>
					</div>
				<?php endif; ?>

				<div class="sf-qv-add-to-cart">
					<?php
					if ( $product->is_type( 'variable' ) ) {
						wc_get_template( 'single-product/add-to-cart/variable.php' );
					} else {
						wc_get_template( 'single-product/add-to-cart/simple.php' );
					}
					?>
				</div>

				<div class="sf-qv-actions">
					<a href="<?php echo esc_url( $product->get_permalink() ); ?>" class="button button-primary">
						<?php esc_html_e( 'View Full Details', 'starter-flavor' ); ?>
					</a>
				</div>
			</div>
		</div>
		<?php

		$html = ob_get_clean();
		wp_send_json_success( array( 'html' => $html ) );
	}

	/**
	 * AJAX add to cart for archive pages
	 *
	 * @since 1.0.0
	 */
	public static function ajax_add_to_cart_archive() {
		check_ajax_referer( 'sf-woo-enhancements', 'nonce' );

		if ( ! isset( $_POST['product_id'] ) ) {
			wp_send_json_error( array( 'message' => 'No product ID provided' ) );
		}

		$product_id = intval( $_POST['product_id'] );
		$quantity = isset( $_POST['quantity'] ) ? intval( $_POST['quantity'] ) : 1;
		$variation_id = isset( $_POST['variation_id'] ) ? intval( $_POST['variation_id'] ) : 0;

		$cart_item_key = WC()->cart->add_to_cart( $product_id, $quantity, $variation_id );

		if ( $cart_item_key ) {
			wp_send_json_success( array(
				'message'     => __( 'Product added to cart', 'starter-flavor' ),
				'cart_count'  => WC()->cart->get_cart_contents_count(),
				'cart_total'  => WC()->cart->get_cart_total(),
			) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to add product to cart', 'starter-flavor' ) ) );
		}
	}

	/**
	 * AJAX product image zoom
	 *
	 * @since 1.0.0
	 */
	public static function ajax_product_image_zoom() {
		check_ajax_referer( 'sf-woo-enhancements', 'nonce' );

		if ( ! isset( $_POST['product_id'] ) ) {
			wp_send_json_error( array( 'message' => 'No product ID provided' ) );
		}

		$product_id = intval( $_POST['product_id'] );
		$image_id = isset( $_POST['image_id'] ) ? intval( $_POST['image_id'] ) : null;

		$product = wc_get_product( $product_id );

		if ( ! $product ) {
			wp_send_json_error( array( 'message' => 'Product not found' ) );
		}

		if ( $image_id ) {
			$image_url = wp_get_attachment_image_src( $image_id, 'large' );
		} else {
			$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $product_id ), 'large' );
		}

		if ( $image_url ) {
			wp_send_json_success( array( 'image_url' => $image_url[0] ) );
		} else {
			wp_send_json_error( array( 'message' => 'Image not found' ) );
		}
	}

	/**
	 * Render product badges (Sale, New, Out of Stock)
	 *
	 * @since 1.0.0
	 */
	public static function render_product_badges() {
		global $product;

		if ( ! $product ) {
			return;
		}

		$badges = array();

		// Sale badge
		if ( $product->is_on_sale() ) {
			if ( $product->get_type() !== 'variable' ) {
				$regular_price = (float) $product->get_regular_price();
				$sale_price = (float) $product->get_sale_price();

				if ( $regular_price > 0 ) {
					$discount = round( ( ( $regular_price - $sale_price ) / $regular_price ) * 100 );
					$badges[] = sprintf(
						'<span class="sf-product-badge sf-badge-sale" title="%s">-%d%%</span>',
						esc_attr__( 'Sale', 'starter-flavor' ),
						intval( $discount )
					);
				} else {
					$badges[] = sprintf(
						'<span class="sf-product-badge sf-badge-sale">%s</span>',
						esc_html__( 'Sale', 'starter-flavor' )
					);
				}
			}
		}

		// New badge (products created in last 14 days by default)
		$days = intval( starter_flavor_get_theme_option( 'woo_new_badge_days', 14 ) );
		$created = strtotime( $product->get_date_created() );
		$now = current_time( 'timestamp' );

		if ( ( $now - $created ) < ( $days * 24 * 60 * 60 ) ) {
			$badges[] = sprintf(
				'<span class="sf-product-badge sf-badge-new">%s</span>',
				esc_html__( 'New', 'starter-flavor' )
			);
		}

		// Out of stock badge
		if ( ! $product->is_in_stock() ) {
			$badges[] = sprintf(
				'<span class="sf-product-badge sf-badge-stock">%s</span>',
				esc_html__( 'Out of Stock', 'starter-flavor' )
			);
		}

		if ( ! empty( $badges ) ) {
			echo '<div class="sf-product-badges">' . implode( '', $badges ) . '</div>';
		}
	}

	/**
	 * Render badges on single product page
	 *
	 * @since 1.0.0
	 */
	public static function render_single_product_badges() {
		echo '<div class="sf-single-product-badges">';
		self::render_product_badges();
		echo '</div>';
	}

	/**
	 * Size guide button
	 *
	 * @since 1.0.0
	 */
	public static function size_guide_button() {
		global $product;

		if ( ! $product ) {
			return;
		}

		// Check if product has size attribute
		if ( ! $product->has_attributes() ) {
			return;
		}

		$attributes = $product->get_attributes();
		$has_size = false;

		foreach ( $attributes as $attribute ) {
			if ( in_array( 'size', array( $attribute->get_name(), 'pa_size' ), true ) ) {
				$has_size = true;
				break;
			}
		}

		if ( ! $has_size ) {
			return;
		}

		?>
		<button type="button" class="button button-secondary sf-size-guide-toggle" data-toggle="sf-size-guide-modal">
			<?php esc_html_e( 'Size Guide', 'starter-flavor' ); ?>
		</button>
		<?php
	}

	/**
	 * Size guide modal
	 *
	 * @since 1.0.0
	 */
	public static function size_guide_modal() {
		if ( ! is_product() ) {
			return;
		}

		?>
		<div id="sf-size-guide-modal" class="sf-modal sf-size-guide-modal" role="dialog" aria-labelledby="sf-sg-title" aria-hidden="true">
			<div class="sf-modal-content">
				<button type="button" class="sf-modal-close" aria-label="<?php esc_attr_e( 'Close modal', 'starter-flavor' ); ?>">
					<span aria-hidden="true">&times;</span>
				</button>
				<div class="sf-modal-body">
					<h2 id="sf-sg-title"><?php esc_html_e( 'Size Guide', 'starter-flavor' ); ?></h2>
					<?php
					// Hook for custom size guide content
					do_action( 'sf_size_guide_content' );

					// Fallback table
					?>
					<table class="sf-size-chart">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Size', 'starter-flavor' ); ?></th>
								<th><?php esc_html_e( 'Chest', 'starter-flavor' ); ?></th>
								<th><?php esc_html_e( 'Waist', 'starter-flavor' ); ?></th>
								<th><?php esc_html_e( 'Length', 'starter-flavor' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>XS</td>
								<td>32-34"</td>
								<td>24-26"</td>
								<td>27"</td>
							</tr>
							<tr>
								<td>S</td>
								<td>34-36"</td>
								<td>26-28"</td>
								<td>28"</td>
							</tr>
							<tr>
								<td>M</td>
								<td>38-40"</td>
								<td>30-32"</td>
								<td>29"</td>
							</tr>
							<tr>
								<td>L</td>
								<td>42-44"</td>
								<td>34-36"</td>
								<td>30"</td>
							</tr>
							<tr>
								<td>XL</td>
								<td>46-48"</td>
								<td>38-40"</td>
								<td>31"</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Cross-sells columns
	 *
	 * @since 1.0.0
	 * @param int $columns Number of columns.
	 * @return int
	 */
	public static function cross_sells_columns( $columns ) {
		return intval( starter_flavor_get_theme_option( 'woo_crosssell_columns', 3 ) );
	}

	/**
	 * Upsells columns
	 *
	 * @since 1.0.0
	 * @param int $columns Number of columns.
	 * @return int
	 */
	public static function upsells_columns( $columns ) {
		return intval( starter_flavor_get_theme_option( 'woo_upsell_columns', 3 ) );
	}

	/**
	 * Wishlist button on archive
	 *
	 * @since 1.0.0
	 */
	public static function wishlist_button() {
		global $product;

		if ( ! $product ) {
			return;
		}

		?>
		<button class="button sf-wishlist-btn" data-product-id="<?php echo intval( $product->get_id() ); ?>" title="<?php esc_attr_e( 'Add to Wishlist', 'starter-flavor' ); ?>" aria-label="<?php esc_attr_e( 'Add to Wishlist', 'starter-flavor' ); ?>">
			<span class="sf-icon-heart">♡</span>
		</button>
		<?php
	}

	/**
	 * Wishlist button on single product
	 *
	 * @since 1.0.0
	 */
	public static function single_product_wishlist_button() {
		global $product;

		if ( ! $product ) {
			return;
		}

		?>
		<button class="button button-secondary sf-wishlist-btn sf-wishlist-single" data-product-id="<?php echo intval( $product->get_id() ); ?>" title="<?php esc_attr_e( 'Add to Wishlist', 'starter-flavor' ); ?>" aria-label="<?php esc_attr_e( 'Add to Wishlist', 'starter-flavor' ); ?>">
			<span class="sf-icon-heart">♡</span>
			<?php esc_html_e( 'Add to Wishlist', 'starter-flavor' ); ?>
		</button>
		<?php
	}

	/**
	 * Mini cart update script after add to cart
	 *
	 * @since 1.0.0
	 */
	public static function mini_cart_update_script() {
		?>
		<script type="text/javascript">
		document.addEventListener('added_to_cart', function() {
			// Update mini cart if it exists
			if (typeof sfWooEnhancements !== 'undefined') {
				jQuery.ajax({
					url: sfWooEnhancements.ajaxUrl,
					type: 'POST',
					data: {
						action: 'sf_update_mini_cart',
						nonce: sfWooEnhancements.nonce
					},
					success: function(response) {
						if (response.success) {
							// Update cart count and contents
							jQuery('.header-cart-widget .cart-count').text(response.data.cart_count);
							if (jQuery('#mini-cart-contents').length) {
								jQuery('#mini-cart-contents').html(response.data.html);
							}
						}
					}
				});
			}
		});
		</script>
		<?php
	}
}

// Initialize
if ( class_exists( 'WooCommerce' ) ) {
	Starter_Flavor_Woo_Enhancements::init();
}
