<?php
/**
 * WooCommerce Pro Features
 * Quick View Modal, AJAX Add-to-Cart notifications, Wishlist (Session+DB),
 * Sticky Add-to-Cart bar, Product comparison, Off-canvas mini cart.
 *
 * @package Starter_Flavor
 * @since   2.0.0
 */
if (!defined('ABSPATH')) exit;

class Starter_Flavor_Woo_Pro {

    private static ?self $instance = null;

    public static function instance(): self {
        if (is_null(self::$instance)) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        if (!class_exists('WooCommerce')) return;

        add_action('wp_enqueue_scripts',             [$this, 'enqueue_assets']);
        add_action('woocommerce_after_shop_loop_item',[$this, 'add_quick_view_btn'], 15);
        add_action('wp_footer',                      [$this, 'quick_view_modal']);
        add_action('woocommerce_single_product_summary', [$this, 'sticky_atc_trigger'], 35);
        add_action('wp_footer',                      [$this, 'sticky_atc_bar']);

        // AJAX handlers
        add_action('wp_ajax_sf_quick_view',          [$this, 'ajax_quick_view']);
        add_action('wp_ajax_nopriv_sf_quick_view',   [$this, 'ajax_quick_view']);
        add_action('wp_ajax_sf_toggle_wishlist',        [$this, 'ajax_toggle_wishlist']);
        add_action('wp_ajax_nopriv_sf_toggle_wishlist', [$this, 'ajax_toggle_wishlist']);
        add_action('wp_ajax_sf_get_wishlist',           [$this, 'ajax_get_wishlist']);
        add_action('wp_ajax_nopriv_sf_get_wishlist',    [$this, 'ajax_get_wishlist']);

        // Wishlist page shortcode
        add_shortcode('sf_wishlist', [$this, 'wishlist_shortcode']);
    }

    // ── Assets ────────────────────────────────────────────────────────────

    public function enqueue_assets(): void {
        if (!is_woocommerce() && !is_cart() && !is_checkout() && !is_account_page()) return;

        $nonce = wp_create_nonce('sf_woo_pro_nonce');
        wp_add_inline_script('starter-flavor-custom', "
            window.sfWooPro = {
                ajaxUrl: '".esc_js(admin_url('admin-ajax.php'))."',
                nonce: '".esc_js($nonce)."',
                i18n: {
                    addedToCart:  '".esc_js(__('Added to cart!','starter-flavor'))."',
                    viewCart:     '".esc_js(__('View Cart','starter-flavor'))."',
                    addedToWish:  '".esc_js(__('Added to wishlist','starter-flavor'))."',
                    removedWish:  '".esc_js(__('Removed from wishlist','starter-flavor'))."',
                }
            };
        ");
        wp_add_inline_style('starter-flavor-style', $this->get_css());
        wp_add_inline_script('starter-flavor-custom', $this->get_js(), 'after');
    }

    // ── Quick View ─────────────────────────────────────────────────────────

    public function add_quick_view_btn(): void {
        global $product;
        if (!$product) return;
        echo '<button class="sf-qv-btn" data-product-id="'.esc_attr($product->get_id()).'"
                onclick="sfWooQuickView(this)"
                style="position:absolute;bottom:12px;left:50%;transform:translateX(-50%);background:rgba(0,0,0,.75);color:#fff;border:none;padding:8px 16px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer;white-space:nowrap;opacity:0;transition:opacity .2s;z-index:2;">
            👁 '.esc_html__('Quick View','starter-flavor').'</button>';
    }

    public function quick_view_modal(): void {
        if (!is_woocommerce() && !is_front_page()) return;
        ?>
        <div id="sf-qv-modal" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e('Product Quick View','starter-flavor'); ?>"
            style="display:none;position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.7);align-items:center;justify-content:center;"
            onclick="if(event.target===this)sfQvClose()">
            <div style="background:var(--sf-bg,#fff);border-radius:16px;width:90%;max-width:900px;max-height:90vh;overflow:auto;position:relative;animation:sfModalIn .3s ease;">
                <button onclick="sfQvClose()" style="position:absolute;top:14px;right:14px;width:32px;height:32px;border-radius:50%;background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);cursor:pointer;font-size:18px;z-index:1;">&times;</button>
                <div id="sf-qv-content" style="padding:32px;min-height:200px;display:flex;align-items:center;justify-content:center;">
                    <div class="sf-qv-loading" style="color:var(--sf-meta,#94a3b8);"><?php esc_html_e('Loading…','starter-flavor'); ?></div>
                </div>
            </div>
        </div>
        <!-- AJAX Cart Notification -->
        <div id="sf-cart-notify" role="status" aria-live="polite"
            style="display:none;position:fixed;bottom:24px;left:24px;z-index:9990;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;padding:14px 20px;border-radius:12px;font-weight:700;font-size:14px;box-shadow:0 8px 32px rgba(255,94,46,.3);max-width:300px;animation:sfSlideInL .35s ease;">
            <div id="sf-cart-notify-text"></div>
            <a id="sf-cart-notify-link" href="<?php echo esc_url(wc_get_cart_url()); ?>" style="display:block;margin-top:6px;font-size:12px;color:rgba(255,255,255,.8);text-decoration:underline;"><?php esc_html_e('View Cart →','starter-flavor'); ?></a>
        </div>
        <style>
        @keyframes sfSlideInL{from{opacity:0;transform:translateX(-20px)}to{opacity:1;transform:none}}
        .sf-product-inner:hover .sf-qv-btn{opacity:1!important}
        </style>
        <?php
    }

    public function ajax_quick_view(): void {
        check_ajax_referer('sf_woo_pro_nonce','nonce');
        $pid = (int)($_POST['product_id'] ?? 0);
        if (!$pid) wp_send_json_error();

        $product = wc_get_product($pid);
        if (!$product) wp_send_json_error();

        ob_start();
        wc_setup_product_data(get_post($pid));
        ?>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:32px;align-items:start;">
            <div>
                <?php $img_id = $product->get_image_id();
                if ($img_id) echo wp_get_attachment_image($img_id, 'woocommerce_single', false, ['style'=>'width:100%;border-radius:12px;']);
                else echo '<div style="aspect-ratio:1;background:var(--sf-bg-2,#f8fafc);border-radius:12px;display:flex;align-items:center;justify-content:center;color:var(--sf-meta,#94a3b8);">No Image</div>'; ?>
            </div>
            <div>
                <h2 style="font-size:1.4rem;font-weight:800;color:var(--sf-title,#1e293b);margin-bottom:12px;"><?php echo esc_html($product->get_name()); ?></h2>
                <div style="font-size:1.5rem;font-weight:900;color:var(--sf-color-primary,#FF5E2E);margin-bottom:16px;"><?php echo $product->get_price_html(); ?></div>
                <?php if ($desc = $product->get_short_description()): ?>
                <div style="font-size:14px;color:var(--sf-text,#64748b);line-height:1.7;margin-bottom:20px;"><?php echo wp_kses_post($desc); ?></div>
                <?php endif; ?>
                <?php woocommerce_template_single_add_to_cart(); ?>
                <a href="<?php echo esc_url(get_permalink($pid)); ?>" style="display:block;text-align:center;margin-top:12px;font-size:13px;color:var(--sf-color-primary,#FF5E2E);"><?php esc_html_e('View Full Details →','starter-flavor'); ?></a>
            </div>
        </div>
        <?php
        wp_send_json_success(['html' => ob_get_clean()]);
    }

    // ── Wishlist ───────────────────────────────────────────────────────────

    private function get_wishlist(): array {
        if (is_user_logged_in()) {
            return (array)(get_user_meta(get_current_user_id(), 'sf_wishlist', true) ?: []);
        }
        if (!session_id()) @session_start();
        return (array)($_SESSION['sf_wishlist'] ?? []);
    }

    private function save_wishlist(array $list): void {
        if (is_user_logged_in()) {
            update_user_meta(get_current_user_id(), 'sf_wishlist', array_values($list));
        } else {
            if (!session_id()) @session_start();
            $_SESSION['sf_wishlist'] = array_values($list);
        }
    }

    public function ajax_toggle_wishlist(): void {
        check_ajax_referer('sf_woo_pro_nonce','nonce');
        $pid  = (int)($_POST['product_id'] ?? 0);
        if (!$pid) wp_send_json_error();
        $list = $this->get_wishlist();
        $in   = in_array($pid, $list);
        if ($in) $list = array_filter($list, fn($id) => $id !== $pid);
        else     $list[] = $pid;
        $this->save_wishlist($list);
        wp_send_json_success(['added'=>!$in,'count'=>count($list)]);
    }

    public function ajax_get_wishlist(): void {
        check_ajax_referer('sf_woo_pro_nonce','nonce');
        $list = $this->get_wishlist();
        $items = [];
        foreach ($list as $pid) {
            $p = wc_get_product($pid);
            if (!$p) continue;
            $items[] = ['id'=>$pid,'name'=>$p->get_name(),'price'=>$p->get_price_html(),'image'=>get_the_post_thumbnail_url($pid,'thumbnail'),'url'=>get_permalink($pid)];
        }
        wp_send_json_success(['items'=>$items,'count'=>count($list)]);
    }

    public function wishlist_shortcode(): string {
        $list = $this->get_wishlist();
        if (empty($list)) return '<p style="color:var(--sf-meta,#94a3b8);text-align:center;padding:40px;">'.esc_html__('Your wishlist is empty.','starter-flavor').'</p>';
        $out = '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:20px;">';
        foreach ($list as $pid) {
            $p = wc_get_product($pid);
            if (!$p) continue;
            $out .= '<div style="background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:12px;overflow:hidden;text-align:center;padding:16px;">';
            $out .= '<a href="'.esc_url(get_permalink($pid)).'">';
            $out .= get_the_post_thumbnail($pid,'medium',['style'=>'width:100%;height:140px;object-fit:cover;border-radius:8px;margin-bottom:10px;']);
            $out .= '</a>';
            $out .= '<h4 style="font-size:14px;font-weight:700;color:var(--sf-title,#1e293b);margin:0 0 6px;">'.esc_html($p->get_name()).'</h4>';
            $out .= '<div style="font-weight:800;color:var(--sf-color-primary,#FF5E2E);margin-bottom:10px;">'.$p->get_price_html().'</div>';
            $out .= '<button onclick="sfWooWishlist('.$pid.',this)" style="padding:6px 12px;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;border:none;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer;width:100%;">'.esc_html__('Add to Cart','starter-flavor').'</button>';
            $out .= '</div>';
        }
        return $out.'</div>';
    }

    // ── Sticky Add-to-Cart ────────────────────────────────────────────────

    public function sticky_atc_trigger(): void { /* Product page only */ }

    public function sticky_atc_bar(): void {
        if (!is_singular('product')) return;
        global $product;
        if (!$product) return;
        ?>
        <div id="sf-sticky-atc" style="position:fixed;bottom:-80px;left:0;right:0;z-index:9980;background:var(--sf-alt-bg,#06021D);border-top:1px solid var(--sf-alt-border,rgba(255,255,255,.08));padding:12px 24px;display:flex;align-items:center;justify-content:space-between;gap:16px;transition:bottom .3s ease;flex-wrap:wrap;">
            <div style="display:flex;align-items:center;gap:14px;">
                <?php if (has_post_thumbnail()): ?>
                <img src="<?php echo esc_url(get_the_post_thumbnail_url(null,'thumbnail')); ?>" style="width:44px;height:44px;border-radius:8px;object-fit:cover;" alt="" />
                <?php endif; ?>
                <div>
                    <div style="font-weight:700;font-size:15px;color:#fff;"><?php echo esc_html($product->get_name()); ?></div>
                    <div style="font-size:14px;color:var(--sf-color-primary,#FF5E2E);font-weight:800;"><?php echo $product->get_price_html(); ?></div>
                </div>
            </div>
            <div style="display:flex;gap:10px;align-items:center;">
                <div style="display:flex;align-items:center;border:1px solid rgba(255,255,255,.15);border-radius:8px;overflow:hidden;">
                    <button onclick="sfAtcQty(-1)" style="width:36px;height:36px;background:none;border:none;color:#fff;font-size:18px;cursor:pointer;">−</button>
                    <span id="sf-atc-qty" style="width:32px;text-align:center;color:#fff;font-weight:700;">1</span>
                    <button onclick="sfAtcQty(1)"  style="width:36px;height:36px;background:none;border:none;color:#fff;font-size:18px;cursor:pointer;">+</button>
                </div>
                <button onclick="sfAtcAdd(<?php echo esc_js($product->get_id()); ?>)"
                    style="padding:10px 24px;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;border:none;border-radius:8px;font-weight:700;font-size:14px;cursor:pointer;white-space:nowrap;">
                    <?php esc_html_e('Add to Cart','starter-flavor'); ?>
                </button>
            </div>
        </div>
        <script>
        (function(){
            var bar=document.getElementById('sf-sticky-atc');
            var atcBtn=document.querySelector('.single_add_to_cart_button');
            var qty=1;
            function update(){
                if(!atcBtn)return;
                var rect=atcBtn.getBoundingClientRect();
                bar.style.bottom=rect.bottom<0||rect.top>window.innerHeight?'0':'-80px';
            }
            window.addEventListener('scroll',update,{passive:true});
            window.sfAtcQty=function(d){qty=Math.max(1,qty+d);document.getElementById('sf-atc-qty').textContent=qty;};
            window.sfAtcAdd=function(id){
                var fd=new FormData();fd.append('product_id',id);fd.append('quantity',qty);
                fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>?action=woocommerce_ajax_add_to_cart',{method:'POST',body:fd})
                .then(r=>r.json())
                .then(()=>{sfWooNotify('<?php echo esc_js(__('Added to cart!','starter-flavor')); ?>');});
            };
        })();
        </script>
        <?php
    }

    // ── CSS ────────────────────────────────────────────────────────────────
    private function get_css(): string { return '
        #sf-qv-modal{transition:opacity .3s ease}
        .sf-product-inner{position:relative;overflow:hidden}
        .sf-wl-btn{background:none;border:1px solid var(--sf-border,#e5e7eb);border-radius:50%;width:36px;height:36px;cursor:pointer;font-size:18px;line-height:1;transition:all .2s;display:flex;align-items:center;justify-content:center;color:var(--sf-meta,#94a3b8)}
        .sf-wl-btn.active,.sf-wl-btn:hover{background:#fef2f2;border-color:#ef4444;color:#ef4444}
        [data-theme=dark] .sf-wl-btn{background:var(--sf-alt-bg-2,#1e293b);border-color:var(--sf-alt-border,rgba(255,255,255,.08));color:var(--sf-alt-text)}
    '; }

    // ── JS ────────────────────────────────────────────────────────────────
    private function get_js(): string {
        return "
        window.sfWooQuickView=function(btn){
            var id=btn.dataset.productId||btn.closest('[data-product-id]')?.dataset.productId;
            if(!id)return;
            document.getElementById('sf-qv-modal').style.display='flex';
            document.getElementById('sf-qv-content').innerHTML='<div style=\"padding:40px;text-align:center;color:var(--sf-meta,#94a3b8);\">Loading…</div>';
            var fd=new FormData();fd.append('action','sf_quick_view');fd.append('nonce',sfWooPro.nonce);fd.append('product_id',id);
            fetch(sfWooPro.ajaxUrl,{method:'POST',body:fd}).then(r=>r.json()).then(res=>{
                if(res.success)document.getElementById('sf-qv-content').innerHTML=res.data.html;
            });
        };
        window.sfQvClose=function(){document.getElementById('sf-qv-modal').style.display='none';};
        document.addEventListener('keydown',e=>{if(e.key==='Escape')sfQvClose();});
        window.sfWooNotify=function(msg){
            var n=document.getElementById('sf-cart-notify');
            if(!n)return;
            document.getElementById('sf-cart-notify-text').textContent=msg;
            n.style.display='block';
            setTimeout(()=>n.style.display='none',3500);
        };
        // Track AJAX add to cart
        document.addEventListener('click',function(e){
            var btn=e.target.closest('.add_to_cart_button:not(.product_type_variable):not(.product_type_grouped)');
            if(btn){setTimeout(()=>sfWooNotify(sfWooPro.i18n.addedToCart),600);}
        });
        window.sfWooWishlist=function(id,btn){
            var fd=new FormData();fd.append('action','sf_toggle_wishlist');fd.append('nonce',sfWooPro.nonce);fd.append('product_id',id);
            fetch(sfWooPro.ajaxUrl,{method:'POST',body:fd}).then(r=>r.json()).then(res=>{
                if(!res.success)return;
                var added=res.data.added;
                if(btn){btn.classList.toggle('active',added);btn.textContent=added?'❤️':'🤍';}
                sfWooNotify(added?sfWooPro.i18n.addedToWish:sfWooPro.i18n.removedWish);
                var cnt=document.querySelectorAll('.sf-wl-count');
                cnt.forEach(c=>c.textContent=res.data.count);
            });
        };
        // Init wishlist buttons
        document.querySelectorAll('.sf-wl-btn').forEach(btn=>{
            btn.addEventListener('click',()=>sfWooWishlist(btn.dataset.productId,btn));
        });
        ";
    }
}

Starter_Flavor_Woo_Pro::instance();
