<?php
/**
 * Announcement Bar Widget
 * @package Starter_Flavor
 */
if (!defined('ABSPATH')) exit;

class Starter_Flavor_Announcement_Bar_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'announcement_bar'; }
    public function get_title() { return esc_html__('Announcement Bar','starter-flavor'); }
    public function get_icon()  { return 'eicon-banner'; }
    public function get_categories() { return ['starter-flavor']; }
    public function get_keywords()   { return ['announcement','bar','banner','top','notification','promo']; }

    protected function register_controls() {
        $this->start_controls_section('s1',['label'=>'Content']);
        $this->add_control('text',['label'=>'Message','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>'🔥 Limited Time Offer: Get 30% off with code LAUNCH30']);
        $this->add_control('cta_text',['label'=>'CTA Text','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Shop Now →']);
        $this->add_control('cta_url',['label'=>'CTA URL','type'=>\Elementor\Controls_Manager::URL]);
        $this->add_control('dismissible',['label'=>'Dismissible','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes']);
        $this->add_control('position',['label'=>'Position','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['top'=>'Top','bottom'=>'Bottom'],'default'=>'top']);
        $this->add_control('bg_color',['label'=>'Background','type'=>\Elementor\Controls_Manager::COLOR,'selectors'=>['body .sf-ann-bar'=>'background:{{VALUE}};']]);
        $this->add_control('text_color',['label'=>'Text Color','type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#fff','selectors'=>['body .sf-ann-bar'=>'color:{{VALUE}};']]);
        $this->end_controls_section();
    }

    protected function render() {
        $s=\$this->get_settings_for_display();
        $pos=\$s['position']??'top';$cta=!empty(\$s['cta_url']['url'])?esc_url(\$s['cta_url']['url']):'';
        $dis='yes'===\$s['dismissible'];
        ?>
        <div class="sf-ann-bar" id="sf-ann-bar" style="position:fixed;<?php echo\$pos;?>:0;left:0;right:0;z-index:9999;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;padding:10px 48px 10px 24px;text-align:center;font-size:14px;font-weight:500;display:flex;align-items:center;justify-content:center;gap:16px;">
            <span><?php echo wp_kses_post(\$s['text']);?></span>
            <?php if(\$cta&&\$s['cta_text']):?><a href="<?php echo\$cta;?>" style="font-weight:700;color:inherit;text-decoration:underline;"><?php echo esc_html(\$s['cta_text']);?></a><?php endif;?>
            <?php if(\$dis):?><button onclick="document.getElementById('sf-ann-bar').remove();document.body.style.paddingTop=''" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:inherit;font-size:20px;cursor:pointer;line-height:1;">&times;</button><?php endif;?>
        </div>
        <script>document.body.style.padding<?php echo ucfirst(\$pos);?>=(document.getElementById('sf-ann-bar')?.offsetHeight||40)+'px';</script>
        <?php
    }
}
