<?php
/**
 * Category Grid Widget for Elementor
 * Display WP categories with thumbnails in a responsive grid.
 *
 * @package Starter_Flavor
 * @since 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Starter_Flavor_Category_Grid_Widget extends \Elementor\Widget_Base {

    public function get_name()       { return 'sf_category_grid'; }
    public function get_title()      { return esc_html__( 'Category Grid', 'starter-flavor' ); }
    public function get_icon()       { return 'eicon-gallery-grid'; }
    public function get_categories() { return array( 'starter-flavor' ); }
    public function get_keywords()   { return array( 'category','categories','grid','taxonomy','blog' ); }

    protected function register_controls() {
        $this->start_controls_section('content', array('label'=>esc_html__('Categories','starter-flavor'),'tab'=>\Elementor\Controls_Manager::TAB_CONTENT));
        $this->add_responsive_control('columns', array('label'=>esc_html__('Columns','starter-flavor'),'type'=>\Elementor\Controls_Manager::SELECT,'default'=>'4','tablet_default'=>'3','mobile_default'=>'2','options'=>array('2'=>'2','3'=>'3','4'=>'4','5'=>'5','6'=>'6')));
        $this->add_control('hide_empty', array('label'=>esc_html__('Hide Empty','starter-flavor'),'type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes'));
        $this->add_control('show_count', array('label'=>esc_html__('Show Post Count','starter-flavor'),'type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes'));
        $this->add_control('style', array('label'=>esc_html__('Card Style','starter-flavor'),'type'=>\Elementor\Controls_Manager::SELECT,'default'=>'overlay','options'=>array('overlay'=>esc_html__('Image Overlay','starter-flavor'),'box'=>esc_html__('Icon + Title Box','starter-flavor'),'minimal'=>esc_html__('Minimal','starter-flavor'))));
        $this->add_responsive_control('card_height', array('label'=>esc_html__('Card Height','starter-flavor'),'type'=>\Elementor\Controls_Manager::SLIDER,'size_units'=>array('px'),'range'=>array('px'=>array('min'=>100,'max'=>400)),'default'=>array('unit'=>'px','size'=>180),'selectors'=>array('{{WRAPPER}} .sf-cg-card'=>'height:{{SIZE}}{{UNIT}};')));
        $this->add_control('card_radius', array('label'=>esc_html__('Radius','starter-flavor'),'type'=>\Elementor\Controls_Manager::SLIDER,'size_units'=>array('px'),'default'=>array('unit'=>'px','size'=>12),'selectors'=>array('{{WRAPPER}} .sf-cg-card'=>'border-radius:{{SIZE}}{{UNIT}};')));
        $this->end_controls_section();
    }

    protected function render() {
        $s    = $this->get_settings_for_display();
        $cats = get_categories( array( 'hide_empty' => 'yes' === ($s['hide_empty']??'yes') ) );
        $cols = absint($s['columns']) ?: 4;
        $style= in_array($s['style']??'overlay', array('overlay','box','minimal'), true) ? $s['style'] : 'overlay';
        ?>
        <div class="sf-cat-grid sf-cg-cols-<?php echo esc_attr($cols); ?> sf-cg-style-<?php echo esc_attr($style); ?>">
            <?php foreach ($cats as $cat) :
                $thumb_id = get_term_meta($cat->term_id, 'thumbnail_id', true);
                $img_url  = $thumb_id ? wp_get_attachment_image_url($thumb_id, 'large') : '';
                $link     = get_category_link($cat->term_id);
            ?>
            <a href="<?php echo esc_url($link); ?>" class="sf-cg-card">
                <?php if ($img_url) : ?>
                <img src="<?php echo esc_url($img_url); ?>" alt="<?php echo esc_attr($cat->name); ?>" loading="lazy" class="sf-cg-img">
                <?php else: ?>
                <div class="sf-cg-placeholder"><i class="fa-solid fa-folder-open" aria-hidden="true"></i></div>
                <?php endif; ?>
                <div class="sf-cg-overlay">
                    <span class="sf-cg-name"><?php echo esc_html($cat->name); ?></span>
                    <?php if ('yes' === ($s['show_count']??'yes')): ?>
                    <span class="sf-cg-count"><?php echo esc_html($cat->count); ?> <?php esc_html_e('posts','starter-flavor'); ?></span>
                    <?php endif; ?>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
        <style>
        .sf-cat-grid{display:grid;gap:16px;}
        .sf-cg-cols-2{grid-template-columns:repeat(2,1fr);}
        .sf-cg-cols-3{grid-template-columns:repeat(3,1fr);}
        .sf-cg-cols-4{grid-template-columns:repeat(4,1fr);}
        .sf-cg-cols-5{grid-template-columns:repeat(5,1fr);}
        .sf-cg-cols-6{grid-template-columns:repeat(6,1fr);}
        .sf-cg-card{position:relative;overflow:hidden;display:block;text-decoration:none;background:#e2e8f0;transition:transform .3s ease;}
        .sf-cg-card:hover{transform:scale(1.03);}
        .sf-cg-img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;transition:transform .4s ease;}
        .sf-cg-card:hover .sf-cg-img{transform:scale(1.08);}
        .sf-cg-placeholder{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,var(--sf-primary,#2563eb),var(--sf-accent,#7c3aed));color:#fff;font-size:2rem;}
        .sf-cg-overlay{position:absolute;bottom:0;left:0;right:0;padding:16px;background:linear-gradient(to top,rgba(0,0,0,.7),transparent);}
        .sf-cg-name{display:block;color:#fff;font-weight:700;font-size:1rem;}
        .sf-cg-count{color:rgba(255,255,255,.75);font-size:.8rem;}
        .sf-cg-style-minimal .sf-cg-overlay{position:static;background:none;padding:10px 4px;}
        .sf-cg-style-minimal .sf-cg-name,.sf-cg-style-minimal .sf-cg-count{color:inherit;}
        @media(max-width:768px){.sf-cg-cols-4,.sf-cg-cols-5,.sf-cg-cols-6{grid-template-columns:repeat(3,1fr);}}
        @media(max-width:480px){.sf-cat-grid{grid-template-columns:repeat(2,1fr)!important;}}
        </style>
        <?php
    }
}
