<?php
/**
 * Changelog / Release Notes Widget
 * @package Starter_Flavor
 */
if (!defined('ABSPATH')) exit;

class Starter_Flavor_Changelog_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'changelog'; }
    public function get_title() { return esc_html__('Changelog / Release Notes','starter-flavor'); }
    public function get_icon()  { return 'eicon-document-file'; }
    public function get_categories() { return ['starter-flavor']; }
    public function get_keywords()   { return ['changelog','release','notes','version','history','updates']; }

    protected function register_controls() {
        $this->start_controls_section('s1',['label'=>'Releases']);
        $repeater=new \Elementor\Repeater();
        $repeater->add_control('version',['label'=>'Version','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'v2.0.0']);
        $repeater->add_control('date',['label'=>'Date','type'=>\Elementor\Controls_Manager::DATE_TIME,'default'=>'2026-04-15']);
        $repeater->add_control('type',['label'=>'Type','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['major'=>'Major','minor'=>'Minor','patch'=>'Patch','hotfix'=>'Hotfix'],'default'=>'minor']);
        $repeater->add_control('changes',['label'=>'Changes (one per line, prefix with + / - / *)','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>"+ Added 5 new Elementor widgets\n+ Dark mode improvements\n* Fixed WooCommerce cart styles"]);
        $this->add_control('releases',['type'=>\Elementor\Controls_Manager::REPEATER,'fields'=>\$repeater->get_controls(),'default'=>[
            ['version'=>'v2.0.0','type'=>'major','changes'=>"+ 50 Elementor widgets\n+ 10 professional skins\n+ Dark mode built-in"],
            ['version'=>'v1.5.0','type'=>'minor','changes'=>"+ WooCommerce full integration\n* Performance improvements"],
        ],'title_field'=>'{{{ version }}}']);
        $this->end_controls_section();
    }

    protected function render() {
        $s=\$this->get_settings_for_display();
        $type_colors=['major'=>['bg'=>'rgba(239,68,68,.1)','c'=>'#ef4444'],'minor'=>['bg'=>'rgba(59,130,246,.1)','c'=>'#3b82f6'],'patch'=>['bg'=>'rgba(16,185,129,.1)','c'=>'#10b981'],'hotfix'=>['bg'=>'rgba(245,158,11,.1)','c'=>'#f59e0b']];
        ?>
        <div class="sf-changelog">
        <?php foreach(\$s['releases'] as \$rel):
            \$tc=\$type_colors[\$rel['type']??'minor'];
            \$lines=array_filter(array_map('trim',explode("\n",\$rel['changes']??'')));
        ?>
        <div style="display:grid;grid-template-columns:120px 1fr;gap:24px;margin-bottom:32px;padding-bottom:32px;border-bottom:1px solid var(--sf-border,#e5e7eb);">
            <div>
                <div style="font-family:'Inter Tight',sans-serif;font-size:18px;font-weight:800;color:var(--sf-color-primary,#FF5E2E);"><?php echo esc_html(\$rel['version']);?></div>
                <div style="font-size:11px;color:var(--sf-meta,#94a3b8);margin:4px 0;"><?php echo esc_html(substr(\$rel['date']??'',0,10));?></div>
                <span style="font-size:10px;font-weight:700;text-transform:uppercase;padding:2px 8px;border-radius:4px;background:<?php echo\$tc['bg'];?>;color:<?php echo\$tc['c'];?>"><?php echo esc_html(strtoupper(\$rel['type']??''));?></span>
            </div>
            <ul style="list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:8px;">
            <?php foreach(\$lines as \$line):
                \$icon=\$color=\$text='';
                if(str_starts_with(\$line,'+')){  \$icon='✓';\$color='#10b981';\$text=ltrim(substr(\$line,1));}
                elseif(str_starts_with(\$line,'-')){\$icon='✗';\$color='#ef4444';\$text=ltrim(substr(\$line,1));}
                else{\$icon='●';\$color=\$tc['c'];\$text=ltrim(substr(\$line,1));}
            ?>
            <li style="display:flex;align-items:flex-start;gap:8px;font-size:14px;color:var(--sf-text,#64748b);">
                <span style="color:<?php echo\$color;?>;font-weight:700;flex-shrink:0;margin-top:1px;"><?php echo\$icon;?></span>
                <?php echo esc_html(\$text);?>
            </li>
            <?php endforeach;?>
            </ul>
        </div>
        <?php endforeach;?>
        </div>
        <?php
    }
}
