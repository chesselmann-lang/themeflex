<?php
/**
 * Cookie Consent Banner Widget — DSGVO/GDPR konform.
 * @package Starter_Flavor
 */
if (!defined('ABSPATH')) exit;

class Starter_Flavor_Cookie_Consent_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'sf_cookie_consent'; }
    public function get_title() { return esc_html__('Cookie Consent','starter-flavor'); }
    public function get_icon()  { return 'eicon-shield'; }
    public function get_categories() { return ['starter-flavor']; }
    public function get_keywords()   { return ['cookie','gdpr','dsgvo','consent','privacy','banner']; }

    protected function register_controls() {
        $this->start_controls_section('s_content',['label'=>'Content']);
        $this->add_control('position',['label'=>'Position','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['bottom'=>'Bottom Bar','bottom-right'=>'Bottom Right Popup','top'=>'Top Bar'],'default'=>'bottom']);
        $this->add_control('text',['label'=>'Message','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>'🍪 We use cookies to improve your experience. By continuing, you agree to our cookie policy.']);
        $this->add_control('accept_text',['label'=>'Accept Button','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Accept All']);
        $this->add_control('decline_text',['label'=>'Decline Button','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Decline']);
        $this->add_control('settings_text',['label'=>'Settings Link Text','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Cookie Settings']);
        $this->add_control('policy_url',['label'=>'Privacy Policy URL','type'=>\Elementor\Controls_Manager::URL]);
        $this->add_control('cookie_name',['label'=>'Cookie Name (unique)','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'sf_cookie_consent']);
        $this->add_control('cookie_days',['label'=>'Cookie Expires (days)','type'=>\Elementor\Controls_Manager::NUMBER,'default'=>365]);
        $this->end_controls_section();

        $this->start_controls_section('s_style',['label'=>'Style','tab'=>\Elementor\Controls_Manager::TAB_STYLE]);
        $this->add_control('bg_color',['label'=>'Background','type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#1e293b']);
        $this->add_control('text_color',['label'=>'Text Color','type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#e2e8f0']);
        $this->end_controls_section();
    }

    protected function render() {
        $s   = $this->get_settings_for_display();
        $uid = 'sfcc-'.$this->get_id();
        $pos = $s['position'] ?? 'bottom';
        $cn  = sanitize_key($s['cookie_name'] ?? 'sf_cookie_consent');
        $days = (int)($s['cookie_days'] ?? 365);
        $policy_url = !empty($s['policy_url']['url']) ? esc_url($s['policy_url']['url']) : '';
        $bg  = $s['bg_color'] ?? '#1e293b';
        $tc  = $s['text_color'] ?? '#e2e8f0';

        $pos_css = match($pos) {
            'top'          => 'top:0;left:0;right:0;',
            'bottom-right' => 'bottom:24px;right:24px;max-width:360px;border-radius:16px;',
            default        => 'bottom:0;left:0;right:0;',
        };
        $is_popup = 'bottom-right' === $pos;
        ?>
        <div id="<?php echo esc_attr($uid); ?>-trigger" style="display:none"></div>
        <div id="<?php echo esc_attr($uid); ?>" role="dialog" aria-label="<?php esc_attr_e('Cookie Consent','starter-flavor'); ?>"
            style="position:fixed;<?php echo $pos_css; ?>z-index:99990;background:<?php echo esc_attr($bg); ?>;padding:<?php echo $is_popup?'24px':'20px 32px'; ?>;display:none;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;box-shadow:0 -4px 24px rgba(0,0,0,.2);<?php echo $is_popup?'flex-direction:column;align-items:flex-start;':''; ?>">
            <div style="flex:1;min-width:200px;">
                <p style="margin:0;font-size:13px;color:<?php echo esc_attr($tc); ?>;line-height:1.6;">
                    <?php echo wp_kses_post($s['text']); ?>
                    <?php if($policy_url): ?> <a href="<?php echo $policy_url; ?>" style="color:var(--sf-color-primary,#FF5E2E);text-decoration:none;font-weight:600;"><?php echo esc_html($s['settings_text']); ?></a><?php endif; ?>
                </p>
            </div>
            <div style="display:flex;gap:8px;flex-shrink:0;flex-wrap:wrap;">
                <?php if($s['decline_text']): ?>
                <button onclick="sfCcDecline('<?php echo esc_js($uid); ?>','<?php echo esc_js($cn); ?>')"
                    style="padding:8px 16px;border-radius:8px;border:1px solid rgba(255,255,255,.2);background:transparent;color:<?php echo esc_attr($tc); ?>;font-size:13px;font-weight:600;cursor:pointer;font-family:inherit;">
                    <?php echo esc_html($s['decline_text']); ?>
                </button>
                <?php endif; ?>
                <button onclick="sfCcAccept('<?php echo esc_js($uid); ?>','<?php echo esc_js($cn); ?>',<?php echo $days; ?>)"
                    style="padding:8px 20px;border-radius:8px;border:none;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit;">
                    <?php echo esc_html($s['accept_text']); ?>
                </button>
            </div>
        </div>
        <script>
        (function(){
            var uid='<?php echo esc_js($uid); ?>';
            var cn='<?php echo esc_js($cn); ?>';
            function getCookie(n){var v='; '+document.cookie;var p=v.split('; '+n+'=');if(p.length===2)return p.pop().split(';').shift();}
            if(!getCookie(cn)){
                var el=document.getElementById(uid);
                if(el)el.style.display='<?php echo $is_popup?'flex':'flex'; ?>';
            }
        })();
        window.sfCcAccept=function(id,cn,days){
            var d=new Date();d.setTime(d.getTime()+(days*24*60*60*1000));
            document.cookie=cn+'=accepted;expires='+d.toUTCString()+';path=/;SameSite=Lax';
            document.getElementById(id).style.display='none';
        };
        window.sfCcDecline=function(id,cn){
            var d=new Date();d.setTime(d.getTime()+(30*24*60*60*1000));
            document.cookie=cn+'=declined;expires='+d.toUTCString()+';path=/;SameSite=Lax';
            document.getElementById(id).style.display='none';
        };
        </script>
        <?php
    }
}
