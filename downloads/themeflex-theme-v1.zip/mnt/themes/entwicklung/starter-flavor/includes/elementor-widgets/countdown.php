<?php
/**
 * Elementor Countdown Timer Widget
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Countdown Widget Class
 *
 * @since 1.0.0
 */
class Starter_Flavor_Countdown_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'starter_flavor_countdown';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Countdown Timer', 'starter-flavor' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-countdown';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'starter-flavor' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Target Date/Time
		$this->add_control(
			'countdown_date',
			array(
				'label'   => esc_html__( 'Target Date', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::DATE_TIME,
				'default' => gmdate( 'Y-m-d H:i', strtotime( '+30 days' ) ),
			)
		);

		// Display Format
		$this->add_control(
			'countdown_format',
			array(
				'label'   => esc_html__( 'Display Format', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'full',
				'options' => array(
					'full'    => esc_html__( 'Days, Hours, Minutes, Seconds', 'starter-flavor' ),
					'dmy'     => esc_html__( 'Days, Hours, Minutes', 'starter-flavor' ),
					'dhm'     => esc_html__( 'Days, Hours, Minutes', 'starter-flavor' ),
					'hms'     => esc_html__( 'Hours, Minutes, Seconds', 'starter-flavor' ),
				),
			)
		);

		// Layout
		$this->add_control(
			'countdown_layout',
			array(
				'label'   => esc_html__( 'Layout', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'boxed',
				'options' => array(
					'inline' => esc_html__( 'Inline', 'starter-flavor' ),
					'boxed'  => esc_html__( 'Boxed', 'starter-flavor' ),
				),
			)
		);

		// Expired Message
		$this->add_control(
			'expired_message',
			array(
				'label'       => esc_html__( 'Expired Message', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'The countdown has finished!', 'starter-flavor' ),
				'placeholder' => esc_html__( 'Enter message to display when timer expires', 'starter-flavor' ),
			)
		);

		$this->end_controls_section();

		// Style Section - Numbers
		$this->start_controls_section(
			'numbers_style_section',
			array(
				'label' => esc_html__( 'Numbers', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'number_size',
			array(
				'label'   => esc_html__( 'Font Size', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 48,
				),
				'range'   => array(
					'px' => array(
						'min' => 16,
						'max' => 100,
					),
				),
			)
		);

		$this->add_control(
			'number_color',
			array(
				'label'     => esc_html__( 'Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#0066cc',
				'selectors' => array(
					'{{WRAPPER}} .countdown-number' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'number_typography',
				'label'    => esc_html__( 'Typography', 'starter-flavor' ),
				'selector' => '{{WRAPPER}} .countdown-number',
			)
		);

		$this->end_controls_section();

		// Style Section - Labels
		$this->start_controls_section(
			'labels_style_section',
			array(
				'label' => esc_html__( 'Labels', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'label_size',
			array(
				'label'   => esc_html__( 'Font Size', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 14,
				),
				'range'   => array(
					'px' => array(
						'min' => 10,
						'max' => 30,
					),
				),
			)
		);

		$this->add_control(
			'label_color',
			array(
				'label'     => esc_html__( 'Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#666666',
				'selectors' => array(
					'{{WRAPPER}} .countdown-label' => 'color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Box
		$this->start_controls_section(
			'box_style_section',
			array(
				'label' => esc_html__( 'Box Style', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'box_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#f5f5f5',
				'selectors' => array(
					'{{WRAPPER}} .countdown-item.boxed' => 'background-color: {{VALUE}}',
				),
				'condition' => array(
					'countdown_layout' => 'boxed',
				),
			)
		);

		$this->add_control(
			'box_padding',
			array(
				'label'      => esc_html__( 'Padding', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => '15',
					'right'  => '20',
					'bottom' => '15',
					'left'   => '20',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .countdown-item.boxed' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'condition'  => array(
					'countdown_layout' => 'boxed',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'      => 'box_border',
				'label'     => esc_html__( 'Border', 'starter-flavor' ),
				'selector'  => '{{WRAPPER}} .countdown-item.boxed',
				'condition' => array(
					'countdown_layout' => 'boxed',
				),
			)
		);

		$this->add_control(
			'separator_color',
			array(
				'label'     => esc_html__( 'Separator Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#cccccc',
				'selectors' => array(
					'{{WRAPPER}} .countdown-separator' => 'color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$countdown_date = isset( $settings['countdown_date'] ) ? $settings['countdown_date'] : '';
		$countdown_format = isset( $settings['countdown_format'] ) ? $settings['countdown_format'] : 'full';
		$countdown_layout = isset( $settings['countdown_layout'] ) ? $settings['countdown_layout'] : 'boxed';
		$expired_message = isset( $settings['expired_message'] ) ? $settings['expired_message'] : esc_html__( 'The countdown has finished!', 'starter-flavor' );
		$number_size = isset( $settings['number_size']['size'] ) ? intval( $settings['number_size']['size'] ) : 48;
		$label_size = isset( $settings['label_size']['size'] ) ? intval( $settings['label_size']['size'] ) : 14;

		if ( empty( $countdown_date ) ) {
			echo '<p>' . esc_html__( 'Please set a target date for the countdown', 'starter-flavor' ) . '</p>';
			return;
		}

		// Convert date to timestamp
		$target_timestamp = strtotime( $countdown_date );
		if ( ! $target_timestamp ) {
			echo '<p>' . esc_html__( 'Invalid date format', 'starter-flavor' ) . '</p>';
			return;
		}

		// Determine which units to show
		$show_days = true;
		$show_hours = true;
		$show_minutes = true;
		$show_seconds = true;

		switch ( $countdown_format ) {
			case 'dmy':
				$show_seconds = false;
				break;
			case 'dhm':
				$show_seconds = false;
				break;
			case 'hms':
				$show_days = false;
				break;
		}

		$layout_class = 'countdown-' . esc_attr( $countdown_layout );
		$item_class = 'countdown-item ' . esc_attr( $countdown_layout );

		echo '<div class="countdown-wrapper ' . esc_attr( $layout_class ) . '" data-target-date="' . esc_attr( $countdown_date ) . '" data-expired-message="' . esc_attr( $expired_message ) . '" style="--number-size: ' . esc_attr( $number_size ) . 'px; --label-size: ' . esc_attr( $label_size ) . 'px;">';

		if ( $show_days ) {
			echo '<div class="' . esc_attr( $item_class ) . '">';
			echo '<div class="countdown-number" data-unit="days">0</div>';
			echo '<div class="countdown-label">' . esc_html__( 'Days', 'starter-flavor' ) . '</div>';
			echo '</div>';
			if ( $show_hours || $show_minutes || $show_seconds ) {
				echo '<div class="countdown-separator">:</div>';
			}
		}

		if ( $show_hours ) {
			echo '<div class="' . esc_attr( $item_class ) . '">';
			echo '<div class="countdown-number" data-unit="hours">0</div>';
			echo '<div class="countdown-label">' . esc_html__( 'Hours', 'starter-flavor' ) . '</div>';
			echo '</div>';
			if ( $show_minutes || $show_seconds ) {
				echo '<div class="countdown-separator">:</div>';
			}
		}

		if ( $show_minutes ) {
			echo '<div class="' . esc_attr( $item_class ) . '">';
			echo '<div class="countdown-number" data-unit="minutes">0</div>';
			echo '<div class="countdown-label">' . esc_html__( 'Minutes', 'starter-flavor' ) . '</div>';
			echo '</div>';
			if ( $show_seconds ) {
				echo '<div class="countdown-separator">:</div>';
			}
		}

		if ( $show_seconds ) {
			echo '<div class="' . esc_attr( $item_class ) . '">';
			echo '<div class="countdown-number" data-unit="seconds">0</div>';
			echo '<div class="countdown-label">' . esc_html__( 'Seconds', 'starter-flavor' ) . '</div>';
			echo '</div>';
		}

		echo '<div class="countdown-expired" style="display: none;">';
		echo wp_kses_post( $expired_message );
		echo '</div>';

		echo '</div>';
	}
}
