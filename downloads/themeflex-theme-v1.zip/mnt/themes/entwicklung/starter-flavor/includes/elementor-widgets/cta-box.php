<?php
/**
 * Elementor CTA Box Widget
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CTA Box Widget Class
 *
 * @since 1.0.0
 */
class Starter_Flavor_CTA_Box_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'starter_flavor_cta_box';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'CTA Box', 'starter-flavor' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-call-to-action';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'starter-flavor' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Heading
		$this->add_control(
			'heading',
			array(
				'label'       => esc_html__( 'Heading', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Call To Action', 'starter-flavor' ),
				'placeholder' => esc_html__( 'Enter heading', 'starter-flavor' ),
			)
		);

		// Description
		$this->add_control(
			'description',
			array(
				'label'       => esc_html__( 'Description', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'Add your CTA description here', 'starter-flavor' ),
				'placeholder' => esc_html__( 'Enter description', 'starter-flavor' ),
			)
		);

		// Button Text
		$this->add_control(
			'button_text',
			array(
				'label'       => esc_html__( 'Button Text', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Learn More', 'starter-flavor' ),
			)
		);

		// Button URL
		$this->add_control(
			'button_url',
			array(
				'label'       => esc_html__( 'Button URL', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://example.com', 'starter-flavor' ),
				'default'     => array(
					'url' => '',
				),
			)
		);

		// Box Style
		$this->add_control(
			'box_style',
			array(
				'label'   => esc_html__( 'Box Style', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'solid',
				'options' => array(
					'solid'   => esc_html__( 'Solid', 'starter-flavor' ),
					'outline' => esc_html__( 'Outline', 'starter-flavor' ),
					'gradient' => esc_html__( 'Gradient', 'starter-flavor' ),
				),
			)
		);

		// Background Color
		$this->add_control(
			'bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#F3F4F6',
				'selectors' => array(
					'{{WRAPPER}} .cta-box' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();

		// Style Section
		$this->start_controls_section(
			'style_section',
			array(
				'label' => esc_html__( 'Style', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Heading Color
		$this->add_control(
			'heading_color',
			array(
				'label'     => esc_html__( 'Heading Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#1F2937',
				'selectors' => array(
					'{{WRAPPER}} .cta-box__heading' => 'color: {{VALUE}}',
				),
			)
		);

		// Text Color
		$this->add_control(
			'text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#6B7280',
				'selectors' => array(
					'{{WRAPPER}} .cta-box__description' => 'color: {{VALUE}}',
				),
			)
		);

		// Border Radius
		$this->add_control(
			'border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => '8',
					'right'  => '8',
					'bottom' => '8',
					'left'   => '8',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .cta-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$button_url = isset( $settings['button_url']['url'] ) ? $settings['button_url']['url'] : '';

		echo '<div class="cta-box cta-box--' . esc_attr( $settings['box_style'] ) . '">';
		echo '<div class="cta-box__inner">';

		// Heading
		if ( ! empty( $settings['heading'] ) ) {
			printf(
				'<h3 class="cta-box__heading">%s</h3>',
				esc_html( $settings['heading'] )
			);
		}

		// Description
		if ( ! empty( $settings['description'] ) ) {
			printf(
				'<p class="cta-box__description">%s</p>',
				esc_html( $settings['description'] )
			);
		}

		// Button
		if ( ! empty( $settings['button_text'] ) && ! empty( $button_url ) ) {
			printf(
				'<a href="%s" class="button button-primary cta-box__button">%s</a>',
				esc_url( $button_url ),
				esc_html( $settings['button_text'] )
			);
		}

		echo '</div>';
		echo '</div>';
	}
}
