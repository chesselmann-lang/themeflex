<?php
/**
 * Dual Button Widget for Elementor
 * Two side-by-side CTA buttons with individual styling.
 *
 * @package Starter_Flavor
 * @since 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Starter_Flavor_Dual_Button_Widget extends \Elementor\Widget_Base {

    public function get_name()       { return 'sf_dual_button'; }
    public function get_title()      { return esc_html__( 'Dual Button', 'starter-flavor' ); }
    public function get_icon()       { return 'eicon-button'; }
    public function get_categories() { return array( 'starter-flavor' ); }
    public function get_keywords()   { return array( 'button','cta','dual','two buttons' ); }

    protected function register_controls() {

        /* ── PRIMARY ── */
        $this->start_controls_section('primary', array('label'=>esc_html__('Primary Button','starter-flavor'),'tab'=>\Elementor\Controls_Manager::TAB_CONTENT));
        $this->add_control('primary_text', array('label'=>esc_html__('Text','starter-flavor'),'type'=>\Elementor\Controls_Manager::TEXT,'default'=>esc_html__('Get Started','starter-flavor')));
        $this->add_control('primary_link', array('label'=>esc_html__('Link','starter-flavor'),'type'=>\Elementor\Controls_Manager::URL,'default'=>array('url'=>'#')));
        $this->add_control('primary_icon', array('label'=>esc_html__('Icon','starter-flavor'),'type'=>\Elementor\Controls_Manager::ICONS));
        $this->add_control('primary_icon_pos', array('label'=>esc_html__('Icon Position','starter-flavor'),'type'=>\Elementor\Controls_Manager::SELECT,'default'=>'right','options'=>array('left'=>esc_html__('Left','starter-flavor'),'right'=>esc_html__('Right','starter-flavor'))));
        $this->end_controls_section();

        /* ── SECONDARY ── */
        $this->start_controls_section('secondary', array('label'=>esc_html__('Secondary Button','starter-flavor'),'tab'=>\Elementor\Controls_Manager::TAB_CONTENT));
        $this->add_control('secondary_text', array('label'=>esc_html__('Text','starter-flavor'),'type'=>\Elementor\Controls_Manager::TEXT,'default'=>esc_html__('Learn More','starter-flavor')));
        $this->add_control('secondary_link', array('label'=>esc_html__('Link','starter-flavor'),'type'=>\Elementor\Controls_Manager::URL,'default'=>array('url'=>'#')));
        $this->add_control('secondary_icon', array('label'=>esc_html__('Icon','starter-flavor'),'type'=>\Elementor\Controls_Manager::ICONS));
        $this->end_controls_section();

        /* ── LAYOUT ── */
        $this->start_controls_section('layout', array('label'=>esc_html__('Layout','starter-flavor'),'tab'=>\Elementor\Controls_Manager::TAB_CONTENT));
        $this->add_control('align', array('label'=>esc_html__('Alignment','starter-flavor'),'type'=>\Elementor\Controls_Manager::CHOOSE,'options'=>array('flex-start'=>array('title'=>esc_html__('Left','starter-flavor'),'icon'=>'eicon-text-align-left'),'center'=>array('title'=>esc_html__('Center','starter-flavor'),'icon'=>'eicon-text-align-center'),'flex-end'=>array('title'=>esc_html__('Right','starter-flavor'),'icon'=>'eicon-text-align-right')),'default'=>'center','selectors'=>array('{{WRAPPER}} .sf-dual-btn'=>'justify-content:{{VALUE}};')));
        $this->add_responsive_control('gap',array('label'=>esc_html__('Gap','starter-flavor'),'type'=>\Elementor\Controls_Manager::SLIDER,'size_units'=>array('px'),'range'=>array('px'=>array('min'=>0,'max'=>40)),'default'=>array('unit'=>'px','size'=>16),'selectors'=>array('{{WRAPPER}} .sf-dual-btn'=>'gap:{{SIZE}}{{UNIT}};')));
        $this->end_controls_section();

        /* ── STYLE PRIMARY ── */
        $this->start_controls_section('style_primary', array('label'=>esc_html__('Primary Style','starter-flavor'),'tab'=>\Elementor\Controls_Manager::TAB_STYLE));
        $this->add_control('p_bg', array('label'=>esc_html__('Background','starter-flavor'),'type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#2563eb','selectors'=>array('{{WRAPPER}} .sf-db-primary'=>'background:{{VALUE}};')));
        $this->add_control('p_color', array('label'=>esc_html__('Text','starter-flavor'),'type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#ffffff','selectors'=>array('{{WRAPPER}} .sf-db-primary'=>'color:{{VALUE}};')));
        $this->add_control('p_radius', array('label'=>esc_html__('Radius','starter-flavor'),'type'=>\Elementor\Controls_Manager::SLIDER,'size_units'=>array('px'),'default'=>array('unit'=>'px','size'=>10),'selectors'=>array('{{WRAPPER}} .sf-db-primary'=>'border-radius:{{SIZE}}{{UNIT}};')));
        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(), array('name'=>'p_typo','selector'=>'{{WRAPPER}} .sf-db-primary'));
        $this->end_controls_section();

        /* ── STYLE SECONDARY ── */
        $this->start_controls_section('style_secondary', array('label'=>esc_html__('Secondary Style','starter-flavor'),'tab'=>\Elementor\Controls_Manager::TAB_STYLE));
        $this->add_control('s_bg', array('label'=>esc_html__('Background','starter-flavor'),'type'=>\Elementor\Controls_Manager::COLOR,'default'=>'transparent','selectors'=>array('{{WRAPPER}} .sf-db-secondary'=>'background:{{VALUE}};')));
        $this->add_control('s_color', array('label'=>esc_html__('Text','starter-flavor'),'type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#2563eb','selectors'=>array('{{WRAPPER}} .sf-db-secondary'=>'color:{{VALUE}};')));
        $this->add_control('s_border', array('label'=>esc_html__('Border Colour','starter-flavor'),'type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#2563eb','selectors'=>array('{{WRAPPER}} .sf-db-secondary'=>'border-color:{{VALUE}};')));
        $this->add_control('s_radius', array('label'=>esc_html__('Radius','starter-flavor'),'type'=>\Elementor\Controls_Manager::SLIDER,'size_units'=>array('px'),'default'=>array('unit'=>'px','size'=>10),'selectors'=>array('{{WRAPPER}} .sf-db-secondary'=>'border-radius:{{SIZE}}{{UNIT}};')));
        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(), array('name'=>'s_typo','selector'=>'{{WRAPPER}} .sf-db-secondary'));
        $this->end_controls_section();
    }

    private function render_btn($s, $prefix, $class) {
        $text = $s[$prefix.'_text'];
        $link = $s[$prefix.'_link'];
        $url  = !empty($link['url']) ? esc_url($link['url']) : '#';
        $target = !empty($link['is_external']) ? ' target="_blank" rel="noopener noreferrer"' : '';
        $icon   = $s[$prefix.'_icon'] ?? array();
        $pos    = $s[$prefix.'_icon_pos'] ?? 'right';

        echo '<a href="' . $url . '"' . $target . ' class="sf-db-btn ' . esc_attr($class) . '">';
        if (!empty($icon['value']) && 'left' === $pos) { \Elementor\Icons_Manager::render_icon($icon, array('aria-hidden'=>'true')); }
        echo esc_html($text);
        if (!empty($icon['value']) && 'right' === $pos) { \Elementor\Icons_Manager::render_icon($icon, array('aria-hidden'=>'true')); }
        echo '</a>';
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        echo '<div class="sf-dual-btn">';
        $this->render_btn($s, 'primary',   'sf-db-primary');
        $this->render_btn($s, 'secondary', 'sf-db-secondary');
        echo '</div>';
        ?>
        <style>
        .sf-dual-btn{display:flex;flex-wrap:wrap;align-items:center;}
        .sf-db-btn{display:inline-flex;align-items:center;gap:8px;padding:14px 28px;font-weight:600;text-decoration:none;transition:all .25s ease;cursor:pointer;}
        .sf-db-secondary{border:2px solid;}
        .sf-db-primary:hover{opacity:.9;transform:translateY(-2px);}
        .sf-db-secondary:hover{opacity:.85;}
        @media(max-width:480px){.sf-dual-btn{flex-direction:column;align-items:stretch;} .sf-db-btn{justify-content:center;}}
        </style>
        <?php
    }
}
