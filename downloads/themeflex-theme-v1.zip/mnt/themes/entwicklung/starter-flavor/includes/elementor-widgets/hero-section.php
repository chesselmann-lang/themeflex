<?php
/**
 * Elementor Hero Section Widget
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Hero Section Widget Class
 *
 * @since 1.0.0
 */
class Starter_Flavor_Hero_Section_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'starter_flavor_hero_section';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Hero Section', 'starter-flavor' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-image';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'starter-flavor' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Background Image
		$this->add_control(
			'background_image',
			array(
				'label'   => esc_html__( 'Background Image', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => array(
					'url' => '',
				),
			)
		);

		// Title
		$this->add_control(
			'title',
			array(
				'label'       => esc_html__( 'Title', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Your Headline Here', 'starter-flavor' ),
				'placeholder' => esc_html__( 'Enter your title', 'starter-flavor' ),
			)
		);

		// Subtitle
		$this->add_control(
			'subtitle',
			array(
				'label'       => esc_html__( 'Subtitle', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Add your subtitle here', 'starter-flavor' ),
				'placeholder' => esc_html__( 'Enter subtitle', 'starter-flavor' ),
			)
		);

		// Button Text
		$this->add_control(
			'button_text',
			array(
				'label'       => esc_html__( 'Button Text', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Get Started', 'starter-flavor' ),
			)
		);

		// Button URL
		$this->add_control(
			'button_url',
			array(
				'label'       => esc_html__( 'Button URL', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://example.com', 'starter-flavor' ),
				'default'     => array(
					'url' => '',
				),
			)
		);

		// Overlay Opacity
		$this->add_control(
			'overlay_opacity',
			array(
				'label'   => esc_html__( 'Overlay Opacity', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 30,
				),
				'range'   => array(
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Title
		$this->start_controls_section(
			'title_style_section',
			array(
				'label' => esc_html__( 'Title', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'title_color',
			array(
				'label'     => esc_html__( 'Title Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FFFFFF',
				'selectors' => array(
					'{{WRAPPER}} .hero-title' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'title_typography',
				'label'    => esc_html__( 'Typography', 'starter-flavor' ),
				'selector' => '{{WRAPPER}} .hero-title',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$button_url = isset( $settings['button_url']['url'] ) ? $settings['button_url']['url'] : '';
		$overlay_opacity = isset( $settings['overlay_opacity']['size'] ) ? $settings['overlay_opacity']['size'] : 30;

		$bg_image_url = isset( $settings['background_image']['url'] ) ? $settings['background_image']['url'] : '';

		echo '<section class="hero-section"';
		if ( ! empty( $bg_image_url ) ) {
			echo ' style="background-image: url(\'' . esc_url( $bg_image_url ) . '\');"';
		}
		echo '>';

		// Overlay
		printf(
			'<div class="hero-overlay" style="opacity: %f;"></div>',
			esc_attr( $overlay_opacity / 100 )
		);

		// Content
		echo '<div class="hero-content">';
		echo '<div class="hero-content-inner">';

		// Title
		if ( ! empty( $settings['title'] ) ) {
			printf(
				'<h1 class="hero-title">%s</h1>',
				esc_html( $settings['title'] )
			);
		}

		// Subtitle
		if ( ! empty( $settings['subtitle'] ) ) {
			printf(
				'<p class="hero-subtitle">%s</p>',
				esc_html( $settings['subtitle'] )
			);
		}

		// Button
		if ( ! empty( $settings['button_text'] ) && ! empty( $button_url ) ) {
			printf(
				'<a href="%s" class="button button-primary hero-button">%s</a>',
				esc_url( $button_url ),
				esc_html( $settings['button_text'] )
			);
		}

		echo '</div>';
		echo '</div>';
		echo '</section>';
	}
}
