<?php
/**
 * Elementor Icon Box Widget
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Icon Box Widget Class
 *
 * @since 1.0.0
 */
class Starter_Flavor_Icon_Box_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'starter_flavor_icon_box';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Icon Box', 'starter-flavor' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-icon-box';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'starter-flavor' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Icon
		$this->add_control(
			'box_icon',
			array(
				'label'       => esc_html__( 'Icon', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::ICONS,
				'default'     => array(
					'value'   => 'fas fa-lightbulb',
					'library' => 'fa-solid',
				),
			)
		);

		// Title
		$this->add_control(
			'box_title',
			array(
				'label'       => esc_html__( 'Title', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Icon Box Title', 'starter-flavor' ),
				'placeholder' => esc_html__( 'Enter title', 'starter-flavor' ),
			)
		);

		// Description
		$this->add_control(
			'box_description',
			array(
				'label'       => esc_html__( 'Description', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'Add your description text here.', 'starter-flavor' ),
				'placeholder' => esc_html__( 'Enter description', 'starter-flavor' ),
			)
		);

		// Link
		$this->add_control(
			'box_link',
			array(
				'label'       => esc_html__( 'Link', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://example.com', 'starter-flavor' ),
				'default'     => array(
					'url' => '',
				),
			)
		);

		$this->end_controls_section();

		// Layout Section
		$this->start_controls_section(
			'layout_section',
			array(
				'label' => esc_html__( 'Layout', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Icon Position
		$this->add_control(
			'icon_position',
			array(
				'label'   => esc_html__( 'Icon Position', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'top',
				'options' => array(
					'top'   => esc_html__( 'Icon Top (Centered)', 'starter-flavor' ),
					'left'  => esc_html__( 'Icon Left', 'starter-flavor' ),
					'right' => esc_html__( 'Icon Right', 'starter-flavor' ),
				),
			)
		);

		// Icon Container Style
		$this->add_control(
			'icon_container_style',
			array(
				'label'   => esc_html__( 'Icon Container', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'circle',
				'options' => array(
					'circle' => esc_html__( 'Circle', 'starter-flavor' ),
					'square' => esc_html__( 'Square', 'starter-flavor' ),
					'none'   => esc_html__( 'None', 'starter-flavor' ),
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Icon
		$this->start_controls_section(
			'icon_style_section',
			array(
				'label' => esc_html__( 'Icon', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Icon Color
		$this->add_control(
			'icon_color',
			array(
				'label'     => esc_html__( 'Icon Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FFFFFF',
				'selectors' => array(
					'{{WRAPPER}} .icon-box-icon' => 'color: {{VALUE}}',
				),
			)
		);

		// Icon Background Color
		$this->add_control(
			'icon_bg_color',
			array(
				'label'     => esc_html__( 'Icon Background Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FF5E2E',
				'selectors' => array(
					'{{WRAPPER}} .icon-box-icon-wrapper' => 'background-color: {{VALUE}}',
				),
			)
		);

		// Icon Size
		$this->add_control(
			'icon_size',
			array(
				'label'      => esc_html__( 'Icon Size', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 16,
						'max' => 100,
					),
				),
				'default'    => array(
					'size' => 40,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .icon-box-icon' => 'font-size: {{SIZE}}{{UNIT}}',
				),
			)
		);

		// Icon Container Size
		$this->add_control(
			'icon_container_size',
			array(
				'label'      => esc_html__( 'Icon Container Size', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 40,
						'max' => 150,
					),
				),
				'default'    => array(
					'size' => 80,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .icon-box-icon-wrapper' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		// Hover Icon Color
		$this->add_control(
			'icon_hover_color',
			array(
				'label'     => esc_html__( 'Hover Icon Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FFFFFF',
				'selectors' => array(
					'{{WRAPPER}} .icon-box:hover .icon-box-icon' => 'color: {{VALUE}}',
				),
			)
		);

		// Hover Background Color
		$this->add_control(
			'icon_hover_bg_color',
			array(
				'label'     => esc_html__( 'Hover Background Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#D14524',
				'selectors' => array(
					'{{WRAPPER}} .icon-box:hover .icon-box-icon-wrapper' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Box
		$this->start_controls_section(
			'box_style_section',
			array(
				'label' => esc_html__( 'Box', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Box Background
		$this->add_control(
			'box_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FFFFFF',
				'selectors' => array(
					'{{WRAPPER}} .icon-box' => 'background-color: {{VALUE}}',
				),
			)
		);

		// Box Border
		$this->add_control(
			'box_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#E5E7EB',
				'selectors' => array(
					'{{WRAPPER}} .icon-box' => 'border-color: {{VALUE}}',
				),
			)
		);

		// Hover Border Color
		$this->add_control(
			'box_hover_border_color',
			array(
				'label'     => esc_html__( 'Hover Border Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FF5E2E',
				'selectors' => array(
					'{{WRAPPER}} .icon-box:hover' => 'border-color: {{VALUE}}',
				),
			)
		);

		// Box Border Radius
		$this->add_control(
			'box_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => '8',
					'right'  => '8',
					'bottom' => '8',
					'left'   => '8',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .icon-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				),
			)
		);

		// Box Padding
		$this->add_control(
			'box_padding',
			array(
				'label'      => esc_html__( 'Padding', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => '30',
					'right'  => '20',
					'bottom' => '30',
					'left'   => '20',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .icon-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Typography
		$this->start_controls_section(
			'typography_style_section',
			array(
				'label' => esc_html__( 'Typography', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Title Color
		$this->add_control(
			'title_color',
			array(
				'label'     => esc_html__( 'Title Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#1F2937',
				'selectors' => array(
					'{{WRAPPER}} .icon-box-title' => 'color: {{VALUE}}',
				),
			)
		);

		// Description Color
		$this->add_control(
			'description_color',
			array(
				'label'     => esc_html__( 'Description Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#6B7280',
				'selectors' => array(
					'{{WRAPPER}} .icon-box-description' => 'color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$icon_position = isset( $settings['icon_position'] ) ? $settings['icon_position'] : 'top';
		$icon_container_style = isset( $settings['icon_container_style'] ) ? $settings['icon_container_style'] : 'circle';
		$link_url = isset( $settings['box_link']['url'] ) ? $settings['box_link']['url'] : '';

		$wrapper_class = 'icon-box icon-box--' . esc_attr( $icon_position );
		echo '<div class="' . esc_attr( $wrapper_class ) . '">';

		// Icon
		if ( ! empty( $settings['box_icon'] ) ) {
			$icon_wrapper_class = 'icon-box-icon-wrapper icon-box-icon-wrapper--' . esc_attr( $icon_container_style );
			echo '<div class="' . esc_attr( $icon_wrapper_class ) . '">';
			\Elementor\Icons_Manager::render_icon(
				$settings['box_icon'],
				array( 'aria-hidden' => 'true', 'class' => 'icon-box-icon' )
			);
			echo '</div>';
		}

		// Content
		echo '<div class="icon-box-content">';

		// Title
		if ( ! empty( $settings['box_title'] ) ) {
			if ( ! empty( $link_url ) ) {
				printf(
					'<a href="%s" class="icon-box-title-link"><h3 class="icon-box-title">%s</h3></a>',
					esc_url( $link_url ),
					esc_html( $settings['box_title'] )
				);
			} else {
				printf(
					'<h3 class="icon-box-title">%s</h3>',
					esc_html( $settings['box_title'] )
				);
			}
		}

		// Description
		if ( ! empty( $settings['box_description'] ) ) {
			printf(
				'<p class="icon-box-description">%s</p>',
				esc_html( $settings['box_description'] )
			);
		}

		echo '</div>';
		echo '</div>';

		// Inline Styles
		?>
		<style>
			.icon-box {
				display: flex;
				gap: 20px;
				align-items: flex-start;
				border: 1px solid #E5E7EB;
				transition: all 0.3s ease;
			}

			.icon-box--top {
				flex-direction: column;
				align-items: center;
				text-align: center;
			}

			.icon-box--left {
				flex-direction: row;
				align-items: flex-start;
			}

			.icon-box--right {
				flex-direction: row-reverse;
				align-items: flex-start;
			}

			.icon-box-icon-wrapper {
				display: flex;
				align-items: center;
				justify-content: center;
				flex-shrink: 0;
				transition: all 0.3s ease;
			}

			.icon-box-icon-wrapper--circle {
				border-radius: 50%;
			}

			.icon-box-icon-wrapper--square {
				border-radius: 4px;
			}

			.icon-box-icon-wrapper--none {
				background-color: transparent !important;
			}

			.icon-box--top .icon-box-icon-wrapper {
				margin-bottom: 10px;
			}

			.icon-box-content {
				flex: 1;
			}

			.icon-box-title {
				margin: 0 0 10px 0;
				font-size: 18px;
				font-weight: 600;
			}

			.icon-box-title-link {
				text-decoration: none;
			}

			.icon-box-title-link:hover .icon-box-title {
				opacity: 0.8;
			}

			.icon-box-description {
				margin: 0;
				line-height: 1.6;
			}
		</style>
		<?php
	}
}
