<?php
/**
 * Icon List Widget
 * Mehrere Zeilen mit individuellen Icons, Links und Farben.
 *
 * @package Starter_Flavor
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class Starter_Flavor_Icon_List_Widget extends \Elementor\Widget_Base {

	public function get_name()  { return 'sf_icon_list'; }
	public function get_title() { return esc_html__( 'Icon List', 'starter-flavor' ); }
	public function get_icon()  { return 'eicon-icon-box'; }
	public function get_categories() { return [ 'starter-flavor' ]; }
	public function get_keywords()   { return [ 'icon', 'list', 'feature', 'check', 'bullet' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'section_items', [ 'label' => esc_html__( 'Items', 'starter-flavor' ) ] );

		$repeater = new \Elementor\Repeater();
		$repeater->add_control( 'item_icon',  [ 'label' => 'Icon', 'type' => \Elementor\Controls_Manager::ICONS, 'default' => [ 'value' => 'fas fa-check-circle', 'library' => 'fa-solid' ] ] );
		$repeater->add_control( 'item_text',  [ 'label' => 'Text', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'List item text' ] );
		$repeater->add_control( 'item_link',  [ 'label' => 'Link', 'type' => \Elementor\Controls_Manager::URL ] );
		$repeater->add_control( 'icon_color', [ 'label' => 'Icon Color', 'type' => \Elementor\Controls_Manager::COLOR ] );

		$this->add_control( 'items', [
			'type'        => \Elementor\Controls_Manager::REPEATER,
			'fields'      => $repeater->get_controls(),
			'default'     => [
				[ 'item_text' => 'Free lifetime updates',     'item_icon' => [ 'value' => 'fas fa-check-circle' ] ],
				[ 'item_text' => 'Priority email support',    'item_icon' => [ 'value' => 'fas fa-check-circle' ] ],
				[ 'item_text' => 'Unlimited projects',        'item_icon' => [ 'value' => 'fas fa-check-circle' ] ],
				[ 'item_text' => 'Advanced analytics',        'item_icon' => [ 'value' => 'fas fa-check-circle' ] ],
			],
			'title_field' => '{{{ item_text }}}',
		] );

		$this->add_responsive_control( 'columns', [
			'label'   => esc_html__( 'Columns', 'starter-flavor' ),
			'type'    => \Elementor\Controls_Manager::SELECT,
			'options' => [ '1' => '1', '2' => '2', '3' => '3' ],
			'default' => '1',
		] );
		$this->add_control( 'divider',   [ 'label' => 'Show Divider', 'type' => \Elementor\Controls_Manager::SWITCHER ] );

		$this->end_controls_section();

		$this->start_controls_section( 'section_style', [ 'label' => 'Style', 'tab' => \Elementor\Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'default_icon_color', [ 'label' => 'Default Icon Color', 'type' => \Elementor\Controls_Manager::COLOR, 'default' => '', 'selectors' => [ '{{WRAPPER}} .sf-il-icon' => 'color: {{VALUE}};' ] ] );
		$this->add_control( 'icon_size', [ 'label' => 'Icon Size', 'type' => \Elementor\Controls_Manager::SLIDER, 'range' => [ 'px' => [ 'min' => 10, 'max' => 48 ] ], 'default' => [ 'size' => 18 ], 'selectors' => [ '{{WRAPPER}} .sf-il-icon' => 'font-size: {{SIZE}}px;' ] ] );
		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
			'name'     => 'text_typography',
			'selector' => '{{WRAPPER}} .sf-il-text',
		] );
		$this->add_responsive_control( 'item_gap', [ 'label' => 'Row Gap', 'type' => \Elementor\Controls_Manager::SLIDER, 'range' => [ 'px' => [ 'min' => 4, 'max' => 40 ] ], 'default' => [ 'size' => 12 ], 'selectors' => [ '{{WRAPPER}} .sf-icon-list' => 'row-gap: {{SIZE}}px;' ] ] );
		$this->end_controls_section();
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$cols = (int) $s['columns'];
		$div  = 'yes' === $s['divider'];
		?>
		<ul class="sf-icon-list" style="list-style:none;padding:0;margin:0;display:grid;grid-template-columns:repeat(<?php echo $cols; ?>,1fr);column-gap:24px;row-gap:12px;">
			<?php foreach ( $s['items'] as $item ) :
				$icon  = ! empty( $item['item_icon']['value'] ) ? $item['item_icon']['value'] : 'fas fa-check';
				$color = ! empty( $item['icon_color'] ) ? 'color:' . $item['icon_color'] . ';' : '';
				$link  = ! empty( $item['item_link']['url'] );
			?>
			<li style="display:flex;align-items:center;gap:10px;<?php echo $div ? 'border-bottom:1px solid #e5e7eb;padding-bottom:12px;' : ''; ?>">
				<span class="sf-il-icon" style="flex-shrink:0;color:var(--sf-color-primary,#FF5E2E);font-size:18px;<?php echo $color; ?>"><i class="<?php echo esc_attr($icon); ?>" aria-hidden="true"></i></span>
				<span class="sf-il-text" style="font-size:15px;color:var(--sf-color-title,#1e293b);line-height:1.5;">
					<?php if ( $link ) : ?><a href="<?php echo esc_url($item['item_link']['url']); ?>" <?php echo $item['item_link']['is_external'] ? 'target="_blank" rel="noopener noreferrer"' : ''; ?>><?php endif; ?>
					<?php echo esc_html($item['item_text']); ?>
					<?php if ( $link ) : ?></a><?php endif; ?>
				</span>
			</li>
			<?php endforeach; ?>
		</ul>
		<?php
	}
}
