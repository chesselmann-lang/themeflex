<?php
/**
 * Elementor Image Gallery Widget
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Image Gallery Widget Class
 *
 * @since 1.0.0
 */
class Starter_Flavor_Image_Gallery_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'starter_flavor_image_gallery';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Image Gallery', 'starter-flavor' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'starter-flavor' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Gallery', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Gallery Control
		$this->add_control(
			'gallery_images',
			array(
				'label'   => esc_html__( 'Gallery Images', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::GALLERY,
				'default' => array(),
			)
		);

		// Layout
		$this->add_control(
			'gallery_layout',
			array(
				'label'   => esc_html__( 'Layout', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'grid',
				'options' => array(
					'grid'    => esc_html__( 'Grid', 'starter-flavor' ),
					'masonry' => esc_html__( 'Masonry', 'starter-flavor' ),
				),
			)
		);

		// Columns
		$this->add_control(
			'gallery_columns',
			array(
				'label'   => esc_html__( 'Columns', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => '3',
				'options' => array(
					'2' => esc_html__( '2', 'starter-flavor' ),
					'3' => esc_html__( '3', 'starter-flavor' ),
					'4' => esc_html__( '4', 'starter-flavor' ),
					'5' => esc_html__( '5', 'starter-flavor' ),
					'6' => esc_html__( '6', 'starter-flavor' ),
				),
			)
		);

		// Enable Lightbox
		$this->add_control(
			'enable_lightbox',
			array(
				'label'        => esc_html__( 'Enable Lightbox', 'starter-flavor' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'starter-flavor' ),
				'label_off'    => esc_html__( 'No', 'starter-flavor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		// Hover Overlay
		$this->add_control(
			'hover_overlay_type',
			array(
				'label'   => esc_html__( 'Hover Overlay', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'icon',
				'options' => array(
					'none'  => esc_html__( 'None', 'starter-flavor' ),
					'icon'  => esc_html__( 'Icon', 'starter-flavor' ),
					'title' => esc_html__( 'Title', 'starter-flavor' ),
				),
			)
		);

		// Gap/Spacing
		$this->add_control(
			'gallery_gap',
			array(
				'label'   => esc_html__( 'Gap/Spacing', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 15,
				),
				'range'   => array(
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
			)
		);

		// Lazy Loading
		$this->add_control(
			'enable_lazy_loading',
			array(
				'label'        => esc_html__( 'Lazy Loading', 'starter-flavor' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'starter-flavor' ),
				'label_off'    => esc_html__( 'No', 'starter-flavor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->end_controls_section();

		// Style Section - Gallery
		$this->start_controls_section(
			'gallery_style_section',
			array(
				'label' => esc_html__( 'Gallery Style', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'image_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'default'    => array(
					'top'    => '5',
					'right'  => '5',
					'bottom' => '5',
					'left'   => '5',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .gallery-image-item img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'image_box_shadow',
				'label'    => esc_html__( 'Shadow', 'starter-flavor' ),
				'selector' => '{{WRAPPER}} .gallery-image-item',
			)
		);

		$this->add_control(
			'overlay_color',
			array(
				'label'     => esc_html__( 'Overlay Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => 'rgba(0, 0, 0, 0.6)',
				'selectors' => array(
					'{{WRAPPER}} .gallery-overlay' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['gallery_images'] ) ) {
			echo '<p>' . esc_html__( 'Please select images for the gallery', 'starter-flavor' ) . '</p>';
			return;
		}

		$layout = isset( $settings['gallery_layout'] ) ? $settings['gallery_layout'] : 'grid';
		$columns = isset( $settings['gallery_columns'] ) ? intval( $settings['gallery_columns'] ) : 3;
		$gap = isset( $settings['gallery_gap']['size'] ) ? intval( $settings['gallery_gap']['size'] ) : 15;
		$enable_lightbox = isset( $settings['enable_lightbox'] ) ? $settings['enable_lightbox'] : 'yes';
		$lazy_loading = isset( $settings['enable_lazy_loading'] ) ? $settings['enable_lazy_loading'] : 'yes';
		$hover_overlay = isset( $settings['hover_overlay_type'] ) ? $settings['hover_overlay_type'] : 'icon';

		$gallery_class = 'gallery-container gallery-' . esc_attr( $layout );
		$gallery_style = 'display: grid; grid-template-columns: repeat(' . esc_attr( $columns ) . ', 1fr); gap: ' . esc_attr( $gap ) . 'px;';

		echo '<div class="' . esc_attr( $gallery_class ) . '" style="' . esc_attr( $gallery_style ) . '">';

		foreach ( $settings['gallery_images'] as $image ) {
			$image_url = isset( $image['url'] ) ? $image['url'] : '';
			$image_id = isset( $image['id'] ) ? $image['id'] : '';

			if ( empty( $image_url ) ) {
				continue;
			}

			$lightbox_attr = '';
			if ( 'yes' === $enable_lightbox ) {
				$lightbox_attr = ' data-elementor-lightbox-slideshow="starter-flavor-gallery" data-elementor-lightbox-index="' . esc_attr( $image_id ) . '"';
			}

			$lazy_attr = '';
			if ( 'yes' === $lazy_loading ) {
				$lazy_attr = ' loading="lazy"';
			}

			echo '<div class="gallery-image-item">';

			// Image
			printf(
				'<img src="%s" alt="%s"%s%s class="gallery-image" />',
				esc_url( $image_url ),
				esc_attr( isset( $image['alt'] ) ? $image['alt'] : '' ),
				$lazy_attr,
				$lightbox_attr
			);

			// Overlay
			if ( 'none' !== $hover_overlay ) {
				echo '<div class="gallery-overlay">';

				if ( 'icon' === $hover_overlay ) {
					echo '<div class="overlay-icon"><i class="eicon-search"></i></div>';
				} elseif ( 'title' === $hover_overlay ) {
					echo '<div class="overlay-title">';
					if ( isset( $image['caption'] ) && ! empty( $image['caption'] ) ) {
						echo esc_html( $image['caption'] );
					} else {
						esc_html_e( 'View Image', 'starter-flavor' );
					}
					echo '</div>';
				}

				echo '</div>';
			}

			echo '</div>';
		}

		echo '</div>';
	}
}
