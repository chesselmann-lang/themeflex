<?php
/**
 * Isotope Portfolio Filter Widget — AJAX Masonry mit Live-Filter.
 * @package Starter_Flavor
 */
if (!defined('ABSPATH')) exit;

class Starter_Flavor_Isotope_Portfolio_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'sf_isotope_portfolio'; }
    public function get_title() { return esc_html__('Portfolio Filter (Isotope)','starter-flavor'); }
    public function get_icon()  { return 'eicon-gallery-justified'; }
    public function get_categories() { return ['starter-flavor']; }
    public function get_keywords()   { return ['portfolio','filter','isotope','masonry','grid','gallery']; }

    protected function register_controls() {
        $this->start_controls_section('section_source',['label'=>'Source']);
        $this->add_control('source',['label'=>'Source','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['cpt'=>'Portfolio CPT','custom'=>'Custom Items'],'default'=>'custom']);
        $this->add_control('posts_per_page',['label'=>'Items to Show','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['px'=>['min'=>4,'max'=>50]],'default'=>['size'=>12],'condition'=>['source'=>'cpt']]);
        $this->end_controls_section();

        $this->start_controls_section('section_custom',['label'=>'Custom Items','condition'=>['source'=>'custom']]);
        $repeater = new \Elementor\Repeater();
        $repeater->add_control('item_title',['label'=>'Title','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Project Title']);
        $repeater->add_control('item_category',['label'=>'Category (slug)','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'branding']);
        $repeater->add_control('item_category_label',['label'=>'Category Label','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Branding']);
        $repeater->add_control('item_image',['label'=>'Image','type'=>\Elementor\Controls_Manager::MEDIA]);
        $repeater->add_control('item_url',['label'=>'Link URL','type'=>\Elementor\Controls_Manager::URL]);
        $repeater->add_control('item_desc',['label'=>'Short Desc','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>'']);
        $repeater->add_control('item_span',['label'=>'Wide (2 cols)','type'=>\Elementor\Controls_Manager::SWITCHER]);
        $this->add_control('items',[
            'type'=>\Elementor\Controls_Manager::REPEATER,'fields'=>$repeater->get_controls(),
            'default'=>[
                ['item_title'=>'Brand Identity','item_category'=>'branding','item_category_label'=>'Branding','item_span'=>''],
                ['item_title'=>'E-Commerce App','item_category'=>'web','item_category_label'=>'Web Design','item_span'=>'yes'],
                ['item_title'=>'Logo System','item_category'=>'branding','item_category_label'=>'Branding','item_span'=>''],
                ['item_title'=>'Mobile App UI','item_category'=>'ui-ux','item_category_label'=>'UI/UX','item_span'=>''],
                ['item_title'=>'Marketing Site','item_category'=>'web','item_category_label'=>'Web Design','item_span'=>''],
                ['item_title'=>'Dashboard Design','item_category'=>'ui-ux','item_category_label'=>'UI/UX','item_span'=>'yes'],
            ],
            'title_field'=>'{{{ item_title }}}',
        ]);
        $this->end_controls_section();

        $this->start_controls_section('section_layout',['label'=>'Layout']);
        $this->add_responsive_control('columns',['label'=>'Columns','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['2'=>'2','3'=>'3','4'=>'4'],'default'=>'3','tablet_default'=>'2','mobile_default'=>'1']);
        $this->add_control('gap',['label'=>'Gap (px)','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['px'=>['min'=>0,'max'=>40]],'default'=>['size'=>16],'selectors'=>['{{WRAPPER}} .sf-iso-grid'=>'gap:{{SIZE}}px;']]);
        $this->add_control('show_overlay',['label'=>'Hover Overlay','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes']);
        $this->add_control('filter_position',['label'=>'Filter Alignment','type'=>\Elementor\Controls_Manager::CHOOSE,'options'=>['flex-start'=>['icon'=>'eicon-text-align-left','title'=>'Left'],'center'=>['icon'=>'eicon-text-align-center','title'=>'Center'],'flex-end'=>['icon'=>'eicon-text-align-right','title'=>'Right']],'default'=>'center','selectors'=>['{{WRAPPER}} .sf-iso-filters'=>'justify-content:{{VALUE}};']]);
        $this->add_control('all_label',['label'=>'"All" Button Label','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'All']);
        $this->end_controls_section();
    }

    protected function render() {
        $s    = $this->get_settings_for_display();
        $uid  = 'sf-iso-'.$this->get_id();
        $cols = (int)($s['columns'] ?? 3);
        $items = $s['items'];
        $show_overlay = 'yes' === $s['show_overlay'];
        // Collect unique categories
        $cats = [];
        foreach($items as $item) {
            if (!empty($item['item_category']) && !isset($cats[$item['item_category']])) {
                $cats[$item['item_category']] = $item['item_category_label'] ?: $item['item_category'];
            }
        }
        ?>
        <div class="sf-iso-wrap" id="<?php echo esc_attr($uid); ?>">
            <!-- Filters -->
            <div class="sf-iso-filters" style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:32px;justify-content:center;">
                <button class="sf-iso-filter active" data-filter="*"><?php echo esc_html($s['all_label'] ?? 'All'); ?></button>
                <?php foreach($cats as $slug => $label): ?>
                <button class="sf-iso-filter" data-filter=".sf-cat-<?php echo esc_attr($slug); ?>"><?php echo esc_html($label); ?></button>
                <?php endforeach; ?>
            </div>
            <!-- Grid -->
            <div class="sf-iso-grid" id="<?php echo esc_attr($uid); ?>-grid" style="display:grid;grid-template-columns:repeat(<?php echo $cols; ?>,1fr);gap:16px;">
                <?php foreach($items as $item):
                    $cats_class = 'sf-cat-'.sanitize_html_class($item['item_category']);
                    $wide = 'yes' === ($item['item_span'] ?? '');
                    $img  = !empty($item['item_image']['url']) ? $item['item_image']['url'] : '';
                    $url  = !empty($item['item_url']['url']) ? $item['item_url']['url'] : '#';
                    $ext  = !empty($item['item_url']['is_external']) ? 'target="_blank" rel="noopener noreferrer"' : '';
                    // Generate a gradient placeholder if no image
                    $placeholder_colors = ['#FF5E2E,#ED4C1C','#0066FF,#0052CC','#10B981,#059669','#7c3aed,#6d28d9','#f59e0b,#d97706'];
                    $pc = $placeholder_colors[crc32($item['item_title']) % count($placeholder_colors)];
                ?>
                <div class="sf-iso-item <?php echo esc_attr($cats_class); ?>" style="<?php echo $wide ? 'grid-column:span 2;' : ''; ?>border-radius:12px;overflow:hidden;aspect-ratio:4/3;position:relative;background:linear-gradient(135deg,<?php echo $pc; ?>);">
                    <?php if($img): ?>
                    <img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr($item['item_title']); ?>" style="width:100%;height:100%;object-fit:cover;display:block;" loading="lazy" />
                    <?php else: ?>
                    <div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;"><span style="color:rgba(255,255,255,.5);font-size:14px;">Image</span></div>
                    <?php endif; ?>
                    <?php if($show_overlay): ?>
                    <div class="sf-iso-overlay" style="position:absolute;inset:0;background:rgba(6,2,29,.85);display:flex;flex-direction:column;align-items:center;justify-content:center;padding:20px;opacity:0;transition:opacity .3s ease;text-align:center;">
                        <div style="font-weight:700;font-size:16px;color:#fff;margin-bottom:6px;"><?php echo esc_html($item['item_title']); ?></div>
                        <?php if($item['item_category_label']): ?>
                        <div style="font-size:12px;color:var(--sf-color-primary,#FF5E2E);font-weight:600;margin-bottom:12px;"><?php echo esc_html($item['item_category_label']); ?></div>
                        <?php endif; ?>
                        <?php if($item['item_desc']): ?>
                        <p style="font-size:13px;color:rgba(255,255,255,.7);margin-bottom:16px;"><?php echo esc_html($item['item_desc']); ?></p>
                        <?php endif; ?>
                        <a href="<?php echo esc_url($url); ?>" <?php echo $ext; ?> style="padding:8px 20px;border-radius:6px;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;font-weight:700;font-size:13px;text-decoration:none;">View Project</a>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <style>
        .sf-iso-filter{padding:8px 20px;border-radius:20px;border:1px solid var(--sf-border,#e5e7eb);background:transparent;color:var(--sf-text,#64748b);font-weight:600;font-size:13px;cursor:pointer;transition:all .2s}
        .sf-iso-filter:hover,.sf-iso-filter.active{background:var(--sf-color-primary,#FF5E2E);border-color:var(--sf-color-primary,#FF5E2E);color:#fff}
        .sf-iso-item:hover .sf-iso-overlay{opacity:1!important}
        .sf-iso-item{transition:transform .3s ease}
        .sf-iso-item.sf-iso-hidden{display:none}
        .sf-iso-item.sf-iso-fade-in{animation:sfIsoIn .35s ease forwards}
        @keyframes sfIsoIn{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}
        @media(max-width:768px){.sf-iso-grid{grid-template-columns:repeat(2,1fr)!important}.sf-iso-item[style*="span 2"]{grid-column:span 1!important}}
        @media(max-width:480px){.sf-iso-grid{grid-template-columns:1fr!important}}
        </style>
        <script>
        (function(){
            var wrap=document.getElementById('<?php echo esc_js($uid); ?>');
            if(!wrap)return;
            var filters=wrap.querySelectorAll('.sf-iso-filter');
            var items=wrap.querySelectorAll('.sf-iso-item');
            filters.forEach(function(btn){
                btn.addEventListener('click',function(){
                    filters.forEach(function(b){b.classList.remove('active');});
                    btn.classList.add('active');
                    var f=btn.dataset.filter;
                    items.forEach(function(item){
                        if(f==='*'||item.classList.contains(f.replace('.',''))) {
                            item.classList.remove('sf-iso-hidden');
                            item.classList.add('sf-iso-fade-in');
                            setTimeout(function(){item.classList.remove('sf-iso-fade-in');},400);
                        } else {
                            item.classList.add('sf-iso-hidden');
                        }
                    });
                });
            });
        })();
        </script>
        <?php
    }
}
