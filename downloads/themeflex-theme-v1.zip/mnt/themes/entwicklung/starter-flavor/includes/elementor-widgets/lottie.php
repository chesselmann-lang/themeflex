<?php
/**
 * Elementor Lottie Animation Widget
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Lottie Animation Widget Class
 *
 * @since 1.0.0
 */
class Starter_Flavor_Lottie_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'starter_flavor_lottie';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Lottie Animation', 'starter-flavor' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-animation';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'starter-flavor' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// JSON Source
		$this->add_control(
			'json_source',
			array(
				'label'   => esc_html__( 'JSON Source', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'url',
				'options' => array(
					'url'    => esc_html__( 'URL', 'starter-flavor' ),
					'upload' => esc_html__( 'Upload JSON', 'starter-flavor' ),
				),
			)
		);

		// JSON URL
		$this->add_control(
			'json_url',
			array(
				'label'       => esc_html__( 'JSON URL', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'https://example.com/animation.json', 'starter-flavor' ),
				'condition'   => array(
					'json_source' => 'url',
				),
			)
		);

		// JSON Upload
		$this->add_control(
			'json_upload',
			array(
				'label'      => esc_html__( 'JSON File', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::MEDIA,
				'media_type' => 'application/json',
				'condition'  => array(
					'json_source' => 'upload',
				),
			)
		);

		// Trigger Type
		$this->add_control(
			'trigger_type',
			array(
				'label'   => esc_html__( 'Trigger Type', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'none',
				'options' => array(
					'none'     => esc_html__( 'Always Playing', 'starter-flavor' ),
					'scroll'   => esc_html__( 'On Scroll', 'starter-flavor' ),
					'hover'    => esc_html__( 'On Hover', 'starter-flavor' ),
					'click'    => esc_html__( 'On Click', 'starter-flavor' ),
				),
			)
		);

		// Loop
		$this->add_control(
			'loop',
			array(
				'label'        => esc_html__( 'Loop', 'starter-flavor' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'starter-flavor' ),
				'label_off'    => esc_html__( 'No', 'starter-flavor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		// Speed
		$this->add_control(
			'speed',
			array(
				'label'   => esc_html__( 'Speed', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 1,
				),
				'range'   => array(
					'px' => array(
						'min'  => 0.5,
						'max'  => 3,
						'step' => 0.1,
					),
				),
			)
		);

		// Direction
		$this->add_control(
			'direction',
			array(
				'label'   => esc_html__( 'Direction', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1'  => esc_html__( 'Forward', 'starter-flavor' ),
					'-1' => esc_html__( 'Reverse', 'starter-flavor' ),
				),
			)
		);

		// Autoplay
		$this->add_control(
			'autoplay',
			array(
				'label'        => esc_html__( 'Autoplay', 'starter-flavor' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'starter-flavor' ),
				'label_off'    => esc_html__( 'No', 'starter-flavor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->end_controls_section();

		// Size Section
		$this->start_controls_section(
			'size_section',
			array(
				'label' => esc_html__( 'Size', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'animation_width',
			array(
				'label'      => esc_html__( 'Width', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%', 'em' ),
				'default'    => array(
					'unit' => 'px',
					'size' => 300,
				),
				'range'      => array(
					'px' => array(
						'min' => 50,
						'max' => 1000,
					),
					'%'  => array(
						'min' => 10,
						'max' => 100,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .lottie-animation' => 'width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'animation_height',
			array(
				'label'      => esc_html__( 'Height', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%', 'em' ),
				'default'    => array(
					'unit' => 'px',
					'size' => 300,
				),
				'range'      => array(
					'px' => array(
						'min' => 50,
						'max' => 1000,
					),
					'%'  => array(
						'min' => 10,
						'max' => 100,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .lottie-animation' => 'height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'alignment',
			array(
				'label'   => esc_html__( 'Alignment', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::CHOOSE,
				'options' => array(
					'flex-start'    => array(
						'title' => esc_html__( 'Left', 'starter-flavor' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center'        => array(
						'title' => esc_html__( 'Center', 'starter-flavor' ),
						'icon'  => 'eicon-text-align-center',
					),
					'flex-end'      => array(
						'title' => esc_html__( 'Right', 'starter-flavor' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'default' => 'center',
				'selectors' => array(
					'{{WRAPPER}}' => 'display: flex; justify-content: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$json_source = isset( $settings['json_source'] ) ? $settings['json_source'] : 'url';
		$json_url = isset( $settings['json_url'] ) ? $settings['json_url'] : '';
		$json_upload = isset( $settings['json_upload']['url'] ) ? $settings['json_upload']['url'] : '';
		$trigger_type = isset( $settings['trigger_type'] ) ? $settings['trigger_type'] : 'none';
		$loop = isset( $settings['loop'] ) && 'yes' === $settings['loop'];
		$speed = isset( $settings['speed']['size'] ) ? floatval( $settings['speed']['size'] ) : 1;
		$direction = isset( $settings['direction'] ) ? intval( $settings['direction'] ) : 1;
		$autoplay = isset( $settings['autoplay'] ) && 'yes' === $settings['autoplay'];

		$animation_data = 'url' === $json_source ? $json_url : $json_upload;

		if ( empty( $animation_data ) ) {
			echo '<p>' . esc_html__( 'Please select a Lottie JSON file', 'starter-flavor' ) . '</p>';
			return;
		}

		?>
		<div class="lottie-animation"
			data-json="<?php echo esc_attr( $animation_data ); ?>"
			data-trigger="<?php echo esc_attr( $trigger_type ); ?>"
			data-loop="<?php echo esc_attr( $loop ? 'true' : 'false' ); ?>"
			data-speed="<?php echo esc_attr( $speed ); ?>"
			data-direction="<?php echo esc_attr( $direction ); ?>"
			data-autoplay="<?php echo esc_attr( $autoplay ? 'true' : 'false' ); ?>">
		</div>
		<?php
	}
}
