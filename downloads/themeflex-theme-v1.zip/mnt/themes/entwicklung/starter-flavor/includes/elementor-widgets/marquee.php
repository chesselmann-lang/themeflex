<?php
/**
 * Elementor Marquee Ticker Widget
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Marquee Ticker Widget Class
 *
 * @since 1.0.0
 */
class Starter_Flavor_Marquee_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'starter_flavor_marquee';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Marquee Ticker', 'starter-flavor' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-scroll';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'starter-flavor' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Marquee Items Repeater
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'item_type',
			array(
				'label'   => esc_html__( 'Type', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'text',
				'options' => array(
					'text'  => esc_html__( 'Text', 'starter-flavor' ),
					'image' => esc_html__( 'Image', 'starter-flavor' ),
					'icon'  => esc_html__( 'Icon', 'starter-flavor' ),
				),
			)
		);

		$repeater->add_control(
			'item_text',
			array(
				'label'       => esc_html__( 'Text', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter text', 'starter-flavor' ),
				'condition'   => array(
					'item_type' => 'text',
				),
			)
		);

		$repeater->add_control(
			'item_image',
			array(
				'label'     => esc_html__( 'Image', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::MEDIA,
				'condition' => array(
					'item_type' => 'image',
				),
			)
		);

		$repeater->add_control(
			'item_icon',
			array(
				'label'     => esc_html__( 'Icon', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::ICONS,
				'default'   => array(
					'value'   => 'fas fa-star',
					'library' => 'fa-solid',
				),
				'condition' => array(
					'item_type' => 'icon',
				),
			)
		);

		$repeater->add_control(
			'item_link',
			array(
				'label'       => esc_html__( 'Link', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://example.com', 'starter-flavor' ),
			)
		);

		$this->add_control(
			'marquee_items',
			array(
				'label'      => esc_html__( 'Items', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::REPEATER,
				'fields'     => $repeater->get_controls(),
				'title_field' => '{{{ item_text }}}',
				'default'    => array(
					array(
						'item_type' => 'text',
						'item_text' => 'Marquee Item 1',
					),
					array(
						'item_type' => 'text',
						'item_text' => 'Marquee Item 2',
					),
				),
			)
		);

		$this->end_controls_section();

		// Settings Section
		$this->start_controls_section(
			'settings_section',
			array(
				'label' => esc_html__( 'Settings', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Speed
		$this->add_control(
			'speed',
			array(
				'label'   => esc_html__( 'Speed (seconds)', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 20,
				),
				'range'   => array(
					'px' => array(
						'min' => 5,
						'max' => 100,
					),
				),
			)
		);

		// Direction
		$this->add_control(
			'direction',
			array(
				'label'   => esc_html__( 'Direction', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'left',
				'options' => array(
					'left'  => esc_html__( 'Left to Right', 'starter-flavor' ),
					'right' => esc_html__( 'Right to Left', 'starter-flavor' ),
				),
			)
		);

		// Pause on Hover
		$this->add_control(
			'pause_on_hover',
			array(
				'label'        => esc_html__( 'Pause on Hover', 'starter-flavor' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'starter-flavor' ),
				'label_off'    => esc_html__( 'No', 'starter-flavor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		// Separator
		$this->add_control(
			'separator_type',
			array(
				'label'   => esc_html__( 'Separator', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'text',
				'options' => array(
					'none' => esc_html__( 'None', 'starter-flavor' ),
					'text' => esc_html__( 'Text', 'starter-flavor' ),
					'icon' => esc_html__( 'Icon', 'starter-flavor' ),
				),
			)
		);

		$this->add_control(
			'separator_text',
			array(
				'label'       => esc_html__( 'Separator Text', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '|',
				'placeholder' => esc_html__( 'Enter separator', 'starter-flavor' ),
				'condition'   => array(
					'separator_type' => 'text',
				),
			)
		);

		$this->add_control(
			'separator_icon',
			array(
				'label'     => esc_html__( 'Separator Icon', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::ICONS,
				'default'   => array(
					'value'   => 'fas fa-circle',
					'library' => 'fa-solid',
				),
				'condition' => array(
					'separator_type' => 'icon',
				),
			)
		);

		$this->end_controls_section();

		// Style Section
		$this->start_controls_section(
			'style_section',
			array(
				'label' => esc_html__( 'Style', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#f5f5f5',
				'selectors' => array(
					'{{WRAPPER}} .marquee-ticker' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#333333',
				'selectors' => array(
					'{{WRAPPER}} .marquee-item' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'height',
			array(
				'label'      => esc_html__( 'Height (px)', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'default'    => array(
					'size' => 60,
				),
				'range'      => array(
					'px' => array(
						'min' => 30,
						'max' => 200,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .marquee-ticker' => 'height: {{SIZE}}px;',
				),
			)
		);

		$this->add_control(
			'gap',
			array(
				'label'      => esc_html__( 'Gap Between Items (px)', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'default'    => array(
					'size' => 30,
				),
				'range'      => array(
					'px' => array(
						'min' => 10,
						'max' => 100,
					),
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$marquee_items = isset( $settings['marquee_items'] ) ? $settings['marquee_items'] : array();
		$speed = isset( $settings['speed']['size'] ) ? intval( $settings['speed']['size'] ) : 20;
		$direction = isset( $settings['direction'] ) ? $settings['direction'] : 'left';
		$pause_on_hover = isset( $settings['pause_on_hover'] ) && 'yes' === $settings['pause_on_hover'];
		$separator_type = isset( $settings['separator_type'] ) ? $settings['separator_type'] : 'text';
		$separator_text = isset( $settings['separator_text'] ) ? $settings['separator_text'] : '|';
		$separator_icon = isset( $settings['separator_icon']['value'] ) ? $settings['separator_icon']['value'] : 'fas fa-circle';
		$gap = isset( $settings['gap']['size'] ) ? intval( $settings['gap']['size'] ) : 30;

		if ( empty( $marquee_items ) ) {
			echo '<p>' . esc_html__( 'Please add marquee items', 'starter-flavor' ) . '</p>';
			return;
		}

		?>
		<div class="marquee-ticker" data-speed="<?php echo esc_attr( $speed ); ?>" data-direction="<?php echo esc_attr( $direction ); ?>" data-pause-hover="<?php echo esc_attr( $pause_on_hover ? 'true' : 'false' ); ?>" style="--marquee-gap: <?php echo esc_attr( $gap ); ?>px;">
			<div class="marquee-content">
				<?php
				foreach ( $marquee_items as $index => $item ) :
					$item_type = isset( $item['item_type'] ) ? $item['item_type'] : 'text';
					$item_text = isset( $item['item_text'] ) ? $item['item_text'] : '';
					$item_image = isset( $item['item_image']['url'] ) ? $item['item_image']['url'] : '';
					$item_icon = isset( $item['item_icon']['value'] ) ? $item['item_icon']['value'] : 'fas fa-star';
					$item_link = isset( $item['item_link']['url'] ) ? $item['item_link']['url'] : '';
					$item_classes = 'marquee-item marquee-item-' . esc_attr( $item_type );
					$tag = ! empty( $item_link ) ? 'a' : 'div';
					$link_attr = ! empty( $item_link ) ? ' href="' . esc_url( $item_link ) . '"' : '';
					?>
					<<?php echo esc_attr( $tag ); ?> class="<?php echo esc_attr( $item_classes ); ?>"<?php echo wp_kses_post( $link_attr ); ?>>
						<?php if ( 'text' === $item_type && ! empty( $item_text ) ) : ?>
							<?php echo esc_html( $item_text ); ?>
						<?php elseif ( 'image' === $item_type && ! empty( $item_image ) ) : ?>
							<img src="<?php echo esc_url( $item_image ); ?>" alt="<?php esc_attr_e( 'Marquee Item', 'starter-flavor' ); ?>" class="marquee-image" />
						<?php elseif ( 'icon' === $item_type ) : ?>
							<i class="<?php echo esc_attr( $item_icon ); ?>"></i>
						<?php endif; ?>
					</<?php echo esc_attr( $tag ); ?>>
					<?php
					// Add separator
					if ( $index < count( $marquee_items ) - 1 && 'none' !== $separator_type ) :
						if ( 'text' === $separator_type ) :
							?>
							<span class="marquee-separator"><?php echo esc_html( $separator_text ); ?></span>
							<?php
						elseif ( 'icon' === $separator_type ) :
							?>
							<i class="marquee-separator-icon <?php echo esc_attr( $separator_icon ); ?>"></i>
							<?php
						endif;
					endif;
				endforeach;
				?>
			</div>
		</div>
		<?php
	}
}
