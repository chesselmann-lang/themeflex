<?php
/**
 * Mega CTA Section Widget — Vollbreite CTA mit Gradient-BG und Statistiken.
 * @package Starter_Flavor
 */
if (!defined('ABSPATH')) exit;

class Starter_Flavor_Mega_Cta_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'sf_mega_cta'; }
    public function get_title() { return esc_html__('Mega CTA Section','starter-flavor'); }
    public function get_icon()  { return 'eicon-call-to-action'; }
    public function get_categories() { return ['starter-flavor']; }
    public function get_keywords()   { return ['cta','call to action','hero','conversion','section','mega']; }

    protected function register_controls() {
        $this->start_controls_section('s_content',['label'=>'Content']);
        $this->add_control('style',['label'=>'Style','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['gradient'=>'Gradient Dark','light'=>'Light Card','split'=>'Split Color'],'default'=>'gradient']);
        $this->add_control('eyebrow',['label'=>'Eyebrow Text','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Ready to get started?']);
        $this->add_control('title',['label'=>'Heading','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>'Build your dream website today']);
        $this->add_control('subtitle',['label'=>'Subtitle','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>'Join 50,000+ businesses that trust Starter Flavor for their online presence.']);
        $this->add_control('primary_btn_text',['label'=>'Primary Button','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Get Started — $59']);
        $this->add_control('primary_btn_url',['label'=>'Primary URL','type'=>\Elementor\Controls_Manager::URL]);
        $this->add_control('secondary_btn_text',['label'=>'Secondary Button','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'View Demos']);
        $this->add_control('secondary_btn_url',['label'=>'Secondary URL','type'=>\Elementor\Controls_Manager::URL]);
        $this->add_control('note',['label'=>'Fine Print','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'✓ GPL Licensed  ·  ✓ Lifetime Updates  ·  ✓ 6 Months Support']);
        $this->end_controls_section();

        $this->start_controls_section('s_stats',['label'=>'Stats (optional)']);
        $rep = new \Elementor\Repeater();
        $rep->add_control('stat_num',['label'=>'Number','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'50K+']);
        $rep->add_control('stat_label',['label'=>'Label','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Customers']);
        $this->add_control('stats',['type'=>\Elementor\Controls_Manager::REPEATER,'fields'=>$rep->get_controls(),'default'=>[
            ['stat_num'=>'50K+','stat_label'=>'Happy Customers'],['stat_num'=>'66+','stat_label'=>'Widgets'],['stat_num'=>'20','stat_label'=>'Pro Skins'],['stat_num'=>'4.9★','stat_label'=>'Rating'],
        ],'title_field'=>'{{{ stat_num }}} {{{ stat_label }}}']);
        $this->end_controls_section();
    }

    protected function render() {
        $s  = $this->get_settings_for_display();
        $st = $s['style'] ?? 'gradient';
        $p_url = !empty($s['primary_btn_url']['url'])   ? esc_url($s['primary_btn_url']['url'])   : '#';
        $s_url = !empty($s['secondary_btn_url']['url']) ? esc_url($s['secondary_btn_url']['url']) : '#';

        $wrap_style = match($st) {
            'gradient' => 'background:linear-gradient(135deg,#06021D 0%,#1a1f29 100%);color:#fff;',
            'light'    => 'background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:24px;',
            'split'    => 'background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));',
            default    => '',
        };
        $title_color = 'gradient'===$st ? '#fff' : 'var(--sf-title,#1e293b)';
        $text_color  = 'gradient'===$st ? 'rgba(255,255,255,.7)' : 'var(--sf-text,#64748b)';
        $eyebrow_color = 'gradient'===$st ? 'rgba(255,255,255,.5)' : 'var(--sf-meta,#94a3b8)';
        $s_btn_style = 'gradient'===$st
            ? 'background:rgba(255,255,255,.1);color:#fff;border:1px solid rgba(255,255,255,.2);'
            : 'background:var(--sf-bg,#fff);color:var(--sf-title,#1e293b);border:1px solid var(--sf-border,#e5e7eb);';
        $stat_color = 'gradient'===$st ? '#fff' : 'var(--sf-color-primary,#FF5E2E)';
        $stat_label_color = 'gradient'===$st ? 'rgba(255,255,255,.55)' : 'var(--sf-meta,#94a3b8)';
        ?>
        <div style="<?php echo $wrap_style; ?>padding:80px 48px;border-radius:24px;text-align:center;position:relative;overflow:hidden;">
            <?php if('gradient'===$st): ?>
            <div style="position:absolute;width:600px;height:600px;border-radius:50%;background:radial-gradient(circle,rgba(255,94,46,.15),transparent);top:50%;left:50%;transform:translate(-50%,-50%);pointer-events:none;"></div>
            <?php endif; ?>
            <div style="position:relative;z-index:1;max-width:720px;margin:0 auto;">
                <?php if($s['eyebrow']): ?><div style="font-size:13px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:<?php echo $eyebrow_color; ?>;margin-bottom:16px;"><?php echo esc_html($s['eyebrow']); ?></div><?php endif; ?>
                <h2 style="font-family:'Inter Tight',sans-serif;font-size:clamp(32px,5vw,56px);font-weight:900;color:<?php echo $title_color; ?>;margin-bottom:16px;letter-spacing:-.5px;line-height:1.1;"><?php echo esc_html($s['title']); ?></h2>
                <?php if($s['subtitle']): ?><p style="font-size:18px;color:<?php echo $text_color; ?>;margin-bottom:36px;line-height:1.7;max-width:560px;margin-left:auto;margin-right:auto;"><?php echo esc_html($s['subtitle']); ?></p><?php endif; ?>
                <div style="display:flex;align-items:center;justify-content:center;gap:12px;flex-wrap:wrap;margin-bottom:<?php echo $s['note']?'16':'0'; ?>px;">
                    <?php if($s['primary_btn_text']): ?>
                    <a href="<?php echo $p_url; ?>" style="padding:15px 32px;background:'split'===$st?'rgba(0,0,0,.25)':'var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C))';color:#fff;border-radius:12px;font-weight:800;font-size:16px;text-decoration:none;display:inline-block;<?php echo 'split'===$st?'background:rgba(0,0,0,.25);border:2px solid rgba(255,255,255,.3);':'background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));'; ?>">
                        <?php echo esc_html($s['primary_btn_text']); ?>
                    </a>
                    <?php endif; ?>
                    <?php if($s['secondary_btn_text']): ?>
                    <a href="<?php echo $s_url; ?>" style="padding:13px 28px;border-radius:12px;font-weight:700;font-size:16px;text-decoration:none;<?php echo $s_btn_style; ?>">
                        <?php echo esc_html($s['secondary_btn_text']); ?>
                    </a>
                    <?php endif; ?>
                </div>
                <?php if($s['note']): ?><p style="font-size:13px;color:<?php echo $eyebrow_color; ?>;margin:0;"><?php echo esc_html($s['note']); ?></p><?php endif; ?>
            </div>
            <?php if(!empty($s['stats'])): ?>
            <div style="display:flex;gap:48px;justify-content:center;margin-top:56px;padding-top:48px;border-top:1px solid <?php echo 'gradient'===$st?'rgba(255,255,255,.1)':'var(--sf-border,#e5e7eb)'; ?>;flex-wrap:wrap;">
                <?php foreach($s['stats'] as $stat): ?>
                <div style="text-align:center;">
                    <div style="font-family:'Inter Tight',sans-serif;font-size:2rem;font-weight:900;color:<?php echo $stat_color; ?>;line-height:1;"><?php echo esc_html($stat['stat_num']); ?></div>
                    <div style="font-size:13px;color:<?php echo $stat_label_color; ?>;margin-top:4px;"><?php echo esc_html($stat['stat_label']); ?></div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }
}
