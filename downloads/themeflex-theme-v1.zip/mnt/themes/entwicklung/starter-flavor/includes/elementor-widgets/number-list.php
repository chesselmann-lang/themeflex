<?php
/**
 * Number List / Process Steps Widget
 * Nummerierte oder Icon-basierte Schrittliste mit horizontalem / vertikalem Layout.
 *
 * @package Starter_Flavor
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class Starter_Flavor_Number_List_Widget extends \Elementor\Widget_Base {

	public function get_name()  { return 'sf_number_list'; }
	public function get_title() { return esc_html__( 'Process Steps', 'starter-flavor' ); }
	public function get_icon()  { return 'eicon-number-field'; }
	public function get_categories() { return [ 'starter-flavor' ]; }
	public function get_keywords()   { return [ 'steps', 'process', 'number', 'list', 'how', 'workflow' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'section_steps', [ 'label' => esc_html__( 'Steps', 'starter-flavor' ) ] );

		$repeater = new \Elementor\Repeater();
		$repeater->add_control( 'step_title', [ 'label' => 'Title', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Step Title' ] );
		$repeater->add_control( 'step_desc',  [ 'label' => 'Description', 'type' => \Elementor\Controls_Manager::TEXTAREA, 'default' => 'Describe this step.' ] );
		$repeater->add_control( 'step_icon',  [ 'label' => 'Icon (optional)', 'type' => \Elementor\Controls_Manager::ICONS ] );

		$this->add_control( 'steps', [
			'type'        => \Elementor\Controls_Manager::REPEATER,
			'fields'      => $repeater->get_controls(),
			'default'     => [
				[ 'step_title' => 'Research & Plan',   'step_desc' => 'Define your goals and research the market.' ],
				[ 'step_title' => 'Design & Build',    'step_desc' => 'Create wireframes and develop the product.' ],
				[ 'step_title' => 'Test & Launch',     'step_desc' => 'QA testing followed by a successful launch.' ],
			],
			'title_field' => '{{{ step_title }}}',
		] );

		$this->add_control( 'layout', [
			'label'   => esc_html__( 'Layout', 'starter-flavor' ),
			'type'    => \Elementor\Controls_Manager::CHOOSE,
			'options' => [
				'horizontal' => [ 'title' => 'Horizontal', 'icon' => 'eicon-navigation-horizontal' ],
				'vertical'   => [ 'title' => 'Vertical',   'icon' => 'eicon-navigation-vertical' ],
			],
			'default' => 'horizontal',
		] );
		$this->add_control( 'number_style', [
			'label'   => 'Number Style',
			'type'    => \Elementor\Controls_Manager::SELECT,
			'options' => [ 'filled' => 'Filled', 'outline' => 'Outline', 'icon' => 'Icon only' ],
			'default' => 'filled',
		] );
		$this->add_control( 'connector', [ 'label' => 'Show Connector', 'type' => \Elementor\Controls_Manager::SWITCHER, 'default' => 'yes' ] );

		$this->end_controls_section();

		$this->start_controls_section( 'section_style', [ 'label' => 'Style', 'tab' => \Elementor\Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'number_size', [
			'label'     => 'Circle Size (px)',
			'type'      => \Elementor\Controls_Manager::SLIDER,
			'range'     => [ 'px' => [ 'min' => 32, 'max' => 96 ] ],
			'default'   => [ 'size' => 52 ],
			'selectors' => [ '{{WRAPPER}} .sf-step-num' => 'width:{{SIZE}}px;height:{{SIZE}}px;font-size:calc({{SIZE}}px * 0.38);' ],
		] );
		$this->end_controls_section();
	}

	protected function render() {
		$s      = $this->get_settings_for_display();
		$steps  = $s['steps'];
		$layout = $s['layout'];
		$style  = $s['number_style'];
		$conn   = 'yes' === $s['connector'];
		if ( empty( $steps ) ) return;

		$is_filled  = 'filled' === $style;
		$is_outline = 'outline' === $style;

		$num_css = $is_filled
			? 'background:var(--sf-color-primary,#FF5E2E);color:#fff;'
			: ( $is_outline ? 'background:transparent;color:var(--sf-color-primary,#FF5E2E);border:2px solid var(--sf-color-primary,#FF5E2E);' : 'background:var(--sf-gradient-soft,rgba(255,94,46,.1));color:var(--sf-color-primary,#FF5E2E);' );
		?>
		<div class="sf-steps sf-steps--<?php echo esc_attr($layout); ?>" style="<?php echo 'horizontal'===$layout?'display:grid;grid-template-columns:repeat('.count($steps).',1fr);gap:0;':'display:flex;flex-direction:column;gap:0;'; ?>">
			<?php foreach ( $steps as $i => $step ) :
				$num   = $i + 1;
				$last  = ( $i === count($steps) - 1 );
				$icon  = ! empty( $step['step_icon']['value'] ) ? $step['step_icon']['value'] : '';
			?>
			<div class="sf-step" style="<?php echo 'horizontal'===$layout?'text-align:center;position:relative;':'display:flex;gap:20px;position:relative;'; ?>">
				<!-- Connector line -->
				<?php if ( $conn && ! $last ) : ?>
				<div aria-hidden="true" style="
					<?php if ( 'horizontal' === $layout ) : ?>
					position:absolute;top:26px;left:calc(50% + 26px);right:calc(-50% + 26px);height:2px;background:linear-gradient(90deg,var(--sf-color-primary,#FF5E2E),transparent);
					<?php else : ?>
					position:absolute;left:25px;top:52px;bottom:-24px;width:2px;background:linear-gradient(180deg,var(--sf-color-primary,#FF5E2E),transparent);
					<?php endif; ?>
				"></div>
				<?php endif; ?>

				<!-- Number/Icon circle -->
				<div style="<?php echo 'horizontal'===$layout?'display:flex;justify-content:center;margin-bottom:16px;':'flex-shrink:0;'; ?>">
					<div class="sf-step-num" style="width:52px;height:52px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:700;<?php echo $num_css; ?>">
						<?php if ( $icon ) : ?><i class="<?php echo esc_attr($icon); ?>" aria-hidden="true"></i>
						<?php else : ?><?php echo $num; ?>
						<?php endif; ?>
					</div>
				</div>

				<!-- Text -->
				<div style="<?php echo 'vertical'===$layout?'padding-top:10px;padding-bottom:24px;':''; ?>">
					<h4 style="font-size:16px;font-weight:700;margin:0 0 8px;color:var(--sf-color-title,#1e293b);"><?php echo esc_html($step['step_title']); ?></h4>
					<p style="font-size:14px;color:#64748b;margin:0;line-height:1.6;"><?php echo esc_html($step['step_desc']); ?></p>
				</div>
			</div>
			<?php endforeach; ?>
		</div>
		<style>
		@media(max-width:640px){.sf-steps--horizontal{grid-template-columns:1fr!important;}}
		[data-theme="dark"] .sf-step h4{color:#e2e8f0!important;}
		[data-theme="dark"] .sf-step p{color:#94a3b8!important;}
		</style>
		<?php
	}
}
