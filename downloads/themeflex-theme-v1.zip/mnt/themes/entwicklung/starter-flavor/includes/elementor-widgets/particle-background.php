<?php
/**
 * Particle Background Widget — Canvas-animierte Partikel als Section-Hintergrund.
 * @package Starter_Flavor
 */
if (!defined('ABSPATH')) exit;

class Starter_Flavor_Particle_Background_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'sf_particle_background'; }
    public function get_title() { return esc_html__('Particle Background','starter-flavor'); }
    public function get_icon()  { return 'eicon-sparkles'; }
    public function get_categories() { return ['starter-flavor']; }
    public function get_keywords()   { return ['particle','background','animation','canvas','effect','visual']; }

    protected function register_controls() {
        $this->start_controls_section('section_particles',['label'=>'Particles']);
        $this->add_control('particle_count',['label'=>'Particle Count','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['px'=>['min'=>20,'max'=>300]],'default'=>['size'=>80]]);
        $this->add_control('particle_color',['label'=>'Color','type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#FF5E2E']);
        $this->add_control('particle_size',['label'=>'Max Size (px)','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['px'=>['min'=>1,'max'=>8]],'default'=>['size'=>3]]);
        $this->add_control('connect_lines',['label'=>'Connect Lines','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes']);
        $this->add_control('line_distance',['label'=>'Line Connect Distance','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['px'=>['min'=>50,'max'=>250]],'default'=>['size'=>120],'condition'=>['connect_lines'=>'yes']]);
        $this->add_control('speed',['label'=>'Speed','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['px'=>['min'=>0.1,'max'=>3,'step'=>0.1]],'default'=>['size'=>0.8]]);
        $this->add_control('mouse_interact',['label'=>'Mouse Interaction','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes']);
        $this->end_controls_section();
        $this->start_controls_section('section_content',['label'=>'Content']);
        $this->add_control('bg_color',['label'=>'Background Color','type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#06021D','selectors'=>['{{WRAPPER}} .sf-particles-wrap'=>'background:{{VALUE}};']]);
        $this->add_responsive_control('height',['label'=>'Height','type'=>\Elementor\Controls_Manager::SLIDER,'size_units'=>['px','vh'],'range'=>['px'=>['min'=>200,'max'=>900],'vh'=>['min'=>20,'max'=>100]],'default'=>['unit'=>'vh','size'=>60],'selectors'=>['{{WRAPPER}} .sf-particles-wrap'=>'height:{{SIZE}}{{UNIT}};']]);
        $this->add_control('content_html',['label'=>'Overlay Content (HTML)','type'=>\Elementor\Controls_Manager::WYSIWYG,'default'=>'<h2 style="color:#fff;font-size:2.5rem;font-weight:900;text-align:center">Beautiful Particle Effect</h2><p style="color:rgba(255,255,255,.7);text-align:center;margin-top:12px">Add any content on top of the animation.</p>']);
        $this->end_controls_section();
    }

    protected function render() {
        $s   = $this->get_settings_for_display();
        $uid = 'sfp-'.$this->get_id();
        $config = wp_json_encode([
            'count'    => (int)($s['particle_count']['size'] ?? 80),
            'color'    => $s['particle_color'] ?: '#FF5E2E',
            'size'     => (float)($s['particle_size']['size'] ?? 3),
            'lines'    => 'yes' === $s['connect_lines'],
            'lineDist' => (float)($s['line_distance']['size'] ?? 120),
            'speed'    => (float)($s['speed']['size'] ?? 0.8),
            'mouse'    => 'yes' === $s['mouse_interact'],
        ]);
        ?>
        <div class="sf-particles-wrap" id="<?php echo esc_attr($uid); ?>" style="position:relative;overflow:hidden;background:#06021D;">
            <canvas id="<?php echo esc_attr($uid); ?>-canvas" style="position:absolute;inset:0;width:100%;height:100%;"></canvas>
            <div style="position:relative;z-index:1;display:flex;align-items:center;justify-content:center;height:100%;padding:40px 24px;">
                <?php echo wp_kses_post($s['content_html']); ?>
            </div>
        </div>
        <script>
        (function(){
            var cfg=<?php echo $config; ?>;
            var canvas=document.getElementById('<?php echo esc_js($uid); ?>-canvas');
            var wrap=document.getElementById('<?php echo esc_js($uid); ?>');
            if(!canvas||!wrap)return;
            var ctx=canvas.getContext('2d');
            var W,H,particles=[],mouse={x:null,y:null};
            function hex2rgba(hex,alpha){var r=parseInt(hex.slice(1,3),16),g=parseInt(hex.slice(3,5),16),b=parseInt(hex.slice(5,7),16);return'rgba('+r+','+g+','+b+','+alpha+')';}
            function resize(){W=canvas.width=wrap.offsetWidth;H=canvas.height=wrap.offsetHeight;}
            function mkParticle(){return{x:Math.random()*W,y:Math.random()*H,r:Math.random()*cfg.size+1,vx:(Math.random()-.5)*cfg.speed,vy:(Math.random()-.5)*cfg.speed,o:Math.random()*.8+.2};}
            function init(){resize();particles=[];for(var i=0;i<cfg.count;i++)particles.push(mkParticle());}
            function draw(){
                ctx.clearRect(0,0,W,H);
                particles.forEach(function(p,i){
                    p.x+=p.vx;p.y+=p.vy;
                    if(p.x<0)p.x=W;if(p.x>W)p.x=0;if(p.y<0)p.y=H;if(p.y>H)p.y=0;
                    ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fillStyle=hex2rgba(cfg.color,p.o);ctx.fill();
                    if(cfg.lines){
                        for(var j=i+1;j<particles.length;j++){
                            var q=particles[j];var d=Math.hypot(p.x-q.x,p.y-q.y);
                            if(d<cfg.lineDist){ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(q.x,q.y);ctx.strokeStyle=hex2rgba(cfg.color,(1-d/cfg.lineDist)*.3);ctx.lineWidth=.8;ctx.stroke();}
                        }
                        if(cfg.mouse&&mouse.x){var md=Math.hypot(p.x-mouse.x,p.y-mouse.y);if(md<cfg.lineDist*1.5){ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(mouse.x,mouse.y);ctx.strokeStyle=hex2rgba(cfg.color,(1-md/(cfg.lineDist*1.5))*.5);ctx.lineWidth=1;ctx.stroke();}}
                    }
                });
                requestAnimationFrame(draw);
            }
            if(cfg.mouse){
                wrap.addEventListener('mousemove',function(e){var r=wrap.getBoundingClientRect();mouse.x=e.clientX-r.left;mouse.y=e.clientY-r.top;});
                wrap.addEventListener('mouseleave',function(){mouse.x=null;mouse.y=null;});
            }
            window.addEventListener('resize',init);
            init();draw();
        })();
        </script>
        <?php
    }
}
