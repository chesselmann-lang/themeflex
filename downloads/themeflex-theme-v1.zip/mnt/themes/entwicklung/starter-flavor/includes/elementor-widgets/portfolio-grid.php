<?php
/**
 * Portfolio Grid Widget for Elementor
 * Filterable masonry/grid portfolio with lightbox support.
 *
 * @package Starter_Flavor
 * @since 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Starter_Flavor_Portfolio_Grid_Widget extends \Elementor\Widget_Base {

    public function get_name()       { return 'sf_portfolio_grid'; }
    public function get_title()      { return esc_html__( 'Portfolio Grid', 'starter-flavor' ); }
    public function get_icon()       { return 'eicon-gallery-masonry'; }
    public function get_categories() { return array( 'starter-flavor' ); }
    public function get_keywords()   { return array( 'portfolio','filter','masonry','gallery','work','projects' ); }

    protected function register_controls() {
        $this->start_controls_section('content', array('label'=>esc_html__('Portfolio','starter-flavor'),'tab'=>\Elementor\Controls_Manager::TAB_CONTENT));

        $this->add_control('source', array('label'=>esc_html__('Source','starter-flavor'),'type'=>\Elementor\Controls_Manager::SELECT,'default'=>'cpt','options'=>array('cpt'=>esc_html__('Portfolio CPT','starter-flavor'),'custom'=>esc_html__('Custom Items','starter-flavor'))));

        $this->add_control('posts_per_page', array('label'=>esc_html__('Items','starter-flavor'),'type'=>\Elementor\Controls_Manager::NUMBER,'default'=>9,'min'=>1,'max'=>50,'condition'=>array('source'=>'cpt')));

        $repeater = new \Elementor\Repeater();
        $repeater->add_control('title',    array('label'=>esc_html__('Title','starter-flavor'),    'type'=>\Elementor\Controls_Manager::TEXT));
        $repeater->add_control('category', array('label'=>esc_html__('Category','starter-flavor'), 'type'=>\Elementor\Controls_Manager::TEXT));
        $repeater->add_control('image',    array('label'=>esc_html__('Image','starter-flavor'),    'type'=>\Elementor\Controls_Manager::MEDIA));
        $repeater->add_control('link',     array('label'=>esc_html__('Link','starter-flavor'),     'type'=>\Elementor\Controls_Manager::URL));

        $this->add_control('items', array('label'=>esc_html__('Items','starter-flavor'),'type'=>\Elementor\Controls_Manager::REPEATER,'fields'=>$repeater->get_controls(),'default'=>array(array('title'=>'Project A','category'=>'Web Design'),array('title'=>'Project B','category'=>'Branding'),array('title'=>'Project C','category'=>'Web Design')),'title_field'=>'{{{ title }}}','condition'=>array('source'=>'custom')));

        $this->add_control('show_filter', array('label'=>esc_html__('Filter Bar','starter-flavor'),'type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes'));
        $this->add_control('filter_all_label', array('label'=>esc_html__('All Label','starter-flavor'),'type'=>\Elementor\Controls_Manager::TEXT,'default'=>esc_html__('All','starter-flavor'),'condition'=>array('show_filter'=>'yes')));
        $this->add_responsive_control('columns', array('label'=>esc_html__('Columns','starter-flavor'),'type'=>\Elementor\Controls_Manager::SELECT,'default'=>'3','tablet_default'=>'2','mobile_default'=>'1','options'=>array('2'=>'2','3'=>'3','4'=>'4')));
        $this->add_control('hover_style', array('label'=>esc_html__('Hover Style','starter-flavor'),'type'=>\Elementor\Controls_Manager::SELECT,'default'=>'overlay','options'=>array('overlay'=>esc_html__('Overlay','starter-flavor'),'zoom'=>esc_html__('Zoom','starter-flavor'),'slide'=>esc_html__('Slide Up','starter-flavor'))));

        $this->end_controls_section();
    }

    protected function render() {
        $s      = $this->get_settings_for_display();
        $cols   = absint($s['columns']) ?: 3;
        $uid    = 'sfpg' . $this->get_id();
        $hover  = in_array($s['hover_style']??'overlay', array('overlay','zoom','slide'), true) ? $s['hover_style'] : 'overlay';

        // Build items array
        $items = array();
        if ('cpt' === $s['source']) {
            $query = new WP_Query(array('post_type'=>'sf_portfolio','posts_per_page'=>absint($s['posts_per_page']),'post_status'=>'publish'));
            while ($query->have_posts()) {
                $query->the_post();
                $cat_terms = get_the_terms(get_the_ID(), 'sf_portfolio_category');
                $items[] = array(
                    'title'    => get_the_title(),
                    'category' => $cat_terms ? $cat_terms[0]->name : '',
                    'cat_slug' => $cat_terms ? $cat_terms[0]->slug : '',
                    'img_url'  => get_the_post_thumbnail_url(get_the_ID(),'large') ?: '',
                    'link'     => get_permalink(),
                );
            }
            wp_reset_postdata();
        } else {
            foreach ((array)$s['items'] as $item) {
                $items[] = array(
                    'title'    => $item['title'] ?? '',
                    'category' => $item['category'] ?? '',
                    'cat_slug' => sanitize_title($item['category'] ?? ''),
                    'img_url'  => $item['image']['url'] ?? '',
                    'link'     => $item['link']['url'] ?? '#',
                );
            }
        }

        // Build filter categories
        $cats_seen = array();
        foreach ($items as $item) {
            if ($item['cat_slug']) $cats_seen[$item['cat_slug']] = $item['category'];
        }

        if ('yes' === ($s['show_filter']??'yes') && count($cats_seen) > 0) {
            echo '<div class="sf-pg-filter" id="' . esc_attr($uid) . '-filter">';
            echo '<button class="sf-pg-fbtn active" data-filter="*">' . esc_html($s['filter_all_label'] ?? 'All') . '</button>';
            foreach ($cats_seen as $slug => $name) {
                echo '<button class="sf-pg-fbtn" data-filter="' . esc_attr($slug) . '">' . esc_html($name) . '</button>';
            }
            echo '</div>';
        }

        echo '<div class="sf-pf-grid sf-pfg-cols-' . $cols . ' sf-pfg-hover-' . esc_attr($hover) . '" id="' . esc_attr($uid) . '">';
        foreach ($items as $item) {
            echo '<div class="sf-pf-item" data-cat="' . esc_attr($item['cat_slug']) . '">';
            echo '<div class="sf-pf-inner">';
            if ($item['img_url']) {
                echo '<img src="' . esc_url($item['img_url']) . '" alt="' . esc_attr($item['title']) . '" loading="lazy" class="sf-pf-img">';
            } else {
                echo '<div class="sf-pf-placeholder"><i class="fa-regular fa-image" aria-hidden="true"></i></div>';
            }
            echo '<div class="sf-pf-overlay"><div class="sf-pf-info">';
            echo '<h4 class="sf-pf-title">' . esc_html($item['title']) . '</h4>';
            if ($item['category']) echo '<span class="sf-pf-cat">' . esc_html($item['category']) . '</span>';
            if ($item['link'] && '#' !== $item['link']) echo '<a href="' . esc_url($item['link']) . '" class="sf-pf-link"><i class="fa-solid fa-arrow-up-right-from-square"></i></a>';
            echo '</div></div>';
            echo '</div></div>';
        }
        echo '</div>';
        ?>
        <style>
        .sf-pg-filter{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:24px;}
        .sf-pg-fbtn{padding:8px 20px;border:2px solid var(--sf-primary,#2563eb);border-radius:100px;background:none;color:var(--sf-primary,#2563eb);cursor:pointer;font-weight:600;font-size:.85rem;transition:all .2s;}
        .sf-pg-fbtn.active,.sf-pg-fbtn:hover{background:var(--sf-primary,#2563eb);color:#fff;}
        .sf-pf-grid{display:grid;gap:20px;}
        .sf-pfg-cols-2{grid-template-columns:repeat(2,1fr);}
        .sf-pfg-cols-3{grid-template-columns:repeat(3,1fr);}
        .sf-pfg-cols-4{grid-template-columns:repeat(4,1fr);}
        .sf-pf-item{overflow:hidden;border-radius:12px;}
        .sf-pf-item.hidden{display:none;}
        .sf-pf-inner{position:relative;overflow:hidden;aspect-ratio:4/3;}
        .sf-pf-img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .4s ease;}
        .sf-pf-placeholder{width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:#e2e8f0;font-size:2rem;color:#94a3b8;}
        .sf-pf-overlay{position:absolute;inset:0;background:rgba(15,23,42,.7);display:flex;align-items:center;justify-content:center;opacity:0;transition:opacity .3s ease;}
        .sf-pf-inner:hover .sf-pf-overlay{opacity:1;}
        .sf-pfg-hover-zoom .sf-pf-inner:hover .sf-pf-img{transform:scale(1.1);}
        .sf-pf-info{text-align:center;color:#fff;}
        .sf-pf-title{color:#fff;margin:0 0 4px;font-size:1rem;}
        .sf-pf-cat{font-size:.8rem;opacity:.75;}
        .sf-pf-link{display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:50%;background:#fff;color:#0f172a;margin-top:10px;text-decoration:none;}
        @media(max-width:768px){.sf-pfg-cols-3,.sf-pfg-cols-4{grid-template-columns:repeat(2,1fr);}}
        @media(max-width:480px){.sf-pf-grid{grid-template-columns:1fr!important;}}
        </style>
        <script>
        (function(){
          var filter=document.querySelector('#<?php echo esc_js($uid); ?>-filter');
          var grid=document.getElementById('<?php echo esc_js($uid); ?>');
          if(!filter||!grid) return;
          filter.addEventListener('click',function(e){
            var btn=e.target.closest('.sf-pg-fbtn');
            if(!btn) return;
            filter.querySelectorAll('.sf-pg-fbtn').forEach(function(b){b.classList.remove('active');});
            btn.classList.add('active');
            var f=btn.getAttribute('data-filter');
            grid.querySelectorAll('.sf-pf-item').forEach(function(item){
              item.classList.toggle('hidden', f!=='*' && item.getAttribute('data-cat')!==f);
            });
          });
        })();
        </script>
        <?php
    }
}
