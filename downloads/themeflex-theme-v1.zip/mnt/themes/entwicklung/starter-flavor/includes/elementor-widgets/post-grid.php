<?php
/**
 * Post Grid Widget for Elementor
 * Displays blog posts in configurable grid/list/masonry layouts.
 *
 * @package Starter_Flavor
 * @since 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Starter_Flavor_Post_Grid_Widget extends \Elementor\Widget_Base {

    public function get_name()       { return 'sf_post_grid'; }
    public function get_title()      { return esc_html__( 'Post Grid', 'starter-flavor' ); }
    public function get_icon()       { return 'eicon-posts-grid'; }
    public function get_categories() { return array( 'starter-flavor' ); }
    public function get_keywords()   { return array( 'posts', 'blog', 'grid', 'masonry', 'list' ); }

    protected function register_controls() {

        /* ── QUERY ── */
        $this->start_controls_section( 'section_query', array(
            'label' => esc_html__( 'Query', 'starter-flavor' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ) );

        $this->add_control( 'posts_per_page', array(
            'label'   => esc_html__( 'Posts Per Page', 'starter-flavor' ),
            'type'    => \Elementor\Controls_Manager::NUMBER,
            'default' => 6,
            'min'     => 1, 'max' => 24,
        ) );

        $this->add_control( 'post_categories', array(
            'label'    => esc_html__( 'Categories', 'starter-flavor' ),
            'type'     => \Elementor\Controls_Manager::SELECT2,
            'multiple' => true,
            'options'  => $this->get_category_options(),
            'default'  => array(),
        ) );

        $this->add_control( 'orderby', array(
            'label'   => esc_html__( 'Order By', 'starter-flavor' ),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'default' => 'date',
            'options' => array(
                'date'          => esc_html__( 'Date', 'starter-flavor' ),
                'modified'      => esc_html__( 'Modified', 'starter-flavor' ),
                'title'         => esc_html__( 'Title', 'starter-flavor' ),
                'comment_count' => esc_html__( 'Comments', 'starter-flavor' ),
                'rand'          => esc_html__( 'Random', 'starter-flavor' ),
            ),
        ) );

        $this->add_control( 'order', array(
            'label'   => esc_html__( 'Order', 'starter-flavor' ),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'default' => 'DESC',
            'options' => array(
                'DESC' => esc_html__( 'DESC', 'starter-flavor' ),
                'ASC'  => esc_html__( 'ASC', 'starter-flavor' ),
            ),
        ) );

        $this->end_controls_section();

        /* ── LAYOUT ── */
        $this->start_controls_section( 'section_layout', array(
            'label' => esc_html__( 'Layout', 'starter-flavor' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ) );

        $this->add_control( 'layout', array(
            'label'   => esc_html__( 'Layout', 'starter-flavor' ),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'default' => 'grid',
            'options' => array(
                'grid'    => esc_html__( 'Grid', 'starter-flavor' ),
                'list'    => esc_html__( 'List', 'starter-flavor' ),
                'masonry' => esc_html__( 'Masonry', 'starter-flavor' ),
            ),
        ) );

        $this->add_responsive_control( 'columns', array(
            'label'          => esc_html__( 'Columns', 'starter-flavor' ),
            'type'           => \Elementor\Controls_Manager::SELECT,
            'default'        => '3',
            'tablet_default' => '2',
            'mobile_default' => '1',
            'options'        => array( '1'=>'1','2'=>'2','3'=>'3','4'=>'4' ),
        ) );

        $this->add_control( 'show_image',    array( 'label'=>esc_html__('Show Image','starter-flavor'),    'type'=>\Elementor\Controls_Manager::SWITCHER, 'default'=>'yes' ) );
        $this->add_control( 'show_category', array( 'label'=>esc_html__('Show Category','starter-flavor'), 'type'=>\Elementor\Controls_Manager::SWITCHER, 'default'=>'yes' ) );
        $this->add_control( 'show_date',     array( 'label'=>esc_html__('Show Date','starter-flavor'),     'type'=>\Elementor\Controls_Manager::SWITCHER, 'default'=>'yes' ) );
        $this->add_control( 'show_excerpt',  array( 'label'=>esc_html__('Show Excerpt','starter-flavor'),  'type'=>\Elementor\Controls_Manager::SWITCHER, 'default'=>'yes' ) );
        $this->add_control( 'excerpt_length', array(
            'label'     => esc_html__( 'Excerpt Length', 'starter-flavor' ),
            'type'      => \Elementor\Controls_Manager::NUMBER,
            'default'   => 20,
            'condition' => array( 'show_excerpt' => 'yes' ),
        ) );
        $this->add_control( 'show_read_more', array( 'label'=>esc_html__('Show Read More','starter-flavor'), 'type'=>\Elementor\Controls_Manager::SWITCHER, 'default'=>'yes' ) );
        $this->add_control( 'read_more_text', array(
            'label'     => esc_html__( 'Read More Text', 'starter-flavor' ),
            'type'      => \Elementor\Controls_Manager::TEXT,
            'default'   => esc_html__( 'Read More', 'starter-flavor' ),
            'condition' => array( 'show_read_more' => 'yes' ),
        ) );

        $this->end_controls_section();

        /* ── STYLE ── */
        $this->start_controls_section( 'section_style_card', array(
            'label' => esc_html__( 'Card Style', 'starter-flavor' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ) );

        $this->add_responsive_control( 'card_gap', array(
            'label'      => esc_html__( 'Gap', 'starter-flavor' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => array( 'px' ),
            'range'      => array( 'px' => array( 'min'=>0,'max'=>60 ) ),
            'default'    => array( 'unit'=>'px','size'=>24 ),
            'selectors'  => array( '{{WRAPPER}} .sf-post-grid' => 'gap: {{SIZE}}{{UNIT}};' ),
        ) );

        $this->add_control( 'card_bg', array(
            'label'     => esc_html__( 'Background', 'starter-flavor' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => '#ffffff',
            'selectors' => array( '{{WRAPPER}} .sf-pg-card' => 'background: {{VALUE}};' ),
        ) );

        $this->add_control( 'card_radius', array(
            'label'      => esc_html__( 'Border Radius', 'starter-flavor' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => array( 'px' ),
            'default'    => array( 'unit'=>'px','size'=>12 ),
            'selectors'  => array( '{{WRAPPER}} .sf-pg-card' => 'border-radius: {{SIZE}}{{UNIT}};' ),
        ) );

        $this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), array(
            'name'     => 'card_shadow',
            'selector' => '{{WRAPPER}} .sf-pg-card',
        ) );

        $this->end_controls_section();
    }

    private function get_category_options() {
        $options = array( '' => esc_html__( 'All', 'starter-flavor' ) );
        $cats    = get_categories( array( 'hide_empty' => false ) );
        foreach ( $cats as $cat ) {
            $options[ $cat->term_id ] = $cat->name;
        }
        return $options;
    }

    protected function render() {
        $s = $this->get_settings_for_display();

        $args = array(
            'posts_per_page' => (int) $s['posts_per_page'],
            'orderby'        => sanitize_key( $s['orderby'] ),
            'order'          => 'ASC' === $s['order'] ? 'ASC' : 'DESC',
            'post_status'    => 'publish',
        );

        if ( ! empty( $s['post_categories'] ) ) {
            $args['category__in'] = array_map( 'intval', (array) $s['post_categories'] );
        }

        $query   = new WP_Query( $args );
        $layout  = in_array( $s['layout'], array('grid','list','masonry'), true ) ? $s['layout'] : 'grid';
        $cols    = absint( $s['columns'] ) ?: 3;

        ?>
        <div class="sf-post-grid sf-pg-layout-<?php echo esc_attr($layout); ?> sf-pg-cols-<?php echo esc_attr($cols); ?>">
            <?php while ( $query->have_posts() ) : $query->the_post(); ?>
            <article class="sf-pg-card">
                <?php if ( 'yes' === $s['show_image'] && has_post_thumbnail() ) : ?>
                <a href="<?php the_permalink(); ?>" class="sf-pg-thumb" aria-label="<?php the_title_attribute(); ?>">
                    <?php the_post_thumbnail( 'large' ); ?>
                </a>
                <?php endif; ?>
                <div class="sf-pg-body">
                    <?php if ( 'yes' === $s['show_category'] ) : ?>
                    <div class="sf-pg-cats">
                        <?php
                        $cats = get_the_category();
                        if ( $cats ) {
                            echo '<a href="' . esc_url( get_category_link( $cats[0]->term_id ) ) . '" class="sf-pg-cat">' . esc_html( $cats[0]->name ) . '</a>';
                        }
                        ?>
                    </div>
                    <?php endif; ?>
                    <h3 class="sf-pg-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <?php if ( 'yes' === $s['show_date'] ) : ?>
                    <time class="sf-pg-date" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
                    <?php endif; ?>
                    <?php if ( 'yes' === $s['show_excerpt'] ) : ?>
                    <p class="sf-pg-excerpt"><?php echo wp_kses_post( wp_trim_words( get_the_excerpt(), absint( $s['excerpt_length'] ), '&hellip;' ) ); ?></p>
                    <?php endif; ?>
                    <?php if ( 'yes' === $s['show_read_more'] ) : ?>
                    <a href="<?php the_permalink(); ?>" class="sf-pg-readmore"><?php echo esc_html( $s['read_more_text'] ); ?> <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></a>
                    <?php endif; ?>
                </div>
            </article>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>
        <style>
        .sf-post-grid { display: grid; }
        .sf-pg-cols-1 { grid-template-columns: 1fr; }
        .sf-pg-cols-2 { grid-template-columns: repeat(2,1fr); }
        .sf-pg-cols-3 { grid-template-columns: repeat(3,1fr); }
        .sf-pg-cols-4 { grid-template-columns: repeat(4,1fr); }
        .sf-pg-layout-list { grid-template-columns: 1fr !important; }
        .sf-pg-layout-list .sf-pg-card { display: flex; gap: 24px; align-items: flex-start; }
        .sf-pg-layout-list .sf-pg-thumb { flex: 0 0 220px; }
        .sf-pg-card { overflow: hidden; transition: transform .3s ease, box-shadow .3s ease; }
        .sf-pg-card:hover { transform: translateY(-4px); }
        .sf-pg-thumb img { width: 100%; height: 220px; object-fit: cover; display: block; }
        .sf-pg-body { padding: 20px; }
        .sf-pg-cat { display: inline-block; font-size: .75rem; font-weight: 600; text-transform: uppercase; letter-spacing: .05em; color: var(--sf-primary,#2563eb); margin-bottom: 8px; text-decoration: none; }
        .sf-pg-title { font-size: 1.1rem; margin: 0 0 8px; line-height: 1.4; }
        .sf-pg-title a { color: inherit; text-decoration: none; }
        .sf-pg-title a:hover { color: var(--sf-primary,#2563eb); }
        .sf-pg-date { font-size: .8rem; color: #64748b; display: block; margin-bottom: 10px; }
        .sf-pg-excerpt { font-size: .9rem; color: #64748b; line-height: 1.6; margin: 0 0 12px; }
        .sf-pg-readmore { font-size: .85rem; font-weight: 600; color: var(--sf-primary,#2563eb); text-decoration: none; display: inline-flex; align-items: center; gap: 6px; transition: gap .2s; }
        .sf-pg-readmore:hover { gap: 10px; }
        @media(max-width:768px){.sf-pg-cols-3,.sf-pg-cols-4{grid-template-columns:repeat(2,1fr);}}
        @media(max-width:480px){.sf-post-grid{grid-template-columns:1fr!important;}}
        </style>
        <?php
    }
}
