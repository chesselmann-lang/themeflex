<?php
/**
 * Elementor Price List Widget
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Price List Widget Class
 *
 * @since 1.0.0
 */
class Starter_Flavor_Price_List_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'starter_flavor_price_list';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Price List', 'starter-flavor' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-price-table';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'starter-flavor' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Columns
		$this->add_control(
			'columns',
			array(
				'label'   => esc_html__( 'Columns', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( '1 Column', 'starter-flavor' ),
					'2' => esc_html__( '2 Columns', 'starter-flavor' ),
					'3' => esc_html__( '3 Columns', 'starter-flavor' ),
				),
			)
		);

		// Price List Items Repeater
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'item_name',
			array(
				'label'       => esc_html__( 'Item Name', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Item name', 'starter-flavor' ),
			)
		);

		$repeater->add_control(
			'item_description',
			array(
				'label'       => esc_html__( 'Description', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Item description', 'starter-flavor' ),
				'rows'        => 3,
			)
		);

		$repeater->add_control(
			'item_price',
			array(
				'label'       => esc_html__( 'Price', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( '$9.99', 'starter-flavor' ),
			)
		);

		$repeater->add_control(
			'item_image',
			array(
				'label' => esc_html__( 'Image', 'starter-flavor' ),
				'type'  => \Elementor\Controls_Manager::MEDIA,
			)
		);

		$this->add_control(
			'price_items',
			array(
				'label'      => esc_html__( 'Items', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::REPEATER,
				'fields'     => $repeater->get_controls(),
				'title_field' => '{{{ item_name }}}',
				'default'    => array(
					array(
						'item_name'        => esc_html__( 'Item 1', 'starter-flavor' ),
						'item_description' => esc_html__( 'Description for item 1', 'starter-flavor' ),
						'item_price'       => '$19.99',
					),
				),
			)
		);

		$this->end_controls_section();

		// Style Section
		$this->start_controls_section(
			'style_section',
			array(
				'label' => esc_html__( 'Style', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'name_color',
			array(
				'label'     => esc_html__( 'Name Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#333333',
				'selectors' => array(
					'{{WRAPPER}} .price-list-name' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'price_color',
			array(
				'label'     => esc_html__( 'Price Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#0066cc',
				'selectors' => array(
					'{{WRAPPER}} .price-list-price' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'description_color',
			array(
				'label'     => esc_html__( 'Description Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#666666',
				'selectors' => array(
					'{{WRAPPER}} .price-list-description' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'separator_color',
			array(
				'label'     => esc_html__( 'Separator Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#dddddd',
				'selectors' => array(
					'{{WRAPPER}} .price-list-separator' => 'border-bottom-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$columns = isset( $settings['columns'] ) ? intval( $settings['columns'] ) : 1;
		$price_items = isset( $settings['price_items'] ) ? $settings['price_items'] : array();

		if ( empty( $price_items ) ) {
			echo '<p>' . esc_html__( 'Please add price list items', 'starter-flavor' ) . '</p>';
			return;
		}

		?>
		<div class="price-list-wrapper" style="--columns: <?php echo esc_attr( $columns ); ?>;">
			<div class="price-list-grid">
				<?php foreach ( $price_items as $item ) : ?>
					<?php
					$name = isset( $item['item_name'] ) ? $item['item_name'] : '';
					$description = isset( $item['item_description'] ) ? $item['item_description'] : '';
					$price = isset( $item['item_price'] ) ? $item['item_price'] : '';
					$image = isset( $item['item_image']['url'] ) ? $item['item_image']['url'] : '';
					?>
					<div class="price-list-item">
						<?php if ( ! empty( $image ) ) : ?>
							<div class="price-list-image">
								<img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $name ); ?>" />
							</div>
						<?php endif; ?>
						<div class="price-list-header">
							<div class="price-list-name-section">
								<h3 class="price-list-name"><?php echo esc_html( $name ); ?></h3>
								<div class="price-list-separator"></div>
							</div>
							<span class="price-list-price"><?php echo esc_html( $price ); ?></span>
						</div>
						<?php if ( ! empty( $description ) ) : ?>
							<p class="price-list-description"><?php echo wp_kses_post( $description ); ?></p>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}
}
