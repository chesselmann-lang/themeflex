<?php
/**
 * Elementor Pricing Table Widget
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pricing Table Widget Class
 *
 * @since 1.0.0
 */
class Starter_Flavor_Pricing_Table_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'starter_flavor_pricing_table';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Pricing Table', 'starter-flavor' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-price-table';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'starter-flavor' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Plan Name
		$this->add_control(
			'plan_name',
			array(
				'label'       => esc_html__( 'Plan Name', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Basic Plan', 'starter-flavor' ),
				'placeholder' => esc_html__( 'Enter plan name', 'starter-flavor' ),
			)
		);

		// Price
		$this->add_control(
			'price',
			array(
				'label'       => esc_html__( 'Price', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '99',
				'placeholder' => esc_html__( 'Enter price', 'starter-flavor' ),
			)
		);

		// Currency
		$this->add_control(
			'currency',
			array(
				'label'       => esc_html__( 'Currency', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '$',
				'placeholder' => esc_html__( 'Enter currency symbol', 'starter-flavor' ),
			)
		);

		// Billing Period
		$this->add_control(
			'billing_period',
			array(
				'label'       => esc_html__( 'Billing Period', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'per month', 'starter-flavor' ),
				'placeholder' => esc_html__( 'e.g., per month, per year', 'starter-flavor' ),
			)
		);

		// Description
		$this->add_control(
			'description',
			array(
				'label'       => esc_html__( 'Description', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'Perfect for getting started', 'starter-flavor' ),
				'placeholder' => esc_html__( 'Enter plan description', 'starter-flavor' ),
			)
		);

		// Features
		$this->add_control(
			'features',
			array(
				'label'       => esc_html__( 'Features', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'default'     => "Feature 1\nFeature 2\nFeature 3",
				'placeholder' => esc_html__( 'Enter features (one per line)', 'starter-flavor' ),
			)
		);

		// Button Text
		$this->add_control(
			'button_text',
			array(
				'label'       => esc_html__( 'Button Text', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Choose Plan', 'starter-flavor' ),
			)
		);

		// Button URL
		$this->add_control(
			'button_url',
			array(
				'label'       => esc_html__( 'Button URL', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://example.com', 'starter-flavor' ),
				'default'     => array(
					'url' => '',
				),
			)
		);

		// Featured Plan
		$this->add_control(
			'is_featured',
			array(
				'label'        => esc_html__( 'Featured Plan', 'starter-flavor' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'starter-flavor' ),
				'label_off'    => esc_html__( 'No', 'starter-flavor' ),
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->end_controls_section();

		// Style Section
		$this->start_controls_section(
			'style_section',
			array(
				'label' => esc_html__( 'Style', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Background Color
		$this->add_control(
			'bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FFFFFF',
				'selectors' => array(
					'{{WRAPPER}} .pricing-table' => 'background-color: {{VALUE}}',
				),
			)
		);

		// Price Color
		$this->add_control(
			'price_color',
			array(
				'label'     => esc_html__( 'Price Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FF5E2E',
				'selectors' => array(
					'{{WRAPPER}} .pricing-price' => 'color: {{VALUE}}',
				),
			)
		);

		// Border Radius
		$this->add_control(
			'border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => '8',
					'right'  => '8',
					'bottom' => '8',
					'left'   => '8',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .pricing-table' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$button_url = isset( $settings['button_url']['url'] ) ? $settings['button_url']['url'] : '';
		$is_featured = isset( $settings['is_featured'] ) && 'yes' === $settings['is_featured'];

		$class = $is_featured ? 'pricing-table pricing-table--featured' : 'pricing-table';
		echo '<div class="' . esc_attr( $class ) . '">';

		// Featured Badge
		if ( $is_featured ) {
			echo '<div class="featured-badge">' . esc_html__( 'Featured', 'starter-flavor' ) . '</div>';
		}

		// Plan Name
		if ( ! empty( $settings['plan_name'] ) ) {
			printf(
				'<h3 class="pricing-plan-name">%s</h3>',
				esc_html( $settings['plan_name'] )
			);
		}

		// Description
		if ( ! empty( $settings['description'] ) ) {
			printf(
				'<p class="pricing-description">%s</p>',
				esc_html( $settings['description'] )
			);
		}

		// Price
		echo '<div class="pricing-header">';
		printf(
			'<div class="pricing-price">%s<span class="price-amount">%s</span></div>',
			esc_html( $settings['currency'] ),
			esc_html( $settings['price'] )
		);
		if ( ! empty( $settings['billing_period'] ) ) {
			printf(
				'<p class="pricing-period">%s</p>',
				esc_html( $settings['billing_period'] )
			);
		}
		echo '</div>';

		// Features List
		if ( ! empty( $settings['features'] ) ) {
			$features = array_filter( array_map( 'trim', explode( "\n", $settings['features'] ) ) );
			if ( ! empty( $features ) ) {
				echo '<ul class="pricing-features">';
				foreach ( $features as $feature ) {
					printf( '<li>✓ %s</li>', esc_html( $feature ) );
				}
				echo '</ul>';
			}
		}

		// Button
		if ( ! empty( $settings['button_text'] ) && ! empty( $button_url ) ) {
			printf(
				'<a href="%s" class="button button-primary pricing-button">%s</a>',
				esc_url( $button_url ),
				esc_html( $settings['button_text'] )
			);
		}

		echo '</div>';
	}
}
