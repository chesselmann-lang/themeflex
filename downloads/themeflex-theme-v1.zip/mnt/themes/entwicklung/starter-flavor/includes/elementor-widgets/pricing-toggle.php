<?php
/**
 * Pricing Toggle Widget
 * Switcher zwischen Monthly / Yearly mit Savings-Badge.
 *
 * @package Starter_Flavor
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class Starter_Flavor_Pricing_Toggle_Widget extends \Elementor\Widget_Base {

	public function get_name()  { return 'sf_pricing_toggle'; }
	public function get_title() { return esc_html__( 'Pricing Toggle', 'starter-flavor' ); }
	public function get_icon()  { return 'eicon-price-table'; }
	public function get_categories() { return [ 'starter-flavor' ]; }
	public function get_keywords()   { return [ 'pricing', 'toggle', 'monthly', 'yearly', 'plan', 'subscription' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'section_toggle', [ 'label' => esc_html__( 'Toggle Labels', 'starter-flavor' ) ] );
		$this->add_control( 'label_monthly', [ 'label' => 'Monthly Label', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Monthly' ] );
		$this->add_control( 'label_yearly',  [ 'label' => 'Yearly Label',  'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Yearly' ] );
		$this->add_control( 'savings_badge', [ 'label' => 'Savings Badge', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Save 20%' ] );
		$this->add_control( 'default_period', [ 'label' => 'Default', 'type' => \Elementor\Controls_Manager::SELECT, 'options' => [ 'monthly' => 'Monthly', 'yearly' => 'Yearly' ], 'default' => 'monthly' ] );
		$this->end_controls_section();

		$this->start_controls_section( 'section_plans', [ 'label' => esc_html__( 'Plans', 'starter-flavor' ) ] );

		$repeater = new \Elementor\Repeater();
		$repeater->add_control( 'plan_name',    [ 'label' => 'Plan Name', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Pro' ] );
		$repeater->add_control( 'price_mo',     [ 'label' => 'Monthly Price', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => '$29' ] );
		$repeater->add_control( 'price_yr',     [ 'label' => 'Yearly Price',  'type' => \Elementor\Controls_Manager::TEXT, 'default' => '$23' ] );
		$repeater->add_control( 'period_label', [ 'label' => 'Period Label',  'type' => \Elementor\Controls_Manager::TEXT, 'default' => '/mo' ] );
		$repeater->add_control( 'description',  [ 'label' => 'Description',   'type' => \Elementor\Controls_Manager::TEXTAREA, 'default' => 'Perfect for growing teams.' ] );
		$repeater->add_control( 'features',     [ 'label' => 'Features (one per line)', 'type' => \Elementor\Controls_Manager::TEXTAREA, 'default' => "10 projects\n50 GB storage\nEmail support" ] );
		$repeater->add_control( 'cta_text',     [ 'label' => 'CTA Text', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Get Started' ] );
		$repeater->add_control( 'cta_url',      [ 'label' => 'CTA URL',  'type' => \Elementor\Controls_Manager::URL ] );
		$repeater->add_control( 'featured',     [ 'label' => 'Featured?', 'type' => \Elementor\Controls_Manager::SWITCHER ] );
		$repeater->add_control( 'badge_text',   [ 'label' => 'Badge Text', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Most Popular', 'condition' => [ 'featured' => 'yes' ] ] );

		$this->add_control( 'plans', [
			'type'        => \Elementor\Controls_Manager::REPEATER,
			'fields'      => $repeater->get_controls(),
			'default'     => [
				[ 'plan_name' => 'Starter', 'price_mo' => '$9',  'price_yr' => '$7',  'features' => "3 projects\n5 GB storage\nEmail support",   'cta_text' => 'Get Started' ],
				[ 'plan_name' => 'Pro',     'price_mo' => '$29', 'price_yr' => '$23', 'features' => "20 projects\n50 GB storage\nPriority support", 'cta_text' => 'Get Started', 'featured' => 'yes', 'badge_text' => 'Most Popular' ],
				[ 'plan_name' => 'Agency',  'price_mo' => '$79', 'price_yr' => '$63', 'features' => "Unlimited projects\n500 GB storage\nDedicated support", 'cta_text' => 'Contact Us' ],
			],
			'title_field' => '{{{ plan_name }}}',
		] );

		$this->end_controls_section();
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$uid  = 'sf-pt-' . $this->get_id();
		$def  = $s['default_period'];
		?>
		<div class="sf-pricing-toggle" id="<?php echo esc_attr($uid); ?>" data-default="<?php echo esc_attr($def); ?>">
			<!-- Toggle switch -->
			<div style="display:flex;align-items:center;justify-content:center;gap:16px;margin-bottom:40px;">
				<span class="sf-pt-lbl sf-pt-lbl--mo" style="font-weight:600;font-size:15px;"><?php echo esc_html($s['label_monthly']); ?></span>
				<label style="position:relative;display:inline-block;width:52px;height:28px;cursor:pointer;">
					<input type="checkbox" class="sf-pt-chk" style="opacity:0;width:0;height:0;" <?php echo 'yearly'===$def?'checked':''; ?> />
					<span style="position:absolute;inset:0;background:#e5e7eb;border-radius:28px;transition:.3s;"></span>
					<span class="sf-pt-thumb" style="position:absolute;width:20px;height:20px;border-radius:50%;background:#fff;top:4px;left:4px;transition:.3s;box-shadow:0 1px 4px rgba(0,0,0,.2);"></span>
				</label>
				<span class="sf-pt-lbl sf-pt-lbl--yr" style="font-weight:600;font-size:15px;"><?php echo esc_html($s['label_yearly']); ?></span>
				<?php if ( $s['savings_badge'] ) : ?>
				<span style="background:var(--sf-color-primary,#FF5E2E);color:#fff;font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;"><?php echo esc_html($s['savings_badge']); ?></span>
				<?php endif; ?>
			</div>

			<!-- Plans grid -->
			<div class="sf-pt-grid" style="display:grid;grid-template-columns:repeat(<?php echo count($s['plans']); ?>,1fr);gap:24px;align-items:start;">
				<?php foreach ( $s['plans'] as $plan ) :
					$feat    = 'yes' === $plan['featured'];
					$features = array_filter( array_map( 'trim', explode( "\n", $plan['features'] ) ) );
					$cta_url  = ! empty( $plan['cta_url']['url'] ) ? $plan['cta_url']['url'] : '#';
					$card_style = $feat ? 'border:2px solid var(--sf-color-primary,#FF5E2E);transform:scale(1.04);' : 'border:1px solid #e5e7eb;';
				?>
				<div class="sf-pt-plan<?php echo $feat ? ' sf-pt-featured' : ''; ?>" style="background:#fff;border-radius:16px;padding:32px 24px;position:relative;<?php echo $card_style; ?>box-shadow:0 4px 24px rgba(0,0,0,.07);">
					<?php if ( $feat && ! empty($plan['badge_text']) ) : ?>
					<div style="position:absolute;top:-14px;left:50%;transform:translateX(-50%);background:var(--sf-color-primary,#FF5E2E);color:#fff;font-size:12px;font-weight:700;padding:4px 16px;border-radius:20px;white-space:nowrap;"><?php echo esc_html($plan['badge_text']); ?></div>
					<?php endif; ?>

					<h3 style="font-size:18px;font-weight:700;margin:0 0 8px;"><?php echo esc_html($plan['plan_name']); ?></h3>
					<?php if ( $plan['description'] ) : ?><p style="font-size:13px;color:#64748b;margin:0 0 20px;"><?php echo esc_html($plan['description']); ?></p><?php endif; ?>

					<div class="sf-pt-price" style="margin-bottom:24px;">
						<span class="sf-pt-amount sf-pt-amount--mo<?php echo 'yearly'===$def?' sf-hidden':''; ?>" style="font-size:2.5rem;font-weight:800;color:var(--sf-color-primary,#FF5E2E);"><?php echo esc_html($plan['price_mo']); ?></span>
						<span class="sf-pt-amount sf-pt-amount--yr<?php echo 'monthly'===$def?' sf-hidden':''; ?>" style="font-size:2.5rem;font-weight:800;color:var(--sf-color-primary,#FF5E2E);"><?php echo esc_html($plan['price_yr']); ?></span>
						<span style="font-size:14px;color:#94a3b8;margin-left:4px;"><?php echo esc_html($plan['period_label']); ?></span>
					</div>

					<ul style="list-style:none;padding:0;margin:0 0 28px;display:flex;flex-direction:column;gap:10px;">
						<?php foreach ( $features as $f ) : ?>
						<li style="display:flex;align-items:center;gap:10px;font-size:14px;color:#475569;">
							<i class="fa-solid fa-check" style="color:var(--sf-color-primary,#FF5E2E);font-size:13px;" aria-hidden="true"></i>
							<?php echo esc_html($f); ?>
						</li>
						<?php endforeach; ?>
					</ul>

					<a href="<?php echo esc_url($cta_url); ?>" class="<?php echo $feat ? 'sf-btn-primary' : 'sf-btn-secondary'; ?>"
						style="display:block;text-align:center;padding:13px 24px;border-radius:8px;font-weight:700;font-size:15px;text-decoration:none;<?php echo $feat ? 'background:var(--sf-gradient,var(--sf-color-primary,#FF5E2E));color:#fff;' : 'border:2px solid var(--sf-color-primary,#FF5E2E);color:var(--sf-color-primary,#FF5E2E);'; ?>">
						<?php echo esc_html($plan['cta_text']); ?>
					</a>
				</div>
				<?php endforeach; ?>
			</div>
		</div>
		<style>
		.sf-hidden{display:none!important;}
		[data-theme="dark"] .sf-pt-plan{background:#1e293b!important;border-color:rgba(255,255,255,.08)!important;}
		[data-theme="dark"] .sf-pt-featured{border-color:var(--sf-color-primary,#FF5E2E)!important;}
		@media(max-width:768px){.sf-pt-grid{grid-template-columns:1fr!important;}.sf-pt-featured{transform:none!important;}}
		</style>
		<script>
		(function(){
			var wrap=document.getElementById('<?php echo esc_js($uid); ?>');
			if(!wrap)return;
			var chk=wrap.querySelector('.sf-pt-chk');
			var thumb=wrap.querySelector('.sf-pt-thumb');
			var bg=thumb?thumb.previousElementSibling:null;
			function update(){
				var yearly=chk.checked;
				wrap.querySelectorAll('.sf-pt-amount--mo').forEach(function(el){el.classList.toggle('sf-hidden',yearly);});
				wrap.querySelectorAll('.sf-pt-amount--yr').forEach(function(el){el.classList.toggle('sf-hidden',!yearly);});
				if(bg)bg.style.background=yearly?'var(--sf-color-primary,#FF5E2E)':'#e5e7eb';
				if(thumb)thumb.style.left=yearly?'28px':'4px';
			}
			update();
			chk.addEventListener('change',update);
		})();
		</script>
		<?php
	}
}
