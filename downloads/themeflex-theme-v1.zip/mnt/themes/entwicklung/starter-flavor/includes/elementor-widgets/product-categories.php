<?php
/**
 * WooCommerce Product Categories Widget
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Elementor\Widget_Base' ) ) {
	return;
}

class Starter_Flavor_Product_Categories_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 */
	public function get_name() {
		return 'sf-product-categories';
	}

	/**
	 * Get widget title
	 */
	public function get_title() {
		return esc_html__( 'WooCommerce Product Categories', 'starter-flavor' );
	}

	/**
	 * Get widget icon
	 */
	public function get_icon() {
		return 'eicon-folder';
	}

	/**
	 * Get widget categories
	 */
	public function get_categories() {
		return array( 'starter-flavor-woo' );
	}

	/**
	 * Get widget keywords
	 */
	public function get_keywords() {
		return array( 'product', 'categories', 'woocommerce', 'shop' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {

		// Content Section
		$this->start_controls_section(
			'section_content',
			array(
				'label' => esc_html__( 'Content', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'categories',
			array(
				'label'       => esc_html__( 'Select Categories', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'multiple'    => true,
				'options'     => self::get_product_categories(),
				'description' => esc_html__( 'Leave empty to show all categories', 'starter-flavor' ),
			)
		);

		$this->add_control(
			'hide_empty',
			array(
				'label'   => esc_html__( 'Hide Empty Categories', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'columns',
			array(
				'label'   => esc_html__( 'Columns', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => '3',
				'options' => array(
					'2' => esc_html__( '2 Columns', 'starter-flavor' ),
					'3' => esc_html__( '3 Columns', 'starter-flavor' ),
					'4' => esc_html__( '4 Columns', 'starter-flavor' ),
				),
			)
		);

		$this->add_control(
			'orderby',
			array(
				'label'   => esc_html__( 'Order By', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'name',
				'options' => array(
					'name'  => esc_html__( 'Name', 'starter-flavor' ),
					'count' => esc_html__( 'Product Count', 'starter-flavor' ),
					'id'    => esc_html__( 'ID', 'starter-flavor' ),
				),
			)
		);

		$this->add_control(
			'order',
			array(
				'label'   => esc_html__( 'Order', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'asc',
				'options' => array(
					'asc'  => esc_html__( 'Ascending', 'starter-flavor' ),
					'desc' => esc_html__( 'Descending', 'starter-flavor' ),
				),
			)
		);

		$this->end_controls_section();

		// Display Section
		$this->start_controls_section(
			'section_display',
			array(
				'label' => esc_html__( 'Display Options', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'show_count',
			array(
				'label'   => esc_html__( 'Show Product Count', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'show_description',
			array(
				'label'   => esc_html__( 'Show Description', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'show_image',
			array(
				'label'   => esc_html__( 'Show Category Image', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'card_style',
			array(
				'label'   => esc_html__( 'Card Style', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'default',
				'options' => array(
					'default' => esc_html__( 'Default', 'starter-flavor' ),
					'overlay' => esc_html__( 'Overlay', 'starter-flavor' ),
					'minimal' => esc_html__( 'Minimal', 'starter-flavor' ),
					'featured' => esc_html__( 'Featured', 'starter-flavor' ),
				),
			)
		);

		$this->add_control(
			'hover_effect',
			array(
				'label'   => esc_html__( 'Hover Effect', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'zoom',
				'options' => array(
					'none'  => esc_html__( 'None', 'starter-flavor' ),
					'zoom'  => esc_html__( 'Zoom', 'starter-flavor' ),
					'fade'  => esc_html__( 'Fade', 'starter-flavor' ),
					'slide' => esc_html__( 'Slide', 'starter-flavor' ),
				),
			)
		);

		$this->end_controls_section();

		// Style Section
		$this->start_controls_section(
			'section_style',
			array(
				'label' => esc_html__( 'Style', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'grid_spacing',
			array(
				'label'      => esc_html__( 'Grid Spacing', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'default'    => array(
					'size' => 20,
				),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 60,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .sf-categories-grid' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'image_height',
			array(
				'label'      => esc_html__( 'Image Height', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'default'    => array(
					'size' => 200,
				),
				'range'      => array(
					'px' => array(
						'min' => 100,
						'max' => 400,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .sf-category-image' => 'height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'card_bg_color',
			array(
				'label'     => esc_html__( 'Card Background Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .sf-category-card' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'title_color',
			array(
				'label'     => esc_html__( 'Title Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => array(
					'{{WRAPPER}} .sf-category-title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Get product categories
	 */
	public static function get_product_categories() {
		$categories = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
			)
		);

		$options = array();

		if ( ! is_wp_error( $categories ) ) {
			foreach ( $categories as $category ) {
				$options[ $category->slug ] = $category->name;
			}
		}

		return $options;
	}

	/**
	 * Render widget
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( ! class_exists( 'WooCommerce' ) ) {
			echo wp_kses_post( '<div class="sf-notice error"><p>' . esc_html__( 'WooCommerce is not installed', 'starter-flavor' ) . '</p></div>' );
			return;
		}

		// Build query args
		$args = array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => 'yes' === $settings['hide_empty'] ? true : false,
			'orderby'    => $settings['orderby'],
			'order'      => strtoupper( $settings['order'] ),
		);

		if ( ! empty( $settings['categories'] ) ) {
			$args['slug'] = $settings['categories'];
		}

		$categories = get_terms( $args );

		if ( is_wp_error( $categories ) || empty( $categories ) ) {
			?>
			<div class="sf-no-categories">
				<?php esc_html_e( 'No categories found', 'starter-flavor' ); ?>
			</div>
			<?php
			return;
		}

		// Render grid
		?>
		<div class="sf-categories-grid sf-card-style-<?php echo esc_attr( $settings['card_style'] ); ?> sf-hover-<?php echo esc_attr( $settings['hover_effect'] ); ?>" style="display: grid; grid-template-columns: repeat(<?php echo intval( $settings['columns'] ); ?>, 1fr);">
			<?php
			foreach ( $categories as $category ) {
				$this->render_category_card( $category, $settings );
			}
			?>
		</div>
		<?php
	}

	/**
	 * Render category card
	 */
	private function render_category_card( $category, $settings ) {
		$show_count       = 'yes' === $settings['show_count'];
		$show_description = 'yes' === $settings['show_description'];
		$show_image       = 'yes' === $settings['show_image'];
		$thumbnail_id     = get_term_meta( $category->term_id, 'thumbnail_id', true );
		$image_url        = wp_get_attachment_image_url( $thumbnail_id, 'woocommerce_thumbnail' );
		?>
		<div class="sf-category-card sf-<?php echo esc_attr( $settings['card_style'] ); ?>">
			<a href="<?php echo esc_url( get_term_link( $category ) ); ?>" class="sf-category-link">
				<?php if ( $show_image && $image_url ) : ?>
					<div class="sf-category-image">
						<img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $category->name ); ?>">
					</div>
				<?php endif; ?>

				<div class="sf-category-content">
					<h3 class="sf-category-title"><?php echo esc_html( $category->name ); ?></h3>

					<?php if ( $show_count ) : ?>
						<p class="sf-category-count">
							<?php
							echo wp_kses_post(
								sprintf(
									// translators: %d: product count
									_n(
										'%d product',
										'%d products',
										$category->count,
										'starter-flavor'
									),
									$category->count
								)
							);
							?>
						</p>
					<?php endif; ?>

					<?php
					if ( $show_description && $category->description ) :
						?>
						<p class="sf-category-description"><?php echo wp_kses_post( $category->description ); ?></p>
					<?php endif; ?>
				</div>
			</a>
		</div>
		<?php
	}
}
