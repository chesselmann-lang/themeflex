<?php
/**
 * Radial Progress Widget for Elementor
 * Circular SVG-based animated skill/progress bars.
 *
 * @package Starter_Flavor
 * @since 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Starter_Flavor_Radial_Progress_Widget extends \Elementor\Widget_Base {

    public function get_name()       { return 'sf_radial_progress'; }
    public function get_title()      { return esc_html__( 'Radial Progress', 'starter-flavor' ); }
    public function get_icon()       { return 'eicon-skill-bar'; }
    public function get_categories() { return array( 'starter-flavor' ); }
    public function get_keywords()   { return array( 'skill','progress','radial','circle','gauge' ); }

    protected function register_controls() {

        $this->start_controls_section( 'section_content', array( 'label'=>esc_html__('Content','starter-flavor'), 'tab'=>\Elementor\Controls_Manager::TAB_CONTENT ) );

        $repeater = new \Elementor\Repeater();
        $repeater->add_control('title', array('label'=>esc_html__('Title','starter-flavor'),'type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Design'));
        $repeater->add_control('value', array('label'=>esc_html__('Value (%)','starter-flavor'),'type'=>\Elementor\Controls_Manager::NUMBER,'default'=>80,'min'=>0,'max'=>100));
        $repeater->add_control('color', array('label'=>esc_html__('Colour','starter-flavor'),'type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#2563eb'));

        $this->add_control('items', array(
            'label'   => esc_html__('Skills','starter-flavor'),
            'type'    => \Elementor\Controls_Manager::REPEATER,
            'fields'  => $repeater->get_controls(),
            'default' => array(
                array('title'=>'Design',      'value'=>85,'color'=>'#2563eb'),
                array('title'=>'Development', 'value'=>92,'color'=>'#7c3aed'),
                array('title'=>'Marketing',   'value'=>70,'color'=>'#10b981'),
            ),
            'title_field' => '{{{ title }}} — {{{ value }}}%',
        ));

        $this->add_responsive_control('columns', array(
            'label'=>esc_html__('Columns','starter-flavor'),'type'=>\Elementor\Controls_Manager::SELECT,
            'default'=>'3','tablet_default'=>'2','mobile_default'=>'2',
            'options'=>array('1'=>'1','2'=>'2','3'=>'3','4'=>'4'),
        ));

        $this->add_control('size', array(
            'label'=>esc_html__('Circle Size (px)','starter-flavor'),'type'=>\Elementor\Controls_Manager::SLIDER,
            'size_units'=>array('px'),'range'=>array('px'=>array('min'=>80,'max'=>200)),
            'default'=>array('unit'=>'px','size'=>120),
        ));

        $this->end_controls_section();
    }

    protected function render() {
        $s    = $this->get_settings_for_display();
        $size = isset($s['size']['size']) ? absint($s['size']['size']) : 120;
        $r    = ($size / 2) - 8;
        $circ = round(2 * M_PI * $r, 2);
        $uid  = 'sfrp' . $this->get_id();
        $cols = absint($s['columns']) ?: 3;

        echo '<div class="sf-radial-wrap sf-rp-cols-' . $cols . '" id="' . esc_attr($uid) . '">';
        foreach ($s['items'] as $item) {
            $val  = min(100, max(0, absint($item['value'])));
            $dash = round($circ * $val / 100, 2);
            $col  = esc_attr($item['color']);
            echo '<div class="sf-rp-item">';
            echo '<svg class="sf-rp-svg" width="' . $size . '" height="' . $size . '" viewBox="0 0 ' . $size . ' ' . $size . '">';
            echo '<circle cx="' . ($size/2) . '" cy="' . ($size/2) . '" r="' . $r . '" fill="none" stroke="#e2e8f0" stroke-width="6"/>';
            echo '<circle class="sf-rp-arc" cx="' . ($size/2) . '" cy="' . ($size/2) . '" r="' . $r . '" fill="none" stroke="' . $col . '" stroke-width="6" stroke-linecap="round" stroke-dasharray="' . $circ . '" stroke-dashoffset="' . $circ . '" data-dash="' . $dash . '" data-circ="' . $circ . '" transform="rotate(-90 ' . ($size/2) . ' ' . ($size/2) . ')"/>';
            echo '<text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-size="' . round($size*.18) . '" font-weight="700" fill="' . $col . '">' . $val . '%</text>';
            echo '</svg>';
            echo '<p class="sf-rp-label">' . esc_html($item['title']) . '</p>';
            echo '</div>';
        }
        echo '</div>';
        ?>
        <style>
        .sf-radial-wrap{display:grid;gap:24px;text-align:center;}
        .sf-rp-cols-2{grid-template-columns:repeat(2,1fr);}
        .sf-rp-cols-3{grid-template-columns:repeat(3,1fr);}
        .sf-rp-cols-4{grid-template-columns:repeat(4,1fr);}
        .sf-rp-svg{display:block;margin:0 auto;}
        .sf-rp-arc{transition:stroke-dashoffset 1.4s cubic-bezier(.4,0,.2,1);}
        .sf-rp-label{margin-top:8px;font-weight:600;font-size:.9rem;}
        @media(max-width:480px){.sf-radial-wrap{grid-template-columns:repeat(2,1fr)!important;}}
        </style>
        <script>
        (function(){
          var arcs = document.querySelectorAll('#<?php echo esc_js($uid); ?> .sf-rp-arc');
          if(!arcs.length) return;
          var obs = new IntersectionObserver(function(entries){
            entries.forEach(function(e){
              if(e.isIntersecting){
                var arc=e.target, circ=parseFloat(arc.getAttribute('data-circ')), dash=parseFloat(arc.getAttribute('data-dash'));
                arc.style.strokeDashoffset = circ - dash;
                obs.unobserve(arc);
              }
            });
          },{threshold:.3});
          arcs.forEach(function(a){obs.observe(a);});
        })();
        </script>
        <?php
    }
}
