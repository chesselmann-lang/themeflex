<?php
/**
 * Scroll Trigger Animation Container Widget.
 * @package Starter_Flavor
 */
if (!defined('ABSPATH')) exit;

class Starter_Flavor_Scroll_Trigger_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'sf_scroll_trigger'; }
    public function get_title() { return esc_html__('Scroll Animation','starter-flavor'); }
    public function get_icon()  { return 'eicon-animation'; }
    public function get_categories() { return ['starter-flavor']; }
    public function get_keywords()   { return ['scroll','animation','trigger','reveal','intersection','entrance']; }

    protected function register_controls() {
        $this->start_controls_section('s_anim',['label'=>'Animation']);
        $this->add_control('animation',['label'=>'Animation','type'=>\Elementor\Controls_Manager::SELECT,'options'=>[
            'fade-up'    =>'Fade Up','fade-down'=>'Fade Down','fade-left'=>'Fade Left','fade-right'=>'Fade Right',
            'zoom-in'    =>'Zoom In','zoom-out'=>'Zoom Out','flip-left'=>'Flip Left','flip-right'=>'Flip Right',
            'slide-up'   =>'Slide Up','bounce'=>'Bounce','rotate-in'=>'Rotate In',
        ],'default'=>'fade-up']);
        $this->add_control('duration',['label'=>'Duration (ms)','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['ms'=>['min'=>200,'max'=>2000,'step'=>100]],'default'=>['size'=>600]]);
        $this->add_control('delay',['label'=>'Delay (ms)','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['ms'=>['min'=>0,'max'=>2000,'step'=>100]],'default'=>['size'=>0]]);
        $this->add_control('threshold',['label'=>'Trigger Threshold (%)','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['px'=>['min'=>0,'max'=>100,'step'=>5]],'default'=>['size'=>20]]);
        $this->add_control('once',['label'=>'Animate Only Once','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes']);
        $this->end_controls_section();

        $this->start_controls_section('s_content',['label'=>'Content']);
        $this->add_control('content_html',['label'=>'Content (HTML)','type'=>\Elementor\Controls_Manager::WYSIWYG,'default'=>'<div style="background:var(--sf-bg-2,#f8fafc);border-radius:12px;padding:32px;text-align:center;"><h3>Scroll to reveal</h3><p>This content animates when it enters the viewport.</p></div>']);
        $this->end_controls_section();
    }

    protected function render() {
        $s   = $this->get_settings_for_display();
        $uid = 'sfst-'.$this->get_id();
        $anim = $s['animation'] ?? 'fade-up';
        $dur  = (int)(!empty($s['duration']['size']) ? $s['duration']['size'] : 600);
        $del  = (int)(!empty($s['delay']['size'])    ? $s['delay']['size']    : 0);
        $thr  = (float)(!empty($s['threshold']['size']) ? $s['threshold']['size'] / 100 : 0.2);
        $once = 'yes' === ($s['once'] ?? 'yes');

        // Initial hidden states
        $init = match($anim) {
            'fade-up'    => 'opacity:0;transform:translateY(40px);',
            'fade-down'  => 'opacity:0;transform:translateY(-40px);',
            'fade-left'  => 'opacity:0;transform:translateX(40px);',
            'fade-right' => 'opacity:0;transform:translateX(-40px);',
            'zoom-in'    => 'opacity:0;transform:scale(0.85);',
            'zoom-out'   => 'opacity:0;transform:scale(1.15);',
            'flip-left'  => 'opacity:0;transform:perspective(600px) rotateY(-60deg);',
            'flip-right' => 'opacity:0;transform:perspective(600px) rotateY(60deg);',
            'slide-up'   => 'opacity:0;transform:translateY(60px);',
            'bounce'     => 'opacity:0;transform:translateY(30px);',
            'rotate-in'  => 'opacity:0;transform:rotate(-10deg) scale(0.9);',
            default      => 'opacity:0;',
        };
        ?>
        <div id="<?php echo esc_attr($uid); ?>" style="<?php echo $init; ?>transition:opacity <?php echo $dur; ?>ms ease <?php echo $del; ?>ms, transform <?php echo $dur; ?>ms ease <?php echo $del; ?>ms;">
            <?php echo wp_kses_post($s['content_html']); ?>
        </div>
        <script>
        (function(){
            var el=document.getElementById('<?php echo esc_js($uid); ?>');
            if(!el||!('IntersectionObserver' in window))return;
            var once=<?php echo $once?'true':'false'; ?>;
            var anim='<?php echo esc_js($anim); ?>';
            var revealed=false;
            function reveal(){
                el.style.opacity='1';el.style.transform='none';
                if(anim==='bounce'){
                    var p=0;var dir=1;var interval=setInterval(function(){
                        p+=dir*3;if(p>8||p<0)dir*=-1;if(Math.abs(p)<0.5&&dir<0){clearInterval(interval);el.style.transform='none';return;}
                        el.style.transform='translateY(-'+Math.abs(p)+'px)';
                    },16);
                }
                revealed=true;
            }
            function hide(){
                if(once)return;
                el.style.opacity='0';
                if(anim==='fade-up')el.style.transform='translateY(40px)';
                else el.style.transform='';
                revealed=false;
            }
            new IntersectionObserver(function(entries){
                entries.forEach(function(e){
                    if(e.isIntersecting&&!revealed)reveal();
                    else if(!e.isIntersecting&&!once&&revealed)hide();
                });
            },{threshold:<?php echo $thr; ?>}).observe(el);
        })();
        </script>
        <?php
    }
}
