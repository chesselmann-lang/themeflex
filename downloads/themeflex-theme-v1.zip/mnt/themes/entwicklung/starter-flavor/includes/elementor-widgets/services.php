<?php
/**
 * Elementor Services/Features Widget
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Services Widget Class
 *
 * @since 1.0.0
 */
class Starter_Flavor_Services_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'starter_flavor_services';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Services / Features', 'starter-flavor' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-featured-image';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'starter-flavor' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Service Icon
		$this->add_control(
			'service_icon',
			array(
				'label'       => esc_html__( 'Icon', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::ICONS,
				'default'     => array(
					'value'   => 'fas fa-star',
					'library' => 'fa-solid',
				),
			)
		);

		// Service Title
		$this->add_control(
			'service_title',
			array(
				'label'       => esc_html__( 'Title', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Premium Features', 'starter-flavor' ),
				'placeholder' => esc_html__( 'Enter service title', 'starter-flavor' ),
			)
		);

		// Service Description
		$this->add_control(
			'service_description',
			array(
				'label'       => esc_html__( 'Description', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'A brief description of your service or feature.', 'starter-flavor' ),
				'placeholder' => esc_html__( 'Enter service description', 'starter-flavor' ),
			)
		);

		// Service Link
		$this->add_control(
			'service_link',
			array(
				'label'       => esc_html__( 'Link', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://example.com', 'starter-flavor' ),
				'default'     => array(
					'url' => '',
				),
			)
		);

		// Link Text
		$this->add_control(
			'link_text',
			array(
				'label'       => esc_html__( 'Link Text', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Learn More', 'starter-flavor' ),
				'placeholder' => esc_html__( 'Enter link text', 'starter-flavor' ),
			)
		);

		$this->end_controls_section();

		// Layout Section
		$this->start_controls_section(
			'layout_section',
			array(
				'label' => esc_html__( 'Layout', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Layout Option
		$this->add_control(
			'icon_position',
			array(
				'label'   => esc_html__( 'Icon Position', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'top',
				'options' => array(
					'top'   => esc_html__( 'Icon Top', 'starter-flavor' ),
					'left'  => esc_html__( 'Icon Left', 'starter-flavor' ),
					'right' => esc_html__( 'Icon Right', 'starter-flavor' ),
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Icon
		$this->start_controls_section(
			'icon_style_section',
			array(
				'label' => esc_html__( 'Icon', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Icon Size
		$this->add_control(
			'icon_size',
			array(
				'label'      => esc_html__( 'Icon Size', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 10,
						'max' => 100,
					),
				),
				'default'    => array(
					'size' => 48,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .service-icon' => 'font-size: {{SIZE}}{{UNIT}}',
				),
			)
		);

		// Icon Color
		$this->add_control(
			'icon_color',
			array(
				'label'     => esc_html__( 'Icon Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FF5E2E',
				'selectors' => array(
					'{{WRAPPER}} .service-icon' => 'color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Box
		$this->start_controls_section(
			'box_style_section',
			array(
				'label' => esc_html__( 'Box', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Box Background
		$this->add_control(
			'box_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FFFFFF',
				'selectors' => array(
					'{{WRAPPER}} .service-box' => 'background-color: {{VALUE}}',
				),
			)
		);

		// Box Border Radius
		$this->add_control(
			'box_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => '8',
					'right'  => '8',
					'bottom' => '8',
					'left'   => '8',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .service-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				),
			)
		);

		// Box Shadow
		$this->add_control(
			'box_shadow',
			array(
				'label'     => esc_html__( 'Box Shadow', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::BOX_SHADOW,
				'default'   => array(
					'horizontal' => '0',
					'vertical'   => '2',
					'blur'       => '8',
					'spread'     => '0',
					'color'      => 'rgba(0,0,0,0.1)',
				),
				'selectors' => array(
					'{{WRAPPER}} .service-box' => 'box-shadow: {{HORIZONTAL}}{{UNIT}} {{VERTICAL}}{{UNIT}} {{BLUR}}{{UNIT}} {{SPREAD}}{{UNIT}} {{COLOR}}',
				),
			)
		);

		// Hover Shadow
		$this->add_control(
			'box_hover_shadow',
			array(
				'label'     => esc_html__( 'Hover Shadow', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::BOX_SHADOW,
				'default'   => array(
					'horizontal' => '0',
					'vertical'   => '12',
					'blur'       => '24',
					'spread'     => '0',
					'color'      => 'rgba(0,0,0,0.15)',
				),
				'selectors' => array(
					'{{WRAPPER}} .service-box:hover' => 'box-shadow: {{HORIZONTAL}}{{UNIT}} {{VERTICAL}}{{UNIT}} {{BLUR}}{{UNIT}} {{SPREAD}}{{UNIT}} {{COLOR}}',
				),
			)
		);

		// Padding
		$this->add_control(
			'box_padding',
			array(
				'label'      => esc_html__( 'Padding', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => '30',
					'right'  => '20',
					'bottom' => '30',
					'left'   => '20',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .service-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Typography
		$this->start_controls_section(
			'typography_style_section',
			array(
				'label' => esc_html__( 'Typography', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Title Color
		$this->add_control(
			'title_color',
			array(
				'label'     => esc_html__( 'Title Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#1F2937',
				'selectors' => array(
					'{{WRAPPER}} .service-title' => 'color: {{VALUE}}',
				),
			)
		);

		// Description Color
		$this->add_control(
			'description_color',
			array(
				'label'     => esc_html__( 'Description Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#6B7280',
				'selectors' => array(
					'{{WRAPPER}} .service-description' => 'color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$icon_position = isset( $settings['icon_position'] ) ? $settings['icon_position'] : 'top';
		$link_url = isset( $settings['service_link']['url'] ) ? $settings['service_link']['url'] : '';

		$wrapper_class = 'service-box service-box--' . esc_attr( $icon_position );
		echo '<div class="' . esc_attr( $wrapper_class ) . '">';

		// Icon
		if ( ! empty( $settings['service_icon'] ) ) {
			echo '<div class="service-icon-wrapper">';
			\Elementor\Icons_Manager::render_icon(
				$settings['service_icon'],
				array( 'aria-hidden' => 'true', 'class' => 'service-icon' )
			);
			echo '</div>';
		}

		// Content Wrapper
		echo '<div class="service-content">';

		// Title
		if ( ! empty( $settings['service_title'] ) ) {
			printf(
				'<h3 class="service-title">%s</h3>',
				esc_html( $settings['service_title'] )
			);
		}

		// Description
		if ( ! empty( $settings['service_description'] ) ) {
			printf(
				'<p class="service-description">%s</p>',
				esc_html( $settings['service_description'] )
			);
		}

		// Link
		if ( ! empty( $link_url ) && ! empty( $settings['link_text'] ) ) {
			printf(
				'<a href="%s" class="service-link">%s <span class="arrow">→</span></a>',
				esc_url( $link_url ),
				esc_html( $settings['link_text'] )
			);
		}

		echo '</div>';
		echo '</div>';

		// Inline Styles
		?>
		<style>
			.service-box {
				display: flex;
				gap: 20px;
				align-items: flex-start;
				transition: all 0.3s ease;
			}

			.service-box--top {
				flex-direction: column;
				align-items: center;
				text-align: center;
			}

			.service-box--left {
				flex-direction: row;
				align-items: flex-start;
			}

			.service-box--right {
				flex-direction: row-reverse;
				align-items: flex-start;
			}

			.service-icon-wrapper {
				display: flex;
				align-items: center;
				justify-content: center;
				flex-shrink: 0;
			}

			.service-box--top .service-icon-wrapper {
				margin-bottom: 10px;
			}

			.service-box--left .service-icon-wrapper,
			.service-box--right .service-icon-wrapper {
				min-width: 60px;
				height: 60px;
				align-items: center;
				justify-content: center;
			}

			.service-content {
				flex: 1;
			}

			.service-title {
				margin: 0 0 10px 0;
				font-size: 18px;
				font-weight: 600;
			}

			.service-description {
				margin: 0 0 15px 0;
				line-height: 1.6;
			}

			.service-link {
				display: inline-block;
				text-decoration: none;
				color: #FF5E2E;
				font-weight: 500;
				transition: all 0.3s ease;
			}

			.service-link .arrow {
				display: inline-block;
				margin-left: 5px;
				transition: transform 0.3s ease;
			}

			.service-box:hover .service-link .arrow {
				transform: translateX(3px);
			}
		</style>
		<?php
	}
}
