<?php
/**
 * Elementor Starter Flavor Form Widget
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * SF Form Widget Class
 *
 * @since 1.0.0
 */
class Starter_Flavor_Form_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'starter_flavor_form';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'SF Contact Form', 'starter-flavor' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-form-horizontal';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'starter-flavor' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Form', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Get available forms
		$forms = get_posts(
			array(
				'post_type'      => 'sf_form',
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);

		$form_options = array( '' => esc_html__( 'Select a Form', 'starter-flavor' ) );
		foreach ( $forms as $form ) {
			$form_options[ $form->ID ] = $form->post_title;
		}

		// Form Selection
		$this->add_control(
			'form_id',
			array(
				'label'   => esc_html__( 'Select Form', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => '',
				'options' => $form_options,
			)
		);

		// Form Label Display
		$this->add_control(
			'show_labels',
			array(
				'label'        => esc_html__( 'Show Labels', 'starter-flavor' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'starter-flavor' ),
				'label_off'    => esc_html__( 'No', 'starter-flavor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->end_controls_section();

		// Style Section - Form
		$this->start_controls_section(
			'style_form_section',
			array(
				'label' => esc_html__( 'Form', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'form_gap',
			array(
				'label'      => esc_html__( 'Field Spacing', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 50,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 20,
				),
				'selectors'  => array(
					'{{WRAPPER}} .sf-form-group' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Input
		$this->start_controls_section(
			'style_input_section',
			array(
				'label' => esc_html__( 'Input Fields', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Input Typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'input_typography',
				'selector' => '{{WRAPPER}} .sf-input',
			)
		);

		// Input Background
		$this->add_control(
			'input_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .sf-input' => 'background-color: {{VALUE}};',
				),
			)
		);

		// Input Border
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'input_border',
				'selector' => '{{WRAPPER}} .sf-input',
			)
		);

		// Input Padding
		$this->add_responsive_control(
			'input_padding',
			array(
				'label'      => esc_html__( 'Padding', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => 12,
					'right'  => 14,
					'bottom' => 12,
					'left'   => 14,
				),
				'selectors'  => array(
					'{{WRAPPER}} .sf-input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		// Input Focus Color
		$this->add_control(
			'input_focus_border_color',
			array(
				'label'     => esc_html__( 'Focus Border Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#3366ff',
				'selectors' => array(
					'{{WRAPPER}} .sf-input:focus' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Label
		$this->start_controls_section(
			'style_label_section',
			array(
				'label' => esc_html__( 'Label', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Label Typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'label_typography',
				'selector' => '{{WRAPPER}} .sf-label',
			)
		);

		// Label Color
		$this->add_control(
			'label_color',
			array(
				'label'     => esc_html__( 'Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#333',
				'selectors' => array(
					'{{WRAPPER}} .sf-label' => 'color: {{VALUE}};',
				),
			)
		);

		// Label Spacing
		$this->add_responsive_control(
			'label_spacing',
			array(
				'label'      => esc_html__( 'Spacing', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 30,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 8,
				),
				'selectors'  => array(
					'{{WRAPPER}} .sf-label' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Button
		$this->start_controls_section(
			'style_button_section',
			array(
				'label' => esc_html__( 'Submit Button', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Button Typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'button_typography',
				'selector' => '{{WRAPPER}} .sf-submit-btn',
			)
		);

		// Button Background
		$this->add_control(
			'button_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#3366ff',
				'selectors' => array(
					'{{WRAPPER}} .sf-submit-btn' => 'background-color: {{VALUE}};',
				),
			)
		);

		// Button Hover Background
		$this->add_control(
			'button_hover_bg_color',
			array(
				'label'     => esc_html__( 'Hover Background Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#254fc7',
				'selectors' => array(
					'{{WRAPPER}} .sf-submit-btn:hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		// Button Text Color
		$this->add_control(
			'button_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => array(
					'{{WRAPPER}} .sf-submit-btn' => 'color: {{VALUE}};',
				),
			)
		);

		// Button Padding
		$this->add_responsive_control(
			'button_padding',
			array(
				'label'      => esc_html__( 'Padding', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => 14,
					'right'  => 30,
					'bottom' => 14,
					'left'   => 30,
				),
				'selectors'  => array(
					'{{WRAPPER}} .sf-submit-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		// Button Border Radius
		$this->add_responsive_control(
			'button_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => 4,
					'right'  => 4,
					'bottom' => 4,
					'left'   => 4,
				),
				'selectors'  => array(
					'{{WRAPPER}} .sf-submit-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		// Button Width
		$this->add_control(
			'button_width',
			array(
				'label'   => esc_html__( 'Width', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'auto',
				'options' => array(
					'auto'  => esc_html__( 'Auto', 'starter-flavor' ),
					'full'  => esc_html__( 'Full Width', 'starter-flavor' ),
					'50'    => esc_html__( '50%', 'starter-flavor' ),
				),
				'selectors' => array(
					'{{WRAPPER}} .sf-submit-btn' => 'width: {{VALUE}}' . ( 'full' === $this->get_settings( 'button_width' ) ? ';' : ';' ),
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['form_id'] ) ) {
			echo '<p>' . esc_html__( 'Please select a form', 'starter-flavor' ) . '</p>';
			return;
		}

		// Render the form using the shortcode
		echo do_shortcode( '[sf_form id="' . intval( $settings['form_id'] ) . '"]' );
	}

	/**
	 * Render widget output in the editor
	 */
	protected function content_template() {
		?>
		<# if ( settings.form_id ) { #>
			<div class="elementor-placeholder">
				<div class="elementor-placeholder-content">
					<span class="elementor-state-icon"><i class="eicon-form-horizontal"></i></span>
					<span class="elementor-state-title"><?php esc_html_e( 'SF Contact Form', 'starter-flavor' ); ?></span>
					<span class="elementor-state-description"><?php esc_html_e( 'Form will be rendered here', 'starter-flavor' ); ?></span>
				</div>
			</div>
		<# } else { #>
			<div class="elementor-placeholder">
				<div class="elementor-placeholder-content">
					<span class="elementor-state-icon"><i class="eicon-form-horizontal"></i></span>
					<span class="elementor-state-title"><?php esc_html_e( 'Select a Form', 'starter-flavor' ); ?></span>
					<span class="elementor-state-description"><?php esc_html_e( 'Please select a form from the widget settings', 'starter-flavor' ); ?></span>
				</div>
			</div>
		<# } #>
		<?php
	}
}

// Register widget
if ( function_exists( 'elementor_register_widget' ) ) {
	elementor_register_widget( new Starter_Flavor_Form_Widget() );
}
