<?php
/**
 * Share Buttons Widget for Elementor
 *
 * @package Starter_Flavor
 * @since 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Starter_Flavor_Share_Buttons_Widget extends \Elementor\Widget_Base {

    public function get_name()       { return 'sf_share_buttons'; }
    public function get_title()      { return esc_html__( 'Share Buttons', 'starter-flavor' ); }
    public function get_icon()       { return 'eicon-social-icons'; }
    public function get_categories() { return array( 'starter-flavor' ); }
    public function get_keywords()   { return array( 'share','social','facebook','twitter','linkedin' ); }

    private static $networks = array(
        'facebook'  => array( 'label'=>'Facebook',  'icon'=>'fa-brands fa-facebook-f',  'color'=>'#1877f2', 'url'=>'https://www.facebook.com/sharer/sharer.php?u=' ),
        'twitter'   => array( 'label'=>'X / Twitter','icon'=>'fa-brands fa-x-twitter',   'color'=>'#000000', 'url'=>'https://twitter.com/intent/tweet?url=' ),
        'linkedin'  => array( 'label'=>'LinkedIn',  'icon'=>'fa-brands fa-linkedin-in',  'color'=>'#0a66c2', 'url'=>'https://www.linkedin.com/sharing/share-offsite/?url=' ),
        'whatsapp'  => array( 'label'=>'WhatsApp',  'icon'=>'fa-brands fa-whatsapp',     'color'=>'#25d366', 'url'=>'https://api.whatsapp.com/send?text=' ),
        'pinterest' => array( 'label'=>'Pinterest', 'icon'=>'fa-brands fa-pinterest-p',  'color'=>'#e60023', 'url'=>'https://pinterest.com/pin/create/button/?url=' ),
        'email'     => array( 'label'=>'Email',     'icon'=>'fa-solid fa-envelope',      'color'=>'#64748b', 'url'=>'mailto:?subject=Check this out&body=' ),
        'copy'      => array( 'label'=>'Copy Link', 'icon'=>'fa-solid fa-link',          'color'=>'#475569', 'url'=>'' ),
    );

    protected function register_controls() {
        $this->start_controls_section('content', array('label'=>esc_html__('Networks','starter-flavor'),'tab'=>\Elementor\Controls_Manager::TAB_CONTENT));

        $network_opts = array();
        foreach (self::$networks as $key => $net) { $network_opts[$key] = $net['label']; }

        $this->add_control('networks', array(
            'label'    => esc_html__('Networks','starter-flavor'),
            'type'     => \Elementor\Controls_Manager::SELECT2,
            'multiple' => true,
            'options'  => $network_opts,
            'default'  => array('facebook','twitter','linkedin','whatsapp'),
        ));

        $this->add_control('style', array('label'=>esc_html__('Style','starter-flavor'),'type'=>\Elementor\Controls_Manager::SELECT,'default'=>'filled','options'=>array('filled'=>esc_html__('Filled','starter-flavor'),'outline'=>esc_html__('Outline','starter-flavor'),'icon_only'=>esc_html__('Icon Only','starter-flavor'),'pill'=>esc_html__('Pill','starter-flavor'))));
        $this->add_control('show_label', array('label'=>esc_html__('Show Label','starter-flavor'),'type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes','condition'=>array('style!'=>'icon_only')));
        $this->add_control('align', array('label'=>esc_html__('Alignment','starter-flavor'),'type'=>\Elementor\Controls_Manager::CHOOSE,'options'=>array('flex-start'=>array('title'=>'Left','icon'=>'eicon-text-align-left'),'center'=>array('title'=>'Center','icon'=>'eicon-text-align-center'),'flex-end'=>array('title'=>'Right','icon'=>'eicon-text-align-right')),'default'=>'flex-start','selectors'=>array('{{WRAPPER}} .sf-share-btns'=>'justify-content:{{VALUE}};')));
        $this->add_responsive_control('gap', array('label'=>esc_html__('Gap','starter-flavor'),'type'=>\Elementor\Controls_Manager::SLIDER,'size_units'=>array('px'),'default'=>array('unit'=>'px','size'=>8),'selectors'=>array('{{WRAPPER}} .sf-share-btns'=>'gap:{{SIZE}}{{UNIT}};')));

        $this->end_controls_section();
    }

    protected function render() {
        $s        = $this->get_settings_for_display();
        $networks = (array) ($s['networks'] ?? array('facebook','twitter','linkedin'));
        $style    = $s['style'];
        $show_lbl = 'yes' === ($s['show_label'] ?? 'yes') && 'icon_only' !== $style;
        $page_url = rawurlencode( get_permalink() ?: home_url( $_SERVER['REQUEST_URI'] ) );
        $uid      = 'sfsh' . $this->get_id();

        echo '<div class="sf-share-btns sf-sb-' . esc_attr($style) . '" id="' . esc_attr($uid) . '">';
        foreach ($networks as $key) {
            if (!isset(self::$networks[$key])) continue;
            $net = self::$networks[$key];
            $col = esc_attr($net['color']);

            if ('copy' === $key) {
                echo '<button class="sf-sb-btn sf-sb-copy" data-url="' . esc_attr(rawurldecode($page_url)) . '" style="--sb-color:' . $col . ';" aria-label="' . esc_attr($net['label']) . '">';
            } else {
                $href = esc_url($net['url'] . $page_url);
                echo '<a href="' . $href . '" class="sf-sb-btn" target="_blank" rel="noopener noreferrer" style="--sb-color:' . $col . ';" aria-label="' . esc_attr($net['label']) . '">';
            }
            echo '<i class="' . esc_attr($net['icon']) . '" aria-hidden="true"></i>';
            if ($show_lbl) echo '<span>' . esc_html($net['label']) . '</span>';
            echo ('copy' === $key) ? '</button>' : '</a>';
        }
        echo '</div>';
        ?>
        <style>
        .sf-share-btns{display:flex;flex-wrap:wrap;align-items:center;}
        .sf-sb-btn{display:inline-flex;align-items:center;gap:6px;padding:9px 16px;border-radius:8px;font-size:.85rem;font-weight:600;text-decoration:none;cursor:pointer;transition:all .2s ease;border:none;}
        .sf-sb-filled .sf-sb-btn{background:var(--sb-color);color:#fff;}
        .sf-sb-outline .sf-sb-btn{background:transparent;border:2px solid var(--sb-color);color:var(--sb-color);}
        .sf-sb-icon_only .sf-sb-btn{background:var(--sb-color);color:#fff;padding:10px;border-radius:50%;}
        .sf-sb-pill .sf-sb-btn{background:var(--sb-color);color:#fff;border-radius:100px;}
        .sf-sb-btn:hover{filter:brightness(1.1);transform:translateY(-2px);}
        </style>
        <script>
        (function(){
          var btns=document.querySelectorAll('#<?php echo esc_js($uid); ?> .sf-sb-copy');
          btns.forEach(function(b){
            b.addEventListener('click',function(){
              navigator.clipboard && navigator.clipboard.writeText(b.getAttribute('data-url')).then(function(){
                var orig=b.innerHTML; b.innerHTML='<i class="fa-solid fa-check"></i><?php echo $show_lbl ? "<span>Copied!</span>" : ""; ?>';
                setTimeout(function(){b.innerHTML=orig;},2000);
              });
            });
          });
        })();
        </script>
        <?php
    }
}
