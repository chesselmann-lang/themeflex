<?php
/**
 * Elementor Content Slider Widget
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Content Slider Widget Class
 *
 * @since 1.0.0
 */
class Starter_Flavor_Slider_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'starter_flavor_slider';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Content Slider', 'starter-flavor' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-slider-full-screen';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'starter-flavor' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Slides', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Slides Repeater
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'slide_background_image',
			array(
				'label'   => esc_html__( 'Background Image', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => array(
					'url' => '',
				),
			)
		);

		$repeater->add_control(
			'slide_title',
			array(
				'label'       => esc_html__( 'Title', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Slide Title', 'starter-flavor' ),
				'placeholder' => esc_html__( 'Enter title', 'starter-flavor' ),
			)
		);

		$repeater->add_control(
			'slide_subtitle',
			array(
				'label'       => esc_html__( 'Subtitle', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'Your subtitle here', 'starter-flavor' ),
				'placeholder' => esc_html__( 'Enter subtitle', 'starter-flavor' ),
			)
		);

		$repeater->add_control(
			'slide_button_text',
			array(
				'label'       => esc_html__( 'Button Text', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Learn More', 'starter-flavor' ),
			)
		);

		$repeater->add_control(
			'slide_button_url',
			array(
				'label'       => esc_html__( 'Button URL', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://example.com', 'starter-flavor' ),
				'default'     => array(
					'url' => '',
				),
			)
		);

		$this->add_control(
			'slides',
			array(
				'label'       => esc_html__( 'Slides', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => array(
					array(
						'slide_title'       => esc_html__( 'Slide 1', 'starter-flavor' ),
						'slide_subtitle'    => esc_html__( 'Subtitle 1', 'starter-flavor' ),
						'slide_button_text' => esc_html__( 'Learn More', 'starter-flavor' ),
					),
					array(
						'slide_title'       => esc_html__( 'Slide 2', 'starter-flavor' ),
						'slide_subtitle'    => esc_html__( 'Subtitle 2', 'starter-flavor' ),
						'slide_button_text' => esc_html__( 'Learn More', 'starter-flavor' ),
					),
				),
				'title_field' => '{{{ slide_title }}}',
			)
		);

		$this->end_controls_section();

		// Settings Section
		$this->start_controls_section(
			'settings_section',
			array(
				'label' => esc_html__( 'Settings', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Auto-slide
		$this->add_control(
			'autoplay',
			array(
				'label'        => esc_html__( 'Autoplay', 'starter-flavor' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'starter-flavor' ),
				'label_off'    => esc_html__( 'No', 'starter-flavor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		// Autoplay Interval
		$this->add_control(
			'autoplay_interval',
			array(
				'label'     => esc_html__( 'Autoplay Interval (ms)', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'default'   => 5000,
				'min'       => 1000,
				'max'       => 10000,
				'condition' => array(
					'autoplay' => 'yes',
				),
			)
		);

		// Slider Height
		$this->add_control(
			'slider_height',
			array(
				'label'   => esc_html__( 'Height (px)', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 600,
				'min'     => 200,
				'max'     => 1000,
			)
		);

		// Mobile Height
		$this->add_control(
			'slider_height_mobile',
			array(
				'label'   => esc_html__( 'Mobile Height (px)', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 300,
				'min'     => 100,
				'max'     => 600,
			)
		);

		$this->end_controls_section();

		// Style Section - Overlay
		$this->start_controls_section(
			'overlay_style_section',
			array(
				'label' => esc_html__( 'Overlay', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'overlay_color',
			array(
				'label'     => esc_html__( 'Overlay Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => 'rgba(0, 0, 0, 0.5)',
				'selectors' => array(
					'{{WRAPPER}} .slide-overlay' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'overlay_opacity',
			array(
				'label'   => esc_html__( 'Overlay Opacity', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 50,
				),
				'range'   => array(
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Typography
		$this->start_controls_section(
			'typography_section',
			array(
				'label' => esc_html__( 'Typography', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'title_color',
			array(
				'label'     => esc_html__( 'Title Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FFFFFF',
				'selectors' => array(
					'{{WRAPPER}} .slide-title' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'title_typography',
				'label'    => esc_html__( 'Title Typography', 'starter-flavor' ),
				'selector' => '{{WRAPPER}} .slide-title',
			)
		);

		$this->add_control(
			'subtitle_color',
			array(
				'label'     => esc_html__( 'Subtitle Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FFFFFF',
				'selectors' => array(
					'{{WRAPPER}} .slide-subtitle' => 'color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Button
		$this->start_controls_section(
			'button_style_section',
			array(
				'label' => esc_html__( 'Button', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'button_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#0066cc',
				'selectors' => array(
					'{{WRAPPER}} .slide-button' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'button_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FFFFFF',
				'selectors' => array(
					'{{WRAPPER}} .slide-button' => 'color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['slides'] ) ) {
			echo '<p>' . esc_html__( 'Please add slides to the slider', 'starter-flavor' ) . '</p>';
			return;
		}

		$autoplay = isset( $settings['autoplay'] ) ? $settings['autoplay'] : 'yes';
		$autoplay_interval = isset( $settings['autoplay_interval'] ) ? intval( $settings['autoplay_interval'] ) : 5000;
		$slider_height = isset( $settings['slider_height'] ) ? intval( $settings['slider_height'] ) : 600;
		$slider_height_mobile = isset( $settings['slider_height_mobile'] ) ? intval( $settings['slider_height_mobile'] ) : 300;
		$overlay_opacity = isset( $settings['overlay_opacity']['size'] ) ? $settings['overlay_opacity']['size'] : 50;

		$slider_style = 'height: ' . esc_attr( $slider_height ) . 'px;';

		echo '<div class="slider-wrapper" data-autoplay="' . esc_attr( $autoplay ) . '" data-interval="' . esc_attr( $autoplay_interval ) . '">';
		echo '<div class="slider-container" style="' . esc_attr( $slider_style ) . '">';

		foreach ( $settings['slides'] as $index => $slide ) {
			$bg_image_url = isset( $slide['slide_background_image']['url'] ) ? $slide['slide_background_image']['url'] : '';
			$slide_title = isset( $slide['slide_title'] ) ? $slide['slide_title'] : '';
			$slide_subtitle = isset( $slide['slide_subtitle'] ) ? $slide['slide_subtitle'] : '';
			$slide_button_text = isset( $slide['slide_button_text'] ) ? $slide['slide_button_text'] : '';
			$slide_button_url = isset( $slide['slide_button_url']['url'] ) ? $slide['slide_button_url']['url'] : '';

			$slide_style = 'display: ' . ( 0 === $index ? 'block' : 'none' ) . ';';
			if ( ! empty( $bg_image_url ) ) {
				$slide_style .= 'background-image: url(\'' . esc_url( $bg_image_url ) . '\');';
			}

			echo '<div class="slide" style="' . esc_attr( $slide_style ) . '">';

			// Overlay
			printf(
				'<div class="slide-overlay" style="opacity: %f;"></div>',
				esc_attr( $overlay_opacity / 100 )
			);

			// Content
			echo '<div class="slide-content">';

			if ( ! empty( $slide_title ) ) {
				printf(
					'<h2 class="slide-title">%s</h2>',
					esc_html( $slide_title )
				);
			}

			if ( ! empty( $slide_subtitle ) ) {
				printf(
					'<p class="slide-subtitle">%s</p>',
					wp_kses_post( $slide_subtitle )
				);
			}

			if ( ! empty( $slide_button_text ) && ! empty( $slide_button_url ) ) {
				printf(
					'<a href="%s" class="slide-button">%s</a>',
					esc_url( $slide_button_url ),
					esc_html( $slide_button_text )
				);
			}

			echo '</div>';
			echo '</div>';
		}

		echo '</div>';

		// Navigation arrows
		echo '<button class="slider-arrow slider-prev" aria-label="' . esc_attr__( 'Previous slide', 'starter-flavor' ) . '"><i class="eicon-chevron-left"></i></button>';
		echo '<button class="slider-arrow slider-next" aria-label="' . esc_attr__( 'Next slide', 'starter-flavor' ) . '"><i class="eicon-chevron-right"></i></button>';

		// Dots navigation
		echo '<div class="slider-dots">';
		foreach ( $settings['slides'] as $index => $slide ) {
			$active_class = 0 === $index ? 'active' : '';
			echo '<span class="dot ' . esc_attr( $active_class ) . '" data-index="' . esc_attr( $index ) . '"></span>';
		}
		echo '</div>';

		echo '</div>';

		// Inline CSS for responsive height
		echo '<style>';
		echo '@media (max-width: 768px) {';
		echo '.slider-container { height: ' . esc_attr( $slider_height_mobile ) . 'px !important; }';
		echo '}';
		echo '</style>';
	}
}
