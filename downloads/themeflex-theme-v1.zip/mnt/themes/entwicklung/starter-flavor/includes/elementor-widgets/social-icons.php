<?php
/**
 * Elementor Social Icons Widget
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Social Icons Widget Class
 *
 * @since 1.0.0
 */
class Starter_Flavor_Social_Icons_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'starter_flavor_social_icons';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Social Icons', 'starter-flavor' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'starter-flavor' );
	}

	/**
	 * Get platform options
	 *
	 * @return array
	 */
	private function get_platform_options() {
		return array(
			'facebook'     => esc_html__( 'Facebook', 'starter-flavor' ),
			'twitter'      => esc_html__( 'Twitter/X', 'starter-flavor' ),
			'instagram'    => esc_html__( 'Instagram', 'starter-flavor' ),
			'linkedin'     => esc_html__( 'LinkedIn', 'starter-flavor' ),
			'youtube'      => esc_html__( 'YouTube', 'starter-flavor' ),
			'tiktok'       => esc_html__( 'TikTok', 'starter-flavor' ),
			'github'       => esc_html__( 'GitHub', 'starter-flavor' ),
			'dribbble'     => esc_html__( 'Dribbble', 'starter-flavor' ),
			'behance'      => esc_html__( 'Behance', 'starter-flavor' ),
			'pinterest'    => esc_html__( 'Pinterest', 'starter-flavor' ),
			'whatsapp'     => esc_html__( 'WhatsApp', 'starter-flavor' ),
			'telegram'     => esc_html__( 'Telegram', 'starter-flavor' ),
			'email'        => esc_html__( 'Email', 'starter-flavor' ),
		);
	}

	/**
	 * Get icon class for platform
	 *
	 * @param string $platform Platform name.
	 * @return string
	 */
	private function get_icon_class( $platform ) {
		$icons = array(
			'facebook'     => 'eicon-social-facebook',
			'twitter'      => 'eicon-social-twitter',
			'instagram'    => 'eicon-social-instagram',
			'linkedin'     => 'eicon-social-linkedin',
			'youtube'      => 'eicon-social-youtube',
			'tiktok'       => 'fab fa-tiktok',
			'github'       => 'eicon-social-github',
			'dribbble'     => 'fab fa-dribbble',
			'behance'      => 'fab fa-behance',
			'pinterest'    => 'eicon-social-pinterest',
			'whatsapp'     => 'fab fa-whatsapp',
			'telegram'     => 'fab fa-telegram',
			'email'        => 'eicon-mail',
		);

		return isset( $icons[ $platform ] ) ? $icons[ $platform ] : 'eicon-link';
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Social Accounts', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Social Links Repeater
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'platform',
			array(
				'label'   => esc_html__( 'Platform', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'facebook',
				'options' => $this->get_platform_options(),
			)
		);

		$repeater->add_control(
			'url',
			array(
				'label'       => esc_html__( 'URL', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://example.com', 'starter-flavor' ),
				'default'     => array(
					'url' => '',
				),
			)
		);

		$this->add_control(
			'social_links',
			array(
				'label'       => esc_html__( 'Social Links', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => array(
					array(
						'platform' => 'facebook',
						'url'      => array( 'url' => '#' ),
					),
					array(
						'platform' => 'twitter',
						'url'      => array( 'url' => '#' ),
					),
					array(
						'platform' => 'instagram',
						'url'      => array( 'url' => '#' ),
					),
				),
				'title_field' => '{{{ platform }}}',
			)
		);

		$this->end_controls_section();

		// Settings Section
		$this->start_controls_section(
			'settings_section',
			array(
				'label' => esc_html__( 'Settings', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Icon Shape
		$this->add_control(
			'icon_shape',
			array(
				'label'   => esc_html__( 'Icon Shape', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'circle',
				'options' => array(
					'circle'  => esc_html__( 'Circle', 'starter-flavor' ),
					'square'  => esc_html__( 'Square', 'starter-flavor' ),
					'rounded' => esc_html__( 'Rounded', 'starter-flavor' ),
				),
			)
		);

		// Layout
		$this->add_control(
			'layout',
			array(
				'label'   => esc_html__( 'Layout', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'horizontal',
				'options' => array(
					'horizontal' => esc_html__( 'Horizontal', 'starter-flavor' ),
					'vertical'   => esc_html__( 'Vertical', 'starter-flavor' ),
				),
			)
		);

		// Hover Animation
		$this->add_control(
			'hover_animation',
			array(
				'label'   => esc_html__( 'Hover Animation', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'scale',
				'options' => array(
					'none'        => esc_html__( 'None', 'starter-flavor' ),
					'bounce'      => esc_html__( 'Bounce', 'starter-flavor' ),
					'scale'       => esc_html__( 'Scale', 'starter-flavor' ),
					'color-change' => esc_html__( 'Color Change', 'starter-flavor' ),
				),
			)
		);

		// Open in new tab
		$this->add_control(
			'open_in_new_tab',
			array(
				'label'        => esc_html__( 'Open in New Tab', 'starter-flavor' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'starter-flavor' ),
				'label_off'    => esc_html__( 'No', 'starter-flavor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->end_controls_section();

		// Style Section - Icons
		$this->start_controls_section(
			'icons_style_section',
			array(
				'label' => esc_html__( 'Icons', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'icon_size',
			array(
				'label'   => esc_html__( 'Icon Size (px)', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 20,
				),
				'range'   => array(
					'px' => array(
						'min' => 10,
						'max' => 100,
					),
				),
			)
		);

		$this->add_control(
			'container_size',
			array(
				'label'   => esc_html__( 'Container Size (px)', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 50,
				),
				'range'   => array(
					'px' => array(
						'min' => 20,
						'max' => 150,
					),
				),
			)
		);

		$this->add_control(
			'icon_color',
			array(
				'label'     => esc_html__( 'Icon Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FFFFFF',
				'selectors' => array(
					'{{WRAPPER}} .social-icon' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'background_color',
			array(
				'label'     => esc_html__( 'Background Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#0066cc',
				'selectors' => array(
					'{{WRAPPER}} .social-icon' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'hover_color',
			array(
				'label'     => esc_html__( 'Hover Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#004da3',
				'selectors' => array(
					'{{WRAPPER}} .social-icon:hover' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Spacing
		$this->start_controls_section(
			'spacing_style_section',
			array(
				'label' => esc_html__( 'Spacing', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'icon_spacing',
			array(
				'label'   => esc_html__( 'Space Between Icons', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 10,
				),
				'range'   => array(
					'px' => array(
						'min' => 0,
						'max' => 50,
					),
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Border
		$this->start_controls_section(
			'border_style_section',
			array(
				'label' => esc_html__( 'Border', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'icon_border',
				'label'    => esc_html__( 'Border', 'starter-flavor' ),
				'selector' => '{{WRAPPER}} .social-icon',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['social_links'] ) ) {
			echo '<p>' . esc_html__( 'Please add social links', 'starter-flavor' ) . '</p>';
			return;
		}

		$icon_shape = isset( $settings['icon_shape'] ) ? $settings['icon_shape'] : 'circle';
		$layout = isset( $settings['layout'] ) ? $settings['layout'] : 'horizontal';
		$hover_animation = isset( $settings['hover_animation'] ) ? $settings['hover_animation'] : 'scale';
		$open_in_new_tab = isset( $settings['open_in_new_tab'] ) ? $settings['open_in_new_tab'] : 'yes';
		$icon_size = isset( $settings['icon_size']['size'] ) ? intval( $settings['icon_size']['size'] ) : 20;
		$container_size = isset( $settings['container_size']['size'] ) ? intval( $settings['container_size']['size'] ) : 50;
		$icon_spacing = isset( $settings['icon_spacing']['size'] ) ? intval( $settings['icon_spacing']['size'] ) : 10;

		$wrapper_class = 'social-icons-wrapper social-layout-' . esc_attr( $layout );
		$icon_class = 'social-icon social-shape-' . esc_attr( $icon_shape );
		if ( 'none' !== $hover_animation ) {
			$icon_class .= ' social-hover-' . esc_attr( $hover_animation );
		}

		$wrapper_style = '--icon-size: ' . esc_attr( $icon_size ) . 'px; --container-size: ' . esc_attr( $container_size ) . 'px; --icon-spacing: ' . esc_attr( $icon_spacing ) . 'px;';

		echo '<div class="' . esc_attr( $wrapper_class ) . '" style="' . esc_attr( $wrapper_style ) . '">';

		foreach ( $settings['social_links'] as $link ) {
			$platform = isset( $link['platform'] ) ? $link['platform'] : 'facebook';
			$url = isset( $link['url']['url'] ) ? $link['url']['url'] : '#';

			if ( empty( $url ) ) {
				continue;
			}

			$icon_name = $this->get_icon_class( $platform );
			$target = 'yes' === $open_in_new_tab ? ' target="_blank" rel="noopener noreferrer"' : '';

			printf(
				'<a href="%s" class="%s" title="%s"%s><i class="%s"></i></a>',
				esc_url( $url ),
				esc_attr( $icon_class ),
				esc_attr( isset( $this->get_platform_options()[ $platform ] ) ? $this->get_platform_options()[ $platform ] : $platform ),
				$target,
				esc_attr( $icon_name )
			);
		}

		echo '</div>';
	}
}
