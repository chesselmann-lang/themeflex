<?php
/**
 * Social Proof Notification Widget
 * "Max aus Berlin kaufte gerade" — Booking.com-Style Conversion Boost.
 * @package Starter_Flavor
 */
if (!defined('ABSPATH')) exit;

class Starter_Flavor_Social_Proof_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'sf_social_proof'; }
    public function get_title() { return esc_html__('Social Proof Notification','starter-flavor'); }
    public function get_icon()  { return 'eicon-person'; }
    public function get_categories() { return ['starter-flavor']; }
    public function get_keywords()   { return ['social proof','notification','conversion','popup','activity','fomo']; }

    protected function register_controls() {
        $this->start_controls_section('section_notifications',['label'=>'Notifications']);
        $repeater = new \Elementor\Repeater();
        $repeater->add_control('name',['label'=>'Name','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Sarah M.']);
        $repeater->add_control('location',['label'=>'Location','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Berlin, DE']);
        $repeater->add_control('action',['label'=>'Action','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'just signed up']);
        $repeater->add_control('time',['label'=>'Time','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'2 minutes ago']);
        $repeater->add_control('emoji',['label'=>'Emoji','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'🎉']);
        $this->add_control('notifications',[
            'type'=>\Elementor\Controls_Manager::REPEATER,'fields'=>$repeater->get_controls(),
            'default'=>[
                ['name'=>'Sarah M.','location'=>'Berlin, DE','action'=>'just purchased Pro','time'=>'2 minutes ago','emoji'=>'🛒'],
                ['name'=>'James K.','location'=>'London, UK','action'=>'started a free trial','time'=>'5 minutes ago','emoji'=>'🚀'],
                ['name'=>'Maria S.','location'=>'Vienna, AT','action'=>'left a 5-star review','time'=>'8 minutes ago','emoji'=>'⭐'],
                ['name'=>'Tom H.','location'=>'New York, US','action'=>'upgraded to Agency','time'=>'12 minutes ago','emoji'=>'💼'],
            ],
            'title_field'=>'{{{ name }}} — {{{ action }}}',
        ]);
        $this->add_control('position',['label'=>'Position','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['bottom-left'=>'Bottom Left','bottom-right'=>'Bottom Right','top-left'=>'Top Left','top-right'=>'Top Right'],'default'=>'bottom-left']);
        $this->add_control('display_time',['label'=>'Display Duration (ms)','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['ms'=>['min'=>2000,'max'=>10000,'step'=>500]],'default'=>['size'=>4000]]);
        $this->add_control('interval',['label'=>'Interval Between (ms)','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['ms'=>['min'=>3000,'max'=>15000,'step'=>500]],'default'=>['size'=>6000]]);
        $this->add_control('initial_delay',['label'=>'Initial Delay (ms)','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['ms'=>['min'=>0,'max'=>10000,'step'=>500]],'default'=>['size'=>3000]]);
        $this->end_controls_section();
        $this->start_controls_section('section_style',['label'=>'Style','tab'=>\Elementor\Controls_Manager::TAB_STYLE]);
        $this->add_control('max_width',['label'=>'Max Width','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['px'=>['min'=>240,'max'=>400]],'default'=>['size'=>320],'selectors'=>['body .sf-sp-popup'=>'max-width:{{SIZE}}px']]);
        $this->end_controls_section();
    }

    protected function render() {
        $s   = $this->get_settings_for_display();
        $uid = 'sf-sp-'.$this->get_id();
        $notifs_json = wp_json_encode(array_map(function($n){return['name'=>$n['name'],'location'=>$n['location'],'action'=>$n['action'],'time'=>$n['time'],'emoji'=>$n['emoji']];}, $s['notifications']));
        $pos    = $s['position'] ?? 'bottom-left';
        $dt     = !empty($s['display_time']['size']) ? (int)$s['display_time']['size'] : 4000;
        $iv     = !empty($s['interval']['size'])     ? (int)$s['interval']['size']     : 6000;
        $delay  = !empty($s['initial_delay']['size'])? (int)$s['initial_delay']['size']: 3000;
        $pos_css = str_replace(['-left','-right','-'],['_left','_right','_'], $pos);
        [$v,$h] = explode('-', $pos);
        ?>
        <div class="sf-sp-trigger" id="<?php echo esc_attr($uid); ?>" style="display:none"></div>
        <style>
        .sf-sp-popup{position:fixed;<?php echo $v; ?>:24px;<?php echo $h; ?>:24px;z-index:99998;background:#fff;border-radius:12px;box-shadow:0 8px 40px rgba(0,0,0,.18);padding:14px 16px;display:flex;align-items:center;gap:14px;max-width:320px;width:calc(100% - 48px);transform:translateY(<?php echo $v==='bottom'?'120%':'-120%'; ?>);opacity:0;transition:transform .4s cubic-bezier(.34,1.56,.64,1),opacity .4s ease;pointer-events:none}
        .sf-sp-popup.visible{transform:translateY(0);opacity:1;pointer-events:auto}
        .sf-sp-emoji{width:44px;height:44px;border-radius:50%;background:var(--sf-gradient-soft,rgba(255,94,46,.1));display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0}
        .sf-sp-body{flex:1;min-width:0}
        .sf-sp-name{font-weight:700;font-size:13px;color:#1e293b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
        .sf-sp-action{font-size:12px;color:#64748b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
        .sf-sp-time{font-size:11px;color:#94a3b8;margin-top:2px}
        .sf-sp-close{background:none;border:none;color:#94a3b8;cursor:pointer;font-size:18px;line-height:1;padding:0;flex-shrink:0}
        .sf-sp-close:hover{color:#1e293b}
        [data-theme=dark] .sf-sp-popup{background:#1e293b;box-shadow:0 8px 40px rgba(0,0,0,.5)}
        [data-theme=dark] .sf-sp-name{color:#f1f5f9}
        [data-theme=dark] .sf-sp-action{color:#94a3b8}
        </style>
        <script>
        (function(){
            if(typeof window.__sfSpInit!=='undefined')return;
            window.__sfSpInit=true;
            var popup=document.createElement('div');popup.className='sf-sp-popup';popup.id='sf-sp-global';
            popup.innerHTML='<div class="sf-sp-emoji" id="sf-sp-em"></div><div class="sf-sp-body"><div class="sf-sp-name" id="sf-sp-n"></div><div class="sf-sp-action" id="sf-sp-a"></div><div class="sf-sp-time" id="sf-sp-t"></div></div><button class="sf-sp-close" onclick="document.getElementById(\'sf-sp-global\').classList.remove(\'visible\')">&times;</button>';
            document.body.appendChild(popup);
            var notifs=<?php echo $notifs_json; ?>;
            var idx=0;var hideTimer=null;
            function show(){
                var n=notifs[idx%notifs.length];idx++;
                document.getElementById('sf-sp-em').textContent=n.emoji;
                document.getElementById('sf-sp-n').textContent=n.name+' · '+n.location;
                document.getElementById('sf-sp-a').textContent=n.action;
                document.getElementById('sf-sp-t').textContent=n.time;
                popup.classList.add('visible');
                clearTimeout(hideTimer);
                hideTimer=setTimeout(function(){popup.classList.remove('visible');},<?php echo $dt; ?>);
            }
            setTimeout(function(){show();setInterval(show,<?php echo $iv; ?>);},<?php echo $delay; ?>);
        })();
        </script>
        <?php
    }
}
