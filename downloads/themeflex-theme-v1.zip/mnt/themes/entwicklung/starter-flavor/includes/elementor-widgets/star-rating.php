<?php
/**
 * Star Rating Widget for Elementor
 *
 * @package Starter_Flavor
 * @since 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Starter_Flavor_Star_Rating_Widget extends \Elementor\Widget_Base {

    public function get_name()       { return 'sf_star_rating'; }
    public function get_title()      { return esc_html__( 'Star Rating', 'starter-flavor' ); }
    public function get_icon()       { return 'eicon-rating'; }
    public function get_categories() { return array( 'starter-flavor' ); }
    public function get_keywords()   { return array( 'star','rating','review','score' ); }

    protected function register_controls() {
        $this->start_controls_section('content', array('label'=>esc_html__('Rating','starter-flavor'),'tab'=>\Elementor\Controls_Manager::TAB_CONTENT));

        $this->add_control('rating', array('label'=>esc_html__('Rating (0-5)','starter-flavor'),'type'=>\Elementor\Controls_Manager::NUMBER,'default'=>4.5,'min'=>0,'max'=>5,'step'=>0.1));
        $this->add_control('max_stars', array('label'=>esc_html__('Stars','starter-flavor'),'type'=>\Elementor\Controls_Manager::NUMBER,'default'=>5,'min'=>1,'max'=>10));
        $this->add_control('show_value', array('label'=>esc_html__('Show Value','starter-flavor'),'type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes'));
        $this->add_control('show_count', array('label'=>esc_html__('Show Review Count','starter-flavor'),'type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'no'));
        $this->add_control('review_count', array('label'=>esc_html__('Review Count','starter-flavor'),'type'=>\Elementor\Controls_Manager::NUMBER,'default'=>128,'condition'=>array('show_count'=>'yes')));
        $this->add_control('align', array('label'=>esc_html__('Alignment','starter-flavor'),'type'=>\Elementor\Controls_Manager::CHOOSE,'options'=>array('flex-start'=>array('title'=>esc_html__('Left','starter-flavor'),'icon'=>'eicon-text-align-left'),'center'=>array('title'=>esc_html__('Center','starter-flavor'),'icon'=>'eicon-text-align-center'),'flex-end'=>array('title'=>esc_html__('Right','starter-flavor'),'icon'=>'eicon-text-align-right')),'default'=>'flex-start','selectors'=>array('{{WRAPPER}} .sf-star-rating'=>'justify-content:{{VALUE}};')));

        $this->end_controls_section();

        $this->start_controls_section('style_s', array('label'=>esc_html__('Style','starter-flavor'),'tab'=>\Elementor\Controls_Manager::TAB_STYLE));
        $this->add_control('star_color', array('label'=>esc_html__('Filled Colour','starter-flavor'),'type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#f59e0b','selectors'=>array('{{WRAPPER}} .sf-sr-star.filled, {{WRAPPER}} .sf-sr-star.partial .sf-sr-fill'=>'color:{{VALUE}};')));
        $this->add_control('empty_color', array('label'=>esc_html__('Empty Colour','starter-flavor'),'type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#d1d5db'));
        $this->add_control('star_size', array('label'=>esc_html__('Size','starter-flavor'),'type'=>\Elementor\Controls_Manager::SLIDER,'size_units'=>array('px','em'),'default'=>array('unit'=>'px','size'=>20),'selectors'=>array('{{WRAPPER}} .sf-sr-star'=>'font-size:{{SIZE}}{{UNIT}};')));
        $this->end_controls_section();
    }

    protected function render() {
        $s       = $this->get_settings_for_display();
        $rating  = floatval($s['rating']);
        $max     = absint($s['max_stars']) ?: 5;
        $ecol    = esc_attr($s['empty_color'] ?? '#d1d5db');

        echo '<div class="sf-star-rating" role="img" aria-label="' . esc_attr(sprintf(/* translators: %1$s = rating, %2$s = max */ __('%1$s out of %2$s stars', 'starter-flavor'), $rating, $max)) . '">';
        for ($i = 1; $i <= $max; $i++) {
            if ($i <= floor($rating)) {
                echo '<span class="sf-sr-star filled"><i class="fa-solid fa-star"></i></span>';
            } elseif ($i - $rating < 1 && $i - $rating > 0) {
                $pct = round(($rating - floor($rating)) * 100);
                echo '<span class="sf-sr-star partial" style="position:relative;color:' . $ecol . ';"><i class="fa-solid fa-star"></i><span class="sf-sr-fill" style="position:absolute;left:0;top:0;overflow:hidden;width:' . $pct . '%;"><i class="fa-solid fa-star"></i></span></span>';
            } else {
                echo '<span class="sf-sr-star empty" style="color:' . $ecol . ';"><i class="fa-solid fa-star"></i></span>';
            }
        }
        if ('yes' === $s['show_value']) echo '<span class="sf-sr-value">' . esc_html($rating) . '</span>';
        if ('yes' === $s['show_count']) echo '<span class="sf-sr-count">(' . esc_html(absint($s['review_count'])) . ')</span>';
        echo '</div>';
        ?>
        <style>
        .sf-star-rating{display:flex;align-items:center;gap:4px;}
        .sf-sr-star{display:inline-flex;}
        .sf-sr-value{font-weight:700;font-size:.95em;margin-left:6px;}
        .sf-sr-count{font-size:.85em;color:#64748b;margin-left:2px;}
        </style>
        <?php
    }
}
