<?php
/**
 * Sticky Floating Element Widget — CTA / Widget das beim Scrollen sticky bleibt.
 * @package Starter_Flavor
 */
if (!defined('ABSPATH')) exit;

class Starter_Flavor_Sticky_Float_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'sf_sticky_float'; }
    public function get_title() { return esc_html__('Sticky Float Element','starter-flavor'); }
    public function get_icon()  { return 'eicon-pin'; }
    public function get_categories() { return ['starter-flavor']; }
    public function get_keywords()   { return ['sticky','float','fixed','cta','persistent','scroll']; }

    protected function register_controls() {
        $this->start_controls_section('s_content',['label'=>'Content']);
        $this->add_control('type',['label'=>'Type','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['cta_bar'=>'CTA Bar','contact_card'=>'Contact Card','discount_pill'=>'Discount Pill'],'default'=>'cta_bar']);
        $this->add_control('text',['label'=>'Text','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'🎯 Limited offer — save 30% today']);
        $this->add_control('btn_text',['label'=>'Button Text','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Claim Now']);
        $this->add_control('btn_url',['label'=>'Button URL','type'=>\Elementor\Controls_Manager::URL]);
        $this->add_control('position',['label'=>'Position','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['bottom'=>'Bottom Bar','bottom-right'=>'Bottom Right','bottom-left'=>'Bottom Left'],'default'=>'bottom']);
        $this->add_control('show_after',['label'=>'Show After (px scroll)','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['px'=>['min'=>0,'max'=>1000]],'default'=>['size'=>300]]);
        $this->add_control('dismissible',['label'=>'Dismissible','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes']);
        $this->add_control('cookie_days',['label'=>'Stay dismissed (days)','type'=>\Elementor\Controls_Manager::NUMBER,'default'=>1,'condition'=>['dismissible'=>'yes']]);
        $this->end_controls_section();
    }

    protected function render() {
        $s   = $this->get_settings_for_display();
        $uid = 'sfsf-'.$this->get_id();
        $pos = $s['position'] ?? 'bottom';
        $type = $s['type'] ?? 'cta_bar';
        $after = (int)(!empty($s['show_after']['size']) ? $s['show_after']['size'] : 300);
        $dis  = 'yes' === ($s['dismissible'] ?? 'yes');
        $days = (int)($s['cookie_days'] ?? 1);
        $btn_url = !empty($s['btn_url']['url']) ? esc_url($s['btn_url']['url']) : '#';
        $pos_css = match($pos) {
            'bottom-right' => 'bottom:24px;right:24px;',
            'bottom-left'  => 'bottom:24px;left:24px;',
            default        => 'bottom:0;left:0;right:0;',
        };
        $is_bar = 'bottom' === $pos;
        ?>
        <div style="display:none" id="<?php echo esc_attr($uid); ?>-ref"></div>
        <div id="<?php echo esc_attr($uid); ?>" style="position:fixed;<?php echo $pos_css; ?>z-index:9980;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;padding:<?php echo $is_bar?'14px 32px':'20px 24px'; ?>;display:none;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;transition:transform .3s ease,opacity .3s ease;<?php echo !$is_bar?'border-radius:16px;max-width:340px;box-shadow:0 8px 32px rgba(0,0,0,.25);':'box-shadow:0 -4px 24px rgba(0,0,0,.15);'; ?>">
            <div style="<?php echo !$is_bar?'flex:1;':''; ?>">
                <p style="margin:0;font-size:<?php echo !$is_bar?'15':'14'; ?>px;font-weight:600;line-height:1.4;"><?php echo wp_kses_post($s['text']); ?></p>
            </div>
            <div style="display:flex;align-items:center;gap:10px;flex-shrink:0;">
                <?php if($s['btn_text']): ?>
                <a href="<?php echo $btn_url; ?>" style="padding:9px 20px;border-radius:8px;background:rgba(0,0,0,.25);color:#fff;font-weight:700;text-decoration:none;font-size:13px;white-space:nowrap;border:1px solid rgba(255,255,255,.3);">
                    <?php echo esc_html($s['btn_text']); ?>
                </a>
                <?php endif; ?>
                <?php if($dis): ?>
                <button onclick="sfSfDismiss('<?php echo esc_js($uid); ?>',<?php echo $days; ?>)" style="background:none;border:none;color:rgba(255,255,255,.7);font-size:20px;cursor:pointer;line-height:1;padding:0;">&times;</button>
                <?php endif; ?>
            </div>
        </div>
        <script>
        (function(){
            var uid='<?php echo esc_js($uid); ?>';
            var el=document.getElementById(uid);
            var after=<?php echo $after; ?>;
            var ck='sf_sf_'+uid;
            function getCookie(n){var v='; '+document.cookie,p=v.split('; '+n+'=');if(p.length===2)return p.pop().split(';').shift();}
            if(getCookie(ck))return;
            window.addEventListener('scroll',function(){
                if(window.scrollY>=after){el.style.display='flex';el.style.opacity='1';}
                else{el.style.opacity='0';}
            },{passive:true});
        })();
        window.sfSfDismiss=function(id,days){
            var el=document.getElementById(id);if(el)el.style.display='none';
            var d=new Date();d.setTime(d.getTime()+(days*864e5));
            document.cookie='sf_sf_'+id+'=1;expires='+d.toUTCString()+';path=/';
        };
        </script>
        <?php
    }
}
