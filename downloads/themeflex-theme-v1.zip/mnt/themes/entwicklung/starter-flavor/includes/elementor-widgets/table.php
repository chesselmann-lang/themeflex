<?php
/**
 * Elementor Advanced Table Widget
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Advanced Table Widget Class
 *
 * @since 1.0.0
 */
class Starter_Flavor_Table_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'starter_flavor_table';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Advanced Table', 'starter-flavor' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-table';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'starter-flavor' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Header Row
		$this->add_control(
			'header_cells',
			array(
				'label'       => esc_html__( 'Header Cells', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Column 1 | Column 2 | Column 3', 'starter-flavor' ),
				'description' => esc_html__( 'Separate cells with |', 'starter-flavor' ),
				'default'     => 'Name | Description | Price',
			)
		);

		// Table Rows Repeater
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'row_cells',
			array(
				'label'       => esc_html__( 'Row Cells', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Cell 1 | Cell 2 | Cell 3', 'starter-flavor' ),
				'description' => esc_html__( 'Separate cells with |', 'starter-flavor' ),
			)
		);

		$this->add_control(
			'rows',
			array(
				'label'      => esc_html__( 'Rows', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::REPEATER,
				'fields'     => $repeater->get_controls(),
				'title_field' => esc_html__( 'Row', 'starter-flavor' ),
				'default'    => array(
					array(
						'row_cells' => 'Item 1 | Description | $19.99',
					),
					array(
						'row_cells' => 'Item 2 | Description | $29.99',
					),
				),
			)
		);

		$this->end_controls_section();

		// Features Section
		$this->start_controls_section(
			'features_section',
			array(
				'label' => esc_html__( 'Features', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'sortable',
			array(
				'label'        => esc_html__( 'Sortable Columns', 'starter-flavor' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'starter-flavor' ),
				'label_off'    => esc_html__( 'No', 'starter-flavor' ),
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'striped_rows',
			array(
				'label'        => esc_html__( 'Striped Rows', 'starter-flavor' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'starter-flavor' ),
				'label_off'    => esc_html__( 'No', 'starter-flavor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'hover_highlight',
			array(
				'label'        => esc_html__( 'Hover Highlight', 'starter-flavor' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'starter-flavor' ),
				'label_off'    => esc_html__( 'No', 'starter-flavor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'responsive_behavior',
			array(
				'label'   => esc_html__( 'Mobile Behavior', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'scroll',
				'options' => array(
					'scroll' => esc_html__( 'Horizontal Scroll', 'starter-flavor' ),
					'stack'  => esc_html__( 'Stack Rows', 'starter-flavor' ),
				),
			)
		);

		$this->end_controls_section();

		// Style Section
		$this->start_controls_section(
			'style_section',
			array(
				'label' => esc_html__( 'Style', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'header_bg_color',
			array(
				'label'     => esc_html__( 'Header Background', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#0066cc',
				'selectors' => array(
					'{{WRAPPER}} .advanced-table thead' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'header_text_color',
			array(
				'label'     => esc_html__( 'Header Text Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .advanced-table thead' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#dddddd',
				'selectors' => array(
					'{{WRAPPER}} .advanced-table' => 'border-color: {{VALUE}}; --table-border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'striped_color',
			array(
				'label'     => esc_html__( 'Striped Row Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#f9f9f9',
				'selectors' => array(
					'{{WRAPPER}} .advanced-table tbody tr:nth-child(even)' => 'background-color: {{VALUE}};',
				),
				'condition' => array(
					'striped_rows' => 'yes',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$header_cells_str = isset( $settings['header_cells'] ) ? $settings['header_cells'] : '';
		$rows = isset( $settings['rows'] ) ? $settings['rows'] : array();
		$sortable = isset( $settings['sortable'] ) && 'yes' === $settings['sortable'];
		$striped = isset( $settings['striped_rows'] ) && 'yes' === $settings['striped_rows'];
		$hover = isset( $settings['hover_highlight'] ) && 'yes' === $settings['hover_highlight'];
		$responsive = isset( $settings['responsive_behavior'] ) ? $settings['responsive_behavior'] : 'scroll';

		$header_cells = array_map( 'trim', explode( '|', $header_cells_str ) );

		if ( empty( $rows ) ) {
			echo '<p>' . esc_html__( 'Please add table rows', 'starter-flavor' ) . '</p>';
			return;
		}

		$classes = 'advanced-table';
		if ( $striped ) {
			$classes .= ' striped';
		}
		if ( $hover ) {
			$classes .= ' hover-highlight';
		}
		if ( $sortable ) {
			$classes .= ' sortable';
		}
		$classes .= ' responsive-' . esc_attr( $responsive );

		?>
		<div class="table-wrapper">
			<table class="<?php echo esc_attr( $classes ); ?>" role="table">
				<thead role="rowgroup">
					<tr role="row">
						<?php foreach ( $header_cells as $index => $cell ) : ?>
							<th role="columnheader" <?php echo $sortable ? 'data-sortable="true"' : ''; ?>>
								<?php echo esc_html( $cell ); ?>
								<?php if ( $sortable ) : ?>
									<span class="sort-icon" aria-hidden="true"></span>
								<?php endif; ?>
							</th>
						<?php endforeach; ?>
					</tr>
				</thead>
				<tbody role="rowgroup">
					<?php foreach ( $rows as $row_index => $row ) : ?>
						<?php
						$row_cells_str = isset( $row['row_cells'] ) ? $row['row_cells'] : '';
						$cells = array_map( 'trim', explode( '|', $row_cells_str ) );
						?>
						<tr role="row">
							<?php foreach ( $cells as $cell_index => $cell ) : ?>
								<td role="cell" data-column="<?php echo esc_attr( isset( $header_cells[ $cell_index ] ) ? $header_cells[ $cell_index ] : '' ); ?>">
									<?php echo wp_kses_post( $cell ); ?>
								</td>
							<?php endforeach; ?>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}
}
