<?php
/**
 * Elementor Team Member Widget
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Team Member Widget Class
 *
 * @since 1.0.0
 */
class Starter_Flavor_Team_Member_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'starter_flavor_team_member';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Team Member', 'starter-flavor' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-person';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'starter-flavor' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Member Image
		$this->add_control(
			'member_image',
			array(
				'label'   => esc_html__( 'Member Photo', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => array(
					'url' => '',
				),
			)
		);

		// Member Name
		$this->add_control(
			'member_name',
			array(
				'label'       => esc_html__( 'Name', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'John Smith', 'starter-flavor' ),
				'placeholder' => esc_html__( 'Enter member name', 'starter-flavor' ),
			)
		);

		// Member Position
		$this->add_control(
			'member_position',
			array(
				'label'       => esc_html__( 'Position/Role', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Marketing Manager', 'starter-flavor' ),
				'placeholder' => esc_html__( 'e.g., CEO, Designer, Developer', 'starter-flavor' ),
			)
		);

		// Member Bio
		$this->add_control(
			'member_bio',
			array(
				'label'       => esc_html__( 'Bio', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'A brief description of the team member.', 'starter-flavor' ),
				'placeholder' => esc_html__( 'Enter bio text', 'starter-flavor' ),
			)
		);

		// Social Links Section
		$this->add_control(
			'social_links_heading',
			array(
				'label'     => esc_html__( 'Social Links', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		// Facebook
		$this->add_control(
			'social_facebook',
			array(
				'label'       => esc_html__( 'Facebook URL', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://facebook.com/...', 'starter-flavor' ),
				'default'     => array(
					'url' => '',
				),
			)
		);

		// Twitter
		$this->add_control(
			'social_twitter',
			array(
				'label'       => esc_html__( 'Twitter URL', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://twitter.com/...', 'starter-flavor' ),
				'default'     => array(
					'url' => '',
				),
			)
		);

		// LinkedIn
		$this->add_control(
			'social_linkedin',
			array(
				'label'       => esc_html__( 'LinkedIn URL', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://linkedin.com/in/...', 'starter-flavor' ),
				'default'     => array(
					'url' => '',
				),
			)
		);

		// Instagram
		$this->add_control(
			'social_instagram',
			array(
				'label'       => esc_html__( 'Instagram URL', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://instagram.com/...', 'starter-flavor' ),
				'default'     => array(
					'url' => '',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Card
		$this->start_controls_section(
			'card_style_section',
			array(
				'label' => esc_html__( 'Card', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Card Background
		$this->add_control(
			'card_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FFFFFF',
				'selectors' => array(
					'{{WRAPPER}} .team-member-card' => 'background-color: {{VALUE}}',
				),
			)
		);

		// Card Border Radius
		$this->add_control(
			'card_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => '8',
					'right'  => '8',
					'bottom' => '8',
					'left'   => '8',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .team-member-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				),
			)
		);

		// Card Shadow
		$this->add_control(
			'card_shadow',
			array(
				'label'     => esc_html__( 'Box Shadow', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::BOX_SHADOW,
				'default'   => array(
					'horizontal' => '0',
					'vertical'   => '2',
					'blur'       => '8',
					'spread'     => '0',
					'color'      => 'rgba(0,0,0,0.1)',
				),
				'selectors' => array(
					'{{WRAPPER}} .team-member-card' => 'box-shadow: {{HORIZONTAL}}{{UNIT}} {{VERTICAL}}{{UNIT}} {{BLUR}}{{UNIT}} {{SPREAD}}{{UNIT}} {{COLOR}}',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Typography
		$this->start_controls_section(
			'typography_style_section',
			array(
				'label' => esc_html__( 'Typography', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Name Color
		$this->add_control(
			'name_color',
			array(
				'label'     => esc_html__( 'Name Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#1F2937',
				'selectors' => array(
					'{{WRAPPER}} .team-member-name' => 'color: {{VALUE}}',
				),
			)
		);

		// Position Color
		$this->add_control(
			'position_color',
			array(
				'label'     => esc_html__( 'Position Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FF5E2E',
				'selectors' => array(
					'{{WRAPPER}} .team-member-position' => 'color: {{VALUE}}',
				),
			)
		);

		// Bio Color
		$this->add_control(
			'bio_color',
			array(
				'label'     => esc_html__( 'Bio Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#6B7280',
				'selectors' => array(
					'{{WRAPPER}} .team-member-bio' => 'color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Spacing
		$this->start_controls_section(
			'spacing_style_section',
			array(
				'label' => esc_html__( 'Spacing', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Padding
		$this->add_control(
			'card_padding',
			array(
				'label'      => esc_html__( 'Padding', 'starter-flavor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => '20',
					'right'  => '20',
					'bottom' => '20',
					'left'   => '20',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .team-member-card-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		// Get social URLs
		$facebook = isset( $settings['social_facebook']['url'] ) ? $settings['social_facebook']['url'] : '';
		$twitter = isset( $settings['social_twitter']['url'] ) ? $settings['social_twitter']['url'] : '';
		$linkedin = isset( $settings['social_linkedin']['url'] ) ? $settings['social_linkedin']['url'] : '';
		$instagram = isset( $settings['social_instagram']['url'] ) ? $settings['social_instagram']['url'] : '';

		echo '<div class="team-member-card">';
		echo '<div class="team-member-image-wrapper">';

		// Member Photo
		if ( ! empty( $settings['member_image']['url'] ) ) {
			printf(
				'<img src="%s" alt="%s" class="team-member-image" />',
				esc_url( $settings['member_image']['url'] ),
				esc_attr( $settings['member_name'] )
			);
		}

		// Social Links Overlay
		if ( ! empty( $facebook ) || ! empty( $twitter ) || ! empty( $linkedin ) || ! empty( $instagram ) ) {
			echo '<div class="team-member-overlay">';
			echo '<div class="team-member-social-links">';

			if ( ! empty( $facebook ) ) {
				printf(
					'<a href="%s" target="_blank" rel="noopener noreferrer" class="social-link facebook" title="%s"><i class="fab fa-facebook-f"></i></a>',
					esc_url( $facebook ),
					esc_attr__( 'Facebook', 'starter-flavor' )
				);
			}

			if ( ! empty( $twitter ) ) {
				printf(
					'<a href="%s" target="_blank" rel="noopener noreferrer" class="social-link twitter" title="%s"><i class="fab fa-twitter"></i></a>',
					esc_url( $twitter ),
					esc_attr__( 'Twitter', 'starter-flavor' )
				);
			}

			if ( ! empty( $linkedin ) ) {
				printf(
					'<a href="%s" target="_blank" rel="noopener noreferrer" class="social-link linkedin" title="%s"><i class="fab fa-linkedin-in"></i></a>',
					esc_url( $linkedin ),
					esc_attr__( 'LinkedIn', 'starter-flavor' )
				);
			}

			if ( ! empty( $instagram ) ) {
				printf(
					'<a href="%s" target="_blank" rel="noopener noreferrer" class="social-link instagram" title="%s"><i class="fab fa-instagram"></i></a>',
					esc_url( $instagram ),
					esc_attr__( 'Instagram', 'starter-flavor' )
				);
			}

			echo '</div>';
			echo '</div>';
		}

		echo '</div>';

		// Card Content
		echo '<div class="team-member-card-inner">';

		// Name
		if ( ! empty( $settings['member_name'] ) ) {
			printf(
				'<h3 class="team-member-name">%s</h3>',
				esc_html( $settings['member_name'] )
			);
		}

		// Position
		if ( ! empty( $settings['member_position'] ) ) {
			printf(
				'<p class="team-member-position">%s</p>',
				esc_html( $settings['member_position'] )
			);
		}

		// Bio
		if ( ! empty( $settings['member_bio'] ) ) {
			printf(
				'<p class="team-member-bio">%s</p>',
				esc_html( $settings['member_bio'] )
			);
		}

		echo '</div>';
		echo '</div>';

		// Inline Styles
		?>
		<style>
			.team-member-card {
				position: relative;
				overflow: hidden;
			}

			.team-member-image-wrapper {
				position: relative;
				overflow: hidden;
				width: 100%;
				height: auto;
			}

			.team-member-image {
				width: 100%;
				height: auto;
				display: block;
				transition: transform 0.3s ease;
			}

			.team-member-card:hover .team-member-image {
				transform: scale(1.05);
			}

			.team-member-overlay {
				position: absolute;
				top: 0;
				left: 0;
				right: 0;
				bottom: 0;
				background-color: rgba(0, 0, 0, 0.7);
				display: flex;
				align-items: center;
				justify-content: center;
				opacity: 0;
				transition: opacity 0.3s ease;
			}

			.team-member-card:hover .team-member-overlay {
				opacity: 1;
			}

			.team-member-social-links {
				display: flex;
				gap: 15px;
				flex-wrap: wrap;
				justify-content: center;
			}

			.social-link {
				display: inline-flex;
				align-items: center;
				justify-content: center;
				width: 40px;
				height: 40px;
				border-radius: 50%;
				background-color: rgba(255, 255, 255, 0.2);
				color: #FFFFFF;
				text-decoration: none;
				transition: all 0.3s ease;
				font-size: 16px;
			}

			.social-link:hover {
				background-color: #FF5E2E;
				transform: translateY(-3px);
			}

			.social-link i {
				display: block;
			}
		</style>
		<?php
	}
}
