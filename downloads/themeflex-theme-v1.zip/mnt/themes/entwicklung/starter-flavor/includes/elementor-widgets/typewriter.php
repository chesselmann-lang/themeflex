<?php
/**
 * Typewriter Effect Widget
 * Headline mit animiertem Text-Rotator.
 *
 * @package Starter_Flavor
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class Starter_Flavor_Typewriter_Widget extends \Elementor\Widget_Base {

	public function get_name()  { return 'sf_typewriter'; }
	public function get_title() { return esc_html__( 'Typewriter Text', 'starter-flavor' ); }
	public function get_icon()  { return 'eicon-animated-headline'; }
	public function get_categories() { return [ 'starter-flavor' ]; }
	public function get_keywords()   { return [ 'typewriter', 'typing', 'animated', 'headline', 'text rotator' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'section_content', [ 'label' => 'Content' ] );

		$this->add_control( 'before_text', [ 'label' => 'Before Text', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'We create' ] );

		$repeater = new \Elementor\Repeater();
		$repeater->add_control( 'word', [ 'label' => 'Word / Phrase', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'awesome websites' ] );

		$this->add_control( 'words', [
			'type'        => \Elementor\Controls_Manager::REPEATER,
			'fields'      => $repeater->get_controls(),
			'default'     => [
				[ 'word' => 'awesome websites' ],
				[ 'word' => 'stunning designs' ],
				[ 'word' => 'real results' ],
			],
			'title_field' => '{{{ word }}}',
		] );

		$this->add_control( 'after_text', [ 'label' => 'After Text', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => '' ] );
		$this->add_control( 'tag', [
			'label'   => 'HTML Tag',
			'type'    => \Elementor\Controls_Manager::SELECT,
			'options' => [ 'h1' => 'H1', 'h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4', 'p' => 'P', 'span' => 'Span' ],
			'default' => 'h2',
		] );
		$this->add_control( 'type_speed',   [ 'label' => 'Type Speed (ms)',   'type' => \Elementor\Controls_Manager::SLIDER, 'range' => [ 'ms' => [ 'min' => 30, 'max' => 300 ] ], 'default' => [ 'size' => 80 ] ] );
		$this->add_control( 'delete_speed', [ 'label' => 'Delete Speed (ms)', 'type' => \Elementor\Controls_Manager::SLIDER, 'range' => [ 'ms' => [ 'min' => 20, 'max' => 200 ] ], 'default' => [ 'size' => 40 ] ] );
		$this->add_control( 'pause_delay',  [ 'label' => 'Pause (ms)',        'type' => \Elementor\Controls_Manager::SLIDER, 'range' => [ 'ms' => [ 'min' => 500, 'max' => 5000 ] ], 'default' => [ 'size' => 2000 ] ] );
		$this->add_control( 'loop', [ 'label' => 'Loop', 'type' => \Elementor\Controls_Manager::SWITCHER, 'default' => 'yes' ] );

		$this->end_controls_section();

		$this->start_controls_section( 'section_style', [ 'label' => 'Style', 'tab' => \Elementor\Controls_Manager::TAB_STYLE ] );
		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
			'name'     => 'heading_typo',
			'selector' => '{{WRAPPER}} .sf-tw-heading',
		] );
		$this->add_control( 'animated_color', [
			'label'     => 'Animated Word Color',
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .sf-tw-word' => 'color: {{VALUE}};' ],
		] );
		$this->add_control( 'cursor_color', [
			'label'     => 'Cursor Color',
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .sf-tw-cursor' => 'color: {{VALUE}};border-color:{{VALUE}};' ],
		] );
		$this->add_control( 'text_align', [
			'label'     => 'Alignment',
			'type'      => \Elementor\Controls_Manager::CHOOSE,
			'options'   => [ 'left' => [ 'icon' => 'eicon-text-align-left', 'title' => 'Left' ], 'center' => [ 'icon' => 'eicon-text-align-center', 'title' => 'Center' ], 'right' => [ 'icon' => 'eicon-text-align-right', 'title' => 'Right' ] ],
			'default'   => 'left',
			'selectors' => [ '{{WRAPPER}} .sf-tw-heading' => 'text-align: {{VALUE}};' ],
		] );
		$this->end_controls_section();
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$uid  = 'sf-tw-' . $this->get_id();
		$tag  = esc_attr( $s['tag'] );
		$words = array_column( $s['words'], 'word' );
		$words_json = wp_json_encode( $words );
		$type_spd  = ! empty( $s['type_speed']['size'] )   ? (int) $s['type_speed']['size']   : 80;
		$del_spd   = ! empty( $s['delete_speed']['size'] ) ? (int) $s['delete_speed']['size'] : 40;
		$pause     = ! empty( $s['pause_delay']['size'] )  ? (int) $s['pause_delay']['size']  : 2000;
		$loop      = 'yes' === $s['loop'] ? 'true' : 'false';
		?>
		<<?php echo $tag; ?> class="sf-tw-heading" id="<?php echo esc_attr($uid); ?>">
			<?php if ( $s['before_text'] ) : ?><?php echo esc_html($s['before_text']); ?> <?php endif; ?>
			<span class="sf-tw-word" style="color:var(--sf-color-primary,#FF5E2E);"></span><span class="sf-tw-cursor" style="display:inline-block;width:2px;height:1em;background:var(--sf-color-primary,#FF5E2E);margin-left:2px;vertical-align:middle;animation:sfBlink .7s step-end infinite;" aria-hidden="true"></span>
			<?php if ( $s['after_text'] ) : ?> <?php echo esc_html($s['after_text']); ?><?php endif; ?>
		</<?php echo $tag; ?>>
		<style>@keyframes sfBlink{0%,100%{opacity:1}50%{opacity:0}}</style>
		<script>
		(function(){
			var words=<?php echo $words_json; ?>;
			var el=document.querySelector('#<?php echo esc_js($uid); ?> .sf-tw-word');
			if(!el||!words.length)return;
			var typeSpd=<?php echo $type_spd; ?>;
			var delSpd=<?php echo $del_spd; ?>;
			var pause=<?php echo $pause; ?>;
			var loop=<?php echo $loop; ?>;
			var wi=0;var ci=0;var deleting=false;var done=false;
			function tick(){
				var word=words[wi];
				if(!deleting){
					el.textContent=word.slice(0,++ci);
					if(ci===word.length){
						deleting=true;
						setTimeout(tick,pause);return;
					}
					setTimeout(tick,typeSpd);
				}else{
					el.textContent=word.slice(0,--ci);
					if(ci===0){
						deleting=false;
						wi=(wi+1)%words.length;
						if(!loop&&wi===0){done=true;return;}
						setTimeout(tick,300);return;
					}
					setTimeout(tick,delSpd);
				}
			}
			tick();
		})();
		</script>
		<?php
	}
}
