<?php
/**
 * Elementor Video Popup Widget
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Video Popup Widget Class
 *
 * @since 1.0.0
 */
class Starter_Flavor_Video_Popup_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'starter_flavor_video_popup';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Video Popup', 'starter-flavor' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-video-camera';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'starter-flavor' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Thumbnail Image
		$this->add_control(
			'thumbnail_image',
			array(
				'label'   => esc_html__( 'Thumbnail Image', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => array(
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				),
			)
		);

		// Video Source
		$this->add_control(
			'video_source',
			array(
				'label'   => esc_html__( 'Video Source', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'youtube',
				'options' => array(
					'youtube' => esc_html__( 'YouTube', 'starter-flavor' ),
					'vimeo'   => esc_html__( 'Vimeo', 'starter-flavor' ),
					'mp4'     => esc_html__( 'MP4 File', 'starter-flavor' ),
				),
			)
		);

		// YouTube URL
		$this->add_control(
			'youtube_url',
			array(
				'label'       => esc_html__( 'YouTube URL', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'https://www.youtube.com/watch?v=...', 'starter-flavor' ),
				'condition'   => array(
					'video_source' => 'youtube',
				),
			)
		);

		// Vimeo URL
		$this->add_control(
			'vimeo_url',
			array(
				'label'       => esc_html__( 'Vimeo URL', 'starter-flavor' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'https://vimeo.com/...', 'starter-flavor' ),
				'condition'   => array(
					'video_source' => 'vimeo',
				),
			)
		);

		// MP4 File
		$this->add_control(
			'mp4_file',
			array(
				'label'   => esc_html__( 'Video File', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'media_type' => 'video',
				'condition'   => array(
					'video_source' => 'mp4',
				),
			)
		);

		// Autoplay in Lightbox
		$this->add_control(
			'lightbox_autoplay',
			array(
				'label'        => esc_html__( 'Autoplay in Lightbox', 'starter-flavor' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'starter-flavor' ),
				'label_off'    => esc_html__( 'No', 'starter-flavor' ),
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->end_controls_section();

		// Button Style Section
		$this->start_controls_section(
			'button_style_section',
			array(
				'label' => esc_html__( 'Play Button', 'starter-flavor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Play Button Icon
		$this->add_control(
			'play_button_icon',
			array(
				'label'   => esc_html__( 'Icon', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::ICONS,
				'default' => array(
					'value'   => 'fas fa-play',
					'library' => 'fa-solid',
				),
			)
		);

		$this->add_control(
			'button_size',
			array(
				'label'   => esc_html__( 'Button Size (px)', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 80,
				),
				'range'   => array(
					'px' => array(
						'min' => 40,
						'max' => 200,
					),
				),
			)
		);

		$this->add_control(
			'button_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => 'rgba(255, 255, 255, 0.9)',
				'selectors' => array(
					'{{WRAPPER}} .video-play-btn' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'button_icon_color',
			array(
				'label'     => esc_html__( 'Icon Color', 'starter-flavor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FF5E2E',
				'selectors' => array(
					'{{WRAPPER}} .video-play-btn i' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'button_hover_scale',
			array(
				'label'   => esc_html__( 'Hover Scale', 'starter-flavor' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 1.1,
				),
				'range'   => array(
					'px' => array(
						'min'  => 1,
						'max'  => 1.5,
						'step' => 0.1,
					),
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$thumbnail = isset( $settings['thumbnail_image']['url'] ) ? $settings['thumbnail_image']['url'] : '';
		$video_source = isset( $settings['video_source'] ) ? $settings['video_source'] : 'youtube';
		$youtube_url = isset( $settings['youtube_url'] ) ? $settings['youtube_url'] : '';
		$vimeo_url = isset( $settings['vimeo_url'] ) ? $settings['vimeo_url'] : '';
		$mp4_file = isset( $settings['mp4_file']['url'] ) ? $settings['mp4_file']['url'] : '';
		$autoplay = isset( $settings['lightbox_autoplay'] ) && 'yes' === $settings['lightbox_autoplay'];
		$play_icon = isset( $settings['play_button_icon']['value'] ) ? $settings['play_button_icon']['value'] : 'fas fa-play';
		$button_size = isset( $settings['button_size']['size'] ) ? intval( $settings['button_size']['size'] ) : 80;
		$button_hover_scale = isset( $settings['button_hover_scale']['size'] ) ? floatval( $settings['button_hover_scale']['size'] ) : 1.1;

		if ( empty( $thumbnail ) ) {
			echo '<p>' . esc_html__( 'Please select a thumbnail image', 'starter-flavor' ) . '</p>';
			return;
		}

		// Determine video URL
		$video_url = '';
		switch ( $video_source ) {
			case 'youtube':
				$video_url = $youtube_url;
				break;
			case 'vimeo':
				$video_url = $vimeo_url;
				break;
			case 'mp4':
				$video_url = $mp4_file;
				break;
		}

		if ( empty( $video_url ) ) {
			echo '<p>' . esc_html__( 'Please provide a video URL', 'starter-flavor' ) . '</p>';
			return;
		}

		?>
		<div class="video-popup-wrapper">
			<div class="video-thumbnail-container" style="--button-hover-scale: <?php echo esc_attr( $button_hover_scale ); ?>;">
				<img src="<?php echo esc_url( $thumbnail ); ?>" alt="<?php esc_attr_e( 'Video Thumbnail', 'starter-flavor' ); ?>" class="video-thumbnail" />
				<div class="video-overlay">
					<button class="video-play-btn"
						data-src="<?php echo esc_attr( $video_url ); ?>"
						data-video-type="<?php echo esc_attr( $video_source ); ?>"
						data-autoplay="<?php echo esc_attr( $autoplay ? 'true' : 'false' ); ?>"
						style="width: <?php echo esc_attr( $button_size ); ?>px; height: <?php echo esc_attr( $button_size ); ?>px;"
						aria-label="<?php esc_attr_e( 'Play Video', 'starter-flavor' ); ?>"
						role="button"
						tabindex="0">
						<i class="<?php echo esc_attr( $play_icon ); ?>"></i>
					</button>
				</div>
			</div>
		</div>
		<?php
	}
}
