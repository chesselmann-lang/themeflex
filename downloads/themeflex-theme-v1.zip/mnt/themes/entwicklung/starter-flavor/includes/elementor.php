<?php
/**
 * Elementor Theme Support
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add Elementor location support
 *
 * @since 1.0.0
 */
function starter_flavor_elementor_locations_included( $elementor_locations ) {
	$elementor_locations['header']  = esc_html__( 'Header', 'starter-flavor' );
	$elementor_locations['footer']  = esc_html__( 'Footer', 'starter-flavor' );
	$elementor_locations['single']  = esc_html__( 'Single', 'starter-flavor' );
	$elementor_locations['archive'] = esc_html__( 'Archive', 'starter-flavor' );

	return $elementor_locations;
}
add_filter( 'elementor/theme/register_locations', 'starter_flavor_elementor_locations_included' );

/**
 * Elementor theme compatibility init
 *
 * @since 1.0.0
 */
function starter_flavor_elementor_init() {
	// Add Elementor theme compatibility
	if ( defined( 'ELEMENTOR_VERSION' ) ) {
		add_theme_support( 'elementor' );
	}
}
add_action( 'after_setup_theme', 'starter_flavor_elementor_init' );

/**
 * Enqueue Elementor compatibility styles
 *
 * @since 1.0.0
 */
function starter_flavor_elementor_enqueue_styles() {
	if ( defined( 'ELEMENTOR_VERSION' ) ) {
		wp_enqueue_style(
			'starter-flavor-elementor',
			STARTER_FLAVOR_THEME_URL . '/styles/elementor-compat.css',
			array(),
			STARTER_FLAVOR_VERSION
		);
	}
}
add_action( 'wp_enqueue_scripts', 'starter_flavor_elementor_enqueue_styles' );

/**
 * Register custom Elementor widgets
 *
 * @since 1.0.0
 */
function starter_flavor_register_elementor_widgets( $widgets_manager ) {
	if ( ! defined( 'ELEMENTOR_VERSION' ) ) {
		return;
	}

	// Hero Section Widget
	$hero_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/hero-section.php';
	if ( file_exists( $hero_widget_path ) ) {
		require_once $hero_widget_path;
		if ( class_exists( 'Starter_Flavor_Hero_Section_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Hero_Section_Widget() );
		}
	}

	// CTA Box Widget
	$cta_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/cta-box.php';
	if ( file_exists( $cta_widget_path ) ) {
		require_once $cta_widget_path;
		if ( class_exists( 'Starter_Flavor_CTA_Box_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_CTA_Box_Widget() );
		}
	}

	// Testimonial Widget
	$testimonial_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/testimonial.php';
	if ( file_exists( $testimonial_widget_path ) ) {
		require_once $testimonial_widget_path;
		if ( class_exists( 'Starter_Flavor_Testimonial_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Testimonial_Widget() );
		}
	}

	// Pricing Table Widget
	$pricing_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/pricing-table.php';
	if ( file_exists( $pricing_widget_path ) ) {
		require_once $pricing_widget_path;
		if ( class_exists( 'Starter_Flavor_Pricing_Table_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Pricing_Table_Widget() );
		}
	}

	// Team Member Widget
	$team_member_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/team-member.php';
	if ( file_exists( $team_member_widget_path ) ) {
		require_once $team_member_widget_path;
		if ( class_exists( 'Starter_Flavor_Team_Member_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Team_Member_Widget() );
		}
	}

	// Services/Features Widget
	$services_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/services.php';
	if ( file_exists( $services_widget_path ) ) {
		require_once $services_widget_path;
		if ( class_exists( 'Starter_Flavor_Services_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Services_Widget() );
		}
	}

	// Counter/Stats Widget
	$counter_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/counter-stats.php';
	if ( file_exists( $counter_widget_path ) ) {
		require_once $counter_widget_path;
		if ( class_exists( 'Starter_Flavor_Counter_Stats_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Counter_Stats_Widget() );
		}
	}

	// Icon Box Widget
	$icon_box_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/icon-box.php';
	if ( file_exists( $icon_box_widget_path ) ) {
		require_once $icon_box_widget_path;
		if ( class_exists( 'Starter_Flavor_Icon_Box_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Icon_Box_Widget() );
		}
	}

	// Accordion & Tabs Widget
	$accordion_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/accordion-tabs.php';
	if ( file_exists( $accordion_widget_path ) ) {
		require_once $accordion_widget_path;
		if ( class_exists( 'Starter_Flavor_Accordion_Tabs_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Accordion_Tabs_Widget() );
		}
	}

	// Contact Form Widget
	$contact_form_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/contact-form.php';
	if ( file_exists( $contact_form_widget_path ) ) {
		require_once $contact_form_widget_path;
		if ( class_exists( 'Starter_Flavor_Contact_Form_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Contact_Form_Widget() );
		}
	}

	// Image Gallery Widget
	$gallery_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/image-gallery.php';
	if ( file_exists( $gallery_widget_path ) ) {
		require_once $gallery_widget_path;
		if ( class_exists( 'Starter_Flavor_Image_Gallery_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Image_Gallery_Widget() );
		}
	}

	// Blog Carousel Widget
	$blog_carousel_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/blog-carousel.php';
	if ( file_exists( $blog_carousel_widget_path ) ) {
		require_once $blog_carousel_widget_path;
		if ( class_exists( 'Starter_Flavor_Blog_Carousel_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Blog_Carousel_Widget() );
		}
	}

	// Slider Widget
	$slider_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/slider.php';
	if ( file_exists( $slider_widget_path ) ) {
		require_once $slider_widget_path;
		if ( class_exists( 'Starter_Flavor_Slider_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Slider_Widget() );
		}
	}

	// Progress Bar Widget
	$progress_bar_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/progress-bar.php';
	if ( file_exists( $progress_bar_widget_path ) ) {
		require_once $progress_bar_widget_path;
		if ( class_exists( 'Starter_Flavor_Progress_Bar_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Progress_Bar_Widget() );
		}
	}

	// Countdown Widget
	$countdown_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/countdown.php';
	if ( file_exists( $countdown_widget_path ) ) {
		require_once $countdown_widget_path;
		if ( class_exists( 'Starter_Flavor_Countdown_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Countdown_Widget() );
		}
	}

	// Social Icons Widget
	$social_icons_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/social-icons.php';
	if ( file_exists( $social_icons_widget_path ) ) {
		require_once $social_icons_widget_path;
		if ( class_exists( 'Starter_Flavor_Social_Icons_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Social_Icons_Widget() );
		}
	}

	// Nav Menu Widget
	$nav_menu_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/nav-menu.php';
	if ( file_exists( $nav_menu_widget_path ) ) {
		require_once $nav_menu_widget_path;
		if ( class_exists( 'Starter_Flavor_Nav_Menu_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Nav_Menu_Widget() );
		}
	}

	// Site Logo Widget
	$site_logo_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/site-logo.php';
	if ( file_exists( $site_logo_widget_path ) ) {
		require_once $site_logo_widget_path;
		if ( class_exists( 'Starter_Flavor_Site_Logo_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Site_Logo_Widget() );
		}
	}

	// Post Grid Widget
	$post_grid_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/post-grid.php';
	if ( file_exists( $post_grid_widget_path ) ) {
		require_once $post_grid_widget_path;
		if ( class_exists( 'Starter_Flavor_Post_Grid_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Post_Grid_Widget() );
		}
	}

	// Fancy Heading Widget
	$fancy_heading_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/fancy-heading.php';
	if ( file_exists( $fancy_heading_widget_path ) ) {
		require_once $fancy_heading_widget_path;
		if ( class_exists( 'Starter_Flavor_Fancy_Heading_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Fancy_Heading_Widget() );
		}
	}

	// Chart Widget
	$chart_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/chart.php';
	if ( file_exists( $chart_widget_path ) ) {
		require_once $chart_widget_path;
		if ( class_exists( 'Starter_Flavor_Chart_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Chart_Widget() );
		}
	}

	// Radial Progress Widget
	$radial_progress_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/radial-progress.php';
	if ( file_exists( $radial_progress_widget_path ) ) {
		require_once $radial_progress_widget_path;
		if ( class_exists( 'Starter_Flavor_Radial_Progress_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Radial_Progress_Widget() );
		}
	}

	// Dual Button Widget
	$dual_button_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/dual-button.php';
	if ( file_exists( $dual_button_widget_path ) ) {
		require_once $dual_button_widget_path;
		if ( class_exists( 'Starter_Flavor_Dual_Button_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Dual_Button_Widget() );
		}
	}

	// Star Rating Widget
	$star_rating_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/star-rating.php';
	if ( file_exists( $star_rating_widget_path ) ) {
		require_once $star_rating_widget_path;
		if ( class_exists( 'Starter_Flavor_Star_Rating_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Star_Rating_Widget() );
		}
	}

	// Share Buttons Widget
	$share_buttons_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/share-buttons.php';
	if ( file_exists( $share_buttons_widget_path ) ) {
		require_once $share_buttons_widget_path;
		if ( class_exists( 'Starter_Flavor_Share_Buttons_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Share_Buttons_Widget() );
		}
	}

	// Google Maps Widget
	$google_maps_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/google-maps.php';
	if ( file_exists( $google_maps_widget_path ) ) {
		require_once $google_maps_widget_path;
		if ( class_exists( 'Starter_Flavor_Google_Maps_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Google_Maps_Widget() );
		}
	}

	// Category Grid Widget
	$category_grid_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/category-grid.php';
	if ( file_exists( $category_grid_widget_path ) ) {
		require_once $category_grid_widget_path;
		if ( class_exists( 'Starter_Flavor_Category_Grid_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Category_Grid_Widget() );
		}
	}

	// Portfolio Grid Widget
	$portfolio_grid_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/portfolio-grid.php';
	if ( file_exists( $portfolio_grid_widget_path ) ) {
		require_once $portfolio_grid_widget_path;
		if ( class_exists( 'Starter_Flavor_Portfolio_Grid_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Portfolio_Grid_Widget() );
		}
	}

	// Before / After Widget
	$before_after_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/before-after.php';
	if ( file_exists( $before_after_widget_path ) ) {
		require_once $before_after_widget_path;
		if ( class_exists( 'Starter_Flavor_Before_After_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Before_After_Widget() );
		}
	}

	// Breadcrumbs Widget
	$breadcrumbs_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/breadcrumbs-widget.php';
	if ( file_exists( $breadcrumbs_widget_path ) ) {
		require_once $breadcrumbs_widget_path;
		if ( class_exists( 'Starter_Flavor_Breadcrumbs_Widget_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Breadcrumbs_Widget_Widget() );
		}
	}

	// Flip Box Widget
	$flip_box_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/flip-box.php';
	if ( file_exists( $flip_box_widget_path ) ) {
		require_once $flip_box_widget_path;
		if ( class_exists( 'Starter_Flavor_Flip_Box_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Flip_Box_Widget() );
		}
	}

	// Hotspot Image Widget
	$hotspot_image_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/hotspot-image.php';
	if ( file_exists( $hotspot_image_widget_path ) ) {
		require_once $hotspot_image_widget_path;
		if ( class_exists( 'Starter_Flavor_Hotspot_Image_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Hotspot_Image_Widget() );
		}
	}

	// Lottie Animation Widget
	$lottie_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/lottie.php';
	if ( file_exists( $lottie_widget_path ) ) {
		require_once $lottie_widget_path;
		if ( class_exists( 'Starter_Flavor_Lottie_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Lottie_Widget() );
		}
	}

	// Marquee / Ticker Widget
	$marquee_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/marquee.php';
	if ( file_exists( $marquee_widget_path ) ) {
		require_once $marquee_widget_path;
		if ( class_exists( 'Starter_Flavor_Marquee_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Marquee_Widget() );
		}
	}

	// Price List Widget
	$price_list_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/price-list.php';
	if ( file_exists( $price_list_widget_path ) ) {
		require_once $price_list_widget_path;
		if ( class_exists( 'Starter_Flavor_Price_List_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Price_List_Widget() );
		}
	}

	// Product Categories Widget (WooCommerce)
	$product_categories_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/product-categories.php';
	if ( file_exists( $product_categories_widget_path ) ) {
		require_once $product_categories_widget_path;
		if ( class_exists( 'Starter_Flavor_Product_Categories_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Product_Categories_Widget() );
		}
	}

	// Product Grid Widget (WooCommerce)
	$product_grid_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/product-grid.php';
	if ( file_exists( $product_grid_widget_path ) ) {
		require_once $product_grid_widget_path;
		if ( class_exists( 'Starter_Flavor_Product_Grid_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Product_Grid_Widget() );
		}
	}

	// Form Widget (SF Native Form)
	$sf_form_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/sf-form.php';
	if ( file_exists( $sf_form_widget_path ) ) {
		require_once $sf_form_widget_path;
		if ( class_exists( 'Starter_Flavor_Form_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Form_Widget() );
		}
	}

	// Data Table Widget
	$table_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/table.php';
	if ( file_exists( $table_widget_path ) ) {
		require_once $table_widget_path;
		if ( class_exists( 'Starter_Flavor_Table_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Table_Widget() );
		}
	}

	// Timeline Widget
	$timeline_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/timeline.php';
	if ( file_exists( $timeline_widget_path ) ) {
		require_once $timeline_widget_path;
		if ( class_exists( 'Starter_Flavor_Timeline_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Timeline_Widget() );
		}
	}

	// Video Popup Widget
	$video_popup_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/video-popup.php';
	if ( file_exists( $video_popup_widget_path ) ) {
		require_once $video_popup_widget_path;
		if ( class_exists( 'Starter_Flavor_Video_Popup_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Video_Popup_Widget() );
		}
	}

	// Image Comparison Slider Widget
	$image_comparison_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/image-comparison.php';
	if ( file_exists( $image_comparison_widget_path ) ) {
		require_once $image_comparison_widget_path;
		if ( class_exists( 'Starter_Flavor_Image_Comparison_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Image_Comparison_Widget() );
		}
	}

	// Advanced Tabs Widget
	$tabs_advanced_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/tabs-advanced.php';
	if ( file_exists( $tabs_advanced_widget_path ) ) {
		require_once $tabs_advanced_widget_path;
		if ( class_exists( 'Starter_Flavor_Tabs_Advanced_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Tabs_Advanced_Widget() );
		}
	}

	// Modal Popup Widget
	$modal_popup_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/modal-popup.php';
	if ( file_exists( $modal_popup_widget_path ) ) {
		require_once $modal_popup_widget_path;
		if ( class_exists( 'Starter_Flavor_Modal_Popup_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Modal_Popup_Widget() );
		}
	}

	// Testimonial Carousel Widget
	$testimonial_carousel_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/testimonial-carousel.php';
	if ( file_exists( $testimonial_carousel_widget_path ) ) {
		require_once $testimonial_carousel_widget_path;
		if ( class_exists( 'Starter_Flavor_Testimonial_Carousel_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Testimonial_Carousel_Widget() );
		}
	}

	// Alert Box Widget
	$alert_box_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/alert-box.php';
	if ( file_exists( $alert_box_widget_path ) ) {
		require_once $alert_box_widget_path;
		if ( class_exists( 'Starter_Flavor_Alert_Box_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Alert_Box_Widget() );
		}
	}

	// Process Steps Widget
	$number_list_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/number-list.php';
	if ( file_exists( $number_list_widget_path ) ) {
		require_once $number_list_widget_path;
		if ( class_exists( 'Starter_Flavor_Number_List_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Number_List_Widget() );
		}
	}

	// Icon List Widget
	$icon_list_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/icon-list.php';
	if ( file_exists( $icon_list_widget_path ) ) {
		require_once $icon_list_widget_path;
		if ( class_exists( 'Starter_Flavor_Icon_List_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Icon_List_Widget() );
		}
	}

	// Counter Box Widget
	$counter_box_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/counter-box.php';
	if ( file_exists( $counter_box_widget_path ) ) {
		require_once $counter_box_widget_path;
		if ( class_exists( 'Starter_Flavor_Counter_Box_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Counter_Box_Widget() );
		}
	}

	// Typewriter Text Widget
	$typewriter_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/typewriter.php';
	if ( file_exists( $typewriter_widget_path ) ) {
		require_once $typewriter_widget_path;
		if ( class_exists( 'Starter_Flavor_Typewriter_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Typewriter_Widget() );
		}
	}

	// Pricing Toggle Widget
	$pricing_toggle_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/pricing-toggle.php';
	if ( file_exists( $pricing_toggle_widget_path ) ) {
		require_once $pricing_toggle_widget_path;
		if ( class_exists( 'Starter_Flavor_Pricing_Toggle_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Pricing_Toggle_Widget() );
		}
	}

	// Announcement Bar Widget
	$announcement_bar_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/announcement-bar.php';
	if ( file_exists( $announcement_bar_path ) ) {
		require_once $announcement_bar_path;
		if ( class_exists( 'Starter_Flavor_Announcement_Bar_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Announcement_Bar_Widget() );
		}
	}

	// Audio Player Widget
	$audio_player_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/audio-player.php';
	if ( file_exists( $audio_player_path ) ) {
		require_once $audio_player_path;
		if ( class_exists( 'Starter_Flavor_Audio_Player_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Audio_Player_Widget() );
		}
	}

	// Award Badges Widget
	$award_badges_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/award-badges.php';
	if ( file_exists( $award_badges_path ) ) {
		require_once $award_badges_path;
		if ( class_exists( 'Starter_Flavor_Award_Badges_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Award_Badges_Widget() );
		}
	}

	// Changelog Widget
	$changelog_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/changelog.php';
	if ( file_exists( $changelog_path ) ) {
		require_once $changelog_path;
		if ( class_exists( 'Starter_Flavor_Changelog_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Changelog_Widget() );
		}
	}

	// Code Snippet Widget
	$code_snippet_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/code-snippet.php';
	if ( file_exists( $code_snippet_path ) ) {
		require_once $code_snippet_path;
		if ( class_exists( 'Starter_Flavor_Code_Snippet_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Code_Snippet_Widget() );
		}
	}

	// Exit Intent Widget
	$exit_intent_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/exit-intent.php';
	if ( file_exists( $exit_intent_path ) ) {
		require_once $exit_intent_path;
		if ( class_exists( 'Starter_Flavor_Exit_Intent_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Exit_Intent_Widget() );
		}
	}

	// Horizontal Scroll Widget
	$horizontal_scroll_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/horizontal-scroll.php';
	if ( file_exists( $horizontal_scroll_path ) ) {
		require_once $horizontal_scroll_path;
		if ( class_exists( 'Starter_Flavor_Horizontal_Scroll_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Horizontal_Scroll_Widget() );
		}
	}

	// Isotope Portfolio Widget
	$isotope_portfolio_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/isotope-portfolio.php';
	if ( file_exists( $isotope_portfolio_path ) ) {
		require_once $isotope_portfolio_path;
		if ( class_exists( 'Starter_Flavor_Isotope_Portfolio_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Isotope_Portfolio_Widget() );
		}
	}

	// Morphing Text Widget
	$morphing_text_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/morphing-text.php';
	if ( file_exists( $morphing_text_path ) ) {
		require_once $morphing_text_path;
		if ( class_exists( 'Starter_Flavor_Morphing_Text_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Morphing_Text_Widget() );
		}
	}

	// Particle Background Widget
	$particle_background_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/particle-background.php';
	if ( file_exists( $particle_background_path ) ) {
		require_once $particle_background_path;
		if ( class_exists( 'Starter_Flavor_Particle_Background_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Particle_Background_Widget() );
		}
	}

	// Pricing Calculator Widget
	$pricing_calculator_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/pricing-calculator.php';
	if ( file_exists( $pricing_calculator_path ) ) {
		require_once $pricing_calculator_path;
		if ( class_exists( 'Starter_Flavor_Pricing_Calculator_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Pricing_Calculator_Widget() );
		}
	}

	// Restaurant Menu Widget
	$restaurant_menu_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/restaurant-menu.php';
	if ( file_exists( $restaurant_menu_path ) ) {
		require_once $restaurant_menu_path;
		if ( class_exists( 'Starter_Flavor_Restaurant_Menu_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Restaurant_Menu_Widget() );
		}
	}

	// Social Proof Widget
	$social_proof_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/social-proof.php';
	if ( file_exists( $social_proof_path ) ) {
		require_once $social_proof_path;
		if ( class_exists( 'Starter_Flavor_Social_Proof_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Social_Proof_Widget() );
		}
	}

	// Tilt Card Widget
	$tilt_card_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/tilt-card.php';
	if ( file_exists( $tilt_card_path ) ) {
		require_once $tilt_card_path;
		if ( class_exists( 'Starter_Flavor_Tilt_Card_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Tilt_Card_Widget() );
		}
	}

	// Whatsapp Button Widget
	$whatsapp_button_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/whatsapp-button.php';
	if ( file_exists( $whatsapp_button_path ) ) {
		require_once $whatsapp_button_path;
		if ( class_exists( 'Starter_Flavor_Whatsapp_Button_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Whatsapp_Button_Widget() );
		}
	}

	// Ai Content Widget
	$ai_content_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/ai-content.php';
	if ( file_exists( $ai_content_path ) ) {
		require_once $ai_content_path;
		if ( class_exists( 'Starter_Flavor_Ai_Content_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Ai_Content_Widget() );
		}
	}

	// Comparison Table Feature Widget
	$comparison_table_feature_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/comparison-table-feature.php';
	if ( file_exists( $comparison_table_feature_path ) ) {
		require_once $comparison_table_feature_path;
		if ( class_exists( 'Starter_Flavor_Comparison_Table_Feature_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Comparison_Table_Feature_Widget() );
		}
	}

	// Cookie Consent Widget
	$cookie_consent_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/cookie-consent.php';
	if ( file_exists( $cookie_consent_path ) ) {
		require_once $cookie_consent_path;
		if ( class_exists( 'Starter_Flavor_Cookie_Consent_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Cookie_Consent_Widget() );
		}
	}

	// Faq Search Widget
	$faq_search_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/faq-search.php';
	if ( file_exists( $faq_search_path ) ) {
		require_once $faq_search_path;
		if ( class_exists( 'Starter_Flavor_Faq_Search_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Faq_Search_Widget() );
		}
	}

	// Feature Showcase Widget
	$feature_showcase_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/feature-showcase.php';
	if ( file_exists( $feature_showcase_path ) ) {
		require_once $feature_showcase_path;
		if ( class_exists( 'Starter_Flavor_Feature_Showcase_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Feature_Showcase_Widget() );
		}
	}

	// Lead Quiz Widget
	$lead_quiz_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/lead-quiz.php';
	if ( file_exists( $lead_quiz_path ) ) {
		require_once $lead_quiz_path;
		if ( class_exists( 'Starter_Flavor_Lead_Quiz_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Lead_Quiz_Widget() );
		}
	}

	// Logo Cloud Widget
	$logo_cloud_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/logo-cloud.php';
	if ( file_exists( $logo_cloud_path ) ) {
		require_once $logo_cloud_path;
		if ( class_exists( 'Starter_Flavor_Logo_Cloud_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Logo_Cloud_Widget() );
		}
	}

	// Mega Cta Widget
	$mega_cta_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/mega-cta.php';
	if ( file_exists( $mega_cta_path ) ) {
		require_once $mega_cta_path;
		if ( class_exists( 'Starter_Flavor_Mega_Cta_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Mega_Cta_Widget() );
		}
	}

	// Newsletter Form Widget
	$newsletter_form_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/newsletter-form.php';
	if ( file_exists( $newsletter_form_path ) ) {
		require_once $newsletter_form_path;
		if ( class_exists( 'Starter_Flavor_Newsletter_Form_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Newsletter_Form_Widget() );
		}
	}

	// Product Mockup Widget
	$product_mockup_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/product-mockup.php';
	if ( file_exists( $product_mockup_path ) ) {
		require_once $product_mockup_path;
		if ( class_exists( 'Starter_Flavor_Product_Mockup_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Product_Mockup_Widget() );
		}
	}

	// Scroll Trigger Widget
	$scroll_trigger_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/scroll-trigger.php';
	if ( file_exists( $scroll_trigger_path ) ) {
		require_once $scroll_trigger_path;
		if ( class_exists( 'Starter_Flavor_Scroll_Trigger_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Scroll_Trigger_Widget() );
		}
	}

	// Split Content Widget
	$split_content_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/split-content.php';
	if ( file_exists( $split_content_path ) ) {
		require_once $split_content_path;
		if ( class_exists( 'Starter_Flavor_Split_Content_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Split_Content_Widget() );
		}
	}

	// Sticky Float Widget
	$sticky_float_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/sticky-float.php';
	if ( file_exists( $sticky_float_path ) ) {
		require_once $sticky_float_path;
		if ( class_exists( 'Starter_Flavor_Sticky_Float_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Sticky_Float_Widget() );
		}
	}

	// Text Reveal Widget
	$text_reveal_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/text-reveal.php';
	if ( file_exists( $text_reveal_path ) ) {
		require_once $text_reveal_path;
		if ( class_exists( 'Starter_Flavor_Text_Reveal_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Text_Reveal_Widget() );
		}
	}
}
add_action( 'elementor/widgets/register', 'starter_flavor_register_elementor_widgets' );


/* ============================================================================
   ELEMENTOR KIT SYNCHRONISATION
   Automatically syncs Starter Flavor skin colors + fonts into the Elementor
   Global Colors and Global Fonts (Kit), so designers only set values once.

   Runs:
   - After customize_save_after  (Customizer changes)
   - After sf_skin_switched      (skin change from Theme Options)
   - Once on activation          (first-time setup)
   ============================================================================ */

/**
 * Push current skin's design tokens into Elementor's active kit.
 *
 * @since 1.1.0
 * @param bool $force Re-write even if nothing appears to have changed.
 */
function starter_flavor_sync_elementor_kit( $force = false ) {
	if ( ! defined( 'ELEMENTOR_VERSION' ) ) {
		return;
	}

	$kit_id = get_option( 'elementor_active_kit' );
	if ( empty( $kit_id ) ) {
		return;
	}

	// Load active skin colors & fonts
	$skin_manager = function_exists( 'starter_flavor_skin_manager' ) ? starter_flavor_skin_manager() : null;
	if ( ! $skin_manager ) {
		return;
	}
	$skin = $skin_manager->get_skin( $skin_manager->get_active_skin() );
	if ( ! $skin ) {
		return;
	}

	$c   = isset( $skin['colors'] )     ? $skin['colors']     : array();
	$typ = isset( $skin['typography'] ) ? $skin['typography'] : array();

	$primary       = isset( $c['primary'] )       ? $c['primary']       : '#FF5E2E';
	$primary_dark  = isset( $c['primary_dark'] )  ? $c['primary_dark']  : '#ED4C1C';
	$primary_light = isset( $c['primary_light'] ) ? $c['primary_light'] : '#FF8A60';
	$secondary     = isset( $c['secondary'] )     ? $c['secondary']     : '#1F242E';
	$accent        = isset( $c['accent'] )        ? $c['accent']        : '#00D4FF';
	$body_font     = isset( $typ['body_font_family'] )    ? $typ['body_font_family']    : 'Inter';
	$heading_font  = isset( $typ['heading_font_family'] ) ? $typ['heading_font_family'] : 'Inter Tight';

	$settings = get_post_meta( $kit_id, '_elementor_page_settings', true );
	if ( ! is_array( $settings ) ) {
		$settings = array();
	}

	// ── Global Colors ──────────────────────────────────────────────────────
	$global_colors = array(
		array( 'id' => 'sf-primary',       'title' => 'SF Primary',       'color' => $primary ),
		array( 'id' => 'sf-primary-dark',  'title' => 'SF Primary Dark',  'color' => $primary_dark ),
		array( 'id' => 'sf-primary-light', 'title' => 'SF Primary Light', 'color' => $primary_light ),
		array( 'id' => 'sf-secondary',     'title' => 'SF Secondary',     'color' => $secondary ),
		array( 'id' => 'sf-accent',        'title' => 'SF Accent',        'color' => $accent ),
	);

	// Merge with existing colors (keep user-added ones, update SF ones)
	$existing_colors = isset( $settings['system_colors'] ) ? $settings['system_colors'] : array();
	$sf_ids = wp_list_pluck( $global_colors, 'id' );

	// Remove stale SF entries
	$existing_colors = array_filter( $existing_colors, function( $col ) use ( $sf_ids ) {
		return ! in_array( isset( $col['id'] ) ? $col['id'] : '', $sf_ids, true );
	} );

	$settings['system_colors'] = array_values( array_merge( array_values( $existing_colors ), $global_colors ) );

	// ── Global Fonts ───────────────────────────────────────────────────────
	$global_fonts = array(
		array( 'id' => 'sf-body',    'title' => 'SF Body',    'font_family' => $body_font,    'font_weight' => '400' ),
		array( 'id' => 'sf-heading', 'title' => 'SF Heading', 'font_family' => $heading_font, 'font_weight' => '500' ),
	);

	$existing_fonts = isset( $settings['system_typography'] ) ? $settings['system_typography'] : array();
	$sf_font_ids    = wp_list_pluck( $global_fonts, 'id' );
	$existing_fonts = array_filter( $existing_fonts, function( $f ) use ( $sf_font_ids ) {
		return ! in_array( isset( $f['id'] ) ? $f['id'] : '', $sf_font_ids, true );
	} );

	$settings['system_typography'] = array_values( array_merge( array_values( $existing_fonts ), $global_fonts ) );

	// ── Container width ────────────────────────────────────────────────────
	$page_width = get_theme_mod( 'sf_page_width', 1290 );
	if ( ! empty( $page_width ) ) {
		$settings['container_width'] = array(
			'unit'  => 'px',
			'size'  => (int) $page_width,
			'sizes' => array(),
		);
	}

	update_post_meta( $kit_id, '_elementor_page_settings', $settings );

	// Clear Elementor CSS cache so new tokens are rendered
	if ( class_exists( '\Elementor\Plugin' ) ) {
		\Elementor\Plugin::instance()->files_manager->clear_cache();
	}
}

// Trigger sync after Customizer save
add_action( 'customize_save_after', function() {
	if ( get_option( 'sf_elementor_kit_sync', true ) ) {
		starter_flavor_sync_elementor_kit();
	}
} );

// Trigger sync after a skin switch
add_action( 'sf_skin_switched', function() {
	starter_flavor_sync_elementor_kit( true );
} );

// First-time setup: sync once on activation
if ( ! get_option( 'sf_elementor_kit_synced' ) ) {
	add_action( 'init', function() {
		if ( did_action( 'elementor_init' ) || defined( 'ELEMENTOR_VERSION' ) ) {
			starter_flavor_sync_elementor_kit();
			update_option( 'sf_elementor_kit_synced', 1 );
		}
	}, 20 );
}

/**
 * Register Elementor widget category
 *
 * @since 1.0.0
 */
function starter_flavor_register_elementor_category() {
	if ( ! defined( 'ELEMENTOR_VERSION' ) ) {
		return;
	}

	\Elementor\Plugin::$instance->elements_manager->add_category(
		'starter-flavor',
		array(
			'title' => esc_html__( 'Starter Flavor', 'starter-flavor' ),
			'icon'  => 'fa fa-plug',
		)
	);
}
add_action( 'elementor/elements/categories_registered', 'starter_flavor_register_elementor_category' );
