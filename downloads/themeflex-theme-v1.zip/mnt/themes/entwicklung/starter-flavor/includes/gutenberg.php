<?php
/**
 * Gutenberg/Block Editor Integration
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add block editor support
 *
 * @since 1.0.0
 */
function starter_flavor_gutenberg_setup() {
	// Add support for responsive embeds
	add_theme_support( 'responsive-embeds' );

	// Add support for editor styles
	add_theme_support( 'editor-styles' );

	// Enqueue editor styles
	add_editor_style( 'assets/css/editor-blocks.css' );

	// Enable wide/full alignment
	add_theme_support( 'align-wide' );

	// Custom color palette
	add_theme_support( 'editor-color-palette', array(
		array(
			'name'  => esc_html__( 'Primary', 'starter-flavor' ),
			'slug'  => 'primary',
			'color' => '#FF5E2E',
		),
		array(
			'name'  => esc_html__( 'Secondary', 'starter-flavor' ),
			'slug'  => 'secondary',
			'color' => '#1F242E',
		),
		array(
			'name'  => esc_html__( 'Accent', 'starter-flavor' ),
			'slug'  => 'accent',
			'color' => '#2ecc71',
		),
		array(
			'name'  => esc_html__( 'Dark', 'starter-flavor' ),
			'slug'  => 'dark',
			'color' => '#1a1a1a',
		),
		array(
			'name'  => esc_html__( 'Light', 'starter-flavor' ),
			'slug'  => 'light',
			'color' => '#f5f5f5',
		),
		array(
			'name'  => esc_html__( 'White', 'starter-flavor' ),
			'slug'  => 'white',
			'color' => '#ffffff',
		),
	) );

	// Custom font sizes
	add_theme_support( 'editor-font-sizes', array(
		array(
			'name'      => esc_html__( 'Small', 'starter-flavor' ),
			'slug'      => 'small',
			'size'      => 14,
		),
		array(
			'name'      => esc_html__( 'Normal', 'starter-flavor' ),
			'slug'      => 'normal',
			'size'      => 16,
		),
		array(
			'name'      => esc_html__( 'Large', 'starter-flavor' ),
			'slug'      => 'large',
			'size'      => 24,
		),
		array(
			'name'      => esc_html__( 'Extra Large', 'starter-flavor' ),
			'slug'      => 'extra-large',
			'size'      => 32,
		),
		array(
			'name'      => esc_html__( 'Huge', 'starter-flavor' ),
			'slug'      => 'huge',
			'size'      => 48,
		),
	) );
}
add_action( 'after_setup_theme', 'starter_flavor_gutenberg_setup' );

/**
 * Register block patterns
 *
 * @since 1.0.0
 */
function starter_flavor_register_block_patterns() {
	// Hero Section Pattern
	register_block_pattern(
		'starter-flavor/hero-section',
		array(
			'title'       => esc_html__( 'Hero Section', 'starter-flavor' ),
			'description' => esc_html__( 'A full-width hero section with title and CTA', 'starter-flavor' ),
			'content'     => '<!-- wp:cover {"url":"' . STARTER_FLAVOR_THEME_URL . '/images/hero-bg.jpg","dimRatio":50,"contentPosition":"center center","isDark":false} -->
				<div class="wp-block-cover is-light" style="background-image:url(' . STARTER_FLAVOR_THEME_URL . '/images/hero-bg.jpg)"><div class="wp-block-cover__inner-container"><!-- wp:heading {"textAlign":"center","fontSize":"huge"} -->
				<h1 class="wp-block-heading has-text-align-center has-huge-font-size">Welcome to Our Site</h1>
				<!-- /wp:heading -->
				<!-- wp:paragraph {"align":"center"} -->
				<p class="has-text-align-center">Add your compelling message here</p>
				<!-- /wp:paragraph -->
				<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
				<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"primary"} -->
				<div class="wp-block-button"><a class="wp-block-button__link has-primary-background-color has-background">Get Started</a></div>
				<!-- /wp:button --></div>
				<!-- /wp:buttons --></div></div>
				<!-- /wp:cover -->',
			'categories'  => array( 'starter-flavor-hero' ),
			'keywords'    => array( 'hero', 'banner', 'cover' ),
			'viewportWidth' => 1200,
		)
	);

	// CTA Section Pattern
	register_block_pattern(
		'starter-flavor/cta-section',
		array(
			'title'       => esc_html__( 'Call to Action', 'starter-flavor' ),
			'description' => esc_html__( 'A prominent call-to-action section', 'starter-flavor' ),
			'content'     => '<!-- wp:group {"backgroundColor":"primary"} -->
				<div class="wp-block-group has-primary-background-color has-background"><!-- wp:heading {"textAlign":"center","textColor":"white"} -->
				<h2 class="wp-block-heading has-text-align-center has-white-color has-text-color">Ready to Get Started?</h2>
				<!-- /wp:heading -->
				<!-- wp:paragraph {"align":"center","textColor":"white"} -->
				<p class="has-text-align-center has-white-color has-text-color">Join thousands of satisfied customers</p>
				<!-- /wp:paragraph -->
				<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
				<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"white","textColor":"primary"} -->
				<div class="wp-block-button"><a class="wp-block-button__link has-white-background-color has-primary-color has-text-color has-background">Sign Up Now</a></div>
				<!-- /wp:button --></div>
				<!-- /wp:buttons --></div>
				<!-- /wp:group -->',
			'categories'  => array( 'starter-flavor-sections' ),
			'keywords'    => array( 'cta', 'call to action', 'conversion' ),
		)
	);

	// Features Grid Pattern
	register_block_pattern(
		'starter-flavor/features-grid',
		array(
			'title'       => esc_html__( 'Features Grid', 'starter-flavor' ),
			'description' => esc_html__( 'A 3-column grid showcasing features', 'starter-flavor' ),
			'content'     => '<!-- wp:heading {"textAlign":"center"} -->
				<h2 class="wp-block-heading has-text-align-center">Our Features</h2>
				<!-- /wp:heading -->
				<!-- wp:columns {"columns":3} -->
				<div class="wp-block-columns has-3-columns"><!-- wp:column -->
				<div class="wp-block-column"><!-- wp:heading {"level":3} -->
				<h3 class="wp-block-heading">Feature One</h3>
				<!-- /wp:heading -->
				<!-- wp:paragraph -->
				<p>Add description for your first feature here.</p>
				<!-- /wp:paragraph --></div>
				<!-- /wp:column -->
				<!-- wp:column -->
				<div class="wp-block-column"><!-- wp:heading {"level":3} -->
				<h3 class="wp-block-heading">Feature Two</h3>
				<!-- /wp:heading -->
				<!-- wp:paragraph -->
				<p>Add description for your second feature here.</p>
				<!-- /wp:paragraph --></div>
				<!-- /wp:column -->
				<!-- wp:column -->
				<div class="wp-block-column"><!-- wp:heading {"level":3} -->
				<h3 class="wp-block-heading">Feature Three</h3>
				<!-- /wp:heading -->
				<!-- wp:paragraph -->
				<p>Add description for your third feature here.</p>
				<!-- /wp:paragraph --></div>
				<!-- /wp:column --></div>
				<!-- /wp:columns -->',
			'categories'  => array( 'starter-flavor-sections' ),
			'keywords'    => array( 'features', 'columns', 'grid' ),
		)
	);

	// Testimonial Pattern
	register_block_pattern(
		'starter-flavor/testimonial',
		array(
			'title'       => esc_html__( 'Testimonial', 'starter-flavor' ),
			'description' => esc_html__( 'A customer testimonial block', 'starter-flavor' ),
			'content'     => '<!-- wp:group {"backgroundColor":"light"} -->
				<div class="wp-block-group has-light-background-color has-background"><!-- wp:quote -->
				<blockquote class="wp-block-quote"><p>This is an amazing product that transformed my business!</p><cite>John Doe, CEO</cite></blockquote>
				<!-- /wp:quote --></div>
				<!-- /wp:group -->',
			'categories'  => array( 'starter-flavor-sections' ),
			'keywords'    => array( 'testimonial', 'quote', 'customer' ),
		)
	);

	// Team Member Pattern
	register_block_pattern(
		'starter-flavor/team-member',
		array(
			'title'       => esc_html__( 'Team Member', 'starter-flavor' ),
			'description' => esc_html__( 'A team member showcase card', 'starter-flavor' ),
			'content'     => '<!-- wp:group -->
				<div class="wp-block-group"><!-- wp:image {"sizeSlug":"large"} -->
				<figure class="wp-block-image size-large"><img src="' . STARTER_FLAVOR_THEME_URL . '/images/team-placeholder.jpg" alt=""/></figure>
				<!-- /wp:image -->
				<!-- wp:heading {"textAlign":"center","level":3} -->
				<h3 class="wp-block-heading has-text-align-center">Team Member Name</h3>
				<!-- /wp:heading -->
				<!-- wp:paragraph {"align":"center"} -->
				<p class="has-text-align-center">Position/Title</p>
				<!-- /wp:paragraph --></div>
				<!-- /wp:group -->',
			'categories'  => array( 'starter-flavor-sections' ),
			'keywords'    => array( 'team', 'member', 'person' ),
		)
	);

	// FAQ Section Pattern
	register_block_pattern(
		'starter-flavor/faq-section',
		array(
			'title'       => esc_html__( 'FAQ Section', 'starter-flavor' ),
			'description' => esc_html__( 'A frequently asked questions section', 'starter-flavor' ),
			'content'     => '<!-- wp:heading -->
				<h2 class="wp-block-heading">Frequently Asked Questions</h2>
				<!-- /wp:heading -->
				<!-- wp:details -->
				<details class="wp-block-details"><summary>What is your return policy?</summary>
				<p>We offer a 30-day money-back guarantee on all purchases.</p></details>
				<!-- /wp:details -->
				<!-- wp:details -->
				<details class="wp-block-details"><summary>How long does shipping take?</summary>
				<p>Standard shipping takes 3-5 business days to most locations.</p></details>
				<!-- /wp:details -->
				<!-- wp:details -->
				<details class="wp-block-details"><summary>Do you offer support?</summary>
				<p>Yes, our support team is available 24/7 to assist you.</p></details>
				<!-- /wp:details -->',
			'categories'  => array( 'starter-flavor-sections' ),
			'keywords'    => array( 'faq', 'questions', 'accordion' ),
		)
	);

	// Pricing Table Pattern
	register_block_pattern(
		'starter-flavor/pricing-table',
		array(
			'title'       => esc_html__( 'Pricing Table', 'starter-flavor' ),
			'description' => esc_html__( 'A pricing comparison table', 'starter-flavor' ),
			'content'     => '<!-- wp:columns {"columns":3} -->
				<div class="wp-block-columns has-3-columns"><!-- wp:column {"backgroundColor":"light"} -->
				<div class="wp-block-column has-light-background-color has-background"><!-- wp:heading {"textAlign":"center","level":3} -->
				<h3 class="wp-block-heading has-text-align-center">Basic</h3>
				<!-- /wp:heading -->
				<!-- wp:paragraph {"align":"center","fontSize":"large"} -->
				<p class="has-text-align-center has-large-font-size">$29</p>
				<!-- /wp:paragraph -->
				<!-- wp:list -->
				<ul><li>Feature One</li><li>Feature Two</li><li>Email Support</li></ul>
				<!-- /wp:list -->
				<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
				<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"primary"} -->
				<div class="wp-block-button"><a class="wp-block-button__link has-primary-background-color has-background">Choose Plan</a></div>
				<!-- /wp:button --></div>
				<!-- /wp:buttons --></div>
				<!-- /wp:column -->
				<!-- wp:column {"backgroundColor":"primary"} -->
				<div class="wp-block-column has-primary-background-color has-background"><!-- wp:heading {"textAlign":"center","level":3,"textColor":"white"} -->
				<h3 class="wp-block-heading has-text-align-center has-white-color has-text-color">Pro</h3>
				<!-- /wp:heading -->
				<!-- wp:paragraph {"align":"center","fontSize":"large","textColor":"white"} -->
				<p class="has-text-align-center has-large-font-size has-white-color has-text-color">$79</p>
				<!-- /wp:paragraph -->
				<!-- wp:list {"textColor":"white"} -->
				<ul class="has-white-color has-text-color"><li>All Basic Features</li><li>Feature Three</li><li>Priority Support</li></ul>
				<!-- /wp:list -->
				<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
				<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"white","textColor":"primary"} -->
				<div class="wp-block-button"><a class="wp-block-button__link has-white-background-color has-primary-color has-text-color has-background">Choose Plan</a></div>
				<!-- /wp:button --></div>
				<!-- /wp:buttons --></div>
				<!-- /wp:column -->
				<!-- wp:column {"backgroundColor":"light"} -->
				<div class="wp-block-column has-light-background-color has-background"><!-- wp:heading {"textAlign":"center","level":3} -->
				<h3 class="wp-block-heading has-text-align-center">Enterprise</h3>
				<!-- /wp:heading -->
				<!-- wp:paragraph {"align":"center","fontSize":"large"} -->
				<p class="has-text-align-center has-large-font-size">Custom</p>
				<!-- /wp:paragraph -->
				<!-- wp:list -->
				<ul><li>All Pro Features</li><li>Dedicated Manager</li><li>24/7 Phone Support</li></ul>
				<!-- /wp:list -->
				<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
				<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"primary"} -->
				<div class="wp-block-button"><a class="wp-block-button__link has-primary-background-color has-background">Contact Us</a></div>
				<!-- /wp:button --></div>
				<!-- /wp:buttons --></div>
				<!-- /wp:column --></div>
				<!-- /wp:columns -->',
			'categories'  => array( 'starter-flavor-sections' ),
			'keywords'    => array( 'pricing', 'table', 'comparison' ),
		)
	);
}
add_action( 'init', 'starter_flavor_register_block_patterns' );

/**
 * Register block pattern categories
 *
 * @since 1.0.0
 */
function starter_flavor_register_block_pattern_categories() {
	register_block_pattern_category( 'starter-flavor-hero', array(
		'label' => esc_html__( 'Starter Flavor - Hero', 'starter-flavor' ),
	) );

	register_block_pattern_category( 'starter-flavor-sections', array(
		'label' => esc_html__( 'Starter Flavor - Sections', 'starter-flavor' ),
	) );
}
add_action( 'init', 'starter_flavor_register_block_pattern_categories' );

/**
 * Enqueue block editor styles
 *
 * @since 1.0.0
 */
function starter_flavor_enqueue_block_editor_assets() {
	wp_enqueue_script(
		'starter-flavor-block-editor',
		STARTER_FLAVOR_THEME_URL . '/assets/js/editor-blocks.js',
		array( 'wp-blocks', 'wp-dom-ready', 'wp-edit-post' ),
		STARTER_FLAVOR_VERSION,
		true
	);
}
add_action( 'enqueue_block_editor_assets', 'starter_flavor_enqueue_block_editor_assets' );

/**
 * Add custom block styles
 *
 * @since 1.0.0
 */
function starter_flavor_register_block_styles() {
	// Button styles
	register_block_style(
		'core/button',
		array(
			'name'  => 'outline',
			'label' => esc_html__( 'Outline', 'starter-flavor' ),
		)
	);

	register_block_style(
		'core/button',
		array(
			'name'  => 'rounded',
			'label' => esc_html__( 'Rounded', 'starter-flavor' ),
		)
	);

	// Image styles
	register_block_style(
		'core/image',
		array(
			'name'  => 'border-shadow',
			'label' => esc_html__( 'Border Shadow', 'starter-flavor' ),
		)
	);

	register_block_style(
		'core/image',
		array(
			'name'  => 'rounded-corners',
			'label' => esc_html__( 'Rounded Corners', 'starter-flavor' ),
		)
	);

	// Column styles
	register_block_style(
		'core/columns',
		array(
			'name'  => 'equal-height',
			'label' => esc_html__( 'Equal Height', 'starter-flavor' ),
		)
	);
}
add_action( 'init', 'starter_flavor_register_block_styles' );

/**
 * Custom block templates for post types
 *
 * @since 1.0.0
 */
function starter_flavor_register_block_templates() {
	// Post template
	$post_template = array(
		array( 'core/heading', array(
			'level'       => 1,
			'placeholder' => esc_html__( 'Add post title...', 'starter-flavor' ),
		) ),
		array( 'core/paragraph', array(
			'placeholder' => esc_html__( 'Start writing your post...', 'starter-flavor' ),
		) ),
	);

	starter_flavor_register_post_type_template( 'post', $post_template );

	// Page template
	$page_template = array(
		array( 'core/heading', array(
			'level'       => 1,
			'placeholder' => esc_html__( 'Add page title...', 'starter-flavor' ),
		) ),
		array( 'core/paragraph', array(
			'placeholder' => esc_html__( 'Start adding content...', 'starter-flavor' ),
		) ),
	);

	starter_flavor_register_post_type_template( 'page', $page_template );
}
add_action( 'init', 'starter_flavor_register_block_templates' );

/**
 * Helper function to register post type templates
 *
 * @since 1.0.0
 * @param string $post_type Post type name.
 * @param array  $template Block template.
 */
function starter_flavor_register_post_type_template( $post_type, $template ) {
	if ( function_exists( 'register_block_template' ) ) {
		register_block_template( "wp_template//{$post_type}", array(
			'title'     => ucfirst( $post_type ),
			'template'  => $template,
		) );
	}
}
