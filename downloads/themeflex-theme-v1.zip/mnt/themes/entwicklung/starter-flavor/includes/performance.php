<?php
/**
 * Starter Flavor Theme - Performance Optimizations
 *
 * @package Starter_Flavor
 * @since 1.0.0
 * @description WordPress performance hooks and optimizations
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ==================================================
 * WORDPRESS FEATURE REMOVAL
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_remove_wp_features' ) ) {
	/**
	 * Remove unnecessary WordPress features for better performance.
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_remove_wp_features() {
		// Remove emoji scripts
		remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
		remove_action( 'wp_print_styles', 'print_emoji_styles' );
		remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
		remove_action( 'admin_print_styles', 'print_emoji_styles' );
		remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
		remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
		remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );

		// Remove oEmbed scripts
		remove_action( 'rest_api_init', 'wp_oembed_register_route' );
		remove_filter( 'oembed_dataparse', 'wp_filter_oembed_result', 10 );
		remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
		remove_action( 'wp_head', 'wp_oembed_add_host_js' );

		// Remove RSD (Really Simple Discovery) link
		remove_action( 'wp_head', 'rsd_link' );

		// Remove Windows Live Writer manifest link
		remove_action( 'wp_head', 'wlwmanifest_link' );

		// Remove REST API link
		remove_action( 'wp_head', 'rest_output_link_wp_head' );
		remove_action( 'wp_head', 'wp_shortlink_wp_head' );
	}

	add_action( 'init', 'starter_flavor_remove_wp_features' );
}

/**
 * ==================================================
 * DEFERRED & ASYNC SCRIPT LOADING
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_defer_async_scripts' ) ) {
	/**
	 * Add defer/async attributes to scripts.
	 *
	 * @since 1.0.0
	 * @param string $tag Script tag.
	 * @param string $handle Script handle.
	 * @return string Modified script tag.
	 */
	function starter_flavor_defer_async_scripts( $tag, $handle ) {
		// Scripts to defer
		$defer_scripts = array(
			'starter-flavor-custom',
			'starter-flavor-navigation',
			'starter-flavor-skip-link-focus-fix',
		);

		// Scripts to async
		$async_scripts = array(
			'jquery',
		);

		if ( in_array( $handle, $defer_scripts, true ) ) {
			return str_replace( ' src', ' defer src', $tag );
		}

		if ( in_array( $handle, $async_scripts, true ) ) {
			return str_replace( ' src', ' async src', $tag );
		}

		return $tag;
	}

	add_filter( 'script_loader_tag', 'starter_flavor_defer_async_scripts', 10, 2 );
}

/**
 * ==================================================
 * PRELOAD & DNS PREFETCH
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_preload_assets' ) ) {
	/**
	 * Add preload and DNS prefetch for critical assets.
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_preload_assets() {
		// Preload Google Fonts
		echo '<link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>' . "\n";
		echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";

		// Preload critical CSS inline
		echo '<link rel="preload" href="' . esc_url( STARTER_FLAVOR_THEME_URL . '/style.css' ) . '" as="style">' . "\n";

		// DNS Prefetch for common CDNs
		echo '<link rel="dns-prefetch" href="https://code.jquery.com">' . "\n";

		// Allow custom preloads via filter
		$preload_urls = apply_filters( 'starter_flavor_preload_urls', array() );
		foreach ( $preload_urls as $url => $as ) {
			echo '<link rel="preload" href="' . esc_url( $url ) . '" as="' . esc_attr( $as ) . '">' . "\n";
		}
	}

	add_action( 'wp_head', 'starter_flavor_preload_assets', 1 );
}

/**
 * ==================================================
 * IMAGE OPTIMIZATION
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_add_image_dimensions' ) ) {
	/**
	 * Add width and height attributes to images for better rendering.
	 *
	 * Prevents cumulative layout shift (CLS) by specifying image dimensions.
	 *
	 * @since 1.0.0
	 * @param string $html Image HTML.
	 * @param int    $id Attachment ID.
	 * @return string Modified image HTML.
	 */
	function starter_flavor_add_image_dimensions( $html, $id ) {
		// Don't modify if already has dimensions
		if ( preg_match( '/\swidth\s*=/', $html ) && preg_match( '/\sheight\s*=/', $html ) ) {
			return $html;
		}

		$attachment = get_post( $id );

		if ( ! $attachment ) {
			return $html;
		}

		$meta = wp_get_attachment_metadata( $id );

		if ( ! $meta || ! isset( $meta['width'], $meta['height'] ) ) {
			return $html;
		}

		// Add dimensions to img tag
		$html = preg_replace(
			'/<img\s/',
			'<img width="' . esc_attr( $meta['width'] ) . '" height="' . esc_attr( $meta['height'] ) . '" ',
			$html,
			1
		);

		return $html;
	}

	add_filter( 'wp_get_attachment_image', 'starter_flavor_add_image_dimensions', 10, 2 );
}

if ( ! function_exists( 'starter_flavor_lazy_load_images' ) ) {
	/**
	 * Add lazy loading attributes to images.
	 *
	 * Uses native lazy loading (loading="lazy") supported by modern browsers.
	 *
	 * @since 1.0.0
	 * @param string $html Image HTML.
	 * @param int    $id Attachment ID.
	 * @return string Modified image HTML.
	 */
	function starter_flavor_lazy_load_images( $html, $id ) {
		// Don't add lazy loading to header/logo images
		if ( preg_match( '/wp-image-\d+\s*(.*?)custom-logo/', $html ) ) {
			return $html;
		}

		// Add native lazy loading
		if ( ! preg_match( '/loading\s*=/', $html ) ) {
			$html = str_replace( '<img ', '<img loading="lazy" ', $html );
		}

		return $html;
	}

	add_filter( 'wp_get_attachment_image', 'starter_flavor_lazy_load_images', 15, 2 );
}

if ( ! function_exists( 'starter_flavor_webp_support' ) ) {
	/**
	 * Detect and output WebP support information.
	 *
	 * Allows JavaScript to detect WebP support for conditional serving.
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_webp_support() {
		$webp_support = 'false';

		// Check if WebP is supported by the server
		if ( function_exists( 'wp_get_image_editor' ) ) {
			$editor = wp_get_image_editor( null, array() );

			if ( ! is_wp_error( $editor ) && method_exists( $editor, 'supports_mime_type' ) ) {
				if ( $editor->supports_mime_type( 'image/webp' ) ) {
					$webp_support = 'true';
				}
			}
		}

		echo '<script type="text/javascript">window.starterFlavorWebPSupport = ' . esc_html( $webp_support ) . ';</script>' . "\n";
	}

	add_action( 'wp_head', 'starter_flavor_webp_support', 99 );
}

/**
 * ==================================================
 * CRITICAL CSS INLINING
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_inline_critical_css' ) ) {
	/**
	 * Inline critical CSS to improve First Contentful Paint (FCP).
	 *
	 * Loads and inlines essential above-the-fold styles from critical-inline.css
	 * to reduce render-blocking resources and improve page performance.
	 *
	 * This function:
	 * 1. Reads critical-inline.css (minimal ~5KB above-the-fold styles)
	 * 2. Outputs CSS inline in <head> to eliminate render-blocking
	 * 3. Defers non-critical stylesheets with media="print" onload
	 * 4. Improves First Contentful Paint and overall page speed
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_inline_critical_css() {
		// Load critical CSS file
		$critical_css_file = STARTER_FLAVOR_THEME_DIR . '/assets/css/critical-inline.css';

		if ( ! file_exists( $critical_css_file ) ) {
			return;
		}

		// Read and output critical CSS
		$critical_css = file_get_contents( $critical_css_file ); // phpcs:ignore

		if ( ! empty( $critical_css ) ) {
			echo '<style id="sf-critical-css">';
			// phpcs:ignore
			echo $critical_css;
			echo '</style>' . "\n";
		}
	}

	add_action( 'wp_head', 'starter_flavor_inline_critical_css', 0 );
}

if ( ! function_exists( 'sf_inline_critical_css' ) ) {
	/**
	 * Helper function to inline critical CSS from assets/css/critical-inline.css
	 *
	 * This is an alias for starter_flavor_inline_critical_css() for convenience.
	 * Reads critical-inline.css and outputs it inline in <head> via wp_head hook.
	 *
	 * The critical CSS includes:
	 * - CSS reset basics (html, body resets)
	 * - Body/html base styles (font-family, color, margin/padding)
	 * - Header layout and navigation (above the fold)
	 * - Hero section basics (heading, text, image sizing)
	 * - Font loading with font-display: swap
	 * - content-visibility: auto for below-fold sections
	 * - Responsive design rules for mobile
	 *
	 * Non-critical stylesheets should be deferred with:
	 * <link rel="stylesheet" href="style.css" media="print" onload="this.media='all'">
	 *
	 * This improves FCP by ~1-2 seconds on slower connections.
	 *
	 * @since 1.0.0
	 */
	function sf_inline_critical_css() {
		starter_flavor_inline_critical_css();
	}
}

/**
 * ==================================================
 * SCRIPT INJECTION PREVENTION
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_remove_block_library_css' ) ) {
	/**
	 * Remove unnecessary Gutenberg block library CSS on non-block pages.
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_remove_block_library_css() {
		if ( ! is_admin() && ! has_block( null ) ) {
			wp_dequeue_style( 'wp-block-library' );
			wp_dequeue_style( 'wp-block-library-theme' );
		}
	}

	add_action( 'wp_enqueue_scripts', 'starter_flavor_remove_block_library_css', 100 );
}

/**
 * ==================================================
 * CONTENT SECURITY POLICY
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_content_security_policy' ) ) {
	/**
	 * Send basic Content Security Policy header.
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_content_security_policy() {
		// Only send on frontend, not in admin
		if ( is_admin() ) {
			return;
		}

		// Allow custom CSP via filter
		$csp_enabled = apply_filters( 'starter_flavor_enable_csp', false );

		if ( ! $csp_enabled || headers_sent() ) {
			return;
		}

		$csp = "default-src 'self'; "
			. "script-src 'self' 'unsafe-inline' *.google-analytics.com *.gstatic.com; "
			. "style-src 'self' 'unsafe-inline' fonts.googleapis.com; "
			. "font-src 'self' fonts.gstatic.com; "
			. "img-src 'self' data: *.google-analytics.com; "
			. "connect-src 'self' *.google-analytics.com;";

		header( 'Content-Security-Policy: ' . esc_attr( $csp ), true );
	}

	add_action( 'send_headers', 'starter_flavor_content_security_policy' );
}

/**
 * ==================================================
 * CACHE HEADERS
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_set_cache_headers' ) ) {
	/**
	 * Set cache headers for static assets.
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_set_cache_headers() {
		// Cache static assets for 30 days
		if ( preg_match( '/\.(jpg|jpeg|png|gif|ico|css|js|woff|woff2|ttf|svg|eot)$/i', $_SERVER['REQUEST_URI'] ?? '' ) ) {
			header( 'Cache-Control: public, max-age=2592000, immutable' );
		}
	}

	// Only on frontend
	if ( ! is_admin() ) {
		add_action( 'send_headers', 'starter_flavor_set_cache_headers' );
	}
}

/**
 * ==================================================
 * OPTIMIZATION HELPERS
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_get_performance_metrics' ) ) {
	/**
	 * Get basic performance metrics data.
	 *
	 * @since 1.0.0
	 * @return array Performance metrics.
	 */
	function starter_flavor_get_performance_metrics() {
		return array(
			'webp_support'     => function_exists( 'wp_get_image_editor' ),
			'lazy_load'        => true,
			'critical_css'     => apply_filters( 'starter_flavor_inline_critical_css', false ),
			'deferred_scripts'  => true,
			'csp_enabled'       => apply_filters( 'starter_flavor_enable_csp', false ),
		);
	}
}

if ( ! function_exists( 'starter_flavor_enqueue_performance_js' ) ) {
	/**
	 * Enqueue performance utilities JavaScript.
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_enqueue_performance_js() {
		wp_enqueue_script(
			'starter-flavor-performance',
			STARTER_FLAVOR_THEME_URL . '/assets/js/performance.js',
			array(),
			STARTER_FLAVOR_VERSION,
			true
		);
	}

	add_action( 'wp_enqueue_scripts', 'starter_flavor_enqueue_performance_js' );
}
