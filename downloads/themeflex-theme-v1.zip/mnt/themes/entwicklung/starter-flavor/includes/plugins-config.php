<?php
/**
 * Starter Flavor Plugin Recommendations Configuration
 *
 * @package Starter_Flavor
 * @subpackage Includes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Register plugin recommendations
 *
 * Uses TGM Plugin Activation if available, otherwise shows admin notices
 *
 * @return void
 */
function starter_flavor_register_required_plugins() {
	$plugins = array(
		array(
			'name'      => esc_html__( 'Elementor', 'starter-flavor' ),
			'slug'      => 'elementor',
			'required'  => false,
			'version'   => '3.0.0',
			'force_activation' => false,
			'force_deactivation' => false,
		),
		array(
			'name'      => esc_html__( 'Contact Form 7', 'starter-flavor' ),
			'slug'      => 'contact-form-7',
			'required'  => false,
			'version'   => '5.0',
			'force_activation' => false,
			'force_deactivation' => false,
		),
		array(
			'name'      => esc_html__( 'WooCommerce', 'starter-flavor' ),
			'slug'      => 'woocommerce',
			'required'  => false,
			'version'   => '5.0',
			'force_activation' => false,
			'force_deactivation' => false,
		),
	);

	// Check if Starter Flavor Addons plugin exists and add it to recommendations.
	if ( ! class_exists( 'Starter_Flavor_Addons' ) ) {
		$plugins[] = array(
			'name'      => esc_html__( 'Starter Flavor Addons', 'starter-flavor' ),
			'slug'      => 'starter-flavor-addons',
			'required'  => false,
			'version'   => '1.0.0',
			'force_activation' => false,
			'force_deactivation' => false,
		);
	}

	// Check if TGM Plugin Activation is available.
	if ( class_exists( 'TGM_Plugin_Activation' ) ) {
		// TGM Plugin Activation is available, register plugins with it.
		$config = array(
			'id'           => 'starter-flavor-tgmpa',
			'parent_slug'  => 'themes.php',
			'capability'   => 'edit_theme_options',
			'menu'         => 'tgmpa-install-plugins',
			'messages'     => array(
				'notice_can_install_recommended' => _n_noop(
					'The following plugin is recommended: %1$s.',
					'The following plugins are recommended: %1$s.',
					'starter-flavor'
				),
			),
		);

		tgmpa( $plugins, $config );
	} else {
		// TGM Plugin Activation not available, use admin notices.
		starter_flavor_show_plugin_recommendations( $plugins );
	}
}
add_action( 'tgmpa_register', 'starter_flavor_register_required_plugins' );

/**
 * Display plugin recommendation admin notices
 *
 * @param array $plugins Array of plugins to recommend.
 * @return void
 */
function starter_flavor_show_plugin_recommendations( $plugins ) {
	// Check if we should display the notice.
	if ( ! current_user_can( 'install_plugins' ) ) {
		return;
	}

	// Get already installed plugins.
	$installed_plugins = get_plugins();
	$missing_plugins   = array();

	foreach ( $plugins as $plugin ) {
		$plugin_path = $plugin['slug'] . '/' . $plugin['slug'] . '.php';

		if ( ! isset( $installed_plugins[ $plugin_path ] ) ) {
			$missing_plugins[] = $plugin;
		}
	}

	if ( empty( $missing_plugins ) ) {
		return;
	}

	// Display admin notice.
	add_action( 'admin_notices', function() use ( $missing_plugins ) {
		starter_flavor_render_plugin_notice( $missing_plugins );
	} );
}

/**
 * Render plugin recommendation notice
 *
 * @param array $plugins Array of missing plugins.
 * @return void
 */
function starter_flavor_render_plugin_notice( $plugins ) {
	$notice_id = 'starter-flavor-plugin-recommendations';

	// Check if user has dismissed this notice.
	$user_id = get_current_user_id();
	if ( get_user_meta( $user_id, $notice_id . '_dismissed', true ) ) {
		return;
	}

	$plugin_names = array();

	foreach ( $plugins as $plugin ) {
		$plugin_names[] = '<strong>' . esc_html( $plugin['name'] ) . '</strong>';
	}

	$plugin_list = implode( ', ', $plugin_names );

	?>
	<div class="notice notice-info is-dismissible" data-notice-id="<?php echo esc_attr( $notice_id ); ?>">
		<p>
			<?php
			printf(
				esc_html__( 'The following plugins are recommended for Starter Flavor: %s.', 'starter-flavor' ),
				wp_kses_post( $plugin_list )
			);
			?>
		</p>
		<p>
			<?php
			foreach ( $plugins as $plugin ) {
				$plugin_path = $plugin['slug'] . '/' . $plugin['slug'] . '.php';
				$nonce       = wp_create_nonce( 'starter-flavor-plugin-install-' . $plugin['slug'] );
				$install_url = wp_nonce_url(
					add_query_arg(
						array(
							'action' => 'install-plugin',
							'plugin' => $plugin['slug'],
						),
						admin_url( 'update.php' )
					),
					'install-plugin_' . $plugin['slug']
				);

				printf(
					'<a href="%s" class="button button-primary">%s</a> ',
					esc_url( $install_url ),
					esc_html( sprintf( esc_html__( 'Install %s', 'starter-flavor' ), $plugin['name'] ) )
				);
			}
			?>
		</p>
	</div>
	<?php
}

/**
 * Handle AJAX dismissal of plugin notice
 *
 * @return void
 */
function starter_flavor_dismiss_plugin_notice() {
	if ( ! isset( $_POST['notice_id'] ) || ! wp_verify_nonce( $_POST['nonce'] ?? '', 'starter-flavor-dismiss-notice' ) ) {
		wp_send_json_error( esc_html__( 'Security check failed', 'starter-flavor' ) );
	}

	$notice_id = sanitize_text_field( $_POST['notice_id'] );
	$user_id   = get_current_user_id();

	if ( $user_id > 0 ) {
		update_user_meta( $user_id, $notice_id . '_dismissed', true );
		wp_send_json_success();
	}

	wp_send_json_error( esc_html__( 'User not logged in', 'starter-flavor' ) );
}
add_action( 'wp_ajax_starter_flavor_dismiss_notice', 'starter_flavor_dismiss_plugin_notice' );

/**
 * Enqueue scripts for notice dismissal
 *
 * @return void
 */
function starter_flavor_enqueue_notice_scripts() {
	if ( ! is_admin() ) {
		return;
	}

	wp_enqueue_script(
		'starter-flavor-notice',
		get_template_directory_uri() . '/assets/js/notice.js',
		array( 'jquery' ),
		'1.0.0',
		true
	);

	wp_localize_script(
		'starter-flavor-notice',
		'starterFlavorNotice',
		array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'starter-flavor-dismiss-notice' ),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'starter_flavor_enqueue_notice_scripts' );

/**
 * Check if a plugin is active
 *
 * @param string $plugin_slug The plugin slug.
 * @return bool True if plugin is active.
 */
function starter_flavor_is_plugin_active( $plugin_slug ) {
	$installed_plugins = get_plugins();
	$plugin_path       = $plugin_slug . '/' . $plugin_slug . '.php';

	return isset( $installed_plugins[ $plugin_path ] ) && is_plugin_active( $plugin_path );
}

/**
 * Check if Elementor is active
 *
 * @return bool True if Elementor is active.
 */
function starter_flavor_has_elementor() {
	return starter_flavor_is_plugin_active( 'elementor' );
}

/**
 * Check if WooCommerce is active
 *
 * @return bool True if WooCommerce is active.
 */
function starter_flavor_has_woocommerce() {
	return starter_flavor_is_plugin_active( 'woocommerce' );
}

/**
 * Check if Contact Form 7 is active
 *
 * @return bool True if Contact Form 7 is active.
 */
function starter_flavor_has_contact_form_7() {
	return starter_flavor_is_plugin_active( 'contact-form-7' );
}

/**
 * Display plugin status in theme information
 *
 * @return void
 */
function starter_flavor_display_plugin_status() {
	if ( ! is_admin() || ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}

	$plugins = array(
		'elementor'       => esc_html__( 'Elementor', 'starter-flavor' ),
		'contact-form-7'  => esc_html__( 'Contact Form 7', 'starter-flavor' ),
		'woocommerce'     => esc_html__( 'WooCommerce', 'starter-flavor' ),
	);

	echo '<div class="starter-flavor-plugin-status">';
	echo '<h3>' . esc_html__( 'Plugin Status', 'starter-flavor' ) . '</h3>';
	echo '<ul>';

	foreach ( $plugins as $slug => $name ) {
		$is_active = starter_flavor_is_plugin_active( $slug );
		$status    = $is_active ? '<span style="color: green;">✓ ' . esc_html__( 'Active', 'starter-flavor' ) . '</span>' : '<span style="color: red;">✗ ' . esc_html__( 'Inactive', 'starter-flavor' ) . '</span>';

		printf(
			'<li>%s: %s</li>',
			esc_html( $name ),
			wp_kses_post( $status )
		);
	}

	echo '</ul>';
	echo '</div>';
}
