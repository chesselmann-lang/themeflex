<?php
/**
 * The Events Calendar Plugin Integration
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add Events Calendar support
 *
 * @since 1.0.0
 */
function starter_flavor_events_calendar_setup() {
	if ( ! defined( 'TRIBE_EVENTS_CALENDAR_VERSION' ) ) {
		return;
	}

	// Enqueue Events Calendar styles
	add_action( 'wp_enqueue_scripts', 'starter_flavor_events_enqueue_styles' );
}
add_action( 'plugins_loaded', 'starter_flavor_events_calendar_setup' );

/**
 * Enqueue Events Calendar theme styles
 *
 * @since 1.0.0
 */
function starter_flavor_events_enqueue_styles() {
	if ( ! defined( 'TRIBE_EVENTS_CALENDAR_VERSION' ) ) {
		return;
	}

	// Check if we're on events pages
	if ( ! is_singular( 'tribe_events' ) && ! tribe_is_events_archive() ) {
		return;
	}

	wp_enqueue_style(
		'starter-flavor-events-calendar',
		STARTER_FLAVOR_THEME_URL . '/assets/css/events-calendar.css',
		array(),
		STARTER_FLAVOR_VERSION
	);
}

/**
 * Register events sidebar
 *
 * @since 1.0.0
 */
function starter_flavor_register_events_sidebar() {
	register_sidebar( array(
		'name'          => esc_html__( 'Events Sidebar', 'starter-flavor' ),
		'id'            => 'events-sidebar',
		'description'   => esc_html__( 'Sidebar for events pages', 'starter-flavor' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'starter_flavor_register_events_sidebar' );

/**
 * Display events sidebar
 *
 * @since 1.0.0
 */
function starter_flavor_events_sidebar() {
	if ( ! is_singular( 'tribe_events' ) && ! tribe_is_events_archive() ) {
		return;
	}

	if ( is_active_sidebar( 'events-sidebar' ) ) {
		echo '<aside class="events-sidebar">';
		dynamic_sidebar( 'events-sidebar' );
		echo '</aside>';
	}
}

/**
 * Add body class for events pages
 *
 * @since 1.0.0
 * @param array $classes Body classes.
 * @return array
 */
function starter_flavor_events_body_classes( $classes ) {
	if ( ! defined( 'TRIBE_EVENTS_CALENDAR_VERSION' ) ) {
		return $classes;
	}

	if ( is_singular( 'tribe_events' ) ) {
		$classes[] = 'events-single-page';
	} elseif ( tribe_is_events_archive() ) {
		$classes[] = 'events-archive-page';
	} elseif ( tribe_is_month() ) {
		$classes[] = 'events-month-view';
	} elseif ( tribe_is_list_view() ) {
		$classes[] = 'events-list-view';
	}

	return $classes;
}
add_filter( 'body_class', 'starter_flavor_events_body_classes' );

/**
 * Customize event list grid layout
 *
 * @since 1.0.0
 * @param string $html The grid HTML.
 * @return string
 */
function starter_flavor_events_grid_layout( $html ) {
	$columns = starter_flavor_get_theme_option( 'events_columns', 3 );

	// Add custom class to events container
	$html = str_replace(
		'class="',
		'class="starter-flavor-events-grid columns-' . esc_attr( $columns ) . ' ',
		$html
	);

	return $html;
}
add_filter( 'tribe_events_list_event_class', 'starter_flavor_events_grid_layout' );

/**
 * Customize event card styling
 *
 * @since 1.0.0
 */
function starter_flavor_event_card_wrapper_start() {
	echo '<div class="starter-flavor-event-card">';
}
add_action( 'tribe_events_single_event_before_meta', 'starter_flavor_event_card_wrapper_start' );

/**
 * Close event card wrapper
 *
 * @since 1.0.0
 */
function starter_flavor_event_card_wrapper_end() {
	echo '</div>';
}
add_action( 'tribe_events_single_event_after_meta', 'starter_flavor_event_card_wrapper_end' );

/**
 * Customize event date format
 *
 * @since 1.0.0
 * @param string $date The date string.
 * @param object $event The event object.
 * @return string
 */
function starter_flavor_event_date_format( $date, $event ) {
	$format = starter_flavor_get_theme_option( 'events_date_format', 'l, F j, Y' );
	return $event->post_date ? date_i18n( $format, strtotime( $event->post_date ) ) : $date;
}
add_filter( 'tribe_events_event_schedule_details', 'starter_flavor_event_date_format', 10, 2 );

/**
 * Customize events per page
 *
 * @since 1.0.0
 * @param int $count Events per page.
 * @return int
 */
function starter_flavor_events_per_page( $count ) {
	return starter_flavor_get_theme_option( 'events_per_page', 12 );
}
add_filter( 'tribe_events_list_events_per_page', 'starter_flavor_events_per_page' );

/**
 * Add event categories filter
 *
 * @since 1.0.0
 */
function starter_flavor_events_category_filter() {
	if ( ! ( is_singular( 'tribe_events' ) || tribe_is_events_archive() ) ) {
		return;
	}

	if ( ! starter_flavor_get_theme_option( 'events_show_category_filter', true ) ) {
		return;
	}

	$categories = get_terms( 'tribe_events_cat', array( 'hide_empty' => true ) );

	if ( empty( $categories ) || is_wp_error( $categories ) ) {
		return;
	}

	echo '<div class="events-category-filter">';
	echo '<h3>' . esc_html__( 'Event Categories', 'starter-flavor' ) . '</h3>';
	echo '<ul>';

	foreach ( $categories as $category ) {
		echo '<li><a href="' . esc_url( get_term_link( $category ) ) . '">' . esc_html( $category->name ) . '</a></li>';
	}

	echo '</ul>';
	echo '</div>';
}
add_action( 'wp_footer', 'starter_flavor_events_category_filter' );

/**
 * Customize event RSVP button
 *
 * @since 1.0.0
 * @param string $button The button HTML.
 * @param int    $event_id The event post ID.
 * @return string
 */
function starter_flavor_custom_event_rsvp_button( $button, $event_id ) {
	// Add custom class to RSVP button
	$button = str_replace(
		'class="',
		'class="starter-flavor-rsvp-btn ',
		$button
	);

	return $button;
}
add_filter( 'tribe_events_single_event_rsvp_button_html', 'starter_flavor_custom_event_rsvp_button', 10, 2 );

/**
 * Add featured image to events
 *
 * @since 1.0.0
 */
function starter_flavor_event_featured_image() {
	if ( ! is_singular( 'tribe_events' ) ) {
		return;
	}

	if ( has_post_thumbnail() ) {
		echo '<div class="event-featured-image">';
		the_post_thumbnail( 'large', array( 'class' => 'event-image' ) );
		echo '</div>';
	}
}
add_action( 'tribe_events_single_event_before_the_meta', 'starter_flavor_event_featured_image' );

/**
 * Customize event venue details
 *
 * @since 1.0.0
 * @param string $venue_html The venue HTML.
 * @return string
 */
function starter_flavor_event_venue_details( $venue_html ) {
	// Add custom styling to venue details
	$venue_html = str_replace(
		'class="',
		'class="starter-flavor-event-venue ',
		$venue_html
	);

	return $venue_html;
}
add_filter( 'tribe_events_venue_details', 'starter_flavor_event_venue_details' );
