<?php
/**
 * MetForm Plugin Integration
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add MetForm support
 *
 * @since 1.0.0
 */
function starter_flavor_metform_setup() {
	if ( ! function_exists( 'metform' ) ) {
		return;
	}

	// Enqueue MetForm styles
	add_action( 'wp_enqueue_scripts', 'starter_flavor_metform_enqueue_styles' );
}
add_action( 'plugins_loaded', 'starter_flavor_metform_setup' );

/**
 * Enqueue MetForm theme styles
 *
 * @since 1.0.0
 */
function starter_flavor_metform_enqueue_styles() {
	if ( ! function_exists( 'metform' ) ) {
		return;
	}

	wp_enqueue_style(
		'starter-flavor-metform',
		STARTER_FLAVOR_THEME_URL . '/assets/css/metform.css',
		array(),
		STARTER_FLAVOR_VERSION
	);
}

/**
 * Customize MetForm form styling
 *
 * @since 1.0.0
 * @param array $form_args Form arguments.
 * @return array
 */
function starter_flavor_metform_form_args( $form_args ) {
	if ( ! is_array( $form_args ) ) {
		return $form_args;
	}

	// Add theme-specific form classes
	$form_args['form_class'] = isset( $form_args['form_class'] )
		? $form_args['form_class'] . ' starter-flavor-form'
		: 'starter-flavor-form';

	return $form_args;
}
add_filter( 'metform_form_args', 'starter_flavor_metform_form_args' );

/**
 * Customize MetForm input field styling
 *
 * @since 1.0.0
 * @param string $html The field HTML.
 * @param array  $field The field data.
 * @return string
 */
function starter_flavor_metform_field_html( $html, $field ) {
	if ( ! is_array( $field ) ) {
		return $html;
	}

	// Add custom classes to inputs
	$html = str_replace(
		'class="mf-input',
		'class="mf-input starter-flavor-input',
		$html
	);

	return $html;
}
add_filter( 'metform_form_field_html', 'starter_flavor_metform_field_html', 10, 2 );

/**
 * Customize MetForm button styling
 *
 * @since 1.0.0
 * @param string $html The button HTML.
 * @return string
 */
function starter_flavor_metform_submit_button( $html ) {
	// Add custom classes to submit button
	$html = str_replace(
		'class="mf-button',
		'class="mf-button starter-flavor-submit-btn',
		$html
	);

	return $html;
}
add_filter( 'metform_form_submit_button', 'starter_flavor_metform_submit_button' );

/**
 * Customize MetForm validation messages
 *
 * @since 1.0.0
 * @param string $message The validation message.
 * @param string $field_name The field name.
 * @return string
 */
function starter_flavor_metform_validation_message( $message, $field_name ) {
	// Add custom error styling
	return '<span class="starter-flavor-error-message">' . esc_html( $message ) . '</span>';
}
add_filter( 'metform_field_validation_message', 'starter_flavor_metform_validation_message', 10, 2 );

/**
 * Add form grid layout support
 *
 * @since 1.0.0
 * @param string $html The form HTML.
 * @param int    $form_id The form ID.
 * @return string
 */
function starter_flavor_metform_form_wrapper( $html, $form_id ) {
	$form_layout = starter_flavor_get_theme_option( 'metform_form_layout', 'default' );

	// Add layout class
	$html = str_replace(
		'class="metform-container',
		'class="metform-container layout-' . esc_attr( $form_layout ) . ' ',
		$html
	);

	return $html;
}
add_filter( 'metform_form_wrapper', 'starter_flavor_metform_form_wrapper', 10, 2 );

/**
 * Customize form success message
 *
 * @since 1.0.0
 * @param string $message The success message.
 * @param int    $form_id The form ID.
 * @return string
 */
function starter_flavor_metform_success_message( $message, $form_id ) {
	return '<div class="metform-success-message starter-flavor-success">' . wp_kses_post( $message ) . '</div>';
}
add_filter( 'metform_response_success_message', 'starter_flavor_metform_success_message', 10, 2 );

/**
 * Customize form error message
 *
 * @since 1.0.0
 * @param string $message The error message.
 * @param int    $form_id The form ID.
 * @return string
 */
function starter_flavor_metform_error_message( $message, $form_id ) {
	return '<div class="metform-error-message starter-flavor-error">' . wp_kses_post( $message ) . '</div>';
}
add_filter( 'metform_response_error_message', 'starter_flavor_metform_error_message', 10, 2 );

/**
 * Add form customizer settings
 *
 * @since 1.0.0
 * @param WP_Customize_Manager $wp_customize The customizer object.
 */
function starter_flavor_metform_customizer_settings( $wp_customize ) {
	if ( ! function_exists( 'metform' ) ) {
		return;
	}

	// Add MetForm panel
	$wp_customize->add_panel(
		'starter_flavor_metform',
		array(
			'title'       => esc_html__( 'MetForm Settings', 'starter-flavor' ),
			'description' => esc_html__( 'Customize form appearance', 'starter-flavor' ),
			'priority'    => 55,
		)
	);

	// Form layout
	$wp_customize->add_setting(
		'starter_flavor_metform_form_layout',
		array(
			'default'           => 'default',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

	$wp_customize->add_control(
		'starter_flavor_metform_form_layout',
		array(
			'label'    => esc_html__( 'Form Layout', 'starter-flavor' ),
			'section'  => 'starter_flavor_metform',
			'type'     => 'select',
			'panel'    => 'starter_flavor_metform',
			'choices'  => array(
				'default'   => esc_html__( 'Default', 'starter-flavor' ),
				'two-column' => esc_html__( 'Two Column', 'starter-flavor' ),
				'three-column' => esc_html__( 'Three Column', 'starter-flavor' ),
			),
		)
	);

	// Input border style
	$wp_customize->add_setting(
		'starter_flavor_metform_input_border',
		array(
			'default'           => 'solid',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

	$wp_customize->add_control(
		'starter_flavor_metform_input_border',
		array(
			'label'    => esc_html__( 'Input Border Style', 'starter-flavor' ),
			'section'  => 'starter_flavor_metform',
			'type'     => 'select',
			'panel'    => 'starter_flavor_metform',
			'choices'  => array(
				'none'   => esc_html__( 'None', 'starter-flavor' ),
				'solid'  => esc_html__( 'Solid', 'starter-flavor' ),
				'dashed' => esc_html__( 'Dashed', 'starter-flavor' ),
			),
		)
	);

	// Input background color
	$wp_customize->add_setting(
		'starter_flavor_metform_input_bg_color',
		array(
			'default'           => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'starter_flavor_metform_input_bg_color',
			array(
				'label'    => esc_html__( 'Input Background Color', 'starter-flavor' ),
				'section'  => 'starter_flavor_metform',
				'panel'    => 'starter_flavor_metform',
			)
		)
	);

	// Button style
	$wp_customize->add_setting(
		'starter_flavor_metform_button_style',
		array(
			'default'           => 'solid',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

	$wp_customize->add_control(
		'starter_flavor_metform_button_style',
		array(
			'label'    => esc_html__( 'Button Style', 'starter-flavor' ),
			'section'  => 'starter_flavor_metform',
			'type'     => 'select',
			'panel'    => 'starter_flavor_metform',
			'choices'  => array(
				'solid'   => esc_html__( 'Solid', 'starter-flavor' ),
				'outline' => esc_html__( 'Outline', 'starter-flavor' ),
				'ghost'   => esc_html__( 'Ghost', 'starter-flavor' ),
			),
		)
	);

	// Button border radius
	$wp_customize->add_setting(
		'starter_flavor_metform_button_radius',
		array(
			'default'           => '4',
			'sanitize_callback' => 'absint',
		)
	);

	$wp_customize->add_control(
		'starter_flavor_metform_button_radius',
		array(
			'label'    => esc_html__( 'Button Border Radius (px)', 'starter-flavor' ),
			'section'  => 'starter_flavor_metform',
			'type'     => 'number',
			'panel'    => 'starter_flavor_metform',
			'input_attrs' => array(
				'min' => 0,
				'max' => 50,
			),
		)
	);
}
add_action( 'customize_register', 'starter_flavor_metform_customizer_settings' );

/**
 * Output dynamic form styles based on customizer settings
 *
 * @since 1.0.0
 */
function starter_flavor_metform_dynamic_styles() {
	if ( ! function_exists( 'metform' ) ) {
		return;
	}

	$input_bg = starter_flavor_get_theme_option( 'metform_input_bg_color', '#ffffff' );
	$button_radius = starter_flavor_get_theme_option( 'metform_button_radius', 4 );
	$button_style = starter_flavor_get_theme_option( 'metform_button_style', 'solid' );

	$css = '';

	// Input styles
	if ( $input_bg ) {
		$css .= '.starter-flavor-input { background-color: ' . sanitize_hex_color( $input_bg ) . '; }';
	}

	// Button radius
	$css .= '.starter-flavor-submit-btn { border-radius: ' . absint( $button_radius ) . 'px; }';

	// Button style
	if ( 'outline' === $button_style ) {
		$css .= '.starter-flavor-submit-btn { background: transparent; border: 2px solid var(--color-primary, #FF5E2E); }';
	} elseif ( 'ghost' === $button_style ) {
		$css .= '.starter-flavor-submit-btn { background: transparent; border: none; }';
	}

	if ( ! empty( $css ) ) {
		wp_add_inline_style( 'starter-flavor-metform', $css );
	}
}
add_action( 'wp_enqueue_scripts', 'starter_flavor_metform_dynamic_styles' );
