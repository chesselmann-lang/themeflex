<?php
/**
 * WPML Plugin Integration
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add WPML support
 *
 * @since 1.0.0
 */
function starter_flavor_wpml_setup() {
	if ( ! defined( 'ICL_SITEPRESS_VERSION' ) ) {
		return;
	}

	// Add WPML language switcher to header
	add_action( 'wp_footer', 'starter_flavor_wpml_language_switcher' );

	// Support for RTL languages
	add_action( 'after_setup_theme', 'starter_flavor_wpml_rtl_support' );
}
add_action( 'plugins_loaded', 'starter_flavor_wpml_setup' );

/**
 * Display WPML language switcher
 *
 * @since 1.0.0
 */
function starter_flavor_wpml_language_switcher() {
	if ( ! defined( 'ICL_SITEPRESS_VERSION' ) ) {
		return;
	}

	if ( ! starter_flavor_get_theme_option( 'wpml_show_language_switcher', true ) ) {
		return;
	}

	$languages = icl_get_languages( 'skip_missing=N&orderby=code' );

	if ( empty( $languages ) ) {
		return;
	}

	echo '<div class="wpml-language-switcher">';
	echo '<span class="language-label">' . esc_html__( 'Languages', 'starter-flavor' ) . ':</span>';
	echo '<ul class="language-list">';

	foreach ( $languages as $code => $lang ) {
		$active_class = $lang['active'] ? ' active' : '';
		$flag = $lang['country_flag_url'] ? $lang['country_flag_url'] : '';

		echo '<li class="language-item' . esc_attr( $active_class ) . '">';

		if ( $lang['active'] ) {
			echo '<span class="language-name">';
			if ( $flag ) {
				echo '<img src="' . esc_url( $flag ) . '" alt="' . esc_attr( $lang['language_code'] ) . '" class="language-flag"> ';
			}
			echo esc_html( $lang['native_name'] );
			echo '</span>';
		} else {
			echo '<a href="' . esc_url( $lang['url'] ) . '" class="language-link">';
			if ( $flag ) {
				echo '<img src="' . esc_url( $flag ) . '" alt="' . esc_attr( $lang['language_code'] ) . '" class="language-flag"> ';
			}
			echo esc_html( $lang['native_name'] );
			echo '</a>';
		}

		echo '</li>';
	}

	echo '</ul>';
	echo '</div>';
}

/**
 * Add RTL support for WPML
 *
 * @since 1.0.0
 */
function starter_flavor_wpml_rtl_support() {
	if ( ! defined( 'ICL_SITEPRESS_VERSION' ) ) {
		return;
	}

	// Check if current language is RTL
	if ( function_exists( 'icl_get_languages' ) ) {
		global $sitepress;

		if ( $sitepress ) {
			$current_lang = $sitepress->get_current_language();
			$lang_info    = $sitepress->get_language_details( $current_lang );

			if ( isset( $lang_info['rtl'] ) && $lang_info['rtl'] ) {
				// Add RTL body class
				add_filter( 'body_class', 'starter_flavor_add_rtl_class' );

				// Enqueue RTL stylesheet
				add_action( 'wp_enqueue_scripts', 'starter_flavor_enqueue_rtl_styles' );
			}
		}
	}
}

/**
 * Add RTL body class
 *
 * @since 1.0.0
 * @param array $classes Body classes.
 * @return array
 */
function starter_flavor_add_rtl_class( $classes ) {
	$classes[] = 'rtl-mode';
	return $classes;
}

/**
 * Enqueue RTL styles
 *
 * @since 1.0.0
 */
function starter_flavor_enqueue_rtl_styles() {
	wp_enqueue_style(
		'starter-flavor-rtl',
		STARTER_FLAVOR_THEME_URL . '/assets/css/rtl.css',
		array(),
		STARTER_FLAVOR_VERSION
	);
}

/**
 * Translate theme options
 *
 * @since 1.0.0
 * @param string $option_name The option name.
 * @param mixed  $default The default value.
 * @return mixed The option value
 */
function starter_flavor_wpml_get_translated_option( $option_name, $default = false ) {
	if ( ! defined( 'ICL_SITEPRESS_VERSION' ) ) {
		return get_option( $option_name, $default );
	}

	global $sitepress;

	if ( ! $sitepress ) {
		return get_option( $option_name, $default );
	}

	$current_lang = $sitepress->get_current_language();
	$option_key   = $option_name . '_' . $current_lang;

	return get_option( $option_key, get_option( $option_name, $default ) );
}

/**
 * Add WPML configuration file
 *
 * @since 1.0.0
 */
function starter_flavor_create_wpml_config() {
	if ( ! defined( 'ICL_SITEPRESS_VERSION' ) ) {
		return;
	}

	// Check if wpml-config.xml already exists
	$wpml_config = STARTER_FLAVOR_THEME_DIR . '/wpml-config.xml';

	if ( file_exists( $wpml_config ) ) {
		return;
	}

	$config_content = '<?xml version="1.0" encoding="UTF-8"?>
<wpml>
	<admin-texts>
		<!-- Theme customizer options that need translation -->
		<key name="starter_flavor_color_primary">
			<key name="label" />
		</key>
		<key name="starter_flavor_color_secondary">
			<key name="label" />
		</key>
		<key name="woo_show_mini_cart">
			<key name="label" />
		</key>
		<key name="woo_shop_columns">
			<key name="label" />
		</key>
	</admin-texts>

	<custom-types>
		<!-- Custom post types that should be translatable -->
		<custom-type translate="1">post</custom-type>
		<custom-type translate="1">page</custom-type>
		<custom-type translate="1">product</custom-type>
	</custom-types>

	<custom-fields>
		<!-- Custom fields that should be translatable -->
		<custom-field action="copy">_thumbnail_id</custom-field>
	</custom-fields>

	<taxonomies>
		<!-- Taxonomies to translate -->
		<taxonomy translate="1">category</taxonomy>
		<taxonomy translate="1">post_tag</taxonomy>
		<taxonomy translate="1">product_cat</taxonomy>
	</taxonomies>

	<widgets>
		<!-- Widgets to copy/translate -->
		<widget type="text" translate="1" />
		<widget type="custom_html" translate="1" />
	</widgets>
</wpml>';

	// Write the configuration file
	wp_mkdir_p( STARTER_FLAVOR_THEME_DIR );
	file_put_contents( $wpml_config, $config_content );
}
add_action( 'after_switch_theme', 'starter_flavor_create_wpml_config' );

/**
 * Add WPML language switcher to customizer
 *
 * @since 1.0.0
 * @param WP_Customize_Manager $wp_customize The customizer object.
 */
function starter_flavor_wpml_customizer_section( $wp_customize ) {
	if ( ! defined( 'ICL_SITEPRESS_VERSION' ) ) {
		return;
	}

	// Add WPML panel
	$wp_customize->add_panel(
		'starter_flavor_wpml',
		array(
			'title'       => esc_html__( 'WPML Settings', 'starter-flavor' ),
			'description' => esc_html__( 'Configure multilingual settings', 'starter-flavor' ),
			'priority'    => 50,
		)
	);

	// Show language switcher
	$wp_customize->add_setting(
		'starter_flavor_wpml_show_language_switcher',
		array(
			'default'           => true,
			'sanitize_callback' => 'rest_sanitize_boolean',
		)
	);

	$wp_customize->add_control(
		'starter_flavor_wpml_show_language_switcher',
		array(
			'label'    => esc_html__( 'Show Language Switcher', 'starter-flavor' ),
			'section'  => 'starter_flavor_wpml',
			'type'     => 'checkbox',
			'panel'    => 'starter_flavor_wpml',
		)
	);

	// Language switcher style
	$wp_customize->add_setting(
		'starter_flavor_wpml_switcher_style',
		array(
			'default'           => 'dropdown',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

	$wp_customize->add_control(
		'starter_flavor_wpml_switcher_style',
		array(
			'label'    => esc_html__( 'Language Switcher Style', 'starter-flavor' ),
			'section'  => 'starter_flavor_wpml',
			'type'     => 'select',
			'panel'    => 'starter_flavor_wpml',
			'choices'  => array(
				'dropdown' => esc_html__( 'Dropdown', 'starter-flavor' ),
				'inline'   => esc_html__( 'Inline', 'starter-flavor' ),
				'flags'    => esc_html__( 'Flags Only', 'starter-flavor' ),
			),
		)
	);

	// Show flag icons
	$wp_customize->add_setting(
		'starter_flavor_wpml_show_flags',
		array(
			'default'           => true,
			'sanitize_callback' => 'rest_sanitize_boolean',
		)
	);

	$wp_customize->add_control(
		'starter_flavor_wpml_show_flags',
		array(
			'label'    => esc_html__( 'Show Language Flags', 'starter-flavor' ),
			'section'  => 'starter_flavor_wpml',
			'type'     => 'checkbox',
			'panel'    => 'starter_flavor_wpml',
		)
	);
}
add_action( 'customize_register', 'starter_flavor_wpml_customizer_section' );

/**
 * Enqueue WPML styles
 *
 * @since 1.0.0
 */
function starter_flavor_wpml_enqueue_styles() {
	if ( ! defined( 'ICL_SITEPRESS_VERSION' ) ) {
		return;
	}

	wp_enqueue_style(
		'starter-flavor-wpml',
		STARTER_FLAVOR_THEME_URL . '/assets/css/wpml.css',
		array(),
		STARTER_FLAVOR_VERSION
	);
}
add_action( 'wp_enqueue_scripts', 'starter_flavor_wpml_enqueue_styles' );
