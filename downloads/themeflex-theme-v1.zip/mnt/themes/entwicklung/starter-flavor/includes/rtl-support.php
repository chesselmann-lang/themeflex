<?php
/**
 * RTL (Right-to-Left) Language Support
 *
 * Handles RTL stylesheet enqueuing and bidirectional text setup
 * for languages like Arabic, Hebrew, Persian, and Urdu.
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Enqueue RTL Stylesheet and Apply RTL Settings
 *
 * Loads the RTL stylesheet only when the site language is RTL.
 * Also applies necessary bidirectional text settings via WordPress hooks.
 *
 * @since 1.0.0
 * @return void
 */
function starter_flavor_enqueue_rtl_stylesheet() {
	// Only enqueue RTL stylesheet if the site language is set to RTL.
	if ( ! is_rtl() ) {
		return;
	}

	// Enqueue RTL Stylesheet with high priority to override LTR styles.
	wp_enqueue_style(
		'starter-flavor-rtl',
		STARTER_FLAVOR_THEME_URL . '/rtl.css',
		array( 'starter-flavor-style' ),
		STARTER_FLAVOR_VERSION
	);

	// Add inline script to set document direction for JavaScript libraries.
	wp_add_inline_script(
		'starter-flavor-custom',
		"window.starterFlavorData = window.starterFlavorData || {};
window.starterFlavorData.isRTL = true;
window.starterFlavorData.textDirection = 'rtl';
document.documentElement.dir = 'rtl';"
	);
}

// Hook into wp_enqueue_scripts with priority 99 (after default scripts but before custom scripts).
add_action( 'wp_enqueue_scripts', 'starter_flavor_enqueue_rtl_stylesheet', 99 );

/**
 * Set HTML dir Attribute for RTL Languages
 *
 * Adds the dir="rtl" attribute to the html element when RTL is active.
 * This is important for proper semantic markup and browser rendering.
 *
 * @since 1.0.0
 * @param string $language The language code.
 * @return string The modified language attribute with dir support.
 */
function starter_flavor_html_lang_attributes( $language ) {
	if ( is_rtl() ) {
		return $language . ' dir="rtl"';
	}

	return $language . ' dir="ltr"';
}

// Apply lang attributes with dir support.
add_filter( 'language_attributes', 'starter_flavor_html_lang_attributes', 10, 1 );

/**
 * Add RTL Body Class
 *
 * Adds 'rtl' class to the body for CSS targeting of RTL-specific styles.
 *
 * @since 1.0.0
 * @param array $classes List of body classes.
 * @return array Modified list of body classes.
 */
function starter_flavor_body_class_rtl( $classes ) {
	if ( is_rtl() ) {
		$classes[] = 'rtl-mode';
		$classes[] = 'is-rtl';
	} else {
		$classes[] = 'ltr-mode';
		$classes[] = 'is-ltr';
	}

	return $classes;
}

add_filter( 'body_class', 'starter_flavor_body_class_rtl', 10, 1 );

/**
 * RTL Support for Mega Menu
 *
 * Ensures mega menu dropdowns are positioned correctly in RTL mode.
 *
 * @since 1.0.0
 * @return void
 */
function starter_flavor_rtl_mega_menu_styles() {
	if ( ! is_rtl() ) {
		return;
	}

	// Add inline CSS for mega menu RTL positioning.
	$rtl_mega_menu_css = "
	.mega-menu {
		flex-direction: row-reverse;
	}

	.mega-menu .dropdown-menu {
		left: auto;
		right: 0;
		text-align: right;
	}

	.mega-menu-col {
		float: right;
		margin-left: 0;
		margin-right: var(--sf-spacing-lg);
	}

	.mega-menu-col:first-child {
		margin-right: 0;
	}
	";

	wp_add_inline_style( 'starter-flavor-rtl', $rtl_mega_menu_css );
}

add_action( 'wp_enqueue_scripts', 'starter_flavor_rtl_mega_menu_styles', 100 );

/**
 * RTL Support for Elementor
 *
 * Adds RTL support hooks for Elementor widgets when active.
 *
 * @since 1.0.0
 * @return void
 */
function starter_flavor_rtl_elementor_support() {
	// Check if Elementor is active.
	if ( ! defined( 'ELEMENTOR_VERSION' ) || ! is_rtl() ) {
		return;
	}

	// Add CSS class to Elementor widget containers for RTL styling.
	add_filter(
		'elementor_frontend_localize_data',
		function( $config ) {
			$config['is_rtl'] = true;
			$config['text_direction'] = 'rtl';

			return $config;
		}
	);
}

add_action( 'wp_enqueue_scripts', 'starter_flavor_rtl_elementor_support', 95 );

/**
 * RTL Support for WooCommerce
 *
 * Adds RTL-specific styles for WooCommerce when the plugin is active.
 *
 * @since 1.0.0
 * @return void
 */
function starter_flavor_rtl_woocommerce_support() {
	// Check if WooCommerce is active and RTL is enabled.
	if ( ! class_exists( 'WooCommerce' ) || ! is_rtl() ) {
		return;
	}

	// Add RTL-specific WooCommerce CSS.
	$woocommerce_rtl_css = "
	.woocommerce .products {
		text-align: right;
		direction: rtl;
	}

	.woocommerce-loop-product {
		text-align: right;
	}

	.woocommerce-loop-product__title {
		text-align: right;
	}

	.product-price {
		text-align: right;
	}

	.woocommerce .quantity {
		margin-left: 0;
		margin-right: var(--sf-spacing-sm);
	}

	.woocommerce .button {
		text-align: center;
	}

	.product-navigation {
		flex-direction: row-reverse;
	}

	.product-related {
		text-align: right;
	}
	";

	wp_add_inline_style( 'starter-flavor-rtl', $woocommerce_rtl_css );
}

add_action( 'wp_enqueue_scripts', 'starter_flavor_rtl_woocommerce_support', 100 );

/**
 * RTL Configuration for JavaScript
 *
 * Passes RTL configuration to JavaScript for dynamic RTL handling.
 *
 * @since 1.0.0
 * @return void
 */
function starter_flavor_rtl_script_config() {
	if ( ! is_rtl() ) {
		return;
	}

	$config = array(
		'isRTL'          => true,
		'textDirection'  => 'rtl',
		'htmlDir'        => 'rtl',
		'bodyDir'        => 'rtl',
		'alignmentLeft'  => 'right',
		'alignmentRight' => 'left',
	);

	// Ensure starterFlavorData is available in custom.js.
	wp_localize_script( 'starter-flavor-custom', 'starterFlavorRTL', $config );
}

add_action( 'wp_enqueue_scripts', 'starter_flavor_rtl_script_config', 101 );

/**
 * Filter Link Styles for RTL
 *
 * Ensures links are styled appropriately in RTL context.
 *
 * @since 1.0.0
 * @return void
 */
function starter_flavor_rtl_link_styles() {
	if ( ! is_rtl() ) {
		return;
	}

	$link_styles = "
	a[href*='://']{
		word-wrap: break-word;
	}

	a:focus {
		outline: 2px solid var(--sf-color-link);
		outline-offset: 2px;
	}
	";

	wp_add_inline_style( 'starter-flavor-rtl', $link_styles );
}

add_action( 'wp_enqueue_scripts', 'starter_flavor_rtl_link_styles', 102 );

/**
 * Admin Enqueue RTL Support
 *
 * Adds RTL support classes to admin screens when needed.
 *
 * @since 1.0.0
 * @return void
 */
function starter_flavor_admin_rtl_support() {
	if ( ! is_rtl() ) {
		return;
	}

	// Add body class to admin screens for RTL styling.
	add_filter(
		'admin_body_class',
		function( $classes ) {
			return $classes . ' rtl-mode is-rtl';
		}
	);
}

add_action( 'admin_init', 'starter_flavor_admin_rtl_support' );

/**
 * Localization Domain Setup for RTL
 *
 * Ensures proper text domain for translation in RTL contexts.
 *
 * @since 1.0.0
 * @return void
 */
function starter_flavor_load_rtl_textdomain() {
	// The theme text domain is loaded from functions.php,
	// but we can enhance it with RTL-specific translations.
	$locale = get_locale();

	// RTL language codes (can be extended as needed).
	$rtl_languages = array(
		'ar'    => 'Arabic',
		'he'    => 'Hebrew',
		'fa'    => 'Persian/Farsi',
		'ur'    => 'Urdu',
		'yi'    => 'Yiddish',
		'ji'    => 'Yiddish (alt)',
		'iw'    => 'Hebrew (alt)',
		'ps'    => 'Pashto',
		'sd'    => 'Sindhi',
		'ug'    => 'Uyghur',
	);

	// Check if current locale is RTL.
	foreach ( $rtl_languages as $code => $name ) {
		if ( strpos( $locale, $code ) === 0 ) {
			// Apply RTL-specific filters or settings here if needed.
			do_action( 'starter_flavor_rtl_locale_loaded', $locale, $code );
			break;
		}
	}
}

add_action( 'after_setup_theme', 'starter_flavor_load_rtl_textdomain', 20 );

/**
 * RTL Mode Detection Helper
 *
 * Returns whether RTL mode is currently active.
 *
 * @since 1.0.0
 * @return bool True if RTL, false otherwise.
 */
function starter_flavor_is_rtl() {
	return is_rtl();
}
