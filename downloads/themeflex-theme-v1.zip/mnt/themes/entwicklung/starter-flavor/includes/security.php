<?php
/**
 * Starter Flavor Theme - Security Hardening
 *
 * @package Starter_Flavor
 * @since 1.0.0
 * @description Security headers, CSP, and WordPress hardening
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ==================================================
 * REMOVE WORDPRESS VERSION INFO
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_remove_version_info' ) ) {
	/**
	 * Remove WordPress version information from frontend.
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_remove_version_info() {
		// Remove version from wp_head (generator tag)
		remove_action( 'wp_head', 'wp_generator' );

		// Remove version from RSS feeds
		add_filter( 'the_generator', '__return_empty_string' );
	}

	add_action( 'init', 'starter_flavor_remove_version_info' );
}

/**
 * ==================================================
 * DISABLE XML-RPC
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_disable_xmlrpc' ) ) {
	/**
	 * Disable XML-RPC to prevent brute force attacks.
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_disable_xmlrpc() {
		// Return 403 for XML-RPC requests
		if ( isset( $_SERVER['REQUEST_URI'] ) && strpos( $_SERVER['REQUEST_URI'], '/xmlrpc.php' ) !== false ) {
			wp_die( esc_html__( 'XML-RPC is disabled on this site.', 'starter-flavor' ), 'Forbidden', array( 'response' => 403 ) );
		}
	}

	add_action( 'init', 'starter_flavor_disable_xmlrpc' );
}

/**
 * ==================================================
 * REMOVE DANGEROUS FILTERS
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_disable_file_edit' ) ) {
	/**
	 * Disable theme and plugin file editor for security.
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_disable_file_edit() {
		if ( ! defined( 'DISALLOW_FILE_EDIT' ) ) {
			define( 'DISALLOW_FILE_EDIT', true );
		}
	}

	// This should be in wp-config.php, but we check here as well
	if ( ! defined( 'DISALLOW_FILE_EDIT' ) ) {
		// If not defined, recommend it be added to wp-config.php
	}
}

/**
 * ==================================================
 * SECURITY HEADERS
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_security_headers' ) ) {
	/**
	 * Send security headers to improve site security.
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_security_headers() {
		// Only on frontend
		if ( is_admin() || headers_sent() ) {
			return;
		}

		// X-Frame-Options: Prevent clickjacking
		header( 'X-Frame-Options: SAMEORIGIN' );

		// X-Content-Type-Options: Prevent MIME sniffing
		header( 'X-Content-Type-Options: nosniff' );

		// X-XSS-Protection: Enable XSS filter in older browsers
		header( 'X-XSS-Protection: 1; mode=block' );

		// Referrer-Policy: Control referrer information
		header( 'Referrer-Policy: no-referrer-when-downgrade' );

		// Permissions-Policy: Control browser features
		header( 'Permissions-Policy: geolocation=(), microphone=(), camera=()' );

		// Allow custom headers via filter
		$custom_headers = apply_filters( 'starter_flavor_custom_security_headers', array() );
		foreach ( $custom_headers as $header_name => $header_value ) {
			header( $header_name . ': ' . $header_value );
		}
	}

	add_action( 'send_headers', 'starter_flavor_security_headers' );
}

/**
 * ==================================================
 * STRICT TRANSPORT SECURITY (HSTS)
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_hsts_header' ) ) {
	/**
	 * Send HSTS header (only on HTTPS sites).
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_hsts_header() {
		// Only on HTTPS
		if ( ! is_ssl() || is_admin() || headers_sent() ) {
			return;
		}

		// Enable HSTS for 1 year, including subdomains
		if ( apply_filters( 'starter_flavor_enable_hsts', false ) ) {
			header( 'Strict-Transport-Security: max-age=31536000; includeSubDomains; preload' );
		}
	}

	add_action( 'send_headers', 'starter_flavor_hsts_header' );
}

/**
 * ==================================================
 * CONTENT SECURITY POLICY (CSP)
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_content_security_policy_header' ) ) {
	/**
	 * Send Content Security Policy header.
	 *
	 * CSP helps prevent XSS attacks by controlling which resources can be loaded.
	 * Start with Report-Only mode for testing.
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_content_security_policy_header() {
		if ( is_admin() || headers_sent() ) {
			return;
		}

		// Check if CSP is enabled
		$csp_enabled = apply_filters( 'starter_flavor_enable_csp', false );
		$csp_report_only = apply_filters( 'starter_flavor_csp_report_only', true );

		if ( ! $csp_enabled ) {
			return;
		}

		// Default CSP policy
		$csp = array(
			'default-src'  => "'self'",
			'script-src'   => "'self' 'unsafe-inline'", // unsafe-inline for WP inline scripts, consider removing later
			'style-src'    => "'self' 'unsafe-inline'",  // unsafe-inline for WP inline styles
			'img-src'      => "'self' data: https:",
			'font-src'     => "'self' data:",
			'connect-src'  => "'self'",
			'frame-src'    => "'self'",
			'media-src'    => "'self'",
			'object-src'   => "'none'",
		);

		// Allow custom CSP rules
		$custom_csp = apply_filters( 'starter_flavor_custom_csp_rules', array() );
		$csp = array_merge( $csp, $custom_csp );

		// Build CSP string
		$csp_string = '';
		foreach ( $csp as $directive => $value ) {
			$csp_string .= $directive . ' ' . $value . '; ';
		}

		// Send header
		if ( $csp_report_only ) {
			header( 'Content-Security-Policy-Report-Only: ' . esc_attr( $csp_string ) );
		} else {
			header( 'Content-Security-Policy: ' . esc_attr( $csp_string ) );
		}
	}

	add_action( 'send_headers', 'starter_flavor_content_security_policy_header' );
}

/**
 * ==================================================
 * SANITIZE USER INPUT
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_sanitize_request_data' ) ) {
	/**
	 * Sanitize user input from GET/POST requests.
	 *
	 * @since 1.0.0
	 * @param string $data User input data.
	 * @param string $type Sanitization type (text, email, url, etc.).
	 * @return string Sanitized data.
	 */
	function starter_flavor_sanitize_request_data( $data, $type = 'text' ) {
		switch ( $type ) {
			case 'email':
				return sanitize_email( $data );
			case 'url':
				return esc_url( $data );
			case 'text':
				return sanitize_text_field( $data );
			case 'html':
				return wp_kses_post( $data );
			default:
				return sanitize_text_field( $data );
		}
	}
}

/**
 * ==================================================
 * NONCE VERIFICATION
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_verify_nonce' ) ) {
	/**
	 * Verify nonce security token.
	 *
	 * @since 1.0.0
	 * @param string $nonce The nonce to verify.
	 * @param string $action The action name for the nonce.
	 * @return bool True if nonce is valid, false otherwise.
	 */
	function starter_flavor_verify_nonce( $nonce, $action = '' ) {
		return wp_verify_nonce( $nonce, $action ) !== false;
	}
}

/**
 * ==================================================
 * SQL INJECTION PREVENTION
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_safe_query' ) ) {
	/**
	 * Safely prepare database queries using wpdb.
	 *
	 * Always use this instead of directly building SQL strings.
	 *
	 * @since 1.0.0
	 * @param string $query SQL query with %d, %f, %s placeholders.
	 * @param array  $args Arguments to bind to placeholders.
	 * @return array|object|null Database query results.
	 */
	function starter_flavor_safe_query( $query, $args = array() ) {
		global $wpdb;

		if ( empty( $args ) ) {
			return $wpdb->get_results( $query ); // phpcs:ignore
		}

		return $wpdb->get_results( $wpdb->prepare( $query, $args ) ); // phpcs:ignore
	}
}

/**
 * ==================================================
 * CORS & CROSS-ORIGIN POLICIES
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_cors_headers' ) ) {
	/**
	 * Set CORS headers (if needed for APIs).
	 *
	 * By default, restrict to same-origin for security.
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_cors_headers() {
		// Only allow same-origin by default
		// Modify via filter if cross-origin requests are needed
		$allowed_origins = apply_filters( 'starter_flavor_allowed_cors_origins', array() );

		if ( ! empty( $allowed_origins ) && headers_sent() === false ) {
			$origin = isset( $_SERVER['HTTP_ORIGIN'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_ORIGIN'] ) ) : '';

			if ( in_array( $origin, $allowed_origins, true ) ) {
				header( 'Access-Control-Allow-Origin: ' . esc_attr( $origin ) );
				header( 'Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS' );
				header( 'Access-Control-Allow-Headers: Content-Type, Authorization' );
			}
		}
	}

	// Uncomment to enable:
	// add_action( 'send_headers', 'starter_flavor_cors_headers' );
}

/**
 * ==================================================
 * SECURITY LOGGING
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_log_security_event' ) ) {
	/**
	 * Log security-related events.
	 *
	 * @since 1.0.0
	 * @param string $event Event type.
	 * @param array  $data Event data.
	 */
	function starter_flavor_log_security_event( $event, $data = array() ) {
		// Only log if security logging is enabled
		if ( ! apply_filters( 'starter_flavor_enable_security_logging', false ) ) {
			return;
		}

		$log_entry = array(
			'timestamp' => current_time( 'mysql' ),
			'event'     => $event,
			'ip'        => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
			'user_id'   => get_current_user_id(),
			'data'      => $data,
		);

		// Store in options or custom table
		$logs = get_option( 'starter_flavor_security_logs', array() );
		$logs[] = $log_entry;

		// Keep only last 1000 logs
		if ( count( $logs ) > 1000 ) {
			$logs = array_slice( $logs, -1000 );
		}

		update_option( 'starter_flavor_security_logs', $logs );

		// Allow custom logging via filter
		do_action( 'starter_flavor_security_event_logged', $event, $data );
	}
}

/**
 * ==================================================
 * ADMIN SECURITY
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_hide_wordpress_version_in_admin' ) ) {
	/**
	 * Hide WordPress version from admin footer.
	 *
	 * @since 1.0.0
	 * @param string $content Footer content.
	 * @return string Modified footer content.
	 */
	function starter_flavor_hide_wordpress_version_in_admin( $content ) {
		return str_replace( get_the_generator( 'xhtml' ), '', $content );
	}

	// Only in admin
	if ( is_admin() ) {
		add_filter( 'admin_footer_text', 'starter_flavor_hide_wordpress_version_in_admin' );
	}
}

/**
 * ==================================================
 * SECURITY STATUS HELPER
 * ==================================================
 */

if ( ! function_exists( 'starter_flavor_get_security_status' ) ) {
	/**
	 * Get security configuration status.
	 *
	 * @since 1.0.0
	 * @return array Security features status.
	 */
	function starter_flavor_get_security_status() {
		return array(
			'version_hidden'         => true,
			'xmlrpc_disabled'        => true,
			'file_edit_disabled'     => defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT,
			'security_headers'       => true,
			'csp_enabled'            => apply_filters( 'starter_flavor_enable_csp', false ),
			'hsts_enabled'           => apply_filters( 'starter_flavor_enable_hsts', false ),
			'cors_restricted'        => true,
			'input_sanitization'     => true,
			'nonce_verification'     => true,
			'sql_injection_safe'     => true,
		);
	}
}
