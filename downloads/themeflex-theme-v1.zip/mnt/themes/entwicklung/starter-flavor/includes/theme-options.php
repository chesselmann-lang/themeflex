<?php
/**
 * Advanced Theme Options Panel
 *
 * Provides a comprehensive theme options admin page with multiple settings
 * organized in tabbed sections.
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Theme Options Class
 *
 * @since 1.0.0
 */
class Starter_Flavor_Theme_Options {

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_admin_page' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'wp_head', array( $this, 'output_css_variables' ) );
		add_action( 'wp_head', array( $this, 'output_google_fonts' ) );
		add_action( 'wp_ajax_sf_save_options', array( $this, 'ajax_save_options' ) );
		add_action( 'wp_ajax_sf_export_options', array( $this, 'ajax_export_options' ) );
		add_action( 'wp_ajax_sf_import_options', array( $this, 'ajax_import_options' ) );
		add_action( 'wp_ajax_sf_reset_options', array( $this, 'ajax_reset_options' ) );
	}

	/**
	 * Add admin menu page
	 *
	 * @since 1.0.0
	 */
	public function add_admin_page() {
		add_submenu_page(
			'themes.php',
			esc_html__( 'Starter Flavor Options', 'starter-flavor' ),
			esc_html__( 'Starter Flavor Options', 'starter-flavor' ),
			'manage_options',
			'starter-flavor-options',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Enqueue scripts and styles
	 *
	 * @since 1.0.0
	 * @param string $hook The current admin page.
	 */
	public function enqueue_scripts( $hook ) {
		if ( 'appearance_page_starter-flavor-options' !== $hook ) {
			return;
		}

		// Enqueue color picker
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );

		// Enqueue jQuery UI for drag/drop if needed
		wp_enqueue_script( 'jquery-ui-sortable' );

		// Enqueue media uploader
		wp_enqueue_media();

		// Admin styles
		wp_enqueue_style(
			'sf-theme-options',
			STARTER_FLAVOR_THEME_URL . '/assets/css/theme-options.css',
			array(),
			STARTER_FLAVOR_VERSION
		);

		// Admin scripts
		wp_enqueue_script(
			'sf-theme-options',
			STARTER_FLAVOR_THEME_URL . '/assets/js/theme-options.js',
			array( 'jquery', 'wp-color-picker', 'media-upload' ),
			STARTER_FLAVOR_VERSION,
			true
		);

		// Localize script
		wp_localize_script(
			'sf-theme-options',
			'sfThemeOptions',
			array(
				'nonce' => wp_create_nonce( 'sf_theme_options_nonce' ),
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'googleFonts' => $this->get_google_fonts_list(),
			)
		);
	}

	/**
	 * Render the options page
	 *
	 * @since 1.0.0
	 */
	public function render_page() {
		$options = $this->get_all_options();
		$tabs = $this->get_tabs();
		?>
		<div class="wrap sf-theme-options-wrap">
			<h1><?php esc_html_e( 'Starter Flavor Options', 'starter-flavor' ); ?></h1>

			<div class="sf-options-container">
				<!-- Tabs Navigation -->
				<nav class="sf-tabs-nav">
					<ul>
						<?php foreach ( $tabs as $tab_key => $tab_label ) : ?>
							<li>
								<a href="#sf-tab-<?php echo esc_attr( $tab_key ); ?>" class="sf-tab-link<?php echo ( 'general' === $tab_key ) ? ' active' : ''; ?>">
									<?php echo esc_html( $tab_label ); ?>
								</a>
							</li>
						<?php endforeach; ?>
					</ul>
				</nav>

				<!-- Tabs Content -->
				<div class="sf-tabs-content">
					<form id="sf-theme-options-form">
						<?php wp_nonce_field( 'sf_theme_options_nonce', 'sf_nonce' ); ?>

						<!-- General Tab -->
						<div id="sf-tab-general" class="sf-tab-content active">
							<h2><?php esc_html_e( 'General Settings', 'starter-flavor' ); ?></h2>
							<?php $this->render_general_tab( $options ); ?>
						</div>

						<!-- Logo Tab -->
						<div id="sf-tab-logo" class="sf-tab-content">
							<h2><?php esc_html_e( 'Logo Settings', 'starter-flavor' ); ?></h2>
							<?php $this->render_logo_tab( $options ); ?>
						</div>

						<!-- Header Tab -->
						<div id="sf-tab-header" class="sf-tab-content">
							<h2><?php esc_html_e( 'Header Settings', 'starter-flavor' ); ?></h2>
							<?php $this->render_header_tab( $options ); ?>
						</div>

						<!-- Footer Tab -->
						<div id="sf-tab-footer" class="sf-tab-content">
							<h2><?php esc_html_e( 'Footer Settings', 'starter-flavor' ); ?></h2>
							<?php $this->render_footer_tab( $options ); ?>
						</div>

						<!-- Sidebar Tab -->
						<div id="sf-tab-sidebar" class="sf-tab-content">
							<h2><?php esc_html_e( 'Sidebar Settings', 'starter-flavor' ); ?></h2>
							<?php $this->render_sidebar_tab( $options ); ?>
						</div>

						<!-- Blog Tab -->
						<div id="sf-tab-blog" class="sf-tab-content">
							<h2><?php esc_html_e( 'Blog Settings', 'starter-flavor' ); ?></h2>
							<?php $this->render_blog_tab( $options ); ?>
						</div>

						<!-- Single Post Tab -->
						<div id="sf-tab-single-post" class="sf-tab-content">
							<h2><?php esc_html_e( 'Single Post Settings', 'starter-flavor' ); ?></h2>
							<?php $this->render_single_post_tab( $options ); ?>
						</div>

						<!-- Colors Tab -->
						<div id="sf-tab-colors" class="sf-tab-content">
							<h2><?php esc_html_e( 'Color Settings', 'starter-flavor' ); ?></h2>
							<?php $this->render_colors_tab( $options ); ?>
						</div>

						<!-- Typography Tab -->
						<div id="sf-tab-typography" class="sf-tab-content">
							<h2><?php esc_html_e( 'Typography Settings', 'starter-flavor' ); ?></h2>
							<?php $this->render_typography_tab( $options ); ?>
						</div>

						<!-- Performance Tab -->
						<div id="sf-tab-performance" class="sf-tab-content">
							<h2><?php esc_html_e( 'Performance Settings', 'starter-flavor' ); ?></h2>
							<?php $this->render_performance_tab( $options ); ?>
						</div>

						<!-- SEO Tab -->
						<div id="sf-tab-seo" class="sf-tab-content">
							<h2><?php esc_html_e( 'SEO Settings', 'starter-flavor' ); ?></h2>
							<?php $this->render_seo_tab( $options ); ?>
						</div>

						<!-- Custom Code Tab -->
						<div id="sf-tab-custom-code" class="sf-tab-content">
							<h2><?php esc_html_e( 'Custom Code', 'starter-flavor' ); ?></h2>
							<?php $this->render_custom_code_tab( $options ); ?>
						</div>
					</form>

					<!-- Action Buttons -->
					<div class="sf-options-actions">
						<button id="sf-save-options" class="button button-primary">
							<?php esc_html_e( 'Save Options', 'starter-flavor' ); ?>
						</button>
						<button id="sf-export-options" class="button">
							<?php esc_html_e( 'Export', 'starter-flavor' ); ?>
						</button>
						<button id="sf-import-options" class="button">
							<?php esc_html_e( 'Import', 'starter-flavor' ); ?>
						</button>
						<button id="sf-reset-options" class="button button-secondary">
							<?php esc_html_e( 'Reset to Defaults', 'starter-flavor' ); ?>
						</button>
						<span id="sf-options-message" class="sf-message"></span>
					</div>

					<!-- Hidden file input for import -->
					<input type="file" id="sf-import-file" style="display:none;" accept=".json" />
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Get all available tabs
	 *
	 * @since 1.0.0
	 * @return array List of tabs.
	 */
	public function get_tabs() {
		return array(
			'general'      => esc_html__( 'General', 'starter-flavor' ),
			'logo'         => esc_html__( 'Logo', 'starter-flavor' ),
			'header'       => esc_html__( 'Header', 'starter-flavor' ),
			'footer'       => esc_html__( 'Footer', 'starter-flavor' ),
			'sidebar'      => esc_html__( 'Sidebar', 'starter-flavor' ),
			'blog'         => esc_html__( 'Blog', 'starter-flavor' ),
			'single-post'  => esc_html__( 'Single Post', 'starter-flavor' ),
			'colors'       => esc_html__( 'Colors', 'starter-flavor' ),
			'typography'   => esc_html__( 'Typography', 'starter-flavor' ),
			'performance'  => esc_html__( 'Performance', 'starter-flavor' ),
			'seo'          => esc_html__( 'SEO', 'starter-flavor' ),
			'custom-code'  => esc_html__( 'Custom Code', 'starter-flavor' ),
		);
	}

	/**
	 * Render General tab
	 *
	 * @since 1.0.0
	 * @param array $options Current options.
	 */
	private function render_general_tab( $options ) {
		?>
		<div class="sf-option-group">
			<label for="body_style">
				<?php esc_html_e( 'Body Style', 'starter-flavor' ); ?>
			</label>
			<select id="body_style" name="body_style" class="sf-select">
				<option value="wide" <?php selected( $options['body_style'], 'wide' ); ?>>
					<?php esc_html_e( 'Wide', 'starter-flavor' ); ?>
				</option>
				<option value="boxed" <?php selected( $options['body_style'], 'boxed' ); ?>>
					<?php esc_html_e( 'Boxed', 'starter-flavor' ); ?>
				</option>
				<option value="fullscreen" <?php selected( $options['body_style'], 'fullscreen' ); ?>>
					<?php esc_html_e( 'Fullscreen', 'starter-flavor' ); ?>
				</option>
			</select>
		</div>

		<div class="sf-option-group">
			<label for="page_width">
				<?php esc_html_e( 'Page Width (px)', 'starter-flavor' ); ?>
				<span class="sf-value-display"><?php echo esc_html( $options['page_width'] ); ?></span>
			</label>
			<input type="range" id="page_width" name="page_width" class="sf-range-slider"
				   min="800" max="1400" step="10" value="<?php echo esc_attr( $options['page_width'] ); ?>" />
		</div>

		<div class="sf-option-group">
			<label for="content_width">
				<?php esc_html_e( 'Content Width (px)', 'starter-flavor' ); ?>
				<span class="sf-value-display"><?php echo esc_html( $options['content_width'] ); ?></span>
			</label>
			<input type="range" id="content_width" name="content_width" class="sf-range-slider"
				   min="600" max="1000" step="10" value="<?php echo esc_attr( $options['content_width'] ); ?>" />
		</div>

		<div class="sf-option-group">
			<label for="page_margins">
				<?php esc_html_e( 'Page Margins (px)', 'starter-flavor' ); ?>
				<span class="sf-value-display"><?php echo esc_html( $options['page_margins'] ); ?></span>
			</label>
			<input type="range" id="page_margins" name="page_margins" class="sf-range-slider"
				   min="0" max="100" step="5" value="<?php echo esc_attr( $options['page_margins'] ); ?>" />
		</div>
		<?php
	}

	/**
	 * Render Logo tab
	 *
	 * @since 1.0.0
	 * @param array $options Current options.
	 */
	private function render_logo_tab( $options ) {
		?>
		<div class="sf-option-group">
			<label><?php esc_html_e( 'Logo Image', 'starter-flavor' ); ?></label>
			<div class="sf-media-uploader">
				<input type="hidden" id="logo_image" name="logo_image" value="<?php echo esc_attr( $options['logo_image'] ); ?>" />
				<button type="button" class="button sf-media-upload-btn" data-target="logo_image">
					<?php esc_html_e( 'Choose Image', 'starter-flavor' ); ?>
				</button>
				<?php if ( ! empty( $options['logo_image'] ) ) : ?>
					<img src="<?php echo esc_url( $options['logo_image'] ); ?>" alt="Logo" class="sf-preview-image" />
				<?php endif; ?>
			</div>
		</div>

		<div class="sf-option-group">
			<label><?php esc_html_e( 'Retina Logo (2x)', 'starter-flavor' ); ?></label>
			<div class="sf-media-uploader">
				<input type="hidden" id="logo_retina" name="logo_retina" value="<?php echo esc_attr( $options['logo_retina'] ); ?>" />
				<button type="button" class="button sf-media-upload-btn" data-target="logo_retina">
					<?php esc_html_e( 'Choose Image', 'starter-flavor' ); ?>
				</button>
				<?php if ( ! empty( $options['logo_retina'] ) ) : ?>
					<img src="<?php echo esc_url( $options['logo_retina'] ); ?>" alt="Retina Logo" class="sf-preview-image" />
				<?php endif; ?>
			</div>
		</div>

		<div class="sf-option-group">
			<label><?php esc_html_e( 'Dark Mode Logo', 'starter-flavor' ); ?></label>
			<div class="sf-media-uploader">
				<input type="hidden" id="logo_dark" name="logo_dark" value="<?php echo esc_attr( $options['logo_dark'] ); ?>" />
				<button type="button" class="button sf-media-upload-btn" data-target="logo_dark">
					<?php esc_html_e( 'Choose Image', 'starter-flavor' ); ?>
				</button>
				<?php if ( ! empty( $options['logo_dark'] ) ) : ?>
					<img src="<?php echo esc_url( $options['logo_dark'] ); ?>" alt="Dark Logo" class="sf-preview-image" />
				<?php endif; ?>
			</div>
		</div>

		<div class="sf-option-group">
			<label for="logo_zoom">
				<?php esc_html_e( 'Logo Zoom (%)', 'starter-flavor' ); ?>
				<span class="sf-value-display"><?php echo esc_html( $options['logo_zoom'] ); ?>%</span>
			</label>
			<input type="range" id="logo_zoom" name="logo_zoom" class="sf-range-slider"
				   min="50" max="200" step="10" value="<?php echo esc_attr( $options['logo_zoom'] ); ?>" />
		</div>

		<div class="sf-option-group">
			<label>
				<input type="checkbox" name="logo_text_enabled" value="1"
					<?php checked( $options['logo_text_enabled'], 1 ); ?> />
				<?php esc_html_e( 'Use Text as Logo', 'starter-flavor' ); ?>
			</label>
		</div>
		<?php
	}

	/**
	 * Render Header tab
	 *
	 * @since 1.0.0
	 * @param array $options Current options.
	 */
	private function render_header_tab( $options ) {
		?>
		<div class="sf-option-group">
			<label for="header_style">
				<?php esc_html_e( 'Header Style', 'starter-flavor' ); ?>
			</label>
			<select id="header_style" name="header_style" class="sf-select">
				<option value="default" <?php selected( $options['header_style'], 'default' ); ?>>
					<?php esc_html_e( 'Default', 'starter-flavor' ); ?>
				</option>
				<option value="centered" <?php selected( $options['header_style'], 'centered' ); ?>>
					<?php esc_html_e( 'Centered', 'starter-flavor' ); ?>
				</option>
				<option value="transparent" <?php selected( $options['header_style'], 'transparent' ); ?>>
					<?php esc_html_e( 'Transparent', 'starter-flavor' ); ?>
				</option>
				<option value="minimal" <?php selected( $options['header_style'], 'minimal' ); ?>>
					<?php esc_html_e( 'Minimal', 'starter-flavor' ); ?>
				</option>
				<option value="hamburger" <?php selected( $options['header_style'], 'hamburger' ); ?>>
					<?php esc_html_e( 'Hamburger', 'starter-flavor' ); ?>
				</option>
			</select>
		</div>

		<div class="sf-option-group">
			<label>
				<input type="checkbox" name="header_sticky" value="1"
					<?php checked( $options['header_sticky'], 1 ); ?> />
				<?php esc_html_e( 'Sticky Header', 'starter-flavor' ); ?>
			</label>
		</div>

		<div class="sf-option-group">
			<label for="header_position">
				<?php esc_html_e( 'Header Position', 'starter-flavor' ); ?>
			</label>
			<select id="header_position" name="header_position" class="sf-select">
				<option value="default" <?php selected( $options['header_position'], 'default' ); ?>>
					<?php esc_html_e( 'Default', 'starter-flavor' ); ?>
				</option>
				<option value="over" <?php selected( $options['header_position'], 'over' ); ?>>
					<?php esc_html_e( 'Over Content', 'starter-flavor' ); ?>
				</option>
			</select>
		</div>

		<div class="sf-option-group">
			<label for="header_video_url">
				<?php esc_html_e( 'Header Background Video URL', 'starter-flavor' ); ?>
			</label>
			<input type="text" id="header_video_url" name="header_video_url"
				   value="<?php echo esc_attr( $options['header_video_url'] ); ?>"
				   placeholder="https://example.com/video.mp4" class="sf-input" />
		</div>

		<div class="sf-option-group">
			<label for="header_mobile_style">
				<?php esc_html_e( 'Mobile Header Style', 'starter-flavor' ); ?>
			</label>
			<select id="header_mobile_style" name="header_mobile_style" class="sf-select">
				<option value="default" <?php selected( $options['header_mobile_style'], 'default' ); ?>>
					<?php esc_html_e( 'Default', 'starter-flavor' ); ?>
				</option>
				<option value="hamburger" <?php selected( $options['header_mobile_style'], 'hamburger' ); ?>>
					<?php esc_html_e( 'Hamburger', 'starter-flavor' ); ?>
				</option>
			</select>
		</div>
		<?php
	}

	/**
	 * Render Footer tab
	 *
	 * @since 1.0.0
	 * @param array $options Current options.
	 */
	private function render_footer_tab( $options ) {
		?>
		<div class="sf-option-group">
			<label for="footer_style">
				<?php esc_html_e( 'Footer Style', 'starter-flavor' ); ?>
			</label>
			<select id="footer_style" name="footer_style" class="sf-select">
				<option value="default" <?php selected( $options['footer_style'], 'default' ); ?>>
					<?php esc_html_e( 'Default', 'starter-flavor' ); ?>
				</option>
				<option value="custom" <?php selected( $options['footer_style'], 'custom' ); ?>>
					<?php esc_html_e( 'Custom', 'starter-flavor' ); ?>
				</option>
			</select>
		</div>

		<div class="sf-option-group">
			<label for="footer_columns">
				<?php esc_html_e( 'Footer Columns', 'starter-flavor' ); ?>
			</label>
			<select id="footer_columns" name="footer_columns" class="sf-select">
				<option value="1" <?php selected( $options['footer_columns'], '1' ); ?>>1</option>
				<option value="2" <?php selected( $options['footer_columns'], '2' ); ?>>2</option>
				<option value="3" <?php selected( $options['footer_columns'], '3' ); ?>>3</option>
				<option value="4" <?php selected( $options['footer_columns'], '4' ); ?>>4</option>
			</select>
		</div>

		<div class="sf-option-group">
			<label for="footer_copyright">
				<?php esc_html_e( 'Copyright Text', 'starter-flavor' ); ?>
			</label>
			<textarea id="footer_copyright" name="footer_copyright" class="sf-textarea" rows="3"><?php echo esc_textarea( $options['footer_copyright'] ); ?></textarea>
			<small><?php esc_html_e( 'Use {year} for current year and {site_title} for site name', 'starter-flavor' ); ?></small>
		</div>

		<div class="sf-option-group">
			<label>
				<input type="checkbox" name="footer_back_to_top" value="1"
					<?php checked( $options['footer_back_to_top'], 1 ); ?> />
				<?php esc_html_e( 'Show Back to Top Button', 'starter-flavor' ); ?>
			</label>
		</div>
		<?php
	}

	/**
	 * Render Sidebar tab
	 *
	 * @since 1.0.0
	 * @param array $options Current options.
	 */
	private function render_sidebar_tab( $options ) {
		?>
		<div class="sf-option-group">
			<label for="sidebar_position">
				<?php esc_html_e( 'Sidebar Position', 'starter-flavor' ); ?>
			</label>
			<select id="sidebar_position" name="sidebar_position" class="sf-select">
				<option value="right" <?php selected( $options['sidebar_position'], 'right' ); ?>>
					<?php esc_html_e( 'Right', 'starter-flavor' ); ?>
				</option>
				<option value="left" <?php selected( $options['sidebar_position'], 'left' ); ?>>
					<?php esc_html_e( 'Left', 'starter-flavor' ); ?>
				</option>
				<option value="none" <?php selected( $options['sidebar_position'], 'none' ); ?>>
					<?php esc_html_e( 'None', 'starter-flavor' ); ?>
				</option>
			</select>
		</div>

		<div class="sf-option-group">
			<label for="sidebar_width">
				<?php esc_html_e( 'Sidebar Width (px)', 'starter-flavor' ); ?>
				<span class="sf-value-display"><?php echo esc_html( $options['sidebar_width'] ); ?></span>
			</label>
			<input type="range" id="sidebar_width" name="sidebar_width" class="sf-range-slider"
				   min="250" max="400" step="10" value="<?php echo esc_attr( $options['sidebar_width'] ); ?>" />
		</div>

		<div class="sf-option-group">
			<label for="sidebar_gap">
				<?php esc_html_e( 'Sidebar Gap (px)', 'starter-flavor' ); ?>
				<span class="sf-value-display"><?php echo esc_html( $options['sidebar_gap'] ); ?></span>
			</label>
			<input type="range" id="sidebar_gap" name="sidebar_gap" class="sf-range-slider"
				   min="10" max="50" step="5" value="<?php echo esc_attr( $options['sidebar_gap'] ); ?>" />
		</div>

		<div class="sf-option-group">
			<label for="sidebar_style">
				<?php esc_html_e( 'Sidebar Style', 'starter-flavor' ); ?>
			</label>
			<select id="sidebar_style" name="sidebar_style" class="sf-select">
				<option value="normal" <?php selected( $options['sidebar_style'], 'normal' ); ?>>
					<?php esc_html_e( 'Normal', 'starter-flavor' ); ?>
				</option>
				<option value="float" <?php selected( $options['sidebar_style'], 'float' ); ?>>
					<?php esc_html_e( 'Float', 'starter-flavor' ); ?>
				</option>
			</select>
		</div>
		<?php
	}

	/**
	 * Render Blog tab
	 *
	 * @since 1.0.0
	 * @param array $options Current options.
	 */
	private function render_blog_tab( $options ) {
		?>
		<div class="sf-option-group">
			<label for="blog_posts_per_page">
				<?php esc_html_e( 'Posts Per Page', 'starter-flavor' ); ?>
			</label>
			<input type="number" id="blog_posts_per_page" name="blog_posts_per_page"
				   value="<?php echo esc_attr( $options['blog_posts_per_page'] ); ?>"
				   min="1" max="50" class="sf-input" />
		</div>

		<div class="sf-option-group">
			<label for="blog_style">
				<?php esc_html_e( 'Blog Style', 'starter-flavor' ); ?>
			</label>
			<select id="blog_style" name="blog_style" class="sf-select">
				<option value="classic" <?php selected( $options['blog_style'], 'classic' ); ?>>
					<?php esc_html_e( 'Classic', 'starter-flavor' ); ?>
				</option>
				<option value="grid" <?php selected( $options['blog_style'], 'grid' ); ?>>
					<?php esc_html_e( 'Grid', 'starter-flavor' ); ?>
				</option>
				<option value="list" <?php selected( $options['blog_style'], 'list' ); ?>>
					<?php esc_html_e( 'List', 'starter-flavor' ); ?>
				</option>
				<option value="masonry" <?php selected( $options['blog_style'], 'masonry' ); ?>>
					<?php esc_html_e( 'Masonry', 'starter-flavor' ); ?>
				</option>
				<option value="metro" <?php selected( $options['blog_style'], 'metro' ); ?>>
					<?php esc_html_e( 'Metro', 'starter-flavor' ); ?>
				</option>
			</select>
		</div>

		<div class="sf-option-group">
			<label for="blog_columns">
				<?php esc_html_e( 'Blog Columns', 'starter-flavor' ); ?>
			</label>
			<select id="blog_columns" name="blog_columns" class="sf-select">
				<option value="2" <?php selected( $options['blog_columns'], '2' ); ?>>2</option>
				<option value="3" <?php selected( $options['blog_columns'], '3' ); ?>>3</option>
				<option value="4" <?php selected( $options['blog_columns'], '4' ); ?>>4</option>
			</select>
		</div>

		<div class="sf-option-group">
			<label for="blog_excerpt_length">
				<?php esc_html_e( 'Excerpt Length (words)', 'starter-flavor' ); ?>
			</label>
			<input type="number" id="blog_excerpt_length" name="blog_excerpt_length"
				   value="<?php echo esc_attr( $options['blog_excerpt_length'] ); ?>"
				   min="10" max="100" class="sf-input" />
		</div>

		<div class="sf-option-group">
			<label for="blog_pagination_type">
				<?php esc_html_e( 'Pagination Type', 'starter-flavor' ); ?>
			</label>
			<select id="blog_pagination_type" name="blog_pagination_type" class="sf-select">
				<option value="numeric" <?php selected( $options['blog_pagination_type'], 'numeric' ); ?>>
					<?php esc_html_e( 'Numeric', 'starter-flavor' ); ?>
				</option>
				<option value="load-more" <?php selected( $options['blog_pagination_type'], 'load-more' ); ?>>
					<?php esc_html_e( 'Load More', 'starter-flavor' ); ?>
				</option>
				<option value="infinite" <?php selected( $options['blog_pagination_type'], 'infinite' ); ?>>
					<?php esc_html_e( 'Infinite Scroll', 'starter-flavor' ); ?>
				</option>
			</select>
		</div>

		<div class="sf-meta-options">
			<h3><?php esc_html_e( 'Post Meta Display', 'starter-flavor' ); ?></h3>
			<label>
				<input type="checkbox" name="blog_meta_date" value="1"
					<?php checked( $options['blog_meta_date'], 1 ); ?> />
				<?php esc_html_e( 'Show Date', 'starter-flavor' ); ?>
			</label>
			<label>
				<input type="checkbox" name="blog_meta_author" value="1"
					<?php checked( $options['blog_meta_author'], 1 ); ?> />
				<?php esc_html_e( 'Show Author', 'starter-flavor' ); ?>
			</label>
			<label>
				<input type="checkbox" name="blog_meta_category" value="1"
					<?php checked( $options['blog_meta_category'], 1 ); ?> />
				<?php esc_html_e( 'Show Category', 'starter-flavor' ); ?>
			</label>
			<label>
				<input type="checkbox" name="blog_meta_comments" value="1"
					<?php checked( $options['blog_meta_comments'], 1 ); ?> />
				<?php esc_html_e( 'Show Comments', 'starter-flavor' ); ?>
			</label>
			<label>
				<input type="checkbox" name="blog_meta_views" value="1"
					<?php checked( $options['blog_meta_views'], 1 ); ?> />
				<?php esc_html_e( 'Show Views', 'starter-flavor' ); ?>
			</label>
		</div>

		<div class="sf-option-group">
			<label>
				<input type="checkbox" name="blog_filters" value="1"
					<?php checked( $options['blog_filters'], 1 ); ?> />
				<?php esc_html_e( 'Enable Category Filters', 'starter-flavor' ); ?>
			</label>
		</div>
		<?php
	}

	/**
	 * Render Single Post tab
	 *
	 * @since 1.0.0
	 * @param array $options Current options.
	 */
	private function render_single_post_tab( $options ) {
		?>
		<div class="sf-option-group">
			<label for="single_post_style">
				<?php esc_html_e( 'Single Post Style', 'starter-flavor' ); ?>
			</label>
			<select id="single_post_style" name="single_post_style" class="sf-select">
				<option value="style1" <?php selected( $options['single_post_style'], 'style1' ); ?>>
					<?php esc_html_e( 'Style 1', 'starter-flavor' ); ?>
				</option>
				<option value="style2" <?php selected( $options['single_post_style'], 'style2' ); ?>>
					<?php esc_html_e( 'Style 2', 'starter-flavor' ); ?>
				</option>
				<option value="style3" <?php selected( $options['single_post_style'], 'style3' ); ?>>
					<?php esc_html_e( 'Style 3', 'starter-flavor' ); ?>
				</option>
			</select>
		</div>

		<div class="sf-option-group">
			<label for="single_featured_position">
				<?php esc_html_e( 'Featured Image Position', 'starter-flavor' ); ?>
			</label>
			<select id="single_featured_position" name="single_featured_position" class="sf-select">
				<option value="top" <?php selected( $options['single_featured_position'], 'top' ); ?>>
					<?php esc_html_e( 'Top', 'starter-flavor' ); ?>
				</option>
				<option value="background" <?php selected( $options['single_featured_position'], 'background' ); ?>>
					<?php esc_html_e( 'Background', 'starter-flavor' ); ?>
				</option>
			</select>
		</div>

		<div class="sf-option-group">
			<label>
				<input type="checkbox" name="single_related_posts" value="1"
					<?php checked( $options['single_related_posts'], 1 ); ?> />
				<?php esc_html_e( 'Show Related Posts', 'starter-flavor' ); ?>
			</label>
		</div>

		<div class="sf-option-group">
			<label for="single_related_columns">
				<?php esc_html_e( 'Related Posts Columns', 'starter-flavor' ); ?>
			</label>
			<select id="single_related_columns" name="single_related_columns" class="sf-select">
				<option value="2" <?php selected( $options['single_related_columns'], '2' ); ?>>2</option>
				<option value="3" <?php selected( $options['single_related_columns'], '3' ); ?>>3</option>
				<option value="4" <?php selected( $options['single_related_columns'], '4' ); ?>>4</option>
			</select>
		</div>

		<div class="sf-option-group">
			<label>
				<input type="checkbox" name="single_author_bio" value="1"
					<?php checked( $options['single_author_bio'], 1 ); ?> />
				<?php esc_html_e( 'Show Author Bio', 'starter-flavor' ); ?>
			</label>
		</div>

		<div class="sf-option-group">
			<label for="single_share_position">
				<?php esc_html_e( 'Share Links Position', 'starter-flavor' ); ?>
			</label>
			<select id="single_share_position" name="single_share_position" class="sf-select">
				<option value="top" <?php selected( $options['single_share_position'], 'top' ); ?>>
					<?php esc_html_e( 'Top', 'starter-flavor' ); ?>
				</option>
				<option value="bottom" <?php selected( $options['single_share_position'], 'bottom' ); ?>>
					<?php esc_html_e( 'Bottom', 'starter-flavor' ); ?>
				</option>
				<option value="both" <?php selected( $options['single_share_position'], 'both' ); ?>>
					<?php esc_html_e( 'Both', 'starter-flavor' ); ?>
				</option>
			</select>
		</div>

		<div class="sf-option-group">
			<label>
				<input type="checkbox" name="single_post_navigation" value="1"
					<?php checked( $options['single_post_navigation'], 1 ); ?> />
				<?php esc_html_e( 'Show Post Navigation', 'starter-flavor' ); ?>
			</label>
		</div>
		<?php
	}

	/**
	 * Render Colors tab
	 *
	 * @since 1.0.0
	 * @param array $options Current options.
	 */
	private function render_colors_tab( $options ) {
		?>
		<div class="sf-option-group">
			<label for="color_primary">
				<?php esc_html_e( 'Primary Color', 'starter-flavor' ); ?>
			</label>
			<input type="text" id="color_primary" name="color_primary"
				   value="<?php echo esc_attr( $options['color_primary'] ); ?>"
				   class="sf-color-picker" />
		</div>

		<div class="sf-option-group">
			<label for="color_secondary">
				<?php esc_html_e( 'Secondary Color', 'starter-flavor' ); ?>
			</label>
			<input type="text" id="color_secondary" name="color_secondary"
				   value="<?php echo esc_attr( $options['color_secondary'] ); ?>"
				   class="sf-color-picker" />
		</div>

		<div class="sf-option-group">
			<label for="color_accent">
				<?php esc_html_e( 'Accent Color', 'starter-flavor' ); ?>
			</label>
			<input type="text" id="color_accent" name="color_accent"
				   value="<?php echo esc_attr( $options['color_accent'] ); ?>"
				   class="sf-color-picker" />
		</div>

		<div class="sf-option-group">
			<label for="color_dark_mode_bg">
				<?php esc_html_e( 'Dark Mode Background', 'starter-flavor' ); ?>
			</label>
			<input type="text" id="color_dark_mode_bg" name="color_dark_mode_bg"
				   value="<?php echo esc_attr( $options['color_dark_mode_bg'] ); ?>"
				   class="sf-color-picker" />
		</div>

		<div class="sf-option-group">
			<label for="color_dark_mode_text">
				<?php esc_html_e( 'Dark Mode Text', 'starter-flavor' ); ?>
			</label>
			<input type="text" id="color_dark_mode_text" name="color_dark_mode_text"
				   value="<?php echo esc_attr( $options['color_dark_mode_text'] ); ?>"
				   class="sf-color-picker" />
		</div>
		<?php
	}

	/**
	 * Render Typography tab
	 *
	 * @since 1.0.0
	 * @param array $options Current options.
	 */
	private function render_typography_tab( $options ) {
		$fonts = $this->get_google_fonts_list();
		?>
		<div class="sf-typography-section">
			<h3><?php esc_html_e( 'Body Font', 'starter-flavor' ); ?></h3>

			<div class="sf-option-group">
				<label for="body_font_family">
					<?php esc_html_e( 'Font Family', 'starter-flavor' ); ?>
				</label>
				<select id="body_font_family" name="body_font_family" class="sf-select">
					<?php foreach ( $fonts as $font ) : ?>
						<option value="<?php echo esc_attr( $font ); ?>"
							<?php selected( $options['body_font_family'], $font ); ?>>
							<?php echo esc_html( $font ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</div>

			<div class="sf-option-group">
				<label for="body_font_size">
					<?php esc_html_e( 'Font Size (px)', 'starter-flavor' ); ?>
				</label>
				<input type="number" id="body_font_size" name="body_font_size"
					   value="<?php echo esc_attr( $options['body_font_size'] ); ?>"
					   min="10" max="24" class="sf-input" />
			</div>

			<div class="sf-option-group">
				<label for="body_font_weight">
					<?php esc_html_e( 'Font Weight', 'starter-flavor' ); ?>
				</label>
				<select id="body_font_weight" name="body_font_weight" class="sf-select">
					<option value="300" <?php selected( $options['body_font_weight'], '300' ); ?>>300 (Light)</option>
					<option value="400" <?php selected( $options['body_font_weight'], '400' ); ?>>400 (Normal)</option>
					<option value="500" <?php selected( $options['body_font_weight'], '500' ); ?>>500 (Medium)</option>
					<option value="600" <?php selected( $options['body_font_weight'], '600' ); ?>>600 (Semibold)</option>
					<option value="700" <?php selected( $options['body_font_weight'], '700' ); ?>>700 (Bold)</option>
				</select>
			</div>

			<div class="sf-option-group">
				<label for="body_line_height">
					<?php esc_html_e( 'Line Height', 'starter-flavor' ); ?>
				</label>
				<input type="text" id="body_line_height" name="body_line_height"
					   value="<?php echo esc_attr( $options['body_line_height'] ); ?>"
					   placeholder="1.6" class="sf-input" />
			</div>
		</div>

		<div class="sf-typography-section">
			<h3><?php esc_html_e( 'Heading Font', 'starter-flavor' ); ?></h3>

			<div class="sf-option-group">
				<label for="heading_font_family">
					<?php esc_html_e( 'Font Family', 'starter-flavor' ); ?>
				</label>
				<select id="heading_font_family" name="heading_font_family" class="sf-select">
					<?php foreach ( $fonts as $font ) : ?>
						<option value="<?php echo esc_attr( $font ); ?>"
							<?php selected( $options['heading_font_family'], $font ); ?>>
							<?php echo esc_html( $font ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</div>

			<div class="sf-option-group">
				<label for="heading_font_weight">
					<?php esc_html_e( 'Font Weight', 'starter-flavor' ); ?>
				</label>
				<select id="heading_font_weight" name="heading_font_weight" class="sf-select">
					<option value="300" <?php selected( $options['heading_font_weight'], '300' ); ?>>300 (Light)</option>
					<option value="400" <?php selected( $options['heading_font_weight'], '400' ); ?>>400 (Normal)</option>
					<option value="500" <?php selected( $options['heading_font_weight'], '500' ); ?>>500 (Medium)</option>
					<option value="600" <?php selected( $options['heading_font_weight'], '600' ); ?>>600 (Semibold)</option>
					<option value="700" <?php selected( $options['heading_font_weight'], '700' ); ?>>700 (Bold)</option>
				</select>
			</div>

			<div class="sf-option-group">
				<label for="heading_line_height">
					<?php esc_html_e( 'Line Height', 'starter-flavor' ); ?>
				</label>
				<input type="text" id="heading_line_height" name="heading_line_height"
					   value="<?php echo esc_attr( $options['heading_line_height'] ); ?>"
					   placeholder="1.2" class="sf-input" />
			</div>
		</div>
		<?php
	}

	/**
	 * Render Performance tab
	 *
	 * @since 1.0.0
	 * @param array $options Current options.
	 */
	private function render_performance_tab( $options ) {
		?>
		<div class="sf-option-group">
			<label>
				<input type="checkbox" name="perf_lazy_loading" value="1"
					<?php checked( $options['perf_lazy_loading'], 1 ); ?> />
				<?php esc_html_e( 'Enable Lazy Loading', 'starter-flavor' ); ?>
			</label>
		</div>

		<div class="sf-option-group">
			<label>
				<input type="checkbox" name="perf_defer_scripts" value="1"
					<?php checked( $options['perf_defer_scripts'], 1 ); ?> />
				<?php esc_html_e( 'Defer JavaScript', 'starter-flavor' ); ?>
			</label>
		</div>

		<div class="sf-option-group">
			<label>
				<input type="checkbox" name="perf_critical_css" value="1"
					<?php checked( $options['perf_critical_css'], 1 ); ?> />
				<?php esc_html_e( 'Extract Critical CSS', 'starter-flavor' ); ?>
			</label>
		</div>

		<div class="sf-option-group">
			<label>
				<input type="checkbox" name="perf_preconnect" value="1"
					<?php checked( $options['perf_preconnect'], 1 ); ?> />
				<?php esc_html_e( 'Preconnect to External Resources', 'starter-flavor' ); ?>
			</label>
		</div>

		<div class="sf-option-group">
			<label>
				<input type="checkbox" name="perf_minify_css" value="1"
					<?php checked( $options['perf_minify_css'], 1 ); ?> />
				<?php esc_html_e( 'Minify Inline CSS', 'starter-flavor' ); ?>
			</label>
		</div>
		<?php
	}

	/**
	 * Render SEO tab
	 *
	 * @since 1.0.0
	 * @param array $options Current options.
	 */
	private function render_seo_tab( $options ) {
		?>
		<div class="sf-option-group">
			<label>
				<input type="checkbox" name="seo_schema_organization" value="1"
					<?php checked( $options['seo_schema_organization'], 1 ); ?> />
				<?php esc_html_e( 'Enable Schema.org Organization', 'starter-flavor' ); ?>
			</label>
		</div>

		<div class="sf-option-group">
			<label>
				<input type="checkbox" name="seo_schema_breadcrumb" value="1"
					<?php checked( $options['seo_schema_breadcrumb'], 1 ); ?> />
				<?php esc_html_e( 'Enable BreadcrumbList Schema', 'starter-flavor' ); ?>
			</label>
		</div>

		<div class="sf-option-group">
			<label>
				<input type="checkbox" name="seo_schema_article" value="1"
					<?php checked( $options['seo_schema_article'], 1 ); ?> />
				<?php esc_html_e( 'Enable Article Schema', 'starter-flavor' ); ?>
			</label>
		</div>

		<div class="sf-option-group">
			<label>
				<input type="checkbox" name="seo_opengraph" value="1"
					<?php checked( $options['seo_opengraph'], 1 ); ?> />
				<?php esc_html_e( 'Enable Open Graph Meta Tags', 'starter-flavor' ); ?>
			</label>
		</div>

		<div class="sf-option-group">
			<label>
				<input type="checkbox" name="seo_twitter_cards" value="1"
					<?php checked( $options['seo_twitter_cards'], 1 ); ?> />
				<?php esc_html_e( 'Enable Twitter Cards', 'starter-flavor' ); ?>
			</label>
		</div>
		<?php
	}

	/**
	 * Render Custom Code tab
	 *
	 * @since 1.0.0
	 * @param array $options Current options.
	 */
	private function render_custom_code_tab( $options ) {
		?>
		<div class="sf-option-group">
			<label for="custom_css">
				<?php esc_html_e( 'Custom CSS', 'starter-flavor' ); ?>
			</label>
			<textarea id="custom_css" name="custom_css" class="sf-textarea" rows="10"><?php echo esc_textarea( $options['custom_css'] ); ?></textarea>
		</div>

		<div class="sf-option-group">
			<label for="custom_js_head">
				<?php esc_html_e( 'Custom JavaScript (Head)', 'starter-flavor' ); ?>
			</label>
			<textarea id="custom_js_head" name="custom_js_head" class="sf-textarea" rows="8"><?php echo esc_textarea( $options['custom_js_head'] ); ?></textarea>
		</div>

		<div class="sf-option-group">
			<label for="custom_js_footer">
				<?php esc_html_e( 'Custom JavaScript (Footer)', 'starter-flavor' ); ?>
			</label>
			<textarea id="custom_js_footer" name="custom_js_footer" class="sf-textarea" rows="8"><?php echo esc_textarea( $options['custom_js_footer'] ); ?></textarea>
		</div>
		<?php
	}

	/**
	 * Get all theme options with defaults
	 *
	 * @since 1.0.0
	 * @return array All options.
	 */
	public function get_all_options() {
		$defaults = $this->get_defaults();
		$options = array();

		foreach ( $defaults as $key => $value ) {
			$options[ $key ] = get_option( 'sf_options_' . $key, $value );
		}

		return $options;
	}

	/**
	 * Get default options
	 *
	 * @since 1.0.0
	 * @return array Default options.
	 */
	private function get_defaults() {
		return array(
			// General
			'body_style'              => 'wide',
			'page_width'              => '1200',
			'content_width'           => '800',
			'page_margins'            => '20',

			// Logo
			'logo_image'              => '',
			'logo_retina'             => '',
			'logo_dark'               => '',
			'logo_zoom'               => '100',
			'logo_text_enabled'       => 0,

			// Header
			'header_style'            => 'default',
			'header_sticky'           => 0,
			'header_position'         => 'default',
			'header_video_url'        => '',
			'header_mobile_style'     => 'hamburger',

			// Footer
			'footer_style'            => 'default',
			'footer_columns'          => '4',
			'footer_copyright'        => '&copy; {year} {site_title}. All rights reserved.',
			'footer_back_to_top'      => 1,

			// Sidebar
			'sidebar_position'        => 'right',
			'sidebar_width'           => '300',
			'sidebar_gap'             => '30',
			'sidebar_style'           => 'normal',

			// Blog
			'blog_posts_per_page'     => '10',
			'blog_style'              => 'classic',
			'blog_columns'            => '2',
			'blog_excerpt_length'     => '20',
			'blog_pagination_type'    => 'numeric',
			'blog_meta_date'          => 1,
			'blog_meta_author'        => 1,
			'blog_meta_category'      => 1,
			'blog_meta_comments'      => 1,
			'blog_meta_views'         => 0,
			'blog_filters'            => 0,

			// Single Post
			'single_post_style'       => 'style1',
			'single_featured_position' => 'top',
			'single_related_posts'    => 1,
			'single_related_columns'  => '3',
			'single_author_bio'       => 1,
			'single_share_position'   => 'bottom',
			'single_post_navigation'  => 1,

			// Colors
			'color_primary'           => '#FF5E2E',
			'color_secondary'         => '#1F242E',
			'color_accent'            => '#00D4FF',
			'color_dark_mode_bg'      => '#1a1a1a',
			'color_dark_mode_text'    => '#ffffff',

			// Typography
			'body_font_family'        => 'Inter',
			'body_font_size'          => '16',
			'body_font_weight'        => '400',
			'body_line_height'        => '1.6',
			'heading_font_family'     => 'Inter Tight',
			'heading_font_weight'     => '700',
			'heading_line_height'     => '1.2',

			// Performance
			'perf_lazy_loading'       => 1,
			'perf_defer_scripts'      => 0,
			'perf_critical_css'       => 0,
			'perf_preconnect'         => 0,
			'perf_minify_css'         => 0,

			// SEO
			'seo_schema_organization' => 1,
			'seo_schema_breadcrumb'   => 1,
			'seo_schema_article'      => 1,
			'seo_opengraph'           => 1,
			'seo_twitter_cards'       => 1,

			// Custom Code
			'custom_css'              => '',
			'custom_js_head'          => '',
			'custom_js_footer'        => '',
		);
	}

	/**
	 * Output CSS variables on frontend
	 *
	 * @since 1.0.0
	 */
	public function output_css_variables() {
		if ( is_admin() ) {
			return;
		}

		$options = $this->get_all_options();

		$css = ':root {
			--sf-color-primary: ' . esc_attr( $options['color_primary'] ) . ';
			--sf-color-secondary: ' . esc_attr( $options['color_secondary'] ) . ';
			--sf-color-accent: ' . esc_attr( $options['color_accent'] ) . ';
			--sf-body-font: ' . esc_attr( $options['body_font_family'] ) . ', sans-serif;
			--sf-heading-font: ' . esc_attr( $options['heading_font_family'] ) . ', sans-serif;
			--sf-body-font-size: ' . esc_attr( $options['body_font_size'] ) . 'px;
			--sf-body-line-height: ' . esc_attr( $options['body_line_height'] ) . ';
			--sf-heading-line-height: ' . esc_attr( $options['heading_line_height'] ) . ';
			--sf-page-width: ' . esc_attr( $options['page_width'] ) . 'px;
			--sf-content-width: ' . esc_attr( $options['content_width'] ) . 'px;
			--sf-sidebar-width: ' . esc_attr( $options['sidebar_width'] ) . 'px;
			--sf-sidebar-gap: ' . esc_attr( $options['sidebar_gap'] ) . 'px;
		}';

		// Output custom CSS
		if ( ! empty( $options['custom_css'] ) ) {
			$css .= "\n" . $options['custom_css'];
		}

		wp_register_style( 'sf-theme-variables', false );
		wp_enqueue_style( 'sf-theme-variables' );
		wp_add_inline_style( 'sf-theme-variables', $css );

		// Output custom JS in head
		if ( ! empty( $options['custom_js_head'] ) ) {
			echo '<script type="text/javascript">' . $options['custom_js_head'] . '</script>' . "\n";
		}
	}

	/**
	 * Output Google Fonts link
	 *
	 * @since 1.0.0
	 */
	public function output_google_fonts() {
		if ( is_admin() ) {
			return;
		}

		$options = $this->get_all_options();
		$fonts = array( $options['body_font_family'], $options['heading_font_family'] );
		$fonts = array_unique( array_filter( $fonts ) );

		if ( empty( $fonts ) ) {
			return;
		}

		$font_string = implode( '|', $fonts );
		$font_url = 'https://fonts.googleapis.com/css2?family=' . urlencode( $font_string ) . ':wght@300;400;500;600;700&display=swap';

		wp_enqueue_style(
			'sf-custom-google-fonts',
			$font_url,
			array(),
			STARTER_FLAVOR_VERSION
		);
	}

	/**
	 * AJAX handler to save options
	 *
	 * @since 1.0.0
	 */
	public function ajax_save_options() {
		check_ajax_referer( 'sf_theme_options_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => esc_html__( 'Insufficient permissions', 'starter-flavor' ) ) );
		}

		$data = isset( $_POST['data'] ) ? wp_parse_args( $_POST['data'] ) : array();

		foreach ( $data as $key => $value ) {
			$key = sanitize_text_field( $key );

			// Sanitize by type
			if ( in_array( $key, array( 'custom_css', 'custom_js_head', 'custom_js_footer' ), true ) ) {
				$value = wp_kses_post( $value );
			} elseif ( in_array( $key, array( 'color_primary', 'color_secondary', 'color_accent', 'color_dark_mode_bg', 'color_dark_mode_text' ), true ) ) {
				$value = sanitize_hex_color( $value );
			} else {
				$value = sanitize_text_field( $value );
			}

			update_option( 'sf_options_' . $key, $value );
		}

		wp_send_json_success( array( 'message' => esc_html__( 'Settings saved successfully', 'starter-flavor' ) ) );
	}

	/**
	 * AJAX handler to export options
	 *
	 * @since 1.0.0
	 */
	public function ajax_export_options() {
		check_ajax_referer( 'sf_theme_options_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => esc_html__( 'Insufficient permissions', 'starter-flavor' ) ) );
		}

		$options = $this->get_all_options();
		wp_send_json_success( array( 'data' => $options ) );
	}

	/**
	 * AJAX handler to import options
	 *
	 * @since 1.0.0
	 */
	public function ajax_import_options() {
		check_ajax_referer( 'sf_theme_options_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => esc_html__( 'Insufficient permissions', 'starter-flavor' ) ) );
		}

		$data = isset( $_POST['data'] ) ? json_decode( wp_unslash( $_POST['data'] ), true ) : array();

		if ( ! is_array( $data ) || empty( $data ) ) {
			wp_send_json_error( array( 'message' => esc_html__( 'Invalid data format', 'starter-flavor' ) ) );
		}

		foreach ( $data as $key => $value ) {
			$key = sanitize_text_field( $key );

			if ( in_array( $key, array( 'custom_css', 'custom_js_head', 'custom_js_footer' ), true ) ) {
				$value = wp_kses_post( $value );
			} elseif ( in_array( $key, array( 'color_primary', 'color_secondary', 'color_accent', 'color_dark_mode_bg', 'color_dark_mode_text' ), true ) ) {
				$value = sanitize_hex_color( $value );
			} else {
				$value = sanitize_text_field( $value );
			}

			update_option( 'sf_options_' . $key, $value );
		}

		wp_send_json_success( array( 'message' => esc_html__( 'Settings imported successfully', 'starter-flavor' ) ) );
	}

	/**
	 * AJAX handler to reset options
	 *
	 * @since 1.0.0
	 */
	public function ajax_reset_options() {
		check_ajax_referer( 'sf_theme_options_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => esc_html__( 'Insufficient permissions', 'starter-flavor' ) ) );
		}

		$defaults = $this->get_defaults();

		foreach ( $defaults as $key => $value ) {
			delete_option( 'sf_options_' . $key );
		}

		wp_send_json_success( array( 'message' => esc_html__( 'Settings reset to defaults', 'starter-flavor' ) ) );
	}

	/**
	 * Get list of popular Google Fonts
	 *
	 * @since 1.0.0
	 * @return array List of font names.
	 */
	private function get_google_fonts_list() {
		return array(
			'Inter',
			'Inter Tight',
			'Poppins',
			'Playfair Display',
			'Montserrat',
			'Lato',
			'Open Sans',
			'Roboto',
			'Ubuntu',
			'PT Sans',
			'Raleway',
			'Merriweather',
			'Dosis',
			'Fjalla One',
			'Inconsolata',
			'IBM Plex Mono',
			'Oswald',
			'Bebas Neue',
			'DM Serif Display',
			'Crimson Text',
			'EB Garamond',
			'Lora',
			'Cormorant Garamond',
			'Work Sans',
			'Quicksand',
			'Mulish',
			'Nunito',
			'Source Sans Pro',
			'Cabin',
			'Barlow',
		);
	}
}

// Initialize the class
new Starter_Flavor_Theme_Options();
