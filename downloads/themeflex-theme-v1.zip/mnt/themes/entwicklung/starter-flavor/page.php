<?php
/**
 * The template for displaying all single pages
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

get_header();
?>

<?php
/**
 * Action hook before loop
 *
 * @since 1.0.0
 */
do_action( 'starter_flavor_before_loop' );
?>

<?php
if ( have_posts() ) :
	while ( have_posts() ) :
		the_post();

		/**
		 * Include the page content template
		 *
		 * @since 1.0.0
		 */
		get_template_part( 'template-parts/content', 'page' );

		/**
		 * If comments are open or we have at least one comment,
		 * load up the comment template
		 *
		 * @since 1.0.0
		 */
		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}

	endwhile;
else :
	/**
	 * Include the no posts found content
	 *
	 * @since 1.0.0
	 */
	get_template_part( 'template-parts/content', 'none' );

endif;
?>

<?php
/**
 * Action hook after loop
 *
 * @since 1.0.0
 */
do_action( 'starter_flavor_after_loop' );
?>

<?php get_footer(); ?>
