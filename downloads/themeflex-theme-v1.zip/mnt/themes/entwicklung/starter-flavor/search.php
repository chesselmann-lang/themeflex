<?php
/**
 * Search Results Template — Starter Flavor
 * @package Starter_Flavor
 */
get_header();
?>
<main id="primary" class="site-main" style="padding:60px 0;">
    <div class="container" style="max-width:var(--sf-content-width,1290px);margin:0 auto;padding:0 24px;">
        <?php if (have_posts()): ?>
        <header style="margin-bottom:48px;padding-bottom:32px;border-bottom:1px solid var(--sf-border,#e5e7eb);">
            <div style="font-size:13px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--sf-meta,#94a3b8);margin-bottom:10px;"><?php printf(esc_html__('%d Results','starter-flavor'), $wp_query->found_posts); ?></div>
            <h1 style="font-family:'Inter Tight',sans-serif;font-size:clamp(28px,4vw,44px);font-weight:900;color:var(--sf-title,#1e293b);margin:0;">
                <?php printf(esc_html__('Search: %s','starter-flavor'), '<span style="color:var(--sf-color-primary,#FF5E2E);">'.get_search_query().'</span>'); ?>
            </h1>
        </header>
        <!-- Refine Search -->
        <div style="background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:12px;padding:20px;margin-bottom:40px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
            <span style="font-size:13px;font-weight:600;color:var(--sf-meta,#94a3b8);"><?php esc_html_e('Refine:','starter-flavor'); ?></span>
            <form role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>" style="display:flex;gap:8px;flex:1;min-width:200px;">
                <input type="search" name="s" value="<?php echo get_search_query(); ?>"
                       style="flex:1;padding:9px 14px;border:1px solid var(--sf-border,#e5e7eb);border-radius:8px;font-size:14px;font-family:inherit;outline:none;background:var(--sf-bg,#fff);color:var(--sf-title,#1e293b);" />
                <button type="submit" style="padding:9px 18px;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;border:none;border-radius:8px;font-weight:700;font-size:14px;cursor:pointer;font-family:inherit;"><?php esc_html_e('Search','starter-flavor'); ?></button>
            </form>
        </div>
        <div style="display:grid;gap:20px;">
            <?php while (have_posts()): the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class('sf-search-result'); ?> style="background:var(--sf-bg,#fff);border:1px solid var(--sf-border,#e5e7eb);border-radius:12px;padding:24px;display:flex;gap:20px;align-items:flex-start;transition:all .25s;" onmouseover="this.style.borderColor='var(--sf-color-primary,#FF5E2E)';this.style.boxShadow='0 4px 24px rgba(0,0,0,.06)'" onmouseout="this.style.borderColor='var(--sf-border,#e5e7eb)';this.style.boxShadow='none'">
                <?php if (has_post_thumbnail()): ?>
                <a href="<?php the_permalink(); ?>" style="flex-shrink:0;border-radius:10px;overflow:hidden;width:120px;height:90px;display:block;">
                    <?php the_post_thumbnail('thumbnail', ['style'=>'width:120px;height:90px;object-fit:cover;display:block;']); ?>
                </a>
                <?php endif; ?>
                <div style="flex:1;min-width:0;">
                    <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--sf-meta,#94a3b8);margin-bottom:6px;"><?php echo esc_html(get_post_type_labels(get_post_type_object(get_post_type()))->singular_name); ?></div>
                    <h2 style="font-size:1.1rem;font-weight:700;margin:0 0 8px;"><a href="<?php the_permalink(); ?>" style="color:var(--sf-title,#1e293b);text-decoration:none;transition:color .2s;" onmouseover="this.style.color='var(--sf-color-primary,#FF5E2E)'" onmouseout="this.style.color='var(--sf-title,#1e293b)'"><?php the_title(); ?></a></h2>
                    <p style="font-size:13px;color:var(--sf-text,#64748b);line-height:1.6;margin:0 0 10px;"><?php echo wp_trim_words(get_the_excerpt(), 20, '…'); ?></p>
                    <div style="font-size:12px;color:var(--sf-meta,#94a3b8);"><?php the_date(); ?> <?php esc_html_e('by','starter-flavor'); ?> <?php the_author(); ?></div>
                </div>
            </article>
            <?php endwhile; ?>
        </div>
        <div style="margin-top:48px;">
            <?php the_posts_pagination(['mid_size'=>2,'prev_text'=>'← '.__('Prev','starter-flavor'),'next_text'=>__('Next','starter-flavor').' →']); ?>
        </div>
        <?php else: ?>
        <div style="text-align:center;padding:80px 24px;">
            <div style="font-size:64px;margin-bottom:16px;">🔍</div>
            <h1 style="font-family:'Inter Tight',sans-serif;font-size:2rem;font-weight:800;color:var(--sf-title,#1e293b);margin-bottom:12px;"><?php esc_html_e('No results found','starter-flavor'); ?></h1>
            <p style="color:var(--sf-text,#64748b);margin-bottom:28px;"><?php esc_html_e("We couldn't find anything matching your search. Try different keywords.",'starter-flavor'); ?></p>
            <?php get_search_form(); ?>
        </div>
        <?php endif; ?>
    </div>
</main>
<?php get_footer(); ?>
