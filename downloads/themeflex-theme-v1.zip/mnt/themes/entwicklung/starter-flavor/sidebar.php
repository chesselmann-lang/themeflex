<?php
/**
 * The sidebar containing the main widget area
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! is_active_sidebar( 'main-sidebar' ) ) {
	return;
}

?>
<aside id="site-sidebar" class="site-sidebar sidebar" role="complementary" aria-label="<?php esc_attr_e( 'Primary Sidebar', 'starter-flavor' ); ?>">
	<div class="sidebar-content">
		<?php dynamic_sidebar( 'main-sidebar' ); ?>
	</div>
</aside><!-- #site-sidebar -->
