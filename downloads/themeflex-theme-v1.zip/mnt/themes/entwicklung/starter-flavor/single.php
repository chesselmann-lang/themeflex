<?php
/**
 * Single Post Template — Starter Flavor
 * @package Starter_Flavor
 */
get_header(); ?>
<main id="primary" class="site-main" style="padding:60px 0;">
    <div class="container" style="max-width:var(--sf-content-width,1290px);margin:0 auto;padding:0 24px;">
        <div style="display:grid;grid-template-columns:1fr 360px;gap:56px;align-items:start;" class="sf-single-grid">
            <!-- Article -->
            <article id="post-<?php the_ID(); ?>" <?php post_class('sf-single-article'); ?>>
                <?php if (have_posts()) while (have_posts()) the_post(); ?>
                <!-- Hero Image -->
                <?php if (has_post_thumbnail()): ?>
                <div style="margin-bottom:36px;border-radius:16px;overflow:hidden;aspect-ratio:16/7;">
                    <?php the_post_thumbnail('full', ['style'=>'width:100%;height:100%;object-fit:cover;display:block;','loading'=>'eager','fetchpriority'=>'high']); ?>
                </div>
                <?php endif; ?>
                <!-- Category + Meta -->
                <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:20px;">
                    <?php $cats = get_the_category(); if ($cats): ?>
                    <a href="<?php echo esc_url(get_category_link($cats[0]->term_id)); ?>"
                       style="padding:4px 12px;background:rgba(255,94,46,.1);color:var(--sf-color-primary,#FF5E2E);border-radius:20px;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;text-decoration:none;">
                        <?php echo esc_html($cats[0]->name); ?>
                    </a>
                    <?php endif; ?>
                    <span style="font-size:13px;color:var(--sf-meta,#94a3b8);"><?php the_date(); ?></span>
                    <span style="font-size:13px;color:var(--sf-meta,#94a3b8);">·</span>
                    <span style="font-size:13px;color:var(--sf-meta,#94a3b8);"><?php echo esc_html(ceil(str_word_count(strip_tags(get_the_content())) / 200)); ?> <?php esc_html_e('min read','starter-flavor'); ?></span>
                </div>
                <!-- Title -->
                <h1 style="font-family:'Inter Tight',sans-serif;font-size:clamp(28px,4vw,48px);font-weight:900;color:var(--sf-title,#1e293b);line-height:1.15;letter-spacing:-.5px;margin-bottom:24px;"><?php the_title(); ?></h1>
                <!-- Author line -->
                <div style="display:flex;align-items:center;gap:12px;padding:20px 0;border-top:1px solid var(--sf-border,#e5e7eb);border-bottom:1px solid var(--sf-border,#e5e7eb);margin-bottom:36px;">
                    <?php echo get_avatar(get_the_author_meta('ID'), 40, '', '', ['style'=>'width:40px;height:40px;border-radius:50%;object-fit:cover;']); ?>
                    <div>
                        <div style="font-weight:700;font-size:14px;color:var(--sf-title,#1e293b);"><?php the_author(); ?></div>
                        <div style="font-size:12px;color:var(--sf-meta,#94a3b8);"><?php echo esc_html(get_the_author_meta('description') ? wp_trim_words(get_the_author_meta('description'), 10) : get_bloginfo('name')); ?></div>
                    </div>
                    <!-- Reading progress indicator -->
                    <div style="margin-left:auto;display:flex;gap:8px;align-items:center;">
                        <?php wp_link_pages(['before'=>'<span style="font-size:12px;color:var(--sf-meta,#94a3b8);">'.__('Pages:','starter-flavor').' </span>','after'=>'']); ?>
                    </div>
                </div>
                <!-- Content -->
                <div class="entry-content sf-article-body" style="font-size:17px;line-height:1.85;color:var(--sf-text,#64748b);max-width:680px;">
                    <?php the_content(); ?>
                    <?php wp_link_pages(['before'=>'<nav class="page-links">','after'=>'</nav>']); ?>
                </div>
                <!-- Tags -->
                <?php $tags = get_the_tags(); if ($tags): ?>
                <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:36px;padding-top:24px;border-top:1px solid var(--sf-border,#e5e7eb);">
                    <span style="font-size:13px;font-weight:600;color:var(--sf-meta,#94a3b8);"><?php esc_html_e('Tags:','starter-flavor'); ?></span>
                    <?php foreach ($tags as $tag): ?>
                    <a href="<?php echo esc_url(get_tag_link($tag->term_id)); ?>"
                       style="padding:4px 12px;background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:20px;font-size:12px;color:var(--sf-text,#64748b);text-decoration:none;transition:all .2s;"
                       onmouseover="this.style.borderColor='var(--sf-color-primary,#FF5E2E)';this.style.color='var(--sf-color-primary,#FF5E2E)'" onmouseout="this.style.borderColor='var(--sf-border,#e5e7eb)';this.style.color='var(--sf-text,#64748b)'">
                        #<?php echo esc_html($tag->name); ?>
                    </a>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
                <!-- Author Box -->
                <div style="background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:16px;padding:28px;margin-top:36px;display:flex;gap:20px;align-items:flex-start;">
                    <?php echo get_avatar(get_the_author_meta('ID'), 64, '', '', ['style'=>'width:64px;height:64px;border-radius:50%;object-fit:cover;flex-shrink:0;']); ?>
                    <div>
                        <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:var(--sf-meta,#94a3b8);margin-bottom:4px;"><?php esc_html_e('About the Author','starter-flavor'); ?></div>
                        <h3 style="font-size:16px;font-weight:800;color:var(--sf-title,#1e293b);margin:0 0 8px;"><?php the_author(); ?></h3>
                        <p style="font-size:14px;color:var(--sf-text,#64748b);line-height:1.7;margin:0;"><?php echo esc_html(get_the_author_meta('description') ?: __('The author has not added a bio yet.','starter-flavor')); ?></p>
                    </div>
                </div>
                <!-- Post Navigation -->
                <nav style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:40px;" aria-label="<?php esc_attr_e('Post navigation','starter-flavor'); ?>">
                    <?php $prev = get_previous_post(); $next = get_next_post(); ?>
                    <?php if ($prev): ?>
                    <a href="<?php echo esc_url(get_permalink($prev)); ?>" style="padding:20px;background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:12px;text-decoration:none;display:block;transition:all .2s;" onmouseover="this.style.borderColor='var(--sf-color-primary,#FF5E2E)'" onmouseout="this.style.borderColor='var(--sf-border,#e5e7eb)'">
                        <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--sf-meta,#94a3b8);margin-bottom:6px;">← <?php esc_html_e('Previous','starter-flavor'); ?></div>
                        <div style="font-weight:700;font-size:14px;color:var(--sf-title,#1e293b);line-height:1.4;"><?php echo esc_html(get_the_title($prev)); ?></div>
                    </a>
                    <?php else: ?><div></div><?php endif; ?>
                    <?php if ($next): ?>
                    <a href="<?php echo esc_url(get_permalink($next)); ?>" style="padding:20px;background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:12px;text-decoration:none;display:block;text-align:right;transition:all .2s;" onmouseover="this.style.borderColor='var(--sf-color-primary,#FF5E2E)'" onmouseout="this.style.borderColor='var(--sf-border,#e5e7eb)'">
                        <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--sf-meta,#94a3b8);margin-bottom:6px;"><?php esc_html_e('Next','starter-flavor'); ?> →</div>
                        <div style="font-weight:700;font-size:14px;color:var(--sf-title,#1e293b);line-height:1.4;"><?php echo esc_html(get_the_title($next)); ?></div>
                    </a>
                    <?php endif; ?>
                </nav>
                <!-- Comments -->
                <?php if (comments_open() || get_comments_number()): ?>
                <div style="margin-top:48px;"><?php comments_template(); ?></div>
                <?php endif; ?>
            </article>
            <!-- Sidebar -->
            <aside class="sf-single-sidebar" style="position:sticky;top:32px;">
                <?php if (is_active_sidebar('sidebar-primary')): ?>
                    <?php dynamic_sidebar('sidebar-primary'); ?>
                <?php else: ?>
                    <!-- Default widgets when no sidebar configured -->
                    <div style="background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:12px;padding:24px;margin-bottom:20px;">
                        <h3 style="font-size:15px;font-weight:800;color:var(--sf-title,#1e293b);margin:0 0 16px;"><?php esc_html_e('Recent Posts','starter-flavor'); ?></h3>
                        <?php $recent = get_posts(['numberposts'=>5]); foreach ($recent as $post): setup_postdata($post); ?>
                        <a href="<?php the_permalink(); ?>" style="display:flex;gap:12px;margin-bottom:14px;text-decoration:none;align-items:flex-start;">
                            <?php if (has_post_thumbnail()): ?>
                            <div style="width:52px;height:52px;border-radius:8px;overflow:hidden;flex-shrink:0;"><?php the_post_thumbnail('thumbnail', ['style'=>'width:52px;height:52px;object-fit:cover;']); ?></div>
                            <?php endif; ?>
                            <div>
                                <div style="font-weight:600;font-size:13px;color:var(--sf-title,#1e293b);line-height:1.4;margin-bottom:3px;"><?php the_title(); ?></div>
                                <div style="font-size:11px;color:var(--sf-meta,#94a3b8);"><?php the_date(); ?></div>
                            </div>
                        </a>
                        <?php endforeach; wp_reset_postdata(); ?>
                    </div>
                    <!-- Categories -->
                    <div style="background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:12px;padding:24px;">
                        <h3 style="font-size:15px;font-weight:800;color:var(--sf-title,#1e293b);margin:0 0 16px;"><?php esc_html_e('Categories','starter-flavor'); ?></h3>
                        <ul style="list-style:none;padding:0;margin:0;">
                        <?php foreach (get_categories() as $cat): ?>
                        <li style="border-bottom:1px solid var(--sf-border,#e5e7eb);padding:8px 0;">
                            <a href="<?php echo esc_url(get_category_link($cat->term_id)); ?>" style="display:flex;justify-content:space-between;color:var(--sf-text,#64748b);text-decoration:none;font-size:14px;transition:color .2s;" onmouseover="this.style.color='var(--sf-color-primary,#FF5E2E)'" onmouseout="this.style.color='var(--sf-text,#64748b)'">
                                <span><?php echo esc_html($cat->name); ?></span>
                                <span style="background:var(--sf-bg,#fff);border:1px solid var(--sf-border,#e5e7eb);border-radius:20px;padding:0 8px;font-size:11px;"><?php echo (int)$cat->count; ?></span>
                            </a>
                        </li>
                        <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </aside>
        </div>
    </div>
</main>
<style>
.sf-article-body h2,.sf-article-body h3{color:var(--sf-title,#1e293b);font-family:'Inter Tight',sans-serif;font-weight:800;margin:2em 0 .75em;letter-spacing:-.3px}
.sf-article-body h2{font-size:1.7rem}.sf-article-body h3{font-size:1.3rem}
.sf-article-body p{margin-bottom:1.5em}
.sf-article-body img{border-radius:10px;max-width:100%;height:auto}
.sf-article-body blockquote{border-left:4px solid var(--sf-color-primary,#FF5E2E);padding:16px 24px;background:rgba(255,94,46,.05);border-radius:0 8px 8px 0;margin:1.5em 0;font-style:italic}
.sf-article-body pre,.sf-article-body code{background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:6px;font-family:'JetBrains Mono','Fira Code',monospace;font-size:13px}
.sf-article-body pre{padding:20px;overflow-x:auto;line-height:1.7}
.sf-article-body code{padding:2px 6px}
.sf-article-body a{color:var(--sf-color-primary,#FF5E2E);text-decoration:underline}
.sf-article-body ul,.sf-article-body ol{padding-left:24px;margin-bottom:1.5em}
.sf-article-body li{margin-bottom:.4em;line-height:1.7}
.sf-article-body hr{border:none;border-top:1px solid var(--sf-border,#e5e7eb);margin:2em 0}
.sf-article-body table{width:100%;border-collapse:collapse;margin:1.5em 0}
.sf-article-body table th,.sf-article-body table td{padding:12px;border:1px solid var(--sf-border,#e5e7eb);font-size:14px}
.sf-article-body table th{background:var(--sf-bg-2,#f8fafc);font-weight:700;color:var(--sf-title,#1e293b)}
@media(max-width:1024px){.sf-single-grid{grid-template-columns:1fr!important}.sf-single-sidebar{display:none}}
[data-theme=dark] .sf-article-body h2,[data-theme=dark] .sf-article-body h3{color:var(--sf-alt-title,#f1f5f9)}
[data-theme=dark] .sf-article-body blockquote{background:rgba(255,94,46,.08)}
</style>
<?php get_footer(); ?>
