<?php
/**
 * Corporate Skin Configuration
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

// Professional blue themed skin with serif typography
