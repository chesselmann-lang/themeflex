<?php
/**
 * Lawyer Skin Configuration
 *
 * Professional, authoritative legal design with dark gold and charcoal,
 * serif elegance, strong borders, and case study focus.
 *
 * @package Starter_Flavor
 * @subpackage Skins
 * @since 1.0.0
 */

namespace Starter_Flavor\Skins;

/**
 * Lawyer Skin Class
 *
 * Extends the base skin class with legal/law firm-specific customizations
 * including professional styling, testimonial focus, and case study layouts.
 */
class Lawyer_Skin {

	/**
	 * Constructor
	 *
	 * Initializes the Lawyer skin and registers hooks.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->register_hooks();
	}

	/**
	 * Register skin-specific hooks and filters
	 *
	 * @since 1.0.0
	 */
	private function register_hooks() {
		// Add skin-specific classes to body
		add_filter( 'body_class', array( $this, 'add_skin_class' ) );

		// Professional styling for testimonials
		add_filter( 'sf_testimonial_classes', array( $this, 'customize_testimonials' ) );

		// Legal practice hooks
		add_action( 'wp_head', array( $this, 'enqueue_skin_specific_styles' ) );
	}

	/**
	 * Add skin identifier class to body
	 *
	 * @param array $classes Existing body classes
	 * @return array Modified body classes
	 *
	 * @since 1.0.0
	 */
	public function add_skin_class( $classes ) {
		$classes[] = 'skin-lawyer';
		$classes[] = 'legal-professional';
		return $classes;
	}

	/**
	 * Customize testimonial styling
	 *
	 * @param string $classes Testimonial CSS classes
	 * @return string Modified testimonial classes
	 *
	 * @since 1.0.0
	 */
	public function customize_testimonials( $classes ) {
		$classes .= ' legal-testimonial--refined';
		return $classes;
	}

	/**
	 * Enqueue skin-specific inline styles
	 *
	 * @since 1.0.0
	 */
	public function enqueue_skin_specific_styles() {
		// Additional inline styles can be added here if needed
		// Main styles are handled via CSS file
	}
}

// Initialize the skin
if ( ! function_exists( 'starter_flavor_init_lawyer_skin' ) ) {
	/**
	 * Initialize Lawyer skin on theme load
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_init_lawyer_skin() {
		new Lawyer_Skin();
	}

	add_action( 'after_setup_theme', 'starter_flavor_init_lawyer_skin' );
}
