<?php
/**
 * Medical Skin Configuration
 *
 * Clean, trustworthy healthcare design with teal and navy colors,
 * rounded corners, trust badges, and appointment booking focus.
 *
 * @package Starter_Flavor
 * @subpackage Skins
 * @since 1.0.0
 */

namespace Starter_Flavor\Skins;

/**
 * Medical Skin Class
 *
 * Extends the base skin class with medical/healthcare-specific customizations
 * including clean cards, trust elements, appointment booking, and accessibility focus.
 */
class Medical_Skin {

	/**
	 * Constructor
	 *
	 * Initializes the Medical skin and registers hooks.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->register_hooks();
	}

	/**
	 * Register skin-specific hooks and filters
	 *
	 * @since 1.0.0
	 */
	private function register_hooks() {
		// Add skin-specific classes to body
		add_filter( 'body_class', array( $this, 'add_skin_class' ) );

		// Add trust badges and certifications
		add_filter( 'sf_card_content', array( $this, 'add_trust_badges' ) );

		// Healthcare-specific hooks
		add_action( 'wp_head', array( $this, 'enqueue_skin_specific_styles' ) );
	}

	/**
	 * Add skin identifier class to body
	 *
	 * @param array $classes Existing body classes
	 * @return array Modified body classes
	 *
	 * @since 1.0.0
	 */
	public function add_skin_class( $classes ) {
		$classes[] = 'skin-medical';
		$classes[] = 'healthcare-clean';
		return $classes;
	}

	/**
	 * Add trust badges to cards
	 *
	 * @param string $content Card content
	 * @return string Content with trust elements
	 *
	 * @since 1.0.0
	 */
	public function add_trust_badges( $content ) {
		// Trust elements are handled via CSS and HTML structure
		return $content;
	}

	/**
	 * Enqueue skin-specific inline styles
	 *
	 * @since 1.0.0
	 */
	public function enqueue_skin_specific_styles() {
		// Additional inline styles can be added here if needed
		// Main styles are handled via CSS file
	}
}

// Initialize the skin
if ( ! function_exists( 'starter_flavor_init_medical_skin' ) ) {
	/**
	 * Initialize Medical skin on theme load
	 *
	 * @since 1.0.0
	 */
	function starter_flavor_init_medical_skin() {
		new Medical_Skin();
	}

	add_action( 'after_setup_theme', 'starter_flavor_init_medical_skin' );
}
