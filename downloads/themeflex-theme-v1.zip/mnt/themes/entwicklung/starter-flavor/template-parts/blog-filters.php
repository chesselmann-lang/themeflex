<?php
/**
 * Template part for displaying blog filters
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

$blog_filters = starter_flavor_blog_filters();
$settings = $blog_filters->get_settings();
$filter_options = $blog_filters->get_filter_options();

if ( ! $settings['enabled'] ) {
	return;
}

?>

<div class="blog-filters-bar">
	<div class="container">
		<div class="filters-wrapper">
			<?php if ( $settings['categories'] && ! empty( $filter_options['categories'] ) ) : ?>
				<div class="filter-group">
					<select id="filter-category" class="filter-select filter-category" data-filter="category">
						<option value=""><?php esc_html_e( 'All Categories', 'starter-flavor' ); ?></option>
						<?php
						foreach ( $filter_options['categories'] as $category ) {
							?>
							<option value="<?php echo esc_attr( $category->slug ); ?>">
								<?php echo esc_html( $category->name ); ?>
							</option>
							<?php
						}
						?>
					</select>
				</div>
			<?php endif; ?>

			<?php if ( $settings['sort'] ) : ?>
				<div class="filter-group">
					<select id="filter-sort" class="filter-select filter-sort" data-filter="sort">
						<option value="date"><?php esc_html_e( 'Newest First', 'starter-flavor' ); ?></option>
						<option value="title"><?php esc_html_e( 'Title (A-Z)', 'starter-flavor' ); ?></option>
						<option value="comments"><?php esc_html_e( 'Most Comments', 'starter-flavor' ); ?></option>
					</select>
				</div>
			<?php endif; ?>

			<div class="filter-loading" style="display:none;">
				<span class="loading-spinner"></span>
				<span><?php esc_html_e( 'Loading posts...', 'starter-flavor' ); ?></span>
			</div>
		</div>
	</div>
</div>
