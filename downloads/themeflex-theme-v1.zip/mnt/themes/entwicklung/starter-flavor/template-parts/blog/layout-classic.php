<?php
/**
 * Blog Classic Layout Template Part
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'blog-post blog-layout-classic' ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<div class="post-thumbnail">
			<a href="<?php echo esc_url( get_permalink() ); ?>">
				<?php the_post_thumbnail( 'starter-flavor-thumb-big' ); ?>
			</a>
		</div>
	<?php endif; ?>

	<header class="entry-header">
		<div class="entry-meta">
			<span class="entry-author">
				<?php esc_html_e( 'By', 'starter-flavor' ); ?>
				<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>">
					<?php the_author(); ?>
				</a>
			</span>
			<span class="entry-date">
				<?php echo esc_html( get_the_date() ); ?>
			</span>
			<?php if ( has_category() ) : ?>
				<span class="entry-categories">
					<?php echo wp_kses_post( starter_flavor_get_post_categories( get_the_ID() ) ); ?>
				</span>
			<?php endif; ?>
		</div>
		<?php the_title( '<h1 class="entry-title"><a href="' . esc_url( get_permalink() ) . '">', '</a></h1>' ); ?>
	</header>

	<div class="entry-content">
		<?php
		if ( has_excerpt() ) {
			?>
			<p class="entry-summary">
				<?php the_excerpt(); ?>
			</p>
			<?php
		}
		?>
	</div>

	<footer class="entry-footer">
		<a href="<?php echo esc_url( get_permalink() ); ?>" class="read-more btn btn-primary">
			<?php esc_html_e( 'Read Full Article', 'starter-flavor' ); ?> →
		</a>
		<?php if ( function_exists( 'starter_flavor_get_reading_time' ) ) : ?>
			<span class="reading-time">
				<?php
				printf(
					esc_html__( '%d min read', 'starter-flavor' ),
					absint( starter_flavor_get_reading_time() )
				);
				?>
			</span>
		<?php endif; ?>
	</footer>
</article>
