<?php
/**
 * Blog Grid Layout Template Part
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'blog-post blog-layout-grid' ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<div class="post-thumbnail">
			<a href="<?php echo esc_url( get_permalink() ); ?>">
				<?php the_post_thumbnail( 'starter-flavor-thumb-med' ); ?>
			</a>
		</div>
	<?php endif; ?>

	<header class="entry-header">
		<div class="entry-meta">
			<span class="entry-date">
				<?php echo esc_html( get_the_date() ); ?>
			</span>
			<?php if ( has_category() ) : ?>
				<span class="entry-categories">
					<?php echo wp_kses_post( starter_flavor_get_post_categories( get_the_ID() ) ); ?>
				</span>
			<?php endif; ?>
		</div>
		<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '">', '</a></h2>' ); ?>
	</header>

	<div class="entry-content">
		<?php the_excerpt(); ?>
		<a href="<?php echo esc_url( get_permalink() ); ?>" class="read-more">
			<?php esc_html_e( 'Read More', 'starter-flavor' ); ?>
		</a>
	</div>

	<footer class="entry-footer">
		<?php if ( get_the_author_meta( 'ID' ) ) : ?>
			<span class="entry-author">
				<?php esc_html_e( 'By', 'starter-flavor' ); ?>
				<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>">
					<?php the_author(); ?>
				</a>
			</span>
		<?php endif; ?>
	</footer>
</article>
