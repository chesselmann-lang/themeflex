<?php
/**
 * Blog Metro Layout Template Part
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'blog-post blog-layout-metro' ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<div class="post-thumbnail" style="background-image: url('<?php echo esc_url( get_the_post_thumbnail_url() ); ?>'); background-size: cover; background-position: center;">
			<a href="<?php echo esc_url( get_permalink() ); ?>" style="display: block; height: 100%;" title="<?php echo esc_attr( get_the_title() ); ?>"></a>
		</div>
	<?php else : ?>
		<div class="post-thumbnail" style="background-color: #f5f5f5; display: flex; align-items: center; justify-content: center; height: 100%;">
			<a href="<?php echo esc_url( get_permalink() ); ?>" style="display: flex; align-items: center; height: 100%;"></a>
		</div>
	<?php endif; ?>

	<header class="entry-header">
		<div class="entry-meta">
			<span class="entry-category">
				<?php
				$categories = get_the_category();
				if ( ! empty( $categories ) ) {
					echo esc_html( $categories[0]->name );
				}
				?>
			</span>
		</div>
		<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '">', '</a></h2>' ); ?>
	</header>
</article>
