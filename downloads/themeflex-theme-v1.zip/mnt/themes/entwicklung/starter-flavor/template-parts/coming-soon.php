<?php
/**
 * Coming Soon / Maintenance Page Template
 * @package Starter_Flavor
 */
$settings = get_option('sf_theme_settings', []);
$msg = $settings['coming_soon_text'] ?? __('We\'re launching soon! Stay tuned.','starter-flavor');
$logo_id  = get_theme_mod('custom_logo');
$logo_url = $logo_id ? wp_get_attachment_image_url($logo_id, 'medium') : '';
status_header(200);
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<meta name="robots" content="noindex,nofollow">
<title><?php esc_html_e('Coming Soon','starter-flavor'); ?> — <?php bloginfo('name'); ?></title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',-apple-system,BlinkMacSystemFont,sans-serif;background:linear-gradient(135deg,#06021D 0%,#1a1f29 50%,#06021D 100%);min-height:100vh;display:flex;align-items:center;justify-content:center;color:#fff;overflow:hidden}
.cs-wrap{text-align:center;padding:40px 24px;position:relative;z-index:1;max-width:560px}
.cs-logo{margin-bottom:32px}
.cs-logo img{max-height:60px;filter:brightness(10)}
.cs-logo-text{font-size:24px;font-weight:900;letter-spacing:-.5px;background:linear-gradient(135deg,#FF5E2E,#00D4FF);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
h1{font-size:clamp(28px,5vw,56px);font-weight:900;line-height:1.1;letter-spacing:-.5px;margin-bottom:20px}
p{font-size:17px;color:rgba(255,255,255,.7);line-height:1.8;margin-bottom:36px}
.cs-form{display:flex;gap:8px;max-width:400px;margin:0 auto 24px}
.cs-form input{flex:1;padding:12px 16px;border:1px solid rgba(255,255,255,.15);border-radius:10px;background:rgba(255,255,255,.06);color:#fff;font-size:15px;font-family:inherit;outline:none}
.cs-form input::placeholder{color:rgba(255,255,255,.4)}
.cs-form button{padding:12px 20px;background:linear-gradient(135deg,#FF5E2E,#ED4C1C);color:#fff;border:none;border-radius:10px;font-weight:700;font-size:14px;cursor:pointer;white-space:nowrap}
.cs-social{display:flex;justify-content:center;gap:12px}
.cs-social a{width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);display:flex;align-items:center;justify-content:center;font-size:16px;text-decoration:none;transition:all .2s}
.cs-social a:hover{background:rgba(255,94,46,.3);border-color:rgba(255,94,46,.5)}
/* Orbs */
.cs-orb{position:fixed;border-radius:50%;filter:blur(80px);opacity:.2;pointer-events:none}
.cs-orb-1{width:500px;height:500px;background:radial-gradient(#FF5E2E,transparent);top:-100px;right:-100px}
.cs-orb-2{width:400px;height:400px;background:radial-gradient(#7c3aed,transparent);bottom:-80px;left:-80px}
</style>
</head>
<body>
<div class="cs-orb cs-orb-1"></div>
<div class="cs-orb cs-orb-2"></div>
<div class="cs-wrap">
    <div class="cs-logo">
        <?php if ($logo_url): ?>
        <img src="<?php echo esc_url($logo_url); ?>" alt="<?php bloginfo('name'); ?>" />
        <?php else: ?>
        <div class="cs-logo-text"><?php bloginfo('name'); ?></div>
        <?php endif; ?>
    </div>
    <h1><?php esc_html_e('Coming Soon','starter-flavor'); ?></h1>
    <p><?php echo wp_kses_post($msg); ?></p>
    <form class="cs-form" action="<?php echo esc_url(home_url('/wp-login.php')); ?>" method="post">
        <input type="email" placeholder="<?php esc_attr_e('Notify me by email...','starter-flavor'); ?>" />
        <button type="button" onclick="this.previousElementSibling.disabled=true;this.textContent='✓ Done';"><?php esc_html_e('Notify Me','starter-flavor'); ?></button>
    </form>
    <div class="cs-social">
        <?php foreach(['facebook'=>'📘','twitter'=>'𝕏','instagram'=>'📷','linkedin'=>'💼'] as $net => $ico):
            $url = get_theme_mod("sf_social_{$net}",'');
            if ($url): ?>
        <a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer" title="<?php echo esc_attr(ucfirst($net)); ?>"><?php echo $ico; ?></a>
        <?php endif; endforeach; ?>
    </div>
</div>
</body>
</html>
<?php exit; ?>
