<?php
/**
 * Template part for displaying a message that posts cannot be found
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

?>
<section class="no-results not-found">
	<header class="page-header">
		<h1 class="page-title">
			<?php esc_html_e( 'Nothing here', 'starter-flavor' ); ?>
		</h1>
	</header><!-- .page-header -->

	<div class="page-content">
		<?php
		if ( is_search() ) {
			?>
			<p>
				<?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with different keywords.', 'starter-flavor' ); ?>
			</p>
			<?php
			get_search_form();
		} elseif ( is_home() && current_user_can( 'publish_posts' ) ) {
			?>
			<p>
				<?php
				printf(
					wp_kses(
						__( 'Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'starter-flavor' ),
						array(
							'a' => array(
								'href' => array(),
							),
						)
					),
					esc_url( admin_url( 'post-new.php' ) )
				);
				?>
			</p>
			<?php
		} else {
			?>
			<p>
				<?php esc_html_e( 'It seems we can not find what you are looking for. Perhaps searching can help.', 'starter-flavor' ); ?>
			</p>
			<?php
			get_search_form();
		}
		?>
	</div><!-- .page-content -->
</section><!-- .no-results -->
