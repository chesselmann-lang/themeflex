<?php
/**
 * Template part for displaying search results
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Starter_Flavor
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry entry--search' ); ?>>
	<div class="entry__inner">
		<div class="entry__type">
			<?php
			$post_type = get_post_type();
			$post_type_object = get_post_type_object( $post_type );
			if ( $post_type_object ) {
				echo '<span class="badge">' . esc_html( $post_type_object->labels->singular_name ) . '</span>';
			}
			?>
		</div>

		<header class="entry__header">
			<?php
			the_title( sprintf( '<h2 class="entry__title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );
			?>
		</header><!-- .entry__header -->

		<div class="entry__excerpt">
			<?php
			// Display excerpt with search query highlighted
			$excerpt = get_the_excerpt();
			$search_query = get_search_query();

			if ( ! empty( $search_query ) && ! empty( $excerpt ) ) {
				$excerpt = preg_replace(
					'/(' . preg_quote( $search_query, '/' ) . ')/i',
					'<mark>$1</mark>',
					$excerpt
				);
			}

			echo wp_kses_post( $excerpt );
			?>
		</div><!-- .entry__excerpt -->

		<div class="entry__meta">
			<?php
			echo '<span class="meta__date">' . esc_html( get_the_date() ) . '</span>';
			echo '<span class="meta__author">' . esc_html__( 'by', 'starter-flavor' ) . ' ';
			the_author_posts_link();
			echo '</span>';
			?>
		</div><!-- .entry__meta -->
	</div><!-- .entry__inner -->
</article><!-- #post-<?php the_ID(); ?> -->
