<?php
/**
 * Template part for displaying posts in the loop
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Starter_Flavor
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>
	<?php
	/**
	 * Hook: starter_flavor_loop_entry_header
	 *
	 * @hooked starter_flavor_post_featured_image - 10
	 */
	do_action( 'starter_flavor_loop_entry_header' );
	?>

	<div class="entry__inner">
		<?php
		/**
		 * Hook: starter_flavor_loop_entry_top
		 *
		 * @hooked starter_flavor_post_categories - 10
		 */
		do_action( 'starter_flavor_loop_entry_top' );
		?>

		<header class="entry__header">
			<?php
			if ( is_singular() ) {
				the_title( '<h1 class="entry__title">', '</h1>' );
			} else {
				the_title( sprintf( '<h2 class="entry__title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );
			}
			?>
		</header><!-- .entry__header -->

		<?php starter_flavor_post_meta(); ?>

		<div class="entry__content">
			<?php
			if ( is_singular() ) {
				the_content(
					sprintf(
						wp_kses(
							/* translators: %s: Name of current post. Only visible to screen readers. */
							__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'starter-flavor' ),
							array(
								'span' => array(
									'class' => array(),
								),
							)
						),
						wp_kses_post( get_the_title() )
					)
				);
			} else {
				the_excerpt();
			}

			wp_link_pages(
				array(
					'before'      => '<div class="page-links">' . esc_html__( 'Pages:', 'starter-flavor' ),
					'after'       => '</div>',
					'link_before' => '<span class="page-link">',
					'link_after'  => '</span>',
				)
			);
			?>
		</div><!-- .entry__content -->

		<?php
		/**
		 * Hook: starter_flavor_loop_entry_footer
		 *
		 * @hooked starter_flavor_post_tags - 10
		 * @hooked starter_flavor_read_more_link - 20
		 */
		do_action( 'starter_flavor_loop_entry_footer' );
		?>
	</div><!-- .entry__inner -->
</article><!-- #post-<?php the_ID(); ?> -->
