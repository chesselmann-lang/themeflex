<?php
/**
 * Template part for displaying footer widgets
 *
 * @package Starter_Flavor
 */

// Get number of footer columns from customizer
$footer_columns = get_theme_mod( 'starter_flavor_footer_columns', 4 );
$footer_columns = max( 1, min( 4, intval( $footer_columns ) ) );

// Check if any widget area has widgets
$has_widgets = false;
for ( $i = 1; $i <= $footer_columns; $i++ ) {
	if ( is_active_sidebar( 'footer-' . $i ) ) {
		$has_widgets = true;
		break;
	}
}

// Only display footer widgets if at least one widget area is active
if ( $has_widgets ) {
	?>
	<div class="footer-widgets">
		<div class="container">
			<div class="footer-widgets__grid" style="--columns: <?php echo intval( $footer_columns ); ?>;">
				<?php
				for ( $i = 1; $i <= $footer_columns; $i++ ) {
					if ( is_active_sidebar( 'footer-' . $i ) ) {
						echo '<div class="footer-widgets__column">';
						dynamic_sidebar( 'footer-' . $i );
						echo '</div>';
					}
				}
				?>
			</div><!-- .footer-widgets__grid -->
		</div><!-- .container -->
	</div><!-- .footer-widgets -->
	<?php
}
?>
