<?php
/**
 * Template part for displaying gallery format posts
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

$post_formats = starter_flavor_post_formats();
$gallery_ids = $post_formats->get_gallery_ids();

?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-gallery post-format-gallery' ); ?>>
	<?php if ( ! empty( $gallery_ids ) ) : ?>
		<div class="post-gallery-slider">
			<div class="gallery-slider-wrapper">
				<?php
				foreach ( $gallery_ids as $gallery_id ) {
					$attachment = get_post( intval( $gallery_id ) );
					if ( ! $attachment ) {
						continue;
					}
					?>
					<div class="gallery-slide">
						<?php
						echo wp_kses_post(
							wp_get_attachment_image(
								$gallery_id,
								'full',
								false,
								array( 'class' => 'gallery-image' )
							)
						);
						?>
					</div>
					<?php
				}
				?>
			</div>
			<div class="gallery-nav-dots"></div>
		</div>
	<?php endif; ?>

	<header class="post-header">
		<h1 class="post-title"><?php the_title(); ?></h1>

		<div class="post-meta">
			<span class="post-date">
				<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
					<?php echo esc_html( get_the_date() ); ?>
				</time>
			</span>
			<span class="post-author">
				<?php esc_html_e( 'by', 'starter-flavor' ); ?> <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php the_author(); ?></a>
			</span>
		</div>
	</header>

	<div class="post-content">
		<?php the_content(); ?>
	</div>
</article>
