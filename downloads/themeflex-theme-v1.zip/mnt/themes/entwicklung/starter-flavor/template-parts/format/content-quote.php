<?php
/**
 * Template part for displaying quote format posts
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

$post_formats = starter_flavor_post_formats();
$quote_text = $post_formats->get_quote_text();
$quote_author = $post_formats->get_quote_author();

if ( empty( $quote_text ) ) {
	$quote_text = get_the_content();
}

?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-quote post-format-quote' ); ?>>
	<blockquote class="post-quote-block">
		<p class="quote-text">
			<?php echo wp_kses_post( $quote_text ); ?>
		</p>

		<?php if ( ! empty( $quote_author ) ) : ?>
			<footer class="quote-footer">
				<cite class="quote-author"><?php echo esc_html( $quote_author ); ?></cite>
			</footer>
		<?php endif; ?>
	</blockquote>

	<div class="post-content">
		<?php
		if ( empty( $quote_text ) || $quote_text !== get_the_content() ) {
			the_content();
		}
		?>
	</div>
</article>
