<?php
/**
 * Template part for displaying video format posts
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

$post_formats = starter_flavor_post_formats();
$video_url = $post_formats->get_video_url();

?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-video post-format-video' ); ?>>
	<?php if ( ! empty( $video_url ) ) : ?>
		<div class="post-video-wrapper">
			<div class="responsive-video-container">
				<?php
				echo wp_kses_post(
					wp_oembed_get( $video_url )
				);
				?>
			</div>
		</div>
	<?php endif; ?>

	<header class="post-header">
		<h1 class="post-title"><?php the_title(); ?></h1>

		<div class="post-meta">
			<span class="post-date">
				<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
					<?php echo esc_html( get_the_date() ); ?>
				</time>
			</span>
			<span class="post-author">
				<?php esc_html_e( 'by', 'starter-flavor' ); ?> <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php the_author(); ?></a>
			</span>
		</div>
	</header>

	<div class="post-content">
		<?php the_content(); ?>
	</div>
</article>
