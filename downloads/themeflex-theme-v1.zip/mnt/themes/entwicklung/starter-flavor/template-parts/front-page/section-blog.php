<?php
/**
 * Front Page Blog Section
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

$title = get_theme_mod( 'sf_blog_title', esc_html__( 'Latest Posts', 'starter-flavor' ) );
$count = get_theme_mod( 'sf_blog_count', '6' );
$bg_color = get_theme_mod( 'sf_blog_bg_color', '#ffffff' );
$padding_top = get_theme_mod( 'sf_blog_padding_top', '60' );
$padding_bottom = get_theme_mod( 'sf_blog_padding_bottom', '60' );
$custom_class = get_theme_mod( 'sf_blog_custom_class' );
?>

<section class="sf-blog-section <?php echo esc_attr( $custom_class ); ?>" style="padding-top: <?php echo absint( $padding_top ); ?>px; padding-bottom: <?php echo absint( $padding_bottom ); ?>px; background-color: <?php echo esc_attr( $bg_color ); ?>;">
	<div class="container">
		<?php if ( $title ) : ?>
			<h2 class="sf-section-title"><?php echo wp_kses_post( $title ); ?></h2>
		<?php endif; ?>

		<div class="sf-blog-grid">
			<?php
			$args = array(
				'posts_per_page' => absint( $count ),
				'post_status'    => 'publish',
			);

			$query = new WP_Query( $args );

			if ( $query->have_posts() ) {
				while ( $query->have_posts() ) {
					$query->the_post();
					get_template_part( 'template-parts/content', get_post_type() );
				}
				wp_reset_postdata();
			}
			?>
		</div>
	</div>
</section>
