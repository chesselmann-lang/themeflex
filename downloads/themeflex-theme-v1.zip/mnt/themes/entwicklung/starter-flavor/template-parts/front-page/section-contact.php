<?php
/**
 * Front Page Contact Section
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

$title = get_theme_mod( 'sf_contact_title', esc_html__( 'Get In Touch', 'starter-flavor' ) );
$form_shortcode = get_theme_mod( 'sf_contact_form_shortcode' );
$address = get_theme_mod( 'sf_contact_address' );
$phone = get_theme_mod( 'sf_contact_phone' );
$email = get_theme_mod( 'sf_contact_email' );
$map_url = get_theme_mod( 'sf_contact_map_url' );
$bg_color = get_theme_mod( 'sf_contact_bg_color', '#ffffff' );
$padding_top = get_theme_mod( 'sf_contact_padding_top', '60' );
$padding_bottom = get_theme_mod( 'sf_contact_padding_bottom', '60' );
$custom_class = get_theme_mod( 'sf_contact_custom_class' );
?>

<section class="sf-contact-section <?php echo esc_attr( $custom_class ); ?>" style="padding-top: <?php echo absint( $padding_top ); ?>px; padding-bottom: <?php echo absint( $padding_bottom ); ?>px; background-color: <?php echo esc_attr( $bg_color ); ?>;">
	<div class="container">
		<?php if ( $title ) : ?>
			<h2 class="sf-section-title"><?php echo wp_kses_post( $title ); ?></h2>
		<?php endif; ?>

		<div class="sf-contact-wrapper">
			<div class="sf-contact-form">
				<?php
				if ( $form_shortcode ) {
					echo do_shortcode( $form_shortcode );
				}
				?>
			</div>

			<?php if ( $address || $phone || $email || $map_url ) : ?>
				<div class="sf-contact-info">
					<?php if ( $address ) : ?>
						<div class="sf-contact-item">
							<strong><?php esc_html_e( 'Address', 'starter-flavor' ); ?>:</strong>
							<p><?php echo wp_kses_post( $address ); ?></p>
						</div>
					<?php endif; ?>

					<?php if ( $phone ) : ?>
						<div class="sf-contact-item">
							<strong><?php esc_html_e( 'Phone', 'starter-flavor' ); ?>:</strong>
							<p><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a></p>
						</div>
					<?php endif; ?>

					<?php if ( $email ) : ?>
						<div class="sf-contact-item">
							<strong><?php esc_html_e( 'Email', 'starter-flavor' ); ?>:</strong>
							<p><a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a></p>
						</div>
					<?php endif; ?>

					<?php if ( $map_url ) : ?>
						<div class="sf-contact-map">
							<iframe src="<?php echo esc_url( $map_url ); ?>" width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
						</div>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
</section>
