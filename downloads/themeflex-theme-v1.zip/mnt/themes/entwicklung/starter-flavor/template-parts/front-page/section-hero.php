<?php
/**
 * Front Page Hero Section — Pflichtenheft 2026
 *
 * Features:
 * - H1 headline + subheadline
 * - Primary + secondary CTA (min-height 48px)
 * - Trust bar (ratings, testimonials count, guarantee)
 * - Background image / video / solid color
 * - Mobile sticky CTA
 *
 * @package Starter_Flavor
 * @since 1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$hero_title       = get_theme_mod( 'sf_hero_title', get_bloginfo( 'name' ) );
$hero_eyebrow     = get_theme_mod( 'sf_hero_eyebrow', '' );
$hero_subtitle    = get_theme_mod( 'sf_hero_subtitle', get_bloginfo( 'description' ) );
$cta1_text        = get_theme_mod( 'sf_hero_cta1_text', esc_html__( 'Get Started — It\'s Free', 'starter-flavor' ) );
$cta1_url         = get_theme_mod( 'sf_hero_cta1_url', home_url( '/contact' ) );
$cta1_icon        = get_theme_mod( 'sf_hero_cta1_icon', 'fa-solid fa-rocket' );
$cta2_text        = get_theme_mod( 'sf_hero_cta2_text', esc_html__( 'View Demo', 'starter-flavor' ) );
$cta2_url         = get_theme_mod( 'sf_hero_cta2_url', home_url( '/#demos' ) );
$cta2_icon        = get_theme_mod( 'sf_hero_cta2_icon', 'fa-regular fa-circle-play' );
$bg_image         = get_theme_mod( 'sf_hero_bg_image' );
$bg_color         = get_theme_mod( 'sf_hero_bg_color', '#0f172a' );
$overlay_color    = get_theme_mod( 'sf_hero_overlay_color', 'rgba(15,23,42,0.65)' );
$video_url        = get_theme_mod( 'sf_hero_video_url' );
$trust_rating     = get_theme_mod( 'sf_hero_trust_rating', '4.9' );
$trust_reviews    = get_theme_mod( 'sf_hero_trust_reviews', '2,400+' );
$trust_guarantee  = get_theme_mod( 'sf_hero_trust_guarantee', __( '14-day money-back guarantee', 'starter-flavor' ) );
$padding_top      = get_theme_mod( 'sf_hero_padding_top', '120' );
$padding_bottom   = get_theme_mod( 'sf_hero_padding_bottom', '80' );
$custom_class     = get_theme_mod( 'sf_hero_custom_class', '' );

$section_style  = 'padding-top: ' . absint( $padding_top ) . 'px; padding-bottom: ' . absint( $padding_bottom ) . 'px;';
$section_style .= ' background-color: ' . esc_attr( $bg_color ) . ';';

if ( $bg_image ) {
	$section_style .= ' background-image: url(' . esc_url( $bg_image ) . '); background-size: cover; background-position: center;';
}
?>

<section
	id="sf-hero"
	class="sf-hero-section <?php echo esc_attr( $custom_class ); ?>"
	style="<?php echo esc_attr( $section_style ); ?>"
	aria-label="<?php esc_attr_e( 'Hero', 'starter-flavor' ); ?>"
>
	<?php if ( $video_url ) : ?>
		<video class="sf-hero-video" autoplay muted loop playsinline aria-hidden="true">
			<source src="<?php echo esc_url( $video_url ); ?>" type="video/mp4">
		</video>
	<?php endif; ?>

	<?php if ( $bg_image || $video_url ) : ?>
		<div class="sf-hero-overlay" style="background-color: <?php echo esc_attr( $overlay_color ); ?>;" aria-hidden="true"></div>
	<?php endif; ?>

	<div class="sf-hero-content sf-container">

		<?php if ( $hero_eyebrow ) : ?>
			<div class="sf-hero-eyebrow">
				<i class="fa-solid fa-star" aria-hidden="true"></i>
				<?php echo esc_html( $hero_eyebrow ); ?>
			</div>
		<?php endif; ?>

		<?php if ( $hero_title ) : ?>
			<h1 class="sf-hero-title"><?php echo wp_kses_post( $hero_title ); ?></h1>
		<?php endif; ?>

		<?php if ( $hero_subtitle ) : ?>
			<p class="sf-hero-subtitle"><?php echo wp_kses_post( $hero_subtitle ); ?></p>
		<?php endif; ?>

		<?php if ( $cta1_text || $cta2_text ) : ?>
			<div class="sf-hero-ctas">
				<?php if ( $cta1_text && $cta1_url ) : ?>
					<a href="<?php echo esc_url( $cta1_url ); ?>" class="sf-btn sf-btn-primary">
						<?php if ( $cta1_icon ) : ?>
							<i class="<?php echo esc_attr( $cta1_icon ); ?>" aria-hidden="true"></i>
						<?php endif; ?>
						<?php echo esc_html( $cta1_text ); ?>
					</a>
				<?php endif; ?>

				<?php if ( $cta2_text && $cta2_url ) : ?>
					<a href="<?php echo esc_url( $cta2_url ); ?>" class="sf-btn sf-btn-secondary">
						<?php if ( $cta2_icon ) : ?>
							<i class="<?php echo esc_attr( $cta2_icon ); ?>" aria-hidden="true"></i>
						<?php endif; ?>
						<?php echo esc_html( $cta2_text ); ?>
					</a>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<!-- Trust Bar -->
		<div class="sf-hero-trust">
			<?php if ( $trust_rating && $trust_reviews ) : ?>
				<div class="sf-hero-trust-item">
					<span class="sf-hero-stars" aria-label="<?php echo esc_attr( sprintf( __( '%s stars', 'starter-flavor' ), $trust_rating ) ); ?>">★★★★★</span>
					<span><?php echo esc_html( $trust_rating ); ?> / 5.0 &middot; <?php echo esc_html( $trust_reviews ); ?> <?php esc_html_e( 'Reviews', 'starter-flavor' ); ?></span>
				</div>
			<?php endif; ?>

			<?php if ( $trust_guarantee ) : ?>
				<div class="sf-hero-trust-item">
					<i class="fa-solid fa-shield-halved" aria-hidden="true"></i>
					<span><?php echo esc_html( $trust_guarantee ); ?></span>
				</div>
			<?php endif; ?>

			<div class="sf-hero-trust-item">
				<i class="fa-solid fa-circle-check" aria-hidden="true"></i>
				<span><?php esc_html_e( 'No credit card required', 'starter-flavor' ); ?></span>
			</div>
		</div>

	</div>
</section>

<!-- Mobile Sticky CTA (appears after hero scroll) -->
<div class="sf-mobile-sticky-cta" id="sfMobileStickyCta" aria-hidden="true">
	<?php if ( $cta1_text && $cta1_url ) : ?>
		<a href="<?php echo esc_url( $cta1_url ); ?>">
			<i class="fa-solid fa-rocket" aria-hidden="true"></i>
			<?php echo esc_html( $cta1_text ); ?>
		</a>
	<?php endif; ?>
</div>
