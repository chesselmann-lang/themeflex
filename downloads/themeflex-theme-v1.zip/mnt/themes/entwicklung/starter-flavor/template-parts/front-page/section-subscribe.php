<?php
/**
 * Front Page Subscribe / Newsletter Section — Pflichtenheft 2026
 *
 * Gradient CTA band with email form and validation.
 * Integrates with Contact Form 7 shortcode, Mailchimp for WP, or native WP.
 *
 * @package Starter_Flavor
 * @since 1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$title          = get_theme_mod( 'sf_subscribe_title', esc_html__( 'Stay in the loop', 'starter-flavor' ) );
$description    = get_theme_mod( 'sf_subscribe_description', esc_html__( 'Join 20,000+ subscribers and get tips, tutorials and updates delivered to your inbox.', 'starter-flavor' ) );
$form_shortcode = get_theme_mod( 'sf_subscribe_form_shortcode' );
$placeholder    = get_theme_mod( 'sf_subscribe_placeholder', esc_attr__( 'Your email address', 'starter-flavor' ) );
$btn_text       = get_theme_mod( 'sf_subscribe_btn_text', esc_html__( 'Subscribe', 'starter-flavor' ) );
$privacy_text   = get_theme_mod( 'sf_subscribe_privacy', esc_html__( 'We respect your privacy. Unsubscribe at any time.', 'starter-flavor' ) );
$bg_color       = get_theme_mod( 'sf_subscribe_bg_color', '' );
$padding_top    = get_theme_mod( 'sf_subscribe_padding_top', '100' );
$padding_bottom = get_theme_mod( 'sf_subscribe_padding_bottom', '100' );
$custom_class   = get_theme_mod( 'sf_subscribe_custom_class', '' );

$section_style  = 'padding-top: ' . absint( $padding_top ) . 'px; padding-bottom: ' . absint( $padding_bottom ) . 'px;';
if ( $bg_color ) { $section_style .= ' background-color: ' . esc_attr( $bg_color ) . ';'; }
?>

<section class="sf-subscribe-section <?php echo esc_attr( $custom_class ); ?>" style="<?php echo esc_attr( $section_style ); ?>" aria-label="<?php esc_attr_e( 'Newsletter', 'starter-flavor' ); ?>">
	<div class="sf-subscribe-wrapper">
		<?php if ( $title ) : ?><h2><?php echo wp_kses_post( $title ); ?></h2><?php endif; ?>
		<?php if ( $description ) : ?><p class="sf-subscribe-description"><?php echo wp_kses_post( $description ); ?></p><?php endif; ?>

		<?php if ( $form_shortcode ) : ?>
			<?php echo do_shortcode( $form_shortcode ); ?>
		<?php else : ?>
			<form class="sf-subscribe-form" id="sfSubscribeForm" novalidate>
				<?php wp_nonce_field( 'sf_subscribe', 'sf_subscribe_nonce' ); ?>
				<input
					type="email"
					id="sfSubscribeEmail"
					name="email"
					placeholder="<?php echo esc_attr( $placeholder ); ?>"
					aria-label="<?php esc_attr_e( 'Email address', 'starter-flavor' ); ?>"
					required
					autocomplete="email"
				>
				<button type="submit" class="sf-btn sf-btn-light" id="sfSubscribeBtn">
					<i class="fa-solid fa-paper-plane" aria-hidden="true"></i>
					<?php echo esc_html( $btn_text ); ?>
				</button>
			</form>
			<p class="sf-subscribe-msg" id="sfSubscribeMsg" aria-live="polite"></p>
		<?php endif; ?>

		<?php if ( $privacy_text ) : ?>
			<p style="margin-top:16px;font-size:12px;color:rgba(255,255,255,0.6);">
				<i class="fa-solid fa-lock" aria-hidden="true" style="margin-right:4px;"></i>
				<?php echo esc_html( $privacy_text ); ?>
			</p>
		<?php endif; ?>
	</div>
</section>
