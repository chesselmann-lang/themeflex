<?php
/**
 * Front Page Testimonials / Social Proof Section — Pflichtenheft 2026
 *
 * Dark-background carousel grid with star ratings, quotes and author info.
 * Items from filter — override via add_filter('sf_testimonials_items', ...).
 *
 * @package Starter_Flavor
 * @since 1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$title          = get_theme_mod( 'sf_testimonials_title', esc_html__( 'What our clients say', 'starter-flavor' ) );
$subtitle       = get_theme_mod( 'sf_testimonials_subtitle', esc_html__( 'Trusted by thousands of businesses worldwide. Here's what they have to say about working with us.', 'starter-flavor' ) );
$tag            = get_theme_mod( 'sf_testimonials_tag', esc_html__( 'Testimonials', 'starter-flavor' ) );
$bg_color       = get_theme_mod( 'sf_testimonials_bg_color', '' );
$padding_top    = get_theme_mod( 'sf_testimonials_padding_top', '100' );
$padding_bottom = get_theme_mod( 'sf_testimonials_padding_bottom', '100' );
$custom_class   = get_theme_mod( 'sf_testimonials_custom_class', '' );

$testimonials = apply_filters( 'sf_testimonials_items', array(
	array( 'quote' => 'Working with this team was a game-changer. Our conversions increased 40% within the first month after launch.', 'name' => 'Sarah Williams',  'title' => 'CEO, GreenLeaf Agency',   'initials' => 'SW', 'photo' => '', 'stars' => 5 ),
	array( 'quote' => 'The theme is incredibly fast and the support team solved our issues within hours. Absolutely worth every penny.', 'name' => 'Marcus Bauer',    'title' => 'Founder, TechStart GmbH', 'initials' => 'MB', 'photo' => '', 'stars' => 5 ),
	array( 'quote' => 'I've tried a dozen WordPress themes and this is by far the best. Clean code, beautiful design and superb docs.', 'name' => 'Lena Kowalski',   'title' => 'Web Developer, Freelance',  'initials' => 'LK', 'photo' => '', 'stars' => 5 ),
	array( 'quote' => 'The mobile experience is flawless. Our bounce rate dropped 25% immediately after switching. Highly recommended!', 'name' => 'James Carter',   'title' => 'Marketing Manager, Bloom', 'initials' => 'JC', 'photo' => '', 'stars' => 5 ),
	array( 'quote' => 'Setup took under an hour. The one-click demo import is brilliant and the customiser options are exactly what I needed.', 'name' => 'Amina Diallo',   'title' => 'Blogger & Content Creator', 'initials' => 'AD', 'photo' => '', 'stars' => 5 ),
	array( 'quote' => 'Finally a theme that takes accessibility seriously. ARIA labels, keyboard nav and contrast ratios all perfect.', 'name' => 'Paul Reinholt',  'title' => 'Accessibility Consultant',  'initials' => 'PR', 'photo' => '', 'stars' => 5 ),
) );

$section_style = 'padding-top: ' . absint( $padding_top ) . 'px; padding-bottom: ' . absint( $padding_bottom ) . 'px;';
if ( $bg_color ) { $section_style .= ' background-color: ' . esc_attr( $bg_color ) . ';'; }
?>

<section class="sf-testimonials-section <?php echo esc_attr( $custom_class ); ?>" style="<?php echo esc_attr( $section_style ); ?>" aria-label="<?php esc_attr_e( 'Testimonials', 'starter-flavor' ); ?>">
	<div class="sf-container">
		<header class="sf-section-header">
			<?php if ( $tag )      : ?><div class="sf-section-tag"><?php echo esc_html( $tag ); ?></div><?php endif; ?>
			<?php if ( $title )    : ?><h2 class="sf-section-title"><?php echo wp_kses_post( $title ); ?></h2><?php endif; ?>
			<?php if ( $subtitle ) : ?><p class="sf-section-subtitle"><?php echo wp_kses_post( $subtitle ); ?></p><?php endif; ?>
		</header>
		<?php if ( ! empty( $testimonials ) ) : ?>
		<div class="sf-testimonials-carousel">
			<?php foreach ( $testimonials as $i => $t ) : ?>
			<div class="sf-testimonial-card sf-fade-in" style="transition-delay: <?php echo (int)( $i % 3 ) * 80; ?>ms">
				<div class="sf-testimonial-stars" aria-label="<?php printf( esc_attr__( '%d out of 5 stars', 'starter-flavor' ), absint( $t['stars'] ) ); ?>">
					<?php echo str_repeat( '★', (int) min( 5, max( 1, $t['stars'] ) ) ); ?>
				</div>
				<?php if ( ! empty( $t['quote'] ) ) : ?><blockquote class="sf-testimonial-quote">"<?php echo esc_html( $t['quote'] ); ?>"</blockquote><?php endif; ?>
				<footer class="sf-testimonial-author">
					<div class="sf-testimonial-avatar">
						<?php if ( ! empty( $t['photo'] ) ) : ?>
						<img src="<?php echo esc_url( $t['photo'] ); ?>" alt="<?php echo esc_attr( $t['name'] ); ?>" loading="lazy" decoding="async">
						<?php else : ?>
						<?php echo esc_html( $t['initials'] ); ?>
						<?php endif; ?>
					</div>
					<div>
						<?php if ( ! empty( $t['name'] ) )  : ?><p class="sf-testimonial-name"><?php echo esc_html( $t['name'] ); ?></p><?php endif; ?>
						<?php if ( ! empty( $t['title'] ) ) : ?><p class="sf-testimonial-title"><?php echo esc_html( $t['title'] ); ?></p><?php endif; ?>
					</div>
				</footer>
			</div>
			<?php endforeach; ?>
		</div>
		<?php endif; ?>
	</div>
</section>
