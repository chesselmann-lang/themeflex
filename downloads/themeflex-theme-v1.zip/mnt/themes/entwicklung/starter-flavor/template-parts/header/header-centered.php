<?php
/**
 * Template part for centered header layout
 *
 * This template displays a centered header with the site title and tagline
 * in the center of the header area.
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<header id="site-header" class="site-header header-centered" role="banner">
	<div class="header-content">
		<div class="header-inner header-centered-inner">
			<div class="header-center">
				<?php
				/**
				 * Action hook for centered header branding
				 *
				 * @since 1.0.0
				 */
				do_action( 'starter_flavor_header_branding' );

				// Display Logo
				if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
					the_custom_logo();
				} else {
					?>
					<h1 class="site-title site-title-centered">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
							<?php bloginfo( 'name' ); ?>
						</a>
					</h1>
					<?php
					$site_description = get_bloginfo( 'description' );
					if ( $site_description ) {
						?>
						<p class="site-description">
							<?php echo esc_html( $site_description ); ?>
						</p>
						<?php
					}
				}
				?>
			</div>

			<nav id="site-navigation" class="site-navigation main-navigation header-centered-nav" role="navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'starter-flavor' ); ?>">
				<button class="menu-toggle" id="menu-toggle" aria-controls="primary-menu" aria-expanded="false">
					<span class="menu-toggle-text"><?php esc_html_e( 'Menu', 'starter-flavor' ); ?></span>
					<span class="menu-toggle-icon">
						<span></span>
						<span></span>
						<span></span>
					</span>
				</button>

				<?php
				wp_nav_menu( array(
					'theme_location' => 'main-menu',
					'menu_id'        => 'primary-menu',
					'container'      => false,
					'fallback_cb'    => 'wp_page_menu',
					'depth'          => 3,
					'walker'         => class_exists( 'Starter_Flavor_Nav_Menu_Walker' ) ? new Starter_Flavor_Nav_Menu_Walker() : '',
				) );
				?>
			</nav>

			<div class="header-right">
				<?php
				// Dark Mode Toggle
				if ( starter_flavor_get_theme_option( 'enable_dark_mode' ) ) {
					?>
					<button class="dark-mode-toggle" id="dark-mode-toggle" aria-label="<?php esc_attr_e( 'Toggle dark mode', 'starter-flavor' ); ?>">
						<span class="dark-mode-icon">
							<svg class="light-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
								<circle cx="12" cy="12" r="5"></circle>
								<line x1="12" y1="1" x2="12" y2="3"></line>
								<line x1="12" y1="21" x2="12" y2="23"></line>
								<line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
								<line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
								<line x1="1" y1="12" x2="3" y2="12"></line>
								<line x1="21" y1="12" x2="23" y2="12"></line>
								<line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
								<line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
							</svg>
							<svg class="dark-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
								<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
							</svg>
						</span>
					</button>
					<?php
				}

				/**
				 * Action hook for header right content
				 *
				 * @since 1.0.0
				 */
				do_action( 'starter_flavor_header_right' );
				?>
			</div>
		</div>
	</div>
</header>
