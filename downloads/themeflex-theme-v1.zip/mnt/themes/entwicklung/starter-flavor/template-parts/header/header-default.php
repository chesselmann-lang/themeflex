<?php
/**
 * Template part for displaying the default header layout
 *
 * @package Starter_Flavor
 */

?>

<header id="masthead" class="site-header">
	<?php
	// Top bar (optional)
	$show_topbar = get_theme_mod( 'starter_flavor_show_topbar', false );
	if ( $show_topbar ) {
		echo '<div class="topbar">';
		echo '<div class="container">';
		echo '<div class="topbar__content">';

		// Left side - contact info
		echo '<div class="topbar__left">';
		$phone = get_theme_mod( 'starter_flavor_topbar_phone' );
		$email = get_theme_mod( 'starter_flavor_topbar_email' );

		if ( ! empty( $phone ) ) {
			echo '<a href="tel:' . esc_attr( $phone ) . '" class="topbar__link">';
			echo '<span class="icon">📞</span> ' . esc_html( $phone );
			echo '</a>';
		}

		if ( ! empty( $email ) ) {
			echo '<a href="mailto:' . esc_attr( $email ) . '" class="topbar__link">';
			echo '<span class="icon">✉</span> ' . esc_html( $email );
			echo '</a>';
		}

		echo '</div>';

		// Right side - social links
		echo '<div class="topbar__right">';
		$social_links = get_theme_mod( 'starter_flavor_social_links', array() );
		if ( ! empty( $social_links ) ) {
			echo '<div class="social-links">';
			foreach ( $social_links as $link ) {
				echo '<a href="' . esc_url( $link['url'] ) . '" class="social-link" aria-label="' . esc_attr( $link['label'] ) . '" target="_blank" rel="noopener noreferrer">';
				echo esc_html( $link['label'] );
				echo '</a>';
			}
			echo '</div>';
		}
		echo '</div>';

		echo '</div>';
		echo '</div>';
		echo '</div>';
	}
	?>

	<div class="header-main">
		<div class="container">
			<div class="header-main__content">
				<!-- Logo -->
				<div class="site-branding">
					<?php get_template_part( 'template-parts/header/header', 'logo' ); ?>
				</div><!-- .site-branding -->

				<!-- Main Navigation -->
				<nav id="site-navigation" class="main-navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'starter-flavor' ); ?>">
					<?php
					wp_nav_menu(
						array(
							'theme_location' => 'primary',
							'menu_id'        => 'primary-menu',
							'fallback_cb'    => 'wp_page_menu',
							'depth'          => 3,
						)
					);
					?>
				</nav><!-- #site-navigation -->

				<!-- Right side icons -->
				<div class="header-main__right">
					<?php
					// Search icon
					echo '<button class="header-search-toggle" aria-expanded="false" aria-label="' . esc_attr__( 'Open search', 'starter-flavor' ) . '">';
					echo '<span class="icon">🔍</span>';
					echo '</button>';

					// WooCommerce cart icon (if WooCommerce is active)
					if ( class_exists( 'WooCommerce' ) ) {
						echo '<a href="' . esc_url( wc_get_cart_url() ) . '" class="header-cart-link" aria-label="' . esc_attr__( 'View cart', 'starter-flavor' ) . '">';
						echo '<span class="icon">🛒</span>';
						$cart_count = WC()->cart->get_cart_contents_count();
						if ( $cart_count > 0 ) {
							echo '<span class="cart-count">' . intval( $cart_count ) . '</span>';
						}
						echo '</a>';
					}
					?>

					<!-- Mobile menu toggle -->
					<button id="mobile-menu-toggle" class="mobile-menu-toggle" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle mobile menu', 'starter-flavor' ); ?>">
						<span class="hamburger">
							<span class="hamburger__line"></span>
							<span class="hamburger__line"></span>
							<span class="hamburger__line"></span>
						</span>
					</button>
				</div><!-- .header-main__right -->
			</div><!-- .header-main__content -->
		</div><!-- .container -->
	</div><!-- .header-main -->

	<!-- Search overlay -->
	<div id="header-search" class="header-search" role="search">
		<div class="container">
			<div class="header-search__inner">
				<?php get_search_form(); ?>
				<button class="header-search-close" aria-label="<?php esc_attr_e( 'Close search', 'starter-flavor' ); ?>">
					<span class="icon">✕</span>
				</button>
			</div>
		</div>
	</div><!-- #header-search -->
</header><!-- #masthead -->
