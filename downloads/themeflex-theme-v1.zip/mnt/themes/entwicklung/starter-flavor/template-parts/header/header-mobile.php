<?php
/**
 * Template part for displaying the mobile menu
 *
 * @package Starter_Flavor
 */

?>

<div id="mobile-menu" class="mobile-menu" role="navigation" aria-label="<?php esc_attr_e( 'Mobile Menu', 'starter-flavor' ); ?>">
	<div class="mobile-menu__backdrop"></div>

	<div class="mobile-menu__panel">
		<div class="mobile-menu__header">
			<!-- Logo -->
			<div class="mobile-menu__logo">
				<?php get_template_part( 'template-parts/header/header', 'logo' ); ?>
			</div>

			<!-- Close button -->
			<button class="mobile-menu__close" aria-label="<?php esc_attr_e( 'Close menu', 'starter-flavor' ); ?>">
				<span class="icon">✕</span>
			</button>
		</div><!-- .mobile-menu__header -->

		<div class="mobile-menu__content">
			<!-- Search form -->
			<div class="mobile-menu__search">
				<?php get_search_form(); ?>
			</div>

			<!-- Navigation -->
			<nav class="mobile-navigation" aria-label="<?php esc_attr_e( 'Mobile Navigation', 'starter-flavor' ); ?>">
				<?php
				// Try mobile menu first, fallback to main menu
				$menu_exist = wp_get_nav_menu_object( 'mobile' );

				if ( $menu_exist ) {
					wp_nav_menu(
						array(
							'theme_location' => 'mobile',
							'menu_id'        => 'mobile-menu-nav',
							'fallback_cb'    => false,
							'depth'          => 3,
						)
					);
				} else {
					wp_nav_menu(
						array(
							'theme_location' => 'primary',
							'menu_id'        => 'mobile-menu-nav',
							'fallback_cb'    => false,
							'depth'          => 3,
						)
					);
				}
				?>
			</nav><!-- .mobile-navigation -->

			<!-- Social links -->
			<?php
			$social_links = get_theme_mod( 'starter_flavor_social_links', array() );
			if ( ! empty( $social_links ) ) {
				echo '<div class="mobile-menu__socials">';
				echo '<h3 class="mobile-menu__title">' . esc_html__( 'Follow us', 'starter-flavor' ) . '</h3>';
				echo '<div class="social-links">';
				foreach ( $social_links as $link ) {
					echo '<a href="' . esc_url( $link['url'] ) . '" class="social-link" aria-label="' . esc_attr( $link['label'] ) . '" target="_blank" rel="noopener noreferrer">';
					echo esc_html( $link['label'] );
					echo '</a>';
				}
				echo '</div>';
				echo '</div>';
			}
			?>
		</div><!-- .mobile-menu__content -->

		<div class="mobile-menu__footer">
			<?php
			$phone = get_theme_mod( 'starter_flavor_topbar_phone' );
			$email = get_theme_mod( 'starter_flavor_topbar_email' );

			if ( ! empty( $phone ) || ! empty( $email ) ) {
				echo '<div class="mobile-menu__contact">';
				if ( ! empty( $phone ) ) {
					echo '<a href="tel:' . esc_attr( $phone ) . '" class="mobile-menu__contact-link">';
					echo esc_html( $phone );
					echo '</a>';
				}
				if ( ! empty( $email ) ) {
					echo '<a href="mailto:' . esc_attr( $email ) . '" class="mobile-menu__contact-link">';
					echo esc_html( $email );
					echo '</a>';
				}
				echo '</div>';
			}
			?>
		</div><!-- .mobile-menu__footer -->
	</div><!-- .mobile-menu__panel -->
</div><!-- #mobile-menu -->
