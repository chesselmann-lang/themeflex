<?php
/**
 * Search Overlay Component
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

Starter_Flavor_Header_Advanced::render_search_overlay();
