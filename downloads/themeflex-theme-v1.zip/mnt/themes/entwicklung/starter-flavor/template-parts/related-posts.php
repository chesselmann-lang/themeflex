<?php
/**
 * Template part for displaying related posts
 *
 * @package Starter_Flavor
 * @since 1.0.0
 *
 * @var array $args The template arguments.
 */

if ( ! isset( $args ) ) {
	$args = array();
}

$defaults = array(
	'enabled'  => true,
	'count'    => 3,
	'columns'  => 3,
	'style'    => 'grid',
	'title'    => esc_html__( 'Related Posts', 'starter-flavor' ),
);

$settings = wp_parse_args( $args, $defaults );

if ( ! $settings['enabled'] ) {
	return;
}

?>

<section class="related-posts-section related-posts-<?php echo esc_attr( $settings['style'] ); ?>">
	<div class="container">
		<h2 class="section-title"><?php echo esc_html( $settings['title'] ); ?></h2>

		<?php
		/**
		 * Related Posts Query
		 */
		$post_id = get_the_ID();
		$categories = wp_get_post_categories( $post_id );
		$tags = wp_get_post_tags( $post_id, array( 'fields' => 'ids' ) );
		$author_id = get_post_field( 'post_author', $post_id );

		$related_args = array(
			'post_type'      => 'post',
			'posts_per_page' => $settings['count'],
			'post__not_in'   => array( $post_id ),
			'orderby'        => 'date',
			'order'          => 'DESC',
		);

		$tax_query = array();

		if ( ! empty( $categories ) ) {
			$tax_query[] = array(
				'taxonomy' => 'category',
				'field'    => 'term_id',
				'terms'    => $categories,
			);
		}

		if ( ! empty( $tags ) ) {
			$tax_query[] = array(
				'taxonomy' => 'post_tag',
				'field'    => 'term_id',
				'terms'    => $tags,
			);
		}

		if ( ! empty( $tax_query ) ) {
			$tax_query['relation'] = 'OR';
			$related_args['tax_query'] = $tax_query;
		}

		$related_query = new WP_Query( $related_args );

		if ( $related_query->have_posts() ) {
			$col_class = 'col-md-' . ( 12 / $settings['columns'] );

			if ( 'grid' === $settings['style'] ) {
				?>
				<div class="related-posts-grid row">
					<?php
					while ( $related_query->have_posts() ) {
						$related_query->the_post();
						?>
						<div class="related-post-item <?php echo esc_attr( $col_class ); ?>">
							<article class="related-post-card">
								<?php if ( has_post_thumbnail() ) : ?>
									<div class="related-post-thumbnail">
										<a href="<?php the_permalink(); ?>" rel="bookmark">
											<img
												class="lazy-load"
												src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 300'%3E%3C/svg%3E"
												data-src="<?php echo esc_attr( get_the_post_thumbnail_url( get_the_ID(), 'medium' ) ); ?>"
												alt="<?php the_title_attribute(); ?>" />
											<noscript>
												<?php the_post_thumbnail( 'medium' ); ?>
											</noscript>
										</a>
									</div>
								<?php endif; ?>

								<div class="related-post-content">
									<?php
									$categories = get_the_category();
									if ( ! empty( $categories ) ) {
										?>
										<div class="related-post-categories">
											<?php
											foreach ( array_slice( $categories, 0, 1 ) as $category ) {
												?>
												<a href="<?php echo esc_url( get_category_link( $category ) ); ?>" class="category-badge">
													<?php echo esc_html( $category->name ); ?>
												</a>
												<?php
											}
											?>
										</div>
										<?php
									}
									?>

									<h3 class="related-post-title">
										<a href="<?php the_permalink(); ?>" rel="bookmark">
											<?php the_title(); ?>
										</a>
									</h3>

									<div class="related-post-meta">
										<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>" class="related-post-date">
											<?php echo esc_html( get_the_date() ); ?>
										</time>
									</div>
								</div>
							</article>
						</div>
						<?php
					}
					?>
				</div>
				<?php
			} else {
				// Horizontal list style
				?>
				<div class="related-posts-list">
					<?php
					while ( $related_query->have_posts() ) {
						$related_query->the_post();
						?>
						<article class="related-post-item-horizontal">
							<?php if ( has_post_thumbnail() ) : ?>
								<div class="related-post-thumbnail-horizontal">
									<a href="<?php the_permalink(); ?>" rel="bookmark">
										<img
											class="lazy-load"
											src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 150 150'%3E%3C/svg%3E"
											data-src="<?php echo esc_attr( get_the_post_thumbnail_url( get_the_ID(), 'thumbnail' ) ); ?>"
											alt="<?php the_title_attribute(); ?>" />
										<noscript>
											<?php the_post_thumbnail( 'thumbnail' ); ?>
										</noscript>
									</a>
								</div>
							<?php endif; ?>

							<div class="related-post-content-horizontal">
								<h3 class="related-post-title-horizontal">
									<a href="<?php the_permalink(); ?>" rel="bookmark">
										<?php the_title(); ?>
									</a>
								</h3>

								<div class="related-post-meta-horizontal">
									<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>" class="related-post-date">
										<?php echo esc_html( get_the_date() ); ?>
									</time>
								</div>
							</div>
						</article>
						<?php
					}
					?>
				</div>
				<?php
			}
		}

		wp_reset_postdata();
		?>
	</div>
</section>
