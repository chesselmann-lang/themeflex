<?php
/**
 * Single post layout style 1 - Classic
 *
 * Featured image above title, sidebar right
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

?>

<div class="single-post-container single-post-style-1">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 main-content">
				<article id="post-<?php the_ID(); ?>" <?php post_class( 'single-post' ); ?>>
					<?php if ( has_post_thumbnail() ) : ?>
						<div class="post-featured-image">
							<?php the_post_thumbnail( 'full' ); ?>
						</div>
					<?php endif; ?>

					<header class="post-header">
						<h1 class="post-title"><?php the_title(); ?></h1>

						<div class="post-meta">
							<span class="post-date">
								<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
									<?php echo esc_html( get_the_date() ); ?>
								</time>
							</span>
							<span class="post-author">
								<?php esc_html_e( 'by', 'starter-flavor' ); ?> <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php the_author(); ?></a>
							</span>
							<?php if ( has_category() ) : ?>
								<span class="post-categories">
									<?php the_category( ', ' ); ?>
								</span>
							<?php endif; ?>
						</div>
					</header>

					<div class="post-content">
						<?php
						the_content();

						wp_link_pages( array(
							'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'starter-flavor' ),
							'after'  => '</div>',
						) );
						?>
					</div>

					<?php if ( has_tag() ) : ?>
						<div class="post-tags">
							<?php the_tags( '<span class="tag-label">' . esc_html__( 'Tags: ', 'starter-flavor' ) . '</span>', ', ' ); ?>
						</div>
					<?php endif; ?>
				</article>

				<?php
				// Post navigation
				the_post_navigation( array(
					'prev_text' => '<span class="nav-subtitle">' . esc_html__( 'Previous Post:', 'starter-flavor' ) . '</span> <span class="nav-title">%title</span>',
					'next_text' => '<span class="nav-subtitle">' . esc_html__( 'Next Post:', 'starter-flavor' ) . '</span> <span class="nav-title">%title</span>',
				) );
				?>

				<?php
				// Related posts
				$related_posts = starter_flavor_related_posts();
				$related_posts->display();
				?>

				<?php
				// Author bio
				get_template_part( 'template-parts/author-bio' );
				?>

				<?php
				// Comments
				if ( comments_open() || get_comments_number() ) {
					comments_template();
				}
				?>
			</div>

			<aside class="col-lg-4 sidebar">
				<?php
				get_sidebar();
				?>
			</aside>
		</div>
	</div>
</div>
