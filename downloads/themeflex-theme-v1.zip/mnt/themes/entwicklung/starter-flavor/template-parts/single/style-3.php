<?php
/**
 * Single post layout style 3 - Minimal
 *
 * No featured image, centered content, large typography, distraction-free
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

?>

<div class="single-post-container single-post-style-3">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 offset-lg-2 main-content">
				<article id="post-<?php the_ID(); ?>" <?php post_class( 'single-post' ); ?>>
					<header class="post-header">
						<h1 class="post-title"><?php the_title(); ?></h1>

						<div class="post-meta post-meta-minimal">
							<span class="post-date">
								<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
									<?php echo esc_html( get_the_date( 'F j, Y' ) ); ?>
								</time>
							</span>
							<span class="post-author">
								<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php the_author(); ?></a>
							</span>
						</div>
					</header>

					<div class="post-content post-content-minimal">
						<?php
						the_content();

						wp_link_pages( array(
							'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'starter-flavor' ),
							'after'  => '</div>',
						) );
						?>
					</div>

					<?php if ( has_category() || has_tag() ) : ?>
						<div class="post-taxonomies">
							<?php if ( has_category() ) : ?>
								<div class="post-categories">
									<?php the_category( ', ' ); ?>
								</div>
							<?php endif; ?>

							<?php if ( has_tag() ) : ?>
								<div class="post-tags">
									<?php the_tags( '', ', ' ); ?>
								</div>
							<?php endif; ?>
						</div>
					<?php endif; ?>
				</article>

				<?php
				// Post navigation
				the_post_navigation( array(
					'prev_text' => '<span class="nav-subtitle">' . esc_html__( 'Previous', 'starter-flavor' ) . '</span> <span class="nav-title">%title</span>',
					'next_text' => '<span class="nav-subtitle">' . esc_html__( 'Next', 'starter-flavor' ) . '</span> <span class="nav-title">%title</span>',
				) );
				?>

				<?php
				// Related posts
				$related_posts = starter_flavor_related_posts();
				$related_posts->display();
				?>

				<?php
				// Author bio
				get_template_part( 'template-parts/author-bio' );
				?>

				<?php
				// Comments
				if ( comments_open() || get_comments_number() ) {
					comments_template();
				}
				?>
			</div>
		</div>
	</div>
</div>
