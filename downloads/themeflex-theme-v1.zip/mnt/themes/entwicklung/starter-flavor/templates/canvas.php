<?php
/**
 * Template Name: Starter Flavor Canvas
 * Template Post Type: page
 *
 * Canvas template for page builders like Elementor
 * Minimal structure - only wp_head and wp_footer
 *
 * @package Starter_Flavor
 */

// No header/footer - only essential WordPress hooks
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class( 'canvas-template' ); ?>>
	<?php wp_body_open(); ?>

	<div id="page" class="site">
		<main id="primary" class="site-main">
			<?php
			while ( have_posts() ) {
				the_post();
				the_content();
			}
			?>
		</main><!-- #primary -->
	</div><!-- #page -->

	<?php wp_footer(); ?>
</body>
</html>
