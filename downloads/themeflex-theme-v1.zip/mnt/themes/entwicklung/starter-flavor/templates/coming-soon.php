<?php
/**
 * Coming Soon / Maintenance Mode Page Template
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Check if maintenance mode is enabled and user is not logged in
$maintenance_enabled = get_theme_mod( 'sf_maintenance_mode_enabled', false );
$current_user = wp_get_current_user();

// Allow logged-in admins to bypass
if ( $maintenance_enabled && ! ( $current_user->exists() && user_can( $current_user, 'manage_options' ) ) ) {
	// Set 503 status for search engines
	status_header( 503 );
	header( 'Retry-After: 3600' );
}

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
	<style>
		* {
			margin: 0;
			padding: 0;
			box-sizing: border-box;
		}

		html,
		body {
			height: 100%;
			width: 100%;
		}

		body {
			display: flex;
			align-items: center;
			justify-content: center;
			background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
			font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
			color: #333;
		}

		.coming-soon-container {
			text-align: center;
			max-width: 600px;
			padding: 40px;
			background: white;
			border-radius: 10px;
			box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
		}

		.coming-soon-logo {
			margin-bottom: 30px;
		}

		.coming-soon-logo img {
			max-width: 150px;
			height: auto;
		}

		.coming-soon-content h1 {
			font-size: 48px;
			margin-bottom: 15px;
			color: #333;
			font-weight: 700;
		}

		.coming-soon-content p {
			font-size: 18px;
			color: #666;
			margin-bottom: 40px;
			line-height: 1.6;
		}

		.countdown {
			display: flex;
			justify-content: center;
			gap: 20px;
			margin: 40px 0;
		}

		.countdown-item {
			flex: 0 0 80px;
		}

		.countdown-number {
			font-size: 36px;
			font-weight: bold;
			color: #667eea;
			display: block;
			margin-bottom: 5px;
		}

		.countdown-label {
			font-size: 12px;
			color: #999;
			text-transform: uppercase;
			letter-spacing: 1px;
		}

		.coming-soon-form {
			margin: 40px 0;
		}

		.coming-soon-form input {
			width: 100%;
			padding: 15px;
			font-size: 16px;
			border: 2px solid #e0e0e0;
			border-radius: 5px;
			margin-bottom: 15px;
			transition: border-color 0.3s;
		}

		.coming-soon-form input:focus {
			outline: none;
			border-color: #667eea;
		}

		.coming-soon-form button {
			width: 100%;
			padding: 15px;
			font-size: 16px;
			font-weight: 600;
			background: #667eea;
			color: white;
			border: none;
			border-radius: 5px;
			cursor: pointer;
			transition: background 0.3s;
		}

		.coming-soon-form button:hover {
			background: #5568d3;
		}

		.coming-soon-social {
			margin-top: 40px;
			padding-top: 30px;
			border-top: 1px solid #e0e0e0;
		}

		.coming-soon-social p {
			font-size: 14px;
			color: #999;
			margin-bottom: 15px;
		}

		.social-links {
			display: flex;
			justify-content: center;
			gap: 15px;
		}

		.social-links a {
			display: inline-flex;
			align-items: center;
			justify-content: center;
			width: 40px;
			height: 40px;
			background: #f0f0f0;
			color: #667eea;
			border-radius: 50%;
			text-decoration: none;
			transition: all 0.3s;
			font-size: 18px;
		}

		.social-links a:hover {
			background: #667eea;
			color: white;
			transform: translateY(-3px);
		}

		.coming-soon-footer {
			margin-top: 40px;
			padding-top: 30px;
			border-top: 1px solid #e0e0e0;
			font-size: 12px;
			color: #999;
		}

		@media (max-width: 600px) {
			.coming-soon-container {
				margin: 20px;
				padding: 30px 20px;
			}

			.coming-soon-content h1 {
				font-size: 32px;
			}

			.coming-soon-content p {
				font-size: 16px;
			}

			.countdown {
				gap: 10px;
			}

			.countdown-item {
				flex: 0 0 60px;
			}

			.countdown-number {
				font-size: 24px;
			}
		}

		.admin-bar-notice {
			background: #fff8e5;
			color: #856404;
			padding: 10px;
			text-align: center;
			font-size: 13px;
			border-bottom: 1px solid #ffeeba;
		}
	</style>
