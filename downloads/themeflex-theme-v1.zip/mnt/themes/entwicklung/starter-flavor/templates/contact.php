<?php
/**
 * Contact Page Template
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<div class="sf-contact-page">
	<div class="sf-page-header">
		<h1><?php the_title(); ?></h1>
	</div>

	<div class="sf-contact-container">
		<div class="sf-contact-info">
			<h3><?php esc_html_e( 'Contact Information', 'starter-flavor' ); ?></h3>

			<?php
			$phone = get_theme_mod( 'sf_contact_phone' );
			$email = get_theme_mod( 'sf_contact_email' );
			$address = get_theme_mod( 'sf_contact_address' );
			$hours = get_theme_mod( 'sf_contact_hours' );
			?>

			<?php if ( $phone ) : ?>
				<div class="sf-contact-item">
					<h4><?php esc_html_e( 'Phone', 'starter-flavor' ); ?></h4>
					<p><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $phone ) ); ?>">
						<?php echo esc_html( $phone ); ?>
					</a></p>
				</div>
			<?php endif; ?>

			<?php if ( $email ) : ?>
				<div class="sf-contact-item">
					<h4><?php esc_html_e( 'Email', 'starter-flavor' ); ?></h4>
					<p><a href="mailto:<?php echo esc_attr( $email ); ?>">
						<?php echo esc_html( $email ); ?>
					</a></p>
				</div>
			<?php endif; ?>

			<?php if ( $address ) : ?>
				<div class="sf-contact-item">
					<h4><?php esc_html_e( 'Address', 'starter-flavor' ); ?></h4>
					<p><?php echo wp_kses_post( nl2br( $address ) ); ?></p>
				</div>
			<?php endif; ?>

			<?php if ( $hours ) : ?>
				<div class="sf-contact-item">
					<h4><?php esc_html_e( 'Business Hours', 'starter-flavor' ); ?></h4>
					<p><?php echo wp_kses_post( nl2br( $hours ) ); ?></p>
				</div>
			<?php endif; ?>
		</div>

		<div class="sf-contact-form">
			<h3><?php esc_html_e( 'Send us a Message', 'starter-flavor' ); ?></h3>
			<?php
			// Display page content (can contain Contact Form 7 or other form)
			the_content();
			?>
		</div>

		<?php
		$map_embed = get_theme_mod( 'sf_contact_map_embed' );
		if ( $map_embed ) :
			?>
			<div class="sf-contact-map">
				<h3><?php esc_html_e( 'Location', 'starter-flavor' ); ?></h3>
				<div class="sf-map-container">
					<?php echo wp_kses_post( $map_embed ); ?>
				</div>
			</div>
		<?php endif; ?>
	</div>
</div>

<style>
	.sf-contact-page {
		padding: 60px 20px;
	}

	.sf-page-header {
		text-align: center;
		margin-bottom: 60px;
	}

	.sf-page-header h1 {
		font-size: 48px;
		margin-bottom: 15px;
	}

	.sf-contact-container {
		max-width: 1200px;
		margin: 0 auto;
		display: grid;
		grid-template-columns: 1fr 1fr;
		gap: 60px;
	}

	.sf-contact-info {
		background: #f9f9f9;
		padding: 40px;
		border-radius: 10px;
		height: fit-content;
	}

	.sf-contact-info h3 {
		font-size: 24px;
		margin-bottom: 30px;
		color: #333;
	}

	.sf-contact-item {
		margin-bottom: 30px;
	}

	.sf-contact-item h4 {
		font-size: 14px;
		color: #667eea;
		text-transform: uppercase;
		letter-spacing: 1px;
		margin-bottom: 8px;
		font-weight: 600;
	}

	.sf-contact-item p {
		color: #666;
		font-size: 16px;
		margin: 0;
	}

	.sf-contact-item a {
		color: #667eea;
		text-decoration: none;
	}

	.sf-contact-item a:hover {
		text-decoration: underline;
	}

	.sf-contact-form h3 {
		font-size: 24px;
		margin-bottom: 30px;
		color: #333;
	}

	.sf-contact-map {
		grid-column: 1 / -1;
		margin-top: 40px;
	}

	.sf-contact-map h3 {
		font-size: 24px;
		margin-bottom: 20px;
		color: #333;
	}

	.sf-map-container {
		border-radius: 10px;
		overflow: hidden;
		height: 400px;
	}

	.sf-map-container iframe {
		width: 100%;
		height: 100%;
		border: none;
	}

	@media (max-width: 768px) {
		.sf-contact-page {
			padding: 40px 15px;
		}

		.sf-page-header h1 {
			font-size: 32px;
		}

		.sf-contact-container {
			grid-template-columns: 1fr;
			gap: 40px;
		}

		.sf-map-container {
			height: 300px;
		}
	}
</style>

<?php
get_footer();
