<?php
/**
 * FAQ Page Template
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<div class="sf-faq-page">
	<div class="sf-page-header">
		<h1><?php the_title(); ?></h1>
		<?php if ( get_the_excerpt() ) : ?>
			<p class="sf-page-description"><?php the_excerpt(); ?></p>
		<?php endif; ?>
	</div>

	<div class="sf-faq-container">
		<?php
		// Get FAQ categories
		$categories = get_terms( array(
			'taxonomy'   => 'sf_faq_category',
			'hide_empty' => true,
		) );

		if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) :
			?>
			<div class="sf-faq-tabs">
				<?php foreach ( $categories as $category ) : ?>
					<div class="sf-faq-tab" data-category="<?php echo esc_attr( $category->term_id ); ?>">
						<h3><?php echo esc_html( $category->name ); ?></h3>
						<div class="sf-faq-items">
							<?php
							$faq_args = array(
								'post_type'      => 'sf_faq',
								'tax_query'      => array(
									array(
										'taxonomy' => 'sf_faq_category',
										'field'    => 'term_id',
										'terms'    => $category->term_id,
									),
								),
								'posts_per_page' => -1,
								'orderby'        => 'menu_order',
								'order'          => 'ASC',
							);

							$faq_query = new WP_Query( $faq_args );

							if ( $faq_query->have_posts() ) :
								while ( $faq_query->have_posts() ) :
									$faq_query->the_post();
									?>
									<div class="sf-faq-item">
										<h4 class="sf-faq-question"><?php the_title(); ?></h4>
										<div class="sf-faq-answer">
											<?php the_content(); ?>
										</div>
									</div>
									<?php
								endwhile;
								wp_reset_postdata();
							endif;
							?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		<?php
		else :
			// Fallback: Display FAQs from page content
			echo '<div class="sf-faq-content">';
			the_content();
			echo '</div>';
		endif;
		?>
	</div>

	<?php
	// Contact CTA
	$contact_title = get_theme_mod( 'sf_faq_contact_title', esc_html__( 'Didn\'t Find Your Answer?', 'starter-flavor' ) );
	$contact_text = get_theme_mod( 'sf_faq_contact_text', esc_html__( 'Get in touch with our support team.', 'starter-flavor' ) );
	$contact_button = get_theme_mod( 'sf_faq_contact_button', esc_html__( 'Contact Us', 'starter-flavor' ) );
	$contact_url = get_theme_mod( 'sf_faq_contact_url', '#' );

	if ( $contact_title ) :
		?>
		<div class="sf-faq-cta">
			<h2><?php echo esc_html( $contact_title ); ?></h2>
			<?php if ( $contact_text ) : ?>
				<p><?php echo esc_html( $contact_text ); ?></p>
			<?php endif; ?>
			<?php if ( $contact_button && $contact_url ) : ?>
				<a href="<?php echo esc_url( $contact_url ); ?>" class="button button-primary">
					<?php echo esc_html( $contact_button ); ?>
				</a>
			<?php endif; ?>
		</div>
	<?php endif; ?>
</div>

<style>
	.sf-faq-page {
		padding: 60px 20px;
	}

	.sf-page-header {
		text-align: center;
		margin-bottom: 60px;
	}

	.sf-page-header h1 {
		font-size: 48px;
		margin-bottom: 15px;
	}

	.sf-page-description {
		font-size: 18px;
		color: #666;
		max-width: 600px;
		margin: 0 auto;
	}

	.sf-faq-container {
		max-width: 800px;
		margin: 0 auto;
	}

	.sf-faq-tabs {
		display: grid;
		gap: 40px;
	}

	.sf-faq-tab h3 {
		font-size: 28px;
		margin-bottom: 20px;
		padding-bottom: 15px;
		border-bottom: 2px solid #667eea;
	}

	.sf-faq-items {
		display: grid;
		gap: 20px;
	}

	.sf-faq-item {
		background: #f9f9f9;
		padding: 20px;
		border-radius: 5px;
		transition: all 0.3s ease;
	}

	.sf-faq-item:hover {
		background: #f0f0f0;
		box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
	}

	.sf-faq-question {
		font-size: 18px;
		margin-bottom: 12px;
		cursor: pointer;
		color: #333;
	}

	.sf-faq-answer {
		color: #666;
		line-height: 1.6;
		display: block;
	}

	.sf-faq-cta {
		text-align: center;
		margin-top: 80px;
		padding: 60px;
		background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
		color: white;
		border-radius: 10px;
	}

	.sf-faq-cta h2 {
		font-size: 36px;
		margin-bottom: 15px;
	}

	.sf-faq-cta p {
		font-size: 18px;
		margin-bottom: 30px;
		opacity: 0.9;
	}

	.sf-faq-cta .button {
		background: white;
		color: #667eea;
	}

	.sf-faq-cta .button:hover {
		background: #f0f0f0;
	}

	@media (max-width: 768px) {
		.sf-faq-page {
			padding: 40px 15px;
		}

		.sf-page-header h1 {
			font-size: 32px;
		}

		.sf-faq-cta {
			padding: 40px 20px;
		}

		.sf-faq-cta h2 {
			font-size: 24px;
		}
	}
</style>

<?php
get_footer();
