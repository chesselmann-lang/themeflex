<?php
/**
 * Template Name: Full Width
 * Template Post Type: page
 *
 * Full width page template with no sidebar
 *
 * @package Starter_Flavor
 */

get_header();
?>

<main id="primary" class="site-main">
	<div class="container container--full-width">
		<?php
		while ( have_posts() ) {
			the_post();
			get_template_part( 'template-parts/content', 'page' );

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}
		}
		?>
	</div><!-- .container -->
</main><!-- #primary -->

<?php
get_footer();
?>
