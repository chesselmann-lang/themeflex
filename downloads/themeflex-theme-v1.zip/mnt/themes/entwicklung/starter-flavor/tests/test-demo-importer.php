<?php
/**
 * Tests for Demo Importer
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

/**
 * Test Demo Importer
 */
class Test_Demo_Importer extends PHPUnit\Framework\TestCase {

	/**
	 * Test demo importer class exists
	 */
	public function test_demo_importer_class_exists() {
		$file = STARTER_FLAVOR_THEME_DIR . '/includes/class-demo-importer.php';
		$this->assertFileExists( $file );

		if ( file_exists( $file ) ) {
			require_once $file;
			$this->assertTrue(
				class_exists( 'Starter_Flavor_Demo_Importer' ),
				'Demo importer class should exist'
			);
		}
	}

	/**
	 * Test elementor-templates directory exists
	 */
	public function test_templates_directory_exists() {
		$templates_dir = STARTER_FLAVOR_THEME_DIR . '/elementor-templates';
		$this->assertTrue(
			is_dir( $templates_dir ),
			'Elementor templates directory should exist'
		);
	}

	/**
	 * Test templates directory contains JSON files
	 */
	public function test_templates_json_files_exist() {
		$templates_dir = STARTER_FLAVOR_THEME_DIR . '/elementor-templates';
		$json_files = glob( $templates_dir . '/*.json' );

		$this->assertNotEmpty(
			$json_files,
			'Templates directory should contain JSON files'
		);
	}

	/**
	 * Test all JSON templates are valid JSON
	 */
	public function test_all_json_templates_valid() {
		$templates_dir = STARTER_FLAVOR_THEME_DIR . '/elementor-templates';
		$json_files = glob( $templates_dir . '/*.json' );

		foreach ( $json_files as $file ) {
			$content = file_get_contents( $file );
			$decoded = json_decode( $content, true );

			$this->assertIsArray(
				$decoded,
				"File " . basename( $file ) . " should be valid JSON"
			);
		}
	}

	/**
	 * Test all templates have required keys
	 */
	public function test_templates_have_required_keys() {
		$templates_dir = STARTER_FLAVOR_THEME_DIR . '/elementor-templates';
		$json_files = glob( $templates_dir . '/*.json' );

		$required_keys = array( 'title', 'type', 'content' );

		foreach ( $json_files as $file ) {
			$content = file_get_contents( $file );
			$template = json_decode( $content, true );

			foreach ( $required_keys as $key ) {
				$this->assertArrayHasKey(
					$key,
					$template,
					"File " . basename( $file ) . " should have '$key' key"
				);
			}
		}
	}

	/**
	 * Test templates have valid type values
	 */
	public function test_templates_have_valid_types() {
		$templates_dir = STARTER_FLAVOR_THEME_DIR . '/elementor-templates';
		$json_files = glob( $templates_dir . '/*.json' );

		$valid_types = array( 'page', 'section', 'template' );

		foreach ( $json_files as $file ) {
			$content = file_get_contents( $file );
			$template = json_decode( $content, true );

			$this->assertContains(
				$template['type'],
				$valid_types,
				"File " . basename( $file ) . " should have valid type"
			);
		}
	}

	/**
	 * Test templates have non-empty title
	 */
	public function test_templates_have_valid_title() {
		$templates_dir = STARTER_FLAVOR_THEME_DIR . '/elementor-templates';
		$json_files = glob( $templates_dir . '/*.json' );

		foreach ( $json_files as $file ) {
			$content = file_get_contents( $file );
			$template = json_decode( $content, true );

			$this->assertNotEmpty(
				$template['title'],
				"File " . basename( $file ) . " should have non-empty title"
			);

			$this->assertIsString(
				$template['title'],
				"File " . basename( $file ) . " title should be string"
			);
		}
	}

	/**
	 * Test templates have content array
	 */
	public function test_templates_have_content_array() {
		$templates_dir = STARTER_FLAVOR_THEME_DIR . '/elementor-templates';
		$json_files = glob( $templates_dir . '/*.json' );

		foreach ( $json_files as $file ) {
			$content = file_get_contents( $file );
			$template = json_decode( $content, true );

			$this->assertTrue(
				is_array( $template['content'] ) || is_string( $template['content'] ),
				"File " . basename( $file ) . " should have content array or string"
			);
		}
	}

	/**
	 * Test demo importer file is readable
	 */
	public function test_demo_importer_file_readable() {
		$file = STARTER_FLAVOR_THEME_DIR . '/includes/class-demo-importer.php';

		if ( file_exists( $file ) ) {
			$content = file_get_contents( $file );
			$this->assertNotEmpty( $content );

			// Should have demo categories
			$this->assertStringContainsString(
				'$categories',
				$content,
				'Demo importer should define categories'
			);
		}
	}

	/**
	 * Test category metadata structure
	 */
	public function test_category_structure() {
		$file = STARTER_FLAVOR_THEME_DIR . '/includes/class-demo-importer.php';

		if ( file_exists( $file ) ) {
			$content = file_get_contents( $file );

			// Check that categories are defined
			$this->assertMatchesRegularExpression(
				"/('|\")\w+-\w+('|\")\s*=>/",
				$content,
				'Demo importer should have category slug => title mappings'
			);
		}
	}
}
