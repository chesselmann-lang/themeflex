<?php
/**
 * Tests for Elementor Widgets
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

/**
 * Test Elementor Widgets
 */
class Test_Elementor_Widgets extends PHPUnit\Framework\TestCase {

	/**
	 * Test elementor-widgets directory exists
	 */
	public function test_elementor_widgets_directory_exists() {
		$widgets_dir = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets';
		$this->assertTrue(
			is_dir( $widgets_dir ),
			'Elementor widgets directory should exist'
		);
	}

	/**
	 * Test widget files exist
	 */
	public function test_widget_files_exist() {
		$widgets_dir = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets';

		$expected_widgets = array(
			'class-image-gallery.php',
			'class-blog-carousel.php',
			'class-slider.php',
			'class-progress-bar.php',
			'class-countdown.php',
			'class-social-icons.php',
		);

		foreach ( $expected_widgets as $widget_file ) {
			$path = $widgets_dir . '/' . $widget_file;
			$this->assertFileExists(
				$path,
				"Widget file $widget_file should exist"
			);
		}
	}

	/**
	 * Test widget files contain class definitions
	 */
	public function test_widget_files_have_classes() {
		$widgets_dir = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets';

		$widget_mappings = array(
			'class-image-gallery.php' => 'Starter_Flavor_Image_Gallery_Widget',
			'class-blog-carousel.php' => 'Starter_Flavor_Blog_Carousel_Widget',
			'class-slider.php' => 'Starter_Flavor_Slider_Widget',
			'class-progress-bar.php' => 'Starter_Flavor_Progress_Bar_Widget',
			'class-countdown.php' => 'Starter_Flavor_Countdown_Widget',
			'class-social-icons.php' => 'Starter_Flavor_Social_Icons_Widget',
		);

		foreach ( $widget_mappings as $file => $class_name ) {
			$path = $widgets_dir . '/' . $file;
			if ( file_exists( $path ) ) {
				$content = file_get_contents( $path );
				$this->assertStringContainsString(
					'class ' . $class_name,
					$content,
					"File $file should contain class $class_name"
				);
			}
		}
	}

	/**
	 * Test widgets have required methods
	 */
	public function test_widgets_have_required_methods() {
		$widgets_dir = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets';

		$files = glob( $widgets_dir . '/class-*.php' );
		$required_methods = array(
			'get_name',
			'get_title',
			'get_icon',
			'register_controls',
			'render',
		);

		foreach ( $files as $file ) {
			$content = file_get_contents( $file );

			foreach ( $required_methods as $method ) {
				$method_pattern = 'function ' . $method . '|public function ' . $method;
				$this->assertMatchesRegularExpression(
					"/$method_pattern/",
					$content,
					"Widget file " . basename( $file ) . " should have $method method"
				);
			}
		}
	}

	/**
	 * Test widget names are properly prefixed
	 */
	public function test_widget_names_prefixed() {
		$widgets_dir = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets';
		$files = glob( $widgets_dir . '/class-*.php' );

		foreach ( $files as $file ) {
			$content = file_get_contents( $file );

			// Check get_name returns prefixed name
			if ( preg_match( "/get_name\(\)\s*\{[^}]*return\s+['\"]([^'\"]+)['\"]/" , $content, $matches ) ) {
				$widget_name = $matches[1];
				$this->assertStringStartsWith(
					'starter-flavor-',
					$widget_name,
					"Widget name in " . basename( $file ) . " should be prefixed with 'starter-flavor-'"
				);
			}
		}
	}

	/**
	 * Test elementor.php registration file exists
	 */
	public function test_elementor_registration_file() {
		$elementor_file = STARTER_FLAVOR_THEME_DIR . '/includes/elementor.php';
		$this->assertFileExists(
			$elementor_file,
			'Elementor registration file should exist'
		);
	}

	/**
	 * Test elementor.php contains widget registration
	 */
	public function test_elementor_registration_content() {
		$elementor_file = STARTER_FLAVOR_THEME_DIR . '/includes/elementor.php';
		$content = file_get_contents( $elementor_file );

		$this->assertStringContainsString(
			'elementor',
			$content,
			'Elementor file should reference Elementor plugin'
		);
	}

	/**
	 * Test widget assets exist
	 */
	public function test_widget_assets_exist() {
		$assets_dir = STARTER_FLAVOR_THEME_DIR . '/assets/elementor';

		if ( is_dir( $assets_dir ) ) {
			$this->assertTrue(
				file_exists( $assets_dir . '/css/elementor-widgets.css' ) ||
				file_exists( STARTER_FLAVOR_ASSETS_DIR . '/css/elementor-widgets.css' ),
				'Elementor widgets CSS should exist'
			);

			$this->assertTrue(
				file_exists( $assets_dir . '/js/elementor-widgets.js' ) ||
				file_exists( STARTER_FLAVOR_ASSETS_DIR . '/js/elementor-widgets.js' ),
				'Elementor widgets JS should exist'
			);
		}
	}

	/**
	 * Test widget class files have security checks
	 */
	public function test_widget_files_have_security_checks() {
		$widgets_dir = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets';
		$files = glob( $widgets_dir . '/class-*.php' );

		foreach ( $files as $file ) {
			$content = file_get_contents( $file );
			$this->assertStringContainsString(
				'ABSPATH',
				$content,
				"Widget file " . basename( $file ) . " should check ABSPATH"
			);
		}
	}
}
