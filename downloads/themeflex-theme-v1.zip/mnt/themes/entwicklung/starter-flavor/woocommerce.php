<?php
/**
 * WooCommerce Template
 *
 * Fallback template for WooCommerce pages when specific templates
 * are not available in the child theme.
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

get_header( 'shop' );

do_action( 'woocommerce_before_main_content' );

?>

	<?php
	if ( is_product() ) {
		woocommerce_template_single_product();
	} elseif ( is_cart() ) {
		woocommerce_cart();
	} elseif ( is_checkout() ) {
		woocommerce_checkout();
	} else {
		// Category, tag, and archive templates
		?>
		<header class="woocommerce-products-header">
			<?php
			if ( is_search() ) {
				echo '<h1 class="woocommerce-products-header__title page-title">';
				printf(
					esc_html__( 'Search Results for: %s', 'starter-flavor' ),
					'<span>' . get_search_query() . '</span>'
				);
				echo '</h1>';
			} else {
				do_action( 'woocommerce_archive_description' );
			}
			?>
		</header>

		<?php
		if ( woocommerce_product_loop() ) {
			do_action( 'woocommerce_before_shop_loop' );

			woocommerce_product_loop_start();

			if ( wc_get_loop_prop( 'total' ) ) {
				while ( have_posts() ) {
					the_post();
					do_action( 'woocommerce_shop_loop' );
					wc_get_template_part( 'content', 'product' );
				}
			}

			woocommerce_product_loop_end();

			do_action( 'woocommerce_after_shop_loop' );
		} else {
			do_action( 'woocommerce_no_products_found' );
		}
	}
	?>

<?php
do_action( 'woocommerce_after_main_content' );

do_action( 'woocommerce_sidebar' );

get_footer( 'shop' );
