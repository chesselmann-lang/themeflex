<?php
/**
 * Email Header — Starter Flavor WooCommerce override.
 * @package Starter_Flavor
 */
defined('ABSPATH') || exit;
$logo_id  = get_theme_mod('custom_logo');
$logo_url = $logo_id ? wp_get_attachment_image_url($logo_id, 'full') : '';
$primary  = '#FF5E2E';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=<?php bloginfo('charset'); ?>" />
    <meta name="viewport" content="width=device-width" />
    <title><?php echo esc_html(get_bloginfo('name','display')); ?></title>
</head>
<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0" style="background-color:#f0f2f5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Inter',sans-serif;padding:0;margin:0;">
    <table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">
        <tr><td align="center" valign="top" style="padding:40px 0 20px;">
            <!-- Header -->
            <table border="0" cellpadding="0" cellspacing="0" width="600" style="max-width:600px;">
                <tr><td align="center" style="padding:24px 32px;background:linear-gradient(135deg,#06021D,#1a1f29);border-radius:12px 12px 0 0;">
                    <?php if ($logo_url): ?>
                    <img src="<?php echo esc_url($logo_url); ?>" alt="<?php bloginfo('name'); ?>" style="max-height:48px;width:auto;" />
                    <?php else: ?>
                    <h1 style="margin:0;font-size:22px;font-weight:800;color:#fff;letter-spacing:-.5px;"><?php bloginfo('name'); ?></h1>
                    <?php endif; ?>
                </td></tr>
                <!-- Colored stripe -->
                <tr><td style="height:4px;background:linear-gradient(90deg,<?php echo $primary; ?>,#00D4FF);"></td></tr>
            </table>
            <!-- Content wrapper -->
            <table border="0" cellpadding="0" cellspacing="0" width="600" style="max-width:600px;background:#ffffff;border-radius:0 0 12px 12px;box-shadow:0 4px 24px rgba(0,0,0,.08);">
                <tr><td align="center" valign="top" style="padding:40px 32px;">
