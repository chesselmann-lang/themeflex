<?php
/**
 * Single Product Template — Starter Flavor
 * @package Starter_Flavor
 */
defined('ABSPATH') || exit;
get_header('shop');
?>
<main id="primary" class="site-main woocommerce" style="padding:60px 0;">
<div class="container" style="max-width:var(--sf-content-width,1290px);margin:0 auto;padding:0 24px;">
    <?php while (have_posts()): the_post(); ?>
    <?php wc_breadcrumb(); ?>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:64px;margin-top:32px;align-items:start;" class="sf-product-layout">
        <!-- Gallery -->
        <div class="sf-product-gallery" style="position:sticky;top:32px;">
            <?php do_action('woocommerce_before_single_product_summary'); ?>
        </div>
        <!-- Details -->
        <div class="summary entry-summary">
            <?php do_action('woocommerce_single_product_summary'); ?>
        </div>
    </div>
    <?php do_action('woocommerce_after_single_product_summary'); ?>
    <?php endwhile; ?>
</div>
</main>
<?php get_footer('shop'); ?>
