<?php
/**
 * Single Product Tabs — Starter Flavor override.
 * @package Starter_Flavor
 */
defined('ABSPATH') || exit;
$product_tabs = apply_filters('woocommerce_product_tabs', []);
if (empty($product_tabs)) return;
$first = array_key_first($product_tabs);
?>
<div class="woocommerce-tabs sf-product-tabs">
    <ul class="sf-tabs-nav-list" role="tablist" style="display:flex;gap:0;list-style:none;padding:0;margin:0 0 0;border-bottom:2px solid var(--sf-border,#e5e7eb);">
        <?php foreach ($product_tabs as $key => $product_tab): $is_first = $key === $first; ?>
        <li role="presentation" style="margin-bottom:-2px;">
            <a href="#tab-<?php echo esc_attr($key); ?>" role="tab"
               class="sf-product-tab-link<?php echo $is_first?' active':''; ?>"
               id="tab-title-<?php echo esc_attr($key); ?>"
               aria-controls="tab-<?php echo esc_attr($key); ?>"
               aria-selected="<?php echo $is_first?'true':'false'; ?>"
               style="display:block;padding:12px 24px;color:<?php echo $is_first?'var(--sf-color-primary,#FF5E2E)':'var(--sf-meta,#94a3b8)'; ?>;font-weight:600;font-size:14px;text-decoration:none;border-bottom:2px solid <?php echo $is_first?'var(--sf-color-primary,#FF5E2E)':'transparent'; ?>;transition:all .2s;">
                <?php echo apply_filters('woocommerce_product_'.$key.'_tab_title', esc_html($product_tab['title']), $key); ?>
            </a>
        </li>
        <?php endforeach; ?>
    </ul>
    <?php foreach ($product_tabs as $key => $product_tab): $is_first = $key === $first; ?>
    <div class="woocommerce-Tabs-panel woocommerce-Tabs-panel--<?php echo esc_attr($key); ?>"
         id="tab-<?php echo esc_attr($key); ?>" role="tabpanel"
         aria-labelledby="tab-title-<?php echo esc_attr($key); ?>"
         style="padding:28px 0;font-size:15px;line-height:1.8;color:var(--sf-text,#64748b);<?php echo !$is_first?'display:none':''; ?>"
         <?php echo !$is_first?'hidden':''; ?>>
        <?php if (!empty($product_tab['callback'])) call_user_func($product_tab['callback'], $key, $product_tab); ?>
    </div>
    <?php endforeach; ?>
</div>
<script>
document.querySelectorAll('.sf-product-tabs .sf-tabs-nav-list a').forEach(function(a){
    a.addEventListener('click',function(e){
        e.preventDefault();
        var tabs=a.closest('.sf-product-tabs');
        tabs.querySelectorAll('.sf-tabs-nav-list a').forEach(function(l){
            l.classList.remove('active');l.style.color='var(--sf-meta,#94a3b8)';l.style.borderBottomColor='transparent';
        });
        tabs.querySelectorAll('.woocommerce-Tabs-panel').forEach(function(p){p.style.display='none';p.setAttribute('hidden','');});
        a.classList.add('active');a.style.color='var(--sf-color-primary,#FF5E2E)';a.style.borderBottomColor='var(--sf-color-primary,#FF5E2E)';
        var panel=document.getElementById(a.getAttribute('href').replace('#',''));
        if(panel){panel.style.display='block';panel.removeAttribute('hidden');}
    });
});
</script>
