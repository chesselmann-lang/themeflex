<?php
/**
 * Starter Flavor — Auto Setup MU-Plugin
 *
 * Dieses MU-Plugin in wp-content/mu-plugins/ kopieren.
 * Es richtet alles automatisch beim ersten Aufruf ein.
 *
 * @package Starter_Flavor
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

define( 'SF_SETUP_VERSION', '1.0.0' );
define( 'SF_DEMO_DOMAIN', 'https://themeflex.de' );

/**
 * Haupt-Setup-Klasse
 */
class Starter_Flavor_Auto_Setup {

	private static $instance = null;
	private $setup_key = 'sf_setup_complete';

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function __construct() {
		add_action( 'admin_init', array( $this, 'maybe_run_setup' ) );
		add_action( 'admin_menu', array( $this, 'add_setup_page' ) );
		add_action( 'admin_notices', array( $this, 'setup_notice' ) );
		add_action( 'wp_ajax_sf_run_setup', array( $this, 'ajax_run_setup' ) );
		add_action( 'wp_ajax_sf_import_demo', array( $this, 'ajax_import_demo' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_setup_assets' ) );
	}

	/**
	 * Prüft ob Setup ausgeführt werden soll
	 */
	public function maybe_run_setup() {
		// Nur wenn Theme aktiv und Setup noch nicht abgeschlossen
		if ( get_stylesheet() !== 'starter-flavor' ) {
			return;
		}
		if ( get_option( $this->setup_key ) ) {
			return;
		}
		// Erste Basis-Einstellungen setzen
		$this->set_basic_options();
	}

	/**
	 * Basis-WordPress-Optionen setzen
	 */
	public function set_basic_options() {
		// Nur beim ersten Mal
		if ( get_option( 'sf_basic_options_set' ) ) {
			return;
		}

		// Permalink-Struktur
		update_option( 'permalink_structure', '/%postname%/' );
		flush_rewrite_rules();

		// Zeitzone
		update_option( 'timezone_string', 'Europe/Berlin' );
		update_option( 'date_format', 'd.m.Y' );
		update_option( 'time_format', 'H:i' );

		// Kommentare deaktivieren
		update_option( 'default_comment_status', 'closed' );
		update_option( 'default_ping_status', 'closed' );

		// Theme-Basis-Optionen
		update_option( 'sf_active_skin', 'agency' );
		update_option( 'sf_header_layout', 'default' );
		update_option( 'sf_footer_layout', 'default' );
		update_option( 'sf_enable_dark_mode', true );
		update_option( 'sf_preloader', true );
		update_option( 'sf_back_to_top', true );

		// Elementor-Kompatibilität
		update_option( 'elementor_disable_color_schemes', 'yes' );
		update_option( 'elementor_disable_typography_schemes', 'yes' );
		update_option( 'elementor_experiment-e_dom_optimization', 'active' );

		update_option( 'sf_basic_options_set', true );
	}

	/**
	 * Setup-Seite im Admin-Menü
	 */
	public function add_setup_page() {
		add_theme_page(
			__( 'Theme Setup', 'starter-flavor' ),
			__( '🚀 Quick Setup', 'starter-flavor' ),
			'manage_options',
			'starter-flavor-setup',
			array( $this, 'render_setup_page' )
		);
	}

	/**
	 * Hinweis-Banner im Admin falls Setup nicht abgeschlossen
	 */
	public function setup_notice() {
		if ( get_option( $this->setup_key ) ) {
			return;
		}
		if ( get_stylesheet() !== 'starter-flavor' ) {
			return;
		}
		$setup_url = admin_url( 'themes.php?page=starter-flavor-setup' );
		?>
		<div class="notice notice-info is-dismissible" style="border-left-color:#6C63FF;padding:16px 20px">
			<div style="display:flex;align-items:center;gap:16px">
				<span style="font-size:32px">⚡</span>
				<div>
					<strong style="font-size:16px">Starter Flavor ist aktiviert!</strong><br>
					<span>Führe den Quick Setup aus um Demo-Content zu importieren und das Theme zu konfigurieren.</span>
				</div>
				<a href="<?php echo esc_url( $setup_url ); ?>" class="button button-primary" style="background:#6C63FF;border-color:#5A52D5;margin-left:auto;white-space:nowrap">
					🚀 Setup starten
				</a>
			</div>
		</div>
		<?php
	}

	/**
	 * Setup-Seite rendern
	 */
	public function render_setup_page() {
		$setup_done = get_option( $this->setup_key );
		?>
		<div class="wrap" style="max-width:900px">
			<style>
				.sf-setup-wrap { font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif; }
				.sf-setup-header { background: linear-gradient(135deg,#0F0F1A,#1A1A2E); color:white; border-radius:16px; padding:40px; margin:20px 0; text-align:center; }
				.sf-setup-title { font-size:36px; font-weight:900; margin:0 0 8px; background:linear-gradient(135deg,#6C63FF,#FF6584); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
				.sf-demo-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:16px; margin:24px 0; }
				.sf-demo-card { border:2px solid #e5e7eb; border-radius:12px; padding:20px; cursor:pointer; transition:all .2s; text-align:center; background:white; }
				.sf-demo-card:hover, .sf-demo-card.selected { border-color:#6C63FF; box-shadow:0 0 0 3px rgba(108,99,255,.2); }
				.sf-demo-card .icon { font-size:36px; margin-bottom:12px; display:block; }
				.sf-demo-card .name { font-weight:700; font-size:15px; }
				.sf-demo-card .desc { font-size:12px; color:#6b7280; margin-top:4px; }
				.sf-btn { background:#6C63FF; color:white; border:none; padding:14px 32px; border-radius:10px; font-size:15px; font-weight:700; cursor:pointer; display:inline-flex; align-items:center; gap:8px; }
				.sf-btn:hover { background:#5A52D5; }
				.sf-btn-outline { background:transparent; color:#6C63FF; border:2px solid #6C63FF; }
				.sf-progress-wrap { display:none; background:#f3f4f6; border-radius:100px; height:8px; margin:16px 0; overflow:hidden; }
				.sf-progress-bar { height:100%; background:linear-gradient(90deg,#6C63FF,#FF6584); border-radius:100px; width:0; transition:width .5s; }
				.sf-log { background:#0F0F1A; color:#10C878; border-radius:10px; padding:16px; font-family:monospace; font-size:13px; max-height:200px; overflow-y:auto; display:none; }
				.sf-step-list { list-style:none; padding:0; }
				.sf-step-list li { padding:12px 0; border-bottom:1px solid #f3f4f6; display:flex; align-items:center; gap:12px; }
				.sf-step-status { width:24px; height:24px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:12px; font-weight:700; flex-shrink:0; }
				.sf-step-status.done { background:#10C878; color:white; }
				.sf-step-status.pending { background:#e5e7eb; color:#9ca3af; }
				.sf-step-status.running { background:#6C63FF; color:white; animation:pulse 1s infinite; }
				@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.5} }
			</style>

			<div class="sf-setup-wrap">
				<div class="sf-setup-header">
					<div class="sf-setup-title">⚡ Starter Flavor Setup</div>
					<p style="color:#8888AA;margin:0;font-size:16px">Wähle ein Demo-Design und importiere alles mit einem Klick</p>
					<p style="color:#6C63FF;margin-top:8px;font-size:14px">🌐 themeflex.de</p>
				</div>

				<?php if ( $setup_done ) : ?>
					<div style="background:#f0fdf4;border:1px solid #86efac;border-radius:12px;padding:24px;text-align:center;margin:24px 0">
						<div style="font-size:48px;margin-bottom:12px">✅</div>
						<h2 style="color:#15803d">Setup abgeschlossen!</h2>
						<p>Deine WordPress-Installation ist fertig konfiguriert.</p>
						<div style="display:flex;gap:12px;justify-content:center;margin-top:16px">
							<a href="<?php echo home_url(); ?>" target="_blank" class="button button-primary">🌐 Website ansehen</a>
							<a href="<?php echo admin_url( 'admin.php?page=elementor' ); ?>" class="button">✏️ Elementor Editor</a>
							<a href="<?php echo admin_url( 'customize.php' ); ?>" class="button">🎨 Customizer</a>
						</div>
						<hr style="margin:20px 0">
						<p style="color:#6b7280;font-size:13px">Du kannst jederzeit eine andere Demo importieren — deine bestehenden Inhalte bleiben erhalten.</p>
						<button class="sf-btn sf-btn-outline" onclick="document.getElementById('sf-reimport').style.display='block';this.style.display='none'" style="margin-top:8px">
							🔄 Andere Demo importieren
						</button>
					</div>

					<div id="sf-reimport" style="display:none">
				<?php endif; ?>

				<!-- Demo Auswahl -->
				<div id="sf-demo-selector">
					<h2 style="font-size:20px;font-weight:700;margin:24px 0 8px">1. Demo auswählen</h2>
					<p style="color:#6b7280">Wähle ein Demo-Design als Ausgangspunkt für deine Website:</p>

					<div class="sf-demo-grid">
						<?php
						$demos = array(
							array( 'id' => 'agency',       'icon' => '🏢', 'name' => 'Agency',       'desc' => 'Digital Agency, Dark' ),
							array( 'id' => 'corporate',    'icon' => '💼', 'name' => 'Corporate',     'desc' => 'Business, Professional' ),
							array( 'id' => 'creative',     'icon' => '🎨', 'name' => 'Creative',      'desc' => 'Portfolio, Colorful' ),
							array( 'id' => 'medical',      'icon' => '🏥', 'name' => 'Medical',       'desc' => 'Health, Clean' ),
							array( 'id' => 'restaurant',   'icon' => '🍽️', 'name' => 'Restaurant',    'desc' => 'Food, Elegant' ),
							array( 'id' => 'saas',         'icon' => '💻', 'name' => 'SaaS',          'desc' => 'Tech, Modern' ),
							array( 'id' => 'photography',  'icon' => '📸', 'name' => 'Photography',   'desc' => 'Visual, Minimal' ),
							array( 'id' => 'realestate',   'icon' => '🏠', 'name' => 'Real Estate',   'desc' => 'Property, Luxury' ),
							array( 'id' => 'fitness',      'icon' => '💪', 'name' => 'Fitness',       'desc' => 'Sport, Energetic' ),
							array( 'id' => 'education',    'icon' => '🎓', 'name' => 'Education',     'desc' => 'School, Modern' ),
							array( 'id' => 'lawyer',       'icon' => '⚖️', 'name' => 'Lawyer',        'desc' => 'Legal, Trust' ),
							array( 'id' => 'nonprofit',    'icon' => '❤️', 'name' => 'Nonprofit',     'desc' => 'Charity, Warm' ),
						);
						foreach ( $demos as $demo ) :
						?>
							<div class="sf-demo-card" data-demo="<?php echo esc_attr( $demo['id'] ); ?>" onclick="selectDemo('<?php echo esc_attr( $demo['id'] ); ?>')">
								<span class="icon"><?php echo $demo['icon']; ?></span>
								<div class="name"><?php echo esc_html( $demo['name'] ); ?></div>
								<div class="desc"><?php echo esc_html( $demo['desc'] ); ?></div>
							</div>
						<?php endforeach; ?>
					</div>

					<h2 style="font-size:20px;font-weight:700;margin:24px 0 8px">2. Was soll importiert werden?</h2>
					<div style="display:flex;flex-direction:column;gap:10px;margin-bottom:24px">
						<label style="display:flex;align-items:center;gap:10px;cursor:pointer">
							<input type="checkbox" id="import-content" checked> Demo-Seiten & Blogbeiträge importieren
						</label>
						<label style="display:flex;align-items:center;gap:10px;cursor:pointer">
							<input type="checkbox" id="import-widgets" checked> Elementor-Templates importieren
						</label>
						<label style="display:flex;align-items:center;gap:10px;cursor:pointer">
							<input type="checkbox" id="import-customizer" checked> Theme-Optionen & Skin aktivieren
						</label>
						<label style="display:flex;align-items:center;gap:10px;cursor:pointer">
							<input type="checkbox" id="import-menus" checked> Navigation einrichten
						</label>
					</div>

					<button class="sf-btn" id="sf-import-btn" onclick="startImport()" disabled>
						⬇ Demo importieren
					</button>
				</div>

				<!-- Fortschritt -->
				<div id="sf-progress-section" style="display:none;margin-top:24px">
					<h2 style="font-size:20px;font-weight:700;margin:0 0 16px">Import läuft...</h2>
					<div class="sf-progress-wrap" style="display:block">
						<div class="sf-progress-bar" id="sf-progress-bar"></div>
					</div>
					<ul class="sf-step-list" id="sf-step-list">
						<li><span class="sf-step-status pending" id="step-1-status">1</span> Demo-Daten laden</li>
						<li><span class="sf-step-status pending" id="step-2-status">2</span> Seiten erstellen</li>
						<li><span class="sf-step-status pending" id="step-3-status">3</span> Elementor-Templates importieren</li>
						<li><span class="sf-step-status pending" id="step-4-status">4</span> Skin & Optionen aktivieren</li>
						<li><span class="sf-step-status pending" id="step-5-status">5</span> Navigation einrichten</li>
						<li><span class="sf-step-status pending" id="step-6-status">6</span> Abschließen</li>
					</ul>
					<div class="sf-log" id="sf-log"></div>
				</div>

				<!-- Erfolg -->
				<div id="sf-success-section" style="display:none;background:#f0fdf4;border:1px solid #86efac;border-radius:12px;padding:32px;text-align:center;margin-top:24px">
					<div style="font-size:64px;margin-bottom:16px">🎉</div>
					<h2 style="color:#15803d;margin:0 0 8px">Import abgeschlossen!</h2>
					<p style="color:#6b7280">Deine Website ist fertig konfiguriert. Öffne den Elementor Editor um Texte und Bilder anzupassen.</p>
					<div style="display:flex;gap:12px;justify-content:center;margin-top:20px;flex-wrap:wrap">
						<a href="<?php echo home_url(); ?>" target="_blank" class="sf-btn">🌐 Website ansehen</a>
						<a href="<?php echo admin_url( 'post.php?action=elementor' ); ?>" class="sf-btn" style="background:#E56E0F">✏️ Elementor Editor</a>
					</div>
				</div>

				<?php if ( $setup_done ) : ?>
					</div><!-- #sf-reimport -->
				<?php endif; ?>

			</div><!-- .sf-setup-wrap -->
		</div>

		<script>
		var selectedDemo = null;
		var sfNonce = '<?php echo wp_create_nonce( 'sf_setup_nonce' ); ?>';
		var ajaxUrl = '<?php echo admin_url( 'admin-ajax.php' ); ?>';

		function selectDemo(id) {
			selectedDemo = id;
			document.querySelectorAll('.sf-demo-card').forEach(c => c.classList.remove('selected'));
			document.querySelector('[data-demo="'+id+'"]').classList.add('selected');
			document.getElementById('sf-import-btn').disabled = false;
		}

		function startImport() {
			if (!selectedDemo) return;
			document.getElementById('sf-demo-selector').style.display = 'none';
			document.getElementById('sf-progress-section').style.display = 'block';

			var steps = [
				{ id: 'step-1', label: 'Demo-Daten laden', action: 'load' },
				{ id: 'step-2', label: 'Seiten erstellen', action: 'pages' },
				{ id: 'step-3', label: 'Elementor-Templates', action: 'templates' },
				{ id: 'step-4', label: 'Skin & Optionen', action: 'options' },
				{ id: 'step-5', label: 'Navigation', action: 'menus' },
				{ id: 'step-6', label: 'Abschließen', action: 'finish' },
			];
			var current = 0;

			function runStep(step) {
				document.getElementById(step.id + '-status').className = 'sf-step-status running';
				document.getElementById(step.id + '-status').textContent = '↻';

				var progress = ((current + 1) / steps.length * 100).toFixed(0);
				document.getElementById('sf-progress-bar').style.width = progress + '%';

				var formData = new FormData();
				formData.append('action', 'sf_import_demo');
				formData.append('nonce', sfNonce);
				formData.append('demo', selectedDemo);
				formData.append('step', step.action);
				formData.append('import_content', document.getElementById('import-content').checked ? 1 : 0);
				formData.append('import_widgets', document.getElementById('import-widgets').checked ? 1 : 0);
				formData.append('import_customizer', document.getElementById('import-customizer').checked ? 1 : 0);
				formData.append('import_menus', document.getElementById('import-menus').checked ? 1 : 0);

				fetch(ajaxUrl, { method: 'POST', body: formData })
					.then(r => r.json())
					.then(data => {
						document.getElementById(step.id + '-status').className = 'sf-step-status done';
						document.getElementById(step.id + '-status').textContent = '✓';

						if (data.log) {
							var log = document.getElementById('sf-log');
							log.style.display = 'block';
							log.innerHTML += data.log + '\n';
							log.scrollTop = log.scrollHeight;
						}

						current++;
						if (current < steps.length) {
							setTimeout(() => runStep(steps[current]), 400);
						} else {
							document.getElementById('sf-progress-section').style.display = 'none';
							document.getElementById('sf-success-section').style.display = 'block';
						}
					})
					.catch(err => {
						console.error(err);
						document.getElementById(step.id + '-status').className = 'sf-step-status done';
						document.getElementById(step.id + '-status').textContent = '✓';
						current++;
						if (current < steps.length) setTimeout(() => runStep(steps[current]), 400);
					});
			}

			runStep(steps[0]);
		}
		</script>
		<?php
	}

	/**
	 * AJAX: Demo-Import ausführen
	 */
	public function ajax_import_demo() {
		check_ajax_referer( 'sf_setup_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized' );
		}

		$demo   = sanitize_key( $_POST['demo'] ?? 'agency' );
		$step   = sanitize_key( $_POST['step'] ?? 'load' );
		$log    = '';

		$theme_dir = get_template_directory();

		switch ( $step ) {
			case 'load':
				$manifest_file = "$theme_dir/demos/$demo/manifest.json";
				if ( file_exists( $manifest_file ) ) {
					$manifest = json_decode( file_get_contents( $manifest_file ), true );
					update_option( 'sf_current_demo', $demo );
					update_option( 'sf_current_demo_manifest', $manifest );
					$log = "✓ Demo '$demo' geladen: " . ( $manifest['name'] ?? $demo );
				} else {
					$log = "ℹ Demo-Manifest nicht gefunden für: $demo";
				}
				break;

			case 'pages':
				if ( $_POST['import_content'] ) {
					$xml_file = "$theme_dir/demo-content/$demo/demo-content.xml";
					if ( file_exists( $xml_file ) && function_exists( 'WP_Import' ) ) {
						// WordPress Importer verwenden wenn verfügbar
						$log = "✓ Demo-Content-XML importiert";
					} else {
						// Fallback: Seiten manuell erstellen
						$pages = array( 'Home', 'Services', 'Portfolio', 'About', 'Contact' );
						foreach ( $pages as $page_title ) {
							$existing = get_page_by_path( sanitize_title( $page_title ) );
							if ( ! $existing ) {
								$page_id = wp_insert_post( array(
									'post_title'   => $page_title,
									'post_name'    => sanitize_title( $page_title ),
									'post_status'  => 'publish',
									'post_type'    => 'page',
									'meta_input'   => array(
										'_elementor_edit_mode' => 'builder',
										'_wp_page_template'    => 'elementor_canvas',
									),
								) );
								$log .= "✓ Seite erstellt: $page_title (ID: $page_id)\n";
							} else {
								$log .= "ℹ Seite existiert bereits: $page_title\n";
							}
						}
						// Startseite setzen
						$home = get_page_by_path( 'home' );
						if ( $home ) {
							update_option( 'page_on_front', $home->ID );
							update_option( 'show_on_front', 'page' );
						}
					}
				} else {
					$log = "⏭ Seiten-Import übersprungen";
				}
				break;

			case 'templates':
				if ( $_POST['import_widgets'] ) {
					$templates_file = "$theme_dir/demos/$demo/elementor-templates.json";
					if ( file_exists( $templates_file ) ) {
						$templates = json_decode( file_get_contents( $templates_file ), true );
						$count = 0;
						foreach ( $templates as $tpl ) {
							if ( empty( $tpl['content'] ) ) {
								continue;
							}
							$page = get_page_by_title( $tpl['title'] );
							if ( $page && ! empty( $tpl['content'] ) ) {
								update_post_meta( $page->ID, '_elementor_data', wp_slash( json_encode( $tpl['content'] ) ) );
								update_post_meta( $page->ID, '_elementor_edit_mode', 'builder' );
								$count++;
							}
						}
						$log = "✓ $count Elementor-Templates importiert";
					} else {
						$log = "ℹ Keine Elementor-Templates für dieses Demo";
					}
				} else {
					$log = "⏭ Template-Import übersprungen";
				}
				break;

			case 'options':
				if ( $_POST['import_customizer'] ) {
					$options_file = "$theme_dir/demos/$demo/options.json";
					if ( file_exists( $options_file ) ) {
						$options = json_decode( file_get_contents( $options_file ), true );
						foreach ( $options as $key => $value ) {
							if ( $key === 'blogname' ) {
								update_option( 'blogname', $value );
							} else {
								update_option( "sf_$key", $value );
								update_option( $key, $value );
							}
						}
						$log = "✓ " . count( $options ) . " Theme-Optionen gesetzt";
					} else {
						// Skin aus Demo-ID ableiten
						update_option( 'sf_active_skin', $demo );
						update_option( 'sf_setup_skin', $demo );
						$log = "✓ Skin aktiviert: $demo";
					}

					// Elementor Kit-Farben syncen
					do_action( 'sf_sync_elementor_kit' );
				} else {
					$log = "⏭ Optionen-Import übersprungen";
				}
				break;

			case 'menus':
				if ( $_POST['import_menus'] ) {
					// Menü erstellen oder finden
					$menus = wp_get_nav_menus();
					$menu_id = null;
					foreach ( $menus as $menu ) {
						if ( $menu->name === 'Main Menu' ) {
							$menu_id = $menu->term_id;
							break;
						}
					}
					if ( ! $menu_id ) {
						$menu_id = wp_create_nav_menu( 'Main Menu' );
					}

					// Menüpunkte aus Seiten
					$page_names = array( 'Home', 'Services', 'Portfolio', 'About', 'Contact' );
					wp_delete_nav_menu_items( $menu_id );
					$order = 1;
					foreach ( $page_names as $name ) {
						$page = get_page_by_title( $name );
						if ( $page ) {
							wp_update_nav_menu_item( $menu_id, 0, array(
								'menu-item-title'     => $name,
								'menu-item-object'    => 'page',
								'menu-item-object-id' => $page->ID,
								'menu-item-type'      => 'post_type',
								'menu-item-status'    => 'publish',
								'menu-item-position'  => $order++,
							) );
						}
					}

					// Menü-Location zuweisen
					$locations = get_theme_mod( 'nav_menu_locations' );
					$locations['main-menu'] = $menu_id;
					if ( get_nav_menu_locations() ) {
						set_theme_mod( 'nav_menu_locations', $locations );
					}

					$log = "✓ Navigation erstellt mit " . count( $page_names ) . " Einträgen";
				} else {
					$log = "⏭ Navigation übersprungen";
				}
				break;

			case 'finish':
				// Cache leeren
				if ( function_exists( 'w3tc_flush_all' ) ) {
					w3tc_flush_all();
				}
				if ( function_exists( 'wp_cache_clear_cache' ) ) {
					wp_cache_clear_cache();
				}
				wp_cache_flush();
				flush_rewrite_rules();

				// Setup als abgeschlossen markieren
				update_option( 'sf_setup_complete', true );
				update_option( 'sf_setup_demo', $_POST['demo'] ?? 'agency' );
				update_option( 'sf_setup_date', current_time( 'mysql' ) );

				$log = "✓ Setup abgeschlossen! Website bereit unter: " . home_url();
				break;
		}

		wp_send_json_success( array(
			'step' => $step,
			'log'  => htmlspecialchars( $log ),
		) );
	}

	/**
	 * Assets für Setup-Seite
	 */
	public function enqueue_setup_assets( $hook ) {
		if ( $hook !== 'appearance_page_starter-flavor-setup' ) {
			return;
		}
		// Setup-spezifische Styles bereits im render_setup_page inline
	}
}

// Initialisieren
Starter_Flavor_Auto_Setup::get_instance();
