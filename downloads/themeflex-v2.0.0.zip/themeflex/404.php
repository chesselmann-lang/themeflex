<?php
/**
 * 404 Page — Starter Flavor
 * @package ThemeFlex
 */
get_header();
?>
<main id="primary" class="site-main" style="min-height:70vh;display:flex;align-items:center;justify-content:center;padding:80px 24px;">
    <div style="text-align:center;max-width:560px;">
        <!-- Animated 404 -->
        <div style="font-family:'Inter Tight',sans-serif;font-size:clamp(100px,20vw,180px);font-weight:900;line-height:1;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#00D4FF));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;margin-bottom:8px;animation:sf404Pulse 3s ease-in-out infinite;">404</div>
        <h1 style="font-family:'Inter Tight',sans-serif;font-size:clamp(24px,4vw,36px);font-weight:800;color:var(--sf-title,#1e293b);margin-bottom:16px;"><?php esc_html_e('Page Not Found','themeflex'); ?></h1>
        <p style="font-size:17px;color:var(--sf-text,#64748b);line-height:1.7;margin-bottom:36px;"><?php esc_html_e("The page you're looking for doesn't exist or has been moved. Let's get you back on track.",'themeflex'); ?></p>
        <!-- Search -->
        <form role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>"
              style="display:flex;gap:8px;margin-bottom:32px;max-width:420px;margin-left:auto;margin-right:auto;">
            <input type="search" name="s" placeholder="<?php esc_attr_e('Search...','themeflex'); ?>"
                   value="<?php echo get_search_query(); ?>"
                   style="flex:1;padding:12px 16px;border:1px solid var(--sf-border,#e5e7eb);border-radius:10px;font-size:15px;font-family:inherit;outline:none;background:var(--sf-bg,#fff);color:var(--sf-title,#1e293b);" />
            <button type="submit" style="padding:12px 20px;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;border:none;border-radius:10px;font-weight:700;font-size:14px;cursor:pointer;font-family:inherit;"><?php esc_html_e('Search','themeflex'); ?></button>
        </form>
        <!-- Quick links -->
        <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
            <a href="<?php echo esc_url(home_url('/')); ?>"
               style="padding:10px 20px;background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:8px;font-weight:600;font-size:14px;color:var(--sf-title,#1e293b);text-decoration:none;transition:all .2s;"
               onmouseover="this.style.borderColor='var(--sf-color-primary,#FF5E2E)'" onmouseout="this.style.borderColor='var(--sf-border,#e5e7eb)'">
                🏠 <?php esc_html_e('Home','themeflex'); ?>
            </a>
            <?php if (wc_get_page_id('shop') > 0): ?>
            <a href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>"
               style="padding:10px 20px;background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:8px;font-weight:600;font-size:14px;color:var(--sf-title,#1e293b);text-decoration:none;transition:all .2s;"
               onmouseover="this.style.borderColor='var(--sf-color-primary,#FF5E2E)'" onmouseout="this.style.borderColor='var(--sf-border,#e5e7eb)'">
                🛍️ <?php esc_html_e('Shop','themeflex'); ?>
            </a>
            <?php endif; ?>
            <?php
            $blog = get_option('page_for_posts');
            if ($blog): ?>
            <a href="<?php echo esc_url(get_permalink($blog)); ?>"
               style="padding:10px 20px;background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:8px;font-weight:600;font-size:14px;color:var(--sf-title,#1e293b);text-decoration:none;transition:all .2s;"
               onmouseover="this.style.borderColor='var(--sf-color-primary,#FF5E2E)'" onmouseout="this.style.borderColor='var(--sf-border,#e5e7eb)'">
                📰 <?php esc_html_e('Blog','themeflex'); ?>
            </a>
            <?php endif; ?>
        </div>
    </div>
</main>
<style>
@keyframes sf404Pulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.85;transform:scale(.97)}}
[data-theme=dark] .site-main h1{color:var(--sf-alt-title,#f1f5f9)!important}
</style>
<?php get_footer(); ?>
