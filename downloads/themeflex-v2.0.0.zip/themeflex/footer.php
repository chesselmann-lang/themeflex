<?php
/**
 * The footer for ThemeFlex theme
 *
 * Features:
 * - Dynamic Widget Columns (1-4)
 * - Social Links
 * - Copyright & Credits
 * - Back to Top Button
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

?>
					<?php
					/**
					 * Action hook after main content
					 *
					 * @since 1.0.0
					 */
					do_action( 'themeflex_after_content' );
					?>
				</main><!-- #site-content -->

				<?php
				/**
				 * Display sidebar if present
				 *
				 * @since 1.0.0
				 */
				if ( themeflex_sidebar_present() ) {
					get_sidebar();
				}
				?>
			</div><!-- .content_wrap -->
		</div><!-- .page_content_wrap -->

		<?php
		/**
		 * Widgets Below Page
		 *
		 * @since 1.0.0
		 */
		if ( is_active_sidebar( 'widgets-below-page' ) ) {
			?>
			<div class="widgets-below-page-wrap">
				<div class="content_wrap">
					<?php dynamic_sidebar( 'widgets-below-page' ); ?>
				</div>
			</div>
			<?php
		}
		?>

		<footer id="site-footer" class="site-footer" role="contentinfo">
			<div class="footer-content">
				<div class="content_wrap">
					<div class="footer-widgets">
						<?php
						// Get number of active footer columns
						$active_columns = 0;
						for ( $i = 1; $i <= 4; $i++ ) {
							if ( is_active_sidebar( 'footer-' . $i ) ) {
								$active_columns++;
							}
						}

						// Display footer widgets with dynamic columns
						$column_class = 'footer-column-' . ( $active_columns > 0 ? $active_columns : 1 );
						for ( $i = 1; $i <= 4; $i++ ) {
							if ( is_active_sidebar( 'footer-' . $i ) ) {
								?>
								<div class="footer-column footer-column-<?php echo esc_attr( $i ); ?> <?php echo esc_attr( $column_class ); ?>">
									<?php dynamic_sidebar( 'footer-' . $i ); ?>
								</div>
								<?php
							}
						}
						?>
					</div>

					<div class="footer-bottom">
						<div class="footer-menu">
							<?php
							wp_nav_menu( array(
								'theme_location' => 'footer-menu',
								'fallback_cb'    => false,
								'depth'          => 1,
								'container'      => false,
							) );
							?>
						</div>

						<?php
						// Social Links
						$social_links = themeflex_get_theme_option( 'social_links' );
						if ( ! empty( $social_links ) ) {
							?>
							<div class="footer-social">
								<?php
								$social_platforms = array(
									'facebook'  => 'Facebook',
									'twitter'   => 'Twitter',
									'instagram' => 'Instagram',
									'linkedin'  => 'LinkedIn',
									'youtube'   => 'YouTube',
									'pinterest' => 'Pinterest',
								);

								foreach ( $social_platforms as $platform => $label ) {
									$url = isset( $social_links[ $platform ] ) ? $social_links[ $platform ] : '';
									if ( ! empty( $url ) ) {
										printf(
											'<a href="%s" class="social-link social-%s" rel="noopener noreferrer" target="_blank" aria-label="%s (opens in new window)">%s</a>',
											esc_url( $url ),
											esc_attr( $platform ),
											esc_attr( $label ),
											esc_html( $label )
										);
									}
								}
								?>
							</div>
							<?php
						}
						?>

						<div class="footer-copyright">
							<?php
							// Dynamic copyright text
							$copyright_text = themeflex_get_theme_option( 'copyright_text' );
							if ( ! empty( $copyright_text ) ) {
								echo wp_kses_post( $copyright_text );
							} else {
								?>
								<p>&copy; <span class="year"><?php echo esc_html( gmdate( 'Y' ) ); ?></span> <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html( bloginfo( 'name' ) ); ?></a>. <?php esc_html_e( 'All rights reserved.', 'themeflex' ); ?></p>
								<?php
							}
							?>
						</div>

						<div class="footer-credits">
							<p><?php printf( esc_html__( 'Powered by %1$s & %2$s', 'themeflex' ), '<a href="https://wordpress.org" target="_blank" rel="noopener noreferrer">WordPress</a>', '<a href="https://whatsdigital.de" target="_blank" rel="noopener noreferrer">WhatsDigital</a>' ); ?></p>
						</div>
					</div>
				</div>
			</div>
		</footer><!-- #site-footer -->

		<?php
		/**
		 * Back to top button
		 *
		 * @since 1.0.0
		 */
		if ( themeflex_get_theme_option( 'enable_back_to_top' ) ) {
			?>
			<a href="#site-header" class="back-to-top" id="back-to-top" title="<?php esc_attr_e( 'Back to top', 'themeflex' ); ?>" aria-label="<?php esc_attr_e( 'Back to top', 'themeflex' ); ?>">
				<span class="back-to-top-icon">↑</span>
			</a>
			<?php
		}
		?>

	</div><!-- .page_wrap -->
	</div><!-- .body_wrap -->

	<?php wp_footer(); ?>
</body>
</html>
