<?php
/**
 * Dynamic Content System
 *
 * Provides dynamic data integration for Elementor widgets:
 *  - Custom Post Type builder
 *  - Dynamic Tags (Post Title, Meta, ACF fields, etc.)
 *  - Query Builder for Post Grid widgets
 *  - Conditional Display logic
 *
 * @package ThemeFlex
 * @since   2.0.0
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Dynamic_Content {

    private static ?self $instance = null;

    public static function instance(): self {
        if (is_null(self::$instance)) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        // Register Dynamic Tags with Elementor
        add_action('elementor/dynamic_tags/register', [$this, 'register_dynamic_tags']);
        // Register custom Dynamic Tag groups
        add_action('elementor/dynamic_tags/register', [$this, 'register_tag_groups'], 5);
        // CPT Builder admin page
        add_action('admin_menu',   [$this, 'add_cpt_builder_page']);
        // Save CPT settings
        add_action('admin_init',   [$this, 'save_cpt_settings']);
        // Register dynamic CPTs from settings
        add_action('init',         [$this, 'register_dynamic_cpts'], 5);
        // Conditional display shortcode
        add_shortcode('sf_if',     [$this, 'shortcode_conditional']);
    }

    // ── Dynamic Tags Registration ──────────────────────────────────────────

    public function register_tag_groups(\Elementor\Modules\DynamicTags\Module $module): void {
        $module->register_group('sf-site', ['title' => esc_html__('ThemeFlex — Site', 'themeflex')]);
        $module->register_group('sf-post', ['title' => esc_html__('ThemeFlex — Post', 'themeflex')]);
        $module->register_group('sf-user', ['title' => esc_html__('ThemeFlex — User', 'themeflex')]);
    }

    public function register_dynamic_tags(\Elementor\Modules\DynamicTags\Module $module): void {
        if (!defined('ELEMENTOR_VERSION')) return;

        $tags = [
            'SF_Tag_Post_Title'      => 'class-dynamic-tags/tag-post-title.php',
            'SF_Tag_Post_Excerpt'    => 'class-dynamic-tags/tag-post-excerpt.php',
            'SF_Tag_Post_Date'       => 'class-dynamic-tags/tag-post-date.php',
            'SF_Tag_Post_Author'     => 'class-dynamic-tags/tag-post-author.php',
            'SF_Tag_Post_Meta'       => 'class-dynamic-tags/tag-post-meta.php',
            'SF_Tag_Site_Title'      => 'class-dynamic-tags/tag-site-title.php',
            'SF_Tag_Site_Tagline'    => 'class-dynamic-tags/tag-site-tagline.php',
            'SF_Tag_User_Name'       => 'class-dynamic-tags/tag-user-name.php',
            'SF_Tag_Current_Date'    => 'class-dynamic-tags/tag-current-date.php',
            'SF_Tag_Request_Param'   => 'class-dynamic-tags/tag-request-param.php',
        ];

        foreach ($tags as $class => $file) {
            $path = get_template_directory().'/includes/api/'.$file;
            if (file_exists($path)) {
                require_once $path;
                if (class_exists($class)) $module->register(new $class());
            }
        }

        // Inline tag classes (no separate files)
        $this->register_inline_tags($module);
    }

    private function register_inline_tags(\Elementor\Modules\DynamicTags\Module $module): void {

        // Post Title Tag
        if (!class_exists('SF_Tag_Post_Title_Inline')) {
            class SF_Tag_Post_Title_Inline extends \Elementor\Core\DynamicTags\Tag {
                public function get_name()  { return 'sf-post-title'; }
                public function get_title() { return esc_html__('Post Title', 'themeflex'); }
                public function get_group() { return 'sf-post'; }
                public function get_categories() { return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY]; }
                public function render() { echo esc_html(get_the_title()); }
            }
            $module->register(new SF_Tag_Post_Title_Inline());
        }

        // Post Excerpt Tag
        if (!class_exists('SF_Tag_Post_Excerpt_Inline')) {
            class SF_Tag_Post_Excerpt_Inline extends \Elementor\Core\DynamicTags\Tag {
                public function get_name()  { return 'sf-post-excerpt'; }
                public function get_title() { return esc_html__('Post Excerpt', 'themeflex'); }
                public function get_group() { return 'sf-post'; }
                public function get_categories() { return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY]; }
                public function render() {
                    $excerpt = has_excerpt() ? get_the_excerpt() : wp_trim_words(get_the_content(), 30, '…');
                    echo esc_html($excerpt);
                }
            }
            $module->register(new SF_Tag_Post_Excerpt_Inline());
        }

        // Site Title
        if (!class_exists('SF_Tag_Site_Title_Inline')) {
            class SF_Tag_Site_Title_Inline extends \Elementor\Core\DynamicTags\Tag {
                public function get_name()  { return 'sf-site-title'; }
                public function get_title() { return esc_html__('Site Name', 'themeflex'); }
                public function get_group() { return 'sf-site'; }
                public function get_categories() { return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY]; }
                public function render() { echo esc_html(get_bloginfo('name')); }
            }
            $module->register(new SF_Tag_Site_Title_Inline());
        }

        // User Name
        if (!class_exists('SF_Tag_User_Name_Inline')) {
            class SF_Tag_User_Name_Inline extends \Elementor\Core\DynamicTags\Tag {
                public function get_name()  { return 'sf-user-name'; }
                public function get_title() { return esc_html__('User Display Name', 'themeflex'); }
                public function get_group() { return 'sf-user'; }
                public function get_categories() { return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY]; }
                public function render() {
                    if (is_user_logged_in()) echo esc_html(wp_get_current_user()->display_name);
                }
            }
            $module->register(new SF_Tag_User_Name_Inline());
        }

        // Post Custom Field (meta)
        if (!class_exists('SF_Tag_Post_Meta_Inline')) {
            class SF_Tag_Post_Meta_Inline extends \Elementor\Core\DynamicTags\Tag {
                public function get_name()  { return 'sf-post-meta'; }
                public function get_title() { return esc_html__('Post Custom Field', 'themeflex'); }
                public function get_group() { return 'sf-post'; }
                public function get_categories() { return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY]; }
                protected function register_controls() {
                    $this->add_control('meta_key', ['label'=>esc_html__('Key','themeflex'),'type'=>\Elementor\Controls_Manager::TEXT,'default'=>'']);
                }
                public function render() {
                    $key = $this->get_settings('meta_key');
                    if ($key) echo esc_html(get_post_meta(get_the_ID(), $key, true));
                }
            }
            $module->register(new SF_Tag_Post_Meta_Inline());
        }

        // Current Year
        if (!class_exists('SF_Tag_Current_Year_Inline')) {
            class SF_Tag_Current_Year_Inline extends \Elementor\Core\DynamicTags\Tag {
                public function get_name()  { return 'sf-current-year'; }
                public function get_title() { return esc_html__('Current Year', 'themeflex'); }
                public function get_group() { return 'sf-site'; }
                public function get_categories() { return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY]; }
                public function render() { echo esc_html(date('Y')); }
            }
            $module->register(new SF_Tag_Current_Year_Inline());
        }
    }

    // ── CPT Builder ────────────────────────────────────────────────────────

    public function add_cpt_builder_page(): void {
        add_submenu_page(
            'themeflex-settings',
            __('Custom Post Types', 'themeflex'),
            __('Custom Post Types', 'themeflex'),
            'manage_options',
            'sf-cpt-builder',
            [$this, 'render_cpt_builder']
        );
    }

    public function render_cpt_builder(): void {
        $cpts = get_option('sf_custom_post_types', []);
        $saved = isset($_GET['saved']);
        ?>
        <div class="wrap" style="font-family:-apple-system,BlinkMacSystemFont,'Inter',sans-serif;">
            <div style="background:linear-gradient(135deg,#06021D,#1a1f29);border-radius:12px;padding:24px 32px;margin-bottom:24px;">
                <h1 style="margin:0;color:#fff;font-size:1.3rem;font-weight:800;">🗂️ <?php esc_html_e('Custom Post Types','themeflex'); ?></h1>
                <p style="margin:4px 0 0;color:rgba(255,255,255,.55);font-size:13px;"><?php esc_html_e('Register custom post types without code. Appears in Elementor query builder.','themeflex'); ?></p>
            </div>
            <?php if ($saved): ?><div class="notice notice-success"><p><?php esc_html_e('Saved. Flush permalinks to activate new post types.','themeflex'); ?></p></div><?php endif; ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="sf_save_cpts" />
                <?php wp_nonce_field('sf_cpt_save','sf_cpt_nonce'); ?>
                <div style="background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:24px;margin-bottom:20px;">
                    <table class="wp-list-table widefat fixed striped" style="border-radius:8px;overflow:hidden;">
                        <thead><tr>
                            <th><?php esc_html_e('Slug','themeflex'); ?></th>
                            <th><?php esc_html_e('Singular Name','themeflex'); ?></th>
                            <th><?php esc_html_e('Plural Name','themeflex'); ?></th>
                            <th><?php esc_html_e('Icon (dashicon)','themeflex'); ?></th>
                            <th><?php esc_html_e('Has Archive','themeflex'); ?></th>
                            <th><?php esc_html_e('Public','themeflex'); ?></th>
                            <th></th>
                        </tr></thead>
                        <tbody id="sf-cpt-rows">
                            <?php foreach ($cpts as $i => $cpt): ?>
                            <tr>
                                <td><input type="text" name="sf_cpts[<?php echo $i; ?>][slug]"     value="<?php echo esc_attr($cpt['slug']); ?>"     style="width:100%" /></td>
                                <td><input type="text" name="sf_cpts[<?php echo $i; ?>][singular]" value="<?php echo esc_attr($cpt['singular']); ?>" style="width:100%" /></td>
                                <td><input type="text" name="sf_cpts[<?php echo $i; ?>][plural]"   value="<?php echo esc_attr($cpt['plural']); ?>"   style="width:100%" /></td>
                                <td><input type="text" name="sf_cpts[<?php echo $i; ?>][icon]"     value="<?php echo esc_attr($cpt['icon'] ?? 'dashicons-admin-post'); ?>" style="width:100%" /></td>
                                <td style="text-align:center"><input type="checkbox" name="sf_cpts[<?php echo $i; ?>][archive]" value="1" <?php checked($cpt['archive'] ?? false); ?> /></td>
                                <td style="text-align:center"><input type="checkbox" name="sf_cpts[<?php echo $i; ?>][public]"  value="1" <?php checked($cpt['public'] ?? true); ?> /></td>
                                <td><button type="button" onclick="this.closest('tr').remove()" style="background:none;border:none;color:#ef4444;cursor:pointer;font-size:16px;">✕</button></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <button type="button" id="sf-add-cpt" onclick="sfAddCptRow()"
                        style="margin-top:12px;padding:8px 16px;background:var(--sf-bg-2,#f8fafc);border:1px dashed #e5e7eb;border-radius:8px;font-size:13px;cursor:pointer;">
                        + <?php esc_html_e('Add Post Type','themeflex'); ?>
                    </button>
                </div>
                <?php submit_button(__('Save Post Types','themeflex')); ?>
            </form>
        </div>
        <script>
        var sfCptIdx=<?php echo count($cpts); ?>;
        function sfAddCptRow(){
            var row='<tr>'
                +'<td><input type="text" name="sf_cpts['+sfCptIdx+'][slug]"     placeholder="my-type"  style="width:100%"/></td>'
                +'<td><input type="text" name="sf_cpts['+sfCptIdx+'][singular]" placeholder="Item"     style="width:100%"/></td>'
                +'<td><input type="text" name="sf_cpts['+sfCptIdx+'][plural]"   placeholder="Items"    style="width:100%"/></td>'
                +'<td><input type="text" name="sf_cpts['+sfCptIdx+'][icon]"     value="dashicons-admin-post" style="width:100%"/></td>'
                +'<td style="text-align:center"><input type="checkbox" name="sf_cpts['+sfCptIdx+'][archive]" value="1"/></td>'
                +'<td style="text-align:center"><input type="checkbox" name="sf_cpts['+sfCptIdx+'][public]"  value="1" checked/></td>'
                +'<td><button type="button" onclick="this.closest(\'tr\').remove()" style="background:none;border:none;color:#ef4444;cursor:pointer;font-size:16px;">✕</button></td>'
                +'</tr>';
            document.getElementById('sf-cpt-rows').insertAdjacentHTML('beforeend',row);
            sfCptIdx++;
        }
        </script>
        <?php
    }

    public function save_cpt_settings(): void {
        if (!isset($_POST['action']) || $_POST['action'] !== 'sf_save_cpts') return;
        check_admin_referer('sf_cpt_save','sf_cpt_nonce');
        if (!current_user_can('manage_options')) return;

        $raw  = $_POST['sf_cpts'] ?? [];
        $cpts = [];
        foreach ($raw as $item) {
            $slug = sanitize_key($item['slug'] ?? '');
            if (!$slug) continue;
            $cpts[] = [
                'slug'     => $slug,
                'singular' => sanitize_text_field($item['singular'] ?? ucfirst($slug)),
                'plural'   => sanitize_text_field($item['plural']   ?? ucfirst($slug).'s'),
                'icon'     => sanitize_text_field($item['icon']     ?? 'dashicons-admin-post'),
                'archive'  => !empty($item['archive']),
                'public'   => !empty($item['public']),
            ];
        }
        update_option('sf_custom_post_types', $cpts);
        flush_rewrite_rules();
        wp_safe_redirect(admin_url('admin.php?page=sf-cpt-builder&saved=1'));
        exit;
    }

    public function register_dynamic_cpts(): void {
        $cpts = get_option('sf_custom_post_types', []);
        foreach ($cpts as $cpt) {
            $slug = $cpt['slug'] ?? '';
            if (!$slug || post_type_exists($slug)) continue;
            register_post_type($slug, [
                'labels' => [
                    'name'          => esc_html($cpt['plural']),
                    'singular_name' => esc_html($cpt['singular']),
                    'add_new_item'  => sprintf(esc_html__('Add New %s','themeflex'), $cpt['singular']),
                    'edit_item'     => sprintf(esc_html__('Edit %s','themeflex'), $cpt['singular']),
                ],
                'public'      => $cpt['public'] ?? true,
                'has_archive' => $cpt['archive'] ?? false,
                'supports'    => ['title','editor','thumbnail','excerpt'],
                'show_in_rest'=> true,
                'menu_icon'   => $cpt['icon'] ?? 'dashicons-admin-post',
                'rewrite'     => ['slug' => $slug],
            ]);
        }
    }

    // ── Conditional Shortcode ──────────────────────────────────────────────

    public function shortcode_conditional(array $atts, string $content = ''): string {
        $a = shortcode_atts([
            'logged_in' => '',  // 'yes' or 'no'
            'role'      => '',  // user role
            'meta'      => '',  // post meta key
            'meta_val'  => '',  // post meta value
            'device'    => '',  // mobile, desktop, tablet
        ], $atts, 'sf_if');

        $show = true;

        if ($a['logged_in'] !== '') {
            $required = 'yes' === strtolower($a['logged_in']);
            if ($required !== is_user_logged_in()) $show = false;
        }

        if ($show && $a['role']) {
            $user = wp_get_current_user();
            if (!in_array($a['role'], (array)$user->roles)) $show = false;
        }

        if ($show && $a['meta'] && $a['meta_val']) {
            $val = get_post_meta(get_the_ID(), $a['meta'], true);
            if ($val !== $a['meta_val']) $show = false;
        }

        return $show ? do_shortcode($content) : '';
    }
}

// AJAX: Save CPT
add_action('admin_post_sf_save_cpts', [ThemeFlex_Dynamic_Content::instance(), 'save_cpt_settings']);
ThemeFlex_Dynamic_Content::instance();
