<?php
/**
 * Design System Panel
 *
 * Global design system configuration panel with centralized color, typography,
 * spacing, and component styling management.
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ThemeFlex_Design_System {

	const OPTION_PREFIX = 'sf_design_system_';
	const DEFAULT_CONFIG = array(
		'colors'      => array(),
		'typography'  => array(),
		'spacing'     => array(),
		'borders'     => array(),
		'shadows'     => array(),
		'buttons'     => array(),
		'layout'      => array(),
	);

	/**
	 * Initialize Design System
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_assets' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_frontend_css' ), 5 );
		add_action( 'wp_head', array( __CLASS__, 'output_css_variables' ), 5 );
		add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );

		// Initialize default config
		self::initialize_defaults();
	}

	/**
	 * Add admin menu
	 */
	public static function add_admin_menu() {
		add_theme_page(
			esc_html__( 'Design System', 'themeflex' ),
			esc_html__( 'Design System', 'themeflex' ),
			'manage_options',
			'sf_design_system',
			array( __CLASS__, 'render_admin_page' ),
			20
		);
	}

	/**
	 * Initialize default configuration
	 */
	private static function initialize_defaults() {
		if ( ! get_option( self::OPTION_PREFIX . 'initialized' ) ) {
			$defaults = array(
				'colors'     => self::get_default_colors(),
				'typography' => self::get_default_typography(),
				'spacing'    => self::get_default_spacing(),
				'borders'    => self::get_default_borders(),
				'shadows'    => self::get_default_shadows(),
				'buttons'    => self::get_default_buttons(),
				'layout'     => self::get_default_layout(),
			);

			update_option( self::OPTION_PREFIX . 'config', $defaults );
			update_option( self::OPTION_PREFIX . 'initialized', true );
		}
	}

	/**
	 * Get default colors
	 */
	private static function get_default_colors() {
		return array(
			'primary'     => '#7c3aed',
			'secondary'   => '#06b6d4',
			'accent'      => '#ec4899',
			'text'        => '#1e293b',
			'text-light'  => '#64748b',
			'heading'     => '#0f172a',
			'link'        => '#0369a1',
			'background'  => '#ffffff',
			'surface'     => '#f8fafc',
			'border'      => '#e2e8f0',
			'muted'       => '#94a3b8',
			'success'     => '#16a34a',
			'warning'     => '#ea580c',
			'error'       => '#dc2626',
			'info'        => '#0284c7',
			'custom-1'    => '#f97316',
			'custom-2'    => '#3b82f6',
			'custom-3'    => '#8b5cf6',
			'custom-4'    => '#f1abee',
			'custom-5'    => '#94e2d5',
		);
	}

	/**
	 * Get default typography
	 */
	private static function get_default_typography() {
		return array(
			'h1' => array(
				'font_family'    => 'system-ui, -apple-system, sans-serif',
				'size_desktop'   => '48px',
				'size_tablet'    => '36px',
				'size_mobile'    => '28px',
				'weight'         => 700,
				'line_height'    => 1.2,
				'letter_spacing' => '-0.02em',
				'transform'      => 'none',
			),
			'h2' => array(
				'font_family'    => 'system-ui, -apple-system, sans-serif',
				'size_desktop'   => '36px',
				'size_tablet'    => '28px',
				'size_mobile'    => '24px',
				'weight'         => 700,
				'line_height'    => 1.3,
				'letter_spacing' => '-0.01em',
				'transform'      => 'none',
			),
			'h3' => array(
				'font_family'    => 'system-ui, -apple-system, sans-serif',
				'size_desktop'   => '28px',
				'size_tablet'    => '24px',
				'size_mobile'    => '20px',
				'weight'         => 600,
				'line_height'    => 1.4,
				'letter_spacing' => '0em',
				'transform'      => 'none',
			),
			'h4' => array(
				'font_family'    => 'system-ui, -apple-system, sans-serif',
				'size_desktop'   => '24px',
				'size_tablet'    => '20px',
				'size_mobile'    => '18px',
				'weight'         => 600,
				'line_height'    => 1.4,
				'letter_spacing' => '0em',
				'transform'      => 'none',
			),
			'h5' => array(
				'font_family'    => 'system-ui, -apple-system, sans-serif',
				'size_desktop'   => '20px',
				'size_tablet'    => '18px',
				'size_mobile'    => '16px',
				'weight'         => 600,
				'line_height'    => 1.5,
				'letter_spacing' => '0em',
				'transform'      => 'none',
			),
			'h6' => array(
				'font_family'    => 'system-ui, -apple-system, sans-serif',
				'size_desktop'   => '16px',
				'size_tablet'    => '16px',
				'size_mobile'    => '14px',
				'weight'         => 600,
				'line_height'    => 1.6,
				'letter_spacing' => '0em',
				'transform'      => 'none',
			),
			'body' => array(
				'font_family'    => 'system-ui, -apple-system, sans-serif',
				'size_desktop'   => '16px',
				'size_tablet'    => '16px',
				'size_mobile'    => '14px',
				'weight'         => 400,
				'line_height'    => 1.6,
				'letter_spacing' => '0em',
				'transform'      => 'none',
			),
			'small' => array(
				'font_family'    => 'system-ui, -apple-system, sans-serif',
				'size_desktop'   => '14px',
				'size_tablet'    => '14px',
				'size_mobile'    => '12px',
				'weight'         => 400,
				'line_height'    => 1.5,
				'letter_spacing' => '0em',
				'transform'      => 'none',
			),
			'caption' => array(
				'font_family'    => 'system-ui, -apple-system, sans-serif',
				'size_desktop'   => '12px',
				'size_tablet'    => '12px',
				'size_mobile'    => '11px',
				'weight'         => 500,
				'line_height'    => 1.4,
				'letter_spacing' => '0.02em',
				'transform'      => 'uppercase',
			),
		);
	}

	/**
	 * Get default spacing scale
	 */
	private static function get_default_spacing() {
		return array(
			'base'  => '8px',
			'xs'    => '4px',
			'sm'    => '8px',
			'md'    => '16px',
			'lg'    => '24px',
			'xl'    => '32px',
			'2xl'   => '48px',
			'3xl'   => '64px',
			'4xl'   => '96px',
			'custom-1' => '12px',
			'custom-2' => '20px',
			'custom-3' => '40px',
			'custom-4' => '80px',
			'custom-5' => '128px',
		);
	}

	/**
	 * Get default borders
	 */
	private static function get_default_borders() {
		return array(
			'radius' => array(
				'none'   => '0px',
				'sm'     => '4px',
				'md'     => '8px',
				'lg'     => '12px',
				'xl'     => '16px',
				'full'   => '9999px',
			),
			'width'  => array(
				'none' => '0px',
				'sm'   => '1px',
				'md'   => '2px',
				'lg'   => '4px',
			),
			'color'  => '#e2e8f0',
		);
	}

	/**
	 * Get default shadows
	 */
	private static function get_default_shadows() {
		return array(
			'sm'    => '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
			'md'    => '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
			'lg'    => '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
			'xl'    => '0 20px 25px -5px rgba(0, 0, 0, 0.1)',
			'inner' => 'inset 0 2px 4px 0 rgba(0, 0, 0, 0.05)',
		);
	}

	/**
	 * Get default button styles
	 */
	private static function get_default_buttons() {
		return array(
			'primary' => array(
				'bg_color'       => '#7c3aed',
				'text_color'     => '#ffffff',
				'border_color'   => '#7c3aed',
				'hover_bg'       => '#6d28d9',
				'hover_text'     => '#ffffff',
				'padding'        => '10px 20px',
				'border_radius'  => '8px',
				'font_size'      => '14px',
				'font_weight'    => 600,
				'transition'     => '0.2s',
			),
			'secondary' => array(
				'bg_color'       => '#e2e8f0',
				'text_color'     => '#1e293b',
				'border_color'   => '#cbd5e1',
				'hover_bg'       => '#cbd5e1',
				'hover_text'     => '#0f172a',
				'padding'        => '10px 20px',
				'border_radius'  => '8px',
				'font_size'      => '14px',
				'font_weight'    => 600,
				'transition'     => '0.2s',
			),
			'outline' => array(
				'bg_color'       => 'transparent',
				'text_color'     => '#7c3aed',
				'border_color'   => '#7c3aed',
				'hover_bg'       => '#f0f4ff',
				'hover_text'     => '#6d28d9',
				'padding'        => '10px 20px',
				'border_radius'  => '8px',
				'font_size'      => '14px',
				'font_weight'    => 600,
				'transition'     => '0.2s',
			),
			'ghost' => array(
				'bg_color'       => 'transparent',
				'text_color'     => '#64748b',
				'border_color'   => 'transparent',
				'hover_bg'       => '#f8fafc',
				'hover_text'     => '#1e293b',
				'padding'        => '10px 20px',
				'border_radius'  => '8px',
				'font_size'      => '14px',
				'font_weight'    => 600,
				'transition'     => '0.2s',
			),
			'link' => array(
				'bg_color'       => 'transparent',
				'text_color'     => '#0369a1',
				'border_color'   => 'transparent',
				'hover_bg'       => 'transparent',
				'hover_text'     => '#0284c7',
				'padding'        => '0px',
				'border_radius'  => '0px',
				'font_size'      => '14px',
				'font_weight'    => 600,
				'transition'     => '0.2s',
			),
		);
	}

	/**
	 * Get default layout settings
	 */
	private static function get_default_layout() {
		return array(
			'container_max_width' => '1200px',
			'content_width'       => '800px',
			'sidebar_width'       => '300px',
			'header_height'       => '80px',
			'section_padding'     => '40px',
			'grid_gap'            => '16px',
		);
	}

	/**
	 * Register REST API routes
	 */
	public static function register_rest_routes() {
		register_rest_route(
			'themeflex/v1',
			'/design-system/config',
			array(
				'methods'             => array( 'GET', 'POST' ),
				'callback'            => array( __CLASS__, 'handle_config_request' ),
				'permission_callback' => array( __CLASS__, 'check_permission' ),
			)
		);

		register_rest_route(
			'themeflex/v1',
			'/design-system/reset/(?P<section>\w+)',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'reset_section' ),
				'permission_callback' => array( __CLASS__, 'check_permission' ),
			)
		);

		register_rest_route(
			'themeflex/v1',
			'/design-system/export',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'export_config' ),
				'permission_callback' => array( __CLASS__, 'check_permission' ),
			)
		);

		register_rest_route(
			'themeflex/v1',
			'/design-system/import',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'import_config' ),
				'permission_callback' => array( __CLASS__, 'check_permission' ),
			)
		);
	}

	/**
	 * Check permission
	 */
	public static function check_permission() {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Handle config GET/POST requests
	 */
	public static function handle_config_request( $request ) {
		if ( 'GET' === $request->get_method() ) {
			$config = get_option( self::OPTION_PREFIX . 'config', self::DEFAULT_CONFIG );
			return rest_ensure_response( $config );
		}

		$section = sanitize_text_field( $request->get_param( 'section' ) );
		$data = $request->get_json_params();

		if ( ! $section || ! isset( $data['values'] ) ) {
			return new WP_Error( 'invalid_request', 'Invalid request parameters' );
		}

		$config = get_option( self::OPTION_PREFIX . 'config', self::DEFAULT_CONFIG );
		$config[ $section ] = $data['values'];

		update_option( self::OPTION_PREFIX . 'config', $config );

		return rest_ensure_response( array(
			'success'  => true,
			'message'  => sprintf( esc_html__( '%s saved successfully', 'themeflex' ), $section ),
			'config'   => $config,
		) );
	}

	/**
	 * Reset section to defaults
	 */
	public static function reset_section( $request ) {
		$section = sanitize_text_field( $request->get_param( 'section' ) );

		if ( ! $section ) {
			return new WP_Error( 'invalid_section', 'Invalid section' );
		}

		$config = get_option( self::OPTION_PREFIX . 'config', self::DEFAULT_CONFIG );

		// Get default for section
		$method = 'get_default_' . $section;
		if ( method_exists( __CLASS__, $method ) ) {
			$config[ $section ] = self::$method();
		} else {
			return new WP_Error( 'invalid_section', 'Section not found' );
		}

		update_option( self::OPTION_PREFIX . 'config', $config );

		return rest_ensure_response( array(
			'success'  => true,
			'message'  => sprintf( esc_html__( '%s reset to defaults', 'themeflex' ), $section ),
			'config'   => $config,
		) );
	}

	/**
	 * Export configuration as JSON
	 */
	public static function export_config() {
		$config = get_option( self::OPTION_PREFIX . 'config', self::DEFAULT_CONFIG );

		return rest_ensure_response( array(
			'success' => true,
			'data'    => $config,
			'timestamp' => time(),
		) );
	}

	/**
	 * Import configuration from JSON
	 */
	public static function import_config( $request ) {
		$data = $request->get_json_params();

		if ( ! isset( $data['config'] ) || ! is_array( $data['config'] ) ) {
			return new WP_Error( 'invalid_data', 'Invalid configuration data' );
		}

		update_option( self::OPTION_PREFIX . 'config', $data['config'] );

		return rest_ensure_response( array(
			'success'  => true,
			'message'  => esc_html__( 'Configuration imported successfully', 'themeflex' ),
			'config'   => $data['config'],
		) );
	}

	/**
	 * Enqueue admin assets
	 */
	public static function enqueue_admin_assets( $hook ) {
		if ( 'appearance_page_sf_design_system' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'wp-color-picker'
		);

		wp_enqueue_script(
			'wp-color-picker'
		);

		wp_enqueue_style(
			'themeflex-design-system',
			THEMEFLEX_URL . '/assets/css/design-system.css',
			array(),
			THEMEFLEX_VERSION
		);

		wp_enqueue_script(
			'themeflex-design-system',
			THEMEFLEX_URL . '/assets/js/design-system.js',
			array( 'wp-color-picker', 'wp-api', 'jquery' ),
			THEMEFLEX_VERSION,
			true
		);

		wp_localize_script(
			'themeflex-design-system',
			'designSystemData',
			array(
				'apiUrl'       => rest_url( 'themeflex/v1/design-system/' ),
				'nonce'        => wp_create_nonce( 'wp_rest' ),
				'defaultConfig' => self::DEFAULT_CONFIG,
			)
		);
	}

	/**
	 * Enqueue frontend CSS
	 */
	public static function enqueue_frontend_css() {
		wp_enqueue_style(
			'themeflex-design-system-frontend',
			THEMEFLEX_URL . '/assets/css/design-system-frontend.css',
			array(),
			THEMEFLEX_VERSION
		);
	}

	/**
	 * Output CSS variables in wp_head
	 */
	public static function output_css_variables() {
		$config = get_option( self::OPTION_PREFIX . 'config', self::DEFAULT_CONFIG );

		echo '<style id="sf-design-system-variables">';
		echo ':root {';

		// Colors
		if ( ! empty( $config['colors'] ) ) {
			foreach ( $config['colors'] as $name => $value ) {
				echo '--sf-color-' . esc_attr( $name ) . ':' . esc_attr( $value ) . ';';
			}
		}

		// Spacing
		if ( ! empty( $config['spacing'] ) ) {
			foreach ( $config['spacing'] as $name => $value ) {
				echo '--sf-space-' . esc_attr( $name ) . ':' . esc_attr( $value ) . ';';
			}
		}

		// Border radius
		if ( ! empty( $config['borders']['radius'] ) ) {
			foreach ( $config['borders']['radius'] as $name => $value ) {
				echo '--sf-radius-' . esc_attr( $name ) . ':' . esc_attr( $value ) . ';';
			}
		}

		// Shadows
		if ( ! empty( $config['shadows'] ) ) {
			foreach ( $config['shadows'] as $name => $value ) {
				echo '--sf-shadow-' . esc_attr( $name ) . ':' . esc_attr( $value ) . ';';
			}
		}

		// Layout
		if ( ! empty( $config['layout'] ) ) {
			foreach ( $config['layout'] as $name => $value ) {
				echo '--sf-' . esc_attr( $name ) . ':' . esc_attr( $value ) . ';';
			}
		}

		// Typography
		if ( ! empty( $config['typography'] ) ) {
			foreach ( $config['typography'] as $element => $props ) {
				echo '--sf-' . esc_attr( $element ) . '-font-family:' . esc_attr( $props['font_family'] ) . ';';
				echo '--sf-' . esc_attr( $element ) . '-size:' . esc_attr( $props['size_desktop'] ) . ';';
				echo '--sf-' . esc_attr( $element ) . '-weight:' . esc_attr( $props['weight'] ) . ';';
				echo '--sf-' . esc_attr( $element ) . '-line-height:' . esc_attr( $props['line_height'] ) . ';';
			}
		}

		echo '}';
		echo '</style>';
	}

	/**
	 * Render admin page
	 */
	public static function render_admin_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized', 'themeflex' ) );
		}

		?>
		<div class="wrap sf-design-system-wrap">
			<h1><?php esc_html_e( 'ThemeFlex Design System', 'themeflex' ); ?></h1>
			<p class="description"><?php esc_html_e( 'Manage your global design tokens and component styles', 'themeflex' ); ?></p>

			<div class="sf-ds-container">
				<!-- Sidebar Navigation -->
				<nav class="sf-ds-sidebar">
					<button class="sf-ds-nav-btn active" data-tab="colors">
						<span class="sf-ds-nav-icon">🎨</span>
						<?php esc_html_e( 'Colors', 'themeflex' ); ?>
					</button>
					<button class="sf-ds-nav-btn" data-tab="typography">
						<span class="sf-ds-nav-icon">✏️</span>
						<?php esc_html_e( 'Typography', 'themeflex' ); ?>
					</button>
					<button class="sf-ds-nav-btn" data-tab="spacing">
						<span class="sf-ds-nav-icon">📏</span>
						<?php esc_html_e( 'Spacing', 'themeflex' ); ?>
					</button>
					<button class="sf-ds-nav-btn" data-tab="borders">
						<span class="sf-ds-nav-icon">▬</span>
						<?php esc_html_e( 'Borders & Shadows', 'themeflex' ); ?>
					</button>
					<button class="sf-ds-nav-btn" data-tab="buttons">
						<span class="sf-ds-nav-icon">🔘</span>
						<?php esc_html_e( 'Buttons', 'themeflex' ); ?>
					</button>
					<button class="sf-ds-nav-btn" data-tab="layout">
						<span class="sf-ds-nav-icon">📐</span>
						<?php esc_html_e( 'Layout', 'themeflex' ); ?>
					</button>
					<hr class="sf-ds-nav-divider">
					<button class="sf-ds-nav-btn sf-ds-nav-secondary" data-action="export">
						<span class="sf-ds-nav-icon">⬇️</span>
						<?php esc_html_e( 'Export', 'themeflex' ); ?>
					</button>
					<button class="sf-ds-nav-btn sf-ds-nav-secondary" data-action="import">
						<span class="sf-ds-nav-icon">⬆️</span>
						<?php esc_html_e( 'Import', 'themeflex' ); ?>
					</button>
				</nav>

				<!-- Main Content -->
				<main class="sf-ds-main">
					<!-- Colors Tab -->
					<div class="sf-ds-section active" data-tab="colors">
						<div class="sf-ds-section-header">
							<h2><?php esc_html_e( 'Global Colors', 'themeflex' ); ?></h2>
							<button class="sf-ds-reset-btn" data-section="colors">
								<?php esc_html_e( 'Reset to Defaults', 'themeflex' ); ?>
							</button>
						</div>
						<p class="sf-ds-section-desc">
							<?php esc_html_e( 'Define your color palette. These colors will be available as CSS variables throughout your theme.', 'themeflex' ); ?>
						</p>
						<div class="sf-ds-colors-grid" id="sf-colors-container"></div>
					</div>

					<!-- Typography Tab -->
					<div class="sf-ds-section" data-tab="typography">
						<div class="sf-ds-section-header">
							<h2><?php esc_html_e( 'Typography', 'themeflex' ); ?></h2>
							<button class="sf-ds-reset-btn" data-section="typography">
								<?php esc_html_e( 'Reset to Defaults', 'themeflex' ); ?>
							</button>
						</div>
						<p class="sf-ds-section-desc">
							<?php esc_html_e( 'Configure font families, sizes, weights, and line heights for each element.', 'themeflex' ); ?>
						</p>
						<div class="sf-ds-typography" id="sf-typography-container"></div>
					</div>

					<!-- Spacing Tab -->
					<div class="sf-ds-section" data-tab="spacing">
						<div class="sf-ds-section-header">
							<h2><?php esc_html_e( 'Spacing Scale', 'themeflex' ); ?></h2>
							<button class="sf-ds-reset-btn" data-section="spacing">
								<?php esc_html_e( 'Reset to Defaults', 'themeflex' ); ?>
							</button>
						</div>
						<p class="sf-ds-section-desc">
							<?php esc_html_e( 'Define your spacing scale for consistent padding and margins throughout your design.', 'themeflex' ); ?>
						</p>
						<div class="sf-ds-spacing-grid" id="sf-spacing-container"></div>
					</div>

					<!-- Borders & Shadows Tab -->
					<div class="sf-ds-section" data-tab="borders">
						<div class="sf-ds-section-header">
							<h2><?php esc_html_e( 'Borders & Shadows', 'themeflex' ); ?></h2>
							<button class="sf-ds-reset-btn" data-section="borders">
								<?php esc_html_e( 'Reset to Defaults', 'themeflex' ); ?>
							</button>
						</div>
						<p class="sf-ds-section-desc">
							<?php esc_html_e( 'Configure border radius, shadows, and border styles.', 'themeflex' ); ?>
						</p>
						<div class="sf-ds-borders" id="sf-borders-container"></div>
					</div>

					<!-- Buttons Tab -->
					<div class="sf-ds-section" data-tab="buttons">
						<div class="sf-ds-section-header">
							<h2><?php esc_html_e( 'Button Styles', 'themeflex' ); ?></h2>
							<button class="sf-ds-reset-btn" data-section="buttons">
								<?php esc_html_e( 'Reset to Defaults', 'themeflex' ); ?>
							</button>
						</div>
						<p class="sf-ds-section-desc">
							<?php esc_html_e( 'Define button variants and their styles.', 'themeflex' ); ?>
						</p>
						<div class="sf-ds-buttons" id="sf-buttons-container"></div>
					</div>

					<!-- Layout Tab -->
					<div class="sf-ds-section" data-tab="layout">
						<div class="sf-ds-section-header">
							<h2><?php esc_html_e( 'Layout Settings', 'themeflex' ); ?></h2>
							<button class="sf-ds-reset-btn" data-section="layout">
								<?php esc_html_e( 'Reset to Defaults', 'themeflex' ); ?>
							</button>
						</div>
						<p class="sf-ds-section-desc">
							<?php esc_html_e( 'Configure container widths, padding, and spacing.', 'themeflex' ); ?>
						</p>
						<div class="sf-ds-layout" id="sf-layout-container"></div>
					</div>

					<!-- Save Status -->
					<div class="sf-ds-save-status" id="sf-save-status"></div>
				</main>
			</div>
		</div>
		<?php
	}
}

// Initialize
ThemeFlex_Design_System::init();
