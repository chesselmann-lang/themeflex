<?php
/**
 * Portfolio Custom Post Type — Complete Implementation
 * Masonry Grid, AJAX Filter, Meta Fields, Admin Columns, Shortcode.
 *
 * @package ThemeFlex
 * @since   1.0.0
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Portfolio {

    private static ?self $instance = null;
    const POST_TYPE = 'sf_portfolio';
    const TAXONOMY  = 'sf_portfolio_cat';

    public static function instance(): self {
        if (is_null(self::$instance)) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('init',                  [$this, 'register_post_type']);
        add_action('init',                  [$this, 'register_taxonomy']);
        add_action('add_meta_boxes',        [$this, 'add_meta_boxes']);
        add_action('save_post',             [$this, 'save_meta']);
        add_action('manage_'.self::POST_TYPE.'_posts_columns', [$this, 'admin_columns']);
        add_action('manage_'.self::POST_TYPE.'_posts_custom_column', [$this, 'admin_column_content'], 10, 2);
        add_action('wp_ajax_sf_portfolio_filter',        [$this, 'ajax_filter']);
        add_action('wp_ajax_nopriv_sf_portfolio_filter', [$this, 'ajax_filter']);
        add_action('wp_ajax_sf_portfolio_load_more',     [$this, 'ajax_load_more']);
        add_action('wp_ajax_nopriv_sf_portfolio_load_more', [$this, 'ajax_load_more']);
        add_shortcode('sf_portfolio',       [$this, 'shortcode']);
        add_action('wp_enqueue_scripts',    [$this, 'enqueue']);
    }

    // ── CPT Registration ─────────────────────────────────────────────────

    public function register_post_type(): void {
        register_post_type(self::POST_TYPE, [
            'labels' => [
                'name'               => __('Portfolio','themeflex'),
                'singular_name'      => __('Portfolio Item','themeflex'),
                'add_new_item'       => __('Add New Portfolio Item','themeflex'),
                'edit_item'          => __('Edit Portfolio Item','themeflex'),
                'new_item'           => __('New Portfolio Item','themeflex'),
                'view_item'          => __('View Portfolio Item','themeflex'),
                'search_items'       => __('Search Portfolio','themeflex'),
                'not_found'          => __('No portfolio items found','themeflex'),
                'not_found_in_trash' => __('No portfolio items in trash','themeflex'),
                'menu_name'          => __('Portfolio','themeflex'),
            ],
            'public'             => true,
            'show_in_menu'       => true,
            'menu_icon'          => 'dashicons-images-alt2',
            'menu_position'      => 5,
            'supports'           => ['title','editor','thumbnail','excerpt','page-attributes'],
            'has_archive'        => true,
            'rewrite'            => ['slug' => 'portfolio', 'with_front' => false],
            'show_in_rest'       => true,
            'taxonomies'         => [self::TAXONOMY],
        ]);
    }

    public function register_taxonomy(): void {
        register_taxonomy(self::TAXONOMY, self::POST_TYPE, [
            'labels' => [
                'name'          => __('Portfolio Categories','themeflex'),
                'singular_name' => __('Category','themeflex'),
                'search_items'  => __('Search Categories','themeflex'),
                'all_items'     => __('All Categories','themeflex'),
                'edit_item'     => __('Edit Category','themeflex'),
                'add_new_item'  => __('Add New Category','themeflex'),
            ],
            'hierarchical'      => true,
            'public'            => true,
            'show_admin_column' => true,
            'rewrite'           => ['slug' => 'portfolio-category'],
            'show_in_rest'      => true,
        ]);
    }

    // ── Meta Boxes ────────────────────────────────────────────────────────

    public function add_meta_boxes(): void {
        add_meta_box('sf_portfolio_meta', __('Portfolio Details','themeflex'), [$this, 'meta_box_html'], self::POST_TYPE, 'side', 'high');
    }

    public function meta_box_html(\WP_Post $post): void {
        wp_nonce_field('sf_portfolio_meta_nonce', 'sf_portfolio_meta_nonce');
        $client      = get_post_meta($post->ID, '_sf_client', true);
        $project_url = get_post_meta($post->ID, '_sf_project_url', true);
        $year        = get_post_meta($post->ID, '_sf_year', true);
        $services    = get_post_meta($post->ID, '_sf_services', true);
        $featured    = get_post_meta($post->ID, '_sf_featured', true);
        ?>
        <table class="form-table" style="width:100%">
            <tr><td style="padding:5px 0">
                <label style="font-weight:600"><?php esc_html_e('Client Name','themeflex'); ?></label><br>
                <input type="text" name="sf_client" value="<?php echo esc_attr($client); ?>" style="width:100%;margin-top:4px" />
            </td></tr>
            <tr><td style="padding:5px 0">
                <label style="font-weight:600"><?php esc_html_e('Project URL','themeflex'); ?></label><br>
                <input type="url" name="sf_project_url" value="<?php echo esc_url($project_url); ?>" placeholder="https://" style="width:100%;margin-top:4px" />
            </td></tr>
            <tr><td style="padding:5px 0">
                <label style="font-weight:600"><?php esc_html_e('Year','themeflex'); ?></label><br>
                <input type="number" name="sf_year" value="<?php echo esc_attr($year); ?>" placeholder="<?php echo date('Y'); ?>" style="width:100%;margin-top:4px" />
            </td></tr>
            <tr><td style="padding:5px 0">
                <label style="font-weight:600"><?php esc_html_e('Services (comma separated)','themeflex'); ?></label><br>
                <input type="text" name="sf_services" value="<?php echo esc_attr($services); ?>" placeholder="Branding, Web Design, SEO" style="width:100%;margin-top:4px" />
            </td></tr>
            <tr><td style="padding:5px 0">
                <label><input type="checkbox" name="sf_featured" value="1" <?php checked($featured,'1'); ?> />
                <?php esc_html_e('Featured (show wide in grid)','themeflex'); ?></label>
            </td></tr>
        </table>
        <?php
    }

    public function save_meta(int $post_id): void {
        if (!isset($_POST['sf_portfolio_meta_nonce']) || !wp_verify_nonce($_POST['sf_portfolio_meta_nonce'], 'sf_portfolio_meta_nonce')) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!current_user_can('edit_post', $post_id)) return;

        $fields = ['sf_client' => '_sf_client', 'sf_project_url' => '_sf_project_url', 'sf_year' => '_sf_year', 'sf_services' => '_sf_services'];
        foreach ($fields as $post_key => $meta_key) {
            if (isset($_POST[$post_key])) {
                update_post_meta($post_id, $meta_key, sanitize_text_field($_POST[$post_key]));
            }
        }
        update_post_meta($post_id, '_sf_featured', isset($_POST['sf_featured']) ? '1' : '0');
    }

    // ── Admin Columns ─────────────────────────────────────────────────────

    public function admin_columns(array $columns): array {
        $new = [];
        foreach ($columns as $k => $v) {
            $new[$k] = $v;
            if ('title' === $k) {
                $new['thumbnail'] = __('Thumbnail','themeflex');
                $new['client']    = __('Client','themeflex');
                $new['year']      = __('Year','themeflex');
                $new['featured']  = __('Featured','themeflex');
            }
        }
        return $new;
    }

    public function admin_column_content(string $column, int $post_id): void {
        switch ($column) {
            case 'thumbnail':
                echo get_the_post_thumbnail($post_id, [60,60]);
                break;
            case 'client':
                echo esc_html(get_post_meta($post_id, '_sf_client', true) ?: '—');
                break;
            case 'year':
                echo esc_html(get_post_meta($post_id, '_sf_year', true) ?: '—');
                break;
            case 'featured':
                echo get_post_meta($post_id, '_sf_featured', true) === '1' ? '⭐' : '—';
                break;
        }
    }

    // ── AJAX Handlers ─────────────────────────────────────────────────────

    public function ajax_filter(): void {
        check_ajax_referer('sf_portfolio_nonce', 'nonce');
        $cat    = sanitize_text_field($_POST['category'] ?? '');
        $cols   = (int)($_POST['columns'] ?? 3);
        $limit  = (int)($_POST['limit'] ?? 12);

        $args = [
            'post_type'      => self::POST_TYPE,
            'posts_per_page' => $limit,
            'post_status'    => 'publish',
            'orderby'        => 'menu_order date',
            'order'          => 'ASC',
        ];
        if ($cat && $cat !== '*') {
            $args['tax_query'] = [['taxonomy' => self::TAXONOMY, 'field' => 'slug', 'terms' => $cat]];
        }

        $query = new WP_Query($args);
        ob_start();
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $this->render_card($cols);
            }
        }
        wp_reset_postdata();
        $html = ob_get_clean();
        wp_send_json_success(['html' => $html, 'found' => $query->found_posts]);
    }

    public function ajax_load_more(): void {
        check_ajax_referer('sf_portfolio_nonce', 'nonce');
        $page  = (int)($_POST['page'] ?? 2);
        $cat   = sanitize_text_field($_POST['category'] ?? '');
        $cols  = (int)($_POST['columns'] ?? 3);
        $limit = (int)($_POST['limit'] ?? 12);

        $args = ['post_type'=>self::POST_TYPE,'posts_per_page'=>$limit,'paged'=>$page,'post_status'=>'publish','orderby'=>'menu_order date','order'=>'ASC'];
        if ($cat && $cat !== '*') {
            $args['tax_query'] = [['taxonomy'=>self::TAXONOMY,'field'=>'slug','terms'=>$cat]];
        }

        $query = new WP_Query($args);
        ob_start();
        if ($query->have_posts()) {
            while ($query->have_posts()) { $query->the_post(); $this->render_card($cols); }
        }
        wp_reset_postdata();
        wp_send_json_success(['html'=>ob_get_clean(),'has_more'=>$page < $query->max_num_pages,'total_pages'=>$query->max_num_pages]);
    }

    // ── Card Rendering ────────────────────────────────────────────────────

    private function render_card(int $cols = 3): void {
        $featured = get_post_meta(get_the_ID(), '_sf_featured', true) === '1';
        $img_url  = get_the_post_thumbnail_url(get_the_ID(), 'large') ?: '';
        $client   = get_post_meta(get_the_ID(), '_sf_client', true);
        $services = get_post_meta(get_the_ID(), '_sf_services', true);
        $proj_url = get_post_meta(get_the_ID(), '_sf_project_url', true) ?: get_permalink();
        $cats     = get_the_terms(get_the_ID(), self::TAXONOMY);
        $cat_slugs = $cats ? implode(' ', array_column($cats, 'slug')) : '';
        ?>
        <div class="sf-port-item<?php echo $featured?' sf-port-featured':''; ?>" data-cats="<?php echo esc_attr($cat_slugs); ?>">
            <div class="sf-port-card">
                <div class="sf-port-img" style="<?php echo $img_url?'background-image:url('.esc_url($img_url).')':'background:var(--sf-gradient-soft,rgba(255,94,46,.1))'; ?>;background-size:cover;background-position:center;aspect-ratio:<?php echo $featured?'16/9':'4/3'; ?>;">
                    <div class="sf-port-overlay">
                        <div class="sf-port-overlay-inner">
                            <h3><?php the_title(); ?></h3>
                            <?php if($client): ?><span><?php echo esc_html($client); ?></span><?php endif; ?>
                            <?php if($services): ?><div class="sf-port-services"><?php echo esc_html($services); ?></div><?php endif; ?>
                            <a href="<?php echo esc_url($proj_url); ?>" class="sf-port-btn"><?php esc_html_e('View Project','themeflex'); ?> →</a>
                        </div>
                    </div>
                </div>
                <div class="sf-port-meta">
                    <h4><?php the_title(); ?></h4>
                    <?php if($cats): ?><span><?php echo esc_html(implode(', ', array_column($cats, 'name'))); ?></span><?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }

    // ── Shortcode ─────────────────────────────────────────────────────────

    public function shortcode(array $atts): string {
        $atts = shortcode_atts([
            'columns'  => 3,
            'limit'    => 12,
            'category' => '',
            'filter'   => 'yes',
            'load_more'=> 'yes',
        ], $atts, 'sf_portfolio');
        $cols  = (int)$atts['columns'];
        $limit = (int)$atts['limit'];

        $query_args = ['post_type'=>self::POST_TYPE,'posts_per_page'=>$limit,'post_status'=>'publish','orderby'=>'menu_order date','order'=>'ASC'];
        if ($atts['category']) {
            $query_args['tax_query'] = [['taxonomy'=>self::TAXONOMY,'field'=>'slug','terms'=>explode(',',str_replace(' ','',$atts['category']))]];
        }
        $query = new WP_Query($query_args);
        $cats  = get_terms(['taxonomy'=>self::TAXONOMY,'hide_empty'=>true]);

        ob_start();
        $uid = 'sfp-'.uniqid();
        ?>
        <div class="sf-portfolio-wrap" id="<?php echo esc_attr($uid); ?>"
            data-columns="<?php echo $cols; ?>" data-limit="<?php echo $limit; ?>" data-nonce="<?php echo wp_create_nonce('sf_portfolio_nonce'); ?>">
            <?php if('yes'===$atts['filter'] && !empty($cats) && !is_wp_error($cats)): ?>
            <div class="sf-port-filters">
                <button class="sf-port-filter active" data-cat="*"><?php esc_html_e('All Work','themeflex'); ?></button>
                <?php foreach($cats as $cat): ?>
                <button class="sf-port-filter" data-cat="<?php echo esc_attr($cat->slug); ?>"><?php echo esc_html($cat->name); ?> <span>(<?php echo (int)$cat->count; ?>)</span></button>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            <div class="sf-port-grid sf-port-cols-<?php echo $cols; ?>">
                <?php if($query->have_posts()): while($query->have_posts()): $query->the_post(); $this->render_card($cols); endwhile; endif; ?>
            </div>
            <div class="sf-port-empty" style="display:none;text-align:center;padding:60px;color:var(--sf-meta,#94a3b8);">
                <div style="font-size:48px;margin-bottom:12px;">🔍</div>
                <p><?php esc_html_e('No projects in this category.','themeflex'); ?></p>
            </div>
            <?php if('yes'===$atts['load_more'] && $query->max_num_pages > 1): ?>
            <div class="sf-port-more-wrap" style="text-align:center;margin-top:48px;">
                <button class="sf-port-load-more" data-page="2" data-max="<?php echo (int)$query->max_num_pages; ?>"><?php esc_html_e('Load More','themeflex'); ?></button>
            </div>
            <?php endif; ?>
        </div>
        <?php
        wp_reset_postdata();
        return ob_get_clean();
    }

    // ── Assets ────────────────────────────────────────────────────────────

    public function enqueue(): void {
        if (!is_post_type_archive(self::POST_TYPE) && !is_singular(self::POST_TYPE) && !has_shortcode(get_the_content(), 'sf_portfolio')) return;
        wp_add_inline_style('themeflex-style', $this->get_css());
        wp_add_inline_script('themeflex-custom', $this->get_js());
    }

    private function get_css(): string {
        return '
        .sf-port-filters{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:32px}
        .sf-port-filter{padding:8px 20px;border-radius:20px;border:1px solid var(--sf-border,#e5e7eb);background:transparent;color:var(--sf-text,#64748b);font-weight:600;font-size:13px;cursor:pointer;transition:all .2s}
        .sf-port-filter:hover,.sf-port-filter.active{background:var(--sf-color-primary,#FF5E2E);border-color:var(--sf-color-primary,#FF5E2E);color:#fff}
        .sf-port-grid{display:grid;gap:20px}
        .sf-port-cols-2{grid-template-columns:repeat(2,1fr)}
        .sf-port-cols-3{grid-template-columns:repeat(3,1fr)}
        .sf-port-cols-4{grid-template-columns:repeat(4,1fr)}
        .sf-port-featured{grid-column:span 2}
        .sf-port-card{border-radius:12px;overflow:hidden;position:relative}
        .sf-port-img{position:relative;overflow:hidden;transition:transform .4s ease}
        .sf-port-card:hover .sf-port-img{transform:scale(1.02)}
        .sf-port-overlay{position:absolute;inset:0;background:rgba(6,2,29,.85);opacity:0;transition:opacity .3s ease;display:flex;align-items:flex-end;padding:24px}
        .sf-port-card:hover .sf-port-overlay{opacity:1}
        .sf-port-overlay h3{color:#fff;font-size:18px;font-weight:800;margin:0 0 6px}
        .sf-port-overlay span{color:rgba(255,255,255,.65);font-size:13px}
        .sf-port-services{font-size:12px;color:var(--sf-color-primary,#FF5E2E);margin-top:4px}
        .sf-port-btn{display:inline-block;margin-top:14px;padding:8px 18px;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;border-radius:8px;font-size:13px;font-weight:700;text-decoration:none}
        .sf-port-meta{padding:14px 0}
        .sf-port-meta h4{font-size:15px;font-weight:700;color:var(--sf-title,#1e293b);margin:0 0 4px}
        .sf-port-meta span{font-size:12px;color:var(--sf-meta,#94a3b8)}
        .sf-port-load-more{padding:12px 32px;background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:10px;font-weight:700;font-size:15px;cursor:pointer;transition:all .2s;font-family:inherit}
        .sf-port-load-more:hover{background:var(--sf-color-primary,#FF5E2E);border-color:var(--sf-color-primary,#FF5E2E);color:#fff}
        .sf-port-item{animation:sfPortIn .35s ease forwards}
        @keyframes sfPortIn{from{opacity:0;transform:scale(.96)}to{opacity:1;transform:scale(1)}}
        @media(max-width:768px){.sf-port-cols-3,.sf-port-cols-4{grid-template-columns:repeat(2,1fr)}.sf-port-featured{grid-column:span 2}}
        @media(max-width:480px){.sf-port-cols-2,.sf-port-cols-3,.sf-port-cols-4{grid-template-columns:1fr}.sf-port-featured{grid-column:span 1}}
        ';
    }

    private function get_js(): string {
        return '
        document.querySelectorAll(".sf-portfolio-wrap").forEach(function(wrap){
            var ajaxUrl="'.esc_js(admin_url('admin-ajax.php')).'";
            var nonce=wrap.dataset.nonce;
            var cols=wrap.dataset.columns;
            var limit=wrap.dataset.limit;
            var currentCat="*";
            var grid=wrap.querySelector(".sf-port-grid");
            var empty=wrap.querySelector(".sf-port-empty");
            var moreWrap=wrap.querySelector(".sf-port-more-wrap");
            var moreBtn=wrap.querySelector(".sf-port-load-more");

            // Filter
            wrap.querySelectorAll(".sf-port-filter").forEach(function(btn){
                btn.addEventListener("click",function(){
                    wrap.querySelectorAll(".sf-port-filter").forEach(function(b){b.classList.remove("active");});
                    btn.classList.add("active");
                    currentCat=btn.dataset.cat;
                    grid.style.opacity=".4";
                    var fd=new FormData();
                    fd.append("action","sf_portfolio_filter");fd.append("nonce",nonce);
                    fd.append("category",currentCat==="*"?"":currentCat);
                    fd.append("columns",cols);fd.append("limit",limit);
                    fetch(ajaxUrl,{method:"POST",body:fd}).then(function(r){return r.json();}).then(function(res){
                        grid.innerHTML=res.data.html;grid.style.opacity="1";
                        if(empty)empty.style.display=res.data.found===0?"block":"none";
                        if(moreWrap)moreWrap.style.display="none";
                        if(moreBtn)moreBtn.dataset.page="2";
                    });
                });
            });

            // Load More
            if(moreBtn){moreBtn.addEventListener("click",function(){
                var page=parseInt(moreBtn.dataset.page)||2;
                var max=parseInt(moreBtn.dataset.max)||1;
                moreBtn.textContent="Loading…";moreBtn.disabled=true;
                var fd=new FormData();
                fd.append("action","sf_portfolio_load_more");fd.append("nonce",nonce);
                fd.append("category",currentCat==="*"?"":currentCat);
                fd.append("columns",cols);fd.append("limit",limit);fd.append("page",page);
                fetch(ajaxUrl,{method:"POST",body:fd}).then(function(r){return r.json();}).then(function(res){
                    grid.insertAdjacentHTML("beforeend",res.data.html);
                    moreBtn.textContent="Load More";moreBtn.disabled=false;
                    moreBtn.dataset.page=page+1;
                    if(!res.data.has_more)moreWrap.style.display="none";
                });
            });}
        });
        ';
    }
}

ThemeFlex_Portfolio::instance();
