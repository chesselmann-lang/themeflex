<?php
/**
 * SEO Features — Schema.org Structured Data + Open Graph / Twitter Cards.
 *
 * @package ThemeFlex
 * @since   1.1.0
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_SEO {

    private static ?self $instance = null;

    public static function instance(): self {
        if (is_null(self::$instance)) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        if (get_theme_mod('sf_enable_og_tags', true)) {
            add_action('wp_head', [$this, 'output_og_tags'], 5);
        }
        if (get_theme_mod('sf_enable_schema', true)) {
            add_action('wp_head', [$this, 'output_schema'], 6);
        }
        add_filter('document_title_separator', fn() => '—');
        add_action('wp_head', [$this, 'output_canonical'], 4);
    }

    // ── Canonical URL ─────────────────────────────────────────────────────

    public function output_canonical(): void {
        $url = '';
        if (is_singular())      $url = get_permalink();
        elseif (is_home())      $url = get_bloginfo('url') . '/';
        elseif (is_archive())   $url = get_the_archive_link();
        elseif (is_search())    $url = get_search_link();
        if ($url) echo '<link rel="canonical" href="'.esc_url($url).'" />'."\n";
    }

    // ── Open Graph Meta Tags ───────────────────────────────────────────────

    public function output_og_tags(): void {
        // Skip if a major SEO plugin is active
        if (defined('WPSEO_VERSION') || defined('RANK_MATH_VERSION') || defined('AIOSEOP_VERSION')) return;

        $site_name = get_bloginfo('name');
        $og_type   = 'website';
        $title     = wp_title('—', false);
        $desc      = get_bloginfo('description');
        $url       = home_url('/');
        $image     = get_theme_mod('sf_og_default_image', '');

        if (is_singular()) {
            $og_type = is_single() ? 'article' : 'website';
            $title   = get_the_title();
            $url     = get_permalink();
            $excerpt = get_the_excerpt();
            if ($excerpt) $desc = wp_strip_all_tags($excerpt);
            if (has_post_thumbnail()) {
                $img_data = wp_get_attachment_image_src(get_post_thumbnail_id(), 'large');
                if ($img_data) $image = $img_data[0];
            }
        } elseif (is_home() || is_front_page()) {
            $title = get_bloginfo('name');
            $desc  = get_bloginfo('description');
        }

        $desc = wp_trim_words($desc, 30, '…');

        echo "\n<!-- Open Graph -->\n";
        echo '<meta property="og:type" content="'.esc_attr($og_type).'" />'."\n";
        echo '<meta property="og:site_name" content="'.esc_attr($site_name).'" />'."\n";
        echo '<meta property="og:title" content="'.esc_attr($title).'" />'."\n";
        if ($desc) echo '<meta property="og:description" content="'.esc_attr($desc).'" />'."\n";
        echo '<meta property="og:url" content="'.esc_url($url).'" />'."\n";
        if ($image) {
            echo '<meta property="og:image" content="'.esc_url($image).'" />'."\n";
            echo '<meta property="og:image:width" content="1200" />'."\n";
            echo '<meta property="og:image:height" content="630" />'."\n";
        }
        if ('article' === $og_type) {
            echo '<meta property="article:published_time" content="'.esc_attr(get_the_date('c')).'" />'."\n";
            echo '<meta property="article:modified_time" content="'.esc_attr(get_the_modified_date('c')).'" />'."\n";
            $cats = get_the_category();
            if ($cats) echo '<meta property="article:section" content="'.esc_attr($cats[0]->name).'" />'."\n";
        }
        // Twitter Cards
        echo "\n<!-- Twitter Card -->\n";
        echo '<meta name="twitter:card" content="'.($image?'summary_large_image':'summary').'" />'."\n";
        echo '<meta name="twitter:title" content="'.esc_attr($title).'" />'."\n";
        if ($desc) echo '<meta name="twitter:description" content="'.esc_attr($desc).'" />'."\n";
        if ($image) echo '<meta name="twitter:image" content="'.esc_url($image).'" />'."\n";
        echo "\n";
    }

    // ── Schema.org JSON-LD ────────────────────────────────────────────────

    public function output_schema(): void {
        if (defined('WPSEO_VERSION') || defined('RANK_MATH_VERSION')) return;

        $schemas = [];

        // WebSite schema (always)
        $schemas[] = [
            '@context' => 'https://schema.org',
            '@type'    => 'WebSite',
            'name'     => get_bloginfo('name'),
            'url'      => home_url('/'),
            'potentialAction' => [
                '@type'       => 'SearchAction',
                'target'      => ['@type'=>'EntryPoint','urlTemplate'=>home_url('/?s={search_term_string}')],
                'query-input' => 'required name=search_term_string',
            ],
        ];

        // Organization / LocalBusiness
        $org_type  = get_theme_mod('sf_site_type', 'Organization');
        $org_logo  = get_theme_mod('custom_logo');
        $logo_url  = $org_logo ? wp_get_attachment_image_url($org_logo, 'full') : '';
        $org_schema = [
            '@context' => 'https://schema.org',
            '@type'    => $org_type,
            'name'     => get_bloginfo('name'),
            'url'      => home_url('/'),
            'description' => get_bloginfo('description'),
        ];
        if ($logo_url) $org_schema['logo'] = ['@type'=>'ImageObject','url'=>$logo_url];
        // Social links
        $socials = [];
        foreach(['facebook','twitter','instagram','linkedin','youtube','github'] as $soc) {
            $url = get_theme_mod("sf_social_{$soc}",'');
            if ($url) $socials[] = esc_url($url);
        }
        if ($socials) $org_schema['sameAs'] = $socials;
        $schemas[] = $org_schema;

        // BreadcrumbList
        $breadcrumbs = $this->get_breadcrumbs();
        if (count($breadcrumbs) > 1) {
            $items = [];
            foreach ($breadcrumbs as $i => $crumb) {
                $items[] = ['@type'=>'ListItem','position'=>$i+1,'name'=>esc_html($crumb['name']),'item'=>esc_url($crumb['url'])];
            }
            $schemas[] = ['@context'=>'https://schema.org','@type'=>'BreadcrumbList','itemListElement'=>$items];
        }

        // Article schema for single posts
        if (is_single() && !is_singular('product')) {
            $thumb_id  = get_post_thumbnail_id();
            $thumb_url = $thumb_id ? wp_get_attachment_image_url($thumb_id, 'large') : $logo_url;
            $author    = get_the_author_meta('display_name');
            $schemas[] = [
                '@context'      => 'https://schema.org',
                '@type'         => 'Article',
                'headline'      => get_the_title(),
                'datePublished' => get_the_date('c'),
                'dateModified'  => get_the_modified_date('c'),
                'author'        => ['@type'=>'Person','name'=>$author],
                'publisher'     => ['@type'=>'Organization','name'=>get_bloginfo('name'),'logo'=>['@type'=>'ImageObject','url'=>$logo_url]],
                'image'         => $thumb_url ?: '',
                'url'           => get_permalink(),
                'description'   => wp_trim_words(get_the_excerpt(), 30, '…'),
            ];
        }

        // Product schema
        if (is_singular('product') && class_exists('WC_Product')) {
            global $product;
            if (is_a($product, 'WC_Product')) {
                $schemas[] = [
                    '@context' => 'https://schema.org',
                    '@type'    => 'Product',
                    'name'     => $product->get_name(),
                    'image'    => wp_get_attachment_image_url($product->get_image_id(), 'large'),
                    'description' => wp_strip_all_tags($product->get_description()),
                    'sku'      => $product->get_sku(),
                    'offers'   => [
                        '@type'         => 'Offer',
                        'price'         => $product->get_price(),
                        'priceCurrency' => get_woocommerce_currency(),
                        'availability'  => $product->is_in_stock() ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
                        'url'           => get_permalink(),
                    ],
                ];
            }
        }

        // Portfolio schema
        if (is_singular('sf_portfolio')) {
            $schemas[] = [
                '@context'    => 'https://schema.org',
                '@type'       => 'CreativeWork',
                'name'        => get_the_title(),
                'description' => wp_trim_words(get_the_excerpt(), 30, '…'),
                'url'         => get_permalink(),
                'creator'     => ['@type'=>'Organization','name'=>get_bloginfo('name')],
                'dateCreated' => get_the_date('c'),
                'image'       => get_the_post_thumbnail_url(null,'large'),
            ];
        }

        // FAQ schema
        if (is_singular()) {
            $faq_items = get_post_meta(get_the_ID(), '_sf_faq_items', true);
            if (!empty($faq_items) && is_array($faq_items)) {
                $entries = [];
                foreach ($faq_items as $item) {
                    if (!empty($item['q']) && !empty($item['a'])) {
                        $entries[] = ['@type'=>'Question','name'=>esc_html($item['q']),'acceptedAnswer'=>['@type'=>'Answer','text'=>wp_strip_all_tags($item['a'])]];
                    }
                }
                if ($entries) {
                    $schemas[] = ['@context'=>'https://schema.org','@type'=>'FAQPage','mainEntity'=>$entries];
                }
            }
        }

        foreach ($schemas as $schema) {
            echo '<script type="application/ld+json">'.wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE).'</script>'."\n";
        }
    }

    private function get_breadcrumbs(): array {
        $crumbs = [['name'=>get_bloginfo('name'),'url'=>home_url('/')]];
        if (is_singular()) {
            if (is_single() && !is_singular(['sf_portfolio','product'])) {
                $cats = get_the_category();
                if ($cats) $crumbs[] = ['name'=>$cats[0]->name,'url'=>get_category_link($cats[0]->term_id)];
            }
            $crumbs[] = ['name'=>get_the_title(),'url'=>get_permalink()];
        } elseif (is_archive()) {
            $crumbs[] = ['name'=>get_the_archive_title(),'url'=>get_the_archive_link()];
        } elseif (is_search()) {
            $crumbs[] = ['name'=>sprintf(__('Search: %s','themeflex'), get_search_query()),'url'=>get_search_link()];
        }
        return $crumbs;
    }
}

ThemeFlex_SEO::instance();
