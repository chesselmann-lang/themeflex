<?php
/**
 * Audio Player Widget
 * @package ThemeFlex
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Audio_Player_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'audio_player'; }
    public function get_title() { return esc_html__('Audio Player','themeflex'); }
    public function get_icon()  { return 'eicon-play'; }
    public function get_categories() { return ['themeflex']; }
    public function get_keywords()   { return ['audio','player','podcast','music','mp3','sound']; }

    protected function register_controls() {
        $this->start_controls_section('s1',['label'=>'Track']);
        $this->add_control('track_title',['label'=>'Title','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Episode 01 — Getting Started']);
        $this->add_control('artist',['label'=>'Artist / Show','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'The Podcast']);
        $this->add_control('audio_url',['label'=>'Audio File URL','type'=>\Elementor\Controls_Manager::URL,'placeholder'=>'https://example.com/audio.mp3']);
        $this->add_control('cover_image',['label'=>'Cover Image','type'=>\Elementor\Controls_Manager::MEDIA]);
        $this->add_control('style',['label'=>'Style','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['minimal'=>'Minimal','card'=>'Card'],'default'=>'card']);
        $this->end_controls_section();
    }

    protected function render() {
        $s=\$this->get_settings_for_display();$uid='sfap-'.\$this->get_id();
        $src=!empty(\$s['audio_url']['url'])?esc_url(\$s['audio_url']['url']):'';
        $img=!empty(\$s['cover_image']['url'])?esc_url(\$s['cover_image']['url']):'';
        $card='card'===(\$s['style']??'card');
        ?>
        <div class="sf-audio-player<?php echo\$card?' sf-audio-card':'';?>" id="<?php echo esc_attr(\$uid);?>" style="<?php echo\$card?'background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:16px;padding:24px;':'';?>display:flex;align-items:center;gap:16px;max-width:560px;">
            <?php if(\$img&&\$card):?><img src="<?php echo\$img;?>" alt="" style="width:64px;height:64px;border-radius:10px;object-fit:cover;flex-shrink:0;" /><?php endif;?>
            <div style="flex:1;min-width:0;">
                <div style="font-weight:700;font-size:14px;color:var(--sf-title,#1e293b);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?php echo esc_html(\$s['track_title']);?></div>
                <div style="font-size:12px;color:var(--sf-meta,#94a3b8);margin-bottom:10px;"><?php echo esc_html(\$s['artist']);?></div>
                <?php if(\$src):?>
                <audio id="<?php echo esc_attr(\$uid);?>-audio" preload="metadata" style="display:none"><source src="<?php echo\$src;?>" /></audio>
                <div style="display:flex;align-items:center;gap:10px;">
                    <button id="<?php echo esc_attr(\$uid);?>-btn" onclick="sfApToggle('<?php echo esc_js(\$uid);?>')" style="width:36px;height:36px;border-radius:50%;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));border:none;color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:14px;">▶</button>
                    <div style="flex:1;height:4px;background:var(--sf-border,#e5e7eb);border-radius:2px;cursor:pointer;position:relative;" id="<?php echo esc_attr(\$uid);?>-bar" onclick="sfApSeek(event,'<?php echo esc_js(\$uid);?>')">
                        <div id="<?php echo esc_attr(\$uid);?>-prog" style="height:100%;width:0;background:var(--sf-gradient,linear-gradient(90deg,#FF5E2E,#00D4FF));border-radius:2px;transition:width .1s linear;pointer-events:none;"></div>
                    </div>
                    <span id="<?php echo esc_attr(\$uid);?>-time" style="font-size:11px;color:var(--sf-meta,#94a3b8);white-space:nowrap;min-width:36px;">0:00</span>
                </div>
                <?php endif;?>
            </div>
        </div>
        <?php if(\$src):?>
        <script>
        window.sfAp=window.sfAp||{};
        sfAp['<?php echo esc_js(\$uid);?>']=document.getElementById('<?php echo esc_js(\$uid);?>-audio');
        function sfApToggle(id){var a=sfAp[id];var btn=document.getElementById(id+'-btn');if(a.paused){a.play();btn.textContent='⏸';}else{a.pause();btn.textContent='▶';}}
        function sfApSeek(e,id){var a=sfAp[id];var bar=document.getElementById(id+'-bar');var r=bar.getBoundingClientRect();a.currentTime=((e.clientX-r.left)/r.width)*a.duration;}
        (function(){var a=document.getElementById('<?php echo esc_js(\$uid);?>-audio');var p=document.getElementById('<?php echo esc_js(\$uid);?>-prog');var t=document.getElementById('<?php echo esc_js(\$uid);?>-time');a.addEventListener('timeupdate',function(){var pct=a.duration?(a.currentTime/a.duration*100):0;p.style.width=pct+'%';var m=Math.floor(a.currentTime/60),s=Math.floor(a.currentTime%60);t.textContent=m+':'+(s<10?'0':'')+s;});})();
        </script>
        <?php endif;?><?php
    }
}
