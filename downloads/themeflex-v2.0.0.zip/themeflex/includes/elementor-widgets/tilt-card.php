<?php
/**
 * 3D Tilt Card Widget
 * @package ThemeFlex
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Tilt_Card_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'tilt_card'; }
    public function get_title() { return esc_html__('3D Tilt Card','themeflex'); }
    public function get_icon()  { return 'eicon-image-box'; }
    public function get_categories() { return ['themeflex']; }
    public function get_keywords()   { return ['3d','tilt','card','hover','effect','interactive']; }

    protected function register_controls() {
        $this->start_controls_section('s1',['label'=>'Content']);
        $this->add_control('icon',['label'=>'Icon','type'=>\Elementor\Controls_Manager::ICONS]);
        $this->add_control('title',['label'=>'Title','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Premium Feature']);
        $this->add_control('description',['label'=>'Description','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>'An impressive 3D hover effect that makes your cards stand out.']);
        $this->add_control('badge',['label'=>'Badge','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'NEW']);
        $this->add_control('tilt_max',['label'=>'Max Tilt (°)','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['px'=>['min'=>5,'max'=>30]],'default'=>['size'=>15]]);
        $this->add_control('glow',['label'=>'Glow Effect','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes']);
        $this->end_controls_section();
        $this->start_controls_section('s2',['label'=>'Style','tab'=>\Elementor\Controls_Manager::TAB_STYLE]);
        $this->add_control('card_bg',['label'=>'Background','type'=>\Elementor\Controls_Manager::COLOR,'selectors'=>['{{WRAPPER}} .sf-tilt-card'=>'background:{{VALUE}};']]);
        $this->end_controls_section();
    }

    protected function render() {
        $s=\$this->get_settings_for_display();$uid='sftc-'.\$this->get_id();
        $icon=!empty(\$s['icon']['value'])?\$s['icon']['value']:'';
        $tilt=(float)(\$s['tilt_max']['size']??15);
        $glow='yes'===(\$s['glow']??'yes');
        ?>
        <div class="sf-tilt-card" id="<?php echo esc_attr(\$uid);?>" style="background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:16px;padding:32px 24px;position:relative;overflow:hidden;transform-style:preserve-3d;transform:perspective(1000px) rotateX(0) rotateY(0);transition:transform .1s ease,box-shadow .2s ease;cursor:default;">
            <?php if(\$s['badge']):?><span style="position:absolute;top:16px;right:16px;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;font-size:10px;font-weight:800;padding:3px 8px;border-radius:4px;letter-spacing:.5px;"><?php echo esc_html(\$s['badge']);?></span><?php endif;?>
            <?php if(\$icon):?>
            <div style="width:56px;height:56px;border-radius:14px;background:var(--sf-gradient-soft,rgba(255,94,46,.1));display:flex;align-items:center;justify-content:center;font-size:24px;color:var(--sf-color-primary,#FF5E2E);margin-bottom:20px;transform:translateZ(20px);">
                <i class="<?php echo esc_attr(\$icon);?>" aria-hidden="true"></i>
            </div>
            <?php endif;?>
            <h4 style="font-size:1.1rem;font-weight:800;color:var(--sf-title,#1e293b);margin-bottom:10px;transform:translateZ(15px);"><?php echo esc_html(\$s['title']);?></h4>
            <p style="font-size:14px;color:var(--sf-text,#64748b);line-height:1.7;margin:0;transform:translateZ(10px);"><?php echo esc_html(\$s['description']);?></p>
            <?php if(\$glow):?><div id="<?php echo esc_attr(\$uid);?>-glow" style="position:absolute;width:200px;height:200px;border-radius:50%;background:radial-gradient(circle,rgba(255,94,46,.15),transparent);pointer-events:none;transform:translate(-50%,-50%);transition:opacity .2s;opacity:0;left:50%;top:50%;"></div><?php endif;?>
        </div>
        <script>
        (function(){
            var card=document.getElementById('<?php echo esc_js(\$uid);?>');
            var glow=document.getElementById('<?php echo esc_js(\$uid);?>-glow');
            var max=<?php echo (int)(\$tilt*10)/10;?>;
            if(!card)return;
            card.addEventListener('mousemove',function(e){
                var r=card.getBoundingClientRect();
                var cx=(e.clientX-r.left)/r.width-.5;
                var cy=(e.clientY-r.top)/r.height-.5;
                card.style.transform='perspective(1000px) rotateY('+(cx*max*2)+'deg) rotateX('+(-cy*max*2)+'deg) scale(1.02)';
                card.style.boxShadow='0 20px 60px rgba(0,0,0,.15)';
                if(glow){glow.style.left=(e.clientX-r.left)+'px';glow.style.top=(e.clientY-r.top)+'px';glow.style.opacity='1';}
            });
            card.addEventListener('mouseleave',function(){
                card.style.transform='perspective(1000px) rotateX(0) rotateY(0) scale(1)';
                card.style.boxShadow='';
                if(glow)glow.style.opacity='0';
            });
        })();
        </script>
        <?php
    }
}
