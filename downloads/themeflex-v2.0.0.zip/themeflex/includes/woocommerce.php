<?php
/**
 * WooCommerce Support Functions
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add WooCommerce support to theme
 *
 * @since 1.0.0
 */
function themeflex_woocommerce_setup() {
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
	add_theme_support( 'wc-product-gallery-lightbox-v2' );
}
add_action( 'after_setup_theme', 'themeflex_woocommerce_setup' );

/**
 * Register WooCommerce widget areas
 *
 * @since 1.0.0
 */
function themeflex_woocommerce_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'WooCommerce Sidebar', 'themeflex' ),
		'id'            => 'woocommerce-sidebar',
		'description'   => esc_html__( 'Sidebar for WooCommerce pages', 'themeflex' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'themeflex_woocommerce_widgets_init' );

/**
 * Enqueue WooCommerce styles and scripts
 *
 * @since 1.0.0
 */
function themeflex_woocommerce_enqueue_scripts() {
	if ( is_woocommerce() || is_cart() || is_checkout() ) {
		wp_enqueue_style(
			'themeflex-woocommerce',
			THEMEFLEX_URL . '/assets/css/woocommerce.css',
			array(),
			THEMEFLEX_VERSION
		);

		wp_enqueue_script(
			'themeflex-woocommerce',
			THEMEFLEX_URL . '/assets/js/woocommerce.js',
			array( 'jquery', 'wp-util' ),
			THEMEFLEX_VERSION,
			true
		);

		wp_localize_script(
			'themeflex-woocommerce',
			'starterFlavorWoo',
			array(
				'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'themeflex-woo' ),
				'currency' => get_woocommerce_currency(),
			)
		);
	}
}
add_action( 'wp_enqueue_scripts', 'themeflex_woocommerce_enqueue_scripts' );

/**
 * Remove default WooCommerce sidebar
 *
 * @since 1.0.0
 */
function themeflex_remove_woocommerce_sidebar() {
	remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar' );
}
add_action( 'init', 'themeflex_remove_woocommerce_sidebar' );

/**
 * Add custom WooCommerce sidebar
 *
 * @since 1.0.0
 */
function themeflex_woocommerce_sidebar() {
	$show_sidebar = themeflex_get_theme_option( 'woo_show_sidebar', true );

	if ( ! $show_sidebar ) {
		return;
	}

	if ( is_active_sidebar( 'woocommerce-sidebar' ) ) {
		echo '<aside class="woocommerce-sidebar">';
		dynamic_sidebar( 'woocommerce-sidebar' );
		echo '</aside>';
	}
}
add_action( 'woocommerce_sidebar', 'themeflex_woocommerce_sidebar' );

/**
 * Add body class for WooCommerce pages
 *
 * @since 1.0.0
 */
function themeflex_woocommerce_body_classes( $classes ) {
	if ( class_exists( 'WooCommerce' ) ) {
		if ( is_woocommerce() ) {
			$classes[] = 'woocommerce-page';
		}
		if ( is_product() ) {
			$classes[] = 'woocommerce-single-product';
		}
		if ( is_cart() ) {
			$classes[] = 'woocommerce-cart-page';
		}
		if ( is_checkout() ) {
			$classes[] = 'woocommerce-checkout-page';
		}
		if ( is_account_page() ) {
			$classes[] = 'woocommerce-account-page';
		}

		// Add sidebar class
		if ( themeflex_get_theme_option( 'woo_show_sidebar', true ) ) {
			$classes[] = 'woocommerce-with-sidebar';
		} else {
			$classes[] = 'woocommerce-no-sidebar';
		}
	}
	return $classes;
}
add_filter( 'body_class', 'themeflex_woocommerce_body_classes' );

/**
 * Customize WooCommerce product per page
 *
 * @since 1.0.0
 */
function themeflex_woocommerce_products_per_page( $products_per_page ) {
	return intval( themeflex_get_theme_option( 'woo_products_per_page', 12 ) );
}
add_filter( 'loop_shop_per_page', 'themeflex_woocommerce_products_per_page' );

/**
 * Customize WooCommerce shop columns
 *
 * @since 1.0.0
 */
function themeflex_woocommerce_loop_columns() {
	return intval( themeflex_get_theme_option( 'woo_shop_columns', 3 ) );
}
add_filter( 'loop_shop_columns', 'themeflex_woocommerce_loop_columns' );

/**
 * Get WooCommerce product image size
 *
 * @since 1.0.0
 * @return array Product image dimensions.
 */
function themeflex_woocommerce_product_image_size() {
	return array(
		'width'  => 370,
		'height' => 370,
	);
}

/**
 * Customize WooCommerce breadcrumb
 *
 * @since 1.0.0
 */
function themeflex_woocommerce_breadcrumb_args( $args ) {
	$args['delimiter'] = ' / ';
	$args['wrap_before'] = '<nav class="woocommerce-breadcrumb">';
	$args['wrap_after'] = '</nav>';
	return $args;
}
add_filter( 'woocommerce_breadcrumb_defaults', 'themeflex_woocommerce_breadcrumb_args' );

/**
 * Customize WooCommerce product title
 *
 * @since 1.0.0
 */
function themeflex_woocommerce_product_title() {
	echo '<h2 class="woocommerce-product-title">';
	the_title();
	echo '</h2>';
}

/**
 * Add custom product rating template tag
 *
 * @since 1.0.0
 * @param int $product_id The product ID.
 * @return string The rating HTML.
 */
function themeflex_get_product_rating( $product_id = 0 ) {
	if ( empty( $product_id ) ) {
		$product_id = get_the_ID();
	}

	if ( ! class_exists( 'WC_Product' ) ) {
		return '';
	}

	$product = wc_get_product( $product_id );

	if ( ! $product ) {
		return '';
	}

	$rating = $product->get_average_rating();

	if ( ! $rating ) {
		return '';
	}

	$rating_html = '<div class="product-rating">';
	$rating_html .= '<span class="rating-score">' . esc_html( $rating ) . '</span>';
	$rating_html .= '<span class="rating-stars">';

	for ( $i = 0; $i < 5; $i++ ) {
		if ( $i < $rating ) {
			$rating_html .= '<span class="star star-filled">★</span>';
		} else {
			$rating_html .= '<span class="star">☆</span>';
		}
	}

	$rating_html .= '</span>';
	$rating_html .= '</div>';

	return $rating_html;
}

/**
 * Add to cart button customization
 *
 * @since 1.0.0
 */
function themeflex_woocommerce_loop_add_to_cart_args( $args ) {
	$args['class'] = 'button button-primary add_to_cart_button';
	return $args;
}
add_filter( 'woocommerce_loop_add_to_cart_args', 'themeflex_woocommerce_loop_add_to_cart_args' );

/**
 * Empty cart message customization
 *
 * @since 1.0.0
 */
function themeflex_woocommerce_empty_cart_message() {
	$shop_page_url = wc_get_page_permalink( 'shop' );
	echo '<p>' . esc_html__( 'Your cart is currently empty.', 'themeflex' ) . '</p>';
	echo '<a href="' . esc_url( $shop_page_url ) . '" class="button button-primary">' . esc_html__( 'Return to shop', 'themeflex' ) . '</a>';
}
add_filter( 'woocommerce_empty_cart_message', 'themeflex_woocommerce_empty_cart_message' );

/**
 * Customize product sale badge with percentage discount
 *
 * @since 1.0.0
 */
function themeflex_woocommerce_sale_flash( $html, $post, $product ) {
	if ( ! $product->is_on_sale() ) {
		return $html;
	}

	$show_badge_type = themeflex_get_theme_option( 'woo_badge_type', 'text' );

	if ( 'percentage' === $show_badge_type && $product->is_type( 'variable' ) === false ) {
		// For simple/grouped products, calculate percentage discount
		$regular_price = (float) $product->get_regular_price();
		$sale_price = (float) $product->get_sale_price();

		if ( $regular_price > 0 ) {
			$discount = round( ( ( $regular_price - $sale_price ) / $regular_price ) * 100 );
			$badge_text = '-' . $discount . '%';
		} else {
			$badge_text = esc_html__( 'Sale', 'themeflex' );
		}
	} else {
		$badge_text = esc_html__( 'Sale', 'themeflex' );
	}

	$html = '<span class="onsale product-badge product-badge-sale">' . esc_html( $badge_text ) . '</span>';

	return $html;
}
add_filter( 'woocommerce_sale_flash', 'themeflex_woocommerce_sale_flash', 10, 3 );

/**
 * Display "New" badge for products
 *
 * @since 1.0.0
 */
function themeflex_woocommerce_new_product_badge() {
	if ( ! themeflex_get_theme_option( 'woo_show_new_badge', true ) ) {
		return;
	}

	global $post;
	$days = intval( themeflex_get_theme_option( 'woo_new_badge_days', 14 ) );
	$created = strtotime( $post->post_date_gmt );
	$now = current_time( 'timestamp' );

	if ( ( $now - $created ) < ( $days * 24 * 60 * 60 ) ) {
		echo '<span class="product-badge product-badge-new">' . esc_html__( 'New', 'themeflex' ) . '</span>';
	}
}
add_action( 'woocommerce_product_loop_start', 'themeflex_woocommerce_new_product_badge' );

/**
 * Display "Hot" badge for best sellers
 *
 * @since 1.0.0
 */
function themeflex_woocommerce_hot_product_badge() {
	if ( ! themeflex_get_theme_option( 'woo_show_hot_badge', false ) ) {
		return;
	}

	global $product;

	// Get total sales from product meta
	$total_sales = get_post_meta( $product->get_id(), 'total_sales', true );
	$hot_threshold = intval( themeflex_get_theme_option( 'woo_hot_badge_threshold', 50 ) );

	if ( intval( $total_sales ) >= $hot_threshold ) {
		echo '<span class="product-badge product-badge-hot">' . esc_html__( 'Hot', 'themeflex' ) . '</span>';
	}
}
add_action( 'woocommerce_product_loop_start', 'themeflex_woocommerce_hot_product_badge' );

/**
 * Display "Out of Stock" badge
 *
 * @since 1.0.0
 */
function themeflex_woocommerce_out_of_stock_badge() {
	if ( ! themeflex_get_theme_option( 'woo_show_stock_badge', true ) ) {
		return;
	}

	global $product;

	if ( ! $product->is_in_stock() ) {
		echo '<span class="product-badge product-badge-out-of-stock">' . esc_html__( 'Out of Stock', 'themeflex' ) . '</span>';
	}
}
add_action( 'woocommerce_product_loop_start', 'themeflex_woocommerce_out_of_stock_badge' );

/**
 * Add quick view button to products
 *
 * @since 1.0.0
 */
function themeflex_product_quick_view_button() {
	if ( ! themeflex_get_theme_option( 'woo_show_quick_view', true ) ) {
		return;
	}

	global $product;
	$product_id = $product->get_id();

	echo sprintf(
		'<button class="button quick-view-button" data-product-id="%d" title="%s">%s</button>',
		esc_attr( $product_id ),
		esc_attr__( 'Quick View', 'themeflex' ),
		esc_html__( 'Quick View', 'themeflex' )
	);
}
add_action( 'woocommerce_after_shop_loop_item', 'themeflex_product_quick_view_button', 12 );

/**
 * Add wishlist button to products
 *
 * @since 1.0.0
 */
function themeflex_product_wishlist_button() {
	if ( ! themeflex_get_theme_option( 'woo_show_wishlist', false ) ) {
		return;
	}

	global $product;
	$product_id = $product->get_id();

	echo sprintf(
		'<button class="button wishlist-button" data-product-id="%d" title="%s"><span class="icon">♡</span></button>',
		esc_attr( $product_id ),
		esc_attr__( 'Add to Wishlist', 'themeflex' )
	);
}
add_action( 'woocommerce_after_shop_loop_item', 'themeflex_product_wishlist_button', 13 );

/**
 * AJAX Quick View Handler
 *
 * @since 1.0.0
 */
function themeflex_quick_view_ajax() {
	check_ajax_referer( 'themeflex-woo', 'nonce' );

	if ( ! isset( $_POST['product_id'] ) ) {
		wp_send_json_error( 'No product ID' );
	}

	$product_id = intval( $_POST['product_id'] );
	$product = wc_get_product( $product_id );

	if ( ! $product ) {
		wp_send_json_error( 'Product not found' );
	}

	ob_start();
	?>
	<div class="quick-view-modal-content">
		<div class="qv-image">
			<?php echo $product->get_image( 'medium' ); ?>
		</div>
		<div class="qv-details">
			<h2><?php echo esc_html( $product->get_name() ); ?></h2>
			<div class="qv-rating">
				<?php wc_get_template( 'single-product/rating.php' ); ?>
			</div>
			<div class="qv-price">
				<?php echo wp_kses_post( $product->get_price_html() ); ?>
			</div>
			<div class="qv-description">
				<?php echo wp_kses_post( wp_trim_words( $product->get_description(), 20 ) ); ?>
			</div>
			<div class="qv-add-to-cart">
				<?php wc_template_loop_add_to_cart(); ?>
			</div>
			<div class="qv-link">
				<a href="<?php echo esc_url( $product->get_permalink() ); ?>" class="button button-secondary">
					<?php esc_html_e( 'View Details', 'themeflex' ); ?>
				</a>
			</div>
		</div>
	</div>
	<?php
	$html = ob_get_clean();

	wp_send_json_success( array( 'html' => $html ) );
}
add_action( 'wp_ajax_themeflex_quick_view', 'themeflex_quick_view_ajax' );
add_action( 'wp_ajax_nopriv_themeflex_quick_view', 'themeflex_quick_view_ajax' );

/**
 * Add mini cart in header with AJAX support
 *
 * @since 1.0.0
 */
function themeflex_header_mini_cart() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}

	if ( ! themeflex_get_theme_option( 'woo_show_mini_cart', true ) ) {
		return;
	}
	?>
	<div class="header-cart-widget">
		<a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="cart-link" title="<?php esc_attr_e( 'Shopping Cart', 'themeflex' ); ?>">
			<span class="cart-icon">🛒</span>
			<span class="cart-count"><?php echo esc_html( WC()->cart->get_cart_contents_count() ); ?></span>
		</a>
		<div class="mini-cart-dropdown" id="mini-cart-contents">
			<div class="mini-cart-loading">
				<?php esc_html_e( 'Loading...', 'themeflex' ); ?>
			</div>
		</div>
	</div>
	<?php
}

/**
 * AJAX Mini Cart Update
 *
 * @since 1.0.0
 */
function themeflex_update_mini_cart() {
	check_ajax_referer( 'themeflex-woo', 'nonce' );

	ob_start();
	wc_get_template( 'cart/mini-cart.php' );
	$mini_cart = ob_get_clean();

	wp_send_json_success( array(
		'fragments' => array(
			'.mini-cart-dropdown' => $mini_cart,
		),
		'cart_count' => WC()->cart->get_cart_contents_count(),
	) );
}
add_action( 'wp_ajax_themeflex_update_mini_cart', 'themeflex_update_mini_cart' );
add_action( 'wp_ajax_nopriv_themeflex_update_mini_cart', 'themeflex_update_mini_cart' );

/**
 * Product Grid Layout Classes
 *
 * @since 1.0.0
 */
function themeflex_woocommerce_product_loop_start() {
	$columns = intval( themeflex_get_theme_option( 'woo_shop_columns', 3 ) );
	echo '<ul class="products columns-' . esc_attr( $columns ) . '">';
}

/**
 * Product list layout
 *
 * @since 1.0.0
 */
function themeflex_woocommerce_product_list_class( $classes ) {
	$list_style = themeflex_get_theme_option( 'woo_product_layout', 'grid' );

	if ( 'list' === $list_style ) {
		$classes .= ' product-list-view';
	} else {
		$classes .= ' product-grid-view';
	}

	return $classes;
}
add_filter( 'post_class', 'themeflex_woocommerce_product_list_class' );

/**
 * Custom checkout field styling
 *
 * @since 1.0.0
 */
function themeflex_checkout_field_class( $class ) {
	return $class;
}
add_filter( 'woocommerce_form_field_class', 'themeflex_checkout_field_class' );

/**
 * Cart page quantity buttons (increment/decrement)
 *
 * @since 1.0.0
 */
function themeflex_cart_quantity_buttons() {
	if ( ! is_cart() ) {
		return;
	}
	?>
	<script>
		document.addEventListener( 'DOMContentLoaded', function() {
			const quantityInputs = document.querySelectorAll( 'input.qty' );

			quantityInputs.forEach( input => {
				const wrapper = input.parentElement;

				if ( wrapper.classList.contains( 'quantity-buttons-initialized' ) ) {
					return;
				}

				const minusBtn = document.createElement( 'button' );
				minusBtn.classList.add( 'qty-minus' );
				minusBtn.textContent = '−';
				minusBtn.type = 'button';

				const plusBtn = document.createElement( 'button' );
				plusBtn.classList.add( 'qty-plus' );
				plusBtn.textContent = '+';
				plusBtn.type = 'button';

				wrapper.insertBefore( minusBtn, input );
				wrapper.appendChild( plusBtn );
				wrapper.classList.add( 'quantity-buttons-initialized' );

				minusBtn.addEventListener( 'click', ( e ) => {
					e.preventDefault();
					const value = parseInt( input.value );
					if ( value > 1 ) {
						input.value = value - 1;
						input.dispatchEvent( new Event( 'change' ) );
					}
				} );

				plusBtn.addEventListener( 'click', ( e ) => {
					e.preventDefault();
					input.value = parseInt( input.value ) + 1;
					input.dispatchEvent( new Event( 'change' ) );
				} );
			} );
		} );
	</script>
	<?php
}
add_action( 'woocommerce_after_cart_contents', 'themeflex_cart_quantity_buttons' );

/**
 * Display cross-sell products on cart page
 *
 * @since 1.0.0
 */
function themeflex_cart_crosssells() {
	if ( ! is_cart() ) {
		return;
	}

	if ( ! themeflex_get_theme_option( 'woo_show_crosssell', true ) ) {
		return;
	}

	wc_get_template( 'cart/cross-sells.php' );
}

/**
 * My Account page styling hook
 *
 * @since 1.0.0
 */
function themeflex_account_page_classes() {
	if ( ! is_account_page() ) {
		return;
	}

	// Add custom account page styles
	echo '<!-- WooCommerce My Account styling -->';
}
add_action( 'wp_head', 'themeflex_account_page_classes' );

/**
 * AJAX Product Filter Handler
 *
 * @since 1.0.0
 */
function themeflex_ajax_filter_products() {
	check_ajax_referer( 'themeflex-woo', 'nonce' );

	$tax_query = array( 'relation' => 'AND' );
	$meta_query = array( 'relation' => 'AND' );
	$args = array(
		'post_type'      => 'product',
		'posts_per_page' => intval( themeflex_get_theme_option( 'woo_products_per_page', 12 ) ),
		'paged'          => isset( $_POST['paged'] ) ? intval( $_POST['paged'] ) : 1,
	);

	// Price filter
	if ( isset( $_POST['min_price'] ) || isset( $_POST['max_price'] ) ) {
		$min_price = isset( $_POST['min_price'] ) ? floatval( $_POST['min_price'] ) : 0;
		$max_price = isset( $_POST['max_price'] ) ? floatval( $_POST['max_price'] ) : PHP_INT_MAX;

		$meta_query[] = array(
			'key'     => '_price',
			'value'   => array( $min_price, $max_price ),
			'compare' => 'BETWEEN',
			'type'    => 'NUMERIC',
		);
	}

	// Category filter
	if ( isset( $_POST['categories'] ) && ! empty( $_POST['categories'] ) ) {
		$categories = array_map( 'intval', (array) $_POST['categories'] );
		$tax_query[] = array(
			'taxonomy' => 'product_cat',
			'field'    => 'term_id',
			'terms'    => $categories,
		);
	}

	// Attribute filter
	if ( isset( $_POST['attributes'] ) && ! empty( $_POST['attributes'] ) ) {
		foreach ( $_POST['attributes'] as $attribute => $values ) {
			if ( ! empty( $values ) ) {
				$tax_query[] = array(
					'taxonomy' => 'pa_' . sanitize_text_field( $attribute ),
					'field'    => 'slug',
					'terms'    => array_map( 'sanitize_text_field', (array) $values ),
				);
			}
		}
	}

	if ( count( $tax_query ) > 1 ) {
		$args['tax_query'] = $tax_query;
	}

	if ( count( $meta_query ) > 1 ) {
		$args['meta_query'] = $meta_query;
	}

	// Stock filter
	if ( isset( $_POST['in_stock_only'] ) && $_POST['in_stock_only'] ) {
		$args['meta_key'] = '_stock_status';
		$args['meta_value'] = 'instock';
	}

	$products = new WP_Query( $args );

	ob_start();
	if ( $products->have_posts() ) {
		while ( $products->have_posts() ) {
			$products->the_post();
			wc_get_template_part( 'content', 'product' );
		}
	} else {
		echo '<p>' . esc_html__( 'No products found.', 'themeflex' ) . '</p>';
	}
	$html = ob_get_clean();

	wp_send_json_success( array(
		'html'         => $html,
		'total_count'  => $products->found_posts,
		'total_pages'  => $products->max_num_pages,
	) );

	wp_reset_postdata();
}
add_action( 'wp_ajax_themeflex_filter_products', 'themeflex_ajax_filter_products' );
add_action( 'wp_ajax_nopriv_themeflex_filter_products', 'themeflex_ajax_filter_products' );
