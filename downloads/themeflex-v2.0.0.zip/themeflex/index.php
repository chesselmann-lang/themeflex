<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

get_header();
?>

<?php
/**
 * Action hook before loop
 *
 * @since 1.0.0
 */
do_action( 'themeflex_before_loop' );
?>

<?php if ( have_posts() ) : ?>

	<?php
	/**
	 * Action hook before posts
	 *
	 * @since 1.0.0
	 */
	do_action( 'themeflex_before_posts' );
	?>

	<?php
	/**
	 * Get layout mode from customizer
	 * Options: 'grid', 'list'
	 *
	 * @since 1.0.0
	 */
	$layout_mode = themeflex_get_theme_option( 'blog_layout', 'grid' );
	$grid_columns = intval( themeflex_get_theme_option( 'blog_grid_columns', 3 ) );
	?>

	<div class="posts-list posts-layout-<?php echo esc_attr( $layout_mode ); ?><?php echo $layout_mode === 'grid' ? ' posts-grid-' . esc_attr( $grid_columns ) : ''; ?>" role="region" aria-label="<?php esc_attr_e( 'Posts', 'themeflex' ); ?>">
		<?php
		while ( have_posts() ) :
			the_post();

			/**
			 * Include the Post-Type-specific template for the content.
			 * For grid layout, use content-grid.php if available
			 * Otherwise fall back to default content template
			 */
			if ( $layout_mode === 'grid' && locate_template( 'template-parts/content-grid.php' ) ) {
				get_template_part( 'template-parts/content', 'grid' );
			} else {
				get_template_part( 'template-parts/content', get_post_type() );
			}

		endwhile;
		?>
	</div><!-- .posts-list -->

	<?php
	/**
	 * Action hook after posts
	 *
	 * @since 1.0.0
	 */
	do_action( 'themeflex_after_posts' );
	?>

	<?php
	/**
	 * Post navigation
	 *
	 * @since 1.0.0
	 */
	?>
	<nav class="posts-navigation pagination" role="navigation" aria-label="<?php esc_attr_e( 'Posts', 'themeflex' ); ?>">
		<h2 class="screen-reader-text"><?php esc_html_e( 'Posts navigation', 'themeflex' ); ?></h2>
		<div class="nav-links">
			<?php
			echo wp_kses_post(
				paginate_links( array(
					'type'      => 'list',
					'prev_text' => '<span class="nav-previous">' . esc_html__( '&larr; Newer Posts', 'themeflex' ) . '</span>',
					'next_text' => '<span class="nav-next">' . esc_html__( 'Older Posts &rarr;', 'themeflex' ) . '</span>',
				) )
			);
			?>
		</div>
	</nav><!-- .posts-navigation -->

<?php else : ?>

	<?php
	/**
	 * Include the no posts found content
	 *
	 * @since 1.0.0
	 */
	get_template_part( 'template-parts/content', 'none' );
	?>

<?php endif; ?>

<?php
/**
 * Action hook after loop
 *
 * @since 1.0.0
 */
do_action( 'themeflex_after_loop' );
?>

<?php get_footer(); ?>
