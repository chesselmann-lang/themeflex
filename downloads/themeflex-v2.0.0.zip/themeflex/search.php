<?php
/**
 * Search Results Template
 *
 * @package ThemeFlex
 * @since   2.0.0
 */

get_header();
?>
<main id="primary" class="site-main tf-search-page">
	<div class="tf-container">

		<?php if ( have_posts() ) : ?>

			<header class="tf-search-header">
				<p class="tf-search-count">
					<?php
					printf(
						/* translators: %d: number of results */
						esc_html( _n( '%d Result', '%d Results', (int) $wp_query->found_posts, 'themeflex' ) ),
						(int) $wp_query->found_posts
					);
					?>
				</p>
				<h1 class="tf-search-title">
					<?php
					printf(
						/* translators: %s: search query */
						esc_html__( 'Search: %s', 'themeflex' ),
						'<span class="tf-search-query">' . esc_html( get_search_query() ) . '</span>'
					);
					?>
				</h1>
			</header>

			<div class="tf-search-refine">
				<span class="tf-search-refine-label"><?php esc_html_e( 'Refine:', 'themeflex' ); ?></span>
				<form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="tf-search-refine-form">
					<input
						type="search"
						name="s"
						class="tf-search-input"
						value="<?php echo esc_attr( get_search_query() ); ?>"
						placeholder="<?php esc_attr_e( 'Search&hellip;', 'themeflex' ); ?>"
					/>
					<button type="submit" class="tf-btn tf-btn-primary">
						<?php esc_html_e( 'Search', 'themeflex' ); ?>
					</button>
				</form>
			</div>

			<div class="tf-search-results">

				<?php while ( have_posts() ) : the_post(); ?>

				<article id="post-<?php the_ID(); ?>" <?php post_class( 'tf-search-item' ); ?>>

					<?php if ( has_post_thumbnail() ) : ?>
					<a href="<?php the_permalink(); ?>" class="tf-search-item__thumb" tabindex="-1" aria-hidden="true">
						<?php the_post_thumbnail( 'thumbnail', array( 'class' => 'tf-search-item__img' ) ); ?>
					</a>
					<?php endif; ?>

					<div class="tf-search-item__body">
						<p class="tf-search-item__type">
							<?php
							$post_type_obj = get_post_type_object( get_post_type() );
							if ( $post_type_obj && isset( $post_type_obj->labels->singular_name ) ) {
								echo esc_html( $post_type_obj->labels->singular_name );
							}
							?>
						</p>
						<h2 class="tf-search-item__title">
							<a href="<?php the_permalink(); ?>" class="tf-search-item__link">
								<?php the_title(); ?>
							</a>
						</h2>
						<p class="tf-search-item__excerpt">
							<?php echo wp_kses_post( wp_trim_words( get_the_excerpt(), 20, '&hellip;' ) ); ?>
						</p>
						<p class="tf-search-item__meta">
							<?php the_date(); ?>
							<?php esc_html_e( 'by', 'themeflex' ); ?>
							<?php the_author(); ?>
						</p>
					</div>

				</article>

				<?php endwhile; ?>

			</div><!-- .tf-search-results -->

			<nav class="tf-search-pagination">
				<?php
				the_posts_pagination( array(
					'mid_size'  => 2,
					'prev_text' => '&larr; ' . esc_html__( 'Prev', 'themeflex' ),
					'next_text' => esc_html__( 'Next', 'themeflex' ) . ' &rarr;',
				) );
				?>
			</nav>

		<?php else : ?>

			<div class="tf-search-empty">
				<span class="tf-search-empty__icon" aria-hidden="true">&#x1F50D;</span>
				<h1 class="tf-search-empty__title">
					<?php esc_html_e( 'No results found', 'themeflex' ); ?>
				</h1>
				<p class="tf-search-empty__text">
					<?php esc_html_e( "We couldn't find anything matching your search. Try different keywords.", 'themeflex' ); ?>
				</p>
				<?php get_search_form(); ?>
			</div>

		<?php endif; ?>

	</div><!-- .tf-container -->
</main><!-- #primary -->

<?php get_footer(); ?>
