<?php
/**
 * Template part for displaying page content
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'page-item' ); ?>>
	<header class="page-header">
		<?php
		/**
		 * Featured image
		 *
		 * @since 1.0.0
		 */
		if ( has_post_thumbnail() ) {
			?>
			<div class="page-thumbnail">
				<?php the_post_thumbnail( 'themeflex-thumb-big' ); ?>
			</div>
			<?php
		}
		?>

		<h1 class="page-title"><?php the_title(); ?></h1>
	</header><!-- .page-header -->

	<div class="page-content">
		<?php
		the_content();

		wp_link_pages(
			array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'themeflex' ),
				'after'  => '</div>',
			)
		);
		?>
	</div><!-- .page-content -->

	<?php
	if ( get_edit_post_link() ) {
		?>
		<footer class="page-footer">
			<?php
			edit_post_link(
				sprintf(
					wp_kses(
						__( 'Edit<span class="screen-reader-text"> "%s"</span>', 'themeflex' ),
						array(
							'span' => array(
								'class' => array(),
							),
						)
					),
					wp_kses_post( get_the_title() )
				),
				'<span class="edit-link">',
				'</span>'
			);
			?>
		</footer><!-- .page-footer -->
		<?php
	}
	?>
</article><!-- #post-<?php the_ID(); ?> -->
