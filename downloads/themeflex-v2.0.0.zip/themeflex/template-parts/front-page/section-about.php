<?php
/**
 * Front Page About / Problem Section — Pflichtenheft 2026
 *
 * Split layout: image left, content right.
 * Includes animated stats counters and trust indicators.
 *
 * @package ThemeFlex
 * @since 1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$title          = get_theme_mod( 'sf_about_title', esc_html__( 'Building the web, one project at a time', 'themeflex' ) );
$tag            = get_theme_mod( 'sf_about_tag', esc_html__( 'About Us', 'themeflex' ) );
$content        = get_theme_mod( 'sf_about_content', esc_html__( 'We know how hard it can be to build a website that actually converts visitors into customers. That\'s why we\'ve spent years perfecting our tools and templates — so you don\'t have to start from scratch.', 'themeflex' ) );
$image          = get_theme_mod( 'sf_about_image' );
$image_alt      = get_theme_mod( 'sf_about_image_alt', esc_html__( 'Our team at work', 'themeflex' ) );
$cta_text       = get_theme_mod( 'sf_about_cta_text', esc_html__( 'Learn More About Us', 'themeflex' ) );
$cta_url        = get_theme_mod( 'sf_about_cta_url', home_url( '/about' ) );

// Stats
$stat1_number   = get_theme_mod( 'sf_about_stat1_number', '10' );
$stat1_suffix   = get_theme_mod( 'sf_about_stat1_suffix', 'k+' );
$stat1_label    = get_theme_mod( 'sf_about_stat1_label', esc_html__( 'Happy Clients', 'themeflex' ) );
$stat2_number   = get_theme_mod( 'sf_about_stat2_number', '150' );
$stat2_suffix   = get_theme_mod( 'sf_about_stat2_suffix', '+' );
$stat2_label    = get_theme_mod( 'sf_about_stat2_label', esc_html__( 'Projects Delivered', 'themeflex' ) );
$stat3_number   = get_theme_mod( 'sf_about_stat3_number', '8' );
$stat3_suffix   = get_theme_mod( 'sf_about_stat3_suffix', 'yrs' );
$stat3_label    = get_theme_mod( 'sf_about_stat3_label', esc_html__( 'Experience', 'themeflex' ) );

$bg_color       = get_theme_mod( 'sf_about_bg_color', '' );
$padding_top    = get_theme_mod( 'sf_about_padding_top', '100' );
$padding_bottom = get_theme_mod( 'sf_about_padding_bottom', '100' );
$custom_class   = get_theme_mod( 'sf_about_custom_class', '' );

$section_style  = 'padding-top: ' . absint( $padding_top ) . 'px; padding-bottom: ' . absint( $padding_bottom ) . 'px;';
if ( $bg_color ) {
	$section_style .= ' background-color: ' . esc_attr( $bg_color ) . ';';
}
?>

<section
	class="sf-about-section <?php echo esc_attr( $custom_class ); ?>"
	style="<?php echo esc_attr( $section_style ); ?>"
	aria-label="<?php esc_attr_e( 'About Us', 'themeflex' ); ?>"
>
	<div class="sf-container">
		<div class="sf-about-wrapper">

			<!-- Image Column -->
			<?php if ( $image ) : ?>
				<div class="sf-about-image sf-fade-in">
					<img
						src="<?php echo esc_url( $image ); ?>"
						alt="<?php echo esc_attr( $image_alt ); ?>"
						loading="lazy"
						decoding="async"
					/>
				</div>
			<?php endif; ?>

			<!-- Content Column -->
			<div class="sf-about-content sf-fade-in" style="transition-delay: 100ms">

				<?php if ( $tag ) : ?>
					<div class="sf-section-tag"><?php echo esc_html( $tag ); ?></div>
				<?php endif; ?>

				<?php if ( $title ) : ?>
					<h2 class="sf-section-title"><?php echo wp_kses_post( $title ); ?></h2>
				<?php endif; ?>

				<?php if ( $content ) : ?>
					<div class="sf-about-text">
						<?php echo wp_kses_post( wpautop( $content ) ); ?>
					</div>
				<?php endif; ?>

				<!-- Stats -->
				<div class="sf-about-stats">
					<div class="sf-stat-item">
						<span
							class="sf-stat-number"
							data-target="<?php echo esc_attr( $stat1_number ); ?>"
							data-suffix="<?php echo esc_attr( $stat1_suffix ); ?>"
						>0</span>
						<span class="sf-stat-label"><?php echo esc_html( $stat1_label ); ?></span>
					</div>
					<div class="sf-stat-item">
						<span
							class="sf-stat-number"
							data-target="<?php echo esc_attr( $stat2_number ); ?>"
							data-suffix="<?php echo esc_attr( $stat2_suffix ); ?>"
						>0</span>
						<span class="sf-stat-label"><?php echo esc_html( $stat2_label ); ?></span>
					</div>
					<div class="sf-stat-item">
						<span
							class="sf-stat-number"
							data-target="<?php echo esc_attr( $stat3_number ); ?>"
							data-suffix="<?php echo esc_attr( $stat3_suffix ); ?>"
						>0</span>
						<span class="sf-stat-label"><?php echo esc_html( $stat3_label ); ?></span>
					</div>
				</div>

				<?php if ( $cta_text && $cta_url ) : ?>
					<a href="<?php echo esc_url( $cta_url ); ?>" class="sf-btn sf-btn-outline" style="align-self: flex-start; margin-top: 8px;">
						<?php echo esc_html( $cta_text ); ?>
						<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
					</a>
				<?php endif; ?>

			</div><!-- /.sf-about-content -->
		</div><!-- /.sf-about-wrapper -->
	</div><!-- /.sf-container -->
</section>
