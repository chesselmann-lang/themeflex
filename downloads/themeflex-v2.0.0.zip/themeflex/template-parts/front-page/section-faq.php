<?php
/**
 * Front Page FAQ Section — Pflichtenheft 2026
 *
 * Accordion FAQ with aria-expanded, smooth max-height animation
 * and keyboard navigation support. Items via filter.
 *
 * @package ThemeFlex
 * @since 1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$title          = get_theme_mod( 'sf_faq_title', esc_html__( 'Frequently Asked Questions', 'themeflex' ) );
$subtitle       = get_theme_mod( 'sf_faq_subtitle', esc_html__( 'Everything you need to know before getting started.', 'themeflex' ) );
$tag            = get_theme_mod( 'sf_faq_tag', esc_html__( 'FAQ', 'themeflex' ) );
$bg_color       = get_theme_mod( 'sf_faq_bg_color', '' );
$padding_top    = get_theme_mod( 'sf_faq_padding_top', '100' );
$padding_bottom = get_theme_mod( 'sf_faq_padding_bottom', '100' );
$custom_class   = get_theme_mod( 'sf_faq_custom_class', '' );

// Default items — override via add_filter( 'sf_faq_items', ... )
$faq_items = apply_filters( 'sf_faq_items', array(
	array(
		'q' => __( 'Do I need coding skills to use this theme?', 'themeflex' ),
		'a' => __( 'No coding required. Everything is controlled through Elementor's drag-and-drop builder and the WordPress Customiser. If you can click, you can build.', 'themeflex' ),
	),
	array(
		'q' => __( 'How many websites can I use the theme on?', 'themeflex' ),
		'a' => __( 'A standard licence covers one website. Developer/agency licences are available for multiple sites — contact us for pricing.', 'themeflex' ),
	),
	array(
		'q' => __( 'Is the theme compatible with WooCommerce?', 'themeflex' ),
		'a' => __( 'Yes. The theme includes full WooCommerce support with a dedicated shop builder, custom product pages, cart and checkout styling, and filter widgets.', 'themeflex' ),
	),
	array(
		'q' => __( 'Will my website be fast and rank well on Google?', 'themeflex' ),
		'a' => __( 'Performance is a top priority. The theme ships with lazy loading, minified assets, a critical-CSS loader, and scores 90+ on Google PageSpeed Insights out of the box.', 'themeflex' ),
	),
	array(
		'q' => __( 'What kind of support do I get?', 'themeflex' ),
		'a' => __( 'All purchases include 6 months of dedicated email support and lifetime access to our documentation and video tutorials. Extended support plans are also available.', 'themeflex' ),
	),
	array(
		'q' => __( 'Is there a money-back guarantee?', 'themeflex' ),
		'a' => __( 'Yes. We offer a 14-day refund policy if the theme is defective or significantly misrepresented. Please review our full refund policy before purchasing.', 'themeflex' ),
	),
) );

$section_style = 'padding-top: ' . absint( $padding_top ) . 'px; padding-bottom: ' . absint( $padding_bottom ) . 'px;';
if ( $bg_color ) { $section_style .= ' background-color: ' . esc_attr( $bg_color ) . ';'; }
?>

<section class="sf-faq-section <?php echo esc_attr( $custom_class ); ?>" style="<?php echo esc_attr( $section_style ); ?>" aria-label="<?php esc_attr_e( 'FAQ', 'themeflex' ); ?>">
	<div class="sf-faq-inner">
		<div class="sf-section-header">
			<?php if ( $tag )      : ?><div class="sf-section-tag"><?php echo esc_html( $tag ); ?></div><?php endif; ?>
			<?php if ( $title )    : ?><h2 class="sf-section-title"><?php echo wp_kses_post( $title ); ?></h2><?php endif; ?>
			<?php if ( $subtitle ) : ?><p class="sf-section-subtitle"><?php echo wp_kses_post( $subtitle ); ?></p><?php endif; ?>
		</div>
		<?php if ( ! empty( $faq_items ) ) : ?>
		<div class="sf-faq-list" role="list">
			<?php foreach ( $faq_items as $i => $item ) :
				$item_id = 'sf-faq-' . $i;
				$ans_id  = 'sf-faq-ans-' . $i;
			?>
			<div class="sf-faq-item sf-fade-in" role="listitem" style="transition-delay: <?php echo (int)( $i * 50 ); ?>ms">
				<button
					class="sf-faq-question"
					id="<?php echo esc_attr( $item_id ); ?>"
					aria-expanded="false"
					aria-controls="<?php echo esc_attr( $ans_id ); ?>"
					onclick="sfToggleFaq(this)"
				>
					<span><?php echo esc_html( $item['q'] ); ?></span>
					<span class="sf-faq-icon" aria-hidden="true"><i class="fa-solid fa-plus"></i></span>
				</button>
				<div
					class="sf-faq-answer"
					id="<?php echo esc_attr( $ans_id ); ?>"
					role="region"
					aria-labelledby="<?php echo esc_attr( $item_id ); ?>"
				><?php echo wp_kses_post( $item['a'] ); ?></div>
			</div>
			<?php endforeach; ?>
		</div>
		<?php endif; ?>
	</div>
</section>
