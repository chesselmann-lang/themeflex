<?php
/**
 * Front Page Features / Benefits Section — Pflichtenheft 2026
 *
 * Icon-boxes with title + description. Up to 6 items via filter.
 * Columns: 2–4, controlled via Customiser.
 *
 * @package ThemeFlex
 * @since 1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$title          = get_theme_mod( 'sf_features_title', esc_html__( 'Everything you need to succeed', 'themeflex' ) );
$subtitle       = get_theme_mod( 'sf_features_subtitle', esc_html__( 'A complete toolkit that saves you time and helps your business grow faster.', 'themeflex' ) );
$tag            = get_theme_mod( 'sf_features_tag', esc_html__( 'Why Choose Us', 'themeflex' ) );
$columns        = absint( get_theme_mod( 'sf_features_columns', '3' ) );
$bg_color       = get_theme_mod( 'sf_features_bg_color', '' );
$padding_top    = get_theme_mod( 'sf_features_padding_top', '100' );
$padding_bottom = get_theme_mod( 'sf_features_padding_bottom', '100' );
$custom_class   = get_theme_mod( 'sf_features_custom_class', '' );

// Default feature boxes — override via add_filter( 'sf_features_items', ... )
$features = apply_filters( 'sf_features_items', array(
	array(
		'icon'  => 'fa-solid fa-bolt',
		'title' => __( 'Lightning Fast', 'themeflex' ),
		'desc'  => __( 'Optimised for Core Web Vitals. Pages load in under 2 seconds — keeping visitors engaged and reducing bounce rates.', 'themeflex' ),
	),
	array(
		'icon'  => 'fa-solid fa-mobile-screen',
		'title' => __( 'Mobile First', 'themeflex' ),
		'desc'  => __( 'Every layout is designed with mobile users in mind. 70%+ of visitors are on phones — and your site is ready for them.', 'themeflex' ),
	),
	array(
		'icon'  => 'fa-solid fa-magnifying-glass-chart',
		'title' => __( 'SEO Ready', 'themeflex' ),
		'desc'  => __( 'Clean HTML5 semantics, schema markup, and structured headings ensure search engines can find and rank your content.', 'themeflex' ),
	),
	array(
		'icon'  => 'fa-solid fa-shield-halved',
		'title' => __( 'Secure by Default', 'themeflex' ),
		'desc'  => __( 'Security best practices baked in. HTTPS, input sanitisation, and GDPR-compliant cookie handling out of the box.', 'themeflex' ),
	),
	array(
		'icon'  => 'fa-solid fa-palette',
		'title' => __( 'Fully Customisable', 'themeflex' ),
		'desc'  => __( 'Unlimited colour palettes, fonts, layouts and style options — all controlled from the WordPress Customiser.', 'themeflex' ),
	),
	array(
		'icon'  => 'fa-solid fa-headset',
		'title' => __( 'Expert Support', 'themeflex' ),
		'desc'  => __( 'Our team responds within 24 hours, every day. 4.9-star rated support trusted by 100,000+ customers worldwide.', 'themeflex' ),
	),
) );

$columns       = max( 2, min( 4, $columns ) );
$section_style = 'padding-top: ' . absint( $padding_top ) . 'px; padding-bottom: ' . absint( $padding_bottom ) . 'px;';
if ( $bg_color ) {
	$section_style .= ' background-color: ' . esc_attr( $bg_color ) . ';';
}
?>

<section
	class="sf-features-section <?php echo esc_attr( $custom_class ); ?>"
	style="<?php echo esc_attr( $section_style ); ?>"
	aria-label="<?php esc_attr_e( 'Features & Benefits', 'themeflex' ); ?>"
>
	<div class="sf-container">
		<header class="sf-section-header">
			<?php if ( $tag ) : ?>
				<div class="sf-section-tag"><?php echo esc_html( $tag ); ?></div>
			<?php endif; ?>
			<?php if ( $title ) : ?>
				<h2 class="sf-section-title"><?php echo wp_kses_post( $title ); ?></h2>
			<?php endif; ?>
			<?php if ( $subtitle ) : ?>
				<p class="sf-section-subtitle"><?php echo wp_kses_post( $subtitle ); ?></p>
			<?php endif; ?>
		</header>

		<?php if ( ! empty( $features ) ) : ?>
			<div class="sf-features-grid sf-features-cols-<?php echo absint( $columns ); ?>">
				<?php foreach ( $features as $i => $feature ) : ?>
					<div
						class="sf-feature-card sf-fade-in"
						style="transition-delay: <?php echo (int) ( $i % 3 ) * 80; ?>ms"
					>
						<?php if ( ! empty( $feature['icon'] ) ) : ?>
							<div class="sf-feature-icon" aria-hidden="true">
								<i class="<?php echo esc_attr( $feature['icon'] ); ?>"></i>
							</div>
						<?php endif; ?>

						<?php if ( ! empty( $feature['title'] ) ) : ?>
							<h3 class="sf-feature-title"><?php echo esc_html( $feature['title'] ); ?></h3>
						<?php endif; ?>

						<?php if ( ! empty( $feature['desc'] ) ) : ?>
							<p class="sf-feature-desc"><?php echo wp_kses_post( $feature['desc'] ); ?></p>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
</section>
