<?php
/**
 * Front Page Services / Offer Section — Pflichtenheft 2026
 *
 * Service cards with icon, title, description and CTA link.
 * Up to 6 services, defined via filter for easy customisation.
 *
 * @package ThemeFlex
 * @since 1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$title          = get_theme_mod( 'sf_services_title', esc_html__( 'Our Services', 'themeflex' ) );
$subtitle       = get_theme_mod( 'sf_services_subtitle', esc_html__( 'We offer a full range of services to take your online presence from zero to outstanding.', 'themeflex' ) );
$tag            = get_theme_mod( 'sf_services_tag', esc_html__( 'What We Do', 'themeflex' ) );
$bg_color       = get_theme_mod( 'sf_services_bg_color', '' );
$padding_top    = get_theme_mod( 'sf_services_padding_top', '100' );
$padding_bottom = get_theme_mod( 'sf_services_padding_bottom', '100' );
$custom_class   = get_theme_mod( 'sf_services_custom_class', '' );

// Default services — override via add_filter( 'sf_services_items', ... )
$services = apply_filters( 'sf_services_items', array(
	array(
		'icon'     => 'fa-solid fa-paintbrush',
		'title'    => __( 'Web Design', 'themeflex' ),
		'desc'     => __( 'Pixel-perfect, conversion-focused websites designed to engage your audience and build trust from the first second.', 'themeflex' ),
		'link'     => home_url( '/services/web-design' ),
		'link_label' => __( 'Learn more', 'themeflex' ),
	),
	array(
		'icon'     => 'fa-solid fa-code',
		'title'    => __( 'Web Development', 'themeflex' ),
		'desc'     => __( 'Custom WordPress development with clean, performant code. Built to scale and easy for your team to manage.', 'themeflex' ),
		'link'     => home_url( '/services/development' ),
		'link_label' => __( 'Learn more', 'themeflex' ),
	),
	array(
		'icon'     => 'fa-solid fa-magnifying-glass',
		'title'    => __( 'SEO & Content', 'themeflex' ),
		'desc'     => __( 'Data-driven SEO strategy paired with authoritative content that ranks, attracts, and converts the right visitors.', 'themeflex' ),
		'link'     => home_url( '/services/seo' ),
		'link_label' => __( 'Learn more', 'themeflex' ),
	),
	array(
		'icon'     => 'fa-solid fa-cart-shopping',
		'title'    => __( 'E-Commerce', 'themeflex' ),
		'desc'     => __( 'WooCommerce stores built for maximum conversions — from product pages to checkout, every step is optimised.', 'themeflex' ),
		'link'     => home_url( '/services/ecommerce' ),
		'link_label' => __( 'Learn more', 'themeflex' ),
	),
	array(
		'icon'     => 'fa-solid fa-chart-line',
		'title'    => __( 'Analytics & CRO', 'themeflex' ),
		'desc'     => __( 'We set up tracking, analyse your data and run A/B tests to continuously improve conversions and ROI.', 'themeflex' ),
		'link'     => home_url( '/services/analytics' ),
		'link_label' => __( 'Learn more', 'themeflex' ),
	),
	array(
		'icon'     => 'fa-solid fa-wrench',
		'title'    => __( 'Maintenance & Care', 'themeflex' ),
		'desc'     => __( 'Regular updates, daily backups, uptime monitoring and security scans — we keep your site running perfectly.', 'themeflex' ),
		'link'     => home_url( '/services/maintenance' ),
		'link_label' => __( 'Learn more', 'themeflex' ),
	),
) );

$section_style = 'padding-top: ' . absint( $padding_top ) . 'px; padding-bottom: ' . absint( $padding_bottom ) . 'px;';
if ( $bg_color ) {
	$section_style .= ' background-color: ' . esc_attr( $bg_color ) . ';';
}
?>

<section
	class="sf-services-section <?php echo esc_attr( $custom_class ); ?>"
	style="<?php echo esc_attr( $section_style ); ?>"
	aria-label="<?php esc_attr_e( 'Services', 'themeflex' ); ?>"
>
	<div class="sf-container">
		<header class="sf-section-header">
			<?php if ( $tag ) : ?>
				<div class="sf-section-tag"><?php echo esc_html( $tag ); ?></div>
			<?php endif; ?>
			<?php if ( $title ) : ?>
				<h2 class="sf-section-title"><?php echo wp_kses_post( $title ); ?></h2>
			<?php endif; ?>
			<?php if ( $subtitle ) : ?>
				<p class="sf-section-subtitle"><?php echo wp_kses_post( $subtitle ); ?></p>
			<?php endif; ?>
		</header>

		<?php if ( ! empty( $services ) ) : ?>
			<div class="sf-services-grid">
				<?php foreach ( $services as $i => $service ) : ?>
					<div
						class="sf-service-card sf-fade-in"
						style="transition-delay: <?php echo (int) ( $i % 3 ) * 80; ?>ms"
					>
						<?php if ( ! empty( $service['icon'] ) ) : ?>
							<div class="sf-service-icon" aria-hidden="true">
								<i class="<?php echo esc_attr( $service['icon'] ); ?>"></i>
							</div>
						<?php endif; ?>

						<?php if ( ! empty( $service['title'] ) ) : ?>
							<h3 class="sf-service-title"><?php echo esc_html( $service['title'] ); ?></h3>
						<?php endif; ?>

						<?php if ( ! empty( $service['desc'] ) ) : ?>
							<p class="sf-service-desc"><?php echo wp_kses_post( $service['desc'] ); ?></p>
						<?php endif; ?>

						<?php if ( ! empty( $service['link'] ) && ! empty( $service['link_label'] ) ) : ?>
							<a
								href="<?php echo esc_url( $service['link'] ); ?>"
								class="sf-service-link"
							>
								<?php echo esc_html( $service['link_label'] ); ?>
								<i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
							</a>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
</section>
