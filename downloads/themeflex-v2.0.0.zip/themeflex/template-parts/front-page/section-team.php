<?php
/**
 * Front Page Team Section — Pflichtenheft 2026
 *
 * Grid of team cards with photo/avatar, name, role, bio and social links.
 * Members from sf_team CPT or filter fallback.
 *
 * @package ThemeFlex
 * @since 1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$title          = get_theme_mod( 'sf_team_title', esc_html__( 'Meet the Team', 'themeflex' ) );
$subtitle       = get_theme_mod( 'sf_team_subtitle', esc_html__( 'The talented people behind every project — passionate, experienced and dedicated to your success.', 'themeflex' ) );
$tag            = get_theme_mod( 'sf_team_tag', esc_html__( 'Our Team', 'themeflex' ) );
$columns        = absint( get_theme_mod( 'sf_team_columns', '4' ) );
$bg_color       = get_theme_mod( 'sf_team_bg_color', '' );
$padding_top    = get_theme_mod( 'sf_team_padding_top', '100' );
$padding_bottom = get_theme_mod( 'sf_team_padding_bottom', '100' );
$custom_class   = get_theme_mod( 'sf_team_custom_class', '' );

$members = array();

if ( post_type_exists( 'sf_team' ) ) {
	$team_query = new WP_Query( array(
		'post_type'      => 'sf_team',
		'posts_per_page' => 8,
		'post_status'    => 'publish',
		'orderby'        => 'menu_order',
		'order'          => 'ASC',
	) );
	if ( $team_query->have_posts() ) {
		while ( $team_query->have_posts() ) {
			$team_query->the_post();
			$n = get_the_title();
			$initials = strtoupper( substr( $n, 0, 1 ) . substr( strrchr( $n, ' ' ) ?: '', 1, 1 ) );
			$members[] = array(
				'name'     => $n,
				'role'     => get_post_meta( get_the_ID(), '_sf_team_role', true ),
				'bio'      => get_the_excerpt(),
				'photo'    => get_the_post_thumbnail_url( get_the_ID(), 'thumbnail' ),
				'initials' => $initials,
				'linkedin' => get_post_meta( get_the_ID(), '_sf_team_linkedin', true ),
				'twitter'  => get_post_meta( get_the_ID(), '_sf_team_twitter', true ),
				'github'   => get_post_meta( get_the_ID(), '_sf_team_github', true ),
			);
		}
		wp_reset_postdata();
	}
}

if ( empty( $members ) ) {
	$members = apply_filters( 'sf_team_members', array(
		array( 'name' => 'Alex Johnson',   'role' => 'Founder & CEO',       'bio' => '10+ years in web development. Building tools that help businesses grow online.', 'photo' => '', 'initials' => 'AJ', 'linkedin' => '#', 'twitter' => '#', 'github' => '' ),
		array( 'name' => 'Maria Schmidt',  'role' => 'Lead Designer',       'bio' => 'Award-winning UI/UX designer. Creates experiences that turn visitors into customers.', 'photo' => '', 'initials' => 'MS', 'linkedin' => '#', 'twitter' => '', 'github' => '' ),
		array( 'name' => 'Tom Nakamura',   'role' => 'Head of Engineering', 'bio' => 'Full-stack architect. Every theme he ships scores 95+ on PageSpeed Insights.', 'photo' => '', 'initials' => 'TN', 'linkedin' => '#', 'twitter' => '', 'github' => '#' ),
		array( 'name' => 'Sophie Bernard', 'role' => 'Customer Success',    'bio' => 'Dedicated to making every customer successful across four time zones.', 'photo' => '', 'initials' => 'SB', 'linkedin' => '#', 'twitter' => '#', 'github' => '' ),
	) );
}

$columns       = max( 2, min( 4, $columns ) );
$section_style = 'padding-top: ' . absint( $padding_top ) . 'px; padding-bottom: ' . absint( $padding_bottom ) . 'px;';
if ( $bg_color ) { $section_style .= ' background-color: ' . esc_attr( $bg_color ) . ';'; }
?>

<section class="sf-team-section <?php echo esc_attr( $custom_class ); ?>" style="<?php echo esc_attr( $section_style ); ?>" aria-label="<?php esc_attr_e( 'Team', 'themeflex' ); ?>">
	<div class="sf-container">
		<header class="sf-section-header">
			<?php if ( $tag )      : ?><div class="sf-section-tag"><?php echo esc_html( $tag ); ?></div><?php endif; ?>
			<?php if ( $title )    : ?><h2 class="sf-section-title"><?php echo wp_kses_post( $title ); ?></h2><?php endif; ?>
			<?php if ( $subtitle ) : ?><p class="sf-section-subtitle"><?php echo wp_kses_post( $subtitle ); ?></p><?php endif; ?>
		</header>
		<?php if ( ! empty( $members ) ) : ?>
		<div class="sf-team-grid" style="grid-template-columns: repeat(<?php echo absint( $columns ); ?>, 1fr);">
			<?php foreach ( $members as $i => $m ) : ?>
			<article class="sf-team-card sf-fade-in" style="transition-delay: <?php echo (int)( $i % 4 ) * 80; ?>ms">
				<div class="sf-team-photo-wrap">
					<?php if ( ! empty( $m['photo'] ) ) : ?>
					<img class="sf-team-photo" src="<?php echo esc_url( $m['photo'] ); ?>" alt="<?php echo esc_attr( $m['name'] ); ?>" loading="lazy" decoding="async" width="88" height="88">
					<?php else : ?>
					<div class="sf-team-avatar-fallback" aria-hidden="true"><?php echo esc_html( $m['initials'] ); ?></div>
					<?php endif; ?>
				</div>
				<?php if ( ! empty( $m['name'] ) ) : ?><h3 class="sf-team-name"><?php echo esc_html( $m['name'] ); ?></h3><?php endif; ?>
				<?php if ( ! empty( $m['role'] ) ) : ?><p class="sf-team-role"><?php echo esc_html( $m['role'] ); ?></p><?php endif; ?>
				<?php if ( ! empty( $m['bio'] ) )  : ?><p class="sf-team-bio"><?php echo esc_html( $m['bio'] ); ?></p><?php endif; ?>
				<?php if ( ! empty( $m['linkedin'] ) || ! empty( $m['twitter'] ) || ! empty( $m['github'] ) ) : ?>
				<div class="sf-team-social">
					<?php if ( ! empty( $m['linkedin'] ) ) : ?><a href="<?php echo esc_url( $m['linkedin'] ); ?>" class="sf-team-soc" aria-label="<?php printf( esc_attr__( '%s on LinkedIn', 'themeflex' ), esc_attr( $m['name'] ) ); ?>" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-linkedin-in" aria-hidden="true"></i></a><?php endif; ?>
					<?php if ( ! empty( $m['twitter'] ) )  : ?><a href="<?php echo esc_url( $m['twitter'] ); ?>"  class="sf-team-soc" aria-label="<?php printf( esc_attr__( '%s on X/Twitter', 'themeflex' ), esc_attr( $m['name'] ) ); ?>" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-x-twitter" aria-hidden="true"></i></a><?php endif; ?>
					<?php if ( ! empty( $m['github'] ) )   : ?><a href="<?php echo esc_url( $m['github'] ); ?>"   class="sf-team-soc" aria-label="<?php printf( esc_attr__( '%s on GitHub', 'themeflex' ), esc_attr( $m['name'] ) ); ?>" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-github" aria-hidden="true"></i></a><?php endif; ?>
				</div>
				<?php endif; ?>
			</article>
			<?php endforeach; ?>
		</div>
		<?php endif; ?>
	</div>
</section>
