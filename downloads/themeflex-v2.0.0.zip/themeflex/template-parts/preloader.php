<?php
/**
 * Preloader template part.
 *
 * Included via get_template_part() in header.php immediately after <body>.
 * Only rendered when the Customizer option is enabled.
 *
 * @package ThemeFlex
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// Allow disabling via Customizer or filter
if ( ! apply_filters( 'sf_show_preloader', get_theme_mod( 'sf_preloader_enabled', true ) ) ) {
	return;
}

$style   = get_theme_mod( 'sf_preloader_style', 'dots' ); // dots | bar | logo-only
$logo_id = get_theme_mod( 'custom_logo' );
$logo_url = $logo_id ? wp_get_attachment_image_url( $logo_id, 'medium' ) : '';
?>
<div class="sf-preloader" id="sf-preloader" role="status" aria-label="<?php esc_attr_e( 'Loading', 'themeflex' ); ?>">
	<?php if ( $logo_url ) : ?>
	<img class="sf-preloader__logo"
		src="<?php echo esc_url( $logo_url ); ?>"
		alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"
		width="140"
		decoding="async" />
	<?php else : ?>
	<div class="sf-preloader__logo" style="font-size:24px;font-weight:800;color:var(--sf-color-primary,#FF5E2E);">
		<?php echo esc_html( get_bloginfo( 'name' ) ); ?>
	</div>
	<?php endif; ?>

	<?php if ( 'bar' === $style ) : ?>
	<div class="sf-preloader__bar-wrap">
		<div class="sf-preloader__bar"></div>
	</div>
	<?php elseif ( 'dots' === $style || '' === $style ) : ?>
	<div class="sf-preloader__dots" aria-hidden="true">
		<span class="sf-preloader__dot"></span>
		<span class="sf-preloader__dot"></span>
		<span class="sf-preloader__dot"></span>
	</div>
	<?php endif; ?>
</div>
