<?php
/**
 * Empty Cart Page — Starter Flavor override.
 * @package ThemeFlex
 */
defined('ABSPATH') || exit;
do_action('woocommerce_cart_is_empty');
?>
<div style="text-align:center;padding:80px 24px;max-width:480px;margin:0 auto;">
    <div style="font-size:80px;margin-bottom:20px;">🛒</div>
    <h2 style="font-family:'Inter Tight',sans-serif;font-size:1.8rem;font-weight:800;color:var(--sf-title,#1e293b);margin-bottom:12px;"><?php esc_html_e('Your cart is empty','themeflex'); ?></h2>
    <p style="color:var(--sf-text,#64748b);margin-bottom:28px;"><?php esc_html_e("Looks like you haven't added anything yet. Browse our products and find something you love.",'themeflex'); ?></p>
    <?php if (wc_get_page_id('shop') > 0): ?>
    <a href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>"
       style="display:inline-flex;align-items:center;gap:8px;padding:14px 28px;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;border-radius:10px;font-weight:700;font-size:15px;text-decoration:none;">
        🛍️ <?php esc_html_e('Continue Shopping','themeflex'); ?>
    </a>
    <?php endif; ?>
    <?php if (wc_coupons_enabled()): ?>
    <div style="margin-top:32px;padding:20px;background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:12px;">
        <p style="font-size:13px;font-weight:700;color:var(--sf-title,#1e293b);margin-bottom:10px;"><?php esc_html_e('Have a coupon?','themeflex'); ?></p>
        <form action="<?php echo esc_url(wc_get_page_permalink('cart')); ?>" method="post" style="display:flex;gap:8px;">
            <input type="text" name="coupon_code" class="input-text" id="coupon_code" value="" placeholder="<?php esc_attr_e('Coupon code','themeflex'); ?>"
                   style="flex:1;padding:10px 14px;border:1px solid var(--sf-border,#e5e7eb);border-radius:8px;font-size:14px;font-family:inherit;" />
            <button type="submit" name="apply_coupon" value="<?php esc_attr_e('Apply coupon','themeflex'); ?>"
                    style="padding:10px 18px;background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:8px;font-weight:700;font-size:14px;cursor:pointer;font-family:inherit;">
                <?php esc_html_e('Apply','themeflex'); ?>
            </button>
            <?php wp_nonce_field('woocommerce-cart', 'woocommerce-cart-nonce'); ?>
        </form>
    </div>
    <?php endif; ?>
</div>
