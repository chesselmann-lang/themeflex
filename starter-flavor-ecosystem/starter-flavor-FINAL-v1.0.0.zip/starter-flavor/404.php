<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * Features:
 * - Attractive 404 design with error code
 * - Search form
 * - Category suggestions
 * - Recent posts
 * - Back to home button
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

get_header();
?>

<div class="error-404-container">
	<div class="error-404-content">
		<div class="error-404-hero">
			<div class="error-404-code">404</div>
			<h1 class="page-title"><?php esc_html_e( 'Page Not Found', 'starter-flavor' ); ?></h1>
			<p class="error-404-description"><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try searching for what you are looking for using the form below, or browse some of our most popular sections.', 'starter-flavor' ); ?></p>

			<div class="error-404-actions">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="button button-primary"><?php esc_html_e( 'Back to Home', 'starter-flavor' ); ?></a>
			</div>
		</div>

		<div class="error-404-search">
			<h2><?php esc_html_e( 'Search Our Site', 'starter-flavor' ); ?></h2>
			<?php
			get_search_form( array(
				'label' => esc_html__( 'Search for:', 'starter-flavor' ),
			) );
			?>
		</div>

		<div class="error-404-suggestions">
			<div class="suggestions-grid">
				<?php
				// Most Used Categories
				$categories = get_categories( array(
					'orderby'       => 'count',
					'order'         => 'DESC',
					'number'        => 5,
					'hierarchical'  => false,
				) );

				if ( ! empty( $categories ) ) {
					?>
					<div class="suggestions-column">
						<h3><?php esc_html_e( 'Popular Categories', 'starter-flavor' ); ?></h3>
						<ul class="suggestions-list">
							<?php
							foreach ( $categories as $category ) {
								printf(
									'<li><a href="%s">%s</a></li>',
									esc_url( get_category_link( $category->term_id ) ),
									esc_html( $category->name )
								);
							}
							?>
						</ul>
					</div>
					<?php
				}

				// Recent Posts
				$recent_posts = wp_get_recent_posts( array(
					'numberposts'      => 5,
					'orderby'          => 'date',
					'post_type'        => 'post',
					'post_status'      => 'publish',
					'suppress_filters'  => true,
				) );

				if ( ! empty( $recent_posts ) ) {
					?>
					<div class="suggestions-column">
						<h3><?php esc_html_e( 'Recent Posts', 'starter-flavor' ); ?></h3>
						<ul class="suggestions-list">
							<?php
							foreach ( $recent_posts as $post ) {
								printf(
									'<li><a href="%s">%s</a></li>',
									esc_url( get_permalink( $post['ID'] ) ),
									esc_html( $post['post_title'] )
								);
							}
							?>
						</ul>
					</div>
					<?php
				}
				?>
			</div>
		</div>

		<?php
		/**
		 * Action hook for 404 page
		 *
		 * @since 1.0.0
		 */
		do_action( 'starter_flavor_404_page' );
		?>
	</div>
</div><!-- .error-404-container -->

<?php get_footer(); ?>
