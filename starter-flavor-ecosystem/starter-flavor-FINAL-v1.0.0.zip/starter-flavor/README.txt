=== Starter Flavor ===
Contributors: whatsdigital
Tags: blog, e-commerce, portfolio, elementor, one-click-demo-import, custom-widgets, woocommerce, dark-mode, rtl-language-support, accessibility-ready, custom-header, custom-menu, featured-images, threaded-comments, translation-ready
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Starter Flavor is a premium WordPress theme designed for agencies, freelancers, and content creators. Built with modern web technologies and deep Elementor integration, it provides everything needed to create professional, feature-rich websites without coding.

Key Features:
- 18 custom Elementor widgets for enhanced page building
- 5 blog layouts with advanced filtering and sorting
- WooCommerce integration with product showcase templates
- Dark mode support and RTL language compatibility
- WCAG 2.1 AA accessibility compliance
- Custom portfolio post type with gallery layouts
- One-click demo import with 3 pre-built professional demos
- Advanced theme options panel with live preview
- Fully responsive design with mobile optimization
- Performance-optimized code with lazy loading
- Full internationalization (i18n) support for translations

== Installation ==

1. Download the Starter Flavor theme
2. Upload the theme folder to `/wp-content/themes/` via FTP or use the WordPress theme uploader
3. Navigate to Appearance > Themes in your WordPress admin
4. Click "Activate" on the Starter Flavor theme
5. Go to Appearance > Starter Flavor Dashboard to configure theme options

For comprehensive setup instructions and documentation, see `/docs/INDEX.md` in the theme folder or visit https://whatsdigital.de/starter-flavor/docs

== Frequently Asked Questions ==

= How do I install the demo content? =
Go to Appearance > Starter Flavor Dashboard > Demo Import and select your desired demo to import with one click.

= Can I use this theme with page builders other than Elementor? =
While optimized for Elementor, Starter Flavor is fully compatible with Gutenberg and other popular page builders.

= Is the theme translation-ready? =
Yes, Starter Flavor includes complete i18n support with POT translation files and is translation-ready via WordPress.org.

= Do you provide support? =
Yes! Our support team is available at https://whatsdigital.de/support

= Can I use this on a WordPress multisite? =
Yes, Starter Flavor is fully compatible with WordPress multisite installations.

= Is there comprehensive documentation? =
Complete documentation is available in the `/docs/` folder and online at https://whatsdigital.de/starter-flavor/docs

= Is the theme compatible with WooCommerce? =
Yes, Starter Flavor includes deep WooCommerce integration with custom product showcase templates and optimized shop pages.

= What about performance and SEO? =
The theme is built for performance with optimized code, lazy loading, and follows WordPress and SEO best practices for better search visibility.

== Changelog ==

= 1.0.0 =
* Initial release
* 18 custom Elementor widgets
* Advanced customizer with live preview
* WooCommerce integration
* Dark mode and RTL support
* WCAG 2.1 AA accessibility compliance
* One-click demo import
* Performance optimization
* Full internationalization support

== Credits ==

Starter Flavor is developed by WhatsDigital (https://whatsdigital.de)

Built with:
- WordPress (https://wordpress.org)
- Elementor (https://elementor.com)
- Supabase (https://supabase.com)
- Modern CSS & JavaScript

Special thanks to the WordPress and Elementor communities, and all contributors who helped make this theme possible.

== License ==

Starter Flavor is licensed under GNU General Public License v2 or later.
See LICENSE.txt for full details.

https://www.gnu.org/licenses/gpl-2.0.html
