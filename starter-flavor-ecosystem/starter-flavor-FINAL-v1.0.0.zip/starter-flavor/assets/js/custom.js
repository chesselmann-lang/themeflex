/**
 * Custom JavaScript for Starter Flavor
 *
 * Handles general theme functionality
 */

(function() {
	'use strict';

	// Back to top button functionality
	const backToTopButton = document.getElementById('back-to-top');

	if (backToTopButton) {
		window.addEventListener('scroll', function() {
			if (window.scrollY > 300) {
				backToTopButton.classList.add('visible');
			} else {
				backToTopButton.classList.remove('visible');
			}
		});

		backToTopButton.addEventListener('click', function(e) {
			e.preventDefault();
			window.scrollTo({
				top: 0,
				behavior: 'smooth'
			});
		});
	}

	// Smooth scroll for anchor links
	document.querySelectorAll('a[href^="#"]').forEach(function(anchor) {
		anchor.addEventListener('click', function(e) {
			const href = this.getAttribute('href');
			if (href && href !== '#') {
				const target = document.querySelector(href);
				if (target) {
					e.preventDefault();
					target.scrollIntoView({
						behavior: 'smooth'
					});
				}
			}
		});
	});

	// Add focus visible to elements
	const interactiveElements = document.querySelectorAll('a, button, input, select, textarea');
	interactiveElements.forEach(function(el) {
		el.addEventListener('keydown', function(e) {
			if (e.key === 'Tab') {
				this.classList.add('focus-visible');
			}
		});
		el.addEventListener('click', function() {
			this.classList.remove('focus-visible');
		});
	});

	// Handle external links
	document.querySelectorAll('a[target="_blank"]').forEach(function(link) {
		link.addEventListener('keypress', function(e) {
			if (e.key === 'Enter' || e.key === ' ') {
				this.click();
			}
		});
	});
})();
