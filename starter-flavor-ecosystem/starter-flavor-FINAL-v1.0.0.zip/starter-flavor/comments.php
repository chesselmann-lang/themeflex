<?php
/**
 * The template for displaying comments
 *
 * This is the template that displays all the comments and the comment form for WordPress.
 * If you are building a custom commenting system, you might want to look at this template,
 * but please realize that WordPress core will be using some of the core comment functionality
 * in newer versions of WordPress so modify wisely!
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( post_password_required() ) {
	return;
}
?>

<div id="comments" class="comments-area">

	<?php
	// You can start editing here -- including this comment!
	if ( have_comments() ) {
		?>
		<h2 class="comments-title">
			<?php
			$starter_flavor_comment_count = get_comments_number();
			if ( '1' === $starter_flavor_comment_count ) {
				esc_html_e( '1 Comment', 'starter-flavor' );
			} else {
				printf(
					/* translators: %s: number of comments */
					esc_html( _nx( '%s Comment', '%s Comments', $starter_flavor_comment_count, 'comments title', 'starter-flavor' ) ),
					esc_html( number_format_i18n( $starter_flavor_comment_count ) )
				);
			}
			?>
		</h2><!-- .comments-title -->

		<?php the_comments_navigation(); ?>

		<ol class="comment-list">
			<?php
			wp_list_comments(
				array(
					'style'      => 'ol',
					'short_ping' => true,
					'avatar_size'=> 100,
				)
			);
			?>
		</ol><!-- .comment-list -->

		<?php
		the_comments_navigation();

		// If comments are closed and there are comments, let's leave a little note.
		if ( ! comments_open() ) {
			?>
			<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'starter-flavor' ); ?></p>
			<?php
		}
	}
	?>

	<?php
	comment_form(
		array(
			'class_form'            => 'comment-form',
			'title_reply_before'    => '<h2 id="reply-title" class="comment-reply-title">',
			'title_reply_after'     => '</h2>',
			'comment_notes_before'  => '<p class="comment-notes"><span class="required-field-message">' . esc_html__( 'Required fields are marked with *', 'starter-flavor' ) . '</span> ' . esc_html__( 'Your email address will not be published.', 'starter-flavor' ) . '</p>',
			'comment_notes_after'   => '',
			'label_submit'          => esc_html__( 'Post Comment', 'starter-flavor' ),
			'submit_button'         => '<button name="%1$s" type="submit" id="%2$s" class="submit button" aria-label="' . esc_attr__( 'Submit comment form', 'starter-flavor' ) . '">%4$s</button>',
			'submit_field'          => '<p class="form-submit">%1$s %2$s</p>',
			'format'                => 'html5',
			'consent'               => true,
		)
	);
	?>
</div><!-- #comments -->
