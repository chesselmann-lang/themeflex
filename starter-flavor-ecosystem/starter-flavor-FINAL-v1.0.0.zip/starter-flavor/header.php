<?php
/**
 * The header for Starter Flavor theme
 *
 * Features:
 * - Sticky Header Support
 * - Dark Mode Toggle Button
 * - Mobile Navigation
 * - Responsive Design
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="<?php echo esc_attr( apply_filters( 'starter_flavor_html_classes', '' ) ); ?>">
<head>
	<meta charset="<?php echo esc_attr( get_bloginfo( 'charset' ) ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- WCAG 2.1: Support for high contrast mode and color scheme preference -->
	<meta name="color-scheme" content="light dark">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<?php
	wp_body_open();
	?>

	<div class="body_wrap">
		<div class="page_wrap">
			<?php
			/**
			 * Action hook before header
			 *
			 * @since 1.0.0
			 */
			do_action( 'starter_flavor_before_header' );
			?>

			<header id="site-header" class="site-header<?php echo starter_flavor_get_header_layout() === 'centered' ? ' header-centered' : ''; ?><?php echo starter_flavor_get_header_layout() === 'transparent' ? ' header-transparent' : ''; ?>" role="banner">
				<div class="header-content">
					<div class="header-inner">
						<div class="header-left">
							<?php
							/**
							 * Action hook for header branding
							 *
							 * @since 1.0.0
							 */
							do_action( 'starter_flavor_header_branding' );

							// Display Logo
							if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
								the_custom_logo();
							} else {
								?>
								<h1 class="site-title">
									<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
										<?php echo esc_html( get_bloginfo( 'name' ) ); ?>
									</a>
								</h1>
								<?php
								$site_description = get_bloginfo( 'description' );
								if ( $site_description ) {
									?>
									<p class="site-description">
										<?php echo esc_html( $site_description ); ?>
									</p>
									<?php
								}
							}
							?>
						</div>

						<nav id="site-navigation" class="site-navigation main-navigation" role="navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'starter-flavor' ); ?>">
							<button class="menu-toggle" id="menu-toggle" aria-controls="primary-menu" aria-expanded="false" aria-haspopup="true">
								<span class="menu-toggle-text"><?php esc_html_e( 'Menu', 'starter-flavor' ); ?></span>
								<span class="menu-toggle-icon">
									<span></span>
									<span></span>
									<span></span>
								</span>
							</button>

							<?php
							$menu_args = array(
								'theme_location' => 'main-menu',
								'menu_id'        => 'primary-menu',
								'container'      => false,
								'fallback_cb'    => 'wp_page_menu',
								'depth'          => 3,
							);
							if ( class_exists( 'Starter_Flavor_Nav_Menu_Walker' ) ) {
								$menu_args['walker'] = new Starter_Flavor_Nav_Menu_Walker();
							}
							wp_nav_menu( $menu_args );
							?>
						</nav>

						<div class="header-right">
							<?php
							// Dark Mode Toggle
							if ( starter_flavor_get_theme_option( 'enable_dark_mode' ) ) {
								?>
								<button class="dark-mode-toggle" id="dark-mode-toggle" aria-label="<?php esc_attr_e( 'Toggle dark mode', 'starter-flavor' ); ?>">
									<span class="dark-mode-icon">
										<svg class="light-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
											<circle cx="12" cy="12" r="5"></circle>
											<line x1="12" y1="1" x2="12" y2="3"></line>
											<line x1="12" y1="21" x2="12" y2="23"></line>
											<line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
											<line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
											<line x1="1" y1="12" x2="3" y2="12"></line>
											<line x1="21" y1="12" x2="23" y2="12"></line>
											<line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
											<line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
										</svg>
										<svg class="dark-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
											<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
										</svg>
									</span>
								</button>
								<?php
							}

							/**
							 * Action hook for header right content
							 *
							 * @since 1.0.0
							 */
							do_action( 'starter_flavor_header_right' );
							?>
						</div>
					</div>
				</div>
			</header>

			<?php
			/**
			 * Action hook after header
			 *
			 * @since 1.0.0
			 */
			do_action( 'starter_flavor_after_header' );
			?>

			<a class="skip-link screen-reader-text" href="#site-content">
				<?php esc_html_e( 'Skip to content', 'starter-flavor' ); ?>
			</a>

			<div class="page_content_wrap">
				<div class="content_wrap">
					<main id="site-content" class="site-content content" role="main">
						<?php
						/**
						 * Action hook before main content
						 *
						 * @since 1.0.0
						 */
						do_action( 'starter_flavor_before_content' );
						?>
