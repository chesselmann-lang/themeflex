<?php
/**
 * Starter Flavor Front Page Section Builder
 *
 * Manages modular front page sections with customizer controls.
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Front Page Builder Class
 *
 * @since 1.0.0
 */
class Starter_Flavor_Front_Page {

	/**
	 * Available sections
	 *
	 * @var array
	 */
	private $sections = array();

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->register_sections();

		add_action( 'customize_register', array( $this, 'customize_register' ) );
		add_filter( 'template_include', array( $this, 'front_page_template' ) );
	}

	/**
	 * Register available sections
	 *
	 * @since 1.0.0
	 */
	private function register_sections() {
		$this->sections = array(
			'hero'          => array(
				'title'       => esc_html__( 'Hero/Title', 'starter-flavor' ),
				'description' => esc_html__( 'Full-screen hero section with title and CTAs', 'starter-flavor' ),
				'priority'    => 10,
			),
			'about'         => array(
				'title'       => esc_html__( 'About', 'starter-flavor' ),
				'description' => esc_html__( 'About section with image and counters', 'starter-flavor' ),
				'priority'    => 20,
			),
			'features'      => array(
				'title'       => esc_html__( 'Features', 'starter-flavor' ),
				'description' => esc_html__( 'Feature icon boxes grid', 'starter-flavor' ),
				'priority'    => 30,
			),
			'services'      => array(
				'title'       => esc_html__( 'Services', 'starter-flavor' ),
				'description' => esc_html__( 'Service cards with icons', 'starter-flavor' ),
				'priority'    => 40,
			),
			'team'          => array(
				'title'       => esc_html__( 'Team', 'starter-flavor' ),
				'description' => esc_html__( 'Team member cards', 'starter-flavor' ),
				'priority'    => 50,
			),
			'testimonials'  => array(
				'title'       => esc_html__( 'Testimonials', 'starter-flavor' ),
				'description' => esc_html__( 'Testimonial carousel', 'starter-flavor' ),
				'priority'    => 60,
			),
			'blog'          => array(
				'title'       => esc_html__( 'Blog', 'starter-flavor' ),
				'description' => esc_html__( 'Latest posts grid', 'starter-flavor' ),
				'priority'    => 70,
			),
			'woocommerce'   => array(
				'title'       => esc_html__( 'WooCommerce', 'starter-flavor' ),
				'description' => esc_html__( 'Featured products', 'starter-flavor' ),
				'priority'    => 80,
			),
			'subscribe'     => array(
				'title'       => esc_html__( 'Subscribe', 'starter-flavor' ),
				'description' => esc_html__( 'Newsletter signup form', 'starter-flavor' ),
				'priority'    => 90,
			),
			'contact'       => array(
				'title'       => esc_html__( 'Contact', 'starter-flavor' ),
				'description' => esc_html__( 'Contact form with map', 'starter-flavor' ),
				'priority'    => 100,
			),
		);

		// Allow filtering sections
		$this->sections = apply_filters( 'sf_front_page_sections', $this->sections );
	}

	/**
	 * Register customizer controls for front page sections
	 *
	 * @since 1.0.0
	 * @param WP_Customize_Manager $wp_customize The customizer object.
	 */
	public function customize_register( $wp_customize ) {
		// Add Front Page Panel
		$wp_customize->add_panel(
			'sf_front_page',
			array(
				'title'       => esc_html__( 'Front Page', 'starter-flavor' ),
				'description' => esc_html__( 'Customize front page sections', 'starter-flavor' ),
				'priority'    => 40,
			)
		);

		// Register each section
		foreach ( $this->sections as $section_id => $section_data ) {
			$this->register_section_controls( $wp_customize, $section_id, $section_data );
		}
	}

	/**
	 * Register controls for a specific section
	 *
	 * @since 1.0.0
	 * @param WP_Customize_Manager $wp_customize The customizer object.
	 * @param string               $section_id The section ID.
	 * @param array                $section_data The section data.
	 */
	private function register_section_controls( $wp_customize, $section_id, $section_data ) {
		// Add Section in Customizer
		$wp_customize->add_section(
			'sf_front_page_' . $section_id,
			array(
				'title'       => $section_data['title'],
				'description' => $section_data['description'],
				'panel'       => 'sf_front_page',
				'priority'    => $section_data['priority'],
			)
		);

		// Enable/Disable Section
		$wp_customize->add_setting(
			'sf_' . $section_id . '_enabled',
			array(
				'default'           => true,
				'sanitize_callback' => array( $this, 'sanitize_checkbox' ),
				'transport'         => 'refresh',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_enabled',
			array(
				'type'    => 'checkbox',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Enable Section', 'starter-flavor' ),
			)
		);

		// Background Color
		$wp_customize->add_setting(
			'sf_' . $section_id . '_bg_color',
			array(
				'default'           => '#ffffff',
				'sanitize_callback' => 'sanitize_hex_color',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			new WP_Customize_Color_Control(
				$wp_customize,
				'sf_' . $section_id . '_bg_color',
				array(
					'label'   => esc_html__( 'Background Color', 'starter-flavor' ),
					'section' => 'sf_front_page_' . $section_id,
				)
			)
		);

		// Background Image
		$wp_customize->add_setting(
			'sf_' . $section_id . '_bg_image',
			array(
				'sanitize_callback' => 'esc_url_raw',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				'sf_' . $section_id . '_bg_image',
				array(
					'label'   => esc_html__( 'Background Image', 'starter-flavor' ),
					'section' => 'sf_front_page_' . $section_id,
				)
			)
		);

		// Padding Top
		$wp_customize->add_setting(
			'sf_' . $section_id . '_padding_top',
			array(
				'default'           => '60',
				'sanitize_callback' => 'absint',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_padding_top',
			array(
				'type'    => 'number',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Padding Top (px)', 'starter-flavor' ),
				'input_attrs' => array(
					'min'  => 0,
					'max'  => 200,
					'step' => 10,
				),
			)
		);

		// Padding Bottom
		$wp_customize->add_setting(
			'sf_' . $section_id . '_padding_bottom',
			array(
				'default'           => '60',
				'sanitize_callback' => 'absint',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_padding_bottom',
			array(
				'type'    => 'number',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Padding Bottom (px)', 'starter-flavor' ),
				'input_attrs' => array(
					'min'  => 0,
					'max'  => 200,
					'step' => 10,
				),
			)
		);

		// Custom CSS Class
		$wp_customize->add_setting(
			'sf_' . $section_id . '_custom_class',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_custom_class',
			array(
				'type'    => 'text',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Custom CSS Class', 'starter-flavor' ),
			)
		);

		// Section-specific controls
		switch ( $section_id ) {
			case 'hero':
				$this->register_hero_controls( $wp_customize, $section_id );
				break;
			case 'about':
				$this->register_about_controls( $wp_customize, $section_id );
				break;
			case 'features':
				$this->register_features_controls( $wp_customize, $section_id );
				break;
			case 'services':
				$this->register_services_controls( $wp_customize, $section_id );
				break;
			case 'team':
				$this->register_team_controls( $wp_customize, $section_id );
				break;
			case 'testimonials':
				$this->register_testimonials_controls( $wp_customize, $section_id );
				break;
			case 'blog':
				$this->register_blog_controls( $wp_customize, $section_id );
				break;
			case 'woocommerce':
				$this->register_woocommerce_controls( $wp_customize, $section_id );
				break;
			case 'subscribe':
				$this->register_subscribe_controls( $wp_customize, $section_id );
				break;
			case 'contact':
				$this->register_contact_controls( $wp_customize, $section_id );
				break;
		}
	}

	/**
	 * Register Hero section controls
	 *
	 * @since 1.0.0
	 * @param WP_Customize_Manager $wp_customize The customizer object.
	 * @param string               $section_id The section ID.
	 */
	private function register_hero_controls( $wp_customize, $section_id ) {
		$wp_customize->add_setting(
			'sf_' . $section_id . '_title',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_title',
			array(
				'type'    => 'text',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Title', 'starter-flavor' ),
			)
		);

		$wp_customize->add_setting(
			'sf_' . $section_id . '_subtitle',
			array(
				'sanitize_callback' => 'sanitize_textarea_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_subtitle',
			array(
				'type'    => 'textarea',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Subtitle', 'starter-flavor' ),
			)
		);

		// CTA Button 1
		$wp_customize->add_setting(
			'sf_' . $section_id . '_cta1_text',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_cta1_text',
			array(
				'type'    => 'text',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Button 1 Text', 'starter-flavor' ),
			)
		);

		$wp_customize->add_setting(
			'sf_' . $section_id . '_cta1_url',
			array(
				'sanitize_callback' => 'esc_url_raw',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_cta1_url',
			array(
				'type'    => 'url',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Button 1 URL', 'starter-flavor' ),
			)
		);

		// CTA Button 2
		$wp_customize->add_setting(
			'sf_' . $section_id . '_cta2_text',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_cta2_text',
			array(
				'type'    => 'text',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Button 2 Text', 'starter-flavor' ),
			)
		);

		$wp_customize->add_setting(
			'sf_' . $section_id . '_cta2_url',
			array(
				'sanitize_callback' => 'esc_url_raw',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_cta2_url',
			array(
				'type'    => 'url',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Button 2 URL', 'starter-flavor' ),
			)
		);

		// Overlay Color
		$wp_customize->add_setting(
			'sf_' . $section_id . '_overlay_color',
			array(
				'default'           => 'rgba(0,0,0,0.3)',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_overlay_color',
			array(
				'type'    => 'text',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Overlay Color', 'starter-flavor' ),
			)
		);

		// Video URL
		$wp_customize->add_setting(
			'sf_' . $section_id . '_video_url',
			array(
				'sanitize_callback' => 'esc_url_raw',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_video_url',
			array(
				'type'    => 'url',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Background Video URL', 'starter-flavor' ),
			)
		);
	}

	/**
	 * Register About section controls
	 *
	 * @since 1.0.0
	 * @param WP_Customize_Manager $wp_customize The customizer object.
	 * @param string               $section_id The section ID.
	 */
	private function register_about_controls( $wp_customize, $section_id ) {
		$wp_customize->add_setting(
			'sf_' . $section_id . '_title',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_title',
			array(
				'type'    => 'text',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Title', 'starter-flavor' ),
			)
		);

		$wp_customize->add_setting(
			'sf_' . $section_id . '_content',
			array(
				'sanitize_callback' => 'wp_kses_post',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_content',
			array(
				'type'    => 'textarea',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Content', 'starter-flavor' ),
			)
		);

		$wp_customize->add_setting(
			'sf_' . $section_id . '_image',
			array(
				'sanitize_callback' => 'esc_url_raw',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				'sf_' . $section_id . '_image',
				array(
					'section' => 'sf_front_page_' . $section_id,
					'label'   => esc_html__( 'Image', 'starter-flavor' ),
				)
			)
		);
	}

	/**
	 * Register Features section controls
	 *
	 * @since 1.0.0
	 * @param WP_Customize_Manager $wp_customize The customizer object.
	 * @param string               $section_id The section ID.
	 */
	private function register_features_controls( $wp_customize, $section_id ) {
		$wp_customize->add_setting(
			'sf_' . $section_id . '_title',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_title',
			array(
				'type'    => 'text',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Title', 'starter-flavor' ),
			)
		);

		$wp_customize->add_setting(
			'sf_' . $section_id . '_columns',
			array(
				'default'           => '3',
				'sanitize_callback' => 'absint',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_columns',
			array(
				'type'    => 'select',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Columns', 'starter-flavor' ),
				'choices' => array(
					'2' => '2',
					'3' => '3',
					'4' => '4',
				),
			)
		);
	}

	/**
	 * Register Services section controls
	 *
	 * @since 1.0.0
	 * @param WP_Customize_Manager $wp_customize The customizer object.
	 * @param string               $section_id The section ID.
	 */
	private function register_services_controls( $wp_customize, $section_id ) {
		$wp_customize->add_setting(
			'sf_' . $section_id . '_title',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_title',
			array(
				'type'    => 'text',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Title', 'starter-flavor' ),
			)
		);
	}

	/**
	 * Register Team section controls
	 *
	 * @since 1.0.0
	 * @param WP_Customize_Manager $wp_customize The customizer object.
	 * @param string               $section_id The section ID.
	 */
	private function register_team_controls( $wp_customize, $section_id ) {
		$wp_customize->add_setting(
			'sf_' . $section_id . '_title',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_title',
			array(
				'type'    => 'text',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Title', 'starter-flavor' ),
			)
		);
	}

	/**
	 * Register Testimonials section controls
	 *
	 * @since 1.0.0
	 * @param WP_Customize_Manager $wp_customize The customizer object.
	 * @param string               $section_id The section ID.
	 */
	private function register_testimonials_controls( $wp_customize, $section_id ) {
		$wp_customize->add_setting(
			'sf_' . $section_id . '_title',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_title',
			array(
				'type'    => 'text',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Title', 'starter-flavor' ),
			)
		);
	}

	/**
	 * Register Blog section controls
	 *
	 * @since 1.0.0
	 * @param WP_Customize_Manager $wp_customize The customizer object.
	 * @param string               $section_id The section ID.
	 */
	private function register_blog_controls( $wp_customize, $section_id ) {
		$wp_customize->add_setting(
			'sf_' . $section_id . '_title',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_title',
			array(
				'type'    => 'text',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Title', 'starter-flavor' ),
			)
		);

		$wp_customize->add_setting(
			'sf_' . $section_id . '_count',
			array(
				'default'           => '6',
				'sanitize_callback' => 'absint',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_count',
			array(
				'type'    => 'number',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Number of Posts', 'starter-flavor' ),
			)
		);
	}

	/**
	 * Register WooCommerce section controls
	 *
	 * @since 1.0.0
	 * @param WP_Customize_Manager $wp_customize The customizer object.
	 * @param string               $section_id The section ID.
	 */
	private function register_woocommerce_controls( $wp_customize, $section_id ) {
		$wp_customize->add_setting(
			'sf_' . $section_id . '_title',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_title',
			array(
				'type'    => 'text',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Title', 'starter-flavor' ),
			)
		);

		$wp_customize->add_setting(
			'sf_' . $section_id . '_count',
			array(
				'default'           => '8',
				'sanitize_callback' => 'absint',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_count',
			array(
				'type'    => 'number',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Number of Products', 'starter-flavor' ),
			)
		);
	}

	/**
	 * Register Subscribe section controls
	 *
	 * @since 1.0.0
	 * @param WP_Customize_Manager $wp_customize The customizer object.
	 * @param string               $section_id The section ID.
	 */
	private function register_subscribe_controls( $wp_customize, $section_id ) {
		$wp_customize->add_setting(
			'sf_' . $section_id . '_title',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_title',
			array(
				'type'    => 'text',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Title', 'starter-flavor' ),
			)
		);

		$wp_customize->add_setting(
			'sf_' . $section_id . '_description',
			array(
				'sanitize_callback' => 'sanitize_textarea_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_description',
			array(
				'type'    => 'textarea',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Description', 'starter-flavor' ),
			)
		);

		$wp_customize->add_setting(
			'sf_' . $section_id . '_form_id',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_form_id',
			array(
				'type'    => 'text',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Mailchimp List ID', 'starter-flavor' ),
			)
		);
	}

	/**
	 * Register Contact section controls
	 *
	 * @since 1.0.0
	 * @param WP_Customize_Manager $wp_customize The customizer object.
	 * @param string               $section_id The section ID.
	 */
	private function register_contact_controls( $wp_customize, $section_id ) {
		$wp_customize->add_setting(
			'sf_' . $section_id . '_title',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_title',
			array(
				'type'    => 'text',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Title', 'starter-flavor' ),
			)
		);

		$wp_customize->add_setting(
			'sf_' . $section_id . '_form_shortcode',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_form_shortcode',
			array(
				'type'    => 'text',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Contact Form Shortcode', 'starter-flavor' ),
			)
		);

		$wp_customize->add_setting(
			'sf_' . $section_id . '_address',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_address',
			array(
				'type'    => 'text',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Address', 'starter-flavor' ),
			)
		);

		$wp_customize->add_setting(
			'sf_' . $section_id . '_phone',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_phone',
			array(
				'type'    => 'text',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Phone', 'starter-flavor' ),
			)
		);

		$wp_customize->add_setting(
			'sf_' . $section_id . '_email',
			array(
				'sanitize_callback' => 'sanitize_email',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_email',
			array(
				'type'    => 'email',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Email', 'starter-flavor' ),
			)
		);

		$wp_customize->add_setting(
			'sf_' . $section_id . '_map_url',
			array(
				'sanitize_callback' => 'esc_url_raw',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_' . $section_id . '_map_url',
			array(
				'type'    => 'url',
				'section' => 'sf_front_page_' . $section_id,
				'label'   => esc_html__( 'Google Maps Embed URL', 'starter-flavor' ),
			)
		);
	}

	/**
	 * Sanitize checkbox value
	 *
	 * @since 1.0.0
	 * @param mixed $value The value to sanitize.
	 * @return bool The sanitized value.
	 */
	public function sanitize_checkbox( $value ) {
		return ! empty( $value );
	}

	/**
	 * Load front page template
	 *
	 * @since 1.0.0
	 * @param string $template The template file path.
	 * @return string The template file path.
	 */
	public function front_page_template( $template ) {
		if ( is_front_page() && ! is_home() ) {
			$custom_template = STARTER_FLAVOR_THEME_DIR . '/front-page.php';

			if ( file_exists( $custom_template ) ) {
				return $custom_template;
			}
		}

		return $template;
	}

	/**
	 * Render a section
	 *
	 * @since 1.0.0
	 * @param string $section_id The section ID.
	 */
	public function render_section( $section_id ) {
		// Check if section is enabled
		if ( ! get_theme_mod( 'sf_' . $section_id . '_enabled', true ) ) {
			return;
		}

		$template_path = STARTER_FLAVOR_THEME_DIR . '/template-parts/front-page/section-' . $section_id . '.php';

		if ( file_exists( $template_path ) ) {
			get_template_part( 'template-parts/front-page/section', $section_id );
		}
	}

	/**
	 * Get section data
	 *
	 * @since 1.0.0
	 * @param string $section_id The section ID.
	 * @return array Section data.
	 */
	public function get_section_data( $section_id ) {
		$data = array();

		// Get all theme mods for this section
		$mods = get_theme_mods();

		foreach ( $mods as $key => $value ) {
			if ( strpos( $key, 'sf_' . $section_id . '_' ) === 0 ) {
				$data_key = str_replace( 'sf_' . $section_id . '_', '', $key );
				$data[ $data_key ] = $value;
			}
		}

		return $data;
	}

	/**
	 * Get all sections
	 *
	 * @since 1.0.0
	 * @return array All sections.
	 */
	public function get_sections() {
		return $this->sections;
	}
}

// Initialize the class
function starter_flavor_front_page() {
	static $instance = null;

	if ( is_null( $instance ) ) {
		$instance = new Starter_Flavor_Front_Page();
	}

	return $instance;
}

// Get the front page instance
starter_flavor_front_page();
