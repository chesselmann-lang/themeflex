<?php
/**
 * Mega Menu Walker and Settings
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Starter Flavor Mega Menu Walker Class
 *
 * Extends Walker_Nav_Menu to support mega menu functionality.
 *
 * @since 1.0.0
 */
class Starter_Flavor_Mega_Menu_Walker extends Walker_Nav_Menu {

	/**
	 * Starts the list before the elements are added.
	 *
	 * @since 1.0.0
	 * @param string $output Passed by reference.
	 * @param int    $depth  Depth of menu item.
	 * @param array  $args   Arguments.
	 */
	public function start_lvl( &$output, $depth = 0, $args = null ) {
		if ( isset( $args->item_spacing ) && 'discard' === $args->item_spacing ) {
			$indent = '';
			$output .= "\n";
		} else {
			$indent = str_repeat( "\t", $depth + 1 );
			$output .= "\n$indent";
		}

		$output .= '<ul class="sub-menu">' . "\n";
	}

	/**
	 * Ends the list of after the elements are added.
	 *
	 * @since 1.0.0
	 * @param string $output Passed by reference.
	 * @param int    $depth  Depth of menu item.
	 * @param array  $args   Arguments.
	 */
	public function end_lvl( &$output, $depth = 0, $args = null ) {
		if ( isset( $args->item_spacing ) && 'discard' === $args->item_spacing ) {
			$indent = '';
		} else {
			$indent = str_repeat( "\t", $depth + 1 );
		}

		$output .= "$indent</ul>\n";
	}

	/**
	 * Start the element output.
	 *
	 * @since 1.0.0
	 * @param string   $output            Passed by reference.
	 * @param WP_Post  $item              Menu item.
	 * @param int      $depth             Depth of menu item.
	 * @param stdClass $args              Arguments.
	 * @param int      $id                Item ID.
	 */
	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
		if ( isset( $args->item_spacing ) && 'discard' === $args->item_spacing ) {
			$indent = '';
		} else {
			$indent = str_repeat( "\t", $depth + 1 );
		}

		$indent = apply_filters( 'nav_menu_item_indent', $indent, $depth, $args );
		$output .= $indent . '<li';

		// Add ID attribute
		$id = apply_filters( 'nav_menu_item_id', 'menu-item-' . $item->ID, $item, $args, $depth );
		if ( $id ) {
			$output .= ' id="' . esc_attr( $id ) . '"';
		}

		// Add menu item classes
		$class_names = array( 'menu-item', 'menu-item-' . $item->ID );

		// Add post type specific class
		$class_names[] = 'menu-item-type-' . $item->type;

		// Add post status class
		$class_names[] = 'menu-item-object-' . $item->object;

		// Add current item class
		if ( in_array( 'current-menu-item', $item->classes, true ) ) {
			$class_names[] = 'current-menu-item';
		}

		// Add parent class if has children
		if ( in_array( 'menu-item-has-children', $item->classes, true ) ) {
			$class_names[] = 'menu-item-has-children';
		}

		// Check for mega menu
		$enable_mega = get_post_meta( $item->ID, 'sf_mega_menu_enable', true );
		if ( $enable_mega ) {
			$class_names[] = 'mega-menu-item';
		}

		$class_names = apply_filters( 'nav_menu_item_class', implode( ' ', $class_names ), $item, $args, $depth );
		$output .= ' class="' . esc_attr( $class_names ) . '">';

		// Link attributes
		$atts = array();
		$atts['title']  = ! empty( $item->attr_title ) ? $item->attr_title : '';
		$atts['target'] = ! empty( $item->target ) ? $item->target : '';
		$atts['rel']    = ! empty( $item->xfn ) ? $item->xfn : '';
		$atts['href']   = ! empty( $item->url ) ? $item->url : '';

		// Add mega menu class to link
		if ( $enable_mega ) {
			$atts['class'] = 'mega-menu-link';
		}

		$atts = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args, $depth );

		$attributes = '';
		foreach ( $atts as $attr => $value ) {
			if ( ! empty( $value ) ) {
				$value = 'href' === $attr ? $value : esc_attr( $value );
				$attributes .= ' ' . $attr . '="' . $value . '"';
			}
		}

		$title = apply_filters( 'nav_menu_item_title', $item->title, $item, $args, $depth );
		$title = apply_filters( 'the_title', $title, $item->ID );
		$title = esc_attr( $title );

		$output .= '<a' . $attributes . '>';
		$output .= $title;
		$output .= '</a>';

		// Add mega menu panel
		if ( $enable_mega && in_array( 'menu-item-has-children', $item->classes, true ) ) {
			$columns = (int) get_post_meta( $item->ID, 'sf_mega_menu_columns', true );
			$columns = ! empty( $columns ) && $columns >= 2 && $columns <= 5 ? $columns : 3;
			$bg_image = get_post_meta( $item->ID, 'sf_mega_menu_bg_image', true );

			$output .= '<div class="mega-menu-panel mega-menu-cols-' . absint( $columns ) . '"';
			if ( ! empty( $bg_image ) ) {
				$output .= ' style="background-image: url(\'' . esc_url( $bg_image ) . '\');"';
			}
			$output .= '>';
			$output .= '<div class="mega-menu-inner">';

			// Output widget areas or submenu items
			if ( ! empty( $item->classes ) && in_array( 'mega-menu-item', $item->classes, true ) ) {
				// Use submenu items in columns
				$output .= $this->render_mega_menu_items( $item, $args, $depth );
			}

			$output .= '</div></div>';
		}

		// Display submenu if not mega menu
		if ( ! $enable_mega && in_array( 'menu-item-has-children', $item->classes, true ) ) {
			// Submenu will be handled by end_el
		}
	}

	/**
	 * Render mega menu items.
	 *
	 * @since 1.0.0
	 * @param WP_Post  $parent_item The parent menu item.
	 * @param stdClass $args        Menu arguments.
	 * @param int      $depth       Current depth.
	 * @return string The HTML output.
	 */
	private function render_mega_menu_items( $parent_item, $args, $depth ) {
		global $wpdb;

		$output = '';
		$columns = (int) get_post_meta( $parent_item->ID, 'sf_mega_menu_columns', true );
		$columns = ! empty( $columns ) && $columns >= 2 && $columns <= 5 ? $columns : 3;

		// Get child menu items
		$children = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $wpdb->postmeta
				INNER JOIN $wpdb->posts ON ($wpdb->posts.ID = $wpdb->postmeta.post_id)
				WHERE $wpdb->postmeta.meta_key = '_menu_item_menu_item_parent'
				AND $wpdb->postmeta.meta_value = %d
				AND $wpdb->posts.post_status = 'publish'
				ORDER BY $wpdb->posts.menu_order ASC",
				$parent_item->ID
			)
		);

		if ( empty( $children ) ) {
			return '';
		}

		// Distribute children across columns
		$items_per_column = ceil( count( $children ) / $columns );
		$current_column = 0;

		foreach ( $children as $index => $child ) {
			if ( 0 === ( $index % $items_per_column ) ) {
				if ( $index > 0 ) {
					$output .= '</div>';
				}
				$current_column++;
				$output .= '<div class="mega-menu-column mega-menu-col-' . absint( $current_column ) . '">';
			}

			$output .= '<div class="mega-menu-item-link">';
			$output .= '<a href="' . esc_url( get_post_meta( $child->ID, '_menu_item_url', true ) ) . '">';
			$output .= esc_html( $child->post_title );
			$output .= '</a>';
			$output .= '</div>';
		}

		if ( $index >= 0 ) {
			$output .= '</div>';
		}

		return $output;
	}
}

/**
 * Starter Flavor Mega Menu Settings Class
 *
 * Handles admin UI for mega menu configuration.
 *
 * @since 1.0.0
 */
class Starter_Flavor_Mega_Menu_Settings {

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'wp_nav_menu_item_custom_fields', array( $this, 'add_custom_fields' ), 10, 4 );
		add_action( 'wp_update_nav_menu_item', array( $this, 'save_custom_fields' ), 10, 3 );
	}

	/**
	 * Add custom fields to menu item.
	 *
	 * @since 1.0.0
	 * @param int      $item_id       Menu item ID.
	 * @param WP_Post  $item          Menu item object.
	 * @param int      $depth         Menu depth.
	 * @param stdClass $args          Menu arguments.
	 */
	public function add_custom_fields( $item_id, $item, $depth, $args ) {
		$enable_mega = get_post_meta( $item_id, 'sf_mega_menu_enable', true );
		$columns = get_post_meta( $item_id, 'sf_mega_menu_columns', true );
		$bg_image = get_post_meta( $item_id, 'sf_mega_menu_bg_image', true );

		// Check if item has children
		global $wpdb;
		$has_children = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM $wpdb->postmeta
				WHERE meta_key = '_menu_item_menu_item_parent'
				AND meta_value = %d",
				$item_id
			)
		);

		if ( ! $has_children ) {
			return;
		}

		?>
		<p class="sf-mega-menu-field">
			<label for="edit-menu-item-mega-<?php echo absint( $item_id ); ?>">
				<input type="checkbox" id="edit-menu-item-mega-<?php echo absint( $item_id ); ?>"
					name="menu-item-mega-enable[<?php echo absint( $item_id ); ?>]"
					value="1" <?php checked( $enable_mega, 1 ); ?> />
				<?php esc_html_e( 'Enable Mega Menu', 'starter-flavor' ); ?>
			</label>
		</p>

		<p class="sf-mega-menu-field sf-mega-menu-columns-field" style="display: <?php echo $enable_mega ? 'block' : 'none'; ?>;">
			<label for="edit-menu-item-cols-<?php echo absint( $item_id ); ?>">
				<?php esc_html_e( 'Columns:', 'starter-flavor' ); ?>
				<select id="edit-menu-item-cols-<?php echo absint( $item_id ); ?>"
					name="menu-item-mega-columns[<?php echo absint( $item_id ); ?>]">
					<?php
					for ( $i = 2; $i <= 5; $i++ ) {
						?>
						<option value="<?php echo absint( $i ); ?>" <?php selected( $columns, $i ); ?>>
							<?php echo absint( $i ); ?>
						</option>
						<?php
					}
					?>
				</select>
			</label>
		</p>

		<p class="sf-mega-menu-field sf-mega-menu-bg-field">
			<label for="edit-menu-item-bg-<?php echo absint( $item_id ); ?>">
				<?php esc_html_e( 'Background Image URL:', 'starter-flavor' ); ?><br />
				<input type="url" id="edit-menu-item-bg-<?php echo absint( $item_id ); ?>"
					name="menu-item-mega-bg[<?php echo absint( $item_id ); ?>]"
					value="<?php echo esc_url( $bg_image ); ?>"
					style="width: 100%; box-sizing: border-box;" />
			</label>
		</p>

		<script>
			(function() {
				const checkbox = document.getElementById( 'edit-menu-item-mega-<?php echo absint( $item_id ); ?>' );
				const columnsField = document.querySelector( '.sf-mega-menu-columns-field' );

				checkbox.addEventListener( 'change', function() {
					columnsField.style.display = this.checked ? 'block' : 'none';
				});
			})();
		</script>

		<style>
			.sf-mega-menu-field {
				padding: 5px 0;
			}
			.sf-mega-menu-field label {
				display: block;
			}
			.sf-mega-menu-field input,
			.sf-mega-menu-field select {
				padding: 4px 6px;
				border: 1px solid #ddd;
				border-radius: 3px;
			}
		</style>
		<?php
	}

	/**
	 * Save custom fields.
	 *
	 * @since 1.0.0
	 * @param int   $item_id    Menu item ID.
	 * @param int   $menu_id    Menu ID.
	 * @param array $args       Menu arguments.
	 */
	public function save_custom_fields( $item_id, $menu_id, $args ) {
		// Save mega menu enable
		$enable_mega = isset( $_POST['menu-item-mega-enable'][ $item_id ] ) ? 1 : 0;
		update_post_meta( $item_id, 'sf_mega_menu_enable', $enable_mega );

		// Save columns
		if ( isset( $_POST['menu-item-mega-columns'][ $item_id ] ) ) {
			$columns = absint( $_POST['menu-item-mega-columns'][ $item_id ] );
			$columns = min( max( $columns, 2 ), 5 ); // Ensure 2-5
			update_post_meta( $item_id, 'sf_mega_menu_columns', $columns );
		}

		// Save background image
		if ( isset( $_POST['menu-item-mega-bg'][ $item_id ] ) ) {
			$bg_image = esc_url_raw( $_POST['menu-item-mega-bg'][ $item_id ] );
			update_post_meta( $item_id, 'sf_mega_menu_bg_image', $bg_image );
		}
	}
}

// Initialize the class
new Starter_Flavor_Mega_Menu_Settings();

/**
 * Get mega menu walker.
 *
 * @since 1.0.0
 * @return Starter_Flavor_Mega_Menu_Walker The mega menu walker instance.
 */
function starter_flavor_get_mega_menu_walker() {
	return new Starter_Flavor_Mega_Menu_Walker();
}
