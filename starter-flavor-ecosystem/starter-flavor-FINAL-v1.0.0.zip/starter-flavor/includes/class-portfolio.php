<?php
/**
 * Portfolio Custom Post Type
 *
 * Registers portfolio post type and taxonomy for managing portfolio items.
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Starter_Flavor_Portfolio {

	/**
	 * Initialize portfolio CPT
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_post_type' ) );
		add_action( 'init', array( __CLASS__, 'register_taxonomy' ) );
		add_action( 'admin_init', array( __CLASS__, 'add_metaboxes' ) );
		add_action( 'save_post_sf_portfolio', array( __CLASS__, 'save_metabox_data' ) );
		add_filter( 'manage_sf_portfolio_posts_columns', array( __CLASS__, 'portfolio_columns' ) );
		add_action( 'manage_sf_portfolio_posts_custom_column', array( __CLASS__, 'portfolio_column_content' ), 10, 2 );
	}

	/**
	 * Register portfolio post type
	 */
	public static function register_post_type() {
		$labels = array(
			'name'                  => esc_html_x( 'Portfolio', 'post type general name', 'starter-flavor' ),
			'singular_name'         => esc_html_x( 'Portfolio Item', 'post type singular name', 'starter-flavor' ),
			'menu_name'             => esc_html_x( 'Portfolio', 'admin menu', 'starter-flavor' ),
			'name_admin_bar'        => esc_html_x( 'Portfolio Item', 'add new on admin bar', 'starter-flavor' ),
			'add_new'               => esc_html__( 'Add New', 'starter-flavor' ),
			'add_new_item'          => esc_html__( 'Add New Portfolio Item', 'starter-flavor' ),
			'new_item'              => esc_html__( 'New Portfolio Item', 'starter-flavor' ),
			'edit_item'             => esc_html__( 'Edit Portfolio Item', 'starter-flavor' ),
			'view_item'             => esc_html__( 'View Portfolio Item', 'starter-flavor' ),
			'all_items'             => esc_html__( 'All Portfolio Items', 'starter-flavor' ),
			'search_items'          => esc_html__( 'Search Portfolio Items', 'starter-flavor' ),
			'parent_item_colon'     => esc_html__( 'Parent Portfolio Items:', 'starter-flavor' ),
			'not_found'             => esc_html__( 'No portfolio items found.', 'starter-flavor' ),
			'not_found_in_trash'    => esc_html__( 'No portfolio items found in Trash.', 'starter-flavor' ),
			'featured_image'        => esc_html__( 'Portfolio Image', 'starter-flavor' ),
			'set_featured_image'    => esc_html__( 'Set portfolio image', 'starter-flavor' ),
			'remove_featured_image' => esc_html__( 'Remove portfolio image', 'starter-flavor' ),
			'use_featured_image'    => esc_html__( 'Use as portfolio image', 'starter-flavor' ),
		);

		$args = array(
			'labels'               => $labels,
			'description'          => esc_html__( 'Portfolio items', 'starter-flavor' ),
			'public'               => true,
			'publicly_queryable'   => true,
			'show_ui'              => true,
			'show_in_menu'         => true,
			'query_var'            => true,
			'rewrite'              => array( 'slug' => 'portfolio' ),
			'capability_type'      => 'post',
			'has_archive'          => true,
			'hierarchical'         => false,
			'menu_position'        => 5,
			'menu_icon'            => 'dashicons-format-gallery',
			'supports'             => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'custom-fields' ),
			'show_in_rest'         => true,
			'rest_base'            => 'portfolio',
			'rest_controller_class' => 'WP_REST_Posts_Controller',
		);

		register_post_type( 'sf_portfolio', $args );
	}

	/**
	 * Register portfolio category taxonomy
	 */
	public static function register_taxonomy() {
		$labels = array(
			'name'              => esc_html_x( 'Categories', 'taxonomy general name', 'starter-flavor' ),
			'singular_name'     => esc_html_x( 'Category', 'taxonomy singular name', 'starter-flavor' ),
			'search_items'      => esc_html__( 'Search Categories', 'starter-flavor' ),
			'all_items'         => esc_html__( 'All Categories', 'starter-flavor' ),
			'parent_item'       => esc_html__( 'Parent Category', 'starter-flavor' ),
			'parent_item_colon' => esc_html__( 'Parent Category:', 'starter-flavor' ),
			'edit_item'         => esc_html__( 'Edit Category', 'starter-flavor' ),
			'update_item'       => esc_html__( 'Update Category', 'starter-flavor' ),
			'add_new_item'      => esc_html__( 'Add New Category', 'starter-flavor' ),
			'new_item_name'     => esc_html__( 'New Category Name', 'starter-flavor' ),
			'menu_name'         => esc_html__( 'Categories', 'starter-flavor' ),
		);

		$args = array(
			'labels'            => $labels,
			'description'       => esc_html__( 'Portfolio categories', 'starter-flavor' ),
			'public'            => true,
			'publicly_queryable' => true,
			'hierarchical'      => true,
			'show_ui'           => true,
			'show_in_menu'      => true,
			'show_in_nav_menus' => true,
			'query_var'         => true,
			'rewrite'           => array( 'slug' => 'portfolio-category' ),
			'show_in_rest'      => true,
			'rest_base'         => 'portfolio-categories',
		);

		register_taxonomy( 'sf_portfolio_category', array( 'sf_portfolio' ), $args );
	}

	/**
	 * Add portfolio metaboxes
	 */
	public static function add_metaboxes() {
		add_meta_box(
			'sf_portfolio_details',
			esc_html__( 'Portfolio Details', 'starter-flavor' ),
			array( __CLASS__, 'render_metabox' ),
			'sf_portfolio',
			'normal',
			'high'
		);
	}

	/**
	 * Render portfolio metabox
	 */
	public static function render_metabox( $post ) {
		wp_nonce_field( 'sf_portfolio_nonce', 'sf_portfolio_nonce' );

		$client = get_post_meta( $post->ID, '_sf_portfolio_client', true );
		$url = get_post_meta( $post->ID, '_sf_portfolio_url', true );
		$date = get_post_meta( $post->ID, '_sf_portfolio_date', true );
		$gallery = get_post_meta( $post->ID, '_sf_portfolio_gallery', true );
		?>

		<div style="margin-bottom: 20px;">
			<label for="sf_portfolio_client" style="display: block; margin-bottom: 8px; font-weight: 600;">
				<?php esc_html_e( 'Client Name', 'starter-flavor' ); ?>
			</label>
			<input type="text" id="sf_portfolio_client" name="sf_portfolio_client" value="<?php echo esc_attr( $client ); ?>" style="width: 100%; padding: 8px; box-sizing: border-box;">
		</div>

		<div style="margin-bottom: 20px;">
			<label for="sf_portfolio_url" style="display: block; margin-bottom: 8px; font-weight: 600;">
				<?php esc_html_e( 'Project URL', 'starter-flavor' ); ?>
			</label>
			<input type="url" id="sf_portfolio_url" name="sf_portfolio_url" value="<?php echo esc_url( $url ); ?>" placeholder="https://example.com" style="width: 100%; padding: 8px; box-sizing: border-box;">
		</div>

		<div style="margin-bottom: 20px;">
			<label for="sf_portfolio_date" style="display: block; margin-bottom: 8px; font-weight: 600;">
				<?php esc_html_e( 'Project Date', 'starter-flavor' ); ?>
			</label>
			<input type="date" id="sf_portfolio_date" name="sf_portfolio_date" value="<?php echo esc_attr( $date ); ?>" style="width: 100%; padding: 8px; box-sizing: border-box;">
		</div>

		<div>
			<label style="display: block; margin-bottom: 8px; font-weight: 600;">
				<?php esc_html_e( 'Project Gallery', 'starter-flavor' ); ?>
			</label>
			<input type="hidden" id="sf_portfolio_gallery" name="sf_portfolio_gallery" value="<?php echo esc_attr( $gallery ); ?>">
			<button type="button" id="sf_portfolio_gallery_btn" class="button">
				<?php esc_html_e( 'Add Gallery Images', 'starter-flavor' ); ?>
			</button>
			<div id="sf_portfolio_gallery_preview" style="margin-top: 15px;"></div>
		</div>

		<script>
			(function($) {
				$('#sf_portfolio_gallery_btn').on('click', function(e) {
					e.preventDefault();
					const frame = wp.media({
						title: '<?php esc_attr_e( 'Select Images', 'starter-flavor' ); ?>',
						button: {
							text: '<?php esc_attr_e( 'Use Images', 'starter-flavor' ); ?>'
						},
						multiple: true
					});

					frame.on('select', function() {
						const attachments = frame.state().get('selection').toJSON();
						const ids = attachments.map(a => a.id).join(',');
						$('#sf_portfolio_gallery').val(ids);
						renderGalleryPreview(attachments);
					});

					frame.open();
				});

				function renderGalleryPreview(attachments) {
					const preview = $('#sf_portfolio_gallery_preview');
					preview.empty();

					if (attachments.length === 0) return;

					const html = '<div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); gap: 10px;">' +
						attachments.map(att => '<img src="' + att.url + '" style="width: 100%; height: auto; border-radius: 4px;">').join('') +
						'</div>';

					preview.html(html);
				}

				// Initial preview
				const galleryVal = $('#sf_portfolio_gallery').val();
				if (galleryVal) {
					const ids = galleryVal.split(',');
					const attachments = <?php echo json_encode( array() ); ?>;
					// Load attachments data via AJAX if needed
				}
			})(jQuery);
		</script>
		<?php
	}

	/**
	 * Save portfolio metabox data
	 */
	public static function save_metabox_data( $post_id ) {
		if ( ! isset( $_POST['sf_portfolio_nonce'] ) || ! wp_verify_nonce( $_POST['sf_portfolio_nonce'], 'sf_portfolio_nonce' ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// Save client
		if ( isset( $_POST['sf_portfolio_client'] ) ) {
			update_post_meta( $post_id, '_sf_portfolio_client', sanitize_text_field( $_POST['sf_portfolio_client'] ) );
		}

		// Save URL
		if ( isset( $_POST['sf_portfolio_url'] ) ) {
			update_post_meta( $post_id, '_sf_portfolio_url', esc_url_raw( $_POST['sf_portfolio_url'] ) );
		}

		// Save date
		if ( isset( $_POST['sf_portfolio_date'] ) ) {
			update_post_meta( $post_id, '_sf_portfolio_date', sanitize_text_field( $_POST['sf_portfolio_date'] ) );
		}

		// Save gallery
		if ( isset( $_POST['sf_portfolio_gallery'] ) ) {
			update_post_meta( $post_id, '_sf_portfolio_gallery', sanitize_text_field( $_POST['sf_portfolio_gallery'] ) );
		}
	}

	/**
	 * Portfolio admin columns
	 */
	public static function portfolio_columns( $columns ) {
		$columns = array(
			'cb'       => $columns['cb'],
			'title'    => esc_html__( 'Title', 'starter-flavor' ),
			'thumbnail' => esc_html__( 'Image', 'starter-flavor' ),
			'category' => esc_html__( 'Category', 'starter-flavor' ),
			'date'     => esc_html__( 'Date', 'starter-flavor' ),
		);

		return $columns;
	}

	/**
	 * Portfolio column content
	 */
	public static function portfolio_column_content( $column, $post_id ) {
		switch ( $column ) {
			case 'thumbnail':
				if ( has_post_thumbnail( $post_id ) ) {
					echo get_the_post_thumbnail( $post_id, array( 50, 50 ) );
				}
				break;

			case 'category':
				$terms = wp_get_post_terms( $post_id, 'sf_portfolio_category' );
				if ( ! empty( $terms ) ) {
					$names = wp_list_pluck( $terms, 'name' );
					echo esc_html( implode( ', ', $names ) );
				}
				break;
		}
	}
}

// Initialize portfolio CPT
add_action( 'init', array( 'Starter_Flavor_Portfolio', 'init' ) );
