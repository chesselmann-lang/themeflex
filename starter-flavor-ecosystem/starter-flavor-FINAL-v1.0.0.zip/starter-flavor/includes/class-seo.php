<?php
/**
 * SEO Class
 *
 * Comprehensive SEO support with structured data and meta tags.
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Starter_Flavor_SEO class
 */
class Starter_Flavor_SEO {

	/**
	 * Instance variable
	 *
	 * @var Starter_Flavor_SEO
	 */
	private static $instance = null;

	/**
	 * Get instance
	 *
	 * @return Starter_Flavor_SEO
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		// Only proceed if Yoast/RankMath aren't active
		if ( $this->has_seo_plugin() ) {
			return;
		}

		add_action( 'wp_head', array( $this, 'output_meta_tags' ) );
		add_action( 'wp_head', array( $this, 'output_structured_data' ) );
		add_action( 'customize_register', array( $this, 'register_customizer_settings' ) );
	}

	/**
	 * Check if SEO plugin is active
	 *
	 * @return bool
	 */
	private function has_seo_plugin() {
		return (
			defined( 'WPSEO_VERSION' ) ||
			defined( 'RANK_MATH_VERSION' ) ||
			class_exists( 'All_in_One_SEO_Pack' )
		);
	}

	/**
	 * Output meta tags
	 */
	public function output_meta_tags() {
		// Open Graph Meta Tags
		$this->output_og_tags();

		// Twitter Card Meta Tags
		$this->output_twitter_tags();

		// Canonical URL
		$this->output_canonical();
	}

	/**
	 * Output Open Graph meta tags
	 */
	private function output_og_tags() {
		$og_type = 'website';
		$og_title = get_bloginfo( 'name' );
		$og_description = get_bloginfo( 'description' );
		$og_image = '';

		if ( is_singular() ) {
			if ( is_singular( 'post' ) ) {
				$og_type = 'article';
			}

			$og_title = get_the_title();
			$og_description = wp_strip_all_tags( get_the_excerpt() );

			if ( empty( $og_description ) ) {
				$og_description = wp_strip_all_tags( substr( get_the_content(), 0, 160 ) );
			}

			if ( has_post_thumbnail() ) {
				$og_image = get_the_post_thumbnail_url();
			}
		}

		echo '<meta property="og:type" content="' . esc_attr( $og_type ) . '" />' . "\n";
		echo '<meta property="og:title" content="' . esc_attr( $og_title ) . '" />' . "\n";
		echo '<meta property="og:description" content="' . esc_attr( $og_description ) . '" />' . "\n";
		echo '<meta property="og:url" content="' . esc_attr( get_the_permalink() ) . '" />' . "\n";
		echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '" />' . "\n";

		if ( ! empty( $og_image ) ) {
			echo '<meta property="og:image" content="' . esc_attr( $og_image ) . '" />' . "\n";
		}
	}

	/**
	 * Output Twitter card meta tags
	 */
	private function output_twitter_tags() {
		$twitter_card = 'summary_large_image';
		$twitter_title = get_bloginfo( 'name' );
		$twitter_description = get_bloginfo( 'description' );
		$twitter_image = '';

		if ( is_singular() ) {
			$twitter_title = get_the_title();
			$twitter_description = wp_strip_all_tags( get_the_excerpt() );

			if ( empty( $twitter_description ) ) {
				$twitter_description = wp_strip_all_tags( substr( get_the_content(), 0, 160 ) );
			}

			if ( has_post_thumbnail() ) {
				$twitter_image = get_the_post_thumbnail_url();
			}
		}

		echo '<meta name="twitter:card" content="' . esc_attr( $twitter_card ) . '" />' . "\n";
		echo '<meta name="twitter:title" content="' . esc_attr( $twitter_title ) . '" />' . "\n";
		echo '<meta name="twitter:description" content="' . esc_attr( $twitter_description ) . '" />' . "\n";

		if ( ! empty( $twitter_image ) ) {
			echo '<meta name="twitter:image" content="' . esc_attr( $twitter_image ) . '" />' . "\n";
		}
	}

	/**
	 * Output canonical URL tag
	 */
	private function output_canonical() {
		echo '<link rel="canonical" href="' . esc_attr( get_the_permalink() ) . '" />' . "\n";
	}

	/**
	 * Output structured data
	 */
	public function output_structured_data() {
		if ( is_singular( 'post' ) ) {
			$this->output_article_schema();
		} elseif ( is_author() ) {
			$this->output_person_schema();
		} elseif ( is_home() || is_archive() ) {
			$this->output_organization_schema();
		}

		// Breadcrumbs
		if ( ! is_home() && ! is_front_page() ) {
			$this->output_breadcrumb_schema();
		}
	}

	/**
	 * Output article schema
	 */
	private function output_article_schema() {
		$schema = array(
			'@context'            => 'https://schema.org',
			'@type'               => 'BlogPosting',
			'headline'            => get_the_title(),
			'description'         => wp_strip_all_tags( get_the_excerpt() ),
			'datePublished'       => get_the_date( 'c' ),
			'dateModified'        => get_the_modified_date( 'c' ),
			'author'              => array(
				'@type' => 'Person',
				'name'  => get_the_author(),
				'url'   => get_author_posts_url( get_the_author_meta( 'ID' ) ),
			),
			'mainEntityOfPage'    => array(
				'@type' => 'WebPage',
				'@id'   => get_the_permalink(),
			),
		);

		if ( has_post_thumbnail() ) {
			$schema['image'] = get_the_post_thumbnail_url();
		}

		echo '<script type="application/ld+json">' . wp_json_encode( $schema ) . '</script>' . "\n";
	}

	/**
	 * Output person schema
	 */
	private function output_person_schema() {
		$author_id = get_queried_object_id();
		$user = get_user_by( 'ID', $author_id );

		if ( ! $user ) {
			return;
		}

		$schema = array(
			'@context'      => 'https://schema.org',
			'@type'         => 'Person',
			'name'          => $user->display_name,
			'url'           => get_author_posts_url( $author_id ),
			'description'   => $user->description,
		);

		if ( ! empty( $user->user_url ) ) {
			$schema['sameAs'] = $user->user_url;
		}

		echo '<script type="application/ld+json">' . wp_json_encode( $schema ) . '</script>' . "\n";
	}

	/**
	 * Output organization schema
	 */
	private function output_organization_schema() {
		$organization_name = get_theme_mod( 'starter_flavor_seo_org_name', get_bloginfo( 'name' ) );
		$organization_logo = get_theme_mod( 'starter_flavor_seo_org_logo', '' );

		if ( empty( $organization_name ) ) {
			return;
		}

		$schema = array(
			'@context' => 'https://schema.org',
			'@type'    => 'Organization',
			'name'     => $organization_name,
			'url'      => get_home_url(),
		);

		if ( ! empty( $organization_logo ) ) {
			$schema['logo'] = $organization_logo;
		}

		echo '<script type="application/ld+json">' . wp_json_encode( $schema ) . '</script>' . "\n";
	}

	/**
	 * Output breadcrumb schema
	 */
	private function output_breadcrumb_schema() {
		$breadcrumbs = $this->get_breadcrumbs();

		if ( empty( $breadcrumbs ) ) {
			return;
		}

		$items = array();

		foreach ( $breadcrumbs as $index => $breadcrumb ) {
			$items[] = array(
				'@type'    => 'ListItem',
				'position' => $index + 1,
				'name'     => $breadcrumb['title'],
				'item'     => $breadcrumb['url'],
			);
		}

		$schema = array(
			'@context'        => 'https://schema.org',
			'@type'           => 'BreadcrumbList',
			'itemListElement' => $items,
		);

		echo '<script type="application/ld+json">' . wp_json_encode( $schema ) . '</script>' . "\n";
	}

	/**
	 * Get breadcrumb structure
	 *
	 * @return array
	 */
	public function get_breadcrumbs() {
		$breadcrumbs = array();

		// Home
		$breadcrumbs[] = array(
			'title' => get_bloginfo( 'name' ),
			'url'   => get_home_url(),
		);

		if ( is_singular( 'post' ) ) {
			// Categories
			$categories = get_the_category();
			if ( ! empty( $categories ) ) {
				$breadcrumbs[] = array(
					'title' => $categories[0]->name,
					'url'   => get_category_link( $categories[0] ),
				);
			}

			// Current post
			$breadcrumbs[] = array(
				'title' => get_the_title(),
				'url'   => get_the_permalink(),
			);
		} elseif ( is_author() ) {
			$breadcrumbs[] = array(
				'title' => get_the_author(),
				'url'   => get_author_posts_url( get_the_author_meta( 'ID' ) ),
			);
		} elseif ( is_archive() ) {
			if ( is_category() ) {
				$breadcrumbs[] = array(
					'title' => single_cat_title( '', false ),
					'url'   => get_the_permalink(),
				);
			} elseif ( is_tag() ) {
				$breadcrumbs[] = array(
					'title' => single_tag_title( '', false ),
					'url'   => get_the_permalink(),
				);
			}
		} elseif ( is_page() ) {
			$breadcrumbs[] = array(
				'title' => get_the_title(),
				'url'   => get_the_permalink(),
			);
		} elseif ( is_search() ) {
			$breadcrumbs[] = array(
				'title' => esc_html__( 'Search Results', 'starter-flavor' ),
				'url'   => get_search_link(),
			);
		}

		return $breadcrumbs;
	}

	/**
	 * Register customizer settings
	 *
	 * @param WP_Customize_Manager $wp_customize The customizer object.
	 */
	public function register_customizer_settings( $wp_customize ) {
		if ( $this->has_seo_plugin() ) {
			return;
		}

		// SEO Panel
		$wp_customize->add_panel(
			'starter_flavor_seo',
			array(
				'title'       => esc_html__( 'SEO & Schema', 'starter-flavor' ),
				'description' => esc_html__( 'Configure SEO settings', 'starter-flavor' ),
				'priority'    => 90,
			)
		);

		// Organization Name
		$wp_customize->add_setting(
			'starter_flavor_seo_org_name',
			array(
				'default'           => get_bloginfo( 'name' ),
				'sanitize_callback' => 'sanitize_text_field',
			)
		);

		$wp_customize->add_control(
			'starter_flavor_seo_org_name',
			array(
				'type'     => 'text',
				'section'  => 'starter_flavor_seo',
				'label'    => esc_html__( 'Organization Name', 'starter-flavor' ),
				'priority' => 10,
			)
		);

		// Organization Logo
		$wp_customize->add_setting(
			'starter_flavor_seo_org_logo',
			array(
				'default'           => '',
				'sanitize_callback' => 'esc_url_raw',
			)
		);

		$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				'starter_flavor_seo_org_logo',
				array(
					'section'  => 'starter_flavor_seo',
					'label'    => esc_html__( 'Organization Logo', 'starter-flavor' ),
					'priority' => 20,
				)
			)
		);
	}
}

// Initialize
if ( ! function_exists( 'starter_flavor_seo' ) ) {
	/**
	 * Get SEO instance
	 *
	 * @return Starter_Flavor_SEO
	 */
	function starter_flavor_seo() {
		return Starter_Flavor_SEO::get_instance();
	}
}

starter_flavor_seo();
