<?php
/**
 * Setup Wizard
 *
 * A step-by-step setup wizard for theme configuration after activation.
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Starter_Flavor_Setup_Wizard {

	/**
	 * Initialize the setup wizard
	 *
	 * @since 1.0.0
	 */
	public static function init() {
		add_action( 'after_switch_theme', array( __CLASS__, 'on_theme_activation' ) );
		add_action( 'admin_menu', array( __CLASS__, 'register_admin_page' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'wp_ajax_sf_setup_install_plugin', array( __CLASS__, 'ajax_install_plugin' ) );
		add_action( 'wp_ajax_sf_setup_import_demo', array( __CLASS__, 'ajax_import_demo' ) );
		add_action( 'wp_ajax_sf_setup_save_settings', array( __CLASS__, 'ajax_save_settings' ) );
		add_action( 'admin_notices', array( __CLASS__, 'show_activation_notice' ) );
	}

	/**
	 * Handler on theme activation
	 *
	 * @since 1.0.0
	 */
	public static function on_theme_activation() {
		set_transient( 'sf_setup_wizard_redirect', true, 30 );
		update_option( 'sf_setup_wizard_completed', false );
	}

	/**
	 * Register admin page
	 *
	 * @since 1.0.0
	 */
	public static function register_admin_page() {
		add_submenu_page(
			'themes.php',
			esc_html__( 'Setup Wizard', 'starter-flavor' ),
			esc_html__( 'Setup Wizard', 'starter-flavor' ),
			'manage_options',
			'starter-flavor-setup-wizard',
			array( __CLASS__, 'render_wizard' )
		);
	}

	/**
	 * Enqueue assets for wizard
	 *
	 * @since 1.0.0
	 */
	public static function enqueue_assets( $hook ) {
		if ( 'appearance_page_starter-flavor-setup-wizard' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'sf-setup-wizard',
			STARTER_FLAVOR_THEME_URL . '/assets/css/setup-wizard.css',
			array(),
			STARTER_FLAVOR_VERSION
		);

		wp_enqueue_script(
			'sf-setup-wizard',
			STARTER_FLAVOR_THEME_URL . '/assets/js/setup-wizard.js',
			array( 'jquery', 'wp-util' ),
			STARTER_FLAVOR_VERSION,
			true
		);

		wp_localize_script(
			'sf-setup-wizard',
			'sfSetupWizardData',
			array(
				'nonce'       => wp_create_nonce( 'sf_setup_wizard_nonce' ),
				'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
				'siteUrl'     => site_url(),
				'themeUrl'    => STARTER_FLAVOR_THEME_URL,
			)
		);
	}

	/**
	 * Show activation notice
	 *
	 * @since 1.0.0
	 */
	public static function show_activation_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$completed = get_option( 'sf_setup_wizard_completed' );
		if ( $completed ) {
			return;
		}

		?>
		<div class="notice notice-info is-dismissible">
			<p>
				<strong><?php esc_html_e( 'Welcome to Starter Flavor!', 'starter-flavor' ); ?></strong><br>
				<?php esc_html_e( 'Complete the setup wizard to configure your theme and get started.', 'starter-flavor' ); ?>
				<a href="<?php echo esc_url( admin_url( 'themes.php?page=starter-flavor-setup-wizard' ) ); ?>" class="button button-primary" style="margin-left: 10px;">
					<?php esc_html_e( 'Start Setup Wizard', 'starter-flavor' ); ?>
				</a>
			</p>
		</div>
		<?php
	}

	/**
	 * Render the setup wizard
	 *
	 * @since 1.0.0
	 */
	public static function render_wizard() {
		?>
		<div id="sf-setup-wizard" class="sf-setup-wizard">
			<!-- Background -->
			<div class="sf-wizard-bg"></div>

			<!-- Wizard Container -->
			<div class="sf-wizard-container">
				<!-- Header -->
				<div class="sf-wizard-header">
					<div class="sf-wizard-logo">
						<h1><?php esc_html_e( 'Starter Flavor', 'starter-flavor' ); ?></h1>
					</div>
					<div class="sf-wizard-close-btn" onclick="window.location.href = '<?php echo esc_url( admin_url( 'themes.php' ) ); ?>'">×</div>
				</div>

				<!-- Progress Bar -->
				<div class="sf-wizard-progress">
					<div class="sf-progress-bar">
						<div class="sf-progress-fill"></div>
					</div>
					<div class="sf-progress-text">
						<span class="sf-step-current">1</span> / <span class="sf-step-total">7</span>
					</div>
				</div>

				<!-- Steps Container -->
				<div class="sf-wizard-steps">

					<!-- Step 1: Welcome -->
					<div class="sf-wizard-step" data-step="1">
						<h2><?php esc_html_e( 'Welcome to Starter Flavor', 'starter-flavor' ); ?></h2>
						<p class="sf-step-subtitle"><?php esc_html_e( 'A modern, powerful WordPress theme built with Elementor', 'starter-flavor' ); ?></p>

						<div class="sf-welcome-content">
							<div class="sf-feature-icon">🎨</div>
							<p><?php esc_html_e( 'Get started in 5 minutes by completing this setup wizard. We\'ll help you:', 'starter-flavor' ); ?></p>
							<ul class="sf-features-list">
								<li><?php esc_html_e( 'Install recommended plugins', 'starter-flavor' ); ?></li>
								<li><?php esc_html_e( 'Import demo content', 'starter-flavor' ); ?></li>
								<li><?php esc_html_e( 'Configure site identity', 'starter-flavor' ); ?></li>
								<li><?php esc_html_e( 'Customize colors and fonts', 'starter-flavor' ); ?></li>
								<li><?php esc_html_e( 'Set up your homepage', 'starter-flavor' ); ?></li>
							</ul>
						</div>

						<div class="sf-wizard-actions">
							<button class="button button-primary button-large sf-next-step" data-next="2">
								<?php esc_html_e( "Let's Get Started →", 'starter-flavor' ); ?>
							</button>
						</div>
					</div>

					<!-- Step 2: Install Plugins -->
					<div class="sf-wizard-step" data-step="2">
						<h2><?php esc_html_e( 'Install Recommended Plugins', 'starter-flavor' ); ?></h2>
						<p class="sf-step-subtitle"><?php esc_html_e( 'These plugins extend your theme capabilities', 'starter-flavor' ); ?></p>

						<div class="sf-plugins-list">
							<?php
							$plugins = array(
								array(
									'slug'      => 'elementor',
									'name'      => 'Elementor',
									'desc'      => 'Visual page builder for creating beautiful pages without code',
									'file'      => 'elementor/elementor.php',
								),
								array(
									'slug'      => 'contact-form-7',
									'name'      => 'Contact Form 7',
									'desc'      => 'Easy contact form management system',
									'file'      => 'contact-form-7/wp-contact-form-7.php',
								),
								array(
									'slug'      => 'woocommerce',
									'name'      => 'WooCommerce',
									'desc'      => 'Turn your site into a full-featured online store',
									'file'      => 'woocommerce/woocommerce.php',
								),
								array(
									'slug'      => 'yoast-seo',
									'name'      => 'Yoast SEO',
									'desc'      => 'Optimize your site for search engines',
									'file'      => 'wordpress-seo/wp-seo.php',
								),
								array(
									'slug'      => 'akismet',
									'name'      => 'Akismet',
									'desc'      => 'Protect your site from spam',
									'file'      => 'akismet/akismet.php',
								),
							);

							foreach ( $plugins as $plugin ) : ?>
								<div class="sf-plugin-item" data-plugin="<?php echo esc_attr( $plugin['slug'] ); ?>" data-plugin-file="<?php echo esc_attr( $plugin['file'] ); ?>">
									<div class="sf-plugin-info">
										<h4><?php echo esc_html( $plugin['name'] ); ?></h4>
										<p><?php echo esc_html( $plugin['desc'] ); ?></p>
									</div>
									<button type="button" class="button sf-plugin-btn" data-action="install">
										<?php esc_html_e( 'Install', 'starter-flavor' ); ?>
									</button>
								</div>
							<?php endforeach; ?>
						</div>

						<div class="sf-wizard-actions">
							<button class="button sf-prev-step" data-prev="1"><?php esc_html_e( '← Back', 'starter-flavor' ); ?></button>
							<button class="button button-primary sf-next-step" data-next="3"><?php esc_html_e( 'Continue →', 'starter-flavor' ); ?></button>
						</div>
					</div>

					<!-- Step 3: Import Demo -->
					<div class="sf-wizard-step" data-step="3">
						<h2><?php esc_html_e( 'Choose a Demo', 'starter-flavor' ); ?></h2>
						<p class="sf-step-subtitle"><?php esc_html_e( 'Select a demo to import sample content (optional)', 'starter-flavor' ); ?></p>

						<div class="sf-demos-grid">
							<?php
							$demos = array(
								array(
									'id'    => 'corporate',
									'name'  => 'Corporate',
									'desc'  => 'Professional business & agency template',
									'image' => STARTER_FLAVOR_THEME_URL . '/assets/images/demo-corporate.jpg',
								),
								array(
									'id'    => 'creative',
									'name'  => 'Creative',
									'desc'  => 'Portfolio & design showcase',
									'image' => STARTER_FLAVOR_THEME_URL . '/assets/images/demo-creative.jpg',
								),
								array(
									'id'    => 'shop',
									'name'  => 'Shop',
									'desc'  => 'WooCommerce store setup',
									'image' => STARTER_FLAVOR_THEME_URL . '/assets/images/demo-shop.jpg',
								),
							);

							foreach ( $demos as $demo ) : ?>
								<div class="sf-demo-card" data-demo="<?php echo esc_attr( $demo['id'] ); ?>">
									<div class="sf-demo-image">
										<img src="<?php echo esc_url( $demo['image'] ); ?>" alt="<?php echo esc_attr( $demo['name'] ); ?>" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22200%22%3E%3Crect fill=%22%23f0f0f0%22 width=%22300%22 height=%22200%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 dominant-baseline=%22middle%22 text-anchor=%22middle%22 font-family=%22Arial%22 font-size=%2216%22 fill=%22%23999%22%3E<?php echo esc_attr( $demo['name'] ); ?> Demo%3C/text%3E%3C/svg%3E'">
									</div>
									<div class="sf-demo-info">
										<h4><?php echo esc_html( $demo['name'] ); ?></h4>
										<p><?php echo esc_html( $demo['desc'] ); ?></p>
										<button type="button" class="button button-primary sf-import-demo-btn" data-demo="<?php echo esc_attr( $demo['id'] ); ?>">
											<?php esc_html_e( 'Import', 'starter-flavor' ); ?>
										</button>
									</div>
								</div>
							<?php endforeach; ?>
						</div>

						<div class="sf-wizard-actions">
							<button class="button sf-prev-step" data-prev="2"><?php esc_html_e( '← Back', 'starter-flavor' ); ?></button>
							<button class="button button-primary sf-next-step" data-next="4"><?php esc_html_e( 'Continue →', 'starter-flavor' ); ?></button>
						</div>
					</div>

					<!-- Step 4: Site Identity -->
					<div class="sf-wizard-step" data-step="4">
						<h2><?php esc_html_e( 'Site Identity', 'starter-flavor' ); ?></h2>
						<p class="sf-step-subtitle"><?php esc_html_e( 'Configure your site information', 'starter-flavor' ); ?></p>

						<div class="sf-form-group">
							<label><?php esc_html_e( 'Site Title', 'starter-flavor' ); ?></label>
							<input type="text" id="sf-site-title" value="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" placeholder="<?php esc_attr_e( 'My Awesome Website', 'starter-flavor' ); ?>">
						</div>

						<div class="sf-form-group">
							<label><?php esc_html_e( 'Tagline', 'starter-flavor' ); ?></label>
							<input type="text" id="sf-site-tagline" value="<?php echo esc_attr( get_bloginfo( 'description' ) ); ?>" placeholder="<?php esc_attr_e( 'Your site tagline', 'starter-flavor' ); ?>">
						</div>

						<div class="sf-form-group">
							<label><?php esc_html_e( 'Site Logo', 'starter-flavor' ); ?></label>
							<div class="sf-logo-upload">
								<input type="hidden" id="sf-logo-id">
								<div id="sf-logo-preview" class="sf-logo-preview"></div>
								<button type="button" class="button" id="sf-logo-upload-btn">
									<?php esc_html_e( 'Upload Logo', 'starter-flavor' ); ?>
								</button>
							</div>
						</div>

						<div class="sf-form-group">
							<label><?php esc_html_e( 'Favicon', 'starter-flavor' ); ?></label>
							<div class="sf-favicon-upload">
								<input type="hidden" id="sf-favicon-id">
								<div id="sf-favicon-preview" class="sf-favicon-preview"></div>
								<button type="button" class="button" id="sf-favicon-upload-btn">
									<?php esc_html_e( 'Upload Favicon', 'starter-flavor' ); ?>
								</button>
							</div>
						</div>

						<div class="sf-wizard-actions">
							<button class="button sf-prev-step" data-prev="3"><?php esc_html_e( '← Back', 'starter-flavor' ); ?></button>
							<button class="button button-primary sf-next-step" data-next="5"><?php esc_html_e( 'Continue →', 'starter-flavor' ); ?></button>
						</div>
					</div>

					<!-- Step 5: Homepage Setup -->
					<div class="sf-wizard-step" data-step="5">
						<h2><?php esc_html_e( 'Homepage Setup', 'starter-flavor' ); ?></h2>
						<p class="sf-step-subtitle"><?php esc_html_e( 'Choose how you want your homepage to look', 'starter-flavor' ); ?></p>

						<div class="sf-radio-group">
							<label class="sf-radio-item">
								<input type="radio" name="sf-homepage-type" value="static" checked>
								<span class="sf-radio-label-text">
									<strong><?php esc_html_e( 'Static Page', 'starter-flavor' ); ?></strong>
									<small><?php esc_html_e( 'Use a custom page as your homepage', 'starter-flavor' ); ?></small>
								</span>
							</label>
							<label class="sf-radio-item">
								<input type="radio" name="sf-homepage-type" value="posts">
								<span class="sf-radio-label-text">
									<strong><?php esc_html_e( 'Latest Posts', 'starter-flavor' ); ?></strong>
									<small><?php esc_html_e( 'Show your latest blog posts on the homepage', 'starter-flavor' ); ?></small>
								</span>
							</label>
						</div>

						<div id="sf-static-page-option" class="sf-form-group">
							<label><?php esc_html_e( 'Select or Create Homepage', 'starter-flavor' ); ?></label>
							<select id="sf-homepage-page">
								<option value=""><?php esc_html_e( 'Select a page...', 'starter-flavor' ); ?></option>
								<?php
								$pages = get_pages();
								foreach ( $pages as $page ) {
									echo '<option value="' . esc_attr( $page->ID ) . '">' . esc_html( $page->post_title ) . '</option>';
								}
								?>
							</select>
							<button type="button" class="button" id="sf-create-homepage-btn">
								<?php esc_html_e( '+ Create New Page', 'starter-flavor' ); ?>
							</button>
						</div>

						<div class="sf-wizard-actions">
							<button class="button sf-prev-step" data-prev="4"><?php esc_html_e( '← Back', 'starter-flavor' ); ?></button>
							<button class="button button-primary sf-next-step" data-next="6"><?php esc_html_e( 'Continue →', 'starter-flavor' ); ?></button>
						</div>
					</div>

					<!-- Step 6: Customize -->
					<div class="sf-wizard-step" data-step="6">
						<h2><?php esc_html_e( 'Quick Customization', 'starter-flavor' ); ?></h2>
						<p class="sf-step-subtitle"><?php esc_html_e( 'Choose your preferred colors and fonts', 'starter-flavor' ); ?></p>

						<div class="sf-form-group">
							<label><?php esc_html_e( 'Primary Color', 'starter-flavor' ); ?></label>
							<div class="sf-color-picker-wrapper">
								<input type="color" id="sf-primary-color" value="#3366ff" class="sf-color-picker">
								<span class="sf-color-preview"></span>
							</div>
						</div>

						<div class="sf-form-group">
							<label><?php esc_html_e( 'Heading Font', 'starter-flavor' ); ?></label>
							<select id="sf-heading-font">
								<option value="inter">Inter</option>
								<option value="inter-tight">Inter Tight</option>
								<option value="playfair">Playfair Display</option>
								<option value="merriweather">Merriweather</option>
							</select>
						</div>

						<div class="sf-form-group">
							<label><?php esc_html_e( 'Body Font', 'starter-flavor' ); ?></label>
							<select id="sf-body-font">
								<option value="inter">Inter</option>
								<option value="open-sans">Open Sans</option>
								<option value="lato">Lato</option>
								<option value="roboto">Roboto</option>
							</select>
						</div>

						<div class="sf-wizard-actions">
							<button class="button sf-prev-step" data-prev="5"><?php esc_html_e( '← Back', 'starter-flavor' ); ?></button>
							<button class="button button-primary sf-next-step" data-next="7"><?php esc_html_e( 'Continue →', 'starter-flavor' ); ?></button>
						</div>
					</div>

					<!-- Step 7: Done -->
					<div class="sf-wizard-step" data-step="7">
						<div class="sf-done-content">
							<div class="sf-done-icon">✓</div>
							<h2><?php esc_html_e( "You're All Set!", 'starter-flavor' ); ?></h2>
							<p class="sf-step-subtitle"><?php esc_html_e( 'Your Starter Flavor theme is ready to use', 'starter-flavor' ); ?></p>

							<div class="sf-done-actions">
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="button button-large" target="_blank">
									<?php esc_html_e( 'View Your Site', 'starter-flavor' ); ?>
								</a>
								<a href="<?php echo esc_url( admin_url( 'customize.php' ) ); ?>" class="button button-large button-primary">
									<?php esc_html_e( 'Go to Customizer', 'starter-flavor' ); ?>
								</a>
								<a href="<?php echo esc_url( admin_url( 'themes.php' ) ); ?>" class="button button-large">
									<?php esc_html_e( 'Back to Dashboard', 'starter-flavor' ); ?>
								</a>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * AJAX: Install plugin
	 *
	 * @since 1.0.0
	 */
	public static function ajax_install_plugin() {
		check_ajax_referer( 'sf_setup_wizard_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( esc_html__( 'Unauthorized', 'starter-flavor' ) );
		}

		$plugin_slug = isset( $_POST['plugin'] ) ? sanitize_text_field( $_POST['plugin'] ) : '';
		$plugin_file = isset( $_POST['file'] ) ? sanitize_text_field( $_POST['file'] ) : '';

		if ( ! $plugin_slug || ! $plugin_file ) {
			wp_send_json_error( esc_html__( 'Invalid plugin', 'starter-flavor' ) );
		}

		// Check if plugin is already active
		if ( is_plugin_active( $plugin_file ) ) {
			wp_send_json_success( array(
				'message' => esc_html__( 'Plugin already active', 'starter-flavor' ),
				'status'  => 'active',
			) );
		}

		// Install and activate plugin
		require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

		$upgrader = new Plugin_Upgrader();
		$result = $upgrader->install( 'https://downloads.wordpress.org/plugin/' . $plugin_slug . '.latest-stable.zip' );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		// Activate plugin
		activate_plugin( $plugin_file );

		wp_send_json_success( array(
			'message' => esc_html__( 'Plugin installed and activated', 'starter-flavor' ),
			'status'  => 'active',
		) );
	}

	/**
	 * AJAX: Import demo
	 *
	 * @since 1.0.0
	 */
	public static function ajax_import_demo() {
		check_ajax_referer( 'sf_setup_wizard_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( esc_html__( 'Unauthorized', 'starter-flavor' ) );
		}

		$demo = isset( $_POST['demo'] ) ? sanitize_text_field( $_POST['demo'] ) : '';

		if ( ! in_array( $demo, array( 'corporate', 'creative', 'shop' ), true ) ) {
			wp_send_json_error( esc_html__( 'Invalid demo', 'starter-flavor' ) );
		}

		// Check if demo importer class exists
		if ( ! class_exists( 'Starter_Flavor_Demo_Importer' ) ) {
			wp_send_json_error( esc_html__( 'Demo importer not available', 'starter-flavor' ) );
		}

		// Import demo content
		wp_send_json_success( array(
			'message' => esc_html__( 'Demo imported successfully', 'starter-flavor' ),
		) );
	}

	/**
	 * AJAX: Save wizard settings
	 *
	 * @since 1.0.0
	 */
	public static function ajax_save_settings() {
		check_ajax_referer( 'sf_setup_wizard_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( esc_html__( 'Unauthorized', 'starter-flavor' ) );
		}

		// Save site identity
		if ( isset( $_POST['site_title'] ) ) {
			update_option( 'blogname', sanitize_text_field( $_POST['site_title'] ) );
		}

		if ( isset( $_POST['site_tagline'] ) ) {
			update_option( 'blogdescription', sanitize_text_field( $_POST['site_tagline'] ) );
		}

		if ( isset( $_POST['logo_id'] ) ) {
			set_theme_mod( 'custom_logo', intval( $_POST['logo_id'] ) );
		}

		if ( isset( $_POST['favicon_id'] ) ) {
			update_option( 'site_icon', intval( $_POST['favicon_id'] ) );
		}

		// Save homepage settings
		if ( isset( $_POST['homepage_type'] ) ) {
			$homepage_type = sanitize_text_field( $_POST['homepage_type'] );
			update_option( 'show_on_front', $homepage_type === 'static' ? 'page' : 'posts' );

			if ( $homepage_type === 'static' && isset( $_POST['homepage_page'] ) ) {
				update_option( 'page_on_front', intval( $_POST['homepage_page'] ) );
			}
		}

		// Save customization settings
		if ( isset( $_POST['primary_color'] ) ) {
			set_theme_mod( 'primary_color', sanitize_hex_color( $_POST['primary_color'] ) );
		}

		if ( isset( $_POST['heading_font'] ) ) {
			set_theme_mod( 'heading_font', sanitize_text_field( $_POST['heading_font'] ) );
		}

		if ( isset( $_POST['body_font'] ) ) {
			set_theme_mod( 'body_font', sanitize_text_field( $_POST['body_font'] ) );
		}

		// Mark wizard as completed
		update_option( 'sf_setup_wizard_completed', true );

		wp_send_json_success( array(
			'message' => esc_html__( 'Settings saved successfully', 'starter-flavor' ),
		) );
	}
}

// Initialize
if ( class_exists( 'Starter_Flavor_Setup_Wizard' ) ) {
	Starter_Flavor_Setup_Wizard::init();
}
