<?php
/**
 * Elementor Theme Support
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add Elementor location support
 *
 * @since 1.0.0
 */
function starter_flavor_elementor_locations_included( $elementor_locations ) {
	$elementor_locations['header']  = esc_html__( 'Header', 'starter-flavor' );
	$elementor_locations['footer']  = esc_html__( 'Footer', 'starter-flavor' );
	$elementor_locations['single']  = esc_html__( 'Single', 'starter-flavor' );
	$elementor_locations['archive'] = esc_html__( 'Archive', 'starter-flavor' );

	return $elementor_locations;
}
add_filter( 'elementor/theme/register_locations', 'starter_flavor_elementor_locations_included' );

/**
 * Elementor theme compatibility init
 *
 * @since 1.0.0
 */
function starter_flavor_elementor_init() {
	// Add Elementor theme compatibility
	if ( defined( 'ELEMENTOR_VERSION' ) ) {
		add_theme_support( 'elementor' );
	}
}
add_action( 'after_setup_theme', 'starter_flavor_elementor_init' );

/**
 * Enqueue Elementor compatibility styles
 *
 * @since 1.0.0
 */
function starter_flavor_elementor_enqueue_styles() {
	if ( defined( 'ELEMENTOR_VERSION' ) ) {
		wp_enqueue_style(
			'starter-flavor-elementor',
			STARTER_FLAVOR_THEME_URL . '/styles/elementor-compat.css',
			array(),
			STARTER_FLAVOR_VERSION
		);
	}
}
add_action( 'wp_enqueue_scripts', 'starter_flavor_elementor_enqueue_styles' );

/**
 * Register custom Elementor widgets
 *
 * @since 1.0.0
 */
function starter_flavor_register_elementor_widgets( $widgets_manager ) {
	if ( ! defined( 'ELEMENTOR_VERSION' ) ) {
		return;
	}

	// Hero Section Widget
	$hero_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/hero-section.php';
	if ( file_exists( $hero_widget_path ) ) {
		require_once $hero_widget_path;
		if ( class_exists( 'Starter_Flavor_Hero_Section_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Hero_Section_Widget() );
		}
	}

	// CTA Box Widget
	$cta_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/cta-box.php';
	if ( file_exists( $cta_widget_path ) ) {
		require_once $cta_widget_path;
		if ( class_exists( 'Starter_Flavor_CTA_Box_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_CTA_Box_Widget() );
		}
	}

	// Testimonial Widget
	$testimonial_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/testimonial.php';
	if ( file_exists( $testimonial_widget_path ) ) {
		require_once $testimonial_widget_path;
		if ( class_exists( 'Starter_Flavor_Testimonial_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Testimonial_Widget() );
		}
	}

	// Pricing Table Widget
	$pricing_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/pricing-table.php';
	if ( file_exists( $pricing_widget_path ) ) {
		require_once $pricing_widget_path;
		if ( class_exists( 'Starter_Flavor_Pricing_Table_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Pricing_Table_Widget() );
		}
	}

	// Team Member Widget
	$team_member_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/team-member.php';
	if ( file_exists( $team_member_widget_path ) ) {
		require_once $team_member_widget_path;
		if ( class_exists( 'Starter_Flavor_Team_Member_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Team_Member_Widget() );
		}
	}

	// Services/Features Widget
	$services_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/services.php';
	if ( file_exists( $services_widget_path ) ) {
		require_once $services_widget_path;
		if ( class_exists( 'Starter_Flavor_Services_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Services_Widget() );
		}
	}

	// Counter/Stats Widget
	$counter_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/counter-stats.php';
	if ( file_exists( $counter_widget_path ) ) {
		require_once $counter_widget_path;
		if ( class_exists( 'Starter_Flavor_Counter_Stats_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Counter_Stats_Widget() );
		}
	}

	// Icon Box Widget
	$icon_box_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/icon-box.php';
	if ( file_exists( $icon_box_widget_path ) ) {
		require_once $icon_box_widget_path;
		if ( class_exists( 'Starter_Flavor_Icon_Box_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Icon_Box_Widget() );
		}
	}

	// Accordion & Tabs Widget
	$accordion_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/accordion-tabs.php';
	if ( file_exists( $accordion_widget_path ) ) {
		require_once $accordion_widget_path;
		if ( class_exists( 'Starter_Flavor_Accordion_Tabs_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Accordion_Tabs_Widget() );
		}
	}

	// Contact Form Widget
	$contact_form_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/contact-form.php';
	if ( file_exists( $contact_form_widget_path ) ) {
		require_once $contact_form_widget_path;
		if ( class_exists( 'Starter_Flavor_Contact_Form_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Contact_Form_Widget() );
		}
	}

	// Image Gallery Widget
	$gallery_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/image-gallery.php';
	if ( file_exists( $gallery_widget_path ) ) {
		require_once $gallery_widget_path;
		if ( class_exists( 'Starter_Flavor_Image_Gallery_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Image_Gallery_Widget() );
		}
	}

	// Blog Carousel Widget
	$blog_carousel_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/blog-carousel.php';
	if ( file_exists( $blog_carousel_widget_path ) ) {
		require_once $blog_carousel_widget_path;
		if ( class_exists( 'Starter_Flavor_Blog_Carousel_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Blog_Carousel_Widget() );
		}
	}

	// Slider Widget
	$slider_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/slider.php';
	if ( file_exists( $slider_widget_path ) ) {
		require_once $slider_widget_path;
		if ( class_exists( 'Starter_Flavor_Slider_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Slider_Widget() );
		}
	}

	// Progress Bar Widget
	$progress_bar_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/progress-bar.php';
	if ( file_exists( $progress_bar_widget_path ) ) {
		require_once $progress_bar_widget_path;
		if ( class_exists( 'Starter_Flavor_Progress_Bar_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Progress_Bar_Widget() );
		}
	}

	// Countdown Widget
	$countdown_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/countdown.php';
	if ( file_exists( $countdown_widget_path ) ) {
		require_once $countdown_widget_path;
		if ( class_exists( 'Starter_Flavor_Countdown_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Countdown_Widget() );
		}
	}

	// Social Icons Widget
	$social_icons_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/social-icons.php';
	if ( file_exists( $social_icons_widget_path ) ) {
		require_once $social_icons_widget_path;
		if ( class_exists( 'Starter_Flavor_Social_Icons_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Social_Icons_Widget() );
		}
	}

	// Nav Menu Widget
	$nav_menu_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/nav-menu.php';
	if ( file_exists( $nav_menu_widget_path ) ) {
		require_once $nav_menu_widget_path;
		if ( class_exists( 'Starter_Flavor_Nav_Menu_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Nav_Menu_Widget() );
		}
	}

	// Site Logo Widget
	$site_logo_widget_path = STARTER_FLAVOR_THEME_DIR . '/includes/elementor-widgets/site-logo.php';
	if ( file_exists( $site_logo_widget_path ) ) {
		require_once $site_logo_widget_path;
		if ( class_exists( 'Starter_Flavor_Site_Logo_Widget' ) ) {
			$widgets_manager->register( new Starter_Flavor_Site_Logo_Widget() );
		}
	}
}
add_action( 'elementor/widgets/register', 'starter_flavor_register_elementor_widgets' );

/**
 * Register Elementor widget category
 *
 * @since 1.0.0
 */
function starter_flavor_register_elementor_category() {
	if ( ! defined( 'ELEMENTOR_VERSION' ) ) {
		return;
	}

	\Elementor\Plugin::$instance->elements_manager->add_category(
		'starter-flavor',
		array(
			'title' => esc_html__( 'Starter Flavor', 'starter-flavor' ),
			'icon'  => 'fa fa-plug',
		)
	);
}
add_action( 'elementor/elements/categories_registered', 'starter_flavor_register_elementor_category' );
