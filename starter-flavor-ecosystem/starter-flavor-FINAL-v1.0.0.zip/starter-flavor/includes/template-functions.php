<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function starter_flavor_body_classes_filter( $classes ) {
	// Adds a class of hfeed to non-singular content.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	// Adds a class if the site has a custom logo.
	if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
		$classes[] = 'has-logo';
	}

	return $classes;
}
add_filter( 'body_class', 'starter_flavor_body_classes_filter' );

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 *
 * @since 1.0.0
 */
function starter_flavor_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'starter_flavor_pingback_header' );

/**
 * Filter the excerpt length
 *
 * @param int $length The excerpt length.
 * @return int
 */
function starter_flavor_excerpt_length_filter( $length ) {
	if ( is_admin() ) {
		return $length;
	}
	return 20;
}
add_filter( 'excerpt_length', 'starter_flavor_excerpt_length_filter' );

/**
 * Filter the excerpt more link
 *
 * @param string $more The more link.
 * @return string
 */
function starter_flavor_excerpt_more( $more ) {
	if ( is_admin() ) {
		return $more;
	}
	return ' ... <a href="' . esc_url( get_permalink() ) . '" class="read-more">' . esc_html__( 'Read More', 'starter-flavor' ) . '</a>';
}
add_filter( 'excerpt_more', 'starter_flavor_excerpt_more' );

/**
 * Enqueue editor styles for the block editor
 *
 * @since 1.0.0
 */
function starter_flavor_block_editor_styles() {
	wp_enqueue_style(
		'starter-flavor-editor-styles',
		STARTER_FLAVOR_THEME_URL . '/styles/editor-style.css',
		array(),
		STARTER_FLAVOR_VERSION
	);
}
add_action( 'enqueue_block_editor_assets', 'starter_flavor_block_editor_styles' );

/**
 * Register block styles and patterns
 *
 * @since 1.0.0
 */
function starter_flavor_register_block_styles() {
	// Register button block variations
	register_block_style(
		'core/button',
		array(
			'name'       => 'secondary',
			'label'      => __( 'Secondary', 'starter-flavor' ),
			'is_default' => false,
		)
	);
}
add_action( 'init', 'starter_flavor_register_block_styles' );
