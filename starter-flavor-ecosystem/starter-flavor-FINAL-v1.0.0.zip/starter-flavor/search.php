<?php
/**
 * The template for displaying search results pages
 *
 * Features:
 * - Search form at top
 * - Grid/List layout support
 * - Results counter
 * - Related search suggestions
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

get_header();
?>

<?php
/**
 * Search header
 *
 * @since 1.0.0
 */
?>
<div class="search-header">
	<div class="search-header-content">
		<h1 class="page-title">
			<?php
			printf(
				esc_html__( 'Search Results for: %s', 'starter-flavor' ),
				'<span>' . esc_html( get_search_query() ) . '</span>'
			);
			?>
		</h1>

		<?php
		// Display search form in header
		?>
		<div class="search-header-form">
			<?php get_search_form(); ?>
		</div>

		<?php
		// Display results counter
		global $wp_query;
		if ( $wp_query->found_posts > 0 ) {
			printf(
				'<p class="search-results-count">%s</p>',
				sprintf(
					esc_html__( 'Found %d result(s)', 'starter-flavor' ),
					intval( $wp_query->found_posts )
				)
			);
		}
		?>
	</div>
</div><!-- .search-header -->

<?php
/**
 * Action hook before loop
 *
 * @since 1.0.0
 */
do_action( 'starter_flavor_before_loop' );
?>

<?php if ( have_posts() ) : ?>

	<?php
	/**
	 * Action hook before posts
	 *
	 * @since 1.0.0
	 */
	do_action( 'starter_flavor_before_posts' );
	?>

	<?php
	/**
	 * Get layout mode from customizer
	 *
	 * @since 1.0.0
	 */
	$layout_mode = starter_flavor_get_theme_option( 'search_layout', 'list' );
	$grid_columns = intval( starter_flavor_get_theme_option( 'search_grid_columns', 2 ) );
	?>

	<div class="posts-list posts-layout-<?php echo esc_attr( $layout_mode ); ?><?php echo $layout_mode === 'grid' ? ' posts-grid-' . esc_attr( $grid_columns ) : ''; ?>" role="region" aria-label="<?php esc_attr_e( 'Search results', 'starter-flavor' ); ?>">
		<?php
		while ( have_posts() ) :
			the_post();

			/**
			 * Include the Post-Type-specific template for the content.
			 */
			if ( $layout_mode === 'grid' && locate_template( 'template-parts/content-grid.php' ) ) {
				get_template_part( 'template-parts/content', 'grid' );
			} else {
				get_template_part( 'template-parts/content', 'search' );
			}

		endwhile;
		?>
	</div><!-- .posts-list -->

	<?php
	/**
	 * Action hook after posts
	 *
	 * @since 1.0.0
	 */
	do_action( 'starter_flavor_after_posts' );
	?>

	<?php
	/**
	 * Post navigation
	 *
	 * @since 1.0.0
	 */
	?>
	<nav class="posts-navigation pagination" role="navigation" aria-label="<?php esc_attr_e( 'Posts', 'starter-flavor' ); ?>">
		<h2 class="screen-reader-text"><?php esc_html_e( 'Posts navigation', 'starter-flavor' ); ?></h2>
		<div class="nav-links">
			<?php
			echo wp_kses_post(
				paginate_links( array(
					'type'      => 'list',
					'prev_text' => '<span class="nav-previous">' . esc_html__( '&larr; Newer Posts', 'starter-flavor' ) . '</span>',
					'next_text' => '<span class="nav-next">' . esc_html__( 'Older Posts &rarr;', 'starter-flavor' ) . '</span>',
				) )
			);
			?>
		</div>
	</nav><!-- .posts-navigation -->

<?php else : ?>

	<?php
	/**
	 * Include the no posts found content
	 *
	 * @since 1.0.0
	 */
	get_template_part( 'template-parts/content', 'none' );
	?>

<?php endif; ?>

<?php
/**
 * Action hook after loop
 *
 * @since 1.0.0
 */
do_action( 'starter_flavor_after_loop' );
?>

<?php get_footer(); ?>
