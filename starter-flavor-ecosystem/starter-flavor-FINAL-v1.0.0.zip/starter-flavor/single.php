<?php
/**
 * The template for displaying all single posts
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

get_header();
?>

<?php
/**
 * Action hook before loop
 *
 * @since 1.0.0
 */
do_action( 'starter_flavor_before_loop' );
?>

<?php
if ( have_posts() ) :
	while ( have_posts() ) :
		the_post();

		/**
		 * Include the single post template
		 *
		 * @since 1.0.0
		 */
		get_template_part( 'template-parts/content', 'single' );

		/**
		 * Display post navigation
		 *
		 * @since 1.0.0
		 */
		?>
		<nav class="post-navigation navigation" role="navigation" aria-label="<?php esc_attr_e( 'Posts', 'starter-flavor' ); ?>">
			<h2 class="screen-reader-text"><?php esc_html_e( 'Post navigation', 'starter-flavor' ); ?></h2>
			<div class="nav-links">
				<?php
				the_post_navigation( array(
					'prev_text' => '<span class="nav-subtitle">' . esc_html__( 'Previous Post:', 'starter-flavor' ) . '</span> <span class="nav-title">%title</span>',
					'next_text' => '<span class="nav-subtitle">' . esc_html__( 'Next Post:', 'starter-flavor' ) . '</span> <span class="nav-title">%title</span>',
				) );
				?>
			</div>
		</nav><!-- .post-navigation -->

		<?php
		/**
		 * Related Posts Section
		 *
		 * @since 1.0.0
		 */
		$related_args = array(
			'posts_per_page' => 3,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'post__not_in'   => array( get_the_ID() ),
			'tax_query'      => array(
				'relation' => 'OR',
			),
		);

		$cats     = wp_get_post_categories( get_the_ID() );
		$tags     = wp_get_post_tags( get_the_ID() );
		$tax_args = array();

		if ( ! empty( $cats ) ) {
			$tax_args[] = array(
				'taxonomy' => 'category',
				'field'    => 'term_id',
				'terms'    => $cats,
			);
		}

		if ( ! empty( $tags ) ) {
			$tax_args[] = array(
				'taxonomy' => 'post_tag',
				'field'    => 'term_id',
				'terms'    => $tags,
			);
		}

		if ( ! empty( $tax_args ) ) {
			$related_args['tax_query'] = $tax_args;
		}

		/**
		 * Filter related posts arguments
		 *
		 * @since 1.0.0
		 * @param array $related_args The related posts arguments.
		 */
		$related_args = apply_filters( 'starter_flavor_related_posts_args', $related_args );
		$related_query = new WP_Query( $related_args );

		if ( $related_query->have_posts() ) {
			?>
			<div class="related-posts-section">
				<h2><?php esc_html_e( 'Related Posts', 'starter-flavor' ); ?></h2>
				<div class="related-posts">
					<?php
					while ( $related_query->have_posts() ) {
						$related_query->the_post();
						get_template_part( 'template-parts/content', get_post_type() );
					}
					?>
				</div>
			</div>
			<?php
		}

		wp_reset_postdata();

		/**
		 * Author Bio Section
		 *
		 * @since 1.0.0
		 */
		if ( get_the_author_meta( 'description' ) ) {
			?>
			<div class="author-bio-section">
				<div class="author-bio">
					<?php
					if ( get_the_author_meta( 'user_url' ) ) {
						?>
						<a href="<?php echo esc_url( get_the_author_meta( 'user_url' ) ); ?>" class="author-bio-link">
							<?php echo get_avatar( get_the_author_meta( 'user_email' ), 100, '', get_the_author_meta( 'display_name' ), array( 'class' => 'author-bio-avatar' ) ); ?>
						</a>
						<?php
					} else {
						echo get_avatar( get_the_author_meta( 'user_email' ), 100, '', get_the_author_meta( 'display_name' ), array( 'class' => 'author-bio-avatar' ) );
					}
					?>
					<div class="author-bio-content">
						<h3 class="author-bio-title"><?php echo esc_html( get_the_author_meta( 'display_name' ) ); ?></h3>
						<p class="author-bio-description"><?php echo wp_kses_post( nl2br( get_the_author_meta( 'description' ) ) ); ?></p>
						<?php if ( get_the_author_meta( 'user_url' ) ) { ?>
							<a href="<?php echo esc_url( get_the_author_meta( 'user_url' ) ); ?>" class="author-bio-link"><?php esc_html_e( 'Visit Website', 'starter-flavor' ); ?></a>
						<?php } ?>
					</div>
				</div>
			</div>
			<?php
		}

		/**
		 * If comments are open or we have at least one comment,
		 * load up the comment template
		 *
		 * @since 1.0.0
		 */
		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}

	endwhile;
else :
	/**
	 * Include the no posts found content
	 *
	 * @since 1.0.0
	 */
	get_template_part( 'template-parts/content', 'none' );

endif;
?>

<?php
/**
 * Action hook after loop
 *
 * @since 1.0.0
 */
do_action( 'starter_flavor_after_loop' );
?>

<?php get_footer(); ?>
