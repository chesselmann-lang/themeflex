<?php
/**
 * Template part for displaying the default footer layout
 *
 * @package Starter_Flavor
 */

?>

<footer id="colophon" class="site-footer">
	<?php
	// Footer widgets area
	get_template_part( 'template-parts/footer/footer', 'widgets' );
	?>

	<div class="footer-bottom">
		<div class="container">
			<div class="footer-bottom__content">
				<!-- Back to top button -->
				<button id="back-to-top" class="back-to-top" aria-label="<?php esc_attr_e( 'Back to top', 'starter-flavor' ); ?>">
					<span class="icon">↑</span>
				</button>

				<!-- Copyright bar -->
				<div class="footer-copyright">
					<?php
					$copyright_text = get_theme_mod(
						'starter_flavor_copyright_text',
						sprintf(
							/* translators: %s: current year, %s: site name */
							__( '&copy; %s %s. All rights reserved.', 'starter-flavor' ),
							gmdate( 'Y' ),
							get_bloginfo( 'name' )
						)
					);
					echo wp_kses_post( $copyright_text );
					?>
				</div><!-- .footer-copyright -->

				<!-- Footer menu -->
				<nav class="footer-navigation" aria-label="<?php esc_attr_e( 'Footer Menu', 'starter-flavor' ); ?>">
					<?php
					wp_nav_menu(
						array(
							'theme_location' => 'footer',
							'menu_id'        => 'footer-menu',
							'fallback_cb'    => false,
							'depth'          => 1,
						)
					);
					?>
				</nav><!-- .footer-navigation -->
			</div><!-- .footer-bottom__content -->
		</div><!-- .container -->
	</div><!-- .footer-bottom -->
</footer><!-- #colophon -->
