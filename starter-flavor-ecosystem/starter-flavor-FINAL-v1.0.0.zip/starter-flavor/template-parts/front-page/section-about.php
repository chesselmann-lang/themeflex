<?php
/**
 * Front Page About Section
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

$title = get_theme_mod( 'sf_about_title', esc_html__( 'About Us', 'starter-flavor' ) );
$content = get_theme_mod( 'sf_about_content', esc_html__( 'Learn more about our company and mission.', 'starter-flavor' ) );
$image = get_theme_mod( 'sf_about_image' );
$bg_color = get_theme_mod( 'sf_about_bg_color', '#ffffff' );
$padding_top = get_theme_mod( 'sf_about_padding_top', '60' );
$padding_bottom = get_theme_mod( 'sf_about_padding_bottom', '60' );
$custom_class = get_theme_mod( 'sf_about_custom_class' );
?>

<section class="sf-about-section <?php echo esc_attr( $custom_class ); ?>" style="padding-top: <?php echo absint( $padding_top ); ?>px; padding-bottom: <?php echo absint( $padding_bottom ); ?>px; background-color: <?php echo esc_attr( $bg_color ); ?>;">
	<div class="container">
		<div class="sf-about-wrapper">
			<?php if ( $image ) : ?>
				<div class="sf-about-image">
					<img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $title ); ?>" />
				</div>
			<?php endif; ?>

			<div class="sf-about-content">
				<?php if ( $title ) : ?>
					<h2><?php echo wp_kses_post( $title ); ?></h2>
				<?php endif; ?>

				<?php if ( $content ) : ?>
					<div class="sf-about-text">
						<?php echo wp_kses_post( wpautop( $content ) ); ?>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>
