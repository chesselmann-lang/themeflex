<?php
/**
 * Front Page Features Section
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

$title = get_theme_mod( 'sf_features_title', esc_html__( 'Features', 'starter-flavor' ) );
$columns = get_theme_mod( 'sf_features_columns', '3' );
$bg_color = get_theme_mod( 'sf_features_bg_color', '#ffffff' );
$padding_top = get_theme_mod( 'sf_features_padding_top', '60' );
$padding_bottom = get_theme_mod( 'sf_features_padding_bottom', '60' );
$custom_class = get_theme_mod( 'sf_features_custom_class' );
?>

<section class="sf-features-section <?php echo esc_attr( $custom_class ); ?>" style="padding-top: <?php echo absint( $padding_top ); ?>px; padding-bottom: <?php echo absint( $padding_bottom ); ?>px; background-color: <?php echo esc_attr( $bg_color ); ?>;">
	<div class="container">
		<?php if ( $title ) : ?>
			<h2 class="sf-section-title"><?php echo wp_kses_post( $title ); ?></h2>
		<?php endif; ?>

		<div class="sf-features-grid sf-features-cols-<?php echo absint( $columns ); ?>">
			<!-- Features content goes here via Elementor or custom widgets -->
		</div>
	</div>
</section>
