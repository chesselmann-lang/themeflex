<?php
/**
 * Front Page Hero Section
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

$hero_title = get_theme_mod( 'sf_hero_title', get_bloginfo( 'name' ) );
$hero_subtitle = get_theme_mod( 'sf_hero_subtitle', get_bloginfo( 'description' ) );
$cta1_text = get_theme_mod( 'sf_hero_cta1_text', esc_html__( 'Get Started', 'starter-flavor' ) );
$cta1_url = get_theme_mod( 'sf_hero_cta1_url', home_url( '/about' ) );
$cta2_text = get_theme_mod( 'sf_hero_cta2_text', esc_html__( 'Learn More', 'starter-flavor' ) );
$cta2_url = get_theme_mod( 'sf_hero_cta2_url', home_url( '/services' ) );
$bg_image = get_theme_mod( 'sf_hero_bg_image' );
$bg_color = get_theme_mod( 'sf_hero_bg_color', '#ffffff' );
$overlay_color = get_theme_mod( 'sf_hero_overlay_color', 'rgba(0,0,0,0.3)' );
$video_url = get_theme_mod( 'sf_hero_video_url' );
$padding_top = get_theme_mod( 'sf_hero_padding_top', '60' );
$padding_bottom = get_theme_mod( 'sf_hero_padding_bottom', '60' );
$custom_class = get_theme_mod( 'sf_hero_custom_class' );

$section_style = 'padding-top: ' . absint( $padding_top ) . 'px; padding-bottom: ' . absint( $padding_bottom ) . 'px; background-color: ' . esc_attr( $bg_color ) . ';';

if ( $bg_image ) {
	$section_style .= ' background-image: url(' . esc_url( $bg_image ) . '); background-size: cover; background-position: center;';
}
?>

<section class="sf-hero-section <?php echo esc_attr( $custom_class ); ?>" style="<?php echo esc_attr( $section_style ); ?>">
	<?php if ( $video_url ) : ?>
		<video class="sf-hero-video" autoplay muted loop playsinline>
			<source src="<?php echo esc_url( $video_url ); ?>" type="video/mp4">
		</video>
	<?php endif; ?>

	<?php if ( $bg_image || $video_url ) : ?>
		<div class="sf-hero-overlay" style="background-color: <?php echo esc_attr( $overlay_color ); ?>"></div>
	<?php endif; ?>

	<div class="sf-hero-content">
		<?php if ( $hero_title ) : ?>
			<h1 class="sf-hero-title"><?php echo wp_kses_post( $hero_title ); ?></h1>
		<?php endif; ?>

		<?php if ( $hero_subtitle ) : ?>
			<p class="sf-hero-subtitle"><?php echo wp_kses_post( $hero_subtitle ); ?></p>
		<?php endif; ?>

		<?php if ( $cta1_text || $cta2_text ) : ?>
			<div class="sf-hero-ctas">
				<?php if ( $cta1_text && $cta1_url ) : ?>
					<a href="<?php echo esc_url( $cta1_url ); ?>" class="sf-hero-cta sf-hero-cta-primary">
						<?php echo esc_html( $cta1_text ); ?>
					</a>
				<?php endif; ?>

				<?php if ( $cta2_text && $cta2_url ) : ?>
					<a href="<?php echo esc_url( $cta2_url ); ?>" class="sf-hero-cta sf-hero-cta-secondary">
						<?php echo esc_html( $cta2_text ); ?>
					</a>
				<?php endif; ?>
			</div>
		<?php endif; ?>
	</div>
</section>
