<?php
/**
 * Front Page Services Section
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

$title = get_theme_mod( 'sf_services_title', esc_html__( 'Services', 'starter-flavor' ) );
$bg_color = get_theme_mod( 'sf_services_bg_color', '#ffffff' );
$padding_top = get_theme_mod( 'sf_services_padding_top', '60' );
$padding_bottom = get_theme_mod( 'sf_services_padding_bottom', '60' );
$custom_class = get_theme_mod( 'sf_services_custom_class' );
?>

<section class="sf-services-section <?php echo esc_attr( $custom_class ); ?>" style="padding-top: <?php echo absint( $padding_top ); ?>px; padding-bottom: <?php echo absint( $padding_bottom ); ?>px; background-color: <?php echo esc_attr( $bg_color ); ?>;">
	<div class="container">
		<?php if ( $title ) : ?>
			<h2 class="sf-section-title"><?php echo wp_kses_post( $title ); ?></h2>
		<?php endif; ?>

		<div class="sf-services-grid">
			<!-- Services content goes here via Elementor or custom widgets -->
		</div>
	</div>
</section>
