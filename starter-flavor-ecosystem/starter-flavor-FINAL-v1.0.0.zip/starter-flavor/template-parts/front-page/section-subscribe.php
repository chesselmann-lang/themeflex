<?php
/**
 * Front Page Subscribe Section
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

$title = get_theme_mod( 'sf_subscribe_title', esc_html__( 'Subscribe to Our Newsletter', 'starter-flavor' ) );
$description = get_theme_mod( 'sf_subscribe_description', esc_html__( 'Get the latest updates delivered to your inbox.', 'starter-flavor' ) );
$form_id = get_theme_mod( 'sf_subscribe_form_id' );
$bg_color = get_theme_mod( 'sf_subscribe_bg_color', '#ffffff' );
$padding_top = get_theme_mod( 'sf_subscribe_padding_top', '60' );
$padding_bottom = get_theme_mod( 'sf_subscribe_padding_bottom', '60' );
$custom_class = get_theme_mod( 'sf_subscribe_custom_class' );
?>

<section class="sf-subscribe-section <?php echo esc_attr( $custom_class ); ?>" style="padding-top: <?php echo absint( $padding_top ); ?>px; padding-bottom: <?php echo absint( $padding_bottom ); ?>px; background-color: <?php echo esc_attr( $bg_color ); ?>;">
	<div class="container">
		<div class="sf-subscribe-wrapper">
			<?php if ( $title ) : ?>
				<h2><?php echo wp_kses_post( $title ); ?></h2>
			<?php endif; ?>

			<?php if ( $description ) : ?>
				<p class="sf-subscribe-description"><?php echo wp_kses_post( $description ); ?></p>
			<?php endif; ?>

			<?php if ( $form_id ) : ?>
				<!-- Mailchimp for WP form ID: <?php echo esc_attr( $form_id ); ?> -->
			<?php endif; ?>
		</div>
	</div>
</section>
