<?php
/**
 * Front Page Team Section
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

$title = get_theme_mod( 'sf_team_title', esc_html__( 'Our Team', 'starter-flavor' ) );
$bg_color = get_theme_mod( 'sf_team_bg_color', '#ffffff' );
$padding_top = get_theme_mod( 'sf_team_padding_top', '60' );
$padding_bottom = get_theme_mod( 'sf_team_padding_bottom', '60' );
$custom_class = get_theme_mod( 'sf_team_custom_class' );
?>

<section class="sf-team-section <?php echo esc_attr( $custom_class ); ?>" style="padding-top: <?php echo absint( $padding_top ); ?>px; padding-bottom: <?php echo absint( $padding_bottom ); ?>px; background-color: <?php echo esc_attr( $bg_color ); ?>;">
	<div class="container">
		<?php if ( $title ) : ?>
			<h2 class="sf-section-title"><?php echo wp_kses_post( $title ); ?></h2>
		<?php endif; ?>

		<div class="sf-team-grid">
			<!-- Team members content goes here via Elementor or custom widgets -->
		</div>
	</div>
</section>
