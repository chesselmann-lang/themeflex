<?php
/**
 * Front Page Testimonials Section
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

$title = get_theme_mod( 'sf_testimonials_title', esc_html__( 'Testimonials', 'starter-flavor' ) );
$bg_color = get_theme_mod( 'sf_testimonials_bg_color', '#ffffff' );
$padding_top = get_theme_mod( 'sf_testimonials_padding_top', '60' );
$padding_bottom = get_theme_mod( 'sf_testimonials_padding_bottom', '60' );
$custom_class = get_theme_mod( 'sf_testimonials_custom_class' );
?>

<section class="sf-testimonials-section <?php echo esc_attr( $custom_class ); ?>" style="padding-top: <?php echo absint( $padding_top ); ?>px; padding-bottom: <?php echo absint( $padding_bottom ); ?>px; background-color: <?php echo esc_attr( $bg_color ); ?>;">
	<div class="container">
		<?php if ( $title ) : ?>
			<h2 class="sf-section-title"><?php echo wp_kses_post( $title ); ?></h2>
		<?php endif; ?>

		<div class="sf-testimonials-carousel">
			<!-- Testimonials carousel content goes here -->
		</div>
	</div>
</section>
