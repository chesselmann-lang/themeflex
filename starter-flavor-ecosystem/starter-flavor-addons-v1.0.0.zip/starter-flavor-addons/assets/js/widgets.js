/**
 * Starter Flavor Addons – Frontend Widget JS
 * Handles: Stats Counter, Testimonials Slider, FAQ Accordion,
 *          Portfolio Filter, Logo Carousel, Timeline Scroll
 */
(function () {
  'use strict';

  /* ── Utility ──────────────────────────────────────────────────────────── */
  function onReady(fn) {
    if (document.readyState !== 'loading') fn();
    else document.addEventListener('DOMContentLoaded', fn);
  }

  function getIntersectionObserver(callback, options) {
    if (!('IntersectionObserver' in window)) {
      // Fallback: fire immediately
      return { observe: function(el) { callback([{ isIntersecting: true, target: el }]); } };
    }
    return new IntersectionObserver(callback, options || { threshold: 0.2 });
  }

  /* ── 1. Stats Counter – count-up animation ────────────────────────────── */
  function initStatsCounters() {
    document.querySelectorAll('.sf-stats-grid').forEach(function(grid) {
      var duration = parseInt(grid.dataset.duration, 10) || 2000;
      var observed = false;

      var obs = getIntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
          if (entry.isIntersecting && !observed) {
            observed = true;
            grid.querySelectorAll('.sf-count-up').forEach(function(el) {
              animateCount(el, duration);
            });
          }
        });
      }, { threshold: 0.3 });

      obs.observe(grid);
    });
  }

  function animateCount(el, duration) {
    var target   = parseInt(el.dataset.target, 10) || 0;
    var start    = 0;
    var startTs  = null;

    function step(ts) {
      if (!startTs) startTs = ts;
      var progress = Math.min((ts - startTs) / duration, 1);
      var ease     = 1 - Math.pow(1 - progress, 3); // cubic ease-out
      el.textContent = Math.floor(ease * target).toLocaleString();
      if (progress < 1) requestAnimationFrame(step);
      else el.textContent = target.toLocaleString();
    }
    requestAnimationFrame(step);
  }

  /* ── 2. Testimonials Slider ───────────────────────────────────────────── */
  function initTestimonialsSliders() {
    document.querySelectorAll('.sf-testimonials-slider').forEach(function(wrap) {
      var track    = wrap.querySelector('.sf-slider-track');
      var dotsWrap = wrap.querySelector('.sf-slider-dots');
      var prevBtn  = wrap.querySelector('.sf-slider-prev');
      var nextBtn  = wrap.querySelector('.sf-slider-next');
      if (!track) return;

      var cards   = Array.from(track.children);
      var count   = cards.length;
      var current = 0;
      var autoplay = wrap.dataset.autoplay === 'true';
      var timer;

      // Build dots
      if (dotsWrap) {
        cards.forEach(function(_, i) {
          var dot = document.createElement('button');
          dot.className = 'sf-dot' + (i === 0 ? ' is-active' : '');
          dot.setAttribute('aria-label', 'Slide ' + (i + 1));
          dot.addEventListener('click', function() { goTo(i); });
          dotsWrap.appendChild(dot);
        });
      }

      function goTo(n) {
        cards[current].classList.remove('is-active');
        current = (n + count) % count;
        cards[current].classList.add('is-active');
        if (dotsWrap) {
          Array.from(dotsWrap.children).forEach(function(d, i) {
            d.classList.toggle('is-active', i === current);
          });
        }
      }

      // Set first active
      cards[0].classList.add('is-active');

      if (prevBtn) prevBtn.addEventListener('click', function() { clearInterval(timer); goTo(current - 1); if (autoplay) startAutoplay(); });
      if (nextBtn) nextBtn.addEventListener('click', function() { clearInterval(timer); goTo(current + 1); if (autoplay) startAutoplay(); });

      function startAutoplay() {
        timer = setInterval(function() { goTo(current + 1); }, 4000);
      }
      if (autoplay) startAutoplay();

      // Pause on hover
      wrap.addEventListener('mouseenter', function() { clearInterval(timer); });
      wrap.addEventListener('mouseleave', function() { if (autoplay) startAutoplay(); });

      // Touch / swipe
      var touchStartX = 0;
      track.addEventListener('touchstart', function(e) { touchStartX = e.changedTouches[0].clientX; }, { passive: true });
      track.addEventListener('touchend', function(e) {
        var diff = touchStartX - e.changedTouches[0].clientX;
        if (Math.abs(diff) > 50) goTo(diff > 0 ? current + 1 : current - 1);
      });
    });
  }

  /* ── 3. FAQ Accordion ─────────────────────────────────────────────────── */
  function initFaqAccordions() {
    document.querySelectorAll('.sf-faq-accordion').forEach(function(acc) {
      var type = acc.dataset.type || 'single';

      acc.querySelectorAll('.sf-faq-question').forEach(function(btn) {
        btn.addEventListener('click', function() {
          var item    = btn.closest('.sf-faq-item');
          var answer  = document.getElementById(btn.getAttribute('aria-controls'));
          var isOpen  = item.classList.contains('is-open');

          // Close all if single mode
          if (type === 'single' && !isOpen) {
            acc.querySelectorAll('.sf-faq-item.is-open').forEach(function(openItem) {
              openItem.classList.remove('is-open');
              openItem.querySelector('.sf-faq-question').setAttribute('aria-expanded', 'false');
              var a = openItem.querySelector('.sf-faq-answer');
              if (a) a.setAttribute('hidden', '');
            });
          }

          if (isOpen) {
            item.classList.remove('is-open');
            btn.setAttribute('aria-expanded', 'false');
            if (answer) answer.setAttribute('hidden', '');
          } else {
            item.classList.add('is-open');
            btn.setAttribute('aria-expanded', 'true');
            if (answer) answer.removeAttribute('hidden');
          }
        });
      });
    });
  }

  /* ── 4. Portfolio Grid Filter ─────────────────────────────────────────── */
  function initPortfolioFilters() {
    document.querySelectorAll('.sf-portfolio-wrapper').forEach(function(wrap) {
      var filterTabs = wrap.querySelectorAll('.sf-filter-tab');
      var items      = wrap.querySelectorAll('.sf-portfolio-item');

      filterTabs.forEach(function(tab) {
        tab.addEventListener('click', function() {
          filterTabs.forEach(function(t) { t.classList.remove('active'); t.setAttribute('aria-selected', 'false'); });
          tab.classList.add('active');
          tab.setAttribute('aria-selected', 'true');

          var filter = tab.dataset.filter;
          items.forEach(function(item) {
            if (filter === '*') {
              item.style.display = '';
            } else {
              var cats = (item.dataset.cats || '').split(' ');
              item.style.display = cats.indexOf(filter) !== -1 ? '' : 'none';
            }
          });
        });
      });
    });
  }

  /* ── 5. Logo Carousel – CSS animation approach ────────────────────────── */
  function initLogoCarousels() {
    document.querySelectorAll('.sf-logo-carousel').forEach(function(wrap) {
      var track     = wrap.querySelector('.sf-logo-track');
      var speed     = parseFloat(wrap.dataset.speed) || 60;
      var pauseHov  = wrap.dataset.pause === 'true';
      var perView   = parseInt(wrap.dataset.perView, 10) || 5;

      if (!track) return;

      // Set animation duration based on content width and speed
      function setDuration() {
        var totalWidth = track.scrollWidth / 2; // duplicated track
        var dur = totalWidth / speed;
        track.style.animationDuration = dur + 's';
      }
      setDuration();
      window.addEventListener('resize', setDuration);

      if (pauseHov) {
        wrap.addEventListener('mouseenter', function() { track.style.animationPlayState = 'paused'; });
        wrap.addEventListener('mouseleave', function() { track.style.animationPlayState = 'running'; });
      }
    });
  }

  /* ── 6. Timeline scroll animation ────────────────────────────────────── */
  function initTimelines() {
    var timelines = document.querySelectorAll('.sf-timeline--animate');
    if (!timelines.length) return;

    var obs = getIntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });

    timelines.forEach(function(tl) {
      tl.querySelectorAll('.sf-timeline-item').forEach(function(item) {
        obs.observe(item);
      });
    });
  }

  /* ── Init all ─────────────────────────────────────────────────────────── */
  onReady(function() {
    initStatsCounters();
    initTestimonialsSliders();
    initFaqAccordions();
    initPortfolioFilters();
    initLogoCarousels();
    initTimelines();
  });

  // Elementor frontend re-init
  if (window.elementorFrontend) {
    window.elementorFrontend.hooks.addAction('frontend/element_ready/global', function() {
      initStatsCounters();
      initTestimonialsSliders();
      initFaqAccordions();
      initPortfolioFilters();
      initLogoCarousels();
    });
  }

})();
