<?php
/**
 * Plugin Name: TF WooCommerce Guard Fix
 * Version: 1.0
 */
if (!defined('ABSPATH')) exit;

register_activation_hook(__FILE__, 'tf_woo_fix_run');
function tf_woo_fix_run() {
    $fp = WP_CONTENT_DIR . '/themes/themeflex/functions.php';
    if (!file_exists($fp)) { update_option('tf_woo_fix_log', 'functions.php not found'); return; }
    $c = file_get_contents($fp);
    $changed = 0;

    $replacements = [
        [
            "// Include WooCommerce Support\nif ( file_exists( THEMEFLEX_DIR . '/includes/woocommerce.php' ) ) {\n\trequire_once THEMEFLEX_DIR . '/includes/woocommerce.php';\n}",
            "// Include WooCommerce Support (only when WooCommerce is active)\nif ( class_exists( 'WooCommerce' ) && file_exists( THEMEFLEX_DIR . '/includes/woocommerce.php' ) ) {\n\trequire_once THEMEFLEX_DIR . '/includes/woocommerce.php';\n}"
        ],
        [
            "if ( file_exists( THEMEFLEX_DIR . '/includes/class-woo-builder.php' ) ) {\n\trequire_once THEMEFLEX_DIR . '/includes/class-woo-builder.php';\n\tThemeFlex_Woo_Builder::init();\n}",
            "if ( class_exists( 'WooCommerce' ) && file_exists( THEMEFLEX_DIR . '/includes/class-woo-builder.php' ) ) {\n\trequire_once THEMEFLEX_DIR . '/includes/class-woo-builder.php';\n\tThemeFlex_Woo_Builder::init();\n}"
        ],
        [
            "if ( file_exists( THEMEFLEX_DIR . '/includes/class-woo-builder.php' ) ) {\n\trequire_once THEMEFLEX_DIR . '/includes/class-woo-builder.php';\n}",
            "if ( class_exists( 'WooCommerce' ) && file_exists( THEMEFLEX_DIR . '/includes/class-woo-builder.php' ) ) {\n\trequire_once THEMEFLEX_DIR . '/includes/class-woo-builder.php';\n}"
        ],
    ];
    foreach ($replacements as $pair) {
        if (strpos($c, $pair[0]) !== false) {
            $c = str_replace($pair[0], $pair[1], $c);
            $changed++;
        }
    }
    if ($changed > 0) {
        file_put_contents($fp, $c);
        update_option('tf_woo_fix_log', "Fixed $changed WooCommerce guard(s) in functions.php");
    } else {
        update_option('tf_woo_fix_log', "Nothing to patch (already done or pattern mismatch)");
    }
}
add_action('admin_notices', function() {
    $log = get_option('tf_woo_fix_log');
    if ($log) echo '<div class="notice notice-success is-dismissible"><p><strong>TF Woo Fix:</strong> ' . esc_html($log) . '</p></div>';
});
