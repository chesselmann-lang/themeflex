<?php
/**
 * Plugin Name: ThemeFlex Widget Fixer
 * Description: One-time fixer — removes escaped dollar signs from Elementor widgets and fixes esc_js_e calls.
 * Version:     1.0.0
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

register_activation_hook( __FILE__, 'themeflex_fixer_run' );

function themeflex_fixer_run() {
    $log = array();

    /* ── 1. Fix the 6 Elementor widget files (\$ → $) ─────────────────── */
    $widget_dir = WP_CONTENT_DIR . '/themes/themeflex/includes/elementor-widgets/';
    $widgets = array(
        'audio-player.php',
        'changelog.php',
        'code-snippet.php',
        'exit-intent.php',
        'restaurant-menu.php',
        'tilt-card.php',
    );

    foreach ( $widgets as $fname ) {
        $path = $widget_dir . $fname;
        if ( ! file_exists( $path ) ) {
            $log[] = "SKIP (not found): $fname";
            continue;
        }
        $content = file_get_contents( $path );
        if ( strpos( $content, '\$' ) !== false ) {
            $fixed = str_replace( '\$', '$', $content );
            if ( file_put_contents( $path, $fixed ) !== false ) {
                $log[] = "FIXED (escaped \$): $fname";
            } else {
                $log[] = "ERROR (write failed): $fname";
            }
        } else {
            $log[] = "OK (no escaped \$): $fname";
        }
    }

    /* ── 2. Fix class-setup-wizard.php (esc_js_e → echo esc_js(__)) ───── */
    $wizard_path = WP_CONTENT_DIR . '/themes/themeflex/includes/class-setup-wizard.php';
    if ( file_exists( $wizard_path ) ) {
        $content = file_get_contents( $wizard_path );
        $changed = false;

        /* fix esc_js_e( 'text', 'domain' ) */
        if ( strpos( $content, 'esc_js_e' ) !== false ) {
            $content = preg_replace(
                "/esc_js_e\s*\(\s*'([^']*)'\s*,\s*'([^']*)'\s*\)/",
                "echo esc_js( __( '$1', '$2' ) )",
                $content
            );
            $changed = true;
        }

        /* fix Unicode ellipsis → three dots */
        $ellipsis = "\xe2\x80\xa6";
        if ( strpos( $content, $ellipsis ) !== false ) {
            $content = str_replace( $ellipsis, '...', $content );
            $changed = true;
        }

        if ( $changed ) {
            if ( file_put_contents( $wizard_path, $content ) !== false ) {
                $log[] = 'FIXED: class-setup-wizard.php';
            } else {
                $log[] = 'ERROR (write failed): class-setup-wizard.php';
            }
        } else {
            $log[] = 'OK (no changes needed): class-setup-wizard.php';
        }
    } else {
        $log[] = 'SKIP (not found): class-setup-wizard.php';
    }

    update_option( 'themeflex_fixer_log', implode( ' | ', $log ) );
}

/* Show result banner in wp-admin */
function themeflex_fixer_notice() {
    $log = get_option( 'themeflex_fixer_log' );
    if ( $log ) {
        echo '<div class="notice notice-success is-dismissible"><p><strong>ThemeFlex Fixer:</strong> ' . esc_html( $log ) . '</p></div>';
    }
}
add_action( 'admin_notices', 'themeflex_fixer_notice' );
