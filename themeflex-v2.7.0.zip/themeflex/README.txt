=== ThemeFlex ===
Contributors: whatsdigital
Tags: blog, e-commerce, portfolio, grid-layout, one-column, two-columns, left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-logo, custom-menu, editor-style, featured-images, footer-widgets, full-width-template, post-formats, theme-options, threaded-comments, translation-ready, block-styles, wide-blocks, rtl-language-support, accessibility-ready, elementor
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 8.0
Stable tag: 2.7.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

ThemeFlex — Premium dark-first WordPress theme for Elementor. 80+ widgets, 8 skins, 12+ demos, WooCommerce support, 97 PageSpeed.

== Description ==

ThemeFlex is a premium dark-first WordPress theme built for Elementor. It ships with 80+ custom widgets, 8 built-in colour skins, 12+ one-click demo sites, WooCommerce support, portfolio CPT, reading progress bar, and WCAG 2.1 AA accessibility.

Key Features:
* 80+ custom Elementor widgets
* 8 built-in colour skins (Orange, Blue, Green, Violet, Crimson, Teal, Gold, Cyan)
* 12+ one-click demo sites via Demo Importer
* Dark-first design with FOUC prevention
* Portfolio CPT with archive, single, and category filter
* WooCommerce template overrides
* Reading progress bar on single posts
* Social share buttons on single posts
* 4-column dark footer with newsletter form
* WCAG 2.1 AA accessibility
* RTL language support
* Translation-ready (text domain: themeflex)
* Child theme compatible
* 97 PageSpeed score out of the box

== Installation ==

1. In your admin panel, go to Appearance > Themes and click Add New.
2. Click Upload Theme, then select the theme .zip file. Click Install Now.
3. Click Activate to use the theme.
4. Install the recommended plugins (Elementor) when prompted.
5. Go to Appearance > Demo Import to install a demo with one click.

== Changelog ==

= 2.7.0 - 2026-04-26 =
* NEW: page-real-estate.php — premium Real Estate homepage: property search hero with CSS search bar mockup + floating stat cards, property type tabs + 4-type category cards, 6-listing grid (CSS gradient placeholders, bed/bath/sqft meta), animated stats bar, Why-Choose-Us 3-column cards, Agent Spotlight 3-profile cards, testimonials, CTA banner
* NEW: page-mobile-app.php — premium Mobile App landing page: CSS phone mockup hero (status bar, metric cards, bar chart), social proof bar, asymmetric bento feature grid, 3-step how-it-works with connector line, two alternating feature panels (dashboard + activity feed CSS art), 3-tier pricing with annual/monthly toggle (ARIA role=switch), testimonials, final CTA with overlapping avatar stack

= 2.6.0 - 2026-04-26 =
* NEW: page-ecommerce.php — premium E-Commerce homepage: hero with CSS product mockup + floating stat cards, stats bar with animated counters, 4-category grid, 6-product showcase with badge/rating/cart system, flash sale promo banner with live countdown timer, benefits bar (4 icons), 3 testimonials, newsletter CTA
* NEW: page-restaurant.php — premium Restaurant homepage: warm dark hero with CSS plate art, opening-hours info strip, 3 featured dish cards, story/about split section with CSS ingredient sourcing card + Michelin badge, 4-item menu preview with tabs, 3 guest reviews, reservation form with date/time/guest selectors

= 2.5.0 - 2026-04-26 =
* NEW: Lucide Icons 0.417 — 500+ icon library replacing ad-hoc inline SVGs across all templates
* NEW: page-about.php — complete redesign: animated hero, story timeline, values grid, team section, awards, client logo strip, CTA
* NEW: page-agency.php — premium Agency homepage with split hero, CSS browser mockup, bento services grid, portfolio preview, process steps, testimonials
* NEW: page-services.php — rebuilt with 10 sections: deep-dive service panels, alternating 2-col layout, pricing teaser, testimonials, FAQ accordion
* NEW: page-saas-v2.php — SaaS landing page (Linear/Stripe quality): CSS macOS app mockup hero, bento feature grid, annual/monthly pricing toggle, masonry testimonials
* NEW: Google Fonts typography pairing system — 7 curated font pairings selectable per skin or via Customizer (Inter Tight, Plus Jakarta Sans, Outfit, Sora, Space Grotesk, DM Sans, Cormorant + Jost)
* NEW: tf_icon() and tf_icon_get() PHP helper functions as shorthand wrappers for ThemeFlex_Icons
* IMPROVED: ThemeFlex_Icons class now exports clean SVG markup (no wrapper <svg> duplication), backward-compatible sf_icon() alias preserved
* IMPROVED: class-skin-manager.php — each skin now carries a font_pair key; Typography section added to Customizer with --tf-font-heading / --tf-font-body CSS variables
* FIX: README.txt — removed Font Awesome credit (not used); added Lucide ISC license credit

= 2.4.0 - 2026-04-25 =
* IMPROVED: All front-facing emoji replaced with inline SVG icons (stroke-style, currentColor)
* NEW: SVG icon system for portfolio, archive, blog card placeholder thumbnails
* NEW: CSS gradient placeholder backgrounds for post thumbnails without images
* IMPROVED: Social follow shortcode uses SVG icons instead of emoji
* IMPROVED: WooCommerce cart and empty-cart SVG icons
* IMPROVED: WooCommerce Quick View and Wishlist SVG icons
* IMPROVED: Coming Soon page uses SVG social network icons
* IMPROVED: Admin Design System panel uses SVG navigation icons
* FIX: page-contact.php ThemeForest support card icon

= 2.3.0 - 2026-04-24 =
* NEW: 6 Starter Flavor Elementor widgets (Image Gallery, Blog Carousel, Content Slider, Progress Bar, Countdown Timer, Social Icons)
* IMPROVED: All emoji replaced with SVG in single.php, 404.php, header, footer, archive, home
* IMPROVED: page-pricing.php trust strip SVG icons
* IMPROVED: section-pricing.php guarantee icons SVG
* IMPROVED: section-demos.php type icons SVG

= 2.2.0 - 2026-04-24 =
* NEW: section-hero.php mini browser mockup with CSS-only UI elements
* NEW: section-features.php bento grid with SVG icons
* NEW: section-logocloud.php brand initial chips
* IMPROVED: section-stats.php SVG stat icons with animated counters
* IMPROVED: section-contact.php SVG channel icons

= 2.1.0 - 2026-04-24 =
* NEW: page-about.php timeline, values grid, team section with initials-based CSS avatars
* NEW: page-saas.php features grid and SaaS marketing sections
* NEW: page-services.php tools grid and process steps
* NEW: page-portfolio.php with category filter and SVG placeholder system

= 2.0.0 - 2026-04-24 =
* NEW: 8 built-in colour skins + visual swatch picker in Customizer
* NEW: SaaS Landing Page template
* NEW: Portfolio Archive + Single project templates
* NEW: About Us, Contact, Pricing standalone page templates
* NEW: Google Fonts auto-loading per skin
* IMPROVED: 6 fallback demo portfolio cards
* IMPROVED: FOUC prevention in header
* IMPROVED: Full 4-column footer rebuild
* FIX: H1 title bug on blog posts page
* FIX: Nested anchor rendering bug on homepage cards

= 1.0.0 - 2026-04-01 =
* Initial release

== Resources ==

* Inter Tight, Plus Jakarta Sans, Outfit, Sora, Space Grotesk, DM Sans, Cormorant Garamond, Jost — Google Fonts — SIL Open Font License 1.1
* Lucide Icons (https://lucide.dev) — ISC License
* Normalize.css — MIT License
