/**
 * Blog Filters JavaScript
 *
 * AJAX-based filtering with URL state management
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

(function() {
	'use strict';

	// Cache DOM elements
	const filterSelects = document.querySelectorAll('.filter-select');
	const loadingDiv = document.querySelector('.filter-loading');

	if (!filterSelects.length) {
		return;
	}

	// Debounce function
	function debounce(func, delay) {
		let timeoutId;
		return function(...args) {
			clearTimeout(timeoutId);
			timeoutId = setTimeout(() => func.apply(this, args), delay);
		};
	}

	// Get filter values from URL
	function getFiltersFromUrl() {
		const params = new URLSearchParams(window.location.search);
		return {
			category: params.get('category') || '',
			tags: params.get('tags') || '',
			sort: params.get('sort') || 'date',
			paged: parseInt(params.get('paged') || 1)
		};
	}

	// Set filter values from URL
	function setFiltersFromUrl() {
		const filters = getFiltersFromUrl();

		filterSelects.forEach(function(select) {
			if (select.classList.contains('filter-category') && filters.category) {
				select.value = filters.category;
			} else if (select.classList.contains('filter-sort')) {
				select.value = filters.sort;
			}
		});
	}

	// Update URL
	function updateUrl(filters) {
		const params = new URLSearchParams();

		if (filters.category) {
			params.set('category', filters.category);
		}
		if (filters.tags) {
			params.set('tags', filters.tags);
		}
		if (filters.sort !== 'date') {
			params.set('sort', filters.sort);
		}
		if (filters.paged > 1) {
			params.set('paged', filters.paged);
		}

		const newUrl = window.location.pathname + (params.toString() ? '?' + params.toString() : '');
		window.history.pushState(null, '', newUrl);
	}

	// Get current filter values
	function getFilterValues() {
		const filters = {
			category: '',
			sort: 'date'
		};

		filterSelects.forEach(function(select) {
			if (select.classList.contains('filter-category')) {
				filters.category = select.value;
			} else if (select.classList.contains('filter-sort')) {
				filters.sort = select.value;
			}
		});

		return filters;
	}

	// Fetch filtered posts
	const debouncedFetch = debounce(function() {
		const filters = getFilterValues();

		// Show loading
		if (loadingDiv) {
			loadingDiv.style.display = 'flex';
		}

		// Build query string
		const params = new URLSearchParams();
		if (filters.category) params.append('category', filters.category);
		if (filters.tags) params.append('tags', filters.tags);
		if (filters.sort) params.append('sort', filters.sort);

		const url = starterFlavorFilters.rest_url + '?' + params.toString();

		fetch(url, {
			headers: {
				'X-WP-Nonce': starterFlavorFilters.nonce
			}
		})
		.then(response => {
			if (!response.ok) {
				throw new Error('Network response was not ok');
			}
			return response.json();
		})
		.then(data => {
			displayPosts(data.posts);
			updateUrl(filters);

			// Hide loading
			if (loadingDiv) {
				loadingDiv.style.display = 'none';
			}

			// Scroll to results
			const postsContainer = document.querySelector('.blog-posts-container, .posts');
			if (postsContainer) {
				postsContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
			}
		})
		.catch(error => {
			console.error('Error fetching posts:', error);

			if (loadingDiv) {
				loadingDiv.style.display = 'none';
			}
		});
	}, 300);

	// Display posts
	function displayPosts(posts) {
		const postsContainer = document.querySelector('.posts, .blog-posts-container');

		if (!postsContainer) {
			return;
		}

		if (posts.length === 0) {
			postsContainer.innerHTML = `
				<div class="blog-posts-empty">
					<h3>${starterFlavorFilters.noResults || 'No posts found'}</h3>
					<p>${starterFlavorFilters.noResultsText || 'Try adjusting your filters'}</p>
				</div>
			`;
			return;
		}

		let html = '';

		posts.forEach(function(post) {
			html += `
				<article class="blog-post-item post">
					${post.thumbnail ? `
						<div class="blog-post-thumbnail">
							<img src="${post.thumbnail}" alt="${escapeHtml(post.title)}" loading="lazy" />
						</div>
					` : ''}
					<div class="blog-post-body">
						<h3 class="blog-post-title">
							<a href="${post.permalink}">${escapeHtml(post.title)}</a>
						</h3>
						<div class="blog-post-meta">
							<time class="blog-post-date">${post.date}</time>
						</div>
						${post.excerpt ? `<p class="blog-post-excerpt">${escapeHtml(post.excerpt)}</p>` : ''}
						<a href="${post.permalink}" class="read-more">${starterFlavorFilters.readMore || 'Read More'}</a>
					</div>
				</article>
			`;
		});

		postsContainer.innerHTML = html;
	}

	// Escape HTML
	function escapeHtml(text) {
		const div = document.createElement('div');
		div.textContent = text;
		return div.innerHTML;
	}

	// Event listeners
	filterSelects.forEach(function(select) {
		select.addEventListener('change', debouncedFetch);
	});

	// Load filters from URL on page load
	setFiltersFromUrl();

	// Handle browser back/forward
	window.addEventListener('popstate', function() {
		setFiltersFromUrl();
		debouncedFetch();
	});

})();
