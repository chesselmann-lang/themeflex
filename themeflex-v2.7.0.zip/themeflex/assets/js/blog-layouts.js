/**
 * Blog Layouts JavaScript
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

( function() {
	'use strict';

	/**
	 * Blog Layouts Handler
	 */
	class StarterFlavorBlogLayouts {
		/**
		 * Constructor.
		 */
		constructor() {
			this.container = document.querySelector( '.blog-container' );

			if ( ! this.container ) {
				return;
			}

			this.posts = this.container.querySelector( '.blog-posts' );
			this.pagination = this.container.querySelector( '.pagination' );
			this.isLoading = false;
			this.hasMore = true;

			this.init();
		}

		/**
		 * Initialize the blog layouts.
		 */
		init() {
			this.detectLayout();
			this.bindEvents();
		}

		/**
		 * Detect current layout.
		 */
		detectLayout() {
			const classes = this.container.className;

			if ( classes.includes( 'blog-pagination-load-more' ) ) {
				this.layout = 'load-more';
			} else if ( classes.includes( 'blog-pagination-infinite-scroll' ) ) {
				this.layout = 'infinite-scroll';
			} else {
				this.layout = 'numeric';
			}

			// Detect post layout
			if ( classes.includes( 'blog-layout-grid' ) ) {
				this.postLayout = 'grid';
			} else if ( classes.includes( 'blog-layout-list' ) ) {
				this.postLayout = 'list';
			} else if ( classes.includes( 'blog-layout-masonry' ) ) {
				this.postLayout = 'masonry';
			} else if ( classes.includes( 'blog-layout-metro' ) ) {
				this.postLayout = 'metro';
			} else {
				this.postLayout = 'classic';
			}
		}

		/**
		 * Bind event listeners.
		 */
		bindEvents() {
			if ( 'load-more' === this.layout ) {
				this.bindLoadMore();
			} else if ( 'infinite-scroll' === this.layout ) {
				this.bindInfiniteScroll();
			}
		}

		/**
		 * Bind load more button.
		 */
		bindLoadMore() {
			const button = this.container.querySelector( '.load-more-btn' );

			if ( ! button ) {
				return;
			}

			button.addEventListener( 'click', ( e ) => {
				e.preventDefault();
				this.loadMorePosts( button );
			});
		}

		/**
		 * Bind infinite scroll.
		 */
		bindInfiniteScroll() {
			const trigger = this.container.querySelector( '.infinite-scroll-trigger' );

			if ( ! trigger ) {
				return;
			}

			// Use Intersection Observer for infinite scroll
			const observer = new IntersectionObserver(
				( entries ) => {
					entries.forEach( ( entry ) => {
						if ( entry.isIntersecting && this.hasMore && ! this.isLoading ) {
							this.loadInfiniteScroll();
						}
					});
				},
				{
					root: null,
					rootMargin: '100px',
					threshold: 0.01,
				}
			);

			observer.observe( trigger );
		}

		/**
		 * Load more posts via AJAX.
		 *
		 * @param {Element} button The load more button.
		 */
		loadMorePosts( button ) {
			if ( this.isLoading ) {
				return;
			}

			const currentPage = parseInt( button.dataset.currentPage, 10 );
			const maxPages = parseInt( button.dataset.maxPages, 10 );

			if ( currentPage >= maxPages ) {
				button.disabled = true;
				button.textContent = starterFlavorBlogData.noMorePosts || 'No more posts';
				this.hasMore = false;
				return;
			}

			this.isLoading = true;
			const loadingIndicator = this.container.querySelector( '.loading-indicator' );

			if ( loadingIndicator ) {
				loadingIndicator.style.display = 'block';
			}

			const nextPage = currentPage + 1;

			this.ajax( {
				paged: nextPage,
				layout: this.postLayout,
				posts_per_page: starterFlavorBlogData.postsPerPage || 10,
				category: this.getCurrentCategory(),
			}, ( response ) => {
				this.isLoading = false;

				if ( loadingIndicator ) {
					loadingIndicator.style.display = 'none';
				}

				if ( response.success ) {
					this.appendPosts( response.data.html );
					button.dataset.currentPage = nextPage.toString();

					if ( ! response.data.has_more_pages ) {
						button.disabled = true;
						button.textContent = starterFlavorBlogData.noMorePosts || 'No more posts';
						this.hasMore = false;
					}
				}
			});
		}

		/**
		 * Load infinite scroll posts.
		 */
		loadInfiniteScroll() {
			if ( this.isLoading || ! this.hasMore ) {
				return;
			}

			this.isLoading = true;
			const scrollData = this.container.querySelector( '.infinite-scroll' );
			const currentPage = parseInt( scrollData.dataset.currentPage, 10 );
			const maxPages = parseInt( scrollData.dataset.maxPages, 10 );

			if ( currentPage >= maxPages ) {
				this.hasMore = false;
				return;
			}

			const nextPage = currentPage + 1;
			const loadingIndicator = this.container.querySelector( '.infinite-scroll-loading' );

			if ( loadingIndicator ) {
				loadingIndicator.style.display = 'block';
			}

			this.ajax( {
				paged: nextPage,
				layout: this.postLayout,
				posts_per_page: starterFlavorBlogData.postsPerPage || 10,
				category: this.getCurrentCategory(),
			}, ( response ) => {
				this.isLoading = false;

				if ( loadingIndicator ) {
					loadingIndicator.style.display = 'none';
				}

				if ( response.success ) {
					this.appendPosts( response.data.html );
					scrollData.dataset.currentPage = nextPage.toString();

					if ( ! response.data.has_more_pages ) {
						this.hasMore = false;
					}
				}
			});
		}

		/**
		 * Send AJAX request.
		 *
		 * @param {Object} data The request data.
		 * @param {Function} callback The callback function.
		 */
		ajax( data, callback ) {
			const formData = new FormData();

			formData.append( 'action', 'load_more_posts' );
			formData.append( 'nonce', starterFlavorBlogData.nonce );

			Object.keys( data ).forEach( ( key ) => {
				formData.append( key, data[ key ] );
			});

			fetch( starterFlavorBlogData.ajaxUrl, {
				method: 'POST',
				body: formData,
			})
				.then( ( response ) => response.json() )
				.then( ( response ) => {
					if ( typeof callback === 'function' ) {
						callback( response );
					}
				})
				.catch( ( error ) => {
					console.error( 'Blog load more error:', error );
				});
		}

		/**
		 * Append posts to the grid.
		 *
		 * @param {string} html The HTML content of posts.
		 */
		appendPosts( html ) {
			const tempDiv = document.createElement( 'div' );
			tempDiv.innerHTML = html;

			const articles = tempDiv.querySelectorAll( 'article' );

			articles.forEach( ( article ) => {
				this.posts.appendChild( article );
			});

			// Trigger masonry reflow if needed
			if ( 'masonry' === this.postLayout && window.Masonry ) {
				const masonryInstance = window.Masonry.data( this.posts );
				if ( masonryInstance ) {
					masonryInstance.appended( articles );
					masonryInstance.reloadItems();
					masonryInstance.layout();
				}
			}

			// Trigger any custom events
			const event = new CustomEvent( 'starterFlavorPostsAppended', {
				detail: {
					posts: articles,
					layout: this.postLayout,
				},
			});
			document.dispatchEvent( event );
		}

		/**
		 * Get current category from URL or data attribute.
		 *
		 * @return {string} The current category.
		 */
		getCurrentCategory() {
			const categoryParam = new URLSearchParams( window.location.search ).get( 'cat' );

			if ( categoryParam ) {
				return categoryParam;
			}

			const data = this.container.dataset;
			return data.category || 'all';
		}
	}

	/**
	 * Initialize when DOM is ready.
	 */
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', () => {
			new StarterFlavorBlogLayouts();
		});
	} else {
		new StarterFlavorBlogLayouts();
	}

	// Expose to global scope for external access
	window.StarterFlavorBlogLayouts = StarterFlavorBlogLayouts;
})();
