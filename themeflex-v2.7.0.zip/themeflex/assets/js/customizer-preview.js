/**
 * File customizer-preview.js.
 *
 * Customizer preview bindings with live updates for all settings.
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

(function( $ ) {
	'use strict';

	// ===== SITE TITLE & DESCRIPTION =====
	wp.customize( 'blogname', function( value ) {
		value.bind( function( to ) {
			$( '.site-title a' ).text( to );
		} );
	} );

	wp.customize( 'blogdescription', function( value ) {
		value.bind( function( to ) {
			$( '.site-description' ).text( to );
		} );
	} );

	// ===== COLOR SCHEME =====
	wp.customize( 'starter_flavor_color_primary', function( value ) {
		value.bind( function( to ) {
			updateCSSVariable( '--sf-color-primary', to );
		} );
	} );

	wp.customize( 'starter_flavor_color_secondary', function( value ) {
		value.bind( function( to ) {
			updateCSSVariable( '--sf-color-secondary', to );
		} );
	} );

	wp.customize( 'starter_flavor_color_accent', function( value ) {
		value.bind( function( to ) {
			updateCSSVariable( '--sf-color-accent', to );
		} );
	} );

	wp.customize( 'starter_flavor_color_background', function( value ) {
		value.bind( function( to ) {
			updateCSSVariable( '--sf-color-bg', to );
		} );
	} );

	wp.customize( 'starter_flavor_color_text', function( value ) {
		value.bind( function( to ) {
			updateCSSVariable( '--sf-color-text', to );
		} );
	} );

	// ===== TYPOGRAPHY - FONTS =====
	wp.customize( 'starter_flavor_font_headings', function( value ) {
		value.bind( function( to ) {
			updateCSSVariable( '--sf-font-headings', to + ', -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif' );
			loadGoogleFont( to );
		} );
	} );

	wp.customize( 'starter_flavor_font_body', function( value ) {
		value.bind( function( to ) {
			updateCSSVariable( '--sf-font-body', to + ', -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif' );
			loadGoogleFont( to );
		} );
	} );

	// ===== TYPOGRAPHY - FONT SIZES =====
	wp.customize( 'starter_flavor_h1_size', function( value ) {
		value.bind( function( to ) {
			updateCSSVariable( '--sf-font-size-h1', to + 'px' );
		} );
	} );

	wp.customize( 'starter_flavor_h2_size', function( value ) {
		value.bind( function( to ) {
			updateCSSVariable( '--sf-font-size-h2', to + 'px' );
		} );
	} );

	wp.customize( 'starter_flavor_h3_size', function( value ) {
		value.bind( function( to ) {
			updateCSSVariable( '--sf-font-size-h3', to + 'px' );
		} );
	} );

	wp.customize( 'starter_flavor_body_size', function( value ) {
		value.bind( function( to ) {
			updateCSSVariable( '--sf-font-size-body', to + 'px' );
		} );
	} );

	// ===== HEADER OPTIONS =====
	wp.customize( 'starter_flavor_header_layout', function( value ) {
		value.bind( function( to ) {
			var $header = $( 'header' );
			$header
				.removeClass( 'layout-standard layout-centered layout-transparent' )
				.addClass( 'layout-' + to );
		} );
	} );

	wp.customize( 'starter_flavor_sticky_header', function( value ) {
		value.bind( function( to ) {
			var $header = $( 'header' );
			if ( to ) {
				$header.addClass( 'sticky' );
			} else {
				$header.removeClass( 'sticky' );
			}
		} );
	} );

	wp.customize( 'starter_flavor_header_height', function( value ) {
		value.bind( function( to ) {
			updateCSSVariable( '--sf-header-height', to + 'px' );
		} );
	} );

	// ===== FOOTER OPTIONS =====
	wp.customize( 'starter_flavor_footer_columns', function( value ) {
		value.bind( function( to ) {
			updateCSSVariable( '--sf-footer-columns', to );
			var $footer = $( '.site-footer .footer-widgets' );
			$footer
				.removeClass( 'col-1 col-2 col-3 col-4' )
				.addClass( 'col-' + to );
		} );
	} );

	wp.customize( 'starter_flavor_copyright_text', function( value ) {
		value.bind( function( to ) {
			$( '.site-footer .copyright' ).html( to );
		} );
	} );

	// ===== BLOG OPTIONS =====
	wp.customize( 'starter_flavor_blog_layout', function( value ) {
		value.bind( function( to ) {
			var $blogContainer = $( '.posts-container' );
			$blogContainer
				.removeClass( 'layout-grid layout-list' )
				.addClass( 'layout-' + to );
		} );
	} );

	wp.customize( 'starter_flavor_excerpt_length', function( value ) {
		value.bind( function( to ) {
			// Note: This would require a page reload to apply properly
			// Stored as data attribute for JavaScript reference
			$( 'body' ).attr( 'data-excerpt-length', to );
		} );
	} );

	wp.customize( 'starter_flavor_pagination_style', function( value ) {
		value.bind( function( to ) {
			var $pagination = $( '.pagination' );
			$pagination
				.removeClass( 'style-numbers style-previous style-infinite' )
				.addClass( 'style-' + to );
		} );
	} );

	// ===== DARK MODE =====
	wp.customize( 'starter_flavor_dark_mode', function( value ) {
		value.bind( function( to ) {
			if ( 'off' === to ) {
				$( 'html' ).removeAttr( 'data-theme' );
			} else if ( 'manual' === to ) {
				$( 'html' ).attr( 'data-theme', 'light' );
			}
		} );
	} );

	wp.customize( 'starter_flavor_dark_color_primary', function( value ) {
		value.bind( function( to ) {
			setDarkModeVariable( '--sf-color-primary', to );
		} );
	} );

	wp.customize( 'starter_flavor_dark_color_background', function( value ) {
		value.bind( function( to ) {
			setDarkModeVariable( '--sf-color-bg', to );
		} );
	} );

	wp.customize( 'starter_flavor_dark_color_text', function( value ) {
		value.bind( function( to ) {
			setDarkModeVariable( '--sf-color-text', to );
		} );
	} );

	// ===== HELPER FUNCTIONS =====

	/**
	 * Update a CSS custom property value
	 *
	 * @param {string} property The CSS variable name.
	 * @param {string} value The value to set.
	 */
	function updateCSSVariable( property, value ) {
		document.documentElement.style.setProperty( property, value );
	}

	/**
	 * Set CSS variable for dark mode
	 *
	 * @param {string} property The CSS variable name.
	 * @param {string} value The value to set.
	 */
	function setDarkModeVariable( property, value ) {
		var $style = $( '#starter-flavor-dark-mode-styles' );
		if ( ! $style.length ) {
			$style = $( '<style id="starter-flavor-dark-mode-styles" type="text/css"></style>' );
			$( 'head' ).append( $style );
		}

		var currentCSS = $style.html() || '';
		// Remove existing property from dark mode selector
		currentCSS = currentCSS.replace(
			new RegExp( property + '[^;]*;?', 'g' ),
			''
		);

		var darkModeSelector = '@media (prefers-color-scheme: dark) { :root { ' + property + ': ' + value + '; } }';
		$style.html( currentCSS + ' ' + darkModeSelector );
	}

	/**
	 * Load Google Font dynamically
	 *
	 * @param {string} fontName The font name to load.
	 */
	function loadGoogleFont( fontName ) {
		var fontParam = fontName.replace( /\s+/g, '+' );
		var linkId = 'google-font-' + fontParam;

		if ( ! document.getElementById( linkId ) ) {
			var link = document.createElement( 'link' );
			link.id = linkId;
			link.href = 'https://fonts.googleapis.com/css2?family=' + fontParam + ':wght@300;400;500;600;700&display=swap';
			link.rel = 'stylesheet';
			document.head.appendChild( link );
		}
	}

} )( jQuery );
