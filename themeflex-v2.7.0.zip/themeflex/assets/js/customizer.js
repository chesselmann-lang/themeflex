/**
 * File customizer.js.
 *
 * Theme Customizer enhancements for a better user experience.
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

(function( $ ) {
	'use strict';

	/**
	 * Panel dependencies - Show/hide panels based on other settings
	 */
	wp.customize( 'starter_flavor_dark_mode', function( setting ) {
		setting.bind( function( value ) {
			if ( 'off' === value ) {
				wp.customize.section( 'starter_flavor_dark_mode' ).deactivate();
			} else {
				wp.customize.section( 'starter_flavor_dark_mode' ).activate();
			}
		} );
	} );

	/**
	 * Enhance font selector with preview
	 */
	wp.customize.control( 'starter_flavor_font_headings', function( control ) {
		control.container.on( 'change', 'select', function() {
			var fontName = $( this ).val();
			previewFont( fontName, 'heading' );
		} );
	} );

	wp.customize.control( 'starter_flavor_font_body', function( control ) {
		control.container.on( 'change', 'select', function() {
			var fontName = $( this ).val();
			previewFont( fontName, 'body' );
		} );
	} );

	/**
	 * Add helper descriptions for complex settings
	 */
	addSettingDescriptions();

	/**
	 * Preview font changes
	 *
	 * @param {string} fontName The font name.
	 * @param {string} type The element type ('heading' or 'body').
	 */
	function previewFont( fontName, type ) {
		var fontParam = fontName.replace( /\s+/g, '+' );
		var frameDoc = wp.customize.previewer.container[0].contentDocument;

		if ( frameDoc ) {
			var link = frameDoc.createElement( 'link' );
			link.href = 'https://fonts.googleapis.com/css2?family=' + fontParam + ':wght@300;400;500;600;700&display=swap';
			link.rel = 'stylesheet';
			frameDoc.head.appendChild( link );
		}
	}

	/**
	 * Add helpful descriptions to settings
	 */
	function addSettingDescriptions() {
		var descriptions = {
			'starter_flavor_color_primary': wp.i18n.__( 'Used for links and primary buttons', 'starter-flavor' ),
			'starter_flavor_color_secondary': wp.i18n.__( 'Used for headings and emphasis', 'starter-flavor' ),
			'starter_flavor_color_accent': wp.i18n.__( 'Used for hover states and highlights', 'starter-flavor' ),
			'starter_flavor_sticky_header': wp.i18n.__( 'Header stays visible when scrolling', 'starter-flavor' ),
			'starter_flavor_blog_layout': wp.i18n.__( 'Controls how blog posts are displayed on archive pages', 'starter-flavor' ),
			'starter_flavor_pagination_style': wp.i18n.__( 'Choose how readers navigate between pages', 'starter-flavor' ),
		};

		$.each( descriptions, function( settingId, description ) {
			wp.customize.control( settingId, function( control ) {
				if ( control && control.container ) {
					var $desc = control.container.find( '.description' );
					if ( ! $desc.length ) {
						$desc = $( '<p class="description"></p>' ).appendTo( control.container );
					}
					$desc.html( description );
				}
			} );
		} );
	}

} )( jQuery );
