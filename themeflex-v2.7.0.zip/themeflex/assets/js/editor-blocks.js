/**
 * Block Editor Enhancements
 * @package Starter_Flavor
 * @since 1.0.0
 */

(function($) {
	'use strict';

	// Add custom block styles on document ready
	document.addEventListener('DOMContentLoaded', function() {
		// Add CSS variables to block editor
		const root = document.documentElement;
		root.style.setProperty('--color-primary', '#FF5E2E');
		root.style.setProperty('--color-secondary', '#1F242E');
		root.style.setProperty('--color-accent', '#2ecc71');
	});

	// Hook into block registration if using JS
	if (window.wp && window.wp.blocks) {
		const { registerBlockStyle } = window.wp.blocks;
		const { addFilter } = window.wp.hooks;

		// Add custom block styles
		registerBlockStyle('core/button', {
			name: 'custom-outline',
			label: 'Outline Style'
		});

		registerBlockStyle('core/image', {
			name: 'custom-shadow',
			label: 'With Shadow'
		});

		// Add custom className to blocks
		addFilter(
			'blocks.registerBlockType',
			'starter-flavor/add-custom-class',
			function(settings, name) {
				if (
					name === 'core/paragraph' ||
					name === 'core/heading' ||
					name === 'core/buttons' ||
					name === 'core/image'
				) {
					settings.attributes = {
						...settings.attributes,
						className: {
							type: 'string'
						}
					};
				}
				return settings;
			}
		);
	}

	// Document ready for jQuery features
	$(document).ready(function() {
		// Initialize any jQuery-based editor enhancements
		initializeEditorToolbar();
	});

	/**
	 * Initialize custom toolbar for block editor
	 */
	function initializeEditorToolbar() {
		// Add custom formatting controls if needed
		if (window.wp && window.wp.richText) {
			const { registerFormatType } = window.wp.richText;

			// Example: Register a custom format
			try {
				registerFormatType('starter-flavor/highlight', {
					title: 'Highlight',
					tagName: 'mark',
					className: 'starter-flavor-highlight',
					edit: function() {
						return null;
					}
				});
			} catch (e) {
				// Format may already be registered
			}
		}
	}

	/**
	 * Add custom block category
	 */
	if (window.wp && window.wp.blocks) {
		const { getCategories, registerBlockCollection } = window.wp.blocks;

		// Register custom block collection
		registerBlockCollection('starter-flavor-custom', {
			title: 'Starter Flavor Custom',
			icon: 'star'
		});
	}

})(jQuery);
