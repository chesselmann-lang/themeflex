/**
 * Starter Flavor Theme - Focus Management
 *
 * @package Starter_Flavor
 * @since 1.0.0
 * @description Keyboard navigation and focus management utilities
 */

(function () {
	'use strict';

	const FocusManagement = {
		/**
		 * Initialize focus management
		 *
		 * @since 1.0.0
		 */
		init: function () {
			this.enhanceSkipLinks();
			this.manageFocusOnNavToggle();
			this.handleTabKeyNavigation();
		},

		/**
		 * Enhance skip links functionality
		 *
		 * @since 1.0.0
		 */
		enhanceSkipLinks: function () {
			const skipLinks = document.querySelectorAll('.skip-link');

			skipLinks.forEach((link) => {
				link.addEventListener('click', (event) => {
					event.preventDefault();

					const href = link.getAttribute('href');
					const target = document.querySelector(href);

					if (target) {
						// Set focus to target
						target.setAttribute('tabindex', '-1');
						target.focus();

						// Remove tabindex after focus is lost
						target.addEventListener('blur', () => {
							target.removeAttribute('tabindex');
						});
					}
				});
			});
		},

		/**
		 * Manage focus when mobile navigation is toggled
		 *
		 * @since 1.0.0
		 */
		manageFocusOnNavToggle: function () {
			const navToggle = document.querySelector('.menu-toggle, .nav-toggle');
			const mobileNav = document.querySelector(
				'.mobile-menu, .mobile-nav, .sidebar-menu'
			);

			if (!navToggle || !mobileNav) {
				return;
			}

			navToggle.addEventListener('click', () => {
				const isOpen = mobileNav.getAttribute('aria-expanded') === 'true';

				if (!isOpen) {
					// When opening, focus first link in mobile nav
					setTimeout(() => {
						const firstLink = mobileNav.querySelector('a, button');
						if (firstLink) {
							firstLink.focus();
						}
					}, 100);
				}
			});

			// Close mobile menu on Escape key
			document.addEventListener('keydown', (event) => {
				if (event.key === 'Escape') {
					const isOpen = mobileNav.getAttribute('aria-expanded') === 'true';
					if (isOpen) {
						mobileNav.setAttribute('aria-expanded', 'false');
						navToggle.focus();
					}
				}
			});
		},

		/**
		 * Handle Tab key navigation and focus trapping
		 *
		 * @since 1.0.0
		 */
		handleTabKeyNavigation: function () {
			// Find all focusable elements
			const focusableSelector =
				'a, button, input, select, textarea, [tabindex]:not([tabindex="-1"])';

			document.addEventListener('keydown', (event) => {
				if (event.key !== 'Tab') {
					return;
				}

				// Get modal or focus trap container
				const modal = document.querySelector('[role="dialog"][open], .modal.active');

				if (!modal) {
					return;
				}

				const focusableElements = Array.from(
					modal.querySelectorAll(focusableSelector)
				);

				if (focusableElements.length === 0) {
					return;
				}

				const firstElement = focusableElements[0];
				const lastElement = focusableElements[focusableElements.length - 1];
				const activeElement = document.activeElement;

				// Trap focus within modal
				if (event.shiftKey) {
					// Shift + Tab
					if (activeElement === firstElement) {
						event.preventDefault();
						lastElement.focus();
					}
				} else {
					// Tab
					if (activeElement === lastElement) {
						event.preventDefault();
						firstElement.focus();
					}
				}
			});
		},

		/**
		 * Set focus to element with announcement
		 *
		 * @since 1.0.0
		 * @param {HTMLElement} element Element to focus
		 * @param {string} announcement Optional announcement for screen readers
		 */
		focusElement: function (element, announcement = '') {
			if (!element) {
				return;
			}

			element.setAttribute('tabindex', '-1');
			element.focus();

			// Announce change to screen readers
			if (announcement) {
				this.announce(announcement);
			}

			element.addEventListener(
				'blur',
				() => {
					element.removeAttribute('tabindex');
				},
				{ once: true }
			);
		},

		/**
		 * Announce message to screen readers
		 *
		 * @since 1.0.0
		 * @param {string} message Message to announce
		 */
		announce: function (message) {
			const announcement = document.createElement('div');
			announcement.setAttribute('role', 'status');
			announcement.setAttribute('aria-live', 'polite');
			announcement.className = 'screen-reader-text';
			announcement.textContent = message;

			document.body.appendChild(announcement);

			// Remove after announcement
			setTimeout(() => {
				announcement.remove();
			}, 1000);
		},

		/**
		 * Make element keyboard accessible
		 *
		 * @since 1.0.0
		 * @param {HTMLElement} element Element to make accessible
		 * @param {string} role Element role
		 */
		makeKeyboardAccessible: function (element, role = '') {
			if (!element.hasAttribute('tabindex')) {
				element.setAttribute('tabindex', '0');
			}

			if (role) {
				element.setAttribute('role', role);
			}

			// Handle Enter and Space for custom elements
			element.addEventListener('keydown', (event) => {
				if (event.key === 'Enter' || event.key === ' ') {
					event.preventDefault();
					element.click();
				}
			});
		},
	};

	// Initialize on DOM ready
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', () => {
			FocusManagement.init();
		});
	} else {
		FocusManagement.init();
	}

	// Export for external use
	window.StarterFlavorFocusManagement = FocusManagement;
})();
