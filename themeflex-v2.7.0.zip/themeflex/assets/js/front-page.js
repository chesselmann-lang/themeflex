/**
 * Starter Flavor — Front Page JavaScript
 * Pflichtenheft 2026: Animations, FAQ, Stats Counter, Mobile Sticky CTA, Newsletter
 *
 * Vanilla JS, no dependencies.
 *
 * @package Starter_Flavor
 * @since 1.1.0
 */

(function () {
	'use strict';

	/* ============================================================
	   SCROLL ANIMATIONS — fade-in on IntersectionObserver
	   ============================================================ */
	var fadeEls = document.querySelectorAll( '.sf-fade-in' );

	if ( fadeEls.length && 'IntersectionObserver' in window ) {
		var fadeObserver = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( entry ) {
				if ( entry.isIntersecting ) {
					entry.target.classList.add( 'sf-visible' );
					fadeObserver.unobserve( entry.target );
				}
			} );
		}, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' } );

		fadeEls.forEach( function ( el ) {
			fadeObserver.observe( el );
		} );
	} else {
		// Fallback: show immediately if no IntersectionObserver
		fadeEls.forEach( function ( el ) {
			el.classList.add( 'sf-visible' );
		} );
	}

	/* ============================================================
	   ANIMATED STATS COUNTER
	   Triggers when .sf-stat-number enters the viewport.
	   Uses data-target (number) and data-suffix attributes.
	   ============================================================ */
	function animateCounter( el, target, suffix ) {
		var start    = 0;
		var duration = 1600;
		var step     = 16;
		var steps    = duration / step;
		var increment = target / steps;
		var timer = setInterval( function () {
			start += increment;
			if ( start >= target ) {
				clearInterval( timer );
				el.textContent = target + suffix;
			} else {
				el.textContent = Math.floor( start ) + suffix;
			}
		}, step );
	}

	var statEls = document.querySelectorAll( '.sf-stat-number[data-target]' );

	if ( statEls.length && 'IntersectionObserver' in window ) {
		var statObserver = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( entry ) {
				if ( entry.isIntersecting ) {
					var el     = entry.target;
					var target = parseInt( el.getAttribute( 'data-target' ), 10 );
					var suffix = el.getAttribute( 'data-suffix' ) || '';
					statObserver.unobserve( el );
					animateCounter( el, target, suffix );
				}
			} );
		}, { threshold: 0.5 } );

		statEls.forEach( function ( el ) {
			statObserver.observe( el );
		} );
	}

	/* ============================================================
	   FAQ ACCORDION
	   sfToggleFaq(btn) called from inline onclick in PHP templates.
	   Exposed on window for template compatibility.
	   ============================================================ */
	window.sfToggleFaq = function ( btn ) {
		var item   = btn.closest( '.sf-faq-item' );
		var isOpen = item.classList.contains( 'open' );

		// Close all
		document.querySelectorAll( '.sf-faq-item.open' ).forEach( function ( openItem ) {
			openItem.classList.remove( 'open' );
			var q = openItem.querySelector( '.sf-faq-question' );
			if ( q ) q.setAttribute( 'aria-expanded', 'false' );
		} );

		// Open clicked if it was closed
		if ( ! isOpen ) {
			item.classList.add( 'open' );
			btn.setAttribute( 'aria-expanded', 'true' );
		}
	};

	// Keyboard support: Enter and Space on FAQ buttons
	document.addEventListener( 'keydown', function ( e ) {
		if ( ( e.key === 'Enter' || e.key === ' ' ) && e.target.classList.contains( 'sf-faq-question' ) ) {
			e.preventDefault();
			window.sfToggleFaq( e.target );
		}
	} );

	/* ============================================================
	   MOBILE STICKY CTA
	   Hides when hero is visible, shows on scroll past hero.
	   ============================================================ */
	var stickyCta  = document.getElementById( 'sfMobileStickyCta' );
	var heroSection = document.getElementById( 'sf-hero' );

	if ( stickyCta && heroSection && 'IntersectionObserver' in window ) {
		var stickyObserver = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( entry ) {
				stickyCta.setAttribute( 'aria-hidden', entry.isIntersecting ? 'true' : 'false' );
				stickyCta.style.display = entry.isIntersecting ? 'none' : 'block';
			} );
		}, { threshold: 0.1 } );

		stickyObserver.observe( heroSection );
	}

	/* ============================================================
	   NEWSLETTER FORM VALIDATION (native form — no shortcode)
	   ============================================================ */
	var subForm = document.getElementById( 'sfSubscribeForm' );
	if ( subForm ) {
		subForm.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			var emailInput = document.getElementById( 'sfSubscribeEmail' );
			var msgEl      = document.getElementById( 'sfSubscribeMsg' );
			var btn        = document.getElementById( 'sfSubscribeBtn' );
			var email      = emailInput ? emailInput.value.trim() : '';
			var emailRe    = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

			if ( ! emailRe.test( email ) ) {
				if ( msgEl ) {
					msgEl.style.color = '#f87171';
					msgEl.textContent = sfFrontPage.i18n.invalidEmail || 'Please enter a valid email address.';
				}
				if ( emailInput ) {
					emailInput.style.borderColor = 'rgba(248,113,113,0.5)';
					emailInput.focus();
				}
				return;
			}

			// Reset error state
			if ( emailInput ) emailInput.style.borderColor = '';
			if ( btn ) { btn.disabled = true; }
			if ( msgEl ) { msgEl.style.color = ''; msgEl.textContent = sfFrontPage.i18n.sending || 'Subscribing…'; }

			// Send to admin-ajax (nonce provided by PHP)
			var data = new FormData( subForm );
			data.append( 'action', 'sf_subscribe' );

			fetch( sfFrontPage.ajaxUrl, { method: 'POST', body: data } )
				.then( function ( res ) { return res.json(); } )
				.then( function ( json ) {
					if ( msgEl ) {
						msgEl.style.color = json.success ? '#4ade80' : '#f87171';
						msgEl.textContent = json.data && json.data.message
							? json.data.message
							: ( json.success
								? ( sfFrontPage.i18n.success || 'Thank you for subscribing!' )
								: ( sfFrontPage.i18n.error   || 'Something went wrong. Please try again.' ) );
					}
					if ( json.success && emailInput ) { emailInput.value = ''; }
				} )
				.catch( function () {
					if ( msgEl ) {
						msgEl.style.color = '#f87171';
						msgEl.textContent = sfFrontPage.i18n.error || 'Something went wrong. Please try again.';
					}
				} )
				.finally( function () {
					if ( btn ) btn.disabled = false;
				} );
		} );
	}

	/* ============================================================
	   SCROLL PROGRESS BAR
	   Creates a <div class="sf-scroll-progress"> if not present.
	   ============================================================ */
	var progressBar = document.querySelector( '.sf-scroll-progress' );
	if ( ! progressBar ) {
		progressBar = document.createElement( 'div' );
		progressBar.className = 'sf-scroll-progress';
		progressBar.setAttribute( 'role', 'progressbar' );
		progressBar.setAttribute( 'aria-hidden', 'true' );
		document.body.appendChild( progressBar );
	}

	function updateScrollProgress() {
		var scrollTop  = window.pageYOffset || document.documentElement.scrollTop;
		var docHeight  = document.documentElement.scrollHeight - document.documentElement.clientHeight;
		var pct        = docHeight > 0 ? ( scrollTop / docHeight ) * 100 : 0;
		progressBar.style.width = Math.min( pct, 100 ).toFixed( 2 ) + '%';
	}

	window.addEventListener( 'scroll', updateScrollProgress, { passive: true } );
	updateScrollProgress();

	/* ============================================================
	   BACK-TO-TOP — enhances the existing #back-to-top in footer-default.php.
	   Upgrades the icon to Font Awesome and applies .sf-back-to-top styles.
	   Dark Mode is handled globally by custom.js (runs on all pages).
	   ============================================================ */
	var backToTop = document.getElementById( 'back-to-top' );
	if ( backToTop ) {
		// Upgrade icon + class so front-page CSS styles apply
		backToTop.classList.add( 'sf-back-to-top' );
		backToTop.innerHTML = '<i class="fa-solid fa-chevron-up" aria-hidden="true"></i>';
	}

	/* ============================================================
	   ONE-PAGE NAVIGATION — Active Section Highlight
	   Adds .sf-nav-active to nav links whose href matches the
	   currently visible section id.
	   ============================================================ */
	var navLinks = document.querySelectorAll(
		'#primary-menu a[href*="#"], .site-navigation a[href*="#"]'
	);

	if ( navLinks.length && 'IntersectionObserver' in window ) {
		var sections = [];
		navLinks.forEach( function ( link ) {
			var id = link.getAttribute( 'href' ).split( '#' ).pop();
			var sec = document.getElementById( id );
			if ( sec ) sections.push( sec );
		} );

		var activeId = null;

		var navObserver = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( entry ) {
				if ( entry.isIntersecting ) {
					activeId = entry.target.id;
				}
			} );

			navLinks.forEach( function ( link ) {
				var id = link.getAttribute( 'href' ).split( '#' ).pop();
				if ( id === activeId ) {
					link.classList.add( 'sf-nav-active' );
				} else {
					link.classList.remove( 'sf-nav-active' );
				}
			} );
		}, { threshold: 0.35 } );

		sections.forEach( function ( sec ) { navObserver.observe( sec ); } );
	}

} )();
