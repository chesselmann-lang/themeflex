/**
 * Mega Menu JavaScript
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

( function() {
	'use strict';

	/**
	 * Mega Menu Handler
	 */
	class StarterFlavorMegaMenu {
		/**
		 * Constructor.
		 */
		constructor() {
			this.menu = document.querySelector( '.sf-nav-menu' );

			if ( ! this.menu ) {
				return;
			}

			this.hamburger = this.menu.querySelector( '.sf-hamburger' );
			this.menuItems = this.menu.querySelectorAll( '.menu-item' );
			this.hoverDelay = 200;
			this.hoverTimeout = null;
			this.isMobile = window.innerWidth <= 768;

			this.init();
		}

		/**
		 * Initialize the mega menu.
		 */
		init() {
			this.bindEvents();
			this.handleResize();
		}

		/**
		 * Bind event listeners.
		 */
		bindEvents() {
			// Hamburger menu toggle
			if ( this.hamburger ) {
				this.hamburger.addEventListener( 'click', ( e ) => this.toggleMobileMenu( e ) );
			}

			// Menu item interactions
			this.menuItems.forEach( ( item ) => {
				const link = item.querySelector( 'a' );

				if ( item.classList.contains( 'menu-item-has-children' ) ) {
					// Desktop hover
					if ( ! this.isMobile ) {
						item.addEventListener( 'mouseenter', ( e ) => this.handleItemHover( e, item ) );
						item.addEventListener( 'mouseleave', ( e ) => this.handleItemLeave( e, item ) );
					}

					// Mobile touch
					link.addEventListener( 'click', ( e ) => {
						if ( this.isMobile ) {
							e.preventDefault();
							this.toggleItem( item );
						}
					});

					// Keyboard navigation
					link.addEventListener( 'keydown', ( e ) => this.handleKeyboard( e, item ) );
				}
			});

			// Close menu on Escape
			document.addEventListener( 'keydown', ( e ) => {
				if ( 'Escape' === e.key ) {
					this.closeMobileMenu();
					this.closeAllItems();
				}
			});

			// Close menu when clicking outside
			document.addEventListener( 'click', ( e ) => {
				if ( ! this.menu.contains( e.target ) ) {
					if ( this.isMobile ) {
						this.closeMobileMenu();
					}
					this.closeAllItems();
				}
			});

			// Window resize
			window.addEventListener( 'resize', () => this.handleResize() );
		}

		/**
		 * Handle menu item hover.
		 *
		 * @param {Event} event The event object.
		 * @param {Element} item The menu item element.
		 */
		handleItemHover( event, item ) {
			if ( this.hoverTimeout ) {
				clearTimeout( this.hoverTimeout );
			}

			this.hoverTimeout = setTimeout( () => {
				this.closeAllItems();
				item.classList.add( 'menu-open' );
			}, this.hoverDelay );
		}

		/**
		 * Handle menu item leave.
		 *
		 * @param {Event} event The event object.
		 * @param {Element} item The menu item element.
		 */
		handleItemLeave( event, item ) {
			if ( this.hoverTimeout ) {
				clearTimeout( this.hoverTimeout );
			}

			this.hoverTimeout = setTimeout( () => {
				item.classList.remove( 'menu-open' );
			}, this.hoverDelay );
		}

		/**
		 * Toggle menu item.
		 *
		 * @param {Element} item The menu item element.
		 */
		toggleItem( item ) {
			const isOpen = item.classList.contains( 'menu-open' );

			// Close other items
			this.menuItems.forEach( ( otherItem ) => {
				if ( otherItem !== item && otherItem.classList.contains( 'menu-item-has-children' ) ) {
					otherItem.classList.remove( 'menu-open' );
				}
			});

			if ( isOpen ) {
				item.classList.remove( 'menu-open' );
			} else {
				item.classList.add( 'menu-open' );
			}
		}

		/**
		 * Close all menu items.
		 */
		closeAllItems() {
			this.menuItems.forEach( ( item ) => {
				item.classList.remove( 'menu-open' );
			});
		}

		/**
		 * Toggle mobile menu.
		 *
		 * @param {Event} event The event object.
		 */
		toggleMobileMenu( event ) {
			event.preventDefault();
			this.menu.classList.toggle( 'mobile-open' );
			this.hamburger.classList.toggle( 'active' );
		}

		/**
		 * Close mobile menu.
		 */
		closeMobileMenu() {
			this.menu.classList.remove( 'mobile-open' );
			if ( this.hamburger ) {
				this.hamburger.classList.remove( 'active' );
			}
		}

		/**
		 * Handle window resize.
		 */
		handleResize() {
			const wasMobile = this.isMobile;
			this.isMobile = window.innerWidth <= 768;

			// Reset menu state when switching between mobile and desktop
			if ( wasMobile !== this.isMobile ) {
				this.closeMobileMenu();
				this.closeAllItems();
			}
		}

		/**
		 * Handle keyboard navigation.
		 *
		 * @param {KeyboardEvent} event The keyboard event.
		 * @param {Element} item The menu item element.
		 */
		handleKeyboard( event, item ) {
			const key = event.key;

			switch ( key ) {
				case 'Enter':
				case ' ':
					event.preventDefault();
					if ( this.isMobile ) {
						this.toggleItem( item );
					}
					break;

				case 'ArrowDown':
					event.preventDefault();
					this.focusNextItem( item );
					break;

				case 'ArrowUp':
					event.preventDefault();
					this.focusPreviousItem( item );
					break;

				case 'ArrowRight':
					if ( this.isMobile ) {
						event.preventDefault();
						item.classList.add( 'menu-open' );
						const firstChild = item.querySelector( '.sub-menu' ) || item.querySelector( '.mega-menu-panel' );
						if ( firstChild ) {
							const firstLink = firstChild.querySelector( 'a' );
							if ( firstLink ) {
								firstLink.focus();
							}
						}
					}
					break;

				case 'ArrowLeft':
					if ( this.isMobile ) {
						event.preventDefault();
						const parent = item.closest( '.menu-item-has-children' );
						if ( parent && parent !== item ) {
							const parentLink = parent.querySelector( '> a' );
							if ( parentLink ) {
								parentLink.focus();
							}
						}
					}
					break;
			}
		}

		/**
		 * Focus next menu item.
		 *
		 * @param {Element} item The current menu item.
		 */
		focusNextItem( item ) {
			const next = item.nextElementSibling;
			if ( next && next.classList.contains( 'menu-item' ) ) {
				const link = next.querySelector( 'a' );
				if ( link ) {
					link.focus();
				}
			}
		}

		/**
		 * Focus previous menu item.
		 *
		 * @param {Element} item The current menu item.
		 */
		focusPreviousItem( item ) {
			const prev = item.previousElementSibling;
			if ( prev && prev.classList.contains( 'menu-item' ) ) {
				const link = prev.querySelector( 'a' );
				if ( link ) {
					link.focus();
				}
			}
		}
	}

	/**
	 * Initialize when DOM is ready.
	 */
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', () => {
			new StarterFlavorMegaMenu();
		});
	} else {
		new StarterFlavorMegaMenu();
	}
})();
