/**
 * Starter Flavor Theme - Performance Utilities
 *
 * @package Starter_Flavor
 * @since 1.0.0
 * @description Lazy loading, deferred script loading, and performance helpers
 */

(function () {
	'use strict';

	const StarterFlavorPerformance = {
		/**
		 * Initialize Performance Features
		 *
		 * @since 1.0.0
		 */
		init: function () {
			this.lazyLoadImages();
			this.deferredScriptLoader();
			this.smoothScrollBehavior();
		},

		/**
		 * Lazy Loading for Images using IntersectionObserver
		 *
		 * Automatically loads images with data-src attribute when they enter viewport.
		 * Fallback for browsers without IntersectionObserver support.
		 *
		 * @since 1.0.0
		 */
		lazyLoadImages: function () {
			// Check if IntersectionObserver is supported
			if (!('IntersectionObserver' in window)) {
				// Fallback: Load all images immediately
				this.lazyLoadImagesFallback();
				return;
			}

			const images = document.querySelectorAll('img[data-src]');

			if (images.length === 0) {
				return;
			}

			const imageObserver = new IntersectionObserver(
				(entries, observer) => {
					entries.forEach((entry) => {
						if (entry.isIntersecting) {
							const img = entry.target;
							img.src = img.dataset.src;

							// Handle srcset if present
							if (img.dataset.srcset) {
								img.srcset = img.dataset.srcset;
							}

							// Remove data attributes and placeholder class
							img.removeAttribute('data-src');
							img.removeAttribute('data-srcset');
							img.classList.remove('lazy');
							img.classList.add('lazy-loaded');

							// Stop observing this image
							observer.unobserve(img);
						}
					});
				},
				{
					rootMargin: '50px', // Start loading 50px before entering viewport
				}
			);

			// Observe all lazy-load images
			images.forEach((img) => {
				imageObserver.observe(img);
			});
		},

		/**
		 * Fallback for browsers without IntersectionObserver
		 *
		 * @since 1.0.0
		 */
		lazyLoadImagesFallback: function () {
			const images = document.querySelectorAll('img[data-src]');

			images.forEach((img) => {
				img.src = img.dataset.src;
				if (img.dataset.srcset) {
					img.srcset = img.dataset.srcset;
				}
				img.classList.add('lazy-loaded');
			});
		},

		/**
		 * Deferred Script Loader
		 *
		 * Loads scripts asynchronously after page load or on user interaction.
		 * Usage: <script type="text/deferred" src="script.js"></script>
		 *
		 * @since 1.0.0
		 */
		deferredScriptLoader: function () {
			const deferredScripts = document.querySelectorAll(
				'script[type="text/deferred"]'
			);

			if (deferredScripts.length === 0) {
				return;
			}

			const loadDeferredScripts = () => {
				deferredScripts.forEach((script) => {
					const actualScript = document.createElement('script');

					// Copy attributes from deferred script
					Array.from(script.attributes).forEach((attr) => {
						if (attr.name !== 'type') {
							actualScript.setAttribute(attr.name, attr.value);
						}
					});

					// Set to async
					actualScript.async = true;

					// Copy text content if present
					if (script.textContent) {
						actualScript.textContent = script.textContent;
					}

					// Replace and execute
					script.parentNode.replaceChild(actualScript, script);
				});
			};

			// Load on page load event
			if (document.readyState === 'loading') {
				document.addEventListener('DOMContentLoaded', loadDeferredScripts);
			} else {
				loadDeferredScripts();
			}

			// Also load on first user interaction
			['click', 'scroll', 'touchstart', 'keypress'].forEach((event) => {
				document.addEventListener(
					event,
					() => {
						loadDeferredScripts();
					},
					{ once: true }
				);
			});
		},

		/**
		 * Smooth Scroll Behavior with requestAnimationFrame
		 *
		 * Optimizes scroll events using requestAnimationFrame to avoid
		 * excessive function calls and improve performance.
		 *
		 * @since 1.0.0
		 */
		smoothScrollBehavior: function () {
			const scrollableElements = document.querySelectorAll('[data-smooth-scroll]');

			if (scrollableElements.length === 0) {
				return;
			}

			scrollableElements.forEach((element) => {
				element.addEventListener('click', (event) => {
					const href = element.getAttribute('href');

					if (!href || !href.startsWith('#')) {
						return;
					}

					event.preventDefault();

					const target = document.querySelector(href);

					if (!target) {
						return;
					}

					this.smoothScrollTo(target);
				});
			});
		},

		/**
		 * Smooth Scroll to Element
		 *
		 * Uses requestAnimationFrame for smooth scrolling animation.
		 *
		 * @since 1.0.0
		 * @param {HTMLElement} element Target element to scroll to
		 * @param {number} duration Animation duration in milliseconds (default: 300)
		 */
		smoothScrollTo: function (element, duration = 300) {
			const startPosition = window.pageYOffset;
			const elementPosition = element.getBoundingClientRect().top + startPosition;
			const offsetTop = 0; // Adjust for fixed headers if needed
			const distance = elementPosition - offsetTop - startPosition;
			let start = null;

			const easeInOutQuad = (t, b, c, d) => {
				t /= d / 2;
				if (t < 1) return (c / 2) * t * t + b;
				t--;
				return (-c / 2) * (t * (t - 2) - 1) + b;
			};

			const scroll = (currentTime) => {
				start = start || currentTime;
				const elapsed = currentTime - start;
				const run = easeInOutQuad(elapsed, startPosition, distance, duration);

				window.scrollTo(0, run);

				if (elapsed < duration) {
					requestAnimationFrame(scroll);
				}
			};

			requestAnimationFrame(scroll);
		},
	};

	/**
	 * Debounce Utility Function
	 *
	 * Creates a debounced version of a function that only executes
	 * after the function stops being invoked for a specified time.
	 *
	 * @since 1.0.0
	 * @param {Function} func The function to debounce
	 * @param {number} wait Wait time in milliseconds
	 * @return {Function} Debounced function
	 */
	window.starterFlavorDebounce = function (func, wait) {
		let timeout;

		return function executedFunction(...args) {
			const later = () => {
				clearTimeout(timeout);
				func(...args);
			};

			clearTimeout(timeout);
			timeout = setTimeout(later, wait);
		};
	};

	/**
	 * Throttle Utility Function
	 *
	 * Creates a throttled version of a function that only executes
	 * at most once every specified interval.
	 *
	 * @since 1.0.0
	 * @param {Function} func The function to throttle
	 * @param {number} limit Throttle limit in milliseconds
	 * @return {Function} Throttled function
	 */
	window.starterFlavorThrottle = function (func, limit) {
		let inThrottle;

		return function (...args) {
			if (!inThrottle) {
				func.apply(this, args);
				inThrottle = true;
				setTimeout(() => {
					inThrottle = false;
				}, limit);
			}
		};
	};

	/**
	 * Request Animation Frame Scroll Handler
	 *
	 * Optimizes scroll event handling using requestAnimationFrame.
	 * Usage: starterFlavorOnScroll(callback);
	 *
	 * @since 1.0.0
	 * @param {Function} callback Function to call on scroll
	 */
	window.starterFlavorOnScroll = function (callback) {
		let ticking = false;

		window.addEventListener('scroll', () => {
			if (!ticking) {
				window.requestAnimationFrame(() => {
					callback(window.pageYOffset);
					ticking = false;
				});
				ticking = true;
			}
		});
	};

	/**
	 * Preload Resource
	 *
	 * Programmatically preload resources (fonts, images, scripts).
	 *
	 * @since 1.0.0
	 * @param {string} url URL of resource to preload
	 * @param {string} type Resource type (image, font, script, etc.)
	 */
	window.starterFlavorPreload = function (url, type = 'image') {
		const link = document.createElement('link');
		link.rel = 'preload';
		link.href = url;

		switch (type) {
			case 'font':
				link.as = 'font';
				link.type = 'font/woff2';
				link.crossOrigin = 'anonymous';
				break;
			case 'script':
				link.as = 'script';
				break;
			case 'style':
				link.as = 'style';
				break;
			case 'image':
			default:
				link.as = 'image';
		}

		document.head.appendChild(link);
	};

	/**
	 * Prefetch Resource
	 *
	 * Hints to browser to prefetch a resource for possible future navigation.
	 *
	 * @since 1.0.0
	 * @param {string} url URL of resource to prefetch
	 */
	window.starterFlavorPrefetch = function (url) {
		const link = document.createElement('link');
		link.rel = 'prefetch';
		link.href = url;
		document.head.appendChild(link);
	};

	/**
	 * Check if Element is in Viewport
	 *
	 * Determines if an element is visible in the current viewport.
	 *
	 * @since 1.0.0
	 * @param {HTMLElement} element Element to check
	 * @return {boolean} True if element is in viewport
	 */
	window.starterFlavorIsInViewport = function (element) {
		const rect = element.getBoundingClientRect();
		return (
			rect.top >= 0 &&
			rect.left >= 0 &&
			rect.bottom <=
				(window.innerHeight || document.documentElement.clientHeight) &&
			rect.right <= (window.innerWidth || document.documentElement.clientWidth)
		);
	};

	/**
	 * Performance Metrics Helper
	 *
	 * Logs Web Vitals and performance metrics to console.
	 *
	 * @since 1.0.0
	 */
	window.starterFlavorLogMetrics = function () {
		if (!window.performance) {
			console.log('Performance API not supported');
			return;
		}

		const perfData = window.performance.timing;
		const pageLoadTime =
			perfData.loadEventEnd - perfData.navigationStart;
		const connectTime = perfData.responseEnd - perfData.requestStart;
		const renderTime = perfData.domComplete - perfData.domLoading;

		console.log('=== Starter Flavor Performance Metrics ===');
		console.log('Page Load Time: ' + pageLoadTime + 'ms');
		console.log('Connect Time: ' + connectTime + 'ms');
		console.log('Render Time: ' + renderTime + 'ms');
	};

	// Initialize on DOM ready
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', () => {
			StarterFlavorPerformance.init();
		});
	} else {
		StarterFlavorPerformance.init();
	}

	// Export for external use
	window.StarterFlavorPerformance = StarterFlavorPerformance;
})();
