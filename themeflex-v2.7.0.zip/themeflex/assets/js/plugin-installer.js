/**
 * Plugin Installer
 * @package Starter_Flavor
 * @since 1.0.0
 */

(function($) {
	'use strict';

	var StarterFlavorPlugins = {
		init: function() {
			this.bindEvents();
		},

		bindEvents: function() {
			var self = this;

			// Install button click
			$(document).on('click', '.install-btn', function(e) {
				e.preventDefault();
				var $btn = $(this);
				var slug = $btn.data('slug');
				self.installPlugin($btn, slug);
			});

			// Activate button click
			$(document).on('click', '.activate-btn', function(e) {
				e.preventDefault();
				var $btn = $(this);
				var slug = $btn.data('slug');
				self.activatePlugin($btn, slug);
			});

			// Bulk install button
			$(document).on('click', '.bulk-install-btn', function(e) {
				e.preventDefault();
				self.bulkInstallPlugins();
			});

			// Bulk activate button
			$(document).on('click', '.bulk-activate-btn', function(e) {
				e.preventDefault();
				self.bulkActivatePlugins();
			});
		},

		installPlugin: function($btn, slug) {
			var self = this;

			$.ajax({
				url: starterFlavorPlugins.ajaxUrl,
				type: 'POST',
				data: {
					action: 'starter_flavor_install_plugin',
					slug: slug,
					nonce: starterFlavorPlugins.nonce
				},
				beforeSend: function() {
					$btn.prop('disabled', true).text('Installing...');
				},
				success: function(response) {
					if (response.success) {
						// Change button to activate
						$btn.removeClass('install-btn').addClass('activate-btn').text('Activate');
						$btn.off('click').on('click', function(e) {
							e.preventDefault();
							self.activatePlugin($(this), slug);
						});
					} else {
						alert('Error installing plugin: ' + response.data);
						$btn.prop('disabled', false).text('Install');
					}
				},
				error: function() {
					alert('Error installing plugin');
					$btn.prop('disabled', false).text('Install');
				}
			});
		},

		activatePlugin: function($btn, slug) {
			$.ajax({
				url: starterFlavorPlugins.ajaxUrl,
				type: 'POST',
				data: {
					action: 'starter_flavor_activate_plugin',
					slug: slug,
					nonce: starterFlavorPlugins.nonce
				},
				beforeSend: function() {
					$btn.prop('disabled', true).text('Activating...');
				},
				success: function(response) {
					if (response.success) {
						// Change button to active status badge
						var $card = $btn.closest('.plugin-card');
						$card.removeClass('installed').addClass('active');
						$btn.replaceWith('<span class="status-badge active"><span class="dashicon dashicons dashicons-yes"></span>Active</span>');
					} else {
						alert('Error activating plugin: ' + response.data);
						$btn.prop('disabled', false).text('Activate');
					}
				},
				error: function() {
					alert('Error activating plugin');
					$btn.prop('disabled', false).text('Activate');
				}
			});
		},

		bulkInstallPlugins: function() {
			var self = this;

			$.ajax({
				url: starterFlavorPlugins.ajaxUrl,
				type: 'POST',
				data: {
					action: 'starter_flavor_bulk_install_plugins',
					nonce: starterFlavorPlugins.nonce
				},
				beforeSend: function() {
					$('.bulk-install-btn').prop('disabled', true).text('Installing all...');
				},
				success: function(response) {
					if (response.success) {
						// Reload page to show updated status
						location.reload();
					} else {
						alert('Error installing plugins: ' + response.data);
						$('.bulk-install-btn').prop('disabled', false).text('Install All Plugins');
					}
				},
				error: function() {
					alert('Error installing plugins');
					$('.bulk-install-btn').prop('disabled', false).text('Install All Plugins');
				}
			});
		},

		bulkActivatePlugins: function() {
			$.ajax({
				url: starterFlavorPlugins.ajaxUrl,
				type: 'POST',
				data: {
					action: 'starter_flavor_bulk_activate_plugins',
					nonce: starterFlavorPlugins.nonce
				},
				beforeSend: function() {
					$('.bulk-activate-btn').prop('disabled', true).text('Activating all...');
				},
				success: function(response) {
					if (response.success) {
						// Reload page to show updated status
						location.reload();
					} else {
						alert('Error activating plugins: ' + response.data);
						$('.bulk-activate-btn').prop('disabled', false).text('Activate All Plugins');
					}
				},
				error: function() {
					alert('Error activating plugins');
					$('.bulk-activate-btn').prop('disabled', false).text('Activate All Plugins');
				}
			});
		}
	};

	// Initialize on document ready
	$(document).ready(function() {
		StarterFlavorPlugins.init();
	});

	// Export for external use
	window.StarterFlavorPlugins = StarterFlavorPlugins;

})(jQuery);
