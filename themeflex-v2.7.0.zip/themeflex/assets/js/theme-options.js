/**
 * Starter Flavor Theme Options JavaScript
 */

(function ($) {
	'use strict';

	var ThemeOptions = {
		init: function () {
			this.bindEvents();
			this.initColorPickers();
			this.updateSliderValues();
		},

		bindEvents: function () {
			// Tab navigation
			$(document).on('click', '.sf-tab-link', function (e) {
				e.preventDefault();
				var tabId = $(this).attr('href');

				// Remove active class and hide all tabs
				$('.sf-tab-link').removeClass('active');
				$('.sf-tab-content').removeClass('active');

				// Add active class to clicked tab and show content
				$(this).addClass('active');
				$(tabId).addClass('active');
			});

			// Save options
			$(document).on('click', '#sf-save-options', function (e) {
				e.preventDefault();
				ThemeOptions.saveOptions();
			});

			// Export options
			$(document).on('click', '#sf-export-options', function (e) {
				e.preventDefault();
				ThemeOptions.exportOptions();
			});

			// Import options
			$(document).on('click', '#sf-import-options', function (e) {
				e.preventDefault();
				$('#sf-import-file').click();
			});

			// Handle file input change
			$(document).on('change', '#sf-import-file', function (e) {
				ThemeOptions.importOptions(e);
			});

			// Reset options
			$(document).on('click', '#sf-reset-options', function (e) {
				e.preventDefault();
				if (confirm(sfThemeOptions.confirmText || 'Are you sure? This will reset all options to defaults.')) {
					ThemeOptions.resetOptions();
				}
			});

			// Update range slider value display
			$(document).on('input change', '.sf-range-slider', function () {
				ThemeOptions.updateSliderValue($(this));
			});

			// Media uploader
			$(document).on('click', '.sf-media-upload-btn', function (e) {
				e.preventDefault();
				var targetInput = $(this).data('target');
				ThemeOptions.mediaUploader(targetInput);
			});
		},

		initColorPickers: function () {
			if ($.fn.wpColorPicker) {
				$('.sf-color-picker').wpColorPicker();
			}
		},

		updateSliderValues: function () {
			$('.sf-range-slider').each(function () {
				ThemeOptions.updateSliderValue($(this));
			});
		},

		updateSliderValue: function ($slider) {
			var value = $slider.val();
			var $display = $slider.closest('.sf-option-group').find('.sf-value-display');

			if ($slider.attr('id').includes('zoom') || $slider.attr('id').includes('percentage')) {
				$display.text(value + '%');
			} else if ($slider.attr('id').includes('line')) {
				$display.text(value);
			} else {
				$display.text(value);
			}
		},

		saveOptions: function () {
			var data = {};
			var $form = $('#sf-theme-options-form');

			// Collect all form data
			$form.find('input, select, textarea').each(function () {
				var $input = $(this);
				var name = $input.attr('name');

				if (!name) return;

				if ($input.attr('type') === 'checkbox') {
					data[name] = $input.is(':checked') ? 1 : 0;
				} else {
					data[name] = $input.val();
				}
			});

			// Show loading state
			var $button = $('#sf-save-options');
			var originalText = $button.text();
			$button.prop('disabled', true).text('Saving...');

			$.ajax({
				url: sfThemeOptions.ajaxUrl,
				type: 'POST',
				data: {
					action: 'sf_save_options',
					nonce: sfThemeOptions.nonce,
					data: data,
				},
				success: function (response) {
					if (response.success) {
						ThemeOptions.showMessage('success', response.data.message || 'Settings saved successfully!');
					} else {
						ThemeOptions.showMessage('error', response.data.message || 'Error saving settings');
					}
				},
				error: function () {
					ThemeOptions.showMessage('error', 'An error occurred while saving');
				},
				complete: function () {
					$button.prop('disabled', false).text(originalText);
				},
			});
		},

		exportOptions: function () {
			$.ajax({
				url: sfThemeOptions.ajaxUrl,
				type: 'POST',
				data: {
					action: 'sf_export_options',
					nonce: sfThemeOptions.nonce,
				},
				success: function (response) {
					if (response.success) {
						var dataStr = JSON.stringify(response.data.data, null, 2);
						var dataBlob = new Blob([dataStr], { type: 'application/json' });
						var url = URL.createObjectURL(dataBlob);
						var link = document.createElement('a');
						link.href = url;
						link.download = 'starter-flavor-options-' + new Date().getTime() + '.json';
						link.click();
						URL.revokeObjectURL(url);

						ThemeOptions.showMessage('success', 'Options exported successfully!');
					}
				},
				error: function () {
					ThemeOptions.showMessage('error', 'Error exporting options');
				},
			});
		},

		importOptions: function (e) {
			var file = e.target.files[0];
			if (!file) return;

			var reader = new FileReader();
			reader.onload = function (event) {
				try {
					var data = JSON.parse(event.target.result);
					ThemeOptions.importData(data);
				} catch (error) {
					ThemeOptions.showMessage('error', 'Invalid JSON file');
				}
			};
			reader.readAsText(file);

			// Reset file input
			$(e.target).val('');
		},

		importData: function (data) {
			$.ajax({
				url: sfThemeOptions.ajaxUrl,
				type: 'POST',
				data: {
					action: 'sf_import_options',
					nonce: sfThemeOptions.nonce,
					data: JSON.stringify(data),
				},
				success: function (response) {
					if (response.success) {
						ThemeOptions.showMessage('success', response.data.message || 'Settings imported successfully!');
						setTimeout(function () {
							location.reload();
						}, 1500);
					} else {
						ThemeOptions.showMessage('error', response.data.message || 'Error importing settings');
					}
				},
				error: function () {
					ThemeOptions.showMessage('error', 'Error importing options');
				},
			});
		},

		resetOptions: function () {
			var $button = $('#sf-reset-options');
			var originalText = $button.text();
			$button.prop('disabled', true).text('Resetting...');

			$.ajax({
				url: sfThemeOptions.ajaxUrl,
				type: 'POST',
				data: {
					action: 'sf_reset_options',
					nonce: sfThemeOptions.nonce,
				},
				success: function (response) {
					if (response.success) {
						ThemeOptions.showMessage('success', response.data.message || 'Settings reset to defaults');
						setTimeout(function () {
							location.reload();
						}, 1500);
					} else {
						ThemeOptions.showMessage('error', response.data.message || 'Error resetting settings');
					}
				},
				error: function () {
					ThemeOptions.showMessage('error', 'Error resetting options');
				},
				complete: function () {
					$button.prop('disabled', false).text(originalText);
				},
			});
		},

		showMessage: function (type, message) {
			var $message = $('#sf-options-message');
			$message
				.removeClass('success error')
				.addClass(type)
				.text(message)
				.stop(true, true)
				.fadeIn()
				.delay(5000)
				.fadeOut();
		},

		mediaUploader: function (targetInput) {
			var frame = wp.media({
				title: 'Select Image',
				button: {
					text: 'Use Image',
				},
				multiple: false,
			});

			frame.on('select', function () {
				var attachment = frame.state().get('selection').first().toJSON();
				$('#' + targetInput).val(attachment.url).trigger('change');

				// Update preview
				var $preview = $('#' + targetInput)
					.closest('.sf-media-uploader')
					.find('.sf-preview-image');

				if ($preview.length) {
					$preview.attr('src', attachment.url);
				} else {
					$('<img />', {
						class: 'sf-preview-image',
						src: attachment.url,
						alt: 'Preview',
					}).insertAfter('#' + targetInput);
				}
			});

			frame.open();
		},
	};

	// Initialize when document is ready
	$(document).ready(function () {
		ThemeOptions.init();
	});
})(jQuery);
