<?php
/**
 * The header for ThemeFlex theme
 *
 * Features:
 * - Sticky Header Support
 * - Dark Mode Toggle Button
 * - Mobile Navigation
 * - Responsive Design
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

/* ── Open Graph / Twitter Card meta tags ────────────────────────── */
function themeflex_output_og_tags() {
	global $post;

	$site_name   = get_bloginfo( 'name' );
	$og_url      = esc_url( ( is_ssl() ? 'https' : 'http' ) . '://' . sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ?? '' ) ) . sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ) ) );
	$og_type     = ( is_singular() && ! is_front_page() ) ? 'article' : 'website';
	$og_title    = wp_get_document_title();
	$og_desc     = '';
	$og_image    = '';

	if ( is_singular() && ! empty( $post ) ) {
		$og_desc = wp_trim_words( wp_strip_all_tags( get_the_excerpt( $post ) ?: get_the_content( null, false, $post ) ), 30, '…' );
		if ( has_post_thumbnail( $post ) ) {
			$img = wp_get_attachment_image_src( get_post_thumbnail_id( $post ), 'large' );
			if ( $img ) $og_image = esc_url( $img[0] );
		}
	} elseif ( is_front_page() ) {
		$og_desc = esc_html( get_bloginfo( 'description' ) );
	}

	if ( ! $og_image ) {
		// Fallback to screenshot
		$og_image = esc_url( get_template_directory_uri() . '/screenshot.png' );
	}
	if ( ! $og_desc ) {
		$og_desc = esc_html( get_bloginfo( 'description' ) );
	}

	?>
	<!-- Open Graph -->
	<meta property="og:type"        content="<?php echo esc_attr( $og_type ); ?>">
	<meta property="og:title"       content="<?php echo esc_attr( $og_title ); ?>">
	<meta property="og:description" content="<?php echo esc_attr( $og_desc ); ?>">
	<meta property="og:url"         content="<?php echo esc_url( $og_url ); ?>">
	<meta property="og:site_name"   content="<?php echo esc_attr( $site_name ); ?>">
	<meta property="og:image"       content="<?php echo esc_url( $og_image ); ?>">
	<meta property="og:image:width" content="1200">
	<meta property="og:image:height" content="628">
	<!-- Twitter Card -->
	<meta name="twitter:card"        content="summary_large_image">
	<meta name="twitter:title"       content="<?php echo esc_attr( $og_title ); ?>">
	<meta name="twitter:description" content="<?php echo esc_attr( $og_desc ); ?>">
	<meta name="twitter:image"       content="<?php echo esc_url( $og_image ); ?>">
	<?php
}
add_action( 'wp_head', 'themeflex_output_og_tags', 1 );
?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="<?php echo esc_attr( apply_filters( 'themeflex_html_classes', '' ) ); ?>">
<head>
	<meta charset="<?php echo esc_attr( get_bloginfo( 'charset' ) ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- WCAG 2.1: Support for high contrast mode and color scheme preference -->
	<meta name="color-scheme" content="light dark">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<?php
	wp_body_open();
	get_template_part( 'template-parts/preloader' );
	?>
	<!-- Dark-first FOUC prevention: apply saved or default dark mode before first paint -->
	<script>
	(function(){
	  try {
	    var saved = localStorage.getItem('sfTheme') || 'dark';
	    if (saved === 'dark') {
	      document.documentElement.setAttribute('data-theme', 'dark');
	      document.documentElement.style.setProperty('background-color', '#06021d');
	    }
	  } catch(e){}
	})();
	</script>
	<style>
	/* ── Dark-first body defaults — override critical-inline.css white bg ── */
	html,body{background-color:#06021d!important;color:#94a3b8}
	/* These vars are read by all template <style> blocks */
	:root{
	  --tf-primary:#ff5e2e;--tf-accent:#00d4ff;
	  --tf-bg:#06021d;--tf-surface:#111827;
	  --tf-border:rgba(255,255,255,.07);
	  --tf-title:#f1f5f9;--tf-text:#94a3b8;--tf-meta:#64748b;
	  --sf-color-primary:#ff5e2e;
	}
	/* Header dark styling */
	.site-header{
	  background:rgba(6,2,29,.92)!important;
	  border-bottom:1px solid rgba(255,255,255,.07)!important;
	  backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);
	}
	.site-title a,.site-title a:hover{color:#f1f5f9!important;text-decoration:none}
	.site-description{color:#64748b!important}
	.main-navigation a,.main-navigation .menu-item a{color:#94a3b8!important;transition:color .2s}
	.main-navigation a:hover,.main-navigation .current-menu-item>a{color:#ff5e2e!important}
	.menu-toggle{color:#94a3b8!important;background:transparent!important;border:1px solid rgba(255,255,255,.1)!important}
	.dark-mode-toggle{color:#94a3b8!important;background:rgba(255,255,255,.06)!important;border:1px solid rgba(255,255,255,.08)!important;border-radius:8px!important}
	.dark-mode-toggle:hover{background:rgba(255,94,46,.1)!important;border-color:rgba(255,94,46,.3)!important;color:#ff5e2e!important}
	</style>

	<div class="body_wrap">
		<div class="page_wrap">
			<?php
			/**
			 * Action hook before header
			 *
			 * @since 1.0.0
			 */
			do_action( 'themeflex_before_header' );
			?>

			<header id="site-header" class="site-header<?php echo themeflex_get_header_layout() === 'centered' ? ' header-centered' : ''; ?><?php echo themeflex_get_header_layout() === 'transparent' ? ' header-transparent' : ''; ?>" role="banner">
				<div class="header-content">
					<div class="header-inner">
						<div class="header-left">
							<?php
							/**
							 * Action hook for header branding
							 *
							 * @since 1.0.0
							 */
							do_action( 'themeflex_header_branding' );

							// Display Logo
							if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
								the_custom_logo();
							} else {
								?>
								<h1 class="site-title">
									<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
										<?php echo esc_html( get_bloginfo( 'name' ) ); ?>
									</a>
								</h1>
								<?php
								$site_description = get_bloginfo( 'description' );
								if ( $site_description ) {
									?>
									<p class="site-description">
										<?php echo esc_html( $site_description ); ?>
									</p>
									<?php
								}
							}
							?>
						</div>

						<nav id="site-navigation" class="site-navigation main-navigation" role="navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'themeflex' ); ?>">
							<button class="menu-toggle" id="menu-toggle" aria-controls="primary-menu" aria-expanded="false" aria-haspopup="true">
								<span class="menu-toggle-text"><?php esc_html_e( 'Menu', 'themeflex' ); ?></span>
								<span class="menu-toggle-icon">
									<span></span>
									<span></span>
									<span></span>
								</span>
							</button>

							<?php
							$menu_args = array(
								'theme_location' => 'main-menu',
								'menu_id'        => 'primary-menu',
								'container'      => false,
								'fallback_cb'    => 'wp_page_menu',
								'depth'          => 3,
							);
							if ( class_exists( 'Starter_Flavor_Nav_Menu_Walker' ) ) {
								$menu_args['walker'] = new Starter_Flavor_Nav_Menu_Walker();
							}
							wp_nav_menu( $menu_args );
							?>
						</nav>

						<div class="header-right">
							<?php
							// Dark Mode Toggle
							if ( themeflex_get_theme_option( 'enable_dark_mode' ) ) {
								?>
								<button class="dark-mode-toggle" id="dark-mode-toggle" aria-label="<?php esc_attr_e( 'Toggle dark mode', 'themeflex' ); ?>">
									<span class="dark-mode-icon">
										<svg class="light-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
											<circle cx="12" cy="12" r="5"></circle>
											<line x1="12" y1="1" x2="12" y2="3"></line>
											<line x1="12" y1="21" x2="12" y2="23"></line>
											<line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
											<line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
											<line x1="1" y1="12" x2="3" y2="12"></line>
											<line x1="21" y1="12" x2="23" y2="12"></line>
											<line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
											<line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
										</svg>
										<svg class="dark-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
											<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
										</svg>
									</span>
								</button>
								<?php
							}

							/**
							 * Action hook for header right content
							 *
							 * @since 1.0.0
							 */
							do_action( 'themeflex_header_right' );
							?>
						</div>
					</div>
				</div>
			</header>

			<?php
			/**
			 * Action hook after header
			 *
			 * @since 1.0.0
			 */
			do_action( 'themeflex_after_header' );
			?>

			<a class="skip-link screen-reader-text" href="#site-content">
				<?php esc_html_e( 'Skip to content', 'themeflex' ); ?>
			</a>

			<div class="page_content_wrap">
				<div class="content_wrap">
					<main id="site-content" class="site-content content" role="main">
						<?php
						/**
						 * Action hook before main content
						 *
						 * @since 1.0.0
						 */
						do_action( 'themeflex_before_content' );
						?>
