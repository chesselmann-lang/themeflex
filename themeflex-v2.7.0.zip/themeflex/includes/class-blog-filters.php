<?php
/**
 * Blog Filters Class
 *
 * AJAX-based blog filtering with URL state management.
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ThemeFlex_Blog_Filters class
 */
class ThemeFlex_Blog_Filters {

	/**
	 * Instance variable
	 *
	 * @var ThemeFlex_Blog_Filters
	 */
	private static $instance = null;

	/**
	 * Get instance
	 *
	 * @return ThemeFlex_Blog_Filters
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'rest_api_init', array( $this, 'register_rest_endpoint' ) );
		add_action( 'customize_register', array( $this, 'register_customizer_settings' ) );
	}

	/**
	 * Enqueue assets
	 */
	public function enqueue_assets() {
		if ( is_home() || is_archive() ) {
			wp_enqueue_script(
				'themeflex-blog-filters',
				get_template_directory_uri() . '/assets/js/blog-filters.js',
				array( 'wp-api-fetch' ),
				THEMEFLEX_VERSION,
				true
			);

			wp_localize_script(
				'themeflex-blog-filters',
				'starterFlavorFilters',
				array(
					'nonce'    => wp_create_nonce( 'wp_rest' ),
					'rest_url' => rest_url( '/themeflex/v1/posts' ),
				)
			);

			wp_enqueue_style(
				'themeflex-blog-filters',
				get_template_directory_uri() . '/assets/css/blog-filters.css',
				array(),
				THEMEFLEX_VERSION
			);
		}
	}

	/**
	 * Register REST API endpoint
	 */
	public function register_rest_endpoint() {
		register_rest_route(
			'themeflex/v1',
			'/posts',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_filtered_posts' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'category' => array(
						'type' => 'string',
					),
					'tags'     => array(
						'type' => 'string',
					),
					'sort'     => array(
						'type' => 'string',
					),
					'paged'    => array(
						'type' => 'integer',
					),
				),
			)
		);
	}

	/**
	 * Get filtered posts
	 *
	 * @param WP_REST_Request $request The REST request object.
	 * @return WP_REST_Response
	 */
	public function get_filtered_posts( $request ) {
		$category = $request->get_param( 'category' );
		$tags = $request->get_param( 'tags' );
		$sort = $request->get_param( 'sort' );
		$paged = $request->get_param( 'paged' ) ? intval( $request->get_param( 'paged' ) ) : 1;

		$args = array(
			'post_type'      => 'post',
			'posts_per_page' => get_option( 'posts_per_page' ),
			'paged'          => $paged,
			'post_status'    => 'publish',
		);

		// Handle sorting
		if ( ! empty( $sort ) ) {
			switch ( $sort ) {
				case 'title':
					$args['orderby'] = 'title';
					$args['order']   = 'ASC';
					break;
				case 'comments':
					$args['orderby'] = 'comment_count';
					$args['order']   = 'DESC';
					break;
				case 'views':
					// This requires a meta field for post views
					$args['meta_key'] = '_post_views_count'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query
					$args['orderby']  = 'meta_value_num';
					$args['order']    = 'DESC';
					break;
				case 'date':
				default:
					$args['orderby'] = 'date';
					$args['order']   = 'DESC';
					break;
			}
		} else {
			$args['orderby'] = 'date';
			$args['order']   = 'DESC';
		}

		// Handle category filter
		if ( ! empty( $category ) ) {
			$args['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query
				array(
					'taxonomy' => 'category',
					'field'    => 'slug',
					'terms'    => array_map( 'sanitize_text_field', explode( ',', $category ) ),
				),
			);
		}

		// Handle tag filter
		if ( ! empty( $tags ) ) {
			$tag_query = array(
				'taxonomy' => 'post_tag',
				'field'    => 'slug',
				'terms'    => array_map( 'sanitize_text_field', explode( ',', $tags ) ),
			);

			if ( ! isset( $args['tax_query'] ) ) {
				$args['tax_query'] = array( $tag_query ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query
			} else {
				$args['tax_query'][] = $tag_query;
				$args['tax_query']['relation'] = 'AND';
			}
		}

		$query = new WP_Query( $args );

		$posts = array();
		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();

				$post_data = array(
					'id'        => get_the_ID(),
					'title'     => get_the_title(),
					'excerpt'   => get_the_excerpt(),
					'permalink' => get_the_permalink(),
					'date'      => get_the_date(),
					'author'    => get_the_author(),
					'categories' => wp_get_post_categories( get_the_ID(), array( 'fields' => 'names' ) ),
				);

				if ( has_post_thumbnail() ) {
					$post_data['thumbnail'] = get_the_post_thumbnail_url();
				}

				$posts[] = $post_data;
			}
		}

		wp_reset_postdata();

		return rest_ensure_response( array(
			'posts'       => $posts,
			'total'       => (int) $query->found_posts,
			'pages'       => (int) $query->max_num_pages,
			'current'     => $paged,
			'per_page'    => get_option( 'posts_per_page' ),
		) );
	}

	/**
	 * Get filter options
	 *
	 * @return array
	 */
	public function get_filter_options() {
		return array(
			'categories' => get_categories( array(
				'hide_empty' => true,
			) ),
			'sort_options' => array(
				'date'     => esc_html__( 'Newest First', 'themeflex' ),
				'title'    => esc_html__( 'Title (A-Z)', 'themeflex' ),
				'comments' => esc_html__( 'Most Comments', 'themeflex' ),
				'views'    => esc_html__( 'Most Views', 'themeflex' ),
			),
		);
	}

	/**
	 * Register customizer settings
	 *
	 * @param WP_Customize_Manager $wp_customize The customizer object.
	 */
	public function register_customizer_settings( $wp_customize ) {
		// Blog Filters Panel
		$wp_customize->add_panel(
			'themeflex_blog_filters',
			array(
				'title'       => esc_html__( 'Blog Filters', 'themeflex' ),
				'description' => esc_html__( 'Configure blog filtering options', 'themeflex' ),
				'priority'    => 95,
			)
		);

		// Enable/Disable
		$wp_customize->add_setting(
			'themeflex_blog_filters_enabled',
			array(
				'default'           => true,
				'sanitize_callback' => 'rest_sanitize_boolean',
				'transport'         => 'refresh',
			)
		);

		$wp_customize->add_control(
			'themeflex_blog_filters_enabled',
			array(
				'type'     => 'checkbox',
				'section'  => 'themeflex_blog_filters',
				'label'    => esc_html__( 'Enable Blog Filters', 'themeflex' ),
				'priority' => 10,
			)
		);

		// Show categories
		$wp_customize->add_setting(
			'themeflex_blog_filters_categories',
			array(
				'default'           => true,
				'sanitize_callback' => 'rest_sanitize_boolean',
				'transport'         => 'refresh',
			)
		);

		$wp_customize->add_control(
			'themeflex_blog_filters_categories',
			array(
				'type'     => 'checkbox',
				'section'  => 'themeflex_blog_filters',
				'label'    => esc_html__( 'Show Category Filter', 'themeflex' ),
				'priority' => 20,
			)
		);

		// Show tags
		$wp_customize->add_setting(
			'themeflex_blog_filters_tags',
			array(
				'default'           => true,
				'sanitize_callback' => 'rest_sanitize_boolean',
				'transport'         => 'refresh',
			)
		);

		$wp_customize->add_control(
			'themeflex_blog_filters_tags',
			array(
				'type'     => 'checkbox',
				'section'  => 'themeflex_blog_filters',
				'label'    => esc_html__( 'Show Tag Filter', 'themeflex' ),
				'priority' => 30,
			)
		);

		// Show sort
		$wp_customize->add_setting(
			'themeflex_blog_filters_sort',
			array(
				'default'           => true,
				'sanitize_callback' => 'rest_sanitize_boolean',
				'transport'         => 'refresh',
			)
		);

		$wp_customize->add_control(
			'themeflex_blog_filters_sort',
			array(
				'type'     => 'checkbox',
				'section'  => 'themeflex_blog_filters',
				'label'    => esc_html__( 'Show Sort Options', 'themeflex' ),
				'priority' => 40,
			)
		);
	}

	/**
	 * Get blog filters settings
	 *
	 * @return array
	 */
	public function get_settings() {
		return array(
			'enabled'     => get_theme_mod( 'themeflex_blog_filters_enabled', true ),
			'categories'  => get_theme_mod( 'themeflex_blog_filters_categories', true ),
			'tags'        => get_theme_mod( 'themeflex_blog_filters_tags', true ),
			'sort'        => get_theme_mod( 'themeflex_blog_filters_sort', true ),
		);
	}
}

// Initialize
if ( ! function_exists( 'themeflex_blog_filters' ) ) {
	/**
	 * Get blog filters instance
	 *
	 * @return ThemeFlex_Blog_Filters
	 */
	function themeflex_blog_filters() {
		return ThemeFlex_Blog_Filters::get_instance();
	}
}

themeflex_blog_filters();
