<?php
/**
 * Demo Content Importer
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ThemeFlex_Demo_Importer {

	/**
	 * Demo categories
	 *
	 * @var array
	 */
	private static $categories = array(
		'ai-technology' => 'AI & Technology',
		'business-finance' => 'Business & Finance',
		'health-wellness' => 'Health & Wellness',
		'services' => 'Services',
		'lifestyle-food' => 'Lifestyle & Food',
		'creative-design' => 'Creative & Design',
		'education-community' => 'Education & Community',
		'retail-shopping' => 'Retail & Shopping',
		'property-construction' => 'Property & Construction',
		'sports-entertainment' => 'Sports & Entertainment',
		'travel-events' => 'Travel & Events',
		'personal-professional' => 'Personal & Professional',
	);

	/**
	 * Demo templates database
	 *
	 * @var array
	 */
	private static $demos = array();

	/**
	 * Initialize static demos on first call
	 */
	private static function init_demos() {
		if ( ! empty( self::$demos ) ) {
			return;
		}

		self::$demos = self::build_demos_database();
	}

	/**
	 * Build the complete demos database from template files
	 *
	 * @return array
	 */
	private static function build_demos_database() {
		return array(
			// AI & Technology
			'ai-agent' => array(
				'title' => 'AI Agent',
				'category' => 'ai-technology',
				'template_file' => 'demo-ai-agent-home.json',
				'thumbnail' => 'ai-agent.jpg',
				'colors' => array( 'primary' => '#6366f1', 'secondary' => '#8b5cf6' ),
			),
			'ai-app' => array(
				'title' => 'AI App',
				'category' => 'ai-technology',
				'template_file' => 'demo-ai-app-home.json',
				'thumbnail' => 'ai-app.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#0ea5e9' ),
			),
			'ai-assistant' => array(
				'title' => 'AI Assistant',
				'category' => 'ai-technology',
				'template_file' => 'demo-ai-assistant-home.json',
				'thumbnail' => 'ai-assistant.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),
			'ai-chatbot' => array(
				'title' => 'AI Chatbot',
				'category' => 'ai-technology',
				'template_file' => 'demo-ai-chatbot-home.json',
				'thumbnail' => 'ai-chatbot.jpg',
				'colors' => array( 'primary' => '#06b6d4', 'secondary' => '#22d3ee' ),
			),
			'ai-courses' => array(
				'title' => 'AI Courses',
				'category' => 'ai-technology',
				'template_file' => 'demo-ai-courses-home.json',
				'thumbnail' => 'ai-courses.jpg',
				'colors' => array( 'primary' => '#f59e0b', 'secondary' => '#fbbf24' ),
			),
			'ai-image-generator' => array(
				'title' => 'AI Image Generator',
				'category' => 'ai-technology',
				'template_file' => 'demo-ai-image-generator-home.json',
				'thumbnail' => 'ai-image-generator.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'ai-music' => array(
				'title' => 'AI Music',
				'category' => 'ai-technology',
				'template_file' => 'demo-ai-music-home.json',
				'thumbnail' => 'ai-music.jpg',
				'colors' => array( 'primary' => '#d946ef', 'secondary' => '#e879f9' ),
			),
			'ai-product' => array(
				'title' => 'AI Product',
				'category' => 'ai-technology',
				'template_file' => 'demo-ai-product-home.json',
				'thumbnail' => 'ai-product.jpg',
				'colors' => array( 'primary' => '#10b981', 'secondary' => '#34d399' ),
			),
			'ai-saas' => array(
				'title' => 'AI SaaS',
				'category' => 'ai-technology',
				'template_file' => 'demo-ai-saas-home.json',
				'thumbnail' => 'ai-saas.jpg',
				'colors' => array( 'primary' => '#6366f1', 'secondary' => '#818cf8' ),
			),
			'ai-service' => array(
				'title' => 'AI Service',
				'category' => 'ai-technology',
				'template_file' => 'demo-ai-service-home.json',
				'thumbnail' => 'ai-service.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'ai-startup' => array(
				'title' => 'AI Startup',
				'category' => 'ai-technology',
				'template_file' => 'demo-ai-startup-home.json',
				'thumbnail' => 'ai-startup.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),
			'ai-text-generator' => array(
				'title' => 'AI Text Generator',
				'category' => 'ai-technology',
				'template_file' => 'demo-ai-text-generator-home.json',
				'thumbnail' => 'ai-text-generator.jpg',
				'colors' => array( 'primary' => '#06b6d4', 'secondary' => '#22d3ee' ),
			),
			'ai-tool' => array(
				'title' => 'AI Tool',
				'category' => 'ai-technology',
				'template_file' => 'demo-ai-tool-home.json',
				'thumbnail' => 'ai-tool.jpg',
				'colors' => array( 'primary' => '#f59e0b', 'secondary' => '#fbbf24' ),
			),
			'ai-video' => array(
				'title' => 'AI Video',
				'category' => 'ai-technology',
				'template_file' => 'demo-ai-video-home.json',
				'thumbnail' => 'ai-video.jpg',
				'colors' => array( 'primary' => '#ef4444', 'secondary' => '#f87171' ),
			),
			'blockchain' => array(
				'title' => 'Blockchain',
				'category' => 'ai-technology',
				'template_file' => 'demo-blockchain-home.json',
				'thumbnail' => 'blockchain.jpg',
				'colors' => array( 'primary' => '#f59e0b', 'secondary' => '#fbbf24' ),
			),
			'cloud-hosting' => array(
				'title' => 'Cloud Hosting',
				'category' => 'ai-technology',
				'template_file' => 'demo-cloud-hosting-home.json',
				'thumbnail' => 'cloud-hosting.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'crm-platform' => array(
				'title' => 'CRM Platform',
				'category' => 'ai-technology',
				'template_file' => 'demo-crm-platform-home.json',
				'thumbnail' => 'crm-platform.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),
			'cyber-protection' => array(
				'title' => 'Cyber Protection',
				'category' => 'ai-technology',
				'template_file' => 'demo-cyber-protection-home.json',
				'thumbnail' => 'cyber-protection.jpg',
				'colors' => array( 'primary' => '#ef4444', 'secondary' => '#f87171' ),
			),
			'cybersecurity' => array(
				'title' => 'Cybersecurity',
				'category' => 'ai-technology',
				'template_file' => 'demo-cybersecurity-home.json',
				'thumbnail' => 'cybersecurity.jpg',
				'colors' => array( 'primary' => '#6366f1', 'secondary' => '#818cf8' ),
			),
			'engineering' => array(
				'title' => 'Engineering',
				'category' => 'ai-technology',
				'template_file' => 'demo-engineering-home.json',
				'thumbnail' => 'engineering.jpg',
				'colors' => array( 'primary' => '#10b981', 'secondary' => '#34d399' ),
			),
			'it-company' => array(
				'title' => 'IT Company',
				'category' => 'ai-technology',
				'template_file' => 'demo-it-company-home.json',
				'thumbnail' => 'it-company.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'mobile-app' => array(
				'title' => 'Mobile App',
				'category' => 'ai-technology',
				'template_file' => 'demo-mobile-app-home.json',
				'thumbnail' => 'mobile-app.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),
			'science' => array(
				'title' => 'Science',
				'category' => 'ai-technology',
				'template_file' => 'demo-science-home.json',
				'thumbnail' => 'science.jpg',
				'colors' => array( 'primary' => '#06b6d4', 'secondary' => '#22d3ee' ),
			),
			'smart-tech' => array(
				'title' => 'Smart Tech',
				'category' => 'ai-technology',
				'template_file' => 'demo-smart-tech-home.json',
				'thumbnail' => 'smart-tech.jpg',
				'colors' => array( 'primary' => '#f59e0b', 'secondary' => '#fbbf24' ),
			),
			'technology' => array(
				'title' => 'Technology',
				'category' => 'ai-technology',
				'template_file' => 'demo-technology-home.json',
				'thumbnail' => 'technology.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),

			// Business & Finance
			'accountant' => array(
				'title' => 'Accountant',
				'category' => 'business-finance',
				'template_file' => 'demo-accountant-home.json',
				'thumbnail' => 'accountant.jpg',
				'colors' => array( 'primary' => '#1e40af', 'secondary' => '#3b82f6' ),
			),
			'advisory-firm' => array(
				'title' => 'Advisory Firm',
				'category' => 'business-finance',
				'template_file' => 'demo-advisory-firm-home.json',
				'thumbnail' => 'advisory-firm.jpg',
				'colors' => array( 'primary' => '#1e40af', 'secondary' => '#3b82f6' ),
			),
			'business-agency' => array(
				'title' => 'Business Agency',
				'category' => 'business-finance',
				'template_file' => 'demo-business-agency-home.json',
				'thumbnail' => 'business-agency.jpg',
				'colors' => array( 'primary' => '#64748b', 'secondary' => '#94a3b8' ),
			),
			'business-app' => array(
				'title' => 'Business App',
				'category' => 'business-finance',
				'template_file' => 'demo-business-app-home.json',
				'thumbnail' => 'business-app.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'consulting-firm' => array(
				'title' => 'Consulting Firm',
				'category' => 'business-finance',
				'template_file' => 'demo-consulting-firm-home.json',
				'thumbnail' => 'consulting-firm.jpg',
				'colors' => array( 'primary' => '#1e3a8a', 'secondary' => '#1e40af' ),
			),
			'consulting-home' => array(
				'title' => 'Consulting',
				'category' => 'business-finance',
				'template_file' => 'demo-consulting-home.json',
				'thumbnail' => 'consulting.jpg',
				'colors' => array( 'primary' => '#1e40af', 'secondary' => '#3b82f6' ),
			),
			'consulting-services' => array(
				'title' => 'Consulting Services',
				'category' => 'business-finance',
				'template_file' => 'demo-consulting-services.json',
				'thumbnail' => 'consulting-services.jpg',
				'colors' => array( 'primary' => '#1e40af', 'secondary' => '#3b82f6' ),
			),
			'consulting-studio' => array(
				'title' => 'Consulting Studio',
				'category' => 'business-finance',
				'template_file' => 'demo-consulting-studio-home.json',
				'thumbnail' => 'consulting-studio.jpg',
				'colors' => array( 'primary' => '#1e40af', 'secondary' => '#3b82f6' ),
			),
			'corporate' => array(
				'title' => 'Corporate',
				'category' => 'business-finance',
				'template_file' => 'demo-corporate-home.json',
				'thumbnail' => 'corporate.jpg',
				'colors' => array( 'primary' => '#1e3a8a', 'secondary' => '#1e40af' ),
			),
			'finance-consulting' => array(
				'title' => 'Finance Consulting',
				'category' => 'business-finance',
				'template_file' => 'demo-finance-consulting-home.json',
				'thumbnail' => 'finance-consulting.jpg',
				'colors' => array( 'primary' => '#059669', 'secondary' => '#10b981' ),
			),
			'finance' => array(
				'title' => 'Finance',
				'category' => 'business-finance',
				'template_file' => 'demo-finance-home.json',
				'thumbnail' => 'finance.jpg',
				'colors' => array( 'primary' => '#10b981', 'secondary' => '#34d399' ),
			),
			'fintech' => array(
				'title' => 'Fintech',
				'category' => 'business-finance',
				'template_file' => 'demo-fintech-home.json',
				'thumbnail' => 'fintech.jpg',
				'colors' => array( 'primary' => '#f59e0b', 'secondary' => '#fbbf24' ),
			),
			'insurance' => array(
				'title' => 'Insurance',
				'category' => 'business-finance',
				'template_file' => 'demo-insurance-home.json',
				'thumbnail' => 'insurance.jpg',
				'colors' => array( 'primary' => '#dc2626', 'secondary' => '#ef4444' ),
			),
			'investment-consulting' => array(
				'title' => 'Investment Consulting',
				'category' => 'business-finance',
				'template_file' => 'demo-investment-consulting-home.json',
				'thumbnail' => 'investment-consulting.jpg',
				'colors' => array( 'primary' => '#059669', 'secondary' => '#10b981' ),
			),
			'investment-firm' => array(
				'title' => 'Investment Firm',
				'category' => 'business-finance',
				'template_file' => 'demo-investment-firm-home.json',
				'thumbnail' => 'investment-firm.jpg',
				'colors' => array( 'primary' => '#1e40af', 'secondary' => '#3b82f6' ),
			),
			'marketing' => array(
				'title' => 'Marketing',
				'category' => 'business-finance',
				'template_file' => 'demo-marketing-home.json',
				'thumbnail' => 'marketing.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'marketing2' => array(
				'title' => 'Marketing 2',
				'category' => 'business-finance',
				'template_file' => 'demo-marketing-home2.json',
				'thumbnail' => 'marketing2.jpg',
				'colors' => array( 'primary' => '#d946ef', 'secondary' => '#e879f9' ),
			),
			'modern-marketing' => array(
				'title' => 'Modern Marketing',
				'category' => 'business-finance',
				'template_file' => 'demo-modern-marketing-home.json',
				'thumbnail' => 'modern-marketing.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'startup' => array(
				'title' => 'Startup',
				'category' => 'business-finance',
				'template_file' => 'demo-startup-home.json',
				'thumbnail' => 'startup.jpg',
				'colors' => array( 'primary' => '#f59e0b', 'secondary' => '#fbbf24' ),
			),

			// Health & Wellness
			'counseling' => array(
				'title' => 'Counseling',
				'category' => 'health-wellness',
				'template_file' => 'demo-counseling-home.json',
				'thumbnail' => 'counseling.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),
			'dental-clinic' => array(
				'title' => 'Dental Clinic',
				'category' => 'health-wellness',
				'template_file' => 'demo-dental-clinic-home.json',
				'thumbnail' => 'dental-clinic.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'dentist' => array(
				'title' => 'Dentist',
				'category' => 'health-wellness',
				'template_file' => 'demo-dentist-home.json',
				'thumbnail' => 'dentist.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'elderly-care' => array(
				'title' => 'Elderly Care',
				'category' => 'health-wellness',
				'template_file' => 'demo-elderly-care-home.json',
				'thumbnail' => 'elderly-care.jpg',
				'colors' => array( 'primary' => '#06b6d4', 'secondary' => '#22d3ee' ),
			),
			'fitness' => array(
				'title' => 'Fitness',
				'category' => 'health-wellness',
				'template_file' => 'demo-fitness-home.json',
				'thumbnail' => 'fitness.jpg',
				'colors' => array( 'primary' => '#ef4444', 'secondary' => '#f87171' ),
			),
			'hospital' => array(
				'title' => 'Hospital',
				'category' => 'health-wellness',
				'template_file' => 'demo-hospital-home.json',
				'thumbnail' => 'hospital.jpg',
				'colors' => array( 'primary' => '#ef4444', 'secondary' => '#f87171' ),
			),
			'massage' => array(
				'title' => 'Massage',
				'category' => 'health-wellness',
				'template_file' => 'demo-massage-home.json',
				'thumbnail' => 'massage.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'medical-center' => array(
				'title' => 'Medical Center',
				'category' => 'health-wellness',
				'template_file' => 'demo-medical-center-home.json',
				'thumbnail' => 'medical-center.jpg',
				'colors' => array( 'primary' => '#ef4444', 'secondary' => '#f87171' ),
			),
			'mental-health' => array(
				'title' => 'Mental Health',
				'category' => 'health-wellness',
				'template_file' => 'demo-mental-health-home.json',
				'thumbnail' => 'mental-health.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),
			'nutritionist' => array(
				'title' => 'Nutritionist',
				'category' => 'health-wellness',
				'template_file' => 'demo-nutritionist-home.json',
				'thumbnail' => 'nutritionist.jpg',
				'colors' => array( 'primary' => '#10b981', 'secondary' => '#34d399' ),
			),
			'pharmacy' => array(
				'title' => 'Pharmacy',
				'category' => 'health-wellness',
				'template_file' => 'demo-pharmacy-home.json',
				'thumbnail' => 'pharmacy.jpg',
				'colors' => array( 'primary' => '#06b6d4', 'secondary' => '#22d3ee' ),
			),
			'physiotherapy' => array(
				'title' => 'Physiotherapy',
				'category' => 'health-wellness',
				'template_file' => 'demo-physiotherapy-home.json',
				'thumbnail' => 'physiotherapy.jpg',
				'colors' => array( 'primary' => '#06b6d4', 'secondary' => '#22d3ee' ),
			),
			'private-clinic' => array(
				'title' => 'Private Clinic',
				'category' => 'health-wellness',
				'template_file' => 'demo-private-clinic-home.json',
				'thumbnail' => 'private-clinic.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'psychologist' => array(
				'title' => 'Psychologist',
				'category' => 'health-wellness',
				'template_file' => 'demo-psychologist-home.json',
				'thumbnail' => 'psychologist.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),
			'senior-care' => array(
				'title' => 'Senior Care',
				'category' => 'health-wellness',
				'template_file' => 'demo-senior-care-home.json',
				'thumbnail' => 'senior-care.jpg',
				'colors' => array( 'primary' => '#06b6d4', 'secondary' => '#22d3ee' ),
			),
			'skincare' => array(
				'title' => 'Skincare',
				'category' => 'health-wellness',
				'template_file' => 'demo-skincare-home.json',
				'thumbnail' => 'skincare.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'skincare-clinic' => array(
				'title' => 'Skincare Clinic',
				'category' => 'health-wellness',
				'template_file' => 'demo-skincare-clinic-home.json',
				'thumbnail' => 'skincare-clinic.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'spa-salon' => array(
				'title' => 'Spa & Salon',
				'category' => 'health-wellness',
				'template_file' => 'demo-spa-salon-home.json',
				'thumbnail' => 'spa-salon.jpg',
				'colors' => array( 'primary' => '#d946ef', 'secondary' => '#e879f9' ),
			),
			'spa-wellness' => array(
				'title' => 'Spa & Wellness',
				'category' => 'health-wellness',
				'template_file' => 'demo-spa-wellness-home.json',
				'thumbnail' => 'spa-wellness.jpg',
				'colors' => array( 'primary' => '#d946ef', 'secondary' => '#e879f9' ),
			),
			'yoga' => array(
				'title' => 'Yoga',
				'category' => 'health-wellness',
				'template_file' => 'demo-yoga-home.json',
				'thumbnail' => 'yoga.jpg',
				'colors' => array( 'primary' => '#10b981', 'secondary' => '#34d399' ),
			),

			// Services
			'auto-service' => array(
				'title' => 'Auto Service',
				'category' => 'services',
				'template_file' => 'demo-auto-service-home.json',
				'thumbnail' => 'auto-service.jpg',
				'colors' => array( 'primary' => '#6b7280', 'secondary' => '#9ca3af' ),
			),
			'cctv-security' => array(
				'title' => 'CCTV Security',
				'category' => 'services',
				'template_file' => 'demo-cctv-security-home.json',
				'thumbnail' => 'cctv-security.jpg',
				'colors' => array( 'primary' => '#1e40af', 'secondary' => '#3b82f6' ),
			),
			'cleaning' => array(
				'title' => 'Cleaning',
				'category' => 'services',
				'template_file' => 'demo-cleaning-home.json',
				'thumbnail' => 'cleaning.jpg',
				'colors' => array( 'primary' => '#06b6d4', 'secondary' => '#22d3ee' ),
			),
			'computer-repair' => array(
				'title' => 'Computer Repair',
				'category' => 'services',
				'template_file' => 'demo-computer-repair-home.json',
				'thumbnail' => 'computer-repair.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'electrician' => array(
				'title' => 'Electrician',
				'category' => 'services',
				'template_file' => 'demo-electrician-home.json',
				'thumbnail' => 'electrician.jpg',
				'colors' => array( 'primary' => '#f59e0b', 'secondary' => '#fbbf24' ),
			),
			'flooring' => array(
				'title' => 'Flooring',
				'category' => 'services',
				'template_file' => 'demo-flooring-home.json',
				'thumbnail' => 'flooring.jpg',
				'colors' => array( 'primary' => '#92400e', 'secondary' => '#d97706' ),
			),
			'handyman' => array(
				'title' => 'Handyman',
				'category' => 'services',
				'template_file' => 'demo-handyman-home.json',
				'thumbnail' => 'handyman.jpg',
				'colors' => array( 'primary' => '#dc2626', 'secondary' => '#ef4444' ),
			),
			'landscaping' => array(
				'title' => 'Landscaping',
				'category' => 'services',
				'template_file' => 'demo-landscaping-home.json',
				'thumbnail' => 'landscaping.jpg',
				'colors' => array( 'primary' => '#16a34a', 'secondary' => '#22c55e' ),
			),
			'laundry' => array(
				'title' => 'Laundry',
				'category' => 'services',
				'template_file' => 'demo-laundry-home.json',
				'thumbnail' => 'laundry.jpg',
				'colors' => array( 'primary' => '#06b6d4', 'secondary' => '#22d3ee' ),
			),
			'locksmith' => array(
				'title' => 'Locksmith',
				'category' => 'services',
				'template_file' => 'demo-locksmith-home.json',
				'thumbnail' => 'locksmith.jpg',
				'colors' => array( 'primary' => '#6b7280', 'secondary' => '#9ca3af' ),
			),
			'moving-company' => array(
				'title' => 'Moving Company',
				'category' => 'services',
				'template_file' => 'demo-moving-company-home.json',
				'thumbnail' => 'moving-company.jpg',
				'colors' => array( 'primary' => '#1e40af', 'secondary' => '#3b82f6' ),
			),
			'paint-shop' => array(
				'title' => 'Paint Shop',
				'category' => 'services',
				'template_file' => 'demo-paint-shop-home.json',
				'thumbnail' => 'paint-shop.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'pest-control' => array(
				'title' => 'Pest Control',
				'category' => 'services',
				'template_file' => 'demo-pest-control-home.json',
				'thumbnail' => 'pest-control.jpg',
				'colors' => array( 'primary' => '#10b981', 'secondary' => '#34d399' ),
			),
			'plumbing' => array(
				'title' => 'Plumbing',
				'category' => 'services',
				'template_file' => 'demo-plumbing-home.json',
				'thumbnail' => 'plumbing.jpg',
				'colors' => array( 'primary' => '#1e40af', 'secondary' => '#3b82f6' ),
			),
			'translation' => array(
				'title' => 'Translation',
				'category' => 'services',
				'template_file' => 'demo-translation-home.json',
				'thumbnail' => 'translation.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),

			// Lifestyle & Food
			'air-conditioning' => array(
				'title' => 'Air Conditioning',
				'category' => 'lifestyle-food',
				'template_file' => 'demo-air-conditioning-home.json',
				'thumbnail' => 'air-conditioning.jpg',
				'colors' => array( 'primary' => '#06b6d4', 'secondary' => '#22d3ee' ),
			),
			'bakery' => array(
				'title' => 'Bakery',
				'category' => 'lifestyle-food',
				'template_file' => 'demo-bakery-home.json',
				'thumbnail' => 'bakery.jpg',
				'colors' => array( 'primary' => '#d97706', 'secondary' => '#f59e0b' ),
			),
			'barbershop' => array(
				'title' => 'Barbershop',
				'category' => 'lifestyle-food',
				'template_file' => 'demo-barbershop-home.json',
				'thumbnail' => 'barbershop.jpg',
				'colors' => array( 'primary' => '#6b7280', 'secondary' => '#9ca3af' ),
			),
			'beauty-center' => array(
				'title' => 'Beauty Center',
				'category' => 'lifestyle-food',
				'template_file' => 'demo-beauty-center-home.json',
				'thumbnail' => 'beauty-center.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'beauty-salon' => array(
				'title' => 'Beauty Salon',
				'category' => 'lifestyle-food',
				'template_file' => 'demo-beauty-salon-home.json',
				'thumbnail' => 'beauty-salon.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'coffee' => array(
				'title' => 'Coffee',
				'category' => 'lifestyle-food',
				'template_file' => 'demo-coffee-home.json',
				'thumbnail' => 'coffee.jpg',
				'colors' => array( 'primary' => '#92400e', 'secondary' => '#d97706' ),
			),
			'coffee-shop' => array(
				'title' => 'Coffee Shop',
				'category' => 'lifestyle-food',
				'template_file' => 'demo-coffee-shop-home.json',
				'thumbnail' => 'coffee-shop.jpg',
				'colors' => array( 'primary' => '#92400e', 'secondary' => '#d97706' ),
			),
			'cosmetics' => array(
				'title' => 'Cosmetics',
				'category' => 'lifestyle-food',
				'template_file' => 'demo-cosmetics-home.json',
				'thumbnail' => 'cosmetics.jpg',
				'colors' => array( 'primary' => '#d946ef', 'secondary' => '#e879f9' ),
			),
			'craft-beer' => array(
				'title' => 'Craft Beer',
				'category' => 'lifestyle-food',
				'template_file' => 'demo-craft-beer-home.json',
				'thumbnail' => 'craft-beer.jpg',
				'colors' => array( 'primary' => '#92400e', 'secondary' => '#d97706' ),
			),
			'dance-studio' => array(
				'title' => 'Dance Studio',
				'category' => 'lifestyle-food',
				'template_file' => 'demo-dance-studio-home.json',
				'thumbnail' => 'dance-studio.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'fast-food' => array(
				'title' => 'Fast Food',
				'category' => 'lifestyle-food',
				'template_file' => 'demo-fast-food-home.json',
				'thumbnail' => 'fast-food.jpg',
				'colors' => array( 'primary' => '#dc2626', 'secondary' => '#ef4444' ),
			),
			'food-truck' => array(
				'title' => 'Food Truck',
				'category' => 'lifestyle-food',
				'template_file' => 'demo-food-truck-home.json',
				'thumbnail' => 'food-truck.jpg',
				'colors' => array( 'primary' => '#f59e0b', 'secondary' => '#fbbf24' ),
			),
			'hair-salon' => array(
				'title' => 'Hair Salon',
				'category' => 'lifestyle-food',
				'template_file' => 'demo-hair-salon-home.json',
				'thumbnail' => 'hair-salon.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'hairdresser' => array(
				'title' => 'Hairdresser',
				'category' => 'lifestyle-food',
				'template_file' => 'demo-hairdresser-home.json',
				'thumbnail' => 'hairdresser.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'pub' => array(
				'title' => 'Pub',
				'category' => 'lifestyle-food',
				'template_file' => 'demo-pub-home.json',
				'thumbnail' => 'pub.jpg',
				'colors' => array( 'primary' => '#92400e', 'secondary' => '#d97706' ),
			),
			'restaurant' => array(
				'title' => 'Restaurant',
				'category' => 'lifestyle-food',
				'template_file' => 'demo-restaurant-home.json',
				'thumbnail' => 'restaurant.jpg',
				'colors' => array( 'primary' => '#dc2626', 'secondary' => '#ef4444' ),
			),
			'tattoo-salon' => array(
				'title' => 'Tattoo Salon',
				'category' => 'lifestyle-food',
				'template_file' => 'demo-tattoo-salon-home.json',
				'thumbnail' => 'tattoo-salon.jpg',
				'colors' => array( 'primary' => '#1f2937', 'secondary' => '#374151' ),
			),
			'wine-bar' => array(
				'title' => 'Wine Bar',
				'category' => 'lifestyle-food',
				'template_file' => 'demo-wine-bar-home.json',
				'thumbnail' => 'wine-bar.jpg',
				'colors' => array( 'primary' => '#7c2d12', 'secondary' => '#92400e' ),
			),
			'wine-shop' => array(
				'title' => 'Wine Shop',
				'category' => 'lifestyle-food',
				'template_file' => 'demo-wine-shop-home.json',
				'thumbnail' => 'wine-shop.jpg',
				'colors' => array( 'primary' => '#7c2d12', 'secondary' => '#92400e' ),
			),

			// Creative & Design
			'architect' => array(
				'title' => 'Architect',
				'category' => 'creative-design',
				'template_file' => 'demo-architect-home.json',
				'thumbnail' => 'architect.jpg',
				'colors' => array( 'primary' => '#6b7280', 'secondary' => '#9ca3af' ),
			),
			'architectural-firm' => array(
				'title' => 'Architectural Firm',
				'category' => 'creative-design',
				'template_file' => 'demo-architectural-firm-home.json',
				'thumbnail' => 'architectural-firm.jpg',
				'colors' => array( 'primary' => '#6b7280', 'secondary' => '#9ca3af' ),
			),
			'architecture' => array(
				'title' => 'Architecture',
				'category' => 'creative-design',
				'template_file' => 'demo-architecture-home.json',
				'thumbnail' => 'architecture.jpg',
				'colors' => array( 'primary' => '#6b7280', 'secondary' => '#9ca3af' ),
			),
			'creative-agency' => array(
				'title' => 'Creative Agency',
				'category' => 'creative-design',
				'template_file' => 'demo-creative-agency-home.json',
				'thumbnail' => 'creative-agency.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),
			'creative-studio' => array(
				'title' => 'Creative Studio',
				'category' => 'creative-design',
				'template_file' => 'demo-creative-studio-home.json',
				'thumbnail' => 'creative-studio.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),
			'design-studio' => array(
				'title' => 'Design Studio',
				'category' => 'creative-design',
				'template_file' => 'demo-design-studio-home.json',
				'thumbnail' => 'design-studio.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),
			'designer' => array(
				'title' => 'Designer',
				'category' => 'creative-design',
				'template_file' => 'demo-designer-home.json',
				'thumbnail' => 'designer.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'designer-minimalist' => array(
				'title' => 'Designer Minimalist',
				'category' => 'creative-design',
				'template_file' => 'demo-designer-minimalist-home.json',
				'thumbnail' => 'designer-minimalist.jpg',
				'colors' => array( 'primary' => '#f5f5f5', 'secondary' => '#d4d4d8' ),
			),
			'digital-agency' => array(
				'title' => 'Digital Agency',
				'category' => 'creative-design',
				'template_file' => 'demo-digital-agency-home.json',
				'thumbnail' => 'digital-agency.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'digital-studio' => array(
				'title' => 'Digital Studio',
				'category' => 'creative-design',
				'template_file' => 'demo-digital-studio-home.json',
				'thumbnail' => 'digital-studio.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'portfolio-grid' => array(
				'title' => 'Portfolio Grid',
				'category' => 'creative-design',
				'template_file' => 'portfolio-grid.json',
				'thumbnail' => 'portfolio-grid.jpg',
				'colors' => array( 'primary' => '#1f2937', 'secondary' => '#374151' ),
			),
			'portfolio-single' => array(
				'title' => 'Portfolio Single',
				'category' => 'creative-design',
				'template_file' => 'portfolio-single.json',
				'thumbnail' => 'portfolio-single.jpg',
				'colors' => array( 'primary' => '#1f2937', 'secondary' => '#374151' ),
			),
			'smm-studio' => array(
				'title' => 'SMM Studio',
				'category' => 'creative-design',
				'template_file' => 'demo-smm-studio-home.json',
				'thumbnail' => 'smm-studio.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),

			// Education & Community
			'book-author' => array(
				'title' => 'Book Author',
				'category' => 'education-community',
				'template_file' => 'demo-book-author-home.json',
				'thumbnail' => 'book-author.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),
			'charity' => array(
				'title' => 'Charity',
				'category' => 'education-community',
				'template_file' => 'demo-charity-home.json',
				'thumbnail' => 'charity.jpg',
				'colors' => array( 'primary' => '#dc2626', 'secondary' => '#ef4444' ),
			),
			'child-center' => array(
				'title' => 'Child Center',
				'category' => 'education-community',
				'template_file' => 'demo-child-center-home.json',
				'thumbnail' => 'child-center.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'church' => array(
				'title' => 'Church',
				'category' => 'education-community',
				'template_file' => 'demo-church-home.json',
				'thumbnail' => 'church.jpg',
				'colors' => array( 'primary' => '#1e40af', 'secondary' => '#3b82f6' ),
			),
			'donation' => array(
				'title' => 'Donation',
				'category' => 'education-community',
				'template_file' => 'demo-donation-home.json',
				'thumbnail' => 'donation.jpg',
				'colors' => array( 'primary' => '#dc2626', 'secondary' => '#ef4444' ),
			),
			'driving-school' => array(
				'title' => 'Driving School',
				'category' => 'education-community',
				'template_file' => 'demo-driving-school-home.json',
				'thumbnail' => 'driving-school.jpg',
				'colors' => array( 'primary' => '#f59e0b', 'secondary' => '#fbbf24' ),
			),
			'education' => array(
				'title' => 'Education',
				'category' => 'education-community',
				'template_file' => 'demo-education-home.json',
				'thumbnail' => 'education.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'kindergarten' => array(
				'title' => 'Kindergarten',
				'category' => 'education-community',
				'template_file' => 'demo-kindergarten-home.json',
				'thumbnail' => 'kindergarten.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'language-school' => array(
				'title' => 'Language School',
				'category' => 'education-community',
				'template_file' => 'demo-language-school-home.json',
				'thumbnail' => 'language-school.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'museum' => array(
				'title' => 'Museum',
				'category' => 'education-community',
				'template_file' => 'demo-museum-home.json',
				'thumbnail' => 'museum.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),
			'history-museum' => array(
				'title' => 'History Museum',
				'category' => 'education-community',
				'template_file' => 'demo-history-museum-home.json',
				'thumbnail' => 'history-museum.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),
			'politics' => array(
				'title' => 'Politics',
				'category' => 'education-community',
				'template_file' => 'demo-politics-home.json',
				'thumbnail' => 'politics.jpg',
				'colors' => array( 'primary' => '#dc2626', 'secondary' => '#ef4444' ),
			),
			'spiritual-counsellor' => array(
				'title' => 'Spiritual Counsellor',
				'category' => 'education-community',
				'template_file' => 'demo-spiritual-counsellor-home.json',
				'thumbnail' => 'spiritual-counsellor.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),

			// Retail & Shopping
			'artisan-fashion' => array(
				'title' => 'Artisan Fashion',
				'category' => 'retail-shopping',
				'template_file' => 'demo-artisan-fashion-home.json',
				'thumbnail' => 'artisan-fashion.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'clothing-shop' => array(
				'title' => 'Clothing Shop',
				'category' => 'retail-shopping',
				'template_file' => 'demo-clothing-shop-home.json',
				'thumbnail' => 'clothing-shop.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'ecommerce' => array(
				'title' => 'E-Commerce',
				'category' => 'retail-shopping',
				'template_file' => 'demo-ecommerce-home.json',
				'thumbnail' => 'ecommerce.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'furniture' => array(
				'title' => 'Furniture',
				'category' => 'retail-shopping',
				'template_file' => 'demo-furniture-home.json',
				'thumbnail' => 'furniture.jpg',
				'colors' => array( 'primary' => '#92400e', 'secondary' => '#d97706' ),
			),
			'groceries' => array(
				'title' => 'Groceries',
				'category' => 'retail-shopping',
				'template_file' => 'demo-groceries-home.json',
				'thumbnail' => 'groceries.jpg',
				'colors' => array( 'primary' => '#16a34a', 'secondary' => '#22c55e' ),
			),
			'home-decor' => array(
				'title' => 'Home Decor',
				'category' => 'retail-shopping',
				'template_file' => 'demo-home-decor-home.json',
				'thumbnail' => 'home-decor.jpg',
				'colors' => array( 'primary' => '#d946ef', 'secondary' => '#e879f9' ),
			),
			'jewelry' => array(
				'title' => 'Jewelry',
				'category' => 'retail-shopping',
				'template_file' => 'demo-jewelry-home.json',
				'thumbnail' => 'jewelry.jpg',
				'colors' => array( 'primary' => '#f59e0b', 'secondary' => '#fbbf24' ),
			),
			'kids-store' => array(
				'title' => 'Kids Store',
				'category' => 'retail-shopping',
				'template_file' => 'demo-kids-store-home.json',
				'thumbnail' => 'kids-store.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'lingerie' => array(
				'title' => 'Lingerie',
				'category' => 'retail-shopping',
				'template_file' => 'demo-lingerie-home.json',
				'thumbnail' => 'lingerie.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'liquor-tobacco' => array(
				'title' => 'Liquor & Tobacco',
				'category' => 'retail-shopping',
				'template_file' => 'demo-liquor-tobacco-home.json',
				'thumbnail' => 'liquor-tobacco.jpg',
				'colors' => array( 'primary' => '#92400e', 'secondary' => '#d97706' ),
			),
			'paint-shop-retail' => array(
				'title' => 'Paint Shop (Retail)',
				'category' => 'retail-shopping',
				'template_file' => 'demo-paint-shop-home.json',
				'thumbnail' => 'paint-shop-retail.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'pets' => array(
				'title' => 'Pets',
				'category' => 'retail-shopping',
				'template_file' => 'demo-pets-home.json',
				'thumbnail' => 'pets.jpg',
				'colors' => array( 'primary' => '#f59e0b', 'secondary' => '#fbbf24' ),
			),
			'print-store' => array(
				'title' => 'Print Store',
				'category' => 'retail-shopping',
				'template_file' => 'demo-print-store-home.json',
				'thumbnail' => 'print-store.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'sports-shop' => array(
				'title' => 'Sports Shop',
				'category' => 'retail-shopping',
				'template_file' => 'demo-sports-shop-home.json',
				'thumbnail' => 'sports-shop.jpg',
				'colors' => array( 'primary' => '#ef4444', 'secondary' => '#f87171' ),
			),

			// Property & Construction
			'3d-printing' => array(
				'title' => '3D Printing',
				'category' => 'property-construction',
				'template_file' => 'demo-3d-printing-home.json',
				'thumbnail' => '3d-printing.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'apartments' => array(
				'title' => 'Apartments',
				'category' => 'property-construction',
				'template_file' => 'demo-apartments-home.json',
				'thumbnail' => 'apartments.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'builder' => array(
				'title' => 'Builder',
				'category' => 'property-construction',
				'template_file' => 'demo-builder-home.json',
				'thumbnail' => 'builder.jpg',
				'colors' => array( 'primary' => '#6b7280', 'secondary' => '#9ca3af' ),
			),
			'car-repair' => array(
				'title' => 'Car Repair',
				'category' => 'property-construction',
				'template_file' => 'demo-car-repair-home.json',
				'thumbnail' => 'car-repair.jpg',
				'colors' => array( 'primary' => '#6b7280', 'secondary' => '#9ca3af' ),
			),
			'carpenter' => array(
				'title' => 'Carpenter',
				'category' => 'property-construction',
				'template_file' => 'demo-carpenter-home.json',
				'thumbnail' => 'carpenter.jpg',
				'colors' => array( 'primary' => '#92400e', 'secondary' => '#d97706' ),
			),
			'construction' => array(
				'title' => 'Construction',
				'category' => 'property-construction',
				'template_file' => 'demo-construction-home.json',
				'thumbnail' => 'construction.jpg',
				'colors' => array( 'primary' => '#f59e0b', 'secondary' => '#fbbf24' ),
			),
			'home-repair' => array(
				'title' => 'Home Repair',
				'category' => 'property-construction',
				'template_file' => 'demo-home-repair-home.json',
				'thumbnail' => 'home-repair.jpg',
				'colors' => array( 'primary' => '#dc2626', 'secondary' => '#ef4444' ),
			),
			'interior-design' => array(
				'title' => 'Interior Design',
				'category' => 'property-construction',
				'template_file' => 'demo-interior-design-home.json',
				'thumbnail' => 'interior-design.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),
			'logistics' => array(
				'title' => 'Logistics',
				'category' => 'property-construction',
				'template_file' => 'demo-logistics-home.json',
				'thumbnail' => 'logistics.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'outdoor-paving' => array(
				'title' => 'Outdoor Paving',
				'category' => 'property-construction',
				'template_file' => 'demo-outdoor-paving-home.json',
				'thumbnail' => 'outdoor-paving.jpg',
				'colors' => array( 'primary' => '#6b7280', 'secondary' => '#9ca3af' ),
			),
			'property-rental' => array(
				'title' => 'Property Rental',
				'category' => 'property-construction',
				'template_file' => 'demo-property-rental-home.json',
				'thumbnail' => 'property-rental.jpg',
				'colors' => array( 'primary' => '#1e40af', 'secondary' => '#3b82f6' ),
			),
			'remodeling' => array(
				'title' => 'Remodeling',
				'category' => 'property-construction',
				'template_file' => 'demo-remodeling-home.json',
				'thumbnail' => 'remodeling.jpg',
				'colors' => array( 'primary' => '#dc2626', 'secondary' => '#ef4444' ),
			),
			'renovation' => array(
				'title' => 'Renovation',
				'category' => 'property-construction',
				'template_file' => 'demo-renovation-home.json',
				'thumbnail' => 'renovation.jpg',
				'colors' => array( 'primary' => '#f59e0b', 'secondary' => '#fbbf24' ),
			),
			'residential-complex' => array(
				'title' => 'Residential Complex',
				'category' => 'property-construction',
				'template_file' => 'demo-residential-complex-home.json',
				'thumbnail' => 'residential-complex.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'woodworking' => array(
				'title' => 'Woodworking',
				'category' => 'property-construction',
				'template_file' => 'demo-woodworking-home.json',
				'thumbnail' => 'woodworking.jpg',
				'colors' => array( 'primary' => '#92400e', 'secondary' => '#d97706' ),
			),

			// Sports & Entertainment
			'ballet' => array(
				'title' => 'Ballet',
				'category' => 'sports-entertainment',
				'template_file' => 'demo-ballet-home.json',
				'thumbnail' => 'ballet.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'board-games' => array(
				'title' => 'Board Games',
				'category' => 'sports-entertainment',
				'template_file' => 'demo-board-games-home.json',
				'thumbnail' => 'board-games.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'bowling' => array(
				'title' => 'Bowling',
				'category' => 'sports-entertainment',
				'template_file' => 'demo-bowling-home.json',
				'thumbnail' => 'bowling.jpg',
				'colors' => array( 'primary' => '#dc2626', 'secondary' => '#ef4444' ),
			),
			'casino' => array(
				'title' => 'Casino',
				'category' => 'sports-entertainment',
				'template_file' => 'demo-casino-home.json',
				'thumbnail' => 'casino.jpg',
				'colors' => array( 'primary' => '#f59e0b', 'secondary' => '#fbbf24' ),
			),
			'concert' => array(
				'title' => 'Concert',
				'category' => 'sports-entertainment',
				'template_file' => 'demo-concert-home.json',
				'thumbnail' => 'concert.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'extreme-sports' => array(
				'title' => 'Extreme Sports',
				'category' => 'sports-entertainment',
				'template_file' => 'demo-extreme-sports-home.json',
				'thumbnail' => 'extreme-sports.jpg',
				'colors' => array( 'primary' => '#dc2626', 'secondary' => '#ef4444' ),
			),
			'game-showcase' => array(
				'title' => 'Game Showcase',
				'category' => 'sports-entertainment',
				'template_file' => 'demo-game-showcase-home.json',
				'thumbnail' => 'game-showcase.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),
			'game-studio' => array(
				'title' => 'Game Studio',
				'category' => 'sports-entertainment',
				'template_file' => 'demo-game-studio-home.json',
				'thumbnail' => 'game-studio.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'kids-park' => array(
				'title' => 'Kids Park',
				'category' => 'sports-entertainment',
				'template_file' => 'demo-kids-park-home.json',
				'thumbnail' => 'kids-park.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'music' => array(
				'title' => 'Music',
				'category' => 'sports-entertainment',
				'template_file' => 'demo-music-home.json',
				'thumbnail' => 'music.jpg',
				'colors' => array( 'primary' => '#d946ef', 'secondary' => '#e879f9' ),
			),
			'racing' => array(
				'title' => 'Racing',
				'category' => 'sports-entertainment',
				'template_file' => 'demo-racing-home.json',
				'thumbnail' => 'racing.jpg',
				'colors' => array( 'primary' => '#dc2626', 'secondary' => '#ef4444' ),
			),
			'scuba-diving' => array(
				'title' => 'Scuba Diving',
				'category' => 'sports-entertainment',
				'template_file' => 'demo-scuba-diving-home.json',
				'thumbnail' => 'scuba-diving.jpg',
				'colors' => array( 'primary' => '#06b6d4', 'secondary' => '#22d3ee' ),
			),
			'shooting-range' => array(
				'title' => 'Shooting Range',
				'category' => 'sports-entertainment',
				'template_file' => 'demo-shooting-range-home.json',
				'thumbnail' => 'shooting-range.jpg',
				'colors' => array( 'primary' => '#6b7280', 'secondary' => '#9ca3af' ),
			),
			'sports' => array(
				'title' => 'Sports',
				'category' => 'sports-entertainment',
				'template_file' => 'demo-sports-home.json',
				'thumbnail' => 'sports.jpg',
				'colors' => array( 'primary' => '#ef4444', 'secondary' => '#f87171' ),
			),
			'surfing' => array(
				'title' => 'Surfing',
				'category' => 'sports-entertainment',
				'template_file' => 'demo-surfing-home.json',
				'thumbnail' => 'surfing.jpg',
				'colors' => array( 'primary' => '#06b6d4', 'secondary' => '#22d3ee' ),
			),
			'tennis' => array(
				'title' => 'Tennis',
				'category' => 'sports-entertainment',
				'template_file' => 'demo-tennis-home.json',
				'thumbnail' => 'tennis.jpg',
				'colors' => array( 'primary' => '#16a34a', 'secondary' => '#22c55e' ),
			),
			'ticket-box' => array(
				'title' => 'Ticket Box',
				'category' => 'sports-entertainment',
				'template_file' => 'demo-ticket-box-home.json',
				'thumbnail' => 'ticket-box.jpg',
				'colors' => array( 'primary' => '#f59e0b', 'secondary' => '#fbbf24' ),
			),

			// Travel & Events
			'cargo' => array(
				'title' => 'Cargo',
				'category' => 'travel-events',
				'template_file' => 'demo-cargo-home.json',
				'thumbnail' => 'cargo.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'catering' => array(
				'title' => 'Catering',
				'category' => 'travel-events',
				'template_file' => 'demo-catering-home.json',
				'thumbnail' => 'catering.jpg',
				'colors' => array( 'primary' => '#dc2626', 'secondary' => '#ef4444' ),
			),
			'drone-expert' => array(
				'title' => 'Drone Expert',
				'category' => 'travel-events',
				'template_file' => 'demo-drone-expert-home.json',
				'thumbnail' => 'drone-expert.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'events' => array(
				'title' => 'Events',
				'category' => 'travel-events',
				'template_file' => 'demo-events-home.json',
				'thumbnail' => 'events.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'transportation' => array(
				'title' => 'Transportation',
				'category' => 'travel-events',
				'template_file' => 'demo-transportation-home.json',
				'thumbnail' => 'transportation.jpg',
				'colors' => array( 'primary' => '#1e40af', 'secondary' => '#3b82f6' ),
			),
			'travel' => array(
				'title' => 'Travel',
				'category' => 'travel-events',
				'template_file' => 'demo-travel-home.json',
				'thumbnail' => 'travel.jpg',
				'colors' => array( 'primary' => '#06b6d4', 'secondary' => '#22d3ee' ),
			),
			'wedding' => array(
				'title' => 'Wedding',
				'category' => 'travel-events',
				'template_file' => 'demo-wedding-home.json',
				'thumbnail' => 'wedding.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),
			'wedding-planner' => array(
				'title' => 'Wedding Planner',
				'category' => 'travel-events',
				'template_file' => 'demo-wedding-planner-home.json',
				'thumbnail' => 'wedding-planner.jpg',
				'colors' => array( 'primary' => '#ec4899', 'secondary' => '#f472b6' ),
			),

			// Personal & Professional
			'agribusiness' => array(
				'title' => 'Agribusiness',
				'category' => 'personal-professional',
				'template_file' => 'demo-agribusiness-home.json',
				'thumbnail' => 'agribusiness.jpg',
				'colors' => array( 'primary' => '#16a34a', 'secondary' => '#22c55e' ),
			),
			'agriculture' => array(
				'title' => 'Agriculture',
				'category' => 'personal-professional',
				'template_file' => 'demo-agriculture-home.json',
				'thumbnail' => 'agriculture.jpg',
				'colors' => array( 'primary' => '#16a34a', 'secondary' => '#22c55e' ),
			),
			'about-us' => array(
				'title' => 'About Us',
				'category' => 'personal-professional',
				'template_file' => 'about-us.json',
				'thumbnail' => 'about-us.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'blog-page' => array(
				'title' => 'Blog Page',
				'category' => 'personal-professional',
				'template_file' => 'blog-page.json',
				'thumbnail' => 'blog-page.jpg',
				'colors' => array( 'primary' => '#1f2937', 'secondary' => '#374151' ),
			),
			'coming-soon' => array(
				'title' => 'Coming Soon',
				'category' => 'personal-professional',
				'template_file' => 'coming-soon.json',
				'thumbnail' => 'coming-soon.jpg',
				'colors' => array( 'primary' => '#f59e0b', 'secondary' => '#fbbf24' ),
			),
			'contact' => array(
				'title' => 'Contact',
				'category' => 'personal-professional',
				'template_file' => 'contact.json',
				'thumbnail' => 'contact.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'default' => array(
				'title' => 'Default',
				'category' => 'personal-professional',
				'template_file' => 'demo-default-home.json',
				'thumbnail' => 'default.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'ebook' => array(
				'title' => 'E-Book',
				'category' => 'personal-professional',
				'template_file' => 'demo-ebook-home.json',
				'thumbnail' => 'ebook.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),
			'faq' => array(
				'title' => 'FAQ',
				'category' => 'personal-professional',
				'template_file' => 'faq.json',
				'thumbnail' => 'faq.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'fundraising' => array(
				'title' => 'Fundraising',
				'category' => 'personal-professional',
				'template_file' => 'demo-fundraising-home.json',
				'thumbnail' => 'fundraising.jpg',
				'colors' => array( 'primary' => '#dc2626', 'secondary' => '#ef4444' ),
			),
			'gardener' => array(
				'title' => 'Gardener',
				'category' => 'personal-professional',
				'template_file' => 'demo-gardener-home.json',
				'thumbnail' => 'gardener.jpg',
				'colors' => array( 'primary' => '#16a34a', 'secondary' => '#22c55e' ),
			),
			'gardening' => array(
				'title' => 'Gardening',
				'category' => 'personal-professional',
				'template_file' => 'demo-gardening-home.json',
				'thumbnail' => 'gardening.jpg',
				'colors' => array( 'primary' => '#16a34a', 'secondary' => '#22c55e' ),
			),
			'green-energy' => array(
				'title' => 'Green Energy',
				'category' => 'personal-professional',
				'template_file' => 'demo-green-energy-home.json',
				'thumbnail' => 'green-energy.jpg',
				'colors' => array( 'primary' => '#10b981', 'secondary' => '#34d399' ),
			),
			'homepage-corporate' => array(
				'title' => 'Homepage Corporate',
				'category' => 'personal-professional',
				'template_file' => 'homepage-corporate.json',
				'thumbnail' => 'homepage-corporate.jpg',
				'colors' => array( 'primary' => '#1e3a8a', 'secondary' => '#1e40af' ),
			),
			'homepage-creative' => array(
				'title' => 'Homepage Creative',
				'category' => 'personal-professional',
				'template_file' => 'homepage-creative.json',
				'thumbnail' => 'homepage-creative.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),
			'homepage-shop' => array(
				'title' => 'Homepage Shop',
				'category' => 'personal-professional',
				'template_file' => 'homepage-shop.json',
				'thumbnail' => 'homepage-shop.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'landing-app' => array(
				'title' => 'Landing App',
				'category' => 'personal-professional',
				'template_file' => 'landing-app.json',
				'thumbnail' => 'landing-app.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'landing-saas' => array(
				'title' => 'Landing SaaS',
				'category' => 'personal-professional',
				'template_file' => 'landing-saas.json',
				'thumbnail' => 'landing-saas.jpg',
				'colors' => array( 'primary' => '#6366f1', 'secondary' => '#818cf8' ),
			),
			'law-firm' => array(
				'title' => 'Law Firm',
				'category' => 'personal-professional',
				'template_file' => 'demo-law-firm-home.json',
				'thumbnail' => 'law-firm.jpg',
				'colors' => array( 'primary' => '#1e40af', 'secondary' => '#3b82f6' ),
			),
			'lawyer' => array(
				'title' => 'Lawyer',
				'category' => 'personal-professional',
				'template_file' => 'demo-lawyer-home.json',
				'thumbnail' => 'lawyer.jpg',
				'colors' => array( 'primary' => '#1e40af', 'secondary' => '#3b82f6' ),
			),
			'life-coach' => array(
				'title' => 'Life Coach',
				'category' => 'personal-professional',
				'template_file' => 'demo-life-coach-home.json',
				'thumbnail' => 'life-coach.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),
			'freelancer' => array(
				'title' => 'Freelancer',
				'category' => 'personal-professional',
				'template_file' => 'demo-freelancer-home.json',
				'thumbnail' => 'freelancer.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),
			'manufactu' => array(
				'title' => 'Manufactory',
				'category' => 'personal-professional',
				'template_file' => 'demo-manufactory-home.json',
				'thumbnail' => 'manufactory.jpg',
				'colors' => array( 'primary' => '#6b7280', 'secondary' => '#9ca3af' ),
			),
			'organic-farm' => array(
				'title' => 'Organic Farm',
				'category' => 'personal-professional',
				'template_file' => 'demo-organic-farm-home.json',
				'thumbnail' => 'organic-farm.jpg',
				'colors' => array( 'primary' => '#16a34a', 'secondary' => '#22c55e' ),
			),
			'personal-portfolio' => array(
				'title' => 'Personal Portfolio',
				'category' => 'personal-professional',
				'template_file' => 'demo-personal-portfolio-home.json',
				'thumbnail' => 'personal-portfolio.jpg',
				'colors' => array( 'primary' => '#8b5cf6', 'secondary' => '#a78bfa' ),
			),
			'personal-resume' => array(
				'title' => 'Personal Resume',
				'category' => 'personal-professional',
				'template_file' => 'demo-personal-resume-home.json',
				'thumbnail' => 'personal-resume.jpg',
				'colors' => array( 'primary' => '#1e40af', 'secondary' => '#3b82f6' ),
			),
			'photographer' => array(
				'title' => 'Photographer',
				'category' => 'personal-professional',
				'template_file' => 'demo-photographer-home.json',
				'thumbnail' => 'photographer.jpg',
				'colors' => array( 'primary' => '#1f2937', 'secondary' => '#374151' ),
			),
			'pricing' => array(
				'title' => 'Pricing',
				'category' => 'personal-professional',
				'template_file' => 'pricing.json',
				'thumbnail' => 'pricing.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'renewable-energy' => array(
				'title' => 'Renewable Energy',
				'category' => 'personal-professional',
				'template_file' => 'demo-renewable-energy-home.json',
				'thumbnail' => 'renewable-energy.jpg',
				'colors' => array( 'primary' => '#10b981', 'secondary' => '#34d399' ),
			),
			'saas' => array(
				'title' => 'SaaS',
				'category' => 'personal-professional',
				'template_file' => 'demo-saas-home.json',
				'thumbnail' => 'saas.jpg',
				'colors' => array( 'primary' => '#6366f1', 'secondary' => '#818cf8' ),
			),
			'saas-about' => array(
				'title' => 'SaaS About',
				'category' => 'personal-professional',
				'template_file' => 'demo-saas-about.json',
				'thumbnail' => 'saas-about.jpg',
				'colors' => array( 'primary' => '#6366f1', 'secondary' => '#818cf8' ),
			),
			'saas-blog' => array(
				'title' => 'SaaS Blog',
				'category' => 'personal-professional',
				'template_file' => 'demo-saas-blog.json',
				'thumbnail' => 'saas-blog.jpg',
				'colors' => array( 'primary' => '#6366f1', 'secondary' => '#818cf8' ),
			),
			'saas-contact' => array(
				'title' => 'SaaS Contact',
				'category' => 'personal-professional',
				'template_file' => 'demo-saas-contact.json',
				'thumbnail' => 'saas-contact.jpg',
				'colors' => array( 'primary' => '#6366f1', 'secondary' => '#818cf8' ),
			),
			'saas-customers' => array(
				'title' => 'SaaS Customers',
				'category' => 'personal-professional',
				'template_file' => 'demo-saas-customers.json',
				'thumbnail' => 'saas-customers.jpg',
				'colors' => array( 'primary' => '#6366f1', 'secondary' => '#818cf8' ),
			),
			'saas-pricing' => array(
				'title' => 'SaaS Pricing',
				'category' => 'personal-professional',
				'template_file' => 'demo-saas-pricing.json',
				'thumbnail' => 'saas-pricing.jpg',
				'colors' => array( 'primary' => '#6366f1', 'secondary' => '#818cf8' ),
			),
			'saas-solutions' => array(
				'title' => 'SaaS Solutions',
				'category' => 'personal-professional',
				'template_file' => 'demo-saas-solutions.json',
				'thumbnail' => 'saas-solutions.jpg',
				'colors' => array( 'primary' => '#6366f1', 'secondary' => '#818cf8' ),
			),
			'saas-startup' => array(
				'title' => 'SaaS Startup',
				'category' => 'personal-professional',
				'template_file' => 'demo-saas-startup-home.json',
				'thumbnail' => 'saas-startup.jpg',
				'colors' => array( 'primary' => '#6366f1', 'secondary' => '#818cf8' ),
			),
			'services' => array(
				'title' => 'Services',
				'category' => 'personal-professional',
				'template_file' => 'services.json',
				'thumbnail' => 'services.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'team' => array(
				'title' => 'Team',
				'category' => 'personal-professional',
				'template_file' => 'team.json',
				'thumbnail' => 'team.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'web-agency' => array(
				'title' => 'Web Agency',
				'category' => 'personal-professional',
				'template_file' => 'demo-web-agency-home.json',
				'thumbnail' => 'web-agency.jpg',
				'colors' => array( 'primary' => '#3b82f6', 'secondary' => '#60a5fa' ),
			),
			'blog-home' => array(
				'title' => 'Blog Home',
				'category' => 'personal-professional',
				'template_file' => 'demo-blog-home.json',
				'thumbnail' => 'blog-home.jpg',
				'colors' => array( 'primary' => '#1f2937', 'secondary' => '#374151' ),
			),
			'elementra-home' => array(
				'title' => 'Elementra Home',
				'category' => 'personal-professional',
				'template_file' => 'elementra-home.json',
				'thumbnail' => 'elementra-home.jpg',
				'colors' => array( 'primary' => '#1e3a8a', 'secondary' => '#1e40af' ),
			),
			'elementra-about' => array(
				'title' => 'Elementra About',
				'category' => 'personal-professional',
				'template_file' => 'elementra-about.json',
				'thumbnail' => 'elementra-about.jpg',
				'colors' => array( 'primary' => '#1e3a8a', 'secondary' => '#1e40af' ),
			),
			'elementra-blog' => array(
				'title' => 'Elementra Blog',
				'category' => 'personal-professional',
				'template_file' => 'elementra-blog.json',
				'thumbnail' => 'elementra-blog.jpg',
				'colors' => array( 'primary' => '#1e3a8a', 'secondary' => '#1e40af' ),
			),
			'elementra-contact' => array(
				'title' => 'Elementra Contact',
				'category' => 'personal-professional',
				'template_file' => 'elementra-contact.json',
				'thumbnail' => 'elementra-contact.jpg',
				'colors' => array( 'primary' => '#1e3a8a', 'secondary' => '#1e40af' ),
			),
			'elementra-customers' => array(
				'title' => 'Elementra Customers',
				'category' => 'personal-professional',
				'template_file' => 'elementra-customers.json',
				'thumbnail' => 'elementra-customers.jpg',
				'colors' => array( 'primary' => '#1e3a8a', 'secondary' => '#1e40af' ),
			),
			'elementra-pricing' => array(
				'title' => 'Elementra Pricing',
				'category' => 'personal-professional',
				'template_file' => 'elementra-pricing.json',
				'thumbnail' => 'elementra-pricing.jpg',
				'colors' => array( 'primary' => '#1e3a8a', 'secondary' => '#1e40af' ),
			),
			'elementra-solutions' => array(
				'title' => 'Elementra Solutions',
				'category' => 'personal-professional',
				'template_file' => 'elementra-solutions.json',
				'thumbnail' => 'elementra-solutions.jpg',
				'colors' => array( 'primary' => '#1e3a8a', 'secondary' => '#1e40af' ),
			),
		);
	}

	/**
	 * Initialize
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_admin_page' ) );
		add_action( 'wp_ajax_sf_import_demo', array( __CLASS__, 'ajax_import_demo' ) );
		add_action( 'wp_ajax_sf_get_demos', array( __CLASS__, 'ajax_get_demos' ) );
		add_action( 'wp_ajax_sf_search_demos', array( __CLASS__, 'ajax_search_demos' ) );
		add_action( 'wp_ajax_sf_reset_demo', array( __CLASS__, 'ajax_reset_demo' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/**
	 * Get all demos organized by category
	 *
	 * @return array
	 */
	public static function get_all_demos() {
		self::init_demos();

		$organized = array();
		foreach ( self::$categories as $cat_slug => $cat_name ) {
			$organized[ $cat_slug ] = array(
				'name' => $cat_name,
				'demos' => array(),
			);
		}

		foreach ( self::$demos as $slug => $demo ) {
			$cat = $demo['category'];
			$organized[ $cat ]['demos'][ $slug ] = $demo;
		}

		return $organized;
	}

	/**
	 * Get demo categories with counts
	 *
	 * @return array
	 */
	public static function get_demo_categories() {
		self::init_demos();

		$categories = array();
		foreach ( self::$categories as $slug => $name ) {
			$count = 0;
			foreach ( self::$demos as $demo ) {
				if ( $demo['category'] === $slug ) {
					$count++;
				}
			}
			$categories[] = array(
				'slug' => $slug,
				'name' => $name,
				'count' => $count,
			);
		}

		return $categories;
	}

	/**
	 * Search demos by query string
	 *
	 * @param string $query Search query.
	 * @return array
	 */
	public static function search_demos( $query ) {
		self::init_demos();

		$query = strtolower( $query );
		$results = array();

		foreach ( self::$demos as $slug => $demo ) {
			$title = strtolower( $demo['title'] );
			$category = strtolower( self::$categories[ $demo['category'] ] );

			if ( strpos( $title, $query ) !== false || strpos( $category, $query ) !== false ) {
				$results[ $slug ] = $demo;
			}
		}

		return $results;
	}

	/**
	 * Import a specific demo
	 *
	 * @param string $slug Demo slug.
	 * @return bool|WP_Error
	 */
	public static function import_demo( $slug ) {
		self::init_demos();

		if ( ! isset( self::$demos[ $slug ] ) ) {
			return new WP_Error( 'invalid_demo', esc_html__( 'Invalid demo selected', 'themeflex' ) );
		}

		$demo = self::$demos[ $slug ];
		$template_file = THEMEFLEX_DIR . '/elementor-templates/' . $demo['template_file'];

		if ( ! file_exists( $template_file ) ) {
			return new WP_Error( 'file_not_found', esc_html__( 'Template file not found', 'themeflex' ) );
		}

		$template_data = json_decode( file_get_contents( $template_file ), true );

		if ( ! is_array( $template_data ) ) {
			return new WP_Error( 'invalid_json', esc_html__( 'Invalid template data', 'themeflex' ) );
		}

		// Create/update page with Elementor data
		if ( isset( $template_data['content'] ) ) {
			// Create page for this template
			$page_id = wp_insert_post( array(
				'post_type' => 'page',
				'post_title' => $demo['title'],
				'post_content' => $template_data['content'] ?? '',
				'post_status' => 'publish',
				'meta_input' => array(
					'_elementor_edit_mode' => 'builder',
					'_elementor_data' => wp_json_encode( $template_data['content'] ?? array() ),
					'_sf_demo_imported' => 1,
				),
			) );

			return is_wp_error( $page_id ) ? $page_id : true;
		}

		return new WP_Error( 'no_content', esc_html__( 'No content found in template', 'themeflex' ) );
	}

	/**
	 * Register admin page
	 */
	public static function register_admin_page() {
		add_submenu_page(
			'themes.php',
			esc_html__( 'Import Demo', 'themeflex' ),
			esc_html__( 'Import Demo', 'themeflex' ),
			'manage_options',
			'themeflex-demo-importer',
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Enqueue assets
	 */
	public static function enqueue_assets( $hook ) {
		if ( 'appearance_page_themeflex-demo-importer' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'sf-demo-importer',
			THEMEFLEX_URL . '/assets/css/demo-importer.css',
			array(),
			THEMEFLEX_VERSION
		);

		wp_enqueue_script(
			'sf-demo-importer',
			THEMEFLEX_URL . '/assets/js/demo-importer.js',
			array( 'jquery' ),
			THEMEFLEX_VERSION,
			true
		);

		wp_localize_script(
			'sf-demo-importer',
			'sfDemoImporter',
			array(
				'nonce' => wp_create_nonce( 'sf_demo_importer_nonce' ),
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'themePath' => THEMEFLEX_URL,
				'importing' => esc_html__( 'Importing...', 'themeflex' ),
				'success' => esc_html__( 'Demo imported successfully!', 'themeflex' ),
				'error' => esc_html__( 'Import failed. Please try again.', 'themeflex' ),
				'total_demos' => count( self::$demos ),
			)
		);
	}

	/**
	 * Render admin page
	 */
	public static function render_page() {
		?>
		<div class="wrap sf-demo-importer-page">
			<h1><?php esc_html_e( 'Import Demo Content', 'themeflex' ); ?></h1>
			<p class="description">
				<?php esc_html_e( 'Choose from 226+ professionally designed Elementor templates. Search by name or browse by category.', 'themeflex' ); ?>
			</p>

			<!-- Search & Filter -->
			<div class="sf-demo-controls">
				<div class="sf-search-container">
					<input type="text" id="sf-demo-search" class="sf-search-input" placeholder="<?php esc_attr_e( 'Search templates...', 'themeflex' ); ?>">
					<span class="sf-search-icon">🔍</span>
				</div>

				<div class="sf-category-tabs">
					<button class="sf-category-tab active" data-category="all">
						<?php esc_html_e( 'All', 'themeflex' ); ?>
						<span class="sf-count"><?php echo count( self::$demos ); ?></span>
					</button>
					<?php foreach ( self::get_demo_categories() as $category ) : ?>
						<button class="sf-category-tab" data-category="<?php echo esc_attr( $category['slug'] ); ?>">
							<?php echo esc_html( $category['name'] ); ?>
							<span class="sf-count"><?php echo absint( $category['count'] ); ?></span>
						</button>
					<?php endforeach; ?>
				</div>
			</div>

			<!-- Demos Grid -->
			<div id="sf-demos-container" class="sf-demos-grid">
				<!-- Populated by JavaScript -->
			</div>

			<!-- Progress Bar -->
			<div id="sf-import-progress" class="sf-progress-container" style="display:none;">
				<h2><?php esc_html_e( 'Importing Demo Content', 'themeflex' ); ?></h2>
				<div class="sf-progress-bar">
					<div class="sf-progress-fill"></div>
				</div>
				<p class="sf-progress-text"></p>
			</div>

			<!-- Success Message -->
			<div id="sf-import-success" class="notice notice-success" style="display:none;">
				<p><?php esc_html_e( 'Demo content imported successfully! Your site is ready to customize.', 'themeflex' ); ?></p>
			</div>

			<!-- Reset Section -->
			<div class="sf-reset-section">
				<h2><?php esc_html_e( 'Reset Demo Content', 'themeflex' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Remove all imported demo content and return to a clean site.', 'themeflex' ); ?></p>
				<button id="sf-reset-btn" class="button button-secondary">
					<?php esc_html_e( 'Reset to Default', 'themeflex' ); ?>
				</button>
			</div>
		</div>
		<?php
	}

	/**
	 * AJAX: Get all demos
	 */
	public static function ajax_get_demos() {
		check_ajax_referer( 'sf_demo_importer_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( esc_html__( 'Insufficient permissions', 'themeflex' ) );
		}

		self::init_demos();

		wp_send_json_success( array(
			'demos' => self::$demos,
			'categories' => self::$categories,
		) );
	}

	/**
	 * AJAX: Search demos
	 */
	public static function ajax_search_demos() {
		check_ajax_referer( 'sf_demo_importer_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( esc_html__( 'Insufficient permissions', 'themeflex' ) );
		}

		$query = isset( $_POST['query'] ) ? sanitize_text_field( wp_unslash( $_POST['query'] ) ) : '';

		if ( empty( $query ) ) {
			self::ajax_get_demos();
			return;
		}

		$results = self::search_demos( $query );

		wp_send_json_success( array(
			'demos' => $results,
		) );
	}

	/**
	 * AJAX: Import demo
	 */
	public static function ajax_import_demo() {
		check_ajax_referer( 'sf_demo_importer_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( esc_html__( 'Insufficient permissions', 'themeflex' ) );
		}

		$slug = isset( $_POST['slug'] ) ? sanitize_text_field( wp_unslash( $_POST['slug'] ) ) : '';

		if ( empty( $slug ) ) {
			wp_send_json_error( esc_html__( 'Demo slug required', 'themeflex' ) );
		}

		$result = self::import_demo( $slug );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		wp_send_json_success( esc_html__( 'Demo imported successfully', 'themeflex' ) );
	}

	/**
	 * AJAX: Reset demo
	 */
	public static function ajax_reset_demo() {
		check_ajax_referer( 'sf_demo_importer_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( esc_html__( 'Insufficient permissions', 'themeflex' ) );
		}

		// Delete all demo-imported posts
		$args = array(
			'posts_per_page' => -1,
			'meta_key' => '_sf_demo_imported',
			'meta_value' => 1,
		);

		$posts = get_posts( $args );

		foreach ( $posts as $post ) {
			wp_delete_post( $post->ID, true );
		}

		wp_send_json_success( esc_html__( 'Demo content reset successfully', 'themeflex' ) );
	}
}

// Initialize
ThemeFlex_Demo_Importer::init();
