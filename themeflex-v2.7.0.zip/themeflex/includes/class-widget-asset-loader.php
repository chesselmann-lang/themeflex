<?php
/**
 * Per-Widget CSS/JS Loading
 *
 * Instead of loading all widget styles globally, this system only loads
 * CSS/JS for widgets actually used on the current page.
 * Falls back to full stylesheet if page not built with Elementor.
 *
 * @package ThemeFlex
 * @since   2.0.0
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Widget_Asset_Loader {

    private static ?self $instance = null;
    /** Widgets found on current page */
    private array $page_widgets = [];
    /** Widget-to-CSS-class mapping */
    private array $widget_css_map = [
        // High-frequency — always load
        'sf_hero_section'       => ['always'],
        'sf_nav_menu'           => ['always'],
        'sf_site_logo'          => ['always'],

        // On-demand widget CSS
        'sf_pricing_calculator' => ['pricing-calc'],
        'sf_social_proof'       => ['social-proof'],
        'sf_particle_background'=> ['particle'],
        'sf_horizontal_scroll'  => ['horizontal-scroll'],
        'sf_isotope_portfolio'  => ['portfolio-grid', 'isotope'],
        'sf_lead_quiz'          => ['quiz'],
        'sf_feature_showcase'   => ['feature-showcase'],
        'sf_image_comparison'   => ['image-comparison'],
        'sf_modal_popup'        => ['modal'],
        'sf_testimonial_carousel'=>['testimonial-carousel'],
        'sf_cookie_consent'     => ['cookie-consent'],
        'sf_pricing_toggle'     => ['pricing-toggle'],
        'sf_countdown'          => ['countdown'],
        'sf_chart'              => ['chart'],
        'sf_ai_content'         => ['ai-widget'],
        'sf_product_mockup'     => ['mockup'],
        'sf_faq_search'         => ['faq'],
        'sf_newsletter_form'    => ['newsletter'],
        'sf_comparison_table_feature' => ['comparison-table'],
    ];

    public static function instance(): self {
        if (is_null(self::$instance)) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_page_assets'], 5);
        add_action('elementor/frontend/widget/before_render', [$this, 'track_widget'], 10, 1);
    }

    public function track_widget(\Elementor\Widget_Base $widget): void {
        $this->page_widgets[] = $widget->get_name();
    }

    public function enqueue_page_assets(): void {
        // Always load the interaction engine
        wp_enqueue_style('sf-interaction-engine',
            get_template_directory_uri().'/assets/css/interaction-engine.css',
            ['themeflex-style'], wp_get_theme()->get('Version')
        );
        wp_enqueue_script('sf-interaction-engine',
            get_template_directory_uri().'/assets/js/interaction-engine.js',
            [], wp_get_theme()->get('Version'), true
        );

        // Load widget-specific CSS if that widget's CSS file exists
        add_action('wp_footer', function() {
            $loaded = [];
            foreach ($this->page_widgets as $widget_name) {
                $groups = $this->widget_css_map[$widget_name] ?? [];
                foreach ($groups as $group) {
                    if ($group === 'always' || isset($loaded[$group])) continue;
                    $css_file = get_template_directory()."/assets/css/widgets/{$group}.css";
                    if (file_exists($css_file)) {
                        wp_enqueue_style(
                            "sf-widget-{$group}",
                            get_template_directory_uri()."/assets/css/widgets/{$group}.css",
                            ['themeflex-style'],
                            wp_get_theme()->get('Version')
                        );
                        $loaded[$group] = true;
                    }
                }
            }
        });
    }

    public function get_page_widgets(): array {
        return $this->page_widgets;
    }
}

ThemeFlex_Widget_Asset_Loader::instance();
