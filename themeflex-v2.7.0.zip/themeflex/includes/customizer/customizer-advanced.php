<?php
/**
 * Advanced Customizer Panels — AI, Performance, SEO, Typography, Social, API Keys, Custom Code.
 * @package ThemeFlex
 * @since   1.1.0
 */
if (!defined('ABSPATH')) exit;

function sf_register_advanced_customizer(WP_Customize_Manager $wp_customize): void {

    $wp_customize->add_panel('sf_advanced', ['title'=>esc_html__('Advanced Settings','themeflex'),'priority'=>200]);

    // ── AI Settings ──
    $wp_customize->add_section('sf_ai_settings',['title'=>esc_html__('AI Content Assistant','themeflex'),'panel'=>'sf_advanced','priority'=>10]);
    $wp_customize->add_setting('sf_openai_api_key',['type'=>'option','capability'=>'manage_options','sanitize_callback'=>'sanitize_text_field']);
    $wp_customize->add_control('sf_openai_api_key',['section'=>'sf_ai_settings','label'=>__('OpenAI API Key','themeflex'),'description'=>__('Your sk-... key from platform.openai.com','themeflex'),'type'=>'text','input_attrs'=>['placeholder'=>'sk-...']]);
    $wp_customize->add_setting('sf_openai_model',['default'=>'gpt-4o-mini','type'=>'option','sanitize_callback'=>'sanitize_text_field']);
    $wp_customize->add_control('sf_openai_model',['section'=>'sf_ai_settings','label'=>__('Default AI Model','themeflex'),'type'=>'select','choices'=>['gpt-4o-mini'=>'GPT-4o Mini (Fast)','gpt-4o'=>'GPT-4o (Best)','gpt-3.5-turbo'=>'GPT-3.5 Turbo']]);

    // ── Preloader ──
    $wp_customize->add_section('sf_preloader_settings',['title'=>esc_html__('Preloader','themeflex'),'panel'=>'sf_advanced','priority'=>20]);
    $wp_customize->add_setting('sf_preloader_enabled',['default'=>true,'sanitize_callback'=>'rest_sanitize_boolean']);
    $wp_customize->add_control('sf_preloader_enabled',['section'=>'sf_preloader_settings','label'=>__('Enable Preloader','themeflex'),'type'=>'checkbox']);
    $wp_customize->add_setting('sf_preloader_style',['default'=>'dots','sanitize_callback'=>'sanitize_text_field']);
    $wp_customize->add_control('sf_preloader_style',['section'=>'sf_preloader_settings','label'=>__('Style','themeflex'),'type'=>'select','choices'=>['dots'=>__('Bouncing Dots','themeflex'),'bar'=>__('Progress Bar','themeflex'),'logo-only'=>__('Logo Only','themeflex')]]);

    // ── Performance ──
    $wp_customize->add_section('sf_performance_settings',['title'=>esc_html__('Performance','themeflex'),'panel'=>'sf_advanced','priority'=>30]);
    foreach([
        'sf_enable_critical_css' => ['default'=>true, 'label'=>__('Inline Critical CSS','themeflex')],
        'sf_defer_scripts'       => ['default'=>false,'label'=>__('Defer Non-Critical Scripts','themeflex')],
        'sf_lazy_load_images'    => ['default'=>true, 'label'=>__('Lazy Load Images','themeflex')],
        'sf_preload_fonts'       => ['default'=>true, 'label'=>__('Preload Google Fonts','themeflex')],
        'sf_link_prefetch'       => ['default'=>true, 'label'=>__('Prefetch Links on Hover','themeflex')],
    ] as $key => $opts) {
        $wp_customize->add_setting($key,['default'=>$opts['default'],'sanitize_callback'=>'rest_sanitize_boolean']);
        $wp_customize->add_control($key,['section'=>'sf_performance_settings','label'=>$opts['label'],'type'=>'checkbox']);
    }

    // ── SEO & Meta ──
    $wp_customize->add_section('sf_seo_settings',['title'=>esc_html__('SEO & Social Meta','themeflex'),'panel'=>'sf_advanced','priority'=>40]);
    $wp_customize->add_setting('sf_enable_og_tags',['default'=>true,'sanitize_callback'=>'rest_sanitize_boolean']);
    $wp_customize->add_control('sf_enable_og_tags',['section'=>'sf_seo_settings','label'=>__('Open Graph Tags','themeflex'),'description'=>__('Disable if using Yoast / RankMath.','themeflex'),'type'=>'checkbox']);
    $wp_customize->add_setting('sf_enable_schema',['default'=>true,'sanitize_callback'=>'rest_sanitize_boolean']);
    $wp_customize->add_control('sf_enable_schema',['section'=>'sf_seo_settings','label'=>__('Schema.org Markup','themeflex'),'type'=>'checkbox']);
    $wp_customize->add_setting('sf_site_type',['default'=>'Organization','sanitize_callback'=>'sanitize_text_field']);
    $wp_customize->add_control('sf_site_type',['section'=>'sf_seo_settings','label'=>__('Organization Type','themeflex'),'type'=>'select','choices'=>['Organization'=>'Organization','LocalBusiness'=>'LocalBusiness','Person'=>'Person']]);
    $wp_customize->add_setting('sf_og_default_image',['default'=>'','sanitize_callback'=>'esc_url_raw']);
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'sf_og_default_image',['section'=>'sf_seo_settings','label'=>__('Default Social Share Image','themeflex')]));

    // ── Typography ──
    $wp_customize->add_section('sf_typography_settings',['title'=>esc_html__('Typography','themeflex'),'panel'=>'sf_advanced','priority'=>50]);
    $wp_customize->add_setting('sf_body_font_size',['default'=>'16px','sanitize_callback'=>'sanitize_text_field']);
    $wp_customize->add_control('sf_body_font_size',['section'=>'sf_typography_settings','label'=>__('Base Font Size','themeflex'),'type'=>'text']);
    $wp_customize->add_setting('sf_body_line_height',['default'=>'1.7','sanitize_callback'=>'sanitize_text_field']);
    $wp_customize->add_control('sf_body_line_height',['section'=>'sf_typography_settings','label'=>__('Body Line Height','themeflex'),'type'=>'text']);
    $wp_customize->add_setting('sf_heading_weight',['default'=>'800','sanitize_callback'=>'sanitize_text_field']);
    $wp_customize->add_control('sf_heading_weight',['section'=>'sf_typography_settings','label'=>__('Heading Font Weight','themeflex'),'type'=>'select','choices'=>['400'=>'Regular','500'=>'Medium','600'=>'Semibold','700'=>'Bold','800'=>'Extrabold','900'=>'Black']]);
    $wp_customize->add_setting('sf_letter_spacing_headings',['default'=>'-0.02em','sanitize_callback'=>'sanitize_text_field']);
    $wp_customize->add_control('sf_letter_spacing_headings',['section'=>'sf_typography_settings','label'=>__('Heading Letter Spacing','themeflex'),'type'=>'text']);

    // ── Layout ──
    $wp_customize->add_section('sf_layout_settings',['title'=>esc_html__('Layout & Spacing','themeflex'),'panel'=>'sf_advanced','priority'=>60]);
    $wp_customize->add_setting('sf_content_width',['default'=>1290,'sanitize_callback'=>'absint']);
    $wp_customize->add_control('sf_content_width',['section'=>'sf_layout_settings','label'=>__('Container Max Width (px)','themeflex'),'type'=>'number','input_attrs'=>['min'=>900,'max'=>2000,'step'=>10]]);
    $wp_customize->add_setting('sf_sidebar_width',['default'=>370,'sanitize_callback'=>'absint']);
    $wp_customize->add_control('sf_sidebar_width',['section'=>'sf_layout_settings','label'=>__('Sidebar Width (px)','themeflex'),'type'=>'number','input_attrs'=>['min'=>200,'max'=>500]]);
    $wp_customize->add_setting('sf_global_border_radius',['default'=>8,'sanitize_callback'=>'absint']);
    $wp_customize->add_control('sf_global_border_radius',['section'=>'sf_layout_settings','label'=>__('Global Border Radius (px)','themeflex'),'type'=>'number','input_attrs'=>['min'=>0,'max'=>32]]);
    $wp_customize->add_setting('sf_button_border_radius',['default'=>10,'sanitize_callback'=>'absint']);
    $wp_customize->add_control('sf_button_border_radius',['section'=>'sf_layout_settings','label'=>__('Button Border Radius (px)','themeflex'),'type'=>'number','input_attrs'=>['min'=>0,'max'=>50]]);

    // ── Social Links ──
    $wp_customize->add_section('sf_social_links',['title'=>esc_html__('Social Links','themeflex'),'panel'=>'sf_advanced','priority'=>70]);
    foreach(['facebook','twitter','instagram','linkedin','youtube','tiktok','pinterest','github','discord'] as $soc) {
        $wp_customize->add_setting("sf_social_{$soc}",['default'=>'','sanitize_callback'=>'esc_url_raw']);
        $wp_customize->add_control("sf_social_{$soc}",['section'=>'sf_social_links','label'=>ucfirst($soc).' URL','type'=>'url','input_attrs'=>['placeholder'=>"https://{$soc}.com/yourhandle"]]);
    }

    // ── API Keys ──
    $wp_customize->add_section('sf_api_keys',['title'=>esc_html__('API Keys','themeflex'),'panel'=>'sf_advanced','priority'=>80]);
    $wp_customize->add_setting('sf_google_maps_api_key',['default'=>'','type'=>'option','sanitize_callback'=>'sanitize_text_field']);
    $wp_customize->add_control('sf_google_maps_api_key',['section'=>'sf_api_keys','label'=>__('Google Maps API Key','themeflex'),'type'=>'text']);
    $wp_customize->add_setting('sf_ga_tracking_id',['default'=>'','type'=>'option','sanitize_callback'=>'sanitize_text_field']);
    $wp_customize->add_control('sf_ga_tracking_id',['section'=>'sf_api_keys','label'=>__('Google Analytics 4 ID','themeflex'),'description'=>'G-XXXXXXXXXX','type'=>'text']);
    $wp_customize->add_setting('sf_fb_pixel_id',['default'=>'','type'=>'option','sanitize_callback'=>'sanitize_text_field']);
    $wp_customize->add_control('sf_fb_pixel_id',['section'=>'sf_api_keys','label'=>__('Meta Pixel ID','themeflex'),'type'=>'text']);

    // ── Custom Code ──
    $wp_customize->add_section('sf_custom_code',['title'=>esc_html__('Custom Code','themeflex'),'panel'=>'sf_advanced','priority'=>90]);
    $wp_customize->add_setting('sf_custom_css',['default'=>'','sanitize_callback'=>'wp_strip_all_tags']);
    $wp_customize->add_control(new WP_Customize_Code_Editor_Control($wp_customize,'sf_custom_css',['section'=>'sf_custom_code','label'=>__('Custom CSS','themeflex'),'code_type'=>'css']));
    $wp_customize->add_setting('sf_custom_js_head',['default'=>'','sanitize_callback'=>'wp_strip_all_tags']);
    $wp_customize->add_control(new WP_Customize_Code_Editor_Control($wp_customize,'sf_custom_js_head',['section'=>'sf_custom_code','label'=>__('Custom JS (Head)','themeflex'),'code_type'=>'javascript']));
    $wp_customize->add_setting('sf_custom_js_footer',['default'=>'','sanitize_callback'=>'wp_strip_all_tags']);
    $wp_customize->add_control(new WP_Customize_Code_Editor_Control($wp_customize,'sf_custom_js_footer',['section'=>'sf_custom_code','label'=>__('Custom JS (Footer)','themeflex'),'code_type'=>'javascript']));
}
add_action('customize_register','sf_register_advanced_customizer');

// Output: GA, FB Pixel, Custom CSS/JS, Typography vars
add_action('wp_head', function() {
    $ga = get_option('sf_ga_tracking_id','');
    if ($ga) {
        echo "<script async src=\"https://www.googletagmanager.com/gtag/js?id=".esc_attr($ga)."\"></script>\n";
        echo "<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','".esc_js($ga)."');</script>\n";
    }
    $fb = get_option('sf_fb_pixel_id','');
    if ($fb) {
        echo "<!-- Meta Pixel --><script>!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','".esc_js($fb)."');fbq('track','PageView');</script>\n";
    }
    $js  = get_theme_mod('sf_custom_js_head','');
    if ($js) echo "<script>".wp_strip_all_tags($js)."</script>\n";
    $css = get_theme_mod('sf_custom_css','');
    if ($css) echo "<style id=\"sf-custom-css\">".wp_strip_all_tags($css)."</style>\n";
    // Typography + Layout vars
    $vars = [];
    $map = [
        'sf_body_font_size'           => '--sf-font-size-base',
        'sf_body_line_height'         => '--sf-line-height-body',
        'sf_heading_weight'           => '--sf-font-weight-heading',
        'sf_letter_spacing_headings'  => '--sf-letter-spacing-headings',
    ];
    foreach ($map as $mod => $var) {
        $v = get_theme_mod($mod,''); if ($v) $vars[] = "{$var}:{$v};";
    }
    $cw = get_theme_mod('sf_content_width',0); if ($cw > 0) $vars[] = "--sf-content-width:{$cw}px;";
    $br = get_theme_mod('sf_global_border_radius',0); if ($br > 0) $vars[] = "--sf-border-radius:{$br}px; --sf-woo-radius:{$br}px;";
    $brbtn = get_theme_mod('sf_button_border_radius',0); if ($brbtn > 0) $vars[] = "--sf-border-radius-button:{$brbtn}px;";
    if ($vars) echo "<style>:root{".implode('',$vars)."}</style>\n";
}, 99);

add_action('wp_footer', function() {
    $js = get_theme_mod('sf_custom_js_footer','');
    if ($js) echo "<script>".wp_strip_all_tags($js)."</script>\n";
}, 99);
