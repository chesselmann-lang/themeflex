/**
 * Custom JavaScript Features
 * Vanilla JS - No jQuery dependency
 * Starter Flavor Theme
 */

(function() {
  'use strict';

  /**
   * Initialize Custom Features
   */
  function init() {
    setupLazyLoading();
    setupSmoothRevealAnimations();
    setupLightbox();
    setupMasonryGrid();
    setupResponsiveTables();
    setupVideoEmbedLazyLoad();
    setupCommentFormValidation();
    setupCookieConsent();
    setupInfiniteScroll();
  }

  /**
   * Lazy Loading for Images
   * Uses IntersectionObserver with fallback
   */
  function setupLazyLoading() {
    const images = document.querySelectorAll('img[data-lazy]');
    if (!images.length) return;

    // Check if IntersectionObserver is supported
    if ('IntersectionObserver' in window) {
      const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const img = entry.target;
            const src = img.getAttribute('data-lazy');
            const srcset = img.getAttribute('data-lazy-srcset');

            if (src) {
              img.src = src;
            }
            if (srcset) {
              img.srcset = srcset;
            }

            img.removeAttribute('data-lazy');
            img.removeAttribute('data-lazy-srcset');
            img.classList.add('loaded');

            observer.unobserve(img);
          }
        });
      }, {
        rootMargin: '50px',
      });

      images.forEach(img => {
        imageObserver.observe(img);
      });
    } else {
      // Fallback for older browsers
      images.forEach(img => {
        const src = img.getAttribute('data-lazy');
        if (src) {
          img.src = src;
          img.removeAttribute('data-lazy');
        }
      });
    }
  }

  /**
   * Smooth Reveal Animations on Scroll
   * Uses IntersectionObserver for fade-up, fade-left, fade-right
   */
  function setupSmoothRevealAnimations() {
    const revealElements = document.querySelectorAll(
      '[data-reveal], .reveal-fade-up, .reveal-fade-left, .reveal-fade-right'
    );

    if (!revealElements.length) return;

    if ('IntersectionObserver' in window) {
      const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('revealed');
            revealObserver.unobserve(entry.target);
          }
        });
      }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px',
      });

      revealElements.forEach(el => {
        revealObserver.observe(el);

        // Set animation type
        if (el.hasAttribute('data-reveal-type')) {
          const type = el.getAttribute('data-reveal-type');
          el.classList.add(`reveal-${type}`);
        }
      });

      // Inject animation styles if not already present
      if (!document.querySelector('style[data-reveal-animations]')) {
        injectRevealAnimations();
      }
    }
  }

  /**
   * Inject Reveal Animation Styles
   */
  function injectRevealAnimations() {
    const style = document.createElement('style');
    style.setAttribute('data-reveal-animations', '');
    style.textContent = `
      [data-reveal], .reveal-fade-up, .reveal-fade-left, .reveal-fade-right {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.6s ease-out, transform 0.6s ease-out;
      }

      [data-reveal].revealed, .revealed.reveal-fade-up {
        opacity: 1;
        transform: translateY(0);
      }

      .reveal-fade-left {
        transform: translateX(-20px);
      }

      .reveal-fade-left.revealed {
        transform: translateX(0);
      }

      .reveal-fade-right {
        transform: translateX(20px);
      }

      .reveal-fade-right.revealed {
        transform: translateX(0);
      }
    `;
    document.head.appendChild(style);
  }

  /**
   * Lightbox for Images and Galleries
   * Simple modal with keyboard support and prev/next navigation
   */
  function setupLightbox() {
    const lightboxLinks = document.querySelectorAll('a[href$=".jpg"], a[href$=".png"], a[href$=".gif"], a[data-lightbox]');

    if (!lightboxLinks.length) return;

    // Create lightbox HTML
    const lightboxHTML = `
      <div class="lightbox-overlay" id="lightbox-overlay">
        <div class="lightbox-container">
          <button class="lightbox-close" aria-label="Close lightbox">&times;</button>
          <button class="lightbox-prev" aria-label="Previous image">&#10094;</button>
          <div class="lightbox-content">
            <img src="" alt="" class="lightbox-image">
          </div>
          <button class="lightbox-next" aria-label="Next image">&#10095;</button>
          <div class="lightbox-counter">
            <span class="lightbox-current">1</span> / <span class="lightbox-total">1</span>
          </div>
        </div>
      </div>
    `;

    // Inject lightbox HTML
    if (!document.getElementById('lightbox-overlay')) {
      document.body.insertAdjacentHTML('beforeend', lightboxHTML);
    }

    // Inject lightbox styles if not present
    if (!document.querySelector('style[data-lightbox-styles]')) {
      injectLightboxStyles();
    }

    const overlay = document.getElementById('lightbox-overlay');
    const image = overlay.querySelector('.lightbox-image');
    const closeBtn = overlay.querySelector('.lightbox-close');
    const prevBtn = overlay.querySelector('.lightbox-prev');
    const nextBtn = overlay.querySelector('.lightbox-next');
    const counter = overlay.querySelector('.lightbox-counter');
    let currentIndex = 0;
    let images = [];
    let currentGroup = null;

    // Open lightbox
    lightboxLinks.forEach((link, index) => {
      link.addEventListener('click', function(e) {
        e.preventDefault();

        const group = link.getAttribute('data-lightbox') || 'default';
        const groupLinks = document.querySelectorAll(`a[href$=".jpg"], a[href$=".png"], a[href$=".gif"], a[data-lightbox="${group}"]`);

        images = Array.from(groupLinks).map(l => ({
          src: l.getAttribute('href'),
          alt: l.getAttribute('alt') || 'Image',
        }));

        currentIndex = Array.from(groupLinks).indexOf(link);
        currentGroup = group;

        showImage(currentIndex);
        overlay.classList.add('active');
        document.body.style.overflow = 'hidden';
      });
    });

    // Show image
    function showImage(index) {
      if (index < 0) index = images.length - 1;
      if (index >= images.length) index = 0;

      currentIndex = index;
      image.src = images[index].src;
      image.alt = images[index].alt;

      overlay.querySelector('.lightbox-current').textContent = index + 1;
      overlay.querySelector('.lightbox-total').textContent = images.length;
    }

    // Close lightbox
    function closeLightbox() {
      overlay.classList.remove('active');
      document.body.style.overflow = '';
    }

    closeBtn.addEventListener('click', closeLightbox);
    overlay.addEventListener('click', function(e) {
      if (e.target === overlay) {
        closeLightbox();
      }
    });

    // Navigation
    prevBtn.addEventListener('click', () => showImage(currentIndex - 1));
    nextBtn.addEventListener('click', () => showImage(currentIndex + 1));

    // Keyboard navigation
    document.addEventListener('keydown', function(e) {
      if (!overlay.classList.contains('active')) return;

      if (e.key === 'ArrowLeft') showImage(currentIndex - 1);
      if (e.key === 'ArrowRight') showImage(currentIndex + 1);
      if (e.key === 'Escape') closeLightbox();
    });
  }

  /**
   * Inject Lightbox Styles
   */
  function injectLightboxStyles() {
    const style = document.createElement('style');
    style.setAttribute('data-lightbox-styles', '');
    style.textContent = `
      .lightbox-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(0, 0, 0, 0.9);
        z-index: 9999;
        opacity: 0;
        transition: opacity 0.3s ease;
      }

      .lightbox-overlay.active {
        display: flex;
        opacity: 1;
      }

      .lightbox-container {
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 100%;
        height: 100%;
      }

      .lightbox-content {
        display: flex;
        align-items: center;
        justify-content: center;
        max-width: 90vw;
        max-height: 90vh;
      }

      .lightbox-image {
        max-width: 100%;
        max-height: 85vh;
        object-fit: contain;
      }

      .lightbox-close,
      .lightbox-prev,
      .lightbox-next {
        position: absolute;
        background: rgba(255, 255, 255, 0.3);
        color: white;
        border: none;
        font-size: 30px;
        cursor: pointer;
        padding: 10px 15px;
        transition: background-color 0.3s ease;
        z-index: 10000;
      }

      .lightbox-close:hover,
      .lightbox-prev:hover,
      .lightbox-next:hover {
        background: rgba(255, 255, 255, 0.6);
      }

      .lightbox-close {
        top: 20px;
        right: 20px;
      }

      .lightbox-prev {
        left: 20px;
        top: 50%;
        transform: translateY(-50%);
      }

      .lightbox-next {
        right: 20px;
        top: 50%;
        transform: translateY(-50%);
      }

      .lightbox-counter {
        position: absolute;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        color: white;
        background: rgba(0, 0, 0, 0.5);
        padding: 10px 20px;
        border-radius: 20px;
        font-size: 14px;
      }

      @media (max-width: 600px) {
        .lightbox-prev,
        .lightbox-next {
          font-size: 20px;
          padding: 8px 12px;
        }
      }
    `;
    document.head.appendChild(style);
  }

  /**
   * Masonry Grid Layout
   * CSS-based using CSS columns, no library dependency
   */
  function setupMasonryGrid() {
    const masonryElements = document.querySelectorAll('[data-masonry]');

    if (!masonryElements.length) return;

    if (!document.querySelector('style[data-masonry-styles]')) {
      injectMasonryStyles();
    }

    masonryElements.forEach(element => {
      const columns = element.getAttribute('data-masonry-columns') || '3';
      element.style.columnCount = columns;
    });

    // Update on window resize
    let resizeTimeout;
    window.addEventListener('resize', () => {
      clearTimeout(resizeTimeout);
      resizeTimeout = setTimeout(() => {
        masonryElements.forEach(element => {
          const columns = element.getAttribute('data-masonry-columns') || '3';
          element.style.columnCount = columns;
        });
      }, 250);
    });
  }

  /**
   * Inject Masonry Styles
   */
  function injectMasonryStyles() {
    const style = document.createElement('style');
    style.setAttribute('data-masonry-styles', '');
    style.textContent = `
      [data-masonry] {
        column-gap: var(--sf-spacing-lg, 32px);
      }

      [data-masonry] > * {
        break-inside: avoid;
        margin-bottom: var(--sf-spacing-lg, 32px);
      }

      @media (max-width: 768px) {
        [data-masonry] {
          column-count: 2 !important;
        }
      }

      @media (max-width: 576px) {
        [data-masonry] {
          column-count: 1 !important;
        }
      }
    `;
    document.head.appendChild(style);
  }

  /**
   * Responsive Tables
   * Wrap in scrollable container on mobile
   */
  function setupResponsiveTables() {
    const tables = document.querySelectorAll('table:not(.wp-block-table table)');

    tables.forEach(table => {
      if (table.closest('.table-responsive')) return;

      const wrapper = document.createElement('div');
      wrapper.className = 'table-responsive';
      table.parentNode.insertBefore(wrapper, table);
      wrapper.appendChild(table);
    });
  }

  /**
   * Video Embed Lazy Load
   * Click to load iframe
   */
  function setupVideoEmbedLazyLoad() {
    const videoContainers = document.querySelectorAll('[data-video-lazy]');

    if (!videoContainers.length) return;

    if (!document.querySelector('style[data-video-lazy-styles]')) {
      injectVideoLazyStyles();
    }

    videoContainers.forEach(container => {
      const videoId = container.getAttribute('data-video-lazy');
      const platform = container.getAttribute('data-video-platform') || 'youtube';
      let src = '';

      if (platform === 'youtube') {
        src = `https://www.youtube.com/embed/${videoId}`;
      } else if (platform === 'vimeo') {
        src = `https://player.vimeo.com/video/${videoId}`;
      }

      // Create play button
      const playBtn = document.createElement('button');
      playBtn.className = 'video-play-btn';
      playBtn.setAttribute('aria-label', 'Play video');
      playBtn.innerHTML = '▶';
      container.appendChild(playBtn);

      playBtn.addEventListener('click', (e) => {
        e.preventDefault();

        // Create iframe
        const iframe = document.createElement('iframe');
        iframe.src = src;
        iframe.width = '100%';
        iframe.height = '100%';
        iframe.frameborder = '0';
        iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
        iframe.allowFullscreen = true;

        container.innerHTML = '';
        container.appendChild(iframe);
      });
    });
  }

  /**
   * Inject Video Lazy Load Styles
   */
  function injectVideoLazyStyles() {
    const style = document.createElement('style');
    style.setAttribute('data-video-lazy-styles', '');
    style.textContent = `
      [data-video-lazy] {
        position: relative;
        width: 100%;
        padding-bottom: 56.25%;
        background: #000;
        overflow: hidden;
        border-radius: 8px;
      }

      [data-video-lazy] iframe {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
      }

      .video-play-btn {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 80px;
        height: 80px;
        background: rgba(255, 94, 46, 0.8);
        color: white;
        border: none;
        border-radius: 50%;
        font-size: 32px;
        cursor: pointer;
        z-index: 10;
        transition: background-color 0.3s ease;
      }

      .video-play-btn:hover {
        background: rgba(255, 94, 46, 1);
      }
    `;
    document.head.appendChild(style);
  }

  /**
   * Comment Form Validation
   */
  function setupCommentFormValidation() {
    const commentForm = document.querySelector('.comment-form, #commentform');
    if (!commentForm) return;

    commentForm.addEventListener('submit', function(e) {
      const author = commentForm.querySelector('[name="author"]');
      const email = commentForm.querySelector('[name="email"]');
      const comment = commentForm.querySelector('[name="comment"]');

      let isValid = true;

      // Validate author
      if (author && !author.value.trim()) {
        author.classList.add('error');
        isValid = false;
      } else if (author) {
        author.classList.remove('error');
      }

      // Validate email
      if (email && email.value && !isValidEmail(email.value)) {
        email.classList.add('error');
        isValid = false;
      } else if (email) {
        email.classList.remove('error');
      }

      // Validate comment
      if (comment && !comment.value.trim()) {
        comment.classList.add('error');
        isValid = false;
      } else if (comment) {
        comment.classList.remove('error');
      }

      if (!isValid) {
        e.preventDefault();
      }
    });
  }

  /**
   * Validate Email Format
   */
  function isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  }

  /**
   * Cookie Consent Banner
   * Simple GDPR-compliant banner
   */
  function setupCookieConsent() {
    const consentRequired = document.body.getAttribute('data-cookie-consent');
    if (consentRequired !== 'true') return;

    const consentKey = 'starter-flavor-cookie-consent';
    const hasConsent = localStorage.getItem(consentKey);

    if (hasConsent) return;

    const bannerHTML = `
      <div class="cookie-consent-banner">
        <div class="cookie-consent-content">
          <p>We use cookies to enhance your experience. By continuing to browse this site you agree to our use of cookies.</p>
        </div>
        <div class="cookie-consent-buttons">
          <button class="cookie-accept-btn">Accept</button>
          <button class="cookie-decline-btn">Decline</button>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('afterbegin', bannerHTML);

    if (!document.querySelector('style[data-cookie-styles]')) {
      injectCookieStyles();
    }

    const banner = document.querySelector('.cookie-consent-banner');
    const acceptBtn = banner.querySelector('.cookie-accept-btn');
    const declineBtn = banner.querySelector('.cookie-decline-btn');

    function handleConsent(accepted) {
      localStorage.setItem(consentKey, accepted ? 'accepted' : 'declined');
      banner.classList.add('hidden');
      setTimeout(() => banner.remove(), 300);
    }

    acceptBtn.addEventListener('click', () => handleConsent(true));
    declineBtn.addEventListener('click', () => handleConsent(false));
  }

  /**
   * Inject Cookie Styles
   */
  function injectCookieStyles() {
    const style = document.createElement('style');
    style.setAttribute('data-cookie-styles', '');
    style.textContent = `
      .cookie-consent-banner {
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background: var(--sf-color-bg-secondary, #F6F7F1);
        border-top: 1px solid var(--sf-color-border, #E5E7DE);
        padding: 20px;
        z-index: 9998;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 20px;
        animation: slideUp 0.3s ease-out;
      }

      @keyframes slideUp {
        from {
          transform: translateY(100%);
        }
        to {
          transform: translateY(0);
        }
      }

      .cookie-consent-banner.hidden {
        animation: slideDown 0.3s ease-out forwards;
      }

      @keyframes slideDown {
        from {
          transform: translateY(0);
        }
        to {
          transform: translateY(100%);
        }
      }

      .cookie-consent-content p {
        margin: 0;
        font-size: 14px;
        color: var(--sf-color-text, #86898C);
      }

      .cookie-consent-buttons {
        display: flex;
        gap: 10px;
        flex-shrink: 0;
      }

      .cookie-accept-btn,
      .cookie-decline-btn {
        padding: 10px 20px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 14px;
        font-weight: 500;
        transition: all 0.3s ease;
      }

      .cookie-accept-btn {
        background: var(--sf-color-link, #FF5E2E);
        color: white;
      }

      .cookie-accept-btn:hover {
        background: var(--sf-color-link-hover, #ED4C1C);
      }

      .cookie-decline-btn {
        background: transparent;
        color: var(--sf-color-text, #86898C);
        border: 1px solid var(--sf-color-border, #E5E7DE);
      }

      .cookie-decline-btn:hover {
        border-color: var(--sf-color-text, #86898C);
      }

      @media (max-width: 600px) {
        .cookie-consent-banner {
          flex-direction: column;
          align-items: stretch;
        }

        .cookie-consent-buttons {
          width: 100%;
        }

        .cookie-consent-buttons button {
          flex: 1;
        }
      }
    `;
    document.head.appendChild(style);
  }

  /**
   * Infinite Scroll for Blog
   */
  function setupInfiniteScroll() {
    const infiniteContainer = document.querySelector('[data-infinite-scroll]');
    if (!infiniteContainer) return;

    let isLoading = false;
    let hasMore = true;
    let page = 1;

    const postsPerPage = infiniteContainer.getAttribute('data-posts-per-page') || '10';
    const ajaxUrl = infiniteContainer.getAttribute('data-ajax-url');
    const nonce = infiniteContainer.getAttribute('data-nonce');

    if (!ajaxUrl) return;

    const observer = new IntersectionObserver(
      entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting && !isLoading && hasMore) {
            loadMorePosts();
          }
        });
      },
      { rootMargin: '100px' }
    );

    const sentinel = document.createElement('div');
    sentinel.className = 'infinite-scroll-sentinel';
    infiniteContainer.appendChild(sentinel);
    observer.observe(sentinel);

    function loadMorePosts() {
      if (isLoading) return;

      isLoading = true;
      page++;

      const formData = new FormData();
      formData.append('action', 'load_more_posts');
      formData.append('page', page);
      formData.append('posts_per_page', postsPerPage);
      formData.append('nonce', nonce);

      fetch(ajaxUrl, {
        method: 'POST',
        body: formData,
      })
        .then(response => response.json())
        .then(data => {
          if (data.success && data.html) {
            infiniteContainer.insertAdjacentHTML(
              'beforeend',
              data.html
            );

            if (!data.has_more) {
              hasMore = false;
            }
          }
          isLoading = false;
        })
        .catch(error => {
          console.error('Error loading more posts:', error);
          isLoading = false;
        });
    }
  }

  /**
   * Initialize on DOM Ready
   */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Expose public API
  window.StarterFlavorCustom = {
    setupLazyLoading: setupLazyLoading,
    setupLightbox: setupLightbox,
    setupMasonryGrid: setupMasonryGrid,
  };

})();
