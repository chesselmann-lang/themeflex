/**
 * Customizer Preview
 * Live preview for WordPress Customizer settings
 * Real-time updates without page reload
 * Starter Flavor Theme
 */

(function() {
  'use strict';

  // Make sure wp.customize is available
  if (typeof wp === 'undefined' || typeof wp.customize === 'undefined') {
    return;
  }

  const api = wp.customize;

  /**
   * Initialize Customizer Preview Bindings
   */
  api.bind('preview-ready', function() {
    // Color Settings
    bindColorSettings();

    // Typography Settings
    bindTypographySettings();

    // Layout Settings
    bindLayoutSettings();

    // Header Settings
    bindHeaderSettings();

    // Footer Settings
    bindFooterSettings();

    // Blog Settings
    bindBlogSettings();
  });

  /**
   * Bind Color Settings to CSS Custom Properties
   */
  function bindColorSettings() {
    const colorSettings = [
      { settingId: 'sf_color_bg', cssVar: '--sf-color-bg' },
      { settingId: 'sf_color_bg_secondary', cssVar: '--sf-color-bg-secondary' },
      { settingId: 'sf_color_border', cssVar: '--sf-color-border' },
      { settingId: 'sf_color_title', cssVar: '--sf-color-title' },
      { settingId: 'sf_color_text', cssVar: '--sf-color-text' },
      { settingId: 'sf_color_meta', cssVar: '--sf-color-meta' },
      { settingId: 'sf_color_link', cssVar: '--sf-color-link' },
      { settingId: 'sf_color_link_hover', cssVar: '--sf-color-link-hover' },
    ];

    colorSettings.forEach(function(setting) {
      api(setting.settingId, function(value) {
        value.bind(function(newValue) {
          document.documentElement.style.setProperty(
            setting.cssVar,
            newValue
          );
        });
      });
    });
  }

  /**
   * Bind Typography Settings
   */
  function bindTypographySettings() {
    // Font Families
    const fontFamilySettings = [
      { settingId: 'sf_font_body', cssVar: '--sf-font-body' },
      { settingId: 'sf_font_headings', cssVar: '--sf-font-headings' },
    ];

    fontFamilySettings.forEach(function(setting) {
      api(setting.settingId, function(value) {
        value.bind(function(newValue) {
          // Format font family string
          const fontFamily = formatFontFamily(newValue);
          document.documentElement.style.setProperty(
            setting.cssVar,
            fontFamily
          );
        });
      });
    });

    // Font Sizes
    const fontSizeSettings = [
      { settingId: 'sf_font_size_h1', cssVar: '--sf-font-size-h1' },
      { settingId: 'sf_font_size_h2', cssVar: '--sf-font-size-h2' },
      { settingId: 'sf_font_size_h3', cssVar: '--sf-font-size-h3' },
      { settingId: 'sf_font_size_h4', cssVar: '--sf-font-size-h4' },
      { settingId: 'sf_font_size_h5', cssVar: '--sf-font-size-h5' },
      { settingId: 'sf_font_size_h6', cssVar: '--sf-font-size-h6' },
      { settingId: 'sf_font_size_body', cssVar: '--sf-font-size-body' },
      { settingId: 'sf_font_size_small', cssVar: '--sf-font-size-small' },
    ];

    fontSizeSettings.forEach(function(setting) {
      api(setting.settingId, function(value) {
        value.bind(function(newValue) {
          document.documentElement.style.setProperty(
            setting.cssVar,
            newValue + 'px'
          );
        });
      });
    });

    // Font Weights
    const fontWeightSettings = [
      { settingId: 'sf_font_weight_normal', cssVar: '--sf-font-weight-normal' },
      { settingId: 'sf_font_weight_medium', cssVar: '--sf-font-weight-medium' },
      { settingId: 'sf_font_weight_semibold', cssVar: '--sf-font-weight-semibold' },
      { settingId: 'sf_font_weight_bold', cssVar: '--sf-font-weight-bold' },
    ];

    fontWeightSettings.forEach(function(setting) {
      api(setting.settingId, function(value) {
        value.bind(function(newValue) {
          document.documentElement.style.setProperty(
            setting.cssVar,
            newValue
          );
        });
      });
    });

    // Line Heights
    const lineHeightSettings = [
      { settingId: 'sf_line_height_body', cssVar: '--sf-line-height-body' },
      { settingId: 'sf_line_height_headings', cssVar: '--sf-line-height-headings' },
      { settingId: 'sf_line_height_tight', cssVar: '--sf-line-height-tight' },
    ];

    lineHeightSettings.forEach(function(setting) {
      api(setting.settingId, function(value) {
        value.bind(function(newValue) {
          document.documentElement.style.setProperty(
            setting.cssVar,
            newValue
          );
        });
      });
    });
  }

  /**
   * Bind Layout Settings
   */
  function bindLayoutSettings() {
    const layoutSettings = [
      { settingId: 'sf_content_width', cssVar: '--sf-content-width' },
      { settingId: 'sf_sidebar_width', cssVar: '--sf-sidebar-width' },
      { settingId: 'sf_gap', cssVar: '--sf-gap' },
      { settingId: 'sf_container_max_width', cssVar: '--sf-container-max-width' },
    ];

    layoutSettings.forEach(function(setting) {
      api(setting.settingId, function(value) {
        value.bind(function(newValue) {
          document.documentElement.style.setProperty(
            setting.cssVar,
            newValue + 'px'
          );
        });
      });
    });
  }

  /**
   * Bind Header Settings
   */
  function bindHeaderSettings() {
    // Header Logo
    api('sf_logo', function(value) {
      value.bind(function(newValue) {
        const logo = document.querySelector('.site-logo');
        if (logo) {
          if (newValue) {
            logo.src = newValue;
            logo.style.display = 'block';
          } else {
            logo.style.display = 'none';
          }
        }
      });
    });

    // Header Background Color
    api('sf_header_bg_color', function(value) {
      value.bind(function(newValue) {
        const header = document.querySelector('.site-header');
        if (header) {
          header.style.backgroundColor = newValue;
        }
      });
    });

    // Header Text Color
    api('sf_header_text_color', function(value) {
      value.bind(function(newValue) {
        const header = document.querySelector('.site-header');
        if (header) {
          header.style.color = newValue;
        }
      });
    });
  }

  /**
   * Bind Footer Settings
   */
  function bindFooterSettings() {
    // Footer Background Color
    api('sf_footer_bg_color', function(value) {
      value.bind(function(newValue) {
        const footer = document.querySelector('.site-footer');
        if (footer) {
          footer.style.backgroundColor = newValue;
        }
      });
    });

    // Footer Text Color
    api('sf_footer_text_color', function(value) {
      value.bind(function(newValue) {
        const footer = document.querySelector('.site-footer');
        if (footer) {
          footer.style.color = newValue;
        }
      });
    });

    // Footer Widget Columns
    api('sf_footer_widget_columns', function(value) {
      value.bind(function(newValue) {
        const footerWidgets = document.querySelector('.footer-widgets');
        if (footerWidgets) {
          footerWidgets.style.gridTemplateColumns = `repeat(${newValue}, 1fr)`;
        }
      });
    });
  }

  /**
   * Bind Blog Settings
   */
  function bindBlogSettings() {
    // Blog Grid Columns
    api('sf_blog_grid_columns', function(value) {
      value.bind(function(newValue) {
        const blogGrid = document.querySelector('.blog-grid, .posts-grid');
        if (blogGrid) {
          blogGrid.style.gridTemplateColumns = `repeat(${newValue}, 1fr)`;
        }
      });
    });

    // Blog Post Excerpt Length
    api('sf_blog_excerpt_length', function(value) {
      value.bind(function(newValue) {
        // This would require updating via AJAX on the front-end
        // as text content can't be changed directly via CSS
        // This is a note for implementation in actual post rendering
      });
    });

    // Featured Image Height
    api('sf_featured_image_height', function(value) {
      value.bind(function(newValue) {
        const featuredImages = document.querySelectorAll(
          '.post-featured-image, .featured-image'
        );
        featuredImages.forEach(function(img) {
          img.style.height = newValue + 'px';
          img.style.objectFit = 'cover';
        });
      });
    });
  }

  /**
   * Format Font Family String
   * Ensures proper formatting for Google Fonts and system fonts
   */
  function formatFontFamily(fontFamily) {
    // If it's already a valid font family string, return it
    if (fontFamily) {
      // Add quotes if it contains spaces and isn't already quoted
      if (
        fontFamily.includes(' ') &&
        !fontFamily.startsWith("'") &&
        !fontFamily.startsWith('"')
      ) {
        return `'${fontFamily}'`;
      }
      return fontFamily;
    }
    return 'inherit';
  }

  /**
   * Utility: Update CSS Variable
   * Can be called from other scripts if needed
   */
  window.StarterFlavorCustomizer = {
    setCSSVariable: function(varName, value) {
      document.documentElement.style.setProperty(varName, value);
    },
    getCSSVariable: function(varName) {
      return getComputedStyle(document.documentElement)
        .getPropertyValue(varName)
        .trim();
    },
  };

})();
