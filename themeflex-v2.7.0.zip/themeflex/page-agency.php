<?php
/**
 * Template Name: Agency Homepage
 * Template Post Type: page
 *
 * Premium dark-first Agency landing page — split hero, client logos, bento
 * services grid, portfolio preview, process steps, testimonials, CTA banner.
 * Zero Elementor dependency. Vanilla CSS + minimal inline JS.
 *
 * @package ThemeFlex
 * @since   1.4.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
get_header(); ?>

<main id="primary" class="tf-ag-main" aria-label="<?php esc_attr_e( 'Agency Homepage', 'themeflex' ); ?>">
<style>
/* ══════════════════════════════════════════════════════════════════════
   ThemeFlex — Agency Homepage Template
   Dark-first, zero dependencies, responsive 3 → 2 → 1 col
   ══════════════════════════════════════════════════════════════════════ */

.tf-ag-main {
  --tc:     #ff5e2e;
  --tc2:    #00d4ff;
  --tc3:    #a855f7;
  --tc4:    #22d3ee;
  --bg:     #06021d;
  --bg2:    #0d1526;
  --bg3:    #111827;
  --border: rgba(255,255,255,.07);
  --title:  #f1f5f9;
  --txt:    #94a3b8;
  --meta:   #64748b;
  --r:      16px;
  font-family: 'Inter Tight', system-ui, sans-serif;
  background: var(--bg);
  color: var(--txt);
  overflow-x: hidden;
}
.tf-ag-main * { box-sizing: border-box; margin: 0; padding: 0; }
.tf-ag-wrap { max-width: 1200px; margin: 0 auto; padding: 0 24px; }

/* ── Section helpers ─────────────────────────────────────────────── */
.tf-ag-section-label {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.22);
  color: var(--tc); font-size: .7rem; font-weight: 800;
  letter-spacing: .14em; text-transform: uppercase;
  padding: 6px 18px; border-radius: 100px; margin-bottom: 18px;
}
.tf-ag-section-head {
  text-align: center; margin-bottom: 56px;
}
.tf-ag-section-head h2 {
  font-size: clamp(1.8rem, 3.5vw, 2.8rem); font-weight: 900;
  color: var(--title); line-height: 1.15; margin: 0 0 14px;
}
.tf-ag-section-head p {
  font-size: 1.05rem; color: var(--txt); max-width: 560px;
  margin: 0 auto; line-height: 1.75;
}

/* ══════════════════════════════════════════════════════════════════════
   1 · SPLIT HERO
   ══════════════════════════════════════════════════════════════════════ */
.tf-ag-hero {
  position: relative; overflow: hidden;
  padding: 120px 0 100px;
  background:
    radial-gradient(ellipse 70% 55% at 25% 40%, rgba(255,94,46,.14) 0%, transparent 65%),
    radial-gradient(ellipse 50% 50% at 80% 20%, rgba(168,85,247,.08) 0%, transparent 60%),
    var(--bg);
  min-height: 90vh; display: flex; align-items: center;
}
/* dot-grid backdrop */
.tf-ag-hero::before {
  content: ''; position: absolute; inset: 0; pointer-events: none;
  background-image: radial-gradient(rgba(255,255,255,.035) 1px, transparent 1px);
  background-size: 38px 38px;
}
.tf-ag-hero-inner {
  display: grid; grid-template-columns: 3fr 2fr;
  gap: 56px; align-items: center; position: relative; z-index: 1;
}

/* — Left copy column — */
.tf-ag-hero-copy { }
.tf-ag-hero-badge {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.25);
  color: var(--tc); font-size: .7rem; font-weight: 800;
  letter-spacing: .14em; text-transform: uppercase;
  padding: 7px 20px; border-radius: 100px; margin-bottom: 28px;
}
.tf-ag-hero-badge svg { width: 13px; height: 13px; flex-shrink: 0; }
.tf-ag-hero-h1 {
  font-size: clamp(2.6rem, 5vw, 4rem); font-weight: 900;
  color: var(--title); line-height: 1.08; letter-spacing: -.6px;
  margin-bottom: 22px;
}
.tf-ag-hero-h1 .tf-gradient {
  background: linear-gradient(90deg, #ff5e2e 0%, #ff8c5a 45%, #ffb347 100%);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  background-clip: text;
}
.tf-ag-hero-sub {
  font-size: 1.1rem; color: var(--txt); line-height: 1.75;
  max-width: 520px; margin-bottom: 36px;
}
.tf-ag-hero-ctas {
  display: flex; gap: 14px; flex-wrap: wrap; margin-bottom: 52px;
}
.tf-ag-btn-primary {
  display: inline-flex; align-items: center; gap: 9px;
  padding: 15px 32px; background: var(--tc); color: #fff;
  border-radius: 12px; font-size: .95rem; font-weight: 700;
  text-decoration: none; letter-spacing: .02em;
  box-shadow: 0 8px 28px rgba(255,94,46,.35);
  transition: transform .2s, box-shadow .2s;
}
.tf-ag-btn-primary:hover { transform: translateY(-2px); box-shadow: 0 12px 36px rgba(255,94,46,.45); }
.tf-ag-btn-primary svg { width: 17px; height: 17px; }
.tf-ag-btn-ghost {
  display: inline-flex; align-items: center; gap: 9px;
  padding: 14px 28px; background: rgba(255,255,255,.05);
  color: var(--title); border-radius: 12px; font-size: .95rem; font-weight: 600;
  text-decoration: none; border: 1px solid var(--border);
  transition: background .2s, border-color .2s;
}
.tf-ag-btn-ghost:hover { background: rgba(255,255,255,.09); border-color: rgba(255,255,255,.14); }
.tf-ag-btn-ghost svg { width: 17px; height: 17px; }

/* Stats row */
.tf-ag-hero-stats {
  display: flex; gap: 0; border: 1px solid var(--border);
  border-radius: 16px; background: rgba(255,255,255,.025);
  overflow: hidden;
}
.tf-ag-stat {
  flex: 1; text-align: center; padding: 20px 16px;
  border-right: 1px solid var(--border);
}
.tf-ag-stat:last-child { border-right: none; }
.tf-ag-stat-num {
  font-size: 1.8rem; font-weight: 900; color: var(--tc);
  line-height: 1; margin-bottom: 5px;
}
.tf-ag-stat-label {
  font-size: .72rem; font-weight: 700; color: var(--meta);
  text-transform: uppercase; letter-spacing: .08em;
}

/* — Right browser mockup — */
.tf-ag-hero-visual { position: relative; }
.tf-ag-browser {
  background: #0d1117; border: 1px solid rgba(255,255,255,.1);
  border-radius: 14px; overflow: hidden;
  box-shadow: 0 32px 80px rgba(0,0,0,.6), 0 0 0 1px rgba(255,255,255,.04);
  transform: perspective(900px) rotateY(-4deg) rotateX(2deg);
  transition: transform .4s;
}
.tf-ag-browser:hover { transform: perspective(900px) rotateY(-2deg) rotateX(1deg); }
/* chrome bar */
.tf-ag-browser-chrome {
  background: #161b22; padding: 12px 16px;
  display: flex; align-items: center; gap: 12px;
  border-bottom: 1px solid rgba(255,255,255,.07);
}
.tf-ag-browser-dots { display: flex; gap: 6px; }
.tf-ag-browser-dots span {
  width: 10px; height: 10px; border-radius: 50%;
}
.tf-ag-browser-dots span:nth-child(1) { background: #ff5f57; }
.tf-ag-browser-dots span:nth-child(2) { background: #ffbd2e; }
.tf-ag-browser-dots span:nth-child(3) { background: #28ca41; }
.tf-ag-browser-url {
  flex: 1; background: rgba(255,255,255,.05); border: 1px solid rgba(255,255,255,.07);
  border-radius: 6px; padding: 5px 12px; font-size: .68rem;
  color: var(--meta); font-family: monospace; white-space: nowrap;
  overflow: hidden; text-overflow: ellipsis;
}
/* dashboard content */
.tf-ag-dashboard {
  padding: 20px; background: #0d1117; min-height: 320px;
}
/* metric cards row */
.tf-ag-dash-metrics {
  display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 16px;
}
.tf-ag-dash-metric {
  background: #161b22; border: 1px solid rgba(255,255,255,.07);
  border-radius: 10px; padding: 12px;
}
.tf-ag-dash-metric-label {
  font-size: .6rem; color: var(--meta); font-weight: 600;
  text-transform: uppercase; letter-spacing: .07em; margin-bottom: 4px;
}
.tf-ag-dash-metric-val {
  font-size: 1.1rem; font-weight: 900; color: var(--title); line-height: 1;
  margin-bottom: 3px;
}
.tf-ag-dash-metric-delta {
  font-size: .6rem; font-weight: 700; color: #22d3ee;
}
/* bar chart */
.tf-ag-dash-chart {
  background: #161b22; border: 1px solid rgba(255,255,255,.07);
  border-radius: 10px; padding: 14px; margin-bottom: 16px;
}
.tf-ag-dash-chart-title {
  font-size: .65rem; font-weight: 700; color: var(--txt);
  margin-bottom: 12px; text-transform: uppercase; letter-spacing: .07em;
}
.tf-ag-bars {
  display: flex; align-items: flex-end; gap: 6px; height: 64px;
}
.tf-ag-bar {
  flex: 1; border-radius: 4px 4px 0 0;
  background: rgba(255,94,46,.18);
  transition: background .3s;
  position: relative;
}
.tf-ag-bar.active { background: var(--tc); }
.tf-ag-bar::after {
  content: ''; position: absolute; top: 0; left: 0; right: 0;
  height: 2px; background: rgba(255,255,255,.25); border-radius: 4px 4px 0 0;
}
/* mini line graph */
.tf-ag-dash-graph {
  background: #161b22; border: 1px solid rgba(255,255,255,.07);
  border-radius: 10px; padding: 14px;
}
.tf-ag-dash-graph-title {
  font-size: .65rem; font-weight: 700; color: var(--txt);
  margin-bottom: 10px; text-transform: uppercase; letter-spacing: .07em;
}
.tf-ag-sparkline {
  width: 100%; height: 44px; display: block; overflow: visible;
}

/* ══════════════════════════════════════════════════════════════════════
   2 · CLIENT LOGOS STRIP
   ══════════════════════════════════════════════════════════════════════ */
.tf-ag-logos {
  padding: 64px 0;
  background: var(--bg2);
  border-top: 1px solid var(--border);
  border-bottom: 1px solid var(--border);
  overflow: hidden;
}
.tf-ag-logos-label {
  text-align: center; font-size: .72rem; font-weight: 700;
  color: var(--meta); text-transform: uppercase; letter-spacing: .12em;
  margin-bottom: 28px;
}
.tf-ag-logos-track-outer {
  overflow: hidden; position: relative;
}
.tf-ag-logos-track-outer::before,
.tf-ag-logos-track-outer::after {
  content: ''; position: absolute; top: 0; bottom: 0; width: 120px; z-index: 2;
}
.tf-ag-logos-track-outer::before {
  left: 0;
  background: linear-gradient(to right, var(--bg2), transparent);
}
.tf-ag-logos-track-outer::after {
  right: 0;
  background: linear-gradient(to left, var(--bg2), transparent);
}
.tf-ag-logos-track {
  display: flex; gap: 20px;
  animation: tf-marquee 28s linear infinite;
  width: max-content;
}
.tf-ag-logos-track:hover { animation-play-state: paused; }
@keyframes tf-marquee {
  0%   { transform: translateX(0); }
  100% { transform: translateX(-50%); }
}
.tf-ag-logo-chip {
  display: flex; align-items: center; gap: 10px;
  background: rgba(255,255,255,.04); border: 1px solid var(--border);
  border-radius: 10px; padding: 11px 20px;
  white-space: nowrap; flex-shrink: 0;
  transition: border-color .2s;
}
.tf-ag-logo-chip:hover { border-color: rgba(255,255,255,.14); }
.tf-ag-logo-init {
  width: 32px; height: 32px; border-radius: 7px;
  display: flex; align-items: center; justify-content: center;
  font-size: .7rem; font-weight: 900; color: #fff;
  flex-shrink: 0;
}
.tf-ag-logo-name {
  font-size: .82rem; font-weight: 700; color: var(--txt);
}

/* ══════════════════════════════════════════════════════════════════════
   3 · SERVICES BENTO GRID
   ══════════════════════════════════════════════════════════════════════ */
.tf-ag-services {
  padding: 100px 0;
}
.tf-ag-bento {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-template-rows: auto auto;
  gap: 20px;
}
.tf-ag-bento-card {
  background: var(--bg3); border: 1px solid var(--border);
  border-radius: 20px; padding: 32px;
  transition: transform .3s, border-color .3s, box-shadow .3s;
  position: relative; overflow: hidden;
}
.tf-ag-bento-card::before {
  content: ''; position: absolute; inset: 0;
  background: linear-gradient(135deg, rgba(255,94,46,.04) 0%, transparent 55%);
  opacity: 0; transition: opacity .3s;
}
.tf-ag-bento-card:hover {
  transform: translateY(-5px);
  border-color: rgba(255,94,46,.22);
  box-shadow: 0 20px 60px rgba(0,0,0,.35);
}
.tf-ag-bento-card:hover::before { opacity: 1; }
/* Featured card spans 2 columns */
.tf-ag-bento-card.featured {
  grid-column: span 2;
  background: linear-gradient(135deg, rgba(255,94,46,.1) 0%, rgba(168,85,247,.06) 100%);
  border-color: rgba(255,94,46,.18);
}
.tf-ag-bento-card.featured:hover {
  border-color: rgba(255,94,46,.35);
}
.tf-ag-card-icon {
  width: 52px; height: 52px; border-radius: 14px;
  background: rgba(255,94,46,.15); border: 1px solid rgba(255,94,46,.22);
  display: flex; align-items: center; justify-content: center;
  margin-bottom: 22px; color: var(--tc);
  flex-shrink: 0;
}
.tf-ag-card-icon svg { width: 24px; height: 24px; display: block; }
.tf-ag-bento-card h3 {
  font-size: 1.1rem; font-weight: 800; color: var(--title);
  margin-bottom: 10px; line-height: 1.3;
}
.tf-ag-bento-card.featured h3 { font-size: 1.35rem; }
.tf-ag-bento-card p {
  font-size: .88rem; color: var(--txt); line-height: 1.7;
  margin-bottom: 20px;
}
.tf-ag-bento-card.featured p { font-size: .95rem; max-width: 540px; }
.tf-ag-card-link {
  display: inline-flex; align-items: center; gap: 6px;
  color: var(--tc); font-size: .83rem; font-weight: 700;
  text-decoration: none; transition: gap .2s;
}
.tf-ag-card-link:hover { gap: 10px; }
.tf-ag-card-link svg { width: 15px; height: 15px; }
/* Featured card decorative pill tags */
.tf-ag-bento-tags {
  display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 24px;
}
.tf-ag-bento-tag {
  padding: 4px 12px; border-radius: 100px;
  font-size: .7rem; font-weight: 700;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.2);
  color: var(--tc);
}

/* ══════════════════════════════════════════════════════════════════════
   4 · PORTFOLIO PREVIEW
   ══════════════════════════════════════════════════════════════════════ */
.tf-ag-portfolio {
  padding: 0 0 100px;
}
.tf-ag-portfolio-header {
  display: flex; align-items: flex-end; justify-content: space-between;
  margin-bottom: 40px; flex-wrap: wrap; gap: 16px;
}
.tf-ag-portfolio-header h2 {
  font-size: clamp(1.8rem, 3vw, 2.6rem); font-weight: 900;
  color: var(--title); line-height: 1.15;
}
.tf-ag-btn-outline {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 11px 24px; border: 1px solid var(--border);
  color: var(--txt); border-radius: 10px; font-size: .85rem; font-weight: 700;
  text-decoration: none; background: transparent;
  transition: border-color .2s, color .2s;
}
.tf-ag-btn-outline:hover { border-color: rgba(255,94,46,.4); color: var(--tc); }
.tf-ag-btn-outline svg { width: 15px; height: 15px; }
.tf-ag-portfolio-grid {
  display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px;
}
.tf-ag-pf-card {
  border-radius: 20px; overflow: hidden;
  border: 1px solid var(--border);
  background: var(--bg3);
  transition: transform .3s, border-color .3s;
  position: relative; cursor: pointer;
}
.tf-ag-pf-card:hover {
  transform: translateY(-6px); border-color: rgba(255,255,255,.14);
}
.tf-ag-pf-thumb {
  height: 220px; position: relative; overflow: hidden;
}
.tf-ag-pf-thumb-bg {
  position: absolute; inset: 0; transition: transform .5s;
}
.tf-ag-pf-card:hover .tf-ag-pf-thumb-bg { transform: scale(1.05); }
/* Gradient placeholders per project */
.tf-ag-pf-card:nth-child(1) .tf-ag-pf-thumb-bg {
  background: linear-gradient(135deg, #1a0a3a 0%, #ff5e2e 50%, #ff8c5a 100%);
}
.tf-ag-pf-card:nth-child(2) .tf-ag-pf-thumb-bg {
  background: linear-gradient(135deg, #0a1a2e 0%, #0077ff 50%, #00d4ff 100%);
}
.tf-ag-pf-card:nth-child(3) .tf-ag-pf-thumb-bg {
  background: linear-gradient(135deg, #0f1a12 0%, #22d3ee 40%, #a855f7 100%);
}
/* decorative geometry inside thumb */
.tf-ag-pf-geo {
  position: absolute; inset: 0; display: flex;
  align-items: center; justify-content: center; pointer-events: none;
}
.tf-ag-pf-geo::before {
  content: ''; width: 100px; height: 100px;
  border: 2px solid rgba(255,255,255,.15);
  border-radius: 50%;
}
.tf-ag-pf-geo::after {
  content: ''; position: absolute;
  width: 60px; height: 60px;
  border: 2px solid rgba(255,255,255,.1);
  border-radius: 50%;
}
/* hover overlay */
.tf-ag-pf-overlay {
  position: absolute; inset: 0;
  background: rgba(0,0,0,.7);
  display: flex; align-items: center; justify-content: center;
  opacity: 0; transition: opacity .3s;
}
.tf-ag-pf-card:hover .tf-ag-pf-overlay { opacity: 1; }
.tf-ag-pf-overlay-cta {
  display: inline-flex; align-items: center; gap: 8px;
  background: var(--tc); color: #fff;
  padding: 11px 22px; border-radius: 10px;
  font-size: .85rem; font-weight: 700; text-decoration: none;
  transform: translateY(8px); transition: transform .3s;
}
.tf-ag-pf-card:hover .tf-ag-pf-overlay-cta { transform: translateY(0); }
.tf-ag-pf-overlay-cta svg { width: 15px; height: 15px; }
.tf-ag-pf-info {
  padding: 22px 24px;
}
.tf-ag-pf-category {
  display: inline-block; font-size: .68rem; font-weight: 800;
  text-transform: uppercase; letter-spacing: .1em;
  color: var(--tc); margin-bottom: 8px;
}
.tf-ag-pf-title {
  font-size: 1.05rem; font-weight: 800; color: var(--title); line-height: 1.3;
}

/* ══════════════════════════════════════════════════════════════════════
   5 · PROCESS STEPS
   ══════════════════════════════════════════════════════════════════════ */
.tf-ag-process {
  padding: 0 0 100px;
}
.tf-ag-process-steps {
  display: grid; grid-template-columns: repeat(4, 1fr);
  gap: 0; position: relative; margin-top: 8px;
}
/* dashed connector line */
.tf-ag-process-steps::before {
  content: ''; position: absolute;
  top: 32px; left: calc(12.5% + 2px); right: calc(12.5% + 2px);
  height: 2px;
  background: repeating-linear-gradient(
    to right, rgba(255,94,46,.4) 0px, rgba(255,94,46,.4) 8px,
    transparent 8px, transparent 18px
  );
  z-index: 0;
}
.tf-ag-process-step {
  text-align: center; padding: 0 20px; position: relative; z-index: 1;
}
.tf-ag-step-num {
  width: 64px; height: 64px; border-radius: 50%;
  background: var(--bg2); border: 2px solid var(--tc);
  display: flex; align-items: center; justify-content: center;
  font-size: 1.2rem; font-weight: 900; color: var(--tc);
  margin: 0 auto 20px; position: relative;
  box-shadow: 0 0 0 6px rgba(255,94,46,.08);
  transition: box-shadow .3s, background .3s;
}
.tf-ag-process-step:hover .tf-ag-step-num {
  background: rgba(255,94,46,.12);
  box-shadow: 0 0 0 10px rgba(255,94,46,.06);
}
.tf-ag-process-step h4 {
  font-size: .95rem; font-weight: 800; color: var(--title); margin-bottom: 8px;
}
.tf-ag-process-step p {
  font-size: .82rem; color: var(--meta); line-height: 1.6;
}

/* ══════════════════════════════════════════════════════════════════════
   6 · TESTIMONIALS
   ══════════════════════════════════════════════════════════════════════ */
.tf-ag-testimonials {
  padding: 0 0 100px;
}
.tf-ag-testimonials-grid {
  display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px;
}
.tf-ag-testi-card {
  background: var(--bg3); border: 1px solid var(--border);
  border-radius: 20px; padding: 32px;
  transition: transform .3s, border-color .3s;
  display: flex; flex-direction: column;
}
.tf-ag-testi-card:hover { transform: translateY(-4px); border-color: rgba(255,255,255,.12); }
.tf-ag-stars {
  display: flex; gap: 4px; margin-bottom: 20px;
}
.tf-ag-star {
  width: 16px; height: 16px;
  color: #f59e0b;
}
.tf-ag-testi-quote {
  font-size: .92rem; color: var(--txt); line-height: 1.75;
  flex: 1; margin-bottom: 28px; font-style: italic;
}
.tf-ag-testi-quote::before { content: '\201C'; }
.tf-ag-testi-quote::after  { content: '\201D'; }
.tf-ag-testi-author {
  display: flex; align-items: center; gap: 14px;
  padding-top: 20px; border-top: 1px solid var(--border);
}
.tf-ag-testi-avatar {
  width: 44px; height: 44px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .78rem; font-weight: 900; color: #fff;
  flex-shrink: 0;
}
.tf-ag-testi-name {
  font-size: .9rem; font-weight: 800; color: var(--title); line-height: 1.2;
}
.tf-ag-testi-role {
  font-size: .75rem; color: var(--meta); margin-top: 2px;
}

/* ══════════════════════════════════════════════════════════════════════
   7 · CTA BANNER
   ══════════════════════════════════════════════════════════════════════ */
.tf-ag-cta-section {
  padding: 0 0 100px;
}
.tf-ag-cta-inner {
  position: relative; overflow: hidden;
  background:
    radial-gradient(ellipse 80% 70% at 50% 50%, rgba(255,94,46,.12) 0%, transparent 70%),
    radial-gradient(ellipse 40% 60% at 10% 90%, rgba(168,85,247,.1) 0%, transparent 60%),
    radial-gradient(ellipse 40% 60% at 90% 10%, rgba(0,212,255,.08) 0%, transparent 60%),
    var(--bg2);
  border: 1px solid rgba(255,94,46,.18);
  border-radius: 28px;
  text-align: center;
  padding: 90px 40px;
}
/* animated orbs */
.tf-ag-orb {
  position: absolute; border-radius: 50%;
  filter: blur(60px); pointer-events: none; opacity: .45;
  animation: tf-orb-float 8s ease-in-out infinite;
}
.tf-ag-orb-1 {
  width: 320px; height: 320px;
  background: rgba(255,94,46,.18);
  top: -80px; left: -80px;
  animation-delay: 0s;
}
.tf-ag-orb-2 {
  width: 280px; height: 280px;
  background: rgba(168,85,247,.15);
  bottom: -60px; right: -40px;
  animation-delay: -4s;
}
.tf-ag-orb-3 {
  width: 200px; height: 200px;
  background: rgba(0,212,255,.1);
  top: 50%; right: 20%; transform: translateY(-50%);
  animation-delay: -2s;
}
@keyframes tf-orb-float {
  0%, 100% { transform: translateY(0) scale(1); }
  50%       { transform: translateY(-24px) scale(1.07); }
}
.tf-ag-orb-3 { animation-name: tf-orb-float-center; }
@keyframes tf-orb-float-center {
  0%, 100% { transform: translateY(-50%) scale(1); }
  50%       { transform: translateY(calc(-50% - 20px)) scale(1.05); }
}
.tf-ag-cta-inner > * { position: relative; z-index: 1; }
.tf-ag-cta-label {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.12); border: 1px solid rgba(255,94,46,.25);
  color: var(--tc); font-size: .7rem; font-weight: 800;
  letter-spacing: .14em; text-transform: uppercase;
  padding: 7px 20px; border-radius: 100px; margin-bottom: 24px;
}
.tf-ag-cta-h2 {
  font-size: clamp(2rem, 4vw, 3.2rem); font-weight: 900;
  color: var(--title); line-height: 1.1; margin-bottom: 16px;
  letter-spacing: -.4px;
}
.tf-ag-cta-sub {
  font-size: 1.05rem; color: var(--txt); max-width: 500px;
  margin: 0 auto 40px; line-height: 1.75;
}
.tf-ag-btn-cta {
  display: inline-flex; align-items: center; gap: 10px;
  padding: 17px 40px; background: var(--tc); color: #fff;
  border-radius: 100px; font-size: 1rem; font-weight: 800;
  text-decoration: none; letter-spacing: .02em;
  box-shadow: 0 12px 40px rgba(255,94,46,.4);
  transition: transform .2s, box-shadow .2s;
}
.tf-ag-btn-cta:hover { transform: translateY(-3px); box-shadow: 0 18px 52px rgba(255,94,46,.5); }
.tf-ag-btn-cta svg { width: 18px; height: 18px; }

/* ══════════════════════════════════════════════════════════════════════
   RESPONSIVE
   ══════════════════════════════════════════════════════════════════════ */
@media (max-width: 1024px) {
  .tf-ag-hero-inner   { grid-template-columns: 1fr 1fr; gap: 36px; }
  .tf-ag-bento        { grid-template-columns: repeat(2, 1fr); }
  .tf-ag-bento-card.featured { grid-column: span 2; }
  .tf-ag-portfolio-grid { grid-template-columns: repeat(2, 1fr); }
  .tf-ag-portfolio-grid .tf-ag-pf-card:last-child { grid-column: span 2; }
  .tf-ag-testimonials-grid { grid-template-columns: repeat(2, 1fr); }
  .tf-ag-testimonials-grid .tf-ag-testi-card:last-child { grid-column: span 2; }
}
@media (max-width: 768px) {
  .tf-ag-hero         { padding: 80px 0 60px; min-height: auto; }
  .tf-ag-hero-inner   { grid-template-columns: 1fr; gap: 40px; }
  .tf-ag-hero-h1      { font-size: 2.4rem; }
  .tf-ag-browser      { transform: none; }
  .tf-ag-bento        { grid-template-columns: 1fr; }
  .tf-ag-bento-card.featured { grid-column: span 1; }
  .tf-ag-portfolio-grid { grid-template-columns: 1fr; }
  .tf-ag-portfolio-grid .tf-ag-pf-card:last-child { grid-column: span 1; }
  .tf-ag-process-steps { grid-template-columns: repeat(2, 1fr); gap: 32px; }
  .tf-ag-process-steps::before { display: none; }
  .tf-ag-testimonials-grid { grid-template-columns: 1fr; }
  .tf-ag-testimonials-grid .tf-ag-testi-card:last-child { grid-column: span 1; }
  .tf-ag-cta-inner    { padding: 60px 24px; }
  .tf-ag-hero-stats   { flex-wrap: wrap; }
  .tf-ag-stat         { min-width: 33%; border-bottom: 1px solid var(--border); }
}
@media (max-width: 480px) {
  .tf-ag-process-steps { grid-template-columns: 1fr; }
  .tf-ag-hero-ctas    { flex-direction: column; }
  .tf-ag-btn-primary, .tf-ag-btn-ghost { justify-content: center; }
  .tf-ag-dash-metrics { grid-template-columns: 1fr 1fr; }
  .tf-ag-portfolio-header { flex-direction: column; align-items: flex-start; }
}
</style>

<?php
/* ─── SVG icon helpers ─────────────────────────────────────────────── */
$ag_icons = array(

  'arrow-right' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>',

  'play-circle' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8"/></svg>',

  'award' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg>',

  'external-link' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>',

  'sparkles' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l1.88 5.47L19 10l-5.12 1.53L12 17l-1.88-5.47L5 10l5.12-1.53z"/><path d="M5 3l.94 2.73L8.5 7l-2.56.77L5 10.5l-.94-2.73L1.5 7l2.56-.77z" opacity=".5"/><path d="M19 14.5l.94 2.73L22.44 19l-2.5.77L19 22.5l-.94-2.73L15.56 19l2.5-.77z" opacity=".5"/></svg>',

  'palette' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10c.926 0 1.648-.746 1.648-1.667 0-.437-.18-.835-.47-1.123C12.93 18.963 13 18.516 13 18c0-1.105.895-2 2-2h1.667C18.403 16 20 14.403 20 12.333 20 6.924 16.523 2 12 2z"/></svg>',

  'layers' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>',

  'code' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',

  'zap' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',

  'trending-up' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>',

  'rocket' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/></svg>',

  'star' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" stroke="none" aria-hidden="true"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',

  'mail' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>',

  'target' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>',
);

?>

<!-- ══════════════════════════════════════════════════════════════════
     SECTION 1 · SPLIT HERO
     ══════════════════════════════════════════════════════════════════ -->
<section class="tf-ag-hero" aria-labelledby="tf-ag-hero-heading">
  <div class="tf-ag-wrap">
    <div class="tf-ag-hero-inner">

      <!-- Left: copy -->
      <div class="tf-ag-hero-copy">
        <div class="tf-ag-hero-badge">
          <?php echo $ag_icons['award']; /* phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped */ ?>
          <?php esc_html_e( 'Award-Winning Digital Agency', 'themeflex' ); ?>
        </div>

        <h1 class="tf-ag-hero-h1" id="tf-ag-hero-heading">
          <?php esc_html_e( 'We craft digital', 'themeflex' ); ?><br>
          <span class="tf-gradient"><?php esc_html_e( 'experiences that', 'themeflex' ); ?></span><br>
          <?php esc_html_e( 'convert', 'themeflex' ); ?>
        </h1>

        <p class="tf-ag-hero-sub">
          <?php esc_html_e( 'From brand strategy to full-stack development — we help ambitious companies build digital products that grow revenue, delight users, and stand out in the market.', 'themeflex' ); ?>
        </p>

        <div class="tf-ag-hero-ctas">
          <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>" class="tf-ag-btn-primary">
            <?php esc_html_e( 'Start a Project', 'themeflex' ); ?>
            <?php echo $ag_icons['arrow-right']; /* phpcs:ignore */ ?>
          </a>
          <a href="<?php echo esc_url( home_url( '/work' ) ); ?>" class="tf-ag-btn-ghost">
            <?php echo $ag_icons['play-circle']; /* phpcs:ignore */ ?>
            <?php esc_html_e( 'View Our Work', 'themeflex' ); ?>
          </a>
        </div>

        <!-- Stats -->
        <div class="tf-ag-hero-stats" role="list" aria-label="<?php esc_attr_e( 'Key figures', 'themeflex' ); ?>">
          <div class="tf-ag-stat" role="listitem">
            <div class="tf-ag-stat-num" data-count="120" aria-label="<?php esc_attr_e( '120+ Clients', 'themeflex' ); ?>">120+</div>
            <div class="tf-ag-stat-label"><?php esc_html_e( 'Clients', 'themeflex' ); ?></div>
          </div>
          <div class="tf-ag-stat" role="listitem">
            <div class="tf-ag-stat-num" data-count="8" aria-label="<?php esc_attr_e( '8 Years', 'themeflex' ); ?>">8</div>
            <div class="tf-ag-stat-label"><?php esc_html_e( 'Years', 'themeflex' ); ?></div>
          </div>
          <div class="tf-ag-stat" role="listitem">
            <div class="tf-ag-stat-num" data-count="98" aria-label="<?php esc_attr_e( '98% NPS Score', 'themeflex' ); ?>">98%</div>
            <div class="tf-ag-stat-label"><?php esc_html_e( 'NPS Score', 'themeflex' ); ?></div>
          </div>
        </div>
      </div><!-- /.tf-ag-hero-copy -->

      <!-- Right: CSS browser mockup -->
      <div class="tf-ag-hero-visual" aria-hidden="true">
        <div class="tf-ag-browser" role="presentation">
          <!-- chrome bar -->
          <div class="tf-ag-browser-chrome">
            <div class="tf-ag-browser-dots">
              <span></span><span></span><span></span>
            </div>
            <div class="tf-ag-browser-url">app.youragency.com/dashboard</div>
          </div>
          <!-- dashboard content -->
          <div class="tf-ag-dashboard">
            <!-- metric cards -->
            <div class="tf-ag-dash-metrics">
              <div class="tf-ag-dash-metric">
                <div class="tf-ag-dash-metric-label">Revenue</div>
                <div class="tf-ag-dash-metric-val">$84.2k</div>
                <div class="tf-ag-dash-metric-delta">↑ 18.4%</div>
              </div>
              <div class="tf-ag-dash-metric">
                <div class="tf-ag-dash-metric-label">Sessions</div>
                <div class="tf-ag-dash-metric-val">142k</div>
                <div class="tf-ag-dash-metric-delta">↑ 9.2%</div>
              </div>
              <div class="tf-ag-dash-metric">
                <div class="tf-ag-dash-metric-label">Conv. Rate</div>
                <div class="tf-ag-dash-metric-val">4.8%</div>
                <div class="tf-ag-dash-metric-delta">↑ 1.3%</div>
              </div>
            </div>
            <!-- bar chart -->
            <div class="tf-ag-dash-chart">
              <div class="tf-ag-dash-chart-title">Monthly Revenue</div>
              <div class="tf-ag-bars" role="img" aria-label="Bar chart showing monthly revenue">
                <div class="tf-ag-bar" style="height:38%"></div>
                <div class="tf-ag-bar" style="height:52%"></div>
                <div class="tf-ag-bar" style="height:44%"></div>
                <div class="tf-ag-bar" style="height:65%"></div>
                <div class="tf-ag-bar" style="height:58%"></div>
                <div class="tf-ag-bar" style="height:72%"></div>
                <div class="tf-ag-bar active" style="height:88%"></div>
              </div>
            </div>
            <!-- sparkline -->
            <div class="tf-ag-dash-graph">
              <div class="tf-ag-dash-graph-title">Conversion Trend</div>
              <svg class="tf-ag-sparkline" viewBox="0 0 260 44" preserveAspectRatio="none" role="img" aria-label="Line graph showing conversion trend">
                <defs>
                  <linearGradient id="tf-spark-fill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stop-color="#ff5e2e" stop-opacity=".25"/>
                    <stop offset="100%" stop-color="#ff5e2e" stop-opacity="0"/>
                  </linearGradient>
                </defs>
                <path d="M0,36 C20,34 40,30 60,28 C80,26 100,30 120,22 C140,14 160,18 180,12 C200,6 220,10 240,6 L260,4 L260,44 L0,44 Z" fill="url(#tf-spark-fill)"/>
                <path d="M0,36 C20,34 40,30 60,28 C80,26 100,30 120,22 C140,14 160,18 180,12 C200,6 220,10 240,6 L260,4" fill="none" stroke="#ff5e2e" stroke-width="1.8"/>
              </svg>
            </div>
          </div><!-- /.tf-ag-dashboard -->
        </div><!-- /.tf-ag-browser -->
      </div><!-- /.tf-ag-hero-visual -->

    </div><!-- /.tf-ag-hero-inner -->
  </div><!-- /.tf-ag-wrap -->
</section>

<!-- ══════════════════════════════════════════════════════════════════
     SECTION 2 · CLIENT LOGOS STRIP
     ══════════════════════════════════════════════════════════════════ -->
<section class="tf-ag-logos" aria-label="<?php esc_attr_e( 'Trusted by leading companies', 'themeflex' ); ?>">
  <p class="tf-ag-logos-label"><?php esc_html_e( 'Trusted by leading companies', 'themeflex' ); ?></p>

  <?php
  $ag_clients = array(
    array( 'init' => 'NX', 'name' => 'Nexora',    'bg' => '#6366f1' ),
    array( 'init' => 'PL', 'name' => 'Pulsify',   'bg' => '#0ea5e9' ),
    array( 'init' => 'VL', 'name' => 'Velocia',   'bg' => '#10b981' ),
    array( 'init' => 'ST', 'name' => 'Stackify',  'bg' => '#f59e0b' ),
    array( 'init' => 'CR', 'name' => 'Crestone',  'bg' => '#ef4444' ),
    array( 'init' => 'LM', 'name' => 'Luminos',   'bg' => '#8b5cf6' ),
    array( 'init' => 'FX', 'name' => 'Flexora',   'bg' => '#ec4899' ),
    array( 'init' => 'ZN', 'name' => 'Zenith',    'bg' => '#14b8a6' ),
  );
  // double for seamless marquee
  $ag_all_clients = array_merge( $ag_clients, $ag_clients );
  ?>
  <div class="tf-ag-logos-track-outer">
    <div class="tf-ag-logos-track" role="list">
      <?php foreach ( $ag_all_clients as $client ) : ?>
        <div class="tf-ag-logo-chip" role="listitem">
          <div class="tf-ag-logo-init" style="background:<?php echo esc_attr( $client['bg'] ); ?>">
            <?php echo esc_html( $client['init'] ); ?>
          </div>
          <span class="tf-ag-logo-name"><?php echo esc_html( $client['name'] ); ?></span>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════
     SECTION 3 · SERVICES BENTO GRID
     ══════════════════════════════════════════════════════════════════ -->
<section class="tf-ag-services" aria-labelledby="tf-ag-services-heading">
  <div class="tf-ag-wrap">
    <div class="tf-ag-section-head">
      <div class="tf-ag-section-label">
        <?php echo $ag_icons['sparkles']; /* phpcs:ignore */ ?>
        <?php esc_html_e( 'What We Do', 'themeflex' ); ?>
      </div>
      <h2 id="tf-ag-services-heading"><?php esc_html_e( 'Services built for growth', 'themeflex' ); ?></h2>
      <p><?php esc_html_e( 'A full-spectrum digital capability — from bold brand creation to high-performance code and data-driven marketing.', 'themeflex' ); ?></p>
    </div>

    <div class="tf-ag-bento">

      <!-- Featured card: Brand Strategy (spans 2 cols) -->
      <div class="tf-ag-bento-card featured">
        <div class="tf-ag-card-icon">
          <?php echo $ag_icons['palette']; /* phpcs:ignore */ ?>
        </div>
        <h3><?php esc_html_e( 'Brand Strategy', 'themeflex' ); ?></h3>
        <div class="tf-ag-bento-tags">
          <span class="tf-ag-bento-tag"><?php esc_html_e( 'Identity', 'themeflex' ); ?></span>
          <span class="tf-ag-bento-tag"><?php esc_html_e( 'Positioning', 'themeflex' ); ?></span>
          <span class="tf-ag-bento-tag"><?php esc_html_e( 'Messaging', 'themeflex' ); ?></span>
          <span class="tf-ag-bento-tag"><?php esc_html_e( 'Visual Systems', 'themeflex' ); ?></span>
        </div>
        <p><?php esc_html_e( 'Your brand is more than a logo — it\'s the story your audience tells themselves about you. We build strategic brand identities grounded in research, crafted for longevity, and designed to command premium positioning in competitive markets.', 'themeflex' ); ?></p>
        <a href="<?php echo esc_url( home_url( '/services/brand-strategy' ) ); ?>" class="tf-ag-card-link">
          <?php esc_html_e( 'Learn more', 'themeflex' ); ?>
          <?php echo $ag_icons['arrow-right']; /* phpcs:ignore */ ?>
        </a>
      </div>

      <!-- Card: Web Design -->
      <div class="tf-ag-bento-card">
        <div class="tf-ag-card-icon">
          <?php echo $ag_icons['layers']; /* phpcs:ignore */ ?>
        </div>
        <h3><?php esc_html_e( 'Web Design', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'Conversion-focused interfaces. We design pixel-perfect digital experiences that guide users to act.', 'themeflex' ); ?></p>
        <a href="<?php echo esc_url( home_url( '/services/web-design' ) ); ?>" class="tf-ag-card-link">
          <?php esc_html_e( 'Learn more', 'themeflex' ); ?>
          <?php echo $ag_icons['arrow-right']; /* phpcs:ignore */ ?>
        </a>
      </div>

      <!-- Card: Development -->
      <div class="tf-ag-bento-card">
        <div class="tf-ag-card-icon">
          <?php echo $ag_icons['code']; /* phpcs:ignore */ ?>
        </div>
        <h3><?php esc_html_e( 'Development', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'Bespoke WordPress & headless builds engineered for performance, scalability, and zero technical debt.', 'themeflex' ); ?></p>
        <a href="<?php echo esc_url( home_url( '/services/development' ) ); ?>" class="tf-ag-card-link">
          <?php esc_html_e( 'Learn more', 'themeflex' ); ?>
          <?php echo $ag_icons['arrow-right']; /* phpcs:ignore */ ?>
        </a>
      </div>

      <!-- Card: Performance -->
      <div class="tf-ag-bento-card">
        <div class="tf-ag-card-icon">
          <?php echo $ag_icons['zap']; /* phpcs:ignore */ ?>
        </div>
        <h3><?php esc_html_e( 'Performance', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( '97+ PageSpeed scores. Core Web Vitals mastery. Sub-800ms LCP — because every millisecond costs money.', 'themeflex' ); ?></p>
        <a href="<?php echo esc_url( home_url( '/services/performance' ) ); ?>" class="tf-ag-card-link">
          <?php esc_html_e( 'Learn more', 'themeflex' ); ?>
          <?php echo $ag_icons['arrow-right']; /* phpcs:ignore */ ?>
        </a>
      </div>

      <!-- Card: Analytics -->
      <div class="tf-ag-bento-card">
        <div class="tf-ag-card-icon">
          <?php echo $ag_icons['trending-up']; /* phpcs:ignore */ ?>
        </div>
        <h3><?php esc_html_e( 'Analytics', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'Full-funnel tracking, dashboards, and insight systems that tell you what\'s working and what needs fixing.', 'themeflex' ); ?></p>
        <a href="<?php echo esc_url( home_url( '/services/analytics' ) ); ?>" class="tf-ag-card-link">
          <?php esc_html_e( 'Learn more', 'themeflex' ); ?>
          <?php echo $ag_icons['arrow-right']; /* phpcs:ignore */ ?>
        </a>
      </div>

      <!-- Card: Growth Marketing -->
      <div class="tf-ag-bento-card">
        <div class="tf-ag-card-icon">
          <?php echo $ag_icons['rocket']; /* phpcs:ignore */ ?>
        </div>
        <h3><?php esc_html_e( 'Growth Marketing', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'Paid, organic, and referral channels wired together into a growth engine that compounds over time.', 'themeflex' ); ?></p>
        <a href="<?php echo esc_url( home_url( '/services/growth' ) ); ?>" class="tf-ag-card-link">
          <?php esc_html_e( 'Learn more', 'themeflex' ); ?>
          <?php echo $ag_icons['arrow-right']; /* phpcs:ignore */ ?>
        </a>
      </div>

    </div><!-- /.tf-ag-bento -->
  </div><!-- /.tf-ag-wrap -->
</section>

<!-- ══════════════════════════════════════════════════════════════════
     SECTION 4 · PORTFOLIO PREVIEW
     ══════════════════════════════════════════════════════════════════ -->
<section class="tf-ag-portfolio" aria-labelledby="tf-ag-portfolio-heading">
  <div class="tf-ag-wrap">
    <div class="tf-ag-portfolio-header">
      <h2 id="tf-ag-portfolio-heading"><?php esc_html_e( 'Selected Work', 'themeflex' ); ?></h2>
      <a href="<?php echo esc_url( home_url( '/work' ) ); ?>" class="tf-ag-btn-outline">
        <?php esc_html_e( 'View All', 'themeflex' ); ?>
        <?php echo $ag_icons['arrow-right']; /* phpcs:ignore */ ?>
      </a>
    </div>

    <div class="tf-ag-portfolio-grid">

      <!-- Project 1 -->
      <article class="tf-ag-pf-card">
        <div class="tf-ag-pf-thumb">
          <div class="tf-ag-pf-thumb-bg"></div>
          <div class="tf-ag-pf-geo" aria-hidden="true"></div>
          <div class="tf-ag-pf-overlay">
            <a href="<?php echo esc_url( home_url( '/work/e-commerce-rebrand' ) ); ?>" class="tf-ag-pf-overlay-cta">
              <?php esc_html_e( 'View Project', 'themeflex' ); ?>
              <?php echo $ag_icons['external-link']; /* phpcs:ignore */ ?>
            </a>
          </div>
        </div>
        <div class="tf-ag-pf-info">
          <span class="tf-ag-pf-category"><?php esc_html_e( 'E-Commerce', 'themeflex' ); ?></span>
          <div class="tf-ag-pf-title"><?php esc_html_e( 'E-Commerce Rebrand', 'themeflex' ); ?></div>
        </div>
      </article>

      <!-- Project 2 -->
      <article class="tf-ag-pf-card">
        <div class="tf-ag-pf-thumb">
          <div class="tf-ag-pf-thumb-bg"></div>
          <div class="tf-ag-pf-geo" aria-hidden="true"></div>
          <div class="tf-ag-pf-overlay">
            <a href="<?php echo esc_url( home_url( '/work/saas-dashboard' ) ); ?>" class="tf-ag-pf-overlay-cta">
              <?php esc_html_e( 'View Project', 'themeflex' ); ?>
              <?php echo $ag_icons['external-link']; /* phpcs:ignore */ ?>
            </a>
          </div>
        </div>
        <div class="tf-ag-pf-info">
          <span class="tf-ag-pf-category"><?php esc_html_e( 'Product Design', 'themeflex' ); ?></span>
          <div class="tf-ag-pf-title"><?php esc_html_e( 'SaaS Dashboard', 'themeflex' ); ?></div>
        </div>
      </article>

      <!-- Project 3 -->
      <article class="tf-ag-pf-card">
        <div class="tf-ag-pf-thumb">
          <div class="tf-ag-pf-thumb-bg"></div>
          <div class="tf-ag-pf-geo" aria-hidden="true"></div>
          <div class="tf-ag-pf-overlay">
            <a href="<?php echo esc_url( home_url( '/work/brand-identity' ) ); ?>" class="tf-ag-pf-overlay-cta">
              <?php esc_html_e( 'View Project', 'themeflex' ); ?>
              <?php echo $ag_icons['external-link']; /* phpcs:ignore */ ?>
            </a>
          </div>
        </div>
        <div class="tf-ag-pf-info">
          <span class="tf-ag-pf-category"><?php esc_html_e( 'Branding', 'themeflex' ); ?></span>
          <div class="tf-ag-pf-title"><?php esc_html_e( 'Brand Identity', 'themeflex' ); ?></div>
        </div>
      </article>

    </div><!-- /.tf-ag-portfolio-grid -->
  </div><!-- /.tf-ag-wrap -->
</section>

<!-- ══════════════════════════════════════════════════════════════════
     SECTION 5 · PROCESS STEPS
     ══════════════════════════════════════════════════════════════════ -->
<section class="tf-ag-process" aria-labelledby="tf-ag-process-heading">
  <div class="tf-ag-wrap">
    <div class="tf-ag-section-head">
      <div class="tf-ag-section-label">
        <?php echo $ag_icons['target']; /* phpcs:ignore */ ?>
        <?php esc_html_e( 'Our Approach', 'themeflex' ); ?>
      </div>
      <h2 id="tf-ag-process-heading"><?php esc_html_e( 'How we work', 'themeflex' ); ?></h2>
      <p><?php esc_html_e( 'A proven four-stage process that turns your vision into a market-ready product — on time, every time.', 'themeflex' ); ?></p>
    </div>

    <div class="tf-ag-process-steps">

      <div class="tf-ag-process-step">
        <div class="tf-ag-step-num" aria-hidden="true">01</div>
        <h4><?php esc_html_e( 'Discovery', 'themeflex' ); ?></h4>
        <p><?php esc_html_e( 'Deep-dive into your goals, audience, and competitive landscape.', 'themeflex' ); ?></p>
      </div>

      <div class="tf-ag-process-step">
        <div class="tf-ag-step-num" aria-hidden="true">02</div>
        <h4><?php esc_html_e( 'Strategy', 'themeflex' ); ?></h4>
        <p><?php esc_html_e( 'A clear roadmap with milestones, KPIs, and success criteria.', 'themeflex' ); ?></p>
      </div>

      <div class="tf-ag-process-step">
        <div class="tf-ag-step-num" aria-hidden="true">03</div>
        <h4><?php esc_html_e( 'Design &amp; Build', 'themeflex' ); ?></h4>
        <p><?php esc_html_e( 'Pixel-perfect design, rapid iteration, and production-ready code.', 'themeflex' ); ?></p>
      </div>

      <div class="tf-ag-process-step">
        <div class="tf-ag-step-num" aria-hidden="true">04</div>
        <h4><?php esc_html_e( 'Launch &amp; Grow', 'themeflex' ); ?></h4>
        <p><?php esc_html_e( 'Smooth deployment, performance monitoring, and ongoing optimisation.', 'themeflex' ); ?></p>
      </div>

    </div><!-- /.tf-ag-process-steps -->
  </div><!-- /.tf-ag-wrap -->
</section>

<!-- ══════════════════════════════════════════════════════════════════
     SECTION 6 · TESTIMONIALS
     ══════════════════════════════════════════════════════════════════ -->
<section class="tf-ag-testimonials" aria-labelledby="tf-ag-testi-heading">
  <div class="tf-ag-wrap">
    <div class="tf-ag-section-head">
      <div class="tf-ag-section-label">
        <?php echo $ag_icons['star']; /* phpcs:ignore */ ?>
        <?php esc_html_e( 'Social Proof', 'themeflex' ); ?>
      </div>
      <h2 id="tf-ag-testi-heading"><?php esc_html_e( 'What our clients say', 'themeflex' ); ?></h2>
      <p><?php esc_html_e( 'Don\'t take our word for it — hear directly from the founders and teams we\'ve partnered with.', 'themeflex' ); ?></p>
    </div>

    <div class="tf-ag-testimonials-grid">

      <?php
      $ag_testimonials = array(
        array(
          'quote'   => __( 'Working with this agency completely transformed how we present ourselves online. Our conversion rate jumped 42% within the first 60 days after launch. The team\'s attention to detail and strategic thinking are unmatched.', 'themeflex' ),
          'name'    => __( 'Sarah Chen', 'themeflex' ),
          'role'    => __( 'CEO', 'themeflex' ),
          'company' => __( 'Nexora Inc.', 'themeflex' ),
          'init'    => 'SC',
          'bg'      => '#6366f1',
        ),
        array(
          'quote'   => __( 'We\'ve worked with a lot of agencies. None of them come close. They delivered a SaaS dashboard redesign in 6 weeks that our previous team couldn\'t ship in 6 months. Genuinely impressive.', 'themeflex' ),
          'name'    => __( 'Marcus Feld', 'themeflex' ),
          'role'    => __( 'CTO', 'themeflex' ),
          'company' => __( 'Stackify', 'themeflex' ),
          'init'    => 'MF',
          'bg'      => '#0ea5e9',
        ),
        array(
          'quote'   => __( 'Our brand identity refresh brought in three new enterprise clients within the first quarter. The strategy work alone was worth every euro — the execution was the cherry on top.', 'themeflex' ),
          'name'    => __( 'Laila Osei', 'themeflex' ),
          'role'    => __( 'CMO', 'themeflex' ),
          'company' => __( 'Pulsify', 'themeflex' ),
          'init'    => 'LO',
          'bg'      => '#10b981',
        ),
      );

      foreach ( $ag_testimonials as $testi ) :
      ?>
      <blockquote class="tf-ag-testi-card">
        <!-- 5 stars -->
        <div class="tf-ag-stars" aria-label="<?php esc_attr_e( '5 out of 5 stars', 'themeflex' ); ?>">
          <?php for ( $i = 0; $i < 5; $i++ ) : ?>
            <span class="tf-ag-star"><?php echo $ag_icons['star']; /* phpcs:ignore */ ?></span>
          <?php endfor; ?>
        </div>
        <p class="tf-ag-testi-quote"><?php echo esc_html( $testi['quote'] ); ?></p>
        <footer class="tf-ag-testi-author">
          <div class="tf-ag-testi-avatar" style="background:<?php echo esc_attr( $testi['bg'] ); ?>" aria-hidden="true">
            <?php echo esc_html( $testi['init'] ); ?>
          </div>
          <div>
            <div class="tf-ag-testi-name"><?php echo esc_html( $testi['name'] ); ?></div>
            <div class="tf-ag-testi-role">
              <?php echo esc_html( $testi['role'] ); ?>, <?php echo esc_html( $testi['company'] ); ?>
            </div>
          </div>
        </footer>
      </blockquote>
      <?php endforeach; ?>

    </div><!-- /.tf-ag-testimonials-grid -->
  </div><!-- /.tf-ag-wrap -->
</section>

<!-- ══════════════════════════════════════════════════════════════════
     SECTION 7 · CTA BANNER
     ══════════════════════════════════════════════════════════════════ -->
<section class="tf-ag-cta-section" aria-labelledby="tf-ag-cta-heading">
  <div class="tf-ag-wrap">
    <div class="tf-ag-cta-inner">
      <!-- animated orbs -->
      <div class="tf-ag-orb tf-ag-orb-1" aria-hidden="true"></div>
      <div class="tf-ag-orb tf-ag-orb-2" aria-hidden="true"></div>
      <div class="tf-ag-orb tf-ag-orb-3" aria-hidden="true"></div>

      <div class="tf-ag-cta-label">
        <?php echo $ag_icons['rocket']; /* phpcs:ignore */ ?>
        <?php esc_html_e( 'Let\'s Build Something', 'themeflex' ); ?>
      </div>

      <h2 class="tf-ag-cta-h2" id="tf-ag-cta-heading">
        <?php esc_html_e( 'Ready to start', 'themeflex' ); ?><br>
        <?php esc_html_e( 'your project?', 'themeflex' ); ?>
      </h2>

      <p class="tf-ag-cta-sub">
        <?php esc_html_e( 'Tell us about your vision. We\'ll come back within 24 hours with a tailored proposal — no fluff, just clear thinking and honest pricing.', 'themeflex' ); ?>
      </p>

      <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>" class="tf-ag-btn-cta">
        <?php esc_html_e( 'Get in Touch', 'themeflex' ); ?>
        <?php echo $ag_icons['arrow-right']; /* phpcs:ignore */ ?>
      </a>
    </div>
  </div>
</section>

</main><!-- /#primary -->

<script>
/* ── Counter animation (IntersectionObserver, no deps) ─────────────── */
(function() {
  'use strict';

  var stats = document.querySelectorAll('.tf-ag-stat-num[data-count]');
  if ( ! stats.length || ! window.IntersectionObserver ) return;

  var animated = false;

  function animateCounters() {
    if ( animated ) return;
    animated = true;

    stats.forEach( function( el ) {
      var target  = parseInt( el.getAttribute('data-count'), 10 );
      var suffix  = el.textContent.replace( /[0-9]/g, '' ); // preserves +, %
      var start   = 0;
      var duration= 1400;
      var step    = Math.ceil( duration / target );
      var timer   = setInterval( function() {
        start = Math.min( start + Math.ceil( target / ( duration / 16 ) ), target );
        el.textContent = start + suffix;
        if ( start >= target ) clearInterval( timer );
      }, 16 );
    } );
  }

  var observer = new IntersectionObserver( function( entries ) {
    entries.forEach( function( entry ) {
      if ( entry.isIntersecting ) animateCounters();
    });
  }, { threshold: 0.4 } );

  observer.observe( stats[0].closest('.tf-ag-hero-stats') );
})();
</script>

<?php get_footer(); ?>
