<?php
/**
 * Template Name: Contact
 * Template Post Type: page
 *
 * Dark-first Contact page — no plugin dependency.
 * Sections: Hero · 2-col layout (form left / info right) · FAQ strip · CTA
 *
 * Handles its own form submission via admin-post.php so it works out-of-the-box.
 * For production swap the email handling with CF7, Gravity Forms, or WPForms.
 *
 * @package ThemeFlex
 * @since 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ── Handle built-in form submission ─────────────────────── */
$form_sent  = isset( $_GET['tf_sent'] ) && '1' === $_GET['tf_sent'];
$form_error = isset( $_GET['tf_sent'] ) && '0' === $_GET['tf_sent'];

get_header(); ?>

<main id="primary" class="tf-contact-main">
<style>
/* ── Contact page — Dark-first ─────────────────────────── */
.tf-contact-main {
  --tc:    #ff5e2e; --tc2: #00d4ff;
  --bg:    #06021d; --bg2: #0d1526; --bg3: #111827;
  --border: rgba(255,255,255,.07);
  --title: #f1f5f9; --txt: #94a3b8; --meta: #64748b;
  background: var(--bg); min-height: 100vh; padding-bottom: 100px;
}
.tf-contact-wrap { max-width: 1200px; margin: 0 auto; padding: 0 24px; }

/* ── Hero ───────────────────────────────────────────────── */
.tf-contact-hero {
  position: relative; text-align: center;
  padding: 120px 24px 80px;
  background: radial-gradient(ellipse 65% 50% at 50% 0%, rgba(255,94,46,.14) 0%, transparent 70%), var(--bg);
  overflow: hidden;
}
.tf-contact-hero::before {
  content: ''; position: absolute; inset: 0;
  background-image: radial-gradient(rgba(255,255,255,.03) 1px, transparent 1px);
  background-size: 36px 36px;
}
.tf-contact-eyebrow {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.25);
  color: var(--tc); font-size: .72rem; font-weight: 700; letter-spacing: .1em;
  text-transform: uppercase; padding: 6px 18px; border-radius: 100px; margin-bottom: 22px;
  position: relative; z-index: 1;
}
.tf-contact-hero h1 {
  position: relative; z-index: 1;
  font-size: clamp(2.2rem, 4.5vw, 3.6rem); font-weight: 900;
  color: var(--title); margin: 0 0 18px; line-height: 1.1;
}
.tf-contact-hero p {
  position: relative; z-index: 1;
  font-size: 1.1rem; color: var(--txt); max-width: 560px; margin: 0 auto; line-height: 1.75;
}

/* ── Main 2-col layout ──────────────────────────────────── */
.tf-contact-grid {
  display: grid; grid-template-columns: 1fr 400px;
  gap: 56px; padding: 72px 0 0;
}

/* ── Form ───────────────────────────────────────────────── */
.tf-contact-form-box {
  background: var(--bg3); border: 1px solid var(--border);
  border-radius: 24px; padding: 44px 40px;
}
.tf-contact-form-box h2 { font-size: 1.4rem; font-weight: 800; color: var(--title); margin: 0 0 8px; }
.tf-contact-form-box > p { font-size: .9rem; color: var(--meta); margin: 0 0 32px; }

/* Alert banners */
.tf-contact-alert {
  border-radius: 10px; padding: 14px 18px; font-size: .9rem; font-weight: 600;
  margin-bottom: 24px; display: flex; align-items: center; gap: 10px;
}
.tf-contact-alert.success { background: rgba(16,185,129,.1); border: 1px solid rgba(16,185,129,.25); color: #34d399; }
.tf-contact-alert.error   { background: rgba(239,68,68,.1);  border: 1px solid rgba(239,68,68,.25);  color: #f87171; }

/* Form rows */
.tf-form-row { margin-bottom: 20px; }
.tf-form-row-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px; }
.tf-form-label { display: block; font-size: .8rem; font-weight: 700; color: var(--txt); margin-bottom: 8px; letter-spacing: .03em; }
.tf-form-label span { color: var(--tc); }
.tf-form-input, .tf-form-select, .tf-form-textarea {
  width: 100%; padding: 13px 16px; border-radius: 10px;
  background: rgba(255,255,255,.05); border: 1px solid var(--border);
  color: var(--title); font-size: .9rem; font-family: inherit;
  outline: none; transition: border-color .2s; box-sizing: border-box;
}
.tf-form-input::placeholder, .tf-form-textarea::placeholder { color: var(--meta); }
.tf-form-input:focus, .tf-form-select:focus, .tf-form-textarea:focus {
  border-color: rgba(255,94,46,.5);
  box-shadow: 0 0 0 3px rgba(255,94,46,.08);
}
.tf-form-select { appearance: none; cursor: pointer; }
.tf-form-select option { background: #111827; color: #f1f5f9; }
.tf-form-textarea { resize: vertical; min-height: 140px; }
.tf-form-submit {
  width: 100%; padding: 15px 28px; border-radius: 12px; border: none; cursor: pointer;
  background: var(--tc); color: #fff; font-size: .95rem; font-weight: 700;
  letter-spacing: .02em; transition: background .2s, transform .2s;
  display: flex; align-items: center; justify-content: center; gap: 8px;
}
.tf-form-submit:hover { background: #e04e22; transform: translateY(-1px); }
.tf-form-note { font-size: .75rem; color: var(--meta); margin-top: 12px; text-align: center; }

/* ── Sidebar info ────────────────────────────────────────── */
.tf-contact-sidebar { display: flex; flex-direction: column; gap: 20px; }

.tf-contact-info-card {
  background: var(--bg3); border: 1px solid var(--border);
  border-radius: 18px; padding: 28px;
}
.tf-contact-info-card h3 {
  font-size: .72rem; font-weight: 800; letter-spacing: .1em; text-transform: uppercase;
  color: var(--title); margin: 0 0 20px;
}
.tf-contact-info-item {
  display: flex; gap: 14px; align-items: flex-start; margin-bottom: 18px;
}
.tf-contact-info-item:last-child { margin-bottom: 0; }
.tf-contact-info-icon {
  width: 38px; height: 38px; border-radius: 10px; flex-shrink: 0;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.2);
  display: flex; align-items: center; justify-content: center;
  color: #ff5e2e;
}
.tf-contact-info-icon svg { width: 18px; height: 18px; display: block; }
.tf-contact-info-label { font-size: .75rem; color: var(--meta); margin-bottom: 2px; font-weight: 600; }
.tf-contact-info-value { font-size: .9rem; color: var(--txt); }
.tf-contact-info-value a { color: var(--tc); text-decoration: none; }
.tf-contact-info-value a:hover { text-decoration: underline; }

/* Status pill */
.tf-contact-status {
  display: flex; align-items: center; gap: 10px; margin-top: 18px;
  padding: 10px 14px; border-radius: 10px;
  background: rgba(16,185,129,.08); border: 1px solid rgba(16,185,129,.2);
}
.tf-contact-status-dot {
  width: 8px; height: 8px; border-radius: 50%; background: #10b981;
  animation: tfStatusPulse 2s ease-in-out infinite;
}
@keyframes tfStatusPulse { 0%,100%{opacity:1} 50%{opacity:.4} }
.tf-contact-status-txt { font-size: .8rem; color: #34d399; font-weight: 600; }

/* Social links */
.tf-contact-socials { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 6px; }
.tf-contact-social-link {
  display: inline-flex; align-items: center; justify-content: center;
  width: 36px; height: 36px; border-radius: 10px;
  background: rgba(255,255,255,.05); border: 1px solid var(--border);
  color: var(--meta); text-decoration: none; font-size: .9rem;
  transition: all .2s;
}
.tf-contact-social-link:hover { background: var(--tc); border-color: var(--tc); color: #fff; transform: translateY(-2px); }

/* Response time card */
.tf-contact-response {
  background: linear-gradient(135deg, rgba(255,94,46,.1), rgba(0,212,255,.06));
  border: 1px solid rgba(255,94,46,.2);
  border-radius: 18px; padding: 24px;
  text-align: center;
}
.tf-contact-response-num { font-size: 2rem; font-weight: 900; color: var(--tc); margin-bottom: 4px; }
.tf-contact-response-txt { font-size: .85rem; color: var(--txt); }

/* ── Responsive ──────────────────────────────────────────── */
@media(max-width:1024px) {
  .tf-contact-grid { grid-template-columns: 1fr; }
  .tf-contact-sidebar { flex-direction: row; flex-wrap: wrap; }
  .tf-contact-sidebar > * { flex: 1 1 280px; }
}
@media(max-width:600px) {
  .tf-form-row-2 { grid-template-columns: 1fr; }
  .tf-contact-form-box { padding: 28px 22px; }
}
</style>

<!-- ── Hero ───────────────────────────────────────────────── -->
<section class="tf-contact-hero">
  <div class="tf-contact-eyebrow">◆ <?php esc_html_e( 'Get In Touch', 'themeflex' ); ?></div>
  <h1><?php esc_html_e( "Let's Start a Conversation", 'themeflex' ); ?></h1>
  <p><?php esc_html_e( "Whether you have a project in mind, a technical question, or just want to say hello — we'd love to hear from you.", 'themeflex' ); ?></p>
</section>

<!-- ── Main grid ──────────────────────────────────────────── -->
<div class="tf-contact-wrap">
<div class="tf-contact-grid">

  <!-- ── Form ──────────────────────────────────────────────── -->
  <div class="tf-contact-form-box">
    <h2><?php esc_html_e( 'Send Us a Message', 'themeflex' ); ?></h2>
    <p><?php esc_html_e( 'We typically respond within 24 hours on business days.', 'themeflex' ); ?></p>

    <?php if ( $form_sent ) : ?>
      <div class="tf-contact-alert success">
        ✓ <?php esc_html_e( "Message sent! We'll get back to you within 24 hours.", 'themeflex' ); ?>
      </div>
    <?php elseif ( $form_error ) : ?>
      <div class="tf-contact-alert error">
        ✗ <?php esc_html_e( 'Something went wrong. Please try again or email us directly.', 'themeflex' ); ?>
      </div>
    <?php endif; ?>

    <?php
    /*
     * Built-in minimal form — sends via wp_mail().
     * For production use: Contact Form 7 / Gravity Forms / WPForms shortcode here instead.
     * Example: echo do_shortcode('[contact-form-7 id="xxx" title="Contact"]');
     */
    $to_email = get_option( 'admin_email' );
    ?>
    <form
      method="POST"
      action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
      novalidate
      id="tfContactForm"
    >
      <input type="hidden" name="action" value="tf_contact_form">
      <?php wp_nonce_field( 'tf_contact_nonce', 'tf_nonce' ); ?>
      <input type="hidden" name="redirect_to" value="<?php echo esc_url( get_permalink() ); ?>">

      <div class="tf-form-row-2">
        <div>
          <label class="tf-form-label" for="tf_name">
            <?php esc_html_e( 'Your Name', 'themeflex' ); ?> <span>*</span>
          </label>
          <input
            class="tf-form-input" type="text" id="tf_name" name="tf_name"
            placeholder="<?php esc_attr_e( 'Alex Johnson', 'themeflex' ); ?>"
            required autocomplete="name"
          >
        </div>
        <div>
          <label class="tf-form-label" for="tf_email">
            <?php esc_html_e( 'Email Address', 'themeflex' ); ?> <span>*</span>
          </label>
          <input
            class="tf-form-input" type="email" id="tf_email" name="tf_email"
            placeholder="<?php esc_attr_e( 'alex@company.com', 'themeflex' ); ?>"
            required autocomplete="email"
          >
        </div>
      </div>

      <div class="tf-form-row">
        <label class="tf-form-label" for="tf_subject"><?php esc_html_e( 'Subject', 'themeflex' ); ?></label>
        <select class="tf-form-select" id="tf_subject" name="tf_subject">
          <option value=""><?php esc_html_e( 'Select a topic…', 'themeflex' ); ?></option>
          <option value="general"><?php esc_html_e( 'General Enquiry', 'themeflex' ); ?></option>
          <option value="purchase"><?php esc_html_e( 'Purchase Question', 'themeflex' ); ?></option>
          <option value="support"><?php esc_html_e( 'Technical Support', 'themeflex' ); ?></option>
          <option value="customisation"><?php esc_html_e( 'Customisation Request', 'themeflex' ); ?></option>
          <option value="partnership"><?php esc_html_e( 'Partnership / Affiliate', 'themeflex' ); ?></option>
          <option value="other"><?php esc_html_e( 'Other', 'themeflex' ); ?></option>
        </select>
      </div>

      <div class="tf-form-row">
        <label class="tf-form-label" for="tf_message">
          <?php esc_html_e( 'Message', 'themeflex' ); ?> <span>*</span>
        </label>
        <textarea
          class="tf-form-textarea" id="tf_message" name="tf_message"
          placeholder="<?php esc_attr_e( 'Tell us about your project or question…', 'themeflex' ); ?>"
          required rows="6"
        ></textarea>
      </div>

      <!-- Honeypot anti-spam -->
      <div style="display:none" aria-hidden="true">
        <input type="text" name="tf_website" tabindex="-1" autocomplete="off">
      </div>

      <button type="submit" class="tf-form-submit">
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
        <?php esc_html_e( 'Send Message', 'themeflex' ); ?>
      </button>

      <p class="tf-form-note">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="12" height="12" style="vertical-align:middle;margin-right:4px;opacity:.5" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg><?php esc_html_e( 'Your information is never shared with third parties.', 'themeflex' ); ?>
      </p>
    </form>
  </div><!-- .tf-contact-form-box -->

  <!-- ── Sidebar info ─────────────────────────────────────── -->
  <aside class="tf-contact-sidebar">

    <!-- Contact info -->
    <div class="tf-contact-info-card">
      <h3><?php esc_html_e( 'Contact Info', 'themeflex' ); ?></h3>

      <div class="tf-contact-info-item">
        <div class="tf-contact-info-icon" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M22 7l-10 7L2 7"/></svg></div>
        <div>
          <div class="tf-contact-info-label"><?php esc_html_e( 'Email', 'themeflex' ); ?></div>
          <div class="tf-contact-info-value">
            <a href="mailto:hello@themeflex.de">hello@themeflex.de</a>
          </div>
        </div>
      </div>

      <div class="tf-contact-info-item">
        <div class="tf-contact-info-icon" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg></div>
        <div>
          <div class="tf-contact-info-label"><?php esc_html_e( 'Website', 'themeflex' ); ?></div>
          <div class="tf-contact-info-value">
            <a href="https://themeflex.de" target="_blank" rel="noopener">themeflex.de</a>
          </div>
        </div>
      </div>

      <div class="tf-contact-info-item">
        <div class="tf-contact-info-icon" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></div>
        <div>
          <div class="tf-contact-info-label"><?php esc_html_e( 'Support Hours', 'themeflex' ); ?></div>
          <div class="tf-contact-info-value"><?php esc_html_e( 'Mon–Fri, 9:00–18:00 CET', 'themeflex' ); ?></div>
        </div>
      </div>

      <div class="tf-contact-status">
        <div class="tf-contact-status-dot"></div>
        <span class="tf-contact-status-txt"><?php esc_html_e( 'Team is online — typically replies in hours', 'themeflex' ); ?></span>
      </div>

      <div style="margin-top:18px">
        <div class="tf-contact-info-label" style="margin-bottom:10px"><?php esc_html_e( 'Follow Us', 'themeflex' ); ?></div>
        <div class="tf-contact-socials">
          <a href="<?php echo esc_url( get_theme_mod( 'sf_social_twitter', '#' ) ); ?>" class="tf-contact-social-link" aria-label="X / Twitter">
            <i class="fa-brands fa-x-twitter" aria-hidden="true"></i>
          </a>
          <a href="<?php echo esc_url( get_theme_mod( 'sf_social_github', '#' ) ); ?>" class="tf-contact-social-link" aria-label="GitHub">
            <i class="fa-brands fa-github" aria-hidden="true"></i>
          </a>
          <a href="<?php echo esc_url( get_theme_mod( 'sf_social_linkedin', '#' ) ); ?>" class="tf-contact-social-link" aria-label="LinkedIn">
            <i class="fa-brands fa-linkedin-in" aria-hidden="true"></i>
          </a>
          <a href="<?php echo esc_url( get_theme_mod( 'sf_social_dribbble', '#' ) ); ?>" class="tf-contact-social-link" aria-label="Dribbble">
            <i class="fa-brands fa-dribbble" aria-hidden="true"></i>
          </a>
        </div>
      </div>
    </div>

    <!-- Response time card -->
    <div class="tf-contact-response">
      <div class="tf-contact-response-num">&lt; 24h</div>
      <div class="tf-contact-response-txt"><?php esc_html_e( 'Average first response time on business days', 'themeflex' ); ?></div>
    </div>

    <!-- ThemeForest support link -->
    <div class="tf-contact-info-card" style="text-align:center">
      <div style="width:44px;height:44px;margin:0 auto 12px;display:flex;align-items:center;justify-content:center;background:rgba(99,102,241,.12);border-radius:10px;color:rgba(99,102,241,.9)" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" width="20" height="20"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg></div>
      <h3 style="text-transform:none;font-size:.95rem;letter-spacing:0;color:var(--title);margin-bottom:8px">
        <?php esc_html_e( 'Purchased on ThemeForest?', 'themeflex' ); ?>
      </h3>
      <p style="font-size:.85rem;color:var(--meta);margin:0 0 18px;line-height:1.6">
        <?php esc_html_e( "Post a comment on the item page for licence-specific support — it's the fastest way to get help.", 'themeflex' ); ?>
      </p>
      <a
        href="https://themeforest.net/item/themeflex"
        target="_blank" rel="noopener"
        style="display:inline-flex;align-items:center;gap:8px;background:var(--tc);color:#fff;font-size:.85rem;font-weight:700;padding:10px 22px;border-radius:10px;text-decoration:none;transition:background .2s;"
        onmouseover="this.style.background='#e04e22'" onmouseout="this.style.background='#ff5e2e'"
      >
        <?php esc_html_e( 'Go to ThemeForest', 'themeflex' ); ?> →
      </a>
    </div>

  </aside>
</div><!-- .tf-contact-grid -->
</div><!-- .tf-contact-wrap -->

<?php
/* ── Register AJAX/POST handler for the built-in form ─────── */
add_action( 'admin_post_tf_contact_form',        'tf_handle_contact_form' );
add_action( 'admin_post_nopriv_tf_contact_form', 'tf_handle_contact_form' );

if ( ! function_exists( 'tf_handle_contact_form' ) ) :
function tf_handle_contact_form() {
	// Verify nonce
	if ( ! isset( $_POST['tf_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['tf_nonce'] ) ), 'tf_contact_nonce' ) ) {
		wp_safe_redirect( add_query_arg( 'tf_sent', '0', sanitize_url( wp_unslash( $_POST['redirect_to'] ?? home_url( '/contact' ) ) ) ) );
		exit;
	}

	// Honeypot
	if ( ! empty( $_POST['tf_website'] ) ) {
		wp_safe_redirect( add_query_arg( 'tf_sent', '1', sanitize_url( wp_unslash( $_POST['redirect_to'] ?? home_url( '/contact' ) ) ) ) );
		exit;
	}

	$name    = sanitize_text_field( wp_unslash( $_POST['tf_name']    ?? '' ) );
	$email   = sanitize_email(      wp_unslash( $_POST['tf_email']   ?? '' ) );
	$subject = sanitize_text_field( wp_unslash( $_POST['tf_subject'] ?? 'Contact Form' ) );
	$message = sanitize_textarea_field( wp_unslash( $_POST['tf_message'] ?? '' ) );

	if ( empty( $name ) || ! is_email( $email ) || empty( $message ) ) {
		wp_safe_redirect( add_query_arg( 'tf_sent', '0', sanitize_url( wp_unslash( $_POST['redirect_to'] ?? home_url( '/contact' ) ) ) ) );
		exit;
	}

	$to      = get_option( 'admin_email' );
	$subj    = sprintf( '[ThemeFlex Contact] %s — from %s', $subject, $name );
	$body    = "Name: {$name}\nEmail: {$email}\nSubject: {$subject}\n\n{$message}";
	$headers = array( "Reply-To: {$name} <{$email}>", 'Content-Type: text/plain; charset=UTF-8' );

	$sent = wp_mail( $to, $subj, $body, $headers );

	wp_safe_redirect( add_query_arg( 'tf_sent', $sent ? '1' : '0', sanitize_url( wp_unslash( $_POST['redirect_to'] ?? home_url( '/contact' ) ) ) ) );
	exit;
}
endif;
?>

</main><!-- #primary -->

<?php get_footer(); ?>
