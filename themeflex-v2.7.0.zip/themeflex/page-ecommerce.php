<?php
/**
 * Template Name: E-Commerce Homepage
 *
 * Premium dark-first WooCommerce landing page with product showcase,
 * category grid, promotional banner, and conversion-focused layout.
 *
 * @package ThemeFlex
 * @since   2.6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<style>
/* ============================================================
   PAGE-ECOMMERCE — SCOPED STYLES
   ============================================================ */

/* ---- Reset & tokens ---- */
.tf-ec-page { color: var(--tf-text, #e2e8f0); }
.tf-ec-page *,
.tf-ec-page *::before,
.tf-ec-page *::after { box-sizing: border-box; }

.tf-ec-page section { position: relative; overflow: hidden; }

.tf-ec-container {
	max-width: 1200px;
	margin-inline: auto;
	padding-inline: 1.5rem;
}
.tf-ec-eyebrow {
	display: inline-flex;
	align-items: center;
	gap: .5rem;
	font-size: .75rem;
	font-weight: 700;
	letter-spacing: .12em;
	text-transform: uppercase;
	color: var(--tf-accent, #ff5e2e);
	margin-bottom: 1rem;
}
.tf-ec-eyebrow-dot {
	width: 6px; height: 6px;
	border-radius: 50%;
	background: var(--tf-accent, #ff5e2e);
}
.tf-ec-section-title {
	font-size: clamp(1.75rem, 3.5vw, 2.5rem);
	font-weight: 800;
	line-height: 1.2;
	color: var(--tf-heading, #f8fafc);
	margin: 0 0 1rem;
}
.tf-ec-section-sub {
	font-size: 1.05rem;
	color: var(--tf-muted, #94a3b8);
	max-width: 560px;
	line-height: 1.7;
	margin: 0 0 2.5rem;
}

/* ============================================================
   1. HERO SECTION
   ============================================================ */
.tf-ec-hero {
	min-height: 100vh;
	display: flex;
	align-items: center;
	background: var(--tf-bg, #06021d);
	padding: 7rem 0 5rem;
}
.tf-ec-hero__grid {
	display: grid;
	grid-template-columns: 1fr 1fr;
	gap: 4rem;
	align-items: center;
}
.tf-ec-hero__badge {
	display: inline-flex;
	align-items: center;
	gap: .5rem;
	background: rgba(255,94,46,.12);
	border: 1px solid rgba(255,94,46,.3);
	border-radius: 100px;
	padding: .35rem .9rem;
	font-size: .75rem;
	font-weight: 700;
	letter-spacing: .08em;
	color: var(--tf-accent, #ff5e2e);
	text-transform: uppercase;
	margin-bottom: 1.5rem;
}
.tf-ec-hero__title {
	font-size: clamp(2.5rem, 5vw, 3.8rem);
	font-weight: 900;
	line-height: 1.1;
	color: var(--tf-heading, #f8fafc);
	margin: 0 0 1.5rem;
}
.tf-ec-hero__title span {
	background: linear-gradient(135deg, var(--tf-accent, #ff5e2e) 0%, #ff9a56 100%);
	-webkit-background-clip: text;
	-webkit-text-fill-color: transparent;
	background-clip: text;
}
.tf-ec-hero__desc {
	font-size: 1.1rem;
	color: var(--tf-muted, #94a3b8);
	line-height: 1.75;
	margin: 0 0 2.25rem;
	max-width: 520px;
}
.tf-ec-hero__actions {
	display: flex;
	align-items: center;
	gap: 1rem;
	flex-wrap: wrap;
	margin-bottom: 2.5rem;
}
.tf-ec-btn-primary {
	display: inline-flex;
	align-items: center;
	gap: .5rem;
	background: var(--tf-accent, #ff5e2e);
	color: #fff;
	font-weight: 700;
	font-size: .95rem;
	padding: .85rem 1.75rem;
	border-radius: 10px;
	text-decoration: none;
	transition: filter .2s, transform .2s;
}
.tf-ec-btn-primary:hover { filter: brightness(1.12); transform: translateY(-1px); }
.tf-ec-btn-ghost {
	display: inline-flex;
	align-items: center;
	gap: .5rem;
	background: transparent;
	color: var(--tf-text, #e2e8f0);
	font-weight: 600;
	font-size: .95rem;
	padding: .85rem 1.5rem;
	border-radius: 10px;
	border: 1px solid var(--tf-border, rgba(255,255,255,.1));
	text-decoration: none;
	transition: border-color .2s, background .2s;
}
.tf-ec-btn-ghost:hover {
	border-color: var(--tf-accent, #ff5e2e);
	background: rgba(255,94,46,.06);
}
.tf-ec-hero__trust {
	display: flex;
	align-items: center;
	gap: 1.5rem;
	flex-wrap: wrap;
}
.tf-ec-hero__trust-item {
	display: flex;
	align-items: center;
	gap: .4rem;
	font-size: .82rem;
	color: var(--tf-muted, #94a3b8);
}
.tf-ec-hero__trust-item svg { color: var(--tf-accent, #ff5e2e); }

/* ---- Hero product mockup (CSS art) ---- */
.tf-ec-hero__visual {
	position: relative;
	height: 520px;
}

/* Glowing orb bg */
.tf-ec-hero__orb {
	position: absolute;
	border-radius: 50%;
	filter: blur(80px);
	pointer-events: none;
}
.tf-ec-hero__orb--1 {
	width: 340px; height: 340px;
	background: radial-gradient(circle, rgba(255,94,46,.22) 0%, transparent 70%);
	top: 10%; right: 0;
}
.tf-ec-hero__orb--2 {
	width: 260px; height: 260px;
	background: radial-gradient(circle, rgba(99,102,241,.18) 0%, transparent 70%);
	bottom: 0; left: 10%;
}

/* Main product card */
.tf-ec-product-card-main {
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-55%, -50%);
	width: 260px;
	background: var(--tf-bg-2, #0d1526);
	border: 1px solid var(--tf-border, rgba(255,255,255,.1));
	border-radius: 20px;
	overflow: hidden;
	box-shadow: 0 32px 80px rgba(0,0,0,.5);
	z-index: 3;
}
.tf-ec-product-img-placeholder {
	height: 200px;
	background: linear-gradient(135deg,
		rgba(255,94,46,.18) 0%,
		rgba(99,102,241,.25) 50%,
		rgba(16,185,129,.15) 100%
	);
	display: flex;
	align-items: center;
	justify-content: center;
	position: relative;
	overflow: hidden;
}
.tf-ec-product-img-placeholder::before {
	content: '';
	position: absolute;
	inset: 0;
	background: radial-gradient(circle at 60% 40%, rgba(255,94,46,.25) 0%, transparent 60%);
}
.tf-ec-product-img-placeholder::after {
	content: '';
	position: absolute;
	width: 80px; height: 80px;
	border-radius: 16px;
	background: rgba(255,255,255,.06);
	border: 1px solid rgba(255,255,255,.12);
}
.tf-ec-product-icon-wrap {
	position: relative;
	z-index: 1;
	display: flex;
	align-items: center;
	justify-content: center;
	width: 72px; height: 72px;
	background: rgba(255,94,46,.15);
	border-radius: 16px;
	border: 1px solid rgba(255,94,46,.3);
}
.tf-ec-product-body {
	padding: 1rem 1.1rem 1.25rem;
}
.tf-ec-product-body-tag {
	display: inline-block;
	font-size: .68rem;
	font-weight: 700;
	letter-spacing: .1em;
	text-transform: uppercase;
	background: rgba(255,94,46,.15);
	color: var(--tf-accent, #ff5e2e);
	border-radius: 4px;
	padding: .2rem .5rem;
	margin-bottom: .5rem;
}
.tf-ec-product-body-name {
	font-size: 1rem;
	font-weight: 700;
	color: var(--tf-heading, #f8fafc);
	margin: 0 0 .35rem;
}
.tf-ec-product-body-stars {
	display: flex;
	align-items: center;
	gap: .25rem;
	margin-bottom: .6rem;
	color: #fbbf24;
	font-size: .78rem;
}
.tf-ec-product-body-price-row {
	display: flex;
	align-items: center;
	justify-content: space-between;
}
.tf-ec-product-body-price {
	font-size: 1.25rem;
	font-weight: 800;
	color: var(--tf-accent, #ff5e2e);
}
.tf-ec-product-body-price-old {
	font-size: .8rem;
	color: var(--tf-muted, #94a3b8);
	text-decoration: line-through;
	margin-left: .4rem;
}
.tf-ec-add-to-cart {
	display: flex;
	align-items: center;
	gap: .4rem;
	background: var(--tf-accent, #ff5e2e);
	color: #fff;
	font-size: .78rem;
	font-weight: 700;
	padding: .45rem .85rem;
	border-radius: 8px;
}

/* Mini floating cards */
.tf-ec-float-card {
	position: absolute;
	background: var(--tf-bg-2, #0d1526);
	border: 1px solid var(--tf-border, rgba(255,255,255,.1));
	border-radius: 14px;
	padding: .75rem 1rem;
	box-shadow: 0 16px 40px rgba(0,0,0,.4);
	z-index: 4;
}
.tf-ec-float-delivery {
	top: 8%;
	right: 0;
	width: 190px;
	display: flex;
	align-items: center;
	gap: .75rem;
}
.tf-ec-float-delivery-icon {
	width: 36px; height: 36px;
	border-radius: 10px;
	background: rgba(16,185,129,.15);
	border: 1px solid rgba(16,185,129,.3);
	display: flex;
	align-items: center;
	justify-content: center;
	color: #10b981;
	flex-shrink: 0;
}
.tf-ec-float-delivery-text strong {
	display: block;
	font-size: .8rem;
	font-weight: 700;
	color: var(--tf-heading, #f8fafc);
}
.tf-ec-float-delivery-text span {
	font-size: .72rem;
	color: var(--tf-muted, #94a3b8);
}

.tf-ec-float-rating {
	bottom: 18%;
	right: -10px;
	width: 170px;
	text-align: center;
}
.tf-ec-float-rating-score {
	font-size: 1.8rem;
	font-weight: 900;
	color: var(--tf-heading, #f8fafc);
	line-height: 1;
	margin-bottom: .2rem;
}
.tf-ec-float-rating-stars {
	color: #fbbf24;
	font-size: .9rem;
	margin-bottom: .2rem;
	letter-spacing: .1em;
}
.tf-ec-float-rating-label {
	font-size: .72rem;
	color: var(--tf-muted, #94a3b8);
}
.tf-ec-float-badge {
	top: 30%;
	left: -15px;
	display: flex;
	align-items: center;
	gap: .5rem;
}
.tf-ec-float-badge-dot {
	width: 8px; height: 8px;
	border-radius: 50%;
	background: #10b981;
	box-shadow: 0 0 0 3px rgba(16,185,129,.2);
}
.tf-ec-float-badge-text {
	font-size: .78rem;
	font-weight: 700;
	color: var(--tf-heading, #f8fafc);
}

/* ============================================================
   2. STATS BAR
   ============================================================ */
.tf-ec-stats {
	background: var(--tf-bg-2, #0d1526);
	border-top: 1px solid var(--tf-border, rgba(255,255,255,.07));
	border-bottom: 1px solid var(--tf-border, rgba(255,255,255,.07));
	padding: 2rem 0;
}
.tf-ec-stats__grid {
	display: grid;
	grid-template-columns: repeat(4, 1fr);
	gap: 0;
}
.tf-ec-stats__item {
	display: flex;
	align-items: center;
	gap: .9rem;
	padding: .5rem 1.5rem;
	border-right: 1px solid var(--tf-border, rgba(255,255,255,.07));
}
.tf-ec-stats__item:last-child { border-right: none; }
.tf-ec-stats__icon {
	width: 44px; height: 44px;
	border-radius: 12px;
	display: flex;
	align-items: center;
	justify-content: center;
	flex-shrink: 0;
}
.tf-ec-stats__icon--orange { background: rgba(255,94,46,.12); color: var(--tf-accent, #ff5e2e); }
.tf-ec-stats__icon--green  { background: rgba(16,185,129,.12); color: #10b981; }
.tf-ec-stats__icon--blue   { background: rgba(99,102,241,.12); color: #818cf8; }
.tf-ec-stats__icon--yellow { background: rgba(251,191,36,.12); color: #fbbf24; }
.tf-ec-stats__value {
	font-size: 1.5rem;
	font-weight: 800;
	color: var(--tf-heading, #f8fafc);
	line-height: 1;
}
.tf-ec-stats__label {
	font-size: .78rem;
	color: var(--tf-muted, #94a3b8);
	margin-top: .2rem;
}

/* ============================================================
   3. FEATURED CATEGORIES
   ============================================================ */
.tf-ec-categories {
	background: var(--tf-bg, #06021d);
	padding: 6rem 0;
}
.tf-ec-categories__header {
	text-align: center;
	margin-bottom: 3rem;
}
.tf-ec-categories__header .tf-ec-section-sub { margin-inline: auto; }
.tf-ec-categories__grid {
	display: grid;
	grid-template-columns: repeat(4, 1fr);
	gap: 1.25rem;
}
.tf-ec-cat-card {
	position: relative;
	border-radius: 20px;
	overflow: hidden;
	background: var(--tf-bg-2, #0d1526);
	border: 1px solid var(--tf-border, rgba(255,255,255,.07));
	padding: 2rem 1.5rem;
	transition: transform .25s, border-color .25s;
	cursor: pointer;
	text-decoration: none;
	display: block;
}
.tf-ec-cat-card:hover {
	transform: translateY(-4px);
	border-color: rgba(255,94,46,.35);
}
.tf-ec-cat-card::before {
	content: '';
	position: absolute;
	inset: 0;
	opacity: 0;
	transition: opacity .25s;
}
.tf-ec-cat-card:hover::before { opacity: 1; }
.tf-ec-cat-card--electronics::before { background: radial-gradient(circle at 50% 0, rgba(99,102,241,.12) 0%, transparent 70%); }
.tf-ec-cat-card--fashion::before    { background: radial-gradient(circle at 50% 0, rgba(236,72,153,.12) 0%, transparent 70%); }
.tf-ec-cat-card--home::before       { background: radial-gradient(circle at 50% 0, rgba(16,185,129,.12) 0%, transparent 70%); }
.tf-ec-cat-card--sport::before      { background: radial-gradient(circle at 50% 0, rgba(255,94,46,.12) 0%, transparent 70%); }

.tf-ec-cat-icon {
	width: 52px; height: 52px;
	border-radius: 14px;
	display: flex;
	align-items: center;
	justify-content: center;
	margin-bottom: 1.25rem;
}
.tf-ec-cat-icon--electronics { background: rgba(99,102,241,.15); color: #818cf8; }
.tf-ec-cat-icon--fashion     { background: rgba(236,72,153,.15); color: #f472b6; }
.tf-ec-cat-icon--home        { background: rgba(16,185,129,.15); color: #10b981; }
.tf-ec-cat-icon--sport       { background: rgba(255,94,46,.15);  color: var(--tf-accent, #ff5e2e); }

.tf-ec-cat-name {
	font-size: 1.05rem;
	font-weight: 700;
	color: var(--tf-heading, #f8fafc);
	margin: 0 0 .3rem;
}
.tf-ec-cat-count {
	font-size: .82rem;
	color: var(--tf-muted, #94a3b8);
	margin: 0 0 1.25rem;
}
.tf-ec-cat-link {
	display: inline-flex;
	align-items: center;
	gap: .3rem;
	font-size: .82rem;
	font-weight: 700;
	color: var(--tf-accent, #ff5e2e);
}

/* ============================================================
   4. PRODUCT SHOWCASE
   ============================================================ */
.tf-ec-products {
	background: var(--tf-bg-3, #111827);
	padding: 6rem 0;
}
.tf-ec-products__header {
	display: flex;
	align-items: flex-end;
	justify-content: space-between;
	margin-bottom: 3rem;
	flex-wrap: wrap;
	gap: 1rem;
}
.tf-ec-products__tabs {
	display: flex;
	gap: .5rem;
	flex-wrap: wrap;
}
.tf-ec-products__tab {
	background: none;
	border: 1px solid var(--tf-border, rgba(255,255,255,.1));
	color: var(--tf-muted, #94a3b8);
	font-size: .82rem;
	font-weight: 600;
	padding: .45rem 1rem;
	border-radius: 8px;
	cursor: pointer;
	transition: all .18s;
}
.tf-ec-products__tab.active,
.tf-ec-products__tab:hover {
	background: var(--tf-accent, #ff5e2e);
	border-color: var(--tf-accent, #ff5e2e);
	color: #fff;
}
.tf-ec-products__grid {
	display: grid;
	grid-template-columns: repeat(3, 1fr);
	gap: 1.5rem;
}
.tf-ec-prod-card {
	background: var(--tf-bg-2, #0d1526);
	border: 1px solid var(--tf-border, rgba(255,255,255,.07));
	border-radius: 18px;
	overflow: hidden;
	transition: transform .25s, border-color .25s, box-shadow .25s;
}
.tf-ec-prod-card:hover {
	transform: translateY(-5px);
	border-color: rgba(255,94,46,.25);
	box-shadow: 0 20px 60px rgba(0,0,0,.35);
}
.tf-ec-prod-img {
	height: 180px;
	display: flex;
	align-items: center;
	justify-content: center;
	position: relative;
	overflow: hidden;
}
.tf-ec-prod-img--violet   { background: linear-gradient(135deg, rgba(99,102,241,.2) 0%, rgba(139,92,246,.15) 100%); color: #818cf8; }
.tf-ec-prod-img--rose     { background: linear-gradient(135deg, rgba(236,72,153,.2) 0%, rgba(168,85,247,.15) 100%); color: #f472b6; }
.tf-ec-prod-img--green    { background: linear-gradient(135deg, rgba(16,185,129,.2) 0%, rgba(5,150,105,.15) 100%); color: #10b981; }
.tf-ec-prod-img--amber    { background: linear-gradient(135deg, rgba(245,158,11,.2) 0%, rgba(217,119,6,.15) 100%); color: #fbbf24; }
.tf-ec-prod-img--orange   { background: linear-gradient(135deg, rgba(255,94,46,.2)  0%, rgba(249,115,22,.15) 100%); color: var(--tf-accent, #ff5e2e); }
.tf-ec-prod-img--cyan     { background: linear-gradient(135deg, rgba(6,182,212,.2)  0%, rgba(14,165,233,.15) 100%); color: #22d3ee; }

.tf-ec-prod-img__icon {
	width: 56px; height: 56px;
	border-radius: 14px;
	background: rgba(255,255,255,.06);
	border: 1px solid rgba(255,255,255,.12);
	display: flex;
	align-items: center;
	justify-content: center;
}
.tf-ec-prod-badge {
	position: absolute;
	top: .75rem;
	right: .75rem;
	font-size: .68rem;
	font-weight: 700;
	letter-spacing: .06em;
	padding: .25rem .55rem;
	border-radius: 6px;
}
.tf-ec-prod-badge--sale { background: var(--tf-accent, #ff5e2e); color: #fff; }
.tf-ec-prod-badge--new  { background: #10b981; color: #fff; }
.tf-ec-prod-badge--hot  { background: #f59e0b; color: #111; }

.tf-ec-prod-info { padding: 1.25rem; }
.tf-ec-prod-category {
	font-size: .72rem;
	font-weight: 600;
	color: var(--tf-muted, #94a3b8);
	text-transform: uppercase;
	letter-spacing: .08em;
	margin-bottom: .4rem;
}
.tf-ec-prod-name {
	font-size: .95rem;
	font-weight: 700;
	color: var(--tf-heading, #f8fafc);
	margin: 0 0 .5rem;
}
.tf-ec-prod-stars {
	display: flex;
	align-items: center;
	gap: .3rem;
	margin-bottom: .75rem;
}
.tf-ec-prod-stars__icons { color: #fbbf24; font-size: .78rem; }
.tf-ec-prod-stars__count { font-size: .75rem; color: var(--tf-muted, #94a3b8); }
.tf-ec-prod-price-row {
	display: flex;
	align-items: center;
	justify-content: space-between;
}
.tf-ec-prod-price {
	font-size: 1.2rem;
	font-weight: 800;
	color: var(--tf-heading, #f8fafc);
}
.tf-ec-prod-price--sale { color: var(--tf-accent, #ff5e2e); }
.tf-ec-prod-price-old {
	font-size: .8rem;
	color: var(--tf-muted, #94a3b8);
	text-decoration: line-through;
	margin-left: .35rem;
}
.tf-ec-prod-cart-btn {
	display: flex;
	align-items: center;
	justify-content: center;
	gap: .35rem;
	background: rgba(255,94,46,.12);
	color: var(--tf-accent, #ff5e2e);
	border: 1px solid rgba(255,94,46,.25);
	font-size: .8rem;
	font-weight: 700;
	padding: .5rem .9rem;
	border-radius: 8px;
	cursor: pointer;
	transition: all .18s;
	text-decoration: none;
}
.tf-ec-prod-cart-btn:hover {
	background: var(--tf-accent, #ff5e2e);
	color: #fff;
	border-color: var(--tf-accent, #ff5e2e);
}

/* ============================================================
   5. PROMO BANNER
   ============================================================ */
.tf-ec-promo {
	background: var(--tf-bg, #06021d);
	padding: 2rem 0;
}
.tf-ec-promo__inner {
	position: relative;
	border-radius: 24px;
	overflow: hidden;
	background: linear-gradient(135deg, #1a0a00 0%, #1c0e1c 50%, #060a1d 100%);
	border: 1px solid rgba(255,94,46,.2);
	padding: 3.5rem;
	display: flex;
	align-items: center;
	gap: 3rem;
}
.tf-ec-promo__orb-1 {
	position: absolute;
	top: -60px; left: -60px;
	width: 300px; height: 300px;
	border-radius: 50%;
	background: radial-gradient(circle, rgba(255,94,46,.25) 0%, transparent 70%);
	filter: blur(40px);
	pointer-events: none;
}
.tf-ec-promo__orb-2 {
	position: absolute;
	bottom: -40px; right: 25%;
	width: 200px; height: 200px;
	border-radius: 50%;
	background: radial-gradient(circle, rgba(99,102,241,.2) 0%, transparent 70%);
	filter: blur(30px);
	pointer-events: none;
}
.tf-ec-promo__content { flex: 1; position: relative; z-index: 1; }
.tf-ec-promo__tag {
	display: inline-block;
	background: rgba(255,94,46,.2);
	border: 1px solid rgba(255,94,46,.35);
	color: var(--tf-accent, #ff5e2e);
	font-size: .72rem;
	font-weight: 700;
	letter-spacing: .1em;
	text-transform: uppercase;
	padding: .3rem .8rem;
	border-radius: 6px;
	margin-bottom: 1rem;
}
.tf-ec-promo__title {
	font-size: clamp(1.5rem, 3vw, 2.2rem);
	font-weight: 900;
	color: #fff;
	margin: 0 0 .75rem;
	line-height: 1.2;
}
.tf-ec-promo__desc {
	color: rgba(255,255,255,.65);
	font-size: .95rem;
	margin: 0 0 1.75rem;
	line-height: 1.6;
}
.tf-ec-promo__cta {
	display: inline-flex;
	align-items: center;
	gap: .5rem;
	background: var(--tf-accent, #ff5e2e);
	color: #fff;
	font-weight: 700;
	font-size: .95rem;
	padding: .9rem 2rem;
	border-radius: 10px;
	text-decoration: none;
	transition: filter .2s;
}
.tf-ec-promo__cta:hover { filter: brightness(1.12); }

/* Countdown */
.tf-ec-promo__countdown { position: relative; z-index: 1; }
.tf-ec-countdown-label {
	font-size: .75rem;
	font-weight: 600;
	color: rgba(255,255,255,.5);
	text-transform: uppercase;
	letter-spacing: .1em;
	margin-bottom: .75rem;
	text-align: center;
}
.tf-ec-countdown-grid {
	display: flex;
	gap: .5rem;
	align-items: center;
}
.tf-ec-countdown-cell {
	background: rgba(0,0,0,.4);
	border: 1px solid rgba(255,255,255,.1);
	border-radius: 12px;
	width: 72px;
	text-align: center;
	padding: .75rem .5rem;
}
.tf-ec-countdown-num {
	font-size: 2rem;
	font-weight: 900;
	color: #fff;
	line-height: 1;
	font-variant-numeric: tabular-nums;
}
.tf-ec-countdown-unit {
	font-size: .65rem;
	font-weight: 600;
	color: rgba(255,255,255,.45);
	text-transform: uppercase;
	letter-spacing: .08em;
	margin-top: .2rem;
}
.tf-ec-countdown-sep {
	font-size: 1.5rem;
	font-weight: 700;
	color: var(--tf-accent, #ff5e2e);
	margin-bottom: 1rem;
}
.tf-ec-promo__discount {
	background: linear-gradient(135deg, var(--tf-accent, #ff5e2e), #ff9a56);
	-webkit-background-clip: text;
	-webkit-text-fill-color: transparent;
	background-clip: text;
	font-size: 5rem;
	font-weight: 900;
	line-height: 1;
	text-align: center;
	margin-bottom: .25rem;
}
.tf-ec-promo__discount-label {
	font-size: .85rem;
	color: rgba(255,255,255,.5);
	text-align: center;
}

/* ============================================================
   6. BENEFITS BAR
   ============================================================ */
.tf-ec-benefits {
	background: var(--tf-bg-2, #0d1526);
	border-top: 1px solid var(--tf-border, rgba(255,255,255,.07));
	border-bottom: 1px solid var(--tf-border, rgba(255,255,255,.07));
	padding: 3rem 0;
}
.tf-ec-benefits__grid {
	display: grid;
	grid-template-columns: repeat(4, 1fr);
	gap: 1rem;
}
.tf-ec-benefit {
	display: flex;
	align-items: flex-start;
	gap: 1rem;
	padding: .5rem;
}
.tf-ec-benefit__icon {
	width: 48px; height: 48px;
	border-radius: 14px;
	display: flex;
	align-items: center;
	justify-content: center;
	flex-shrink: 0;
}
.tf-ec-benefit__icon--orange { background: rgba(255,94,46,.12); color: var(--tf-accent, #ff5e2e); }
.tf-ec-benefit__icon--green  { background: rgba(16,185,129,.12); color: #10b981; }
.tf-ec-benefit__icon--blue   { background: rgba(99,102,241,.12); color: #818cf8; }
.tf-ec-benefit__icon--yellow { background: rgba(251,191,36,.12); color: #fbbf24; }
.tf-ec-benefit__title {
	font-size: .9rem;
	font-weight: 700;
	color: var(--tf-heading, #f8fafc);
	margin: 0 0 .3rem;
}
.tf-ec-benefit__desc {
	font-size: .8rem;
	color: var(--tf-muted, #94a3b8);
	line-height: 1.5;
	margin: 0;
}

/* ============================================================
   7. TESTIMONIALS
   ============================================================ */
.tf-ec-testimonials {
	background: var(--tf-bg, #06021d);
	padding: 6rem 0;
}
.tf-ec-testimonials__header {
	text-align: center;
	margin-bottom: 3rem;
}
.tf-ec-testimonials__header .tf-ec-section-sub { margin-inline: auto; }
.tf-ec-testimonials__grid {
	display: grid;
	grid-template-columns: repeat(3, 1fr);
	gap: 1.5rem;
}
.tf-ec-review-card {
	background: var(--tf-bg-2, #0d1526);
	border: 1px solid var(--tf-border, rgba(255,255,255,.07));
	border-radius: 18px;
	padding: 1.75rem;
	transition: transform .25s;
}
.tf-ec-review-card:hover { transform: translateY(-3px); }
.tf-ec-review-stars {
	color: #fbbf24;
	font-size: 1rem;
	letter-spacing: .1em;
	margin-bottom: 1rem;
}
.tf-ec-review-text {
	font-size: .9rem;
	color: var(--tf-text, #e2e8f0);
	line-height: 1.7;
	margin: 0 0 1.25rem;
	font-style: italic;
}
.tf-ec-review-text::before { content: '\201C'; }
.tf-ec-review-text::after  { content: '\201D'; }
.tf-ec-review-author {
	display: flex;
	align-items: center;
	gap: .75rem;
}
.tf-ec-review-avatar {
	width: 40px; height: 40px;
	border-radius: 50%;
	display: flex;
	align-items: center;
	justify-content: center;
	font-size: .85rem;
	font-weight: 800;
	flex-shrink: 0;
}
.tf-ec-review-avatar--1 { background: rgba(255,94,46,.2);  color: var(--tf-accent, #ff5e2e); }
.tf-ec-review-avatar--2 { background: rgba(99,102,241,.2); color: #818cf8; }
.tf-ec-review-avatar--3 { background: rgba(16,185,129,.2); color: #10b981; }
.tf-ec-review-name {
	font-size: .88rem;
	font-weight: 700;
	color: var(--tf-heading, #f8fafc);
}
.tf-ec-review-meta {
	font-size: .75rem;
	color: var(--tf-muted, #94a3b8);
}
.tf-ec-review-verified {
	margin-left: auto;
	display: flex;
	align-items: center;
	gap: .25rem;
	font-size: .72rem;
	color: #10b981;
	font-weight: 600;
}

/* ============================================================
   8. NEWSLETTER CTA
   ============================================================ */
.tf-ec-newsletter {
	background: var(--tf-bg-3, #111827);
	padding: 6rem 0;
	border-top: 1px solid var(--tf-border, rgba(255,255,255,.07));
}
.tf-ec-newsletter__inner {
	max-width: 640px;
	margin-inline: auto;
	text-align: center;
}
.tf-ec-newsletter__icon {
	width: 64px; height: 64px;
	border-radius: 18px;
	background: rgba(255,94,46,.12);
	border: 1px solid rgba(255,94,46,.25);
	display: flex;
	align-items: center;
	justify-content: center;
	margin: 0 auto 1.5rem;
	color: var(--tf-accent, #ff5e2e);
}
.tf-ec-newsletter__title {
	font-size: clamp(1.75rem, 3.5vw, 2.5rem);
	font-weight: 800;
	color: var(--tf-heading, #f8fafc);
	margin: 0 0 .75rem;
}
.tf-ec-newsletter__desc {
	color: var(--tf-muted, #94a3b8);
	font-size: 1rem;
	margin: 0 0 2rem;
	line-height: 1.7;
}
.tf-ec-newsletter__form {
	display: flex;
	gap: .75rem;
	justify-content: center;
	flex-wrap: wrap;
}
.tf-ec-newsletter__input {
	flex: 1;
	min-width: 240px;
	background: var(--tf-bg-2, #0d1526);
	border: 1px solid var(--tf-border, rgba(255,255,255,.1));
	border-radius: 10px;
	padding: .85rem 1.25rem;
	color: var(--tf-text, #e2e8f0);
	font-size: .95rem;
	outline: none;
	transition: border-color .18s;
}
.tf-ec-newsletter__input:focus { border-color: var(--tf-accent, #ff5e2e); }
.tf-ec-newsletter__input::placeholder { color: var(--tf-muted, #94a3b8); }
.tf-ec-newsletter__submit {
	display: inline-flex;
	align-items: center;
	gap: .5rem;
	background: var(--tf-accent, #ff5e2e);
	color: #fff;
	font-weight: 700;
	font-size: .95rem;
	padding: .85rem 1.75rem;
	border-radius: 10px;
	border: none;
	cursor: pointer;
	transition: filter .2s;
}
.tf-ec-newsletter__submit:hover { filter: brightness(1.12); }
.tf-ec-newsletter__small {
	margin-top: 1rem;
	font-size: .78rem;
	color: var(--tf-muted, #94a3b8);
	display: flex;
	align-items: center;
	justify-content: center;
	gap: .3rem;
}

/* ============================================================
   RESPONSIVE
   ============================================================ */
@media (max-width: 1024px) {
	.tf-ec-hero__grid { grid-template-columns: 1fr; gap: 3rem; }
	.tf-ec-hero__visual { height: 400px; }
	.tf-ec-categories__grid { grid-template-columns: repeat(2, 1fr); }
	.tf-ec-products__grid  { grid-template-columns: repeat(2, 1fr); }
	.tf-ec-stats__grid     { grid-template-columns: repeat(2, 1fr); }
	.tf-ec-stats__item:nth-child(2) { border-right: none; }
	.tf-ec-benefits__grid  { grid-template-columns: repeat(2, 1fr); }
	.tf-ec-promo__inner    { flex-direction: column; padding: 2.5rem; }
}
@media (max-width: 640px) {
	.tf-ec-hero { padding: 5rem 0 3rem; }
	.tf-ec-hero__title { font-size: 2rem; }
	.tf-ec-hero__visual { display: none; }
	.tf-ec-categories__grid { grid-template-columns: 1fr; }
	.tf-ec-products__grid   { grid-template-columns: 1fr; }
	.tf-ec-stats__grid      { grid-template-columns: 1fr; }
	.tf-ec-stats__item      { border-right: none; border-bottom: 1px solid var(--tf-border, rgba(255,255,255,.07)); }
	.tf-ec-benefits__grid   { grid-template-columns: 1fr; }
	.tf-ec-testimonials__grid { grid-template-columns: 1fr; }
}

/* ---- Scroll animations ---- */
.tf-ec-reveal {
	opacity: 0;
	transform: translateY(24px);
	transition: opacity .55s ease, transform .55s ease;
}
.tf-ec-reveal.is-visible {
	opacity: 1;
	transform: none;
}
</style>

<main id="tf-ec-main" class="tf-ec-page" role="main">

	<?php
	/* ============================================================
	   1. HERO
	   ============================================================ */
	?>
	<section class="tf-ec-hero" aria-labelledby="tf-ec-hero-title">
		<div class="tf-ec-container">
			<div class="tf-ec-hero__grid">

				<!-- Text column -->
				<div class="tf-ec-hero__text">
					<div class="tf-ec-hero__badge">
						<?php echo tf_icon_get( 'zap', 14 ); ?>
						<?php esc_html_e( 'New Season Sale — Up to 60% Off', 'themeflex' ); ?>
					</div>
					<h1 id="tf-ec-hero-title" class="tf-ec-hero__title">
						<?php esc_html_e( 'Shop Smarter.', 'themeflex' ); ?><br>
						<span><?php esc_html_e( 'Live Better.', 'themeflex' ); ?></span>
					</h1>
					<p class="tf-ec-hero__desc">
						<?php esc_html_e( 'Discover thousands of curated products from trusted brands. Free shipping on orders over $49. Easy 30-day returns. Shop with confidence.', 'themeflex' ); ?>
					</p>
					<div class="tf-ec-hero__actions">
						<a href="<?php echo esc_url( home_url( '/shop' ) ); ?>" class="tf-ec-btn-primary">
							<?php echo tf_icon_get( 'shopping-bag', 18 ); ?>
							<?php esc_html_e( 'Shop Now', 'themeflex' ); ?>
						</a>
						<a href="<?php echo esc_url( home_url( '/product-category' ) ); ?>" class="tf-ec-btn-ghost">
							<?php echo tf_icon_get( 'grid', 18 ); ?>
							<?php esc_html_e( 'Browse Categories', 'themeflex' ); ?>
						</a>
					</div>
					<div class="tf-ec-hero__trust">
						<div class="tf-ec-hero__trust-item">
							<?php echo tf_icon_get( 'truck', 16 ); ?>
							<span><?php esc_html_e( 'Free Delivery', 'themeflex' ); ?></span>
						</div>
						<div class="tf-ec-hero__trust-item">
							<?php echo tf_icon_get( 'shield-check', 16 ); ?>
							<span><?php esc_html_e( 'Secure Payment', 'themeflex' ); ?></span>
						</div>
						<div class="tf-ec-hero__trust-item">
							<?php echo tf_icon_get( 'refresh-ccw', 16 ); ?>
							<span><?php esc_html_e( '30-Day Returns', 'themeflex' ); ?></span>
						</div>
					</div>
				</div>

				<!-- Visual column (CSS art) -->
				<div class="tf-ec-hero__visual" aria-hidden="true">
					<div class="tf-ec-hero__orb tf-ec-hero__orb--1"></div>
					<div class="tf-ec-hero__orb tf-ec-hero__orb--2"></div>

					<!-- Main product card -->
					<div class="tf-ec-product-card-main">
						<div class="tf-ec-product-img-placeholder">
							<div class="tf-ec-product-icon-wrap">
								<?php echo tf_icon_get( 'headphones', 32 ); ?>
							</div>
						</div>
						<div class="tf-ec-product-body">
							<div class="tf-ec-product-body-tag"><?php esc_html_e( 'Electronics', 'themeflex' ); ?></div>
							<h3 class="tf-ec-product-body-name"><?php esc_html_e( 'Pro Wireless ANC', 'themeflex' ); ?></h3>
							<div class="tf-ec-product-body-stars">
								<span>&#9733;&#9733;&#9733;&#9733;&#9733;</span>
								<span style="color:var(--tf-muted,#94a3b8);">(2,847)</span>
							</div>
							<div class="tf-ec-product-body-price-row">
								<div>
									<span class="tf-ec-product-body-price">$129</span>
									<span class="tf-ec-product-body-price-old">$199</span>
								</div>
								<div class="tf-ec-add-to-cart">
									<?php echo tf_icon_get( 'shopping-cart', 13 ); ?>
									<?php esc_html_e( 'Add', 'themeflex' ); ?>
								</div>
							</div>
						</div>
					</div>

					<!-- Floating: delivery -->
					<div class="tf-ec-float-card tf-ec-float-delivery">
						<div class="tf-ec-float-delivery-icon"><?php echo tf_icon_get( 'truck', 18 ); ?></div>
						<div class="tf-ec-float-delivery-text">
							<strong><?php esc_html_e( 'Fast Delivery', 'themeflex' ); ?></strong>
							<span><?php esc_html_e( 'Arrives tomorrow', 'themeflex' ); ?></span>
						</div>
					</div>

					<!-- Floating: rating -->
					<div class="tf-ec-float-card tf-ec-float-rating">
						<div class="tf-ec-float-rating-score">4.9</div>
						<div class="tf-ec-float-rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
						<div class="tf-ec-float-rating-label"><?php esc_html_e( '50k+ Reviews', 'themeflex' ); ?></div>
					</div>

					<!-- Floating: live stock -->
					<div class="tf-ec-float-card tf-ec-float-badge">
						<div class="tf-ec-float-badge-dot"></div>
						<div class="tf-ec-float-badge-text"><?php esc_html_e( '1,240 sold today', 'themeflex' ); ?></div>
					</div>

				</div><!-- /.tf-ec-hero__visual -->
			</div>
		</div>
	</section>

	<?php
	/* ============================================================
	   2. STATS BAR
	   ============================================================ */
	?>
	<section class="tf-ec-stats" aria-label="<?php esc_attr_e( 'Store highlights', 'themeflex' ); ?>">
		<div class="tf-ec-container">
			<div class="tf-ec-stats__grid">

				<div class="tf-ec-stats__item">
					<div class="tf-ec-stats__icon tf-ec-stats__icon--orange">
						<?php echo tf_icon_get( 'package', 22 ); ?>
					</div>
					<div>
						<div class="tf-ec-stats__value" data-counter="50000" data-suffix="+">0</div>
						<div class="tf-ec-stats__label"><?php esc_html_e( 'Products Available', 'themeflex' ); ?></div>
					</div>
				</div>

				<div class="tf-ec-stats__item">
					<div class="tf-ec-stats__icon tf-ec-stats__icon--green">
						<?php echo tf_icon_get( 'users', 22 ); ?>
					</div>
					<div>
						<div class="tf-ec-stats__value" data-counter="200000" data-suffix="+">0</div>
						<div class="tf-ec-stats__label"><?php esc_html_e( 'Happy Customers', 'themeflex' ); ?></div>
					</div>
				</div>

				<div class="tf-ec-stats__item">
					<div class="tf-ec-stats__icon tf-ec-stats__icon--blue">
						<?php echo tf_icon_get( 'star', 22 ); ?>
					</div>
					<div>
						<div class="tf-ec-stats__value" data-counter="4.9" data-suffix="/5">0</div>
						<div class="tf-ec-stats__label"><?php esc_html_e( 'Average Rating', 'themeflex' ); ?></div>
					</div>
				</div>

				<div class="tf-ec-stats__item">
					<div class="tf-ec-stats__icon tf-ec-stats__icon--yellow">
						<?php echo tf_icon_get( 'award', 22 ); ?>
					</div>
					<div>
						<div class="tf-ec-stats__value" data-counter="99" data-suffix="%">0</div>
						<div class="tf-ec-stats__label"><?php esc_html_e( 'Satisfaction Rate', 'themeflex' ); ?></div>
					</div>
				</div>

			</div>
		</div>
	</section>

	<?php
	/* ============================================================
	   3. FEATURED CATEGORIES
	   ============================================================ */
	?>
	<section class="tf-ec-categories" aria-labelledby="tf-ec-cat-title">
		<div class="tf-ec-container">
			<div class="tf-ec-categories__header">
				<div class="tf-ec-eyebrow">
					<span class="tf-ec-eyebrow-dot"></span>
					<?php esc_html_e( 'Shop by Category', 'themeflex' ); ?>
				</div>
				<h2 id="tf-ec-cat-title" class="tf-ec-section-title">
					<?php esc_html_e( 'Find What You\'re Looking For', 'themeflex' ); ?>
				</h2>
				<p class="tf-ec-section-sub">
					<?php esc_html_e( 'From cutting-edge electronics to everyday essentials — explore our hand-picked categories and discover the best deals.', 'themeflex' ); ?>
				</p>
			</div>

			<div class="tf-ec-categories__grid">

				<a href="<?php echo esc_url( home_url( '/product-category/electronics' ) ); ?>" class="tf-ec-cat-card tf-ec-cat-card--electronics tf-ec-reveal">
					<div class="tf-ec-cat-icon tf-ec-cat-icon--electronics">
						<?php echo tf_icon_get( 'cpu', 26 ); ?>
					</div>
					<h3 class="tf-ec-cat-name"><?php esc_html_e( 'Electronics', 'themeflex' ); ?></h3>
					<p class="tf-ec-cat-count"><?php esc_html_e( '12,400+ products', 'themeflex' ); ?></p>
					<span class="tf-ec-cat-link">
						<?php esc_html_e( 'Shop Now', 'themeflex' ); ?>
						<?php echo tf_icon_get( 'arrow-right', 14 ); ?>
					</span>
				</a>

				<a href="<?php echo esc_url( home_url( '/product-category/fashion' ) ); ?>" class="tf-ec-cat-card tf-ec-cat-card--fashion tf-ec-reveal">
					<div class="tf-ec-cat-icon tf-ec-cat-icon--fashion">
						<?php echo tf_icon_get( 'shirt', 26 ); ?>
					</div>
					<h3 class="tf-ec-cat-name"><?php esc_html_e( 'Fashion', 'themeflex' ); ?></h3>
					<p class="tf-ec-cat-count"><?php esc_html_e( '8,200+ products', 'themeflex' ); ?></p>
					<span class="tf-ec-cat-link">
						<?php esc_html_e( 'Shop Now', 'themeflex' ); ?>
						<?php echo tf_icon_get( 'arrow-right', 14 ); ?>
					</span>
				</a>

				<a href="<?php echo esc_url( home_url( '/product-category/home-garden' ) ); ?>" class="tf-ec-cat-card tf-ec-cat-card--home tf-ec-reveal">
					<div class="tf-ec-cat-icon tf-ec-cat-icon--home">
						<?php echo tf_icon_get( 'home', 26 ); ?>
					</div>
					<h3 class="tf-ec-cat-name"><?php esc_html_e( 'Home & Garden', 'themeflex' ); ?></h3>
					<p class="tf-ec-cat-count"><?php esc_html_e( '5,600+ products', 'themeflex' ); ?></p>
					<span class="tf-ec-cat-link">
						<?php esc_html_e( 'Shop Now', 'themeflex' ); ?>
						<?php echo tf_icon_get( 'arrow-right', 14 ); ?>
					</span>
				</a>

				<a href="<?php echo esc_url( home_url( '/product-category/sport' ) ); ?>" class="tf-ec-cat-card tf-ec-cat-card--sport tf-ec-reveal">
					<div class="tf-ec-cat-icon tf-ec-cat-icon--sport">
						<?php echo tf_icon_get( 'dumbbell', 26 ); ?>
					</div>
					<h3 class="tf-ec-cat-name"><?php esc_html_e( 'Sport & Fitness', 'themeflex' ); ?></h3>
					<p class="tf-ec-cat-count"><?php esc_html_e( '3,900+ products', 'themeflex' ); ?></p>
					<span class="tf-ec-cat-link">
						<?php esc_html_e( 'Shop Now', 'themeflex' ); ?>
						<?php echo tf_icon_get( 'arrow-right', 14 ); ?>
					</span>
				</a>

			</div>
		</div>
	</section>

	<?php
	/* ============================================================
	   4. PRODUCT SHOWCASE
	   ============================================================ */
	?>
	<section class="tf-ec-products" aria-labelledby="tf-ec-prod-title">
		<div class="tf-ec-container">
			<div class="tf-ec-products__header">
				<div>
					<div class="tf-ec-eyebrow">
						<span class="tf-ec-eyebrow-dot"></span>
						<?php esc_html_e( 'Featured Products', 'themeflex' ); ?>
					</div>
					<h2 id="tf-ec-prod-title" class="tf-ec-section-title" style="margin-bottom:0;">
						<?php esc_html_e( 'Today\'s Best Picks', 'themeflex' ); ?>
					</h2>
				</div>
				<div class="tf-ec-products__tabs" role="tablist" aria-label="<?php esc_attr_e( 'Filter products', 'themeflex' ); ?>">
					<button class="tf-ec-products__tab active" role="tab" aria-selected="true"><?php esc_html_e( 'All', 'themeflex' ); ?></button>
					<button class="tf-ec-products__tab" role="tab" aria-selected="false"><?php esc_html_e( 'New Arrivals', 'themeflex' ); ?></button>
					<button class="tf-ec-products__tab" role="tab" aria-selected="false"><?php esc_html_e( 'Best Sellers', 'themeflex' ); ?></button>
					<button class="tf-ec-products__tab" role="tab" aria-selected="false"><?php esc_html_e( 'On Sale', 'themeflex' ); ?></button>
				</div>
			</div>

			<div class="tf-ec-products__grid">

				<?php
				$tf_ec_products = array(
					array(
						'img_class' => 'tf-ec-prod-img--violet',
						'icon'      => 'headphones',
						'badge'     => 'sale',
						'badge_txt' => esc_html__( '-35%', 'themeflex' ),
						'cat'       => esc_html__( 'Electronics', 'themeflex' ),
						'name'      => esc_html__( 'Pro Wireless ANC Headphones', 'themeflex' ),
						'stars'     => 5,
						'review_ct' => '2,847',
						'price'     => '$129',
						'old_price' => '$199',
						'sale'      => true,
					),
					array(
						'img_class' => 'tf-ec-prod-img--rose',
						'icon'      => 'watch',
						'badge'     => 'new',
						'badge_txt' => esc_html__( 'New', 'themeflex' ),
						'cat'       => esc_html__( 'Accessories', 'themeflex' ),
						'name'      => esc_html__( 'Smart Fitness Watch Series 5', 'themeflex' ),
						'stars'     => 5,
						'review_ct' => '1,204',
						'price'     => '$249',
						'old_price' => '',
						'sale'      => false,
					),
					array(
						'img_class' => 'tf-ec-prod-img--green',
						'icon'      => 'camera',
						'badge'     => '',
						'badge_txt' => '',
						'cat'       => esc_html__( 'Electronics', 'themeflex' ),
						'name'      => esc_html__( 'Mirrorless Camera 4K UHD', 'themeflex' ),
						'stars'     => 4,
						'review_ct' => '986',
						'price'     => '$899',
						'old_price' => '',
						'sale'      => false,
					),
					array(
						'img_class' => 'tf-ec-prod-img--amber',
						'icon'      => 'lamp-desk',
						'badge'     => 'hot',
						'badge_txt' => esc_html__( 'Hot', 'themeflex' ),
						'cat'       => esc_html__( 'Home & Office', 'themeflex' ),
						'name'      => esc_html__( 'Minimalist LED Desk Lamp', 'themeflex' ),
						'stars'     => 5,
						'review_ct' => '3,512',
						'price'     => '$69',
						'old_price' => '$89',
						'sale'      => true,
					),
					array(
						'img_class' => 'tf-ec-prod-img--orange',
						'icon'      => 'backpack',
						'badge'     => 'sale',
						'badge_txt' => esc_html__( '-20%', 'themeflex' ),
						'cat'       => esc_html__( 'Fashion', 'themeflex' ),
						'name'      => esc_html__( 'Urban Commuter Backpack 30L', 'themeflex' ),
						'stars'     => 5,
						'review_ct' => '4,091',
						'price'     => '$79',
						'old_price' => '$99',
						'sale'      => true,
					),
					array(
						'img_class' => 'tf-ec-prod-img--cyan',
						'icon'      => 'bluetooth',
						'badge'     => 'new',
						'badge_txt' => esc_html__( 'New', 'themeflex' ),
						'cat'       => esc_html__( 'Audio', 'themeflex' ),
						'name'      => esc_html__( 'Compact True Wireless Earbuds', 'themeflex' ),
						'stars'     => 4,
						'review_ct' => '1,763',
						'price'     => '$89',
						'old_price' => '',
						'sale'      => false,
					),
				);
				?>

				<?php foreach ( $tf_ec_products as $tf_ec_product ) : ?>
				<article class="tf-ec-prod-card tf-ec-reveal">
					<div class="tf-ec-prod-img <?php echo esc_attr( $tf_ec_product['img_class'] ); ?>">
						<div class="tf-ec-prod-img__icon">
							<?php echo tf_icon_get( esc_attr( $tf_ec_product['icon'] ), 28 ); ?>
						</div>
						<?php if ( $tf_ec_product['badge'] ) : ?>
						<span class="tf-ec-prod-badge tf-ec-prod-badge--<?php echo esc_attr( $tf_ec_product['badge'] ); ?>">
							<?php echo $tf_ec_product['badge_txt']; ?>
						</span>
						<?php endif; ?>
					</div>
					<div class="tf-ec-prod-info">
						<div class="tf-ec-prod-category"><?php echo $tf_ec_product['cat']; ?></div>
						<h3 class="tf-ec-prod-name"><?php echo $tf_ec_product['name']; ?></h3>
						<div class="tf-ec-prod-stars">
							<span class="tf-ec-prod-stars__icons">
								<?php for ( $i = 1; $i <= 5; $i++ ) : ?>
									<?php if ( $i <= $tf_ec_product['stars'] ) : ?>
										<?php echo tf_icon_get( 'star', 13, 'tf-icon--star-filled' ); ?>
									<?php else : ?>
										<?php echo tf_icon_get( 'star', 13 ); ?>
									<?php endif; ?>
								<?php endfor; ?>
							</span>
							<span class="tf-ec-prod-stars__count">(<?php echo esc_html( $tf_ec_product['review_ct'] ); ?>)</span>
						</div>
						<div class="tf-ec-prod-price-row">
							<div>
								<span class="tf-ec-prod-price <?php echo $tf_ec_product['sale'] ? 'tf-ec-prod-price--sale' : ''; ?>">
									<?php echo esc_html( $tf_ec_product['price'] ); ?>
								</span>
								<?php if ( $tf_ec_product['old_price'] ) : ?>
									<span class="tf-ec-prod-price-old"><?php echo esc_html( $tf_ec_product['old_price'] ); ?></span>
								<?php endif; ?>
							</div>
							<a href="<?php echo esc_url( home_url( '/shop' ) ); ?>" class="tf-ec-prod-cart-btn" aria-label="<?php echo esc_attr( sprintf( __( 'Add %s to cart', 'themeflex' ), $tf_ec_product['name'] ) ); ?>">
								<?php echo tf_icon_get( 'shopping-cart', 15 ); ?>
								<?php esc_html_e( 'Add', 'themeflex' ); ?>
							</a>
						</div>
					</div>
				</article>
				<?php endforeach; ?>

			</div><!-- /.tf-ec-products__grid -->

			<div style="text-align:center;margin-top:3rem;">
				<a href="<?php echo esc_url( home_url( '/shop' ) ); ?>" class="tf-ec-btn-ghost">
					<?php esc_html_e( 'View All Products', 'themeflex' ); ?>
					<?php echo tf_icon_get( 'arrow-right', 18 ); ?>
				</a>
			</div>
		</div>
	</section>

	<?php
	/* ============================================================
	   5. PROMO BANNER
	   ============================================================ */
	?>
	<section class="tf-ec-promo" aria-label="<?php esc_attr_e( 'Promotional sale', 'themeflex' ); ?>">
		<div class="tf-ec-container">
			<div class="tf-ec-promo__inner">
				<div class="tf-ec-promo__orb-1" aria-hidden="true"></div>
				<div class="tf-ec-promo__orb-2" aria-hidden="true"></div>

				<div class="tf-ec-promo__content">
					<div class="tf-ec-promo__tag">
						<?php echo tf_icon_get( 'tag', 13 ); ?>
						<?php esc_html_e( 'Flash Sale', 'themeflex' ); ?>
					</div>
					<h2 class="tf-ec-promo__title">
						<?php esc_html_e( 'Summer Mega Sale is Live', 'themeflex' ); ?><br>
						<?php esc_html_e( 'Don\'t Miss Out', 'themeflex' ); ?>
					</h2>
					<p class="tf-ec-promo__desc">
						<?php esc_html_e( 'Exclusive deals on thousands of top products. Limited time only — grab yours before they\'re gone. No coupon code needed.', 'themeflex' ); ?>
					</p>
					<a href="<?php echo esc_url( home_url( '/sale' ) ); ?>" class="tf-ec-promo__cta">
						<?php echo tf_icon_get( 'shopping-bag', 18 ); ?>
						<?php esc_html_e( 'Shop the Sale', 'themeflex' ); ?>
					</a>
				</div>

				<div class="tf-ec-promo__countdown" aria-live="polite" aria-label="<?php esc_attr_e( 'Sale countdown timer', 'themeflex' ); ?>">
					<div class="tf-ec-promo__discount">60%</div>
					<div class="tf-ec-promo__discount-label"><?php esc_html_e( 'OFF selected items', 'themeflex' ); ?></div>
					<div style="margin-top:1.5rem;">
						<p class="tf-ec-countdown-label"><?php esc_html_e( 'Ends in', 'themeflex' ); ?></p>
						<div class="tf-ec-countdown-grid">
							<div class="tf-ec-countdown-cell">
								<div class="tf-ec-countdown-num" id="tf-ec-cd-days">02</div>
								<div class="tf-ec-countdown-unit"><?php esc_html_e( 'Days', 'themeflex' ); ?></div>
							</div>
							<div class="tf-ec-countdown-sep" aria-hidden="true">:</div>
							<div class="tf-ec-countdown-cell">
								<div class="tf-ec-countdown-num" id="tf-ec-cd-hours">14</div>
								<div class="tf-ec-countdown-unit"><?php esc_html_e( 'Hours', 'themeflex' ); ?></div>
							</div>
							<div class="tf-ec-countdown-sep" aria-hidden="true">:</div>
							<div class="tf-ec-countdown-cell">
								<div class="tf-ec-countdown-num" id="tf-ec-cd-mins">38</div>
								<div class="tf-ec-countdown-unit"><?php esc_html_e( 'Mins', 'themeflex' ); ?></div>
							</div>
							<div class="tf-ec-countdown-sep" aria-hidden="true">:</div>
							<div class="tf-ec-countdown-cell">
								<div class="tf-ec-countdown-num" id="tf-ec-cd-secs">00</div>
								<div class="tf-ec-countdown-unit"><?php esc_html_e( 'Secs', 'themeflex' ); ?></div>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</section>

	<?php
	/* ============================================================
	   6. BENEFITS BAR
	   ============================================================ */
	?>
	<section class="tf-ec-benefits" aria-label="<?php esc_attr_e( 'Shopping benefits', 'themeflex' ); ?>">
		<div class="tf-ec-container">
			<div class="tf-ec-benefits__grid">

				<div class="tf-ec-benefit">
					<div class="tf-ec-benefit__icon tf-ec-benefit__icon--orange">
						<?php echo tf_icon_get( 'truck', 24 ); ?>
					</div>
					<div>
						<p class="tf-ec-benefit__title"><?php esc_html_e( 'Free Shipping', 'themeflex' ); ?></p>
						<p class="tf-ec-benefit__desc"><?php esc_html_e( 'On all orders over $49. Delivered to your door in 2–5 business days.', 'themeflex' ); ?></p>
					</div>
				</div>

				<div class="tf-ec-benefit">
					<div class="tf-ec-benefit__icon tf-ec-benefit__icon--green">
						<?php echo tf_icon_get( 'shield-check', 24 ); ?>
					</div>
					<div>
						<p class="tf-ec-benefit__title"><?php esc_html_e( 'Secure Payment', 'themeflex' ); ?></p>
						<p class="tf-ec-benefit__desc"><?php esc_html_e( 'SSL-encrypted checkout. We accept Visa, Mastercard, PayPal & more.', 'themeflex' ); ?></p>
					</div>
				</div>

				<div class="tf-ec-benefit">
					<div class="tf-ec-benefit__icon tf-ec-benefit__icon--blue">
						<?php echo tf_icon_get( 'refresh-ccw', 24 ); ?>
					</div>
					<div>
						<p class="tf-ec-benefit__title"><?php esc_html_e( 'Easy Returns', 'themeflex' ); ?></p>
						<p class="tf-ec-benefit__desc"><?php esc_html_e( 'Not happy? Return any product within 30 days, no questions asked.', 'themeflex' ); ?></p>
					</div>
				</div>

				<div class="tf-ec-benefit">
					<div class="tf-ec-benefit__icon tf-ec-benefit__icon--yellow">
						<?php echo tf_icon_get( 'headset', 24 ); ?>
					</div>
					<div>
						<p class="tf-ec-benefit__title"><?php esc_html_e( '24/7 Support', 'themeflex' ); ?></p>
						<p class="tf-ec-benefit__desc"><?php esc_html_e( 'Our customer service team is here around the clock to help you.', 'themeflex' ); ?></p>
					</div>
				</div>

			</div>
		</div>
	</section>

	<?php
	/* ============================================================
	   7. TESTIMONIALS
	   ============================================================ */
	?>
	<section class="tf-ec-testimonials" aria-labelledby="tf-ec-reviews-title">
		<div class="tf-ec-container">
			<div class="tf-ec-testimonials__header">
				<div class="tf-ec-eyebrow">
					<span class="tf-ec-eyebrow-dot"></span>
					<?php esc_html_e( 'Customer Reviews', 'themeflex' ); ?>
				</div>
				<h2 id="tf-ec-reviews-title" class="tf-ec-section-title">
					<?php esc_html_e( 'Real Shoppers. Real Stories.', 'themeflex' ); ?>
				</h2>
				<p class="tf-ec-section-sub">
					<?php esc_html_e( 'Over 200,000 customers trust us for quality products and outstanding service. Here\'s what some of them have to say.', 'themeflex' ); ?>
				</p>
			</div>

			<div class="tf-ec-testimonials__grid">

				<article class="tf-ec-review-card tf-ec-reveal">
					<div class="tf-ec-review-stars" aria-label="<?php esc_attr_e( '5 out of 5 stars', 'themeflex' ); ?>">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
					<p class="tf-ec-review-text"><?php esc_html_e( 'Ordered the ANC headphones and they arrived the next day. Sound quality is absolutely incredible — way beyond what I expected for the price. The packaging was premium too.', 'themeflex' ); ?></p>
					<div class="tf-ec-review-author">
						<div class="tf-ec-review-avatar tf-ec-review-avatar--1" aria-hidden="true">SL</div>
						<div>
							<div class="tf-ec-review-name"><?php esc_html_e( 'Sarah L.', 'themeflex' ); ?></div>
							<div class="tf-ec-review-meta"><?php esc_html_e( 'Verified Buyer · Electronics', 'themeflex' ); ?></div>
						</div>
						<div class="tf-ec-review-verified">
							<?php echo tf_icon_get( 'badge-check', 14 ); ?>
							<?php esc_html_e( 'Verified', 'themeflex' ); ?>
						</div>
					</div>
				</article>

				<article class="tf-ec-review-card tf-ec-reveal">
					<div class="tf-ec-review-stars" aria-label="<?php esc_attr_e( '5 out of 5 stars', 'themeflex' ); ?>">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
					<p class="tf-ec-review-text"><?php esc_html_e( 'The backpack is solid. I use it every day for my commute. The build quality is outstanding — all zippers and stitching feel premium. Returns process was also super smooth when I exchanged sizes.', 'themeflex' ); ?></p>
					<div class="tf-ec-review-author">
						<div class="tf-ec-review-avatar tf-ec-review-avatar--2" aria-hidden="true">MK</div>
						<div>
							<div class="tf-ec-review-name"><?php esc_html_e( 'Marcus K.', 'themeflex' ); ?></div>
							<div class="tf-ec-review-meta"><?php esc_html_e( 'Verified Buyer · Fashion', 'themeflex' ); ?></div>
						</div>
						<div class="tf-ec-review-verified">
							<?php echo tf_icon_get( 'badge-check', 14 ); ?>
							<?php esc_html_e( 'Verified', 'themeflex' ); ?>
						</div>
					</div>
				</article>

				<article class="tf-ec-review-card tf-ec-reveal">
					<div class="tf-ec-review-stars" aria-label="<?php esc_attr_e( '5 out of 5 stars', 'themeflex' ); ?>">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
					<p class="tf-ec-review-text"><?php esc_html_e( 'Fast checkout, quick delivery, and the desk lamp is exactly as described. I\'ve already recommended this store to my entire team. Customer support replied within an hour when I had a question.', 'themeflex' ); ?></p>
					<div class="tf-ec-review-author">
						<div class="tf-ec-review-avatar tf-ec-review-avatar--3" aria-hidden="true">AJ</div>
						<div>
							<div class="tf-ec-review-name"><?php esc_html_e( 'Anna J.', 'themeflex' ); ?></div>
							<div class="tf-ec-review-meta"><?php esc_html_e( 'Verified Buyer · Home & Office', 'themeflex' ); ?></div>
						</div>
						<div class="tf-ec-review-verified">
							<?php echo tf_icon_get( 'badge-check', 14 ); ?>
							<?php esc_html_e( 'Verified', 'themeflex' ); ?>
						</div>
					</div>
				</article>

			</div>
		</div>
	</section>

	<?php
	/* ============================================================
	   8. NEWSLETTER CTA
	   ============================================================ */
	?>
	<section class="tf-ec-newsletter" aria-labelledby="tf-ec-newsletter-title">
		<div class="tf-ec-container">
			<div class="tf-ec-newsletter__inner">
				<div class="tf-ec-newsletter__icon" aria-hidden="true">
					<?php echo tf_icon_get( 'mail', 28 ); ?>
				</div>
				<h2 id="tf-ec-newsletter-title" class="tf-ec-newsletter__title">
					<?php esc_html_e( 'Get Exclusive Deals First', 'themeflex' ); ?>
				</h2>
				<p class="tf-ec-newsletter__desc">
					<?php esc_html_e( 'Join 85,000+ savvy shoppers who get early access to sales, new arrivals, and member-only discounts delivered straight to their inbox.', 'themeflex' ); ?>
				</p>
				<?php
				// Use WooCommerce or CF7 form if available, fallback to native HTML
				?>
				<form class="tf-ec-newsletter__form" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get" aria-label="<?php esc_attr_e( 'Newsletter signup form', 'themeflex' ); ?>">
					<input
						type="email"
						class="tf-ec-newsletter__input"
						name="email"
						placeholder="<?php esc_attr_e( 'Enter your email address...', 'themeflex' ); ?>"
						required
						aria-label="<?php esc_attr_e( 'Your email address', 'themeflex' ); ?>"
					>
					<button type="submit" class="tf-ec-newsletter__submit">
						<?php echo tf_icon_get( 'send', 18 ); ?>
						<?php esc_html_e( 'Subscribe', 'themeflex' ); ?>
					</button>
				</form>
				<p class="tf-ec-newsletter__small">
					<?php echo tf_icon_get( 'shield', 14 ); ?>
					<?php esc_html_e( 'No spam, ever. Unsubscribe anytime.', 'themeflex' ); ?>
				</p>
			</div>
		</div>
	</section>

</main>

<script>
(function() {
	'use strict';

	/* ---- Scroll reveal ---- */
	if ('IntersectionObserver' in window) {
		var reveals = document.querySelectorAll('.tf-ec-reveal');
		var observer = new IntersectionObserver(function(entries) {
			entries.forEach(function(entry, idx) {
				if (entry.isIntersecting) {
					entry.target.style.transitionDelay = (idx % 4) * 80 + 'ms';
					entry.target.classList.add('is-visible');
					observer.unobserve(entry.target);
				}
			});
		}, { threshold: 0.12 });
		reveals.forEach(function(el) { observer.observe(el); });
	} else {
		document.querySelectorAll('.tf-ec-reveal').forEach(function(el) {
			el.classList.add('is-visible');
		});
	}

	/* ---- Counter animation ---- */
	function animateCounter(el) {
		var target = parseFloat(el.getAttribute('data-counter'));
		var suffix = el.getAttribute('data-suffix') || '';
		var duration = 1800;
		var start = null;
		var isDecimal = target % 1 !== 0;

		function step(ts) {
			if (!start) start = ts;
			var progress = Math.min((ts - start) / duration, 1);
			var eased = 1 - Math.pow(1 - progress, 3);
			var val = eased * target;
			var display;
			if (isDecimal) {
				display = val.toFixed(1);
			} else if (target >= 1000) {
				display = Math.floor(val).toLocaleString();
			} else {
				display = Math.floor(val).toString();
			}
			el.textContent = display + suffix;
			if (progress < 1) requestAnimationFrame(step);
		}
		requestAnimationFrame(step);
	}

	if ('IntersectionObserver' in window) {
		var counters = document.querySelectorAll('[data-counter]');
		var counterObs = new IntersectionObserver(function(entries) {
			entries.forEach(function(entry) {
				if (entry.isIntersecting) {
					animateCounter(entry.target);
					counterObs.unobserve(entry.target);
				}
			});
		}, { threshold: 0.5 });
		counters.forEach(function(el) { counterObs.observe(el); });
	}

	/* ---- Product tabs (UI only) ---- */
	var tabs = document.querySelectorAll('.tf-ec-products__tab');
	tabs.forEach(function(tab) {
		tab.addEventListener('click', function() {
			tabs.forEach(function(t) {
				t.classList.remove('active');
				t.setAttribute('aria-selected', 'false');
			});
			this.classList.add('active');
			this.setAttribute('aria-selected', 'true');
		});
	});

	/* ---- Sale countdown timer ---- */
	var endDate = new Date();
	endDate.setDate(endDate.getDate() + 2);
	endDate.setHours(endDate.getHours() + 14);
	endDate.setMinutes(endDate.getMinutes() + 38);

	function padTwo(n) {
		return n < 10 ? '0' + n : '' + n;
	}

	var cdDays  = document.getElementById('tf-ec-cd-days');
	var cdHours = document.getElementById('tf-ec-cd-hours');
	var cdMins  = document.getElementById('tf-ec-cd-mins');
	var cdSecs  = document.getElementById('tf-ec-cd-secs');

	if (cdDays && cdHours && cdMins && cdSecs) {
		function updateCountdown() {
			var now   = new Date().getTime();
			var diff  = endDate.getTime() - now;
			if (diff <= 0) {
				cdDays.textContent = cdHours.textContent = cdMins.textContent = cdSecs.textContent = '00';
				return;
			}
			var days  = Math.floor(diff / (1000 * 60 * 60 * 24));
			var hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
			var mins  = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
			var secs  = Math.floor((diff % (1000 * 60)) / 1000);
			cdDays.textContent  = padTwo(days);
			cdHours.textContent = padTwo(hours);
			cdMins.textContent  = padTwo(mins);
			cdSecs.textContent  = padTwo(secs);
		}
		updateCountdown();
		setInterval(updateCountdown, 1000);
	}

})();
</script>

<?php get_footer(); ?>
