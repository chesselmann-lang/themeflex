<?php
/**
 * Template Name: Portfolio Archive
 * Template Post Type: page
 *
 * Full portfolio listing with category filter tabs, masonry-style grid,
 * lazy-load animations, and a CTA footer row.
 * Standalone dark-first — no Elementor dependency.
 *
 * @package ThemeFlex
 * @since 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
get_header(); ?>

<main id="primary" class="tf-portfolio-main">
<style>
/* ── Portfolio Archive — Dark-first ───────────────────────── */
.tf-portfolio-main {
  --tc:  #ff5e2e;
  --tc2: #00d4ff;
  --bg:  #06021d;
  --bg2: #0d1526;
  --bg3: #111827;
  --border: rgba(255,255,255,.07);
  --title: #f1f5f9;
  --txt:   #94a3b8;
  --meta:  #64748b;
  background: var(--bg);
  min-height: 100vh;
  padding-bottom: 120px;
}

/* ── Page Hero ─────────────────────────────────────────────── */
.tf-pf-hero {
  position: relative;
  text-align: center;
  padding: 120px 24px 80px;
  background: radial-gradient(ellipse 70% 50% at 50% 0%, rgba(255,94,46,.16) 0%, transparent 70%),
              var(--bg);
  overflow: hidden;
}
.tf-pf-hero::before {
  content: '';
  position: absolute;
  inset: 0;
  background-image: radial-gradient(rgba(255,255,255,.035) 1px, transparent 1px);
  background-size: 36px 36px;
}
.tf-pf-hero-inner { position: relative; z-index: 1; max-width: 720px; margin: 0 auto; }
.tf-pf-eyebrow {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.25);
  color: var(--tc); font-size: .72rem; font-weight: 700; letter-spacing: .1em;
  text-transform: uppercase; padding: 6px 16px; border-radius: 100px; margin-bottom: 24px;
}
.tf-pf-hero h1 {
  font-size: clamp(2.4rem, 5vw, 4rem);
  font-weight: 900; color: var(--title); margin: 0 0 18px; line-height: 1.1;
}
.tf-pf-hero p {
  font-size: 1.1rem; color: var(--txt); max-width: 560px; margin: 0 auto; line-height: 1.7;
}

/* ── Category filter tabs ──────────────────────────────────── */
.tf-pf-filter {
  display: flex; flex-wrap: wrap; justify-content: center; gap: 10px;
  padding: 0 24px 60px;
}
.tf-pf-tab {
  padding: 8px 20px; border-radius: 100px; border: 1px solid var(--border);
  background: transparent; color: var(--txt); font-size: .83rem; font-weight: 600;
  cursor: pointer; transition: all .22s;
}
.tf-pf-tab:hover, .tf-pf-tab.active {
  background: var(--tc); border-color: var(--tc); color: #fff;
}

/* ── Grid ──────────────────────────────────────────────────── */
.tf-pf-wrap { max-width: 1240px; margin: 0 auto; padding: 0 24px; }
.tf-pf-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 28px;
}

/* ── Card ──────────────────────────────────────────────────── */
.tf-pf-card {
  position: relative;
  border-radius: 18px; overflow: hidden;
  background: var(--bg3);
  border: 1px solid var(--border);
  transition: transform .3s, box-shadow .3s;
  text-decoration: none;
  display: block;
  opacity: 0; transform: translateY(20px);
  animation: tfPfFadeIn .5s ease forwards;
}
.tf-pf-card:hover {
  transform: translateY(-8px);
  box-shadow: 0 28px 56px rgba(0,0,0,.45);
}
@keyframes tfPfFadeIn {
  to { opacity: 1; transform: translateY(0); }
}
/* stagger */
.tf-pf-card:nth-child(1){animation-delay:.05s}
.tf-pf-card:nth-child(2){animation-delay:.10s}
.tf-pf-card:nth-child(3){animation-delay:.15s}
.tf-pf-card:nth-child(4){animation-delay:.20s}
.tf-pf-card:nth-child(5){animation-delay:.25s}
.tf-pf-card:nth-child(6){animation-delay:.30s}
.tf-pf-card:nth-child(7){animation-delay:.35s}
.tf-pf-card:nth-child(8){animation-delay:.40s}
.tf-pf-card:nth-child(9){animation-delay:.45s}

/* ── Thumb ────────────────────────────────────────────────── */
.tf-pf-thumb {
  aspect-ratio: 16/10;
  position: relative; overflow: hidden;
  background: linear-gradient(135deg, #1e293b, #0f172a);
  display: flex; align-items: center; justify-content: center;
}
.tf-pf-thumb img {
  width: 100%; height: 100%; object-fit: cover;
  position: absolute; inset: 0;
  transition: transform .5s ease;
}
.tf-pf-card:hover .tf-pf-thumb img { transform: scale(1.06); }
.tf-pf-thumb-no-img { position:absolute; inset:0; display:flex; align-items:center; justify-content:center; }
.tf-pf-thumb-icon { width:56px; height:56px; display:flex; align-items:center; justify-content:center; }
.tf-pf-thumb-icon svg { width:38px; height:38px; }

/* Overlay on hover */
.tf-pf-overlay {
  position: absolute; inset: 0;
  background: linear-gradient(to top, rgba(6,2,29,.9) 0%, rgba(6,2,29,.2) 60%, transparent 100%);
  opacity: 0; transition: opacity .3s;
  display: flex; align-items: flex-end; justify-content: center; padding-bottom: 24px;
}
.tf-pf-card:hover .tf-pf-overlay { opacity: 1; }
.tf-pf-view {
  background: var(--tc); color: #fff; font-size: .8rem; font-weight: 700;
  letter-spacing: .06em; text-transform: uppercase; padding: 10px 22px;
  border-radius: 100px; white-space: nowrap;
  transform: translateY(8px); opacity: 0; transition: opacity .3s, transform .3s;
}
.tf-pf-card:hover .tf-pf-view { opacity: 1; transform: translateY(0); }

/* ── Card body ───────────────────────────────────────────── */
.tf-pf-body { padding: 22px 26px 26px; }
.tf-pf-cat {
  font-size: .68rem; font-weight: 700; letter-spacing: .1em;
  text-transform: uppercase; color: var(--tc); margin-bottom: 8px;
}
.tf-pf-title {
  font-size: 1.05rem; font-weight: 700; color: var(--title);
  margin: 0 0 10px; line-height: 1.3;
}
.tf-pf-excerpt { font-size: .875rem; color: var(--meta); line-height: 1.55; margin: 0; }

/* Tags row */
.tf-pf-tags { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 14px; }
.tf-pf-tag {
  padding: 3px 10px; border-radius: 20px; font-size: .68rem; font-weight: 600;
  background: rgba(255,255,255,.05); border: 1px solid var(--border); color: var(--meta);
}

/* ── Load More ───────────────────────────────────────────── */
.tf-pf-loadmore {
  text-align: center; margin-top: 60px;
}
.tf-pf-loadmore-btn {
  display: inline-flex; align-items: center; gap: 10px;
  background: transparent; border: 2px solid var(--tc); color: var(--tc);
  font-size: .9rem; font-weight: 700; padding: 14px 36px; border-radius: 100px;
  cursor: pointer; transition: background .25s, color .25s;
}
.tf-pf-loadmore-btn:hover { background: var(--tc); color: #fff; }

/* ── Empty state ─────────────────────────────────────────── */
.tf-pf-empty {
  text-align: center; padding: 80px 24px;
  color: var(--meta);
}
.tf-pf-empty h2 { font-size: 1.4rem; color: var(--title); margin-bottom: 12px; }

/* ── CTA banner ──────────────────────────────────────────── */
.tf-pf-cta {
  margin: 100px 24px 0;
  background: linear-gradient(135deg, rgba(255,94,46,.12) 0%, rgba(0,212,255,.06) 100%);
  border: 1px solid rgba(255,94,46,.2);
  border-radius: 24px; text-align: center;
  padding: 72px 40px; max-width: 840px; margin-inline: auto;
}
.tf-pf-cta h2 { font-size: clamp(1.6rem, 3vw, 2.4rem); font-weight: 800; color: var(--title); margin: 0 0 14px; }
.tf-pf-cta p  { font-size: 1.05rem; color: var(--txt); margin: 0 0 36px; }
.tf-pf-cta-btn {
  display: inline-flex; align-items: center; gap: 10px;
  background: var(--tc); color: #fff; font-size: .95rem; font-weight: 700;
  padding: 16px 40px; border-radius: 100px; text-decoration: none;
  transition: background .2s, transform .2s;
}
.tf-pf-cta-btn:hover { background: #e04e22; transform: translateY(-2px); }

/* ── Responsive ──────────────────────────────────────────── */
@media(max-width:1024px) { .tf-pf-grid { grid-template-columns: repeat(2,1fr); } }
@media(max-width:640px)  { .tf-pf-grid { grid-template-columns: 1fr; } }
</style>

<!-- ── Page Hero ──────────────────────────────────────────── -->
<div class="tf-pf-hero">
  <div class="tf-pf-hero-inner">
    <div class="tf-pf-eyebrow">◆ <?php esc_html_e( 'Our Work', 'themeflex' ); ?></div>
    <h1><?php esc_html_e( 'Crafted With Purpose', 'themeflex' ); ?></h1>
    <p><?php esc_html_e( 'Explore our portfolio — bold digital identities, high-performance WordPress builds, and enterprise-grade web applications.', 'themeflex' ); ?></p>
  </div>
</div>

<?php
/* ── Collect all sf_portfolio_cat terms for filter tabs ──── */
$all_cats = get_terms( array(
  'taxonomy'   => 'sf_portfolio_cat',
  'hide_empty' => true,
) );

if ( ! is_wp_error( $all_cats ) && ! empty( $all_cats ) ) : ?>
<div class="tf-pf-filter">
  <button class="tf-pf-tab active" data-filter="all"><?php esc_html_e( 'All', 'themeflex' ); ?></button>
  <?php foreach ( $all_cats as $cat ) : ?>
    <button class="tf-pf-tab" data-filter="<?php echo esc_attr( $cat->slug ); ?>">
      <?php echo esc_html( $cat->name ); ?>
    </button>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- ── Grid ───────────────────────────────────────────────── -->
<div class="tf-pf-wrap">
<?php
/* ── Query ───────────────────────────────────────────────── */
$pf_query = new WP_Query( array(
  'post_type'      => 'sf_portfolio',
  'posts_per_page' => 12,
  'post_status'    => 'publish',
  'orderby'        => 'menu_order date',
  'order'          => 'ASC',
) );

/* ── SVG icon map keyed by category slug ──────────────────── */
$_pf_svgs = array(
  'monitor'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>',
  'cart'     => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>',
  'palette'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="13.5" cy="6.5" r=".5"/><circle cx="17.5" cy="10.5" r=".5"/><circle cx="8.5" cy="7.5" r=".5"/><circle cx="6.5" cy="12.5" r=".5"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/></svg>',
  'phone'    => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>',
  'barchart' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
  'rocket'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/></svg>',
  'coffee'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M17 8h1a4 4 0 1 1 0 8h-1"/><path d="M3 8h14v9a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4Z"/><line x1="6" y1="2" x2="6" y2="4"/><line x1="10" y1="2" x2="10" y2="4"/><line x1="14" y1="2" x2="14" y2="4"/></svg>',
  'camera'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>',
  'home'     => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
  'dollar'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>',
  'layers'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>',
  'star'     => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
  'folder'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>',
);
$_pf_default_svg = $_pf_svgs['star'];

$emoji_map = array(
  'web-design'  => array('s'=>$_pf_svgs['monitor'],'c'=>'rgba(99,102,241,.7)','g'=>'linear-gradient(135deg,rgba(99,102,241,.18),rgba(99,102,241,.04))'),
  'web design'  => array('s'=>$_pf_svgs['monitor'],'c'=>'rgba(99,102,241,.7)','g'=>'linear-gradient(135deg,rgba(99,102,241,.18),rgba(99,102,241,.04))'),
  'e-commerce'  => array('s'=>$_pf_svgs['cart'],   'c'=>'rgba(234,179,8,.75)','g'=>'linear-gradient(135deg,rgba(234,179,8,.18),rgba(234,179,8,.04))'),
  'ecommerce'   => array('s'=>$_pf_svgs['cart'],   'c'=>'rgba(234,179,8,.75)','g'=>'linear-gradient(135deg,rgba(234,179,8,.18),rgba(234,179,8,.04))'),
  'woocommerce' => array('s'=>$_pf_svgs['cart'],   'c'=>'rgba(234,179,8,.75)','g'=>'linear-gradient(135deg,rgba(234,179,8,.18),rgba(234,179,8,.04))'),
  'branding'    => array('s'=>$_pf_svgs['palette'],'c'=>'rgba(249,115,22,.75)','g'=>'linear-gradient(135deg,rgba(249,115,22,.18),rgba(249,115,22,.04))'),
  'brand'       => array('s'=>$_pf_svgs['palette'],'c'=>'rgba(249,115,22,.75)','g'=>'linear-gradient(135deg,rgba(249,115,22,.18),rgba(249,115,22,.04))'),
  'mobile-app'  => array('s'=>$_pf_svgs['phone'],  'c'=>'rgba(34,211,238,.75)','g'=>'linear-gradient(135deg,rgba(34,211,238,.18),rgba(34,211,238,.04))'),
  'mobile app'  => array('s'=>$_pf_svgs['phone'],  'c'=>'rgba(34,211,238,.75)','g'=>'linear-gradient(135deg,rgba(34,211,238,.18),rgba(34,211,238,.04))'),
  'saas'        => array('s'=>$_pf_svgs['barchart'],'c'=>'rgba(16,185,129,.75)','g'=>'linear-gradient(135deg,rgba(16,185,129,.18),rgba(16,185,129,.04))'),
  'dashboard'   => array('s'=>$_pf_svgs['barchart'],'c'=>'rgba(16,185,129,.75)','g'=>'linear-gradient(135deg,rgba(16,185,129,.18),rgba(16,185,129,.04))'),
  'analytics'   => array('s'=>$_pf_svgs['barchart'],'c'=>'rgba(16,185,129,.75)','g'=>'linear-gradient(135deg,rgba(16,185,129,.18),rgba(16,185,129,.04))'),
  'landing-page'=> array('s'=>$_pf_svgs['rocket'], 'c'=>'rgba(255,94,46,.75)','g'=>'linear-gradient(135deg,rgba(255,94,46,.18),rgba(255,94,46,.04))'),
  'landing page'=> array('s'=>$_pf_svgs['rocket'], 'c'=>'rgba(255,94,46,.75)','g'=>'linear-gradient(135deg,rgba(255,94,46,.18),rgba(255,94,46,.04))'),
  'restaurant'  => array('s'=>$_pf_svgs['coffee'], 'c'=>'rgba(217,119,6,.75)','g'=>'linear-gradient(135deg,rgba(217,119,6,.18),rgba(217,119,6,.04))'),
  'hospitality' => array('s'=>$_pf_svgs['coffee'], 'c'=>'rgba(217,119,6,.75)','g'=>'linear-gradient(135deg,rgba(217,119,6,.18),rgba(217,119,6,.04))'),
  'photography' => array('s'=>$_pf_svgs['camera'], 'c'=>'rgba(139,92,246,.75)','g'=>'linear-gradient(135deg,rgba(139,92,246,.18),rgba(139,92,246,.04))'),
  'real-estate' => array('s'=>$_pf_svgs['home'],   'c'=>'rgba(20,184,166,.75)','g'=>'linear-gradient(135deg,rgba(20,184,166,.18),rgba(20,184,166,.04))'),
  'fintech'     => array('s'=>$_pf_svgs['dollar'],  'c'=>'rgba(52,211,153,.75)','g'=>'linear-gradient(135deg,rgba(52,211,153,.18),rgba(52,211,153,.04))'),
  'finance'     => array('s'=>$_pf_svgs['dollar'],  'c'=>'rgba(52,211,153,.75)','g'=>'linear-gradient(135deg,rgba(52,211,153,.18),rgba(52,211,153,.04))'),
  'nft'         => array('s'=>$_pf_svgs['layers'],  'c'=>'rgba(168,85,247,.75)','g'=>'linear-gradient(135deg,rgba(168,85,247,.18),rgba(168,85,247,.04))'),
  'web3'        => array('s'=>$_pf_svgs['layers'],  'c'=>'rgba(168,85,247,.75)','g'=>'linear-gradient(135deg,rgba(168,85,247,.18),rgba(168,85,247,.04))'),
  'crypto'      => array('s'=>$_pf_svgs['layers'],  'c'=>'rgba(168,85,247,.75)','g'=>'linear-gradient(135deg,rgba(168,85,247,.18),rgba(168,85,247,.04))'),
);

if ( $pf_query->have_posts() ) :
?>
<div class="tf-pf-grid" id="tfPfGrid">
<?php while ( $pf_query->have_posts() ) : $pf_query->the_post();
  $cats      = wp_get_post_terms( get_the_ID(), 'sf_portfolio_cat' );
  $cat_name  = ( ! empty( $cats ) && ! is_wp_error( $cats ) ) ? $cats[0]->name : '';
  $cat_slug  = ( ! empty( $cats ) && ! is_wp_error( $cats ) ) ? $cats[0]->slug : '';
  $_pf_map   = $emoji_map[ strtolower( $cat_slug ) ] ?? $emoji_map[ strtolower( $cat_name ) ] ?? array();
  $_pf_icon  = $_pf_map['s'] ?? $_pf_default_svg;
  $_pf_color = $_pf_map['c'] ?? 'rgba(255,94,46,.7)';
  $_pf_grad  = $_pf_map['g'] ?? 'linear-gradient(135deg,rgba(255,94,46,.15),rgba(255,94,46,.04))';

  /* Tags from second+ terms or a custom taxonomy */
  $extra_cats = array_slice( $cats, 1 );
  $tags       = wp_get_post_terms( get_the_ID(), 'sf_portfolio_tag' );
  $all_tags   = array_merge( $extra_cats, is_wp_error( $tags ) ? array() : $tags );
?>
<a
  href="<?php the_permalink(); ?>"
  class="tf-pf-card"
  data-cat="<?php echo esc_attr( $cat_slug ); ?>"
  aria-label="<?php echo esc_attr( get_the_title() ); ?>"
>
  <div class="tf-pf-thumb">
    <?php if ( has_post_thumbnail() ) : ?>
      <?php the_post_thumbnail( 'medium_large' ); ?>
    <?php else : ?>
      <div class="tf-pf-thumb-no-img" style="background:<?php echo esc_attr($_pf_grad); ?>">
        <div class="tf-pf-thumb-icon" style="color:<?php echo esc_attr($_pf_color); ?>" aria-hidden="true"><?php echo $_pf_icon; ?></div>
      </div>
    <?php endif; ?>
    <div class="tf-pf-overlay">
      <span class="tf-pf-view"><?php esc_html_e( 'View Project', 'themeflex' ); ?> →</span>
    </div>
  </div>
  <div class="tf-pf-body">
    <?php if ( $cat_name ) : ?>
      <div class="tf-pf-cat"><?php echo esc_html( $cat_name ); ?></div>
    <?php endif; ?>
    <h2 class="tf-pf-title"><?php the_title(); ?></h2>
    <p class="tf-pf-excerpt">
      <?php echo esc_html( wp_trim_words( get_the_excerpt() ?: get_the_content(), 16, '…' ) ); ?>
    </p>
    <?php if ( ! empty( $all_tags ) ) : ?>
    <div class="tf-pf-tags">
      <?php foreach ( array_slice( $all_tags, 0, 4 ) as $t ) : ?>
        <span class="tf-pf-tag"><?php echo esc_html( $t->name ); ?></span>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</a>
<?php endwhile; wp_reset_postdata(); ?>
</div><!-- .tf-pf-grid -->

<?php else : /* No CPT items — show friendly empty state */ ?>
<div class="tf-pf-empty">
  <div style="width:48px;height:48px;margin:0 auto 16px;opacity:.4;color:#ff5e2e"><?php echo $_pf_svgs['folder']; ?></div>
  <h2><?php esc_html_e( 'Portfolio Coming Soon', 'themeflex' ); ?></h2>
  <p><?php esc_html_e( 'Create your first sf_portfolio post in the WordPress admin to populate this page.', 'themeflex' ); ?></p>
</div>
<?php endif; ?>

<!-- ── CTA Banner ─────────────────────────────────────────── -->
<div class="tf-pf-cta">
  <h2><?php esc_html_e( 'Have a Project in Mind?', 'themeflex' ); ?></h2>
  <p><?php esc_html_e( "Let's turn your vision into a high-performance WordPress site that drives real results.", 'themeflex' ); ?></p>
  <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>" class="tf-pf-cta-btn">
    <?php esc_html_e( 'Start a Project', 'themeflex' ); ?>
    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
  </a>
</div>

</div><!-- .tf-pf-wrap -->

<?php
/* ── Category filter JS (vanilla, no jQuery needed) ─────────── */
if ( ! is_wp_error( $all_cats ) && ! empty( $all_cats ) ) : ?>
<script>
(function () {
  var tabs = document.querySelectorAll('.tf-pf-tab');
  var cards = document.querySelectorAll('#tfPfGrid .tf-pf-card');

  tabs.forEach(function (tab) {
    tab.addEventListener('click', function () {
      var filter = this.getAttribute('data-filter');
      // Update active tab
      tabs.forEach(function (t) { t.classList.remove('active'); });
      this.classList.add('active');
      // Show / hide cards
      cards.forEach(function (card) {
        var cat = card.getAttribute('data-cat');
        var show = (filter === 'all' || cat === filter);
        card.style.display = show ? 'block' : 'none';
      });
    });
  });
})();
</script>
<?php endif; ?>

</main><!-- #primary -->

<?php get_footer(); ?>
