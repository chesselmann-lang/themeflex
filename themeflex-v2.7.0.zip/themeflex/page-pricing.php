<?php
/**
 * Template Name: Pricing
 * Template Post Type: page
 *
 * Full dark-first Pricing page with:
 *  - Hero + Monthly/Annual toggle
 *  - 3-tier pricing cards (Free/Pro/Agency)
 *  - Full feature comparison table
 *  - FAQ accordion
 *  - Trust signals strip
 *  - CTA section
 *
 * No Elementor dependency — standalone.
 *
 * @package ThemeFlex
 * @since 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
get_header(); ?>

<main id="primary" class="tf-pricing-page">
<style>
/* ── Pricing Page — Dark-first ──────────────────────────── */
.tf-pricing-page {
  --tc:  #ff5e2e; --tc2: #00d4ff;
  --bg:  #06021d; --bg2: #0d1526; --bg3: #111827;
  --border: rgba(255,255,255,.07);
  --title: #f1f5f9; --txt: #94a3b8; --meta: #64748b;
  background: var(--bg); min-height: 100vh; padding-bottom: 100px;
}
.tf-pr-wrap { max-width: 1160px; margin: 0 auto; padding: 0 24px; }

/* ── Hero ───────────────────────────────────────────────── */
.tf-pr-hero {
  text-align: center;
  padding: 120px 24px 72px;
  background: radial-gradient(ellipse 70% 55% at 50% 0%, rgba(255,94,46,.14) 0%, transparent 70%), var(--bg);
  position: relative; overflow: hidden;
}
.tf-pr-hero::before {
  content: ''; position: absolute; inset: 0;
  background-image: radial-gradient(rgba(255,255,255,.03) 1px, transparent 1px);
  background-size: 36px 36px;
}
.tf-pr-eyebrow {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.25);
  color: var(--tc); font-size: .72rem; font-weight: 700; letter-spacing: .1em;
  text-transform: uppercase; padding: 6px 18px; border-radius: 100px; margin-bottom: 22px;
  position: relative; z-index: 1;
}
.tf-pr-hero h1 {
  position: relative; z-index: 1;
  font-size: clamp(2.4rem, 5vw, 3.8rem); font-weight: 900;
  color: var(--title); margin: 0 0 18px; line-height: 1.1;
}
.tf-pr-hero p {
  position: relative; z-index: 1;
  font-size: 1.1rem; color: var(--txt); max-width: 580px; margin: 0 auto 40px; line-height: 1.75;
}

/* ── Toggle switch ──────────────────────────────────────── */
.tf-pr-toggle-wrap {
  display: inline-flex; align-items: center; gap: 14px;
  background: var(--bg3); border: 1px solid var(--border);
  border-radius: 100px; padding: 6px 14px;
  position: relative; z-index: 1;
}
.tf-pr-toggle-label { font-size: .875rem; font-weight: 600; color: var(--meta); }
.tf-pr-toggle-label.active { color: var(--title); }
.tf-pr-switch {
  position: relative; width: 44px; height: 24px; cursor: pointer;
}
.tf-pr-switch input { opacity: 0; width: 0; height: 0; }
.tf-pr-slider {
  position: absolute; inset: 0; background: var(--tc); border-radius: 100px;
  transition: background .3s;
}
.tf-pr-slider::before {
  content: ''; position: absolute;
  height: 18px; width: 18px; left: 3px; top: 3px;
  background: #fff; border-radius: 50%; transition: transform .3s;
}
.tf-pr-switch input:checked + .tf-pr-slider::before { transform: translateX(20px); }
.tf-pr-save-badge {
  background: rgba(16,185,129,.15); border: 1px solid rgba(16,185,129,.3);
  color: #34d399; font-size: .7rem; font-weight: 700; letter-spacing: .06em;
  padding: 3px 10px; border-radius: 100px; white-space: nowrap;
}

/* ── Cards ──────────────────────────────────────────────── */
.tf-pr-cards {
  display: grid; grid-template-columns: repeat(3, 1fr);
  gap: 24px; padding: 64px 24px 0; max-width: 1100px; margin: 0 auto;
}
.tf-pr-card {
  background: var(--bg3); border: 1px solid var(--border);
  border-radius: 22px; padding: 36px 32px; position: relative;
  transition: border-color .3s, transform .3s;
  display: flex; flex-direction: column;
}
.tf-pr-card:hover { transform: translateY(-4px); border-color: rgba(255,255,255,.14); }
.tf-pr-card.featured {
  background: linear-gradient(160deg, #0f1e3a 0%, #0d1526 100%);
  border-color: rgba(255,94,46,.35);
  box-shadow: 0 0 0 1px rgba(255,94,46,.1), 0 32px 64px rgba(0,0,0,.35);
}
.tf-pr-card.featured:hover { transform: translateY(-6px); }
.tf-pr-popular {
  position: absolute; top: -13px; left: 50%; transform: translateX(-50%);
  background: var(--tc); color: #fff; font-size: .68rem; font-weight: 800;
  letter-spacing: .08em; text-transform: uppercase; padding: 5px 18px; border-radius: 100px;
  white-space: nowrap;
}

/* Card header */
.tf-pr-card-tier { font-size: .7rem; font-weight: 800; letter-spacing: .12em; text-transform: uppercase; color: var(--meta); margin-bottom: 16px; }
.tf-pr-card.featured .tf-pr-card-tier { color: var(--tc); }
.tf-pr-price { display: flex; align-items: flex-end; gap: 4px; margin-bottom: 6px; }
.tf-pr-price-amount { font-size: 3rem; font-weight: 900; color: var(--title); line-height: 1; }
.tf-pr-price-cents { font-size: 1.2rem; font-weight: 700; color: var(--title); margin-bottom: 6px; }
.tf-pr-price-period { font-size: .85rem; color: var(--meta); margin-bottom: 6px; }
.tf-pr-price-note { font-size: .78rem; color: var(--meta); margin: 0 0 24px; min-height: 20px; }

/* Features list */
.tf-pr-features { list-style: none; padding: 0; margin: 0 0 32px; flex: 1; }
.tf-pr-features li {
  display: flex; align-items: flex-start; gap: 10px;
  font-size: .875rem; color: var(--txt); padding: 8px 0;
  border-bottom: 1px solid rgba(255,255,255,.04);
}
.tf-pr-features li:last-child { border-bottom: none; }
.tf-pr-check { color: #22c55e; flex-shrink: 0; font-size: .9rem; margin-top: 1px; }
.tf-pr-cross { color: var(--meta); flex-shrink: 0; font-size: .9rem; margin-top: 1px; }
.tf-pr-features li.dim { opacity: .45; }

/* CTA button */
.tf-pr-btn {
  display: block; text-align: center;
  padding: 14px 24px; border-radius: 12px;
  font-size: .9rem; font-weight: 700; letter-spacing: .02em;
  text-decoration: none; transition: all .2s;
}
.tf-pr-btn.primary { background: var(--tc); color: #fff; }
.tf-pr-btn.primary:hover { background: #e04e22; transform: translateY(-1px); }
.tf-pr-btn.outline { background: transparent; border: 2px solid var(--border); color: var(--txt); }
.tf-pr-btn.outline:hover { border-color: var(--tc); color: var(--tc); }

/* ── Comparison table ───────────────────────────────────── */
.tf-pr-compare { padding: 100px 24px 0; }
.tf-pr-compare-inner { max-width: 1100px; margin: 0 auto; }
.tf-pr-compare h2 { font-size: 2rem; font-weight: 800; color: var(--title); text-align: center; margin: 0 0 48px; }
.tf-pr-table { width: 100%; border-collapse: collapse; }
.tf-pr-table th {
  padding: 16px 20px; text-align: left; font-size: .78rem; font-weight: 800;
  letter-spacing: .08em; text-transform: uppercase; color: var(--meta);
  border-bottom: 1px solid var(--border);
}
.tf-pr-table th:not(:first-child) { text-align: center; }
.tf-pr-table .tf-th-plan { font-size: 1rem; font-weight: 900; color: var(--title); letter-spacing: 0; text-transform: none; }
.tf-pr-table .tf-th-featured { color: var(--tc); }
.tf-pr-table tr.tf-tr-group td {
  background: rgba(255,255,255,.025); padding: 10px 20px;
  font-size: .72rem; font-weight: 800; letter-spacing: .1em; text-transform: uppercase;
  color: var(--meta); border-bottom: 1px solid var(--border);
  border-top: 1px solid var(--border);
}
.tf-pr-table td {
  padding: 14px 20px; font-size: .875rem; color: var(--txt);
  border-bottom: 1px solid rgba(255,255,255,.04);
}
.tf-pr-table td:not(:first-child) { text-align: center; }
.tf-pr-table tr:hover td { background: rgba(255,255,255,.015); }
.tf-pr-table .tf-td-yes { color: #22c55e; font-size: 1.1rem; }
.tf-pr-table .tf-td-no  { color: var(--meta); font-size: 1.1rem; }
.tf-pr-table .tf-td-val { font-weight: 700; color: var(--title); }

/* ── FAQ ────────────────────────────────────────────────── */
.tf-pr-faq { padding: 100px 24px 0; }
.tf-pr-faq-inner { max-width: 760px; margin: 0 auto; }
.tf-pr-faq h2 { font-size: 2rem; font-weight: 800; color: var(--title); text-align: center; margin: 0 0 48px; }
.tf-faq-item {
  border: 1px solid var(--border); border-radius: 14px; margin-bottom: 12px;
  overflow: hidden; background: var(--bg3);
}
.tf-faq-q {
  width: 100%; text-align: left; padding: 20px 24px; background: transparent; border: none;
  color: var(--title); font-size: .95rem; font-weight: 700; cursor: pointer;
  display: flex; justify-content: space-between; align-items: center; gap: 16px;
  transition: color .2s;
}
.tf-faq-q:hover { color: var(--tc); }
.tf-faq-icon { font-size: 1.2rem; flex-shrink: 0; transition: transform .3s; color: var(--tc); }
.tf-faq-item.open .tf-faq-icon { transform: rotate(45deg); }
.tf-faq-a {
  display: none; padding: 0 24px 20px;
  font-size: .9rem; color: var(--txt); line-height: 1.75;
}
.tf-faq-item.open .tf-faq-a { display: block; }

/* ── Trust strip ─────────────────────────────────────────── */
.tf-pr-trust {
  display: flex; flex-wrap: wrap; justify-content: center; gap: 32px;
  padding: 72px 24px 0; max-width: 900px; margin: 0 auto; text-align: center;
}
.tf-pr-trust-item { flex: 1 1 160px; }
.tf-pr-trust-icon {
  width: 44px; height: 44px; border-radius: 12px;
  margin: 0 auto 12px;
  display: flex; align-items: center; justify-content: center;
  background: rgba(255,255,255,.05);
  border: 1px solid rgba(255,255,255,.07);
  color: #ff5e2e;
}
.tf-pr-trust-icon svg { width: 22px; height: 22px; display: block; }
.tf-pr-trust-title { font-size: .9rem; font-weight: 700; color: var(--title); margin-bottom: 4px; }
.tf-pr-trust-txt { font-size: .8rem; color: var(--meta); line-height: 1.5; }

/* ── CTA ─────────────────────────────────────────────────── */
.tf-pr-cta {
  margin: 80px 24px 0; max-width: 860px; margin-inline: auto;
  background: linear-gradient(135deg, rgba(255,94,46,.12), rgba(0,212,255,.06));
  border: 1px solid rgba(255,94,46,.2); border-radius: 24px;
  text-align: center; padding: 80px 40px;
}
.tf-pr-cta h2 { font-size: clamp(1.6rem, 3vw, 2.4rem); font-weight: 800; color: var(--title); margin: 0 0 14px; }
.tf-pr-cta p  { font-size: 1.05rem; color: var(--txt); margin: 0 0 36px; }
.tf-pr-cta-btn {
  display: inline-flex; align-items: center; gap: 10px;
  background: var(--tc); color: #fff; font-size: .95rem; font-weight: 700;
  padding: 16px 40px; border-radius: 100px; text-decoration: none;
  transition: background .2s, transform .2s;
}
.tf-pr-cta-btn:hover { background: #e04e22; transform: translateY(-2px); }

/* ── Responsive ──────────────────────────────────────────── */
@media(max-width:900px)  { .tf-pr-cards { grid-template-columns: 1fr; max-width: 480px; } }
@media(max-width:768px)  { .tf-pr-table { display: none; } /* too narrow for full table */ }
</style>

<!-- ── Hero ───────────────────────────────────────────────── -->
<div class="tf-pr-hero">
  <div class="tf-pr-eyebrow">◆ <?php esc_html_e( 'Simple Pricing', 'themeflex' ); ?></div>
  <h1><?php esc_html_e( 'One Purchase. Lifetime Access.', 'themeflex' ); ?></h1>
  <p><?php esc_html_e( 'ThemeFlex is a one-time purchase on ThemeForest — no monthly fees, no subscription traps. Choose the plan that fits your project.', 'themeflex' ); ?></p>

  <!-- Toggle — monthly/annual (for SaaS demos showing recurring billing) -->
  <div class="tf-pr-toggle-wrap" role="group" aria-label="<?php esc_attr_e( 'Billing period', 'themeflex' ); ?>">
    <span class="tf-pr-toggle-label active" id="tfLblMonthly"><?php esc_html_e( 'One-time', 'themeflex' ); ?></span>
    <label class="tf-pr-switch" aria-label="<?php esc_attr_e( 'Switch to extended licence', 'themeflex' ); ?>">
      <input type="checkbox" id="tfPricingToggle" role="switch">
      <span class="tf-pr-slider"></span>
    </label>
    <span class="tf-pr-toggle-label" id="tfLblAnnual"><?php esc_html_e( 'Extended Licence', 'themeflex' ); ?></span>
    <span class="tf-pr-save-badge"><?php esc_html_e( 'For SaaS / Apps', 'themeflex' ); ?></span>
  </div>
</div>

<!-- ── Pricing cards ──────────────────────────────────────── -->
<div class="tf-pr-cards">

  <!-- Starter -->
  <div class="tf-pr-card">
    <div class="tf-pr-card-tier"><?php esc_html_e( 'Starter', 'themeflex' ); ?></div>
    <div class="tf-pr-price">
      <span class="tf-pr-price-amount" data-monthly="Free" data-annual="Free">Free</span>
    </div>
    <p class="tf-pr-price-note" data-monthly="<?php esc_attr_e( 'No credit card required', 'themeflex' ); ?>" data-annual="<?php esc_attr_e( 'No credit card required', 'themeflex' ); ?>">
      <?php esc_html_e( 'No credit card required', 'themeflex' ); ?>
    </p>
    <ul class="tf-pr-features">
      <li><span class="tf-pr-check">✓</span> <?php esc_html_e( '1 WordPress site', 'themeflex' ); ?></li>
      <li><span class="tf-pr-check">✓</span> <?php esc_html_e( 'Core dark-first templates', 'themeflex' ); ?></li>
      <li><span class="tf-pr-check">✓</span> <?php esc_html_e( '20+ Elementor widgets', 'themeflex' ); ?></li>
      <li><span class="tf-pr-check">✓</span> <?php esc_html_e( '3 colour skins', 'themeflex' ); ?></li>
      <li class="dim"><span class="tf-pr-cross">–</span> <?php esc_html_e( 'Premium demo content', 'themeflex' ); ?></li>
      <li class="dim"><span class="tf-pr-cross">–</span> <?php esc_html_e( 'Priority support', 'themeflex' ); ?></li>
      <li class="dim"><span class="tf-pr-cross">–</span> <?php esc_html_e( '80+ widgets', 'themeflex' ); ?></li>
    </ul>
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="tf-pr-btn outline">
      <?php esc_html_e( 'Download Free', 'themeflex' ); ?>
    </a>
  </div>

  <!-- Pro — FEATURED -->
  <div class="tf-pr-card featured">
    <div class="tf-pr-popular"><?php esc_html_e( 'Most Popular', 'themeflex' ); ?></div>
    <div class="tf-pr-card-tier"><?php esc_html_e( 'Pro', 'themeflex' ); ?></div>
    <div class="tf-pr-price">
      <span class="tf-pr-price-cents">$</span>
      <span class="tf-pr-price-amount" data-monthly="59" data-annual="79">59</span>
    </div>
    <p class="tf-pr-price-note"
       data-monthly="<?php esc_attr_e( 'One-time purchase · Regular Licence', 'themeflex' ); ?>"
       data-annual="<?php esc_attr_e( 'One-time purchase · Extended Licence', 'themeflex' ); ?>">
      <?php esc_html_e( 'One-time purchase · Regular Licence', 'themeflex' ); ?>
    </p>
    <ul class="tf-pr-features">
      <li><span class="tf-pr-check">✓</span> <?php esc_html_e( '1 client / personal project', 'themeflex' ); ?></li>
      <li><span class="tf-pr-check">✓</span> <?php esc_html_e( 'All dark-first page templates', 'themeflex' ); ?></li>
      <li><span class="tf-pr-check">✓</span> <?php esc_html_e( '80+ Elementor widgets', 'themeflex' ); ?></li>
      <li><span class="tf-pr-check">✓</span> <?php esc_html_e( '8 colour skins + Google Fonts', 'themeflex' ); ?></li>
      <li><span class="tf-pr-check">✓</span> <?php esc_html_e( 'One-click demo import', 'themeflex' ); ?></li>
      <li><span class="tf-pr-check">✓</span> <?php esc_html_e( '12+ full demo sites', 'themeflex' ); ?></li>
      <li><span class="tf-pr-check">✓</span> <?php esc_html_e( '6 months support on ThemeForest', 'themeflex' ); ?></li>
    </ul>
    <a
      href="https://themeforest.net/item/themeflex"
      target="_blank" rel="noopener"
      class="tf-pr-btn primary"
    >
      <?php esc_html_e( 'Buy on ThemeForest', 'themeflex' ); ?> →
    </a>
  </div>

  <!-- Agency -->
  <div class="tf-pr-card">
    <div class="tf-pr-card-tier"><?php esc_html_e( 'Agency', 'themeflex' ); ?></div>
    <div class="tf-pr-price">
      <span class="tf-pr-price-cents">$</span>
      <span class="tf-pr-price-amount" data-monthly="199" data-annual="299">199</span>
    </div>
    <p class="tf-pr-price-note"
       data-monthly="<?php esc_attr_e( 'ThemeForest multi-licence bundle', 'themeflex' ); ?>"
       data-annual="<?php esc_attr_e( 'Extended multi-licence bundle', 'themeflex' ); ?>">
      <?php esc_html_e( 'ThemeForest multi-licence bundle', 'themeflex' ); ?>
    </p>
    <ul class="tf-pr-features">
      <li><span class="tf-pr-check">✓</span> <?php esc_html_e( 'Up to 5 client projects', 'themeflex' ); ?></li>
      <li><span class="tf-pr-check">✓</span> <?php esc_html_e( 'Everything in Pro', 'themeflex' ); ?></li>
      <li><span class="tf-pr-check">✓</span> <?php esc_html_e( 'White-label Admin branding', 'themeflex' ); ?></li>
      <li><span class="tf-pr-check">✓</span> <?php esc_html_e( 'Companion plugin (companion.tf)', 'themeflex' ); ?></li>
      <li><span class="tf-pr-check">✓</span> <?php esc_html_e( '12 months priority support', 'themeflex' ); ?></li>
      <li><span class="tf-pr-check">✓</span> <?php esc_html_e( 'Onboarding call (60 min)', 'themeflex' ); ?></li>
      <li><span class="tf-pr-check">✓</span> <?php esc_html_e( 'Lifetime updates', 'themeflex' ); ?></li>
    </ul>
    <a
      href="<?php echo esc_url( home_url( '/contact' ) ); ?>"
      class="tf-pr-btn outline"
    >
      <?php esc_html_e( 'Contact for Agency Deal', 'themeflex' ); ?>
    </a>
  </div>

</div><!-- .tf-pr-cards -->

<!-- ── Feature comparison table ──────────────────────────── -->
<div class="tf-pr-compare">
  <div class="tf-pr-compare-inner">
    <h2><?php esc_html_e( 'Full Feature Comparison', 'themeflex' ); ?></h2>
    <table class="tf-pr-table" aria-label="<?php esc_attr_e( 'Feature comparison table', 'themeflex' ); ?>">
      <thead>
        <tr>
          <th><?php esc_html_e( 'Feature', 'themeflex' ); ?></th>
          <th class="tf-th-plan"><?php esc_html_e( 'Starter', 'themeflex' ); ?></th>
          <th class="tf-th-plan tf-th-featured"><?php esc_html_e( 'Pro', 'themeflex' ); ?></th>
          <th class="tf-th-plan"><?php esc_html_e( 'Agency', 'themeflex' ); ?></th>
        </tr>
      </thead>
      <tbody>
        <!-- Design -->
        <tr class="tf-tr-group"><td colspan="4"><?php esc_html_e( 'Design', 'themeflex' ); ?></td></tr>
        <tr><td><?php esc_html_e( 'Dark-first templates', 'themeflex' ); ?></td><td class="tf-td-yes">✓</td><td class="tf-td-yes">✓</td><td class="tf-td-yes">✓</td></tr>
        <tr><td><?php esc_html_e( 'Colour skins', 'themeflex' ); ?></td><td class="tf-td-val">3</td><td class="tf-td-val">8</td><td class="tf-td-val">8+</td></tr>
        <tr><td><?php esc_html_e( 'Custom Google Fonts per skin', 'themeflex' ); ?></td><td class="tf-td-no">–</td><td class="tf-td-yes">✓</td><td class="tf-td-yes">✓</td></tr>
        <tr><td><?php esc_html_e( 'Light / Dark mode toggle', 'themeflex' ); ?></td><td class="tf-td-yes">✓</td><td class="tf-td-yes">✓</td><td class="tf-td-yes">✓</td></tr>
        <!-- Elementor -->
        <tr class="tf-tr-group"><td colspan="4"><?php esc_html_e( 'Elementor Widgets', 'themeflex' ); ?></td></tr>
        <tr><td><?php esc_html_e( 'Core widget set', 'themeflex' ); ?></td><td class="tf-td-val">20+</td><td class="tf-td-val">80+</td><td class="tf-td-val">80+</td></tr>
        <tr><td><?php esc_html_e( 'Advanced chart widgets', 'themeflex' ); ?></td><td class="tf-td-no">–</td><td class="tf-td-yes">✓</td><td class="tf-td-yes">✓</td></tr>
        <tr><td><?php esc_html_e( 'WooCommerce widgets', 'themeflex' ); ?></td><td class="tf-td-no">–</td><td class="tf-td-yes">✓</td><td class="tf-td-yes">✓</td></tr>
        <!-- Pages -->
        <tr class="tf-tr-group"><td colspan="4"><?php esc_html_e( 'Page Templates', 'themeflex' ); ?></td></tr>
        <tr><td><?php esc_html_e( 'Core templates (Blog, Archive, 404)', 'themeflex' ); ?></td><td class="tf-td-yes">✓</td><td class="tf-td-yes">✓</td><td class="tf-td-yes">✓</td></tr>
        <tr><td><?php esc_html_e( 'SaaS landing page', 'themeflex' ); ?></td><td class="tf-td-no">–</td><td class="tf-td-yes">✓</td><td class="tf-td-yes">✓</td></tr>
        <tr><td><?php esc_html_e( 'Portfolio archive + single', 'themeflex' ); ?></td><td class="tf-td-no">–</td><td class="tf-td-yes">✓</td><td class="tf-td-yes">✓</td></tr>
        <tr><td><?php esc_html_e( 'About, Contact, Pricing pages', 'themeflex' ); ?></td><td class="tf-td-no">–</td><td class="tf-td-yes">✓</td><td class="tf-td-yes">✓</td></tr>
        <!-- Demos -->
        <tr class="tf-tr-group"><td colspan="4"><?php esc_html_e( 'Demo Content', 'themeflex' ); ?></td></tr>
        <tr><td><?php esc_html_e( 'One-click demo import', 'themeflex' ); ?></td><td class="tf-td-no">–</td><td class="tf-td-yes">✓</td><td class="tf-td-yes">✓</td></tr>
        <tr><td><?php esc_html_e( 'Number of full demos', 'themeflex' ); ?></td><td class="tf-td-val">–</td><td class="tf-td-val">12+</td><td class="tf-td-val">12+</td></tr>
        <!-- Support -->
        <tr class="tf-tr-group"><td colspan="4"><?php esc_html_e( 'Support', 'themeflex' ); ?></td></tr>
        <tr><td><?php esc_html_e( 'Community forum access', 'themeflex' ); ?></td><td class="tf-td-yes">✓</td><td class="tf-td-yes">✓</td><td class="tf-td-yes">✓</td></tr>
        <tr><td><?php esc_html_e( 'ThemeForest item comments', 'themeflex' ); ?></td><td class="tf-td-no">–</td><td class="tf-td-val">6 months</td><td class="tf-td-val">12 months</td></tr>
        <tr><td><?php esc_html_e( 'Priority email support', 'themeflex' ); ?></td><td class="tf-td-no">–</td><td class="tf-td-no">–</td><td class="tf-td-yes">✓</td></tr>
        <tr><td><?php esc_html_e( 'Onboarding call', 'themeflex' ); ?></td><td class="tf-td-no">–</td><td class="tf-td-no">–</td><td class="tf-td-yes">✓</td></tr>
        <tr><td><?php esc_html_e( 'Lifetime updates', 'themeflex' ); ?></td><td class="tf-td-no">–</td><td class="tf-td-yes">✓</td><td class="tf-td-yes">✓</td></tr>
        <tr><td><?php esc_html_e( 'Money-back guarantee', 'themeflex' ); ?></td><td class="tf-td-val">–</td><td class="tf-td-val">14 days</td><td class="tf-td-val">14 days</td></tr>
      </tbody>
    </table>
  </div>
</div>

<!-- ── FAQ ────────────────────────────────────────────────── -->
<div class="tf-pr-faq">
  <div class="tf-pr-faq-inner">
    <h2><?php esc_html_e( 'Frequently Asked Questions', 'themeflex' ); ?></h2>

    <?php
    $faqs = array(
      array(
        'q' => __( 'Does ThemeFlex work without Elementor?', 'themeflex' ),
        'a' => __( 'Yes. All core page templates (SaaS, About, Contact, Portfolio, Pricing) are completely standalone PHP — no Elementor dependency. Elementor is only needed if you want to use the 80+ custom widgets for building custom layouts.', 'themeflex' ),
      ),
      array(
        'q' => __( 'What does "dark-first" mean?', 'themeflex' ),
        'a' => __( "It means dark mode is the default — not an afterthought. Every template, widget, and section is designed and tested in dark mode first. Light mode support is included but dark is the primary experience, which is what modern SaaS and agency sites expect.", 'themeflex' ),
      ),
      array(
        'q' => __( 'Can I use ThemeFlex on a client site?', 'themeflex' ),
        'a' => __( 'A Regular Licence (Pro plan) covers one end product — whether personal or for a client who pays you. If you build for multiple clients, the Agency multi-licence bundle covers up to 5 projects. For unlimited use, contact us.', 'themeflex' ),
      ),
      array(
        'q' => __( 'Will I get future updates?', 'themeflex' ),
        'a' => __( 'Yes — Pro and Agency licences include lifetime updates via ThemeForest. Every time we ship a new version you can update directly from WP Admin, just like any other theme.', 'themeflex' ),
      ),
      array(
        'q' => __( 'Does it work with WooCommerce?', 'themeflex' ),
        'a' => __( 'Yes. ThemeFlex includes WooCommerce template overrides and dedicated Elementor widgets for shop pages, product archives, and single product pages. Full dark-first WooCommerce styling is included.', 'themeflex' ),
      ),
      array(
        'q' => __( 'What is the money-back guarantee?', 'themeflex' ),
        'a' => __( "If ThemeFlex doesn't work for your project within 14 days of purchase and we can't resolve the issue, Envato will process a refund. The standard ThemeForest refund policy applies.", 'themeflex' ),
      ),
    );
    foreach ( $faqs as $i => $faq ) : ?>
    <div class="tf-faq-item" id="tfFaq<?php echo $i; ?>">
      <button class="tf-faq-q" aria-expanded="false" aria-controls="tfFaqA<?php echo $i; ?>">
        <?php echo esc_html( $faq['q'] ); ?>
        <span class="tf-faq-icon" aria-hidden="true">+</span>
      </button>
      <div class="tf-faq-a" id="tfFaqA<?php echo $i; ?>" role="region">
        <?php echo esc_html( $faq['a'] ); ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- ── Trust strip ────────────────────────────────────────── -->
<div class="tf-pr-trust">
  <div class="tf-pr-trust-item">
    <div class="tf-pr-trust-icon" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg></div>
    <div class="tf-pr-trust-title"><?php esc_html_e( '97 PageSpeed', 'themeflex' ); ?></div>
    <div class="tf-pr-trust-txt"><?php esc_html_e( 'Out of the box, no config', 'themeflex' ); ?></div>
  </div>
  <div class="tf-pr-trust-item">
    <div class="tf-pr-trust-icon" style="color:#10b981" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg></div>
    <div class="tf-pr-trust-title"><?php esc_html_e( 'WCAG 2.1 AA', 'themeflex' ); ?></div>
    <div class="tf-pr-trust-txt"><?php esc_html_e( 'Accessibility by default', 'themeflex' ); ?></div>
  </div>
  <div class="tf-pr-trust-item">
    <div class="tf-pr-trust-icon" style="color:#a855f7" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg></div>
    <div class="tf-pr-trust-title"><?php esc_html_e( 'No Tracking', 'themeflex' ); ?></div>
    <div class="tf-pr-trust-txt"><?php esc_html_e( 'Privacy-first, zero data phoning home', 'themeflex' ); ?></div>
  </div>
  <div class="tf-pr-trust-item">
    <div class="tf-pr-trust-icon" style="color:#3b82f6" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></div>
    <div class="tf-pr-trust-title"><?php esc_html_e( '14-day Refund', 'themeflex' ); ?></div>
    <div class="tf-pr-trust-txt"><?php esc_html_e( 'Via ThemeForest guarantee', 'themeflex' ); ?></div>
  </div>
  <div class="tf-pr-trust-item">
    <div class="tf-pr-trust-icon" style="color:#00d4ff" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg></div>
    <div class="tf-pr-trust-title"><?php esc_html_e( '40+ Countries', 'themeflex' ); ?></div>
    <div class="tf-pr-trust-txt"><?php esc_html_e( 'Trusted by agencies worldwide', 'themeflex' ); ?></div>
  </div>
</div>

<!-- ── CTA ─────────────────────────────────────────────────── -->
<div class="tf-pr-cta" style="margin-top:80px;margin-bottom:0">
  <h2><?php esc_html_e( 'Ready to Build with ThemeFlex?', 'themeflex' ); ?></h2>
  <p><?php esc_html_e( 'One purchase. Lifetime updates. 14-day money-back guarantee. No risk.', 'themeflex' ); ?></p>
  <a href="https://themeforest.net/item/themeflex" target="_blank" rel="noopener" class="tf-pr-cta-btn">
    <?php esc_html_e( 'Get ThemeFlex on ThemeForest', 'themeflex' ); ?> →
  </a>
</div>

<script>
/* ── Toggle: update displayed prices ───────────────────── */
(function () {
  var toggle = document.getElementById('tfPricingToggle');
  if (!toggle) return;
  var amounts = document.querySelectorAll('.tf-pr-price-amount');
  var notes   = document.querySelectorAll('.tf-pr-price-note');
  var lblM    = document.getElementById('tfLblMonthly');
  var lblA    = document.getElementById('tfLblAnnual');

  toggle.addEventListener('change', function () {
    var extended = this.checked;
    amounts.forEach(function (el) {
      el.textContent = extended ? el.dataset.annual : el.dataset.monthly;
    });
    notes.forEach(function (el) {
      el.textContent = extended ? el.dataset.annual : el.dataset.monthly;
    });
    if (lblM) lblM.classList.toggle('active', !extended);
    if (lblA) lblA.classList.toggle('active',  extended);
  });
})();

/* ── FAQ accordion ─────────────────────────────────────── */
(function () {
  document.querySelectorAll('.tf-faq-q').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var item = this.closest('.tf-faq-item');
      var isOpen = item.classList.contains('open');
      // close all
      document.querySelectorAll('.tf-faq-item.open').forEach(function (i) {
        i.classList.remove('open');
        i.querySelector('.tf-faq-q').setAttribute('aria-expanded', 'false');
      });
      // toggle clicked
      if (!isOpen) {
        item.classList.add('open');
        this.setAttribute('aria-expanded', 'true');
      }
    });
  });
})();
</script>

</main><!-- #primary -->

<?php get_footer(); ?>
