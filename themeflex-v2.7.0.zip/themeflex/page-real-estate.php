<?php
/**
 * Template Name: Real Estate Homepage
 * Template Post Type: page
 *
 * Premium dark-first Real Estate landing page — full-bleed hero with search
 * bar UI, property type tabs, featured listings grid, animated stats bar,
 * feature cards, agent spotlight, testimonials, and CTA banner.
 * Zero Elementor dependency. Vanilla CSS + minimal inline JS.
 *
 * @package ThemeFlex
 * @since   2.8.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
?>

<main id="primary" class="tf-re-page" aria-label="<?php echo esc_attr( esc_html__( 'Real Estate Homepage', 'themeflex' ) ); ?>">
<style>
/* ══════════════════════════════════════════════════════════════════════
   ThemeFlex — Real Estate Homepage Template
   Dark-first, zero dependencies, responsive 3 → 2 → 1 col
   Colour tokens extend global CSS custom properties.
   ══════════════════════════════════════════════════════════════════════ */

.tf-re-page {
  --re-bg:       var(--tf-bg,      #06021d);
  --re-bg-2:     var(--tf-bg-2,    #0d1526);
  --re-bg-3:     var(--tf-bg-3,    #111827);
  --re-accent:   var(--tf-accent,  #ff5e2e);
  --re-border:   var(--tf-border,  rgba(255,255,255,.07));
  --re-heading:  var(--tf-heading, #f8fafc);
  --re-muted:    var(--tf-muted,   #94a3b8);
  --re-text:     var(--tf-text,    #e2e8f0);
  --re-blue:     #3b82f6;
  --re-green:    #10b981;
  --re-amber:    #f59e0b;
  --re-violet:   #8b5cf6;
  --re-teal:     #14b8a6;
  --re-rose:     #f43f5e;
  --re-r:        14px;
  font-family: 'Inter Tight', system-ui, sans-serif;
  background: var(--re-bg);
  color: var(--re-text);
  overflow-x: hidden;
}
.tf-re-page *,
.tf-re-page *::before,
.tf-re-page *::after { box-sizing: border-box; margin: 0; padding: 0; }

/* ── Layout helpers ──────────────────────────────────────────────────── */
.tf-re-wrap { max-width: 1200px; margin: 0 auto; padding: 0 24px; }
.tf-re-section { padding: 96px 0; }
.tf-re-section-head { text-align: center; margin-bottom: 56px; }
.tf-re-eyebrow {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.22);
  color: var(--re-accent); font-size: .68rem; font-weight: 800;
  letter-spacing: .16em; text-transform: uppercase;
  padding: 5px 16px; border-radius: 100px; margin-bottom: 16px;
}
.tf-re-eyebrow svg { width: 12px; height: 12px; }
.tf-re-section-head h2 {
  font-size: clamp(1.75rem, 3.2vw, 2.7rem); font-weight: 900;
  color: var(--re-heading); line-height: 1.15; margin-bottom: 14px;
}
.tf-re-section-head p {
  font-size: 1.05rem; color: var(--re-muted); max-width: 560px;
  margin: 0 auto; line-height: 1.75;
}

/* ── Scroll reveal ───────────────────────────────────────────────────── */
.tf-re-reveal {
  opacity: 0;
  transform: translateY(28px);
  transition: opacity .55s ease, transform .55s ease;
}
.tf-re-reveal.tf-re-visible {
  opacity: 1;
  transform: translateY(0);
}

/* ══════════════════════════════════════════════════════════════════════
   1 · HERO
   ══════════════════════════════════════════════════════════════════════ */
.tf-re-hero {
  position: relative;
  overflow: hidden;
  min-height: 100vh;
  display: flex;
  align-items: center;
  padding: 120px 0 100px;
  background: var(--re-bg);
}

/* Animated gradient orbs */
.tf-re-hero-orb-1,
.tf-re-hero-orb-2 {
  position: absolute;
  border-radius: 50%;
  filter: blur(90px);
  pointer-events: none;
  animation: tf-re-orb-drift 14s ease-in-out infinite alternate;
}
.tf-re-hero-orb-1 {
  width: 680px; height: 680px;
  background: radial-gradient(circle, rgba(255,94,46,.18) 0%, transparent 70%);
  top: -160px; left: -160px;
}
.tf-re-hero-orb-2 {
  width: 520px; height: 520px;
  background: radial-gradient(circle, rgba(59,130,246,.14) 0%, transparent 70%);
  bottom: -100px; right: -60px;
  animation-delay: -7s;
}
@keyframes tf-re-orb-drift {
  from { transform: translate(0,0) scale(1); }
  to   { transform: translate(30px, 20px) scale(1.06); }
}

/* Dot-grid backdrop */
.tf-re-hero::before {
  content: '';
  position: absolute; inset: 0;
  pointer-events: none;
  background-image: radial-gradient(rgba(255,255,255,.032) 1px, transparent 1px);
  background-size: 32px 32px;
  mask-image: linear-gradient(to bottom, transparent 0%, rgba(0,0,0,.6) 20%, rgba(0,0,0,.6) 80%, transparent 100%);
}

.tf-re-hero-inner {
  position: relative;
  z-index: 2;
  text-align: center;
  width: 100%;
}

/* Trust badges */
.tf-re-hero-badges {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 10px;
  margin-bottom: 28px;
}
.tf-re-hero-badge {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: rgba(255,255,255,.05);
  border: 1px solid var(--re-border);
  border-radius: 100px;
  padding: 5px 14px;
  font-size: .75rem;
  font-weight: 600;
  color: var(--re-muted);
  backdrop-filter: blur(8px);
}
.tf-re-hero-badge svg { width: 13px; height: 13px; color: var(--re-accent); }

/* Hero headline */
.tf-re-hero-headline {
  font-size: clamp(2.4rem, 6vw, 4.4rem);
  font-weight: 900;
  color: var(--re-heading);
  line-height: 1.1;
  margin-bottom: 18px;
  letter-spacing: -.02em;
}
.tf-re-hero-headline span {
  background: linear-gradient(135deg, var(--re-accent) 0%, #ff8c5a 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
.tf-re-hero-sub {
  font-size: 1.15rem;
  color: var(--re-muted);
  max-width: 560px;
  margin: 0 auto 40px;
  line-height: 1.7;
}

/* Search bar */
.tf-re-search-bar {
  display: flex;
  flex-wrap: wrap;
  gap: 0;
  max-width: 860px;
  margin: 0 auto 60px;
  background: rgba(13,21,38,.9);
  border: 1px solid var(--re-border);
  border-radius: 16px;
  overflow: hidden;
  backdrop-filter: blur(12px);
  box-shadow: 0 24px 60px rgba(0,0,0,.45);
}
.tf-re-search-field {
  flex: 1 1 160px;
  display: flex;
  flex-direction: column;
  padding: 16px 20px;
  border-right: 1px solid var(--re-border);
  min-width: 0;
}
.tf-re-search-field:last-of-type { border-right: none; }
.tf-re-search-label {
  font-size: .65rem;
  font-weight: 700;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: var(--re-muted);
  margin-bottom: 4px;
}
.tf-re-search-value {
  font-size: .92rem;
  color: var(--re-text);
  font-weight: 500;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.tf-re-search-value svg { width: 14px; height: 14px; vertical-align: middle; color: var(--re-muted); margin-right: 4px; }
.tf-re-search-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  background: var(--re-accent);
  color: #fff;
  font-size: .92rem;
  font-weight: 700;
  padding: 0 32px;
  cursor: pointer;
  border: none;
  white-space: nowrap;
  transition: background .2s;
  min-width: 140px;
}
.tf-re-search-btn svg { width: 18px; height: 18px; }
.tf-re-search-btn:hover { background: #e5501e; }

/* Floating stat cards */
.tf-re-hero-stats {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 16px;
}
.tf-re-hero-stat {
  background: rgba(13,21,38,.85);
  border: 1px solid var(--re-border);
  border-radius: var(--re-r);
  padding: 20px 28px;
  text-align: center;
  backdrop-filter: blur(10px);
  min-width: 160px;
  box-shadow: 0 8px 30px rgba(0,0,0,.3);
}
.tf-re-hero-stat-num {
  font-size: 1.9rem;
  font-weight: 900;
  color: var(--re-heading);
  display: block;
  line-height: 1;
  margin-bottom: 6px;
}
.tf-re-hero-stat-num span { color: var(--re-accent); }
.tf-re-hero-stat-label {
  font-size: .78rem;
  color: var(--re-muted);
  font-weight: 500;
}

/* ══════════════════════════════════════════════════════════════════════
   2 · PROPERTY TYPE TABS
   ══════════════════════════════════════════════════════════════════════ */
.tf-re-tabs-section {
  padding: 72px 0;
  background: var(--re-bg-2);
  border-top: 1px solid var(--re-border);
  border-bottom: 1px solid var(--re-border);
}

.tf-re-tab-nav {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: center;
  margin-bottom: 48px;
}
.tf-re-tab-btn {
  padding: 8px 22px;
  border-radius: 100px;
  border: 1px solid var(--re-border);
  background: transparent;
  color: var(--re-muted);
  font-size: .85rem;
  font-weight: 600;
  cursor: pointer;
  transition: all .2s;
}
.tf-re-tab-btn:hover,
.tf-re-tab-btn.tf-re-tab-active {
  background: var(--re-accent);
  border-color: var(--re-accent);
  color: #fff;
}

.tf-re-type-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
}
.tf-re-type-card {
  background: var(--re-bg-3);
  border: 1px solid var(--re-border);
  border-radius: var(--re-r);
  padding: 32px 24px;
  text-align: center;
  cursor: pointer;
  transition: border-color .25s, transform .25s, box-shadow .25s;
}
.tf-re-type-card:hover {
  border-color: var(--re-accent);
  transform: translateY(-4px);
  box-shadow: 0 12px 32px rgba(0,0,0,.3);
}
.tf-re-type-icon {
  width: 52px; height: 52px;
  border-radius: 12px;
  background: rgba(255,94,46,.12);
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto 16px;
  color: var(--re-accent);
}
.tf-re-type-icon svg { width: 26px; height: 26px; }
.tf-re-type-name {
  font-size: 1rem;
  font-weight: 700;
  color: var(--re-heading);
  margin-bottom: 6px;
}
.tf-re-type-count {
  font-size: .8rem;
  color: var(--re-muted);
}

@media (max-width: 1024px) {
  .tf-re-type-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 640px) {
  .tf-re-type-grid { grid-template-columns: 1fr; }
  .tf-re-search-bar { border-radius: 12px; }
  .tf-re-search-field { border-right: none; border-bottom: 1px solid var(--re-border); }
  .tf-re-search-field:last-of-type { border-bottom: none; }
  .tf-re-search-btn { min-height: 52px; }
}

/* ══════════════════════════════════════════════════════════════════════
   3 · FEATURED LISTINGS GRID
   ══════════════════════════════════════════════════════════════════════ */
.tf-re-listings-section { background: var(--re-bg); }

.tf-re-listings-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
}
.tf-re-listing-card {
  background: var(--re-bg-2);
  border: 1px solid var(--re-border);
  border-radius: var(--re-r);
  overflow: hidden;
  transition: transform .25s, box-shadow .25s, border-color .25s;
}
.tf-re-listing-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 20px 48px rgba(0,0,0,.4);
  border-color: rgba(255,94,46,.25);
}

/* Image placeholder */
.tf-re-listing-img {
  position: relative;
  height: 200px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}
.tf-re-listing-img svg { width: 52px; height: 52px; opacity: .55; color: #fff; position: relative; z-index: 1; }
.tf-re-listing-img--blue   { background: linear-gradient(135deg, #1e3a5f 0%, #2563eb 100%); }
.tf-re-listing-img--green  { background: linear-gradient(135deg, #064e3b 0%, #059669 100%); }
.tf-re-listing-img--amber  { background: linear-gradient(135deg, #451a03 0%, #d97706 100%); }
.tf-re-listing-img--violet { background: linear-gradient(135deg, #2e1065 0%, #7c3aed 100%); }
.tf-re-listing-img--teal   { background: linear-gradient(135deg, #042f2e 0%, #0d9488 100%); }
.tf-re-listing-img--rose   { background: linear-gradient(135deg, #4c0519 0%, #e11d48 100%); }

.tf-re-listing-badges {
  position: absolute;
  top: 12px; left: 12px;
  display: flex; gap: 6px;
  z-index: 2;
}
.tf-re-badge {
  font-size: .68rem;
  font-weight: 700;
  letter-spacing: .06em;
  text-transform: uppercase;
  padding: 3px 10px;
  border-radius: 100px;
  backdrop-filter: blur(6px);
}
.tf-re-badge--sale  { background: rgba(255,94,46,.85); color: #fff; }
.tf-re-badge--rent  { background: rgba(59,130,246,.85); color: #fff; }
.tf-re-badge--new   { background: rgba(16,185,129,.85); color: #fff; }

/* Card body */
.tf-re-listing-body { padding: 20px; }
.tf-re-listing-name {
  font-size: 1.05rem;
  font-weight: 700;
  color: var(--re-heading);
  margin-bottom: 6px;
}
.tf-re-listing-loc {
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: .82rem;
  color: var(--re-muted);
  margin-bottom: 14px;
}
.tf-re-listing-loc svg { width: 13px; height: 13px; flex-shrink: 0; color: var(--re-accent); }

.tf-re-listing-meta {
  display: flex;
  gap: 16px;
  flex-wrap: wrap;
  margin-bottom: 16px;
  padding-bottom: 16px;
  border-bottom: 1px solid var(--re-border);
}
.tf-re-listing-meta-item {
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: .8rem;
  color: var(--re-muted);
}
.tf-re-listing-meta-item svg { width: 14px; height: 14px; color: var(--re-muted); }

.tf-re-listing-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}
.tf-re-listing-price {
  font-size: 1.25rem;
  font-weight: 800;
  color: var(--re-heading);
}
.tf-re-listing-price-meta {
  font-size: .72rem;
  font-weight: 400;
  color: var(--re-muted);
}
.tf-re-listing-btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: .8rem;
  font-weight: 700;
  color: var(--re-accent);
  border: 1px solid rgba(255,94,46,.35);
  border-radius: 8px;
  padding: 7px 14px;
  text-decoration: none;
  transition: background .2s, color .2s;
}
.tf-re-listing-btn:hover { background: var(--re-accent); color: #fff; }
.tf-re-listing-btn svg { width: 13px; height: 13px; }

@media (max-width: 1024px) {
  .tf-re-listings-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 640px) {
  .tf-re-listings-grid { grid-template-columns: 1fr; }
}

/* ══════════════════════════════════════════════════════════════════════
   4 · STATS BAR
   ══════════════════════════════════════════════════════════════════════ */
.tf-re-stats-section {
  background: linear-gradient(135deg, rgba(255,94,46,.12) 0%, rgba(59,130,246,.08) 100%),
              var(--re-bg-2);
  border-top: 1px solid var(--re-border);
  border-bottom: 1px solid var(--re-border);
  padding: 64px 0;
}
.tf-re-stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 24px;
  text-align: center;
}
.tf-re-stat-item {
  padding: 8px;
}
.tf-re-stat-num {
  font-size: clamp(2rem, 4vw, 3rem);
  font-weight: 900;
  color: var(--re-heading);
  line-height: 1;
  margin-bottom: 8px;
  display: block;
}
.tf-re-stat-num-suffix { color: var(--re-accent); }
.tf-re-stat-label {
  font-size: .9rem;
  color: var(--re-muted);
  font-weight: 500;
}
@media (max-width: 1024px) {
  .tf-re-stats-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 640px) {
  .tf-re-stats-grid { grid-template-columns: 1fr; }
}

/* ══════════════════════════════════════════════════════════════════════
   5 · WHY CHOOSE US
   ══════════════════════════════════════════════════════════════════════ */
.tf-re-why-section { background: var(--re-bg); }
.tf-re-why-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
}
.tf-re-why-card {
  background: var(--re-bg-2);
  border: 1px solid var(--re-border);
  border-radius: var(--re-r);
  padding: 36px 28px;
  transition: border-color .25s, transform .25s;
}
.tf-re-why-card:hover {
  border-color: rgba(255,94,46,.3);
  transform: translateY(-4px);
}
.tf-re-why-icon-box {
  width: 56px; height: 56px;
  border-radius: 14px;
  display: flex; align-items: center; justify-content: center;
  margin-bottom: 22px;
}
.tf-re-why-icon-box svg { width: 28px; height: 28px; }
.tf-re-why-icon-box--orange { background: rgba(255,94,46,.15); color: var(--re-accent); }
.tf-re-why-icon-box--blue   { background: rgba(59,130,246,.15); color: var(--re-blue); }
.tf-re-why-icon-box--green  { background: rgba(16,185,129,.15); color: var(--re-green); }
.tf-re-why-card h3 {
  font-size: 1.15rem;
  font-weight: 800;
  color: var(--re-heading);
  margin-bottom: 12px;
}
.tf-re-why-card p {
  font-size: .9rem;
  color: var(--re-muted);
  line-height: 1.72;
}
@media (max-width: 1024px) {
  .tf-re-why-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 640px) {
  .tf-re-why-grid { grid-template-columns: 1fr; }
}

/* ══════════════════════════════════════════════════════════════════════
   6 · AGENT SPOTLIGHT
   ══════════════════════════════════════════════════════════════════════ */
.tf-re-agents-section {
  background: var(--re-bg-2);
  border-top: 1px solid var(--re-border);
  border-bottom: 1px solid var(--re-border);
}
.tf-re-agents-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
}
.tf-re-agent-card {
  background: var(--re-bg-3);
  border: 1px solid var(--re-border);
  border-radius: var(--re-r);
  padding: 32px 24px;
  text-align: center;
  transition: border-color .25s, transform .25s, box-shadow .25s;
}
.tf-re-agent-card:hover {
  border-color: rgba(255,94,46,.3);
  transform: translateY(-5px);
  box-shadow: 0 16px 40px rgba(0,0,0,.35);
}
.tf-re-agent-avatar {
  width: 80px; height: 80px;
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto 16px;
  font-size: 1.6rem;
  font-weight: 900;
  color: #fff;
  letter-spacing: .02em;
  border: 3px solid var(--re-border);
}
.tf-re-agent-avatar--orange { background: linear-gradient(135deg, #ff5e2e, #ff8c5a); }
.tf-re-agent-avatar--blue   { background: linear-gradient(135deg, #2563eb, #60a5fa); }
.tf-re-agent-avatar--violet { background: linear-gradient(135deg, #7c3aed, #a78bfa); }

.tf-re-agent-name {
  font-size: 1.1rem;
  font-weight: 800;
  color: var(--re-heading);
  margin-bottom: 4px;
}
.tf-re-agent-title {
  font-size: .82rem;
  color: var(--re-muted);
  margin-bottom: 12px;
}
.tf-re-agent-specialty {
  display: inline-block;
  font-size: .7rem;
  font-weight: 700;
  letter-spacing: .07em;
  text-transform: uppercase;
  padding: 4px 12px;
  border-radius: 100px;
  background: rgba(255,94,46,.1);
  border: 1px solid rgba(255,94,46,.22);
  color: var(--re-accent);
  margin-bottom: 20px;
}
.tf-re-agent-stats {
  display: flex;
  justify-content: center;
  gap: 24px;
  margin-bottom: 20px;
  padding-bottom: 20px;
  border-bottom: 1px solid var(--re-border);
}
.tf-re-agent-stat { text-align: center; }
.tf-re-agent-stat-num {
  font-size: 1.25rem;
  font-weight: 800;
  color: var(--re-heading);
  display: block;
}
.tf-re-agent-stat-label {
  font-size: .72rem;
  color: var(--re-muted);
}
.tf-re-agent-contacts {
  display: flex;
  justify-content: center;
  gap: 10px;
}
.tf-re-agent-contact-btn {
  width: 36px; height: 36px;
  border-radius: 8px;
  background: rgba(255,255,255,.05);
  border: 1px solid var(--re-border);
  display: flex; align-items: center; justify-content: center;
  color: var(--re-muted);
  text-decoration: none;
  transition: background .2s, color .2s, border-color .2s;
}
.tf-re-agent-contact-btn svg { width: 15px; height: 15px; }
.tf-re-agent-contact-btn:hover {
  background: var(--re-accent);
  border-color: var(--re-accent);
  color: #fff;
}
@media (max-width: 1024px) {
  .tf-re-agents-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 640px) {
  .tf-re-agents-grid { grid-template-columns: 1fr; }
}

/* ══════════════════════════════════════════════════════════════════════
   7 · TESTIMONIALS
   ══════════════════════════════════════════════════════════════════════ */
.tf-re-testimonials-section { background: var(--re-bg); }
.tf-re-testimonials-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
}
.tf-re-testi-card {
  background: var(--re-bg-2);
  border: 1px solid var(--re-border);
  border-radius: var(--re-r);
  padding: 30px;
  display: flex;
  flex-direction: column;
}
.tf-re-testi-stars {
  display: flex;
  gap: 3px;
  margin-bottom: 16px;
  color: var(--re-amber);
}
.tf-re-testi-stars svg { width: 16px; height: 16px; }
.tf-re-testi-quote {
  font-size: .95rem;
  color: var(--re-text);
  line-height: 1.72;
  flex: 1;
  margin-bottom: 22px;
  font-style: italic;
}
.tf-re-testi-author {
  display: flex;
  align-items: center;
  gap: 12px;
}
.tf-re-testi-avatar {
  width: 44px; height: 44px;
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .88rem; font-weight: 800; color: #fff;
  flex-shrink: 0;
}
.tf-re-testi-avatar--a { background: linear-gradient(135deg, #ff5e2e, #ff8c5a); }
.tf-re-testi-avatar--b { background: linear-gradient(135deg, #2563eb, #60a5fa); }
.tf-re-testi-avatar--c { background: linear-gradient(135deg, #7c3aed, #a78bfa); }
.tf-re-testi-name {
  font-size: .92rem;
  font-weight: 700;
  color: var(--re-heading);
}
.tf-re-testi-meta {
  font-size: .78rem;
  color: var(--re-muted);
}
@media (max-width: 1024px) {
  .tf-re-testimonials-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 640px) {
  .tf-re-testimonials-grid { grid-template-columns: 1fr; }
}

/* ══════════════════════════════════════════════════════════════════════
   8 · CTA BANNER
   ══════════════════════════════════════════════════════════════════════ */
.tf-re-cta-section {
  padding: 96px 0;
  background:
    radial-gradient(ellipse 70% 80% at 15% 50%, rgba(255,94,46,.14) 0%, transparent 60%),
    radial-gradient(ellipse 50% 60% at 85% 50%, rgba(59,130,246,.1) 0%, transparent 60%),
    var(--re-bg-2);
  border-top: 1px solid var(--re-border);
}
.tf-re-cta-inner {
  text-align: center;
  max-width: 700px;
  margin: 0 auto;
}
.tf-re-cta-inner h2 {
  font-size: clamp(1.9rem, 3.5vw, 3rem);
  font-weight: 900;
  color: var(--re-heading);
  line-height: 1.15;
  margin-bottom: 16px;
}
.tf-re-cta-inner h2 span { color: var(--re-accent); }
.tf-re-cta-inner p {
  font-size: 1.05rem;
  color: var(--re-muted);
  line-height: 1.7;
  margin-bottom: 36px;
}
.tf-re-cta-btns {
  display: flex;
  flex-wrap: wrap;
  gap: 14px;
  justify-content: center;
  margin-bottom: 36px;
}
.tf-re-btn-primary {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: var(--re-accent);
  color: #fff;
  font-size: .95rem;
  font-weight: 700;
  padding: 14px 30px;
  border-radius: 10px;
  text-decoration: none;
  transition: background .2s, transform .2s, box-shadow .2s;
  box-shadow: 0 4px 20px rgba(255,94,46,.35);
}
.tf-re-btn-primary svg { width: 17px; height: 17px; }
.tf-re-btn-primary:hover {
  background: #e5501e;
  transform: translateY(-2px);
  box-shadow: 0 8px 28px rgba(255,94,46,.45);
}
.tf-re-btn-ghost {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: transparent;
  color: var(--re-text);
  font-size: .95rem;
  font-weight: 700;
  padding: 14px 30px;
  border-radius: 10px;
  border: 1px solid var(--re-border);
  text-decoration: none;
  transition: border-color .2s, color .2s, background .2s;
}
.tf-re-btn-ghost svg { width: 17px; height: 17px; }
.tf-re-btn-ghost:hover {
  border-color: var(--re-accent);
  color: var(--re-accent);
  background: rgba(255,94,46,.06);
}
.tf-re-cta-contact {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 24px;
}
.tf-re-cta-contact-item {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: .85rem;
  color: var(--re-muted);
  text-decoration: none;
  transition: color .2s;
}
.tf-re-cta-contact-item:hover { color: var(--re-text); }
.tf-re-cta-contact-item svg { width: 15px; height: 15px; color: var(--re-accent); flex-shrink: 0; }

</style>

<?php
/* ── Inline SVG icon helper shim ─────────────────────────────────────────
   Uses tf_icon_get() if available (ThemeFlex core loaded), otherwise falls
   back to a lightweight inline-SVG helper so the template is self-contained
   in unit-test / CLI environments.
   ─────────────────────────────────────────────────────────────────────── */
if ( ! function_exists( 'tf_icon_get' ) ) :
  /**
   * Minimal fallback — should never run in a live ThemeFlex install.
   *
   * @param string $name  Lucide icon slug.
   * @param int    $size  Width / height in px.
   * @return string SVG HTML.
   */
  function tf_icon_get( $name, $size = 20 ) { // phpcs:ignore
    $s = (int) $size;
    return '<svg xmlns="http://www.w3.org/2000/svg" width="' . $s . '" height="' . $s . '" '
         . 'viewBox="0 0 24 24" fill="none" stroke="currentColor" '
         . 'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" '
         . 'aria-hidden="true" class="tf-icon tf-icon--' . esc_attr( $name ) . '"><title>'
         . esc_html( $name ) . '</title></svg>';
  }
endif;
?>

<!-- ══════════════════════════════════════════════════════════════════════
     SECTION 1 · HERO
     ══════════════════════════════════════════════════════════════════════ -->
<section class="tf-re-hero" aria-labelledby="tf-re-hero-heading">
  <div class="tf-re-hero-orb-1" aria-hidden="true"></div>
  <div class="tf-re-hero-orb-2" aria-hidden="true"></div>

  <div class="tf-re-wrap tf-re-hero-inner">

    <!-- Trust badges -->
    <div class="tf-re-hero-badges" role="list">
      <span class="tf-re-hero-badge" role="listitem">
        <?php echo tf_icon_get( 'check-circle', 13 ); /* phpcs:ignore */ ?>
        <?php esc_html_e( 'Verified Listings', 'themeflex' ); ?>
      </span>
      <span class="tf-re-hero-badge" role="listitem">
        <?php echo tf_icon_get( 'users', 13 ); /* phpcs:ignore */ ?>
        <?php esc_html_e( 'Top Agents', 'themeflex' ); ?>
      </span>
      <span class="tf-re-hero-badge" role="listitem">
        <?php echo tf_icon_get( 'search', 13 ); /* phpcs:ignore */ ?>
        <?php esc_html_e( 'Smart Search', 'themeflex' ); ?>
      </span>
    </div>

    <!-- Headline -->
    <h1 class="tf-re-hero-headline" id="tf-re-hero-heading">
      <?php esc_html_e( 'Find Your', 'themeflex' ); ?>
      <span><?php esc_html_e( 'Perfect Home', 'themeflex' ); ?></span>
    </h1>
    <p class="tf-re-hero-sub">
      <?php esc_html_e( 'Browse thousands of verified properties across every neighbourhood. Whether you are buying, renting, or investing — we have your next move covered.', 'themeflex' ); ?>
    </p>

    <!-- Search bar mockup -->
    <div class="tf-re-search-bar" role="search" aria-label="<?php esc_attr_e( 'Property search', 'themeflex' ); ?>">
      <div class="tf-re-search-field">
        <span class="tf-re-search-label"><?php esc_html_e( 'Location', 'themeflex' ); ?></span>
        <span class="tf-re-search-value">
          <?php echo tf_icon_get( 'map-pin', 14 ); /* phpcs:ignore */ ?>
          <?php esc_html_e( 'City, postcode or area', 'themeflex' ); ?>
        </span>
      </div>
      <div class="tf-re-search-field">
        <span class="tf-re-search-label"><?php esc_html_e( 'Property Type', 'themeflex' ); ?></span>
        <span class="tf-re-search-value">
          <?php echo tf_icon_get( 'building-2', 14 ); /* phpcs:ignore */ ?>
          <?php esc_html_e( 'All property types', 'themeflex' ); ?>
        </span>
      </div>
      <div class="tf-re-search-field">
        <span class="tf-re-search-label"><?php esc_html_e( 'Price Range', 'themeflex' ); ?></span>
        <span class="tf-re-search-value">
          <?php echo tf_icon_get( 'sliders', 14 ); /* phpcs:ignore */ ?>
          <?php esc_html_e( 'Any price', 'themeflex' ); ?>
        </span>
      </div>
      <a href="<?php echo esc_url( home_url( '/listings' ) ); ?>" class="tf-re-search-btn" aria-label="<?php esc_attr_e( 'Search properties', 'themeflex' ); ?>">
        <?php echo tf_icon_get( 'search', 18 ); /* phpcs:ignore */ ?>
        <?php esc_html_e( 'Search', 'themeflex' ); ?>
      </a>
    </div>

    <!-- Floating stat cards -->
    <div class="tf-re-hero-stats" role="list">
      <div class="tf-re-hero-stat tf-re-reveal" role="listitem">
        <strong class="tf-re-hero-stat-num">
          2,400<span>+</span>
        </strong>
        <span class="tf-re-hero-stat-label"><?php esc_html_e( 'Active Listings', 'themeflex' ); ?></span>
      </div>
      <div class="tf-re-hero-stat tf-re-reveal" role="listitem" style="transition-delay:.1s">
        <strong class="tf-re-hero-stat-num">
          98<span>%</span>
        </strong>
        <span class="tf-re-hero-stat-label"><?php esc_html_e( 'Client Satisfaction', 'themeflex' ); ?></span>
      </div>
      <div class="tf-re-hero-stat tf-re-reveal" role="listitem" style="transition-delay:.2s">
        <strong class="tf-re-hero-stat-num">
          12<span>+</span>
        </strong>
        <span class="tf-re-hero-stat-label"><?php esc_html_e( 'Years Experience', 'themeflex' ); ?></span>
      </div>
    </div>

  </div><!-- /.tf-re-hero-inner -->
</section>


<!-- ══════════════════════════════════════════════════════════════════════
     SECTION 2 · PROPERTY TYPE TABS
     ══════════════════════════════════════════════════════════════════════ -->
<section class="tf-re-tabs-section" aria-labelledby="tf-re-tabs-heading">
  <div class="tf-re-wrap">

    <div class="tf-re-section-head tf-re-reveal">
      <span class="tf-re-eyebrow">
        <?php echo tf_icon_get( 'filter', 12 ); /* phpcs:ignore */ ?>
        <?php esc_html_e( 'Browse by Type', 'themeflex' ); ?>
      </span>
      <h2 id="tf-re-tabs-heading"><?php esc_html_e( 'What Are You Looking For?', 'themeflex' ); ?></h2>
      <p><?php esc_html_e( 'From cosy apartments to sprawling commercial spaces — filter your search by the type of property that suits your needs.', 'themeflex' ); ?></p>
    </div>

    <!-- Tab navigation -->
    <nav class="tf-re-tab-nav" aria-label="<?php esc_attr_e( 'Property filter tabs', 'themeflex' ); ?>" role="tablist">
      <button class="tf-re-tab-btn tf-re-tab-active" data-tab="all" role="tab" aria-selected="true">
        <?php esc_html_e( 'All', 'themeflex' ); ?>
      </button>
      <button class="tf-re-tab-btn" data-tab="buy" role="tab" aria-selected="false">
        <?php esc_html_e( 'Buy', 'themeflex' ); ?>
      </button>
      <button class="tf-re-tab-btn" data-tab="rent" role="tab" aria-selected="false">
        <?php esc_html_e( 'Rent', 'themeflex' ); ?>
      </button>
      <button class="tf-re-tab-btn" data-tab="commercial" role="tab" aria-selected="false">
        <?php esc_html_e( 'Commercial', 'themeflex' ); ?>
      </button>
      <button class="tf-re-tab-btn" data-tab="new-build" role="tab" aria-selected="false">
        <?php esc_html_e( 'New Build', 'themeflex' ); ?>
      </button>
    </nav>

    <!-- Property type cards -->
    <div class="tf-re-type-grid tf-re-reveal" role="tabpanel" aria-label="<?php esc_attr_e( 'Property types', 'themeflex' ); ?>">

      <div class="tf-re-type-card">
        <div class="tf-re-type-icon">
          <?php echo tf_icon_get( 'building-2', 26 ); /* phpcs:ignore */ ?>
        </div>
        <div class="tf-re-type-name"><?php esc_html_e( 'Apartments', 'themeflex' ); ?></div>
        <div class="tf-re-type-count"><?php esc_html_e( '842 listings', 'themeflex' ); ?></div>
      </div>

      <div class="tf-re-type-card">
        <div class="tf-re-type-icon">
          <?php echo tf_icon_get( 'home', 26 ); /* phpcs:ignore */ ?>
        </div>
        <div class="tf-re-type-name"><?php esc_html_e( 'Houses', 'themeflex' ); ?></div>
        <div class="tf-re-type-count"><?php esc_html_e( '1,124 listings', 'themeflex' ); ?></div>
      </div>

      <div class="tf-re-type-card">
        <div class="tf-re-type-icon">
          <?php echo tf_icon_get( 'warehouse', 26 ); /* phpcs:ignore */ ?>
        </div>
        <div class="tf-re-type-name"><?php esc_html_e( 'Villas', 'themeflex' ); ?></div>
        <div class="tf-re-type-count"><?php esc_html_e( '215 listings', 'themeflex' ); ?></div>
      </div>

      <div class="tf-re-type-card">
        <div class="tf-re-type-icon">
          <?php echo tf_icon_get( 'building', 26 ); /* phpcs:ignore */ ?>
        </div>
        <div class="tf-re-type-name"><?php esc_html_e( 'Commercial', 'themeflex' ); ?></div>
        <div class="tf-re-type-count"><?php esc_html_e( '319 listings', 'themeflex' ); ?></div>
      </div>

    </div><!-- /.tf-re-type-grid -->

  </div><!-- /.tf-re-wrap -->
</section>


<!-- ══════════════════════════════════════════════════════════════════════
     SECTION 3 · FEATURED LISTINGS GRID
     ══════════════════════════════════════════════════════════════════════ -->
<section class="tf-re-section tf-re-listings-section" aria-labelledby="tf-re-listings-heading">
  <div class="tf-re-wrap">

    <div class="tf-re-section-head tf-re-reveal">
      <span class="tf-re-eyebrow">
        <?php echo tf_icon_get( 'star', 12 ); /* phpcs:ignore */ ?>
        <?php esc_html_e( 'Featured Properties', 'themeflex' ); ?>
      </span>
      <h2 id="tf-re-listings-heading"><?php esc_html_e( 'Handpicked Listings', 'themeflex' ); ?></h2>
      <p><?php esc_html_e( 'Our experts curate the finest properties updated daily. Every listing is independently verified for accuracy and quality.', 'themeflex' ); ?></p>
    </div>

    <div class="tf-re-listings-grid">

      <!-- Card 1 — Apartment, For Sale, Blue -->
      <article class="tf-re-listing-card tf-re-reveal" aria-label="<?php esc_attr_e( 'Skyline Residences listing', 'themeflex' ); ?>">
        <div class="tf-re-listing-img tf-re-listing-img--blue">
          <div class="tf-re-listing-badges">
            <span class="tf-re-badge tf-re-badge--sale"><?php esc_html_e( 'For Sale', 'themeflex' ); ?></span>
          </div>
          <?php echo tf_icon_get( 'building-2', 52 ); /* phpcs:ignore */ ?>
        </div>
        <div class="tf-re-listing-body">
          <h3 class="tf-re-listing-name"><?php esc_html_e( 'Skyline Residences', 'themeflex' ); ?></h3>
          <div class="tf-re-listing-loc">
            <?php echo tf_icon_get( 'map-pin', 13 ); /* phpcs:ignore */ ?>
            <?php esc_html_e( 'Mitte, Berlin', 'themeflex' ); ?>
          </div>
          <div class="tf-re-listing-meta">
            <span class="tf-re-listing-meta-item">
              <?php echo tf_icon_get( 'bed', 14 ); /* phpcs:ignore */ ?>
              3 <?php esc_html_e( 'Beds', 'themeflex' ); ?>
            </span>
            <span class="tf-re-listing-meta-item">
              <?php echo tf_icon_get( 'bath', 14 ); /* phpcs:ignore */ ?>
              2 <?php esc_html_e( 'Baths', 'themeflex' ); ?>
            </span>
            <span class="tf-re-listing-meta-item">
              <?php echo tf_icon_get( 'maximize', 14 ); /* phpcs:ignore */ ?>
              118 m&sup2;
            </span>
          </div>
          <div class="tf-re-listing-footer">
            <div>
              <div class="tf-re-listing-price">&euro;485,000</div>
            </div>
            <a href="<?php echo esc_url( home_url( '/listings/skyline-residences' ) ); ?>" class="tf-re-listing-btn">
              <?php esc_html_e( 'View Details', 'themeflex' ); ?>
              <?php echo tf_icon_get( 'arrow-right', 13 ); /* phpcs:ignore */ ?>
            </a>
          </div>
        </div>
      </article>

      <!-- Card 2 — House, For Sale, Green -->
      <article class="tf-re-listing-card tf-re-reveal" style="transition-delay:.08s" aria-label="<?php esc_attr_e( 'Garden Gate Villa listing', 'themeflex' ); ?>">
        <div class="tf-re-listing-img tf-re-listing-img--green">
          <div class="tf-re-listing-badges">
            <span class="tf-re-badge tf-re-badge--sale"><?php esc_html_e( 'For Sale', 'themeflex' ); ?></span>
            <span class="tf-re-badge tf-re-badge--new"><?php esc_html_e( 'New', 'themeflex' ); ?></span>
          </div>
          <?php echo tf_icon_get( 'home', 52 ); /* phpcs:ignore */ ?>
        </div>
        <div class="tf-re-listing-body">
          <h3 class="tf-re-listing-name"><?php esc_html_e( 'Garden Gate Villa', 'themeflex' ); ?></h3>
          <div class="tf-re-listing-loc">
            <?php echo tf_icon_get( 'map-pin', 13 ); /* phpcs:ignore */ ?>
            <?php esc_html_e( 'Pankow, Berlin', 'themeflex' ); ?>
          </div>
          <div class="tf-re-listing-meta">
            <span class="tf-re-listing-meta-item">
              <?php echo tf_icon_get( 'bed', 14 ); /* phpcs:ignore */ ?>
              5 <?php esc_html_e( 'Beds', 'themeflex' ); ?>
            </span>
            <span class="tf-re-listing-meta-item">
              <?php echo tf_icon_get( 'bath', 14 ); /* phpcs:ignore */ ?>
              3 <?php esc_html_e( 'Baths', 'themeflex' ); ?>
            </span>
            <span class="tf-re-listing-meta-item">
              <?php echo tf_icon_get( 'maximize', 14 ); /* phpcs:ignore */ ?>
              240 m&sup2;
            </span>
          </div>
          <div class="tf-re-listing-footer">
            <div>
              <div class="tf-re-listing-price">&euro;1,250,000</div>
            </div>
            <a href="<?php echo esc_url( home_url( '/listings/garden-gate-villa' ) ); ?>" class="tf-re-listing-btn">
              <?php esc_html_e( 'View Details', 'themeflex' ); ?>
              <?php echo tf_icon_get( 'arrow-right', 13 ); /* phpcs:ignore */ ?>
            </a>
          </div>
        </div>
      </article>

      <!-- Card 3 — Warehouse / Loft, For Rent, Amber -->
      <article class="tf-re-listing-card tf-re-reveal" style="transition-delay:.16s" aria-label="<?php esc_attr_e( 'Urban Loft Studio listing', 'themeflex' ); ?>">
        <div class="tf-re-listing-img tf-re-listing-img--amber">
          <div class="tf-re-listing-badges">
            <span class="tf-re-badge tf-re-badge--rent"><?php esc_html_e( 'For Rent', 'themeflex' ); ?></span>
          </div>
          <?php echo tf_icon_get( 'warehouse', 52 ); /* phpcs:ignore */ ?>
        </div>
        <div class="tf-re-listing-body">
          <h3 class="tf-re-listing-name"><?php esc_html_e( 'Urban Loft Studio', 'themeflex' ); ?></h3>
          <div class="tf-re-listing-loc">
            <?php echo tf_icon_get( 'map-pin', 13 ); /* phpcs:ignore */ ?>
            <?php esc_html_e( 'Kreuzberg, Berlin', 'themeflex' ); ?>
          </div>
          <div class="tf-re-listing-meta">
            <span class="tf-re-listing-meta-item">
              <?php echo tf_icon_get( 'bed', 14 ); /* phpcs:ignore */ ?>
              1 <?php esc_html_e( 'Bed', 'themeflex' ); ?>
            </span>
            <span class="tf-re-listing-meta-item">
              <?php echo tf_icon_get( 'bath', 14 ); /* phpcs:ignore */ ?>
              1 <?php esc_html_e( 'Bath', 'themeflex' ); ?>
            </span>
            <span class="tf-re-listing-meta-item">
              <?php echo tf_icon_get( 'maximize', 14 ); /* phpcs:ignore */ ?>
              68 m&sup2;
            </span>
          </div>
          <div class="tf-re-listing-footer">
            <div>
              <div class="tf-re-listing-price">
                &euro;1,490
                <span class="tf-re-listing-price-meta"><?php esc_html_e( '/ month', 'themeflex' ); ?></span>
              </div>
            </div>
            <a href="<?php echo esc_url( home_url( '/listings/urban-loft-studio' ) ); ?>" class="tf-re-listing-btn">
              <?php esc_html_e( 'View Details', 'themeflex' ); ?>
              <?php echo tf_icon_get( 'arrow-right', 13 ); /* phpcs:ignore */ ?>
            </a>
          </div>
        </div>
      </article>

      <!-- Card 4 — Office / Commercial, For Sale, Violet -->
      <article class="tf-re-listing-card tf-re-reveal" style="transition-delay:.24s" aria-label="<?php esc_attr_e( 'Riverside Office Suite listing', 'themeflex' ); ?>">
        <div class="tf-re-listing-img tf-re-listing-img--violet">
          <div class="tf-re-listing-badges">
            <span class="tf-re-badge tf-re-badge--sale"><?php esc_html_e( 'For Sale', 'themeflex' ); ?></span>
          </div>
          <?php echo tf_icon_get( 'building', 52 ); /* phpcs:ignore */ ?>
        </div>
        <div class="tf-re-listing-body">
          <h3 class="tf-re-listing-name"><?php esc_html_e( 'Riverside Office Suite', 'themeflex' ); ?></h3>
          <div class="tf-re-listing-loc">
            <?php echo tf_icon_get( 'map-pin', 13 ); /* phpcs:ignore */ ?>
            <?php esc_html_e( 'Mitte, Hamburg', 'themeflex' ); ?>
          </div>
          <div class="tf-re-listing-meta">
            <span class="tf-re-listing-meta-item">
              <?php echo tf_icon_get( 'bed', 14 ); /* phpcs:ignore */ ?>
              6 <?php esc_html_e( 'Rooms', 'themeflex' ); ?>
            </span>
            <span class="tf-re-listing-meta-item">
              <?php echo tf_icon_get( 'bath', 14 ); /* phpcs:ignore */ ?>
              2 <?php esc_html_e( 'Baths', 'themeflex' ); ?>
            </span>
            <span class="tf-re-listing-meta-item">
              <?php echo tf_icon_get( 'maximize', 14 ); /* phpcs:ignore */ ?>
              320 m&sup2;
            </span>
          </div>
          <div class="tf-re-listing-footer">
            <div>
              <div class="tf-re-listing-price">&euro;2,100,000</div>
            </div>
            <a href="<?php echo esc_url( home_url( '/listings/riverside-office-suite' ) ); ?>" class="tf-re-listing-btn">
              <?php esc_html_e( 'View Details', 'themeflex' ); ?>
              <?php echo tf_icon_get( 'arrow-right', 13 ); /* phpcs:ignore */ ?>
            </a>
          </div>
        </div>
      </article>

      <!-- Card 5 — Castle / Luxury, For Sale, Teal -->
      <article class="tf-re-listing-card tf-re-reveal" style="transition-delay:.32s" aria-label="<?php esc_attr_e( 'Lakeside Manor listing', 'themeflex' ); ?>">
        <div class="tf-re-listing-img tf-re-listing-img--teal">
          <div class="tf-re-listing-badges">
            <span class="tf-re-badge tf-re-badge--sale"><?php esc_html_e( 'For Sale', 'themeflex' ); ?></span>
            <span class="tf-re-badge tf-re-badge--new"><?php esc_html_e( 'New', 'themeflex' ); ?></span>
          </div>
          <?php echo tf_icon_get( 'building-2', 52 ); /* phpcs:ignore */ ?>
        </div>
        <div class="tf-re-listing-body">
          <h3 class="tf-re-listing-name"><?php esc_html_e( 'Lakeside Manor', 'themeflex' ); ?></h3>
          <div class="tf-re-listing-loc">
            <?php echo tf_icon_get( 'map-pin', 13 ); /* phpcs:ignore */ ?>
            <?php esc_html_e( 'Wannsee, Berlin', 'themeflex' ); ?>
          </div>
          <div class="tf-re-listing-meta">
            <span class="tf-re-listing-meta-item">
              <?php echo tf_icon_get( 'bed', 14 ); /* phpcs:ignore */ ?>
              8 <?php esc_html_e( 'Beds', 'themeflex' ); ?>
            </span>
            <span class="tf-re-listing-meta-item">
              <?php echo tf_icon_get( 'bath', 14 ); /* phpcs:ignore */ ?>
              5 <?php esc_html_e( 'Baths', 'themeflex' ); ?>
            </span>
            <span class="tf-re-listing-meta-item">
              <?php echo tf_icon_get( 'maximize', 14 ); /* phpcs:ignore */ ?>
              640 m&sup2;
            </span>
          </div>
          <div class="tf-re-listing-footer">
            <div>
              <div class="tf-re-listing-price">&euro;5,800,000</div>
            </div>
            <a href="<?php echo esc_url( home_url( '/listings/lakeside-manor' ) ); ?>" class="tf-re-listing-btn">
              <?php esc_html_e( 'View Details', 'themeflex' ); ?>
              <?php echo tf_icon_get( 'arrow-right', 13 ); /* phpcs:ignore */ ?>
            </a>
          </div>
        </div>
      </article>

      <!-- Card 6 — Retail / Shop, For Rent, Rose -->
      <article class="tf-re-listing-card tf-re-reveal" style="transition-delay:.4s" aria-label="<?php esc_attr_e( 'City Retail Storefront listing', 'themeflex' ); ?>">
        <div class="tf-re-listing-img tf-re-listing-img--rose">
          <div class="tf-re-listing-badges">
            <span class="tf-re-badge tf-re-badge--rent"><?php esc_html_e( 'For Rent', 'themeflex' ); ?></span>
          </div>
          <?php echo tf_icon_get( 'building', 52 ); /* phpcs:ignore */ ?>
        </div>
        <div class="tf-re-listing-body">
          <h3 class="tf-re-listing-name"><?php esc_html_e( 'City Retail Storefront', 'themeflex' ); ?></h3>
          <div class="tf-re-listing-loc">
            <?php echo tf_icon_get( 'map-pin', 13 ); /* phpcs:ignore */ ?>
            <?php esc_html_e( 'Friedrichshain, Berlin', 'themeflex' ); ?>
          </div>
          <div class="tf-re-listing-meta">
            <span class="tf-re-listing-meta-item">
              <?php echo tf_icon_get( 'bed', 14 ); /* phpcs:ignore */ ?>
              2 <?php esc_html_e( 'Rooms', 'themeflex' ); ?>
            </span>
            <span class="tf-re-listing-meta-item">
              <?php echo tf_icon_get( 'bath', 14 ); /* phpcs:ignore */ ?>
              1 <?php esc_html_e( 'Bath', 'themeflex' ); ?>
            </span>
            <span class="tf-re-listing-meta-item">
              <?php echo tf_icon_get( 'maximize', 14 ); /* phpcs:ignore */ ?>
              95 m&sup2;
            </span>
          </div>
          <div class="tf-re-listing-footer">
            <div>
              <div class="tf-re-listing-price">
                &euro;3,200
                <span class="tf-re-listing-price-meta"><?php esc_html_e( '/ month', 'themeflex' ); ?></span>
              </div>
            </div>
            <a href="<?php echo esc_url( home_url( '/listings/city-retail-storefront' ) ); ?>" class="tf-re-listing-btn">
              <?php esc_html_e( 'View Details', 'themeflex' ); ?>
              <?php echo tf_icon_get( 'arrow-right', 13 ); /* phpcs:ignore */ ?>
            </a>
          </div>
        </div>
      </article>

    </div><!-- /.tf-re-listings-grid -->

    <div style="text-align:center;margin-top:44px;" class="tf-re-reveal">
      <a href="<?php echo esc_url( home_url( '/listings' ) ); ?>" class="tf-re-btn-primary">
        <?php esc_html_e( 'View All Listings', 'themeflex' ); ?>
        <?php echo tf_icon_get( 'arrow-right', 17 ); /* phpcs:ignore */ ?>
      </a>
    </div>

  </div><!-- /.tf-re-wrap -->
</section>


<!-- ══════════════════════════════════════════════════════════════════════
     SECTION 4 · STATS BAR
     ══════════════════════════════════════════════════════════════════════ -->
<section class="tf-re-stats-section" aria-labelledby="tf-re-stats-heading">
  <div class="tf-re-wrap">
    <h2 id="tf-re-stats-heading" class="screen-reader-text"><?php esc_html_e( 'Key Statistics', 'themeflex' ); ?></h2>
    <div class="tf-re-stats-grid tf-re-reveal" id="tf-re-stats-grid">

      <div class="tf-re-stat-item">
        <span class="tf-re-stat-num" data-counter="2400">
          0<span class="tf-re-stat-num-suffix">+</span>
        </span>
        <span class="tf-re-stat-label"><?php esc_html_e( 'Properties Listed', 'themeflex' ); ?></span>
      </div>

      <div class="tf-re-stat-item">
        <span class="tf-re-stat-num" data-counter="1200">
          0<span class="tf-re-stat-num-suffix">+</span>
        </span>
        <span class="tf-re-stat-label"><?php esc_html_e( 'Happy Clients', 'themeflex' ); ?></span>
      </div>

      <div class="tf-re-stat-item">
        <span class="tf-re-stat-num" data-counter="850">
          0<span class="tf-re-stat-num-suffix">+</span>
        </span>
        <span class="tf-re-stat-label"><?php esc_html_e( 'Deals Closed', 'themeflex' ); ?></span>
      </div>

      <div class="tf-re-stat-item">
        <span class="tf-re-stat-num" data-counter="15">
          0<span class="tf-re-stat-num-suffix">+</span>
        </span>
        <span class="tf-re-stat-label"><?php esc_html_e( 'Years of Excellence', 'themeflex' ); ?></span>
      </div>

    </div>
  </div><!-- /.tf-re-wrap -->
</section>


<!-- ══════════════════════════════════════════════════════════════════════
     SECTION 5 · WHY CHOOSE US
     ══════════════════════════════════════════════════════════════════════ -->
<section class="tf-re-section tf-re-why-section" aria-labelledby="tf-re-why-heading">
  <div class="tf-re-wrap">

    <div class="tf-re-section-head tf-re-reveal">
      <span class="tf-re-eyebrow">
        <?php echo tf_icon_get( 'check-circle', 12 ); /* phpcs:ignore */ ?>
        <?php esc_html_e( 'Why Choose Us', 'themeflex' ); ?>
      </span>
      <h2 id="tf-re-why-heading"><?php esc_html_e( 'The Smarter Way to Buy & Rent', 'themeflex' ); ?></h2>
      <p><?php esc_html_e( 'We combine local expertise with cutting-edge technology to deliver a seamless property experience from first search to final signature.', 'themeflex' ); ?></p>
    </div>

    <div class="tf-re-why-grid">

      <!-- Feature 1 -->
      <div class="tf-re-why-card tf-re-reveal">
        <div class="tf-re-why-icon-box tf-re-why-icon-box--orange">
          <?php echo tf_icon_get( 'users', 28 ); /* phpcs:ignore */ ?>
        </div>
        <h3><?php esc_html_e( 'Expert Agents', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'Our licensed agents bring deep local knowledge and a client-first approach to every transaction. You will always have a dedicated specialist by your side.', 'themeflex' ); ?></p>
      </div>

      <!-- Feature 2 -->
      <div class="tf-re-why-card tf-re-reveal" style="transition-delay:.1s">
        <div class="tf-re-why-icon-box tf-re-why-icon-box--blue">
          <?php echo tf_icon_get( 'shield-check', 28 ); /* phpcs:ignore */ ?>
        </div>
        <h3><?php esc_html_e( 'Verified Properties', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'Every listing undergoes a rigorous multi-point verification process. No ghost listings, no outdated prices — only accurate, trustworthy property data.', 'themeflex' ); ?></p>
      </div>

      <!-- Feature 3 -->
      <div class="tf-re-why-card tf-re-reveal" style="transition-delay:.2s">
        <div class="tf-re-why-icon-box tf-re-why-icon-box--green">
          <?php echo tf_icon_get( 'badge-percent', 28 ); /* phpcs:ignore */ ?>
        </div>
        <h3><?php esc_html_e( 'Best Price Guarantee', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'We leverage real-time market data and our negotiation expertise to ensure you always pay — or receive — the fairest price on the market.', 'themeflex' ); ?></p>
      </div>

    </div><!-- /.tf-re-why-grid -->

  </div><!-- /.tf-re-wrap -->
</section>


<!-- ══════════════════════════════════════════════════════════════════════
     SECTION 6 · AGENT SPOTLIGHT
     ══════════════════════════════════════════════════════════════════════ -->
<section class="tf-re-section tf-re-agents-section" aria-labelledby="tf-re-agents-heading">
  <div class="tf-re-wrap">

    <div class="tf-re-section-head tf-re-reveal">
      <span class="tf-re-eyebrow">
        <?php echo tf_icon_get( 'users', 12 ); /* phpcs:ignore */ ?>
        <?php esc_html_e( 'Meet the Team', 'themeflex' ); ?>
      </span>
      <h2 id="tf-re-agents-heading"><?php esc_html_e( 'Our Top Agents', 'themeflex' ); ?></h2>
      <p><?php esc_html_e( 'Experienced, certified, and passionate about property — our agents are ready to guide you to the right decision.', 'themeflex' ); ?></p>
    </div>

    <div class="tf-re-agents-grid">

      <!-- Agent 1 -->
      <div class="tf-re-agent-card tf-re-reveal">
        <div class="tf-re-agent-avatar tf-re-agent-avatar--orange" aria-hidden="true">SM</div>
        <div class="tf-re-agent-name"><?php esc_html_e( 'Sophie Müller', 'themeflex' ); ?></div>
        <div class="tf-re-agent-title"><?php esc_html_e( 'Senior Property Consultant', 'themeflex' ); ?></div>
        <span class="tf-re-agent-specialty"><?php esc_html_e( 'Luxury Residential', 'themeflex' ); ?></span>
        <div class="tf-re-agent-stats">
          <div class="tf-re-agent-stat">
            <span class="tf-re-agent-stat-num">142</span>
            <span class="tf-re-agent-stat-label"><?php esc_html_e( 'Deals Closed', 'themeflex' ); ?></span>
          </div>
          <div class="tf-re-agent-stat">
            <span class="tf-re-agent-stat-num">8</span>
            <span class="tf-re-agent-stat-label"><?php esc_html_e( 'Years Exp.', 'themeflex' ); ?></span>
          </div>
        </div>
        <div class="tf-re-agent-contacts">
          <a href="tel:+4930123456" class="tf-re-agent-contact-btn" aria-label="<?php esc_attr_e( 'Call Sophie Müller', 'themeflex' ); ?>">
            <?php echo tf_icon_get( 'phone', 15 ); /* phpcs:ignore */ ?>
          </a>
          <a href="mailto:sophie@example.com" class="tf-re-agent-contact-btn" aria-label="<?php esc_attr_e( 'Email Sophie Müller', 'themeflex' ); ?>">
            <?php echo tf_icon_get( 'mail', 15 ); /* phpcs:ignore */ ?>
          </a>
          <a href="<?php echo esc_url( 'https://linkedin.com' ); ?>" class="tf-re-agent-contact-btn" aria-label="<?php esc_attr_e( 'LinkedIn profile of Sophie Müller', 'themeflex' ); ?>" target="_blank" rel="noopener noreferrer">
            <?php echo tf_icon_get( 'linkedin', 15 ); /* phpcs:ignore */ ?>
          </a>
        </div>
      </div>

      <!-- Agent 2 -->
      <div class="tf-re-agent-card tf-re-reveal" style="transition-delay:.1s">
        <div class="tf-re-agent-avatar tf-re-agent-avatar--blue" aria-hidden="true">TK</div>
        <div class="tf-re-agent-name"><?php esc_html_e( 'Thomas Klein', 'themeflex' ); ?></div>
        <div class="tf-re-agent-title"><?php esc_html_e( 'Commercial Property Specialist', 'themeflex' ); ?></div>
        <span class="tf-re-agent-specialty"><?php esc_html_e( 'Commercial & Office', 'themeflex' ); ?></span>
        <div class="tf-re-agent-stats">
          <div class="tf-re-agent-stat">
            <span class="tf-re-agent-stat-num">87</span>
            <span class="tf-re-agent-stat-label"><?php esc_html_e( 'Deals Closed', 'themeflex' ); ?></span>
          </div>
          <div class="tf-re-agent-stat">
            <span class="tf-re-agent-stat-num">5</span>
            <span class="tf-re-agent-stat-label"><?php esc_html_e( 'Years Exp.', 'themeflex' ); ?></span>
          </div>
        </div>
        <div class="tf-re-agent-contacts">
          <a href="tel:+4930789012" class="tf-re-agent-contact-btn" aria-label="<?php esc_attr_e( 'Call Thomas Klein', 'themeflex' ); ?>">
            <?php echo tf_icon_get( 'phone', 15 ); /* phpcs:ignore */ ?>
          </a>
          <a href="mailto:thomas@example.com" class="tf-re-agent-contact-btn" aria-label="<?php esc_attr_e( 'Email Thomas Klein', 'themeflex' ); ?>">
            <?php echo tf_icon_get( 'mail', 15 ); /* phpcs:ignore */ ?>
          </a>
          <a href="<?php echo esc_url( 'https://linkedin.com' ); ?>" class="tf-re-agent-contact-btn" aria-label="<?php esc_attr_e( 'LinkedIn profile of Thomas Klein', 'themeflex' ); ?>" target="_blank" rel="noopener noreferrer">
            <?php echo tf_icon_get( 'linkedin', 15 ); /* phpcs:ignore */ ?>
          </a>
        </div>
      </div>

      <!-- Agent 3 -->
      <div class="tf-re-agent-card tf-re-reveal" style="transition-delay:.2s">
        <div class="tf-re-agent-avatar tf-re-agent-avatar--violet" aria-hidden="true">AW</div>
        <div class="tf-re-agent-name"><?php esc_html_e( 'Anna Weber', 'themeflex' ); ?></div>
        <div class="tf-re-agent-title"><?php esc_html_e( 'Residential Letting Agent', 'themeflex' ); ?></div>
        <span class="tf-re-agent-specialty"><?php esc_html_e( 'Apartments & Rentals', 'themeflex' ); ?></span>
        <div class="tf-re-agent-stats">
          <div class="tf-re-agent-stat">
            <span class="tf-re-agent-stat-num">214</span>
            <span class="tf-re-agent-stat-label"><?php esc_html_e( 'Deals Closed', 'themeflex' ); ?></span>
          </div>
          <div class="tf-re-agent-stat">
            <span class="tf-re-agent-stat-num">11</span>
            <span class="tf-re-agent-stat-label"><?php esc_html_e( 'Years Exp.', 'themeflex' ); ?></span>
          </div>
        </div>
        <div class="tf-re-agent-contacts">
          <a href="tel:+4930345678" class="tf-re-agent-contact-btn" aria-label="<?php esc_attr_e( 'Call Anna Weber', 'themeflex' ); ?>">
            <?php echo tf_icon_get( 'phone', 15 ); /* phpcs:ignore */ ?>
          </a>
          <a href="mailto:anna@example.com" class="tf-re-agent-contact-btn" aria-label="<?php esc_attr_e( 'Email Anna Weber', 'themeflex' ); ?>">
            <?php echo tf_icon_get( 'mail', 15 ); /* phpcs:ignore */ ?>
          </a>
          <a href="<?php echo esc_url( 'https://linkedin.com' ); ?>" class="tf-re-agent-contact-btn" aria-label="<?php esc_attr_e( 'LinkedIn profile of Anna Weber', 'themeflex' ); ?>" target="_blank" rel="noopener noreferrer">
            <?php echo tf_icon_get( 'linkedin', 15 ); /* phpcs:ignore */ ?>
          </a>
        </div>
      </div>

    </div><!-- /.tf-re-agents-grid -->

    <div style="text-align:center;margin-top:44px;" class="tf-re-reveal">
      <a href="<?php echo esc_url( home_url( '/agents' ) ); ?>" class="tf-re-btn-ghost">
        <?php esc_html_e( 'Meet All Agents', 'themeflex' ); ?>
        <?php echo tf_icon_get( 'arrow-right', 17 ); /* phpcs:ignore */ ?>
      </a>
    </div>

  </div><!-- /.tf-re-wrap -->
</section>


<!-- ══════════════════════════════════════════════════════════════════════
     SECTION 7 · TESTIMONIALS
     ══════════════════════════════════════════════════════════════════════ -->
<section class="tf-re-section tf-re-testimonials-section" aria-labelledby="tf-re-testimonials-heading">
  <div class="tf-re-wrap">

    <div class="tf-re-section-head tf-re-reveal">
      <span class="tf-re-eyebrow">
        <?php echo tf_icon_get( 'star', 12 ); /* phpcs:ignore */ ?>
        <?php esc_html_e( 'Client Reviews', 'themeflex' ); ?>
      </span>
      <h2 id="tf-re-testimonials-heading"><?php esc_html_e( 'What Our Clients Say', 'themeflex' ); ?></h2>
      <p><?php esc_html_e( 'Real stories from real people who found their dream home with our help. We measure success by the smiles of our clients.', 'themeflex' ); ?></p>
    </div>

    <div class="tf-re-testimonials-grid">

      <!-- Testimonial 1 -->
      <blockquote class="tf-re-testi-card tf-re-reveal">
        <div class="tf-re-testi-stars" aria-label="<?php esc_attr_e( '5 out of 5 stars', 'themeflex' ); ?>">
          <?php echo tf_icon_get( 'star', 16 ); /* phpcs:ignore */ ?>
          <?php echo tf_icon_get( 'star', 16 ); /* phpcs:ignore */ ?>
          <?php echo tf_icon_get( 'star', 16 ); /* phpcs:ignore */ ?>
          <?php echo tf_icon_get( 'star', 16 ); /* phpcs:ignore */ ?>
          <?php echo tf_icon_get( 'star', 16 ); /* phpcs:ignore */ ?>
        </div>
        <p class="tf-re-testi-quote">
          <?php esc_html_e( '"Sophie was absolutely brilliant. She understood exactly what we were looking for and found us our dream apartment in under three weeks. The whole process felt effortless."', 'themeflex' ); ?>
        </p>
        <footer class="tf-re-testi-author">
          <div class="tf-re-testi-avatar tf-re-testi-avatar--a" aria-hidden="true">MR</div>
          <div>
            <div class="tf-re-testi-name"><?php esc_html_e( 'Markus Richter', 'themeflex' ); ?></div>
            <div class="tf-re-testi-meta"><?php esc_html_e( 'Bought in Berlin-Mitte', 'themeflex' ); ?></div>
          </div>
        </footer>
      </blockquote>

      <!-- Testimonial 2 -->
      <blockquote class="tf-re-testi-card tf-re-reveal" style="transition-delay:.12s">
        <div class="tf-re-testi-stars" aria-label="<?php esc_attr_e( '5 out of 5 stars', 'themeflex' ); ?>">
          <?php echo tf_icon_get( 'star', 16 ); /* phpcs:ignore */ ?>
          <?php echo tf_icon_get( 'star', 16 ); /* phpcs:ignore */ ?>
          <?php echo tf_icon_get( 'star', 16 ); /* phpcs:ignore */ ?>
          <?php echo tf_icon_get( 'star', 16 ); /* phpcs:ignore */ ?>
          <?php echo tf_icon_get( 'star', 16 ); /* phpcs:ignore */ ?>
        </div>
        <p class="tf-re-testi-quote">
          <?php esc_html_e( '"Thomas helped us lease our new office space at below-market rates. His knowledge of the commercial sector is unmatched and his communication was transparent throughout."', 'themeflex' ); ?>
        </p>
        <footer class="tf-re-testi-author">
          <div class="tf-re-testi-avatar tf-re-testi-avatar--b" aria-hidden="true">JL</div>
          <div>
            <div class="tf-re-testi-name"><?php esc_html_e( 'Jana Lehmann', 'themeflex' ); ?></div>
            <div class="tf-re-testi-meta"><?php esc_html_e( 'Leased office in Hamburg', 'themeflex' ); ?></div>
          </div>
        </footer>
      </blockquote>

      <!-- Testimonial 3 -->
      <blockquote class="tf-re-testi-card tf-re-reveal" style="transition-delay:.24s">
        <div class="tf-re-testi-stars" aria-label="<?php esc_attr_e( '5 out of 5 stars', 'themeflex' ); ?>">
          <?php echo tf_icon_get( 'star', 16 ); /* phpcs:ignore */ ?>
          <?php echo tf_icon_get( 'star', 16 ); /* phpcs:ignore */ ?>
          <?php echo tf_icon_get( 'star', 16 ); /* phpcs:ignore */ ?>
          <?php echo tf_icon_get( 'star', 16 ); /* phpcs:ignore */ ?>
          <?php echo tf_icon_get( 'star', 16 ); /* phpcs:ignore */ ?>
        </div>
        <p class="tf-re-testi-quote">
          <?php esc_html_e( '"As a first-time buyer I was nervous, but Anna made everything clear and stress-free. The verified listings saved me hours of wasted viewings. Highly recommended!"', 'themeflex' ); ?>
        </p>
        <footer class="tf-re-testi-author">
          <div class="tf-re-testi-avatar tf-re-testi-avatar--c" aria-hidden="true">FH</div>
          <div>
            <div class="tf-re-testi-name"><?php esc_html_e( 'Felix Hoffmann', 'themeflex' ); ?></div>
            <div class="tf-re-testi-meta"><?php esc_html_e( 'Rented in Kreuzberg', 'themeflex' ); ?></div>
          </div>
        </footer>
      </blockquote>

    </div><!-- /.tf-re-testimonials-grid -->

  </div><!-- /.tf-re-wrap -->
</section>


<!-- ══════════════════════════════════════════════════════════════════════
     SECTION 8 · CTA BANNER
     ══════════════════════════════════════════════════════════════════════ -->
<section class="tf-re-cta-section" aria-labelledby="tf-re-cta-heading">
  <div class="tf-re-wrap">
    <div class="tf-re-cta-inner tf-re-reveal">

      <span class="tf-re-eyebrow" style="justify-content:center;">
        <?php echo tf_icon_get( 'arrow-right', 12 ); /* phpcs:ignore */ ?>
        <?php esc_html_e( 'Get Started Today', 'themeflex' ); ?>
      </span>

      <h2 id="tf-re-cta-heading">
        <?php esc_html_e( 'Ready to Find Your', 'themeflex' ); ?>
        <span><?php esc_html_e( 'Dream Home?', 'themeflex' ); ?></span>
      </h2>

      <p>
        <?php esc_html_e( 'Join thousands of happy clients who found their perfect property with us. Browse our latest listings or speak directly with one of our expert agents today.', 'themeflex' ); ?>
      </p>

      <div class="tf-re-cta-btns">
        <a href="<?php echo esc_url( home_url( '/listings' ) ); ?>" class="tf-re-btn-primary">
          <?php esc_html_e( 'Browse Listings', 'themeflex' ); ?>
          <?php echo tf_icon_get( 'arrow-right', 17 ); /* phpcs:ignore */ ?>
        </a>
        <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>" class="tf-re-btn-ghost">
          <?php esc_html_e( 'Talk to an Agent', 'themeflex' ); ?>
          <?php echo tf_icon_get( 'users', 17 ); /* phpcs:ignore */ ?>
        </a>
      </div>

      <!-- Contact strip -->
      <div class="tf-re-cta-contact">
        <a href="tel:+493012345678" class="tf-re-cta-contact-item">
          <?php echo tf_icon_get( 'phone', 15 ); /* phpcs:ignore */ ?>
          <span>+49 30 123 456 78</span>
        </a>
        <a href="mailto:hello@themeflex.de" class="tf-re-cta-contact-item">
          <?php echo tf_icon_get( 'mail', 15 ); /* phpcs:ignore */ ?>
          <span>hello@themeflex.de</span>
        </a>
      </div>

    </div><!-- /.tf-re-cta-inner -->
  </div><!-- /.tf-re-wrap -->
</section>

</main><!-- /.tf-re-page -->

<script>
/* ══════════════════════════════════════════════════════════════════════
   ThemeFlex Real Estate — Vanilla JS
   1. Scroll-reveal (.tf-re-reveal)
   2. Animated counters (data-counter)
   3. Tab switching (.tf-re-tab-btn)
   ══════════════════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  if ( ! window.IntersectionObserver ) { return; }

  /* ── 1. Scroll reveal ─────────────────────────────────────────────── */
  var revealEls = document.querySelectorAll( '.tf-re-reveal' );
  if ( revealEls.length ) {
    var revealObserver = new IntersectionObserver( function ( entries ) {
      entries.forEach( function ( entry ) {
        if ( entry.isIntersecting ) {
          entry.target.classList.add( 'tf-re-visible' );
          revealObserver.unobserve( entry.target );
        }
      } );
    }, { threshold: 0.12 } );

    revealEls.forEach( function ( el ) {
      revealObserver.observe( el );
    } );
  }

  /* ── 2. Animated counters ─────────────────────────────────────────── */
  var counterEls = document.querySelectorAll( '[data-counter]' );
  var countersAnimated = false;

  function runCounters() {
    if ( countersAnimated ) { return; }
    countersAnimated = true;

    counterEls.forEach( function ( el ) {
      var target   = parseInt( el.getAttribute( 'data-counter' ), 10 );
      var suffix   = el.querySelector( '.tf-re-stat-num-suffix' );
      var suffixTxt = suffix ? suffix.outerHTML : '';
      var duration = 1600;
      var startTime = null;

      function step( timestamp ) {
        if ( ! startTime ) { startTime = timestamp; }
        var progress = Math.min( ( timestamp - startTime ) / duration, 1 );
        var eased    = 1 - Math.pow( 1 - progress, 3 ); /* ease-out-cubic */
        var current  = Math.floor( eased * target );
        el.innerHTML = current + suffixTxt;
        if ( progress < 1 ) {
          requestAnimationFrame( step );
        } else {
          el.innerHTML = target + suffixTxt;
        }
      }
      requestAnimationFrame( step );
    } );
  }

  if ( counterEls.length ) {
    var statsGrid = document.getElementById( 'tf-re-stats-grid' );
    if ( statsGrid ) {
      var counterObserver = new IntersectionObserver( function ( entries ) {
        entries.forEach( function ( entry ) {
          if ( entry.isIntersecting ) {
            runCounters();
            counterObserver.unobserve( statsGrid );
          }
        } );
      }, { threshold: 0.3 } );
      counterObserver.observe( statsGrid );
    }
  }

  /* ── 3. Tab switching ─────────────────────────────────────────────── */
  var tabBtns = document.querySelectorAll( '.tf-re-tab-btn' );
  tabBtns.forEach( function ( btn ) {
    btn.addEventListener( 'click', function () {
      tabBtns.forEach( function ( b ) {
        b.classList.remove( 'tf-re-tab-active' );
        b.setAttribute( 'aria-selected', 'false' );
      } );
      btn.classList.add( 'tf-re-tab-active' );
      btn.setAttribute( 'aria-selected', 'true' );
      /* In a live implementation, filter .tf-re-listing-card elements
         by their data-type attribute matching btn.getAttribute('data-tab'). */
    } );
  } );

})();
</script>

<?php get_footer(); ?>
