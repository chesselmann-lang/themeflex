<?php
/**
 * Template Name: Restaurant Homepage
 *
 * Warm dark restaurant homepage: full-bleed hero, featured dishes,
 * about/story split, menu preview, testimonials, reservation CTA.
 *
 * @package ThemeFlex
 * @since   2.6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<style>
/* ============================================================
   PAGE-RESTAURANT — SCOPED STYLES
   Warm dark palette: deep coffee #0f0a07, amber #e8882a, cream #f5e8d0
   ============================================================ */

.tf-rst-page { color: #e8ddd0; }
.tf-rst-page *,
.tf-rst-page *::before,
.tf-rst-page *::after { box-sizing: border-box; }
.tf-rst-page section { position: relative; overflow: hidden; }

/* Colour tokens (override skin vars locally) */
.tf-rst-page {
	--rst-bg:       #0f0a07;
	--rst-bg-2:     #1a1108;
	--rst-bg-3:     #221606;
	--rst-accent:   #e8882a;
	--rst-amber:    #f5b944;
	--rst-cream:    #f5e8d0;
	--rst-muted:    #9e8f7e;
	--rst-border:   rgba(232,136,42,.12);
	--rst-heading:  #f5e8d0;
}

.tf-rst-container {
	max-width: 1200px;
	margin-inline: auto;
	padding-inline: 1.5rem;
}
.tf-rst-eyebrow {
	display: inline-flex;
	align-items: center;
	gap: .5rem;
	font-size: .72rem;
	font-weight: 700;
	letter-spacing: .16em;
	text-transform: uppercase;
	color: var(--rst-accent);
	margin-bottom: .9rem;
	font-family: var(--tf-font-body, inherit);
}
.tf-rst-eyebrow-line {
	display: inline-block;
	width: 28px;
	height: 1px;
	background: var(--rst-accent);
}
.tf-rst-section-title {
	font-size: clamp(1.8rem, 3.5vw, 2.75rem);
	font-weight: 800;
	line-height: 1.15;
	color: var(--rst-heading);
	margin: 0 0 1rem;
	font-family: var(--tf-font-heading, inherit);
}
.tf-rst-section-sub {
	font-size: 1rem;
	color: var(--rst-muted);
	line-height: 1.75;
	max-width: 560px;
}

/* ============================================================
   1. HERO
   ============================================================ */
.tf-rst-hero {
	min-height: 100vh;
	background: var(--rst-bg);
	display: flex;
	align-items: center;
	padding: 8rem 0 6rem;
}
.tf-rst-hero__inner {
	display: grid;
	grid-template-columns: 1fr 1fr;
	gap: 5rem;
	align-items: center;
}
.tf-rst-hero__kicker {
	display: inline-flex;
	align-items: center;
	gap: .6rem;
	background: rgba(232,136,42,.1);
	border: 1px solid rgba(232,136,42,.25);
	border-radius: 100px;
	padding: .35rem 1rem;
	font-size: .73rem;
	font-weight: 700;
	letter-spacing: .1em;
	text-transform: uppercase;
	color: var(--rst-accent);
	margin-bottom: 1.5rem;
}
.tf-rst-hero__kicker-dot {
	width: 6px; height: 6px;
	border-radius: 50%;
	background: #10b981;
	box-shadow: 0 0 0 3px rgba(16,185,129,.2);
}
.tf-rst-hero__title {
	font-size: clamp(2.6rem, 5.5vw, 4.2rem);
	font-weight: 900;
	line-height: 1.08;
	color: var(--rst-heading);
	margin: 0 0 1.5rem;
	font-family: var(--tf-font-heading, inherit);
}
.tf-rst-hero__title em {
	font-style: italic;
	color: var(--rst-accent);
}
.tf-rst-hero__desc {
	font-size: 1.05rem;
	color: var(--rst-muted);
	line-height: 1.75;
	margin: 0 0 2.25rem;
}
.tf-rst-hero__actions {
	display: flex;
	align-items: center;
	gap: 1rem;
	flex-wrap: wrap;
	margin-bottom: 2.5rem;
}
.tf-rst-btn-primary {
	display: inline-flex;
	align-items: center;
	gap: .5rem;
	background: var(--rst-accent);
	color: #fff;
	font-weight: 700;
	font-size: .95rem;
	padding: .9rem 1.85rem;
	border-radius: 10px;
	text-decoration: none;
	transition: filter .2s, transform .2s;
}
.tf-rst-btn-primary:hover { filter: brightness(1.1); transform: translateY(-2px); }
.tf-rst-btn-ghost {
	display: inline-flex;
	align-items: center;
	gap: .5rem;
	background: transparent;
	color: var(--rst-heading);
	font-weight: 600;
	font-size: .95rem;
	padding: .9rem 1.6rem;
	border-radius: 10px;
	border: 1px solid var(--rst-border);
	text-decoration: none;
	transition: border-color .2s, background .2s;
}
.tf-rst-btn-ghost:hover { border-color: var(--rst-accent); background: rgba(232,136,42,.07); }
.tf-rst-hero__hours {
	display: flex;
	align-items: center;
	gap: 1.5rem;
	flex-wrap: wrap;
}
.tf-rst-hero__hours-item {
	display: flex;
	align-items: center;
	gap: .4rem;
	font-size: .82rem;
	color: var(--rst-muted);
}
.tf-rst-hero__hours-item svg { color: var(--rst-accent); }

/* ---- Hero visual: CSS dish art ---- */
.tf-rst-hero__visual {
	position: relative;
	height: 500px;
}
.tf-rst-hero__orb {
	position: absolute;
	border-radius: 50%;
	filter: blur(70px);
	pointer-events: none;
}
.tf-rst-hero__orb--1 {
	width: 360px; height: 360px;
	background: radial-gradient(circle, rgba(232,136,42,.22) 0%, transparent 70%);
	top: 5%; left: 10%;
}
.tf-rst-hero__orb--2 {
	width: 200px; height: 200px;
	background: radial-gradient(circle, rgba(168,85,247,.12) 0%, transparent 70%);
	bottom: 10%; right: 0;
}

/* Plate mockup */
.tf-rst-plate {
	position: absolute;
	top: 50%; left: 50%;
	transform: translate(-50%, -50%);
	width: 280px; height: 280px;
	border-radius: 50%;
	background: radial-gradient(circle at 40% 35%,
		rgba(232,136,42,.3) 0%,
		rgba(181,93,20,.2) 40%,
		rgba(30,15,5,.9) 100%
	);
	border: 2px solid rgba(232,136,42,.18);
	box-shadow:
		0 40px 100px rgba(0,0,0,.7),
		inset 0 2px 4px rgba(255,255,255,.04);
	display: flex;
	align-items: center;
	justify-content: center;
	z-index: 3;
}
.tf-rst-plate::before {
	content: '';
	position: absolute;
	inset: 16px;
	border-radius: 50%;
	border: 1px solid rgba(232,136,42,.12);
}
.tf-rst-plate__icon {
	color: var(--rst-accent);
	opacity: .9;
}

/* Floating info cards */
.tf-rst-float {
	position: absolute;
	background: var(--rst-bg-2);
	border: 1px solid var(--rst-border);
	border-radius: 14px;
	padding: .8rem 1.1rem;
	box-shadow: 0 20px 50px rgba(0,0,0,.5);
	z-index: 4;
}
.tf-rst-float-dish {
	top: 6%;
	right: -5px;
	width: 200px;
}
.tf-rst-float-dish-name {
	font-size: .85rem;
	font-weight: 700;
	color: var(--rst-heading);
	margin-bottom: .25rem;
}
.tf-rst-float-dish-desc {
	font-size: .73rem;
	color: var(--rst-muted);
	margin-bottom: .5rem;
}
.tf-rst-float-dish-price {
	font-size: 1rem;
	font-weight: 800;
	color: var(--rst-accent);
}
.tf-rst-float-rating {
	bottom: 20%;
	left: -10px;
	display: flex;
	align-items: center;
	gap: .6rem;
}
.tf-rst-float-rating-stars { color: var(--rst-amber); font-size: .9rem; }
.tf-rst-float-rating-text strong {
	display: block;
	font-size: .82rem;
	color: var(--rst-heading);
	font-weight: 700;
}
.tf-rst-float-rating-text span {
	font-size: .7rem;
	color: var(--rst-muted);
}
.tf-rst-float-tag {
	top: 35%;
	left: 0;
	display: flex;
	align-items: center;
	gap: .5rem;
	font-size: .78rem;
	font-weight: 700;
	color: #10b981;
}
.tf-rst-float-tag-dot {
	width: 8px; height: 8px;
	border-radius: 50%;
	background: #10b981;
	box-shadow: 0 0 0 3px rgba(16,185,129,.2);
}

/* ============================================================
   2. INFO STRIP
   ============================================================ */
.tf-rst-info-strip {
	background: var(--rst-bg-2);
	border-top: 1px solid var(--rst-border);
	border-bottom: 1px solid var(--rst-border);
	padding: 1.75rem 0;
}
.tf-rst-info-strip__grid {
	display: grid;
	grid-template-columns: repeat(4, 1fr);
	gap: 0;
}
.tf-rst-info-strip__item {
	display: flex;
	align-items: center;
	gap: .85rem;
	padding: .5rem 1.5rem;
	border-right: 1px solid var(--rst-border);
}
.tf-rst-info-strip__item:last-child { border-right: none; }
.tf-rst-info-strip__icon {
	width: 40px; height: 40px;
	border-radius: 10px;
	display: flex;
	align-items: center;
	justify-content: center;
	flex-shrink: 0;
	background: rgba(232,136,42,.1);
	color: var(--rst-accent);
}
.tf-rst-info-strip__title {
	font-size: .88rem;
	font-weight: 700;
	color: var(--rst-heading);
	margin-bottom: .15rem;
}
.tf-rst-info-strip__sub {
	font-size: .75rem;
	color: var(--rst-muted);
}

/* ============================================================
   3. FEATURED DISHES
   ============================================================ */
.tf-rst-dishes {
	background: var(--rst-bg);
	padding: 6rem 0;
}
.tf-rst-dishes__header {
	text-align: center;
	margin-bottom: 3.5rem;
}
.tf-rst-dishes__header .tf-rst-section-sub { margin-inline: auto; }
.tf-rst-dishes__grid {
	display: grid;
	grid-template-columns: repeat(3, 1fr);
	gap: 1.5rem;
}
.tf-rst-dish-card {
	background: var(--rst-bg-2);
	border: 1px solid var(--rst-border);
	border-radius: 20px;
	overflow: hidden;
	transition: transform .25s, border-color .25s;
}
.tf-rst-dish-card:hover { transform: translateY(-5px); border-color: rgba(232,136,42,.3); }

.tf-rst-dish-img {
	height: 200px;
	position: relative;
	display: flex;
	align-items: center;
	justify-content: center;
	overflow: hidden;
}
.tf-rst-dish-img--1 { background: linear-gradient(135deg, rgba(232,136,42,.25) 0%, rgba(181,93,20,.3) 100%); color: var(--rst-accent); }
.tf-rst-dish-img--2 { background: linear-gradient(135deg, rgba(168,85,247,.2) 0%, rgba(99,102,241,.2) 100%); color: #c084fc; }
.tf-rst-dish-img--3 { background: linear-gradient(135deg, rgba(16,185,129,.2) 0%, rgba(5,150,105,.25) 100%); color: #10b981; }

.tf-rst-dish-img__icon {
	width: 60px; height: 60px;
	border-radius: 14px;
	background: rgba(0,0,0,.3);
	border: 1px solid rgba(255,255,255,.1);
	display: flex;
	align-items: center;
	justify-content: center;
}
.tf-rst-dish-chef-pick {
	position: absolute;
	top: .75rem; left: .75rem;
	background: var(--rst-accent);
	color: #fff;
	font-size: .68rem;
	font-weight: 700;
	letter-spacing: .08em;
	text-transform: uppercase;
	padding: .25rem .6rem;
	border-radius: 6px;
}
.tf-rst-dish-new {
	position: absolute;
	top: .75rem; left: .75rem;
	background: #10b981;
	color: #fff;
	font-size: .68rem;
	font-weight: 700;
	letter-spacing: .08em;
	text-transform: uppercase;
	padding: .25rem .6rem;
	border-radius: 6px;
}
.tf-rst-dish-info { padding: 1.25rem 1.5rem 1.5rem; }
.tf-rst-dish-cat {
	font-size: .7rem;
	font-weight: 700;
	letter-spacing: .1em;
	text-transform: uppercase;
	color: var(--rst-accent);
	margin-bottom: .4rem;
}
.tf-rst-dish-name {
	font-size: 1.1rem;
	font-weight: 700;
	color: var(--rst-heading);
	margin: 0 0 .4rem;
}
.tf-rst-dish-desc {
	font-size: .83rem;
	color: var(--rst-muted);
	line-height: 1.6;
	margin: 0 0 1rem;
}
.tf-rst-dish-footer {
	display: flex;
	align-items: center;
	justify-content: space-between;
}
.tf-rst-dish-price {
	font-size: 1.2rem;
	font-weight: 800;
	color: var(--rst-heading);
}
.tf-rst-dish-tags {
	display: flex;
	gap: .4rem;
	flex-wrap: wrap;
}
.tf-rst-dish-tag {
	font-size: .68rem;
	font-weight: 600;
	background: rgba(232,136,42,.1);
	color: var(--rst-accent);
	border-radius: 4px;
	padding: .2rem .5rem;
}

/* ============================================================
   4. STORY / ABOUT SPLIT
   ============================================================ */
.tf-rst-story {
	background: var(--rst-bg-3);
	padding: 7rem 0;
	border-top: 1px solid var(--rst-border);
	border-bottom: 1px solid var(--rst-border);
}
.tf-rst-story__grid {
	display: grid;
	grid-template-columns: 1fr 1fr;
	gap: 5rem;
	align-items: center;
}
.tf-rst-story__text p {
	font-size: .95rem;
	color: var(--rst-muted);
	line-height: 1.85;
	margin: 0 0 1.25rem;
}
.tf-rst-story__text p:last-of-type { margin-bottom: 2rem; }
.tf-rst-story__stats {
	display: grid;
	grid-template-columns: 1fr 1fr;
	gap: 1.5rem;
	margin-top: 2rem;
}
.tf-rst-story__stat-card {
	background: var(--rst-bg-2);
	border: 1px solid var(--rst-border);
	border-radius: 14px;
	padding: 1.25rem 1.5rem;
	text-align: center;
}
.tf-rst-story__stat-num {
	font-size: 2rem;
	font-weight: 900;
	color: var(--rst-accent);
	line-height: 1;
	margin-bottom: .3rem;
}
.tf-rst-story__stat-label {
	font-size: .78rem;
	color: var(--rst-muted);
}

/* Story visual — CSS kitchen art */
.tf-rst-story__visual {
	position: relative;
	height: 480px;
}
.tf-rst-story__orb {
	position: absolute;
	border-radius: 50%;
	filter: blur(60px);
	pointer-events: none;
}
.tf-rst-story__orb--1 {
	width: 280px; height: 280px;
	background: radial-gradient(circle, rgba(232,136,42,.18) 0%, transparent 70%);
	top: 0; right: 0;
}
/* Main "window" card */
.tf-rst-story__window {
	position: absolute;
	top: 50%; left: 50%;
	transform: translate(-50%, -50%);
	width: 300px;
	background: var(--rst-bg-2);
	border: 1px solid var(--rst-border);
	border-radius: 18px;
	overflow: hidden;
	box-shadow: 0 30px 80px rgba(0,0,0,.5);
	z-index: 3;
}
.tf-rst-story__window-header {
	background: var(--rst-bg);
	padding: .6rem 1rem;
	display: flex;
	align-items: center;
	gap: .5rem;
	border-bottom: 1px solid var(--rst-border);
}
.tf-rst-story__window-dot {
	width: 8px; height: 8px;
	border-radius: 50%;
}
.tf-rst-story__window-body {
	padding: 1.25rem;
}
.tf-rst-story__chef-row {
	display: flex;
	align-items: center;
	gap: .75rem;
	margin-bottom: 1rem;
	padding-bottom: 1rem;
	border-bottom: 1px solid var(--rst-border);
}
.tf-rst-story__chef-avatar {
	width: 40px; height: 40px;
	border-radius: 50%;
	background: rgba(232,136,42,.15);
	border: 2px solid rgba(232,136,42,.3);
	display: flex;
	align-items: center;
	justify-content: center;
	color: var(--rst-accent);
	font-size: .8rem;
	font-weight: 800;
	flex-shrink: 0;
}
.tf-rst-story__chef-name { font-size: .88rem; font-weight: 700; color: var(--rst-heading); }
.tf-rst-story__chef-title { font-size: .72rem; color: var(--rst-muted); }
/* Ingredient list */
.tf-rst-ingredient-row {
	display: flex;
	align-items: center;
	justify-content: space-between;
	padding: .4rem 0;
	border-bottom: 1px solid rgba(255,255,255,.04);
}
.tf-rst-ingredient-row:last-child { border-bottom: none; }
.tf-rst-ingredient-name { font-size: .78rem; color: var(--rst-muted); }
.tf-rst-ingredient-badge {
	font-size: .68rem;
	font-weight: 700;
	padding: .18rem .45rem;
	border-radius: 4px;
}
.tf-rst-ingredient-badge--fresh { background: rgba(16,185,129,.15); color: #10b981; }
.tf-rst-ingredient-badge--local { background: rgba(232,136,42,.15); color: var(--rst-accent); }
.tf-rst-ingredient-badge--organic { background: rgba(99,102,241,.15); color: #818cf8; }

/* Floating award badge */
.tf-rst-story__award {
	position: absolute;
	bottom: 20%;
	right: -5px;
	background: var(--rst-bg-2);
	border: 1px solid rgba(245,185,68,.25);
	border-radius: 12px;
	padding: .7rem 1rem;
	display: flex;
	align-items: center;
	gap: .6rem;
	z-index: 4;
	box-shadow: 0 12px 40px rgba(0,0,0,.4);
}
.tf-rst-story__award-icon { color: var(--rst-amber); }
.tf-rst-story__award-title { font-size: .82rem; font-weight: 700; color: var(--rst-heading); }
.tf-rst-story__award-sub   { font-size: .7rem; color: var(--rst-muted); }

/* ============================================================
   5. MENU PREVIEW
   ============================================================ */
.tf-rst-menu {
	background: var(--rst-bg);
	padding: 6rem 0;
}
.tf-rst-menu__header { text-align: center; margin-bottom: 3rem; }
.tf-rst-menu__header .tf-rst-section-sub { margin-inline: auto; }
.tf-rst-menu__tabs {
	display: flex;
	justify-content: center;
	gap: .5rem;
	flex-wrap: wrap;
	margin-bottom: 2.5rem;
}
.tf-rst-menu__tab {
	background: none;
	border: 1px solid var(--rst-border);
	color: var(--rst-muted);
	font-size: .82rem;
	font-weight: 600;
	padding: .5rem 1.25rem;
	border-radius: 8px;
	cursor: pointer;
	transition: all .18s;
}
.tf-rst-menu__tab.active,
.tf-rst-menu__tab:hover {
	background: var(--rst-accent);
	border-color: var(--rst-accent);
	color: #fff;
}
.tf-rst-menu__list {
	display: grid;
	grid-template-columns: 1fr 1fr;
	gap: 1rem;
}
.tf-rst-menu-item {
	display: flex;
	align-items: flex-start;
	gap: 1rem;
	background: var(--rst-bg-2);
	border: 1px solid var(--rst-border);
	border-radius: 14px;
	padding: 1.1rem 1.25rem;
	transition: border-color .2s;
}
.tf-rst-menu-item:hover { border-color: rgba(232,136,42,.3); }
.tf-rst-menu-item__icon {
	width: 44px; height: 44px;
	border-radius: 12px;
	background: rgba(232,136,42,.1);
	border: 1px solid rgba(232,136,42,.15);
	display: flex;
	align-items: center;
	justify-content: center;
	color: var(--rst-accent);
	flex-shrink: 0;
}
.tf-rst-menu-item__name {
	font-size: .92rem;
	font-weight: 700;
	color: var(--rst-heading);
	margin: 0 0 .25rem;
}
.tf-rst-menu-item__desc {
	font-size: .78rem;
	color: var(--rst-muted);
	line-height: 1.55;
	margin: 0 0 .4rem;
}
.tf-rst-menu-item__row {
	display: flex;
	align-items: center;
	justify-content: space-between;
}
.tf-rst-menu-item__price {
	font-size: 1rem;
	font-weight: 800;
	color: var(--rst-accent);
}
.tf-rst-menu-item__allergy {
	font-size: .68rem;
	color: var(--rst-muted);
	display: flex;
	align-items: center;
	gap: .25rem;
}

/* ============================================================
   6. TESTIMONIALS
   ============================================================ */
.tf-rst-testimonials {
	background: var(--rst-bg-2);
	padding: 6rem 0;
	border-top: 1px solid var(--rst-border);
}
.tf-rst-testimonials__header { text-align: center; margin-bottom: 3rem; }
.tf-rst-testimonials__header .tf-rst-section-sub { margin-inline: auto; }
.tf-rst-testimonials__grid {
	display: grid;
	grid-template-columns: repeat(3, 1fr);
	gap: 1.5rem;
}
.tf-rst-review {
	background: var(--rst-bg);
	border: 1px solid var(--rst-border);
	border-radius: 18px;
	padding: 1.75rem;
	transition: transform .25s;
}
.tf-rst-review:hover { transform: translateY(-3px); }
.tf-rst-review__quote-icon {
	color: var(--rst-accent);
	opacity: .4;
	margin-bottom: .75rem;
}
.tf-rst-review__stars {
	color: var(--rst-amber);
	font-size: .9rem;
	letter-spacing: .1em;
	margin-bottom: .75rem;
}
.tf-rst-review__text {
	font-size: .88rem;
	color: #c4b8a8;
	line-height: 1.75;
	margin: 0 0 1.25rem;
	font-style: italic;
}
.tf-rst-review__author {
	display: flex;
	align-items: center;
	gap: .75rem;
}
.tf-rst-review__avatar {
	width: 40px; height: 40px;
	border-radius: 50%;
	display: flex;
	align-items: center;
	justify-content: center;
	font-size: .82rem;
	font-weight: 800;
	flex-shrink: 0;
}
.tf-rst-review__avatar--1 { background: rgba(232,136,42,.2); color: var(--rst-accent); }
.tf-rst-review__avatar--2 { background: rgba(245,185,68,.15); color: var(--rst-amber); }
.tf-rst-review__avatar--3 { background: rgba(16,185,129,.15); color: #10b981; }
.tf-rst-review__name { font-size: .88rem; font-weight: 700; color: var(--rst-heading); }
.tf-rst-review__meta { font-size: .73rem; color: var(--rst-muted); }

/* ============================================================
   7. RESERVATION CTA
   ============================================================ */
.tf-rst-reservation {
	background: var(--rst-bg);
	padding: 7rem 0;
}
.tf-rst-reservation__inner {
	position: relative;
	border-radius: 28px;
	overflow: hidden;
	background: linear-gradient(135deg, #1a0d02 0%, #221606 50%, #160d0d 100%);
	border: 1px solid rgba(232,136,42,.18);
	padding: 4rem;
	display: grid;
	grid-template-columns: 1fr 1fr;
	gap: 4rem;
	align-items: center;
}
.tf-rst-reservation__orb {
	position: absolute;
	border-radius: 50%;
	filter: blur(60px);
	pointer-events: none;
}
.tf-rst-reservation__orb--1 {
	width: 320px; height: 320px;
	background: radial-gradient(circle, rgba(232,136,42,.2) 0%, transparent 70%);
	top: -60px; left: -60px;
}
.tf-rst-reservation__orb--2 {
	width: 200px; height: 200px;
	background: radial-gradient(circle, rgba(99,102,241,.15) 0%, transparent 70%);
	bottom: -40px; right: 20%;
}
.tf-rst-reservation__content { position: relative; z-index: 1; }
.tf-rst-reservation__tag {
	display: inline-flex;
	align-items: center;
	gap: .4rem;
	background: rgba(232,136,42,.15);
	border: 1px solid rgba(232,136,42,.3);
	color: var(--rst-accent);
	font-size: .72rem;
	font-weight: 700;
	letter-spacing: .1em;
	text-transform: uppercase;
	padding: .3rem .8rem;
	border-radius: 6px;
	margin-bottom: 1rem;
}
.tf-rst-reservation__title {
	font-size: clamp(1.8rem, 3.5vw, 2.8rem);
	font-weight: 900;
	color: var(--rst-heading);
	margin: 0 0 1rem;
	line-height: 1.15;
	font-family: var(--tf-font-heading, inherit);
}
.tf-rst-reservation__desc {
	color: rgba(245,232,208,.6);
	font-size: .95rem;
	line-height: 1.7;
	margin: 0 0 2rem;
}
.tf-rst-reservation__perks {
	display: flex;
	flex-direction: column;
	gap: .6rem;
	margin-bottom: 2rem;
}
.tf-rst-reservation__perk {
	display: flex;
	align-items: center;
	gap: .6rem;
	font-size: .85rem;
	color: rgba(245,232,208,.75);
}
.tf-rst-reservation__perk svg { color: var(--rst-accent); flex-shrink: 0; }

/* Form */
.tf-rst-res-form { position: relative; z-index: 1; }
.tf-rst-res-form__title {
	font-size: 1rem;
	font-weight: 700;
	color: var(--rst-heading);
	margin: 0 0 1.25rem;
}
.tf-rst-form-group { margin-bottom: .85rem; }
.tf-rst-form-label {
	display: block;
	font-size: .75rem;
	font-weight: 600;
	color: var(--rst-muted);
	text-transform: uppercase;
	letter-spacing: .08em;
	margin-bottom: .35rem;
}
.tf-rst-form-input,
.tf-rst-form-select {
	width: 100%;
	background: rgba(0,0,0,.35);
	border: 1px solid rgba(232,136,42,.15);
	border-radius: 10px;
	padding: .75rem 1rem;
	color: var(--rst-heading);
	font-size: .9rem;
	outline: none;
	transition: border-color .18s;
	-webkit-appearance: none;
	appearance: none;
}
.tf-rst-form-input:focus,
.tf-rst-form-select:focus { border-color: var(--rst-accent); }
.tf-rst-form-input::placeholder { color: var(--rst-muted); }
.tf-rst-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: .75rem; }
.tf-rst-form-submit {
	display: flex;
	align-items: center;
	justify-content: center;
	gap: .5rem;
	width: 100%;
	background: var(--rst-accent);
	color: #fff;
	font-weight: 700;
	font-size: .95rem;
	padding: .9rem;
	border-radius: 10px;
	border: none;
	cursor: pointer;
	margin-top: 1rem;
	transition: filter .2s;
}
.tf-rst-form-submit:hover { filter: brightness(1.1); }

/* ============================================================
   RESPONSIVE
   ============================================================ */
@media (max-width: 1024px) {
	.tf-rst-hero__inner    { grid-template-columns: 1fr; gap: 3rem; }
	.tf-rst-hero__visual   { height: 380px; }
	.tf-rst-story__grid    { grid-template-columns: 1fr; gap: 3rem; }
	.tf-rst-story__visual  { height: 360px; }
	.tf-rst-dishes__grid   { grid-template-columns: repeat(2, 1fr); }
	.tf-rst-menu__list     { grid-template-columns: 1fr; }
	.tf-rst-info-strip__grid { grid-template-columns: repeat(2, 1fr); }
	.tf-rst-info-strip__item:nth-child(2) { border-right: none; }
	.tf-rst-reservation__inner { grid-template-columns: 1fr; padding: 2.5rem; }
}
@media (max-width: 640px) {
	.tf-rst-hero { padding: 5rem 0 3rem; }
	.tf-rst-hero__visual   { display: none; }
	.tf-rst-story__visual  { display: none; }
	.tf-rst-dishes__grid   { grid-template-columns: 1fr; }
	.tf-rst-testimonials__grid { grid-template-columns: 1fr; }
	.tf-rst-info-strip__grid { grid-template-columns: 1fr; }
	.tf-rst-info-strip__item { border-right: none; border-bottom: 1px solid var(--rst-border); }
	.tf-rst-form-row { grid-template-columns: 1fr; }
}

/* Scroll reveal */
.tf-rst-reveal {
	opacity: 0;
	transform: translateY(22px);
	transition: opacity .55s ease, transform .55s ease;
}
.tf-rst-reveal.is-visible {
	opacity: 1;
	transform: none;
}
</style>

<main id="tf-rst-main" class="tf-rst-page" role="main">

	<?php
	/* ============================================================
	   1. HERO
	   ============================================================ */
	?>
	<section class="tf-rst-hero" aria-labelledby="tf-rst-hero-title">
		<div class="tf-rst-container">
			<div class="tf-rst-hero__inner">

				<div>
					<div class="tf-rst-hero__kicker">
						<span class="tf-rst-hero__kicker-dot"></span>
						<?php esc_html_e( 'Now Accepting Reservations', 'themeflex' ); ?>
					</div>
					<h1 id="tf-rst-hero-title" class="tf-rst-hero__title">
						<?php esc_html_e( 'Where Every', 'themeflex' ); ?><br>
						<em><?php esc_html_e( 'Dish Tells', 'themeflex' ); ?></em><br>
						<?php esc_html_e( 'a Story', 'themeflex' ); ?>
					</h1>
					<p class="tf-rst-hero__desc">
						<?php esc_html_e( 'Handcrafted seasonal menus inspired by local farms and artisan producers. Every plate is a celebration of provenance, technique, and flavour — in an atmosphere you\'ll want to linger in.', 'themeflex' ); ?>
					</p>
					<div class="tf-rst-hero__actions">
						<a href="<?php echo esc_url( home_url( '/reservations' ) ); ?>" class="tf-rst-btn-primary">
							<?php echo tf_icon_get( 'calendar', 18 ); ?>
							<?php esc_html_e( 'Reserve a Table', 'themeflex' ); ?>
						</a>
						<a href="<?php echo esc_url( home_url( '/menu' ) ); ?>" class="tf-rst-btn-ghost">
							<?php echo tf_icon_get( 'book-open', 18 ); ?>
							<?php esc_html_e( 'View Menu', 'themeflex' ); ?>
						</a>
					</div>
					<div class="tf-rst-hero__hours">
						<div class="tf-rst-hero__hours-item">
							<?php echo tf_icon_get( 'clock', 15 ); ?>
							<span><?php esc_html_e( 'Tue–Sun 12:00–22:00', 'themeflex' ); ?></span>
						</div>
						<div class="tf-rst-hero__hours-item">
							<?php echo tf_icon_get( 'map-pin', 15 ); ?>
							<span><?php esc_html_e( 'Downtown Quarter', 'themeflex' ); ?></span>
						</div>
					</div>
				</div>

				<!-- Visual (CSS plate art) -->
				<div class="tf-rst-hero__visual" aria-hidden="true">
					<div class="tf-rst-hero__orb tf-rst-hero__orb--1"></div>
					<div class="tf-rst-hero__orb tf-rst-hero__orb--2"></div>

					<div class="tf-rst-plate">
						<div class="tf-rst-plate__icon">
							<?php echo tf_icon_get( 'utensils', 48 ); ?>
						</div>
					</div>

					<!-- Floating dish info card -->
					<div class="tf-rst-float tf-rst-float-dish">
						<div class="tf-rst-float-dish-name"><?php esc_html_e( 'Truffle Risotto', 'themeflex' ); ?></div>
						<div class="tf-rst-float-dish-desc"><?php esc_html_e( 'Porcini · Parmesan · Microgreens', 'themeflex' ); ?></div>
						<div class="tf-rst-float-dish-price">$38</div>
					</div>

					<!-- Floating rating -->
					<div class="tf-rst-float tf-rst-float-rating">
						<div class="tf-rst-float-rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
						<div class="tf-rst-float-rating-text">
							<strong><?php esc_html_e( '4.9 / 5.0', 'themeflex' ); ?></strong>
							<span><?php esc_html_e( '3,200+ reviews', 'themeflex' ); ?></span>
						</div>
					</div>

					<!-- Live status -->
					<div class="tf-rst-float tf-rst-float-tag">
						<span class="tf-rst-float-tag-dot"></span>
						<span><?php esc_html_e( 'Kitchen is open', 'themeflex' ); ?></span>
					</div>
				</div>

			</div>
		</div>
	</section>

	<?php
	/* ============================================================
	   2. INFO STRIP
	   ============================================================ */
	?>
	<section class="tf-rst-info-strip" aria-label="<?php esc_attr_e( 'Restaurant information', 'themeflex' ); ?>">
		<div class="tf-rst-container">
			<div class="tf-rst-info-strip__grid">

				<div class="tf-rst-info-strip__item">
					<div class="tf-rst-info-strip__icon"><?php echo tf_icon_get( 'clock', 22 ); ?></div>
					<div>
						<div class="tf-rst-info-strip__title"><?php esc_html_e( 'Opening Hours', 'themeflex' ); ?></div>
						<div class="tf-rst-info-strip__sub"><?php esc_html_e( 'Tue–Sun 12:00 – 22:00', 'themeflex' ); ?></div>
					</div>
				</div>

				<div class="tf-rst-info-strip__item">
					<div class="tf-rst-info-strip__icon"><?php echo tf_icon_get( 'map-pin', 22 ); ?></div>
					<div>
						<div class="tf-rst-info-strip__title"><?php esc_html_e( 'Location', 'themeflex' ); ?></div>
						<div class="tf-rst-info-strip__sub"><?php esc_html_e( '42 Market Street, Downtown', 'themeflex' ); ?></div>
					</div>
				</div>

				<div class="tf-rst-info-strip__item">
					<div class="tf-rst-info-strip__icon"><?php echo tf_icon_get( 'phone', 22 ); ?></div>
					<div>
						<div class="tf-rst-info-strip__title"><?php esc_html_e( 'Reservations', 'themeflex' ); ?></div>
						<div class="tf-rst-info-strip__sub"><?php esc_html_e( '+1 (555) 000-1234', 'themeflex' ); ?></div>
					</div>
				</div>

				<div class="tf-rst-info-strip__item">
					<div class="tf-rst-info-strip__icon"><?php echo tf_icon_get( 'award', 22 ); ?></div>
					<div>
						<div class="tf-rst-info-strip__title"><?php esc_html_e( 'Michelin Recognised', 'themeflex' ); ?></div>
						<div class="tf-rst-info-strip__sub"><?php esc_html_e( 'Bib Gourmand 2024 & 2025', 'themeflex' ); ?></div>
					</div>
				</div>

			</div>
		</div>
	</section>

	<?php
	/* ============================================================
	   3. FEATURED DISHES
	   ============================================================ */
	?>
	<section class="tf-rst-dishes" aria-labelledby="tf-rst-dishes-title">
		<div class="tf-rst-container">
			<div class="tf-rst-dishes__header">
				<div class="tf-rst-eyebrow">
					<span class="tf-rst-eyebrow-line"></span>
					<?php esc_html_e( 'Signature Dishes', 'themeflex' ); ?>
					<span class="tf-rst-eyebrow-line"></span>
				</div>
				<h2 id="tf-rst-dishes-title" class="tf-rst-section-title">
					<?php esc_html_e( 'Crafted to Perfection', 'themeflex' ); ?>
				</h2>
				<p class="tf-rst-section-sub">
					<?php esc_html_e( 'Our kitchen team obsesses over every detail — from the provenance of each ingredient to the final presentation. These are the dishes guests keep coming back for.', 'themeflex' ); ?>
				</p>
			</div>

			<div class="tf-rst-dishes__grid">

				<article class="tf-rst-dish-card tf-rst-reveal">
					<div class="tf-rst-dish-img tf-rst-dish-img--1">
						<div class="tf-rst-dish-img__icon"><?php echo tf_icon_get( 'flame', 28 ); ?></div>
						<div class="tf-rst-dish-chef-pick"><?php esc_html_e( "Chef's Pick", 'themeflex' ); ?></div>
					</div>
					<div class="tf-rst-dish-info">
						<div class="tf-rst-dish-cat"><?php esc_html_e( 'Main Course', 'themeflex' ); ?></div>
						<h3 class="tf-rst-dish-name"><?php esc_html_e( 'Wagyu Beef Tenderloin', 'themeflex' ); ?></h3>
						<p class="tf-rst-dish-desc"><?php esc_html_e( 'A5 Wagyu, truffle jus, celeriac purée, seasonal wild mushrooms, crispy shallots.', 'themeflex' ); ?></p>
						<div class="tf-rst-dish-footer">
							<div class="tf-rst-dish-price">$68</div>
							<div class="tf-rst-dish-tags">
								<span class="tf-rst-dish-tag"><?php esc_html_e( 'Gluten-Free', 'themeflex' ); ?></span>
								<span class="tf-rst-dish-tag"><?php esc_html_e( 'Signature', 'themeflex' ); ?></span>
							</div>
						</div>
					</div>
				</article>

				<article class="tf-rst-dish-card tf-rst-reveal">
					<div class="tf-rst-dish-img tf-rst-dish-img--2">
						<div class="tf-rst-dish-img__icon"><?php echo tf_icon_get( 'leaf', 28 ); ?></div>
						<div class="tf-rst-dish-chef-pick"><?php esc_html_e( 'Vegetarian', 'themeflex' ); ?></div>
					</div>
					<div class="tf-rst-dish-info">
						<div class="tf-rst-dish-cat"><?php esc_html_e( 'Starter', 'themeflex' ); ?></div>
						<h3 class="tf-rst-dish-name"><?php esc_html_e( 'Heritage Beetroot Tart', 'themeflex' ); ?></h3>
						<p class="tf-rst-dish-desc"><?php esc_html_e( 'Trio of beetroot, goat\'s cheese mousse, candied walnuts, rocket oil, edible flowers.', 'themeflex' ); ?></p>
						<div class="tf-rst-dish-footer">
							<div class="tf-rst-dish-price">$22</div>
							<div class="tf-rst-dish-tags">
								<span class="tf-rst-dish-tag"><?php esc_html_e( 'Vegan Option', 'themeflex' ); ?></span>
							</div>
						</div>
					</div>
				</article>

				<article class="tf-rst-dish-card tf-rst-reveal">
					<div class="tf-rst-dish-img tf-rst-dish-img--3">
						<div class="tf-rst-dish-img__icon"><?php echo tf_icon_get( 'fish', 28 ); ?></div>
						<div class="tf-rst-dish-new"><?php esc_html_e( 'New', 'themeflex' ); ?></div>
					</div>
					<div class="tf-rst-dish-info">
						<div class="tf-rst-dish-cat"><?php esc_html_e( 'Main Course', 'themeflex' ); ?></div>
						<h3 class="tf-rst-dish-name"><?php esc_html_e( 'Line-Caught Sea Bass', 'themeflex' ); ?></h3>
						<p class="tf-rst-dish-desc"><?php esc_html_e( 'Pan-seared fillet, saffron velouté, samphire, charred lemon, fennel pollen.', 'themeflex' ); ?></p>
						<div class="tf-rst-dish-footer">
							<div class="tf-rst-dish-price">$44</div>
							<div class="tf-rst-dish-tags">
								<span class="tf-rst-dish-tag"><?php esc_html_e( 'Seasonal', 'themeflex' ); ?></span>
							</div>
						</div>
					</div>
				</article>

			</div><!-- /.tf-rst-dishes__grid -->

			<div style="text-align:center;margin-top:3rem;">
				<a href="<?php echo esc_url( home_url( '/menu' ) ); ?>" class="tf-rst-btn-ghost">
					<?php echo tf_icon_get( 'book-open', 18 ); ?>
					<?php esc_html_e( 'Browse Full Menu', 'themeflex' ); ?>
				</a>
			</div>
		</div>
	</section>

	<?php
	/* ============================================================
	   4. STORY / ABOUT SPLIT
	   ============================================================ */
	?>
	<section class="tf-rst-story" aria-labelledby="tf-rst-story-title">
		<div class="tf-rst-container">
			<div class="tf-rst-story__grid">

				<div class="tf-rst-story__text">
					<div class="tf-rst-eyebrow">
						<span class="tf-rst-eyebrow-line"></span>
						<?php esc_html_e( 'Our Story', 'themeflex' ); ?>
					</div>
					<h2 id="tf-rst-story-title" class="tf-rst-section-title">
						<?php esc_html_e( 'Rooted in Passion for Honest Food', 'themeflex' ); ?>
					</h2>
					<p>
						<?php esc_html_e( 'Founded in 2009 by chef Elena Maher, our restaurant was born from a simple belief: that the best dishes come from the best ingredients. We partner directly with local farmers and growers — people who share our commitment to sustainable, ethical food production.', 'themeflex' ); ?>
					</p>
					<p>
						<?php esc_html_e( 'Every season our menu changes to reflect what\'s at its peak. We don\'t chase trends — we follow the land. Our kitchen team of twelve approaches each service with the care of a small family dinner, whether we\'re hosting twelve guests or a full dining room.', 'themeflex' ); ?>
					</p>
					<a href="<?php echo esc_url( home_url( '/about' ) ); ?>" class="tf-rst-btn-ghost">
						<?php echo tf_icon_get( 'arrow-right', 17 ); ?>
						<?php esc_html_e( 'Read Our Full Story', 'themeflex' ); ?>
					</a>
					<div class="tf-rst-story__stats">
						<div class="tf-rst-story__stat-card">
							<div class="tf-rst-story__stat-num">16</div>
							<div class="tf-rst-story__stat-label"><?php esc_html_e( 'Years of Excellence', 'themeflex' ); ?></div>
						</div>
						<div class="tf-rst-story__stat-card">
							<div class="tf-rst-story__stat-num">8</div>
							<div class="tf-rst-story__stat-label"><?php esc_html_e( 'Local Farm Partners', 'themeflex' ); ?></div>
						</div>
						<div class="tf-rst-story__stat-card">
							<div class="tf-rst-story__stat-num">120k</div>
							<div class="tf-rst-story__stat-label"><?php esc_html_e( 'Covers Per Year', 'themeflex' ); ?></div>
						</div>
						<div class="tf-rst-story__stat-card">
							<div class="tf-rst-story__stat-num">4</div>
							<div class="tf-rst-story__stat-label"><?php esc_html_e( 'Industry Awards', 'themeflex' ); ?></div>
						</div>
					</div>
				</div>

				<!-- Visual: CSS ingredient sourcing card -->
				<div class="tf-rst-story__visual" aria-hidden="true">
					<div class="tf-rst-story__orb tf-rst-story__orb--1"></div>

					<div class="tf-rst-story__window">
						<div class="tf-rst-story__window-header">
							<div class="tf-rst-story__window-dot" style="background:#ef4444;"></div>
							<div class="tf-rst-story__window-dot" style="background:#f59e0b;"></div>
							<div class="tf-rst-story__window-dot" style="background:#10b981;"></div>
							<span style="font-size:.72rem;color:var(--rst-muted);margin-left:.75rem;"><?php esc_html_e( "Today's Sourcing", 'themeflex' ); ?></span>
						</div>
						<div class="tf-rst-story__window-body">
							<!-- Chef profile row -->
							<div class="tf-rst-story__chef-row">
								<div class="tf-rst-story__chef-avatar">EM</div>
								<div>
									<div class="tf-rst-story__chef-name"><?php esc_html_e( 'Elena Maher', 'themeflex' ); ?></div>
									<div class="tf-rst-story__chef-title"><?php esc_html_e( 'Head Chef & Founder', 'themeflex' ); ?></div>
								</div>
								<div style="margin-left:auto;color:var(--rst-accent);">
									<?php echo tf_icon_get( 'chef-hat', 18 ); ?>
								</div>
							</div>
							<!-- Ingredients -->
							<div class="tf-rst-ingredient-row">
								<span class="tf-rst-ingredient-name"><?php esc_html_e( 'Heritage tomatoes', 'themeflex' ); ?></span>
								<span class="tf-rst-ingredient-badge tf-rst-ingredient-badge--fresh"><?php esc_html_e( 'Fresh', 'themeflex' ); ?></span>
							</div>
							<div class="tf-rst-ingredient-row">
								<span class="tf-rst-ingredient-name"><?php esc_html_e( 'Black truffle', 'themeflex' ); ?></span>
								<span class="tf-rst-ingredient-badge tf-rst-ingredient-badge--local"><?php esc_html_e( 'Local', 'themeflex' ); ?></span>
							</div>
							<div class="tf-rst-ingredient-row">
								<span class="tf-rst-ingredient-name"><?php esc_html_e( 'Microgreens', 'themeflex' ); ?></span>
								<span class="tf-rst-ingredient-badge tf-rst-ingredient-badge--organic"><?php esc_html_e( 'Organic', 'themeflex' ); ?></span>
							</div>
							<div class="tf-rst-ingredient-row">
								<span class="tf-rst-ingredient-name"><?php esc_html_e( 'Grass-fed butter', 'themeflex' ); ?></span>
								<span class="tf-rst-ingredient-badge tf-rst-ingredient-badge--local"><?php esc_html_e( 'Local', 'themeflex' ); ?></span>
							</div>
							<div class="tf-rst-ingredient-row">
								<span class="tf-rst-ingredient-name"><?php esc_html_e( 'Wild mushrooms', 'themeflex' ); ?></span>
								<span class="tf-rst-ingredient-badge tf-rst-ingredient-badge--fresh"><?php esc_html_e( 'Fresh', 'themeflex' ); ?></span>
							</div>
						</div>
					</div>

					<!-- Award badge -->
					<div class="tf-rst-story__award">
						<div class="tf-rst-story__award-icon"><?php echo tf_icon_get( 'star', 20 ); ?></div>
						<div>
							<div class="tf-rst-story__award-title"><?php esc_html_e( 'Bib Gourmand', 'themeflex' ); ?></div>
							<div class="tf-rst-story__award-sub"><?php esc_html_e( 'Michelin Guide 2025', 'themeflex' ); ?></div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</section>

	<?php
	/* ============================================================
	   5. MENU PREVIEW
	   ============================================================ */
	?>
	<section class="tf-rst-menu" aria-labelledby="tf-rst-menu-title">
		<div class="tf-rst-container">
			<div class="tf-rst-menu__header">
				<div class="tf-rst-eyebrow">
					<span class="tf-rst-eyebrow-line"></span>
					<?php esc_html_e( 'Menu Highlights', 'themeflex' ); ?>
					<span class="tf-rst-eyebrow-line"></span>
				</div>
				<h2 id="tf-rst-menu-title" class="tf-rst-section-title">
					<?php esc_html_e( 'A Taste of What\'s Inside', 'themeflex' ); ?>
				</h2>
				<p class="tf-rst-section-sub">
					<?php esc_html_e( 'A curated preview of our seasonal menu. From delicate starters to indulgent desserts, there\'s something for every palate.', 'themeflex' ); ?>
				</p>
			</div>

			<div class="tf-rst-menu__tabs" role="tablist">
				<button class="tf-rst-menu__tab active" role="tab" aria-selected="true"><?php esc_html_e( 'Starters', 'themeflex' ); ?></button>
				<button class="tf-rst-menu__tab" role="tab" aria-selected="false"><?php esc_html_e( 'Mains', 'themeflex' ); ?></button>
				<button class="tf-rst-menu__tab" role="tab" aria-selected="false"><?php esc_html_e( 'Desserts', 'themeflex' ); ?></button>
				<button class="tf-rst-menu__tab" role="tab" aria-selected="false"><?php esc_html_e( 'Wine', 'themeflex' ); ?></button>
			</div>

			<?php
			$tf_rst_menu_items = array(
				array( 'icon' => 'soup', 'name' => esc_html__( 'Celeriac Velouté', 'themeflex' ), 'desc' => esc_html__( 'Smoked celeriac, chestnut cream, truffle oil, crispy capers', 'themeflex' ), 'price' => '$18', 'allergy' => esc_html__( 'Dairy, Nuts', 'themeflex' ) ),
				array( 'icon' => 'egg', 'name' => esc_html__( 'Burrata & Heritage Tomatoes', 'themeflex' ), 'desc' => esc_html__( 'Hand-torn burrata, vine tomatoes, basil oil, aged balsamic', 'themeflex' ), 'price' => '$21', 'allergy' => esc_html__( 'Dairy', 'themeflex' ) ),
				array( 'icon' => 'fish', 'name' => esc_html__( 'Seared Scallops', 'themeflex' ), 'desc' => esc_html__( 'Hand-dived scallops, cauliflower purée, hazelnut butter, caviar', 'themeflex' ), 'price' => '$29', 'allergy' => esc_html__( 'Shellfish', 'themeflex' ) ),
				array( 'icon' => 'salad', 'name' => esc_html__( 'Smoked Salmon Tartare', 'themeflex' ), 'desc' => esc_html__( 'Cold-smoked salmon, cucumber, crème fraîche, dill, rye crisps', 'themeflex' ), 'price' => '$24', 'allergy' => esc_html__( 'Fish, Dairy', 'themeflex' ) ),
			);
			?>
			<div class="tf-rst-menu__list">
				<?php foreach ( $tf_rst_menu_items as $tf_rst_item ) : ?>
				<div class="tf-rst-menu-item tf-rst-reveal">
					<div class="tf-rst-menu-item__icon">
						<?php echo tf_icon_get( esc_attr( $tf_rst_item['icon'] ), 22 ); ?>
					</div>
					<div style="flex:1;">
						<div class="tf-rst-menu-item__name"><?php echo $tf_rst_item['name']; ?></div>
						<div class="tf-rst-menu-item__desc"><?php echo $tf_rst_item['desc']; ?></div>
						<div class="tf-rst-menu-item__row">
							<div class="tf-rst-menu-item__price"><?php echo esc_html( $tf_rst_item['price'] ); ?></div>
							<div class="tf-rst-menu-item__allergy">
								<?php echo tf_icon_get( 'info', 12 ); ?>
								<?php echo $tf_rst_item['allergy']; ?>
							</div>
						</div>
					</div>
				</div>
				<?php endforeach; ?>
			</div>

		</div>
	</section>

	<?php
	/* ============================================================
	   6. TESTIMONIALS
	   ============================================================ */
	?>
	<section class="tf-rst-testimonials" aria-labelledby="tf-rst-reviews-title">
		<div class="tf-rst-container">
			<div class="tf-rst-testimonials__header">
				<div class="tf-rst-eyebrow">
					<span class="tf-rst-eyebrow-line"></span>
					<?php esc_html_e( 'Guest Reviews', 'themeflex' ); ?>
					<span class="tf-rst-eyebrow-line"></span>
				</div>
				<h2 id="tf-rst-reviews-title" class="tf-rst-section-title">
					<?php esc_html_e( 'What Our Guests Say', 'themeflex' ); ?>
				</h2>
				<p class="tf-rst-section-sub">
					<?php esc_html_e( 'Over 3,200 reviews on Google and TripAdvisor — consistently rated 4.9 out of 5. We\'re proud of every single one.', 'themeflex' ); ?>
				</p>
			</div>

			<div class="tf-rst-testimonials__grid">

				<article class="tf-rst-review tf-rst-reveal">
					<div class="tf-rst-review__quote-icon"><?php echo tf_icon_get( 'quote', 28 ); ?></div>
					<div class="tf-rst-review__stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
					<p class="tf-rst-review__text"><?php esc_html_e( 'An extraordinary evening. The Wagyu tenderloin was the finest piece of beef I\'ve had anywhere in the world. The sommelier\'s pairing was spot-on. We will absolutely return.', 'themeflex' ); ?></p>
					<div class="tf-rst-review__author">
						<div class="tf-rst-review__avatar tf-rst-review__avatar--1" aria-hidden="true">JW</div>
						<div>
							<div class="tf-rst-review__name"><?php esc_html_e( 'James W.', 'themeflex' ); ?></div>
							<div class="tf-rst-review__meta"><?php esc_html_e( 'Google · Visited March 2025', 'themeflex' ); ?></div>
						</div>
					</div>
				</article>

				<article class="tf-rst-review tf-rst-reveal">
					<div class="tf-rst-review__quote-icon"><?php echo tf_icon_get( 'quote', 28 ); ?></div>
					<div class="tf-rst-review__stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
					<p class="tf-rst-review__text"><?php esc_html_e( 'We celebrated our anniversary here and the team made it utterly magical. The tasting menu was a journey — each course better than the last. The atmosphere is warm without being stuffy.', 'themeflex' ); ?></p>
					<div class="tf-rst-review__author">
						<div class="tf-rst-review__avatar tf-rst-review__avatar--2" aria-hidden="true">CM</div>
						<div>
							<div class="tf-rst-review__name"><?php esc_html_e( 'Claire & Marc', 'themeflex' ); ?></div>
							<div class="tf-rst-review__meta"><?php esc_html_e( 'TripAdvisor · Visited February 2025', 'themeflex' ); ?></div>
						</div>
					</div>
				</article>

				<article class="tf-rst-review tf-rst-reveal">
					<div class="tf-rst-review__quote-icon"><?php echo tf_icon_get( 'quote', 28 ); ?></div>
					<div class="tf-rst-review__stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
					<p class="tf-rst-review__text"><?php esc_html_e( 'As a food writer I\'ve visited hundreds of restaurants. This one genuinely surprised me. The scallop starter alone was worth the trip. Chef Elena\'s approach to local sourcing is the real deal.', 'themeflex' ); ?></p>
					<div class="tf-rst-review__author">
						<div class="tf-rst-review__avatar tf-rst-review__avatar--3" aria-hidden="true">RB</div>
						<div>
							<div class="tf-rst-review__name"><?php esc_html_e( 'Rachel B.', 'themeflex' ); ?></div>
							<div class="tf-rst-review__meta"><?php esc_html_e( 'Food Critic · Visited January 2025', 'themeflex' ); ?></div>
						</div>
					</div>
				</article>

			</div>
		</div>
	</section>

	<?php
	/* ============================================================
	   7. RESERVATION CTA
	   ============================================================ */
	?>
	<section class="tf-rst-reservation" aria-labelledby="tf-rst-res-title">
		<div class="tf-rst-container">
			<div class="tf-rst-reservation__inner">
				<div class="tf-rst-reservation__orb tf-rst-reservation__orb--1" aria-hidden="true"></div>
				<div class="tf-rst-reservation__orb tf-rst-reservation__orb--2" aria-hidden="true"></div>

				<div class="tf-rst-reservation__content">
					<div class="tf-rst-reservation__tag">
						<?php echo tf_icon_get( 'calendar', 13 ); ?>
						<?php esc_html_e( 'Reservations', 'themeflex' ); ?>
					</div>
					<h2 id="tf-rst-res-title" class="tf-rst-reservation__title">
						<?php esc_html_e( 'Book Your Table Today', 'themeflex' ); ?>
					</h2>
					<p class="tf-rst-reservation__desc">
						<?php esc_html_e( 'Whether it\'s an intimate dinner for two, a family celebration, or a private dining event, we\'ll make it memorable.', 'themeflex' ); ?>
					</p>
					<div class="tf-rst-reservation__perks">
						<div class="tf-rst-reservation__perk">
							<?php echo tf_icon_get( 'check-circle', 16 ); ?>
							<span><?php esc_html_e( 'Instant confirmation by email', 'themeflex' ); ?></span>
						</div>
						<div class="tf-rst-reservation__perk">
							<?php echo tf_icon_get( 'check-circle', 16 ); ?>
							<span><?php esc_html_e( 'Private dining available for 8–30 guests', 'themeflex' ); ?></span>
						</div>
						<div class="tf-rst-reservation__perk">
							<?php echo tf_icon_get( 'check-circle', 16 ); ?>
							<span><?php esc_html_e( 'Special dietary requirements catered for', 'themeflex' ); ?></span>
						</div>
						<div class="tf-rst-reservation__perk">
							<?php echo tf_icon_get( 'check-circle', 16 ); ?>
							<span><?php esc_html_e( 'Cancel or modify up to 24 hours before', 'themeflex' ); ?></span>
						</div>
					</div>
					<div style="display:flex;align-items:center;gap:1rem;flex-wrap:wrap;">
						<a href="tel:+15550001234" class="tf-rst-btn-ghost">
							<?php echo tf_icon_get( 'phone', 17 ); ?>
							<?php esc_html_e( '+1 (555) 000-1234', 'themeflex' ); ?>
						</a>
					</div>
				</div>

				<div class="tf-rst-res-form" role="form" aria-labelledby="tf-rst-res-form-title">
					<h3 id="tf-rst-res-form-title" class="tf-rst-res-form__title">
						<?php echo tf_icon_get( 'calendar', 18 ); ?>
						<?php esc_html_e( 'Request a Reservation', 'themeflex' ); ?>
					</h3>
					<form method="post" action="<?php echo esc_url( home_url( '/reservations' ) ); ?>">
						<?php wp_nonce_field( 'tf_reservation', 'tf_reservation_nonce' ); ?>
						<div class="tf-rst-form-group">
							<label class="tf-rst-form-label" for="tf-rst-name"><?php esc_html_e( 'Full Name', 'themeflex' ); ?></label>
							<input type="text" id="tf-rst-name" name="full_name" class="tf-rst-form-input" placeholder="<?php esc_attr_e( 'Your full name', 'themeflex' ); ?>" required>
						</div>
						<div class="tf-rst-form-row">
							<div class="tf-rst-form-group">
								<label class="tf-rst-form-label" for="tf-rst-date"><?php esc_html_e( 'Date', 'themeflex' ); ?></label>
								<input type="date" id="tf-rst-date" name="date" class="tf-rst-form-input" required>
							</div>
							<div class="tf-rst-form-group">
								<label class="tf-rst-form-label" for="tf-rst-time"><?php esc_html_e( 'Time', 'themeflex' ); ?></label>
								<select id="tf-rst-time" name="time" class="tf-rst-form-select" required>
									<option value=""><?php esc_html_e( 'Select time', 'themeflex' ); ?></option>
									<option>12:00</option><option>12:30</option>
									<option>13:00</option><option>13:30</option>
									<option>18:00</option><option>18:30</option>
									<option>19:00</option><option>19:30</option>
									<option>20:00</option><option>20:30</option>
									<option>21:00</option>
								</select>
							</div>
						</div>
						<div class="tf-rst-form-row">
							<div class="tf-rst-form-group">
								<label class="tf-rst-form-label" for="tf-rst-guests"><?php esc_html_e( 'Guests', 'themeflex' ); ?></label>
								<select id="tf-rst-guests" name="guests" class="tf-rst-form-select" required>
									<option value=""><?php esc_html_e( 'How many?', 'themeflex' ); ?></option>
									<?php for ( $g = 1; $g <= 10; $g++ ) : ?>
										<option value="<?php echo esc_attr( $g ); ?>"><?php echo esc_html( $g . ' ' . _n( 'Guest', 'Guests', $g, 'themeflex' ) ); ?></option>
									<?php endfor; ?>
									<option value="10+"><?php esc_html_e( '10+ (Private Dining)', 'themeflex' ); ?></option>
								</select>
							</div>
							<div class="tf-rst-form-group">
								<label class="tf-rst-form-label" for="tf-rst-email"><?php esc_html_e( 'Email', 'themeflex' ); ?></label>
								<input type="email" id="tf-rst-email" name="email" class="tf-rst-form-input" placeholder="<?php esc_attr_e( 'your@email.com', 'themeflex' ); ?>" required>
							</div>
						</div>
						<button type="submit" class="tf-rst-form-submit">
							<?php echo tf_icon_get( 'calendar-check', 18 ); ?>
							<?php esc_html_e( 'Request Reservation', 'themeflex' ); ?>
						</button>
					</form>
				</div>

			</div>
		</div>
	</section>

</main>

<script>
(function() {
	'use strict';

	/* ---- Scroll reveal ---- */
	if ('IntersectionObserver' in window) {
		var reveals = document.querySelectorAll('.tf-rst-reveal');
		var observer = new IntersectionObserver(function(entries) {
			entries.forEach(function(entry, idx) {
				if (entry.isIntersecting) {
					entry.target.style.transitionDelay = (idx % 3) * 90 + 'ms';
					entry.target.classList.add('is-visible');
					observer.unobserve(entry.target);
				}
			});
		}, { threshold: 0.12 });
		reveals.forEach(function(el) { observer.observe(el); });
	} else {
		document.querySelectorAll('.tf-rst-reveal').forEach(function(el) {
			el.classList.add('is-visible');
		});
	}

	/* ---- Menu tabs (UI only) ---- */
	var menuTabs = document.querySelectorAll('.tf-rst-menu__tab');
	menuTabs.forEach(function(tab) {
		tab.addEventListener('click', function() {
			menuTabs.forEach(function(t) {
				t.classList.remove('active');
				t.setAttribute('aria-selected', 'false');
			});
			this.classList.add('active');
			this.setAttribute('aria-selected', 'true');
		});
	});

})();
</script>

<?php get_footer(); ?>
