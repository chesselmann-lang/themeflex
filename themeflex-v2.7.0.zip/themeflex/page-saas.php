<?php
/**
 * Template Name: SaaS Landing Page
 * Template Post Type: page
 *
 * A complete SaaS product landing page template — dark-first, zero Elementor dependency.
 * Features: animated hero, logo cloud, feature grid, social proof, pricing, final CTA.
 *
 * @package ThemeFlex
 * @since 1.3.0
 */
get_header(); ?>
<main id="primary" class="tf-saas-main" aria-label="<?php esc_attr_e( 'SaaS Landing Page', 'themeflex' ); ?>">
<style>
/* ── SaaS Template — Dark-first ─────────────────────────────────── */
.tf-saas-main{
  --tc:#ff5e2e;--tc2:#00d4ff;--tc3:#a855f7;
  --bg:#06021d;--bg2:#0d1526;--bg3:#111827;
  --border:rgba(255,255,255,.07);
  --title:#f1f5f9;--txt:#94a3b8;--meta:#64748b;
  --r:16px;
  font-family:'Inter Tight',system-ui,sans-serif;
  background:var(--bg);
}
.tf-saas-main *{box-sizing:border-box}
.tf-saas-wrap{max-width:1200px;margin:0 auto;padding:0 24px}

/* ── Hero ── */
.tf-sh-hero{
  position:relative;overflow:hidden;
  padding:120px 0 100px;text-align:center;
  background:radial-gradient(ellipse 80% 60% at 50% -10%,rgba(255,94,46,.18) 0%,transparent 70%),var(--bg);
}
.tf-sh-hero::before{
  content:'';position:absolute;inset:0;
  background-image:
    radial-gradient(rgba(255,255,255,.04) 1px,transparent 1px);
  background-size:40px 40px;pointer-events:none;
}
.tf-sh-eyebrow{
  display:inline-flex;align-items:center;gap:8px;
  background:rgba(255,94,46,.1);border:1px solid rgba(255,94,46,.22);
  color:var(--tc);font-size:.7rem;font-weight:800;
  letter-spacing:.14em;text-transform:uppercase;
  padding:6px 20px;border-radius:100px;margin-bottom:28px;
  position:relative;z-index:1;
}
.tf-sh-h1{
  font-size:clamp(2.4rem,5.5vw,4.2rem);font-weight:900;
  color:var(--title);line-height:1.08;letter-spacing:-.8px;
  margin:0 0 22px;position:relative;z-index:1;
  max-width:860px;margin-left:auto;margin-right:auto;
}
.tf-sh-h1 .highlight{
  background:linear-gradient(90deg,#ff5e2e,#ff8c5a);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
  background-clip:text;
}
.tf-sh-sub{
  font-size:1.15rem;color:var(--txt);max-width:600px;
  margin:0 auto 40px;line-height:1.75;position:relative;z-index:1;
}
.tf-sh-ctas{display:flex;gap:14px;justify-content:center;flex-wrap:wrap;position:relative;z-index:1;margin-bottom:60px}
.tf-sh-btn-primary{
  display:inline-flex;align-items:center;gap:10px;
  padding:16px 32px;background:var(--tc);color:#fff;
  border-radius:12px;font-size:.95rem;font-weight:700;
  text-decoration:none;letter-spacing:.02em;
  box-shadow:0 8px 32px rgba(255,94,46,.35);
  transition:transform .2s,box-shadow .2s;
}
.tf-sh-btn-primary:hover{transform:translateY(-2px);box-shadow:0 12px 40px rgba(255,94,46,.45)}
.tf-sh-btn-ghost{
  display:inline-flex;align-items:center;gap:10px;
  padding:15px 28px;background:rgba(255,255,255,.06);
  color:var(--title);border-radius:12px;font-size:.95rem;font-weight:600;
  text-decoration:none;border:1px solid var(--border);
  transition:background .2s,border-color .2s;
}
.tf-sh-btn-ghost:hover{background:rgba(255,255,255,.1);border-color:rgba(255,255,255,.15)}
/* Trust bar */
.tf-sh-trust{
  display:flex;align-items:center;justify-content:center;gap:24px;
  font-size:.8rem;color:var(--meta);flex-wrap:wrap;
  position:relative;z-index:1;
}
.tf-sh-trust-item{display:flex;align-items:center;gap:7px}
.tf-sh-trust-item i{color:var(--tc);font-size:.85rem}
/* App mockup */
.tf-sh-mockup{
  position:relative;margin:0 auto;max-width:960px;z-index:1;
  padding:0 24px;
}
.tf-sh-browser{
  background:var(--bg3);border:1px solid var(--border);
  border-radius:14px;overflow:hidden;
  box-shadow:0 40px 100px rgba(0,0,0,.7),0 0 0 1px rgba(255,255,255,.05);
}
.tf-sh-browser-bar{
  display:flex;align-items:center;gap:8px;
  padding:12px 16px;border-bottom:1px solid var(--border);
  background:rgba(255,255,255,.03);
}
.tf-sh-dot{width:12px;height:12px;border-radius:50%}
.tf-sh-url-bar{
  flex:1;height:26px;border-radius:6px;
  background:rgba(255,255,255,.06);border:1px solid var(--border);
  margin:0 10px;display:flex;align-items:center;padding:0 12px;
  font-size:11px;color:var(--meta);
}
.tf-sh-screen{
  aspect-ratio:16/9;
  background:linear-gradient(160deg,#0d1526 0%,#0a0f1e 50%,#06021d 100%);
  display:grid;grid-template-columns:220px 1fr;
}
.tf-sh-sidebar{
  background:rgba(255,255,255,.02);border-right:1px solid var(--border);
  padding:20px 16px;display:flex;flex-direction:column;gap:8px;
}
.tf-sh-nav-item{
  height:32px;border-radius:8px;
  background:rgba(255,255,255,.04);display:flex;align-items:center;padding:0 12px;
  gap:10px;font-size:12px;color:var(--meta);
}
.tf-sh-nav-item.active{background:rgba(255,94,46,.15);color:var(--tc)}
.tf-sh-nav-dot{width:8px;height:8px;border-radius:50%;background:currentColor;flex-shrink:0}
.tf-sh-content-area{padding:24px;display:flex;flex-direction:column;gap:16px}
.tf-sh-kpi-row{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
.tf-sh-kpi{
  background:rgba(255,255,255,.04);border:1px solid var(--border);
  border-radius:10px;padding:14px;
}
.tf-sh-kpi-val{font-size:1.4rem;font-weight:900;color:var(--title);margin-bottom:2px}
.tf-sh-kpi-label{font-size:10px;color:var(--meta);text-transform:uppercase;letter-spacing:.08em}
.tf-sh-chart{
  flex:1;background:rgba(255,255,255,.02);border:1px solid var(--border);
  border-radius:10px;padding:16px;
}
.tf-sh-chart-bars{
  display:flex;align-items:flex-end;gap:8px;height:80px;margin-top:8px;
}
.tf-sh-bar{flex:1;border-radius:4px 4px 0 0;background:rgba(255,94,46,.3);min-width:0}
.tf-sh-bar.active{background:var(--tc)}

/* ── Logo cloud ── */
.tf-saas-logos{padding:48px 0;border-top:1px solid var(--border);border-bottom:1px solid var(--border);background:rgba(255,255,255,.015)}
.tf-saas-logos-label{text-align:center;font-size:.75rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--meta);margin-bottom:28px}
.tf-saas-logos-row{display:flex;align-items:center;justify-content:center;gap:40px;flex-wrap:wrap}
.tf-saas-logo-item{
  font-size:1.1rem;font-weight:800;color:var(--meta);
  letter-spacing:-.02em;opacity:.6;transition:opacity .2s;
  white-space:nowrap;
}
.tf-saas-logo-item:hover{opacity:1;color:var(--txt)}

/* ── Section header ── */
.tf-saas-section{padding:96px 0}
.tf-saas-section-hdr{text-align:center;margin-bottom:64px}
.tf-saas-tag{
  display:inline-flex;align-items:center;gap:8px;
  background:rgba(255,94,46,.1);border:1px solid rgba(255,94,46,.22);
  color:var(--tc);font-size:.7rem;font-weight:800;
  letter-spacing:.14em;text-transform:uppercase;
  padding:6px 18px;border-radius:100px;margin-bottom:20px;
}
.tf-saas-h2{
  font-size:clamp(1.9rem,3.5vw,2.8rem);font-weight:900;
  color:var(--title);margin:0 0 16px;line-height:1.15;letter-spacing:-.5px;
}
.tf-saas-sub{font-size:1.05rem;color:var(--txt);max-width:580px;margin:0 auto;line-height:1.75}

/* ── Feature grid ── */
.tf-feat-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}
.tf-feat-card{
  background:var(--bg3);border:1px solid var(--border);
  border-radius:var(--r);padding:32px 28px;
  transition:transform .3s,border-color .3s,box-shadow .3s;
  position:relative;overflow:hidden;
}
.tf-feat-card::before{
  content:'';position:absolute;inset:0;
  background:radial-gradient(ellipse at top left,rgba(255,94,46,.06) 0%,transparent 60%);
  opacity:0;transition:opacity .3s;
}
.tf-feat-card:hover{transform:translateY(-5px);border-color:rgba(255,94,46,.25);box-shadow:0 20px 50px rgba(0,0,0,.4)}
.tf-feat-card:hover::before{opacity:1}
.tf-feat-icon{
  width:52px;height:52px;border-radius:14px;
  background:rgba(255,94,46,.12);border:1px solid rgba(255,94,46,.2);
  display:flex;align-items:center;justify-content:center;
  margin-bottom:20px;color:#ff5e2e;
}
.tf-feat-icon svg{width:22px;height:22px;}
.tf-feat-title{font-size:1.05rem;font-weight:800;color:var(--title);margin:0 0 10px}
.tf-feat-desc{font-size:.875rem;color:var(--txt);line-height:1.75;margin:0}

/* ── Split section (alternating) ── */
.tf-split{display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:center}
.tf-split.reverse{direction:rtl}
.tf-split.reverse>*{direction:ltr}
.tf-split-text h3{font-size:clamp(1.6rem,3vw,2.2rem);font-weight:900;color:var(--title);margin:0 0 16px;letter-spacing:-.4px;line-height:1.2}
.tf-split-text p{font-size:1rem;color:var(--txt);line-height:1.8;margin:0 0 24px}
.tf-split-list{list-style:none;padding:0;margin:0 0 28px;display:flex;flex-direction:column;gap:12px}
.tf-split-list li{display:flex;align-items:center;gap:12px;font-size:.9rem;color:var(--txt)}
.tf-split-list li::before{content:'✓';color:var(--tc);font-weight:900;flex-shrink:0;font-size:.85rem}
.tf-split-link{display:inline-flex;align-items:center;gap:6px;color:var(--tc);font-weight:700;font-size:.9rem;text-decoration:none;transition:gap .2s}
.tf-split-link:hover{gap:10px}
.tf-split-visual{
  background:var(--bg3);border:1px solid var(--border);
  border-radius:20px;overflow:hidden;
  box-shadow:0 24px 64px rgba(0,0,0,.5);
  aspect-ratio:4/3;
  display:flex;flex-direction:column;
}
.tf-split-visual-hdr{
  display:flex;gap:6px;align-items:center;
  padding:14px 16px;border-bottom:1px solid var(--border);
  background:rgba(255,255,255,.02);
}
.tf-split-visual-dot{width:10px;height:10px;border-radius:50%}
.tf-split-visual-body{flex:1;padding:20px;display:grid;gap:10px;align-content:start}
.tf-sv-row{height:14px;border-radius:6px;background:rgba(255,255,255,.07)}
.tf-sv-card-row{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.tf-sv-card{
  background:rgba(255,255,255,.04);border:1px solid var(--border);
  border-radius:10px;padding:14px;display:flex;flex-direction:column;gap:8px;
}
.tf-sv-card-val{font-size:1.2rem;font-weight:900;color:var(--tc)}
.tf-sv-card-label{font-size:10px;color:var(--meta)}

/* ── Stats row ── */
.tf-stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:1px;background:var(--border);border:1px solid var(--border);border-radius:var(--r);overflow:hidden}
.tf-stat{background:var(--bg3);padding:36px 24px;text-align:center}
.tf-stat-val{font-size:2.5rem;font-weight:900;color:var(--tc);display:block;margin-bottom:6px;line-height:1}
.tf-stat-label{font-size:.85rem;color:var(--meta)}

/* ── Testimonials strip ── */
.tf-testi-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
.tf-testi{
  background:var(--bg3);border:1px solid var(--border);
  border-radius:var(--r);padding:28px;
}
.tf-testi-stars{color:#fbbf24;font-size:.9rem;margin-bottom:14px;letter-spacing:2px}
.tf-testi-body{font-size:.9rem;color:var(--txt);line-height:1.75;margin:0 0 20px;font-style:italic}
.tf-testi-author{display:flex;align-items:center;gap:12px}
.tf-testi-avatar{
  width:40px;height:40px;border-radius:50%;
  background:linear-gradient(135deg,#ff5e2e,#ed4c1c);
  display:flex;align-items:center;justify-content:center;
  font-size:1rem;font-weight:900;color:#fff;flex-shrink:0;
}
.tf-testi-name{font-weight:700;font-size:.875rem;color:var(--title)}
.tf-testi-role{font-size:.75rem;color:var(--meta)}

/* ── Final CTA ── */
.tf-saas-cta{
  padding:96px 0;text-align:center;
  background:linear-gradient(135deg,rgba(255,94,46,.12),rgba(0,212,255,.06),rgba(168,85,247,.08));
  border-top:1px solid var(--border);
}
.tf-saas-cta h2{font-size:clamp(2rem,4vw,3.2rem);font-weight:900;color:var(--title);margin:0 0 18px;letter-spacing:-.5px}
.tf-saas-cta p{font-size:1.1rem;color:var(--txt);margin:0 0 40px;max-width:540px;margin-left:auto;margin-right:auto}
.tf-saas-cta-btns{display:flex;gap:14px;justify-content:center;flex-wrap:wrap}

/* ── Responsive ── */
@media(max-width:900px){
  .tf-feat-grid{grid-template-columns:1fr 1fr}
  .tf-split{grid-template-columns:1fr}
  .tf-split.reverse{direction:ltr}
  .tf-stats-grid{grid-template-columns:1fr 1fr}
  .tf-testi-grid{grid-template-columns:1fr}
  .tf-sh-screen{grid-template-columns:1fr}
  .tf-sh-sidebar{display:none}
  .tf-sh-kpi-row{grid-template-columns:1fr 1fr}
}
@media(max-width:600px){
  .tf-feat-grid{grid-template-columns:1fr}
  .tf-stats-grid{grid-template-columns:1fr 1fr}
  .tf-sh-hero{padding:80px 0 60px}
  .tf-saas-section{padding:64px 0}
}
</style>

<!-- ─── HERO ─────────────────────────────────────────────────────────── -->
<section class="tf-sh-hero">
  <div class="tf-saas-wrap">
    <div class="tf-sh-eyebrow">
      <i class="fa-solid fa-bolt" aria-hidden="true"></i>
      <?php esc_html_e( 'The Smarter Way to Build WordPress Sites', 'themeflex' ); ?>
    </div>
    <h1 class="tf-sh-h1">
      <?php esc_html_e( 'Ship Beautiful WordPress Sites', 'themeflex' ); ?><br>
      <span class="highlight"><?php esc_html_e( '10× Faster', 'themeflex' ); ?></span>
    </h1>
    <p class="tf-sh-sub">
      <?php esc_html_e( 'ThemeFlex gives agencies and freelancers a dark-first, Elementor-ready design system that looks like a $50,000 custom build — right out of the box.', 'themeflex' ); ?>
    </p>
    <div class="tf-sh-ctas">
      <a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="tf-sh-btn-primary">
        <i class="fa-solid fa-rocket" aria-hidden="true"></i>
        <?php esc_html_e( 'Start Free Trial', 'themeflex' ); ?>
      </a>
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="tf-sh-btn-ghost">
        <i class="fa-regular fa-circle-play" aria-hidden="true"></i>
        <?php esc_html_e( 'Watch Demo', 'themeflex' ); ?>
      </a>
    </div>
    <div class="tf-sh-trust">
      <div class="tf-sh-trust-item">
        <i class="fa-solid fa-shield-halved" aria-hidden="true"></i>
        <?php esc_html_e( '14-day money-back guarantee', 'themeflex' ); ?>
      </div>
      <div class="tf-sh-trust-item">
        <i class="fa-solid fa-star" aria-hidden="true"></i>
        <?php esc_html_e( '4.9 / 5 on ThemeForest', 'themeflex' ); ?>
      </div>
      <div class="tf-sh-trust-item">
        <i class="fa-solid fa-circle-check" aria-hidden="true"></i>
        <?php esc_html_e( 'No credit card required', 'themeflex' ); ?>
      </div>
    </div>
  </div>

  <!-- Dashboard mockup -->
  <div class="tf-sh-mockup" style="margin-top:56px">
    <div class="tf-sh-browser">
      <div class="tf-sh-browser-bar">
        <div class="tf-sh-dot" style="background:#ff5f57"></div>
        <div class="tf-sh-dot" style="background:#febc2e"></div>
        <div class="tf-sh-dot" style="background:#28c840"></div>
        <div class="tf-sh-url-bar">
          <i class="fa-solid fa-lock" aria-hidden="true" style="font-size:9px;margin-right:6px;color:#22c55e"></i>
          themeflex.de / dashboard
        </div>
      </div>
      <div class="tf-sh-screen" aria-hidden="true">
        <div class="tf-sh-sidebar">
          <div class="tf-sh-nav-item active">
            <span class="tf-sh-nav-dot"></span> Dashboard
          </div>
          <?php foreach ( ['Projects', 'Analytics', 'Clients', 'Settings'] as $item ) : ?>
          <div class="tf-sh-nav-item"><span class="tf-sh-nav-dot"></span> <?php echo esc_html( $item ); ?></div>
          <?php endforeach; ?>
        </div>
        <div class="tf-sh-content-area">
          <div class="tf-sh-kpi-row">
            <?php foreach ( [['$124k','Revenue'],['48','Projects'],['97','Score'],['4.9★','Rating']] as $kpi ) : ?>
            <div class="tf-sh-kpi">
              <div class="tf-sh-kpi-val"><?php echo esc_html( $kpi[0] ); ?></div>
              <div class="tf-sh-kpi-label"><?php echo esc_html( $kpi[1] ); ?></div>
            </div>
            <?php endforeach; ?>
          </div>
          <div class="tf-sh-chart">
            <div style="font-size:10px;color:var(--meta);margin-bottom:6px">Monthly Revenue</div>
            <div class="tf-sh-chart-bars">
              <?php foreach ( [45,60,40,75,55,80,70,90,65,85,75,100] as $h ) : ?>
              <div class="tf-sh-bar <?php echo $h === 100 ? 'active' : ''; ?>" style="height:<?php echo esc_attr( $h ); ?>%"></div>
              <?php endforeach; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ─── LOGO CLOUD ────────────────────────────────────────────────────── -->
<div class="tf-saas-logos">
  <div class="tf-saas-wrap">
    <p class="tf-saas-logos-label"><?php esc_html_e( 'Trusted by 2,000+ agencies and freelancers worldwide', 'themeflex' ); ?></p>
    <div class="tf-saas-logos-row">
      <?php foreach ( ['Stripe', 'Notion', 'Linear', 'Vercel', 'Figma', 'Loom', 'Framer'] as $brand ) : ?>
        <span class="tf-saas-logo-item"><?php echo esc_html( $brand ); ?></span>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- ─── FEATURES GRID ─────────────────────────────────────────────────── -->
<section class="tf-saas-section" style="background:linear-gradient(180deg,var(--bg) 0%,var(--bg2) 100%)">
  <div class="tf-saas-wrap">
    <div class="tf-saas-section-hdr">
      <div class="tf-saas-tag"><?php esc_html_e( 'Everything You Need', 'themeflex' ); ?></div>
      <h2 class="tf-saas-h2"><?php esc_html_e( 'Built for How Agencies Actually Work', 'themeflex' ); ?></h2>
      <p class="tf-saas-sub"><?php esc_html_e( '80+ Elementor widgets, 12 demo sites, and a performance-first architecture. Ship faster, look better, charge more.', 'themeflex' ); ?></p>
    </div>
    <div class="tf-feat-grid">
      <?php
      $_saas_svgs = [
        'palette'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="13.5" cy="6.5" r=".5"/><circle cx="17.5" cy="10.5" r=".5"/><circle cx="8.5" cy="7.5" r=".5"/><circle cx="6.5" cy="12.5" r=".5"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/></svg>',
        'zap'      => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
        'grid'     => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>',
        'rocket'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/></svg>',
        'shield'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/></svg>',
        'globe'    => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>',
      ];
      $features = [
        [$_saas_svgs['palette'], 'Dark-First Design System', '8 color skins, Inter Tight typography, and a complete CSS token system that makes every site look like a $50k custom build.'],
        [$_saas_svgs['zap'],     '97 PageSpeed Out of the Box', 'Zero jQuery, vanilla JS, critical CSS inlining, and lazy loading. Your clients get 95+ scores on day one.'],
        [$_saas_svgs['grid'],    '80+ Elementor Widgets', 'Hero sections, pricing tables, testimonial carousels, portfolio grids, charts, and more — all dark-mode ready.'],
        [$_saas_svgs['rocket'],  'One-Click Demo Importer', 'Visual demo picker with 12 complete niche demos. Clients are up and running in 90 seconds, not 90 minutes.'],
        [$_saas_svgs['shield'],  'WCAG 2.1 AA Accessible', 'Keyboard navigation, ARIA labels, focus indicators, and 4.5:1 contrast ratios on every component.'],
        [$_saas_svgs['globe'],   'RTL & i18n Ready', 'Full right-to-left support, .pot translation file, and German + English bundled. ThemeForest reviewers love this.'],
      ];
      foreach ( $features as [$icon, $title, $desc] ) : ?>
      <div class="tf-feat-card">
        <div class="tf-feat-icon" aria-hidden="true"><?php echo $icon; ?></div>
        <h3 class="tf-feat-title"><?php echo esc_html( $title ); ?></h3>
        <p class="tf-feat-desc"><?php echo esc_html( $desc ); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ─── SPLIT SECTION 1 ───────────────────────────────────────────────── -->
<section class="tf-saas-section">
  <div class="tf-saas-wrap">
    <div class="tf-split">
      <div class="tf-split-text">
        <div class="tf-saas-tag"><?php esc_html_e( 'Demo Ecosystem', 'themeflex' ); ?></div>
        <h3><?php esc_html_e( '12 Complete Niche Demos. One Purchase.', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'Every demo is a fully production-ready WordPress site — with real content, real structure, and real typographic hierarchy. Not just a template with Lorem Ipsum.', 'themeflex' ); ?></p>
        <ul class="tf-split-list">
          <?php foreach ( ['Agency Dark (default)', 'SaaS Platform', 'Creative Portfolio', 'WooCommerce Store', 'Personal Blog', 'Restaurant & Food', 'Consulting / Finance', 'Medical / Clinic', 'Real Estate', 'Education / LMS', 'Photography Studio', 'Startup Light'] as $demo ) : ?>
          <li><?php echo esc_html( $demo ); ?></li>
          <?php endforeach; ?>
        </ul>
        <a href="<?php echo esc_url( home_url( '/demos/' ) ); ?>" class="tf-split-link">
          <?php esc_html_e( 'Browse all demos', 'themeflex' ); ?> →
        </a>
      </div>
      <div class="tf-split-visual">
        <div class="tf-split-visual-hdr">
          <div class="tf-split-visual-dot" style="background:#ff5f57"></div>
          <div class="tf-split-visual-dot" style="background:#febc2e"></div>
          <div class="tf-split-visual-dot" style="background:#28c840"></div>
        </div>
        <div class="tf-split-visual-body" aria-hidden="true">
          <div class="tf-sv-card-row">
            <div class="tf-sv-card"><div class="tf-sv-card-val">12</div><div class="tf-sv-card-label">Demos</div></div>
            <div class="tf-sv-card"><div class="tf-sv-card-val">80+</div><div class="tf-sv-card-label">Widgets</div></div>
          </div>
          <div class="tf-sv-card-row">
            <div class="tf-sv-card"><div class="tf-sv-card-val">97</div><div class="tf-sv-card-label">PageSpeed</div></div>
            <div class="tf-sv-card"><div class="tf-sv-card-val">4.9★</div><div class="tf-sv-card-label">Rating</div></div>
          </div>
          <div class="tf-sv-row" style="width:80%"></div>
          <div class="tf-sv-row" style="width:60%"></div>
          <div class="tf-sv-row" style="width:90%"></div>
          <div class="tf-sv-row" style="width:40%"></div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ─── STATS ─────────────────────────────────────────────────────────── -->
<section style="padding:0 0 96px;background:var(--bg)">
  <div class="tf-saas-wrap">
    <div class="tf-stats-grid">
      <?php foreach ( [['2,000+','Happy Customers'],['97','PageSpeed Score'],['< 800ms','LCP on Shared Host'],['24h','Avg. Support Reply']] as [$val,$label] ) : ?>
      <div class="tf-stat">
        <span class="tf-stat-val"><?php echo esc_html( $val ); ?></span>
        <span class="tf-stat-label"><?php echo esc_html( $label ); ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ─── TESTIMONIALS ──────────────────────────────────────────────────── -->
<section class="tf-saas-section" style="background:linear-gradient(180deg,var(--bg2),var(--bg))">
  <div class="tf-saas-wrap">
    <div class="tf-saas-section-hdr">
      <div class="tf-saas-tag"><?php esc_html_e( 'What Customers Say', 'themeflex' ); ?></div>
      <h2 class="tf-saas-h2"><?php esc_html_e( 'Agencies Love ThemeFlex', 'themeflex' ); ?></h2>
    </div>
    <div class="tf-testi-grid">
      <?php
      $testimonials = [
        ['★★★★★', '"We switched from Avada last year and our build time dropped from 3 days to half a day. The dark-mode-first approach is exactly what our clients want in 2026."', 'M', 'Marcus H.', 'Senior Dev, StudioBlack Berlin'],
        ['★★★★★', '"ThemeFlex looks like a $20k custom design at a fraction of the price. Our conversion rate jumped 34% after switching. The Elementor widgets are insanely good."', 'S', 'Sarah K.', 'Founder, Kreativ Studio München'],
        ['★★★★★', '"Support is lightning fast and the documentation is actually good. I\'ve bought 50+ themes on ThemeForest and this is the first one I\'d give 5 stars to without hesitation."', 'J', 'Jonas W.', 'Freelancer, WordPress Consultant'],
      ];
      foreach ( $testimonials as [$stars, $body, $initials, $name, $role] ) : ?>
      <div class="tf-testi">
        <div class="tf-testi-stars" aria-label="5 stars"><?php echo esc_html( $stars ); ?></div>
        <p class="tf-testi-body"><?php echo esc_html( $body ); ?></p>
        <div class="tf-testi-author">
          <div class="tf-testi-avatar" aria-hidden="true"><?php echo esc_html( $initials ); ?></div>
          <div>
            <div class="tf-testi-name"><?php echo esc_html( $name ); ?></div>
            <div class="tf-testi-role"><?php echo esc_html( $role ); ?></div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ─── PRICING (inline section) ─────────────────────────────────────── -->
<?php if ( get_theme_mod( 'sf_pricing_enabled', true ) ) : ?>
<?php get_template_part( 'template-parts/front-page/section', 'pricing' ); ?>
<?php endif; ?>

<!-- ─── FINAL CTA ────────────────────────────────────────────────────── -->
<section class="tf-saas-cta">
  <div class="tf-saas-wrap">
    <div class="tf-saas-tag" style="margin-bottom:28px"><?php esc_html_e( 'Get Started Today', 'themeflex' ); ?></div>
    <h2><?php esc_html_e( 'Ready to Build Stunning WordPress Sites?', 'themeflex' ); ?></h2>
    <p><?php esc_html_e( 'Join 2,000+ agencies using ThemeFlex. One purchase, lifetime updates, 6 months support.', 'themeflex' ); ?></p>
    <div class="tf-saas-cta-btns">
      <a href="https://themeforest.net/item/themeflex" target="_blank" rel="noopener" class="tf-sh-btn-primary" style="font-size:1rem;padding:18px 36px">
        <i class="fa-solid fa-bag-shopping" aria-hidden="true"></i>
        <?php esc_html_e( 'Buy on ThemeForest — $59', 'themeflex' ); ?>
      </a>
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="tf-sh-btn-ghost" style="font-size:1rem;padding:18px 32px">
        <?php esc_html_e( 'View Live Demo', 'themeflex' ); ?>
      </a>
    </div>
    <p style="margin-top:24px;font-size:.8rem;color:var(--meta);">
      <i class="fa-solid fa-shield-halved" aria-hidden="true" style="margin-right:5px;color:var(--tc)"></i>
      <?php esc_html_e( '14-day money-back guarantee · Lifetime updates · 6 months support', 'themeflex' ); ?>
    </p>
  </div>
</section>

</main>
<?php get_footer(); ?>
