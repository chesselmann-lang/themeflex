<?php
/**
 * Minimal Header (Hamburger Only)
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<header <?php echo implode( ' ', Starter_Flavor_Header_Advanced::get_header_classes() ); ?>>
	<div class="container">
		<div class="site-header-inner">
			<div class="site-branding">
				<?php the_custom_logo(); ?>
				<?php if ( is_home() || is_front_page() ) : ?>
					<h1 class="site-title">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
							<?php bloginfo( 'name' ); ?>
						</a>
					</h1>
				<?php else : ?>
					<p class="site-title">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
							<?php bloginfo( 'name' ); ?>
						</a>
					</p>
				<?php endif; ?>
			</div>

			<button class="mobile-menu-toggle" aria-label="<?php esc_attr_e( 'Toggle menu', 'themeflex' ); ?>">
				<?php echo wp_kses_post( Starter_Flavor_Icons::get_icon( 'menu', 24 ) ); ?>
			</button>
		</div>
	</div>
</header>
