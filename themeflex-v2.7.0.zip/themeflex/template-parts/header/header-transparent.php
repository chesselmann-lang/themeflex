<?php
/**
 * Template part for transparent header layout
 *
 * This template displays a transparent header that overlays on the page,
 * useful for hero sections with background images.
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<header id="site-header" class="site-header header-transparent" role="banner">
	<div class="header-content">
		<div class="header-inner header-transparent-inner">
			<div class="header-left">
				<?php
				/**
				 * Action hook for header branding
				 *
				 * @since 1.0.0
				 */
				do_action( 'themeflex_header_branding' );

				// Display Logo (usually white/light on transparent header)
				if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
					the_custom_logo();
				} else {
					?>
					<h1 class="site-title site-title-transparent">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
							<?php bloginfo( 'name' ); ?>
						</a>
					</h1>
					<?php
				}
				?>
			</div>

			<nav id="site-navigation" class="site-navigation main-navigation header-transparent-nav" role="navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'themeflex' ); ?>">
				<button class="menu-toggle" id="menu-toggle" aria-controls="primary-menu" aria-expanded="false">
					<span class="menu-toggle-text"><?php esc_html_e( 'Menu', 'themeflex' ); ?></span>
					<span class="menu-toggle-icon">
						<span></span>
						<span></span>
						<span></span>
					</span>
				</button>

				<?php
				wp_nav_menu( array(
					'theme_location' => 'main-menu',
					'menu_id'        => 'primary-menu',
					'container'      => false,
					'fallback_cb'    => 'wp_page_menu',
					'depth'          => 3,
					'walker'         => class_exists( 'Starter_Flavor_Nav_Menu_Walker' ) ? new Starter_Flavor_Nav_Menu_Walker() : '',
				) );
				?>
			</nav>

			<div class="header-right">
				<?php
				// Dark Mode Toggle
				if ( themeflex_get_theme_option( 'enable_dark_mode' ) ) {
					?>
					<button class="dark-mode-toggle dark-mode-toggle-transparent" id="dark-mode-toggle" aria-label="<?php esc_attr_e( 'Toggle dark mode', 'themeflex' ); ?>">
						<span class="dark-mode-icon">
							<svg class="light-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
								<circle cx="12" cy="12" r="5"></circle>
								<line x1="12" y1="1" x2="12" y2="3"></line>
								<line x1="12" y1="21" x2="12" y2="23"></line>
								<line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
								<line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
								<line x1="1" y1="12" x2="3" y2="12"></line>
								<line x1="21" y1="12" x2="23" y2="12"></line>
								<line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
								<line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
							</svg>
							<svg class="dark-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
								<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
							</svg>
						</span>
					</button>
					<?php
				}

				/**
				 * Action hook for header right content
				 *
				 * @since 1.0.0
				 */
				do_action( 'themeflex_header_right' );
				?>
			</div>
		</div>
	</div>
</header>
