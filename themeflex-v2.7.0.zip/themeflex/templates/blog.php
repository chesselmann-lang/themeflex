<?php
/**
 * Template Name: Blog
 * Template Post Type: page
 *
 * Blog listing page template with layout options
 *
 * @package ThemeFlex
 */

get_header();

// Get layout preference from customizer
$blog_layout = get_theme_mod( 'themeflex_blog_layout', 'classic' );
$blog_columns = get_theme_mod( 'themeflex_blog_columns', 2 );
$posts_per_page = get_theme_mod( 'themeflex_blog_posts_per_page', 10 );

// Query blog posts for this page
$paged = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;

$args = array(
	'post_type'      => 'post',
	'posts_per_page' => intval( $posts_per_page ),
	'paged'          => intval( $paged ),
);

$blog_query = new WP_Query( $args );
?>

<main id="primary" class="site-main">
	<div class="container">
		<div class="content-area">
			<?php
			// Page title and content
			while ( have_posts() ) {
				the_post();
				?>
				<header class="page-header">
					<?php the_title( '<h1 class="page-title">', '</h1>' ); ?>
					<?php
					if ( ! empty( get_the_content() ) ) {
						echo '<div class="page-description">' . wp_kses_post( get_the_content() ) . '</div>';
					}
					?>
				</header><!-- .page-header -->
				<?php
			}
			?>

			<!-- Blog posts -->
			<?php
			if ( $blog_query->have_posts() ) {
				// Add layout class
				$layout_class = 'classic' === $blog_layout ? 'posts-list' : 'posts-grid';
				if ( 'masonry' === $blog_layout ) {
					$layout_class = 'posts-masonry';
				}

				echo '<div class="' . esc_attr( $layout_class ) . '" style="--columns: ' . intval( $blog_columns ) . ';">';

				while ( $blog_query->have_posts() ) {
					$blog_query->the_post();

					if ( 'classic' === $blog_layout ) {
						get_template_part( 'template-parts/content' );
					} else {
						get_template_part( 'template-parts/content', 'grid' );
					}
				}

				echo '</div>';

				// Pagination
				echo '<div class="pagination">';
				echo paginate_links(
					array(
						'query'      => $blog_query->query,
						'total'      => $blog_query->max_num_pages,
						'current'    => $paged,
						'prev_text'  => __( '&larr; Newer Posts', 'themeflex' ),
						'next_text'  => __( 'Older Posts &rarr;', 'themeflex' ),
						'type'       => 'list',
					)
				);
				echo '</div>';
			} else {
				get_template_part( 'template-parts/content', 'none' );
			}

			wp_reset_postdata();
			?>
		</div><!-- .content-area -->

		<?php
		// Sidebar (if enabled)
		$show_sidebar = get_theme_mod( 'themeflex_blog_sidebar', true );
		if ( $show_sidebar && is_active_sidebar( 'primary' ) ) {
			echo '<aside id="secondary" class="widget-area">';
			dynamic_sidebar( 'primary' );
			echo '</aside>';
		}
		?>
	</div><!-- .container -->
</main><!-- #primary -->

<?php
get_footer();
?>
