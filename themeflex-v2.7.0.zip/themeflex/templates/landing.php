<?php
/**
 * Template Name: Landing Page
 * Template Post Type: page
 *
 * Landing page template - minimal design, no header nav, minimal footer
 *
 * @package ThemeFlex
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class( 'landing-page' ); ?>>
	<?php wp_body_open(); ?>

	<div id="page" class="site">
		<?php
		// Optional minimal logo bar
		$show_logo = get_theme_mod( 'themeflex_landing_show_logo', true );
		if ( $show_logo ) {
			?>
			<div class="landing-header">
				<div class="container">
					<div class="site-branding">
						<?php get_template_part( 'template-parts/header/header', 'logo' ); ?>
					</div>
				</div>
			</div>
			<?php
		}
		?>

		<main id="primary" class="site-main landing-main">
			<?php
			while ( have_posts() ) {
				the_post();
				?>
				<article id="post-<?php the_ID(); ?>" <?php post_class( 'landing-content' ); ?>>
					<div class="entry__content">
						<?php
						the_content();

						wp_link_pages(
							array(
								'before'      => '<div class="page-links">' . esc_html__( 'Pages:', 'themeflex' ),
								'after'       => '</div>',
								'link_before' => '<span class="page-link">',
								'link_after'  => '</span>',
							)
						);
						?>
					</div><!-- .entry__content -->
				</article><!-- #post-<?php the_ID(); ?> -->
				<?php
			}
			?>
		</main><!-- #primary -->

		<?php
		// Minimal footer
		$show_footer = get_theme_mod( 'themeflex_landing_show_footer', true );
		if ( $show_footer ) {
			?>
			<footer id="colophon" class="site-footer landing-footer">
				<div class="container">
					<div class="footer-copyright">
						<?php
						$copyright_text = get_theme_mod(
							'themeflex_copyright_text',
							sprintf(
								/* translators: %s: current year, %s: site name */
								__( '&copy; %s %s. All rights reserved.', 'themeflex' ),
								gmdate( 'Y' ),
								get_bloginfo( 'name' )
							)
						);
						echo wp_kses_post( $copyright_text );
						?>
					</div>
				</div>
			</footer><!-- #colophon -->
			<?php
		}
		?>
	</div><!-- #page -->

	<?php wp_footer(); ?>
</body>
</html>
