<?php
/**
 * Portfolio Page Template
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

// Get portfolio settings
$posts_per_page = get_theme_mod( 'sf_portfolio_posts_per_page', 12 );
$columns = get_theme_mod( 'sf_portfolio_columns', 3 );
?>

<div class="sf-portfolio-page">
	<div class="sf-portfolio-hero">
		<div class="sf-hero-content">
			<h1><?php the_title(); ?></h1>
			<?php if ( get_the_excerpt() ) : ?>
				<p><?php the_excerpt(); ?></p>
			<?php endif; ?>
		</div>
	</div>

	<div class="sf-portfolio-filters">
		<?php
		// Get portfolio categories
		$categories = get_terms( array(
			'taxonomy'   => 'sf_portfolio_category',
			'hide_empty' => true,
		) );

		if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) :
			?>
			<div class="filter-buttons">
				<button class="filter-btn active" data-filter="all">
					<?php esc_html_e( 'All', 'themeflex' ); ?>
				</button>
				<?php foreach ( $categories as $category ) : ?>
					<button class="filter-btn" data-filter="<?php echo esc_attr( $category->slug ); ?>">
						<?php echo esc_html( $category->name ); ?>
					</button>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>

	<div class="sf-portfolio-grid" data-columns="<?php echo esc_attr( $columns ); ?>">
		<?php
		$args = array(
			'post_type'      => 'sf_portfolio',
			'posts_per_page' => $posts_per_page,
			'orderby'        => 'date',
			'order'          => 'DESC',
		);

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) :
			while ( $query->have_posts() ) :
				$query->the_post();
				?>
				<div class="sf-portfolio-item" data-category="<?php echo esc_attr( implode( ' ', wp_get_post_terms( get_the_ID(), 'sf_portfolio_category', array( 'fields' => 'slugs' ) ) ) ); ?>">
					<div class="sf-portfolio-image">
						<?php
						if ( has_post_thumbnail() ) {
							the_post_thumbnail( 'large' );
						}
						?>
						<div class="sf-portfolio-overlay">
							<a href="<?php the_permalink(); ?>" class="sf-portfolio-link">
								<?php esc_html_e( 'View Project', 'themeflex' ); ?>
							</a>
						</div>
					</div>
					<div class="sf-portfolio-content">
						<h3><?php the_title(); ?></h3>
						<?php
						$categories = wp_get_post_terms( get_the_ID(), 'sf_portfolio_category', array( 'fields' => 'names' ) );
						if ( ! empty( $categories ) ) :
							?>
							<p class="sf-portfolio-meta"><?php echo esc_html( implode( ', ', $categories ) ); ?></p>
						<?php endif; ?>
					</div>
				</div>
				<?php
			endwhile;
			wp_reset_postdata();
		else :
			?>
			<p><?php esc_html_e( 'No portfolio items found.', 'themeflex' ); ?></p>
		<?php endif; ?>
	</div>

	<?php
	// Pagination
	if ( $query->max_num_pages > 1 ) {
		echo paginate_links( array(
			'total'     => $query->max_num_pages,
			'current'   => max( 1, get_query_var( 'paged' ) ),
			'prev_text' => '&larr; ' . esc_html__( 'Previous', 'themeflex' ),
			'next_text' => esc_html__( 'Next', 'themeflex' ) . ' &rarr;',
		) );
	}
	?>
</div>

<?php
get_footer();
