<?php
/**
 * WooCommerce Elementor Template
 *
 * This template loads Elementor-built WooCommerce page layouts
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get the post ID from the custom template
global $post;

if ( isset( $args['post_id'] ) ) {
	$template_id = $args['post_id'];
} else {
	// Try to get from global context
	$template_id = null;
}

// Check if we have a valid template
if ( ! $template_id ) {
	// Fallback to default WooCommerce template
	wc_get_template_part( 'archive', 'product' );
	return;
}

// Check if Elementor is active
if ( ! class_exists( '\Elementor\Plugin' ) ) {
	wc_get_template_part( 'archive', 'product' );
	return;
}

// Get the Elementor frontend
$elementor = \Elementor\Plugin::instance();
$elementor->frontend->register_scripts();

// Output the Elementor content
echo '<div class="sf-woo-elementor-template">';

if ( class_exists( '\Elementor\Frontend' ) ) {
	// Render the post with Elementor
	echo $elementor->frontend->get_builder_content( $template_id, true );
} else {
	// Fallback: show post content
	echo wp_kses_post( get_post_field( 'post_content', $template_id ) );
}

echo '</div>';
