<?php
/**
 * PHPUnit Bootstrap File
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( dirname( dirname( dirname( dirname( dirname( __FILE__ ) ) ) ) ) ) . '/wordpress/' );
}

// Define theme constants
if ( ! defined( 'THEMEFLEX_THEME_DIR' ) ) {
	define( 'THEMEFLEX_THEME_DIR', dirname( dirname( __FILE__ ) ) );
}

if ( ! defined( 'THEMEFLEX_THEME_URL' ) ) {
	define( 'THEMEFLEX_THEME_URL', 'http://example.com/' );
}

if ( ! defined( 'THEMEFLEX_VERSION' ) ) {
	define( 'THEMEFLEX_VERSION', '1.0.0' );
}

// Load the WordPress test library
if ( ! file_exists( ABSPATH . 'wp-load.php' ) ) {
	// For standalone testing without WordPress installation
	require_once dirname( __FILE__ ) . '/../includes/class-demo-importer.php';
	echo "WordPress test environment not found. Running limited tests.\n";
} else {
	require_once ABSPATH . 'wp-load.php';
	require_once ABSPATH . 'wp-includes/functions.php';
	require_once ABSPATH . 'wp-includes/plugin.php';
}

// Load theme functions
if ( file_exists( THEMEFLEX_THEME_DIR . '/functions.php' ) ) {
	require_once THEMEFLEX_THEME_DIR . '/functions.php';
}

/**
 * Mock WordPress functions if WordPress is not loaded
 */
if ( ! function_exists( 'get_template_directory' ) ) {
	function get_template_directory() {
		return THEMEFLEX_THEME_DIR;
	}
}

if ( ! function_exists( 'get_template_directory_uri' ) ) {
	function get_template_directory_uri() {
		return THEMEFLEX_THEME_URL;
	}
}

if ( ! function_exists( 'get_stylesheet_directory' ) ) {
	function get_stylesheet_directory() {
		return THEMEFLEX_THEME_DIR;
	}
}

if ( ! function_exists( 'get_stylesheet_directory_uri' ) ) {
	function get_stylesheet_directory_uri() {
		return THEMEFLEX_THEME_URL;
	}
}

if ( ! function_exists( 'add_theme_support' ) ) {
	function add_theme_support( $feature, $args = array() ) {
		// Mock function
	}
}

if ( ! function_exists( 'add_action' ) ) {
	function add_action( $hook, $function_to_add, $priority = 10, $accepted_args = 1 ) {
		// Mock function
	}
}

if ( ! function_exists( 'add_filter' ) ) {
	function add_filter( $hook, $function_to_add, $priority = 10, $accepted_args = 1 ) {
		// Mock function
	}
}

if ( ! function_exists( 'register_nav_menu' ) ) {
	function register_nav_menu( $location, $description ) {
		// Mock function
	}
}

if ( ! function_exists( 'register_sidebar' ) ) {
	function register_sidebar( $args ) {
		// Mock function
	}
}

if ( ! function_exists( 'add_image_size' ) ) {
	function add_image_size( $name, $width = 0, $height = 0, $crop = false ) {
		// Mock function
	}
}

if ( ! function_exists( '__' ) ) {
	function __( $text, $domain = 'default' ) {
		return $text;
	}
}

if ( ! function_exists( '_e' ) ) {
	function _e( $text, $domain = 'default' ) {
		echo $text;
	}
}

if ( ! function_exists( 'load_theme_textdomain' ) ) {
	function load_theme_textdomain( $domain, $path = false ) {
		return true;
	}
}

if ( ! function_exists( 'esc_attr' ) ) {
	function esc_attr( $text ) {
		return htmlspecialchars( $text, ENT_QUOTES, 'UTF-8' );
	}
}

if ( ! function_exists( 'esc_html' ) ) {
	function esc_html( $text ) {
		return htmlspecialchars( $text, ENT_QUOTES, 'UTF-8' );
	}
}

if ( ! function_exists( 'esc_url' ) ) {
	function esc_url( $url ) {
		return filter_var( $url, FILTER_SANITIZE_URL );
	}
}

if ( ! function_exists( 'wp_enqueue_script' ) ) {
	function wp_enqueue_script( $handle, $src = '', $deps = array(), $ver = false, $in_footer = false ) {
		// Mock function
	}
}

if ( ! function_exists( 'wp_enqueue_style' ) ) {
	function wp_enqueue_style( $handle, $src = '', $deps = array(), $ver = false, $media = 'all' ) {
		// Mock function
	}
}

if ( ! class_exists( 'WP_Widget' ) ) {
	class WP_Widget {}
}

if ( ! class_exists( 'WP_Query' ) ) {
	class WP_Query {}
}

if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
	namespace Elementor {
		class Widget_Base {
			public function get_name() {
				return '';
			}
			public function get_title() {
				return '';
			}
			public function get_icon() {
				return '';
			}
			public function render() {}
		}
	}
}
