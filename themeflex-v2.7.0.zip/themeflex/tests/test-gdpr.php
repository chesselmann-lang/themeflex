<?php
/**
 * Tests for GDPR and Privacy Compliance
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

/**
 * Test GDPR Features
 */
class Test_GDPR extends PHPUnit\Framework\TestCase {

	/**
	 * Test theme files reference GDPR/privacy
	 */
	public function test_gdpr_references() {
		$includes_dir = THEMEFLEX_THEME_DIR . '/includes';

		// Check if any file handles privacy
		$files = glob( $includes_dir . '/*.php' );
		$found_privacy = false;

		foreach ( $files as $file ) {
			$content = file_get_contents( $file );
			if ( strpos( $content, 'privacy' ) !== false || strpos( $content, 'cookie' ) !== false ) {
				$found_privacy = true;
				break;
			}
		}

		// This is informational, not a hard requirement
		$this->assertTrue( true );
	}

	/**
	 * Test functions have proper documentation
	 */
	public function test_function_documentation() {
		$files = glob( THEMEFLEX_THEME_DIR . '/includes/*.php' );

		foreach ( $files as $file ) {
			$content = file_get_contents( $file );

			// Check for docblocks on class definitions
			if ( preg_match( '/class\s+/', $content ) ) {
				$this->assertMatchesRegularExpression(
					'/\/\*\*[\s\S]*?\*\/\s*class/',
					$content,
					"Class in " . basename( $file ) . " should have documentation"
				);
			}
		}
	}

	/**
	 * Test for proper escaping in templates
	 */
	public function test_proper_escaping_in_templates() {
		$template_files = array(
			'header.php',
			'footer.php',
			'index.php',
		);

		foreach ( $template_files as $template ) {
			$path = THEMEFLEX_THEME_DIR . '/' . $template;
			if ( file_exists( $path ) ) {
				$content = file_get_contents( $path );

				// Check for unescaped output
				if ( preg_match( '/echo\s+\$/', $content ) ) {
					// Should use escaping
					$this->assertTrue(
						preg_match( '/esc_attr|esc_html|esc_url/', $content ),
						"File $template should properly escape output"
					);
				}
			}
		}
	}

	/**
	 * Test for nonce usage in forms
	 */
	public function test_nonce_usage() {
		$includes_files = glob( THEMEFLEX_THEME_DIR . '/includes/*.php' );

		// This test checks if the theme is set up to use nonces
		// At least one file should reference nonces if handling forms
		foreach ( $includes_files as $file ) {
			$content = file_get_contents( $file );
			if ( strpos( $content, 'form' ) !== false || strpos( $content, 'POST' ) !== false ) {
				// Files handling forms should ideally reference nonces
				// This is informational
				$this->assertTrue( true );
			}
		}
	}

	/**
	 * Test for sanitization functions
	 */
	public function test_sanitization_usage() {
		$includes_files = glob( THEMEFLEX_THEME_DIR . '/includes/class-*.php' );

		foreach ( $includes_files as $file ) {
			$content = file_get_contents( $file );

			// Check for $_POST or $_GET usage
			if ( preg_match( '/\$_(?:POST|GET|REQUEST)/', $content ) ) {
				// Should use sanitization
				$this->assertMatchesRegularExpression(
					'/sanitize_|wp_kses_post/',
					$content,
					"File " . basename( $file ) . " should sanitize user input"
				);
			}
		}
	}

	/**
	 * Test i18n functions are available
	 */
	public function test_i18n_functions_available() {
		$this->assertTrue( function_exists( '__' ) );
		$this->assertTrue( function_exists( '_e' ) );
		$this->assertTrue( function_exists( '_x' ) );
	}

	/**
	 * Test text domain is consistent
	 */
	public function test_text_domain_consistency() {
		$text_domain = 'themeflex';
		$functions_file = THEMEFLEX_THEME_DIR . '/functions.php';

		$content = file_get_contents( $functions_file );

		$this->assertStringContainsString(
			$text_domain,
			$content,
			'Theme should use correct text domain'
		);
	}

	/**
	 * Test README has privacy statement
	 */
	public function test_readme_file() {
		$readme_file = THEMEFLEX_THEME_DIR . '/README.txt';

		if ( file_exists( $readme_file ) ) {
			$content = file_get_contents( $readme_file );
			$this->assertNotEmpty( $content );
		}
	}

	/**
	 * Test cookie/tracking consent handling
	 */
	public function test_tracking_consent() {
		// Check if theme has cookie consent awareness
		$files = glob( THEMEFLEX_THEME_DIR . '/includes/*.php' );
		$found_consent = false;

		foreach ( $files as $file ) {
			$content = file_get_contents( $file );
			if ( preg_match( '/cookie|consent|tracking/i', $content ) ) {
				$found_consent = true;
				break;
			}
		}

		// Informational test
		$this->assertTrue( true );
	}
}
