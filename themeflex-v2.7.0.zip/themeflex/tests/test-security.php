<?php
/**
 * Tests for Security Settings
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

/**
 * Test Security Features
 */
class Test_Security extends PHPUnit\Framework\TestCase {

	/**
	 * Test ABSPATH is defined for security
	 */
	public function test_abspath_defined() {
		$this->assertTrue( defined( 'ABSPATH' ) );
	}

	/**
	 * Test theme files check for direct access
	 */
	public function test_theme_files_have_direct_access_check() {
		$files_to_check = array(
			'/functions.php',
			'/tests/bootstrap.php',
			'/includes/class-demo-importer.php',
			'/includes/class-asset-loader.php',
		);

		foreach ( $files_to_check as $file ) {
			$path = THEMEFLEX_THEME_DIR . $file;
			if ( file_exists( $path ) ) {
				$content = file_get_contents( $path );
				$this->assertStringContainsString(
					'ABSPATH',
					$content,
					"File $file should check ABSPATH for security"
				);
			}
		}
	}

	/**
	 * Test escaping functions are available
	 */
	public function test_escaping_functions_available() {
		$this->assertTrue( function_exists( 'esc_attr' ) );
		$this->assertTrue( function_exists( 'esc_html' ) );
		$this->assertTrue( function_exists( 'esc_url' ) );
	}

	/**
	 * Test escaping functions work correctly
	 */
	public function test_escaping_functions_work() {
		$test_string = '<script>alert("xss")</script>';

		$escaped_attr = esc_attr( $test_string );
		$this->assertStringNotContainsString( '<script>', $escaped_attr );

		$escaped_html = esc_html( $test_string );
		$this->assertStringNotContainsString( '<script>', $escaped_html );

		$test_url = 'javascript:alert("xss")';
		$escaped_url = esc_url( $test_url );
		$this->assertStringNotContainsString( 'javascript:', $escaped_url );
	}

	/**
	 * Test htaccess file exists
	 */
	public function test_htaccess_file() {
		$htaccess = dirname( THEMEFLEX_THEME_DIR ) . '/.htaccess';
		// htaccess is optional, but if it exists, test it
		if ( file_exists( $htaccess ) ) {
			$content = file_get_contents( $htaccess );
			$this->assertNotEmpty( $content );
		}
	}

	/**
	 * Test no debug constants in theme files
	 */
	public function test_no_debug_in_production() {
		$functions_file = THEMEFLEX_THEME_DIR . '/functions.php';
		$content = file_get_contents( $functions_file );

		// These should typically be off in production
		// This test warns if found, not fails
		if ( strpos( $content, 'WP_DEBUG' ) !== false ) {
			$this->assertTrue( true, 'WP_DEBUG may be in configuration file' );
		}
	}

	/**
	 * Test nonce functions are available
	 */
	public function test_nonce_functions_available() {
		// Check if nonce functions would be available in WP context
		if ( function_exists( 'wp_verify_nonce' ) ) {
			$this->assertTrue( function_exists( 'wp_create_nonce' ) );
		}
	}

	/**
	 * Test sanitization functions are available
	 */
	public function test_sanitization_functions_available() {
		if ( function_exists( 'sanitize_text_field' ) ) {
			$this->assertTrue( function_exists( 'wp_kses_post' ) );
		}
	}

	/**
	 * Test no eval() calls in theme
	 */
	public function test_no_eval_in_theme() {
		$files = glob( THEMEFLEX_THEME_DIR . '/includes/*.php' );

		foreach ( $files as $file ) {
			$content = file_get_contents( $file );
			$this->assertStringNotContainsString(
				'eval(',
				$content,
				"File $file should not use eval()"
			);
		}
	}

	/**
	 * Test no system execution functions in theme
	 */
	public function test_no_system_execution() {
		$dangerous_functions = array(
			'exec(',
			'system(',
			'shell_exec(',
			'passthru(',
		);

		$files = glob( THEMEFLEX_THEME_DIR . '/includes/*.php' );

		foreach ( $files as $file ) {
			$content = file_get_contents( $file );
			foreach ( $dangerous_functions as $func ) {
				$this->assertStringNotContainsString(
					$func,
					$content,
					"File $file should not use $func"
				);
			}
		}
	}
}
