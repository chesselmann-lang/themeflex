<?php
/**
 * Tests for Theme Setup
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

/**
 * Test Theme Setup Functions
 */
class Test_Theme_Setup extends PHPUnit\Framework\TestCase {

	/**
	 * Test theme constants are defined
	 */
	public function test_theme_constants_defined() {
		$this->assertTrue( defined( 'THEMEFLEX_THEME_DIR' ) );
		$this->assertTrue( defined( 'THEMEFLEX_THEME_URL' ) );
		$this->assertTrue( defined( 'THEMEFLEX_VERSION' ) );
		$this->assertTrue( defined( 'THEMEFLEX_ASSETS_DIR' ) );
		$this->assertTrue( defined( 'THEMEFLEX_ASSETS_URL' ) );
	}

	/**
	 * Test theme constants have correct values
	 */
	public function test_theme_constants_values() {
		$this->assertStringEndsWith(
			'themeflex',
			THEMEFLEX_THEME_DIR,
			'Theme directory should end with themeflex'
		);
		$this->assertStringContains(
			'themeflex',
			THEMEFLEX_ASSETS_URL,
			'Assets URL should contain themeflex'
		);
		$this->assertTrue( is_dir( THEMEFLEX_THEME_DIR ) );
		$this->assertTrue( is_dir( THEMEFLEX_ASSETS_DIR ) );
	}

	/**
	 * Test theme version is valid
	 */
	public function test_theme_version_valid() {
		$version = THEMEFLEX_VERSION;
		// Check semver format (e.g., 1.0.0)
		$this->assertMatchesRegularExpression(
			'/^\d+\.\d+\.\d+/',
			$version,
			'Version should follow semantic versioning'
		);
	}

	/**
	 * Test theme style.css exists
	 */
	public function test_theme_stylesheet_exists() {
		$stylesheet = THEMEFLEX_THEME_DIR . '/style.css';
		$this->assertFileExists(
			$stylesheet,
			'Theme should have style.css file'
		);
	}

	/**
	 * Test theme functions.php exists
	 */
	public function test_theme_functions_exists() {
		$functions = THEMEFLEX_THEME_DIR . '/functions.php';
		$this->assertFileExists(
			$functions,
			'Theme should have functions.php file'
		);
	}

	/**
	 * Test theme index.php exists
	 */
	public function test_theme_index_exists() {
		$index = THEMEFLEX_THEME_DIR . '/index.php';
		$this->assertFileExists(
			$index,
			'Theme should have index.php file'
		);
	}

	/**
	 * Test required template files exist
	 */
	public function test_required_template_files() {
		$required_files = array(
			'header.php',
			'footer.php',
			'404.php',
			'archive.php',
			'comments.php',
		);

		foreach ( $required_files as $file ) {
			$path = THEMEFLEX_THEME_DIR . '/' . $file;
			$this->assertFileExists(
				$path,
				"Theme should have $file template"
			);
		}
	}

	/**
	 * Test includes directory structure
	 */
	public function test_includes_directory_exists() {
		$includes_dir = THEMEFLEX_THEME_DIR . '/includes';
		$this->assertTrue(
			is_dir( $includes_dir ),
			'Theme should have includes directory'
		);
	}

	/**
	 * Test assets directories exist
	 */
	public function test_assets_directories() {
		$required_dirs = array(
			'css',
			'js',
			'images',
		);

		foreach ( $required_dirs as $dir ) {
			$path = THEMEFLEX_ASSETS_DIR . $dir;
			$this->assertTrue(
				is_dir( $path ),
				"Assets should have $dir directory"
			);
		}
	}

	/**
	 * Test elementor-templates directory exists
	 */
	public function test_elementor_templates_directory() {
		$templates_dir = THEMEFLEX_THEME_DIR . '/elementor-templates';
		$this->assertTrue(
			is_dir( $templates_dir ),
			'Theme should have elementor-templates directory'
		);
	}

	/**
	 * Test main style.css has proper header
	 */
	public function test_stylesheet_header() {
		$stylesheet = THEMEFLEX_THEME_DIR . '/style.css';
		$content = file_get_contents( $stylesheet );

		$this->assertStringContainsString( 'Theme Name:', $content );
		$this->assertStringContainsString( 'Theme URI:', $content );
		$this->assertStringContainsString( 'Author:', $content );
		$this->assertStringContainsString( 'Description:', $content );
		$this->assertStringContainsString( 'Version:', $content );
		$this->assertStringContainsString( 'Text Domain:', $content );
		$this->assertStringContainsString( 'Domain Path:', $content );
		$this->assertStringContainsString( 'License:', $content );
	}

	/**
	 * Test language directory exists
	 */
	public function test_language_directory() {
		$lang_dir = THEMEFLEX_THEME_DIR . '/languages';
		$this->assertTrue(
			is_dir( $lang_dir ),
			'Theme should have languages directory for translations'
		);
	}

	/**
	 * Test important classes files exist
	 */
	public function test_important_class_files() {
		$required_classes = array(
			'class-demo-importer.php',
			'class-asset-loader.php',
			'class-design-system.php',
		);

		foreach ( $required_classes as $file ) {
			$path = THEMEFLEX_THEME_DIR . '/includes/' . $file;
			$this->assertFileExists(
				$path,
				"Theme should have includes/$file"
			);
		}
	}
}
