<?php
/**
 * Mini Cart — Starter Flavor override.
 * @package ThemeFlex
 */
defined('ABSPATH') || exit;
do_action('woocommerce_before_mini_cart');
if (!WC()->cart->is_empty()):
?>
<ul class="woocommerce-mini-cart cart_list product_list_widget <?php echo esc_attr($args['list_class']); ?>">
    <?php do_action('woocommerce_before_mini_cart_contents'); ?>
    <?php foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item):
        $_product    = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
        $product_id  = apply_filters('woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key);
        if ($_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters('woocommerce_widget_cart_item_visible', true, $cart_item, $cart_item_key)):
            $product_name  = apply_filters('woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key);
            $thumbnail     = apply_filters('woocommerce_cart_item_thumbnail', $_product->get_image('thumbnail'), $cart_item, $cart_item_key);
            $product_price = apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($_product), $cart_item, $cart_item_key);
            $product_url   = apply_filters('woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink($cart_item) : '', $cart_item, $cart_item_key);
    ?>
    <li class="woocommerce-mini-cart-item <?php echo esc_attr(apply_filters('woocommerce_mini_cart_item_class', 'mini_cart_item', $cart_item, $cart_item_key)); ?>"
        style="display:grid;grid-template-columns:56px 1fr auto;gap:12px;align-items:start;padding:12px 0;border-bottom:1px solid var(--sf-border,#e5e7eb);">
        <?php echo apply_filters('woocommerce_cart_item_remove_link', sprintf('<a href="%s" class="remove remove_from_cart_button" aria-label="%s" data-product_id="%d" data-cart_item_key="%s" data-product_sku="%s" style="display:flex;align-items:center;justify-content:center;width:20px;height:20px;border-radius:50%;background:var(--sf-border,#e5e7eb);color:var(--sf-meta,#94a3b8);font-size:14px;font-weight:700;text-decoration:none;transition:all .2s;flex-shrink:0;" onmouseover="this.style.background=\'#ef4444\';this.style.color=\'#fff\'" onmouseout="this.style.background=\'var(--sf-border,#e5e7eb)\';this.style.color=\'var(--sf-meta,#94a3b8)\'">&times;</a>',
            esc_url(wc_get_cart_remove_url($cart_item_key)),
            esc_attr__('Remove this item','themeflex'),
            (int)$product_id,
            esc_attr($cart_item_key),
            esc_attr($_product->get_sku())
        ), $cart_item_key); ?>
        <?php if (!empty($product_url)): ?><a href="<?php echo esc_url($product_url); ?>"><?php endif; ?>
        <?php echo str_replace(['width="','height="'], ['style="max-width:56px;height:56px;object-fit:cover;border-radius:8px;display:block;" width="','height="'], $thumbnail); ?>
        <?php if (!empty($product_url)): ?></a><?php endif; ?>
        <div style="min-width:0;">
            <div style="font-weight:600;font-size:13px;color:var(--sf-title,#1e293b);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:2px;">
                <?php if (!empty($product_url)): ?><a href="<?php echo esc_url($product_url); ?>" style="color:inherit;text-decoration:none;"><?php echo wp_kses_post($product_name); ?></a><?php else: echo wp_kses_post($product_name); endif; ?>
            </div>
            <div style="font-size:12px;color:var(--sf-meta,#94a3b8);"><?php echo esc_html($cart_item['quantity']); ?> × <?php echo $product_price; ?></div>
            <?php echo wc_get_formatted_cart_item_data($cart_item); ?>
        </div>
    </li>
    <?php endif; endforeach; ?>
    <?php do_action('woocommerce_mini_cart_contents'); ?>
</ul>
<p class="woocommerce-mini-cart__total total" style="display:flex;justify-content:space-between;align-items:center;padding:16px 0 8px;font-size:15px;">
    <strong><?php esc_html_e('Subtotal','themeflex'); ?></strong>
    <span style="font-size:1.2rem;font-weight:800;color:var(--sf-color-primary,#FF5E2E);"><?php echo WC()->cart->get_cart_subtotal(); ?></span>
</p>
<?php do_action('woocommerce_widget_shopping_cart_before_buttons'); ?>
<p class="woocommerce-mini-cart__buttons buttons" style="display:grid;grid-template-columns:1fr 1fr;gap:8px;padding-top:8px;">
    <a href="<?php echo esc_url(wc_get_cart_url()); ?>" class="button wc-forward" style="text-align:center;padding:11px;font-size:13px;font-weight:700;border-radius:8px;background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);color:var(--sf-title,#1e293b);text-decoration:none;"><?php esc_html_e('View Cart','themeflex'); ?></a>
    <a href="<?php echo esc_url(wc_get_checkout_url()); ?>" class="button checkout wc-forward" style="text-align:center;padding:11px;font-size:13px;font-weight:700;border-radius:8px;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;text-decoration:none;"><?php esc_html_e('Checkout','themeflex'); ?></a>
</p>
<?php do_action('woocommerce_widget_shopping_cart_after_buttons'); ?>
<?php else: ?>
<p class="woocommerce-mini-cart__empty-message" style="text-align:center;padding:24px;color:var(--sf-meta,#94a3b8);">
    <?php esc_html_e('No products in the cart.','themeflex'); ?>
</p>
<?php endif; ?>
<?php do_action('woocommerce_after_mini_cart'); ?>
