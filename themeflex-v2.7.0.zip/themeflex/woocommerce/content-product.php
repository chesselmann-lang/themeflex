<?php
/**
 * Content for each product in the loop — Starter Flavor override.
 * @package ThemeFlex
 */
defined('ABSPATH') || exit;
global $product;
if (!is_a($product, 'WC_Product')) return;
?>
<li <?php wc_product_class('sf-woo-product-card', $product); ?>>
    <div class="sf-product-inner">
        <!-- Thumbnail -->
        <div class="sf-product-thumb">
            <?php if (has_post_thumbnail()): ?>
            <a href="<?php the_permalink(); ?>">
                <?php the_post_thumbnail('woocommerce_thumbnail', ['loading'=>'lazy','decoding'=>'async']); ?>
            </a>
            <?php endif; ?>
            <!-- Badges -->
            <div class="sf-product-badges">
                <?php if ($product->is_on_sale()): ?><span class="sf-badge sf-badge-sale"><?php esc_html_e('Sale!','themeflex'); ?></span><?php endif; ?>
                <?php if ($product->is_featured()): ?><span class="sf-badge sf-badge-featured"><?php esc_html_e('Featured','themeflex'); ?></span><?php endif; ?>
                <?php if (!$product->is_in_stock()): ?><span class="sf-badge sf-badge-out"><?php esc_html_e('Out of Stock','themeflex'); ?></span><?php endif; ?>
            </div>
            <!-- Quick Add -->
            <div class="sf-product-quick-add">
                <?php woocommerce_template_loop_add_to_cart(); ?>
            </div>
        </div>
        <!-- Info -->
        <div class="sf-product-info">
            <div class="sf-product-cats"><?php echo wc_get_product_category_list($product->get_id(), ', '); ?></div>
            <h3 class="sf-product-title">
                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
            </h3>
            <?php if ($rating_count = $product->get_rating_count()): ?>
            <div class="sf-product-rating"><?php woocommerce_template_loop_rating(); ?></div>
            <?php endif; ?>
            <div class="sf-product-price"><?php woocommerce_template_loop_price(); ?></div>
        </div>
    </div>
</li>
<style>
.sf-woo-product-card{list-style:none;position:relative}
.sf-product-inner{background:var(--sf-bg,#fff);border:1px solid var(--sf-border,#e5e7eb);border-radius:12px;overflow:hidden;transition:all .3s ease}
.sf-product-inner:hover{box-shadow:0 12px 40px rgba(0,0,0,.1);transform:translateY(-4px)}
.sf-product-thumb{position:relative;overflow:hidden;aspect-ratio:1}
.sf-product-thumb img{width:100%;height:100%;object-fit:cover;transition:transform .4s ease;display:block}
.sf-product-inner:hover .sf-product-thumb img{transform:scale(1.06)}
.sf-product-badges{position:absolute;top:10px;left:10px;display:flex;flex-direction:column;gap:4px;z-index:2}
.sf-badge{padding:3px 8px;border-radius:4px;font-size:11px;font-weight:700;color:#fff}
.sf-badge-sale{background:var(--sf-color-primary,#FF5E2E)}
.sf-badge-featured{background:#7c3aed}
.sf-badge-out{background:#94a3b8}
.sf-product-quick-add{position:absolute;bottom:-50px;left:0;right:0;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));padding:12px;text-align:center;transition:bottom .3s ease;z-index:2}
.sf-product-inner:hover .sf-product-quick-add{bottom:0}
.sf-product-quick-add .button{background:none;border:none;color:#fff;font-weight:700;font-size:13px;cursor:pointer;font-family:inherit}
.sf-product-info{padding:16px}
.sf-product-cats{font-size:11px;color:var(--sf-meta,#94a3b8);text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px}
.sf-product-title{font-size:15px;font-weight:700;margin:0 0 8px}
.sf-product-title a{color:var(--sf-title,#1e293b);text-decoration:none;transition:color .2s}
.sf-product-title a:hover{color:var(--sf-color-primary,#FF5E2E)}
.sf-product-price .price{color:var(--sf-color-primary,#FF5E2E);font-weight:800;font-size:16px}
[data-theme=dark] .sf-product-inner{background:var(--sf-alt-bg-2,#1e293b);border-color:var(--sf-alt-border,rgba(255,255,255,.08))}
[data-theme=dark] .sf-product-title a{color:var(--sf-alt-title,#f1f5f9)}
</style>
