<?php
/**
 * Email Footer — Starter Flavor WooCommerce override.
 * @package ThemeFlex
 */
defined('ABSPATH') || exit;
?>
                </td></tr>
            </table>
            <!-- Footer -->
            <table border="0" cellpadding="0" cellspacing="0" width="600" style="max-width:600px;margin-top:20px;">
                <tr><td align="center" style="padding:20px 32px;">
                    <p style="font-size:12px;color:#94a3b8;margin:0 0 8px;">
                        <?php echo wp_kses_post(wpautop(wptexturize(apply_filters('woocommerce_email_footer_text', get_option('woocommerce_email_footer_text'))))); ?>
                    </p>
                    <p style="font-size:11px;color:#c0c4d0;margin:0;">
                        &copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?> — 
                        <a href="<?php echo esc_url(get_permalink(get_option('wp_page_for_privacy_policy'))); ?>" style="color:#94a3b8;text-decoration:none;"><?php esc_html_e('Privacy Policy','themeflex'); ?></a>
                        &nbsp;·&nbsp;
                        <a href="<?php echo esc_url(home_url('/')); ?>" style="color:#FF5E2E;text-decoration:none;"><?php bloginfo('name'); ?></a>
                    </p>
                </td></tr>
            </table>
        </td></tr>
    </table>
</body>
</html>
