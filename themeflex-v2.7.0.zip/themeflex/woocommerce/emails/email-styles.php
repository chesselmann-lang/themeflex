<?php
/**
 * Email Styles — Starter Flavor WooCommerce override.
 * @package ThemeFlex
 */
defined('ABSPATH') || exit;
$bg    = '#ffffff';
$body  = '#1e293b';
$base  = '#f0f2f5';
$text  = '#64748b';
$link  = '#FF5E2E';
$price = '#FF5E2E';
?>
#wrapper {background-color:<?php echo esc_attr($base); ?>;}
#template_header {background-color:#06021D;}
#template_header h1, #template_header h1 a {color:#ffffff !important;}
#template_container {box-shadow: 0 4px 24px rgba(0,0,0,.08) !important; border-radius: 12px !important;}
#template_body {background-color:<?php echo esc_attr($bg); ?>;}
.td {color:<?php echo esc_attr($body); ?>;}
.td h1, .td h2, .td h3 {color:<?php echo esc_attr($body); ?>;}
.td a {color:<?php echo esc_attr($link); ?>;}
.td p {color:<?php echo esc_attr($text); ?>;}
.button a {
    background-color:<?php echo esc_attr($link); ?> !important;
    border-radius: 10px !important;
    font-weight: 700 !important;
    font-size: 15px !important;
}
.order_item td {padding: 14px !important; border-color: #e5e7eb !important;}
.order_details th {background: #f8fafc !important; color: <?php echo esc_attr($body); ?> !important;}
#template_footer {background-color: transparent !important;}
#template_footer td {color: #94a3b8 !important; font-size: 12px !important;}
