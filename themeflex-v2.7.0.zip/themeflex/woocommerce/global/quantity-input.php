<?php
/**
 * Quantity Input — Starter Flavor override
 * @package ThemeFlex
 */
defined('ABSPATH') || exit;
if (!$product) return;
$min = $args['min_value'];
$max = $args['max_value'] ?? '';
$step = $args['step'] ?? 1;
$value = $args['input_value'] ?? 1;
?>
<div class="sf-qty-wrap quantity" style="display:flex;align-items:center;border:1px solid var(--sf-border,#e5e7eb);border-radius:10px;overflow:hidden;background:var(--sf-bg,#fff);">
    <button type="button" class="sf-qty-btn sf-qty-minus" onclick="sfQtyChange(this,-<?php echo (float)$step; ?>)"
        style="width:40px;height:44px;background:none;border:none;border-right:1px solid var(--sf-border,#e5e7eb);font-size:18px;cursor:pointer;color:var(--sf-text,#64748b);display:flex;align-items:center;justify-content:center;flex-shrink:0;"
        aria-label="<?php esc_attr_e('Decrease quantity','themeflex'); ?>">−</button>
    <input type="number"
        id="<?php echo esc_attr($args['input_id'] ?? 'quantity'); ?>"
        class="input-text qty text"
        name="<?php echo esc_attr($args['input_name'] ?? 'quantity'); ?>"
        value="<?php echo esc_attr($value); ?>"
        min="<?php echo esc_attr($min); ?>"
        <?php echo $max !== '' ? 'max="'.esc_attr($max).'"' : ''; ?>
        step="<?php echo esc_attr($step); ?>"
        style="width:52px;height:44px;border:none;text-align:center;font-size:15px;font-weight:700;background:none;color:var(--sf-title,#1e293b);font-family:inherit;outline:none;"
        aria-label="<?php esc_attr_e('Product quantity','themeflex'); ?>" />
    <button type="button" class="sf-qty-btn sf-qty-plus" onclick="sfQtyChange(this,<?php echo (float)$step; ?>)"
        style="width:40px;height:44px;background:none;border:none;border-left:1px solid var(--sf-border,#e5e7eb);font-size:18px;cursor:pointer;color:var(--sf-text,#64748b);display:flex;align-items:center;justify-content:center;flex-shrink:0;"
        aria-label="<?php esc_attr_e('Increase quantity','themeflex'); ?>">+</button>
</div>
<script>
window.sfQtyChange=window.sfQtyChange||function(btn,delta){
    var wrap=btn.closest('.sf-qty-wrap');
    var input=wrap.querySelector('input[type=number]');
    if(!input)return;
    var val=parseFloat(input.value)||0;
    var min=parseFloat(input.min)||0;
    var max=input.max?parseFloat(input.max):Infinity;
    var newVal=Math.max(min,Math.min(max,val+delta));
    input.value=newVal;
    input.dispatchEvent(new Event('change',{bubbles:true}));
};
</script>
