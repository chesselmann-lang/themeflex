<?php
/**
 * Template Name: Medical Homepage
 *
 * Premium Medical / Healthcare landing page for ThemeFlex.
 * Dark-first, CSS-art hero (pulse monitor + health dashboard),
 * appointment CTA, specialties grid, doctors team, certifications strip,
 * patient stats, testimonials, and contact/map section.
 *
 * @package ThemeFlex
 * @since   2.8.0
 */

get_header();
?>

<div class="tf-medical-page">

<style>
/* ─── Design Tokens ───────────────────────────────────────────── */
.tf-medical-page {
  --med-bg:       #0a0f1a;
  --med-surface:  #111827;
  --med-card:     #1a2236;
  --med-border:   rgba(255,255,255,.07);
  --med-accent:   #06b6d4;   /* cyan – medical clean */
  --med-accent2:  #10b981;   /* emerald – health/vitals */
  --med-accent3:  #f59e0b;   /* amber – urgency/CTA */
  --med-text:     #f1f5f9;
  --med-muted:    #94a3b8;
  --med-radius:   14px;
  background: var(--med-bg);
  color: var(--med-text);
  font-family: var(--tf-font-body, 'Inter', sans-serif);
}

/* ─── Shared Utilities ────────────────────────────────────────── */
.tf-medical-page .med-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 24px;
}
.tf-medical-page .med-section {
  padding: 96px 0;
}
.tf-medical-page .med-label {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-size: .75rem;
  font-weight: 600;
  letter-spacing: .12em;
  text-transform: uppercase;
  color: var(--med-accent);
  margin-bottom: 16px;
}
.tf-medical-page .med-label::before {
  content: '';
  width: 18px;
  height: 2px;
  background: var(--med-accent);
  border-radius: 2px;
}
.tf-medical-page .med-heading {
  font-family: var(--tf-font-heading, 'Inter Tight', sans-serif);
  font-size: clamp(2rem, 4vw, 2.75rem);
  font-weight: 700;
  line-height: 1.2;
  margin: 0 0 20px;
  color: var(--med-text);
}
.tf-medical-page .med-sub {
  font-size: 1.1rem;
  color: var(--med-muted);
  line-height: 1.7;
  max-width: 560px;
}
.tf-medical-page .med-btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 14px 28px;
  border-radius: 8px;
  font-size: .95rem;
  font-weight: 600;
  text-decoration: none;
  cursor: pointer;
  border: none;
  transition: all .2s;
}
.tf-medical-page .med-btn-primary {
  background: var(--med-accent);
  color: #000;
}
.tf-medical-page .med-btn-primary:hover { background: #22d3ee; }
.tf-medical-page .med-btn-outline {
  background: transparent;
  color: var(--med-text);
  border: 1.5px solid var(--med-border);
}
.tf-medical-page .med-btn-outline:hover {
  border-color: var(--med-accent);
  color: var(--med-accent);
}

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   1. HERO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-medical-page .med-hero {
  min-height: 100vh;
  display: grid;
  grid-template-columns: 1fr 1fr;
  align-items: center;
  gap: 64px;
  padding: 120px 0 80px;
  position: relative;
  overflow: hidden;
}
.tf-medical-page .med-hero::before {
  content: '';
  position: absolute;
  top: -200px; right: -200px;
  width: 700px; height: 700px;
  background: radial-gradient(circle, rgba(6,182,212,.08) 0%, transparent 70%);
  pointer-events: none;
}
.tf-medical-page .med-hero-badge {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: rgba(6,182,212,.1);
  border: 1px solid rgba(6,182,212,.25);
  border-radius: 100px;
  padding: 6px 14px;
  font-size: .8rem;
  font-weight: 600;
  color: var(--med-accent);
  margin-bottom: 24px;
}
.tf-medical-page .med-hero-badge .pulse-dot {
  width: 8px; height: 8px;
  background: var(--med-accent2);
  border-radius: 50%;
  animation: med-pulse 1.5s ease-in-out infinite;
}
@keyframes med-pulse {
  0%,100% { opacity: 1; transform: scale(1); }
  50%      { opacity: .4; transform: scale(.7); }
}
.tf-medical-page .med-hero h1 {
  font-family: var(--tf-font-heading, 'Inter Tight', sans-serif);
  font-size: clamp(2.5rem, 5vw, 3.75rem);
  font-weight: 800;
  line-height: 1.1;
  margin: 0 0 24px;
}
.tf-medical-page .med-hero h1 em {
  font-style: normal;
  background: linear-gradient(135deg, var(--med-accent), var(--med-accent2));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
.tf-medical-page .med-hero-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  margin-top: 36px;
}
.tf-medical-page .med-hero-trust {
  display: flex;
  align-items: center;
  gap: 20px;
  margin-top: 40px;
  padding-top: 32px;
  border-top: 1px solid var(--med-border);
}
.tf-medical-page .med-hero-trust-item {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: .85rem;
  color: var(--med-muted);
}
.tf-medical-page .med-hero-trust-item strong {
  display: block;
  font-size: 1.1rem;
  font-weight: 700;
  color: var(--med-text);
}

/* CSS Health Monitor Mockup */
.tf-medical-page .med-monitor {
  background: var(--med-surface);
  border: 1.5px solid var(--med-border);
  border-radius: 20px;
  overflow: hidden;
  box-shadow:
    0 40px 80px rgba(0,0,0,.4),
    0 0 0 1px rgba(255,255,255,.04);
  position: relative;
}
.tf-medical-page .med-monitor-topbar {
  background: rgba(6,182,212,.08);
  border-bottom: 1px solid var(--med-border);
  padding: 14px 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.tf-medical-page .med-monitor-topbar .dots {
  display: flex; gap: 7px;
}
.tf-medical-page .med-monitor-topbar .dots span {
  width: 10px; height: 10px; border-radius: 50%;
}
.tf-medical-page .med-monitor-topbar .dots span:nth-child(1) { background: #ff5f57; }
.tf-medical-page .med-monitor-topbar .dots span:nth-child(2) { background: #febc2e; }
.tf-medical-page .med-monitor-topbar .dots span:nth-child(3) { background: #28c840; }
.tf-medical-page .med-monitor-topbar .med-title-bar {
  font-size: .8rem;
  color: var(--med-muted);
  font-weight: 500;
}
.tf-medical-page .med-monitor-topbar .med-live {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: .75rem;
  color: var(--med-accent2);
  font-weight: 600;
}
.tf-medical-page .med-monitor-topbar .med-live::before {
  content: '';
  width: 7px; height: 7px;
  border-radius: 50%;
  background: var(--med-accent2);
  animation: med-pulse 1.5s ease-in-out infinite;
}
.tf-medical-page .med-monitor-body {
  padding: 20px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}
/* Vitals row */
.tf-medical-page .med-vitals {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
}
.tf-medical-page .med-vital-card {
  background: var(--med-card);
  border: 1px solid var(--med-border);
  border-radius: 10px;
  padding: 12px;
}
.tf-medical-page .med-vital-card .vital-label {
  font-size: .65rem;
  color: var(--med-muted);
  text-transform: uppercase;
  letter-spacing: .08em;
  margin-bottom: 6px;
  display: flex;
  align-items: center;
  gap: 5px;
}
.tf-medical-page .med-vital-card .vital-value {
  font-size: 1.3rem;
  font-weight: 700;
  color: var(--med-text);
  font-family: var(--tf-font-heading, monospace);
}
.tf-medical-page .med-vital-card .vital-value span {
  font-size: .75rem;
  font-weight: 400;
  color: var(--med-muted);
}
.tf-medical-page .med-vital-card .vital-status {
  font-size: .65rem;
  margin-top: 4px;
  font-weight: 600;
}
.tf-medical-page .med-vital-card .vital-status.ok { color: var(--med-accent2); }
.tf-medical-page .med-vital-card .vital-status.warn { color: var(--med-accent3); }
/* ECG Line */
.tf-medical-page .med-ecg-wrap {
  background: var(--med-card);
  border: 1px solid var(--med-border);
  border-radius: 10px;
  padding: 14px;
}
.tf-medical-page .med-ecg-label {
  font-size: .7rem;
  color: var(--med-muted);
  text-transform: uppercase;
  letter-spacing: .08em;
  margin-bottom: 10px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.tf-medical-page .med-ecg-label strong { color: var(--med-accent2); font-size: .85rem; }
.tf-medical-page .med-ecg-svg {
  width: 100%;
  height: 48px;
  overflow: visible;
}
.tf-medical-page .med-ecg-path {
  fill: none;
  stroke: var(--med-accent2);
  stroke-width: 2;
  stroke-dasharray: 600;
  stroke-dashoffset: 600;
  animation: med-ecg-draw 2.5s ease forwards .8s;
}
@keyframes med-ecg-draw {
  to { stroke-dashoffset: 0; }
}
/* Patient list */
.tf-medical-page .med-patient-list {
  background: var(--med-card);
  border: 1px solid var(--med-border);
  border-radius: 10px;
  overflow: hidden;
}
.tf-medical-page .med-patient-row {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 14px;
  border-bottom: 1px solid var(--med-border);
  font-size: .8rem;
}
.tf-medical-page .med-patient-row:last-child { border-bottom: none; }
.tf-medical-page .med-patient-avatar {
  width: 32px; height: 32px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .7rem; font-weight: 700; flex-shrink: 0;
}
.tf-medical-page .med-patient-info { flex: 1; }
.tf-medical-page .med-patient-info .pat-name { color: var(--med-text); font-weight: 600; }
.tf-medical-page .med-patient-info .pat-meta { color: var(--med-muted); font-size: .7rem; }
.tf-medical-page .med-patient-status {
  font-size: .65rem; font-weight: 600; padding: 3px 8px; border-radius: 100px;
}
.tf-medical-page .med-patient-status.scheduled {
  background: rgba(6,182,212,.15); color: var(--med-accent);
}
.tf-medical-page .med-patient-status.inprogress {
  background: rgba(16,185,129,.15); color: var(--med-accent2);
}
.tf-medical-page .med-patient-status.done {
  background: rgba(148,163,184,.1); color: var(--med-muted);
}
/* Floating appointment card */
.tf-medical-page .med-appt-float {
  position: absolute;
  bottom: -16px;
  left: -28px;
  background: var(--med-card);
  border: 1.5px solid var(--med-border);
  border-radius: 12px;
  padding: 14px 18px;
  display: flex;
  align-items: center;
  gap: 14px;
  box-shadow: 0 20px 40px rgba(0,0,0,.4);
  animation: med-float 4s ease-in-out infinite;
}
@keyframes med-float {
  0%,100% { transform: translateY(0); }
  50%      { transform: translateY(-8px); }
}
.tf-medical-page .med-appt-float .appt-icon {
  width: 40px; height: 40px;
  background: rgba(6,182,212,.15);
  border-radius: 10px;
  display: flex; align-items: center; justify-content: center;
  color: var(--med-accent);
}
.tf-medical-page .med-appt-float .appt-text strong {
  display: block; font-size: .85rem; color: var(--med-text);
}
.tf-medical-page .med-appt-float .appt-text span {
  font-size: .75rem; color: var(--med-muted);
}
.tf-medical-page .med-monitor-wrap {
  position: relative;
}

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   2. APPOINTMENT BANNER
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-medical-page .med-appt-banner {
  background: linear-gradient(135deg, var(--med-accent) 0%, #0891b2 100%);
  padding: 32px 0;
}
.tf-medical-page .med-appt-banner .inner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 24px;
  flex-wrap: wrap;
}
.tf-medical-page .med-appt-banner .appt-copy { color: #fff; }
.tf-medical-page .med-appt-banner .appt-copy h3 {
  font-size: 1.4rem; font-weight: 700; margin: 0 0 4px;
}
.tf-medical-page .med-appt-banner .appt-copy p {
  margin: 0; opacity: .85; font-size: .95rem;
}
.tf-medical-page .med-appt-banner .med-btn-appt {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: #000;
  color: #fff;
  padding: 14px 28px;
  border-radius: 8px;
  font-size: .95rem;
  font-weight: 600;
  text-decoration: none;
  white-space: nowrap;
  transition: background .2s;
}
.tf-medical-page .med-appt-banner .med-btn-appt:hover { background: #1a1a1a; }
.tf-medical-page .med-appt-banner .appt-info {
  display: flex;
  gap: 28px;
  flex-wrap: wrap;
}
.tf-medical-page .med-appt-banner .appt-info-item {
  display: flex;
  align-items: center;
  gap: 8px;
  color: rgba(255,255,255,.9);
  font-size: .9rem;
}

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   3. SPECIALTIES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-medical-page .med-specialties-head {
  text-align: center;
  margin-bottom: 56px;
}
.tf-medical-page .med-specialties-head .med-sub {
  margin: 0 auto;
}
.tf-medical-page .med-spec-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
}
.tf-medical-page .med-spec-card {
  background: var(--med-card);
  border: 1.5px solid var(--med-border);
  border-radius: var(--med-radius);
  padding: 28px 24px;
  transition: all .25s;
  position: relative;
  overflow: hidden;
}
.tf-medical-page .med-spec-card::before {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, rgba(6,182,212,.06) 0%, transparent 60%);
  opacity: 0;
  transition: opacity .25s;
}
.tf-medical-page .med-spec-card:hover {
  border-color: rgba(6,182,212,.35);
  transform: translateY(-4px);
}
.tf-medical-page .med-spec-card:hover::before { opacity: 1; }
.tf-medical-page .med-spec-icon {
  width: 52px; height: 52px;
  border-radius: 12px;
  display: flex; align-items: center; justify-content: center;
  margin-bottom: 18px;
  font-size: 1.5rem;
}
.tf-medical-page .med-spec-card h4 {
  font-size: 1rem; font-weight: 700; margin: 0 0 10px; color: var(--med-text);
}
.tf-medical-page .med-spec-card p {
  font-size: .85rem; color: var(--med-muted); line-height: 1.6; margin: 0 0 16px;
}
.tf-medical-page .med-spec-card a {
  font-size: .8rem; font-weight: 600; color: var(--med-accent); text-decoration: none;
  display: inline-flex; align-items: center; gap: 6px;
}
.tf-medical-page .med-spec-card a:hover { color: #22d3ee; }

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   4. STATS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-medical-page .med-stats-bar {
  background: var(--med-surface);
  border-top: 1px solid var(--med-border);
  border-bottom: 1px solid var(--med-border);
  padding: 56px 0;
}
.tf-medical-page .med-stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 0;
}
.tf-medical-page .med-stat {
  text-align: center;
  padding: 0 32px;
  border-right: 1px solid var(--med-border);
}
.tf-medical-page .med-stat:last-child { border-right: none; }
.tf-medical-page .med-stat-num {
  font-family: var(--tf-font-heading, 'Inter Tight', sans-serif);
  font-size: 2.75rem;
  font-weight: 800;
  color: var(--med-accent);
  line-height: 1;
  margin-bottom: 8px;
}
.tf-medical-page .med-stat-label {
  font-size: .85rem;
  color: var(--med-muted);
  line-height: 1.5;
}

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   5. ABOUT / APPROACH
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-medical-page .med-about {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 80px;
  align-items: center;
}
.tf-medical-page .med-approach-list {
  list-style: none; margin: 28px 0 0; padding: 0;
  display: flex; flex-direction: column; gap: 20px;
}
.tf-medical-page .med-approach-item {
  display: flex; gap: 16px; align-items: flex-start;
}
.tf-medical-page .med-approach-num {
  flex-shrink: 0;
  width: 36px; height: 36px;
  background: rgba(6,182,212,.12);
  border: 1px solid rgba(6,182,212,.25);
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .8rem; font-weight: 700; color: var(--med-accent);
}
.tf-medical-page .med-approach-body h5 {
  font-size: .95rem; font-weight: 700; margin: 0 0 4px; color: var(--med-text);
}
.tf-medical-page .med-approach-body p {
  font-size: .85rem; color: var(--med-muted); margin: 0; line-height: 1.6;
}
/* CSS Health Visual */
.tf-medical-page .med-health-visual {
  background: var(--med-surface);
  border: 1.5px solid var(--med-border);
  border-radius: 20px;
  padding: 28px;
  position: relative;
}
.tf-medical-page .med-health-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 20px;
}
.tf-medical-page .med-health-header h4 {
  font-size: .9rem; font-weight: 700; margin: 0; color: var(--med-text);
}
.tf-medical-page .med-health-header .period {
  font-size: .75rem; color: var(--med-muted);
  background: var(--med-card); border-radius: 6px; padding: 4px 10px;
}
.tf-medical-page .med-chart-bars {
  display: flex; align-items: flex-end; gap: 8px; height: 140px; margin-bottom: 16px;
}
.tf-medical-page .med-chart-bar-wrap {
  flex: 1; display: flex; flex-direction: column; align-items: center; gap: 6px;
}
.tf-medical-page .med-chart-bar {
  width: 100%; border-radius: 4px 4px 0 0;
  background: linear-gradient(180deg, var(--med-accent) 0%, rgba(6,182,212,.3) 100%);
  transition: height .8s cubic-bezier(.34,1.56,.64,1);
}
.tf-medical-page .med-chart-bar-label { font-size: .65rem; color: var(--med-muted); }
.tf-medical-page .med-health-metrics {
  display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px;
}
.tf-medical-page .med-health-metric {
  background: var(--med-card);
  border: 1px solid var(--med-border);
  border-radius: 8px; padding: 12px;
}
.tf-medical-page .med-health-metric .hm-label {
  font-size: .7rem; color: var(--med-muted); text-transform: uppercase;
  letter-spacing: .06em; margin-bottom: 6px;
}
.tf-medical-page .med-health-metric .hm-value {
  font-size: 1.2rem; font-weight: 700; color: var(--med-text);
}
.tf-medical-page .med-health-metric .hm-delta {
  font-size: .75rem; font-weight: 600; margin-top: 2px;
}
.tf-medical-page .med-health-metric .hm-delta.up { color: var(--med-accent2); }
.tf-medical-page .med-health-metric .hm-delta.down { color: #f87171; }

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   6. DOCTORS / TEAM
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-medical-page .med-doctors-section {
  background: var(--med-surface);
}
.tf-medical-page .med-doctors-head {
  text-align: center; margin-bottom: 56px;
}
.tf-medical-page .med-doctors-grid {
  display: grid; grid-template-columns: repeat(4, 1fr); gap: 24px;
}
.tf-medical-page .med-doctor-card {
  background: var(--med-card);
  border: 1.5px solid var(--med-border);
  border-radius: var(--med-radius);
  overflow: hidden;
  transition: all .25s;
}
.tf-medical-page .med-doctor-card:hover {
  border-color: rgba(6,182,212,.35);
  transform: translateY(-4px);
  box-shadow: 0 20px 40px rgba(0,0,0,.3);
}
.tf-medical-page .med-doctor-photo {
  height: 180px;
  display: flex; align-items: center; justify-content: center;
  font-size: 3rem; font-weight: 800;
  border-bottom: 1px solid var(--med-border);
  position: relative;
}
.tf-medical-page .med-doctor-badge-top {
  position: absolute; top: 12px; right: 12px;
  background: rgba(6,182,212,.15);
  border: 1px solid rgba(6,182,212,.3);
  border-radius: 100px; padding: 3px 10px;
  font-size: .65rem; font-weight: 700;
  color: var(--med-accent); letter-spacing: .04em;
}
.tf-medical-page .med-doctor-info { padding: 20px; }
.tf-medical-page .med-doctor-info h4 {
  font-size: 1rem; font-weight: 700; margin: 0 0 4px; color: var(--med-text);
}
.tf-medical-page .med-doctor-info .doc-specialty {
  font-size: .8rem; color: var(--med-accent); font-weight: 600; margin-bottom: 8px;
}
.tf-medical-page .med-doctor-info .doc-bio {
  font-size: .82rem; color: var(--med-muted); line-height: 1.6; margin-bottom: 16px;
}
.tf-medical-page .med-doctor-meta {
  display: flex; gap: 14px; margin-bottom: 16px;
}
.tf-medical-page .med-doctor-meta span {
  font-size: .75rem; color: var(--med-muted);
  display: flex; align-items: center; gap: 4px;
}
.tf-medical-page .med-doctor-social {
  display: flex; gap: 8px;
}
.tf-medical-page .med-doctor-social a {
  width: 30px; height: 30px; border-radius: 6px;
  border: 1px solid var(--med-border);
  display: flex; align-items: center; justify-content: center;
  color: var(--med-muted); text-decoration: none;
  transition: all .2s;
}
.tf-medical-page .med-doctor-social a:hover {
  border-color: var(--med-accent); color: var(--med-accent);
}

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   7. CERTIFICATIONS STRIP
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-medical-page .med-certs-strip {
  padding: 48px 0;
  border-top: 1px solid var(--med-border);
  border-bottom: 1px solid var(--med-border);
}
.tf-medical-page .med-certs-inner {
  display: flex; flex-wrap: wrap; align-items: center; justify-content: center;
  gap: 32px;
}
.tf-medical-page .med-cert-item {
  display: flex; align-items: center; gap: 12px;
  background: var(--med-card);
  border: 1px solid var(--med-border);
  border-radius: 10px;
  padding: 14px 20px;
}
.tf-medical-page .med-cert-icon {
  width: 40px; height: 40px;
  background: rgba(6,182,212,.1);
  border-radius: 8px;
  display: flex; align-items: center; justify-content: center;
  color: var(--med-accent);
}
.tf-medical-page .med-cert-text strong {
  display: block; font-size: .9rem; color: var(--med-text); font-weight: 700;
}
.tf-medical-page .med-cert-text span {
  font-size: .75rem; color: var(--med-muted);
}

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   8. TESTIMONIALS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-medical-page .med-testi-section { background: var(--med-surface); }
.tf-medical-page .med-testi-head { text-align: center; margin-bottom: 56px; }
.tf-medical-page .med-testi-grid {
  display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px;
}
.tf-medical-page .med-testi-card {
  background: var(--med-card);
  border: 1.5px solid var(--med-border);
  border-radius: var(--med-radius);
  padding: 28px;
  display: flex; flex-direction: column;
}
.tf-medical-page .med-testi-stars {
  display: flex; gap: 4px; margin-bottom: 16px; color: var(--med-accent3);
}
.tf-medical-page .med-testi-quote {
  font-size: .95rem; color: var(--med-muted); line-height: 1.7; font-style: italic;
  flex: 1; margin-bottom: 20px;
}
.tf-medical-page .med-testi-author {
  display: flex; align-items: center; gap: 12px;
  padding-top: 20px; border-top: 1px solid var(--med-border);
}
.tf-medical-page .med-testi-avatar {
  width: 44px; height: 44px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .85rem; font-weight: 700; flex-shrink: 0;
}
.tf-medical-page .med-testi-author-info .testi-name {
  font-size: .9rem; font-weight: 700; color: var(--med-text);
}
.tf-medical-page .med-testi-author-info .testi-meta {
  font-size: .78rem; color: var(--med-muted);
}
.tf-medical-page .med-verified {
  margin-left: auto;
  background: rgba(16,185,129,.1);
  border: 1px solid rgba(16,185,129,.25);
  border-radius: 100px;
  padding: 3px 10px;
  font-size: .65rem; font-weight: 700; color: var(--med-accent2);
}

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   9. CONTACT / CTA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-medical-page .med-contact-section {
  display: grid; grid-template-columns: 1fr 1fr; gap: 64px; align-items: start;
}
.tf-medical-page .med-contact-form-wrap {
  background: var(--med-card);
  border: 1.5px solid var(--med-border);
  border-radius: var(--med-radius);
  padding: 36px;
}
.tf-medical-page .med-form-row {
  display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px;
}
.tf-medical-page .med-form-row.full { grid-template-columns: 1fr; }
.tf-medical-page .med-form-group { display: flex; flex-direction: column; gap: 6px; }
.tf-medical-page .med-form-group label {
  font-size: .8rem; font-weight: 600; color: var(--med-muted);
}
.tf-medical-page .med-form-group input,
.tf-medical-page .med-form-group select,
.tf-medical-page .med-form-group textarea {
  background: var(--med-surface);
  border: 1.5px solid var(--med-border);
  border-radius: 8px;
  padding: 12px 14px;
  color: var(--med-text);
  font-size: .9rem;
  font-family: inherit;
  transition: border-color .2s;
}
.tf-medical-page .med-form-group input:focus,
.tf-medical-page .med-form-group select:focus,
.tf-medical-page .med-form-group textarea:focus {
  outline: none; border-color: var(--med-accent);
}
.tf-medical-page .med-form-group textarea { resize: vertical; min-height: 100px; }
.tf-medical-page .med-form-group select option { background: var(--med-surface); }
.tf-medical-page .med-contact-info { display: flex; flex-direction: column; gap: 24px; }
.tf-medical-page .med-contact-card {
  background: var(--med-card);
  border: 1.5px solid var(--med-border);
  border-radius: var(--med-radius);
  padding: 24px;
  display: flex; align-items: flex-start; gap: 16px;
}
.tf-medical-page .med-contact-card-icon {
  width: 48px; height: 48px; flex-shrink: 0;
  background: rgba(6,182,212,.1);
  border-radius: 12px;
  display: flex; align-items: center; justify-content: center;
  color: var(--med-accent);
}
.tf-medical-page .med-contact-card-body h4 {
  font-size: .95rem; font-weight: 700; margin: 0 0 4px; color: var(--med-text);
}
.tf-medical-page .med-contact-card-body p {
  font-size: .85rem; color: var(--med-muted); margin: 0; line-height: 1.6;
}
.tf-medical-page .med-contact-card-body a {
  color: var(--med-accent); text-decoration: none; font-weight: 600;
}
.tf-medical-page .med-hours-grid {
  display: grid; grid-template-columns: 1fr 1fr; gap: 6px; margin-top: 10px;
}
.tf-medical-page .med-hours-row {
  display: flex; justify-content: space-between; align-items: center;
  font-size: .82rem; padding: 4px 0;
}
.tf-medical-page .med-hours-row span { color: var(--med-muted); }
.tf-medical-page .med-hours-row strong { color: var(--med-text); }

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   Responsive
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
@media (max-width: 1024px) {
  .tf-medical-page .med-spec-grid { grid-template-columns: repeat(2, 1fr); }
  .tf-medical-page .med-doctors-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 768px) {
  .tf-medical-page .med-hero {
    grid-template-columns: 1fr; padding: 80px 0 48px;
  }
  .tf-medical-page .med-monitor-wrap { display: none; }
  .tf-medical-page .med-stats-grid { grid-template-columns: repeat(2, 1fr); gap: 24px; }
  .tf-medical-page .med-stat { border-right: none; border-bottom: 1px solid var(--med-border); padding-bottom: 24px; }
  .tf-medical-page .med-stat:nth-child(3),
  .tf-medical-page .med-stat:nth-child(4) { border-bottom: none; }
  .tf-medical-page .med-about { grid-template-columns: 1fr; gap: 40px; }
  .tf-medical-page .med-spec-grid { grid-template-columns: 1fr; }
  .tf-medical-page .med-doctors-grid { grid-template-columns: 1fr; }
  .tf-medical-page .med-testi-grid { grid-template-columns: 1fr; }
  .tf-medical-page .med-contact-section { grid-template-columns: 1fr; }
  .tf-medical-page .med-form-row { grid-template-columns: 1fr; }
}
</style>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     1. HERO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="med-section">
  <div class="med-container">
    <div class="med-hero">
      <div class="med-hero-content">
        <div class="med-hero-badge">
          <span class="pulse-dot" aria-hidden="true"></span>
          <?php esc_html_e( 'Now Accepting New Patients', 'themeflex' ); ?>
        </div>

        <h1><?php esc_html_e( 'Advanced Care for a', 'themeflex' ); ?><br>
          <em><?php esc_html_e( 'Healthier Future', 'themeflex' ); ?></em></h1>

        <p class="med-sub">
          <?php esc_html_e( 'Expert physicians, cutting-edge diagnostics, and compassionate care — all under one roof. From preventive medicine to complex interventions, we are with you every step.', 'themeflex' ); ?>
        </p>

        <div class="med-hero-actions">
          <a href="#appointment" class="med-btn med-btn-primary" aria-label="<?php esc_attr_e( 'Book an appointment', 'themeflex' ); ?>">
            <?php echo tf_icon_get( 'calendar-plus', 18 ); ?>
            <?php esc_html_e( 'Book Appointment', 'themeflex' ); ?>
          </a>
          <a href="#specialties" class="med-btn med-btn-outline" aria-label="<?php esc_attr_e( 'View our specialties', 'themeflex' ); ?>">
            <?php echo tf_icon_get( 'stethoscope', 18 ); ?>
            <?php esc_html_e( 'Our Specialties', 'themeflex' ); ?>
          </a>
        </div>

        <div class="med-hero-trust" role="list">
          <div class="med-hero-trust-item" role="listitem">
            <?php echo tf_icon_get( 'users', 20 ); ?>
            <div>
              <strong data-counter="50000" data-suffix="+">50,000+</strong>
              <?php esc_html_e( 'Patients Treated', 'themeflex' ); ?>
            </div>
          </div>
          <div class="med-hero-trust-item" role="listitem">
            <?php echo tf_icon_get( 'award', 20 ); ?>
            <div>
              <strong><?php esc_html_e( 'JCI Accredited', 'themeflex' ); ?></strong>
              <?php esc_html_e( 'International Standard', 'themeflex' ); ?>
            </div>
          </div>
          <div class="med-hero-trust-item" role="listitem">
            <?php echo tf_icon_get( 'clock', 20 ); ?>
            <div>
              <strong><?php esc_html_e( '24/7', 'themeflex' ); ?></strong>
              <?php esc_html_e( 'Emergency Care', 'themeflex' ); ?>
            </div>
          </div>
        </div>
      </div>

      <!-- CSS Health Monitor Mockup -->
      <div class="med-monitor-wrap" aria-hidden="true">
        <div class="med-monitor" role="img" aria-label="<?php esc_attr_e( 'Patient health monitoring dashboard illustration', 'themeflex' ); ?>">
          <!-- Topbar -->
          <div class="med-monitor-topbar">
            <div class="dots">
              <span></span><span></span><span></span>
            </div>
            <div class="med-title-bar"><?php esc_html_e( 'HealthCore Dashboard', 'themeflex' ); ?></div>
            <div class="med-live"><?php esc_html_e( 'LIVE', 'themeflex' ); ?></div>
          </div>

          <div class="med-monitor-body">
            <!-- Vitals -->
            <div class="med-vitals" aria-label="<?php esc_attr_e( 'Vital signs', 'themeflex' ); ?>">
              <div class="med-vital-card">
                <div class="vital-label">
                  <?php echo tf_icon_get( 'heart', 12 ); ?>
                  <?php esc_html_e( 'Heart Rate', 'themeflex' ); ?>
                </div>
                <div class="vital-value">72 <span><?php esc_html_e( 'bpm', 'themeflex' ); ?></span></div>
                <div class="vital-status ok"><?php esc_html_e( 'Normal', 'themeflex' ); ?></div>
              </div>
              <div class="med-vital-card">
                <div class="vital-label">
                  <?php echo tf_icon_get( 'activity', 12 ); ?>
                  <?php esc_html_e( 'Blood Pressure', 'themeflex' ); ?>
                </div>
                <div class="vital-value">118<span>/78</span></div>
                <div class="vital-status ok"><?php esc_html_e( 'Optimal', 'themeflex' ); ?></div>
              </div>
              <div class="med-vital-card">
                <div class="vital-label">
                  <?php echo tf_icon_get( 'thermometer', 12 ); ?>
                  <?php esc_html_e( 'Temperature', 'themeflex' ); ?>
                </div>
                <div class="vital-value">36.8<span>°C</span></div>
                <div class="vital-status warn"><?php esc_html_e( 'Slight', 'themeflex' ); ?></div>
              </div>
            </div>

            <!-- ECG Line -->
            <div class="med-ecg-wrap">
              <div class="med-ecg-label">
                <?php esc_html_e( 'ECG', 'themeflex' ); ?>
                <strong><?php esc_html_e( 'Sinus Rhythm', 'themeflex' ); ?></strong>
              </div>
              <svg class="med-ecg-svg" viewBox="0 0 320 48" aria-hidden="true" focusable="false">
                <path class="med-ecg-path" d="M0,24 L30,24 L38,24 L42,8 L46,40 L50,14 L54,24 L60,24 L90,24 L98,24 L102,8 L106,40 L110,14 L114,24 L120,24 L150,24 L158,24 L162,8 L166,40 L170,14 L174,24 L180,24 L210,24 L218,24 L222,8 L226,40 L230,14 L234,24 L240,24 L270,24 L278,24 L282,8 L286,40 L290,14 L294,24 L320,24"/>
              </svg>
            </div>

            <!-- Patient List -->
            <div class="med-patient-list" aria-label="<?php esc_attr_e( 'Today\'s patient schedule', 'themeflex' ); ?>">
              <div class="med-patient-row">
                <div class="med-patient-avatar" style="background:rgba(6,182,212,.15);color:var(--med-accent);">MK</div>
                <div class="med-patient-info">
                  <div class="pat-name"><?php esc_html_e( 'Maria K.', 'themeflex' ); ?></div>
                  <div class="pat-meta"><?php esc_html_e( '09:30 — Cardiology', 'themeflex' ); ?></div>
                </div>
                <span class="med-patient-status inprogress"><?php esc_html_e( 'In Progress', 'themeflex' ); ?></span>
              </div>
              <div class="med-patient-row">
                <div class="med-patient-avatar" style="background:rgba(16,185,129,.15);color:var(--med-accent2);">TH</div>
                <div class="med-patient-info">
                  <div class="pat-name"><?php esc_html_e( 'Thomas H.', 'themeflex' ); ?></div>
                  <div class="pat-meta"><?php esc_html_e( '10:15 — Neurology', 'themeflex' ); ?></div>
                </div>
                <span class="med-patient-status scheduled"><?php esc_html_e( 'Scheduled', 'themeflex' ); ?></span>
              </div>
              <div class="med-patient-row">
                <div class="med-patient-avatar" style="background:rgba(245,158,11,.15);color:var(--med-accent3);">SB</div>
                <div class="med-patient-info">
                  <div class="pat-name"><?php esc_html_e( 'Sophie B.', 'themeflex' ); ?></div>
                  <div class="pat-meta"><?php esc_html_e( '08:00 — Orthopedics', 'themeflex' ); ?></div>
                </div>
                <span class="med-patient-status done"><?php esc_html_e( 'Complete', 'themeflex' ); ?></span>
              </div>
            </div>
          </div>
        </div>

        <!-- Floating appointment card -->
        <div class="med-appt-float" aria-hidden="true">
          <div class="appt-icon"><?php echo tf_icon_get( 'calendar-check', 20 ); ?></div>
          <div class="appt-text">
            <strong><?php esc_html_e( 'Next available slot', 'themeflex' ); ?></strong>
            <span><?php esc_html_e( 'Tomorrow, 10:00 AM', 'themeflex' ); ?></span>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     2. APPOINTMENT BANNER
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="med-appt-banner" id="appointment">
  <div class="med-container">
    <div class="inner">
      <div class="appt-copy">
        <h3><?php esc_html_e( 'Ready to take the first step towards better health?', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'Book online in under 60 seconds. No wait lines, no paperwork upfront.', 'themeflex' ); ?></p>
      </div>
      <div class="appt-info">
        <div class="appt-info-item">
          <?php echo tf_icon_get( 'phone', 18 ); ?>
          <span><?php esc_html_e( '+49 800 123 4567', 'themeflex' ); ?></span>
        </div>
        <div class="appt-info-item">
          <?php echo tf_icon_get( 'clock', 18 ); ?>
          <span><?php esc_html_e( 'Mon–Fri 7:00–20:00', 'themeflex' ); ?></span>
        </div>
      </div>
      <a href="#contact" class="med-btn-appt" aria-label="<?php esc_attr_e( 'Book your appointment now', 'themeflex' ); ?>">
        <?php echo tf_icon_get( 'calendar-plus', 18 ); ?>
        <?php esc_html_e( 'Book Now', 'themeflex' ); ?>
      </a>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     3. SPECIALTIES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="med-section" id="specialties">
  <div class="med-container">
    <div class="med-specialties-head">
      <div class="med-label"><?php esc_html_e( 'Specialties', 'themeflex' ); ?></div>
      <h2 class="med-heading"><?php esc_html_e( 'Comprehensive Medical Care', 'themeflex' ); ?></h2>
      <p class="med-sub">
        <?php esc_html_e( 'Our board-certified specialists cover the full spectrum of medical needs — from prevention and diagnostics to surgery and rehabilitation.', 'themeflex' ); ?>
      </p>
    </div>

    <?php
    $specialties = [
      [
        'icon'    => 'heart-pulse',
        'color'   => 'rgba(239,68,68,.12)',
        'icolor'  => '#ef4444',
        'name'    => __( 'Cardiology', 'themeflex' ),
        'desc'    => __( 'Heart disease prevention, diagnosis, and treatment with state-of-the-art imaging and interventional procedures.', 'themeflex' ),
      ],
      [
        'icon'    => 'brain',
        'color'   => 'rgba(168,85,247,.12)',
        'icolor'  => '#a855f7',
        'name'    => __( 'Neurology', 'themeflex' ),
        'desc'    => __( 'Expert diagnosis and management of neurological disorders including stroke, epilepsy, and movement disorders.', 'themeflex' ),
      ],
      [
        'icon'    => 'bone',
        'color'   => 'rgba(6,182,212,.12)',
        'icolor'  => '#06b6d4',
        'name'    => __( 'Orthopedics', 'themeflex' ),
        'desc'    => __( 'Joint replacement, sports injuries, spinal surgery, and musculoskeletal rehabilitation programmes.', 'themeflex' ),
      ],
      [
        'icon'    => 'baby',
        'color'   => 'rgba(16,185,129,.12)',
        'icolor'  => '#10b981',
        'name'    => __( 'Pediatrics', 'themeflex' ),
        'desc'    => __( 'Specialised care for children from newborn to adolescent, including developmental medicine and vaccinations.', 'themeflex' ),
      ],
      [
        'icon'    => 'microscope',
        'color'   => 'rgba(245,158,11,.12)',
        'icolor'  => '#f59e0b',
        'name'    => __( 'Oncology', 'themeflex' ),
        'desc'    => __( 'Personalised cancer care with immunotherapy, targeted therapies, and precision radiation oncology.', 'themeflex' ),
      ],
      [
        'icon'    => 'eye',
        'color'   => 'rgba(59,130,246,.12)',
        'icolor'  => '#3b82f6',
        'name'    => __( 'Ophthalmology', 'themeflex' ),
        'desc'    => __( 'Comprehensive eye care from routine exams to laser refractive surgery, cataract, and retinal procedures.', 'themeflex' ),
      ],
      [
        'icon'    => 'lungs',
        'color'   => 'rgba(6,182,212,.12)',
        'icolor'  => '#06b6d4',
        'name'    => __( 'Pulmonology', 'themeflex' ),
        'desc'    => __( 'Diagnosis and treatment of respiratory diseases including asthma, COPD, and sleep disorders.', 'themeflex' ),
      ],
      [
        'icon'    => 'shield-check',
        'color'   => 'rgba(16,185,129,.12)',
        'icolor'  => '#10b981',
        'name'    => __( 'Preventive Medicine', 'themeflex' ),
        'desc'    => __( 'Health screenings, lifestyle coaching, genetic risk assessment, and wellness programmes.', 'themeflex' ),
      ],
    ];
    ?>

    <div class="med-spec-grid" role="list">
      <?php foreach ( $specialties as $spec ) : ?>
        <article class="med-spec-card" role="listitem">
          <div class="med-spec-icon" style="background:<?php echo esc_attr( $spec['color'] ); ?>;color:<?php echo esc_attr( $spec['icolor'] ); ?>;"
               aria-hidden="true">
            <?php echo tf_icon_get( esc_attr( $spec['icon'] ), 24 ); ?>
          </div>
          <h4><?php echo esc_html( $spec['name'] ); ?></h4>
          <p><?php echo esc_html( $spec['desc'] ); ?></p>
          <a href="#appointment" aria-label="<?php printf( esc_attr__( 'Book appointment for %s', 'themeflex' ), esc_attr( $spec['name'] ) ); ?>">
            <?php esc_html_e( 'Book Now', 'themeflex' ); ?>
            <?php echo tf_icon_get( 'arrow-right', 14 ); ?>
          </a>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     4. STATS BAR
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="med-stats-bar" aria-label="<?php esc_attr_e( 'Key statistics', 'themeflex' ); ?>">
  <div class="med-container">
    <div class="med-stats-grid" role="list">
      <?php
      $stats = [
        [ 'num' => 50000,  'suffix' => '+',  'label' => __( 'Patients Treated Annually', 'themeflex' ) ],
        [ 'num' => 120,    'suffix' => '+',  'label' => __( 'Board-Certified Physicians', 'themeflex' ) ],
        [ 'num' => 25,     'suffix' => '',   'label' => __( 'Years of Excellence', 'themeflex' ) ],
        [ 'num' => 98,     'suffix' => '%',  'label' => __( 'Patient Satisfaction Rate', 'themeflex' ) ],
      ];
      foreach ( $stats as $stat ) :
      ?>
        <div class="med-stat" role="listitem">
          <div class="med-stat-num" data-counter="<?php echo esc_attr( $stat['num'] ); ?>" data-suffix="<?php echo esc_attr( $stat['suffix'] ); ?>">
            <?php echo esc_html( number_format( $stat['num'] ) . $stat['suffix'] ); ?>
          </div>
          <div class="med-stat-label"><?php echo esc_html( $stat['label'] ); ?></div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     5. ABOUT / OUR APPROACH
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="med-section">
  <div class="med-container">
    <div class="med-about">
      <!-- CSS Health Visual -->
      <div class="med-health-visual" aria-hidden="true">
        <div class="med-health-header">
          <h4><?php esc_html_e( 'Recovery Rate by Department', 'themeflex' ); ?></h4>
          <span class="period"><?php esc_html_e( 'Q1 2026', 'themeflex' ); ?></span>
        </div>
        <div class="med-chart-bars" aria-hidden="true">
          <?php
          $bars = [
            ['h' => '78%',  'l' => 'Card.'],
            ['h' => '92%',  'l' => 'Ortho'],
            ['h' => '85%',  'l' => 'Neuro'],
            ['h' => '95%',  'l' => 'Peds'],
            ['h' => '70%',  'l' => 'Onco'],
            ['h' => '88%',  'l' => 'Pulm'],
          ];
          foreach ( $bars as $b ) :
          ?>
            <div class="med-chart-bar-wrap">
              <div class="med-chart-bar" style="height:<?php echo esc_attr( $b['h'] ); ?>;"></div>
              <div class="med-chart-bar-label"><?php echo esc_html( $b['l'] ); ?></div>
            </div>
          <?php endforeach; ?>
        </div>
        <div class="med-health-metrics">
          <div class="med-health-metric">
            <div class="hm-label"><?php esc_html_e( 'Avg. Recovery', 'themeflex' ); ?></div>
            <div class="hm-value">4.2 <small style="font-size:.7rem;color:var(--med-muted);"><?php esc_html_e( 'days', 'themeflex' ); ?></small></div>
            <div class="hm-delta up"><?php echo tf_icon_get( 'trending-down', 12 ); ?> <?php esc_html_e( '18% faster', 'themeflex' ); ?></div>
          </div>
          <div class="med-health-metric">
            <div class="hm-label"><?php esc_html_e( 'Success Rate', 'themeflex' ); ?></div>
            <div class="hm-value">96.4%</div>
            <div class="hm-delta up"><?php echo tf_icon_get( 'trending-up', 12 ); ?> <?php esc_html_e( '+2.1% YoY', 'themeflex' ); ?></div>
          </div>
          <div class="med-health-metric">
            <div class="hm-label"><?php esc_html_e( 'Readmission', 'themeflex' ); ?></div>
            <div class="hm-value">1.8%</div>
            <div class="hm-delta up"><?php echo tf_icon_get( 'trending-down', 12 ); ?> <?php esc_html_e( 'Below avg.', 'themeflex' ); ?></div>
          </div>
          <div class="med-health-metric">
            <div class="hm-label"><?php esc_html_e( 'NPS Score', 'themeflex' ); ?></div>
            <div class="hm-value">82</div>
            <div class="hm-delta up"><?php echo tf_icon_get( 'trending-up', 12 ); ?> <?php esc_html_e( 'World-class', 'themeflex' ); ?></div>
          </div>
        </div>
      </div>

      <!-- Text side -->
      <div>
        <div class="med-label"><?php esc_html_e( 'Our Approach', 'themeflex' ); ?></div>
        <h2 class="med-heading"><?php esc_html_e( 'Evidence-Based Medicine, Human-Centered Care', 'themeflex' ); ?></h2>
        <p class="med-sub">
          <?php esc_html_e( 'We combine rigorous clinical protocols with genuine compassion. Every care pathway is built on the latest evidence, personalised for you.', 'themeflex' ); ?>
        </p>

        <ol class="med-approach-list" aria-label="<?php esc_attr_e( 'Our care approach', 'themeflex' ); ?>">
          <?php
          $steps = [
            [
              'title' => __( 'Thorough Diagnostics', 'themeflex' ),
              'desc'  => __( 'Advanced imaging (MRI, CT, PET), genomic testing, and AI-assisted screening to pinpoint issues early.', 'themeflex' ),
            ],
            [
              'title' => __( 'Personalised Treatment Plan', 'themeflex' ),
              'desc'  => __( 'A multidisciplinary team reviews your case and crafts a plan tailored to your biology, lifestyle, and goals.', 'themeflex' ),
            ],
            [
              'title' => __( 'Expert Intervention', 'themeflex' ),
              'desc'  => __( 'Minimally invasive procedures wherever possible, performed by internationally trained specialists.', 'themeflex' ),
            ],
            [
              'title' => __( 'Continuity of Care', 'themeflex' ),
              'desc'  => __( 'Follow-up, rehabilitation, and preventive monitoring to ensure lasting health outcomes.', 'themeflex' ),
            ],
          ];
          foreach ( $steps as $i => $step ) :
          ?>
            <li class="med-approach-item">
              <div class="med-approach-num" aria-hidden="true"><?php echo esc_html( $i + 1 ); ?></div>
              <div class="med-approach-body">
                <h5><?php echo esc_html( $step['title'] ); ?></h5>
                <p><?php echo esc_html( $step['desc'] ); ?></p>
              </div>
            </li>
          <?php endforeach; ?>
        </ol>
      </div>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     6. DOCTORS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="med-section med-doctors-section" id="doctors">
  <div class="med-container">
    <div class="med-doctors-head">
      <div class="med-label"><?php esc_html_e( 'Our Team', 'themeflex' ); ?></div>
      <h2 class="med-heading"><?php esc_html_e( 'Meet Our Specialists', 'themeflex' ); ?></h2>
      <p class="med-sub" style="margin:0 auto;">
        <?php esc_html_e( 'Over 120 board-certified physicians across 20+ specialties, trained at world-leading medical institutions.', 'themeflex' ); ?>
      </p>
    </div>

    <?php
    $doctors = [
      [
        'initials'   => 'AK',
        'bg'         => 'linear-gradient(135deg,rgba(6,182,212,.2),rgba(6,182,212,.05))',
        'color'      => '#06b6d4',
        'name'       => __( 'Dr. Anna Kellner', 'themeflex' ),
        'specialty'  => __( 'Cardiology', 'themeflex' ),
        'badge'      => __( 'Department Head', 'themeflex' ),
        'bio'        => __( 'Harvard Medical graduate with 18 years of interventional cardiology experience and 200+ peer-reviewed publications.', 'themeflex' ),
        'exp'        => __( '18 yrs exp.', 'themeflex' ),
        'rating'     => '4.9',
      ],
      [
        'initials'   => 'MV',
        'bg'         => 'linear-gradient(135deg,rgba(168,85,247,.2),rgba(168,85,247,.05))',
        'color'      => '#a855f7',
        'name'       => __( 'Dr. Marco Vidal', 'themeflex' ),
        'specialty'  => __( 'Neurology', 'themeflex' ),
        'badge'      => __( 'Research Lead', 'themeflex' ),
        'bio'        => __( 'Specialises in movement disorders and deep brain stimulation. Trained at Johns Hopkins and Charité Berlin.', 'themeflex' ),
        'exp'        => __( '14 yrs exp.', 'themeflex' ),
        'rating'     => '4.8',
      ],
      [
        'initials'   => 'SB',
        'bg'         => 'linear-gradient(135deg,rgba(16,185,129,.2),rgba(16,185,129,.05))',
        'color'      => '#10b981',
        'name'       => __( 'Dr. Sarah Bauer', 'themeflex' ),
        'specialty'  => __( 'Oncology', 'themeflex' ),
        'badge'      => __( 'Senior Consultant', 'themeflex' ),
        'bio'        => __( 'Precision oncology pioneer with expertise in immunotherapy and targeted cancer therapies for solid tumours.', 'themeflex' ),
        'exp'        => __( '11 yrs exp.', 'themeflex' ),
        'rating'     => '4.9',
      ],
      [
        'initials'   => 'RL',
        'bg'         => 'linear-gradient(135deg,rgba(245,158,11,.2),rgba(245,158,11,.05))',
        'color'      => '#f59e0b',
        'name'       => __( 'Dr. Rafael Lima', 'themeflex' ),
        'specialty'  => __( 'Orthopedics', 'themeflex' ),
        'badge'      => __( 'Sports Medicine', 'themeflex' ),
        'bio'        => __( 'Robotic-assisted joint replacement specialist and team physician for professional sports organisations.', 'themeflex' ),
        'exp'        => __( '16 yrs exp.', 'themeflex' ),
        'rating'     => '4.7',
      ],
    ];
    ?>

    <div class="med-doctors-grid">
      <?php foreach ( $doctors as $doc ) : ?>
        <article class="med-doctor-card">
          <div class="med-doctor-photo" style="background:<?php echo esc_attr( $doc['bg'] ); ?>;color:<?php echo esc_attr( $doc['color'] ); ?>;" aria-hidden="true">
            <?php echo esc_html( $doc['initials'] ); ?>
            <div class="med-doctor-badge-top"><?php echo esc_html( $doc['badge'] ); ?></div>
          </div>
          <div class="med-doctor-info">
            <h4><?php echo esc_html( $doc['name'] ); ?></h4>
            <div class="doc-specialty"><?php echo esc_html( $doc['specialty'] ); ?></div>
            <p class="doc-bio"><?php echo esc_html( $doc['bio'] ); ?></p>
            <div class="med-doctor-meta">
              <span>
                <?php echo tf_icon_get( 'clock', 13 ); ?>
                <?php echo esc_html( $doc['exp'] ); ?>
              </span>
              <span>
                <?php echo tf_icon_get( 'star', 13 ); ?>
                <?php echo esc_html( $doc['rating'] ); ?>
              </span>
            </div>
            <div class="med-doctor-social">
              <a href="#" aria-label="<?php printf( esc_attr__( '%s on LinkedIn', 'themeflex' ), esc_attr( $doc['name'] ) ); ?>">
                <?php echo tf_icon_get( 'linkedin', 14 ); ?>
              </a>
              <a href="#" aria-label="<?php printf( esc_attr__( 'Email %s', 'themeflex' ), esc_attr( $doc['name'] ) ); ?>">
                <?php echo tf_icon_get( 'mail', 14 ); ?>
              </a>
              <a href="#appointment" aria-label="<?php printf( esc_attr__( 'Book appointment with %s', 'themeflex' ), esc_attr( $doc['name'] ) ); ?>">
                <?php echo tf_icon_get( 'calendar-plus', 14 ); ?>
              </a>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     7. CERTIFICATIONS STRIP
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="med-certs-strip" aria-label="<?php esc_attr_e( 'Accreditations and certifications', 'themeflex' ); ?>">
  <div class="med-container">
    <div class="med-certs-inner" role="list">
      <?php
      $certs = [
        [ 'icon' => 'shield-check', 'name' => __( 'JCI Accredited', 'themeflex' ),       'meta' => __( 'Joint Commission International', 'themeflex' ) ],
        [ 'icon' => 'award',        'name' => __( 'ISO 9001:2015', 'themeflex' ),         'meta' => __( 'Quality Management Certified', 'themeflex' ) ],
        [ 'icon' => 'star',         'name' => __( 'Top Hospital 2025', 'themeflex' ),     'meta' => __( 'Focus Magazin Rating', 'themeflex' ) ],
        [ 'icon' => 'heart',        'name' => __( 'Cardiac Centre', 'themeflex' ),        'meta' => __( 'DGK Certified', 'themeflex' ) ],
        [ 'icon' => 'microscope',   'name' => __( 'Oncology CoE', 'themeflex' ),          'meta' => __( 'European Commission Designation', 'themeflex' ) ],
        [ 'icon' => 'activity',     'name' => __( 'Trauma Centre L1', 'themeflex' ),      'meta' => __( 'DGU Certified', 'themeflex' ) ],
      ];
      foreach ( $certs as $cert ) :
      ?>
        <div class="med-cert-item" role="listitem">
          <div class="med-cert-icon" aria-hidden="true"><?php echo tf_icon_get( esc_attr( $cert['icon'] ), 20 ); ?></div>
          <div class="med-cert-text">
            <strong><?php echo esc_html( $cert['name'] ); ?></strong>
            <span><?php echo esc_html( $cert['meta'] ); ?></span>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     8. TESTIMONIALS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="med-section med-testi-section">
  <div class="med-container">
    <div class="med-testi-head">
      <div class="med-label"><?php esc_html_e( 'Patient Stories', 'themeflex' ); ?></div>
      <h2 class="med-heading"><?php esc_html_e( 'What Our Patients Say', 'themeflex' ); ?></h2>
    </div>

    <?php
    $testimonials = [
      [
        'initials' => 'EH',
        'bg'       => 'linear-gradient(135deg,#06b6d4,#0891b2)',
        'quote'    => __( 'After my cardiac procedure at HealthCore, I was back on my bike within six weeks. Dr. Kellner and the entire cardiology team were exceptional — professional, caring, and always available for questions.', 'themeflex' ),
        'name'     => __( 'Ernst H.', 'themeflex' ),
        'meta'     => __( 'Cardiac Surgery Patient', 'themeflex' ),
      ],
      [
        'initials' => 'LM',
        'bg'       => 'linear-gradient(135deg,#a855f7,#7c3aed)',
        'quote'    => __( 'The neurology department changed my life. After years of misdiagnoses elsewhere, they found the root cause of my condition and started a treatment that actually works. I am genuinely grateful.', 'themeflex' ),
        'name'     => __( 'Laura M.', 'themeflex' ),
        'meta'     => __( 'Neurology Patient', 'themeflex' ),
      ],
      [
        'initials' => 'JP',
        'bg'       => 'linear-gradient(135deg,#10b981,#059669)',
        'quote'    => __( 'From the moment I arrived, everything was seamless — the diagnostics were fast, the treatment plan was explained clearly, and the follow-up care was thorough. Best medical experience I have had.', 'themeflex' ),
        'name'     => __( 'Jonas P.', 'themeflex' ),
        'meta'     => __( 'Orthopedics Patient', 'themeflex' ),
      ],
    ];
    ?>

    <div class="med-testi-grid">
      <?php foreach ( $testimonials as $t ) : ?>
        <div class="med-testi-card">
          <div class="med-testi-stars" aria-label="<?php esc_attr_e( '5 out of 5 stars', 'themeflex' ); ?>">
            <?php for ( $i = 0; $i < 5; $i++ ) : ?>
              <?php echo tf_icon_get( 'star', 16 ); ?>
            <?php endfor; ?>
          </div>
          <blockquote class="med-testi-quote">
            &ldquo;<?php echo esc_html( $t['quote'] ); ?>&rdquo;
          </blockquote>
          <div class="med-testi-author">
            <div class="med-testi-avatar" style="background:<?php echo esc_attr( $t['bg'] ); ?>;color:#fff;" aria-hidden="true">
              <?php echo esc_html( $t['initials'] ); ?>
            </div>
            <div class="med-testi-author-info">
              <div class="testi-name"><?php echo esc_html( $t['name'] ); ?></div>
              <div class="testi-meta"><?php echo esc_html( $t['meta'] ); ?></div>
            </div>
            <div class="med-verified" aria-label="<?php esc_attr_e( 'Verified patient review', 'themeflex' ); ?>">
              <?php echo tf_icon_get( 'check', 10 ); ?>
              <?php esc_html_e( 'Verified', 'themeflex' ); ?>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     9. CONTACT / APPOINTMENT FORM
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="med-section" id="contact">
  <div class="med-container">
    <div class="med-label" style="margin-bottom:16px;"><?php esc_html_e( 'Contact & Appointments', 'themeflex' ); ?></div>
    <h2 class="med-heading" style="margin-bottom:48px;"><?php esc_html_e( 'Get in Touch', 'themeflex' ); ?></h2>

    <div class="med-contact-section">
      <!-- Form -->
      <div class="med-contact-form-wrap">
        <h3 style="font-size:1.2rem;margin:0 0 24px;color:var(--med-text);"><?php esc_html_e( 'Book an Appointment', 'themeflex' ); ?></h3>
        <form action="#" method="post" aria-label="<?php esc_attr_e( 'Appointment request form', 'themeflex' ); ?>">
          <?php wp_nonce_field( 'medical_appointment', 'med_appt_nonce' ); ?>
          <div class="med-form-row">
            <div class="med-form-group">
              <label for="med-fname"><?php esc_html_e( 'First Name', 'themeflex' ); ?></label>
              <input type="text" id="med-fname" name="fname" required
                     placeholder="<?php esc_attr_e( 'Anna', 'themeflex' ); ?>"
                     autocomplete="given-name">
            </div>
            <div class="med-form-group">
              <label for="med-lname"><?php esc_html_e( 'Last Name', 'themeflex' ); ?></label>
              <input type="text" id="med-lname" name="lname" required
                     placeholder="<?php esc_attr_e( 'Müller', 'themeflex' ); ?>"
                     autocomplete="family-name">
            </div>
          </div>
          <div class="med-form-row">
            <div class="med-form-group">
              <label for="med-email"><?php esc_html_e( 'Email', 'themeflex' ); ?></label>
              <input type="email" id="med-email" name="email" required
                     placeholder="<?php esc_attr_e( 'anna@example.com', 'themeflex' ); ?>"
                     autocomplete="email">
            </div>
            <div class="med-form-group">
              <label for="med-phone"><?php esc_html_e( 'Phone', 'themeflex' ); ?></label>
              <input type="tel" id="med-phone" name="phone"
                     placeholder="<?php esc_attr_e( '+49 30 ...', 'themeflex' ); ?>"
                     autocomplete="tel">
            </div>
          </div>
          <div class="med-form-row">
            <div class="med-form-group">
              <label for="med-specialty"><?php esc_html_e( 'Specialty', 'themeflex' ); ?></label>
              <select id="med-specialty" name="specialty">
                <option value=""><?php esc_html_e( 'Select Specialty', 'themeflex' ); ?></option>
                <option value="cardiology"><?php esc_html_e( 'Cardiology', 'themeflex' ); ?></option>
                <option value="neurology"><?php esc_html_e( 'Neurology', 'themeflex' ); ?></option>
                <option value="orthopedics"><?php esc_html_e( 'Orthopedics', 'themeflex' ); ?></option>
                <option value="pediatrics"><?php esc_html_e( 'Pediatrics', 'themeflex' ); ?></option>
                <option value="oncology"><?php esc_html_e( 'Oncology', 'themeflex' ); ?></option>
                <option value="other"><?php esc_html_e( 'Other', 'themeflex' ); ?></option>
              </select>
            </div>
            <div class="med-form-group">
              <label for="med-date"><?php esc_html_e( 'Preferred Date', 'themeflex' ); ?></label>
              <input type="date" id="med-date" name="pref_date">
            </div>
          </div>
          <div class="med-form-row full">
            <div class="med-form-group">
              <label for="med-message"><?php esc_html_e( 'Brief Description of Symptoms', 'themeflex' ); ?></label>
              <textarea id="med-message" name="message"
                        placeholder="<?php esc_attr_e( 'Please briefly describe your concern or symptoms…', 'themeflex' ); ?>"></textarea>
            </div>
          </div>
          <button type="submit" class="med-btn med-btn-primary" style="width:100%;justify-content:center;margin-top:8px;"
                  aria-label="<?php esc_attr_e( 'Submit appointment request', 'themeflex' ); ?>">
            <?php echo tf_icon_get( 'calendar-check', 18 ); ?>
            <?php esc_html_e( 'Request Appointment', 'themeflex' ); ?>
          </button>
          <p style="font-size:.75rem;color:var(--med-muted);text-align:center;margin:12px 0 0;">
            <?php esc_html_e( 'We will contact you within 2 business hours to confirm.', 'themeflex' ); ?>
          </p>
        </form>
      </div>

      <!-- Contact Info -->
      <div class="med-contact-info">
        <div class="med-contact-card">
          <div class="med-contact-card-icon" aria-hidden="true"><?php echo tf_icon_get( 'map-pin', 22 ); ?></div>
          <div class="med-contact-card-body">
            <h4><?php esc_html_e( 'Visit Us', 'themeflex' ); ?></h4>
            <p>
              <?php esc_html_e( 'HealthCore Medical Centre', 'themeflex' ); ?><br>
              <?php esc_html_e( 'Friedrichstraße 120, 10117 Berlin', 'themeflex' ); ?>
            </p>
          </div>
        </div>

        <div class="med-contact-card">
          <div class="med-contact-card-icon" aria-hidden="true"><?php echo tf_icon_get( 'phone', 22 ); ?></div>
          <div class="med-contact-card-body">
            <h4><?php esc_html_e( 'Call Us', 'themeflex' ); ?></h4>
            <p>
              <a href="tel:+498001234567">+49 800 123 4567</a> <?php esc_html_e( '(Appointments)', 'themeflex' ); ?><br>
              <a href="tel:+4930112233">+49 30 11 22 33</a> <?php esc_html_e( '(Emergency)', 'themeflex' ); ?>
            </p>
          </div>
        </div>

        <div class="med-contact-card">
          <div class="med-contact-card-icon" aria-hidden="true"><?php echo tf_icon_get( 'clock', 22 ); ?></div>
          <div class="med-contact-card-body">
            <h4><?php esc_html_e( 'Opening Hours', 'themeflex' ); ?></h4>
            <div class="med-hours-grid" aria-label="<?php esc_attr_e( 'Opening hours', 'themeflex' ); ?>">
              <?php
              $hours = [
                [ 'd' => __( 'Mon–Fri', 'themeflex' ), 'h' => '07:00–20:00' ],
                [ 'd' => __( 'Saturday', 'themeflex' ), 'h' => '08:00–16:00' ],
                [ 'd' => __( 'Sunday', 'themeflex' ),   'h' => __( 'Emergency only', 'themeflex' ) ],
                [ 'd' => __( 'Holidays', 'themeflex' ),  'h' => '09:00–14:00' ],
              ];
              foreach ( $hours as $h ) :
              ?>
                <div class="med-hours-row">
                  <span><?php echo esc_html( $h['d'] ); ?></span>
                  <strong><?php echo esc_html( $h['h'] ); ?></strong>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
        </div>

        <div class="med-contact-card" style="background:linear-gradient(135deg,rgba(239,68,68,.08),rgba(239,68,68,.03));border-color:rgba(239,68,68,.2);">
          <div class="med-contact-card-icon" style="background:rgba(239,68,68,.1);color:#ef4444;" aria-hidden="true">
            <?php echo tf_icon_get( 'ambulance', 22 ); ?>
          </div>
          <div class="med-contact-card-body">
            <h4 style="color:#ef4444;"><?php esc_html_e( 'Emergency', 'themeflex' ); ?></h4>
            <p><?php esc_html_e( 'For life-threatening emergencies, please call the European emergency number.', 'themeflex' ); ?></p>
            <p><strong style="font-size:1.4rem;color:#ef4444;">112</strong></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

</div><!-- /.tf-medical-page -->

<script>
(function () {
  'use strict';
  var counters = document.querySelectorAll('.tf-medical-page [data-counter]');
  if (!counters.length || !window.IntersectionObserver) return;
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (!entry.isIntersecting) return;
      io.unobserve(entry.target);
      var el     = entry.target;
      var target = parseInt(el.dataset.counter, 10);
      var suffix = el.dataset.suffix || '';
      var start  = 0;
      var dur    = 1800;
      var step   = 16;
      var inc    = target / (dur / step);
      var timer  = setInterval(function () {
        start += inc;
        if (start >= target) {
          start = target;
          clearInterval(timer);
        }
        el.textContent = (start >= 1000 ? Math.round(start).toLocaleString() : Math.round(start)) + suffix;
      }, step);
    });
  }, { threshold: 0.3 });
  counters.forEach(function (c) { io.observe(c); });
})();
</script>

<?php get_footer(); ?>
