<?php
/**
 * Template Name: Gym & Fitness Homepage
 *
 * Premium Gym / Fitness Centre landing page for ThemeFlex.
 * Dark-first with energetic orange-red accents, CSS fitness tracker
 * hero, membership plans, class schedule, trainer team, stats, testimonials.
 *
 * @package ThemeFlex
 * @since   2.9.0
 */

get_header();
?>

<div class="tf-gym-page">

<style>
/* ─── Tokens ──────────────────────────────────────────────────── */
.tf-gym-page {
  --gym-bg:       #0a0a0a;
  --gym-surface:  #111111;
  --gym-card:     #181818;
  --gym-border:   rgba(255,255,255,.07);
  --gym-accent:   #f97316;   /* fire orange */
  --gym-accent2:  #ef4444;   /* red / power */
  --gym-accent3:  #facc15;   /* gold / premium */
  --gym-text:     #f5f5f5;
  --gym-muted:    #888888;
  --gym-radius:   12px;
  background: var(--gym-bg);
  color: var(--gym-text);
  font-family: var(--tf-font-body, 'Inter', sans-serif);
}
.tf-gym-page .gym-container { max-width: 1200px; margin: 0 auto; padding: 0 24px; }
.tf-gym-page .gym-section   { padding: 88px 0; }
.tf-gym-page .gym-label {
  display: inline-flex; align-items: center; gap: 8px;
  font-size: .72rem; font-weight: 700; letter-spacing: .14em; text-transform: uppercase;
  color: var(--gym-accent); margin-bottom: 14px;
}
.tf-gym-page .gym-label::before { content:''; width:20px; height:2px; background:var(--gym-accent); border-radius:2px; }
.tf-gym-page .gym-heading {
  font-family: var(--tf-font-heading, 'Inter Tight', sans-serif);
  font-size: clamp(2rem, 4vw, 2.8rem);
  font-weight: 800; line-height: 1.15; margin: 0 0 18px;
}
.tf-gym-page .gym-sub { font-size: 1.05rem; color: var(--gym-muted); line-height: 1.7; max-width: 540px; }
.tf-gym-page .gym-btn {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 14px 28px; border-radius: 8px; font-size: .95rem; font-weight: 700;
  text-decoration: none; cursor: pointer; border: none; transition: all .2s;
}
.tf-gym-page .gym-btn-primary { background: var(--gym-accent); color: #000; }
.tf-gym-page .gym-btn-primary:hover { background: #fb923c; }
.tf-gym-page .gym-btn-outline {
  background: transparent; color: var(--gym-text); border: 1.5px solid var(--gym-border);
}
.tf-gym-page .gym-btn-outline:hover { border-color: var(--gym-accent); color: var(--gym-accent); }

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   1. HERO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-gym-page .gym-hero {
  min-height: 100vh; padding: 120px 0 80px;
  display: grid; grid-template-columns: 1fr 1fr; gap: 60px;
  align-items: center; position: relative; overflow: hidden;
}
.tf-gym-page .gym-hero::before {
  content: '';
  position: absolute; bottom: -200px; left: -200px;
  width: 600px; height: 600px;
  background: radial-gradient(circle, rgba(249,115,22,.1) 0%, transparent 70%);
  pointer-events: none;
}
.tf-gym-page .gym-hero-tag {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(249,115,22,.12); border: 1px solid rgba(249,115,22,.3);
  border-radius: 100px; padding: 6px 14px;
  font-size: .78rem; font-weight: 700; color: var(--gym-accent); margin-bottom: 22px;
}
.tf-gym-page .gym-hero h1 {
  font-family: var(--tf-font-heading, 'Inter Tight', sans-serif);
  font-size: clamp(2.8rem, 6vw, 4.5rem);
  font-weight: 900; line-height: 1.05; margin: 0 0 22px; text-transform: uppercase;
}
.tf-gym-page .gym-hero h1 em {
  font-style: normal;
  background: linear-gradient(135deg, var(--gym-accent), var(--gym-accent2));
  -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
}
.tf-gym-page .gym-hero-actions { display: flex; flex-wrap: wrap; gap: 12px; margin-top: 32px; }
.tf-gym-page .gym-hero-perks {
  display: flex; gap: 20px; margin-top: 36px; flex-wrap: wrap;
}
.tf-gym-page .gym-hero-perk {
  display: flex; align-items: center; gap: 8px;
  font-size: .82rem; color: var(--gym-muted);
}
.tf-gym-page .gym-hero-perk-icon {
  width: 28px; height: 28px; border-radius: 6px;
  background: rgba(249,115,22,.1); display: flex; align-items: center; justify-content: center;
  color: var(--gym-accent);
}

/* CSS Fitness Tracker Mockup */
.tf-gym-page .gym-tracker {
  background: var(--gym-surface);
  border: 1.5px solid var(--gym-border);
  border-radius: 20px; padding: 24px;
  box-shadow: 0 40px 80px rgba(0,0,0,.5);
  position: relative;
}
.tf-gym-page .gym-tracker-header {
  display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px;
}
.tf-gym-page .gym-tracker-header h4 { font-size: .85rem; font-weight: 700; margin: 0; }
.tf-gym-page .gym-tracker-header .streak {
  display: flex; align-items: center; gap: 6px;
  background: rgba(249,115,22,.1); border-radius: 100px; padding: 4px 12px;
  font-size: .72rem; font-weight: 700; color: var(--gym-accent);
}
/* Progress rings row */
.tf-gym-page .gym-rings-row {
  display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 16px;
}
.tf-gym-page .gym-ring-card {
  background: var(--gym-card); border: 1px solid var(--gym-border);
  border-radius: 10px; padding: 14px; text-align: center;
}
.tf-gym-page .gym-ring-svg { width: 56px; height: 56px; margin: 0 auto 8px; display: block; }
.tf-gym-page .gym-ring-track { fill: none; stroke: rgba(255,255,255,.06); stroke-width: 5; }
.tf-gym-page .gym-ring-fill  {
  fill: none; stroke-width: 5; stroke-linecap: round;
  stroke-dasharray: 138; stroke-dashoffset: 138;
  animation: gym-ring-draw 1.4s cubic-bezier(.34,1.56,.64,1) forwards .6s;
  transform-origin: center; transform: rotate(-90deg);
}
@keyframes gym-ring-draw { to { stroke-dashoffset: var(--ring-offset, 40); } }
.tf-gym-page .gym-ring-label { font-size: .65rem; color: var(--gym-muted); text-transform: uppercase; letter-spacing: .06em; }
.tf-gym-page .gym-ring-val   { font-size: .9rem; font-weight: 700; color: var(--gym-text); }
/* Weekly bar chart */
.tf-gym-page .gym-weekly {
  background: var(--gym-card); border: 1px solid var(--gym-border);
  border-radius: 10px; padding: 14px; margin-bottom: 14px;
}
.tf-gym-page .gym-weekly-top {
  display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;
  font-size: .75rem; color: var(--gym-muted);
}
.tf-gym-page .gym-weekly-top strong { color: var(--gym-accent); }
.tf-gym-page .gym-bars-wrap {
  display: flex; align-items: flex-end; gap: 6px; height: 64px;
}
.tf-gym-page .gym-bar-col { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 4px; }
.tf-gym-page .gym-bar {
  width: 100%; border-radius: 3px 3px 0 0;
  transition: height .8s cubic-bezier(.34,1.56,.64,1);
}
.tf-gym-page .gym-bar.active { background: var(--gym-accent); }
.tf-gym-page .gym-bar.done   { background: rgba(249,115,22,.3); }
.tf-gym-page .gym-bar.rest   { background: rgba(255,255,255,.05); }
.tf-gym-page .gym-bar-day { font-size: .6rem; color: var(--gym-muted); }
/* Today session card */
.tf-gym-page .gym-today-card {
  background: linear-gradient(135deg, rgba(249,115,22,.15), rgba(249,115,22,.03));
  border: 1.5px solid rgba(249,115,22,.25); border-radius: 10px; padding: 14px;
  display: flex; align-items: center; gap: 14px;
}
.tf-gym-page .gym-today-icon {
  width: 42px; height: 42px; flex-shrink: 0;
  background: var(--gym-accent); border-radius: 10px;
  display: flex; align-items: center; justify-content: center; color: #000;
}
.tf-gym-page .gym-today-info strong { display: block; font-size: .9rem; color: var(--gym-text); }
.tf-gym-page .gym-today-info span   { font-size: .78rem; color: var(--gym-muted); }
.tf-gym-page .gym-today-stats {
  margin-left: auto; display: flex; gap: 14px;
}
.tf-gym-page .gym-today-stat { text-align: center; }
.tf-gym-page .gym-today-stat strong { display: block; font-size: .9rem; color: var(--gym-text); }
.tf-gym-page .gym-today-stat span { font-size: .65rem; color: var(--gym-muted); }
/* Floating PR chip */
.tf-gym-page .gym-pr-float {
  position: absolute; top: -18px; right: -18px;
  background: var(--gym-accent2); color: #fff;
  border-radius: 10px; padding: 10px 14px;
  display: flex; align-items: center; gap: 8px;
  font-size: .78rem; font-weight: 700;
  box-shadow: 0 12px 32px rgba(239,68,68,.4);
  animation: gym-float 4s ease-in-out infinite;
}
@keyframes gym-float {
  0%,100% { transform: translateY(0) rotate(-2deg); }
  50%      { transform: translateY(-8px) rotate(0deg); }
}

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   2. STATS BAR
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-gym-page .gym-stats-bar {
  background: var(--gym-accent); padding: 40px 0;
}
.tf-gym-page .gym-stats-grid {
  display: grid; grid-template-columns: repeat(4, 1fr); gap: 0;
}
.tf-gym-page .gym-stat {
  text-align: center; padding: 0 24px;
  border-right: 1px solid rgba(0,0,0,.15);
}
.tf-gym-page .gym-stat:last-child { border-right: none; }
.tf-gym-page .gym-stat-num {
  font-family: var(--tf-font-heading, 'Inter Tight', sans-serif);
  font-size: 2.5rem; font-weight: 900; color: #000; line-height: 1; margin-bottom: 4px;
}
.tf-gym-page .gym-stat-label { font-size: .82rem; color: rgba(0,0,0,.7); font-weight: 600; }

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   3. MEMBERSHIP PLANS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-gym-page .gym-plans-head { text-align: center; margin-bottom: 52px; }
.tf-gym-page .gym-plans-head .gym-sub { margin: 0 auto; }
.tf-gym-page .gym-plans-grid {
  display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; align-items: start;
}
.tf-gym-page .gym-plan-card {
  background: var(--gym-card); border: 1.5px solid var(--gym-border);
  border-radius: var(--gym-radius); padding: 32px; position: relative; overflow: hidden;
  transition: all .25s;
}
.tf-gym-page .gym-plan-card:hover { transform: translateY(-4px); border-color: rgba(249,115,22,.3); }
.tf-gym-page .gym-plan-card.featured {
  border-color: var(--gym-accent);
  background: linear-gradient(145deg, rgba(249,115,22,.08), var(--gym-card));
  transform: scale(1.03);
}
.tf-gym-page .gym-plan-badge {
  position: absolute; top: 16px; right: 16px;
  background: var(--gym-accent); color: #000;
  font-size: .65rem; font-weight: 800; letter-spacing: .1em; text-transform: uppercase;
  padding: 4px 10px; border-radius: 100px;
}
.tf-gym-page .gym-plan-name { font-size: .8rem; font-weight: 700; color: var(--gym-muted); text-transform: uppercase; letter-spacing: .1em; margin-bottom: 12px; }
.tf-gym-page .gym-plan-price {
  font-family: var(--tf-font-heading, 'Inter Tight', sans-serif);
  font-size: 3rem; font-weight: 900; line-height: 1; margin-bottom: 4px;
}
.tf-gym-page .gym-plan-price sup { font-size: 1.2rem; vertical-align: super; }
.tf-gym-page .gym-plan-price sub { font-size: .9rem; color: var(--gym-muted); font-weight: 400; }
.tf-gym-page .gym-plan-note { font-size: .78rem; color: var(--gym-muted); margin-bottom: 24px; }
.tf-gym-page .gym-plan-divider { height: 1px; background: var(--gym-border); margin-bottom: 24px; }
.tf-gym-page .gym-plan-features { list-style: none; margin: 0 0 28px; padding: 0; display: flex; flex-direction: column; gap: 12px; }
.tf-gym-page .gym-plan-feature {
  display: flex; align-items: center; gap: 10px; font-size: .875rem;
}
.tf-gym-page .gym-plan-feature .feat-icon { flex-shrink: 0; }
.tf-gym-page .gym-plan-feature .feat-icon.yes { color: var(--gym-accent); }
.tf-gym-page .gym-plan-feature .feat-icon.no  { color: rgba(255,255,255,.2); }
.tf-gym-page .gym-plan-feature.dim { color: var(--gym-muted); }

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   4. CLASS SCHEDULE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-gym-page .gym-schedule-section { background: var(--gym-surface); }
.tf-gym-page .gym-schedule-head { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 36px; }
.tf-gym-page .gym-schedule-head-left {}
.tf-gym-page .gym-day-tabs { display: flex; gap: 8px; }
.tf-gym-page .gym-day-tab {
  padding: 8px 16px; border-radius: 6px; font-size: .8rem; font-weight: 600;
  background: var(--gym-card); border: 1.5px solid var(--gym-border);
  color: var(--gym-muted); text-decoration: none; transition: all .2s;
}
.tf-gym-page .gym-day-tab.active,
.tf-gym-page .gym-day-tab:hover { background: var(--gym-accent); color: #000; border-color: var(--gym-accent); }
.tf-gym-page .gym-schedule-grid { display: flex; flex-direction: column; gap: 8px; }
.tf-gym-page .gym-class-row {
  display: grid; grid-template-columns: 100px 1fr 140px 100px 80px;
  align-items: center; gap: 16px;
  background: var(--gym-card); border: 1.5px solid var(--gym-border);
  border-radius: 10px; padding: 16px 20px; transition: all .2s;
}
.tf-gym-page .gym-class-row:hover { border-color: rgba(249,115,22,.3); }
.tf-gym-page .gym-class-time { font-size: .85rem; font-weight: 700; color: var(--gym-text); }
.tf-gym-page .gym-class-time span { display: block; font-size: .72rem; color: var(--gym-muted); font-weight: 400; }
.tf-gym-page .gym-class-info h4 { font-size: .95rem; font-weight: 700; margin: 0 0 3px; }
.tf-gym-page .gym-class-info span { font-size: .75rem; color: var(--gym-muted); }
.tf-gym-page .gym-class-trainer {
  display: flex; align-items: center; gap: 8px; font-size: .8rem;
}
.tf-gym-page .gym-trainer-dot {
  width: 28px; height: 28px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .6rem; font-weight: 700; flex-shrink: 0;
}
.tf-gym-page .gym-class-spots {
  font-size: .78rem; text-align: center;
}
.tf-gym-page .gym-class-spots .spots-num { font-size: 1.1rem; font-weight: 700; }
.tf-gym-page .gym-class-spots .spots-num.low { color: var(--gym-accent2); }
.tf-gym-page .gym-class-spots .spots-num.ok  { color: var(--gym-accent); }
.tf-gym-page .gym-class-cta a {
  display: inline-flex; align-items: center; justify-content: center;
  padding: 8px 16px; border-radius: 6px;
  font-size: .8rem; font-weight: 700; text-decoration: none;
  background: var(--gym-accent); color: #000; transition: background .2s; white-space: nowrap;
}
.tf-gym-page .gym-class-cta a:hover { background: #fb923c; }
.tf-gym-page .gym-class-cta a.full {
  background: rgba(255,255,255,.05); color: var(--gym-muted); cursor: not-allowed;
}

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   5. TRAINERS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-gym-page .gym-trainers-head { text-align: center; margin-bottom: 52px; }
.tf-gym-page .gym-trainers-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; }
.tf-gym-page .gym-trainer-card {
  background: var(--gym-card); border: 1.5px solid var(--gym-border);
  border-radius: var(--gym-radius); overflow: hidden; transition: all .25s;
}
.tf-gym-page .gym-trainer-card:hover { border-color: rgba(249,115,22,.3); transform: translateY(-4px); }
.tf-gym-page .gym-trainer-photo {
  height: 200px; display: flex; align-items: center; justify-content: center;
  font-size: 3.5rem; font-weight: 900; position: relative;
  border-bottom: 1px solid var(--gym-border);
}
.tf-gym-page .gym-trainer-cert {
  position: absolute; bottom: 12px; left: 12px;
  background: rgba(0,0,0,.8); border: 1px solid var(--gym-border); border-radius: 6px;
  padding: 4px 10px; font-size: .65rem; font-weight: 700; color: var(--gym-accent);
}
.tf-gym-page .gym-trainer-info { padding: 18px; }
.tf-gym-page .gym-trainer-info h4 { font-size: .95rem; font-weight: 700; margin: 0 0 3px; }
.tf-gym-page .gym-trainer-info .specialty { font-size: .78rem; color: var(--gym-accent); font-weight: 600; margin-bottom: 10px; }
.tf-gym-page .gym-trainer-info p { font-size: .8rem; color: var(--gym-muted); line-height: 1.6; margin-bottom: 12px; }
.tf-gym-page .gym-trainer-tags { display: flex; flex-wrap: wrap; gap: 6px; }
.tf-gym-page .gym-trainer-tag {
  background: rgba(249,115,22,.1); color: var(--gym-accent);
  border-radius: 100px; padding: 3px 10px; font-size: .65rem; font-weight: 700;
}

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   6. TRANSFORMATIONS / TESTIMONIALS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-gym-page .gym-testi-section { background: var(--gym-surface); }
.tf-gym-page .gym-testi-head { text-align: center; margin-bottom: 52px; }
.tf-gym-page .gym-testi-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; }
.tf-gym-page .gym-testi-card {
  background: var(--gym-card); border: 1.5px solid var(--gym-border);
  border-radius: var(--gym-radius); padding: 28px;
}
.tf-gym-page .gym-testi-result {
  display: flex; gap: 16px; margin-bottom: 20px;
  padding-bottom: 20px; border-bottom: 1px solid var(--gym-border);
}
.tf-gym-page .gym-result-chip {
  flex: 1; background: rgba(249,115,22,.08); border: 1px solid rgba(249,115,22,.2);
  border-radius: 8px; padding: 10px; text-align: center;
}
.tf-gym-page .gym-result-chip .chip-num { font-size: 1.3rem; font-weight: 800; color: var(--gym-accent); }
.tf-gym-page .gym-result-chip .chip-label { font-size: .65rem; color: var(--gym-muted); text-transform: uppercase; letter-spacing: .06em; }
.tf-gym-page .gym-testi-quote { font-size: .9rem; color: var(--gym-muted); line-height: 1.7; font-style: italic; margin-bottom: 18px; }
.tf-gym-page .gym-testi-author { display: flex; align-items: center; gap: 10px; }
.tf-gym-page .gym-testi-avatar {
  width: 40px; height: 40px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .8rem; font-weight: 700; flex-shrink: 0;
}
.tf-gym-page .gym-testi-name { font-size: .88rem; font-weight: 700; }
.tf-gym-page .gym-testi-meta { font-size: .72rem; color: var(--gym-muted); }
.tf-gym-page .gym-testi-duration {
  margin-left: auto; font-size: .72rem; color: var(--gym-muted);
  display: flex; align-items: center; gap: 4px;
}

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   7. CTA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-gym-page .gym-cta-section {
  background: linear-gradient(135deg, #1a0800 0%, #0a0a0a 100%);
  position: relative; overflow: hidden; text-align: center;
}
.tf-gym-page .gym-cta-section::before {
  content: '';
  position: absolute; inset: 0;
  background: radial-gradient(ellipse 80% 60% at 50% 50%, rgba(249,115,22,.1) 0%, transparent 70%);
}
.tf-gym-page .gym-cta-section h2 {
  font-family: var(--tf-font-heading, 'Inter Tight', sans-serif);
  font-size: clamp(2rem, 5vw, 3.5rem); font-weight: 900;
  text-transform: uppercase; margin: 0 0 16px; line-height: 1.1;
  position: relative; z-index: 1;
}
.tf-gym-page .gym-cta-section h2 em {
  font-style: normal;
  background: linear-gradient(135deg, var(--gym-accent), var(--gym-accent2));
  -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
}
.tf-gym-page .gym-cta-section p {
  font-size: 1.05rem; color: var(--gym-muted); margin: 0 auto 36px; max-width: 500px; position: relative; z-index: 1;
}
.tf-gym-page .gym-cta-actions { display: flex; gap: 14px; justify-content: center; flex-wrap: wrap; position: relative; z-index: 1; }
.tf-gym-page .gym-cta-meta { margin-top: 28px; font-size: .8rem; color: var(--gym-muted); position: relative; z-index: 1; }
.tf-gym-page .gym-cta-meta span { margin: 0 12px; }

/* Responsive */
@media (max-width: 1024px) {
  .tf-gym-page .gym-trainers-grid { grid-template-columns: repeat(2,1fr); }
  .tf-gym-page .gym-class-row { grid-template-columns: 90px 1fr 100px 80px; }
  .tf-gym-page .gym-class-spots { display: none; }
}
@media (max-width: 768px) {
  .tf-gym-page .gym-hero { grid-template-columns: 1fr; }
  .tf-gym-page .gym-tracker { display: none; }
  .tf-gym-page .gym-stats-grid { grid-template-columns: repeat(2,1fr); }
  .tf-gym-page .gym-plans-grid { grid-template-columns: 1fr; }
  .tf-gym-page .gym-plan-card.featured { transform: none; }
  .tf-gym-page .gym-trainers-grid { grid-template-columns: 1fr; }
  .tf-gym-page .gym-testi-grid { grid-template-columns: 1fr; }
  .tf-gym-page .gym-class-row { grid-template-columns: 1fr; }
  .tf-gym-page .gym-schedule-head { flex-direction: column; align-items: flex-start; gap: 16px; }
}
</style>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     1. HERO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="gym-section">
  <div class="gym-container">
    <div class="gym-hero">
      <div>
        <div class="gym-hero-tag">
          <?php echo tf_icon_get( 'flame', 14 ); ?>
          <?php esc_html_e( 'Now Enrolling — July Cohort', 'themeflex' ); ?>
        </div>
        <h1>
          <?php esc_html_e( 'Forge Your', 'themeflex' ); ?><br>
          <em><?php esc_html_e( 'Best Self', 'themeflex' ); ?></em><br>
          <?php esc_html_e( 'Here.', 'themeflex' ); ?>
        </h1>
        <p class="gym-sub">
          <?php esc_html_e( 'Elite coaching, science-backed programming, and a community that pushes you further than you\'d go alone. No excuses. Only results.', 'themeflex' ); ?>
        </p>
        <div class="gym-hero-actions">
          <a href="#membership" class="gym-btn gym-btn-primary" aria-label="<?php esc_attr_e( 'Start free trial', 'themeflex' ); ?>">
            <?php echo tf_icon_get( 'zap', 18 ); ?>
            <?php esc_html_e( 'Start Free Trial', 'themeflex' ); ?>
          </a>
          <a href="#schedule" class="gym-btn gym-btn-outline" aria-label="<?php esc_attr_e( 'View class schedule', 'themeflex' ); ?>">
            <?php echo tf_icon_get( 'calendar', 18 ); ?>
            <?php esc_html_e( 'View Schedule', 'themeflex' ); ?>
          </a>
        </div>
        <div class="gym-hero-perks">
          <?php
          $perks = [
            [ 'icon' => 'check-circle', 'text' => __( 'No lock-in contract', 'themeflex' ) ],
            [ 'icon' => 'clock',        'text' => __( 'Open 24/7',           'themeflex' ) ],
            [ 'icon' => 'users',        'text' => __( '3,200+ members',      'themeflex' ) ],
          ];
          foreach ( $perks as $p ) :
          ?>
            <div class="gym-hero-perk">
              <div class="gym-hero-perk-icon" aria-hidden="true"><?php echo tf_icon_get( esc_attr( $p['icon'] ), 14 ); ?></div>
              <span><?php echo esc_html( $p['text'] ); ?></span>
            </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- CSS Fitness Tracker -->
      <div class="gym-tracker" aria-hidden="true" role="img" aria-label="<?php esc_attr_e( 'Fitness tracking dashboard illustration', 'themeflex' ); ?>">
        <div class="gym-pr-float">
          <?php echo tf_icon_get( 'trophy', 16 ); ?>
          <?php esc_html_e( 'New PR! Bench 120 kg', 'themeflex' ); ?>
        </div>

        <div class="gym-tracker-header">
          <h4><?php esc_html_e( 'My Training Dashboard', 'themeflex' ); ?></h4>
          <div class="streak"><?php echo tf_icon_get( 'flame', 12 ); ?> 14 day streak</div>
        </div>

        <!-- Progress Rings -->
        <div class="gym-rings-row">
          <div class="gym-ring-card">
            <svg class="gym-ring-svg" viewBox="0 0 56 56" aria-hidden="true" focusable="false">
              <circle class="gym-ring-track" cx="28" cy="28" r="22"/>
              <circle class="gym-ring-fill" cx="28" cy="28" r="22" stroke="#f97316" style="--ring-offset:28;"/>
            </svg>
            <div class="gym-ring-val">82%</div>
            <div class="gym-ring-label"><?php esc_html_e( 'Calories', 'themeflex' ); ?></div>
          </div>
          <div class="gym-ring-card">
            <svg class="gym-ring-svg" viewBox="0 0 56 56" aria-hidden="true" focusable="false">
              <circle class="gym-ring-track" cx="28" cy="28" r="22"/>
              <circle class="gym-ring-fill" cx="28" cy="28" r="22" stroke="#06b6d4" style="--ring-offset:55;"/>
            </svg>
            <div class="gym-ring-val">6/10</div>
            <div class="gym-ring-label"><?php esc_html_e( 'Sets', 'themeflex' ); ?></div>
          </div>
          <div class="gym-ring-card">
            <svg class="gym-ring-svg" viewBox="0 0 56 56" aria-hidden="true" focusable="false">
              <circle class="gym-ring-track" cx="28" cy="28" r="22"/>
              <circle class="gym-ring-fill" cx="28" cy="28" r="22" stroke="#10b981" style="--ring-offset:20;"/>
            </svg>
            <div class="gym-ring-val">94%</div>
            <div class="gym-ring-label"><?php esc_html_e( 'Volume', 'themeflex' ); ?></div>
          </div>
        </div>

        <!-- Weekly bars -->
        <div class="gym-weekly">
          <div class="gym-weekly-top">
            <span><?php esc_html_e( 'This Week', 'themeflex' ); ?></span>
            <strong><?php esc_html_e( '5/6 sessions', 'themeflex' ); ?></strong>
          </div>
          <div class="gym-bars-wrap" aria-hidden="true">
            <?php
            $days = [
              ['d'=>'M','h'=>'85%','c'=>'done'],
              ['d'=>'T','h'=>'100%','c'=>'done'],
              ['d'=>'W','h'=>'70%','c'=>'done'],
              ['d'=>'T','h'=>'90%','c'=>'done'],
              ['d'=>'F','h'=>'100%','c'=>'active'],
              ['d'=>'S','h'=>'20%','c'=>'rest'],
              ['d'=>'S','h'=>'10%','c'=>'rest'],
            ];
            foreach ( $days as $d ) :
            ?>
              <div class="gym-bar-col">
                <div class="gym-bar <?php echo esc_attr( $d['c'] ); ?>" style="height:<?php echo esc_attr( $d['h'] ); ?>;"></div>
                <span class="gym-bar-day"><?php echo esc_html( $d['d'] ); ?></span>
              </div>
            <?php endforeach; ?>
          </div>
        </div>

        <!-- Today's session -->
        <div class="gym-today-card">
          <div class="gym-today-icon" aria-hidden="true"><?php echo tf_icon_get( 'dumbbell', 20 ); ?></div>
          <div class="gym-today-info">
            <strong><?php esc_html_e( 'Upper Body Power', 'themeflex' ); ?></strong>
            <span><?php esc_html_e( 'Today · 18:00 with Coach Alex', 'themeflex' ); ?></span>
          </div>
          <div class="gym-today-stats">
            <div class="gym-today-stat">
              <strong>62<small style="font-size:.6rem">min</small></strong>
              <span><?php esc_html_e( 'Duration', 'themeflex' ); ?></span>
            </div>
            <div class="gym-today-stat">
              <strong>480</strong>
              <span><?php esc_html_e( 'kcal', 'themeflex' ); ?></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     2. STATS BAR
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="gym-stats-bar" aria-label="<?php esc_attr_e( 'Key statistics', 'themeflex' ); ?>">
  <div class="gym-container">
    <div class="gym-stats-grid" role="list">
      <?php
      $stats = [
        [ 'num' => 3200,  'suffix' => '+',  'label' => __( 'Active Members', 'themeflex' ) ],
        [ 'num' => 42,    'suffix' => '+',  'label' => __( 'Classes Per Week', 'themeflex' ) ],
        [ 'num' => 18,    'suffix' => '',   'label' => __( 'Expert Trainers', 'themeflex' ) ],
        [ 'num' => 97,    'suffix' => '%',  'label' => __( 'Member Satisfaction', 'themeflex' ) ],
      ];
      foreach ( $stats as $s ) :
      ?>
        <div class="gym-stat" role="listitem">
          <div class="gym-stat-num" data-counter="<?php echo esc_attr( $s['num'] ); ?>" data-suffix="<?php echo esc_attr( $s['suffix'] ); ?>">
            <?php echo esc_html( number_format( $s['num'] ) . $s['suffix'] ); ?>
          </div>
          <div class="gym-stat-label"><?php echo esc_html( $s['label'] ); ?></div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     3. MEMBERSHIP PLANS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="gym-section" id="membership">
  <div class="gym-container">
    <div class="gym-plans-head">
      <div class="gym-label"><?php esc_html_e( 'Membership', 'themeflex' ); ?></div>
      <h2 class="gym-heading"><?php esc_html_e( 'Simple, Transparent Pricing', 'themeflex' ); ?></h2>
      <p class="gym-sub"><?php esc_html_e( 'No hidden fees. Cancel any time. Pick the plan that fits your goals.', 'themeflex' ); ?></p>
    </div>

    <?php
    $plans = [
      [
        'name'     => __( 'Starter', 'themeflex' ),
        'price'    => '29',
        'note'     => __( 'per month, billed monthly', 'themeflex' ),
        'featured' => false,
        'badge'    => '',
        'features' => [
          [ 'yes' => true,  'text' => __( 'Gym floor access (6 AM–10 PM)', 'themeflex' ) ],
          [ 'yes' => true,  'text' => __( 'Locker room + showers', 'themeflex' ) ],
          [ 'yes' => true,  'text' => __( '2 group classes per week', 'themeflex' ) ],
          [ 'yes' => false, 'text' => __( 'Personal trainer sessions', 'themeflex' ) ],
          [ 'yes' => false, 'text' => __( 'Nutrition coaching', 'themeflex' ) ],
          [ 'yes' => false, 'text' => __( '24/7 access + guest passes', 'themeflex' ) ],
        ],
      ],
      [
        'name'     => __( 'Elite', 'themeflex' ),
        'price'    => '59',
        'note'     => __( 'per month, billed monthly', 'themeflex' ),
        'featured' => true,
        'badge'    => __( 'Most Popular', 'themeflex' ),
        'features' => [
          [ 'yes' => true, 'text' => __( '24/7 gym floor access', 'themeflex' ) ],
          [ 'yes' => true, 'text' => __( 'Locker room + showers + sauna', 'themeflex' ) ],
          [ 'yes' => true, 'text' => __( 'Unlimited group classes', 'themeflex' ) ],
          [ 'yes' => true, 'text' => __( '2 PT sessions per month', 'themeflex' ) ],
          [ 'yes' => true, 'text' => __( 'Basic nutrition plan', 'themeflex' ) ],
          [ 'yes' => false, 'text' => __( '2 guest passes per month', 'themeflex' ) ],
        ],
      ],
      [
        'name'     => __( 'Champion', 'themeflex' ),
        'price'    => '99',
        'note'     => __( 'per month, billed monthly', 'themeflex' ),
        'featured' => false,
        'badge'    => '',
        'features' => [
          [ 'yes' => true, 'text' => __( '24/7 gym floor access', 'themeflex' ) ],
          [ 'yes' => true, 'text' => __( 'Full spa & recovery suite', 'themeflex' ) ],
          [ 'yes' => true, 'text' => __( 'Unlimited group classes', 'themeflex' ) ],
          [ 'yes' => true, 'text' => __( '4 PT sessions per month', 'themeflex' ) ],
          [ 'yes' => true, 'text' => __( 'Full nutrition & meal coaching', 'themeflex' ) ],
          [ 'yes' => true, 'text' => __( '4 guest passes per month', 'themeflex' ) ],
        ],
      ],
    ];
    ?>

    <div class="gym-plans-grid">
      <?php foreach ( $plans as $plan ) : ?>
        <div class="gym-plan-card <?php echo $plan['featured'] ? 'featured' : ''; ?>">
          <?php if ( $plan['badge'] ) : ?>
            <div class="gym-plan-badge"><?php echo esc_html( $plan['badge'] ); ?></div>
          <?php endif; ?>
          <div class="gym-plan-name"><?php echo esc_html( $plan['name'] ); ?></div>
          <div class="gym-plan-price"><sup>€</sup><?php echo esc_html( $plan['price'] ); ?><sub>/<?php esc_html_e( 'mo', 'themeflex' ); ?></sub></div>
          <div class="gym-plan-note"><?php echo esc_html( $plan['note'] ); ?></div>
          <div class="gym-plan-divider"></div>
          <ul class="gym-plan-features" aria-label="<?php printf( esc_attr__( '%s plan features', 'themeflex' ), esc_attr( $plan['name'] ) ); ?>">
            <?php foreach ( $plan['features'] as $feat ) : ?>
              <li class="gym-plan-feature <?php echo ! $feat['yes'] ? 'dim' : ''; ?>">
                <span class="feat-icon <?php echo $feat['yes'] ? 'yes' : 'no'; ?>" aria-hidden="true">
                  <?php echo tf_icon_get( $feat['yes'] ? 'check' : 'x', 16 ); ?>
                </span>
                <?php echo esc_html( $feat['text'] ); ?>
              </li>
            <?php endforeach; ?>
          </ul>
          <a href="#" class="gym-btn <?php echo $plan['featured'] ? 'gym-btn-primary' : 'gym-btn-outline'; ?>"
             style="width:100%;justify-content:center;"
             aria-label="<?php printf( esc_attr__( 'Get %s plan', 'themeflex' ), esc_attr( $plan['name'] ) ); ?>">
            <?php echo tf_icon_get( 'arrow-right', 16 ); ?>
            <?php esc_html_e( 'Get Started', 'themeflex' ); ?>
          </a>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     4. CLASS SCHEDULE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="gym-section gym-schedule-section" id="schedule">
  <div class="gym-container">
    <div class="gym-schedule-head">
      <div>
        <div class="gym-label"><?php esc_html_e( 'Classes', 'themeflex' ); ?></div>
        <h2 class="gym-heading" style="margin:0;"><?php esc_html_e( 'Today\'s Schedule', 'themeflex' ); ?></h2>
      </div>
      <nav class="gym-day-tabs" aria-label="<?php esc_attr_e( 'Filter schedule by day', 'themeflex' ); ?>">
        <?php
        $days = [
          __( 'Mon', 'themeflex' ), __( 'Tue', 'themeflex' ), __( 'Wed', 'themeflex' ),
          __( 'Thu', 'themeflex' ), __( 'Fri', 'themeflex' ), __( 'Sat', 'themeflex' ),
        ];
        foreach ( $days as $i => $day ) :
        ?>
          <a href="#" class="gym-day-tab <?php echo $i === 4 ? 'active' : ''; ?>"
             aria-current="<?php echo $i === 4 ? 'true' : 'false'; ?>">
            <?php echo esc_html( $day ); ?>
          </a>
        <?php endforeach; ?>
      </nav>
    </div>

    <?php
    $classes = [
      [
        'time' => '06:00', 'dur' => '45 min',
        'name' => __( 'HIIT Ignite', 'themeflex' ),
        'type' => __( 'High Intensity', 'themeflex' ),
        'trainer_init' => 'AK', 'trainer_bg' => '#f97316', 'trainer' => __( 'Alex K.', 'themeflex' ),
        'spots' => 3, 'max' => 20, 'status' => 'low',
      ],
      [
        'time' => '08:30', 'dur' => '60 min',
        'name' => __( 'Yoga Flow', 'themeflex' ),
        'type' => __( 'Flexibility & Mind', 'themeflex' ),
        'trainer_init' => 'SM', 'trainer_bg' => '#a855f7', 'trainer' => __( 'Sara M.', 'themeflex' ),
        'spots' => 12, 'max' => 18, 'status' => 'ok',
      ],
      [
        'time' => '10:00', 'dur' => '50 min',
        'name' => __( 'Cycle Power', 'themeflex' ),
        'type' => __( 'Cardio', 'themeflex' ),
        'trainer_init' => 'JR', 'trainer_bg' => '#06b6d4', 'trainer' => __( 'Jake R.', 'themeflex' ),
        'spots' => 0, 'max' => 20, 'status' => 'full',
      ],
      [
        'time' => '12:00', 'dur' => '45 min',
        'name' => __( 'Boxing Fundamentals', 'themeflex' ),
        'type' => __( 'Combat Sports', 'themeflex' ),
        'trainer_init' => 'TC', 'trainer_bg' => '#ef4444', 'trainer' => __( 'Tony C.', 'themeflex' ),
        'spots' => 8, 'max' => 16, 'status' => 'ok',
      ],
      [
        'time' => '17:30', 'dur' => '55 min',
        'name' => __( 'Strength & Conditioning', 'themeflex' ),
        'type' => __( 'Strength', 'themeflex' ),
        'trainer_init' => 'AK', 'trainer_bg' => '#f97316', 'trainer' => __( 'Alex K.', 'themeflex' ),
        'spots' => 5, 'max' => 14, 'status' => 'low',
      ],
      [
        'time' => '19:00', 'dur' => '60 min',
        'name' => __( 'Pilates Core', 'themeflex' ),
        'type' => __( 'Core & Stability', 'themeflex' ),
        'trainer_init' => 'NL', 'trainer_bg' => '#10b981', 'trainer' => __( 'Nina L.', 'themeflex' ),
        'spots' => 9, 'max' => 18, 'status' => 'ok',
      ],
    ];
    ?>

    <div class="gym-schedule-grid" role="list">
      <?php foreach ( $classes as $cls ) : ?>
        <div class="gym-class-row" role="listitem">
          <div class="gym-class-time">
            <?php echo esc_html( $cls['time'] ); ?>
            <span><?php echo esc_html( $cls['dur'] ); ?></span>
          </div>
          <div class="gym-class-info">
            <h4><?php echo esc_html( $cls['name'] ); ?></h4>
            <span><?php echo esc_html( $cls['type'] ); ?></span>
          </div>
          <div class="gym-class-trainer">
            <div class="gym-trainer-dot" style="background:<?php echo esc_attr( $cls['trainer_bg'] ); ?>;color:#000;" aria-hidden="true">
              <?php echo esc_html( $cls['trainer_init'] ); ?>
            </div>
            <span><?php echo esc_html( $cls['trainer'] ); ?></span>
          </div>
          <div class="gym-class-spots" aria-label="<?php printf( esc_attr__( '%d spots remaining', 'themeflex' ), $cls['spots'] ); ?>">
            <div class="spots-num <?php echo esc_attr( $cls['status'] ); ?>">
              <?php echo $cls['status'] === 'full' ? esc_html__( 'Full', 'themeflex' ) : esc_html( $cls['spots'] ); ?>
            </div>
            <div><?php $cls['status'] === 'full' ? esc_html_e( 'Waitlist', 'themeflex' ) : esc_html_e( 'spots left', 'themeflex' ); ?></div>
          </div>
          <div class="gym-class-cta">
            <a href="#" class="<?php echo $cls['status'] === 'full' ? 'full' : ''; ?>"
               aria-label="<?php printf( esc_attr__( 'Book %s', 'themeflex' ), esc_attr( $cls['name'] ) ); ?>"
               <?php echo $cls['status'] === 'full' ? 'aria-disabled="true"' : ''; ?>>
              <?php $cls['status'] === 'full' ? esc_html_e( 'Waitlist', 'themeflex' ) : esc_html_e( 'Book', 'themeflex' ); ?>
            </a>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     5. TRAINERS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="gym-section">
  <div class="gym-container">
    <div class="gym-trainers-head">
      <div class="gym-label"><?php esc_html_e( 'Our Team', 'themeflex' ); ?></div>
      <h2 class="gym-heading"><?php esc_html_e( 'World-Class Coaches', 'themeflex' ); ?></h2>
      <p class="gym-sub" style="margin:0 auto;"><?php esc_html_e( 'Every trainer is certified, experienced, and obsessed with helping you hit your goals faster.', 'themeflex' ); ?></p>
    </div>
    <?php
    $trainers = [
      [
        'init'    => 'AK',
        'bg'      => 'linear-gradient(135deg,rgba(249,115,22,.2),rgba(249,115,22,.05))',
        'color'   => '#f97316',
        'name'    => __( 'Alex König', 'themeflex' ),
        'spec'    => __( 'Strength & S&C', 'themeflex' ),
        'cert'    => __( 'NSCA-CSCS', 'themeflex' ),
        'bio'     => __( '12 years coaching elite athletes. Former national-level powerlifter. Specialises in periodised strength blocks.', 'themeflex' ),
        'tags'    => [ __( 'Powerlifting', 'themeflex' ), __( 'Peaking', 'themeflex' ), __( 'Olympic Lifting', 'themeflex' ) ],
      ],
      [
        'init'    => 'SM',
        'bg'      => 'linear-gradient(135deg,rgba(168,85,247,.2),rgba(168,85,247,.05))',
        'color'   => '#a855f7',
        'name'    => __( 'Sara Müller', 'themeflex' ),
        'spec'    => __( 'Yoga & Mobility', 'themeflex' ),
        'cert'    => __( 'RYT-500', 'themeflex' ),
        'bio'     => __( 'Trained in Mysore, India. Expert in injury-prevention mobility and mental resilience through movement.', 'themeflex' ),
        'tags'    => [ __( 'Vinyasa', 'themeflex' ), __( 'Mobility', 'themeflex' ), __( 'Breathwork', 'themeflex' ) ],
      ],
      [
        'init'    => 'JR',
        'bg'      => 'linear-gradient(135deg,rgba(6,182,212,.2),rgba(6,182,212,.05))',
        'color'   => '#06b6d4',
        'name'    => __( 'Jake Roth', 'themeflex' ),
        'spec'    => __( 'Cardio & HIIT', 'themeflex' ),
        'cert'    => __( 'ACE-CPT', 'themeflex' ),
        'bio'     => __( 'Endurance athlete turned coach. Ran 14 marathons. Programs interval and threshold training for all fitness levels.', 'themeflex' ),
        'tags'    => [ __( 'Running', 'themeflex' ), __( 'HIIT', 'themeflex' ), __( 'Cycling', 'themeflex' ) ],
      ],
      [
        'init'    => 'TC',
        'bg'      => 'linear-gradient(135deg,rgba(239,68,68,.2),rgba(239,68,68,.05))',
        'color'   => '#ef4444',
        'name'    => __( 'Tony Castillo', 'themeflex' ),
        'spec'    => __( 'Boxing & Combat', 'themeflex' ),
        'cert'    => __( 'USA Boxing', 'themeflex' ),
        'bio'     => __( 'Golden Gloves champion. Trains fighters and fitness enthusiasts alike in technique, footwork, and conditioning.', 'themeflex' ),
        'tags'    => [ __( 'Boxing', 'themeflex' ), __( 'Kickboxing', 'themeflex' ), __( 'MMA', 'themeflex' ) ],
      ],
    ];
    ?>
    <div class="gym-trainers-grid">
      <?php foreach ( $trainers as $tr ) : ?>
        <article class="gym-trainer-card">
          <div class="gym-trainer-photo" style="background:<?php echo esc_attr( $tr['bg'] ); ?>;color:<?php echo esc_attr( $tr['color'] ); ?>;" aria-hidden="true">
            <?php echo esc_html( $tr['init'] ); ?>
            <div class="gym-trainer-cert"><?php echo esc_html( $tr['cert'] ); ?></div>
          </div>
          <div class="gym-trainer-info">
            <h4><?php echo esc_html( $tr['name'] ); ?></h4>
            <div class="specialty"><?php echo esc_html( $tr['spec'] ); ?></div>
            <p><?php echo esc_html( $tr['bio'] ); ?></p>
            <div class="gym-trainer-tags">
              <?php foreach ( $tr['tags'] as $tag ) : ?>
                <span class="gym-trainer-tag"><?php echo esc_html( $tag ); ?></span>
              <?php endforeach; ?>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     6. TRANSFORMATIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="gym-section gym-testi-section">
  <div class="gym-container">
    <div class="gym-testi-head">
      <div class="gym-label"><?php esc_html_e( 'Results', 'themeflex' ); ?></div>
      <h2 class="gym-heading"><?php esc_html_e( 'Real People. Real Results.', 'themeflex' ); ?></h2>
    </div>
    <?php
    $testimonials = [
      [
        'init'    => 'MW',
        'bg'      => 'linear-gradient(135deg,#f97316,#ea580c)',
        'results' => [ ['-18 kg', __( 'Body Fat', 'themeflex' )], ['+42%', __( 'Strength', 'themeflex' )] ],
        'quote'   => __( 'In 6 months I went from barely being able to run 1 km to completing my first half marathon. Alex\'s programming and the gym community made it happen.', 'themeflex' ),
        'name'    => __( 'Marcus W.', 'themeflex' ),
        'meta'    => __( 'Elite member since 2024', 'themeflex' ),
        'dur'     => __( '6 months', 'themeflex' ),
      ],
      [
        'init'    => 'LF',
        'bg'      => 'linear-gradient(135deg,#a855f7,#7c3aed)',
        'results' => [ ['-12 kg', __( 'Weight', 'themeflex' )], ['2× faster', __( 'Recovery', 'themeflex' )] ],
        'quote'   => __( 'The yoga and mobility sessions completely fixed my chronic back pain. I feel stronger and more pain-free than I did in my 20s.', 'themeflex' ),
        'name'    => __( 'Laura F.', 'themeflex' ),
        'meta'    => __( 'Champion member', 'themeflex' ),
        'dur'     => __( '4 months', 'themeflex' ),
      ],
      [
        'init'    => 'DJ',
        'bg'      => 'linear-gradient(135deg,#06b6d4,#0891b2)',
        'results' => [ ['180 kg', __( 'Deadlift PR', 'themeflex' )], ['+28 kg', __( 'Muscle Mass', 'themeflex' )] ],
        'quote'   => __( 'The coaching here is at a level I\'ve never experienced at any other gym. Tony\'s boxing sessions alone are worth the membership.', 'themeflex' ),
        'name'    => __( 'David J.', 'themeflex' ),
        'meta'    => __( 'Champion member', 'themeflex' ),
        'dur'     => __( '1 year', 'themeflex' ),
      ],
    ];
    ?>
    <div class="gym-testi-grid">
      <?php foreach ( $testimonials as $t ) : ?>
        <div class="gym-testi-card">
          <div class="gym-testi-result">
            <?php foreach ( $t['results'] as $r ) : ?>
              <div class="gym-result-chip">
                <div class="chip-num"><?php echo esc_html( $r[0] ); ?></div>
                <div class="chip-label"><?php echo esc_html( $r[1] ); ?></div>
              </div>
            <?php endforeach; ?>
          </div>
          <blockquote class="gym-testi-quote">&ldquo;<?php echo esc_html( $t['quote'] ); ?>&rdquo;</blockquote>
          <div class="gym-testi-author">
            <div class="gym-testi-avatar" style="background:<?php echo esc_attr( $t['bg'] ); ?>;color:#fff;" aria-hidden="true">
              <?php echo esc_html( $t['init'] ); ?>
            </div>
            <div>
              <div class="gym-testi-name"><?php echo esc_html( $t['name'] ); ?></div>
              <div class="gym-testi-meta"><?php echo esc_html( $t['meta'] ); ?></div>
            </div>
            <div class="gym-testi-duration">
              <?php echo tf_icon_get( 'clock', 12 ); ?>
              <?php echo esc_html( $t['dur'] ); ?>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     7. CTA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="gym-section gym-cta-section">
  <div class="gym-container" style="position:relative;z-index:1;">
    <h2><?php esc_html_e( 'Ready to', 'themeflex' ); ?><br><em><?php esc_html_e( 'Start?', 'themeflex' ); ?></em></h2>
    <p><?php esc_html_e( 'Join 3,200+ members already training smarter. First 7 days completely free — no card required.', 'themeflex' ); ?></p>
    <div class="gym-cta-actions">
      <a href="#membership" class="gym-btn gym-btn-primary" style="font-size:1.05rem;padding:16px 36px;">
        <?php echo tf_icon_get( 'zap', 20 ); ?>
        <?php esc_html_e( 'Claim Free Week', 'themeflex' ); ?>
      </a>
      <a href="tel:+4930001234" class="gym-btn gym-btn-outline" style="font-size:1.05rem;padding:16px 36px;">
        <?php echo tf_icon_get( 'phone', 20 ); ?>
        <?php esc_html_e( 'Call Us', 'themeflex' ); ?>
      </a>
    </div>
    <div class="gym-cta-meta">
      <span><?php echo tf_icon_get( 'shield-check', 13 ); ?> <?php esc_html_e( 'No contract', 'themeflex' ); ?></span>
      <span><?php echo tf_icon_get( 'credit-card', 13 ); ?> <?php esc_html_e( 'No card needed', 'themeflex' ); ?></span>
      <span><?php echo tf_icon_get( 'x-circle', 13 ); ?> <?php esc_html_e( 'Cancel any time', 'themeflex' ); ?></span>
    </div>
  </div>
</section>

</div><!-- /.tf-gym-page -->

<script>
(function(){
  'use strict';
  var els = document.querySelectorAll('.tf-gym-page [data-counter]');
  if (!els.length || !window.IntersectionObserver) return;
  var io = new IntersectionObserver(function(entries){
    entries.forEach(function(e){
      if (!e.isIntersecting) return;
      io.unobserve(e.target);
      var el = e.target, t = parseInt(el.dataset.counter, 10), suf = el.dataset.suffix || '';
      var cur = 0, dur = 1600, step = 16, inc = t / (dur/step);
      var timer = setInterval(function(){
        cur += inc;
        if (cur >= t){ cur = t; clearInterval(timer); }
        el.textContent = (cur >= 1000 ? Math.round(cur).toLocaleString() : Math.round(cur)) + suf;
      }, step);
    });
  }, { threshold: 0.3 });
  els.forEach(function(e){ io.observe(e); });
})();
</script>

<?php get_footer(); ?>
