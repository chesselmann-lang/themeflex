<?php
/**
 * Template Name: Law Firm Homepage
 *
 * Premium Law Firm / Legal Services homepage for ThemeFlex.
 * Dark-first with gold/amber accents, CSS case-management
 * dashboard hero, practice areas, attorney profiles,
 * case results, client testimonials, and consultation form.
 *
 * @package ThemeFlex
 * @since   2.9.0
 */

get_header();
?>

<div class="tf-law-page">

<style>
/* ─── Tokens ──────────────────────────────────────────────────── */
.tf-law-page {
  --law-bg:       #09090b;
  --law-surface:  #111113;
  --law-card:     #18181b;
  --law-border:   rgba(255,255,255,.07);
  --law-accent:   #d4a853;   /* legal gold */
  --law-accent2:  #a37c38;   /* deep gold */
  --law-accent3:  #10b981;   /* win-green */
  --law-text:     #fafafa;
  --law-muted:    #71717a;
  --law-radius:   10px;
  background: var(--law-bg);
  color: var(--law-text);
  font-family: var(--tf-font-body, 'Inter', sans-serif);
}
.tf-law-page .law-container { max-width: 1200px; margin: 0 auto; padding: 0 24px; }
.tf-law-page .law-section   { padding: 96px 0; }
.tf-law-page .law-label {
  display: inline-flex; align-items: center; gap: 8px;
  font-size: .72rem; font-weight: 700; letter-spacing: .14em; text-transform: uppercase;
  color: var(--law-accent); margin-bottom: 14px;
}
.tf-law-page .law-label::before { content:''; width:20px; height:1px; background:var(--law-accent); }
.tf-law-page .law-heading {
  font-family: var(--tf-font-heading, 'Cormorant Garamond', 'Georgia', serif);
  font-size: clamp(2rem, 4vw, 3rem); font-weight: 700; line-height: 1.2; margin: 0 0 18px;
}
.tf-law-page .law-sub { font-size: 1rem; color: var(--law-muted); line-height: 1.8; max-width: 520px; }
.tf-law-page .law-btn {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 14px 28px; border-radius: 4px; font-size: .9rem; font-weight: 600;
  text-decoration: none; cursor: pointer; border: none; transition: all .2s;
}
.tf-law-page .law-btn-primary { background: var(--law-accent); color: #000; }
.tf-law-page .law-btn-primary:hover { background: #e0b96a; }
.tf-law-page .law-btn-outline {
  background: transparent; color: var(--law-text); border: 1.5px solid var(--law-border);
}
.tf-law-page .law-btn-outline:hover { border-color: var(--law-accent); color: var(--law-accent); }

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   1. HERO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-law-page .law-hero {
  min-height: 100vh; padding: 120px 0 80px;
  display: grid; grid-template-columns: 1fr 1fr; gap: 64px;
  align-items: center; position: relative; overflow: hidden;
}
.tf-law-page .law-hero::before {
  content: '';
  position: absolute; top: -100px; right: -200px;
  width: 700px; height: 700px;
  background: radial-gradient(circle, rgba(212,168,83,.06) 0%, transparent 70%);
  pointer-events: none;
}
.tf-law-page .law-hero-tagline {
  font-size: .8rem; font-weight: 600; letter-spacing: .16em; text-transform: uppercase;
  color: var(--law-accent); margin-bottom: 20px;
  display: flex; align-items: center; gap: 12px;
}
.tf-law-page .law-hero-tagline::before,
.tf-law-page .law-hero-tagline::after { content:''; flex:0 0 28px; height:1px; background:var(--law-accent); }
.tf-law-page .law-hero h1 {
  font-family: var(--tf-font-heading, 'Cormorant Garamond', 'Georgia', serif);
  font-size: clamp(3rem, 6vw, 5rem); font-weight: 700; line-height: 1.05; margin: 0 0 24px;
}
.tf-law-page .law-hero h1 em {
  font-style: italic; color: var(--law-accent);
}
.tf-law-page .law-hero-creds {
  display: flex; gap: 28px; margin-top: 36px; padding-top: 32px; border-top: 1px solid var(--law-border);
}
.tf-law-page .law-hero-cred strong { display: block; font-size: 1.2rem; font-weight: 700; color: var(--law-accent); }
.tf-law-page .law-hero-cred span   { font-size: .78rem; color: var(--law-muted); }
.tf-law-page .law-hero-actions { display: flex; gap: 12px; margin-top: 28px; flex-wrap: wrap; }

/* CSS Case Dashboard Mockup */
.tf-law-page .law-dashboard {
  background: var(--law-surface);
  border: 1.5px solid var(--law-border);
  border-radius: 16px; overflow: hidden;
  box-shadow: 0 40px 80px rgba(0,0,0,.5), 0 0 0 1px rgba(212,168,83,.08);
}
.tf-law-page .law-dash-topbar {
  background: rgba(212,168,83,.05);
  border-bottom: 1px solid var(--law-border);
  padding: 14px 20px;
  display: flex; align-items: center; justify-content: space-between;
}
.tf-law-page .law-dash-topbar .dots { display: flex; gap: 6px; }
.tf-law-page .law-dash-topbar .dots span { width: 9px; height: 9px; border-radius: 50%; }
.tf-law-page .law-dash-topbar .dots span:nth-child(1){ background:#ff5f57; }
.tf-law-page .law-dash-topbar .dots span:nth-child(2){ background:#febc2e; }
.tf-law-page .law-dash-topbar .dots span:nth-child(3){ background:#28c840; }
.tf-law-page .law-dash-topbar .dash-title { font-size: .78rem; color: var(--law-muted); font-weight: 500; }
.tf-law-page .law-dash-topbar .dash-badge {
  background: rgba(212,168,83,.12); border: 1px solid rgba(212,168,83,.25);
  border-radius: 4px; padding: 2px 8px; font-size: .65rem; font-weight: 700;
  color: var(--law-accent); letter-spacing: .08em; text-transform: uppercase;
}
.tf-law-page .law-dash-body { padding: 20px; display: flex; flex-direction: column; gap: 14px; }
/* KPI Row */
.tf-law-page .law-kpi-row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; }
.tf-law-page .law-kpi {
  background: var(--law-card); border: 1px solid var(--law-border);
  border-radius: 8px; padding: 12px 14px;
}
.tf-law-page .law-kpi .kpi-label { font-size: .62rem; color: var(--law-muted); text-transform: uppercase; letter-spacing: .08em; margin-bottom: 6px; }
.tf-law-page .law-kpi .kpi-val   { font-size: 1.3rem; font-weight: 700; color: var(--law-text); }
.tf-law-page .law-kpi .kpi-delta { font-size: .65rem; margin-top: 2px; font-weight: 600; }
.tf-law-page .law-kpi .kpi-delta.up   { color: var(--law-accent3); }
.tf-law-page .law-kpi .kpi-delta.same { color: var(--law-muted); }
/* Active cases list */
.tf-law-page .law-cases-list { background: var(--law-card); border: 1px solid var(--law-border); border-radius: 8px; overflow: hidden; }
.tf-law-page .law-cases-header {
  padding: 10px 14px; border-bottom: 1px solid var(--law-border);
  font-size: .7rem; font-weight: 700; color: var(--law-muted); text-transform: uppercase; letter-spacing: .08em;
  display: flex; justify-content: space-between;
}
.tf-law-page .law-case-row {
  display: flex; align-items: center; gap: 10px;
  padding: 10px 14px; border-bottom: 1px solid var(--law-border); font-size: .78rem;
}
.tf-law-page .law-case-row:last-child { border-bottom: none; }
.tf-law-page .law-case-row .case-id { color: var(--law-accent); font-weight: 700; font-size: .7rem; flex-shrink: 0; width: 60px; }
.tf-law-page .law-case-row .case-name { flex: 1; font-weight: 600; color: var(--law-text); }
.tf-law-page .law-case-row .case-type { color: var(--law-muted); font-size: .7rem; flex-shrink: 0; }
.tf-law-page .law-case-status {
  font-size: .62rem; font-weight: 700; padding: 2px 8px; border-radius: 4px; flex-shrink: 0;
}
.tf-law-page .law-case-status.active  { background: rgba(212,168,83,.12); color: var(--law-accent); }
.tf-law-page .law-case-status.hearing { background: rgba(239,68,68,.1);   color: #ef4444; }
.tf-law-page .law-case-status.review  { background: rgba(6,182,212,.1);   color: #06b6d4; }
/* Upcoming deadline */
.tf-law-page .law-deadline-card {
  background: linear-gradient(135deg, rgba(212,168,83,.1), rgba(212,168,83,.02));
  border: 1.5px solid rgba(212,168,83,.2);
  border-radius: 8px; padding: 12px 14px;
  display: flex; align-items: center; gap: 12px;
}
.tf-law-page .law-deadline-icon {
  width: 36px; height: 36px; flex-shrink: 0;
  background: rgba(212,168,83,.12); border-radius: 8px;
  display: flex; align-items: center; justify-content: center; color: var(--law-accent);
}
.tf-law-page .law-deadline-info strong { display: block; font-size: .85rem; color: var(--law-text); }
.tf-law-page .law-deadline-info span   { font-size: .72rem; color: var(--law-muted); }
.tf-law-page .law-deadline-countdown {
  margin-left: auto; text-align: center;
  font-size: 1.2rem; font-weight: 800; color: var(--law-accent);
}
.tf-law-page .law-deadline-countdown span { display: block; font-size: .6rem; color: var(--law-muted); font-weight: 400; }

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   2. TRUST BAR
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-law-page .law-trust-bar {
  background: var(--law-surface);
  border-top: 1px solid var(--law-border); border-bottom: 1px solid var(--law-border);
  padding: 40px 0;
}
.tf-law-page .law-trust-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 0; }
.tf-law-page .law-trust-item {
  text-align: center; padding: 0 28px;
  border-right: 1px solid var(--law-border);
}
.tf-law-page .law-trust-item:last-child { border-right: none; }
.tf-law-page .law-trust-num {
  font-family: var(--tf-font-heading, 'Cormorant Garamond', serif);
  font-size: 2.8rem; font-weight: 700; color: var(--law-accent); line-height: 1; margin-bottom: 6px;
}
.tf-law-page .law-trust-label { font-size: .8rem; color: var(--law-muted); line-height: 1.5; }

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   3. PRACTICE AREAS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-law-page .law-practice-head { margin-bottom: 52px; }
.tf-law-page .law-practice-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 2px; background: var(--law-border); border: 1px solid var(--law-border); border-radius: var(--law-radius); overflow: hidden; }
.tf-law-page .law-practice-card {
  background: var(--law-card); padding: 32px 28px; transition: all .22s; cursor: default;
  position: relative; overflow: hidden;
}
.tf-law-page .law-practice-card::before {
  content: ''; position: absolute; bottom: 0; left: 0; right: 0; height: 3px;
  background: var(--law-accent); transform: scaleX(0); transform-origin: left; transition: transform .25s;
}
.tf-law-page .law-practice-card:hover::before { transform: scaleX(1); }
.tf-law-page .law-practice-card:hover { background: rgba(212,168,83,.04); }
.tf-law-page .law-practice-icon {
  width: 48px; height: 48px; border-radius: 10px;
  background: rgba(212,168,83,.1); color: var(--law-accent);
  display: flex; align-items: center; justify-content: center;
  margin-bottom: 18px;
}
.tf-law-page .law-practice-card h4 { font-size: 1rem; font-weight: 700; margin: 0 0 10px; }
.tf-law-page .law-practice-card p  { font-size: .85rem; color: var(--law-muted); line-height: 1.7; margin: 0 0 16px; }
.tf-law-page .law-practice-card a  {
  font-size: .8rem; font-weight: 600; color: var(--law-accent); text-decoration: none;
  display: inline-flex; align-items: center; gap: 4px;
}

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   4. CASE RESULTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-law-page .law-results-section { background: var(--law-surface); }
.tf-law-page .law-results-layout { display: grid; grid-template-columns: 1fr 1fr; gap: 64px; align-items: center; }
.tf-law-page .law-result-cards { display: flex; flex-direction: column; gap: 14px; }
.tf-law-page .law-result-card {
  background: var(--law-card); border: 1.5px solid var(--law-border);
  border-radius: var(--law-radius); padding: 22px 24px;
  display: flex; align-items: center; gap: 20px;
  transition: border-color .2s;
}
.tf-law-page .law-result-card:hover { border-color: rgba(212,168,83,.3); }
.tf-law-page .law-result-amount {
  font-family: var(--tf-font-heading, 'Cormorant Garamond', serif);
  font-size: 1.8rem; font-weight: 700; color: var(--law-accent); flex-shrink: 0; min-width: 120px;
}
.tf-law-page .law-result-body .result-case { font-size: .85rem; font-weight: 700; color: var(--law-text); margin-bottom: 4px; }
.tf-law-page .law-result-body .result-type { font-size: .75rem; color: var(--law-muted); }
.tf-law-page .law-win-badge {
  margin-left: auto; background: rgba(16,185,129,.1); border: 1px solid rgba(16,185,129,.25);
  border-radius: 4px; padding: 4px 10px; font-size: .65rem; font-weight: 700; color: var(--law-accent3);
  flex-shrink: 0;
}
.tf-law-page .law-disclaimer { font-size: .72rem; color: var(--law-muted); margin-top: 16px; line-height: 1.6; font-style: italic; }

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   5. ATTORNEYS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-law-page .law-attorneys-head { text-align: center; margin-bottom: 52px; }
.tf-law-page .law-attorneys-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 20px; }
.tf-law-page .law-attorney-card {
  background: var(--law-card); border: 1.5px solid var(--law-border);
  border-radius: var(--law-radius); overflow: hidden; transition: all .22s;
}
.tf-law-page .law-attorney-card:hover { border-color: rgba(212,168,83,.3); transform: translateY(-3px); }
.tf-law-page .law-attorney-photo {
  height: 180px; display: flex; align-items: center; justify-content: center;
  font-size: 2.8rem; font-weight: 700;
  border-bottom: 1px solid var(--law-border); position: relative;
}
.tf-law-page .law-attorney-role {
  position: absolute; bottom: 10px; left: 0; right: 0; text-align: center;
  font-size: .62rem; font-weight: 700; text-transform: uppercase; letter-spacing: .1em;
  color: var(--law-accent);
}
.tf-law-page .law-attorney-info { padding: 18px 16px; }
.tf-law-page .law-attorney-info h4 { font-size: .95rem; font-weight: 700; margin: 0 0 4px; }
.tf-law-page .law-attorney-info .practice { font-size: .75rem; color: var(--law-accent); font-weight: 600; margin-bottom: 10px; }
.tf-law-page .law-attorney-info .bar-admitted { font-size: .72rem; color: var(--law-muted); margin-bottom: 12px; }
.tf-law-page .law-attorney-social { display: flex; gap: 8px; }
.tf-law-page .law-attorney-social a {
  width: 28px; height: 28px; border-radius: 4px;
  border: 1px solid var(--law-border); display: flex; align-items: center; justify-content: center;
  color: var(--law-muted); text-decoration: none; transition: all .2s;
}
.tf-law-page .law-attorney-social a:hover { border-color: var(--law-accent); color: var(--law-accent); }

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   6. TESTIMONIALS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-law-page .law-testi-section { background: var(--law-surface); }
.tf-law-page .law-testi-head { text-align: center; margin-bottom: 52px; }
.tf-law-page .law-testi-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; }
.tf-law-page .law-testi-card {
  background: var(--law-card); border: 1.5px solid var(--law-border);
  border-radius: var(--law-radius); padding: 28px; display: flex; flex-direction: column;
}
.tf-law-page .law-testi-outcome {
  display: inline-flex; align-items: center; gap: 6px;
  background: rgba(16,185,129,.08); border: 1px solid rgba(16,185,129,.2);
  border-radius: 4px; padding: 5px 12px; margin-bottom: 18px;
  font-size: .72rem; font-weight: 700; color: var(--law-accent3); width: fit-content;
}
.tf-law-page .law-testi-quote {
  font-family: var(--tf-font-heading, 'Georgia', serif);
  font-size: .95rem; font-style: italic; color: var(--law-muted); line-height: 1.8; flex: 1; margin-bottom: 20px;
}
.tf-law-page .law-testi-author {
  display: flex; align-items: center; gap: 12px;
  padding-top: 18px; border-top: 1px solid var(--law-border);
}
.tf-law-page .law-testi-avatar {
  width: 40px; height: 40px; border-radius: 50%;
  background: rgba(212,168,83,.15); border: 1px solid rgba(212,168,83,.25);
  display: flex; align-items: center; justify-content: center;
  font-size: .78rem; font-weight: 700; color: var(--law-accent); flex-shrink: 0;
}
.tf-law-page .law-testi-name { font-size: .88rem; font-weight: 700; color: var(--law-text); }
.tf-law-page .law-testi-case { font-size: .72rem; color: var(--law-muted); }

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   7. CONSULTATION CTA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-law-page .law-consult-layout { display: grid; grid-template-columns: 1fr 1fr; gap: 64px; align-items: start; }
.tf-law-page .law-consult-form-wrap {
  background: var(--law-card); border: 1.5px solid var(--law-border);
  border-radius: var(--law-radius); padding: 36px;
}
.tf-law-page .law-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px; }
.tf-law-page .law-form-row.full { grid-template-columns: 1fr; }
.tf-law-page .law-form-group { display: flex; flex-direction: column; gap: 6px; }
.tf-law-page .law-form-group label { font-size: .78rem; font-weight: 600; color: var(--law-muted); }
.tf-law-page .law-form-group input,
.tf-law-page .law-form-group select,
.tf-law-page .law-form-group textarea {
  background: var(--law-surface); border: 1.5px solid var(--law-border);
  border-radius: 4px; padding: 12px 14px; color: var(--law-text);
  font-size: .875rem; font-family: inherit; transition: border-color .2s;
}
.tf-law-page .law-form-group input:focus,
.tf-law-page .law-form-group select:focus,
.tf-law-page .law-form-group textarea:focus { outline: none; border-color: var(--law-accent); }
.tf-law-page .law-form-group textarea { resize: vertical; min-height: 110px; }
.tf-law-page .law-form-group select option { background: var(--law-surface); }
.tf-law-page .law-consult-info { display: flex; flex-direction: column; gap: 24px; }
.tf-law-page .law-consult-promise {
  background: var(--law-card); border: 1.5px solid var(--law-border);
  border-radius: var(--law-radius); padding: 28px;
}
.tf-law-page .law-consult-promise h4 { font-size: 1rem; font-weight: 700; margin: 0 0 16px; color: var(--law-text); }
.tf-law-page .law-promise-list { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 12px; }
.tf-law-page .law-promise-item {
  display: flex; align-items: flex-start; gap: 10px; font-size: .875rem;
}
.tf-law-page .law-promise-icon { color: var(--law-accent); flex-shrink: 0; margin-top: 2px; }
.tf-law-page .law-contact-cards { display: flex; flex-direction: column; gap: 12px; }
.tf-law-page .law-contact-card {
  background: var(--law-card); border: 1.5px solid var(--law-border);
  border-radius: var(--law-radius); padding: 18px 20px;
  display: flex; align-items: center; gap: 16px;
}
.tf-law-page .law-contact-icon {
  width: 42px; height: 42px; flex-shrink: 0;
  background: rgba(212,168,83,.08); border-radius: 8px;
  display: flex; align-items: center; justify-content: center; color: var(--law-accent);
}
.tf-law-page .law-contact-info h5 { font-size: .85rem; font-weight: 700; margin: 0 0 2px; }
.tf-law-page .law-contact-info p  { font-size: .8rem; color: var(--law-muted); margin: 0; }
.tf-law-page .law-contact-info a  { color: var(--law-accent); text-decoration: none; font-weight: 600; }

/* Responsive */
@media (max-width: 1024px) {
  .tf-law-page .law-attorneys-grid { grid-template-columns: repeat(2,1fr); }
  .tf-law-page .law-practice-grid  { grid-template-columns: repeat(2,1fr); }
}
@media (max-width: 768px) {
  .tf-law-page .law-hero         { grid-template-columns: 1fr; }
  .tf-law-page .law-dashboard    { display: none; }
  .tf-law-page .law-trust-grid   { grid-template-columns: repeat(2,1fr); gap: 24px; }
  .tf-law-page .law-trust-item   { border-right: none; border-bottom: 1px solid var(--law-border); padding-bottom: 24px; }
  .tf-law-page .law-trust-item:nth-child(3),
  .tf-law-page .law-trust-item:nth-child(4) { border-bottom: none; }
  .tf-law-page .law-results-layout  { grid-template-columns: 1fr; }
  .tf-law-page .law-attorneys-grid  { grid-template-columns: 1fr; }
  .tf-law-page .law-testi-grid      { grid-template-columns: 1fr; }
  .tf-law-page .law-consult-layout  { grid-template-columns: 1fr; }
  .tf-law-page .law-form-row        { grid-template-columns: 1fr; }
  .tf-law-page .law-practice-grid   { grid-template-columns: 1fr; }
}
</style>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     1. HERO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="law-section">
  <div class="law-container">
    <div class="law-hero">
      <div>
        <div class="law-hero-tagline"><?php esc_html_e( 'Est. 1998 · 26 Years of Excellence', 'themeflex' ); ?></div>
        <h1>
          <?php esc_html_e( 'When the Stakes Are', 'themeflex' ); ?><br>
          <em><?php esc_html_e( 'Highest,', 'themeflex' ); ?></em><br>
          <?php esc_html_e( 'We Deliver.', 'themeflex' ); ?>
        </h1>
        <p class="law-sub">
          <?php esc_html_e( 'A full-service litigation and advisory firm with a 94% client success rate across commercial, criminal, and family law. Your fight is our fight.', 'themeflex' ); ?>
        </p>
        <div class="law-hero-actions">
          <a href="#consultation" class="law-btn law-btn-primary" aria-label="<?php esc_attr_e( 'Request free consultation', 'themeflex' ); ?>">
            <?php echo tf_icon_get( 'scale', 18 ); ?>
            <?php esc_html_e( 'Free Consultation', 'themeflex' ); ?>
          </a>
          <a href="#results" class="law-btn law-btn-outline" aria-label="<?php esc_attr_e( 'View case results', 'themeflex' ); ?>">
            <?php echo tf_icon_get( 'trophy', 18 ); ?>
            <?php esc_html_e( 'Case Results', 'themeflex' ); ?>
          </a>
        </div>
        <div class="law-hero-creds" role="list">
          <?php
          $creds = [
            [ 'num' => '94%', 'label' => __( 'Case Win Rate', 'themeflex' ) ],
            [ 'num' => '€2B+', 'label' => __( 'Recovered for Clients', 'themeflex' ) ],
            [ 'num' => '26', 'label' => __( 'Years in Practice', 'themeflex' ) ],
          ];
          foreach ( $creds as $c ) :
          ?>
            <div class="law-hero-cred" role="listitem">
              <strong><?php echo esc_html( $c['num'] ); ?></strong>
              <span><?php echo esc_html( $c['label'] ); ?></span>
            </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- CSS Case Management Dashboard -->
      <div class="law-dashboard" aria-hidden="true" role="img" aria-label="<?php esc_attr_e( 'Case management dashboard illustration', 'themeflex' ); ?>">
        <div class="law-dash-topbar">
          <div class="dots"><span></span><span></span><span></span></div>
          <div class="dash-title"><?php esc_html_e( 'LexCore Case Management', 'themeflex' ); ?></div>
          <div class="dash-badge"><?php esc_html_e( 'Confidential', 'themeflex' ); ?></div>
        </div>
        <div class="law-dash-body">
          <!-- KPIs -->
          <div class="law-kpi-row">
            <div class="law-kpi">
              <div class="kpi-label"><?php esc_html_e( 'Active Cases', 'themeflex' ); ?></div>
              <div class="kpi-val">47</div>
              <div class="kpi-delta up"><?php echo tf_icon_get( 'trending-up', 11 ); ?> +3 this month</div>
            </div>
            <div class="law-kpi">
              <div class="kpi-label"><?php esc_html_e( 'Win Rate', 'themeflex' ); ?></div>
              <div class="kpi-val">94%</div>
              <div class="kpi-delta same"><?php esc_html_e( 'YTD 2026', 'themeflex' ); ?></div>
            </div>
            <div class="law-kpi">
              <div class="kpi-label"><?php esc_html_e( 'Hearings', 'themeflex' ); ?></div>
              <div class="kpi-val">8</div>
              <div class="kpi-delta up"><?php esc_html_e( 'This month', 'themeflex' ); ?></div>
            </div>
          </div>
          <!-- Cases list -->
          <div class="law-cases-list">
            <div class="law-cases-header">
              <span><?php esc_html_e( 'Case ID / Client', 'themeflex' ); ?></span>
              <span><?php esc_html_e( 'Status', 'themeflex' ); ?></span>
            </div>
            <?php
            $cases = [
              [ 'id' => '#2406-A', 'name' => __( 'Müller Group v. Schmidt', 'themeflex' ),   'type' => __( 'Commercial', 'themeflex' ), 'status' => 'active',  'status_label' => __( 'Active', 'themeflex' ) ],
              [ 'id' => '#2404-C', 'name' => __( 'Bauer — Criminal Appeal', 'themeflex' ),   'type' => __( 'Criminal', 'themeflex' ),   'status' => 'hearing', 'status_label' => __( 'Hearing', 'themeflex' ) ],
              [ 'id' => '#2403-F', 'name' => __( 'Weber Family Estate', 'themeflex' ),        'type' => __( 'Family', 'themeflex' ),     'status' => 'review',  'status_label' => __( 'Review', 'themeflex' ) ],
              [ 'id' => '#2402-M', 'name' => __( 'Schneider M&A Dispute', 'themeflex' ),     'type' => __( 'M&A', 'themeflex' ),        'status' => 'active',  'status_label' => __( 'Active', 'themeflex' ) ],
            ];
            foreach ( $cases as $c ) :
            ?>
              <div class="law-case-row">
                <span class="case-id"><?php echo esc_html( $c['id'] ); ?></span>
                <span class="case-name"><?php echo esc_html( $c['name'] ); ?></span>
                <span class="case-type"><?php echo esc_html( $c['type'] ); ?></span>
                <span class="law-case-status <?php echo esc_attr( $c['status'] ); ?>"><?php echo esc_html( $c['status_label'] ); ?></span>
              </div>
            <?php endforeach; ?>
          </div>
          <!-- Upcoming deadline -->
          <div class="law-deadline-card">
            <div class="law-deadline-icon" aria-hidden="true"><?php echo tf_icon_get( 'calendar-clock', 18 ); ?></div>
            <div class="law-deadline-info">
              <strong><?php esc_html_e( 'Filing Deadline — Müller Group', 'themeflex' ); ?></strong>
              <span><?php esc_html_e( 'LG Frankfurt / Case #2406-A', 'themeflex' ); ?></span>
            </div>
            <div class="law-deadline-countdown">3<span><?php esc_html_e( 'days', 'themeflex' ); ?></span></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     2. TRUST BAR
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="law-trust-bar" aria-label="<?php esc_attr_e( 'Key statistics', 'themeflex' ); ?>">
  <div class="law-container">
    <div class="law-trust-grid" role="list">
      <?php
      $stats = [
        [ 'num' => '€2B+', 'label' => __( 'Recovered for Clients', 'themeflex' ) ],
        [ 'num' => '4,800+', 'label' => __( 'Cases Handled', 'themeflex' ) ],
        [ 'num' => '26', 'label' => __( 'Years in Practice', 'themeflex' ) ],
        [ 'num' => '94%', 'label' => __( 'Success Rate', 'themeflex' ) ],
      ];
      foreach ( $stats as $s ) :
      ?>
        <div class="law-trust-item" role="listitem">
          <div class="law-trust-num"><?php echo esc_html( $s['num'] ); ?></div>
          <div class="law-trust-label"><?php echo esc_html( $s['label'] ); ?></div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     3. PRACTICE AREAS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="law-section">
  <div class="law-container">
    <div class="law-practice-head">
      <div class="law-label"><?php esc_html_e( 'Practice Areas', 'themeflex' ); ?></div>
      <h2 class="law-heading"><?php esc_html_e( 'Full-Spectrum Legal Representation', 'themeflex' ); ?></h2>
      <p class="law-sub"><?php esc_html_e( 'From boardroom disputes to personal injury claims, our specialists handle every area of law with the same relentless commitment.', 'themeflex' ); ?></p>
    </div>
    <?php
    $practices = [
      [ 'icon' => 'briefcase',     'name' => __( 'Commercial Litigation', 'themeflex' ), 'desc' => __( 'Contract disputes, shareholder conflicts, insolvency, and high-stakes commercial claims handled by our litigation team.', 'themeflex' ) ],
      [ 'icon' => 'shield',        'name' => __( 'Criminal Defence', 'themeflex' ),      'desc' => __( 'Aggressive, experienced defence in fraud, white-collar crime, cybercrime, and all criminal proceedings at every court level.', 'themeflex' ) ],
      [ 'icon' => 'home',          'name' => __( 'Family Law', 'themeflex' ),            'desc' => __( 'Divorce, child custody, maintenance, estate disputes, and domestic matters handled with discretion and care.', 'themeflex' ) ],
      [ 'icon' => 'building-2',    'name' => __( 'Corporate & M&A', 'themeflex' ),       'desc' => __( 'Due diligence, transaction structuring, regulatory compliance, and post-merger integration for businesses of all sizes.', 'themeflex' ) ],
      [ 'icon' => 'activity',      'name' => __( 'Personal Injury', 'themeflex' ),       'desc' => __( 'Negligence, medical malpractice, road accidents, and workplace injuries — no recovery, no fee.', 'themeflex' ) ],
      [ 'icon' => 'globe',         'name' => __( 'International Arbitration', 'themeflex' ), 'desc' => __( 'ICC, DIS, and ad hoc arbitrations. Cross-border disputes resolved efficiently with our multilingual team.', 'themeflex' ) ],
    ];
    ?>
    <div class="law-practice-grid" role="list">
      <?php foreach ( $practices as $p ) : ?>
        <div class="law-practice-card" role="listitem">
          <div class="law-practice-icon" aria-hidden="true"><?php echo tf_icon_get( esc_attr( $p['icon'] ), 22 ); ?></div>
          <h4><?php echo esc_html( $p['name'] ); ?></h4>
          <p><?php echo esc_html( $p['desc'] ); ?></p>
          <a href="#consultation" aria-label="<?php printf( esc_attr__( 'Enquire about %s', 'themeflex' ), esc_attr( $p['name'] ) ); ?>">
            <?php esc_html_e( 'Discuss Your Case', 'themeflex' ); ?>
            <?php echo tf_icon_get( 'arrow-right', 13 ); ?>
          </a>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     4. CASE RESULTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="law-section law-results-section" id="results">
  <div class="law-container">
    <div class="law-results-layout">
      <div>
        <div class="law-label"><?php esc_html_e( 'Track Record', 'themeflex' ); ?></div>
        <h2 class="law-heading"><?php esc_html_e( 'Results That Speak for Themselves', 'themeflex' ); ?></h2>
        <p class="law-sub"><?php esc_html_e( 'A selection of recent outcomes across our core practice areas. Past results do not guarantee future outcomes.', 'themeflex' ); ?></p>
      </div>
      <div>
        <?php
        $results = [
          [ 'amount' => '€14.2M', 'case' => __( 'Müller GmbH v. Technika AG — breach of exclusivity', 'themeflex' ), 'type' => __( 'Commercial Litigation · Frankfurt LG', 'themeflex' ) ],
          [ 'amount' => 'Acquittal', 'case' => __( 'State v. Dr. K. Bauer — financial fraud charges dismissed', 'themeflex' ), 'type' => __( 'Criminal Defence · OLG Munich', 'themeflex' ) ],
          [ 'amount' => '€6.8M', 'case' => __( 'Weber v. Insurance Conglomerate — bad-faith claim payout', 'themeflex' ), 'type' => __( 'Personal Injury · Hamburg LG', 'themeflex' ) ],
          [ 'amount' => 'ICC Award', 'case' => __( 'Ritter Holdings — €22M arbitration award upheld', 'themeflex' ), 'type' => __( 'International Arbitration · Paris', 'themeflex' ) ],
          [ 'amount' => 'Full Custody', 'case' => __( 'Family matter — sole parental authority granted', 'themeflex' ), 'type' => __( 'Family Law · Berlin AG', 'themeflex' ) ],
        ];
        ?>
        <div class="law-result-cards" role="list">
          <?php foreach ( $results as $r ) : ?>
            <div class="law-result-card" role="listitem">
              <div class="law-result-amount"><?php echo esc_html( $r['amount'] ); ?></div>
              <div class="law-result-body">
                <div class="result-case"><?php echo esc_html( $r['case'] ); ?></div>
                <div class="result-type"><?php echo esc_html( $r['type'] ); ?></div>
              </div>
              <div class="law-win-badge"><?php echo tf_icon_get( 'check', 10 ); ?> <?php esc_html_e( 'Won', 'themeflex' ); ?></div>
            </div>
          <?php endforeach; ?>
        </div>
        <p class="law-disclaimer"><?php esc_html_e( '* Case names are anonymised or pseudonymised to protect client confidentiality. Outcomes are actual results obtained for our clients.', 'themeflex' ); ?></p>
      </div>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     5. ATTORNEYS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="law-section">
  <div class="law-container">
    <div class="law-attorneys-head">
      <div class="law-label"><?php esc_html_e( 'Our Attorneys', 'themeflex' ); ?></div>
      <h2 class="law-heading"><?php esc_html_e( 'Exceptional Counsel, Every Case', 'themeflex' ); ?></h2>
      <p class="law-sub" style="margin:0 auto;"><?php esc_html_e( 'Educated at Europe\'s leading law schools, admitted to the bars of four jurisdictions, and relentlessly focused on your outcome.', 'themeflex' ); ?></p>
    </div>
    <?php
    $attorneys = [
      [
        'init'    => 'TK',
        'bg'      => 'linear-gradient(135deg,rgba(212,168,83,.2),rgba(212,168,83,.04))',
        'color'   => '#d4a853',
        'name'    => __( 'Dr. Thomas König', 'themeflex' ),
        'practice'=> __( 'Commercial Litigation', 'themeflex' ),
        'role'    => __( 'Managing Partner', 'themeflex' ),
        'bar'     => __( 'Admitted: DE · AT · EU', 'themeflex' ),
      ],
      [
        'init'    => 'SM',
        'bg'      => 'linear-gradient(135deg,rgba(168,85,247,.15),rgba(168,85,247,.03))',
        'color'   => '#a855f7',
        'name'    => __( 'Sophie Maier', 'themeflex' ),
        'practice'=> __( 'Criminal Defence', 'themeflex' ),
        'role'    => __( 'Senior Partner', 'themeflex' ),
        'bar'     => __( 'Admitted: DE · CH', 'themeflex' ),
      ],
      [
        'init'    => 'RB',
        'bg'      => 'linear-gradient(135deg,rgba(6,182,212,.15),rgba(6,182,212,.03))',
        'color'   => '#06b6d4',
        'name'    => __( 'Raphael Braun', 'themeflex' ),
        'practice'=> __( 'International Arbitration', 'themeflex' ),
        'role'    => __( 'Partner', 'themeflex' ),
        'bar'     => __( 'Admitted: DE · FR · ICC', 'themeflex' ),
      ],
      [
        'init'    => 'AL',
        'bg'      => 'linear-gradient(135deg,rgba(16,185,129,.15),rgba(16,185,129,.03))',
        'color'   => '#10b981',
        'name'    => __( 'Anna Lehmann', 'themeflex' ),
        'practice'=> __( 'Family & Estate Law', 'themeflex' ),
        'role'    => __( 'Partner', 'themeflex' ),
        'bar'     => __( 'Admitted: DE · EU', 'themeflex' ),
      ],
    ];
    ?>
    <div class="law-attorneys-grid">
      <?php foreach ( $attorneys as $att ) : ?>
        <article class="law-attorney-card">
          <div class="law-attorney-photo" style="background:<?php echo esc_attr( $att['bg'] ); ?>;color:<?php echo esc_attr( $att['color'] ); ?>;" aria-hidden="true">
            <?php echo esc_html( $att['init'] ); ?>
            <div class="law-attorney-role"><?php echo esc_html( $att['role'] ); ?></div>
          </div>
          <div class="law-attorney-info">
            <h4><?php echo esc_html( $att['name'] ); ?></h4>
            <div class="practice"><?php echo esc_html( $att['practice'] ); ?></div>
            <div class="bar-admitted"><?php echo esc_html( $att['bar'] ); ?></div>
            <div class="law-attorney-social">
              <a href="#" aria-label="<?php printf( esc_attr__( '%s on LinkedIn', 'themeflex' ), esc_attr( $att['name'] ) ); ?>">
                <?php echo tf_icon_get( 'linkedin', 13 ); ?>
              </a>
              <a href="#" aria-label="<?php printf( esc_attr__( 'Email %s', 'themeflex' ), esc_attr( $att['name'] ) ); ?>">
                <?php echo tf_icon_get( 'mail', 13 ); ?>
              </a>
              <a href="#consultation" aria-label="<?php printf( esc_attr__( 'Book consultation with %s', 'themeflex' ), esc_attr( $att['name'] ) ); ?>">
                <?php echo tf_icon_get( 'calendar', 13 ); ?>
              </a>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     6. TESTIMONIALS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="law-section law-testi-section">
  <div class="law-container">
    <div class="law-testi-head">
      <div class="law-label"><?php esc_html_e( 'Client Voices', 'themeflex' ); ?></div>
      <h2 class="law-heading"><?php esc_html_e( 'Trusted by Clients Across Europe', 'themeflex' ); ?></h2>
    </div>
    <?php
    $testimonials = [
      [
        'outcome' => __( 'Commercial Win — €14.2M', 'themeflex' ),
        'quote'   => __( 'Dr. König and his team understood our case at a level no other firm had managed. Their strategic approach to the Frankfurt proceedings was exceptional — and the result proved it.', 'themeflex' ),
        'init'    => 'HM',
        'name'    => __( 'H. Müller', 'themeflex' ),
        'case'    => __( 'CEO, Müller Group', 'themeflex' ),
      ],
      [
        'outcome' => __( 'Criminal Acquittal', 'themeflex' ),
        'quote'   => __( 'Faced with charges that threatened my career and freedom, Sophie Maier\'s relentless defence and brilliant cross-examination secured the outcome I had stopped hoping for. I am forever grateful.', 'themeflex' ),
        'init'    => 'KB',
        'name'    => __( 'K. Bauer', 'themeflex' ),
        'case'    => __( 'Medical Professional', 'themeflex' ),
      ],
      [
        'outcome' => __( 'Full Custody Granted', 'themeflex' ),
        'quote'   => __( 'Going through a custody battle was the hardest thing I have ever faced. Anna Lehmann guided us through every step with compassion and fierce advocacy. My children are safe.', 'themeflex' ),
        'init'    => 'EW',
        'name'    => __( 'E. Weber', 'themeflex' ),
        'case'    => __( 'Family Law Client', 'themeflex' ),
      ],
    ];
    ?>
    <div class="law-testi-grid">
      <?php foreach ( $testimonials as $t ) : ?>
        <div class="law-testi-card">
          <div class="law-testi-outcome">
            <?php echo tf_icon_get( 'check-circle', 13 ); ?>
            <?php echo esc_html( $t['outcome'] ); ?>
          </div>
          <blockquote class="law-testi-quote">&ldquo;<?php echo esc_html( $t['quote'] ); ?>&rdquo;</blockquote>
          <div class="law-testi-author">
            <div class="law-testi-avatar" aria-hidden="true"><?php echo esc_html( $t['init'] ); ?></div>
            <div>
              <div class="law-testi-name"><?php echo esc_html( $t['name'] ); ?></div>
              <div class="law-testi-case"><?php echo esc_html( $t['case'] ); ?></div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     7. CONSULTATION FORM
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="law-section" id="consultation">
  <div class="law-container">
    <div class="law-label" style="margin-bottom:14px;"><?php esc_html_e( 'Free Consultation', 'themeflex' ); ?></div>
    <h2 class="law-heading" style="margin-bottom:48px;"><?php esc_html_e( 'Discuss Your Case', 'themeflex' ); ?></h2>

    <div class="law-consult-layout">
      <!-- Form -->
      <div class="law-consult-form-wrap">
        <h3 style="font-size:1.1rem;margin:0 0 22px;color:var(--law-text);"><?php esc_html_e( 'Request a Confidential Consultation', 'themeflex' ); ?></h3>
        <form action="#" method="post" aria-label="<?php esc_attr_e( 'Consultation request form', 'themeflex' ); ?>">
          <?php wp_nonce_field( 'law_consultation', 'law_consult_nonce' ); ?>
          <div class="law-form-row">
            <div class="law-form-group">
              <label for="law-name"><?php esc_html_e( 'Full Name', 'themeflex' ); ?></label>
              <input type="text" id="law-name" name="name" required
                     placeholder="<?php esc_attr_e( 'Dr. Anna Schmidt', 'themeflex' ); ?>"
                     autocomplete="name">
            </div>
            <div class="law-form-group">
              <label for="law-email"><?php esc_html_e( 'Email Address', 'themeflex' ); ?></label>
              <input type="email" id="law-email" name="email" required
                     placeholder="<?php esc_attr_e( 'anna@company.de', 'themeflex' ); ?>"
                     autocomplete="email">
            </div>
          </div>
          <div class="law-form-row">
            <div class="law-form-group">
              <label for="law-phone"><?php esc_html_e( 'Phone Number', 'themeflex' ); ?></label>
              <input type="tel" id="law-phone" name="phone"
                     placeholder="<?php esc_attr_e( '+49 30 ...', 'themeflex' ); ?>"
                     autocomplete="tel">
            </div>
            <div class="law-form-group">
              <label for="law-area"><?php esc_html_e( 'Practice Area', 'themeflex' ); ?></label>
              <select id="law-area" name="practice_area">
                <option value=""><?php esc_html_e( 'Select Area', 'themeflex' ); ?></option>
                <option value="commercial"><?php esc_html_e( 'Commercial Litigation', 'themeflex' ); ?></option>
                <option value="criminal"><?php esc_html_e( 'Criminal Defence', 'themeflex' ); ?></option>
                <option value="family"><?php esc_html_e( 'Family Law', 'themeflex' ); ?></option>
                <option value="corporate"><?php esc_html_e( 'Corporate & M&A', 'themeflex' ); ?></option>
                <option value="injury"><?php esc_html_e( 'Personal Injury', 'themeflex' ); ?></option>
                <option value="arbitration"><?php esc_html_e( 'International Arbitration', 'themeflex' ); ?></option>
              </select>
            </div>
          </div>
          <div class="law-form-row full">
            <div class="law-form-group">
              <label for="law-matter"><?php esc_html_e( 'Brief Description of Your Matter', 'themeflex' ); ?></label>
              <textarea id="law-matter" name="matter"
                        placeholder="<?php esc_attr_e( 'Please describe your situation briefly. All information is treated as strictly confidential under attorney-client privilege.', 'themeflex' ); ?>"></textarea>
            </div>
          </div>
          <button type="submit" class="law-btn law-btn-primary" style="width:100%;justify-content:center;margin-top:8px;"
                  aria-label="<?php esc_attr_e( 'Submit consultation request', 'themeflex' ); ?>">
            <?php echo tf_icon_get( 'send', 18 ); ?>
            <?php esc_html_e( 'Send Confidential Enquiry', 'themeflex' ); ?>
          </button>
          <p style="font-size:.72rem;color:var(--law-muted);text-align:center;margin:12px 0 0;">
            <?php esc_html_e( 'Protected by attorney-client privilege. We respond within 4 business hours.', 'themeflex' ); ?>
          </p>
        </form>
      </div>

      <!-- Info -->
      <div class="law-consult-info">
        <div class="law-consult-promise">
          <h4><?php esc_html_e( 'Our Commitment to You', 'themeflex' ); ?></h4>
          <ul class="law-promise-list">
            <?php
            $promises = [
              __( 'Free initial consultation — no obligation', 'themeflex' ),
              __( 'Strict confidentiality under attorney-client privilege', 'themeflex' ),
              __( 'Response within 4 business hours', 'themeflex' ),
              __( 'No-win no-fee available for personal injury cases', 'themeflex' ),
              __( 'Fixed-fee options for commercial matters', 'themeflex' ),
              __( 'Representation in English, German, French, and Spanish', 'themeflex' ),
            ];
            foreach ( $promises as $p ) :
            ?>
              <li class="law-promise-item">
                <span class="law-promise-icon" aria-hidden="true"><?php echo tf_icon_get( 'check', 16 ); ?></span>
                <?php echo esc_html( $p ); ?>
              </li>
            <?php endforeach; ?>
          </ul>
        </div>

        <div class="law-contact-cards">
          <div class="law-contact-card">
            <div class="law-contact-icon" aria-hidden="true"><?php echo tf_icon_get( 'phone', 20 ); ?></div>
            <div class="law-contact-info">
              <h5><?php esc_html_e( 'Telephone', 'themeflex' ); ?></h5>
              <p><a href="tel:+4930987654321">+49 30 98765 4321</a></p>
            </div>
          </div>
          <div class="law-contact-card">
            <div class="law-contact-icon" aria-hidden="true"><?php echo tf_icon_get( 'mail', 20 ); ?></div>
            <div class="law-contact-info">
              <h5><?php esc_html_e( 'Secure Email', 'themeflex' ); ?></h5>
              <p><a href="mailto:consult@lexcore-law.de">consult@lexcore-law.de</a></p>
            </div>
          </div>
          <div class="law-contact-card">
            <div class="law-contact-icon" aria-hidden="true"><?php echo tf_icon_get( 'map-pin', 20 ); ?></div>
            <div class="law-contact-info">
              <h5><?php esc_html_e( 'Office', 'themeflex' ); ?></h5>
              <p><?php esc_html_e( 'Kurfürstendamm 58, 10707 Berlin', 'themeflex' ); ?></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

</div><!-- /.tf-law-page -->

<?php get_footer(); ?>
