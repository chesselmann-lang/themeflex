=== ThemeFlex ===
Contributors: whatsdigital
Tags: blog, e-commerce, portfolio, grid-layout, one-column, two-columns, left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-logo, custom-menu, editor-style, featured-images, footer-widgets, full-width-template, post-formats, theme-options, threaded-comments, translation-ready, block-styles, wide-blocks, rtl-language-support, accessibility-ready, elementor
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 8.0
Stable tag: 3.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

ThemeFlex — Premium dark-first WordPress theme for Elementor. 80+ widgets, 8 skins, 24+ demos, WooCommerce support, 97 PageSpeed.

== Description ==

ThemeFlex is a premium dark-first WordPress theme built for Elementor. It ships with 80+ custom widgets, 8 built-in colour skins, 12+ one-click demo sites, WooCommerce support, portfolio CPT, reading progress bar, and WCAG 2.1 AA accessibility.

Key Features:
* 80+ custom Elementor widgets
* 8 built-in colour skins (Orange, Blue, Green, Violet, Crimson, Teal, Gold, Cyan)
* 24+ one-click demo sites via Demo Importer
* Dark-first design with FOUC prevention
* Portfolio CPT with archive, single, and category filter
* WooCommerce template overrides
* Reading progress bar on single posts
* Social share buttons on single posts
* 4-column dark footer with newsletter form
* WCAG 2.1 AA accessibility
* RTL language support
* Translation-ready (text domain: themeflex)
* Child theme compatible
* 97 PageSpeed score out of the box

== Installation ==

1. In your admin panel, go to Appearance > Themes and click Add New.
2. Click Upload Theme, then select the theme .zip file. Click Install Now.
3. Click Activate to use the theme.
4. Install the recommended plugins (Elementor) when prompted.
5. Go to Appearance > Demo Import to install a demo with one click.

== Changelog ==

= 3.1.0 - 2026-04-30 =
* NEW: page-travel.php — premium Travel & Tourism Homepage: split hero with CSS globe art (meridian/parallel grid lines, continent shapes, animated orbit ring with dot, radial glow), IATA-code destination cards with local-time clocks, 6-experience cards (Adventure/Cultural/Luxury/Beach/Wildlife/Culinary) with CSS landscape art, group-tour package grid with durations and inclusions, 4-guide profile cards, 5-item testimonials with trip-badge chips, interactive trip-builder inquiry form with journey-type selects + GDPR note, full-bleed CTA with gradient background
* NEW: page-wedding.php — premium Wedding & Events Homepage: CSS floral arch hero (PHP-generated petal positions/durations, floating rings with sway animation, altar + candles + couple silhouette SVG art, scroll mouse hint), 6 wedding-service cards (Planning/Catering/Flowers/Photo/Music/Venue) with Lucide icons, 3-panel polaroid about section (couple silhouette / rings / flowers CSS art), 7-item masonry gallery grid with hover overlays, 3-tier pricing (Elegance €3,500 / Bespoke €8,900 featured / Opulence custom), 3 venue cards (castle/ocean/garden CSS art), testimonials, 4 planner team cards, FAQ accordion, split inquiry form with wp_nonce_field
* NEW: page-startup.php — premium Tech Startup Homepage: animated CSS grid background with drift animation, 3 orbit rings (electric/cyan/green) with dots, terminal mockup (macOS traffic lights + PHP-rendered shell output + blinking cursor), floating badge cards, 7 trusted-by logos, 6 feature cards (3 color variants), interactive product dashboard (metric cards + PHP-generated bar chart + activity feed), 4 animated stat counters, 4-step how-it-works with connector line, 3 testimonials, 3-tier pricing (Hobby $0 / Growth $49 featured / Scale custom), 12-integration tile grid, FAQ accordion, bordered CTA with gradient pseudo-border
* NEW: page-hotel.php — premium Hotel & Hospitality Homepage: CSS hotel building facade (PHP loops: 5 floors × 9 columns window grid with 70% deterministic lit flicker pattern, wing windows, entrance arch, 5-column colonnade, flag, balconies), 60 PHP-generated CSS stars with animated moon + palm trees + lamp posts, fixed bottom booking strip (check-in/check-out/guests/room-type + wp_nonce_field), 5-accolade awards bar, about section with chandelier radial gradient + columns CSS art + 100-year badge, asymmetric room grid (Penthouse 2-row spanning / Ocean Suite / Garden Villa), dining section with animated candlelight, spa with clip-path animated pool water, 3 experience cards, 3 luxury testimonials (Georgia serif), CSS art map with animated ping + compass rose, offer CTA strip
* IMPROVED: Naming consistency audit — ThemeFlex_Nav_Menu_Walker canonical class with Starter_Flavor_Nav_Menu_Walker class_alias() for backward compatibility; themeflex_data JS object with window.starterFlavorData shim; all header.php/template-parts references updated to canonical names

= 3.0.0 - 2026-04-30 =
* NEW: page-education.php — premium Education & University Homepage: split hero with CSS campus building (animated dome with pulsing glow, 7 portico columns, 8-floor window grid with individual flicker animations, side wings, entrance steps, floating acceptance-rate card with 4 colour-coded metrics), indigo stats bar (38K students, 240+ programmes, 4,800+ faculty, 98% graduate employment), 6 program cards (CS&AI/indigo, Life Sciences/emerald, Business/gold, Law/pink, Engineering/blue, Arts/orange) with level badges and meta rows, events strip with giant day numerals, 4 faculty cards with fellowship/laureate badges, research section with animated bar chart viz panel + 4 stats + research-area list, 3 alumni testimonials with outcome badges (€40M Startup, Charité Residency, €120M VC Portfolio), enrollment form with degree/area selects + GDPR note, indigo radial CTA with gold Apply button
* NEW: page-finance.php — premium Finance & Wealth Management Homepage: hero with CSS trading dashboard (macOS-style topbar + LIVE pulsing dot, 3-KPI strip with Portfolio Value/Day Gain/Sharpe Ratio, SVG line chart with portfolio path + area gradient + dashed benchmark + grid lines, 4-holdings list with ticker/price/change colour-coding), scrolling ticker tape (10 instruments × 2, seamless 35s loop, pause-on-hover: SPX/DAX/EURUSD/GOLD/BTC/AAPL/MSFT/NVDA/TSLA/NOVO.B), stats bar (€4.2B AUM, 37 years, 1,200 families, 12.4% avg return), 6 service cards (Wealth Management/Private Banking/Estate & Tax/Alternatives/Family Office/Pension) with feature lists, performance panel with grouped animated bar chart (6 years × portfolio+benchmark bars) + 3-return summary cards, 4 investment philosophy pillars, 4 advisor cards with AUM badges, 3 client testimonials with result badges (€2.4M tax saved, 24% IRR, +108% real return), consultation form with 6-asset-range radio picker + service select + GDPR, dark-green radial CTA
* NEW: page-photography.php — premium Photography Studio Homepage: full-width hero with CSS aperture rings (5 concentric rings rotating at different speeds/directions, tick marks via ::before, 8 aperture blade divs with alternating opacity, lens glow pulse), film-strip decoration column left edge, Cormorant Garamond italic copper H1 ("Light, Moment, Story."), 3-stat credits row, 7-item masonry portfolio grid (tall/wide/large span variants) with unique CSS photo placeholders (portrait oval, arch building, wedding figures, nature horizon, product box, event stage lights) + hover overlay with category+title, 5 decorative category filter tabs, 4 service cards with pricing (Wedding €2,900+, Portrait €490+, Architecture €890+, Commercial €1,400/day) + bottom-border reveal hover, 5-step process timeline with vertical connector line + CSS camera mockup art (body/lens/dial/screen/shutter), 3 Cormorant italic testimonials, booking form with session type/date/location/message

= 2.9.0 - 2026-04-30 =
* NEW: page-gym-fitness.php — premium Gym & Fitness Homepage: hero with CSS fitness tracker (SVG animated progress rings for Calories/Sets/Volume, weekly bar chart, floating PR chip with red glow), inverted-orange stats bar, 3-tier membership pricing (Starter €29 / Elite €59 featured / Champion €99) with annual/monthly toggle, 6-class schedule grid with live spots counters and full/waitlist states, 4-trainer profiles (NSCA-CSCS strength, RYT-500 yoga, ACE-CPT cardio, USA Boxing), 3 transformation testimonials with result chips (-18 kg / +42% Strength), CTA strip
* NEW: page-law-firm.php — premium Law Firm Homepage: hero with CSS case management dashboard (macOS topbar, KPI row with 47 cases/94% win rate/8 hearings, 4-case list with active/hearing/review status badges, deadline countdown card), gold trust bar, 3×2 practice area grid with bottom-border reveal hover (Commercial Litigation, Criminal Defence, Family Law, Corporate M&A, Personal Injury, International Arbitration), 5 case results strip (€14.2M / Acquittal / €6.8M / ICC Award / Full Custody), 4 attorney profiles with Cormorant Garamond serif, 3 testimonials with outcome badges, consultation form with practice area select + attorney-client privilege disclaimer, 6-promise list (free consult, confidentiality, 4hr response, no-win-no-fee, fixed fee, multilingual)
* NEW: page-architecture.php — premium Architecture & Design Studio Homepage: split hero with CSS blueprint wireframe (building silhouette with animated lit windows, dimension lines, annotation callouts, compass rose, scale bar, project identifier badge), recognition marquee strip, 5-project CSS portfolio grid (large featured + tall vertical + 3 standard, each with unique CSS art), 4-service cards (Architecture, Interior Design, Landscape, Urban Planning), floor-plan CSS art about section with founding philosophy quote + 4 values, 5-award strip (AIA/Dezeen/RIBA/Architizer/WAF), 4-principal team cards with serif typography, 5-step process section, animated stat counters, commission enquiry form with 6-budget radio picker + NDA/fixed-fee promise cards

= 2.8.0 - 2026-04-28 =
* NEW: page-corporate.php — premium Corporate Homepage: split hero with CSS Dashboard mockup (topbar, KPI cards, bar chart, activity feed), animated stats bar (30+ yrs, 500+ clients, 45 countries, 98% satisfaction), 6-card services bento (per-card accent colors + hover animation), milestone timeline + CSS Office card with map ping + 4 office location chips, 3 case-study cards, client logo marquee (10 corps, 28s seamless loop), 4-card leadership team with CSS initials avatars, 3 testimonials, CTA banner
* NEW: page-medical.php — premium Medical / Healthcare Homepage: split hero with CSS health monitor (ECG pulse line SVG animation, vitals cards, patient schedule list, floating appointment card), appointment banner strip, 8-specialty card grid, animated stats bar (50K patients, 120 physicians, 25 years, 98%), about section with CSS recovery-rate bar chart + health metrics panel, 4-doctor team cards, 6-certification chips strip, 3 patient testimonials with verified badges, full appointment request form + 4 contact info cards
* NEW: page-blog-magazine.php — premium Editorial Magazine Homepage: breaking-news ticker (animated marquee, pause-on-hover), hero featured story with CSS editorial art + floating stat chips + top-stories sidebar list, category navigation ribbon with article counts, 5-article editorial grid (large featured card + 4 supporting), trending sidebar widget, popular topics tag cloud, inline newsletter signup widget, 3-column editor's pick row, 4-author spotlight cards with follow CTA, full-width newsletter CTA section

= 2.7.0 - 2026-04-26 =
* NEW: page-real-estate.php — premium Real Estate homepage: property search hero with CSS search bar mockup + floating stat cards, property type tabs + 4-type category cards, 6-listing grid (CSS gradient placeholders, bed/bath/sqft meta), animated stats bar, Why-Choose-Us 3-column cards, Agent Spotlight 3-profile cards, testimonials, CTA banner
* NEW: page-mobile-app.php — premium Mobile App landing page: CSS phone mockup hero (status bar, metric cards, bar chart), social proof bar, asymmetric bento feature grid, 3-step how-it-works with connector line, two alternating feature panels (dashboard + activity feed CSS art), 3-tier pricing with annual/monthly toggle (ARIA role=switch), testimonials, final CTA with overlapping avatar stack

= 2.6.0 - 2026-04-26 =
* NEW: page-ecommerce.php — premium E-Commerce homepage: hero with CSS product mockup + floating stat cards, stats bar with animated counters, 4-category grid, 6-product showcase with badge/rating/cart system, flash sale promo banner with live countdown timer, benefits bar (4 icons), 3 testimonials, newsletter CTA
* NEW: page-restaurant.php — premium Restaurant homepage: warm dark hero with CSS plate art, opening-hours info strip, 3 featured dish cards, story/about split section with CSS ingredient sourcing card + Michelin badge, 4-item menu preview with tabs, 3 guest reviews, reservation form with date/time/guest selectors

= 2.5.0 - 2026-04-26 =
* NEW: Lucide Icons 0.417 — 500+ icon library replacing ad-hoc inline SVGs across all templates
* NEW: page-about.php — complete redesign: animated hero, story timeline, values grid, team section, awards, client logo strip, CTA
* NEW: page-agency.php — premium Agency homepage with split hero, CSS browser mockup, bento services grid, portfolio preview, process steps, testimonials
* NEW: page-services.php — rebuilt with 10 sections: deep-dive service panels, alternating 2-col layout, pricing teaser, testimonials, FAQ accordion
* NEW: page-saas-v2.php — SaaS landing page (Linear/Stripe quality): CSS macOS app mockup hero, bento feature grid, annual/monthly pricing toggle, masonry testimonials
* NEW: Google Fonts typography pairing system — 7 curated font pairings selectable per skin or via Customizer (Inter Tight, Plus Jakarta Sans, Outfit, Sora, Space Grotesk, DM Sans, Cormorant + Jost)
* NEW: tf_icon() and tf_icon_get() PHP helper functions as shorthand wrappers for ThemeFlex_Icons
* IMPROVED: ThemeFlex_Icons class now exports clean SVG markup (no wrapper <svg> duplication), backward-compatible sf_icon() alias preserved
* IMPROVED: class-skin-manager.php — each skin now carries a font_pair key; Typography section added to Customizer with --tf-font-heading / --tf-font-body CSS variables
* FIX: README.txt — removed Font Awesome credit (not used); added Lucide ISC license credit

= 2.4.0 - 2026-04-25 =
* IMPROVED: All front-facing emoji replaced with inline SVG icons (stroke-style, currentColor)
* NEW: SVG icon system for portfolio, archive, blog card placeholder thumbnails
* NEW: CSS gradient placeholder backgrounds for post thumbnails without images
* IMPROVED: Social follow shortcode uses SVG icons instead of emoji
* IMPROVED: WooCommerce cart and empty-cart SVG icons
* IMPROVED: WooCommerce Quick View and Wishlist SVG icons
* IMPROVED: Coming Soon page uses SVG social network icons
* IMPROVED: Admin Design System panel uses SVG navigation icons
* FIX: page-contact.php ThemeForest support card icon

= 2.3.0 - 2026-04-24 =
* NEW: 6 Starter Flavor Elementor widgets (Image Gallery, Blog Carousel, Content Slider, Progress Bar, Countdown Timer, Social Icons)
* IMPROVED: All emoji replaced with SVG in single.php, 404.php, header, footer, archive, home
* IMPROVED: page-pricing.php trust strip SVG icons
* IMPROVED: section-pricing.php guarantee icons SVG
* IMPROVED: section-demos.php type icons SVG

= 2.2.0 - 2026-04-24 =
* NEW: section-hero.php mini browser mockup with CSS-only UI elements
* NEW: section-features.php bento grid with SVG icons
* NEW: section-logocloud.php brand initial chips
* IMPROVED: section-stats.php SVG stat icons with animated counters
* IMPROVED: section-contact.php SVG channel icons

= 2.1.0 - 2026-04-24 =
* NEW: page-about.php timeline, values grid, team section with initials-based CSS avatars
* NEW: page-saas.php features grid and SaaS marketing sections
* NEW: page-services.php tools grid and process steps
* NEW: page-portfolio.php with category filter and SVG placeholder system

= 2.0.0 - 2026-04-24 =
* NEW: 8 built-in colour skins + visual swatch picker in Customizer
* NEW: SaaS Landing Page template
* NEW: Portfolio Archive + Single project templates
* NEW: About Us, Contact, Pricing standalone page templates
* NEW: Google Fonts auto-loading per skin
* IMPROVED: 6 fallback demo portfolio cards
* IMPROVED: FOUC prevention in header
* IMPROVED: Full 4-column footer rebuild
* FIX: H1 title bug on blog posts page
* FIX: Nested anchor rendering bug on homepage cards

= 1.0.0 - 2026-04-01 =
* Initial release

== Resources ==

* Inter Tight, Plus Jakarta Sans, Outfit, Sora, Space Grotesk, DM Sans, Cormorant Garamond, Jost — Google Fonts — SIL Open Font License 1.1
* Lucide Icons (https://lucide.dev) — ISC License
* Normalize.css — MIT License
