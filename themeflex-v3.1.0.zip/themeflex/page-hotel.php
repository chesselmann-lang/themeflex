<?php
/**
 * Template Name: Hotel & Hospitality Homepage
 *
 * Premium Hotel & Hospitality landing page template for ThemeFlex.
 * Art-directed hero: CSS-art hotel facade at golden hour, animated
 * window-light particles, palm silhouette, room booking widget.
 * Dark-warm luxury palette. Zero external images.
 *
 * Palette:
 *   --ht-gold:   #c9a96e  (champagne gold)
 *   --ht-amber:  #92400e  (deep amber)
 *   --ht-cream:  #faf6f0  (warm ivory)
 *   --ht-dark:   #0d0a06  (near-black warm)
 *   --ht-warm:   #1c1308  (deep warm surface)
 *
 * @package ThemeFlex
 * @since   3.1.0
 */

get_header();
?>

<style>
/* ═══════════════════════════════════════════════════════════════
   HOTEL PAGE — TOKEN LAYER
   ═══════════════════════════════════════════════════════════════ */
.tf-hotel-page {
  --ht-gold:    #c9a96e;
  --ht-gold-lt: #e8d5a8;
  --ht-gold-dk: #8a6a30;
  --ht-amber:   #92400e;
  --ht-cream:   #faf6f0;
  --ht-ivory:   #f5ede0;
  --ht-dark:    #0d0a06;
  --ht-warm:    #1c1308;
  --ht-surface: #251910;
  --ht-card:    #2d1e0e;
  --ht-text:    #d4c4a8;
  --ht-muted:   #8a7a64;
  --ht-border:  rgba(201,169,110,.15);
  --ht-border-lt: rgba(201,169,110,.08);
  --ht-shadow:  0 8px 48px rgba(13,10,6,.6);
  --ht-glow:    0 0 40px rgba(201,169,110,.12);

  background: var(--ht-dark);
  color: var(--ht-text);
  font-family: 'Inter', -apple-system, sans-serif;
  overflow-x: hidden;
}

/* ─── Typography helpers ──────────────────────────────────────── */
.tf-hotel-page .ht-serif { font-family: Georgia, 'Times New Roman', serif; }
.tf-hotel-page .ht-gold-text {
  background: linear-gradient(135deg, var(--ht-gold-lt), var(--ht-gold));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
.tf-hotel-page .ht-eyebrow {
  font-size: .68rem;
  letter-spacing: .3em;
  text-transform: uppercase;
  color: var(--ht-gold);
  margin-bottom: .875rem;
}
.tf-hotel-page .ht-divider {
  width: 60px;
  height: 1px;
  background: linear-gradient(90deg, var(--ht-gold), transparent);
  margin: 1.25rem 0;
}
.tf-hotel-page .ht-divider.center { margin: 1.25rem auto; background: linear-gradient(90deg, transparent, var(--ht-gold), transparent); width: 100px; }

/* ─── Layout ──────────────────────────────────────────────────── */
.tf-hotel-page .ht-section { position: relative; padding: 6rem 1.5rem; }
.tf-hotel-page .ht-container { max-width: 1200px; margin: 0 auto; }
.tf-hotel-page .ht-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 4rem; align-items: center; }
.tf-hotel-page .ht-grid-3 { display: grid; grid-template-columns: repeat(3,1fr); gap: 2rem; }
.tf-hotel-page .ht-grid-4 { display: grid; grid-template-columns: repeat(4,1fr); gap: 1.5rem; }

@media(max-width:900px){
  .tf-hotel-page .ht-grid-2,
  .tf-hotel-page .ht-grid-3,
  .tf-hotel-page .ht-grid-4 { grid-template-columns:1fr; gap:2rem; }
  .tf-hotel-page .ht-section { padding:4rem 1rem; }
}

/* ─── Buttons ─────────────────────────────────────────────────── */
.tf-hotel-page .ht-btn-primary {
  display: inline-flex;
  align-items: center;
  gap: .6rem;
  padding: .9rem 2.2rem;
  background: linear-gradient(135deg, var(--ht-gold) 0%, var(--ht-gold-dk) 100%);
  color: var(--ht-dark);
  border-radius: 4px;
  font-weight: 700;
  font-size: .9rem;
  letter-spacing: .05em;
  text-transform: uppercase;
  text-decoration: none;
  transition: transform .25s, box-shadow .25s;
  box-shadow: 0 4px 20px rgba(201,169,110,.3);
}
.tf-hotel-page .ht-btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 32px rgba(201,169,110,.45);
  color: var(--ht-dark);
}
.tf-hotel-page .ht-btn-outline {
  display: inline-flex;
  align-items: center;
  gap: .6rem;
  padding: .875rem 2.2rem;
  border: 1px solid var(--ht-gold);
  color: var(--ht-gold);
  border-radius: 4px;
  font-weight: 600;
  font-size: .9rem;
  letter-spacing: .05em;
  text-transform: uppercase;
  text-decoration: none;
  transition: all .25s;
}
.tf-hotel-page .ht-btn-outline:hover {
  background: var(--ht-gold);
  color: var(--ht-dark);
}

/* ═══════════════════════════════════════════════════════════════
   HERO — CSS Hotel Facade + Booking Strip
   ═══════════════════════════════════════════════════════════════ */
.ht-hero {
  min-height: 100vh;
  position: relative;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-end;
  background: linear-gradient(180deg, #0d0a06 0%, #1c1308 40%, #2d1e0e 100%);
}

/* Sky gradient with warm glow */
.ht-hero-sky {
  position: absolute;
  inset: 0;
  background:
    radial-gradient(ellipse 80% 50% at 50% 0%, rgba(146,64,14,.35) 0%, transparent 55%),
    radial-gradient(ellipse 60% 40% at 50% 20%, rgba(201,169,110,.12) 0%, transparent 50%),
    linear-gradient(180deg, #1a0c04 0%, #0d0a06 60%, #0d0a06 100%);
}

/* Stars */
.ht-stars { position: absolute; inset: 0; pointer-events: none; }
.ht-star {
  position: absolute;
  width: 2px;
  height: 2px;
  border-radius: 50%;
  background: #fff;
  opacity: 0;
  animation: ht-twinkle ease-in-out infinite;
}
@keyframes ht-twinkle { 0%,100%{opacity:.15} 50%{opacity:.7} }
<?php
$ht_star_data = [];
for ( $i = 0; $i < 60; $i++ ) {
  $x   = rand( 5, 95 );
  $y   = rand( 2, 35 );
  $dur = round( rand( 20, 50 ) / 10, 1 );
  $del = round( rand( 0, 50 ) / 10, 1 );
  echo ".ht-star:nth-child({$i}){left:{$x}%;top:{$y}%;animation-duration:{$dur}s;animation-delay:-{$del}s;}\n";
}
?>

/* Moon */
.ht-moon {
  position: absolute;
  top: 6%;
  right: 12%;
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background: radial-gradient(circle at 35% 40%, #fff9e8 0%, #f0d890 60%, #c8a840 100%);
  box-shadow: 0 0 25px rgba(201,169,110,.5), 0 0 60px rgba(201,169,110,.2);
}
.ht-moon::after {
  content: '';
  position: absolute;
  top: 6px;
  left: 12px;
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(200,168,64,.3) 0%, transparent 70%);
}

/* Hotel building facade */
.ht-building-wrap {
  position: absolute;
  bottom: 160px;
  left: 50%;
  transform: translateX(-50%);
  width: min(700px, 90vw);
}
.ht-building-svg { width: 100%; height: auto; display: block; }

/* Palm trees */
.ht-palms {
  position: absolute;
  bottom: 155px;
  width: 100%;
  pointer-events: none;
}

/* Animated window lights */
@keyframes ht-window-flicker {
  0%,95%,100%  { opacity: 1; }
  96%          { opacity: .3; }
  97%          { opacity: .9; }
}
.ht-win-on { animation: ht-window-flicker 12s ease-in-out infinite; }
.ht-win-on:nth-child(3n)   { animation-delay: -3s; }
.ht-win-on:nth-child(4n)   { animation-delay: -7s; }
.ht-win-on:nth-child(5n)   { animation-delay: -2s; }
.ht-win-on:nth-child(7n)   { animation-delay: -9s; }

/* Ground / road */
.ht-ground {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 160px;
  background: linear-gradient(180deg, #0d0a06 0%, #1a120a 60%, #201508 100%);
  border-top: 1px solid rgba(201,169,110,.1);
}
/* Driveway glow */
.ht-ground::before {
  content: '';
  position: absolute;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 200px;
  height: 100%;
  background: linear-gradient(180deg, rgba(201,169,110,.06) 0%, transparent 100%);
}
/* Lamps */
.ht-lamp {
  position: absolute;
  bottom: 40px;
  width: 6px;
  height: 60px;
  background: var(--ht-muted);
  border-radius: 3px;
}
.ht-lamp::before {
  content: '';
  position: absolute;
  top: -20px;
  left: -8px;
  width: 22px;
  height: 22px;
  border-radius: 50%;
  background: radial-gradient(circle, #fff9c4 0%, rgba(201,169,110,.6) 50%, transparent 100%);
}
.ht-lamp-l { left: calc(50% - 120px); }
.ht-lamp-r { right: calc(50% - 120px); }

/* Hero text overlay */
.ht-hero-text {
  position: relative;
  z-index: 10;
  text-align: center;
  padding: 0 1.5rem;
  margin-bottom: 220px;
  width: 100%;
}
.ht-hero-text .ht-eyebrow { justify-content: center; display: block; }
.ht-hero-title {
  font-size: clamp(2.8rem, 7vw, 5.5rem);
  font-weight: 700;
  line-height: 1.1;
  color: #fff;
  font-family: Georgia, serif;
  margin-bottom: .75rem;
  text-shadow: 0 2px 20px rgba(0,0,0,.4);
}
.ht-hero-subtitle {
  font-size: clamp(1rem, 2vw, 1.25rem);
  color: var(--ht-text);
  font-family: Georgia, serif;
  font-style: italic;
  max-width: 600px;
  margin: 0 auto 2.5rem;
}
.ht-hero-actions { display: flex; justify-content: center; gap: 1rem; flex-wrap: wrap; }

/* Booking strip */
.ht-booking-strip {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 20;
  background: rgba(13,10,6,.95);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  border-top: 1px solid var(--ht-border);
  padding: 1.75rem 2rem;
}
.ht-booking-form {
  max-width: 1100px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: 1fr 1fr 1fr 1fr auto;
  gap: 1rem;
  align-items: end;
}
.ht-booking-field label {
  display: block;
  font-size: .62rem;
  letter-spacing: .2em;
  text-transform: uppercase;
  color: var(--ht-muted);
  margin-bottom: .5rem;
}
.ht-booking-field input,
.ht-booking-field select {
  width: 100%;
  background: rgba(255,255,255,.05);
  border: 1px solid var(--ht-border);
  border-radius: 4px;
  padding: .75rem 1rem;
  color: var(--ht-gold-lt);
  font-size: .9rem;
  font-family: inherit;
  transition: border-color .2s;
}
.ht-booking-field select option { background: var(--ht-dark); }
.ht-booking-field input:focus,
.ht-booking-field select:focus { outline: none; border-color: var(--ht-gold); }
.ht-booking-field input::placeholder { color: var(--ht-muted); }

@media(max-width:800px){
  .ht-booking-form { grid-template-columns:1fr 1fr; }
  .ht-booking-field:last-of-type { grid-column:1/3; }
  .ht-hero-text { margin-bottom: 280px; }
}
@media(max-width:500px){
  .ht-booking-form { grid-template-columns:1fr; }
  .ht-booking-field:last-of-type { grid-column:1; }
  .ht-hero-text { margin-bottom: 380px; }
}

/* ═══════════════════════════════════════════════════════════════
   AWARDS / ACCOLADES BAR
   ═══════════════════════════════════════════════════════════════ */
.ht-awards {
  background: var(--ht-warm);
  border-top: 1px solid var(--ht-border);
  border-bottom: 1px solid var(--ht-border);
  padding: 2rem 1.5rem;
}
.ht-awards-inner {
  max-width: 1000px;
  margin: 0 auto;
  display: flex;
  align-items: center;
  justify-content: space-around;
  flex-wrap: wrap;
  gap: 2rem;
}
.ht-award {
  display: flex;
  align-items: center;
  gap: .75rem;
  font-size: .82rem;
  color: var(--ht-muted);
}
.ht-award-icon {
  width: 38px;
  height: 38px;
  border-radius: 50%;
  background: rgba(201,169,110,.1);
  border: 1px solid var(--ht-border);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.ht-award-icon svg { stroke: var(--ht-gold); }
.ht-award-text strong { display: block; color: var(--ht-gold-lt); font-size: .88rem; }

/* ═══════════════════════════════════════════════════════════════
   ABOUT — Heritage section
   ═══════════════════════════════════════════════════════════════ */
.ht-about { background: var(--ht-dark); }
.ht-about-visual {
  position: relative;
  height: 500px;
}
/* Main visual — lobby art */
.ht-lobby-art {
  position: absolute;
  inset: 0;
  border-radius: 12px;
  overflow: hidden;
  background: linear-gradient(160deg, #2d1e0e 0%, #1c1308 60%, #0d0a06 100%);
}
/* Chandelier */
.ht-lobby-art::before {
  content: '';
  position: absolute;
  top: 8%;
  left: 50%;
  transform: translateX(-50%);
  width: 120px;
  height: 80px;
  background:
    radial-gradient(circle at 50% 30%, rgba(201,169,110,.9) 5px, transparent 6px),
    radial-gradient(circle at 25% 60%, rgba(201,169,110,.7) 4px, transparent 5px),
    radial-gradient(circle at 75% 60%, rgba(201,169,110,.7) 4px, transparent 5px),
    radial-gradient(circle at 15% 85%, rgba(201,169,110,.6) 3px, transparent 4px),
    radial-gradient(circle at 85% 85%, rgba(201,169,110,.6) 3px, transparent 4px),
    radial-gradient(circle at 35% 85%, rgba(201,169,110,.5) 3px, transparent 4px),
    radial-gradient(circle at 65% 85%, rgba(201,169,110,.5) 3px, transparent 4px);
}
/* Chandelier glow */
.ht-lobby-art::after {
  content: '';
  position: absolute;
  top: 5%;
  left: 50%;
  transform: translateX(-50%);
  width: 200px;
  height: 200px;
  background: radial-gradient(circle, rgba(201,169,110,.12) 0%, transparent 70%);
}
/* Floor reflection */
.ht-lobby-floor {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 35%;
  background: linear-gradient(180deg, transparent 0%, rgba(201,169,110,.04) 100%);
}
/* Lobby columns */
.ht-lobby-col {
  position: absolute;
  bottom: 0;
  width: 30px;
  background: linear-gradient(180deg, #c9a96e 0%, #8a6a30 100%);
  opacity: .25;
  border-radius: 4px 4px 0 0;
}
.ht-lobby-col-l { left: 15%; height: 75%; }
.ht-lobby-col-r { right: 15%; height: 75%; }
/* Corner ornament */
.ht-corner {
  position: absolute;
  width: 60px;
  height: 60px;
}
.ht-corner-tl { top: 12px; left: 12px; border-top: 2px solid var(--ht-gold); border-left: 2px solid var(--ht-gold); }
.ht-corner-tr { top: 12px; right: 12px; border-top: 2px solid var(--ht-gold); border-right: 2px solid var(--ht-gold); }
.ht-corner-bl { bottom: 12px; left: 12px; border-bottom: 2px solid var(--ht-gold); border-left: 2px solid var(--ht-gold); }
.ht-corner-br { bottom: 12px; right: 12px; border-bottom: 2px solid var(--ht-gold); border-right: 2px solid var(--ht-gold); }

/* Year badge */
.ht-year-badge {
  position: absolute;
  bottom: 30px;
  right: 30px;
  width: 90px;
  height: 90px;
  border-radius: 50%;
  background: linear-gradient(135deg, var(--ht-gold), var(--ht-gold-dk));
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: var(--ht-dark);
  text-align: center;
  box-shadow: 0 4px 24px rgba(201,169,110,.4);
}
.ht-year-badge-num { font-size: 1.6rem; font-weight: 800; line-height: 1; }
.ht-year-badge-txt { font-size: .55rem; letter-spacing: .1em; text-transform: uppercase; }

.ht-about-content h2 {
  font-size: clamp(2rem, 4vw, 3rem);
  color: var(--ht-gold-lt);
  font-family: Georgia, serif;
  line-height: 1.2;
  margin-bottom: 1.25rem;
}
.ht-about-content p {
  color: var(--ht-text);
  line-height: 1.85;
  margin-bottom: 1rem;
  font-size: .95rem;
}
.ht-about-facts { display: grid; grid-template-columns:1fr 1fr; gap: 1rem; margin: 2rem 0; }
.ht-fact {
  border-left: 2px solid var(--ht-gold);
  padding-left: 1rem;
}
.ht-fact-num { font-size: 1.8rem; font-weight: 700; color: var(--ht-gold); font-family: Georgia, serif; }
.ht-fact-label { font-size: .78rem; color: var(--ht-muted); text-transform: uppercase; letter-spacing: .1em; }

/* ═══════════════════════════════════════════════════════════════
   ROOMS — Accommodation Grid
   ═══════════════════════════════════════════════════════════════ */
.ht-rooms { background: var(--ht-warm); border-top: 1px solid var(--ht-border-lt); }
.ht-rooms-head { text-align: center; margin-bottom: 3.5rem; }
.ht-rooms-head h2 { font-size: clamp(2rem, 4vw, 3rem); color: var(--ht-gold-lt); font-family: Georgia, serif; }
.ht-rooms-head p  { color: var(--ht-muted); max-width: 560px; margin: .75rem auto 0; }

.ht-rooms-grid {
  display: grid;
  grid-template-columns: 1.5fr 1fr 1fr;
  grid-template-rows: auto auto;
  gap: 1.5rem;
}
.ht-room-card {
  background: var(--ht-card);
  border: 1px solid var(--ht-border);
  border-radius: 8px;
  overflow: hidden;
  transition: transform .35s, box-shadow .35s;
}
.ht-room-card:hover { transform: translateY(-5px); box-shadow: var(--ht-shadow), var(--ht-glow); }
.ht-room-card--featured { grid-row: 1/3; }

.ht-room-img {
  position: relative;
  overflow: hidden;
}
.ht-room-card--featured .ht-room-img { height: 340px; }
.ht-room-img-default { height: 200px; }
.ht-room-img-inner { width: 100%; height: 100%; transition: transform .5s; }
.ht-room-card:hover .ht-room-img-inner { transform: scale(1.06); }

/* CSS room scenes */
.ht-room-card:nth-child(1) .ht-room-img-inner { /* Penthouse — deep night luxury */
  background: linear-gradient(180deg, #0d0a06 0%, #1c1308 30%, #2d1e0e 70%, #3d2810 100%);
}
.ht-room-card:nth-child(1) .ht-room-img-inner::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    /* City lights below */
    radial-gradient(ellipse 120% 30% at 50% 100%, rgba(201,169,110,.15) 0%, transparent 60%),
    /* Fireplace glow */
    radial-gradient(ellipse 40% 30% at 25% 80%, rgba(146,64,14,.4) 0%, transparent 60%),
    /* Chandelier */
    radial-gradient(circle at 50% 10%, rgba(201,169,110,.5) 8px, transparent 9px),
    radial-gradient(circle at 50% 10%, rgba(201,169,110,.15) 35px, transparent 36px);
}
.ht-room-card:nth-child(2) .ht-room-img-inner { /* Ocean suite */
  background: linear-gradient(180deg, #0a1525 0%, #0d2040 35%, #1a4060 60%, #c9a96e 80%, #8a6a30 100%);
}
.ht-room-card:nth-child(2) .ht-room-img-inner::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(circle at 75% 25%, rgba(255,220,100,.4) 14px, transparent 15px),
    radial-gradient(circle at 75% 25%, rgba(255,180,50,.1) 30px, transparent 31px),
    radial-gradient(ellipse 80% 20% at 50% 68%, rgba(201,169,110,.15) 0%, transparent 100%);
}
.ht-room-card:nth-child(3) .ht-room-img-inner { /* Garden villa */
  background: linear-gradient(180deg, #0a1a08 0%, #1a3810 50%, #2d5a1a 100%);
}
.ht-room-card:nth-child(3) .ht-room-img-inner::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(circle at 20% 70%, rgba(30,80,20,.7) 35px, transparent 36px),
    radial-gradient(circle at 70% 60%, rgba(40,100,25,.6) 28px, transparent 29px),
    radial-gradient(circle at 50% 40%, rgba(25,70,15,.5) 45px, transparent 46px),
    radial-gradient(ellipse 100% 20% at 50% 100%, rgba(0,0,0,.4) 0%, transparent 100%);
}

.ht-room-img::after {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(to top, rgba(13,10,6,.7) 0%, transparent 50%);
}
.ht-room-badge {
  position: absolute;
  top: 1rem;
  left: 1rem;
  background: var(--ht-gold);
  color: var(--ht-dark);
  font-size: .62rem;
  font-weight: 700;
  letter-spacing: .12em;
  text-transform: uppercase;
  padding: .3rem .8rem;
  border-radius: 2px;
  z-index: 1;
}
.ht-room-body { padding: 1.5rem; }
.ht-room-cat  { font-size: .68rem; letter-spacing: .2em; text-transform: uppercase; color: var(--ht-gold); margin-bottom: .4rem; }
.ht-room-name { font-size: 1.25rem; color: var(--ht-gold-lt); font-family: Georgia, serif; margin-bottom: .75rem; }
.ht-room-desc { font-size: .85rem; color: var(--ht-muted); line-height: 1.6; margin-bottom: 1.25rem; }
.ht-room-amenities { display: flex; flex-wrap: wrap; gap: .4rem; margin-bottom: 1.25rem; }
.ht-amenity-tag { font-size: .68rem; padding: .25rem .65rem; border: 1px solid var(--ht-border); border-radius: 2px; color: var(--ht-muted); }
.ht-room-footer { display: flex; align-items: center; justify-content: space-between; }
.ht-room-price-label { font-size: .68rem; color: var(--ht-muted); text-transform: uppercase; letter-spacing: .1em; }
.ht-room-price-value { font-size: 1.5rem; font-weight: 700; color: var(--ht-gold); font-family: Georgia, serif; }
.ht-room-price-night { font-size: .7rem; color: var(--ht-muted); }

@media(max-width:900px){ .ht-rooms-grid{grid-template-columns:1fr;} .ht-room-card--featured{grid-row:auto;} }

/* ═══════════════════════════════════════════════════════════════
   DINING — Restaurant section
   ═══════════════════════════════════════════════════════════════ */
.ht-dining { background: var(--ht-dark); position: relative; overflow: hidden; }
.ht-dining::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(ellipse 60% 50% at 80% 50%, rgba(146,64,14,.08) 0%, transparent 60%);
}
.ht-dining-content h2 { font-size: clamp(2rem, 4vw, 3rem); color: var(--ht-gold-lt); font-family: Georgia, serif; line-height: 1.2; margin-bottom: 1.25rem; }
.ht-dining-content p  { color: var(--ht-text); line-height: 1.85; margin-bottom: 1rem; }

/* Table setting visual */
.ht-table-art {
  position: relative;
  height: 460px;
  border-radius: 12px;
  overflow: hidden;
  background: linear-gradient(160deg, #1c1308 0%, #0d0a06 100%);
}
/* Candlelight glow */
.ht-table-art::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(ellipse 60% 80% at 50% 60%, rgba(201,169,110,.1) 0%, transparent 60%),
    radial-gradient(circle at 50% 50%, rgba(146,64,14,.15) 0%, transparent 50%);
}
/* Table surface */
.ht-table-art::after {
  content: '';
  position: absolute;
  bottom: 10%;
  left: 10%;
  right: 10%;
  height: 4px;
  background: linear-gradient(90deg, transparent, rgba(201,169,110,.3), transparent);
  border-radius: 2px;
}
.ht-dining-card {
  background: var(--ht-card);
  border: 1px solid var(--ht-border);
  border-radius: 8px;
  padding: 1.75rem;
  margin-top: 1.5rem;
}
.ht-dining-card h4 { font-size: 1.1rem; color: var(--ht-gold-lt); font-family: Georgia, serif; margin-bottom: .5rem; }
.ht-dining-card p  { font-size: .87rem; color: var(--ht-muted); line-height: 1.6; }

/* ═══════════════════════════════════════════════════════════════
   EXPERIENCES — Activities
   ═══════════════════════════════════════════════════════════════ */
.ht-experiences { background: var(--ht-warm); border-top: 1px solid var(--ht-border-lt); }
.ht-exp-head { text-align: center; margin-bottom: 3.5rem; }
.ht-exp-head h2 { font-size: clamp(2rem, 4vw, 3rem); color: var(--ht-gold-lt); font-family: Georgia, serif; }
.ht-exp-head p  { color: var(--ht-muted); max-width: 560px; margin: .75rem auto 0; }

.ht-exp-card {
  background: var(--ht-card);
  border: 1px solid var(--ht-border);
  border-radius: 8px;
  overflow: hidden;
  transition: transform .3s, border-color .3s;
}
.ht-exp-card:hover { transform: translateY(-5px); border-color: rgba(201,169,110,.3); }
.ht-exp-img { height: 200px; position: relative; overflow: hidden; }
.ht-exp-img-inner { width: 100%; height: 100%; transition: transform .4s; }
.ht-exp-card:hover .ht-exp-img-inner { transform: scale(1.05); }

/* CSS art for experiences */
.ht-exp-card:nth-child(1) .ht-exp-img-inner { background: linear-gradient(160deg, #0a1a25 0%, #1a4060 50%, #0d3050 100%); }
.ht-exp-card:nth-child(1) .ht-exp-img-inner::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(ellipse 120% 30% at 50% 100%, rgba(6,120,200,.3) 0%, transparent 100%),
    radial-gradient(ellipse 40% 15% at 50% 75%, rgba(100,200,255,.15) 0%, transparent 100%);
}
.ht-exp-card:nth-child(2) .ht-exp-img-inner { background: linear-gradient(160deg, #2d1e0e 0%, #4a2810 60%, #6a3818 100%); }
.ht-exp-card:nth-child(2) .ht-exp-img-inner::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(circle at 50% 40%, rgba(201,169,110,.2) 30px, transparent 31px),
    radial-gradient(circle at 50% 40%, rgba(201,169,110,.08) 60px, transparent 61px);
}
.ht-exp-card:nth-child(3) .ht-exp-img-inner { background: linear-gradient(160deg, #1a0a14 0%, #380a28 50%, #600a40 100%); }
.ht-exp-card:nth-child(3) .ht-exp-img-inner::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(circle at 20% 30%, rgba(255,100,200,.15) 20px, transparent 21px),
    radial-gradient(circle at 75% 50%, rgba(200,100,255,.12) 15px, transparent 16px),
    radial-gradient(circle at 50% 80%, rgba(255,150,100,.1) 25px, transparent 26px);
}

.ht-exp-img::after {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(to top, rgba(13,10,6,.6) 0%, transparent 50%);
}
.ht-exp-body { padding: 1.5rem; }
.ht-exp-cat  { font-size: .65rem; letter-spacing: .2em; text-transform: uppercase; color: var(--ht-gold); margin-bottom: .4rem; }
.ht-exp-name { font-size: 1.1rem; color: var(--ht-gold-lt); font-family: Georgia, serif; margin-bottom: .6rem; }
.ht-exp-desc { font-size: .85rem; color: var(--ht-muted); line-height: 1.6; }

/* ═══════════════════════════════════════════════════════════════
   TESTIMONIALS
   ═══════════════════════════════════════════════════════════════ */
.ht-testi { background: var(--ht-dark); }
.ht-testi-head { text-align: center; margin-bottom: 3rem; }
.ht-testi-head h2 { font-size: clamp(2rem, 4vw, 3rem); color: var(--ht-gold-lt); font-family: Georgia, serif; }

.ht-testi-card {
  background: var(--ht-warm);
  border: 1px solid var(--ht-border);
  border-radius: 8px;
  padding: 2.5rem 2rem;
  position: relative;
}
.ht-testi-card::before {
  content: '\201C';
  position: absolute;
  top: 1rem;
  left: 1.5rem;
  font-size: 5rem;
  font-family: Georgia, serif;
  color: var(--ht-gold);
  opacity: .2;
  line-height: 1;
}
.ht-testi-stars { color: var(--ht-gold); font-size: .9rem; margin-bottom: 1rem; }
.ht-testi-text  { color: var(--ht-text); line-height: 1.85; font-style: italic; font-family: Georgia, serif; margin-bottom: 1.75rem; }
.ht-testi-guest { display: flex; align-items: center; gap: .75rem; }
.ht-testi-avatar {
  width: 44px;
  height: 44px;
  border-radius: 50%;
  overflow: hidden;
  border: 1.5px solid var(--ht-gold);
}
.ht-testi-avatar-inner { width: 100%; height: 100%; }
.ht-testi-card:nth-child(1) .ht-testi-avatar-inner { background: linear-gradient(135deg, #c9a96e, #8a6a30); }
.ht-testi-card:nth-child(2) .ht-testi-avatar-inner { background: linear-gradient(135deg, #92400e, #c97b6a); }
.ht-testi-card:nth-child(3) .ht-testi-avatar-inner { background: linear-gradient(135deg, #8aab8e, #5f7d63); }
.ht-testi-name { font-weight: 700; color: var(--ht-gold-lt); font-family: Georgia, serif; font-size: .95rem; }
.ht-testi-origin { font-size: .75rem; color: var(--ht-muted); }

/* ═══════════════════════════════════════════════════════════════
   SPA & WELLNESS TEASER
   ═══════════════════════════════════════════════════════════════ */
.ht-spa {
  background: var(--ht-warm);
  border-top: 1px solid var(--ht-border-lt);
  border-bottom: 1px solid var(--ht-border-lt);
  position: relative;
  overflow: hidden;
}
.ht-spa::before {
  content: '';
  position: absolute;
  inset: 0;
  background: radial-gradient(ellipse 70% 60% at 30% 50%, rgba(201,169,110,.04) 0%, transparent 60%);
}

/* Spa pool visual */
.ht-pool-art {
  height: 380px;
  border-radius: 12px;
  overflow: hidden;
  position: relative;
  background: linear-gradient(180deg, #0a1520 0%, #0d2840 40%, #1a4060 100%);
}
/* Water surface */
.ht-pool-art::before {
  content: '';
  position: absolute;
  top: 50%;
  left: 0;
  right: 0;
  bottom: 0;
  background:
    linear-gradient(180deg, rgba(6,120,200,.4) 0%, rgba(6,80,180,.6) 100%),
    repeating-linear-gradient(90deg, rgba(255,255,255,.03) 0px, rgba(255,255,255,.03) 1px, transparent 1px, transparent 40px);
  animation: ht-water 6s ease-in-out infinite;
}
@keyframes ht-water {
  0%,100%  { clip-path: polygon(0 5%,10% 0,20% 4%,30% 0,40% 5%,50% 0,60% 4%,70% 0,80% 5%,90% 0,100% 4%,100% 100%,0 100%); }
  50%      { clip-path: polygon(0 0,10% 4%,20% 0,30% 5%,40% 0,50% 4%,60% 0,70% 5%,80% 0,90% 4%,100% 0,100% 100%,0 100%); }
}
/* Starlight reflections */
.ht-pool-art::after {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 50%;
  background:
    radial-gradient(circle at 70% 25%, rgba(255,220,100,.3) 8px, transparent 9px),
    radial-gradient(circle at 70% 25%, rgba(255,180,50,.1) 20px, transparent 21px);
}
.ht-spa-content { display: flex; flex-direction: column; justify-content: center; }
.ht-spa-content h2 { font-size: clamp(2rem, 4vw, 3rem); color: var(--ht-gold-lt); font-family: Georgia, serif; line-height: 1.2; margin-bottom: 1.25rem; }
.ht-spa-content p  { color: var(--ht-text); line-height: 1.85; margin-bottom: 1rem; }
.ht-spa-treatments { list-style: none; padding: 0; margin: 1.5rem 0 2rem; display: flex; flex-direction: column; gap: .75rem; }
.ht-spa-treatments li { display: flex; align-items: center; gap: .75rem; font-size: .9rem; color: var(--ht-text); }
.ht-spa-treatments li::before { content: '✦'; color: var(--ht-gold); font-size: .7rem; }

/* ═══════════════════════════════════════════════════════════════
   LOCATION — Map placeholder + details
   ═══════════════════════════════════════════════════════════════ */
.ht-location { background: var(--ht-dark); }
.ht-location-head { text-align: center; margin-bottom: 3rem; }
.ht-location-head h2 { font-size: clamp(2rem, 4vw, 2.8rem); color: var(--ht-gold-lt); font-family: Georgia, serif; }

.ht-location-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 3rem; }
/* CSS art map */
.ht-map-art {
  height: 400px;
  border-radius: 8px;
  overflow: hidden;
  position: relative;
  background: linear-gradient(135deg, #1a2830 0%, #0d1a22 100%);
  border: 1px solid var(--ht-border);
}
/* Roads */
.ht-map-art::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    linear-gradient(rgba(201,169,110,.12) 1px, transparent 1px),
    linear-gradient(90deg, rgba(201,169,110,.12) 1px, transparent 1px),
    linear-gradient(45deg, rgba(201,169,110,.06) 1px, transparent 1px);
  background-size: 60px 60px, 60px 60px, 120px 120px;
}
/* Hotel pin */
.ht-map-pin {
  position: absolute;
  top: 45%;
  left: 50%;
  transform: translate(-50%, -50%);
}
.ht-map-pin-dot {
  width: 18px;
  height: 18px;
  border-radius: 50% 50% 50% 0;
  background: var(--ht-gold);
  transform: rotate(-45deg);
  box-shadow: 0 0 20px rgba(201,169,110,.6);
}
.ht-map-pin-ring {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%,-50%);
  width: 40px;
  height: 40px;
  border-radius: 50%;
  border: 1px solid rgba(201,169,110,.3);
  animation: ht-ping 2s ease-out infinite;
}
@keyframes ht-ping { 0%{transform:translate(-50%,-50%) scale(0.5);opacity:1} 100%{transform:translate(-50%,-50%) scale(2);opacity:0} }
.ht-map-label {
  position: absolute;
  top: 32%;
  left: 50%;
  transform: translateX(-50%);
  background: var(--ht-card);
  border: 1px solid var(--ht-border);
  border-radius: 4px;
  padding: .4rem .75rem;
  font-size: .72rem;
  color: var(--ht-gold-lt);
  white-space: nowrap;
}
/* Compass rose */
.ht-map-compass {
  position: absolute;
  bottom: 16px;
  right: 16px;
  width: 40px;
  height: 40px;
  opacity: .5;
}

.ht-location-details { display: flex; flex-direction: column; gap: 1.5rem; }
.ht-location-detail { display: flex; align-items: flex-start; gap: 1rem; }
.ht-location-detail-icon {
  width: 40px;
  height: 40px;
  border-radius: 8px;
  background: rgba(201,169,110,.08);
  border: 1px solid var(--ht-border);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.ht-location-detail-icon svg { stroke: var(--ht-gold); }
.ht-location-detail-text strong { display: block; color: var(--ht-gold-lt); margin-bottom: .25rem; font-family: Georgia, serif; }
.ht-location-detail-text span  { font-size: .88rem; color: var(--ht-muted); line-height: 1.6; }

@media(max-width:800px){ .ht-location-grid{grid-template-columns:1fr;} }

/* ═══════════════════════════════════════════════════════════════
   CTA — Final booking prompt
   ═══════════════════════════════════════════════════════════════ */
.ht-cta {
  background: linear-gradient(135deg, var(--ht-warm) 0%, var(--ht-dark) 100%);
  padding: 6rem 1.5rem;
  text-align: center;
  position: relative;
  overflow: hidden;
  border-top: 1px solid var(--ht-border-lt);
}
.ht-cta::before {
  content: '';
  position: absolute;
  inset: 0;
  background: radial-gradient(ellipse 70% 60% at 50% 50%, rgba(201,169,110,.05) 0%, transparent 70%);
}
.ht-cta-inner { position: relative; z-index: 1; }
.ht-cta h2 { font-size: clamp(2.2rem, 5vw, 4rem); color: var(--ht-gold-lt); font-family: Georgia, serif; margin-bottom: .75rem; }
.ht-cta p  { color: var(--ht-muted); max-width: 540px; margin: 0 auto 2.5rem; line-height: 1.8; font-style: italic; font-family: Georgia, serif; }
.ht-cta-actions { display: flex; justify-content: center; gap: 1rem; flex-wrap: wrap; }
.ht-cta-offer {
  margin-top: 2rem;
  display: inline-block;
  padding: .6rem 1.5rem;
  background: rgba(201,169,110,.08);
  border: 1px solid var(--ht-border);
  border-radius: 4px;
  font-size: .8rem;
  color: var(--ht-gold);
  letter-spacing: .1em;
}
</style>

<div class="tf-hotel-page">

  <!-- ─── HERO ─────────────────────────────────────────────────── -->
  <section class="ht-hero" aria-label="<?php esc_attr_e('Hotel hero','themeflex'); ?>">

    <!-- Sky + stars -->
    <div class="ht-hero-sky" aria-hidden="true"></div>
    <div class="ht-stars" aria-hidden="true">
      <?php for ( $i = 0; $i < 60; $i++ ) : ?>
      <div class="ht-star"></div>
      <?php endfor; ?>
    </div>

    <!-- Moon -->
    <div class="ht-moon" aria-hidden="true"></div>

    <!-- Hotel building -->
    <div class="ht-building-wrap" aria-hidden="true">
      <svg class="ht-building-svg" viewBox="0 0 700 380" fill="none" xmlns="http://www.w3.org/2000/svg">

        <!-- Main building body -->
        <rect x="100" y="60"  width="500" height="320" fill="rgba(45,30,15,.9)" stroke="rgba(201,169,110,.2)" stroke-width="1"/>
        <!-- Side wings -->
        <rect x="30"  y="120" width="80"  height="260" fill="rgba(35,22,10,.9)" stroke="rgba(201,169,110,.15)" stroke-width="1"/>
        <rect x="590" y="120" width="80"  height="260" fill="rgba(35,22,10,.9)" stroke="rgba(201,169,110,.15)" stroke-width="1"/>

        <!-- Roofline details -->
        <path d="M 95,60 L 605,60 L 620,45 L 80,45 Z" fill="rgba(60,40,20,.8)" stroke="rgba(201,169,110,.3)" stroke-width="1"/>
        <!-- Cornice -->
        <rect x="90"  y="55" width="520" height="8" fill="rgba(201,169,110,.25)" rx="2"/>

        <!-- Central tower -->
        <rect x="280" y="15" width="140" height="50" fill="rgba(50,35,18,.9)" stroke="rgba(201,169,110,.3)" stroke-width="1"/>
        <!-- Flag -->
        <line x1="350" y1="5" x2="350" y2="20" stroke="rgba(201,169,110,.6)" stroke-width="2"/>
        <polygon points="350,5 370,10 350,15" fill="rgba(201,169,110,.7)"/>

        <!-- Hotel entrance -->
        <path d="M 290,380 L 290,280 Q 350,240 410,280 L 410,380" fill="rgba(201,169,110,.08)" stroke="rgba(201,169,110,.3)" stroke-width="1.5"/>
        <!-- Door -->
        <rect x="325" y="320" width="50" height="60" fill="rgba(201,169,110,.15)" stroke="rgba(201,169,110,.3)" stroke-width="1"/>
        <line x1="350" y1="320" x2="350" y2="380" stroke="rgba(201,169,110,.2)" stroke-width="1"/>

        <!-- Colonnade -->
        <?php for ( $col = 0; $col < 5; $col++ ) : ?>
        <rect x="<?php echo 200 + $col * 70; ?>" y="320" width="10" height="60" fill="rgba(201,169,110,.2)" rx="3"/>
        <?php endfor; ?>

        <!-- Windows — lit (on) -->
        <?php
        // Generate window grid: floors × columns
        $ht_win_floors = 5;
        $ht_win_cols   = 9;
        $ht_win_x_start = 120;
        $ht_win_y_start = 80;
        $ht_win_dx = 52;
        $ht_win_dy = 48;
        $ht_win_on_prob = 0.72; // 72% of windows lit

        for ( $row = 0; $row < $ht_win_floors; $row++ ) :
          for ( $col = 0; $col < $ht_win_cols; $col++ ) :
            $wx = $ht_win_x_start + $col * $ht_win_dx;
            $wy = $ht_win_y_start + $row * $ht_win_dy;
            // Skip entrance arch area
            if ( $row >= 4 && $col >= 3 && $col <= 5 ) continue;
            $is_lit = ( ( $row * $ht_win_cols + $col ) % 10 ) < 7; // deterministic 70%
        ?>
        <rect x="<?php echo $wx; ?>" y="<?php echo $wy; ?>" width="28" height="20" rx="2"
          fill="<?php echo $is_lit ? 'rgba(201,169,110,0.55)' : 'rgba(13,10,6,0.8)'; ?>"
          stroke="rgba(201,169,110,.2)" stroke-width=".5"
          class="<?php echo $is_lit ? 'ht-win-on' : ''; ?>"/>
        <?php endforeach; endfor; ?>

        <!-- Wing windows -->
        <?php
        for ( $row = 0; $row < 4; $row++ ) :
          for ( $side = 0; $side < 2; $side++ ) :
            $wx = $side === 0 ? 42 : 600;
            $wy = 135 + $row * 55;
            $lit = ( $row + $side ) % 3 !== 2;
        ?>
        <rect x="<?php echo $wx; ?>" y="<?php echo $wy; ?>" width="26" height="20" rx="2"
          fill="<?php echo $lit ? 'rgba(201,169,110,0.45)' : 'rgba(13,10,6,0.8)'; ?>"
          stroke="rgba(201,169,110,.2)" stroke-width=".5"
          class="<?php echo $lit ? 'ht-win-on' : ''; ?>"/>
        <?php endfor; endfor; ?>

        <!-- Balconies on featured floors -->
        <?php for ( $col = 0; $col < 9; $col++ ) : ?>
        <rect x="<?php echo 116 + $col * 52; ?>" y="175" width="38" height="4" fill="rgba(201,169,110,.25)" rx="1"/>
        <rect x="<?php echo 116 + $col * 52; ?>" y="223" width="38" height="4" fill="rgba(201,169,110,.2)" rx="1"/>
        <?php endfor; ?>

        <!-- Ground floor arcade -->
        <?php for ( $a = 0; $a < 8; $a++ ) : ?>
        <path d="M <?php echo 110 + $a*62; ?>,380 L <?php echo 110 + $a*62; ?>,340 Q <?php echo 141 + $a*62; ?>,315 <?php echo 172 + $a*62; ?>,340 L <?php echo 172 + $a*62; ?>,380"
          fill="rgba(201,169,110,.05)" stroke="rgba(201,169,110,.15)" stroke-width=".8"/>
        <?php endfor; ?>

      </svg>
    </div>

    <!-- Palm silhouettes -->
    <div class="ht-palms" aria-hidden="true">
      <svg viewBox="0 0 700 200" fill="none" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:auto;position:absolute;bottom:0;">
        <!-- Left palm -->
        <g opacity=".6">
          <line x1="80" y1="200" x2="95" y2="120" stroke="rgba(45,25,5,.9)" stroke-width="6" stroke-linecap="round"/>
          <path d="M 95,120 Q 55,90 30,60 Q 60,85 95,105" fill="rgba(30,50,15,.7)"/>
          <path d="M 95,120 Q 120,80 145,55 Q 115,85 95,110" fill="rgba(30,50,15,.65)"/>
          <path d="M 95,120 Q 70,100 45,85 Q 75,100 95,115" fill="rgba(30,50,15,.6)"/>
        </g>
        <!-- Right palm -->
        <g opacity=".55">
          <line x1="620" y1="200" x2="605" y2="110" stroke="rgba(45,25,5,.9)" stroke-width="6" stroke-linecap="round"/>
          <path d="M 605,110 Q 650,80 680,50 Q 645,80 605,100" fill="rgba(30,50,15,.7)"/>
          <path d="M 605,110 Q 575,75 555,50 Q 580,80 605,105" fill="rgba(30,50,15,.65)"/>
          <path d="M 605,110 Q 635,95 660,80 Q 630,95 605,108" fill="rgba(30,50,15,.6)"/>
        </g>
      </svg>
    </div>

    <!-- Ground -->
    <div class="ht-ground" aria-hidden="true">
      <div class="ht-lamp ht-lamp-l"></div>
      <div class="ht-lamp ht-lamp-r"></div>
    </div>

    <!-- Hero text -->
    <div class="ht-hero-text">
      <div class="ht-eyebrow">Est. 1924 · French Riviera · 5-Star Luxury</div>
      <h1 class="ht-hero-title">Grand Hôtel<br><span class="ht-gold-text ht-serif">Belle Époque</span></h1>
      <p class="ht-hero-subtitle">Where timeless elegance meets the luminous Côte d'Azur</p>
      <div class="ht-hero-actions">
        <a href="<?php echo esc_url( home_url( '/reservations' ) ); ?>" class="ht-btn-primary">
          <?php echo tf_icon_get('calendar', 18, 18); ?>
          Reserve Your Stay
        </a>
        <a href="<?php echo esc_url( home_url( '/rooms' ) ); ?>" class="ht-btn-outline">
          <?php echo tf_icon_get('layout', 18, 18); ?>
          Explore Rooms
        </a>
      </div>
    </div>

    <!-- Booking strip -->
    <div class="ht-booking-strip">
      <form class="ht-booking-form" method="get" action="<?php echo esc_url( home_url( '/reservations' ) ); ?>">
        <?php wp_nonce_field('ht_search_nonce','ht_nonce'); ?>
        <div class="ht-booking-field">
          <label for="ht-checkin"><?php esc_html_e('Check-In','themeflex'); ?></label>
          <input type="text" id="ht-checkin" name="checkin" placeholder="dd / mm / yyyy">
        </div>
        <div class="ht-booking-field">
          <label for="ht-checkout"><?php esc_html_e('Check-Out','themeflex'); ?></label>
          <input type="text" id="ht-checkout" name="checkout" placeholder="dd / mm / yyyy">
        </div>
        <div class="ht-booking-field">
          <label for="ht-guests"><?php esc_html_e('Guests','themeflex'); ?></label>
          <select id="ht-guests" name="guests">
            <option>1 Adult</option>
            <option>2 Adults</option>
            <option>2 Adults + 1 Child</option>
            <option>2 Adults + 2 Children</option>
            <option>Group (3+)</option>
          </select>
        </div>
        <div class="ht-booking-field">
          <label for="ht-room"><?php esc_html_e('Room Type','themeflex'); ?></label>
          <select id="ht-room" name="room">
            <option value=""><?php esc_html_e('Any Category','themeflex'); ?></option>
            <option>Deluxe Room</option>
            <option>Ocean Suite</option>
            <option>Garden Villa</option>
            <option>Penthouse Suite</option>
          </select>
        </div>
        <button type="submit" class="ht-btn-primary" style="white-space:nowrap;">
          <?php echo tf_icon_get('search', 18, 18); ?>
          <?php esc_html_e('Check Availability','themeflex'); ?>
        </button>
      </form>
    </div>
  </section>

  <!-- ─── AWARDS ───────────────────────────────────────────────── -->
  <div class="ht-awards">
    <div class="ht-awards-inner">
      <?php
      $ht_awards = [
        [ 'award',    'Forbes Travel Guide',     '5-Star Award 2025' ],
        [ 'star',     'Condé Nast Traveller',    'Gold List 2025' ],
        [ 'shield',   'Leading Hotels of World', 'Member Since 1938' ],
        [ 'thumbs-up','TripAdvisor',              'Travellers\' Choice 2025' ],
        [ 'heart',    'European Hotel Awards',    'Best Luxury Property' ],
      ];
      foreach ( $ht_awards as $aw ) :
      ?>
      <div class="ht-award">
        <div class="ht-award-icon" aria-hidden="true"><?php echo tf_icon_get($aw[0], 17, 17); ?></div>
        <div>
          <strong><?php echo esc_html( $aw[1] ); ?></strong>
          <?php echo esc_html( $aw[2] ); ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- ─── ABOUT ─────────────────────────────────────────────────── -->
  <section class="ht-section ht-about">
    <div class="ht-container">
      <div class="ht-grid-2">

        <!-- Lobby art -->
        <div class="ht-about-visual" aria-hidden="true">
          <div class="ht-lobby-art">
            <div class="ht-lobby-floor"></div>
            <div class="ht-lobby-col ht-lobby-col-l"></div>
            <div class="ht-lobby-col ht-lobby-col-r"></div>
            <div class="ht-corner ht-corner-tl"></div>
            <div class="ht-corner ht-corner-tr"></div>
            <div class="ht-corner ht-corner-bl"></div>
            <div class="ht-corner ht-corner-br"></div>
          </div>
          <div class="ht-year-badge" aria-hidden="true">
            <div class="ht-year-badge-num">100</div>
            <div class="ht-year-badge-txt">Years<br>of Heritage</div>
          </div>
        </div>

        <!-- Copy -->
        <div>
          <p class="ht-eyebrow">Our Heritage</p>
          <h2 style="font-size:clamp(2rem,4vw,3rem);color:var(--ht-gold-lt);font-family:Georgia,serif;line-height:1.2;margin-bottom:1.25rem;">A Century of<br>Unrivalled Hospitality</h2>
          <div class="ht-divider"></div>
          <p style="color:var(--ht-text);line-height:1.85;margin-bottom:1rem;">Since opening its doors in 1924, Grand Hôtel Belle Époque has welcomed kings, artists, diplomats, and discerning travellers seeking perfection. Perched above the azure Mediterranean, our Beaux-Arts palace has defined luxury hospitality for a century.</p>
          <p style="color:var(--ht-muted);line-height:1.85;margin-bottom:2rem;font-style:italic;font-family:Georgia,serif;">We believe that true luxury lies not in opulence alone, but in the quality of human connection — the remembered name, the anticipated need, the unexpected gesture.</p>
          <div class="ht-about-facts">
            <?php
            $ht_facts = [
              ['100', 'Years of History'],
              ['92',  'Suites & Rooms'],
              ['3',   'Michelin-Starred Restaurant'],
              ['4.9', 'Guest Rating'],
            ];
            foreach ( $ht_facts as $f ) :
            ?>
            <div class="ht-fact">
              <div class="ht-fact-num" data-counter="<?php echo esc_attr( preg_replace('/[^0-9.]/','',$f[0]) ); ?>"><?php echo esc_html( $f[0] ); ?></div>
              <div class="ht-fact-label"><?php echo esc_html( $f[1] ); ?></div>
            </div>
            <?php endforeach; ?>
          </div>
          <a href="<?php echo esc_url( home_url( '/about' ) ); ?>" class="ht-btn-outline">
            <?php echo tf_icon_get('book-open', 18, 18); ?>
            Discover Our Story
          </a>
        </div>
      </div>
    </div>
  </section>

  <!-- ─── ROOMS ─────────────────────────────────────────────────── -->
  <section class="ht-section ht-rooms">
    <div class="ht-container">
      <div class="ht-rooms-head">
        <p class="ht-eyebrow">Accommodation</p>
        <h2>Rooms & Suites</h2>
        <div class="ht-divider center" aria-hidden="true"></div>
        <p>Each of our 92 rooms and suites is a sanctuary — individually decorated with antiques, original artwork, and bespoke furnishings.</p>
      </div>
      <div class="ht-rooms-grid">

        <!-- Penthouse — Featured -->
        <article class="ht-room-card ht-room-card--featured">
          <div class="ht-room-img">
            <div class="ht-room-img-inner" style="height:340px;position:relative;"></div>
            <div class="ht-room-badge">Featured Suite</div>
          </div>
          <div class="ht-room-body">
            <div class="ht-room-cat">Penthouse</div>
            <h2 class="ht-room-name" style="font-size:1.6rem;">Royal Penthouse Suite</h2>
            <p class="ht-room-desc">Six rooms of pure opulence crowning the hotel, with panoramic views of the Mediterranean from a private terrace. Original Belle Époque plasterwork, a grand piano, and butler service around the clock.</p>
            <div class="ht-room-amenities">
              <?php foreach ( ['300 m²','Private Terrace','Butler Service','Grand Piano','Fireplace','Sea Views'] as $a ) : ?>
              <span class="ht-amenity-tag"><?php echo esc_html($a); ?></span>
              <?php endforeach; ?>
            </div>
            <div class="ht-room-footer">
              <div>
                <div class="ht-room-price-label">From</div>
                <div class="ht-room-price-value">€3,200 <span class="ht-room-price-night">/ night</span></div>
              </div>
              <a href="<?php echo esc_url( home_url('/reservations') ); ?>" class="ht-btn-primary">Reserve</a>
            </div>
          </div>
        </article>

        <!-- Ocean Suite -->
        <article class="ht-room-card">
          <div class="ht-room-img ht-room-img-default">
            <div class="ht-room-img-inner" style="position:relative;"></div>
          </div>
          <div class="ht-room-body">
            <div class="ht-room-cat">Suite</div>
            <h3 class="ht-room-name">Ocean Vista Suite</h3>
            <p class="ht-room-desc">Floor-to-ceiling windows frame an uninterrupted horizon of blue. A private balcony, separate salon, and marble bathroom with freestanding copper bath.</p>
            <div class="ht-room-amenities">
              <?php foreach ( ['85 m²','Sea View','Private Balcony','Marble Bath'] as $a ) : ?>
              <span class="ht-amenity-tag"><?php echo esc_html($a); ?></span>
              <?php endforeach; ?>
            </div>
            <div class="ht-room-footer">
              <div>
                <div class="ht-room-price-label">From</div>
                <div class="ht-room-price-value">€890 <span class="ht-room-price-night">/ night</span></div>
              </div>
              <a href="<?php echo esc_url( home_url('/reservations') ); ?>" class="ht-btn-outline">Book</a>
            </div>
          </div>
        </article>

        <!-- Garden Villa -->
        <article class="ht-room-card">
          <div class="ht-room-img ht-room-img-default">
            <div class="ht-room-img-inner" style="position:relative;"></div>
          </div>
          <div class="ht-room-body">
            <div class="ht-room-cat">Villa</div>
            <h3 class="ht-room-name">Jardin Privé Villa</h3>
            <p class="ht-room-desc">A private villa nestled in our walled garden, with a dedicated plunge pool, shaded terrace, and direct garden access. Ideal for families seeking seclusion.</p>
            <div class="ht-room-amenities">
              <?php foreach ( ['140 m²','Plunge Pool','Garden Access','Private Terrace'] as $a ) : ?>
              <span class="ht-amenity-tag"><?php echo esc_html($a); ?></span>
              <?php endforeach; ?>
            </div>
            <div class="ht-room-footer">
              <div>
                <div class="ht-room-price-label">From</div>
                <div class="ht-room-price-value">€1,450 <span class="ht-room-price-night">/ night</span></div>
              </div>
              <a href="<?php echo esc_url( home_url('/reservations') ); ?>" class="ht-btn-outline">Book</a>
            </div>
          </div>
        </article>

      </div>
    </div>
  </section>

  <!-- ─── DINING ────────────────────────────────────────────────── -->
  <section class="ht-section ht-dining">
    <div class="ht-container">
      <div class="ht-grid-2">
        <div class="ht-dining-content">
          <p class="ht-eyebrow">Gastronomy</p>
          <h2 style="font-size:clamp(2rem,4vw,3rem);color:var(--ht-gold-lt);font-family:Georgia,serif;line-height:1.2;margin-bottom:1.25rem;">Three Stars.<br>One Unforgettable<br>Table.</h2>
          <div class="ht-divider"></div>
          <p>Under the guidance of Chef Yannick Moreau, Restaurant Lumière has held three Michelin stars since 2015. The tasting menu is a journey through the seasons of Provence — each dish a dialogue between tradition and the avant-garde.</p>
          <div class="ht-dining-card">
            <h4><?php echo tf_icon_get('coffee', 18, 18, 'stroke:var(--ht-gold)'); ?> Le Bar Doré</h4>
            <p>Our Art Deco bar serves hand-crafted cocktails, rare whiskies, and light Mediterranean bites from 10am until midnight.</p>
          </div>
          <div class="ht-dining-card">
            <h4><?php echo tf_icon_get('sun', 18, 18, 'stroke:var(--ht-gold)'); ?> La Terrasse</h4>
            <p>Casual poolside dining with grilled Méditerranéen cuisine, fresh seafood, and rosé beneath the Riviera sun.</p>
          </div>
          <a href="<?php echo esc_url( home_url('/dining') ); ?>" class="ht-btn-outline" style="margin-top:1.5rem;display:inline-flex;">
            <?php echo tf_icon_get('utensils', 18, 18); ?>
            Reserve a Table
          </a>
        </div>
        <!-- Table art -->
        <div class="ht-table-art" role="img" aria-label="<?php esc_attr_e('Dining experience visual','themeflex'); ?>">
          <div class="ht-corner ht-corner-tl"></div>
          <div class="ht-corner ht-corner-tr"></div>
          <div class="ht-corner ht-corner-bl"></div>
          <div class="ht-corner ht-corner-br"></div>
        </div>
      </div>
    </div>
  </section>

  <!-- ─── SPA ───────────────────────────────────────────────────── -->
  <section class="ht-section ht-spa">
    <div class="ht-container">
      <div class="ht-grid-2">
        <!-- Pool art -->
        <div class="ht-pool-art" role="img" aria-label="<?php esc_attr_e('Infinity pool visual','themeflex'); ?>"></div>
        <!-- Copy -->
        <div class="ht-spa-content">
          <p class="ht-eyebrow">Wellbeing</p>
          <h2>Retreat Into<br>Pure Serenity</h2>
          <div class="ht-divider"></div>
          <p>Our 2,000 m² Spa Belle Époque is a sanctuary of calm — drawing on the healing traditions of the Mediterranean to restore body, mind, and spirit.</p>
          <ul class="ht-spa-treatments">
            <?php
            $ht_treatments = [
              'Hammam &amp; Thermal Experiences',
              'Vinotherapy by Caudalie',
              'Couples Ritual Suites',
              'Hydrotherapy Infinity Pool',
              'Medical Aesthetic Treatments',
              'Haute Couture Fitness Studio',
            ];
            foreach ( $ht_treatments as $t ) :
            ?>
            <li><?php echo $t; ?></li>
            <?php endforeach; ?>
          </ul>
          <a href="<?php echo esc_url( home_url('/spa') ); ?>" class="ht-btn-primary">
            <?php echo tf_icon_get('heart', 18, 18, 'stroke:var(--ht-dark)'); ?>
            Discover the Spa
          </a>
        </div>
      </div>
    </div>
  </section>

  <!-- ─── EXPERIENCES ───────────────────────────────────────────── -->
  <section class="ht-section ht-experiences">
    <div class="ht-container">
      <div class="ht-exp-head">
        <p class="ht-eyebrow">Experiences</p>
        <h2>Beyond the Room</h2>
        <div class="ht-divider center" aria-hidden="true"></div>
        <p>Curated moments that transform a stay into a memory you will return to.</p>
      </div>
      <div class="ht-grid-3">
        <?php
        $ht_exps = [
          [ 'Yachting & Water Sports',  'Mediterranean', 'Private yacht charters, diving, sea-kayaking, and water-skiing with our resident marine specialists.', 0 ],
          [ 'Provençal Culinary Journey','Gastronomy',   'Morning market visits with Chef Moreau, followed by a masterclass in classic Provençal cuisine.', 1 ],
          [ 'Riviera Evenings',          'Culture',      'Curated access to the Cannes Film Festival, Monaco Grand Prix, and exclusive private gallery openings.', 2 ],
        ];
        foreach ( $ht_exps as $exp ) :
        ?>
        <article class="ht-exp-card">
          <div class="ht-exp-img">
            <div class="ht-exp-img-inner" style="position:relative;"></div>
          </div>
          <div class="ht-exp-body">
            <div class="ht-exp-cat"><?php echo esc_html( $exp[1] ); ?></div>
            <h3 class="ht-exp-name"><?php echo esc_html( $exp[0] ); ?></h3>
            <p class="ht-exp-desc"><?php echo esc_html( $exp[2] ); ?></p>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ─── TESTIMONIALS ─────────────────────────────────────────── -->
  <section class="ht-section ht-testi">
    <div class="ht-container">
      <div class="ht-testi-head">
        <p class="ht-eyebrow">Guest Stories</p>
        <h2>Moments That Stay</h2>
      </div>
      <div class="ht-grid-3">
        <?php
        $ht_testis = [
          [
            'The penthouse at Belle Époque surpassed every expectation. The view over the bay at dawn, the white-gloved morning service, the personal thoughtfulness of every member of staff — extraordinary.',
            'H.R.H. Princess Frederica of Monaco',
            'Monte Carlo',
          ],
          [
            'I have stayed in every great hotel in Europe. None holds a candle to Belle Époque for the combination of historic atmosphere and absolute contemporary luxury. Chef Moreau\'s table is an unmissable pilgrimage.',
            'Marcus van der Berg',
            'Amsterdam',
          ],
          [
            'Our honeymoon suite was decorated with flowers we had mentioned once in passing at check-in. That is the level of attention this hotel gives. We will return every anniversary.',
            'Sophia & James Whitmore',
            'London',
          ],
        ];
        foreach ( $ht_testis as $testi ) :
        ?>
        <article class="ht-testi-card">
          <div class="ht-testi-stars" aria-label="5 stars">★★★★★</div>
          <p class="ht-testi-text">"<?php echo esc_html( $testi[0] ); ?>"</p>
          <div class="ht-testi-guest">
            <div class="ht-testi-avatar" aria-hidden="true"><div class="ht-testi-avatar-inner"></div></div>
            <div>
              <div class="ht-testi-name"><?php echo esc_html( $testi[1] ); ?></div>
              <div class="ht-testi-origin"><?php echo esc_html( $testi[2] ); ?></div>
            </div>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ─── LOCATION ─────────────────────────────────────────────── -->
  <section class="ht-section ht-location">
    <div class="ht-container">
      <div class="ht-location-head">
        <p class="ht-eyebrow">Getting Here</p>
        <h2>The Heart of the Riviera</h2>
      </div>
      <div class="ht-location-grid">
        <!-- CSS map -->
        <div class="ht-map-art" role="img" aria-label="<?php esc_attr_e('Map showing hotel location','themeflex'); ?>">
          <div class="ht-map-label">Grand Hôtel Belle Époque</div>
          <div class="ht-map-pin">
            <div class="ht-map-pin-ring"></div>
            <div class="ht-map-pin-dot"></div>
          </div>
          <!-- Compass rose -->
          <svg class="ht-map-compass" viewBox="0 0 40 40" fill="none" stroke="rgba(201,169,110,.6)" stroke-width="1">
            <circle cx="20" cy="20" r="18"/>
            <polygon points="20,4 23,18 20,22 17,18" fill="rgba(201,169,110,.5)"/>
            <polygon points="20,36 23,22 20,18 17,22" fill="rgba(201,169,110,.25)"/>
            <polygon points="4,20 18,17 22,20 18,23"  fill="rgba(201,169,110,.25)"/>
            <polygon points="36,20 22,17 18,20 22,23" fill="rgba(201,169,110,.25)"/>
            <text x="20" y="10" text-anchor="middle" font-size="6" fill="rgba(201,169,110,.8)">N</text>
          </svg>
        </div>
        <!-- Details -->
        <div class="ht-location-details">
          <?php
          $ht_loc_details = [
            [ 'map-pin',    'Address',           '1 Promenade de la Croisette\n06400 Cannes, France' ],
            [ 'plane',      'Nearest Airport',   'Nice Côte d\'Azur (NCE) — 25 minutes\nMonaco Helipad — 10 minutes by helicopter' ],
            [ 'anchor',     'From the Port',     'Private motorboat service from Cannes port\nYacht berths available on request' ],
            [ 'car',        'Valet Parking',     'Complimentary valet service for all guests\nElectric vehicle charging available' ],
            [ 'phone',      'Reservations',      '+33 4 93 38 00 00\nreservations@hotelbelleepoque.com' ],
          ];
          foreach ( $ht_loc_details as $det ) :
          ?>
          <div class="ht-location-detail">
            <div class="ht-location-detail-icon" aria-hidden="true">
              <?php echo tf_icon_get( $det[0], 17, 17 ); ?>
            </div>
            <div class="ht-location-detail-text">
              <strong><?php echo esc_html( $det[1] ); ?></strong>
              <span><?php echo nl2br( esc_html( $det[2] ) ); ?></span>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </section>

  <!-- ─── CTA ──────────────────────────────────────────────────── -->
  <section class="ht-cta">
    <div class="ht-cta-inner">
      <p class="ht-eyebrow" style="justify-content:center;margin-bottom:1rem;">Make It Unforgettable</p>
      <h2>Reserve Your<br>Belle Époque Moment</h2>
      <p class="ht-serif">Life is made of rare occasions. This is one of them.</p>
      <div class="ht-cta-actions">
        <a href="<?php echo esc_url( home_url('/reservations') ); ?>" class="ht-btn-primary">
          <?php echo tf_icon_get('calendar', 18, 18, 'stroke:var(--ht-dark)'); ?>
          Reserve Now
        </a>
        <a href="<?php echo esc_url( home_url('/contact') ); ?>" class="ht-btn-outline">
          <?php echo tf_icon_get('phone', 18, 18); ?>
          Contact Concierge
        </a>
      </div>
      <div class="ht-cta-offer">
        ✦ Complimentary champagne and late check-out for direct bookings ✦
      </div>
    </div>
  </section>

</div><!-- .tf-hotel-page -->

<script>
(function() {
  'use strict';

  // ── Animated counters ────────────────────────────────────────
  var counters = document.querySelectorAll('[data-counter]');
  if (counters.length && 'IntersectionObserver' in window) {
    var obs = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (!entry.isIntersecting) return;
        var el     = entry.target;
        var target = parseFloat(el.dataset.counter.replace(/,/g,''));
        var suffix = el.dataset.suffix || '';
        var duration = 1800;
        var startTime = null;
        var isDecimal = target % 1 !== 0;
        (function step(ts) {
          if (!startTime) startTime = ts;
          var p = Math.min((ts - startTime) / duration, 1);
          var ease = 1 - Math.pow(1 - p, 3);
          var val = target * ease;
          el.textContent = (isDecimal ? val.toFixed(1) : Math.round(val).toLocaleString()) + suffix;
          if (p < 1) requestAnimationFrame(step);
        })(performance.now());
        obs.unobserve(el);
      });
    }, { threshold: 0.5 });
    counters.forEach(function(c) { obs.observe(c); });
  }

})();
</script>

<?php get_footer(); ?>
