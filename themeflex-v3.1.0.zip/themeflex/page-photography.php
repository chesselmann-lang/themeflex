<?php
/**
 * Template Name: Photography Studio Homepage
 *
 * Premium dark photography studio landing page.
 * Near-black + amber accent · CSS aperture/camera hero ·
 * masonry portfolio · services · testimonials · booking form.
 *
 * @package ThemeFlex
 * @since   3.0.0
 */

get_header();
?>

<style>
/* ============================================================
   PHOTOGRAPHY PAGE — DESIGN TOKENS
   ============================================================ */
.tf-photo-page {
  --ph-bg:       #080808;
  --ph-surface:  #0f0f0f;
  --ph-card:     #141414;
  --ph-border:   rgba(255,255,255,.06);
  --ph-accent:   #e8a838;    /* warm amber / film orange */
  --ph-accent2:  #f5f5f5;    /* light */
  --ph-red:      #e84444;    /* darkroom red */
  --ph-text:     #f0ede8;
  --ph-muted:    #5a5650;
}

.tf-photo-page {
  background: var(--ph-bg);
  color: var(--ph-text);
  font-family: var(--tf-font-body,'Inter','Helvetica Neue',sans-serif);
  line-height: 1.6;
}

/* ============================================================
   HERO — FULL WIDTH WITH CSS CAMERA APERTURE
   ============================================================ */
.ph-hero {
  position: relative;
  min-height: clamp(600px,92vh,900px);
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  background: var(--ph-bg);
}

/* Dark texture grid */
.ph-hero__grid {
  position: absolute;
  inset: 0;
  background-image:
    linear-gradient(rgba(232,168,56,.03) 1px, transparent 1px),
    linear-gradient(90deg, rgba(232,168,56,.03) 1px, transparent 1px);
  background-size: 60px 60px;
  pointer-events: none;
}

/* Central aperture ring */
.ph-aperture {
  position: absolute;
  top: 50%;
  right: 8%;
  transform: translateY(-50%);
  width: clamp(300px, 42vw, 500px);
  height: clamp(300px, 42vw, 500px);
  pointer-events: none;
}
.ph-aperture__ring {
  position: absolute;
  inset: 0;
  border-radius: 50%;
  border: 1px solid rgba(232,168,56,.15);
  animation: ph-ring-spin var(--s,40s) linear infinite var(--dir,normal);
}
.ph-aperture__ring:nth-child(1) { --s:50s; border-color: rgba(232,168,56,.08); }
.ph-aperture__ring:nth-child(2) { inset:8%; --s:35s; --dir:reverse; border-color:rgba(232,168,56,.15); }
.ph-aperture__ring:nth-child(3) { inset:16%; --s:25s; border-color: rgba(232,168,56,.2); border-width: 1.5px; }
.ph-aperture__ring:nth-child(4) { inset:24%; --s:18s; --dir:reverse; border-color:rgba(232,168,56,.3); border-width: 2px; }
.ph-aperture__ring:nth-child(5) { inset:32%; --s:12s; border-color:rgba(232,168,56,.5); border-width: 2.5px; }

/* Tick marks on rings */
.ph-aperture__ring::before {
  content:'';
  position: absolute;
  top: -3px;
  left: 50%;
  width: 1px;
  height: 6px;
  background: var(--ph-accent);
  opacity: .5;
}

/* Aperture blades */
.ph-aperture__blades {
  position: absolute;
  inset: 30%;
  border-radius: 50%;
  overflow: hidden;
}
.ph-blade {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 50%;
  height: 50%;
  transform-origin: 0% 0%;
  background: rgba(232,168,56,.06);
  border-left: 1px solid rgba(232,168,56,.15);
  animation: ph-blade-open 3s ease-in-out infinite alternate;
}
@keyframes ph-blade-open {
  0%   { opacity: .8; }
  100% { opacity: .3; }
}
<?php for($i=0;$i<8;$i++) echo ".ph-blade:nth-child(".($i+1).") { transform: rotate(".($i*45)."deg); animation-delay:".($i*.1)."s; }\n"; ?>

/* Lens centre glow */
.ph-aperture__glow {
  position: absolute;
  inset: 38%;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(232,168,56,.12) 0%, transparent 70%);
  animation: ph-glow-pulse 4s ease-in-out infinite;
}
@keyframes ph-glow-pulse {
  0%,100% { opacity:.6; transform: scale(1); }
  50% { opacity:1; transform: scale(1.1); }
}
@keyframes ph-ring-spin {
  to { transform: rotate(360deg); }
}

/* Film strip decoration on left */
.ph-filmstrip {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 48px;
  background: #0a0a0a;
  border-right: 1px solid rgba(232,168,56,.08);
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 1rem 0;
  gap: .75rem;
  overflow: hidden;
}
.ph-filmstrip__hole {
  width: 24px;
  height: 16px;
  border: 1px solid rgba(232,168,56,.2);
  border-radius: 3px;
  flex-shrink: 0;
}
.ph-filmstrip__frame {
  width: 32px;
  height: 24px;
  background: rgba(232,168,56,.06);
  border: 1px solid rgba(232,168,56,.12);
  border-radius: 2px;
  flex-shrink: 0;
}

/* Hero copy */
.ph-hero__copy {
  position: relative;
  z-index: 2;
  max-width: 680px;
  padding: 0 3rem 0 5rem;
  text-align: left;
}
.ph-hero__tag {
  display: inline-flex;
  align-items: center;
  gap: .5rem;
  font-size: .68rem;
  letter-spacing: .2em;
  text-transform: uppercase;
  color: var(--ph-accent);
  margin-bottom: 1.5rem;
}
.ph-hero__tag-line { width: 2.5rem; height: 1px; background: var(--ph-accent); }

.ph-hero__h1 {
  font-family: var(--tf-font-heading,'Cormorant Garamond','Georgia',serif);
  font-size: clamp(3.5rem,7vw,7.5rem);
  font-weight: 300;
  line-height: .95;
  letter-spacing: -.03em;
  color: var(--ph-text);
  margin: 0 0 1.5rem;
}
.ph-hero__h1 em { font-style: italic; color: var(--ph-accent); }

.ph-hero__sub {
  font-size: 1rem;
  color: var(--ph-muted);
  max-width: 36ch;
  line-height: 1.75;
  margin: 0 0 2.5rem;
}
.ph-hero__ctas { display: flex; gap: 1rem; flex-wrap: wrap; }

.ph-btn {
  display: inline-flex;
  align-items: center;
  gap: .5rem;
  padding: .85rem 1.75rem;
  border-radius: 0;
  font-size: .82rem;
  font-weight: 500;
  letter-spacing: .06em;
  text-transform: uppercase;
  text-decoration: none;
  transition: all .25s ease;
  cursor: pointer;
  border: none;
}
.ph-btn--primary { background: var(--ph-accent); color: #0a0a0a; }
.ph-btn--primary:hover { background: #f0b840; }
.ph-btn--outline { background: transparent; color: var(--ph-text); border: 1px solid rgba(255,255,255,.15); }
.ph-btn--outline:hover { border-color: var(--ph-accent); color: var(--ph-accent); }

.ph-hero__credits {
  display: flex;
  gap: 2.5rem;
  margin-top: 3rem;
  padding-top: 2rem;
  border-top: 1px solid var(--ph-border);
}
.ph-hero__credit-val {
  font-family: var(--tf-font-heading,'Cormorant Garamond','Georgia',serif);
  font-size: 2.8rem;
  font-weight: 300;
  color: var(--ph-accent);
  line-height: 1;
}
.ph-hero__credit-lbl {
  font-size: .65rem;
  letter-spacing: .14em;
  text-transform: uppercase;
  color: var(--ph-muted);
  margin-top: .2rem;
}

/* ============================================================
   PORTFOLIO GRID (masonry-style)
   ============================================================ */
.ph-portfolio {
  background: var(--ph-surface);
  padding: 6rem 0;
}
.ph-container { max-width: 1400px; margin: 0 auto; padding: 0 2.5rem; }
.ph-section-container { max-width: 1280px; margin: 0 auto; padding: 0 2.5rem; }
.ph-label {
  display: inline-flex;
  align-items: center;
  gap: .6rem;
  font-size: .68rem;
  letter-spacing: .2em;
  text-transform: uppercase;
  color: var(--ph-accent);
  margin-bottom: 1rem;
}
.ph-label-line { width: 2rem; height: 1px; background: var(--ph-accent); }
.ph-h2 {
  font-family: var(--tf-font-heading,'Cormorant Garamond','Georgia',serif);
  font-size: clamp(2.2rem,4.5vw,4rem);
  font-weight: 300;
  line-height: 1.1;
  letter-spacing: -.02em;
  color: var(--ph-text);
  margin: 0 0 1rem;
}
.ph-h2 em { font-style: italic; color: var(--ph-accent); }
.ph-lead { font-size: 1rem; color: var(--ph-muted); max-width: 50ch; line-height: 1.75; }

.ph-portfolio__header {
  max-width: 1280px;
  margin: 0 auto 3rem;
  padding: 0 2.5rem;
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 1.5rem;
}

/* Filter tabs */
.ph-filter-tabs { display: flex; gap: .5rem; flex-wrap: wrap; }
.ph-filter-tab {
  font-size: .7rem;
  letter-spacing: .12em;
  text-transform: uppercase;
  padding: .4rem 1rem;
  border: 1px solid var(--ph-border);
  color: var(--ph-muted);
  cursor: pointer;
  transition: all .2s;
  background: transparent;
  border-radius: 0;
}
.ph-filter-tab:hover,
.ph-filter-tab.active {
  border-color: var(--ph-accent);
  color: var(--ph-accent);
}

/* Masonry grid */
.ph-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  grid-auto-rows: 200px;
  gap: 4px;
  background: #040404;
}
.ph-grid-item {
  position: relative;
  overflow: hidden;
  cursor: pointer;
  background: var(--ph-card);
}
.ph-grid-item--tall  { grid-row: span 2; }
.ph-grid-item--wide  { grid-column: span 2; }
.ph-grid-item--large { grid-column: span 2; grid-row: span 2; }

/* CSS photo placeholders — each unique */
.ph-grid-bg {
  position: absolute;
  inset: 0;
  transition: transform .8s cubic-bezier(.16,1,.3,1);
}
.ph-grid-item:hover .ph-grid-bg { transform: scale(1.06); }

.ph-grid-item--1 .ph-grid-bg { background: linear-gradient(135deg,#1a1008 0%,#2d1f0a 50%,#1a1008 100%); }
.ph-grid-item--2 .ph-grid-bg { background: linear-gradient(160deg,#0d0d1a 0%,#141428 100%); }
.ph-grid-item--3 .ph-grid-bg { background: linear-gradient(120deg,#0e1a12 0%,#162a1c 100%); }
.ph-grid-item--4 .ph-grid-bg { background: linear-gradient(150deg,#1a0a0a 0%,#2d1010 100%); }
.ph-grid-item--5 .ph-grid-bg { background: linear-gradient(135deg,#08101a 0%,#101820 100%); }
.ph-grid-item--6 .ph-grid-bg { background: linear-gradient(120deg,#1a1510 0%,#2a2018 100%); }
.ph-grid-item--7 .ph-grid-bg { background: linear-gradient(140deg,#100818 0%,#1a1028 100%); }

/* Subject silhouettes via CSS shapes */
/* Portrait — oval figure shape */
.ph-subject-portrait {
  position: absolute;
  bottom: 10%;
  left: 50%;
  transform: translateX(-50%);
  width: 40%;
  height: 60%;
}
.ph-subject-portrait::before {
  content: '';
  position: absolute;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 35%;
  height: 38%;
  border-radius: 50%;
  background: rgba(232,168,56,.12);
}
.ph-subject-portrait::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 80%;
  height: 62%;
  border-radius: 40% 40% 0 0;
  background: rgba(232,168,56,.08);
}

/* Architecture — building shape */
.ph-subject-arch {
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 60%;
  height: 70%;
  border: 1px solid rgba(232,168,56,.15);
  background: rgba(232,168,56,.04);
}
.ph-subject-arch::before {
  content:'';
  position: absolute;
  top: -20%;
  left: 20%;
  right: 20%;
  height: 20%;
  background: rgba(232,168,56,.06);
  border: 1px solid rgba(232,168,56,.1);
  border-bottom: none;
}

/* Wedding — two figures */
.ph-subject-wedding {
  position: absolute;
  bottom: 5%;
  left: 50%;
  transform: translateX(-50%);
  width: 60%;
  height: 65%;
  display: flex;
  gap: 8px;
  align-items: flex-end;
  justify-content: center;
}
.ph-wed-fig {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
}
.ph-wed-head {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: rgba(255,255,255,.1);
  flex-shrink: 0;
}
.ph-wed-body {
  flex: 1;
  width: 28px;
  background: rgba(255,255,255,.06);
  border-radius: 4px 4px 0 0;
}
.ph-wed-fig--dress .ph-wed-body { width: 40px; border-radius: 20px 20px 0 0; }

/* Nature — horizon line */
.ph-subject-nature {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
}
.ph-nature-sky { flex: .6; background: linear-gradient(180deg, transparent, rgba(232,168,56,.04)); }
.ph-nature-ground { flex: .4; background: rgba(52,211,153,.04); border-top: 1px solid rgba(52,211,153,.15); }

/* Commercial — product shape */
.ph-subject-product {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%,-50%);
  width: 42%;
  height: 60%;
  border: 1.5px solid rgba(232,168,56,.25);
  background: rgba(232,168,56,.06);
  border-radius: 4px;
}
.ph-subject-product::before {
  content:'';
  position: absolute;
  inset: 15%;
  border: 1px solid rgba(232,168,56,.15);
}

/* Event — stage lights */
.ph-subject-event {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 40%;
  background: rgba(232,168,56,.03);
  border-top: 1px solid rgba(232,168,56,.1);
}
.ph-event-light {
  position: absolute;
  top: -100%;
  width: 2px;
  height: 100%;
  background: linear-gradient(180deg, transparent, rgba(232,168,56,.25));
  transform-origin: top center;
}

/* Lens flare overlays */
.ph-grid-item::after {
  content:'';
  position: absolute;
  inset: 0;
  background: linear-gradient(to bottom, rgba(232,168,56,.04) 0%, transparent 40%, rgba(0,0,0,.6) 100%);
  transition: opacity .4s;
}
.ph-grid-item:hover::after { opacity: .7; }

/* Hover overlay text */
.ph-grid-overlay {
  position: absolute;
  inset: 0;
  z-index: 2;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  padding: 1.25rem 1.5rem;
  opacity: 0;
  transition: opacity .4s;
}
.ph-grid-item:hover .ph-grid-overlay { opacity: 1; }
.ph-grid-overlay__cat {
  font-size: .6rem;
  letter-spacing: .16em;
  text-transform: uppercase;
  color: var(--ph-accent);
  margin-bottom: .25rem;
}
.ph-grid-overlay__title {
  font-family: var(--tf-font-heading,'Cormorant Garamond','Georgia',serif);
  font-size: 1.2rem;
  font-weight: 300;
  color: #fff;
}

/* ============================================================
   SERVICES
   ============================================================ */
.ph-section { padding: 7rem 0; }
.ph-services { background: var(--ph-bg); }
.ph-services__grid {
  display: grid;
  grid-template-columns: repeat(2,1fr);
  gap: 1px;
  background: var(--ph-border);
  margin-top: 3.5rem;
}
.ph-service-card {
  background: var(--ph-card);
  padding: 3rem;
  position: relative;
  overflow: hidden;
  transition: background .3s;
}
.ph-service-card:hover { background: #1a1a1a; }
.ph-service-card__num {
  font-family: var(--tf-font-heading,'Cormorant Garamond','Georgia',serif);
  font-size: 5rem;
  font-weight: 300;
  color: rgba(232,168,56,.06);
  line-height: 1;
  margin-bottom: 1.5rem;
  letter-spacing: -.04em;
}
.ph-service-card__icon {
  width: 44px;
  height: 44px;
  border: 1px solid rgba(232,168,56,.3);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--ph-accent);
  margin-bottom: 1.25rem;
}
.ph-service-card__title {
  font-family: var(--tf-font-heading,'Cormorant Garamond','Georgia',serif);
  font-size: 1.5rem;
  font-weight: 400;
  color: var(--ph-text);
  margin: 0 0 .75rem;
}
.ph-service-card__desc {
  font-size: .88rem;
  color: var(--ph-muted);
  line-height: 1.75;
  margin-bottom: 1.5rem;
}
.ph-service-card__price {
  font-size: .75rem;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: var(--ph-accent);
  border: 1px solid rgba(232,168,56,.25);
  padding: .3rem .75rem;
  display: inline-block;
}
.ph-service-card__line {
  position: absolute;
  bottom: 0;
  left: 0;
  height: 2px;
  width: 0;
  background: var(--ph-accent);
  transition: width .4s;
}
.ph-service-card:hover .ph-service-card__line { width: 100%; }

/* ============================================================
   PROCESS
   ============================================================ */
.ph-process { background: var(--ph-surface); }
.ph-process__inner {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 5rem;
  align-items: center;
}
.ph-process__steps {
  display: flex;
  flex-direction: column;
  gap: 0;
}
.ph-step {
  display: flex;
  gap: 1.5rem;
  padding: 1.75rem 0;
  border-bottom: 1px solid var(--ph-border);
  position: relative;
}
.ph-step:last-child { border-bottom: none; }
.ph-step::before {
  content: '';
  position: absolute;
  left: 18px;
  top: 0;
  bottom: 0;
  width: 1px;
  background: var(--ph-border);
  z-index: 0;
}
.ph-step:first-child::before { top: 50%; }
.ph-step:last-child::before { bottom: 50%; }
.ph-step__num {
  width: 38px;
  height: 38px;
  border-radius: 50%;
  border: 1px solid rgba(232,168,56,.4);
  background: var(--ph-bg);
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: var(--tf-font-heading,'Cormorant Garamond','Georgia',serif);
  font-size: 1rem;
  font-weight: 400;
  color: var(--ph-accent);
  flex-shrink: 0;
  position: relative;
  z-index: 1;
}
.ph-step__title { font-size: .92rem; font-weight: 600; color: var(--ph-text); margin-bottom: .3rem; }
.ph-step__desc  { font-size: .82rem; color: var(--ph-muted); line-height: 1.7; }

/* Camera mockup CSS art */
.ph-camera {
  width: 100%;
  max-width: 360px;
  margin: 0 auto;
  background: #1a1a1a;
  border-radius: 16px;
  padding: 2rem;
  border: 2px solid rgba(232,168,56,.15);
  position: relative;
}
.ph-camera__top {
  height: 20px;
  display: flex;
  align-items: center;
  gap: .75rem;
  margin-bottom: 1.25rem;
}
.ph-cam-btn { width: 12px; height: 12px; border-radius: 50%; flex-shrink: 0; }
.ph-cam-btn--1 { background: #ef4444; }
.ph-cam-btn--2 { background: #f59e0b; }
.ph-cam-btn--3 { background: #22c55e; }
.ph-camera__hotshoe {
  width: 40px;
  height: 8px;
  background: #2a2a2a;
  border: 1px solid rgba(232,168,56,.2);
  border-radius: 2px;
  margin-left: auto;
}
.ph-camera__body {
  background: #222;
  border: 1.5px solid rgba(232,168,56,.2);
  border-radius: 12px;
  padding: 1.5rem;
  position: relative;
}
.ph-camera__lens-wrap {
  width: 140px;
  height: 140px;
  border-radius: 50%;
  background: #111;
  border: 3px solid rgba(232,168,56,.3);
  margin: 0 auto 1rem;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  box-shadow: 0 0 0 6px #1a1a1a, 0 0 0 8px rgba(232,168,56,.1);
}
.ph-camera__lens {
  width: 90px;
  height: 90px;
  border-radius: 50%;
  background: radial-gradient(circle at 35% 35%, #2a3a4a 0%, #0a1520 40%, #000 100%);
  border: 2px solid rgba(56,130,200,.3);
  display: flex;
  align-items: center;
  justify-content: center;
}
.ph-camera__lens-inner {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  background: radial-gradient(circle at 40% 35%, rgba(100,150,220,.2) 0%, rgba(0,0,30,.8) 100%);
  border: 1px solid rgba(100,150,220,.2);
  animation: ph-lens-pulse 4s ease-in-out infinite;
}
@keyframes ph-lens-pulse {
  0%,100% { box-shadow: 0 0 12px rgba(56,130,200,.2); }
  50% { box-shadow: 0 0 24px rgba(56,130,200,.35); }
}
.ph-camera__controls {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.ph-camera__dial {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background: #2a2a2a;
  border: 1px solid rgba(232,168,56,.2);
}
.ph-camera__screen {
  width: 80px;
  height: 50px;
  background: #0a0f0a;
  border: 1px solid rgba(34,197,94,.15);
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: .5rem;
  font-family: 'Courier New',monospace;
  color: rgba(34,197,94,.8);
  flex-direction: column;
  gap: 2px;
}
.ph-camera__shutter {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: linear-gradient(135deg,rgba(232,168,56,.4),rgba(232,168,56,.2));
  border: 1px solid var(--ph-accent);
  display: flex;
  align-items: center;
  justify-content: center;
}

/* ============================================================
   TESTIMONIALS
   ============================================================ */
.ph-testimonials { background: var(--ph-bg); }
.ph-testimonials__grid {
  display: grid;
  grid-template-columns: repeat(3,1fr);
  gap: 1px;
  background: var(--ph-border);
  margin-top: 3.5rem;
}
.ph-testi-card {
  background: var(--ph-card);
  padding: 2.5rem;
  display: flex;
  flex-direction: column;
}
.ph-testi-card__stars {
  display: flex;
  gap: .2rem;
  margin-bottom: 1.25rem;
  color: var(--ph-accent);
}
.ph-testi-card__text {
  font-family: var(--tf-font-heading,'Cormorant Garamond','Georgia',serif);
  font-size: 1.1rem;
  font-style: italic;
  font-weight: 300;
  color: var(--ph-text);
  line-height: 1.65;
  flex: 1;
  margin-bottom: 1.5rem;
}
.ph-testi-card__footer { display: flex; align-items: center; gap: .85rem; }
.ph-testi-card__av {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: .75rem;
  font-weight: 700;
  color: #fff;
  flex-shrink: 0;
}
.ph-testi-card__name { font-size: .85rem; font-weight: 600; color: var(--ph-text); }
.ph-testi-card__role { font-size: .72rem; color: var(--ph-muted); }
.ph-testi-card__session {
  margin-left: auto;
  font-size: .65rem;
  letter-spacing: .08em;
  color: var(--ph-accent);
  border: 1px solid rgba(232,168,56,.25);
  padding: .25rem .6rem;
  white-space: nowrap;
}

/* ============================================================
   BOOKING FORM
   ============================================================ */
.ph-booking { background: var(--ph-surface); }
.ph-booking__inner {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 5rem;
  align-items: start;
}
.ph-booking__info { padding-top: .5rem; }
.ph-booking__promises { display: flex; flex-direction: column; gap: 1rem; margin-top: 2rem; }
.ph-promise {
  display: flex;
  gap: .85rem;
  align-items: flex-start;
}
.ph-promise__icon {
  width: 30px;
  height: 30px;
  border: 1px solid rgba(232,168,56,.3);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--ph-accent);
  flex-shrink: 0;
}
.ph-promise__title { font-size: .88rem; font-weight: 600; color: var(--ph-text); margin-bottom: .15rem; }
.ph-promise__desc  { font-size: .8rem; color: var(--ph-muted); line-height: 1.6; }

.ph-form { display: flex; flex-direction: column; gap: 1.25rem; }
.ph-field { display: flex; flex-direction: column; gap: .4rem; }
.ph-field label {
  font-size: .7rem;
  letter-spacing: .12em;
  text-transform: uppercase;
  color: var(--ph-muted);
}
.ph-field input,
.ph-field select,
.ph-field textarea {
  background: var(--ph-card);
  border: 1px solid var(--ph-border);
  color: var(--ph-text);
  padding: .85rem 1rem;
  font-size: .9rem;
  font-family: inherit;
  outline: none;
  border-radius: 0;
  transition: border-color .2s;
  box-sizing: border-box;
  width: 100%;
  -webkit-appearance: none;
}
.ph-field input:focus,
.ph-field select:focus,
.ph-field textarea:focus { border-color: var(--ph-accent); }
.ph-field select option { background: var(--ph-card); }
.ph-field textarea { resize: vertical; min-height: 100px; }
.ph-form__row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
.ph-form__note { font-size: .73rem; color: var(--ph-muted); line-height: 1.6; border-left: 2px solid rgba(232,168,56,.3); padding-left: .75rem; }

/* ============================================================
   CTA
   ============================================================ */
.ph-cta {
  background: var(--ph-bg);
  border-top: 1px solid var(--ph-border);
  padding: 6rem 0;
  text-align: center;
  position: relative;
  overflow: hidden;
}
.ph-cta::before {
  content:'';
  position: absolute;
  top: -100px;
  left: 50%;
  transform: translateX(-50%);
  width: 500px;
  height: 500px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(232,168,56,.06) 0%, transparent 70%);
  pointer-events: none;
}
.ph-cta__inner { position: relative; z-index: 1; }
.ph-cta__eyebrow {
  font-size: .68rem;
  letter-spacing: .2em;
  text-transform: uppercase;
  color: var(--ph-accent);
  margin-bottom: 1rem;
}
.ph-cta__h2 {
  font-family: var(--tf-font-heading,'Cormorant Garamond','Georgia',serif);
  font-size: clamp(2.8rem,5.5vw,5rem);
  font-weight: 300;
  color: var(--ph-text);
  letter-spacing: -.02em;
  line-height: 1.1;
  margin: 0 0 1.25rem;
}
.ph-cta__h2 em { font-style: italic; color: var(--ph-accent); }
.ph-cta__sub {
  font-size: 1rem;
  color: var(--ph-muted);
  max-width: 44ch;
  margin: 0 auto 2.5rem;
  line-height: 1.75;
}
.ph-cta__btns { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; }

/* ============================================================
   RESPONSIVE
   ============================================================ */
@media (max-width: 1100px) {
  .ph-grid { grid-template-columns: repeat(3,1fr); }
}
@media (max-width: 960px) {
  .ph-hero__copy { padding: 0 2rem 0 3.5rem; }
  .ph-aperture { right: 2%; width: clamp(200px,30vw,320px); height: clamp(200px,30vw,320px); }
  .ph-process__inner { grid-template-columns: 1fr; gap: 3rem; }
  .ph-booking__inner { grid-template-columns: 1fr; gap: 3rem; }
  .ph-services__grid { grid-template-columns: 1fr; }
  .ph-testimonials__grid { grid-template-columns: 1fr 1fr; }
  .ph-grid { grid-template-columns: repeat(2,1fr); }
  .ph-grid-item--wide { grid-column: span 2; }
  .ph-grid-item--large { grid-column: span 2; }
}
@media (max-width: 640px) {
  .ph-container, .ph-section-container { padding: 0 1.5rem; }
  .ph-section { padding: 4rem 0; }
  .ph-hero__copy { padding: 4rem 1.5rem; }
  .ph-aperture { display: none; }
  .ph-hero { justify-content: flex-start; min-height: 550px; }
  .ph-testimonials__grid { grid-template-columns: 1fr; }
  .ph-grid { grid-template-columns: 1fr 1fr; }
  .ph-grid-item--large { grid-column: span 2; }
  .ph-grid-item--wide  { grid-column: span 2; }
  .ph-form__row { grid-template-columns: 1fr; }
  .ph-hero__credits { gap: 1.5rem; }
}
</style>

<main class="tf-photo-page" id="main">

  <?php
  // ============================================================
  // HERO
  // ============================================================
  ?>
  <section class="ph-hero" aria-label="<?php esc_attr_e( 'Photography studio hero', 'themeflex' ); ?>">
    <div class="ph-hero__grid" aria-hidden="true"></div>
    <div class="ph-filmstrip" aria-hidden="true">
      <?php for($i=0;$i<30;$i++) echo '<div class="ph-filmstrip__'.($i%3===0?'hole':'frame').'"></div>'."\n"; ?>
    </div>

    <!-- Aperture -->
    <div class="ph-aperture" aria-hidden="true">
      <?php for($i=0;$i<5;$i++) echo '<div class="ph-aperture__ring"></div>'."\n"; ?>
      <div class="ph-aperture__blades">
        <?php for($i=0;$i<8;$i++) echo '<div class="ph-blade"></div>'."\n"; ?>
      </div>
      <div class="ph-aperture__glow"></div>
    </div>

    <!-- Copy -->
    <div class="ph-hero__copy">
      <div class="ph-hero__tag">
        <span class="ph-hero__tag-line" aria-hidden="true"></span>
        <?php esc_html_e( 'Visual Storytelling Studio', 'themeflex' ); ?>
      </div>

      <h1 class="ph-hero__h1">
        <?php esc_html_e( 'Light,', 'themeflex' ); ?><br>
        <em><?php esc_html_e( 'Moment,', 'themeflex' ); ?></em><br>
        <?php esc_html_e( 'Story.', 'themeflex' ); ?>
      </h1>

      <p class="ph-hero__sub">
        <?php esc_html_e( 'Lumen Studio is an award-winning photography house capturing weddings, portraits, architecture, and commercial campaigns across Europe and beyond.', 'themeflex' ); ?>
      </p>

      <div class="ph-hero__ctas">
        <a href="#booking" class="ph-btn ph-btn--primary">
          <?php tf_icon( 'camera', 18 ); ?>
          <?php esc_html_e( 'Book a Session', 'themeflex' ); ?>
        </a>
        <a href="#portfolio" class="ph-btn ph-btn--outline">
          <?php tf_icon( 'image', 18 ); ?>
          <?php esc_html_e( 'View Portfolio', 'themeflex' ); ?>
        </a>
      </div>

      <div class="ph-hero__credits">
        <div>
          <div class="ph-hero__credit-val" data-counter="12" data-suffix="+">12+</div>
          <div class="ph-hero__credit-lbl"><?php esc_html_e( 'Years Active', 'themeflex' ); ?></div>
        </div>
        <div>
          <div class="ph-hero__credit-val" data-counter="800" data-suffix="+">800+</div>
          <div class="ph-hero__credit-lbl"><?php esc_html_e( 'Sessions Shot', 'themeflex' ); ?></div>
        </div>
        <div>
          <div class="ph-hero__credit-val" data-counter="22" data-suffix="">22</div>
          <div class="ph-hero__credit-lbl"><?php esc_html_e( 'Awards Won', 'themeflex' ); ?></div>
        </div>
      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // PORTFOLIO GRID
  // ============================================================
  $grid_items = [
    [ 'class'=>'ph-grid-item--1 ph-grid-item--tall',  'cat'=>__('Wedding','themeflex'),      'title'=>__('Clara & Erik','themeflex'),       'subj'=>'wedding' ],
    [ 'class'=>'ph-grid-item--2 ph-grid-item--large', 'cat'=>__('Portrait','themeflex'),     'title'=>__('Studio Portraits','themeflex'),   'subj'=>'portrait' ],
    [ 'class'=>'ph-grid-item--3',                     'cat'=>__('Architecture','themeflex'), 'title'=>__('Haus am See','themeflex'),        'subj'=>'arch' ],
    [ 'class'=>'ph-grid-item--4',                     'cat'=>__('Nature','themeflex'),       'title'=>__('Alpine Series','themeflex'),      'subj'=>'nature' ],
    [ 'class'=>'ph-grid-item--5 ph-grid-item--wide',  'cat'=>__('Commercial','themeflex'),   'title'=>__('Brand Campaign','themeflex'),     'subj'=>'product' ],
    [ 'class'=>'ph-grid-item--6',                     'cat'=>__('Events','themeflex'),       'title'=>__('Gala Evening','themeflex'),       'subj'=>'event' ],
    [ 'class'=>'ph-grid-item--7 ph-grid-item--tall',  'cat'=>__('Portrait','themeflex'),     'title'=>__('Editorial Series','themeflex'),   'subj'=>'portrait' ],
  ];
  ?>
  <section class="ph-portfolio" id="portfolio"
           aria-labelledby="ph-portfolio-h">
    <div class="ph-portfolio__header">
      <div>
        <div class="ph-label">
          <span class="ph-label-line" aria-hidden="true"></span>
          <?php esc_html_e( 'Portfolio', 'themeflex' ); ?>
        </div>
        <h2 class="ph-h2" id="ph-portfolio-h">
          <?php esc_html_e( 'Selected', 'themeflex' ); ?> <em><?php esc_html_e( 'Work', 'themeflex' ); ?></em>
        </h2>
      </div>
      <div>
        <div class="ph-filter-tabs" role="tablist" aria-label="<?php esc_attr_e( 'Filter portfolio by category', 'themeflex' ); ?>">
          <?php
          $tabs = [
            __('All','themeflex'), __('Wedding','themeflex'), __('Portrait','themeflex'),
            __('Architecture','themeflex'), __('Commercial','themeflex'),
          ];
          foreach ($tabs as $i=>$tab):
          ?>
          <button class="ph-filter-tab<?php echo $i===0?' active':''; ?>"
                  role="tab"
                  aria-selected="<?php echo $i===0?'true':'false'; ?>">
            <?php echo esc_html($tab); ?>
          </button>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <div class="ph-container">
      <div class="ph-grid">
        <?php foreach ($grid_items as $idx => $item): ?>
        <div class="ph-grid-item <?php echo esc_attr($item['class']); ?>"
             role="img"
             aria-label="<?php echo esc_attr($item['cat'].': '.$item['title']); ?>">
          <div class="ph-grid-bg"></div>
          <?php if ($item['subj'] === 'portrait'): ?>
          <div class="ph-subject-portrait" aria-hidden="true"></div>
          <?php elseif ($item['subj'] === 'arch'): ?>
          <div class="ph-subject-arch" aria-hidden="true"></div>
          <?php elseif ($item['subj'] === 'wedding'): ?>
          <div class="ph-subject-wedding" aria-hidden="true">
            <div class="ph-wed-fig ph-wed-fig--suit">
              <div class="ph-wed-head"></div>
              <div class="ph-wed-body" style="height:60px;"></div>
            </div>
            <div class="ph-wed-fig ph-wed-fig--dress">
              <div class="ph-wed-head"></div>
              <div class="ph-wed-body" style="height:60px;"></div>
            </div>
          </div>
          <?php elseif ($item['subj'] === 'nature'): ?>
          <div class="ph-subject-nature" aria-hidden="true"></div>
          <?php elseif ($item['subj'] === 'product'): ?>
          <div class="ph-subject-product" aria-hidden="true"></div>
          <?php elseif ($item['subj'] === 'event'): ?>
          <div class="ph-subject-event" aria-hidden="true">
            <div class="ph-event-light" style="left:20%;transform:rotate(-15deg);"></div>
            <div class="ph-event-light" style="left:50%;transform:rotate(0deg);"></div>
            <div class="ph-event-light" style="left:80%;transform:rotate(15deg);"></div>
          </div>
          <?php endif; ?>
          <div class="ph-grid-overlay">
            <div class="ph-grid-overlay__cat"><?php echo esc_html($item['cat']); ?></div>
            <div class="ph-grid-overlay__title"><?php echo esc_html($item['title']); ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // SERVICES
  // ============================================================
  $services = [
    [
      'icon'=>'heart',   'num'=>'01',
      'title'=>__('Wedding Photography','themeflex'),
      'desc'=>__('Full-day documentary wedding coverage — from getting-ready to reception — plus a curated collection of 600+ edited images and an optional cinematic highlight film.','themeflex'),
      'price'=>__('From €2,900','themeflex'),
    ],
    [
      'icon'=>'user',    'num'=>'02',
      'title'=>__('Portrait Sessions','themeflex'),
      'desc'=>__('Studio and location portrait sessions for individuals, families, executives, and creative professionals. Retouched gallery delivered within 5 working days.','themeflex'),
      'price'=>__('From €490','themeflex'),
    ],
    [
      'icon'=>'building-2','num'=>'03',
      'title'=>__('Architectural Photography','themeflex'),
      'desc'=>__('Interior and exterior property photography for architects, interior designers, developers, and real estate agencies — shot with tilt-shift and drone perspectives.','themeflex'),
      'price'=>__('From €890','themeflex'),
    ],
    [
      'icon'=>'briefcase','num'=>'04',
      'title'=>__('Commercial & Brand','themeflex'),
      'desc'=>__('Product photography, lookbook shoots, campaign imagery, and content creation for brands, agencies, and e-commerce platforms. Full creative direction available.','themeflex'),
      'price'=>__('From €1,400/day','themeflex'),
    ],
  ];
  ?>
  <section class="ph-section ph-services"
           aria-labelledby="ph-services-h">
    <div class="ph-section-container">
      <div class="ph-label">
        <span class="ph-label-line" aria-hidden="true"></span>
        <?php esc_html_e( 'Services', 'themeflex' ); ?>
      </div>
      <h2 class="ph-h2" id="ph-services-h">
        <?php esc_html_e( 'What We', 'themeflex' ); ?> <em><?php esc_html_e( 'Shoot', 'themeflex' ); ?></em>
      </h2>
      <div class="ph-services__grid">
        <?php foreach ($services as $srv): ?>
        <div class="ph-service-card">
          <div class="ph-service-card__num" aria-hidden="true"><?php echo esc_html($srv['num']); ?></div>
          <div class="ph-service-card__icon" aria-hidden="true">
            <?php tf_icon($srv['icon'],20); ?>
          </div>
          <h3 class="ph-service-card__title"><?php echo esc_html($srv['title']); ?></h3>
          <p class="ph-service-card__desc"><?php echo esc_html($srv['desc']); ?></p>
          <span class="ph-service-card__price"><?php echo esc_html($srv['price']); ?></span>
          <div class="ph-service-card__line" aria-hidden="true"></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // PROCESS
  // ============================================================
  $steps = [
    [ 'num'=>'1', 'title'=>__('Initial Enquiry','themeflex'),       'desc'=>__('Send a message describing your vision, date, and location. We\'ll respond within 24 hours to confirm availability.','themeflex') ],
    [ 'num'=>'2', 'title'=>__('Discovery Call','themeflex'),        'desc'=>__('A 30-minute video call to understand your style, preferences, and the story you want to tell.','themeflex') ],
    [ 'num'=>'3', 'title'=>__('Proposal & Contract','themeflex'),   'desc'=>__('Receive a tailored proposal with a clear scope, timeline, and pricing — no hidden fees. Contract and deposit to confirm the date.','themeflex') ],
    [ 'num'=>'4', 'title'=>__('Shoot Day','themeflex'),             'desc'=>__('Relax and be yourself — our job is to disappear into the background and capture authentic moments and genuine emotion.','themeflex') ],
    [ 'num'=>'5', 'title'=>__('Gallery Delivery','themeflex'),      'desc'=>__('Your edited gallery is delivered via a private online portal within 3–5 weeks. Prints, albums, and USB drives available on request.','themeflex') ],
  ];
  ?>
  <section class="ph-section ph-process"
           aria-labelledby="ph-process-h">
    <div class="ph-section-container">
      <div class="ph-process__inner">
        <div>
          <div class="ph-label">
            <span class="ph-label-line" aria-hidden="true"></span>
            <?php esc_html_e( 'How It Works', 'themeflex' ); ?>
          </div>
          <h2 class="ph-h2" id="ph-process-h">
            <?php esc_html_e( 'From Enquiry', 'themeflex' ); ?><br>
            <em><?php esc_html_e( 'to Gallery', 'themeflex' ); ?></em>
          </h2>
          <p class="ph-lead">
            <?php esc_html_e( 'Five effortless steps from first contact to receiving your finished images — guided at every stage by your dedicated photographer.', 'themeflex' ); ?>
          </p>
        </div>

        <!-- Steps -->
        <div class="ph-process__steps">
          <?php foreach ($steps as $step): ?>
          <div class="ph-step">
            <div class="ph-step__num" aria-hidden="true"><?php echo esc_html($step['num']); ?></div>
            <div>
              <div class="ph-step__title"><?php echo esc_html($step['title']); ?></div>
              <div class="ph-step__desc"><?php echo esc_html($step['desc']); ?></div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // TESTIMONIALS
  // ============================================================
  $testimonials = [
    [ 'text'=>__("We were so nervous about our wedding photos but Elena made us completely forget she was there. When the gallery arrived, we cried. Every single image is perfect — she captured things we didn't even notice happening.", 'themeflex'), 'init'=>'CK','bg'=>'#e8a838','name'=>'Clara & Erik König','role'=>__('Wedding · June 2024', 'themeflex'), 'session'=>__('Wedding','themeflex') ],
    [ 'text'=>__("The executive portraits from our brand shoot have completely transformed our agency's presence. The images are sophisticated, modern, and genuinely capture the personality of our team. Truly outstanding work.", 'themeflex'), 'init'=>'MR','bg'=>'#38bdf8','name'=>'Markus Reuter','role'=>__('CEO, Studio Reuter · Commercial', 'themeflex'), 'session'=>__('Commercial','themeflex') ],
    [ 'text'=>__("Elena's architectural photography of our completed project sold two units before the building even opened. The images show spaces as they should be shown — with soul, atmosphere, and impeccable light.", 'themeflex'), 'init'=>'AL','bg'=>'#34d399','name'=>'Anna Lehr','role'=>__('Architect, Studio AL · Architecture', 'themeflex'), 'session'=>__('Architecture','themeflex') ],
  ];
  ?>
  <section class="ph-section ph-testimonials"
           aria-labelledby="ph-testi-h">
    <div class="ph-section-container">
      <div class="ph-label">
        <span class="ph-label-line" aria-hidden="true"></span>
        <?php esc_html_e( 'Client Reviews', 'themeflex' ); ?>
      </div>
      <h2 class="ph-h2" id="ph-testi-h">
        <?php esc_html_e( 'Words from', 'themeflex' ); ?> <em><?php esc_html_e( 'Clients', 'themeflex' ); ?></em>
      </h2>
      <div class="ph-testimonials__grid">
        <?php foreach ($testimonials as $t): ?>
        <div class="ph-testi-card">
          <div class="ph-testi-card__stars" aria-label="5 star review">
            <?php for($i=0;$i<5;$i++) tf_icon('star',14); ?>
          </div>
          <p class="ph-testi-card__text"><?php echo esc_html($t['text']); ?></p>
          <div class="ph-testi-card__footer">
            <div class="ph-testi-card__av" style="background:<?php echo esc_attr($t['bg']); ?>;">
              <?php echo esc_html($t['init']); ?>
            </div>
            <div>
              <div class="ph-testi-card__name"><?php echo esc_html($t['name']); ?></div>
              <div class="ph-testi-card__role"><?php echo esc_html($t['role']); ?></div>
            </div>
            <span class="ph-testi-card__session"><?php echo esc_html($t['session']); ?></span>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // BOOKING FORM
  // ============================================================
  ?>
  <section class="ph-section ph-booking" id="booking"
           aria-labelledby="ph-booking-h">
    <div class="ph-section-container">
      <div class="ph-booking__inner">

        <div class="ph-booking__info">
          <div class="ph-label">
            <span class="ph-label-line" aria-hidden="true"></span>
            <?php esc_html_e( 'Book a Session', 'themeflex' ); ?>
          </div>
          <h2 class="ph-h2" id="ph-booking-h">
            <?php esc_html_e( "Let's Create", 'themeflex' ); ?><br>
            <em><?php esc_html_e( 'Something Beautiful', 'themeflex' ); ?></em>
          </h2>
          <p class="ph-lead">
            <?php esc_html_e( 'Tell us about your project and we\'ll respond within 24 hours with availability and a personalised quote.', 'themeflex' ); ?>
          </p>

          <div class="ph-booking__promises">
            <?php
            $promises = [
              [ 'icon'=>'clock',    'title'=>__('Response in 24 Hours','themeflex'),   'desc'=>__('We reply to every enquiry the same or next business day.','themeflex') ],
              [ 'icon'=>'calendar', 'title'=>__('Flexible Scheduling','themeflex'),    'desc'=>__('Weekdays, weekends, early mornings — we work around your diary.','themeflex') ],
              [ 'icon'=>'camera',   'title'=>__('Trial Session Available','themeflex'),'desc'=>__('Unsure which package fits? Book a 90-minute taster session first.','themeflex') ],
              [ 'icon'=>'shield',   'title'=>__('Fully Insured Studio','themeflex'),   'desc'=>__('Professional liability and equipment insurance on every shoot.','themeflex') ],
            ];
            foreach ($promises as $p):
            ?>
            <div class="ph-promise">
              <div class="ph-promise__icon" aria-hidden="true">
                <?php tf_icon($p['icon'],15); ?>
              </div>
              <div>
                <div class="ph-promise__title"><?php echo esc_html($p['title']); ?></div>
                <div class="ph-promise__desc"><?php echo esc_html($p['desc']); ?></div>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>

        <form class="ph-form" method="post" novalidate
              aria-label="<?php esc_attr_e( 'Session booking form', 'themeflex' ); ?>">
          <?php wp_nonce_field('ph_booking_enquiry','ph_booking_nonce'); ?>

          <div class="ph-form__row">
            <div class="ph-field">
              <label for="ph-first"><?php esc_html_e('First Name','themeflex'); ?></label>
              <input type="text" id="ph-first" name="first_name" required autocomplete="given-name"
                     placeholder="<?php esc_attr_e('Clara','themeflex'); ?>">
            </div>
            <div class="ph-field">
              <label for="ph-last"><?php esc_html_e('Last Name','themeflex'); ?></label>
              <input type="text" id="ph-last" name="last_name" required autocomplete="family-name"
                     placeholder="<?php esc_attr_e('König','themeflex'); ?>">
            </div>
          </div>

          <div class="ph-field">
            <label for="ph-email"><?php esc_html_e('Email Address','themeflex'); ?></label>
            <input type="email" id="ph-email" name="email" required autocomplete="email"
                   placeholder="clara@example.com">
          </div>

          <div class="ph-form__row">
            <div class="ph-field">
              <label for="ph-type"><?php esc_html_e('Session Type','themeflex'); ?></label>
              <select id="ph-type" name="session_type">
                <option value="" disabled selected><?php esc_html_e('Select type…','themeflex'); ?></option>
                <option value="wedding"><?php esc_html_e('Wedding','themeflex'); ?></option>
                <option value="engagement"><?php esc_html_e('Engagement / Pre-Wedding','themeflex'); ?></option>
                <option value="portrait"><?php esc_html_e('Portrait','themeflex'); ?></option>
                <option value="family"><?php esc_html_e('Family','themeflex'); ?></option>
                <option value="architecture"><?php esc_html_e('Architecture / Interior','themeflex'); ?></option>
                <option value="commercial"><?php esc_html_e('Commercial / Brand','themeflex'); ?></option>
                <option value="event"><?php esc_html_e('Corporate Event','themeflex'); ?></option>
              </select>
            </div>
            <div class="ph-field">
              <label for="ph-date"><?php esc_html_e('Preferred Date','themeflex'); ?></label>
              <input type="date" id="ph-date" name="preferred_date">
            </div>
          </div>

          <div class="ph-field">
            <label for="ph-location"><?php esc_html_e('Location / City','themeflex'); ?></label>
            <input type="text" id="ph-location" name="location"
                   placeholder="<?php esc_attr_e('Munich, Germany','themeflex'); ?>">
          </div>

          <div class="ph-field">
            <label for="ph-message"><?php esc_html_e('Tell Us About Your Vision','themeflex'); ?></label>
            <textarea id="ph-message" name="message" rows="4"
                      placeholder="<?php esc_attr_e('Describe your session — style preferences, location ideas, special moments you want captured…','themeflex'); ?>"></textarea>
          </div>

          <p class="ph-form__note">
            <?php esc_html_e('All enquiries are treated confidentially. Dates are not held until a booking contract is signed and a deposit received.','themeflex'); ?>
          </p>

          <button type="submit" class="ph-btn ph-btn--primary">
            <?php tf_icon('send',16); ?>
            <?php esc_html_e('Send Booking Enquiry','themeflex'); ?>
          </button>
        </form>

      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // CTA
  // ============================================================
  ?>
  <section class="ph-cta" aria-label="<?php esc_attr_e('Call to action','themeflex'); ?>">
    <div class="ph-section-container ph-cta__inner">
      <p class="ph-cta__eyebrow"><?php esc_html_e('Award-Winning Photography · Europe & Beyond','themeflex'); ?></p>
      <h2 class="ph-cta__h2">
        <?php esc_html_e('Every Moment','themeflex'); ?><br>
        <em><?php esc_html_e('Deserves to Endure','themeflex'); ?></em>
      </h2>
      <p class="ph-cta__sub">
        <?php esc_html_e('Lumen Studio has been turning fleeting moments into lasting images for over 12 years. Book a session and let us tell your story.','themeflex'); ?>
      </p>
      <div class="ph-cta__btns">
        <a href="#booking" class="ph-btn ph-btn--primary">
          <?php tf_icon('camera',18); ?>
          <?php esc_html_e('Book Your Session','themeflex'); ?>
        </a>
        <a href="#portfolio" class="ph-btn ph-btn--outline">
          <?php esc_html_e('View the Portfolio','themeflex'); ?>
          <?php tf_icon('arrow-right',16); ?>
        </a>
      </div>
    </div>
  </section>

</main>

<script>
/* Photography page — animated stat counters */
(function(){
  'use strict';
  function animateCounter(el){
    const target = parseInt(el.dataset.counter, 10);
    const suffix = el.dataset.suffix||'';
    const dur = 1600;
    let start;
    function step(ts){
      if(!start) start=ts;
      const p=Math.min((ts-start)/dur,1);
      const ease=1-Math.pow(1-p,3);
      el.textContent=Math.round(ease*target)+suffix;
      if(p<1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }
  const counters=document.querySelectorAll('.tf-photo-page [data-counter]');
  if(!counters.length) return;
  const obs=new IntersectionObserver(function(entries){
    entries.forEach(function(e){
      if(e.isIntersecting){ animateCounter(e.target); obs.unobserve(e.target); }
    });
  },{threshold:0.5});
  counters.forEach(function(c){obs.observe(c);});
})();
</script>

<?php get_footer(); ?>
