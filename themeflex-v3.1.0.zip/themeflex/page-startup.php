<?php
/**
 * Template Name: Tech Startup Homepage
 *
 * Premium Tech Startup landing page template for ThemeFlex.
 * Art-directed hero: animated CSS code-rain / matrix effect,
 * glowing terminal window mockup, geometric orbit rings.
 * Dark-first. Zero external images.
 *
 * Palette:
 *   --su-electric: #6366f1  (electric indigo)
 *   --su-cyan:     #06b6d4  (cyber cyan)
 *   --su-green:    #10b981  (terminal green)
 *   --su-bg:       #050816  (deep space)
 *   --su-surface:  #0d1526  (card surface)
 *
 * @package ThemeFlex
 * @since   3.1.0
 */

get_header();
?>

<style>
/* ═══════════════════════════════════════════════════════════════
   STARTUP PAGE — TOKEN LAYER
   ═══════════════════════════════════════════════════════════════ */
.tf-startup-page {
  --su-electric: #6366f1;
  --su-electric-lt: #818cf8;
  --su-cyan:     #06b6d4;
  --su-cyan-lt:  #67e8f9;
  --su-green:    #10b981;
  --su-amber:    #f59e0b;
  --su-red:      #ef4444;
  --su-bg:       #050816;
  --su-surface:  #0d1526;
  --su-card:     #0f1e38;
  --su-border:   rgba(99,102,241,.18);
  --su-text:     #94a3b8;
  --su-title:    #f1f5f9;
  --su-muted:    #64748b;
  --su-glow-e:   rgba(99,102,241,.15);
  --su-glow-c:   rgba(6,182,212,.12);
  --su-shadow:   0 8px 40px rgba(5,8,22,.6);

  background: var(--su-bg);
  color: var(--su-text);
  font-family: 'Inter', -apple-system, sans-serif;
  overflow-x: hidden;
}

/* ─── Utility ──────────────────────────────────────────────────── */
.tf-startup-page .su-eyebrow {
  font-size: .7rem;
  letter-spacing: .25em;
  text-transform: uppercase;
  color: var(--su-cyan);
  margin-bottom: .75rem;
  display: flex;
  align-items: center;
  gap: .5rem;
}
.tf-startup-page .su-eyebrow::before {
  content: '';
  width: 24px;
  height: 1px;
  background: var(--su-cyan);
  flex-shrink: 0;
}
.tf-startup-page .su-gradient-text {
  background: linear-gradient(135deg, var(--su-electric-lt) 0%, var(--su-cyan) 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
.tf-startup-page .su-section { position: relative; padding: 6rem 1.5rem; }
.tf-startup-page .su-container { max-width: 1200px; margin: 0 auto; }
.tf-startup-page .su-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 4rem; align-items: center; }
.tf-startup-page .su-grid-3 { display: grid; grid-template-columns: repeat(3,1fr); gap: 2rem; }
.tf-startup-page .su-grid-4 { display: grid; grid-template-columns: repeat(4,1fr); gap: 1.5rem; }

@media (max-width:900px) {
  .tf-startup-page .su-grid-2,
  .tf-startup-page .su-grid-3,
  .tf-startup-page .su-grid-4 { grid-template-columns: 1fr; gap: 2rem; }
  .tf-startup-page .su-section { padding: 4rem 1rem; }
}

/* ─── Buttons ──────────────────────────────────────────────────── */
.tf-startup-page .su-btn-primary {
  display: inline-flex;
  align-items: center;
  gap: .6rem;
  padding: .875rem 2.2rem;
  background: linear-gradient(135deg, var(--su-electric) 0%, var(--su-cyan) 100%);
  color: #fff;
  border-radius: 8px;
  font-weight: 600;
  font-size: .95rem;
  text-decoration: none;
  transition: transform .25s, box-shadow .25s;
  box-shadow: 0 4px 24px rgba(99,102,241,.35);
}
.tf-startup-page .su-btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 32px rgba(99,102,241,.5);
  color: #fff;
}
.tf-startup-page .su-btn-ghost {
  display: inline-flex;
  align-items: center;
  gap: .6rem;
  padding: .85rem 2rem;
  border: 1px solid var(--su-border);
  color: var(--su-text);
  border-radius: 8px;
  font-weight: 500;
  font-size: .95rem;
  text-decoration: none;
  transition: all .2s;
  background: rgba(255,255,255,.02);
}
.tf-startup-page .su-btn-ghost:hover {
  border-color: var(--su-electric);
  color: var(--su-electric-lt);
  background: rgba(99,102,241,.06);
}

/* ─── Card base ────────────────────────────────────────────────── */
.tf-startup-page .su-card {
  background: var(--su-card);
  border: 1px solid var(--su-border);
  border-radius: 16px;
  padding: 2rem;
  transition: transform .3s, border-color .3s;
}
.tf-startup-page .su-card:hover {
  transform: translateY(-4px);
  border-color: rgba(99,102,241,.4);
}

/* ═══════════════════════════════════════════════════════════════
   HERO — Matrix Code Rain + Terminal
   ═══════════════════════════════════════════════════════════════ */
.su-hero {
  min-height: 100vh;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 4rem;
  align-items: center;
  padding: 8rem 4vw 6rem;
  position: relative;
  overflow: hidden;
  background: var(--su-bg);
}

/* Animated grid background */
.su-hero::before {
  content: '';
  position: absolute;
  inset: 0;
  background-image:
    linear-gradient(rgba(99,102,241,.04) 1px, transparent 1px),
    linear-gradient(90deg, rgba(99,102,241,.04) 1px, transparent 1px);
  background-size: 60px 60px;
  animation: su-grid-drift 30s linear infinite;
}
@keyframes su-grid-drift {
  0%   { background-position: 0 0; }
  100% { background-position: 60px 60px; }
}

/* Radial glow spots */
.su-hero::after {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(ellipse 60% 60% at 20% 50%, rgba(99,102,241,.08) 0%, transparent 60%),
    radial-gradient(ellipse 50% 50% at 80% 30%, rgba(6,182,212,.06) 0%, transparent 60%);
  pointer-events: none;
}

/* Orbits decoration (top-right) */
.su-orbits {
  position: absolute;
  top: -80px;
  right: -80px;
  width: 500px;
  height: 500px;
  pointer-events: none;
  opacity: .35;
}
.su-orbit {
  position: absolute;
  top: 50%;
  left: 50%;
  border-radius: 50%;
  border: 1px solid;
  transform: translate(-50%,-50%);
}
.su-orbit:nth-child(1) { width: 200px; height: 200px; border-color: rgba(99,102,241,.4); animation: su-orbit-spin 20s linear infinite; }
.su-orbit:nth-child(2) { width: 320px; height: 320px; border-color: rgba(6,182,212,.3);  animation: su-orbit-spin 32s linear infinite reverse; }
.su-orbit:nth-child(3) { width: 440px; height: 440px; border-color: rgba(99,102,241,.2); animation: su-orbit-spin 48s linear infinite; }
.su-orbit-dot {
  position: absolute;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  top: -4px;
  left: 50%;
  transform: translateX(-50%);
}
.su-orbit:nth-child(1) .su-orbit-dot { background: var(--su-electric); box-shadow: 0 0 12px var(--su-electric); }
.su-orbit:nth-child(2) .su-orbit-dot { background: var(--su-cyan); box-shadow: 0 0 12px var(--su-cyan); }
.su-orbit:nth-child(3) .su-orbit-dot { background: var(--su-green); box-shadow: 0 0 12px var(--su-green); }
@keyframes su-orbit-spin { from{transform:translate(-50%,-50%) rotate(0)} to{transform:translate(-50%,-50%) rotate(360deg)} }

/* Hero left — text */
.su-hero-text { position: relative; z-index: 2; }
.su-hero-badge {
  display: inline-flex;
  align-items: center;
  gap: .5rem;
  padding: .35rem .9rem;
  background: rgba(99,102,241,.12);
  border: 1px solid rgba(99,102,241,.3);
  border-radius: 50px;
  font-size: .75rem;
  color: var(--su-electric-lt);
  margin-bottom: 1.75rem;
}
.su-hero-badge-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: var(--su-green);
  box-shadow: 0 0 8px var(--su-green);
  animation: su-pulse 2s ease-in-out infinite;
}
@keyframes su-pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:.6;transform:scale(.8)} }

.su-hero-title {
  font-size: clamp(2.5rem, 5.5vw, 4.2rem);
  font-weight: 800;
  line-height: 1.1;
  color: var(--su-title);
  margin-bottom: 1.5rem;
  letter-spacing: -.02em;
}
.su-hero-desc {
  font-size: 1.05rem;
  color: var(--su-text);
  line-height: 1.75;
  max-width: 480px;
  margin-bottom: 2.5rem;
}
.su-hero-actions {
  display: flex;
  align-items: center;
  gap: 1rem;
  flex-wrap: wrap;
  margin-bottom: 3rem;
}
.su-hero-social-proof {
  display: flex;
  align-items: center;
  gap: 1rem;
}
.su-avatar-stack {
  display: flex;
}
.su-avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  border: 2px solid var(--su-bg);
  margin-left: -10px;
  overflow: hidden;
}
.su-avatar:first-child { margin-left: 0; }
.su-avatar-inner { width: 100%; height: 100%; }
.su-avatar:nth-child(1) .su-avatar-inner { background: linear-gradient(135deg, #6366f1, #8b5cf6); }
.su-avatar:nth-child(2) .su-avatar-inner { background: linear-gradient(135deg, #06b6d4, #0ea5e9); }
.su-avatar:nth-child(3) .su-avatar-inner { background: linear-gradient(135deg, #10b981, #059669); }
.su-avatar:nth-child(4) .su-avatar-inner { background: linear-gradient(135deg, #f59e0b, #d97706); }
.su-social-text { font-size: .82rem; color: var(--su-muted); }
.su-social-text strong { color: var(--su-title); }
.su-stars-mini { color: #fbbf24; font-size: .75rem; }

/* Hero right — Terminal mockup */
.su-terminal-wrap { position: relative; z-index: 2; }
.su-terminal {
  background: #090f1e;
  border: 1px solid rgba(99,102,241,.25);
  border-radius: 14px;
  overflow: hidden;
  box-shadow: var(--su-shadow), 0 0 60px rgba(99,102,241,.08);
}
.su-terminal-bar {
  background: #0d1526;
  padding: .75rem 1.25rem;
  display: flex;
  align-items: center;
  gap: .5rem;
  border-bottom: 1px solid rgba(99,102,241,.15);
}
.su-terminal-dot {
  width: 12px;
  height: 12px;
  border-radius: 50%;
}
.su-terminal-dot:nth-child(1) { background: #ef4444; }
.su-terminal-dot:nth-child(2) { background: #f59e0b; }
.su-terminal-dot:nth-child(3) { background: #10b981; }
.su-terminal-title {
  flex: 1;
  text-align: center;
  font-size: .72rem;
  color: var(--su-muted);
  font-family: 'SF Mono', 'Fira Code', monospace;
}
.su-terminal-body {
  padding: 1.5rem;
  font-family: 'SF Mono', 'Fira Code', 'Courier New', monospace;
  font-size: .8rem;
  line-height: 1.8;
  color: var(--su-text);
  min-height: 340px;
}
.su-terminal-prompt { color: var(--su-green); }
.su-terminal-cmd    { color: var(--su-title); }
.su-terminal-output { color: var(--su-text); }
.su-terminal-key    { color: var(--su-cyan); }
.su-terminal-str    { color: #f59e0b; }
.su-terminal-num    { color: var(--su-green); }
.su-terminal-comment{ color: var(--su-muted); }
.su-terminal-cursor {
  display: inline-block;
  width: 8px;
  height: 1rem;
  background: var(--su-green);
  animation: su-blink .85s step-end infinite;
  vertical-align: text-bottom;
  margin-left: 1px;
}
@keyframes su-blink { 0%,100%{opacity:1} 50%{opacity:0} }

/* Floating badges around terminal */
.su-float-badge {
  position: absolute;
  background: var(--su-card);
  border: 1px solid var(--su-border);
  border-radius: 10px;
  padding: .6rem 1rem;
  display: flex;
  align-items: center;
  gap: .6rem;
  font-size: .78rem;
  color: var(--su-title);
  box-shadow: var(--su-shadow);
  animation: su-float 5s ease-in-out infinite;
  white-space: nowrap;
}
.su-float-badge:nth-child(2) { top: 10%; right: -20px; animation-delay: 0s; }
.su-float-badge:nth-child(3) { bottom: 15%; left: -30px; animation-delay: 1.2s; }
.su-float-badge:nth-child(4) { top: 60%; right: -25px; animation-delay: 2.1s; }
@keyframes su-float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
.su-badge-icon { width: 28px; height: 28px; border-radius: 6px; display: flex; align-items: center; justify-content: center; }

@media (max-width:1000px) {
  .su-hero { grid-template-columns: 1fr; padding: 7rem 1.5rem 4rem; }
  .su-float-badge { display: none; }
  .su-orbits { display: none; }
}

/* ═══════════════════════════════════════════════════════════════
   LOGOS — Trusted By
   ═══════════════════════════════════════════════════════════════ */
.su-logos {
  background: var(--su-surface);
  padding: 2.5rem 1.5rem;
  border-top: 1px solid var(--su-border);
  border-bottom: 1px solid var(--su-border);
}
.su-logos-inner {
  max-width: 1100px;
  margin: 0 auto;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-wrap: wrap;
  gap: 3rem;
}
.su-logos-label { font-size: .72rem; color: var(--su-muted); letter-spacing: .15em; text-transform: uppercase; }
.su-logo-item {
  font-family: 'SF Mono', 'Fira Code', monospace;
  font-size: .9rem;
  font-weight: 700;
  color: var(--su-muted);
  letter-spacing: .05em;
  opacity: .6;
  transition: opacity .2s;
}
.su-logo-item:hover { opacity: 1; color: var(--su-title); }

/* ═══════════════════════════════════════════════════════════════
   FEATURES — Product Capabilities
   ═══════════════════════════════════════════════════════════════ */
.su-features { background: var(--su-bg); }
.su-features-head { text-align: center; margin-bottom: 4rem; }
.su-features-head h2 { font-size: clamp(2rem, 4vw, 3rem); font-weight: 800; color: var(--su-title); letter-spacing: -.02em; margin-bottom: 1rem; }
.su-features-head p  { color: var(--su-text); max-width: 560px; margin: 0 auto; line-height: 1.75; }

.su-feature-card {
  background: var(--su-card);
  border: 1px solid var(--su-border);
  border-radius: 16px;
  padding: 2rem;
  position: relative;
  overflow: hidden;
  transition: transform .3s, border-color .3s;
}
.su-feature-card:hover { transform: translateY(-5px); border-color: rgba(99,102,241,.45); }
.su-feature-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 2px;
  background: linear-gradient(90deg, var(--su-electric), var(--su-cyan));
  opacity: 0;
  transition: opacity .3s;
}
.su-feature-card:hover::before { opacity: 1; }
.su-feature-icon {
  width: 48px;
  height: 48px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 1.25rem;
}
.su-feature-icon-e { background: rgba(99,102,241,.15); border: 1px solid rgba(99,102,241,.2); }
.su-feature-icon-c { background: rgba(6,182,212,.12); border: 1px solid rgba(6,182,212,.2); }
.su-feature-icon-g { background: rgba(16,185,129,.12); border: 1px solid rgba(16,185,129,.2); }
.su-feature-card h3 { font-size: 1.1rem; font-weight: 700; color: var(--su-title); margin-bottom: .75rem; }
.su-feature-card p  { font-size: .9rem; color: var(--su-text); line-height: 1.7; }

/* ═══════════════════════════════════════════════════════════════
   PRODUCT DEMO — Split visual
   ═══════════════════════════════════════════════════════════════ */
.su-demo { background: var(--su-surface); border-top: 1px solid var(--su-border); border-bottom: 1px solid var(--su-border); }

.su-dashboard-mockup {
  background: var(--su-bg);
  border: 1px solid var(--su-border);
  border-radius: 14px;
  overflow: hidden;
  box-shadow: var(--su-shadow);
}
.su-dashboard-topbar {
  background: var(--su-surface);
  padding: .875rem 1.25rem;
  display: flex;
  align-items: center;
  gap: 1rem;
  border-bottom: 1px solid var(--su-border);
}
.su-dashboard-tab {
  font-size: .75rem;
  color: var(--su-muted);
  padding: .3rem .8rem;
  border-radius: 6px;
  cursor: default;
}
.su-dashboard-tab.active {
  background: rgba(99,102,241,.15);
  color: var(--su-electric-lt);
}
.su-dashboard-body { padding: 1.5rem; }

/* Mini chart */
.su-mini-chart {
  height: 120px;
  display: flex;
  align-items: flex-end;
  gap: 6px;
  margin-bottom: 1.5rem;
}
.su-bar {
  flex: 1;
  border-radius: 4px 4px 0 0;
  background: linear-gradient(to top, var(--su-electric), var(--su-cyan));
  opacity: .7;
  transition: opacity .2s;
}
.su-bar:hover { opacity: 1; }
<?php
$su_bars = [35,55,40,70,65,90,78,92,82,100,88,96];
foreach ( $su_bars as $i => $h ) {
  echo ".su-bar:nth-child(" . ($i+1) . "){height:{$h}%;}\n";
}
?>

/* Metric cards */
.su-metrics { display: grid; grid-template-columns: repeat(3,1fr); gap: 1rem; margin-bottom: 1.25rem; }
.su-metric-card {
  background: var(--su-card);
  border: 1px solid var(--su-border);
  border-radius: 10px;
  padding: 1rem;
}
.su-metric-label { font-size: .68rem; color: var(--su-muted); letter-spacing: .08em; text-transform: uppercase; margin-bottom: .4rem; }
.su-metric-value { font-size: 1.4rem; font-weight: 700; color: var(--su-title); }
.su-metric-delta { font-size: .7rem; color: var(--su-green); }

/* Activity feed */
.su-activity { display: flex; flex-direction: column; gap: .6rem; }
.su-activity-row {
  display: flex;
  align-items: center;
  gap: .75rem;
  font-size: .78rem;
  color: var(--su-muted);
}
.su-activity-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  flex-shrink: 0;
}
.su-activity-dot.green { background: var(--su-green); }
.su-activity-dot.blue  { background: var(--su-electric); }
.su-activity-dot.cyan  { background: var(--su-cyan); }
.su-activity-time { margin-left: auto; font-size: .68rem; white-space: nowrap; }

.su-demo-content h2 { font-size: clamp(1.8rem, 3.5vw, 2.8rem); font-weight: 800; color: var(--su-title); letter-spacing: -.02em; margin-bottom: 1.25rem; }
.su-demo-content p  { color: var(--su-text); line-height: 1.75; margin-bottom: 1rem; font-size: .95rem; }

.su-check-list { list-style: none; padding: 0; margin: 1.5rem 0 2rem; display: flex; flex-direction: column; gap: .75rem; }
.su-check-list li {
  display: flex;
  align-items: flex-start;
  gap: .75rem;
  font-size: .92rem;
  color: var(--su-text);
}
.su-check-icon {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: rgba(16,185,129,.15);
  border: 1px solid rgba(16,185,129,.25);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  margin-top: .1rem;
}
.su-check-icon svg { stroke: var(--su-green); }

/* ═══════════════════════════════════════════════════════════════
   STATS — Numbers that matter
   ═══════════════════════════════════════════════════════════════ */
.su-stats { background: var(--su-bg); }
.su-stats-grid {
  display: grid;
  grid-template-columns: repeat(4,1fr);
  gap: 2rem;
  text-align: center;
}
.su-stat-card {
  padding: 2.5rem 1.5rem;
  border: 1px solid var(--su-border);
  border-radius: 16px;
  background: var(--su-card);
  position: relative;
  overflow: hidden;
}
.su-stat-card::before {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 60%;
  height: 1px;
  background: linear-gradient(90deg, transparent, var(--su-electric), transparent);
}
.su-stat-num {
  font-size: 3rem;
  font-weight: 800;
  letter-spacing: -.03em;
  line-height: 1;
  margin-bottom: .5rem;
}
.su-stat-label { font-size: .82rem; color: var(--su-muted); }
@media(max-width:700px){ .su-stats-grid{grid-template-columns:1fr 1fr;} }

/* ═══════════════════════════════════════════════════════════════
   HOW IT WORKS — Process steps
   ═══════════════════════════════════════════════════════════════ */
.su-how { background: var(--su-surface); border-top: 1px solid var(--su-border); border-bottom: 1px solid var(--su-border); }
.su-how-head { text-align: center; margin-bottom: 4rem; }
.su-how-head h2 { font-size: clamp(2rem, 4vw, 3rem); font-weight: 800; color: var(--su-title); letter-spacing: -.02em; }

.su-steps-grid {
  display: grid;
  grid-template-columns: repeat(4,1fr);
  gap: 0;
  position: relative;
}
/* Connector line */
.su-steps-grid::before {
  content: '';
  position: absolute;
  top: 32px;
  left: 12.5%;
  width: 75%;
  height: 1px;
  background: linear-gradient(90deg, var(--su-electric), var(--su-cyan));
  opacity: .3;
}
.su-step { text-align: center; padding: 1.5rem; position: relative; }
.su-step-num {
  width: 64px;
  height: 64px;
  border-radius: 50%;
  background: var(--su-card);
  border: 2px solid var(--su-electric);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.1rem;
  font-weight: 800;
  color: var(--su-electric-lt);
  margin: 0 auto 1.25rem;
  position: relative;
  z-index: 1;
  box-shadow: 0 0 20px rgba(99,102,241,.2);
}
.su-step:nth-child(2) .su-step-num { border-color: var(--su-cyan); color: var(--su-cyan); box-shadow: 0 0 20px rgba(6,182,212,.2); }
.su-step:nth-child(3) .su-step-num { border-color: var(--su-green); color: var(--su-green); box-shadow: 0 0 20px rgba(16,185,129,.2); }
.su-step:nth-child(4) .su-step-num { border-color: var(--su-electric-lt); color: var(--su-electric-lt); }
.su-step h3 { font-size: 1rem; font-weight: 700; color: var(--su-title); margin-bottom: .6rem; }
.su-step p  { font-size: .85rem; color: var(--su-muted); line-height: 1.65; }

@media(max-width:800px){ .su-steps-grid{grid-template-columns:1fr 1fr;} .su-steps-grid::before{display:none;} }
@media(max-width:500px){ .su-steps-grid{grid-template-columns:1fr;} }

/* ═══════════════════════════════════════════════════════════════
   PRICING
   ═══════════════════════════════════════════════════════════════ */
.su-pricing { background: var(--su-bg); }
.su-pricing-head { text-align: center; margin-bottom: 1rem; }
.su-pricing-head h2 { font-size: clamp(2rem, 4vw, 3rem); font-weight: 800; color: var(--su-title); letter-spacing: -.02em; }
.su-pricing-toggle {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  margin: 1.5rem 0 3rem;
  font-size: .88rem;
  color: var(--su-muted);
}
.su-toggle-pill {
  position: relative;
  width: 52px;
  height: 28px;
  background: rgba(99,102,241,.2);
  border: 1px solid rgba(99,102,241,.3);
  border-radius: 50px;
  cursor: pointer;
}
.su-toggle-pill::after {
  content: '';
  position: absolute;
  top: 3px;
  left: 3px;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: linear-gradient(135deg, var(--su-electric), var(--su-cyan));
  transition: left .25s;
}
.su-pricing-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 1.5rem; }

.su-price-card {
  background: var(--su-card);
  border: 1px solid var(--su-border);
  border-radius: 20px;
  padding: 2.5rem 2rem;
  display: flex;
  flex-direction: column;
  position: relative;
  overflow: hidden;
  transition: transform .3s, border-color .3s;
}
.su-price-card:hover { transform: translateY(-6px); }
.su-price-card--pop {
  border-color: var(--su-electric);
  background: linear-gradient(160deg, rgba(99,102,241,.08) 0%, var(--su-card) 60%);
}
.su-price-card--pop::before {
  content: 'Most Popular';
  position: absolute;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  background: linear-gradient(90deg, var(--su-electric), var(--su-cyan));
  color: #fff;
  font-size: .65rem;
  font-weight: 700;
  letter-spacing: .1em;
  text-transform: uppercase;
  padding: .3rem 1.25rem;
  border-radius: 0 0 8px 8px;
}
.su-price-name { font-size: .72rem; letter-spacing: .2em; text-transform: uppercase; color: var(--su-muted); margin-bottom: .5rem; margin-top: 1rem; }
.su-price-title { font-size: 1.4rem; font-weight: 700; color: var(--su-title); margin-bottom: 1.25rem; }
.su-price-amount { display: flex; align-items: flex-end; gap: .2rem; margin-bottom: .35rem; }
.su-price-currency { font-size: 1.2rem; color: var(--su-muted); margin-bottom: .35rem; }
.su-price-value { font-size: 3.2rem; font-weight: 800; color: var(--su-title); line-height: 1; }
.su-price-period { font-size: .82rem; color: var(--su-muted); }
.su-price-desc { font-size: .85rem; color: var(--su-muted); margin: 1rem 0; padding: 1rem 0; border-top: 1px solid var(--su-border); border-bottom: 1px solid var(--su-border); line-height: 1.6; }
.su-price-features { list-style: none; padding: 0; margin: 0; flex: 1; display: flex; flex-direction: column; gap: .6rem; }
.su-price-features li { display: flex; align-items: flex-start; gap: .6rem; font-size: .86rem; color: var(--su-text); }
.su-price-features li::before { content: '✓'; color: var(--su-green); font-weight: 700; font-size: .8rem; margin-top: .1rem; }
.su-price-features li.su-no::before { content: '✗'; color: var(--su-muted); font-weight: 700; }
.su-price-features li.su-no { color: var(--su-muted); }
.su-price-cta { margin-top: 2rem; }
.su-price-cta a { display: block; text-align: center; }

@media(max-width:800px){ .su-pricing-grid{grid-template-columns:1fr;} }

/* ═══════════════════════════════════════════════════════════════
   TESTIMONIALS
   ═══════════════════════════════════════════════════════════════ */
.su-testi { background: var(--su-surface); border-top: 1px solid var(--su-border); border-bottom: 1px solid var(--su-border); }
.su-testi-head { text-align: center; margin-bottom: 3rem; }
.su-testi-head h2 { font-size: clamp(2rem, 4vw, 3rem); font-weight: 800; color: var(--su-title); letter-spacing: -.02em; }

.su-testi-card {
  background: var(--su-card);
  border: 1px solid var(--su-border);
  border-radius: 16px;
  padding: 2rem;
}
.su-testi-stars { color: #fbbf24; font-size: .9rem; margin-bottom: 1rem; letter-spacing: .05em; }
.su-testi-text { color: var(--su-text); line-height: 1.8; font-size: .93rem; margin-bottom: 1.5rem; }
.su-testi-author { display: flex; align-items: center; gap: .75rem; }
.su-testi-avatar { width: 40px; height: 40px; border-radius: 50%; overflow: hidden; border: 1.5px solid var(--su-border); }
.su-testi-avatar-inner { width: 100%; height: 100%; }
.su-testi-card:nth-child(1) .su-testi-avatar-inner { background: linear-gradient(135deg, var(--su-electric), #8b5cf6); }
.su-testi-card:nth-child(2) .su-testi-avatar-inner { background: linear-gradient(135deg, var(--su-cyan), #0ea5e9); }
.su-testi-card:nth-child(3) .su-testi-avatar-inner { background: linear-gradient(135deg, var(--su-green), #059669); }
.su-testi-name  { font-weight: 700; color: var(--su-title); font-size: .9rem; }
.su-testi-role  { font-size: .75rem; color: var(--su-muted); }

/* ═══════════════════════════════════════════════════════════════
   TECH STACK — Integration logos (CSS only)
   ═══════════════════════════════════════════════════════════════ */
.su-integrations { background: var(--su-bg); }
.su-integrations-head { text-align: center; margin-bottom: 3rem; }
.su-integrations-head h2 { font-size: clamp(1.8rem, 3.5vw, 2.5rem); font-weight: 800; color: var(--su-title); letter-spacing: -.02em; }
.su-integrations-head p  { color: var(--su-muted); margin-top: .75rem; }

.su-integrations-grid {
  display: grid;
  grid-template-columns: repeat(6,1fr);
  gap: 1rem;
}
.su-integration-tile {
  background: var(--su-card);
  border: 1px solid var(--su-border);
  border-radius: 14px;
  padding: 1.5rem 1rem;
  text-align: center;
  transition: transform .25s, border-color .25s;
  cursor: default;
}
.su-integration-tile:hover { transform: translateY(-4px); border-color: rgba(99,102,241,.4); }
.su-integration-logo {
  width: 44px;
  height: 44px;
  border-radius: 10px;
  margin: 0 auto .75rem;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: .7rem;
  font-weight: 800;
  font-family: monospace;
  letter-spacing: -.05em;
}
.su-integration-name { font-size: .75rem; color: var(--su-muted); }

@media(max-width:800px){ .su-integrations-grid{grid-template-columns:repeat(3,1fr);} }
@media(max-width:500px){ .su-integrations-grid{grid-template-columns:repeat(2,1fr);} }

/* ═══════════════════════════════════════════════════════════════
   FAQ
   ═══════════════════════════════════════════════════════════════ */
.su-faq { background: var(--su-surface); border-top: 1px solid var(--su-border); }
.su-faq-inner { max-width: 740px; margin: 0 auto; }
.su-faq-head  { text-align: center; margin-bottom: 3rem; }
.su-faq-head h2 { font-size: clamp(1.8rem, 3.5vw, 2.5rem); font-weight: 800; color: var(--su-title); letter-spacing: -.02em; }
.su-faq-item  { border-bottom: 1px solid var(--su-border); }
.su-faq-q {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 1.25rem 0;
  font-size: .95rem;
  color: var(--su-title);
  background: none;
  border: none;
  cursor: pointer;
  text-align: left;
  font-weight: 500;
}
.su-faq-q:hover { color: var(--su-electric-lt); }
.su-faq-chevron {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  border: 1px solid var(--su-border);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  transition: transform .3s, border-color .2s;
}
.su-faq-item.open .su-faq-chevron { transform: rotate(45deg); border-color: var(--su-electric); }
.su-faq-a { max-height: 0; overflow: hidden; transition: max-height .35s ease; }
.su-faq-a p { padding: 0 0 1.25rem; color: var(--su-muted); line-height: 1.8; font-size: .9rem; }
.su-faq-item.open .su-faq-a { max-height: 300px; }

/* ═══════════════════════════════════════════════════════════════
   CTA — Final
   ═══════════════════════════════════════════════════════════════ */
.su-cta {
  background: var(--su-bg);
  padding: 7rem 1.5rem;
  text-align: center;
  position: relative;
  overflow: hidden;
}
.su-cta::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(ellipse 70% 60% at 50% 50%, rgba(99,102,241,.08) 0%, transparent 70%);
}
/* Grid border on CTA box */
.su-cta-box {
  max-width: 700px;
  margin: 0 auto;
  background: var(--su-card);
  border: 1px solid var(--su-border);
  border-radius: 24px;
  padding: 4rem 3rem;
  position: relative;
  overflow: hidden;
}
.su-cta-box::before {
  content: '';
  position: absolute;
  inset: -1px;
  border-radius: 24px;
  background: linear-gradient(135deg, var(--su-electric), var(--su-cyan));
  z-index: -1;
  opacity: .35;
}
.su-cta-box h2 { font-size: clamp(1.8rem, 4vw, 2.8rem); font-weight: 800; color: var(--su-title); letter-spacing: -.02em; margin-bottom: 1rem; }
.su-cta-box p  { color: var(--su-text); font-size: 1rem; max-width: 480px; margin: 0 auto 2rem; line-height: 1.75; }
.su-cta-actions { display: flex; justify-content: center; gap: 1rem; flex-wrap: wrap; }
.su-cta-note { margin-top: 1.5rem; font-size: .78rem; color: var(--su-muted); }
</style>

<div class="tf-startup-page">

  <!-- ─── HERO ─────────────────────────────────────────────────── -->
  <section class="su-hero" aria-label="<?php esc_attr_e('Hero','themeflex'); ?>">

    <!-- Orbit decoration -->
    <div class="su-orbits" aria-hidden="true">
      <div class="su-orbit"><div class="su-orbit-dot"></div></div>
      <div class="su-orbit"><div class="su-orbit-dot"></div></div>
      <div class="su-orbit"><div class="su-orbit-dot"></div></div>
    </div>

    <!-- Left: copy -->
    <div class="su-hero-text">
      <div class="su-hero-badge" role="note">
        <div class="su-hero-badge-dot" aria-hidden="true"></div>
        <?php esc_html_e( 'Now in Public Beta — Free to start', 'themeflex' ); ?>
      </div>

      <h1 class="su-hero-title">
        Ship<br>
        <span class="su-gradient-text">10× Faster</span><br>
        with AI-Powered<br>Infrastructure
      </h1>

      <p class="su-hero-desc">
        NovaDeploy is the developer platform that automates infrastructure, scales automatically, and ships code from commit to production in under 60 seconds.
      </p>

      <div class="su-hero-actions">
        <a href="<?php echo esc_url( home_url( '/signup' ) ); ?>" class="su-btn-primary">
          <?php echo tf_icon_get('zap', 18, 18); ?>
          <?php esc_html_e( 'Start Building Free', 'themeflex' ); ?>
        </a>
        <a href="<?php echo esc_url( home_url( '/demo' ) ); ?>" class="su-btn-ghost">
          <?php echo tf_icon_get('play-circle', 18, 18); ?>
          <?php esc_html_e( 'Watch Demo', 'themeflex' ); ?>
        </a>
      </div>

      <div class="su-hero-social-proof">
        <div class="su-avatar-stack" aria-label="<?php esc_attr_e('Team photos','themeflex'); ?>">
          <?php for ( $i = 0; $i < 4; $i++ ) : ?>
          <div class="su-avatar" aria-hidden="true"><div class="su-avatar-inner"></div></div>
          <?php endfor; ?>
        </div>
        <div class="su-social-text">
          <div class="su-stars-mini" aria-label="5 stars">★★★★★</div>
          Trusted by <strong>50,000+</strong> developers worldwide
        </div>
      </div>
    </div>

    <!-- Right: Terminal -->
    <div class="su-terminal-wrap">

      <div class="su-float-badge" aria-hidden="true">
        <div class="su-badge-icon" style="background:rgba(16,185,129,.15);">
          <?php echo tf_icon_get('check-circle', 16, 16, 'stroke:#10b981'); ?>
        </div>
        Deployed in 43s
      </div>
      <div class="su-float-badge" aria-hidden="true">
        <div class="su-badge-icon" style="background:rgba(99,102,241,.15);">
          <?php echo tf_icon_get('trending-up', 16, 16, 'stroke:#818cf8'); ?>
        </div>
        Latency ↓ 68%
      </div>
      <div class="su-float-badge" aria-hidden="true">
        <div class="su-badge-icon" style="background:rgba(6,182,212,.15);">
          <?php echo tf_icon_get('shield', 16, 16, 'stroke:#06b6d4'); ?>
        </div>
        SOC 2 Type II
      </div>

      <div class="su-terminal" role="img" aria-label="<?php esc_attr_e('Terminal showing deployment output','themeflex'); ?>">
        <div class="su-terminal-bar" aria-hidden="true">
          <div class="su-terminal-dot"></div>
          <div class="su-terminal-dot"></div>
          <div class="su-terminal-dot"></div>
          <div class="su-terminal-title">novadeploy — production</div>
        </div>
        <div class="su-terminal-body" aria-hidden="true">
          <div><span class="su-terminal-prompt">$</span> <span class="su-terminal-cmd">nova deploy --env production</span></div>
          <div class="su-terminal-output">  Analysing project structure...</div>
          <div class="su-terminal-output">  <span class="su-terminal-key">✓</span> Detected: <span class="su-terminal-str">Next.js 15 + Prisma + Redis</span></div>
          <div class="su-terminal-output">  Building Docker image...</div>
          <div class="su-terminal-output">  <span class="su-terminal-key">✓</span> Build completed in <span class="su-terminal-num">18.4s</span></div>
          <div class="su-terminal-output">  Running test suite... (<span class="su-terminal-num">247</span> tests)</div>
          <div class="su-terminal-output">  <span class="su-terminal-key">✓</span> All tests passed</div>
          <div class="su-terminal-output">  Provisioning edge nodes...</div>
          <div class="su-terminal-output">  <span class="su-terminal-key">✓</span> Nodes: <span class="su-terminal-str">us-east-1</span>, <span class="su-terminal-str">eu-west-1</span>, <span class="su-terminal-str">ap-south-1</span></div>
          <div class="su-terminal-output">  Rolling deployment (canary 10%→25%→100%)</div>
          <div class="su-terminal-comment">  <span style="color:var(--su-green)">✓ DEPLOYED</span> → https://app.example.com</div>
          <div class="su-terminal-comment">  Total time: <span class="su-terminal-num">43.2s</span> <span class="su-terminal-comment">// prev: 8m 41s</span></div>
          <div>&nbsp;</div>
          <div><span class="su-terminal-prompt">$</span> <span class="su-terminal-cursor"></span></div>
        </div>
      </div>
    </div>
  </section>

  <!-- ─── TRUSTED BY ────────────────────────────────────────────── -->
  <div class="su-logos">
    <div class="su-logos-inner">
      <span class="su-logos-label">Trusted by engineering teams at</span>
      <?php
      $su_logos = ['STRIPE', 'LINEAR', 'VERCEL', 'FIGMA', 'NOTION', 'LOOM', 'RETOOL'];
      foreach ( $su_logos as $logo ) :
      ?>
      <div class="su-logo-item"><?php echo esc_html( $logo ); ?></div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- ─── FEATURES ─────────────────────────────────────────────── -->
  <section class="su-section su-features">
    <div class="su-container">
      <div class="su-features-head">
        <p class="su-eyebrow">Product</p>
        <h2>Everything Your Team<br>Needs to Move Fast</h2>
        <p>Stop wrestling with infrastructure. NovaDeploy handles orchestration, scaling, and observability so engineers can focus on code.</p>
      </div>
      <div class="su-grid-3">
        <?php
        $su_features = [
          [ 'zap',       'su-feature-icon-e', 'electric', 'Zero-Config Deploys',       'Push to git. We detect your framework, build it, and deploy to a global edge network automatically.' ],
          [ 'git-branch','su-feature-icon-c', 'cyan',     'Preview Environments',       'Every pull request gets a unique URL. Review changes in production-identical environments before merging.' ],
          [ 'shield',    'su-feature-icon-g', 'green',    'Built-in Security',          'SOC 2 Type II, automatic TLS, DDoS protection, and secret management — no configuration required.' ],
          [ 'bar-chart', 'su-feature-icon-e', 'electric', 'Real-time Observability',   'Logs, metrics, traces, and alerts unified in one dashboard. Find issues in seconds, not hours.' ],
          [ 'globe',     'su-feature-icon-c', 'cyan',     'Global Edge Network',        'Deploy to 40+ regions with automatic geo-routing. P99 latency under 20ms for any user, anywhere.' ],
          [ 'cpu',       'su-feature-icon-g', 'green',    'Auto-scaling Infrastructure','Scale from zero to millions of requests without touching a config file. Pay only for what you use.' ],
        ];
        foreach ( $su_features as $feat ) :
          $stroke_color = $feat[2] === 'electric' ? 'var(--su-electric-lt)' : ( $feat[2] === 'cyan' ? 'var(--su-cyan)' : 'var(--su-green)' );
        ?>
        <article class="su-feature-card">
          <div class="su-feature-icon <?php echo esc_attr( $feat[1] ); ?>" aria-hidden="true">
            <?php echo tf_icon_get( $feat[0], 22, 22, "stroke:{$stroke_color}" ); ?>
          </div>
          <h3><?php echo esc_html( $feat[3] ); ?></h3>
          <p><?php echo esc_html( $feat[4] ); ?></p>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ─── PRODUCT DEMO ─────────────────────────────────────────── -->
  <section class="su-section su-demo">
    <div class="su-container">
      <div class="su-grid-2">

        <!-- Dashboard mockup -->
        <div class="su-dashboard-mockup" role="img" aria-label="<?php esc_attr_e('Product dashboard preview','themeflex'); ?>">
          <div class="su-dashboard-topbar" aria-hidden="true">
            <div class="su-dashboard-tab active">Overview</div>
            <div class="su-dashboard-tab">Deployments</div>
            <div class="su-dashboard-tab">Analytics</div>
            <div class="su-dashboard-tab">Logs</div>
          </div>
          <div class="su-dashboard-body" aria-hidden="true">
            <!-- Metrics -->
            <div class="su-metrics">
              <div class="su-metric-card">
                <div class="su-metric-label">Requests / min</div>
                <div class="su-metric-value" data-counter="84219">84,219</div>
                <div class="su-metric-delta">↑ 12.4%</div>
              </div>
              <div class="su-metric-card">
                <div class="su-metric-label">P99 Latency</div>
                <div class="su-metric-value">18ms</div>
                <div class="su-metric-delta">↓ 8ms</div>
              </div>
              <div class="su-metric-card">
                <div class="su-metric-label">Uptime</div>
                <div class="su-metric-value">99.99%</div>
                <div class="su-metric-delta" style="color:var(--su-cyan)">◆ SLA</div>
              </div>
            </div>
            <!-- Chart -->
            <div class="su-mini-chart" aria-hidden="true">
              <?php for ( $i = 0; $i < 12; $i++ ) : ?>
              <div class="su-bar"></div>
              <?php endfor; ?>
            </div>
            <!-- Activity -->
            <div class="su-activity">
              <?php
              $su_activities = [
                [ 'green', 'Deploy: v2.4.1 → production', '12s ago' ],
                [ 'blue',  'Auto-scaled: 4 → 8 instances', '3m ago' ],
                [ 'cyan',  'Cache warmed: us-east-1', '5m ago' ],
                [ 'green', 'Health check: all 40 regions OK', '11m ago' ],
              ];
              foreach ( $su_activities as $act ) :
              ?>
              <div class="su-activity-row">
                <div class="su-activity-dot <?php echo esc_attr( $act[0] ); ?>"></div>
                <span><?php echo esc_html( $act[1] ); ?></span>
                <span class="su-activity-time"><?php echo esc_html( $act[2] ); ?></span>
              </div>
              <?php endforeach; ?>
            </div>
          </div>
        </div>

        <!-- Copy -->
        <div class="su-demo-content">
          <p class="su-eyebrow">Observability</p>
          <h2>Every Deployment.<br>Every Metric.<br>One Dashboard.</h2>
          <p>Stop switching between five tools to understand your production system. NovaDeploy consolidates logs, metrics, traces, and deployment history into a single, fast interface.</p>
          <ul class="su-check-list">
            <?php
            $su_checks = [
              'Real-time log streaming with full-text search',
              'Distributed tracing across every microservice',
              'Smart alerting with noise reduction',
              'Automated incident runbooks',
              'Cost attribution per service and team',
            ];
            foreach ( $su_checks as $check ) :
            ?>
            <li>
              <div class="su-check-icon" aria-hidden="true">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
              </div>
              <?php echo esc_html( $check ); ?>
            </li>
            <?php endforeach; ?>
          </ul>
          <a href="<?php echo esc_url( home_url( '/product' ) ); ?>" class="su-btn-primary">
            <?php echo tf_icon_get('arrow-right', 18, 18); ?>
            Explore the Platform
          </a>
        </div>

      </div>
    </div>
  </section>

  <!-- ─── STATS ─────────────────────────────────────────────────── -->
  <section class="su-section su-stats">
    <div class="su-container">
      <div class="su-stats-grid">
        <?php
        $su_stats = [
          [ '50K',   '+',  'Developers',          '--su-electric-lt' ],
          [ '2.4B',  '+',  'Deploys Processed',   '--su-cyan' ],
          [ '99.99', '%',  'Uptime SLA',           '--su-green' ],
          [ '43',    's',  'Avg. Deploy Time',     '--su-electric-lt' ],
        ];
        foreach ( $su_stats as $stat ) :
        ?>
        <div class="su-stat-card">
          <div class="su-stat-num su-gradient-text" data-counter="<?php echo esc_attr( preg_replace('/[^0-9.]/','',$stat[0]) ); ?>" data-suffix="<?php echo esc_attr( $stat[1] ); ?>">
            <?php echo esc_html( $stat[0] . $stat[1] ); ?>
          </div>
          <div class="su-stat-label"><?php echo esc_html( $stat[2] ); ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ─── HOW IT WORKS ─────────────────────────────────────────── -->
  <section class="su-section su-how">
    <div class="su-container">
      <div class="su-how-head">
        <p class="su-eyebrow">Process</p>
        <h2>From Zero to Production<br>in Four Steps</h2>
      </div>
      <div class="su-steps-grid">
        <?php
        $su_steps = [
          [ '01', 'Connect Repo',      'Link your GitHub, GitLab, or Bitbucket repository in under 60 seconds.', 'git-branch' ],
          [ '02', 'Auto-Detect Stack', 'We analyse your code and configure the optimal build and runtime settings.', 'cpu' ],
          [ '03', 'Deploy to Edge',    'Your app is built, tested, and deployed to 40+ global regions automatically.', 'globe' ],
          [ '04', 'Monitor & Scale',   'Observe performance and let auto-scaling handle traffic spikes without manual intervention.', 'bar-chart' ],
        ];
        foreach ( $su_steps as $step ) :
        ?>
        <div class="su-step">
          <div class="su-step-num" aria-hidden="true"><?php echo esc_html( $step[0] ); ?></div>
          <h3><?php echo esc_html( $step[1] ); ?></h3>
          <p><?php echo esc_html( $step[2] ); ?></p>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ─── TESTIMONIALS ─────────────────────────────────────────── -->
  <section class="su-section su-testi">
    <div class="su-container">
      <div class="su-testi-head">
        <p class="su-eyebrow">Social Proof</p>
        <h2>Loved by Engineering Teams</h2>
      </div>
      <div class="su-grid-3">
        <?php
        $su_testis = [
          [
            '"We cut our deployment pipeline from 12 minutes to 41 seconds. Our engineers now ship 3× more often without any anxiety about production."',
            'Alex Kim',
            'CTO at Paycycle',
          ],
          [
            '"The preview environment feature alone saves us 4 hours of QA coordination per sprint. We can\'t imagine going back to our old workflow."',
            'Sarah Chen',
            'VP Engineering at Flowtrace',
          ],
          [
            '"NovaDeploy\'s observability dashboard replaced three separate tools for us. The signal-to-noise ratio of the alerts is genuinely excellent."',
            'Marcus Hofer',
            'Head of Platform at Clarifai',
          ],
        ];
        foreach ( $su_testis as $testi ) :
        ?>
        <article class="su-testi-card">
          <div class="su-testi-stars" aria-label="5 stars">★★★★★</div>
          <p class="su-testi-text"><?php echo esc_html( $testi[0] ); ?></p>
          <div class="su-testi-author">
            <div class="su-testi-avatar" aria-hidden="true"><div class="su-testi-avatar-inner"></div></div>
            <div>
              <div class="su-testi-name"><?php echo esc_html( $testi[1] ); ?></div>
              <div class="su-testi-role"><?php echo esc_html( $testi[2] ); ?></div>
            </div>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ─── PRICING ──────────────────────────────────────────────── -->
  <section class="su-section su-pricing">
    <div class="su-container">
      <div class="su-pricing-head">
        <p class="su-eyebrow">Pricing</p>
        <h2>Simple, Transparent Pricing</h2>
        <div class="su-pricing-toggle" aria-hidden="true">
          <span>Monthly</span>
          <div class="su-toggle-pill" role="switch" aria-checked="false"></div>
          <span>Annual <span style="color:var(--su-green);font-size:.75rem;font-weight:700;">Save 20%</span></span>
        </div>
      </div>
      <div class="su-pricing-grid">

        <!-- Hobby -->
        <article class="su-price-card">
          <div class="su-price-name">Hobby</div>
          <div class="su-price-title">Starter</div>
          <div class="su-price-amount">
            <span class="su-price-currency">$</span>
            <span class="su-price-value">0</span>
          </div>
          <div class="su-price-period">Forever free</div>
          <p class="su-price-desc">Perfect for side projects, prototypes, and learning NovaDeploy.</p>
          <ul class="su-price-features">
            <li>3 Projects</li>
            <li>100 Deploys/month</li>
            <li>Shared compute</li>
            <li>Community support</li>
            <li class="su-no">Preview environments</li>
            <li class="su-no">Custom domains</li>
            <li class="su-no">SLA guarantee</li>
          </ul>
          <div class="su-price-cta">
            <a href="<?php echo esc_url( home_url( '/signup' ) ); ?>" class="su-btn-ghost">Get Started Free</a>
          </div>
        </article>

        <!-- Pro — popular -->
        <article class="su-price-card su-price-card--pop">
          <div class="su-price-name">Pro</div>
          <div class="su-price-title">Growth</div>
          <div class="su-price-amount">
            <span class="su-price-currency">$</span>
            <span class="su-price-value" data-counter="49">49</span>
          </div>
          <div class="su-price-period">per month, per team</div>
          <p class="su-price-desc">For growing teams shipping features to real users.</p>
          <ul class="su-price-features">
            <li>Unlimited Projects</li>
            <li>Unlimited Deploys</li>
            <li>Dedicated compute</li>
            <li>Preview Environments</li>
            <li>Custom Domains + SSL</li>
            <li>Email support (4h SLA)</li>
            <li class="su-no">Dedicated infrastructure</li>
          </ul>
          <div class="su-price-cta">
            <a href="<?php echo esc_url( home_url( '/signup' ) ); ?>" class="su-btn-primary">Start Pro Trial</a>
          </div>
        </article>

        <!-- Enterprise -->
        <article class="su-price-card">
          <div class="su-price-name">Enterprise</div>
          <div class="su-price-title">Scale</div>
          <div class="su-price-amount">
            <span class="su-price-value" style="font-size:2.4rem;">Custom</span>
          </div>
          <div class="su-price-period">Volume discounts available</div>
          <p class="su-price-desc">For organizations demanding SLAs, compliance, and dedicated support.</p>
          <ul class="su-price-features">
            <li>Everything in Pro</li>
            <li>Dedicated Infrastructure</li>
            <li>SOC 2 / HIPAA compliance</li>
            <li>SAML SSO + SCIM</li>
            <li>99.99% Uptime SLA</li>
            <li>24/7 Phone + Slack support</li>
            <li>Custom contract &amp; invoicing</li>
          </ul>
          <div class="su-price-cta">
            <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>" class="su-btn-ghost">Talk to Sales</a>
          </div>
        </article>

      </div>
    </div>
  </section>

  <!-- ─── INTEGRATIONS ─────────────────────────────────────────── -->
  <section class="su-section su-integrations">
    <div class="su-container">
      <div class="su-integrations-head">
        <p class="su-eyebrow">Integrations</p>
        <h2>Plays Well With<br>Your Stack</h2>
        <p>Connect the tools your team already uses — no disruption to existing workflows.</p>
      </div>
      <div class="su-integrations-grid">
        <?php
        $su_integrations = [
          [ 'GH',  '#24292f', '#fff',     'GitHub' ],
          [ 'GL',  '#fc6d26', '#fff',     'GitLab' ],
          [ 'BB',  '#0052cc', '#fff',     'Bitbucket' ],
          [ 'SL',  '#4a154b', '#fff',     'Slack' ],
          [ 'PD',  '#06ac38', '#fff',     'PagerDuty' ],
          [ 'DD',  '#632ca6', '#fff',     'Datadog' ],
          [ 'TF',  '#7b42bc', '#fff',     'Terraform' ],
          [ 'K8',  '#326ce5', '#fff',     'Kubernetes' ],
          [ 'PR',  '#1b1f23', '#fff',     'Prometheus' ],
          [ 'GF',  '#f46800', '#fff',     'Grafana' ],
          [ 'LN',  '#e01e5a', '#fff',     'Linear' ],
          [ 'JR',  '#0052cc', '#fff',     'Jira' ],
        ];
        foreach ( $su_integrations as $int ) :
        ?>
        <div class="su-integration-tile">
          <div class="su-integration-logo" style="background:<?php echo esc_attr( $int[0][0] === 'G' ? 'rgba(255,255,255,.05)' : $int[1] ); ?>;color:<?php echo esc_attr( $int[2] ); ?>;border:1px solid rgba(255,255,255,.08);">
            <?php echo esc_html( $int[0] ); ?>
          </div>
          <div class="su-integration-name"><?php echo esc_html( $int[3] ); ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ─── FAQ ──────────────────────────────────────────────────── -->
  <section class="su-section su-faq">
    <div class="su-container">
      <div class="su-faq-inner">
        <div class="su-faq-head">
          <p class="su-eyebrow">FAQ</p>
          <h2>Common Questions</h2>
        </div>
        <?php
        $su_faqs = [
          [ 'Can I migrate from Vercel or Railway?',        'Yes. We provide a one-command migration tool that imports your project configuration, environment variables, and domain settings. Most migrations complete in under 10 minutes.' ],
          [ 'What happens when I hit the free tier limits?','Your deployments continue running. We\'ll notify you when you\'re approaching limits and ask you to upgrade before new deploys are blocked. No surprise shutdowns.' ],
          [ 'Do you support monorepos?',                    'Yes, with first-class support. We auto-detect affected packages and only rebuild and redeploy what changed, making monorepo deployments as fast as single-app ones.' ],
          [ 'Where is my data stored?',                     'Your code runs in the region you select. Build logs and metadata are stored in US-East-1 and EU-West-1. Enterprise plans support single-region data residency.' ],
          [ 'Is there a self-hosted option?',               'NovaDeploy Enterprise includes a Bring-Your-Own-Cloud option to deploy the platform into your own AWS or GCP account, maintaining full control of your infrastructure.' ],
        ];
        foreach ( $su_faqs as $i => $faq ) :
        ?>
        <div class="su-faq-item" id="su-faq-<?php echo $i; ?>">
          <button class="su-faq-q" aria-expanded="false" aria-controls="su-faq-a-<?php echo $i; ?>">
            <span><?php echo esc_html( $faq[0] ); ?></span>
            <span class="su-faq-chevron" aria-hidden="true">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            </span>
          </button>
          <div class="su-faq-a" id="su-faq-a-<?php echo $i; ?>">
            <p><?php echo esc_html( $faq[1] ); ?></p>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ─── CTA ──────────────────────────────────────────────────── -->
  <section class="su-cta">
    <div class="su-cta-box">
      <p class="su-eyebrow" style="justify-content:center;margin-bottom:1rem">Ready to ship faster?</p>
      <h2>Start Deploying in<br>Under 60 Seconds</h2>
      <p>No credit card required. No infrastructure to manage. Just push your code and go.</p>
      <div class="su-cta-actions">
        <a href="<?php echo esc_url( home_url( '/signup' ) ); ?>" class="su-btn-primary">
          <?php echo tf_icon_get('zap', 18, 18); ?>
          Start Free — No Card Needed
        </a>
        <a href="<?php echo esc_url( home_url( '/docs' ) ); ?>" class="su-btn-ghost">
          <?php echo tf_icon_get('book-open', 18, 18); ?>
          Read the Docs
        </a>
      </div>
      <p class="su-cta-note">Free forever up to 3 projects · 100 deploys/month · Community support</p>
    </div>
  </section>

</div><!-- .tf-startup-page -->

<script>
(function() {
  'use strict';

  // ── FAQ accordion ────────────────────────────────────────────
  document.querySelectorAll('.su-faq-q').forEach(function(btn) {
    btn.addEventListener('click', function() {
      var item = btn.closest('.su-faq-item');
      var isOpen = item.classList.contains('open');
      document.querySelectorAll('.su-faq-item').forEach(function(i) {
        i.classList.remove('open');
        i.querySelector('.su-faq-q').setAttribute('aria-expanded', 'false');
      });
      if (!isOpen) {
        item.classList.add('open');
        btn.setAttribute('aria-expanded', 'true');
      }
    });
  });

  // ── Counter animation (shared util) ─────────────────────────
  var counters = document.querySelectorAll('.su-stat-num[data-counter], .su-metric-value[data-counter]');
  if (counters.length && 'IntersectionObserver' in window) {
    var obs = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (!entry.isIntersecting) return;
        var el = entry.target;
        var target = parseFloat(el.dataset.counter.replace(/,/g,''));
        var suffix = el.dataset.suffix || '';
        var duration = 1600;
        var startTime = null;
        var isDecimal = target % 1 !== 0;
        (function tick(ts) {
          if (!startTime) startTime = ts;
          var progress = Math.min((ts - startTime) / duration, 1);
          var ease = 1 - Math.pow(1 - progress, 3);
          var current = target * ease;
          el.textContent = (isDecimal ? current.toFixed(1) : Math.round(current).toLocaleString()) + suffix;
          if (progress < 1) requestAnimationFrame(tick);
        })(performance.now());
        obs.unobserve(el);
      });
    }, { threshold: 0.4 });
    counters.forEach(function(c) { obs.observe(c); });
  }

})();
</script>

<?php get_footer(); ?>
