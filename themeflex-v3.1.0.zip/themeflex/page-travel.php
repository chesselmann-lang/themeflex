<?php
/**
 * Template Name: Travel & Tourism Homepage
 *
 * @package ThemeFlex
 * @version 3.1.0
 */

get_header();
?>
<div class="tf-travel-page">
<style>
/* =========================================================
   ThemeFlex — Travel & Tourism Homepage  v3.1.0
   Accent: #0ea5e9 (sky blue), #f59e0b (amber), #10b981 (emerald)
   BG: #050d18 (deep ocean night)
   ========================================================= */

/* ---------- tokens ---------- */
.tf-travel-page {
  --tr-accent:   #0ea5e9;
  --tr-amber:    #f59e0b;
  --tr-green:    #10b981;
  --tr-bg:       #050d18;
  --tr-bg2:      #0a1628;
  --tr-bg3:      #0f1f3d;
  --tr-border:   rgba(14,165,233,.18);
  --tr-text:     #e2eaf6;
  --tr-muted:    #7a96b8;
  --tr-card:     #0c1930;
  --tr-radius:   14px;
  background: var(--tr-bg);
  color: var(--tr-text);
  font-family: var(--tf-font-body, 'Plus Jakarta Sans', sans-serif);
}
.tf-travel-page *, .tf-travel-page *::before, .tf-travel-page *::after { box-sizing: border-box; margin: 0; padding: 0; }
.tf-travel-page a { color: inherit; text-decoration: none; }
.tf-travel-page img { display: block; max-width: 100%; }

/* ---------- layout ---------- */
.tr-container { max-width: 1200px; margin: 0 auto; padding: 0 24px; }
.tr-section { padding: 96px 0; }
.tr-section--alt { background: var(--tr-bg2); }
.tr-section--dark { background: var(--tr-bg3); }
.tr-label {
  display: inline-block;
  font-size: .72rem;
  font-weight: 700;
  letter-spacing: .14em;
  text-transform: uppercase;
  color: var(--tr-accent);
  margin-bottom: 12px;
}
.tr-heading {
  font-family: var(--tf-font-heading, 'Plus Jakarta Sans', sans-serif);
  font-size: clamp(2rem, 3.5vw, 3rem);
  font-weight: 800;
  line-height: 1.15;
  color: #fff;
  margin-bottom: 16px;
}
.tr-heading span { color: var(--tr-accent); }
.tr-sub {
  font-size: 1.05rem;
  color: var(--tr-muted);
  line-height: 1.7;
  max-width: 580px;
}
.tr-btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 13px 28px;
  border-radius: 8px;
  font-size: .9rem;
  font-weight: 700;
  cursor: pointer;
  transition: all .2s;
  border: none;
}
.tr-btn--primary {
  background: var(--tr-accent);
  color: #fff;
}
.tr-btn--primary:hover { background: #0284c7; transform: translateY(-1px); }
.tr-btn--ghost {
  background: transparent;
  color: #fff;
  border: 1.5px solid rgba(255,255,255,.25);
}
.tr-btn--ghost:hover { border-color: var(--tr-accent); color: var(--tr-accent); }

/* =========================================================
   HERO — CSS World Map + Compass
   ========================================================= */
.tr-hero {
  min-height: 100vh;
  display: grid;
  grid-template-columns: 1fr 1fr;
  align-items: center;
  gap: 60px;
  padding: 120px 0 80px;
  position: relative;
  overflow: hidden;
}
.tr-hero::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(ellipse 60% 50% at 70% 50%, rgba(14,165,233,.12) 0%, transparent 70%),
    radial-gradient(ellipse 40% 40% at 20% 80%, rgba(16,185,129,.08) 0%, transparent 60%);
  pointer-events: none;
}

/* Hero copy */
.tr-hero__copy { position: relative; z-index: 2; }
.tr-hero__eyebrow {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 20px;
}
.tr-hero__dot {
  width: 8px; height: 8px; border-radius: 50%;
  background: var(--tr-green);
  animation: tr-pulse 2s ease-in-out infinite;
}
@keyframes tr-pulse {
  0%,100% { box-shadow: 0 0 0 0 rgba(16,185,129,.6); }
  50%       { box-shadow: 0 0 0 8px rgba(16,185,129,0); }
}
.tr-hero__title {
  font-family: var(--tf-font-heading, 'Plus Jakarta Sans', sans-serif);
  font-size: clamp(2.8rem, 5vw, 4.2rem);
  font-weight: 800;
  line-height: 1.1;
  color: #fff;
  margin-bottom: 20px;
}
.tr-hero__title em {
  font-style: normal;
  background: linear-gradient(90deg, var(--tr-accent), var(--tr-green));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
.tr-hero__sub {
  font-size: 1.1rem;
  color: var(--tr-muted);
  line-height: 1.7;
  margin-bottom: 36px;
  max-width: 500px;
}
.tr-hero__cta { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; }
.tr-hero__stats {
  display: flex;
  gap: 32px;
  margin-top: 48px;
  padding-top: 32px;
  border-top: 1px solid var(--tr-border);
}
.tr-hero__stat-num {
  font-size: 1.8rem;
  font-weight: 800;
  color: #fff;
}
.tr-hero__stat-num span { color: var(--tr-accent); }
.tr-hero__stat-label { font-size: .8rem; color: var(--tr-muted); }

/* CSS World Map Art */
.tr-hero__map {
  position: relative;
  z-index: 2;
  width: 100%;
  max-width: 560px;
  aspect-ratio: 4/3;
  justify-self: end;
}
.tr-map-globe {
  position: absolute;
  inset: 0;
  border-radius: 50%;
  width: 340px; height: 340px;
  top: 50%; left: 50%;
  transform: translate(-50%,-50%);
  background: radial-gradient(circle at 35% 35%,
    #1e3a5f 0%, #0a1f3d 50%, #050d18 100%);
  border: 1.5px solid var(--tr-border);
  overflow: hidden;
}
/* Latitude lines */
.tr-map-globe::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    repeating-linear-gradient(
      0deg,
      transparent 0px,
      transparent 33px,
      rgba(14,165,233,.15) 33px,
      rgba(14,165,233,.15) 34px
    ),
    repeating-linear-gradient(
      90deg,
      transparent 0px,
      transparent 33px,
      rgba(14,165,233,.12) 33px,
      rgba(14,165,233,.12) 34px
    );
}
/* Globe shine */
.tr-map-globe::after {
  content: '';
  position: absolute;
  top: 8%; left: 15%;
  width: 38%; height: 28%;
  background: radial-gradient(ellipse, rgba(255,255,255,.12) 0%, transparent 70%);
  border-radius: 50%;
}
/* Continent shapes — CSS approximations */
.tr-continent {
  position: absolute;
  background: rgba(14,165,233,.22);
  border-radius: 40% 60% 55% 45% / 50% 45% 55% 50%;
}
.tr-continent--eu   { width: 60px; height: 45px; top: 28%; left: 48%; }
.tr-continent--af   { width: 65px; height: 85px; top: 42%; left: 49%; border-radius: 35% 65% 60% 40% / 45% 40% 60% 55%; }
.tr-continent--na   { width: 80px; height: 70px; top: 22%; left: 15%; border-radius: 55% 45% 50% 50% / 60% 55% 45% 40%; }
.tr-continent--sa   { width: 55px; height: 80px; top: 48%; left: 24%; border-radius: 40% 60% 65% 35% / 50% 40% 60% 50%; }
.tr-continent--as   { width: 110px; height: 70px; top: 24%; left: 60%; border-radius: 50% 50% 55% 45% / 45% 55% 50% 50%; }
.tr-continent--au   { width: 60px; height: 45px; top: 62%; left: 72%; }

/* Destination pins */
.tr-pin {
  position: absolute;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  cursor: pointer;
}
.tr-pin__dot {
  width: 10px; height: 10px; border-radius: 50%;
  background: var(--tr-amber);
  box-shadow: 0 0 0 3px rgba(245,158,11,.3);
  animation: tr-pin-pulse 2.5s ease-in-out infinite;
}
.tr-pin:nth-child(2) .tr-pin__dot { animation-delay: .5s; }
.tr-pin:nth-child(3) .tr-pin__dot { animation-delay: 1s; background: var(--tr-green); box-shadow: 0 0 0 3px rgba(16,185,129,.3); }
.tr-pin:nth-child(4) .tr-pin__dot { animation-delay: 1.5s; }
.tr-pin:nth-child(5) .tr-pin__dot { animation-delay: .8s; background: var(--tr-accent); box-shadow: 0 0 0 3px rgba(14,165,233,.3); }
@keyframes tr-pin-pulse {
  0%,100% { transform: scale(1); }
  50%       { transform: scale(1.3); }
}
.tr-pin__label {
  font-size: .62rem;
  font-weight: 700;
  color: #fff;
  background: rgba(5,13,24,.85);
  padding: 2px 6px;
  border-radius: 4px;
  white-space: nowrap;
  border: 1px solid var(--tr-border);
}
.tr-pin--bali  { top: 62%; left: 72%; }
.tr-pin--paris { top: 28%; left: 48%; }
.tr-pin--nyc   { top: 30%; left: 20%; }
.tr-pin--dubai { top: 40%; left: 62%; }
.tr-pin--rio   { top: 58%; left: 28%; }

/* Compass rose */
.tr-compass {
  position: absolute;
  bottom: 20px; right: 20px;
  width: 70px; height: 70px;
}
.tr-compass-ring {
  position: absolute;
  inset: 0;
  border: 1.5px solid rgba(14,165,233,.3);
  border-radius: 50%;
}
.tr-compass-ring::before {
  content: '';
  position: absolute;
  inset: 6px;
  border: 1px solid rgba(14,165,233,.2);
  border-radius: 50%;
}
.tr-compass-n, .tr-compass-s, .tr-compass-e, .tr-compass-w {
  position: absolute;
  font-size: .55rem;
  font-weight: 800;
  color: var(--tr-accent);
}
.tr-compass-n { top: 4px; left: 50%; transform: translateX(-50%); }
.tr-compass-s { bottom: 4px; left: 50%; transform: translateX(-50%); color: var(--tr-muted); }
.tr-compass-e { right: 4px; top: 50%; transform: translateY(-50%); color: var(--tr-muted); }
.tr-compass-w { left: 4px;  top: 50%; transform: translateY(-50%); color: var(--tr-muted); }
.tr-compass-needle {
  position: absolute;
  top: 50%; left: 50%;
  width: 2px; height: 24px;
  transform-origin: bottom center;
}
.tr-compass-needle::before {
  content: '';
  position: absolute;
  top: 0; left: 50%; transform: translateX(-50%);
  width: 0; height: 0;
  border-left: 4px solid transparent;
  border-right: 4px solid transparent;
  border-bottom: 16px solid var(--tr-accent);
}
.tr-compass-needle::after {
  content: '';
  position: absolute;
  bottom: 0; left: 50%; transform: translateX(-50%);
  width: 0; height: 0;
  border-left: 4px solid transparent;
  border-right: 4px solid transparent;
  border-top: 16px solid var(--tr-muted);
}

/* Floating stat cards */
.tr-hero__card {
  position: absolute;
  background: rgba(10,22,40,.9);
  border: 1px solid var(--tr-border);
  border-radius: 10px;
  padding: 12px 16px;
  backdrop-filter: blur(10px);
  min-width: 140px;
}
.tr-hero__card--tl { top: 10%; left: 0; }
.tr-hero__card--br { bottom: 12%; right: 0; }
.tr-hero__card__label { font-size: .65rem; color: var(--tr-muted); margin-bottom: 4px; }
.tr-hero__card__val { font-size: 1.2rem; font-weight: 800; color: #fff; }
.tr-hero__card__val span { font-size: .75rem; color: var(--tr-green); }

/* =========================================================
   SEARCH STRIP
   ========================================================= */
.tr-search {
  background: var(--tr-bg2);
  padding: 0;
  position: relative;
  z-index: 10;
}
.tr-search__bar {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr auto;
  gap: 1px;
  background: var(--tr-border);
  border-radius: var(--tr-radius);
  overflow: hidden;
  border: 1px solid var(--tr-border);
  margin: -36px 0 0;
  box-shadow: 0 20px 60px rgba(0,0,0,.4);
}
.tr-search__field {
  background: var(--tr-card);
  padding: 20px 24px;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.tr-search__field label {
  font-size: .7rem;
  font-weight: 700;
  letter-spacing: .08em;
  text-transform: uppercase;
  color: var(--tr-muted);
}
.tr-search__field input, .tr-search__field select {
  background: transparent;
  border: none;
  outline: none;
  color: #fff;
  font-size: .95rem;
  font-family: inherit;
  font-weight: 600;
}
.tr-search__field select option { background: var(--tr-card); }
.tr-search__go {
  background: var(--tr-accent);
  border: none;
  color: #fff;
  font-weight: 800;
  font-size: .95rem;
  padding: 0 36px;
  cursor: pointer;
  transition: background .2s;
  font-family: inherit;
  display: flex;
  align-items: center;
  gap: 8px;
}
.tr-search__go:hover { background: #0284c7; }
.tr-search__wrap { padding-bottom: 48px; }

/* =========================================================
   DESTINATIONS GRID
   ========================================================= */
.tr-destinations__grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  margin-top: 48px;
}
.tr-dest-card {
  border-radius: var(--tr-radius);
  overflow: hidden;
  position: relative;
  aspect-ratio: 3/4;
  cursor: pointer;
  transition: transform .3s;
}
.tr-dest-card:first-child {
  grid-row: span 2;
  aspect-ratio: auto;
}
.tr-dest-card:hover { transform: translateY(-4px); }
.tr-dest-card:hover .tr-dest-card__overlay { opacity: 1; }

/* CSS destination art */
.tr-dest-card__art {
  width: 100%; height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
}
/* Santorini */
.tr-dest-card:nth-child(1) .tr-dest-card__art {
  background: linear-gradient(160deg, #1a6b8a 0%, #0d4a6b 35%, #c8a87a 60%, #e8d5b0 100%);
}
/* Kyoto */
.tr-dest-card:nth-child(2) .tr-dest-card__art {
  background: linear-gradient(160deg, #2d1b3d 0%, #4a1942 40%, #ff6b6b 65%, #ffb347 100%);
}
/* Safari */
.tr-dest-card:nth-child(3) .tr-dest-card__art {
  background: linear-gradient(160deg, #1a2f1a 0%, #2d4a1e 30%, #c8a03a 60%, #e8c060 100%);
}
/* Maldives */
.tr-dest-card:nth-child(4) .tr-dest-card__art {
  background: linear-gradient(160deg, #0a1f3d 0%, #0f4c8a 35%, #0ea5e9 60%, #67e8f9 100%);
}
/* New York */
.tr-dest-card:nth-child(5) .tr-dest-card__art {
  background: linear-gradient(160deg, #0a0a1a 0%, #1a1a3a 40%, #2a2a5a 65%, #ffd700 85%, #ff8c00 100%);
}

/* Art details — Santorini white dome */
.tr-dest-card:nth-child(1) .tr-dest-card__art::before {
  content: '';
  position: absolute;
  bottom: 30%; left: 50%; transform: translateX(-50%);
  width: 60px; height: 35px;
  background: rgba(255,255,255,.9);
  border-radius: 50% 50% 0 0;
}
.tr-dest-card:nth-child(1) .tr-dest-card__art::after {
  content: '';
  position: absolute;
  bottom: 25%; left: 45%;
  width: 80px; height: 20px;
  background: rgba(255,255,255,.8);
  border-radius: 4px;
}
/* Kyoto pagoda */
.tr-dest-card:nth-child(2) .tr-dest-card__art::before {
  content: '';
  position: absolute;
  bottom: 20%; left: 50%; transform: translateX(-50%);
  width: 3px; height: 60px;
  background: rgba(255,255,255,.6);
  box-shadow: -20px 15px 0 rgba(255,255,255,.5), 20px 15px 0 rgba(255,255,255,.5),
              -28px 28px 0 rgba(255,255,255,.4), 28px 28px 0 rgba(255,255,255,.4);
}
/* Safari tree */
.tr-dest-card:nth-child(3) .tr-dest-card__art::before {
  content: '';
  position: absolute;
  bottom: 20%; left: 50%; transform: translateX(-50%);
  width: 4px; height: 50px;
  background: rgba(60,30,10,.8);
}
.tr-dest-card:nth-child(3) .tr-dest-card__art::after {
  content: '';
  position: absolute;
  bottom: 55%; left: 50%; transform: translateX(-50%);
  width: 70px; height: 25px;
  background: rgba(30,80,20,.7);
  border-radius: 50%;
}
/* Maldives hut */
.tr-dest-card:nth-child(4) .tr-dest-card__art::before {
  content: '';
  position: absolute;
  bottom: 30%; left: 50%; transform: translateX(-50%);
  width: 50px; height: 30px;
  background: rgba(200,160,80,.7);
  border-radius: 4px 4px 0 0;
}
/* NYC skyline */
.tr-dest-card:nth-child(5) .tr-dest-card__art::before {
  content: '';
  position: absolute;
  bottom: 0; left: 10%;
  width: 80%;
  height: 60%;
  background:
    linear-gradient(to top, #1a1a3a 0%, transparent 100%),
    repeating-linear-gradient(
      90deg,
      #2a2a5a 0px, #2a2a5a 8px,
      transparent 8px, transparent 12px
    );
  clip-path: polygon(
    0% 100%, 0% 60%, 5% 60%, 5% 40%, 10% 40%, 10% 50%, 15% 50%, 15% 30%, 20% 30%, 20% 45%, 25% 45%, 25% 25%, 30% 25%, 30% 55%, 35% 55%, 35% 20%, 40% 20%, 40% 15%, 45% 15%, 45% 35%, 50% 35%, 50% 18%, 55% 18%, 55% 42%, 60% 42%, 60% 28%, 65% 28%, 65% 50%, 70% 50%, 70% 35%, 75% 35%, 75% 55%, 80% 55%, 80% 40%, 85% 40%, 85% 60%, 90% 60%, 90% 48%, 95% 48%, 95% 65%, 100% 65%, 100% 100%
  );
}

.tr-dest-card__overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(to top, rgba(5,13,24,.9) 0%, rgba(5,13,24,.3) 50%, transparent 100%);
  opacity: .7;
  transition: opacity .3s;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  padding: 20px;
}
.tr-dest-card__country {
  font-size: .7rem;
  font-weight: 700;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: var(--tr-accent);
  margin-bottom: 4px;
}
.tr-dest-card__name {
  font-size: 1.15rem;
  font-weight: 800;
  color: #fff;
  margin-bottom: 8px;
}
.tr-dest-card:first-child .tr-dest-card__name { font-size: 1.5rem; }
.tr-dest-card__meta {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: .78rem;
  color: rgba(255,255,255,.7);
}
.tr-dest-card__price {
  margin-left: auto;
  font-size: .85rem;
  font-weight: 800;
  color: var(--tr-amber);
}

/* =========================================================
   PACKAGES
   ========================================================= */
.tr-packages__grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
  margin-top: 48px;
}
.tr-package {
  background: var(--tr-card);
  border: 1px solid var(--tr-border);
  border-radius: var(--tr-radius);
  overflow: hidden;
  transition: transform .3s, box-shadow .3s;
  display: flex;
  flex-direction: column;
}
.tr-package:hover {
  transform: translateY(-4px);
  box-shadow: 0 20px 40px rgba(0,0,0,.3);
}
.tr-package--featured {
  border-color: var(--tr-accent);
  box-shadow: 0 0 0 1px rgba(14,165,233,.3);
}
.tr-package__img {
  height: 180px;
  position: relative;
  overflow: hidden;
}
.tr-package__badge {
  position: absolute;
  top: 12px; left: 12px;
  background: var(--tr-accent);
  color: #fff;
  font-size: .68rem;
  font-weight: 700;
  letter-spacing: .06em;
  padding: 3px 10px;
  border-radius: 20px;
  text-transform: uppercase;
}
.tr-package--featured .tr-package__badge {
  background: var(--tr-amber);
  color: #000;
}
/* Package art */
.tr-package:nth-child(1) .tr-package__img { background: linear-gradient(135deg, #0a2a4a 0%, #1a6b8a 50%, #67e8f9 100%); }
.tr-package:nth-child(2) .tr-package__img { background: linear-gradient(135deg, #2d1b3d 0%, #7c3aed 50%, #c084fc 100%); }
.tr-package:nth-child(3) .tr-package__img { background: linear-gradient(135deg, #1a2f1a 0%, #15803d 50%, #bbf7d0 100%); }

.tr-package__body { padding: 24px; flex: 1; display: flex; flex-direction: column; }
.tr-package__tag {
  font-size: .68rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: .08em;
  color: var(--tr-accent);
  margin-bottom: 8px;
}
.tr-package--featured .tr-package__tag { color: var(--tr-amber); }
.tr-package__name {
  font-size: 1.15rem;
  font-weight: 800;
  color: #fff;
  margin-bottom: 10px;
  line-height: 1.3;
}
.tr-package__desc { font-size: .88rem; color: var(--tr-muted); line-height: 1.65; margin-bottom: 16px; }
.tr-package__includes {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 24px;
  flex: 1;
}
.tr-package__includes li {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: .83rem;
  color: var(--tr-text);
}
.tr-package__includes li svg { color: var(--tr-green); flex-shrink: 0; }
.tr-package__footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-top: 16px;
  border-top: 1px solid var(--tr-border);
}
.tr-package__price-label { font-size: .72rem; color: var(--tr-muted); }
.tr-package__price-val {
  font-size: 1.5rem;
  font-weight: 800;
  color: #fff;
}
.tr-package__price-val span { font-size: .8rem; font-weight: 500; color: var(--tr-muted); }
.tr-package__cta {
  background: transparent;
  border: 1.5px solid var(--tr-border);
  color: #fff;
  font-size: .82rem;
  font-weight: 700;
  padding: 9px 18px;
  border-radius: 8px;
  cursor: pointer;
  transition: all .2s;
  font-family: inherit;
}
.tr-package__cta:hover { border-color: var(--tr-accent); color: var(--tr-accent); }
.tr-package--featured .tr-package__cta {
  background: var(--tr-accent);
  border-color: var(--tr-accent);
}
.tr-package--featured .tr-package__cta:hover { background: #0284c7; }

/* =========================================================
   WHY CHOOSE US
   ========================================================= */
.tr-why__grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 24px;
  margin-top: 48px;
}
.tr-why-card {
  background: var(--tr-card);
  border: 1px solid var(--tr-border);
  border-radius: var(--tr-radius);
  padding: 28px 24px;
  transition: border-color .3s;
}
.tr-why-card:hover { border-color: var(--tr-accent); }
.tr-why-card__icon {
  width: 48px; height: 48px;
  border-radius: 10px;
  background: rgba(14,165,233,.12);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 16px;
  color: var(--tr-accent);
}
.tr-why-card:nth-child(2) .tr-why-card__icon { background: rgba(245,158,11,.12); color: var(--tr-amber); }
.tr-why-card:nth-child(3) .tr-why-card__icon { background: rgba(16,185,129,.12); color: var(--tr-green); }
.tr-why-card:nth-child(4) .tr-why-card__icon { background: rgba(139,92,246,.12); color: #8b5cf6; }
.tr-why-card__title { font-size: 1rem; font-weight: 700; color: #fff; margin-bottom: 8px; }
.tr-why-card__desc { font-size: .85rem; color: var(--tr-muted); line-height: 1.65; }

/* =========================================================
   STATS BAR
   ========================================================= */
.tr-stats {
  background: linear-gradient(90deg, #0ea5e9 0%, #0284c7 100%);
  padding: 40px 0;
}
.tr-stats__grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 32px;
  text-align: center;
}
.tr-stats__num {
  font-size: 2.2rem;
  font-weight: 900;
  color: #fff;
  line-height: 1;
  margin-bottom: 6px;
}
.tr-stats__label { font-size: .82rem; color: rgba(255,255,255,.75); font-weight: 500; }

/* =========================================================
   TESTIMONIALS
   ========================================================= */
.tr-testi__grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
  margin-top: 48px;
}
.tr-testi-card {
  background: var(--tr-card);
  border: 1px solid var(--tr-border);
  border-radius: var(--tr-radius);
  padding: 28px 24px;
}
.tr-testi-card__stars {
  display: flex;
  gap: 4px;
  margin-bottom: 16px;
  color: var(--tr-amber);
}
.tr-testi-card__quote {
  font-size: .93rem;
  color: var(--tr-text);
  line-height: 1.7;
  margin-bottom: 20px;
  font-style: italic;
}
.tr-testi-card__author {
  display: flex;
  align-items: center;
  gap: 12px;
}
.tr-testi-card__avatar {
  width: 40px; height: 40px;
  border-radius: 50%;
  background: linear-gradient(135deg, var(--tr-accent), var(--tr-green));
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: .75rem;
  font-weight: 800;
  color: #fff;
  flex-shrink: 0;
}
.tr-testi-card__name { font-size: .88rem; font-weight: 700; color: #fff; }
.tr-testi-card__trip { font-size: .75rem; color: var(--tr-accent); }
.tr-testi-card__badge {
  margin-left: auto;
  font-size: .68rem;
  font-weight: 700;
  padding: 3px 10px;
  border-radius: 20px;
  background: rgba(16,185,129,.12);
  color: var(--tr-green);
  border: 1px solid rgba(16,185,129,.3);
}

/* =========================================================
   BOOKING FORM
   ========================================================= */
.tr-booking {
  background: var(--tr-bg3);
}
.tr-booking__inner {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 80px;
  align-items: start;
}
.tr-booking__sub { font-size: 1rem; color: var(--tr-muted); line-height: 1.7; margin-bottom: 32px; }
.tr-booking__features {
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.tr-booking__feature {
  display: flex;
  align-items: flex-start;
  gap: 14px;
}
.tr-booking__feature-icon {
  width: 36px; height: 36px;
  border-radius: 8px;
  background: rgba(14,165,233,.12);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--tr-accent);
  flex-shrink: 0;
}
.tr-booking__feature-title { font-size: .9rem; font-weight: 700; color: #fff; margin-bottom: 2px; }
.tr-booking__feature-desc { font-size: .8rem; color: var(--tr-muted); }

.tr-form {
  background: var(--tr-card);
  border: 1px solid var(--tr-border);
  border-radius: var(--tr-radius);
  padding: 32px;
}
.tr-form__title { font-size: 1.15rem; font-weight: 800; color: #fff; margin-bottom: 24px; }
.tr-form__row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.tr-form__group { margin-bottom: 16px; }
.tr-form__label {
  display: block;
  font-size: .75rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: .06em;
  color: var(--tr-muted);
  margin-bottom: 6px;
}
.tr-form__input, .tr-form__select, .tr-form__textarea {
  width: 100%;
  background: rgba(255,255,255,.04);
  border: 1px solid var(--tr-border);
  border-radius: 8px;
  color: #fff;
  font-family: inherit;
  font-size: .9rem;
  padding: 11px 14px;
  outline: none;
  transition: border-color .2s;
}
.tr-form__input:focus, .tr-form__select:focus, .tr-form__textarea:focus {
  border-color: var(--tr-accent);
}
.tr-form__select option { background: var(--tr-card); }
.tr-form__textarea { resize: vertical; min-height: 90px; }
.tr-form__footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  flex-wrap: wrap;
  margin-top: 8px;
}
.tr-form__guarantee { font-size: .75rem; color: var(--tr-muted); display: flex; align-items: center; gap: 6px; }
.tr-form__guarantee svg { color: var(--tr-green); }
.tr-form__submit {
  background: var(--tr-accent);
  color: #fff;
  border: none;
  border-radius: 8px;
  font-size: .9rem;
  font-weight: 700;
  padding: 13px 28px;
  cursor: pointer;
  font-family: inherit;
  transition: background .2s;
  display: flex;
  align-items: center;
  gap: 8px;
}
.tr-form__submit:hover { background: #0284c7; }

/* =========================================================
   CTA BANNER
   ========================================================= */
.tr-cta {
  background: linear-gradient(135deg, #0a1f3d 0%, #0f2d56 50%, #0a1f3d 100%);
  padding: 96px 0;
  text-align: center;
  position: relative;
  overflow: hidden;
}
.tr-cta::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(ellipse 50% 60% at 50% 50%, rgba(14,165,233,.15) 0%, transparent 70%);
}
.tr-cta__inner { position: relative; z-index: 1; max-width: 600px; margin: 0 auto; }
.tr-cta__title {
  font-size: clamp(2rem, 3.5vw, 2.8rem);
  font-weight: 800;
  color: #fff;
  margin-bottom: 16px;
}
.tr-cta__title span { color: var(--tr-accent); }
.tr-cta__sub { font-size: 1.05rem; color: rgba(255,255,255,.65); margin-bottom: 36px; }
.tr-cta__btns { display: flex; align-items: center; justify-content: center; gap: 16px; flex-wrap: wrap; }

/* =========================================================
   RESPONSIVE
   ========================================================= */
@media (max-width: 1100px) {
  .tr-hero { grid-template-columns: 1fr; gap: 40px; padding: 100px 0 60px; }
  .tr-hero__map { justify-self: center; max-width: 420px; }
  .tr-destinations__grid { grid-template-columns: repeat(2,1fr); }
  .tr-dest-card:first-child { grid-row: span 1; }
  .tr-packages__grid { grid-template-columns: 1fr 1fr; }
  .tr-why__grid { grid-template-columns: 1fr 1fr; }
  .tr-booking__inner { grid-template-columns: 1fr; gap: 40px; }
}
@media (max-width: 768px) {
  .tr-section { padding: 64px 0; }
  .tr-search__bar { grid-template-columns: 1fr; }
  .tr-destinations__grid { grid-template-columns: 1fr; }
  .tr-packages__grid { grid-template-columns: 1fr; }
  .tr-testi__grid { grid-template-columns: 1fr; }
  .tr-stats__grid { grid-template-columns: 1fr 1fr; }
  .tr-why__grid { grid-template-columns: 1fr; }
  .tr-form__row { grid-template-columns: 1fr; }
  .tr-hero__stats { flex-wrap: wrap; gap: 20px; }
  .tr-hero__card--tl, .tr-hero__card--br { display: none; }
}
</style>

<!-- =========================================================
     HERO
     ========================================================= -->
<section class="tr-hero">
  <div class="tr-container" style="display:contents;">

    <div class="tr-hero__copy tr-container" style="display:block;">
      <div class="tr-hero__eyebrow">
        <span class="tr-hero__dot"></span>
        <span class="tr-label" style="margin:0;"><?php esc_html_e('Trusted by 50,000+ Travellers', 'themeflex'); ?></span>
      </div>
      <h1 class="tr-hero__title">
        <?php esc_html_e('Discover the World,', 'themeflex'); ?><br>
        <em><?php esc_html_e('Your Way.', 'themeflex'); ?></em>
      </h1>
      <p class="tr-hero__sub">
        <?php esc_html_e('Handcrafted travel experiences across 80+ countries. From luxury escapes to adventure expeditions — we turn your travel dreams into unforgettable memories.', 'themeflex'); ?>
      </p>
      <div class="tr-hero__cta">
        <a href="<?php echo esc_url(get_permalink(get_page_by_path('tours'))); ?>" class="tr-btn tr-btn--primary">
          <?php echo tf_icon_get('map', 18); ?>
          <?php esc_html_e('Explore Destinations', 'themeflex'); ?>
        </a>
        <a href="<?php echo esc_url(get_permalink(get_page_by_path('about'))); ?>" class="tr-btn tr-btn--ghost">
          <?php esc_html_e('How It Works', 'themeflex'); ?>
        </a>
      </div>
      <div class="tr-hero__stats">
        <div>
          <div class="tr-hero__stat-num"><span data-counter="80" data-suffix="+">80+</span></div>
          <div class="tr-hero__stat-label"><?php esc_html_e('Countries', 'themeflex'); ?></div>
        </div>
        <div>
          <div class="tr-hero__stat-num"><span data-counter="50" data-suffix="K+">50K+</span></div>
          <div class="tr-hero__stat-label"><?php esc_html_e('Happy Travellers', 'themeflex'); ?></div>
        </div>
        <div>
          <div class="tr-hero__stat-num"><span data-counter="4.9" data-suffix="★">4.9★</span></div>
          <div class="tr-hero__stat-label"><?php esc_html_e('Average Rating', 'themeflex'); ?></div>
        </div>
      </div>
    </div>

    <div class="tr-hero__map tr-container" style="display:block; position:relative;">
      <!-- Globe -->
      <div class="tr-map-globe">
        <div class="tr-continent tr-continent--na"></div>
        <div class="tr-continent tr-continent--sa"></div>
        <div class="tr-continent tr-continent--eu"></div>
        <div class="tr-continent tr-continent--af"></div>
        <div class="tr-continent tr-continent--as"></div>
        <div class="tr-continent tr-continent--au"></div>
      </div>
      <!-- Destination pins -->
      <div class="tr-pin tr-pin--bali" style="position:absolute; top:62%; left:72%;">
        <div class="tr-pin__dot"></div>
        <div class="tr-pin__label"><?php esc_html_e('Bali', 'themeflex'); ?></div>
      </div>
      <div class="tr-pin tr-pin--paris" style="position:absolute; top:28%; left:48%;">
        <div class="tr-pin__dot"></div>
        <div class="tr-pin__label"><?php esc_html_e('Paris', 'themeflex'); ?></div>
      </div>
      <div class="tr-pin tr-pin--nyc" style="position:absolute; top:30%; left:20%;">
        <div class="tr-pin__dot"></div>
        <div class="tr-pin__label"><?php esc_html_e('New York', 'themeflex'); ?></div>
      </div>
      <div class="tr-pin tr-pin--dubai" style="position:absolute; top:40%; left:62%;">
        <div class="tr-pin__dot"></div>
        <div class="tr-pin__label"><?php esc_html_e('Dubai', 'themeflex'); ?></div>
      </div>
      <div class="tr-pin tr-pin--rio" style="position:absolute; top:58%; left:28%;">
        <div class="tr-pin__dot"></div>
        <div class="tr-pin__label"><?php esc_html_e('Rio', 'themeflex'); ?></div>
      </div>
      <!-- Compass -->
      <div class="tr-compass" style="position:absolute; bottom:20px; right:20px;">
        <div class="tr-compass-ring"></div>
        <span class="tr-compass-n">N</span>
        <span class="tr-compass-s">S</span>
        <span class="tr-compass-e">E</span>
        <span class="tr-compass-w">W</span>
        <div class="tr-compass-needle" style="position:absolute; top:50%; left:50%; transform:translate(-50%,-100%) rotate(-25deg);"></div>
      </div>
      <!-- Stat cards -->
      <div class="tr-hero__card tr-hero__card--tl">
        <div class="tr-hero__card__label"><?php esc_html_e('Next Departure', 'themeflex'); ?></div>
        <div class="tr-hero__card__val"><?php esc_html_e('Bali', 'themeflex'); ?> <span>+12 seats</span></div>
      </div>
      <div class="tr-hero__card tr-hero__card--br">
        <div class="tr-hero__card__label"><?php esc_html_e('Best Value', 'themeflex'); ?></div>
        <div class="tr-hero__card__val"><?php esc_html_e('from €890', 'themeflex'); ?></div>
      </div>
    </div>

  </div>
</section>

<!-- =========================================================
     SEARCH STRIP
     ========================================================= -->
<section class="tr-search">
  <div class="tr-search__wrap tr-container">
    <div class="tr-search__bar">
      <div class="tr-search__field">
        <label for="tr-destination"><?php esc_html_e('Destination', 'themeflex'); ?></label>
        <input id="tr-destination" type="text" placeholder="<?php esc_attr_e('Where to?', 'themeflex'); ?>">
      </div>
      <div class="tr-search__field">
        <label for="tr-checkin"><?php esc_html_e('Travel Date', 'themeflex'); ?></label>
        <input id="tr-checkin" type="text" placeholder="<?php esc_attr_e('Select date', 'themeflex'); ?>">
      </div>
      <div class="tr-search__field">
        <label for="tr-type"><?php esc_html_e('Tour Type', 'themeflex'); ?></label>
        <select id="tr-type">
          <option value=""><?php esc_html_e('All Types', 'themeflex'); ?></option>
          <option><?php esc_html_e('Adventure', 'themeflex'); ?></option>
          <option><?php esc_html_e('Luxury', 'themeflex'); ?></option>
          <option><?php esc_html_e('Cultural', 'themeflex'); ?></option>
          <option><?php esc_html_e('Family', 'themeflex'); ?></option>
          <option><?php esc_html_e('Honeymoon', 'themeflex'); ?></option>
        </select>
      </div>
      <button class="tr-search__go" type="button">
        <?php echo tf_icon_get('search', 18); ?>
        <?php esc_html_e('Search', 'themeflex'); ?>
      </button>
    </div>
  </div>
</section>

<!-- =========================================================
     DESTINATIONS GRID
     ========================================================= -->
<section class="tr-section">
  <div class="tr-container">
    <span class="tr-label"><?php esc_html_e('Top Destinations', 'themeflex'); ?></span>
    <h2 class="tr-heading"><?php esc_html_e('Where Will You Go <span>Next?</span>', 'themeflex'); ?></h2>
    <p class="tr-sub"><?php esc_html_e('From the sun-drenched Greek islands to the neon-lit streets of New York — explore our most loved destinations.', 'themeflex'); ?></p>
    <div class="tr-destinations__grid">

      <div class="tr-dest-card">
        <div class="tr-dest-card__art"></div>
        <div class="tr-dest-card__overlay">
          <div class="tr-dest-card__country"><?php esc_html_e('Greece', 'themeflex'); ?></div>
          <div class="tr-dest-card__name"><?php esc_html_e('Santorini', 'themeflex'); ?></div>
          <div class="tr-dest-card__meta">
            <?php echo tf_icon_get('clock', 14); ?>
            <?php esc_html_e('8 days', 'themeflex'); ?>
            <?php echo tf_icon_get('users', 14); ?>
            <?php esc_html_e('Small group', 'themeflex'); ?>
            <span class="tr-dest-card__price"><?php esc_html_e('from €1,890', 'themeflex'); ?></span>
          </div>
        </div>
      </div>

      <div class="tr-dest-card">
        <div class="tr-dest-card__art"></div>
        <div class="tr-dest-card__overlay">
          <div class="tr-dest-card__country"><?php esc_html_e('Japan', 'themeflex'); ?></div>
          <div class="tr-dest-card__name"><?php esc_html_e('Kyoto', 'themeflex'); ?></div>
          <div class="tr-dest-card__meta">
            <?php echo tf_icon_get('clock', 14); ?>
            <?php esc_html_e('10 days', 'themeflex'); ?>
            <span class="tr-dest-card__price"><?php esc_html_e('from €2,490', 'themeflex'); ?></span>
          </div>
        </div>
      </div>

      <div class="tr-dest-card">
        <div class="tr-dest-card__art"></div>
        <div class="tr-dest-card__overlay">
          <div class="tr-dest-card__country"><?php esc_html_e('Kenya', 'themeflex'); ?></div>
          <div class="tr-dest-card__name"><?php esc_html_e('Masai Mara Safari', 'themeflex'); ?></div>
          <div class="tr-dest-card__meta">
            <?php echo tf_icon_get('clock', 14); ?>
            <?php esc_html_e('7 days', 'themeflex'); ?>
            <span class="tr-dest-card__price"><?php esc_html_e('from €3,200', 'themeflex'); ?></span>
          </div>
        </div>
      </div>

      <div class="tr-dest-card">
        <div class="tr-dest-card__art"></div>
        <div class="tr-dest-card__overlay">
          <div class="tr-dest-card__country"><?php esc_html_e('Maldives', 'themeflex'); ?></div>
          <div class="tr-dest-card__name"><?php esc_html_e('Private Island', 'themeflex'); ?></div>
          <div class="tr-dest-card__meta">
            <?php echo tf_icon_get('clock', 14); ?>
            <?php esc_html_e('6 days', 'themeflex'); ?>
            <span class="tr-dest-card__price"><?php esc_html_e('from €4,800', 'themeflex'); ?></span>
          </div>
        </div>
      </div>

      <div class="tr-dest-card">
        <div class="tr-dest-card__art"></div>
        <div class="tr-dest-card__overlay">
          <div class="tr-dest-card__country"><?php esc_html_e('USA', 'themeflex'); ?></div>
          <div class="tr-dest-card__name"><?php esc_html_e('New York City', 'themeflex'); ?></div>
          <div class="tr-dest-card__meta">
            <?php echo tf_icon_get('clock', 14); ?>
            <?php esc_html_e('5 days', 'themeflex'); ?>
            <span class="tr-dest-card__price"><?php esc_html_e('from €1,490', 'themeflex'); ?></span>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- =========================================================
     STATS BAR
     ========================================================= -->
<div class="tr-stats">
  <div class="tr-container">
    <div class="tr-stats__grid">
      <div>
        <div class="tr-stats__num" data-counter="80" data-suffix="+">80+</div>
        <div class="tr-stats__label"><?php esc_html_e('Countries Covered', 'themeflex'); ?></div>
      </div>
      <div>
        <div class="tr-stats__num" data-counter="50000" data-suffix="+">50,000+</div>
        <div class="tr-stats__label"><?php esc_html_e('Happy Travellers', 'themeflex'); ?></div>
      </div>
      <div>
        <div class="tr-stats__num" data-counter="18" data-suffix=" yrs">18 yrs</div>
        <div class="tr-stats__label"><?php esc_html_e('In Business', 'themeflex'); ?></div>
      </div>
      <div>
        <div class="tr-stats__num" data-counter="4.9" data-suffix="★">4.9★</div>
        <div class="tr-stats__label"><?php esc_html_e('Average Rating', 'themeflex'); ?></div>
      </div>
    </div>
  </div>
</div>

<!-- =========================================================
     PACKAGES
     ========================================================= -->
<section class="tr-section tr-section--alt">
  <div class="tr-container">
    <span class="tr-label"><?php esc_html_e('Curated Experiences', 'themeflex'); ?></span>
    <h2 class="tr-heading"><?php esc_html_e('Our Signature <span>Travel Packages</span>', 'themeflex'); ?></h2>
    <p class="tr-sub"><?php esc_html_e('Meticulously planned itineraries crafted by destination experts. Every detail sorted — flights, hotels, guides, and surprises.', 'themeflex'); ?></p>
    <div class="tr-packages__grid">

      <div class="tr-package">
        <div class="tr-package__img">
          <span class="tr-package__badge"><?php esc_html_e('Popular', 'themeflex'); ?></span>
        </div>
        <div class="tr-package__body">
          <div class="tr-package__tag"><?php esc_html_e('Luxury · Mediterranean', 'themeflex'); ?></div>
          <h3 class="tr-package__name"><?php esc_html_e('Greek Islands Grand Tour', 'themeflex'); ?></h3>
          <p class="tr-package__desc"><?php esc_html_e('Athens, Santorini, Mykonos & Crete — 14 days of island-hopping in style with private yacht day trips.', 'themeflex'); ?></p>
          <ul class="tr-package__includes">
            <li><?php echo tf_icon_get('check', 15); ?> <?php esc_html_e('Return flights included', 'themeflex'); ?></li>
            <li><?php echo tf_icon_get('check', 15); ?> <?php esc_html_e('5-star boutique hotels', 'themeflex'); ?></li>
            <li><?php echo tf_icon_get('check', 15); ?> <?php esc_html_e('Private transfers', 'themeflex'); ?></li>
            <li><?php echo tf_icon_get('check', 15); ?> <?php esc_html_e('Expert local guide', 'themeflex'); ?></li>
          </ul>
          <div class="tr-package__footer">
            <div>
              <div class="tr-package__price-label"><?php esc_html_e('per person', 'themeflex'); ?></div>
              <div class="tr-package__price-val"><?php esc_html_e('€3,490', 'themeflex'); ?> <span><?php esc_html_e('/ 14 days', 'themeflex'); ?></span></div>
            </div>
            <button class="tr-package__cta"><?php esc_html_e('Book Now', 'themeflex'); ?></button>
          </div>
        </div>
      </div>

      <div class="tr-package tr-package--featured">
        <div class="tr-package__img">
          <span class="tr-package__badge"><?php esc_html_e('Best Value', 'themeflex'); ?></span>
        </div>
        <div class="tr-package__body">
          <div class="tr-package__tag"><?php esc_html_e('Cultural · Asia', 'themeflex'); ?></div>
          <h3 class="tr-package__name"><?php esc_html_e('Japan Cherry Blossom Journey', 'themeflex'); ?></h3>
          <p class="tr-package__desc"><?php esc_html_e('Tokyo, Kyoto, Osaka & Hiroshima during sakura season — a once-in-a-lifetime cultural immersion.', 'themeflex'); ?></p>
          <ul class="tr-package__includes">
            <li><?php echo tf_icon_get('check', 15); ?> <?php esc_html_e('Return flights included', 'themeflex'); ?></li>
            <li><?php echo tf_icon_get('check', 15); ?> <?php esc_html_e('Ryokan & city hotels', 'themeflex'); ?></li>
            <li><?php echo tf_icon_get('check', 15); ?> <?php esc_html_e('JR Rail Pass', 'themeflex'); ?></li>
            <li><?php echo tf_icon_get('check', 15); ?> <?php esc_html_e('Tea ceremony & cooking class', 'themeflex'); ?></li>
          </ul>
          <div class="tr-package__footer">
            <div>
              <div class="tr-package__price-label"><?php esc_html_e('per person', 'themeflex'); ?></div>
              <div class="tr-package__price-val"><?php esc_html_e('€4,190', 'themeflex'); ?> <span><?php esc_html_e('/ 12 days', 'themeflex'); ?></span></div>
            </div>
            <button class="tr-package__cta"><?php esc_html_e('Book Now', 'themeflex'); ?></button>
          </div>
        </div>
      </div>

      <div class="tr-package">
        <div class="tr-package__img">
          <span class="tr-package__badge"><?php esc_html_e('Adventure', 'themeflex'); ?></span>
        </div>
        <div class="tr-package__body">
          <div class="tr-package__tag"><?php esc_html_e('Safari · Africa', 'themeflex'); ?></div>
          <h3 class="tr-package__name"><?php esc_html_e('Kenya & Tanzania Wildlife Safari', 'themeflex'); ?></h3>
          <p class="tr-package__desc"><?php esc_html_e('Witness the Great Migration across the Serengeti with guided game drives and luxury tented camps.', 'themeflex'); ?></p>
          <ul class="tr-package__includes">
            <li><?php echo tf_icon_get('check', 15); ?> <?php esc_html_e('Light aircraft transfers', 'themeflex'); ?></li>
            <li><?php echo tf_icon_get('check', 15); ?> <?php esc_html_e('Luxury tented lodges', 'themeflex'); ?></li>
            <li><?php echo tf_icon_get('check', 15); ?> <?php esc_html_e('All-inclusive meals', 'themeflex'); ?></li>
            <li><?php echo tf_icon_get('check', 15); ?> <?php esc_html_e('Expert wildlife guide', 'themeflex'); ?></li>
          </ul>
          <div class="tr-package__footer">
            <div>
              <div class="tr-package__price-label"><?php esc_html_e('per person', 'themeflex'); ?></div>
              <div class="tr-package__price-val"><?php esc_html_e('€5,890', 'themeflex'); ?> <span><?php esc_html_e('/ 10 days', 'themeflex'); ?></span></div>
            </div>
            <button class="tr-package__cta"><?php esc_html_e('Book Now', 'themeflex'); ?></button>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- =========================================================
     WHY CHOOSE US
     ========================================================= -->
<section class="tr-section">
  <div class="tr-container">
    <span class="tr-label"><?php esc_html_e('Why Travel With Us', 'themeflex'); ?></span>
    <h2 class="tr-heading"><?php esc_html_e('We Make Every Journey <span>Extraordinary</span>', 'themeflex'); ?></h2>
    <div class="tr-why__grid">
      <div class="tr-why-card">
        <div class="tr-why-card__icon"><?php echo tf_icon_get('shield-check', 24); ?></div>
        <h3 class="tr-why-card__title"><?php esc_html_e('Fully Protected Travel', 'themeflex'); ?></h3>
        <p class="tr-why-card__desc"><?php esc_html_e('All packages are ATOL & ABTA protected. Your money and travel plans are 100% secure.', 'themeflex'); ?></p>
      </div>
      <div class="tr-why-card">
        <div class="tr-why-card__icon"><?php echo tf_icon_get('headphones', 24); ?></div>
        <h3 class="tr-why-card__title"><?php esc_html_e('24/7 Support On-Trip', 'themeflex'); ?></h3>
        <p class="tr-why-card__desc"><?php esc_html_e('Local experts and a 24/7 emergency line ensure you are never alone, no matter where you are.', 'themeflex'); ?></p>
      </div>
      <div class="tr-why-card">
        <div class="tr-why-card__icon"><?php echo tf_icon_get('award', 24); ?></div>
        <h3 class="tr-why-card__title"><?php esc_html_e('Award-Winning Itineraries', 'themeflex'); ?></h3>
        <p class="tr-why-card__desc"><?php esc_html_e('Winner of the World Travel Awards for Best Tour Operator 2023 and 2024.', 'themeflex'); ?></p>
      </div>
      <div class="tr-why-card">
        <div class="tr-why-card__icon"><?php echo tf_icon_get('leaf', 24); ?></div>
        <h3 class="tr-why-card__title"><?php esc_html_e('Sustainable Tourism', 'themeflex'); ?></h3>
        <p class="tr-why-card__desc"><?php esc_html_e('B-Corp certified. We offset every trip, support local communities and operate carbon-conscious.', 'themeflex'); ?></p>
      </div>
    </div>
  </div>
</section>

<!-- =========================================================
     TESTIMONIALS
     ========================================================= -->
<section class="tr-section tr-section--alt">
  <div class="tr-container">
    <span class="tr-label"><?php esc_html_e('Traveller Stories', 'themeflex'); ?></span>
    <h2 class="tr-heading"><?php esc_html_e('Memories <span>Made</span></h2>', 'themeflex'); ?>
    <div class="tr-testi__grid">

      <div class="tr-testi-card">
        <div class="tr-testi-card__stars">
          <?php for($i=0;$i<5;$i++) echo tf_icon_get('star',16); ?>
        </div>
        <p class="tr-testi-card__quote"><?php esc_html_e('"The Japan trip was beyond anything I imagined. Every ryokan, every bullet train, every temple — perfectly arranged. I\'ve already booked my next trip with them."', 'themeflex'); ?></p>
        <div class="tr-testi-card__author">
          <div class="tr-testi-card__avatar">SL</div>
          <div>
            <div class="tr-testi-card__name"><?php esc_html_e('Sophie L.', 'themeflex'); ?></div>
            <div class="tr-testi-card__trip"><?php esc_html_e('Japan Cherry Blossom · April 2025', 'themeflex'); ?></div>
          </div>
          <span class="tr-testi-card__badge"><?php esc_html_e('Verified', 'themeflex'); ?></span>
        </div>
      </div>

      <div class="tr-testi-card">
        <div class="tr-testi-card__stars">
          <?php for($i=0;$i<5;$i++) echo tf_icon_get('star',16); ?>
        </div>
        <p class="tr-testi-card__quote"><?php esc_html_e('"We saw lions, elephants, and the Migration crossing the Mara River. The tented lodge was incredible — absolute luxury in the wild. Truly life-changing."', 'themeflex'); ?></p>
        <div class="tr-testi-card__author">
          <div class="tr-testi-card__avatar" style="background:linear-gradient(135deg,#f59e0b,#ef4444);">MR</div>
          <div>
            <div class="tr-testi-card__name"><?php esc_html_e('Marco & Rosa B.', 'themeflex'); ?></div>
            <div class="tr-testi-card__trip"><?php esc_html_e('Kenya Safari · August 2025', 'themeflex'); ?></div>
          </div>
          <span class="tr-testi-card__badge"><?php esc_html_e('Verified', 'themeflex'); ?></span>
        </div>
      </div>

      <div class="tr-testi-card">
        <div class="tr-testi-card__stars">
          <?php for($i=0;$i<5;$i++) echo tf_icon_get('star',16); ?>
        </div>
        <p class="tr-testi-card__quote"><?php esc_html_e('"Greek islands for our honeymoon — they thought of everything. Surprise sunset dinner in Santorini, private boat, champagne. We will use them for every holiday now."', 'themeflex'); ?></p>
        <div class="tr-testi-card__author">
          <div class="tr-testi-card__avatar" style="background:linear-gradient(135deg,#10b981,#0ea5e9);">AM</div>
          <div>
            <div class="tr-testi-card__name"><?php esc_html_e('Anna & Max K.', 'themeflex'); ?></div>
            <div class="tr-testi-card__trip"><?php esc_html_e('Greek Islands · June 2025', 'themeflex'); ?></div>
          </div>
          <span class="tr-testi-card__badge"><?php esc_html_e('Verified', 'themeflex'); ?></span>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- =========================================================
     BOOKING FORM
     ========================================================= -->
<section class="tr-section tr-booking">
  <div class="tr-container">
    <div class="tr-booking__inner">

      <div>
        <span class="tr-label"><?php esc_html_e('Plan Your Trip', 'themeflex'); ?></span>
        <h2 class="tr-heading"><?php esc_html_e('Start Your <span>Adventure</span>', 'themeflex'); ?></h2>
        <p class="tr-booking__sub"><?php esc_html_e('Tell us your travel dreams and our destination experts will craft a personalised itinerary within 24 hours. No obligations, no sales pressure.', 'themeflex'); ?></p>
        <div class="tr-booking__features">
          <div class="tr-booking__feature">
            <div class="tr-booking__feature-icon"><?php echo tf_icon_get('clock', 20); ?></div>
            <div>
              <div class="tr-booking__feature-title"><?php esc_html_e('24-Hour Response', 'themeflex'); ?></div>
              <div class="tr-booking__feature-desc"><?php esc_html_e('A specialist will contact you within one business day.', 'themeflex'); ?></div>
            </div>
          </div>
          <div class="tr-booking__feature">
            <div class="tr-booking__feature-icon"><?php echo tf_icon_get('file-text', 20); ?></div>
            <div>
              <div class="tr-booking__feature-title"><?php esc_html_e('Free Custom Itinerary', 'themeflex'); ?></div>
              <div class="tr-booking__feature-desc"><?php esc_html_e('No-cost, no-obligation trip proposal tailored to you.', 'themeflex'); ?></div>
            </div>
          </div>
          <div class="tr-booking__feature">
            <div class="tr-booking__feature-icon"><?php echo tf_icon_get('lock', 20); ?></div>
            <div>
              <div class="tr-booking__feature-title"><?php esc_html_e('Price Lock Guarantee', 'themeflex'); ?></div>
              <div class="tr-booking__feature-desc"><?php esc_html_e('Prices held for 7 days while you consider your proposal.', 'themeflex'); ?></div>
            </div>
          </div>
        </div>
      </div>

      <div class="tr-form">
        <div class="tr-form__title"><?php esc_html_e('Get a Free Quote', 'themeflex'); ?></div>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
          <?php wp_nonce_field('tr_booking_enquiry', '_tr_nonce'); ?>
          <input type="hidden" name="action" value="tr_booking_enquiry">
          <div class="tr-form__row">
            <div class="tr-form__group">
              <label class="tr-form__label" for="tr_fname"><?php esc_html_e('First Name', 'themeflex'); ?></label>
              <input class="tr-form__input" id="tr_fname" name="tr_fname" type="text" required placeholder="<?php esc_attr_e('Maria', 'themeflex'); ?>">
            </div>
            <div class="tr-form__group">
              <label class="tr-form__label" for="tr_lname"><?php esc_html_e('Last Name', 'themeflex'); ?></label>
              <input class="tr-form__input" id="tr_lname" name="tr_lname" type="text" required placeholder="<?php esc_attr_e('Schmidt', 'themeflex'); ?>">
            </div>
          </div>
          <div class="tr-form__group">
            <label class="tr-form__label" for="tr_email"><?php esc_html_e('Email Address', 'themeflex'); ?></label>
            <input class="tr-form__input" id="tr_email" name="tr_email" type="email" required placeholder="<?php esc_attr_e('maria@example.com', 'themeflex'); ?>">
          </div>
          <div class="tr-form__row">
            <div class="tr-form__group">
              <label class="tr-form__label" for="tr_dest"><?php esc_html_e('Dream Destination', 'themeflex'); ?></label>
              <input class="tr-form__input" id="tr_dest" name="tr_dest" type="text" placeholder="<?php esc_attr_e('e.g. Japan, Maldives', 'themeflex'); ?>">
            </div>
            <div class="tr-form__group">
              <label class="tr-form__label" for="tr_budget"><?php esc_html_e('Budget (per person)', 'themeflex'); ?></label>
              <select class="tr-form__select" id="tr_budget" name="tr_budget">
                <option value=""><?php esc_html_e('Select range', 'themeflex'); ?></option>
                <option value="under2k"><?php esc_html_e('Under €2,000', 'themeflex'); ?></option>
                <option value="2k5k"><?php esc_html_e('€2,000 – €5,000', 'themeflex'); ?></option>
                <option value="5k10k"><?php esc_html_e('€5,000 – €10,000', 'themeflex'); ?></option>
                <option value="over10k"><?php esc_html_e('€10,000+', 'themeflex'); ?></option>
              </select>
            </div>
          </div>
          <div class="tr-form__group">
            <label class="tr-form__label" for="tr_message"><?php esc_html_e('Tell Us Your Dream', 'themeflex'); ?></label>
            <textarea class="tr-form__textarea" id="tr_message" name="tr_message" placeholder="<?php esc_attr_e('Dates, travel style, special interests, group size...', 'themeflex'); ?>"></textarea>
          </div>
          <div class="tr-form__footer">
            <span class="tr-form__guarantee">
              <?php echo tf_icon_get('shield-check', 16); ?>
              <?php esc_html_e('Free consultation, no obligation', 'themeflex'); ?>
            </span>
            <button type="submit" class="tr-form__submit">
              <?php echo tf_icon_get('send', 18); ?>
              <?php esc_html_e('Request Quote', 'themeflex'); ?>
            </button>
          </div>
        </form>
      </div>

    </div>
  </div>
</section>

<!-- =========================================================
     CTA BANNER
     ========================================================= -->
<section class="tr-cta">
  <div class="tr-cta__inner">
    <h2 class="tr-cta__title">
      <?php esc_html_e('The World Is Waiting. <span>Are You?</span>', 'themeflex'); ?>
    </h2>
    <p class="tr-cta__sub">
      <?php esc_html_e('Join 50,000+ travellers who have trusted us to create the journeys of their lives. Your next adventure starts here.', 'themeflex'); ?>
    </p>
    <div class="tr-cta__btns">
      <a href="<?php echo esc_url(get_permalink(get_page_by_path('destinations'))); ?>" class="tr-btn tr-btn--primary">
        <?php echo tf_icon_get('globe', 18); ?>
        <?php esc_html_e('Browse Destinations', 'themeflex'); ?>
      </a>
      <a href="<?php echo esc_url(get_permalink(get_page_by_path('contact'))); ?>" class="tr-btn tr-btn--ghost">
        <?php esc_html_e('Talk to an Expert', 'themeflex'); ?>
      </a>
    </div>
  </div>
</section>

<script>
(function(){
  'use strict';
  // Animated stat counters
  const counters = document.querySelectorAll('.tf-travel-page [data-counter]');
  if (!counters.length) return;
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const target = parseFloat(el.dataset.counter);
      const suffix = el.dataset.suffix || '';
      const isFloat = target % 1 !== 0;
      const duration = 1600;
      const start = performance.now();
      const update = (now) => {
        const progress = Math.min((now - start) / duration, 1);
        const ease = 1 - Math.pow(1 - progress, 3);
        const val = isFloat ? (target * ease).toFixed(1) : Math.round(target * ease).toLocaleString();
        el.textContent = val + suffix;
        if (progress < 1) requestAnimationFrame(update);
      };
      requestAnimationFrame(update);
      io.unobserve(el);
    });
  }, { threshold: 0.5 });
  counters.forEach(el => io.observe(el));
})();
</script>

</div><!-- .tf-travel-page -->
<?php get_footer(); ?>
