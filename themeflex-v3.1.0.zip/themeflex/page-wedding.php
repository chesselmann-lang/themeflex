<?php
/**
 * Template Name: Wedding & Events Homepage
 *
 * Premium Wedding & Events landing page template for ThemeFlex.
 * Art-directed hero: pure-CSS illustrated arch with floral SVG garlands,
 * rose-gold particle petals, animated ring motif. Zero external images.
 *
 * Palette:
 *   --wd-rose:    #e8a598  (blush rose)
 *   --wd-gold:    #c9a96e  (champagne gold)
 *   --wd-cream:   #fdf6f0  (ivory cream)
 *   --wd-sage:    #8aab8e  (eucalyptus sage)
 *   --wd-deep:    #1a0e0a  (deep warm black)
 *
 * @package ThemeFlex
 * @since   3.1.0
 */

get_header();
?>

<style>
/* ═══════════════════════════════════════════════════════════════
   WEDDING PAGE — TOKEN LAYER
   ═══════════════════════════════════════════════════════════════ */
.tf-wedding-page {
  --wd-rose:    #e8a598;
  --wd-rose-dk: #c97b6a;
  --wd-gold:    #c9a96e;
  --wd-gold-lt: #e8d5a8;
  --wd-cream:   #fdf6f0;
  --wd-ivory:   #f5ede3;
  --wd-sage:    #8aab8e;
  --wd-sage-dk: #5f7d63;
  --wd-deep:    #1a0e0a;
  --wd-warm:    #2d1c14;
  --wd-text:    #5a3d32;
  --wd-muted:   #9b7b6e;
  --wd-border:  rgba(201,169,110,.2);
  --wd-shadow:  0 8px 40px rgba(26,14,10,.12);

  background: var(--wd-cream);
  color: var(--wd-text);
  font-family: 'Inter', -apple-system, sans-serif;
  overflow-x: hidden;
}

/* ─── Typography helpers ──────────────────────────────────────── */
.tf-wedding-page .wd-serif {
  font-family: Georgia, 'Times New Roman', serif;
  font-style: italic;
}
.tf-wedding-page .wd-script {
  font-family: Georgia, serif;
  font-style: italic;
  letter-spacing: .04em;
}
.tf-wedding-page .wd-gold-text {
  background: linear-gradient(135deg, var(--wd-gold), var(--wd-rose));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
.tf-wedding-page .wd-eyebrow {
  font-size: .72rem;
  letter-spacing: .25em;
  text-transform: uppercase;
  color: var(--wd-gold);
  margin-bottom: .75rem;
}
.tf-wedding-page .wd-divider {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin: 1.5rem auto;
  max-width: 200px;
}
.tf-wedding-page .wd-divider::before,
.tf-wedding-page .wd-divider::after {
  content: '';
  flex: 1;
  height: 1px;
  background: linear-gradient(to right, transparent, var(--wd-gold));
}
.tf-wedding-page .wd-divider::after {
  background: linear-gradient(to left, transparent, var(--wd-gold));
}
.tf-wedding-page .wd-divider svg { flex-shrink: 0; }

/* ─── Section layout ──────────────────────────────────────────── */
.tf-wedding-page .wd-section {
  position: relative;
  padding: 6rem 1.5rem;
}
.tf-wedding-page .wd-container {
  max-width: 1200px;
  margin: 0 auto;
}
.tf-wedding-page .wd-grid-2 {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 4rem;
  align-items: center;
}
.tf-wedding-page .wd-grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 2rem; }
.tf-wedding-page .wd-grid-4 { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1.5rem; }

@media (max-width: 900px) {
  .tf-wedding-page .wd-grid-2,
  .tf-wedding-page .wd-grid-3,
  .tf-wedding-page .wd-grid-4 { grid-template-columns: 1fr; gap: 2rem; }
}
@media (max-width: 600px) {
  .tf-wedding-page .wd-section { padding: 4rem 1rem; }
}

/* ─── Buttons ─────────────────────────────────────────────────── */
.tf-wedding-page .wd-btn-primary {
  display: inline-flex;
  align-items: center;
  gap: .6rem;
  padding: .9rem 2.4rem;
  background: linear-gradient(135deg, var(--wd-gold), var(--wd-rose-dk));
  color: #fff;
  border-radius: 50px;
  font-weight: 600;
  font-size: .95rem;
  text-decoration: none;
  transition: transform .25s, box-shadow .25s;
  box-shadow: 0 4px 20px rgba(201,169,110,.35);
}
.tf-wedding-page .wd-btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 32px rgba(201,169,110,.5);
  color: #fff;
}
.tf-wedding-page .wd-btn-outline {
  display: inline-flex;
  align-items: center;
  gap: .6rem;
  padding: .85rem 2.2rem;
  border: 1.5px solid var(--wd-gold);
  color: var(--wd-gold);
  border-radius: 50px;
  font-weight: 600;
  font-size: .95rem;
  text-decoration: none;
  transition: all .25s;
  background: transparent;
}
.tf-wedding-page .wd-btn-outline:hover {
  background: var(--wd-gold);
  color: #fff;
}

/* ═══════════════════════════════════════════════════════════════
   HERO — Floral Arch Scene
   ═══════════════════════════════════════════════════════════════ */
.wd-hero {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  position: relative;
  overflow: hidden;
  background: linear-gradient(160deg, #fdf6f0 0%, #f9ede0 40%, #f5e4d3 100%);
  text-align: center;
  padding: 7rem 1.5rem 5rem;
}

/* Petals canvas */
.wd-petals { position: absolute; inset: 0; pointer-events: none; overflow: hidden; }
.wd-petal {
  position: absolute;
  width: 8px;
  height: 12px;
  border-radius: 80% 0 80% 0;
  opacity: 0;
  animation: wd-fall linear infinite;
}
.wd-petal:nth-child(odd)  { background: rgba(232,165,152,.5); border-radius: 0 80% 0 80%; }
.wd-petal:nth-child(even) { background: rgba(201,169,110,.3); }
.wd-petal:nth-child(3n)   { background: rgba(138,171,142,.35); width:6px; height:9px; }
@keyframes wd-fall {
  0%   { opacity: 0; transform: translateY(-40px) rotate(0deg) translateX(0); }
  10%  { opacity: .8; }
  90%  { opacity: .5; }
  100% { opacity: 0; transform: translateY(110vh) rotate(360deg) translateX(30px); }
}
<?php
$wd_petal_positions = [5,12,18,25,32,40,47,55,62,70,78,85,92,8,22,38,52,68,82];
$wd_petal_delays    = [0,1.2,2.4,0.6,3.1,1.8,4.2,0.3,2.7,3.8,1.1,4.6,0.9,2.1,3.5,1.5,4.0,0.7,2.9];
$wd_petal_durations = [8,10,7,9,11,8,10,9,7,11,8,10,9,7,8,11,10,9,8];
foreach ( $wd_petal_positions as $i => $pos ) {
  $delay = $wd_petal_delays[ $i ] ?? 0;
  $dur   = $wd_petal_durations[ $i ] ?? 9;
  echo ".wd-petal:nth-child(" . ($i+1) . "){left:{$pos}%;animation-duration:{$dur}s;animation-delay:-{$delay}s;}\n";
}
?>

/* Arch structure */
.wd-arch-wrap {
  position: relative;
  width: min(420px, 90vw);
  margin: 0 auto 3rem;
}
.wd-arch-svg { width: 100%; height: auto; }

/* Floating rings above arch */
.wd-rings {
  position: absolute;
  top: -30px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  gap: -8px;
}
.wd-ring {
  width: 42px;
  height: 42px;
  border-radius: 50%;
  border: 3px solid var(--wd-gold);
  position: relative;
  animation: wd-ring-sway 4s ease-in-out infinite;
  box-shadow: inset 0 0 8px rgba(201,169,110,.2), 0 2px 8px rgba(201,169,110,.3);
}
.wd-ring:first-child  { margin-right: -14px; animation-delay: 0s; }
.wd-ring:last-child   { margin-left:  -14px; animation-delay: .4s; }
.wd-ring::after {
  content: '';
  position: absolute;
  inset: 4px;
  border-radius: 50%;
  background: linear-gradient(135deg, rgba(201,169,110,.15), transparent);
}
@keyframes wd-ring-sway {
  0%,100% { transform: translateY(0) rotate(-3deg); }
  50%      { transform: translateY(-6px) rotate(3deg); }
}

/* Hero text */
.wd-hero-eyebrow {
  font-size: .72rem;
  letter-spacing: .3em;
  text-transform: uppercase;
  color: var(--wd-gold);
  margin-bottom: 1rem;
}
.wd-hero-title {
  font-size: clamp(2.8rem, 7vw, 5.5rem);
  line-height: 1.1;
  color: var(--wd-deep);
  margin-bottom: .5rem;
  font-family: Georgia, serif;
  font-style: italic;
}
.wd-hero-tagline {
  font-size: clamp(.95rem, 2vw, 1.2rem);
  color: var(--wd-muted);
  max-width: 540px;
  margin: 1.25rem auto 2.5rem;
  line-height: 1.7;
  font-style: italic;
}
.wd-hero-actions { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; }

/* Scroll hint */
.wd-scroll-hint {
  position: absolute;
  bottom: 2rem;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: .5rem;
  color: var(--wd-muted);
  font-size: .7rem;
  letter-spacing: .1em;
  text-transform: uppercase;
}
.wd-scroll-mouse {
  width: 22px;
  height: 34px;
  border: 1.5px solid var(--wd-gold);
  border-radius: 11px;
  position: relative;
}
.wd-scroll-mouse::after {
  content: '';
  width: 3px;
  height: 6px;
  background: var(--wd-gold);
  border-radius: 2px;
  position: absolute;
  top: 5px;
  left: 50%;
  transform: translateX(-50%);
  animation: wd-scroll-dot 1.6s ease-in-out infinite;
}
@keyframes wd-scroll-dot { 0%,100%{opacity:1;top:5px} 50%{opacity:0;top:16px} }

/* ═══════════════════════════════════════════════════════════════
   STATS BAR
   ═══════════════════════════════════════════════════════════════ */
.wd-stats-bar {
  background: linear-gradient(135deg, var(--wd-deep) 0%, var(--wd-warm) 100%);
  padding: 3rem 1.5rem;
}
.wd-stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 2rem;
  text-align: center;
  max-width: 1000px;
  margin: 0 auto;
}
.wd-stat-num {
  font-size: 2.5rem;
  font-weight: 700;
  font-family: Georgia, serif;
  background: linear-gradient(135deg, var(--wd-gold-lt), var(--wd-rose));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
.wd-stat-label { color: rgba(255,255,255,.55); font-size: .8rem; letter-spacing: .1em; text-transform: uppercase; margin-top: .25rem; }
@media (max-width:700px){ .wd-stats-grid{ grid-template-columns:1fr 1fr; } }

/* ═══════════════════════════════════════════════════════════════
   SERVICES — What We Offer
   ═══════════════════════════════════════════════════════════════ */
.wd-services { background: var(--wd-ivory); }
.wd-services-head { text-align: center; margin-bottom: 3.5rem; }
.wd-services-head h2 { font-size: clamp(1.8rem, 4vw, 2.8rem); color: var(--wd-deep); font-family: Georgia, serif; font-style: italic; }
.wd-services-head p  { color: var(--wd-muted); max-width: 560px; margin: 1rem auto 0; line-height: 1.7; }

.wd-service-card {
  background: var(--wd-cream);
  border: 1px solid var(--wd-border);
  border-radius: 20px;
  padding: 2.5rem 2rem;
  text-align: center;
  transition: transform .3s, box-shadow .3s;
}
.wd-service-card:hover { transform: translateY(-6px); box-shadow: var(--wd-shadow); }
.wd-service-icon {
  width: 70px;
  height: 70px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 1.5rem;
  background: linear-gradient(135deg, rgba(201,169,110,.15), rgba(232,165,152,.15));
  border: 1px solid var(--wd-border);
}
.wd-service-icon svg { stroke: var(--wd-gold); }
.wd-service-card h3 { font-size: 1.15rem; color: var(--wd-deep); margin-bottom: .75rem; font-family: Georgia, serif; font-style: italic; }
.wd-service-card p  { font-size: .9rem; color: var(--wd-muted); line-height: 1.7; }

/* ═══════════════════════════════════════════════════════════════
   ABOUT — Story Section (asymmetric 2-col)
   ═══════════════════════════════════════════════════════════════ */
.wd-about { background: var(--wd-cream); }
.wd-about-visual {
  position: relative;
  min-height: 460px;
}
/* CSS-art polaroid stack */
.wd-polaroid {
  position: absolute;
  background: #fff;
  padding: 1rem 1rem .5rem;
  box-shadow: 0 8px 30px rgba(26,14,10,.15);
  border-radius: 2px;
}
.wd-polaroid-inner {
  border-radius: 2px;
  overflow: hidden;
}
.wd-polaroid-img {
  width: 100%;
  aspect-ratio: 4/3;
  display: block;
}
/* Polaroid A — main large, slightly tilted left */
.wd-polaroid-a {
  width: 280px;
  top: 0;
  left: 0;
  transform: rotate(-3deg);
  z-index: 2;
}
.wd-polaroid-a .wd-polaroid-img {
  background: linear-gradient(135deg, #f5d9d0 0%, #e8c4ae 40%, #d9b090 100%);
}
/* Floral garland inside */
.wd-polaroid-a .wd-polaroid-img::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(circle at 20% 20%, rgba(232,165,152,.6) 12px, transparent 13px),
    radial-gradient(circle at 80% 15%, rgba(201,169,110,.5) 9px, transparent 10px),
    radial-gradient(circle at 50% 50%, rgba(138,171,142,.4) 6px, transparent 7px),
    radial-gradient(circle at 30% 75%, rgba(232,165,152,.5) 10px, transparent 11px),
    radial-gradient(circle at 75% 80%, rgba(201,169,110,.4) 8px, transparent 9px);
}
/* Couple silhouette */
.wd-polaroid-a .wd-polaroid-img::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 140px;
  height: 140px;
  background: rgba(100,60,40,.25);
  clip-path: polygon(
    25% 100%, 25% 65%, 20% 60%, 20% 45%, 25% 40%, 30% 45%, 30% 60%, 25% 65%,
    38% 100%, 38% 60%, 36% 55%, 36% 38%, 42% 34%, 44% 38%, 44% 55%, 42% 60%, 38% 60%,
    56% 100%, 56% 60%, 54% 55%, 54% 38%, 60% 34%, 62% 38%, 62% 55%, 60% 60%, 56% 60%,
    75% 100%, 75% 65%, 70% 60%, 70% 45%, 75% 40%, 80% 45%, 80% 60%, 75% 65%
  );
}
/* Polaroid B — smaller, tilted right */
.wd-polaroid-b {
  width: 210px;
  top: 60px;
  right: 0;
  transform: rotate(4deg);
  z-index: 3;
}
.wd-polaroid-b .wd-polaroid-img {
  background: linear-gradient(135deg, #e8d5a8 0%, #d4b87a 60%, #c9a96e 100%);
}
/* Rings illustration */
.wd-polaroid-b .wd-polaroid-img::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(circle at 38% 55%, transparent 28px, rgba(201,169,110,.9) 28px, rgba(201,169,110,.9) 32px, transparent 33px),
    radial-gradient(circle at 58% 55%, transparent 28px, rgba(201,169,110,.9) 28px, rgba(201,169,110,.9) 32px, transparent 33px),
    radial-gradient(circle at 48% 55%, transparent 22px, rgba(245,229,188,.5) 22px, rgba(245,229,188,.5) 26px, transparent 27px);
}
/* Polaroid C — flowers, bottom, centered */
.wd-polaroid-c {
  width: 180px;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%) rotate(-2deg);
  z-index: 4;
}
.wd-polaroid-c .wd-polaroid-img {
  background: linear-gradient(160deg, #f0e8f0 0%, #e8d5e8 50%, #d5c0d5 100%);
}
.wd-polaroid-c .wd-polaroid-img::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(circle at 30% 40%, rgba(232,165,152,.8) 14px, transparent 15px),
    radial-gradient(circle at 30% 40%, rgba(255,200,190,.5) 20px, transparent 21px),
    radial-gradient(circle at 65% 35%, rgba(201,169,110,.7) 10px, transparent 11px),
    radial-gradient(circle at 65% 35%, rgba(245,220,150,.4) 16px, transparent 17px),
    radial-gradient(circle at 50% 65%, rgba(138,171,142,.6) 11px, transparent 12px),
    radial-gradient(circle at 50% 65%, rgba(180,210,184,.4) 17px, transparent 18px),
    radial-gradient(circle at 80% 60%, rgba(232,165,152,.5) 8px, transparent 9px);
}

.wd-about-content { display: flex; flex-direction: column; justify-content: center; }
.wd-about-content h2 { font-size: clamp(1.8rem, 3.5vw, 2.6rem); color: var(--wd-deep); font-family: Georgia, serif; font-style: italic; line-height: 1.25; margin-bottom: 1.25rem; }
.wd-about-content p  { color: var(--wd-muted); line-height: 1.8; margin-bottom: 1rem; font-size: .95rem; }
.wd-about-features { display: grid; grid-template-columns: 1fr 1fr; gap: .75rem; margin: 1.5rem 0 2rem; }
.wd-about-feat {
  display: flex;
  align-items: center;
  gap: .5rem;
  font-size: .88rem;
  color: var(--wd-text);
}
.wd-about-feat::before {
  content: '';
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--wd-gold);
  flex-shrink: 0;
}

/* ═══════════════════════════════════════════════════════════════
   PACKAGES — Pricing
   ═══════════════════════════════════════════════════════════════ */
.wd-packages { background: var(--wd-ivory); }
.wd-pkg-head { text-align: center; margin-bottom: 3.5rem; }
.wd-pkg-head h2 { font-size: clamp(1.8rem, 4vw, 2.8rem); color: var(--wd-deep); font-family: Georgia, serif; font-style: italic; }
.wd-pkg-head p  { color: var(--wd-muted); max-width: 520px; margin: .75rem auto 0; }

.wd-pkg-card {
  background: var(--wd-cream);
  border: 1px solid var(--wd-border);
  border-radius: 24px;
  padding: 2.5rem 2rem;
  display: flex;
  flex-direction: column;
  gap: .5rem;
  transition: transform .3s, box-shadow .3s;
  position: relative;
  overflow: hidden;
}
.wd-pkg-card:hover { transform: translateY(-6px); box-shadow: var(--wd-shadow); }
.wd-pkg-card--featured {
  border-color: var(--wd-gold);
  background: linear-gradient(160deg, #fff 0%, #fdf8f2 100%);
}
.wd-pkg-card--featured::before {
  content: 'Most Popular';
  position: absolute;
  top: 1.25rem;
  right: -2rem;
  background: linear-gradient(135deg, var(--wd-gold), var(--wd-rose-dk));
  color: #fff;
  font-size: .65rem;
  font-weight: 700;
  letter-spacing: .1em;
  text-transform: uppercase;
  padding: .35rem 2.5rem;
  transform: rotate(45deg);
}
/* Corner flourish */
.wd-pkg-card--featured::after {
  content: '';
  position: absolute;
  bottom: -30px;
  right: -30px;
  width: 100px;
  height: 100px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(201,169,110,.1) 0%, transparent 70%);
}
.wd-pkg-name { font-size: .75rem; letter-spacing: .2em; text-transform: uppercase; color: var(--wd-gold); }
.wd-pkg-title { font-size: 1.5rem; color: var(--wd-deep); font-family: Georgia, serif; font-style: italic; }
.wd-pkg-price { display: flex; align-items: flex-end; gap: .25rem; margin: .75rem 0; }
.wd-pkg-currency { font-size: 1.25rem; color: var(--wd-gold); line-height: 2; }
.wd-pkg-amount { font-size: 3rem; font-weight: 700; color: var(--wd-deep); line-height: 1; }
.wd-pkg-period { color: var(--wd-muted); font-size: .85rem; margin-bottom: .25rem; }
.wd-pkg-desc { color: var(--wd-muted); font-size: .88rem; line-height: 1.6; padding-bottom: 1rem; border-bottom: 1px solid var(--wd-border); margin-bottom: 1rem; }
.wd-pkg-features { list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: .6rem; flex: 1; }
.wd-pkg-features li { display: flex; align-items: flex-start; gap: .6rem; font-size: .88rem; color: var(--wd-text); }
.wd-pkg-features li::before { content: '✦'; color: var(--wd-gold); font-size: .65rem; margin-top: .2rem; flex-shrink: 0; }
.wd-pkg-features li.wd-unavail { color: var(--wd-muted); }
.wd-pkg-features li.wd-unavail::before { content: '✦'; color: rgba(0,0,0,.15); }
.wd-pkg-cta { margin-top: 1.75rem; }
.wd-pkg-cta a { display: block; text-align: center; }

/* ═══════════════════════════════════════════════════════════════
   GALLERY — Masonry-inspired CSS grid
   ═══════════════════════════════════════════════════════════════ */
.wd-gallery { background: var(--wd-cream); }
.wd-gallery-head { text-align: center; margin-bottom: 3rem; }
.wd-gallery-head h2 { font-size: clamp(1.8rem, 4vw, 2.8rem); color: var(--wd-deep); font-family: Georgia, serif; font-style: italic; }

.wd-gallery-grid {
  display: grid;
  grid-template-columns: repeat(12, 1fr);
  grid-template-rows: auto;
  gap: 1rem;
  max-width: 1200px;
  margin: 0 auto;
}
.wd-gallery-item {
  border-radius: 12px;
  overflow: hidden;
  position: relative;
}
.wd-gallery-item-inner {
  width: 100%;
  height: 100%;
  min-height: 200px;
  border-radius: 12px;
  transition: transform .4s ease;
}
.wd-gallery-item:hover .wd-gallery-item-inner { transform: scale(1.04); }

/* Grid placement */
.wd-gallery-item:nth-child(1) { grid-column: 1/6;  grid-row: 1; }
.wd-gallery-item:nth-child(2) { grid-column: 6/9;  grid-row: 1; }
.wd-gallery-item:nth-child(3) { grid-column: 9/13; grid-row: 1/3; }
.wd-gallery-item:nth-child(4) { grid-column: 1/4;  grid-row: 2/4; }
.wd-gallery-item:nth-child(5) { grid-column: 4/9;  grid-row: 2; }
.wd-gallery-item:nth-child(6) { grid-column: 4/7;  grid-row: 3; }
.wd-gallery-item:nth-child(7) { grid-column: 7/13; grid-row: 3; }

/* Color palettes for CSS art gallery items */
.wd-gallery-item:nth-child(1) .wd-gallery-item-inner { background: linear-gradient(135deg, #f5d9d0 0%, #e8b4a0 50%, #d99070 100%); min-height: 240px; }
.wd-gallery-item:nth-child(2) .wd-gallery-item-inner { background: linear-gradient(160deg, #e8d5a8 0%, #c9a96e 100%); min-height: 240px; }
.wd-gallery-item:nth-child(3) .wd-gallery-item-inner { background: linear-gradient(180deg, #d5e8d8 0%, #8aab8e 100%); min-height: 500px; }
.wd-gallery-item:nth-child(4) .wd-gallery-item-inner { background: linear-gradient(180deg, #f0e0e8 0%, #d5a0b8 100%); min-height: 480px; }
.wd-gallery-item:nth-child(5) .wd-gallery-item-inner { background: linear-gradient(135deg, #fdf6f0 0%, #f0d8c8 100%); min-height: 240px; }
.wd-gallery-item:nth-child(6) .wd-gallery-item-inner { background: linear-gradient(135deg, #1a0e0a 0%, #3d2014 100%); min-height: 240px; }
.wd-gallery-item:nth-child(7) .wd-gallery-item-inner { background: linear-gradient(135deg, #e8c4ae 0%, #c9a080 100%); min-height: 240px; }

/* CSS art overlays on gallery items */
.wd-gallery-item:nth-child(1) .wd-gallery-item-inner::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(circle at 50% 30%, rgba(255,255,255,.2) 40%, transparent 41%),
    radial-gradient(circle at 20% 80%, rgba(232,165,152,.4) 20px, transparent 21px),
    radial-gradient(circle at 80% 75%, rgba(201,169,110,.35) 15px, transparent 16px);
}
/* Bouquet on item 2 */
.wd-gallery-item:nth-child(2) .wd-gallery-item-inner::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(ellipse 80% 60% at 50% 70%, rgba(232,165,152,.5) 0%, transparent 100%),
    radial-gradient(circle at 35% 30%, rgba(255,200,200,.6) 18px, transparent 19px),
    radial-gradient(circle at 65% 25%, rgba(255,200,200,.5) 14px, transparent 15px),
    radial-gradient(circle at 50% 20%, rgba(255,220,180,.6) 16px, transparent 17px),
    radial-gradient(circle at 30% 50%, rgba(138,171,142,.4) 8px, transparent 9px),
    radial-gradient(circle at 70% 55%, rgba(138,171,142,.4) 10px, transparent 11px);
}
/* Table setting on item 5 */
.wd-gallery-item:nth-child(5) .wd-gallery-item-inner::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(ellipse 60% 8% at 50% 50%, rgba(201,169,110,.3) 0%, transparent 100%),
    radial-gradient(circle at 50% 35%, rgba(201,169,110,.4) 25px, transparent 26px),
    radial-gradient(circle at 50% 35%, rgba(245,229,188,.3) 35px, transparent 36px);
}
/* Night sky on item 6 */
.wd-gallery-item:nth-child(6) .wd-gallery-item-inner::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(circle at 20% 20%, rgba(201,169,110,.8) 2px, transparent 3px),
    radial-gradient(circle at 45% 15%, rgba(201,169,110,.6) 1.5px, transparent 2.5px),
    radial-gradient(circle at 70% 25%, rgba(201,169,110,.7) 2px, transparent 3px),
    radial-gradient(circle at 85% 10%, rgba(201,169,110,.5) 1px, transparent 2px),
    radial-gradient(circle at 60% 40%, rgba(201,169,110,.6) 1.5px, transparent 2.5px),
    radial-gradient(ellipse 70% 30% at 50% 80%, rgba(201,169,110,.1) 0%, transparent 100%);
}

.wd-gallery-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(to top, rgba(26,14,10,.6) 0%, transparent 50%);
  display: flex;
  align-items: flex-end;
  padding: 1.25rem;
  opacity: 0;
  transition: opacity .35s;
}
.wd-gallery-item:hover .wd-gallery-overlay { opacity: 1; }
.wd-gallery-label { color: #fff; font-size: .8rem; font-family: Georgia, serif; font-style: italic; }

@media (max-width: 900px) {
  .wd-gallery-grid { grid-template-columns: 1fr 1fr; }
  .wd-gallery-item { grid-column: auto !important; grid-row: auto !important; }
  .wd-gallery-item .wd-gallery-item-inner { min-height: 200px !important; }
}

/* ═══════════════════════════════════════════════════════════════
   TESTIMONIALS
   ═══════════════════════════════════════════════════════════════ */
.wd-testimonials { background: var(--wd-ivory); }
.wd-testi-head { text-align: center; margin-bottom: 3rem; }
.wd-testi-head h2 { font-size: clamp(1.8rem, 4vw, 2.6rem); color: var(--wd-deep); font-family: Georgia, serif; font-style: italic; }

.wd-testi-card {
  background: var(--wd-cream);
  border: 1px solid var(--wd-border);
  border-radius: 20px;
  padding: 2.5rem 2rem;
  position: relative;
}
.wd-testi-card::before {
  content: '\201C';
  position: absolute;
  top: 1.25rem;
  left: 1.5rem;
  font-size: 4rem;
  font-family: Georgia, serif;
  color: var(--wd-gold);
  opacity: .3;
  line-height: 1;
}
.wd-testi-stars {
  display: flex;
  gap: .2rem;
  margin-bottom: 1rem;
}
.wd-testi-stars span {
  color: var(--wd-gold);
  font-size: .9rem;
}
.wd-testi-text { color: var(--wd-text); line-height: 1.8; font-style: italic; margin-bottom: 1.5rem; font-size: .95rem; }
.wd-testi-couple {
  display: flex;
  align-items: center;
  gap: .875rem;
}
.wd-testi-avatar {
  width: 46px;
  height: 46px;
  border-radius: 50%;
  border: 2px solid var(--wd-gold);
  overflow: hidden;
}
.wd-testi-avatar-inner {
  width: 100%;
  height: 100%;
}
/* CSS art avatar */
.wd-testi-avatar:nth-of-type(1) .wd-testi-avatar-inner { background: linear-gradient(135deg, #f5d9d0, #e8a598); }
.wd-testi-avatar:nth-of-type(2) .wd-testi-avatar-inner { background: linear-gradient(135deg, #e8d5a8, #c9a96e); }
.wd-testi-name { font-weight: 700; color: var(--wd-deep); font-size: .95rem; font-family: Georgia, serif; font-style: italic; }
.wd-testi-date { font-size: .78rem; color: var(--wd-muted); }

/* ═══════════════════════════════════════════════════════════════
   TEAM — Our Planners
   ═══════════════════════════════════════════════════════════════ */
.wd-team { background: var(--wd-cream); }
.wd-team-head { text-align: center; margin-bottom: 3rem; }
.wd-team-head h2 { font-size: clamp(1.8rem, 4vw, 2.6rem); color: var(--wd-deep); font-family: Georgia, serif; font-style: italic; }
.wd-team-head p  { color: var(--wd-muted); max-width: 500px; margin: .75rem auto 0; }

.wd-team-card {
  text-align: center;
  transition: transform .3s;
}
.wd-team-card:hover { transform: translateY(-4px); }
.wd-team-photo {
  width: 160px;
  height: 160px;
  border-radius: 50%;
  margin: 0 auto 1.25rem;
  overflow: hidden;
  border: 3px solid var(--wd-gold);
  position: relative;
}
.wd-team-photo-inner { width: 100%; height: 100%; }
.wd-team-card:nth-child(1) .wd-team-photo-inner { background: linear-gradient(160deg, #f5d9d0 0%, #c97b6a 100%); }
.wd-team-card:nth-child(2) .wd-team-photo-inner { background: linear-gradient(160deg, #e8d5a8 0%, #8a6a30 100%); }
.wd-team-card:nth-child(3) .wd-team-photo-inner { background: linear-gradient(160deg, #d5e8d8 0%, #5f7d63 100%); }
.wd-team-card:nth-child(4) .wd-team-photo-inner { background: linear-gradient(160deg, #f0d8c8 0%, #8a5030 100%); }
/* Silhouette */
.wd-team-photo-inner::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 80px;
  height: 100px;
  background: rgba(0,0,0,.2);
  clip-path: ellipse(40% 50% at 50% 100%);
}
.wd-team-name { font-size: 1.1rem; color: var(--wd-deep); font-family: Georgia, serif; font-style: italic; margin-bottom: .25rem; }
.wd-team-role { font-size: .8rem; color: var(--wd-gold); letter-spacing: .1em; text-transform: uppercase; margin-bottom: .75rem; }
.wd-team-bio  { font-size: .85rem; color: var(--wd-muted); line-height: 1.6; }

/* ═══════════════════════════════════════════════════════════════
   VENUES — Featured Locations
   ═══════════════════════════════════════════════════════════════ */
.wd-venues { background: var(--wd-ivory); }
.wd-venues-head { text-align: center; margin-bottom: 3rem; }
.wd-venues-head h2 { font-size: clamp(1.8rem, 4vw, 2.6rem); color: var(--wd-deep); font-family: Georgia, serif; font-style: italic; }

.wd-venue-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1.5rem;
}
.wd-venue-card {
  border-radius: 16px;
  overflow: hidden;
  box-shadow: var(--wd-shadow);
  transition: transform .3s;
}
.wd-venue-card:hover { transform: translateY(-5px); }
.wd-venue-img {
  height: 220px;
  position: relative;
  overflow: hidden;
}
.wd-venue-img-inner {
  width: 100%;
  height: 100%;
  transition: transform .5s;
}
.wd-venue-card:hover .wd-venue-img-inner { transform: scale(1.06); }
.wd-venue-card:nth-child(1) .wd-venue-img-inner { background: linear-gradient(160deg, #1a0e0a 0%, #3d1a0a 40%, #5d3020 100%); }
.wd-venue-card:nth-child(2) .wd-venue-img-inner { background: linear-gradient(160deg, #0a1520 0%, #103050 50%, #2060a0 100%); }
.wd-venue-card:nth-child(3) .wd-venue-img-inner { background: linear-gradient(160deg, #0a1a08 0%, #1a3a10 40%, #2a5a18 100%); }

/* Castle silhouette on venue 1 */
.wd-venue-card:nth-child(1) .wd-venue-img-inner::before {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 100%;
  height: 60%;
  background: rgba(90,40,15,.5);
  clip-path: polygon(
    0% 100%, 0% 70%, 5% 70%, 5% 55%, 10% 55%, 10% 70%,
    20% 70%, 20% 40%, 23% 40%, 23% 30%, 30% 30%, 30% 20%, 35% 15%,
    40% 20%, 40% 30%, 45% 30%, 50% 15%, 55% 30%, 60% 30%,
    60% 20%, 65% 15%, 70% 20%, 70% 30%, 77% 30%, 77% 40%,
    80% 40%, 80% 70%, 90% 70%, 90% 55%, 95% 55%, 95% 70%, 100% 70%, 100% 100%
  );
}

/* Ocean/beach on venue 2 */
.wd-venue-card:nth-child(2) .wd-venue-img-inner::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(ellipse 120% 30% at 50% 100%, rgba(32,120,200,.8) 0%, transparent 100%),
    radial-gradient(circle at 70% 25%, rgba(255,220,100,.5) 25px, transparent 26px),
    radial-gradient(circle at 70% 25%, rgba(255,180,50,.3) 40px, transparent 41px);
}

/* Garden on venue 3 */
.wd-venue-card:nth-child(3) .wd-venue-img-inner::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(ellipse 120% 25% at 50% 100%, rgba(20,70,15,.6) 0%, transparent 100%),
    radial-gradient(circle at 25% 40%, rgba(30,80,20,.5) 40px, transparent 41px),
    radial-gradient(circle at 75% 45%, rgba(30,80,20,.4) 30px, transparent 31px),
    radial-gradient(circle at 50% 60%, rgba(20,60,15,.3) 60px, transparent 61px);
}

.wd-venue-body { background: var(--wd-cream); padding: 1.5rem; }
.wd-venue-location { font-size: .75rem; color: var(--wd-gold); letter-spacing: .12em; text-transform: uppercase; margin-bottom: .5rem; }
.wd-venue-name { font-size: 1.2rem; color: var(--wd-deep); font-family: Georgia, serif; font-style: italic; margin-bottom: .5rem; }
.wd-venue-desc { font-size: .85rem; color: var(--wd-muted); line-height: 1.6; margin-bottom: 1rem; }
.wd-venue-tags { display: flex; flex-wrap: wrap; gap: .4rem; }
.wd-venue-tag {
  font-size: .7rem;
  padding: .25rem .7rem;
  border: 1px solid var(--wd-border);
  border-radius: 50px;
  color: var(--wd-muted);
  background: transparent;
}
@media (max-width: 800px) { .wd-venue-grid { grid-template-columns: 1fr; } }

/* ═══════════════════════════════════════════════════════════════
   FAQ
   ═══════════════════════════════════════════════════════════════ */
.wd-faq { background: var(--wd-cream); }
.wd-faq-wrap { max-width: 760px; margin: 0 auto; }
.wd-faq-head { text-align: center; margin-bottom: 3rem; }
.wd-faq-head h2 { font-size: clamp(1.8rem, 4vw, 2.6rem); color: var(--wd-deep); font-family: Georgia, serif; font-style: italic; }
.wd-faq-item { border-bottom: 1px solid var(--wd-border); }
.wd-faq-q {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 1.25rem 0;
  font-size: 1rem;
  color: var(--wd-deep);
  background: none;
  border: none;
  cursor: pointer;
  text-align: left;
  font-family: Georgia, serif;
  font-style: italic;
}
.wd-faq-q:hover { color: var(--wd-gold); }
.wd-faq-icon {
  width: 28px;
  height: 28px;
  border: 1.5px solid var(--wd-border);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  transition: border-color .2s;
}
.wd-faq-q:hover .wd-faq-icon { border-color: var(--wd-gold); }
.wd-faq-a { max-height: 0; overflow: hidden; transition: max-height .35s ease; }
.wd-faq-a p { padding: 0 0 1.25rem; color: var(--wd-muted); line-height: 1.8; font-size: .92rem; }
.wd-faq-item.open .wd-faq-a { max-height: 300px; }

/* ═══════════════════════════════════════════════════════════════
   CONTACT / INQUIRY FORM
   ═══════════════════════════════════════════════════════════════ */
.wd-contact {
  background: linear-gradient(160deg, var(--wd-deep) 0%, var(--wd-warm) 100%);
  position: relative;
  overflow: hidden;
}
.wd-contact::before {
  content: '';
  position: absolute;
  top: -100px;
  left: -100px;
  width: 400px;
  height: 400px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(201,169,110,.08) 0%, transparent 70%);
}
.wd-contact::after {
  content: '';
  position: absolute;
  bottom: -80px;
  right: -80px;
  width: 350px;
  height: 350px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(232,165,152,.08) 0%, transparent 70%);
}

.wd-contact-inner { display: grid; grid-template-columns: 1fr 1fr; gap: 4rem; align-items: start; position: relative; z-index: 1; }
.wd-contact-info h2 { font-size: clamp(1.8rem, 3.5vw, 2.5rem); color: #fff; font-family: Georgia, serif; font-style: italic; margin-bottom: 1rem; }
.wd-contact-info p  { color: rgba(255,255,255,.6); line-height: 1.8; margin-bottom: 2rem; }
.wd-contact-detail { display: flex; align-items: flex-start; gap: .875rem; margin-bottom: 1.25rem; }
.wd-contact-detail-icon {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: rgba(201,169,110,.15);
  border: 1px solid rgba(201,169,110,.25);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.wd-contact-detail-icon svg { stroke: var(--wd-gold-lt); }
.wd-contact-detail-text strong { display: block; color: var(--wd-gold-lt); font-size: .8rem; letter-spacing: .08em; text-transform: uppercase; margin-bottom: .2rem; }
.wd-contact-detail-text span  { color: rgba(255,255,255,.65); font-size: .9rem; }

.wd-contact-form {
  background: rgba(255,255,255,.05);
  backdrop-filter: blur(8px);
  border: 1px solid rgba(255,255,255,.1);
  border-radius: 24px;
  padding: 2.5rem 2rem;
}
.wd-form-title { font-size: 1.3rem; color: #fff; font-family: Georgia, serif; font-style: italic; margin-bottom: 1.75rem; }
.wd-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
.wd-form-group { margin-bottom: 1.25rem; }
.wd-form-group label { display: block; font-size: .78rem; color: rgba(255,255,255,.5); letter-spacing: .1em; text-transform: uppercase; margin-bottom: .5rem; }
.wd-form-group input,
.wd-form-group select,
.wd-form-group textarea {
  width: 100%;
  background: rgba(255,255,255,.06);
  border: 1px solid rgba(255,255,255,.12);
  border-radius: 10px;
  padding: .8rem 1rem;
  color: #fff;
  font-size: .9rem;
  transition: border-color .2s;
  font-family: inherit;
}
.wd-form-group input::placeholder,
.wd-form-group textarea::placeholder { color: rgba(255,255,255,.25); }
.wd-form-group select option { background: var(--wd-deep); }
.wd-form-group input:focus,
.wd-form-group select:focus,
.wd-form-group textarea:focus {
  outline: none;
  border-color: var(--wd-gold);
}
.wd-form-group textarea { resize: vertical; min-height: 100px; }
.wd-form-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  flex-wrap: wrap;
  margin-top: .5rem;
}
.wd-form-footer p { color: rgba(255,255,255,.4); font-size: .75rem; }

@media (max-width: 900px) {
  .wd-contact-inner { grid-template-columns: 1fr; gap: 2.5rem; }
  .wd-form-row { grid-template-columns: 1fr; }
}

/* ═══════════════════════════════════════════════════════════════
   CTA — Final Banner
   ═══════════════════════════════════════════════════════════════ */
.wd-cta {
  background: linear-gradient(135deg, var(--wd-gold) 0%, var(--wd-rose-dk) 100%);
  padding: 5rem 1.5rem;
  text-align: center;
  position: relative;
  overflow: hidden;
}
.wd-cta::before {
  content: '';
  position: absolute;
  inset: 0;
  background:
    radial-gradient(circle at 20% 50%, rgba(255,255,255,.1) 0%, transparent 50%),
    radial-gradient(circle at 80% 50%, rgba(255,255,255,.08) 0%, transparent 50%);
}
.wd-cta-inner { position: relative; z-index: 1; }
.wd-cta h2 { font-size: clamp(2rem, 5vw, 3.5rem); color: #fff; font-family: Georgia, serif; font-style: italic; margin-bottom: .75rem; }
.wd-cta p  { color: rgba(255,255,255,.8); font-size: 1.05rem; max-width: 560px; margin: 0 auto 2rem; }
.wd-cta .wd-btn-white {
  display: inline-flex;
  align-items: center;
  gap: .6rem;
  padding: 1rem 2.8rem;
  background: #fff;
  color: var(--wd-rose-dk);
  border-radius: 50px;
  font-weight: 700;
  font-size: 1rem;
  text-decoration: none;
  transition: transform .25s, box-shadow .25s;
  box-shadow: 0 4px 20px rgba(0,0,0,.15);
}
.wd-cta .wd-btn-white:hover { transform: translateY(-3px); box-shadow: 0 8px 32px rgba(0,0,0,.2); color: var(--wd-rose-dk); }
</style>

<div class="tf-wedding-page">

  <!-- ─── HERO ─────────────────────────────────────────────────── -->
  <section class="wd-hero">
    <!-- Falling petals -->
    <div class="wd-petals" aria-hidden="true">
      <?php for ( $i = 0; $i < 19; $i++ ) : ?>
        <div class="wd-petal"></div>
      <?php endfor; ?>
    </div>

    <!-- Rings -->
    <div class="wd-rings" aria-hidden="true">
      <div class="wd-ring"></div>
      <div class="wd-ring"></div>
    </div>

    <!-- Arch illustration -->
    <div class="wd-arch-wrap" aria-hidden="true">
      <svg class="wd-arch-svg" viewBox="0 0 420 360" fill="none" xmlns="http://www.w3.org/2000/svg">
        <!-- Arch frame -->
        <path d="M 60,355 L 60,160 Q 60,60 210,60 Q 360,60 360,160 L 360,355"
              stroke="#c9a96e" stroke-width="3" fill="rgba(253,246,240,0)" stroke-linecap="round"/>
        <!-- Inner arch -->
        <path d="M 90,355 L 90,172 Q 90,95 210,95 Q 330,95 330,172 L 330,355"
              stroke="rgba(201,169,110,.35)" stroke-width="1.5" fill="none" stroke-dasharray="6 4"/>

        <!-- Left floral garland -->
        <g opacity=".85">
          <circle cx="68" cy="155" r="12" fill="#e8a598" opacity=".7"/>
          <circle cx="58" cy="172" r="8"  fill="#c9a96e" opacity=".6"/>
          <circle cx="72" cy="188" r="10" fill="#8aab8e" opacity=".65"/>
          <circle cx="62" cy="205" r="7"  fill="#e8a598" opacity=".5"/>
          <circle cx="72" cy="220" r="9"  fill="#c9a96e" opacity=".6"/>
          <circle cx="63" cy="238" r="6"  fill="#e8a598" opacity=".5"/>
          <!-- Leaves -->
          <ellipse cx="55" cy="163" rx="6" ry="10" fill="#8aab8e" opacity=".5" transform="rotate(-30 55 163)"/>
          <ellipse cx="80" cy="196" rx="5" ry="9"  fill="#8aab8e" opacity=".45" transform="rotate(20 80 196)"/>
          <ellipse cx="55" cy="228" rx="6" ry="8"  fill="#8aab8e" opacity=".4" transform="rotate(-15 55 228)"/>
        </g>

        <!-- Right floral garland -->
        <g opacity=".85">
          <circle cx="352" cy="155" r="12" fill="#e8a598" opacity=".7"/>
          <circle cx="362" cy="172" r="8"  fill="#c9a96e" opacity=".6"/>
          <circle cx="348" cy="188" r="10" fill="#8aab8e" opacity=".65"/>
          <circle cx="358" cy="205" r="7"  fill="#e8a598" opacity=".5"/>
          <circle cx="348" cy="220" r="9"  fill="#c9a96e" opacity=".6"/>
          <circle cx="357" cy="238" r="6"  fill="#e8a598" opacity=".5"/>
          <!-- Leaves -->
          <ellipse cx="365" cy="163" rx="6" ry="10" fill="#8aab8e" opacity=".5" transform="rotate(30 365 163)"/>
          <ellipse cx="340" cy="196" rx="5" ry="9"  fill="#8aab8e" opacity=".45" transform="rotate(-20 340 196)"/>
          <ellipse cx="365" cy="228" rx="6" ry="8"  fill="#8aab8e" opacity=".4" transform="rotate(15 365 228)"/>
        </g>

        <!-- Top floral crown -->
        <g opacity=".9">
          <circle cx="210" cy="60"  r="16" fill="#e8a598" opacity=".6"/>
          <circle cx="180" cy="68"  r="11" fill="#c9a96e" opacity=".55"/>
          <circle cx="240" cy="68"  r="11" fill="#c9a96e" opacity=".55"/>
          <circle cx="160" cy="82"  r="9"  fill="#8aab8e" opacity=".6"/>
          <circle cx="260" cy="82"  r="9"  fill="#8aab8e" opacity=".6"/>
          <circle cx="143" cy="100" r="7"  fill="#e8a598" opacity=".45"/>
          <circle cx="277" cy="100" r="7"  fill="#e8a598" opacity=".45"/>
          <!-- Petals on crown center -->
          <?php
          $petal_angles = [0, 45, 90, 135, 180, 225, 270, 315];
          foreach ( $petal_angles as $ang ) {
            $rad = deg2rad( $ang );
            $px  = round( 210 + 10 * cos( $rad ), 1 );
            $py  = round( 60 + 10 * sin( $rad ), 1 );
            echo "<circle cx=\"{$px}\" cy=\"{$py}\" r=\"4\" fill=\"#e8d5a8\" opacity=\".5\"/>\n";
          }
          ?>
          <circle cx="210" cy="60" r="5" fill="#c9a96e" opacity=".8"/>
        </g>

        <!-- Candles at base corners -->
        <rect x="80"  y="300" width="8"  height="55" rx="2" fill="#e8d5a8" opacity=".7"/>
        <ellipse cx="84"  cy="298" rx="5" ry="7" fill="#f59e0b" opacity=".6"/>
        <rect x="332" y="300" width="8"  height="55" rx="2" fill="#e8d5a8" opacity=".7"/>
        <ellipse cx="336" cy="298" rx="5" ry="7" fill="#f59e0b" opacity=".6"/>

        <!-- Altar table -->
        <rect x="140" y="310" width="140" height="8"  rx="4" fill="#c9a96e" opacity=".5"/>
        <rect x="150" y="318" width="4"   height="40" rx="2" fill="#c9a96e" opacity=".4"/>
        <rect x="266" y="318" width="4"   height="40" rx="2" fill="#c9a96e" opacity=".4"/>
        <!-- Bouquet on altar -->
        <circle cx="210" cy="305" r="14" fill="#e8a598" opacity=".5"/>
        <circle cx="200" cy="310" r="9"  fill="#c9a96e" opacity=".45"/>
        <circle cx="220" cy="308" r="10" fill="#8aab8e" opacity=".45"/>
        <circle cx="210" cy="295" r="8"  fill="#e8d5a8" opacity=".5"/>
      </svg>
    </div>

    <!-- Text -->
    <p class="wd-hero-eyebrow">Est. Since 2008 · Award-Winning Wedding Studio</p>
    <h1 class="wd-hero-title">
      Where Every<br><em>Love Story</em><br>Becomes<br>a Masterpiece
    </h1>
    <p class="wd-hero-tagline">
      Bespoke wedding planning &amp; design, crafted with heart, executed with flawless precision.
    </p>
    <div class="wd-hero-actions">
      <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>" class="wd-btn-primary">
        <?php echo tf_icon_get('calendar', 20, 20); ?>
        Begin Planning Together
      </a>
      <a href="<?php echo esc_url( home_url( '/gallery' ) ); ?>" class="wd-btn-outline">
        <?php echo tf_icon_get('image', 20, 20); ?>
        View Our Work
      </a>
    </div>

    <!-- Scroll hint -->
    <div class="wd-scroll-hint" aria-hidden="true">
      <div class="wd-scroll-mouse"></div>
      <span>Discover</span>
    </div>
  </section>

  <!-- ─── STATS ────────────────────────────────────────────────── -->
  <section class="wd-stats-bar" aria-label="<?php esc_attr_e('Key figures','themeflex'); ?>">
    <div class="wd-stats-grid">
      <?php
      $wd_stats = [
        [ '1,240', '+', 'Weddings Planned' ],
        [ '18',    '',  'Years of Excellence' ],
        [ '97',    '%', 'Couples Return Us for Referrals' ],
        [ '4.9',   '★', 'Average Client Rating' ],
      ];
      foreach ( $wd_stats as $s ) :
      ?>
      <div class="wd-stat" role="group">
        <div class="wd-stat-num" data-counter="<?php echo esc_attr( preg_replace('/[^0-9.]/','',$s[0]) ); ?>" data-suffix="<?php echo esc_attr( $s[1] ); ?>" data-prefix="<?php echo esc_attr( strpos($s[0],',') !== false ? '' : '' ); ?>">
          <?php echo esc_html( $s[0] . $s[1] ); ?>
        </div>
        <div class="wd-stat-label"><?php echo esc_html( $s[2] ); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- ─── SERVICES ─────────────────────────────────────────────── -->
  <section class="wd-section wd-services">
    <div class="wd-container">
      <div class="wd-services-head">
        <p class="wd-eyebrow">What We Do</p>
        <h2>Services Crafted for Your<br>Perfect Day</h2>
        <p>From intimate elopements to grand celebrations — we handle every detail so you can be fully present in the moment.</p>
      </div>
      <div class="wd-grid-3">
        <?php
        $wd_services = [
          [ 'heart',        'Full Wedding Planning',       'We manage every element — venue, vendors, timeline, florals — from first meeting to final farewell.' ],
          [ 'layout',       'Day-Of Coordination',         'Your perfectly organized coordinator to execute the day flawlessly while you enjoy every moment.' ],
          [ 'flower',       'Floral & Décor Design',       'Bespoke floral installations, table scapes, and décor that transform spaces into dreamlike settings.' ],
          [ 'camera',       'Photography & Film',          'Artful storytelling through our curated network of award-winning photographers and cinematographers.' ],
          [ 'utensils',     'Catering & Cake',             'Personalized menus and culinary experiences that delight every guest, from cocktails to desserts.' ],
          [ 'music',        'Entertainment & Music',       'Live bands, orchestras, DJs, and bespoke entertainment programs tuned to your vision.' ],
        ];
        foreach ( $wd_services as $svc ) :
        ?>
        <article class="wd-service-card">
          <div class="wd-service-icon" aria-hidden="true">
            <?php echo tf_icon_get( $svc[0], 26, 26 ); ?>
          </div>
          <h3><?php echo esc_html( $svc[1] ); ?></h3>
          <p><?php echo esc_html( $svc[2] ); ?></p>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ─── ABOUT ─────────────────────────────────────────────────── -->
  <section class="wd-section wd-about">
    <div class="wd-container">
      <div class="wd-grid-2">
        <!-- Visual column -->
        <div class="wd-about-visual" aria-hidden="true">
          <div class="wd-polaroid wd-polaroid-a">
            <div class="wd-polaroid-inner">
              <div class="wd-polaroid-img" style="position:relative;"></div>
            </div>
          </div>
          <div class="wd-polaroid wd-polaroid-b">
            <div class="wd-polaroid-inner">
              <div class="wd-polaroid-img" style="position:relative;"></div>
            </div>
          </div>
          <div class="wd-polaroid wd-polaroid-c">
            <div class="wd-polaroid-inner">
              <div class="wd-polaroid-img" style="position:relative;"></div>
            </div>
          </div>
        </div>
        <!-- Text column -->
        <div class="wd-about-content">
          <p class="wd-eyebrow">Our Story</p>
          <h2>Eighteen Years of Making<br>Dreams Come True</h2>
          <p>Founded in 2008 by Sophie &amp; Marc Laurent, <em>Blossoms &amp; Vows</em> began as a small studio in the French Riviera. Today we are one of Europe's most sought-after wedding studios — having planned celebrations on six continents.</p>
          <p>We believe a wedding is more than an event. It is the first chapter of your shared story, and every detail should reflect who you are as a couple.</p>
          <div class="wd-about-features">
            <?php
            $wd_feats = ['Certified Wedding Planners','Multilingual Team','Sustainable Practices','Worldwide Network','24/7 Planning Support','Luxury Vendor Access'];
            foreach ( $wd_feats as $f ) :
            ?>
            <div class="wd-about-feat"><?php echo esc_html( $f ); ?></div>
            <?php endforeach; ?>
          </div>
          <a href="<?php echo esc_url( home_url( '/about' ) ); ?>" class="wd-btn-primary">
            <?php echo tf_icon_get('users', 18, 18); ?>
            Meet the Team
          </a>
        </div>
      </div>
    </div>
  </section>

  <!-- ─── GALLERY ───────────────────────────────────────────────── -->
  <section class="wd-section wd-gallery">
    <div class="wd-container">
      <div class="wd-gallery-head">
        <p class="wd-eyebrow">Portfolio</p>
        <h2>Moments That Last Forever</h2>
        <div class="wd-divider" aria-hidden="true">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#c9a96e" stroke-width="1.5"><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2"/><path d="M12 8v4l3 3"/></svg>
        </div>
      </div>
      <div class="wd-gallery-grid">
        <?php
        $wd_gallery = [
          'Chateau Margaux, France',
          'The Orangery, London',
          'Villa d\'Este, Italy',
          'Bali Cliff Resort',
          'Table Setting Detail',
          'First Dance Under Stars',
          'Garden Ceremony',
        ];
        foreach ( $wd_gallery as $label ) :
        ?>
        <div class="wd-gallery-item">
          <div class="wd-gallery-item-inner" style="position:relative;"></div>
          <div class="wd-gallery-overlay">
            <span class="wd-gallery-label"><?php echo esc_html( $label ); ?></span>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ─── PACKAGES ─────────────────────────────────────────────── -->
  <section class="wd-section wd-packages">
    <div class="wd-container">
      <div class="wd-pkg-head">
        <p class="wd-eyebrow">Investment</p>
        <h2>Find Your Perfect Package</h2>
        <p>Transparent pricing with no hidden fees. Every package includes our personal promise of excellence.</p>
      </div>
      <div class="wd-grid-3">

        <!-- Essential -->
        <article class="wd-pkg-card">
          <div class="wd-pkg-name">Essential</div>
          <div class="wd-pkg-title">Elegance</div>
          <div class="wd-pkg-price">
            <span class="wd-pkg-currency">€</span>
            <span class="wd-pkg-amount" data-counter="3500">3,500</span>
          </div>
          <div class="wd-pkg-period">Starting from</div>
          <div class="wd-pkg-desc">Ideal for intimate weddings up to 50 guests seeking polished coordination.</div>
          <ul class="wd-pkg-features">
            <li>Day-of Coordination (12 hrs)</li>
            <li>Vendor Referrals &amp; Management</li>
            <li>Timeline Creation</li>
            <li>Ceremony Rehearsal Direction</li>
            <li>1 Planning Meeting</li>
            <li class="wd-unavail">Full Design Consultation</li>
            <li class="wd-unavail">Décor Styling</li>
          </ul>
          <div class="wd-pkg-cta">
            <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>" class="wd-btn-outline">Enquire Now</a>
          </div>
        </article>

        <!-- Signature — Featured -->
        <article class="wd-pkg-card wd-pkg-card--featured">
          <div class="wd-pkg-name">Signature</div>
          <div class="wd-pkg-title">Bespoke</div>
          <div class="wd-pkg-price">
            <span class="wd-pkg-currency">€</span>
            <span class="wd-pkg-amount" data-counter="8900">8,900</span>
          </div>
          <div class="wd-pkg-period">Starting from</div>
          <div class="wd-pkg-desc">Our most beloved package — full planning &amp; design for weddings up to 150 guests.</div>
          <ul class="wd-pkg-features">
            <li>Full Wedding Planning (12 months)</li>
            <li>Complete Design Consultation</li>
            <li>Floral Concept Direction</li>
            <li>Venue Sourcing &amp; Negotiation</li>
            <li>All Vendor Management</li>
            <li>Day-of Coordination (16 hrs)</li>
            <li>Rehearsal Dinner Planning</li>
          </ul>
          <div class="wd-pkg-cta">
            <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>" class="wd-btn-primary">Begin Planning</a>
          </div>
        </article>

        <!-- Prestige -->
        <article class="wd-pkg-card">
          <div class="wd-pkg-name">Prestige</div>
          <div class="wd-pkg-title">Opulence</div>
          <div class="wd-pkg-price">
            <span class="wd-pkg-currency">€</span>
            <span class="wd-pkg-amount">Custom</span>
          </div>
          <div class="wd-pkg-period">Fully bespoke</div>
          <div class="wd-pkg-desc">White-glove luxury planning for landmark celebrations — destination and multi-day events.</div>
          <ul class="wd-pkg-features">
            <li>Everything in Bespoke</li>
            <li>International Destination Planning</li>
            <li>Guest Experience Management</li>
            <li>Branding &amp; Stationery Suite</li>
            <li>Welcome Party &amp; After-Party</li>
            <li>Honeymoon Concierge</li>
            <li>Dedicated Senior Planner</li>
          </ul>
          <div class="wd-pkg-cta">
            <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>" class="wd-btn-outline">Request Proposal</a>
          </div>
        </article>

      </div>
    </div>
  </section>

  <!-- ─── VENUES ───────────────────────────────────────────────── -->
  <section class="wd-section wd-venues">
    <div class="wd-container">
      <div class="wd-venues-head">
        <p class="wd-eyebrow">Favourite Venues</p>
        <h2>Exceptional Settings for<br>Extraordinary Days</h2>
      </div>
      <div class="wd-venue-grid">
        <?php
        $wd_venues = [
          [
            'Château du Soleil',
            'Provence, France',
            'A 17th-century estate nestled among lavender fields with panoramic vineyard views. Perfect for intimate French countryside weddings.',
            ['Up to 200 guests','Historic grounds','Overnight accommodation'],
          ],
          [
            'Villa Marina Blu',
            'Amalfi Coast, Italy',
            'Cliffside luxury with dramatic sea views, terraced gardens, and a private beach. The essence of Italian romance.',
            ['Up to 120 guests','Seafront ceremony','In-house catering'],
          ],
          [
            'The Secret Garden',
            'Cotswolds, England',
            'A hidden English garden estate surrounded by centuries-old oaks. Quintessentially romantic, serene, and beautifully preserved.',
            ['Up to 150 guests','Outdoor ceremony','Tudor manor house'],
          ],
        ];
        foreach ( $wd_venues as $venue ) :
        ?>
        <article class="wd-venue-card">
          <div class="wd-venue-img">
            <div class="wd-venue-img-inner" style="position:relative;"></div>
          </div>
          <div class="wd-venue-body">
            <div class="wd-venue-location">
              <?php echo tf_icon_get('map-pin', 12, 12); ?>
              <?php echo esc_html( $venue[1] ); ?>
            </div>
            <h3 class="wd-venue-name"><?php echo esc_html( $venue[0] ); ?></h3>
            <p class="wd-venue-desc"><?php echo esc_html( $venue[2] ); ?></p>
            <div class="wd-venue-tags">
              <?php foreach ( $venue[3] as $tag ) : ?>
              <span class="wd-venue-tag"><?php echo esc_html( $tag ); ?></span>
              <?php endforeach; ?>
            </div>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ─── TESTIMONIALS ─────────────────────────────────────────── -->
  <section class="wd-section wd-testimonials">
    <div class="wd-container">
      <div class="wd-testi-head">
        <p class="wd-eyebrow">Love Letters</p>
        <h2>What Our Couples Say</h2>
      </div>
      <div class="wd-grid-3">
        <?php
        $wd_testis = [
          [
            'Sophie completely transformed our vision into something beyond imagination. Every detail — from the hand-painted escort cards to the candlelit ceremony arch — was pure perfection.',
            'Emma & James Thornton',
            'Married in Provence, June 2025',
          ],
          [
            'Working with Blossoms & Vows was the single best decision we made for our wedding. They brought calm where we felt overwhelmed, and magic where we saw logistics.',
            'Isabella & Marco Ricci',
            'Married in Amalfi, May 2025',
          ],
          [
            'Our guests are still talking about the evening. The transitions, the lighting design, the surprise entertainment — all seamlessly woven together. We are forever grateful.',
            'Charlotte & William Hayes',
            'Married in the Cotswolds, September 2024',
          ],
        ];
        foreach ( $wd_testis as $testi ) :
        ?>
        <article class="wd-testi-card">
          <div class="wd-testi-stars" aria-label="5 stars">
            <?php for ( $s = 0; $s < 5; $s++ ) : ?><span aria-hidden="true">★</span><?php endfor; ?>
          </div>
          <p class="wd-testi-text">"<?php echo esc_html( $testi[0] ); ?>"</p>
          <div class="wd-testi-couple">
            <div class="wd-testi-avatar" aria-hidden="true">
              <div class="wd-testi-avatar-inner"></div>
            </div>
            <div>
              <div class="wd-testi-name"><?php echo esc_html( $testi[1] ); ?></div>
              <div class="wd-testi-date"><?php echo esc_html( $testi[2] ); ?></div>
            </div>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ─── TEAM ─────────────────────────────────────────────────── -->
  <section class="wd-section wd-team">
    <div class="wd-container">
      <div class="wd-team-head">
        <p class="wd-eyebrow">Our Planners</p>
        <h2>The Hearts Behind the Magic</h2>
        <p>A small, passionate team of certified wedding professionals who pour their hearts into every celebration.</p>
      </div>
      <div class="wd-grid-4">
        <?php
        $wd_team = [
          [ 'Sophie Laurent',    'Lead Planner & Creative Director', 'Founder with 18 years of experience and a gift for turning the impossible beautiful.' ],
          [ 'Marc Laurent',     'Operations & Logistics Director',  'The calm, meticulous mind behind every flawless timeline and vendor coordination.' ],
          [ 'Céline Dubois',    'Floral & Décor Designer',          'Award-winning designer creating breathtaking environments from organic materials.' ],
          [ 'Alessia Romano',   'Client Relations & Concierge',     'Your dedicated support from inquiry to the final farewell — always one call away.' ],
        ];
        foreach ( $wd_team as $member ) :
        ?>
        <article class="wd-team-card">
          <div class="wd-team-photo" aria-hidden="true">
            <div class="wd-team-photo-inner" style="position:relative;"></div>
          </div>
          <div class="wd-team-name"><?php echo esc_html( $member[0] ); ?></div>
          <div class="wd-team-role"><?php echo esc_html( $member[1] ); ?></div>
          <p class="wd-team-bio"><?php echo esc_html( $member[2] ); ?></p>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ─── FAQ ──────────────────────────────────────────────────── -->
  <section class="wd-section wd-faq">
    <div class="wd-faq-wrap">
      <div class="wd-faq-head">
        <p class="wd-eyebrow">Questions</p>
        <h2>Things You May Wonder</h2>
      </div>
      <?php
      $wd_faqs = [
        [ 'How far in advance should we begin planning?', 'We recommend reaching out at least 12–18 months before your wedding date. For popular venues and high-season dates, even earlier is ideal. That said, we have beautifully delivered weddings with as little as 6 months notice.' ],
        [ 'Do you plan destination weddings?', 'Absolutely. Destination weddings are our speciality. We have planned celebrations in France, Italy, Spain, Greece, the UK, Bali, and many more locations. Our international network ensures nothing is lost in translation.' ],
        [ 'Can we customize a package?', 'Every couple is unique, and so is every package we offer. The tiers above are starting frameworks — we will tailor scope, support level, and inclusions to your specific needs and budget during our first consultation.' ],
        [ 'How many couples do you work with each year?', 'We intentionally limit our roster to 20 weddings per year to ensure every couple receives our full personal attention and commitment. Quality always over volume.' ],
        [ 'What is your fee structure?', 'Our planning fees are a combination of a base package rate and a percentage of the total event budget for Prestige packages. We are fully transparent — every fee is detailed in your proposal with no surprises.' ],
      ];
      foreach ( $wd_faqs as $i => $faq ) :
      ?>
      <div class="wd-faq-item" id="wd-faq-<?php echo $i; ?>">
        <button class="wd-faq-q" aria-expanded="false" aria-controls="wd-faq-a-<?php echo $i; ?>">
          <span><?php echo esc_html( $faq[0] ); ?></span>
          <span class="wd-faq-icon" aria-hidden="true">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          </span>
        </button>
        <div class="wd-faq-a" id="wd-faq-a-<?php echo $i; ?>" role="region">
          <p><?php echo esc_html( $faq[1] ); ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- ─── CONTACT ───────────────────────────────────────────────── -->
  <section class="wd-section wd-contact">
    <div class="wd-container">
      <div class="wd-contact-inner">

        <div class="wd-contact-info">
          <p class="wd-eyebrow" style="color:var(--wd-gold-lt)">Begin Your Journey</p>
          <h2>Let's Plan Something<br>Extraordinary Together</h2>
          <p>Share your vision with us and we'll respond within 24 hours with a personal message — not a template.</p>

          <?php
          $wd_details = [
            [ 'phone',    'Phone',     '+33 4 93 12 34 56' ],
            [ 'mail',     'Email',     'hello@blossomsvows.com' ],
            [ 'map-pin',  'Studio',    'Cannes, Côte d\'Azur, France' ],
            [ 'clock',    'Available', 'Mon–Sat, 9am–7pm CET' ],
          ];
          foreach ( $wd_details as $det ) :
          ?>
          <div class="wd-contact-detail">
            <div class="wd-contact-detail-icon" aria-hidden="true">
              <?php echo tf_icon_get( $det[0], 16, 16 ); ?>
            </div>
            <div class="wd-contact-detail-text">
              <strong><?php echo esc_html( $det[1] ); ?></strong>
              <span><?php echo esc_html( $det[2] ); ?></span>
            </div>
          </div>
          <?php endforeach; ?>
        </div>

        <div class="wd-contact-form">
          <h3 class="wd-form-title">Start the Conversation</h3>
          <form method="post" action="<?php echo esc_url( home_url( '/' ) ); ?>" novalidate>
            <?php wp_nonce_field( 'wd_inquiry_nonce', 'wd_nonce' ); ?>
            <div class="wd-form-row">
              <div class="wd-form-group">
                <label for="wd-name-a"><?php esc_html_e( 'Your Name', 'themeflex' ); ?></label>
                <input type="text" id="wd-name-a" name="wd_name_a" placeholder="Partner A" autocomplete="given-name">
              </div>
              <div class="wd-form-group">
                <label for="wd-name-b"><?php esc_html_e( 'Partner\'s Name', 'themeflex' ); ?></label>
                <input type="text" id="wd-name-b" name="wd_name_b" placeholder="Partner B" autocomplete="given-name">
              </div>
            </div>
            <div class="wd-form-row">
              <div class="wd-form-group">
                <label for="wd-email"><?php esc_html_e( 'Email Address', 'themeflex' ); ?></label>
                <input type="email" id="wd-email" name="wd_email" placeholder="hello@you.com" autocomplete="email">
              </div>
              <div class="wd-form-group">
                <label for="wd-date"><?php esc_html_e( 'Wedding Date', 'themeflex' ); ?></label>
                <input type="text" id="wd-date" name="wd_date" placeholder="Month / Year">
              </div>
            </div>
            <div class="wd-form-row">
              <div class="wd-form-group">
                <label for="wd-guests"><?php esc_html_e( 'Guest Count', 'themeflex' ); ?></label>
                <select id="wd-guests" name="wd_guests">
                  <option value=""><?php esc_html_e( 'Approximate guests', 'themeflex' ); ?></option>
                  <option>Under 30</option>
                  <option>30–80</option>
                  <option>80–150</option>
                  <option>150–300</option>
                  <option>300+</option>
                </select>
              </div>
              <div class="wd-form-group">
                <label for="wd-package"><?php esc_html_e( 'Package Interest', 'themeflex' ); ?></label>
                <select id="wd-package" name="wd_package">
                  <option value=""><?php esc_html_e( 'I\'m thinking...', 'themeflex' ); ?></option>
                  <option>Elegance (Essential)</option>
                  <option>Bespoke (Signature)</option>
                  <option>Opulence (Prestige)</option>
                  <option>Not sure yet</option>
                </select>
              </div>
            </div>
            <div class="wd-form-group">
              <label for="wd-message"><?php esc_html_e( 'Tell Us About Your Dream Wedding', 'themeflex' ); ?></label>
              <textarea id="wd-message" name="wd_message" placeholder="Share your vision, location ideas, must-haves, or simply say hello..."></textarea>
            </div>
            <div class="wd-form-footer">
              <p><?php esc_html_e( 'We respond within 24 hours. No spam, ever.', 'themeflex' ); ?></p>
              <button type="submit" class="wd-btn-primary">
                <?php echo tf_icon_get('send', 18, 18); ?>
                <?php esc_html_e( 'Send Inquiry', 'themeflex' ); ?>
              </button>
            </div>
          </form>
        </div>

      </div>
    </div>
  </section>

  <!-- ─── CTA ──────────────────────────────────────────────────── -->
  <section class="wd-cta">
    <div class="wd-cta-inner wd-container">
      <p class="wd-hero-eyebrow" style="color:rgba(255,255,255,.7);margin-bottom:.75rem">Your Story Awaits</p>
      <h2>Every Great Love Deserves<br>a Perfect Beginning</h2>
      <p>Join over 1,200 couples who trusted us with the most important day of their lives. Let's create something timeless.</p>
      <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>" class="wd-btn-white">
        <?php echo tf_icon_get('calendar-heart', 20, 20); ?>
        Schedule a Free Consultation
      </a>
    </div>
  </section>

</div><!-- .tf-wedding-page -->

<script>
(function() {
  'use strict';

  // ── FAQ accordion ────────────────────────────────────────────
  document.querySelectorAll('.wd-faq-q').forEach(function(btn) {
    btn.addEventListener('click', function() {
      var item = btn.closest('.wd-faq-item');
      var isOpen = item.classList.contains('open');
      // Close all
      document.querySelectorAll('.wd-faq-item').forEach(function(i) {
        i.classList.remove('open');
        i.querySelector('.wd-faq-q').setAttribute('aria-expanded', 'false');
      });
      if (!isOpen) {
        item.classList.add('open');
        btn.setAttribute('aria-expanded', 'true');
      }
    });
  });

  // ── Counter animation ────────────────────────────────────────
  var counters = document.querySelectorAll('[data-counter]');
  if (counters.length && 'IntersectionObserver' in window) {
    var obs = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (!entry.isIntersecting) return;
        var el     = entry.target;
        var target = parseFloat(el.dataset.counter.replace(/,/g, ''));
        var suffix = el.dataset.suffix || '';
        var start  = 0;
        var duration = 1800;
        var startTime = null;
        var isDecimal = target % 1 !== 0;
        function step(ts) {
          if (!startTime) startTime = ts;
          var progress = Math.min((ts - startTime) / duration, 1);
          var ease = 1 - Math.pow(1 - progress, 3);
          var current = start + (target - start) * ease;
          el.textContent = (isDecimal ? current.toFixed(1) : Math.round(current).toLocaleString()) + suffix;
          if (progress < 1) requestAnimationFrame(step);
        }
        requestAnimationFrame(step);
        obs.unobserve(el);
      });
    }, { threshold: 0.4 });
    counters.forEach(function(c) { obs.observe(c); });
  }

})();
</script>

<?php get_footer(); ?>
