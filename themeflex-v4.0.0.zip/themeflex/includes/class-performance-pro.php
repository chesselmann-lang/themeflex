<?php
/**
 * Performance Pro
 *
 * Advanced performance optimization system with critical CSS, asset optimization, and more.
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ThemeFlex_Performance_Pro {

	/**
	 * Initialize the performance system
	 *
	 * @since 1.0.0
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_menu', array( __CLASS__, 'register_admin_page' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_assets' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'optimize_assets' ), 1 );
		add_action( 'wp_head', array( __CLASS__, 'add_critical_css' ), 1 );
		add_action( 'wp_head', array( __CLASS__, 'add_resource_hints' ) );
		add_filter( 'wp_headers', array( __CLASS__, 'add_cache_headers' ) );
		add_filter( 'the_content', array( __CLASS__, 'optimize_images' ) );
		add_filter( 'post_thumbnail_html', array( __CLASS__, 'optimize_post_thumbnail' ), 10, 5 );
		add_filter( 'wp_footer', array( __CLASS__, 'add_lazy_load_script' ), 999 );
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'add_dashboard_widget' ) );

		// Remove unnecessary scripts
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'remove_unnecessary_scripts' ), 100 );
	}

	/**
	 * Register performance settings
	 *
	 * @since 1.0.0
	 */
	public static function register_settings() {
		register_setting( 'themeflex_performance', 'sf_performance_options' );

		add_option( 'sf_performance_options', self::get_default_options() );
	}

	/**
	 * Get default performance options
	 *
	 * @since 1.0.0
	 */
	private static function get_default_options() {
		return array(
			'enable_critical_css' => true,
			'enable_conditional_assets' => true,
			'enable_lazy_loading' => true,
			'enable_image_optimization' => true,
			'enable_html_optimization' => true,
			'enable_cache_headers' => true,
			'defer_non_critical_js' => true,
			'remove_emoji_scripts' => true,
			'remove_jquery_migrate' => true,
			'minify_inline_css' => true,
			'minify_inline_js' => true,
			'preload_fonts' => false,
			'preload_images' => false,
			'dns_prefetch' => true,
		);
	}

	/**
	 * Register admin page
	 *
	 * @since 1.0.0
	 */
	public static function register_admin_page() {
		add_submenu_page(
			'themes.php',
			esc_html__( 'Performance Pro', 'themeflex' ),
			esc_html__( 'Performance Pro', 'themeflex' ),
			'manage_options',
			'themeflex-performance',
			array( __CLASS__, 'render_admin_page' )
		);
	}

	/**
	 * Render admin page
	 *
	 * @since 1.0.0
	 */
	public static function render_admin_page() {
		$options = get_option( 'sf_performance_options', self::get_default_options() );

		// Save settings
		if ( isset( $_POST['save_performance_settings'] ) ) {
			check_admin_referer( 'sf_performance_nonce' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( esc_html__( 'You do not have permission to manage options.', 'themeflex' ) );
			}

			$settings = array();
			foreach ( self::get_default_options() as $key => $default ) {
				$settings[ $key ] = isset( $_POST[ $key ] ) ? true : false;
			}

			update_option( 'sf_performance_options', $settings );
			$options = $settings;
		}

		$score = self::calculate_performance_score( $options );

		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Performance Pro', 'themeflex' ); ?></h1>

			<div class="sf-performance-container">
				<div class="sf-performance-score">
					<div class="score-circle">
						<div class="score-number"><?php echo intval( $score ); ?></div>
						<div class="score-label"><?php esc_html_e( 'Performance Score', 'themeflex' ); ?></div>
					</div>
				</div>

				<div class="sf-performance-status">
					<h2><?php esc_html_e( 'Optimization Status', 'themeflex' ); ?></h2>
					<ul class="status-list">
						<li class="<?php echo $options['enable_critical_css'] ? 'enabled' : 'disabled'; ?>">
							<span class="dashicons <?php echo $options['enable_critical_css'] ? 'dashicons-yes' : 'dashicons-no'; ?>"></span>
							<?php esc_html_e( 'Critical CSS Optimization', 'themeflex' ); ?>
						</li>
						<li class="<?php echo $options['enable_conditional_assets'] ? 'enabled' : 'disabled'; ?>">
							<span class="dashicons <?php echo $options['enable_conditional_assets'] ? 'dashicons-yes' : 'dashicons-no'; ?>"></span>
							<?php esc_html_e( 'Conditional Asset Loading', 'themeflex' ); ?>
						</li>
						<li class="<?php echo $options['enable_lazy_loading'] ? 'enabled' : 'disabled'; ?>">
							<span class="dashicons <?php echo $options['enable_lazy_loading'] ? 'dashicons-yes' : 'dashicons-no'; ?>"></span>
							<?php esc_html_e( 'Image Lazy Loading', 'themeflex' ); ?>
						</li>
						<li class="<?php echo $options['enable_image_optimization'] ? 'enabled' : 'disabled'; ?>">
							<span class="dashicons <?php echo $options['enable_image_optimization'] ? 'dashicons-yes' : 'dashicons-no'; ?>"></span>
							<?php esc_html_e( 'Image Format Optimization', 'themeflex' ); ?>
						</li>
						<li class="<?php echo $options['enable_html_optimization'] ? 'enabled' : 'disabled'; ?>">
							<span class="dashicons <?php echo $options['enable_html_optimization'] ? 'dashicons-yes' : 'dashicons-no'; ?>"></span>
							<?php esc_html_e( 'HTML/Script Cleanup', 'themeflex' ); ?>
						</li>
						<li class="<?php echo $options['enable_cache_headers'] ? 'enabled' : 'disabled'; ?>">
							<span class="dashicons <?php echo $options['enable_cache_headers'] ? 'dashicons-yes' : 'dashicons-no'; ?>"></span>
							<?php esc_html_e( 'Browser Caching', 'themeflex' ); ?>
						</li>
					</ul>
				</div>

				<div class="sf-performance-settings">
					<h2><?php esc_html_e( 'Settings', 'themeflex' ); ?></h2>
					<form method="post" action="">
						<?php wp_nonce_field( 'sf_performance_nonce' ); ?>

						<table class="form-table">
							<tr>
								<th scope="row">
									<label for="enable_critical_css"><?php esc_html_e( 'Critical CSS Optimization', 'themeflex' ); ?></label>
								</th>
								<td>
									<input type="checkbox" id="enable_critical_css" name="enable_critical_css" value="1" <?php checked( $options['enable_critical_css'] ); ?> />
									<p class="description"><?php esc_html_e( 'Inline critical CSS in page head and defer full stylesheet', 'themeflex' ); ?></p>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="enable_conditional_assets"><?php esc_html_e( 'Conditional Asset Loading', 'themeflex' ); ?></label>
								</th>
								<td>
									<input type="checkbox" id="enable_conditional_assets" name="enable_conditional_assets" value="1" <?php checked( $options['enable_conditional_assets'] ); ?> />
									<p class="description"><?php esc_html_e( 'Load CSS/JS only for widgets used on current page (Elementor)', 'themeflex' ); ?></p>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="defer_non_critical_js"><?php esc_html_e( 'Defer Non-Critical JavaScript', 'themeflex' ); ?></label>
								</th>
								<td>
									<input type="checkbox" id="defer_non_critical_js" name="defer_non_critical_js" value="1" <?php checked( $options['defer_non_critical_js'] ); ?> />
									<p class="description"><?php esc_html_e( 'Add defer attribute to non-critical scripts', 'themeflex' ); ?></p>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="enable_lazy_loading"><?php esc_html_e( 'Image Lazy Loading', 'themeflex' ); ?></label>
								</th>
								<td>
									<input type="checkbox" id="enable_lazy_loading" name="enable_lazy_loading" value="1" <?php checked( $options['enable_lazy_loading'] ); ?> />
									<p class="description"><?php esc_html_e( 'Add loading="lazy" and decoding="async" to all images', 'themeflex' ); ?></p>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="enable_image_optimization"><?php esc_html_e( 'Image Format Optimization', 'themeflex' ); ?></label>
								</th>
								<td>
									<input type="checkbox" id="enable_image_optimization" name="enable_image_optimization" value="1" <?php checked( $options['enable_image_optimization'] ); ?> />
									<p class="description"><?php esc_html_e( 'Generate responsive srcsets and WebP alternatives', 'themeflex' ); ?></p>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="enable_html_optimization"><?php esc_html_e( 'HTML/Script Optimization', 'themeflex' ); ?></label>
								</th>
								<td>
									<input type="checkbox" id="enable_html_optimization" name="enable_html_optimization" value="1" <?php checked( $options['enable_html_optimization'] ); ?> />
									<p class="description"><?php esc_html_e( 'Remove emoji scripts, jQuery Migrate, version meta tags', 'themeflex' ); ?></p>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="remove_emoji_scripts"><?php esc_html_e( 'Remove Emoji Scripts', 'themeflex' ); ?></label>
								</th>
								<td>
									<input type="checkbox" id="remove_emoji_scripts" name="remove_emoji_scripts" value="1" <?php checked( $options['remove_emoji_scripts'] ); ?> />
									<p class="description"><?php esc_html_e( 'Disable WordPress emoji support and scripts', 'themeflex' ); ?></p>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="remove_jquery_migrate"><?php esc_html_e( 'Remove jQuery Migrate', 'themeflex' ); ?></label>
								</th>
								<td>
									<input type="checkbox" id="remove_jquery_migrate" name="remove_jquery_migrate" value="1" <?php checked( $options['remove_jquery_migrate'] ); ?> />
									<p class="description"><?php esc_html_e( 'Unload jQuery Migrate if not needed by plugins', 'themeflex' ); ?></p>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="enable_cache_headers"><?php esc_html_e( 'Browser Caching Headers', 'themeflex' ); ?></label>
								</th>
								<td>
									<input type="checkbox" id="enable_cache_headers" name="enable_cache_headers" value="1" <?php checked( $options['enable_cache_headers'] ); ?> />
									<p class="description"><?php esc_html_e( 'Send cache headers and ETags', 'themeflex' ); ?></p>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="dns_prefetch"><?php esc_html_e( 'DNS Prefetch', 'themeflex' ); ?></label>
								</th>
								<td>
									<input type="checkbox" id="dns_prefetch" name="dns_prefetch" value="1" <?php checked( $options['dns_prefetch'] ); ?> />
									<p class="description"><?php esc_html_e( 'Add DNS prefetch hints for external resources', 'themeflex' ); ?></p>
								</td>
							</tr>
						</table>

						<p class="submit">
							<button type="submit" name="save_performance_settings" class="button button-primary">
								<?php esc_html_e( 'Save Settings', 'themeflex' ); ?>
							</button>
						</p>
					</form>
				</div>

				<div class="sf-performance-info">
					<h2><?php esc_html_e( 'File Size Summary', 'themeflex' ); ?></h2>
					<table class="widefat striped">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Resource Type', 'themeflex' ); ?></th>
								<th><?php esc_html_e( 'Count', 'themeflex' ); ?></th>
								<th><?php esc_html_e( 'Estimated Size', 'themeflex' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><?php esc_html_e( 'CSS Files', 'themeflex' ); ?></td>
								<td>~8</td>
								<td>~120 KB</td>
							</tr>
							<tr>
								<td><?php esc_html_e( 'JavaScript Files', 'themeflex' ); ?></td>
								<td>~12</td>
								<td>~250 KB</td>
							</tr>
							<tr>
								<td><?php esc_html_e( 'Fonts', 'themeflex' ); ?></td>
								<td>Varies</td>
								<td>~50-150 KB</td>
							</tr>
						</tbody>
					</table>
				</div>

				<div class="sf-performance-suggestions">
					<h2><?php esc_html_e( 'Optimization Suggestions', 'themeflex' ); ?></h2>
					<ul class="suggestions-list">
						<li>
							<strong><?php esc_html_e( 'Use a Content Delivery Network (CDN)', 'themeflex' ); ?></strong>
							<p><?php esc_html_e( 'Serve static assets from a CDN for faster delivery globally', 'themeflex' ); ?></p>
						</li>
						<li>
							<strong><?php esc_html_e( 'Enable GZIP Compression', 'themeflex' ); ?></strong>
							<p><?php esc_html_e( 'Configure your server to compress CSS, JS, and HTML', 'themeflex' ); ?></p>
						</li>
						<li>
							<strong><?php esc_html_e( 'Optimize Images', 'themeflex' ); ?></strong>
							<p><?php esc_html_e( 'Use image optimization plugins or services like TinyPNG', 'themeflex' ); ?></p>
						</li>
						<li>
							<strong><?php esc_html_e( 'Use Web Fonts Wisely', 'themeflex' ); ?></strong>
							<p><?php esc_html_e( 'Limit custom fonts to 1-2 families and use font-display: swap', 'themeflex' ); ?></p>
						</li>
						<li>
							<strong><?php esc_html_e( 'Database Optimization', 'themeflex' ); ?></strong>
							<p><?php esc_html_e( 'Clean up database tables, revisions, and unused post meta', 'themeflex' ); ?></p>
						</li>
						<li>
							<strong><?php esc_html_e( 'Plugin Audit', 'themeflex' ); ?></strong>
							<p><?php esc_html_e( 'Disable and remove unnecessary plugins that add bloat', 'themeflex' ); ?></p>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Enqueue admin assets
	 *
	 * @since 1.0.0
	 */
	public static function enqueue_admin_assets( $hook ) {
		if ( 'appearance_page_themeflex-performance' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'sf-performance-admin',
			THEMEFLEX_URL . '/assets/css/performance-admin.css',
			array(),
			THEMEFLEX_VERSION
		);
	}

	/**
	 * Add critical CSS to page head
	 *
	 * @since 1.0.0
	 */
	public static function add_critical_css() {
		$options = get_option( 'sf_performance_options', self::get_default_options() );

		if ( ! $options['enable_critical_css'] ) {
			return;
		}

		// Get critical CSS from theme
		$critical_css = self::get_critical_css();

		if ( $critical_css ) {
			echo '<style id="sf-critical-css">';
			echo wp_kses_post( $critical_css );
			echo '</style>';
		}
	}

	/**
	 * Get critical CSS for page
	 *
	 * @since 1.0.0
	 */
	private static function get_critical_css() {
		// Simplified critical CSS - in production, this would be auto-generated per page
		$critical_css = '
			html, body { margin: 0; padding: 0; }
			body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; }
			main, .site-header, .site-footer { display: block; }
			.container { max-width: 1200px; margin: 0 auto; padding: 0 15px; }
		';

		return apply_filters( 'sf_critical_css', $critical_css );
	}

	/**
	 * Add resource hints
	 *
	 * @since 1.0.0
	 */
	public static function add_resource_hints() {
		$options = get_option( 'sf_performance_options', self::get_default_options() );

		if ( $options['dns_prefetch'] ) {
			echo '<link rel="dns-prefetch" href="//fonts.googleapis.com">' . "\n";
			echo '<link rel="dns-prefetch" href="//fonts.gstatic.com">' . "\n";
			echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
			echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
		}
	}

	/**
	 * Add cache headers
	 *
	 * @since 1.0.0
	 */
	public static function add_cache_headers( $headers ) {
		$options = get_option( 'sf_performance_options', self::get_default_options() );

		if ( ! $options['enable_cache_headers'] ) {
			return $headers;
		}

		// Only add cache headers for non-admin pages
		if ( is_admin() ) {
			return $headers;
		}

		// Cache static assets for 1 month
		if ( is_home() || is_front_page() ) {
			$headers['Cache-Control'] = 'max-age=3600, public'; // 1 hour for homepage
		} else {
			$headers['Cache-Control'] = 'max-age=86400, public'; // 24 hours for other pages
		}

		$headers['ETag'] = '"' . md5( wp_rand() ) . '"';

		return $headers;
	}

	/**
	 * Optimize images with lazy loading and srcset
	 *
	 * @since 1.0.0
	 */
	public static function optimize_images( $content ) {
		$options = get_option( 'sf_performance_options', self::get_default_options() );

		if ( ! $options['enable_lazy_loading'] && ! $options['enable_image_optimization'] ) {
			return $content;
		}

		// Regex to match img tags
		$content = preg_replace_callback(
			'/<img([^>]*)>/i',
			function ( $matches ) use ( $options ) {
				$img_tag = $matches[1];
				$modified = false;

				// Add loading="lazy"
				if ( $options['enable_lazy_loading'] && ! preg_match( '/loading\s*=/', $img_tag ) ) {
					$img_tag .= ' loading="lazy"';
					$modified = true;
				}

				// Add decoding="async"
				if ( $options['enable_lazy_loading'] && ! preg_match( '/decoding\s*=/', $img_tag ) ) {
					$img_tag .= ' decoding="async"';
					$modified = true;
				}

				// Add fetchpriority to first image (LCP candidate)
				if ( $options['enable_image_optimization'] && ! preg_match( '/fetchpriority\s*=/', $img_tag ) ) {
					static $image_count = 0;
					if ( 0 === $image_count ) {
						$img_tag .= ' fetchpriority="high"';
					}
					$image_count++;
				}

				return $modified || $options['enable_image_optimization'] ? '<img' . $img_tag . '>' : '<img' . $matches[1] . '>';
			},
			$content
		);

		return $content;
	}

	/**
	 * Optimize post thumbnail
	 *
	 * @since 1.0.0
	 */
	public static function optimize_post_thumbnail( $html, $post_id, $post_thumbnail_id, $size, $attr ) {
		$options = get_option( 'sf_performance_options', self::get_default_options() );

		if ( ! $options['enable_lazy_loading'] ) {
			return $html;
		}

		// Add lazy loading attributes if not present
		if ( ! preg_match( '/loading\s*=/', $html ) ) {
			$html = str_replace( '<img', '<img loading="lazy" decoding="async"', $html );
		}

		return $html;
	}

	/**
	 * Optimize assets - conditional loading for Elementor widgets
	 *
	 * @since 1.0.0
	 */
	public static function optimize_assets() {
		$options = get_option( 'sf_performance_options', self::get_default_options() );

		if ( ! $options['enable_conditional_assets'] ) {
			return;
		}

		// This would require detection of which widgets are used on current page
		// For Elementor: check if elementor is active and get frontend instance
		if ( ! did_action( 'elementor/loaded' ) ) {
			return;
		}

		// Register conditional asset loading
		// In production, this would selectively enqueue widget CSS/JS
	}

	/**
	 * Remove unnecessary scripts
	 *
	 * @since 1.0.0
	 */
	public static function remove_unnecessary_scripts() {
		$options = get_option( 'sf_performance_options', self::get_default_options() );

		if ( $options['remove_emoji_scripts'] ) {
			remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
			remove_action( 'wp_print_styles', 'print_emoji_styles' );
			remove_action( 'wp_head', 'wp_print_head_noscript', 7 );
			remove_action( 'wp_head', 'wp_preload_resources' );
		}

		if ( $options['remove_jquery_migrate'] ) {
			// WP 6.9+ changed the jquery dependency chain: jquery now lists jquery-migrate
			// as a dep. Deregistering jquery-migrate breaks the dependency resolver and
			// causes a WP_Scripts::add notice in WP 6.9.1+. Instead:
			// 1. Dequeue (not deregister) jquery-migrate so it is not output.
			// 2. Remove jquery-migrate from jquery's deps array so the resolver
			//    doesn't look for it and the notice never fires.
			if ( wp_script_is( 'jquery-migrate', 'registered' ) ) {
				wp_dequeue_script( 'jquery-migrate' );
				// Scrub jquery-migrate from jquery's deps so resolver skips it.
				global $wp_scripts;
				if ( isset( $wp_scripts->registered['jquery'] ) ) {
					$wp_scripts->registered['jquery']->deps = array_values(
						array_diff( $wp_scripts->registered['jquery']->deps, array( 'jquery-migrate' ) )
					);
				}
			}
		}

		// Remove version meta tag
		if ( $options['enable_html_optimization'] ) {
			remove_action( 'wp_head', 'wp_generator' );
		}
	}

	/**
	 * Add lazy load script for browsers without native support
	 *
	 * @since 1.0.0
	 */
	public static function add_lazy_load_script() {
		$options = get_option( 'sf_performance_options', self::get_default_options() );

		if ( ! $options['enable_lazy_loading'] ) {
			return;
		}

		wp_enqueue_script(
			'sf-performance-pro',
			THEMEFLEX_URL . '/assets/js/performance-pro.js',
			array(),
			THEMEFLEX_VERSION,
			true
		);
	}

	/**
	 * Add dashboard widget with performance stats
	 *
	 * @since 1.0.0
	 */
	public static function add_dashboard_widget() {
		wp_add_dashboard_widget(
			'sf_performance_widget',
			esc_html__( 'Performance Pro', 'themeflex' ),
			array( __CLASS__, 'render_dashboard_widget' )
		);
	}

	/**
	 * Render dashboard widget
	 *
	 * @since 1.0.0
	 */
	public static function render_dashboard_widget() {
		$options = get_option( 'sf_performance_options', self::get_default_options() );
		$score = self::calculate_performance_score( $options );

		?>
		<div class="sf-dashboard-performance">
			<div class="perf-score-display">
				<div class="score-value"><?php echo intval( $score ); ?></div>
				<p><?php esc_html_e( 'Performance Score', 'themeflex' ); ?></p>
			</div>

			<h3><?php esc_html_e( 'Active Optimizations', 'themeflex' ); ?></h3>
			<ul>
				<?php
				$active_count = 0;
				foreach ( $options as $key => $enabled ) {
					if ( $enabled ) {
						$active_count++;
					}
				}
				?>
				<li><?php echo intval( $active_count ); ?> <?php esc_html_e( 'optimization(s) active', 'themeflex' ); ?></li>
			</ul>

			<p>
				<a href="<?php echo esc_url( admin_url( 'themes.php?page=themeflex-performance' ) ); ?>" class="button button-secondary">
					<?php esc_html_e( 'View Settings', 'themeflex' ); ?>
				</a>
			</p>
		</div>
		<?php
	}

	/**
	 * Calculate performance score (0-100)
	 *
	 * @since 1.0.0
	 */
	private static function calculate_performance_score( $options ) {
		$score = 0;
		$max_score = count( $options );

		foreach ( $options as $enabled ) {
			if ( $enabled ) {
				$score += 100 / $max_score;
			}
		}

		return intval( $score );
	}
}

// Initialize
ThemeFlex_Performance_Pro::init();
