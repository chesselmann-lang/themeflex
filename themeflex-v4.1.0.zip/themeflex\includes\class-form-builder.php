<?php
/**
 * Contact Form Builder
 *
 * A lightweight form builder system for creating contact forms without plugins.
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ThemeFlex_Form_Builder {

	/**
	 * Initialize the form builder
	 *
	 * @since 1.0.0
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_post_type' ) );
		add_action( 'init', array( __CLASS__, 'create_forms_table' ) );
		add_action( 'admin_menu', array( __CLASS__, 'register_admin_page' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_assets' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_frontend_assets' ) );
		add_action( 'wp_ajax_sf_save_form_fields', array( __CLASS__, 'ajax_save_form_fields' ) );
		add_action( 'wp_ajax_sf_submit_form', array( __CLASS__, 'ajax_submit_form' ) );
		add_action( 'wp_ajax_nopriv_sf_submit_form', array( __CLASS__, 'ajax_submit_form' ) );
		add_shortcode( 'sf_form', array( __CLASS__, 'render_shortcode' ) );
	}

	/**
	 * Register custom post type for forms
	 *
	 * @since 1.0.0
	 */
	public static function register_post_type() {
		$args = array(
			'labels'              => array(
				'name'          => esc_html__( 'Forms', 'themeflex' ),
				'singular_name' => esc_html__( 'Form', 'themeflex' ),
			),
			'public'              => false,
			'show_ui'             => false,
			'show_in_nav_menus'   => false,
			'has_archive'         => false,
			'supports'            => array( 'title', 'custom-fields' ),
			'can_export'          => false,
			'publicly_queryable'  => false,
		);

		register_post_type( 'sf_form', $args );
	}

	/**
	 * Create custom table for form submissions
	 *
	 * @since 1.0.0
	 */
	public static function create_forms_table() {
		global $wpdb;
		$table_name = $wpdb->prefix . 'sf_form_submissions';
		$charset_collate = $wpdb->get_charset_collate();

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
			$sql = "CREATE TABLE $table_name (
				id mediumint(9) NOT NULL AUTO_INCREMENT,
				form_id mediumint(9) NOT NULL,
				submission_data longtext NOT NULL,
				ip_address varchar(45) NOT NULL,
				user_agent text NOT NULL,
				created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
				PRIMARY KEY (id),
				INDEX form_id (form_id)
			) $charset_collate;";

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			dbDelta( $sql );
		}
	}

	/**
	 * Register admin page
	 *
	 * @since 1.0.0
	 */
	public static function register_admin_page() {
		add_submenu_page(
			'themes.php',
			esc_html__( 'Form Builder', 'themeflex' ),
			esc_html__( 'Form Builder', 'themeflex' ),
			'manage_options',
			'themeflex-form-builder',
			array( __CLASS__, 'render_admin_page' )
		);
	}

	/**
	 * Enqueue admin assets
	 *
	 * @since 1.0.0
	 */
	public static function enqueue_admin_assets( $hook ) {
		if ( 'appearance_page_themeflex-form-builder' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'sf-form-builder-admin',
			THEMEFLEX_URL . '/assets/css/form-builder.css',
			array(),
			THEMEFLEX_VERSION
		);

		wp_enqueue_script(
			'sf-form-builder-admin',
			THEMEFLEX_URL . '/assets/js/form-builder.js',
			array( 'jquery', 'wp-util' ),
			THEMEFLEX_VERSION,
			true
		);

		wp_localize_script(
			'sf-form-builder-admin',
			'sfFormBuilderData',
			array(
				'nonce'       => wp_create_nonce( 'sf_form_builder_nonce' ),
				'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
				'confirmDelete' => esc_html__( 'Are you sure you want to delete this form?', 'themeflex' ),
			)
		);
	}

	/**
	 * Enqueue frontend assets
	 *
	 * @since 1.0.0
	 */
	public static function enqueue_frontend_assets() {
		wp_enqueue_style(
			'sf-forms',
			THEMEFLEX_URL . '/assets/css/forms.css',
			array(),
			THEMEFLEX_VERSION
		);

		wp_enqueue_script(
			'sf-forms',
			THEMEFLEX_URL . '/assets/js/forms.js',
			array( 'jquery' ),
			THEMEFLEX_VERSION,
			true
		);

		wp_localize_script(
			'sf-forms',
			'sfFormsData',
			array(
				'nonce'   => wp_create_nonce( 'sf_forms_nonce' ),
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			)
		);
	}

	/**
	 * Render admin page
	 *
	 * @since 1.0.0
	 */
	public static function render_admin_page() {
		// Get all forms
		$forms = get_posts( array(
			'post_type'      => 'sf_form',
			'posts_per_page' => -1,
			'orderby'        => 'date',
			'order'          => 'DESC',
		) );

		// Get current action
		$action = isset( $_GET['action'] ) ? sanitize_text_field( $_GET['action'] ) : 'list';
		$form_id = isset( $_GET['form_id'] ) ? intval( $_GET['form_id'] ) : 0;

		?>
		<div class="wrap sf-form-builder-wrap">
			<h1><?php esc_html_e( 'Form Builder', 'themeflex' ); ?></h1>

			<?php if ( 'edit' === $action && $form_id ) : ?>
				<?php self::render_form_editor( $form_id ); ?>
			<?php else : ?>
				<div class="sf-form-builder-toolbar">
					<a href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'action', 'new' ), 'sf_form_new' ) ); ?>" class="button button-primary">
						<?php esc_html_e( '+ New Form', 'themeflex' ); ?>
					</a>
				</div>

				<table class="widefat striped">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Form Name', 'themeflex' ); ?></th>
							<th><?php esc_html_e( 'Shortcode', 'themeflex' ); ?></th>
							<th><?php esc_html_e( 'Fields', 'themeflex' ); ?></th>
							<th><?php esc_html_e( 'Recipient Email', 'themeflex' ); ?></th>
							<th><?php esc_html_e( 'Actions', 'themeflex' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php if ( ! empty( $forms ) ) : ?>
							<?php foreach ( $forms as $form ) : ?>
								<?php
								$fields = get_post_meta( $form->ID, '_sf_form_fields', true );
								$email = get_post_meta( $form->ID, '_sf_form_email', true );
								$field_count = ! empty( $fields ) ? count( json_decode( $fields, true ) ) : 0;
								?>
								<tr>
									<td><strong><?php echo esc_html( $form->post_title ); ?></strong></td>
									<td><code>[sf_form id="<?php echo esc_attr( $form->ID ); ?>"]</code></td>
									<td><?php echo esc_html( $field_count ); ?></td>
									<td><?php echo esc_html( $email ); ?></td>
									<td>
										<a href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'action' => 'edit', 'form_id' => $form->ID ) ), 'sf_form_edit' ) ); ?>" class="button button-small">
											<?php esc_html_e( 'Edit', 'themeflex' ); ?>
										</a>
										<a href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'action' => 'entries', 'form_id' => $form->ID ) ), 'sf_form_entries' ) ); ?>" class="button button-small">
											<?php esc_html_e( 'Entries', 'themeflex' ); ?>
										</a>
										<a href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'action' => 'delete', 'form_id' => $form->ID ) ), 'sf_form_delete' ) ); ?>" class="button button-small button-link-delete" onclick="return confirm('<?php esc_html_e( 'Are you sure?', 'themeflex' ); ?>') ">
											<?php esc_html_e( 'Delete', 'themeflex' ); ?>
										</a>
									</td>
								</tr>
							<?php endforeach; ?>
						<?php else : ?>
							<tr>
								<td colspan="5" style="text-align: center; padding: 20px;">
									<?php esc_html_e( 'No forms yet. Create one to get started!', 'themeflex' ); ?>
								</td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render form editor
	 *
	 * @since 1.0.0
	 * @param int $form_id Form ID
	 */
	public static function render_form_editor( $form_id ) {
		$form = get_post( $form_id );
		if ( ! $form || 'sf_form' !== $form->post_type ) {
			wp_safe_remote_get( admin_url( 'themes.php?page=themeflex-form-builder' ) );
			return;
		}

		$fields = get_post_meta( $form_id, '_sf_form_fields', true );
		$fields = ! empty( $fields ) ? json_decode( $fields, true ) : array();
		$email = get_post_meta( $form_id, '_sf_form_email', true );
		$subject = get_post_meta( $form_id, '_sf_form_subject', true );
		$success_msg = get_post_meta( $form_id, '_sf_form_success_msg', true );
		$redirect_url = get_post_meta( $form_id, '_sf_form_redirect_url', true );

		?>
		<div class="sf-form-editor">
			<h2><?php esc_html_e( 'Edit Form: ', 'themeflex' ); ?><?php echo esc_html( $form->post_title ); ?></h2>
			<a href="<?php echo esc_url( admin_url( 'themes.php?page=themeflex-form-builder' ) ); ?>" class="button">
				<?php esc_html_e( '← Back to Forms', 'themeflex' ); ?>
			</a>

			<div class="sf-form-editor-container">
				<div class="sf-form-editor-fields">
					<h3><?php esc_html_e( 'Form Fields', 'themeflex' ); ?></h3>
					<div id="sf-form-fields-list" class="sf-form-fields-list">
						<?php foreach ( $fields as $index => $field ) : ?>
							<?php self::render_field_item( $field, $index ); ?>
						<?php endforeach; ?>
					</div>

					<div class="sf-form-editor-actions">
						<button class="button" id="sf-add-field-btn"><?php esc_html_e( '+ Add Field', 'themeflex' ); ?></button>
						<button class="button button-primary" id="sf-save-form-btn"><?php esc_html_e( 'Save Form', 'themeflex' ); ?></button>
					</div>
				</div>

				<div class="sf-form-editor-settings">
					<h3><?php esc_html_e( 'Form Settings', 'themeflex' ); ?></h3>

					<div class="sf-setting-group">
						<label><?php esc_html_e( 'Email Recipient', 'themeflex' ); ?></label>
						<input type="email" id="sf-form-email" value="<?php echo esc_attr( $email ); ?>" placeholder="<?php esc_attr_e( 'admin@example.com', 'themeflex' ); ?>">
					</div>

					<div class="sf-setting-group">
						<label><?php esc_html_e( 'Email Subject', 'themeflex' ); ?></label>
						<input type="text" id="sf-form-subject" value="<?php echo esc_attr( $subject ); ?>" placeholder="<?php esc_attr_e( 'New Form Submission', 'themeflex' ); ?>">
					</div>

					<div class="sf-setting-group">
						<label><?php esc_html_e( 'Success Message', 'themeflex' ); ?></label>
						<textarea id="sf-form-success-msg" placeholder="<?php esc_attr_e( 'Thank you for your submission!', 'themeflex' ); ?>"><?php echo esc_textarea( $success_msg ); ?></textarea>
					</div>

					<div class="sf-setting-group">
						<label><?php esc_html_e( 'Redirect URL (Optional)', 'themeflex' ); ?></label>
						<input type="url" id="sf-form-redirect-url" value="<?php echo esc_attr( $redirect_url ); ?>" placeholder="<?php esc_attr_e( 'https://example.com/thank-you', 'themeflex' ); ?>">
					</div>
				</div>
			</div>
		</div>

		<template id="sf-field-template">
			<?php self::render_field_item( array(), -1 ); ?>
		</template>

		<div id="sf-field-types-modal" style="display:none;">
			<h3><?php esc_html_e( 'Select Field Type', 'themeflex' ); ?></h3>
			<div class="sf-field-types">
				<?php
				$field_types = array(
					'text'       => esc_html__( 'Text Input', 'themeflex' ),
					'email'      => esc_html__( 'Email', 'themeflex' ),
					'phone'      => esc_html__( 'Phone', 'themeflex' ),
					'url'        => esc_html__( 'URL', 'themeflex' ),
					'textarea'   => esc_html__( 'Textarea', 'themeflex' ),
					'select'     => esc_html__( 'Select Dropdown', 'themeflex' ),
					'radio'      => esc_html__( 'Radio Buttons', 'themeflex' ),
					'checkbox'   => esc_html__( 'Checkboxes', 'themeflex' ),
					'number'     => esc_html__( 'Number', 'themeflex' ),
					'date'       => esc_html__( 'Date', 'themeflex' ),
					'file'       => esc_html__( 'File Upload', 'themeflex' ),
					'hidden'     => esc_html__( 'Hidden Field', 'themeflex' ),
				);
				foreach ( $field_types as $type => $label ) : ?>
					<button type="button" class="sf-field-type-btn" data-type="<?php echo esc_attr( $type ); ?>">
						<?php echo esc_html( $label ); ?>
					</button>
				<?php endforeach; ?>
			</div>
		</div>

		<script>
			window.sfFormData = {
				formId: <?php echo intval( $form_id ); ?>,
				nonce: '<?php echo wp_create_nonce( 'sf_form_builder_nonce' ); ?>'
			};
		</script>
		<?php
	}

	/**
	 * Render a field item in the editor
	 *
	 * @since 1.0.0
	 * @param array $field Field data
	 * @param int   $index Field index
	 */
	public static function render_field_item( $field, $index ) {
		$type = isset( $field['type'] ) ? $field['type'] : 'text';
		$label = isset( $field['label'] ) ? $field['label'] : '';
		$placeholder = isset( $field['placeholder'] ) ? $field['placeholder'] : '';
		$required = isset( $field['required'] ) ? $field['required'] : false;
		$width = isset( $field['width'] ) ? $field['width'] : 'full';
		$css_class = isset( $field['css_class'] ) ? $field['css_class'] : '';
		$options = isset( $field['options'] ) ? $field['options'] : array();

		?>
		<div class="sf-field-item" data-index="<?php echo esc_attr( $index ); ?>" draggable="true">
			<div class="sf-field-header">
				<span class="sf-field-handle">::</span>
				<span class="sf-field-label"><?php echo esc_html( $label ? $label : 'Field ' . ( $index + 1 ) ); ?></span>
				<button type="button" class="sf-field-remove-btn" title="<?php esc_attr_e( 'Remove field', 'themeflex' ); ?>">×</button>
			</div>

			<div class="sf-field-editor" style="display: none;">
				<div class="sf-field-row">
					<div class="sf-field-col">
						<label><?php esc_html_e( 'Field Type', 'themeflex' ); ?></label>
						<select class="sf-field-type-select" name="type">
							<option value="text" <?php selected( $type, 'text' ); ?>><?php esc_html_e( 'Text', 'themeflex' ); ?></option>
							<option value="email" <?php selected( $type, 'email' ); ?>><?php esc_html_e( 'Email', 'themeflex' ); ?></option>
							<option value="phone" <?php selected( $type, 'phone' ); ?>><?php esc_html_e( 'Phone', 'themeflex' ); ?></option>
							<option value="url" <?php selected( $type, 'url' ); ?>><?php esc_html_e( 'URL', 'themeflex' ); ?></option>
							<option value="textarea" <?php selected( $type, 'textarea' ); ?>><?php esc_html_e( 'Textarea', 'themeflex' ); ?></option>
							<option value="select" <?php selected( $type, 'select' ); ?>><?php esc_html_e( 'Select', 'themeflex' ); ?></option>
							<option value="radio" <?php selected( $type, 'radio' ); ?>><?php esc_html_e( 'Radio', 'themeflex' ); ?></option>
							<option value="checkbox" <?php selected( $type, 'checkbox' ); ?>><?php esc_html_e( 'Checkbox', 'themeflex' ); ?></option>
							<option value="number" <?php selected( $type, 'number' ); ?>><?php esc_html_e( 'Number', 'themeflex' ); ?></option>
							<option value="date" <?php selected( $type, 'date' ); ?>><?php esc_html_e( 'Date', 'themeflex' ); ?></option>
							<option value="file" <?php selected( $type, 'file' ); ?>><?php esc_html_e( 'File', 'themeflex' ); ?></option>
							<option value="hidden" <?php selected( $type, 'hidden' ); ?>><?php esc_html_e( 'Hidden', 'themeflex' ); ?></option>
						</select>
					</div>
				</div>

				<div class="sf-field-row">
					<div class="sf-field-col">
						<label><?php esc_html_e( 'Label', 'themeflex' ); ?></label>
						<input type="text" name="label" value="<?php echo esc_attr( $label ); ?>" placeholder="<?php esc_attr_e( 'Field label', 'themeflex' ); ?>">
					</div>
				</div>

				<div class="sf-field-row">
					<div class="sf-field-col">
						<label><?php esc_html_e( 'Placeholder', 'themeflex' ); ?></label>
						<input type="text" name="placeholder" value="<?php echo esc_attr( $placeholder ); ?>" placeholder="<?php esc_attr_e( 'Placeholder text', 'themeflex' ); ?>">
					</div>
				</div>

				<div class="sf-field-row">
					<div class="sf-field-col">
						<label><?php esc_html_e( 'Width', 'themeflex' ); ?></label>
						<select name="width">
							<option value="full" <?php selected( $width, 'full' ); ?>><?php esc_html_e( 'Full Width', 'themeflex' ); ?></option>
							<option value="half" <?php selected( $width, 'half' ); ?>><?php esc_html_e( 'Half Width', 'themeflex' ); ?></option>
							<option value="third" <?php selected( $width, 'third' ); ?>><?php esc_html_e( 'Third Width', 'themeflex' ); ?></option>
						</select>
					</div>

					<div class="sf-field-col">
						<label><?php esc_html_e( 'CSS Class', 'themeflex' ); ?></label>
						<input type="text" name="css_class" value="<?php echo esc_attr( $css_class ); ?>" placeholder="<?php esc_attr_e( 'Custom CSS class', 'themeflex' ); ?>">
					</div>
				</div>

				<div class="sf-field-row">
					<div class="sf-field-col">
						<label>
							<input type="checkbox" name="required" value="1" <?php checked( $required ); ?>>
							<?php esc_html_e( 'Required Field', 'themeflex' ); ?>
						</label>
					</div>
				</div>

				<div class="sf-field-row sf-field-options" style="display: none;">
					<div class="sf-field-col">
						<label><?php esc_html_e( 'Options (one per line)', 'themeflex' ); ?></label>
						<textarea name="options" placeholder="Option 1&#10;Option 2&#10;Option 3"><?php echo esc_textarea( implode( "\n", (array) $options ) ); ?></textarea>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Save form fields via AJAX
	 *
	 * @since 1.0.0
	 */
	public static function ajax_save_form_fields() {
		check_ajax_referer( 'sf_form_builder_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( esc_html__( 'Unauthorized', 'themeflex' ) );
		}

		$form_id = isset( $_POST['form_id'] ) ? intval( $_POST['form_id'] ) : 0;
		$fields = isset( $_POST['fields'] ) ? wp_kses_post_deep( $_POST['fields'] ) : array();
		$email = isset( $_POST['email'] ) ? sanitize_email( $_POST['email'] ) : '';
		$subject = isset( $_POST['subject'] ) ? sanitize_text_field( $_POST['subject'] ) : '';
		$success_msg = isset( $_POST['success_msg'] ) ? wp_kses_post( $_POST['success_msg'] ) : '';
		$redirect_url = isset( $_POST['redirect_url'] ) ? esc_url_raw( $_POST['redirect_url'] ) : '';

		if ( ! $form_id || ! current_user_can( 'edit_post', $form_id ) ) {
			wp_send_json_error( esc_html__( 'Invalid form', 'themeflex' ) );
		}

		update_post_meta( $form_id, '_sf_form_fields', wp_json_encode( $fields ) );
		update_post_meta( $form_id, '_sf_form_email', $email );
		update_post_meta( $form_id, '_sf_form_subject', $subject );
		update_post_meta( $form_id, '_sf_form_success_msg', $success_msg );
		update_post_meta( $form_id, '_sf_form_redirect_url', $redirect_url );

		wp_send_json_success( esc_html__( 'Form saved successfully', 'themeflex' ) );
	}

	/**
	 * Submit form via AJAX
	 *
	 * @since 1.0.0
	 */
	public static function ajax_submit_form() {
		check_ajax_referer( 'sf_forms_nonce', 'nonce' );

		$form_id = isset( $_POST['form_id'] ) ? intval( $_POST['form_id'] ) : 0;
		$form_data = isset( $_POST['form_data'] ) ? wp_kses_post_deep( $_POST['form_data'] ) : array();

		if ( ! $form_id ) {
			wp_send_json_error( esc_html__( 'Invalid form', 'themeflex' ) );
		}

		$form = get_post( $form_id );
		if ( ! $form || 'sf_form' !== $form->post_type ) {
			wp_send_json_error( esc_html__( 'Form not found', 'themeflex' ) );
		}

		// Verify honeypot.
		if ( ! empty( $_POST['sf_honeypot'] ) ) {
			wp_send_json_error( esc_html__( 'Invalid submission', 'themeflex' ) );
		}

		// Verify math captcha.
		$captcha_token  = isset( $_POST['sf_captcha_token'] ) ? sanitize_key( $_POST['sf_captcha_token'] ) : '';
		$captcha_answer = isset( $_POST['sf_captcha_answer'] ) ? intval( $_POST['sf_captcha_answer'] ) : '';
		if ( empty( $captcha_token ) ) {
			wp_send_json_error( esc_html__( 'Security check failed.', 'themeflex' ) );
		}
		$expected = get_transient( 'sf_captcha_' . $captcha_token );
		delete_transient( 'sf_captcha_' . $captcha_token ); // Single-use.
		if ( false === $expected || intval( $expected ) !== intval( $captcha_answer ) ) {
			wp_send_json_error( esc_html__( 'Incorrect answer to the security question. Please try again.', 'themeflex' ) );
		}

		// Get form fields and settings
		$fields = get_post_meta( $form_id, '_sf_form_fields', true );
		$fields = ! empty( $fields ) ? json_decode( $fields, true ) : array();
		$email = get_post_meta( $form_id, '_sf_form_email', true );
		$subject = get_post_meta( $form_id, '_sf_form_subject', true );
		$success_msg = get_post_meta( $form_id, '_sf_form_success_msg', true );
		$redirect_url = get_post_meta( $form_id, '_sf_form_redirect_url', true );

		// Validate and process submission
		$submission_data = array();
		foreach ( $fields as $field ) {
			$field_name = sanitize_key( $field['label'] );
			$field_type = $field['type'];
			$field_required = isset( $field['required'] ) ? $field['required'] : false;
			$field_value = isset( $form_data[ $field_name ] ) ? $form_data[ $field_name ] : '';

			// Validate required fields
			if ( $field_required && empty( $field_value ) ) {
				wp_send_json_error( sprintf(
					esc_html__( '%s is required', 'themeflex' ),
					esc_html( $field['label'] )
				) );
			}

			// Validate email fields
			if ( 'email' === $field_type && ! empty( $field_value ) ) {
				if ( ! is_email( $field_value ) ) {
					wp_send_json_error( sprintf(
						esc_html__( '%s must be a valid email', 'themeflex' ),
						esc_html( $field['label'] )
					) );
				}
			}

			// Sanitize value based on type
			if ( 'textarea' === $field_type ) {
				$field_value = wp_kses_post( $field_value );
			} elseif ( 'email' === $field_type ) {
				$field_value = sanitize_email( $field_value );
			} elseif ( 'url' === $field_type ) {
				$field_value = esc_url_raw( $field_value );
			} else {
				$field_value = sanitize_text_field( $field_value );
			}

			$submission_data[ $field['label'] ] = $field_value;
		}

		// Store submission in database
		global $wpdb;
		$wpdb->insert(
			$wpdb->prefix . 'sf_form_submissions',
			array(
				'form_id'           => $form_id,
				'submission_data'   => wp_json_encode( $submission_data ),
				'ip_address'        => sanitize_text_field( $_SERVER['REMOTE_ADDR'] ),
				'user_agent'        => sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ),
			),
			array( '%d', '%s', '%s', '%s' )
		);

		// Send email notification
		if ( ! empty( $email ) ) {
			$message = $subject ? $subject . "\n\n" : '';
			foreach ( $submission_data as $label => $value ) {
				$message .= $label . ': ' . $value . "\n";
			}

			wp_mail(
				$email,
				$subject ? sanitize_text_field( $subject ) : esc_html__( 'New Form Submission', 'themeflex' ),
				$message
			);
		}

		// Prepare response
		$response = array(
			'message' => $success_msg ? $success_msg : esc_html__( 'Thank you for your submission!', 'themeflex' ),
		);

		if ( ! empty( $redirect_url ) ) {
			$response['redirect'] = $redirect_url;
		}

		wp_send_json_success( $response );
	}

	/**
	 * Render form shortcode
	 *
	 * @since 1.0.0
	 * @param array $atts Shortcode attributes
	 * @return string Form HTML
	 */
	public static function render_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'id' => 0,
			),
			$atts,
			'sf_form'
		);

		$form_id = intval( $atts['id'] );
		$form = get_post( $form_id );

		if ( ! $form || 'sf_form' !== $form->post_type ) {
			return '';
		}

		$fields = get_post_meta( $form_id, '_sf_form_fields', true );
		$fields = ! empty( $fields ) ? json_decode( $fields, true ) : array();

		// Generate math captcha.
		$num_a         = wp_rand( 1, 12 );
		$num_b         = wp_rand( 1, 12 );
		$captcha_ops   = array( 'plus', 'minus' );
		$captcha_op    = $captcha_ops[ wp_rand( 0, 1 ) ];
		if ( 'minus' === $captcha_op && $num_b > $num_a ) {
			// Ensure non-negative result.
			list( $num_a, $num_b ) = array( $num_b, $num_a );
		}
		$captcha_answer  = ( 'plus' === $captcha_op ) ? $num_a + $num_b : $num_a - $num_b;
		$captcha_token   = wp_generate_password( 20, false );
		set_transient( 'sf_captcha_' . $captcha_token, $captcha_answer, 30 * MINUTE_IN_SECONDS );
		$captcha_symbol  = ( 'plus' === $captcha_op ) ? '+' : '−';
		/* translators: %1$d = first number, %2$s = operator symbol, %3$d = second number */
		$captcha_label   = sprintf( esc_html__( 'Security check: %1$d %2$s %3$d = ?', 'themeflex' ), $num_a, $captcha_symbol, $num_b );

		ob_start();
		?>
		<form class="sf-form" data-form-id="<?php echo esc_attr( $form_id ); ?>" method="post">
			<?php wp_nonce_field( 'sf_forms_nonce', 'nonce' ); ?>

			<input type="hidden" name="sf_honeypot" value="">
			<input type="hidden" name="sf_captcha_token" value="<?php echo esc_attr( $captcha_token ); ?>">

			<?php foreach ( $fields as $field ) : ?>
				<?php self::render_field( $field ); ?>
			<?php endforeach; ?>

			<div class="sf-field sf-field-captcha">
				<label class="sf-label" for="sf-captcha-<?php echo esc_attr( $form_id ); ?>">
					<?php echo esc_html( $captcha_label ); ?>
					<span class="sf-required" aria-hidden="true">*</span>
				</label>
				<input
					type="number"
					id="sf-captcha-<?php echo esc_attr( $form_id ); ?>"
					name="sf_captcha_answer"
					class="sf-input"
					inputmode="numeric"
					autocomplete="off"
					required
					aria-required="true"
					aria-label="<?php echo esc_attr( $captcha_label ); ?>"
				>
			</div>

			<button type="submit" class="sf-submit-btn">
				<?php esc_html_e( 'Submit', 'themeflex' ); ?>
			</button>
		</form>
		<?php
		return ob_get_clean();
	}

	/**
	 * Render a form field
	 *
	 * @since 1.0.0
	 * @param array $field Field data
	 */
	public static function render_field( $field ) {
		$type = isset( $field['type'] ) ? $field['type'] : 'text';
		$label = isset( $field['label'] ) ? $field['label'] : '';
		$placeholder = isset( $field['placeholder'] ) ? $field['placeholder'] : '';
		$required = isset( $field['required'] ) ? $field['required'] : false;
		$width = isset( $field['width'] ) ? $field['width'] : 'full';
		$css_class = isset( $field['css_class'] ) ? $field['css_class'] : '';
		$options = isset( $field['options'] ) ? $field['options'] : array();
		$field_name = sanitize_key( $label );

		$width_class = 'sf-field-width-' . $width;
		$required_attr = $required ? 'required' : '';

		?>
		<div class="sf-form-group <?php echo esc_attr( $width_class . ' ' . $css_class ); ?>">
			<?php if ( 'hidden' !== $type ) : ?>
				<label for="<?php echo esc_attr( $field_name ); ?>" class="sf-label">
					<?php echo esc_html( $label ); ?>
					<?php if ( $required ) : ?>
						<span class="sf-required">*</span>
					<?php endif; ?>
				</label>
			<?php endif; ?>

			<?php if ( 'textarea' === $type ) : ?>
				<textarea
					id="<?php echo esc_attr( $field_name ); ?>"
					name="<?php echo esc_attr( $field_name ); ?>"
					class="sf-input sf-textarea"
					placeholder="<?php echo esc_attr( $placeholder ); ?>"
					<?php echo wp_kses_post( $required_attr ); ?>
				></textarea>

			<?php elseif ( 'select' === $type ) : ?>
				<select
					id="<?php echo esc_attr( $field_name ); ?>"
					name="<?php echo esc_attr( $field_name ); ?>"
					class="sf-input sf-select"
					<?php echo wp_kses_post( $required_attr ); ?>
				>
					<option value=""><?php echo esc_html__( 'Select an option', 'themeflex' ); ?></option>
					<?php foreach ( (array) $options as $option ) : ?>
						<option value="<?php echo esc_attr( $option ); ?>"><?php echo esc_html( $option ); ?></option>
					<?php endforeach; ?>
				</select>

			<?php elseif ( 'radio' === $type ) : ?>
				<div class="sf-radio-group">
					<?php foreach ( (array) $options as $index => $option ) : ?>
						<label class="sf-radio-label">
							<input
								type="radio"
								name="<?php echo esc_attr( $field_name ); ?>"
								value="<?php echo esc_attr( $option ); ?>"
								class="sf-radio"
								<?php echo wp_kses_post( $required_attr ); ?>
							>
							<span><?php echo esc_html( $option ); ?></span>
						</label>
					<?php endforeach; ?>
				</div>

			<?php elseif ( 'checkbox' === $type ) : ?>
				<div class="sf-checkbox-group">
					<?php foreach ( (array) $options as $index => $option ) : ?>
						<label class="sf-checkbox-label">
							<input
								type="checkbox"
								name="<?php echo esc_attr( $field_name ); ?>[]"
								value="<?php echo esc_attr( $option ); ?>"
								class="sf-checkbox"
							>
							<span><?php echo esc_html( $option ); ?></span>
						</label>
					<?php endforeach; ?>
				</div>

			<?php elseif ( 'file' === $type ) : ?>
				<input
					type="file"
					id="<?php echo esc_attr( $field_name ); ?>"
					name="<?php echo esc_attr( $field_name ); ?>"
					class="sf-input sf-file"
					accept=".jpg,.jpeg,.png,.pdf,.doc,.docx"
					<?php echo wp_kses_post( $required_attr ); ?>
				>

			<?php elseif ( 'hidden' === $type ) : ?>
				<input
					type="hidden"
					name="<?php echo esc_attr( $field_name ); ?>"
					value="<?php echo esc_attr( $placeholder ); ?>"
				>

			<?php else : ?>
				<input
					type="<?php echo esc_attr( $type ); ?>"
					id="<?php echo esc_attr( $field_name ); ?>"
					name="<?php echo esc_attr( $field_name ); ?>"
					class="sf-input"
					placeholder="<?php echo esc_attr( $placeholder ); ?>"
					<?php echo wp_kses_post( $required_attr ); ?>
				>

			<?php endif; ?>
		</div>
		<?php
	}
}

// Initialize
if ( class_exists( 'ThemeFlex_Form_Builder' ) ) {
	ThemeFlex_Form_Builder::init();
}
