<?php
/**
 * Performance Optimizer
 * Critical CSS inline, resource preloading, lazy loading enhancements,
 * DNS prefetch, defer non-critical scripts, and resource hints.
 *
 * @package ThemeFlex
 * @since   1.1.0
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Performance {

    private static ?self $instance = null;

    public static function instance(): self {
        if (is_null(self::$instance)) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('wp_head',              [$this, 'output_resource_hints'], 2);
        add_action('wp_head',              [$this, 'output_critical_css'], 3);
        add_filter('wp_resource_hints',    [$this, 'add_preconnect'], 10, 2);
        add_filter('script_loader_tag',    [$this, 'defer_scripts'], 10, 3);
        add_filter('style_loader_tag',     [$this, 'preload_fonts'], 10, 4);
        add_action('wp_footer',            [$this, 'output_perf_hints']);
        add_filter('the_content',          [$this, 'add_lazy_loading_to_content']);
        add_filter('post_thumbnail_html',  [$this, 'add_lazy_to_thumbnail'], 10, 1);
        add_action('wp_enqueue_scripts',   [$this, 'preload_lcp_image']);
    }

    // ── Resource Hints (DNS Prefetch + Preconnect) ─────────────────────────

    public function add_preconnect(array $urls, string $relation_type): array {
        if ('preconnect' === $relation_type) {
            // Google Fonts preconnect (always needed — skin manager loads fonts).
            $urls[] = ['href' => 'https://fonts.googleapis.com'];
            $urls[] = ['href' => 'https://fonts.gstatic.com', 'crossorigin' => 'anonymous'];
            // cdnjs.cloudflare.com removed — Font Awesome replaced by Lucide SVG icons.
        }
        if ('dns-prefetch' === $relation_type) {
            // api.openai.com: only prefetch when AI assistant feature is active.
            if ( get_theme_mod( 'themeflex_ai_enabled', false ) ) {
                $urls[] = 'https://api.openai.com';
            }
            if (get_theme_mod('sf_google_maps_api_key')) {
                $urls[] = 'https://maps.googleapis.com';
            }
        }
        return $urls;
    }

    public function output_resource_hints(): void {
        // Google Fonts are managed exclusively by class-skin-manager.php which reads the
        // active skin's font_pair and outputs a single, correct Google Fonts URL.
        // Do NOT add a second font preload here — it creates a duplicate request.
        // Font Awesome has been fully removed; all icons use Lucide SVG (inline, zero-cost).
    }

    // ── Critical CSS (Above-the-fold styles inlined) ───────────────────────

    public function output_critical_css(): void {
        echo '<style id="sf-critical-css">';
        echo '
        /* Critical CSS — renders immediately before any stylesheet loads */
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        html{font-size:16px;-webkit-font-smoothing:antialiased;scroll-behavior:smooth}
        body{font-family:"Inter",-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:#fff;color:#64748b;overflow-x:hidden;line-height:1.625}
        .page_wrap,.body_wrap{width:100%}
        img{max-width:100%;height:auto}
        a{text-decoration:none;color:inherit}
        /* Prevent layout shift from preloader */
        body.sf-preloading{overflow:hidden}
        /* Skeleton state for LCP hero */
        .sf-hero-section{min-height:60vh}
        ';
        echo '</style>';
    }

    // ── Defer non-critical scripts ─────────────────────────────────────────

    public function defer_scripts(string $tag, string $handle, string $src): string {
        $defer_handles = ['jquery', 'elementor-frontend', 'wp-embed'];
        // Skip Elementor and our own scripts from defer to avoid rendering issues
        $skip = ['themeflex-front-page', 'themeflex-custom', 'themeflex-elementor'];
        if (in_array($handle, $skip, true)) return $tag;
        if (in_array($handle, $defer_handles, true)) {
            return str_replace(' src', ' defer src', $tag);
        }
        return $tag;
    }

    // ── Font Preloading ────────────────────────────────────────────────────

    public function preload_fonts(string $html, string $handle, string $href, string $media): string {
        return $html;
    }

    // ── LCP Image Preload ─────────────────────────────────────────────────

    public function preload_lcp_image(): void {
        if (!is_singular() && !is_front_page()) return;
        $thumb = get_the_post_thumbnail_url(get_the_ID(), 'full');
        if ($thumb) {
            add_action('wp_head', function() use ($thumb) {
                echo '<link rel="preload" as="image" href="'.esc_url($thumb).'" fetchpriority="high">'."\n";
            }, 1);
        }
    }

    // ── Lazy Loading Enhancement ───────────────────────────────────────────

    public function add_lazy_loading_to_content(string $content): string {
        // Add loading="lazy" and decoding="async" to all images that don't have it
        $content = preg_replace('/<img(?![^>]*loading=)([^>]*)>/i', '<img loading="lazy" decoding="async"$1>', $content);
        return $content;
    }

    public function add_lazy_to_thumbnail(string $html): string {
        if (strpos($html, 'loading=') === false) {
            $html = str_replace('<img ', '<img loading="lazy" decoding="async" ', $html);
        }
        return $html;
    }

    // ── Footer: Performance JS Hints ──────────────────────────────────────

    public function output_perf_hints(): void {
        ?>
        <script>
        // Register service worker for offline caching (if supported)
        if ('serviceWorker' in navigator && '<?php echo is_ssl() ? '1' : '0'; ?>' === '1') {
            window.addEventListener('load', function() {
                navigator.serviceWorker.register('<?php echo esc_js(get_template_directory_uri()); ?>/sw.js')
                    .catch(function() {}); // Silent fail if sw.js not present
            });
        }
        // Prefetch visible links on hover
        var prefetched = new Set();
        document.addEventListener('mouseover', function(e) {
            var a = e.target.closest('a[href]');
            if (!a) return;
            var href = a.href;
            if (!href || href.startsWith('#') || prefetched.has(href)) return;
            if (href.startsWith(window.location.origin)) {
                prefetched.add(href);
                var link = document.createElement('link');
                link.rel = 'prefetch'; link.href = href;
                document.head.appendChild(link);
            }
        }, { passive: true });
        </script>
        <?php
    }
}

ThemeFlex_Performance::instance();
