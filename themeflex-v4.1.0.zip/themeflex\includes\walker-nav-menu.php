<?php
/**
 * Custom Menu Walker for ThemeFlex
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Custom menu walker for better output
 *
 * @since 1.0.0
 */
class ThemeFlex_Nav_Menu_Walker extends Walker_Nav_Menu {

	/**
	 * Starts the list before the elements are added.
	 *
	 * @since 1.0.0
	 *
	 * @param string   $output Passed by reference. Used to append additional content.
	 * @param int      $depth  Depth of menu item. Used for padding.
	 * @param stdClass $args   An object of wp_nav_menu() arguments.
	 */
	public function start_lvl( &$output, $depth = 0, $args = null ) {
		if ( isset( $args->item_spacing ) && 'discard' === $args->item_spacing ) {
			$indent = '';
			$newline = '';
		} else {
			$indent  = str_repeat( "\t", $depth );
			$newline = "\n";
		}
		$output .= "{$newline}{$indent}<ul class=\"sub-menu menu-depth-" . ( $depth + 1 ) . "\">{$newline}";
	}

	/**
	 * Starts the element output.
	 *
	 * @since 1.0.0
	 *
	 * @param string   $output Passed by reference. Used to append additional content.
	 * @param WP_Post  $item   Menu item data object.
	 * @param int      $depth  Depth of menu item. Used for padding.
	 * @param stdClass $args   An object of wp_nav_menu() arguments.
	 * @param int      $id     Current item ID.
	 */
	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
		if ( isset( $args->item_spacing ) && 'discard' === $args->item_spacing ) {
			$indent = '';
			$newline = '';
		} else {
			$indent  = ( $depth ) ? str_repeat( "\t", $depth ) : '';
			$newline = "\n";
		}

		$indent .= str_repeat( "\t", 1 );

		$classes   = empty( $item->classes ) ? array() : (array) $item->classes;
		$classes[] = 'menu-item-' . $item->ID;

		if ( isset( $args->active_class ) && in_array( 'current-menu-item', $classes, true ) ) {
			$classes[] = $args->active_class;
		}

		$args = apply_filters( 'nav_menu_item_args', $args, $item, $depth );

		$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args, $depth ) );
		$class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

		$id = apply_filters( 'nav_menu_item_id', 'menu-item-' . $item->ID, $item, $args, $depth );
		$id = $id ? ' id="' . esc_attr( $id ) . '"' : '';

		$output .= $indent . '<li' . $id . $class_names . '>';

		$atts = array();
		$atts['title']  = ! empty( $item->attr_title ) ? $item->attr_title : '';
		$atts['target'] = ! empty( $item->target ) ? $item->target : '';
		$atts['rel']    = ! empty( $item->xfn ) ? $item->xfn : '';
		$atts['href']   = ! empty( $item->url ) ? $item->url : '';

		$atts = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args, $depth );

		$attributes = '';
		foreach ( $atts as $attr => $value ) {
			if ( ! empty( $value ) ) {
				$value      = 'href' === $attr ? esc_url( $value ) : esc_attr( $value );
				$attributes .= ' ' . $attr . '="' . $value . '"';
			}
		}

		$title = apply_filters( 'nav_menu_item_title', $item->title, $item, $args, $depth );
		$title = apply_filters( 'the_title', $title, $item->ID );
		$title = apply_filters( 'nav_menu_item_title', $title, $item, $args, $depth );

		$item_output = $args->before;
		$item_output .= '<a' . $attributes . '>';
		$item_output .= $args->link_before . $title . $args->link_after;
		$item_output .= '</a>';
		$item_output .= $args->after;

		$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
	}
}

/**
 * Backward-compatibility alias — renamed from Starter_Flavor_Nav_Menu_Walker
 * in ThemeFlex v3.1.0. The old class name is kept for one major version so
 * child themes and plugins that reference it continue to work without changes.
 *
 * @deprecated 3.1.0 Use ThemeFlex_Nav_Menu_Walker instead.
 * @since      3.1.0
 */
if ( ! class_exists( 'Starter_Flavor_Nav_Menu_Walker' ) ) {
	class_alias( 'ThemeFlex_Nav_Menu_Walker', 'Starter_Flavor_Nav_Menu_Walker' );
}
