<?php
/**
 * Template Name: Music Artist & Label Homepage
 * Template Post Type: page
 *
 * ThemeFlex – Starter Flavor: Dark Stage / Artist Portfolio
 * Namespace : --mu-*
 * Fonts     : Space Grotesk (display) + Inter (body)
 * Palette   : Void #060810 / Neon #E8FF00 / Electric #FF3D6B / Steel #8892A4 / Smoke #1A1D28
 */
defined('ABSPATH') || exit;
get_header();

/* ── Palette ─────────────────────────────────────────────── */
$mu_void    = '#060810';
$mu_neon    = '#E8FF00';
$mu_elec    = '#FF3D6B';
$mu_steel   = '#8892A4';
$mu_smoke   = '#1A1D28';
$mu_white   = '#FFFFFF';
$mu_mid     = '#E2E8F0';

/* ── PHP random seed (deterministic) ────────────────────── */
srand(crc32('mu-artist-hero'));

/* ── Hero waveform bars ──────────────────────────────────── */
$mu_bars = [];
for($b=0;$b<64;$b++){
  $mu_bars[] = [
    'h' => rand(8,100),
    'c' => ($b%7===0)?$mu_elec:($b%5===0?$mu_neon:'rgba(232,255,0,.15)'),
  ];
}

/* ── Discography ─────────────────────────────────────────── */
$mu_albums = [
  ['title'=>'Signals','year'=>'2026','tracks'=>12,'label'=>'LP','color'=>'#E8FF00','bg'=>'#0D1022','desc'=>'Debut full-length — eleven tracks of post-industrial synth and fractured rhythm.'],
  ['title'=>'Drift EP','year'=>'2025','tracks'=>5,'label'=>'EP','color'=>'#FF3D6B','bg'=>'#1A0A12','desc'=>'Five explorations in ambient texture recorded over one winter in Oslo.'],
  ['title'=>'Fault Lines','year'=>'2024','tracks'=>8,'label'=>'LP','color'=>'#8892A4','bg'=>'#0E0E1A','desc'=>'Collaborative record with producer SKHM — industrial beats meet string arrangements.'],
  ['title'=>'Static','year'=>'2023','tracks'=>4,'label'=>'EP','color'=>'#FFFFFF','bg'=>'#111118','desc'=>'Early EP — raw digital noise sculpted into four short meditations.'],
];

/* ── Tour Dates ──────────────────────────────────────────── */
$mu_tours = [
  ['date'=>'12 Jun 2026','venue'=>'Fabric','city'=>'London, UK','status'=>'few-left'],
  ['date'=>'15 Jun 2026','venue'=>'Berghain','city'=>'Berlin, DE','status'=>'sold-out'],
  ['date'=>'20 Jun 2026','venue'=>'Boiler Room','city'=>'Amsterdam, NL','status'=>'available'],
  ['date'=>'28 Jun 2026','venue'=>'La Machine du Moulin Rouge','city'=>'Paris, FR','status'=>'available'],
  ['date'=>'04 Jul 2026','venue'=>'Output','city'=>'Brooklyn, NY, US','status'=>'available'],
  ['date'=>'07 Jul 2026','venue'=>'Smart Bar','city'=>'Chicago, IL, US','status'=>'few-left'],
  ['date'=>'12 Jul 2026','venue'=>'Echoplex','city'=>'Los Angeles, CA, US','status'=>'available'],
  ['date'=>'19 Jul 2026','venue'=>'Moog','city'=>'Barcelona, ES','status'=>'sold-out'],
];

/* ── Merch ───────────────────────────────────────────────── */
$mu_merch = [
  ['name'=>'SIGNALS Hoodie','price'=>'58','color'=>'#1A1D28','badge'=>'New'],
  ['name'=>'Neon Logo Tee','price'=>'32','color'=>'#060810','badge'=>''],
  ['name'=>'Static Vinyl (Ltd)','price'=>'24','color'=>'#0D0D14','badge'=>'Ltd'],
  ['name'=>'Tour Poster A2','price'=>'18','color'=>'#111118','badge'=>''],
];

/* ── Press Quotes ────────────────────────────────────────── */
$mu_press = [
  ['pub'=>'Pitchfork','score'=>'8.4','quote'=>'"A genuinely new voice in electronic music — unsettling in all the right ways."'],
  ['pub'=>'NME','score'=>'★★★★','quote'=>'"VHRL makes music that sounds like the inside of a collapsing data centre."'],
  ['pub'=>'The Wire','score'=>'Recommended','quote'=>'"Fault Lines is 2024\'s most thoughtfully constructed noise record."'],
];
?>
<!- GLOBAL CSS ──────────────────────────────────────────── -->
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600&display=swap');
:root{
  --mu-void:<?php echo $mu_void; ?>;
  --mu-neon:<?php echo $mu_neon; ?>;
  --mu-elec:<?php echo $mu_elec; ?>;
  --mu-steel:<?php echo $mu_steel; ?>;
  --mu-smoke:<?php echo $mu_smoke; ?>;
}
.mu-page{font-family:'Inter',system-ui,sans-serif;background:var(--mu-void);color:var(--mu-mid);line-height:1.6;margin:0;}
.mu-container{max-width:1200px;margin:0 auto;padding:0 2rem;}
.mu-section{padding:6rem 0;}
.mu-reveal{opacity:0;transform:translateY(28px);transition:opacity .7s ease,transform .7s ease;}
.mu-reveal.mu-visible{opacity:1;transform:none;}
/* Neon glow utility */
.mu-glow{text-shadow:0 0 20px var(--mu-neon),0 0 60px rgba(232,255,0,.3);}
.mu-glow-elec{text-shadow:0 0 20px var(--mu-elec),0 0 50px rgba(255,61,107,.3);}
/* Section eyebrow */
.mu-eyebrow{font-family:'Space Grotesk',sans-serif;font-size:.68rem;letter-spacing:.28em;text-transform:uppercase;color:var(--mu-steel);margin-bottom:.75rem;}
/* Waveform bars */
.mu-wave{display:flex;align-items:flex-end;gap:2px;height:100px;width:100%;}
.mu-wave__bar{flex:1;border-radius:1px 1px 0 0;transition:height .4s ease;}
/* Tour table */
.mu-tour{width:100%;border-collapse:collapse;}
.mu-tour tr{border-bottom:1px solid rgba(255,255,255,.06);}
.mu-tour tr:first-child{border-top:1px solid rgba(255,255,255,.06);}
.mu-tour td{padding:1.25rem 0;font-size:.9rem;vertical-align:middle;}
.mu-tour td:last-child{text-align:right;}
/* Status pills */
.mu-pill{display:inline-block;padding:.2rem .75rem;border-radius:2px;font-size:.65rem;letter-spacing:.12em;text-transform:uppercase;font-family:'Space Grotesk',sans-serif;}
.mu-pill--av{background:rgba(232,255,0,.12);color:var(--mu-neon);border:1px solid rgba(232,255,0,.25);}
.mu-pill--few{background:rgba(255,61,107,.12);color:var(--mu-elec);border:1px solid rgba(255,61,107,.25);}
.mu-pill--so{background:rgba(136,146,164,.12);color:var(--mu-steel);border:1px solid rgba(136,146,164,.2);}
/* Merch card */
.mu-merch-card{background:var(--mu-smoke);border-radius:4px;overflow:hidden;position:relative;cursor:pointer;transition:transform .3s ease,box-shadow .3s ease;}
.mu-merch-card:hover{transform:translateY(-4px);box-shadow:0 20px 50px rgba(232,255,0,.08);}
/* FAQ */
.mu-faq__a{max-height:0;overflow:hidden;transition:max-height .4s ease;}
.mu-faq.mu-open .mu-faq__a{max-height:300px;}
</style>

<div class="mu-page">

  <!-- HERO ─────────────────────────────────────────────────── -->
  <section style="min-height:100vh;position:relative;display:flex;flex-direction:column;justify-content:flex-end;overflow:hidden;background:var(--mu-void);" aria-labelledby="mu-hero-title">

    <!-- Background grid -->
    <div aria-hidden="true" style="position:absolute;inset:0;background-image:linear-gradient(rgba(232,255,0,.025) 1px,transparent 1px),linear-gradient(90deg,rgba(232,255,0,.025) 1px,transparent 1px);background-size:60px 60px;"></div>

    <!-- Radial spotlight -->
    <div aria-hidden="true" style="position:absolute;top:-10%;left:50%;transform:translateX(-50%);width:900px;height:700px;background:radial-gradient(ellipse at 50% 0%,rgba(232,255,0,.07) 0%,transparent 65%);pointer-events:none;"></div>

    <!-- Electric spot bottom left -->
    <div aria-hidden="true" style="position:absolute;bottom:0;left:-100px;width:600px;height:400px;background:radial-gradient(ellipse at 0% 100%,rgba(255,61,107,.09) 0%,transparent 60%);pointer-events:none;"></div>

    <!-- Artist name super-large -->
    <div aria-hidden="true" style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-family:'Space Grotesk',sans-serif;font-size:clamp(6rem,18vw,22rem);font-weight:700;color:rgba(255,255,255,.025);letter-spacing:-.04em;white-space:nowrap;user-select:none;pointer-events:none;line-height:1;">VHRL</div>

    <!-- CSS Stage Scene ─────────────────────────────────── -->
    <div aria-hidden="true" style="position:absolute;top:0;left:0;right:0;height:65%;display:flex;align-items:flex-end;justify-content:center;gap:0;overflow:hidden;">
      <!-- Stage floor -->
      <div style="position:absolute;bottom:0;left:0;right:0;height:35%;background:linear-gradient(0deg,rgba(232,255,0,.03) 0%,transparent 100%);"></div>
      <!-- Hanging lights row -->
      <?php for($hl=0;$hl<9;$hl++):
        $lit = ($hl%3===0)?$mu_neon:($hl%3===1?$mu_elec:'rgba(255,255,255,.4)');
        $lx = 6 + $hl * 11;
      ?>
      <div style="position:absolute;top:0;left:<?php echo $lx; ?>%;display:flex;flex-direction:column;align-items:center;">
        <div style="width:1px;height:<?php echo 60+$hl*12; ?>px;background:rgba(255,255,255,.08);"></div>
        <div style="width:18px;height:18px;border-radius:50%;background:<?php echo $lit; ?>;box-shadow:0 0 18px <?php echo $lit; ?>,0 0 60px <?php echo $lit; ?>,0 0 120px <?php echo $lit; ?>;"></div>
      </div>
      <?php endfor; ?>
      <!-- Artist silhouette — CSS figure at microphone -->
      <!-- Base -->
      <div style="position:absolute;bottom:18%;left:50%;transform:translateX(-50%);width:280px;height:4px;background:rgba(232,255,0,.12);border-radius:2px;box-shadow:0 0 30px rgba(232,255,0,.2);"></div>
      <!-- Legs -->
      <div style="position:absolute;bottom:18%;left:calc(50% - 18px);width:12px;height:80px;background:#1A1D28;"></div>
      <div style="position:absolute;bottom:18%;left:calc(50% + 6px);width:12px;height:80px;background:#1A1D28;"></div>
      <!-- Body -->
      <div style="position:absolute;bottom:calc(18% + 80px);left:calc(50% - 20px);width:40px;height:65px;background:#222533;border-radius:4px 4px 0 0;"></div>
      <!-- Arm L (extended to mic) -->
      <div style="position:absolute;bottom:calc(18% + 115px);left:calc(50% - 50px);width:38px;height:8px;background:#1E2130;border-radius:4px;transform:rotate(-25deg);transform-origin:right center;"></div>
      <!-- Arm R (down) -->
      <div style="position:absolute;bottom:calc(18% + 90px);left:calc(50% + 20px);width:8px;height:40px;background:#1E2130;border-radius:4px;"></div>
      <!-- Head -->
      <div style="position:absolute;bottom:calc(18% + 145px);left:calc(50% - 14px);width:28px;height:28px;border-radius:50%;background:#C4956A;box-shadow:0 0 0 2px rgba(232,255,0,.1);"></div>
      <!-- Hair -->
      <div style="position:absolute;bottom:calc(18% + 162px);left:calc(50% - 16px);width:32px;height:14px;background:#1A0A0A;border-radius:8px 8px 0 0;"></div>
      <!-- Mic stand -->
      <div style="position:absolute;bottom:calc(18% + 80px);left:calc(50% - 3px);width:2px;height:70px;background:rgba(255,255,255,.25);"></div>
      <!-- Mic head -->
      <div style="position:absolute;bottom:calc(18% + 148px);left:calc(50% - 6px);width:12px;height:20px;border-radius:50% 50% 30% 30%;background:rgba(255,255,255,.3);box-shadow:0 0 8px rgba(232,255,0,.4);"></div>
      <!-- Spotlight cone on artist -->
      <div style="position:absolute;top:0;left:calc(50% - 80px);width:160px;height:100%;background:linear-gradient(180deg,rgba(232,255,0,.05) 0%,transparent 80%);clip-path:polygon(35% 0%,65% 0%,100% 100%,0% 100%);"></div>
      <!-- Floor glow under artist -->
      <div style="position:absolute;bottom:18%;left:calc(50% - 80px);width:160px;height:30px;background:radial-gradient(ellipse,rgba(232,255,0,.18) 0%,transparent 70%);border-radius:50%;"></div>
    </div>

    <!-- Hero waveform -->
    <div aria-hidden="true" style="position:absolute;bottom:0;left:0;right:0;height:120px;display:flex;align-items:flex-end;gap:2px;padding:0 2rem;overflow:hidden;opacity:.35;">
      <?php foreach($mu_bars as $bar): ?>
      <div style="flex:1;height:<?php echo $bar['h']; ?>%;background:<?php echo esc_attr($bar['c']); ?>;border-radius:1px 1px 0 0;min-width:0;"></div>
      <?php endforeach; ?>
    </div>

    <!-- Hero Content -->
    <div class="mu-container" style="position:relative;z-index:2;padding-bottom:5rem;">
      <div style="max-width:700px;">
        <p class="mu-eyebrow" style="color:var(--mu-neon);margin-bottom:1.25rem;animation:none;">New Album — SIGNALS — Out Now</p>
        <h1 id="mu-hero-title" class="mu-glow" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(3.5rem,8vw,7rem);font-weight:700;color:#ffffff;line-height:.95;letter-spacing:-.04em;margin:0 0 1.5rem;">VHRL</h1>
        <p style="font-size:1.1rem;color:var(--mu-steel);max-width:480px;line-height:1.7;margin:0 0 2.5rem;">Electronic artist. Composer of the in-between. Based in Berlin and broadcasting on all frequencies.</p>
        <div style="display:flex;gap:1rem;flex-wrap:wrap;align-items:center;">
          <a href="<?php echo esc_url(home_url('/listen')); ?>" style="display:inline-flex;align-items:center;gap:.6rem;padding:.9rem 2rem;background:var(--mu-neon);color:var(--mu-void);font-family:'Space Grotesk',sans-serif;font-size:.8rem;font-weight:600;letter-spacing:.12em;text-transform:uppercase;text-decoration:none;border-radius:2px;">
            <span aria-hidden="true" style="font-size:1rem;">&#9654;</span> Listen Now
          </a>
          <a href="<?php echo esc_url(home_url('/tour')); ?>" style="display:inline-block;padding:.9rem 2rem;border:1px solid rgba(255,255,255,.15);color:var(--mu-mid);font-family:'Space Grotesk',sans-serif;font-size:.8rem;letter-spacing:.12em;text-transform:uppercase;text-decoration:none;border-radius:2px;">Tour Dates</a>
          <div style="display:flex;gap:1rem;align-items:center;margin-left:.5rem;">
            <?php
            $mu_platforms=[
              ['n'=>'Spotify','u'=>'https://spotify.com','ic'=>'&#9835;'],
              ['n'=>'Apple Music','u'=>'https://music.apple.com','ic'=>'&#9836;'],
              ['n'=>'Bandcamp','u'=>'https://bandcamp.com','ic'=>'&#9833;'],
              ['n'=>'SoundCloud','u'=>'https://soundcloud.com','ic'=>'&#127925;'],
            ];
            foreach($mu_platforms as $pl):?>
            <a href="<?php echo esc_url($pl['u']); ?>" aria-label="<?php echo esc_attr($pl['n']); ?>" style="width:36px;height:36px;border-radius:50%;border:1px solid rgba(255,255,255,.1);display:flex;align-items:center;justify-content:center;color:var(--mu-steel);font-size:.9rem;text-decoration:none;transition:border-color .2s,color .2s;" title="<?php echo esc_attr($pl['n']); ?>"><?php echo $pl['ic']; ?></a>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- LATEST RELEASE / FEATURED TRACK ────────────────────── -->
  <section class="mu-section" style="background:var(--mu-smoke);" aria-labelledby="mu-release-title">
    <div class="mu-container">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:5rem;align-items:center;">
        <!-- Album art CSS -->
        <div class="mu-reveal" style="aspect-ratio:1;background:#0D1022;border-radius:6px;position:relative;overflow:hidden;box-shadow:0 40px 100px rgba(232,255,0,.1);">
          <!-- Geometric record design -->
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;">
            <!-- Outer ring -->
            <div style="width:85%;height:85%;border-radius:50%;border:1px solid rgba(232,255,0,.08);position:absolute;"></div>
            <div style="width:72%;height:72%;border-radius:50%;border:1px solid rgba(232,255,0,.05);position:absolute;"></div>
            <div style="width:55%;height:55%;border-radius:50%;border:1px solid rgba(232,255,0,.08);position:absolute;"></div>
            <!-- Center circle -->
            <div style="width:18%;height:18%;border-radius:50%;background:linear-gradient(135deg,var(--mu-neon),rgba(232,255,0,.4));position:absolute;box-shadow:0 0 30px rgba(232,255,0,.4);"></div>
            <!-- Diagonal lines -->
            <div style="position:absolute;inset:0;background:repeating-linear-gradient(45deg,transparent,transparent 18px,rgba(232,255,0,.02) 18px,rgba(232,255,0,.02) 19px);"></div>
          </div>
          <!-- Album title text overlay -->
          <div style="position:absolute;bottom:2rem;left:2rem;right:2rem;">
            <p style="font-family:'Space Grotesk',sans-serif;font-size:3rem;font-weight:700;color:rgba(232,255,0,.1);letter-spacing:-.04em;line-height:1;margin:0;">SIGNALS</p>
          </div>
          <!-- Neon corner accent -->
          <div style="position:absolute;top:0;right:0;width:80px;height:80px;background:linear-gradient(225deg,rgba(255,61,107,.12) 0%,transparent 60%);"></div>
        </div>
        <!-- Release info -->
        <div class="mu-reveal" style="transition-delay:120ms;">
          <p class="mu-eyebrow">New Album — 2026</p>
          <h2 id="mu-release-title" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(2.5rem,4vw,4rem);font-weight:700;color:#ffffff;letter-spacing:-.03em;margin:0 0 .5rem;line-height:1.05;">SIGNALS</h2>
          <p style="font-size:.95rem;color:var(--mu-steel);line-height:1.7;margin:0 0 2rem;max-width:440px;">Twelve tracks of post-industrial synthesis. Recorded between Berlin and the Faroe Islands over fourteen months. Available everywhere.</p>
          <!-- Tracklist (first 5) -->
          <ol style="list-style:none;padding:0;margin:0 0 2rem;border-top:1px solid rgba(255,255,255,.06);">
            <?php
            $mu_tracks=[
              ['n'=>'Carrier Wave','t'=>'4:12'],
              ['n'=>'Threshold','t'=>'3:51'],
              ['n'=>'Iron Meridian','t'=>'5:08'],
              ['n'=>'Signal Loss','t'=>'4:44'],
              ['n'=>'Ghost Protocol','t'=>'6:02'],
            ];
            foreach($mu_tracks as $ti=>$tr):?>
            <li style="display:flex;align-items:center;justify-content:space-between;padding:.85rem 0;border-bottom:1px solid rgba(255,255,255,.06);">
              <div style="display:flex;align-items:center;gap:1rem;">
                <span style="font-family:'Space Grotesk',sans-serif;font-size:.75rem;color:var(--mu-steel);min-width:1.5rem;"><?php echo str_pad($ti+1,2,'0',STR_PAD_LEFT); ?></span>
                <span style="font-size:.9rem;color:var(--mu-mid);"><?php echo esc_html($tr['n']); ?></span>
              </div>
              <div style="display:flex;align-items:center;gap:1rem;">
                <span style="font-size:.8rem;color:var(--mu-steel);"><?php echo esc_html($tr['t']); ?></span>
                <button style="width:28px;height:28px;border-radius:50%;background:rgba(232,255,0,.1);border:none;cursor:pointer;color:var(--mu-neon);font-size:.7rem;" aria-label="Play <?php echo esc_attr($tr['n']); ?>">&#9654;</button>
              </div>
            </li>
            <?php endforeach; ?>
          </ol>
          <div style="display:flex;gap:1rem;">
            <a href="<?php echo esc_url(home_url('/listen/signals')); ?>" style="padding:.8rem 1.75rem;background:var(--mu-neon);color:var(--mu-void);font-family:'Space Grotesk',sans-serif;font-size:.75rem;font-weight:600;letter-spacing:.12em;text-transform:uppercase;text-decoration:none;border-radius:2px;">Stream Now</a>
            <a href="<?php echo esc_url(home_url('/shop/signals-vinyl')); ?>" style="padding:.8rem 1.75rem;border:1px solid rgba(255,255,255,.12);color:var(--mu-mid);font-family:'Space Grotesk',sans-serif;font-size:.75rem;letter-spacing:.12em;text-transform:uppercase;text-decoration:none;border-radius:2px;">Buy Vinyl</a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- DISCOGRAPHY ─────────────────────────────────────────── -->
  <section class="mu-section" style="background:var(--mu-void);" aria-labelledby="mu-disco-title">
    <div class="mu-container">
      <div class="mu-reveal" style="margin-bottom:3.5rem;">
        <p class="mu-eyebrow">Full Catalogue</p>
        <h2 id="mu-disco-title" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(2rem,3vw,2.75rem);font-weight:700;color:#ffffff;letter-spacing:-.03em;margin:0;">Discography</h2>
      </div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:1.25rem;">
        <?php foreach($mu_albums as $ai=>$alb): ?>
        <article class="mu-reveal" style="transition-delay:<?php echo $ai*80; ?>ms;background:<?php echo esc_attr($alb['bg']); ?>;border-radius:4px;overflow:hidden;cursor:pointer;border:1px solid rgba(255,255,255,.05);transition:border-color .3s ease,transform .3s ease;" onmouseenter="this.style.borderColor='rgba(232,255,0,.2)';this.style.transform='translateY(-3px)'" onmouseleave="this.style.borderColor='rgba(255,255,255,.05)';this.style.transform='none'">
          <!-- Artwork -->
          <div style="aspect-ratio:1;position:relative;overflow:hidden;background:<?php echo esc_attr($alb['bg']); ?>;">
            <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;">
              <div style="width:70%;height:70%;border-radius:50%;border:2px solid <?php echo esc_attr($alb['color']); ?>;opacity:.3;"></div>
              <div style="position:absolute;width:45%;height:45%;border-radius:50%;background:radial-gradient(circle,<?php echo esc_attr($alb['color']); ?>22 0%,transparent 70%);"></div>
              <p style="position:absolute;font-family:'Space Grotesk',sans-serif;font-size:1.5rem;font-weight:700;color:<?php echo esc_attr($alb['color']); ?>;opacity:.2;letter-spacing:-.04em;"><?php echo esc_html($alb['title']); ?></p>
            </div>
            <div style="position:absolute;top:.75rem;left:.75rem;background:<?php echo esc_attr($alb['color']); ?>;color:<?php echo $alb['color']===$mu_neon?$mu_void:'#ffffff'; ?>;font-family:'Space Grotesk',sans-serif;font-size:.55rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;padding:.2rem .5rem;border-radius:2px;"><?php echo esc_html($alb['label']); ?></div>
          </div>
          <div style="padding:1rem;">
            <h3 style="font-family:'Space Grotesk',sans-serif;font-size:1rem;font-weight:600;color:#ffffff;margin:0 0 .25rem;"><?php echo esc_html($alb['title']); ?></h3>
            <p style="font-size:.75rem;color:var(--mu-steel);margin:0 0 .6rem;"><?php echo esc_html($alb['year']); ?> · <?php echo esc_html($alb['tracks']); ?> tracks</p>
            <p style="font-size:.78rem;color:var(--mu-steel);line-height:1.55;margin:0 0 1rem;"><?php echo esc_html($alb['desc']); ?></p>
            <a href="<?php echo esc_url(home_url('/music/'.sanitize_title($alb['title']))); ?>" style="font-family:'Space Grotesk',sans-serif;font-size:.7rem;letter-spacing:.1em;text-transform:uppercase;color:<?php echo esc_attr($alb['color']); ?>;text-decoration:none;border-bottom:1px solid <?php echo esc_attr($alb['color']); ?>;padding-bottom:1px;">Listen &#8594;</a>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- TOUR DATES ──────────────────────────────────────────── -->
  <section class="mu-section" style="background:var(--mu-smoke);" aria-labelledby="mu-tour-title">
    <div class="mu-container">
      <div style="display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:3.5rem;flex-wrap:wrap;gap:1.5rem;">
        <div class="mu-reveal">
          <p class="mu-eyebrow">Live</p>
          <h2 id="mu-tour-title" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(2rem,3vw,2.75rem);font-weight:700;color:#ffffff;letter-spacing:-.03em;margin:0;">Tour Dates 2026</h2>
        </div>
        <a href="<?php echo esc_url(home_url('/tour')); ?>" class="mu-reveal" style="padding:.75rem 1.75rem;border:1px solid rgba(255,255,255,.12);color:var(--mu-mid);font-family:'Space Grotesk',sans-serif;font-size:.75rem;letter-spacing:.12em;text-transform:uppercase;text-decoration:none;border-radius:2px;">All Dates</a>
      </div>
      <table class="mu-tour mu-reveal" role="table" aria-label="Tour dates">
        <thead style="display:none"><tr><th>Date</th><th>Venue</th><th>City</th><th>Status</th><th>Tickets</th></tr></thead>
        <tbody>
        <?php foreach($mu_tours as $td=>$t):
          $sc = $t['status']==='sold-out'?'mu-pill--so':($t['status']==='few-left'?'mu-pill--few':'mu-pill--av');
          $sl = $t['status']==='sold-out'?'Sold Out':($t['status']==='few-left'?'Few Left':'Tickets');
        ?>
        <tr style="transition-delay:<?php echo $td*50; ?>ms;">
          <td style="font-family:'Space Grotesk',sans-serif;font-weight:500;color:#ffffff;width:130px;font-size:.875rem;"><?php echo esc_html($t['date']); ?></td>
          <td style="color:var(--mu-mid);padding-left:2rem;"><?php echo esc_html($t['venue']); ?></td>
          <td style="color:var(--mu-steel);font-size:.875rem;"><?php echo esc_html($t['city']); ?></td>
          <td style="text-align:right;">
            <?php if($t['status']==='sold-out'): ?>
            <span class="mu-pill <?php echo $sc; ?>" aria-label="Sold out"><?php echo $sl; ?></span>
            <?php else: ?>
            <a href="<?php echo esc_url(home_url('/tickets/'.sanitize_title($t['venue'].'-'.$t['city']))); ?>" class="mu-pill <?php echo $sc; ?>" style="text-decoration:none;"><?php echo esc_html($sl); ?></a>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </section>

  <!-- PRESS QUOTES ────────────────────────────────────────── -->
  <section class="mu-section" style="background:var(--mu-void);border-top:1px solid rgba(255,255,255,.05);" aria-labelledby="mu-press-title">
    <div class="mu-container">
      <div class="mu-reveal" style="text-align:center;margin-bottom:3.5rem;">
        <p class="mu-eyebrow">Critical Reception</p>
        <h2 id="mu-press-title" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(2rem,3vw,2.5rem);font-weight:700;color:#ffffff;letter-spacing:-.03em;margin:0;">Press</h2>
      </div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:1.5rem;">
        <?php foreach($mu_press as $pp=>$pr): ?>
        <blockquote class="mu-reveal" style="transition-delay:<?php echo $pp*100; ?>ms;margin:0;background:var(--mu-smoke);border:1px solid rgba(255,255,255,.06);border-radius:4px;padding:2rem;position:relative;overflow:hidden;">
          <div aria-hidden="true" style="position:absolute;top:1rem;right:1.5rem;font-family:'Space Grotesk',sans-serif;font-size:4rem;color:rgba(232,255,0,.04);font-weight:700;line-height:1;">&ldquo;</div>
          <p style="font-size:2rem;font-family:'Space Grotesk',sans-serif;font-weight:700;color:var(--mu-neon);margin:0 0 1rem;line-height:1;"><?php echo esc_html($pr['score']); ?></p>
          <p style="font-size:.9rem;font-style:italic;color:var(--mu-mid);line-height:1.65;margin:0 0 1.25rem;"><?php echo esc_html($pr['quote']); ?></p>
          <p style="font-family:'Space Grotesk',sans-serif;font-size:.7rem;letter-spacing:.15em;text-transform:uppercase;color:var(--mu-steel);margin:0;"><?php echo esc_html($pr['pub']); ?></p>
        </blockquote>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- MERCH ───────────────────────────────────────────────── -->
  <section class="mu-section" style="background:var(--mu-smoke);" aria-labelledby="mu-merch-title">
    <div class="mu-container">
      <div style="display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:3.5rem;flex-wrap:wrap;gap:1.5rem;">
        <div class="mu-reveal">
          <p class="mu-eyebrow">Store</p>
          <h2 id="mu-merch-title" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(2rem,3vw,2.75rem);font-weight:700;color:#ffffff;letter-spacing:-.03em;margin:0;">Merch</h2>
        </div>
        <a href="<?php echo esc_url(home_url('/shop')); ?>" class="mu-reveal" style="padding:.75rem 1.75rem;background:var(--mu-neon);color:var(--mu-void);font-family:'Space Grotesk',sans-serif;font-size:.75rem;font-weight:600;letter-spacing:.12em;text-transform:uppercase;text-decoration:none;border-radius:2px;">View All</a>
      </div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:1.25rem;">
        <?php foreach($mu_merch as $mi=>$m): ?>
        <article class="mu-merch-card mu-reveal" style="transition-delay:<?php echo $mi*80; ?>ms;">
          <!-- Merch art -->
          <div style="aspect-ratio:1;background:<?php echo esc_attr($m['color']); ?>;display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden;">
            <p aria-hidden="true" style="font-family:'Space Grotesk',sans-serif;font-size:3.5rem;font-weight:700;color:rgba(232,255,0,.06);letter-spacing:-.04em;margin:0;user-select:none;">VHRL</p>
            <?php if($m['badge']): ?>
            <div style="position:absolute;top:.75rem;right:.75rem;background:var(--mu-neon);color:var(--mu-void);font-family:'Space Grotesk',sans-serif;font-size:.55rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;padding:.25rem .5rem;border-radius:2px;"><?php echo esc_html($m['badge']); ?></div>
            <?php endif; ?>
          </div>
          <div style="padding:1rem;">
            <h3 style="font-family:'Space Grotesk',sans-serif;font-size:.9rem;font-weight:500;color:#ffffff;margin:0 0 .35rem;"><?php echo esc_html($m['name']); ?></h3>
            <div style="display:flex;align-items:center;justify-content:space-between;">
              <span style="font-size:.9rem;color:var(--mu-neon);font-family:'Space Grotesk',sans-serif;font-weight:600;">&pound;<?php echo esc_html($m['price']); ?></span>
              <button style="padding:.4rem .9rem;background:rgba(232,255,0,.1);border:1px solid rgba(232,255,0,.2);border-radius:2px;color:var(--mu-neon);font-family:'Space Grotesk',sans-serif;font-size:.65rem;font-weight:600;letter-spacing:.1em;text-transform:uppercase;cursor:pointer;">Add to bag</button>
            </div>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- MAILING LIST ─────────────────────────────────────────── -->
  <section class="mu-section" style="background:linear-gradient(135deg,var(--mu-void) 0%,#0D1022 100%);border-top:1px solid rgba(232,255,0,.08);border-bottom:1px solid rgba(232,255,0,.08);" aria-labelledby="mu-signup-title">
    <div class="mu-container">
      <div class="mu-reveal" style="max-width:600px;margin:0 auto;text-align:center;">
        <p class="mu-eyebrow" style="color:var(--mu-neon);">Transmissions</p>
        <h2 id="mu-signup-title" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(1.75rem,3vw,2.5rem);font-weight:700;color:#ffffff;letter-spacing:-.03em;margin:0 0 1rem;">Stay on frequency</h2>
        <p style="font-size:.95rem;color:var(--mu-steel);line-height:1.7;margin:0 0 2.5rem;">Tour announcements, new music, and signals from the studio. No noise — just signal.</p>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:flex;gap:.75rem;max-width:460px;margin:0 auto 1rem;" novalidate>
          <input type="hidden" name="action" value="tf_mu_signup">
          <?php wp_nonce_field('tf_mu_signup','tf_mu_nonce'); ?>
          <label for="mu-email" class="screen-reader-text"><?php esc_html_e('Your email address','themeflex'); ?></label>
          <input type="email" id="mu-email" name="email" placeholder="your@email.com" required style="flex:1;padding:.9rem 1rem;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:2px;color:#ffffff;font-family:'Inter',sans-serif;font-size:.875rem;outline:none;">
          <button type="submit" style="padding:.9rem 1.5rem;background:var(--mu-neon);color:var(--mu-void);font-family:'Space Grotesk',sans-serif;font-size:.75rem;font-weight:600;letter-spacing:.12em;text-transform:uppercase;border:none;border-radius:2px;cursor:pointer;white-space:nowrap;">Subscribe</button>
        </form>
        <p style="font-size:.75rem;color:var(--mu-steel);">No spam. Unsubscribe anytime. We respect your privacy.</p>
      </div>
    </div>
  </section>

  <!-- FAQ ─────────────────────────────────────────────────── -->
  <section class="mu-section" style="background:var(--mu-void);" aria-labelledby="mu-faq-title">
    <div class="mu-container">
      <div class="mu-reveal" style="text-align:center;margin-bottom:3.5rem;">
        <p class="mu-eyebrow">Questions</p>
        <h2 id="mu-faq-title" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(2rem,3vw,2.5rem);font-weight:700;color:#ffffff;letter-spacing:-.03em;margin:0;">FAQ</h2>
      </div>
      <div style="max-width:720px;margin:0 auto;">
        <?php
        $mu_faqs=[
          ['q'=>'Where can I listen to SIGNALS?','a'=>'SIGNALS is available on Spotify, Apple Music, Tidal, Bandcamp, and all major streaming platforms. Physical vinyl and CD editions are available from the merch store.'],
          ['q'=>'How do I get tickets for upcoming shows?','a'=>'Tickets are available directly from this website and from the venue box offices. Some shows are limited capacity — we recommend booking early to avoid disappointment.'],
          ['q'=>'Do you ship merch internationally?','a'=>'Yes — we ship worldwide from Berlin. Standard shipping takes 5–10 business days. Express options are available at checkout. All orders are tracked.'],
          ['q'=>'Can I license music for film, TV or commercial use?','a'=>'For sync licensing enquiries, please contact the label directly via the booking form below. We\'ll respond within 3–5 business days.'],
          ['q'=>'Is there a fan club or community space?','a'=>'Yes — newsletter subscribers get access to the VHRL Discord server where we share early demos, live recordings, and occasional Q&As.'],
        ];
        foreach($mu_faqs as $fi=>$fq):?>
        <div class="mu-faq mu-reveal" style="transition-delay:<?php echo $fi*60; ?>ms;border-bottom:1px solid rgba(255,255,255,.07);margin:0;">
          <button class="mu-faq__q" aria-expanded="false" style="width:100%;display:flex;align-items:center;justify-content:space-between;padding:1.4rem 0;background:none;border:none;cursor:pointer;text-align:left;gap:1rem;">
            <span style="font-family:'Space Grotesk',sans-serif;font-size:.95rem;font-weight:500;color:#ffffff;"><?php echo esc_html($fq['q']); ?></span>
            <span class="mu-faq__icon" aria-hidden="true" style="font-size:1.2rem;color:var(--mu-neon);flex-shrink:0;transition:transform .3s ease;">+</span>
          </button>
          <div class="mu-faq__a" role="region">
            <div class="mu-faq__a-inner" style="padding:0 0 1.4rem;">
              <p style="font-size:.9rem;color:var(--mu-steel);line-height:1.7;margin:0;"><?php echo esc_html($fq['a']); ?></p>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- BOOKING / CONTACT ───────────────────────────────────── -->
  <section class="mu-section" style="background:var(--mu-smoke);" aria-labelledby="mu-booking-title">
    <div class="mu-container">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:5rem;align-items:start;">
        <div class="mu-reveal">
          <p class="mu-eyebrow">Get in Touch</p>
          <h2 id="mu-booking-title" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(2rem,3vw,3rem);font-weight:700;color:#ffffff;letter-spacing:-.03em;margin:0 0 1.5rem;line-height:1.05;">Booking &amp;<br>Enquiries</h2>
          <p style="font-size:.95rem;color:var(--mu-steel);line-height:1.7;margin:0 0 2.5rem;">For live bookings, sync licensing, press and all other enquiries — use the form or contact the management team directly.</p>
          <div style="display:flex;flex-direction:column;gap:1.25rem;">
            <?php
            $mu_contacts=[
              ['l'=>'General','e'=>'hello@vhrl.com'],
              ['l'=>'Booking &amp; Live','e'=>'booking@vhrl.com'],
              ['l'=>'Press &amp; PR','e'=>'press@vhrl.com'],
              ['l'=>'Sync Licensing','e'=>'sync@vhrl.com'],
            ];
            foreach($mu_contacts as $mc):?>
            <div style="display:flex;align-items:center;gap:1rem;padding:1rem 1.25rem;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:4px;">
              <div style="width:8px;height:8px;border-radius:50%;background:var(--mu-neon);flex-shrink:0;"></div>
              <div>
                <p style="font-family:'Space Grotesk',sans-serif;font-size:.65rem;letter-spacing:.15em;text-transform:uppercase;color:var(--mu-steel);margin:0 0 .2rem;"><?php echo $mc['l']; ?></p>
                <p style="font-size:.875rem;color:var(--mu-mid);margin:0;"><?php echo esc_html($mc['e']); ?></p>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
        <!-- Contact form -->
        <div class="mu-reveal" style="transition-delay:120ms;">
          <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" novalidate style="display:flex;flex-direction:column;gap:1.25rem;">
            <input type="hidden" name="action" value="tf_mu_booking">
            <?php wp_nonce_field('tf_mu_booking','tf_mu_b_nonce'); ?>
            <?php
            $mu_fields=[
              ['id'=>'mu-name','name'=>'name','label'=>'Your Name','type'=>'text','placeholder'=>'Name'],
              ['id'=>'mu-email-b','name'=>'email','label'=>'Email','type'=>'email','placeholder'=>'you@example.com'],
              ['id'=>'mu-org','name'=>'organisation','label'=>'Organisation (optional)','type'=>'text','placeholder'=>'Label / Agency / Publication'],
            ];
            foreach($mu_fields as $mf):?>
            <div>
              <label for="<?php echo esc_attr($mf['id']); ?>" style="display:block;font-family:'Space Grotesk',sans-serif;font-size:.65rem;letter-spacing:.15em;text-transform:uppercase;color:var(--mu-steel);margin-bottom:.5rem;"><?php echo esc_html($mf['label']); ?></label>
              <input type="<?php echo esc_attr($mf['type']); ?>" id="<?php echo esc_attr($mf['id']); ?>" name="<?php echo esc_attr($mf['name']); ?>" placeholder="<?php echo esc_attr($mf['placeholder']); ?>" style="width:100%;padding:.85rem 1rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:2px;color:#ffffff;font-family:'Inter',sans-serif;font-size:.875rem;outline:none;box-sizing:border-box;" required>
            </div>
            <?php endforeach; ?>
            <div>
              <label for="mu-enquiry" style="display:block;font-family:'Space Grotesk',sans-serif;font-size:.65rem;letter-spacing:.15em;text-transform:uppercase;color:var(--mu-steel);margin-bottom:.5rem;">Enquiry Type</label>
              <select id="mu-enquiry" name="enquiry_type" style="width:100%;padding:.85rem 1rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:2px;color:#ffffff;font-family:'Inter',sans-serif;font-size:.875rem;outline:none;appearance:none;">
                <option value="">Select enquiry type</option>
                <option value="booking">Live Booking</option>
                <option value="sync">Sync Licensing</option>
                <option value="press">Press / Interview</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div>
              <label for="mu-msg" style="display:block;font-family:'Space Grotesk',sans-serif;font-size:.65rem;letter-spacing:.15em;text-transform:uppercase;color:var(--mu-steel);margin-bottom:.5rem;">Message</label>
              <textarea id="mu-msg" name="message" rows="5" placeholder="Tell us about your enquiry..." style="width:100%;padding:.85rem 1rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:2px;color:#ffffff;font-family:'Inter',sans-serif;font-size:.875rem;outline:none;resize:vertical;box-sizing:border-box;line-height:1.6;"></textarea>
            </div>
            <button type="submit" style="padding:1rem 2rem;background:var(--mu-neon);color:var(--mu-void);font-family:'Space Grotesk',sans-serif;font-size:.8rem;font-weight:600;letter-spacing:.12em;text-transform:uppercase;border:none;border-radius:2px;cursor:pointer;align-self:flex-start;">Send Enquiry</button>
          </form>
        </div>
      </div>
    </div>
  </section>

</div><!-- /.mu-page -->

<script>
(function(){
  'use strict';
  var obs=new IntersectionObserver(function(entries){
    entries.forEach(function(e){
      if(e.isIntersecting){e.target.classList.add('mu-visible');obs.unobserve(e.target);}
    });
  },{threshold:.1});
  document.querySelectorAll('.mu-reveal').forEach(function(el){obs.observe(el);});

  /* FAQ accordion */
  document.querySelectorAll('.mu-faq__q').forEach(function(btn){
    btn.addEventListener('click',function(){
      var faq=btn.closest('.mu-faq'),
          ans=faq.querySelector('.mu-faq__a'),
          inn=faq.querySelector('.mu-faq__a-inner'),
          ico=faq.querySelector('.mu-faq__icon'),
          open=faq.classList.contains('mu-open');
      document.querySelectorAll('.mu-faq.mu-open').forEach(function(f){
        f.querySelector('.mu-faq__a').style.maxHeight='0';
        f.classList.remove('mu-open');
        f.querySelector('.mu-faq__q').setAttribute('aria-expanded','false');
        var i=f.querySelector('.mu-faq__icon');if(i)i.textContent='+';
      });
      if(!open){
        ans.style.maxHeight=inn.scrollHeight+'px';
        faq.classList.add('mu-open');
        btn.setAttribute('aria-expanded','true');
        if(ico)ico.textContent='×';
      }
    });
  });

  /* Waveform hover animation */
  var bars=document.querySelectorAll('[data-mu-bar]');
  if(bars.length){
    setInterval(function(){
      bars.forEach(function(b){
        var h=Math.round(8+Math.random()*92);
        b.style.height=h+'%';
      });
    },800);
  }
})();
</script>


<?php
/* ─────────────────────────────────────────────────────────────
   BIOGRAPHY SECTION
   ───────────────────────────────────────────────────────────── */
$mu_timeline = [
  ['year'=>'2019','event'=>'First release — "Carrier Wave" EP uploaded to Bandcamp from a Berlin bedroom. 12,000 downloads in the first month.'],
  ['year'=>'2020','event'=>'Signed to independent Berlin label FREQ Records. Began collaboration with producer SKHM in Oslo.'],
  ['year'=>'2021','event'=>'Performed at Unsound Festival, Krakow. First major international booking.'],
  ['year'=>'2022','event'=>'Debut Boiler Room set broadcast globally — 2.3M views in 30 days. Pitchfork feature.'],
  ['year'=>'2023','event'=>'"Static" EP released. BBC Radio 6 Music "Album of the Day". European tour — 14 dates, 9 countries.'],
  ['year'=>'2024','event'=>'"Fault Lines" full-length. Collaboration with Nils Frahm on "Meridian." FACT Magazine Artist of the Year.'],
  ['year'=>'2025','event'=>'"Drift EP" — recorded over one winter in a Norwegian fjord. Sold 4,000 vinyl copies in 48 hours.'],
  ['year'=>'2026','event'=>'"SIGNALS" — debut album. 12 tracks, 2 years in production. Out now on all platforms.'],
];
?>
<!-- BIOGRAPHY ────────────────────────────────────────────── -->
<section class="mu-section" style="background:var(--mu-void);border-top:1px solid rgba(255,255,255,.05);" aria-labelledby="mu-bio-title">
  <div class="mu-container">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:6rem;align-items:start;">
      <div class="mu-reveal">
        <p class="mu-eyebrow">Artist</p>
        <h2 id="mu-bio-title" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(2rem,3vw,3rem);font-weight:700;color:#ffffff;letter-spacing:-.03em;margin:0 0 1.75rem;line-height:1.05;">About VHRL</h2>
        <div style="display:flex;flex-direction:column;gap:1rem;">
          <p style="font-size:.975rem;color:var(--mu-mid);line-height:1.8;margin:0;">VHRL (pronounced "veer-el") is the project of Berlin-based electronic composer and producer Viktor Harlan. Born in Tallinn, Estonia, and trained as a sound engineer at SAE Berlin, he began releasing music in 2019 after a decade working in post-production for film and documentary.</p>
          <p style="font-size:.975rem;color:var(--mu-steel);line-height:1.8;margin:0;">His music occupies the territory between industrial electronics, ambient composition, and club-oriented bass music — drawing as much from field recording and spectralist composition as from the Berlin underground.</p>
          <p style="font-size:.975rem;color:var(--mu-steel);line-height:1.8;margin:0;">He performs and records alone, using a custom modular synthesizer rig and heavily processed acoustic instruments. No laptops on stage — only hardware, cables, and controlled accident.</p>
        </div>
        <div style="display:flex;gap:2rem;margin-top:2.5rem;padding-top:2rem;border-top:1px solid rgba(255,255,255,.07);">
          <?php
          $mu_stats=[['n'=>'7 years','l'=>'Active'],['n'=>'4','l'=>'Releases'],['n'=>'62','l'=>'Live Shows'],['n'=>'1.2M','l'=>'Monthly listeners']];
          foreach($mu_stats as $ms):?>
          <div>
            <p style="font-family:'Space Grotesk',sans-serif;font-size:1.5rem;font-weight:700;color:var(--mu-neon);margin:0 0 .2rem;line-height:1;"><?php echo esc_html($ms['n']); ?></p>
            <p style="font-size:.7rem;color:var(--mu-steel);letter-spacing:.12em;text-transform:uppercase;font-family:'Space Grotesk',sans-serif;margin:0;"><?php echo esc_html($ms['l']); ?></p>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <!-- Timeline -->
      <div class="mu-reveal" style="transition-delay:120ms;">
        <p style="font-family:'Space Grotesk',sans-serif;font-size:.68rem;letter-spacing:.28em;text-transform:uppercase;color:var(--mu-steel);margin-bottom:2rem;">Timeline</p>
        <div style="position:relative;padding-left:2rem;">
          <!-- Vertical line -->
          <div aria-hidden="true" style="position:absolute;left:5px;top:0;bottom:0;width:1px;background:linear-gradient(180deg,var(--mu-neon) 0%,rgba(232,255,0,.1) 100%);"></div>
          <?php foreach($mu_timeline as $tli=>$tl): ?>
          <div style="position:relative;margin-bottom:2rem;<?php echo $tli===count($mu_timeline)-1?'margin-bottom:0;':''; ?>">
            <!-- Dot -->
            <div aria-hidden="true" style="position:absolute;left:-2rem;top:4px;width:10px;height:10px;border-radius:50%;background:<?php echo $tli===count($mu_timeline)-1?'var(--mu-neon)':'rgba(232,255,0,.25)'; ?>;border:2px solid <?php echo $tli===count($mu_timeline)-1?'var(--mu-neon)':'rgba(232,255,0,.15)'; ?>;box-shadow:<?php echo $tli===count($mu_timeline)-1?'0 0 12px var(--mu-neon)':'none'; ?>;"></div>
            <p style="font-family:'Space Grotesk',sans-serif;font-size:.75rem;font-weight:600;color:var(--mu-neon);margin:0 0 .3rem;letter-spacing:.05em;"><?php echo esc_html($tl['year']); ?></p>
            <p style="font-size:.85rem;color:var(--mu-steel);line-height:1.6;margin:0;"><?php echo esc_html($tl['event']); ?></p>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<?php
/* ─────────────────────────────────────────────────────────────
   LIVE PERFORMANCES / VIDEO SECTION
   ───────────────────────────────────────────────────────────── */
$mu_videos = [
  ['title'=>'Boiler Room Berlin 2022','duration'=>'1h 12m','views'=>'2.3M','tag'=>'Live Set','color'=>'#0D1022'],
  ['title'=>'Unsound Festival, Krakow 2021','duration'=>'48m','views'=>'840K','tag'=>'Festival','color'=>'#120A1A'],
  ['title'=>'"Carrier Wave" Official Video','duration'=>'4:12','views'=>'1.1M','tag'=>'Music Video','color'=>'#0A1208'],
  ['title'=>'NTS Radio Session','duration'=>'2h 00m','views'=>'512K','tag'=>'Radio','color'=>'#1A0D0A'],
];
?>
<!-- LIVE VIDEO ───────────────────────────────────────────── -->
<section class="mu-section" style="background:var(--mu-smoke);" aria-labelledby="mu-video-title">
  <div class="mu-container">
    <div class="mu-reveal" style="margin-bottom:3.5rem;">
      <p class="mu-eyebrow">Watch</p>
      <h2 id="mu-video-title" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(2rem,3vw,2.75rem);font-weight:700;color:#ffffff;letter-spacing:-.03em;margin:0;">Live &amp; Video</h2>
    </div>
    <div style="display:grid;grid-template-columns:2fr 1fr 1fr;grid-template-rows:auto auto;gap:1rem;">
      <?php foreach($mu_videos as $vi=>$v):
        $span = $vi===0?'grid-row:span 2;':'';
        $ht   = $vi===0?'100%':'140px';
      ?>
      <div class="mu-reveal" style="transition-delay:<?php echo $vi*80; ?>ms;background:<?php echo esc_attr($v['color']); ?>;border-radius:4px;overflow:hidden;<?php echo $span; ?>position:relative;<?php echo $vi===0?'min-height:320px;':'height:'.$ht.';'; ?>cursor:pointer;border:1px solid rgba(255,255,255,.05);display:flex;flex-direction:column;justify-content:flex-end;padding:1.5rem;">
        <!-- Play button -->
        <div aria-hidden="true" style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:<?php echo $vi===0?'64px':'44px'; ?>;height:<?php echo $vi===0?'64px':'44px'; ?>;border-radius:50%;background:rgba(232,255,0,.15);border:1px solid rgba(232,255,0,.3);display:flex;align-items:center;justify-content:center;color:var(--mu-neon);font-size:<?php echo $vi===0?'1.4rem':'1rem'; ?>;">&#9654;</div>
        <!-- Gradient overlay -->
        <div style="position:absolute;inset:0;background:linear-gradient(0deg,rgba(0,0,0,.7) 0%,transparent 60%);pointer-events:none;"></div>
        <!-- Large waveform bg art -->
        <div aria-hidden="true" style="position:absolute;top:50%;left:0;right:0;transform:translateY(-50%);display:flex;align-items:center;gap:1px;height:40%;opacity:.08;overflow:hidden;">
          <?php for($wb=0;$wb<40;$wb++) echo '<div style="flex:1;height:'.rand(20,100).'%;background:var(--mu-neon);border-radius:1px;min-width:0;"></div>'; ?>
        </div>
        <!-- Tag -->
        <div style="position:relative;z-index:1;display:flex;flex-direction:column;gap:.4rem;">
          <div style="display:inline-block;background:rgba(232,255,0,.15);border:1px solid rgba(232,255,0,.2);border-radius:2px;padding:.2rem .5rem;font-family:'Space Grotesk',sans-serif;font-size:.55rem;letter-spacing:.12em;text-transform:uppercase;color:var(--mu-neon);width:fit-content;"><?php echo esc_html($v['tag']); ?></div>
          <h3 style="font-family:'Space Grotesk',sans-serif;font-size:<?php echo $vi===0?'1.1rem':'.85rem'; ?>;font-weight:500;color:#ffffff;margin:0;"><?php echo esc_html($v['title']); ?></h3>
          <div style="display:flex;gap:1rem;">
            <span style="font-size:.7rem;color:var(--mu-steel);"><?php echo esc_html($v['duration']); ?></span>
            <span style="font-size:.7rem;color:var(--mu-steel);"><?php echo esc_html($v['views']); ?> views</span>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php
/* ─────────────────────────────────────────────────────────────
   AWARDS & RECOGNITION
   ───────────────────────────────────────────────────────────── */
$mu_awards = [
  ['award'=>'FACT Magazine','title'=>'Artist of the Year 2024','cat'=>'Editorial'],
  ['award'=>'Electronic Beats','title'=>'Best Live Act 2023','cat'=>'Live Music'],
  ['award'=>'BBC Radio 6','title'=>'Album of the Day — Static EP','cat'=>'Radio'],
  ['award'=>'Pitchfork','title'=>'Best New Music — Fault Lines','cat'=>'Critical'],
  ['award'=>'Resident Advisor','title'=>'Top 10 Labels: FREQ Records 2025','cat'=>'Industry'],
  ['award'=>'NME','title'=>'One to Watch 2022','cat'=>'Editorial'],
];
?>
<!-- AWARDS ──────────────────────────────────────────────── -->
<section class="mu-section" style="background:var(--mu-void);border-top:1px solid rgba(255,255,255,.05);" aria-labelledby="mu-awards-title">
  <div class="mu-container">
    <div class="mu-reveal" style="text-align:center;margin-bottom:3.5rem;">
      <p class="mu-eyebrow">Recognition</p>
      <h2 id="mu-awards-title" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(2rem,3vw,2.5rem);font-weight:700;color:#ffffff;letter-spacing:-.03em;margin:0;">Awards &amp; Press</h2>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:1px;background:rgba(255,255,255,.06);">
      <?php foreach($mu_awards as $awi=>$aw): ?>
      <div class="mu-reveal" style="transition-delay:<?php echo $awi*70; ?>ms;background:var(--mu-void);padding:2rem;position:relative;overflow:hidden;">
        <div aria-hidden="true" style="position:absolute;top:.75rem;right:1rem;font-family:'Space Grotesk',sans-serif;font-size:3rem;font-weight:700;color:rgba(232,255,0,.03);line-height:1;"><?php echo str_pad($awi+1,2,'0',STR_PAD_LEFT); ?></div>
        <p style="font-family:'Space Grotesk',sans-serif;font-size:.6rem;letter-spacing:.18em;text-transform:uppercase;color:var(--mu-neon);margin:0 0 .6rem;"><?php echo esc_html($aw['cat']); ?></p>
        <h3 style="font-family:'Space Grotesk',sans-serif;font-size:.95rem;font-weight:500;color:#ffffff;margin:0 0 .35rem;line-height:1.4;"><?php echo esc_html($aw['title']); ?></h3>
        <p style="font-size:.8rem;color:var(--mu-steel);margin:0;"><?php echo esc_html($aw['award']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php get_footer(); ?>
