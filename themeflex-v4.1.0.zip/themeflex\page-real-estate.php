<?php
/**
 * Template Name: Premium Real Estate Agency Homepage
 * Template Post Type: page
 *
 * ThemeFlex – Starter Flavor: Luxury Property
 * Namespace : --re-*
 * Fonts     : Cormorant (display) + Karla (body)
 * Palette   : Slate #1C2B3A / Gold #C6A84B / Ivory #FAF9F6 / Stone #8B8C8D / Mist #EEF0F2
 */
defined('ABSPATH') || exit;
get_header();

/* ── Palette ─────────────────────────────────────────────── */
$re_slate  = '#1C2B3A';
$re_gold   = '#C6A84B';
$re_ivory  = '#FAF9F6';
$re_stone  = '#8B8C8D';
$re_mist   = '#EEF0F2';
$re_dark   = '#111820';
$re_mid    = '#4A5568';

/* ── Deterministic randomness ─────────────────────────────── */
srand(crc32('re-agency-2026'));

/* ── Featured Properties ────────────────────────────────── */
$re_props = [
  ['name'=>'Pemberton House','type'=>'Detached Townhouse','beds'=>5,'baths'=>4,'area'=>3800,'price'=>'£4,250,000','location'=>'Notting Hill, London W11','tag'=>'Exclusive','color'=>'#1E2C3A','accent'=>'#C6A84B'],
  ['name'=>'The Observatory','type'=>'Penthouse','beds'=>4,'baths'=>3,'area'=>2900,'price'=>'£6,800,000','location'=>'Primrose Hill, London NW3','tag'=>'New','color'=>'#1A2233','accent'=>'#D4AA55'],
  ['name'=>'Birch Manor','type'=>'Victorian Villa','beds'=>6,'baths'=>5,'area'=>4600,'price'=>'£3,900,000','location'=>'Hampstead, London NW3','tag'=>'Reduced','color'=>'#1F2A20','accent'=>'#A8C6A4'],
  ['name'=>'The Glass Atelier','type'=>'Contemporary Loft','beds'=>3,'baths'=>2,'area'=>2100,'price'=>'£2,100,000','location'=>'Shoreditch, London EC2','tag'=>'Under Offer','color'=>'#261F1A','accent'=>'#C6A84B'],
  ['name'=>'Holland Park Mews','type'=>'Mews House','beds'=>4,'baths'=>3,'area'=>2400,'price'=>'£3,200,000','location'=>'Holland Park, London W14','tag'=>'Exclusive','color'=>'#1C2430','accent'=>'#C6A84B'],
  ['name'=>'Heron Wharf','type'=>'Riverside Apartment','beds'=>2,'baths'=>2,'area'=>1500,'price'=>'£1,650,000','location'=>'Strand, London WC2','tag'=>'New','color'=>'#1A2228','accent'=>'#9BBCC6'],
];

/* ── Agents ──────────────────────────────────────────────── */
$re_agents = [
  ['name'=>'Charlotte Holt','role'=>'Senior Partner','phone'=>'+44 20 7123 4001','sales'=>'£42M','props'=>14,'skin'=>'#C8956A','hair'=>'#2C1A0A'],
  ['name'=>'James Whitmore','role'=>'Associate Director','phone'=>'+44 20 7123 4002','sales'=>'£28M','props'=>9,'skin'=>'#B87A5A','hair'=>'#1A1010'],
  ['name'=>'Priya Mehra','role'=>'Residential Sales','phone'=>'+44 20 7123 4003','sales'=>'£19M','props'=>7,'skin'=>'#C49A72','hair'=>'#0A0404'],
  ['name'=>'Oliver Ashby','role'=>'Head of Lettings','phone'=>'+44 20 7123 4004','sales'=>'£35M','props'=>12,'skin'=>'#D4A882','hair'=>'#3A2010'],
];

/* ── Neighbourhoods ──────────────────────────────────────── */
$re_hoods = [
  ['name'=>'Notting Hill','avg'=>'£5.2M','trend'=>'+8.4%','type'=>'Prime Residential','color'=>'#1E2C3A'],
  ['name'=>'Hampstead','avg'=>'£4.1M','trend'=>'+5.2%','type'=>'Village & Garden','color'=>'#1F2A20'],
  ['name'=>'Mayfair','avg'=>'£9.8M','trend'=>'+12.1%','type'=>'Ultra-Prime Central','color'=>'#26201A'],
  ['name'=>'Shoreditch','avg'=>'£1.8M','trend'=>'+6.7%','type'=>'Urban Creative','color'=>'#1A1E26'],
];

/* ── Market Stats ────────────────────────────────────────── */
$re_stats = [
  ['n'=>'£4.6M','l'=>'Average sale price'],
  ['n'=>'24 days','l'=>'Average time to sale'],
  ['n'=>'98.3%','l'=>'Asking price achieved'],
  ['n'=>'340+','l'=>'Transactions in 2025'],
];
?>
<!-- GLOBAL CSS ──────────────────────────────────────────── -->
<style>
@import url('https://fonts.googleapis.com/css2?family=Cormorant:ital,wght@0,300;0,400;0,600;0,700;1,300;1,400&family=Karla:wght@300;400;500;600&display=swap');
:root{
  --re-slate:<?php echo $re_slate; ?>;
  --re-gold:<?php echo $re_gold; ?>;
  --re-ivory:<?php echo $re_ivory; ?>;
  --re-stone:<?php echo $re_stone; ?>;
  --re-mist:<?php echo $re_mist; ?>;
}
.re-page{font-family:'Karla',system-ui,sans-serif;background:var(--re-ivory);color:var(--re-slate);line-height:1.6;margin:0;}
.re-container{max-width:1220px;margin:0 auto;padding:0 2rem;}
.re-section{padding:6rem 0;}
.re-reveal{opacity:0;transform:translateY(24px);transition:opacity .65s ease,transform .65s ease;}
.re-reveal.re-visible{opacity:1;transform:none;}
.re-eyebrow{font-family:'Karla',sans-serif;font-size:.68rem;letter-spacing:.28em;text-transform:uppercase;color:var(--re-gold);margin-bottom:.75rem;}
/* Property card */
.re-prop{background:#fff;border-radius:3px;overflow:hidden;box-shadow:0 2px 20px rgba(28,43,58,.07);transition:box-shadow .3s ease,transform .3s ease;}
.re-prop:hover{box-shadow:0 12px 50px rgba(28,43,58,.14);transform:translateY(-3px);}
/* Gold rule */
.re-rule{display:block;width:40px;height:2px;background:var(--re-gold);margin-bottom:1.5rem;}
/* Input */
.re-input{width:100%;padding:.85rem 1rem;border:1px solid #d1d5db;border-radius:2px;font-family:'Karla',sans-serif;font-size:.875rem;color:var(--re-slate);outline:none;box-sizing:border-box;background:#fff;}
.re-input:focus{border-color:var(--re-gold);}
</style>

<div class="re-page">

  <!-- HERO ─────────────────────────────────────────────────── -->
  <section style="min-height:100vh;position:relative;display:flex;flex-direction:column;justify-content:flex-end;overflow:hidden;background:var(--re-slate);" aria-labelledby="re-hero-title">

    <!-- Sky gradient -->
    <div aria-hidden="true" style="position:absolute;inset:0;background:linear-gradient(180deg,#0F1C28 0%,#1C2B3A 55%,#243344 100%);"></div>

    <!-- Stars -->
    <div aria-hidden="true" style="position:absolute;inset:0;overflow:hidden;">
      <?php for($s=0;$s<60;$s++){
        $sx=rand(0,100); $sy=rand(0,60); $ss=rand(1,3); $so=rand(20,80)/100;
        echo "<div style='position:absolute;left:{$sx}%;top:{$sy}%;width:{$ss}px;height:{$ss}px;border-radius:50%;background:#ffffff;opacity:{$so};'></div>";
      } ?>
    </div>

    <!-- CSS Property Exterior Scene ─────────────────────── -->
    <div aria-hidden="true" style="position:absolute;bottom:0;left:0;right:0;height:70%;display:flex;align-items:flex-end;justify-content:center;overflow:hidden;">

      <!-- Ground / grass -->
      <div style="position:absolute;bottom:0;left:0;right:0;height:15%;background:linear-gradient(0deg,#162212 0%,#1E2A18 100%);"></div>
      <!-- Path -->
      <div style="position:absolute;bottom:0;left:calc(50% - 40px);width:80px;height:18%;background:linear-gradient(0deg,#8B7355 0%,#9E8A6A 80%,transparent 100%);"></div>

      <!-- Main House Body -->
      <div style="position:absolute;bottom:15%;left:calc(50% - 160px);width:320px;height:200px;background:linear-gradient(180deg,#F5F0E8 0%,#EDE5D4 100%);"></div>
      <!-- Roof -->
      <div style="position:absolute;bottom:calc(15% + 200px);left:calc(50% - 185px);width:0;height:0;border-left:185px solid transparent;border-right:185px solid transparent;border-bottom:100px solid #2A2218;"></div>
      <!-- Chimney -->
      <div style="position:absolute;bottom:calc(15% + 270px);left:calc(50% + 50px);width:30px;height:60px;background:#2A2218;"></div>
      <!-- Chimney top -->
      <div style="position:absolute;bottom:calc(15% + 326px);left:calc(50% + 44px);width:42px;height:8px;background:#3A2E22;"></div>
      <!-- Front door -->
      <div style="position:absolute;bottom:15%;left:calc(50% - 22px);width:44px;height:80px;background:#1C2B3A;border-radius:4px 4px 0 0;"></div>
      <!-- Door knocker -->
      <div style="position:absolute;bottom:calc(15% + 36px);left:calc(50% - 5px);width:10px;height:10px;border-radius:50%;background:#C6A84B;"></div>
      <!-- Windows row 1 -->
      <?php for($w=0;$w<4;$w++){ $wx = -140 + $w*90; if(abs($wx)<30) continue; ?>
      <div style="position:absolute;bottom:calc(15% + 70px);left:calc(50% + <?php echo $wx-18; ?>px);width:36px;height:45px;background:#1A2E44;border-radius:2px;border:3px solid #D4C8B0;">
        <div style="position:absolute;top:50%;left:0;right:0;height:1px;background:rgba(255,255,255,.1);"></div>
        <div style="position:absolute;left:50%;top:0;bottom:0;width:1px;background:rgba(255,255,255,.1);"></div>
        <div style="position:absolute;inset:0;background:linear-gradient(135deg,rgba(255,220,100,.08),transparent);"></div>
      </div>
      <?php } ?>
      <!-- Windows row 2 (upper) -->
      <?php for($w=0;$w<3;$w++){ $wx = -90 + $w*90; ?>
      <div style="position:absolute;bottom:calc(15% + 130px);left:calc(50% + <?php echo $wx-18; ?>px);width:36px;height:45px;background:#1A2E44;border-radius:2px;border:3px solid #D4C8B0;">
        <div style="position:absolute;top:50%;left:0;right:0;height:1px;background:rgba(255,255,255,.1);"></div>
        <div style="position:absolute;left:50%;top:0;bottom:0;width:1px;background:rgba(255,255,255,.1);"></div>
      </div>
      <?php } ?>
      <!-- Side wings -->
      <div style="position:absolute;bottom:15%;left:calc(50% - 280px);width:120px;height:140px;background:linear-gradient(180deg,#EDE5D4 0%,#E0D8C8 100%);"></div>
      <div style="position:absolute;bottom:15%;right:calc(50% - 280px);width:120px;height:140px;background:linear-gradient(180deg,#EDE5D4 0%,#E0D8C8 100%);"></div>
      <!-- Wing roofs -->
      <div style="position:absolute;bottom:calc(15% + 140px);left:calc(50% - 282px);width:0;height:0;border-left:62px solid transparent;border-right:62px solid transparent;border-bottom:50px solid #2A2218;"></div>
      <div style="position:absolute;bottom:calc(15% + 140px);right:calc(50% - 282px);width:0;height:0;border-left:62px solid transparent;border-right:62px solid transparent;border-bottom:50px solid #2A2218;"></div>
      <!-- Trees -->
      <?php for($t=0;$t<4;$t++){ $tx = ($t<2)?(-360-$t*60):(360+($t-2)*60); $th = 100+rand(0,40); ?>
      <div style="position:absolute;bottom:15%;left:calc(50% + <?php echo $tx; ?>px);">
        <div style="width:28px;height:<?php echo $th; ?>px;background:#1E2A18;margin:0 auto 0;"></div>
        <div style="position:absolute;bottom:<?php echo $th; ?>px;left:50%;transform:translateX(-50%);width:0;height:0;border-left:40px solid transparent;border-right:40px solid transparent;border-bottom:<?php echo 60+rand(0,20); ?>px solid #1A3018;"></div>
      </div>
      <?php } ?>
      <!-- Lamppost -->
      <div style="position:absolute;bottom:15%;left:calc(50% + 120px);">
        <div style="width:4px;height:90px;background:#2A2A2A;margin:0 auto;"></div>
        <div style="position:absolute;top:0;left:50%;transform:translateX(-50%) translateY(-10px);width:16px;height:16px;border-radius:50%;background:#C6A84B;box-shadow:0 0 20px rgba(198,168,75,.8),0 0 50px rgba(198,168,75,.3);"></div>
      </div>

    </div><!-- /stage -->

    <!-- Gold ornamental line -->
    <div aria-hidden="true" style="position:absolute;top:40%;left:50%;transform:translateX(-50%);width:120px;height:1px;background:linear-gradient(90deg,transparent,var(--re-gold),transparent);"></div>

    <!-- Hero content -->
    <div class="re-container" style="position:relative;z-index:2;padding-bottom:5rem;">
      <div style="max-width:680px;">
        <p class="re-eyebrow" style="color:rgba(198,168,75,.8);">London's Premier Property Agency</p>
        <h1 id="re-hero-title" style="font-family:'Cormorant',Georgia,serif;font-size:clamp(3rem,7vw,6.5rem);font-weight:300;color:#FAF9F6;line-height:.95;letter-spacing:-.02em;margin:0 0 1.5rem;">Homes of<br><em style="font-style:italic;color:var(--re-gold);">distinction.</em></h1>
        <p style="font-size:1rem;color:rgba(234,238,242,.65);max-width:460px;line-height:1.75;margin:0 0 2.5rem;">Meridian Estate have guided London's most discerning buyers, sellers, and investors since 1989. Discreet, considered, exceptional.</p>
        <div style="display:flex;gap:1rem;flex-wrap:wrap;">
          <a href="<?php echo esc_url(home_url('/properties/for-sale')); ?>" style="display:inline-block;padding:.95rem 2.25rem;background:var(--re-gold);color:#ffffff;font-family:'Karla',sans-serif;font-size:.78rem;font-weight:600;letter-spacing:.14em;text-transform:uppercase;text-decoration:none;border-radius:2px;">View Properties</a>
          <a href="<?php echo esc_url(home_url('/valuation')); ?>" style="display:inline-block;padding:.95rem 2.25rem;border:1px solid rgba(198,168,75,.4);color:rgba(234,238,242,.8);font-family:'Karla',sans-serif;font-size:.78rem;letter-spacing:.14em;text-transform:uppercase;text-decoration:none;border-radius:2px;">Book Valuation</a>
        </div>
      </div>
    </div>

    <!-- Scroll indicator -->
    <div aria-hidden="true" style="position:absolute;bottom:2rem;right:3rem;display:flex;flex-direction:column;align-items:center;gap:.5rem;opacity:.4;">
      <span style="font-family:'Karla',sans-serif;font-size:.6rem;letter-spacing:.2em;text-transform:uppercase;color:#ffffff;writing-mode:vertical-rl;">Scroll</span>
      <div style="width:1px;height:40px;background:linear-gradient(180deg,#ffffff,transparent);"></div>
    </div>
  </section>

  <!-- PROPERTY SEARCH ────────────────────────────────────── -->
  <section style="background:#ffffff;padding:2.5rem 0;border-bottom:1px solid #e8eaec;" aria-label="Property search">
    <div class="re-container">
      <form method="get" action="<?php echo esc_url(home_url('/properties')); ?>" style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr auto;gap:1rem;align-items:end;">
        <div>
          <label for="re-location" style="display:block;font-family:'Karla',sans-serif;font-size:.65rem;letter-spacing:.18em;text-transform:uppercase;color:var(--re-stone);margin-bottom:.5rem;">Location</label>
          <input class="re-input" type="text" id="re-location" name="location" placeholder="Area, postcode or street">
        </div>
        <div>
          <label for="re-type" style="display:block;font-family:'Karla',sans-serif;font-size:.65rem;letter-spacing:.18em;text-transform:uppercase;color:var(--re-stone);margin-bottom:.5rem;">Property Type</label>
          <select class="re-input" id="re-type" name="type">
            <option value="">All types</option>
            <option value="house">House</option>
            <option value="flat">Flat</option>
            <option value="townhouse">Townhouse</option>
            <option value="penthouse">Penthouse</option>
            <option value="mews">Mews</option>
          </select>
        </div>
        <div>
          <label for="re-budget" style="display:block;font-family:'Karla',sans-serif;font-size:.65rem;letter-spacing:.18em;text-transform:uppercase;color:var(--re-stone);margin-bottom:.5rem;">Max Budget</label>
          <select class="re-input" id="re-budget" name="max_price">
            <option value="">No maximum</option>
            <option value="1000000">£1,000,000</option>
            <option value="2000000">£2,000,000</option>
            <option value="3000000">£3,000,000</option>
            <option value="5000000">£5,000,000</option>
            <option value="10000000">£10,000,000+</option>
          </select>
        </div>
        <div>
          <label for="re-beds" style="display:block;font-family:'Karla',sans-serif;font-size:.65rem;letter-spacing:.18em;text-transform:uppercase;color:var(--re-stone);margin-bottom:.5rem;">Bedrooms</label>
          <select class="re-input" id="re-beds" name="bedrooms">
            <option value="">Any</option>
            <option value="1">1+</option>
            <option value="2">2+</option>
            <option value="3">3+</option>
            <option value="4">4+</option>
            <option value="5">5+</option>
          </select>
        </div>
        <button type="submit" style="padding:.85rem 2rem;background:var(--re-slate);color:#ffffff;font-family:'Karla',sans-serif;font-size:.78rem;font-weight:500;letter-spacing:.12em;text-transform:uppercase;border:none;border-radius:2px;cursor:pointer;white-space:nowrap;">Search</button>
      </form>
    </div>
  </section>

  <!-- FEATURED PROPERTIES ────────────────────────────────── -->
  <section class="re-section" style="background:var(--re-ivory);" aria-labelledby="re-props-title">
    <div class="re-container">
      <div style="display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:3.5rem;flex-wrap:wrap;gap:1.5rem;">
        <div class="re-reveal">
          <span class="re-rule" aria-hidden="true"></span>
          <p class="re-eyebrow">Portfolio</p>
          <h2 id="re-props-title" style="font-family:'Cormorant',Georgia,serif;font-size:clamp(2.5rem,4vw,3.75rem);font-weight:400;color:var(--re-slate);margin:0;line-height:1.1;">Featured Properties</h2>
        </div>
        <a href="<?php echo esc_url(home_url('/properties')); ?>" class="re-reveal" style="padding:.75rem 1.75rem;border:1px solid var(--re-slate);color:var(--re-slate);font-family:'Karla',sans-serif;font-size:.75rem;letter-spacing:.14em;text-transform:uppercase;text-decoration:none;border-radius:2px;">View All</a>
      </div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:1.5rem;">
        <?php foreach($re_props as $pi=>$prop):
          $delay = $pi * 80;
        ?>
        <article class="re-prop re-reveal" style="transition-delay:<?php echo $delay; ?>ms;">
          <!-- Property art / CSS facade -->
          <div style="aspect-ratio:4/3;background:<?php echo esc_attr($prop['color']); ?>;position:relative;overflow:hidden;">
            <!-- Building silhouette lines -->
            <div style="position:absolute;inset:0;background:repeating-linear-gradient(90deg,transparent,transparent 19px,rgba(255,255,255,.02) 19px,rgba(255,255,255,.02) 20px),repeating-linear-gradient(0deg,transparent,transparent 19px,rgba(255,255,255,.02) 19px,rgba(255,255,255,.02) 20px);"></div>
            <!-- Ground level light -->
            <div style="position:absolute;bottom:0;left:0;right:0;height:30%;background:linear-gradient(0deg,rgba(<?php echo implode(',',sscanf($prop['accent'],'#%02x%02x%02x')); ?>,.06) 0%,transparent 100%);"></div>
            <!-- Property name -->
            <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;">
              <p aria-hidden="true" style="font-family:'Cormorant',Georgia,serif;font-size:2rem;font-weight:300;color:rgba(255,255,255,.08);text-align:center;letter-spacing:-.01em;padding:0 1rem;"><?php echo esc_html($prop['name']); ?></p>
            </div>
            <!-- Gold accent line -->
            <div style="position:absolute;bottom:2rem;left:1.5rem;right:1.5rem;height:1px;background:linear-gradient(90deg,transparent,<?php echo esc_attr($prop['accent']); ?>,transparent);opacity:.5;"></div>
            <!-- Tag -->
            <div style="position:absolute;top:1rem;left:1rem;background:<?php
              echo $prop['tag']==='Exclusive'?'var(--re-slate)':($prop['tag']==='Reduced'?'#6B2222':($prop['tag']==='Under Offer'?'#1A3A1A':'rgba(255,255,255,.15)'));
            ?>;color:#ffffff;font-family:'Karla',sans-serif;font-size:.58rem;font-weight:500;letter-spacing:.14em;text-transform:uppercase;padding:.25rem .65rem;border-radius:2px;"><?php echo esc_html($prop['tag']); ?></div>
          </div>
          <div style="padding:1.5rem;">
            <p style="font-family:'Karla',sans-serif;font-size:.65rem;letter-spacing:.18em;text-transform:uppercase;color:var(--re-gold);margin:0 0 .35rem;"><?php echo esc_html($prop['type']); ?></p>
            <h3 style="font-family:'Cormorant',Georgia,serif;font-size:1.5rem;font-weight:400;color:var(--re-slate);margin:0 0 .35rem;"><?php echo esc_html($prop['name']); ?></h3>
            <p style="font-family:'Karla',sans-serif;font-size:.8rem;color:var(--re-stone);margin:0 0 1rem;display:flex;align-items:center;gap:.4rem;"><span aria-hidden="true">&#9679;</span><?php echo esc_html($prop['location']); ?></p>
            <div style="display:flex;gap:1.5rem;margin-bottom:1.25rem;padding-top:1rem;border-top:1px solid #f0f0f0;">
              <div style="text-align:center;"><p style="font-family:'Cormorant',Georgia,serif;font-size:1.25rem;font-weight:400;color:var(--re-slate);margin:0;"><?php echo esc_html($prop['beds']); ?></p><p style="font-size:.62rem;letter-spacing:.14em;text-transform:uppercase;color:var(--re-stone);margin:0;">Beds</p></div>
              <div style="text-align:center;"><p style="font-family:'Cormorant',Georgia,serif;font-size:1.25rem;font-weight:400;color:var(--re-slate);margin:0;"><?php echo esc_html($prop['baths']); ?></p><p style="font-size:.62rem;letter-spacing:.14em;text-transform:uppercase;color:var(--re-stone);margin:0;">Baths</p></div>
              <div style="text-align:center;"><p style="font-family:'Cormorant',Georgia,serif;font-size:1.25rem;font-weight:400;color:var(--re-slate);margin:0;"><?php echo number_format($prop['area']); ?></p><p style="font-size:.62rem;letter-spacing:.14em;text-transform:uppercase;color:var(--re-stone);margin:0;">sq ft</p></div>
            </div>
            <div style="display:flex;align-items:center;justify-content:space-between;">
              <p style="font-family:'Cormorant',Georgia,serif;font-size:1.5rem;font-weight:600;color:var(--re-slate);margin:0;"><?php echo esc_html($prop['price']); ?></p>
              <a href="<?php echo esc_url(home_url('/properties/'.sanitize_title($prop['name']))); ?>" style="font-family:'Karla',sans-serif;font-size:.7rem;letter-spacing:.12em;text-transform:uppercase;color:var(--re-gold);text-decoration:none;border-bottom:1px solid rgba(198,168,75,.3);padding-bottom:1px;">Details &#8594;</a>
            </div>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- MARKET STATS ────────────────────────────────────────── -->
  <section style="background:var(--re-slate);padding:5rem 0;" aria-labelledby="re-stats-title">
    <div class="re-container">
      <div style="display:grid;grid-template-columns:1fr 3fr;gap:5rem;align-items:center;">
        <div class="re-reveal">
          <span class="re-rule" aria-hidden="true" style="background:rgba(198,168,75,.5);"></span>
          <h2 id="re-stats-title" style="font-family:'Cormorant',Georgia,serif;font-size:clamp(2rem,3vw,3rem);font-weight:300;color:var(--re-ivory);margin:0;line-height:1.2;"><em style="font-style:italic;color:var(--re-gold);">Market</em><br>Intelligence</h2>
        </div>
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:2rem;" class="re-reveal" style="transition-delay:100ms;">
          <?php foreach($re_stats as $si=>$st): ?>
          <div style="text-align:center;padding:2rem 1rem;border-left:1px solid rgba(255,255,255,.07);<?php echo $si===0?'border-left:none;':''; ?>">
            <p class="re-counter" data-target="<?php echo esc_attr($st['n']); ?>" style="font-family:'Cormorant',Georgia,serif;font-size:2.5rem;font-weight:400;color:var(--re-gold);margin:0 0 .4rem;line-height:1;"><?php echo esc_html($st['n']); ?></p>
            <p style="font-family:'Karla',sans-serif;font-size:.7rem;letter-spacing:.16em;text-transform:uppercase;color:rgba(255,255,255,.45);margin:0;"><?php echo esc_html($st['l']); ?></p>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </section>

  <!-- MEET THE AGENTS ────────────────────────────────────── -->
  <section class="re-section" style="background:#ffffff;" aria-labelledby="re-team-title">
    <div class="re-container">
      <div class="re-reveal" style="text-align:center;margin-bottom:4rem;">
        <span class="re-rule" aria-hidden="true" style="margin:0 auto 1.5rem;"></span>
        <p class="re-eyebrow">Our People</p>
        <h2 id="re-team-title" style="font-family:'Cormorant',Georgia,serif;font-size:clamp(2.5rem,4vw,3.5rem);font-weight:400;color:var(--re-slate);margin:0;">Meet the Team</h2>
      </div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:2rem;">
        <?php foreach($re_agents as $agi=>$agent): ?>
        <article class="re-reveal" style="transition-delay:<?php echo $agi*80; ?>ms;text-align:center;">
          <!-- CSS Agent portrait -->
          <div style="width:120px;height:120px;border-radius:50%;background:linear-gradient(135deg,<?php echo esc_attr($agent['skin']); ?> 0%,<?php echo esc_attr($agent['skin']); ?> 100%);margin:0 auto 1.5rem;position:relative;overflow:hidden;border:3px solid #f0ede6;">
            <!-- Hair -->
            <div style="position:absolute;top:-2px;left:0;right:0;height:42%;background:<?php echo esc_attr($agent['hair']); ?>;border-radius:50% 50% 0 0;"></div>
            <!-- Collar -->
            <div style="position:absolute;bottom:-2px;left:50%;transform:translateX(-50%);width:60px;height:30px;background:#ffffff;border-radius:50% 50% 0 0;"></div>
            <!-- Navy suit v-neck -->
            <div style="position:absolute;bottom:-2px;left:50%;transform:translateX(-50%);width:80px;height:30px;background:var(--re-slate);border-radius:4px 4px 0 0;clip-path:polygon(20% 0%,80% 0%,100% 100%,0% 100%);"></div>
          </div>
          <h3 style="font-family:'Cormorant',Georgia,serif;font-size:1.35rem;font-weight:400;color:var(--re-slate);margin:0 0 .25rem;"><?php echo esc_html($agent['name']); ?></h3>
          <p style="font-family:'Karla',sans-serif;font-size:.72rem;letter-spacing:.14em;text-transform:uppercase;color:var(--re-gold);margin:0 0 1rem;"><?php echo esc_html($agent['role']); ?></p>
          <div style="display:flex;justify-content:center;gap:2rem;margin-bottom:1.25rem;padding:1rem 0;border-top:1px solid #f0f0f0;border-bottom:1px solid #f0f0f0;">
            <div><p style="font-family:'Cormorant',Georgia,serif;font-size:1.1rem;color:var(--re-slate);margin:0;"><?php echo esc_html($agent['sales']); ?></p><p style="font-size:.6rem;letter-spacing:.12em;text-transform:uppercase;color:var(--re-stone);margin:0;">Sold 2025</p></div>
            <div><p style="font-family:'Cormorant',Georgia,serif;font-size:1.1rem;color:var(--re-slate);margin:0;"><?php echo esc_html($agent['props']); ?></p><p style="font-size:.6rem;letter-spacing:.12em;text-transform:uppercase;color:var(--re-stone);margin:0;">Active</p></div>
          </div>
          <a href="<?php echo esc_url(home_url('/team/'.sanitize_title($agent['name']))); ?>" style="font-family:'Karla',sans-serif;font-size:.7rem;letter-spacing:.12em;text-transform:uppercase;color:var(--re-gold);text-decoration:none;border-bottom:1px solid rgba(198,168,75,.3);padding-bottom:1px;">View profile &#8594;</a>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- NEIGHBOURHOODS ─────────────────────────────────────── -->
  <section class="re-section" style="background:var(--re-mist);" aria-labelledby="re-hood-title">
    <div class="re-container">
      <div class="re-reveal" style="margin-bottom:3.5rem;">
        <span class="re-rule" aria-hidden="true"></span>
        <p class="re-eyebrow">Local Knowledge</p>
        <h2 id="re-hood-title" style="font-family:'Cormorant',Georgia,serif;font-size:clamp(2.5rem,4vw,3.5rem);font-weight:400;color:var(--re-slate);margin:0;">Prime Neighbourhoods</h2>
      </div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:1px;background:#d0d4d8;">
        <?php foreach($re_hoods as $hi=>$hood): ?>
        <div class="re-reveal" style="transition-delay:<?php echo $hi*80; ?>ms;background:#ffffff;padding:2.5rem 2rem;cursor:pointer;transition:background .3s;" onmouseenter="this.style.background='var(--re-slate)';Array.from(this.querySelectorAll('[data-light]')).forEach(el=>el.style.color='rgba(255,255,255,.85)');Array.from(this.querySelectorAll('[data-dim]')).forEach(el=>el.style.color='rgba(255,255,255,.45)')" onmouseleave="this.style.background='#ffffff';Array.from(this.querySelectorAll('[data-light]')).forEach(el=>el.style.color='var(--re-slate)');Array.from(this.querySelectorAll('[data-dim]')).forEach(el=>el.style.color='var(--re-stone)')">
          <div style="width:48px;height:48px;border-radius:50%;background:var(--re-mist);display:flex;align-items:center;justify-content:center;margin-bottom:1.5rem;border:1px solid #e5e7eb;">
            <span aria-hidden="true" style="color:var(--re-gold);font-size:1.2rem;">&#9679;</span>
          </div>
          <h3 data-light style="font-family:'Cormorant',Georgia,serif;font-size:1.5rem;font-weight:400;color:var(--re-slate);margin:0 0 .35rem;"><?php echo esc_html($hood['name']); ?></h3>
          <p data-dim style="font-family:'Karla',sans-serif;font-size:.72rem;letter-spacing:.14em;text-transform:uppercase;color:var(--re-stone);margin:0 0 1.5rem;"><?php echo esc_html($hood['type']); ?></p>
          <div style="display:flex;flex-direction:column;gap:.6rem;">
            <div style="display:flex;justify-content:space-between;align-items:center;">
              <span data-dim style="font-size:.75rem;color:var(--re-stone);">Avg price</span>
              <span data-light style="font-family:'Cormorant',Georgia,serif;font-size:1.1rem;color:var(--re-slate);"><?php echo esc_html($hood['avg']); ?></span>
            </div>
            <div style="display:flex;justify-content:space-between;align-items:center;">
              <span data-dim style="font-size:.75rem;color:var(--re-stone);">YoY trend</span>
              <span style="font-family:'Karla',sans-serif;font-size:.8rem;font-weight:500;color:#2A6B2A;background:#e8f5e8;padding:.15rem .5rem;border-radius:2px;"><?php echo esc_html($hood['trend']); ?></span>
            </div>
          </div>
          <div style="margin-top:1.5rem;padding-top:1.5rem;border-top:1px solid rgba(0,0,0,.07);">
            <a href="<?php echo esc_url(home_url('/areas/'.sanitize_title($hood['name']))); ?>" data-light style="font-family:'Karla',sans-serif;font-size:.7rem;letter-spacing:.12em;text-transform:uppercase;color:var(--re-gold);text-decoration:none;">Explore &#8594;</a>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- VALUATION CTA ──────────────────────────────────────── -->
  <section style="background:var(--re-slate);padding:6rem 0;position:relative;overflow:hidden;" aria-labelledby="re-val-title">
    <div aria-hidden="true" style="position:absolute;top:0;right:0;width:500px;height:100%;background:linear-gradient(270deg,rgba(198,168,75,.05) 0%,transparent 70%);pointer-events:none;"></div>
    <div class="re-container">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:5rem;align-items:center;">
        <div class="re-reveal">
          <span class="re-rule" aria-hidden="true" style="background:rgba(198,168,75,.4);"></span>
          <p class="re-eyebrow" style="color:rgba(198,168,75,.7);">Free &amp; confidential</p>
          <h2 id="re-val-title" style="font-family:'Cormorant',Georgia,serif;font-size:clamp(2.5rem,4vw,4rem);font-weight:300;color:var(--re-ivory);line-height:1.1;margin:0 0 1.25rem;">What is your<br><em style="color:var(--re-gold);font-style:italic;">property worth?</em></h2>
          <p style="font-family:'Karla',sans-serif;font-size:.95rem;color:rgba(234,238,242,.55);line-height:1.75;margin:0;">Our senior agents provide accurate, confidential valuations backed by thirty-five years of Prime London expertise. No obligation, no pressure.</p>
        </div>
        <div class="re-reveal" style="transition-delay:120ms;">
          <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:flex;flex-direction:column;gap:1rem;" novalidate>
            <input type="hidden" name="action" value="tf_re_valuation">
            <?php wp_nonce_field('tf_re_valuation','tf_re_nonce'); ?>
            <?php
            $re_form_fields=[
              ['id'=>'re-f-name','name'=>'name','label'=>'Your Name','type'=>'text','ph'=>'Full name'],
              ['id'=>'re-f-email','name'=>'email','label'=>'Email Address','type'=>'email','ph'=>'email@example.com'],
              ['id'=>'re-f-phone','name'=>'phone','label'=>'Phone Number','type'=>'tel','ph'=>'+44'],
              ['id'=>'re-f-addr','name'=>'address','label'=>'Property Address','type'=>'text','ph'=>'Property address or postcode'],
            ];
            foreach($re_form_fields as $ff):?>
            <div>
              <label for="<?php echo esc_attr($ff['id']); ?>" style="display:block;font-family:'Karla',sans-serif;font-size:.62rem;letter-spacing:.18em;text-transform:uppercase;color:rgba(255,255,255,.4);margin-bottom:.4rem;"><?php echo esc_html($ff['label']); ?></label>
              <input type="<?php echo esc_attr($ff['type']); ?>" id="<?php echo esc_attr($ff['id']); ?>" name="<?php echo esc_attr($ff['name']); ?>" placeholder="<?php echo esc_attr($ff['ph']); ?>" class="re-input" style="background:rgba(255,255,255,.06);border-color:rgba(255,255,255,.1);color:#ffffff;" required>
            </div>
            <?php endforeach; ?>
            <button type="submit" style="margin-top:.5rem;padding:1rem 2rem;background:var(--re-gold);color:#ffffff;font-family:'Karla',sans-serif;font-size:.78rem;font-weight:600;letter-spacing:.14em;text-transform:uppercase;border:none;border-radius:2px;cursor:pointer;">Request Valuation</button>
          </form>
        </div>
      </div>
    </div>
  </section>

  <!-- TESTIMONIALS ────────────────────────────────────────── -->
  <section class="re-section" style="background:var(--re-ivory);" aria-labelledby="re-testi-title">
    <div class="re-container">
      <div class="re-reveal" style="text-align:center;margin-bottom:4rem;">
        <span class="re-rule" aria-hidden="true" style="margin:0 auto 1.5rem;"></span>
        <p class="re-eyebrow">Client Stories</p>
        <h2 id="re-testi-title" style="font-family:'Cormorant',Georgia,serif;font-size:clamp(2.5rem,4vw,3.5rem);font-weight:400;color:var(--re-slate);margin:0;">What Our Clients Say</h2>
      </div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:2rem;">
        <?php
        $re_testis=[
          ['name'=>'Edward &amp; Clara Forsyth','prop'=>'Pemberton House, Notting Hill','txt'=>"Meridian's discretion and market knowledge are unmatched in London. They found us our dream home in six weeks without a single wasted viewing.",'stars'=>5],
          ['name'=>'Dr Ananya Krishnan','prop'=>'The Observatory, Primrose Hill','txt'=>"I'd sold two properties in Prime London before working with Meridian. The difference in service level is remarkable. The result exceeded our guide price by 7%.",'stars'=>5],
          ['name'=>'The Harrington Family','prop'=>'Birch Manor, Hampstead','txt'=>"James guided us through a complex purchase with patience and professionalism. We never felt like just another client. Exceptional from first call to completion.",'stars'=>5],
        ];
        foreach($re_testis as $ri=>$rt):?>
        <blockquote class="re-reveal" style="transition-delay:<?php echo $ri*100; ?>ms;margin:0;background:#ffffff;border-top:3px solid var(--re-gold);padding:2.5rem 2rem;position:relative;">
          <div aria-label="<?php echo esc_attr($rt['stars']); ?> stars" style="display:flex;gap:.25rem;margin-bottom:1.25rem;">
            <?php for($s=0;$s<$rt['stars'];$s++) echo '<span aria-hidden="true" style="color:var(--re-gold);font-size:.9rem;">&#9733;</span>'; ?>
          </div>
          <p style="font-family:'Cormorant',Georgia,serif;font-style:italic;font-size:1.1rem;color:var(--re-mid);line-height:1.75;margin:0 0 1.5rem;"><?php echo esc_html($rt['txt']); ?></p>
          <footer>
            <p style="font-family:'Karla',sans-serif;font-size:.85rem;font-weight:600;color:var(--re-slate);margin:0 0 .2rem;"><?php echo $rt['name']; ?></p>
            <p style="font-family:'Karla',sans-serif;font-size:.75rem;color:var(--re-stone);margin:0;"><?php echo esc_html($rt['prop']); ?></p>
          </footer>
        </blockquote>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- FOOTER STRIP ────────────────────────────────────────── -->
  <div style="background:var(--re-slate);padding:3rem 0;border-top:1px solid rgba(255,255,255,.06);">
    <div class="re-container" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:2rem;">
      <div>
        <p style="font-family:'Cormorant',Georgia,serif;font-size:1.5rem;font-weight:400;color:var(--re-ivory);margin:0 0 .25rem;letter-spacing:-.01em;">Meridian Estate</p>
        <p style="font-family:'Karla',sans-serif;font-size:.75rem;color:rgba(255,255,255,.35);margin:0;">14 Portobello Road, Notting Hill, London W11 · Est. 1989</p>
      </div>
      <div style="display:flex;gap:2rem;align-items:center;flex-wrap:wrap;">
        <?php
        $re_footer_links=[['l'=>'Properties','u'=>'/properties'],['l'=>'Sell','u'=>'/sell'],['l'=>'Let','u'=>'/let'],['l'=>'Valuations','u'=>'/valuation'],['l'=>'About','u'=>'/about'],['l'=>'Contact','u'=>'/contact']];
        foreach($re_footer_links as $fl):?>
        <a href="<?php echo esc_url(home_url($fl['u'])); ?>" style="font-family:'Karla',sans-serif;font-size:.72rem;letter-spacing:.14em;text-transform:uppercase;color:rgba(255,255,255,.45);text-decoration:none;"><?php echo esc_html($fl['l']); ?></a>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

</div><!-- /.re-page -->

<script>
(function(){
  'use strict';
  var obs=new IntersectionObserver(function(entries){
    entries.forEach(function(e){if(e.isIntersecting){e.target.classList.add('re-visible');obs.unobserve(e.target);}});
  },{threshold:.08});
  document.querySelectorAll('.re-reveal').forEach(function(el){obs.observe(el);});
})();
</script>


<?php
/* ─────────────────────────────────────────────────────────────
   INSIGHTS / BLOG SECTION
   ───────────────────────────────────────────────────────────── */
$re_posts = [
  ['title'=>'Prime London Market Review — Spring 2026','cat'=>'Market Report','date'=>'28 April 2026','read'=>'6 min','excerpt'=>'Transaction volumes in Prime Central London rose 14% year-on-year in Q1, driven by returning international buyers and a renewed focus on family houses above £3M.','color'=>'#1C2B3A'],
  ['title'=>'Buying Off-Market: The Advantages of a Quiet Approach','cat'=>'Buying Guide','date'=>'15 April 2026','read'=>'4 min','excerpt'=>'Up to 40% of prime London properties never appear on the portals. Our guide explains how to access the best stock before it reaches the open market.','color'=>'#1F2A20'],
  ['title'=>'Capital Gains and Inheritance Tax: What Sellers Need to Know in 2026','cat'=>'Legal & Finance','date'=>'2 April 2026','read'=>'8 min','excerpt'=>'The 2026 Budget introduced changes affecting second home sales and estate planning. We outline what high-value property owners need to consider.','color'=>'#26201A'],
];
?>
<!-- INSIGHTS ─────────────────────────────────────────────── -->
<section class="re-section" style="background:var(--re-mist);" aria-labelledby="re-insights-title">
  <div class="re-container">
    <div style="display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:3.5rem;flex-wrap:wrap;gap:1.5rem;">
      <div class="re-reveal">
        <span class="re-rule" aria-hidden="true"></span>
        <p class="re-eyebrow">Knowledge Centre</p>
        <h2 id="re-insights-title" style="font-family:'Cormorant',Georgia,serif;font-size:clamp(2.5rem,4vw,3.5rem);font-weight:400;color:var(--re-slate);margin:0;">Market Insights</h2>
      </div>
      <a href="<?php echo esc_url(home_url('/insights')); ?>" class="re-reveal" style="padding:.75rem 1.75rem;border:1px solid var(--re-slate);color:var(--re-slate);font-family:'Karla',sans-serif;font-size:.75rem;letter-spacing:.14em;text-transform:uppercase;text-decoration:none;border-radius:2px;">All Articles</a>
    </div>
    <div style="display:grid;grid-template-columns:1.5fr 1fr 1fr;gap:1.5rem;">
      <?php foreach($re_posts as $bpi=>$bp): ?>
      <article class="re-reveal" style="transition-delay:<?php echo $bpi*90; ?>ms;background:#ffffff;border-radius:3px;overflow:hidden;box-shadow:0 2px 20px rgba(28,43,58,.07);display:flex;flex-direction:column;">
        <!-- Art block -->
        <div style="<?php echo $bpi===0?'height:220px;':'height:150px;'; ?>background:<?php echo esc_attr($bp['color']); ?>;position:relative;overflow:hidden;flex-shrink:0;">
          <div style="position:absolute;inset:0;background:repeating-linear-gradient(45deg,transparent,transparent 24px,rgba(198,168,75,.02) 24px,rgba(198,168,75,.02) 25px);"></div>
          <div style="position:absolute;bottom:1.5rem;left:1.5rem;background:rgba(198,168,75,.15);border:1px solid rgba(198,168,75,.3);border-radius:2px;padding:.2rem .65rem;font-family:'Karla',sans-serif;font-size:.58rem;letter-spacing:.14em;text-transform:uppercase;color:var(--re-gold);"><?php echo esc_html($bp['cat']); ?></div>
        </div>
        <div style="padding:1.5rem;display:flex;flex-direction:column;flex:1;">
          <div style="display:flex;gap:1rem;margin-bottom:.85rem;">
            <span style="font-family:'Karla',sans-serif;font-size:.7rem;color:var(--re-stone);"><?php echo esc_html($bp['date']); ?></span>
            <span style="font-family:'Karla',sans-serif;font-size:.7rem;color:var(--re-stone);"><?php echo esc_html($bp['read']); ?> read</span>
          </div>
          <h3 style="font-family:'Cormorant',Georgia,serif;font-size:<?php echo $bpi===0?'1.35rem':'1.1rem'; ?>;font-weight:400;color:var(--re-slate);margin:0 0 .75rem;line-height:1.3;"><?php echo esc_html($bp['title']); ?></h3>
          <p style="font-family:'Karla',sans-serif;font-size:.82rem;color:var(--re-mid);line-height:1.65;margin:0 0 1.25rem;flex:1;"><?php echo esc_html($bp['excerpt']); ?></p>
          <a href="<?php echo esc_url(home_url('/insights/'.sanitize_title($bp['title']))); ?>" style="font-family:'Karla',sans-serif;font-size:.7rem;letter-spacing:.12em;text-transform:uppercase;color:var(--re-gold);text-decoration:none;border-bottom:1px solid rgba(198,168,75,.3);padding-bottom:1px;align-self:flex-start;">Read article &#8594;</a>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php
/* ─────────────────────────────────────────────────────────────
   LETTINGS SECTION
   ───────────────────────────────────────────────────────────── */
$re_lets = [
  ['name'=>'Garden Flat, Kensington','beds'=>2,'baths'=>1,'area'=>950,'price'=>'£4,200 pcm','color'=>'#1C2B3A'],
  ['name'=>'River Penthouse, Chelsea','beds'=>3,'baths'=>2,'area'=>1800,'price'=>'£9,500 pcm','color'=>'#1A2233'],
  ['name'=>'Mews Cottage, Holland Park','beds'=>2,'baths'=>2,'area'=>1200,'price'=>'£6,800 pcm','color'=>'#1F2A20'],
  ['name'=>'Studio, Soho','beds'=>1,'baths'=>1,'area'=>580,'price'=>'£2,750 pcm','color'=>'#26201A'],
];
?>
<!-- LETTINGS ─────────────────────────────────────────────── -->
<section class="re-section" style="background:#ffffff;" aria-labelledby="re-lets-title">
  <div class="re-container">
    <div style="display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:3.5rem;flex-wrap:wrap;gap:1.5rem;">
      <div class="re-reveal">
        <span class="re-rule" aria-hidden="true"></span>
        <p class="re-eyebrow">To Let</p>
        <h2 id="re-lets-title" style="font-family:'Cormorant',Georgia,serif;font-size:clamp(2.5rem,4vw,3.5rem);font-weight:400;color:var(--re-slate);margin:0;">Available Now</h2>
      </div>
      <div class="re-reveal" style="display:flex;gap:1rem;align-items:center;">
        <a href="<?php echo esc_url(home_url('/properties/to-let')); ?>" style="padding:.75rem 1.75rem;background:var(--re-slate);color:#ffffff;font-family:'Karla',sans-serif;font-size:.75rem;letter-spacing:.14em;text-transform:uppercase;text-decoration:none;border-radius:2px;">All Lettings</a>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:1.25rem;">
      <?php foreach($re_lets as $li=>$let): ?>
      <article class="re-prop re-reveal" style="transition-delay:<?php echo $li*80; ?>ms;">
        <div style="aspect-ratio:4/3;background:<?php echo esc_attr($let['color']); ?>;position:relative;overflow:hidden;">
          <div style="position:absolute;inset:0;background:repeating-linear-gradient(90deg,transparent,transparent 14px,rgba(255,255,255,.015) 14px,rgba(255,255,255,.015) 15px);"></div>
          <div aria-hidden="true" style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-family:'Cormorant',Georgia,serif;font-size:1.2rem;font-weight:300;color:rgba(255,255,255,.07);padding:.75rem;text-align:center;"><?php echo esc_html($let['name']); ?></div>
          <div style="position:absolute;top:.75rem;left:.75rem;background:rgba(198,168,75,.15);border:1px solid rgba(198,168,75,.3);border-radius:2px;padding:.2rem .5rem;font-family:'Karla',sans-serif;font-size:.55rem;letter-spacing:.12em;text-transform:uppercase;color:var(--re-gold);">To Let</div>
        </div>
        <div style="padding:1.25rem;">
          <h3 style="font-family:'Cormorant',Georgia,serif;font-size:1.15rem;font-weight:400;color:var(--re-slate);margin:0 0 .5rem;"><?php echo esc_html($let['name']); ?></h3>
          <div style="display:flex;gap:1rem;margin-bottom:.75rem;">
            <span style="font-size:.72rem;color:var(--re-stone);"><?php echo esc_html($let['beds']); ?> bed</span>
            <span style="font-size:.72rem;color:var(--re-stone);"><?php echo esc_html($let['baths']); ?> bath</span>
            <span style="font-size:.72rem;color:var(--re-stone);"><?php echo number_format($let['area']); ?> sq ft</span>
          </div>
          <div style="display:flex;align-items:center;justify-content:space-between;">
            <p style="font-family:'Cormorant',Georgia,serif;font-size:1.2rem;font-weight:600;color:var(--re-slate);margin:0;"><?php echo esc_html($let['price']); ?></p>
            <a href="<?php echo esc_url(home_url('/properties/'.sanitize_title($let['name']))); ?>" style="font-family:'Karla',sans-serif;font-size:.65rem;letter-spacing:.12em;text-transform:uppercase;color:var(--re-gold);text-decoration:none;border-bottom:1px solid rgba(198,168,75,.3);padding-bottom:1px;">View &#8594;</a>
          </div>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php
/* ─────────────────────────────────────────────────────────────
   FAQ SECTION
   ───────────────────────────────────────────────────────────── */
$re_faqs = [
  ['q'=>'How is Meridian different from online estate agents?','a'=>"Meridian Estate is a full-service prime London agency. We provide dedicated agent representation, professional photography and marketing, proactive buyer matching from our database of over 8,000 registered clients, and negotiation expertise that consistently achieves above guide price."],
  ['q'=>'What are your fees for selling a property?','a'=>"Our fees are competitive for the prime London market and are discussed transparently from the outset. There are no hidden charges. We work on a no-sale-no-fee basis for all standard instructions."],
  ['q'=>'Can you sell my property discreetly without listing it publicly?','a'=>"Yes — we manage a significant number of off-market and discreet sale mandates. Our client database allows us to match buyers to properties without the property appearing on any portal. Please contact us to discuss your requirements."],
  ['q'=>'Do you handle the legal and surveying process?','a'=>"We work closely with a network of trusted solicitors and RICS surveyors and can provide referrals. We actively manage the conveyancing timeline to keep transactions on track and minimise delays to exchange."],
  ['q'=>'How do I register as a buyer?','a'=>"Register via the form on our Properties page or call our office directly. A senior agent will conduct a brief qualification call to understand your requirements before presenting suitable properties."],
];
?>
<!-- FAQ ─────────────────────────────────────────────────── -->
<section class="re-section" style="background:var(--re-ivory);" aria-labelledby="re-faq-title">
  <div class="re-container">
    <div style="display:grid;grid-template-columns:1fr 1.5fr;gap:5rem;align-items:start;">
      <div class="re-reveal">
        <span class="re-rule" aria-hidden="true"></span>
        <p class="re-eyebrow">Information</p>
        <h2 id="re-faq-title" style="font-family:'Cormorant',Georgia,serif;font-size:clamp(2.5rem,4vw,3.5rem);font-weight:400;color:var(--re-slate);margin:0 0 1.25rem;line-height:1.1;">Frequently<br>Asked Questions</h2>
        <p style="font-family:'Karla',sans-serif;font-size:.9rem;color:var(--re-mid);line-height:1.75;margin:0 0 2rem;">Everything you need to know about working with Meridian Estate. Can't find an answer? Call us on <strong style="color:var(--re-slate);">+44 20 7123 4000</strong>.</p>
        <a href="<?php echo esc_url(home_url('/contact')); ?>" style="display:inline-block;padding:.85rem 2rem;background:var(--re-gold);color:#ffffff;font-family:'Karla',sans-serif;font-size:.78rem;font-weight:600;letter-spacing:.14em;text-transform:uppercase;text-decoration:none;border-radius:2px;">Contact Us</a>
      </div>
      <div class="re-reveal" style="transition-delay:100ms;">
        <?php foreach($re_faqs as $fi=>$fq): ?>
        <div class="re-faq" style="border-bottom:1px solid #e8eaec;margin:0;">
          <button class="re-faq__q" aria-expanded="false" style="width:100%;display:flex;align-items:flex-start;justify-content:space-between;padding:1.4rem 0;background:none;border:none;cursor:pointer;text-align:left;gap:1.5rem;">
            <span style="font-family:'Cormorant',Georgia,serif;font-size:1.1rem;font-weight:400;color:var(--re-slate);line-height:1.4;"><?php echo esc_html($fq['q']); ?></span>
            <span class="re-faq__icon" aria-hidden="true" style="font-size:1.25rem;color:var(--re-gold);flex-shrink:0;margin-top:2px;transition:transform .3s ease;line-height:1;">+</span>
          </button>
          <div class="re-faq__a" role="region" style="max-height:0;overflow:hidden;transition:max-height .4s ease;">
            <div class="re-faq__a-inner" style="padding:0 0 1.4rem;">
              <p style="font-family:'Karla',sans-serif;font-size:.9rem;color:var(--re-mid);line-height:1.75;margin:0;"><?php echo esc_html($fq['a']); ?></p>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<script>
(function(){
  /* FAQ accordion for re-page */
  document.querySelectorAll('.re-faq .re-faq__q').forEach(function(btn){
    btn.addEventListener('click',function(){
      var faq=btn.closest('.re-faq'),
          ans=faq.querySelector('.re-faq__a'),
          inn=faq.querySelector('.re-faq__a-inner'),
          ico=faq.querySelector('.re-faq__icon'),
          open=faq.classList.contains('re-open');
      document.querySelectorAll('.re-faq.re-open').forEach(function(f){
        f.querySelector('.re-faq__a').style.maxHeight='0';
        f.classList.remove('re-open');
        f.querySelector('.re-faq__q').setAttribute('aria-expanded','false');
        var i=f.querySelector('.re-faq__icon');if(i){i.textContent='+';i.style.transform='none';}
      });
      if(!open){
        ans.style.maxHeight=inn.scrollHeight+'px';
        faq.classList.add('re-open');
        btn.setAttribute('aria-expanded','true');
        if(ico){ico.textContent='&#215;';ico.style.transform='rotate(45deg)';}
      }
    });
  });
})();
</script>

<?php get_footer(); ?>
