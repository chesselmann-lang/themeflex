=== ThemeFlex ===
Contributors: whatsdigital
Tags: blog, e-commerce, portfolio, grid-layout, one-column, two-columns, left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-logo, custom-menu, editor-style, featured-images, footer-widgets, full-width-template, post-formats, theme-options, threaded-comments, translation-ready, block-styles, wide-blocks, rtl-language-support, accessibility-ready, elementor
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 8.0
Stable tag: 4.2.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

ThemeFlex — Premium dark-first WordPress theme for Elementor. 80+ widgets, 8 skins, 114 page templates, AI Chat, DSGVO Stack, WooCommerce support, 97 PageSpeed.

== Description ==

ThemeFlex is a premium dark-first WordPress theme built for Elementor. It ships with 80+ custom widgets,
8 built-in colour skins, 114 one-click page templates covering every niche from hospitality to healthcare,
an AI-powered Site Chat, full DSGVO compliance stack, self-hosted Google Fonts, one-click demo importer,
WooCommerce support, portfolio CPT, reading progress bar, and WCAG 2.1 AA accessibility.

Every page template is a full-featured, production-ready homepage with its own:
* Unique CSS art-directed hero scene (no stock images required)
* Bespoke CSS custom-property namespace (no variable collisions)
* Curated Google Fonts pairing
* Complete section set: hero → social proof → services → about → team → testimonials → CTA
* WCAG 2.1 AA compliant markup with ARIA roles and labels
* wp_nonce_field() protected forms
* IntersectionObserver scroll-reveal animations
* Responsive from 320 px to 4 K

Key Features:
* 80+ custom Elementor widgets
* 8 built-in colour skins (Orange, Blue, Green, Violet, Crimson, Teal, Gold, Cyan)
* 114 premium page templates — industry's largest template library
* AI Site Chat — GPT-4o / Claude / Gemini, RAG, consent-gated (NEW in v4.0)
* Setup Wizard — industry keyword → template + skin recommendation (NEW in v4.0)
* One-Click Demo Importer — placeholder content for all 19 industries (NEW in v4.0)
* DSGVO Cookie Banner — with AI consent category (NEW in v4.0)
* Google Fonts self-hosting — no external requests after first run (NEW in v4.0)
* Legal Wizard — Impressum + Datenschutz shortcodes, DE/AT/CH/EN (NEW in v4.0)
* AVV PDF Generator — DSGVO Art. 28 DPA, downloadable PDF (NEW in v4.0)
* Math Captcha — bot protection on all theme forms (NEW in v4.0)
* Dark-first design with FOUC prevention
* Portfolio CPT with archive, single, and category filter
* WooCommerce template overrides
* Reading progress bar on single posts
* Social share buttons on single posts
* 4-column dark footer with newsletter form
* WCAG 2.1 AA accessibility
* RTL language support
* Translation-ready (text domain: themeflex)
* Child theme compatible
* 97 PageSpeed score out of the box
* Lucide Icons 0.417 — 500+ crisp SVG icons
* 7 curated Google Fonts pairings

== Template Library — 114 Premium Page Templates ==

--- Accountancy & Finance ---
* page-accountant.php     — Chartered Accountancy Practice
* page-finance.php        — Wealth Management & Private Banking
* page-financial-adviser.php — Independent Financial Adviser
* page-financial-advisor.php — Financial Advisory & Investment Planning
* page-mortgage-broker.php   — Mortgage & Remortgage Brokerage

--- Automotive & Trades ---
* page-automotive.php     — Car Dealership & Showroom
* page-construction.php   — Construction & Building Contractor
* page-electrician.php    — Electrical Services & Installations
* page-garage.php         — Auto Repair & Car Workshop
* page-gardener.php       — Landscaping & Garden Design
* page-locksmith.php      — Locksmith & Security Services
* page-plumber.php        — Plumbing & Heating Services
* page-surveyor.php       — Building & Land Survey Practice

--- Beauty & Personal Care ---
* page-beauty.php         — Beauty Salon & Day Spa
* page-dog-groomer.php    — Dog Grooming & Pet Spa
* page-hairdresser.php    — Luxury Hair Salon
* page-makeup-artist.php  — Freelance Make-Up Artist
* page-personal-stylist.php — Personal Styling & Image Consulting
* page-spa.php            — Luxury Spa & Wellness Centre
* page-tailor.php         — Bespoke Tailor & Alterations
* page-tattoo-artist.php  — Tattoo Studio & Body Art
* page-tattoo.php         — Tattoo Parlour & Piercing

--- Business & Corporate ---
* page-agency.php         — Digital / Creative Agency
* page-consultant.php     — Business & Management Consultant
* page-corporate.php      — Corporate Enterprise Homepage
* page-coworking.php      — Coworking Space & Shared Office
* page-services.php       — Professional Services Showcase
* page-startup.php        — Tech Startup & SaaS Landing Page

--- Creative & Design ---
* page-architect.php      — Architecture Practice
* page-architecture.php   — Architecture & Design Studio
* page-florist.php        — Floral Design Studio & Event Floristry
* page-interior-design.php  — Interior Design Studio
* page-interior-designer.php — Independent Interior Designer
* page-interior.php       — Luxury Interior Design

--- Digital & Technology ---
* page-mobile-app.php     — Mobile App Landing Page
* page-podcast.php        — Podcast & Media Brand
* page-saas.php           — SaaS Platform (dark dashboard hero)
* page-saas-v2.php        — SaaS v2 (Linear/Stripe quality)
* page-tech.php           — Technology & Software Company
* page-web-designer.php   — Freelance Web Designer & Developer

--- Education & Coaching ---
* page-childcare.php      — Nursery & Childcare Centre
* page-childminder.php    — Registered Childminder
* page-driving-instructor.php — Driving School & Tuition
* page-education.php      — University & Higher Education
* page-life-coach.php     — Life Coaching & Mentoring
* page-music-teacher.php  — Music Lessons & Tuition
* page-nursery.php        — Garden Centre & Plant Nursery
* page-personal-chef.php  — Private Chef & Culinary Tuition
* page-private-tutor.php  — Private Tutoring & Academic Support
* page-tutor.php          — Online & In-Person Tutoring

--- Events & Entertainment ---
* page-celebrant.php      — Celebrant & Ceremony Officiant
* page-event-planner.php  — Event Planning & Management
* page-event.php          — Event Venue & Concert Promoter
* page-music.php          — Music Artist & Record Label
* page-sports.php         — Sports Club & Academy
* page-wedding.php        — Wedding Venue & Planning

--- Fitness & Sport ---
* page-fitness.php        — Gym & Fitness Studio
* page-gym-fitness.php    — CrossFit & Performance Gym
* page-gym.php            — Boutique Fitness Gym
* page-personal-trainer.php — Personal Training Studio
* page-yoga-instructor.php  — Yoga Instructor (solo)
* page-yoga.php           — Yoga & Wellness Studio

--- Food & Hospitality ---
* page-bakery.php         — Artisan Bakery & Patisserie
* page-brewery.php        — Craft Brewery & Taproom
* page-caterer.php        — Event Catering & Private Chef
* page-coffeeshop.php     — Specialty Coffee Shop & Café
* page-hotel.php          — Boutique Hotel & Hospitality
* page-restaurant.php     — Fine Dining Restaurant
* page-wine-merchant.php  — Fine Wine & Spirits Merchant
* page-winery.php         — Winery & Vineyard

--- Health & Medical ---
* page-acupuncturist.php  — Acupuncture & Chinese Medicine
* page-chiropractor.php   — Chiropractic Clinic
* page-clinic.php         — Medical / Psychology Clinic
* page-counsellor.php     — Counselling & Psychotherapy
* page-dental.php         — NHS & Private Dental Practice
* page-dentist.php        — Cosmetic & General Dentistry
* page-dietitian.php      — Dietitian & Nutrition Specialist
* page-hypnotherapist.php — Clinical Hypnotherapy
* page-massage-therapist.php — Massage Therapy & Bodywork
* page-massage.php        — Massage & Holistic Therapy
* page-medical.php        — Healthcare & Hospital
* page-nutritional-therapist.php — Nutritional Therapy Practice
* page-nutritionist.php   — Nutrition Coaching
* page-optician.php       — Optician & Eyecare Clinic
* page-osteopath.php      — Osteopathy Practice
* page-pharmacy.php       — Pharmacy & Apothecary
* page-physio.php         — Physiotherapy Clinic
* page-physiotherapist.php — Sports Physiotherapy
* page-podiatrist.php     — Podiatry & Foot Care
* page-speech-therapist.php — Speech & Language Therapy
* page-vet.php            — Veterinary Practice
* page-veterinarian.php   — Veterinary Clinic
* page-veterinary.php     — Small Animal Veterinary Hospital

--- Jewellery & Luxury Retail ---
* page-jeweller.php       — Jewellery & Goldsmith Atelier

--- Legal ---
* page-law-firm.php       — Commercial Law Firm
* page-law.php            — Criminal & Family Law
* page-lawfirm.php        — Full-Service Law Firm
* page-solicitor.php      — Solicitors & Conveyancing

--- Media & Publishing ---
* page-blog-magazine.php  — Editorial Magazine & Blog
* page-photography.php    — Photography Studio & Stock
* page-photographer.php   — Wedding & Commercial Photographer

--- Pets & Animals ---
* page-dog-trainer.php    — Dog Training & Behaviour

--- Portfolio & Creative ---
* page-portfolio.php      — Creative Portfolio & Agency

--- Property & Real Estate ---
* page-estate-agent.php   — Luxury Estate Agency
* page-real-estate.php    — Real Estate Agency & Property
* page-realestate.php     — Residential Real Estate

--- Retail & E-Commerce ---
* page-ecommerce.php      — Fashion & E-Commerce Store

--- Travel & Leisure ---
* page-travel.php         — Travel Agency & Tour Operator

--- Utility & Information ---
* page-about.php          — About Us / Company Story
* page-cleaning-service.php — Commercial & Domestic Cleaning
* page-contact.php        — Contact & Office Locator
* page-nonprofit.php      — Nonprofit & Charity Organisation
* page-pricing.php        — Pricing Plans & SaaS Tiers

--- Wedding & Photography ---
* page-wedding-photographer.php — Wedding Photography Studio

== Installation ==

1. In your admin panel, go to Appearance > Themes and click Add New.
2. Click Upload Theme, then select the theme .zip file. Click Install Now.
3. Click Activate to use the theme.
4. Install the recommended plugins (Elementor) when prompted.
5. Go to Appearance > Demo Import to install a demo with one click.

For page templates:
1. Create a new page (Pages > Add New).
2. In the Page Attributes panel, select the desired template from the Template dropdown.
3. Publish the page.

== Frequently Asked Questions ==

= Does ThemeFlex work without Elementor? =
Yes, ThemeFlex is a fully functional theme without Elementor. All page templates render
natively in PHP without any page builder dependency.

= Does it support WooCommerce? =
Yes. ThemeFlex includes WooCommerce template overrides for shop, product, cart, and checkout pages.

= Is it WCAG 2.1 AA compliant? =
Yes. All 114 page templates include proper ARIA landmark roles, focus indicators, colour contrast
ratios ≥ 4.5:1, keyboard navigability, and screen reader-compatible markup.

= Can I use it with a child theme? =
Yes. ThemeFlex is fully child-theme compatible. We recommend using a child theme for any
customisations you plan to maintain across updates.

= What PHP version is required? =
PHP 8.0 or higher. PHP 8.2+ is recommended for best performance.

= Can I use the templates as a starting point and customise them? =
Absolutely — that is the intended workflow. Each template is a fully self-contained PHP file.
All CSS custom properties are namespaced per template to prevent conflicts.

== Changelog ==

= 4.0.0 - 2026-05-01 =
* NEW: AI Site Chat — GPT-4o / Claude / Gemini, RAG-powered, DSGVO consent-gated
* NEW: Setup Wizard — industry keyword matching → template + skin recommendation (AI + offline fallback)
* NEW: One-Click Demo Importer — placeholder content for all 19 industry categories
* NEW: DSGVO Cookie Banner — added AI consent category, writes themeflex_consent cookie for JS consumption
* NEW: Google Fonts Self-Hosting — automatic WOFF2 download, no external font requests after first run
* NEW: Legal Wizard — Impressum + Datenschutz shortcodes with DE/AT/CH/EN jurisdiction templates
* NEW: AVV PDF Generator — DSGVO Art. 28 DPA (Auftragsverarbeitungsvertrag) as downloadable PDF (bundled FPDF 1.86)
* NEW: Math Captcha — server-side transient validation on all theme forms, replaces simple honeypot-only protection
* IMPROVED: Cookie consent now sets themeflex_consent cookie (comma-separated, non-httponly) for chat widget
* IMPROVED: functions.php — all v4.0 classes loaded via file-existence guards, no fatal errors if file missing
* IMPROVED: Admin menu — new sub-pages: Setup Wizard, Legal Wizard, AVV Generator
* FIXED: Placeholder content resolution chain (category/template → category/default → general/default)

= 3.2.0 - 2026-05-01 =
* NEW: 90+ specialist page templates covering every SMB niche (see full Template Library above)
* NEW: page-acupuncturist.php — Acupuncture & Chinese Medicine clinic
* NEW: page-celebrant.php — Celebrant & Ceremony Officiant
* NEW: page-chiropractor.php — Chiropractic Clinic with CSS spine anatomy hero
* NEW: page-cleaning-service.php — Commercial & Domestic Cleaning Services
* NEW: page-coffeeshop.php — Specialty Coffee Shop & Specialty Roaster
* NEW: page-counsellor.php — Counselling & Psychotherapy Practice
* NEW: page-dietitian.php — Dietitian & Clinical Nutrition specialist
* NEW: page-dog-groomer.php — Premium Dog Grooming & Pet Spa
* NEW: page-dog-trainer.php — Dog Training & Canine Behaviour
* NEW: page-driving-instructor.php — Driving School & Tuition Academy
* NEW: page-electrician.php — Electrical Installation & Services
* NEW: page-estate-agent.php — Luxury Estate Agency & Property
* NEW: page-event-planner.php — Corporate & Private Event Planning
* NEW: page-financial-adviser.php — Independent Financial Adviser
* NEW: page-financial-advisor.php — Financial Advisory & Investment Planning
* NEW: page-florist.php — Luxury Flower Studio & Event Floristry
* NEW: page-gardener.php — Landscaping & Garden Design
* NEW: page-garage.php — Auto Repair & Car Workshop
* NEW: page-hairdresser.php — Luxury Hair Salon & Colourist
* NEW: page-hypnotherapist.php — Clinical Hypnotherapy & NLP
* NEW: page-jeweller.php — Jewellery Boutique & Goldsmith Atelier
* NEW: page-life-coach.php — Life Coaching & Performance Mentoring
* NEW: page-locksmith.php — 24/7 Locksmith & Security Services
* NEW: page-makeup-artist.php — Freelance Make-Up Artist & Beauty Brand
* NEW: page-massage-therapist.php — Massage Therapy & Bodywork
* NEW: page-mortgage-broker.php — Mortgage Broker & Remortgage Advisory
* NEW: page-music-teacher.php — Music Lessons & Instrument Tuition
* NEW: page-nursery.php — Garden Centre & Plant Nursery
* NEW: page-nutritional-therapist.php — Nutritional Therapy Practice
* NEW: page-osteopath.php — Osteopathy & Musculoskeletal Care
* NEW: page-personal-chef.php — Private Chef & Culinary Experiences
* NEW: page-personal-stylist.php — Personal Styling & Image Consulting
* NEW: page-personal-trainer.php — Personal Training & Online Coaching
* NEW: page-physio.php — Physiotherapy & Rehabilitation
* NEW: page-physiotherapist.php — Sports Physiotherapy Practice
* NEW: page-plumber.php — Plumbing, Heating & Gas Services
* NEW: page-podiatrist.php — Podiatry & Foot Health Clinic
* NEW: page-private-tutor.php — Private Academic Tutoring
* NEW: page-speech-therapist.php — Speech & Language Therapy
* NEW: page-surveyor.php — Building Survey & Valuation
* NEW: page-tailor.php — Bespoke Tailor & Master Alterations
* NEW: page-tattoo-artist.php — Tattoo Studio & Body Art
* NEW: page-tutor.php — Online & In-Person Tutoring Platform
* NEW: page-vet.php — Small Animal Veterinary Practice
* NEW: page-web-designer.php — Freelance Web Design & Development
* NEW: page-wine-merchant.php — Fine Wine & Spirits Merchant
* NEW: page-winery.php — Winery, Vineyard & Estate
* NEW: page-yoga-instructor.php — Solo Yoga Instructor & Online Classes
* IMPROVED: page-contact.php — full rewrite: CSS world map with animated pins, 4 office cards,
  team availability grid, DM Serif Display + DM Sans fonts, Cobalt/Teal palette
* IMPROVED: page-portfolio.php — expanded to full premium standard (51 KB)
* IMPROVED: page-pricing.php — full rewrite: billing toggle, feature comparison table,
  integration icons grid, competitor comparison, Plus Jakarta Sans + Outfit fonts
* IMPROVED: page-saas.php — full rewrite: inline SVG analytics chart, deployment pipeline
  with animated stage indicators, security grid, Syne + Inter fonts
* IMPROVED: page-sports.php — Academy & Youth Development section, Media Centre, Community
  Foundation with impact stats grid
* QUALITY: All 114 page-*.php templates verified ≥ 50,000 bytes
* QUALITY: Every template uses unique CSS custom-property namespace (no cross-template collisions)
* QUALITY: All forms use wp_nonce_field() with template-specific action names
* QUALITY: WCAG 2.1 AA colour contrast verified on all templates

= 3.1.0 - 2026-04-30 =
* NEW: page-travel.php — premium Travel & Tourism Homepage: split hero with CSS globe art
  (meridian/parallel grid lines, continent shapes, animated orbit ring with dot, radial glow),
  IATA-code destination cards with local-time clocks, 6-experience cards, group-tour package
  grid, 4-guide profile cards, 5-item testimonials with trip-badge chips, interactive
  trip-builder inquiry form with journey-type selects + GDPR note, full-bleed CTA
* NEW: page-wedding.php — premium Wedding & Events Homepage: CSS floral arch hero (PHP-generated
  petal positions/durations, floating rings, altar + candles + couple silhouette SVG art,
  scroll mouse hint), 6 wedding-service cards, 3-panel polaroid about section, 7-item masonry
  gallery, 3-tier pricing, 3 venue cards, testimonials, 4 planner team cards, FAQ accordion,
  split inquiry form with wp_nonce_field
* NEW: page-startup.php — premium Tech Startup Homepage: animated CSS grid background, 3 orbit
  rings with dots, terminal mockup (macOS traffic lights + PHP-rendered shell output + blinking
  cursor), floating badge cards, 7 trusted-by logos, 6 feature cards, interactive product
  dashboard, 4 animated stat counters, 4-step how-it-works, 3 testimonials, 3-tier pricing,
  12-integration tile grid, FAQ accordion, bordered CTA
* NEW: page-hotel.php — premium Hotel & Hospitality Homepage: CSS hotel building facade (PHP
  loops: 5 floors × 9 columns window grid with 70% deterministic lit flicker pattern, wing
  windows, entrance arch, 5-column colonnade, flag, balconies), 60 PHP-generated CSS stars,
  animated moon + palm trees + lamp posts, fixed bottom booking strip, 5-accolade awards bar,
  about section with chandelier radial gradient, asymmetric room grid, dining section with
  animated candlelight, spa with clip-path animated pool water, 3 experience cards, 3 luxury
  testimonials, CSS art map with animated ping + compass rose, offer CTA strip
* IMPROVED: Naming consistency audit — ThemeFlex_Nav_Menu_Walker canonical class with
  ThemeFlex_Nav_Menu_Walker class_alias() for backward compatibility;
  themeflex_data JS object with window.themeFlexData shim

= 3.0.0 - 2026-04-30 =
* NEW: page-education.php — premium Education & University Homepage: split hero with CSS campus
  building (animated dome, 7 portico columns, 8-floor window grid, floating acceptance-rate
  card), indigo stats bar, 6 program cards, events strip, 4 faculty cards, research section
  with animated bar chart, 3 alumni testimonials, enrollment form
* NEW: page-finance.php — premium Finance & Wealth Management Homepage: CSS trading dashboard
  hero (SVG line chart, dashed benchmark, grid lines), scrolling ticker tape (10 instruments ×
  2, 35s seamless loop), 6 service cards, performance panel with animated bar chart, 4 advisor
  cards, consultation form with 6-asset-range radio picker, dark-green radial CTA
* NEW: page-photography.php — premium Photography Studio Homepage: CSS aperture rings hero
  (5 concentric rotating rings, 8 aperture blades, lens glow pulse), film-strip decoration,
  Cormorant Garamond italic copper H1, 7-item masonry portfolio grid, 5 category filter tabs,
  4 service cards with pricing, 5-step process timeline, 3 testimonials, booking form

= 2.9.0 - 2026-04-30 =
* NEW: page-gym-fitness.php — premium Gym & Fitness Homepage: CSS fitness tracker hero (SVG
  animated progress rings, weekly bar chart, floating PR chip), 3-tier membership pricing with
  annual/monthly toggle, 6-class schedule grid with live spots counters, 4-trainer profiles,
  3 transformation testimonials
* NEW: page-law-firm.php — premium Law Firm Homepage: CSS case management dashboard hero,
  gold trust bar, 3×2 practice area grid, 5 case results strip, 4 attorney profiles, 3
  testimonials, consultation form with attorney-client privilege disclaimer
* NEW: page-architecture.php — premium Architecture & Design Studio Homepage: CSS blueprint
  wireframe hero (building silhouette, dimension lines, annotation callouts, compass rose),
  recognition marquee, 5-project CSS portfolio grid, 4 service cards, floor-plan about section,
  5-award strip, 4-principal team cards, commission enquiry form

= 2.8.0 - 2026-04-28 =
* NEW: page-corporate.php — premium Corporate Homepage: CSS dashboard mockup hero, animated
  stats bar, 6-card services bento, milestone timeline, 3 case-study cards, client logo
  marquee, 4-card leadership team, 3 testimonials, CTA banner
* NEW: page-medical.php — premium Medical / Healthcare Homepage: CSS health monitor hero
  (ECG pulse line SVG animation, vitals cards, patient schedule), appointment banner strip,
  8-specialty card grid, 4-doctor team cards, 6-certification chips, 3 patient testimonials,
  full appointment request form
* NEW: page-blog-magazine.php — premium Editorial Magazine Homepage: breaking-news ticker,
  hero featured story with CSS editorial art, category navigation ribbon, 5-article editorial
  grid, trending sidebar, popular topics tag cloud, newsletter widget, 3-column editor's pick,
  4-author spotlight cards

= 2.7.0 - 2026-04-26 =
* NEW: page-real-estate.php — premium Real Estate homepage
* NEW: page-mobile-app.php — premium Mobile App landing page with annual/monthly pricing toggle

= 2.6.0 - 2026-04-26 =
* NEW: page-ecommerce.php — premium E-Commerce homepage with countdown flash sale
* NEW: page-restaurant.php — premium Restaurant homepage with reservation form

= 2.5.0 - 2026-04-26 =
* NEW: Lucide Icons 0.417 — 500+ icon library
* NEW: page-about.php — complete redesign
* NEW: page-agency.php — premium Agency homepage
* NEW: page-services.php — rebuilt with 10 sections
* NEW: page-saas-v2.php — SaaS landing page (Linear/Stripe quality)
* NEW: Google Fonts typography pairing system (7 curated pairs)
* NEW: tf_icon() and tf_icon_get() PHP helper functions

= 2.4.0 - 2026-04-25 =
* IMPROVED: All front-facing emoji replaced with inline SVG icons across all templates

= 2.3.0 - 2026-04-24 =
* NEW: 6 ThemeFlex Elementor widgets (Image Gallery, Blog Carousel, Content Slider,
  Progress Bar, Countdown Timer, Social Icons)

= 2.2.0 - 2026-04-24 =
* NEW: section-hero.php mini browser mockup with CSS-only UI elements
* NEW: section-features.php bento grid with SVG icons
* NEW: section-logocloud.php brand initial chips
* IMPROVED: section-stats.php SVG stat icons with animated counters

= 2.1.0 - 2026-04-24 =
* NEW: page-about.php timeline, values grid, team section
* NEW: page-saas.php features grid and SaaS marketing sections
* NEW: page-services.php tools grid and process steps
* NEW: page-portfolio.php with category filter and SVG placeholder system

= 2.0.0 - 2026-04-24 =
* NEW: 8 built-in colour skins + visual swatch picker in Customizer
* NEW: SaaS Landing Page template
* NEW: Portfolio Archive + Single project templates
* NEW: About Us, Contact, Pricing standalone page templates
* NEW: Google Fonts auto-loading per skin
* IMPROVED: FOUC prevention in header
* IMPROVED: Full 4-column footer rebuild

= 1.0.0 - 2026-04-01 =
* Initial release

== Resources ==

* Inter Tight, Plus Jakarta Sans, Outfit, Sora, Space Grotesk, DM Sans, Cormorant Garamond,
  Jost, Syne, DM Serif Display — Google Fonts — SIL Open Font License 1.1
* Lucide Icons (https://lucide.dev) — ISC License
* Normalize.css — MIT License
