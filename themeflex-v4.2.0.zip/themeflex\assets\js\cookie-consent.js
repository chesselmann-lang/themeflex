/**
 * Cookie Consent Manager
 * DSGVO/GDPR Compliant JavaScript Implementation
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

(function() {
	'use strict';

	/**
	 * Cookie Consent Manager
	 */
	class CookieConsentManager {
		constructor() {
			this.cookieName = 'sf_cookie_consent';
			this.cookieExpiry = 365 * 24 * 60 * 60 * 1000; // 1 year in milliseconds
			this.modal = document.getElementById('sf-cookie-modal');
			this.banner = document.getElementById('sf-cookie-consent');
			this.setupEventListeners();
			this.initializeScriptBlocking();
		}

		/**
		 * Setup Event Listeners
		 */
		setupEventListeners() {
			// Banner buttons
			const acceptAllBtn = document.getElementById('sf-cookie-accept-all');
			const declineBtn = document.getElementById('sf-cookie-decline');
			const settingsBtn = document.getElementById('sf-cookie-settings');

			if (acceptAllBtn) {
				acceptAllBtn.addEventListener('click', () => this.acceptAll());
			}

			if (declineBtn) {
				declineBtn.addEventListener('click', () => this.declineOptional());
			}

			if (settingsBtn) {
				settingsBtn.addEventListener('click', () => this.showModal());
			}

			// Modal buttons
			const modalSaveBtn = document.getElementById('sf-cookie-modal-save');
			const modalCancelBtn = document.getElementById('sf-cookie-modal-cancel');
			const modalCloseBtn = document.getElementById('sf-cookie-modal-close');

			if (modalSaveBtn) {
				modalSaveBtn.addEventListener('click', () => this.saveSettings());
			}

			if (modalCancelBtn) {
				modalCancelBtn.addEventListener('click', () => this.hideModal());
			}

			if (modalCloseBtn) {
				modalCloseBtn.addEventListener('click', () => this.hideModal());
			}

			// Close modal on escape key
			document.addEventListener('keydown', (e) => {
				if (e.key === 'Escape' && this.modal) {
					this.hideModal();
				}
			});

			// Close modal on backdrop click
			if (this.modal) {
				this.modal.addEventListener('click', (e) => {
					if (e.target === this.modal) {
						this.hideModal();
					}
				});
			}
		}

		/**
		 * Initialize Script Blocking
		 * Block analytics and marketing scripts until consent is given
		 */
		initializeScriptBlocking() {
			if (!window.sfCookieConsent) {
				return;
			}

			const consent = this.getConsent();

			// Block Google Analytics until consent
			if (!consent || !consent.analytics) {
				this.blockScript('google-analytics', 'analytics');
				this.blockScript('gtag', 'analytics');
			}

			// Block marketing scripts until consent
			if (!consent || !consent.marketing) {
				this.blockScript('facebook-pixel', 'marketing');
				this.blockScript('hotjar', 'marketing');
			}
		}

		/**
		 * Block Script from Loading
		 *
		 * @param {string} scriptId Script ID
		 * @param {string} category Cookie category
		 */
		blockScript(scriptId, category) {
			const scripts = document.querySelectorAll(`script[data-category="${category}"]`);
			scripts.forEach((script) => {
				// Clone script to remove it from document
				const newScript = script.cloneNode(true);
				newScript.type = 'text/plain';
				newScript.setAttribute('data-category', category);
				newScript.setAttribute('data-blocked', 'true');

				// Replace original with blocked version
				script.parentNode.replaceChild(newScript, script);
			});
		}

		/**
		 * Show Modal
		 */
		showModal() {
			if (this.modal) {
				this.modal.setAttribute('aria-hidden', 'false');
				this.modal.focus();

				// Prevent body scroll
				document.body.style.overflow = 'hidden';
			}
		}

		/**
		 * Hide Modal
		 */
		hideModal() {
			if (this.modal) {
				this.modal.setAttribute('aria-hidden', 'true');

				// Restore body scroll
				document.body.style.overflow = '';
			}
		}

		/**
		 * Accept All Cookies
		 */
		acceptAll() {
			const categories = window.sfCookieConsent?.categories || {};
			const consent = {};

			Object.keys(categories).forEach((key) => {
				consent[key] = true;
			});

			this.saveConsent(consent);
		}

		/**
		 * Decline Optional Cookies
		 */
		declineOptional() {
			const categories = window.sfCookieConsent?.categories || {};
			const consent = {};

			Object.keys(categories).forEach((key) => {
				// Only keep necessary cookies
				consent[key] = categories[key].required || false;
			});

			this.saveConsent(consent);
		}

		/**
		 * Save Custom Settings from Modal
		 */
		saveSettings() {
			const consent = {};
			const checkboxes = document.querySelectorAll('.sf-cookie-modal-checkbox');

			checkboxes.forEach((checkbox) => {
				const category = checkbox.name.replace('sf-cookie-', '');
				consent[category] = checkbox.checked;
			});

			this.saveConsent(consent);
		}

		/**
		 * Save Consent Preference
		 *
		 * @param {object} consent Consent object with category keys
		 */
		saveConsent(consent) {
			// Send to server
			this.sendConsentToServer(consent);

			// Save locally
			this.setConsent(consent);

			// Hide banner and modal
			if (this.banner) {
				this.banner.style.display = 'none';
			}
			this.hideModal();

			// Unblock scripts if consent given
			this.unblockScriptsIfConsented(consent);

			// Trigger custom event
			document.dispatchEvent(new CustomEvent('sfCookieConsentSaved', {
				detail: consent
			}));
		}

		/**
		 * Send Consent to Server via AJAX
		 *
		 * @param {object} consent Consent object
		 */
		sendConsentToServer(consent) {
			if (!window.sfCookieConsent?.ajaxUrl || !window.sfCookieConsent?.nonce) {
				return;
			}

			const formData = new FormData();
			formData.append('action', 'sf_save_cookie_consent');
			formData.append('nonce', window.sfCookieConsent.nonce);
			formData.append('consent', JSON.stringify(consent));

			fetch(window.sfCookieConsent.ajaxUrl, {
				method: 'POST',
				body: formData,
				credentials: 'same-origin'
			})
				.then((response) => response.json())
				.catch((error) => {
					console.warn('Failed to save cookie consent to server:', error);
				});
		}

		/**
		 * Unblock Scripts if Consent Given
		 *
		 * @param {object} consent Consent object
		 */
		unblockScriptsIfConsented(consent) {
			if (consent.analytics) {
				this.unblockScripts('analytics');
			}

			if (consent.marketing) {
				this.unblockScripts('marketing');
			}

			if (consent.preferences) {
				this.unblockScripts('preferences');
			}
		}

		/**
		 * Unblock Scripts by Category
		 *
		 * @param {string} category Cookie category
		 */
		unblockScripts(category) {
			const blockedScripts = document.querySelectorAll(
				`script[data-category="${category}"][data-blocked="true"]`
			);

			blockedScripts.forEach((script) => {
				const newScript = document.createElement('script');
				newScript.type = 'text/javascript';

				// Copy attributes
				Array.from(script.attributes).forEach((attr) => {
					if (attr.name !== 'type' && attr.name !== 'data-blocked') {
						newScript.setAttribute(attr.name, attr.value);
					}
				});

				// Copy content
				if (script.textContent) {
					newScript.textContent = script.textContent;
				}

				// Replace and execute
				script.parentNode.replaceChild(newScript, script);
			});
		}

		/**
		 * Get Consent from Cookie
		 *
		 * @return {object|null} Consent object or null if not set
		 */
		getConsent() {
			const value = `; ${document.cookie}`;
			const parts = value.split(`; ${this.cookieName}=`);

			if (parts.length === 2) {
				try {
					return JSON.parse(decodeURIComponent(parts.pop().split(';').shift()));
				} catch (e) {
					return null;
				}
			}

			return null;
		}

		/**
		 * Set Consent Cookie
		 *
		 * @param {object} consent Consent object
		 */
		setConsent(consent) {
			const expires = new Date(Date.now() + this.cookieExpiry);
			const cookieValue = encodeURIComponent(JSON.stringify(consent));

			document.cookie = `${this.cookieName}=${cookieValue}; expires=${expires.toUTCString()}; path=/; samesite=Lax${this.isSecure() ? '; secure' : ''}`;
		}

		/**
		 * Check if Connection is Secure
		 *
		 * @return {boolean}
		 */
		isSecure() {
			return window.location.protocol === 'https:';
		}
	}

	/**
	 * Initialize on Document Ready
	 */
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', () => {
			new CookieConsentManager();
		});
	} else {
		new CookieConsentManager();
	}

	/**
	 * Public API for Theme Features
	 */
	window.ThemeFlexCookies = {
		/**
		 * Check if User Consented to Category
		 *
		 * @param {string} category Cookie category
		 * @return {boolean}
		 */
		hasConsent(category) {
			if (window.cookieManager && window.cookieManager instanceof CookieConsentManager) {
				const consent = window.cookieManager.getConsent();
				return consent && consent[category] === true;
			}
			return false;
		},

		/**
		 * Get All Consent Preferences
		 *
		 * @return {object|null}
		 */
		getConsent() {
			if (window.cookieManager && window.cookieManager instanceof CookieConsentManager) {
				return window.cookieManager.getConsent();
			}
			return null;
		},

		/**
		 * Show Cookie Banner
		 */
		showBanner() {
			const banner = document.getElementById('sf-cookie-consent');
			if (banner) {
				banner.style.display = 'block';
			}
		},

		/**
		 * Show Cookie Settings Modal
		 */
		showSettings() {
			if (window.cookieManager && window.cookieManager instanceof CookieConsentManager) {
				window.cookieManager.showModal();
			}
		}
	};

	// Store manager instance globally for easy access
	window.cookieManager = new CookieConsentManager();
})();
