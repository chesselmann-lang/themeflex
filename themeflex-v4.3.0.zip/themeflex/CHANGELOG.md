# ThemeFlex Changelog

All notable changes to ThemeFlex are documented here.

---

## [4.0.0] — 2026-05-01

### Added — AI Site Chat (Sprints 01–04)
- **Multi-provider AI engine** — supports Anthropic Claude, OpenAI GPT-4o, Google Gemini via unified `ThemeFlex_Provider_Factory` interface
- **RAG (Retrieval-Augmented Generation)** — TF-IDF indexer builds a JSON vector store from site content; chat answers are grounded in the site's own pages/posts
- **Frontend chat widget** — floating bubble with consent gate; consent state read from `themeflex_consent` cookie
- **Admin AI panel** — token usage log, indexer status, manual re-index button, API key settings with live validation
- **AJAX endpoint** — `wp_ajax_tf_chat` + `wp_ajax_nopriv_tf_chat` with rate limiting and nonce protection

### Added — Industry Setup Wizard + Demo Importer (Sprints 05–06)
- **Setup Wizard** (`ThemeFlex_Demo_Wizard`) — 3-step admin UI: industry keyword → template selection → one-click import
- **Industry mapping** — `inc/demo-importer/mapping.json` covers 19 industries, 114 templates with `schema_type`, `recommended_skin`, keyword lists
- **AI + offline matching** — fuzzy industry detection via AI provider (if key set), fallback to substring keyword matching
- **One-Click Demo Importer** (`ThemeFlex_Wizard_Importer`) — creates WP pages as drafts, applies skin, stores Schema.org type, sets front page
- **Placeholder content** — 19 × `default.json` files with industry-specific heading/body/FAQ content; 3-level resolution chain
- **Content depth selector** — headlines only / short / full (H2s + body + FAQ DL)
- **Admin notice** on activation linking to wizard, with AJAX dismiss

### Added — DSGVO Stack (Sprints 07–09)

#### Cookie Consent
- **AI cookie category** added to cookie banner — "AI Functions" with DSGVO-compliant description
- **`themeflex_consent` cookie** — comma-separated accepted categories, non-httponly (JS-readable by chat widget), 1-year expiry
- **Bridges** existing `themeflex_cookie_consent` JSON cookie to new comma-separated format

#### Font Self-Hosting
- `ThemeFlex_Font_Local_Host` — intercepts `style_loader_tag` filter to rewrite Google Fonts `<link>` tags to local URLs
- Automatic WOFF2 download on first request or when skin/typography changes
- Removes `fonts.googleapis.com` and `fonts.gstatic.com` from `<link rel="preconnect">` hints
- Font map stored in `themeflex_local_font_map` wp_option; admin button for manual re-download

#### Legal Wizard
- `ThemeFlex_Legal_Wizard` — saves 21 legal fields to `themeflex_legal_data` wp_option
- 4 jurisdiction templates: **DE** (§5 TMG Impressum + DSGVO Datenschutzerklärung), **AT** (§§5,24,25 MedienG), **CH** (simpler Swiss format), **EN** (full English privacy policy)
- Shortcodes: `[themeflex_impressum]` and `[themeflex_datenschutz]`
- Conditional AI section in privacy policy when AI provider is configured
- Conditional analytics section when analytics tool is set

#### AVV PDF Generator
- `ThemeFlex_AVV_Generator` — generates a DSGVO Art. 28 DPA (Auftragsverarbeitungsvertrag) as a downloadable PDF
- 11 contract sections: parties, subject & duration, instructions, confidentiality, TOM (Art. 32), sub-processors, data subject rights, breach notification, deletion, audit rights, final clauses, signature blocks
- Pre-fills controller data from Legal Wizard
- Bundled **FPDF 1.86** — no Composer dependency
- UTF-8 → ISO-8859-1 conversion for FPDF compatibility
- Download filename: `AVV-{processor}-{date}.pdf`

#### Form Security
- **Math captcha** added to all theme forms — randomised addition/subtraction, answer stored in single-use WP transient (30 min TTL), validated server-side before submission is processed
- Captcha field is ARIA-accessible with `aria-required`, `inputmode="numeric"`, descriptive `aria-label`

### Changed
- `functions.php` — new classes loaded via `file_exists()` guards (no fatal errors if file missing)
- `style.css` — Version bumped to 4.0.0, description updated
- `README.txt` — Version 4.0.0, all new features listed, changelog entry added

### Technical
- PHP 8.0+ required (null-safe operators, typed properties, `match` expressions)
- All AJAX handlers: nonce verification + `current_user_can()` (nopriv handlers exempt from capability check by design)
- All form inputs: `sanitize_text_field()` / `sanitize_textarea_field()` + `wp_unslash()`
- FPDF output uses `'D'` mode (force download) — no inline PDF display

---

## [3.2.0] — 2026-05-01

- 114 premium page templates (complete specialist niche coverage)
- 90+ new templates across all SMB categories
- All templates pass: brace balance, duplicate Template Name, get_footer(), DOCTYPE deduplication audits
- Live site audit: 0 PHP errors across all 8 published pages

## [3.1.0] — 2026-03-01

- 24 templates
- Portfolio CPT
- WooCommerce overrides
- Reading progress bar
- Social share buttons

## [3.0.0] — 2026-02-01

- 15 templates (hospitality, legal, fitness, creative, tech, education)
- Dark-first design system
- 8 colour skins
- 7 Google Fonts pairings
- WCAG 2.1 AA compliance

## [2.8.0] — 2026-01-15

- 9 templates
- Section library: hero, blog, portfolio, process, stats, pricing, FAQ, shape dividers

## [2.7.0] — 2026-01-01

- 6 templates
- Video background hero
- Lucide Icons 500+

## [2.5.0] — 2025-12-15

- 3 templates (agency, saas-v2, services)
- Typography system

## [1.0.0] — 2025-12-01

- Initial release
