<?php
/**
 * ThemeFlex Theme Customizer
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register theme customizer options
 *
 * @param WP_Customize_Manager $wp_customize The Customizer object.
 * @since 1.0.0
 */
function themeflex_customize_register( $wp_customize ) {
	// Default transport for postMessage
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial(
			'blogname',
			array(
				'selector'        => '.site-title a',
				'render_callback' => function() {
					echo esc_html( get_bloginfo( 'name' ) );
				},
			)
		);
		$wp_customize->selective_refresh->add_partial(
			'blogdescription',
			array(
				'selector'        => '.site-description',
				'render_callback' => function() {
					echo esc_html( get_bloginfo( 'description' ) );
				},
			)
		);
	}

	// ===== COLOR SCHEME PANEL =====
	$wp_customize->add_panel(
		'themeflex_colors',
		array(
			'title'       => esc_html__( 'Color Scheme', 'themeflex' ),
			'description' => esc_html__( 'Customize colors for your website', 'themeflex' ),
			'priority'    => 30,
		)
	);

	// Primary Color
	$wp_customize->add_setting(
		'themeflex_color_primary',
		array(
			'default'           => '#FF5E2E',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'themeflex_color_primary',
			array(
				'label'   => esc_html__( 'Primary Color', 'themeflex' ),
				'section' => 'colors',
				'priority' => 10,
			)
		)
	);

	// Secondary Color
	$wp_customize->add_setting(
		'themeflex_color_secondary',
		array(
			'default'           => '#1F242E',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'themeflex_color_secondary',
			array(
				'label'   => esc_html__( 'Secondary Color', 'themeflex' ),
				'section' => 'colors',
				'priority' => 20,
			)
		)
	);

	// Accent Color
	$wp_customize->add_setting(
		'themeflex_color_accent',
		array(
			'default'           => '#ED4C1C',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'themeflex_color_accent',
			array(
				'label'   => esc_html__( 'Accent Color', 'themeflex' ),
				'section' => 'colors',
				'priority' => 30,
			)
		)
	);

	// Background Color
	$wp_customize->add_setting(
		'themeflex_color_background',
		array(
			'default'           => '#FFFFFF',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'themeflex_color_background',
			array(
				'label'   => esc_html__( 'Background Color', 'themeflex' ),
				'section' => 'colors',
				'priority' => 40,
			)
		)
	);

	// Text Color
	$wp_customize->add_setting(
		'themeflex_color_text',
		array(
			'default'           => '#86898C',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'themeflex_color_text',
			array(
				'label'   => esc_html__( 'Text Color', 'themeflex' ),
				'section' => 'colors',
				'priority' => 50,
			)
		)
	);

	// ===== TYPOGRAPHY PANEL =====
	$wp_customize->add_panel(
		'themeflex_typography',
		array(
			'title'       => esc_html__( 'Typography', 'themeflex' ),
			'description' => esc_html__( 'Configure fonts and typography settings', 'themeflex' ),
			'priority'    => 40,
		)
	);

	// Headings Font Section
	$wp_customize->add_section(
		'themeflex_typography_headings',
		array(
			'title'       => esc_html__( 'Headings', 'themeflex' ),
			'panel'       => 'themeflex_typography',
			'priority'    => 10,
		)
	);

	// Headings Font
	$wp_customize->add_setting(
		'themeflex_font_headings',
		array(
			'default'           => 'Inter Tight',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		'themeflex_font_headings',
		array(
			'type'            => 'select',
			'label'           => esc_html__( 'Headings Font', 'themeflex' ),
			'section'         => 'themeflex_typography_headings',
			'choices'         => themeflex_get_google_fonts(),
			'priority'        => 10,
		)
	);

	// H1 Font Size
	$wp_customize->add_setting(
		'themeflex_h1_size',
		array(
			'default'           => '57',
			'sanitize_callback' => 'absint',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		'themeflex_h1_size',
		array(
			'type'              => 'number',
			'label'             => esc_html__( 'H1 Size (px)', 'themeflex' ),
			'section'           => 'themeflex_typography_headings',
			'input_attrs'       => array(
				'min'  => 24,
				'max'  => 120,
				'step' => 1,
			),
			'priority'          => 20,
		)
	);

	// H2 Font Size
	$wp_customize->add_setting(
		'themeflex_h2_size',
		array(
			'default'           => '47',
			'sanitize_callback' => 'absint',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		'themeflex_h2_size',
		array(
			'type'              => 'number',
			'label'             => esc_html__( 'H2 Size (px)', 'themeflex' ),
			'section'           => 'themeflex_typography_headings',
			'input_attrs'       => array(
				'min'  => 24,
				'max'  => 120,
				'step' => 1,
			),
			'priority'          => 30,
		)
	);

	// H3 Font Size
	$wp_customize->add_setting(
		'themeflex_h3_size',
		array(
			'default'           => '35',
			'sanitize_callback' => 'absint',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		'themeflex_h3_size',
		array(
			'type'              => 'number',
			'label'             => esc_html__( 'H3 Size (px)', 'themeflex' ),
			'section'           => 'themeflex_typography_headings',
			'input_attrs'       => array(
				'min'  => 20,
				'max'  => 100,
				'step' => 1,
			),
			'priority'          => 40,
		)
	);

	// Body Font Section
	$wp_customize->add_section(
		'themeflex_typography_body',
		array(
			'title'       => esc_html__( 'Body Text', 'themeflex' ),
			'panel'       => 'themeflex_typography',
			'priority'    => 20,
		)
	);

	// Body Font
	$wp_customize->add_setting(
		'themeflex_font_body',
		array(
			'default'           => 'Inter',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		'themeflex_font_body',
		array(
			'type'            => 'select',
			'label'           => esc_html__( 'Body Font', 'themeflex' ),
			'section'         => 'themeflex_typography_body',
			'choices'         => themeflex_get_google_fonts(),
			'priority'        => 10,
		)
	);

	// Body Font Size
	$wp_customize->add_setting(
		'themeflex_body_size',
		array(
			'default'           => '16',
			'sanitize_callback' => 'absint',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		'themeflex_body_size',
		array(
			'type'              => 'number',
			'label'             => esc_html__( 'Body Font Size (px)', 'themeflex' ),
			'section'           => 'themeflex_typography_body',
			'input_attrs'       => array(
				'min'  => 12,
				'max'  => 24,
				'step' => 1,
			),
			'priority'          => 20,
		)
	);

	// ===== HEADER OPTIONS PANEL =====
	$wp_customize->add_panel(
		'themeflex_header',
		array(
			'title'       => esc_html__( 'Header Options', 'themeflex' ),
			'description' => esc_html__( 'Customize header layout and settings', 'themeflex' ),
			'priority'    => 50,
		)
	);

	// Header Layout
	$wp_customize->add_setting(
		'themeflex_header_layout',
		array(
			'default'           => 'standard',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		'themeflex_header_layout',
		array(
			'type'            => 'select',
			'label'           => esc_html__( 'Header Layout', 'themeflex' ),
			'section'         => 'header_image',
			'choices'         => array(
				'standard'     => esc_html__( 'Standard', 'themeflex' ),
				'centered'     => esc_html__( 'Centered', 'themeflex' ),
				'transparent'  => esc_html__( 'Transparent', 'themeflex' ),
			),
			'priority'        => 10,
		)
	);

	// Sticky Header
	$wp_customize->add_setting(
		'themeflex_sticky_header',
		array(
			'default'           => true,
			'sanitize_callback' => 'rest_sanitize_boolean',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		'themeflex_sticky_header',
		array(
			'type'            => 'checkbox',
			'label'           => esc_html__( 'Enable Sticky Header', 'themeflex' ),
			'section'         => 'header_image',
			'priority'        => 20,
		)
	);

	// Header Height
	$wp_customize->add_setting(
		'themeflex_header_height',
		array(
			'default'           => '80',
			'sanitize_callback' => 'absint',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		'themeflex_header_height',
		array(
			'type'              => 'number',
			'label'             => esc_html__( 'Header Height (px)', 'themeflex' ),
			'section'           => 'header_image',
			'input_attrs'       => array(
				'min'  => 50,
				'max'  => 200,
				'step' => 5,
			),
			'priority'          => 30,
		)
	);

	// ===== FOOTER OPTIONS PANEL =====
	$wp_customize->add_panel(
		'themeflex_footer',
		array(
			'title'       => esc_html__( 'Footer Options', 'themeflex' ),
			'description' => esc_html__( 'Customize footer settings', 'themeflex' ),
			'priority'    => 60,
		)
	);

	// Footer Columns
	$wp_customize->add_setting(
		'themeflex_footer_columns',
		array(
			'default'           => '4',
			'sanitize_callback' => 'absint',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		'themeflex_footer_columns',
		array(
			'type'            => 'select',
			'label'           => esc_html__( 'Footer Columns', 'themeflex' ),
			'section'         => 'footer_image',
			'choices'         => array(
				'1' => esc_html__( '1 Column', 'themeflex' ),
				'2' => esc_html__( '2 Columns', 'themeflex' ),
				'3' => esc_html__( '3 Columns', 'themeflex' ),
				'4' => esc_html__( '4 Columns', 'themeflex' ),
			),
			'priority'        => 10,
		)
	);

	// Copyright Text
	$wp_customize->add_setting(
		'themeflex_copyright_text',
		array(
			'default'           => sprintf( esc_html__( 'Copyright %s %s. All rights reserved.', 'themeflex' ), '&copy;', get_bloginfo( 'name' ) ),
			'sanitize_callback' => 'wp_kses_post',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		'themeflex_copyright_text',
		array(
			'type'            => 'textarea',
			'label'           => esc_html__( 'Copyright Text', 'themeflex' ),
			'section'         => 'footer_image',
			'priority'        => 20,
		)
	);

	// ===== BLOG OPTIONS PANEL =====
	$wp_customize->add_panel(
		'themeflex_blog',
		array(
			'title'       => esc_html__( 'Blog Options', 'themeflex' ),
			'description' => esc_html__( 'Customize blog and archive layout', 'themeflex' ),
			'priority'    => 70,
		)
	);

	// Blog Layout
	$wp_customize->add_setting(
		'themeflex_blog_layout',
		array(
			'default'           => 'grid',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		'themeflex_blog_layout',
		array(
			'type'            => 'select',
			'label'           => esc_html__( 'Blog Layout', 'themeflex' ),
			'section'         => 'blog_image',
			'choices'         => array(
				'grid' => esc_html__( 'Grid', 'themeflex' ),
				'list' => esc_html__( 'List', 'themeflex' ),
			),
			'priority'        => 10,
		)
	);

	// Excerpt Length
	$wp_customize->add_setting(
		'themeflex_excerpt_length',
		array(
			'default'           => '20',
			'sanitize_callback' => 'absint',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		'themeflex_excerpt_length',
		array(
			'type'              => 'number',
			'label'             => esc_html__( 'Excerpt Length (words)', 'themeflex' ),
			'section'           => 'blog_image',
			'input_attrs'       => array(
				'min'  => 5,
				'max'  => 100,
				'step' => 5,
			),
			'priority'          => 20,
		)
	);

	// Pagination Style
	$wp_customize->add_setting(
		'themeflex_pagination_style',
		array(
			'default'           => 'numbers',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		'themeflex_pagination_style',
		array(
			'type'            => 'select',
			'label'           => esc_html__( 'Pagination Style', 'themeflex' ),
			'section'         => 'blog_image',
			'choices'         => array(
				'numbers'  => esc_html__( 'Numbers', 'themeflex' ),
				'previous' => esc_html__( 'Previous/Next', 'themeflex' ),
				'infinite' => esc_html__( 'Infinite Scroll', 'themeflex' ),
			),
			'priority'        => 30,
		)
	);

	// ===== DARK MODE PANEL =====
	$wp_customize->add_panel(
		'themeflex_dark_mode',
		array(
			'title'       => esc_html__( 'Dark Mode', 'themeflex' ),
			'description' => esc_html__( 'Configure dark mode settings', 'themeflex' ),
			'priority'    => 80,
		)
	);

	// Dark Mode Setting
	$wp_customize->add_setting(
		'themeflex_dark_mode',
		array(
			'default'           => 'auto',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		'themeflex_dark_mode',
		array(
			'type'            => 'select',
			'label'           => esc_html__( 'Dark Mode', 'themeflex' ),
			'section'         => 'colors',
			'choices'         => array(
				'off'    => esc_html__( 'Off', 'themeflex' ),
				'auto'   => esc_html__( 'Auto (System Preference)', 'themeflex' ),
				'manual' => esc_html__( 'Manual (User Toggle)', 'themeflex' ),
			),
			'priority'        => 100,
		)
	);

	// Dark Mode Primary Color
	$wp_customize->add_setting(
		'themeflex_dark_color_primary',
		array(
			'default'           => '#FF5E2E',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'themeflex_dark_color_primary',
			array(
				'label'   => esc_html__( 'Dark Mode Primary Color', 'themeflex' ),
				'section' => 'colors',
				'priority' => 101,
			)
		)
	);

	// Dark Mode Background Color
	$wp_customize->add_setting(
		'themeflex_dark_color_background',
		array(
			'default'           => '#06021D',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'themeflex_dark_color_background',
			array(
				'label'   => esc_html__( 'Dark Mode Background', 'themeflex' ),
				'section' => 'colors',
				'priority' => 102,
			)
		)
	);

	// Dark Mode Text Color
	$wp_customize->add_setting(
		'themeflex_dark_color_text',
		array(
			'default'           => '#B8BCC4',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'themeflex_dark_color_text',
			array(
				'label'   => esc_html__( 'Dark Mode Text Color', 'themeflex' ),
				'section' => 'colors',
				'priority' => 103,
			)
		)
	);
}

add_action( 'customize_register', 'themeflex_customize_register' );

/**
 * Get Google Fonts list (Top 20 fonts)
 *
 * @since 1.0.0
 * @return array List of Google Fonts
 */
function themeflex_get_google_fonts() {
	return array(
		'Inter'                => 'Inter',
		'Inter Tight'          => 'Inter Tight',
		'Open Sans'            => 'Open Sans',
		'Roboto'               => 'Roboto',
		'Poppins'              => 'Poppins',
		'Montserrat'           => 'Montserrat',
		'Lato'                 => 'Lato',
		'Source Sans Pro'      => 'Source Sans Pro',
		'Raleway'              => 'Raleway',
		'Playfair Display'     => 'Playfair Display',
		'Dosis'                => 'Dosis',
		'Quicksand'            => 'Quicksand',
		'Merriweather'         => 'Merriweather',
		'Ubuntu'               => 'Ubuntu',
		'Nunito'               => 'Nunito',
		'PT Sans'              => 'PT Sans',
		'Titillium Web'        => 'Titillium Web',
		'Cabin'                => 'Cabin',
		'Oswald'               => 'Oswald',
		'Mulish'               => 'Mulish',
	);
}

/**
 * Output CSS custom properties in the head
 *
 * @since 1.0.0
 */
function themeflex_custom_css_variables() {
	// Get Customizer values
	$primary_color       = get_theme_mod( 'themeflex_color_primary', '#FF5E2E' );
	$secondary_color     = get_theme_mod( 'themeflex_color_secondary', '#1F242E' );
	$accent_color        = get_theme_mod( 'themeflex_color_accent', '#ED4C1C' );
	$background_color    = get_theme_mod( 'themeflex_color_background', '#FFFFFF' );
	$text_color          = get_theme_mod( 'themeflex_color_text', '#86898C' );
	$font_headings       = get_theme_mod( 'themeflex_font_headings', 'Inter Tight' );
	$font_body           = get_theme_mod( 'themeflex_font_body', 'Inter' );
	$h1_size             = get_theme_mod( 'themeflex_h1_size', '57' );
	$h2_size             = get_theme_mod( 'themeflex_h2_size', '47' );
	$h3_size             = get_theme_mod( 'themeflex_h3_size', '35' );
	$body_size           = get_theme_mod( 'themeflex_body_size', '16' );
	$header_height       = get_theme_mod( 'themeflex_header_height', '80' );
	$footer_columns      = get_theme_mod( 'themeflex_footer_columns', '4' );
	$dark_mode           = get_theme_mod( 'themeflex_dark_mode', 'auto' );
	$dark_primary_color  = get_theme_mod( 'themeflex_dark_color_primary', '#FF5E2E' );
	$dark_bg_color       = get_theme_mod( 'themeflex_dark_color_background', '#06021D' );
	$dark_text_color     = get_theme_mod( 'themeflex_dark_color_text', '#B8BCC4' );

	// Build CSS variables
	$css = ':root {';
	$css .= '--sf-color-primary: ' . sanitize_hex_color( $primary_color ) . ';';
	$css .= '--sf-color-secondary: ' . sanitize_hex_color( $secondary_color ) . ';';
	$css .= '--sf-color-accent: ' . sanitize_hex_color( $accent_color ) . ';';
	$css .= '--sf-color-bg: ' . sanitize_hex_color( $background_color ) . ';';
	$css .= '--sf-color-text: ' . sanitize_hex_color( $text_color ) . ';';
	$css .= '--sf-font-headings: ' . esc_attr( $font_headings ) . ', -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;';
	$css .= '--sf-font-body: ' . esc_attr( $font_body ) . ', -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;';
	$css .= '--sf-font-size-h1: ' . intval( $h1_size ) . 'px;';
	$css .= '--sf-font-size-h2: ' . intval( $h2_size ) . 'px;';
	$css .= '--sf-font-size-h3: ' . intval( $h3_size ) . 'px;';
	$css .= '--sf-font-size-body: ' . intval( $body_size ) . 'px;';
	$css .= '--sf-header-height: ' . intval( $header_height ) . 'px;';
	$css .= '--sf-footer-columns: ' . intval( $footer_columns ) . ';';
	$css .= '}';

	// Dark mode CSS variables — full 16-token semantic override
	if ( 'off' !== $dark_mode ) {
		$dark_selector = 'auto' === $dark_mode ? '@media (prefers-color-scheme: dark)' : '[data-theme="dark"]';
		$css          .= $dark_selector . ' { :root {';
		// Brand colour
		$css          .= '--sf-color-primary:       ' . sanitize_hex_color( $dark_primary_color ) . ';';
		$css          .= '--sf-color-primary-light: #ff8a60;';
		// Main surface tokens (content areas → dark)
		$css          .= '--sf-bg:        ' . sanitize_hex_color( $dark_bg_color ) . ';';
		$css          .= '--sf-bg-2:      #1a1f29;';
		$css          .= '--sf-border:    #3c3f47;';
		$css          .= '--sf-title:     #fffefe;';
		$css          .= '--sf-text:      ' . sanitize_hex_color( $dark_text_color ) . ';';
		$css          .= '--sf-meta:      #8892a4;';
		$css          .= '--sf-link:      ' . sanitize_hex_color( $dark_primary_color ) . ';';
		$css          .= '--sf-hover:     #ff8a60;';
		// Alt surface tokens (hero / CTA / footer sections → deeper dark)
		$css          .= '--sf-alt-bg:     #0d1117;';
		$css          .= '--sf-alt-bg-2:   #1a1f29;';
		$css          .= '--sf-alt-border: #2a2f3a;';
		$css          .= '--sf-alt-title:  #fffefe;';
		$css          .= '--sf-alt-text:   #b8bcc4;';
		$css          .= '--sf-alt-meta:   #6b7280;';
		$css          .= '--sf-alt-link:   ' . sanitize_hex_color( $dark_primary_color ) . ';';
		$css          .= '--sf-alt-hover:  #ff8a60;';
		// Legacy aliases
		$css          .= '--sf-color-bg:     ' . sanitize_hex_color( $dark_bg_color ) . ';';
		$css          .= '--sf-color-text:   ' . sanitize_hex_color( $dark_text_color ) . ';';
		$css          .= '--sf-color-title:  #fffefe;';
		$css          .= '--sf-color-border: #3c3f47;';
		$css          .= '}}';
		// Always-available [data-theme] selectors (for JS toggle, regardless of mode setting)
		$css          .= '[data-theme="light"] :root {';
		$css          .= '--sf-bg: #ffffff; --sf-bg-2: #f6f7f1; --sf-border: #e5e7de;';
		$css          .= '--sf-title: #1f242e; --sf-text: #86898c; --sf-meta: #acafb2;';
		$css          .= '--sf-link: var(--sf-color-primary); --sf-hover: var(--sf-color-primary-dark);';
		$css          .= '--sf-alt-bg: #06021d; --sf-alt-bg-2: #1a1f29; --sf-alt-border: #3c3f47;';
		$css          .= '--sf-alt-title: #fffefe; --sf-alt-text: #b8bcc4; --sf-alt-meta: #6b7280;';
		$css          .= '--sf-color-bg: #ffffff; --sf-color-text: #86898c; --sf-color-title: #1f242e;';
		$css          .= '}';
	}

	echo '<style id="themeflex-css-variables" type="text/css">' . wp_kses_post( $css ) . '</style>' . "\n";
}

add_action( 'wp_head', 'themeflex_custom_css_variables', 1 );

/**
 * Enqueue Customizer preview script
 *
 * @since 1.0.0
 */
function themeflex_customize_preview_js() {
	wp_enqueue_script(
		'themeflex-customizer-preview',
		THEMEFLEX_URL . '/assets/js/customizer-preview.js',
		array( 'customize-preview', 'jquery' ),
		THEMEFLEX_VERSION,
		true
	);

	wp_localize_script(
		'themeflex-customizer-preview',
		'themeFlexPreview',
		array(
			'googleFontsUrl' => 'https://fonts.googleapis.com/css2',
			'fonts'          => themeflex_get_google_fonts(),
		)
	);
}

add_action( 'customize_preview_init', 'themeflex_customize_preview_js' );

/**
 * Enqueue Customizer controls script
 *
 * @since 1.0.0
 */
function themeflex_customize_controls_js() {
	wp_enqueue_script(
		'themeflex-customizer',
		THEMEFLEX_URL . '/assets/js/customizer.js',
		array( 'customize-controls', 'jquery' ),
		THEMEFLEX_VERSION,
		true
	);

	wp_localize_script(
		'themeflex-customizer',
		'themeFlexCustomizer',
		array(
			'fonts' => themeflex_get_google_fonts(),
		)
	);
}

add_action( 'customize_controls_enqueue_scripts', 'themeflex_customize_controls_js' );
