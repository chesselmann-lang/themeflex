<?php
/**
 * 404 Error Page — ThemeFlex v1.0
 *
 * Custom 404 with animated glitch number, search field, and quick links.
 * Dark-first, self-contained styling.
 *
 * @package ThemeFlex
 * @since   2.3.0
 */

get_header(); ?>

<main id="tf-404" class="tf-404-page" aria-label="<?php esc_attr_e( '404 Page not found', 'themeflex' ); ?>">
<style>
/* ══════════════════════════════════════════════════════════
   404 PAGE — Glitch + Search
   ══════════════════════════════════════════════════════════ */
.tf-404-page {
  min-height: 85vh;
  background: #06021d;
  display: flex; align-items: center; justify-content: center;
  padding: 80px 24px;
  position: relative; overflow: hidden;
}
/* Dot grid */
.tf-404-page::before {
  content: '';
  position: absolute; inset: 0;
  background-image: radial-gradient(rgba(255,255,255,.025) 1px, transparent 1px);
  background-size: 44px 44px;
  pointer-events: none;
}
/* Glow */
.tf-404-glow {
  position: absolute; top: 0; left: 50%; transform: translateX(-50%);
  width: 700px; height: 700px;
  background: radial-gradient(circle, rgba(255,94,46,.06) 0%, transparent 65%);
  pointer-events: none;
}

.tf-404-inner {
  position: relative; z-index: 2;
  text-align: center;
  max-width: 680px; margin: 0 auto;
}

/* ── Big 404 number ── */
.tf-404-num {
  font-family: 'Inter Tight', sans-serif;
  font-size: clamp(8rem, 20vw, 16rem);
  font-weight: 900;
  line-height: .9;
  letter-spacing: -.06em;
  color: transparent;
  background: linear-gradient(135deg, rgba(255,255,255,.08) 0%, rgba(255,255,255,.03) 100%);
  -webkit-background-clip: text;
  background-clip: text;
  position: relative;
  margin-bottom: 8px;
  animation: tf404Glitch 6s ease-in-out infinite;
  user-select: none;
}
/* Glitch layers */
.tf-404-num::before,
.tf-404-num::after {
  content: '404';
  position: absolute; left: 0; right: 0; top: 0;
  font-family: 'Inter Tight', sans-serif;
  font-weight: 900; letter-spacing: -.06em; line-height: .9;
}
.tf-404-num::before {
  color: rgba(255,94,46,.35);
  animation: tf404GlitchA 6s ease-in-out infinite;
  clip-path: polygon(0 15%, 100% 15%, 100% 40%, 0 40%);
}
.tf-404-num::after {
  color: rgba(0,212,255,.25);
  animation: tf404GlitchB 6s ease-in-out infinite;
  clip-path: polygon(0 60%, 100% 60%, 100% 80%, 0 80%);
}

@keyframes tf404Glitch {
  0%,94%,100% { transform: none; }
  95%          { transform: skewX(2deg); }
  97%          { transform: skewX(-3deg); }
}
@keyframes tf404GlitchA {
  0%,94%,100% { transform: none; }
  95%          { transform: translate(-4px, 2px); }
  97%          { transform: translate(4px, -2px); }
}
@keyframes tf404GlitchB {
  0%,94%,100% { transform: none; }
  95%          { transform: translate(3px, -1px); }
  97%          { transform: translate(-3px, 1px); }
}

.tf-404-eyebrow {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.25);
  color: #ff7a54; font-size: .68rem; font-weight: 800; letter-spacing: .14em;
  text-transform: uppercase; padding: 5px 16px; border-radius: 100px;
  margin-bottom: 20px;
}

.tf-404-title {
  font-family: 'Inter Tight', sans-serif;
  font-size: clamp(1.6rem, 3vw, 2.4rem);
  font-weight: 900; color: #f1f5f9;
  letter-spacing: -.04em; line-height: 1.15;
  margin: 0 0 14px;
}
.tf-404-sub {
  color: #64748b; font-size: 1rem; line-height: 1.7;
  max-width: 480px; margin: 0 auto 40px;
}

/* ── Search form ── */
.tf-404-search {
  display: flex; gap: 0;
  max-width: 440px; margin: 0 auto 40px;
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(255,255,255,.1);
  border-radius: 100px;
  overflow: hidden;
  transition: border-color .2s, box-shadow .2s;
}
.tf-404-search:focus-within {
  border-color: rgba(255,94,46,.4);
  box-shadow: 0 0 0 4px rgba(255,94,46,.1);
}
.tf-404-search-input {
  flex: 1; background: none; border: none; outline: none;
  color: #e2e8f0; font-size: .9rem; padding: 14px 20px;
}
.tf-404-search-input::placeholder { color: #475569; }
.tf-404-search-btn {
  background: #ff5e2e; border: none; cursor: pointer;
  color: #fff; padding: 12px 24px; font-size: .88rem; font-weight: 700;
  border-radius: 0 100px 100px 0;
  transition: background .2s;
}
.tf-404-search-btn:hover { background: #e04e22; }

/* ── Quick links ── */
.tf-404-links-label {
  font-size: .72rem; font-weight: 700; color: #475569;
  letter-spacing: .1em; text-transform: uppercase; margin-bottom: 16px;
}
.tf-404-links {
  display: flex; flex-wrap: wrap; justify-content: center; gap: 10px;
  margin-bottom: 40px;
}
.tf-404-link {
  display: inline-flex; align-items: center; gap: 6px;
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(255,255,255,.08);
  color: #94a3b8; font-size: .85rem; font-weight: 600;
  padding: 9px 18px; border-radius: 100px;
  text-decoration: none;
  transition: background .2s, border-color .2s, color .2s;
}
.tf-404-link:hover { background: rgba(255,94,46,.08); border-color: rgba(255,94,46,.3); color: #ff5e2e; }

/* ── Home button ── */
.tf-404-home {
  display: inline-flex; align-items: center; gap: 10px;
  background: #ff5e2e; color: #fff;
  font-size: .9rem; font-weight: 800; letter-spacing: .02em;
  padding: 14px 32px; border-radius: 100px;
  text-decoration: none;
  box-shadow: 0 8px 24px rgba(255,94,46,.3);
  transition: transform .2s, box-shadow .2s;
}
.tf-404-home:hover { transform: translateY(-2px); box-shadow: 0 14px 36px rgba(255,94,46,.4); }
</style>

<div class="tf-404-glow" aria-hidden="true"></div>

<div class="tf-404-inner">
  <div class="tf-404-num" aria-hidden="true">404</div>

  <div class="tf-404-eyebrow"><?php esc_html_e( 'Page Not Found', 'themeflex' ); ?></div>
  <h1 class="tf-404-title"><?php esc_html_e( "This Page Has Gone Into the Void", 'themeflex' ); ?></h1>
  <p class="tf-404-sub"><?php esc_html_e( "The page you're looking for doesn't exist or has been moved. Let's get you back on track.", 'themeflex' ); ?></p>

  <!-- Search -->
  <form class="tf-404-search" role="search" method="get" action="<?php echo esc_url( home_url('/') ); ?>">
    <label for="tf-404-q" class="screen-reader-text"><?php esc_html_e( 'Search', 'themeflex' ); ?></label>
    <input
      id="tf-404-q"
      class="tf-404-search-input"
      type="search"
      name="s"
      value="<?php echo esc_attr( get_search_query() ); ?>"
      placeholder="<?php esc_attr_e( 'Search for something…', 'themeflex' ); ?>"
      autocomplete="off"
    >
    <button type="submit" class="tf-404-search-btn">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
    </button>
  </form>

  <!-- Quick links -->
  <div class="tf-404-links-label"><?php esc_html_e( 'Or go to', 'themeflex' ); ?></div>
  <div class="tf-404-links">
    <a class="tf-404-link" href="<?php echo esc_url( home_url('/') ); ?>"><?php esc_html_e( 'Homepage', 'themeflex' ); ?></a>
    <a class="tf-404-link" href="<?php echo esc_url( home_url('/portfolio/') ); ?>"><?php esc_html_e( 'Portfolio', 'themeflex' ); ?></a>
    <a class="tf-404-link" href="<?php echo esc_url( home_url('/blog/') ); ?>"><?php esc_html_e( 'Blog', 'themeflex' ); ?></a>
    <a class="tf-404-link" href="<?php echo esc_url( home_url('/contact/') ); ?>"><?php esc_html_e( 'Contact', 'themeflex' ); ?></a>
    <a class="tf-404-link" href="<?php echo esc_url( home_url('/pricing/') ); ?>"><?php esc_html_e( 'Pricing', 'themeflex' ); ?></a>
  </div>

  <a class="tf-404-home" href="<?php echo esc_url( home_url('/') ); ?>">
    ← <?php esc_html_e( 'Back to Home', 'themeflex' ); ?>
  </a>
</div>

</main>

<?php get_footer(); ?>
