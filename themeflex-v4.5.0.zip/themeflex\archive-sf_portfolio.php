<?php
/**
 * Archive template for the sf_portfolio custom post type.
 *
 * WordPress will use this automatically when visiting /portfolio/ if the CPT
 * is registered with has_archive => true.
 * It delegates directly to the page-portfolio template so the layout and
 * styles stay in one place.
 *
 * @package ThemeFlex
 * @since 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/*
 * Simply include the portfolio page template.
 * We reset the main query first so the page template's own WP_Query
 * fetches portfolio items correctly.
 */
wp_reset_query();
include locate_template( 'page-portfolio.php' );
