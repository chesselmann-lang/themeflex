<?php
/**
 * Archive Template — ThemeFlex
 * Category, tag, date, and author archive pages.
 * Dark-first, self-contained.
 *
 * @package ThemeFlex
 * @since 1.3.0
 */
get_header(); ?>
<main id="primary" class="site-main tf-archive-main">
<style>
/* ── Variables ─────────────────────────────────────────────────────── */
.tf-archive-main{
  padding:80px 0 110px;
  --tc:#ff5e2e;
  --bg:#06021d;--bg2:#0d1526;--bg3:#111827;
  --border:rgba(255,255,255,.07);
  --title:#f1f5f9;--txt:#94a3b8;--meta:#64748b;
  background:var(--bg);
}
/* ── Archive Header ─────────────────────────────────────────────────── */
.tf-archive-header{text-align:center;margin-bottom:56px}
.tf-archive-breadcrumb{font-size:.78rem;color:var(--meta);margin-bottom:16px}
.tf-archive-breadcrumb a{color:var(--tc);text-decoration:none}
.tf-archive-label{display:inline-flex;align-items:center;gap:8px;background:rgba(255,94,46,.1);border:1px solid rgba(255,94,46,.22);color:var(--tc);font-size:.7rem;font-weight:800;letter-spacing:.12em;text-transform:uppercase;padding:6px 18px;border-radius:100px;margin-bottom:22px}
.tf-archive-header h1{font-family:'Inter Tight',sans-serif;font-size:clamp(2rem,4.5vw,3rem);font-weight:900;color:var(--title);margin:0 0 14px;letter-spacing:-.5px;line-height:1.12}
.tf-archive-header .tf-archive-desc{color:var(--txt);font-size:1.05rem;max-width:540px;margin:0 auto}
/* ── Filter ─────────────────────────────────────────────────────────── */
.tf-arc-filters{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-bottom:48px}
.tf-arc-filter-btn{padding:7px 18px;border-radius:100px;border:1px solid var(--border);color:var(--meta);font-size:.8rem;font-weight:700;letter-spacing:.04em;text-decoration:none;transition:all .25s;background:transparent}
.tf-arc-filter-btn:hover,.tf-arc-filter-btn.active{background:var(--tc);color:#fff;border-color:var(--tc)}
/* ── Grid ───────────────────────────────────────────────────────────── */
.tf-arc-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}
/* ── Card ───────────────────────────────────────────────────────────── */
.tf-arc-card{background:var(--bg3);border:1px solid var(--border);border-radius:16px;overflow:hidden;display:flex;flex-direction:column;transition:transform .3s,box-shadow .3s,border-color .3s;position:relative}
.tf-arc-card::before{content:'';position:absolute;inset:0;border-radius:16px;background:linear-gradient(135deg,rgba(255,94,46,.08),rgba(0,212,255,.05));opacity:0;transition:opacity .3s;pointer-events:none}
.tf-arc-card:hover{transform:translateY(-6px);box-shadow:0 24px 64px rgba(0,0,0,.45);border-color:rgba(255,94,46,.3)}
.tf-arc-card:hover::before{opacity:1}
/* ── Thumb ──────────────────────────────────────────────────────────── */
.tf-arc-thumb{aspect-ratio:16/9;position:relative;overflow:hidden;background:linear-gradient(135deg,#1e293b,#0f172a);flex-shrink:0}
.tf-arc-thumb img{width:100%;height:100%;object-fit:cover;position:absolute;inset:0;transition:transform .5s ease}
.tf-arc-card:hover .tf-arc-thumb img{transform:scale(1.04)}
.tf-arc-thumb-icon{position:absolute;inset:0;display:flex;align-items:center;justify-content:center}
.tf-arc-thumb-icon svg{width:36px;height:36px;display:block}
.tf-arc-cat-badge{position:absolute;top:14px;left:14px;background:var(--tc);color:#fff;font-size:.62rem;font-weight:800;letter-spacing:.1em;text-transform:uppercase;padding:4px 11px;border-radius:100px;z-index:2;text-decoration:none;transition:background .2s}
.tf-arc-cat-badge:hover{background:#e04e22}
/* ── Body ───────────────────────────────────────────────────────────── */
.tf-arc-body{padding:22px 24px 26px;flex:1;display:flex;flex-direction:column}
.tf-arc-title{font-family:'Inter Tight',sans-serif;font-size:1.05rem;font-weight:800;color:var(--title);margin:0 0 10px;line-height:1.35}
.tf-arc-title a{color:inherit;text-decoration:none;transition:color .2s}
.tf-arc-title a:hover{color:var(--tc)}
.tf-arc-excerpt{font-size:.875rem;color:var(--meta);line-height:1.7;margin:0 0 20px;flex:1}
/* ── Meta ───────────────────────────────────────────────────────────── */
.tf-arc-meta{display:flex;align-items:center;justify-content:space-between;font-size:.75rem;color:var(--meta);margin-top:auto;padding-top:14px;border-top:1px solid var(--border)}
.tf-arc-meta-left{display:flex;align-items:center;gap:8px}
.tf-arc-meta-left img{width:24px;height:24px;border-radius:50%;object-fit:cover}
/* ── Pagination ─────────────────────────────────────────────────────── */
.tf-arc-pagination{text-align:center;margin-top:64px}
.tf-arc-pagination .page-numbers{display:inline-flex;align-items:center;justify-content:center;min-width:42px;height:42px;border-radius:10px;border:1px solid var(--border);color:var(--txt);text-decoration:none;font-size:.875rem;font-weight:600;transition:all .22s;margin:0 3px;padding:0 12px}
.tf-arc-pagination .page-numbers:hover,.tf-arc-pagination .page-numbers.current{background:var(--tc);color:#fff;border-color:var(--tc)}
/* ── Responsive ─────────────────────────────────────────────────────── */
@media(max-width:960px){.tf-arc-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:600px){.tf-arc-grid{grid-template-columns:1fr}}
</style>

<div class="container" style="max-width:1220px;margin:0 auto;padding:0 24px;">

  <!-- Archive Header -->
  <header class="tf-archive-header">
    <!-- Breadcrumb -->
    <div class="tf-archive-breadcrumb">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'themeflex' ); ?></a>
      <?php if ( is_category() ) :
        $parent_id = get_queried_object()->parent;
        if ( $parent_id ) : ?>
          <span> / </span>
          <a href="<?php echo esc_url( get_category_link( $parent_id ) ); ?>"><?php echo esc_html( get_cat_name( $parent_id ) ); ?></a>
        <?php endif; ?>
        <span> / <?php single_cat_title(); ?></span>
      <?php elseif ( is_tag() ) : ?>
        <span> / <?php esc_html_e( 'Tag', 'themeflex' ); ?>: <?php single_tag_title(); ?></span>
      <?php elseif ( is_author() ) : ?>
        <span> / <?php esc_html_e( 'Author', 'themeflex' ); ?>: <?php the_author(); ?></span>
      <?php elseif ( is_date() ) : ?>
        <span> / <?php echo esc_html( get_the_date( 'F Y' ) ); ?></span>
      <?php endif; ?>
    </div>

    <!-- Label badge -->
    <div class="tf-archive-label">
      <?php if ( is_category() )      esc_html_e( 'Category', 'themeflex' );
      elseif ( is_tag() )             esc_html_e( 'Tag', 'themeflex' );
      elseif ( is_author() )          esc_html_e( 'Author', 'themeflex' );
      elseif ( is_date() )            esc_html_e( 'Archive', 'themeflex' );
      else                            esc_html_e( 'Archive', 'themeflex' ); ?>
    </div>

    <?php the_archive_title( '<h1>', '</h1>' ); ?>
    <?php the_archive_description( '<p class="tf-archive-desc">', '</p>' ); ?>
  </header>

  <!-- Category filter tabs (only for category archives) -->
  <?php
  $all_cats = get_categories( ['hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC'] );
  if ( is_category() && count( $all_cats ) > 1 ) : ?>
  <nav class="tf-arc-filters" aria-label="<?php esc_attr_e( 'Filter by category', 'themeflex' ); ?>">
    <a href="<?php echo esc_url( get_permalink( get_option( 'page_for_posts' ) ) ); ?>" class="tf-arc-filter-btn">
      <?php esc_html_e( 'All Posts', 'themeflex' ); ?>
    </a>
    <?php foreach ( $all_cats as $fcat ) : ?>
    <a href="<?php echo esc_url( get_category_link( $fcat->term_id ) ); ?>"
       class="tf-arc-filter-btn<?php echo is_category( $fcat->term_id ) ? ' active' : ''; ?>">
      <?php echo esc_html( $fcat->name ); ?>
    </a>
    <?php endforeach; ?>
  </nav>
  <?php endif; ?>

  <!-- Category gradient + SVG icon map -->
  <?php
  /* SVG icons: all 24×24, stroke, currentColor */
  $_arc_svgs = [
    'design'      => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2z"/><path d="M22 12a10 10 0 0 1-10 10 4 4 0 0 1 0-8 4 4 0 0 0 0-8 10 10 0 0 1 10 6z"/></svg>',
    'development' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
    'tutorial'    => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>',
    'company'     => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
    'services'    => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M16.24 7.76a6 6 0 0 1 0 8.49M4.93 4.93a10 10 0 0 0 0 14.14M7.76 7.76a6 6 0 0 0 0 8.49"/></svg>',
    'seo'         => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
    'ecommerce'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>',
    'wordpress'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>',
    'marketing'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
    'tips'        => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="2" x2="12" y2="6"/><line x1="12" y1="18" x2="12" y2="22"/><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"/><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"/><line x1="2" y1="12" x2="6" y2="12"/><line x1="18" y1="12" x2="22" y2="12"/><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"/><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"/></svg>',
  ];
  $_arc_default_svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>';
  $emoji_map = [
    'design'      => ['s' => $_arc_svgs['design'],      'g' => 'linear-gradient(135deg,#2a1a1a,#1e0f0f)', 'c' => 'rgba(248,113,113,.35)'],
    'development' => ['s' => $_arc_svgs['development'], 'g' => 'linear-gradient(135deg,#0f1a2e,#091220)', 'c' => 'rgba(96,165,250,.35)'],
    'tutorial'    => ['s' => $_arc_svgs['tutorial'],    'g' => 'linear-gradient(135deg,#1e1a0f,#14120a)', 'c' => 'rgba(251,191,36,.35)'],
    'company'     => ['s' => $_arc_svgs['company'],     'g' => 'linear-gradient(135deg,#0f1e2a,#091418)', 'c' => 'rgba(52,211,153,.35)'],
    'services'    => ['s' => $_arc_svgs['services'],    'g' => 'linear-gradient(135deg,#1a1e2a,#0f1318)', 'c' => 'rgba(167,139,250,.35)'],
    'seo'         => ['s' => $_arc_svgs['seo'],         'g' => 'linear-gradient(135deg,#1a2a0f,#0f1e09)', 'c' => 'rgba(110,231,183,.35)'],
    'ecommerce'   => ['s' => $_arc_svgs['ecommerce'],   'g' => 'linear-gradient(135deg,#1a1a2e,#0f0f1e)', 'c' => 'rgba(139,92,246,.35)'],
    'wordpress'   => ['s' => $_arc_svgs['wordpress'],   'g' => 'linear-gradient(135deg,#0f1f2e,#091525)', 'c' => 'rgba(56,88,233,.35)'],
    'marketing'   => ['s' => $_arc_svgs['marketing'],   'g' => 'linear-gradient(135deg,#1a2e0f,#0e1f09)', 'c' => 'rgba(74,222,128,.35)'],
    'tips'        => ['s' => $_arc_svgs['tips'],        'g' => 'linear-gradient(135deg,#2a240f,#1a170a)', 'c' => 'rgba(251,146,60,.35)'],
  ];
  $default = ['s' => $_arc_default_svg, 'g' => 'linear-gradient(135deg,#1e293b,#0f172a)', 'c' => 'rgba(255,255,255,.2)'];
  ?>

  <?php if ( have_posts() ) : ?>
  <div class="tf-arc-grid">
    <?php while ( have_posts() ) : the_post();
      $cats  = get_the_category();
      $cat   = ! empty( $cats ) ? $cats[0] : null;
      $slug  = $cat ? strtolower( $cat->slug ) : '';
      $map   = isset( $emoji_map[ $slug ] ) ? $emoji_map[ $slug ] : $default;
      $map_s = isset( $map['s'] ) ? $map['s'] : $default['s'];
      $map_c = isset( $map['c'] ) ? $map['c'] : $default['c'];
      $words = str_word_count( strip_tags( get_the_content() ) );
      $read  = max( 1, (int) ceil( $words / 200 ) );
    ?>
    <article class="tf-arc-card" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

      <!-- Thumbnail -->
      <a href="<?php the_permalink(); ?>" class="tf-arc-thumb" style="background:<?php echo esc_attr( $map['g'] ); ?>;" aria-hidden="true" tabindex="-1">
        <?php if ( has_post_thumbnail() ) :
          the_post_thumbnail( 'medium_large' );
        else : ?>
          <span class="tf-arc-thumb-icon" style="color:<?php echo esc_attr($map_c); ?>" aria-hidden="true"><?php echo $map_s; ?></span>
        <?php endif; ?>
        <?php if ( $cat ) : ?>
          <a class="tf-arc-cat-badge" href="<?php echo esc_url( get_category_link( $cat->term_id ) ); ?>"><?php echo esc_html( $cat->name ); ?></a>
        <?php endif; ?>
      </a>

      <!-- Body -->
      <div class="tf-arc-body">
        <h2 class="tf-arc-title">
          <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h2>
        <p class="tf-arc-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt() ?: strip_tags( get_the_content() ), 22, '…' ) ); ?></p>
        <div class="tf-arc-meta">
          <div class="tf-arc-meta-left">
            <?php echo get_avatar( get_the_author_meta( 'ID' ), 24, '', '', ['style' => 'border-radius:50%;'] ); ?>
            <span><?php the_author(); ?></span>
          </div>
          <span><?php echo esc_html( get_the_date( 'M j, Y' ) ); ?> · <?php echo $read; ?> min</span>
        </div>
      </div>

    </article>
    <?php endwhile; ?>
  </div>

  <!-- Pagination -->
  <div class="tf-arc-pagination">
    <?php echo wp_kses_post( paginate_links( [
      'type'      => 'plain',
      'prev_text' => '← ' . esc_html__( 'Newer', 'themeflex' ),
      'next_text' => esc_html__( 'Older', 'themeflex' ) . ' →',
    ] ) ); ?>
  </div>

  <?php else : ?>
  <div style="text-align:center;padding:80px 0;">
    <p style="color:var(--meta,#64748b);font-size:1.05rem;"><?php esc_html_e( 'No posts found in this archive.', 'themeflex' ); ?></p>
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>"
       style="display:inline-flex;align-items:center;gap:8px;margin-top:24px;padding:12px 28px;background:#ff5e2e;color:#fff;border-radius:100px;text-decoration:none;font-weight:700;font-size:.9rem;">
      ← <?php esc_html_e( 'Back to Home', 'themeflex' ); ?>
    </a>
  </div>
  <?php endif; ?>

</div>
</main>
<?php get_footer(); ?>
