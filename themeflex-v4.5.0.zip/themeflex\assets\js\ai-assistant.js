/**
 * AI Assistant Frontend
 *
 * Provides floating AI button and content generation UI for Elementor and frontend.
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

(function() {
	'use strict';

	const AIAssistant = {
		apiUrl: window.themeFlexAI?.apiUrl || '/wp-json/themeflex/v1/ai/',
		nonce: window.themeFlexAI?.nonce || '',
		isOpen: false,
		history: [],
		maxHistory: 10,

		/**
		 * Initialize AI Assistant
		 */
		init() {
			if (!window.themeFlexAI?.enabled) {
				return;
			}

			this.createFloatingButton();
			this.createDropdownMenu();
			this.attachEventListeners();
			this.loadHistory();
			this.setupKeyboardShortcuts();
		},

		/**
		 * Create floating AI button
		 */
		createFloatingButton() {
			const button = document.createElement('button');
			button.id = 'sf-ai-assistant-button';
			button.setAttribute('aria-label', 'AI Content Assistant');
			button.title = 'AI Assistant (Ctrl+Shift+A)';
			button.innerHTML = '<span class="ai-icon">✨</span>';
			document.body.appendChild(button);
		},

		/**
		 * Create dropdown menu
		 */
		createDropdownMenu() {
			const menu = document.createElement('div');
			menu.id = 'sf-ai-assistant-menu';
			menu.className = 'ai-menu hidden';
			menu.innerHTML = `
				<div class="ai-menu-header">
					<h3>${window.themeFlexAI?.strings?.title || 'AI Assistant'}</h3>
					<button class="ai-close-btn" aria-label="Close menu">×</button>
				</div>
				<div class="ai-menu-content">
					<div class="ai-tabs">
						<button class="ai-tab-btn active" data-tab="generate">
							${window.themeFlexAI?.strings?.generate || 'Generate'}
						</button>
						<button class="ai-tab-btn" data-tab="improve">
							${window.themeFlexAI?.strings?.improve || 'Improve'}
						</button>
						<button class="ai-tab-btn" data-tab="headline">
							${window.themeFlexAI?.strings?.headline || 'Headlines'}
						</button>
						<button class="ai-tab-btn" data-tab="seo">
							${window.themeFlexAI?.strings?.seo || 'SEO Meta'}
						</button>
						<button class="ai-tab-btn" data-tab="translate">
							${window.themeFlexAI?.strings?.translate || 'Translate'}
						</button>
					</div>

					<!-- Generate Tab -->
					<div class="ai-tab-content active" data-tab="generate">
						<textarea
							class="ai-input"
							placeholder="${window.themeFlexAI?.strings?.generatePlaceholder || 'Describe what you want to generate...'}"
							rows="3"
						></textarea>
						<div class="ai-options">
							<div class="ai-option">
								<label>${window.themeFlexAI?.strings?.tone || 'Tone'}:</label>
								<select class="ai-select" data-option="tone">
									<option value="professional">Professional</option>
									<option value="casual">Casual</option>
									<option value="creative">Creative</option>
									<option value="formal">Formal</option>
								</select>
							</div>
							<div class="ai-option">
								<label>${window.themeFlexAI?.strings?.length || 'Length'}:</label>
								<select class="ai-select" data-option="length">
									<option value="short">Short</option>
									<option value="medium" selected>Medium</option>
									<option value="long">Long</option>
								</select>
							</div>
						</div>
						<button class="ai-action-btn generate-btn">
							${window.themeFlexAI?.strings?.generateBtn || 'Generate'}
						</button>
					</div>

					<!-- Improve Tab -->
					<div class="ai-tab-content" data-tab="improve">
						<textarea
							class="ai-input"
							placeholder="${window.themeFlexAI?.strings?.improvePlaceholder || 'Paste text to improve...'}"
							rows="3"
						></textarea>
						<div class="ai-options">
							<div class="ai-option">
								<label>${window.themeFlexAI?.strings?.style || 'Style'}:</label>
								<select class="ai-select" data-option="style">
									<option value="clarity">Clarity</option>
									<option value="tone">Tone</option>
									<option value="grammar">Grammar</option>
									<option value="expansion">Expansion</option>
									<option value="summary">Summary</option>
								</select>
							</div>
							<div class="ai-option">
								<label>${window.themeFlexAI?.strings?.tone || 'Tone'}:</label>
								<select class="ai-select" data-option="tone">
									<option value="professional">Professional</option>
									<option value="casual">Casual</option>
									<option value="creative">Creative</option>
									<option value="formal">Formal</option>
								</select>
							</div>
						</div>
						<button class="ai-action-btn improve-btn">
							${window.themeFlexAI?.strings?.improveBtn || 'Improve'}
						</button>
					</div>

					<!-- Headline Tab -->
					<div class="ai-tab-content" data-tab="headline">
						<textarea
							class="ai-input"
							placeholder="${window.themeFlexAI?.strings?.headlinePlaceholder || 'Paste content to generate headlines...'}"
							rows="3"
						></textarea>
						<div class="ai-options">
							<div class="ai-option">
								<label>${window.themeFlexAI?.strings?.style || 'Style'}:</label>
								<select class="ai-select" data-option="style">
									<option value="catchy">Catchy</option>
									<option value="direct">Direct</option>
									<option value="curious">Curious</option>
									<option value="benefit">Benefit-focused</option>
								</select>
							</div>
						</div>
						<button class="ai-action-btn headline-btn">
							${window.themeFlexAI?.strings?.generateBtn || 'Generate'}
						</button>
					</div>

					<!-- SEO Meta Tab -->
					<div class="ai-tab-content" data-tab="seo">
						<div class="ai-option">
							<label>${window.themeFlexAI?.strings?.title || 'Title'}:</label>
							<input type="text" class="ai-input" placeholder="Page title" data-field="title" />
						</div>
						<div class="ai-option">
							<label>${window.themeFlexAI?.strings?.content || 'Content'}:</label>
							<textarea
								class="ai-input"
								placeholder="${window.themeFlexAI?.strings?.contentPlaceholder || 'Page content'}"
								rows="3"
								data-field="content"
							></textarea>
						</div>
						<div class="ai-option">
							<label>${window.themeFlexAI?.strings?.keywords || 'Keywords'} (${window.themeFlexAI?.strings?.optional || 'optional'}):</label>
							<input type="text" class="ai-input" placeholder="target keywords" data-field="keywords" />
						</div>
						<button class="ai-action-btn seo-btn">
							${window.themeFlexAI?.strings?.generateBtn || 'Generate'}
						</button>
					</div>

					<!-- Translate Tab -->
					<div class="ai-tab-content" data-tab="translate">
						<textarea
							class="ai-input"
							placeholder="${window.themeFlexAI?.strings?.translatePlaceholder || 'Text to translate...'}"
							rows="3"
						></textarea>
						<div class="ai-options">
							<div class="ai-option">
								<label>${window.themeFlexAI?.strings?.language || 'Target Language'}:</label>
								<select class="ai-select" data-option="language">
									<option value="es">Spanish (Español)</option>
									<option value="fr">French (Français)</option>
									<option value="de">German (Deutsch)</option>
									<option value="it">Italian (Italiano)</option>
									<option value="pt">Portuguese (Português)</option>
									<option value="ja">Japanese (日本語)</option>
									<option value="zh">Chinese (中文)</option>
									<option value="ru">Russian (Русский)</option>
									<option value="ar">Arabic (العربية)</option>
									<option value="ko">Korean (한국어)</option>
								</select>
							</div>
						</div>
						<button class="ai-action-btn translate-btn">
							${window.themeFlexAI?.strings?.translateBtn || 'Translate'}
						</button>
					</div>

					<!-- Result Display -->
					<div class="ai-result-container hidden">
						<div class="ai-result-header">
							<h4>${window.themeFlexAI?.strings?.result || 'Result'}</h4>
							<button class="ai-result-close" aria-label="Close result">×</button>
						</div>
						<div class="ai-result-content"></div>
						<div class="ai-result-actions">
							<button class="ai-copy-btn">
								${window.themeFlexAI?.strings?.copy || 'Copy'}
							</button>
							<button class="ai-insert-btn">
								${window.themeFlexAI?.strings?.insert || 'Insert'}
							</button>
						</div>
					</div>

					<!-- Loading State -->
					<div class="ai-loading hidden">
						<div class="ai-shimmer"></div>
						<p>${window.themeFlexAI?.strings?.generating || 'Generating...'}</p>
					</div>

					<!-- History -->
					<div class="ai-history">
						<button class="ai-history-toggle">
							${window.themeFlexAI?.strings?.history || 'History'}
							<span class="ai-history-count">(${this.history.length})</span>
						</button>
						<ul class="ai-history-list hidden"></ul>
					</div>
				</div>
			`;

			document.body.appendChild(menu);
		},

		/**
		 * Attach event listeners
		 */
		attachEventListeners() {
			const button = document.getElementById('sf-ai-assistant-button');
			const menu = document.getElementById('sf-ai-assistant-menu');
			const closeBtn = menu.querySelector('.ai-close-btn');
			const tabBtns = menu.querySelectorAll('.ai-tab-btn');
			const actionBtns = menu.querySelectorAll('.ai-action-btn');
			const resultClose = menu.querySelector('.ai-result-close');
			const copyBtn = menu.querySelector('.ai-copy-btn');
			const insertBtn = menu.querySelector('.ai-insert-btn');
			const historyToggle = menu.querySelector('.ai-history-toggle');

			button.addEventListener('click', () => this.toggleMenu());
			closeBtn.addEventListener('click', () => this.closeMenu());
			menu.addEventListener('click', (e) => e.stopPropagation());

			tabBtns.forEach(btn => {
				btn.addEventListener('click', (e) => this.switchTab(e.target.dataset.tab));
			});

			actionBtns.forEach(btn => {
				btn.addEventListener('click', (e) => this.handleAction(e.target));
			});

			resultClose.addEventListener('click', () => this.clearResult());
			copyBtn.addEventListener('click', () => this.copyResult());
			insertBtn.addEventListener('click', () => this.insertResult());
			historyToggle.addEventListener('click', () => this.toggleHistory());

			document.addEventListener('click', (e) => {
				if (!menu.contains(e.target) && !button.contains(e.target)) {
					this.closeMenu();
				}
			});
		},

		/**
		 * Toggle menu visibility
		 */
		toggleMenu() {
			if (this.isOpen) {
				this.closeMenu();
			} else {
				this.openMenu();
			}
		},

		/**
		 * Open menu
		 */
		openMenu() {
			const menu = document.getElementById('sf-ai-assistant-menu');
			menu.classList.remove('hidden');
			this.isOpen = true;
		},

		/**
		 * Close menu
		 */
		closeMenu() {
			const menu = document.getElementById('sf-ai-assistant-menu');
			menu.classList.add('hidden');
			this.isOpen = false;
		},

		/**
		 * Switch tabs
		 */
		switchTab(tabName) {
			const menu = document.getElementById('sf-ai-assistant-menu');
			const tabBtns = menu.querySelectorAll('.ai-tab-btn');
			const tabContents = menu.querySelectorAll('.ai-tab-content');

			tabBtns.forEach(btn => btn.classList.remove('active'));
			tabContents.forEach(content => content.classList.remove('active'));

			menu.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
			menu.querySelector(`.ai-tab-content[data-tab="${tabName}"]`).classList.add('active');
		},

		/**
		 * Handle action button clicks
		 */
		handleAction(btn) {
			const tabContent = btn.closest('.ai-tab-content');
			const action = tabContent.dataset.tab;

			if (action === 'generate') {
				this.generateText(tabContent);
			} else if (action === 'improve') {
				this.improveText(tabContent);
			} else if (action === 'headline') {
				this.generateHeadline(tabContent);
			} else if (action === 'seo') {
				this.generateMeta(tabContent);
			} else if (action === 'translate') {
				this.translateText(tabContent);
			}
		},

		/**
		 * Generate text
		 */
		async generateText(tabContent) {
			const prompt = tabContent.querySelector('.ai-input').value.trim();
			if (!prompt) {
				alert('Please enter a prompt');
				return;
			}

			const tone = tabContent.querySelector('[data-option="tone"]').value;
			const length = tabContent.querySelector('[data-option="length"]').value;

			this.showLoading();

			try {
				const response = await fetch(this.apiUrl + 'generate-text', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
						'X-WP-Nonce': this.nonce,
					},
					body: JSON.stringify({
						prompt,
						tone,
						length,
					}),
				});

				const data = await response.json();

				if (response.ok) {
					this.showResult(data.content);
					this.addToHistory('generate', prompt, data.content);
				} else {
					alert('Error: ' + (data.message || 'Failed to generate content'));
				}
			} catch (error) {
				console.error('AI Assistant Error:', error);
				alert('Error: ' + error.message);
			} finally {
				this.hideLoading();
			}
		},

		/**
		 * Improve text
		 */
		async improveText(tabContent) {
			const text = tabContent.querySelector('.ai-input').value.trim();
			if (!text) {
				alert('Please paste text to improve');
				return;
			}

			const style = tabContent.querySelector('[data-option="style"]').value;
			const tone = tabContent.querySelector('[data-option="tone"]').value;

			this.showLoading();

			try {
				const response = await fetch(this.apiUrl + 'improve-text', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
						'X-WP-Nonce': this.nonce,
					},
					body: JSON.stringify({
						text,
						style,
						tone,
					}),
				});

				const data = await response.json();

				if (response.ok) {
					this.showResult(data.improved);
					this.addToHistory('improve', text, data.improved);
				} else {
					alert('Error: ' + (data.message || 'Failed to improve text'));
				}
			} catch (error) {
				console.error('AI Assistant Error:', error);
				alert('Error: ' + error.message);
			} finally {
				this.hideLoading();
			}
		},

		/**
		 * Generate headlines
		 */
		async generateHeadline(tabContent) {
			const content = tabContent.querySelector('.ai-input').value.trim();
			if (!content) {
				alert('Please paste content');
				return;
			}

			const style = tabContent.querySelector('[data-option="style"]').value;

			this.showLoading();

			try {
				const response = await fetch(this.apiUrl + 'generate-headline', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
						'X-WP-Nonce': this.nonce,
					},
					body: JSON.stringify({
						content,
						style,
						count: 5,
					}),
				});

				const data = await response.json();

				if (response.ok) {
					const headlines = data.headlines.map(h => h.trim()).filter(h => h);
					this.showResult(headlines.join('\n'));
					this.addToHistory('headline', content, headlines.join('\n'));
				} else {
					alert('Error: ' + (data.message || 'Failed to generate headlines'));
				}
			} catch (error) {
				console.error('AI Assistant Error:', error);
				alert('Error: ' + error.message);
			} finally {
				this.hideLoading();
			}
		},

		/**
		 * Generate SEO meta
		 */
		async generateMeta(tabContent) {
			const title = tabContent.querySelector('[data-field="title"]').value.trim();
			const content = tabContent.querySelector('[data-field="content"]').value.trim();
			const keywords = tabContent.querySelector('[data-field="keywords"]').value.trim();

			if (!title || !content) {
				alert('Please fill in title and content');
				return;
			}

			this.showLoading();

			try {
				const response = await fetch(this.apiUrl + 'generate-meta', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
						'X-WP-Nonce': this.nonce,
					},
					body: JSON.stringify({
						title,
						content,
						keywords: keywords || undefined,
					}),
				});

				const data = await response.json();

				if (response.ok) {
					this.showResult(data.seo_data);
					this.addToHistory('seo', title, data.seo_data);
				} else {
					alert('Error: ' + (data.message || 'Failed to generate meta'));
				}
			} catch (error) {
				console.error('AI Assistant Error:', error);
				alert('Error: ' + error.message);
			} finally {
				this.hideLoading();
			}
		},

		/**
		 * Translate text
		 */
		async translateText(tabContent) {
			const text = tabContent.querySelector('.ai-input').value.trim();
			if (!text) {
				alert('Please enter text to translate');
				return;
			}

			const language = tabContent.querySelector('[data-option="language"]').value;

			this.showLoading();

			try {
				const response = await fetch(this.apiUrl + 'translate', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
						'X-WP-Nonce': this.nonce,
					},
					body: JSON.stringify({
						text,
						target_language: language,
					}),
				});

				const data = await response.json();

				if (response.ok) {
					this.showResult(data.translated);
					this.addToHistory('translate', text, data.translated);
				} else {
					alert('Error: ' + (data.message || 'Failed to translate'));
				}
			} catch (error) {
				console.error('AI Assistant Error:', error);
				alert('Error: ' + error.message);
			} finally {
				this.hideLoading();
			}
		},

		/**
		 * Show loading state
		 */
		showLoading() {
			const menu = document.getElementById('sf-ai-assistant-menu');
			const loading = menu.querySelector('.ai-loading');
			const resultContainer = menu.querySelector('.ai-result-container');
			loading.classList.remove('hidden');
			resultContainer.classList.add('hidden');
		},

		/**
		 * Hide loading state
		 */
		hideLoading() {
			const menu = document.getElementById('sf-ai-assistant-menu');
			const loading = menu.querySelector('.ai-loading');
			loading.classList.add('hidden');
		},

		/**
		 * Show result
		 */
		showResult(content) {
			const menu = document.getElementById('sf-ai-assistant-menu');
			const resultContainer = menu.querySelector('.ai-result-container');
			const resultContent = resultContainer.querySelector('.ai-result-content');
			resultContent.textContent = content;
			resultContainer.classList.remove('hidden');
			this.currentResult = content;
		},

		/**
		 * Clear result
		 */
		clearResult() {
			const menu = document.getElementById('sf-ai-assistant-menu');
			const resultContainer = menu.querySelector('.ai-result-container');
			resultContainer.classList.add('hidden');
			this.currentResult = null;
		},

		/**
		 * Copy result to clipboard
		 */
		copyResult() {
			if (this.currentResult) {
				navigator.clipboard.writeText(this.currentResult).then(() => {
					alert('Copied to clipboard!');
				}).catch(err => {
					console.error('Failed to copy:', err);
				});
			}
		},

		/**
		 * Insert result into active field
		 */
		insertResult() {
			if (!this.currentResult) return;

			// Try to insert into Elementor widget
			if (window.elementor && window.elementor.documents.getCurrent()) {
				const selection = window.elementor.documents.getCurrent().getSelectedElement();
				if (selection && selection.get('elType') === 'widget') {
					const control = selection.getControl('editor_content') || selection.getControl('text');
					if (control) {
						selection.setSetting('editor_content', this.currentResult);
						alert('Inserted into widget!');
						return;
					}
				}
			}

			// Fallback: Try to insert into active textarea
			const textarea = document.activeElement;
			if (textarea && textarea.tagName === 'TEXTAREA') {
				textarea.value = this.currentResult;
				textarea.dispatchEvent(new Event('input', { bubbles: true }));
				alert('Inserted into text field!');
				return;
			}

			alert('Please select a text field first');
		},

		/**
		 * Add to history
		 */
		addToHistory(type, input, output) {
			this.history.unshift({
				type,
				input: input.substring(0, 50) + (input.length > 50 ? '...' : ''),
				output,
				timestamp: new Date().getTime(),
			});

			if (this.history.length > this.maxHistory) {
				this.history.pop();
			}

			this.saveHistory();
			this.updateHistoryUI();
		},

		/**
		 * Save history to sessionStorage
		 */
		saveHistory() {
			sessionStorage.setItem('themeflex_ai_history', JSON.stringify(this.history));
		},

		/**
		 * Load history from sessionStorage
		 */
		loadHistory() {
			const saved = sessionStorage.getItem('themeflex_ai_history');
			if (saved) {
				this.history = JSON.parse(saved);
				this.updateHistoryUI();
			}
		},

		/**
		 * Toggle history visibility
		 */
		toggleHistory() {
			const menu = document.getElementById('sf-ai-assistant-menu');
			const historyList = menu.querySelector('.ai-history-list');
			historyList.classList.toggle('hidden');
		},

		/**
		 * Update history UI
		 */
		updateHistoryUI() {
			const menu = document.getElementById('sf-ai-assistant-menu');
			const historyList = menu.querySelector('.ai-history-list');
			const historyCount = menu.querySelector('.ai-history-count');

			historyCount.textContent = `(${this.history.length})`;
			historyList.innerHTML = '';

			this.history.forEach((item, index) => {
				const li = document.createElement('li');
				li.className = 'ai-history-item';
				li.innerHTML = `
					<div class="ai-history-type">${item.type}</div>
					<div class="ai-history-input">${item.input}</div>
					<button class="ai-history-restore" data-index="${index}">Restore</button>
				`;

				li.querySelector('.ai-history-restore').addEventListener('click', () => {
					this.currentResult = item.output;
					this.showResult(item.output);
				});

				historyList.appendChild(li);
			});
		},

		/**
		 * Setup keyboard shortcuts
		 */
		setupKeyboardShortcuts() {
			document.addEventListener('keydown', (e) => {
				if (e.ctrlKey && e.shiftKey && e.key === 'A') {
					e.preventDefault();
					this.toggleMenu();
				}
			});
		},
	};

	// Initialize when DOM is ready
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', () => AIAssistant.init());
	} else {
		AIAssistant.init();
	}

	// Expose for Elementor integration
	window.ThemeFlexAI = AIAssistant;
})();
