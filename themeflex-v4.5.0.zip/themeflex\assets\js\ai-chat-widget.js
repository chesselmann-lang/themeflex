/**
 * ThemeFlex AI Chat Widget — v4.0
 *
 * Vanilla JS, no jQuery, no framework. <6 KB unminified.
 * Consent-gated: checks cookie "themeflex_consent" contains "ai".
 *
 * Expected DOM structure injected by class-chat-endpoint.php:
 *   .tf-chat-wrap > .tf-chat-toggle + .tf-chat-window
 *
 * Config injected via wp_localize_script as window.tfChatConfig:
 *   endpoint   — REST URL for /themeflex/v1/chat/
 *   nonce      — wp_create_nonce('wp_rest')
 *   siteName   — get_bloginfo('name')
 *   debug      — bool (admin only)
 */
/* global tfChatConfig */
(function () {
	'use strict';

	// -----------------------------------------------------------------------
	// Config
	// -----------------------------------------------------------------------
	var cfg = window.tfChatConfig || {};
	var ENDPOINT = cfg.endpoint  || '';
	var NONCE    = cfg.nonce     || '';
	var DEBUG    = cfg.debug     || false;

	// -----------------------------------------------------------------------
	// State
	// -----------------------------------------------------------------------
	var isOpen     = false;
	var isBusy     = false;
	var hasConsent = false;

	// -----------------------------------------------------------------------
	// DOM refs (populated after DOMContentLoaded)
	// -----------------------------------------------------------------------
	var wrap, toggleBtn, chatWindow, messagesArea, inputEl, sendBtn;

	// -----------------------------------------------------------------------
	// Consent helpers
	// -----------------------------------------------------------------------
	function checkConsent() {
		var cookies = document.cookie.split(';');
		for (var i = 0; i < cookies.length; i++) {
			var parts = cookies[i].trim().split('=');
			if (parts[0] === 'themeflex_consent') {
				var cats = decodeURIComponent(parts[1] || '').split(',');
				return cats.indexOf('ai') !== -1;
			}
		}
		return false;
	}

	// -----------------------------------------------------------------------
	// Render helpers
	// -----------------------------------------------------------------------
	function escHtml(str) {
		var d = document.createElement('div');
		d.textContent = str;
		return d.innerHTML;
	}

	function scrollBottom() {
		if (messagesArea) {
			messagesArea.scrollTop = messagesArea.scrollHeight;
		}
	}

	function addMessage(role, text, contactUrl) {
		var el  = document.createElement('div');
		var cls = role === 'user' ? 'tf-msg tf-msg-user' : 'tf-msg tf-msg-ai';
		el.className = cls;

		// Basic text (XSS-safe via textContent then convert newlines).
		var p = document.createElement('div');
		p.textContent = text;
		el.appendChild(p);

		// Escalation link for AI responses with low confidence.
		if (role === 'ai' && contactUrl) {
			var esc = document.createElement('div');
			esc.className = 'tf-msg-escalate';
			var a = document.createElement('a');
			a.href      = contactUrl;
			a.textContent = '→ ' + (cfg.contactLabel || 'Send us a message');
			a.target    = '_blank';
			a.rel       = 'noopener noreferrer';
			esc.appendChild(a);
			el.appendChild(esc);
		}

		messagesArea.appendChild(el);
		scrollBottom();
		return el;
	}

	function showTyping() {
		var el = document.createElement('div');
		el.className = 'tf-msg tf-msg-ai tf-msg-typing';
		el.innerHTML = '<span></span><span></span><span></span>';
		el.id = 'tf-typing';
		messagesArea.appendChild(el);
		scrollBottom();
	}

	function hideTyping() {
		var el = document.getElementById('tf-typing');
		if (el) el.remove();
	}

	function showConsentScreen() {
		messagesArea.innerHTML = '<div class="tf-chat-consent">'
			+ '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">'
			+ '<path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />'
			+ '</svg>'
			+ '<p>' + escHtml(cfg.consentText || 'To use the AI assistant, please accept AI cookies in our cookie settings.') + '</p>'
			+ '<button class="tf-consent-btn" id="tf-open-consent">'
			+ escHtml(cfg.consentBtnLabel || 'Manage Cookies') + '</button>'
			+ '</div>';

		var btn = document.getElementById('tf-open-consent');
		if (btn) {
			btn.addEventListener('click', function () {
				// Try to open the ThemeFlex cookie modal.
				var modal = document.getElementById('tf-cookie-modal');
				if (modal) {
					modal.hidden = false;
				} else {
					// Fallback: dispatch custom event.
					document.dispatchEvent(new CustomEvent('tf:open-consent-modal'));
				}
			});
		}
	}

	// -----------------------------------------------------------------------
	// API
	// -----------------------------------------------------------------------
	function sendMessage(message) {
		if (isBusy || !message.trim()) return;

		hasConsent = checkConsent();
		if (!hasConsent) {
			showConsentScreen();
			return;
		}

		isBusy = true;
		sendBtn.disabled = true;

		addMessage('user', message);
		inputEl.value = '';
		inputEl.style.height = '';
		showTyping();

		var body = JSON.stringify({ message: message, debug: DEBUG });

		fetch(ENDPOINT, {
			method:  'POST',
			headers: {
				'Content-Type': 'application/json',
				'X-WP-Nonce':   NONCE,
			},
			body: body,
		})
		.then(function (res) {
			return res.json().then(function (data) {
				data.__status = res.status;
				return data;
			});
		})
		.then(function (data) {
			hideTyping();

			if (data.consent_modal) {
				showConsentScreen();
				isBusy = false;
				sendBtn.disabled = false;
				return;
			}

			if (!data.success) {
				var errMsg = data.message || cfg.errorText || 'Sorry, something went wrong. Please try again.';
				addMessage('ai', errMsg, null);
			} else {
				addMessage('ai', data.content || '', data.contact_url || null);
				if (DEBUG && data._debug) {
					console.log('[ThemeFlex Chat Debug]', data._debug);
				}
			}
		})
		.catch(function () {
			hideTyping();
			addMessage('ai', cfg.errorText || 'Connection error. Please try again.', null);
		})
		.finally(function () {
			isBusy = false;
			sendBtn.disabled = false;
			inputEl.focus();
		});
	}

	// -----------------------------------------------------------------------
	// Open / close
	// -----------------------------------------------------------------------
	function openChat() {
		isOpen = true;
		wrap.classList.add('tf-chat--open');
		toggleBtn.setAttribute('aria-expanded', 'true');
		chatWindow.removeAttribute('hidden');

		// First open: show consent screen or welcome message.
		if (!messagesArea.children.length) {
			hasConsent = checkConsent();
			if (!hasConsent) {
				showConsentScreen();
			} else {
				addMessage('ai', cfg.welcomeText || 'Hi! I\'m the AI assistant for this website. How can I help you?');
			}
		}

		setTimeout(function () { inputEl.focus(); }, 50);
	}

	function closeChat() {
		isOpen = false;
		wrap.classList.remove('tf-chat--open');
		toggleBtn.setAttribute('aria-expanded', 'false');
	}

	// -----------------------------------------------------------------------
	// Init
	// -----------------------------------------------------------------------
	function init() {
		wrap        = document.getElementById('tf-chat-wrap');
		toggleBtn   = document.getElementById('tf-chat-toggle');
		chatWindow  = document.getElementById('tf-chat-window');
		messagesArea = document.getElementById('tf-chat-messages');
		inputEl     = document.getElementById('tf-chat-input');
		sendBtn     = document.getElementById('tf-chat-send');

		if (!wrap || !toggleBtn || !chatWindow) return;

		// Toggle button.
		toggleBtn.addEventListener('click', function () {
			isOpen ? closeChat() : openChat();
		});

		// Close on Escape.
		document.addEventListener('keydown', function (e) {
			if (isOpen && e.key === 'Escape') closeChat();
		});

		// Send on button click.
		sendBtn.addEventListener('click', function () {
			sendMessage(inputEl.value);
		});

		// Send on Enter (Shift+Enter = newline).
		inputEl.addEventListener('keydown', function (e) {
			if (e.key === 'Enter' && !e.shiftKey) {
				e.preventDefault();
				sendMessage(inputEl.value);
			}
		});

		// Auto-resize textarea.
		inputEl.addEventListener('input', function () {
			this.style.height = '';
			this.style.height = Math.min(this.scrollHeight, 96) + 'px';
		});

		// Listen for consent accepted event (from cookie banner).
		document.addEventListener('tf:consent-accepted', function (e) {
			if (e.detail && e.detail.categories && e.detail.categories.indexOf('ai') !== -1) {
				hasConsent = true;
				if (isOpen && !messagesArea.querySelector('.tf-chat-consent ~ *')) {
					messagesArea.innerHTML = '';
					addMessage('ai', cfg.welcomeText || 'Hi! How can I help you?');
				}
			}
		});
	}

	// Boot after DOM ready.
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
