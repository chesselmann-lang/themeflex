/**
 * Scroll Reveal Animations
 */
(function() {
	'use strict';

	const ScrollReveal = {
		elements: [],
		prefersReducedMotion: window.matchMedia('(prefers-reduced-motion: reduce)').matches,

		init: function() {
			if (this.prefersReducedMotion || !sfAnimations.enable) {
				return;
			}

			this.observeElements();
			this.setupScrollListener();
			this.setupBackToTop();
		},

		observeElements: function() {
			const self = this;
			const options = {
				threshold: 0.1,
				rootMargin: '0px 0px -100px 0px'
			};

			const observer = new IntersectionObserver((entries) => {
				entries.forEach((entry) => {
					if (entry.isIntersecting) {
						self.animateElement(entry.target);
						observer.unobserve(entry.target);
					}
				});
			}, options);

			// Find all animatable elements
			document.querySelectorAll('[data-animate]').forEach((el) => {
				observer.observe(el);
			});
		},

		animateElement: function(el) {
			const animation = el.getAttribute('data-animate');
			const delay = el.getAttribute('data-animate-delay') || 0;
			const duration = el.getAttribute('data-animate-duration') || 600;

			setTimeout(() => {
				el.style.animationDuration = duration + 'ms';
				el.classList.add('animate-' + animation);
				el.style.opacity = '1';
			}, parseInt(delay));
		},

		setupScrollListener: function() {
			let ticking = false;
			const self = this;

			// Parallax handler
			window.addEventListener('scroll', () => {
				if (!ticking) {
					window.requestAnimationFrame(() => {
						self.updateParallax();
						ticking = false;
					});
					ticking = true;
				}
			});
		},

		updateParallax: function() {
			const scrollY = window.scrollY;

			document.querySelectorAll('[data-parallax]').forEach((el) => {
				const speed = parseFloat(el.getAttribute('data-parallax-speed')) || 0.5;
				const offset = scrollY * speed;
				el.style.transform = `translate3d(0, ${offset}px, 0)`;
			});
		},

		setupBackToTop: function() {
			const backToTop = document.getElementById('sf-back-to-top');
			if (!backToTop) return;

			const scrollProgress = document.querySelector('.sf-scroll-progress-bar');

			window.addEventListener('scroll', () => {
				const scrollTop = window.scrollY;
				const docHeight = document.documentElement.scrollHeight - window.innerHeight;
				const scrollPercent = (scrollTop / docHeight) * 100;

				if (scrollTop > 300) {
					backToTop.classList.add('show');
				} else {
					backToTop.classList.remove('show');
				}

				if (scrollProgress) {
					scrollProgress.style.width = scrollPercent + '%';
				}
			});

			backToTop.addEventListener('click', () => {
				window.scrollTo({
					top: 0,
					behavior: 'smooth'
				});
			});
		}
	};

	// Smooth scroll for anchor links
	function setupSmoothScroll() {
		if (!sfAnimations.smooth_scroll) return;

		document.querySelectorAll('a[href^="#"]').forEach(anchor => {
			anchor.addEventListener('click', function (e) {
				const href = this.getAttribute('href');
				if (href === '#' || href === '') return;

				const target = document.querySelector(href);
				if (target) {
					e.preventDefault();
					target.scrollIntoView({ behavior: 'smooth' });
				}
			});
		});
	}

	// Initialize when DOM is ready
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', () => {
			ScrollReveal.init();
			setupSmoothScroll();
		});
	} else {
		ScrollReveal.init();
		setupSmoothScroll();
	}

	// Expose to window for external use
	window.sfScrollReveal = ScrollReveal;
})();
