/**
 * ThemeFlex Custom Cursor v1.0
 *
 * Dual-ring cursor with:
 * - Small dot that snaps to position
 * - Large ring that lags behind (elastic follow)
 * - Expand on hover over links/buttons
 * - Text state on headings
 * - Hide on touch devices
 *
 * Zero dependencies. ~2KB.
 */
(function () {
  'use strict';

  // Skip on touch devices
  if (window.matchMedia('(pointer: coarse)').matches) return;

  /* ── Create cursor elements ──────────────────────────────── */
  var dot  = document.createElement('div');
  var ring = document.createElement('div');
  dot.className  = 'tf-cursor-dot';
  ring.className = 'tf-cursor-ring';
  document.body.appendChild(dot);
  document.body.appendChild(ring);

  /* ── Inject CSS ──────────────────────────────────────────── */
  var style = document.createElement('style');
  style.textContent = [
    '*, *::before, *::after { cursor: none !important; }',
    '.tf-cursor-dot {',
    '  position: fixed; z-index: 99999; pointer-events: none;',
    '  width: 6px; height: 6px; border-radius: 50%;',
    '  background: #ff5e2e;',
    '  top: 0; left: 0;',
    '  transform: translate(-50%,-50%);',
    '  transition: width .2s, height .2s, background .2s, opacity .3s;',
    '}',
    '.tf-cursor-ring {',
    '  position: fixed; z-index: 99998; pointer-events: none;',
    '  width: 32px; height: 32px; border-radius: 50%;',
    '  border: 1.5px solid rgba(255,94,46,.5);',
    '  top: 0; left: 0;',
    '  transform: translate(-50%,-50%);',
    '  transition: width .4s cubic-bezier(.23,1,.32,1),',
    '              height .4s cubic-bezier(.23,1,.32,1),',
    '              border-color .3s, opacity .3s, background .3s;',
    '}',
    '.tf-cursor-dot.tf-cur-hover  { width: 10px; height: 10px; }',
    '.tf-cursor-ring.tf-cur-hover { width: 52px; height: 52px; border-color: rgba(255,94,46,.25); }',
    '.tf-cursor-dot.tf-cur-link   { background: #fff; width: 8px; height: 8px; }',
    '.tf-cursor-ring.tf-cur-link  { width: 44px; height: 44px; background: rgba(255,94,46,.08); border-color: rgba(255,94,46,.4); }',
    '.tf-cursor-dot.tf-cur-text   { width: 2px; height: 22px; border-radius: 1px; background: #ff5e2e; }',
    '.tf-cursor-ring.tf-cur-text  { width: 3px; height: 26px; border-radius: 2px; border: none; background: rgba(255,94,46,.2); }',
    '.tf-cursor-dot.tf-cur-hidden, .tf-cursor-ring.tf-cur-hidden { opacity: 0; }',
  ].join('\n');
  document.head.appendChild(style);

  /* ── State ───────────────────────────────────────────────── */
  var mx = -100, my = -100; // mouse position
  var rx = -100, ry = -100; // ring position (lags)
  var speed = 0.14;

  /* ── RAF loop for elastic ring ───────────────────────────── */
  function loop() {
    rx += (mx - rx) * speed;
    ry += (my - ry) * speed;
    ring.style.left = rx + 'px';
    ring.style.top  = ry + 'px';
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);

  /* ── Mouse tracking ──────────────────────────────────────── */
  document.addEventListener('mousemove', function (e) {
    mx = e.clientX;
    my = e.clientY;
    dot.style.left = mx + 'px';
    dot.style.top  = my + 'px';
  }, { passive: true });

  /* ── Enter / leave document ──────────────────────────────── */
  document.addEventListener('mouseleave', function () {
    dot.classList.add('tf-cur-hidden');
    ring.classList.add('tf-cur-hidden');
  });
  document.addEventListener('mouseenter', function () {
    dot.classList.remove('tf-cur-hidden');
    ring.classList.remove('tf-cur-hidden');
  });

  /* ── Hover detection ─────────────────────────────────────── */
  var interactors = 'a, button, [role="button"], input, textarea, select, label, .tf-skin-dot, .tf-demo-tab, .tf-faq-cat';
  var textEls = 'h1, h2, h3, p';

  function onEnter(e) {
    var el = e.target;
    if (el.matches && el.matches(interactors)) {
      dot.classList.add('tf-cur-link');
      ring.classList.add('tf-cur-link');
    } else if (el.matches && el.matches(textEls)) {
      dot.classList.add('tf-cur-text');
      ring.classList.add('tf-cur-text');
    } else {
      dot.classList.add('tf-cur-hover');
      ring.classList.add('tf-cur-hover');
    }
  }

  function onLeave() {
    dot.className  = 'tf-cursor-dot';
    ring.className = 'tf-cursor-ring';
  }

  document.addEventListener('mouseover',  onEnter, { passive: true });
  document.addEventListener('mouseout',   onLeave, { passive: true });

  /* ── Click pulse ─────────────────────────────────────────── */
  document.addEventListener('mousedown', function () {
    ring.style.transform = 'translate(-50%,-50%) scale(0.8)';
  });
  document.addEventListener('mouseup', function () {
    ring.style.transform = 'translate(-50%,-50%) scale(1)';
  });

})();
