/**
 * Custom JavaScript for ThemeFlex
 *
 * Handles: scroll animations, mobile sticky CTA, stats counters,
 * back-to-top, touch feedback, smooth scroll, accessibility
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

(function() {
	'use strict';

	const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	// -----------------------------------------------
	// SCROLL-REVEAL — IntersectionObserver for .sf-animate
	// -----------------------------------------------
	function initScrollReveal() {
		if (prefersReducedMotion) {
			// Show everything immediately if motion reduced
			document.querySelectorAll('.sf-animate, .sf-animate-left, .sf-animate-scale').forEach(function(el) {
				el.classList.add('sf-visible');
			});
			return;
		}

		var observer = new IntersectionObserver(function(entries) {
			entries.forEach(function(entry) {
				if (entry.isIntersecting) {
					entry.target.classList.add('sf-visible');
					observer.unobserve(entry.target);
				}
			});
		}, {
			threshold: 0.1,
			rootMargin: '0px 0px -60px 0px'
		});

		document.querySelectorAll('.sf-animate, .sf-animate-left, .sf-animate-scale').forEach(function(el) {
			observer.observe(el);
		});
	}

	// -----------------------------------------------
	// STAGGERED CHILDREN — add sf-animate to list items
	// -----------------------------------------------
	function initStaggerChildren() {
		if (prefersReducedMotion) return;

		document.querySelectorAll('.sf-stagger').forEach(function(container) {
			var children = container.children;
			for (var i = 0; i < children.length; i++) {
				children[i].classList.add('sf-animate');
				children[i].style.transitionDelay = (i * 80) + 'ms';
			}
		});

		// Re-run scroll reveal to pick up newly added classes
		initScrollReveal();
	}

	// -----------------------------------------------
	// STATS COUNTER ANIMATION
	// -----------------------------------------------
	function animateCounter(el) {
		var target = parseInt(el.getAttribute('data-target') || el.textContent, 10);
		if (isNaN(target)) return;

		var start = 0;
		var duration = 1800;
		var startTime = null;

		function easeOutQuart(t) {
			return 1 - Math.pow(1 - t, 4);
		}

		function step(timestamp) {
			if (!startTime) startTime = timestamp;
			var elapsed = timestamp - startTime;
			var progress = Math.min(elapsed / duration, 1);
			var current = Math.floor(easeOutQuart(progress) * target);

			el.textContent = current.toLocaleString();

			if (progress < 1) {
				requestAnimationFrame(step);
			} else {
				el.textContent = target.toLocaleString();
			}
		}

		requestAnimationFrame(step);
	}

	function initCounters() {
		var counters = document.querySelectorAll('.sf-counter[data-target], [data-counter]');
		if (!counters.length) return;

		var counterObserver = new IntersectionObserver(function(entries) {
			entries.forEach(function(entry) {
				if (entry.isIntersecting) {
					if (!prefersReducedMotion) {
						animateCounter(entry.target);
					}
					counterObserver.unobserve(entry.target);
				}
			});
		}, { threshold: 0.5 });

		counters.forEach(function(counter) {
			counterObserver.observe(counter);
		});
	}

	// -----------------------------------------------
	// MOBILE STICKY CTA
	// -----------------------------------------------
	function initMobileStickyCTA() {
		var cta = document.querySelector('.sf-mobile-cta');
		if (!cta) return;

		var hero = document.querySelector('.hero, .wp-block-cover, .site-content > article');
		if (!hero) {
			// No hero — show after 300px scroll
			window.addEventListener('scroll', function() {
				if (window.scrollY > 300) {
					cta.style.display = 'block';
				}
			}, { passive: true });
			return;
		}

		var stickyObserver = new IntersectionObserver(function(entries) {
			entries.forEach(function(entry) {
				// Show CTA once hero scrolls out of view
				if (!entry.isIntersecting) {
					cta.style.display = 'block';
				} else {
					cta.style.display = 'none';
				}
			});
		}, { threshold: 0 });

		stickyObserver.observe(hero);
	}

	// -----------------------------------------------
	// MOBILE MENU TOGGLE ANIMATION
	// -----------------------------------------------
	function initMobileMenu() {
		var toggle = document.getElementById('menu-toggle');
		var nav = document.querySelector('.main-navigation, #site-navigation');
		if (!toggle || !nav) return;

		toggle.addEventListener('click', function() {
			var expanded = this.getAttribute('aria-expanded') === 'true';
			this.setAttribute('aria-expanded', String(!expanded));
			nav.classList.toggle('is-open', !expanded);
			nav.classList.toggle('nav-open', !expanded);

			// Prevent body scroll when mobile menu is open
			document.body.style.overflow = !expanded ? 'hidden' : '';
		});

		// Close on Escape
		document.addEventListener('keydown', function(e) {
			if (e.key === 'Escape' && nav.classList.contains('is-open')) {
				toggle.setAttribute('aria-expanded', 'false');
				nav.classList.remove('is-open', 'nav-open');
				document.body.style.overflow = '';
				toggle.focus();
			}
		});

		// Close when clicking outside nav
		document.addEventListener('click', function(e) {
			if (!nav.contains(e.target) && !toggle.contains(e.target)) {
				toggle.setAttribute('aria-expanded', 'false');
				nav.classList.remove('is-open', 'nav-open');
				document.body.style.overflow = '';
			}
		});
	}

	// -----------------------------------------------
	// MOBILE SUBMENU TOGGLE
	// -----------------------------------------------
	function initSubMenuToggle() {
		document.querySelectorAll('.menu-item-has-children > a').forEach(function(link) {
			// Only for mobile
			if (window.innerWidth > 768) return;

			link.addEventListener('click', function(e) {
				var li = this.parentElement;
				var submenu = li.querySelector('.sub-menu');
				if (!submenu) return;

				e.preventDefault();
				li.classList.toggle('is-open');
			});
		});
	}

	// -----------------------------------------------
	// TOUCH FEEDBACK (mobile tap highlight)
	// -----------------------------------------------
	function initTouchFeedback() {
		if (!('ontouchstart' in window)) return;

		document.querySelectorAll('a, button, .post-card').forEach(function(el) {
			el.addEventListener('touchstart', function() {
				this.style.opacity = '0.8';
			}, { passive: true });

			el.addEventListener('touchend', function() {
				var self = this;
				setTimeout(function() { self.style.opacity = ''; }, 150);
			}, { passive: true });
		});
	}

	// -----------------------------------------------
	// BACK TO TOP BUTTON
	// -----------------------------------------------
	function initBackToTop() {
		var btn = document.getElementById('back-to-top') || document.querySelector('.sf-back-to-top-custom');
		if (!btn) return;

		window.addEventListener('scroll', function() {
			btn.classList.toggle('visible', window.scrollY > 400);
		}, { passive: true });

		btn.addEventListener('click', function(e) {
			e.preventDefault();
			window.scrollTo({ top: 0, behavior: prefersReducedMotion ? 'auto' : 'smooth' });
		});
	}

	// -----------------------------------------------
	// SMOOTH SCROLL — anchor links with sticky header offset
	// -----------------------------------------------
	function initSmoothScroll() {
		document.querySelectorAll('a[href^="#"]').forEach(function(anchor) {
			anchor.addEventListener('click', function(e) {
				var href = this.getAttribute('href');
				if (!href || href === '#') return;

				var target = document.querySelector(href);
				if (!target) return;

				e.preventDefault();

				var header = document.querySelector('#site-header, .site-header');
				var offset = header ? header.getBoundingClientRect().height + 16 : 0;
				var targetY = target.getBoundingClientRect().top + window.scrollY - offset;

				window.scrollTo({ top: targetY, behavior: prefersReducedMotion ? 'auto' : 'smooth' });
			});
		});
	}

	// -----------------------------------------------
	// FOCUS VISIBLE POLYFILL (for older browsers)
	// -----------------------------------------------
	function initFocusVisible() {
		var hadKeyboardEvent = false;

		document.addEventListener('keydown', function() { hadKeyboardEvent = true; });
		document.addEventListener('mousedown', function() { hadKeyboardEvent = false; });

		document.addEventListener('focusin', function(e) {
			if (hadKeyboardEvent) {
				e.target.classList.add('focus-visible');
			}
		});

		document.addEventListener('focusout', function(e) {
			e.target.classList.remove('focus-visible');
		});
	}

	// -----------------------------------------------
	// EXTERNAL LINKS — keyboard activation
	// -----------------------------------------------
	function initExternalLinks() {
		document.querySelectorAll('a[target="_blank"]').forEach(function(link) {
			link.addEventListener('keypress', function(e) {
				if (e.key === 'Enter' || e.key === ' ') {
					this.click();
				}
			});

			// Add rel if missing (security)
			if (!link.rel.includes('noopener')) {
				link.rel = (link.rel ? link.rel + ' ' : '') + 'noopener noreferrer';
			}
		});
	}

	// -----------------------------------------------
	// DARK MODE — global (all pages)
	// Works with the toggle button in header.php:
	//   <button id="dark-mode-toggle">
	// Persists choice in localStorage under key 'themeflexTheme'.
	// Also respects prefers-color-scheme on first visit.
	// -----------------------------------------------
	function sfApplyTheme( theme ) {
		document.documentElement.setAttribute( 'data-theme', theme );
		try { localStorage.setItem( 'themeflexTheme', theme ); } catch ( e ) {}

		var btn = document.getElementById( 'dark-mode-toggle' );
		if ( btn ) {
			btn.setAttribute( 'aria-pressed', theme === 'dark' ? 'true' : 'false' );
			btn.setAttribute( 'aria-label', theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode' );
		}
	}

	function initDarkMode() {
		var saved = null;
		try { saved = localStorage.getItem( 'themeflexTheme' ); } catch ( e ) {}

		var prefersDark = window.matchMedia && window.matchMedia( '(prefers-color-scheme: dark)' ).matches;
		// Default to dark mode for the ThemeFlex demo — dark-first design
		sfApplyTheme( saved || ( prefersDark ? 'dark' : 'light' ) );

		// OS-level change (no saved preference)
		if ( window.matchMedia ) {
			window.matchMedia( '(prefers-color-scheme: dark)' ).addEventListener( 'change', function ( e ) {
				try {
					if ( ! localStorage.getItem( 'themeflexTheme' ) ) {
						sfApplyTheme( e.matches ? 'dark' : 'light' );
					}
				} catch ( err ) {
					sfApplyTheme( e.matches ? 'dark' : 'light' );
				}
			} );
		}

		// Toggle button click
		var toggle = document.getElementById( 'dark-mode-toggle' );
		if ( toggle ) {
			toggle.addEventListener( 'click', function () {
				var current = document.documentElement.getAttribute( 'data-theme' );
				sfApplyTheme( current === 'dark' ? 'light' : 'dark' );
			} );
		}
	}

	// -----------------------------------------------
	// INIT — DOMContentLoaded
	// -----------------------------------------------
	function init() {
		initDarkMode(); // must run first — prevents FOUC on dark-mode pages
		initScrollReveal();
		initStaggerChildren();
		initCounters();
		initMobileStickyCTA();
		initMobileMenu();
		initSubMenuToggle();
		initTouchFeedback();
		initBackToTop();
		initSmoothScroll();
		initFocusVisible();
		initExternalLinks();
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}

})();

/* ── Preloader ────────────────────────────────────────────────────────── */
(function () {
	'use strict';

	var preloader = document.getElementById('sf-preloader');
	if (!preloader) return;

	// Add loading class immediately
	document.body.classList.add('sf-preloading');

	function hidePreloader() {
		preloader.classList.add('sf-preloader--hidden');
		document.body.classList.remove('sf-preloading');
		// Remove from DOM after transition
		setTimeout(function () {
			if (preloader && preloader.parentNode) {
				preloader.parentNode.removeChild(preloader);
			}
		}, 450);
	}

	// Hide after page load
	if (document.readyState === 'complete') {
		hidePreloader();
	} else {
		window.addEventListener('load', hidePreloader, { once: true });
		// Safety timeout — never block the page for more than 4s
		setTimeout(hidePreloader, 4000);
	}
})();

/* ── Interaction Engine — IntersectionObserver for all .sf-anim-* elements ── */
(function () {
    'use strict';

    if (!('IntersectionObserver' in window)) return;

    var observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('sf-revealed');
                // Auto-stagger children
                var children = entry.target.querySelectorAll('[class*="sf-anim-"]');
                children.forEach(function (child, i) {
                    if (!child.classList.contains('sf-revealed')) {
                        child.style.transitionDelay = (i * 0.1) + 's';
                        setTimeout(function () { child.classList.add('sf-revealed'); }, i * 100);
                    }
                });
            }
        });
    }, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });

    function initObserver() {
        document.querySelectorAll('[class*="sf-anim-"]').forEach(function (el) {
            observer.observe(el);
        });
    }

    // Init on load + re-init for Elementor Frontend
    document.addEventListener('DOMContentLoaded', initObserver);
    window.addEventListener('elementor/frontend/init', initObserver);
    if (window.elementorFrontend) {
        window.elementorFrontend.hooks.addAction('frontend/element_ready/global', initObserver);
    }

    /* ── 3D Tilt (lightweight) ── */
    document.addEventListener('mousemove', function (e) {
        var el = e.target.closest('.sf-hover-tilt');
        if (!el) return;
        var r = el.getBoundingClientRect();
        var cx = (e.clientX - r.left) / r.width  - 0.5;
        var cy = (e.clientY - r.top)  / r.height - 0.5;
        el.style.transform = 'perspective(600px) rotateY(' + (cx * 12) + 'deg) rotateX(' + (-cy * 12) + 'deg)';
    });
    document.addEventListener('mouseleave', function (e) {
        var el = e.target.closest('.sf-hover-tilt');
        if (el) el.style.transform = '';
    }, true);

    /* ── Parallax (passive scroll listener) ── */
    var parallaxEls = [];
    function updateParallax() {
        parallaxEls.forEach(function (el) {
            var speed  = parseFloat(el.dataset.parallax || '0.3');
            var rect   = el.getBoundingClientRect();
            var center = rect.top + rect.height / 2 - window.innerHeight / 2;
            el.style.setProperty('--sf-parallax-offset', (center * speed).toFixed(1) + 'px');
        });
    }
    function initParallax() {
        parallaxEls = Array.from(document.querySelectorAll('.sf-parallax'));
        if (parallaxEls.length) window.addEventListener('scroll', updateParallax, { passive: true });
    }
    document.addEventListener('DOMContentLoaded', initParallax);

    /* ── Sticky header on scroll ── */
    var header = document.querySelector('.site-header');
    if (header) {
        var headerH = header.offsetHeight;
        window.addEventListener('scroll', function () {
            header.classList.toggle('sf-sticky', window.scrollY > headerH);
        }, { passive: true });
    }
})();
