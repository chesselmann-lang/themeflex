/**
 * File customizer.js.
 *
 * Theme Customizer enhancements for a better user experience.
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

(function( $ ) {
	'use strict';

	/**
	 * Panel dependencies - Show/hide panels based on other settings
	 */
	wp.customize( 'themeflex_dark_mode', function( setting ) {
		setting.bind( function( value ) {
			if ( 'off' === value ) {
				wp.customize.section( 'themeflex_dark_mode' ).deactivate();
			} else {
				wp.customize.section( 'themeflex_dark_mode' ).activate();
			}
		} );
	} );

	/**
	 * Enhance font selector with preview
	 */
	wp.customize.control( 'themeflex_font_headings', function( control ) {
		control.container.on( 'change', 'select', function() {
			var fontName = $( this ).val();
			previewFont( fontName, 'heading' );
		} );
	} );

	wp.customize.control( 'themeflex_font_body', function( control ) {
		control.container.on( 'change', 'select', function() {
			var fontName = $( this ).val();
			previewFont( fontName, 'body' );
		} );
	} );

	/**
	 * Add helper descriptions for complex settings
	 */
	addSettingDescriptions();

	/**
	 * Preview font changes
	 *
	 * @param {string} fontName The font name.
	 * @param {string} type The element type ('heading' or 'body').
	 */
	function previewFont( fontName, type ) {
		var fontParam = fontName.replace( /\s+/g, '+' );
		var frameDoc = wp.customize.previewer.container[0].contentDocument;

		if ( frameDoc ) {
			var link = frameDoc.createElement( 'link' );
			link.href = 'https://fonts.googleapis.com/css2?family=' + fontParam + ':wght@300;400;500;600;700&display=swap';
			link.rel = 'stylesheet';
			frameDoc.head.appendChild( link );
		}
	}

	/**
	 * Add helpful descriptions to settings
	 */
	function addSettingDescriptions() {
		var descriptions = {
			'themeflex_color_primary': wp.i18n.__( 'Used for links and primary buttons', 'themeflex' ),
			'themeflex_color_secondary': wp.i18n.__( 'Used for headings and emphasis', 'themeflex' ),
			'themeflex_color_accent': wp.i18n.__( 'Used for hover states and highlights', 'themeflex' ),
			'themeflex_sticky_header': wp.i18n.__( 'Header stays visible when scrolling', 'themeflex' ),
			'themeflex_blog_layout': wp.i18n.__( 'Controls how blog posts are displayed on archive pages', 'themeflex' ),
			'themeflex_pagination_style': wp.i18n.__( 'Choose how readers navigate between pages', 'themeflex' ),
		};

		$.each( descriptions, function( settingId, description ) {
			wp.customize.control( settingId, function( control ) {
				if ( control && control.container ) {
					var $desc = control.container.find( '.description' );
					if ( ! $desc.length ) {
						$desc = $( '<p class="description"></p>' ).appendTo( control.container );
					}
					$desc.html( description );
				}
			} );
		} );
	}

} )( jQuery );
