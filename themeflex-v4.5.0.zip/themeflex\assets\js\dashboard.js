(function($) {
	'use strict';

	const Dashboard = {
		init: function() {
			this.bindTabs();
		},

		bindTabs: function() {
			$(document).on('click', '.sf-tab-btn', this.onTabClick.bind(this));
		},

		onTabClick: function(e) {
			const $btn = $(e.currentTarget);
			const tab = $btn.data('tab');

			// Remove active state from all buttons and tabs
			$('.sf-tab-btn').removeClass('active');
			$('.sf-tab-content').removeClass('active');

			// Add active state to clicked button and corresponding tab
			$btn.addClass('active');
			$('#' + tab).addClass('active');
		}
	};

	$(function() {
		Dashboard.init();
	});
})(jQuery);
