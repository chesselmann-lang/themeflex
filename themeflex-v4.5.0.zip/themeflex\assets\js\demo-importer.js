(function($) {
	'use strict';

	const DemoImporter = {
		cache: {},
		currentCategory: 'all',
		searchQuery: '',

		init: function() {
			this.bindEvents();
			this.loadDemos();
		},

		bindEvents: function() {
			// Search input
			$(document).on('input', '#sf-demo-search', $.proxy(this.handleSearch, this));

			// Category tabs
			$(document).on('click', '.sf-category-tab', $.proxy(this.handleCategoryChange, this));

			// Import button
			$(document).on('click', '.sf-import-btn', $.proxy(this.handleImport, this));

			// Reset button
			$(document).on('click', '#sf-reset-btn', $.proxy(this.handleReset, this));
		},

		loadDemos: function() {
			const self = this;

			$.ajax({
				url: sfDemoImporter.ajaxUrl,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'sf_get_demos',
					nonce: sfDemoImporter.nonce
				},
				success: function(response) {
					if (response.success) {
						self.cache = response.data;
						self.renderDemos(response.data.demos);
					}
				},
				error: function(xhr, status, error) {
					console.error('Error loading demos:', error);
				}
			});
		},

		renderDemos: function(demos) {
			const container = $('#sf-demos-container');
			container.empty();

			if (Object.keys(demos).length === 0) {
				container.html('<p class="sf-no-results">' + sfDemoImporter.error + '</p>');
				return;
			}

			let html = '';
			$.each(demos, function(slug, demo) {
				// Filter by category
				if (DemoImporter.currentCategory !== 'all' && demo.category !== DemoImporter.currentCategory) {
					return true; // continue
				}

				html += DemoImporter.renderDemoCard(slug, demo);
			});

			if (html === '') {
				container.html('<p class="sf-no-results">No templates found matching your filters.</p>');
			} else {
				container.html(html);
			}
		},

		renderDemoCard: function(slug, demo) {
			const categoryName = DemoImporter.cache.categories[demo.category] || demo.category;
			const themePath = sfDemoImporter.themePath;
			const thumbnail = themePath + '/assets/images/demo-' + slug + '.jpg';

			return `
				<div class="sf-demo-card" data-slug="${slug}" data-category="${demo.category}">
					<div class="sf-demo-preview">
						<img src="${thumbnail}" alt="${demo.title}" onerror="this.src='${themePath}/assets/images/placeholder.png'">
						<div class="sf-demo-overlay">
							<button class="sf-import-btn button button-primary" data-slug="${slug}">
								Import Template
							</button>
						</div>
					</div>
					<div class="sf-demo-content">
						<h3 class="sf-demo-title">${demo.title}</h3>
						<p class="sf-demo-category">${categoryName}</p>
						<div class="sf-demo-colors">
							<span class="sf-color-dot" style="background-color: ${demo.colors.primary};" title="Primary Color"></span>
							<span class="sf-color-dot" style="background-color: ${demo.colors.secondary};" title="Secondary Color"></span>
						</div>
					</div>
				</div>
			`;
		},

		handleSearch: function(e) {
			const query = $(e.target).val().trim();
			this.searchQuery = query;

			if (query === '') {
				this.renderDemos(this.cache.demos);
				return;
			}

			const self = this;

			$.ajax({
				url: sfDemoImporter.ajaxUrl,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'sf_search_demos',
					nonce: sfDemoImporter.nonce,
					query: query
				},
				success: function(response) {
					if (response.success) {
						self.renderDemos(response.data.demos);
					}
				}
			});
		},

		handleCategoryChange: function(e) {
			const tab = $(e.target).closest('.sf-category-tab');
			const category = tab.data('category');

			$('.sf-category-tab').removeClass('active');
			tab.addClass('active');

			this.currentCategory = category;
			this.renderDemos(this.cache.demos);
		},

		handleImport: function(e) {
			e.preventDefault();
			e.stopPropagation();

			const button = $(e.target);
			const slug = button.data('slug');
			const card = button.closest('.sf-demo-card');

			if (!slug) {
				console.error('No demo slug found');
				return;
			}

			const self = this;
			const originalText = button.text();

			button.prop('disabled', true).text(sfDemoImporter.importing);

			$.ajax({
				url: sfDemoImporter.ajaxUrl,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'sf_import_demo',
					nonce: sfDemoImporter.nonce,
					slug: slug
				},
				success: function(response) {
					button.prop('disabled', false);

					if (response.success) {
						button.text('Imported!').addClass('button-success disabled');
						card.addClass('imported');

						// Show success message
						const successDiv = $('#sf-import-success');
						successDiv.show().delay(5000).fadeOut();

						// Scroll to success message
						$('html, body').animate({
							scrollTop: successDiv.offset().top - 100
						}, 500);
					} else {
						button.text(originalText).prop('disabled', false);
						alert(response.data || sfDemoImporter.error);
					}
				},
				error: function(xhr, status, error) {
					button.text(originalText).prop('disabled', false);
					console.error('Import failed:', error);
					alert(sfDemoImporter.error);
				}
			});
		},

		handleReset: function(e) {
			e.preventDefault();

			if (!confirm('Are you sure you want to reset all demo content? This action cannot be undone.')) {
				return;
			}

			const button = $(e.target);
			const originalText = button.text();

			button.prop('disabled', true).text('Resetting...');

			$.ajax({
				url: sfDemoImporter.ajaxUrl,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'sf_reset_demo',
					nonce: sfDemoImporter.nonce
				},
				success: function(response) {
					button.prop('disabled', false);

					if (response.success) {
						button.text('Reset Complete!');
						alert(response.data || 'Demo content has been reset.');

						// Reload page
						setTimeout(function() {
							window.location.reload();
						}, 1500);
					} else {
						button.text(originalText).prop('disabled', false);
						alert(response.data || sfDemoImporter.error);
					}
				},
				error: function(xhr, status, error) {
					button.text(originalText).prop('disabled', false);
					console.error('Reset failed:', error);
					alert(sfDemoImporter.error);
				}
			});
		}
	};

	$(function() {
		DemoImporter.init();
	});
})(jQuery);
