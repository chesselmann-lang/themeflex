/**
 * Design System Admin Panel
 *
 * JavaScript for the global design system configuration interface.
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

(function($) {
	'use strict';

	const DesignSystem = {
		apiUrl: designSystemData?.apiUrl || '/wp-json/themeflex/v1/design-system/',
		nonce: designSystemData?.nonce || '',
		defaultConfig: designSystemData?.defaultConfig || {},
		config: {},
		saveTimeout: null,

		/**
		 * Initialize
		 */
		init() {
			this.loadConfig();
			this.attachEventListeners();
			this.renderSections();
		},

		/**
		 * Load configuration from API
		 */
		loadConfig() {
			$.ajax({
				url: this.apiUrl + 'config',
				method: 'GET',
				headers: {
					'X-WP-Nonce': this.nonce,
				},
				success: (data) => {
					this.config = data;
					this.renderSections();
				},
				error: (error) => {
					console.error('Failed to load configuration:', error);
				},
			});
		},

		/**
		 * Attach event listeners
		 */
		attachEventListeners() {
			// Tab navigation
			$('.sf-ds-nav-btn').on('click', (e) => {
				const $btn = $(e.currentTarget);
				const action = $btn.data('action');
				const tab = $btn.data('tab');

				if (action) {
					if (action === 'export') {
						this.exportConfig();
					} else if (action === 'import') {
						this.importConfig();
					}
				} else if (tab) {
					this.switchTab(tab);
				}
			});

			// Reset buttons
			$(document).on('click', '.sf-ds-reset-btn', (e) => {
				const $btn = $(e.currentTarget);
				const section = $btn.data('section');
				if (confirm('Reset ' + section + ' to defaults? This cannot be undone.')) {
					this.resetSection(section);
				}
			});

			// Input changes with debounce
			$(document).on('change', '[data-ds-field]', (e) => {
				clearTimeout(this.saveTimeout);
				this.saveTimeout = setTimeout(() => {
					this.saveChanges();
				}, 500);
			});
		},

		/**
		 * Switch tabs
		 */
		switchTab(tabName) {
			$('.sf-ds-nav-btn').removeClass('active');
			$('[data-tab="' + tabName + '"]').addClass('active').filter('.sf-ds-nav-btn').addClass('active');

			$('.sf-ds-section').removeClass('active');
			$('[data-tab="' + tabName + '"].sf-ds-section').addClass('active');

			// Re-initialize color pickers for the new tab
			$('.sf-ds-section.active .wp-color-picker').iris('hide');
			$('.sf-ds-section.active .wp-color-picker').wpColorPicker();
		},

		/**
		 * Render all sections
		 */
		renderSections() {
			this.renderColors();
			this.renderTypography();
			this.renderSpacing();
			this.renderBorders();
			this.renderButtons();
			this.renderLayout();
		},

		/**
		 * Render colors section
		 */
		renderColors() {
			const $container = $('#sf-colors-container');
			const colors = this.config.colors || this.defaultConfig.colors || {};
			let html = '';

			$.each(colors, (name, value) => {
				html += `
					<div class="sf-ds-color-item">
						<label class="sf-ds-color-label">${this.formatLabel(name)}</label>
						<div class="sf-ds-color-input-wrapper">
							<input type="text" class="sf-ds-color-preview wp-color-picker"
								   value="${value}" data-ds-field="colors.${name}" />
							<input type="text" class="sf-ds-color-hex wp-color-picker"
								   value="${value}" data-ds-field="colors.${name}" />
						</div>
					</div>
				`;
			});

			$container.html(html);
			$('.wp-color-picker').wpColorPicker({
				change: (event, ui) => {
					const $input = $(event.target);
					const field = $input.data('ds-field');
					const value = ui.color.toString();

					// Update all inputs with same field
					$('[data-ds-field="' + field + '"]').val(value);

					// Trigger change event
					$input.trigger('change');
				},
			});
		},

		/**
		 * Render typography section
		 */
		renderTypography() {
			const $container = $('#sf-typography-container');
			const typography = this.config.typography || this.defaultConfig.typography || {};
			let html = '';

			$.each(typography, (element, props) => {
				const preview = this.generateTypoPreview(element, props);
				html += `
					<div class="sf-ds-typo-item">
						<div class="sf-ds-typo-preview" style="${preview.style}">${element}</div>
						<div class="sf-ds-typo-field">
							<div>
								<label class="sf-ds-field-label">Font Family</label>
								<input type="text" class="sf-ds-field-input"
									   value="${props.font_family}"
									   data-ds-field="typography.${element}.font_family" />
							</div>
							<div class="sf-ds-typo-field-group">
								<div>
									<label class="sf-ds-field-label">Size (Desktop)</label>
									<input type="text" class="sf-ds-field-input"
										   value="${props.size_desktop}"
										   data-ds-field="typography.${element}.size_desktop" />
								</div>
								<div>
									<label class="sf-ds-field-label">Weight</label>
									<input type="number" class="sf-ds-field-input" min="100" max="900" step="100"
										   value="${props.weight}"
										   data-ds-field="typography.${element}.weight" />
								</div>
							</div>
							<div class="sf-ds-typo-field-group">
								<div>
									<label class="sf-ds-field-label">Line Height</label>
									<input type="text" class="sf-ds-field-input"
										   value="${props.line_height}"
										   data-ds-field="typography.${element}.line_height" />
								</div>
								<div>
									<label class="sf-ds-field-label">Letter Spacing</label>
									<input type="text" class="sf-ds-field-input"
										   value="${props.letter_spacing}"
										   data-ds-field="typography.${element}.letter_spacing" />
								</div>
							</div>
						</div>
					</div>
				`;
			});

			$container.html(html);
		},

		/**
		 * Render spacing section
		 */
		renderSpacing() {
			const $container = $('#sf-spacing-container');
			const spacing = this.config.spacing || this.defaultConfig.spacing || {};
			let html = '';

			$.each(spacing, (name, value) => {
				html += `
					<div class="sf-ds-spacing-item">
						<label class="sf-ds-field-label">${this.formatLabel(name)}</label>
						<div class="sf-ds-spacing-preview" style="width: ${value}; padding: 5px;">
							${value}
						</div>
						<input type="text" class="sf-ds-field-input"
							   value="${value}"
							   data-ds-field="spacing.${name}" />
					</div>
				`;
			});

			$container.html(html);
		},

		/**
		 * Render borders section
		 */
		renderBorders() {
			const $container = $('#sf-borders-container');
			const borders = this.config.borders || this.defaultConfig.borders || {};
			let html = '<div class="sf-ds-borders-section">';

			// Border Radius
			html += '<h3>Border Radius</h3>';
			if (borders.radius) {
				$.each(borders.radius, (name, value) => {
					html += `
						<div class="sf-ds-radius-item">
							<div class="sf-ds-radius-preview" style="border-radius: ${value};"></div>
							<div style="flex: 1;">
								<label class="sf-ds-field-label">${this.formatLabel(name)}</label>
								<input type="text" class="sf-ds-radius-input"
									   value="${value}"
									   data-ds-field="borders.radius.${name}" />
							</div>
						</div>
					`;
				});
			}

			html += '</div><div class="sf-ds-borders-section">';

			// Shadows
			html += '<h3>Shadows</h3>';
			if (borders.shadows) {
				$.each(this.config.shadows || this.defaultConfig.shadows || {}, (name, value) => {
					html += `
						<div class="sf-ds-shadow-item">
							<div class="sf-ds-shadow-preview" style="box-shadow: ${value};"></div>
							<div style="flex: 1;">
								<label class="sf-ds-field-label">${this.formatLabel(name)}</label>
								<input type="text" class="sf-ds-shadow-input"
									   value="${value}"
									   data-ds-field="shadows.${name}" />
							</div>
						</div>
					`;
				});
			}

			html += '</div>';
			$container.html(html);
		},

		/**
		 * Render buttons section
		 */
		renderButtons() {
			const $container = $('#sf-buttons-container');
			const buttons = this.config.buttons || this.defaultConfig.buttons || {};
			let html = '';

			$.each(buttons, (variant, props) => {
				const btnStyle = `
					background-color: ${props.bg_color};
					color: ${props.text_color};
					border: 1px solid ${props.border_color};
					padding: ${props.padding};
					border-radius: ${props.border_radius};
					font-size: ${props.font_size};
					font-weight: ${props.font_weight};
				`;

				html += `
					<div class="sf-ds-button-item">
						<div class="sf-ds-button-preview">
							<button class="sf-ds-button-preview-btn" style="${btnStyle}">
								${this.formatLabel(variant)}
							</button>
						</div>
						<div class="sf-ds-typo-field">
							<div>
								<label class="sf-ds-field-label">Background Color</label>
								<input type="text" class="sf-ds-field-input wp-color-picker"
									   value="${props.bg_color}"
									   data-ds-field="buttons.${variant}.bg_color" />
							</div>
							<div>
								<label class="sf-ds-field-label">Text Color</label>
								<input type="text" class="sf-ds-field-input wp-color-picker"
									   value="${props.text_color}"
									   data-ds-field="buttons.${variant}.text_color" />
							</div>
							<div>
								<label class="sf-ds-field-label">Padding</label>
								<input type="text" class="sf-ds-field-input"
									   value="${props.padding}"
									   data-ds-field="buttons.${variant}.padding" />
							</div>
						</div>
					</div>
				`;
			});

			$container.html(html);
			$('.wp-color-picker').wpColorPicker();
		},

		/**
		 * Render layout section
		 */
		renderLayout() {
			const $container = $('#sf-layout-container');
			const layout = this.config.layout || this.defaultConfig.layout || {};
			let html = '';

			$.each(layout, (name, value) => {
				html += `
					<div class="sf-ds-layout-item">
						<label class="sf-ds-field-label">${this.formatLabel(name)}</label>
						<input type="text" class="sf-ds-field-input"
							   value="${value}"
							   data-ds-field="layout.${name}" />
						<small style="color: #64748b; font-size: 12px;">Current: ${value}</small>
					</div>
				`;
			});

			$container.html(html);
		},

		/**
		 * Save changes
		 */
		saveChanges() {
			const sections = ['colors', 'typography', 'spacing', 'borders', 'buttons', 'layout', 'shadows'];
			const $status = $('#sf-save-status');

			sections.forEach(section => {
				const values = this.getFieldValues(section);
				if (Object.keys(values).length > 0) {
					this.saveSection(section, values);
				}
			});

			// Show save status
			$status.removeClass('error').addClass('success show');
			$status.text('Saving...');

			setTimeout(() => {
				$status.text('Saved successfully!');
				setTimeout(() => {
					$status.removeClass('show');
				}, 2000);
			}, 500);
		},

		/**
		 * Save single section
		 */
		saveSection(section, values) {
			$.ajax({
				url: this.apiUrl + 'config',
				method: 'POST',
				headers: {
					'X-WP-Nonce': this.nonce,
				},
				data: JSON.stringify({
					section: section,
					values: values,
				}),
				contentType: 'application/json',
				success: (response) => {
					if (response.config) {
						this.config = response.config;
					}
				},
				error: (error) => {
					console.error('Failed to save section:', section, error);
					const $status = $('#sf-save-status');
					$status.removeClass('success').addClass('error show');
					$status.text('Error saving changes');
				},
			});
		},

		/**
		 * Get field values for a section
		 */
		getFieldValues(section) {
			const values = {};
			$(`[data-ds-field^="${section}."]`).each((index, input) => {
				const $input = $(input);
				const field = $input.data('ds-field');
				const path = field.replace(section + '.', '').split('.');
				const value = $input.val();

				// Set nested value
				let obj = values;
				for (let i = 0; i < path.length - 1; i++) {
					obj[path[i]] = obj[path[i]] || {};
					obj = obj[path[i]];
				}
				obj[path[path.length - 1]] = value;
			});

			return values;
		},

		/**
		 * Reset section to defaults
		 */
		resetSection(section) {
			$.ajax({
				url: this.apiUrl + 'reset/' + section,
				method: 'POST',
				headers: {
					'X-WP-Nonce': this.nonce,
				},
				success: (response) => {
					if (response.config) {
						this.config = response.config;
						this.renderSections();

						const $status = $('#sf-save-status');
						$status.removeClass('error').addClass('success show');
						$status.text(section + ' reset to defaults');
						setTimeout(() => {
							$status.removeClass('show');
						}, 2000);
					}
				},
				error: (error) => {
					console.error('Failed to reset section:', error);
					alert('Error resetting section');
				},
			});
		},

		/**
		 * Export configuration
		 */
		exportConfig() {
			$.ajax({
				url: this.apiUrl + 'export',
				method: 'GET',
				headers: {
					'X-WP-Nonce': this.nonce,
				},
				success: (response) => {
					const json = JSON.stringify(response.data, null, 2);
					const blob = new Blob([json], { type: 'application/json' });
					const url = URL.createObjectURL(blob);
					const a = document.createElement('a');
					a.href = url;
					a.download = 'design-system-' + new Date().toISOString().slice(0, 10) + '.json';
					a.click();
					URL.revokeObjectURL(url);
				},
				error: (error) => {
					console.error('Failed to export:', error);
					alert('Error exporting configuration');
				},
			});
		},

		/**
		 * Import configuration
		 */
		importConfig() {
			const input = document.createElement('input');
			input.type = 'file';
			input.accept = '.json';

			input.onchange = (e) => {
				const file = e.target.files[0];
				if (!file) return;

				const reader = new FileReader();
				reader.onload = (event) => {
					try {
						const config = JSON.parse(event.target.result);
						$.ajax({
							url: this.apiUrl + 'import',
							method: 'POST',
							headers: {
								'X-WP-Nonce': this.nonce,
							},
							data: JSON.stringify({
								config: config,
							}),
							contentType: 'application/json',
							success: (response) => {
								if (response.config) {
									this.config = response.config;
									this.renderSections();

									const $status = $('#sf-save-status');
									$status.removeClass('error').addClass('success show');
									$status.text('Configuration imported successfully');
									setTimeout(() => {
										$status.removeClass('show');
									}, 2000);
								}
							},
							error: (error) => {
								console.error('Failed to import:', error);
								alert('Error importing configuration');
							},
						});
					} catch (error) {
						alert('Invalid JSON file');
					}
				};

				reader.readAsText(file);
			};

			input.click();
		},

		/**
		 * Generate typography preview styles
		 */
		generateTypoPreview(element, props) {
			return {
				style: `
					font-family: ${props.font_family};
					font-size: ${props.size_desktop};
					font-weight: ${props.weight};
					line-height: ${props.line_height};
					letter-spacing: ${props.letter_spacing};
					text-transform: ${props.transform};
				`,
			};
		},

		/**
		 * Format label from snake_case to Title Case
		 */
		formatLabel(str) {
			return str
				.replace(/_/g, ' ')
				.replace(/\b\w/g, (l) => l.toUpperCase());
		},
	};

	// Initialize on document ready
	$(document).ready(() => {
		DesignSystem.init();
	});

	// Expose to window for debugging
	window.DesignSystem = DesignSystem;

})(jQuery);
