/**
 * Elementor Templates Admin JavaScript
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

(function ($) {
  'use strict';

  const SF_Templates = {
    config: sfTemplatesConfig,
    templates: [],

    init: function () {
      this.fetchTemplates();
      this.setupEventHandlers();
    },

    fetchTemplates: function () {
      const self = this;

      $.ajax({
        url: this.config.ajax_url,
        type: 'POST',
        data: {
          action: 'sf_get_templates',
          nonce: this.config.nonce,
        },
        success: function (response) {
          if (response.success) {
            self.templates = response.data;
            self.renderTemplates();
          }
        },
        error: function () {
          self.showNotice('Error loading templates', 'error');
        },
      });
    },

    renderTemplates: function () {
      const container = $('#sf-templates-container');
      container.empty();

      if (this.templates.length === 0) {
        container.html(
          '<p style="text-align: center; color: #999;">No templates available</p>'
        );
        return;
      }

      // Group templates by category
      const grouped = this.groupBy(this.templates, 'category');

      $.each(grouped, (category, templates) => {
        const categorySection = $('<div class="sf-templates-category"></div>');
        const categoryTitle = $(
          '<h2 style="margin-top: 30px; margin-bottom: 20px; color: #333;">' +
            category +
            '</h2>'
        );
        categorySection.append(categoryTitle);

        const categoryGrid = $('<div class="sf-templates-grid"></div>');

        $.each(templates, (idx, template) => {
          const card = this.createTemplateCard(template);
          categoryGrid.append(card);
        });

        categorySection.append(categoryGrid);
        container.append(categorySection);
      });
    },

    createTemplateCard: function (template) {
      const card = $(
        '<div class="sf-template-card" data-template-id="' +
          template.id +
          '">' +
          '<div class="sf-template-preview">' +
          '<img src="' +
          template.preview +
          '" alt="' +
          template.title +
          '">' +
          '<div class="sf-template-preview-overlay">' +
          '<a href="#" class="sf-template-preview-btn sf-preview-btn">Preview</a>' +
          '</div>' +
          '</div>' +
          '<div class="sf-template-info">' +
          '<span class="sf-template-category">' +
          template.category +
          '</span>' +
          '<h3>' +
          template.title +
          '</h3>' +
          '<p class="sf-template-desc">' +
          template.description +
          '</p>' +
          '<button class="sf-template-import-btn sf-import-btn" type="button">' +
          'Import Template' +
          '</button>' +
          '</div>' +
          '</div>'
      );

      return card;
    },

    setupEventHandlers: function () {
      const self = this;

      // Preview button
      $(document).on('click', '.sf-preview-btn', function (e) {
        e.preventDefault();
        const templateId = $(this).closest('.sf-template-card').data('template-id');
        self.openModal(templateId);
      });

      // Import button
      $(document).on('click', '.sf-import-btn', function (e) {
        e.preventDefault();
        const templateId = $(this).closest('.sf-template-card').data('template-id');
        self.importTemplate(templateId, $(this));
      });

      // Modal import button
      $(document).on('click', '#sf-modal-import-btn', function (e) {
        e.preventDefault();
        const templateId = $(this).data('template-id');
        self.importTemplate(templateId, $(this));
      });

      // Close modal
      $(document).on('click', '.sf-modal-close', function () {
        $('#sf-template-modal').hide();
      });

      $(window).on('click', function (event) {
        const modal = $('#sf-template-modal')[0];
        if (event.target === modal) {
          $(modal).hide();
        }
      });
    },

    openModal: function (templateId) {
      const template = this.templates.find((t) => t.id === templateId);

      if (!template) return;

      $('#sf-modal-preview-img').attr('src', template.preview);
      $('#sf-modal-title').text(template.title);
      $('#sf-modal-description').text(template.description);
      $('#sf-modal-category').text(template.category);
      $('#sf-modal-widgets').text(
        template.widgets && template.widgets.length > 0
          ? template.widgets.join(', ')
          : 'Standard Widgets'
      );

      $('#sf-modal-import-btn')
        .data('template-id', templateId)
        .text('Import Template')
        .prop('disabled', false);

      $('#sf-template-modal').show();
    },

    importTemplate: function (templateId, button) {
      const self = this;
      const template = this.templates.find((t) => t.id === templateId);

      if (!template) return;

      const $btn = $(button);
      $btn.prop('disabled', true).addClass('importing').text(this.config.importing);

      $.ajax({
        url: this.config.ajax_url,
        type: 'POST',
        data: {
          action: 'sf_import_template',
          nonce: this.config.nonce,
          template_id: templateId,
        },
        success: function (response) {
          if (response.success) {
            self.showNotice(
              'Template imported successfully! Redirecting...',
              'success'
            );

            setTimeout(function () {
              const editUrl =
                'post.php?post=' + response.data.page_id + '&action=edit';
              window.location.href = editUrl;
            }, 1500);
          } else {
            self.showNotice(response.data || self.config.error, 'error');
            $btn.prop('disabled', false).removeClass('importing').text('Import Template');
          }
        },
        error: function () {
          self.showNotice(self.config.error, 'error');
          $btn.prop('disabled', false).removeClass('importing').text('Import Template');
        },
      });
    },

    groupBy: function (array, key) {
      return array.reduce(function (result, item) {
        if (!result[item[key]]) {
          result[item[key]] = [];
        }
        result[item[key]].push(item);
        return result;
      }, {});
    },

    showNotice: function (message, type) {
      const notice = $(
        '<div class="sf-notice ' +
          type +
          '" style="display:none;">' +
          message +
          '</div>'
      );

      $('#sf-templates-container').before(notice);
      notice.slideDown();

      setTimeout(function () {
        notice.slideUp(function () {
          $(this).remove();
        });
      }, 4000);
    },
  };

  $(document).ready(function () {
    SF_Templates.init();
  });
})(jQuery);
