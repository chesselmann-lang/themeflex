/**
 * Elementor Pro Widgets JavaScript
 * Interactive functionality for advanced widgets
 * @package Starter_Flavor
 * @since 1.0.0
 */

(function () {
	'use strict';

	// Initialize widgets on document ready
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', initializeWidgets);
	} else {
		initializeWidgets();
	}

	// Listen for dynamic element additions (Elementor live editing)
	if (window.elementorFrontend) {
		window.elementorFrontend.hooks.addAction('frontend/element_ready/global', initializeWidgets);
	}

	function initializeWidgets() {
		initBeforeAfterSliders();
		initLottieAnimations();
		initHotspotImages();
		initTimelines();
		initFlipBoxes();
		initMarqueeTickers();
		initVideos();
		initTableSorting();
	}

	/**
	 * Before/After Slider
	 */
	function initBeforeAfterSliders() {
		const sliders = document.querySelectorAll('.before-after-slider');

		sliders.forEach(slider => {
			const orientation = slider.dataset.orientation || 'horizontal';
			const handle = slider.querySelector('.ba-handle');
			const afterWrapper = slider.querySelector('.ba-after-wrapper');
			const container = slider.querySelector('.ba-container');

			if (!handle || !afterWrapper || !container) return;

			let isActive = false;

			function getPosition(e) {
				const rect = container.getBoundingClientRect();
				if (orientation === 'horizontal') {
					return Math.max(0, Math.min(100, ((e.clientX - rect.left) / rect.width) * 100));
				} else {
					return Math.max(0, Math.min(100, ((e.clientY - rect.top) / rect.height) * 100));
				}
			}

			function updatePosition(pos) {
				slider.style.setProperty('--ba-initial-pos', pos + '%');
				if (orientation === 'horizontal') {
					afterWrapper.style.width = pos + '%';
				} else {
					afterWrapper.style.height = pos + '%';
				}
			}

			// Mouse events
			handle.addEventListener('mousedown', () => { isActive = true; });
			document.addEventListener('mouseup', () => { isActive = false; });
			document.addEventListener('mousemove', (e) => {
				if (!isActive) return;
				const pos = getPosition(e);
				updatePosition(pos);
			});

			// Touch events
			handle.addEventListener('touchstart', () => { isActive = true; });
			document.addEventListener('touchend', () => { isActive = false; });
			document.addEventListener('touchmove', (e) => {
				if (!isActive || !e.touches[0]) return;
				const pos = getPosition(e.touches[0]);
				updatePosition(pos);
			});

			// Keyboard support
			handle.addEventListener('keydown', (e) => {
				const step = 2;
				const current = parseFloat(slider.style.getPropertyValue('--ba-initial-pos') || 50);
				let newPos = current;

				if (orientation === 'horizontal') {
					if (e.key === 'ArrowLeft') newPos -= step;
					if (e.key === 'ArrowRight') newPos += step;
				} else {
					if (e.key === 'ArrowUp') newPos -= step;
					if (e.key === 'ArrowDown') newPos += step;
				}

				newPos = Math.max(0, Math.min(100, newPos));
				updatePosition(newPos);
				e.preventDefault();
			});
		});
	}

	/**
	 * Lottie Animation
	 */
	function initLottieAnimations() {
		if (typeof lottie === 'undefined') {
			console.warn('Lottie Web library not loaded');
			return;
		}

		const animations = document.querySelectorAll('.lottie-animation');

		animations.forEach(container => {
			const jsonUrl = container.dataset.json;
			const trigger = container.dataset.trigger || 'none';
			const loop = container.dataset.loop === 'true';
			const speed = parseFloat(container.dataset.speed) || 1;
			const direction = parseInt(container.dataset.direction) || 1;
			const autoplay = container.dataset.autoplay === 'true';

			const animationConfig = {
				container: container,
				renderer: 'svg',
				loop: loop,
				autoplay: autoplay,
				path: jsonUrl,
			};

			const animation = lottie.loadAnimation(animationConfig);
			animation.setSpeed(speed);
			animation.setDirection(direction);

			// Handle triggers
			if (trigger === 'hover') {
				container.addEventListener('mouseenter', () => animation.play());
				container.addEventListener('mouseleave', () => animation.stop());
			} else if (trigger === 'click') {
				container.addEventListener('click', () => {
					if (animation.isPaused) {
						animation.play();
					} else {
						animation.pause();
					}
				});
			} else if (trigger === 'scroll') {
				const observer = new IntersectionObserver((entries) => {
					entries.forEach(entry => {
						if (entry.isIntersecting) {
							animation.play();
						} else {
							animation.stop();
						}
					});
				}, { threshold: 0.5 });

				observer.observe(container);
			}
		});
	}

	/**
	 * Hotspot Image
	 */
	function initHotspotImages() {
		const hotspotWrappers = document.querySelectorAll('.hotspot-image-wrapper');

		hotspotWrappers.forEach(wrapper => {
			const markers = wrapper.querySelectorAll('.hotspot-marker');

			markers.forEach(marker => {
				// Mouse events
				marker.addEventListener('mouseenter', function () {
					this.setAttribute('aria-expanded', 'true');
				});

				marker.addEventListener('mouseleave', function () {
					this.setAttribute('aria-expanded', 'false');
				});

				// Keyboard events
				marker.addEventListener('keydown', function (e) {
					if (e.key === 'Enter' || e.key === ' ') {
						const currentState = this.getAttribute('aria-expanded') === 'true';
						this.setAttribute('aria-expanded', !currentState);
						e.preventDefault();
					}
				});

				// Click to toggle
				marker.addEventListener('click', function (e) {
					e.stopPropagation();
					const currentState = this.getAttribute('aria-expanded') === 'true';
					this.setAttribute('aria-expanded', !currentState);
				});
			});

			// Close tooltip when clicking outside
			document.addEventListener('click', () => {
				markers.forEach(marker => {
					marker.setAttribute('aria-expanded', 'false');
				});
			}, true);
		});
	}

	/**
	 * Timeline - Scroll Animation
	 */
	function initTimelines() {
		const timelineItems = document.querySelectorAll('.timeline-item[data-animate="true"]');

		if (timelineItems.length === 0) return;

		const observer = new IntersectionObserver((entries) => {
			entries.forEach(entry => {
				if (entry.isIntersecting) {
					entry.target.style.animation = 'slideInUp 0.6s ease-out forwards';
					observer.unobserve(entry.target);
				}
			});
		}, {
			threshold: 0.1,
			rootMargin: '0px 0px -50px 0px',
		});

		timelineItems.forEach(item => {
			observer.observe(item);
		});
	}

	/**
	 * Flip Box
	 */
	function initFlipBoxes() {
		const flipBoxes = document.querySelectorAll('.flip-box-container');

		flipBoxes.forEach(container => {
			const box = container.querySelector('.flip-box');

			// Allow keyboard interaction
			container.addEventListener('click', function () {
				if (box.style.transform === '') {
					box.style.cursor = 'pointer';
				}
			});

			// Optional: Add keyboard support
			container.addEventListener('keydown', (e) => {
				if (e.key === 'Enter' || e.key === ' ') {
					const currentTransform = window.getComputedStyle(box).transform;
					const isFlipped = currentTransform.includes('matrix');

					if (!isFlipped) {
						const direction = container.dataset.flipDirection || 'horizontal';
						if (direction === 'horizontal') {
							box.style.transform = 'rotateY(180deg)';
						} else if (direction === 'vertical') {
							box.style.transform = 'rotateX(180deg)';
						} else {
							box.style.transform = 'rotateY(180deg) rotateX(180deg)';
						}
					} else {
						box.style.transform = '';
					}
					e.preventDefault();
				}
			});
		});
	}

	/**
	 * Marquee Ticker
	 */
	function initMarqueeTickers() {
		const tickers = document.querySelectorAll('.marquee-ticker');

		tickers.forEach(ticker => {
			const speed = parseInt(ticker.dataset.speed) || 20;
			const content = ticker.querySelector('.marquee-content');

			if (!content) return;

			// Set animation duration based on speed
			content.style.animationDuration = speed + 's';

			// Clone content for seamless loop
			const clone = content.cloneNode(true);
			ticker.appendChild(clone);

			// Keyboard support for pause/play
			ticker.addEventListener('keydown', (e) => {
				if (e.key === ' ') {
					if (content.style.animationPlayState === 'paused') {
						content.style.animationPlayState = 'running';
						clone.style.animationPlayState = 'running';
					} else {
						content.style.animationPlayState = 'paused';
						clone.style.animationPlayState = 'paused';
					}
					e.preventDefault();
				}
			});
		});
	}

	/**
	 * Video Popup
	 */
	function initVideos() {
		const playButtons = document.querySelectorAll('.video-play-btn');

		playButtons.forEach(btn => {
			const videoUrl = btn.dataset.src;
			const videoType = btn.dataset.videoType;
			const autoplay = btn.dataset.autoplay === 'true';

			btn.addEventListener('click', (e) => {
				e.preventDefault();
				e.stopPropagation();
				openVideoLightbox(videoUrl, videoType, autoplay);
			});

			// Keyboard support
			btn.addEventListener('keydown', (e) => {
				if (e.key === 'Enter' || e.key === ' ') {
					openVideoLightbox(videoUrl, videoType, autoplay);
					e.preventDefault();
				}
			});
		});

		function openVideoLightbox(url, type, autoplay) {
			const lightbox = document.createElement('div');
			lightbox.className = 'video-lightbox';
			lightbox.style.cssText = `
				position: fixed;
				top: 0;
				left: 0;
				right: 0;
				bottom: 0;
				background-color: rgba(0, 0, 0, 0.9);
				display: flex;
				align-items: center;
				justify-content: center;
				z-index: 9999;
			`;

			let videoContent = '';

			if (type === 'youtube') {
				const videoId = extractYoutubeId(url);
				videoContent = `<iframe width="90%" height="90%" style="max-width: 1200px; max-height: 600px; border: none; border-radius: 8px;" src="https://www.youtube.com/embed/${videoId}?autoplay=${autoplay ? 1 : 0}" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>`;
			} else if (type === 'vimeo') {
				const videoId = extractVimeoId(url);
				videoContent = `<iframe width="90%" height="90%" style="max-width: 1200px; max-height: 600px; border: none; border-radius: 8px;" src="https://player.vimeo.com/video/${videoId}?autoplay=${autoplay ? 1 : 0}" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>`;
			} else if (type === 'mp4') {
				videoContent = `<video width="90%" height="90%" style="max-width: 1200px; max-height: 600px;" controls ${autoplay ? 'autoplay' : ''}><source src="${url}" type="video/mp4">Your browser does not support the video tag.</video>`;
			}

			lightbox.innerHTML = videoContent + `<button class="video-lightbox-close" style="position: absolute; top: 20px; right: 20px; background: #fff; border: none; width: 40px; height: 40px; border-radius: 50%; font-size: 24px; cursor: pointer; display: flex; align-items: center; justify-content: center; z-index: 10000; line-height: 1;">&times;</button>`;

			document.body.appendChild(lightbox);

			// Close lightbox
			const closeBtn = lightbox.querySelector('.video-lightbox-close');
			closeBtn.addEventListener('click', () => {
				lightbox.remove();
			});

			lightbox.addEventListener('click', (e) => {
				if (e.target === lightbox) {
					lightbox.remove();
				}
			});

			// Close on Escape key
			const handleEscape = (e) => {
				if (e.key === 'Escape') {
					lightbox.remove();
					document.removeEventListener('keydown', handleEscape);
				}
			};

			document.addEventListener('keydown', handleEscape);
		}

		function extractYoutubeId(url) {
			const regex = /(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\n?#]+)/;
			const match = url.match(regex);
			return match ? match[1] : '';
		}

		function extractVimeoId(url) {
			const regex = /(?:vimeo\.com\/)([0-9]+)/;
			const match = url.match(regex);
			return match ? match[1] : '';
		}
	}

	/**
	 * Advanced Table Sorting
	 */
	function initTableSorting() {
		const tables = document.querySelectorAll('.advanced-table.sortable');

		tables.forEach(table => {
			const headers = table.querySelectorAll('thead th');

			headers.forEach((header, columnIndex) => {
				header.style.cursor = 'pointer';

				header.addEventListener('click', () => {
					const tbody = table.querySelector('tbody');
					const rows = Array.from(tbody.querySelectorAll('tr'));

					// Determine sort direction
					const isAscending = !header.dataset.ascending || header.dataset.ascending === 'false';
					const direction = isAscending ? 1 : -1;

					// Update header state
					headers.forEach(h => {
						h.dataset.ascending = 'false';
						h.classList.remove('sorted-asc', 'sorted-desc');
					});

					header.data.ascending = isAscending;
					header.classList.add(isAscending ? 'sorted-asc' : 'sorted-desc');

					// Sort rows
					rows.sort((a, b) => {
						const cellA = a.querySelectorAll('td')[columnIndex];
						const cellB = b.querySelectorAll('td')[columnIndex];

						let valueA = cellA.textContent.trim();
						let valueB = cellB.textContent.trim();

						// Try numeric sort
						const numA = parseFloat(valueA);
						const numB = parseFloat(valueB);

						if (!isNaN(numA) && !isNaN(numB)) {
							return direction * (numA - numB);
						}

						// String sort
						return direction * valueA.localeCompare(valueB);
					});

					// Re-append sorted rows
					rows.forEach(row => tbody.appendChild(row));
				});
			});
		});
	}

	// Utility: Setup Intersection Observer for scroll animations
	function setupScrollAnimations() {
		const elements = document.querySelectorAll('[data-animate="true"]');

		if ('IntersectionObserver' in window) {
			const observer = new IntersectionObserver((entries) => {
				entries.forEach(entry => {
					if (entry.isIntersecting) {
						entry.target.classList.add('in-view');
						observer.unobserve(entry.target);
					}
				});
			}, {
				threshold: 0.1,
				rootMargin: '0px 0px -100px 0px',
			});

			elements.forEach(element => observer.observe(element));
		}
	}

	// Initialize scroll animations
	setupScrollAnimations();

})();
