/**
 * Elementor Widgets - JavaScript Functionality
 */

(function() {
	'use strict';

	/**
	 * Blog Carousel
	 */
	function initBlogCarousel() {
		const carousels = document.querySelectorAll('.blog-carousel');

		carousels.forEach((carousel) => {
			const inner = carousel.querySelector('.carousel-inner');
			const prevBtn = carousel.querySelector('.carousel-prev');
			const nextBtn = carousel.querySelector('.carousel-next');
			const dots = carousel.querySelectorAll('.carousel-dots .dot');
			const cards = carousel.querySelectorAll('.blog-card');
			let currentIndex = 0;
			let autoplayTimer;

			if (!inner || !prevBtn || !nextBtn) return;

			const updateCarousel = () => {
				const cardWidth = cards[0].offsetWidth + 20;
				inner.scrollTo({
					left: currentIndex * cardWidth,
					behavior: 'smooth',
				});

				dots.forEach((dot, idx) => {
					dot.classList.toggle('active', idx === currentIndex);
				});
			};

			prevBtn.addEventListener('click', () => {
				currentIndex = (currentIndex - 1 + cards.length) % cards.length;
				updateCarousel();
				resetAutoplay();
			});

			nextBtn.addEventListener('click', () => {
				currentIndex = (currentIndex + 1) % cards.length;
				updateCarousel();
				resetAutoplay();
			});

			dots.forEach((dot, idx) => {
				dot.addEventListener('click', () => {
					currentIndex = idx;
					updateCarousel();
					resetAutoplay();
				});
			});

			const resetAutoplay = () => {
				clearTimeout(autoplayTimer);
				if (carousel.dataset.autoplay === 'yes') {
					startAutoplay();
				}
			};

			const startAutoplay = () => {
				const speed = parseInt(carousel.dataset.speed) || 5000;
				autoplayTimer = setInterval(() => {
					currentIndex = (currentIndex + 1) % cards.length;
					updateCarousel();
				}, speed);
			};

			if (carousel.dataset.autoplay === 'yes') {
				startAutoplay();
			}

			updateCarousel();
		});
	}

	/**
	 * Slider Widget
	 */
	function initSlider() {
		const sliders = document.querySelectorAll('.slider-wrapper');

		sliders.forEach((slider) => {
			const container = slider.querySelector('.slider-container');
			const slides = slider.querySelectorAll('.slide');
			const prevBtn = slider.querySelector('.slider-prev');
			const nextBtn = slider.querySelector('.slider-next');
			const dots = slider.querySelectorAll('.slider-dots .dot');
			let currentSlide = 0;
			let autoplayTimer;

			if (!container || slides.length === 0) return;

			const showSlide = (index) => {
				slides.forEach((slide) => slide.classList.remove('active'));
				dots.forEach((dot) => dot.classList.remove('active'));

				slides[index].classList.add('active');
				if (dots[index]) {
					dots[index].classList.add('active');
				}
			};

			const nextSlide = () => {
				currentSlide = (currentSlide + 1) % slides.length;
				showSlide(currentSlide);
			};

			const prevSlide = () => {
				currentSlide = (currentSlide - 1 + slides.length) % slides.length;
				showSlide(currentSlide);
			};

			if (prevBtn) {
				prevBtn.addEventListener('click', () => {
					prevSlide();
					resetAutoplay();
				});
			}

			if (nextBtn) {
				nextBtn.addEventListener('click', () => {
					nextSlide();
					resetAutoplay();
				});
			}

			dots.forEach((dot, idx) => {
				dot.addEventListener('click', () => {
					currentSlide = idx;
					showSlide(currentSlide);
					resetAutoplay();
				});
			});

			const resetAutoplay = () => {
				clearInterval(autoplayTimer);
				if (slider.dataset.autoplay === 'yes') {
					startAutoplay();
				}
			};

			const startAutoplay = () => {
				const interval = parseInt(slider.dataset.interval) || 5000;
				autoplayTimer = setInterval(nextSlide, interval);
			};

			if (slider.dataset.autoplay === 'yes') {
				startAutoplay();
			}

			showSlide(0);
		});
	}

	/**
	 * Progress Bars - Animated fill on scroll
	 */
	function initProgressBars() {
		const containers = document.querySelectorAll('.progress-bars-container');

		const animateProgressBars = (container) => {
			const items = container.querySelectorAll('.skill-item');

			items.forEach((item) => {
				const fill = item.querySelector('.progress-fill');
				const target = parseInt(item.dataset.percentage) || 0;

				if (fill) {
					fill.style.width = target + '%';
				}
			});
		};

		containers.forEach((container) => {
			const observer = new IntersectionObserver(
				(entries) => {
					entries.forEach((entry) => {
						if (entry.isIntersecting) {
							animateProgressBars(entry.target);
							observer.unobserve(entry.target);
						}
					});
				},
				{ threshold: 0.1 }
			);

			observer.observe(container);
		});
	}

	/**
	 * Countdown Timer
	 */
	function initCountdown() {
		const countdowns = document.querySelectorAll('.countdown-wrapper');

		countdowns.forEach((countdown) => {
			const targetDate = countdown.dataset.targetDate;
			const expiredMessage = countdown.dataset.expiredMessage;

			if (!targetDate) return;

			const updateCountdown = () => {
				const targetTime = new Date(targetDate).getTime();
				const now = new Date().getTime();
				const distance = targetTime - now;

				if (distance < 0) {
					countdown.querySelector('.countdown-expired').style.display = 'block';
					countdown.querySelectorAll('.countdown-item').forEach((item) => {
						item.style.display = 'none';
					});
					countdown.querySelectorAll('.countdown-separator').forEach((sep) => {
						sep.style.display = 'none';
					});
					return;
				}

				const days = Math.floor(distance / (1000 * 60 * 60 * 24));
				const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
				const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
				const seconds = Math.floor((distance % (1000 * 60)) / 1000);

				const updateValue = (unit, value) => {
					const element = countdown.querySelector(`[data-unit="${unit}"]`);
					if (element) {
						element.textContent = String(value).padStart(2, '0');
					}
				};

				updateValue('days', days);
				updateValue('hours', hours);
				updateValue('minutes', minutes);
				updateValue('seconds', seconds);
			};

			updateCountdown();
			setInterval(updateCountdown, 1000);
		});
	}

	/**
	 * Gallery Lightbox (uses Elementor's native lightbox)
	 */
	function initGalleryLightbox() {
		const galleries = document.querySelectorAll('.gallery-container');

		galleries.forEach((gallery) => {
			const images = gallery.querySelectorAll('.gallery-image-item img');

			images.forEach((img) => {
				const item = img.closest('.gallery-image-item');
				const overlay = item.querySelector('.gallery-overlay');

				if (overlay) {
					overlay.addEventListener('click', () => {
						img.click();
					});
				}
			});
		});
	}

	/**
	 * Initialize all widgets on document ready
	 */
	function initWidgets() {
		initBlogCarousel();
		initSlider();
		initProgressBars();
		initCountdown();
		initGalleryLightbox();
	}

	// Initialize when DOM is ready
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', initWidgets);
	} else {
		initWidgets();
	}

	// Re-initialize when Elementor editor updates live preview
	if (window.elementorFrontend) {
		window.elementorFrontend.hooks.addAction(
			'frontend/element_ready/widget',
			function() {
				initWidgets();
			}
		);
	}
})();
