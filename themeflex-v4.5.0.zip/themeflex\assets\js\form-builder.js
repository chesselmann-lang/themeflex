/**
 * Form Builder Admin JavaScript
 *
 * @since 1.0.0
 */

(function ($) {
	'use strict';

	const FormBuilder = {
		formId: window.themeflexFormData?.formId || 0,
		nonce: window.themeflexFormData?.nonce || '',
		draggedElement: null,

		/**
		 * Initialize
		 */
		init() {
			this.bindEvents();
		},

		/**
		 * Bind events
		 */
		bindEvents() {
			const self = this;

			// Add field
			$(document).on('click', '#sf-add-field-btn', function () {
				self.showFieldTypeSelector();
			});

			// Save form
			$(document).on('click', '#sf-save-form-btn', function () {
				self.saveForm();
			});

			// Remove field
			$(document).on('click', '.sf-field-remove-btn', function () {
				$(this).closest('.sf-field-item').remove();
			});

			// Toggle field editor
			$(document).on('click', '.sf-field-header', function () {
				const $editor = $(this).next('.sf-field-editor');
				const $items = $('.sf-field-editor').not($editor);
				$items.slideUp();
				$editor.slideToggle();
			});

			// Update field label on input change
			$(document).on('change', '.sf-field-editor input[name="label"]', function () {
				const $item = $(this).closest('.sf-field-item');
				const label = $(this).val() || 'Field ' + ($item.index() + 1);
				$item.find('.sf-field-label').text(label);
			});

			// Update field type (show/hide options for select/radio/checkbox)
			$(document).on('change', '.sf-field-type-select', function () {
				const type = $(this).val();
				const $item = $(this).closest('.sf-field-item');
				const $optionsRow = $item.find('.sf-field-options');

				if (['select', 'radio', 'checkbox'].includes(type)) {
					$optionsRow.show();
				} else {
					$optionsRow.hide();
				}
			});

			// Drag and drop
			$(document).on('dragstart', '.sf-field-item', function (e) {
				self.draggedElement = this;
				$(this).addClass('dragging');
			});

			$(document).on('dragend', '.sf-field-item', function (e) {
				$(this).removeClass('dragging');
				self.draggedElement = null;
			});

			$(document).on('dragover', '.sf-form-fields-list', function (e) {
				e.preventDefault();
				e.dataTransfer.dropEffect = 'move';
			});

			$(document).on('drop', '.sf-form-fields-list', function (e) {
				e.preventDefault();
				if (self.draggedElement) {
					$(this).append(self.draggedElement);
				}
			});

			// Field type selector
			$(document).on('click', '.sf-field-type-btn', function () {
				const type = $(this).data('type');
				self.addField(type);
				self.closeFieldTypeSelector();
			});
		},

		/**
		 * Show field type selector
		 */
		showFieldTypeSelector() {
			const $modal = $('#sf-field-types-modal');
			if ($modal.length) {
				const modalHTML = $modal.html();
				const $dialog = $('<div class="sf-field-type-selector-modal">' + modalHTML + '</div>');

				// Simple modal
				const $backdrop = $('<div class="sf-modal-backdrop"></div>');
				$('body').append($backdrop);
				$('body').append($dialog);

				$backdrop.on('click', () => this.closeFieldTypeSelector());
				$dialog.find('.close-modal').on('click', () => this.closeFieldTypeSelector());
			}
		},

		/**
		 * Close field type selector
		 */
		closeFieldTypeSelector() {
			$('.sf-field-type-selector-modal').remove();
			$('.sf-modal-backdrop').remove();
		},

		/**
		 * Add a new field
		 */
		addField(type) {
			const index = $('.sf-field-item').length;
			const template = $('#sf-field-template').html();

			if (template) {
				const $newField = $(template);
				$newField.attr('data-index', index);
				$newField.find('.sf-field-type-select').val(type).change();

				$('#sf-form-fields-list').append($newField);

				// Open the new field editor
				$newField.find('.sf-field-editor').slideDown();
			}
		},

		/**
		 * Get form data
		 */
		getFormData() {
			const fields = [];

			$('.sf-field-item').each(function () {
				const $item = $(this);
				const field = {
					type: $item.find('input[name="type"], select[name="type"]').val() || 'text',
					label: $item.find('input[name="label"]').val() || '',
					placeholder: $item.find('input[name="placeholder"]').val() || '',
					required: $item.find('input[name="required"]').is(':checked'),
					width: $item.find('select[name="width"]').val() || 'full',
					css_class: $item.find('input[name="css_class"]').val() || '',
					options: []
				};

				// Get options for select/radio/checkbox fields
				const optionsText = $item.find('textarea[name="options"]').val();
				if (optionsText) {
					field.options = optionsText.split('\n').map(opt => opt.trim()).filter(opt => opt);
				}

				fields.push(field);
			});

			return fields;
		},

		/**
		 * Save form via AJAX
		 */
		saveForm() {
			if (!this.formId) {
				alert('Invalid form ID');
				return;
			}

			const fields = this.getFormData();
			const email = $('#sf-form-email').val();
			const subject = $('#sf-form-subject').val();
			const successMsg = $('#sf-form-success-msg').val();
			const redirectUrl = $('#sf-form-redirect-url').val();

			const $btn = $('#sf-save-form-btn');
			const originalText = $btn.text();
			$btn.text('Saving...').prop('disabled', true);

			$.ajax({
				url: sfFormBuilderData.ajaxUrl,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'sf_save_form_fields',
					nonce: sfFormBuilderData.nonce,
					form_id: this.formId,
					fields: JSON.stringify(fields),
					email: email,
					subject: subject,
					success_msg: successMsg,
					redirect_url: redirectUrl
				},
				success: (response) => {
					if (response.success) {
						alert('Form saved successfully!');
						$btn.text(originalText).prop('disabled', false);
					} else {
						alert('Error: ' + (response.data || 'Unknown error'));
						$btn.text(originalText).prop('disabled', false);
					}
				},
				error: () => {
					alert('Error saving form');
					$btn.text(originalText).prop('disabled', false);
				}
			});
		}
	};

	// Initialize on ready
	$(document).ready(function () {
		FormBuilder.init();
	});

})(jQuery);
