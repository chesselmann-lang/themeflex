/**
 * Forms Frontend JavaScript
 *
 * @since 1.0.0
 */

(function ($) {
	'use strict';

	const Forms = {
		/**
		 * Initialize
		 */
		init() {
			this.bindEvents();
		},

		/**
		 * Bind events
		 */
		bindEvents() {
			const self = this;

			// Form submission
			$(document).on('submit', '.sf-form', function (e) {
				e.preventDefault();
				self.submitForm($(this));
			});

			// Clear error on input
			$(document).on('change input', '.sf-input, .sf-select, .sf-textarea', function () {
				$(this).closest('.sf-form-group').removeClass('has-error').find('.sf-error-message').empty();
			});
		},

		/**
		 * Submit form via AJAX
		 */
		submitForm($form) {
			const self = this;
			const formId = $form.data('form-id');
			const nonce = $form.find('input[name="nonce"]').val();

			if (!formId) {
				console.error('Form ID not found');
				return;
			}

			// Collect form data
			const formData = new FormData($form[0]);
			const data = {
				action: 'sf_submit_form',
				nonce: nonce,
				form_id: formId,
				form_data: {}
			};

			// Convert FormData to object
			formData.forEach((value, key) => {
				if (key !== 'nonce' && key !== 'sf_honeypot') {
					if (data.form_data[key]) {
						if (!Array.isArray(data.form_data[key])) {
							data.form_data[key] = [data.form_data[key]];
						}
						data.form_data[key].push(value);
					} else {
						data.form_data[key] = value;
					}
				}
			});

			// Add honeypot value (should be empty)
			data.sf_honeypot = $form.find('input[name="sf_honeypot"]').val();

			// Disable submit button
			const $submitBtn = $form.find('.sf-submit-btn');
			const originalText = $submitBtn.text();
			$submitBtn.prop('disabled', true).addClass('loading').text('Submitting...');

			// Remove previous messages
			$form.find('.sf-form-message').remove();
			$form.find('.sf-form-group').removeClass('has-error');

			// Submit
			$.ajax({
				url: sfFormsData.ajaxUrl,
				type: 'POST',
				dataType: 'json',
				data: data,
				success: (response) => {
					if (response.success) {
						const message = response.data.message || 'Thank you for your submission!';
						const successHTML = '<div class="sf-form-message success">' + self.escapeHtml(message) + '</div>';
						$form.prepend(successHTML);

						// Reset form
						$form[0].reset();
						$submitBtn.prop('disabled', false).removeClass('loading').text(originalText);

						// Redirect if specified
						if (response.data.redirect) {
							setTimeout(() => {
								window.location.href = response.data.redirect;
							}, 1500);
						} else {
							// Scroll to message
							$('html, body').animate({
								scrollTop: $form.find('.sf-form-message').offset().top - 100
							}, 300);
						}
					} else {
						self.handleError(response.data || 'An error occurred', $form);
						$submitBtn.prop('disabled', false).removeClass('loading').text(originalText);
					}
				},
				error: (xhr, status, error) => {
					self.handleError('Network error: ' + error, $form);
					$submitBtn.prop('disabled', false).removeClass('loading').text(originalText);
				}
			});
		},

		/**
		 * Handle form error
		 */
		handleError(message, $form) {
			const errorHTML = '<div class="sf-form-message error">' + this.escapeHtml(message) + '</div>';
			$form.prepend(errorHTML);

			// If message contains field name, highlight that field
			const fieldName = this.extractFieldName(message);
			if (fieldName) {
				const $field = $form.find('[name="' + fieldName + '"]');
				if ($field.length) {
					$field.closest('.sf-form-group').addClass('has-error');
					const $errorMsg = $field.closest('.sf-form-group').find('.sf-error-message');
					if ($errorMsg.length) {
						$errorMsg.text(message).show();
					} else {
						$field.closest('.sf-form-group').append('<div class="sf-error-message">' + this.escapeHtml(message) + '</div>');
					}
				}
			}

			// Scroll to message
			$('html, body').animate({
				scrollTop: $form.find('.sf-form-message').offset().top - 100
			}, 300);
		},

		/**
		 * Extract field name from error message
		 */
		extractFieldName(message) {
			const match = message.match(/^(.+)\s(?:is required|must be)/);
			if (match) {
				return match[1].toLowerCase().replace(/\s+/g, '_');
			}
			return null;
		},

		/**
		 * Escape HTML
		 */
		escapeHtml(text) {
			const div = document.createElement('div');
			div.textContent = text;
			return div.innerHTML;
		}
	};

	// Initialize on ready
	$(document).ready(function () {
		Forms.init();
	});

})(jQuery);
