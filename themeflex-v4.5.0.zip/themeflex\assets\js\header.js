/**
 * Advanced Header Functions
 */
(function() {
	'use strict';

	const Header = {
		stickyEnabled: false,
		lastScrollY: 0,
		ticking: false,

		init: function() {
			this.stickyEnabled = sfHeader.sticky === 'true' || sfHeader.sticky === true;

			if (this.stickyEnabled) {
				this.setupStickyHeader();
			}

			if (sfHeader.search_overlay === 'true' || sfHeader.search_overlay === true) {
				this.setupSearchOverlay();
			}

			if (sfHeader.offcanvas === 'true' || sfHeader.offcanvas === true) {
				this.setupOffcanvas();
			}

			this.setupMobileMenu();
		},

		setupStickyHeader: function() {
			const self = this;
			const header = document.querySelector('.site-header');

			if (!header) return;

			window.addEventListener('scroll', () => {
				self.lastScrollY = window.scrollY;

				if (!self.ticking) {
					window.requestAnimationFrame(() => {
						self.updateStickyHeader();
						self.ticking = false;
					});
					self.ticking = true;
				}
			});
		},

		updateStickyHeader: function() {
			const header = document.querySelector('.site-header');
			if (!header) return;

			if (this.lastScrollY > 100) {
				header.classList.add('sticky');

				// Apply shrink effect if enabled
				if (document.body.classList.contains('sticky-shrink-enabled')) {
					header.classList.add('shrink');
				}
			} else {
				header.classList.remove('sticky', 'shrink');
			}
		},

		setupSearchOverlay: function() {
			const overlay = document.querySelector('.sf-search-overlay');
			if (!overlay) return;

			// Find search trigger button
			const searchBtns = document.querySelectorAll('[data-search-trigger], .site-search-btn');

			searchBtns.forEach((btn) => {
				btn.addEventListener('click', (e) => {
					e.preventDefault();
					overlay.classList.add('active');
					overlay.querySelector('input[type="search"]').focus();
				});
			});

			// Close overlay
			const closeBtn = overlay.querySelector('.sf-search-overlay-close');
			if (closeBtn) {
				closeBtn.addEventListener('click', () => {
					overlay.classList.remove('active');
				});
			}

			// Close on Escape key
			document.addEventListener('keydown', (e) => {
				if (e.key === 'Escape' && overlay.classList.contains('active')) {
					overlay.classList.remove('active');
				}
			});

			// Search functionality
			const searchForm = overlay.querySelector('.sf-search-form');
			const searchInput = overlay.querySelector('input[type="search"]');
			const resultsContainer = overlay.querySelector('.sf-search-results');

			if (searchInput) {
				searchInput.addEventListener('keyup', (e) => {
					const query = e.target.value.trim();

					if (query.length < 2) {
						resultsContainer.innerHTML = '';
						return;
					}

					this.searchPosts(query, resultsContainer);
				});
			}
		},

		searchPosts: function(query, container) {
			// Use WP REST API or AJAX for search
			const searchUrl = new URL(window.location.href);
			searchUrl.searchParams.set('s', query);
			searchUrl.searchParams.set('rest_route', '/wp/v2/search');

			fetch(searchUrl)
				.then(response => response.json())
				.then(results => {
					let html = '';

					if (results.length === 0) {
						html = '<p>No results found.</p>';
					} else {
						results.slice(0, 5).forEach(result => {
							html += `<a href="${result.url}" class="sf-search-result">
								<h4>${result.title}</h4>
								<p>${result.content || ''}</p>
							</a>`;
						});
					}

					container.innerHTML = html;
				})
				.catch(() => {
					container.innerHTML = '<p>Error fetching results.</p>';
				});
		},

		setupOffcanvas: function() {
			const menu = document.querySelector('.sf-offcanvas-menu');
			const overlay = document.querySelector('.sf-offcanvas-overlay');

			if (!menu) return;

			// Find trigger button
			const trigger = document.querySelector('.mobile-menu-toggle, [data-offcanvas-trigger]');

			if (trigger) {
				trigger.addEventListener('click', (e) => {
					e.preventDefault();
					menu.classList.add('active');
					overlay.classList.add('active');
					document.body.style.overflow = 'hidden';
				});
			}

			// Close button
			const closeBtn = menu.querySelector('.sf-offcanvas-close');
			if (closeBtn) {
				closeBtn.addEventListener('click', () => {
					this.closeOffcanvas();
				});
			}

			// Close on overlay click
			if (overlay) {
				overlay.addEventListener('click', () => {
					this.closeOffcanvas();
				});
			}

			// Close menu links
			menu.querySelectorAll('a').forEach(link => {
				link.addEventListener('click', () => {
					this.closeOffcanvas();
				});
			});

			// Close on Escape
			document.addEventListener('keydown', (e) => {
				if (e.key === 'Escape' && menu.classList.contains('active')) {
					this.closeOffcanvas();
				}
			});
		},

		closeOffcanvas: function() {
			const menu = document.querySelector('.sf-offcanvas-menu');
			const overlay = document.querySelector('.sf-offcanvas-overlay');

			if (menu) menu.classList.remove('active');
			if (overlay) overlay.classList.remove('active');
			document.body.style.overflow = '';
		},

		setupMobileMenu: function() {
			// Responsive menu handling
			const menuBtn = document.querySelector('.site-header-menu-btn, .hamburger-btn');

			if (menuBtn) {
				menuBtn.addEventListener('click', () => {
					const menu = document.querySelector('.site-navigation, .nav-menu');
					if (menu) {
						menu.classList.toggle('active');
					}
				});
			}
		}
	};

	// Initialize
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', () => {
			Header.init();
		});
	} else {
		Header.init();
	}

	// Expose to window
	window.sfHeader = Header;
})();
