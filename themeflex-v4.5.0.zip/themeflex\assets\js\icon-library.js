(function($) {
	'use strict';

	const IconLibrary = {
		init: function() {
			this.bindCopyToClipboard();
		},

		bindCopyToClipboard: function() {
			$(document).on('click', '.sf-icon-code', this.onCodeClick.bind(this));
		},

		onCodeClick: function(e) {
			const $code = $(e.currentTarget);
			const text = $code.text();

			// Copy to clipboard
			const temp = $('<textarea/>').val(text);
			$('body').append(temp);
			temp.select();
			document.execCommand('copy');
			temp.remove();

			// Show feedback
			const originalText = $code.text();
			$code.text('Copied!');

			setTimeout(() => {
				$code.text(originalText);
			}, 2000);
		}
	};

	$(function() {
		IconLibrary.init();
	});
})(jQuery);
