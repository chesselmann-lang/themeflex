/**
 * ThemeFlex — Interaction Engine
 * 
 * IntersectionObserver-based animation system, parallax,
 * 3D tilt, sticky header, cursor effects, stagger animations.
 * 
 * Zero dependencies — Vanilla JS.
 * 
 * @package Starter_Flavor
 * @since   2.0.0
 */
'use strict';

(function () {

    /* ── ENTRANCE ANIMATIONS ──────────────────────────────────────────── */
    function initAnimations() {
        const els = document.querySelectorAll('[data-sf-animate]');
        if (!els.length) return;

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (!entry.isIntersecting) return;
                const el = entry.target;
                const dur = el.dataset.sfDuration || 'normal';
                const durations = { fast: '300ms', normal: '600ms', slow: '900ms' };
                el.style.transitionDuration = durations[dur] || '600ms';
                el.classList.add('sf-animated');
                // Don't observe again for "once" (default)
                if (el.dataset.sfOnce !== 'false') observer.unobserve(el);
            });
        }, {
            threshold: parseFloat(document.documentElement.dataset.sfThreshold || '0.15'),
            rootMargin: '0px 0px -40px 0px',
        });

        els.forEach(el => observer.observe(el));
    }

    /* ── STAGGER CHILDREN ─────────────────────────────────────────────── */
    function initStagger() {
        document.querySelectorAll('[data-sf-stagger]').forEach(parent => {
            const delay = parseInt(parent.dataset.sfStagger) || 80;
            const selector = parent.dataset.sfStaggerTarget || '[data-sf-animate]';
            const children = parent.querySelectorAll(selector);
            children.forEach((child, i) => {
                child.style.transitionDelay = (i * delay) + 'ms';
            });
        });
    }

    /* ── PARALLAX ─────────────────────────────────────────────────────── */
    function initParallax() {
        const sections = document.querySelectorAll('.sf-parallax');
        if (!sections.length || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

        const update = () => {
            sections.forEach(section => {
                const rect = section.getBoundingClientRect();
                if (rect.bottom < 0 || rect.top > window.innerHeight) return;
                const speed = parseFloat(section.dataset.sfParallax || '0.3');
                const offset = (rect.top / window.innerHeight) * speed * 100;
                const inner = section.querySelector('.sf-parallax-inner');
                if (inner) inner.style.transform = `translateY(${offset}px)`;
            });
        };
        window.addEventListener('scroll', update, { passive: true });
        update();
    }

    /* ── 3D TILT (hover effect) ───────────────────────────────────────── */
    function initTilt() {
        if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

        document.querySelectorAll('.sf-hover-tilt').forEach(el => {
            const max = parseFloat(el.dataset.sfTiltMax || '12');
            const glowColor = el.dataset.sfTiltGlow || null;

            el.addEventListener('mousemove', e => {
                const rect = el.getBoundingClientRect();
                const cx = (e.clientX - rect.left) / rect.width  - 0.5;
                const cy = (e.clientY - rect.top)  / rect.height - 0.5;
                el.style.transform = `perspective(800px) rotateY(${cx * max * 2}deg) rotateX(${-cy * max * 2}deg) scale(1.02)`;
                if (glowColor) el.style.boxShadow = `${cx * 20}px ${cy * 20}px 40px ${glowColor}`;
            });
            el.addEventListener('mouseleave', () => {
                el.style.transform = '';
                el.style.boxShadow = '';
            });
        });
    }

    /* ── STICKY HEADER ────────────────────────────────────────────────── */
    function initStickyHeader() {
        const header = document.querySelector('.site-header[data-sf-sticky]');
        if (!header) return;

        const offset = parseInt(header.dataset.sfStickyOffset || '80');
        let lastScroll = 0;

        window.addEventListener('scroll', () => {
            const current = window.scrollY;
            if (current > offset) {
                header.classList.add('sf-sticky');
                header.classList.toggle('sf-scrolled-down', current > lastScroll && current > offset + 100);
                header.classList.toggle('sf-scrolled-up',   current < lastScroll);
            } else {
                header.classList.remove('sf-sticky', 'sf-scrolled-down', 'sf-scrolled-up');
            }
            lastScroll = Math.max(0, current);
        }, { passive: true });
    }

    /* ── CUSTOM CURSOR ────────────────────────────────────────────────── */
    function initCursor() {
        if (!document.documentElement.dataset.sfCursor) return;
        if (window.matchMedia('(pointer: coarse)').matches) return; // no cursor on touch

        const dot  = document.createElement('div');
        const ring = document.createElement('div');
        dot.className  = 'sf-cursor-dot';
        ring.className = 'sf-cursor-ring';
        document.body.append(dot, ring);

        let mx = 0, my = 0, rx = 0, ry = 0;

        document.addEventListener('mousemove', e => {
            mx = e.clientX; my = e.clientY;
            dot.style.left  = mx + 'px';
            dot.style.top   = my + 'px';
        });

        // Ring follows with lag
        (function animateRing() {
            rx += (mx - rx) * 0.15;
            ry += (my - ry) * 0.15;
            ring.style.left = rx + 'px';
            ring.style.top  = ry + 'px';
            requestAnimationFrame(animateRing);
        })();

        // Scale on interactive elements
        const interactive = 'a,button,.sf-hover-tilt,[data-sf-cursor-grow]';
        document.addEventListener('mouseover', e => {
            if (e.target.closest(interactive)) {
                dot.style.transform  = 'translate(-50%,-50%) scale(2.5)';
                ring.style.transform = 'translate(-50%,-50%) scale(1.6)';
                ring.style.opacity   = '0.2';
            }
        });
        document.addEventListener('mouseout', e => {
            if (e.target.closest(interactive)) {
                dot.style.transform  = 'translate(-50%,-50%)';
                ring.style.transform = 'translate(-50%,-50%)';
                ring.style.opacity   = '0.4';
            }
        });
    }

    /* ── COUNTER ANIMATION ────────────────────────────────────────────── */
    function initCounters() {
        const counters = document.querySelectorAll('[data-sf-counter]');
        if (!counters.length) return;

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (!entry.isIntersecting) return;
                const el   = entry.target;
                const end  = parseFloat(el.dataset.sfCounter);
                const dur  = parseInt(el.dataset.sfDuration || '1600');
                const dec  = parseInt(el.dataset.sfDecimals || '0');
                const step = 16;
                const inc  = (end / (dur / step));
                let cur    = 0;
                const fmt  = n => dec > 0 ? n.toFixed(dec) : Math.floor(n).toLocaleString();
                const timer = setInterval(() => {
                    cur += inc;
                    if (cur >= end) { cur = end; clearInterval(timer); }
                    el.textContent = fmt(cur);
                }, step);
                observer.unobserve(el);
            });
        }, { threshold: 0.5 });

        counters.forEach(el => observer.observe(el));
    }

    /* ── SCROLL PROGRESS BAR ──────────────────────────────────────────── */
    function initScrollProgress() {
        const bar = document.getElementById('sf-scroll-progress');
        if (!bar) return;
        window.addEventListener('scroll', () => {
            const pct = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
            bar.style.width = Math.min(100, pct) + '%';
        }, { passive: true });
    }

    /* ── BACK TO TOP ──────────────────────────────────────────────────── */
    function initBackToTop() {
        const btn = document.getElementById('back-to-top') || document.querySelector('.sf-back-to-top');
        if (!btn) return;
        window.addEventListener('scroll', () => {
            btn.classList.toggle('visible', window.scrollY > 400);
        }, { passive: true });
        btn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
    }

    /* ── SMOOTH ANCHOR SCROLL ─────────────────────────────────────────── */
    function initSmoothAnchors() {
        document.querySelectorAll('a[href^="#"]').forEach(link => {
            link.addEventListener('click', e => {
                const target = document.querySelector(link.getAttribute('href'));
                if (!target) return;
                e.preventDefault();
                const header = document.querySelector('.site-header.sf-sticky');
                const offset = header ? header.offsetHeight + 16 : 80;
                window.scrollTo({
                    top: target.getBoundingClientRect().top + window.scrollY - offset,
                    behavior: 'smooth',
                });
            });
        });
    }

    /* ── ONE-PAGE NAV HIGHLIGHT ───────────────────────────────────────── */
    function initOnePageNav() {
        const sections = document.querySelectorAll('section[id], div[id][data-sf-section]');
        if (!sections.length) return;

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (!entry.isIntersecting) return;
                const id = entry.target.id;
                document.querySelectorAll('.site-navigation a').forEach(a => {
                    a.classList.toggle('sf-nav-active', a.getAttribute('href') === '#' + id);
                });
            });
        }, { threshold: 0.4 });

        sections.forEach(s => observer.observe(s));
    }

    /* ── LAZY LOAD ENHANCEMENT ────────────────────────────────────────── */
    function initLazyLoad() {
        if ('loading' in HTMLImageElement.prototype) return; // native support
        const imgs = document.querySelectorAll('img[loading="lazy"]');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (!entry.isIntersecting) return;
                const img = entry.target;
                if (img.dataset.src) img.src = img.dataset.src;
                observer.unobserve(img);
            });
        });
        imgs.forEach(img => observer.observe(img));
    }

    /* ── INITIALISE ────────────────────────────────────────────────────── */
    function init() {
        initAnimations();
        initStagger();
        initParallax();
        initTilt();
        initStickyHeader();
        initCursor();
        initCounters();
        initScrollProgress();
        initBackToTop();
        initSmoothAnchors();
        initOnePageNav();
        initLazyLoad();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Re-init on Elementor frontend init (for editor preview)
    window.addEventListener('elementor/frontend/init', () => {
        setTimeout(init, 300);
    });

    // Public API — usable by extensions
    window.sfInteraction = { initAnimations, initTilt, initCounters, initParallax };

})();
