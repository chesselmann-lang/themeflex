/**
 * ThemeFlex Theme - Mobile Navigation Accessibility
 *
 * @package Starter_Flavor
 * @since 1.0.0
 * @description Mobile menu keyboard and accessibility enhancements
 */

(function () {
	'use strict';

	const MobileNavAccessibility = {
		/**
		 * Initialize mobile navigation accessibility
		 *
		 * @since 1.0.0
		 */
		init: function () {
			this.setupMenuButton();
			this.setupMenuItems();
			this.setupSubmenuButtons();
		},

		/**
		 * Setup menu toggle button accessibility
		 *
		 * @since 1.0.0
		 */
		setupMenuButton: function () {
			const menuButtons = document.querySelectorAll(
				'.menu-toggle, .nav-toggle, [aria-controls*="menu"]'
			);

			menuButtons.forEach((button) => {
				// Ensure button has proper ARIA attributes
				if (!button.hasAttribute('aria-label')) {
					button.setAttribute('aria-label', 'Toggle navigation menu');
				}

				if (!button.hasAttribute('aria-expanded')) {
					button.setAttribute('aria-expanded', 'false');
				}

				// Get the menu element
				const menuId = button.getAttribute('aria-controls');
				const menu = menuId ? document.getElementById(menuId) : null;

				if (!menu) {
					return;
				}

				// Toggle aria-expanded on click
				button.addEventListener('click', () => {
					const isExpanded = button.getAttribute('aria-expanded') === 'true';
					button.setAttribute('aria-expanded', !isExpanded);

					if (!isExpanded) {
						// When opening, focus first menu item
						setTimeout(() => {
							const firstItem = menu.querySelector('a, button, [role="menuitem"]');
							if (firstItem) {
								firstItem.focus();
							}
						}, 100);
					}
				});

				// Close menu on Escape
				document.addEventListener('keydown', (event) => {
					if (event.key === 'Escape') {
						const isExpanded = button.getAttribute('aria-expanded') === 'true';
						if (isExpanded) {
							button.setAttribute('aria-expanded', 'false');
							button.focus();
						}
					}
				});
			});
		},

		/**
		 * Setup menu items with proper ARIA roles
		 *
		 * @since 1.0.0
		 */
		setupMenuItems: function () {
			const menuItems = document.querySelectorAll(
				'.mobile-menu a, .mobile-nav a, .sidebar-menu a'
			);

			menuItems.forEach((item) => {
				// Ensure items are keyboard accessible
				if (!item.hasAttribute('tabindex')) {
					item.setAttribute('tabindex', '0');
				}

				// Add role if not present
				if (!item.hasAttribute('role')) {
					item.setAttribute('role', 'menuitem');
				}

				// Handle click
				item.addEventListener('click', () => {
					// Close mobile menu after navigation
					const menuButton = document.querySelector('.menu-toggle, .nav-toggle');
					if (menuButton) {
						menuButton.setAttribute('aria-expanded', 'false');
					}
				});
			});
		},

		/**
		 * Setup submenu buttons for accessibility
		 *
		 * @since 1.0.0
		 */
		setupSubmenuButtons: function () {
			const submenus = document.querySelectorAll(
				'.mobile-menu ul ul, .mobile-nav ul ul, .sidebar-menu ul ul'
			);

			submenus.forEach((submenu) => {
				const parentItem = submenu.parentElement;
				const parentLink = parentItem.querySelector('a');

				if (!parentLink) {
					return;
				}

				// Add submenu toggle button
				let toggleButton = parentItem.querySelector('.submenu-toggle');

				if (!toggleButton) {
					toggleButton = document.createElement('button');
					toggleButton.className = 'submenu-toggle';
					toggleButton.setAttribute('aria-expanded', 'false');
					toggleButton.setAttribute('aria-label', 'Expand submenu');
					toggleButton.innerHTML =
						'<span class="screen-reader-text">Submenu</span>';

					parentItem.appendChild(toggleButton);
				}

				// Store submenu in data attribute for reference
				toggleButton.setAttribute(
					'aria-controls',
					submenu.id || 'submenu-' + Math.random().toString(36).substr(2, 9)
				);

				// Toggle submenu on button click
				toggleButton.addEventListener('click', (event) => {
					event.preventDefault();
					event.stopPropagation();

					const isExpanded =
						toggleButton.getAttribute('aria-expanded') === 'true';
					toggleButton.setAttribute('aria-expanded', !isExpanded);

					if (!isExpanded) {
						// When opening, focus first submenu item
						setTimeout(() => {
							const firstSubItem = submenu.querySelector(
								'a, button, [role="menuitem"]'
							);
							if (firstSubItem) {
								firstSubItem.focus();
							}
						}, 100);
					}
				});

				// Make submenu accessible
				submenu.setAttribute('role', 'menu');
				submenu.style.display = isExpanded ? 'block' : 'none';
			});
		},

		/**
		 * Add keyboard navigation support
		 *
		 * @since 1.0.0
		 * @param {HTMLElement} menu Menu element
		 */
		addKeyboardNavigation: function (menu) {
			const items = menu.querySelectorAll('[role="menuitem"]');

			items.forEach((item, index) => {
				item.addEventListener('keydown', (event) => {
					switch (event.key) {
						case 'ArrowDown':
							event.preventDefault();
							if (index + 1 < items.length) {
								items[index + 1].focus();
							}
							break;

						case 'ArrowUp':
							event.preventDefault();
							if (index - 1 >= 0) {
								items[index - 1].focus();
							}
							break;

						case 'Home':
							event.preventDefault();
							items[0].focus();
							break;

						case 'End':
							event.preventDefault();
							items[items.length - 1].focus();
							break;

						case 'Escape':
							event.preventDefault();
							menu.parentElement.querySelector('.menu-toggle').focus();
							break;

						default:
							break;
					}
				});
			});
		},

		/**
		 * Close mobile menu
		 *
		 * @since 1.0.0
		 */
		closeMenu: function () {
			const menuButton = document.querySelector('.menu-toggle, .nav-toggle');
			const menu = menuButton
				? document.getElementById(menuButton.getAttribute('aria-controls'))
				: null;

			if (menuButton && menu) {
				menuButton.setAttribute('aria-expanded', 'false');
				menu.setAttribute('aria-hidden', 'true');
			}
		},

		/**
		 * Open mobile menu
		 *
		 * @since 1.0.0
		 */
		openMenu: function () {
			const menuButton = document.querySelector('.menu-toggle, .nav-toggle');
			const menu = menuButton
				? document.getElementById(menuButton.getAttribute('aria-controls'))
				: null;

			if (menuButton && menu) {
				menuButton.setAttribute('aria-expanded', 'true');
				menu.setAttribute('aria-hidden', 'false');

				// Focus first menu item
				setTimeout(() => {
					const firstItem = menu.querySelector(
						'a, button, [role="menuitem"]'
					);
					if (firstItem) {
						firstItem.focus();
					}
				}, 100);
			}
		},
	};

	// Initialize on DOM ready
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', () => {
			MobileNavAccessibility.init();
		});
	} else {
		MobileNavAccessibility.init();
	}

	// Export for external use
	window.ThemeFlexMobileNavAccessibility = MobileNavAccessibility;
})();
