/**
 * File navigation.js.
 *
 * Handles toggling the navigation menu for small screens and
 * accessibility for keyboard navigation.
 */

(function() {
	const toggle = document.querySelector('.menu-toggle');
	const menu = document.querySelector('#primary-menu');

	// Early exit if the menu does not exist.
	if (!menu) {
		return;
	}

	// Hide menu toggle button if menu is empty and string is missing.
	if (!toggle || 0 === menu.children.length) {
		toggle?.classList.add('hidden');
	}

	// Allow for additional setup by hooking to the init.
	document.body.addEventListener('post-load', function() {
		// Re-check toggle button visibility
		if (toggle && 0 === menu.children.length) {
			toggle.classList.add('hidden');
		}
	});

	toggle?.addEventListener('click', function() {
		menu.classList.toggle('toggled');
		toggle.setAttribute('aria-expanded', menu.classList.contains('toggled') ? 'true' : 'false');
	});

	// Get all menu items that have children
	const menuItems = menu.querySelectorAll('.menu-item-has-children > a');

	menuItems.forEach(function(item) {
		item.addEventListener('click', function(e) {
			e.preventDefault();
			const parent = item.parentElement;
			parent.classList.toggle('menu-open');
		});
	});

	// Close menu when clicking outside
	document.addEventListener('click', function(e) {
		if (!toggle?.contains(e.target) && !menu.contains(e.target)) {
			menu.classList.remove('toggled');
			toggle?.setAttribute('aria-expanded', 'false');
		}
	});

	// Close menu on Escape key
	document.addEventListener('keydown', function(e) {
		if (e.key === 'Escape') {
			menu.classList.remove('toggled');
			toggle?.setAttribute('aria-expanded', 'false');
		}
	});
})();
