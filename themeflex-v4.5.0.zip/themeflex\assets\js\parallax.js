/**
 * Parallax Background Scroll Handler
 */
(function() {
	'use strict';

	const Parallax = {
		elements: [],
		scrollY: 0,
		ticking: false,

		init: function() {
			this.cacheElements();
			this.setupScrollListener();
			this.update();
		},

		cacheElements: function() {
			this.elements = Array.from(document.querySelectorAll('[data-parallax]'));
		},

		setupScrollListener: function() {
			const self = this;

			window.addEventListener('scroll', () => {
				self.scrollY = window.scrollY || window.pageYOffset;

				if (!self.ticking) {
					window.requestAnimationFrame(() => {
						self.update();
						self.ticking = false;
					});
					self.ticking = true;
				}
			});

			window.addEventListener('resize', () => {
				self.cacheElements();
			});
		},

		update: function() {
			this.elements.forEach((element) => {
				this.updateElement(element);
			});
		},

		updateElement: function(element) {
			const rect = element.getBoundingClientRect();
			const elementTop = rect.top + this.scrollY;
			const elementHeight = rect.height;
			const windowHeight = window.innerHeight;

			// Only update if element is in viewport
			if (elementTop + elementHeight > this.scrollY && elementTop < this.scrollY + windowHeight) {
				const speed = parseFloat(element.getAttribute('data-parallax-speed')) || 0.5;
				const yOffset = (this.scrollY - elementTop) * speed;

				element.style.transform = `translate3d(0, ${yOffset}px, 0)`;
				element.style.willChange = 'transform';
			}
		}
	};

	// Initialize when DOM is ready
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', () => {
			Parallax.init();
		});
	} else {
		Parallax.init();
	}

	// Expose to window
	window.sfParallax = Parallax;
})();
