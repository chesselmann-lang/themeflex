/**
 * Performance Pro Frontend Script
 *
 * Lazy loading, LCP detection, and performance optimizations
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

(function() {
	'use strict';

	/**
	 * Performance Pro Manager
	 */
	const sfPerformance = {
		/**
		 * Initialize performance optimizations
		 */
		init: function() {
			this.setupLazyLoading();
			this.detectLCP();
			this.setupResourceHints();
		},

		/**
		 * Setup lazy loading for images
		 */
		setupLazyLoading: function() {
			// Use Intersection Observer for lazy loading
			if (!('IntersectionObserver' in window)) {
				// Fallback for older browsers
				this.lazyLoadFallback();
				return;
			}

			const imageObserver = new IntersectionObserver((entries, observer) => {
				entries.forEach(entry => {
					if (entry.isIntersecting) {
						const img = entry.target;

						// Load from data-src or src
						if (img.dataset.src) {
							img.src = img.dataset.src;
							img.removeAttribute('data-src');
						}

						// Handle srcset
						if (img.dataset.srcset) {
							img.srcset = img.dataset.srcset;
							img.removeAttribute('data-srcset');
						}

						// Add loaded class
						img.classList.add('sf-lazy-loaded');
						observer.unobserve(img);
					}
				});
			}, {
				rootMargin: '50px' // Start loading 50px before image enters viewport
			});

			// Observe all lazy images
			document.querySelectorAll('img[loading="lazy"]').forEach(img => {
				imageObserver.observe(img);
			});
		},

		/**
		 * Fallback lazy loading for older browsers
		 */
		lazyLoadFallback: function() {
			const images = document.querySelectorAll('img[data-src]');
			images.forEach(img => {
				if (img.dataset.src) {
					img.src = img.dataset.src;
					img.removeAttribute('data-src');
				}
			});
		},

		/**
		 * Detect and mark Largest Contentful Paint (LCP) image
		 */
		detectLCP: function() {
			// Use PerformanceObserver if available
			if (!('PerformanceObserver' in window)) {
				return;
			}

			try {
				const observer = new PerformanceObserver((list) => {
					const entries = list.getEntries();
					const lastEntry = entries[entries.length - 1];

					if (lastEntry.element) {
						lastEntry.element.classList.add('sf-lcp-element');
					}
				});

				observer.observe({ entryTypes: ['largest-contentful-paint'] });
			} catch (e) {
				// LCP not supported
			}
		},

		/**
		 * Setup resource hints (dns-prefetch, preconnect, preload)
		 */
		setupResourceHints: function() {
			// Check Web Fonts
			const fontLinks = document.querySelectorAll('link[href*="fonts"]');
			fontLinks.forEach(link => {
				const href = link.getAttribute('href');
				if (href && !link.hasAttribute('rel')) {
					link.setAttribute('rel', 'preload');
					link.setAttribute('as', 'style');
				}
			});
		},

		/**
		 * Log Web Vitals (Core Web Vitals)
		 */
		logWebVitals: function() {
			// Largest Contentful Paint (LCP)
			if ('PerformanceObserver' in window) {
				try {
					const lcpObserver = new PerformanceObserver((list) => {
						const entries = list.getEntries();
						const lastEntry = entries[entries.length - 1];
						this.logVital('LCP', lastEntry.renderTime || lastEntry.loadTime);
					});
					lcpObserver.observe({ entryTypes: ['largest-contentful-paint'] });
				} catch (e) {
					// LCP not supported
				}
			}

			// Cumulative Layout Shift (CLS)
			if ('PerformanceObserver' in window) {
				try {
					let clsValue = 0;
					const clsObserver = new PerformanceObserver((list) => {
						for (const entry of list.getEntries()) {
							if (!entry.hadRecentInput) {
								clsValue += entry.value;
							}
						}
						this.logVital('CLS', clsValue);
					});
					clsObserver.observe({ entryTypes: ['layout-shift'] });
				} catch (e) {
					// CLS not supported
				}
			}

			// First Input Delay (FID) / Interaction to Next Paint (INP)
			if ('PerformanceObserver' in window) {
				try {
					const fpObserver = new PerformanceObserver((list) => {
						for (const entry of list.getEntries()) {
							this.logVital('FID/INP', entry.processingDuration);
						}
					});
					fpObserver.observe({ entryTypes: ['first-input', 'event'] });
				} catch (e) {
					// FID/INP not supported
				}
			}
		},

		/**
		 * Log vital metrics (for debugging)
		 */
		logVital: function(name, value) {
			if (window.sfPerformanceDebug) {
				console.log(`Web Vital [${name}]: ${value.toFixed(2)}ms`);
			}
		}
	};

	/**
	 * Initialize on DOM ready or immediately if already loaded
	 */
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', function() {
			sfPerformance.init();
		});
	} else {
		sfPerformance.init();
	}

	// Expose to window for external use
	window.sfPerformance = sfPerformance;
})();
