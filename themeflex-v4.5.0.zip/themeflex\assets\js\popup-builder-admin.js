/**
 * Popup Builder Admin Script
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

(function($) {
	'use strict';

	$(document).ready(function() {
		// Conditional field visibility
		const triggerSelect = $('#trigger_type');
		const displaySelect = $('#display_rule');

		// Update trigger condition visibility
		function updateTriggerFields() {
			const selected = triggerSelect.val();
			$('.sf-trigger-condition').hide();

			if (selected) {
				$('.sf-trigger-condition[data-trigger="' + selected + '"]').show();
			}
		}

		// Update display rule fields visibility
		function updateDisplayFields() {
			const selected = displaySelect.val();
			$('.sf-display-condition').hide();

			if (selected && selected !== 'all_pages') {
				$('.sf-display-condition[data-display="' + selected + '"]').show();
			}
		}

		// Event listeners
		triggerSelect.on('change', updateTriggerFields);
		displaySelect.on('change', updateDisplayFields);

		// Initialize on page load
		updateTriggerFields();
		updateDisplayFields();

		// Opacity range slider display
		const opacityInput = $('#overlay_opacity');
		if (opacityInput.length) {
			opacityInput.on('input change', function() {
				const value = parseFloat($(this).val()).toFixed(1);
				$('#opacity-value').text(value);
			});
		}

		// Multi-select handling
		const multiSelects = $('select[multiple]');
		if (multiSelects.length) {
			multiSelects.each(function() {
				const $select = $(this);
				$select.wrap('<div class="sf-multi-select-wrapper"></div>');
			});
		}

		// Preview popup trigger
		const previewBtn = $('<button type="button" class="button button-secondary" id="sf-popup-preview">')
			.text('Preview Popup')
			.insertAfter('input[type="submit"]');

		previewBtn.on('click', function(e) {
			e.preventDefault();
			previewPopup();
		});

		/**
		 * Preview popup in modal
		 */
		function previewPopup() {
			const title = $('#title').val() || 'Popup Preview';
			const content = $('#content').val() || 'Popup content preview...';
			const position = $('#position').val() || 'center';
			const layout = $('#layout').val() || 'modal';
			const animation = $('#animation').val() || 'fade';
			const width = $('#popup_width').val() || 'medium';

			const previewHTML = `
				<div id="sf-preview-overlay" style="
					position: fixed;
					top: 0;
					left: 0;
					width: 100%;
					height: 100%;
					background-color: rgba(0, 0, 0, 0.5);
					z-index: 9998;
					display: flex;
					align-items: center;
					justify-content: center;
				">
					<div id="sf-preview-popup" style="
						background: white;
						padding: 30px;
						border-radius: 8px;
						box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
						max-width: 600px;
						width: 90%;
						max-height: 80vh;
						overflow-y: auto;
						position: relative;
						animation: previewFadeIn 0.4s ease-in-out;
					">
						<button id="sf-preview-close" style="
							position: absolute;
							top: 15px;
							right: 15px;
							background: transparent;
							border: none;
							width: 32px;
							height: 32px;
							cursor: pointer;
							font-size: 24px;
							padding: 0;
							line-height: 1;
						">×</button>
						<h2 style="margin-top: 0;">${title}</h2>
						<div>${content}</div>
					</div>
				</div>
				<style>
					@keyframes previewFadeIn {
						from { opacity: 0; transform: scale(0.9); }
						to { opacity: 1; transform: scale(1); }
					}
				</style>
			`;

			// Append to body
			$('body').append(previewHTML);

			// Close preview
			$('#sf-preview-close, #sf-preview-overlay').on('click', function(e) {
				if (e.target === this || e.target.id === 'sf-preview-close') {
					$('#sf-preview-overlay').remove();
				}
			});

			// ESC to close
			$(document).on('keydown.sfPreview', function(e) {
				if (e.key === 'Escape') {
					$('#sf-preview-overlay').remove();
					$(document).off('keydown.sfPreview');
				}
			});
		}

		// Form validation
		$('#post').on('submit', function(e) {
			const triggerType = $('#trigger_type').val();
			const displayRule = $('#display_rule').val();

			if (!triggerType) {
				alert('Please select a trigger type.');
				e.preventDefault();
				return false;
			}

			if (!displayRule) {
				alert('Please select a display rule.');
				e.preventDefault();
				return false;
			}

			// Validate conditional fields
			if ('scroll_depth' === triggerType) {
				const depth = parseInt($('#scroll_depth').val());
				if (!depth || depth < 1 || depth > 100) {
					alert('Scroll depth must be between 1 and 100.');
					e.preventDefault();
					return false;
				}
			}

			if ('time_delay' === triggerType) {
				const delay = parseFloat($('#time_delay').val());
				if (!delay || delay < 0) {
					alert('Time delay must be 0 or greater.');
					e.preventDefault();
					return false;
				}
			}

			if ('click' === triggerType) {
				const selector = $('#click_selector').val();
				if (!selector) {
					alert('Please enter a CSS selector for click trigger.');
					e.preventDefault();
					return false;
				}

				// Validate CSS selector
				try {
					document.querySelector(selector);
				} catch (err) {
					alert('Invalid CSS selector: ' + selector);
					e.preventDefault();
					return false;
				}
			}

			if ('specific_pages' === displayRule) {
				const pages = $('#specific_pages').val();
				if (!pages || pages.length === 0) {
					alert('Please select at least one page/post.');
					e.preventDefault();
					return false;
				}
			}

			if ('specific_categories' === displayRule) {
				const categories = $('#specific_categories').val();
				if (!categories || categories.length === 0) {
					alert('Please select at least one category.');
					e.preventDefault();
					return false;
				}
			}
		});
	});
})(jQuery);
