/**
 * Popup Builder Frontend Script
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

(function() {
	'use strict';

	/**
	 * Popup Manager
	 */
	window.sfPopup = {
		popups: {},
		activePopup: null,

		/**
		 * Initialize popup system
		 */
		init: function() {
			this.bindEvents();
			this.detectTriggers();
		},

		/**
		 * Bind event listeners
		 */
		bindEvents: function() {
			const self = this;

			// Close button click
			document.addEventListener('click', function(e) {
				if (e.target.closest('.sf-popup-close')) {
					const popup = e.target.closest('.sf-popup-wrapper');
					if (popup) {
						self.close(popup.dataset.popupId);
					}
				}

				// Overlay click
				if (e.target.classList.contains('sf-popup-overlay')) {
					if (e.target.dataset.closeOverlay === 'true' || e.target.dataset.closeOverlay === true) {
						const popup = e.target.nextElementSibling;
						if (popup && popup.classList.contains('sf-popup-wrapper')) {
							self.close(popup.dataset.popupId);
						}
					}
				}
			});

			// ESC key to close
			document.addEventListener('keydown', function(e) {
				if (e.key === 'Escape' && self.activePopup) {
					self.close(self.activePopup);
				}
			});
		},

		/**
		 * Detect trigger types and initialize
		 */
		detectTriggers: function() {
			const self = this;
			const popups = document.querySelectorAll('.sf-popup-wrapper');

			popups.forEach(popup => {
				const popupId = popup.dataset.popupId;
				const config = popup.dataset.popupConfig;

				if (!config) return;

				let triggerData = {};
				try {
					triggerData = JSON.parse(config);
				} catch (e) {
					console.error('Invalid popup config:', e);
					return;
				}

				// Check frequency
				if (!self.shouldShow(popupId, triggerData.frequency)) {
					popup.style.display = 'none';
					popup.previousElementSibling?.style.display = 'none';
					return;
				}

				switch (triggerData.trigger_type) {
					case 'on_load':
						self.open(popupId);
						break;

					case 'exit_intent':
						self.setupExitIntent(popupId);
						break;

					case 'scroll_depth':
						self.setupScrollDepth(popupId, triggerData.scroll_depth);
						break;

					case 'time_delay':
						self.setupTimeDelay(popupId, triggerData.time_delay);
						break;

					case 'click':
						self.setupClickTrigger(popupId, triggerData.click_selector);
						break;

					case 'manual':
						// No automatic trigger, wait for manual open
						break;
				}
			});
		},

		/**
		 * Setup exit intent trigger
		 */
		setupExitIntent: function(popupId) {
			const self = this;
			let shown = false;

			document.addEventListener('mouseleave', function(e) {
				if (!shown && e.clientY <= 0) {
					self.open(popupId);
					shown = true;
					self.setFrequencyCookie(popupId);
				}
			});
		},

		/**
		 * Setup scroll depth trigger
		 */
		setupScrollDepth: function(popupId, depth) {
			const self = this;
			let shown = false;
			depth = parseInt(depth) || 50;

			window.addEventListener('scroll', function() {
				if (shown) return;

				const scrolled = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
				if (scrolled >= depth) {
					self.open(popupId);
					shown = true;
					self.setFrequencyCookie(popupId);
				}
			});
		},

		/**
		 * Setup time delay trigger
		 */
		setupTimeDelay: function(popupId, delay) {
			const self = this;
			delay = (parseFloat(delay) || 3) * 1000;

			setTimeout(function() {
				self.open(popupId);
				self.setFrequencyCookie(popupId);
			}, delay);
		},

		/**
		 * Setup click trigger
		 */
		setupClickTrigger: function(popupId, selector) {
			const self = this;

			document.addEventListener('click', function(e) {
				if (!selector) return;

				if (e.target.closest(selector)) {
					e.preventDefault();
					self.open(popupId);
					self.setFrequencyCookie(popupId);
				}
			});
		},

		/**
		 * Open popup
		 */
		open: function(popupId) {
			const popup = document.querySelector(`[data-popup-id="${popupId}"]`);
			const overlay = popup?.previousElementSibling;

			if (!popup) return;

			// Show overlay
			if (overlay && overlay.classList.contains('sf-popup-overlay')) {
				overlay.style.display = 'block';
			}

			// Show popup
			popup.style.display = 'flex';
			popup.classList.add('sf-popup-active');

			// Focus management
			this.setFocusTrap(popup);

			// Disable body scroll
			document.body.classList.add('sf-popup-no-scroll');

			this.activePopup = popupId;
		},

		/**
		 * Close popup
		 */
		close: function(popupId) {
			const popup = document.querySelector(`[data-popup-id="${popupId}"]`);
			const overlay = popup?.previousElementSibling;

			if (!popup) return;

			// Hide overlay
			if (overlay && overlay.classList.contains('sf-popup-overlay')) {
				overlay.style.display = 'none';
			}

			// Hide popup
			popup.style.display = 'none';
			popup.classList.remove('sf-popup-active');

			// Enable body scroll
			document.body.classList.remove('sf-popup-no-scroll');

			this.activePopup = null;
		},

		/**
		 * Set focus trap for accessibility
		 */
		setFocusTrap: function(popup) {
			const focusableElements = popup.querySelectorAll(
				'a, button, input, select, textarea, [tabindex]'
			);

			if (focusableElements.length === 0) return;

			const firstElement = focusableElements[0];
			const lastElement = focusableElements[focusableElements.length - 1];

			popup.addEventListener('keydown', (e) => {
				if (e.key !== 'Tab') return;

				if (e.shiftKey) {
					if (document.activeElement === firstElement) {
						e.preventDefault();
						lastElement.focus();
					}
				} else {
					if (document.activeElement === lastElement) {
						e.preventDefault();
						firstElement.focus();
					}
				}
			});

			firstElement.focus();
		},

		/**
		 * Check if popup should be shown based on frequency
		 */
		shouldShow: function(popupId, frequency) {
			frequency = frequency || 'every_visit';

			switch (frequency) {
				case 'every_visit':
					return true;

				case 'once_per_session':
					return !sessionStorage.getItem(`sf_popup_shown_${popupId}`);

				case 'once_per_day':
					const dayKey = `sf_popup_day_${popupId}`;
					const lastShown = localStorage.getItem(dayKey);
					const today = new Date().toDateString();

					if (!lastShown || lastShown !== today) {
						localStorage.setItem(dayKey, today);
						return true;
					}
					return false;

				case 'once_ever':
					return !localStorage.getItem(`sf_popup_shown_${popupId}`);

				default:
					return true;
			}
		},

		/**
		 * Set frequency cookie
		 */
		setFrequencyCookie: function(popupId) {
			const config = document.querySelector(`[data-popup-id="${popupId}"]`).dataset.popupConfig;
			let frequency = 'every_visit';

			try {
				frequency = JSON.parse(config).frequency || 'every_visit';
			} catch (e) {
				// Ignore
			}

			if (frequency === 'once_per_session') {
				sessionStorage.setItem(`sf_popup_shown_${popupId}`, '1');
			} else if (frequency === 'once_ever') {
				localStorage.setItem(`sf_popup_shown_${popupId}`, '1');
			}
		},

		/**
		 * Toggle popup visibility
		 */
		toggle: function(popupId) {
			const popup = document.querySelector(`[data-popup-id="${popupId}"]`);
			if (popup && popup.style.display !== 'none') {
				this.close(popupId);
			} else {
				this.open(popupId);
			}
		}
	};

	/**
	 * Initialize on DOM ready
	 */
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', function() {
			window.sfPopup.init();
		});
	} else {
		window.sfPopup.init();
	}
})();
