/**
 * Post Formats JavaScript
 *
 * @package Starter_Flavor
 * @since 1.0.0
 */

(function() {
	'use strict';

	document.addEventListener('DOMContentLoaded', function() {
		initGallerySlider();
		initLazyLoad();
		initChat();
	});

	/**
	 * Initialize gallery slider
	 */
	function initGallerySlider() {
		const sliders = document.querySelectorAll('.gallery-slider-wrapper');

		sliders.forEach(function(slider) {
			const slides = slider.querySelectorAll('.gallery-slide');
			const dotsContainer = slider.parentElement.querySelector('.gallery-nav-dots');

			if (!slides.length || !dotsContainer) {
				return;
			}

			let currentIndex = 0;

			// Create dots
			slides.forEach(function(_, index) {
				const dot = document.createElement('span');
				dot.className = 'gallery-dot' + (index === 0 ? ' active' : '');
				dot.addEventListener('click', function() {
					goToSlide(index);
				});
				dotsContainer.appendChild(dot);
			});

			// Go to slide
			function goToSlide(index) {
				currentIndex = index;
				slider.scrollLeft = slides[currentIndex].offsetLeft;
				updateDots();
			}

			// Update dots
			function updateDots() {
				const dots = dotsContainer.querySelectorAll('.gallery-dot');
				dots.forEach(function(dot, index) {
					dot.classList.toggle('active', index === currentIndex);
				});
			}

			// Handle scroll snap
			let scrollTimeout;
			slider.addEventListener('scroll', function() {
				clearTimeout(scrollTimeout);
				scrollTimeout = setTimeout(function() {
					const slideWidth = slides[0].offsetWidth;
					currentIndex = Math.round(slider.scrollLeft / slideWidth);
					updateDots();
				}, 100);
			});
		});
	}

	/**
	 * Initialize lazy loading
	 */
	function initLazyLoad() {
		const lazyImages = document.querySelectorAll('img.lazy-load');

		// Check if IntersectionObserver is supported
		if ('IntersectionObserver' in window) {
			const imageObserver = new IntersectionObserver(function(entries) {
				entries.forEach(function(entry) {
					if (entry.isIntersecting) {
						const img = entry.target;
						if (img.dataset.src) {
							img.src = img.dataset.src;
							img.removeAttribute('data-src');
							img.classList.remove('lazy-load');
						}
						imageObserver.unobserve(img);
					}
				});
			}, {
				rootMargin: '50px'
			});

			lazyImages.forEach(function(img) {
				imageObserver.observe(img);
			});
		} else {
			// Fallback for older browsers
			lazyImages.forEach(function(img) {
				if (img.dataset.src) {
					img.src = img.dataset.src;
					img.removeAttribute('data-src');
					img.classList.remove('lazy-load');
				}
			});
		}
	}

	/**
	 * Initialize chat message styling
	 */
	function initChat() {
		const chatMessages = document.querySelectorAll('.post-chat-transcript .chat-message');

		if (!chatMessages.length) {
			return;
		}

		let alternateClass = 'chat-message-a';

		chatMessages.forEach(function(message, index) {
			// Remove any existing classes and add the correct one
			message.classList.remove('chat-message-a', 'chat-message-b');

			if (!message.classList.contains('chat-message-a') && !message.classList.contains('chat-message-b')) {
				alternateClass = index % 2 === 0 ? 'chat-message-a' : 'chat-message-b';
				message.classList.add(alternateClass);
			}
		});
	}

})();
