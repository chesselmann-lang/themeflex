/**
 * ThemeFlex Scroll Animations v2.0
 *
 * - IntersectionObserver for entrance animations
 * - Smooth parallax on hero elements
 * - Animated counters
 * - Staggered card reveals
 *
 * Zero dependencies. ~3KB minified.
 */
(function () {
  'use strict';

  // ── Entrance animation observer ─────────────────────────────
  var animTargets = document.querySelectorAll(
    '.tf-reveal, .tf-reveal-left, .tf-reveal-right, ' +
    '.sf-section-grid > *, .sf-testimonials-grid > *, ' +
    '.sf-blog-grid > *, .tf-pf-card, .sf-pricing-grid > *, ' +
    '.tf-srv-card, .tf-about-value-card, .tf-bento-card'
  );

  if (animTargets.length && 'IntersectionObserver' in window) {
    var entranceObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('tf-in');
          entranceObs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

    animTargets.forEach(function (el, i) {
      // Stagger delay based on position in parent
      var siblings = Array.from(el.parentNode.children);
      var idx = siblings.indexOf(el);
      el.style.transitionDelay = Math.min(idx * 0.08, 0.5) + 's';
      el.classList.add('tf-pre-anim');
      entranceObs.observe(el);
    });
  }

  // ── Section header reveals ──────────────────────────────────
  var headers = document.querySelectorAll(
    '.sf-section-header, .tf-feat-header, .tf-pr-faq-inner h2, ' +
    '.tf-about-section-header, .tf-pf-header, .tf-spf-related h2'
  );

  if (headers.length && 'IntersectionObserver' in window) {
    var headerObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('tf-header-in');
          headerObs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2 });

    headers.forEach(function (el) {
      el.classList.add('tf-header-pre');
      headerObs.observe(el);
    });
  }

  // ── Parallax on hero blobs (light, CSS only on mobile) ──────
  if (window.innerWidth > 768) {
    var blobs = document.querySelectorAll('.tf-hero-blob');
    var visual = document.querySelector('.tf-hero-visual');

    if (blobs.length || visual) {
      window.addEventListener('scroll', function () {
        var y = window.scrollY;
        blobs.forEach(function (b, i) {
          var speed = (i === 0) ? 0.08 : (i === 1) ? -0.06 : 0.05;
          b.style.transform = 'translateY(' + (y * speed) + 'px)';
        });
      }, { passive: true });
    }
  }

  // ── Magnetic CTA buttons (subtle) ───────────────────────────
  var magBtns = document.querySelectorAll('.tf-hero-cta-primary');
  magBtns.forEach(function (btn) {
    btn.addEventListener('mousemove', function (e) {
      var rect = btn.getBoundingClientRect();
      var x = (e.clientX - rect.left - rect.width / 2) * 0.15;
      var y = (e.clientY - rect.top - rect.height / 2) * 0.15;
      btn.style.transform = 'translate(' + x + 'px,' + y + 'px) translateY(-3px)';
    });
    btn.addEventListener('mouseleave', function () {
      btn.style.transform = '';
    });
  });

  // ── Skin swatch hover in hero ────────────────────────────────
  var skinDots = document.querySelectorAll('.tf-skin-dot');
  skinDots.forEach(function (dot) {
    dot.addEventListener('click', function () {
      skinDots.forEach(function (d) { d.classList.remove('active'); });
      dot.classList.add('active');
    });
  });

  // ── Smooth scroll for anchor links ──────────────────────────
  document.querySelectorAll('a[href^="#"]').forEach(function (link) {
    link.addEventListener('click', function (e) {
      var target = document.querySelector(link.getAttribute('href'));
      if (!target) return;
      e.preventDefault();
      var offset = 80;
      var top = target.getBoundingClientRect().top + window.scrollY - offset;
      window.scrollTo({ top: top, behavior: 'smooth' });
    });
  });

  // ── Reading progress bar (single posts) ─────────────────────
  var progressBar = document.getElementById('tfReadingProgress');
  if (progressBar) {
    window.addEventListener('scroll', function () {
      var article = document.querySelector('.tf-article-body') || document.querySelector('article');
      if (!article) return;
      var rect = article.getBoundingClientRect();
      var total = article.offsetHeight - window.innerHeight;
      var scrolled = -rect.top;
      var pct = Math.max(0, Math.min(100, (scrolled / total) * 100));
      progressBar.style.width = pct + '%';
    }, { passive: true });
  }

  // ── Back to top button ───────────────────────────────────────
  var backTop = document.getElementById('tfBackTop');
  if (backTop) {
    window.addEventListener('scroll', function () {
      backTop.classList.toggle('visible', window.scrollY > 400);
    }, { passive: true });
    backTop.addEventListener('click', function (e) {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

})();


// ── [data-reveal] attribute system ─────────────────────────────
(function() {
  var revealEls = document.querySelectorAll('[data-reveal]');
  if (!revealEls.length || !('IntersectionObserver' in window)) return;

  var obs = new IntersectionObserver(function(entries) {
    entries.forEach(function(entry) {
      if (entry.isIntersecting) {
        var el = entry.target;
        var delay = el.dataset.revealDelay || 0;
        setTimeout(function() {
          el.classList.add('tf-revealed');
        }, parseFloat(delay) * 1000);
        obs.unobserve(el);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

  revealEls.forEach(function(el) { obs.observe(el); });
})();

// ── Section number parallax (subtle) ──────────────────────────
(function() {
  var secNums = document.querySelectorAll('.tf-sec-number');
  if (!secNums.length) return;
  window.addEventListener('scroll', function() {
    var scrollY = window.scrollY;
    secNums.forEach(function(el) {
      var rect = el.getBoundingClientRect();
      var offset = (rect.top / window.innerHeight) * 10;
      el.style.transform = 'translateY(' + offset + 'px)';
    });
  }, { passive: true });
})();
