/**
 * Setup Wizard JavaScript
 *
 * @since 1.0.0
 */

(function ($) {
	'use strict';

	const SetupWizard = {
		currentStep: 1,
		totalSteps: 7,
		logoId: 0,
		faviconId: 0,

		/**
		 * Initialize
		 */
		init() {
			this.updateProgress();
			this.bindEvents();
			this.initMediaUploader();
		},

		/**
		 * Bind events
		 */
		bindEvents() {
			const self = this;

			// Step navigation
			$(document).on('click', '.sf-next-step', function () {
				const nextStep = $(this).data('next');
				self.goToStep(nextStep);
			});

			$(document).on('click', '.sf-prev-step', function () {
				const prevStep = $(this).data('prev');
				self.goToStep(prevStep);
			});

			// Plugin installation
			$(document).on('click', '.sf-plugin-btn', function () {
				const $item = $(this).closest('.sf-plugin-item');
				const plugin = $item.data('plugin');
				const file = $item.data('plugin-file');
				self.installPlugin($(this), plugin, file);
			});

			// Demo import
			$(document).on('click', '.sf-import-demo-btn', function () {
				const demo = $(this).data('demo');
				self.importDemo($(this), demo);
			});

			// Logo upload
			$(document).on('click', '#sf-logo-upload-btn', function () {
				self.openMediaUploader('logo');
			});

			// Favicon upload
			$(document).on('click', '#sf-favicon-upload-btn', function () {
				self.openMediaUploader('favicon');
			});

			// Homepage type change
			$(document).on('change', 'input[name="sf-homepage-type"]', function () {
				const type = $(this).val();
				if (type === 'static') {
					$('#sf-static-page-option').show();
				} else {
					$('#sf-static-page-option').hide();
				}
			});

			// Create homepage
			$(document).on('click', '#sf-create-homepage-btn', function () {
				self.createHomepage();
			});

			// Color picker
			$(document).on('change', '#sf-primary-color', function () {
				const color = $(this).val();
				$(this).closest('.sf-color-picker-wrapper').find('.sf-color-preview').css('background', color);
			});

			// Save all settings on final step
			$(document).on('click', '.sf-wizard-step[data-step="7"] .sf-wizard-actions', function () {
				self.saveAllSettings();
			});
		},

		/**
		 * Go to specific step
		 */
		goToStep(step) {
			if (step < 1 || step > this.totalSteps) {
				return;
			}

			// Hide current step
			$('.sf-wizard-step').hide();

			// Show new step
			$('.sf-wizard-step[data-step="' + step + '"]').show();

			// Update current step
			this.currentStep = step;
			this.updateProgress();
		},

		/**
		 * Update progress bar
		 */
		updateProgress() {
			const percent = (this.currentStep / this.totalSteps) * 100;
			$('.sf-progress-fill').css('width', percent + '%');
			$('.sf-step-current').text(this.currentStep);
		},

		/**
		 * Install plugin via AJAX
		 */
		installPlugin($btn, plugin, file) {
			const originalText = $btn.text();
			const $item = $btn.closest('.sf-plugin-item');
			$btn.text('Installing...').addClass('installing').prop('disabled', true);

			$.ajax({
				url: sfSetupWizardData.ajaxUrl,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'sf_setup_install_plugin',
					nonce: sfSetupWizardData.nonce,
					plugin: plugin,
					file: file
				},
				success: (response) => {
					if (response.success) {
						$btn.text('Installed ✓').removeClass('installing').prop('disabled', true);
						$item.addClass('installed');
					} else {
						$btn.text('Install').removeClass('installing').prop('disabled', false);
						alert('Error: ' + (response.data || 'Unknown error'));
					}
				},
				error: () => {
					$btn.text('Install').removeClass('installing').prop('disabled', false);
					alert('Network error while installing plugin');
				}
			});
		},

		/**
		 * Import demo content
		 */
		importDemo($btn, demo) {
			const originalText = $btn.text();
			$btn.text('Importing...').prop('disabled', true);

			$.ajax({
				url: sfSetupWizardData.ajaxUrl,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'sf_setup_import_demo',
					nonce: sfSetupWizardData.nonce,
					demo: demo
				},
				success: (response) => {
					if (response.success) {
						$btn.text('Imported ✓').prop('disabled', true);
						alert('Demo imported successfully!');
					} else {
						$btn.text(originalText).prop('disabled', false);
						alert('Error: ' + (response.data || 'Unknown error'));
					}
				},
				error: () => {
					$btn.text(originalText).prop('disabled', false);
					alert('Network error while importing demo');
				}
			});
		},

		/**
		 * Initialize media uploader
		 */
		initMediaUploader() {
			const self = this;

			// Check if wp.media exists
			if (typeof wp === 'undefined' || typeof wp.media === 'undefined') {
				console.log('WordPress media library not available');
				return;
			}

			let frame;

			window.openMediaUploader = function (type) {
				if (frame) {
					frame.open();
					return;
				}

				frame = wp.media({
					title: type === 'logo' ? 'Select Logo' : 'Select Favicon',
					button: {
						text: 'Use this image'
					},
					multiple: false
				});

				frame.on('select', function () {
					const attachment = frame.state().get('selection').first().toJSON();
					self.handleMediaUpload(type, attachment);
				});

				frame.open();
			};
		},

		/**
		 * Open media uploader
		 */
		openMediaUploader(type) {
			if (typeof window.openMediaUploader === 'function') {
				window.openMediaUploader(type);
			} else {
				// Fallback: use simpler image selection
				const input = document.createElement('input');
				input.type = 'file';
				input.accept = 'image/*';

				input.onchange = (e) => {
					const file = e.target.files[0];
					const reader = new FileReader();

					reader.onload = (event) => {
						const attachment = {
							id: Date.now(),
							url: event.target.result
						};
						this.handleMediaUpload(type, attachment);
					};

					reader.readAsDataURL(file);
				};

				input.click();
			}
		},

		/**
		 * Handle media upload
		 */
		handleMediaUpload(type, attachment) {
			if (type === 'logo') {
				this.logoId = attachment.id;
				$('#sf-logo-id').val(attachment.id);
				$('#sf-logo-preview').html('<img src="' + this.escapeHtml(attachment.url) + '" alt="Logo">');
			} else if (type === 'favicon') {
				this.faviconId = attachment.id;
				$('#sf-favicon-id').val(attachment.id);
				$('#sf-favicon-preview').html('<img src="' + this.escapeHtml(attachment.url) + '" alt="Favicon">');
			}
		},

		/**
		 * Create homepage
		 */
		createHomepage() {
			const pageName = prompt('Enter homepage name:', 'Home');
			if (!pageName) {
				return;
			}

			// Create page via AJAX
			const data = {
				action: 'create_post',
				post_type: 'page',
				post_title: pageName,
				post_status: 'publish',
				_wpnonce: sfSetupWizardData.nonce
			};

			$.post(sfSetupWizardData.ajaxUrl, data, (response) => {
				if (response && response.post_id) {
					const $select = $('#sf-homepage-page');
					$select.append('<option value="' + response.post_id + '" selected>' + this.escapeHtml(pageName) + '</option>');
					$select.val(response.post_id);
					alert('Homepage created successfully!');
				} else {
					alert('Error creating page');
				}
			});
		},

		/**
		 * Save all settings
		 */
		saveAllSettings() {
			const data = {
				action: 'sf_setup_save_settings',
				nonce: sfSetupWizardData.nonce,
				site_title: $('#sf-site-title').val(),
				site_tagline: $('#sf-site-tagline').val(),
				logo_id: this.logoId || $('#sf-logo-id').val(),
				favicon_id: this.faviconId || $('#sf-favicon-id').val(),
				homepage_type: $('input[name="sf-homepage-type"]:checked').val(),
				homepage_page: $('#sf-homepage-page').val(),
				primary_color: $('#sf-primary-color').val(),
				heading_font: $('#sf-heading-font').val(),
				body_font: $('#sf-body-font').val()
			};

			$.ajax({
				url: sfSetupWizardData.ajaxUrl,
				type: 'POST',
				dataType: 'json',
				data: data,
				success: (response) => {
					if (response.success) {
						// Wizard is complete
						console.log('Setup complete!');
					} else {
						alert('Error: ' + (response.data || 'Unknown error'));
					}
				},
				error: () => {
					alert('Network error while saving settings');
				}
			});
		},

		/**
		 * Escape HTML
		 */
		escapeHtml(text) {
			const div = document.createElement('div');
			div.textContent = text;
			return div.innerHTML;
		}
	};

	// Initialize on ready
	$(document).ready(function () {
		SetupWizard.init();
	});

})(jQuery);
