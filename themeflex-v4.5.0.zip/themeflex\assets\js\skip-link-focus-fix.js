/**
 * File skip-link-focus-fix.js.
 *
 * Helps with accessibility for keyboard only users.
 *
 * Learn more: https://github.com/WordPress/gutenberg/pull/26728
 */
(function() {
	const isIe11 = !!window.MSInputMethodContext && !!document.documentMode;
	if (isIe11 || typeof window.requestAnimationFrame === 'undefined') {
		return;
	}
	const focusableElementsString = [
		'a[href]',
		'area[href]',
		'input:not([disabled]):not([type="hidden"]):not([aria-hidden])',
		'select:not([disabled]):not([aria-hidden])',
		'textarea:not([disabled]):not([aria-hidden])',
		'button:not([disabled]):not([aria-hidden])',
		'iframe',
		'object',
		'embed',
		'[contenteditable]',
		'[tabindex]:not([tabindex^="-"])',
	].join(',');
	const skipLinkButton = document.querySelector('a.skip-link-focus-fix');

	function moveFocusToElement(element) {
		if (!element) {
			return;
		}
		if (element === document.body) {
			element.focus();
		}
		element.addEventListener('blur', onBlur);
		element.focus();
		window.scrollBy(0, -element.offsetTop + 50);
	}

	function onBlur() {
		this.removeEventListener('blur', onBlur);
	}

	skipLinkButton?.addEventListener('click', (e) => {
		e.preventDefault();
		const target = document.getElementById('site-content') || document.querySelector('main');
		if (target) {
			let focusElement = target.querySelector(focusableElementsString);
			if (!focusElement) {
				focusElement = target;
			}
			moveFocusToElement(focusElement);
		}
	});
})();
