/**
 * ThemeFlex Smooth Scroll v1.0
 *
 * Lightweight native smooth scroll enhancement.
 * Uses CSS scroll-behavior:smooth as foundation,
 * with JS only for:
 * - Offset for sticky header
 * - Active state on nav links
 * - Scroll progress indicator
 * - Section-in-view detection for nav highlighting
 */
(function () {
  'use strict';

  var HEADER_OFFSET = 80;

  /* ── Smooth anchor scroll with offset ───────────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(function (a) {
    var href = a.getAttribute('href');
    if (href === '#') return;
    a.addEventListener('click', function (e) {
      var target = document.querySelector(href);
      if (!target) return;
      e.preventDefault();
      var top = target.getBoundingClientRect().top + window.scrollY - HEADER_OFFSET;
      window.scrollTo({ top: top, behavior: 'smooth' });
      // Update URL without jump
      if (history.pushState) history.pushState(null, null, href);
    });
  });

  /* ── Active nav link based on scroll position ────────────── */
  var navLinks = document.querySelectorAll('.main-navigation a');
  var sections = document.querySelectorAll('section[id], div[id^="sf-"]');

  if (sections.length && navLinks.length) {
    window.addEventListener('scroll', function () {
      var scrollY = window.scrollY + HEADER_OFFSET + 40;
      var current = '';
      sections.forEach(function (s) {
        if (s.offsetTop <= scrollY) current = s.getAttribute('id');
      });
      navLinks.forEach(function (link) {
        link.classList.remove('tf-nav-active');
        var href = link.getAttribute('href') || '';
        if (href.includes(current) && current) {
          link.classList.add('tf-nav-active');
        }
      });
    }, { passive: true });
  }

  /* ── Sticky header shrink on scroll ─────────────────────── */
  var header = document.getElementById('site-header');
  if (header) {
    window.addEventListener('scroll', function () {
      header.classList.toggle('tf-header-scrolled', window.scrollY > 60);
    }, { passive: true });
  }

  /* ── Page fade-in on load ────────────────────────────────── */
  document.documentElement.style.opacity = '0';
  window.addEventListener('load', function () {
    document.documentElement.style.transition = 'opacity .4s ease';
    document.documentElement.style.opacity = '1';
  });

})();
