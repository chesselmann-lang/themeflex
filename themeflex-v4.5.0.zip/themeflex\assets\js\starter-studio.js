/**
 * Starter Studio - Admin Scripts
 * @package Starter_Flavor
 */

(function($) {
	'use strict';

	const StarterStudio = {
		init: function() {
			this.cacheDom();
			this.bindEvents();
			this.loadSections();
		},

		cacheDom: function() {
			this.$document = $(document);
			this.$filterBtns = $('.sf-studio-tab-btn');
			this.$grid = $('.sf-studio-grid');
			this.$previewBtn = $(document).on('click', '.sf-studio-preview-btn', this.openPreview.bind(this));
			this.$copyBtn = $(document).on('click', '.sf-studio-copy-btn', this.copyJson.bind(this));
			this.$filterContainer = $('.sf-studio-filter-container, .sf-studio-filter-tabs');
			this.$modal = $('#sf-studio-preview-modal');
			this.$modalClose = $('.sf-modal-close');
		},

		bindEvents: function() {
			// Filter tabs
			this.$filterBtns.on('click', this.filterSections.bind(this));

			// Modal close
			if (this.$modalClose.length) {
				this.$modalClose.on('click', this.closeModal.bind(this));
			}

			// Close modal on background click
			$(document).on('click', '#sf-studio-preview-modal', function(e) {
				if (e.target.id === 'sf-studio-preview-modal') {
					StarterStudio.closeModal();
				}
			});
		},

		loadSections: function() {
			// Load sections via AJAX if needed
			if (typeof sfStarterStudio !== 'undefined' && this.$grid.length) {
				$.ajax({
					url: sfStarterStudio.ajaxurl,
					type: 'POST',
					data: {
						action: 'sf_get_sections',
						nonce: sfStarterStudio.nonce
					},
					success: function(response) {
						if (response.success) {
							// Sections already loaded, just set up filtering
						}
					}
				});
			}
		},

		filterSections: function(e) {
			e.preventDefault();

			const $btn = $(e.currentTarget);
			const filter = $btn.data('filter') || $btn.data('tab');

			// Update active button
			this.$filterBtns.removeClass('active');
			$btn.addClass('active');

			// Filter items
			if (this.$grid.length) {
				if (filter === 'all') {
					this.$grid.find('.sf-studio-item').fadeIn(300);
				} else {
					this.$grid.find('.sf-studio-item').each(function() {
						const $item = $(this);
						if ($item.data('category') === filter) {
							$item.fadeIn(300);
						} else {
							$item.fadeOut(300);
						}
					});
				}
			}

			// Also filter cards in panel if exists
			const $sectionCards = $('.sf-studio-section-card');
			if ($sectionCards.length) {
				if (filter === 'all') {
					$sectionCards.fadeIn(300);
				} else {
					$sectionCards.each(function() {
						const $card = $(this);
						if ($card.data('category') === filter) {
							$card.fadeIn(300);
						} else {
							$card.fadeOut(300);
						}
					});
				}
			}
		},

		openPreview: function(e) {
			e.preventDefault();

			const $btn = $(e.currentTarget);
			const sectionId = $btn.data('section-id');

			if (!sectionId) {
				return;
			}

			this.showModal();

			// Show loading message
			const $modal = this.$modal;
			$modal.find('.sf-modal-body').html('<div class="sf-preview-loading">' + 'Loading preview...' + '</div>');

			// Load section preview
			if (typeof sfStarterStudio !== 'undefined') {
				$.ajax({
					url: sfStarterStudio.ajaxurl,
					type: 'POST',
					data: {
						action: 'sf_get_section_preview',
						nonce: sfStarterStudio.nonce,
						section_id: sectionId
					},
					success: function(response) {
						if (response.success) {
							const section = response.data;
							const preview = StarterStudio.renderPreview(section);
							$modal.find('.sf-modal-body').html(preview);
						} else {
							$modal.find('.sf-modal-body').html('<div class="sf-preview-loading" style="color: #d32f2f;">Error loading preview</div>');
						}
					},
					error: function() {
						$modal.find('.sf-modal-body').html('<div class="sf-preview-loading" style="color: #d32f2f;">Error loading preview</div>');
					}
				});
			}
		},

		renderPreview: function(section) {
			let html = '<div class="sf-preview-content">';

			if (section.title) {
				html += '<h2>' + escapeHtml(section.title) + '</h2>';
			}

			if (section.description) {
				html += '<p>' + escapeHtml(section.description) + '</p>';
			}

			if (section.preview_image) {
				html += '<img src="' + escapeHtml(section.preview_image) + '" alt="' + escapeHtml(section.title) + '" style="max-width: 100%; height: auto; border-radius: 8px; margin: 20px 0;">';
			}

			if (section.section) {
				html += '<details style="margin-top: 20px;"><summary style="cursor: pointer; padding: 10px; background: #f5f5f5; border-radius: 4px;">View JSON Structure</summary>';
				html += '<pre style="background: #f9f9f9; padding: 15px; border-radius: 4px; overflow-x: auto;"><code>' + escapeHtml(JSON.stringify(section.section, null, 2)) + '</code></pre>';
				html += '</details>';
			}

			html += '</div>';

			return html;
		},

		copyJson: function(e) {
			e.preventDefault();

			const $btn = $(e.currentTarget);
			const sectionJson = $btn.data('section-json');

			if (!sectionJson) {
				alert('No JSON data available');
				return;
			}

			// Copy to clipboard
			const textArea = document.createElement('textarea');
			textArea.value = JSON.stringify(JSON.parse(sectionJson), null, 2);
			document.body.appendChild(textArea);
			textArea.select();

			try {
				document.execCommand('copy');
				this.showCopySuccess();
				$btn.text('Copied!').addClass('copied');

				setTimeout(function() {
					$btn.text('Copy JSON').removeClass('copied');
				}, 2000);
			} catch (err) {
				alert('Failed to copy to clipboard');
			}

			document.body.removeChild(textArea);
		},

		showCopySuccess: function() {
			const $notice = $('<div class="sf-copy-success">Section JSON copied to clipboard!</div>');
			$('body').append($notice);

			setTimeout(function() {
				$notice.fadeOut(300, function() {
					$(this).remove();
				});
			}, 3000);
		},

		showModal: function() {
			if (this.$modal.length) {
				this.$modal.addClass('active').fadeIn(300);
			}
		},

		closeModal: function() {
			if (this.$modal.length) {
				this.$modal.removeClass('active').fadeOut(300);
			}
		}
	};

	// Helper function to escape HTML
	function escapeHtml(text) {
		const map = {
			'&': '&amp;',
			'<': '&lt;',
			'>': '&gt;',
			'"': '&quot;',
			"'": '&#039;'
		};
		return text.replace(/[&<>"']/g, function(m) { return map[m]; });
	}

	// Initialize on document ready
	$(document).ready(function() {
		StarterStudio.init();
	});

	// Export for use in Elementor editor
	window.StarterStudio = StarterStudio;

})(jQuery);
