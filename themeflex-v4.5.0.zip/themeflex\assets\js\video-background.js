/**
 * Video Background Handler
 */
(function() {
	'use strict';

	const VideoBackground = {
		init: function() {
			this.setupVideoContainers();
			this.setupYouTubeVideos();
			this.setupVimeoVideos();
			this.setupPlayButtons();
		},

		setupVideoContainers: function() {
			document.querySelectorAll('.sf-video-background').forEach((container) => {
				const videoType = container.getAttribute('data-video-type');

				// Lazy load videos when in viewport
				const observer = new IntersectionObserver((entries) => {
					entries.forEach((entry) => {
						if (entry.isIntersecting) {
							this.loadVideo(entry.target);
							observer.unobserve(entry.target);
						}
					});
				});

				observer.observe(container);
			});
		},

		loadVideo: function(container) {
			const videoType = container.getAttribute('data-video-type');

			if (videoType === 'self-hosted') {
				const video = container.querySelector('.sf-video-element');
				if (video && !video.src) {
					video.load();
				}
			}
		},

		setupYouTubeVideos: function() {
			// Load YouTube API if not already loaded
			if (!window.YT) {
				const script = document.createElement('script');
				script.src = 'https://www.youtube.com/iframe_api';
				document.head.appendChild(script);
			}

			window.onYouTubeIframeAPIReady = () => {
				document.querySelectorAll('.sf-youtube-video').forEach((container) => {
					const videoId = container.getAttribute('data-video-id');
					if (!videoId) return;

					new YT.Player(container, {
						videoId: videoId,
						playerVars: {
							autoplay: 1,
							controls: 0,
							modestbranding: 1,
							rel: 0,
							showinfo: 0,
							iv_load_policy: 3,
							mute: 1,
							loop: 1,
							playlist: videoId
						},
						events: {
							onReady: (event) => {
								event.target.setSize(
									container.parentElement.offsetWidth,
									container.parentElement.offsetHeight
								);
								event.target.mute();
								event.target.playVideo();
							}
						}
					});
				});
			};
		},

		setupVimeoVideos: function() {
			// Load Vimeo API
			if (!window.Vimeo) {
				const script = document.createElement('script');
				script.src = 'https://player.vimeo.com/api/player.js';
				document.head.appendChild(script);
			}

			document.querySelectorAll('.sf-vimeo-video').forEach((container) => {
				const videoId = container.getAttribute('data-video-id');
				if (!videoId) return;

				const iframe = document.createElement('iframe');
				iframe.src = `https://player.vimeo.com/video/${videoId}?h=&autoplay=1&loop=1&byline=0&title=0&portrait=0&muted=1`;
				iframe.allow = 'autoplay; fullscreen; picture-in-picture';
				iframe.style.position = 'absolute';
				iframe.style.top = '0';
				iframe.style.left = '0';
				iframe.style.width = '100%';
				iframe.style.height = '100%';
				iframe.style.border = 'none';

				container.appendChild(iframe);
			});
		},

		setupPlayButtons: function() {
			document.querySelectorAll('.sf-video-play-btn').forEach((btn) => {
				btn.addEventListener('click', (e) => {
					e.preventDefault();

					const container = btn.closest('.sf-video-background');
					const video = container.querySelector('video');

					if (video) {
						if (video.paused) {
							video.play();
							btn.classList.add('playing');
						} else {
							video.pause();
							btn.classList.remove('playing');
						}
					}
				});
			});
		}
	};

	// Initialize
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', () => {
			VideoBackground.init();
		});
	} else {
		VideoBackground.init();
	}

	// Expose to window
	window.sfVideoBackground = VideoBackground;
})();
