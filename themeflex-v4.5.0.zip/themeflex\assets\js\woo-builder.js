/**
 * WooCommerce Builder - Admin Scripts
 * @package Starter_Flavor
 */

(function($) {
	'use strict';

	const WooBuilder = {
		init: function() {
			this.cacheDom();
			this.bindEvents();
			this.loadTemplates();
		},

		cacheDom: function() {
			this.$document = $(document);
			this.$toggleBtns = $('.sf-toggle-template');
			this.$page = $('.sf-woo-builder-page');
		},

		bindEvents: function() {
			this.$toggleBtns.on('click', this.toggleTemplate.bind(this));
		},

		loadTemplates: function() {
			if (typeof sfWooBuilder === 'undefined') {
				return;
			}

			$.ajax({
				url: sfWooBuilder.ajaxurl,
				type: 'POST',
				data: {
					action: 'sf_get_woo_templates',
					nonce: sfWooBuilder.nonce
				},
				success: function(response) {
					if (response.success) {
						// Templates loaded, UI already rendered
					}
				}
			});
		},

		toggleTemplate: function(e) {
			e.preventDefault();

			const $btn = $(e.currentTarget);
			const templateId = $btn.data('template-id');
			const currentActive = parseInt($btn.data('active'), 10) === 1;
			const newActive = !currentActive;

			if (!templateId) {
				return;
			}

			if (typeof sfWooBuilder === 'undefined') {
				return;
			}

			// Show loading state
			$btn.addClass('transitioning').prop('disabled', true);

			$.ajax({
				url: sfWooBuilder.ajaxurl,
				type: 'POST',
				data: {
					action: 'sf_toggle_template',
					nonce: sfWooBuilder.nonce,
					template_id: templateId,
					active: newActive ? 1 : 0
				},
				success: function(response) {
					if (response.success) {
						const data = response.data;

						// Update button state
						$btn.data('active', data.active ? 1 : 0);
						$btn.removeClass('transitioning').prop('disabled', false);

						// Update button text
						$btn.text(data.active ? 'Deactivate' : 'Activate');

						// Update status display
						const $card = $btn.closest('.sf-woo-template-card');
						const $status = $card.find('.sf-template-status');

						if (data.active) {
							$status.removeClass('inactive').addClass('active').text('Active');
						} else {
							$status.removeClass('active').addClass('inactive').text('Inactive');
						}

						// Show success notification
						WooBuilder.showNotice('Template updated successfully', 'success');
					} else {
						$btn.removeClass('transitioning').prop('disabled', false);
						WooBuilder.showNotice('Error updating template', 'error');
					}
				},
				error: function() {
					$btn.removeClass('transitioning').prop('disabled', false);
					WooBuilder.showNotice('Error updating template', 'error');
				}
			});
		},

		showNotice: function(message, type) {
			type = type || 'info';

			const iconClass = {
				'success': 'dashicons-yes-alt',
				'error': 'dashicons-warning',
				'info': 'dashicons-info'
			};

			const icon = iconClass[type] || 'dashicons-info';

			const $notice = $(
				'<div class="sf-notice ' + type + '">' +
					'<div class="sf-notice-icon"><span class="dashicons ' + icon + '"></span></div>' +
					'<div class="sf-notice-message">' + escapeHtml(message) + '</div>' +
					'<div class="sf-notice-close"><span class="dashicons dashicons-no-alt"></span></div>' +
				'</div>'
			);

			// Insert after page header
			const $header = $('.sf-page-header');
			if ($header.length) {
				$notice.insertAfter($header);
			} else {
				$('.sf-woo-builder-page').prepend($notice);
			}

			// Close button
			$notice.find('.sf-notice-close').on('click', function() {
				$notice.fadeOut(300, function() {
					$(this).remove();
				});
			});

			// Auto-remove after 5 seconds
			setTimeout(function() {
				$notice.fadeOut(300, function() {
					$(this).remove();
				});
			}, 5000);
		}
	};

	// Helper function to escape HTML
	function escapeHtml(text) {
		const map = {
			'&': '&amp;',
			'<': '&lt;',
			'>': '&gt;',
			'"': '&quot;',
			"'": '&#039;'
		};
		return text.replace(/[&<>"']/g, function(m) { return map[m]; });
	}

	// Initialize on document ready
	$(document).ready(function() {
		WooBuilder.init();
	});

	// Export for global use
	window.WooBuilder = WooBuilder;

})(jQuery);
