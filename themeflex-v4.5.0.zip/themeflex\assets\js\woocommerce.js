/**
 * WooCommerce Theme Integration
 * @package Starter_Flavor
 * @since 1.0.0
 */

(function($) {
	'use strict';

	var ThemeFlexWoo = {
		// Initialize
		init: function() {
			this.cacheElements();
			this.bindEvents();
			this.initQuickView();
			this.initFilters();
			this.initMiniCart();
		},

		// Cache DOM elements
		cacheElements: function() {
			this.$document = $(document);
			this.$body = $(document.body);
			this.$quickViewButtons = $('.quick-view-button');
			this.$filterButtons = $('.product-filter-button');
			this.$cartLink = $('.cart-link');
		},

		// Bind event listeners
		bindEvents: function() {
			var self = this;

			// Quick View button click
			this.$document.on('click', '.quick-view-button', function(e) {
				e.preventDefault();
				var productId = $(this).data('product-id');
				self.openQuickView(productId);
			});

			// Quick View modal close
			this.$document.on('click', '.quick-view-modal', function(e) {
				if ($(e.target).hasClass('quick-view-modal')) {
					$(this).removeClass('active').fadeOut();
				}
			});

			// Quick View close button
			this.$document.on('click', '.quick-view-close', function(e) {
				e.preventDefault();
				$('.quick-view-modal').removeClass('active').fadeOut();
			});

			// Wishlist button
			this.$document.on('click', '.wishlist-button', function(e) {
				e.preventDefault();
				self.toggleWishlist($(this));
			});

			// AJAX Add to cart
			this.$document.on('click', '.add_to_cart_button:not(.product_type_variable, .product_type_grouped, .product_type_external)', function(e) {
				e.preventDefault();
				self.addToCartAjax($(this));
			});

			// Update mini cart on cart change
			this.$body.on('added_to_cart', function() {
				self.updateMiniCart();
			});

			// Filter form submission
			this.$document.on('submit', '.product-filters-form', function(e) {
				e.preventDefault();
				self.filterProducts($(this));
			});

			// Filter range input
			this.$document.on('change', '.price-range-input', function() {
				self.filterProducts($('.product-filters-form'));
			});

			// Price range slider
			this.$document.on('change', '.price-slider', function() {
				var min = $(this).data('min-value') || 0;
				var max = $(this).data('max-value') || $(this).attr('max');
				$('.price-min-display').text(self.formatPrice(min));
				$('.price-max-display').text(self.formatPrice(max));
			});
		},

		// Quick View modal
		initQuickView: function() {
			var modal = '<div class="quick-view-modal" id="quickViewModal">' +
				'<div class="quick-view-modal-overlay"></div>' +
				'<div class="quick-view-content-wrapper">' +
				'<button class="quick-view-close" title="Close">×</button>' +
				'<div class="quick-view-modal-content"></div>' +
				'</div>' +
				'</div>';
			this.$body.append(modal);
		},

		// Open Quick View
		openQuickView: function(productId) {
			var self = this;
			var $modal = $('#quickViewModal');

			if (!$modal.length) {
				this.initQuickView();
				$modal = $('#quickViewModal');
			}

			$.ajax({
				url: themeFlexWoo.ajaxUrl,
				type: 'POST',
				data: {
					action: 'themeflex_quick_view',
					product_id: productId,
					nonce: themeFlexWoo.nonce
				},
				beforeSend: function() {
					$modal.find('.quick-view-modal-content').html(
						'<div class="spinner"><p>' + 'Loading...' + '</p></div>'
					);
					$modal.addClass('active').fadeIn();
				},
				success: function(response) {
					if (response.success) {
						$modal.find('.quick-view-modal-content').html(response.data.html);
						// Trigger WooCommerce add to cart
						self.$body.trigger('wc_cart_button_refresh');
					} else {
						$modal.find('.quick-view-modal-content').html(
							'<p class="error">' + 'Error loading product.' + '</p>'
						);
					}
				},
				error: function() {
					$modal.find('.quick-view-modal-content').html(
						'<p class="error">' + 'Error loading product.' + '</p>'
					);
				}
			});
		},

		// Toggle Wishlist
		toggleWishlist: function($button) {
			var productId = $button.data('product-id');
			var isAdded = $button.hasClass('added');

			$.ajax({
				url: themeFlexWoo.ajaxUrl,
				type: 'POST',
				data: {
					action: 'themeflex_toggle_wishlist',
					product_id: productId,
					nonce: themeFlexWoo.nonce
				},
				success: function(response) {
					if (response.success) {
						$button.toggleClass('added');
						if ($button.hasClass('added')) {
							$button.attr('title', 'Remove from Wishlist');
						} else {
							$button.attr('title', 'Add to Wishlist');
						}
					}
				}
			});
		},

		// Add to Cart AJAX
		addToCartAjax: function($button) {
			var self = this;
			var $product = $button.closest('.product');
			var productId = $button.val();

			$.ajax({
				url: themeFlexWoo.ajaxUrl,
				type: 'POST',
				data: {
					action: 'woocommerce_add_to_cart',
					product_id: productId,
					quantity: 1
				},
				beforeSend: function() {
					$button.prop('disabled', true).addClass('loading');
				},
				success: function(response) {
					if (response.success) {
						$button.removeClass('loading').addClass('added');
						self.updateMiniCart();
						// Show success message
						self.showNotice('Product added to cart!', 'success');
					}
				},
				error: function() {
					self.showNotice('Error adding to cart.', 'error');
				},
				complete: function() {
					$button.prop('disabled', false);
				}
			});
		},

		// Update Mini Cart
		updateMiniCart: function() {
			$.ajax({
				url: themeFlexWoo.ajaxUrl,
				type: 'POST',
				data: {
					action: 'themeflex_update_mini_cart',
					nonce: themeFlexWoo.nonce
				},
				success: function(response) {
					if (response.success) {
						var fragments = response.data.fragments;
						for (var selector in fragments) {
							if (fragments.hasOwnProperty(selector)) {
								$(selector).html(fragments[selector]);
							}
						}
						// Update cart count
						$('.cart-count').text(response.data.cart_count);
					}
				}
			});
		},

		// Initialize Mini Cart
		initMiniCart: function() {
			this.$document.on('mouseenter', '.header-cart-widget', function() {
				var $miniCart = $(this).find('.mini-cart-dropdown');
				if ($miniCart.find('li').length === 0) {
					// Load mini cart if empty
				}
			});
		},

		// Initialize Filters
		initFilters: function() {
			// Price range slider
			var $slider = $('.price-slider');
			if ($slider.length) {
				$slider.on('change', function() {
					// Update display
				});
			}
		},

		// Filter Products
		filterProducts: function($form) {
			var self = this;
			var data = $form.serialize();
			data += '&action=themeflex_filter_products&nonce=' + themeFlexWoo.nonce;

			$.ajax({
				url: themeFlexWoo.ajaxUrl,
				type: 'POST',
				data: data,
				beforeSend: function() {
					$('.products').css('opacity', '0.5');
				},
				success: function(response) {
					if (response.success) {
						$('.products').html(response.data.html);
						// Scroll to products
						$('html, body').animate({
							scrollTop: $('.products').offset().top - 100
						}, 500);
					}
				},
				complete: function() {
					$('.products').css('opacity', '1');
				}
			});
		},

		// Show Notice/Toast
		showNotice: function(message, type) {
			var className = 'notice-' + (type || 'info');
			var $notice = $('<div class="woo-notice ' + className + '">' + message + '</div>');

			this.$body.append($notice);

			$notice.fadeIn().delay(3000).fadeOut(function() {
				$(this).remove();
			});
		},

		// Format Price
		formatPrice: function(price) {
			var currency = themeFlexWoo.currency || '$';
			return currency + parseFloat(price).toFixed(2);
		},

		// Quantity Plus/Minus handlers
		quantityPlusMinus: function() {
			var self = this;

			this.$document.on('click', '.qty-minus', function(e) {
				e.preventDefault();
				var $input = $(this).siblings('input.qty');
				var current = parseInt($input.val()) || 1;
				if (current > 1) {
					$input.val(current - 1).change();
				}
			});

			this.$document.on('click', '.qty-plus', function(e) {
				e.preventDefault();
				var $input = $(this).siblings('input.qty');
				var current = parseInt($input.val()) || 1;
				$input.val(current + 1).change();
			});
		}
	};

	// Initialize on document ready
	$(document).ready(function() {
		ThemeFlexWoo.init();
	});

	// Export for external use
	window.ThemeFlexWoo = ThemeFlexWoo;

})(jQuery);
