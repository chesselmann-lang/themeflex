<?php
/**
 * Comments Template — ThemeFlex
 *
 * Dark-first styled comments with proper wp_list_comments() callback,
 * paginated list, and a fully styled comment form.
 *
 * @package ThemeFlex
 * @since   2.4.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
if ( post_password_required() ) return;
?>
<style>
/* ══════════════════════════════════════════════════════════
   COMMENTS — ThemeFlex Dark-first v2.4
   ══════════════════════════════════════════════════════════ */
#comments {
  --tc:     #ff5e2e;
  --bg2:    #0d1526;
  --bg3:    #111827;
  --border: rgba(255,255,255,.07);
  --title:  #f1f5f9;
  --txt:    #94a3b8;
  --meta:   #64748b;
  color: var(--txt);
  font-size: .9rem;
}

/* Section heading */
.tf-cmt-heading {
  font-family: 'Inter Tight', sans-serif;
  font-size: 1.35rem; font-weight: 900; color: var(--title);
  letter-spacing: -.03em; margin: 0 0 32px;
  display: flex; align-items: center; gap: 10px;
}
.tf-cmt-badge {
  display: inline-flex; align-items: center; justify-content: center;
  background: rgba(255,94,46,.12); border: 1px solid rgba(255,94,46,.22);
  color: var(--tc); font-size: .7rem; font-weight: 800; letter-spacing: .08em;
  padding: 3px 10px; border-radius: 100px;
}

/* Comment list */
.tf-cmt-list { list-style: none; margin: 0 0 48px; padding: 0; }
.tf-cmt-list .children {
  list-style: none; margin: 0; padding: 0 0 0 36px;
  border-left: 2px solid rgba(255,94,46,.1);
}
.tf-cmt-list li { position: relative; }

/* Single comment */
.tf-cmt {
  display: grid;
  grid-template-columns: 46px 1fr;
  gap: 16px;
  padding: 24px 0;
  border-bottom: 1px solid var(--border);
}
.tf-cmt-list > li:last-child > .tf-cmt { border-bottom: none; }

/* Avatar */
.tf-cmt-avatar {
  width: 46px; height: 46px; border-radius: 50%;
  border: 2px solid var(--border); display: block;
  object-fit: cover;
}

/* Content area */
.tf-cmt-inner { min-width: 0; }
.tf-cmt-meta {
  display: flex; align-items: baseline; flex-wrap: wrap; gap: 8px;
  margin-bottom: 10px;
}
.tf-cmt-author {
  font-weight: 800; font-size: .92rem; color: var(--title);
}
.tf-cmt-author a { color: inherit; text-decoration: none; }
.tf-cmt-author a:hover { color: var(--tc); }
.tf-cmt-date {
  font-size: .75rem; color: var(--meta);
}
.tf-cmt-date a { color: inherit; text-decoration: none; }
.tf-cmt-date a:hover { color: var(--tc); }

/* Awaiting moderation badge */
.tf-cmt-pending {
  display: inline-block;
  background: rgba(245,158,11,.1); border: 1px solid rgba(245,158,11,.2);
  color: #f59e0b; font-size: .7rem; font-weight: 700;
  padding: 2px 9px; border-radius: 100px;
  letter-spacing: .06em; text-transform: uppercase;
}
.tf-cmt-text {
  font-size: .9rem; line-height: 1.78; color: var(--txt);
}
.tf-cmt-text p { margin: 0 0 8px; }
.tf-cmt-text p:last-child { margin: 0; }
.tf-cmt-text a { color: var(--tc); }

.tf-cmt-reply {
  margin-top: 10px;
}
.tf-cmt-reply .comment-reply-link {
  display: inline-flex; align-items: center; gap: 5px;
  font-size: .78rem; font-weight: 700; color: var(--meta);
  text-decoration: none; transition: color .2s;
}
.tf-cmt-reply .comment-reply-link:hover { color: var(--tc); }

/* Closed / no comments */
.tf-cmt-closed,
.tf-cmt-empty {
  padding: 20px 24px; border-radius: 12px;
  border: 1px solid var(--border);
  background: rgba(255,255,255,.02);
  font-size: .875rem; color: var(--meta);
  text-align: center; margin-bottom: 40px;
}
.tf-cmt-empty svg { opacity: .3; margin: 0 auto 12px; display: block; }

/* Pagination */
.tf-cmt-pagination {
  display: flex; align-items: center; gap: 6px; margin-bottom: 40px;
}
.tf-cmt-pagination .page-numbers {
  display: inline-flex; align-items: center; justify-content: center;
  min-width: 38px; height: 38px; padding: 0 10px;
  border-radius: 8px; border: 1px solid var(--border);
  color: var(--txt); text-decoration: none; font-size: .82rem; font-weight: 700;
  transition: all .2s;
}
.tf-cmt-pagination .page-numbers:hover,
.tf-cmt-pagination .page-numbers.current {
  background: var(--tc); color: #fff; border-color: var(--tc);
}

/* ── Comment Form ── */
#respond {
  background: var(--bg3);
  border: 1px solid var(--border);
  border-radius: 20px;
  padding: 40px;
}
@media (max-width: 640px) { #respond { padding: 24px; } }

#respond #reply-title {
  font-family: 'Inter Tight', sans-serif;
  font-size: 1.2rem; font-weight: 900; color: var(--title);
  margin: 0 0 6px; letter-spacing: -.02em;
}
#respond #reply-title small {
  font-size: .78rem; font-weight: 700;
}
#respond #reply-title small a {
  color: var(--tc); text-decoration: none; margin-left: 8px;
}
.comment-notes {
  font-size: .8rem; color: var(--meta); margin: 0 0 24px;
}
.logged-in-as {
  font-size: .82rem; color: var(--meta); margin: 0 0 20px;
}
.logged-in-as a { color: var(--tc); text-decoration: none; }

/* Form layout */
.comment-form {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}
.comment-form-comment,
.comment-form-cookies-consent,
.form-submit,
p.logged-in-as { grid-column: 1 / -1; }

/* Labels */
.comment-form label {
  display: block;
  font-size: .75rem; font-weight: 700; color: var(--txt);
  letter-spacing: .05em; text-transform: uppercase;
  margin-bottom: 7px;
}
.comment-form label .required { color: var(--tc); margin-left: 2px; }

/* Fields */
.comment-form input[type="text"],
.comment-form input[type="email"],
.comment-form input[type="url"],
.comment-form textarea {
  width: 100%;
  padding: 11px 14px;
  background: rgba(255,255,255,.04);
  border: 1px solid var(--border);
  border-radius: 10px;
  color: var(--title);
  font-family: inherit; font-size: .88rem;
  outline: none;
  transition: border-color .2s, background .2s;
  box-sizing: border-box;
  -webkit-appearance: none; appearance: none;
}
.comment-form input:focus,
.comment-form textarea:focus {
  border-color: rgba(255,94,46,.45);
  background: rgba(255,94,46,.025);
}
.comment-form input::placeholder,
.comment-form textarea::placeholder { color: var(--meta); }
.comment-form textarea { min-height: 120px; resize: vertical; }

/* Checkbox */
.comment-form-cookies-consent {
  display: flex; align-items: flex-start; gap: 10px;
}
.comment-form-cookies-consent label {
  text-transform: none; letter-spacing: 0; font-size: .82rem;
  color: var(--meta); font-weight: 500;
}
.comment-form input[type="checkbox"] {
  width: 15px; height: 15px;
  accent-color: var(--tc); flex-shrink: 0; margin-top: 2px;
}

/* Submit */
.comment-form .submit {
  display: inline-flex; align-items: center; gap: 8px;
  background: linear-gradient(135deg, #ff5e2e, #ed4c1c);
  color: #fff; font-family: inherit;
  font-size: .88rem; font-weight: 800; letter-spacing: .04em;
  padding: 13px 36px; border: none; border-radius: 100px;
  cursor: pointer;
  box-shadow: 0 8px 24px rgba(255,94,46,.25);
  transition: opacity .2s, transform .2s;
}
.comment-form .submit:hover { opacity: .9; transform: translateY(-1px); }

@media (max-width: 600px) {
  .comment-form { grid-template-columns: 1fr; }
  .comment-form-author,
  .comment-form-email,
  .comment-form-url { grid-column: 1; }
}
</style>

<div id="comments" class="tf-comments-wrap">

	<?php if ( have_comments() ) : ?>

		<h2 class="tf-cmt-heading">
			<?php
			$cmt_num = (int) get_comments_number();
			echo esc_html( sprintf(
				/* translators: %d comment count */
				_n( '%d Comment', '%d Comments', $cmt_num, 'themeflex' ),
				$cmt_num
			) );
			?>
			<span class="tf-cmt-badge"><?php echo number_format_i18n( $cmt_num ); ?></span>
		</h2>

		<ol class="tf-cmt-list">
			<?php
			wp_list_comments( array(
				'style'       => 'ol',
				'short_ping'  => true,
				'avatar_size' => 46,
				'callback'    => 'themeflex_comment_callback',
			) );
			?>
		</ol>

		<?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : ?>
		<nav class="tf-cmt-pagination" aria-label="<?php esc_attr_e( 'Comment navigation', 'themeflex' ); ?>">
			<?php
			paginate_comments_links( array(
				'prev_text' => '&lsaquo;',
				'next_text' => '&rsaquo;',
			) );
			?>
		</nav>
		<?php endif; ?>

	<?php elseif ( get_comments_number() === '0' && comments_open() ) : ?>

		<div class="tf-cmt-empty">
			<svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
			<?php esc_html_e( 'No comments yet. Be the first to share your thoughts!', 'themeflex' ); ?>
		</div>

	<?php endif; ?>

	<?php if ( ! comments_open() && get_comments_number() !== '0' ) : ?>
		<div class="tf-cmt-closed">
			<?php esc_html_e( 'Comments are closed.', 'themeflex' ); ?>
		</div>
	<?php endif; ?>

	<?php
	comment_form( array(
		'title_reply'          => esc_html__( 'Leave a Comment', 'themeflex' ),
		'title_reply_to'       => esc_html__( 'Reply to %s', 'themeflex' ),
		'cancel_reply_link'    => esc_html__( 'Cancel reply', 'themeflex' ),
		'label_submit'         => esc_html__( 'Post Comment', 'themeflex' ),
		'comment_notes_before' => '<p class="comment-notes">' .
			esc_html__( 'Your email address will not be published. Required fields are marked', 'themeflex' ) .
			' <span class="required" aria-hidden="true">*</span></p>',
		'comment_field' =>
			'<p class="comment-form-comment">' .
			'<label for="comment">' . esc_html__( 'Comment', 'themeflex' ) .
			' <span class="required" aria-hidden="true">*</span></label>' .
			'<textarea id="comment" name="comment" cols="45" rows="5" maxlength="65525" required ' .
			'placeholder="' . esc_attr__( 'Share your thoughts…', 'themeflex' ) . '"></textarea></p>',
	) );
	?>

</div><!-- #comments -->

<?php
/**
 * Custom comment template callback.
 *
 * @param WP_Comment $comment Comment object.
 * @param array      $args    Args from wp_list_comments().
 * @param int        $depth   Nesting depth.
 */
if ( ! function_exists( 'themeflex_comment_callback' ) ) :
function themeflex_comment_callback( $comment, $args, $depth ) {
	$tag = ( 'div' === $args['style'] ) ? 'div' : 'li';
	?>
<<?php echo esc_attr( $tag ); ?> id="comment-<?php comment_ID(); ?>" <?php comment_class( ! empty( $args['has_children'] ) ? 'parent' : '', $comment ); ?>>
<div class="tf-cmt">

	<?php echo get_avatar( $comment, 46, '', '', array( 'class' => 'tf-cmt-avatar' ) ); ?>

	<div class="tf-cmt-inner">
		<div class="tf-cmt-meta">
			<span class="tf-cmt-author"><?php comment_author_link( $comment ); ?></span>
			<span class="tf-cmt-date">
				<a href="<?php echo esc_url( get_comment_link( $comment, $args ) ); ?>">
					<time datetime="<?php comment_time( 'c' ); ?>"><?php comment_date(); ?></time>
				</a>
			</span>
			<?php if ( '0' === $comment->comment_approved ) : ?>
				<span class="tf-cmt-pending"><?php esc_html_e( 'Awaiting moderation', 'themeflex' ); ?></span>
			<?php endif; ?>
		</div>

		<div class="tf-cmt-text">
			<?php comment_text(); ?>
		</div>

		<div class="tf-cmt-reply">
			<?php
			comment_reply_link( array_merge( $args, array(
				'add_below' => 'comment',
				'depth'     => $depth,
				'max_depth' => $args['max_depth'],
				'before'    => '',
				'after'     => '',
				'reply_text'=> '↩ ' . esc_html__( 'Reply', 'themeflex' ),
			) ) );
			?>
		</div>
	</div>

</div>
	<?php
}
endif;
