# Starter Flavor Theme - Build Process Documentation

## Overview

The Starter Flavor WordPress theme includes a comprehensive build process for minifying CSS and JavaScript assets. This process reduces file sizes by an average of 26.8%, improving page load times and performance.

## What Was Built

### Asset Minification
- **38 CSS files** reduced from 285.64 KB to 216.03 KB (24.4% reduction)
- **36 JavaScript files** reduced from 209.33 KB to 146.56 KB (30.0% reduction)
- **Total savings: 132.41 KB** (26.8% combined reduction)

### Build Scripts Created

```
scripts/
├── build.py              # Master build orchestrator
├── minify-css.py         # CSS minification engine
├── minify-js.py          # JavaScript minification engine
└── watch.sh              # File watcher for development
```

### Asset Loader System

**File:** `includes/class-asset-loader.php`

A smart PHP class that:
- Auto-detects minified `.min.css` and `.min.js` files
- Loads minified files in production (when `SCRIPT_DEBUG = false`)
- Falls back to unminified files in development mode
- Provides helper functions for easy integration

## Quick Start

### Building Assets

#### Option 1: Using npm (from theme root)
```bash
npm run build           # Build once
npm run build:css       # CSS only
npm run build:js        # JavaScript only
npm run watch           # Watch for changes and rebuild
```

#### Option 2: Using Python (from theme root)
```bash
python3 scripts/build.py
```

#### Option 3: Using Make (from project root)
```bash
make build-assets
```

### Using the Asset Loader

In your `functions.php` or relevant theme file:

```php
// Include the asset loader
require_once get_template_directory() . '/includes/class-asset-loader.php';

// Use helper functions to enqueue assets
sf_enqueue_style( 'my-handle', 'my-style.css' );
sf_enqueue_script( 'my-handle', 'my-script.js' );

// Or get individual asset URLs
echo sf_asset_url( 'my-style.css' ); // Returns minified or unminified URL
```

## Configuration

### Development vs Production

The build system automatically detects whether you're in development or production mode:

**Production (Default):**
- `SCRIPT_DEBUG` is `false` or undefined
- Minified files (`.min.css`, `.min.js`) are automatically loaded
- Smaller file sizes = faster page loads

**Development:**
- `SCRIPT_DEBUG` is `true`
- Unminified files are loaded for easier debugging
- Line numbers match source files
- Comments and whitespace preserved

Set in `wp-config.php`:
```php
// Development
define( 'SCRIPT_DEBUG', true );

// Production
define( 'SCRIPT_DEBUG', false );
```

## File Structure

```
starter-flavor/
├── assets/
│   ├── css/
│   │   ├── animations.css         # Original
│   │   ├── animations.min.css     # Minified (auto-generated)
│   │   ├── elementor-widgets.css
│   │   ├── elementor-widgets.min.css
│   │   └── ... (36 more CSS files)
│   └── js/
│       ├── animations.js          # Original
│       ├── animations.min.js      # Minified (auto-generated)
│       ├── elementor-widgets.js
│       ├── elementor-widgets.min.js
│       └── ... (34 more JS files)
├── includes/
│   ├── class-asset-loader.php     # NEW: Smart asset loader
│   └── ... (other includes)
├── scripts/
│   ├── build.py                   # NEW: Master build script
│   ├── minify-css.py              # NEW: CSS minifier
│   ├── minify-js.py               # NEW: JS minifier
│   └── watch.sh                   # NEW: File watcher
├── package.json                    # NEW: npm configuration
└── BUILD_PROCESS.md               # This file
```

## Minification Details

### CSS Minification (`minify-css.py`)

The CSS minifier performs safe transformations:

✓ **Removes:**
- Multi-line comments (`/* ... */`)
- Single-line comments (`//`)
- Unnecessary whitespace
- Blank lines
- Spaces around selectors, properties, and values

✓ **Preserves:**
- All CSS functionality
- Vendor prefixes
- Media queries
- Pseudo-classes and pseudo-elements

**Example:**
```css
/* Before: 500 bytes */
.button {
  background-color: #007bff;
  color: white;
  padding: 10px 20px;
  /* Some comment */
}

/* After: 60 bytes */
.button{background-color:#007bff;color:white;padding:10px 20px}
```

### JavaScript Minification (`minify-js.py`)

The JavaScript minifier is carefully designed to be safe:

✓ **Removes:**
- Single-line comments (`//`)
- Multi-line comments (`/* ... */`)
- Unnecessary whitespace
- Blank lines
- Spaces around operators and punctuation

✓ **Preserves:**
- WordPress global variables (`window`, `jQuery`, `wp`, etc.)
- All function names (no variable renaming)
- String content
- Code functionality and logic

⚠️ **Safe by Design:**
- No variable renaming (respects WordPress globals)
- No minification of function names
- Comment detection avoids URLs in strings
- Conservative whitespace collapsing

**Example:**
```javascript
/* Before: 400 bytes */
// Initialize the widget
function initWidget() {
  // Get the container
  const container = document.getElementById('widget');
  // Set up event listeners
  container.addEventListener('click', handleClick);
}

/* After: 100 bytes */
function initWidget(){const container=document.getElementById('widget');container.addEventListener('click',handleClick)}
```

## API Reference

### Asset Loader Class

```php
// Get the asset loader instance
$loader = sf_get_asset_loader();

// Get asset URL (auto-detects minified version)
$url = $loader->get_asset_url( 'style.css' );

// Enqueue CSS
$loader->enqueue_style( 'handle', 'style.css', array(), 'all' );

// Enqueue JavaScript
$loader->enqueue_script( 'handle', 'script.js', array(), true, $localized_data );

// Check if asset exists
if ( $loader->asset_exists( 'style.css' ) ) {
  // Asset found
}

// Get asset version (for cache busting)
$version = $loader->get_version();

// Check if debug mode is enabled
if ( $loader->is_debug_mode() ) {
  // Development mode
}

// Get all CSS assets
$css_files = $loader->get_css_assets();

// Get all JS assets
$js_files = $loader->get_js_assets();
```

### Helper Functions

```php
// Get asset URL
$url = sf_asset_url( 'style.css' );

// Enqueue style
sf_enqueue_style( 'handle', 'style.css', array(), 'all' );

// Enqueue script
sf_enqueue_script( 'handle', 'script.js', array(), true, array(
  'i18n' => array( 'hello' => 'world' ),
) );

// Get loader instance
$loader = sf_get_asset_loader();
```

## Watch Mode for Development

Use the watch script to automatically rebuild assets when they change:

### On Linux (using inotifywait)
```bash
npm run watch
# or
bash scripts/watch.sh
```

The script monitors `assets/css/` and `assets/js/` directories. Any changes to unminified files trigger an automatic rebuild.

### Installation Requirements

**Linux:**
```bash
sudo apt-get install inotify-tools
```

**macOS:**
```bash
brew install fswatch
```

**Any System (Polling - slower):**
No installation needed; uses built-in polling (2-second intervals).

## Build Output

When you run the build process, you'll see detailed output:

```
[10:11:00] [START] Processing CSS files in .../assets/css
--------------------------------------------------------------------------------
[10:11:00] [MINIFY] ai-assistant.css                      11.76 KB →  9.47 KB ( 19.5% reduction)
[10:11:00] [MINIFY] animations.css                         3.15 KB →  2.34 KB ( 25.7% reduction)
...
--------------------------------------------------------------------------------
[10:11:00] [SUMMARY] Total: 285.64 KB → 216.03 KB (24.4% reduction) - 38 files

[10:11:00] [START] Processing JavaScript files in .../assets/js
...
[10:11:01] [SUMMARY] Total: 209.33 KB → 146.56 KB (30.0% reduction) - 36 files
```

## Workflow Integration

### Development Workflow
1. Edit CSS/JS files in `assets/css/` and `assets/js/`
2. Run `npm run watch` to automatically minify on changes
3. Open `wp-config.php` and set `define( 'SCRIPT_DEBUG', true );`
4. Test with unminified files (easier debugging)
5. Use browser DevTools to debug JavaScript

### Pre-Production Workflow
1. Ensure all CSS/JS files are finalized
2. Run `npm run build` (or `make build-assets`)
3. Verify minified files exist: `ls assets/css/*.min.css`
4. Test with minified files in staging environment
5. Set `define( 'SCRIPT_DEBUG', false );` for production
6. Deploy to production

### Continuous Integration
Add to your CI/CD pipeline:
```bash
# Build assets before deploying
cd themes/entwicklung/starter-flavor
python3 scripts/build.py

# Verify minified files exist
test -f assets/css/elementor-widgets.min.css
test -f assets/js/elementor-widgets.min.js

# Continue with deployment...
```

## Performance Impact

### Before Build Process
```
CSS Total:  285.64 KB
JS Total:   209.33 KB
Combined:   495 KB
```

### After Build Process
```
CSS Total:  216.03 KB (saved 69.61 KB)
JS Total:   146.56 KB (saved 62.77 KB)
Combined:   362.59 KB (saved 132.41 KB)
```

**Performance Improvement: 26.8% reduction in asset size**

### Page Load Time Improvement

With typical compression (gzip):
- CSS files: 40-50% reduction with gzip
- JS files: 65-75% reduction with gzip
- Estimated page load improvement: 5-10% faster

## Troubleshooting

### Minified files not being generated

**Issue:** `*.min.css` and `*.min.js` files don't exist

**Solution:**
1. Verify Python 3 is installed: `python3 --version`
2. Run build manually: `python3 scripts/build.py`
3. Check for errors in output
4. Verify `assets/css/` and `assets/js/` directories exist

### Assets not loading correctly

**Issue:** Assets 404 or not loading

**Solution:**
1. Verify minified files exist: `ls assets/css/*.min.css`
2. Check `SCRIPT_DEBUG` setting in `wp-config.php`
3. Verify asset URLs in browser DevTools (Network tab)
4. Check WordPress error logs: `wp-content/debug.log`

### Watch mode not detecting changes

**Issue:** `npm run watch` doesn't rebuild on file changes

**Solution:**
1. Verify file system supports inotify/fswatch
2. Try polling mode instead: `bash scripts/watch.sh`
3. Manually run `npm run build` after making changes
4. Check for file permission issues: `chmod 644 assets/css/*.css`

## Support

For issues or questions about the build process:
1. Check the troubleshooting section above
2. Verify all scripts are executable: `chmod +x scripts/*.py scripts/*.sh`
3. Check theme documentation: `README.txt`, `IMPLEMENTATION_SUMMARY.md`
4. Review theme code structure: `THEME_STRUCTURE.txt`

## Future Enhancements

Potential improvements to the build process:
- [ ] Add CSS concatenation (combine multiple CSS files)
- [ ] Add JavaScript bundling (combine and minify all JS)
- [ ] Add source maps for debugging minified code
- [ ] Add vendor prefix auto-detection
- [ ] Add CSS class name obfuscation (optional)
- [ ] Add integration with webpack or Gulp
- [ ] Add automated testing of minified assets
- [ ] Add SVG optimization

## References

- WordPress Theme Development: https://developer.wordpress.org/themes/
- Asset Management: https://developer.wordpress.org/plugins/hooks/actions/wp_enqueue_scripts/
- Performance Optimization: https://developer.wordpress.org/plugins/performance/
- CSS Minification Best Practices: https://web.dev/minify-css/
- JavaScript Minification Best Practices: https://web.dev/reduce-javascript/

---

**Build Process Version:** 1.0.0  
**Last Updated:** 2026-04-13  
**Theme Version:** 1.0.0
