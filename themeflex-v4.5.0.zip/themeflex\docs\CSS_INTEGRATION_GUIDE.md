# CSS Integration Guide - Starter Flavor

Quick reference for integrating the new CSS architecture into your WordPress theme.

## Files Added

```
starter-flavor/
├── assets/css/
│   ├── modern.css          (741 lines - Modern CSS features)
│   └── utilities.css       (493 lines - Utility classes)
├── screenshot.png          (1200x900px - Theme preview)
├── screenshot.svg          (Editable SVG version)
├── tools/
│   └── generate-screenshot.html  (Interactive screenshot creator)
├── CSS_ARCHITECTURE_SUMMARY.md   (Full documentation)
└── CSS_INTEGRATION_GUIDE.md      (This file)
```

## Quick Start

### 1. Enqueue CSS Files in functions.php

Add to your theme's `functions.php`:

```php
function starter_flavor_enqueue_styles() {
    // Modern CSS with cutting-edge features
    wp_enqueue_style(
        'starter-flavor-modern',
        get_template_directory_uri() . '/assets/css/modern.css',
        [],
        wp_get_theme()->get( 'Version' ),
        'all'
    );

    // Utility classes for rapid development
    wp_enqueue_style(
        'starter-flavor-utilities',
        get_template_directory_uri() . '/assets/css/utilities.css',
        [],
        wp_get_theme()->get( 'Version' ),
        'all'
    );
}
add_action( 'wp_enqueue_scripts', 'starter_flavor_enqueue_styles' );
```

### 2. Use in Custom Templates

```html
<!-- Fluid Typography -->
<h1 style="font-size: var(--sf-fluid-h1)">Dynamic Heading</h1>

<!-- Card Component -->
<div class="sf-card sf-card--featured">
    <div class="sf-card__header">
        <img src="image.jpg" alt="" class="sf-card__image">
    </div>
    <div class="sf-card__content">
        <h3 class="sf-card__title">Card Title</h3>
        <p>Card description here.</p>
    </div>
</div>

<!-- Button Component -->
<a href="#" class="sf-btn sf-btn--primary">Primary Button</a>
<button class="sf-btn sf-btn--outline sf-btn--lg">Large Outline</button>

<!-- Grid Component -->
<div class="sf-grid sf-grid--3 sf-gap-lg">
    <div class="sf-card">Card 1</div>
    <div class="sf-card">Card 2</div>
    <div class="sf-card">Card 3</div>
</div>

<!-- Utility Classes -->
<div class="sf-flex sf-items-center sf-justify-between sf-p-md sf-rounded-lg sf-bg-secondary">
    <span class="sf-text-primary sf-font-bold">Left aligned</span>
    <span class="sf-text-muted sf-text-sm">Right aligned</span>
</div>

<!-- Responsive Visibility -->
<nav class="sf-hide-mobile">Desktop navigation</nav>
<nav class="sf-show-mobile sf-hide-tablet sf-hide-desktop">Mobile menu</nav>

<!-- Animations -->
<div class="sf-animate-slide-up sf-stagger-1">Content 1</div>
<div class="sf-animate-slide-up sf-stagger-2">Content 2</div>
<div class="sf-animate-slide-up sf-stagger-3">Content 3</div>
```

### 3. Use in Elementor

1. Select any Elementor widget
2. Go to Advanced → CSS Classes
3. Add utility classes: `.sf-btn .sf-btn--primary .sf-btn--lg`
4. Or component classes: `.sf-card .sf-card--featured`
5. Combine for full control: `.sf-p-md .sf-rounded-lg .sf-shadow-lg`

## Common Patterns

### Responsive Layout
```html
<div class="sf-flex sf-flex-col sf-gap-md">
    <!-- Stacks vertically on mobile, horizontal on desktop -->
    <div class="sf-stack">
        <section class="sf-flex-cols">
            <article>Column 1</article>
            <aside>Column 2</aside>
        </section>
    </div>
</div>
```

### Card Grid
```html
<div class="sf-grid sf-grid--auto-fit sf-gap-lg">
    <div class="sf-card-container">
        <div class="sf-card">
            <img src="image.jpg" alt="" class="sf-card__image">
            <h3 class="sf-card__title">Title</h3>
            <p class="sf-card__content">Description</p>
        </div>
    </div>
    <!-- Repeats for each card -->
</div>
```

### Button Variations
```html
<!-- Size variations -->
<button class="sf-btn sf-btn--primary sf-btn--sm">Small</button>
<button class="sf-btn sf-btn--primary">Default</button>
<button class="sf-btn sf-btn--primary sf-btn--lg">Large</button>

<!-- Style variations -->
<button class="sf-btn sf-btn--primary">Solid Primary</button>
<button class="sf-btn sf-btn--secondary">Solid Secondary</button>
<button class="sf-btn sf-btn--outline">Outline</button>
<button class="sf-btn sf-btn--ghost">Ghost</button>

<!-- Special states -->
<button class="sf-btn sf-btn--primary sf-btn--loading">Loading...</button>
<button class="sf-btn sf-btn--icon sf-btn--primary">+</button>
```

### Staggered List Animation
```html
<ul class="sf-flex sf-flex-col sf-gap-sm">
    <li class="sf-animate-slide-up sf-stagger-1">Item 1</li>
    <li class="sf-animate-slide-up sf-stagger-2">Item 2</li>
    <li class="sf-animate-slide-up sf-stagger-3">Item 3</li>
    <li class="sf-animate-slide-up sf-stagger-4">Item 4</li>
    <li class="sf-animate-slide-up sf-stagger-5">Item 5</li>
    <li class="sf-animate-slide-up sf-stagger-6">Item 6</li>
</ul>
```

### Dark Mode Support
```html
<div class="sf-card">
    <!-- Automatically adapts to dark mode -->
    <h3 class="sf-card__title">Works in light and dark modes</h3>
</div>

<!-- Custom dark mode styling if needed -->
<style>
    @media (prefers-color-scheme: dark) {
        .custom-element {
            background: var(--sf-color-bg-dark);
            color: var(--sf-color-title-dark);
        }
    }
</style>
```

## Available CSS Variables

### Colors
```css
--sf-color-bg: #FFFFFF;
--sf-color-bg-secondary: #F6F7F1;
--sf-color-border: #E5E7DE;
--sf-color-title: #1F242E;
--sf-color-text: #86898C;
--sf-color-meta: #ACAFB2;
--sf-color-link: #FF5E2E;
--sf-color-link-hover: #ED4C1C;
```

### Typography
```css
--sf-font-body: 'Inter', sans-serif;
--sf-font-headings: 'Inter Tight', sans-serif;
--sf-font-size-h1: 57px;
--sf-font-size-body: 16px;
--sf-line-height-headings: 1.2;
--sf-line-height-body: 1.625;
```

### Spacing (Fixed)
```css
--sf-spacing-xs: 8px;
--sf-spacing-sm: 16px;
--sf-spacing-md: 24px;
--sf-spacing-lg: 32px;
--sf-spacing-xl: 48px;
--sf-spacing-2xl: 64px;
--sf-spacing-3xl: 96px;
```

### Spacing (Fluid)
```css
--sf-fluid-sm: clamp(1rem, 0.8rem + 0.8vw, 1.5rem);
--sf-fluid-md: clamp(1.5rem, 1.2rem + 1.2vw, 2.25rem);
--sf-fluid-lg: clamp(2rem, 1.6rem + 1.6vw, 3rem);
/* ... more fluid scales */
```

### Shadows
```css
--sf-shadow-xs: 0 1px 2px rgba(31, 36, 46, 0.05);
--sf-shadow-sm: 0 1px 3px rgba(31, 36, 46, 0.1);
--sf-shadow-md: 0 4px 6px rgba(31, 36, 46, 0.1);
--sf-shadow-lg: 0 10px 15px rgba(31, 36, 46, 0.1);
--sf-shadow-xl: 0 20px 25px rgba(31, 36, 46, 0.1);
--sf-shadow-2xl: 0 25px 50px rgba(31, 36, 46, 0.25);
```

### Transitions
```css
--sf-transition-fast: 150ms ease;
--sf-transition-base: 200ms ease;
--sf-transition-slow: 300ms ease;
--sf-transition-slower: 500ms ease;
```

## Component Reference

### Card Component Modifiers
```html
.sf-card                    <!-- Base card -->
.sf-card--featured          <!-- Highlighted with accent border -->
.sf-card--horizontal        <!-- Side-by-side image and content -->
.sf-card__header            <!-- Card header section -->
.sf-card__image             <!-- Image element -->
.sf-card__title             <!-- Heading -->
.sf-card__content           <!-- Main content -->
.sf-card__footer            <!-- Footer section -->
```

### Button Component Modifiers
```html
.sf-btn                     <!-- Base button -->
.sf-btn--primary            <!-- Accent color -->
.sf-btn--secondary          <!-- Light gray -->
.sf-btn--outline            <!-- Border style -->
.sf-btn--ghost              <!-- Text only -->
.sf-btn--sm                 <!-- Small size -->
.sf-btn--lg                 <!-- Large size -->
.sf-btn--icon               <!-- Icon button -->
.sf-btn--loading            <!-- Loading spinner state -->
```

### Grid Component Modifiers
```html
.sf-grid                    <!-- Base grid -->
.sf-grid--2                 <!-- 2-column responsive -->
.sf-grid--3                 <!-- 3-column responsive -->
.sf-grid--4                 <!-- 4-column responsive -->
.sf-grid--auto-fit          <!-- Auto-fit responsive -->
.sf-grid--masonry           <!-- Multi-column layout -->
```

## Responsive Breakpoints

```css
Mobile:     max-width: 640px
Tablet:     641px to 1024px
Desktop:    min-width: 1025px
```

Use utility class suffixes for responsive variants:
```html
.sf-hide-mobile             <!-- Hide on mobile -->
.sf-show-mobile             <!-- Show only on mobile -->
.sf-hide-tablet             <!-- Hide on tablet -->
.sf-hide-desktop            <!-- Hide on desktop -->
```

## Animation Utilities

### Available Animations
```css
.sf-animate-fade-in         <!-- Opacity fade in -->
.sf-animate-slide-up        <!-- Slide up from bottom -->
.sf-animate-slide-down      <!-- Slide down from top -->
.sf-animate-slide-left      <!-- Slide left from right -->
.sf-animate-slide-right     <!-- Slide right from left -->
.sf-animate-zoom-in         <!-- Scale up from smaller -->
.sf-animate-bounce-in       <!-- Bounce effect -->
.sf-animate-shimmer         <!-- Loading shimmer -->
.sf-animate-pulse           <!-- Pulsing opacity -->
```

### Stagger Delays
```css
.sf-stagger-1               <!-- 50ms delay -->
.sf-stagger-2               <!-- 100ms delay -->
.sf-stagger-3               <!-- 150ms delay -->
.sf-stagger-4               <!-- 200ms delay -->
.sf-stagger-5               <!-- 250ms delay -->
.sf-stagger-6               <!-- 300ms delay -->
```

## Container Query Support

Modern browsers support responsive layouts without media queries:

```html
<div class="sf-card-container">
    <!-- Automatically responds to container width -->
    <div class="sf-card">Content adapts to space</div>
</div>
```

Requires modern browser (Chrome 105+, Firefox 110+, Safari 16+)

## Performance Tips

1. **Use CSS Variables** for theming instead of duplicating colors
2. **Combine Utility Classes** instead of writing custom CSS
3. **Leverage Fluid Typography** to avoid breakpoint-specific font sizes
4. **Enable Gzip Compression** (combined CSS is only 9KB gzipped)
5. **Minify in Production** (CSS files are readable for development)

## Troubleshooting

### Classes Not Applying?
- Ensure CSS files are enqueued with correct priority
- Check for specificity conflicts with other stylesheets
- Verify class names are spelled correctly (case-sensitive)

### Animations Not Working?
- Check `prefers-reduced-motion` user settings
- Verify browser supports CSS animations
- Ensure animation classes are applied to correct elements

### Container Queries Not Working?
- Requires Chrome 105+, Firefox 110+, Safari 16+
- For older browser support, use media queries instead
- Test with `.sf-container-supported` class detection

### Dark Mode Issues?
- Verify browser/OS dark mode is enabled
- Check that color variables are properly scoped
- Ensure sufficient contrast in dark mode colors

## Support & Documentation

For complete documentation, see: `CSS_ARCHITECTURE_SUMMARY.md`

For feature details, review:
- `assets/css/modern.css` - All modern features with comments
- `assets/css/utilities.css` - Complete utility class definitions

## Version Info

- **Version**: 1.0.0
- **Created**: April 13, 2026
- **Compatible With**: WordPress 6.0+, Elementor 3.0+
- **Browser Support**: Chrome 90+, Firefox 88+, Safari 14+, Edge 90+
