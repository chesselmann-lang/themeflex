# Customizer Usage Guide - Starter Flavor Theme

## Quick Start

### Accessing the Customizer
1. Log in to WordPress admin
2. Go to **Appearance** > **Customize**
3. Available panels appear in left sidebar

### Panel Navigation
All customizer panels are organized by function:
- **Colors** - Color Scheme panel
- **Site Identity** - WordPress default panel
- **Header** - Header Options panel
- **Footer** - Footer Options panel
- **Blog** - Blog Options panel
- **Colors** (bottom) - Dark Mode settings

---

## Panel Guide

### 1. Color Scheme Panel

**Location**: Customize > Colors (default Colors section)

**Controls**:
1. **Primary Color**
   - Default: #FF5E2E (Orange)
   - Used for: Links, buttons, accents
   - Live preview: Enabled
   - Affects: All elements using `--sf-color-primary`

2. **Secondary Color**
   - Default: #1F242E (Dark Blue)
   - Used for: Headings, emphasis
   - Live preview: Enabled

3. **Accent Color**
   - Default: #ED4C1C (Dark Orange)
   - Used for: Hover states, highlights
   - Live preview: Enabled

4. **Background Color**
   - Default: #FFFFFF (White)
   - Used for: Page background
   - Live preview: Enabled

5. **Text Color**
   - Default: #86898C (Gray)
   - Used for: Body text, paragraphs
   - Live preview: Enabled

**Quick Tips**:
- Colors update in preview instantly
- No page reload needed
- Click "Save & Publish" to apply to live site
- Use color picker or enter hex code

**Example Color Schemes**:
```
Professional:
- Primary: #2563eb (Blue)
- Secondary: #1e293b (Dark Slate)
- Accent: #0ea5e9 (Light Blue)

Creative:
- Primary: #a855f7 (Purple)
- Secondary: #1e1b4b (Deep Purple)
- Accent: #ec4899 (Pink)

Nature:
- Primary: #16a34a (Green)
- Secondary: #15803d (Dark Green)
- Accent: #84cc16 (Lime)
```

---

### 2. Typography Panel

**Location**: Customize > Typography

**Sections**:

#### Headings Subsection

1. **Headings Font**
   - Dropdown menu with 20 Google Fonts
   - Default: Inter Tight
   - Live preview: Font loads dynamically
   - Options: Inter, Roboto, Poppins, Playfair Display, etc.

2. **H1 Size**
   - Range: 24px - 120px
   - Default: 57px
   - Live preview: Enabled
   - Unit: Pixels

3. **H2 Size**
   - Range: 24px - 120px
   - Default: 47px
   - Live preview: Enabled

4. **H3 Size**
   - Range: 20px - 100px
   - Default: 35px
   - Live preview: Enabled

#### Body Text Subsection

1. **Body Font**
   - Dropdown menu with 20 Google Fonts
   - Default: Inter
   - Live preview: Font loads dynamically

2. **Body Font Size**
   - Range: 12px - 24px
   - Default: 16px
   - Live preview: Enabled
   - Note: Controls main text size on pages and posts

**Available Fonts**:
```
Sans-Serif (Recommended):
- Inter (modern, clean)
- Roboto (versatile)
- Open Sans (friendly)
- Poppins (modern, rounded)
- Lato (geometric)

Serif (Elegant):
- Merriweather (classic)
- Playfair Display (luxury)
- PT Sans (professional)

Display (Headlines):
- Montserrat (bold)
- Oswald (compact)
- Raleway (elegant)
```

**Font Selection Tips**:
- Headlines: Choose distinctive fonts (Playfair, Montserrat, Oswald)
- Body: Choose readable fonts (Inter, Open Sans, Lato)
- Avoid using same font for both (creates visual hierarchy)
- Test with different sizes before publishing

---

### 3. Header Options Panel

**Location**: Customize > Header Image (section expanded with new controls)

**Controls**:

1. **Header Layout**
   - Options: Standard / Centered / Transparent
   - Default: Standard
   - Live preview: Layout updates instantly
   
   **Standard**: Logo left, menu right (traditional)
   **Centered**: Logo centered, menu below
   **Transparent**: No background, overlays content

2. **Enable Sticky Header**
   - Toggle: On / Off
   - Default: On
   - Live preview: Enabled
   - Effect: Header stays visible when scrolling
   - Note: Only visible on desktop (mobile uses hamburger menu)

3. **Header Height**
   - Range: 50px - 200px
   - Default: 80px
   - Live preview: Enabled
   - Effect: Controls vertical space for logo and menu

**Layout Examples**:
```
Standard Layout (80px height):
┌─────────────────────────────────────┐
│ [Logo] [Menu Items...] [Search]     │
└─────────────────────────────────────┘

Centered Layout (80px height):
┌─────────────────────────────────────┐
│         [Logo Centered]             │
│      [Menu Items Centered]          │
└─────────────────────────────────────┘

Transparent Layout (60px height):
┌─────────────────────────────────────┐
│ [Logo] Overlays Hero Image [Search] │
└─────────────────────────────────────┘
```

---

### 4. Footer Options Panel

**Location**: Customize > Footer Image (section expanded with new controls)

**Controls**:

1. **Footer Columns**
   - Options: 1 / 2 / 3 / 4
   - Default: 4
   - Live preview: Layout updates instantly
   - Effect: Controls widget area layout using CSS Grid
   
   **1 Column**: Full width footer widgets (stacked)
   **2 Columns**: Side by side layout
   **3 Columns**: Three equal columns
   **4 Columns**: Four equal columns

2. **Copyright Text**
   - Text area with rich text support
   - Default: © [Site Name] [Year]. All rights reserved.
   - Live preview: Enabled
   - Supports: HTML formatting, entities
   
   **Available Variables**:
   - `{year}` → Current year
   - `{site_name}` → Your site name
   - `{home_url}` → Site home URL

**Example Copyright Texts**:
```
Simple:
© 2026 Your Company. All rights reserved.

With Link:
© 2026 <a href="/">Your Company</a>. All rights reserved.

With License:
© 2026 Your Company. Some rights reserved under <a href="#">CC License</a>.

Multi-line:
© 2026 Your Company<br>Made with ❤️ by WhatsDigital<br>All rights reserved.
```

**Footer Columns Responsive Behavior**:
- Desktop: Displays as configured (1, 2, 3, or 4 columns)
- Tablet: Adjusts to 2 columns if set to 3-4
- Mobile: All widgets stack to 1 column

---

### 5. Blog Options Panel

**Location**: Customize > Blog Image (new Blog panel)

**Controls**:

1. **Blog Layout**
   - Options: Grid / List
   - Default: Grid
   - Live preview: Layout updates instantly
   
   **Grid Layout**:
   - Multiple columns on desktop
   - Card-style design
   - Featured images visible
   - Good for visual content
   
   **List Layout**:
   - Single column
   - Featured image left, text right
   - More text visible
   - Good for text-heavy blogs

2. **Excerpt Length**
   - Range: 5 - 100 words
   - Default: 20 words
   - Effect: Controls post preview length
   - Note: Applies to `the_excerpt()` template tag
   
   **Common Settings**:
   - 15 words: Very short preview (teaser)
   - 20 words: Default (balanced)
   - 30 words: Longer preview
   - 50 words: Substantial preview

3. **Pagination Style**
   - Options: Numbers / Previous-Next / Infinite Scroll
   - Default: Numbers
   - Live preview: Enabled
   
   **Numbers**: Classic pagination (1 2 3 4 5...)
   **Previous/Next**: Simple prev/next buttons
   **Infinite Scroll**: Load more on scroll (requires JS implementation)

**Example Configurations**:
```
News Website:
- Blog Layout: List
- Excerpt Length: 30
- Pagination: Previous/Next

Portfolio Site:
- Blog Layout: Grid
- Excerpt Length: 15
- Pagination: Numbers

Magazine:
- Blog Layout: Grid
- Excerpt Length: 25
- Pagination: Numbers
```

---

### 6. Dark Mode Panel

**Location**: Customize > Colors (bottom of panel)

**Controls**:

1. **Dark Mode Setting**
   - Options: Off / Auto / Manual
   - Default: Auto
   - Live preview: Enabled
   
   **Off**: Dark mode disabled
   **Auto**: Respects system preference (OS dark mode setting)
   **Manual**: User can toggle dark mode on/off

2. **Dark Mode Primary Color**
   - Default: #FF5E2E (Same as light mode)
   - Used for: Links, buttons in dark mode
   - Live preview: Enabled
   - Tip: Choose lighter shade of primary color

3. **Dark Mode Background Color**
   - Default: #06021D (Very dark blue)
   - Used for: Background in dark mode
   - Live preview: Enabled
   - Tip: WCAG AAA contrast with text color

4. **Dark Mode Text Color**
   - Default: #B8BCC4 (Light gray)
   - Used for: Body text in dark mode
   - Live preview: Enabled
   - Tip: Use lighter colors for text in dark mode

**Dark Mode Behavior**:

**Off Mode**:
- Always light theme
- System preference ignored
- Fastest (no theme detection)

**Auto Mode**:
- Follows system preference
- User changes in OS settings apply
- No toggle button needed
- Modern/accessible approach

**Manual Mode**:
- User clicks toggle button (requires JS)
- Preference stored in localStorage
- Persists across sessions
- Most user control

**CSS Variables for Dark Mode**:
```css
/* Auto mode (system preference) */
@media (prefers-color-scheme: dark) {
  :root {
    --sf-color-primary: #FF5E2E;
    --sf-color-bg: #06021D;
    --sf-color-text: #B8BCC4;
  }
}

/* Manual mode (user toggle) */
[data-theme="dark"] {
  --sf-color-primary: #FF5E2E;
  --sf-color-bg: #06021D;
  --sf-color-text: #B8BCC4;
}
```

**Dark Mode Color Recommendations**:
```
Dark Mode Colors (Testing):
- Background: #06021D or #1a1f2e
- Primary: #FF5E2E (same as light)
- Accent: #ED4C1C
- Text: #B8BCC4 or #E0E0E0
- Secondary: #FFFEFE

Verify WCAG Contrast:
- Text (#B8BCC4) on BG (#06021D): 14:1 ratio (AAA)
- Primary (#FF5E2E) on BG (#06021D): 9:1 ratio (AAA)
```

---

## Live Preview Features

### How Live Preview Works
1. Make a change in customizer
2. Preview pane updates immediately
3. No page reload needed
4. Change reverts if not published
5. Click "Save & Publish" to apply

### Preview-Enabled Settings
✅ All color settings
✅ All typography settings  
✅ All header settings
✅ All footer settings
✅ All blog layout settings
✅ All dark mode settings

### What Requires Page Reload
- Excerpt length (updates on next page load after publish)
- Some responsive adjustments
- Cache clearing (may need manual refresh)

---

## Common Tasks

### Change Theme Colors
1. Go to **Customize > Colors**
2. Click color field to open picker
3. Adjust hue, saturation, brightness
4. Or paste hex code directly
5. Watch preview update
6. Click **Save & Publish**

### Switch Blog Layout
1. Go to **Customize > Blog Options**
2. Select **Blog Layout**
3. Choose **Grid** or **List**
4. Preview updates immediately
5. Check different pages (archive, homepage)
6. Click **Save & Publish**

### Set Dark Mode
1. Go to **Customize > Colors** (scroll to bottom)
2. Find **Dark Mode** setting
3. Choose: Off / Auto / Manual
4. Set dark mode colors
5. Test on dark mode device or use browser dev tools
6. Click **Save & Publish**

### Add Copyright Text
1. Go to **Customize > Footer Options**
2. Click **Copyright Text** field
3. Type or paste your copyright
4. Can include: HTML, year, company name
5. Watch footer update in preview
6. Click **Save & Publish**

### Create Custom Font Pairing
1. Go to **Customize > Typography > Headings**
2. Select **Headings Font** (e.g., Playfair Display)
3. Go to **Body Text** section
4. Select **Body Font** (e.g., Inter)
5. Adjust sizes as needed
6. Preview changes in real-time
7. Click **Save & Publish**

---

## Troubleshooting

### Colors not updating in preview
- **Solution**: Hard refresh (Ctrl+F5 or Cmd+Shift+R)
- **Check**: JavaScript console for errors (F12)

### Fonts not loading
- **Solution**: Check internet connection (fonts load from Google)
- **Check**: Browser console (F12) for CORS errors
- **Fallback**: Fonts will use system defaults

### Changes not saving
- **Solution**: Click **Save & Publish** button (not just preview)
- **Check**: User has admin role
- **Check**: No plugins blocking customizer

### Dark mode not working
- **Solution**: Ensure setting is not "Off"
- **Check**: Browser supports CSS media queries
- **Check**: Manual mode requires JavaScript enabled

### Mobile layout issues
- **Solution**: Check responsive view in browser (F12)
- **Check**: Mobile menu might override header layout
- **Resize**: Browser window to test different breakpoints

---

## Advanced Usage

### CSS Variable Reference
All customizer settings output as CSS variables:

```css
/* Use in custom CSS */
a {
  color: var(--sf-color-primary);
}

h1 {
  font-family: var(--sf-font-headings);
  font-size: var(--sf-font-size-h1);
}

body {
  background: var(--sf-color-bg);
  color: var(--sf-color-text);
}

@media (prefers-color-scheme: dark) {
  /* Dark mode automatically applied */
}
```

### Child Theme Integration
To override customizer defaults in child theme:

```php
// In child theme functions.php
function child_theme_customize_register( $wp_customize ) {
    // Override defaults
    $wp_customize->get_setting( 'starter_flavor_color_primary' )
        ->default = '#0000FF'; // Blue instead of orange
}
add_action( 'customize_register', 'child_theme_customize_register' );
```

### Adding Custom Settings
To add new customizer settings:

```php
// In child theme or custom plugin
function custom_customizer_settings( $wp_customize ) {
    $wp_customize->add_setting( 'my_custom_setting', array(
        'default'           => 'value',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'postMessage',
    ) );
    
    $wp_customize->add_control( 'my_custom_setting', array(
        'label'   => 'My Setting',
        'section' => 'colors', // Add to colors section
        'type'    => 'text',
    ) );
}
add_action( 'customize_register', 'custom_customizer_settings' );
```

---

## Best Practices

### Color Selection
✅ Use complementary colors
✅ Test contrast ratios (WCAG compliance)
✅ Maintain consistency across site
✅ Test in dark mode too
❌ Don't use too many different colors

### Typography
✅ Use 1-2 font families maximum
✅ Pair sans-serif with serif or vice versa
✅ Ensure headings stand out from body
✅ Test readability on mobile
❌ Avoid fonts smaller than 14px for body

### Layout
✅ Test all header layouts on mobile
✅ Check footer columns on different screen sizes
✅ Use grid layout for image-heavy blogs
✅ Use list layout for text-heavy blogs
❌ Don't use too many columns on mobile

### Dark Mode
✅ Test all pages in dark mode
✅ Ensure sufficient contrast
✅ Use lighter shades of primary color
✅ Provide toggle for manual mode
❌ Don't force dark mode on all users

---

## Performance Notes

- **CSS Variables**: No performance impact (native CSS)
- **Live Preview**: Optimized with debouncing
- **Google Fonts**: Only loaded when selected
- **Caching**: May need cache clear after publish
- **Database**: Minimal storage (one option per setting)

---

## Support & Documentation

**Files**:
- `/includes/customizer.php` - Core customizer code
- `/assets/js/customizer-preview.js` - Live preview script
- `/assets/js/customizer.js` - Control enhancements
- `/style.css` - CSS variables and layouts

**Hooks Available**:
```php
// Customize default values
add_filter( 'theme_mod_starter_flavor_color_primary', $value );

// Output custom CSS after customizer variables
add_action( 'wp_head', 'my_custom_css' );

// Customize registered settings
add_action( 'customize_register', 'my_customizer_settings' );
```

**Resources**:
- [WordPress Customizer API](https://developer.wordpress.org/themes/customize-api/)
- [CSS Variables Guide](https://developer.mozilla.org/en-US/docs/Web/CSS/--*)
- [WCAG Contrast Checker](https://webaim.org/resources/contrastchecker/)
