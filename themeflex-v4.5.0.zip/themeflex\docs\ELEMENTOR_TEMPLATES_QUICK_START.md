# Elementor Templates - Quick Start Guide

## Access Templates

**Admin Panel**: Appearance → Elementor Templates

## 15 Pre-Built Templates

### Homepages (3)
- **Corporate** - Professional business template
- **Creative** - Design-focused template
- **Shop** - E-commerce focused template

### Inner Pages (10)
- **About Us** - Team, stats, company story
- **Services** - Service cards & details
- **Contact** - Form, map, contact info
- **Portfolio Grid** - Filterable gallery
- **Portfolio Single** - Project showcase
- **Blog** - Blog listing layout
- **Pricing** - Pricing tiers & features
- **FAQ** - Accordion questions
- **Team** - Team members showcase
- **Coming Soon** - Launch countdown

### Landing Pages (2)
- **SaaS Landing** - Software product landing
- **App Landing** - Mobile app landing

## Import Steps

1. Go to **Appearance → Elementor Templates**
2. Click **Import** on any template
3. Wait for page creation
4. Edit in Elementor (automatic redirect)
5. Customize: text, images, colors, layout
6. Publish when ready

## New Features

### Portfolio System
- Custom "Portfolio" post type
- Category filtering
- Portfolio archive template
- Client & project details metabox

**Location**: WordPress Admin → Portfolio

### Coming Soon / Maintenance
- Enable via **Appearance → Customize → Maintenance Mode**
- Shows to non-logged-in users only
- Customizable countdown, title, description
- Social links integration
- Admin bypass (admins always see site)

### Admin Template Manager
- Browse all 15 templates visually
- Preview before importing
- See template details (category, widgets)
- One-click import to draft page
- Organized by category

## Template Details

| Template | Category | Best For |
|----------|----------|----------|
| Corporate | Homepage | Business/Agency |
| Creative | Homepage | Portfolio/Design |
| Shop | Homepage | E-commerce |
| About Us | Inner | Company info |
| Services | Inner | Service listing |
| Contact | Inner | Contact form |
| Portfolio Grid | Inner | Work showcase |
| Portfolio Single | Inner | Project detail |
| Blog | Inner | Blog home |
| Pricing | Inner | Plans/Pricing |
| FAQ | Inner | FAQ section |
| Team | Inner | Team showcase |
| Coming Soon | Special | Launch/Maintenance |
| SaaS Landing | Landing | Software product |
| App Landing | Landing | Mobile app |

## File Locations

```
/elementor-templates/           Templates JSON files
/templates/                     Page templates (PHP)
  ├── coming-soon.php           Coming soon page
  ├── portfolio.php             Portfolio archive
  ├── contact.php               Contact page
  └── faq.php                   FAQ page
/includes/
  ├── class-elementor-templates.php
  ├── class-portfolio.php       Portfolio CPT
  └── class-maintenance-mode.php
```

## Customizer Settings

### Maintenance Mode
- **Path**: Appearance → Customize → Maintenance Mode
- **Options**:
  - Enable/disable toggle
  - Page title
  - Description
  - Countdown date
  - Background image/color
  - Social media URLs

## Common Tasks

### Change Template Colors
1. Import template
2. Edit in Elementor
3. Select element → Change colors
4. Or use theme CSS variables

### Replace Images
1. Click image in Elementor
2. Upload new image or select from library
3. Adjust size/position as needed

### Add Your Form
1. Replace form placeholder with:
   - Contact Form 7 shortcode
   - MetForm form
   - Or custom form

### Customize Text
1. Click text element
2. Edit content directly in Elementor
3. Format with styling options

## Performance Tips

- Optimize images before upload
- Use lazy loading
- Minimize heavy widgets per page
- Test page speed after customization
- Don't duplicate unnecessary sections

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Templates not showing | Clear cache, reload page |
| Won't import | Check file permissions, update Elementor |
| Customization not working | Disable plugins, test in safe mode |
| Missing widgets | Ensure Starter Flavor widget plugin is active |

## Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Mobile browsers (iOS Safari, Chrome Mobile)

## Required

- **WordPress**: 5.8+
- **Elementor**: 3.0+
- **PHP**: 7.4+
- **Starter Flavor Theme**: 1.0+

## Next Steps

1. Import a template
2. Customize content & images
3. Set up portfolio items (optional)
4. Enable maintenance mode if needed
5. Publish and promote

## Support

- Check documentation in `/documentation/ELEMENTOR_TEMPLATES.md`
- Verify Elementor is active and updated
- Test in default WordPress theme
- Check browser console for errors

---

**Made for Starter Flavor Theme** | Version 1.0.0
