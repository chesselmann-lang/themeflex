# Header/Footer Builder System & Mega Menu Guide

## Übersicht

Das Starter Flavor Theme enthält ein umfassendes System für:

1. **Header/Footer Builder** - Custom Post Type für flexible Header/Footer Templates
2. **Mega Menu** - Erweiterte Navigation mit Multi-Column Layout
3. **Blog Layouts** - Multiple Layout-Optionen für Blog-Archive
4. **Elementor Widgets** - Navigation Menu und Site Logo Widgets

---

## Header/Footer Builder

### Verwendung

1. **Neues Template erstellen:**
   - Gehe zu `Admin → Header/Footer Templates`
   - Klicke auf `Neues Template`
   - Wähle den Typ: Header oder Footer
   - Konfiguriere die Anzeigebedingungen

2. **Template bearbeiten:**
   - Nutze den Elementor Editor um das Template zu designen
   - Die Elementor Canvas wird automatisch geladen

3. **Anzeigebedingungen:**
   - **All Pages:** Template wird auf allen Seiten angezeigt
   - **Specific Pages:** Template nur auf ausgewählten Seiten
   - **404 Page:** Template nur auf 404-Fehlerseiten
   - **Blog Archive:** Template nur auf Blog-Archiv-Seiten
   - **Single Post:** Template nur auf einzelnen Post-Seiten

### Shortcode

Jedes Template generiert automatisch einen Shortcode:
```
[sf_hf_template id="123"]
```

### Funktionen im Code

```php
// Header Template ermitteln (mit Bedingungen)
$header_id = starter_flavor_get_header_template();

// Footer Template ermitteln (mit Bedingungen)
$footer_id = starter_flavor_get_footer_template();

// Render Template
echo do_shortcode( '[sf_hf_template id="' . $header_id . '"]' );
```

### Integration in Template-Dateien

In `header.php`:
```php
<?php
$header_template = starter_flavor_get_header_template();
if ( $header_template ) {
    echo do_shortcode( '[sf_hf_template id="' . $header_template . '"]' );
} else {
    // Fallback zur PHP-Header
    // Original Header-Code hier
}
?>
```

---

## Mega Menu System

### Konfiguration im Admin

1. **Menu Item aktivieren:**
   - Gehe zu `Admin → Menus`
   - Wähle ein Menu aus oder erstelle ein neues
   - Für Menu Items mit Unterseiten können die folgenden Optionen aktiviert werden:
     - **Enable Mega Menu:** Checkbox zum Aktivieren
     - **Columns:** Anzahl der Spalten (2-5)
     - **Background Image URL:** Optional ein Hintergrundbild

2. **Structure:**
   ```
   - Main Item (mit Enable Mega Menu aktivieren)
     ├── Sub Item 1
     ├── Sub Item 2
     ├── Sub Item 3
     └── Sub Item 4
   ```

### Walker verwenden

```php
wp_nav_menu( array(
    'menu'   => 'main-menu',
    'walker' => new Starter_Flavor_Mega_Menu_Walker(),
) );
```

### CSS Klassen

Automatisch angewendet:
- `.sf-nav-menu` - Container
- `.mega-menu-item` - Mega Menu aktiviert
- `.mega-menu-panel` - Mega Menu Dropdown
- `.mega-menu-cols-2` bis `.mega-menu-cols-5` - Spalten-Anzahl
- `.animation-fade` / `.animation-slide-down` / `.animation-scale` - Animationen

### JavaScript Features

- Hover Intent Delay (200ms)
- Touch Device Support
- Keyboard Navigation (Arrow Keys, Enter, Escape)
- Mobile Hamburger Menu
- Accordian auf mobilen Geräten

---

## Elementor Widgets

### Navigation Menu Widget

**Optionen:**
- Select Menu: Wähle ein Menu
- Layout: Horizontal / Vertical
- Enable Mega Menu: An/Aus
- Mobile Breakpoint: Breakpoint für Mobile Menu
- Show Hamburger Icon on Mobile: An/Aus
- Styling: Typography, Colors, Dropdown Styles, Animation

**Verwendung in Elementor:**
1. Öffne ein Elementor Template/Page
2. Ziehe "Navigation Menu" Widget in den Editor
3. Wähle das Menu aus
4. Konfiguriere Layout und Styling

### Site Logo Widget

**Optionen:**
- Logo Source: Site Logo (Customizer) oder Custom Image
- Custom Logo: Upload Custom Logo Image
- Dark Mode Logo: Alternative Logo für Dark Mode
- Link To: Home URL / Custom URL / None
- Size: Width und Max-Width Controls
- Styling: Alignment, Margin, Padding, Border, Border Radius, Box Shadow

**Verwendung in Elementor:**
1. Ziehe "Site Logo" Widget in den Editor
2. Wähle die Logo-Quelle
3. Konfiguriere Größe und Styling

---

## Blog Layouts

### Verfügbare Layouts

1. **Grid** - 3-spaltige responsive Grid
2. **List** - Single Column mit Thumbnail
3. **Masonry** - CSS Columns Layout
4. **Metro** - CSS Grid mit featured Post
5. **Classic** - Traditionelles Blog Layout

### Customizer Konfiguration

1. Gehe zu `Admin → Customize`
2. Bereich: Blog Settings
3. Wähle:
   - **Blog Layout:** Grid, List, Masonry, Metro, Classic
   - **Blog Pagination:** Numeric, Load More, Infinite Scroll

### Verwendung im Template

```php
// Render blog with configured layout and pagination
starter_flavor_render_blog();

// Oder manuell:
Starter_Flavor_Blog_Layouts::render_blog();
```

### Load More Button

Automatisch gerendert bei Pagination Type "Load More Button".
- AJAX basiert
- Lädt nächste Seite beim Klick
- Deaktiviert sich automatisch auf letzter Seite

### Infinite Scroll

Automatisch gerendert bei Pagination Type "Infinite Scroll".
- Nutzt Intersection Observer API
- Lädt automatisch beim Scrollen
- 100px Trigger Margin

### AJAX Request

```javascript
fetch(starterFlavorBlogData.ajaxUrl, {
    method: 'POST',
    body: formData
})
.then(response => response.json())
.then(data => {
    // data.html - HTML der Posts
    // data.max_pages - Maximale Seiten
    // data.has_more_pages - Hat noch mehr Seiten
});
```

### Template Parts

Jedes Layout hat ein entsprechendes Template Part:
- `template-parts/blog/layout-grid.php`
- `template-parts/blog/layout-list.php`
- `template-parts/blog/layout-masonry.php`
- `template-parts/blog/layout-metro.php`
- `template-parts/blog/layout-classic.php`

---

## PHP Funktionen

### Header/Footer Builder

```php
// Header Template ID ermitteln
$header_id = starter_flavor_get_header_template();

// Footer Template ID ermitteln
$footer_id = starter_flavor_get_footer_template();

// Check display conditions
$should_display = starter_flavor_check_display_conditions( $template_id );

// Render via shortcode
echo do_shortcode( '[sf_hf_template id="' . $template_id . '"]' );
```

### Mega Menu

```php
// Walker Instanz
$walker = starter_flavor_get_mega_menu_walker();

// In wp_nav_menu nutzen
wp_nav_menu( array(
    'walker' => $walker,
    'menu'   => 'main-menu',
) );
```

### Blog Layouts

```php
// Render complete blog
starter_flavor_render_blog();

// Get current layout
$layout = Starter_Flavor_Blog_Layouts::get_current_layout();

// Get current pagination type
$pagination = Starter_Flavor_Blog_Layouts::get_current_pagination();

// Get available layouts
$layouts = Starter_Flavor_Blog_Layouts::get_layouts();

// Get pagination types
$pagination_types = Starter_Flavor_Blog_Layouts::get_pagination_types();
```

---

## CSS Klassen & Styling

### Mega Menu CSS

```css
.sf-nav-menu                 /* Container */
.menu-items                  /* Menu List */
.menu-item                   /* Single Item */
.menu-item-has-children      /* Item mit Kindern */
.mega-menu-item              /* Mega Menu aktiviert */
.mega-menu-panel             /* Mega Menu Dropdown */
.mega-menu-inner             /* Inner Wrapper */
.mega-menu-column            /* Spalte */
.mega-menu-item-link         /* Link in Spalte */
.sub-menu                    /* Submenu */
.sf-hamburger                /* Hamburger Icon */
.mobile-open                 /* Mobile Menu offen */
.menu-open                   /* Item offen */
```

### Blog Layout CSS

```css
.blog-container              /* Container */
.blog-posts                  /* Posts Grid/List */
.blog-post                   /* Single Post */
.blog-layout-grid            /* Grid Layout */
.blog-layout-list            /* List Layout */
.blog-layout-masonry         /* Masonry Layout */
.blog-layout-metro           /* Metro Layout */
.blog-layout-classic         /* Classic Layout */
.pagination                  /* Pagination */
.numeric-pagination          /* Numeric Pagination */
.load-more-pagination        /* Load More */
.infinite-scroll             /* Infinite Scroll */
```

---

## Responsive Verhalten

### Mobile (≤768px)

- Mega Menu wird zu Accordion
- Hamburger Icon wird angezeigt
- Menu wird über Sidebar angezeigt
- Blog Layout wird zu Single Column
- Touch-freundliche Interaktionen

### Desktop (>768px)

- Full Mega Menu mit Hover
- Keyboard Navigation
- Multi-Column Layouts
- Optimale Performance

---

## Hooks & Filter

### Header/Footer Builder

```php
// Customize display conditions
apply_filters( 'starter_flavor_check_display_conditions', $template_id );

// Customize HF template content
apply_filters( 'starter_flavor_hf_template_content', $content, $template_id );
```

### Mega Menu

```php
// Customize walker
apply_filters( 'starter_flavor_mega_menu_walker', $walker );

// Customize menu output
apply_filters( 'nav_menu_item_class', $class_names, $item, $args, $depth );
```

### Blog Layouts

```php
// Customize query args for load more
apply_filters( 'starter_flavor_load_more_query_args', $query_args );

// Trigger custom event
addEventListener( 'starterFlavorPostsAppended', function( event ) {
    console.log( event.detail.posts, event.detail.layout );
});
```

---

## Performance Tipps

1. **Caching:** Nutze WP Super Cache oder ähnliche Plugins
2. **Lazy Loading:** Bilder werden automatisch lazy loaded
3. **Pagination:** Nutze "Load More" statt "Numeric" für bessere Performance
4. **Menu:** Limitiere die Anzahl der Menu Items
5. **Elementor:** Nutze Elementor Pro Cache/Minify Features

---

## Browser Unterstützung

- Chrome/Edge: Vollständig unterstützt
- Firefox: Vollständig unterstützt
- Safari: Vollständig unterstützt
- IE 11: Nicht unterstützt (Grid Layout)
- Mobile Browser: iOS Safari 12+, Chrome Mobile

---

## Debugging

### JavaScript Console

```javascript
// Blog Layouts Instanz
const blog = new StarterFlavorBlogLayouts();

// Mega Menu Instanz
const menu = new StarterFlavorMegaMenu();
```

### PHP Debugging

```php
// Check if header template exists
error_log( 'Header ID: ' . starter_flavor_get_header_template() );

// Check conditions
error_log( print_r( get_post_meta( $id, 'sf_hf_display_conditions', true ), true ) );
```

### CSS Debugging

Inspect Element und überprüfen Sie:
- `.sf-nav-menu` Klassen
- `.blog-layout-*` Klassen
- Grid/Column Berechnungen
- Responsive Breakpoints

---

## Support & Customization

Für erweiterte Customizations, nutzen Sie die verfügbaren Hooks und Filter.
Alle Klassen sind auf einfache Erweiterung ausgelegt.

**Custom Walker Beispiel:**

```php
class My_Custom_Mega_Menu_Walker extends Starter_Flavor_Mega_Menu_Walker {
    public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
        // Custom Logic
        parent::start_el( $output, $item, $depth, $args, $id );
    }
}
```

---

## Datei-Übersicht

```
includes/
├── class-header-footer-builder.php    # Header/Footer System
├── class-mega-menu.php                # Mega Menu Walker
├── class-blog-layouts.php             # Blog Layouts System
└── elementor-widgets/
    ├── nav-menu.php                   # Navigation Menu Widget
    └── site-logo.php                  # Site Logo Widget

assets/
├── css/
│   ├── mega-menu.css                  # Mega Menu Styling
│   └── blog-layouts.css               # Blog Layouts Styling
└── js/
    ├── mega-menu.js                   # Mega Menu JavaScript
    └── blog-layouts.js                # Blog Layouts AJAX

template-parts/blog/
├── layout-grid.php
├── layout-list.php
├── layout-masonry.php
├── layout-metro.php
└── layout-classic.php
```

---

**Version:** 1.0.0  
**Kompatibilität:** WordPress 5.9+, Elementor 3.0+  
**Lizenz:** GPL v2 oder höher
