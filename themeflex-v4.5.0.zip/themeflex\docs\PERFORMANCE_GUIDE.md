# Starter Flavor Performance Guide

## Overview

The Starter Flavor theme includes comprehensive performance optimizations designed to achieve excellent Lighthouse scores while maintaining flexibility and ease of use. This guide documents built-in features, server recommendations, and optimization strategies.

---

## Built-in Performance Features

### Critical CSS Optimization
- **Location:** `includes/class-performance-pro.php` / `includes/performance.php`
- **Feature:** Inline critical CSS in page `<head>` to improve First Contentful Paint (FCP)
- **Implementation:** Reads from `assets/css/critical-inline.css` and outputs minimal styles above-the-fold
- **Benefit:** Reduces render-blocking CSS, enables parallel stylesheet loading with `media="print" onload`

### Script Optimization
- **Defer/Async Attributes:** Non-critical scripts automatically deferred to improve page load
- **jQuery Migrate Removal:** Optional removal via Performance Pro admin panel
- **Emoji Scripts Removal:** Disables WordPress emoji detection scripts
- **Block Library Cleanup:** Removes Gutenberg CSS on non-block pages
- **Location:** `includes/performance.php`

### Image Optimization
- **Lazy Loading:** Native `loading="lazy"` and `decoding="async"` attributes
- **Responsive Images:** Automatic width/height attributes prevent Cumulative Layout Shift (CLS)
- **Image Dimensions:** Added to all images to reserve space and prevent layout shift
- **Fetchpriority:** First image marked as `fetchpriority="high"` for LCP optimization
- **WebP Detection:** Server-side WebP support detection via JavaScript variable

### Resource Hints
- **Preconnect:** Font CDN connections preloaded
- **DNS Prefetch:** Common CDNs pre-resolved (Cloudflare, jQuery CDN)
- **Preload:** Critical stylesheets preloaded in `<head>`
- **Location:** `includes/performance.php`

### Asset Loading Strategy
- **Conditional Loading:** Elementor widget CSS/JS only loaded when widgets are used on page
- **Asset Lazy Loading:** Non-critical stylesheets deferred with `media="print" onload`
- **Font Preloading:** Optional font preloading for custom fonts
- **Location:** `includes/class-asset-loader.php`

### Cache Headers
- **Browser Cache:** 1 hour cache for homepage, 24 hours for other pages
- **Static Assets:** 30-day cache for media files (images, fonts, CSS, JS)
- **ETag Support:** Automatic cache validation via ETags
- **Static Asset Extensions:** .jpg, .jpeg, .png, .gif, .ico, .css, .js, .woff, .woff2, .ttf, .svg, .eot
- **Location:** `includes/performance.php` / `includes/class-performance-pro.php`

### Content Security Policy
- **Optional CSP Headers:** Configurable via `starter_flavor_enable_csp` filter
- **Whitelist Management:** Allows safe third-party scripts (Google Analytics, fonts)
- **Location:** `includes/performance.php`

### Performance Admin Dashboard
- **Location:** Appearance > Performance Pro
- **Features:**
  - Visual performance score (0-100)
  - Toggleable optimization settings
  - Real-time status monitoring
  - Resource file size estimates
  - Optimization recommendations
- **Dashboard Widget:** Quick status on WordPress dashboard

---

## Expected Lighthouse Scores

With all optimizations enabled and proper server configuration:

| Metric | Expected Score | Notes |
|--------|----------------|-------|
| **Performance** | 85-95 | Depends on image optimization & server speed |
| **Accessibility** | 90-98 | Excellent ARIA labels and semantic HTML |
| **Best Practices** | 90-98 | No deprecated APIs, security headers |
| **SEO** | 95-100 | Mobile-friendly, proper structured data |
| **Core Web Vitals** | | |
| - LCP (Largest Contentful Paint) | <2.0s | Hero image optimization, critical CSS |
| - FID (First Input Delay) | <100ms | Deferred non-critical JavaScript |
| - CLS (Cumulative Layout Shift) | <0.1 | Image dimensions, font-display: swap |

**Factors that improve scores:**
- Fast hosting (sub-100ms response time)
- CDN for static assets
- Image optimization (WebP, proper sizing)
- Gzip/Brotli compression
- Database optimization
- Minimal plugin bloat

---

## Server Configuration Recommendations

### PHP Opcache (Critical)
Enable PHP Opcache to cache compiled PHP bytecode:

```ini
; /etc/php/8.1/fpm/conf.d/10-opcache.ini (or similar)
[opcache]
opcache.enable=1
opcache.memory_consumption=256
opcache.interned_strings_buffer=16
opcache.max_accelerated_files=10000
opcache.validate_timestamps=1
opcache.revalidate_freq=60
opcache.fast_shutdown=1
```

**Impact:** 2-5x PHP execution speedup

### Object/Query Caching (Recommended)
Use Redis or Memcached for database query caching:

```php
// wp-config.php
define( 'WP_CACHE', true );
define( 'WP_REDIS_HOST', 'localhost' );
define( 'WP_REDIS_PORT', 6379 );
define( 'WP_REDIS_PASSWORD', '' );
define( 'WP_REDIS_DB', 0 );
define( 'WP_REDIS_TIMEOUT', 1 );
```

**Plugins:** Redis Object Cache, W3 Total Cache, WP Super Cache

**Impact:** 5-10x reduction in database queries

### Gzip/Brotli Compression (Critical)
Compress all text-based assets:

```apache
# .htaccess
<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/plain
  AddOutputFilterByType DEFLATE text/html
  AddOutputFilterByType DEFLATE text/xml
  AddOutputFilterByType DEFLATE text/css
  AddOutputFilterByType DEFLATE text/javascript
  AddOutputFilterByType DEFLATE application/xml
  AddOutputFilterByType DEFLATE application/xhtml+xml
  AddOutputFilterByType DEFLATE application/rss+xml
  AddOutputFilterByType DEFLATE application/javascript
  AddOutputFilterByType DEFLATE application/x-javascript
</IfModule>
```

**Impact:** 60-80% reduction in CSS/JS/HTML file sizes

### CDN Configuration (Recommended)
Serve static assets from a Content Delivery Network:

- **Cloudflare, Bunny CDN, Fastly** - Popular options
- **Cache Rules:** Cache CSS, JS, images, fonts for 1 month
- **Minification:** Enable automatic CSS/JS minification
- **HTTP/2 Push:** Enable for critical assets

**Impact:** 30-50% reduction in page load time globally

### Database Optimization (Recommended)
Clean up database bloat:

```sql
-- Remove post revisions
DELETE FROM wp_posts WHERE post_type = 'revision';

-- Remove auto-drafts
DELETE FROM wp_posts WHERE post_type = 'auto-draft' AND post_status = 'auto-draft';

-- Optimize tables
OPTIMIZE TABLE wp_posts;
OPTIMIZE TABLE wp_postmeta;
```

**Plugins:** Cleaner, WP-Optimize, Advanced Database Cleaner

---

## Image Optimization Recommendations

### Formats
- **Use WebP:** Modern browsers, 25-35% smaller than JPEG
- **Use AVIF:** Newer format, 20% smaller than WebP (limited support)
- **Fallback to JPEG:** Older browsers
- **PNG for Graphics:** Transparency needed
- **SVG for Icons:** Scalable, smallest file size

### Sizing
- **Hero Images:** 1200-1600px width (2x display for retina)
- **Product Images:** 500-700px width
- **Thumbnails:** 150-250px width
- **Responsive Srcsets:** Generate 2-3 sizes for each image

### Tools
- **TinyPNG/Squoosh:** Lossless compression
- **ImageMagick/VIPS:** Batch server-side optimization
- **Plugins:** Smush, Optimole, ShortPixel
- **Services:** ImageKit, Cloudinary, Imgix (CDNs with optimization)

### Lazy Loading
- **Native Loading:** `loading="lazy"` attribute (all modern browsers)
- **JavaScript Fallback:** For older browsers (included in theme)
- **LCP Image:** First above-fold image uses `fetchpriority="high"`

---

## Font Loading Strategy

### Optimization Approach
The theme implements `font-display: swap` to prevent invisible text:

```css
@font-face {
  font-family: 'Custom Font';
  src: url('/fonts/custom.woff2') format('woff2');
  font-display: swap; /* Show fallback immediately */
  font-weight: 400;
  font-style: normal;
}
```

### Recommendations
1. **Limit Font Families:** 1-2 families maximum
2. **Limit Font Weights:** Use only 400 (regular) and 700 (bold)
3. **Subset Fonts:** Load only characters used (Latin, etc.)
4. **Preload in Critical CSS:** Add `<link rel="preload">` for primary font
5. **System Fonts:** Use system font stack as fallback

### Font Strategy
- **Primary Font:** Load via preconnect + font-display: swap
- **Secondary Fonts:** Load on-demand or defer
- **Google Fonts:** Use `font-display=swap` parameter: `?display=swap`

---

## Core Web Vitals Optimization

### Largest Contentful Paint (LCP) - Target: <2.5s

**Optimization tactics:**
1. Optimize server response time (TTFB)
2. Minify CSS/JS
3. Remove render-blocking resources
4. Lazy load images below fold
5. Mark LCP image with `fetchpriority="high"`
6. Preload critical resources
7. Use CDN for static assets

**Starter Flavor implementation:**
- Critical CSS inlined in `<head>`
- Non-critical CSS deferred
- LCP image detection and optimization
- Resource hints for preconnect/DNS prefetch

### First Input Delay (FID) / Interaction to Next Paint (INP) - Target: <100ms

**Optimization tactics:**
1. Defer non-critical JavaScript
2. Break up long JavaScript tasks
3. Use Web Workers for heavy computations
4. Minimize JavaScript bundle size
5. Remove unused dependencies

**Starter Flavor implementation:**
- Script deferring via `defer` attribute
- jQuery Migrate optional removal
- Emoji scripts optional removal
- Block library CSS removal

### Cumulative Layout Shift (CLS) - Target: <0.1

**Optimization tactics:**
1. Reserve space for images with width/height
2. Reserve space for ads/embeds
3. Use `font-display: swap` for fonts
4. Avoid inserting content above existing
5. Use transform/opacity for animations

**Starter Flavor implementation:**
- Automatic width/height on images
- Font preloading with swap strategy
- Responsive image sizing
- Avoid late-loaded ads

---

## Caching Strategy

### Page Caching
- **Plugin:** WP Super Cache, W3 Total Cache, LiteSpeed Cache
- **Cache Duration:** 1-12 hours (depends on content freshness)
- **Invalidation:** Automatic on post updates

### Browser Caching
- **Static Assets:** 30 days (CSS, JS, images, fonts)
- **HTML Pages:** 1 hour (homepage), 24 hours (other pages)
- **Dynamic Content:** No cache (API responses, etc.)

### Database Query Caching
- **Object Cache:** Redis/Memcached for common queries
- **TTL:** 1-24 hours depending on data freshness
- **Invalidation:** Automatic on data changes

### CDN Caching
- **CSS/JS:** Cache indefinitely (use cache-busting via version numbers)
- **Images:** Cache indefinitely
- **HTML:** Cache 1 hour (check for updates frequently)

---

## Font Loading Performance

### Best Practice
Implement `font-display: swap` to prevent invisible text (FOUT):

```css
@font-face {
  font-family: 'Montserrat';
  src: url('/fonts/montserrat-400.woff2') format('woff2');
  font-display: swap; /* Swap immediately */
  font-weight: 400;
}
```

### Timeline
1. **0-100ms:** Show fallback font
2. **100-3000ms:** Load custom font
3. **3000ms+:** Show custom font when available

### Preload Critical Font
```html
<link rel="preload" as="font" href="/fonts/primary.woff2" crossorigin>
```

---

## Performance Monitoring

### Built-in Monitoring
- **Admin Dashboard Widget:** Quick performance metrics
- **Performance Pro Panel:** Detailed settings and statistics
- **Performance Metrics Function:** `starter_flavor_get_performance_metrics()`

### External Tools
- **Google PageSpeed Insights:** Public URL analysis
- **WebPageTest:** Detailed waterfall charts
- **GTmetrix:** Trend tracking over time
- **Lighthouse CI:** Continuous integration monitoring
- **Web Vitals JavaScript Library:** Real User Monitoring

### Key Metrics to Track
```javascript
// Performance API
const navigation = performance.getEntriesByType('navigation')[0];
console.log('TTFB:', navigation.responseStart);
console.log('DCP:', navigation.domContentLoadedEventEnd);
console.log('LCP:', /* via PerformanceObserver */);
```

---

## Troubleshooting Performance Issues

### High TTFB (Time to First Byte)
- Check PHP execution time: `max_execution_time`
- Enable database query caching
- Upgrade hosting/server resources
- Check for poorly optimized plugins

### Slow CSS Rendering
- Reduce CSS file size via minification
- Remove unused CSS (PurgeCSS)
- Use critical CSS inlining (enabled)
- Enable Gzip compression

### Large JavaScript
- Remove unused plugins
- Code splitting for heavy scripts
- Tree shaking via build tools
- Lazy load third-party scripts (Google Analytics, ads)

### Poor Image Performance
- Compress images (WebP, JPEG optimization)
- Use responsive images (srcset)
- Implement lazy loading (enabled)
- Use CDN for media

### High CLS
- Set image width/height attributes (enabled)
- Use font-display: swap (enabled)
- Avoid inserting DOM elements above fold
- Use transform instead of width/height animations

---

## Performance Optimization Checklist

- [ ] Enable PHP Opcache on server
- [ ] Set up Redis/Memcached object cache
- [ ] Enable Gzip/Brotli compression
- [ ] Configure CDN for static assets
- [ ] Optimize all images (WebP + JPEG)
- [ ] Limit custom fonts (1-2 families max)
- [ ] Enable all Performance Pro optimizations
- [ ] Run Lighthouse audit and verify scores
- [ ] Set up performance monitoring/alerts
- [ ] Test on real devices (mobile)
- [ ] Monitor Core Web Vitals
- [ ] Clean up database (remove revisions)
- [ ] Audit and remove unnecessary plugins
- [ ] Configure cache headers (.htaccess)
- [ ] Test with PageSpeed Insights

---

## Additional Resources

- [Google PageSpeed Insights](https://pagespeed.web.dev/)
- [Web.dev Core Web Vitals Guide](https://web.dev/vitals/)
- [WordPress Performance Guidelines](https://developer.wordpress.org/plugins/performance/)
- [MDN Web Performance](https://developer.mozilla.org/en-US/docs/Web/Performance)
- [Core Web Vitals Report](https://support.google.com/webmasters/answer/9205520)

