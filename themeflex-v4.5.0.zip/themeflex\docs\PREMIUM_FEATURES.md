# Starter Flavor Premium Features

Two enterprise-grade features have been added to the Starter Flavor WordPress theme, bringing it to par with premium ThemeForest themes like Avada.

## 1. Starter Studio - Prebuilt Section Library

A comprehensive library of 30 pre-designed, professional content sections that users can insert directly into Elementor pages with a single click.

### Location & Files

```
includes/class-starter-studio.php          (420 lines) - Main class
assets/css/starter-studio.css              (480 lines) - Admin styling
assets/js/starter-studio.js                (320 lines) - Admin interactions
starter-studio/                            - JSON section library (30 files)
```

### Features

- **Admin Page**: Access via WordPress Dashboard → Starter Flavor → Starter Studio
- **30 Pre-Designed Sections** organized in 9 categories:
  - **Hero Sections** (5): Split, Video Background, Slider, Minimal, Parallax
  - **Content Sections** (5): About, Timeline, Features Grid, Statistics, CTA Banner
  - **Team Sections** (3): Grid 4-up, Carousel, Creative Staggered
  - **Testimonial Sections** (3): Cards, Slider, Masonry
  - **Pricing Sections** (3): Simple, Monthly/Yearly Toggle, Comparison Table
  - **Portfolio Sections** (3): Grid, Carousel, Featured Showcase
  - **Blog Sections** (3): 3-Column Grid, Featured, Carousel
  - **Contact Sections** (3): Split Form/Map, Centered, Minimal
  - **Footer Sections** (2): 4-Column, Minimal

- **Visual Library Interface**:
  - Category filter tabs
  - Thumbnail previews with hover effects
  - Preview modal
  - Copy JSON to clipboard functionality

- **Elementor Integration**:
  - Custom editor panel in Elementor
  - Drag-and-drop ready sections
  - One-click insertion

### Usage

#### Admin Page

1. Navigate to **Starter Flavor → Starter Studio**
2. Browse sections by category using filter tabs
3. Click **Preview** to see section details
4. Click **Copy JSON** to get section data
5. Paste into Elementor or use directly

#### Elementor Editor

1. Open page in Elementor
2. Look for "Starter Studio" panel (when available)
3. Browse and drag sections into your layout
4. Customize with Elementor's controls

### Section Structure

Each section JSON includes:

```json
{
  "id": "section-slug",
  "title": "Section Name",
  "category": "Category Name",
  "description": "What this section does",
  "thumbnail": "URL to 400x300 preview",
  "preview_image": "URL to 1200x600 preview",
  "section": {
    "id": "elementor_section_id",
    "elType": "section",
    "settings": { /* Elementor section settings */ },
    "elements": [ /* Columns and widgets */ ]
  }
}
```

### API & AJAX Endpoints

```
GET /wp-admin/admin-ajax.php?action=sf_get_sections
  → Returns all sections grouped by category

POST /wp-admin/admin-ajax.php?action=sf_get_section_preview
  → Parameters: section_id (string)
  → Returns: Full section data with preview HTML
```

### Customization

To add new sections:

1. Create new JSON file in `starter-studio/` directory
2. Follow the structure of existing sections
3. Sections automatically appear in the library
4. File naming: `category-name.json`

---

## 2. WooCommerce Builder

A complete system for creating custom WooCommerce page layouts using Elementor, similar to Avada's WooCommerce Builder.

### Location & Files

```
includes/class-woo-builder.php             (350 lines) - Main class
assets/css/woo-builder.css                 (480 lines) - Admin styling
assets/css/woo-builder-frontend.css        (50 lines)  - Frontend styling
assets/js/woo-builder.js                   (200 lines) - Admin interactions
templates/woo-elementor-template.php       - Template renderer
includes/elementor-widgets/product-grid.php (400 lines) - Product grid widget
includes/elementor-widgets/product-categories.php (350 lines) - Categories widget
```

### Features

- **Custom Post Type**: `sf_woo_template` for WooCommerce layouts
- **Template Types** (6 supported):
  - Shop Page (archive-product)
  - Single Product
  - Cart Page
  - Checkout Page
  - My Account
  - Order Received (Thank You)

- **Admin Interface**:
  - Access via WordPress Dashboard → Starter Flavor → WooCommerce Builder
  - Visual grid of template types
  - Status indicators (Active/Inactive)
  - Quick edit/create buttons

- **Conditional Activation**:
  - Enable/disable custom templates per type
  - Global override of default WooCommerce pages
  - Fallback to WooCommerce defaults if custom template inactive

- **Elementor Integration**:
  - Build templates with full Elementor editor
  - All Elementor widgets available
  - Full page builder experience

### WooCommerce Elementor Widgets

#### 1. Product Grid Widget

**Location**: `includes/elementor-widgets/product-grid.php`

Features:
- Query Types: Latest, Featured, Sale, Best Selling, Top Rated, By Category
- Customizable Columns (2-6)
- Products Per Page control
- Sorting Options: Date, Title, Price, Popularity, Rating, Random
- Display Options:
  - Show/Hide Title
  - Show/Hide Price
  - Show/Hide Rating
  - Show/Hide Add to Cart
  - Show/Hide Sale Badge
- Card Styles: Classic, Minimal, Overlay, Featured
- Hover Effects: None, Zoom, Fade, Slide, Lift
- Fully Responsive
- WooCommerce-native integration

#### 2. Product Categories Widget

**Location**: `includes/elementor-widgets/product-categories.php`

Features:
- Select specific categories or show all
- Hide empty categories option
- Customizable Columns (2-4)
- Sorting Options: Name, Product Count, ID
- Display Options:
  - Show/Hide Product Count
  - Show/Hide Description
  - Show/Hide Category Image
- Card Styles: Default, Overlay, Minimal, Featured
- Hover Effects: None, Zoom, Fade, Slide
- Custom height for category images
- WooCommerce-native integration

### Usage

#### Creating a Custom Shop Page

1. Navigate to **Starter Flavor → WooCommerce Builder**
2. Click **Create** under "Shop Page"
3. Elementor editor opens for `sf_woo_template`
4. Select "Product Grid" widget from WooCommerce category
5. Configure:
   - Query type (Featured, Sale, etc.)
   - Number of columns
   - Display options
6. Customize styling via Elementor panels
7. Save and publish
8. Return to WooCommerce Builder
9. Click **Activate** to enable custom template

#### Creating a Custom Single Product Page

1. Navigate to **Starter Flavor → WooCommerce Builder**
2. Click **Create** under "Single Product"
3. Build layout with:
   - Product image gallery
   - Product title/description
   - Price, variations, add-to-cart
   - Product tabs (description, reviews)
   - Related products
4. Use standard WooCommerce widgets or Product Grid
5. Save, publish, and activate

#### Creating Custom Checkout

1. Navigate to **Starter Flavor → WooCommerce Builder**
2. Click **Create** under "Checkout Page"
3. Add WooCommerce checkout form
4. Customize appearance with Elementor
5. Save and activate

### Conditional Template Logic

The system uses meta fields to control template application:

```php
// Get template for page type
$template = Starter_Flavor_Woo_Builder::get_template_by_type( 'shop' );

// Check if active
$is_active = get_post_meta( $template->ID, 'woo_template_active', true );

// If active, override default WooCommerce template
// If inactive, use WooCommerce default
```

### API & AJAX Endpoints

```
POST /wp-admin/admin-ajax.php?action=sf_get_woo_templates
  → Returns all WooCommerce templates with status

POST /wp-admin/admin-ajax.php?action=sf_toggle_template
  → Parameters: template_id (int), active (bool)
  → Toggles template active status
```

### Hooks & Filters

```php
// Hook when template is rendered
apply_filters( 'starter_flavor_woo_template_rendered', $template_id )

// Override template detection
apply_filters( 'starter_flavor_woo_template_type', $type )
```

### Fallback Behavior

If WooCommerce Builder template is not active or available:
1. System checks for custom template
2. If not found or inactive, uses default WooCommerce template
3. Default WooCommerce functionality remains intact
4. No conflicts with standard WooCommerce

---

## Technical Details

### WordPress Standards

- ✓ Proper text domain: `starter-flavor`
- ✓ Escaping & sanitization on all outputs
- ✓ Nonce verification on AJAX calls
- ✓ Capability checking (manage_options)
- ✓ Custom post type registration
- ✓ Meta field registration
- ✓ Proper action/filter hooks

### Performance

- Lazy loading for section previews
- CSS/JS only enqueued on relevant pages
- JSON parsing optimized
- Placeholder images used for previews
- No external dependencies (vanilla JS)

### Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- IE11: Not supported (modern JS syntax)

### WooCommerce Compatibility

- Works with WooCommerce 6.0+
- Elementor 3.0+ required
- All WooCommerce hooks honored
- Backward compatible with existing WooCommerce pages

---

## File Structure Summary

```
starter-flavor/
├── includes/
│   ├── class-starter-studio.php
│   ├── class-woo-builder.php
│   └── elementor-widgets/
│       ├── product-grid.php
│       └── product-categories.php
├── starter-studio/
│   ├── hero-split.json
│   ├── hero-video.json
│   ├── hero-slider.json
│   ├── hero-minimal.json
│   ├── hero-parallax.json
│   ├── content-about.json
│   ├── content-timeline.json
│   ├── content-features-grid.json
│   ├── content-stats.json
│   ├── content-cta-banner.json
│   ├── team-grid-4.json
│   ├── team-carousel.json
│   ├── team-creative.json
│   ├── testimonial-cards.json
│   ├── testimonial-slider.json
│   ├── testimonial-masonry.json
│   ├── pricing-simple.json
│   ├── pricing-toggle.json
│   ├── pricing-comparison.json
│   ├── portfolio-grid.json
│   ├── portfolio-carousel.json
│   ├── portfolio-showcase.json
│   ├── blog-grid-3.json
│   ├── blog-featured.json
│   ├── blog-carousel.json
│   ├── contact-split.json
│   ├── contact-centered.json
│   ├── contact-minimal.json
│   ├── footer-4col.json
│   └── footer-minimal.json
├── assets/
│   ├── css/
│   │   ├── starter-studio.css
│   │   ├── woo-builder.css
│   │   └── woo-builder-frontend.css
│   └── js/
│       ├── starter-studio.js
│       └── woo-builder.js
├── templates/
│   └── woo-elementor-template.php
└── functions.php (updated with init calls)
```

---

## Getting Started

### For Users

1. **Starter Studio**:
   - Go to Dashboard → Starter Flavor → Starter Studio
   - Browse 30 pre-designed sections
   - Preview and copy sections into your pages
   - Edit with Elementor's full capabilities

2. **WooCommerce Builder**:
   - Go to Dashboard → Starter Flavor → WooCommerce Builder
   - Create custom templates for shop, products, cart, etc.
   - Use Elementor to design layouts
   - Activate to override defaults

### For Developers

1. Add new sections to `starter-studio/` directory
2. Create custom widgets extending `Elementor\Widget_Base`
3. Use hooks: `starter_flavor_woo_template_rendered`
4. Extend with custom filtering/conditional logic

---

## Future Enhancement Ideas

- Section preview thumbnails as actual images
- Drag-and-drop section reordering
- Custom section creation via UI
- Template library sharing/import
- Section versioning
- A/B testing for sections
- Dynamic content population
- Multi-language section descriptions
