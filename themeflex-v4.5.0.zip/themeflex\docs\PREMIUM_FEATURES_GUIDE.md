# Premium Features Guide

## Overview

This guide covers three major premium features added to the Starter Flavor theme to compete with Avada, Divi, and Astra.

---

## FEATURE 1: Popup Builder

A full-featured popup/modal system with advanced triggers, display rules, and animations — like Avada and Divi.

### Location
- **Class**: `/includes/class-popup-builder.php`
- **Frontend CSS**: `/assets/css/popup-builder.css`
- **Frontend JS**: `/assets/js/popup-builder.js`
- **Admin CSS**: `/assets/css/popup-builder-admin.css`
- **Admin JS**: `/assets/js/popup-builder-admin.js`

### Custom Post Type
- **Type**: `sf_popup`
- **Features**: Full Elementor support, editor integration
- **Admin Menu**: Theme → Popups

### Trigger Types

#### 1. On Page Load
- Popup displays immediately when page loads
- Optional delay before showing

#### 2. Exit Intent
- Detects when user moves mouse toward top of page
- Common for lead capture and promotional offers

#### 3. Scroll Depth (%)
- Shows popup when user scrolls to specified percentage
- Range: 1-100%
- Example: Show at 50% scroll depth

#### 4. Time Delay (seconds)
- Popup appears after specified seconds on page
- Decimal values supported (e.g., 2.5 seconds)

#### 5. Click Element (CSS Selector)
- Popup triggered by clicking element matching CSS selector
- Examples: `.button`, `#cta-btn`, `.product-link`

#### 6. Manual (JS API)
- No automatic trigger
- Controlled via JavaScript API: `sfPopup.open(id)`

### Display Rules

#### 1. All Pages
- Shows popup on every page/post on site

#### 2. Specific Pages/Posts
- Multi-select pages and posts
- Only displays on selected items

#### 3. Specific Categories
- Target blog categories
- Multi-select support

#### 4. WooCommerce Pages
- Shop page
- Product pages
- Cart page
- Checkout page
- Account page

#### 5. 404 Page
- Separate checkbox to show on 404 pages

### Display Frequency

#### Every Visit
- Shows popup every time user visits page

#### Once Per Session
- Shows once per browser session
- Uses sessionStorage

#### Once Per Day
- Shows maximum once per calendar day
- Uses localStorage

#### Once Ever
- Shows only one time (permanent)
- Uses localStorage for persistence

### Layouts

#### 1. Modal with Overlay
- Centered popup with semi-transparent overlay
- Click overlay to close (optional)
- Most common layout

#### 2. Slide-in Panel
- Slides in from left or right
- Full height on mobile
- Great for forms

#### 3. Notification Bar
- Full-width bar at top or bottom
- Fixed position
- Perfect for announcements

#### 4. Floating Box
- Corner-positioned box
- Smaller size
- Non-intrusive

### Positions

**Modal**: center, top, bottom, left, right, corners, fullscreen

**Slide Panel**: left, right (edges automatically)

**Notification**: top, bottom

**Floating**: corners + center

### Animations

1. **Fade** - Smooth opacity transition
2. **Slide Up** - Slides upward into view
3. **Slide Down** - Slides downward into view
4. **Slide Left** - Slides from right to left
5. **Slide Right** - Slides from left to right
6. **Zoom** - Scales from small to full size
7. **Flip** - 3D flip rotation

### Sizes

- **Small**: 400px
- **Medium**: 600px (default)
- **Large**: 800px
- **Fullscreen**: 100% width/height
- **Custom**: Set any width in pixels

### Advanced Settings

#### Overlay Customization
- **Color**: Any hex color
- **Opacity**: 0 (transparent) to 1 (opaque)
- **Blur**: 0-20px backdrop blur effect
- **Click to Close**: Allow closing by clicking overlay

#### Close Button
- **Position**: Inside or outside popup
- **Delay**: Seconds before close button appears
- **Hide on Mobile**: Don't show on small screens

#### Other Settings
- **Priority**: Higher number = higher priority (1-100)
- **Hide on Mobile**: Disable popup on screens < 768px

### JavaScript API

```javascript
// Open popup by ID
sfPopup.open(popupId);

// Close popup
sfPopup.close(popupId);

// Toggle popup
sfPopup.toggle(popupId);

// Check if should show (respects frequency)
sfPopup.shouldShow(popupId, frequency);
```

### HTML Attributes

Each popup includes data attributes for integration:

```html
<div class="sf-popup-wrapper" 
     data-popup-id="123"
     data-popup-config='{"trigger_type":"on_load",...}'>
```

### CSS Classes

- `.sf-popup-wrapper` - Main wrapper
- `.sf-popup-overlay` - Background overlay
- `.sf-popup-content` - Content container
- `.sf-popup-close` - Close button
- `.sf-popup-position-[type]` - Position variant
- `.sf-popup-layout-[type]` - Layout variant
- `.sf-popup-animation-[type]` - Animation variant
- `.sf-popup-[size]` - Size variant

### Mobile Optimization

- Responsive design adapts to smaller screens
- Slide panels become full-width on mobile
- Notification bars stack properly
- Touch-friendly close button
- Respects viewport constraints

### Accessibility

- ARIA labels on close button
- Focus trap to keep focus in popup
- ESC key closes popup
- Keyboard navigation support
- Semantic HTML structure

### Performance

- Vanilla JavaScript (no dependencies)
- Lazy loading of popup content
- Efficient event delegation
- Cookie/localStorage for frequency control
- Minimal CSS/JS footprint

### Example: Lead Capture Popup

```
Title: "Get 20% Off"
Trigger: Exit Intent
Display: All Pages
Frequency: Once Per Day
Layout: Modal with Overlay
Position: Center
Animation: Fade
Size: Medium (600px)
Close Button: Inside, shows after 2 seconds
```

---

## FEATURE 2: Dynamic Content System

ACF/Meta Box integration with dynamic tags for Elementor — like Elementor Pro's dynamic tags but built into the theme.

### Location
- **Class**: `/includes/class-dynamic-content.php`

### Dynamic Tags Available

#### Post Tags
- `post_title` - Page/post title
- `post_excerpt` - Post excerpt
- `post_content` - Full post content
- `post_date` - Publication date
- `post_author` - Author name
- `post_featured_image` - Featured image URL
- `post_url` - Permalink
- `post_terms` - Comma-separated categories
- `post_meta_[field]` - Any custom meta field

#### Site Tags
- `site_title` - Site name/blog title
- `site_tagline` - Site tagline
- `site_url` - Site URL
- `site_logo` - Logo image URL
- `current_year` - Current year (2026)
- `current_date` - Today's date

#### Author Tags
- `author_name` - Post author name
- `author_bio` - Author biography
- `author_avatar` - Avatar image URL
- `author_url` - Author profile URL
- `author_meta_[field]` - Any author custom field

#### WooCommerce Tags (if installed)
- `product_price` - Product price (HTML or text)
- `product_sale_price` - Sale price only
- `product_rating` - Star rating (numeric)
- `product_stock` - Stock quantity
- `product_sku` - Product SKU

#### Archive Tags
- `archive_title` - Archive page title
- `archive_description` - Archive description
- `term_image` - Category/taxonomy image

#### User Tags
- `current_user_name` - Logged-in user's name
- `current_user_email` - User email
- `current_user_role` - User role(s)

#### ACF Tags (auto-detected)
- `acf_[field_name]` - Any ACF field

### Shortcode Usage

Use anywhere in content:

```
[sf_dynamic field="post_title"]
[sf_dynamic field="author_name"]
[sf_dynamic field="current_year"]
[sf_dynamic field="product_price" format="text"]
[sf_dynamic field="site_logo" format="html"]
```

### Conditional Display Logic

Show/hide Elementor widgets based on conditions:

**Available Conditions:**
- User logged in/out
- User role (admin, subscriber, etc.)
- Date range
- URL parameter value
- Cookie value
- ACF field value
- WooCommerce cart status

**Logic Options:**
- AND - All conditions must be true
- OR - Any condition can be true

### Implementation Examples

#### 1. Show Content Only to Logged-In Users
Conditions:
- Type: User Logged In
- Logic: AND

#### 2. Show WooCommerce Content Only
Conditions:
- Type: WooCommerce Cart Status
- Value: cart_not_empty
- Logic: AND

#### 3. Show Based on URL Parameter
Conditions:
- Type: URL Parameter
- Param: `source`
- Value: `newsletter`
- Logic: AND

#### 4. Show Based on ACF Field
Conditions:
- Type: ACF Field
- Field: `show_special_offer`
- Logic: AND

#### 5. Complex: Multiple Conditions
Conditions:
1. Type: User Role = Editor
2. Type: Date Range = 2026-01-01 to 2026-03-31
3. Type: URL Parameter = campaign = spring
- Logic: AND (all must be true)

### Usage in Elementor

1. Go to Elementor widget advanced settings
2. Enable "Conditional Display"
3. Add conditions with dropdowns
4. Choose AND/OR logic
5. Widget hides/shows based on conditions

### Dynamic Shortcodes in Content

```
<h1>[sf_dynamic field="post_title"]</h1>
<p>Author: [sf_dynamic field="author_name"]</p>
<p>Price: [sf_dynamic field="product_price" format="text"]</p>
<p>Copyright © [sf_dynamic field="current_year"]</p>
```

### Real-World Use Cases

#### 1. Dynamic Post Meta Display
Show custom fields on product pages:
```
[sf_dynamic field="post_meta_manufacturer"]
[sf_dynamic field="post_meta_warranty"]
```

#### 2. Author Profile Pages
Auto-fill author information:
```
Name: [sf_dynamic field="author_name"]
Bio: [sf_dynamic field="author_bio"]
Website: [sf_dynamic field="author_url"]
```

#### 3. WooCommerce Product Pages
Display dynamic product info:
```
Price: [sf_dynamic field="product_price"]
Rating: [sf_dynamic field="product_rating"]
SKU: [sf_dynamic field="product_sku"]
Stock: [sf_dynamic field="product_stock"]
```

#### 4. Privacy Notice with Current Year
```
© [sf_dynamic field="current_year"] [sf_dynamic field="site_title"]
All rights reserved.
```

#### 5. Promotional Banners by Referral Source
Show different banners based on ?ref= URL parameter:
```
Conditions: URL Parameter ref = "facebook"
Show: Special Facebook Offer
```

### Performance Considerations

- Dynamic content loads at render time
- Conditional logic checks on each page load
- Cookie/localStorage checks are instant
- Database queries minimal (uses WordPress get_field/get_post_meta)
- No external API calls

### Security Notes

- All values properly escaped
- URL parameters sanitized
- Cookie values checked before use
- ACF field values validated
- WooCommerce data directly from objects

---

## FEATURE 3: Performance Pro

Advanced performance optimization system to compete with Astra's speed claims.

### Location
- **Class**: `/includes/class-performance-pro.php`
- **Admin CSS**: `/assets/css/performance-admin.css`
- **Frontend JS**: `/assets/js/performance-pro.js`

### Admin Location
Theme → Performance Pro

### Performance Features

#### 1. Critical CSS Optimization
- Inlines above-the-fold CSS in `<head>`
- Defers full stylesheet loading
- Reduces initial render time
- Per-page critical CSS support

**Settings**: Enable/Disable toggle

#### 2. Conditional Asset Loading
- Only loads CSS/JS for widgets used on page
- Detects Elementor widgets
- Reduces unused CSS/JS
- Faster page load

**Settings**: Enable/Disable toggle

#### 3. Defer Non-Critical JavaScript
- Adds `defer` attribute to non-critical scripts
- Improves rendering performance
- Prevents JavaScript blocking
- Safe for most plugins

**Settings**: Enable/Disable toggle

#### 4. Image Lazy Loading
- Adds `loading="lazy"` attribute to all images
- Adds `decoding="async"` for async decoding
- Detects LCP (Largest Contentful Paint) image
- Adds `fetchpriority="high"` to LCP

**Settings**: Enable/Disable toggle

#### 5. Image Format Optimization
- Generates responsive srcsets
- Detects WebP format support
- Picture element hints for modern formats
- Responsive image support

**Settings**: Enable/Disable toggle

#### 6. HTML/Script Cleanup
- Removes WordPress emoji scripts
- Removes jQuery Migrate (if not needed)
- Removes WordPress version meta tag
- Minifies inline CSS/JS (production mode)

**Settings**: Multiple toggles for each cleanup

#### 7. Browser Caching Headers
- Sets Cache-Control headers
- Adds ETag support
- 1 hour caching for homepage
- 24 hour caching for other pages

**Settings**: Enable/Disable toggle

#### 8. DNS Prefetch & Resource Hints
- Adds DNS prefetch for external services
- Preconnect to Google Fonts
- Helps with Core Web Vitals

**Settings**: Enable/Disable toggle

### Admin Dashboard

Performance Pro adds:
1. **Performance Score** (0-100) based on enabled optimizations
2. **Status List** showing active optimizations
3. **Optimization Settings** with toggle switches
4. **File Size Summary** (CSS, JS, Fonts estimates)
5. **Optimization Suggestions** for further improvements

### Dashboard Widget

The dashboard shows:
- Current performance score
- Count of active optimizations
- Link to Performance Pro settings

### Configuration Options

```php
// Default options (from code)
$options = array(
	'enable_critical_css' => true,
	'enable_conditional_assets' => true,
	'enable_lazy_loading' => true,
	'enable_image_optimization' => true,
	'enable_html_optimization' => true,
	'enable_cache_headers' => true,
	'defer_non_critical_js' => true,
	'remove_emoji_scripts' => true,
	'remove_jquery_migrate' => true,
	'minify_inline_css' => true,
	'minify_inline_js' => true,
	'preload_fonts' => false,
	'preload_images' => false,
	'dns_prefetch' => true,
);
```

### Web Vitals Detection

Performance Pro includes JavaScript for detecting:

**Core Web Vitals**:
- **LCP** (Largest Contentful Paint) - Target < 2.5s
- **FID** (First Input Delay) - Target < 100ms
- **CLS** (Cumulative Layout Shift) - Target < 0.1

Enable debug mode:
```javascript
window.sfPerformanceDebug = true;
```

### Image Optimization Details

#### Automatic Features
- Adds `loading="lazy"` to all images
- Adds `decoding="async"` for async decode
- Marks first image as `fetchpriority="high"`
- Optimizes post thumbnail images
- Responsive srcset generation

#### Lazy Loading Fallback
- Intersection Observer for modern browsers
- Fallback to immediate load for older browsers
- 50px margin before viewport (prefetch)
- CSS class `.sf-lazy-loaded` on loaded images

### Server Configuration Recommendations

For best performance, also configure:

1. **GZIP Compression** (.htaccess)
```
<IfModule mod_deflate.c>
	AddOutputFilterByType DEFLATE text/html text/plain text/xml
	AddOutputFilterByType DEFLATE text/css text/javascript
	AddOutputFilterByType DEFLATE application/javascript
</IfModule>
```

2. **Browser Caching** (.htaccess)
```
<IfModule mod_expires.c>
	ExpiresActive On
	ExpiresByType image/jpg "access plus 1 month"
	ExpiresByType image/gif "access plus 1 month"
	ExpiresByType image/png "access plus 1 month"
	ExpiresByType text/css "access plus 1 year"
	ExpiresByType application/javascript "access plus 1 year"
</IfModule>
```

3. **CDN Integration**
- CloudFlare
- BunnyCDN
- AWS CloudFront
- KeyCDN

### Optimization Score Breakdown

Performance score calculated from enabled features:
- Each enabled optimization adds points
- Score = (Enabled Features / Total Features) × 100
- Score ranges from 0-100

**Score Interpretation**:
- 90-100: Excellent
- 70-89: Good
- 50-69: Fair
- Below 50: Needs improvement

### Performance Impact Estimates

| Feature | LCP Impact | FID Impact | CLS Impact | File Size Reduction |
|---------|-----------|-----------|-----------|-------------------|
| Critical CSS | -20% | Neutral | Neutral | -15% |
| Conditional Assets | Neutral | Neutral | Neutral | -25% |
| Lazy Loading | Neutral | +5% | -10% | Neutral |
| Defer JS | +10% | -30% | Neutral | Neutral |
| Remove Emoji | Neutral | Neutral | Neutral | -10KB |
| Remove jQuery Migrate | Neutral | Neutral | Neutral | -60KB |
| Cache Headers | Neutral | Neutral | Neutral | Neutral |

### Troubleshooting

**Issue**: Popup button not appearing
**Solution**: Check `defer_non_critical_js` - may delay button availability

**Issue**: Forms not submitting
**Solution**: Disable `defer_non_critical_js` for form scripts

**Issue**: Images not loading
**Solution**: Check lazy loading implementation with error logging

**Issue**: Layout shifts
**Solution**: Ensure images have width/height attributes for CLS

### Testing & Monitoring

Use these tools to test:
1. **Google PageSpeed Insights** - Free Core Web Vitals analysis
2. **GTmetrix** - Performance waterfall
3. **WebPageTest** - Detailed testing
4. **Chrome DevTools** - Real-time performance
5. **Lighthouse** - Built-in performance audit

### Advanced Customization

Filter hook for custom critical CSS:
```php
$critical_css = apply_filters('sf_critical_css', $default_css);
```

Filter hook for cache headers:
```php
$headers = apply_filters('wp_headers', $headers);
```

---

## Integration Notes

### All Three Features Together

These features work seamlessly:

1. **Popup Builder** - Deliver popups with optimal performance
2. **Dynamic Content** - Personalize popup content dynamically
3. **Performance Pro** - Ensure fast popup delivery

### Example Workflow

1. Create popup with Dynamic Content tags:
   ```
   "Welcome back, [sf_dynamic field="current_user_name"]!
   Special offer expires [sf_dynamic field="current_date"]"
   ```

2. Set trigger to Exit Intent
3. Set frequency to Once Per Day
4. Performance Pro ensures fast delivery
5. Conditional Display shows only to logged-in users

### Compatibility

- **WordPress**: 5.8+
- **PHP**: 7.4+
- **Elementor**: 3.0+ (for dynamic content)
- **WooCommerce**: Optional (for WooCommerce tags)
- **ACF**: Optional (for ACF tags)

### Browser Support

All features tested on:
- ✓ Chrome 90+
- ✓ Firefox 88+
- ✓ Safari 14+
- ✓ Edge 90+
- ✗ IE11 (uses modern JS)

---

## Conclusion

These three premium features provide enterprise-level functionality competitive with Avada, Divi, and Astra, while maintaining lightweight code and WordPress standards compliance.
