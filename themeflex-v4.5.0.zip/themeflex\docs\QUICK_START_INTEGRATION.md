# Starter Flavor - Quick Start Integration Guide

## ⚡ 5-Minute Integration

To activate all 6 new features, add this code to your theme's `functions.php`:

```php
/**
 * Load Advanced Features
 * 
 * One-Click Demo Importer
 * Parallax & Animation System
 * Video Background System
 * Custom Icon System
 * Theme Dashboard
 * Advanced Header Features
 */

// 1. Demo Importer
require_once get_template_directory() . '/includes/class-demo-importer.php';

// 2. Animations & Parallax
require_once get_template_directory() . '/includes/class-animations.php';

// 3. Video Backgrounds
require_once get_template_directory() . '/includes/class-video-background.php';

// 4. Icon System
require_once get_template_directory() . '/includes/class-icons.php';

// 5. Theme Dashboard
require_once get_template_directory() . '/includes/class-theme-dashboard.php';

// 6. Advanced Headers
require_once get_template_directory() . '/includes/class-header-advanced.php';
```

---

## 🎨 In Your Header Template

Add these lines to `template-parts/header/header.php` or your main header template:

```php
<?php
// Display top bar (if enabled in Customizer)
get_template_part( 'template-parts/header/header-topbar' );
?>

<!-- Your existing header HTML -->

<?php
// Search overlay modal
get_template_part( 'template-parts/header/header-search-overlay' );

// Off-canvas mobile menu
get_template_part( 'template-parts/header/header-offcanvas' );
?>
```

---

## 📱 In Your Main Footer

Add this at the very end of `footer.php` (before closing body):

```php
<?php
// Back-to-top button & scroll progress bar are auto-rendered
// (included in animations.js)
?>
```

---

## 🚀 Access Points in WordPress Admin

After integration, these menu items will appear:

1. **Appearance → Starter Flavor** - Theme Dashboard (welcome page)
2. **Appearance → Import Demo** - Demo Content Importer
3. **Appearance → Icon Library** - Browse 60 available icons
4. **Customize → Animations** - Toggle animations globally
5. **Customize → Advanced Header** - Header options (sticky, transparent, etc.)
6. **Customize → Header Video Background** - Video settings

---

## 💡 Usage Examples

### 1. Add Scroll Animations to Elements

```php
<!-- Simple fade-in animation -->
<div data-animate="fade-in">
    <h2>This will fade in when scrolled into view</h2>
</div>

<!-- With delay and custom duration -->
<div data-animate="slide-up" data-animate-delay="200" data-animate-duration="1000">
    <p>Slides up with 200ms delay, 1 second duration</p>
</div>

<!-- Animation types: fade-in, slide-up, slide-down, slide-left, slide-right, zoom-in, flip -->
```

### 2. Add Parallax Effect to Backgrounds

```php
<div data-parallax="true" data-parallax-speed="0.5" style="height: 400px;">
    <img src="background.jpg" alt="Parallax Background">
</div>

<!-- Speed range: 0.1 (very slow) to 1.0 (normal scroll speed) -->
```

### 3. Use Icons in Your Templates

```php
<!-- Display an icon -->
<?php echo sf_icon( 'arrow-right', 24, 'my-custom-class' ); ?>

<!-- Available icons: arrow-right, arrow-left, menu, close, search, heart, star, etc. -->
<!-- Size in pixels, class for custom styling -->
```

### 4. Add Video Backgrounds

```php
<?php
// YouTube
Starter_Flavor_Video_Background::render_video_background(
    'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    '/images/poster.jpg'
);

// Vimeo
Starter_Flavor_Video_Background::render_video_background(
    'https://vimeo.com/123456789',
    '/images/poster.jpg'
);

// Self-hosted MP4
Starter_Flavor_Video_Background::render_video_background(
    '/videos/background.mp4',
    '/images/poster.jpg'
);
?>
```

### 5. Enable Page-Specific Transparent Headers

```php
<?php
// In page meta (or add custom post meta in editor):
update_post_meta( $post_id, '_transparent_header', 1 );

// Will override global transparency setting
?>
```

---

## 🎯 Features At A Glance

| Feature | Location | Admin Page | Customizer |
|---------|----------|-----------|-----------|
| Demo Importer | `includes/class-demo-importer.php` | ✅ Appearance → Import Demo | ❌ |
| Animations | `includes/class-animations.php` | ❌ | ✅ Animations |
| Video BG | `includes/class-video-background.php` | ❌ | ✅ Header Video |
| Icons | `includes/class-icons.php` | ✅ Appearance → Icon Library | ❌ |
| Dashboard | `includes/class-theme-dashboard.php` | ✅ Starter Flavor | ❌ |
| Headers | `includes/class-header-advanced.php` | ❌ | ✅ Advanced Header |

---

## 📦 What's Included

### PHP Classes (6)
- `class-demo-importer.php` (350+ lines)
- `class-animations.php` (180+ lines)
- `class-video-background.php` (280+ lines)
- `class-icons.php` (380+ lines)
- `class-theme-dashboard.php` (420+ lines)
- `class-header-advanced.php` (480+ lines)

### JavaScript (7 files)
- `parallax.js` - High-performance parallax engine
- `animations.js` - Scroll reveal system
- `video-background.js` - Video player handler
- `demo-importer.js` - AJAX import interface
- `dashboard.js` - Admin dashboard tabs
- `header.js` - Sticky, search, off-canvas
- `icon-library.js` - Icon admin interface

### CSS (5 files)
- `animations.css` - Keyframes & animations
- `demo-importer.css` - Demo UI styles
- `dashboard.css` - Dashboard styling
- `header-advanced.css` - Header component styles
- `icon-library.css` - Icon gallery styles

### Templates (4 new files)
- `header-topbar.php` - Top contact bar
- `header-minimal.php` - Hamburger-only header
- `header-search-overlay.php` - Full-screen search
- `header-offcanvas.php` - Mobile slide-out menu

### Demo Content (3 complete demos)
- Corporate (business/agency)
- Creative (portfolio/design)
- Shop (WooCommerce store)

**Total: 40+ new files, ~4000 lines of code**

---

## ✨ Features Summary

### 1️⃣ Demo Importer
- 3 pre-built demos
- One-click import
- Selective content selection
- Progress tracking
- Reset functionality

### 2️⃣ Animations
- 7 animation types
- Scroll reveal system
- Parallax backgrounds
- Back-to-top button
- Smooth scrolling

### 3️⃣ Video Backgrounds
- YouTube support
- Vimeo support
- Self-hosted MP4
- Mobile fallback
- Lazy loading

### 4️⃣ Icon System
- 60 SVG icons
- Admin gallery
- Copy-to-clipboard
- PHP & JS helpers
- Elementor ready

### 5️⃣ Dashboard
- Welcome page
- Setup guide
- Plugin status
- System info
- Support links

### 6️⃣ Advanced Headers
- Sticky header
- Transparent option
- Search overlay
- Off-canvas menu
- Top bar
- Multiple styles

---

## 🔧 Customizer Options

Navigate to **Appearance → Customize** to find:

- **Animations** section:
  - Enable/Disable Animations
  - Smooth Scroll
  - Back to Top Button

- **Header Video Background** section:
  - Video URL
  - Poster Image
  - Autoplay
  - Muted
  - Loop

- **Advanced Header** section:
  - Sticky Header
  - Shrink on Scroll
  - Transparent Header Default
  - Search Overlay
  - Off-Canvas Menu
  - Top Bar Settings
  - Header Style Selection

---

## 🌐 Browser Support

- ✅ Chrome/Edge 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ❌ IE11 (uses modern ES6)

---

## ♿ Accessibility

- ✅ ARIA labels
- ✅ Keyboard navigation
- ✅ Prefers-reduced-motion support
- ✅ Semantic HTML
- ✅ Screen reader friendly

---

## ⚡ Performance

- 🚀 Vanilla JavaScript (no jQuery dependencies)
- 🚀 Lazy loading for videos
- 🚀 RequestAnimationFrame (60fps)
- 🚀 IntersectionObserver
- 🚀 Optimized SVG icons
- 🚀 Minimal CSS footprint

---

## 📖 Documentation Files

- `FEATURES_BUILD_MANIFEST.md` - Complete feature documentation
- `QUICK_START_INTEGRATION.md` - This file

---

## ✅ Checklist for Integration

- [ ] Copy 6 PHP class files to `/includes/`
- [ ] Copy 7 JS files to `/assets/js/`
- [ ] Copy 5 CSS files to `/assets/css/`
- [ ] Copy 4 template parts to `/template-parts/header/`
- [ ] Copy demo-content folder with all demos
- [ ] Add feature includes to `functions.php`
- [ ] Add template parts to header template
- [ ] Test all features in browser
- [ ] Check WordPress admin pages (Dashboard, Demo Importer, Icon Library)
- [ ] Test Customizer settings
- [ ] Test on mobile devices
- [ ] Run accessibility audit

---

## 🆘 Troubleshooting

**Theme Dashboard not appearing?**
- Ensure `class-theme-dashboard.php` is loaded in `functions.php`
- Clear browser cache
- Deactivate other plugins temporarily

**Animations not working?**
- Check if enabled in Customizer → Animations
- Verify `animations.js` is loaded
- Browser might have "Prefers Reduced Motion" enabled

**Demo import failing?**
- Check PHP memory limit (minimum 256MB)
- Ensure demo files exist in `/demo-content/`
- Check WordPress importer plugin is active

**Icons not displaying?**
- Verify `class-icons.php` is loaded
- Check browser console for errors
- Ensure SVG rendering is allowed

---

## 📞 Support

All classes include:
- Comprehensive inline documentation
- Clear method descriptions
- Parameter documentation
- Return type information
- Usage examples

For additional help, refer to:
- `FEATURES_BUILD_MANIFEST.md` - Detailed feature docs
- Individual class headers - Code documentation
- WordPress Codex - Core function reference

---

## 📋 Version Info

- **Theme**: Starter Flavor
- **Version**: 1.0.0
- **Build Date**: 2026-04-13
- **Code Lines**: ~4,000
- **Files Created**: 40+
- **Status**: Production Ready ✅

---

**Happy Building! 🚀**
