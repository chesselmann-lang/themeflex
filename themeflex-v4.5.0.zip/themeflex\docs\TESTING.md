# Starter Flavor Theme - Testing & Linting Guide

## Overview

This document describes the testing and code quality infrastructure for the Starter Flavor WordPress theme.

## Contents

- [PHPUnit Testing](#phpunit-testing)
- [Linting Tools](#linting-tools)
- [JSON Validation](#json-validation)
- [Running Tests](#running-tests)
- [Continuous Integration](#continuous-integration)

---

## PHPUnit Testing

### Setup

PHPUnit is configured to test theme setup, security, Elementor widgets, demo content, and GDPR compliance.

#### Installation

```bash
composer install
```

#### Configuration

PHPUnit is configured in `phpunit.xml.dist`:
- Bootstrap: `tests/bootstrap.php`
- Test directory: `tests/`
- Coverage reporting included

### Test Files

#### 1. `tests/test-theme-setup.php` (~150 lines)

Tests core theme setup and structure:

- **Constants**: Verifies all theme constants are defined (STARTER_FLAVOR_THEME_DIR, STARTER_FLAVOR_VERSION, etc.)
- **Files**: Checks required template files exist (header.php, footer.php, index.php, etc.)
- **Directories**: Validates asset and include directories exist
- **Stylesheet**: Verifies style.css has proper WordPress theme header
- **Language Support**: Checks language directory exists for i18n

**Run individually:**
```bash
composer test -- tests/test-theme-setup.php
```

#### 2. `tests/test-security.php` (~100 lines)

Tests security best practices:

- **Direct Access Protection**: Verifies files check for ABSPATH
- **Escaping Functions**: Tests esc_attr(), esc_html(), esc_url() work correctly
- **No Dangerous Functions**: Checks for absence of eval(), exec(), system(), etc.
- **Sanitization**: Verifies input sanitization functions are available
- **Nonce Support**: Checks nonce functions are available in WP context

**Run individually:**
```bash
composer test -- tests/test-security.php
```

#### 3. `tests/test-elementor-widgets.php` (~150 lines)

Tests Elementor widget infrastructure:

- **Widget Files**: Verifies all 6 widget classes exist
- **Class Structure**: Checks widget classes are properly defined
- **Required Methods**: Tests get_name, get_title, get_icon, register_controls, render
- **Naming Convention**: Verifies widgets are prefixed with "starter-flavor-"
- **Assets**: Confirms widget CSS and JS files exist
- **Security**: Checks widget files include ABSPATH security checks

**Run individually:**
```bash
composer test -- tests/test-elementor-widgets.php
```

#### 4. `tests/test-demo-importer.php` (~100 lines)

Tests demo content infrastructure:

- **Class Exists**: Verifies Starter_Flavor_Demo_Importer class exists
- **Templates Directory**: Checks elementor-templates directory exists
- **JSON Validity**: Validates all 226 JSON templates are valid JSON
- **Required Keys**: Ensures templates have required metadata (title, type/content, etc.)
- **Type Validation**: Validates template type values (page, section, template)
- **Content Validation**: Checks templates have non-empty content/elements/sections

**Run individually:**
```bash
composer test -- tests/test-demo-importer.php
```

#### 5. `tests/test-gdpr.php` (~80 lines)

Tests GDPR and privacy compliance:

- **Privacy References**: Checks for privacy/cookie handling code
- **Documentation**: Verifies functions have proper docblocks
- **Output Escaping**: Tests proper escaping in templates
- **Nonce Usage**: Checks nonce functions are available for form protection
- **Input Sanitization**: Verifies sanitization functions are used for user input
- **i18n Functions**: Tests translation functions are available
- **Text Domain**: Validates consistent use of 'starter-flavor' text domain

**Run individually:**
```bash
composer test -- tests/test-gdpr.php
```

### Running Tests

#### All Tests

```bash
composer test
```

#### With Coverage Report

```bash
composer test:coverage
```

This generates HTML coverage report in `coverage/` directory.

#### Specific Test

```bash
composer test -- tests/test-theme-setup.php
```

#### Specific Test Method

```bash
composer test -- tests/test-theme-setup.php --filter testThemeConstantsDefined
```

---

## Linting Tools

### ESLint (JavaScript)

Configuration: `.eslintrc.json`

Checks JavaScript files for:
- Syntax errors
- Best practices
- WordPress/jQuery/Elementor globals
- Proper escaping
- Consistent style

**Install dependencies:**
```bash
npm install
```

**Run linting:**
```bash
npm run lint:js
```

**Example output:**
```
assets/js/some-file.js
  5:8  error  'undefined variable' is not defined  no-undef
  12:1  error  Missing semicolon  semi
```

### PHP_CodeSniffer (PHP)

Configuration: `.phpcs.xml.dist`

Checks PHP files for:
- WordPress Coding Standards
- Text domain consistency
- Proper prefix usage (starter_flavor_, sf_)
- PHP 7.4 compatibility

**Installation:**
```bash
composer install
```

**Run linting:**
```bash
composer lint
```

**Auto-fix issues:**
```bash
composer lint:fix
```

**PHP Compatibility check:**
```bash
composer lint:compat
```

### EditorConfig

Configuration: `.editorconfig`

Ensures consistent coding style across the team:
- Tab/space usage
- Line endings (LF)
- Character encoding (UTF-8)
- Max line length

Supported editors: VS Code, PhpStorm, Sublime, etc.

---

## JSON Validation

### Template Validation

All Elementor templates in `elementor-templates/` are validated for:

✅ Valid JSON syntax
✅ Required fields (title + content/elements/sections)
✅ Non-empty arrays/strings
✅ Consistent structure

**Run validation:**
```bash
npm test
```

**What it checks:**

1. **JSON Validity** - All files are valid JSON
2. **Title Field** - Every template has a non-empty title
3. **Content Field** - Templates contain one of:
   - `content` (string or array)
   - `elements` (array)
   - `sections` (array)
   - `pages` (array)
4. **Array Validation** - Content arrays are not empty

**Supported Template Formats:**

```javascript
// Format 1: Simple content
{
  "title": "Page Title",
  "type": "page",
  "content": [...]
}

// Format 2: Elementor elements
{
  "version": "1.0.0",
  "title": "Agency",
  "elements": [...]
}

// Format 3: Sections
{
  "title": "Team",
  "type": "page",
  "sections": [...]
}

// Format 4: Pages metadata
{
  "version": "1.0.0",
  "title": "Law Firm",
  "pages": [...]
}
```

---

## Running Tests

### Quick Check

Run all validations:
```bash
npm run test:all
```

This runs:
1. JSON template validation
2. JavaScript linting
3. CSS linting

### Development Workflow

```bash
# Before committing, run full test suite
npm run test:all

# Or run individual checks
npm test                 # JSON validation
npm run lint:js         # JavaScript linting
npm run lint:css        # CSS linting

# Fix auto-fixable issues
npm run lint:js -- --fix
composer lint:fix
```

### Pre-commit Hook (Optional)

Create `.git/hooks/pre-commit`:

```bash
#!/bin/bash
npm run test:all
if [ $? -ne 0 ]; then
  echo "Tests failed. Commit aborted."
  exit 1
fi
```

Make executable:
```bash
chmod +x .git/hooks/pre-commit
```

---

## Continuous Integration

### GitHub Actions Example

Create `.github/workflows/test.yml`:

```yaml
name: Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v2
      
      - name: Setup Node
        uses: actions/setup-node@v2
        with:
          node-version: '14'
      
      - name: Setup PHP
        uses: shivammathur/setup-php@v2
        with:
          php-version: '7.4'
      
      - name: Install dependencies
        run: |
          npm install
          composer install
      
      - name: Run tests
        run: npm run test:all
      
      - name: Run PHPUnit
        run: composer test
```

---

## Test Results Summary

### Current Status

✅ **226/226 JSON templates** - All valid
✅ **Theme constants** - All defined
✅ **Required files** - All present
✅ **Security checks** - Passed
✅ **Widget structure** - Valid
✅ **GDPR compliance** - Checked

### Key Metrics

- **Total Tests**: ~5 test classes with 40+ test methods
- **Code Coverage**: Asset included for includes/ and elementor-templates/
- **Linting Rules**: ESLint (80+ rules), PHPCS (WordPress standards)
- **Template Validation**: All 226 templates validated

---

## Troubleshooting

### JSON Validation Fails

**Error: "Invalid JSON"**
- Check file syntax with `node -e "console.log(JSON.parse(require('fs').readFileSync('file.json')))"`
- Use JSON formatter to validate structure

**Error: "Missing required keys"**
- Ensure template has `title` field
- Add one of: `content`, `elements`, `sections`, or `pages`
- Verify arrays are not empty

### PHPUnit Won't Run

**Error: "WordPress test library not found"**
- This is expected. Tests use mock functions for standalone running.
- Optional: Install WordPress test suite for full integration testing.

### ESLint/PHP_CodeSniffer Install Issues

```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install

composer dump-autoload
composer install
```

---

## Adding New Tests

### Add PHPUnit Test

1. Create file in `tests/test-*.php`
2. Extend `PHPUnit\Framework\TestCase`
3. Add test methods with `public function test*() { ... }`

Example:
```php
class Test_New_Feature extends PHPUnit\Framework\TestCase {
    public function test_feature_works() {
        $this->assertTrue(true);
    }
}
```

### Add ESLint Rule

Edit `.eslintrc.json` in `rules` section:
```json
"no-console": ["warn"],
"semi": ["error", "always"]
```

### Add PHPCS Rule

Edit `.phpcs.xml.dist` to add exclusions or configurations:
```xml
<rule ref="WordPress.NamingConventions.PrefixAllGlobals">
    <properties>
        <property name="prefixes" type="array">
            <element>starter_flavor_</element>
        </property>
    </properties>
</rule>
```

---

## Resources

- [PHPUnit Documentation](https://phpunit.de/)
- [ESLint Documentation](https://eslint.org/)
- [PHP_CodeSniffer](https://github.com/squizlabs/PHP_CodeSniffer)
- [WordPress Coding Standards](https://developer.wordpress.org/coding-standards/)
- [Elementor Widget Development](https://developers.elementor.com/creating-a-simple-widget/)

---

## Support

For issues or questions about testing infrastructure:
1. Check this documentation
2. Review test files for examples
3. Check PHPUnit/ESLint error messages
4. Refer to external documentation links above
