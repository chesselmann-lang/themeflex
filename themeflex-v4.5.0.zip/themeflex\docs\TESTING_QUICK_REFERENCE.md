# Testing Quick Reference

## Run All Tests
```bash
npm run test:all
```

## Individual Commands

### JSON Template Validation
```bash
npm test
```
✅ 226/226 templates validated

### JavaScript Linting
```bash
npm run lint:js
npm run lint:js -- --fix  # Auto-fix
```

### CSS Linting
```bash
npm run lint:css
```

### PHP Linting
```bash
composer lint
composer lint:fix        # Auto-fix
composer lint:compat     # PHP 7.4 check
```

### PHPUnit Tests
```bash
composer test                              # All tests
composer test -- tests/test-theme-setup.php  # Specific file
composer test:coverage                    # With coverage
```

---

## Test Files

| File | Tests | Focus |
|------|-------|-------|
| `tests/test-theme-setup.php` | 12 | Constants, files, directories |
| `tests/test-security.php` | 11 | Escaping, sanitization, no eval |
| `tests/test-elementor-widgets.php` | 10 | Widget structure, prefixes |
| `tests/test-demo-importer.php` | 10 | JSON validity, template structure |
| `tests/test-gdpr.php` | 9 | Privacy, GDPR compliance |

**Total**: 52 test methods

---

## Configuration Files

| File | Purpose |
|------|---------|
| `phpunit.xml.dist` | PHPUnit configuration |
| `.eslintrc.json` | JavaScript linting rules |
| `.phpcs.xml.dist` | PHP linting rules |
| `.editorconfig` | Code style consistency |
| `composer.json` | PHP dependencies & scripts |
| `package.json` | Node dependencies & scripts |

---

## JSON Template Validation

### Supported Formats
- `{title, type, content}` — Simple content
- `{version, title, elements}` — Elementor elements
- `{title, type, sections}` — Sections
- `{version, title, pages}` — Metadata

### Status
✅ All 226 templates: Valid JSON
✅ All templates: Have title + content
✅ No empty arrays/strings

---

## Common Issues & Fixes

### JSON Validation Failed
```bash
# Check specific file
node -e "console.log(JSON.parse(require('fs').readFileSync('file.json')))"
```

### ESLint Won't Run
```bash
npm install
npm run lint:js
```

### PHPCS Won't Run
```bash
composer install
composer lint
```

### Need Coverage Report
```bash
composer test:coverage
# Open coverage/index.html
```

---

## Pre-commit Hook

Create `.git/hooks/pre-commit`:
```bash
#!/bin/bash
npm run test:all
composer test
```

Make executable:
```bash
chmod +x .git/hooks/pre-commit
```

---

## Documentation

- Full guide: **TESTING.md**
- Implementation details: **TESTING_INFRASTRUCTURE_SUMMARY.md**

---

## Key Metrics

✅ **Test Methods**: 52+
✅ **Template Validation**: 226/226
✅ **Linting Rules**: 17+ ESLint, WordPress standards
✅ **Security Tests**: eval/exec/system checks
✅ **Coverage**: includes/, elementor-templates/
