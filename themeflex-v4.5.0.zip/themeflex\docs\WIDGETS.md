# Starter Flavor - Elementor Widgets

Vollständige Dokumentation aller Custom Elementor Widgets des "Starter Flavor" WordPress Themes.

## Übersicht

Das Theme includes 7 Custom Widgets in der Kategorie "Starter Flavor":

1. **Hero Section** - Hero Banner mit Hintergrund, Title, Subtitle und Button
2. **Image Gallery** - Responsive Bildergalerie mit Grid/Masonry Layout
3. **Blog Carousel** - Blog-Beiträge Carousel mit CSS Scroll-Snap
4. **Content Slider** - Fullwidth Slider/Slideshow mit Auto-Slide
5. **Progress Bar** - Skill/Progress Bars mit Animation
6. **Countdown Timer** - Countdown zu einem Zieldatum
7. **Social Icons** - Social Media Links mit mehreren Shapes

---

## 1. Image Gallery Widget

### Funktionen
- **Gallery Control**: Elementor-natives Gallery Control für Bilder
- **Layout**: Grid (2-6 Spalten) oder Masonry
- **Lightbox**: Elementor Lightbox Support
- **Hover Overlay**: Icon oder Titel beim Hover
- **Gap/Spacing**: Einstellbarer Abstand zwischen Bildern
- **Lazy Loading**: Automatisches Lazy Loading
- **Styling**: Border-radius, Shadow, Overlay Color

### Controls

**Content Tab:**
- Gallery Images (GALLERY control)
- Layout (Select: Grid, Masonry)
- Columns (Select: 2-6)
- Enable Lightbox (Switcher)
- Hover Overlay (Select: None, Icon, Title)
- Gap/Spacing (Slider)
- Lazy Loading (Switcher)

**Style Tab:**
- Image Border Radius (Dimensions)
- Image Shadow (Box Shadow)
- Overlay Color (Color picker)

### CSS-Klassen
```
.gallery-container
.gallery-image-item
.gallery-image
.gallery-overlay
.overlay-icon
.overlay-title
```

### JavaScript
Automatische Initialisierung im `elementor-widgets.js`

---

## 2. Blog Carousel Widget

### Funktionen
- **WP_Query**: Automatische Post-Abfrage mit Filteroptionen
- **CSS Scroll-Snap**: Vanilla CSS Carousel (kein Framework)
- **Navigation**: Prev/Next Buttons und Dots
- **Card Design**: Thumbnail, Date, Title, Excerpt, Read More Button
- **Autoplay**: Optionaler Autoplay mit einstellbarem Interval
- **Responsive**: Vollständig responsive

### Controls

**Content Tab:**
- Number of Posts (Number: 1-20)
- Category Filter (Select)
- Order By (Select: Date, Title, Modified, Random, Menu Order)
- Order (Select: ASC, DESC)
- Autoplay (Switcher)
- Autoplay Speed (Number: 1000-10000ms)

**Card Style Tab:**
- Card Background Color
- Card Box Shadow

**Typography Tab:**
- Title Typography (Group Control)

**Button Tab:**
- Button Color

### CSS-Klassen
```
.blog-carousel
.carousel-inner
.blog-card
.blog-thumbnail
.blog-card-content
.blog-date
.blog-card-title
.blog-excerpt
.blog-read-more
.carousel-prev / .carousel-next
.carousel-dots
.dot
```

### JavaScript
- Scroll-Snap Navigation
- Autoplay mit manuellem Reset
- Dot/Arrow Navigation

---

## 3. Content Slider Widget

### Funktionen
- **Repeater**: Beliebig viele Slides mit Hintergrund, Title, Subtitle, Button
- **Fullwidth Slider**: Vollbreiter Slider mit Overlay
- **Navigation**: Arrows und Dots
- **Auto-Slide**: Mit einstellbarem Interval
- **Fade Animation**: Fade-Effekt zwischen Slides
- **Responsive Heights**: Desktop und Mobile Heights

### Controls

**Slides Tab (Repeater):**
- Background Image (MEDIA)
- Title (TEXT)
- Subtitle (TEXTAREA)
- Button Text (TEXT)
- Button URL (URL)

**Settings Tab:**
- Autoplay (Switcher)
- Autoplay Interval (Number)
- Slider Height (Number)
- Mobile Height (Number)

**Overlay Style Tab:**
- Overlay Color (Color picker)
- Overlay Opacity (Slider)

**Typography Tab:**
- Title Color & Typography
- Subtitle Color

**Button Tab:**
- Button Background Color
- Button Text Color

### CSS-Klassen
```
.slider-wrapper
.slider-container
.slide
.slide.active
.slide-overlay
.slide-content
.slide-title
.slide-subtitle
.slide-button
.slider-arrow
.slider-prev / .slider-next
.slider-dots
.dot
```

### JavaScript
- Slide Navigation (Arrows & Dots)
- Autoplay mit Reset
- Fade-Animation

---

## 4. Progress Bar Widget

### Funktionen
- **Repeater**: Beliebig viele Skills mit Name und Percentage
- **Animated Fill**: IntersectionObserver Animation on Scroll
- **Horizontal Layout**: Horizontale Progress Bars
- **Percentage Text**: Optional anzeigbar
- **Gradient Support**: Optionaler Gradient Fill
- **Styling**: Bar Color, Height, Border-radius, Typography

### Controls

**Skills Tab (Repeater):**
- Skill Name (TEXT)
- Skill Percentage (SLIDER: 0-100)

**Settings:**
- Show Percentage Text (Switcher)

**Bar Style Tab:**
- Bar Height (Number)
- Bar Background Color
- Bar Fill Color
- Use Gradient (Switcher)
- Bar Gradient (Group Control - conditional)
- Bar Border Radius (Dimensions)

**Typography Tab:**
- Skill Name Typography & Color
- Percentage Typography & Color

**Spacing Tab:**
- Space Between Skills (Slider)

### CSS-Klassen
```
.progress-bars-container
.skill-item
.skill-header
.skill-name
.skill-percentage-text
.progress-background
.progress-fill
.progress-fill.gradient
```

### JavaScript
- IntersectionObserver für Animation on Scroll
- Automatische Percentage-Berechnung und Animation

---

## 5. Countdown Timer Widget

### Funktionen
- **Date/Time Picker**: Target-Datum Auswahl
- **Display Options**: Days, Hours, Minutes, Seconds (konfigurierbar)
- **Layouts**: Inline oder Boxed
- **Expired Message**: Custom Message bei Ablauf
- **Vanilla JS**: Reine JavaScript Countdown-Logik
- **Styling**: Separate Styles für Numbers und Labels

### Controls

**Content Tab:**
- Target Date (DATE_TIME picker)
- Display Format (Select: Full, Days-Hours-Minutes, etc.)
- Layout (Select: Inline, Boxed)
- Expired Message (TEXTAREA)

**Numbers Style Tab:**
- Font Size (Slider)
- Color (Color picker)
- Typography (Group Control)

**Labels Style Tab:**
- Font Size (Slider)
- Color (Color picker)

**Box Style Tab:**
- Background Color (conditional - boxed layout)
- Padding (Dimensions - conditional)
- Border (Border control - conditional)
- Separator Color

### CSS-Klassen
```
.countdown-wrapper
.countdown-item
.countdown-item.boxed
.countdown-item.inline
.countdown-number
.countdown-label
.countdown-separator
.countdown-expired
```

### JavaScript
- Echtzeit Countdown-Berechnung
- 1-Sekunden-Update
- Automatischer Expired-State

### Format-Optionen
- **full**: Days : Hours : Minutes : Seconds
- **dmy**: Days : Hours : Minutes
- **dhm**: Days : Hours : Minutes
- **hms**: Hours : Minutes : Seconds

---

## 6. Social Icons Widget

### Funktionen
- **Repeater**: Beliebig viele Social Links
- **Platforms**: 13 vordefinierte Plattformen
- **Icon Shapes**: Circle, Square, Rounded
- **Layouts**: Horizontal oder Vertikal
- **Hover Animations**: Bounce, Scale, Color Change
- **Styling**: Size, Color, Background, Border

### Controls

**Social Links Tab (Repeater):**
- Platform (Select: Facebook, Twitter/X, Instagram, LinkedIn, YouTube, TikTok, GitHub, Dribbble, Behance, Pinterest, WhatsApp, Telegram, Email)
- URL (URL control)

**Settings Tab:**
- Icon Shape (Select: Circle, Square, Rounded)
- Layout (Select: Horizontal, Vertical)
- Hover Animation (Select: None, Bounce, Scale, Color Change)
- Open in New Tab (Switcher)

**Icons Style Tab:**
- Icon Size (Slider)
- Container Size (Slider)
- Icon Color
- Background Color
- Hover Color

**Spacing Tab:**
- Space Between Icons (Slider)

**Border Tab:**
- Icon Border (Border control)

### CSS-Klassen
```
.social-icons-wrapper
.social-layout-horizontal
.social-layout-vertical
.social-icon
.social-shape-circle
.social-shape-square
.social-shape-rounded
.social-hover-bounce
.social-hover-scale
.social-hover-color-change
```

### Unterstützte Plattformen
- Facebook
- Twitter/X
- Instagram
- LinkedIn
- YouTube
- TikTok
- GitHub
- Dribbble
- Behance
- Pinterest
- WhatsApp
- Telegram
- Email

---

## Assets

### CSS
- **Datei**: `assets/css/elementor-widgets.css`
- **Features**: Vollständige Styling für alle Widgets, Responsive Design, Mobile-first Approach

### JavaScript
- **Datei**: `assets/js/elementor-widgets.js`
- **Features**: Vanilla JavaScript (keine Dependencies), Elementor-Integration Hook

---

## Integration

### Registrierung
Alle Widgets werden automatisch in der `includes/elementor.php` registriert.

### Kategorie
Alle Widgets erscheinen in der "Starter Flavor" Kategorie im Elementor Editor.

### Enqueue
CSS und JS werden automatisch enqueued, wenn Elementor aktiv ist.

---

## Best Practices

### Performance
- Lazy Loading für Bilder ist standardmäßig aktiviert
- Vanilla JavaScript statt jQuery für bessere Performance
- CSS Scroll-Snap statt JavaScript für Carousel
- IntersectionObserver für Animations on Scroll

### Accessibility
- ARIA Labels für Navigation Buttons
- Semantic HTML (h1, h2, h3 tags)
- Proper color contrast
- Keyboard Navigation Support

### Responsiveness
- Mobile-first CSS
- Configurable Heights für verschiedene Breakpoints
- Flexible Layouts (Flex/Grid)

---

## Enhancements & Future

Mögliche Erweiterungen:
- Video Support für Slider
- Advanced Animation Controls
- Dark Mode Support
- Custom Icon Upload für Social Icons
- Mehr Countdown Layouts
- Filtering für Blog Carousel

---

## Troubleshooting

### Widgets erscheinen nicht
1. Elementor Plugin aktiviert?
2. Theme version >= 1.0.0?
3. Widgets im Admin aktiviert?
4. Browser Cache leeren

### JavaScript funktioniert nicht
1. Console-Fehler prüfen
2. Assets richtig enqueued?
3. Elementor JavaScript wird korrekt geladen?
4. Theme-Kompatibilität prüfen

### Styling-Probleme
1. Elementor Responsive Breakpoints prüfen
2. Custom CSS nicht überschreiben lassen?
3. Theme Customizer Settings prüfen
4. Cache leeren (Browser + WordPress)
