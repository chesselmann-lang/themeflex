# Starter Flavor Widgets - Quick Start Guide

Schnelle Einstiegshilfe für die neuen Elementor Widgets.

## Installation

1. Theme im WordPress Admin aktivieren
2. Elementor Plugin aktivieren
3. Eine Seite/Post mit Elementor öffnen
4. Widgets finden unter "Starter Flavor" Kategorie

## Die 6 Neuen Widgets

### 1. Image Gallery
Bildergalerie mit Grid oder Masonry Layout.

**Quick Setup:**
1. Klicke "Add Widget" > Suche "Image Gallery"
2. Klicke "Gallery Images"
3. Wähle Bilder aus Mediathek
4. Wähle Layout (Grid oder Masonry)
5. Stelle Spalten (2-6) ein
6. Optional: Lightbox aktivieren, Hover Style einstellen

**Key Settings:**
- Layout: Grid oder Masonry
- Columns: 2-6
- Hover Overlay: Icon/Title/None
- Lightbox: Yes/No
- Lazy Loading: Yes/No

---

### 2. Blog Carousel
Blog-Beiträge als Carousel anzeigen.

**Quick Setup:**
1. Klicke "Add Widget" > Suche "Blog Carousel"
2. Stelle Anzahl Posts ein (1-20)
3. Optional: Kategorie filtern
4. Wähle Sort Order (Date, Title, etc.)
5. Optional: Autoplay aktivieren

**Key Settings:**
- Number of Posts: 1-20
- Category: Filter by category
- Order By: Date, Title, Modified, Random
- Autoplay: Yes/No
- Autoplay Speed: 1000-10000ms

---

### 3. Content Slider
Fullwidth Slider mit Bildern und Text.

**Quick Setup:**
1. Klicke "Add Widget" > Suche "Content Slider"
2. Klicke "Add Item" um Slides hinzuzufügen
3. Für jeden Slide:
   - Background Image wählen
   - Title eingeben
   - Subtitle eingeben
   - Button Text & URL (optional)
4. Optional: Autoplay aktivieren

**Key Settings:**
- Slides: Unbegrenzt viele hinzufügbar
- Autoplay: Yes/No
- Autoplay Interval: 1000-10000ms
- Slider Height: Desktop & Mobile
- Overlay Opacity: 0-100%

---

### 4. Progress Bar
Skill/Progress Bars mit animierter Füllung.

**Quick Setup:**
1. Klicke "Add Widget" > Suche "Progress Bar"
2. Klicke "Add Item" um Skills hinzuzufügen
3. Für jeden Skill:
   - Skill Name eingeben
   - Percentage setzen (0-100)
4. Optional: Show Percentage Text aktivieren

**Key Settings:**
- Skills: Unbegrenzt viele
- Show Percentage: Yes/No
- Bar Height: px
- Bar Color: Color/Gradient
- Border Radius: px

---

### 5. Countdown Timer
Countdown zu einem Zieldatum.

**Quick Setup:**
1. Klicke "Add Widget" > Suche "Countdown"
2. Klicke "Target Date" und wähle Datum/Zeit
3. Wähle Display Format (Full, Days-Hours-Minutes, etc.)
4. Wähle Layout (Inline oder Boxed)
5. Optional: Custom Expired Message

**Key Settings:**
- Target Date: Date/Time Picker
- Display Format: Full, DM, DHM, HMS
- Layout: Inline, Boxed
- Expired Message: Custom Text
- Number Size/Color: Styling

---

### 6. Social Icons
Social Media Links mit Icons.

**Quick Setup:**
1. Klicke "Add Widget" > Suche "Social Icons"
2. Klicke "Add Item" um Links hinzuzufügen
3. Für jeden Link:
   - Platform wählen (Facebook, Twitter, etc.)
   - URL eingeben
4. Wähle Icon Shape (Circle, Square, Rounded)
5. Wähle Layout (Horizontal oder Vertical)

**Unterstützte Plattformen:**
Facebook, Twitter/X, Instagram, LinkedIn, YouTube, TikTok, GitHub, Dribbble, Behance, Pinterest, WhatsApp, Telegram, Email

**Key Settings:**
- Icon Shape: Circle, Square, Rounded
- Layout: Horizontal, Vertical
- Hover Animation: None, Bounce, Scale, Color Change
- Icon Size: px
- Container Size: px

---

## Common Tasks

### Responsive Design
Alle Widgets sind automatisch responsive. Für Custom Breakpoints:
1. Nutze Elementor's Device Icons (Desktop/Tablet/Mobile)
2. Ändere Einstellungen für jedes Device
3. Z.B.: Slider Height unterschiedlich für Mobile/Desktop

### Styling
Alle Widgets haben vollständige Style Tabs:
1. Klicke Widget
2. Gehe zu "Style" Tab
3. Ändere Farben, Größen, Abstände, etc.

### Performance
- Lazy Loading für Galerie ist aktiviert (Standard)
- Autoplay wird bei manueller Navigation zurückgesetzt
- JavaScript wird nur initialisiert wenn Widget auf Seite ist

---

## Häufige Fehler

### Widget erscheint nicht
- Elementor Plugin aktiviert?
- "Starter Flavor" Kategorie sichtbar?
- Elementor Version 3.0+?

### Carousel/Slider funktioniert nicht
- JavaScript in Browser Console Fehler?
- Widgetinformationen als Widget speigeichert?
- Page Reload probieren

### Styling funktioniert nicht
- Cache geleert (Browser + WordPress)?
- Custom CSS überschreiben andere Styles?
- Device Breakpoints korrekt eingestellt?

---

## Tipps & Tricks

1. **Blog Carousel**: Nutze "Random" Order für Featured Posts
2. **Progress Bar**: Setze Gradient für Premium Look
3. **Countdown**: Nutze für Sale Deadlines, Event Countdowns
4. **Social Icons**: Open in New Tab für externe Links
5. **Slider**: Verwende gute Quality Images für beste Optik
6. **Gallery**: Aktiviere Lightbox für besseres User Experience

---

## Weitere Ressourcen

- **Full Documentation**: Siehe `WIDGETS.md`
- **Troubleshooting**: Siehe `WIDGETS_CHECKLIST.txt`
- **Browser Compatibility**: Siehe `WIDGET_IMPLEMENTATION_SUMMARY.md`

---

## Support

Für Probleme:
1. Siehe Dokumentation in Theme Ordner
2. Prüfe Browser Console auf Fehler
3. Leere WordPress Cache
4. Deaktiviere andere Plugins zum Testen

---

*Last Updated: 2026-04-12*  
*Version: 1.0.0*
