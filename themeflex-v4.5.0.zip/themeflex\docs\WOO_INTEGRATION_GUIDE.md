# WooCommerce Integration Guide

## Overview

Starter Flavor theme includes comprehensive WooCommerce support with advanced features for building professional e-commerce sites. This guide documents all available features, customization options, and best practices.

---

## Core WooCommerce Features

### Theme Support
The theme registers full WooCommerce support including:
- **Product Gallery Zoom:** Interactive zoom on product images
- **Product Gallery Lightbox:** Modal image viewing
- **Product Gallery Slider:** Image carousel navigation
- **Lightbox V2:** Advanced lightbox implementation

**Location:** `includes/woocommerce.php` (lines 18-24)

### Widget Areas
- **WooCommerce Sidebar:** Dedicated sidebar for product filters and widgets
- **Display Control:** Show/hide via theme options

**Location:** `includes/woocommerce.php` (lines 32-43)

---

## Shop Page Features

### Shop Layout Options
1. **Grid Layout** (default)
   - Responsive grid with configurable columns
   - Hover effects and smooth transitions
   - Product badges overlay

2. **List Layout** (optional)
   - Product image on left, details on right
   - More compact information display
   - Better for detailed product descriptions

**Configuration:**
```php
// Theme options
'woo_product_layout' => 'grid' // or 'list'
'woo_shop_columns' => 3        // 1-6 columns
'woo_products_per_page' => 12  // Items per page
```

### Product Cards
- Hover effects with image zoom
- Product badges (Sale, New, Hot, Out of Stock)
- Star ratings
- Price display with sale pricing
- Quick View button
- Wishlist button
- Add to Cart button

### Sidebar Features
- **Widgets:** Product categories, filters, price range
- **Appearance:** 300px width, sticky positioning
- **Styling:** Custom background and border styles

---

## Product Badges

### Available Badges
1. **Sale Badge**
   - Shows percentage discount or "Sale" text
   - Configurable discount calculation
   - Red/orange color (primary)

2. **New Badge**
   - Shows on products created within configurable days
   - Green color
   - Default: 14 days

3. **Hot Badge**
   - Shows on best-selling products
   - Configurable minimum sales threshold
   - Orange color

4. **Out of Stock Badge**
   - Shows when product inventory is empty
   - Gray color
   - Prevents adds to cart

**Configuration:**
```php
'woo_show_new_badge' => true
'woo_new_badge_days' => 14
'woo_show_hot_badge' => false
'woo_hot_badge_threshold' => 50
'woo_show_stock_badge' => true
```

---

## Quick View Modal

### Features
- **AJAX Loading:** Fast product preview without page reload
- **Modal Display:** Product details in beautiful lightbox
- **Responsive:** Works perfectly on mobile devices
- **Accessibility:** Keyboard navigable, ARIA labels

### What's Included in Quick View
- Product image
- Title
- Rating/reviews
- Price (with sale pricing)
- Short description (25 words)
- Add to cart button
- "View Full Details" link

### AJAX Handler
**File:** `includes/class-woo-enhancements.php` (lines 160-205)
**Action:** `wp_ajax_sf_quick_view` / `wp_ajax_nopriv_sf_quick_view`
**Nonce:** `sf-woo-enhancements`

### Usage
```html
<button class="quick-view-button" data-product-id="123">
  Quick View
</button>
```

### Styling
- Modal background: Dark overlay with 0.7 opacity
- Content width: 90%, max 800px
- Animation: Slide down effect (0.3s)
- Close button: Top-right corner

---

## AJAX Add-to-Cart (Archive Pages)

### Features
- **No Page Reload:** Add products without leaving page
- **Cart Update:** Mini cart updates immediately
- **Variation Support:** Works with variable products
- **Quantity Control:** Specify quantity before adding

### AJAX Handler
**File:** `includes/class-woo-enhancements.php` (lines 207-238)
**Action:** `wp_ajax_sf_add_to_cart_archive`
**Returns:** Cart count, total, success message

### Implementation
```javascript
// JavaScript event triggered after add to cart
document.addEventListener('added_to_cart', function() {
  // Update UI, show notification, etc.
});
```

---

## Product Image Zoom

### Features
- **Interactive Zoom:** Hover to zoom on product image
- **Large View:** Display full-resolution image
- **Mobile Support:** Touch-friendly zoom controls
- **Performance:** Lazy-loaded high-res images

### AJAX Handler
**File:** `includes/class-woo-enhancements.php` (lines 240-260)
**Action:** `wp_ajax_sf_product_image_zoom`
**Returns:** Full-resolution image URL

### Usage
Zoom is automatically enabled for all product images via theme JavaScript.

---

## Wishlist Support

### Features
- **Archive Wishlist Button:** Add products from shop
- **Single Product Wishlist:** Add from product page
- **Heart Icon:** Visual wishlist indicator
- **Ajax Integration:** Add without page reload
- **Hooks Available:** For custom wishlist plugins

### Wishlist Integration Points
```php
// Hook for custom wishlist functionality
add_action( 'sf_wishlist_add_item', function( $product_id ) {
  // Custom wishlist logic
});

// Hook for wishlist button styling
add_filter( 'sf_wishlist_button_class', function( $class ) {
  return $class . ' custom-class';
});
```

### Supported Plugins
- **YITH WooCommerce Wishlist**
- **WooCommerce Wishlists**
- **TI WooCommerce Wishlist**

### Button States
- **Default:** Empty heart (♡)
- **Added:** Filled/colored heart (♥)
- **Color:** White text on primary color when added

---

## Size Guide Modal

### Features
- **Product-Specific:** Only shows for sizeable products
- **Modal Display:** Beautiful lightbox presentation
- **Custom Content:** Filterable size guide content
- **Responsive Table:** Mobile-optimized sizing charts

### Default Size Chart
| Size | Chest | Waist | Length |
|------|-------|-------|--------|
| XS   | 32-34" | 24-26" | 27" |
| S    | 34-36" | 26-28" | 28" |
| M    | 38-40" | 30-32" | 29" |
| L    | 42-44" | 34-36" | 30" |
| XL   | 46-48" | 38-40" | 31" |

### Custom Size Guide
```php
// Hook to customize size guide content
add_action( 'sf_size_guide_content', function() {
  ?>
  <p>Custom size guide content here</p>
  <?php
});
```

### Implementation
- Auto-detects products with size attributes
- Shows button only when size attribute exists
- Triggered from single product page
- AJAX modal loading

---

## Cross-Sells & Upsells

### Features
- **Cross-Sells:** Shown on cart page (complementary products)
- **Upsells:** Shown on product page (related premium products)
- **Column Control:** Configurable grid layout
- **Responsive:** Adapts to screen size

### Configuration
```php
'woo_crosssell_columns' => 3   // Grid columns
'woo_upsell_columns' => 3      // Grid columns
```

### Hook Customization
```php
// Filter cross-sells
add_filter( 'woocommerce_cross_sells_columns', function( $columns ) {
  return 4; // 4 columns instead of 3
});

// Filter upsells
add_filter( 'woocommerce_upsells_columns', function( $columns ) {
  return 5;
});
```

---

## Mini-Cart in Header

### Features
- **Always Visible:** Shows in header at all times
- **Hover Dropdown:** Cart contents on hover
- **Item Count:** Badge showing number of items
- **Quick Access:** Cart total visible
- **AJAX Updates:** Updates on add to cart
- **Remove Items:** Quick item deletion

### Display
- Location: Header right side
- Icon: Shopping cart emoji (🛒)
- Count Badge: Red circle with number

### Configuration
```php
'woo_show_mini_cart' => true  // Show/hide mini cart
```

### Cart Contents Include
- Product name and image
- Quantity
- Individual product price
- Remove button
- Cart subtotal
- Checkout button

### Mobile Display
- Width: 100% of screen - 30px
- Positioned absolutely
- Scrollable on small screens

---

## Product Ratings & Reviews

### Features
- **Star Display:** 5-star visual rating system
- **Average Rating:** Shows product rating score
- **Review Count:** Number of reviews
- **Accessible:** Proper markup for screen readers

### Template Tag
```php
// Display product rating
echo starter_flavor_get_product_rating( $product_id );
```

### Rating Display
```html
<div class="product-rating">
  <span class="rating-score">4.5</span>
  <span class="rating-stars">★★★★☆</span>
</div>
```

---

## Single Product Page

### Layout
- **Image Gallery:** Left side (sticky on desktop)
- **Product Details:** Right side
- **Tab Content:** Description, specifications, reviews
- **Related Products:** Below main content
- **Breadcrumb Navigation:** Above title

### Product Meta Information
- SKU (Stock Keeping Unit)
- Categories
- Tags
- Availability

### Add-to-Cart Section
- **Quantity Selector:** +/- buttons
- **Add to Cart Button:** Primary CTA
- **Wishlist Button:** Secondary action
- **Size Guide Button:** If applicable

### Gallery Features
- **Zoom on Hover:** Interactive product image zoom
- **Lightbox:** Click to view full-size
- **Multiple Images:** Thumbnail navigation
- **Mobile Swipe:** Swipe between images

---

## Cart Page Features

### Layout
- **Product List:** Table with images, names, prices
- **Quantity Controls:** +/- buttons for each item
- **Totals Sidebar:** Subtotal, tax, shipping, total
- **Cross-Sells:** Suggested products below cart
- **Actions:** Continue shopping, checkout buttons

### Quantity Controls
- **Increment Button:** (+) increases quantity
- **Decrement Button:** (-) decreases quantity (min 1)
- **Manual Input:** Click to type quantity
- **Auto-Update:** Cart updates on quantity change

### Cart Actions
- **Remove Item:** Delete product from cart
- **Update Cart:** Refresh totals
- **Continue Shopping:** Link to shop
- **Proceed to Checkout:** Next step in purchase

---

## Checkout Page

### Two-Column Layout
- **Left Column:** Billing, shipping, order notes
- **Right Column:** Order review and summary

### Form Sections
1. **Billing Address**
   - First/last name
   - Email
   - Address fields
   - Phone number

2. **Shipping Address** (if applicable)
   - Same address option
   - Different shipping address

3. **Order Notes**
   - Special instructions
   - Delivery notes

### Order Review
- Product list with images
- Individual prices
- Quantity
- Subtotal
- Shipping cost
- Tax
- Total price

### Payment Methods
- Credit card
- PayPal
- Bank transfer
- Custom payment gateways

---

## My Account Page

### Features
- **Account Navigation:** Sidebar menu
- **Dashboard:** Account overview
- **Orders:** Purchase history
- **Addresses:** Saved addresses
- **Account Details:** Profile information
- **Logout:** Sign out option

### Navigation Menu
- Dashboard (default tab)
- Orders
- Downloads
- Addresses
- Account Details
- Logout

### Styling
- Primary color accent
- Responsive layout
- Mobile navigation
- Quick access buttons

---

## WooCommerce Builder

### Features
- **Custom Templates:** Create custom shop page layouts
- **Template Types:** Shop, Single Product, Cart, Checkout, Account, Thank You
- **Elementor Integration:** Design with Elementor
- **Activation Toggle:** Enable/disable per template type

### Location
**Admin Menu:** Appearance > WooCommerce Builder

### Template Management
```php
// Get template by type
$template = Starter_Flavor_Woo_Builder::get_template_by_type( 'shop' );

// Get all templates
$templates = Starter_Flavor_Woo_Builder::get_templates();
```

### Available Template Types
| Type | Purpose | Default |
|------|---------|---------|
| shop | Product archive/listing | WooCommerce default |
| single | Single product page | WooCommerce default |
| cart | Shopping cart page | WooCommerce default |
| checkout | Checkout form | WooCommerce default |
| account | My account pages | WooCommerce default |
| thankyou | Order confirmation | WooCommerce default |

---

## Color & Styling Customization

### CSS Variables
```css
--color-primary: #FF5E2E      /* Sale badges, buttons, links */
--color-secondary: #1F242E    /* Hover states, text */
```

### Key Classes
```css
.woocommerce-page          /* Main wrapper */
.products                   /* Product grid */
.product                    /* Individual product card */
.product-badge              /* Badge styling */
.quick-view-button          /* Quick view button */
.wishlist-button            /* Wishlist button */
.add_to_cart_button         /* Add to cart button */
.woocommerce-product-title  /* Product title */
.price                      /* Price display */
```

### Customization Example
```css
/* Override product card border */
.product {
  border: 2px solid var(--color-primary);
  border-radius: 8px;
}

/* Custom badge styling */
.product-badge-sale {
  background: linear-gradient(135deg, #FF5E2E, #e74c3c);
  border-radius: 50%;
  width: 50px;
  height: 50px;
  display: flex;
  align-items: center;
  justify-content: center;
}
```

---

## Theme Options Reference

### Shop Page
```php
'woo_show_sidebar' => true          // Show/hide sidebar
'woo_products_per_page' => 12       // Items per page
'woo_shop_columns' => 3             // Grid columns (2-6)
'woo_product_layout' => 'grid'      // 'grid' or 'list'
'woo_badge_type' => 'percentage'    // 'text' or 'percentage'
```

### Product Display
```php
'woo_show_new_badge' => true        // Show new badge
'woo_new_badge_days' => 14          // Days for new badge
'woo_show_hot_badge' => false       // Show hot/bestseller badge
'woo_hot_badge_threshold' => 50     // Sales threshold
'woo_show_stock_badge' => true      // Show out of stock badge
```

### Features
```php
'woo_show_quick_view' => true       // Quick view button
'woo_show_wishlist' => false        // Wishlist button
'woo_show_mini_cart' => true        // Header mini cart
'woo_show_crosssell' => true        // Cart cross-sells
```

### Cross-Sells/Upsells
```php
'woo_crosssell_columns' => 3        // Cross-sell columns
'woo_upsell_columns' => 3           // Upsell columns
```

---

## Performance Considerations

### Image Optimization
- Use responsive images with srcset
- Compress product images (WebP + JPEG)
- Lazy load product images
- Optimize product gallery images

### Database Queries
- Enable object caching (Redis/Memcached)
- Remove old cart data
- Clean up product variations
- Archive old orders

### JavaScript Optimization
- Deferred script loading
- Minimal JavaScript on shop page
- Lazy load wishlist functionality
- Cache AJAX responses

---

## Developer Hooks

### Action Hooks
```php
// Size guide content
do_action( 'sf_size_guide_content' );

// Wishlist add item
do_action( 'sf_wishlist_add_item', $product_id );

// After quick view loaded
do_action( 'sf_quick_view_loaded', $product_id );
```

### Filter Hooks
```php
// Wishlist button class
apply_filters( 'sf_wishlist_button_class', $class );

// Size guide content
apply_filters( 'sf_size_guide_content', $content );

// Cross-sells columns
apply_filters( 'woocommerce_cross_sells_columns', $columns );
```

---

## Troubleshooting

### Quick View Not Working
1. Check AJAX URL is correct
2. Verify nonce is valid
3. Check JavaScript console for errors
4. Ensure WooCommerce is activated

### Mini Cart Not Updating
1. Verify AJAX is enabled
2. Check server error logs
3. Ensure cart fragments are loading
4. Disable conflicting plugins

### Wishlist Not Displaying
1. Check theme options (woo_show_wishlist)
2. Verify buttons are in correct hooks
3. Check if wishlist plugin is active
4. Verify button styling isn't hidden

### Performance Issues
1. Optimize product images
2. Enable caching plugins
3. Use CDN for static assets
4. Minimize JavaScript

---

## Best Practices

1. **Image Optimization**
   - Compress all product images
   - Use WebP format when possible
   - Set proper image dimensions
   - Use responsive images

2. **Performance**
   - Enable browser caching
   - Use a caching plugin
   - Minimize database queries
   - Lazy load images

3. **SEO**
   - Write descriptive product titles
   - Use proper product descriptions
   - Add product images with alt text
   - Configure breadcrumbs

4. **Security**
   - Keep WooCommerce updated
   - Use SSL/TLS certificate
   - Secure checkout page
   - Validate user input

5. **User Experience**
   - Clear product information
   - High-quality product images
   - Easy checkout process
   - Mobile optimization

---

## Additional Resources

- [WooCommerce Documentation](https://docs.woocommerce.com/)
- [WooCommerce Code Snippets](https://docs.woocommerce.com/document/snippet-library/)
- [WooCommerce Hooks Reference](https://docs.woocommerce.com/document/hooks/)
- [WooCommerce REST API](https://woocommerce.github.io/woocommerce-rest-api-docs/)

