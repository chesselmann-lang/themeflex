# ADR-001: AI Provider Abstraction via Interface + Factory

**Status:** Accepted  
**Date:** 2026-05-01  
**Decider:** Christian Hesselmann / Claude (Technical Lead)

---

## Context

ThemeFlex v3 used a hardcoded OpenAI-only AI assistant (`class-ai-assistant.php`).  
ThemeFlex v4.0 must support Anthropic Claude, OpenAI GPT, and Google Gemini  
without requiring users to use a specific provider.

## Decision

Introduce `ThemeFlex_AI_Provider` interface with four methods:  
`chat()`, `embed()`, `get_name()`, `validate_key()`.

Each provider has its own adapter class implementing the interface:
- `ThemeFlex_Provider_Anthropic` — default provider
- `ThemeFlex_Provider_OpenAI`
- `ThemeFlex_Provider_Gemini`

`ThemeFlex_Provider_Factory` reads the active provider from `wp_options` and returns  
the correct adapter. All consuming code (RAG endpoint, chat endpoint) calls the factory.

## Consequences

**Positive:**
- Provider switching requires zero code changes — only wp_options update
- ThemeForest review: no vendor lock-in, user brings own key
- Upgrade path: adding a fourth provider (e.g. Mistral) = one new adapter class

**Negative:**
- `embed()` returns `[]` for Anthropic (no public embedding endpoint) → TF-IDF fallback required
- Legacy `class-ai-assistant.php` kept as compatibility layer — dual-registration risk mitigated by file guards in `functions.php`

## Alternatives Considered

1. **Single class with provider switch** — rejected: spaghetti code, impossible to test providers in isolation
2. **External plugin dependency** — rejected: ThemeForest rules prohibit required external plugins
