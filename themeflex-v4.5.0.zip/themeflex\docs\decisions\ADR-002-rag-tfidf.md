# ADR-002: RAG-Backend via TF-IDF (no external embedding API)

**Status:** Accepted  
**Date:** 2026-05-01  
**Decider:** Christian Hesselmann / Claude (Technical Lead)

---

## Context

The RAG chatbot requires a similarity search over page content.  
Options considered: (a) real embedding vectors via OpenAI/Anthropic API,  
(b) SQLite + sqlite-vec, (c) TF-IDF in PHP stored as JSON.

## Decision

Use **TF-IDF cosine similarity in pure PHP** stored in `uploads/themeflex-rag/index.json`.

- No external embedding API call during indexing
- No Composer dependency
- No SQLite extension requirement (not guaranteed on shared hosting)
- Index stored as JSON file in WP uploads directory (backed up automatically)

## Consequences

**Positive:**
- Zero cost at index time
- Works on any standard WordPress hosting (PHP 8.2+)
- Upgrade path documented: if provider supports `embed()`, real vectors stored alongside TF-IDF vectors; v4.1 can switch retrieval without re-indexing schema change

**Negative:**
- RAG quality lower than real embeddings for semantic similarity
- German language handling requires stop-word list (implemented in `class-rag-indexer.php`)
- Large sites (>500 pages) may see slow index writes — mitigated by 50-posts-per-page pagination

## Upgrade Path (v4.1)

When Anthropic releases a public embedding endpoint or when user has OpenAI key,  
`ThemeFlex_RAG_Indexer::index_chunk()` calls `$provider->embed()` and stores the vector.  
`ThemeFlex_RAG_Retriever` prefers vector similarity over TF-IDF if vectors exist.

## Alternatives Considered

1. **sqlite-vec** — rejected: not available on Mittwald shared hosting; adds SQLite extension requirement
2. **OpenAI embeddings** — rejected: creates API cost at index time; violates "user-brings-own-key" principle
3. **Files with pre-computed embeddings bundled** — rejected: legally and practically not feasible for user content
