# ADR-003: AVV PDF Generation via FPDF (standalone, no Composer)

**Status:** Accepted  
**Date:** 2026-05-01  
**Decider:** Christian Hesselmann / Claude (Technical Lead)

---

## Context

The DSGVO AVV Generator (Art. 28 GDPR) must produce a downloadable PDF.  
ThemeForest prohibits required external services. Composer introduces complexity  
for theme distribution (ZIP must be self-contained).

## Decision

Bundle **FPDF** (fpdf.org) as a standalone library in `inc/fpdf/`.  
No Composer, no external service, no runtime download.

FPDF is MIT-compatible (permissive license), self-contained PHP, no dependencies.

## Consequences

**Positive:**
- ZIP-distributable without Composer install step
- No runtime internet requirement
- ~200 KB library size — acceptable for a premium theme bundle

**Negative:**
- FPDF supports ISO-8859-1 natively; UTF-8 content must be converted via `mb_convert_encoding()`
  → handled in `ThemeFlex_AVV_Generator::latin1()` helper
- FPDF v1.x — not actively developed; Unicode support via tFPDF extension if needed in v4.1

## Alternatives Considered

1. **dompdf** — rejected: requires Composer; large dependency tree; complex setup for end users
2. **TCPDF** — rejected: 30+ MB library; too large for theme ZIP
3. **External PDF API** — rejected: privacy/DSGVO concern; requires internet at generation time
