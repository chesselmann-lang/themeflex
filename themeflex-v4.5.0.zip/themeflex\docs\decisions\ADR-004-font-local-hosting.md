# ADR-004: Google Fonts Local Hosting via wp_remote_get + WP-Cron

**Status:** Accepted  
**Date:** 2026-05-01  
**Decider:** Christian Hesselmann / Claude (Technical Lead)

---

## Context

DSGVO requires no data transfer to third-party servers without consent.  
Google Fonts loads from `fonts.googleapis.com` → German court rulings classify this as DSGVO violation.  
The solution must be automatic (no manual font upload) and survive skin changes.

## Decision

`ThemeFlex_Font_Local_Host` hooks into the skin-change action and:
1. Fetches Google Fonts CSS via `wp_remote_get()` (server-to-server, no user data leaked)
2. Extracts `@font-face` URLs from the CSS
3. Downloads font files into `wp-content/uploads/themeflex-fonts/`
4. Writes a local CSS file referencing those local files
5. Theme enqueues local CSS file instead of fonts.googleapis.com

A WP-Cron event `themeflex_download_fonts_event` handles async download if the skin-change  
hook fires during a page request.

## Consequences

**Positive:**
- Zero user data sent to Google during font delivery
- Fully automatic — no manual upload
- Fallback: if download fails, reverts to googleapis.com + shows Admin notice

**Negative:**
- Mittwald firewall may block outbound `wp_remote_get` to googleapis.com — must test on live
- Font files add to uploads storage (typically 50–200 KB per font family)
- Fonts could become outdated if Google updates them — scheduled re-download every 30 days (WP-Cron)

## Alternatives Considered

1. **Bundle fonts with theme ZIP** — rejected: fonts are large (5+ MB for all skins); ZIP would exceed ThemeForest size limit
2. **Plugin like OMGF** — rejected: additional plugin dependency, not self-contained
3. **user manually downloads** — rejected: UX friction, defeats Premium-Theme value proposition
