# Sprint 10 — Integration + Full-Audit + ZIP v4.0.0

**Status:** AKTIV  
**Gestartet:** 2026-05-01  
**Ziel:** Alle Sprints validiert, Lücken geschlossen, Release-Package bereit.

---

## Kontext

Sprints 01–09 sind vollständig implementiert (Code-Inspektion 2026-05-01).  
Sprint 10 konsolidiert, auditiert und erstellt das Release.

---

## Zu ändernde / erstellende Dateien

| Datei | Aktion |
|---|---|
| `includes/class-ai-assistant.php` | PHPDoc-Header aktualisieren (Zeilen 1–10) |
| `docs/decisions/ADR-001-provider-abstraction.md` | ✅ angelegt |
| `docs/decisions/ADR-002-rag-tfidf.md` | ✅ angelegt |
| `docs/decisions/ADR-003-fpdf-standalone.md` | ✅ angelegt |
| `docs/decisions/ADR-004-font-local-hosting.md` | ✅ angelegt |
| `THEMEFLEX-V3-STATUS.md` | anlegen (historischer Snapshot) |
| `docs/v4-baseline.md` | ✅ aktualisiert |
| `docs/v4-roadmap.md` | ✅ aktualisiert |
| `README.txt` | v4.0.0 Feature-Beschreibung ergänzen |
| `changelog.txt` | v4.0.0-Eintrag |
| `reports/latest.md` | Status-Report anlegen |
| `themeflex-v4.0.0.zip` | Release-ZIP (nach GO) |

---

## Akzeptanzkriterien

### Code-Qualität
- [x] PHP-Syntax-Check: 392 Dateien, 0 Fehler (2026-05-01)
- [ ] WPCS-Check über includes/ai/ (sofern phpcs verfügbar)
- [ ] class-ai-assistant.php PHPDoc auf v4 aktualisiert

### Template-Audit
- [x] 108/114 Templates strukturell valide (DOCTYPE, get_header/footer, Template-Name, kein wp_head/footer)
- [ ] Klärung 6 borderline-Templates (50.301–50.778 Byte vs. ThemeForest-50KB-Regel)

### Funktionstest P0.1 (RAG-Chatbot)
- [ ] Widget erscheint auf Frontend, öffnet/schließt korrekt
- [ ] Indexer läuft ohne Fatal Error
- [ ] Chat-Antwort enthält Site-Content (RAG nachweisbar)
- [ ] Ohne Consent: kein API-Call
- [ ] Admin-Panel "ThemeFlex → AI-Chat" sichtbar + Re-Index-Button funktioniert

### Funktionstest P0.2 (Demo-Importer)
- [x] mapping.json: 19 Kategorien, 114 Templates ✓
- [ ] Wizard öffnet nach Theme-Aktivierung
- [ ] Import legt Pages an, weist Templates zu
- [ ] Undo-Funktion funktioniert

### Funktionstest P0.3 (DSGVO-Stack)
- [ ] Cookie-Banner: 4 Kategorien inkl. "AI-Funktionen"
- [ ] Google Fonts lokal nach Skin-Wechsel (Network-Tab)
- [ ] `[themeflex_impressum]` und `[themeflex_datenschutz]` geben Output
- [ ] Honeypot blockiert Bot-POST
- [ ] AVV-PDF generierbar + herunterladbar

### Performance
- [ ] debug.log: 0 Einträge über 8 Hauptseiten
- [ ] Lighthouse mobile ≥ 95 (Chat-Widget darf Score nicht senken)

### Release
- [ ] README.txt aktualisiert
- [ ] changelog.txt v4.0.0-Eintrag
- [ ] Git-Commit (lokal)
- [ ] ZIP erstellt
- [ ] Deploy-Frage an Christian ← BESTÄTIGUNGSPFLICHTIG

---

## Abhängigkeiten

Keine technischen Blocker. Live-Tests (debug.log, Lighthouse, Funktionstest) erfordern laufende WP-Instanz.
