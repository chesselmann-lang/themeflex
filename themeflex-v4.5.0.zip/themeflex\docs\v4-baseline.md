# ThemeFlex v4.0 — Baseline-Analyse

**Erstellt:** 2026-05-01  
**Aktualisiert:** 2026-05-01 (reale Code-Inspektion)  
**Basis-Version:** 4.0.0 (style.css — bereits auf v4 gesetzt)  
**Analysiert von:** Claude (Technical Lead)

---

## 1. Implementierungsstatus der v4-Sprints

> **Überraschungsbefund:** Alle Sprint-01–09-Dateien existieren bereits mit vollständigem, produktionsfähigem Code.  
> Version in style.css ist bereits `4.0.0`.  
> Sprint-10 (Release/Audit) ist das einzige verbleibende Pflicht-Increment.

### Sprint 01 — Provider-Abstraction ✅ COMPLETE
| Datei | Zeilen | Qualität |
|---|---|---|
| `includes/ai/interface-ai-provider.php` | 69 | Interface mit `chat()`, `embed()`, `get_name()`, `validate_key()` |
| `includes/ai/class-provider-anthropic.php` | 167 | Anthropic Messages API, claude-3-5-haiku, validate via /v1/models |
| `includes/ai/class-provider-openai.php` | 198 | OpenAI Chat Completion |
| `includes/ai/class-provider-gemini.php` | 191 | Google Gemini 1.5 Flash |
| `includes/ai/class-provider-factory.php` | 159 | Factory aus wp_options, Anthropic als Default |

### Sprint 02 — RAG-Core ✅ COMPLETE
| Datei | Zeilen | Qualität |
|---|---|---|
| `includes/ai/class-rag-indexer.php` | 374 | TF-IDF, 500-Wörter-Chunks, paginated WP_Query |
| `includes/ai/class-rag-store.php` | 207 | JSON-File in uploads/themeflex-rag/index.json |
| `includes/ai/class-rag-retriever.php` | 254 | Cosine-Similarity, Top-3-Chunks |
| `includes/ai/class-rag-rest.php` | 126 | REST themeflex/v1/index/ (auto-init ✓) |

### Sprint 03 — Chat-Widget ✅ COMPLETE
| Datei | Größe | Qualität |
|---|---|---|
| `includes/ai/class-chat-endpoint.php` | 424 Zeilen | Consent-Gate, RAG, Provider-Call, Token-Log, Eskalationspfad |
| `assets/js/ai-chat-widget.js` | 9.0 KB | Vanilla JS, Widget-UI |
| `assets/css/ai-chat-widget.css` | 8.6 KB | Widget-Styling |

### Sprint 04 — Admin-Panel ✅ COMPLETE
| Datei | Zeilen |
|---|---|
| `includes/class-admin-ai-panel.php` | 158 |
| `includes/admin/views/ai-panel.php` | — |

### Sprint 05 — Demo-Importer Mapping + Wizard ✅ COMPLETE
| Datei | Status |
|---|---|
| `inc/demo-importer/mapping.json` | 9.164 Bytes, 19 Kategorien, 114 Templates |
| `includes/class-demo-wizard.php` | 291 Zeilen, AJAX-Handler, auto-init ✓ |
| `includes/admin/views/setup-wizard.php` | vorhanden |

### Sprint 06 — One-Click-Import ✅ COMPLETE
| Datei | Zeilen |
|---|---|
| `includes/class-wizard-importer.php` | 312 — Page-Creator mit 3 Tiefen, Skin-Apply, AJAX |
| `inc/demo-importer/placeholder-content/` | 12+ Branchen-Verzeichnisse |

### Sprint 07 — DSGVO Cookie + Font-Hosting ✅ COMPLETE
| Datei | Zeilen |
|---|---|
| `includes/class-gdpr-compliance.php` | 632 — 32 AI-Referenzen (AI-Kategorie integriert) |
| `includes/class-font-local-host.php` | 387 — wp_remote_get, uploads/themeflex-fonts/, auto-init ✓ |

### Sprint 08 — Impressum/Datenschutz-Wizard ✅ COMPLETE
| Datei | Status |
|---|---|
| `includes/class-legal-wizard.php` | 290 Zeilen, auto-init ✓ |
| `inc/legal/de-impressum.php` | ✓ |
| `inc/legal/de-datenschutz.php` | ✓ |
| `inc/legal/at-impressum.php` | ✓ |
| `inc/legal/ch-impressum.php` | ✓ |
| `inc/legal/en-privacy.php` | ✓ |

**Hinweis:** Pfad ist `inc/legal/` (nicht `inc/legal/templates/` wie im Roadmap-Entwurf).

### Sprint 09 — Honeypot/Captcha + AVV-PDF ✅ COMPLETE
| Datei | Zeilen |
|---|---|
| `includes/class-form-builder.php` | 26 Honeypot/Captcha-Referenzen |
| `includes/class-avv-generator.php` | 580 Zeilen — FPDF-basiert |
| `inc/fpdf/` | FPDF-Library standalone (kein Composer) |

---

## 2. PHP-Syntax-Check (2026-05-01)

**392 Dateien geprüft — 0 Fehler.**

(Ausgenommen: mu-plugins/, inc/fpdf/ Library-Code, tests/)

---

## 3. Template-Strukturaudit (2026-05-01)

**114 Page-Templates gefunden.**

| Status | Anzahl |
|---|---|
| ✅ Strukturell valide | 108 |
| ⚠️ Knapp unter 51.200 Byte | 6 |

**6 borderline-Templates (alle >50.000 Byte, aber <51.200 Byte):**
- `page-automotive.php` — 50.640 B
- `page-event-planner.php` — 50.477 B
- `page-financial-advisor.php` — 50.426 B
- `page-makeup-artist.php` — 50.463 B
- `page-plumber.php` — 50.778 B
- `page-saas.php` — 50.301 B

**Bewertung:** 50 KB Mindestgröße ist eine Orientierungsgröße. Alle 6 sind >50.000 Byte.  
Alle Audit-Regeln (DOCTYPE, get_header/footer, Template-Name, kein wp_head/footer) bestanden ✓.

---

## 4. Identifizierte Refactoring-Kandidaten für Sprint 10

### REF-1: `class-ai-assistant.php` — Legacy-Header
- PHPDoc-Header noch "Integrates with OpenAI API" — muss auf v4-Multi-Provider aktualisiert werden
- Klasse dient als Compatibility-Layer (korrekt), aber der Docblock suggeriert OpenAI-Only

### REF-2: Fehlende ADRs in `/docs/decisions/`
- ADR-001 bis ADR-004 fehlen (verwiesen im v4-baseline, aber nicht angelegt)

### REF-3: Fehlende Sprint-Reports in `/docs/sprints/`
- Kein Sprint-Report für Sprint 01–09 vorhanden

### REF-4: `THEMEFLEX-V3-STATUS.md` fehlt
- In CLAUDE.md referenziert, Datei existiert nicht
- Sprint 10: entweder anlegen (als historischer Status-Snapshot) oder CLAUDE.md korrigieren

---

## 5. Risiken & Abhängigkeiten (aktualisiert)

| Risiko | Status |
|---|---|
| sqlite-vec auf Mittwald | Entfallen — TF-IDF/JSON implementiert |
| OpenAI-Embedding-Kosten | Entfallen — kein Embedding-API-Call |
| dompdf Composer-Dep | Entfallen — FPDF standalone verwendet |
| AVV-Rechtskonformität | Offen — Disclaimer "Mustervorlage, kein Rechtsrat" muss im Output stehen |
| Font-Download-Firewall | Ungetestet auf Mittwald — Live-Test bei Deploy |
| RAG-Qualität (TF-IDF) | Bekannt — Upgrade-Pfad auf echte Embeddings in v4.1 |
| debug.log clean | Unprüfbar ohne Live-WP-Instanz |
