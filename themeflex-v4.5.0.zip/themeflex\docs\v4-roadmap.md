# ThemeFlex v4.0 — Sprint-Roadmap

**Erstellt:** 2026-05-01  
**Aktualisiert:** 2026-05-01 (nach realer Code-Inspektion)  
**Release-Ziel:** ThemeFlex v4.0.0  
**Basis:** v3.2.0 → v4.0.0 (alle Sprint-01–09 bereits implementiert)

---

## Status-Übersicht

| Sprint | Ziel | Status | Dauer |
|---|---|---|---|
| Sprint 01 | Provider-Abstraction + Anthropic | ✅ DONE | — |
| Sprint 02 | RAG-Core: Indexer + Vector-Store (TF-IDF) | ✅ DONE | — |
| Sprint 03 | Chat-Widget: Frontend + Consent-Gate | ✅ DONE | — |
| Sprint 04 | Admin-Panel: AI-Chat-Verwaltung | ✅ DONE | — |
| Sprint 05 | Demo-Importer: mapping.json + Branchen-Wizard | ✅ DONE | — |
| Sprint 06 | Demo-Importer: One-Click-Import + Platzhaltertexte | ✅ DONE | — |
| Sprint 07 | DSGVO: Cookie AI-Kategorie + Font-Local-Hosting | ✅ DONE | — |
| Sprint 08 | DSGVO: Impressum/Datenschutz-Wizard + Shortcodes | ✅ DONE | — |
| Sprint 09 | DSGVO: Honeypot/Math-Captcha + AVV-PDF-Generator | ✅ DONE | — |
| **Sprint 10** | **Integration + Full-Audit + ZIP v4.0.0** | **🔄 AKTIV** | 1 Tag |

---

## Sprint 10 — Integration + Full-Audit + Release ZIP

**Ziel:** Alle Sprints validieren, Lücken schließen, Release-Package erstellen.

### Phase 1 — Lücken schließen

**10.1 — class-ai-assistant.php PHPDoc aktualisieren**
- [ ] Header-Kommentar auf Multi-Provider aktualisieren (v4.0, Anthropic default)
- Datei: `includes/class-ai-assistant.php` Zeilen 1–10

**10.2 — ADRs anlegen** (`/docs/decisions/`)
- [ ] `ADR-001-provider-abstraction.md` — Interface + Factory Pattern
- [ ] `ADR-002-rag-tfidf.md` — TF-IDF statt externer Embeddings-API
- [ ] `ADR-003-fpdf-standalone.md` — FPDF ohne Composer
- [ ] `ADR-004-font-local-hosting.md` — wp_remote_get + WP-Cron

**10.3 — THEMEFLEX-V3-STATUS.md anlegen**
- [ ] Historischer Status-Snapshot v3.2 (referenziert in CLAUDE.md)

**10.4 — Borderline-Templates prüfen**
- [ ] 6 Templates (50.301–50.778 Byte) gegen ThemeForest-Submission-FAQ klären
  - Wenn ">50 KB" = "≥50.000 Byte": alle 6 ✅
  - Wenn ">50 KB" = "≥51.200 Byte": Content-Erweiterung nötig

### Phase 2 — Vollständiger Audit

**PHP-Syntax-Check:** 392 Dateien, 0 Fehler ✅ (bereits erledigt)

**Strukturaudit Templates:**
- [ ] Automatisierter Check über alle 114 Templates (Script in tools/)
- 108/114 ✅ bestätigt; 6 borderline (Größe)

**WPCS-Check:**
- [ ] `phpcs --standard=WordPress includes/ai/ includes/class-*.php` sofern phpcs verfügbar

**Funktionstest Akzeptanzkriterien P0.1–P0.3:**
- [ ] Chat-Widget öffnet/schließt ✓ (Frontend-Test)
- [ ] Consent-Gate blockiert API-Call ohne Cookie ✓ (Network-Tab)
- [ ] RAG-Antwort enthält Site-Content ✓ (debug-Mode)
- [ ] Indexer läuft ohne Fatal ✓
- [ ] Admin-Panel "ThemeFlex → AI-Chat" sichtbar ✓
- [ ] Wizard öffnet nach Aktivierung ✓
- [ ] mapping.json deckt 114 Templates ✅ (verifiziert: 19 Kategorien, 114 Templates)
- [ ] Import erstellt Pages ohne Fatal ✓
- [ ] Cookie-Banner: 4 Kategorien inkl. "AI-Funktionen" ✓
- [ ] Google Fonts lokal nach Skin-Wechsel ✓
- [ ] `[themeflex_impressum]` Shortcode-Output ✓
- [ ] Honeypot blockiert Bot-POST ✓
- [ ] AVV-PDF generiert + downloadbar ✓

**debug.log-Check:**
- [ ] WP lokal starten, 8 Hauptseiten aufrufen, debug.log prüfen

**Lighthouse:**
- [ ] Mobile ≥ 95 auf Homepage (Chat-Widget darf Score nicht senken)

### Phase 3 — Dokumentation

- [ ] `README.txt` auf v4.0.0 aktualisieren (neue Features auflisten)
- [ ] `CHANGELOG.md` oder `changelog.txt` — v4.0.0-Eintrag
- [ ] Sprint-Reports `docs/sprints/sprint-01-09-summary.md` (retroaktiv)
- [ ] `reports/latest.md` aktualisieren

### Phase 4 — Release

- [ ] Git-Commit mit `feat: ThemeFlex v4.0.0 — AI RAG Chatbot, Demo-Importer, DSGVO-Stack`
- [ ] `themeflex-v4.0.0.zip` erstellen (alle neuen Dateien inklusive)
- [ ] Frage an Christian: "Deploy auf themeflex.de?" ← BESTÄTIGUNGSPFLICHTIG

---

## Sprint-Abhängigkeitsgraph (archiviert)

```
Sprint 01 (Provider)
    ├── Sprint 02 (RAG)
    │       ├── Sprint 03 (Widget) → Sprint 04 (Admin-Panel)
    │       └── Sprint 07 (Font-Hosting)
    └── Sprint 05 (Mapping) → Sprint 06 (Import)

Sprint 08 (Wizard) → Sprint 09 (AVV)

Sprint 10 (Release) ← alle vorherigen ✅
```

---

## P1-Backlog (nach v4.0)

- Anthropic als sichtbarer Default im Provider-Dropdown (UI-Label-Update)
- Multi-Provider-Switcher gleichwertige Labels in Admin
- Skin-Preview im Customizer ohne Page-Reload
- Template-Vorschau-Seite (Screenshot-Grid)

## P2-Backlog (v4.1)

- WooCommerce-Checkout-Optimierung
- Schema.org-Auto-Output pro Branche
- Lighthouse CI in GitHub Actions (nach Task #36)
- Multilingual (WPML/Polylang) Wizard
- Echte Embeddings (OpenAI/Anthropic) als RAG-Upgrade
