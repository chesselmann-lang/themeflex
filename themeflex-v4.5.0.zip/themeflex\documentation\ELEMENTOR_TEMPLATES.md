# Elementor Template Library System

The ThemeFlex WordPress theme includes a comprehensive Elementor Template Library System with 15 pre-built page templates that users can import with a single click.

## Features

### 1. Template Library Management
- **Admin Dashboard**: Navigate to **Appearance → Elementor Templates** to browse all available templates
- **Visual Grid**: Templates are displayed in an organized, categorized grid
- **One-Click Import**: Import any template with a single button click
- **Live Preview**: Preview templates before importing them
- **Modal Interface**: Full preview modal with template details

### 2. Available Templates (15 Total)

#### Homepage Templates (3)
1. **Corporate Homepage** (`homepage-corporate.json`)
   - Professional business/agency layout
   - Hero section with CTA
   - Services grid (3 columns)
   - Counter statistics
   - Testimonials carousel
   - Team section
   - Call-to-action banner
   - Blog posts preview

2. **Creative Homepage** (`homepage-creative.json`)
   - Full-screen hero with visual impact
   - Portfolio gallery showcase
   - About section with image
   - Skills/Progress bars
   - Testimonials section
   - Modern, design-focused layout

3. **Shop Homepage** (`homepage-shop.json`)
   - Hero image slider
   - Featured products section
   - Category grid
   - Flash sale countdown timer
   - Customer testimonials
   - Newsletter subscription CTA

#### Inner Page Templates (10)

4. **About Us** (`about-us.json`)
   - Hero header
   - Company story with image
   - Counter statistics
   - Team member showcase
   - Core values/culture section

5. **Services** (`services.json`)
   - Services hero section
   - 6-column service cards
   - Icon integration
   - Professional layout

6. **Contact** (`contact.json`)
   - Contact information sidebar
   - Embedded map
   - Contact form placeholder
   - Office hours display
   - Phone/email/address

7. **Portfolio Grid** (`portfolio-grid.json`)
   - Filterable portfolio gallery
   - Masonry layout
   - Category filter buttons
   - Lightbox integration ready

8. **Portfolio Single** (`portfolio-single.json`)
   - Project hero image
   - Full project description
   - Gallery section
   - Project details sidebar
   - Related projects link

9. **Blog Page** (`blog-page.json`)
   - Blog hero section
   - Featured blog carousel
   - Blog grid layout
   - Newsletter subscription CTA

10. **Pricing** (`pricing.json`)
    - Pricing hero
    - 3-tier pricing cards
    - Feature comparison
    - Call-to-action buttons

11. **FAQ** (`faq.json`)
    - FAQ hero section
    - Accordion-based questions
    - Categorized FAQs
    - Contact CTA

12. **Team** (`team.json`)
    - Team showcase hero
    - Team member grid
    - Social links per member
    - Company culture section

#### Special Pages (2)

13. **Coming Soon** (`coming-soon.json`)
    - Full-screen layout
    - Countdown timer
    - Email subscription form
    - Social media links
    - Maintenance mode compatible

#### Landing Pages (2)

14. **SaaS Landing** (`landing-saas.json`)
    - App mockup hero
    - Feature highlights
    - How it works section
    - Pricing tiers
    - Testimonials
    - Download CTA

15. **App Landing** (`landing-app.json`)
    - App hero with phone mockup
    - Feature list
    - Screenshots slider
    - App store download buttons
    - User reviews

## How to Use

### Importing a Template

1. **Via Admin Panel**:
   - Go to **Appearance → Elementor Templates**
   - Browse templates organized by category
   - Click **Import Template** on any template card
   - The template will be created as a new draft page
   - You'll be redirected to edit it in Elementor

2. **Via Elementor Editor**:
   - Create a new page
   - Click "Add Template" in Elementor
   - Go to "My Templates" / "ThemeFlex Templates" tab
   - Select and import desired template

### Customizing Imported Templates

After importing a template:

1. **Edit in Elementor**:
   - Use Elementor's visual editor to customize content
   - Replace placeholder text with your content
   - Update images and colors
   - Adjust layout as needed

2. **Change Colors**:
   - Use theme CSS variables or Elementor color controls
   - Customize buttons, headings, and accents
   - Apply to entire sections or individual elements

3. **Replace Images**:
   - Click on image elements
   - Upload your own images or select from media library
   - Use Featured Image if available

4. **Add Your Widgets**:
   - Insert custom widgets from ThemeFlex collection
   - Add Contact Form 7 or MetForm forms
   - Integrate WooCommerce products
   - Add blog carousels and galleries

## Elementor Template Source

The templates are registered as a custom Elementor Template Source:
- **Source ID**: `themeflex`
- **Source Name**: "ThemeFlex Templates"
- **Location**: `/elementor-templates/`

### Template Metadata

Each template includes:
- **Title**: Human-readable template name
- **Description**: Brief overview of template purpose
- **Category**: Homepage, Inner Pages, Landing Pages, Special Pages
- **Widgets**: List of widgets used
- **Preview Image**: Visual thumbnail

## File Structure

```
themeflex/
├── elementor-templates/
│   ├── class-template-source.php (Custom Elementor source)
│   ├── homepage-corporate.json
│   ├── homepage-creative.json
│   ├── homepage-shop.json
│   ├── about-us.json
│   ├── services.json
│   ├── contact.json
│   ├── portfolio-grid.json
│   ├── portfolio-single.json
│   ├── blog-page.json
│   ├── pricing.json
│   ├── faq.json
│   ├── team.json
│   ├── coming-soon.json
│   ├── landing-saas.json
│   └── landing-app.json
├── includes/
│   ├── class-elementor-templates.php (Main class)
│   ├── class-portfolio.php (Portfolio CPT)
│   └── class-maintenance-mode.php (Coming Soon/Maintenance)
├── templates/
│   ├── coming-soon.php (Coming soon page template)
│   ├── portfolio.php (Portfolio page template)
│   ├── contact.php (Contact page template)
│   └── faq.php (FAQ page template)
└── assets/
    ├── css/
    │   └── elementor-templates-admin.css
    └── js/
        └── elementor-templates-admin.js
```

## Portfolio Custom Post Type

The theme includes a **Portfolio CPT** (`class-portfolio.php`):

### Features
- Custom "Portfolio" post type with archive support
- "Portfolio Category" taxonomy for filtering
- Admin columns showing image and category
- Metabox for project details:
  - Client name
  - Project URL
  - Project date
  - Gallery images

### Usage
- Create portfolio items from WordPress admin
- Assign categories for filtering
- Use `portfolio.php` template for portfolio archive page

## Maintenance Mode / Coming Soon

The theme includes a **Maintenance Mode** system (`class-maintenance-mode.php`):

### Features
- Enable/disable via Customizer
- Customize title, description, countdown date
- Background image and color options
- Social media links integration
- Contact email for form submissions
- Admin bypass (logged-in admins always see site)
- HTTP 503 status header for search engines
- Admin bar notice when active

### Customizer Settings
Navigate to **Appearance → Customize → Maintenance Mode** to:
- Enable/disable maintenance mode
- Set countdown date
- Customize messaging
- Add social links
- Configure contact email
- Upload background image

## Template JSON Format

Templates follow Elementor's standard JSON format:

```json
{
  "title": "Template Name",
  "type": "page",
  "content": [
    {
      "id": "unique-section-id",
      "elType": "section",
      "settings": {
        "background_background": "classic",
        "background_color": "#ffffff"
      },
      "elements": [
        {
          "id": "unique-column-id",
          "elType": "column",
          "settings": {
            "width": "100"
          },
          "elements": [
            {
              "id": "unique-widget-id",
              "elType": "widget",
              "widgetType": "heading",
              "settings": {
                "title": "Sample Title",
                "header_size": "h1"
              }
            }
          ]
        }
      ]
    }
  ]
}
```

## Custom Widgets Used

Templates utilize ThemeFlex custom widgets:
- `image-gallery` - Grid/masonry gallery
- `blog-carousel` - Blog post carousel
- `slider` - Content slider
- `progress-bar` - Animated progress bars
- `countdown` - Countdown timer
- `social-icons` - Social media links

Plus standard Elementor widgets:
- `heading` - Text headings
- `text-editor` - Text content
- `image` - Images
- `button` - Call-to-action buttons
- `spacer` - Spacing elements
- `divider` - Visual dividers
- `icon` - Icon display
- `icon-list` - Icon lists

## Best Practices

1. **After Import**:
   - Always customize placeholder content
   - Replace demo images with your own
   - Update colors to match your brand
   - Test responsiveness on mobile

2. **SEO**:
   - Update page titles and meta descriptions
   - Add alt text to all images
   - Include relevant keywords in content
   - Set up proper URL structure

3. **Performance**:
   - Optimize images before uploading
   - Use lazy loading for images
   - Minimize number of heavy widgets per page
   - Test page speed after customization

4. **Accessibility**:
   - Use semantic heading hierarchy (H1, H2, H3)
   - Add alt text to all images
   - Ensure sufficient color contrast
   - Test with keyboard navigation

## Troubleshooting

### Template Won't Import
- Ensure Elementor plugin is active and up-to-date
- Check WordPress file permissions on `/elementor-templates/` directory
- Verify template JSON files exist and are valid

### Templates Not Showing in Elementor
- Clear browser cache
- Deactivate and reactivate theme
- Check that Elementor Theme Support is enabled

### Customization Not Working
- Ensure Elementor Pro isn't conflicting
- Try in Elementor's safe mode
- Check console for JavaScript errors

## Support

For issues with templates or customization:
1. Check Elementor documentation
2. Verify theme and plugin versions
3. Test in WordPress default theme
4. Check browser console for errors
5. Contact theme support

## Version Info

- **Theme**: ThemeFlex v1.0.0+
- **Elementor**: 3.0.0+
- **WordPress**: 5.8+
- **PHP**: 7.4+

## License

All templates and code are included with the ThemeFlex theme license.
