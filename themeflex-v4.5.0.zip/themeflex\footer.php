<?php
/**
 * Footer Template — ThemeFlex
 * Dark-first. Four-column layout with brand, navigation, resources, newsletter.
 *
 * @package ThemeFlex
 * @since 1.3.0
 */
?>
					<?php do_action( 'themeflex_after_content' ); ?>
				</main><!-- #site-content -->
			</div><!-- .content_wrap -->
		</div><!-- .page_content_wrap -->

<footer id="site-footer" class="tf-footer" role="contentinfo">
<style>
/* ── Footer — Dark-first ───────────────────────────────────────────── */
.tf-footer{
  background:linear-gradient(180deg,#060217 0%,#04010f 100%);
  border-top:1px solid rgba(255,255,255,.06);
  font-family:'Inter Tight',system-ui,sans-serif;
  --tc:#ff5e2e;--txt:#64748b;--title:#94a3b8;--white:#f1f5f9;
  --border:rgba(255,255,255,.07);
}
/* ── Main footer grid ── */
.tf-footer-main{
  max-width:1220px;margin:0 auto;padding:72px 24px 48px;
  display:grid;
  grid-template-columns:1.6fr 1fr 1fr 1.4fr;
  gap:48px;
}
/* ── Brand column ── */
.tf-footer-brand-name{
  font-size:1.4rem;font-weight:900;color:var(--white);
  text-decoration:none;letter-spacing:-.3px;
  background:linear-gradient(90deg,#fff 0%,#ff5e2e 100%);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
  background-clip:text;
  display:inline-block;margin-bottom:14px;
}
.tf-footer-tagline{font-size:14px;color:var(--txt);line-height:1.75;margin:0 0 24px;max-width:280px}
.tf-footer-social{display:flex;gap:8px;flex-wrap:wrap}
.tf-social-icon{
  display:inline-flex;align-items:center;justify-content:center;
  width:36px;height:36px;border-radius:10px;
  background:rgba(255,255,255,.06);border:1px solid var(--border);
  color:var(--txt);font-size:14px;text-decoration:none;
  transition:all .22s;
}
.tf-social-icon:hover{background:var(--tc);color:#fff;border-color:var(--tc);transform:translateY(-2px)}
/* ── Nav columns ── */
.tf-footer-col h4{
  font-size:11px;font-weight:800;color:var(--white);
  letter-spacing:.14em;text-transform:uppercase;
  margin:0 0 20px;
}
.tf-footer-links{list-style:none;padding:0;margin:0}
.tf-footer-links li{margin-bottom:10px}
.tf-footer-links a{
  font-size:14px;color:var(--txt);text-decoration:none;
  transition:color .2s;display:inline-flex;align-items:center;gap:6px;
}
.tf-footer-links a:hover{color:var(--tc)}
/* ── Newsletter mini-form ── */
.tf-footer-newsletter p{font-size:14px;color:var(--txt);line-height:1.7;margin:0 0 18px}
.tf-footer-form{display:flex;gap:8px;flex-direction:column}
.tf-footer-input{
  padding:11px 16px;border-radius:10px;
  background:rgba(255,255,255,.06);border:1px solid var(--border);
  color:var(--white);font-size:14px;outline:none;
  transition:border-color .2s;
}
.tf-footer-input::placeholder{color:var(--txt)}
.tf-footer-input:focus{border-color:rgba(255,94,46,.5)}
.tf-footer-submit{
  padding:11px 20px;border-radius:10px;border:none;cursor:pointer;
  background:var(--tc);color:#fff;font-size:13px;font-weight:700;
  letter-spacing:.03em;transition:background .2s;
}
.tf-footer-submit:hover{background:#e04e22}
/* ── Badge pills ── */
.tf-footer-badges{display:flex;gap:8px;margin-top:16px;flex-wrap:wrap}
.tf-footer-badge{
  padding:4px 12px;border-radius:20px;font-size:11px;font-weight:700;
  border:1px solid var(--border);color:var(--txt);
}
/* ── Divider ── */
.tf-footer-divider{
  max-width:1220px;margin:0 auto;
  border:none;border-top:1px solid var(--border);
}
/* ── Bottom bar ── */
.tf-footer-bottom{
  max-width:1220px;margin:0 auto;padding:24px 24px;
  display:flex;align-items:center;justify-content:space-between;
  flex-wrap:wrap;gap:16px;
}
.tf-footer-copyright{font-size:13px;color:var(--txt)}
.tf-footer-copyright a{color:var(--txt);text-decoration:none;transition:color .2s}
.tf-footer-copyright a:hover{color:var(--tc)}
.tf-footer-nav{display:flex;gap:20px;list-style:none;padding:0;margin:0}
.tf-footer-nav a{font-size:13px;color:var(--txt);text-decoration:none;transition:color .2s}
.tf-footer-nav a:hover{color:var(--tc)}
.tf-footer-made{font-size:12px;color:#334155;text-align:right}
/* ── Back to top ── */
.tf-back-top{
  position:fixed;bottom:28px;right:28px;width:44px;height:44px;
  background:var(--tc);color:#fff;border:none;border-radius:12px;
  cursor:pointer;font-size:18px;display:flex;align-items:center;justify-content:center;
  box-shadow:0 8px 24px rgba(255,94,46,.4);
  opacity:0;pointer-events:none;transform:translateY(8px);
  transition:opacity .3s,transform .3s;z-index:99;text-decoration:none;
}
.tf-back-top.visible{opacity:1;pointer-events:auto;transform:translateY(0)}
.tf-back-top:hover{background:#e04e22;transform:translateY(-3px)!important}
/* ── Responsive ── */
@media(max-width:1024px){
  .tf-footer-main{grid-template-columns:1fr 1fr;gap:36px}
}
@media(max-width:640px){
  .tf-footer-main{grid-template-columns:1fr;gap:32px;padding:48px 24px 32px}
  .tf-footer-bottom{flex-direction:column;text-align:center}
  .tf-footer-nav{justify-content:center}
}
</style>

  <!-- ── Main grid ── -->
  <div class="tf-footer-main">

    <!-- Brand column -->
    <div class="tf-footer-brand">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="tf-footer-brand-name"><?php echo esc_html( get_bloginfo( 'name' ) ?: 'ThemeFlex' ); ?></a>
      <p class="tf-footer-tagline"><?php esc_html_e( 'The professional dark-first WordPress theme for agencies, SaaS, and creative studios. Built for Elementor.', 'themeflex' ); ?></p>
      <div class="tf-footer-social">
        <?php
        $socials = [
          'twitter'   => ['icon' => 'fa-brands fa-x-twitter',   'url' => get_theme_mod( 'sf_social_twitter', '#' ),   'label' => 'X / Twitter'],
          'github'    => ['icon' => 'fa-brands fa-github',      'url' => get_theme_mod( 'sf_social_github', '#' ),    'label' => 'GitHub'],
          'dribbble'  => ['icon' => 'fa-brands fa-dribbble',    'url' => get_theme_mod( 'sf_social_dribbble', '#' ),  'label' => 'Dribbble'],
          'linkedin'  => ['icon' => 'fa-brands fa-linkedin-in', 'url' => get_theme_mod( 'sf_social_linkedin', '#' ),  'label' => 'LinkedIn'],
          'youtube'   => ['icon' => 'fa-brands fa-youtube',     'url' => get_theme_mod( 'sf_social_youtube', '#' ),   'label' => 'YouTube'],
        ];
        foreach ( $socials as $platform => $data ) : ?>
          <a href="<?php echo esc_url( $data['url'] ); ?>" class="tf-social-icon" aria-label="<?php echo esc_attr( $data['label'] ); ?>" <?php echo $data['url'] !== '#' ? 'target="_blank" rel="noopener"' : ''; ?>>
            <i class="<?php echo esc_attr( $data['icon'] ); ?>" aria-hidden="true"></i>
          </a>
        <?php endforeach; ?>
      </div>
      <div class="tf-footer-badges" style="margin-top:20px">
        <span class="tf-footer-badge">97 PageSpeed</span>
        <span class="tf-footer-badge">WCAG 2.1 AA</span>
        <span class="tf-footer-badge">Elementor Ready</span>
      </div>
    </div>

    <!-- Pages column -->
    <div class="tf-footer-col">
      <h4><?php esc_html_e( 'Pages', 'themeflex' ); ?></h4>
      <ul class="tf-footer-links">
        <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'themeflex' ); ?></a></li>
        <li><a href="<?php echo esc_url( home_url( '/about' ) ); ?>"><?php esc_html_e( 'About', 'themeflex' ); ?></a></li>
        <li><a href="<?php echo esc_url( home_url( '/services' ) ); ?>"><?php esc_html_e( 'Services', 'themeflex' ); ?></a></li>
        <li><a href="<?php echo esc_url( home_url( '/portfolio' ) ); ?>"><?php esc_html_e( 'Portfolio', 'themeflex' ); ?></a></li>
        <li><a href="<?php echo esc_url( home_url( '/pricing' ) ); ?>"><?php esc_html_e( 'Pricing', 'themeflex' ); ?></a></li>
        <li><a href="<?php echo esc_url( home_url( '/blog' ) ); ?>"><?php esc_html_e( 'Blog', 'themeflex' ); ?></a></li>
        <li><a href="<?php echo esc_url( home_url( '/contact' ) ); ?>"><?php esc_html_e( 'Contact', 'themeflex' ); ?></a></li>
      </ul>
    </div>

    <!-- Resources column -->
    <div class="tf-footer-col">
      <h4><?php esc_html_e( 'Resources', 'themeflex' ); ?></h4>
      <ul class="tf-footer-links">
        <li><a href="https://docs.themeflex.de" target="_blank" rel="noopener"><?php esc_html_e( 'Documentation', 'themeflex' ); ?></a></li>
        <li><a href="<?php echo esc_url( home_url( '/changelog' ) ); ?>"><?php esc_html_e( 'Changelog', 'themeflex' ); ?></a></li>
        <li><a href="https://themeforest.net/item/themeflex" target="_blank" rel="noopener"><?php esc_html_e( 'Buy on ThemeForest', 'themeflex' ); ?></a></li>
        <li><a href="<?php echo esc_url( home_url( '/support' ) ); ?>"><?php esc_html_e( 'Support Center', 'themeflex' ); ?></a></li>
        <li><a href="<?php echo esc_url( home_url( '/demos' ) ); ?>"><?php esc_html_e( 'All Demos', 'themeflex' ); ?></a></li>
        <li><a href="<?php echo esc_url( home_url( '/privacy-policy' ) ); ?>"><?php esc_html_e( 'Privacy Policy', 'themeflex' ); ?></a></li>
      </ul>
    </div>

    <!-- Newsletter column -->
    <div class="tf-footer-newsletter tf-footer-col">
      <h4><?php esc_html_e( 'Stay Updated', 'themeflex' ); ?></h4>
      <p><?php esc_html_e( 'Get theme updates, design tips and WordPress tutorials. No spam, unsubscribe any time.', 'themeflex' ); ?></p>
      <div class="tf-footer-form">
        <input type="email" class="tf-footer-input"
               placeholder="<?php esc_attr_e( 'your@email.com', 'themeflex' ); ?>"
               aria-label="<?php esc_attr_e( 'Email address', 'themeflex' ); ?>">
        <button type="button" class="tf-footer-submit">
          <i class="fa-solid fa-paper-plane" aria-hidden="true" style="margin-right:6px"></i>
          <?php esc_html_e( 'Subscribe', 'themeflex' ); ?>
        </button>
      </div>
      <p style="font-size:12px;color:#334155;margin:10px 0 0;">
        <i class="fa-solid fa-lock" aria-hidden="true" style="margin-right:4px"></i>
        <?php esc_html_e( 'No spam. Unsubscribe anytime.', 'themeflex' ); ?>
      </p>
    </div>

  </div><!-- .tf-footer-main -->

  <hr class="tf-footer-divider">

  <!-- ── Bottom bar ── -->
  <div class="tf-footer-bottom">
    <p class="tf-footer-copyright">
      &copy; <?php echo esc_html( gmdate( 'Y' ) ); ?>
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html( get_bloginfo( 'name' ) ?: 'ThemeFlex' ); ?></a>.
      <?php esc_html_e( 'All rights reserved.', 'themeflex' ); ?>
    </p>
    <ul class="tf-footer-nav">
      <li><a href="<?php echo esc_url( home_url( '/privacy-policy' ) ); ?>"><?php esc_html_e( 'Privacy', 'themeflex' ); ?></a></li>
      <li><a href="<?php echo esc_url( home_url( '/terms' ) ); ?>"><?php esc_html_e( 'Terms', 'themeflex' ); ?></a></li>
      <li><a href="<?php echo esc_url( home_url( '/cookies' ) ); ?>"><?php esc_html_e( 'Cookies', 'themeflex' ); ?></a></li>
    </ul>
    <p class="tf-footer-made">
      <?php esc_html_e( 'Made with', 'themeflex' ); ?> ♥ <?php esc_html_e( 'in Germany', 'themeflex' ); ?>
    </p>
  </div>

</footer><!-- #site-footer -->

<!-- Back to top -->
<a href="#" class="tf-back-top" id="tfBackTop" aria-label="<?php esc_attr_e( 'Back to top', 'themeflex' ); ?>">↑</a>

<script>
(function(){
  var btn = document.getElementById('tfBackTop');
  if(!btn) return;
  window.addEventListener('scroll', function(){
    btn.classList.toggle('visible', window.scrollY > 400);
  }, {passive:true});
  btn.addEventListener('click', function(e){
    e.preventDefault();
    window.scrollTo({top:0,behavior:'smooth'});
  });
})();
</script>

	</div><!-- .page_wrap -->
	</div><!-- .body_wrap -->
	<?php wp_footer(); ?>
</body>
</html>
