<?php
/**
 * Front Page Template
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

get_header(); ?>

<?php
// Get the front page builder instance
$front_page = themeflex_front_page();

// Get all sections
$sections = $front_page->get_sections();

// Sort sections by priority
uasort( $sections, function ( $a, $b ) {
	return $a['priority'] - $b['priority'];
} );

// Render each section
foreach ( $sections as $section_id => $section_data ) {
	$front_page->render_section( $section_id );
}
?>

<?php get_footer(); ?>
