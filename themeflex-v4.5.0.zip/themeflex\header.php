<?php
/**
 * The header for ThemeFlex theme
 *
 * Features:
 * - Sticky Header Support
 * - Dark Mode Toggle Button
 * - Mobile Navigation
 * - Responsive Design
 *
 * Note: Open Graph / Twitter Card meta tags are output via
 * themeflex_output_og_tags() in includes/template-functions.php.
 * They were moved there in v3.1.0 to prevent "Cannot redeclare"
 * fatal errors that can occur when header.php is loaded more than once.
 *
 * @package ThemeFlex
 * @since 1.0.0
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="<?php echo esc_attr( apply_filters( 'themeflex_html_classes', '' ) ); ?>">
<head>
	<meta charset="<?php echo esc_attr( get_bloginfo( 'charset' ) ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- WCAG 2.1: Support for high contrast mode and color scheme preference -->
	<meta name="color-scheme" content="light dark">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<?php
	wp_body_open();
	get_template_part( 'template-parts/preloader' );
	?>
	<!-- Dark-first FOUC prevention: apply saved or default dark mode before first paint -->
	<script>
	(function(){
	  try {
	    var saved = localStorage.getItem('themeflexTheme') || 'dark';
	    if (saved === 'dark') {
	      document.documentElement.setAttribute('data-theme', 'dark');
	      document.documentElement.style.setProperty('background-color', '#06021d');
	    }
	  } catch(e){}
	})();
	</script>
	<style>
	/* ── Dark-first body defaults — override critical-inline.css white bg ── */
	html,body{background-color:#06021d!important;color:#94a3b8}
	/* These vars are read by all template <style> blocks */
	:root{
	  --tf-primary:#ff5e2e;--tf-accent:#00d4ff;
	  --tf-bg:#06021d;--tf-surface:#111827;
	  --tf-border:rgba(255,255,255,.07);
	  --tf-title:#f1f5f9;--tf-text:#94a3b8;--tf-meta:#64748b;
	  --sf-color-primary:#ff5e2e;
	}
	/* Header dark styling */
	.site-header{
	  background:rgba(6,2,29,.92)!important;
	  border-bottom:1px solid rgba(255,255,255,.07)!important;
	  backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);
	}
	.site-title a,.site-title a:hover{color:#f1f5f9!important;text-decoration:none}
	.site-description{color:#64748b!important}
	.main-navigation a,.main-navigation .menu-item a{color:#94a3b8!important;transition:color .2s}
	.main-navigation a:hover,.main-navigation .current-menu-item>a{color:#ff5e2e!important}
	.menu-toggle{color:#94a3b8!important;background:transparent!important;border:1px solid rgba(255,255,255,.1)!important}
	.dark-mode-toggle{color:#94a3b8!important;background:rgba(255,255,255,.06)!important;border:1px solid rgba(255,255,255,.08)!important;border-radius:8px!important}
	.dark-mode-toggle:hover{background:rgba(255,94,46,.1)!important;border-color:rgba(255,94,46,.3)!important;color:#ff5e2e!important}
	</style>

	<div class="body_wrap">
		<div class="page_wrap">
			<?php
			/**
			 * Action hook before header
			 *
			 * @since 1.0.0
			 */
			do_action( 'themeflex_before_header' );
			?>

			<?php
			/**
			 * Dynamic header template loader — resolves themeflex_header_layout
			 * to the matching template-part in template-parts/header/header-{slug}.php.
			 * Fallback is header-default.php which mirrors the classic monolithic header.
			 *
			 * @since 4.5.0
			 */
			$_sf_layout_map = array(
				'standard'       => 'default',
				'default'        => 'default',
				'centered'       => 'centered',
				'transparent'    => 'transparent',
				'minimal'        => 'minimal',
				'offcanvas'      => 'offcanvas',
				'search-overlay' => 'search-overlay',
				'topbar'         => 'topbar',
				'logo'           => 'logo',
				'mobile'         => 'mobile',
			);
			$_sf_layout = get_theme_mod( 'themeflex_header_layout', 'standard' );
			$_sf_tpl    = isset( $_sf_layout_map[ $_sf_layout ] ) ? $_sf_layout_map[ $_sf_layout ] : 'default';
			get_template_part( 'template-parts/header/header', $_sf_tpl );
			unset( $_sf_layout_map, $_sf_layout, $_sf_tpl );
			?>

			<?php
			/**
			 * Action hook after header
			 *
			 * @since 1.0.0
			 */
			do_action( 'themeflex_after_header' );
			?>

			<a class="skip-link screen-reader-text" href="#site-content">
				<?php esc_html_e( 'Skip to content', 'themeflex' ); ?>
			</a>

			<div class="page_content_wrap">
				<div class="content_wrap">
					<main id="site-content" class="site-content content" role="main">
						<?php
						/**
						 * Action hook before main content
						 *
						 * @since 1.0.0
						 */
						do_action( 'themeflex_before_content' );
						?>
