<?php
/**
 * Blog Home / Posts Page — ThemeFlex
 * Dark-first, self-contained. No external CSS required.
 *
 * @package ThemeFlex
 * @since 1.2.0
 */
get_header(); ?>
<main id="primary" class="site-main tf-blog-main">
<style>
/* ── Variables ─────────────────────────────────────────────────────────── */
.tf-blog-main{
  padding:80px 0 110px;
  --tc:#ff5e2e;--tc2:#00d4ff;
  --bg:#06021d;--bg2:#0d1526;--bg3:#111827;
  --border:rgba(255,255,255,.07);
  --title:#f1f5f9;--txt:#94a3b8;--meta:#64748b;
  background:var(--bg);
}
/* ── Hero ──────────────────────────────────────────────────────────────── */
.tf-hero{text-align:center;margin-bottom:56px}
.tf-eyebrow{display:inline-flex;align-items:center;gap:8px;background:rgba(255,94,46,.1);border:1px solid rgba(255,94,46,.22);color:var(--tc);font-size:.7rem;font-weight:800;letter-spacing:.12em;text-transform:uppercase;padding:6px 18px;border-radius:100px;margin-bottom:22px}
.tf-hero h1{font-family:'Inter Tight',sans-serif;font-size:clamp(2.1rem,4.5vw,3.2rem);font-weight:900;color:var(--title);margin:0 0 14px;letter-spacing:-.6px;line-height:1.12}
.tf-hero p{color:var(--txt);font-size:1.08rem;max-width:520px;margin:0 auto;line-height:1.7}
/* ── Filter Tabs ───────────────────────────────────────────────────────── */
.tf-filters{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-bottom:48px}
.tf-filter-btn{padding:7px 18px;border-radius:100px;border:1px solid var(--border);color:var(--meta);font-size:.8rem;font-weight:700;letter-spacing:.04em;text-decoration:none;transition:all .25s;cursor:pointer;background:transparent}
.tf-filter-btn:hover,.tf-filter-btn.active{background:var(--tc);color:#fff;border-color:var(--tc)}
/* ── Grid ──────────────────────────────────────────────────────────────── */
.tf-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}
/* Featured first card spans 2 cols */
.tf-grid .tf-card:first-child{grid-column:1/3}
.tf-grid .tf-card:first-child .tf-thumb{aspect-ratio:16/7}
.tf-grid .tf-card:first-child .tf-title{font-size:1.35rem}
/* ── Card ──────────────────────────────────────────────────────────────── */
.tf-card{background:var(--bg3);border:1px solid var(--border);border-radius:16px;overflow:hidden;display:flex;flex-direction:column;transition:transform .3s,box-shadow .3s,border-color .3s;position:relative}
.tf-card::before{content:'';position:absolute;inset:0;border-radius:16px;background:linear-gradient(135deg,rgba(255,94,46,.08),rgba(0,212,255,.05));opacity:0;transition:opacity .3s;pointer-events:none}
.tf-card:hover{transform:translateY(-6px);box-shadow:0 24px 64px rgba(0,0,0,.45);border-color:rgba(255,94,46,.3)}
.tf-card:hover::before{opacity:1}
/* ── Thumbnail ─────────────────────────────────────────────────────────── */
.tf-thumb{aspect-ratio:16/9;position:relative;overflow:hidden;background:linear-gradient(135deg,#1e293b,#0f172a);flex-shrink:0}
.tf-thumb img{width:100%;height:100%;object-fit:cover;position:absolute;inset:0;transition:transform .5s ease}
.tf-card:hover .tf-thumb img{transform:scale(1.04)}
.tf-thumb-icon{position:absolute;inset:0;display:flex;align-items:center;justify-content:center}
.tf-thumb-icon svg{width:40px;height:40px;display:block}
.tf-cat-badge{position:absolute;top:14px;left:14px;background:var(--tc);color:#fff;font-size:.62rem;font-weight:800;letter-spacing:.1em;text-transform:uppercase;padding:4px 11px;border-radius:100px;z-index:2;text-decoration:none;transition:background .2s}
.tf-cat-badge:hover{background:#e04e22}
/* ── Body ──────────────────────────────────────────────────────────────── */
.tf-body{padding:22px 24px 26px;flex:1;display:flex;flex-direction:column}
.tf-title{font-family:'Inter Tight',sans-serif;font-size:1.05rem;font-weight:800;color:var(--title);margin:0 0 10px;line-height:1.35}
.tf-title a{color:inherit;text-decoration:none;transition:color .2s}
.tf-title a:hover{color:var(--tc)}
.tf-excerpt{font-size:.875rem;color:var(--meta);line-height:1.7;margin:0 0 20px;flex:1}
/* ── Meta ──────────────────────────────────────────────────────────────── */
.tf-meta{display:flex;align-items:center;justify-content:space-between;font-size:.75rem;color:var(--meta);margin-top:auto;padding-top:14px;border-top:1px solid var(--border)}
.tf-meta-left{display:flex;align-items:center;gap:8px}
.tf-meta-left img,.tf-avatar{width:24px;height:24px;border-radius:50%;object-fit:cover}
/* ── Read-more link ────────────────────────────────────────────────────── */
.tf-readmore{display:inline-flex;align-items:center;gap:6px;margin-top:18px;font-size:.8rem;font-weight:700;color:var(--tc);text-decoration:none;letter-spacing:.03em;transition:gap .2s}
.tf-readmore:hover{gap:10px}
/* ── Pagination ────────────────────────────────────────────────────────── */
.tf-pagination{text-align:center;margin-top:64px}
.tf-pagination .page-numbers{display:inline-flex;align-items:center;justify-content:center;min-width:42px;height:42px;border-radius:10px;border:1px solid var(--border);color:var(--txt);text-decoration:none;font-size:.875rem;font-weight:600;transition:all .22s;margin:0 3px;padding:0 12px}
.tf-pagination .page-numbers:hover,.tf-pagination .page-numbers.current{background:var(--tc);color:#fff;border-color:var(--tc)}
/* ── Responsive ────────────────────────────────────────────────────────── */
@media(max-width:960px){
  .tf-grid{grid-template-columns:repeat(2,1fr)}
  .tf-grid .tf-card:first-child{grid-column:1/-1}
}
@media(max-width:600px){
  .tf-grid{grid-template-columns:1fr}
  .tf-grid .tf-card:first-child{grid-column:1}
}
</style>

<div class="container" style="max-width:1220px;margin:0 auto;padding:0 24px;">

  <!-- ── Hero ── -->
  <header class="tf-hero">
    <div class="tf-eyebrow">✍️ Insights &amp; Ideas</div>
    <h1><?php
      // Reliably get the "Posts page" title if one is set
      $posts_page_id = (int) get_option( 'page_for_posts' );
      if ( $posts_page_id > 0 ) {
        echo esc_html( get_the_title( $posts_page_id ) );
      } else {
        esc_html_e( 'Our Blog', 'themeflex' );
      }
    ?></h1>
    <p><?php esc_html_e( 'Expert tips, design trends and WordPress know-how from the ThemeFlex team.', 'themeflex' ); ?></p>
  </header>

  <?php
  /* ── Category filter tabs ── */
  $all_cats = get_categories( ['hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC'] );
  if ( count( $all_cats ) > 1 ) : ?>
  <nav class="tf-filters" aria-label="<?php esc_attr_e( 'Filter by category', 'themeflex' ); ?>">
    <a href="<?php echo esc_url( get_permalink( get_option('page_for_posts') ) ); ?>"
       class="tf-filter-btn<?php echo ( ! is_category() ) ? ' active' : ''; ?>">
      <?php esc_html_e( 'All Posts', 'themeflex' ); ?>
    </a>
    <?php foreach ( $all_cats as $fcat ) : ?>
    <a href="<?php echo esc_url( get_category_link( $fcat->term_id ) ); ?>"
       class="tf-filter-btn<?php echo ( is_category( $fcat->term_id ) ) ? ' active' : ''; ?>">
      <?php echo esc_html( $fcat->name ); ?>
    </a>
    <?php endforeach; ?>
  </nav>
  <?php endif; ?>

  <?php
  /* ── SVG icon / gradient map by category slug ── */
  $_hsvg = [
    'design'      => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2z"/><path d="M22 12a10 10 0 0 1-10 10 4 4 0 0 1 0-8 4 4 0 0 0 0-8 10 10 0 0 1 10 6z"/></svg>',
    'development' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
    'tutorial'    => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>',
    'company'     => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
    'services'    => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 4.93a10 10 0 0 0 0 14.14"/></svg>',
    'seo'         => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
    'ecommerce'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>',
    'wordpress'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>',
    'marketing'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
    'tips'        => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="2" x2="12" y2="6"/><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"/><line x1="2" y1="12" x2="6" y2="12"/><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"/><line x1="12" y1="18" x2="12" y2="22"/><line x1="19.07" y1="19.07" x2="16.24" y2="16.24"/><line x1="18" y1="12" x2="22" y2="12"/><line x1="19.07" y1="4.93" x2="16.24" y2="7.76"/></svg>',
    '_default'    => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>',
  ];
  $emoji_map = [
    'design'      => ['s' => $_hsvg['design'],      'c' => 'rgba(248,113,113,.3)', 'g' => 'linear-gradient(135deg,#2a1a1a,#1e0f0f)'],
    'development' => ['s' => $_hsvg['development'], 'c' => 'rgba(96,165,250,.3)',  'g' => 'linear-gradient(135deg,#0f1a2e,#091220)'],
    'tutorial'    => ['s' => $_hsvg['tutorial'],    'c' => 'rgba(251,191,36,.3)',  'g' => 'linear-gradient(135deg,#1e1a0f,#14120a)'],
    'company'     => ['s' => $_hsvg['company'],     'c' => 'rgba(52,211,153,.3)',  'g' => 'linear-gradient(135deg,#0f1e2a,#091418)'],
    'services'    => ['s' => $_hsvg['services'],    'c' => 'rgba(167,139,250,.3)', 'g' => 'linear-gradient(135deg,#1a1e2a,#0f1318)'],
    'seo'         => ['s' => $_hsvg['seo'],         'c' => 'rgba(110,231,183,.3)', 'g' => 'linear-gradient(135deg,#1a2a0f,#0f1e09)'],
    'ecommerce'   => ['s' => $_hsvg['ecommerce'],   'c' => 'rgba(139,92,246,.3)',  'g' => 'linear-gradient(135deg,#1a1a2e,#0f0f1e)'],
    'wordpress'   => ['s' => $_hsvg['wordpress'],   'c' => 'rgba(56,88,233,.3)',   'g' => 'linear-gradient(135deg,#0f1f2e,#091525)'],
    'marketing'   => ['s' => $_hsvg['marketing'],   'c' => 'rgba(74,222,128,.3)',  'g' => 'linear-gradient(135deg,#1a2e0f,#0e1f09)'],
    'tips'        => ['s' => $_hsvg['tips'],        'c' => 'rgba(251,146,60,.3)',  'g' => 'linear-gradient(135deg,#2a240f,#1a170a)'],
  ];
  $default = ['s' => $_hsvg['_default'], 'c' => 'rgba(255,255,255,.2)', 'g' => 'linear-gradient(135deg,#1e293b,#0f172a)'];

  if ( have_posts() ) : ?>
  <div class="tf-grid">
    <?php $idx = 0; while ( have_posts() ) : the_post(); $idx++;
      $cats  = get_the_category();
      $cat   = ! empty( $cats ) ? $cats[0] : null;
      $slug  = $cat ? strtolower( $cat->slug ) : '';
      $map   = isset( $emoji_map[ $slug ] ) ? $emoji_map[ $slug ] : $default;
      $_icon_svg = isset( $map['s'] ) ? $map['s'] : $default['s'];
      $_icon_clr = isset( $map['c'] ) ? $map['c'] : $default['c'];
      $words = str_word_count( strip_tags( get_the_content() ) );
      $read  = max( 1, (int) ceil( $words / 200 ) );
    ?>
    <article class="tf-card" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

      <!-- Thumbnail — wrapper is a div to avoid invalid nested <a> -->
      <div class="tf-thumb" style="background:<?php echo esc_attr( $map['g'] ); ?>">
        <a href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1" style="display:block;width:100%;height:100%;position:absolute;inset:0;">
          <?php if ( has_post_thumbnail() ) :
            the_post_thumbnail( 'medium_large' );
          else : ?>
            <span class="tf-thumb-icon" style="color:<?php echo esc_attr($_icon_clr); ?>" aria-hidden="true"><?php echo $_icon_svg; ?></span>
          <?php endif; ?>
        </a>
        <?php if ( $cat ) : ?>
          <a class="tf-cat-badge" href="<?php echo esc_url( get_category_link( $cat->term_id ) ); ?>"><?php echo esc_html( $cat->name ); ?></a>
        <?php endif; ?>
      </div>

      <!-- Body -->
      <div class="tf-body">
        <h2 class="tf-title">
          <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h2>
        <p class="tf-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt() ?: strip_tags( get_the_content() ), 22, '…' ) ); ?></p>
        <?php if ( $idx === 1 ) : ?>
          <a href="<?php the_permalink(); ?>" class="tf-readmore"><?php esc_html_e( 'Read Article', 'themeflex' ); ?> →</a>
        <?php endif; ?>
        <div class="tf-meta">
          <div class="tf-meta-left">
            <?php echo get_avatar( get_the_author_meta( 'ID' ), 24, '', '', ['style'=>'border-radius:50%;'] ); ?>
            <span><?php the_author(); ?></span>
          </div>
          <span><?php echo esc_html( get_the_date( 'M j, Y' ) ); ?> &middot; <?php echo $read; ?> min</span>
        </div>
      </div>

    </article>
    <?php endwhile; ?>
  </div>

  <!-- Pagination -->
  <div class="tf-pagination">
    <?php echo wp_kses_post( paginate_links( [
      'type'      => 'plain',
      'prev_text' => '← ' . esc_html__( 'Newer', 'themeflex' ),
      'next_text' => esc_html__( 'Older', 'themeflex' ) . ' →',
    ] ) ); ?>
  </div>

  <?php else : ?>
  <p style="text-align:center;color:var(--meta);font-size:1.05rem;padding:60px 0;">
    <?php esc_html_e( 'No posts found.', 'themeflex' ); ?>
  </p>
  <?php endif; ?>

</div>
</main>
<?php get_footer(); ?>
