<?php
/**
 * Impressum Template — Österreich (AT)
 * §§ 5, 24, 25 MedienG; § 63 GewO
 *
 * Variables available: $legal (array of legal data)
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

$company = esc_html( $legal['company_name'] ?? '' );
$form    = esc_html( $legal['company_form'] ?? '' );
$owner   = esc_html( $legal['owner_name'] ?? '' );
$street  = esc_html( $legal['street'] ?? '' );
$post    = esc_html( $legal['postcode'] ?? '' );
$city    = esc_html( $legal['city'] ?? '' );
$phone   = esc_html( $legal['phone'] ?? '' );
$email   = esc_html( $legal['email'] ?? '' );
$vat     = esc_html( $legal['vat_id'] ?? '' );
$reg_no  = esc_html( $legal['register_number'] ?? '' );
$reg_ct  = esc_html( $legal['register_court'] ?? '' );
$superv  = esc_html( $legal['supervisory_authority'] ?? '' );
$profess = esc_html( $legal['profession'] ?? '' );
$chamber = esc_html( $legal['chamber'] ?? '' );
?>
<div class="tf-legal-impressum">
<h2><?php esc_html_e( 'Impressum', 'themeflex' ); ?></h2>

<h3><?php esc_html_e( 'Offenlegungspflicht gemäß § 25 MedienG', 'themeflex' ); ?></h3>
<p>
<?php if ( $company ) echo $company . ( $form ? ' ' . $form : '' ) . '<br>'; ?>
<?php if ( $owner ) echo $owner . '<br>'; ?>
<?php if ( $street ) echo $street . '<br>'; ?>
<?php if ( $post || $city ) echo trim( $post . ' ' . $city ) . '<br>'; ?>
Österreich<br>
</p>

<h3><?php esc_html_e( 'Kontakt', 'themeflex' ); ?></h3>
<p>
<?php if ( $phone ) echo esc_html__( 'Tel:', 'themeflex' ) . ' ' . $phone . '<br>'; ?>
<?php if ( $email ) echo 'E-Mail: <a href="mailto:' . antispambot( $email ) . '">' . antispambot( $email ) . '</a>'; ?>
</p>

<?php if ( $vat ) : ?>
<h3><?php esc_html_e( 'UID-Nummer', 'themeflex' ); ?></h3>
<p><?php echo $vat; ?></p>
<?php endif; ?>

<?php if ( $reg_no || $reg_ct ) : ?>
<h3><?php esc_html_e( 'Firmenbucheintrag', 'themeflex' ); ?></h3>
<p>
<?php if ( $reg_ct ) echo esc_html__( 'Firmenbuchgericht:', 'themeflex' ) . ' ' . $reg_ct . '<br>'; ?>
<?php if ( $reg_no ) echo esc_html__( 'Firmenbuchnummer:', 'themeflex' ) . ' ' . $reg_no; ?>
</p>
<?php endif; ?>

<?php if ( $superv ) : ?>
<h3><?php esc_html_e( 'Aufsichtsbehörde', 'themeflex' ); ?></h3>
<p><?php echo $superv; ?></p>
<?php endif; ?>

<?php if ( $profess || $chamber ) : ?>
<h3><?php esc_html_e( 'Berufsrecht', 'themeflex' ); ?></h3>
<p>
<?php if ( $profess ) echo esc_html__( 'Berufsbezeichnung:', 'themeflex' ) . ' ' . $profess . '<br>'; ?>
<?php if ( $chamber ) echo esc_html__( 'Kammer:', 'themeflex' ) . ' ' . $chamber; ?>
</p>
<?php endif; ?>

<h3><?php esc_html_e( 'Haftungsausschluss', 'themeflex' ); ?></h3>
<p><?php esc_html_e( 'Trotz sorgfältiger inhaltlicher Kontrolle übernehmen wir keine Haftung für die Inhalte externer Links. Für den Inhalt der verlinkten Seiten sind ausschließlich deren Betreiber verantwortlich.', 'themeflex' ); ?></p>
</div>
