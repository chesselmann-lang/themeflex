<?php
/**
 * Impressum Template — Schweiz (CH)
 *
 * Variables available: $legal (array of legal data)
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

$company = esc_html( $legal['company_name'] ?? '' );
$form    = esc_html( $legal['company_form'] ?? '' );
$owner   = esc_html( $legal['owner_name'] ?? '' );
$street  = esc_html( $legal['street'] ?? '' );
$post    = esc_html( $legal['postcode'] ?? '' );
$city    = esc_html( $legal['city'] ?? '' );
$phone   = esc_html( $legal['phone'] ?? '' );
$email   = esc_html( $legal['email'] ?? '' );
$vat     = esc_html( $legal['vat_id'] ?? '' );
?>
<div class="tf-legal-impressum">
<h2><?php esc_html_e( 'Impressum / Kontakt', 'themeflex' ); ?></h2>

<p>
<?php if ( $company ) echo $company . ( $form ? ' ' . $form : '' ) . '<br>'; ?>
<?php if ( $owner ) echo $owner . '<br>'; ?>
<?php if ( $street ) echo $street . '<br>'; ?>
<?php if ( $post || $city ) echo trim( $post . ' ' . $city ) . '<br>'; ?>
Schweiz<br>
</p>

<p>
<?php if ( $phone ) echo esc_html__( 'Tel:', 'themeflex' ) . ' ' . $phone . '<br>'; ?>
<?php if ( $email ) echo 'E-Mail: <a href="mailto:' . antispambot( $email ) . '">' . antispambot( $email ) . '</a>'; ?>
</p>

<?php if ( $vat ) : ?>
<p><?php esc_html_e( 'MWST-Nr.:', 'themeflex' ); ?> <?php echo $vat; ?></p>
<?php endif; ?>

<h3><?php esc_html_e( 'Haftungsausschluss', 'themeflex' ); ?></h3>
<p><?php esc_html_e( 'Alle Angaben auf dieser Website wurden sorgfältig geprüft. Wir sind bemüht, dafür Sorge zu tragen, dass die von uns bereitgestellten Informationen aktuell, richtig und vollständig sind. Dennoch ist das Auftreten von Fehlern nicht völlig auszuschliessen, weshalb wir für die Vollständigkeit, Richtigkeit und Aktualität der Informationen keine Gewähr übernehmen können.', 'themeflex' ); ?></p>
</div>
