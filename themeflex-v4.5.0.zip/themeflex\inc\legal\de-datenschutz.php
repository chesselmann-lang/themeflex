<?php
/**
 * Datenschutzerklärung Template — Deutschland (DE) / Österreich (AT) / Schweiz (CH)
 *
 * Variables available: $legal (array of legal data)
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

$controller = esc_html( $legal['data_controller_name'] ?? ( $legal['company_name'] ?? '' ) );
$email      = esc_html( $legal['data_controller_email'] ?? ( $legal['email'] ?? '' ) );
$hosting    = esc_html( $legal['hosting_provider'] ?? '' );
$analytics  = esc_html( $legal['analytics_tool'] ?? '' );
$ai_prov    = esc_html( $legal['ai_provider_name'] ?? '' );
$site_url   = esc_url( home_url() );
$jurisdiction = $legal['jurisdiction'] ?? 'de';

$law_ref = 'de' === $jurisdiction
	? __( 'Datenschutz-Grundverordnung (DSGVO)', 'themeflex' )
	: ( 'at' === $jurisdiction ? __( 'österreichischen Datenschutzgesetz (DSG) und der DSGVO', 'themeflex' )
		: __( 'revidierten Datenschutzgesetz (revDSG) der Schweiz', 'themeflex' ) );
?>
<div class="tf-legal-datenschutz">
<h2><?php esc_html_e( 'Datenschutzerklärung', 'themeflex' ); ?></h2>

<h3><?php esc_html_e( '1. Datenschutz auf einen Blick', 'themeflex' ); ?></h3>
<h4><?php esc_html_e( 'Allgemeine Hinweise', 'themeflex' ); ?></h4>
<p>
<?php
/* translators: %s: name of applicable data protection law */
printf( esc_html__( 'Die folgenden Hinweise geben einen einfachen Überblick darüber, was mit Ihren personenbezogenen Daten passiert, wenn Sie diese Website besuchen. Personenbezogene Daten sind alle Daten, mit denen Sie persönlich identifiziert werden können. Ausführliche Informationen zum Thema Datenschutz entnehmen Sie unserer unter diesem Text aufgeführten Datenschutzerklärung. Es gilt die %s.', 'themeflex' ), $law_ref );
?>
</p>

<h4><?php esc_html_e( 'Datenerfassung auf dieser Website', 'themeflex' ); ?></h4>
<p><strong><?php esc_html_e( 'Wer ist verantwortlich für die Datenerfassung auf dieser Website?', 'themeflex' ); ?></strong><br>
<?php
/* translators: %s: controller name */
printf( esc_html__( 'Die Datenverarbeitung auf dieser Website erfolgt durch den Websitebetreiber. Dessen Kontaktdaten können Sie dem Impressum dieser Website entnehmen. Verantwortliche Stelle: %s', 'themeflex' ), $controller );
?>
<?php if ( $email ) : ?><br><a href="mailto:<?php echo antispambot( $email ); ?>"><?php echo antispambot( $email ); ?></a><?php endif; ?>
</p>

<h3><?php esc_html_e( '2. Hosting', 'themeflex' ); ?></h3>
<?php if ( $hosting ) : ?>
<p>
<?php
/* translators: %s: hosting provider name */
printf( esc_html__( 'Diese Website wird bei %s gehostet. Personenbezogene Daten, die auf dieser Website erfasst werden, werden auf den Servern des Hosters gespeichert. Hierbei kann es sich v. a. um IP-Adressen, Kontaktanfragen, Meta- und Kommunikationsdaten, Vertragsdaten, Kontaktdaten, Namen, Websitezugriffe und sonstige Daten, die über eine Website generiert werden, handeln.', 'themeflex' ), $hosting );
?>
</p>
<?php else : ?>
<p><?php esc_html_e( 'Diese Website wird extern gehostet. Personenbezogene Daten, die auf dieser Website erfasst werden, werden auf den Servern des Hosters gespeichert.', 'themeflex' ); ?></p>
<?php endif; ?>

<h3><?php esc_html_e( '3. Cookies', 'themeflex' ); ?></h3>
<p><?php esc_html_e( 'Diese Website verwendet technisch notwendige Cookies. Diese sind für den Betrieb der Website erforderlich. Wir verwenden darüber hinaus optionale Cookies nur nach Ihrer ausdrücklichen Einwilligung. Sie können Ihren Browser so einrichten, dass Sie über das Setzen von Cookies informiert werden und Cookies nur im Einzelfall erlauben, die Annahme von Cookies für bestimmte Fälle oder generell ausschließen sowie das automatische Löschen der Cookies beim Schließen des Browsers aktivieren.', 'themeflex' ); ?></p>

<?php if ( $analytics && 'none' !== strtolower( $analytics ) ) : ?>
<h3><?php esc_html_e( '4. Analyse-Tools', 'themeflex' ); ?></h3>
<p>
<?php
/* translators: %s: analytics tool name */
printf( esc_html__( 'Diese Website nutzt %s zur Analyse des Nutzerverhaltens. Die Nutzung erfolgt auf Grundlage Ihrer Einwilligung gemäß Art. 6 Abs. 1 lit. a DSGVO. Sie können Ihre Einwilligung jederzeit über unsere Cookie-Einstellungen widerrufen.', 'themeflex' ), $analytics );
?>
</p>
<?php endif; ?>

<?php if ( $ai_prov ) : ?>
<h3><?php 'de' === $jurisdiction ? esc_html_e( '5. KI-Chat-Assistent', 'themeflex' ) : esc_html_e( '5. AI-Chat-Assistent', 'themeflex' ); ?></h3>
<p>
<?php
/* translators: %s: AI provider name */
printf( esc_html__( 'Diese Website bietet einen optionalen KI-Chat-Assistenten an, der von %s betrieben wird. Die Nutzung des Chat-Assistenten ist nur nach Ihrer ausdrücklichen Einwilligung möglich. Wenn Sie den Chat-Assistenten nutzen, werden Ihre eingegebenen Nachrichten zur Verarbeitung an die Server von %s übermittelt. Es werden keine Nachrichten dauerhaft gespeichert. Rechtsgrundlage ist Ihre Einwilligung gemäß Art. 6 Abs. 1 lit. a DSGVO. Sie können Ihre Einwilligung jederzeit durch Anpassen der Cookie-Einstellungen widerrufen.', 'themeflex' ), $ai_prov, $ai_prov );
?>
</p>
<?php endif; ?>

<h3><?php esc_html_e( 'Ihre Rechte', 'themeflex' ); ?></h3>
<p><?php esc_html_e( 'Sie haben jederzeit das Recht, unentgeltlich Auskunft über Herkunft, Empfänger und Zweck Ihrer gespeicherten personenbezogenen Daten zu erhalten. Sie haben außerdem ein Recht, die Berichtigung, Sperrung oder Löschung dieser Daten zu verlangen. Hierzu sowie zu weiteren Fragen zum Thema Datenschutz können Sie sich jederzeit an uns wenden.', 'themeflex' ); ?></p>
<?php if ( $email ) : ?>
<p><?php esc_html_e( 'Datenschutzkontakt:', 'themeflex' ); ?> <a href="mailto:<?php echo antispambot( $email ); ?>"><?php echo antispambot( $email ); ?></a></p>
<?php endif; ?>
</div>
