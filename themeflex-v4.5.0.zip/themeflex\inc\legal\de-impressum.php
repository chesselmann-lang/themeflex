<?php
/**
 * Impressum Template — Deutschland (DE)
 *
 * Variables available: $legal (array of legal data from ThemeFlex_Legal_Wizard)
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) { exit; }

$company = esc_html( $legal['company_name'] ?? '' );
$form    = esc_html( $legal['company_form'] ?? '' );
$owner   = esc_html( $legal['owner_name'] ?? '' );
$street  = esc_html( $legal['street'] ?? '' );
$post    = esc_html( $legal['postcode'] ?? '' );
$city    = esc_html( $legal['city'] ?? '' );
$phone   = esc_html( $legal['phone'] ?? '' );
$email   = esc_html( $legal['email'] ?? '' );
$vat     = esc_html( $legal['vat_id'] ?? '' );
$reg_no  = esc_html( $legal['register_number'] ?? '' );
$reg_ct  = esc_html( $legal['register_court'] ?? '' );
?>
<div class="tf-legal-impressum">
<h2><?php esc_html_e( 'Impressum', 'themeflex' ); ?></h2>

<h3><?php esc_html_e( 'Angaben gemäß § 5 TMG', 'themeflex' ); ?></h3>
<p>
<?php if ( $company ) echo $company . ( $form ? ' ' . $form : '' ) . '<br>'; ?>
<?php if ( $owner ) echo $owner . '<br>'; ?>
<?php if ( $street ) echo $street . '<br>'; ?>
<?php if ( $post || $city ) echo trim( $post . ' ' . $city ) . '<br>'; ?>
</p>

<h3><?php esc_html_e( 'Kontakt', 'themeflex' ); ?></h3>
<p>
<?php if ( $phone ) echo esc_html__( 'Telefon:', 'themeflex' ) . ' ' . $phone . '<br>'; ?>
<?php if ( $email ) echo esc_html__( 'E-Mail:', 'themeflex' ) . ' <a href="mailto:' . antispambot( $email ) . '">' . antispambot( $email ) . '</a>'; ?>
</p>

<?php if ( $vat ) : ?>
<h3><?php esc_html_e( 'Umsatzsteuer-ID', 'themeflex' ); ?></h3>
<p><?php echo esc_html__( 'Umsatzsteuer-Identifikationsnummer gemäß § 27a UStG:', 'themeflex' ); ?><br><?php echo $vat; ?></p>
<?php endif; ?>

<?php if ( $reg_no || $reg_ct ) : ?>
<h3><?php esc_html_e( 'Handelsregistereintrag', 'themeflex' ); ?></h3>
<p>
<?php if ( $reg_ct ) echo esc_html__( 'Registergericht:', 'themeflex' ) . ' ' . $reg_ct . '<br>'; ?>
<?php if ( $reg_no ) echo esc_html__( 'Registernummer:', 'themeflex' ) . ' ' . $reg_no; ?>
</p>
<?php endif; ?>

<h3><?php esc_html_e( 'Verantwortlich für den Inhalt nach § 55 Abs. 2 RStV', 'themeflex' ); ?></h3>
<p><?php echo $owner ?: $company; ?></p>

<h3><?php esc_html_e( 'Haftung für Inhalte', 'themeflex' ); ?></h3>
<p><?php esc_html_e( 'Als Diensteanbieter sind wir gemäß § 7 Abs.1 TMG für eigene Inhalte auf diesen Seiten nach den allgemeinen Gesetzen verantwortlich. Nach §§ 8 bis 10 TMG sind wir als Diensteanbieter jedoch nicht verpflichtet, übermittelte oder gespeicherte fremde Informationen zu überwachen oder nach Umständen zu forschen, die auf eine rechtswidrige Tätigkeit hinweisen.', 'themeflex' ); ?></p>

<h3><?php esc_html_e( 'Haftung für Links', 'themeflex' ); ?></h3>
<p><?php esc_html_e( 'Unser Angebot enthält Links zu externen Webseiten Dritter, auf deren Inhalte wir keinen Einfluss haben. Deshalb können wir für diese fremden Inhalte auch keine Gewähr übernehmen. Für die Inhalte der verlinkten Seiten ist stets der jeweilige Anbieter oder Betreiber der Seiten verantwortlich.', 'themeflex' ); ?></p>

<h3><?php esc_html_e( 'Urheberrecht', 'themeflex' ); ?></h3>
<p><?php esc_html_e( 'Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen dem deutschen Urheberrecht. Die Vervielfältigung, Bearbeitung, Verbreitung und jede Art der Verwertung außerhalb der Grenzen des Urheberrechtes bedürfen der schriftlichen Zustimmung des jeweiligen Autors bzw. Erstellers.', 'themeflex' ); ?></p>
</div>
