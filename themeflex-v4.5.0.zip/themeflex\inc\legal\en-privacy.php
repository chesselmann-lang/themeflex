<?php
/**
 * Privacy Policy Template — International (EN)
 *
 * Variables available: $legal (array of legal data)
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

$controller = esc_html( $legal['data_controller_name'] ?? ( $legal['company_name'] ?? '' ) );
$email      = esc_html( $legal['data_controller_email'] ?? ( $legal['email'] ?? '' ) );
$hosting    = esc_html( $legal['hosting_provider'] ?? '' );
$analytics  = esc_html( $legal['analytics_tool'] ?? '' );
$ai_prov    = esc_html( $legal['ai_provider_name'] ?? '' );
?>
<div class="tf-legal-privacy">
<h2><?php esc_html_e( 'Privacy Policy', 'themeflex' ); ?></h2>
<p><em><?php echo esc_html( 'Last updated: ' . wp_date( get_option( 'date_format' ) ) ); ?></em></p>

<h3><?php esc_html_e( '1. Controller', 'themeflex' ); ?></h3>
<p>
<?php if ( $controller ) : ?>
<?php esc_html_e( 'The controller responsible for data processing on this website is:', 'themeflex' ); ?><br>
<?php echo $controller; ?>
<?php if ( $email ) : ?><br><a href="mailto:<?php echo antispambot( $email ); ?>"><?php echo antispambot( $email ); ?></a><?php endif; ?>
<?php else : ?>
<?php esc_html_e( 'Please see our contact page for controller details.', 'themeflex' ); ?>
<?php endif; ?>
</p>

<h3><?php esc_html_e( '2. Data We Collect', 'themeflex' ); ?></h3>
<p><?php esc_html_e( 'We collect data you provide directly (e.g. via contact forms), data collected automatically (e.g. server logs, IP addresses), and data collected with your consent (e.g. cookies, analytics).', 'themeflex' ); ?></p>

<h3><?php esc_html_e( '3. Hosting', 'themeflex' ); ?></h3>
<p>
<?php if ( $hosting ) : ?>
<?php
/* translators: %s: hosting provider name */
printf( esc_html__( 'This website is hosted by %s. When you visit our website, your IP address and other technical data are processed by the hosting provider.', 'themeflex' ), $hosting );
?>
<?php else : ?>
<?php esc_html_e( 'This website is hosted externally. IP addresses and technical data are processed by our hosting provider.', 'themeflex' ); ?>
<?php endif; ?>
</p>

<h3><?php esc_html_e( '4. Cookies', 'themeflex' ); ?></h3>
<p><?php esc_html_e( 'We use strictly necessary cookies to operate this website. Optional cookies (analytics, AI functions) are only set with your explicit consent, which you can withdraw at any time via our cookie settings.', 'themeflex' ); ?></p>

<?php if ( $analytics && 'none' !== strtolower( $analytics ) ) : ?>
<h3><?php esc_html_e( '5. Analytics', 'themeflex' ); ?></h3>
<p>
<?php
/* translators: %s: analytics tool name */
printf( esc_html__( 'We use %s to analyse website usage. This processing is based on your consent. You can withdraw consent at any time.', 'themeflex' ), $analytics );
?>
</p>
<?php endif; ?>

<?php if ( $ai_prov ) : ?>
<h3><?php esc_html_e( 'AI Chat Assistant', 'themeflex' ); ?></h3>
<p>
<?php
/* translators: %s: AI provider name */
printf( esc_html__( 'This website offers an optional AI chat assistant powered by %1$s. Your messages are transmitted to %1$s servers for processing only when you have given consent. No messages are stored permanently. You may withdraw consent at any time via cookie settings.', 'themeflex' ), $ai_prov );
?>
</p>
<?php endif; ?>

<h3><?php esc_html_e( 'Your Rights', 'themeflex' ); ?></h3>
<p><?php esc_html_e( 'You have the right to access, rectify, erase, restrict processing of, and port your personal data. You also have the right to object to processing and to lodge a complaint with a supervisory authority. To exercise your rights, please contact us.', 'themeflex' ); ?></p>
<?php if ( $email ) : ?>
<p><?php esc_html_e( 'Privacy contact:', 'themeflex' ); ?> <a href="mailto:<?php echo antispambot( $email ); ?>"><?php echo antispambot( $email ); ?></a></p>
<?php endif; ?>
</div>
