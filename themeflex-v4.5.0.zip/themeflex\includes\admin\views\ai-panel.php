<?php
/**
 * Admin View: AI Chat Panel
 *
 * @package ThemeFlex
 * @since   4.0.0
 *
 * Variables available from ThemeFlex_Admin_AI_Panel::render_page().
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// -----------------------------------------------------------------------
// Data
// -----------------------------------------------------------------------
$provider_id   = get_option( ThemeFlex_Provider_Factory::OPTION_PROVIDER, 'anthropic' );
$has_key       = ThemeFlex_Provider_Factory::has_api_key();
$rag_meta      = ThemeFlex_RAG_Store::get_meta();
$has_index     = ThemeFlex_RAG_Store::has_index();
$providers_map = ThemeFlex_Provider_Factory::get_providers();
$provider_name = $providers_map[ $provider_id ] ?? $provider_id;
$token_log     = get_option( ThemeFlex_Chat_Endpoint::OPTION_TOKEN_LOG, array() );

// Notices.
$saved   = isset( $_GET['saved'] )   ? '1' === $_GET['saved']   : false; // phpcs:ignore WordPress.Security.NonceVerification
$indexed = isset( $_GET['indexed'] ) ? '1' === $_GET['indexed'] : false; // phpcs:ignore WordPress.Security.NonceVerification

// Key validation (lightweight).
$key_valid = false;
if ( $has_key ) {
	try {
		$provider  = ThemeFlex_Provider_Factory::make();
		$key_valid = true; // Factory didn't throw, so key is set (we skip live validate here for speed).
	} catch ( RuntimeException $e ) {
		$key_valid = false;
	}
}

// Cost estimates (very rough USD).
$cost_rates = array(
	'anthropic' => array( 'in' => 0.00000025, 'out' => 0.00000125 ),
	'openai'    => array( 'in' => 0.00000015, 'out' => 0.00000060 ),
	'gemini'    => array( 'in' => 0.00000010, 'out' => 0.00000040 ),
);
?>
<div class="wrap" id="tf-ai-panel">
<style>
#tf-ai-panel { max-width: 960px; }
.tf-card { background:#fff; border:1px solid #e5e7eb; border-radius:8px; padding:1.5rem; margin-bottom:1.25rem; }
.tf-card h2 { margin-top:0; font-size:1rem; border-bottom:1px solid #f3f4f6; padding-bottom:.75rem; margin-bottom:1rem; }
.tf-stat-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(180px,1fr)); gap:1rem; }
.tf-stat { background:#f9fafb; border-radius:6px; padding:1rem; }
.tf-stat .label { font-size:.8rem; color:#6b7280; margin-bottom:.25rem; }
.tf-stat .value { font-size:1.25rem; font-weight:600; color:#111827; }
.tf-badge { display:inline-block; padding:.15rem .5rem; border-radius:4px; font-size:.75rem; font-weight:600; }
.tf-badge-green  { background:#dcfce7; color:#166534; }
.tf-badge-red    { background:#fee2e2; color:#991b1b; }
.tf-badge-yellow { background:#fef9c3; color:#854d0e; }
.tf-token-table { width:100%; border-collapse:collapse; font-size:.875rem; }
.tf-token-table th { text-align:left; padding:.5rem .75rem; background:#f3f4f6; border-bottom:1px solid #e5e7eb; }
.tf-token-table td { padding:.5rem .75rem; border-bottom:1px solid #f3f4f6; }
.tf-token-table tr:last-child td { border-bottom:0; }
#tf-reindex-btn { position:relative; }
#tf-reindex-progress { display:none; margin-top:.75rem; font-size:.875rem; color:#6b7280; }
</style>

<h1><?php esc_html_e( 'ThemeFlex — AI Chat', 'themeflex' ); ?></h1>

<?php if ( $saved ) : ?>
<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Settings saved.', 'themeflex' ); ?></p></div>
<?php endif; ?>

<?php if ( $indexed ) : ?>
<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Re-index complete.', 'themeflex' ); ?></p></div>
<?php endif; ?>

<?php if ( ! $has_key ) : ?>
<div class="notice notice-warning"><p>
	<?php esc_html_e( 'No API key configured. Enter your key below to activate the AI chat widget.', 'themeflex' ); ?>
</p></div>
<?php endif; ?>

<!-- Provider + Key Settings -->
<div class="tf-card">
	<h2><?php esc_html_e( 'Provider & API Key', 'themeflex' ); ?></h2>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="themeflex_save_ai_settings">
		<?php wp_nonce_field( 'themeflex_ai_settings' ); ?>

		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="tf-provider"><?php esc_html_e( 'Provider', 'themeflex' ); ?></label></th>
				<td>
					<select name="themeflex_ai_provider" id="tf-provider">
						<?php foreach ( $providers_map as $pid => $plabel ) : ?>
						<option value="<?php echo esc_attr( $pid ); ?>" <?php selected( $provider_id, $pid ); ?>>
							<?php echo esc_html( $plabel ); ?>
						</option>
						<?php endforeach; ?>
					</select>
					<p class="description"><?php esc_html_e( 'Anthropic Claude is the recommended default.', 'themeflex' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="tf-apikey"><?php esc_html_e( 'API Key', 'themeflex' ); ?></label></th>
				<td>
					<input
						type="password"
						name="themeflex_ai_api_key_raw"
						id="tf-apikey"
						class="regular-text"
						placeholder="<?php echo $has_key ? esc_attr__( '(key already saved — leave blank to keep)', 'themeflex' ) : 'sk-ant-...'; ?>"
						autocomplete="off"
					>
					<p class="description">
						<?php if ( $has_key ) : ?>
						<span class="tf-badge tf-badge-green">✓ <?php esc_html_e( 'Key saved', 'themeflex' ); ?></span>
						<?php else : ?>
						<span class="tf-badge tf-badge-red"><?php esc_html_e( 'No key', 'themeflex' ); ?></span>
						<?php endif; ?>
					</p>
				</td>
			</tr>
		</table>

		<?php submit_button( __( 'Save Settings', 'themeflex' ) ); ?>
	</form>
</div>

<!-- Indexer Status -->
<div class="tf-card">
	<h2><?php esc_html_e( 'RAG Index Status', 'themeflex' ); ?></h2>

	<div class="tf-stat-grid">
		<div class="tf-stat">
			<div class="label"><?php esc_html_e( 'Status', 'themeflex' ); ?></div>
			<div class="value">
				<?php if ( $has_index ) : ?>
				<span class="tf-badge tf-badge-green">✓ <?php esc_html_e( 'Index exists', 'themeflex' ); ?></span>
				<?php else : ?>
				<span class="tf-badge tf-badge-yellow"><?php esc_html_e( 'Not indexed', 'themeflex' ); ?></span>
				<?php endif; ?>
			</div>
		</div>
		<div class="tf-stat">
			<div class="label"><?php esc_html_e( 'Last indexed', 'themeflex' ); ?></div>
			<div class="value"><?php echo $rag_meta['indexed_at'] ? esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $rag_meta['indexed_at'] ) ) ) : '—'; ?></div>
		</div>
		<div class="tf-stat">
			<div class="label"><?php esc_html_e( 'Pages indexed', 'themeflex' ); ?></div>
			<div class="value"><?php echo esc_html( $rag_meta['page_count'] ?: '—' ); ?></div>
		</div>
		<div class="tf-stat">
			<div class="label"><?php esc_html_e( 'Chunks stored', 'themeflex' ); ?></div>
			<div class="value"><?php echo esc_html( $rag_meta['chunk_count'] ?: '—' ); ?></div>
		</div>
	</div>

	<p style="margin-top:1rem;">
		<button
			type="button"
			id="tf-reindex-btn"
			class="button button-primary"
			<?php echo $has_key ? '' : 'disabled'; ?>
		><?php esc_html_e( '↺ Re-Index Now', 'themeflex' ); ?></button>
		<?php if ( ! $has_key ) : ?>
		<span style="margin-left:.75rem;color:#6b7280;font-size:.875rem;"><?php esc_html_e( '(requires API key)', 'themeflex' ); ?></span>
		<?php endif; ?>
	</p>
	<div id="tf-reindex-progress"></div>
</div>

<!-- Token Log -->
<div class="tf-card">
	<h2><?php esc_html_e( 'Token Usage — Last 30 Days', 'themeflex' ); ?></h2>

	<?php if ( empty( $token_log ) ) : ?>
	<p style="color:#6b7280;"><?php esc_html_e( 'No token usage recorded yet.', 'themeflex' ); ?></p>
	<?php else : ?>
	<table class="tf-token-table">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Date', 'themeflex' ); ?></th>
				<th><?php esc_html_e( 'Provider', 'themeflex' ); ?></th>
				<th><?php esc_html_e( 'Calls', 'themeflex' ); ?></th>
				<th><?php esc_html_e( 'Input tokens', 'themeflex' ); ?></th>
				<th><?php esc_html_e( 'Output tokens', 'themeflex' ); ?></th>
				<th><?php esc_html_e( 'Est. cost (USD)', 'themeflex' ); ?></th>
			</tr>
		</thead>
		<tbody>
		<?php
		$log_sorted = $token_log;
		usort( $log_sorted, static function ( array $a, array $b ): int {
			return strcmp( $b['date'], $a['date'] );
		} );
		foreach ( $log_sorted as $entry ) :
			$prov   = $entry['provider'] ?? 'anthropic';
			$rate   = $cost_rates[ $prov ] ?? $cost_rates['anthropic'];
			$cost   = ( $entry['input'] ?? 0 ) * $rate['in'] + ( $entry['output'] ?? 0 ) * $rate['out'];
			?>
			<tr>
				<td><?php echo esc_html( $entry['date'] ?? '' ); ?></td>
				<td><?php echo esc_html( $providers_map[ $prov ] ?? $prov ); ?></td>
				<td><?php echo esc_html( number_format( $entry['calls'] ?? 0 ) ); ?></td>
				<td><?php echo esc_html( number_format( $entry['input'] ?? 0 ) ); ?></td>
				<td><?php echo esc_html( number_format( $entry['output'] ?? 0 ) ); ?></td>
				<td>$<?php echo esc_html( number_format( $cost, 4 ) ); ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<p class="description" style="margin-top:.75rem;"><?php esc_html_e( 'Cost estimates are approximate. Actual billing depends on your provider plan.', 'themeflex' ); ?></p>
	<?php endif; ?>
</div>

<script>
(function(){
	var btn = document.getElementById('tf-reindex-btn');
	var prog = document.getElementById('tf-reindex-progress');
	if (!btn) return;

	btn.addEventListener('click', function(){
		btn.disabled = true;
		btn.textContent = '<?php echo esc_js( __( 'Indexing…', 'themeflex' ) ); ?>';
		prog.style.display = 'block';
		prog.textContent = '<?php echo esc_js( __( 'Running index — this may take a moment…', 'themeflex' ) ); ?>';

		var fd = new FormData();
		fd.append('action', 'themeflex_reindex');
		fd.append('nonce', '<?php echo esc_js( wp_create_nonce( 'themeflex_reindex_nonce' ) ); ?>');

		fetch('<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>', {
			method: 'POST',
			body: fd,
			credentials: 'same-origin',
		})
		.then(function(r){ return r.json(); })
		.then(function(data){
			if (data.success) {
				prog.textContent = '✓ ' + data.data.pages + ' <?php echo esc_js( __( 'pages,', 'themeflex' ) ); ?> ' + data.data.chunks + ' <?php echo esc_js( __( 'chunks indexed.', 'themeflex' ) ); ?>';
				prog.style.color = '#166534';
				setTimeout(function(){ location.reload(); }, 1500);
			} else {
				prog.textContent = '✗ ' + (data.data ? data.data.message : '<?php echo esc_js( __( 'Error', 'themeflex' ) ); ?>');
				prog.style.color = '#991b1b';
				btn.disabled = false;
				btn.textContent = '<?php echo esc_js( __( '↺ Re-Index Now', 'themeflex' ) ); ?>';
			}
		})
		.catch(function(){
			prog.textContent = '<?php echo esc_js( __( 'Request failed. Please try again.', 'themeflex' ) ); ?>';
			prog.style.color = '#991b1b';
			btn.disabled = false;
			btn.textContent = '<?php echo esc_js( __( '↺ Re-Index Now', 'themeflex' ) ); ?>';
		});
	});
})();
</script>
</div>
