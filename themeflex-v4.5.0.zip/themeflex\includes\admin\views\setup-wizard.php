<?php
/**
 * Admin View: Setup Wizard (3-Step Industry Wizard)
 *
 * Step 1 — Industry input (free text + autocomplete from 19 categories)
 * Step 2 — Suggestions (templates, skin preview, schema type)
 * Step 3 — Import confirmation + progress
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$nonce_match   = wp_create_nonce( 'tf_wizard_match' );
$nonce_dismiss = wp_create_nonce( 'tf_wizard_dismiss' );
$has_ai        = ThemeFlex_Provider_Factory::has_api_key();

// Skin color map for preview badges.
$skin_colors = array(
	'skin-light-blue'    => array( 'label' => 'Light Blue',    'hex' => '#3B82F6' ),
	'skin-light-purple'  => array( 'label' => 'Light Purple',  'hex' => '#8B5CF6' ),
	'skin-dark-energy'   => array( 'label' => 'Dark Energy',   'hex' => '#1F2937' ),
	'skin-rose-blush'    => array( 'label' => 'Rose Blush',    'hex' => '#F43F5E' ),
	'skin-warm-earth'    => array( 'label' => 'Warm Earth',    'hex' => '#D97706' ),
	'skin-corporate-navy'=> array( 'label' => 'Corporate Navy','hex' => '#1E3A5F' ),
	'skin-friendly-green'=> array( 'label' => 'Friendly Green','hex' => '#10B981' ),
	'skin-creative-dark' => array( 'label' => 'Creative Dark', 'hex' => '#111827' ),
	'skin-tech-dark'     => array( 'label' => 'Tech Dark',     'hex' => '#0F172A' ),
);

// All 19 category labels for autocomplete.
$category_hints = array(
	array( 'id' => 'health-medical',     'label' => __( 'Health & Medical',            'themeflex' ), 'label_de' => 'Gesundheit & Medizin' ),
	array( 'id' => 'wellness-therapy',   'label' => __( 'Wellness & Therapy',           'themeflex' ), 'label_de' => 'Wellness & Therapie' ),
	array( 'id' => 'fitness-sports',     'label' => __( 'Fitness & Sports',             'themeflex' ), 'label_de' => 'Fitness & Sport' ),
	array( 'id' => 'beauty-personal-care','label'=> __( 'Beauty & Personal Care',       'themeflex' ), 'label_de' => 'Beauty & Körperpflege' ),
	array( 'id' => 'food-hospitality',   'label' => __( 'Food & Hospitality',           'themeflex' ), 'label_de' => 'Gastronomie & Hotellerie' ),
	array( 'id' => 'legal-finance',      'label' => __( 'Legal & Finance',              'themeflex' ), 'label_de' => 'Recht & Finanzen' ),
	array( 'id' => 'real-estate',        'label' => __( 'Real Estate',                  'themeflex' ), 'label_de' => 'Immobilien' ),
	array( 'id' => 'education-coaching', 'label' => __( 'Education & Coaching',         'themeflex' ), 'label_de' => 'Bildung & Coaching' ),
	array( 'id' => 'creative-media',     'label' => __( 'Creative & Media',             'themeflex' ), 'label_de' => 'Kreativ & Medien' ),
	array( 'id' => 'technology-saas',    'label' => __( 'Technology & SaaS',            'themeflex' ), 'label_de' => 'Technologie & Software' ),
	array( 'id' => 'business-corporate', 'label' => __( 'Business & Corporate',         'themeflex' ), 'label_de' => 'Business & Unternehmen' ),
	array( 'id' => 'events-entertainment','label'=> __( 'Events & Entertainment',       'themeflex' ), 'label_de' => 'Events & Unterhaltung' ),
	array( 'id' => 'trades-home-services','label'=> __( 'Trades & Home Services',       'themeflex' ), 'label_de' => 'Handwerk & Haushaltsdienstleistungen' ),
	array( 'id' => 'pets-animals',       'label' => __( 'Pets & Animals',               'themeflex' ), 'label_de' => 'Tiere & Haustiere' ),
	array( 'id' => 'interior-design',    'label' => __( 'Interior Design',              'themeflex' ), 'label_de' => 'Innenarchitektur & Design' ),
	array( 'id' => 'nonprofit-community','label' => __( 'Nonprofit & Community',        'themeflex' ), 'label_de' => 'Gemeinnützig & Community' ),
	array( 'id' => 'travel-tourism',     'label' => __( 'Travel & Tourism',             'themeflex' ), 'label_de' => 'Reisen & Tourismus' ),
	array( 'id' => 'ecommerce-retail',   'label' => __( 'E-Commerce & Retail',          'themeflex' ), 'label_de' => 'E-Commerce & Handel' ),
	array( 'id' => 'general',            'label' => __( 'General / Other',              'themeflex' ), 'label_de' => 'Allgemein / Sonstige' ),
);
?>
<div class="wrap" id="tf-wizard-wrap">
<style>
/* ---- Reset ---- */
#tf-wizard-wrap { max-width:860px; }
#tf-wizard-wrap * { box-sizing:border-box; }

/* ---- Progress bar ---- */
.tf-wiz-steps { display:flex; align-items:center; gap:0; margin-bottom:2rem; }
.tf-wiz-step  { flex:1; text-align:center; position:relative; }
.tf-wiz-step + .tf-wiz-step::before {
	content:''; position:absolute; top:18px; left:0; right:100%; height:2px;
	background:#e5e7eb; width:100%;
}
.tf-wiz-dot {
	display:inline-flex; align-items:center; justify-content:center;
	width:36px; height:36px; border-radius:50%; border:2px solid #d1d5db;
	background:#fff; font-size:.875rem; font-weight:700; color:#9ca3af;
	position:relative; z-index:1;
}
.tf-wiz-step.active .tf-wiz-dot  { border-color:#2271b1; background:#2271b1; color:#fff; }
.tf-wiz-step.done   .tf-wiz-dot  { border-color:#16a34a; background:#16a34a; color:#fff; }
.tf-wiz-label { font-size:.75rem; color:#6b7280; margin-top:.35rem; display:block; }
.tf-wiz-step.active .tf-wiz-label { color:#2271b1; font-weight:600; }
.tf-wiz-step.done   .tf-wiz-label { color:#16a34a; }

/* ---- Cards ---- */
.tf-card {
	background:#fff; border:1px solid #e5e7eb; border-radius:10px;
	padding:1.75rem 2rem; margin-bottom:1.25rem;
}
.tf-card h2 { margin-top:0; font-size:1.15rem; margin-bottom:.25rem; }
.tf-card p.sub { color:#6b7280; font-size:.875rem; margin-top:.25rem; margin-bottom:1.25rem; }

/* ---- Inputs ---- */
.tf-field { margin-bottom:1rem; }
.tf-field label { display:block; font-weight:600; font-size:.875rem; margin-bottom:.35rem; }
.tf-field input[type=text],
.tf-field textarea {
	width:100%; padding:.6rem .75rem; border:1px solid #d1d5db; border-radius:6px;
	font-size:.9375rem; line-height:1.5;
}
.tf-field input[type=text]:focus,
.tf-field textarea:focus { outline:2px solid #2271b1; border-color:#2271b1; }
.tf-field .desc { font-size:.8rem; color:#6b7280; margin-top:.3rem; }

/* ---- Autocomplete dropdown ---- */
.tf-autocomplete {
	position:absolute; z-index:9999; background:#fff; border:1px solid #d1d5db;
	border-radius:6px; box-shadow:0 4px 12px rgba(0,0,0,.1);
	max-height:240px; overflow-y:auto; width:100%;
}
.tf-autocomplete-item {
	padding:.55rem .85rem; cursor:pointer; font-size:.875rem;
	display:flex; align-items:center; gap:.5rem;
}
.tf-autocomplete-item:hover,
.tf-autocomplete-item.focused { background:#f0f4ff; }
.tf-autocomplete-item .cat-id { color:#9ca3af; font-size:.75rem; margin-left:auto; }
.tf-field-wrap { position:relative; }

/* ---- Buttons ---- */
.tf-btn {
	display:inline-flex; align-items:center; gap:.4rem;
	padding:.6rem 1.25rem; border-radius:6px; font-size:.9375rem; font-weight:600;
	cursor:pointer; border:none; transition:background .15s;
}
.tf-btn-primary { background:#2271b1; color:#fff; }
.tf-btn-primary:hover:not(:disabled) { background:#135e96; }
.tf-btn-secondary { background:#f3f4f6; color:#374151; border:1px solid #d1d5db; }
.tf-btn-secondary:hover { background:#e5e7eb; }
.tf-btn:disabled { opacity:.55; cursor:not-allowed; }
.tf-btn-row { display:flex; gap:.75rem; align-items:center; margin-top:1.25rem; }

/* ---- Step panels ---- */
.tf-step-panel { display:none; }
.tf-step-panel.active { display:block; }

/* ---- AI badge ---- */
.tf-ai-badge {
	display:inline-flex; align-items:center; gap:.3rem;
	font-size:.75rem; padding:.2rem .5rem; border-radius:4px;
	background:#ede9fe; color:#5b21b6; font-weight:600;
}

/* ---- Result grid ---- */
.tf-result-header {
	display:flex; align-items:flex-start; justify-content:space-between;
	flex-wrap:wrap; gap:1rem; margin-bottom:1.5rem;
}
.tf-result-meta { flex:1; }
.tf-result-meta h3 { margin:0 0 .25rem; font-size:1.15rem; }
.tf-result-meta .tf-schema { font-size:.8rem; color:#6b7280; }
.tf-skin-badge {
	display:inline-flex; align-items:center; gap:.5rem;
	background:#f9fafb; border:1px solid #e5e7eb; border-radius:6px;
	padding:.5rem .85rem; font-size:.875rem; font-weight:600;
}
.tf-skin-dot { width:14px; height:14px; border-radius:50%; display:inline-block; }

.tf-template-grid {
	display:grid; grid-template-columns:repeat(auto-fill,minmax(160px,1fr)); gap:.75rem;
}
.tf-template-card {
	border:2px solid #e5e7eb; border-radius:8px; overflow:hidden;
	cursor:pointer; transition:border-color .15s, box-shadow .15s;
}
.tf-template-card:hover { border-color:#2271b1; box-shadow:0 2px 8px rgba(34,113,177,.15); }
.tf-template-card.selected { border-color:#2271b1; background:#f0f6ff; }
.tf-template-thumb {
	height:90px; background:linear-gradient(135deg,#e5e7eb 0%,#f3f4f6 100%);
	display:flex; align-items:center; justify-content:center;
	font-size:1.5rem; color:#9ca3af;
}
.tf-template-label {
	padding:.4rem .6rem; font-size:.75rem; font-weight:600; color:#374151;
	white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
}

/* ---- Import progress ---- */
.tf-import-progress { display:none; margin-top:1rem; }
.tf-progress-bar-wrap {
	background:#f3f4f6; border-radius:9999px; height:8px; overflow:hidden; margin-bottom:.6rem;
}
.tf-progress-bar { height:100%; background:#2271b1; border-radius:9999px; transition:width .4s; width:0%; }
.tf-progress-text { font-size:.875rem; color:#6b7280; }
.tf-import-done { display:none; }
.tf-import-done .tf-success-icon { font-size:2.5rem; }
.tf-import-done p { color:#374151; }

/* ---- Notices ---- */
.tf-notice {
	border-left:4px solid #2271b1; background:#f0f6ff;
	padding:.75rem 1rem; border-radius:0 6px 6px 0;
	font-size:.875rem; color:#1e3a5f; margin-bottom:1rem;
}
.tf-notice.warn { border-color:#d97706; background:#fffbeb; color:#92400e; }
.tf-notice.error { border-color:#dc2626; background:#fef2f2; color:#991b1b; }
</style>

<h1>
	<?php esc_html_e( 'ThemeFlex — Setup Wizard', 'themeflex' ); ?>
	<?php if ( $has_ai ) : ?>
	<span class="tf-ai-badge" style="margin-left:.75rem;">✦ <?php esc_html_e( 'AI-powered', 'themeflex' ); ?></span>
	<?php endif; ?>
</h1>

<!-- Step indicator -->
<div class="tf-wiz-steps" id="tf-step-indicator">
	<div class="tf-wiz-step active" data-step="1">
		<span class="tf-wiz-dot">1</span>
		<span class="tf-wiz-label"><?php esc_html_e( 'Your Business', 'themeflex' ); ?></span>
	</div>
	<div class="tf-wiz-step" data-step="2">
		<span class="tf-wiz-dot">2</span>
		<span class="tf-wiz-label"><?php esc_html_e( 'Templates', 'themeflex' ); ?></span>
	</div>
	<div class="tf-wiz-step" data-step="3">
		<span class="tf-wiz-dot">3</span>
		<span class="tf-wiz-label"><?php esc_html_e( 'Import', 'themeflex' ); ?></span>
	</div>
</div>

<!-- ====================================================
     STEP 1 — Industry input
     ==================================================== -->
<div id="tf-step-1" class="tf-step-panel active">
	<div class="tf-card">
		<h2><?php esc_html_e( 'What kind of business do you have?', 'themeflex' ); ?></h2>
		<p class="sub"><?php esc_html_e( 'Describe your industry and we\'ll recommend the best templates and design skin.', 'themeflex' ); ?></p>

		<?php if ( ! $has_ai ) : ?>
		<div class="tf-notice warn">
			<?php esc_html_e( 'Tip: Add an AI API key under ThemeFlex → AI Chat to get smarter industry matching.', 'themeflex' ); ?>
		</div>
		<?php endif; ?>

		<div class="tf-field">
			<label for="tf-industry-input"><?php esc_html_e( 'Your Industry or Business Type', 'themeflex' ); ?></label>
			<div class="tf-field-wrap">
				<input
					type="text"
					id="tf-industry-input"
					placeholder="<?php esc_attr_e( 'e.g. Physiotherapist, Restaurant, Software Startup…', 'themeflex' ); ?>"
					autocomplete="off"
					aria-autocomplete="list"
					aria-controls="tf-autocomplete-list"
				>
				<div id="tf-autocomplete-list" class="tf-autocomplete" role="listbox" hidden></div>
			</div>
			<p class="desc"><?php esc_html_e( 'Choose from suggestions or type freely.', 'themeflex' ); ?></p>
		</div>

		<div class="tf-field">
			<label for="tf-location-input"><?php esc_html_e( 'Location (optional)', 'themeflex' ); ?></label>
			<input type="text" id="tf-location-input" placeholder="<?php esc_attr_e( 'e.g. Berlin, Wien, Zürich…', 'themeflex' ); ?>">
			<p class="desc"><?php esc_html_e( 'Helps tailor the recommendation for regional industries.', 'themeflex' ); ?></p>
		</div>

		<div class="tf-field">
			<label for="tf-usp-input"><?php esc_html_e( 'Your Unique Selling Point (optional)', 'themeflex' ); ?></label>
			<input type="text" id="tf-usp-input" placeholder="<?php esc_attr_e( 'e.g. Family-run since 1990, Certified organic, 24/7 service…', 'themeflex' ); ?>">
		</div>

		<div class="tf-btn-row">
			<button type="button" id="tf-step1-next" class="tf-btn tf-btn-primary">
				<?php esc_html_e( 'Find Templates', 'themeflex' ); ?> →
			</button>
			<span id="tf-step1-spinner" style="display:none;color:#6b7280;font-size:.875rem;">
				<?php esc_html_e( 'Matching your industry…', 'themeflex' ); ?>
			</span>
			<span id="tf-step1-error" style="display:none;color:#dc2626;font-size:.875rem;"></span>
		</div>
	</div>
</div>

<!-- ====================================================
     STEP 2 — Suggestions
     ==================================================== -->
<div id="tf-step-2" class="tf-step-panel">
	<div class="tf-card">
		<div class="tf-result-header">
			<div class="tf-result-meta">
				<h2 id="tf-result-label"><?php esc_html_e( 'Recommended Templates', 'themeflex' ); ?></h2>
				<p class="sub" id="tf-result-sub"></p>
				<p class="tf-schema">
					<?php esc_html_e( 'Schema.org type:', 'themeflex' ); ?>
					<strong id="tf-result-schema">—</strong>
				</p>
			</div>
			<div>
				<div class="tf-skin-badge">
					<span class="tf-skin-dot" id="tf-skin-dot"></span>
					<span id="tf-skin-label"><?php esc_html_e( 'Recommended Skin', 'themeflex' ); ?></span>
				</div>
			</div>
		</div>

		<p style="font-weight:600;margin-bottom:.6rem;"><?php esc_html_e( 'Select a template to import:', 'themeflex' ); ?></p>
		<div class="tf-template-grid" id="tf-template-grid">
			<!-- Populated by JS -->
		</div>

		<div class="tf-btn-row">
			<button type="button" id="tf-step2-back" class="tf-btn tf-btn-secondary">
				← <?php esc_html_e( 'Back', 'themeflex' ); ?>
			</button>
			<button type="button" id="tf-step2-next" class="tf-btn tf-btn-primary" disabled>
				<?php esc_html_e( 'Continue with selection', 'themeflex' ); ?> →
			</button>
		</div>
	</div>
</div>

<!-- ====================================================
     STEP 3 — Import confirmation + progress
     ==================================================== -->
<div id="tf-step-3" class="tf-step-panel">
	<div class="tf-card">
		<h2><?php esc_html_e( 'Ready to Import', 'themeflex' ); ?></h2>
		<p class="sub"><?php esc_html_e( 'Review the details below then start the import.', 'themeflex' ); ?></p>

		<table class="form-table" role="presentation" style="margin-bottom:1rem;">
			<tr>
				<th scope="row" style="width:160px;"><?php esc_html_e( 'Template', 'themeflex' ); ?></th>
				<td><strong id="tf-confirm-template">—</strong></td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Category', 'themeflex' ); ?></th>
				<td id="tf-confirm-category">—</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Skin', 'themeflex' ); ?></th>
				<td id="tf-confirm-skin">—</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Schema.org', 'themeflex' ); ?></th>
				<td><code id="tf-confirm-schema">—</code></td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Content depth', 'themeflex' ); ?></th>
				<td>
					<select id="tf-depth-select" style="min-width:240px;">
						<option value="headlines"><?php esc_html_e( 'Headlines only (fast)', 'themeflex' ); ?></option>
						<option value="short" selected><?php esc_html_e( 'Headlines + short text', 'themeflex' ); ?></option>
						<option value="full"><?php esc_html_e( 'Full content incl. FAQ', 'themeflex' ); ?></option>
					</select>
				</td>
			</tr>
		</table>

		<div class="tf-notice">
			<?php esc_html_e( 'The import will create new pages using placeholder content. Your existing pages are not affected.', 'themeflex' ); ?>
		</div>

		<div class="tf-btn-row">
			<button type="button" id="tf-step3-back" class="tf-btn tf-btn-secondary">
				← <?php esc_html_e( 'Back', 'themeflex' ); ?>
			</button>
			<button type="button" id="tf-step3-import" class="tf-btn tf-btn-primary">
				⬇ <?php esc_html_e( 'Start Import', 'themeflex' ); ?>
			</button>
		</div>

		<!-- Progress -->
		<div class="tf-import-progress" id="tf-import-progress">
			<div class="tf-progress-bar-wrap">
				<div class="tf-progress-bar" id="tf-progress-bar"></div>
			</div>
			<p class="tf-progress-text" id="tf-progress-text"><?php esc_html_e( 'Preparing…', 'themeflex' ); ?></p>
		</div>

		<!-- Done -->
		<div class="tf-import-done" id="tf-import-done">
			<div class="tf-success-icon">🎉</div>
			<p>
				<strong><?php esc_html_e( 'Import complete!', 'themeflex' ); ?></strong>
				<?php esc_html_e( 'Your pages have been created.', 'themeflex' ); ?>
			</p>
			<div class="tf-btn-row">
				<a id="tf-view-pages" href="<?php echo esc_url( admin_url( 'edit.php?post_type=page' ) ); ?>" class="tf-btn tf-btn-primary">
					<?php esc_html_e( 'View Pages', 'themeflex' ); ?>
				</a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=themeflex-setup-wizard' ) ); ?>" class="tf-btn tf-btn-secondary">
					<?php esc_html_e( 'Run Wizard Again', 'themeflex' ); ?>
				</a>
			</div>
		</div>
	</div>
</div>

<script>
(function(){
'use strict';

/* ---------- Data ---------- */
var CATEGORIES = <?php echo wp_json_encode( $category_hints ); ?>;
var SKIN_COLORS = <?php echo wp_json_encode( $skin_colors ); ?>;
var AJAX_URL    = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
var NONCE_MATCH = <?php echo wp_json_encode( $nonce_match ); ?>;
var NONCE_IMPORT = <?php echo wp_json_encode( wp_create_nonce( 'tf_wizard_import' ) ); ?>;

/* ---------- State ---------- */
var state = { step:1, result:null, selectedTemplate:null };

/* ---------- DOM refs ---------- */
var steps    = [null,
	document.getElementById('tf-step-1'),
	document.getElementById('tf-step-2'),
	document.getElementById('tf-step-3')
];
var dots = document.querySelectorAll('.tf-wiz-step');

var elIndustry  = document.getElementById('tf-industry-input');
var elLocation  = document.getElementById('tf-location-input');
var elUsp       = document.getElementById('tf-usp-input');
var elAutoList  = document.getElementById('tf-autocomplete-list');
var elSpinner   = document.getElementById('tf-step1-spinner');
var elError     = document.getElementById('tf-step1-error');
var elStep1Next = document.getElementById('tf-step1-next');
var elStep2Back = document.getElementById('tf-step2-back');
var elStep2Next = document.getElementById('tf-step2-next');
var elStep3Back = document.getElementById('tf-step3-back');
var elStep3Imp  = document.getElementById('tf-step3-import');
var elGrid      = document.getElementById('tf-template-grid');
var elProgress  = document.getElementById('tf-import-progress');
var elProgressB = document.getElementById('tf-progress-bar');
var elProgressT = document.getElementById('tf-progress-text');
var elDone      = document.getElementById('tf-import-done');

/* ---------- Step navigation ---------- */
function goStep(n){
	state.step = n;
	steps.forEach(function(el, i){ if(el){ el.classList.toggle('active', i===n); } });
	dots.forEach(function(dot, i){
		var s = i+1;
		dot.classList.toggle('active', s===n);
		dot.classList.toggle('done', s<n);
	});
	window.scrollTo(0,0);
}

/* ---------- Autocomplete ---------- */
var acFocused = -1;

function filterCats(q){
	if(!q) return [];
	q = q.toLowerCase();
	return CATEGORIES.filter(function(c){
		return c.label.toLowerCase().indexOf(q)!==-1 ||
		       c.label_de.toLowerCase().indexOf(q)!==-1 ||
		       c.id.indexOf(q)!==-1;
	}).slice(0,8);
}

function renderAutoComplete(items){
	if(!items.length){ elAutoList.hidden=true; return; }
	elAutoList.innerHTML = items.map(function(c,i){
		return '<div class="tf-autocomplete-item" role="option" data-id="'+c.id+'" data-label="'+c.label+'" data-idx="'+i+'">'
			+'<span>'+c.label+'</span>'
			+'<span class="cat-id">'+c.label_de+'</span>'
			+'</div>';
	}).join('');
	elAutoList.hidden = false;
	acFocused = -1;
	elAutoList.querySelectorAll('.tf-autocomplete-item').forEach(function(el){
		el.addEventListener('mousedown', function(e){
			e.preventDefault();
			elIndustry.value = el.dataset.label;
			elAutoList.hidden = true;
		});
	});
}

elIndustry.addEventListener('input', function(){
	renderAutoComplete(filterCats(this.value));
});

elIndustry.addEventListener('keydown', function(e){
	var items = elAutoList.querySelectorAll('.tf-autocomplete-item');
	if(e.key==='ArrowDown'){ acFocused=Math.min(acFocused+1,items.length-1); }
	else if(e.key==='ArrowUp'){ acFocused=Math.max(acFocused-1,0); }
	else if(e.key==='Enter'&&acFocused>=0){ e.preventDefault(); items[acFocused].dispatchEvent(new MouseEvent('mousedown')); return; }
	else if(e.key==='Escape'){ elAutoList.hidden=true; return; }
	items.forEach(function(el,i){ el.classList.toggle('focused',i===acFocused); });
});

document.addEventListener('click', function(e){
	if(!elAutoList.contains(e.target)&&e.target!==elIndustry) elAutoList.hidden=true;
});

/* ---------- Step 1 → 2 ---------- */
elStep1Next.addEventListener('click', function(){
	var kw = elIndustry.value.trim();
	if(!kw){ elError.textContent='<?php echo esc_js( __( 'Please enter your business type.', 'themeflex' ) ); ?>'; elError.style.display='inline'; return; }
	elError.style.display='none';
	elStep1Next.disabled=true;
	elSpinner.style.display='inline';

	var fd = new FormData();
	fd.append('action','themeflex_wizard_match');
	fd.append('nonce', NONCE_MATCH);
	fd.append('keyword', kw);
	fd.append('location', elLocation.value.trim());
	fd.append('usp', elUsp.value.trim());

	fetch(AJAX_URL,{method:'POST',body:fd,credentials:'same-origin'})
	.then(function(r){return r.json();})
	.then(function(data){
		elStep1Next.disabled=false;
		elSpinner.style.display='none';
		if(!data.success){
			elError.textContent=data.data?data.data.message:'<?php echo esc_js( __( 'Match failed. Try again.', 'themeflex' ) ); ?>';
			elError.style.display='inline';
			return;
		}
		state.result = data.data;
		renderStep2(data.data);
		goStep(2);
	})
	.catch(function(){
		elStep1Next.disabled=false;
		elSpinner.style.display='none';
		elError.textContent='<?php echo esc_js( __( 'Connection error. Please try again.', 'themeflex' ) ); ?>';
		elError.style.display='inline';
	});
});

/* ---------- Render Step 2 ---------- */
function renderStep2(res){
	// Header
	document.getElementById('tf-result-label').textContent = res.category_label;
	document.getElementById('tf-result-sub').textContent =
		'<?php echo esc_js( __( 'Industry match:', 'themeflex' ) ); ?> ' + res.category_id;
	document.getElementById('tf-result-schema').textContent = res.schema_type;

	// Skin
	var skinInfo = SKIN_COLORS[res.skin] || {label:res.skin, hex:'#9ca3af'};
	document.getElementById('tf-skin-dot').style.background = skinInfo.hex;
	document.getElementById('tf-skin-label').textContent = skinInfo.label;

	// Templates
	elGrid.innerHTML = '';
	state.selectedTemplate = null;
	elStep2Next.disabled = true;

	(res.templates||[]).forEach(function(tpl){
		var card = document.createElement('div');
		card.className = 'tf-template-card';
		card.dataset.tpl = tpl;

		// Pick an icon emoji based on category prefix
		var icon = iconForCategory(res.category_id);
		card.innerHTML =
			'<div class="tf-template-thumb">'+icon+'</div>'+
			'<div class="tf-template-label" title="'+tpl+'">'+tpl.replace('page-','').replace(/-/g,' ')+'</div>';

		card.addEventListener('click',function(){
			elGrid.querySelectorAll('.tf-template-card').forEach(function(c){c.classList.remove('selected');});
			card.classList.add('selected');
			state.selectedTemplate = tpl;
			elStep2Next.disabled = false;
		});
		elGrid.appendChild(card);
	});
}

function iconForCategory(id){
	var map={
		'health-medical':'🏥','wellness-therapy':'🧘','fitness-sports':'💪',
		'beauty-personal-care':'💅','food-hospitality':'🍽️','legal-finance':'⚖️',
		'real-estate':'🏡','education-coaching':'📚','creative-media':'🎨',
		'technology-saas':'💻','business-corporate':'🏢','events-entertainment':'🎉',
		'trades-home-services':'🔧','pets-animals':'🐾','interior-design':'🛋️',
		'nonprofit-community':'🤝','travel-tourism':'✈️','ecommerce-retail':'🛒','general':'🌐'
	};
	return map[id]||'📄';
}

/* ---------- Step 2 → 3 ---------- */
elStep2Back.addEventListener('click',function(){ goStep(1); });
elStep2Next.addEventListener('click',function(){
	if(!state.selectedTemplate) return;
	var res = state.result;
	document.getElementById('tf-confirm-template').textContent = state.selectedTemplate;
	document.getElementById('tf-confirm-category').textContent = res.category_label;
	var skinInfo = SKIN_COLORS[res.skin]||{label:res.skin,hex:'#9ca3af'};
	document.getElementById('tf-confirm-skin').textContent = skinInfo.label;
	document.getElementById('tf-confirm-schema').textContent = res.schema_type;
	goStep(3);
});

/* ---------- Step 3 — Import ---------- */
elStep3Back.addEventListener('click',function(){ goStep(2); });

elStep3Imp.addEventListener('click',function(){
	elStep3Imp.disabled=true;
	elStep3Back.disabled=true;
	elProgress.style.display='block';
	elDone.style.display='none';

	var depth = document.getElementById('tf-depth-select').value;
	var fd = new FormData();
	fd.append('action','themeflex_import_demo');
	fd.append('nonce', NONCE_IMPORT);
	fd.append('template', state.selectedTemplate);
	fd.append('category', state.result.category_id);
	fd.append('skin', state.result.skin);
	fd.append('schema', state.result.schema_type);
	fd.append('depth', depth);

	// Simulate progress steps while waiting for response.
	var pct = 0;
	var msgs = [
		'<?php echo esc_js( __( 'Creating pages…', 'themeflex' ) ); ?>',
		'<?php echo esc_js( __( 'Importing placeholder content…', 'themeflex' ) ); ?>',
		'<?php echo esc_js( __( 'Applying skin settings…', 'themeflex' ) ); ?>',
		'<?php echo esc_js( __( 'Finalising…', 'themeflex' ) ); ?>',
	];
	var msgIdx = 0;
	var timer = setInterval(function(){
		if(pct<85){ pct+=5; elProgressB.style.width=pct+'%'; }
		if(msgIdx<msgs.length-1&&pct>20*msgIdx){ elProgressT.textContent=msgs[msgIdx++]; }
	},300);

	fetch(AJAX_URL,{method:'POST',body:fd,credentials:'same-origin'})
	.then(function(r){return r.json();})
	.then(function(data){
		clearInterval(timer);
		elProgressB.style.width='100%';
		if(data.success){
			elProgressT.textContent='<?php echo esc_js( __( 'Done!', 'themeflex' ) ); ?>';
			setTimeout(function(){
				elProgress.style.display='none';
				elDone.style.display='block';
				if(data.data&&data.data.pages_url){
					document.getElementById('tf-view-pages').href=data.data.pages_url;
				}
			},600);
		}else{
			elProgressT.textContent='✗ '+(data.data?data.data.message:'<?php echo esc_js( __( 'Import failed.', 'themeflex' ) ); ?>');
			elProgressT.style.color='#dc2626';
			elStep3Imp.disabled=false;
			elStep3Back.disabled=false;
		}
	})
	.catch(function(){
		clearInterval(timer);
		elProgressT.textContent='<?php echo esc_js( __( 'Connection error. Please try again.', 'themeflex' ) ); ?>';
		elProgressT.style.color='#dc2626';
		elStep3Imp.disabled=false;
		elStep3Back.disabled=false;
	});
});

})();
</script>
</div>
