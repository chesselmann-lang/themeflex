<?php
/**
 * Chat Endpoint Handler
 *
 * Registers POST themeflex/v1/chat/ and handles:
 *  1. DSGVO consent check (cookie "themeflex_consent" must contain "ai")
 *  2. RAG retrieval — Top-3 chunks
 *  3. Provider API call with injected context
 *  4. Confidence check — low-confidence returns contact-form prefill URL
 *  5. Token logging to wp_options (rolling 30-day log)
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ThemeFlex_Chat_Endpoint
 */
class ThemeFlex_Chat_Endpoint {

	/**
	 * Confidence threshold below which we suggest the contact form.
	 *
	 * @var float
	 */
	const CONFIDENCE_THRESHOLD = 0.4;

	/**
	 * wp_options key for rolling token log.
	 *
	 * @var string
	 */
	const OPTION_TOKEN_LOG = 'themeflex_ai_token_log';

	/**
	 * How many days to keep in the rolling log.
	 *
	 * @var int
	 */
	const LOG_DAYS = 30;

	/**
	 * Register hooks.
	 */
	public static function init(): void {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * Register REST route.
	 */
	public static function register_routes(): void {
		register_rest_route(
			'themeflex/v1',
			'/chat/',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_chat' ),
				'permission_callback' => '__return_true', // Public — consent checked in handler.
				'args'                => array(
					'message' => array(
						'type'              => 'string',
						'required'          => true,
						'sanitize_callback' => 'sanitize_textarea_field',
						'validate_callback' => static function ( $value ): bool {
							return is_string( $value ) && mb_strlen( trim( $value ) ) >= 3;
						},
					),
					'debug'   => array(
						'type'    => 'boolean',
						'default' => false,
					),
				),
			)
		);
	}

	/**
	 * Handle POST /chat/ requests.
	 *
	 * @param  WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public static function handle_chat( WP_REST_Request $request ): WP_REST_Response {
		// 1. Nonce verification (basic CSRF protection for logged-in users).
		//    Public users rely on the consent gate below.

		// 2. DSGVO consent check.
		if ( ! self::has_ai_consent() ) {
			return new WP_REST_Response(
				array(
					'success'       => false,
					'error'         => 'consent_required',
					'message'       => __( 'Please accept AI cookies to use the chat assistant.', 'themeflex' ),
					'consent_modal' => true,
				),
				403
			);
		}

		// 3. Check API key configured.
		if ( ! ThemeFlex_Provider_Factory::has_api_key() ) {
			return new WP_REST_Response(
				array(
					'success'    => false,
					'error'      => 'no_api_key',
					'setup_url'  => admin_url( 'admin.php?page=themeflex-ai-chat' ),
					'message'    => __( 'The AI chat is not yet configured. Please contact the site administrator.', 'themeflex' ),
				),
				503
			);
		}

		$user_message = sanitize_textarea_field( $request->get_param( 'message' ) );
		$debug        = (bool) $request->get_param( 'debug' ) && current_user_can( 'manage_options' );

		// 4. RAG retrieval.
		$chunks  = ThemeFlex_RAG_Retriever::retrieve( $user_message );
		$context = ThemeFlex_RAG_Retriever::format_context( $chunks );

		// 5. Build system prompt.
		$system_prompt = self::build_system_prompt( $context );

		// 6. Provider call.
		try {
			$provider = ThemeFlex_Provider_Factory::make();
			$result   = $provider->chat( $system_prompt, $user_message, 0.6, 600 );
		} catch ( RuntimeException $e ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'error'   => 'provider_error',
					'message' => __( 'AI service temporarily unavailable. Please try again.', 'themeflex' ),
				),
				502
			);
		}

		// 7. Log token usage.
		self::log_tokens(
			get_option( ThemeFlex_Provider_Factory::OPTION_PROVIDER, 'anthropic' ),
			$result['input_tokens'],
			$result['output_tokens']
		);

		// 8. Confidence check — if no RAG chunks matched, confidence is low.
		$confidence   = empty( $chunks ) ? 0.2 : ( $chunks[0]['score'] * 2.5 );
		$confidence   = min( 1.0, max( 0.0, (float) $confidence ) );
		$contact_url  = null;

		if ( $confidence < self::CONFIDENCE_THRESHOLD ) {
			$contact_page = get_page_by_path( 'contact' );
			$base_url     = $contact_page ? get_permalink( $contact_page ) : home_url( '/contact/' );
			$contact_url  = add_query_arg(
				array( 'subject' => rawurlencode( mb_substr( $user_message, 0, 80 ) ) ),
				$base_url
			);
		}

		// 9. Build response.
		$response = array(
			'success'     => true,
			'content'     => $result['content'],
			'confidence'  => round( $confidence, 2 ),
			'contact_url' => $contact_url,
		);

		if ( $debug ) {
			$response['_debug'] = array(
				'provider'      => $provider->get_name(),
				'input_tokens'  => $result['input_tokens'],
				'output_tokens' => $result['output_tokens'],
				'chunks_used'   => count( $chunks ),
				'top_chunk_score' => $chunks[0]['score'] ?? 0,
				'system_prompt_length' => mb_strlen( $system_prompt ),
			);
		}

		return new WP_REST_Response( $response, 200 );
	}

	// -----------------------------------------------------------------------
	// Helpers
	// -----------------------------------------------------------------------

	/**
	 * Check whether the visitor has accepted the "ai" consent category.
	 *
	 * The cookie "themeflex_consent" is a comma-separated list of accepted
	 * categories, e.g. "necessary,statistics,ai".
	 *
	 * @return bool
	 */
	private static function has_ai_consent(): bool {
		if ( ! isset( $_COOKIE['themeflex_consent'] ) ) {
			return false;
		}

		$consent    = sanitize_text_field( wp_unslash( $_COOKIE['themeflex_consent'] ) );
		$categories = array_map( 'trim', explode( ',', $consent ) );
		return in_array( 'ai', $categories, true );
	}

	/**
	 * Build the system prompt, injecting RAG context.
	 *
	 * @param  string $context  Formatted context from the retriever.
	 * @return string
	 */
	private static function build_system_prompt( string $context ): string {
		$site_name = get_bloginfo( 'name' );
		$site_desc = get_bloginfo( 'description' );

		$base = "You are a helpful assistant for {$site_name} — {$site_desc}. "
			. "Answer questions based on the information provided below. "
			. "If the answer is not in the provided information, say so honestly and suggest the visitor contacts the team. "
			. "Keep answers concise (2-4 sentences). Respond in the same language as the user's question.";

		if ( ! empty( $context ) ) {
			$base .= "\n\n" . $context;
		}

		return $base;
	}

	/**
	 * Append a token usage entry to the rolling 30-day log.
	 *
	 * Log is stored in wp_options as a JSON array of daily buckets:
	 * [ { date: "2026-05-01", provider: "anthropic", input: 1234, output: 567 }, ... ]
	 *
	 * @param  string $provider       Provider identifier.
	 * @param  int    $input_tokens   Prompt tokens.
	 * @param  int    $output_tokens  Completion tokens.
	 */
	private static function log_tokens( string $provider, int $input_tokens, int $output_tokens ): void {
		$log    = get_option( self::OPTION_TOKEN_LOG, array() );
		if ( ! is_array( $log ) ) {
			$log = array();
		}

		$today = gmdate( 'Y-m-d' );
		$found = false;

		foreach ( $log as &$entry ) {
			if ( isset( $entry['date'], $entry['provider'] )
				&& $entry['date'] === $today
				&& $entry['provider'] === $provider ) {
				$entry['input']  += $input_tokens;
				$entry['output'] += $output_tokens;
				$entry['calls']   = ( $entry['calls'] ?? 0 ) + 1;
				$found = true;
				break;
			}
		}
		unset( $entry );

		if ( ! $found ) {
			$log[] = array(
				'date'     => $today,
				'provider' => $provider,
				'input'    => $input_tokens,
				'output'   => $output_tokens,
				'calls'    => 1,
			);
		}

		// Prune entries older than LOG_DAYS.
		$cutoff = gmdate( 'Y-m-d', strtotime( '-' . self::LOG_DAYS . ' days' ) );
		$log    = array_filter(
			$log,
			static function ( array $entry ) use ( $cutoff ): bool {
				return isset( $entry['date'] ) && $entry['date'] >= $cutoff;
			}
		);

		update_option( self::OPTION_TOKEN_LOG, array_values( $log ), false );
	}
}

/**
 * Enqueue widget assets and inject HTML.
 */
class ThemeFlex_Chat_Widget {

	/**
	 * Register hooks.
	 */
	public static function init(): void {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'wp_footer', array( __CLASS__, 'render_widget' ) );
	}

	/**
	 * Enqueue CSS + JS, localise config.
	 */
	public static function enqueue_assets(): void {
		// Only load if chat is enabled (provider set) or in preview.
		if ( ! ThemeFlex_Provider_Factory::has_api_key() && ! is_customize_preview() ) {
			// Still load CSS so the toggle button is visible (shows setup prompt).
		}

		$ver = wp_get_theme()->get( 'Version' );

		wp_enqueue_style(
			'tf-ai-chat-widget',
			get_template_directory_uri() . '/assets/css/ai-chat-widget.css',
			array(),
			$ver
		);

		wp_enqueue_script(
			'tf-ai-chat-widget',
			get_template_directory_uri() . '/assets/js/ai-chat-widget.js',
			array(),
			$ver,
			true // Footer.
		);

		// Localise config.
		$contact_page = get_page_by_path( 'contact' );
		wp_localize_script(
			'tf-ai-chat-widget',
			'tfChatConfig',
			array(
				'endpoint'       => rest_url( 'themeflex/v1/chat/' ),
				'nonce'          => wp_create_nonce( 'wp_rest' ),
				'siteName'       => get_bloginfo( 'name' ),
				'debug'          => current_user_can( 'manage_options' ),
				'welcomeText'    => __( "Hi! I'm the AI assistant for this website. How can I help you?", 'themeflex' ),
				'consentText'    => __( 'To use the AI assistant, please accept the "AI Functions" category in our cookie settings.', 'themeflex' ),
				'consentBtnLabel'=> __( 'Manage Cookies', 'themeflex' ),
				'errorText'      => __( 'Something went wrong. Please try again or contact us directly.', 'themeflex' ),
				'contactLabel'   => __( 'Send us a message', 'themeflex' ),
			)
		);
	}

	/**
	 * Output the widget HTML in wp_footer.
	 */
	public static function render_widget(): void {
		?>
		<div id="tf-chat-wrap" class="tf-chat-wrap" aria-live="polite">
			<button
				id="tf-chat-toggle"
				class="tf-chat-toggle"
				aria-label="<?php esc_attr_e( 'Open AI chat assistant', 'themeflex' ); ?>"
				aria-expanded="false"
				aria-controls="tf-chat-window"
			>
				<!-- Chat icon -->
				<svg class="tf-icon-chat" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
					<path stroke-linecap="round" stroke-linejoin="round" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
				</svg>
				<!-- Close icon -->
				<svg class="tf-icon-close" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
					<path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
				</svg>
			</button>

			<div
				id="tf-chat-window"
				class="tf-chat-window"
				role="dialog"
				aria-label="<?php esc_attr_e( 'AI Chat Assistant', 'themeflex' ); ?>"
				hidden
			>
				<!-- Header -->
				<div class="tf-chat-header">
					<div class="tf-chat-header-avatar" aria-hidden="true">
						<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
							<path stroke-linecap="round" stroke-linejoin="round" d="M9.75 3.104v5.714a2.25 2.25 0 01-.659 1.591L5 14.5M9.75 3.104c-.251.023-.501.05-.75.082m.75-.082a24.301 24.301 0 014.5 0m0 0v5.714c0 .597.237 1.17.659 1.591L19.8 15.3M14.25 3.104c.251.023.501.05.75.082M19.8 15.3l-1.57.393A9.065 9.065 0 0112 15a9.065 9.065 0 00-6.23-.693L5 14.5m14.8.8l1.402 1.402c1 1 .23 2.798-1.144 2.798H4.942c-1.374 0-2.144-1.798-1.144-2.798L5 14.5" />
						</svg>
					</div>
					<div>
						<div class="tf-chat-header-title"><?php esc_html_e( 'AI Assistant', 'themeflex' ); ?></div>
						<div class="tf-chat-header-status"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></div>
					</div>
				</div>

				<!-- Messages -->
				<div id="tf-chat-messages" class="tf-chat-messages" role="log" aria-label="<?php esc_attr_e( 'Chat messages', 'themeflex' ); ?>">
				</div>

				<!-- Input -->
				<div class="tf-chat-input-area">
					<textarea
						id="tf-chat-input"
						class="tf-chat-input"
						placeholder="<?php esc_attr_e( 'Type your question…', 'themeflex' ); ?>"
						rows="1"
						maxlength="800"
						aria-label="<?php esc_attr_e( 'Your message', 'themeflex' ); ?>"
					></textarea>
					<button
						id="tf-chat-send"
						class="tf-chat-send"
						aria-label="<?php esc_attr_e( 'Send message', 'themeflex' ); ?>"
					>
						<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
							<path stroke-linecap="round" stroke-linejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
						</svg>
					</button>
				</div>

				<!-- Footer -->
				<div class="tf-chat-footer">
					<?php esc_html_e( 'Powered by AI · Answers may not be perfect', 'themeflex' ); ?>
				</div>
			</div>
		</div>
		<?php
	}
}

// Auto-init both classes.
ThemeFlex_Chat_Endpoint::init();
ThemeFlex_Chat_Widget::init();
