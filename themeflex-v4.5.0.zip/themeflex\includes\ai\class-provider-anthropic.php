<?php
/**
 * Anthropic Claude Provider Adapter
 *
 * Implements ThemeFlex_AI_Provider for Anthropic's Messages API.
 * Default provider for ThemeFlex v4.0.
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ThemeFlex_Provider_Anthropic
 */
class ThemeFlex_Provider_Anthropic implements ThemeFlex_AI_Provider {

	/**
	 * Anthropic Messages API endpoint.
	 *
	 * @var string
	 */
	const API_ENDPOINT = 'https://api.anthropic.com/v1/messages';

	/**
	 * Anthropic API version header value.
	 *
	 * @var string
	 */
	const API_VERSION = '2023-06-01';

	/**
	 * Default model.
	 *
	 * @var string
	 */
	const DEFAULT_MODEL = 'claude-3-5-haiku-20241022';

	/**
	 * API key.
	 *
	 * @var string
	 */
	private string $api_key;

	/**
	 * Model identifier.
	 *
	 * @var string
	 */
	private string $model;

	/**
	 * Constructor.
	 *
	 * @param string $api_key API key (from wp_options, already decrypted).
	 * @param string $model   Optional model override.
	 */
	public function __construct( string $api_key, string $model = self::DEFAULT_MODEL ) {
		$this->api_key = $api_key;
		$this->model   = $model;
	}

	/**
	 * {@inheritdoc}
	 */
	public function chat( string $system_prompt, string $user_message, float $temperature = 0.7, int $max_tokens = 800 ): array {
		$body = wp_json_encode(
			array(
				'model'       => $this->model,
				'max_tokens'  => $max_tokens,
				'temperature' => $temperature,
				'system'      => $system_prompt,
				'messages'    => array(
					array(
						'role'    => 'user',
						'content' => $user_message,
					),
				),
			)
		);

		$response = wp_remote_post(
			self::API_ENDPOINT,
			array(
				'timeout' => 30,
				'headers' => array(
					'x-api-key'         => $this->api_key,
					'anthropic-version' => self::API_VERSION,
					'content-type'      => 'application/json',
				),
				'body'    => $body,
			)
		);

		if ( is_wp_error( $response ) ) {
			throw new RuntimeException(
				'Anthropic API request failed: ' . $response->get_error_message()
			);
		}

		$code = wp_remote_retrieve_response_code( $response );
		$raw  = wp_remote_retrieve_body( $response );
		$data = json_decode( $raw, true );

		if ( 200 !== (int) $code ) {
			$error = isset( $data['error']['message'] ) ? $data['error']['message'] : $raw;
			throw new RuntimeException( 'Anthropic API error ' . $code . ': ' . $error );
		}

		$content       = $data['content'][0]['text'] ?? '';
		$input_tokens  = $data['usage']['input_tokens'] ?? 0;
		$output_tokens = $data['usage']['output_tokens'] ?? 0;

		return array(
			'content'       => $content,
			'input_tokens'  => (int) $input_tokens,
			'output_tokens' => (int) $output_tokens,
			'confidence'    => 1.0, // Anthropic does not expose a confidence score.
		);
	}

	/**
	 * {@inheritdoc}
	 *
	 * Anthropic does not currently offer a public embedding endpoint.
	 * Returns empty array — RAG will use TF-IDF similarity.
	 */
	public function embed( string $text ): array {
		return array();
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name(): string {
		return 'Anthropic Claude';
	}

	/**
	 * {@inheritdoc}
	 *
	 * Validates by listing available models (low-cost read endpoint).
	 */
	public function validate_key( string $api_key ): bool {
		$response = wp_remote_get(
			'https://api.anthropic.com/v1/models',
			array(
				'timeout' => 10,
				'headers' => array(
					'x-api-key'         => $api_key,
					'anthropic-version' => self::API_VERSION,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return false;
		}

		return 200 === (int) wp_remote_retrieve_response_code( $response );
	}
}
