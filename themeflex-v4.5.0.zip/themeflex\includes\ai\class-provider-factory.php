<?php
/**
 * AI Provider Factory
 *
 * Resolves the active provider from theme options and returns a ready-to-use
 * ThemeFlex_AI_Provider instance.
 *
 * Usage:
 *   $provider = ThemeFlex_Provider_Factory::make();
 *   $result   = $provider->chat( $system_prompt, $user_message );
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ThemeFlex_Provider_Factory
 */
class ThemeFlex_Provider_Factory {

	/**
	 * wp_options key for provider selection.
	 *
	 * @var string
	 */
	const OPTION_PROVIDER = 'themeflex_ai_provider';

	/**
	 * wp_options key for API key (stored base64-encoded for obfuscation).
	 *
	 * @var string
	 */
	const OPTION_API_KEY = 'themeflex_ai_api_key';

	/**
	 * wp_options key for model selection.
	 *
	 * @var string
	 */
	const OPTION_MODEL = 'themeflex_ai_model';

	/**
	 * Build and return the active provider instance.
	 *
	 * @param  string|null $provider_id Force a specific provider (for testing).
	 * @return ThemeFlex_AI_Provider
	 * @throws RuntimeException If API key is missing.
	 */
	public static function make( ?string $provider_id = null ): ThemeFlex_AI_Provider {
		$provider_id = $provider_id ?? get_option( self::OPTION_PROVIDER, 'anthropic' );
		$api_key     = self::get_api_key();
		$model       = get_option( self::OPTION_MODEL, '' );

		if ( empty( $api_key ) ) {
			throw new RuntimeException( 'No AI provider API key configured.' );
		}

		switch ( $provider_id ) {
			case 'openai':
				$default = ThemeFlex_Provider_OpenAI::DEFAULT_MODEL;
				return new ThemeFlex_Provider_OpenAI( $api_key, $model ?: $default );

			case 'gemini':
				$default = ThemeFlex_Provider_Gemini::DEFAULT_MODEL;
				return new ThemeFlex_Provider_Gemini( $api_key, $model ?: $default );

			case 'anthropic':
			default:
				$default = ThemeFlex_Provider_Anthropic::DEFAULT_MODEL;
				return new ThemeFlex_Provider_Anthropic( $api_key, $model ?: $default );
		}
	}

	/**
	 * Check whether a valid API key is configured.
	 *
	 * @return bool
	 */
	public static function has_api_key(): bool {
		return ! empty( self::get_api_key() );
	}

	/**
	 * Retrieve and decode the stored API key.
	 *
	 * Keys are stored base64-encoded for light obfuscation (not encryption).
	 * For true encryption, a later sprint can add libsodium.
	 *
	 * @return string  Plaintext API key, or '' if not set.
	 */
	public static function get_api_key(): string {
		$encoded = get_option( self::OPTION_API_KEY, '' );
		if ( empty( $encoded ) ) {
			return '';
		}
		$decoded = base64_decode( $encoded, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
		return ( false !== $decoded ) ? $decoded : '';
	}

	/**
	 * Encode and save an API key.
	 *
	 * @param  string $api_key  Plaintext API key.
	 * @return bool  True on success.
	 */
	public static function save_api_key( string $api_key ): bool {
		return update_option(
			self::OPTION_API_KEY,
			base64_encode( $api_key ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
			false // Do not autoload.
		);
	}

	/**
	 * Return all supported providers as id => label pairs.
	 *
	 * Used to populate the Customizer dropdown.
	 *
	 * @return string[]
	 */
	public static function get_providers(): array {
		return array(
			'anthropic' => __( 'Anthropic Claude (Recommended)', 'themeflex' ),
			'openai'    => __( 'OpenAI (GPT-4o)', 'themeflex' ),
			'gemini'    => __( 'Google Gemini 2.0 Flash', 'themeflex' ),
		);
	}

	/**
	 * Return the default model identifiers per provider.
	 *
	 * Keyed by provider id → array of model_id => label.
	 *
	 * @return array<string, string[]>
	 */
	public static function get_models(): array {
		return array(
			'anthropic' => array(
				'claude-3-5-haiku-20241022'  => 'Claude 3.5 Haiku (Fast)',
				'claude-3-5-sonnet-20241022' => 'Claude 3.5 Sonnet (Balanced)',
				'claude-opus-4-5'            => 'Claude Opus 4 (Most Capable)',
			),
			'openai'    => array(
				'gpt-4o-mini' => 'GPT-4o Mini (Fast)',
				'gpt-4o'      => 'GPT-4o (Balanced)',
				'o1-mini'     => 'o1 Mini (Reasoning)',
			),
			'gemini'    => array(
				'gemini-2.0-flash'   => 'Gemini 2.0 Flash (Fast)',
				'gemini-1.5-pro'     => 'Gemini 1.5 Pro (Balanced)',
			),
		);
	}
}
