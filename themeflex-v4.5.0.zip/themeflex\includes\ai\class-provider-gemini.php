<?php
/**
 * Google Gemini Provider Adapter
 *
 * Implements ThemeFlex_AI_Provider for Google's Generative Language API
 * (Gemini 2.0 Flash — fast and cost-efficient).
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ThemeFlex_Provider_Gemini
 */
class ThemeFlex_Provider_Gemini implements ThemeFlex_AI_Provider {

	/**
	 * Gemini API base URL (model appended at runtime).
	 *
	 * @var string
	 */
	const API_BASE = 'https://generativelanguage.googleapis.com/v1beta/models/';

	/**
	 * Default model.
	 *
	 * @var string
	 */
	const DEFAULT_MODEL = 'gemini-2.0-flash';

	/**
	 * API key.
	 *
	 * @var string
	 */
	private string $api_key;

	/**
	 * Model identifier.
	 *
	 * @var string
	 */
	private string $model;

	/**
	 * Constructor.
	 *
	 * @param string $api_key API key (from wp_options, already decrypted).
	 * @param string $model   Optional model override.
	 */
	public function __construct( string $api_key, string $model = self::DEFAULT_MODEL ) {
		$this->api_key = $api_key;
		$this->model   = $model;
	}

	/**
	 * {@inheritdoc}
	 *
	 * Gemini API uses generateContent with a system instruction + user parts.
	 */
	public function chat( string $system_prompt, string $user_message, float $temperature = 0.7, int $max_tokens = 800 ): array {
		$url = self::API_BASE . rawurlencode( $this->model ) . ':generateContent?key=' . rawurlencode( $this->api_key );

		$body = wp_json_encode(
			array(
				'system_instruction' => array(
					'parts' => array(
						array( 'text' => $system_prompt ),
					),
				),
				'contents'           => array(
					array(
						'role'  => 'user',
						'parts' => array(
							array( 'text' => $user_message ),
						),
					),
				),
				'generationConfig'   => array(
					'temperature'     => $temperature,
					'maxOutputTokens' => $max_tokens,
				),
			)
		);

		$response = wp_remote_post(
			$url,
			array(
				'timeout' => 30,
				'headers' => array(
					'Content-Type' => 'application/json',
				),
				'body'    => $body,
			)
		);

		if ( is_wp_error( $response ) ) {
			throw new RuntimeException(
				'Gemini API request failed: ' . $response->get_error_message()
			);
		}

		$code = wp_remote_retrieve_response_code( $response );
		$raw  = wp_remote_retrieve_body( $response );
		$data = json_decode( $raw, true );

		if ( 200 !== (int) $code ) {
			$error = isset( $data['error']['message'] ) ? $data['error']['message'] : $raw;
			throw new RuntimeException( 'Gemini API error ' . $code . ': ' . $error );
		}

		$content       = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
		$input_tokens  = $data['usageMetadata']['promptTokenCount'] ?? 0;
		$output_tokens = $data['usageMetadata']['candidatesTokenCount'] ?? 0;

		return array(
			'content'       => $content,
			'input_tokens'  => (int) $input_tokens,
			'output_tokens' => (int) $output_tokens,
			'confidence'    => 1.0,
		);
	}

	/**
	 * {@inheritdoc}
	 *
	 * Google Gemini Embedding API (text-embedding-004).
	 */
	public function embed( string $text ): array {
		$url = self::API_BASE . 'text-embedding-004:embedContent?key=' . rawurlencode( $this->api_key );

		$body = wp_json_encode(
			array(
				'content' => array(
					'parts' => array(
						array( 'text' => $text ),
					),
				),
			)
		);

		$response = wp_remote_post(
			$url,
			array(
				'timeout' => 15,
				'headers' => array(
					'Content-Type' => 'application/json',
				),
				'body'    => $body,
			)
		);

		if ( is_wp_error( $response ) ) {
			return array();
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		return $data['embedding']['values'] ?? array();
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name(): string {
		return 'Google Gemini';
	}

	/**
	 * {@inheritdoc}
	 *
	 * Validates by listing available models (read-only, no charge).
	 */
	public function validate_key( string $api_key ): bool {
		$url      = 'https://generativelanguage.googleapis.com/v1beta/models?key=' . rawurlencode( $api_key );
		$response = wp_remote_get(
			$url,
			array( 'timeout' => 10 )
		);

		if ( is_wp_error( $response ) ) {
			return false;
		}

		return 200 === (int) wp_remote_retrieve_response_code( $response );
	}
}
