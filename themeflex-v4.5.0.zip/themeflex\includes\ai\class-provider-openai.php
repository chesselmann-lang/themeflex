<?php
/**
 * OpenAI Provider Adapter
 *
 * Implements ThemeFlex_AI_Provider for OpenAI's Chat Completions API.
 * Extracted and refactored from the original class-ai-assistant.php.
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ThemeFlex_Provider_OpenAI
 */
class ThemeFlex_Provider_OpenAI implements ThemeFlex_AI_Provider {

	/**
	 * OpenAI Chat Completions API endpoint.
	 *
	 * @var string
	 */
	const API_ENDPOINT = 'https://api.openai.com/v1/chat/completions';

	/**
	 * OpenAI Embeddings API endpoint.
	 *
	 * @var string
	 */
	const EMBED_ENDPOINT = 'https://api.openai.com/v1/embeddings';

	/**
	 * Default chat model.
	 *
	 * @var string
	 */
	const DEFAULT_MODEL = 'gpt-4o-mini';

	/**
	 * Default embedding model.
	 *
	 * @var string
	 */
	const DEFAULT_EMBED_MODEL = 'text-embedding-3-small';

	/**
	 * API key.
	 *
	 * @var string
	 */
	private string $api_key;

	/**
	 * Chat model identifier.
	 *
	 * @var string
	 */
	private string $model;

	/**
	 * Constructor.
	 *
	 * @param string $api_key API key (from wp_options, already decrypted).
	 * @param string $model   Optional model override.
	 */
	public function __construct( string $api_key, string $model = self::DEFAULT_MODEL ) {
		$this->api_key = $api_key;
		$this->model   = $model;
	}

	/**
	 * {@inheritdoc}
	 */
	public function chat( string $system_prompt, string $user_message, float $temperature = 0.7, int $max_tokens = 800 ): array {
		$body = wp_json_encode(
			array(
				'model'       => $this->model,
				'max_tokens'  => $max_tokens,
				'temperature' => $temperature,
				'messages'    => array(
					array(
						'role'    => 'system',
						'content' => $system_prompt,
					),
					array(
						'role'    => 'user',
						'content' => $user_message,
					),
				),
			)
		);

		$response = wp_remote_post(
			self::API_ENDPOINT,
			array(
				'timeout' => 30,
				'headers' => array(
					'Authorization' => 'Bearer ' . $this->api_key,
					'Content-Type'  => 'application/json',
				),
				'body'    => $body,
			)
		);

		if ( is_wp_error( $response ) ) {
			throw new RuntimeException(
				'OpenAI API request failed: ' . $response->get_error_message()
			);
		}

		$code = wp_remote_retrieve_response_code( $response );
		$raw  = wp_remote_retrieve_body( $response );
		$data = json_decode( $raw, true );

		if ( 200 !== (int) $code ) {
			$error = isset( $data['error']['message'] ) ? $data['error']['message'] : $raw;
			throw new RuntimeException( 'OpenAI API error ' . $code . ': ' . $error );
		}

		$content       = $data['choices'][0]['message']['content'] ?? '';
		$input_tokens  = $data['usage']['prompt_tokens'] ?? 0;
		$output_tokens = $data['usage']['completion_tokens'] ?? 0;

		return array(
			'content'       => $content,
			'input_tokens'  => (int) $input_tokens,
			'output_tokens' => (int) $output_tokens,
			'confidence'    => 1.0,
		);
	}

	/**
	 * {@inheritdoc}
	 *
	 * Uses text-embedding-3-small for cost efficiency.
	 */
	public function embed( string $text ): array {
		$body = wp_json_encode(
			array(
				'model' => self::DEFAULT_EMBED_MODEL,
				'input' => $text,
			)
		);

		$response = wp_remote_post(
			self::EMBED_ENDPOINT,
			array(
				'timeout' => 15,
				'headers' => array(
					'Authorization' => 'Bearer ' . $this->api_key,
					'Content-Type'  => 'application/json',
				),
				'body'    => $body,
			)
		);

		if ( is_wp_error( $response ) ) {
			return array();
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		return $data['data'][0]['embedding'] ?? array();
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name(): string {
		return 'OpenAI';
	}

	/**
	 * {@inheritdoc}
	 *
	 * Validates by calling the /models endpoint (free, no charge).
	 */
	public function validate_key( string $api_key ): bool {
		$response = wp_remote_get(
			'https://api.openai.com/v1/models',
			array(
				'timeout' => 10,
				'headers' => array(
					'Authorization' => 'Bearer ' . $api_key,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return false;
		}

		return 200 === (int) wp_remote_retrieve_response_code( $response );
	}
}
