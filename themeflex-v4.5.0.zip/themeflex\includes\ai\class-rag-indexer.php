<?php
/**
 * RAG Indexer
 *
 * Iterates all published Pages, splits content into chunks (max 500 words),
 * computes TF-IDF vectors, and persists them via ThemeFlex_RAG_Store.
 *
 * Design goals:
 *  - Pure PHP, no Composer, no external embedding API.
 *  - Upgrade path: if a provider supports embed(), real vectors are stored
 *    alongside TF-IDF so v4.1 can switch without re-indexing.
 *  - No WP_Query timeout: iterate with pagination (50 posts per page).
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ThemeFlex_RAG_Indexer
 */
class ThemeFlex_RAG_Indexer {

	/**
	 * Maximum words per chunk.
	 *
	 * @var int
	 */
	const CHUNK_MAX_WORDS = 500;

	/**
	 * Posts per WP_Query page (pagination to avoid memory issues).
	 *
	 * @var int
	 */
	const POSTS_PER_PAGE = 50;

	/**
	 * Minimum characters a chunk must have to be stored.
	 *
	 * @var int
	 */
	const MIN_CHUNK_CHARS = 80;

	// -----------------------------------------------------------------------
	// Public API
	// -----------------------------------------------------------------------

	/**
	 * Run a full re-index of all published pages.
	 *
	 * @param  bool $use_embeddings  If true and a provider supports embed(),
	 *                               attach the embedding vector to each chunk.
	 * @return array {
	 *     @type int $pages   Pages processed.
	 *     @type int $chunks  Chunks stored.
	 * }
	 */
	public static function run( bool $use_embeddings = false ): array {
		$all_chunks = array();
		$page_count = 0;
		$paged      = 1;

		// Optionally get a provider for real embeddings.
		$provider = null;
		if ( $use_embeddings && ThemeFlex_Provider_Factory::has_api_key() ) {
			try {
				$provider = ThemeFlex_Provider_Factory::make();
			} catch ( RuntimeException $e ) {
				$provider = null;
			}
		}

		// Build IDF corpus first (two-pass: collect all docs, then compute).
		$corpus = self::collect_corpus();
		$idf    = self::compute_idf( $corpus );

		// Second pass: chunk, vectorise, store.
		do {
			$query = new WP_Query(
				array(
					'post_type'      => array( 'page', 'post' ),
					'post_status'    => 'publish',
					'posts_per_page' => self::POSTS_PER_PAGE,
					'paged'          => $paged,
					'no_found_rows'  => false,
					'fields'         => 'all',
				)
			);

			if ( ! $query->have_posts() ) {
				break;
			}

			foreach ( $query->posts as $post ) {
				$page_count++;
				$text   = self::extract_text( $post );
				$chunks = self::split_into_chunks( $text );

				foreach ( $chunks as $idx => $chunk_text ) {
					$tf      = self::compute_tf( $chunk_text );
					$tfidf   = self::multiply_tf_idf( $tf, $idf );
					$chunk   = array(
						'post_id'   => $post->ID,
						'post_url'  => get_permalink( $post->ID ),
						'post_title'=> $post->post_title,
						'chunk_idx' => $idx,
						'text'      => $chunk_text,
						'tfidf'     => $tfidf,
					);

					// Attach real embedding if available.
					if ( $provider ) {
						try {
							$chunk['embedding'] = $provider->embed( $chunk_text );
						} catch ( RuntimeException $e ) {
							$chunk['embedding'] = array();
						}
					}

					$all_chunks[] = $chunk;
				}
			}

			$max_pages = $query->max_num_pages;
			$paged++;
		} while ( $paged <= $max_pages );

		ThemeFlex_RAG_Store::set_page_count( $page_count );
		ThemeFlex_RAG_Store::save( $all_chunks );

		return array(
			'pages'  => $page_count,
			'chunks' => count( $all_chunks ),
		);
	}

	// -----------------------------------------------------------------------
	// Text extraction
	// -----------------------------------------------------------------------

	/**
	 * Extract indexable plain text from a WP_Post.
	 *
	 * @param  WP_Post $post
	 * @return string
	 */
	private static function extract_text( WP_Post $post ): string {
		$parts = array();

		// Title (weighted by repeating it).
		$parts[] = $post->post_title . '. ' . $post->post_title;

		// Excerpt.
		if ( ! empty( $post->post_excerpt ) ) {
			$parts[] = $post->post_excerpt;
		}

		// Content — strip shortcodes, HTML, decode entities.
		$content = wp_strip_all_tags(
			strip_shortcodes( $post->post_content )
		);
		$content = html_entity_decode( $content, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$content = preg_replace( '/\s+/', ' ', $content );
		$parts[] = trim( $content );

		return implode( ' ', array_filter( $parts ) );
	}

	// -----------------------------------------------------------------------
	// Chunking
	// -----------------------------------------------------------------------

	/**
	 * Split a long string into word-bounded chunks.
	 *
	 * @param  string $text  Full text.
	 * @return string[]  Array of chunk strings.
	 */
	private static function split_into_chunks( string $text ): array {
		$words  = preg_split( '/\s+/', $text, -1, PREG_SPLIT_NO_EMPTY );
		$chunks = array();
		$buffer = array();

		foreach ( $words as $word ) {
			$buffer[] = $word;
			if ( count( $buffer ) >= self::CHUNK_MAX_WORDS ) {
				$chunk = implode( ' ', $buffer );
				if ( strlen( $chunk ) >= self::MIN_CHUNK_CHARS ) {
					$chunks[] = $chunk;
				}
				$buffer = array();
			}
		}

		// Remainder.
		if ( ! empty( $buffer ) ) {
			$chunk = implode( ' ', $buffer );
			if ( strlen( $chunk ) >= self::MIN_CHUNK_CHARS ) {
				$chunks[] = $chunk;
			}
		}

		return $chunks;
	}

	// -----------------------------------------------------------------------
	// TF-IDF computation
	// -----------------------------------------------------------------------

	/**
	 * Collect all page texts for IDF computation (first pass).
	 *
	 * @return string[]  Array of plain-text documents (one per page).
	 */
	private static function collect_corpus(): array {
		$corpus = array();
		$paged  = 1;

		do {
			$query = new WP_Query(
				array(
					'post_type'      => array( 'page', 'post' ),
					'post_status'    => 'publish',
					'posts_per_page' => self::POSTS_PER_PAGE,
					'paged'          => $paged,
					'no_found_rows'  => false,
					'fields'         => 'all',
				)
			);

			if ( ! $query->have_posts() ) {
				break;
			}

			foreach ( $query->posts as $post ) {
				$corpus[] = self::extract_text( $post );
			}

			$max_pages = $query->max_num_pages;
			$paged++;
		} while ( $paged <= $max_pages );

		return $corpus;
	}

	/**
	 * Compute IDF (Inverse Document Frequency) for the corpus.
	 *
	 * @param  string[] $corpus  Array of document texts.
	 * @return float[]  Map of term => IDF score.
	 */
	private static function compute_idf( array $corpus ): array {
		$num_docs       = count( $corpus );
		$doc_freq       = array();

		foreach ( $corpus as $doc ) {
			$terms = self::tokenise( $doc );
			// Count each term once per document.
			foreach ( array_unique( $terms ) as $term ) {
				$doc_freq[ $term ] = ( $doc_freq[ $term ] ?? 0 ) + 1;
			}
		}

		$idf = array();
		foreach ( $doc_freq as $term => $df ) {
			// Smooth IDF: log((N + 1) / (df + 1)) + 1.
			$idf[ $term ] = log( ( $num_docs + 1 ) / ( $df + 1 ) ) + 1.0;
		}

		return $idf;
	}

	/**
	 * Compute raw TF (Term Frequency) for a chunk.
	 *
	 * @param  string $text  Chunk text.
	 * @return float[]  Map of term => relative frequency.
	 */
	private static function compute_tf( string $text ): array {
		$terms = self::tokenise( $text );
		$count = count( $terms );

		if ( 0 === $count ) {
			return array();
		}

		$freq = array_count_values( $terms );
		$tf   = array();
		foreach ( $freq as $term => $n ) {
			$tf[ $term ] = $n / $count;
		}

		return $tf;
	}

	/**
	 * Multiply TF by IDF to produce the TF-IDF vector.
	 *
	 * Only keeps terms with IDF > 0 (i.e. terms seen in corpus).
	 *
	 * @param  float[] $tf   Term => TF score.
	 * @param  float[] $idf  Term => IDF score.
	 * @return float[]  Term => TF-IDF score (sparse representation).
	 */
	private static function multiply_tf_idf( array $tf, array $idf ): array {
		$tfidf = array();
		foreach ( $tf as $term => $tf_score ) {
			if ( isset( $idf[ $term ] ) ) {
				$tfidf[ $term ] = $tf_score * $idf[ $term ];
			}
		}
		return $tfidf;
	}

	/**
	 * Tokenise text into lowercase, alpha-only terms.
	 *
	 * Stop words are removed to reduce vector noise.
	 *
	 * @param  string $text
	 * @return string[]
	 */
	private static function tokenise( string $text ): array {
		// Lowercase.
		$text  = mb_strtolower( $text, 'UTF-8' );
		// Extract words (Unicode-aware).
		preg_match_all( '/\p{L}+/u', $text, $matches );
		$words = $matches[0];

		// Remove short words and stop words.
		$stop  = self::get_stop_words();
		$terms = array();
		foreach ( $words as $w ) {
			if ( mb_strlen( $w ) > 2 && ! isset( $stop[ $w ] ) ) {
				$terms[] = $w;
			}
		}

		return $terms;
	}

	/**
	 * Return a map of common German + English stop words.
	 *
	 * @return array<string, bool>
	 */
	private static function get_stop_words(): array {
		static $stop = null;
		if ( null !== $stop ) {
			return $stop;
		}

		$words = array(
			// German.
			'der','die','das','den','dem','des','und','oder','aber','ist',
			'war','hat','haben','sein','nicht','auch','sich','mit','auf',
			'für','von','bei','zum','zur','ein','eine','einen','einem',
			'einer','eines','als','wie','wenn','wir','sie','ich','ihr',
			'uns','ihn','ihm','ihnen','diese','dieser','diesem','dieses',
			// English.
			'the','and','for','are','but','not','you','all','can','her',
			'was','one','our','out','has','had','him','his','how','its',
			'may','now','use','who','did','she','too','any','via','per',
		);

		$stop = array_fill_keys( $words, true );
		return $stop;
	}
}
