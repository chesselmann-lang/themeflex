<?php
/**
 * RAG REST Endpoints
 *
 * Registers themeflex/v1/index/ — admin-only re-index trigger.
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ThemeFlex_RAG_REST
 */
class ThemeFlex_RAG_REST {

	/**
	 * Register hooks.
	 */
	public static function init(): void {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * Register REST routes.
	 */
	public static function register_routes(): void {
		// POST themeflex/v1/index/ — trigger a full re-index.
		register_rest_route(
			'themeflex/v1',
			'/index/',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_reindex' ),
				'permission_callback' => array( __CLASS__, 'check_permission' ),
				'args'                => array(
					'use_embeddings' => array(
						'type'    => 'boolean',
						'default' => false,
					),
				),
			)
		);

		// GET themeflex/v1/index/status — return index metadata.
		register_rest_route(
			'themeflex/v1',
			'/index/status',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'handle_status' ),
				'permission_callback' => array( __CLASS__, 'check_permission' ),
			)
		);
	}

	/**
	 * Permission callback — admin only.
	 *
	 * @return bool|WP_Error
	 */
	public static function check_permission(): bool|WP_Error {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error(
				'rest_forbidden',
				esc_html__( 'Administrator access required.', 'themeflex' ),
				array( 'status' => 403 )
			);
		}
		return true;
	}

	/**
	 * Handle POST /index/ — run full re-index.
	 *
	 * @param  WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public static function handle_reindex( WP_REST_Request $request ): WP_REST_Response {
		$use_embeddings = (bool) $request->get_param( 'use_embeddings' );

		try {
			$result = ThemeFlex_RAG_Indexer::run( $use_embeddings );
		} catch ( Throwable $e ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => $e->getMessage(),
				),
				500
			);
		}

		return new WP_REST_Response(
			array(
				'success' => true,
				'pages'   => $result['pages'],
				'chunks'  => $result['chunks'],
				'meta'    => ThemeFlex_RAG_Store::get_meta(),
			),
			200
		);
	}

	/**
	 * Handle GET /index/status — return stored index metadata.
	 *
	 * @return WP_REST_Response
	 */
	public static function handle_status(): WP_REST_Response {
		return new WP_REST_Response(
			array(
				'has_index' => ThemeFlex_RAG_Store::has_index(),
				'meta'      => ThemeFlex_RAG_Store::get_meta(),
			),
			200
		);
	}
}

// Auto-init.
ThemeFlex_RAG_REST::init();
