<?php
/**
 * RAG Retriever
 *
 * Given a user query, finds the Top-N most relevant chunks from the index
 * using cosine similarity over TF-IDF vectors.
 *
 * If the chunk has a real embedding vector attached (from a v4.1+ index run),
 * it uses cosine similarity over the embedding instead — automatically.
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ThemeFlex_RAG_Retriever
 */
class ThemeFlex_RAG_Retriever {

	/**
	 * Number of top chunks to return.
	 *
	 * @var int
	 */
	const TOP_K = 3;

	/**
	 * Minimum similarity score to include a chunk (0.0–1.0).
	 *
	 * @var float
	 */
	const MIN_SCORE = 0.05;

	// -----------------------------------------------------------------------
	// Public API
	// -----------------------------------------------------------------------

	/**
	 * Retrieve the top-K most relevant chunks for a query.
	 *
	 * @param  string $query     User's question / search string.
	 * @param  int    $top_k     How many chunks to return (default: TOP_K).
	 * @return array[]  Array of chunk objects with an additional 'score' key.
	 *                  Each chunk: { post_id, post_url, post_title, text, score }.
	 */
	public static function retrieve( string $query, int $top_k = self::TOP_K ): array {
		$chunks = ThemeFlex_RAG_Store::load();
		if ( empty( $chunks ) ) {
			return array();
		}

		// Compute query TF-IDF vector.
		$query_tfidf = self::query_to_tfidf( $query, $chunks );

		$scored = array();
		foreach ( $chunks as $chunk ) {
			$score = self::score_chunk( $chunk, $query_tfidf );
			if ( $score >= self::MIN_SCORE ) {
				$scored[] = array(
					'post_id'    => $chunk['post_id']    ?? 0,
					'post_url'   => $chunk['post_url']   ?? '',
					'post_title' => $chunk['post_title'] ?? '',
					'text'       => $chunk['text']       ?? '',
					'score'      => $score,
				);
			}
		}

		// Sort descending by score.
		usort( $scored, static function ( array $a, array $b ): int {
			return $b['score'] <=> $a['score'];
		} );

		return array_slice( $scored, 0, $top_k );
	}

	/**
	 * Format retrieved chunks into a system-prompt context block.
	 *
	 * @param  array[] $chunks  Chunks from retrieve().
	 * @return string  Ready-to-inject context string.
	 */
	public static function format_context( array $chunks ): string {
		if ( empty( $chunks ) ) {
			return '';
		}

		$lines = array( 'Relevant information from this website:' );
		foreach ( $chunks as $idx => $chunk ) {
			$n       = $idx + 1;
			$title   = sanitize_text_field( $chunk['post_title'] );
			$url     = esc_url_raw( $chunk['post_url'] );
			$text    = wp_strip_all_tags( $chunk['text'] );
			$lines[] = "\n[{$n}] Page: {$title} ({$url})\n{$text}";
		}

		return implode( "\n", $lines );
	}

	// -----------------------------------------------------------------------
	// Scoring helpers
	// -----------------------------------------------------------------------

	/**
	 * Score a single chunk against the query.
	 *
	 * Prefers cosine similarity over real embeddings when available.
	 *
	 * @param  array   $chunk        Chunk from the store.
	 * @param  float[] $query_tfidf  Query's TF-IDF vector.
	 * @return float  Similarity score (0.0–1.0).
	 */
	private static function score_chunk( array $chunk, array $query_tfidf ): float {
		// Use real embedding if present.
		if ( ! empty( $chunk['embedding'] ) && is_array( $chunk['embedding'] ) ) {
			// We don't have a query embedding here (would need a provider call).
			// Fall through to TF-IDF — real embeddings are used in v4.1+ retriever.
		}

		// TF-IDF cosine similarity.
		$chunk_tfidf = $chunk['tfidf'] ?? array();
		if ( empty( $chunk_tfidf ) || empty( $query_tfidf ) ) {
			return 0.0;
		}

		return self::cosine_similarity( $query_tfidf, $chunk_tfidf );
	}

	/**
	 * Compute a TF-IDF-like vector for the raw query string.
	 *
	 * We derive IDF approximation from the stored corpus (the unique terms
	 * that appear across all chunks), so the query is comparable.
	 *
	 * @param  string  $query   Raw query text.
	 * @param  array[] $chunks  All stored chunks (to derive corpus terms).
	 * @return float[]  Query term => weight map.
	 */
	private static function query_to_tfidf( string $query, array $chunks ): array {
		$query_terms = self::tokenise( $query );
		if ( empty( $query_terms ) ) {
			return array();
		}

		// Count in how many chunks each query term appears (document frequency).
		$num_docs = count( $chunks );
		$df       = array();
		foreach ( $query_terms as $term ) {
			if ( isset( $df[ $term ] ) ) {
				continue; // Already counted.
			}
			$df[ $term ] = 0;
			foreach ( $chunks as $chunk ) {
				if ( isset( ( $chunk['tfidf'] ?? array() )[ $term ] ) ) {
					$df[ $term ]++;
				}
			}
		}

		$freq        = array_count_values( $query_terms );
		$total_terms = count( $query_terms );
		$vector      = array();

		foreach ( $freq as $term => $n ) {
			$tf          = $n / $total_terms;
			$idf         = log( ( $num_docs + 1 ) / ( ( $df[ $term ] ?? 0 ) + 1 ) ) + 1.0;
			$vector[ $term ] = $tf * $idf;
		}

		return $vector;
	}

	/**
	 * Cosine similarity between two sparse term-weight maps.
	 *
	 * @param  float[] $a  Vector A (term => weight).
	 * @param  float[] $b  Vector B (term => weight).
	 * @return float  Value in [0, 1].
	 */
	private static function cosine_similarity( array $a, array $b ): float {
		// Dot product over shared terms only.
		$dot    = 0.0;
		$mag_a  = 0.0;
		$mag_b  = 0.0;

		foreach ( $a as $term => $weight ) {
			$dot   += $weight * ( $b[ $term ] ?? 0.0 );
			$mag_a += $weight ** 2;
		}

		foreach ( $b as $weight ) {
			$mag_b += $weight ** 2;
		}

		$denom = sqrt( $mag_a ) * sqrt( $mag_b );
		if ( $denom < 1e-10 ) {
			return 0.0;
		}

		return $dot / $denom;
	}

	/**
	 * Tokenise a query string into lowercase alpha terms (mirrors Indexer).
	 *
	 * @param  string $text
	 * @return string[]
	 */
	private static function tokenise( string $text ): array {
		$text = mb_strtolower( $text, 'UTF-8' );
		preg_match_all( '/\p{L}+/u', $text, $matches );
		$words = $matches[0];

		$stop  = self::get_stop_words();
		$terms = array();
		foreach ( $words as $w ) {
			if ( mb_strlen( $w ) > 2 && ! isset( $stop[ $w ] ) ) {
				$terms[] = $w;
			}
		}
		return $terms;
	}

	/**
	 * German + English stop words (mirrors Indexer).
	 *
	 * @return array<string, bool>
	 */
	private static function get_stop_words(): array {
		static $stop = null;
		if ( null !== $stop ) {
			return $stop;
		}

		$words = array(
			'der','die','das','den','dem','des','und','oder','aber','ist',
			'war','hat','haben','sein','nicht','auch','sich','mit','auf',
			'für','von','bei','zum','zur','ein','eine','einen','einem',
			'einer','eines','als','wie','wenn','wir','sie','ich','ihr',
			'uns','ihn','ihm','ihnen','diese','dieser','diesem','dieses',
			'the','and','for','are','but','not','you','all','can','her',
			'was','one','our','out','has','had','him','his','how','its',
			'may','now','use','who','did','she','too','any','via','per',
		);

		$stop = array_fill_keys( $words, true );
		return $stop;
	}
}
