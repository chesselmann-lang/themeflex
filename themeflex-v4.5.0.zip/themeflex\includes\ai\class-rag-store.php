<?php
/**
 * RAG Vector Store
 *
 * Persists TF-IDF chunk vectors to a JSON file in the uploads directory.
 * Provides read / write / clear operations for the RAG index.
 *
 * Storage path: /wp-content/uploads/themeflex-rag/index.json
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ThemeFlex_RAG_Store
 */
class ThemeFlex_RAG_Store {

	/**
	 * Sub-directory inside wp-content/uploads/.
	 *
	 * @var string
	 */
	const SUBDIR = 'themeflex-rag';

	/**
	 * Index filename.
	 *
	 * @var string
	 */
	const FILENAME = 'index.json';

	/**
	 * wp_options key for index metadata.
	 *
	 * @var string
	 */
	const OPTION_META = 'themeflex_rag_meta';

	/**
	 * Cached upload dir info.
	 *
	 * @var array|null
	 */
	private static ?array $upload_dir = null;

	// -----------------------------------------------------------------------
	// Public API
	// -----------------------------------------------------------------------

	/**
	 * Write the full index to disk (replaces any existing index).
	 *
	 * @param  array $chunks  Array of chunk objects (as produced by ThemeFlex_RAG_Indexer).
	 * @return bool  True on success.
	 */
	public static function save( array $chunks ): bool {
		$path = self::get_index_path();
		if ( ! $path ) {
			return false;
		}

		$payload = wp_json_encode( $chunks, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		if ( false === $payload ) {
			return false;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		$written = file_put_contents( $path, $payload, LOCK_EX );

		if ( false !== $written ) {
			self::update_meta( count( $chunks ) );
		}

		return false !== $written;
	}

	/**
	 * Load and return all chunks from the index.
	 *
	 * @return array  Array of chunk objects, or [] if the index does not exist.
	 */
	public static function load(): array {
		$path = self::get_index_path();
		if ( ! $path || ! file_exists( $path ) ) {
			return array();
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$raw = file_get_contents( $path );
		if ( false === $raw || empty( $raw ) ) {
			return array();
		}

		$data = json_decode( $raw, true );
		return is_array( $data ) ? $data : array();
	}

	/**
	 * Delete the index file and clear the meta option.
	 *
	 * @return bool
	 */
	public static function clear(): bool {
		$path = self::get_index_path();
		if ( $path && file_exists( $path ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
			unlink( $path );
		}
		delete_option( self::OPTION_META );
		return true;
	}

	/**
	 * Return stored metadata about the last index run.
	 *
	 * @return array {
	 *     @type string $indexed_at  ISO-8601 datetime of last index run.
	 *     @type int    $page_count  Number of pages indexed.
	 *     @type int    $chunk_count Number of chunks stored.
	 * }
	 */
	public static function get_meta(): array {
		$default = array(
			'indexed_at'  => '',
			'page_count'  => 0,
			'chunk_count' => 0,
		);

		$stored = get_option( self::OPTION_META, array() );
		return wp_parse_args( $stored, $default );
	}

	/**
	 * Check whether the index exists and is non-empty.
	 *
	 * @return bool
	 */
	public static function has_index(): bool {
		$path = self::get_index_path();
		return $path && file_exists( $path ) && filesize( $path ) > 10;
	}

	// -----------------------------------------------------------------------
	// Internal helpers
	// -----------------------------------------------------------------------

	/**
	 * Return the absolute path to the index JSON file (creates the dir if needed).
	 *
	 * @return string|null  Absolute path, or null on failure.
	 */
	private static function get_index_path(): ?string {
		if ( null === self::$upload_dir ) {
			self::$upload_dir = wp_upload_dir();
		}

		$dir = trailingslashit( self::$upload_dir['basedir'] ) . self::SUBDIR;

		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
			// Prevent directory listing.
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			file_put_contents( $dir . '/index.html', '' );
		}

		if ( ! is_writable( $dir ) ) {
			return null;
		}

		return $dir . '/' . self::FILENAME;
	}

	/**
	 * Update the meta option after a successful index write.
	 *
	 * @param  int $chunk_count  Number of chunks saved.
	 */
	private static function update_meta( int $chunk_count ): void {
		$meta = self::get_meta();
		update_option(
			self::OPTION_META,
			array(
				'indexed_at'  => gmdate( 'c' ),
				'page_count'  => $meta['page_count'], // Updated by indexer after counting pages.
				'chunk_count' => $chunk_count,
			),
			false
		);
	}

	/**
	 * Allow the indexer to record how many pages were processed.
	 *
	 * @param  int $page_count  Number of WP_Post objects indexed.
	 */
	public static function set_page_count( int $page_count ): void {
		$meta               = self::get_meta();
		$meta['page_count'] = $page_count;
		update_option( self::OPTION_META, $meta, false );
	}
}
