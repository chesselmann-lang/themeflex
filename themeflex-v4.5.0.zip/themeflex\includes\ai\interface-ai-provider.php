<?php
/**
 * AI Provider Interface
 *
 * Defines the contract that all AI provider adapters must implement.
 * Supports Anthropic Claude, OpenAI GPT, and Google Gemini.
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Interface ThemeFlex_AI_Provider
 *
 * Every provider adapter (Anthropic, OpenAI, Gemini) must implement this interface.
 */
interface ThemeFlex_AI_Provider {

	/**
	 * Send a chat completion request.
	 *
	 * @param  string $system_prompt  System / context prompt.
	 * @param  string $user_message   The user's message / question.
	 * @param  float  $temperature    Creativity (0.0–1.0).
	 * @param  int    $max_tokens     Maximum tokens in the response.
	 * @return array {
	 *     @type string $content      The assistant's reply text.
	 *     @type int    $input_tokens  Tokens consumed by the prompt.
	 *     @type int    $output_tokens Tokens consumed by the response.
	 *     @type float  $confidence   Estimated confidence score (0.0–1.0), if available.
	 * }
	 * @throws RuntimeException On API error or non-200 HTTP response.
	 */
	public function chat( string $system_prompt, string $user_message, float $temperature = 0.7, int $max_tokens = 800 ): array;

	/**
	 * Generate an embedding vector for a text chunk.
	 *
	 * Used by the RAG indexer. Returns an empty array if the provider
	 * does not support embeddings — the store will fall back to TF-IDF.
	 *
	 * @param  string $text  Plain text to embed (max ~8 000 tokens).
	 * @return float[]  Embedding vector, or [] if not supported.
	 */
	public function embed( string $text ): array;

	/**
	 * Return a human-readable provider name.
	 *
	 * @return string e.g. "Anthropic Claude", "OpenAI", "Google Gemini".
	 */
	public function get_name(): string;

	/**
	 * Validate an API key without making a billable call.
	 *
	 * Should perform a lightweight request (e.g. models list) and return
	 * true if the key is accepted, false otherwise.
	 *
	 * @param  string $api_key  The key to validate.
	 * @return bool
	 */
	public function validate_key( string $api_key ): bool;
}
