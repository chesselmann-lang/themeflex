<?php
/**
 * ThemeFlex Hook & Filter API
 *
 * Das Herzstück des Ökosystems. Erlaubt Addons, Extensions und Entwicklern
 * das Theme vollständig zu erweitern ohne Core-Dateien zu ändern.
 *
 * USAGE EXAMPLES:
 *
 *   // Filter widget output
 *   add_filter('sf_widget_output', function($html, $widget_id, $context) {
 *       return $html . '<div class="my-extension">...</div>';
 *   }, 10, 3);
 *
 *   // Modify skin tokens before CSS output
 *   add_filter('sf_skin_tokens', function($tokens, $skin_id) {
 *       $tokens['--sf-color-primary'] = '#custom';
 *       return $tokens;
 *   }, 10, 2);
 *
 *   // Register a custom module
 *   sf_register_module('my-addon', ['label' => 'My Addon', 'enabled' => true]);
 *
 * @package ThemeFlex
 * @since   2.0.0
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Hook_API {

    private static ?self $instance = null;
    private array $registered_extensions = [];
    private array $registered_modules    = [];

    public static function instance(): self {
        if (is_null(self::$instance)) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        $this->register_core_hooks();
    }

    // ── Core Hook Registration ─────────────────────────────────────────────

    private function register_core_hooks(): void {

        // Widget lifecycle hooks
        add_action('elementor/widget/before_render_content', [$this, 'before_widget_render'], 10, 1);
        add_action('elementor/widget/after_render',          [$this, 'after_widget_render'],  10, 1);

        // Skin system hooks
        add_filter('sf_skin_css_output',      [$this, 'passthrough_filter'], 10, 2);
        add_filter('sf_skin_tokens',          [$this, 'passthrough_filter'], 10, 2);
        add_filter('sf_active_skin',          [$this, 'passthrough_filter'], 10, 1);

        // Demo import hooks
        add_filter('sf_demo_manifest',        [$this, 'passthrough_filter'], 10, 2);
        add_action('sf_before_demo_import',   '__return_null');
        add_action('sf_after_demo_import',    '__return_null');
        add_filter('sf_demo_import_pages',    [$this, 'passthrough_filter'], 10, 2);

        // Asset hooks
        add_filter('sf_enqueue_widget_assets', [$this, 'passthrough_filter'], 10, 2);
        add_filter('sf_critical_css',          [$this, 'passthrough_filter'], 10, 1);
        add_filter('sf_preload_assets',        [$this, 'passthrough_filter'], 10, 1);

        // Template hooks
        add_filter('sf_template_path',         [$this, 'passthrough_filter'], 10, 2);
        add_filter('sf_widget_template_args',  [$this, 'passthrough_filter'], 10, 3);
        add_filter('sf_widget_output',         [$this, 'passthrough_filter'], 10, 3);

        // Schema / SEO hooks
        add_filter('sf_schema_data',           [$this, 'passthrough_filter'], 10, 2);
        add_filter('sf_og_meta',               [$this, 'passthrough_filter'], 10, 2);

        // Module system
        add_filter('sf_registered_modules',    [$this, 'passthrough_filter'], 10, 1);
        add_filter('sf_module_enabled',        [$this, 'passthrough_filter'], 10, 2);
    }

    // ── Passthrough (ensures filter chain always returns value) ────────────

    public function passthrough_filter($value) {
        return $value;
    }

    // ── Widget Lifecycle ───────────────────────────────────────────────────

    public function before_widget_render(\Elementor\Widget_Base $widget): void {
        $context = [
            'widget_name' => $widget->get_name(),
            'widget_id'   => $widget->get_id(),
            'settings'    => $widget->get_settings_for_display(),
        ];
        /**
         * Fires before any Elementor widget renders.
         *
         * @param \Elementor\Widget_Base $widget  The widget instance.
         * @param array                  $context Widget context data.
         */
        do_action('sf_before_widget_render', $widget, $context);
        do_action("sf_before_widget_{$widget->get_name()}_render", $widget, $context);
    }

    public function after_widget_render(\Elementor\Widget_Base $widget): void {
        /**
         * Fires after any Elementor widget renders.
         *
         * @param \Elementor\Widget_Base $widget The widget instance.
         */
        do_action('sf_after_widget_render', $widget);
        do_action("sf_after_widget_{$widget->get_name()}_render", $widget);
    }

    // ── Extension Registry ─────────────────────────────────────────────────

    /**
     * Register an extension with the theme.
     *
     * @param string $id      Unique extension identifier (e.g. 'sf-pro')
     * @param array  $config  Extension config: name, version, author, requires_modules
     */
    public function register_extension(string $id, array $config): bool {
        if (isset($this->registered_extensions[$id])) {
            return false; // Already registered
        }
        $defaults = [
            'id'               => $id,
            'name'             => $id,
            'version'          => '1.0.0',
            'author'           => '',
            'author_url'       => '',
            'requires_modules' => [],
            'file'             => '',
            'callback'         => null,
        ];
        $this->registered_extensions[$id] = array_merge($defaults, $config);

        /**
         * Fires after an extension is registered.
         *
         * @param string $id     Extension ID.
         * @param array  $config Extension configuration.
         */
        do_action('sf_extension_registered', $id, $this->registered_extensions[$id]);

        // Run extension callback if provided
        if (!empty($config['callback']) && is_callable($config['callback'])) {
            call_user_func($config['callback'], $id, $config);
        }

        return true;
    }

    public function get_extensions(): array {
        return $this->registered_extensions;
    }

    public function get_extension(string $id): ?array {
        return $this->registered_extensions[$id] ?? null;
    }

    // ── Module Registry ────────────────────────────────────────────────────

    /**
     * Register a module. Called by both core and extensions.
     *
     * @param string $id     Module identifier (e.g. 'ai', 'woocommerce', 'animations')
     * @param array  $config Module config: label, description, enabled, assets
     */
    public function register_module(string $id, array $config = []): void {
        $defaults = [
            'id'          => $id,
            'label'       => ucfirst(str_replace(['-','_'], ' ', $id)),
            'description' => '',
            'enabled'     => true,
            'pro'         => false,
            'assets'      => ['css' => [], 'js' => []],
            'depends'     => [],
        ];

        // Allow extensions to override module defaults
        $config = apply_filters('sf_module_config', array_merge($defaults, ['id'=>$id], $config), $id);
        $this->registered_modules[$id] = $config;

        do_action('sf_module_registered', $id, $config);
    }

    /**
     * Check if a module is enabled.
     *
     * @param string $id Module identifier.
     * @return bool
     */
    public function is_module_enabled(string $id): bool {
        if (!isset($this->registered_modules[$id])) return false;

        $enabled = (bool)$this->registered_modules[$id]['enabled'];

        // Allow filters to override (e.g. user setting, license check)
        return (bool) apply_filters('sf_module_enabled', $enabled, $id);
    }

    public function get_modules(): array {
        return $this->registered_modules;
    }

    public function get_module(string $id): ?array {
        return $this->registered_modules[$id] ?? null;
    }

    /**
     * Disable a module at runtime.
     */
    public function disable_module(string $id): void {
        if (isset($this->registered_modules[$id])) {
            $this->registered_modules[$id]['enabled'] = false;
        }
    }
}

// ── Global Helper Functions ─────────────────────────────────────────────────

/**
 * Register an extension with the ThemeFlex ecosystem.
 *
 * @param string $id     Unique slug for your extension.
 * @param array  $config Extension metadata and callback.
 * @return bool
 */
function sf_register_extension(string $id, array $config = []): bool {
    return ThemeFlex_Hook_API::instance()->register_extension($id, $config);
}

/**
 * Register a feature module.
 *
 * @param string $id     Module slug (e.g. 'ai', 'woocommerce').
 * @param array  $config Module configuration.
 */
function sf_register_module(string $id, array $config = []): void {
    ThemeFlex_Hook_API::instance()->register_module($id, $config);
}

/**
 * Check if a module is active.
 *
 * @param string $id Module slug.
 * @return bool
 */
function sf_is_module_enabled(string $id): bool {
    return ThemeFlex_Hook_API::instance()->is_module_enabled($id);
}

/**
 * Get all registered modules.
 *
 * @return array
 */
function sf_get_modules(): array {
    return ThemeFlex_Hook_API::instance()->get_modules();
}

/**
 * Get all registered extensions.
 *
 * @return array
 */
function sf_get_extensions(): array {
    return ThemeFlex_Hook_API::instance()->get_extensions();
}

/**
 * Filter wrapper — applies sf_ filters and returns the result.
 * Useful in widgets for hookable output.
 *
 * @param string $filter_name   Filter name (without 'sf_' prefix).
 * @param mixed  $value         Value to filter.
 * @param mixed  ...$extra_args Additional args passed to filter callbacks.
 * @return mixed
 */
function sf_apply(string $filter_name, mixed $value, mixed ...$extra_args): mixed {
    return apply_filters("sf_{$filter_name}", $value, ...$extra_args);
}

/**
 * Action wrapper — fires a sf_ action.
 *
 * @param string $action_name  Action name (without 'sf_' prefix).
 * @param mixed  ...$args      Arguments passed to action callbacks.
 */
function sf_do(string $action_name, mixed ...$args): void {
    do_action("sf_{$action_name}", ...$args);
}

// Initialise the API as early as possible
add_action('plugins_loaded', function() {
    ThemeFlex_Hook_API::instance();
}, 1);

// Also init on after_setup_theme if no plugin loaded it first
add_action('after_setup_theme', function() {
    ThemeFlex_Hook_API::instance();
}, 1);
