<?php
/**
 * Module Loader System
 *
 * Registers all core modules and handles conditional asset loading.
 * Each module can be enabled/disabled via Settings → ThemeFlex
 * or via filter for pro/extension control.
 *
 * Core modules:
 *   ai, animations, woocommerce, portfolio, mega-menu,
 *   preloader, dark-mode, performance, seo, social-proof
 *
 * @package ThemeFlex
 * @since   2.0.0
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Module_Loader {

    private static ?self $instance = null;

    /** Widgets actually used on the current page (populated from DB) */
    private array $used_widgets = [];

    public static function instance(): self {
        if (is_null(self::$instance)) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('after_setup_theme',  [$this, 'register_core_modules'], 5);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_module_assets'], 15);
        add_filter('sf_skin_tokens',     [$this, 'inject_token_overrides'], 5, 2);
    }

    // ── Register Core Modules ──────────────────────────────────────────────

    public function register_core_modules(): void {
        $settings = get_option('sf_theme_settings', []);

        // Core modules — always on unless explicitly disabled
        $modules = [
            'dark-mode' => [
                'label'       => __('Dark Mode', 'themeflex'),
                'description' => __('Native dark mode support for all components.', 'themeflex'),
                'enabled'     => true,
                'assets'      => ['css' => ['custom']],
            ],
            'preloader' => [
                'label'       => __('Preloader', 'themeflex'),
                'description' => __('Page loading animation before content appears.', 'themeflex'),
                'enabled'     => !empty($settings['enable_preloader']) || get_theme_mod('sf_preloader_enabled', true),
                'assets'      => ['css' => ['custom'], 'js' => ['custom']],
            ],
            'performance' => [
                'label'       => __('Performance Optimizer', 'themeflex'),
                'description' => __('Critical CSS, preload hints, link prefetch.', 'themeflex'),
                'enabled'     => !empty($settings['enable_critical_css']),
            ],
            'seo' => [
                'label'       => __('SEO & Schema', 'themeflex'),
                'description' => __('Schema.org JSON-LD + Open Graph meta tags.', 'themeflex'),
                'enabled'     => !empty($settings['enable_og']) || get_theme_mod('sf_enable_og_tags', true),
            ],
            'portfolio' => [
                'label'       => __('Portfolio CPT', 'themeflex'),
                'description' => __('Custom post type for portfolio projects.', 'themeflex'),
                'enabled'     => true,
            ],
            'mega-menu' => [
                'label'       => __('Mega Menu', 'themeflex'),
                'description' => __('Full-width dropdown mega menus.', 'themeflex'),
                'enabled'     => true,
            ],
            'woocommerce' => [
                'label'       => __('WooCommerce Integration', 'themeflex'),
                'description' => __('Full WooCommerce theme support and templates.', 'themeflex'),
                'enabled'     => class_exists('WooCommerce'),
                'depends'     => ['woocommerce-plugin'],
            ],
            'ai' => [
                'label'       => __('AI Content Assistant', 'themeflex'),
                'description' => __('OpenAI-powered content generation in widgets.', 'themeflex'),
                'enabled'     => !empty(get_option('themeflex_openai_api_key', '')),
                'pro'         => false, // Core in v1, could be Pro later
            ],
            'animations' => [
                'label'       => __('Scroll Animations', 'themeflex'),
                'description' => __('IntersectionObserver entrance animations.', 'themeflex'),
                'enabled'     => true,
                'assets'      => ['js' => ['custom']],
            ],
            'social-proof' => [
                'label'       => __('Social Proof Notifications', 'themeflex'),
                'description' => __('Activity notifications widget (Booking.com style).', 'themeflex'),
                'enabled'     => true,
            ],
            'shortcodes' => [
                'label'       => __('Shortcodes Library', 'themeflex'),
                'description' => __('13 utility shortcodes: sf_button, sf_alert, etc.', 'themeflex'),
                'enabled'     => true,
            ],
            'custom-login' => [
                'label'       => __('Custom Login Page', 'themeflex'),
                'description' => __('Branded wp-login.php styling.', 'themeflex'),
                'enabled'     => get_theme_mod('sf_custom_login', true),
            ],
            'white-label' => [
                'label'       => __('White Label', 'themeflex'),
                'description' => __('Agency rebranding for client sites.', 'themeflex'),
                'enabled'     => !empty(get_option('sfa_white_label', [])['enabled']),
                'plugin_only' => true, // Only available via companion plugin
            ],
        ];

        foreach ($modules as $id => $config) {
            sf_register_module($id, $config);
        }

        /**
         * Fires after all core modules are registered.
         * Extensions should register their modules here.
         *
         * @example
         * add_action('sf_modules_registered', function() {
         *     sf_register_module('my-extension', ['label' => 'My Feature', 'enabled' => true]);
         * });
         */
        do_action('sf_modules_registered');
    }

    // ── Conditional Asset Loading ──────────────────────────────────────────

    public function enqueue_module_assets(): void {
        if (!sf_is_module_enabled('animations')) {
            // Remove animation classes from body
            add_filter('body_class', function(array $classes): array {
                return array_filter($classes, fn($c) => $c !== 'sf-animations-enabled');
            });
        }

        if (!sf_is_module_enabled('preloader')) {
            // Dequeue preloader assets
            add_filter('sf_show_preloader', '__return_false');
        }

        // Let extensions conditionally load their assets
        foreach (sf_get_modules() as $id => $module) {
            if (!sf_is_module_enabled($id)) continue;
            if (empty($module['assets'])) continue;

            /**
             * Fires for each enabled module to allow asset enqueueing.
             *
             * @param string $id     Module ID.
             * @param array  $module Module config.
             */
            do_action("sf_enqueue_module_{$id}_assets", $id, $module);
        }
    }

    // ── Token Injection from Modules ───────────────────────────────────────

    public function inject_token_overrides(array $tokens, string $skin_id): array {
        // Allow each enabled module to add/override design tokens
        foreach (sf_get_modules() as $id => $module) {
            if (!sf_is_module_enabled($id)) continue;
            $tokens = apply_filters("sf_module_{$id}_tokens", $tokens, $skin_id);
        }
        return $tokens;
    }

    // ── Utility: Check if widget is used on current page ──────────────────

    /**
     * Check if a specific Elementor widget is used on the current page.
     * Useful for conditional CSS/JS loading.
     *
     * @param string $widget_name  Widget name (e.g. 'sf_pricing_table')
     * @return bool
     */
    public function is_widget_used(string $widget_name): bool {
        if (!is_singular()) return false;
        static $widgets_cache = [];

        $post_id = get_the_ID();
        if (!isset($widgets_cache[$post_id])) {
            $data = get_post_meta($post_id, '_elementor_data', true);
            $widgets_cache[$post_id] = $data ? json_decode($data, true) : [];
        }
        return $this->search_widget_in_data($widgets_cache[$post_id], $widget_name);
    }

    private function search_widget_in_data(?array $data, string $widget_name): bool {
        if (empty($data)) return false;
        foreach ($data as $element) {
            if (($element['widgetType'] ?? '') === $widget_name) return true;
            if (!empty($element['elements']) && $this->search_widget_in_data($element['elements'], $widget_name)) return true;
        }
        return false;
    }
}

// Global helper
function sf_is_widget_used(string $widget_name): bool {
    return ThemeFlex_Module_Loader::instance()->is_widget_used($widget_name);
}

ThemeFlex_Module_Loader::instance();
