<?php
/**
 * Admin AI-Chat Panel
 *
 * Registers the "ThemeFlex → AI Chat" admin page.
 * Shows: provider, API-key status, indexer status, re-index button, 30-day token log.
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ThemeFlex_Admin_AI_Panel
 */
class ThemeFlex_Admin_AI_Panel {

	/**
	 * Admin page slug.
	 *
	 * @var string
	 */
	const PAGE_SLUG = 'themeflex-ai-chat';

	/**
	 * Register hooks.
	 */
	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_post_themeflex_save_ai_settings', array( __CLASS__, 'handle_save_settings' ) );
		add_action( 'admin_post_themeflex_reindex', array( __CLASS__, 'handle_reindex' ) );
		add_action( 'wp_ajax_themeflex_reindex', array( __CLASS__, 'handle_reindex_ajax' ) );
	}

	/**
	 * Register submenu under ThemeFlex top-level menu.
	 */
	public static function register_menu(): void {
		// Ensure ThemeFlex top-level menu exists (may be registered elsewhere).
		if ( ! menu_page_url( 'themeflex', false ) ) {
			add_menu_page(
				__( 'ThemeFlex', 'themeflex' ),
				__( 'ThemeFlex', 'themeflex' ),
				'manage_options',
				'themeflex',
				'__return_empty_string',
				'dashicons-layout',
				59
			);
		}

		add_submenu_page(
			'themeflex',
			__( 'AI Chat', 'themeflex' ),
			__( 'AI Chat', 'themeflex' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Handle the settings form submission (save API key + provider).
	 */
	public static function handle_save_settings(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Permission denied.', 'themeflex' ) );
		}

		check_admin_referer( 'themeflex_ai_settings' );

		$provider = sanitize_text_field( wp_unslash( $_POST['themeflex_ai_provider'] ?? 'anthropic' ) );
		$api_key  = sanitize_text_field( wp_unslash( $_POST['themeflex_ai_api_key_raw'] ?? '' ) );

		// Validate provider.
		$valid_providers = array_keys( ThemeFlex_Provider_Factory::get_providers() );
		if ( ! in_array( $provider, $valid_providers, true ) ) {
			$provider = 'anthropic';
		}

		update_option( ThemeFlex_Provider_Factory::OPTION_PROVIDER, $provider, false );

		// Only update key if a new one was supplied.
		if ( ! empty( $api_key ) ) {
			ThemeFlex_Provider_Factory::save_api_key( $api_key );
		}

		wp_safe_redirect(
			add_query_arg(
				array( 'page' => self::PAGE_SLUG, 'saved' => '1' ),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Handle non-AJAX re-index (fallback).
	 */
	public static function handle_reindex(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Permission denied.', 'themeflex' ) );
		}

		check_admin_referer( 'themeflex_reindex' );

		ThemeFlex_RAG_Indexer::run();

		wp_safe_redirect(
			add_query_arg(
				array( 'page' => self::PAGE_SLUG, 'indexed' => '1' ),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Handle AJAX re-index (with progress response).
	 */
	public static function handle_reindex_ajax(): void {
		check_ajax_referer( 'themeflex_reindex_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied.' ), 403 );
		}

		try {
			$result = ThemeFlex_RAG_Indexer::run();
			wp_send_json_success(
				array(
					'pages'  => $result['pages'],
					'chunks' => $result['chunks'],
					'meta'   => ThemeFlex_RAG_Store::get_meta(),
				)
			);
		} catch ( Throwable $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}
	}

	/**
	 * Render the admin page.
	 */
	public static function render_page(): void {
		$view = THEMEFLEX_DIR . '/includes/admin/views/ai-panel.php';
		if ( file_exists( $view ) ) {
			include $view;
		}
	}
}

// Auto-init.
ThemeFlex_Admin_AI_Panel::init();
