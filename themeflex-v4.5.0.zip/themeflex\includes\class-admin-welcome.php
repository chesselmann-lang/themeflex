<?php
/**
 * Admin Welcome / Getting-Started Page
 * Zeigt einen professionellen Onboarding-Screen im WordPress-Backend.
 *
 * @package ThemeFlex
 * @since   1.1.0
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Admin_Welcome {

    private static ?self $instance = null;

    public static function instance(): self {
        if (is_null(self::$instance)) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', [$this, 'add_admin_page']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('admin_notices', [$this, 'activation_redirect_notice']);
        // Redirect to welcome page on activation
        add_action('after_switch_theme', function() {
            set_transient('sf_activation_redirect', true, 30);
        });
        add_action('admin_init', function() {
            if (get_transient('sf_activation_redirect') && !isset($_GET['page'])) {
                delete_transient('sf_activation_redirect');
                wp_safe_redirect(admin_url('themes.php?page=themeflex-welcome'));
                exit;
            }
        });
    }

    public function add_admin_page(): void {
        add_theme_page(
            esc_html__('ThemeFlex — Getting Started', 'themeflex'),
            esc_html__('Theme Setup', 'themeflex'),
            'manage_options',
            'themeflex-welcome',
            [$this, 'render_page']
        );
    }

    public function enqueue_assets(string $hook): void {
        if ('appearance_page_themeflex-welcome' !== $hook) return;
        wp_enqueue_style('sf-admin-welcome', false);
    }

    public function activation_redirect_notice(): void {
        // silent — redirect handles it
    }

    public function render_page(): void {
        $skin_manager   = function_exists('themeflex_skin_manager') ? themeflex_skin_manager() : null;
        $active_skin    = $skin_manager ? $skin_manager->get_active_skin() : 'default';
        $all_skins      = $skin_manager ? $skin_manager->get_skins() : [];
        $elm_active     = defined('ELEMENTOR_VERSION');
        $addons_active  = class_exists('ThemeFlex_Addons');
        $woo_active     = class_exists('WooCommerce');
        $tutor_active   = function_exists('tutor');
        $events_active  = class_exists('Tribe__Events__Main');
        $widget_count   = count(glob(THEMEFLEX_DIR . '/includes/elementor-widgets/*.php') ?: []);
        $skin_count     = count($all_skins);
        $demo_count     = count(glob(THEMEFLEX_DIR . '/demos/*', GLOB_ONLYDIR) ?: []);
        $version        = wp_get_theme()->get('Version');
        ?>
        <div class="sf-welcome" style="font-family:-apple-system,BlinkMacSystemFont,'Inter',sans-serif;max-width:1100px;margin:0;padding:32px 20px;">
            <!-- Header -->
            <div style="background:linear-gradient(135deg,#06021D 0%,#1a1f29 100%);border-radius:16px;padding:40px 48px;margin-bottom:32px;color:#fff;display:flex;align-items:center;justify-content:space-between;gap:24px;flex-wrap:wrap;">
                <div>
                    <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">
                        <div style="width:10px;height:10px;border-radius:50%;background:linear-gradient(135deg,#FF5E2E,#ED4C1C);"></div>
                        <span style="font-size:13px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:rgba(255,255,255,.6);"><?php esc_html_e('ThemeFlex','themeflex'); ?> v<?php echo esc_html($version); ?></span>
                    </div>
                    <h1 style="margin:0 0 8px;font-size:2rem;font-weight:900;letter-spacing:-.5px;"><?php esc_html_e('Welcome — Let\'s build something amazing.','themeflex'); ?></h1>
                    <p style="margin:0;color:rgba(255,255,255,.65);font-size:15px;"><?php esc_html_e('Your complete WordPress theme ecosystem is ready. Follow the steps below to get started.','themeflex'); ?></p>
                </div>
                <div style="display:flex;gap:24px;flex-wrap:wrap;">
                    <?php foreach ([
                        [$widget_count.'+', __('Widgets','themeflex'), '#FF5E2E'],
                        [$skin_count, __('Skins','themeflex'), '#00D4FF'],
                        [$demo_count, __('Demos','themeflex'), '#10b981'],
                    ] as [$num, $label, $color]): ?>
                    <div style="text-align:center;">
                        <div style="font-size:2rem;font-weight:900;color:<?php echo esc_attr($color); ?>;line-height:1;"><?php echo esc_html($num); ?></div>
                        <div style="font-size:11px;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:.5px;"><?php echo esc_html($label); ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Setup Steps -->
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:32px;">
                <!-- Step 1: Elementor -->
                <?php $this->step_card(
                    '1', __('Install Elementor','themeflex'),
                    __('ThemeFlex is built for Elementor. Install and activate the free Elementor plugin to unlock all widgets and page-building features.','themeflex'),
                    $elm_active,
                    $elm_active ? null : ['url' => wp_nonce_url(admin_url('update.php?action=install-plugin&plugin=elementor'), 'install-plugin_elementor'), 'label' => __('Install Elementor','themeflex')],
                    '🔌'
                ); ?>

                <!-- Step 2: Addons Plugin -->
                <?php $this->step_card(
                    '2', __('Install ThemeFlex Addons','themeflex'),
                    __('The companion plugin provides all widget auto-discovery, one-click demo import, and advanced features. Upload themeflex-addons.zip in Plugins → Add New.','themeflex'),
                    $addons_active,
                    $addons_active ? null : ['url' => admin_url('plugin-install.php'), 'label' => __('Go to Plugin Installer','themeflex')],
                    '🧩'
                ); ?>

                <!-- Step 3: Choose Skin -->
                <?php $this->step_card(
                    '3', __('Choose Your Skin','themeflex'),
                    sprintf(__('Your active skin: <strong>%s</strong>. Change it anytime in Customize → Skin Settings. Each skin is a complete design system — colors, fonts, and components.','themeflex'), ucfirst($active_skin)),
                    true,
                    ['url' => admin_url('customize.php'), 'label' => __('Open Customizer','themeflex')],
                    '🎨'
                ); ?>

                <!-- Step 4: Import Demo -->
                <?php $this->step_card(
                    '4', __('Import a Demo','themeflex'),
                    __('Start with a full demo site. One click imports all pages, Elementor templates, and applies the right skin automatically. Works best on a fresh installation.','themeflex'),
                    false,
                    ['url' => admin_url('themes.php?page=sfa-demo-importer'), 'label' => __('Open Demo Importer','themeflex')],
                    '📦'
                ); ?>
            </div>

            <!-- Plugin Status -->
            <div style="background:#fff;border:1px solid #e5e7eb;border-radius:16px;padding:32px;margin-bottom:32px;">
                <h2 style="margin:0 0 20px;font-size:1rem;font-weight:700;color:#1e293b;"><?php esc_html_e('Plugin Status','themeflex'); ?></h2>
                <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px;">
                    <?php foreach ([
                        ['Elementor', $elm_active, 'elementor', __('Required','themeflex')],
                        ['ThemeFlex Addons', $addons_active, null, __('Required','themeflex')],
                        ['WooCommerce', $woo_active, 'woocommerce', __('Recommended','themeflex')],
                        ['Tutor LMS', $tutor_active, 'tutor', __('Optional','themeflex')],
                        ['The Events Calendar', $events_active, 'the-events-calendar', __('Optional','themeflex')],
                    ] as [$name, $active, $slug, $type]):
                        $type_color = __('Required','themeflex') === $type ? '#ef4444' : (__('Recommended','themeflex') === $type ? '#f59e0b' : '#94a3b8');
                    ?>
                    <div style="background:<?php echo $active?'#f0fdf4':'#fef2f2'; ?>;border:1px solid <?php echo $active?'#bbf7d0':'#fecaca'; ?>;border-radius:10px;padding:14px 16px;display:flex;align-items:center;justify-content:space-between;gap:8px;">
                        <div>
                            <div style="font-weight:600;font-size:13px;color:<?php echo $active?'#065f46':'#991b1b'; ?>;"><?php echo esc_html($name); ?></div>
                            <div style="font-size:11px;color:<?php echo esc_attr($type_color); ?>;font-weight:600;"><?php echo esc_html($type); ?></div>
                        </div>
                        <?php if ($active): ?>
                        <span style="color:#10b981;font-size:18px;">✓</span>
                        <?php elseif ($slug): ?>
                        <a href="<?php echo esc_url(wp_nonce_url(admin_url('update.php?action=install-plugin&plugin='.$slug), 'install-plugin_'.$slug)); ?>" style="font-size:11px;font-weight:700;color:#ef4444;text-decoration:none;white-space:nowrap;"><?php esc_html_e('Install','themeflex'); ?></a>
                        <?php else: ?>
                        <span style="color:#ef4444;font-size:11px;font-weight:700;"><?php esc_html_e('Upload','themeflex'); ?></span>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Quick Links -->
            <div style="background:#fff;border:1px solid #e5e7eb;border-radius:16px;padding:32px;">
                <h2 style="margin:0 0 20px;font-size:1rem;font-weight:700;color:#1e293b;"><?php esc_html_e('Quick Links','themeflex'); ?></h2>
                <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;">
                    <?php
                    $links = [
                        [admin_url('customize.php'), '🎨', __('Customizer','themeflex')],
                        [admin_url('post-new.php?post_type=page'), '📄', __('New Page','themeflex')],
                        [admin_url('themes.php?page=sfa-demo-importer'), '📦', __('Demo Importer','themeflex')],
                        [admin_url('widgets.php'), '🔧', __('Widgets','themeflex')],
                        [admin_url('nav-menus.php'), '☰', __('Menus','themeflex')],
                        ['https://doc.themerex.net/', '📖', __('Documentation','themeflex')],
                    ];
                    foreach ($links as [$url, $icon, $label]): ?>
                    <a href="<?php echo esc_url($url); ?>" style="display:flex;align-items:center;gap:10px;padding:12px 16px;background:#f8fafc;border:1px solid #e5e7eb;border-radius:10px;text-decoration:none;color:#1e293b;font-weight:600;font-size:13px;transition:all .2s;" onmouseover="this.style.borderColor='#FF5E2E';this.style.background='#fff5f2'" onmouseout="this.style.borderColor='#e5e7eb';this.style.background='#f8fafc'">
                        <span style="font-size:18px;"><?php echo $icon; ?></span>
                        <?php echo esc_html($label); ?>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
    }

    private function step_card(string $num, string $title, string $desc, bool $done, ?array $cta, string $icon): void {
        $border = $done ? '#bbf7d0' : '#e5e7eb';
        $bg     = $done ? '#f0fdf4' : '#fff';
        ?>
        <div style="background:<?php echo $bg; ?>;border:1px solid <?php echo $border; ?>;border-radius:16px;padding:28px;position:relative;overflow:hidden;">
            <div style="display:flex;align-items:flex-start;gap:14px;">
                <div style="width:44px;height:44px;border-radius:12px;background:<?php echo $done?'linear-gradient(135deg,#10b981,#059669)':'linear-gradient(135deg,#FF5E2E,#ED4C1C)'; ?>;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;"><?php echo $done ? '✓' : esc_html($icon); ?></div>
                <div style="flex:1;">
                    <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
                        <span style="font-size:11px;font-weight:700;color:#94a3b8;"><?php printf(esc_html__('STEP %s','themeflex'), $num); ?></span>
                        <?php if ($done): ?><span style="font-size:11px;font-weight:700;color:#10b981;background:#dcfce7;padding:1px 6px;border-radius:4px;"><?php esc_html_e('DONE','themeflex'); ?></span><?php endif; ?>
                    </div>
                    <h3 style="font-size:1rem;font-weight:700;color:#1e293b;margin:0 0 8px;"><?php echo esc_html($title); ?></h3>
                    <p style="font-size:13px;color:#64748b;line-height:1.6;margin:0 0 16px;"><?php echo wp_kses_post($desc); ?></p>
                    <?php if ($cta): ?>
                    <a href="<?php echo esc_url($cta['url']); ?>" class="button <?php echo $done?'button-secondary':'button-primary'; ?>" style="<?php echo !$done?'background:linear-gradient(135deg,#FF5E2E,#ED4C1C);border-color:transparent;color:#fff;':''; ?>"><?php echo esc_html($cta['label']); ?></a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }
}

ThemeFlex_Admin_Welcome::instance();
