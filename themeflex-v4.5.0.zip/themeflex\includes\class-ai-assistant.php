<?php
/**
 * AI Content Assistant
 *
 * Provides AI-powered content generation, improvement, and SEO optimization.
 * Integrates with OpenAI API or custom endpoints.
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ThemeFlex_AI_Assistant {

	const RATE_LIMIT = 50; // Max requests per hour
	const OPTION_API_KEY = 'sf_ai_assistant_api_key';
	const OPTION_ENDPOINT = 'sf_ai_assistant_endpoint';
	const TRANSIENT_PREFIX = 'sf_ai_requests_';

	/**
	 * Initialize AI Assistant
	 */
	public static function init() {
		add_action( 'customize_register', array( __CLASS__, 'register_customizer_settings' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ), 20 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_assets' ) );
		add_action( 'elementor/editor/before_enqueue_scripts', array( __CLASS__, 'enqueue_elementor_assets' ) );
	}

	/**
	 * Register customizer settings for API configuration
	 *
	 * @param WP_Customize_Manager $wp_customize Theme customizer instance.
	 */
	public static function register_customizer_settings( $wp_customize ) {
		$wp_customize->add_section(
			'sf_ai_assistant',
			array(
				'title'       => esc_html__( 'AI Assistant Settings', 'themeflex' ),
				'description' => esc_html__( 'Configure AI content generation API', 'themeflex' ),
				'priority'    => 170,
				'capability'  => 'manage_options',
			)
		);

		// -------------------------------------------------------
		// AI Provider (v4.0 — Anthropic default, OpenAI, Gemini)
		// -------------------------------------------------------
		$wp_customize->add_setting(
			ThemeFlex_Provider_Factory::OPTION_PROVIDER,
			array(
				'default'           => 'anthropic',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
				'capability'        => 'manage_options',
			)
		);

		$wp_customize->add_control(
			ThemeFlex_Provider_Factory::OPTION_PROVIDER,
			array(
				'label'       => esc_html__( 'AI Provider', 'themeflex' ),
				'section'     => 'sf_ai_assistant',
				'type'        => 'select',
				'choices'     => ThemeFlex_Provider_Factory::get_providers(),
				'description' => esc_html__( 'Enter your own API key below. Anthropic Claude is the recommended default.', 'themeflex' ),
			)
		);

		// API Key (stored base64-encoded; managed via Admin Panel for security).
		$wp_customize->add_setting(
			ThemeFlex_Provider_Factory::OPTION_API_KEY,
			array(
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
				'capability'        => 'manage_options',
			)
		);

		$wp_customize->add_control(
			ThemeFlex_Provider_Factory::OPTION_API_KEY,
			array(
				'label'       => esc_html__( 'API Key', 'themeflex' ),
				'section'     => 'sf_ai_assistant',
				'type'        => 'password',
				'description' => esc_html__( 'Your Anthropic, OpenAI, or Gemini API key. Stored obfuscated in wp_options.', 'themeflex' ),
			)
		);

		// Model Selection.
		$wp_customize->add_setting(
			ThemeFlex_Provider_Factory::OPTION_MODEL,
			array(
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
				'capability'        => 'manage_options',
			)
		);

		$wp_customize->add_control(
			ThemeFlex_Provider_Factory::OPTION_MODEL,
			array(
				'label'       => esc_html__( 'AI Model (optional)', 'themeflex' ),
				'section'     => 'sf_ai_assistant',
				'type'        => 'text',
				'description' => esc_html__( 'Leave blank to use the recommended default for your provider.', 'themeflex' ),
			)
		);

		// Temperature
		$wp_customize->add_setting(
			'sf_ai_temperature',
			array(
				'default'           => 0.7,
				'sanitize_callback' => 'floatval',
				'transport'         => 'postMessage',
				'capability'        => 'manage_options',
			)
		);

		$wp_customize->add_control(
			'sf_ai_temperature',
			array(
				'label'       => esc_html__( 'Temperature (Creativity)', 'themeflex' ),
				'section'     => 'sf_ai_assistant',
				'type'        => 'range',
				'input_attrs' => array(
					'min'  => 0,
					'max'  => 2,
					'step' => 0.1,
				),
				'description' => esc_html__( '0 = Deterministic, 2 = Creative', 'themeflex' ),
			)
		);

		// Max Tokens
		$wp_customize->add_setting(
			'sf_ai_max_tokens',
			array(
				'default'           => 500,
				'sanitize_callback' => 'absint',
				'transport'         => 'postMessage',
				'capability'        => 'manage_options',
			)
		);

		$wp_customize->add_control(
			'sf_ai_max_tokens',
			array(
				'label'       => esc_html__( 'Max Tokens per Request', 'themeflex' ),
				'section'     => 'sf_ai_assistant',
				'type'        => 'number',
				'description' => esc_html__( 'Maximum length of generated content', 'themeflex' ),
				'input_attrs' => array(
					'min' => 100,
					'max' => 2000,
				),
			)
		);

		// Enable/Disable
		$wp_customize->add_setting(
			'sf_ai_assistant_enabled',
			array(
				'default'           => true,
				'sanitize_callback' => 'rest_sanitize_boolean',
				'transport'         => 'postMessage',
				'capability'        => 'manage_options',
			)
		);

		$wp_customize->add_control(
			'sf_ai_assistant_enabled',
			array(
				'label'   => esc_html__( 'Enable AI Assistant', 'themeflex' ),
				'section' => 'sf_ai_assistant',
				'type'    => 'checkbox',
			)
		);
	}

	/**
	 * Register REST API routes
	 */
	public static function register_rest_routes() {
		register_rest_route(
			'themeflex/v1',
			'/ai/generate-text',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'generate_text' ),
				'permission_callback' => array( __CLASS__, 'check_permission' ),
				'args'                => array(
					'prompt'  => array(
						'type'        => 'string',
						'required'    => true,
						'description' => 'The prompt for content generation',
					),
					'context' => array(
						'type'        => 'string',
						'description' => 'Additional context for generation',
					),
					'tone'    => array(
						'type'    => 'string',
						'enum'    => array( 'professional', 'casual', 'creative', 'formal' ),
						'default' => 'professional',
					),
					'length'  => array(
						'type'    => 'string',
						'enum'    => array( 'short', 'medium', 'long' ),
						'default' => 'medium',
					),
				),
			)
		);

		register_rest_route(
			'themeflex/v1',
			'/ai/improve-text',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'improve_text' ),
				'permission_callback' => array( __CLASS__, 'check_permission' ),
				'args'                => array(
					'text'      => array(
						'type'        => 'string',
						'required'    => true,
						'description' => 'Text to improve',
					),
					'style'     => array(
						'type'        => 'string',
						'enum'        => array( 'tone', 'clarity', 'grammar', 'expansion', 'summary' ),
						'default'     => 'clarity',
						'description' => 'Type of improvement',
					),
					'tone'      => array(
						'type'    => 'string',
						'enum'    => array( 'professional', 'casual', 'creative', 'formal' ),
						'default' => 'professional',
					),
				),
			)
		);

		register_rest_route(
			'themeflex/v1',
			'/ai/generate-headline',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'generate_headline' ),
				'permission_callback' => array( __CLASS__, 'check_permission' ),
				'args'                => array(
					'content' => array(
						'type'        => 'string',
						'required'    => true,
						'description' => 'Content to generate headline for',
					),
					'style'   => array(
						'type'        => 'string',
						'enum'        => array( 'catchy', 'direct', 'curious', 'benefit' ),
						'default'     => 'catchy',
					),
					'count'   => array(
						'type'        => 'integer',
						'default'     => 5,
						'description' => 'Number of headlines to generate',
					),
				),
			)
		);

		register_rest_route(
			'themeflex/v1',
			'/ai/generate-meta',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'generate_meta' ),
				'permission_callback' => array( __CLASS__, 'check_permission' ),
				'args'                => array(
					'title'   => array(
						'type'        => 'string',
						'required'    => true,
						'description' => 'Page/post title',
					),
					'content' => array(
						'type'        => 'string',
						'required'    => true,
						'description' => 'Page/post content',
					),
					'keywords' => array(
						'type'        => 'string',
						'description' => 'Target keywords',
					),
				),
			)
		);

		register_rest_route(
			'themeflex/v1',
			'/ai/translate',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'translate_text' ),
				'permission_callback' => array( __CLASS__, 'check_permission' ),
				'args'                => array(
					'text'           => array(
						'type'        => 'string',
						'required'    => true,
						'description' => 'Text to translate',
					),
					'target_language' => array(
						'type'        => 'string',
						'required'    => true,
						'description' => 'Target language (e.g., es, fr, de)',
					),
				),
			)
		);
	}

	/**
	 * Check user permission and rate limit
	 *
	 * @return bool|WP_Error
	 */
	public static function check_permission() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return new WP_Error( 'rest_forbidden', esc_html__( 'You do not have permission to use AI Assistant', 'themeflex' ), array( 'status' => 403 ) );
		}

		// Check rate limit
		if ( ! self::check_rate_limit() ) {
			return new WP_Error( 'rate_limit_exceeded', esc_html__( 'Rate limit exceeded. Maximum 50 requests per hour.', 'themeflex' ), array( 'status' => 429 ) );
		}

		// Check if AI Assistant is enabled
		if ( ! get_theme_mod( 'sf_ai_assistant_enabled', true ) ) {
			return new WP_Error( 'ai_disabled', esc_html__( 'AI Assistant is not enabled', 'themeflex' ), array( 'status' => 403 ) );
		}

		// Check for API key
		$api_key = get_option( self::OPTION_API_KEY );
		if ( empty( $api_key ) ) {
			return new WP_Error( 'no_api_key', esc_html__( 'AI Assistant API key not configured', 'themeflex' ), array( 'status' => 500 ) );
		}

		return true;
	}

	/**
	 * Check rate limit for current user
	 *
	 * @return bool
	 */
	private static function check_rate_limit() {
		$user_id = get_current_user_id();
		$transient_key = self::TRANSIENT_PREFIX . $user_id;
		$request_count = get_transient( $transient_key );

		if ( false === $request_count ) {
			set_transient( $transient_key, 1, HOUR_IN_SECONDS );
			return true;
		}

		if ( $request_count >= self::RATE_LIMIT ) {
			return false;
		}

		set_transient( $transient_key, $request_count + 1, HOUR_IN_SECONDS );
		return true;
	}

	/**
	 * Generate text content
	 *
	 * @param WP_REST_Request $request REST request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function generate_text( $request ) {
		$prompt = sanitize_text_field( $request->get_param( 'prompt' ) );
		$context = sanitize_textarea_field( $request->get_param( 'context' ) );
		$tone = sanitize_text_field( $request->get_param( 'tone' ) ) ?: 'professional';
		$length = sanitize_text_field( $request->get_param( 'length' ) ) ?: 'medium';

		$full_prompt = self::build_prompt( $prompt, $context, $tone, $length );

		$response = self::call_ai_api( $full_prompt );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		return rest_ensure_response( array(
			'success' => true,
			'content' => $response,
			'timestamp' => time(),
		) );
	}

	/**
	 * Improve existing text
	 *
	 * @param WP_REST_Request $request REST request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function improve_text( $request ) {
		$text = sanitize_textarea_field( $request->get_param( 'text' ) );
		$style = sanitize_text_field( $request->get_param( 'style' ) ) ?: 'clarity';
		$tone = sanitize_text_field( $request->get_param( 'tone' ) ) ?: 'professional';

		$style_instructions = array(
			'tone'       => 'Change the tone to ' . $tone . ' while maintaining the original meaning.',
			'clarity'    => 'Rewrite for maximum clarity and readability.',
			'grammar'    => 'Fix grammar, spelling, and punctuation errors.',
			'expansion'  => 'Expand this text with more details and examples.',
			'summary'    => 'Create a shorter, more concise version.',
		);

		$instruction = $style_instructions[ $style ] ?? $style_instructions['clarity'];
		$full_prompt = "Please improve the following text. {$instruction}\n\nOriginal text:\n{$text}";

		$response = self::call_ai_api( $full_prompt );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		return rest_ensure_response( array(
			'success'     => true,
			'original'    => $text,
			'improved'    => $response,
			'style_used'  => $style,
			'timestamp'   => time(),
		) );
	}

	/**
	 * Generate headlines
	 *
	 * @param WP_REST_Request $request REST request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function generate_headline( $request ) {
		$content = sanitize_textarea_field( $request->get_param( 'content' ) );
		$style = sanitize_text_field( $request->get_param( 'style' ) ) ?: 'catchy';
		$count = absint( $request->get_param( 'count' ) ) ?: 5;

		$style_instructions = array(
			'catchy'   => 'creative and attention-grabbing',
			'direct'   => 'clear and straightforward',
			'curious'  => 'curiosity-inducing and intriguing',
			'benefit'  => 'benefit-focused headlines',
		);

		$instruction = $style_instructions[ $style ] ?? $style_instructions['catchy'];
		$full_prompt = "Generate {$count} {$instruction} headlines for the following content:\n\n{$content}\n\nReturn only the headlines, numbered 1-{$count}.";

		$response = self::call_ai_api( $full_prompt );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$headlines = array_filter( explode( "\n", $response ) );

		return rest_ensure_response( array(
			'success'   => true,
			'headlines' => $headlines,
			'count'     => count( $headlines ),
			'timestamp' => time(),
		) );
	}

	/**
	 * Generate SEO meta tags
	 *
	 * @param WP_REST_Request $request REST request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function generate_meta( $request ) {
		$title = sanitize_text_field( $request->get_param( 'title' ) );
		$content = sanitize_textarea_field( $request->get_param( 'content' ) );
		$keywords = sanitize_text_field( $request->get_param( 'keywords' ) );

		$prompt = "Generate SEO-optimized meta tags for the following:\n\n";
		$prompt .= "Title: {$title}\n";
		$prompt .= "Content: " . substr( $content, 0, 500 ) . "\n";
		if ( ! empty( $keywords ) ) {
			$prompt .= "Keywords: {$keywords}\n";
		}
		$prompt .= "\nProvide:\n1. Meta Title (50-60 chars)\n2. Meta Description (150-160 chars)\n3. Focus Keywords (3-5)\n4. Long-tail Keywords (2-3)";

		$response = self::call_ai_api( $prompt );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		return rest_ensure_response( array(
			'success'   => true,
			'seo_data'  => $response,
			'timestamp' => time(),
		) );
	}

	/**
	 * Translate text
	 *
	 * @param WP_REST_Request $request REST request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function translate_text( $request ) {
		$text = sanitize_textarea_field( $request->get_param( 'text' ) );
		$target_language = sanitize_text_field( $request->get_param( 'target_language' ) );

		$language_names = array(
			'es'    => 'Spanish',
			'fr'    => 'French',
			'de'    => 'German',
			'it'    => 'Italian',
			'pt'    => 'Portuguese',
			'ja'    => 'Japanese',
			'zh'    => 'Chinese',
			'ru'    => 'Russian',
			'ar'    => 'Arabic',
			'ko'    => 'Korean',
		);

		$lang_name = $language_names[ $target_language ] ?? ucfirst( $target_language );
		$prompt = "Translate the following text to {$lang_name}. Maintain the original tone and meaning.\n\nText: {$text}";

		$response = self::call_ai_api( $prompt );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		return rest_ensure_response( array(
			'success'   => true,
			'original'  => $text,
			'translated' => $response,
			'language'  => $target_language,
			'timestamp' => time(),
		) );
	}

	/**
	 * Build complete prompt with context
	 *
	 * @param string $prompt Main prompt.
	 * @param string $context Additional context.
	 * @param string $tone Desired tone.
	 * @param string $length Desired length.
	 * @return string
	 */
	private static function build_prompt( $prompt, $context, $tone, $length ) {
		$length_instructions = array(
			'short'  => 'Keep response under 100 words.',
			'medium' => 'Response should be 100-300 words.',
			'long'   => 'Response should be 300-500 words.',
		);

		$length_instruction = $length_instructions[ $length ] ?? $length_instructions['medium'];

		$full_prompt = "Generate content with the following requirements:\n";
		$full_prompt .= "- Tone: {$tone}\n";
		$full_prompt .= "- {$length_instruction}\n";
		if ( ! empty( $context ) ) {
			$full_prompt .= "- Context: {$context}\n";
		}
		$full_prompt .= "\nRequest: {$prompt}";

		return $full_prompt;
	}

	/**
	 * Call AI API
	 *
	 * @param string $prompt The prompt to send.
	 * @return string|WP_Error Generated response or error.
	 */
	private static function call_ai_api( $prompt ) {
		$provider = get_theme_mod( 'sf_ai_provider', 'openai' );
		$api_key = get_option( self::OPTION_API_KEY );

		if ( empty( $api_key ) ) {
			return new WP_Error( 'no_api_key', esc_html__( 'API key not configured', 'themeflex' ) );
		}

		if ( 'openai' === $provider ) {
			return self::call_openai_api( $prompt, $api_key );
		} else {
			return self::call_custom_api( $prompt, $api_key );
		}
	}

	/**
	 * Call OpenAI API
	 *
	 * @param string $prompt The prompt.
	 * @param string $api_key API key.
	 * @return string|WP_Error
	 */
	private static function call_openai_api( $prompt, $api_key ) {
		$model = get_theme_mod( 'sf_ai_model', 'gpt-3.5-turbo' );
		$temperature = get_theme_mod( 'sf_ai_temperature', 0.7 );
		$max_tokens = get_theme_mod( 'sf_ai_max_tokens', 500 );

		$response = wp_remote_post(
			'https://api.openai.com/v1/chat/completions',
			array(
				'timeout' => 30,
				'headers' => array(
					'Content-Type'  => 'application/json',
					'Authorization' => 'Bearer ' . $api_key,
				),
				'body'    => wp_json_encode( array(
					'model'       => $model,
					'messages'    => array(
						array(
							'role'    => 'system',
							'content' => 'You are a helpful content assistant. Provide clear, concise, and high-quality responses.',
						),
						array(
							'role'    => 'user',
							'content' => $prompt,
						),
					),
					'temperature' => floatval( $temperature ),
					'max_tokens'  => intval( $max_tokens ),
				) ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'api_error', sprintf( esc_html__( 'API Error: %s', 'themeflex' ), $response->get_error_message() ) );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! isset( $body['choices'][0]['message']['content'] ) ) {
			$error = $body['error']['message'] ?? 'Unknown error';
			return new WP_Error( 'api_error', sprintf( esc_html__( 'API Error: %s', 'themeflex' ), $error ) );
		}

		return trim( $body['choices'][0]['message']['content'] );
	}

	/**
	 * Call custom AI API
	 *
	 * @param string $prompt The prompt.
	 * @param string $api_key API key.
	 * @return string|WP_Error
	 */
	private static function call_custom_api( $prompt, $api_key ) {
		$endpoint = get_option( self::OPTION_ENDPOINT );

		if ( empty( $endpoint ) ) {
			return new WP_Error( 'no_endpoint', esc_html__( 'Custom endpoint not configured', 'themeflex' ) );
		}

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout' => 30,
				'headers' => array(
					'Content-Type'  => 'application/json',
					'Authorization' => 'Bearer ' . $api_key,
				),
				'body'    => wp_json_encode( array(
					'prompt' => $prompt,
				) ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'api_error', sprintf( esc_html__( 'API Error: %s', 'themeflex' ), $response->get_error_message() ) );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! isset( $body['content'] ) && ! isset( $body['text'] ) && ! isset( $body['result'] ) ) {
			return new WP_Error( 'api_error', esc_html__( 'Invalid API response format', 'themeflex' ) );
		}

		return trim( $body['content'] ?? $body['text'] ?? $body['result'] );
	}

	/**
	 * Enqueue frontend assets
	 */
	public static function enqueue_assets() {
		if ( ! get_theme_mod( 'sf_ai_assistant_enabled', true ) ) {
			return;
		}

		wp_enqueue_style(
			'themeflex-ai-assistant',
			THEMEFLEX_URL . '/assets/css/ai-assistant.css',
			array(),
			THEMEFLEX_VERSION
		);

		wp_enqueue_script(
			'themeflex-ai-assistant',
			THEMEFLEX_URL . '/assets/js/ai-assistant.js',
			array( 'wp-api', 'wp-dom-ready' ),
			THEMEFLEX_VERSION,
			true
		);

		wp_localize_script(
			'themeflex-ai-assistant',
			'themeFlexAI',
			array(
				'apiUrl'  => rest_url( 'themeflex/v1/ai/' ),
				'nonce'   => wp_create_nonce( 'wp_rest' ),
				'enabled' => true,
			)
		);
	}

	/**
	 * Enqueue admin assets
	 */
	public static function enqueue_admin_assets() {
		if ( ! get_theme_mod( 'sf_ai_assistant_enabled', true ) ) {
			return;
		}

		wp_enqueue_style(
			'themeflex-ai-assistant-admin',
			THEMEFLEX_URL . '/assets/css/ai-assistant.css',
			array(),
			THEMEFLEX_VERSION
		);
	}

	/**
	 * Enqueue Elementor editor assets
	 */
	public static function enqueue_elementor_assets() {
		if ( ! get_theme_mod( 'sf_ai_assistant_enabled', true ) ) {
			return;
		}

		wp_enqueue_script(
			'themeflex-ai-elementor',
			THEMEFLEX_URL . '/assets/js/ai-assistant-elementor.js',
			array( 'jquery', 'elementor-editor' ),
			THEMEFLEX_VERSION,
			true
		);

		wp_localize_script(
			'themeflex-ai-elementor',
			'themeFlexAIElementor',
			array(
				'apiUrl'  => rest_url( 'themeflex/v1/ai/' ),
				'nonce'   => wp_create_nonce( 'wp_rest' ),
				'enabled' => true,
			)
		);
	}
}

// Initialize
ThemeFlex_AI_Assistant::init();
