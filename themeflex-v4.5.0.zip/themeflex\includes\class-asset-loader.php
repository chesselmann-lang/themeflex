<?php
/**
 * Asset Loader - Smart CSS/JS loading with minification support
 *
 * Handles intelligent loading of CSS and JavaScript assets:
 * - Detects minified versions and loads them in production
 * - Falls back to unminified versions in development mode
 * - Provides helper methods for asset URLs
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Asset_Loader class
 *
 * Manages CSS and JavaScript asset loading with smart minification detection.
 *
 * @class Asset_Loader
 */
class ThemeFlex_Asset_Loader {

	/**
	 * Theme root URI
	 *
	 * @var string
	 */
	private $theme_uri;

	/**
	 * Theme root path
	 *
	 * @var string
	 */
	private $theme_path;

	/**
	 * Whether debug mode is enabled
	 *
	 * @var bool
	 */
	private $debug_mode;

	/**
	 * Asset version (for cache busting)
	 *
	 * @var string
	 */
	private $version;

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->theme_uri   = get_template_directory_uri();
		$this->theme_path  = get_template_directory();
		$this->debug_mode  = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG;
		$this->version     = wp_get_theme()->get( 'Version' );
	}

	/**
	 * Get asset URL with smart minification detection
	 *
	 * Returns the minified version if it exists and debug mode is off.
	 * Falls back to unminified version in development or if minified version doesn't exist.
	 *
	 * @param string $filename The filename (e.g., 'elementor-widgets.css' or 'animations.js').
	 * @return string The full URL to the asset
	 *
	 * @since 1.0.0
	 */
	public function get_asset_url( $filename ) {
		// Determine asset type and directory
		if ( strpos( $filename, '.css' ) !== false ) {
			$type      = 'css';
			$directory = 'assets/css';
			$mime_type = 'text/css';
		} elseif ( strpos( $filename, '.js' ) !== false ) {
			$type      = 'js';
			$directory = 'assets/js';
			$mime_type = 'application/javascript';
		} else {
			return ''; // Invalid asset
		}

		// Check if minified version exists (unless in debug mode)
		if ( ! $this->debug_mode ) {
			$minified_filename = $this->get_minified_filename( $filename );
			$minified_path     = $this->theme_path . '/' . $directory . '/' . $minified_filename;

			if ( file_exists( $minified_path ) ) {
				return $this->theme_uri . '/' . $directory . '/' . $minified_filename;
			}
		}

		// Fall back to unminified version
		return $this->theme_uri . '/' . $directory . '/' . $filename;
	}

	/**
	 * Enqueue CSS with smart minification detection
	 *
	 * @param string $handle     The stylesheet handle.
	 * @param string $filename   The filename (e.g., 'elementor-widgets.css').
	 * @param array  $deps       Array of stylesheet dependencies.
	 * @param bool   $media      The media for which the stylesheet has been defined.
	 *
	 * @return bool Whether the stylesheet was enqueued
	 *
	 * @since 1.0.0
	 */
	public function enqueue_style( $handle, $filename, $deps = array(), $media = 'all' ) {
		$url = $this->get_asset_url( $filename );

		if ( empty( $url ) ) {
			return false;
		}

		wp_enqueue_style( $handle, $url, $deps, $this->version, $media );
		return true;
	}

	/**
	 * Enqueue JavaScript with smart minification detection
	 *
	 * @param string $handle          The script handle.
	 * @param string $filename        The filename (e.g., 'elementor-widgets.js').
	 * @param array  $deps            Array of script dependencies.
	 * @param bool   $in_footer       Whether to print the script before </body> or in <head>.
	 * @param array  $localized_data  Optional array of data to localize for this script.
	 *
	 * @return bool Whether the script was enqueued
	 *
	 * @since 1.0.0
	 */
	public function enqueue_script( $handle, $filename, $deps = array(), $in_footer = true, $localized_data = array() ) {
		$url = $this->get_asset_url( $filename );

		if ( empty( $url ) ) {
			return false;
		}

		wp_enqueue_script( $handle, $url, $deps, $this->version, $in_footer );

		// Localize script if data provided
		if ( ! empty( $localized_data ) && is_array( $localized_data ) ) {
			foreach ( $localized_data as $var_name => $var_data ) {
				wp_localize_script( $handle, $var_name, $var_data );
			}
		}

		return true;
	}

	/**
	 * Register CSS for later enqueueing
	 *
	 * @param string $handle     The stylesheet handle.
	 * @param string $filename   The filename.
	 * @param array  $deps       Array of stylesheet dependencies.
	 * @param bool   $media      The media for which the stylesheet has been defined.
	 *
	 * @return bool Whether the stylesheet was registered
	 *
	 * @since 1.0.0
	 */
	public function register_style( $handle, $filename, $deps = array(), $media = 'all' ) {
		$url = $this->get_asset_url( $filename );

		if ( empty( $url ) ) {
			return false;
		}

		wp_register_style( $handle, $url, $deps, $this->version, $media );
		return true;
	}

	/**
	 * Register JavaScript for later enqueueing
	 *
	 * @param string $handle          The script handle.
	 * @param string $filename        The filename.
	 * @param array  $deps            Array of script dependencies.
	 * @param bool   $in_footer       Whether to print the script before </body> or in <head>.
	 * @param array  $localized_data  Optional array of data to localize for this script.
	 *
	 * @return bool Whether the script was registered
	 *
	 * @since 1.0.0
	 */
	public function register_script( $handle, $filename, $deps = array(), $in_footer = true, $localized_data = array() ) {
		$url = $this->get_asset_url( $filename );

		if ( empty( $url ) ) {
			return false;
		}

		wp_register_script( $handle, $url, $deps, $this->version, $in_footer );

		// Localize script if data provided
		if ( ! empty( $localized_data ) && is_array( $localized_data ) ) {
			foreach ( $localized_data as $var_name => $var_data ) {
				wp_localize_script( $handle, $var_name, $var_data );
			}
		}

		return true;
	}

	/**
	 * Check if asset exists
	 *
	 * @param string $filename The filename.
	 * @return bool Whether the asset (minified or unminified) exists
	 *
	 * @since 1.0.0
	 */
	public function asset_exists( $filename ) {
		$url = $this->get_asset_url( $filename );
		return ! empty( $url );
	}

	/**
	 * Get minified filename
	 *
	 * Converts 'style.css' to 'style.min.css' or 'script.js' to 'script.min.js'
	 *
	 * @param string $filename The original filename.
	 * @return string The minified filename
	 *
	 * @since 1.0.0
	 */
	private function get_minified_filename( $filename ) {
		$parts = explode( '.', $filename );
		$ext   = array_pop( $parts );
		$parts[] = 'min';
		$parts[] = $ext;
		return implode( '.', $parts );
	}

	/**
	 * Get asset version for cache busting
	 *
	 * @return string The asset version
	 *
	 * @since 1.0.0
	 */
	public function get_version() {
		return $this->version;
	}

	/**
	 * Get debug mode status
	 *
	 * @return bool Whether debug mode is enabled
	 *
	 * @since 1.0.0
	 */
	public function is_debug_mode() {
		return $this->debug_mode;
	}

	/**
	 * Get all CSS assets in assets/css directory
	 *
	 * @return array Array of CSS filenames (unminified versions)
	 *
	 * @since 1.0.0
	 */
	public function get_css_assets() {
		$css_dir = $this->theme_path . '/assets/css';
		$files   = array();

		if ( is_dir( $css_dir ) ) {
			$dir_files = glob( $css_dir . '/*.css' );

			foreach ( $dir_files as $file ) {
				$filename = basename( $file );
				// Only include unminified files
				if ( strpos( $filename, '.min.' ) === false ) {
					$files[] = $filename;
				}
			}
		}

		return $files;
	}

	/**
	 * Get all JS assets in assets/js directory
	 *
	 * @return array Array of JS filenames (unminified versions)
	 *
	 * @since 1.0.0
	 */
	public function get_js_assets() {
		$js_dir = $this->theme_path . '/assets/js';
		$files  = array();

		if ( is_dir( $js_dir ) ) {
			$dir_files = glob( $js_dir . '/*.js' );

			foreach ( $dir_files as $file ) {
				$filename = basename( $file );
				// Only include unminified files
				if ( strpos( $filename, '.min.' ) === false ) {
					$files[] = $filename;
				}
			}
		}

		return $files;
	}
}

/**
 * Get global instance of Asset_Loader
 *
 * @return ThemeFlex_Asset_Loader The asset loader instance
 *
 * @since 1.0.0
 */
function sf_get_asset_loader() {
	static $loader = null;

	if ( $loader === null ) {
		$loader = new ThemeFlex_Asset_Loader();
	}

	return $loader;
}

/**
 * Helper function to get asset URL
 *
 * @param string $filename The asset filename.
 * @return string The full URL to the asset
 *
 * @since 1.0.0
 */
function sf_asset_url( $filename ) {
	return sf_get_asset_loader()->get_asset_url( $filename );
}

/**
 * Helper function to enqueue CSS
 *
 * @param string $handle     The stylesheet handle.
 * @param string $filename   The filename.
 * @param array  $deps       Array of stylesheet dependencies.
 * @param bool   $media      The media for which the stylesheet has been defined.
 * @return bool Whether the stylesheet was enqueued
 *
 * @since 1.0.0
 */
function sf_enqueue_style( $handle, $filename, $deps = array(), $media = 'all' ) {
	return sf_get_asset_loader()->enqueue_style( $handle, $filename, $deps, $media );
}

/**
 * Helper function to enqueue JavaScript
 *
 * @param string $handle          The script handle.
 * @param string $filename        The filename.
 * @param array  $deps            Array of script dependencies.
 * @param bool   $in_footer       Whether to print the script before </body> or in <head>.
 * @param array  $localized_data  Optional array of data to localize.
 * @return bool Whether the script was enqueued
 *
 * @since 1.0.0
 */
function sf_enqueue_script( $handle, $filename, $deps = array(), $in_footer = true, $localized_data = array() ) {
	return sf_get_asset_loader()->enqueue_script( $handle, $filename, $deps, $in_footer, $localized_data );
}
