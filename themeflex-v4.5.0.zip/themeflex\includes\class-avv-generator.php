<?php
/**
 * AVV PDF Generator
 *
 * Generates a DSGVO-compliant Auftragsverarbeitungsvertrag (AVV / DPA) as a
 * downloadable PDF. Uses a bundled FPDF 1.86 library — no Composer required.
 *
 * Admin page:  ThemeFlex → AVV Generator
 * Download:    POST action `themeflex_generate_avv`
 * Shortcode:   (none — admin-only tool)
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ThemeFlex_AVV_Generator
 */
class ThemeFlex_AVV_Generator {

	/**
	 * Admin page slug.
	 *
	 * @var string
	 */
	const PAGE_SLUG = 'themeflex-avv-generator';

	/**
	 * wp_options key for saved AVV data.
	 *
	 * @var string
	 */
	const OPTION_AVV = 'themeflex_avv_data';

	/**
	 * Register hooks.
	 */
	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_post_themeflex_save_avv', array( __CLASS__, 'handle_save' ) );
		add_action( 'admin_post_themeflex_generate_avv', array( __CLASS__, 'handle_generate' ) );
	}

	// -----------------------------------------------------------------------
	// Menu
	// -----------------------------------------------------------------------

	/**
	 * Register submenu page under ThemeFlex.
	 */
	public static function register_menu(): void {
		add_submenu_page(
			'themeflex',
			__( 'AVV Generator', 'themeflex' ),
			__( 'AVV Generator', 'themeflex' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	// -----------------------------------------------------------------------
	// Admin page
	// -----------------------------------------------------------------------

	/**
	 * Render admin page.
	 */
	public static function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$data    = self::get_data();
		$message = '';

		if ( isset( $_GET['saved'] ) && '1' === $_GET['saved'] ) { // phpcs:ignore WordPress.Security.NonceVerification
			$message = __( 'AVV data saved.', 'themeflex' );
		}

		$legal_data = get_option( 'themeflex_legal_data', array() );
		// Pre-fill from Legal Wizard if AVV data is empty.
		if ( empty( $data['controller_name'] ) && ! empty( $legal_data['company_name'] ) ) {
			$data['controller_name']  = $legal_data['company_name'];
			$data['controller_email'] = $legal_data['email'] ?? '';
			$data['controller_street']= $legal_data['street'] ?? '';
			$data['controller_city']  = $legal_data['city'] ?? '';
			$data['controller_zip']   = $legal_data['postcode'] ?? '';
			$data['controller_country']= $legal_data['country'] ?? 'Deutschland';
		}

		$fields_controller = array(
			'controller_name'    => __( 'Company / Controller Name', 'themeflex' ),
			'controller_street'  => __( 'Street & Number', 'themeflex' ),
			'controller_zip'     => __( 'Postcode', 'themeflex' ),
			'controller_city'    => __( 'City', 'themeflex' ),
			'controller_country' => __( 'Country', 'themeflex' ),
			'controller_email'   => __( 'Contact E-Mail', 'themeflex' ),
			'controller_rep'     => __( 'Authorised Representative (Name)', 'themeflex' ),
		);
		$fields_processor = array(
			'processor_name'    => __( 'Processor (Service Provider) Name', 'themeflex' ),
			'processor_street'  => __( 'Street & Number', 'themeflex' ),
			'processor_zip'     => __( 'Postcode', 'themeflex' ),
			'processor_city'    => __( 'City', 'themeflex' ),
			'processor_country' => __( 'Country', 'themeflex' ),
			'processor_service' => __( 'Service Description', 'themeflex' ),
			'processor_rep'     => __( 'Authorised Representative (Name)', 'themeflex' ),
		);
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'AVV Generator', 'themeflex' ); ?></h1>
			<p><?php esc_html_e( 'Generate a DSGVO-compliant Data Processing Agreement (Auftragsverarbeitungsvertrag) as a PDF.', 'themeflex' ); ?></p>

			<?php if ( $message ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $message ); ?></p></div>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="themeflex_save_avv">
				<?php wp_nonce_field( 'themeflex_save_avv', '_wpnonce_avv' ); ?>

				<h2><?php esc_html_e( 'Controller (Your Company)', 'themeflex' ); ?></h2>
				<table class="form-table">
					<?php foreach ( $fields_controller as $key => $label ) : ?>
						<tr>
							<th><label for="avv-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
							<td>
								<input type="text" id="avv-<?php echo esc_attr( $key ); ?>" name="avv[<?php echo esc_attr( $key ); ?>]"
									value="<?php echo esc_attr( $data[ $key ] ?? '' ); ?>" class="regular-text">
							</td>
						</tr>
					<?php endforeach; ?>
				</table>

				<h2><?php esc_html_e( 'Processor (Service Provider)', 'themeflex' ); ?></h2>
				<table class="form-table">
					<?php foreach ( $fields_processor as $key => $label ) : ?>
						<tr>
							<th><label for="avv-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
							<td>
								<?php if ( 'processor_service' === $key ) : ?>
									<textarea id="avv-<?php echo esc_attr( $key ); ?>" name="avv[<?php echo esc_attr( $key ); ?>]"
										rows="3" class="large-text"><?php echo esc_textarea( $data[ $key ] ?? '' ); ?></textarea>
								<?php else : ?>
									<input type="text" id="avv-<?php echo esc_attr( $key ); ?>" name="avv[<?php echo esc_attr( $key ); ?>]"
										value="<?php echo esc_attr( $data[ $key ] ?? '' ); ?>" class="regular-text">
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>

				<h2><?php esc_html_e( 'Agreement Details', 'themeflex' ); ?></h2>
				<table class="form-table">
					<tr>
						<th><label for="avv-date"><?php esc_html_e( 'Agreement Date', 'themeflex' ); ?></label></th>
						<td>
							<input type="date" id="avv-date" name="avv[agreement_date]"
								value="<?php echo esc_attr( $data['agreement_date'] ?? wp_date( 'Y-m-d' ) ); ?>" class="regular-text">
						</td>
					</tr>
					<tr>
						<th><label for="avv-jurisdiction"><?php esc_html_e( 'Jurisdiction', 'themeflex' ); ?></label></th>
						<td>
							<select id="avv-jurisdiction" name="avv[jurisdiction]">
								<?php
								$jurs = array( 'de' => 'Deutschland', 'at' => 'Österreich', 'ch' => 'Schweiz' );
								foreach ( $jurs as $jval => $jlabel ) :
									$sel = ( ( $data['jurisdiction'] ?? 'de' ) === $jval ) ? 'selected' : '';
								?>
									<option value="<?php echo esc_attr( $jval ); ?>" <?php echo esc_attr( $sel ); ?>><?php echo esc_html( $jlabel ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
				</table>

				<p class="submit">
					<button type="submit" class="button button-secondary"><?php esc_html_e( 'Save Data', 'themeflex' ); ?></button>
				</p>
			</form>

			<hr>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="themeflex_generate_avv">
				<?php wp_nonce_field( 'themeflex_generate_avv', '_wpnonce_avv_gen' ); ?>
				<p>
					<button type="submit" class="button button-primary" style="font-size:1rem;padding:.6rem 1.4rem;">
						⬇ <?php esc_html_e( 'Download AVV as PDF', 'themeflex' ); ?>
					</button>
				</p>
			</form>
		</div>
		<?php
	}

	// -----------------------------------------------------------------------
	// Handlers
	// -----------------------------------------------------------------------

	/**
	 * Save AVV form data.
	 */
	public static function handle_save(): void {
		check_admin_referer( 'themeflex_save_avv', '_wpnonce_avv' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Forbidden', 'themeflex' ) );
		}

		$raw  = isset( $_POST['avv'] ) && is_array( $_POST['avv'] ) ? $_POST['avv'] : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$data = array();

		$allowed_keys = array(
			'controller_name', 'controller_street', 'controller_zip', 'controller_city',
			'controller_country', 'controller_email', 'controller_rep',
			'processor_name', 'processor_street', 'processor_zip', 'processor_city',
			'processor_country', 'processor_rep', 'processor_service',
			'agreement_date', 'jurisdiction',
		);

		foreach ( $allowed_keys as $key ) {
			if ( isset( $raw[ $key ] ) ) {
				$data[ $key ] = 'processor_service' === $key
					? sanitize_textarea_field( wp_unslash( $raw[ $key ] ) )
					: sanitize_text_field( wp_unslash( $raw[ $key ] ) );
			}
		}

		update_option( self::OPTION_AVV, $data, false );

		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE_SLUG . '&saved=1' ) );
		exit;
	}

	/**
	 * Generate and stream the AVV PDF.
	 */
	public static function handle_generate(): void {
		check_admin_referer( 'themeflex_generate_avv', '_wpnonce_avv_gen' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Forbidden', 'themeflex' ) );
		}

		$data = self::get_data();

		// Load FPDF (bundled).
		$fpdf_path = THEMEFLEX_DIR . '/inc/fpdf/fpdf.php';
		if ( ! file_exists( $fpdf_path ) ) {
			wp_die( esc_html__( 'FPDF library not found. Please re-install ThemeFlex.', 'themeflex' ) );
		}
		require_once $fpdf_path;

		// Build and stream PDF.
		self::build_pdf( $data );
		exit;
	}

	// -----------------------------------------------------------------------
	// PDF builder
	// -----------------------------------------------------------------------

	/**
	 * Build AVV PDF and stream it to the browser.
	 *
	 * @param array $data AVV form data.
	 */
	private static function build_pdf( array $data ): void {
		$pdf = new FPDF( 'P', 'mm', 'A4' );
		$pdf->SetMargins( 20, 20, 20 );
		$pdf->SetAutoPageBreak( true, 25 );
		$pdf->AddPage();

		$jur          = $data['jurisdiction'] ?? 'de';
		$date_raw     = $data['agreement_date'] ?? wp_date( 'Y-m-d' );
		$date_display = self::format_date( $date_raw );

		// ----------------------------------------------------------------
		// Helper closures — FPDF uses a class-based approach, so we define
		// small lambdas that capture $pdf by reference.
		// ----------------------------------------------------------------
		$h1 = static function ( string $text ) use ( $pdf ): void {
			$pdf->SetFont( 'Helvetica', 'B', 14 );
			$pdf->SetFillColor( 30, 80, 160 );
			$pdf->SetTextColor( 255, 255, 255 );
			$pdf->Cell( 170, 9, self::latin1( $text ), 0, 1, 'L', true );
			$pdf->SetTextColor( 0, 0, 0 );
			$pdf->Ln( 2 );
		};
		$h2 = static function ( string $text ) use ( $pdf ): void {
			$pdf->SetFont( 'Helvetica', 'B', 11 );
			$pdf->SetFillColor( 220, 230, 245 );
			$pdf->Cell( 170, 7, self::latin1( $text ), 0, 1, 'L', true );
			$pdf->Ln( 1 );
			$pdf->SetFont( 'Helvetica', '', 10 );
		};
		$body = static function ( string $text ) use ( $pdf ): void {
			$pdf->SetFont( 'Helvetica', '', 10 );
			$pdf->MultiCell( 170, 5, self::latin1( $text ), 0, 'J' );
			$pdf->Ln( 2 );
		};
		$kv = static function ( string $key, string $val ) use ( $pdf ): void {
			$pdf->SetFont( 'Helvetica', 'B', 10 );
			$pdf->Cell( 60, 5, self::latin1( $key . ':' ), 0, 0 );
			$pdf->SetFont( 'Helvetica', '', 10 );
			$pdf->MultiCell( 110, 5, self::latin1( $val ), 0, 'L' );
		};
		$sig_block = static function ( string $party, string $name, string $place, string $date ) use ( $pdf ): void {
			$pdf->SetFont( 'Helvetica', '', 10 );
			$pdf->Ln( 10 );
			$pdf->Cell( 80, 5, self::latin1( $place . ', ' . $date ), 0, 0 );
			$pdf->Cell( 10, 5, '', 0, 0 );
			$pdf->Cell( 80, 5, self::latin1( $place . ', ' . $date ), 0, 1 );
			$pdf->Ln( 8 );
			$pdf->Cell( 80, 0, '', 'T', 0 );
			$pdf->Cell( 10, 0, '', 0, 0 );
			$pdf->Cell( 80, 0, '', 'T', 1 );
			$pdf->Ln( 2 );
			$pdf->SetFont( 'Helvetica', 'I', 9 );
			$pdf->Cell( 80, 5, self::latin1( $party ), 0, 0 );
			$pdf->Cell( 10, 5, '', 0, 0 );
			$pdf->Cell( 80, 5, self::latin1( $name ), 0, 1 );
		};

		// Jurisdiction strings.
		$law_ref = match ( $jur ) {
			'at'    => 'DSGVO i.V.m. DSG (Österreich)',
			'ch'    => 'DSG (Schweiz) i.V.m. anwendbarer DSGVO',
			default => 'DSGVO (EU) 2016/679',
		};

		// ----------------------------------------------------------------
		// COVER / TITLE
		// ----------------------------------------------------------------
		$pdf->SetFont( 'Helvetica', 'B', 18 );
		$pdf->Cell( 170, 12, 'Auftragsverarbeitungsvertrag', 0, 1, 'C' );
		$pdf->SetFont( 'Helvetica', '', 11 );
		$pdf->Cell( 170, 6, self::latin1( 'gemäß Art. 28 ' . $law_ref ), 0, 1, 'C' );
		$pdf->Ln( 6 );
		$pdf->SetFont( 'Helvetica', 'I', 10 );
		$pdf->Cell( 170, 5, self::latin1( 'Stand: ' . $date_display ), 0, 1, 'C' );
		$pdf->Ln( 8 );

		// ----------------------------------------------------------------
		// PARTIES
		// ----------------------------------------------------------------
		$h1( '§ 1 – Vertragsparteien' );

		$h2( 'Verantwortlicher (Controller)' );
		$kv( 'Name', $data['controller_name'] ?? '' );
		$kv( 'Anschrift', implode( ', ', array_filter( array(
			$data['controller_street'] ?? '',
			trim( ( $data['controller_zip'] ?? '' ) . ' ' . ( $data['controller_city'] ?? '' ) ),
			$data['controller_country'] ?? '',
		) ) ) );
		$kv( 'E-Mail', $data['controller_email'] ?? '' );
		$kv( 'Vertreten durch', $data['controller_rep'] ?? '' );
		$pdf->Ln( 3 );

		$h2( 'Auftragsverarbeiter (Processor)' );
		$kv( 'Name', $data['processor_name'] ?? '' );
		$kv( 'Anschrift', implode( ', ', array_filter( array(
			$data['processor_street'] ?? '',
			trim( ( $data['processor_zip'] ?? '' ) . ' ' . ( $data['processor_city'] ?? '' ) ),
			$data['processor_country'] ?? '',
		) ) ) );
		$kv( 'Vertreten durch', $data['processor_rep'] ?? '' );
		$pdf->Ln( 4 );

		// ----------------------------------------------------------------
		// SUBJECT
		// ----------------------------------------------------------------
		$h1( '§ 2 – Gegenstand und Dauer' );
		$body(
			'Der Auftragsverarbeiter erbringt für den Verantwortlichen folgende Leistung: ' .
			( $data['processor_service'] ?? '(keine Angabe)' ) . "\n\n" .
			'Der Vertrag gilt für die Dauer der Leistungserbringung und endet automatisch mit Beendigung des Hauptvertrags.'
		);

		// ----------------------------------------------------------------
		// INSTRUCTIONS
		// ----------------------------------------------------------------
		$h1( '§ 3 – Weisungsgebundenheit' );
		$body(
			'Der Auftragsverarbeiter verarbeitet personenbezogene Daten ausschließlich auf dokumentierte Weisung des Verantwortlichen, ' .
			'einschließlich der in diesem Vertrag festgelegten Weisungen, es sei denn, er ist nach dem Recht der Union oder ' .
			'der Mitgliedstaaten, dem er unterliegt, zur Verarbeitung verpflichtet. In einem solchen Fall teilt der ' .
			'Auftragsverarbeiter dem Verantwortlichen diese rechtlichen Anforderungen vor der Verarbeitung mit, sofern das ' .
			'betreffende Recht eine solche Mitteilung nicht aus Gründen des wichtigen öffentlichen Interesses verbietet.'
		);

		// ----------------------------------------------------------------
		// CONFIDENTIALITY
		// ----------------------------------------------------------------
		$h1( '§ 4 – Vertraulichkeit' );
		$body(
			'Der Auftragsverarbeiter gewährleistet, dass die zur Verarbeitung der personenbezogenen Daten befugten Personen ' .
			'zur Vertraulichkeit verpflichtet worden sind oder einer angemessenen gesetzlichen Verschwiegenheitspflicht unterliegen.'
		);

		// ----------------------------------------------------------------
		// SECURITY
		// ----------------------------------------------------------------
		$h1( '§ 5 – Technisch-organisatorische Maßnahmen (Art. 32 DSGVO)' );
		$body(
			'Der Auftragsverarbeiter trifft alle erforderlichen Maßnahmen gemäß Art. 32 DSGVO, insbesondere:'
		);
		$measures = array(
			'Verschlüsselung der Daten bei Übertragung (TLS 1.2+) und Speicherung (AES-256)',
			'Pseudonymisierung und Anonymisierung, soweit technisch möglich',
			'Gewährleistung der Vertraulichkeit, Integrität, Verfügbarkeit und Belastbarkeit',
			'Verfahren zur regelmäßigen Überprüfung, Bewertung und Evaluierung (Audits)',
			'Zugangskontrolle: Mehrfaktorauthentifizierung, rollenbasierte Zugriffsrechte',
			'Auftrags- und Weitergabekontrolle: Protokollierung aller Zugriffe',
		);
		foreach ( $measures as $m ) {
			$pdf->SetFont( 'Helvetica', '', 10 );
			$pdf->Cell( 6, 5, '', 0, 0 );
			$pdf->MultiCell( 164, 5, self::latin1( '• ' . $m ), 0, 'L' );
		}
		$pdf->Ln( 2 );

		// ----------------------------------------------------------------
		// SUB-PROCESSORS
		// ----------------------------------------------------------------
		$h1( '§ 6 – Unterauftragnehmer' );
		$body(
			'Der Auftragsverarbeiter darf Unterauftragnehmer nur mit schriftlicher Genehmigung des Verantwortlichen ' .
			'einsetzen. Er verpflichtet seine Unterauftragnehmer durch Vertrag gemäß Art. 28 Abs. 4 DSGVO zu ' .
			'denselben Datenschutzpflichten wie in diesem AVV festgelegt. Für Verstöße der Unterauftragnehmer ' .
			'bleibt der Auftragsverarbeiter gegenüber dem Verantwortlichen verantwortlich.'
		);

		// ----------------------------------------------------------------
		// DATA SUBJECT RIGHTS
		// ----------------------------------------------------------------
		$h1( '§ 7 – Rechte betroffener Personen' );
		$body(
			'Der Auftragsverarbeiter unterstützt den Verantwortlichen durch geeignete technische und organisatorische ' .
			'Maßnahmen soweit möglich dabei, seiner Pflicht zur Beantwortung von Anträgen auf Wahrnehmung der in ' .
			'Kapitel III DSGVO genannten Rechte der betroffenen Person nachzukommen. Er leitet eingehende ' .
			'Anfragen betroffener Personen unverzüglich an den Verantwortlichen weiter.'
		);

		// ----------------------------------------------------------------
		// BREACH NOTIFICATION
		// ----------------------------------------------------------------
		$h1( '§ 8 – Meldepflicht bei Datenpannen' );
		$body(
			'Der Auftragsverarbeiter unterrichtet den Verantwortlichen unverzüglich, spätestens innerhalb von 24 Stunden, ' .
			'nachdem er von einer Verletzung des Schutzes personenbezogener Daten Kenntnis erhalten hat (Art. 33 DSGVO). ' .
			'Er leistet dem Verantwortlichen Hilfe bei der Erfüllung seiner Pflichten gemäß Art. 33 und Art. 34 DSGVO.'
		);

		// ----------------------------------------------------------------
		// DELETION
		// ----------------------------------------------------------------
		$h1( '§ 9 – Löschung und Rückgabe' );
		$body(
			'Nach Abschluss der Erbringung der Verarbeitungsleistungen hat der Auftragsverarbeiter nach Wahl des ' .
			'Verantwortlichen alle personenbezogenen Daten zu löschen oder zurückzugeben und vorhandene Kopien zu ' .
			'vernichten, sofern nicht eine Verpflichtung zur Speicherung der personenbezogenen Daten nach dem Unionsrecht ' .
			'oder dem Recht der Mitgliedstaaten besteht.'
		);

		// ----------------------------------------------------------------
		// AUDIT RIGHTS
		// ----------------------------------------------------------------
		$h1( '§ 10 – Inspektionen und Audits' );
		$body(
			'Der Auftragsverarbeiter stellt dem Verantwortlichen alle erforderlichen Informationen zum Nachweis der ' .
			'Einhaltung der in Art. 28 DSGVO festgelegten Pflichten zur Verfügung und ermöglicht Inspektionen – ' .
			'einschließlich Audits – die vom Verantwortlichen oder einem anderen vom Verantwortlichen beauftragten ' .
			'Prüfer durchgeführt werden, und trägt zu ihnen bei.'
		);

		// ----------------------------------------------------------------
		// FINAL CLAUSES
		// ----------------------------------------------------------------
		$h1( '§ 11 – Schlussbestimmungen' );
		$body(
			'Dieser Vertrag unterliegt dem Recht der Bundesrepublik Deutschland (bzw. des jeweiligen Mitgliedstaats). ' .
			'Änderungen und Ergänzungen dieses Vertrages bedürfen der Schriftform. Sollten einzelne Bestimmungen ' .
			'ganz oder teilweise unwirksam sein, berührt dies die Wirksamkeit der übrigen Bestimmungen nicht.'
		);

		// ----------------------------------------------------------------
		// SIGNATURES
		// ----------------------------------------------------------------
		$pdf->Ln( 6 );
		$h1( 'Unterschriften' );
		$pdf->Ln( 4 );

		$sig_block(
			'Verantwortlicher: ' . ( $data['controller_name'] ?? '___________________' ),
			$data['controller_rep'] ?? '___________________',
			$data['controller_city'] ?? '___________',
			$date_display
		);
		$pdf->Ln( 14 );
		$sig_block(
			'Auftragsverarbeiter: ' . ( $data['processor_name'] ?? '___________________' ),
			$data['processor_rep'] ?? '___________________',
			$data['processor_city'] ?? '___________',
			$date_display
		);

		// ----------------------------------------------------------------
		// Stream to browser.
		// ----------------------------------------------------------------
		$filename = 'AVV-' . sanitize_file_name( $data['processor_name'] ?? 'Auftragsverarbeiter' ) . '-' . $date_raw . '.pdf';
		$pdf->Output( 'D', $filename ); // 'D' = force download.
	}

	// -----------------------------------------------------------------------
	// Helpers
	// -----------------------------------------------------------------------

	/**
	 * Get saved AVV data with defaults.
	 *
	 * @return array
	 */
	private static function get_data(): array {
		$defaults = array(
			'controller_name'    => '',
			'controller_street'  => '',
			'controller_zip'     => '',
			'controller_city'    => '',
			'controller_country' => 'Deutschland',
			'controller_email'   => '',
			'controller_rep'     => '',
			'processor_name'     => '',
			'processor_street'   => '',
			'processor_zip'      => '',
			'processor_city'     => '',
			'processor_country'  => 'Deutschland',
			'processor_rep'      => '',
			'processor_service'  => '',
			'agreement_date'     => wp_date( 'Y-m-d' ),
			'jurisdiction'       => 'de',
		);
		$saved = get_option( self::OPTION_AVV, array() );
		return wp_parse_args( $saved, $defaults );
	}

	/**
	 * Format a Y-m-d date string to locale-friendly display.
	 *
	 * @param  string $date_raw  YYYY-MM-DD.
	 * @return string
	 */
	private static function format_date( string $date_raw ): string {
		$ts = strtotime( $date_raw );
		if ( ! $ts ) {
			return $date_raw;
		}
		return date_i18n( get_option( 'date_format' ), $ts );
	}

	/**
	 * Convert UTF-8 string to ISO-8859-1 for FPDF.
	 *
	 * @param  string $text UTF-8 text.
	 * @return string ISO-8859-1 text.
	 */
	private static function latin1( string $text ): string {
		return mb_convert_encoding( $text, 'ISO-8859-1', 'UTF-8' );
	}
}

// Auto-init.
ThemeFlex_AVV_Generator::init();
