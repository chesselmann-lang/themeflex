<?php
/**
 * Blog Layouts System
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ThemeFlex Blog Layouts Class
 *
 * Manages different blog layout options and AJAX handlers.
 *
 * @since 1.0.0
 */
class ThemeFlex_Blog_Layouts {

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'wp_ajax_load_more_posts', array( $this, 'load_more_posts' ) );
		add_action( 'wp_ajax_nopriv_load_more_posts', array( $this, 'load_more_posts' ) );
	}

	/**
	 * Enqueue scripts and styles.
	 *
	 * @since 1.0.0
	 */
	public function enqueue_scripts() {
		if ( is_home() || is_archive() ) {
			wp_enqueue_style(
				'themeflex-blog-layouts',
				THEMEFLEX_URL . '/assets/css/blog-layouts.css',
				array(),
				THEMEFLEX_VERSION
			);

			wp_enqueue_script(
				'themeflex-blog-layouts',
				THEMEFLEX_URL . '/assets/js/blog-layouts.js',
				array( 'jquery' ),
				THEMEFLEX_VERSION,
				true
			);

			wp_localize_script(
				'themeflex-blog-layouts',
				'themeFlexBlogData',
				array(
					'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
					'nonce'    => wp_create_nonce( 'sf_blog_nonce' ),
				)
			);
		}
	}

	/**
	 * Load more posts via AJAX.
	 *
	 * @since 1.0.0
	 */
	public function load_more_posts() {
		check_ajax_referer( 'sf_blog_nonce' );

		// Get parameters
		$paged = isset( $_POST['paged'] ) ? absint( $_POST['paged'] ) : 1;
		$layout = isset( $_POST['layout'] ) ? sanitize_text_field( wp_unslash( $_POST['layout'] ) ) : 'grid';
		$posts_per_page = isset( $_POST['posts_per_page'] ) ? absint( $_POST['posts_per_page'] ) : get_option( 'posts_per_page' );
		$category = isset( $_POST['category'] ) ? sanitize_text_field( wp_unslash( $_POST['category'] ) ) : '';

		// Build query args
		$query_args = array(
			'paged'          => $paged,
			'posts_per_page' => $posts_per_page,
			'post_type'      => 'post',
			'post_status'    => 'publish',
		);

		// Add category filter if provided
		if ( ! empty( $category ) && 'all' !== $category ) {
			$query_args['category_name'] = $category;
		}

		// Apply filters for archive/search context
		if ( is_archive() ) {
			$query_args = apply_filters( 'themeflex_load_more_query_args', $query_args );
		}

		$query = new WP_Query( $query_args );

		ob_start();

		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				$this->render_post( $layout );
			}
		}

		$output = ob_get_clean();

		wp_send_json_success(
			array(
				'html'           => $output,
				'max_pages'      => $query->max_num_pages,
				'has_more_pages' => $paged < $query->max_num_pages,
			)
		);
	}

	/**
	 * Render single post based on layout.
	 *
	 * @since 1.0.0
	 * @param string $layout The layout type.
	 */
	public function render_post( $layout = 'grid' ) {
		$post_id = get_the_ID();
		$template_path = THEMEFLEX_DIR . '/template-parts/blog/layout-' . $layout . '.php';

		if ( file_exists( $template_path ) ) {
			include $template_path;
		} else {
			// Fallback to default layout
			?>
			<article id="post-<?php the_ID(); ?>" <?php post_class( 'blog-post blog-layout-' . esc_attr( $layout ) ); ?>>
				<header class="entry-header">
					<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '">', '</a></h2>' ); ?>
				</header>
				<div class="entry-content">
					<?php the_excerpt(); ?>
				</div>
			</article>
			<?php
		}
	}

	/**
	 * Get available layout options.
	 *
	 * @since 1.0.0
	 * @return array Layout options.
	 */
	public static function get_layouts() {
		return array(
			'grid'    => esc_html__( 'Grid', 'themeflex' ),
			'list'    => esc_html__( 'List', 'themeflex' ),
			'masonry' => esc_html__( 'Masonry', 'themeflex' ),
			'metro'   => esc_html__( 'Metro', 'themeflex' ),
			'classic' => esc_html__( 'Classic', 'themeflex' ),
		);
	}

	/**
	 * Get pagination type options.
	 *
	 * @since 1.0.0
	 * @return array Pagination options.
	 */
	public static function get_pagination_types() {
		return array(
			'numeric'         => esc_html__( 'Numeric', 'themeflex' ),
			'load-more'       => esc_html__( 'Load More Button', 'themeflex' ),
			'infinite-scroll' => esc_html__( 'Infinite Scroll', 'themeflex' ),
		);
	}

	/**
	 * Get current blog layout.
	 *
	 * @since 1.0.0
	 * @return string The current layout.
	 */
	public static function get_current_layout() {
		return get_theme_mod( 'themeflex_blog_layout', 'grid' );
	}

	/**
	 * Get current pagination type.
	 *
	 * @since 1.0.0
	 * @return string The current pagination type.
	 */
	public static function get_current_pagination() {
		return get_theme_mod( 'themeflex_blog_pagination', 'numeric' );
	}

	/**
	 * Render blog posts with selected layout.
	 *
	 * @since 1.0.0
	 */
	public static function render_blog() {
		$layout = self::get_current_layout();
		$pagination = self::get_current_pagination();
		?>
		<div class="blog-container blog-layout-<?php echo esc_attr( $layout ); ?> blog-pagination-<?php echo esc_attr( $pagination ); ?>">
			<div class="blog-posts">
				<?php
				if ( have_posts() ) {
					while ( have_posts() ) {
						the_post();
						?>
						<article id="post-<?php the_ID(); ?>" <?php post_class( 'blog-post' ); ?>>
							<header class="entry-header">
								<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '">', '</a></h2>' ); ?>
							</header>
							<div class="entry-content">
								<?php the_excerpt(); ?>
								<a href="<?php echo esc_url( get_permalink() ); ?>" class="read-more">
									<?php esc_html_e( 'Read More', 'themeflex' ); ?>
								</a>
							</div>
						</article>
						<?php
					}
				}
				?>
			</div>

			<?php self::render_pagination( $pagination ); ?>
		</div>
		<?php
	}

	/**
	 * Render pagination.
	 *
	 * @since 1.0.0
	 * @param string $type The pagination type.
	 */
	public static function render_pagination( $type = 'numeric' ) {
		global $wp_query;

		switch ( $type ) {
			case 'load-more':
				self::render_load_more_button();
				break;

			case 'infinite-scroll':
				self::render_infinite_scroll();
				break;

			case 'numeric':
			default:
				self::render_numeric_pagination();
				break;
		}
	}

	/**
	 * Render numeric pagination.
	 *
	 * @since 1.0.0
	 */
	private static function render_numeric_pagination() {
		global $wp_query;

		$big = 999999999;
		$pages = paginate_links(
			array(
				'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
				'format'    => '?paged=%#%',
				'current'   => max( 1, get_query_var( 'paged' ) ),
				'total'     => $wp_query->max_num_pages,
				'type'      => 'array',
				'prev_text' => esc_html__( '&laquo; Previous', 'themeflex' ),
				'next_text' => esc_html__( 'Next &raquo;', 'themeflex' ),
			)
		);

		if ( is_array( $pages ) ) {
			echo '<nav class="pagination numeric-pagination">';
			echo '<ul class="page-numbers">';
			echo implode( '', $pages );
			echo '</ul>';
			echo '</nav>';
		}
	}

	/**
	 * Render load more button.
	 *
	 * @since 1.0.0
	 */
	private static function render_load_more_button() {
		global $wp_query;

		if ( $wp_query->max_num_pages > 1 ) {
			$current_page = max( 1, get_query_var( 'paged' ) );
			?>
			<div class="pagination load-more-pagination">
				<button class="load-more-btn" data-current-page="<?php echo absint( $current_page ); ?>" data-max-pages="<?php echo absint( $wp_query->max_num_pages ); ?>">
					<?php esc_html_e( 'Load More', 'themeflex' ); ?>
				</button>
				<div class="loading-indicator" style="display: none;">
					<span class="spinner"></span>
				</div>
			</div>
			<?php
		}
	}

	/**
	 * Render infinite scroll trigger.
	 *
	 * @since 1.0.0
	 */
	private static function render_infinite_scroll() {
		global $wp_query;

		if ( $wp_query->max_num_pages > 1 ) {
			$current_page = max( 1, get_query_var( 'paged' ) );
			?>
			<div class="pagination infinite-scroll" data-current-page="<?php echo absint( $current_page ); ?>" data-max-pages="<?php echo absint( $wp_query->max_num_pages ); ?>">
				<div class="infinite-scroll-trigger"></div>
				<div class="infinite-scroll-loading" style="display: none;">
					<span class="spinner"></span>
				</div>
			</div>
			<?php
		}
	}
}

// Initialize the class
new ThemeFlex_Blog_Layouts();

/**
 * Render blog layout.
 *
 * @since 1.0.0
 */
function themeflex_render_blog() {
	ThemeFlex_Blog_Layouts::render_blog();
}
