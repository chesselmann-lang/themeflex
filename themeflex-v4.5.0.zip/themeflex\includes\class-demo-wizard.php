<?php
/**
 * Demo Importer — Branchen-Wizard Controller
 *
 * Loads mapping.json, matches a user-supplied industry keyword to a category,
 * returns template suggestions, skin recommendation, and Schema.org type.
 *
 * Optionally uses an AI provider for fuzzy matching if an API key is set.
 * Falls back to keyword matching when no key is available.
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ThemeFlex_Demo_Wizard
 */
class ThemeFlex_Demo_Wizard {

	/**
	 * Admin page slug.
	 *
	 * @var string
	 */
	const PAGE_SLUG = 'themeflex-setup-wizard';

	/**
	 * wp_options key to record dismissal.
	 *
	 * @var string
	 */
	const OPTION_DISMISSED = 'themeflex_wizard_dismissed';

	/**
	 * Cached mapping data.
	 *
	 * @var array|null
	 */
	private static ?array $mapping = null;

	/**
	 * Register hooks.
	 */
	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_notices', array( __CLASS__, 'maybe_show_notice' ) );
		add_action( 'wp_ajax_themeflex_wizard_match', array( __CLASS__, 'handle_match' ) );
		add_action( 'wp_ajax_themeflex_wizard_dismiss', array( __CLASS__, 'handle_dismiss' ) );
	}

	// -----------------------------------------------------------------------
	// Menu + Notices
	// -----------------------------------------------------------------------

	/**
	 * Register setup wizard submenu under ThemeFlex.
	 */
	public static function register_menu(): void {
		add_submenu_page(
			'themeflex',
			__( 'Setup Wizard', 'themeflex' ),
			__( 'Setup Wizard', 'themeflex' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Show admin notice after theme activation (if wizard not dismissed).
	 */
	public static function maybe_show_notice(): void {
		if ( get_option( self::OPTION_DISMISSED ) ) {
			return;
		}

		// Only show on ThemeFlex admin pages and dashboard.
		$screen = get_current_screen();
		if ( ! $screen || ( 'dashboard' !== $screen->id && false === strpos( $screen->id, 'themeflex' ) ) ) {
			return;
		}

		$url = admin_url( 'admin.php?page=' . self::PAGE_SLUG );
		?>
		<div class="notice notice-info is-dismissible" id="tf-wizard-notice">
			<p>
				<strong><?php esc_html_e( '🎉 Welcome to ThemeFlex!', 'themeflex' ); ?></strong>
				<?php esc_html_e( 'Use the Setup Wizard to find the perfect template for your industry.', 'themeflex' ); ?>
				<a href="<?php echo esc_url( $url ); ?>" class="button button-primary" style="margin-left:1rem;">
					<?php esc_html_e( 'Start Setup Wizard', 'themeflex' ); ?>
				</a>
				<a href="#" id="tf-wizard-dismiss" style="margin-left:.75rem;">
					<?php esc_html_e( 'Dismiss', 'themeflex' ); ?>
				</a>
			</p>
		</div>
		<script>
		document.getElementById('tf-wizard-dismiss')?.addEventListener('click', function(e){
			e.preventDefault();
			document.getElementById('tf-wizard-notice')?.remove();
			fetch('<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>', {
				method:'POST',
				body: new URLSearchParams({ action:'themeflex_wizard_dismiss', nonce:'<?php echo esc_js( wp_create_nonce( 'tf_wizard_dismiss' ) ); ?>' }),
				credentials:'same-origin',
			});
		});
		</script>
		<?php
	}

	// -----------------------------------------------------------------------
	// AJAX handlers
	// -----------------------------------------------------------------------

	/**
	 * AJAX: match a user keyword to an industry category.
	 */
	public static function handle_match(): void {
		check_ajax_referer( 'tf_wizard_match', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Forbidden' ), 403 );
		}

		$keyword  = sanitize_text_field( wp_unslash( $_POST['keyword'] ?? '' ) );
		$location = sanitize_text_field( wp_unslash( $_POST['location'] ?? '' ) );
		$usp      = sanitize_text_field( wp_unslash( $_POST['usp'] ?? '' ) );

		if ( empty( $keyword ) ) {
			wp_send_json_error( array( 'message' => 'Keyword required.' ) );
		}

		// Try AI matching first (if API key set).
		$result = null;
		if ( ThemeFlex_Provider_Factory::has_api_key() ) {
			$result = self::ai_match( $keyword, $location, $usp );
		}

		// Fallback to offline keyword matching.
		if ( ! $result ) {
			$result = self::offline_match( $keyword );
		}

		if ( ! $result ) {
			wp_send_json_error( array( 'message' => __( 'No matching industry found. Try a different keyword.', 'themeflex' ) ) );
		}

		wp_send_json_success( $result );
	}

	/**
	 * AJAX: dismiss wizard.
	 */
	public static function handle_dismiss(): void {
		check_ajax_referer( 'tf_wizard_dismiss', 'nonce' );
		update_option( self::OPTION_DISMISSED, true, false );
		wp_send_json_success();
	}

	// -----------------------------------------------------------------------
	// Matching logic
	// -----------------------------------------------------------------------

	/**
	 * AI-powered industry match.
	 *
	 * @param  string $keyword
	 * @param  string $location
	 * @param  string $usp
	 * @return array|null
	 */
	private static function ai_match( string $keyword, string $location, string $usp ): ?array {
		$mapping    = self::load_mapping();
		$categories = array_column( $mapping['industry_categories'], 'id' );
		$cat_list   = implode( ', ', $categories );

		$system = "You are a website template recommender. Given a user's business description, select the single best matching category from this list:\n{$cat_list}\n\nRespond ONLY with a valid JSON object: {\"category\": \"category-id\"}";
		$user   = "Business: {$keyword}. Location: {$location}. USP: {$usp}.";

		try {
			$provider = ThemeFlex_Provider_Factory::make();
			$result   = $provider->chat( $system, $user, 0.2, 60 );
			$data     = json_decode( $result['content'], true );
			if ( isset( $data['category'] ) ) {
				return self::build_result( $data['category'] );
			}
		} catch ( RuntimeException $e ) {
			// Fall through to offline matching.
		}

		return null;
	}

	/**
	 * Keyword-based offline match.
	 *
	 * @param  string $keyword
	 * @return array|null
	 */
	private static function offline_match( string $keyword ): ?array {
		$mapping  = self::load_mapping();
		$keyword  = mb_strtolower( $keyword, 'UTF-8' );
		$best_id  = null;
		$best_hit = 0;

		foreach ( $mapping['industry_categories'] as $cat ) {
			$hits = 0;
			foreach ( $cat['keywords'] as $kw ) {
				if ( false !== mb_strpos( $keyword, $kw ) || false !== mb_strpos( $kw, $keyword ) ) {
					$hits++;
				}
			}
			if ( $hits > $best_hit ) {
				$best_hit = $hits;
				$best_id  = $cat['id'];
			}
		}

		// Fallback: "general".
		return self::build_result( $best_id ?? 'general' );
	}

	/**
	 * Build the result array for a given category ID.
	 *
	 * @param  string $category_id
	 * @return array|null
	 */
	private static function build_result( string $category_id ): ?array {
		$mapping = self::load_mapping();
		foreach ( $mapping['industry_categories'] as $cat ) {
			if ( $cat['id'] === $category_id ) {
				return array(
					'category_id'   => $cat['id'],
					'category_label'=> $cat['label'],
					'schema_type'   => $cat['schema_type'],
					'skin'          => $cat['recommended_skin'],
					'templates'     => $cat['templates'],
				);
			}
		}
		return null;
	}

	// -----------------------------------------------------------------------
	// Mapping loader
	// -----------------------------------------------------------------------

	/**
	 * Load and cache mapping.json.
	 *
	 * @return array
	 */
	private static function load_mapping(): array {
		if ( null !== self::$mapping ) {
			return self::$mapping;
		}

		$path = THEMEFLEX_DIR . '/inc/demo-importer/mapping.json';
		if ( ! file_exists( $path ) ) {
			return self::$mapping = array( 'industry_categories' => array() );
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$raw           = file_get_contents( $path );
		self::$mapping = json_decode( $raw, true ) ?? array( 'industry_categories' => array() );
		return self::$mapping;
	}

	// -----------------------------------------------------------------------
	// Render
	// -----------------------------------------------------------------------

	/**
	 * Render the setup wizard admin page.
	 */
	public static function render_page(): void {
		$view = THEMEFLEX_DIR . '/includes/admin/views/setup-wizard.php';
		if ( file_exists( $view ) ) {
			include $view;
		}
	}
}

// Auto-init.
ThemeFlex_Demo_Wizard::init();
