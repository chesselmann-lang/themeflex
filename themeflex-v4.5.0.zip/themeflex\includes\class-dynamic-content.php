<?php
/**
 * Dynamic Content System
 *
 * ACF / Meta Box integration with dynamic tags for Elementor — like Elementor Pro's dynamic tags.
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ThemeFlex_Dynamic_Content {

	/**
	 * Initialize the dynamic content system
	 *
	 * @since 1.0.0
	 */
	public static function init() {
		// Only register if Elementor is active
		if ( ! did_action( 'elementor/loaded' ) && ! function_exists( 'elementor_load_plugin_textdomain' ) ) {
			return;
		}

		add_action( 'elementor/dynamic_tags/register_tags', array( __CLASS__, 'register_dynamic_tags' ) );
		add_filter( 'elementor/frontend/widget/before_render', array( __CLASS__, 'apply_conditional_display' ), 10, 1 );
		add_shortcode( 'sf_dynamic', array( __CLASS__, 'render_shortcode' ) );
	}

	/**
	 * Register dynamic tags for Elementor
	 *
	 * @since 1.0.0
	 */
	public static function register_dynamic_tags( $dynamic_tags ) {
		// Post tags
		self::register_tag( $dynamic_tags, 'sf_post_title', esc_html__( 'Post Title', 'themeflex' ), 'post' );
		self::register_tag( $dynamic_tags, 'sf_post_excerpt', esc_html__( 'Post Excerpt', 'themeflex' ), 'post' );
		self::register_tag( $dynamic_tags, 'sf_post_content', esc_html__( 'Post Content', 'themeflex' ), 'post' );
		self::register_tag( $dynamic_tags, 'sf_post_date', esc_html__( 'Post Date', 'themeflex' ), 'post' );
		self::register_tag( $dynamic_tags, 'sf_post_author', esc_html__( 'Post Author', 'themeflex' ), 'post' );
		self::register_tag( $dynamic_tags, 'sf_post_featured_image', esc_html__( 'Post Featured Image', 'themeflex' ), 'post' );
		self::register_tag( $dynamic_tags, 'sf_post_url', esc_html__( 'Post URL', 'themeflex' ), 'post' );
		self::register_tag( $dynamic_tags, 'sf_post_terms', esc_html__( 'Post Terms', 'themeflex' ), 'post' );
		self::register_tag( $dynamic_tags, 'sf_post_meta', esc_html__( 'Post Meta', 'themeflex' ), 'post' );

		// Site tags
		self::register_tag( $dynamic_tags, 'sf_site_title', esc_html__( 'Site Title', 'themeflex' ), 'site' );
		self::register_tag( $dynamic_tags, 'sf_site_tagline', esc_html__( 'Site Tagline', 'themeflex' ), 'site' );
		self::register_tag( $dynamic_tags, 'sf_site_url', esc_html__( 'Site URL', 'themeflex' ), 'site' );
		self::register_tag( $dynamic_tags, 'sf_site_logo', esc_html__( 'Site Logo', 'themeflex' ), 'site' );
		self::register_tag( $dynamic_tags, 'sf_current_year', esc_html__( 'Current Year', 'themeflex' ), 'site' );
		self::register_tag( $dynamic_tags, 'sf_current_date', esc_html__( 'Current Date', 'themeflex' ), 'site' );

		// Author tags
		self::register_tag( $dynamic_tags, 'sf_author_name', esc_html__( 'Author Name', 'themeflex' ), 'author' );
		self::register_tag( $dynamic_tags, 'sf_author_bio', esc_html__( 'Author Bio', 'themeflex' ), 'author' );
		self::register_tag( $dynamic_tags, 'sf_author_avatar', esc_html__( 'Author Avatar', 'themeflex' ), 'author' );
		self::register_tag( $dynamic_tags, 'sf_author_url', esc_html__( 'Author URL', 'themeflex' ), 'author' );
		self::register_tag( $dynamic_tags, 'sf_author_meta', esc_html__( 'Author Meta', 'themeflex' ), 'author' );

		// WooCommerce tags (if active)
		if ( class_exists( 'WooCommerce' ) ) {
			self::register_tag( $dynamic_tags, 'sf_product_price', esc_html__( 'Product Price', 'themeflex' ), 'woocommerce' );
			self::register_tag( $dynamic_tags, 'sf_product_sale_price', esc_html__( 'Product Sale Price', 'themeflex' ), 'woocommerce' );
			self::register_tag( $dynamic_tags, 'sf_product_rating', esc_html__( 'Product Rating', 'themeflex' ), 'woocommerce' );
			self::register_tag( $dynamic_tags, 'sf_product_stock', esc_html__( 'Product Stock', 'themeflex' ), 'woocommerce' );
			self::register_tag( $dynamic_tags, 'sf_product_sku', esc_html__( 'Product SKU', 'themeflex' ), 'woocommerce' );
		}

		// Archive tags
		self::register_tag( $dynamic_tags, 'sf_archive_title', esc_html__( 'Archive Title', 'themeflex' ), 'archive' );
		self::register_tag( $dynamic_tags, 'sf_archive_description', esc_html__( 'Archive Description', 'themeflex' ), 'archive' );
		self::register_tag( $dynamic_tags, 'sf_term_image', esc_html__( 'Term Image', 'themeflex' ), 'archive' );

		// User tags
		self::register_tag( $dynamic_tags, 'sf_current_user_name', esc_html__( 'Current User Name', 'themeflex' ), 'user' );
		self::register_tag( $dynamic_tags, 'sf_current_user_email', esc_html__( 'Current User Email', 'themeflex' ), 'user' );
		self::register_tag( $dynamic_tags, 'sf_current_user_role', esc_html__( 'Current User Role', 'themeflex' ), 'user' );

		// ACF tags (auto-detect if ACF is active)
		if ( function_exists( 'acf_get_field_groups' ) ) {
			$field_groups = acf_get_field_groups();
			if ( $field_groups ) {
				foreach ( $field_groups as $group ) {
					$fields = acf_get_fields( $group['ID'] );
					if ( $fields ) {
						foreach ( $fields as $field ) {
							$tag_id = 'sf_acf_' . $field['name'];
							self::register_tag( $dynamic_tags, $tag_id, 'ACF: ' . $field['label'], 'acf' );
						}
					}
				}
			}
		}
	}

	/**
	 * Register individual dynamic tag
	 *
	 * @since 1.0.0
	 */
	private static function register_tag( $dynamic_tags, $tag_id, $label, $category ) {
		// This would normally extend Elementor\Core\DynamicTags\Tag
		// For simplicity, we're using filters to replace dynamic content
		// In a more robust implementation, create individual tag classes
	}

	/**
	 * Apply conditional display logic
	 *
	 * @since 1.0.0
	 */
	public static function apply_conditional_display( $widget ) {
		$settings = $widget->get_settings();

		// Check for conditional display settings
		if ( ! isset( $settings['sf_conditional_display'] ) || ! $settings['sf_conditional_display'] ) {
			return;
		}

		$conditions = isset( $settings['sf_conditions'] ) ? $settings['sf_conditions'] : array();

		if ( ! is_array( $conditions ) || empty( $conditions ) ) {
			return;
		}

		$display = self::check_conditions( $conditions, isset( $settings['sf_condition_logic'] ) ? $settings['sf_condition_logic'] : 'and' );

		if ( ! $display ) {
			$widget->add_render_attribute( '_wrapper', 'style', 'display: none !important;' );
		}
	}

	/**
	 * Check conditional display conditions
	 *
	 * @since 1.0.0
	 */
	private static function check_conditions( $conditions, $logic = 'and' ) {
		if ( empty( $conditions ) ) {
			return true;
		}

		$results = array();

		foreach ( $conditions as $condition ) {
			$type = isset( $condition['type'] ) ? $condition['type'] : '';
			$operator = isset( $condition['operator'] ) ? $condition['operator'] : '=';
			$value = isset( $condition['value'] ) ? $condition['value'] : '';

			$result = false;

			switch ( $type ) {
				case 'user_logged_in':
					$result = is_user_logged_in();
					if ( 'not' === $operator ) {
						$result = ! $result;
					}
					break;

				case 'user_logged_out':
					$result = ! is_user_logged_in();
					if ( 'not' === $operator ) {
						$result = ! $result;
					}
					break;

				case 'user_role':
					if ( is_user_logged_in() ) {
						$current_user = wp_get_current_user();
						$user_roles = $current_user->roles;
						$result = in_array( $value, $user_roles, true );
						if ( 'not' === $operator ) {
							$result = ! $result;
						}
					}
					break;

				case 'date_range':
					$current_date = current_time( 'Y-m-d' );
					$date_from = isset( $condition['date_from'] ) ? $condition['date_from'] : '';
					$date_to = isset( $condition['date_to'] ) ? $condition['date_to'] : '';

					if ( $date_from && $date_to ) {
						$result = $current_date >= $date_from && $current_date <= $date_to;
					}
					break;

				case 'url_parameter':
					$param = isset( $condition['param_name'] ) ? $condition['param_name'] : '';
					$param_value = isset( $_GET[ $param ] ) ? sanitize_text_field( wp_unslash( $_GET[ $param ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
					$result = $param_value === $value;
					if ( 'not' === $operator ) {
						$result = ! $result;
					}
					break;

				case 'cookie':
					$cookie_name = isset( $condition['cookie_name'] ) ? $condition['cookie_name'] : '';
					$cookie_value = isset( $_COOKIE[ $cookie_name ] ) ? sanitize_text_field( wp_unslash( $_COOKIE[ $cookie_name ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
					$result = $cookie_value === $value;
					if ( 'not' === $operator ) {
						$result = ! $result;
					}
					break;

				case 'acf_field':
					if ( function_exists( 'get_field' ) ) {
						$field_value = get_field( $value );
						$result = ! empty( $field_value );
						if ( 'not' === $operator ) {
							$result = ! $result;
						}
					}
					break;

				case 'woo_cart_status':
					if ( class_exists( 'WooCommerce' ) ) {
						$cart_empty = WC()->cart->is_empty();
						if ( 'cart_not_empty' === $value ) {
							$result = ! $cart_empty;
						} else {
							$result = $cart_empty;
						}
					}
					break;
			}

			$results[] = $result;
		}

		// Apply logic
		if ( 'or' === $logic ) {
			return in_array( true, $results, true );
		}

		return ! in_array( false, $results, true );
	}

	/**
	 * Render shortcode for dynamic content
	 *
	 * @since 1.0.0
	 */
	public static function render_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'field' => '',
				'format' => 'text',
			),
			$atts,
			'sf_dynamic'
		);

		return self::get_dynamic_value( $atts['field'], $atts['format'] );
	}

	/**
	 * Get dynamic value by field name
	 *
	 * @since 1.0.0
	 */
	public static function get_dynamic_value( $field, $format = 'text' ) {
		$value = '';

		// Post tags
		if ( 'post_title' === $field ) {
			$value = get_the_title();
		} elseif ( 'post_excerpt' === $field ) {
			$value = get_the_excerpt();
		} elseif ( 'post_content' === $field ) {
			$post = get_post();
			$value = $post ? $post->post_content : '';
		} elseif ( 'post_date' === $field ) {
			$value = get_the_date();
		} elseif ( 'post_author' === $field ) {
			$value = get_the_author();
		} elseif ( 'post_featured_image' === $field ) {
			$value = get_the_post_thumbnail_url();
			if ( 'html' === $format ) {
				return get_the_post_thumbnail();
			}
		} elseif ( 'post_url' === $field ) {
			$value = get_the_permalink();
		} elseif ( 'post_terms' === $field ) {
			$terms = get_the_terms( get_the_ID(), 'category' );
			if ( $terms && ! is_wp_error( $terms ) ) {
				$value = implode( ', ', wp_list_pluck( $terms, 'name' ) );
			}
		} elseif ( strpos( $field, 'post_meta_' ) === 0 ) {
			$meta_key = substr( $field, 10 );
			$value = get_post_meta( get_the_ID(), $meta_key, true );
		}

		// Site tags
		elseif ( 'site_title' === $field ) {
			$value = get_bloginfo( 'name' );
		} elseif ( 'site_tagline' === $field ) {
			$value = get_bloginfo( 'description' );
		} elseif ( 'site_url' === $field ) {
			$value = site_url();
		} elseif ( 'site_logo' === $field ) {
			$logo_id = get_theme_mod( 'custom_logo' );
			$value = wp_get_attachment_image_url( $logo_id );
			if ( 'html' === $format ) {
				return wp_get_attachment_image( $logo_id );
			}
		} elseif ( 'current_year' === $field ) {
			$value = gmdate( 'Y' );
		} elseif ( 'current_date' === $field ) {
			$value = current_time( 'Y-m-d' );
		}

		// Author tags
		elseif ( 'author_name' === $field ) {
			$value = get_the_author_meta( 'display_name' );
		} elseif ( 'author_bio' === $field ) {
			$value = get_the_author_meta( 'description' );
		} elseif ( 'author_avatar' === $field ) {
			$value = get_avatar_url( get_the_author_meta( 'ID' ) );
			if ( 'html' === $format ) {
				return get_avatar( get_the_author_meta( 'ID' ) );
			}
		} elseif ( 'author_url' === $field ) {
			$value = get_the_author_meta( 'user_url' );
		} elseif ( strpos( $field, 'author_meta_' ) === 0 ) {
			$meta_key = substr( $field, 12 );
			$value = get_the_author_meta( $meta_key );
		}

		// WooCommerce tags
		elseif ( class_exists( 'WooCommerce' ) && is_product() ) {
			$product = wc_get_product();
			if ( $product ) {
				if ( 'product_price' === $field ) {
					$value = $product->get_price_html();
					if ( 'text' === $format ) {
						$value = $product->get_price();
					}
				} elseif ( 'product_sale_price' === $field ) {
					$value = $product->get_sale_price();
				} elseif ( 'product_rating' === $field ) {
					$value = $product->get_average_rating();
				} elseif ( 'product_stock' === $field ) {
					$value = $product->get_stock_quantity();
				} elseif ( 'product_sku' === $field ) {
					$value = $product->get_sku();
				}
			}
		}

		// Archive tags
		elseif ( 'archive_title' === $field ) {
			$value = get_the_archive_title();
		} elseif ( 'archive_description' === $field ) {
			$value = get_the_archive_description();
		} elseif ( 'term_image' === $field && is_tax() ) {
			$term_id = get_queried_object()->term_id;
			$image_id = get_term_meta( $term_id, 'thumbnail_id', true );
			$value = wp_get_attachment_image_url( $image_id );
			if ( 'html' === $format ) {
				return wp_get_attachment_image( $image_id );
			}
		}

		// User tags
		elseif ( 'current_user_name' === $field ) {
			$current_user = wp_get_current_user();
			$value = $current_user->display_name ?: $current_user->user_login;
		} elseif ( 'current_user_email' === $field ) {
			$current_user = wp_get_current_user();
			$value = $current_user->user_email;
		} elseif ( 'current_user_role' === $field ) {
			$current_user = wp_get_current_user();
			$value = ! empty( $current_user->roles ) ? implode( ', ', $current_user->roles ) : '';
		}

		// ACF tags
		elseif ( function_exists( 'get_field' ) && strpos( $field, 'acf_' ) === 0 ) {
			$acf_field = substr( $field, 4 );
			$value = get_field( $acf_field );

			if ( 'html' === $format && is_array( $value ) ) {
				// For ACF galleries/repeaters, return as HTML
				if ( isset( $value[0] ) && is_array( $value[0] ) ) {
					return wp_json_encode( $value );
				}
			}
		}

		return esc_html( $value );
	}

	/**
	 * Filter content to replace dynamic tags
	 *
	 * @since 1.0.0
	 */
	public static function replace_dynamic_tags( $content ) {
		// Match [sf_dynamic field="..."] patterns
		$pattern = '/\[sf_dynamic\s+field=["\']([^"\']+)["\']\]/i';
		$content = preg_replace_callback(
			$pattern,
			function ( $matches ) {
				return self::get_dynamic_value( $matches[1] );
			},
			$content
		);

		return $content;
	}
}

// Initialize only if Elementor is loaded
add_action( 'wp_loaded', array( 'ThemeFlex_Dynamic_Content', 'init' ) );
