<?php
/**
 * Font Local Host
 *
 * Automatically downloads Google Fonts CSS + WOFF2 files to the WordPress
 * uploads directory and rewrites all font URLs to serve them locally.
 *
 * Triggered on theme_mod change for 'sf_typography_pair' and 'sf_skin'.
 * Falls back transparently to remote Google Fonts if the download fails.
 *
 * DSGVO/GDPR motivation: self-hosting fonts avoids sending visitor IP
 * addresses to Google servers, which constitutes data transfer under GDPR.
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ThemeFlex_Font_Local_Host
 */
class ThemeFlex_Font_Local_Host {

	/**
	 * Sub-directory inside wp-content/uploads/ for cached font files.
	 *
	 * @var string
	 */
	const UPLOAD_SUBDIR = 'themeflex-fonts';

	/**
	 * wp_options key for the local font map.
	 *
	 * @var string
	 */
	const OPTION_FONT_MAP = 'themeflex_local_font_map';

	/**
	 * Timeout for remote font download requests (seconds).
	 *
	 * @var int
	 */
	const DOWNLOAD_TIMEOUT = 20;

	/**
	 * Register hooks.
	 */
	public static function init(): void {
		// Rewrite remote font URLs to local URLs in the <head>.
		add_filter( 'style_loader_tag', array( __CLASS__, 'rewrite_font_url' ), 20, 2 );
		add_filter( 'wp_resource_hints', array( __CLASS__, 'remove_google_preconnect' ), 10, 2 );

		// Download fonts when the typography pair changes.
		add_action( 'update_option_theme_mods_' . get_option( 'stylesheet' ), array( __CLASS__, 'maybe_download_on_mod_change' ), 10, 2 );

		// Admin AJAX: manually trigger re-download.
		add_action( 'wp_ajax_themeflex_download_fonts', array( __CLASS__, 'handle_ajax_download' ) );

		// Admin notice if local fonts are not yet cached.
		add_action( 'admin_notices', array( __CLASS__, 'maybe_show_download_notice' ) );
	}

	// -----------------------------------------------------------------------
	// URL rewriting
	// -----------------------------------------------------------------------

	/**
	 * Replace Google Fonts stylesheet URLs with local equivalents.
	 *
	 * @param  string $html    Original <link> tag HTML.
	 * @param  string $handle  Script handle.
	 * @return string          Modified tag HTML.
	 */
	public static function rewrite_font_url( string $html, string $handle ): string {
		if ( false === strpos( $html, 'fonts.googleapis.com' ) ) {
			return $html;
		}

		$map = get_option( self::OPTION_FONT_MAP, array() );

		if ( empty( $map ) ) {
			// Trigger background download.
			if ( ! get_transient( 'themeflex_font_dl_pending' ) ) {
				set_transient( 'themeflex_font_dl_pending', 1, 3600 );
				wp_schedule_single_event( time() + 5, 'themeflex_download_fonts_event' );
			}
			return $html; // Serve Google remote until cache is ready.
		}

		foreach ( $map as $remote_url => $local_url ) {
			$html = str_replace( esc_url( $remote_url ), esc_url( $local_url ), $html );
		}

		return $html;
	}

	/**
	 * Remove Google Fonts preconnect resource hints.
	 *
	 * @param  array  $hints  Existing resource hints.
	 * @param  string $type   Hint type (dns-prefetch, preconnect, etc.).
	 * @return array
	 */
	public static function remove_google_preconnect( array $hints, string $type ): array {
		if ( ! in_array( $type, array( 'preconnect', 'dns-prefetch' ), true ) ) {
			return $hints;
		}

		$map = get_option( self::OPTION_FONT_MAP, array() );
		if ( empty( $map ) ) {
			return $hints;
		}

		return array_filter( $hints, static function ( $hint ) {
			$url = is_array( $hint ) ? ( $hint['href'] ?? '' ) : $hint;
			return false === strpos( (string) $url, 'fonts.googleapis.com' )
				&& false === strpos( (string) $url, 'fonts.gstatic.com' );
		} );
	}

	// -----------------------------------------------------------------------
	// Download trigger
	// -----------------------------------------------------------------------

	/**
	 * Check if the relevant theme mods changed and trigger a font re-download.
	 *
	 * @param  mixed $old_value  Previous option value.
	 * @param  mixed $new_value  New option value.
	 */
	public static function maybe_download_on_mod_change( $old_value, $new_value ): void {
		if ( ! is_array( $old_value ) || ! is_array( $new_value ) ) {
			return;
		}

		$watch_keys = array( 'sf_typography_pair', 'sf_skin' );
		foreach ( $watch_keys as $key ) {
			if ( ( $old_value[ $key ] ?? null ) !== ( $new_value[ $key ] ?? null ) ) {
				// Clear old map and schedule fresh download.
				delete_option( self::OPTION_FONT_MAP );
				wp_schedule_single_event( time() + 2, 'themeflex_download_fonts_event' );
				return;
			}
		}
	}

	/**
	 * AJAX handler: manually download / refresh local fonts.
	 */
	public static function handle_ajax_download(): void {
		check_ajax_referer( 'themeflex_download_fonts', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied.' ), 403 );
		}

		$result = self::download_and_cache();
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success( array( 'fonts_cached' => count( get_option( self::OPTION_FONT_MAP, array() ) ) ) );
	}

	/**
	 * Admin notice: prompt to download fonts if none are cached yet.
	 */
	public static function maybe_show_download_notice(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$screen = get_current_screen();
		if ( ! $screen || false === strpos( $screen->id, 'themeflex' ) ) {
			return;
		}

		$map = get_option( self::OPTION_FONT_MAP, array() );
		if ( ! empty( $map ) ) {
			return; // Already cached.
		}

		$nonce = wp_create_nonce( 'themeflex_download_fonts' );
		?>
		<div class="notice notice-warning" id="tf-font-notice">
			<p>
				<strong><?php esc_html_e( 'ThemeFlex DSGVO:', 'themeflex' ); ?></strong>
				<?php esc_html_e( 'Google Fonts are not yet cached locally. Download them now to ensure DSGVO/GDPR compliance.', 'themeflex' ); ?>
				<button type="button" class="button button-secondary" id="tf-dl-fonts-btn" style="margin-left:.75rem;" data-nonce="<?php echo esc_attr( $nonce ); ?>">
					<?php esc_html_e( '⬇ Download Fonts Locally', 'themeflex' ); ?>
				</button>
				<span id="tf-dl-fonts-status" style="margin-left:.5rem;font-size:.875rem;color:#6b7280;"></span>
			</p>
		</div>
		<script>
		(function(){
			var btn = document.getElementById('tf-dl-fonts-btn');
			if(!btn) return;
			btn.addEventListener('click', function(){
				btn.disabled=true;
				document.getElementById('tf-dl-fonts-status').textContent='<?php echo esc_js( __( 'Downloading…', 'themeflex' ) ); ?>';
				var fd = new FormData();
				fd.append('action','themeflex_download_fonts');
				fd.append('nonce', btn.dataset.nonce);
				fetch('<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>',{method:'POST',body:fd,credentials:'same-origin'})
				.then(function(r){return r.json();})
				.then(function(data){
					if(data.success){
						document.getElementById('tf-font-notice').remove();
					} else {
						document.getElementById('tf-dl-fonts-status').textContent='✗ '+(data.data?data.data.message:'Error');
						document.getElementById('tf-dl-fonts-status').style.color='#dc2626';
						btn.disabled=false;
					}
				})
				.catch(function(){
					document.getElementById('tf-dl-fonts-status').textContent='<?php echo esc_js( __( 'Request failed. Try again.', 'themeflex' ) ); ?>';
					btn.disabled=false;
				});
			});
		})();
		</script>
		<?php
	}

	// -----------------------------------------------------------------------
	// Download engine
	// -----------------------------------------------------------------------

	/**
	 * Discover all enqueued Google Fonts stylesheet URLs, download the CSS
	 * and all referenced WOFF2 files, store them locally, and save a URL map.
	 *
	 * @return true|WP_Error
	 */
	public static function download_and_cache() {
		$upload     = wp_upload_dir();
		$local_dir  = trailingslashit( $upload['basedir'] ) . self::UPLOAD_SUBDIR;
		$local_url  = trailingslashit( $upload['baseurl'] ) . self::UPLOAD_SUBDIR;

		// Ensure directory exists and is protected.
		if ( ! file_exists( $local_dir ) ) {
			wp_mkdir_p( $local_dir );
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			file_put_contents( $local_dir . '/index.html', '' );
		}

		// Collect Google Fonts URLs from registered styles.
		$google_font_urls = self::collect_google_font_urls();

		if ( empty( $google_font_urls ) ) {
			// No Google Fonts registered — nothing to do.
			update_option( self::OPTION_FONT_MAP, array(), false );
			return true;
		}

		$font_map = array();

		foreach ( $google_font_urls as $remote_css_url ) {
			$result = self::download_font_css( $remote_css_url, $local_dir, $local_url, $font_map );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}

		update_option( self::OPTION_FONT_MAP, $font_map, false );
		return true;
	}

	/**
	 * Collect all Google Fonts stylesheet URLs from the WP styles registry.
	 *
	 * @return string[]
	 */
	private static function collect_google_font_urls(): array {
		global $wp_styles;

		if ( ! $wp_styles instanceof WP_Styles ) {
			return array();
		}

		$urls = array();

		foreach ( $wp_styles->registered as $handle => $style ) {
			if ( isset( $style->src ) && false !== strpos( (string) $style->src, 'fonts.googleapis.com' ) ) {
				$urls[] = $style->src;
			}
		}

		return array_unique( $urls );
	}

	/**
	 * Download a Google Fonts CSS file, replace all src: url() WOFF2 references
	 * with locally downloaded copies, and save the rewritten CSS locally.
	 *
	 * @param  string $remote_css_url  Remote Google Fonts CSS URL.
	 * @param  string $local_dir       Absolute path to local fonts directory.
	 * @param  string $local_url       Public URL to local fonts directory.
	 * @param  array  &$font_map       Map of remote URL → local URL (modified by reference).
	 * @return true|WP_Error
	 */
	private static function download_font_css(
		string $remote_css_url,
		string $local_dir,
		string $local_url,
		array &$font_map
	) {
		// Request CSS with a modern user-agent to get WOFF2 format.
		$response = wp_remote_get(
			$remote_css_url,
			array(
				'timeout'    => self::DOWNLOAD_TIMEOUT,
				'user-agent' => 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$css_body = wp_remote_retrieve_body( $response );

		if ( empty( $css_body ) ) {
			return new WP_Error( 'empty_response', 'Google Fonts CSS response was empty.' );
		}

		// Find all src: url('...') references in the CSS.
		preg_match_all( '/src:\s*url\([\'"]?([^\'")]+\.woff2)[\'"]?\)/i', $css_body, $matches );
		$woff2_urls = array_unique( $matches[1] ?? array() );

		foreach ( $woff2_urls as $woff2_url ) {
			$filename   = self::safe_font_filename( $woff2_url );
			$local_path = $local_dir . '/' . $filename;

			if ( ! file_exists( $local_path ) ) {
				$dl = wp_remote_get( $woff2_url, array( 'timeout' => self::DOWNLOAD_TIMEOUT ) );
				if ( is_wp_error( $dl ) ) {
					continue; // Skip this file; CSS will still reference remote.
				}
				$file_content = wp_remote_retrieve_body( $dl );
				if ( ! empty( $file_content ) ) {
					// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
					file_put_contents( $local_path, $file_content );
				}
			}

			$local_woff2_url = $local_url . '/' . $filename;
			$css_body        = str_replace( $woff2_url, $local_woff2_url, $css_body );
		}

		// Save the rewritten CSS locally.
		$css_filename = self::safe_font_filename( $remote_css_url, 'css' );
		$css_path     = $local_dir . '/' . $css_filename;
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		file_put_contents( $css_path, $css_body );

		$local_css_url = $local_url . '/' . $css_filename;
		$font_map[ $remote_css_url ] = $local_css_url;

		return true;
	}

	/**
	 * Generate a safe filename from a URL.
	 *
	 * @param  string $url        Source URL.
	 * @param  string $extension  Force this extension (optional).
	 * @return string
	 */
	private static function safe_font_filename( string $url, string $extension = '' ): string {
		$hash = substr( md5( $url ), 0, 12 );
		$ext  = $extension ?: pathinfo( wp_parse_url( $url, PHP_URL_PATH ), PATHINFO_EXTENSION );
		$ext  = $ext ?: 'css';
		return 'tf-font-' . $hash . '.' . ltrim( $ext, '.' );
	}
}

// Register the scheduled event callback.
add_action( 'themeflex_download_fonts_event', array( 'ThemeFlex_Font_Local_Host', 'download_and_cache' ) );

// Auto-init.
ThemeFlex_Font_Local_Host::init();
