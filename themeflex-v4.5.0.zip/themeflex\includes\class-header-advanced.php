<?php
/**
 * Advanced Header Features
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ThemeFlex_Header_Advanced {

	/**
	 * Initialize
	 */
	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_scripts' ) );
		add_action( 'customize_register', array( __CLASS__, 'customize_register' ) );
		add_action( 'wp_head', array( __CLASS__, 'output_header_styles' ) );
	}

	/**
	 * Enqueue scripts and styles
	 */
	public static function enqueue_scripts() {
		wp_enqueue_style(
			'sf-header-advanced',
			THEMEFLEX_URL . '/assets/css/header-advanced.css',
			array(),
			THEMEFLEX_VERSION
		);

		wp_enqueue_script(
			'sf-header',
			THEMEFLEX_URL . '/assets/js/header.js',
			array(),
			THEMEFLEX_VERSION,
			true
		);

		wp_localize_script(
			'sf-header',
			'sfHeader',
			array(
				'sticky' => get_theme_mod( 'sticky_header', true ),
				'search_overlay' => get_theme_mod( 'search_overlay', true ),
				'offcanvas' => get_theme_mod( 'offcanvas_menu', true ),
			)
		);
	}

	/**
	 * Customize register
	 */
	public static function customize_register( $wp_customize ) {
		// Header settings section
		$wp_customize->add_section(
			'sf_header_advanced',
			array(
				'title' => esc_html__( 'Advanced Header', 'themeflex' ),
				'panel' => 'themeflex_settings',
			)
		);

		// Sticky header
		$wp_customize->add_setting(
			'sticky_header',
			array(
				'default' => true,
				'sanitize_callback' => 'rest_sanitize_boolean',
				'transport' => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sticky_header',
			array(
				'label' => esc_html__( 'Sticky Header', 'themeflex' ),
				'description' => esc_html__( 'Header stays fixed when scrolling', 'themeflex' ),
				'section' => 'sf_header_advanced',
				'type' => 'checkbox',
			)
		);

		// Sticky header shrink
		$wp_customize->add_setting(
			'sticky_header_shrink',
			array(
				'default' => true,
				'sanitize_callback' => 'rest_sanitize_boolean',
				'transport' => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sticky_header_shrink',
			array(
				'label' => esc_html__( 'Shrink Sticky Header on Scroll', 'themeflex' ),
				'section' => 'sf_header_advanced',
				'type' => 'checkbox',
			)
		);

		// Transparent header
		$wp_customize->add_setting(
			'transparent_header',
			array(
				'default' => false,
				'sanitize_callback' => 'rest_sanitize_boolean',
				'transport' => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'transparent_header',
			array(
				'label' => esc_html__( 'Transparent Header (Default)', 'themeflex' ),
				'description' => esc_html__( 'Can be overridden per page', 'themeflex' ),
				'section' => 'sf_header_advanced',
				'type' => 'checkbox',
			)
		);

		// Search overlay
		$wp_customize->add_setting(
			'search_overlay',
			array(
				'default' => true,
				'sanitize_callback' => 'rest_sanitize_boolean',
				'transport' => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'search_overlay',
			array(
				'label' => esc_html__( 'Full-Screen Search Overlay', 'themeflex' ),
				'section' => 'sf_header_advanced',
				'type' => 'checkbox',
			)
		);

		// Off-canvas menu
		$wp_customize->add_setting(
			'offcanvas_menu',
			array(
				'default' => true,
				'sanitize_callback' => 'rest_sanitize_boolean',
				'transport' => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'offcanvas_menu',
			array(
				'label' => esc_html__( 'Off-Canvas Mobile Menu', 'themeflex' ),
				'section' => 'sf_header_advanced',
				'type' => 'checkbox',
			)
		);

		// Top bar
		$wp_customize->add_setting(
			'show_topbar',
			array(
				'default' => false,
				'sanitize_callback' => 'rest_sanitize_boolean',
				'transport' => 'refresh',
			)
		);

		$wp_customize->add_control(
			'show_topbar',
			array(
				'label' => esc_html__( 'Show Top Bar', 'themeflex' ),
				'description' => esc_html__( 'Display top bar with contact info', 'themeflex' ),
				'section' => 'sf_header_advanced',
				'type' => 'checkbox',
			)
		);

		// Top bar phone
		$wp_customize->add_setting(
			'topbar_phone',
			array(
				'default' => '',
				'sanitize_callback' => 'sanitize_text_field',
				'transport' => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'topbar_phone',
			array(
				'label' => esc_html__( 'Phone Number', 'themeflex' ),
				'section' => 'sf_header_advanced',
				'type' => 'text',
			)
		);

		// Top bar email
		$wp_customize->add_setting(
			'topbar_email',
			array(
				'default' => '',
				'sanitize_callback' => 'sanitize_email',
				'transport' => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'topbar_email',
			array(
				'label' => esc_html__( 'Email Address', 'themeflex' ),
				'section' => 'sf_header_advanced',
				'type' => 'text',
			)
		);

		// NOTE: Header style is now controlled by themeflex_header_layout in customizer.php.
		// The canonical 9-layout selector lives under "Header Options → Header Layout".
		// Registering the old header_style setting (without a control) keeps backwards compat
		// for any saved theme_mod values without showing a duplicate control.
		$wp_customize->add_setting(
			'header_style',
			array(
				'default' => 'standard',
				'sanitize_callback' => 'sanitize_text_field',
				'transport' => 'refresh',
			)
		);
	}

	/**
	 * Output header styles
	 */
	public static function output_header_styles() {
		$transparent = get_theme_mod( 'transparent_header', false ) || get_post_meta( get_the_ID(), '_transparent_header', true );
		$sticky_height = 80; // Default header height
		$sticky_shrink_height = 60; // Shrink height

		?>
		<style>
			<?php if ( $transparent ) : ?>
			.site-header {
				background-color: transparent;
				border-bottom-color: transparent;
			}
			<?php endif; ?>

			.site-header.sticky {
				height: <?php echo intval( $sticky_height ); ?>px;
				box-shadow: 0 2px 20px rgba(0,0,0,0.1);
			}

			.site-header.sticky.shrink {
				height: <?php echo intval( $sticky_shrink_height ); ?>px;
			}

			.site-header.sticky.shrink .site-logo img {
				transform: scale(0.85);
			}
		</style>
		<?php
	}

	/**
	 * Check if header is transparent
	 *
	 * @return bool
	 */
	public static function is_transparent_header() {
		if ( is_singular() ) {
			$transparent = get_post_meta( get_the_ID(), '_transparent_header', true );
			if ( $transparent ) {
				return true;
			}
		}

		return get_theme_mod( 'transparent_header', false );
	}

	/**
	 * Get header classes
	 *
	 * @return array
	 */
	public static function get_header_classes() {
		$classes = array( 'site-header' );

		if ( self::is_transparent_header() ) {
			$classes[] = 'transparent-header';
		}

		if ( get_theme_mod( 'sticky_header', true ) || get_theme_mod( 'themeflex_sticky_header', true ) ) {
			$classes[] = 'sticky-enabled';
		}

		// Canonical key: themeflex_header_layout; fallback to legacy header_style.
		$layout = get_theme_mod( 'themeflex_header_layout', '' );
		if ( ! $layout ) {
			$layout = get_theme_mod( 'header_style', 'standard' );
		}
		$classes[] = 'header-' . sanitize_html_class( $layout );

		return $classes;
	}

	/**
	 * Render top bar
	 */
	public static function render_topbar() {
		if ( ! get_theme_mod( 'show_topbar', false ) ) {
			return;
		}

		$phone = get_theme_mod( 'topbar_phone' );
		$email = get_theme_mod( 'topbar_email' );

		?>
		<div class="sf-topbar">
			<div class="container-fluid">
				<div class="sf-topbar-left">
					<?php if ( $phone ) : ?>
						<a href="tel:<?php echo esc_attr( preg_replace( '/\D/', '', $phone ) ); ?>" class="sf-topbar-item">
							<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
								<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
							</svg>
							<?php echo esc_html( $phone ); ?>
						</a>
					<?php endif; ?>

					<?php if ( $email ) : ?>
						<a href="mailto:<?php echo esc_attr( $email ); ?>" class="sf-topbar-item">
							<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
								<rect x="2" y="4" width="20" height="16" rx="2"/>
								<path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>
							</svg>
							<?php echo esc_html( $email ); ?>
						</a>
					<?php endif; ?>
				</div>

				<div class="sf-topbar-right">
					<?php self::render_topbar_social(); ?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render topbar social icons
	 */
	private static function render_topbar_social() {
		$socials = array(
			'facebook' => get_theme_mod( 'social_facebook' ),
			'twitter' => get_theme_mod( 'social_twitter' ),
			'instagram' => get_theme_mod( 'social_instagram' ),
			'linkedin' => get_theme_mod( 'social_linkedin' ),
		);

		?>
		<div class="sf-topbar-social">
			<?php foreach ( $socials as $social => $url ) : ?>
				<?php if ( ! empty( $url ) ) : ?>
					<a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( ucfirst( $social ) ); ?>" class="sf-social-link">
						<?php echo wp_kses_post( ThemeFlex_Icons::get_icon( $social, 16 ) ); ?>
					</a>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Render search overlay
	 */
	public static function render_search_overlay() {
		if ( ! get_theme_mod( 'search_overlay', true ) ) {
			return;
		}

		?>
		<div class="sf-search-overlay">
			<div class="sf-search-overlay-content">
				<button class="sf-search-overlay-close" aria-label="<?php esc_attr_e( 'Close search', 'themeflex' ); ?>">
					<?php echo wp_kses_post( ThemeFlex_Icons::get_icon( 'close', 32 ) ); ?>
				</button>

				<h2><?php esc_html_e( 'What are you looking for?', 'themeflex' ); ?></h2>

				<form method="get" class="sf-search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
					<input type="search" name="s" placeholder="<?php esc_attr_e( 'Search...', 'themeflex' ); ?>" autocomplete="off">
					<button type="submit" aria-label="<?php esc_attr_e( 'Submit search', 'themeflex' ); ?>">
						<?php echo wp_kses_post( ThemeFlex_Icons::get_icon( 'search', 24 ) ); ?>
					</button>
				</form>

				<div class="sf-search-results"></div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render off-canvas menu
	 */
	public static function render_offcanvas() {
		if ( ! get_theme_mod( 'offcanvas_menu', true ) ) {
			return;
		}

		?>
		<div class="sf-offcanvas-menu">
			<div class="sf-offcanvas-header">
				<button class="sf-offcanvas-close" aria-label="<?php esc_attr_e( 'Close menu', 'themeflex' ); ?>">
					<?php echo wp_kses_post( ThemeFlex_Icons::get_icon( 'close', 24 ) ); ?>
				</button>
			</div>

			<nav class="sf-offcanvas-nav">
				<?php
				wp_nav_menu( array(
					'theme_location' => 'primary',
					'fallback_cb' => 'wp_page_menu',
					'depth' => 2,
				) );
				?>
			</nav>

			<div class="sf-offcanvas-footer">
				<?php if ( class_exists( 'WooCommerce' ) ) : ?>
					<a href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>" class="button">
						<?php esc_html_e( 'Shop', 'themeflex' ); ?>
					</a>
				<?php endif; ?>
			</div>
		</div>

		<div class="sf-offcanvas-overlay"></div>
		<?php
	}
}

// Initialize
ThemeFlex_Header_Advanced::init();
