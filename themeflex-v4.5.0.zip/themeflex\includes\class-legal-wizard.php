<?php
/**
 * Legal Wizard
 *
 * Provides:
 *  1. Admin wizard page for collecting legal info (name, address, VAT, etc.)
 *  2. Shortcodes [themeflex_impressum] and [themeflex_datenschutz] that render
 *     jurisdiction-correct legal pages using template files.
 *  3. Four jurisdiction templates: DE, AT, CH, EN
 *
 * wp_options key: themeflex_legal_data
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ThemeFlex_Legal_Wizard
 */
class ThemeFlex_Legal_Wizard {

	/**
	 * wp_options key for legal data.
	 *
	 * @var string
	 */
	const OPTION_LEGAL = 'themeflex_legal_data';

	/**
	 * Admin page slug.
	 *
	 * @var string
	 */
	const PAGE_SLUG = 'themeflex-legal-wizard';

	/**
	 * Register hooks.
	 */
	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_post_themeflex_save_legal', array( __CLASS__, 'handle_save' ) );
		add_shortcode( 'themeflex_impressum', array( __CLASS__, 'shortcode_impressum' ) );
		add_shortcode( 'themeflex_datenschutz', array( __CLASS__, 'shortcode_datenschutz' ) );
	}

	// -----------------------------------------------------------------------
	// Admin menu
	// -----------------------------------------------------------------------

	/**
	 * Register "Legal Wizard" submenu under ThemeFlex.
	 */
	public static function register_menu(): void {
		add_submenu_page(
			'themeflex',
			__( 'Legal Wizard', 'themeflex' ),
			__( 'Legal Wizard', 'themeflex' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Handle settings form submission.
	 */
	public static function handle_save(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Permission denied.', 'themeflex' ) );
		}

		check_admin_referer( 'themeflex_save_legal' );

		$fields = array(
			'jurisdiction', 'company_name', 'company_form', 'owner_name',
			'street', 'city', 'postcode', 'country', 'phone', 'email',
			'website', 'vat_id', 'register_number', 'register_court',
			'supervisory_authority', 'profession', 'chamber',
			'data_controller_name', 'data_controller_email',
			'hosting_provider', 'analytics_tool', 'ai_provider_name',
		);

		$data = array();
		foreach ( $fields as $field ) {
			$data[ $field ] = sanitize_text_field( wp_unslash( $_POST[ $field ] ?? '' ) );
		}

		update_option( self::OPTION_LEGAL, $data, false );

		wp_safe_redirect(
			add_query_arg( array( 'page' => self::PAGE_SLUG, 'saved' => '1' ), admin_url( 'admin.php' ) )
		);
		exit;
	}

	// -----------------------------------------------------------------------
	// Shortcodes
	// -----------------------------------------------------------------------

	/**
	 * [themeflex_impressum] shortcode.
	 *
	 * @param  array $atts  Shortcode attributes (unused).
	 * @return string       HTML output.
	 */
	public static function shortcode_impressum( array $atts = array() ): string {
		return self::render_legal_template( 'impressum' );
	}

	/**
	 * [themeflex_datenschutz] shortcode.
	 *
	 * @param  array $atts  Shortcode attributes (unused).
	 * @return string       HTML output.
	 */
	public static function shortcode_datenschutz( array $atts = array() ): string {
		return self::render_legal_template( 'datenschutz' );
	}

	/**
	 * Render a legal template with the stored legal data.
	 *
	 * @param  string $type  'impressum' or 'datenschutz'.
	 * @return string        HTML output.
	 */
	private static function render_legal_template( string $type ): string {
		$data         = (array) get_option( self::OPTION_LEGAL, array() );
		$jurisdiction = $data['jurisdiction'] ?? 'de';

		$template_map = array(
			'impressum'   => array(
				'de' => '/inc/legal/de-impressum.php',
				'at' => '/inc/legal/at-impressum.php',
				'ch' => '/inc/legal/ch-impressum.php',
				'en' => '/inc/legal/en-privacy.php',
			),
			'datenschutz' => array(
				'de' => '/inc/legal/de-datenschutz.php',
				'at' => '/inc/legal/de-datenschutz.php', // AT uses DE template with AT jurisdiction note.
				'ch' => '/inc/legal/de-datenschutz.php', // CH uses DE template with CH note.
				'en' => '/inc/legal/en-privacy.php',
			),
		);

		$path = THEMEFLEX_DIR . ( $template_map[ $type ][ $jurisdiction ] ?? $template_map[ $type ]['de'] );

		if ( ! file_exists( $path ) ) {
			return '<p>' . esc_html__( 'Legal template not found. Please check your ThemeFlex installation.', 'themeflex' ) . '</p>';
		}

		// Render template in isolated scope.
		ob_start();
		$legal = $data; // Make $legal available in template.
		include $path;
		return ob_get_clean();
	}

	// -----------------------------------------------------------------------
	// Admin page render
	// -----------------------------------------------------------------------

	/**
	 * Render the Legal Wizard admin page.
	 */
	public static function render_page(): void {
		$saved = isset( $_GET['saved'] ) && '1' === $_GET['saved']; // phpcs:ignore WordPress.Security.NonceVerification
		$data  = (array) get_option( self::OPTION_LEGAL, array() );

		$jurisdictions = array(
			'de' => __( 'Germany (DE) — Impressum + DSGVO', 'themeflex' ),
			'at' => __( 'Austria (AT) — Impressum + DSG', 'themeflex' ),
			'ch' => __( 'Switzerland (CH) — Impressum + DSG', 'themeflex' ),
			'en' => __( 'International (EN) — Privacy Policy', 'themeflex' ),
		);

		$current_jurisdiction = $data['jurisdiction'] ?? 'de';
		?>
		<div class="wrap" id="tf-legal-wrap" style="max-width:820px;">
		<h1><?php esc_html_e( 'ThemeFlex — Legal Wizard', 'themeflex' ); ?></h1>
		<p style="color:#6b7280;margin-bottom:1.5rem;">
			<?php esc_html_e( 'Fill in your company details once. Use [themeflex_impressum] and [themeflex_datenschutz] shortcodes on any page.', 'themeflex' ); ?>
		</p>

		<?php if ( $saved ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Legal data saved.', 'themeflex' ); ?></p></div>
		<?php endif; ?>

		<style>
		#tf-legal-wrap .tf-card { background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:1.5rem 2rem;margin-bottom:1.25rem; }
		#tf-legal-wrap .tf-card h2 { margin-top:0;font-size:1rem;border-bottom:1px solid #f3f4f6;padding-bottom:.6rem;margin-bottom:1rem; }
		#tf-legal-wrap .tf-shortcode-box { background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;padding:.75rem 1rem;font-family:monospace;font-size:.9rem; margin-bottom:.5rem; }
		</style>

		<!-- Shortcode reference -->
		<div class="tf-card">
			<h2><?php esc_html_e( 'Shortcodes', 'themeflex' ); ?></h2>
			<p><?php esc_html_e( 'Add these shortcodes to any page to automatically render your legal texts:', 'themeflex' ); ?></p>
			<div class="tf-shortcode-box">[themeflex_impressum]</div>
			<div class="tf-shortcode-box">[themeflex_datenschutz]</div>
		</div>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="themeflex_save_legal">
			<?php wp_nonce_field( 'themeflex_save_legal' ); ?>

			<!-- Jurisdiction -->
			<div class="tf-card">
				<h2><?php esc_html_e( 'Jurisdiction', 'themeflex' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="tf-jurisdiction"><?php esc_html_e( 'Country / Jurisdiction', 'themeflex' ); ?></label></th>
						<td>
							<select name="jurisdiction" id="tf-jurisdiction">
								<?php foreach ( $jurisdictions as $key => $label ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $current_jurisdiction, $key ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
				</table>
			</div>

			<!-- Company details -->
			<div class="tf-card">
				<h2><?php esc_html_e( 'Company Details', 'themeflex' ); ?></h2>
				<table class="form-table" role="presentation">
					<?php
					$company_fields = array(
						'company_name'   => __( 'Company Name', 'themeflex' ),
						'company_form'   => __( 'Legal Form (e.g. GmbH, UG)', 'themeflex' ),
						'owner_name'     => __( 'Owner / Managing Director', 'themeflex' ),
						'street'         => __( 'Street & House Number', 'themeflex' ),
						'postcode'       => __( 'Postcode', 'themeflex' ),
						'city'           => __( 'City', 'themeflex' ),
						'country'        => __( 'Country', 'themeflex' ),
						'phone'          => __( 'Phone Number', 'themeflex' ),
						'email'          => __( 'E-Mail Address', 'themeflex' ),
						'website'        => __( 'Website URL', 'themeflex' ),
						'vat_id'         => __( 'VAT ID (Umsatzsteuer-ID)', 'themeflex' ),
						'register_number'=> __( 'Commercial Register Number', 'themeflex' ),
						'register_court' => __( 'Register Court (Amtsgericht)', 'themeflex' ),
					);
					foreach ( $company_fields as $field_key => $label ) :
						$val = esc_attr( $data[ $field_key ] ?? '' );
						?>
					<tr>
						<th scope="row"><label for="tf-<?php echo esc_attr( $field_key ); ?>"><?php echo esc_html( $label ); ?></label></th>
						<td><input type="text" name="<?php echo esc_attr( $field_key ); ?>" id="tf-<?php echo esc_attr( $field_key ); ?>" value="<?php echo $val; ?>" class="regular-text"></td>
					</tr>
					<?php endforeach; ?>
				</table>
			</div>

			<!-- Data protection details -->
			<div class="tf-card">
				<h2><?php esc_html_e( 'Data Protection / Privacy', 'themeflex' ); ?></h2>
				<table class="form-table" role="presentation">
					<?php
					$privacy_fields = array(
						'data_controller_name'  => __( 'Data Controller Name', 'themeflex' ),
						'data_controller_email' => __( 'Data Controller E-Mail', 'themeflex' ),
						'hosting_provider'      => __( 'Hosting Provider', 'themeflex' ),
						'analytics_tool'        => __( 'Analytics Tool (e.g. Matomo, none)', 'themeflex' ),
						'ai_provider_name'      => __( 'AI Provider (e.g. Anthropic Claude)', 'themeflex' ),
					);
					foreach ( $privacy_fields as $field_key => $label ) :
						$val = esc_attr( $data[ $field_key ] ?? '' );
						?>
					<tr>
						<th scope="row"><label for="tf-<?php echo esc_attr( $field_key ); ?>"><?php echo esc_html( $label ); ?></label></th>
						<td><input type="text" name="<?php echo esc_attr( $field_key ); ?>" id="tf-<?php echo esc_attr( $field_key ); ?>" value="<?php echo $val; ?>" class="regular-text"></td>
					</tr>
					<?php endforeach; ?>
				</table>
			</div>

			<?php submit_button( __( 'Save Legal Data', 'themeflex' ) ); ?>
		</form>
		</div>
		<?php
	}
}

// Auto-init.
ThemeFlex_Legal_Wizard::init();
