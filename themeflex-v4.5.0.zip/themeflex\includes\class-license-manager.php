<?php
/**
 * ThemeFlex License Manager
 *
 * Handles license verification, activation, and status checks via Supabase Edge Functions.
 * Supports Envato/ThemeForest purchase codes with per-domain activation.
 *
 * @package ThemeFlex
 * @version 2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'ThemeFlex_License_Manager' ) ) :

class ThemeFlex_License_Manager {

	/**
	 * Supabase API base URL
	 *
	 * @var string
	 */
	private $api_url;

	/**
	 * Theme slug / identifier
	 *
	 * @var string
	 */
	private $theme_slug = 'themeflex';

	/**
	 * Cache duration in seconds (24 hours)
	 *
	 * @var int
	 */
	private $cache_duration = DAY_IN_SECONDS;

	/**
	 * Singleton instance
	 *
	 * @var ThemeFlex_License_Manager|null
	 */
	private static $instance = null;

	/**
	 * Get singleton instance
	 *
	 * @return ThemeFlex_License_Manager
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	private function __construct() {
		$this->api_url = defined( 'THEMEFLEX_SUPABASE_URL' )
			? rtrim( THEMEFLEX_SUPABASE_URL, '/' )
			: '';

		// Admin hooks
		add_action( 'admin_menu',    array( $this, 'add_license_menu' ) );
		add_action( 'admin_init',    array( $this, 'register_license_settings' ) );
		add_action( 'admin_notices', array( $this, 'show_license_notice' ) );
		add_action( 'admin_post_themeflex_activate_license',   array( $this, 'handle_activate' ) );
		add_action( 'admin_post_themeflex_deactivate_license', array( $this, 'handle_deactivate' ) );
	}

	// ─── Public API ──────────────────────────────────────────────────────────────

	/**
	 * Check if the site has an active license.
	 *
	 * @return bool
	 */
	public function is_licensed() {
		$status = $this->check_license();
		return ! empty( $status['is_active'] );
	}

	/**
	 * Verify a purchase code (Supabase verify-license edge function).
	 *
	 * @param string $purchase_code Envato purchase code.
	 * @return array
	 */
	public function verify_license( $purchase_code ) {
		$purchase_code = sanitize_text_field( $purchase_code );

		if ( empty( $purchase_code ) ) {
			return array(
				'valid'   => false,
				'message' => __( 'Bitte gib einen gültigen Purchase Code ein.', 'themeflex' ),
			);
		}

		$cache_key = 'tf_license_verify_' . md5( $purchase_code );
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}

		$result = $this->api_request( 'verify-license', array(
			'purchase_code' => $purchase_code,
			'domain'        => $this->get_domain(),
		) );

		set_transient( $cache_key, $result, $this->cache_duration );
		return $result;
	}

	/**
	 * Activate a license for this domain.
	 *
	 * @param string $purchase_code Envato purchase code.
	 * @return array
	 */
	public function activate_license( $purchase_code ) {
		$purchase_code = sanitize_text_field( $purchase_code );

		if ( empty( $purchase_code ) ) {
			return array(
				'activated' => false,
				'message'   => __( 'Bitte gib einen gültigen Purchase Code ein.', 'themeflex' ),
			);
		}

		$result = $this->api_request( 'activate-license', array(
			'purchase_code' => $purchase_code,
			'domain'        => $this->get_domain(),
		) );

		if ( ! empty( $result['activated'] ) ) {
			update_option( $this->option_key(), $purchase_code );
			$this->clear_cache( $purchase_code );
		}

		return $result;
	}

	/**
	 * Deactivate the license for this domain.
	 *
	 * @param string $purchase_code Envato purchase code.
	 * @return array
	 */
	public function deactivate_license( $purchase_code ) {
		$purchase_code = sanitize_text_field( $purchase_code );

		if ( empty( $purchase_code ) ) {
			return array(
				'deactivated' => false,
				'message'     => __( 'Kein Purchase Code gespeichert.', 'themeflex' ),
			);
		}

		$result = $this->api_request( 'deactivate-license', array(
			'purchase_code' => $purchase_code,
			'domain'        => $this->get_domain(),
		) );

		if ( ! empty( $result['deactivated'] ) ) {
			delete_option( $this->option_key() );
			$this->clear_cache( $purchase_code );
		}

		return $result;
	}

	/**
	 * Check license status (cached).
	 *
	 * @param string|null $purchase_code Falls back to stored option.
	 * @return array
	 */
	public function check_license( $purchase_code = null ) {
		if ( null === $purchase_code ) {
			$purchase_code = get_option( $this->option_key(), '' );
		}

		$purchase_code = sanitize_text_field( $purchase_code );

		if ( empty( $purchase_code ) ) {
			return array(
				'valid'      => false,
				'is_active'  => false,
				'message'    => __( 'Keine Lizenz hinterlegt.', 'themeflex' ),
			);
		}

		$cache_key = 'tf_license_check_' . md5( $purchase_code );
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}

		$result = $this->api_request( 'check-license', array(
			'purchase_code' => $purchase_code,
			'domain'        => $this->get_domain(),
		) );

		set_transient( $cache_key, $result, $this->cache_duration );
		return $result;
	}

	// ─── Admin UI ────────────────────────────────────────────────────────────────

	/**
	 * Register admin menu page under Appearance.
	 */
	public function add_license_menu() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		add_theme_page(
			__( 'ThemeFlex Lizenz', 'themeflex' ),
			__( 'Lizenz', 'themeflex' ),
			'manage_options',
			'themeflex-license',
			array( $this, 'render_license_page' )
		);
	}

	/**
	 * Register settings.
	 */
	public function register_license_settings() {
		register_setting(
			'themeflex-license',
			$this->option_key(),
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			)
		);
	}

	/**
	 * Handle activate form POST.
	 */
	public function handle_activate() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'themeflex_activate_license' ) ) {
			wp_die( 'Unauthorized' );
		}

		$code   = isset( $_POST['purchase_code'] ) ? sanitize_text_field( wp_unslash( $_POST['purchase_code'] ) ) : '';
		$result = $this->activate_license( $code );

		$status  = ! empty( $result['activated'] ) ? 'activated' : 'error';
		$message = isset( $result['message'] ) ? $result['message'] : '';

		wp_safe_redirect( add_query_arg(
			array( 'page' => 'themeflex-license', 'tf_status' => $status, 'tf_msg' => urlencode( $message ) ),
			admin_url( 'themes.php' )
		) );
		exit;
	}

	/**
	 * Handle deactivate form POST.
	 */
	public function handle_deactivate() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'themeflex_deactivate_license' ) ) {
			wp_die( 'Unauthorized' );
		}

		$code   = get_option( $this->option_key(), '' );
		$result = $this->deactivate_license( $code );

		$status  = ! empty( $result['deactivated'] ) ? 'deactivated' : 'error';
		$message = isset( $result['message'] ) ? $result['message'] : '';

		wp_safe_redirect( add_query_arg(
			array( 'page' => 'themeflex-license', 'tf_status' => $status, 'tf_msg' => urlencode( $message ) ),
			admin_url( 'themes.php' )
		) );
		exit;
	}

	/**
	 * Render the license admin page.
	 */
	public function render_license_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Unauthorized' );
		}

		$purchase_code = get_option( $this->option_key(), '' );
		$status        = $purchase_code ? $this->check_license( $purchase_code ) : array( 'valid' => false, 'is_active' => false );
		$is_active     = ! empty( $status['is_active'] );
		$tf_msg        = isset( $_GET['tf_msg'] ) ? sanitize_text_field( urldecode( $_GET['tf_msg'] ) ) : '';
		$tf_status     = isset( $_GET['tf_status'] ) ? sanitize_text_field( $_GET['tf_status'] ) : '';

		$no_api = empty( $this->api_url );
		?>
		<div class="wrap" style="max-width: 800px;">

			<h1 style="display:flex;align-items:center;gap:10px;">
				<span style="font-size:28px;">⚡</span>
				<?php esc_html_e( 'ThemeFlex — Lizenz', 'themeflex' ); ?>
			</h1>

			<?php if ( $tf_msg ) : ?>
				<div class="notice notice-<?php echo in_array( $tf_status, array( 'activated', 'deactivated' ), true ) ? 'success' : 'error'; ?> is-dismissible">
					<p><?php echo esc_html( $tf_msg ); ?></p>
				</div>
			<?php endif; ?>

			<?php if ( $no_api ) : ?>
				<div class="notice notice-warning">
					<p>
						<strong><?php esc_html_e( 'Supabase nicht konfiguriert:', 'themeflex' ); ?></strong>
						<?php esc_html_e( 'Definiere THEMEFLEX_SUPABASE_URL in deiner wp-config.php, um die Lizenzverwaltung zu aktivieren.', 'themeflex' ); ?>
					</p>
					<pre style="background:#f0f0f0;padding:10px;border-radius:4px;">define( 'THEMEFLEX_SUPABASE_URL', 'https://YOUR_PROJECT.supabase.co' );</pre>
				</div>
			<?php endif; ?>

			<!-- Status Card -->
			<div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:24px;margin:20px 0;">
				<table class="form-table" style="margin:0;">
					<tr>
						<th style="width:180px;"><?php esc_html_e( 'Domain', 'themeflex' ); ?></th>
						<td><code><?php echo esc_html( $this->get_domain() ); ?></code></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Status', 'themeflex' ); ?></th>
						<td>
							<?php if ( $is_active ) : ?>
								<span style="color:#00a32a;font-weight:600;">✓ <?php esc_html_e( 'Aktiv', 'themeflex' ); ?></span>
								<?php if ( ! empty( $status['license_type'] ) ) : ?>
									&nbsp;·&nbsp;<em><?php echo esc_html( ucfirst( $status['license_type'] ) ); ?> License</em>
								<?php endif; ?>
							<?php elseif ( $purchase_code ) : ?>
								<span style="color:#d63638;font-weight:600;">✗ <?php esc_html_e( 'Inaktiv', 'themeflex' ); ?></span>
								<?php if ( ! empty( $status['message'] ) ) : ?>
									&nbsp;— <?php echo esc_html( $status['message'] ); ?>
								<?php endif; ?>
							<?php else : ?>
								<span style="color:#999;"><?php esc_html_e( 'Keine Lizenz hinterlegt', 'themeflex' ); ?></span>
							<?php endif; ?>
						</td>
					</tr>
					<?php if ( ! empty( $status['support_until'] ) ) : ?>
					<tr>
						<th><?php esc_html_e( 'Support bis', 'themeflex' ); ?></th>
						<td><code><?php echo esc_html( $status['support_until'] ); ?></code></td>
					</tr>
					<?php endif; ?>
				</table>
			</div>

			<!-- Activate Form -->
			<?php if ( ! $is_active ) : ?>
			<div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:24px;margin:20px 0;">
				<h2 style="margin-top:0;"><?php esc_html_e( 'Lizenz aktivieren', 'themeflex' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'themeflex_activate_license' ); ?>
					<input type="hidden" name="action" value="themeflex_activate_license" />
					<table class="form-table" style="margin:0;">
						<tr>
							<th><label for="purchase_code"><?php esc_html_e( 'Purchase Code', 'themeflex' ); ?></label></th>
							<td>
								<input
									type="text"
									id="purchase_code"
									name="purchase_code"
									value="<?php echo esc_attr( $purchase_code ); ?>"
									placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
									class="regular-text"
									style="font-family:monospace;"
								/>
								<p class="description">
									<?php esc_html_e( 'Envato / ThemeForest Purchase Code aus deinen Downloads.', 'themeflex' ); ?>
								</p>
							</td>
						</tr>
					</table>
					<?php submit_button( __( 'Lizenz aktivieren', 'themeflex' ), 'primary', 'submit', true ); ?>
				</form>
			</div>
			<?php else : ?>
			<!-- Deactivate Form -->
			<div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:24px;margin:20px 0;">
				<h2 style="margin-top:0;"><?php esc_html_e( 'Lizenz deaktivieren', 'themeflex' ); ?></h2>
				<p><?php esc_html_e( 'Deaktiviere die Lizenz auf dieser Domain, um sie auf einer anderen Domain zu nutzen.', 'themeflex' ); ?></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'themeflex_deactivate_license' ); ?>
					<input type="hidden" name="action" value="themeflex_deactivate_license" />
					<?php submit_button( __( 'Lizenz deaktivieren', 'themeflex' ), 'secondary', 'submit', true ); ?>
				</form>
			</div>
			<?php endif; ?>

			<!-- How to get your code -->
			<div style="background:#f9f9f9;border:1px solid #ddd;border-radius:8px;padding:24px;margin:20px 0;">
				<h2 style="margin-top:0;"><?php esc_html_e( 'So findest du deinen Purchase Code', 'themeflex' ); ?></h2>
				<ol>
					<li><?php esc_html_e( 'Logge dich bei ThemeForest ein', 'themeflex' ); ?> → <a href="https://themeforest.net/user/account/downloads" target="_blank" rel="noopener">themeforest.net/account/downloads</a></li>
					<li><?php esc_html_e( 'Finde "ThemeFlex" in deinen Downloads', 'themeflex' ); ?></li>
					<li><?php esc_html_e( 'Klicke auf den Pfeil neben dem Themenamen', 'themeflex' ); ?></li>
					<li><?php esc_html_e( 'Kopiere den Purchase Code und füge ihn oben ein', 'themeflex' ); ?></li>
				</ol>
			</div>

		</div>
		<?php
	}

	/**
	 * Show admin notice if license is missing or inactive.
	 */
	public function show_license_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// Don't show on the license page itself
		$screen = get_current_screen();
		if ( $screen && strpos( $screen->id, 'themeflex-license' ) !== false ) {
			return;
		}

		$purchase_code = get_option( $this->option_key(), '' );
		$license_url   = admin_url( 'themes.php?page=themeflex-license' );

		if ( empty( $purchase_code ) ) {
			?>
			<div class="notice notice-warning is-dismissible">
				<p>
					<strong>ThemeFlex:</strong>
					<?php
					printf(
						/* translators: %s: link to license page */
						esc_html__( 'Bitte hinterlege deinen Purchase Code, um alle Pro-Features freizuschalten. %s', 'themeflex' ),
						'<a href="' . esc_url( $license_url ) . '">' . esc_html__( 'Lizenz aktivieren →', 'themeflex' ) . '</a>'
					);
					?>
				</p>
			</div>
			<?php
			return;
		}

		$status = $this->check_license( $purchase_code );

		if ( empty( $status['is_active'] ) ) {
			?>
			<div class="notice notice-error is-dismissible">
				<p>
					<strong>ThemeFlex:</strong>
					<?php echo esc_html( $status['message'] ?? __( 'Lizenz inaktiv.', 'themeflex' ) ); ?>
					<a href="<?php echo esc_url( $license_url ); ?>"><?php esc_html_e( 'Details →', 'themeflex' ); ?></a>
				</p>
			</div>
			<?php
		} elseif ( ! empty( $status['support_until'] ) ) {
			$days = ceil( ( strtotime( $status['support_until'] ) - time() ) / DAY_IN_SECONDS );
			if ( $days > 0 && $days <= 30 ) {
				?>
				<div class="notice notice-warning is-dismissible">
					<p>
						<strong>ThemeFlex:</strong>
						<?php
						printf(
							/* translators: %d: number of days */
							esc_html__( 'Dein Theme-Support läuft in %d Tagen ab.', 'themeflex' ),
							(int) $days
						);
						?>
						<a href="<?php echo esc_url( $license_url ); ?>"><?php esc_html_e( 'Verlängern →', 'themeflex' ); ?></a>
					</p>
				</div>
				<?php
			}
		}
	}

	// ─── Private Helpers ─────────────────────────────────────────────────────────

	/**
	 * Make a POST request to a Supabase Edge Function.
	 *
	 * @param string $function Function name (e.g. 'verify-license').
	 * @param array  $data     Request payload.
	 * @return array
	 */
	private function api_request( $function, $data ) {
		if ( empty( $this->api_url ) ) {
			return array(
				'valid'      => false,
				'is_active'  => false,
				'activated'  => false,
				'deactivated' => false,
				'message'    => __( 'Supabase URL nicht konfiguriert (THEMEFLEX_SUPABASE_URL fehlt).', 'themeflex' ),
			);
		}

		$url  = $this->api_url . '/functions/v1/' . $function;
		$args = array(
			'method'  => 'POST',
			'headers' => array(
				'Content-Type' => 'application/json',
				'apikey'       => defined( 'THEMEFLEX_SUPABASE_ANON_KEY' ) ? THEMEFLEX_SUPABASE_ANON_KEY : '',
			),
			'body'    => wp_json_encode( $data ),
			'timeout' => 10,
		);

		$response = wp_remote_post( $url, $args );

		if ( is_wp_error( $response ) ) {
			return array(
				'valid'     => false,
				'is_active' => false,
				'message'   => $response->get_error_message(),
			);
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $code >= 200 && $code < 300 ) {
			return is_array( $body ) ? $body : array( 'valid' => false, 'message' => 'Invalid API response' );
		}

		return array(
			'valid'     => false,
			'is_active' => false,
			'message'   => isset( $body['error'] ) ? $body['error'] : sprintf( 'API Error %d', $code ),
		);
	}

	/**
	 * Get the clean site domain.
	 *
	 * @return string
	 */
	private function get_domain() {
		$host = wp_parse_url( get_home_url(), PHP_URL_HOST );
		return $host ?: ( isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '' );
	}

	/**
	 * WordPress option key for the purchase code.
	 *
	 * @return string
	 */
	private function option_key() {
		return 'themeflex_purchase_code';
	}

	/**
	 * Clear all transient caches for a purchase code.
	 *
	 * @param string $purchase_code The purchase code.
	 */
	private function clear_cache( $purchase_code ) {
		delete_transient( 'tf_license_verify_' . md5( $purchase_code ) );
		delete_transient( 'tf_license_check_' . md5( $purchase_code ) );
	}
}

endif; // class_exists
