<?php
/**
 * Maintenance Mode / Coming Soon
 *
 * Enables maintenance mode to show coming soon page to non-logged-in users.
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ThemeFlex_Maintenance_Mode {

	/**
	 * Initialize maintenance mode
	 */
	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'check_maintenance_mode' ) );
		add_action( 'customize_register', array( __CLASS__, 'register_customizer_settings' ) );
		add_action( 'admin_bar_menu', array( __CLASS__, 'admin_bar_notice' ), 100 );
	}

	/**
	 * Check if maintenance mode is enabled and display coming soon page
	 */
	public static function check_maintenance_mode() {
		// Skip if user is logged in and has admin capability
		if ( is_user_logged_in() ) {
			$current_user = wp_get_current_user();
			if ( user_can( $current_user, 'manage_options' ) ) {
				return;
			}
		}

		// Check if maintenance mode is enabled
		$maintenance_enabled = get_theme_mod( 'sf_maintenance_mode_enabled', false );

		if ( ! $maintenance_enabled ) {
			return;
		}

		// Set 503 status for search engines
		status_header( 503 );
		header( 'Retry-After: 3600' );

		// Include coming soon template
		get_template_part( 'templates/coming-soon' );
		exit;
	}

	/**
	 * Register customizer settings for maintenance mode
	 */
	public static function register_customizer_settings( $wp_customize ) {
		// Add section
		$wp_customize->add_section(
			'sf_maintenance_mode',
			array(
				'title'       => esc_html__( 'Maintenance Mode', 'themeflex' ),
				'description' => esc_html__( 'Configure coming soon and maintenance mode settings', 'themeflex' ),
				'priority'    => 160,
			)
		);

		// Enable/Disable toggle
		$wp_customize->add_setting(
			'sf_maintenance_mode_enabled',
			array(
				'default'           => false,
				'sanitize_callback' => 'rest_sanitize_boolean',
				'transport'         => 'refresh',
			)
		);

		$wp_customize->add_control(
			'sf_maintenance_mode_enabled',
			array(
				'label'       => esc_html__( 'Enable Maintenance Mode', 'themeflex' ),
				'description' => esc_html__( 'When enabled, non-logged-in users will see the coming soon page. Admin users can still access the site.', 'themeflex' ),
				'section'     => 'sf_maintenance_mode',
				'type'        => 'checkbox',
			)
		);

		// Page Title
		$wp_customize->add_setting(
			'sf_maintenance_title',
			array(
				'default'           => esc_html__( 'Coming Soon', 'themeflex' ),
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_maintenance_title',
			array(
				'label'   => esc_html__( 'Page Title', 'themeflex' ),
				'section' => 'sf_maintenance_mode',
				'type'    => 'text',
			)
		);

		// Description
		$wp_customize->add_setting(
			'sf_maintenance_description',
			array(
				'default'           => esc_html__( 'Something amazing is on the way. We are working hard to bring you an incredible experience.', 'themeflex' ),
				'sanitize_callback' => 'sanitize_textarea_field',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'sf_maintenance_description',
			array(
				'label'       => esc_html__( 'Description', 'themeflex' ),
				'section'     => 'sf_maintenance_mode',
				'type'        => 'textarea',
				'description' => esc_html__( 'Brief description shown on the coming soon page', 'themeflex' ),
			)
		);

		// Countdown date
		$wp_customize->add_setting(
			'sf_maintenance_countdown_date',
			array(
				'default'           => gmdate( 'Y-m-d H:i', time() + 30 * DAY_IN_SECONDS ),
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);

		$wp_customize->add_control(
			'sf_maintenance_countdown_date',
			array(
				'label'       => esc_html__( 'Countdown Date', 'themeflex' ),
				'section'     => 'sf_maintenance_mode',
				'type'        => 'datetime-local',
				'description' => esc_html__( 'The date when the site will launch', 'themeflex' ),
			)
		);

		// Background image
		$wp_customize->add_setting(
			'sf_maintenance_background_image',
			array(
				'default'           => '',
				'sanitize_callback' => 'absint',
				'transport'         => 'refresh',
			)
		);

		$wp_customize->add_control(
			new WP_Customize_Media_Control(
				$wp_customize,
				'sf_maintenance_background_image',
				array(
					'label'   => esc_html__( 'Background Image', 'themeflex' ),
					'section' => 'sf_maintenance_mode',
					'mime_type' => 'image',
				)
			)
		);

		// Background color
		$wp_customize->add_setting(
			'sf_maintenance_background_color',
			array(
				'default'           => '#667eea',
				'sanitize_callback' => 'sanitize_hex_color',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			new WP_Customize_Color_Control(
				$wp_customize,
				'sf_maintenance_background_color',
				array(
					'label'   => esc_html__( 'Background Color', 'themeflex' ),
					'section' => 'sf_maintenance_mode',
				)
			)
		);

		// Contact email
		$wp_customize->add_setting(
			'sf_maintenance_contact_email',
			array(
				'default'           => get_option( 'admin_email' ),
				'sanitize_callback' => 'sanitize_email',
				'transport'         => 'refresh',
			)
		);

		$wp_customize->add_control(
			'sf_maintenance_contact_email',
			array(
				'label'       => esc_html__( 'Contact Email', 'themeflex' ),
				'section'     => 'sf_maintenance_mode',
				'type'        => 'email',
				'description' => esc_html__( 'Email address for contact form submissions', 'themeflex' ),
			)
		);

		// Show social links
		$wp_customize->add_setting(
			'sf_maintenance_show_social',
			array(
				'default'           => true,
				'sanitize_callback' => 'rest_sanitize_boolean',
				'transport'         => 'refresh',
			)
		);

		$wp_customize->add_control(
			'sf_maintenance_show_social',
			array(
				'label'   => esc_html__( 'Show Social Links', 'themeflex' ),
				'section' => 'sf_maintenance_mode',
				'type'    => 'checkbox',
			)
		);

		// Social links
		$social_platforms = array( 'facebook', 'twitter', 'instagram', 'linkedin', 'youtube' );

		foreach ( $social_platforms as $platform ) {
			$wp_customize->add_setting(
				'sf_maintenance_social_' . $platform,
				array(
					'default'           => '',
					'sanitize_callback' => 'esc_url_raw',
					'transport'         => 'refresh',
				)
			);

			$wp_customize->add_control(
				'sf_maintenance_social_' . $platform,
				array(
					'label'       => ucfirst( $platform ) . ' ' . esc_html__( 'URL', 'themeflex' ),
					'section'     => 'sf_maintenance_mode',
					'type'        => 'url',
					'description' => sprintf( esc_html__( 'Your %s profile URL', 'themeflex' ), ucfirst( $platform ) ),
				)
			);
		}
	}

	/**
	 * Add admin bar notice when maintenance mode is enabled
	 */
	public static function admin_bar_notice( $wp_admin_bar ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$maintenance_enabled = get_theme_mod( 'sf_maintenance_mode_enabled', false );

		if ( ! $maintenance_enabled ) {
			return;
		}

		$wp_admin_bar->add_node( array(
			'id'     => 'sf_maintenance_notice',
			'title'  => '<span style="background: #ff9800; color: white; padding: 2px 8px; border-radius: 3px;">' .
					esc_html__( 'Maintenance Mode Active', 'themeflex' ) .
					'</span>',
			'href'   => admin_url( 'customize.php?autofocus[section]=sf_maintenance_mode' ),
			'parent' => 'top-secondary',
		) );
	}
}

// Initialize maintenance mode
add_action( 'wp_loaded', array( 'ThemeFlex_Maintenance_Mode', 'init' ) );
