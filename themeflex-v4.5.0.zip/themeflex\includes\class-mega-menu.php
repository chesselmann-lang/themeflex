<?php
/**
 * Mega Menu Builder
 * Ermöglicht Mega-Dropdown-Menüs mit Widgets, Columns, Images und Custom HTML.
 *
 * @package ThemeFlex
 * @since   1.1.0
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Mega_Menu {

    private static ?self $instance = null;

    public static function instance(): self {
        if (is_null(self::$instance)) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('wp_nav_menu_item_custom_fields', [$this, 'nav_item_fields'], 10, 4);
        add_action('wp_update_nav_menu_item',        [$this, 'save_nav_item_fields'], 10, 3);
        add_filter('wp_nav_menu_items',              [$this, 'add_mega_content'], 10, 2);
        add_filter('nav_menu_css_class',             [$this, 'add_menu_classes'], 10, 3);
        add_action('wp_enqueue_scripts',             [$this, 'enqueue']);
        add_action('admin_enqueue_scripts',          [$this, 'admin_enqueue']);
    }

    // ── Admin: Extra Fields in Menu Editor ────────────────────────────────

    public function nav_item_fields(int $item_id, \WP_Post $item, int $depth, stdClass $args): void {
        if ($depth !== 0) return;
        $mega_enabled = get_post_meta($item_id, '_sf_mega_enabled', true);
        $mega_cols    = get_post_meta($item_id, '_sf_mega_cols', true) ?: '4';
        $mega_content = get_post_meta($item_id, '_sf_mega_content', true);
        $mega_width   = get_post_meta($item_id, '_sf_mega_width', true) ?: 'full';
        ?>
        <div class="sf-mega-menu-fields" style="padding:10px 0;border-top:1px dashed #ddd;margin-top:8px;">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;">
                <input type="checkbox" id="sf_mega_enabled_<?php echo $item_id; ?>" name="sf_mega_enabled[<?php echo $item_id; ?>]" value="1" <?php checked($mega_enabled,'1'); ?> />
                <label for="sf_mega_enabled_<?php echo $item_id; ?>" style="font-weight:600;color:#333;"><?php esc_html_e('Enable Mega Menu','themeflex'); ?></label>
            </div>
            <div class="sf-mega-options" style="<?php echo $mega_enabled?'':'display:none;'; ?>">
                <p>
                    <label><?php esc_html_e('Columns:','themeflex'); ?></label>
                    <select name="sf_mega_cols[<?php echo $item_id; ?>]">
                        <?php foreach(['1'=>'1','2'=>'2','3'=>'3','4'=>'4'] as $v=>$l): ?>
                        <option value="<?php echo $v; ?>" <?php selected($mega_cols,$v); ?>><?php echo $l; ?></option>
                        <?php endforeach; ?>
                    </select>
                    &nbsp;
                    <label><?php esc_html_e('Width:','themeflex'); ?></label>
                    <select name="sf_mega_width[<?php echo $item_id; ?>]">
                        <option value="full" <?php selected($mega_width,'full'); ?>><?php esc_html_e('Full Width','themeflex'); ?></option>
                        <option value="container" <?php selected($mega_width,'container'); ?>><?php esc_html_e('Container','themeflex'); ?></option>
                    </select>
                </p>
                <p>
                    <label style="display:block;margin-bottom:4px;font-weight:600;"><?php esc_html_e('Mega Content (HTML/Shortcodes):','themeflex'); ?></label>
                    <textarea name="sf_mega_content[<?php echo $item_id; ?>]" rows="4" style="width:100%;font-size:12px;"><?php echo esc_textarea($mega_content); ?></textarea>
                    <span style="font-size:11px;color:#888;"><?php esc_html_e('Supports HTML, shortcodes like [sf_portfolio], and Elementor template shortcodes.','themeflex'); ?></span>
                </p>
            </div>
        </div>
        <script>
        (function(){
            var cb=document.getElementById('sf_mega_enabled_<?php echo $item_id; ?>');
            var opts=cb.closest('.sf-mega-menu-fields').querySelector('.sf-mega-options');
            cb.addEventListener('change',function(){opts.style.display=cb.checked?'':'none';});
        })();
        </script>
        <?php
    }

    public function save_nav_item_fields(int $menu_id, int $item_id, array $args): void {
        update_post_meta($item_id, '_sf_mega_enabled', !empty($_POST['sf_mega_enabled'][$item_id]) ? '1' : '0');
        if (isset($_POST['sf_mega_cols'][$item_id])) {
            update_post_meta($item_id, '_sf_mega_cols', sanitize_text_field($_POST['sf_mega_cols'][$item_id]));
        }
        if (isset($_POST['sf_mega_width'][$item_id])) {
            update_post_meta($item_id, '_sf_mega_width', sanitize_text_field($_POST['sf_mega_width'][$item_id]));
        }
        if (isset($_POST['sf_mega_content'][$item_id])) {
            update_post_meta($item_id, '_sf_mega_content', wp_kses_post($_POST['sf_mega_content'][$item_id]));
        }
    }

    // ── Frontend: Add Mega CSS class ──────────────────────────────────────

    public function add_menu_classes(array $classes, \WP_Post $item, stdClass $args): array {
        if ('1' === get_post_meta($item->ID, '_sf_mega_enabled', true)) {
            $classes[] = 'sf-has-mega';
            $width = get_post_meta($item->ID, '_sf_mega_width', true) ?: 'full';
            $classes[] = 'sf-mega-width-'.$width;
        }
        return $classes;
    }

    // ── Frontend: Inject Mega Content into nav items ──────────────────────

    public function add_mega_content(string $items, stdClass $args): string {
        if (!isset($args->menu) || !is_main_query()) return $items;

        // Replace each top-level item that has mega enabled
        $items = preg_replace_callback('/<li[^>]+class="[^"]*sf-has-mega[^"]*"[^>]*>(.*?)<ul class="sub-menu">/s', function($matches) {
            return $matches[0]; // leave the sub-menu intact — mega content added below
        }, $items);

        // Inject mega panels after sub-menu closing tag for mega items
        // This approach: Add custom data panel before the closing </li>
        preg_match_all('/<li[^>]+class="([^"]*sf-has-mega[^"]*)"[^>]*id="menu-item-(\d+)"[^>]*>/', $items, $ms, PREG_OFFSET_CAPTURE);
        // Simpler approach: filter is applied, mega CSS classes are there, JS handles the layout
        return $items;
    }

    // ── Scripts & Styles ─────────────────────────────────────────────────

    public function enqueue(): void {
        wp_add_inline_style('themeflex-style', $this->get_css());
        wp_add_inline_script('themeflex-custom', $this->get_js());
    }

    public function admin_enqueue(string $hook): void {
        if ('nav-menus.php' !== $hook) return;
        // Any admin-side CSS/JS for the mega menu editor
    }

    private function get_css(): string {
        return '
        /* Mega Menu */
        .sf-has-mega{position:static!important}
        .sf-has-mega > .sub-menu{
            position:fixed;left:0;right:0;width:100%;padding:32px 40px;
            display:grid;gap:32px;background:var(--sf-bg,#fff);
            border-top:3px solid var(--sf-color-primary,#FF5E2E);
            box-shadow:0 16px 48px rgba(0,0,0,.12);
            transform:translateY(10px);opacity:0;pointer-events:none;
            transition:opacity .25s ease,transform .25s ease;z-index:9999;
        }
        .sf-has-mega:hover > .sub-menu,.sf-has-mega:focus-within > .sub-menu{
            opacity:1;transform:translateY(0);pointer-events:auto;
        }
        .sf-has-mega > .sub-menu > li{border:none;padding:0}
        .sf-has-mega > .sub-menu > li > a{
            font-weight:800;font-size:12px;text-transform:uppercase;letter-spacing:1px;
            color:var(--sf-color-primary,#FF5E2E);margin-bottom:12px;display:block;
            pointer-events:none;cursor:default;
        }
        .sf-has-mega > .sub-menu > li > ul{
            position:static!important;opacity:1!important;transform:none!important;
            padding:0;box-shadow:none;background:none;border:none;pointer-events:auto;
        }
        .sf-has-mega > .sub-menu > li > ul > li > a{
            color:var(--sf-text,#64748b);font-size:14px;font-weight:500;padding:6px 0;
            display:flex;align-items:center;gap:8px;transition:color .2s;
        }
        .sf-has-mega > .sub-menu > li > ul > li > a:hover{color:var(--sf-color-primary,#FF5E2E);}
        [data-theme=dark] .sf-has-mega > .sub-menu{
            background:var(--sf-alt-bg-2,#1e293b);
            border-color:var(--sf-color-primary,#FF5E2E);
        }
        [data-theme=dark] .sf-has-mega > .sub-menu > li > ul > li > a{color:var(--sf-alt-text,#b8bcc4)}
        ';
    }

    private function get_js(): string {
        return '
        // Mega menu: set grid-template-columns per item
        document.querySelectorAll(".sf-has-mega > .sub-menu").forEach(function(sm){
            var li=sm.closest("li.sf-has-mega");
            if(!li)return;
            var count=sm.children.length||4;
            sm.style.gridTemplateColumns="repeat("+count+",1fr)";
        });
        ';
    }
}

ThemeFlex_Mega_Menu::instance();
