<?php
/**
 * Theme Plugin Installer and Recommender
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ThemeFlex_Plugin_Installer
 *
 * Manages plugin recommendations and installation
 */
class ThemeFlex_Plugin_Installer {

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'wp_ajax_themeflex_install_plugin', array( $this, 'ajax_install_plugin' ) );
		add_action( 'wp_ajax_themeflex_activate_plugin', array( $this, 'ajax_activate_plugin' ) );
		add_action( 'wp_ajax_themeflex_bulk_install_plugins', array( $this, 'ajax_bulk_install_plugins' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
		add_action( 'after_switch_theme', array( $this, 'show_setup_notice' ) );
	}

	/**
	 * Get recommended plugins list
	 *
	 * @since 1.0.0
	 * @return array List of recommended plugins
	 */
	public static function get_recommended_plugins() {
		return array(
			array(
				'slug'    => 'elementor',
				'name'    => 'Elementor – Website Builder',
				'desc'    => 'Drag & drop page builder for WordPress',
				'icon'    => 'https://ps.w.org/elementor/assets/icon-128x128.png',
				'link'    => 'https://wordpress.org/plugins/elementor/',
				'author'  => 'Elementor.com',
				'rating'  => 4.6,
				'reviews' => 15000,
				'required' => true,
			),
			array(
				'slug'    => 'woocommerce',
				'name'    => 'WooCommerce',
				'desc'    => 'Sell anything online with the #1 eCommerce plugin',
				'icon'    => 'https://ps.w.org/woocommerce/assets/icon-128x128.png',
				'link'    => 'https://wordpress.org/plugins/woocommerce/',
				'author'  => 'Automattic',
				'rating'  => 4.5,
				'reviews' => 8000,
				'required' => false,
			),
			array(
				'slug'    => 'contact-form-7',
				'name'    => 'Contact Form 7',
				'desc'    => 'Just another contact form plugin',
				'icon'    => 'https://ps.w.org/contact-form-7/assets/icon-128x128.png',
				'link'    => 'https://wordpress.org/plugins/contact-form-7/',
				'author'  => 'Takayuki Miyoshi',
				'rating'  => 4.2,
				'reviews' => 3000,
				'required' => false,
			),
			array(
				'slug'    => 'mailchimp-for-wordpress',
				'name'    => 'Mailchimp for WordPress',
				'desc'    => 'Powerful, easy to use email marketing',
				'icon'    => 'https://ps.w.org/mailchimp-for-wordpress/assets/icon-128x128.png',
				'link'    => 'https://wordpress.org/plugins/mailchimp-for-wordpress/',
				'author'  => 'MC4WP',
				'rating'  => 4.3,
				'reviews' => 2500,
				'required' => false,
			),
			array(
				'slug'    => 'rank-math',
				'name'    => 'Rank Math SEO',
				'desc'    => 'The easiest and most powerful way to optimize your WordPress website',
				'icon'    => 'https://ps.w.org/seo-by-rank-math/assets/icon-128x128.png',
				'link'    => 'https://wordpress.org/plugins/seo-by-rank-math/',
				'author'  => 'Rank Math',
				'rating'  => 4.7,
				'reviews' => 5000,
				'required' => false,
			),
			array(
				'slug'    => 'wpml-core',
				'name'    => 'WPML',
				'desc'    => 'Run a multilingual website',
				'icon'    => 'https://ps.w.org/sitepress-multilingual-cms/assets/icon-128x128.png',
				'link'    => 'https://wordpress.org/plugins/sitepress-multilingual-cms/',
				'author'  => 'OnTheGoSystems',
				'rating'  => 4.4,
				'reviews' => 1500,
				'required' => false,
			),
			array(
				'slug'    => 'tutor',
				'name'    => 'Tutor LMS',
				'desc'    => 'Create an online course and sell them on your website',
				'icon'    => 'https://ps.w.org/tutor/assets/icon-128x128.png',
				'link'    => 'https://wordpress.org/plugins/tutor/',
				'author'  => 'Themeum',
				'rating'  => 4.5,
				'reviews' => 800,
				'required' => false,
			),
			array(
				'slug'    => 'the-events-calendar',
				'name'    => 'The Events Calendar',
				'desc'    => 'Manage and showcase events on your WordPress website',
				'icon'    => 'https://ps.w.org/the-events-calendar/assets/icon-128x128.png',
				'link'    => 'https://wordpress.org/plugins/the-events-calendar/',
				'author'  => 'The Events Calendar',
				'rating'  => 4.4,
				'reviews' => 3000,
				'required' => false,
			),
			array(
				'slug'    => 'metform',
				'name'    => 'MetForm',
				'desc'    => 'Create powerful forms with Elementor builder',
				'icon'    => 'https://ps.w.org/metform/assets/icon-128x128.png',
				'link'    => 'https://wordpress.org/plugins/metform/',
				'author'  => 'wpmet',
				'rating'  => 4.6,
				'reviews' => 500,
				'required' => false,
			),
		);
	}

	/**
	 * Add admin menu
	 *
	 * @since 1.0.0
	 */
	public function add_admin_menu() {
		add_theme_page(
			esc_html__( 'Install Plugins', 'themeflex' ),
			esc_html__( 'Install Plugins', 'themeflex' ),
			'manage_options',
			'themeflex-plugins',
			array( $this, 'render_admin_page' )
		);
	}

	/**
	 * Render admin page
	 *
	 * @since 1.0.0
	 */
	public function render_admin_page() {
		$plugins = self::get_recommended_plugins();
		$installed = self::get_installed_plugins();
		?>
		<div class="wrap themeflex-plugins-page">
			<h1><?php esc_html_e( 'ThemeFlex - Plugin Installer', 'themeflex' ); ?></h1>

			<p class="description">
				<?php esc_html_e( 'We recommend installing the following plugins to get the most out of your ThemeFlex theme:', 'themeflex' ); ?>
			</p>

			<div class="themeflex-plugins-grid">
				<?php foreach ( $plugins as $plugin ) : ?>
					<?php $status = self::get_plugin_status( $plugin['slug'], $installed ); ?>
					<div class="plugin-card <?php echo esc_attr( $status ); ?>" data-slug="<?php echo esc_attr( $plugin['slug'] ); ?>">
						<div class="plugin-card-top">
							<div class="plugin-icon">
								<img src="<?php echo esc_url( $plugin['icon'] ); ?>" alt="<?php echo esc_attr( $plugin['name'] ); ?>">
								<?php if ( $plugin['required'] ) : ?>
									<span class="required-badge"><?php esc_html_e( 'Required', 'themeflex' ); ?></span>
								<?php endif; ?>
							</div>
							<div class="plugin-info">
								<h3><?php echo esc_html( $plugin['name'] ); ?></h3>
								<p class="plugin-author">
									<?php echo wp_kses_post( sprintf( 'By <strong>%s</strong>', $plugin['author'] ) ); ?>
								</p>
								<p class="plugin-desc"><?php echo esc_html( $plugin['desc'] ); ?></p>
								<div class="plugin-rating">
									<span class="stars">
										<?php echo $this->render_stars( $plugin['rating'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
									</span>
									<span class="rating-count">
										<?php echo esc_html( $plugin['rating'] . ' (' . number_format( $plugin['reviews'] ) . ')' ); ?>
									</span>
								</div>
							</div>
						</div>

						<div class="plugin-action">
							<?php if ( 'active' === $status ) : ?>
								<span class="status-badge active">
									<span class="dashicon dashicons dashicons-yes"></span>
									<?php esc_html_e( 'Active', 'themeflex' ); ?>
								</span>
							<?php elseif ( 'installed' === $status ) : ?>
								<button class="button button-secondary activate-btn" data-slug="<?php echo esc_attr( $plugin['slug'] ); ?>">
									<?php esc_html_e( 'Activate', 'themeflex' ); ?>
								</button>
							<?php else : ?>
								<button class="button button-primary install-btn" data-slug="<?php echo esc_attr( $plugin['slug'] ); ?>">
									<?php esc_html_e( 'Install', 'themeflex' ); ?>
								</button>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>

			<div class="bulk-actions">
				<button class="button button-primary bulk-install-btn">
					<?php esc_html_e( 'Install All Plugins', 'themeflex' ); ?>
				</button>
				<button class="button bulk-activate-btn">
					<?php esc_html_e( 'Activate All Plugins', 'themeflex' ); ?>
				</button>
			</div>
		</div>

		<style>
			.themeflex-plugins-page {
				max-width: 1200px;
			}

			.themeflex-plugins-grid {
				display: grid;
				grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
				gap: 20px;
				margin: 30px 0;
			}

			.plugin-card {
				border: 1px solid #ddd;
				border-radius: 4px;
				background: #fff;
				padding: 20px;
				transition: all 0.3s ease;
				position: relative;
			}

			.plugin-card:hover {
				border-color: #FF5E2E;
				box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
			}

			.plugin-card.active {
				background: #f0f8f5;
			}

			.plugin-icon {
				position: relative;
				margin-bottom: 15px;
			}

			.plugin-icon img {
				width: 64px;
				height: 64px;
				border-radius: 4px;
			}

			.required-badge {
				position: absolute;
				top: 5px;
				right: 5px;
				background: #e74c3c;
				color: #fff;
				font-size: 10px;
				padding: 3px 6px;
				border-radius: 2px;
				font-weight: 600;
			}

			.plugin-info h3 {
				margin: 0 0 10px 0;
				font-size: 16px;
			}

			.plugin-author {
				margin: 0 0 10px 0;
				font-size: 12px;
				color: #999;
			}

			.plugin-desc {
				margin: 0 0 10px 0;
				font-size: 13px;
				color: #666;
				line-height: 1.4;
			}

			.plugin-rating {
				display: flex;
				align-items: center;
				gap: 10px;
				font-size: 12px;
				color: #999;
				margin-bottom: 15px;
			}

			.stars {
				color: #ffc107;
			}

			.plugin-action {
				border-top: 1px solid #eee;
				padding-top: 15px;
			}

			.plugin-action .button {
				width: 100%;
			}

			.status-badge {
				display: block;
				text-align: center;
				padding: 8px;
				background: #2ecc71;
				color: #fff;
				border-radius: 4px;
				font-weight: 600;
			}

			.bulk-actions {
				display: flex;
				gap: 10px;
				margin-top: 30px;
			}

			.bulk-actions .button {
				padding: 10px 20px;
			}
		</style>
		<?php
	}

	/**
	 * Render star rating
	 *
	 * @since 1.0.0
	 * @param float $rating The rating value.
	 * @return string Star HTML
	 */
	public function render_stars( $rating ) {
		$html = '';
		for ( $i = 0; $i < 5; $i++ ) {
			if ( $i < floor( $rating ) ) {
				$html .= '★';
			} else {
				$html .= '☆';
			}
		}
		return $html;
	}

	/**
	 * Get installed plugins
	 *
	 * @since 1.0.0
	 * @return array Installed plugins
	 */
	public static function get_installed_plugins() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		return get_plugins();
	}

	/**
	 * Get plugin status
	 *
	 * @since 1.0.0
	 * @param string $slug Plugin slug.
	 * @param array  $installed List of installed plugins.
	 * @return string Plugin status
	 */
	public static function get_plugin_status( $slug, $installed ) {
		// Check if plugin is active
		if ( is_plugin_active( $slug . '/' . $slug . '.php' ) ) {
			return 'active';
		}

		// Check if plugin is installed
		foreach ( $installed as $file => $plugin ) {
			if ( strpos( $file, $slug ) === 0 ) {
				return 'installed';
			}
		}

		return 'not-installed';
	}

	/**
	 * AJAX Install Plugin
	 *
	 * @since 1.0.0
	 */
	public function ajax_install_plugin() {
		check_ajax_referer( 'themeflex-plugins', 'nonce' );

		if ( ! current_user_can( 'install_plugins' ) ) {
			wp_send_json_error( 'Insufficient permissions' );
		}

		$slug = isset( $_POST['slug'] ) ? sanitize_text_field( $_POST['slug'] ) : '';

		if ( ! $slug ) {
			wp_send_json_error( 'No plugin slug provided' );
		}

		$this->install_plugin( $slug );

		wp_send_json_success( array( 'message' => 'Plugin installed successfully' ) );
	}

	/**
	 * AJAX Activate Plugin
	 *
	 * @since 1.0.0
	 */
	public function ajax_activate_plugin() {
		check_ajax_referer( 'themeflex-plugins', 'nonce' );

		if ( ! current_user_can( 'activate_plugins' ) ) {
			wp_send_json_error( 'Insufficient permissions' );
		}

		$slug = isset( $_POST['slug'] ) ? sanitize_text_field( $_POST['slug'] ) : '';

		if ( ! $slug ) {
			wp_send_json_error( 'No plugin slug provided' );
		}

		activate_plugin( $slug . '/' . $slug . '.php' );

		wp_send_json_success( array( 'message' => 'Plugin activated successfully' ) );
	}

	/**
	 * AJAX Bulk Install Plugins
	 *
	 * @since 1.0.0
	 */
	public function ajax_bulk_install_plugins() {
		check_ajax_referer( 'themeflex-plugins', 'nonce' );

		if ( ! current_user_can( 'install_plugins' ) ) {
			wp_send_json_error( 'Insufficient permissions' );
		}

		$plugins = self::get_recommended_plugins();

		foreach ( $plugins as $plugin ) {
			if ( 'active' !== self::get_plugin_status( $plugin['slug'], self::get_installed_plugins() ) ) {
				$this->install_plugin( $plugin['slug'] );
			}
		}

		wp_send_json_success( array( 'message' => 'All plugins installed successfully' ) );
	}

	/**
	 * Install plugin
	 *
	 * @since 1.0.0
	 * @param string $slug Plugin slug.
	 */
	public function install_plugin( $slug ) {
		// Include plugin installer
		include_once ABSPATH . 'wp-admin/includes/plugin-install.php';
		include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

		$plugin_information = plugins_api(
			'plugin_information',
			array( 'slug' => $slug )
		);

		if ( is_wp_error( $plugin_information ) ) {
			return;
		}

		$upgrader = new Plugin_Upgrader();
		$upgrader->install( $plugin_information->download_link );
	}

	/**
	 * Show theme setup notice
	 *
	 * @since 1.0.0
	 */
	public function show_setup_notice() {
		set_transient( 'themeflex_setup_notice', true, 5 * 60 );
	}

	/**
	 * Enqueue admin scripts
	 *
	 * @since 1.0.0
	 * @param string $hook Admin page hook.
	 */
	public function enqueue_admin_scripts( $hook ) {
		if ( 'appearance_page_themeflex-plugins' !== $hook ) {
			return;
		}

		wp_enqueue_script(
			'themeflex-plugin-installer',
			THEMEFLEX_URL . '/assets/js/plugin-installer.js',
			array( 'jquery' ),
			THEMEFLEX_VERSION,
			true
		);

		wp_localize_script(
			'themeflex-plugin-installer',
			'themeFlexPlugins',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'themeflex-plugins' ),
			)
		);
	}
}

// Initialize plugin installer
new ThemeFlex_Plugin_Installer();
