<?php
/**
 * Plugin Requirements Manager
 *
 * Checks for required and recommended plugins and shows structured
 * admin notices with install/activate links — similar to TGMPA but
 * lightweight (no external library dependency).
 *
 * @package ThemeFlex
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Registers required/recommended plugins and handles admin notices.
 */
class ThemeFlex_Plugin_Requirements {

	private static ?self $instance = null;

	/** Plugin definitions. */
	private array $required     = [];
	private array $recommended  = [];

	public static function instance(): self {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->register_plugins();
		add_action( 'admin_notices',  [ $this, 'show_notices' ] );
		add_action( 'admin_init',     [ $this, 'handle_dismiss' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_styles' ] );
	}

	// ── Plugin Definitions ────────────────────────────────────────────────

	private function register_plugins(): void {

		// ── Required ──────────────────────────────────────────────────────
		$this->required = [
			'elementor/elementor.php' => [
				'name'    => 'Elementor',
				'slug'    => 'elementor',
				'version' => '3.0',
				'desc'    => __( 'Required for page building and all visual editing features.', 'themeflex' ),
			],
			'themeflex-addons/themeflex-addons.php' => [
				'name'    => 'ThemeFlex Addons',
				'slug'    => 'themeflex-addons',
				'version' => '1.0.0',
				'desc'    => __( 'Required for 51+ custom widgets, demo importer, and advanced features.', 'themeflex' ),
				'local'   => true, // Installed manually, not from WP repo
			],
		];

		// ── Recommended ───────────────────────────────────────────────────
		$this->recommended = [
			'woocommerce/woocommerce.php' => [
				'name' => 'WooCommerce',
				'slug' => 'woocommerce',
				'desc' => __( 'Adds full e-commerce functionality including the Shop, Cart, and Checkout pages.', 'themeflex' ),
			],
			'the-events-calendar/the-events-calendar.php' => [
				'name' => 'The Events Calendar',
				'slug' => 'the-events-calendar',
				'desc' => __( 'Adds event management and calendar display features.', 'themeflex' ),
			],
			'tutor/tutor.php' => [
				'name' => 'Tutor LMS',
				'slug' => 'tutor',
				'desc' => __( 'Adds LMS / eLearning course functionality.', 'themeflex' ),
			],
			'give/give.php' => [
				'name' => 'GiveWP',
				'slug' => 'give',
				'desc' => __( 'Adds donation and fundraising features.', 'themeflex' ),
			],
		];
	}

	// ── Notice Rendering ──────────────────────────────────────────────────

	public function show_notices(): void {
		if ( ! current_user_can( 'install_plugins' ) ) return;
		if ( get_user_meta( get_current_user_id(), 'sf_plugins_notice_dismissed', true ) ) return;

		$missing_required    = $this->get_missing( $this->required );
		$inactive_required   = $this->get_inactive( $this->required );
		$missing_recommended = $this->get_missing( $this->recommended );

		if ( empty( $missing_required ) && empty( $inactive_required ) && empty( $missing_recommended ) ) {
			return;
		}

		$dismiss_url = wp_nonce_url(
			add_query_arg( 'sf_dismiss_plugins_notice', '1' ),
			'sf_dismiss_plugins_notice'
		);
		?>
		<div class="notice sf-plugins-notice" style="border-left:4px solid #FF5E2E;padding:16px 20px;background:#fff;">
			<div style="display:flex;align-items:flex-start;justify-content:space-between;gap:16px;">
				<div>
					<h3 style="margin:0 0 12px;font-size:14px;font-weight:700;color:#1e293b;">
						<?php esc_html_e( 'ThemeFlex — Plugin Setup', 'themeflex' ); ?>
					</h3>

					<?php if ( ! empty( $missing_required ) || ! empty( $inactive_required ) ) : ?>
					<p style="margin:0 0 8px;font-weight:600;color:#dc2626;">
						<?php esc_html_e( 'Required plugins:', 'themeflex' ); ?>
					</p>
					<ul style="margin:0 0 12px;padding-left:20px;">
						<?php foreach ( array_merge( $missing_required, $inactive_required ) as $plugin ) :
							$action = isset( $missing_required[ $plugin['slug'] ] ) ? 'install' : 'activate';
							$url    = $this->get_plugin_action_url( $plugin['slug'], $action, $plugin['local'] ?? false );
						?>
						<li style="margin-bottom:6px;">
							<strong><?php echo esc_html( $plugin['name'] ); ?></strong>
							— <?php echo esc_html( $plugin['desc'] ); ?>
							<?php if ( ! ( $plugin['local'] ?? false ) && $url ) : ?>
							&nbsp;<a href="<?php echo esc_url( $url ); ?>" class="button button-primary button-small">
								<?php echo 'install' === $action ? esc_html__( 'Install', 'themeflex' ) : esc_html__( 'Activate', 'themeflex' ); ?>
							</a>
							<?php elseif ( $plugin['local'] ?? false ) : ?>
							&nbsp;<span style="color:#6b7280;font-size:12px;"><?php esc_html_e( '(Upload plugin manually)', 'themeflex' ); ?></span>
							<?php endif; ?>
						</li>
						<?php endforeach; ?>
					</ul>
					<?php endif; ?>

					<?php if ( ! empty( $missing_recommended ) ) : ?>
					<p style="margin:0 0 8px;font-weight:600;color:#64748b;">
						<?php esc_html_e( 'Recommended plugins:', 'themeflex' ); ?>
					</p>
					<ul style="margin:0;padding-left:20px;color:#64748b;">
						<?php foreach ( $missing_recommended as $plugin ) :
							$url = $this->get_plugin_action_url( $plugin['slug'], 'install', false );
						?>
						<li style="margin-bottom:4px;font-size:13px;">
							<strong><?php echo esc_html( $plugin['name'] ); ?></strong>
							— <?php echo esc_html( $plugin['desc'] ); ?>
							<?php if ( $url ) : ?>
							&nbsp;<a href="<?php echo esc_url( $url ); ?>" class="button button-small">
								<?php esc_html_e( 'Install', 'themeflex' ); ?>
							</a>
							<?php endif; ?>
						</li>
						<?php endforeach; ?>
					</ul>
					<?php endif; ?>
				</div>
				<a href="<?php echo esc_url( $dismiss_url ); ?>" style="white-space:nowrap;color:#94a3b8;font-size:20px;text-decoration:none;line-height:1;" title="<?php esc_attr_e( 'Dismiss', 'themeflex' ); ?>">&times;</a>
			</div>
		</div>
		<?php
	}

	public function handle_dismiss(): void {
		if (
			isset( $_GET['sf_dismiss_plugins_notice'] ) &&
			wp_verify_nonce( $_GET['_wpnonce'] ?? '', 'sf_dismiss_plugins_notice' ) &&
			current_user_can( 'install_plugins' )
		) {
			update_user_meta( get_current_user_id(), 'sf_plugins_notice_dismissed', true );
			wp_safe_redirect( remove_query_arg( [ 'sf_dismiss_plugins_notice', '_wpnonce' ] ) );
			exit;
		}
	}

	public function enqueue_styles(): void {
		// Inline — no extra HTTP request
	}

	// ── Helpers ───────────────────────────────────────────────────────────

	private function get_missing( array $plugins ): array {
		$missing = [];
		foreach ( $plugins as $file => $plugin ) {
			if ( ! file_exists( WP_PLUGIN_DIR . '/' . $file ) ) {
				$missing[ $plugin['slug'] ] = $plugin;
			}
		}
		return $missing;
	}

	private function get_inactive( array $plugins ): array {
		$inactive = [];
		foreach ( $plugins as $file => $plugin ) {
			if ( file_exists( WP_PLUGIN_DIR . '/' . $file ) && ! is_plugin_active( $file ) ) {
				$inactive[ $plugin['slug'] ] = $plugin;
			}
		}
		return $inactive;
	}

	private function get_plugin_action_url( string $slug, string $action, bool $local = false ): string {
		if ( $local ) return '';
		if ( 'install' === $action ) {
			return wp_nonce_url(
				admin_url( 'update.php?action=install-plugin&plugin=' . $slug ),
				'install-plugin_' . $slug
			);
		}
		// activate
		$plugin_file = $slug . '/' . $slug . '.php';
		return wp_nonce_url(
			admin_url( 'plugins.php?action=activate&plugin=' . urlencode( $plugin_file ) ),
			'activate-plugin_' . $plugin_file
		);
	}
}

// Init
ThemeFlex_Plugin_Requirements::instance();
