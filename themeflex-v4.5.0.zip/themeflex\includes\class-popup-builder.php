<?php
/**
 * Popup Builder
 *
 * A premium popup/modal system with advanced triggers, display rules, and animations.
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ThemeFlex_Popup_Builder {

	/**
	 * Initialize the popup builder
	 *
	 * @since 1.0.0
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_post_type' ) );
		add_action( 'admin_menu', array( __CLASS__, 'register_admin_menu' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_boxes' ) );
		add_action( 'save_post_sf_popup', array( __CLASS__, 'save_popup_meta' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_assets' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_frontend_assets' ) );
		add_action( 'wp_footer', array( __CLASS__, 'render_popups_on_page' ) );
		add_action( 'wp_ajax_sf_popup_inline', array( __CLASS__, 'ajax_popup_inline' ) );
		add_action( 'wp_ajax_nopriv_sf_popup_inline', array( __CLASS__, 'ajax_popup_inline' ) );
		add_filter( 'manage_sf_popup_posts_columns', array( __CLASS__, 'popup_custom_columns' ) );
		add_action( 'manage_sf_popup_posts_custom_column', array( __CLASS__, 'popup_column_content' ), 10, 2 );
		add_filter( 'display_post_states', array( __CLASS__, 'add_post_states' ), 10, 2 );
	}

	/**
	 * Register custom post type for popups
	 *
	 * @since 1.0.0
	 */
	public static function register_post_type() {
		$args = array(
			'labels'              => array(
				'name'          => esc_html__( 'Popups', 'themeflex' ),
				'singular_name' => esc_html__( 'Popup', 'themeflex' ),
				'add_new'       => esc_html__( 'Add New', 'themeflex' ),
				'add_new_item'  => esc_html__( 'Add New Popup', 'themeflex' ),
				'edit_item'     => esc_html__( 'Edit Popup', 'themeflex' ),
				'view_item'     => esc_html__( 'View Popup', 'themeflex' ),
			),
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => false,
			'show_in_nav_menus'   => false,
			'has_archive'         => false,
			'supports'            => array( 'title', 'editor', 'custom-fields' ),
			'can_export'          => true,
			'publicly_queryable'  => false,
			'capability_type'     => 'post',
		);

		register_post_type( 'sf_popup', $args );
	}

	/**
	 * Register admin menu
	 *
	 * @since 1.0.0
	 */
	public static function register_admin_menu() {
		add_menu_page(
			esc_html__( 'Popups', 'themeflex' ),
			esc_html__( 'Popups', 'themeflex' ),
			'manage_options',
			'edit.php?post_type=sf_popup',
			'',
			'dashicons-image-flip',
			30
		);
	}

	/**
	 * Add meta boxes for popup settings
	 *
	 * @since 1.0.0
	 */
	public static function add_meta_boxes() {
		add_meta_box(
			'sf_popup_settings',
			esc_html__( 'Popup Settings', 'themeflex' ),
			array( __CLASS__, 'render_settings_meta_box' ),
			'sf_popup',
			'normal',
			'high'
		);

		add_meta_box(
			'sf_popup_display_rules',
			esc_html__( 'Display Rules', 'themeflex' ),
			array( __CLASS__, 'render_display_rules_meta_box' ),
			'sf_popup',
			'normal',
			'high'
		);

		add_meta_box(
			'sf_popup_advanced',
			esc_html__( 'Advanced Settings', 'themeflex' ),
			array( __CLASS__, 'render_advanced_meta_box' ),
			'sf_popup',
			'normal',
			'high'
		);
	}

	/**
	 * Render settings meta box
	 *
	 * @since 1.0.0
	 */
	public static function render_settings_meta_box( $post ) {
		wp_nonce_field( 'sf_popup_nonce', 'sf_popup_nonce' );

		$popup_enabled = get_post_meta( $post->ID, '_popup_enabled', true );
		$trigger_type = get_post_meta( $post->ID, '_trigger_type', true );
		$scroll_depth = get_post_meta( $post->ID, '_scroll_depth', true );
		$time_delay = get_post_meta( $post->ID, '_time_delay', true );
		$click_selector = get_post_meta( $post->ID, '_click_selector', true );
		$animation = get_post_meta( $post->ID, '_animation', true );
		$position = get_post_meta( $post->ID, '_position', true );
		$layout = get_post_meta( $post->ID, '_layout', true );
		$popup_width = get_post_meta( $post->ID, '_popup_width', true );

		$trigger_types = array(
			'on_load' => esc_html__( 'On Page Load', 'themeflex' ),
			'exit_intent' => esc_html__( 'Exit Intent', 'themeflex' ),
			'scroll_depth' => esc_html__( 'Scroll Depth (%)', 'themeflex' ),
			'time_delay' => esc_html__( 'Time Delay (seconds)', 'themeflex' ),
			'click' => esc_html__( 'Click Element', 'themeflex' ),
			'manual' => esc_html__( 'Manual (JS API)', 'themeflex' ),
		);

		$animations = array(
			'fade' => esc_html__( 'Fade', 'themeflex' ),
			'slide_up' => esc_html__( 'Slide Up', 'themeflex' ),
			'slide_down' => esc_html__( 'Slide Down', 'themeflex' ),
			'slide_left' => esc_html__( 'Slide Left', 'themeflex' ),
			'slide_right' => esc_html__( 'Slide Right', 'themeflex' ),
			'zoom' => esc_html__( 'Zoom', 'themeflex' ),
			'flip' => esc_html__( 'Flip', 'themeflex' ),
		);

		$positions = array(
			'center' => esc_html__( 'Center', 'themeflex' ),
			'top' => esc_html__( 'Top', 'themeflex' ),
			'bottom' => esc_html__( 'Bottom', 'themeflex' ),
			'left' => esc_html__( 'Left', 'themeflex' ),
			'right' => esc_html__( 'Right', 'themeflex' ),
			'top_left' => esc_html__( 'Top Left', 'themeflex' ),
			'top_right' => esc_html__( 'Top Right', 'themeflex' ),
			'bottom_left' => esc_html__( 'Bottom Left', 'themeflex' ),
			'bottom_right' => esc_html__( 'Bottom Right', 'themeflex' ),
			'fullscreen' => esc_html__( 'Fullscreen', 'themeflex' ),
		);

		$layouts = array(
			'modal' => esc_html__( 'Modal with Overlay', 'themeflex' ),
			'slide_panel' => esc_html__( 'Slide-in Panel', 'themeflex' ),
			'notification' => esc_html__( 'Notification Bar', 'themeflex' ),
			'floating_box' => esc_html__( 'Floating Box', 'themeflex' ),
		);

		$widths = array(
			'small' => esc_html__( 'Small (400px)', 'themeflex' ),
			'medium' => esc_html__( 'Medium (600px)', 'themeflex' ),
			'large' => esc_html__( 'Large (800px)', 'themeflex' ),
			'fullscreen' => esc_html__( 'Fullscreen', 'themeflex' ),
			'custom' => esc_html__( 'Custom', 'themeflex' ),
		);

		?>
		<div class="sf-popup-settings">
			<table class="form-table">
				<tr>
					<th scope="row">
						<label for="popup_enabled"><?php esc_html_e( 'Enable Popup', 'themeflex' ); ?></label>
					</th>
					<td>
						<input type="checkbox" id="popup_enabled" name="popup_enabled" value="1" <?php checked( $popup_enabled, 1 ); ?> />
						<p class="description"><?php esc_html_e( 'Enable or disable this popup', 'themeflex' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="trigger_type"><?php esc_html_e( 'Trigger Type', 'themeflex' ); ?></label>
					</th>
					<td>
						<select id="trigger_type" name="trigger_type">
							<?php foreach ( $trigger_types as $key => $label ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $trigger_type, $key ); ?>>
									<?php echo esc_html( $label ); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
				<tr class="sf-trigger-condition" data-trigger="scroll_depth">
					<th scope="row">
						<label for="scroll_depth"><?php esc_html_e( 'Scroll Depth (%)', 'themeflex' ); ?></label>
					</th>
					<td>
						<input type="number" id="scroll_depth" name="scroll_depth" value="<?php echo esc_attr( $scroll_depth ); ?>" min="1" max="100" style="width: 100px;" />
						<p class="description"><?php esc_html_e( 'Show popup when user scrolls this percentage down the page', 'themeflex' ); ?></p>
					</td>
				</tr>
				<tr class="sf-trigger-condition" data-trigger="time_delay">
					<th scope="row">
						<label for="time_delay"><?php esc_html_e( 'Time Delay (seconds)', 'themeflex' ); ?></label>
					</th>
					<td>
						<input type="number" id="time_delay" name="time_delay" value="<?php echo esc_attr( $time_delay ); ?>" min="0" step="0.1" style="width: 100px;" />
						<p class="description"><?php esc_html_e( 'Show popup after this many seconds on page load', 'themeflex' ); ?></p>
					</td>
				</tr>
				<tr class="sf-trigger-condition" data-trigger="click">
					<th scope="row">
						<label for="click_selector"><?php esc_html_e( 'Click Selector', 'themeflex' ); ?></label>
					</th>
					<td>
						<input type="text" id="click_selector" name="click_selector" value="<?php echo esc_attr( $click_selector ); ?>" placeholder=".button, #trigger-id" style="width: 100%;" />
						<p class="description"><?php esc_html_e( 'CSS selector for elements that trigger the popup', 'themeflex' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="animation"><?php esc_html_e( 'Animation', 'themeflex' ); ?></label>
					</th>
					<td>
						<select id="animation" name="animation">
							<?php foreach ( $animations as $key => $label ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $animation, $key ); ?>>
									<?php echo esc_html( $label ); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="position"><?php esc_html_e( 'Position', 'themeflex' ); ?></label>
					</th>
					<td>
						<select id="position" name="position">
							<?php foreach ( $positions as $key => $label ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $position, $key ); ?>>
									<?php echo esc_html( $label ); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="layout"><?php esc_html_e( 'Layout Type', 'themeflex' ); ?></label>
					</th>
					<td>
						<select id="layout" name="layout">
							<?php foreach ( $layouts as $key => $label ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $layout, $key ); ?>>
									<?php echo esc_html( $label ); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="popup_width"><?php esc_html_e( 'Width', 'themeflex' ); ?></label>
					</th>
					<td>
						<select id="popup_width" name="popup_width">
							<?php foreach ( $widths as $key => $label ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $popup_width, $key ); ?>>
									<?php echo esc_html( $label ); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
				<tr class="sf-trigger-condition" data-trigger="custom">
					<th scope="row">
						<label for="custom_width"><?php esc_html_e( 'Custom Width (px)', 'themeflex' ); ?></label>
					</th>
					<td>
						<input type="number" id="custom_width" name="custom_width" value="<?php echo esc_attr( get_post_meta( $post->ID, '_custom_width', true ) ); ?>" min="100" style="width: 100px;" />
					</td>
				</tr>
			</table>
		</div>
		<?php
	}

	/**
	 * Render display rules meta box
	 *
	 * @since 1.0.0
	 */
	public static function render_display_rules_meta_box( $post ) {
		$display_rule = get_post_meta( $post->ID, '_display_rule', true );
		$frequency = get_post_meta( $post->ID, '_frequency', true );
		$specific_pages = get_post_meta( $post->ID, '_specific_pages', true );
		$specific_categories = get_post_meta( $post->ID, '_specific_categories', true );
		$woo_pages = get_post_meta( $post->ID, '_woo_pages', true );
		$show_404 = get_post_meta( $post->ID, '_show_404', true );

		$display_rules = array(
			'all_pages' => esc_html__( 'All Pages', 'themeflex' ),
			'specific_pages' => esc_html__( 'Specific Pages/Posts', 'themeflex' ),
			'specific_categories' => esc_html__( 'Specific Categories', 'themeflex' ),
			'woo_pages' => esc_html__( 'WooCommerce Pages', 'themeflex' ),
		);

		$frequencies = array(
			'every_visit' => esc_html__( 'Every Visit', 'themeflex' ),
			'once_per_session' => esc_html__( 'Once Per Session', 'themeflex' ),
			'once_per_day' => esc_html__( 'Once Per Day', 'themeflex' ),
			'once_ever' => esc_html__( 'Once Ever', 'themeflex' ),
		);

		$woo_page_options = array(
			'shop' => esc_html__( 'Shop Page', 'themeflex' ),
			'product' => esc_html__( 'Product Pages', 'themeflex' ),
			'cart' => esc_html__( 'Cart Page', 'themeflex' ),
			'checkout' => esc_html__( 'Checkout Page', 'themeflex' ),
			'account' => esc_html__( 'Account Page', 'themeflex' ),
		);

		$posts = get_posts( array(
			'posts_per_page' => -1,
			'post_type' => array( 'page', 'post' ),
			'orderby' => 'title',
			'order' => 'ASC',
		) );

		$categories = get_categories( array(
			'hide_empty' => false,
		) );

		?>
		<div class="sf-popup-display-rules">
			<table class="form-table">
				<tr>
					<th scope="row">
						<label for="display_rule"><?php esc_html_e( 'Show on', 'themeflex' ); ?></label>
					</th>
					<td>
						<select id="display_rule" name="display_rule">
							<?php foreach ( $display_rules as $key => $label ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $display_rule, $key ); ?>>
									<?php echo esc_html( $label ); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
				<tr class="sf-display-condition" data-display="specific_pages" style="<?php echo 'specific_pages' === $display_rule ? '' : 'display: none;'; ?>">
					<th scope="row">
						<label for="specific_pages"><?php esc_html_e( 'Pages/Posts', 'themeflex' ); ?></label>
					</th>
					<td>
						<select id="specific_pages" name="specific_pages[]" multiple="multiple" style="min-height: 150px;">
							<?php foreach ( $posts as $page ) : ?>
								<option value="<?php echo esc_attr( $page->ID ); ?>" <?php echo in_array( $page->ID, (array) $specific_pages, true ) ? 'selected' : ''; ?>>
									<?php echo esc_html( $page->post_title ); ?>
								</option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'Hold Ctrl/Cmd to select multiple', 'themeflex' ); ?></p>
					</td>
				</tr>
				<tr class="sf-display-condition" data-display="specific_categories" style="<?php echo 'specific_categories' === $display_rule ? '' : 'display: none;'; ?>">
					<th scope="row">
						<label for="specific_categories"><?php esc_html_e( 'Categories', 'themeflex' ); ?></label>
					</th>
					<td>
						<select id="specific_categories" name="specific_categories[]" multiple="multiple" style="min-height: 150px;">
							<?php foreach ( $categories as $cat ) : ?>
								<option value="<?php echo esc_attr( $cat->term_id ); ?>" <?php echo in_array( $cat->term_id, (array) $specific_categories, true ) ? 'selected' : ''; ?>>
									<?php echo esc_html( $cat->name ); ?>
								</option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'Hold Ctrl/Cmd to select multiple', 'themeflex' ); ?></p>
					</td>
				</tr>
				<tr class="sf-display-condition" data-display="woo_pages" style="<?php echo 'woo_pages' === $display_rule ? '' : 'display: none;'; ?>">
					<th scope="row">
						<label><?php esc_html_e( 'WooCommerce Pages', 'themeflex' ); ?></label>
					</th>
					<td>
						<?php foreach ( $woo_page_options as $key => $label ) : ?>
							<label>
								<input type="checkbox" name="woo_pages[]" value="<?php echo esc_attr( $key ); ?>" <?php echo in_array( $key, (array) $woo_pages, true ) ? 'checked' : ''; ?> />
								<?php echo esc_html( $label ); ?>
							</label><br />
						<?php endforeach; ?>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="show_404"><?php esc_html_e( 'Show on 404 Page', 'themeflex' ); ?></label>
					</th>
					<td>
						<input type="checkbox" id="show_404" name="show_404" value="1" <?php checked( $show_404, 1 ); ?> />
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="frequency"><?php esc_html_e( 'Display Frequency', 'themeflex' ); ?></label>
					</th>
					<td>
						<select id="frequency" name="frequency">
							<?php foreach ( $frequencies as $key => $label ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $frequency, $key ); ?>>
									<?php echo esc_html( $label ); ?>
								</option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'How often the popup should appear to users', 'themeflex' ); ?></p>
					</td>
				</tr>
			</table>
		</div>
		<?php
	}

	/**
	 * Render advanced settings meta box
	 *
	 * @since 1.0.0
	 */
	public static function render_advanced_meta_box( $post ) {
		$overlay_color = get_post_meta( $post->ID, '_overlay_color', true );
		$overlay_opacity = get_post_meta( $post->ID, '_overlay_opacity', true );
		$overlay_blur = get_post_meta( $post->ID, '_overlay_blur', true );
		$close_on_overlay = get_post_meta( $post->ID, '_close_on_overlay', true );
		$close_btn_position = get_post_meta( $post->ID, '_close_btn_position', true );
		$close_btn_delay = get_post_meta( $post->ID, '_close_btn_delay', true );
		$hide_on_mobile = get_post_meta( $post->ID, '_hide_on_mobile', true );
		$priority = get_post_meta( $post->ID, '_priority', true );

		if ( ! $overlay_opacity ) {
			$overlay_opacity = 0.5;
		}
		if ( ! $overlay_blur ) {
			$overlay_blur = 0;
		}

		?>
		<div class="sf-popup-advanced">
			<table class="form-table">
				<tr>
					<th scope="row">
						<label for="overlay_color"><?php esc_html_e( 'Overlay Color', 'themeflex' ); ?></label>
					</th>
					<td>
						<input type="color" id="overlay_color" name="overlay_color" value="<?php echo esc_attr( $overlay_color ?: '#000000' ); ?>" />
						<p class="description"><?php esc_html_e( 'Color of the background overlay', 'themeflex' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="overlay_opacity"><?php esc_html_e( 'Overlay Opacity', 'themeflex' ); ?></label>
					</th>
					<td>
						<input type="range" id="overlay_opacity" name="overlay_opacity" value="<?php echo esc_attr( $overlay_opacity ); ?>" min="0" max="1" step="0.1" />
						<span id="opacity-value"><?php echo esc_html( number_format( $overlay_opacity, 1 ) ); ?></span>
						<p class="description"><?php esc_html_e( 'Opacity from 0 (transparent) to 1 (opaque)', 'themeflex' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="overlay_blur"><?php esc_html_e( 'Overlay Blur (px)', 'themeflex' ); ?></label>
					</th>
					<td>
						<input type="number" id="overlay_blur" name="overlay_blur" value="<?php echo esc_attr( $overlay_blur ); ?>" min="0" max="20" />
						<p class="description"><?php esc_html_e( 'Apply blur effect to background', 'themeflex' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="close_on_overlay"><?php esc_html_e( 'Close on Overlay Click', 'themeflex' ); ?></label>
					</th>
					<td>
						<input type="checkbox" id="close_on_overlay" name="close_on_overlay" value="1" <?php checked( $close_on_overlay, 1 ); ?> />
						<p class="description"><?php esc_html_e( 'Allow users to close popup by clicking overlay', 'themeflex' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="close_btn_position"><?php esc_html_e( 'Close Button Position', 'themeflex' ); ?></label>
					</th>
					<td>
						<select id="close_btn_position" name="close_btn_position">
							<option value="inside" <?php selected( $close_btn_position, 'inside' ); ?>><?php esc_html_e( 'Inside Popup', 'themeflex' ); ?></option>
							<option value="outside" <?php selected( $close_btn_position, 'outside' ); ?>><?php esc_html_e( 'Outside Popup', 'themeflex' ); ?></option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="close_btn_delay"><?php esc_html_e( 'Close Button Delay (seconds)', 'themeflex' ); ?></label>
					</th>
					<td>
						<input type="number" id="close_btn_delay" name="close_btn_delay" value="<?php echo esc_attr( $close_btn_delay ); ?>" min="0" step="0.1" style="width: 100px;" />
						<p class="description"><?php esc_html_e( 'Delay before close button appears (0 = show immediately)', 'themeflex' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="hide_on_mobile"><?php esc_html_e( 'Hide on Mobile', 'themeflex' ); ?></label>
					</th>
					<td>
						<input type="checkbox" id="hide_on_mobile" name="hide_on_mobile" value="1" <?php checked( $hide_on_mobile, 1 ); ?> />
						<p class="description"><?php esc_html_e( 'Do not show popup on mobile devices (screen width < 768px)', 'themeflex' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="priority"><?php esc_html_e( 'Priority', 'themeflex' ); ?></label>
					</th>
					<td>
						<input type="number" id="priority" name="priority" value="<?php echo esc_attr( $priority ?: 10 ); ?>" min="1" max="100" style="width: 100px;" />
						<p class="description"><?php esc_html_e( 'Higher number = higher priority when multiple popups match. Default: 10', 'themeflex' ); ?></p>
					</td>
				</tr>
			</table>
		</div>
		<script>
			document.getElementById( 'overlay_opacity' ).addEventListener( 'change', function() {
				document.getElementById( 'opacity-value' ).textContent = parseFloat( this.value ).toFixed( 1 );
			} );

			document.getElementById( 'display_rule' ).addEventListener( 'change', function() {
				document.querySelectorAll( '.sf-display-condition' ).forEach( el => el.style.display = 'none' );
				const condition = document.querySelector( '.sf-display-condition[data-display="' + this.value + '"]' );
				if ( condition ) {
					condition.style.display = '';
				}
			} );

			document.getElementById( 'trigger_type' ).addEventListener( 'change', function() {
				document.querySelectorAll( '.sf-trigger-condition' ).forEach( el => el.style.display = 'none' );
				const condition = document.querySelector( '.sf-trigger-condition[data-trigger="' + this.value + '"]' );
				if ( condition ) {
					condition.style.display = '';
				}
			} );
		</script>
		<?php
	}

	/**
	 * Save popup meta data
	 *
	 * @since 1.0.0
	 */
	public static function save_popup_meta( $post_id ) {
		// Verify nonce
		if ( ! isset( $_POST['sf_popup_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['sf_popup_nonce'] ) ), 'sf_popup_nonce' ) ) {
			return;
		}

		// Verify user capability
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// Avoid infinite loops
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		// Save checkbox fields
		$checkbox_fields = array(
			'popup_enabled',
			'close_on_overlay',
			'show_404',
			'hide_on_mobile',
		);

		foreach ( $checkbox_fields as $field ) {
			if ( isset( $_POST[ $field ] ) ) {
				update_post_meta( $post_id, '_' . $field, 1 );
			} else {
				delete_post_meta( $post_id, '_' . $field );
			}
		}

		// Save text/select fields
		$text_fields = array(
			'trigger_type',
			'scroll_depth',
			'time_delay',
			'click_selector',
			'animation',
			'position',
			'layout',
			'popup_width',
			'custom_width',
			'display_rule',
			'frequency',
			'overlay_color',
			'overlay_opacity',
			'overlay_blur',
			'close_btn_position',
			'close_btn_delay',
			'priority',
		);

		foreach ( $text_fields as $field ) {
			if ( isset( $_POST[ $field ] ) ) {
				update_post_meta( $post_id, '_' . $field, sanitize_text_field( wp_unslash( $_POST[ $field ] ) ) );
			}
		}

		// Save array fields
		if ( isset( $_POST['specific_pages'] ) ) {
			$pages = array_map( 'intval', (array) $_POST['specific_pages'] );
			update_post_meta( $post_id, '_specific_pages', $pages );
		}

		if ( isset( $_POST['specific_categories'] ) ) {
			$categories = array_map( 'intval', (array) $_POST['specific_categories'] );
			update_post_meta( $post_id, '_specific_categories', $categories );
		}

		if ( isset( $_POST['woo_pages'] ) ) {
			$woo = array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['woo_pages'] ) );
			update_post_meta( $post_id, '_woo_pages', $woo );
		}
	}

	/**
	 * Enqueue admin assets
	 *
	 * @since 1.0.0
	 */
	public static function enqueue_admin_assets( $hook ) {
		global $post;

		if ( 'post.php' !== $hook && 'post-new.php' !== $hook ) {
			return;
		}

		if ( ! isset( $post ) || 'sf_popup' !== $post->post_type ) {
			return;
		}

		wp_enqueue_style(
			'sf-popup-admin',
			THEMEFLEX_URL . '/assets/css/popup-builder-admin.css',
			array(),
			THEMEFLEX_VERSION
		);

		wp_enqueue_script(
			'sf-popup-admin',
			THEMEFLEX_URL . '/assets/js/popup-builder-admin.js',
			array( 'jquery' ),
			THEMEFLEX_VERSION,
			true
		);
	}

	/**
	 * Enqueue frontend assets
	 *
	 * @since 1.0.0
	 */
	public static function enqueue_frontend_assets() {
		wp_enqueue_style(
			'sf-popup',
			THEMEFLEX_URL . '/assets/css/popup-builder.css',
			array(),
			THEMEFLEX_VERSION
		);

		wp_enqueue_script(
			'sf-popup',
			THEMEFLEX_URL . '/assets/js/popup-builder.js',
			array(),
			THEMEFLEX_VERSION,
			true
		);

		// Localize popup data
		wp_localize_script(
			'sf-popup',
			'sfPopupData',
			array(
				'nonce' => wp_create_nonce( 'sf_popup_nonce' ),
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			)
		);
	}

	/**
	 * Render popups on frontend
	 *
	 * @since 1.0.0
	 */
	public static function render_popups_on_page() {
		if ( is_admin() ) {
			return;
		}

		$args = array(
			'post_type' => 'sf_popup',
			'posts_per_page' => -1,
			'meta_query' => array(
				array(
					'key' => '_popup_enabled',
					'value' => 1,
				),
			),
			'orderby' => 'meta_value_num',
			'meta_key' => '_priority',
			'order' => 'DESC',
		);

		$popups = new WP_Query( $args );

		while ( $popups->have_posts() ) {
			$popups->the_post();
			$post_id = get_the_ID();

			if ( self::should_display_popup( $post_id ) ) {
				self::render_popup( $post_id );
			}
		}

		wp_reset_postdata();
	}

	/**
	 * Check if popup should be displayed
	 *
	 * @since 1.0.0
	 */
	private static function should_display_popup( $post_id ) {
		$display_rule = get_post_meta( $post_id, '_display_rule', true );
		$hide_on_mobile = get_post_meta( $post_id, '_hide_on_mobile', true );
		$frequency = get_post_meta( $post_id, '_frequency', true );

		// Check mobile
		if ( $hide_on_mobile && wp_is_mobile() ) {
			return false;
		}

		// Check display rule
		switch ( $display_rule ) {
			case 'all_pages':
				return true;

			case 'specific_pages':
				$specific_pages = get_post_meta( $post_id, '_specific_pages', true );
				return is_singular( array( 'page', 'post' ) ) && in_array( get_the_ID(), (array) $specific_pages, true );

			case 'specific_categories':
				$specific_categories = get_post_meta( $post_id, '_specific_categories', true );
				return is_category( $specific_categories );

			case 'woo_pages':
				if ( ! class_exists( 'WooCommerce' ) ) {
					return false;
				}
				$woo_pages = get_post_meta( $post_id, '_woo_pages', true );
				$show = false;
				if ( in_array( 'shop', (array) $woo_pages, true ) && is_shop() ) {
					$show = true;
				}
				if ( in_array( 'product', (array) $woo_pages, true ) && is_product() ) {
					$show = true;
				}
				if ( in_array( 'cart', (array) $woo_pages, true ) && is_cart() ) {
					$show = true;
				}
				if ( in_array( 'checkout', (array) $woo_pages, true ) && is_checkout() ) {
					$show = true;
				}
				if ( in_array( 'account', (array) $woo_pages, true ) && is_account_page() ) {
					$show = true;
				}
				return $show;

			default:
				return false;
		}
	}

	/**
	 * Render popup HTML
	 *
	 * @since 1.0.0
	 */
	private static function render_popup( $post_id ) {
		$post = get_post( $post_id );
		$animation = get_post_meta( $post_id, '_animation', true );
		$position = get_post_meta( $post_id, '_position', true );
		$layout = get_post_meta( $post_id, '_layout', true );
		$popup_width = get_post_meta( $post_id, '_popup_width', true );
		$custom_width = get_post_meta( $post_id, '_custom_width', true );
		$overlay_color = get_post_meta( $post_id, '_overlay_color', true );
		$overlay_opacity = get_post_meta( $post_id, '_overlay_opacity', true );
		$overlay_blur = get_post_meta( $post_id, '_overlay_blur', true );
		$close_on_overlay = get_post_meta( $post_id, '_close_on_overlay', true );
		$close_btn_position = get_post_meta( $post_id, '_close_btn_position', true );
		$close_btn_delay = get_post_meta( $post_id, '_close_btn_delay', true );

		$width_class = 'sf-popup-' . ( $popup_width ?: 'medium' );

		$popup_classes = array(
			'sf-popup-wrapper',
			'sf-popup-layout-' . $layout,
			'sf-popup-position-' . $position,
			'sf-popup-animation-' . $animation,
			$width_class,
		);

		$inline_styles = '';
		if ( 'custom' === $popup_width && $custom_width ) {
			$inline_styles = 'max-width: ' . intval( $custom_width ) . 'px;';
		}

		$overlay_styles = '';
		if ( $overlay_color || $overlay_opacity || $overlay_blur ) {
			$overlay_color = $overlay_color ?: '#000000';
			$overlay_opacity = $overlay_opacity ?: 0.5;
			$overlay_blur = $overlay_blur ?: 0;

			$overlay_styles = sprintf(
				'background-color: %s; opacity: %f;',
				esc_attr( $overlay_color ),
				floatval( $overlay_opacity )
			);

			if ( $overlay_blur > 0 ) {
				$overlay_styles .= ' backdrop-filter: blur(' . intval( $overlay_blur ) . 'px);';
			}
		}

		$trigger_data = array(
			'trigger_type' => get_post_meta( $post_id, '_trigger_type', true ),
			'scroll_depth' => get_post_meta( $post_id, '_scroll_depth', true ),
			'time_delay' => get_post_meta( $post_id, '_time_delay', true ),
			'click_selector' => get_post_meta( $post_id, '_click_selector', true ),
			'frequency' => get_post_meta( $post_id, '_frequency', true ),
			'close_btn_delay' => $close_btn_delay ?: 0,
		);

		?>
		<div class="sf-popup-overlay" style="<?php echo esc_attr( $overlay_styles ); ?>" <?php echo $close_on_overlay ? 'data-close-overlay="true"' : ''; ?>></div>
		<div class="<?php echo esc_attr( implode( ' ', $popup_classes ) ); ?>" style="<?php echo esc_attr( $inline_styles ); ?>" data-popup-id="<?php echo esc_attr( $post_id ); ?>" data-popup-config="<?php echo esc_attr( wp_json_encode( $trigger_data ) ); ?>">
			<?php if ( 'outside' === $close_btn_position ) : ?>
				<button class="sf-popup-close" aria-label="<?php esc_attr_e( 'Close popup', 'themeflex' ); ?>">
					<span></span>
					<span></span>
				</button>
			<?php endif; ?>
			<div class="sf-popup-content">
				<?php if ( 'inside' === $close_btn_position ) : ?>
					<button class="sf-popup-close" aria-label="<?php esc_attr_e( 'Close popup', 'themeflex' ); ?>">
						<span></span>
						<span></span>
					</button>
				<?php endif; ?>
				<?php
				echo wp_kses_post( apply_filters( 'the_content', $post->post_content ) );
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * Add custom columns to popup listing
	 *
	 * @since 1.0.0
	 */
	public static function popup_custom_columns( $columns ) {
		$new_columns = array(
			'cb' => $columns['cb'],
			'title' => $columns['title'],
			'trigger' => esc_html__( 'Trigger', 'themeflex' ),
			'display' => esc_html__( 'Display Rule', 'themeflex' ),
			'status' => esc_html__( 'Status', 'themeflex' ),
			'date' => $columns['date'],
		);
		return $new_columns;
	}

	/**
	 * Render custom column content
	 *
	 * @since 1.0.0
	 */
	public static function popup_column_content( $column, $post_id ) {
		switch ( $column ) {
			case 'trigger':
				$trigger = get_post_meta( $post_id, '_trigger_type', true );
				echo esc_html( ucwords( str_replace( '_', ' ', $trigger ?: 'None' ) ) );
				break;

			case 'display':
				$display = get_post_meta( $post_id, '_display_rule', true );
				echo esc_html( ucwords( str_replace( '_', ' ', $display ?: 'All Pages' ) ) );
				break;

			case 'status':
				$enabled = get_post_meta( $post_id, '_popup_enabled', true );
				echo $enabled ? '<span class="dashicons dashicons-yes" style="color: green;"></span>' : '<span class="dashicons dashicons-no" style="color: red;"></span>';
				break;
		}
	}

	/**
	 * Add custom post states
	 *
	 * @since 1.0.0
	 */
	public static function add_post_states( $states, $post ) {
		if ( 'sf_popup' === $post->post_type ) {
			$enabled = get_post_meta( $post->ID, '_popup_enabled', true );
			if ( ! $enabled ) {
				$states['sf_popup_disabled'] = esc_html__( 'Disabled', 'themeflex' );
			}
		}
		return $states;
	}

	/**
	 * AJAX handler for inline popup loading
	 *
	 * @since 1.0.0
	 */
	public static function ajax_popup_inline() {
		check_ajax_referer( 'sf_popup_nonce' );

		if ( ! isset( $_POST['popup_id'] ) ) {
			wp_send_json_error( 'Invalid popup ID' );
		}

		$popup_id = intval( $_POST['popup_id'] );
		$popup = get_post( $popup_id );

		if ( ! $popup || 'sf_popup' !== $popup->post_type ) {
			wp_send_json_error( 'Popup not found' );
		}

		if ( ! self::should_display_popup( $popup_id ) ) {
			wp_send_json_error( 'Popup should not be displayed on this page' );
		}

		ob_start();
		self::render_popup( $popup_id );
		$html = ob_get_clean();

		wp_send_json_success( array( 'html' => $html ) );
	}
}

// Initialize
ThemeFlex_Popup_Builder::init();
