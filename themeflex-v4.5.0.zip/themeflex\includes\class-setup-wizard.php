<?php
/**
 * Setup Wizard — Zero Config Mode
 *
 * Multi-step onboarding wizard that runs once after theme activation.
 * Steps: Welcome → Choose Demo → Choose Skin → Install Plugins → Import → Done
 *
 * @package ThemeFlex
 * @since   2.0.0
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Setup_Wizard {

    private static ?self $instance = null;
    const OPTION_COMPLETE = 'sf_wizard_complete';
    const OPTION_STEP     = 'sf_wizard_step';

    public static function instance(): self {
        if (is_null(self::$instance)) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu',   [$this, 'add_wizard_page']);
        add_action('admin_init',   [$this, 'maybe_redirect']);
        add_action('wp_ajax_sf_wizard_step', [$this, 'ajax_step']);
    }

    public function add_wizard_page(): void {
        add_dashboard_page(
            __('ThemeFlex Setup','themeflex'),
            __('Theme Setup','themeflex'),
            'manage_options',
            'sf-setup-wizard',
            [$this, 'render']
        );
    }

    public function maybe_redirect(): void {
        // Already complete
        if (get_option(self::OPTION_COMPLETE)) return;
        // Only run once after activation
        if (!get_transient('sf_activation_redirect')) return;
        delete_transient('sf_activation_redirect');
        // Don't redirect on bulk activation
        if (isset($_GET['activate-multi'])) return;
        wp_safe_redirect(admin_url('index.php?page=sf-setup-wizard'));
        exit;
    }

    public function ajax_step(): void {
        check_ajax_referer('sf_wizard_nonce','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

        $action = sanitize_key($_POST['wizard_action'] ?? '');
        $data   = $_POST['wizard_data'] ?? [];

        switch ($action) {
            case 'skip':
                update_option(self::OPTION_COMPLETE, true);
                wp_send_json_success(['redirect' => admin_url('themes.php?page=themeflex-welcome')]);
                break;

            case 'choose_demo':
                $demo = sanitize_key($data['demo'] ?? '');
                update_option('sf_wizard_selected_demo', $demo);
                wp_send_json_success(['next_step' => 3]);
                break;

            case 'choose_skin':
                $skin = sanitize_key($data['skin'] ?? '');
                if ($skin) {
                    set_theme_mod('sf_active_skin', $skin);
                    do_action('sf_skin_switched', $skin, '');
                }
                wp_send_json_success(['next_step' => 4]);
                break;

            case 'import_demo':
                $demo_id = get_option('sf_wizard_selected_demo', '');
                if ($demo_id && class_exists('ThemeFlex_Demo_Engine')) {
                    // Trigger import via demo engine — import all pages of selected demo
                    $engine = ThemeFlex_Demo_Engine::instance();
                    $demos  = $engine->get_all_demos();
                    if (isset($demos[$demo_id])) {
                        $demo = $demos[$demo_id];
                        // Apply skin
                        if (!empty($demo['skin'])) {
                            set_theme_mod('sf_active_skin', $demo['skin']);
                        }
                    }
                }
                update_option(self::OPTION_COMPLETE, true);
                wp_send_json_success(['redirect' => admin_url('themes.php?page=themeflex-welcome&wizard=done')]);
                break;
        }
    }

    public function render(): void {
        $step  = (int)($_GET['step'] ?? 1);
        $nonce = wp_create_nonce('sf_wizard_nonce');
        $demos = [];
        if (class_exists('ThemeFlex_Demo_Engine')) {
            $demos = ThemeFlex_Demo_Engine::instance()->get_all_demos();
        }
        $skins = function_exists('themeflex_skin_manager')
            ? themeflex_skin_manager()->get_skins()
            : [];
        $skin_colors = [
            'default'=>'#FF5E2E','corporate'=>'#1B4FD8','creative'=>'#10B981','agency'=>'#0066FF',
            'saas'=>'#7c3aed','realestate'=>'#c9a84c','medical'=>'#0D9488','restaurant'=>'#722F37',
            'freelancer'=>'#D97706','lawyer'=>'#B8860B','minimal'=>'#000','dark'=>'#00D4FF',
            'luxury'=>'#C9A84C','beauty'=>'#e88fa0','fitness'=>'#FF6B00','education'=>'#2563EB',
            'nonprofit'=>'#16a34a','photography'=>'#c9a84c','construction'=>'#F59E0B','finance'=>'#1e3a5f',
        ];
        // No wrapper div — full-screen page
        remove_action('admin_header', 'wp_admin_bar_render');
        ?>
        <!DOCTYPE html>
        <html <?php language_attributes(); ?>>
        <head>
        <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
        <title><?php esc_html_e('Setup Wizard — ThemeFlex','themeflex'); ?></title>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
        <style>
        *{box-sizing:border-box;margin:0;padding:0}
        body{font-family:'Inter',-apple-system,sans-serif;background:#f0f2f5;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:24px}
        .wz{width:100%;max-width:800px}
        .wz-card{background:#fff;border-radius:20px;padding:48px;box-shadow:0 8px 48px rgba(0,0,0,.08)}
        .wz-step{display:none}.wz-step.active{display:block}
        .wz-progress{display:flex;justify-content:center;gap:8px;margin-bottom:40px}
        .wz-dot{width:8px;height:8px;border-radius:50%;background:#e5e7eb;transition:all .2s}
        .wz-dot.done{background:#10b981}.wz-dot.active{background:#FF5E2E;width:24px;border-radius:4px}
        .wz-title{font-size:1.8rem;font-weight:900;color:#1e293b;text-align:center;margin-bottom:8px;letter-spacing:-.3px}
        .wz-sub{font-size:15px;color:#64748b;text-align:center;margin-bottom:32px;line-height:1.7}
        .wz-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;margin-bottom:32px;max-height:380px;overflow-y:auto}
        .wz-option{border:2px solid #e5e7eb;border-radius:12px;padding:16px;cursor:pointer;transition:all .2s;text-align:center}
        .wz-option:hover{border-color:#FF5E2E;background:rgba(255,94,46,.04)}
        .wz-option.selected{border-color:#FF5E2E;background:rgba(255,94,46,.06)}
        .wz-option-emoji{font-size:32px;margin-bottom:8px}
        .wz-option-name{font-size:12px;font-weight:700;color:#1e293b}
        .wz-btns{display:flex;align-items:center;justify-content:space-between;gap:12px}
        .wz-btn-p{padding:12px 28px;background:linear-gradient(135deg,#FF5E2E,#ED4C1C);color:#fff;border:none;border-radius:10px;font-weight:700;font-size:15px;cursor:pointer;font-family:inherit;transition:all .2s}
        .wz-btn-p:hover{filter:brightness(1.08)}
        .wz-btn-p:disabled{opacity:.6;cursor:not-allowed}
        .wz-btn-s{padding:10px 20px;background:transparent;border:1px solid #e5e7eb;border-radius:10px;font-size:14px;color:#64748b;cursor:pointer;font-family:inherit}
        .wz-skin-swatch{height:48px;border-radius:6px;margin-bottom:8px}
        </style>
        </head>
        <body>
        <div class="wz">
            <!-- Header -->
            <div style="text-align:center;margin-bottom:32px;">
                <div style="font-size:28px;font-weight:900;color:#1e293b;display:flex;align-items:center;justify-content:center;gap:10px;">
                    <div style="width:10px;height:10px;border-radius:50%;background:linear-gradient(135deg,#FF5E2E,#ED4C1C);"></div>
                    ThemeFlex
                </div>
            </div>
            <!-- Progress Dots -->
            <div class="wz-progress">
                <?php for ($i=1;$i<=5;$i++): ?>
                <div class="wz-dot <?php echo $i<$step?'done':($i===$step?'active':''); ?>" id="wz-dot-<?php echo $i; ?>"></div>
                <?php endfor; ?>
            </div>
            <!-- Card -->
            <div class="wz-card">
                <!-- Step 1: Welcome -->
                <div class="wz-step <?php echo $step===1?'active':''; ?>" id="wz-step-1">
                    <div style="font-size:64px;text-align:center;margin-bottom:20px;">👋</div>
                    <h1 class="wz-title"><?php esc_html_e('Welcome to ThemeFlex!','themeflex'); ?></h1>
                    <p class="wz-sub"><?php esc_html_e('Let\'s set up your website in 3 quick steps. It takes less than 2 minutes and you can change everything later.','themeflex'); ?></p>
                    <div style="display:flex;gap:16px;margin-bottom:28px;">
                        <?php foreach (['80+ Widgets','20 Skins','27 Demos','AI-Ready'] as $f): ?>
                        <div style="flex:1;text-align:center;padding:16px;background:#f8fafc;border-radius:10px;">
                            <div style="font-weight:800;font-size:18px;color:#FF5E2E;"><?php echo esc_html(explode(' ',$f)[0]); ?></div>
                            <div style="font-size:11px;color:#64748b;margin-top:2px;"><?php echo esc_html(implode(' ',array_slice(explode(' ',$f),1))); ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="wz-btns">
                        <button class="wz-btn-s" onclick="sfWzSkip()"><?php esc_html_e('Skip Setup','themeflex'); ?></button>
                        <button class="wz-btn-p" onclick="sfWzGo(2)"><?php esc_html_e('Let\'s Get Started →','themeflex'); ?></button>
                    </div>
                </div>
                <!-- Step 2: Choose Demo -->
                <div class="wz-step <?php echo $step===2?'active':''; ?>" id="wz-step-2">
                    <h1 class="wz-title"><?php esc_html_e('Choose your demo','themeflex'); ?></h1>
                    <p class="wz-sub"><?php esc_html_e('Start with a complete demo site. You can customise everything after import.','themeflex'); ?></p>
                    <div class="wz-grid">
                        <?php
                        $emojis=['default'=>'🏢','creative'=>'🎨','agency'=>'⚡','saas'=>'🚀','shop'=>'🛒','medical'=>'🏥','restaurant'=>'🍽️','photography'=>'📷','fitness'=>'💪','education'=>'📚','crypto'=>'₿','startup'=>'🌟','travel'=>'✈️','wedding'=>'💍','appstore'=>'📱','consulting'=>'🎯','yoga'=>'🧘'];
                        foreach (array_slice($demos,0,12) as $demo):
                            $emoji = $emojis[$demo['id']] ?? '📦';
                        ?>
                        <div class="wz-option" data-value="<?php echo esc_attr($demo['id']); ?>" onclick="sfWzSelect(this,'demo')">
                            <div class="wz-option-emoji"><?php echo $emoji; ?></div>
                            <div class="wz-option-name"><?php echo esc_html($demo['name']); ?></div>
                        </div>
                        <?php endforeach; ?>
                        <div class="wz-option" data-value="" onclick="sfWzSelect(this,'demo')">
                            <div class="wz-option-emoji">⬜</div>
                            <div class="wz-option-name"><?php esc_html_e('Blank (start fresh)','themeflex'); ?></div>
                        </div>
                    </div>
                    <div class="wz-btns">
                        <button class="wz-btn-s" onclick="sfWzGo(1)">← <?php esc_html_e('Back','themeflex'); ?></button>
                        <button class="wz-btn-p" id="wz-next-2" disabled onclick="sfWzChooseDemo()"><?php esc_html_e('Continue →','themeflex'); ?></button>
                    </div>
                </div>
                <!-- Step 3: Choose Skin -->
                <div class="wz-step <?php echo $step===3?'active':''; ?>" id="wz-step-3">
                    <h1 class="wz-title"><?php esc_html_e('Choose your style','themeflex'); ?></h1>
                    <p class="wz-sub"><?php esc_html_e('Each skin is a complete design system with colors, fonts, and component styles.','themeflex'); ?></p>
                    <div class="wz-grid">
                        <?php foreach ($skin_colors as $skin_id => $color): ?>
                        <div class="wz-option" data-value="<?php echo esc_attr($skin_id); ?>" onclick="sfWzSelect(this,'skin')">
                            <div class="wz-skin-swatch" style="background:linear-gradient(135deg,<?php echo esc_attr($color); ?>,<?php echo esc_attr($color); ?>88);"></div>
                            <div class="wz-option-name" style="text-transform:capitalize;"><?php echo esc_html($skin_id); ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="wz-btns">
                        <button class="wz-btn-s" onclick="sfWzGo(2)">← <?php esc_html_e('Back','themeflex'); ?></button>
                        <button class="wz-btn-p" id="wz-next-3" disabled onclick="sfWzChooseSkin()"><?php esc_html_e('Continue →','themeflex'); ?></button>
                    </div>
                </div>
                <!-- Step 4: Import -->
                <div class="wz-step <?php echo $step===4?'active':''; ?>" id="wz-step-4">
                    <div style="font-size:64px;text-align:center;margin-bottom:20px;">📦</div>
                    <h1 class="wz-title"><?php esc_html_e('Ready to build!','themeflex'); ?></h1>
                    <p class="wz-sub"><?php esc_html_e('Click Import to set up your selected demo and skin. This takes about 30 seconds.','themeflex'); ?></p>
                    <div id="wz-import-progress" style="display:none;margin:24px 0;">
                        <div style="height:6px;background:#e5e7eb;border-radius:3px;overflow:hidden;margin-bottom:8px;">
                            <div id="wz-prog-bar" style="height:100%;width:0;background:linear-gradient(90deg,#FF5E2E,#00D4FF);transition:width .3s;border-radius:3px;"></div>
                        </div>
                        <div id="wz-prog-text" style="font-size:13px;color:#64748b;text-align:center;"></div>
                    </div>
                    <div class="wz-btns" style="justify-content:center;flex-direction:column;gap:12px;">
                        <button class="wz-btn-p" style="width:100%;font-size:16px;padding:15px;" id="wz-import-btn" onclick="sfWzImport()"><?php esc_html_e('Import & Launch','themeflex'); ?></button>
                        <button class="wz-btn-s" onclick="sfWzSkip()"><?php esc_html_e('Skip — I\'ll set up manually','themeflex'); ?></button>
                    </div>
                </div>
                <!-- Step 5: Done -->
                <div class="wz-step <?php echo $step===5?'active':''; ?>" id="wz-step-5">
                    <div style="font-size:80px;text-align:center;margin-bottom:20px;animation:sfPulse 2s ease-in-out infinite;">🎉</div>
                    <h1 class="wz-title"><?php esc_html_e('You\'re all set!','themeflex'); ?></h1>
                    <p class="wz-sub"><?php esc_html_e('Your website is ready. Head to the Customizer to fine-tune colors, fonts, and more.','themeflex'); ?></p>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:28px;">
                        <?php foreach ([
                            [admin_url('customize.php'), '🎨', __('Open Customizer','themeflex')],
                            [admin_url('post-new.php?post_type=page'), '📄', __('Create a Page','themeflex')],
                            [admin_url('themes.php?page=themeflex-welcome'), '🏠', __('Theme Dashboard','themeflex')],
                            [home_url('/'), '🌐', __('View Website','themeflex')],
                        ] as [$url,$icon,$label]): ?>
                        <a href="<?php echo esc_url($url); ?>" style="display:flex;align-items:center;gap:10px;padding:14px 16px;background:#f8fafc;border:1px solid #e5e7eb;border-radius:10px;text-decoration:none;color:#1e293b;font-weight:600;font-size:14px;transition:all .2s;"
                            onmouseover="this.style.borderColor='#FF5E2E'" onmouseout="this.style.borderColor='#e5e7eb'">
                            <span style="font-size:20px;"><?php echo $icon; ?></span><?php echo esc_html($label); ?>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        <style>@keyframes sfPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.06)}}</style>
        <script>
        var sfWzNonce='<?php echo esc_js($nonce); ?>';
        var sfWzSelected={demo:null,skin:null};
        var sfWzCurrentStep=<?php echo $step; ?>;

        function sfWzGo(step){
            document.querySelectorAll('.wz-step').forEach(function(s){s.classList.remove('active');});
            document.getElementById('wz-step-'+step).classList.add('active');
            document.querySelectorAll('.wz-dot').forEach(function(d,i){
                d.classList.remove('active','done');
                if(i+1<step)d.classList.add('done');
                else if(i+1===step)d.classList.add('active');
            });
            sfWzCurrentStep=step;
        }

        function sfWzSelect(el,type){
            el.closest('.wz-grid').querySelectorAll('.wz-option').forEach(function(o){o.classList.remove('selected');});
            el.classList.add('selected');
            sfWzSelected[type]=el.dataset.value;
            var nextBtn=document.getElementById('wz-next-'+(sfWzCurrentStep));
            if(nextBtn)nextBtn.disabled=false;
        }

        function sfWzChooseDemo(){
            sfWzPost('choose_demo',{demo:sfWzSelected.demo||''},function(res){sfWzGo(3);});
        }
        function sfWzChooseSkin(){
            sfWzPost('choose_skin',{skin:sfWzSelected.skin||'default'},function(res){sfWzGo(4);});
        }
        function sfWzImport(){
            var btn=document.getElementById('wz-import-btn');
            btn.disabled=true;btn.textContent='<?php echo esc_js( __( 'Importing...', 'themeflex' ) ); ?>';
            document.getElementById('wz-import-progress').style.display='block';
            var steps=['<?php echo esc_js( __( 'Applying skin...', 'themeflex' ) ); ?>','<?php echo esc_js( __( 'Importing templates...', 'themeflex' ) ); ?>','<?php echo esc_js( __( 'Setting up pages...', 'themeflex' ) ); ?>','<?php echo esc_js( __( 'Almost done...', 'themeflex' ) ); ?>'];
            var i=0;var iv=setInterval(function(){
                if(i<steps.length){document.getElementById('wz-prog-bar').style.width=(i+1)/steps.length*80+'%';document.getElementById('wz-prog-text').textContent=steps[i++];}
            },600);
            sfWzPost('import_demo',{},function(res){
                clearInterval(iv);
                document.getElementById('wz-prog-bar').style.width='100%';
                document.getElementById('wz-prog-text').textContent='<?php echo esc_js( __( 'Done!', 'themeflex' ) ); ?>';
                setTimeout(function(){
                    if(res.redirect)window.location.href=res.redirect;
                    else sfWzGo(5);
                },800);
            });
        }
        function sfWzSkip(){
            sfWzPost('skip',{},function(res){
                if(res.redirect)window.location.href=res.redirect;
            });
        }
        function sfWzPost(action,data,cb){
            var fd=new FormData();
            fd.append('action','sf_wizard_step');
            fd.append('nonce',sfWzNonce);
            fd.append('wizard_action',action);
            for(var k in data)fd.append('wizard_data['+k+']',data[k]);
            fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>',{method:'POST',body:fd})
            .then(function(r){return r.json();})
            .then(function(res){if(res.success&&cb)cb(res.data);});
        }
        </script>
        </body>
        </html>
        <?php
        exit; // Don't render admin wrapper
    }
}

ThemeFlex_Setup_Wizard::instance();
