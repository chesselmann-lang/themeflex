<?php
/**
 * ThemeFlex Skin Manager
 *
 * Manages theme skins with extensible skin system for customization.
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Skin Manager Class
 *
 * @since 1.0.0
 */
class ThemeFlex_Skin_Manager {

	/**
	 * Available skins
	 *
	 * @var array
	 */
	private $skins = array();

	/**
	 * Google Fonts typography pairings.
	 *
	 * Each entry contains:
	 *  - label          Human-readable name shown in the Customizer.
	 *  - heading_font   CSS font-family value for headings (without quotes).
	 *  - body_font      CSS font-family value for body text (without quotes).
	 *  - google_url     The families/weights fragment appended to the Fonts API URL.
	 *
	 * @since 1.3.0
	 * @var array
	 */
	private static $font_pairs = array(
		'inter-tight'   => array(
			'label'       => 'Inter Tight / Inter',
			'heading_font' => 'Inter Tight',
			'body_font'    => 'Inter',
			'google_url'   => 'Inter+Tight:wght@800;900&family=Inter:wght@400;500;600',
		),
		'plus-jakarta'  => array(
			'label'       => 'Plus Jakarta Sans',
			'heading_font' => 'Plus Jakarta Sans',
			'body_font'    => 'Plus Jakarta Sans',
			'google_url'   => 'Plus+Jakarta+Sans:wght@400;500;700;800;900',
		),
		'outfit'        => array(
			'label'       => 'Outfit / Inter',
			'heading_font' => 'Outfit',
			'body_font'    => 'Inter',
			'google_url'   => 'Outfit:wght@700;800;900&family=Inter:wght@400;500',
		),
		'sora'          => array(
			'label'       => 'Sora',
			'heading_font' => 'Sora',
			'body_font'    => 'Sora',
			'google_url'   => 'Sora:wght@400;500;700;800',
		),
		'space-grotesk' => array(
			'label'       => 'Space Grotesk',
			'heading_font' => 'Space Grotesk',
			'body_font'    => 'Space Grotesk',
			'google_url'   => 'Space+Grotesk:wght@400;500;700',
		),
		'dm-sans'       => array(
			'label'       => 'DM Sans',
			'heading_font' => 'DM Sans',
			'body_font'    => 'DM Sans',
			'google_url'   => 'DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,700;0,9..40,800;1,9..40,400',
		),
		'cormorant'     => array(
			'label'       => 'Cormorant Garamond / Jost',
			'heading_font' => 'Cormorant Garamond',
			'body_font'    => 'Jost',
			'google_url'   => 'Cormorant+Garamond:wght@600;700&family=Jost:wght@400;500',
		),
	);

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->load_skins();

		add_action( 'customize_register', array( $this, 'customize_register' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_skin_styles' ) );
		add_action( 'wp_head', array( $this, 'output_skin_css_variables' ) );
	}

	/**
	 * Load all available skins
	 *
	 * @since 1.0.0
	 */
	private function load_skins() {
		$skins_dir = THEMEFLEX_DIR . '/skins';

		// Load built-in skins
		$this->register_builtin_skins();

		// Allow plugins/child themes to register skins
		do_action( 'sf_register_skin', $this );

		// Load skins from /skins directory
		if ( is_dir( $skins_dir ) ) {
			$skin_folders = array_diff( scandir( $skins_dir ), array( '.', '..' ) );

			foreach ( $skin_folders as $folder ) {
				$skin_path = $skins_dir . '/' . $folder;

				if ( ! is_dir( $skin_path ) ) {
					continue;
				}

				$skin_data_file = $skin_path . '/skin.json';

				if ( file_exists( $skin_data_file ) ) {
					$skin_data = json_decode( file_get_contents( $skin_data_file ), true );

					if ( $skin_data ) {
						$this->skins[ $folder ] = array_merge(
							array(
								'id'        => $folder,
								'path'      => $skin_path,
								'name'      => $skin_data['name'] ?? ucfirst( $folder ),
								'desc'      => $skin_data['description'] ?? '',
								'screenshot' => $skin_path . '/screenshot.jpg',
								'config'    => $skin_path . '/skin.php',
								'css'       => $skin_path . '/skin.css',
							),
							$skin_data
						);
					}
				}
			}
		}
	}

	/**
	 * Register built-in skins
	 *
	 * @since 1.0.0
	 */
	private function register_builtin_skins() {
		$skins_dir = THEMEFLEX_DIR . '/skins';

		// Default Skin
		$this->skins['default'] = array(
			'id'         => 'default',
			'name'       => 'Default',
			'desc'       => 'The current orange design',
			'path'       => $skins_dir . '/default',
			'screenshot' => $skins_dir . '/default/screenshot.jpg',
			'font_pair'  => 'inter-tight',
			'colors'     => array(
				'primary'   => '#FF5E2E',
				'secondary' => '#1F242E',
				'accent'    => '#00D4FF',
			),
		);

		// Corporate Skin
		$this->skins['corporate'] = array(
			'id'         => 'corporate',
			'name'       => 'Corporate',
			'desc'       => 'Professional blue design with serif headings',
			'path'       => $skins_dir . '/corporate',
			'screenshot' => $skins_dir . '/corporate/screenshot.jpg',
			'font_pair'  => 'dm-sans',
			'colors'     => array(
				'primary'   => '#3B82F6',
				'secondary' => '#1e293b',
				'accent'    => '#f59e0b',
			),
			'typography' => array(
				'heading_font_family' => 'Lora',
			),
		);

		// Creative Skin
		$this->skins['creative'] = array(
			'id'         => 'creative',
			'name'       => 'Creative',
			'desc'       => 'Modern green design with gradient accents',
			'path'       => $skins_dir . '/creative',
			'screenshot' => $skins_dir . '/creative/screenshot.jpg',
			'font_pair'  => 'plus-jakarta',
			'colors'     => array(
				'primary'      => '#10B981',
				'primary_dark' => '#059669',
				'secondary'    => '#065f46',
				'accent'       => '#ec4899',
			),
			'scheme'     => array(
				'alt_bg'     => '#030d09',
				'alt_bg_2'   => '#061a10',
				'alt_border' => 'rgba(16,185,129,.12)',
				'alt_title'  => '#ecfdf5',
				'alt_text'   => '#6ee7b7',
				'alt_meta'   => '#34d399',
			),
		);

		// ── Midnight Skin (Deep Violet / Purple) ────────────────────────
		$this->skins['midnight'] = array(
			'id'         => 'midnight',
			'name'       => 'Midnight',
			'desc'       => 'Deep violet with electric purple — perfect for SaaS and tech',
			'path'       => $skins_dir . '/midnight',
			'screenshot' => $skins_dir . '/midnight/screenshot.jpg',
			'font_pair'  => 'space-grotesk',
			'colors'     => array(
				'primary'       => '#7C3AED',
				'primary_dark'  => '#6d28d9',
				'primary_light' => '#a78bfa',
				'secondary'     => '#1e1b4b',
				'accent'        => '#f59e0b',
				'accent_light'  => '#fcd34d',
			),
			'scheme'     => array(
				'alt_bg'     => '#05030f',
				'alt_bg_2'   => '#0d0a1f',
				'alt_border' => 'rgba(124,58,237,.14)',
				'alt_title'  => '#f5f3ff',
				'alt_text'   => '#c4b5fd',
				'alt_meta'   => '#7c6fcd',
			),
			'typography' => array(
				'heading_font_family' => 'Space Grotesk',
			),
		);

		// ── Rose Skin (Crimson / Bold) ───────────────────────────────────
		$this->skins['rose'] = array(
			'id'         => 'rose',
			'name'       => 'Rose',
			'desc'       => 'Bold crimson — standout for creative studios and beauty brands',
			'path'       => $skins_dir . '/rose',
			'screenshot' => $skins_dir . '/rose/screenshot.jpg',
			'font_pair'  => 'cormorant',
			'colors'     => array(
				'primary'       => '#E11D48',
				'primary_dark'  => '#be123c',
				'primary_light' => '#fb7185',
				'secondary'     => '#1c0a0d',
				'accent'        => '#f97316',
				'accent_light'  => '#fdba74',
			),
			'scheme'     => array(
				'alt_bg'     => '#0c0206',
				'alt_bg_2'   => '#18060c',
				'alt_border' => 'rgba(225,29,72,.14)',
				'alt_title'  => '#fff1f2',
				'alt_text'   => '#fda4af',
				'alt_meta'   => '#e07080',
			),
			'typography' => array(
				'heading_font_family' => 'Playfair Display',
			),
		);

		// ── Ocean Skin (Teal / Cyan — Clean Professional) ────────────────
		$this->skins['ocean'] = array(
			'id'         => 'ocean',
			'name'       => 'Ocean',
			'desc'       => 'Deep teal and cyan — elegant for agencies and consultancies',
			'path'       => $skins_dir . '/ocean',
			'screenshot' => $skins_dir . '/ocean/screenshot.jpg',
			'font_pair'  => 'outfit',
			'colors'     => array(
				'primary'       => '#0891B2',
				'primary_dark'  => '#0e7490',
				'primary_light' => '#22d3ee',
				'secondary'     => '#0c1a22',
				'accent'        => '#6366f1',
				'accent_light'  => '#a5b4fc',
			),
			'scheme'     => array(
				'alt_bg'     => '#020e14',
				'alt_bg_2'   => '#071620',
				'alt_border' => 'rgba(8,145,178,.14)',
				'alt_title'  => '#ecfeff',
				'alt_text'   => '#67e8f9',
				'alt_meta'   => '#22b8c9',
			),
			'typography' => array(
				'heading_font_family' => 'DM Sans',
			),
		);

		// ── Amber Skin (Gold / Luxury / Premium) ────────────────────────
		$this->skins['amber'] = array(
			'id'         => 'amber',
			'name'       => 'Amber',
			'desc'       => 'Warm gold — premium feel for luxury brands and high-end agencies',
			'path'       => $skins_dir . '/amber',
			'screenshot' => $skins_dir . '/amber/screenshot.jpg',
			'font_pair'  => 'cormorant',
			'colors'     => array(
				'primary'       => '#D97706',
				'primary_dark'  => '#b45309',
				'primary_light' => '#fbbf24',
				'secondary'     => '#1c1003',
				'accent'        => '#ef4444',
				'accent_light'  => '#fca5a5',
			),
			'scheme'     => array(
				'alt_bg'     => '#0c0800',
				'alt_bg_2'   => '#181004',
				'alt_border' => 'rgba(217,119,6,.15)',
				'alt_title'  => '#fffbeb',
				'alt_text'   => '#fde68a',
				'alt_meta'   => '#d4a840',
			),
			'typography' => array(
				'heading_font_family' => 'Cormorant Garamond',
				'body_font_family'    => 'Jost',
			),
		);

		// ── Neon Skin (Cyberpunk / Gaming / Bold Tech) ──────────────────
		$this->skins['neon'] = array(
			'id'         => 'neon',
			'name'       => 'Neon',
			'desc'       => 'Cyberpunk electric cyan on near-black — gaming, tech, Web3',
			'path'       => $skins_dir . '/neon',
			'screenshot' => $skins_dir . '/neon/screenshot.jpg',
			'font_pair'  => 'sora',
			'colors'     => array(
				'primary'       => '#00F5FF',
				'primary_dark'  => '#00c4ca',
				'primary_light' => '#7ffcff',
				'secondary'     => '#0a0014',
				'accent'        => '#ff2d78',
				'accent_light'  => '#ff7eb3',
			),
			'scheme'     => array(
				'alt_bg'     => '#020007',
				'alt_bg_2'   => '#08000e',
				'alt_border' => 'rgba(0,245,255,.12)',
				'alt_title'  => '#e0feff',
				'alt_text'   => '#67e8f9',
				'alt_meta'   => '#22d3ee',
			),
			'typography' => array(
				'heading_font_family' => 'Exo 2',
				'body_font_family'    => 'Rajdhani',
			),
		);
	}

	/**
	 * Get all registered skins
	 *
	 * @since 1.0.0
	 * @return array List of skins.
	 */
	public function get_skins() {
		return $this->skins;
	}

	/**
	 * Get a specific skin
	 *
	 * @since 1.0.0
	 * @param string $skin_id The skin ID.
	 * @return array|false Skin data or false if not found.
	 */
	public function get_skin( $skin_id ) {
		return isset( $this->skins[ $skin_id ] ) ? $this->skins[ $skin_id ] : false;
	}

	/**
	 * Register a custom skin
	 *
	 * @since 1.0.0
	 * @param string $skin_id The skin ID.
	 * @param array  $skin_args Skin arguments.
	 */
	public function register_skin( $skin_id, $skin_args ) {
		$defaults = array(
			'id'         => $skin_id,
			'name'       => ucfirst( $skin_id ),
			'desc'       => '',
			'path'       => '',
			'screenshot' => '',
			'colors'     => array(),
			'typography' => array(),
		);

		$this->skins[ $skin_id ] = wp_parse_args( $skin_args, $defaults );
	}

	/**
	 * Get active skin ID
	 *
	 * @since 1.0.0
	 * @return string The active skin ID.
	 */
	public function get_active_skin() {
		return get_theme_mod( 'themeflex_active_skin', 'default' );
	}

	/**
	 * Set active skin
	 *
	 * @since 1.0.0
	 * @param string $skin_id The skin ID.
	 * @return bool True if set successfully.
	 */
	public function set_active_skin( $skin_id ) {
		if ( ! isset( $this->skins[ $skin_id ] ) ) {
			return false;
		}

		set_theme_mod( 'themeflex_active_skin', $skin_id );

		// Load skin config if available
		$skin = $this->get_skin( $skin_id );
		if ( $skin && file_exists( $skin['config'] ) ) {
			include_once $skin['config'];
		}

		return true;
	}

	/**
	 * Register customizer controls — visual swatch picker
	 *
	 * @since 1.2.0
	 * @param WP_Customize_Manager $wp_customize The customizer object.
	 */
	public function customize_register( $wp_customize ) {

		// ── Section ────────────────────────────────────────────────────────
		$wp_customize->add_section(
			'themeflex_skins',
			array(
				'title'       => '🎨 Skins',
				'description' => 'Choose one of 8 built-in color schemes. Each skin sets the primary accent, background depths, and (where applicable) a custom Google Font pairing.',
				'panel'       => 'themeflex_colors',
				'priority'    => 5,
			)
		);

		// ── Setting ────────────────────────────────────────────────────────
		$wp_customize->add_setting(
			'themeflex_active_skin',
			array(
				'default'           => 'default',
				'sanitize_callback' => array( $this, 'sanitize_skin_id' ),
				'transport'         => 'refresh',
			)
		);

		// ── Register custom visual swatch control class ────────────────────
		if ( ! class_exists( 'ThemeFlex_Skin_Swatch_Control' ) ) {
			require_once THEMEFLEX_DIR . '/includes/class-skin-swatch-control.php';
		}

		if ( class_exists( 'ThemeFlex_Skin_Swatch_Control' ) ) {
			$wp_customize->add_control( new ThemeFlex_Skin_Swatch_Control(
				$wp_customize,
				'themeflex_active_skin',
				array(
					'section' => 'themeflex_skins',
					'label'   => 'Select Skin',
					'skins'   => $this->skins,
				)
			) );
		} else {
			// Fallback: plain select
			$wp_customize->add_control(
				'themeflex_active_skin',
				array(
					'type'    => 'select',
					'section' => 'themeflex_skins',
					'label'   => 'Select Skin',
					'choices' => $this->get_skin_choices(),
				)
			);
		}

		// ── Typography Section ─────────────────────────────────────────────
		$wp_customize->add_section(
			'sf_typography_section',
			array(
				'title'       => __( 'Typography', 'themeflex' ),
				'description' => __( 'Choose a Google Fonts pairing for headings and body text. The selected pair overrides the skin default and is loaded automatically via the Google Fonts API.', 'themeflex' ),
				'panel'       => 'themeflex_colors',
				'priority'    => 10,
			)
		);

		// ── Typography Setting ─────────────────────────────────────────────
		$wp_customize->add_setting(
			'sf_font_pair',
			array(
				'default'           => 'inter-tight',
				'sanitize_callback' => array( $this, 'sanitize_font_pair_id' ),
				'transport'         => 'refresh',
			)
		);

		// ── Typography Control — select with human-readable pair labels ────
		$font_pair_choices = array();
		foreach ( self::$font_pairs as $pair_id => $pair_data ) {
			$font_pair_choices[ $pair_id ] = $pair_data['label'];
		}

		$wp_customize->add_control(
			'sf_font_pair',
			array(
				'type'        => 'select',
				'section'     => 'sf_typography_section',
				'label'       => __( 'Font Pairing', 'themeflex' ),
				'description' => __( 'Heading font / body font. Leave on "Skin default" to use the pairing bundled with each skin.', 'themeflex' ),
				'choices'     => $font_pair_choices,
			)
		);
	}

	/**
	 * Sanitize font pair ID — must be a key in $font_pairs.
	 *
	 * @since 1.3.0
	 * @param string $value Raw input.
	 * @return string Valid pair ID or 'inter-tight'.
	 */
	public function sanitize_font_pair_id( $value ) {
		return isset( self::$font_pairs[ $value ] ) ? $value : 'inter-tight';
	}

	/**
	 * Sanitize skin ID — must be a registered skin key.
	 *
	 * @param string $value Raw input.
	 * @return string Validated skin ID or 'default'.
	 */
	public function sanitize_skin_id( $value ) {
		return isset( $this->skins[ $value ] ) ? $value : 'default';
	}

	/**
	 * Get skin choices for customizer
	 *
	 * @since 1.0.0
	 * @return array Skin choices.
	 */
	private function get_skin_choices() {
		$choices = array();
		foreach ( $this->skins as $skin ) {
			$choices[ $skin['id'] ] = $skin['name'];
		}
		return $choices;
	}

	/**
	 * Enqueue active skin stylesheet + Google Fonts for custom typography.
	 *
	 * @since 1.2.0
	 */
	public function enqueue_skin_styles() {
		$active_skin_id = $this->get_active_skin();
		$skin           = $this->get_skin( $active_skin_id );

		if ( ! $skin ) {
			return;
		}

		// ── Enqueue skin CSS file if it exists ────────────────────────────
		$css_path = isset( $skin['css'] ) ? $skin['css'] : ( $skin['path'] . '/skin.css' );
		if ( file_exists( $css_path ) ) {
			$relative_path = str_replace( THEMEFLEX_DIR, '', $css_path );
			wp_enqueue_style(
				'sf-skin-' . $active_skin_id,
				THEMEFLEX_URL . $relative_path,
				array( 'themeflex-style' ),
				THEMEFLEX_VERSION
			);
		}

		// ── Google Fonts for skin-specific typography ─────────────────────
		$typ = isset( $skin['typography'] ) ? $skin['typography'] : array();
		$this->enqueue_skin_google_fonts( $typ );

		// ── Google Fonts for selected typography pairing ──────────────────
		$this->enqueue_font_pair();

		// ── Load skin PHP config if it exists ─────────────────────────────
		$config_path = isset( $skin['config'] ) ? $skin['config'] : ( $skin['path'] . '/skin.php' );
		if ( file_exists( $config_path ) ) {
			include_once $config_path;
		}
	}

	/**
	 * Build and enqueue a Google Fonts URL for a skin's typography config.
	 * Only non-system fonts are fetched (Inter Tight is already loaded by default).
	 *
	 * @param array $typ Typography config from skin definition.
	 */
	private function enqueue_skin_google_fonts( array $typ ) {
		// Fonts already present in the default theme enqueue — skip them
		$default_fonts = array( 'Inter Tight', 'Inter', 'system-ui', 'sans-serif' );

		$families = array();
		foreach ( array( 'heading_font_family', 'body_font_family' ) as $key ) {
			if ( ! empty( $typ[ $key ] ) && ! in_array( $typ[ $key ], $default_fonts, true ) ) {
				$families[] = $typ[ $key ];
			}
		}

		if ( empty( $families ) ) {
			return;
		}

		// Google Fonts API v2 — variable font weights 300-900
		$family_params = array_map( function( $f ) {
			return 'family=' . rawurlencode( $f ) . ':ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,400';
		}, array_unique( $families ) );

		$url = 'https://fonts.googleapis.com/css2?' . implode( '&', $family_params ) . '&display=swap';

		wp_enqueue_style(
			'sf-skin-fonts-' . get_theme_mod( 'themeflex_active_skin', 'default' ),
			$url,
			array(),
			null
		);
	}

	/**
	 * Return the active font pair ID.
	 *
	 * Priority order:
	 *  1. Customizer setting `sf_font_pair` (user override).
	 *  2. `font_pair` key on the active skin definition.
	 *  3. Hard-coded fallback 'inter-tight'.
	 *
	 * @since 1.3.0
	 * @return string Font pair ID.
	 */
	public function get_active_font_pair() {
		// 1. User override via Customizer.
		$customizer_pair = get_theme_mod( 'sf_font_pair', '' );
		if ( $customizer_pair && isset( self::$font_pairs[ $customizer_pair ] ) ) {
			return $customizer_pair;
		}

		// 2. Per-skin default.
		$skin = $this->get_skin( $this->get_active_skin() );
		if ( $skin && ! empty( $skin['font_pair'] ) && isset( self::$font_pairs[ $skin['font_pair'] ] ) ) {
			return $skin['font_pair'];
		}

		// 3. Global fallback.
		return 'inter-tight';
	}

	/**
	 * Enqueue Google Fonts for the active font pairing.
	 *
	 * Registers a stylesheet with `display=swap` so text renders immediately
	 * using the fallback font while the web font loads.
	 *
	 * @since 1.3.0
	 */
	private function enqueue_font_pair() {
		$pair_id = $this->get_active_font_pair();
		$pair    = self::$font_pairs[ $pair_id ];

		$url = 'https://fonts.googleapis.com/css2?family=' . $pair['google_url'] . '&display=swap';

		wp_enqueue_style(
			'sf-font-pair-' . $pair_id,
			$url,
			array(),
			null
		);
	}

	/**
	 * Return the full font pairs definitions array (used by Customizer JS).
	 *
	 * @since 1.3.0
	 * @return array
	 */
	public static function get_font_pairs() {
		return self::$font_pairs;
	}

	/**
	 * Output skin CSS variables based on active skin
	 *
	 * @since 1.0.0
	 */
	/**
	 * Output all skin CSS custom properties into :root.
	 *
	 * Emits three layers:
	 *  1. Brand color tokens  (--sf-color-primary, --sf-gradient, …)
	 *  2. Semantic surface tokens inspired by Elementra's color-scheme system:
	 *       --sf-bg / --sf-bg-2 / --sf-border / --sf-title / --sf-text / --sf-meta
	 *       --sf-alt-bg / --sf-alt-bg-2 / … (for dark/inverse sections)
	 *       --sf-link / --sf-hover / --sf-alt-link / --sf-alt-hover
	 *  3. Typography tokens  (--sf-body-font / --sf-heading-font)
	 *
	 * Skin CSS files can override any token freely; this gives sane defaults.
	 *
	 * @since 1.1.0
	 */
	public function output_skin_css_variables() {
		if ( is_admin() ) {
			return;
		}

		$skin = $this->get_skin( $this->get_active_skin() );
		if ( ! $skin ) {
			return;
		}

		$c   = isset( $skin['colors'] )     ? $skin['colors']     : array();
		$sch = isset( $skin['scheme'] )     ? $skin['scheme']     : array();
		$typ = isset( $skin['typography'] ) ? $skin['typography'] : array();

		/* ── helpers ─────────────────────────────────────────────────────── */
		$v = static function( array $src, string $key ) {
			return isset( $src[ $key ] ) ? esc_attr( $src[ $key ] ) : '';
		};

		/* ── Brand color tokens ─────────────────────────────────────────── */
		$primary       = $v( $c, 'primary' );
		$primary_dark  = $v( $c, 'primary_dark' );
		$primary_light = $v( $c, 'primary_light' );
		$secondary     = $v( $c, 'secondary' );
		$accent        = $v( $c, 'accent' );
		$accent_light  = $v( $c, 'accent_light' );

		// Derive dark/light if not set explicitly
		$derived_dark  = $primary ? 'color-mix(in srgb,' . $primary . ' 80%,#000)' : '';
		$derived_light = $primary ? 'color-mix(in srgb,' . $primary . ' 70%,#fff)' : '';

		$css = ':root {';

		if ( $primary )                     $css .= '--sf-color-primary:'       . $primary . ';';
		if ( $primary_dark  ?: $derived_dark  ) $css .= '--sf-color-primary-dark:'  . ( $primary_dark  ?: $derived_dark  ) . ';';
		if ( $primary_light ?: $derived_light ) $css .= '--sf-color-primary-light:' . ( $primary_light ?: $derived_light ) . ';';
		if ( $secondary )                   $css .= '--sf-color-secondary:'     . $secondary . ';';
		if ( $accent )                      $css .= '--sf-color-accent:'        . $accent . ';';
		if ( $accent_light )                $css .= '--sf-color-accent-light:'  . $accent_light . ';';

		// Gradient shorthands
		$pd = $primary_dark ?: $derived_dark;
		$pl = $primary_light ?: $derived_light;
		if ( $primary && $pd ) {
			$css .= '--sf-gradient:linear-gradient(135deg,' . $primary . ' 0%,' . $pd . ' 100%);';
			$css .= '--sf-gradient-dark:linear-gradient(135deg,' . $pd . ' 0%,color-mix(in srgb,' . $primary . ' 60%,#000) 100%);';
		}
		if ( $primary ) {
			$css .= '--sf-gradient-soft:linear-gradient(135deg,color-mix(in srgb,' . $primary . ' 12%,#fff) 0%,color-mix(in srgb,' . $primary . ' 6%,#fff) 100%);';
		}

		/* ── Semantic surface tokens (Elementra-style, 16 tokens) ────────── */
		// Main scheme (light sections)
		$bg         = $v( $sch, 'bg' );
		$bg_2       = $v( $sch, 'bg_2' );
		$border     = $v( $sch, 'border' );
		$title      = $v( $sch, 'title' );
		$text       = $v( $sch, 'text' );
		$meta       = $v( $sch, 'meta' );
		// Alt scheme (dark/inverse sections, footer, hero overlays)
		$alt_bg     = $v( $sch, 'alt_bg' );
		$alt_bg_2   = $v( $sch, 'alt_bg_2' );
		$alt_border = $v( $sch, 'alt_border' );
		$alt_title  = $v( $sch, 'alt_title' );
		$alt_text   = $v( $sch, 'alt_text' );
		$alt_meta   = $v( $sch, 'alt_meta' );

		if ( $bg )         $css .= '--sf-bg:'         . $bg . ';';
		if ( $bg_2 )       $css .= '--sf-bg-2:'       . $bg_2 . ';';
		if ( $border )     $css .= '--sf-border:'     . $border . ';';
		if ( $title )      $css .= '--sf-title:'      . $title . ';';
		if ( $text )       $css .= '--sf-text:'       . $text . ';';
		if ( $meta )       $css .= '--sf-meta:'       . $meta . ';';

		if ( $alt_bg )     $css .= '--sf-alt-bg:'     . $alt_bg . ';';
		if ( $alt_bg_2 )   $css .= '--sf-alt-bg-2:'   . $alt_bg_2 . ';';
		if ( $alt_border ) $css .= '--sf-alt-border:' . $alt_border . ';';
		if ( $alt_title )  $css .= '--sf-alt-title:'  . $alt_title . ';';
		if ( $alt_text )   $css .= '--sf-alt-text:'   . $alt_text . ';';
		if ( $alt_meta )   $css .= '--sf-alt-meta:'   . $alt_meta . ';';

		// link / hover always derived from brand colors
		if ( $primary )  $css .= '--sf-link:' . $primary . ';--sf-alt-link:' . $primary . ';';
		if ( $pd )       $css .= '--sf-hover:' . $pd . ';';
		if ( $pl )       $css .= '--sf-alt-hover:' . $pl . ';';

		/* ── Typography ──────────────────────────────────────────────────── */
		$body_font    = $v( $typ, 'body_font_family' );
		$heading_font = $v( $typ, 'heading_font_family' );
		$base_size    = $v( $typ, 'base_font_size' );
		$base_lh      = $v( $typ, 'base_line_height' );

		if ( $body_font )    $css .= "--sf-body-font:'{$body_font}',sans-serif;";
		if ( $heading_font ) $css .= "--sf-heading-font:'{$heading_font}',sans-serif;";
		if ( $base_size )    $css .= "--sf-font-size-base:{$base_size};";
		if ( $base_lh )      $css .= "--sf-line-height-base:{$base_lh};";

		/* ── Google Fonts pairing tokens ─────────────────────────────────── */
		// --tf-font-heading and --tf-font-body come from the active font pair.
		// They are separate from the per-skin typography keys above so that the
		// Customizer "Font Pairing" control can override without touching the
		// skin's own --sf-heading-font / --sf-body-font legacy tokens.
		$pair_id   = $this->get_active_font_pair();
		$pair_data = self::$font_pairs[ $pair_id ];

		$tf_heading = esc_attr( $pair_data['heading_font'] );
		$tf_body    = esc_attr( $pair_data['body_font'] );

		$css .= "--tf-font-heading:'{$tf_heading}',sans-serif;";
		$css .= "--tf-font-body:'{$tf_body}',sans-serif;";

		$css .= '}';

		wp_register_style( 'sf-skin-variables', false );
		wp_enqueue_style( 'sf-skin-variables' );
		wp_add_inline_style( 'sf-skin-variables', $css );
	}

	/**
	 * Get screenshot URL for a skin
	 *
	 * @since 1.0.0
	 * @param string $skin_id The skin ID.
	 * @return string|false Screenshot URL or false.
	 */
	public function get_skin_screenshot( $skin_id ) {
		$skin = $this->get_skin( $skin_id );

		if ( ! $skin || ! file_exists( $skin['screenshot'] ) ) {
			return false;
		}

		$relative_path = str_replace( THEMEFLEX_DIR, '', $skin['screenshot'] );
		return THEMEFLEX_URL . $relative_path;
	}
}

// Initialize the class
function themeflex_skin_manager() {
	static $instance = null;

	if ( is_null( $instance ) ) {
		$instance = new ThemeFlex_Skin_Manager();
	}

	return $instance;
}

// Get the skin manager instance
themeflex_skin_manager();
