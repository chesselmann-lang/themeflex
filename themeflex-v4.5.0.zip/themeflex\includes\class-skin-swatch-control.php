<?php
/**
 * ThemeFlex Skin Swatch Control
 *
 * A custom WP_Customize_Control that renders a visual grid of skins —
 * each card shows a colour swatch, the skin name, and a short description.
 * Selecting a card updates the hidden input so WP Customizer can save it.
 *
 * @package ThemeFlex
 * @since 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'WP_Customize_Control' ) ) return;

/**
 * Class ThemeFlex_Skin_Swatch_Control
 */
class ThemeFlex_Skin_Swatch_Control extends WP_Customize_Control {

	/** @var string Control type identifier. */
	public $type = 'tf_skin_swatch';

	/** @var array All registered skins passed from the Skin Manager. */
	public $skins = array();

	/**
	 * Enqueue control-specific scripts and styles (called once in Customizer).
	 */
	public function enqueue() {
		// Inline — no external file needed for this lightweight control.
	}

	/**
	 * Pass extra properties to JS (not strictly needed for refresh transport).
	 */
	public function to_json() {
		parent::to_json();
		$this->json['skins'] = $this->skins;
	}

	/**
	 * Render the control markup.
	 */
	public function render_content() {
		$active = $this->value();
		?>
		<style>
		.tf-skin-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:8px}
		.tf-skin-card{
			position:relative;border-radius:10px;overflow:hidden;cursor:pointer;
			border:2px solid transparent;transition:border-color .2s,box-shadow .2s;
			background:#1e293b;
		}
		.tf-skin-card.active{border-color:var(--tf-swatch,#ff5e2e);box-shadow:0 0 0 3px rgba(255,94,46,.2)}
		.tf-skin-card input[type="radio"]{position:absolute;opacity:0;pointer-events:none}
		.tf-skin-swatch-bar{height:6px;width:100%}
		.tf-skin-body{padding:8px 10px 10px}
		.tf-skin-name{font-size:12px;font-weight:700;color:#f1f5f9;margin-bottom:2px}
		.tf-skin-desc{font-size:10px;color:#64748b;line-height:1.4}
		.tf-skin-dots{display:flex;gap:4px;margin-bottom:6px}
		.tf-skin-dot{width:10px;height:10px;border-radius:50%}
		</style>

		<label class="customize-control-title"><?php echo esc_html( $this->label ); ?></label>
		<?php if ( $this->description ) : ?>
			<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
		<?php endif; ?>

		<div class="tf-skin-grid">
		<?php foreach ( $this->skins as $skin_id => $skin ) :
			$primary = isset( $skin['colors']['primary'] )      ? esc_attr( $skin['colors']['primary'] )      : '#ff5e2e';
			$accent  = isset( $skin['colors']['accent'] )       ? esc_attr( $skin['colors']['accent'] )       : '#00d4ff';
			$pd      = isset( $skin['colors']['primary_dark'] ) ? esc_attr( $skin['colors']['primary_dark'] ) : $primary;
			$is_active = ( $skin_id === $active );
		?>
			<label
				class="tf-skin-card<?php echo $is_active ? ' active' : ''; ?>"
				style="--tf-swatch:<?php echo $primary; ?>"
				title="<?php echo esc_attr( $skin['desc'] ?? $skin['name'] ); ?>"
			>
				<input
					type="radio"
					name="<?php echo esc_attr( $this->id ); ?>"
					value="<?php echo esc_attr( $skin_id ); ?>"
					<?php checked( $skin_id, $active ); ?>
					<?php $this->link(); ?>
				>
				<!-- 3-colour gradient bar representing the skin palette -->
				<div class="tf-skin-swatch-bar"
					 style="background:linear-gradient(90deg,<?php echo $pd; ?> 0%,<?php echo $primary; ?> 50%,<?php echo $accent; ?> 100%)">
				</div>
				<div class="tf-skin-body">
					<div class="tf-skin-dots">
						<span class="tf-skin-dot" style="background:<?php echo $primary; ?>"></span>
						<span class="tf-skin-dot" style="background:<?php echo $accent; ?>"></span>
						<span class="tf-skin-dot" style="background:<?php echo $pd; ?>"></span>
					</div>
					<div class="tf-skin-name"><?php echo esc_html( $skin['name'] ); ?></div>
					<div class="tf-skin-desc">
						<?php
						$desc = $skin['desc'] ?? '';
						// Trim description to ~55 chars for card readability
						echo esc_html( mb_strlen( $desc ) > 55 ? mb_substr( $desc, 0, 52 ) . '…' : $desc );
						?>
					</div>
				</div>
			</label>
		<?php endforeach; ?>
		</div>

		<script>
		(function(){
			var grid = document.querySelector('.tf-skin-grid');
			if (!grid) return;
			grid.addEventListener('change', function(e){
				if (e.target.type !== 'radio') return;
				grid.querySelectorAll('.tf-skin-card').forEach(function(c){
					c.classList.remove('active');
				});
				e.target.closest('.tf-skin-card').classList.add('active');
			});
		})();
		</script>
		<?php
	}
}
