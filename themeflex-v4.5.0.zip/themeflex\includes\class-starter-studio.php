<?php
/**
 * Starter Studio - Prebuilt Section Library
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ThemeFlex_Starter_Studio {

	/**
	 * Initialize
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_studio_page' ), 20 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'wp_ajax_sf_get_sections', array( __CLASS__, 'ajax_get_sections' ) );
		add_action( 'wp_ajax_sf_get_section_preview', array( __CLASS__, 'ajax_get_section_preview' ) );
		add_action( 'elementor/editor/footer', array( __CLASS__, 'render_elementor_panel' ) );
	}

	/**
	 * Register admin page
	 */
	public static function register_studio_page() {
		add_submenu_page(
			'themeflex-dashboard',
			esc_html__( 'Starter Studio', 'themeflex' ),
			esc_html__( 'Starter Studio', 'themeflex' ),
			'manage_options',
			'themeflex-studio',
			array( __CLASS__, 'render_page' ),
			5
		);
	}

	/**
	 * Enqueue assets
	 */
	public static function enqueue_assets( $hook ) {
		if ( 'themeflex_page_themeflex-studio' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'sf-starter-studio',
			THEMEFLEX_URL . '/assets/css/starter-studio.css',
			array(),
			THEMEFLEX_VERSION
		);

		wp_enqueue_script(
			'sf-starter-studio',
			THEMEFLEX_URL . '/assets/js/starter-studio.js',
			array( 'jquery' ),
			THEMEFLEX_VERSION,
			true
		);

		wp_localize_script(
			'sf-starter-studio',
			'sfStarterStudio',
			array(
				'nonce'     => wp_create_nonce( 'sf_starter_studio_nonce' ),
				'ajaxurl'   => admin_url( 'admin-ajax.php' ),
				'themePath' => THEMEFLEX_URL,
			)
		);
	}

	/**
	 * Get all sections from directory
	 */
	public static function get_sections() {
		$sections_dir = THEMEFLEX_DIR . '/starter-studio/';
		$sections     = array();

		if ( ! is_dir( $sections_dir ) ) {
			return $sections;
		}

		$files = scandir( $sections_dir );

		if ( ! $files ) {
			return $sections;
		}

		foreach ( $files as $file ) {
			if ( '.json' !== substr( $file, -5 ) ) {
				continue;
			}

			$file_path = $sections_dir . $file;
			$content   = file_get_contents( $file_path );

			if ( ! $content ) {
				continue;
			}

			$section = json_decode( $content, true );

			if ( $section && isset( $section['id'], $section['title'], $section['category'] ) ) {
				$sections[] = $section;
			}
		}

		return $sections;
	}

	/**
	 * Get sections grouped by category
	 */
	public static function get_sections_by_category() {
		$sections = self::get_sections();
		$grouped  = array();

		foreach ( $sections as $section ) {
			$category = isset( $section['category'] ) ? $section['category'] : 'Other';

			if ( ! isset( $grouped[ $category ] ) ) {
				$grouped[ $category ] = array();
			}

			$grouped[ $category ][] = $section;
		}

		return $grouped;
	}

	/**
	 * AJAX: Get sections
	 */
	public static function ajax_get_sections() {
		check_ajax_referer( 'sf_starter_studio_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Insufficient permissions' );
		}

		$sections = self::get_sections_by_category();

		wp_send_json_success( $sections );
	}

	/**
	 * AJAX: Get section preview
	 */
	public static function ajax_get_section_preview() {
		check_ajax_referer( 'sf_starter_studio_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Insufficient permissions' );
		}

		$section_id = isset( $_POST['section_id'] ) ? sanitize_text_field( wp_unslash( $_POST['section_id'] ) ) : '';

		if ( ! $section_id ) {
			wp_send_json_error( 'Invalid section ID' );
		}

		$sections_dir = THEMEFLEX_DIR . '/starter-studio/';
		$file_path    = $sections_dir . $section_id . '.json';

		if ( ! file_exists( $file_path ) ) {
			wp_send_json_error( 'Section not found' );
		}

		$content = file_get_contents( $file_path );
		$section = json_decode( $content, true );

		if ( ! $section ) {
			wp_send_json_error( 'Invalid section data' );
		}

		wp_send_json_success( $section );
	}

	/**
	 * Render Elementor editor panel
	 */
	public static function render_elementor_panel() {
		if ( ! class_exists( '\Elementor\Plugin' ) ) {
			return;
		}

		$sections = self::get_sections_by_category();
		?>
		<script type="text/template" id="tmpl-sf-starter-studio-panel">
			<div id="sf-starter-studio-panel" class="sf-starter-studio-panel elementor-panel-category">
				<div class="sf-studio-panel-header">
					<h3><?php esc_html_e( 'Starter Studio', 'themeflex' ); ?></h3>
					<p class="sf-studio-panel-description"><?php esc_html_e( 'Drag and drop pre-designed sections into your page', 'themeflex' ); ?></p>
				</div>

				<div class="sf-studio-filter-tabs">
					<button class="sf-studio-tab-btn active" data-tab="all"><?php esc_html_e( 'All', 'themeflex' ); ?></button>
					<?php
					$categories = array_keys( $sections );
					foreach ( $categories as $category ) :
						$category_slug = sanitize_html_class( $category );
						?>
						<button class="sf-studio-tab-btn" data-tab="<?php echo esc_attr( $category_slug ); ?>">
							<?php echo esc_html( $category ); ?>
						</button>
					<?php endforeach; ?>
				</div>

				<div class="sf-studio-sections-grid">
					<?php
					foreach ( $sections as $category => $category_sections ) :
						$category_slug = sanitize_html_class( $category );
						foreach ( $category_sections as $section ) :
							$thumbnail = isset( $section['thumbnail'] ) ? esc_attr( $section['thumbnail'] ) : '';
							$title      = isset( $section['title'] ) ? esc_html( $section['title'] ) : '';
							$description = isset( $section['description'] ) ? esc_html( $section['description'] ) : '';
							$section_id = isset( $section['id'] ) ? esc_attr( $section['id'] ) : '';
							?>
							<div class="sf-studio-section-card" data-section-id="<?php echo esc_attr( $section_id ); ?>" data-category="<?php echo esc_attr( $category_slug ); ?>">
								<?php if ( $thumbnail ) : ?>
									<div class="sf-studio-thumbnail">
										<img src="<?php echo esc_url( $thumbnail ); ?>" alt="<?php echo esc_attr( $title ); ?>">
										<div class="sf-studio-card-overlay">
											<button class="sf-studio-btn-preview" title="<?php esc_attr_e( 'Preview', 'themeflex' ); ?>">
												<span class="dashicons dashicons-visibility"></span>
											</button>
											<button class="sf-studio-btn-insert" title="<?php esc_attr_e( 'Insert', 'themeflex' ); ?>">
												<span class="dashicons dashicons-plus-alt2"></span>
											</button>
										</div>
									</div>
								<?php endif; ?>
								<div class="sf-studio-card-content">
									<h4><?php echo esc_html( $title ); ?></h4>
									<?php if ( $description ) : ?>
										<p><?php echo esc_html( $description ); ?></p>
									<?php endif; ?>
								</div>
							</div>
						<?php endforeach; ?>
					<?php endforeach; ?>
				</div>
			</div>
		</script>
		<?php
	}

	/**
	 * Render admin page
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions', 'themeflex' ) );
		}

		$sections = self::get_sections_by_category();
		?>
		<div class="wrap sf-starter-studio-page">
			<div class="sf-page-header">
				<h1><?php esc_html_e( 'Starter Studio', 'themeflex' ); ?></h1>
				<p><?php esc_html_e( 'Browse and insert pre-designed sections into your Elementor pages', 'themeflex' ); ?></p>
			</div>

			<div class="sf-studio-filter-container">
				<button class="sf-studio-tab-btn active" data-filter="all"><?php esc_html_e( 'All Sections', 'themeflex' ); ?></button>
				<?php
				$categories = array_keys( $sections );
				foreach ( $categories as $category ) :
					$category_slug = sanitize_html_class( $category );
					$count         = count( $sections[ $category ] );
					?>
					<button class="sf-studio-tab-btn" data-filter="<?php echo esc_attr( $category_slug ); ?>">
						<?php echo esc_html( $category ); ?> <span class="count"><?php echo intval( $count ); ?></span>
					</button>
				<?php endforeach; ?>
			</div>

			<div class="sf-studio-grid">
				<?php
				foreach ( $sections as $category => $category_sections ) :
					$category_slug = sanitize_html_class( $category );
					foreach ( $category_sections as $section ) :
						$thumbnail    = isset( $section['thumbnail'] ) ? esc_attr( $section['thumbnail'] ) : '';
						$title        = isset( $section['title'] ) ? esc_html( $section['title'] ) : '';
						$description  = isset( $section['description'] ) ? esc_html( $section['description'] ) : '';
						$section_id   = isset( $section['id'] ) ? esc_attr( $section['id'] ) : '';
						$section_json = wp_json_encode( isset( $section['section'] ) ? $section['section'] : array() );
						?>
						<div class="sf-studio-item" data-category="<?php echo esc_attr( $category_slug ); ?>">
							<div class="sf-studio-item-inner">
								<?php if ( $thumbnail ) : ?>
									<div class="sf-studio-preview-image">
										<img src="<?php echo esc_url( $thumbnail ); ?>" alt="<?php echo esc_attr( $title ); ?>">
									</div>
								<?php endif; ?>
								<div class="sf-studio-item-content">
									<h3><?php echo esc_html( $title ); ?></h3>
									<?php if ( $description ) : ?>
										<p><?php echo esc_html( $description ); ?></p>
									<?php endif; ?>
									<div class="sf-studio-item-actions">
										<button class="button sf-studio-preview-btn" data-section-id="<?php echo esc_attr( $section_id ); ?>">
											<?php esc_html_e( 'Preview', 'themeflex' ); ?>
										</button>
										<button class="button button-primary sf-studio-copy-btn" data-section-json="<?php echo esc_attr( $section_json ); ?>">
											<?php esc_html_e( 'Copy JSON', 'themeflex' ); ?>
										</button>
									</div>
								</div>
							</div>
						</div>
					<?php endforeach; ?>
				<?php endforeach; ?>
			</div>
		</div>

		<!-- Preview Modal -->
		<div id="sf-studio-preview-modal" class="sf-modal" style="display: none;">
			<div class="sf-modal-content">
				<span class="sf-modal-close">&times;</span>
				<div class="sf-modal-body">
					<div class="sf-preview-loading"><?php esc_html_e( 'Loading preview...', 'themeflex' ); ?></div>
				</div>
			</div>
		</div>

		<style>
			.sf-modal {
				display: none;
				position: fixed;
				z-index: 99999;
				left: 0;
				top: 0;
				width: 100%;
				height: 100%;
				background-color: rgba(0, 0, 0, 0.8);
			}
			.sf-modal-content {
				background-color: #fff;
				margin: 5% auto;
				padding: 0;
				width: 80%;
				max-width: 1200px;
				border-radius: 8px;
				box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
				position: relative;
			}
			.sf-modal-close {
				color: #aaa;
				float: right;
				font-size: 28px;
				font-weight: bold;
				cursor: pointer;
				padding: 10px 20px;
				display: block;
			}
			.sf-modal-close:hover {
				color: #000;
			}
			.sf-modal-body {
				padding: 30px;
				max-height: 70vh;
				overflow-y: auto;
			}
		</style>
		<?php
	}
}
