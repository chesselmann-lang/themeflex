<?php
/**
 * Theme Dashboard
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ThemeFlex_Theme_Dashboard {

	/**
	 * Initialize
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_dashboard_page' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_notices', array( __CLASS__, 'welcome_notice' ) );
		add_action( 'wp_ajax_sf_dismiss_welcome_notice', array( __CLASS__, 'ajax_dismiss_notice' ) );
	}

	/**
	 * Register dashboard page
	 */
	public static function register_dashboard_page() {
		add_menu_page(
			esc_html__( 'ThemeFlex', 'themeflex' ),
			esc_html__( 'ThemeFlex', 'themeflex' ),
			'manage_options',
			'themeflex-dashboard',
			array( __CLASS__, 'render_dashboard' ),
			'dashicons-welcome-learn-more',
			59
		);
	}

	/**
	 * Enqueue dashboard assets
	 */
	public static function enqueue_assets( $hook ) {
		if ( 'toplevel_page_themeflex-dashboard' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'sf-dashboard',
			THEMEFLEX_URL . '/assets/css/dashboard.css',
			array(),
			THEMEFLEX_VERSION
		);

		wp_enqueue_script(
			'sf-dashboard',
			THEMEFLEX_URL . '/assets/js/dashboard.js',
			array( 'jquery' ),
			THEMEFLEX_VERSION,
			true
		);

		wp_localize_script(
			'sf-dashboard',
			'sfDashboard',
			array(
				'nonce' => wp_create_nonce( 'sf_dashboard_nonce' ),
			)
		);
	}

	/**
	 * Render dashboard
	 */
	public static function render_dashboard() {
		?>
		<div class="wrap sf-dashboard-page">
			<div class="sf-dashboard-header">
				<h1><?php esc_html_e( 'Welcome to ThemeFlex', 'themeflex' ); ?></h1>
				<p><?php esc_html_e( 'A powerful WordPress theme for creative professionals', 'themeflex' ); ?></p>
			</div>

			<div class="sf-dashboard-content">
				<div class="sf-tabs-nav">
					<button class="sf-tab-btn active" data-tab="welcome"><?php esc_html_e( 'Welcome', 'themeflex' ); ?></button>
					<button class="sf-tab-btn" data-tab="getting-started"><?php esc_html_e( 'Getting Started', 'themeflex' ); ?></button>
					<button class="sf-tab-btn" data-tab="plugins"><?php esc_html_e( 'Plugins', 'themeflex' ); ?></button>
					<button class="sf-tab-btn" data-tab="system"><?php esc_html_e( 'System Info', 'themeflex' ); ?></button>
					<button class="sf-tab-btn" data-tab="changelog"><?php esc_html_e( 'Changelog', 'themeflex' ); ?></button>
					<button class="sf-tab-btn" data-tab="support"><?php esc_html_e( 'Support', 'themeflex' ); ?></button>
				</div>

				<!-- Welcome Tab -->
				<div id="welcome" class="sf-tab-content active">
					<h2><?php esc_html_e( 'Theme Information', 'themeflex' ); ?></h2>
					<div class="sf-info-card">
						<p><?php esc_html_e( 'Theme Name:', 'themeflex' ); ?> <strong>ThemeFlex</strong></p>
						<p><?php esc_html_e( 'Version:', 'themeflex' ); ?> <strong><?php echo esc_html( THEMEFLEX_VERSION ); ?></strong></p>
						<p><?php esc_html_e( 'Author:', 'themeflex' ); ?> <strong>ThemeFlex Team</strong></p>
						<p><?php esc_html_e( 'License:', 'themeflex' ); ?> <strong>GPL v2 or later</strong></p>
					</div>

					<h3><?php esc_html_e( 'Quick Links', 'themeflex' ); ?></h3>
					<ul class="sf-quick-links">
						<li><a href="<?php echo esc_url( admin_url( 'customize.php' ) ); ?>" class="button"><?php esc_html_e( 'Customize Theme', 'themeflex' ); ?></a></li>
						<li><a href="<?php echo esc_url( admin_url( 'themes.php?page=themeflex-demo-importer' ) ); ?>" class="button"><?php esc_html_e( 'Import Demo', 'themeflex' ); ?></a></li>
						<li><a href="<?php echo esc_url( admin_url( 'nav-menus.php' ) ); ?>" class="button"><?php esc_html_e( 'Manage Menus', 'themeflex' ); ?></a></li>
						<li><a href="<?php echo esc_url( admin_url( 'widgets.php' ) ); ?>" class="button"><?php esc_html_e( 'Manage Widgets', 'themeflex' ); ?></a></li>
					</ul>
				</div>

				<!-- Getting Started Tab -->
				<div id="getting-started" class="sf-tab-content">
					<h2><?php esc_html_e( 'Getting Started Setup Guide', 'themeflex' ); ?></h2>

					<div class="sf-setup-steps">
						<div class="sf-setup-step">
							<div class="sf-step-number">1</div>
							<div class="sf-step-content">
								<h3><?php esc_html_e( 'Install Recommended Plugins', 'themeflex' ); ?></h3>
								<p><?php esc_html_e( 'Install Elementor and other recommended plugins for the best experience.', 'themeflex' ); ?></p>
								<a href="<?php echo esc_url( admin_url( 'admin.php?page=tgmpa-install-plugins' ) ); ?>" class="button"><?php esc_html_e( 'Install Plugins', 'themeflex' ); ?></a>
							</div>
						</div>

						<div class="sf-setup-step">
							<div class="sf-step-number">2</div>
							<div class="sf-step-content">
								<h3><?php esc_html_e( 'Import Demo Content', 'themeflex' ); ?></h3>
								<p><?php esc_html_e( 'Choose from multiple demo templates to get started quickly.', 'themeflex' ); ?></p>
								<a href="<?php echo esc_url( admin_url( 'themes.php?page=themeflex-demo-importer' ) ); ?>" class="button"><?php esc_html_e( 'Import Demo', 'themeflex' ); ?></a>
							</div>
						</div>

						<div class="sf-setup-step">
							<div class="sf-step-number">3</div>
							<div class="sf-step-content">
								<h3><?php esc_html_e( 'Setup Homepage', 'themeflex' ); ?></h3>
								<p><?php esc_html_e( 'Create and set a static homepage for your site.', 'themeflex' ); ?></p>
								<a href="<?php echo esc_url( admin_url( 'customize.php?autofocus[section]=static_front_page' ) ); ?>" class="button"><?php esc_html_e( 'Setup Homepage', 'themeflex' ); ?></a>
							</div>
						</div>

						<div class="sf-setup-step">
							<div class="sf-step-number">4</div>
							<div class="sf-step-content">
								<h3><?php esc_html_e( 'Customize Theme', 'themeflex' ); ?></h3>
								<p><?php esc_html_e( 'Customize colors, fonts, layouts, and more from the Theme Customizer.', 'themeflex' ); ?></p>
								<a href="<?php echo esc_url( admin_url( 'customize.php' ) ); ?>" class="button button-primary"><?php esc_html_e( 'Go to Customizer', 'themeflex' ); ?></a>
							</div>
						</div>
					</div>
				</div>

				<!-- Plugins Tab -->
				<div id="plugins" class="sf-tab-content">
					<h2><?php esc_html_e( 'Recommended Plugins', 'themeflex' ); ?></h2>
					<?php self::render_plugins_status(); ?>
				</div>

				<!-- System Info Tab -->
				<div id="system" class="sf-tab-content">
					<h2><?php esc_html_e( 'System Information', 'themeflex' ); ?></h2>
					<?php self::render_system_info(); ?>
				</div>

				<!-- Changelog Tab -->
				<div id="changelog" class="sf-tab-content">
					<h2><?php esc_html_e( 'Changelog', 'themeflex' ); ?></h2>
					<?php self::render_changelog(); ?>
				</div>

				<!-- Support Tab -->
				<div id="support" class="sf-tab-content">
					<h2><?php esc_html_e( 'Support & Resources', 'themeflex' ); ?></h2>
					<div class="sf-support-grid">
						<div class="sf-support-card">
							<h3><?php esc_html_e( 'Documentation', 'themeflex' ); ?></h3>
							<p><?php esc_html_e( 'Read our comprehensive documentation and guides.', 'themeflex' ); ?></p>
							<a href="#" target="_blank" class="button"><?php esc_html_e( 'View Docs', 'themeflex' ); ?></a>
						</div>
						<div class="sf-support-card">
							<h3><?php esc_html_e( 'Support Forum', 'themeflex' ); ?></h3>
							<p><?php esc_html_e( 'Get help from our support community.', 'themeflex' ); ?></p>
							<a href="#" target="_blank" class="button"><?php esc_html_e( 'Visit Forum', 'themeflex' ); ?></a>
						</div>
						<div class="sf-support-card">
							<h3><?php esc_html_e( 'Video Tutorials', 'themeflex' ); ?></h3>
							<p><?php esc_html_e( 'Learn from video tutorials and walkthroughs.', 'themeflex' ); ?></p>
							<a href="#" target="_blank" class="button"><?php esc_html_e( 'Watch Videos', 'themeflex' ); ?></a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render plugins status
	 */
	private static function render_plugins_status() {
		$recommended = array(
			'elementor' => array(
				'name' => 'Elementor Page Builder',
				'file' => 'elementor/elementor.php',
			),
			'woocommerce' => array(
				'name' => 'WooCommerce',
				'file' => 'woocommerce/woocommerce.php',
			),
			'rank-math-seo' => array(
				'name' => 'Rank Math SEO',
				'file' => 'seo-by-rank-math/rank-math.php',
			),
			'contact-form-7' => array(
				'name' => 'Contact Form 7',
				'file' => 'contact-form-7/wp-contact-form-7.php',
			),
		);

		echo '<table class="wp-list-table striped">';
		echo '<thead><tr><th>' . esc_html__( 'Plugin', 'themeflex' ) . '</th><th>' . esc_html__( 'Status', 'themeflex' ) . '</th></tr></thead>';
		echo '<tbody>';

		foreach ( $recommended as $slug => $plugin ) {
			$active = is_plugin_active( $plugin['file'] );
			$status = $active ? '<span style="color: green;">✓ ' . esc_html__( 'Active', 'themeflex' ) . '</span>' : '<span style="color: orange;">✗ ' . esc_html__( 'Inactive', 'themeflex' ) . '</span>';

			echo '<tr>';
			echo '<td>' . esc_html( $plugin['name'] ) . '</td>';
			echo '<td>' . wp_kses_post( $status ) . '</td>';
			echo '</tr>';
		}

		echo '</tbody>';
		echo '</table>';
	}

	/**
	 * Render system info
	 */
	private static function render_system_info() {
		?>
		<table class="wp-list-table striped">
			<tbody>
				<tr>
					<td><?php esc_html_e( 'PHP Version', 'themeflex' ); ?></td>
					<td><strong><?php echo esc_html( phpversion() ); ?></strong></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'WordPress Version', 'themeflex' ); ?></td>
					<td><strong><?php echo esc_html( get_bloginfo( 'version' ) ); ?></strong></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Theme Version', 'themeflex' ); ?></td>
					<td><strong><?php echo esc_html( THEMEFLEX_VERSION ); ?></strong></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Memory Limit', 'themeflex' ); ?></td>
					<td><strong><?php echo esc_html( WP_MEMORY_LIMIT ); ?></strong></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Max Upload Size', 'themeflex' ); ?></td>
					<td><strong><?php echo esc_html( size_format( wp_max_upload_size() ) ); ?></strong></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Active Plugins', 'themeflex' ); ?></td>
					<td><strong><?php echo count( get_option( 'active_plugins' ) ); ?></strong></td>
				</tr>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Render changelog
	 */
	private static function render_changelog() {
		?>
		<div class="sf-changelog">
			<h3>Version 1.0.0</h3>
			<ul>
				<li><?php esc_html_e( 'Initial release', 'themeflex' ); ?></li>
				<li><?php esc_html_e( '6 Elementor widgets', 'themeflex' ); ?></li>
				<li><?php esc_html_e( 'Parallax and animation system', 'themeflex' ); ?></li>
				<li><?php esc_html_e( 'Video background support', 'themeflex' ); ?></li>
				<li><?php esc_html_e( 'Custom icon library', 'themeflex' ); ?></li>
				<li><?php esc_html_e( 'Advanced header features', 'themeflex' ); ?></li>
				<li><?php esc_html_e( 'Demo content importer', 'themeflex' ); ?></li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Welcome notice
	 */
	public static function welcome_notice() {
		if ( get_option( 'sf_welcome_notice_dismissed' ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( 'appearance_page_themeflex-dashboard' === get_current_screen()->id ) {
			return;
		}

		?>
		<div class="notice notice-info is-dismissible" id="sf-welcome-notice">
			<p>
				<strong><?php esc_html_e( 'Welcome to ThemeFlex!', 'themeflex' ); ?></strong>
				<?php esc_html_e( 'Set up your new theme with our quick start guide.', 'themeflex' ); ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=themeflex-dashboard' ) ); ?>" class="button button-small">
					<?php esc_html_e( 'Get Started', 'themeflex' ); ?>
				</a>
			</p>
		</div>

		<script>
			jQuery(document).ready(function($) {
				$('#sf-welcome-notice').on('click', '.notice-dismiss', function() {
					$.post(ajaxurl, {
						action: 'sf_dismiss_welcome_notice',
						nonce: '<?php echo wp_create_nonce( 'sf_dismiss_notice' ); ?>'
					});
				});
			});
		</script>
		<?php
	}

	/**
	 * AJAX dismiss notice
	 */
	public static function ajax_dismiss_notice() {
		check_ajax_referer( 'sf_dismiss_notice', 'nonce' );
		update_option( 'sf_welcome_notice_dismissed', 1 );
		wp_send_json_success();
	}
}

// Initialize
ThemeFlex_Theme_Dashboard::init();
