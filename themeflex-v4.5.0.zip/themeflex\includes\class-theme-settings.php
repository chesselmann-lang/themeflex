<?php
/**
 * Theme Settings Admin Page
 * Central hub: AI Key, Performance switches, Analytics IDs, White-Label, Support.
 *
 * @package ThemeFlex
 * @since   1.1.0
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Theme_Settings {

    private static ?self $instance = null;
    const OPTION = 'sf_theme_settings';

    public static function instance(): self {
        if (is_null(self::$instance)) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu',    [$this, 'add_menu']);
        add_action('admin_init',    [$this, 'register_settings']);
        add_action('admin_notices', [$this, 'save_notice']);
        add_action('wp_head',       [$this, 'output_settings_to_head'], 8);
    }

    public function add_menu(): void {
        add_menu_page(
            esc_html__('ThemeFlex','themeflex'),
            esc_html__('ThemeFlex','themeflex'),
            'manage_options',
            'themeflex-settings',
            [$this, 'render_page'],
            'data:image/svg+xml;base64,'.base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#FF5E2E"><circle cx="12" cy="12" r="10"/><path d="M8 12l3 3 5-5" stroke="#fff" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>'),
            58
        );
        add_submenu_page('themeflex-settings', __('Settings','themeflex'), __('Settings','themeflex'), 'manage_options', 'themeflex-settings', [$this, 'render_page']);
        add_submenu_page('themeflex-settings', __('Demo Importer','themeflex'), __('Demo Importer','themeflex'), 'manage_options', 'sfa-demo-importer', null);
        add_submenu_page('themeflex-settings', __('Theme Setup','themeflex'), __('Theme Setup','themeflex'), 'manage_options', 'themeflex-welcome', null);
        add_submenu_page('themeflex-settings', __('White Label','themeflex'), __('White Label','themeflex'), 'manage_options', 'sfa-white-label', null);
    }

    public function register_settings(): void {
        register_setting('sf_settings_group', self::OPTION, ['sanitize_callback' => [$this, 'sanitize']]);
    }

    public function sanitize(array $input): array {
        $clean = [];
        $text_fields = ['openai_api_key','ga_id','fb_pixel','maps_key','recaptcha_key','recaptcha_secret','support_email'];
        foreach ($text_fields as $f) {
            $clean[$f] = sanitize_text_field($input[$f] ?? '');
        }
        $bool_fields = ['enable_og','enable_schema','enable_critical_css','enable_preloader','enable_cookie_notice','maintenance_mode','coming_soon_mode'];
        foreach ($bool_fields as $f) {
            $clean[$f] = !empty($input[$f]);
        }
        $clean['coming_soon_text'] = wp_kses_post($input['coming_soon_text'] ?? '');
        $clean['cookie_text']      = sanitize_textarea_field($input['cookie_text'] ?? '');
        $clean['openai_model']     = sanitize_text_field($input['openai_model'] ?? 'gpt-4o-mini');
        return $clean;
    }

    private function get(string $key, $default = '') {
        static $settings = null;
        if (null === $settings) $settings = get_option(self::OPTION, []);
        return $settings[$key] ?? $default;
    }

    public function save_notice(): void {
        if (isset($_GET['settings-updated']) && 'themeflex-settings' === $_GET['page']) {
            echo '<div class="notice notice-success is-dismissible"><p>'.esc_html__('ThemeFlex settings saved.','themeflex').'</p></div>';
        }
    }

    public function render_page(): void {
        $tabs = [
            'ai'          => ['🤖', __('AI Assistant','themeflex')],
            'analytics'   => ['📊', __('Analytics','themeflex')],
            'performance' => ['⚡', __('Performance','themeflex')],
            'seo'         => ['🔍', __('SEO','themeflex')],
            'maintenance' => ['🔧', __('Maintenance','themeflex')],
            'support'     => ['💬', __('Support','themeflex')],
        ];
        $active_tab = sanitize_key($_GET['tab'] ?? 'ai');
        ?>
        <div class="wrap sf-settings-wrap" style="font-family:-apple-system,BlinkMacSystemFont,'Inter',sans-serif;">
            <!-- Header -->
            <div style="background:linear-gradient(135deg,#06021D,#1a1f29);border-radius:12px;padding:28px 32px;margin-bottom:24px;display:flex;align-items:center;justify-content:space-between;">
                <div style="display:flex;align-items:center;gap:14px;">
                    <div style="width:44px;height:44px;border-radius:10px;background:linear-gradient(135deg,#FF5E2E,#ED4C1C);display:flex;align-items:center;justify-content:center;font-size:22px;">🌟</div>
                    <div>
                        <h1 style="margin:0;color:#fff;font-size:1.3rem;font-weight:800;"><?php esc_html_e('ThemeFlex','themeflex'); ?></h1>
                        <p style="margin:0;color:rgba(255,255,255,.55);font-size:13px;"><?php printf(esc_html__('Version %s — The most complete WordPress theme ecosystem','themeflex'), wp_get_theme()->get('Version')); ?></p>
                    </div>
                </div>
                <div style="display:flex;gap:10px;">
                    <a href="<?php echo esc_url(admin_url('customize.php')); ?>" class="button" style="background:rgba(255,255,255,.1);color:#fff;border-color:rgba(255,255,255,.2);"><?php esc_html_e('Customizer','themeflex'); ?></a>
                    <a href="<?php echo esc_url(admin_url('themes.php?page=themeflex-welcome')); ?>" class="button button-primary"><?php esc_html_e('Theme Setup','themeflex'); ?></a>
                </div>
            </div>
            <!-- Tabs -->
            <nav style="display:flex;gap:2px;margin-bottom:20px;flex-wrap:wrap;">
                <?php foreach ($tabs as $tab_id => [$icon, $label]): ?>
                <a href="<?php echo esc_url(admin_url('admin.php?page=themeflex-settings&tab='.$tab_id)); ?>"
                   style="padding:9px 18px;border-radius:8px;font-size:13px;font-weight:600;text-decoration:none;transition:all .15s;<?php echo $active_tab===$tab_id?'background:#FF5E2E;color:#fff;':'background:#f8fafc;color:#374151;border:1px solid #e5e7eb;'; ?>">
                    <?php echo $icon; ?> <?php echo esc_html($label); ?>
                </a>
                <?php endforeach; ?>
            </nav>
            <!-- Form -->
            <form method="post" action="options.php" style="background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:32px;">
                <?php settings_fields('sf_settings_group'); ?>
                <?php if ('ai' === $active_tab): ?>
                    <h2 style="margin-top:0;"><?php esc_html_e('AI Content Assistant','themeflex'); ?></h2>
                    <p style="color:#64748b;margin-bottom:24px;"><?php esc_html_e('Connect your OpenAI account to enable the AI Content Assistant widget and AI-powered features.','themeflex'); ?></p>
                    <?php $this->field('openai_api_key', __('OpenAI API Key','themeflex'), 'password', '', __('Your sk-... key. Get one at platform.openai.com/api-keys','themeflex')); ?>
                    <?php $this->select_field('openai_model', __('Default Model','themeflex'), ['gpt-4o-mini'=>'GPT-4o Mini (Fast & Cheap)','gpt-4o'=>'GPT-4o (Best Quality)','gpt-3.5-turbo'=>'GPT-3.5 Turbo (Legacy)']); ?>
                    <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:10px;padding:16px;margin-top:20px;">
                        <strong style="color:#1e40af;">💡 <?php esc_html_e('Cost Estimate','themeflex'); ?></strong><br>
                        <span style="font-size:13px;color:#374151;"><?php esc_html_e('GPT-4o Mini: ~$0.0003 per request · GPT-4o: ~$0.01 per request. Very affordable for typical website use.','themeflex'); ?></span>
                    </div>

                <?php elseif ('analytics' === $active_tab): ?>
                    <h2 style="margin-top:0;"><?php esc_html_e('Analytics & Tracking','themeflex'); ?></h2>
                    <?php $this->field('ga_id', __('Google Analytics 4 Measurement ID','themeflex'), 'text', 'G-XXXXXXXXXX', __('Leave empty to disable. Format: G-XXXXXXXXXX','themeflex')); ?>
                    <?php $this->field('fb_pixel', __('Meta (Facebook) Pixel ID','themeflex'), 'text', '123456789', __('Your Facebook Pixel ID. Leave empty to disable.','themeflex')); ?>
                    <?php $this->field('maps_key', __('Google Maps API Key','themeflex'), 'text', '', __('Required for the Google Maps Elementor widget.','themeflex')); ?>
                    <?php $this->field('recaptcha_key', __('reCAPTCHA v3 Site Key','themeflex'), 'text', '', __('For form spam protection.','themeflex')); ?>
                    <?php $this->field('recaptcha_secret', __('reCAPTCHA v3 Secret Key','themeflex'), 'password', ''); ?>

                <?php elseif ('performance' === $active_tab): ?>
                    <h2 style="margin-top:0;"><?php esc_html_e('Performance','themeflex'); ?></h2>
                    <?php $this->checkbox('enable_critical_css', __('Inline Critical CSS','themeflex'), __('Improves Largest Contentful Paint (LCP) by inlining above-the-fold styles.','themeflex'), true); ?>
                    <?php $this->checkbox('enable_preloader', __('Enable Page Preloader','themeflex'), __('Shows a loading animation until the page is ready.','themeflex'), true); ?>

                <?php elseif ('seo' === $active_tab): ?>
                    <h2 style="margin-top:0;"><?php esc_html_e('SEO','themeflex'); ?></h2>
                    <div style="background:#fef9c3;border:1px solid #fef08a;border-radius:10px;padding:14px;margin-bottom:20px;font-size:13px;color:#713f12;">
                        <?php esc_html_e('If you use Yoast SEO, RankMath, or AIOSEO — disable these options to avoid duplicate meta tags.','themeflex'); ?>
                    </div>
                    <?php $this->checkbox('enable_og', __('Open Graph + Twitter Card Tags','themeflex'), __('Adds og: and twitter: meta tags for better social sharing.','themeflex'), true); ?>
                    <?php $this->checkbox('enable_schema', __('Schema.org JSON-LD','themeflex'), __('Adds structured data for Google rich results (Article, Product, BreadcrumbList, FAQPage, etc.).','themeflex'), true); ?>

                <?php elseif ('maintenance' === $active_tab): ?>
                    <h2 style="margin-top:0;"><?php esc_html_e('Maintenance','themeflex'); ?></h2>
                    <?php $this->checkbox('maintenance_mode', __('Enable Maintenance Mode','themeflex'), __('Shows a maintenance page to visitors. Admins can still access the site.','themeflex'), false); ?>
                    <?php $this->checkbox('coming_soon_mode', __('Enable Coming Soon Mode','themeflex'), __('Shows a coming soon page to non-logged-in visitors.','themeflex'), false); ?>
                    <?php $this->textarea('coming_soon_text', __('Coming Soon Message','themeflex'), __('We\'re launching soon! Stay tuned.','themeflex')); ?>
                    <?php $this->textarea('cookie_text', __('Cookie Notice Text','themeflex'), __('We use cookies to improve your experience.','themeflex')); ?>

                <?php elseif ('support' === $active_tab): ?>
                    <h2 style="margin-top:0;"><?php esc_html_e('Support & Resources','themeflex'); ?></h2>
                    <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:16px;">
                        <?php foreach ([
                            ['📖', __('Documentation','themeflex'), 'https://whatsdigital.de/themeflex/docs', __('Complete setup and usage guide','themeflex')],
                            ['🎫', __('Support Forum','themeflex'), 'https://themeforest.net/item/themeflex/support', __('Get help from our team','themeflex')],
                            ['🎬', __('Video Tutorials','themeflex'), 'https://youtube.com/@whatsdigital', __('Step-by-step video guides','themeflex')],
                            ['⭐', __('Rate the Theme','themeflex'), 'https://themeforest.net/downloads', __('Leave a 5-star review on ThemeForest','themeflex')],
                        ] as [$icon, $label, $url, $desc]):?>
                        <a href="<?php echo esc_url($url); ?>" target="_blank" style="display:flex;align-items:flex-start;gap:12px;padding:20px;background:#f8fafc;border:1px solid #e5e7eb;border-radius:10px;text-decoration:none;transition:all .2s;" onmouseover="this.style.borderColor='#FF5E2E'" onmouseout="this.style.borderColor='#e5e7eb'">
                            <span style="font-size:24px;"><?php echo $icon; ?></span>
                            <div><strong style="display:block;color:#1e293b;font-size:14px;"><?php echo esc_html($label); ?></strong><span style="font-size:12px;color:#64748b;"><?php echo esc_html($desc); ?></span></div>
                        </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <?php if ('support' !== $active_tab): ?>
                <?php submit_button(__('Save Settings','themeflex'), 'primary', 'submit', true, ['style'=>'background:linear-gradient(135deg,#FF5E2E,#ED4C1C);border-color:transparent;box-shadow:none;padding:10px 24px;font-size:14px;font-weight:700;']); ?>
                <?php endif; ?>
            </form>
        </div>
        <?php
    }

    private function field(string $key, string $label, string $type, string $placeholder = '', string $desc = ''): void {
        $val = $this->get($key, '');
        $name = self::OPTION.'['.$key.']';
        echo '<div style="margin-bottom:20px;">';
        echo '<label style="display:block;font-weight:700;color:#1e293b;margin-bottom:6px;">'.esc_html($label).'</label>';
        echo '<input type="'.esc_attr($type).'" name="'.esc_attr($name).'" value="'.esc_attr($val).'" placeholder="'.esc_attr($placeholder).'" style="width:100%;max-width:480px;padding:10px 14px;border:1px solid #e5e7eb;border-radius:8px;font-size:14px;" />';
        if ($desc) echo '<p style="margin:6px 0 0;font-size:12px;color:#64748b;">'.esc_html($desc).'</p>';
        echo '</div>';
    }

    private function select_field(string $key, string $label, array $choices): void {
        $val = $this->get($key, '');
        $name = self::OPTION.'['.$key.']';
        echo '<div style="margin-bottom:20px;">';
        echo '<label style="display:block;font-weight:700;color:#1e293b;margin-bottom:6px;">'.esc_html($label).'</label>';
        echo '<select name="'.esc_attr($name).'" style="padding:10px 14px;border:1px solid #e5e7eb;border-radius:8px;font-size:14px;min-width:240px;">';
        foreach ($choices as $v => $l) echo '<option value="'.esc_attr($v).'" '.selected($val,$v,false).'>'.esc_html($l).'</option>';
        echo '</select></div>';
    }

    private function checkbox(string $key, string $label, string $desc = '', bool $default = false): void {
        $val  = $this->get($key, $default);
        $name = self::OPTION.'['.$key.']';
        echo '<div style="display:flex;align-items:flex-start;gap:12px;margin-bottom:16px;padding:16px;background:#f8fafc;border:1px solid #e5e7eb;border-radius:10px;">';
        echo '<input type="checkbox" name="'.esc_attr($name).'" value="1" '.checked($val,true,false).' style="margin-top:2px;width:16px;height:16px;" id="'.esc_attr($key).'" />';
        echo '<label for="'.esc_attr($key).'" style="cursor:pointer;"><strong style="display:block;color:#1e293b;font-size:14px;">'.esc_html($label).'</strong><span style="font-size:12px;color:#64748b;">'.esc_html($desc).'</span></label>';
        echo '</div>';
    }

    private function textarea(string $key, string $label, string $placeholder = ''): void {
        $val  = $this->get($key, '');
        $name = self::OPTION.'['.$key.']';
        echo '<div style="margin-bottom:20px;">';
        echo '<label style="display:block;font-weight:700;color:#1e293b;margin-bottom:6px;">'.esc_html($label).'</label>';
        echo '<textarea name="'.esc_attr($name).'" rows="3" placeholder="'.esc_attr($placeholder).'" style="width:100%;padding:10px 14px;border:1px solid #e5e7eb;border-radius:8px;font-size:14px;font-family:inherit;">'.esc_textarea($val).'</textarea>';
        echo '</div>';
    }

    public function output_settings_to_head(): void {
        // Maintenance / Coming Soon
        if ($this->get('maintenance_mode') && !current_user_can('manage_options')) {
            wp_die(wp_kses_post($this->get('coming_soon_text', __('Site is under maintenance. Please check back soon.','themeflex'))), esc_html__('Maintenance','themeflex'), ['response'=>503]);
        }
        if ($this->get('coming_soon_mode') && !is_user_logged_in()) {
            // Redirect to coming soon page if one exists
            $cs_page = get_page_by_path('coming-soon');
            if ($cs_page && !is_page('coming-soon')) {
                wp_redirect(get_permalink($cs_page->ID)); exit;
            }
        }
    }
}

ThemeFlex_Theme_Settings::instance();

// Also sync option-based settings to get_option() for widgets
add_action('init', function() {
    $s = get_option(ThemeFlex_Theme_Settings::OPTION, []);
    if (!empty($s['openai_api_key']) && !get_option('themeflex_openai_api_key')) {
        update_option('themeflex_openai_api_key', $s['openai_api_key']);
    }
    if (!empty($s['maps_key']) && !get_option('themeflex_google_maps_api_key')) {
        update_option('themeflex_google_maps_api_key', $s['maps_key']);
    }
});
