<?php
/**
 * Video Background System
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ThemeFlex_Video_Background {

	/**
	 * Initialize
	 */
	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_scripts' ) );
		add_action( 'customize_register', array( __CLASS__, 'customize_register' ) );
	}

	/**
	 * Enqueue scripts and styles
	 */
	public static function enqueue_scripts() {
		wp_enqueue_script(
			'sf-video-background',
			THEMEFLEX_URL . '/assets/js/video-background.js',
			array(),
			THEMEFLEX_VERSION,
			true
		);
	}

	/**
	 * Customize register
	 */
	public static function customize_register( $wp_customize ) {
		// Video background section
		$wp_customize->add_section(
			'sf_video_background',
			array(
				'title' => esc_html__( 'Header Video Background', 'themeflex' ),
				'panel' => 'themeflex_settings',
			)
		);

		// Header video URL
		$wp_customize->add_setting(
			'header_video_url',
			array(
				'default' => '',
				'sanitize_callback' => 'esc_url_raw',
				'transport' => 'refresh',
			)
		);

		$wp_customize->add_control(
			'header_video_url',
			array(
				'label' => esc_html__( 'Header Video URL', 'themeflex' ),
				'description' => esc_html__( 'Supports YouTube, Vimeo, or self-hosted MP4 URLs', 'themeflex' ),
				'section' => 'sf_video_background',
				'type' => 'text',
			)
		);

		// Header video poster
		$wp_customize->add_setting(
			'header_video_poster',
			array(
				'default' => '',
				'sanitize_callback' => 'esc_url_raw',
				'transport' => 'refresh',
			)
		);

		$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				'header_video_poster',
				array(
					'label' => esc_html__( 'Poster Image (Mobile Fallback)', 'themeflex' ),
					'section' => 'sf_video_background',
				)
			)
		);

		// Header video autoplay
		$wp_customize->add_setting(
			'header_video_autoplay',
			array(
				'default' => true,
				'sanitize_callback' => 'rest_sanitize_boolean',
				'transport' => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'header_video_autoplay',
			array(
				'label' => esc_html__( 'Autoplay', 'themeflex' ),
				'section' => 'sf_video_background',
				'type' => 'checkbox',
			)
		);

		// Header video muted
		$wp_customize->add_setting(
			'header_video_muted',
			array(
				'default' => true,
				'sanitize_callback' => 'rest_sanitize_boolean',
				'transport' => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'header_video_muted',
			array(
				'label' => esc_html__( 'Muted', 'themeflex' ),
				'section' => 'sf_video_background',
				'type' => 'checkbox',
			)
		);

		// Header video loop
		$wp_customize->add_setting(
			'header_video_loop',
			array(
				'default' => true,
				'sanitize_callback' => 'rest_sanitize_boolean',
				'transport' => 'postMessage',
			)
		);

		$wp_customize->add_control(
			'header_video_loop',
			array(
				'label' => esc_html__( 'Loop', 'themeflex' ),
				'section' => 'sf_video_background',
				'type' => 'checkbox',
			)
		);
	}

	/**
	 * Render video background
	 *
	 * @param string $video_url Video URL
	 * @param string $poster_url Poster image URL
	 * @param array $args Additional arguments
	 */
	public static function render_video_background( $video_url = '', $poster_url = '', $args = array() ) {
		if ( empty( $video_url ) ) {
			$video_url = get_theme_mod( 'header_video_url' );
		}

		if ( empty( $poster_url ) ) {
			$poster_url = get_theme_mod( 'header_video_poster' );
		}

		if ( empty( $video_url ) ) {
			return;
		}

		$defaults = array(
			'autoplay' => get_theme_mod( 'header_video_autoplay', true ),
			'muted' => get_theme_mod( 'header_video_muted', true ),
			'loop' => get_theme_mod( 'header_video_loop', true ),
			'controls' => false,
			'class' => 'sf-video-background',
		);

		$args = wp_parse_args( $args, $defaults );

		// Detect video type
		$video_type = self::detect_video_type( $video_url );

		?>
		<div class="<?php echo esc_attr( $args['class'] ); ?>" data-video-type="<?php echo esc_attr( $video_type ); ?>">
			<?php if ( 'self-hosted' === $video_type ) : ?>
				<video
					autoplay="<?php echo esc_attr( $args['autoplay'] ? 'autoplay' : '' ); ?>"
					muted="<?php echo esc_attr( $args['muted'] ? 'muted' : '' ); ?>"
					loop="<?php echo esc_attr( $args['loop'] ? 'loop' : '' ); ?>"
					<?php echo ! $args['controls'] ? '' : 'controls'; ?>
					poster="<?php echo esc_url( $poster_url ); ?>"
					class="sf-video-element"
				>
					<source src="<?php echo esc_url( $video_url ); ?>" type="video/mp4">
					<?php esc_html_e( 'Your browser does not support the video tag.', 'themeflex' ); ?>
				</video>
			<?php elseif ( 'youtube' === $video_type ) : ?>
				<div class="sf-youtube-video" data-video-id="<?php echo esc_attr( self::extract_youtube_id( $video_url ) ); ?>"></div>
			<?php elseif ( 'vimeo' === $video_type ) : ?>
				<div class="sf-vimeo-video" data-video-id="<?php echo esc_attr( self::extract_vimeo_id( $video_url ) ); ?>"></div>
			<?php endif; ?>

			<?php if ( ! empty( $poster_url ) && 'self-hosted' !== $video_type ) : ?>
				<img src="<?php echo esc_url( $poster_url ); ?>" alt="" class="sf-video-poster">
			<?php endif; ?>

			<button class="sf-video-play-btn" aria-label="<?php esc_attr_e( 'Play video', 'themeflex' ); ?>">
				<svg width="48" height="48" viewBox="0 0 24 24" fill="currentColor">
					<polygon points="5 3 19 12 5 21 5 3"></polygon>
				</svg>
			</button>
		</div>
		<?php
	}

	/**
	 * Detect video type
	 *
	 * @param string $url Video URL
	 * @return string
	 */
	public static function detect_video_type( $url ) {
		if ( strpos( $url, 'youtube.com' ) !== false || strpos( $url, 'youtu.be' ) !== false ) {
			return 'youtube';
		}

		if ( strpos( $url, 'vimeo.com' ) !== false ) {
			return 'vimeo';
		}

		if ( strpos( $url, '.mp4' ) !== false ) {
			return 'self-hosted';
		}

		return 'unknown';
	}

	/**
	 * Extract YouTube video ID
	 *
	 * @param string $url YouTube URL
	 * @return string
	 */
	public static function extract_youtube_id( $url ) {
		preg_match( '%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?\s]{11})%i', $url, $match );
		return isset( $match[1] ) ? $match[1] : '';
	}

	/**
	 * Extract Vimeo video ID
	 *
	 * @param string $url Vimeo URL
	 * @return string
	 */
	public static function extract_vimeo_id( $url ) {
		preg_match( '/vimeo\.com\/(\d+)/', $url, $match );
		return isset( $match[1] ) ? $match[1] : '';
	}

	/**
	 * Get video metadata
	 *
	 * @param string $video_url Video URL
	 * @return array
	 */
	public static function get_video_metadata( $video_url ) {
		return array(
			'type' => self::detect_video_type( $video_url ),
			'youtube_id' => self::extract_youtube_id( $video_url ),
			'vimeo_id' => self::extract_vimeo_id( $video_url ),
		);
	}
}

// Initialize
ThemeFlex_Video_Background::init();
