<?php
/**
 * ThemeFlex Widget Base Class
 *
 * All theme widgets should extend this instead of \Elementor\Widget_Base directly.
 * Provides: automatic Hook API integration, conditional asset loading trigger,
 * skin token access, and standardized render lifecycle.
 *
 * @package ThemeFlex
 * @since   2.0.0
 */
if (!defined('ABSPATH')) exit;

abstract class ThemeFlex_Widget_Base extends \Elementor\Widget_Base {

    // ── Skin Token Access ──────────────────────────────────────────────────

    /**
     * Get a skin CSS custom property value.
     *
     * @param string $token    Token name (without --sf- prefix), e.g. 'color-primary'
     * @param string $fallback Fallback value.
     * @return string
     */
    protected function skin_token(string $token, string $fallback = ''): string {
        static $skin_manager = null;
        if (null === $skin_manager && function_exists('themeflex_skin_manager')) {
            $skin_manager = themeflex_skin_manager();
        }
        if ($skin_manager) {
            $skin = $skin_manager->get_skin($skin_manager->get_active_skin());
            // Check colors first
            $token_key = ltrim(str_replace('--sf-', '', $token), '-');
            if (!empty($skin['colors'][$token_key])) return $skin['colors'][$token_key];
            if (!empty($skin['scheme'][$token_key])) return $skin['scheme'][$token_key];
        }
        return $fallback;
    }

    // ── Hookable Render ────────────────────────────────────────────────────

    /**
     * Wraps render() with Hook API fire points.
     * Core render remains in render() — never call this directly.
     */
    public function render_content(): void { // @phpstan-ignore-line
        $context = [
            'widget_name'    => $this->get_name(),
            'widget_id'      => $this->get_id(),
            'widget_instance'=> $this,
            'settings'       => $this->get_settings_for_display(),
        ];

        // Fire: before this specific widget type
        do_action("sf_before_{$this->get_name()}_render", $this, $context);

        // Capture output for filtering
        ob_start();
        parent::render_content();
        $output = ob_get_clean();

        // Filter: let extensions modify widget output
        $output = apply_filters('sf_widget_output', $output, $this->get_name(), $context);
        $output = apply_filters("sf_widget_{$this->get_name()}_output", $output, $context);

        echo $output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

        // Fire: after this widget type
        do_action("sf_after_{$this->get_name()}_render", $this, $context);
    }

    // ── Standardized CSS var() helper ────────────────────────────────────

    /**
     * Return a CSS var() with fallback — for inline styles.
     *
     * @param string $var      CSS custom property name with --sf- prefix.
     * @param string $fallback Fallback hex/value.
     * @return string   e.g. "var(--sf-color-primary, #FF5E2E)"
     */
    protected function css_var(string $var, string $fallback = ''): string {
        if ($fallback) return "var({$var}, {$fallback})";
        return "var({$var})";
    }

    // ── Module Guard ───────────────────────────────────────────────────────

    /**
     * Check if a module is enabled before rendering premium features.
     *
     * @param string $module_id Module ID.
     * @return bool
     */
    protected function module_enabled(string $module_id): bool {
        return function_exists('sf_is_module_enabled') && sf_is_module_enabled($module_id);
    }

    // ── Template Helper ────────────────────────────────────────────────────

    /**
     * Load a widget-specific template part.
     * Template paths are filterable via sf_widget_template_path.
     *
     * @param string $template Template name (without .php).
     * @param array  $args     Variables available in template.
     */
    protected function load_template(string $template, array $args = []): void {
        $path = apply_filters(
            'sf_widget_template_path',
            get_template_directory()."/template-parts/widgets/{$template}.php",
            $template,
            $this->get_name()
        );
        if ( ! file_exists( $path ) ) {
			return;
		}
		// Pass $args as a named variable instead of extract() to comply with PHPCS.
		$template_args = $args;
		include $path;
    }
}
