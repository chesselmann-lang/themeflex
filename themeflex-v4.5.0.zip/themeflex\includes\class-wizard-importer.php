<?php
/**
 * Demo Importer — One-Click Page Creator Engine (v4.0)
 *
 * Handles AJAX `themeflex_import_demo` (called from the Setup Wizard Step 3).
 * Creates WP pages from placeholder-content JSON at three depth levels:
 *   headlines — title headings only
 *   short     — headings + brief body paragraphs
 *   full      — headings + body + FAQ section
 *
 * Also applies the recommended skin via set_theme_mod().
 *
 * @package ThemeFlex
 * @since   4.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ThemeFlex_Wizard_Importer
 */
class ThemeFlex_Wizard_Importer {

	/**
	 * Sub-path to placeholder-content JSON files (relative to THEMEFLEX_DIR).
	 *
	 * @var string
	 */
	const CONTENT_DIR = '/inc/demo-importer/placeholder-content/';

	/**
	 * Fallback category when no specific content file is found.
	 *
	 * @var string
	 */
	const FALLBACK_CATEGORY = 'general';

	/**
	 * Register hooks.
	 */
	public static function init(): void {
		add_action( 'wp_ajax_themeflex_import_demo', array( __CLASS__, 'handle_import' ) );
	}

	// -----------------------------------------------------------------------
	// AJAX handler
	// -----------------------------------------------------------------------

	/**
	 * Handle `themeflex_import_demo` AJAX request.
	 */
	public static function handle_import(): void {
		check_ajax_referer( 'tf_wizard_import', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied.' ), 403 );
		}

		$template = sanitize_key( wp_unslash( $_POST['template'] ?? '' ) );
		$category = sanitize_key( wp_unslash( $_POST['category'] ?? self::FALLBACK_CATEGORY ) );
		$skin     = sanitize_key( wp_unslash( $_POST['skin']     ?? '' ) );
		$schema   = sanitize_text_field( wp_unslash( $_POST['schema'] ?? '' ) );
		$depth    = sanitize_key( wp_unslash( $_POST['depth']    ?? 'short' ) );

		if ( ! in_array( $depth, array( 'headlines', 'short', 'full' ), true ) ) {
			$depth = 'short';
		}

		if ( empty( $template ) ) {
			wp_send_json_error( array( 'message' => 'Template slug required.' ) );
		}

		try {
			$result = self::run_import( $template, $category, $skin, $schema, $depth );
			wp_send_json_success( $result );
		} catch ( RuntimeException $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}
	}

	// -----------------------------------------------------------------------
	// Import engine
	// -----------------------------------------------------------------------

	/**
	 * Create pages from placeholder content.
	 *
	 * @param  string $template  Template slug (e.g. "page-restaurant").
	 * @param  string $category  Industry category ID.
	 * @param  string $skin      Recommended skin slug.
	 * @param  string $schema    Schema.org type string.
	 * @param  string $depth     Content depth: headlines | short | full.
	 * @return array             Result with created count and admin URL.
	 * @throws RuntimeException  On irrecoverable failure.
	 */
	private static function run_import(
		string $template,
		string $category,
		string $skin,
		string $schema,
		string $depth
	): array {
		// 1. Load placeholder content.
		$pages = self::load_placeholder_content( $category, $template );

		if ( empty( $pages ) ) {
			throw new RuntimeException(
				/* translators: %s: industry category id */
				sprintf( __( 'No placeholder content found for "%s".', 'themeflex' ), $category )
			);
		}

		// 2. Apply skin.
		if ( ! empty( $skin ) ) {
			self::apply_skin( $skin );
		}

		// 3. Store Schema.org type for SEO output.
		if ( ! empty( $schema ) ) {
			update_option( 'themeflex_schema_type', sanitize_text_field( $schema ), false );
		}

		// 4. Create / update pages.
		$created_ids   = array();
		$front_page_id = 0;

		foreach ( $pages as $page_data ) {
			$slug     = sanitize_title( $page_data['slug'] ?? '' );
			$existing = $slug ? self::find_existing_page( $slug ) : 0;

			$post_args = array(
				'post_title'   => wp_strip_all_tags( $page_data['title'] ?? '' ),
				'post_name'    => $slug,
				'post_content' => self::render_content( $page_data, $depth ),
				'post_status'  => 'draft',
				'post_type'    => 'page',
				'post_author'  => get_current_user_id(),
				'meta_input'   => array(
					'_themeflex_imported'        => '1',
					'_themeflex_import_template' => $template,
					'_themeflex_import_category' => $category,
					'_themeflex_import_depth'    => $depth,
					'_themeflex_import_date'     => gmdate( 'Y-m-d H:i:s' ),
				),
			);

			if ( $existing ) {
				$post_args['ID'] = $existing;
				$id = wp_update_post( $post_args, true );
			} else {
				$id = wp_insert_post( $post_args, true );
			}

			if ( is_wp_error( $id ) ) {
				continue;
			}

			$created_ids[] = $id;

			// Mark first page with front_page flag as the homepage.
			if ( ! $front_page_id && ! empty( $page_data['front_page'] ) ) {
				$front_page_id = $id;
			}
		}

		if ( empty( $created_ids ) ) {
			throw new RuntimeException( __( 'No pages could be created. Check user permissions.', 'themeflex' ) );
		}

		// 5. Set front page if flagged.
		if ( $front_page_id ) {
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $front_page_id );
		}

		return array(
			'created'   => count( $created_ids ),
			'page_ids'  => $created_ids,
			'pages_url' => admin_url( 'edit.php?post_type=page' ),
		);
	}

	// -----------------------------------------------------------------------
	// Content loading
	// -----------------------------------------------------------------------

	/**
	 * Load placeholder-content pages array.
	 *
	 * Resolution order:
	 *  1. {CONTENT_DIR}/{category}/{template}.json
	 *  2. {CONTENT_DIR}/{category}/default.json
	 *  3. {CONTENT_DIR}/general/default.json
	 *
	 * @param  string $category
	 * @param  string $template
	 * @return array  Array of page definition arrays, or empty array.
	 */
	private static function load_placeholder_content(
		string $category,
		string $template
	): array {
		$base = THEMEFLEX_DIR . self::CONTENT_DIR;

		$candidates = array(
			$base . $category . '/' . $template . '.json',
			$base . $category . '/default.json',
			$base . self::FALLBACK_CATEGORY . '/default.json',
		);

		foreach ( $candidates as $path ) {
			if ( ! file_exists( $path ) ) {
				continue;
			}

			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$raw  = file_get_contents( $path );
			$data = json_decode( $raw, true );

			if ( is_array( $data ) && ! empty( $data['pages'] ) ) {
				return (array) $data['pages'];
			}
		}

		return array();
	}

	// -----------------------------------------------------------------------
	// Content rendering
	// -----------------------------------------------------------------------

	/**
	 * Render HTML page content from page definition at the given depth.
	 *
	 * @param  array  $page   Page definition from JSON.
	 * @param  string $depth  headlines | short | full.
	 * @return string         HTML content string.
	 */
	private static function render_content( array $page, string $depth ): string {
		$sections = $page['sections'] ?? array();

		if ( 'headlines' === $depth ) {
			$parts = array();
			foreach ( $sections as $section ) {
				$heading = wp_strip_all_tags( $section['heading'] ?? '' );
				if ( $heading ) {
					$parts[] = '<h2>' . esc_html( $heading ) . '</h2>';
				}
			}
			return implode( "\n\n", $parts );
		}

		$html = '';

		foreach ( $sections as $section ) {
			$heading = wp_strip_all_tags( $section['heading'] ?? '' );
			if ( $heading ) {
				$html .= '<h2>' . esc_html( $heading ) . '</h2>' . "\n";
			}

			if ( ! empty( $section['body'] ) ) {
				$html .= wpautop( wp_strip_all_tags( $section['body'] ) ) . "\n";
			}

			if ( 'full' === $depth && ! empty( $section['faq'] ) ) {
				$html .= '<h3>' . esc_html__( 'Frequently Asked Questions', 'themeflex' ) . '</h3>' . "\n";
				$html .= '<dl class="tf-faq">' . "\n";
				foreach ( (array) $section['faq'] as $faq_item ) {
					$q = wp_strip_all_tags( $faq_item['q'] ?? '' );
					$a = wp_strip_all_tags( $faq_item['a'] ?? '' );
					if ( $q && $a ) {
						$html .= '<dt>' . esc_html( $q ) . '</dt>' . "\n";
						$html .= '<dd>' . esc_html( $a )  . '</dd>' . "\n";
					}
				}
				$html .= '</dl>' . "\n";
			}
		}

		return $html;
	}

	// -----------------------------------------------------------------------
	// Helpers
	// -----------------------------------------------------------------------

	/**
	 * Find an existing page by slug to avoid duplicates on re-import.
	 *
	 * @param  string $slug
	 * @return int    Post ID or 0 if not found.
	 */
	private static function find_existing_page( string $slug ): int {
		$page = get_page_by_path( $slug, OBJECT, 'page' );
		return $page ? (int) $page->ID : 0;
	}

	/**
	 * Apply a recommended skin via Customizer theme mod.
	 *
	 * @param  string $skin  Skin slug, e.g. "skin-corporate-navy".
	 */
	private static function apply_skin( string $skin ): void {
		set_theme_mod( 'sf_skin', sanitize_key( $skin ) );
	}
}

// Auto-init.
ThemeFlex_Wizard_Importer::init();
