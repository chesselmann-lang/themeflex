<?php
/**
 * WooCommerce Builder - Custom Product Page Layouts
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ThemeFlex_Woo_Builder {

	/**
	 * Custom post type slug
	 */
	const CPT_SLUG = 'sf_woo_template';

	/**
	 * Template types
	 */
	const TEMPLATE_TYPES = array(
		'shop'      => 'Shop Page',
		'single'    => 'Single Product',
		'cart'      => 'Cart Page',
		'checkout'  => 'Checkout Page',
		'account'   => 'My Account',
		'thankyou'  => 'Thank You Page',
	);

	/**
	 * Initialize
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_post_type' ), 10 );
		add_action( 'init', array( __CLASS__, 'register_meta' ), 10 );
		add_action( 'admin_menu', array( __CLASS__, 'register_admin_page' ), 30 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'wp_ajax_sf_get_woo_templates', array( __CLASS__, 'ajax_get_templates' ) );
		add_action( 'wp_ajax_sf_toggle_template', array( __CLASS__, 'ajax_toggle_template' ) );

		// Template override hooks
		add_filter( 'wc_get_template', array( __CLASS__, 'override_wc_template' ), 10, 5 );
		add_filter( 'woocommerce_locate_template', array( __CLASS__, 'override_locate_template' ), 10, 3 );

		// Enqueue template styles/scripts
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_template_scripts' ) );
	}

	/**
	 * Register custom post type
	 */
	public static function register_post_type() {
		register_post_type(
			self::CPT_SLUG,
			array(
				'label'              => esc_html__( 'WooCommerce Templates', 'themeflex' ),
				'public'             => false,
				'show_in_rest'       => true,
				'show_ui'            => false,
				'supports'           => array( 'title', 'editor', 'custom-fields' ),
				'capability_type'    => 'post',
				'map_meta_cap'       => true,
				'hierarchical'       => false,
				'rewrite'            => false,
				'query_var'          => false,
				'exclude_from_search' => true,
			)
		);
	}

	/**
	 * Register post meta
	 */
	public static function register_meta() {
		register_post_meta(
			self::CPT_SLUG,
			'woo_template_type',
			array(
				'type'           => 'string',
				'single'         => true,
				'show_in_rest'   => true,
				'sanitize_callback' => 'sanitize_text_field',
			)
		);

		register_post_meta(
			self::CPT_SLUG,
			'woo_template_active',
			array(
				'type'           => 'boolean',
				'single'         => true,
				'show_in_rest'   => true,
				'sanitize_callback' => 'rest_sanitize_boolean',
			)
		);

		register_post_meta(
			self::CPT_SLUG,
			'woo_template_category',
			array(
				'type'           => 'string',
				'single'         => true,
				'show_in_rest'   => true,
				'sanitize_callback' => 'sanitize_text_field',
			)
		);
	}

	/**
	 * Register admin page
	 */
	public static function register_admin_page() {
		add_submenu_page(
			'themeflex-dashboard',
			esc_html__( 'WooCommerce Builder', 'themeflex' ),
			esc_html__( 'WooCommerce Builder', 'themeflex' ),
			'manage_options',
			'themeflex-woo-builder',
			array( __CLASS__, 'render_page' ),
			10
		);
	}

	/**
	 * Enqueue assets
	 */
	public static function enqueue_assets( $hook ) {
		if ( 'themeflex_page_themeflex-woo-builder' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'sf-woo-builder',
			THEMEFLEX_URL . '/assets/css/woo-builder.css',
			array(),
			THEMEFLEX_VERSION
		);

		wp_enqueue_script(
			'sf-woo-builder',
			THEMEFLEX_URL . '/assets/js/woo-builder.js',
			array( 'jquery' ),
			THEMEFLEX_VERSION,
			true
		);

		wp_localize_script(
			'sf-woo-builder',
			'sfWooBuilder',
			array(
				'nonce'   => wp_create_nonce( 'sf_woo_builder_nonce' ),
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
			)
		);
	}

	/**
	 * Get all WooCommerce templates
	 */
	public static function get_templates() {
		$templates = get_posts(
			array(
				'post_type'      => self::CPT_SLUG,
				'posts_per_page' => -1,
				'orderby'        => 'meta_value',
				'meta_key'       => 'woo_template_type',
				'order'          => 'ASC',
			)
		);

		return $templates;
	}

	/**
	 * Get template by type
	 */
	public static function get_template_by_type( $type ) {
		$templates = get_posts(
			array(
				'post_type'      => self::CPT_SLUG,
				'posts_per_page' => 1,
				'meta_key'       => 'woo_template_type',
				'meta_value'     => $type,
				'meta_compare'   => '=',
			)
		);

		return ! empty( $templates ) ? $templates[0] : null;
	}

	/**
	 * AJAX: Get templates
	 */
	public static function ajax_get_templates() {
		check_ajax_referer( 'sf_woo_builder_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Insufficient permissions' );
		}

		$templates = self::get_templates();
		$data      = array();

		foreach ( $templates as $template ) {
			$type   = get_post_meta( $template->ID, 'woo_template_type', true );
			$active = get_post_meta( $template->ID, 'woo_template_active', true );

			$data[] = array(
				'id'       => $template->ID,
				'title'    => $template->post_title,
				'type'     => $type,
				'active'   => (bool) $active,
				'edit_url' => get_edit_post_link( $template->ID, 'raw' ),
			);
		}

		wp_send_json_success( $data );
	}

	/**
	 * AJAX: Toggle template active status
	 */
	public static function ajax_toggle_template() {
		check_ajax_referer( 'sf_woo_builder_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Insufficient permissions' );
		}

		$template_id = isset( $_POST['template_id'] ) ? intval( $_POST['template_id'] ) : 0;
		$active      = isset( $_POST['active'] ) ? rest_sanitize_boolean( wp_unslash( $_POST['active'] ) ) : false;

		if ( ! $template_id ) {
			wp_send_json_error( 'Invalid template ID' );
		}

		update_post_meta( $template_id, 'woo_template_active', $active );

		wp_send_json_success(
			array(
				'template_id' => $template_id,
				'active'      => $active,
			)
		);
	}

	/**
	 * Override WooCommerce template
	 */
	public static function override_wc_template( $template, $template_name, $template_path, $default_path, $args ) {
		// Determine template type from template name
		$type = self::get_template_type_from_name( $template_name );

		if ( ! $type ) {
			return $template;
		}

		$custom_template = self::get_template_by_type( $type );

		if ( ! $custom_template || ! get_post_meta( $custom_template->ID, 'woo_template_active', true ) ) {
			return $template;
		}

		// Return a custom template file that loads the Elementor content
		return self::get_custom_template_file( $custom_template->ID );
	}

	/**
	 * Override locate template
	 */
	public static function override_locate_template( $template, $template_name, $template_path ) {
		return $template;
	}

	/**
	 * Enqueue template scripts
	 */
	public static function enqueue_template_scripts() {
		if ( ! is_woocommerce() ) {
			return;
		}

		wp_enqueue_style(
			'sf-woo-builder-frontend',
			THEMEFLEX_URL . '/assets/css/woo-builder-frontend.css',
			array(),
			THEMEFLEX_VERSION
		);
	}

	/**
	 * Get template type from WooCommerce template name
	 */
	private static function get_template_type_from_name( $template_name ) {
		if ( false !== strpos( $template_name, 'archive-product' ) ) {
			return 'shop';
		} elseif ( false !== strpos( $template_name, 'single-product' ) ) {
			return 'single';
		} elseif ( false !== strpos( $template_name, 'cart' ) ) {
			return 'cart';
		} elseif ( false !== strpos( $template_name, 'checkout' ) ) {
			return 'checkout';
		} elseif ( false !== strpos( $template_name, 'myaccount' ) ) {
			return 'account';
		} elseif ( false !== strpos( $template_name, 'order-received' ) ) {
			return 'thankyou';
		}

		return null;
	}

	/**
	 * Get custom template file
	 */
	private static function get_custom_template_file( $template_id ) {
		// For Elementor-built templates, we return a path that loads Elementor content
		if ( class_exists( '\Elementor\Plugin' ) ) {
			return THEMEFLEX_DIR . '/templates/woo-elementor-template.php';
		}

		return '';
	}

	/**
	 * Render admin page
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions', 'themeflex' ) );
		}

		$templates = self::get_templates();
		?>
		<div class="wrap sf-woo-builder-page">
			<div class="sf-page-header">
				<h1><?php esc_html_e( 'WooCommerce Builder', 'themeflex' ); ?></h1>
				<p><?php esc_html_e( 'Create custom layouts for WooCommerce pages using Elementor', 'themeflex' ); ?></p>
				<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=' . self::CPT_SLUG ) ); ?>" class="button button-primary">
					<?php esc_html_e( '+ Create New Template', 'themeflex' ); ?>
				</a>
			</div>

			<div class="sf-woo-templates-grid">
				<?php
				foreach ( self::TEMPLATE_TYPES as $type => $label ) :
					$template = self::get_template_by_type( $type );
					$is_active = $template ? (bool) get_post_meta( $template->ID, 'woo_template_active', true ) : false;
					$edit_url = $template ? get_edit_post_link( $template->ID, 'raw' ) : '';
					?>
					<div class="sf-woo-template-card">
						<div class="sf-woo-template-inner">
							<div class="sf-woo-template-icon">
								<span class="dashicons dashicons-<?php echo esc_attr( self::get_icon_for_type( $type ) ); ?>"></span>
							</div>
							<h3><?php echo esc_html( $label ); ?></h3>
							<?php if ( $template ) : ?>
								<p class="sf-template-name"><?php echo esc_html( $template->post_title ); ?></p>
								<div class="sf-template-status <?php echo $is_active ? 'active' : 'inactive'; ?>">
									<?php echo $is_active ? esc_html__( 'Active', 'themeflex' ) : esc_html__( 'Inactive', 'themeflex' ); ?>
								</div>
								<div class="sf-woo-template-actions">
									<a href="<?php echo esc_url( $edit_url ); ?>" class="button button-secondary">
										<?php esc_html_e( 'Edit', 'themeflex' ); ?>
									</a>
									<button class="button sf-toggle-template" data-template-id="<?php echo intval( $template->ID ); ?>" data-active="<?php echo $is_active ? '1' : '0'; ?>">
										<?php echo $is_active ? esc_html__( 'Deactivate', 'themeflex' ) : esc_html__( 'Activate', 'themeflex' ); ?>
									</button>
								</div>
							<?php else : ?>
								<p class="sf-no-template"><?php esc_html_e( 'No custom template yet', 'themeflex' ); ?></p>
								<div class="sf-woo-template-actions">
									<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=' . self::CPT_SLUG . '&woo_type=' . $type ) ); ?>" class="button button-primary">
										<?php esc_html_e( 'Create', 'themeflex' ); ?>
									</a>
								</div>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Get icon for template type
	 */
	private static function get_icon_for_type( $type ) {
		$icons = array(
			'shop'     => 'store',
			'single'   => 'product',
			'cart'     => 'cart',
			'checkout' => 'credit',
			'account'  => 'admin-users',
			'thankyou' => 'yes-alt',
		);

		return isset( $icons[ $type ] ) ? $icons[ $type ] : 'dashicons-admin-generic';
	}
}
