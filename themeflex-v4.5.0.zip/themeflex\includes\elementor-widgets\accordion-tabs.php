<?php
/**
 * Elementor Accordion & Tabs Combo Widget
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Accordion Tabs Widget Class
 *
 * @since 1.0.0
 */
class ThemeFlex_Accordion_Tabs_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'themeflex_accordion_tabs';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Accordion & Tabs', 'themeflex' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-accordion';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'themeflex' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Display Mode
		$this->add_control(
			'display_mode',
			array(
				'label'   => esc_html__( 'Display Mode', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::CHOOSE,
				'options' => array(
					'accordion' => array(
						'title' => esc_html__( 'Accordion', 'themeflex' ),
						'icon'  => 'eicon-accordion',
					),
					'tabs'      => array(
						'title' => esc_html__( 'Tabs', 'themeflex' ),
						'icon'  => 'eicon-tabs',
					),
				),
				'default' => 'accordion',
				'toggle'  => true,
			)
		);

		// Items Repeater
		$this->add_control(
			'items',
			array(
				'label'       => esc_html__( 'Items', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => array(
					array(
						'name'        => 'item_title',
						'label'       => esc_html__( 'Title', 'themeflex' ),
						'type'        => \Elementor\Controls_Manager::TEXT,
						'default'     => esc_html__( 'Item Title', 'themeflex' ),
						'placeholder' => esc_html__( 'Enter item title', 'themeflex' ),
					),
					array(
						'name'        => 'item_content',
						'label'       => esc_html__( 'Content', 'themeflex' ),
						'type'        => \Elementor\Controls_Manager::TEXTAREA,
						'default'     => esc_html__( 'Item content goes here', 'themeflex' ),
						'placeholder' => esc_html__( 'Enter item content', 'themeflex' ),
						'rows'        => 3,
					),
				),
				'default'     => array(
					array(
						'item_title'   => esc_html__( 'Item 1', 'themeflex' ),
						'item_content' => esc_html__( 'Content for item 1', 'themeflex' ),
					),
					array(
						'item_title'   => esc_html__( 'Item 2', 'themeflex' ),
						'item_content' => esc_html__( 'Content for item 2', 'themeflex' ),
					),
					array(
						'item_title'   => esc_html__( 'Item 3', 'themeflex' ),
						'item_content' => esc_html__( 'Content for item 3', 'themeflex' ),
					),
				),
				'title_field' => '{{{ item_title }}}',
			)
		);

		$this->end_controls_section();

		// Style Section - Items
		$this->start_controls_section(
			'items_style_section',
			array(
				'label' => esc_html__( 'Items', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Title Background Color
		$this->add_control(
			'title_bg_color',
			array(
				'label'     => esc_html__( 'Title Background Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#F3F4F6',
				'selectors' => array(
					'{{WRAPPER}} .accordion-item-title, {{WRAPPER}} .tab-button' => 'background-color: {{VALUE}}',
				),
			)
		);

		// Title Color
		$this->add_control(
			'title_color',
			array(
				'label'     => esc_html__( 'Title Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#1F2937',
				'selectors' => array(
					'{{WRAPPER}} .accordion-item-title, {{WRAPPER}} .tab-button' => 'color: {{VALUE}}',
				),
			)
		);

		// Active Title Background Color
		$this->add_control(
			'active_title_bg_color',
			array(
				'label'     => esc_html__( 'Active Title Background Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FF5E2E',
				'selectors' => array(
					'{{WRAPPER}} .accordion-item-title.active, {{WRAPPER}} .tab-button.active' => 'background-color: {{VALUE}}',
				),
			)
		);

		// Active Title Color
		$this->add_control(
			'active_title_color',
			array(
				'label'     => esc_html__( 'Active Title Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FFFFFF',
				'selectors' => array(
					'{{WRAPPER}} .accordion-item-title.active, {{WRAPPER}} .tab-button.active' => 'color: {{VALUE}}',
				),
			)
		);

		// Content Background Color
		$this->add_control(
			'content_bg_color',
			array(
				'label'     => esc_html__( 'Content Background Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FFFFFF',
				'selectors' => array(
					'{{WRAPPER}} .accordion-item-content, {{WRAPPER}} .tab-content' => 'background-color: {{VALUE}}',
				),
			)
		);

		// Content Color
		$this->add_control(
			'content_color',
			array(
				'label'     => esc_html__( 'Content Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#6B7280',
				'selectors' => array(
					'{{WRAPPER}} .accordion-item-content, {{WRAPPER}} .tab-content' => 'color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Spacing
		$this->start_controls_section(
			'spacing_style_section',
			array(
				'label' => esc_html__( 'Spacing', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Title Padding
		$this->add_control(
			'title_padding',
			array(
				'label'      => esc_html__( 'Title Padding', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => '15',
					'right'  => '20',
					'bottom' => '15',
					'left'   => '20',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .accordion-item-title, {{WRAPPER}} .tab-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				),
			)
		);

		// Content Padding
		$this->add_control(
			'content_padding',
			array(
				'label'      => esc_html__( 'Content Padding', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => '20',
					'right'  => '20',
					'bottom' => '20',
					'left'   => '20',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .accordion-item-content, {{WRAPPER}} .tab-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				),
			)
		);

		// Item Spacing
		$this->add_control(
			'item_spacing',
			array(
				'label'      => esc_html__( 'Item Spacing', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 30,
					),
				),
				'default'    => array(
					'size' => 0,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .accordion-item' => 'margin-bottom: {{SIZE}}{{UNIT}}',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$display_mode = isset( $settings['display_mode'] ) ? $settings['display_mode'] : 'accordion';
		$items = isset( $settings['items'] ) ? $settings['items'] : array();

		if ( empty( $items ) ) {
			return;
		}

		$wrapper_class = 'accordion-tabs accordion-tabs--' . esc_attr( $display_mode );
		echo '<div class="' . esc_attr( $wrapper_class ) . '" data-mode="' . esc_attr( $display_mode ) . '">';

		if ( 'tabs' === $display_mode ) {
			// Tabs Header
			echo '<div class="tabs-header">';
			foreach ( $items as $index => $item ) {
				$active_class = ( 0 === $index ) ? 'active' : '';
				printf(
					'<button class="tab-button %s" data-tab="%s">%s</button>',
					esc_attr( $active_class ),
					esc_attr( 'tab-' . $index ),
					esc_html( $item['item_title'] )
				);
			}
			echo '</div>';

			// Tabs Content
			echo '<div class="tabs-content">';
			foreach ( $items as $index => $item ) {
				$active_class = ( 0 === $index ) ? 'active' : '';
				printf(
					'<div class="tab-content %s" data-tab="%s">%s</div>',
					esc_attr( $active_class ),
					esc_attr( 'tab-' . $index ),
					esc_html( $item['item_content'] )
				);
			}
			echo '</div>';
		} else {
			// Accordion Items
			foreach ( $items as $index => $item ) {
				$active_class = ( 0 === $index ) ? 'active' : '';
				echo '<div class="accordion-item">';

				printf(
					'<button class="accordion-item-title %s" data-toggle="%s">%s <span class="toggle-icon">+</span></button>',
					esc_attr( $active_class ),
					esc_attr( 'accordion-' . $index ),
					esc_html( $item['item_title'] )
				);

				printf(
					'<div class="accordion-item-content %s" data-toggle="%s">%s</div>',
					esc_attr( $active_class ),
					esc_attr( 'accordion-' . $index ),
					esc_html( $item['item_content'] )
				);

				echo '</div>';
			}
		}

		echo '</div>';

		// Inline Styles
		?>
		<style>
			.accordion-tabs {
				width: 100%;
			}

			/* Tabs Mode */
			.accordion-tabs--tabs .tabs-header {
				display: flex;
				flex-wrap: wrap;
				border-bottom: 1px solid #E5E7EB;
				gap: 0;
			}

			.accordion-tabs--tabs .tab-button {
				border: none;
				cursor: pointer;
				transition: all 0.3s ease;
				font-size: 14px;
				font-weight: 500;
				flex: 1;
				text-align: center;
				border-radius: 0;
				margin-right: -1px;
			}

			.accordion-tabs--tabs .tab-button:last-child {
				margin-right: 0;
			}

			.accordion-tabs--tabs .tab-content {
				display: none;
			}

			.accordion-tabs--tabs .tab-content.active {
				display: block;
				animation: fadeIn 0.3s ease;
			}

			/* Accordion Mode */
			.accordion-tabs--accordion .accordion-item {
				border: 1px solid #E5E7EB;
				border-radius: 4px;
			}

			.accordion-item-title {
				width: 100%;
				border: none;
				cursor: pointer;
				transition: all 0.3s ease;
				font-size: 14px;
				font-weight: 500;
				text-align: left;
				display: flex;
				justify-content: space-between;
				align-items: center;
				border-radius: 4px 4px 0 0;
			}

			.accordion-tabs--accordion .accordion-item:not(:first-child) .accordion-item-title {
				border-radius: 0;
			}

			.accordion-item-title.active {
				border-radius: 4px 4px 0 0;
			}

			.accordion-tabs--accordion .accordion-item:last-child .accordion-item-title {
				border-radius: 0;
			}

			.accordion-tabs--accordion .accordion-item:last-child .accordion-item-content.active {
				border-radius: 0 0 4px 4px;
			}

			.toggle-icon {
				display: inline-block;
				transition: transform 0.3s ease;
				font-size: 18px;
				font-weight: bold;
			}

			.accordion-item-title.active .toggle-icon {
				transform: rotate(45deg);
			}

			.accordion-item-content {
				display: none;
				border-top: 1px solid #E5E7EB;
				border-radius: 0 0 4px 4px;
			}

			.accordion-item-content.active {
				display: block;
				animation: slideDown 0.3s ease;
			}

			/* Animation */
			@keyframes slideDown {
				from {
					opacity: 0;
					max-height: 0;
				}
				to {
					opacity: 1;
					max-height: 1000px;
				}
			}

			@keyframes fadeIn {
				from {
					opacity: 0;
				}
				to {
					opacity: 1;
				}
			}
		</style>

		<script>
			(function() {
				function initAccordionTabs() {
					const containers = document.querySelectorAll('.accordion-tabs');

					containers.forEach(function(container) {
						const mode = container.getAttribute('data-mode');

						if ('tabs' === mode) {
							const buttons = container.querySelectorAll('.tab-button');
							const contents = container.querySelectorAll('.tab-content');

							buttons.forEach(function(button) {
								button.addEventListener('click', function() {
									const tabId = button.getAttribute('data-tab');

									// Remove active from all buttons and contents
									buttons.forEach(function(btn) {
										btn.classList.remove('active');
									});
									contents.forEach(function(content) {
										content.classList.remove('active');
									});

									// Add active to clicked button and corresponding content
									button.classList.add('active');
									container.querySelector('[data-tab="' + tabId + '"].tab-content').classList.add('active');
								});
							});
						} else {
							// Accordion mode
							const titles = container.querySelectorAll('.accordion-item-title');

							titles.forEach(function(title) {
								title.addEventListener('click', function() {
									const toggleId = title.getAttribute('data-toggle');
									const content = container.querySelector('[data-toggle="' + toggleId + '"].accordion-item-content');

									// If clicked item is already open, close it
									if (title.classList.contains('active')) {
										title.classList.remove('active');
										content.classList.remove('active');
									} else {
										// Close all other items
										titles.forEach(function(t) {
											t.classList.remove('active');
										});
										container.querySelectorAll('.accordion-item-content').forEach(function(c) {
											c.classList.remove('active');
										});

										// Open clicked item
										title.classList.add('active');
										content.classList.add('active');
									}
								});
							});
						}
					});
				}

				if (document.readyState === 'loading') {
					document.addEventListener('DOMContentLoaded', initAccordionTabs);
				} else {
					initAccordionTabs();
				}
			})();
		</script>
		<?php
	}
}
