<?php
/**
 * AI Content Assistant Widget — OpenAI API Integration direkt in Elementor.
 * @package ThemeFlex
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Ai_Content_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'sf_ai_content'; }
    public function get_title() { return esc_html__('AI Content Assistant','themeflex'); }
    public function get_icon()  { return 'eicon-ai'; }
    public function get_categories() { return ['themeflex']; }
    public function get_keywords()   { return ['ai','openai','gpt','content','assistant','generate','text']; }

    protected function register_controls() {
        $this->start_controls_section('s_content',['label'=>'Content & Prompts']);
        $this->add_control('style',['label'=>'Widget Style','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['input-output'=>'Input + Output Area','quick-prompts'=>'Quick Prompt Buttons','chat'=>'Mini Chat'],'default'=>'quick-prompts']);
        $this->add_control('heading',['label'=>'Heading','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'AI Content Assistant']);
        $this->add_control('subtitle',['label'=>'Subtext','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Powered by ChatGPT — generate content instantly']);
        $this->add_control('api_key_option',['label'=>'API Key Setting Name','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'themeflex_openai_api_key','description'=>'WordPress option name where the API key is stored (set in Theme Options).']);
        $this->add_control('model',['label'=>'GPT Model','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['gpt-4o-mini'=>'GPT-4o Mini (Fast & Cheap)','gpt-4o'=>'GPT-4o (Best)','gpt-3.5-turbo'=>'GPT-3.5 Turbo (Legacy)'],'default'=>'gpt-4o-mini']);
        $this->add_control('system_prompt',['label'=>'System Prompt','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>'You are a helpful content assistant for a WordPress website. Write concise, professional content. Keep responses under 300 words unless asked for more.']);

        $this->end_controls_section();

        $this->start_controls_section('s_prompts',['label'=>'Quick Prompt Buttons']);
        $rep = new \Elementor\Repeater();
        $rep->add_control('btn_label',['label'=>'Button Label','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Write a tagline']);
        $rep->add_control('btn_prompt',['label'=>'Prompt Template','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>'Write a compelling one-line tagline for a digital agency.']);
        $rep->add_control('btn_icon',['label'=>'Icon','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'✍️']);
        $this->add_control('prompts',['type'=>\Elementor\Controls_Manager::REPEATER,'fields'=>$rep->get_controls(),'default'=>[
            ['btn_label'=>'Hero Headline','btn_prompt'=>'Write a powerful hero headline for a modern WordPress theme. Maximum 8 words.','btn_icon'=>'🎯'],
            ['btn_label'=>'About Text','btn_prompt'=>'Write a 2-sentence about us paragraph for a creative digital agency.','btn_icon'=>'📝'],
            ['btn_label'=>'CTA Copy','btn_prompt'=>'Write a compelling call-to-action button text and supporting sentence for a WordPress theme.','btn_icon'=>'🚀'],
            ['btn_label'=>'SEO Description','btn_prompt'=>'Write a 155-character meta description for a premium WordPress theme called ThemeFlex.','btn_icon'=>'🔍'],
        ],'title_field'=>'{{{ btn_label }}}']);
        $this->end_controls_section();
    }

    protected function render() {
        $s    = $this->get_settings_for_display();
        $uid  = 'sfai-'.$this->get_id();
        $style = $s['style'] ?? 'quick-prompts';
        $model = $s['model'] ?? 'gpt-4o-mini';
        $sys   = $s['system_prompt'] ?? '';
        $api_key = get_option($s['api_key_option'] ?? 'themeflex_openai_api_key', '');
        $has_key = !empty($api_key);
        // Never expose API key to frontend — use AJAX
        $nonce = wp_create_nonce('sf_ai_content');
        ?>
        <div class="sf-ai-wrap" id="<?php echo esc_attr($uid); ?>" style="background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:16px;padding:28px;">
            <!-- Header -->
            <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;">
                <div style="width:40px;height:40px;border-radius:10px;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));display:flex;align-items:center;justify-content:center;font-size:20px;">🤖</div>
                <div>
                    <div style="font-weight:800;font-size:15px;color:var(--sf-title,#1e293b);"><?php echo esc_html($s['heading']); ?></div>
                    <div style="font-size:12px;color:var(--sf-meta,#94a3b8);"><?php echo esc_html($s['subtitle']); ?></div>
                </div>
                <?php if(!$has_key): ?>
                <span style="margin-left:auto;font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;background:#fef2f2;color:#ef4444;border:1px solid #fecaca;"><?php esc_html_e('API Key Missing','themeflex'); ?></span>
                <?php else: ?>
                <span style="margin-left:auto;font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;background:#ecfdf5;color:#10b981;border:1px solid #a7f3d0;"><?php esc_html_e('Ready','themeflex'); ?></span>
                <?php endif; ?>
            </div>

            <?php if(!$has_key): ?>
            <div style="background:#fef2f2;border-radius:10px;padding:16px;font-size:13px;color:#991b1b;">
                <?php esc_html_e('Set your OpenAI API key in WordPress Settings → ThemeFlex → AI Settings.','themeflex'); ?>
            </div>
            <?php else: ?>

            <?php if('quick-prompts' === $style && !empty($s['prompts'])): ?>
            <!-- Quick Prompt Buttons -->
            <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px;">
                <?php foreach($s['prompts'] as $p): ?>
                <button onclick="sfAiGenerate('<?php echo esc_js($uid); ?>',<?php echo wp_json_encode($p['btn_prompt']); ?>)"
                    style="padding:8px 14px;border:1px solid var(--sf-border,#e5e7eb);border-radius:8px;background:var(--sf-bg,#fff);color:var(--sf-title,#1e293b);font-size:13px;font-weight:600;cursor:pointer;display:flex;align-items:center;gap:6px;transition:all .2s;font-family:inherit;"
                    onmouseover="this.style.borderColor='var(--sf-color-primary,#FF5E2E)';this.style.background='rgba(255,94,46,.05)'"
                    onmouseout="this.style.borderColor='var(--sf-border,#e5e7eb)';this.style.background='var(--sf-bg,#fff)'">
                    <?php echo esc_html($p['btn_icon']); ?> <?php echo esc_html($p['btn_label']); ?>
                </button>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <!-- Custom Input -->
            <div style="display:flex;gap:8px;margin-bottom:12px;">
                <input type="text" id="<?php echo esc_attr($uid); ?>-input" placeholder="<?php esc_attr_e('Or type your own prompt…','themeflex'); ?>"
                    onkeydown="if(event.key==='Enter')sfAiGenerate('<?php echo esc_js($uid); ?>',this.value)"
                    style="flex:1;padding:10px 14px;border:1px solid var(--sf-border,#e5e7eb);border-radius:8px;font-size:14px;background:var(--sf-bg,#fff);color:var(--sf-title,#1e293b);font-family:inherit;outline:none;" />
                <button onclick="sfAiGenerate('<?php echo esc_js($uid); ?>',document.getElementById('<?php echo esc_js($uid); ?>-input').value)"
                    style="padding:10px 18px;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;border:none;border-radius:8px;font-weight:700;font-size:14px;cursor:pointer;font-family:inherit;white-space:nowrap;">
                    <?php esc_html_e('Generate','themeflex'); ?> ✨
                </button>
            </div>

            <!-- Output Area -->
            <div id="<?php echo esc_attr($uid); ?>-output" style="display:none;background:var(--sf-bg,#fff);border:1px solid var(--sf-border,#e5e7eb);border-radius:10px;padding:16px;min-height:80px;position:relative;">
                <div id="<?php echo esc_attr($uid); ?>-text" style="font-size:14px;color:var(--sf-text,#64748b);line-height:1.8;white-space:pre-wrap;"></div>
                <div style="display:flex;gap:8px;margin-top:12px;padding-top:12px;border-top:1px solid var(--sf-border,#e5e7eb);">
                    <button onclick="sfAiCopy('<?php echo esc_js($uid); ?>')" style="padding:6px 12px;border:1px solid var(--sf-border,#e5e7eb);border-radius:6px;background:none;color:var(--sf-title,#1e293b);font-size:12px;font-weight:600;cursor:pointer;font-family:inherit;"><?php esc_html_e('Copy','themeflex'); ?></button>
                    <button onclick="sfAiRetry('<?php echo esc_js($uid); ?>')" style="padding:6px 12px;border:1px solid var(--sf-border,#e5e7eb);border-radius:6px;background:none;color:var(--sf-title,#1e293b);font-size:12px;font-weight:600;cursor:pointer;font-family:inherit;"><?php esc_html_e('Regenerate','themeflex'); ?></button>
                </div>
            </div>
            <div id="<?php echo esc_attr($uid); ?>-loading" style="display:none;text-align:center;padding:20px;color:var(--sf-meta,#94a3b8);">
                <div style="display:inline-block;width:20px;height:20px;border:2px solid var(--sf-border,#e5e7eb);border-top-color:var(--sf-color-primary,#FF5E2E);border-radius:50%;animation:sfSpin 1s linear infinite;"></div>
                <span style="margin-left:10px;font-size:13px;"><?php esc_html_e('Generating…','themeflex'); ?></span>
            </div>
            <?php endif; ?>
        </div>
        <script>
        var sfAiLastPrompt='';
        window.sfAiGenerate=function(id,prompt){
            if(!prompt||!prompt.trim())return;
            sfAiLastPrompt=prompt;
            document.getElementById(id+'-output').style.display='none';
            document.getElementById(id+'-loading').style.display='block';
            var fd=new FormData();
            fd.append('action','sf_ai_generate');
            fd.append('nonce','<?php echo esc_js($nonce); ?>');
            fd.append('prompt',prompt);
            fd.append('model','<?php echo esc_js($model); ?>');
            fd.append('system','<?php echo esc_js($sys); ?>');
            fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>',{method:'POST',body:fd})
            .then(function(r){return r.json();})
            .then(function(res){
                document.getElementById(id+'-loading').style.display='none';
                document.getElementById(id+'-output').style.display='block';
                document.getElementById(id+'-text').textContent=res.success?(res.data.content||'No response'):(res.data||'Error');
            })
            .catch(function(){
                document.getElementById(id+'-loading').style.display='none';
                document.getElementById(id+'-output').style.display='block';
                document.getElementById(id+'-text').textContent='Connection error. Please try again.';
            });
        };
        window.sfAiCopy=function(id){navigator.clipboard.writeText(document.getElementById(id+'-text').textContent);};
        window.sfAiRetry=function(id){sfAiGenerate(id,sfAiLastPrompt);};
        </script>
        <?php
    }
}

// AJAX handler for AI content generation
add_action('wp_ajax_sf_ai_generate', function() {
    check_ajax_referer('sf_ai_content','nonce');
    if(!current_user_can('edit_posts')) wp_send_json_error('Unauthorized');
    $prompt = sanitize_textarea_field($_POST['prompt'] ?? '');
    $model  = sanitize_text_field($_POST['model'] ?? 'gpt-4o-mini');
    $system = sanitize_textarea_field($_POST['system'] ?? '');
    $api_key = get_option('themeflex_openai_api_key','');
    if(!$api_key) wp_send_json_error('API key not configured');
    if(!$prompt) wp_send_json_error('Empty prompt');
    $response = wp_remote_post('https://api.openai.com/v1/chat/completions',[
        'headers'=>['Content-Type'=>'application/json','Authorization'=>'Bearer '.$api_key],
        'body'=>wp_json_encode(['model'=>$model,'messages'=>[['role'=>'system','content'=>$system],['role'=>'user','content'=>$prompt]],'max_tokens'=>800,'temperature'=>0.7]),
        'timeout'=>30,
    ]);
    if(is_wp_error($response)) wp_send_json_error($response->get_error_message());
    $body = json_decode(wp_remote_retrieve_body($response),true);
    $content = $body['choices'][0]['message']['content'] ?? '';
    if(empty($content)) wp_send_json_error('No content returned');
    wp_send_json_success(['content'=>$content]);
});

// AJAX handler for newsletter
add_action('wp_ajax_sf_newsletter_subscribe',        'sf_newsletter_subscribe_handler');
add_action('wp_ajax_nopriv_sf_newsletter_subscribe', 'sf_newsletter_subscribe_handler');
function sf_newsletter_subscribe_handler() {
    check_ajax_referer('sf_nl_nonce','nonce');
    $email = sanitize_email($_POST['email'] ?? '');
    if(!$email || !is_email($email)) wp_send_json_error('Invalid email');
    do_action('sf_newsletter_subscribe', $email);
    wp_send_json_success(['message'=>'Subscribed']);
}
