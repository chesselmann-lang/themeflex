<?php
/**
 * Alert / Notification Bar Widget
 * Info, Success, Warning, Error — mit optionalem Icon + Schließen-Button.
 *
 * @package ThemeFlex
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class ThemeFlex_Alert_Box_Widget extends \Elementor\Widget_Base {

	public function get_name()  { return 'sf_alert_box'; }
	public function get_title() { return esc_html__( 'Alert Box', 'themeflex' ); }
	public function get_icon()  { return 'eicon-alert'; }
	public function get_categories() { return [ 'themeflex' ]; }
	public function get_keywords()   { return [ 'alert', 'notice', 'info', 'warning', 'notification', 'message' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'section_content', [ 'label' => esc_html__( 'Content', 'themeflex' ) ] );

		$this->add_control( 'alert_type', [
			'label'   => esc_html__( 'Type', 'themeflex' ),
			'type'    => \Elementor\Controls_Manager::SELECT,
			'options' => [
				'info'    => 'Info (Blue)',
				'success' => 'Success (Green)',
				'warning' => 'Warning (Orange)',
				'error'   => 'Error (Red)',
				'custom'  => 'Custom',
			],
			'default' => 'info',
		] );
		$this->add_control( 'title', [ 'label' => esc_html__( 'Title', 'themeflex' ), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Heads up!' ] );
		$this->add_control( 'message', [
			'label'   => esc_html__( 'Message', 'themeflex' ),
			'type'    => \Elementor\Controls_Manager::TEXTAREA,
			'default' => 'This is an important notice. Please read carefully.',
		] );
		$this->add_control( 'show_icon',    [ 'label' => 'Show Icon',      'type' => \Elementor\Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'dismissible',  [ 'label' => 'Dismissible',    'type' => \Elementor\Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'custom_icon',  [ 'label' => 'Custom Icon',    'type' => \Elementor\Controls_Manager::ICONS, 'condition' => [ 'show_icon' => 'yes' ] ] );

		$this->end_controls_section();

		$this->start_controls_section( 'section_style', [ 'label' => 'Style', 'tab' => \Elementor\Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'custom_bg',    [ 'label' => 'Background', 'type' => \Elementor\Controls_Manager::COLOR, 'condition' => [ 'alert_type' => 'custom' ], 'selectors' => [ '{{WRAPPER}} .sf-alert' => 'background: {{VALUE}};' ] ] );
		$this->add_control( 'custom_color', [ 'label' => 'Text Color',  'type' => \Elementor\Controls_Manager::COLOR, 'condition' => [ 'alert_type' => 'custom' ], 'selectors' => [ '{{WRAPPER}} .sf-alert' => 'color: {{VALUE}};' ] ] );
		$this->add_control( 'border_left',  [ 'label' => 'Left Border', 'type' => \Elementor\Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_responsive_control( 'padding', [
			'label'      => 'Padding',
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => [ 'px', 'em' ],
			'selectors'  => [ '{{WRAPPER}} .sf-alert' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
		] );
		$this->end_controls_section();
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$type = $s['alert_type'];
		$uid  = 'sf-alert-' . $this->get_id();

		$presets = [
			'info'    => [ 'bg' => '#eff6ff', 'border' => '#3b82f6', 'color' => '#1e40af', 'icon' => 'fa-circle-info' ],
			'success' => [ 'bg' => '#ecfdf5', 'border' => '#10b981', 'color' => '#065f46', 'icon' => 'fa-circle-check' ],
			'warning' => [ 'bg' => '#fffbeb', 'border' => '#f59e0b', 'color' => '#92400e', 'icon' => 'fa-triangle-exclamation' ],
			'error'   => [ 'bg' => '#fef2f2', 'border' => '#ef4444', 'color' => '#991b1b', 'icon' => 'fa-circle-xmark' ],
		];
		$p = isset( $presets[$type] ) ? $presets[$type] : [ 'bg' => '#f8fafc', 'border' => '#94a3b8', 'color' => '#1e293b', 'icon' => 'fa-bell' ];

		$icon_class = ( ! empty( $s['custom_icon']['value'] ) ) ? $s['custom_icon']['value'] : 'fa-solid ' . $p['icon'];
		$border_style = 'yes' === $s['border_left'] ? 'border-left:4px solid ' . $p['border'] . ';' : '';

		$inline = 'background:' . $p['bg'] . ';color:' . $p['color'] . ';border-radius:8px;padding:16px 20px;display:flex;align-items:flex-start;gap:14px;position:relative;' . $border_style;
		?>
		<div class="sf-alert sf-alert--<?php echo esc_attr($type); ?>" id="<?php echo esc_attr($uid); ?>" role="alert" style="<?php echo esc_attr($inline); ?>">
			<?php if ( 'yes' === $s['show_icon'] ) : ?>
			<span style="font-size:20px;flex-shrink:0;padding-top:2px;"><i class="fa-solid <?php echo esc_attr($icon_class); ?>" aria-hidden="true"></i></span>
			<?php endif; ?>
			<div style="flex:1;">
				<?php if ( $s['title'] ) : ?><strong style="display:block;margin-bottom:4px;"><?php echo esc_html($s['title']); ?></strong><?php endif; ?>
				<p style="margin:0;font-size:14px;line-height:1.6;"><?php echo wp_kses_post($s['message']); ?></p>
			</div>
			<?php if ( 'yes' === $s['dismissible'] ) : ?>
			<button onclick="this.closest('.sf-alert').style.display='none';" aria-label="<?php esc_attr_e('Dismiss','themeflex'); ?>" style="background:none;border:none;cursor:pointer;font-size:20px;line-height:1;color:inherit;opacity:.6;padding:0;flex-shrink:0;">&times;</button>
			<?php endif; ?>
		</div>
		<?php
	}
}
