<?php
/**
 * Announcement Bar Widget
 * @package ThemeFlex
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Announcement_Bar_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'announcement_bar'; }
    public function get_title() { return esc_html__('Announcement Bar','themeflex'); }
    public function get_icon()  { return 'eicon-banner'; }
    public function get_categories() { return ['themeflex']; }
    public function get_keywords()   { return ['announcement','bar','banner','top','notification','promo']; }

    protected function register_controls() {
        $this->start_controls_section('s1',['label'=>'Content']);
        $this->add_control('text',['label'=>'Message','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>'🔥 Limited Time Offer: Get 30% off with code LAUNCH30']);
        $this->add_control('cta_text',['label'=>'CTA Text','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Shop Now →']);
        $this->add_control('cta_url',['label'=>'CTA URL','type'=>\Elementor\Controls_Manager::URL]);
        $this->add_control('dismissible',['label'=>'Dismissible','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes']);
        $this->add_control('position',['label'=>'Position','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['top'=>'Top','bottom'=>'Bottom'],'default'=>'top']);
        $this->add_control('bg_color',['label'=>'Background','type'=>\Elementor\Controls_Manager::COLOR,'selectors'=>['body .sf-ann-bar'=>'background:{{VALUE}};']]);
        $this->add_control('text_color',['label'=>'Text Color','type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#fff','selectors'=>['body .sf-ann-bar'=>'color:{{VALUE}};']]);
        $this->end_controls_section();
    }

    protected function render() {
        $s   = $this->get_settings_for_display();
        $uid = 'sf-ann-' . $this->get_id();
        $pos = isset( $s['position'] ) ? $s['position'] : 'top';
        $cta = ! empty( $s['cta_url']['url'] ) ? esc_url( $s['cta_url']['url'] ) : '';
        $cta_ext = ! empty( $s['cta_url']['is_external'] ) ? ' target="_blank" rel="noopener noreferrer"' : '';
        $dis = 'yes' === ( isset( $s['dismissible'] ) ? $s['dismissible'] : 'yes' );
        list( $v, $h ) = strpos( $pos, '-' ) !== false ? explode( '-', $pos ) : array( $pos, 'left' );
        ?>
        <div class="sf-ann-bar" id="<?php echo esc_attr( $uid ); ?>"
             style="position:fixed;<?php echo esc_attr( $v ); ?>:0;left:0;right:0;z-index:9999;background:var(--sf-primary,#FF5E2E);color:#fff;padding:10px 48px 10px 24px;text-align:center;font-size:14px;font-weight:500;display:flex;align-items:center;justify-content:center;gap:16px;"
             role="banner" aria-label="<?php esc_attr_e( 'Announcement', 'themeflex' ); ?>">
            <span><?php echo wp_kses_post( $s['text'] ); ?></span>
            <?php if ( $cta && ! empty( $s['cta_text'] ) ) : ?>
                <a href="<?php echo $cta; ?>"<?php echo $cta_ext; ?> style="font-weight:700;color:inherit;text-decoration:underline;white-space:nowrap;"><?php echo esc_html( $s['cta_text'] ); ?></a>
            <?php endif; ?>
            <?php if ( $dis ) : ?>
                <button onclick="var b=document.getElementById('<?php echo esc_js( $uid ); ?>');if(b){b.style.display='none';document.body.style.padding<?php echo ucfirst( esc_js( $v ) ); ?>='0';}"
                        aria-label="<?php esc_attr_e( 'Close announcement', 'themeflex' ); ?>"
                        style="position:absolute;<?php echo esc_attr( $h === 'right' ? 'right' : 'right' ); ?>:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:inherit;font-size:22px;cursor:pointer;line-height:1;opacity:.8;padding:4px;">&times;</button>
            <?php endif; ?>
        </div>
        <script>
        (function(){
            var bar = document.getElementById('<?php echo esc_js( $uid ); ?>');
            if (!bar) return;
            var h = bar.offsetHeight || 40;
            document.body.style.padding<?php echo ucfirst( esc_js( $v ) ); ?> = h + 'px';
        })();
        </script>
        <?php
    }
}
