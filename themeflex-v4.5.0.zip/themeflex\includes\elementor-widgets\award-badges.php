<?php
/**
 * Awards & Trust Badges Widget
 * @package ThemeFlex
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Award_Badges_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'award_badges'; }
    public function get_title() { return esc_html__('Awards & Trust Badges','themeflex'); }
    public function get_icon()  { return 'eicon-medal'; }
    public function get_categories() { return ['themeflex']; }
    public function get_keywords()   { return ['awards','badges','trust','certifications','logos','accreditation']; }

    protected function register_controls() {
        $this->start_controls_section('s1',['label'=>'Badges']);
        $repeater=new \Elementor\Repeater();
        $repeater->add_control('badge_image',['label'=>'Badge Image','type'=>\Elementor\Controls_Manager::MEDIA]);
        $repeater->add_control('badge_title',['label'=>'Title','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Award 2024']);
        $repeater->add_control('badge_org',['label'=>'Organization','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Design Awards']);
        $repeater->add_control('badge_url',['label'=>'Link','type'=>\Elementor\Controls_Manager::URL]);
        $this->add_control('badges',['type'=>\Elementor\Controls_Manager::REPEATER,'fields'=>$repeater->get_controls(),'default'=>[
            ['badge_title'=>'Best WordPress Theme 2024','badge_org'=>'ThemeForest'],
            ['badge_title'=>'Top Rated Item','badge_org'=>'Envato'],
            ['badge_title'=>'Staff Pick','badge_org'=>'CSS Design Awards'],
            ['badge_title'=>'5-Star Support','badge_org'=>'Envato'],
        ],'title_field'=>'{{{ badge_title }}}']);
        $this->add_responsive_control('cols',['label'=>'Columns','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['2'=>'2','3'=>'3','4'=>'4','5'=>'5','6'=>'6'],'default'=>'4']);
        $this->add_control('style',['label'=>'Style','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['card'=>'Card','minimal'=>'Minimal'],'default'=>'card']);
        $this->end_controls_section();
    }

    protected function render() {
        $s     = $this->get_settings_for_display();
        $style = isset( $s['style'] ) ? $s['style'] : 'card';
        $cols  = isset( $s['cols'] ) ? absint( $s['cols'] ) : 4;
        $badges = $s['badges'] ?? array();

        if ( empty( $badges ) ) {
            echo '<p>' . esc_html__( 'Please add badges.', 'themeflex' ) . '</p>';
            return;
        }

        $is_card = 'card' === $style;
        ?>
        <div class="sf-award-badges" style="display:grid;grid-template-columns:repeat(<?php echo absint( $cols ); ?>,1fr);gap:16px;">
            <?php foreach ( $badges as $b ) :
                $img  = ! empty( $b['badge_image']['url'] ) ? $b['badge_image']['url'] : '';
                $url  = ! empty( $b['badge_url']['url'] )   ? esc_url( $b['badge_url']['url'] ) : '';
                $ext  = ! empty( $b['badge_url']['is_external'] ) ? ' target="_blank" rel="noopener noreferrer"' : '';
                $el   = $url ? 'a' : 'div';
            ?>
            <<?php echo esc_attr( $el ); ?>
                <?php if ( $url ) : ?>href="<?php echo $url; ?>"<?php echo $ext; ?><?php endif; ?>
                class="sf-award-badge-item"
                style="<?php if ( $is_card ) echo 'background:var(--sf-alt-bg,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:12px;padding:20px 16px;'; ?>display:flex;flex-direction:column;align-items:center;gap:10px;text-align:center;text-decoration:none;transition:transform .25s ease,border-color .25s ease;"
                <?php if ( $is_card ) : ?>
                    onmouseover="this.style.transform='translateY(-4px)';this.style.borderColor='var(--sf-primary,#FF5E2E)'"
                    onmouseout="this.style.transform='translateY(0)';this.style.borderColor='var(--sf-border,#e5e7eb)'"
                <?php endif; ?>>
                <?php if ( $img ) : ?>
                    <img src="<?php echo esc_url( $img ); ?>"
                         alt="<?php echo esc_attr( $b['badge_title'] ?? '' ); ?>"
                         style="max-height:60px;width:auto;object-fit:contain;display:block;"
                         loading="lazy" />
                <?php else : ?>
                    <div style="width:52px;height:52px;border-radius:50%;background:linear-gradient(135deg,var(--sf-primary,#FF5E2E),#ED4C1C);display:flex;align-items:center;justify-content:center;font-size:24px;" role="img" aria-label="<?php echo esc_attr( $b['badge_title'] ?? 'Award' ); ?>">&#127942;</div>
                <?php endif; ?>
                <div style="font-weight:700;font-size:13px;color:var(--sf-title,#1e293b);line-height:1.3;"><?php echo esc_html( $b['badge_title'] ?? '' ); ?></div>
                <?php if ( ! empty( $b['badge_org'] ) ) : ?>
                    <div style="font-size:11px;color:var(--sf-muted,#94a3b8);"><?php echo esc_html( $b['badge_org'] ); ?></div>
                <?php endif; ?>
            </<?php echo esc_attr( $el ); ?>>
            <?php endforeach; ?>
        </div>
        <style>
        @media(max-width:640px){.sf-award-badges{grid-template-columns:repeat(2,1fr)!important;}}
        @media(max-width:360px){.sf-award-badges{grid-template-columns:repeat(1,1fr)!important;}}
        </style>
        <?php
    }
}
