<?php
/**
 * Elementor Before/After Slider Widget
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Before/After Slider Widget Class
 *
 * @since 1.0.0
 */
class ThemeFlex_Before_After_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'themeflex_before_after';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Before/After Slider', 'themeflex' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-image-before-after';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'themeflex' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Before Image
		$this->add_control(
			'before_image',
			array(
				'label'   => esc_html__( 'Before Image', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => array(
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				),
			)
		);

		// After Image
		$this->add_control(
			'after_image',
			array(
				'label'   => esc_html__( 'After Image', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => array(
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				),
			)
		);

		// Orientation
		$this->add_control(
			'orientation',
			array(
				'label'   => esc_html__( 'Orientation', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'horizontal',
				'options' => array(
					'horizontal' => esc_html__( 'Horizontal', 'themeflex' ),
					'vertical'   => esc_html__( 'Vertical', 'themeflex' ),
				),
			)
		);

		// Before Label
		$this->add_control(
			'before_label',
			array(
				'label'       => esc_html__( 'Before Label', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Before', 'themeflex' ),
				'placeholder' => esc_html__( 'Enter before label', 'themeflex' ),
			)
		);

		// After Label
		$this->add_control(
			'after_label',
			array(
				'label'       => esc_html__( 'After Label', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'After', 'themeflex' ),
				'placeholder' => esc_html__( 'Enter after label', 'themeflex' ),
			)
		);

		// Initial Position
		$this->add_control(
			'initial_position',
			array(
				'label'   => esc_html__( 'Initial Position (%)', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 50,
				),
				'range'   => array(
					'%' => array(
						'min' => 0,
						'max' => 100,
					),
				),
			)
		);

		$this->end_controls_section();

		// Handle Style Section
		$this->start_controls_section(
			'handle_style_section',
			array(
				'label' => esc_html__( 'Handle', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'handle_width',
			array(
				'label'   => esc_html__( 'Handle Width (px)', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 4,
				),
				'range'   => array(
					'px' => array(
						'min' => 1,
						'max' => 10,
					),
				),
			)
		);

		$this->add_control(
			'handle_color',
			array(
				'label'     => esc_html__( 'Handle Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .before-after-slider .ba-handle' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'handle_shadow',
			array(
				'label'     => esc_html__( 'Handle Shadow', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::BOX_SHADOW,
				'default'   => array(
					'horizontal' => 0,
					'vertical'   => 0,
					'blur'       => 10,
					'spread'     => 0,
					'color'      => 'rgba(0,0,0,0.3)',
				),
				'selectors' => array(
					'{{WRAPPER}} .before-after-slider .ba-handle' => 'box-shadow: {{HORIZONTAL}}px {{VERTICAL}}px {{BLUR}}px {{SPREAD}}px {{COLOR}};',
				),
			)
		);

		$this->end_controls_section();

		// Label Style Section
		$this->start_controls_section(
			'label_style_section',
			array(
				'label' => esc_html__( 'Labels', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'label_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => 'rgba(0,0,0,0.5)',
				'selectors' => array(
					'{{WRAPPER}} .before-after-slider .ba-label' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'label_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .before-after-slider .ba-label' => 'color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$before_image = isset( $settings['before_image']['url'] ) ? $settings['before_image']['url'] : '';
		$after_image = isset( $settings['after_image']['url'] ) ? $settings['after_image']['url'] : '';
		$orientation = isset( $settings['orientation'] ) ? $settings['orientation'] : 'horizontal';
		$before_label = isset( $settings['before_label'] ) ? $settings['before_label'] : esc_html__( 'Before', 'themeflex' );
		$after_label = isset( $settings['after_label'] ) ? $settings['after_label'] : esc_html__( 'After', 'themeflex' );
		$initial_pos = isset( $settings['initial_position']['size'] ) ? intval( $settings['initial_position']['size'] ) : 50;
		$handle_width = isset( $settings['handle_width']['size'] ) ? intval( $settings['handle_width']['size'] ) : 4;

		if ( empty( $before_image ) || empty( $after_image ) ) {
			echo '<p>' . esc_html__( 'Please select both before and after images', 'themeflex' ) . '</p>';
			return;
		}

		?>
		<div class="before-after-slider" data-orientation="<?php echo esc_attr( $orientation ); ?>" data-position="<?php echo esc_attr( $initial_pos ); ?>" style="--ba-initial-pos: <?php echo esc_attr( $initial_pos ); ?>%; --ba-handle-width: <?php echo esc_attr( $handle_width ); ?>px;">
			<div class="ba-container">
				<img src="<?php echo esc_url( $before_image ); ?>" alt="<?php echo esc_attr( $before_label ); ?>" class="ba-before" />
				<div class="ba-after-wrapper" style="<?php echo 'horizontal' === $orientation ? 'width: ' . esc_attr( $initial_pos ) . '%;' : 'height: ' . esc_attr( $initial_pos ) . '%;'; ?>">
					<img src="<?php echo esc_url( $after_image ); ?>" alt="<?php echo esc_attr( $after_label ); ?>" class="ba-after" />
					<div class="ba-label ba-after-label"><?php echo esc_html( $after_label ); ?></div>
				</div>
				<div class="ba-label ba-before-label"><?php echo esc_html( $before_label ); ?></div>
				<div class="ba-handle" role="slider" aria-label="<?php esc_attr_e( 'Image comparison slider', 'themeflex' ); ?>" tabindex="0">
					<span class="ba-arrow ba-arrow-left"></span>
					<span class="ba-arrow ba-arrow-right"></span>
				</div>
			</div>
		</div>
		<?php
	}
}
