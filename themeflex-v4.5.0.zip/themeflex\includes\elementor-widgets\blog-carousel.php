<?php
/**
 * Elementor Blog Posts Carousel Widget
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Blog Carousel Widget Class
 *
 * @since 1.0.0
 */
class ThemeFlex_Blog_Carousel_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'themeflex_blog_carousel';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Blog Carousel', 'themeflex' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-post-list';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'themeflex' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Post Count
		$this->add_control(
			'post_count',
			array(
				'label'   => esc_html__( 'Number of Posts', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 5,
				'min'     => 1,
				'max'     => 20,
			)
		);

		// Category Filter
		$this->add_control(
			'post_category',
			array(
				'label'       => esc_html__( 'Category', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'options'     => $this->get_categories_options(),
				'default'     => '',
				'label_block' => true,
			)
		);

		// Order By
		$this->add_control(
			'orderby',
			array(
				'label'   => esc_html__( 'Order By', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'date',
				'options' => array(
					'date'       => esc_html__( 'Date', 'themeflex' ),
					'title'      => esc_html__( 'Title', 'themeflex' ),
					'modified'   => esc_html__( 'Modified', 'themeflex' ),
					'rand'       => esc_html__( 'Random', 'themeflex' ),
					'menu_order' => esc_html__( 'Menu Order', 'themeflex' ),
				),
			)
		);

		// Order Direction
		$this->add_control(
			'order',
			array(
				'label'   => esc_html__( 'Order', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => array(
					'ASC'  => esc_html__( 'Ascending', 'themeflex' ),
					'DESC' => esc_html__( 'Descending', 'themeflex' ),
				),
			)
		);

		// Autoplay
		$this->add_control(
			'autoplay',
			array(
				'label'        => esc_html__( 'Autoplay', 'themeflex' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'themeflex' ),
				'label_off'    => esc_html__( 'No', 'themeflex' ),
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		// Autoplay Speed
		$this->add_control(
			'autoplay_speed',
			array(
				'label'       => esc_html__( 'Autoplay Speed (ms)', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'default'     => 5000,
				'min'         => 1000,
				'max'         => 10000,
				'condition'   => array(
					'autoplay' => 'yes',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Card
		$this->start_controls_section(
			'card_style_section',
			array(
				'label' => esc_html__( 'Card Style', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'card_background_color',
			array(
				'label'     => esc_html__( 'Background Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FFFFFF',
				'selectors' => array(
					'{{WRAPPER}} .blog-card' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'card_box_shadow',
				'label'    => esc_html__( 'Shadow', 'themeflex' ),
				'selector' => '{{WRAPPER}} .blog-card',
			)
		);

		$this->end_controls_section();

		// Style Section - Typography
		$this->start_controls_section(
			'typography_section',
			array(
				'label' => esc_html__( 'Typography', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'title_typography',
				'label'    => esc_html__( 'Title Typography', 'themeflex' ),
				'selector' => '{{WRAPPER}} .blog-card-title',
			)
		);

		$this->end_controls_section();

		// Style Section - Button
		$this->start_controls_section(
			'button_style_section',
			array(
				'label' => esc_html__( 'Button Style', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'button_color',
			array(
				'label'     => esc_html__( 'Button Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#0066cc',
				'selectors' => array(
					'{{WRAPPER}} .blog-read-more' => 'color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Get categories options
	 *
	 * @return array
	 */
	private function get_categories_options() {
		$options = array( '' => esc_html__( 'All Categories', 'themeflex' ) );

		$categories = get_categories( array(
			'hide_empty' => false,
		) );

		foreach ( $categories as $category ) {
			$options[ $category->term_id ] = $category->name;
		}

		return $options;
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$post_count = isset( $settings['post_count'] ) ? intval( $settings['post_count'] ) : 5;
		$category = isset( $settings['post_category'] ) ? $settings['post_category'] : '';
		$orderby = isset( $settings['orderby'] ) ? $settings['orderby'] : 'date';
		$order = isset( $settings['order'] ) ? $settings['order'] : 'DESC';
		$autoplay = isset( $settings['autoplay'] ) ? $settings['autoplay'] : '';
		$autoplay_speed = isset( $settings['autoplay_speed'] ) ? intval( $settings['autoplay_speed'] ) : 5000;

		// Query args
		$args = array(
			'post_type'      => 'post',
			'posts_per_page' => $post_count,
			'orderby'        => $orderby,
			'order'          => $order,
		);

		if ( ! empty( $category ) ) {
			$args['cat'] = intval( $category );
		}

		$query = new \WP_Query( $args );

		if ( ! $query->have_posts() ) {
			echo '<p>' . esc_html__( 'No posts found', 'themeflex' ) . '</p>';
			return;
		}

		$autoplay_class = 'yes' === $autoplay ? 'autoplay' : '';

		echo '<div class="blog-carousel ' . esc_attr( $autoplay_class ) . '" data-autoplay="' . esc_attr( $autoplay ) . '" data-speed="' . esc_attr( $autoplay_speed ) . '">';
		echo '<div class="carousel-inner">';

		while ( $query->have_posts() ) {
			$query->the_post();

			$post_id = get_the_ID();
			$thumbnail_url = has_post_thumbnail( $post_id ) ? get_the_post_thumbnail_url( $post_id, 'large' ) : '';

			echo '<div class="blog-card">';

			// Thumbnail
			if ( ! empty( $thumbnail_url ) ) {
				printf(
					'<img src="%s" alt="%s" class="blog-thumbnail" loading="lazy" />',
					esc_url( $thumbnail_url ),
					esc_attr( get_the_title() )
				);
			}

			echo '<div class="blog-card-content">';

			// Date
			printf(
				'<span class="blog-date">%s</span>',
				esc_html( get_the_date() )
			);

			// Title
			printf(
				'<h3 class="blog-card-title"><a href="%s">%s</a></h3>',
				esc_url( get_the_permalink() ),
				esc_html( get_the_title() )
			);

			// Excerpt
			printf(
				'<p class="blog-excerpt">%s</p>',
				esc_html( wp_trim_words( get_the_excerpt(), 15 ) )
			);

			// Read More Button
			printf(
				'<a href="%s" class="blog-read-more">%s</a>',
				esc_url( get_the_permalink() ),
				esc_html__( 'Read More', 'themeflex' )
			);

			echo '</div>';
			echo '</div>';
		}

		wp_reset_postdata();

		echo '</div>';

		// Navigation buttons
		echo '<button class="carousel-prev" aria-label="' . esc_attr__( 'Previous', 'themeflex' ) . '"><i class="eicon-chevron-left"></i></button>';
		echo '<button class="carousel-next" aria-label="' . esc_attr__( 'Next', 'themeflex' ) . '"><i class="eicon-chevron-right"></i></button>';

		// Dots navigation
		echo '<div class="carousel-dots">';
		for ( $i = 0; $i < $query->post_count; $i++ ) {
			echo '<span class="dot" data-index="' . esc_attr( $i ) . '"></span>';
		}
		echo '</div>';

		echo '</div>';
	}
}
