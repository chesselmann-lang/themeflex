<?php
/**
 * Elementor Breadcrumbs Widget
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Breadcrumbs Widget Class
 *
 * @since 1.0.0
 */
class ThemeFlex_Breadcrumbs_Widget_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'themeflex_breadcrumbs_widget';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Breadcrumbs', 'themeflex' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-breadcrumbs';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'themeflex' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Settings', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Separator Type
		$this->add_control(
			'separator_type',
			array(
				'label'   => esc_html__( 'Separator Type', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'text',
				'options' => array(
					'text' => esc_html__( 'Text', 'themeflex' ),
					'icon' => esc_html__( 'Icon', 'themeflex' ),
				),
			)
		);

		// Separator Text
		$this->add_control(
			'separator_text',
			array(
				'label'       => esc_html__( 'Separator', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '/',
				'placeholder' => esc_html__( 'Enter separator', 'themeflex' ),
				'condition'   => array(
					'separator_type' => 'text',
				),
			)
		);

		// Separator Icon
		$this->add_control(
			'separator_icon',
			array(
				'label'     => esc_html__( 'Separator Icon', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::ICONS,
				'default'   => array(
					'value'   => 'fas fa-chevron-right',
					'library' => 'fa-solid',
				),
				'condition' => array(
					'separator_type' => 'icon',
				),
			)
		);

		// Show Home
		$this->add_control(
			'show_home',
			array(
				'label'        => esc_html__( 'Show Home Link', 'themeflex' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'themeflex' ),
				'label_off'    => esc_html__( 'No', 'themeflex' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		// Home Label
		$this->add_control(
			'home_label',
			array(
				'label'       => esc_html__( 'Home Label', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Home', 'themeflex' ),
				'placeholder' => esc_html__( 'Home label text', 'themeflex' ),
				'condition'   => array(
					'show_home' => 'yes',
				),
			)
		);

		// Show Current Page
		$this->add_control(
			'show_current_page',
			array(
				'label'        => esc_html__( 'Show Current Page', 'themeflex' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'themeflex' ),
				'label_off'    => esc_html__( 'No', 'themeflex' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		// Schema Markup
		$this->add_control(
			'schema_markup',
			array(
				'label'        => esc_html__( 'Add Schema.org Markup', 'themeflex' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'themeflex' ),
				'label_off'    => esc_html__( 'No', 'themeflex' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->end_controls_section();

		// Style Section
		$this->start_controls_section(
			'style_section',
			array(
				'label' => esc_html__( 'Style', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#666666',
				'selectors' => array(
					'{{WRAPPER}} .breadcrumb' => 'color: {{VALUE}};',
					'{{WRAPPER}} .breadcrumb-separator' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'link_color',
			array(
				'label'     => esc_html__( 'Link Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#0066cc',
				'selectors' => array(
					'{{WRAPPER}} .breadcrumb a' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'link_hover_color',
			array(
				'label'     => esc_html__( 'Link Hover Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FF5E2E',
				'selectors' => array(
					'{{WRAPPER}} .breadcrumb a:hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'current_color',
			array(
				'label'     => esc_html__( 'Current Page Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#333333',
				'selectors' => array(
					'{{WRAPPER}} .breadcrumb-current' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'typography',
				'label'    => esc_html__( 'Typography', 'themeflex' ),
				'selector' => '{{WRAPPER}} .breadcrumbs-list',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$separator_type = isset( $settings['separator_type'] ) ? $settings['separator_type'] : 'text';
		$separator_text = isset( $settings['separator_text'] ) ? $settings['separator_text'] : '/';
		$separator_icon = isset( $settings['separator_icon']['value'] ) ? $settings['separator_icon']['value'] : 'fas fa-chevron-right';
		$show_home = isset( $settings['show_home'] ) && 'yes' === $settings['show_home'];
		$home_label = isset( $settings['home_label'] ) ? $settings['home_label'] : esc_html__( 'Home', 'themeflex' );
		$show_current = isset( $settings['show_current_page'] ) && 'yes' === $settings['show_current_page'];
		$schema_markup = isset( $settings['schema_markup'] ) && 'yes' === $settings['schema_markup'];

		$breadcrumbs = array();

		// Add home breadcrumb
		if ( $show_home ) {
			$breadcrumbs[] = array(
				'url'   => home_url( '/' ),
				'title' => $home_label,
				'current' => false,
			);
		}

		// Build breadcrumb trail
		if ( is_home() ) {
			// Blog page
			$breadcrumbs[] = array(
				'url'     => '',
				'title'   => get_the_title( get_option( 'page_for_posts' ) ),
				'current' => true,
			);
		} elseif ( is_singular() ) {
			// Single post/page
			$post = get_queried_object();
			if ( isset( $post->post_parent ) && $post->post_parent ) {
				// Get parent pages
				$ancestors = get_post_ancestors( $post );
				$ancestors = array_reverse( $ancestors );
				foreach ( $ancestors as $ancestor ) {
					$breadcrumbs[] = array(
						'url'     => get_permalink( $ancestor ),
						'title'   => get_the_title( $ancestor ),
						'current' => false,
					);
				}
			}
			if ( $show_current ) {
				$breadcrumbs[] = array(
					'url'     => '',
					'title'   => get_the_title( $post ),
					'current' => true,
				);
			}
		} elseif ( is_category() || is_tag() ) {
			// Category or tag
			if ( $show_current ) {
				$breadcrumbs[] = array(
					'url'     => '',
					'title'   => single_term_title( '', false ),
					'current' => true,
				);
			}
		} elseif ( is_archive() ) {
			// Archive page
			if ( $show_current ) {
				$breadcrumbs[] = array(
					'url'     => '',
					'title'   => esc_html__( 'Archives', 'themeflex' ),
					'current' => true,
				);
			}
		}

		if ( empty( $breadcrumbs ) && ! $show_home ) {
			return;
		}

		?>
		<nav class="breadcrumbs-nav sf-breadcrumbs" role="navigation" aria-label="<?php esc_attr_e( 'Breadcrumb', 'themeflex' ); ?>">
			<?php if ( $schema_markup ) :
				$schema_items = array();
				foreach ( $breadcrumbs as $index => $item ) {
					$schema_items[] = array(
						'@type'    => 'ListItem',
						'position' => $index + 1,
						'name'     => $item['title'],
						'item'     => ! empty( $item['url'] ) ? $item['url'] : home_url( '/' ),
					);
				}
				$schema = array(
					'@context'        => 'https://schema.org',
					'@type'           => 'BreadcrumbList',
					'itemListElement' => $schema_items,
				);
				?>
				<script type="application/ld+json"><?php echo wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ); ?></script>
			<?php endif; ?>

			<ol class="breadcrumbs-list" style="display:flex;flex-wrap:wrap;list-style:none;padding:0;margin:0;align-items:center;gap:4px;">
				<?php foreach ( $breadcrumbs as $index => $item ) : ?>
					<li class="breadcrumb <?php echo $item['current'] ? 'breadcrumb-current' : ''; ?>"
					    style="display:flex;align-items:center;gap:4px;">
						<?php if ( ! $item['current'] && ! empty( $item['url'] ) ) : ?>
							<a href="<?php echo esc_url( $item['url'] ); ?>"
							   style="transition:color .2s ease;text-decoration:none;">
								<?php echo esc_html( $item['title'] ); ?>
							</a>
						<?php else : ?>
							<span aria-current="page"><?php echo esc_html( $item['title'] ); ?></span>
						<?php endif; ?>

						<?php if ( $index < count( $breadcrumbs ) - 1 ) : ?>
							<span class="breadcrumb-separator" aria-hidden="true" style="margin-left:4px;">
								<?php if ( 'text' === $separator_type ) : ?>
									<?php echo esc_html( $separator_text ); ?>
								<?php else : ?>
									<i class="<?php echo esc_attr( $separator_icon ); ?>" style="font-size:.75em;"></i>
								<?php endif; ?>
							</span>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ol>
		</nav>
		<?php
	}
}
