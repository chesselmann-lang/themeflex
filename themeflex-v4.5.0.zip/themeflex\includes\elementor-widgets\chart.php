<?php
/**
 * Animated Chart Widget for Elementor
 * CSS-animated donut, pie, and bar charts. No canvas required.
 *
 * @package ThemeFlex
 * @since 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class ThemeFlex_Chart_Widget extends \Elementor\Widget_Base {

    public function get_name()       { return 'sf_chart'; }
    public function get_title()      { return esc_html__( 'Chart', 'themeflex' ); }
    public function get_icon()       { return 'eicon-counter-circle'; }
    public function get_categories() { return array( 'themeflex' ); }
    public function get_keywords()   { return array( 'chart', 'graph', 'pie', 'donut', 'bar', 'data' ); }

    protected function register_controls() {

        $this->start_controls_section( 'section_content', array(
            'label' => esc_html__( 'Chart', 'themeflex' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ) );

        $this->add_control( 'chart_type', array(
            'label'   => esc_html__( 'Type', 'themeflex' ),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'default' => 'donut',
            'options' => array(
                'donut' => esc_html__( 'Donut', 'themeflex' ),
                'pie'   => esc_html__( 'Pie', 'themeflex' ),
                'bar'   => esc_html__( 'Bar', 'themeflex' ),
            ),
        ) );

        $repeater = new \Elementor\Repeater();
        $repeater->add_control( 'label', array( 'label'=>esc_html__('Label','themeflex'), 'type'=>\Elementor\Controls_Manager::TEXT, 'default'=>'Item' ) );
        $repeater->add_control( 'value', array( 'label'=>esc_html__('Value (%)','themeflex'), 'type'=>\Elementor\Controls_Manager::NUMBER, 'default'=>25, 'min'=>1, 'max'=>100 ) );
        $repeater->add_control( 'color', array( 'label'=>esc_html__('Colour','themeflex'), 'type'=>\Elementor\Controls_Manager::COLOR, 'default'=>'#2563eb' ) );

        $this->add_control( 'items', array(
            'label'       => esc_html__( 'Segments', 'themeflex' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'fields'      => $repeater->get_controls(),
            'default'     => array(
                array( 'label'=>'Design',      'value'=>35, 'color'=>'#2563eb' ),
                array( 'label'=>'Development', 'value'=>40, 'color'=>'#7c3aed' ),
                array( 'label'=>'Marketing',   'value'=>25, 'color'=>'#10b981' ),
            ),
            'title_field' => '{{{ label }}} ({{{ value }}}%)',
        ) );

        $this->add_control( 'show_legend', array(
            'label'   => esc_html__( 'Show Legend', 'themeflex' ),
            'type'    => \Elementor\Controls_Manager::SWITCHER,
            'default' => 'yes',
        ) );

        $this->add_control( 'chart_size', array(
            'label'      => esc_html__( 'Chart Size (px)', 'themeflex' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => array('px'),
            'range'      => array('px'=>array('min'=>100,'max'=>400)),
            'default'    => array('unit'=>'px','size'=>200),
            'condition'  => array( 'chart_type!' => 'bar' ),
        ) );

        $this->end_controls_section();
    }

    protected function render() {
        $s    = $this->get_settings_for_display();
        $type = $s['chart_type'];
        $items= $s['items'];
        $uid  = 'sfc' . $this->get_id();
        $size = isset($s['chart_size']['size']) ? absint($s['chart_size']['size']) : 200;

        if ( 'bar' === $type ) {
            echo '<div class="sf-chart-bar" id="' . esc_attr($uid) . '">';
            foreach ( $items as $item ) {
                $val = min(100, max(1, absint($item['value'])));
                $col = esc_attr( $item['color'] );
                echo '<div class="sf-cb-row">';
                echo '<span class="sf-cb-label">' . esc_html($item['label']) . '</span>';
                echo '<div class="sf-cb-track"><div class="sf-cb-fill" data-width="' . $val . '" style="background:' . $col . ';width:0%;"></div></div>';
                echo '<span class="sf-cb-val">' . esc_html($val) . '%</span>';
                echo '</div>';
            }
            echo '</div>';
        } else {
            // Build conic-gradient
            $total = array_sum( array_column( $items, 'value' ) );
            $deg   = 0;
            $stops = array();
            foreach ( $items as $item ) {
                $pct  = $total > 0 ? ($item['value'] / $total * 360) : 0;
                $stops[] = esc_attr($item['color']) . ' ' . round($deg) . 'deg ' . round($deg + $pct) . 'deg';
                $deg += $pct;
            }
            $gradient = 'conic-gradient(' . implode(', ', $stops) . ')';
            $inner = 'donut' === $type ? round($size * 0.55) : 0;

            echo '<div class="sf-chart-circle" id="' . esc_attr($uid) . '" style="width:' . $size . 'px;height:' . $size . 'px;">';
            echo '<div class="sf-cc-pie" style="background:' . $gradient . ';border-radius:50%;width:100%;height:100%;position:relative;">';
            if ($inner) {
                echo '<div class="sf-cc-hole" style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:' . $inner . 'px;height:' . $inner . 'px;border-radius:50%;background:#fff;"></div>';
            }
            echo '</div></div>';
        }

        if ( 'yes' === $s['show_legend'] ) {
            echo '<div class="sf-chart-legend">';
            foreach ( $items as $item ) {
                echo '<div class="sf-cl-item"><span class="sf-cl-dot" style="background:' . esc_attr($item['color']) . '"></span><span class="sf-cl-label">' . esc_html($item['label']) . '</span><span class="sf-cl-val">' . esc_html($item['value']) . '%</span></div>';
            }
            echo '</div>';
        }
        ?>
        <style>
        .sf-chart-bar .sf-cb-row{display:grid;grid-template-columns:120px 1fr 40px;gap:10px;align-items:center;margin-bottom:12px;}
        .sf-cb-label{font-size:.85rem;font-weight:500;}
        .sf-cb-track{background:#f1f5f9;border-radius:100px;height:10px;overflow:hidden;}
        .sf-cb-fill{height:100%;border-radius:100px;transition:width 1.2s cubic-bezier(.4,0,.2,1);}
        .sf-cb-val{font-size:.8rem;font-weight:600;text-align:right;}
        .sf-chart-circle{margin:0 auto;}
        .sf-chart-legend{display:flex;flex-wrap:wrap;gap:12px;margin-top:16px;justify-content:center;}
        .sf-cl-item{display:flex;align-items:center;gap:6px;font-size:.85rem;}
        .sf-cl-dot{width:10px;height:10px;border-radius:50%;flex-shrink:0;}
        </style>
        <script>
        (function(){
          var bars = document.querySelectorAll('#<?php echo esc_js($uid); ?> .sf-cb-fill[data-width]');
          if(!bars.length) return;
          var obs = new IntersectionObserver(function(entries){
            entries.forEach(function(e){ if(e.isIntersecting){ e.target.style.width=e.target.getAttribute('data-width')+'%'; obs.unobserve(e.target); }});
          },{threshold:.3});
          bars.forEach(function(b){ obs.observe(b); });
        })();
        </script>
        <?php
    }
}
