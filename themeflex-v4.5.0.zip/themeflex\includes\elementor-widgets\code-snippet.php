<?php
/**
 * Code Snippet Widget
 * @package ThemeFlex
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Code_Snippet_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'code_snippet'; }
    public function get_title() { return esc_html__('Code Snippet','themeflex'); }
    public function get_icon()  { return 'eicon-code'; }
    public function get_categories() { return ['themeflex']; }
    public function get_keywords()   { return ['code','snippet','syntax','highlight','developer','programming']; }

    protected function register_controls() {
        $this->start_controls_section('s1',['label'=>'Code']);
        $this->add_control('language',['label'=>'Language','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['html'=>'HTML','css'=>'CSS','javascript'=>'JavaScript','php'=>'PHP','python'=>'Python','bash'=>'Bash','json'=>'JSON'],'default'=>'javascript']);
        $this->add_control('code',['label'=>'Code','type'=>\Elementor\Controls_Manager::CODE,'language'=>'javascript','default'=>'// Install the package\nnpm install themeflex-addons\n\n// Import and use\nimport { createWidget } from \'@themeflex/widgets\'\n\ncreateWidget({ name: \'hero\', skin: \'agency\' });']);
        $this->add_control('show_filename',['label'=>'Show Filename','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes']);
        $this->add_control('filename',['label'=>'Filename','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'example.js','condition'=>['show_filename'=>'yes']]);
        $this->add_control('show_copy',['label'=>'Copy Button','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes']);
        $this->add_control('theme',['label'=>'Color Theme','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['dark'=>'Dark','light'=>'Light'],'default'=>'dark']);
        $this->end_controls_section();
    }

    protected function render() {
        $s=$this->get_settings_for_display();$uid='sfcs-'.$this->get_id();
        $dark='dark'===($s['theme']??'dark');$bg=$dark?'#0d1117':'#f6f8fa';$col=$dark?'#e6edf3':'#24292f';
        $lang=$s['language']??'javascript';$code=$s['code']??'';
        ?>
        <div class="sf-code-block" id="<?php echo esc_attr($uid);?>" style="border-radius:12px;overflow:hidden;border:1px solid <?php echo$dark?'rgba(255,255,255,.1)':'#d0d7de';?>;">
            <div style="background:<?php echo$dark?'#161b22':'#f0f2f5';?>;padding:10px 16px;display:flex;align-items:center;justify-content:space-between;gap:8px;">
                <div style="display:flex;align-items:center;gap:8px;">
                    <span style="width:12px;height:12px;border-radius:50%;background:#ff5f57;"></span>
                    <span style="width:12px;height:12px;border-radius:50%;background:#ffbd2e;"></span>
                    <span style="width:12px;height:12px;border-radius:50%;background:#28ca41;"></span>
                    <?php if('yes'===$s['show_filename']&&$s['filename']):?>
                    <span style="font-size:12px;color:<?php echo$dark?'#8b949e':'#57606a';?>;margin-left:8px;font-family:monospace;"><?php echo esc_html($s['filename']);?></span>
                    <?php endif;?>
                </div>
                <div style="display:flex;align-items:center;gap:8px;">
                    <span style="font-size:11px;font-weight:600;padding:2px 8px;border-radius:4px;background:var(--sf-color-primary,#FF5E2E);color:#fff;text-transform:uppercase;"><?php echo esc_html($lang);?></span>
                    <?php if('yes'===$s['show_copy']):?>
                    <button onclick="sfCsCopy('<?php echo esc_js($uid);?>')" id="<?php echo esc_attr($uid);?>-cp" style="background:none;border:1px solid <?php echo$dark?'rgba(255,255,255,.15)':'#d0d7de';?>;color:<?php echo$dark?'#8b949e':'#57606a';?>;padding:3px 10px;border-radius:4px;font-size:11px;cursor:pointer;transition:all .2s;">Copy</button>
                    <?php endif;?>
                </div>
            </div>
            <pre style="margin:0;padding:20px;background:<?php echo esc_attr($bg);?>;overflow-x:auto;"><code id="<?php echo esc_attr($uid);?>-code" style="font-family:'Fira Code','JetBrains Mono',monospace;font-size:13px;line-height:1.7;color:<?php echo esc_attr($col);?>;display:block;white-space:pre;"><?php echo esc_html($code);?></code></pre>
        </div>
        <script>
        window.sfCsCopy=window.sfCsCopy||function(id){var code=document.getElementById(id+'-code');var btn=document.getElementById(id+'-cp');if(!code||!btn)return;navigator.clipboard.writeText(code.textContent).then(function(){btn.textContent='Copied!';btn.style.color='#10b981';setTimeout(function(){btn.textContent='Copy';btn.style.color='';},2000);});};
        </script>
        <?php
    }
}
