<?php
/**
 * Feature Comparison Table Widget — Wie wir vs. Konkurrenz.
 * @package ThemeFlex
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Comparison_Table_Feature_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'sf_comparison_table_feature'; }
    public function get_title() { return esc_html__('Feature Comparison Table','themeflex'); }
    public function get_icon()  { return 'eicon-table'; }
    public function get_categories() { return ['themeflex']; }
    public function get_keywords()   { return ['comparison','table','features','versus','vs','pricing']; }

    protected function register_controls() {
        $this->start_controls_section('s_columns',['label'=>'Columns']);
        $col_rep = new \Elementor\Repeater();
        $col_rep->add_control('col_name',['label'=>'Column Name','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Product']);
        $col_rep->add_control('col_highlight',['label'=>'Highlighted (Your Product)','type'=>\Elementor\Controls_Manager::SWITCHER]);
        $col_rep->add_control('col_price',['label'=>'Price Tag','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'']);
        $col_rep->add_control('col_cta',['label'=>'CTA Text','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'']);
        $col_rep->add_control('col_cta_url',['label'=>'CTA URL','type'=>\Elementor\Controls_Manager::URL]);
        $this->add_control('columns',['type'=>\Elementor\Controls_Manager::REPEATER,'fields'=>$col_rep->get_controls(),'default'=>[
            ['col_name'=>'ThemeFlex','col_highlight'=>'yes','col_price'=>'$59','col_cta'=>'Buy Now'],
            ['col_name'=>'Elementra','col_highlight'=>''],
            ['col_name'=>'Avada','col_highlight'=>''],
        ],'title_field'=>'{{{ col_name }}}']);
        $this->end_controls_section();

        $this->start_controls_section('s_rows',['label'=>'Feature Rows']);
        $row_rep = new \Elementor\Repeater();
        $row_rep->add_control('feature_name',['label'=>'Feature Name','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Feature']);
        $row_rep->add_control('col1_val',['label'=>'Col 1 Value','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'✓','description'=>'Use ✓ ✗ or any text']);
        $row_rep->add_control('col2_val',['label'=>'Col 2 Value','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'✗']);
        $row_rep->add_control('col3_val',['label'=>'Col 3 Value','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'✗']);
        $row_rep->add_control('col4_val',['label'=>'Col 4 Value (if 4 cols)','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'']);
        $this->add_control('rows',['type'=>\Elementor\Controls_Manager::REPEATER,'fields'=>$row_rep->get_controls(),'default'=>[
            ['feature_name'=>'Custom Elementor Widgets','col1_val'=>'66+','col2_val'=>'71','col3_val'=>'90+'],
            ['feature_name'=>'Professional Skins','col1_val'=>'20','col2_val'=>'1+Plugin','col3_val'=>'10'],
            ['feature_name'=>'Native Dark Mode','col1_val'=>'✓','col2_val'=>'✗','col3_val'=>'Partial'],
            ['feature_name'=>'AI Features','col1_val'=>'✓','col2_val'=>'✗','col3_val'=>'✗'],
            ['feature_name'=>'WooCommerce CSS Lines','col1_val'=>'2,300+','col2_val'=>'Partial','col3_val'=>'Full'],
            ['feature_name'=>'Price','col1_val'=>'$59','col2_val'=>'$69','col3_val'=>'$69'],
        ],'title_field'=>'{{{ feature_name }}}']);
        $this->end_controls_section();
    }

    protected function render() {
        $s    = $this->get_settings_for_display();
        $cols = $s['columns'];
        $rows = $s['rows'];
        $col_fields = ['col1_val','col2_val','col3_val','col4_val'];
        ?>
        <div style="overflow-x:auto;border-radius:16px;border:1px solid var(--sf-border,#e5e7eb);">
        <table style="width:100%;border-collapse:collapse;background:var(--sf-bg,#fff);min-width:480px;">
            <thead>
                <tr>
                    <th style="padding:20px 24px;text-align:left;font-size:13px;font-weight:700;color:var(--sf-meta,#94a3b8);text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--sf-border,#e5e7eb);">Feature</th>
                    <?php foreach($cols as $ci => $col):
                        $hl = 'yes' === ($col['col_highlight'] ?? '');
                    ?>
                    <th style="padding:20px 24px;text-align:center;border-bottom:1px solid var(--sf-border,#e5e7eb);<?php echo $hl?'background:rgba(255,94,46,.04);':''; ?>">
                        <div style="font-size:14px;font-weight:800;color:<?php echo $hl?'var(--sf-color-primary,#FF5E2E)':'var(--sf-title,#1e293b)'; ?>;margin-bottom:<?php echo ($col['col_price']||$col['col_cta'])?'6':'0'; ?>px;">
                            <?php echo esc_html($col['col_name']); ?>
                            <?php if($hl): ?><div style="display:inline-block;margin-left:6px;padding:1px 6px;border-radius:4px;background:var(--sf-color-primary,#FF5E2E);color:#fff;font-size:9px;font-weight:700;vertical-align:middle;">US</div><?php endif; ?>
                        </div>
                        <?php if($col['col_price']): ?><div style="font-size:11px;color:var(--sf-meta,#94a3b8);"><?php echo esc_html($col['col_price']); ?></div><?php endif; ?>
                    </th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach($rows as $ri => $row):
                    $stripe = $ri % 2 === 0 ? '' : 'background:var(--sf-bg-2,#f8fafc);';
                ?>
                <tr>
                    <td style="padding:14px 24px;font-size:14px;font-weight:500;color:var(--sf-title,#1e293b);border-bottom:1px solid var(--sf-border,#e5e7eb);<?php echo $stripe; ?>"><?php echo esc_html($row['feature_name']); ?></td>
                    <?php foreach($cols as $ci => $col):
                        $hl  = 'yes' === ($col['col_highlight'] ?? '');
                        $val = $row[$col_fields[$ci]] ?? '';
                        $is_check = '✓' === trim($val);
                        $is_cross = '✗' === trim($val);
                        $vcolor = $is_check ? '#10b981' : ($is_cross ? '#94a3b8' : 'var(--sf-title,#1e293b)');
                    ?>
                    <td style="padding:14px 24px;text-align:center;border-bottom:1px solid var(--sf-border,#e5e7eb);font-size:<?php echo ($is_check||$is_cross)?'18':'13'; ?>px;font-weight:<?php echo ($is_check||$is_cross)?'400':'700'; ?>;color:<?php echo $vcolor; ?>;<?php echo $hl?'background:rgba(255,94,46,.03);':$stripe; ?>">
                        <?php echo esc_html($val); ?>
                    </td>
                    <?php endforeach; ?>
                </tr>
                <?php endforeach; ?>
                <!-- CTA row -->
                <?php $has_cta = false; foreach($cols as $c){ if($c['col_cta']) $has_cta=true; } ?>
                <?php if($has_cta): ?>
                <tr>
                    <td style="padding:20px 24px;"></td>
                    <?php foreach($cols as $ci => $col):
                        $hl = 'yes' === ($col['col_highlight'] ?? '');
                        $cta_url = !empty($col['col_cta_url']['url']) ? esc_url($col['col_cta_url']['url']) : '#';
                    ?>
                    <td style="padding:16px 24px;text-align:center;<?php echo $hl?'background:rgba(255,94,46,.04);':''; ?>">
                        <?php if($col['col_cta']): ?>
                        <a href="<?php echo $cta_url; ?>" style="display:inline-block;padding:9px 20px;border-radius:8px;font-size:13px;font-weight:700;text-decoration:none;<?php echo $hl?'background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;':'background:var(--sf-bg-2,#f8fafc);color:var(--sf-title,#1e293b);border:1px solid var(--sf-border,#e5e7eb);'; ?>"><?php echo esc_html($col['col_cta']); ?></a>
                        <?php endif; ?>
                    </td>
                    <?php endforeach; ?>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
        </div>
        <style>
        [data-theme=dark] table{background:var(--sf-alt-bg-2,#1e293b)!important;}
        [data-theme=dark] td,[data-theme=dark] th{border-color:var(--sf-alt-border,rgba(255,255,255,.08))!important;}
        </style>
        <?php
    }
}
