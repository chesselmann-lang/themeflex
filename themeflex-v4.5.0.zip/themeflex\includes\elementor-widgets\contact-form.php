<?php
/**
 * Elementor Contact Form 7 / WPForms Styling Widget
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Contact Form Widget Class
 *
 * @since 1.0.0
 */
class ThemeFlex_Contact_Form_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'themeflex_contact_form';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Contact Form Styler', 'themeflex' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-form-horizontal';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'themeflex' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Form', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Form Shortcode
		$this->add_control(
			'form_shortcode',
			array(
				'label'       => esc_html__( 'Form Shortcode', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'default'     => '[contact-form-7 id="1" title="Contact form 1"]',
				'placeholder' => esc_html__( 'e.g., [contact-form-7 id="1" title="Contact form 1"] or [wpforms id="1"]', 'themeflex' ),
				'description' => esc_html__( 'Paste your Contact Form 7 or WPForms shortcode here', 'themeflex' ),
			)
		);

		$this->end_controls_section();

		// Style Preset Section
		$this->start_controls_section(
			'style_preset_section',
			array(
				'label' => esc_html__( 'Style Preset', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Form Style Preset
		$this->add_control(
			'form_style_preset',
			array(
				'label'   => esc_html__( 'Style Preset', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'modern',
				'options' => array(
					'modern'  => esc_html__( 'Modern', 'themeflex' ),
					'classic' => esc_html__( 'Classic', 'themeflex' ),
					'minimal' => esc_html__( 'Minimal', 'themeflex' ),
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Input Fields
		$this->start_controls_section(
			'input_style_section',
			array(
				'label' => esc_html__( 'Input Fields', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Input Background
		$this->add_control(
			'input_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#F9FAFB',
				'selectors' => array(
					'{{WRAPPER}} .contact-form input[type="text"],
					{{WRAPPER}} .contact-form input[type="email"],
					{{WRAPPER}} .contact-form input[type="url"],
					{{WRAPPER}} .contact-form input[type="tel"],
					{{WRAPPER}} .contact-form textarea,
					{{WRAPPER}} .contact-form select,
					{{WRAPPER}} .wpforms-field input[type="text"],
					{{WRAPPER}} .wpforms-field input[type="email"],
					{{WRAPPER}} .wpforms-field textarea,
					{{WRAPPER}} .wpforms-field select' => 'background-color: {{VALUE}}',
				),
			)
		);

		// Input Text Color
		$this->add_control(
			'input_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#1F2937',
				'selectors' => array(
					'{{WRAPPER}} .contact-form input[type="text"],
					{{WRAPPER}} .contact-form input[type="email"],
					{{WRAPPER}} .contact-form input[type="url"],
					{{WRAPPER}} .contact-form input[type="tel"],
					{{WRAPPER}} .contact-form textarea,
					{{WRAPPER}} .contact-form select,
					{{WRAPPER}} .wpforms-field input[type="text"],
					{{WRAPPER}} .wpforms-field input[type="email"],
					{{WRAPPER}} .wpforms-field textarea,
					{{WRAPPER}} .wpforms-field select' => 'color: {{VALUE}}',
				),
			)
		);

		// Input Border Color
		$this->add_control(
			'input_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#E5E7EB',
				'selectors' => array(
					'{{WRAPPER}} .contact-form input[type="text"],
					{{WRAPPER}} .contact-form input[type="email"],
					{{WRAPPER}} .contact-form input[type="url"],
					{{WRAPPER}} .contact-form input[type="tel"],
					{{WRAPPER}} .contact-form textarea,
					{{WRAPPER}} .contact-form select,
					{{WRAPPER}} .wpforms-field input[type="text"],
					{{WRAPPER}} .wpforms-field input[type="email"],
					{{WRAPPER}} .wpforms-field textarea,
					{{WRAPPER}} .wpforms-field select' => 'border-color: {{VALUE}}',
				),
			)
		);

		// Input Focus Border Color
		$this->add_control(
			'input_focus_border_color',
			array(
				'label'     => esc_html__( 'Focus Border Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FF5E2E',
				'selectors' => array(
					'{{WRAPPER}} .contact-form input[type="text"]:focus,
					{{WRAPPER}} .contact-form input[type="email"]:focus,
					{{WRAPPER}} .contact-form input[type="url"]:focus,
					{{WRAPPER}} .contact-form input[type="tel"]:focus,
					{{WRAPPER}} .contact-form textarea:focus,
					{{WRAPPER}} .contact-form select:focus,
					{{WRAPPER}} .wpforms-field input[type="text"]:focus,
					{{WRAPPER}} .wpforms-field input[type="email"]:focus,
					{{WRAPPER}} .wpforms-field textarea:focus,
					{{WRAPPER}} .wpforms-field select:focus' => 'border-color: {{VALUE}}; box-shadow: 0 0 0 3px rgba(255, 94, 46, 0.1)',
				),
			)
		);

		// Input Padding
		$this->add_control(
			'input_padding',
			array(
				'label'      => esc_html__( 'Padding', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => '12',
					'right'  => '15',
					'bottom' => '12',
					'left'   => '15',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .contact-form input[type="text"],
					{{WRAPPER}} .contact-form input[type="email"],
					{{WRAPPER}} .contact-form input[type="url"],
					{{WRAPPER}} .contact-form input[type="tel"],
					{{WRAPPER}} .contact-form textarea,
					{{WRAPPER}} .contact-form select,
					{{WRAPPER}} .wpforms-field input[type="text"],
					{{WRAPPER}} .wpforms-field input[type="email"],
					{{WRAPPER}} .wpforms-field textarea,
					{{WRAPPER}} .wpforms-field select' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				),
			)
		);

		// Input Border Radius
		$this->add_control(
			'input_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => '4',
					'right'  => '4',
					'bottom' => '4',
					'left'   => '4',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .contact-form input[type="text"],
					{{WRAPPER}} .contact-form input[type="email"],
					{{WRAPPER}} .contact-form input[type="url"],
					{{WRAPPER}} .contact-form input[type="tel"],
					{{WRAPPER}} .contact-form textarea,
					{{WRAPPER}} .contact-form select,
					{{WRAPPER}} .wpforms-field input[type="text"],
					{{WRAPPER}} .wpforms-field input[type="email"],
					{{WRAPPER}} .wpforms-field textarea,
					{{WRAPPER}} .wpforms-field select' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Labels
		$this->start_controls_section(
			'label_style_section',
			array(
				'label' => esc_html__( 'Labels', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Label Color
		$this->add_control(
			'label_color',
			array(
				'label'     => esc_html__( 'Label Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#1F2937',
				'selectors' => array(
					'{{WRAPPER}} .contact-form label,
					{{WRAPPER}} .wpforms-field label' => 'color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Button
		$this->start_controls_section(
			'button_style_section',
			array(
				'label' => esc_html__( 'Button', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Button Background Color
		$this->add_control(
			'button_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FF5E2E',
				'selectors' => array(
					'{{WRAPPER}} .contact-form input[type="submit"],
					{{WRAPPER}} .contact-form button[type="submit"],
					{{WRAPPER}} .wpforms-submit' => 'background-color: {{VALUE}}',
				),
			)
		);

		// Button Text Color
		$this->add_control(
			'button_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FFFFFF',
				'selectors' => array(
					'{{WRAPPER}} .contact-form input[type="submit"],
					{{WRAPPER}} .contact-form button[type="submit"],
					{{WRAPPER}} .wpforms-submit' => 'color: {{VALUE}}',
				),
			)
		);

		// Button Hover Background Color
		$this->add_control(
			'button_hover_bg_color',
			array(
				'label'     => esc_html__( 'Hover Background Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#D14524',
				'selectors' => array(
					'{{WRAPPER}} .contact-form input[type="submit"]:hover,
					{{WRAPPER}} .contact-form button[type="submit"]:hover,
					{{WRAPPER}} .wpforms-submit:hover' => 'background-color: {{VALUE}}',
				),
			)
		);

		// Button Padding
		$this->add_control(
			'button_padding',
			array(
				'label'      => esc_html__( 'Padding', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => '12',
					'right'  => '30',
					'bottom' => '12',
					'left'   => '30',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .contact-form input[type="submit"],
					{{WRAPPER}} .contact-form button[type="submit"],
					{{WRAPPER}} .wpforms-submit' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				),
			)
		);

		// Button Border Radius
		$this->add_control(
			'button_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => '4',
					'right'  => '4',
					'bottom' => '4',
					'left'   => '4',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .contact-form input[type="submit"],
					{{WRAPPER}} .contact-form button[type="submit"],
					{{WRAPPER}} .wpforms-submit' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Messages
		$this->start_controls_section(
			'message_style_section',
			array(
				'label' => esc_html__( 'Messages', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Success Message Color
		$this->add_control(
			'success_color',
			array(
				'label'     => esc_html__( 'Success Message Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#10B981',
				'selectors' => array(
					'{{WRAPPER}} .wpcf7-mail-success-page,
					{{WRAPPER}} .contact-form .success-message,
					{{WRAPPER}} .wpforms-confirmation-container' => 'color: {{VALUE}}',
				),
			)
		);

		// Success Background Color
		$this->add_control(
			'success_bg_color',
			array(
				'label'     => esc_html__( 'Success Background Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ECFDF5',
				'selectors' => array(
					'{{WRAPPER}} .wpcf7-mail-success-page,
					{{WRAPPER}} .contact-form .success-message,
					{{WRAPPER}} .wpforms-confirmation-container' => 'background-color: {{VALUE}}',
				),
			)
		);

		// Error Message Color
		$this->add_control(
			'error_color',
			array(
				'label'     => esc_html__( 'Error Message Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#EF4444',
				'selectors' => array(
					'{{WRAPPER}} .wpcf7-form-control.wpcf7-form-control.wpcf7-not-valid,
					{{WRAPPER}} .contact-form .error-message,
					{{WRAPPER}} .wpforms-error' => 'color: {{VALUE}}',
				),
			)
		);

		// Error Background Color
		$this->add_control(
			'error_bg_color',
			array(
				'label'     => esc_html__( 'Error Background Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FEF2F2',
				'selectors' => array(
					'{{WRAPPER}} .contact-form .error-message,
					{{WRAPPER}} .wpforms-error' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$shortcode = isset( $settings['form_shortcode'] ) ? trim( $settings['form_shortcode'] ) : '';
		$style_preset = isset( $settings['form_style_preset'] ) ? $settings['form_style_preset'] : 'modern';

		$wrapper_class = 'contact-form contact-form--' . esc_attr( $style_preset );
		echo '<div class="' . esc_attr( $wrapper_class ) . '">';

		// Display the shortcode
		if ( ! empty( $shortcode ) ) {
			echo do_shortcode( $shortcode );
		} else {
			echo '<p style="color: #999; font-style: italic;">' . esc_html__( 'Please add your form shortcode', 'themeflex' ) . '</p>';
		}

		echo '</div>';

		// Inline Styles
		?>
		<style>
			.contact-form {
				width: 100%;
			}

			/* Modern Preset */
			.contact-form--modern input[type="text"],
			.contact-form--modern input[type="email"],
			.contact-form--modern input[type="url"],
			.contact-form--modern input[type="tel"],
			.contact-form--modern textarea,
			.contact-form--modern select {
				width: 100%;
				border: 1px solid #E5E7EB;
				transition: all 0.3s ease;
				font-size: 14px;
				font-family: inherit;
			}

			.contact-form--modern input[type="text"]:focus,
			.contact-form--modern input[type="email"]:focus,
			.contact-form--modern input[type="url"]:focus,
			.contact-form--modern input[type="tel"]:focus,
			.contact-form--modern textarea:focus,
			.contact-form--modern select:focus {
				outline: none;
				box-shadow: 0 0 0 3px rgba(255, 94, 46, 0.1);
			}

			.contact-form--modern input[type="submit"],
			.contact-form--modern button[type="submit"] {
				cursor: pointer;
				border: none;
				font-weight: 500;
				transition: all 0.3s ease;
				font-size: 14px;
			}

			.contact-form--modern input[type="submit"]:hover,
			.contact-form--modern button[type="submit"]:hover {
				transform: translateY(-2px);
				box-shadow: 0 4px 12px rgba(255, 94, 46, 0.3);
			}

			/* Classic Preset */
			.contact-form--classic input[type="text"],
			.contact-form--classic input[type="email"],
			.contact-form--classic input[type="url"],
			.contact-form--classic input[type="tel"],
			.contact-form--classic textarea,
			.contact-form--classic select {
				width: 100%;
				border: 2px solid #D1D5DB;
				transition: border-color 0.3s ease;
				font-size: 14px;
				font-family: inherit;
			}

			.contact-form--classic input[type="text"]:focus,
			.contact-form--classic input[type="email"]:focus,
			.contact-form--classic input[type="url"]:focus,
			.contact-form--classic input[type="tel"]:focus,
			.contact-form--classic textarea:focus,
			.contact-form--classic select:focus {
				outline: none;
				border-color: #FF5E2E;
			}

			.contact-form--classic input[type="submit"],
			.contact-form--classic button[type="submit"] {
				cursor: pointer;
				border: 2px solid #FF5E2E;
				transition: all 0.3s ease;
				font-size: 14px;
				font-weight: 600;
			}

			.contact-form--classic input[type="submit"]:hover,
			.contact-form--classic button[type="submit"]:hover {
				background-color: transparent;
				color: #FF5E2E;
			}

			/* Minimal Preset */
			.contact-form--minimal input[type="text"],
			.contact-form--minimal input[type="email"],
			.contact-form--minimal input[type="url"],
			.contact-form--minimal input[type="tel"],
			.contact-form--minimal textarea,
			.contact-form--minimal select {
				width: 100%;
				border: none;
				border-bottom: 1px solid #E5E7EB;
				background-color: transparent;
				padding-left: 0;
				padding-right: 0;
				padding-top: 8px;
				padding-bottom: 8px;
				font-size: 14px;
				font-family: inherit;
				transition: border-color 0.3s ease;
			}

			.contact-form--minimal input[type="text"]:focus,
			.contact-form--minimal input[type="email"]:focus,
			.contact-form--minimal input[type="url"]:focus,
			.contact-form--minimal input[type="tel"]:focus,
			.contact-form--minimal textarea:focus,
			.contact-form--minimal select:focus {
				outline: none;
				border-bottom-color: #FF5E2E;
			}

			.contact-form--minimal input[type="submit"],
			.contact-form--minimal button[type="submit"] {
				cursor: pointer;
				border: none;
				background-color: transparent;
				color: #FF5E2E;
				font-weight: 600;
				font-size: 14px;
				transition: all 0.3s ease;
				text-decoration: underline;
			}

			.contact-form--minimal input[type="submit"]:hover,
			.contact-form--minimal button[type="submit"]:hover {
				opacity: 0.7;
			}

			/* WPForms compatibility */
			.contact-form .wpforms-form {
				width: 100%;
			}

			.contact-form .wpforms-field-container {
				margin-bottom: 20px;
			}

			.contact-form .wpforms-field label {
				display: block;
				margin-bottom: 8px;
				font-weight: 500;
			}
		</style>
		<?php
	}
}
