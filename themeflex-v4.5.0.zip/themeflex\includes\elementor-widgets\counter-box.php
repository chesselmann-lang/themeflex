<?php
/**
 * Counter Box Widget
 * Einzelner Zähler mit Icon, Titel und animierter Zahl.
 *
 * @package ThemeFlex
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class ThemeFlex_Counter_Box_Widget extends \Elementor\Widget_Base {

	public function get_name()  { return 'sf_counter_box'; }
	public function get_title() { return esc_html__( 'Counter Box', 'themeflex' ); }
	public function get_icon()  { return 'eicon-counter'; }
	public function get_categories() { return [ 'themeflex' ]; }
	public function get_keywords()   { return [ 'counter', 'stat', 'number', 'fun fact', 'milestone' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'section_counter', [ 'label' => esc_html__( 'Counter', 'themeflex' ) ] );

		$this->add_control( 'icon', [ 'label' => 'Icon', 'type' => \Elementor\Controls_Manager::ICONS, 'default' => [ 'value' => 'fas fa-users', 'library' => 'fa-solid' ] ] );
		$this->add_control( 'starting_number', [ 'label' => 'Start', 'type' => \Elementor\Controls_Manager::NUMBER, 'default' => 0 ] );
		$this->add_control( 'ending_number',   [ 'label' => 'End',   'type' => \Elementor\Controls_Manager::NUMBER, 'default' => 500 ] );
		$this->add_control( 'prefix',  [ 'label' => 'Prefix',  'type' => \Elementor\Controls_Manager::TEXT, 'default' => '' ] );
		$this->add_control( 'suffix',  [ 'label' => 'Suffix',  'type' => \Elementor\Controls_Manager::TEXT, 'default' => '+' ] );
		$this->add_control( 'title',   [ 'label' => 'Title',   'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Happy Clients' ] );
		$this->add_control( 'description', [ 'label' => 'Description', 'type' => \Elementor\Controls_Manager::TEXTAREA, 'default' => '' ] );
		$this->add_control( 'duration', [ 'label' => 'Animation Duration (ms)', 'type' => \Elementor\Controls_Manager::SLIDER, 'range' => [ 'ms' => [ 'min' => 500, 'max' => 4000 ] ], 'default' => [ 'size' => 1600 ] ] );

		$this->end_controls_section();

		$this->start_controls_section( 'section_style', [ 'label' => 'Style', 'tab' => \Elementor\Controls_Manager::TAB_STYLE ] );

		$this->add_control( 'layout_style', [
			'label'   => 'Layout',
			'type'    => \Elementor\Controls_Manager::SELECT,
			'options' => [ 'centered' => 'Centered', 'left' => 'Left-aligned', 'icon-left' => 'Icon Left' ],
			'default' => 'centered',
		] );
		$this->add_control( 'show_box', [ 'label' => 'Card Background', 'type' => \Elementor\Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'number_color', [ 'label' => 'Number Color', 'type' => \Elementor\Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .sf-cb-number' => 'color: {{VALUE}};' ] ] );
		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
			'name'     => 'number_typography',
			'selector' => '{{WRAPPER}} .sf-cb-number',
		] );

		$this->end_controls_section();
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$uid   = 'sf-cb-' . $this->get_id();
		$end   = (float) $s['ending_number'];
		$start = (float) $s['starting_number'];
		$dur   = ! empty( $s['duration']['size'] ) ? (int) $s['duration']['size'] : 1600;
		$icon  = ! empty( $s['icon']['value'] ) ? $s['icon']['value'] : '';
		$layout = $s['layout_style'];
		$card   = 'yes' === $s['show_box'];

		$align = 'centered' === $layout ? 'text-align:center;' : ( 'icon-left' === $layout ? 'display:flex;align-items:center;gap:20px;' : 'text-align:left;' );
		$box   = $card ? 'background:var(--sf-woo-bg-alt,#f8fafc);border:1px solid #e5e7eb;border-radius:12px;padding:32px 24px;box-shadow:0 2px 12px rgba(0,0,0,.05);' : '';
		?>
		<div class="sf-counter-box" id="<?php echo esc_attr($uid); ?>" style="<?php echo $align . $box; ?>">
			<?php if ( $icon ) : ?>
			<div class="sf-cb-icon" style="<?php echo 'icon-left'===$layout?'flex-shrink:0;':'margin-bottom:16px;'; ?>">
				<span style="display:inline-flex;align-items:center;justify-content:center;width:56px;height:56px;border-radius:50%;background:var(--sf-gradient-soft,rgba(255,94,46,.1));color:var(--sf-color-primary,#FF5E2E);font-size:24px;">
					<i class="<?php echo esc_attr($icon); ?>" aria-hidden="true"></i>
				</span>
			</div>
			<?php endif; ?>
			<div>
				<div class="sf-cb-number" aria-live="polite" style="font-size:3rem;font-weight:800;line-height:1;color:var(--sf-color-primary,#FF5E2E);margin-bottom:8px;">
					<?php echo esc_html($s['prefix']); ?><span class="sf-cb-val"><?php echo esc_html($s['ending_number']); ?></span><?php echo esc_html($s['suffix']); ?>
				</div>
				<?php if ( $s['title'] ) : ?><div style="font-size:16px;font-weight:700;color:#1e293b;margin-bottom:6px;"><?php echo esc_html($s['title']); ?></div><?php endif; ?>
				<?php if ( $s['description'] ) : ?><p style="font-size:13px;color:#64748b;margin:0;"><?php echo esc_html($s['description']); ?></p><?php endif; ?>
			</div>
		</div>
		<script>
		(function(){
			var el=document.querySelector('#<?php echo esc_js($uid); ?> .sf-cb-val');
			if(!el||!('IntersectionObserver' in window))return;
			var done=false;
			new IntersectionObserver(function(entries){
				if(done||!entries[0].isIntersecting)return;
				done=true;
				var start=<?php echo (float)$start; ?>;
				var end=<?php echo $end; ?>;
				var dur=<?php echo $dur; ?>;
				var step=16;
				var steps=dur/step;
				var inc=(end-start)/steps;
				var cur=start;
				var t=setInterval(function(){
					cur+=inc;
					if(cur>=end){cur=end;clearInterval(t);}
					el.textContent=Number.isInteger(end)?Math.floor(cur):cur.toFixed(1);
				},step);
			},{threshold:0.5}).observe(document.getElementById('<?php echo esc_js($uid); ?>'));
		})();
		</script>
		<?php
	}
}
