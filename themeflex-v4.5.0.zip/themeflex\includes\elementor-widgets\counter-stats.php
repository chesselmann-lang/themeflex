<?php
/**
 * Elementor Animated Counter/Stats Widget
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Counter Stats Widget Class
 *
 * @since 1.0.0
 */
class ThemeFlex_Counter_Stats_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'themeflex_counter_stats';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Animated Counter / Stats', 'themeflex' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-counter';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'themeflex' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Start Value
		$this->add_control(
			'start_value',
			array(
				'label'       => esc_html__( 'Start Value', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'default'     => 0,
				'placeholder' => esc_html__( 'Enter start value', 'themeflex' ),
			)
		);

		// End Value
		$this->add_control(
			'end_value',
			array(
				'label'       => esc_html__( 'End Value', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'default'     => 100,
				'placeholder' => esc_html__( 'Enter end value', 'themeflex' ),
			)
		);

		// Prefix
		$this->add_control(
			'prefix',
			array(
				'label'       => esc_html__( 'Prefix', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '',
				'placeholder' => esc_html__( 'e.g., $, #, +', 'themeflex' ),
			)
		);

		// Suffix
		$this->add_control(
			'suffix',
			array(
				'label'       => esc_html__( 'Suffix', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '',
				'placeholder' => esc_html__( 'e.g., %, K, M', 'themeflex' ),
			)
		);

		// Title
		$this->add_control(
			'counter_title',
			array(
				'label'       => esc_html__( 'Title', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Happy Customers', 'themeflex' ),
				'placeholder' => esc_html__( 'Enter counter title', 'themeflex' ),
			)
		);

		// Icon
		$this->add_control(
			'counter_icon',
			array(
				'label'   => esc_html__( 'Icon (Optional)', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::ICONS,
				'default' => array(
					'value'   => 'fas fa-chart-bar',
					'library' => 'fa-solid',
				),
			)
		);

		// Animation Duration
		$this->add_control(
			'animation_duration',
			array(
				'label'      => esc_html__( 'Animation Duration (ms)', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::NUMBER,
				'default'    => 2000,
				'min'        => 300,
				'max'        => 5000,
				'step'       => 100,
				'placeholder' => esc_html__( 'Enter duration in milliseconds', 'themeflex' ),
			)
		);

		$this->end_controls_section();

		// Layout Section
		$this->start_controls_section(
			'layout_section',
			array(
				'label' => esc_html__( 'Layout', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Layout Type
		$this->add_control(
			'layout_type',
			array(
				'label'   => esc_html__( 'Layout', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'vertical',
				'options' => array(
					'vertical'   => esc_html__( 'Vertical', 'themeflex' ),
					'horizontal' => esc_html__( 'Horizontal', 'themeflex' ),
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Number
		$this->start_controls_section(
			'number_style_section',
			array(
				'label' => esc_html__( 'Number', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Number Color
		$this->add_control(
			'number_color',
			array(
				'label'     => esc_html__( 'Number Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FF5E2E',
				'selectors' => array(
					'{{WRAPPER}} .counter-number' => 'color: {{VALUE}}',
				),
			)
		);

		// Number Size
		$this->add_control(
			'number_size',
			array(
				'label'      => esc_html__( 'Number Size', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 20,
						'max' => 100,
					),
				),
				'default'    => array(
					'size' => 48,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .counter-number' => 'font-size: {{SIZE}}{{UNIT}}; font-weight: 700;',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Title
		$this->start_controls_section(
			'title_style_section',
			array(
				'label' => esc_html__( 'Title', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Title Color
		$this->add_control(
			'title_color',
			array(
				'label'     => esc_html__( 'Title Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#1F2937',
				'selectors' => array(
					'{{WRAPPER}} .counter-title' => 'color: {{VALUE}}',
				),
			)
		);

		// Title Size
		$this->add_control(
			'title_size',
			array(
				'label'      => esc_html__( 'Title Size', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 12,
						'max' => 32,
					),
				),
				'default'    => array(
					'size' => 16,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .counter-title' => 'font-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Icon
		$this->start_controls_section(
			'icon_style_section',
			array(
				'label' => esc_html__( 'Icon', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Icon Color
		$this->add_control(
			'icon_color',
			array(
				'label'     => esc_html__( 'Icon Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FF5E2E',
				'selectors' => array(
					'{{WRAPPER}} .counter-icon' => 'color: {{VALUE}}',
				),
			)
		);

		// Icon Size
		$this->add_control(
			'icon_size',
			array(
				'label'      => esc_html__( 'Icon Size', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 16,
						'max' => 64,
					),
				),
				'default'    => array(
					'size' => 32,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .counter-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$start_value = isset( $settings['start_value'] ) ? intval( $settings['start_value'] ) : 0;
		$end_value = isset( $settings['end_value'] ) ? intval( $settings['end_value'] ) : 100;
		$prefix = isset( $settings['prefix'] ) ? $settings['prefix'] : '';
		$suffix = isset( $settings['suffix'] ) ? $settings['suffix'] : '';
		$duration = isset( $settings['animation_duration'] ) ? intval( $settings['animation_duration'] ) : 2000;
		$layout = isset( $settings['layout_type'] ) ? $settings['layout_type'] : 'vertical';

		$wrapper_class = 'counter-stats counter-stats--' . esc_attr( $layout );
		echo '<div class="' . esc_attr( $wrapper_class ) . '">';

		// Icon
		if ( ! empty( $settings['counter_icon'] ) ) {
			echo '<div class="counter-icon-wrapper">';
			\Elementor\Icons_Manager::render_icon(
				$settings['counter_icon'],
				array( 'aria-hidden' => 'true', 'class' => 'counter-icon' )
			);
			echo '</div>';
		}

		// Content
		echo '<div class="counter-content">';

		// Number with prefix/suffix
		$unique_id = 'counter-' . uniqid();
		echo '<div class="counter-number-wrapper">';
		echo '<div class="counter-prefix">' . esc_html( $prefix ) . '</div>';
		echo '<div class="counter-number" data-counter="' . esc_attr( $unique_id ) . '" data-start="' . esc_attr( $start_value ) . '" data-end="' . esc_attr( $end_value ) . '" data-duration="' . esc_attr( $duration ) . '">0</div>';
		echo '<div class="counter-suffix">' . esc_html( $suffix ) . '</div>';
		echo '</div>';

		// Title
		if ( ! empty( $settings['counter_title'] ) ) {
			printf(
				'<h3 class="counter-title">%s</h3>',
				esc_html( $settings['counter_title'] )
			);
		}

		echo '</div>';
		echo '</div>';

		// Inline Styles
		?>
		<style>
			.counter-stats {
				display: flex;
				align-items: flex-start;
				gap: 20px;
				text-align: center;
			}

			.counter-stats--horizontal {
				flex-direction: row;
				align-items: center;
				text-align: center;
			}

			.counter-stats--vertical {
				flex-direction: column;
				align-items: center;
				text-align: center;
			}

			.counter-icon-wrapper {
				display: flex;
				align-items: center;
				justify-content: center;
			}

			.counter-content {
				flex: 1;
			}

			.counter-number-wrapper {
				display: flex;
				align-items: baseline;
				justify-content: center;
				gap: 5px;
				margin-bottom: 10px;
			}

			.counter-number {
				line-height: 1;
			}

			.counter-prefix {
				font-size: 0.8em;
			}

			.counter-suffix {
				font-size: 0.8em;
			}

			.counter-title {
				margin: 0;
				font-size: 16px;
				font-weight: 500;
			}
		</style>

		<script>
			(function() {
				function countUp(element, startValue, endValue, duration) {
					const startTime = performance.now();
					const range = endValue - startValue;

					function update(currentTime) {
						const elapsed = currentTime - startTime;
						const progress = Math.min(elapsed / duration, 1);
						const currentValue = Math.floor(startValue + range * easeOutQuad(progress));
						element.textContent = currentValue;

						if (progress < 1) {
							requestAnimationFrame(update);
						}
					}

					function easeOutQuad(t) {
						return 1 - (1 - t) * (1 - t);
					}

					requestAnimationFrame(update);
				}

				function initCounters() {
					const counters = document.querySelectorAll('[data-counter]');
					counters.forEach(function(counter) {
						const observer = new IntersectionObserver(function(entries) {
							entries.forEach(function(entry) {
								if (entry.isIntersecting) {
									const start = parseInt(entry.target.dataset.start, 10);
									const end = parseInt(entry.target.dataset.end, 10);
									const duration = parseInt(entry.target.dataset.duration, 10);
									countUp(entry.target, start, end, duration);
									observer.unobserve(entry.target);
								}
							});
						}, { threshold: 0.1 });

						observer.observe(counter);
					});
				}

				if (document.readyState === 'loading') {
					document.addEventListener('DOMContentLoaded', initCounters);
				} else {
					initCounters();
				}
			})();
		</script>
		<?php
	}
}
