<?php
/**
 * Elementor CTA Box Widget
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CTA Box Widget Class
 *
 * @since 1.0.0
 */
class ThemeFlex_CTA_Box_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'themeflex_cta_box';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'CTA Box', 'themeflex' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-call-to-action';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'themeflex' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Heading
		$this->add_control(
			'heading',
			array(
				'label'       => esc_html__( 'Heading', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Call To Action', 'themeflex' ),
				'placeholder' => esc_html__( 'Enter heading', 'themeflex' ),
			)
		);

		// Description
		$this->add_control(
			'description',
			array(
				'label'       => esc_html__( 'Description', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'Add your CTA description here', 'themeflex' ),
				'placeholder' => esc_html__( 'Enter description', 'themeflex' ),
			)
		);

		// Button Text
		$this->add_control(
			'button_text',
			array(
				'label'       => esc_html__( 'Button Text', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Learn More', 'themeflex' ),
			)
		);

		// Button URL
		$this->add_control(
			'button_url',
			array(
				'label'       => esc_html__( 'Button URL', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://example.com', 'themeflex' ),
				'default'     => array(
					'url' => '',
				),
			)
		);

		// Box Style
		$this->add_control(
			'box_style',
			array(
				'label'   => esc_html__( 'Box Style', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'solid',
				'options' => array(
					'solid'   => esc_html__( 'Solid', 'themeflex' ),
					'outline' => esc_html__( 'Outline', 'themeflex' ),
					'gradient' => esc_html__( 'Gradient', 'themeflex' ),
				),
			)
		);

		// Background Color
		$this->add_control(
			'bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#F3F4F6',
				'selectors' => array(
					'{{WRAPPER}} .cta-box' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();

		// Style Section
		$this->start_controls_section(
			'style_section',
			array(
				'label' => esc_html__( 'Style', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Heading Color
		$this->add_control(
			'heading_color',
			array(
				'label'     => esc_html__( 'Heading Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#1F2937',
				'selectors' => array(
					'{{WRAPPER}} .cta-box__heading' => 'color: {{VALUE}}',
				),
			)
		);

		// Text Color
		$this->add_control(
			'text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#6B7280',
				'selectors' => array(
					'{{WRAPPER}} .cta-box__description' => 'color: {{VALUE}}',
				),
			)
		);

		// Border Radius
		$this->add_control(
			'border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => '8',
					'right'  => '8',
					'bottom' => '8',
					'left'   => '8',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .cta-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings   = $this->get_settings_for_display();
		$box_style  = isset( $settings['box_style'] ) ? $settings['box_style'] : 'solid';
		$btn_url    = isset( $settings['button_url']['url'] ) ? $settings['button_url']['url'] : '';
		$btn_ext    = ! empty( $settings['button_url']['is_external'] ) ? ' target="_blank" rel="noopener noreferrer"' : '';

		// Box container style
		$box_inline = '';
		if ( 'gradient' === $box_style ) {
			$box_inline = 'background:linear-gradient(135deg,var(--sf-primary,#FF5E2E),#ED4C1C);color:#fff;';
		} elseif ( 'outline' === $box_style ) {
			$box_inline = 'background:transparent;border:2px solid var(--sf-primary,#FF5E2E);';
		}
		?>
		<div class="sf-cta-box sf-cta-box--<?php echo esc_attr( $box_style ); ?>"
		     style="border-radius:var(--sf-radius,12px);padding:40px 36px;<?php echo esc_attr( $box_inline ); ?>box-shadow:var(--sf-shadow,0 4px 24px rgba(0,0,0,.08));">
			<div class="sf-cta-box__inner" style="max-width:720px;margin:0 auto;text-align:center;">

				<?php if ( ! empty( $settings['heading'] ) ) : ?>
					<h3 class="cta-box__heading"
					    style="font-size:clamp(1.5rem,3vw,2rem);font-weight:800;line-height:1.2;margin:0 0 16px;<?php echo 'gradient' === $box_style ? 'color:#fff;' : 'color:var(--sf-title,#1e293b);'; ?>">
						<?php echo esc_html( $settings['heading'] ); ?>
					</h3>
				<?php endif; ?>

				<?php if ( ! empty( $settings['description'] ) ) : ?>
					<p class="cta-box__description"
					   style="font-size:1rem;line-height:1.7;margin:0 0 28px;<?php echo 'gradient' === $box_style ? 'color:rgba(255,255,255,.9);' : 'color:var(--sf-text,#4b5563);'; ?>">
						<?php echo esc_html( $settings['description'] ); ?>
					</p>
				<?php endif; ?>

				<?php if ( ! empty( $settings['button_text'] ) && ! empty( $btn_url ) ) : ?>
					<div class="sf-cta-box__actions" style="display:flex;flex-wrap:wrap;gap:12px;justify-content:center;align-items:center;">
						<a href="<?php echo esc_url( $btn_url ); ?>"<?php echo $btn_ext; ?>
						   class="sf-cta-box__button"
						   style="display:inline-flex;align-items:center;gap:8px;padding:14px 32px;border-radius:var(--sf-radius,8px);font-weight:700;font-size:.95rem;text-decoration:none;transition:all .25s ease;<?php echo 'gradient' === $box_style ? 'background:#fff;color:var(--sf-primary,#FF5E2E);' : 'background:var(--sf-primary,#FF5E2E);color:#fff;'; ?>"
						   onmouseover="this.style.transform='translateY(-2px)';this.style.boxShadow='0 6px 20px rgba(255,94,46,.35)'"
						   onmouseout="this.style.transform='translateY(0)';this.style.boxShadow='none'">
							<?php echo esc_html( $settings['button_text'] ); ?>
						</a>
					</div>
				<?php endif; ?>

			</div>
		</div>
		<?php
	}
}
