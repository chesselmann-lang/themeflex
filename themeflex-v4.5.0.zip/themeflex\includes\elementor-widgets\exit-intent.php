<?php
/**
 * Exit Intent Popup Widget
 * @package ThemeFlex
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Exit_Intent_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'exit_intent'; }
    public function get_title() { return esc_html__('Exit Intent Popup','themeflex'); }
    public function get_icon()  { return 'eicon-close-circle'; }
    public function get_categories() { return ['themeflex']; }
    public function get_keywords()   { return ['exit','intent','popup','leave','abandon']; }

    protected function register_controls() {
        $this->start_controls_section('s1',['label'=>'Content']);
        $this->add_control('title',['label'=>'Title','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Wait — Before You Go!']);
        $this->add_control('subtitle',['label'=>'Subtitle','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>'Get 20% off your first order — subscribe now.']);
        $this->add_control('cta_text',['label'=>'Button Text','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Get My Discount']);
        $this->add_control('cta_url',['label'=>'Button URL','type'=>\Elementor\Controls_Manager::URL]);
        $this->add_control('dismiss_text',['label'=>'Dismiss Text','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'No thanks']);
        $this->add_control('once_per_session',['label'=>'Show Once per Session','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes']);
        $this->end_controls_section();
    }

    protected function render() {
        $s=$this->get_settings_for_display();$uid='sfei-'.$this->get_id();
        $once='yes'===$s['once_per_session'];$cta=!empty($s['cta_url']['url'])?esc_url($s['cta_url']['url']):'#';
        ?>
        <div id="<?php echo esc_attr($uid);?>" style="display:none" aria-hidden="true"></div>
        <div id="<?php echo esc_attr($uid);?>-modal" role="dialog" aria-modal="true" style="display:none;position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.7);align-items:center;justify-content:center;">
            <div style="background:var(--sf-bg,#fff);border-radius:16px;padding:48px 40px;max-width:480px;width:90%;text-align:center;position:relative;box-shadow:0 24px 80px rgba(0,0,0,.3);animation:sfModalIn .3s ease;">
                <button onclick="sfEiClose('<?php echo esc_js($uid);?>')" style="position:absolute;top:12px;right:16px;background:none;border:none;font-size:24px;cursor:pointer;color:var(--sf-meta,#94a3b8);">&times;</button>
                <div style="font-size:48px;margin-bottom:16px;">👋</div>
                <h3 style="font-size:1.5rem;font-weight:800;color:var(--sf-title,#1e293b);margin-bottom:12px;"><?php echo esc_html($s['title']);?></h3>
                <p style="color:var(--sf-text,#64748b);margin-bottom:28px;"><?php echo esc_html($s['subtitle']);?></p>
                <a href="<?php echo $cta;?>" style="display:block;padding:14px;border-radius:10px;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;font-weight:700;text-decoration:none;margin-bottom:12px;"><?php echo esc_html($s['cta_text']);?></a>
                <button onclick="sfEiClose('<?php echo esc_js($uid);?>')" style="background:none;border:none;color:var(--sf-meta,#94a3b8);cursor:pointer;font-size:13px;"><?php echo esc_html($s['dismiss_text']);?></button>
            </div>
        </div>
        <script>
        (function(){
            var uid='<?php echo esc_js($uid);?>';
            var once=<?php echo $once?'true':'false';?>;
            var key='sf_ei_'+uid;
            if(once&&sessionStorage.getItem(key))return;
            var shown=false;
            document.addEventListener('mouseleave',function(e){
                if(e.clientY>0||shown)return;shown=true;
                if(once)sessionStorage.setItem(key,'1');
                var m=document.getElementById(uid+'-modal');m.style.display='flex';
                document.body.style.overflow='hidden';
            });
        })();
        window.sfEiClose=window.sfEiClose||function(id){
            var m=document.getElementById(id+'-modal');if(m){m.style.display='none';document.body.style.overflow='';}
        };
        </script>
        <?php
    }
}
