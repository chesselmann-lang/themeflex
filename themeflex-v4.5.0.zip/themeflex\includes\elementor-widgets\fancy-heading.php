<?php
/**
 * Fancy Heading Widget for Elementor
 * Gradient text, animated typewriter, highlighted words, split animations.
 *
 * @package ThemeFlex
 * @since 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class ThemeFlex_Fancy_Heading_Widget extends \Elementor\Widget_Base {

    public function get_name()       { return 'sf_fancy_heading'; }
    public function get_title()      { return esc_html__( 'Fancy Heading', 'themeflex' ); }
    public function get_icon()       { return 'eicon-heading'; }
    public function get_categories() { return array( 'themeflex' ); }
    public function get_keywords()   { return array( 'heading', 'title', 'gradient', 'typewriter', 'animated', 'text' ); }

    protected function register_controls() {

        $this->start_controls_section( 'section_content', array(
            'label' => esc_html__( 'Content', 'themeflex' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ) );

        $this->add_control( 'heading_style', array(
            'label'   => esc_html__( 'Style', 'themeflex' ),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'default' => 'gradient',
            'options' => array(
                'gradient'   => esc_html__( 'Gradient Text', 'themeflex' ),
                'highlight'  => esc_html__( 'Highlighted Word', 'themeflex' ),
                'typewriter' => esc_html__( 'Typewriter Effect', 'themeflex' ),
                'outline'    => esc_html__( 'Outline Text', 'themeflex' ),
                'split'      => esc_html__( 'Split Colour', 'themeflex' ),
            ),
        ) );

        $this->add_control( 'before_text', array(
            'label'       => esc_html__( 'Before Text', 'themeflex' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => 'We build',
            'label_block' => true,
        ) );

        $this->add_control( 'accent_text', array(
            'label'       => esc_html__( 'Accent / Animated Text', 'themeflex' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => 'beautiful websites',
            'label_block' => true,
        ) );

        $this->add_control( 'after_text', array(
            'label'       => esc_html__( 'After Text', 'themeflex' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => 'that convert',
            'label_block' => true,
        ) );

        $this->add_control( 'typewriter_words', array(
            'label'       => esc_html__( 'Typewriter Words (one per line)', 'themeflex' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => "beautiful\nfast\npowerful",
            'condition'   => array( 'heading_style' => 'typewriter' ),
            'rows'        => 4,
        ) );

        $this->add_control( 'tag', array(
            'label'   => esc_html__( 'HTML Tag', 'themeflex' ),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'default' => 'h2',
            'options' => array( 'h1'=>'H1','h2'=>'H2','h3'=>'H3','h4'=>'H4','p'=>'p','div'=>'div' ),
        ) );

        $this->add_control( 'align', array(
            'label'     => esc_html__( 'Alignment', 'themeflex' ),
            'type'      => \Elementor\Controls_Manager::CHOOSE,
            'options'   => array(
                'left'   => array('title'=>esc_html__('Left','themeflex'),   'icon'=>'eicon-text-align-left'),
                'center' => array('title'=>esc_html__('Center','themeflex'), 'icon'=>'eicon-text-align-center'),
                'right'  => array('title'=>esc_html__('Right','themeflex'),  'icon'=>'eicon-text-align-right'),
            ),
            'default'   => 'center',
            'selectors' => array( '{{WRAPPER}} .sf-fancy-heading' => 'text-align: {{VALUE}};' ),
        ) );

        $this->end_controls_section();

        /* ── STYLE ── */
        $this->start_controls_section( 'section_style', array(
            'label' => esc_html__( 'Typography', 'themeflex' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ) );

        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array(
            'name'     => 'heading_typography',
            'selector' => '{{WRAPPER}} .sf-fancy-heading',
        ) );

        $this->add_control( 'text_color', array(
            'label'     => esc_html__( 'Text Colour', 'themeflex' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => '#0f172a',
            'selectors' => array( '{{WRAPPER}} .sf-fancy-heading' => 'color: {{VALUE}};' ),
        ) );

        $this->add_control( 'gradient_color_1', array(
            'label'     => esc_html__( 'Gradient Colour 1', 'themeflex' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => '#2563eb',
            'condition' => array( 'heading_style' => array('gradient','typewriter') ),
        ) );

        $this->add_control( 'gradient_color_2', array(
            'label'     => esc_html__( 'Gradient Colour 2', 'themeflex' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => '#7c3aed',
            'condition' => array( 'heading_style' => array('gradient','typewriter') ),
        ) );

        $this->add_control( 'highlight_color', array(
            'label'     => esc_html__( 'Highlight Background', 'themeflex' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => '#fef08a',
            'condition' => array( 'heading_style' => 'highlight' ),
        ) );

        $this->end_controls_section();
    }

    protected function render() {
        $s     = $this->get_settings_for_display();
        $tag   = in_array( $s['tag'], array('h1','h2','h3','h4','p','div'), true ) ? $s['tag'] : 'h2';
        $style = $s['heading_style'];
        $uid   = 'sfh' . $this->get_id();

        $c1 = esc_attr( $s['gradient_color_1'] ?? '#2563eb' );
        $c2 = esc_attr( $s['gradient_color_2'] ?? '#7c3aed' );
        $hl = esc_attr( $s['highlight_color']  ?? '#fef08a' );

        echo '<' . esc_attr( $tag ) . ' class="sf-fancy-heading sf-fh-' . esc_attr( $style ) . '" id="' . esc_attr($uid) . '">';
        echo esc_html( $s['before_text'] ) . ' ';

        if ( 'gradient' === $style ) {
            echo '<span class="sf-fh-accent" style="background:linear-gradient(135deg,' . $c1 . ',' . $c2 . ');-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;">' . esc_html( $s['accent_text'] ) . '</span>';
        } elseif ( 'highlight' === $style ) {
            echo '<mark class="sf-fh-accent" style="background:' . $hl . ';padding:2px 6px;border-radius:4px;color:inherit;">' . esc_html( $s['accent_text'] ) . '</mark>';
        } elseif ( 'outline' === $style ) {
            echo '<span class="sf-fh-accent" style="-webkit-text-stroke:2px ' . $c1 . ';color:transparent;">' . esc_html( $s['accent_text'] ) . '</span>';
        } elseif ( 'split' === $style ) {
            echo '<span class="sf-fh-accent" style="color:' . $c1 . ';">' . esc_html( $s['accent_text'] ) . '</span>';
        } elseif ( 'typewriter' === $style ) {
            $words = array_filter( array_map( 'trim', explode( "\n", $s['typewriter_words'] ) ) );
            $words_json = wp_json_encode( array_values( $words ) );
            echo '<span class="sf-fh-accent sf-typewriter" data-words=\'' . $words_json . '\' style="background:linear-gradient(135deg,' . $c1 . ',' . $c2 . ');-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;"></span>';
        }

        echo ' ' . esc_html( $s['after_text'] );
        echo '</' . esc_attr( $tag ) . '>';
        ?>
        <script>
        (function() {
          var els = document.querySelectorAll('#<?php echo esc_js($uid); ?> .sf-typewriter[data-words]');
          els.forEach(function(el) {
            var words = JSON.parse(el.getAttribute('data-words') || '[]');
            if (!words.length) return;
            var i = 0, c = 0, typing = true;
            function tick() {
              var word = words[i % words.length];
              if (typing) { c++; el.textContent = word.slice(0, c); if (c >= word.length) { typing = false; setTimeout(tick, 1400); return; } }
              else { c--; el.textContent = word.slice(0, c); if (c <= 0) { i++; typing = true; } }
              setTimeout(tick, typing ? 80 : 40);
            }
            tick();
          });
        })();
        </script>
        <?php
    }
}
