<?php
/**
 * FAQ with Live Search Widget
 * @package ThemeFlex
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Faq_Search_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'sf_faq_search'; }
    public function get_title() { return esc_html__('FAQ with Search','themeflex'); }
    public function get_icon()  { return 'eicon-help'; }
    public function get_categories() { return ['themeflex']; }
    public function get_keywords()   { return ['faq','search','questions','filter','accordion','help']; }

    protected function register_controls() {
        $this->start_controls_section('s_header',['label'=>'Header']);
        $this->add_control('show_search',['label'=>'Show Search Box','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes']);
        $this->add_control('search_placeholder',['label'=>'Search Placeholder','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Search frequently asked questions…']);
        $this->add_control('no_results_text',['label'=>'No Results Text','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'No questions found. Try a different search term.']);
        $this->end_controls_section();

        $this->start_controls_section('s_items',['label'=>'Questions']);
        $rep = new \Elementor\Repeater();
        $rep->add_control('question',['label'=>'Question','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'How does this work?']);
        $rep->add_control('answer',['label'=>'Answer','type'=>\Elementor\Controls_Manager::WYSIWYG,'default'=>'This is the answer to your question. You can add rich text, links, and formatting here.']);
        $rep->add_control('category',['label'=>'Category Tag','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'General']);
        $this->add_control('items',['type'=>\Elementor\Controls_Manager::REPEATER,'fields'=>$rep->get_controls(),'default'=>[
            ['question'=>'How do I install the theme?','answer'=>'<p>Download the .zip file from ThemeForest, go to WordPress → Appearance → Themes → Add New → Upload Theme, select the file and activate.</p>','category'=>'Installation'],
            ['question'=>'Do I need Elementor Pro?','answer'=>'<p>No! ThemeFlex works fully with the free version of Elementor. All 66+ custom widgets are included with the theme.</p>','category'=>'General'],
            ['question'=>'How do I import a demo?','answer'=>'<p>Go to Appearance → Theme Setup → Demo Importer, choose your demo and click Import. The process takes 1–2 minutes.</p>','category'=>'Installation'],
            ['question'=>'Can I use multiple skins on one site?','answer'=>'<p>Yes — you can switch skins globally in the Customizer. Each skin is a complete design system with colors, fonts, and component styles.</p>','category'=>'Customization'],
            ['question'=>'Is WooCommerce supported?','answer'=>'<p>Absolutely. ThemeFlex includes 2,300+ lines of WooCommerce CSS covering Shop, Product, Cart, Checkout, My Account, and all dark mode states.</p>','category'=>'General'],
        ],'title_field'=>'{{{ question }}}']);
        $this->add_control('open_first',['label'=>'Open First Item','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes']);
        $this->end_controls_section();

        $this->start_controls_section('s_style',['label'=>'Style','tab'=>\Elementor\Controls_Manager::TAB_STYLE]);
        $this->add_control('icon_open',['label'=>'Open Icon','type'=>\Elementor\Controls_Manager::ICONS,'default'=>['value'=>'fas fa-minus']]);
        $this->add_control('icon_closed',['label'=>'Closed Icon','type'=>\Elementor\Controls_Manager::ICONS,'default'=>['value'=>'fas fa-plus']]);
        $this->end_controls_section();
    }

    protected function render() {
        $s   = $this->get_settings_for_display();
        $uid = 'sffq-'.$this->get_id();
        $open_icon   = !empty($s['icon_open']['value'])   ? $s['icon_open']['value']   : 'fas fa-minus';
        $closed_icon = !empty($s['icon_closed']['value']) ? $s['icon_closed']['value'] : 'fas fa-plus';
        ?>
        <div class="sf-faq-search-wrap" id="<?php echo esc_attr($uid); ?>">
            <?php if('yes' === ($s['show_search'] ?? 'yes')): ?>
            <div style="position:relative;margin-bottom:32px;">
                <input type="text" id="<?php echo esc_attr($uid); ?>-search"
                    placeholder="<?php echo esc_attr($s['search_placeholder'] ?? 'Search...'); ?>"
                    oninput="sfFaqSearch('<?php echo esc_js($uid); ?>')"
                    style="width:100%;padding:14px 16px 14px 48px;border:2px solid var(--sf-border,#e5e7eb);border-radius:12px;font-size:15px;background:var(--sf-bg,#fff);color:var(--sf-title,#1e293b);font-family:inherit;outline:none;box-sizing:border-box;transition:border-color .2s;"
                    onfocus="this.style.borderColor='var(--sf-color-primary,#FF5E2E)'"
                    onblur="this.style.borderColor='var(--sf-border,#e5e7eb)'" />
                <i class="fa-solid fa-magnifying-glass" style="position:absolute;left:16px;top:50%;transform:translateY(-50%);color:var(--sf-meta,#94a3b8);" aria-hidden="true"></i>
            </div>
            <?php endif; ?>
            <div id="<?php echo esc_attr($uid); ?>-list">
                <?php foreach($s['items'] as $i => $item):
                    $open = (0 === $i && 'yes' === ($s['open_first'] ?? 'yes'));
                    $pid  = $uid.'-panel-'.$i;
                ?>
                <div class="sf-faq-item" data-question="<?php echo esc_attr(strtolower($item['question'])); ?>" data-answer="<?php echo esc_attr(strtolower(strip_tags($item['answer']))); ?>"
                    style="border:1px solid var(--sf-border,#e5e7eb);border-radius:12px;margin-bottom:10px;overflow:hidden;transition:border-color .2s;">
                    <button class="sf-faq-trigger" onclick="sfFaqToggle(this,'<?php echo esc_js($pid); ?>')"
                        style="width:100%;display:flex;align-items:center;justify-content:space-between;padding:20px 24px;background:none;border:none;text-align:left;cursor:pointer;gap:16px;font-family:inherit;"
                        aria-expanded="<?php echo $open?'true':'false'; ?>" aria-controls="<?php echo esc_attr($pid); ?>">
                        <span style="font-weight:700;font-size:15px;color:var(--sf-title,#1e293b);line-height:1.4;"><?php echo esc_html($item['question']); ?></span>
                        <span class="sf-faq-icon" style="flex-shrink:0;width:28px;height:28px;border-radius:50%;background:<?php echo $open?'var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C))':'var(--sf-bg-2,#f8fafc)'; ?>;display:flex;align-items:center;justify-content:center;transition:all .25s;">
                            <i class="<?php echo $open ? esc_attr($open_icon) : esc_attr($closed_icon); ?>" style="font-size:11px;color:<?php echo $open?'#fff':'var(--sf-meta,#94a3b8)'; ?>;" aria-hidden="true"></i>
                        </span>
                    </button>
                    <div id="<?php echo esc_attr($pid); ?>" style="display:<?php echo $open?'block':'none'; ?>;padding:0 24px 20px;font-size:14px;color:var(--sf-text,#64748b);line-height:1.8;">
                        <?php echo wp_kses_post($item['answer']); ?>
                        <?php if(!empty($item['category'])): ?>
                        <div style="margin-top:12px;"><span style="font-size:11px;font-weight:600;padding:2px 10px;border-radius:20px;background:rgba(255,94,46,.08);color:var(--sf-color-primary,#FF5E2E);"><?php echo esc_html($item['category']); ?></span></div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div id="<?php echo esc_attr($uid); ?>-noresults" style="display:none;text-align:center;padding:40px;color:var(--sf-meta,#94a3b8);">
                <div style="font-size:32px;margin-bottom:12px;">🔍</div>
                <?php echo esc_html($s['no_results_text'] ?? 'No results found.'); ?>
            </div>
        </div>
        <script>
        window.sfFaqToggle=function(btn,panelId){
            var panel=document.getElementById(panelId);if(!panel)return;
            var wrap=btn.closest('.sf-faq-item');
            var icon=btn.querySelector('.sf-faq-icon');
            var iEl=btn.querySelector('.sf-faq-icon i');
            var open=panel.style.display!=='none';
            panel.style.display=open?'none':'block';
            btn.setAttribute('aria-expanded',!open);
            if(icon)icon.style.background=!open?'var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C))':'var(--sf-bg-2,#f8fafc)';
            if(iEl)iEl.style.color=!open?'#fff':'var(--sf-meta,#94a3b8)';
            if(wrap)wrap.style.borderColor=!open?'var(--sf-color-primary,#FF5E2E)':'var(--sf-border,#e5e7eb)';
        };
        window.sfFaqSearch=function(uid){
            var q=document.getElementById(uid+'-search').value.toLowerCase();
            var items=document.querySelectorAll('#'+uid+'-list .sf-faq-item');
            var found=0;
            items.forEach(function(item){
                var match=q===''||item.dataset.question.includes(q)||item.dataset.answer.includes(q);
                item.style.display=match?'':'none';
                if(match)found++;
            });
            document.getElementById(uid+'-noresults').style.display=found===0?'block':'none';
        };
        </script>
        <?php
    }
}
