<?php
/**
 * Feature Showcase Widget — Tabs mit Bild-Preview (wie SaaS-Landingpages).
 * @package ThemeFlex
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Feature_Showcase_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'sf_feature_showcase'; }
    public function get_title() { return esc_html__('Feature Showcase','themeflex'); }
    public function get_icon()  { return 'eicon-tabs'; }
    public function get_categories() { return ['themeflex']; }
    public function get_keywords()   { return ['feature','showcase','tabs','preview','product','saas']; }

    protected function register_controls() {
        $this->start_controls_section('s_items',['label'=>'Features']);
        $rep = new \Elementor\Repeater();
        $rep->add_control('tab_icon',['label'=>'Icon','type'=>\Elementor\Controls_Manager::ICONS]);
        $rep->add_control('tab_title',['label'=>'Tab Title','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Feature']);
        $rep->add_control('feature_title',['label'=>'Feature Heading','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Powerful Feature Name']);
        $rep->add_control('feature_desc',['label'=>'Description','type'=>\Elementor\Controls_Manager::WYSIWYG,'default'=>'<p>Describe this feature in detail. Explain the benefit and value it brings.</p>']);
        $rep->add_control('preview_image',['label'=>'Preview Image','type'=>\Elementor\Controls_Manager::MEDIA]);
        $rep->add_control('cta_text',['label'=>'CTA Text','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Learn more']);
        $rep->add_control('cta_url',['label'=>'CTA URL','type'=>\Elementor\Controls_Manager::URL]);
        $this->add_control('features',['type'=>\Elementor\Controls_Manager::REPEATER,'fields'=>$rep->get_controls(),'default'=>[
            ['tab_title'=>'Design','feature_title'=>'Pixel-perfect design tools','feature_desc'=>'<p>Create stunning layouts with our advanced design system. Every component is crafted for perfection.</p>','cta_text'=>'Explore Design'],
            ['tab_title'=>'Speed','feature_title'=>'Lightning-fast performance','feature_desc'=>'<p>Built for speed from the ground up. 90+ PageSpeed scores out of the box, no optimization needed.</p>','cta_text'=>'See Benchmarks'],
            ['tab_title'=>'Widgets','feature_title'=>'66+ Elementor Widgets','feature_desc'=>'<p>From simple text blocks to AI-powered content tools — every widget you need is included.</p>','cta_text'=>'View All Widgets'],
        ],'title_field'=>'{{{ tab_title }}}']);
        $this->add_control('autoplay',['label'=>'Autoplay','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes']);
        $this->add_control('autoplay_speed',['label'=>'Autoplay Speed (ms)','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['ms'=>['min'=>2000,'max'=>8000]],'default'=>['size'=>4000],'condition'=>['autoplay'=>'yes']]);
        $this->end_controls_section();

        $this->start_controls_section('s_style',['label'=>'Style','tab'=>\Elementor\Controls_Manager::TAB_STYLE]);
        $this->add_control('img_radius',['label'=>'Image Radius','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['px'=>['min'=>0,'max'=>32]],'default'=>['size'=>16],'selectors'=>['{{WRAPPER}} .sf-fs-preview img'=>'border-radius:{{SIZE}}px;']]);
        $this->add_control('tab_style',['label'=>'Tab Style','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['pills'=>'Pills','underline'=>'Underline','boxed'=>'Boxed'],'default'=>'pills']);
        $this->end_controls_section();
    }

    protected function render() {
        $s    = $this->get_settings_for_display();
        $uid  = 'sffs-'.$this->get_id();
        $auto = 'yes' === ($s['autoplay'] ?? 'yes');
        $spd  = !empty($s['autoplay_speed']['size']) ? (int)$s['autoplay_speed']['size'] : 4000;
        $tab_style = $s['tab_style'] ?? 'pills';
        $features  = $s['features'];
        if(empty($features)) return;

        $tab_btn_base = 'display:flex;align-items:center;gap:8px;padding:10px 18px;font-weight:600;font-size:14px;cursor:pointer;border:none;font-family:inherit;transition:all .25s;white-space:nowrap;';
        $tab_active = [
            'pills'     => 'background:var(--sf-color-primary,#FF5E2E);color:#fff;border-radius:8px;',
            'underline' => 'color:var(--sf-color-primary,#FF5E2E);border-bottom:2px solid var(--sf-color-primary,#FF5E2E);',
            'boxed'     => 'background:var(--sf-bg,#fff);color:var(--sf-title,#1e293b);box-shadow:0 2px 12px rgba(0,0,0,.08);border-radius:8px;',
        ];
        $tab_inactive = [
            'pills'     => 'background:transparent;color:var(--sf-text,#64748b);border-radius:8px;',
            'underline' => 'color:var(--sf-text,#64748b);border-bottom:2px solid transparent;',
            'boxed'     => 'background:transparent;color:var(--sf-text,#64748b);border-radius:8px;',
        ];
        ?>
        <div class="sf-feature-showcase" id="<?php echo esc_attr($uid); ?>">
            <!-- Tab Nav -->
            <div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:40px;<?php echo 'pills'===$tab_style?'background:var(--sf-bg-2,#f8fafc);padding:6px;border-radius:12px;':( 'underline'===$tab_style?'border-bottom:1px solid var(--sf-border,#e5e7eb);':'background:var(--sf-bg-2,#f8fafc);padding:8px;border-radius:12px;'); ?>">
                <?php foreach($features as $i => $feat):
                    $icon = !empty($feat['tab_icon']['value']) ? $feat['tab_icon']['value'] : '';
                    $active = 0 === $i;
                ?>
                <button class="sf-fs-tab" id="<?php echo esc_attr($uid.'-tab-'.$i); ?>"
                    onclick="sfFsSwitch('<?php echo esc_js($uid); ?>',<?php echo $i; ?>,<?php echo count($features); ?>)"
                    style="<?php echo $tab_btn_base . ($active ? $tab_active[$tab_style] : $tab_inactive[$tab_style]); ?>">
                    <?php if($icon): ?><i class="<?php echo esc_attr($icon); ?>" aria-hidden="true"></i><?php endif; ?>
                    <?php echo esc_html($feat['tab_title']); ?>
                </button>
                <?php endforeach; ?>
            </div>
            <!-- Panels -->
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:center;">
                <?php foreach($features as $i => $feat):
                    $img = !empty($feat['preview_image']['url']) ? $feat['preview_image']['url'] : '';
                    $cta_url = !empty($feat['cta_url']['url']) ? esc_url($feat['cta_url']['url']) : '#';
                ?>
                <div class="sf-fs-panel" id="<?php echo esc_attr($uid.'-panel-'.$i); ?>" style="display:<?php echo 0===$i?'contents':'none'; ?>;">
                    <div style="animation:sfFadeIn .35s ease;">
                        <h3 style="font-family:'Inter Tight',sans-serif;font-size:clamp(24px,3vw,36px);font-weight:800;color:var(--sf-title,#1e293b);margin-bottom:16px;letter-spacing:-.3px;"><?php echo esc_html($feat['feature_title']); ?></h3>
                        <div style="font-size:16px;color:var(--sf-text,#64748b);line-height:1.8;margin-bottom:24px;"><?php echo wp_kses_post($feat['feature_desc']); ?></div>
                        <?php if($feat['cta_text']): ?>
                        <a href="<?php echo $cta_url; ?>" style="display:inline-flex;align-items:center;gap:6px;color:var(--sf-color-primary,#FF5E2E);font-weight:700;text-decoration:none;font-size:15px;">
                            <?php echo esc_html($feat['cta_text']); ?> →
                        </a>
                        <?php endif; ?>
                    </div>
                    <div class="sf-fs-preview">
                        <?php if($img): ?>
                        <img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr($feat['feature_title']); ?>"
                             style="width:100%;border-radius:16px;box-shadow:0 24px 80px rgba(0,0,0,.12);display:block;" loading="lazy" />
                        <?php else: ?>
                        <div style="aspect-ratio:16/10;background:var(--sf-gradient-soft,rgba(255,94,46,.08));border-radius:16px;border:2px dashed var(--sf-border,#e5e7eb);display:flex;align-items:center;justify-content:center;color:var(--sf-meta,#94a3b8);font-size:14px;"><?php esc_html_e('Feature Preview Image','themeflex'); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <!-- Progress dots -->
            <div style="display:flex;justify-content:center;gap:6px;margin-top:32px;">
                <?php for($i=0;$i<count($features);$i++): ?>
                <div id="<?php echo esc_attr($uid.'-dot-'.$i); ?>" style="width:6px;height:6px;border-radius:50%;background:<?php echo 0===$i?'var(--sf-color-primary,#FF5E2E)':'var(--sf-border,#e5e7eb)'; ?>;transition:background .3s,width .3s;<?php echo 0===$i?'width:20px;border-radius:3px;':''; ?>"></div>
                <?php endfor; ?>
            </div>
        </div>
        <style>
        @media(max-width:768px){.sf-fs-panel{display:block!important;grid-template-columns:1fr!important}}
        .sf-fs-panel[style*="display:contents"]{display:contents!important}
        @keyframes sfFadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
        </style>
        <script>
        (function(){
            var uid='<?php echo esc_js($uid); ?>';
            var total=<?php echo count($features); ?>;
            var cur=0;var timer=null;
            var tabActive=<?php echo wp_json_encode($tab_active[$tab_style]); ?>;
            var tabInactive=<?php echo wp_json_encode($tab_inactive[$tab_style]); ?>;
            window.sfFsSwitch=function(id,idx,tot){
                // Hide all panels
                for(var i=0;i<tot;i++){
                    var p=document.getElementById(id+'-panel-'+i);
                    var t=document.getElementById(id+'-tab-'+i);
                    var d=document.getElementById(id+'-dot-'+i);
                    if(p)p.style.display='none';
                    if(t)t.style.cssText=t.style.cssText.replace(/([^;]+;)*/,'')+(tabInactive.replace(/[\r\n]/g,' '));
                    if(d){d.style.background='var(--sf-border,#e5e7eb)';d.style.width='6px';d.style.borderRadius='50%';}
                }
                var ap=document.getElementById(id+'-panel-'+idx);
                var at=document.getElementById(id+'-tab-'+idx);
                var ad=document.getElementById(id+'-dot-'+idx);
                if(ap)ap.style.display='contents';
                if(at)at.style.cssText=at.style.cssText+(tabActive.replace(/[\r\n]/g,' '));
                if(ad){ad.style.background='var(--sf-color-primary,#FF5E2E)';ad.style.width='20px';ad.style.borderRadius='3px';}
                cur=idx;
            };
            <?php if($auto): ?>
            timer=setInterval(function(){sfFsSwitch(uid,(cur+1)%total,total);},<?php echo $spd; ?>);
            document.getElementById(uid).addEventListener('mouseenter',function(){clearInterval(timer);});
            document.getElementById(uid).addEventListener('mouseleave',function(){timer=setInterval(function(){sfFsSwitch(uid,(cur+1)%total,total);},<?php echo $spd; ?>);});
            <?php endif; ?>
        })();
        </script>
        <?php
    }
}
