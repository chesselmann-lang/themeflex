<?php
/**
 * Elementor Flip Box Widget
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Flip Box Widget Class
 *
 * @since 1.0.0
 */
class ThemeFlex_Flip_Box_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'themeflex_flip_box';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Flip Box', 'themeflex' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-flip';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'themeflex' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Front Content Section
		$this->start_controls_section(
			'front_content_section',
			array(
				'label' => esc_html__( 'Front Side', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Front Image
		$this->add_control(
			'front_image',
			array(
				'label'   => esc_html__( 'Image', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => array(
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				),
			)
		);

		// Front Icon
		$this->add_control(
			'front_icon',
			array(
				'label'   => esc_html__( 'Icon', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::ICONS,
				'default' => array(
					'value'   => 'fas fa-star',
					'library' => 'fa-solid',
				),
			)
		);

		// Front Title
		$this->add_control(
			'front_title',
			array(
				'label'       => esc_html__( 'Title', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Front Title', 'themeflex' ),
				'placeholder' => esc_html__( 'Enter title', 'themeflex' ),
			)
		);

		$this->end_controls_section();

		// Back Content Section
		$this->start_controls_section(
			'back_content_section',
			array(
				'label' => esc_html__( 'Back Side', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Back Title
		$this->add_control(
			'back_title',
			array(
				'label'       => esc_html__( 'Title', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Back Title', 'themeflex' ),
				'placeholder' => esc_html__( 'Enter title', 'themeflex' ),
			)
		);

		// Back Content
		$this->add_control(
			'back_content',
			array(
				'label'       => esc_html__( 'Description', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'Add your description here', 'themeflex' ),
				'placeholder' => esc_html__( 'Enter description', 'themeflex' ),
			)
		);

		// Button Text
		$this->add_control(
			'button_text',
			array(
				'label'       => esc_html__( 'Button Text', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Learn More', 'themeflex' ),
				'placeholder' => esc_html__( 'Enter button text', 'themeflex' ),
			)
		);

		// Button URL
		$this->add_control(
			'button_url',
			array(
				'label'       => esc_html__( 'Button URL', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://example.com', 'themeflex' ),
				'default'     => array(
					'url' => '',
				),
			)
		);

		$this->end_controls_section();

		// Settings Section
		$this->start_controls_section(
			'settings_section',
			array(
				'label' => esc_html__( 'Settings', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Flip Direction
		$this->add_control(
			'flip_direction',
			array(
				'label'   => esc_html__( 'Flip Direction', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'horizontal',
				'options' => array(
					'horizontal' => esc_html__( 'Horizontal', 'themeflex' ),
					'vertical'   => esc_html__( 'Vertical', 'themeflex' ),
					'diagonal'   => esc_html__( 'Diagonal', 'themeflex' ),
				),
			)
		);

		$this->end_controls_section();

		// Front Style Section
		$this->start_controls_section(
			'front_style_section',
			array(
				'label' => esc_html__( 'Front Style', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'front_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#0066cc',
				'selectors' => array(
					'{{WRAPPER}} .flip-box-front' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'front_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .flip-box-front' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'icon_size',
			array(
				'label'   => esc_html__( 'Icon Size (px)', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 60,
				),
				'range'   => array(
					'px' => array(
						'min' => 20,
						'max' => 150,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .flip-box-front i' => 'font-size: {{SIZE}}px;',
				),
			)
		);

		$this->end_controls_section();

		// Back Style Section
		$this->start_controls_section(
			'back_style_section',
			array(
				'label' => esc_html__( 'Back Style', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'back_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FF5E2E',
				'selectors' => array(
					'{{WRAPPER}} .flip-box-back' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'back_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .flip-box-back' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$front_image = isset( $settings['front_image']['url'] ) ? $settings['front_image']['url'] : '';
		$front_icon = isset( $settings['front_icon']['value'] ) ? $settings['front_icon']['value'] : 'fas fa-star';
		$front_title = isset( $settings['front_title'] ) ? $settings['front_title'] : esc_html__( 'Front Title', 'themeflex' );
		$back_title = isset( $settings['back_title'] ) ? $settings['back_title'] : esc_html__( 'Back Title', 'themeflex' );
		$back_content = isset( $settings['back_content'] ) ? $settings['back_content'] : '';
		$button_text = isset( $settings['button_text'] ) ? $settings['button_text'] : esc_html__( 'Learn More', 'themeflex' );
		$button_url = isset( $settings['button_url']['url'] ) ? $settings['button_url']['url'] : '';
		$flip_direction = isset( $settings['flip_direction'] ) ? $settings['flip_direction'] : 'horizontal';

		?>
		<div class="flip-box-container" data-flip-direction="<?php echo esc_attr( $flip_direction ); ?>">
			<div class="flip-box" class="flip-<?php echo esc_attr( $flip_direction ); ?>">
				<!-- Front Side -->
				<div class="flip-box-front">
					<?php if ( ! empty( $front_image ) ) : ?>
						<img src="<?php echo esc_url( $front_image ); ?>" alt="<?php echo esc_attr( $front_title ); ?>" class="flip-box-image" />
					<?php else : ?>
						<i class="<?php echo esc_attr( $front_icon ); ?>"></i>
					<?php endif; ?>
					<h3 class="flip-box-title"><?php echo esc_html( $front_title ); ?></h3>
				</div>

				<!-- Back Side -->
				<div class="flip-box-back">
					<h3 class="flip-box-title"><?php echo esc_html( $back_title ); ?></h3>
					<?php if ( ! empty( $back_content ) ) : ?>
						<p class="flip-box-content"><?php echo wp_kses_post( $back_content ); ?></p>
					<?php endif; ?>
					<?php if ( ! empty( $button_text ) && ! empty( $button_url ) ) : ?>
						<a href="<?php echo esc_url( $button_url ); ?>" class="flip-box-btn"><?php echo esc_html( $button_text ); ?></a>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
	}
}
