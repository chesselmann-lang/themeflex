<?php
/**
 * Google Maps Widget for Elementor
 * Embed Google Maps with custom styling, markers, and height control.
 *
 * @package ThemeFlex
 * @since 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class ThemeFlex_Google_Maps_Widget extends \Elementor\Widget_Base {

    public function get_name()       { return 'sf_google_maps'; }
    public function get_title()      { return esc_html__( 'Google Maps', 'themeflex' ); }
    public function get_icon()       { return 'eicon-google-maps'; }
    public function get_categories() { return array( 'themeflex' ); }
    public function get_keywords()   { return array( 'map','maps','google','location','address' ); }

    protected function register_controls() {
        $this->start_controls_section('content', array('label'=>esc_html__('Map','themeflex'),'tab'=>\Elementor\Controls_Manager::TAB_CONTENT));

        $this->add_control('address', array('label'=>esc_html__('Address / Coordinates','themeflex'),'type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Berlin, Germany','label_block'=>true));
        $this->add_control('zoom', array('label'=>esc_html__('Zoom (1-20)','themeflex'),'type'=>\Elementor\Controls_Manager::NUMBER,'default'=>14,'min'=>1,'max'=>20));
        $this->add_responsive_control('height', array('label'=>esc_html__('Height','themeflex'),'type'=>\Elementor\Controls_Manager::SLIDER,'size_units'=>array('px','vh'),'range'=>array('px'=>array('min'=>100,'max'=>800)),'default'=>array('unit'=>'px','size'=>400),'selectors'=>array('{{WRAPPER}} .sf-gmap-frame'=>'height:{{SIZE}}{{UNIT}};')));

        $this->add_control('map_type', array('label'=>esc_html__('Map Type','themeflex'),'type'=>\Elementor\Controls_Manager::SELECT,'default'=>'roadmap','options'=>array('roadmap'=>esc_html__('Roadmap','themeflex'),'satellite'=>esc_html__('Satellite','themeflex'),'hybrid'=>esc_html__('Hybrid','themeflex'),'terrain'=>esc_html__('Terrain','themeflex'))));
        $this->add_control('show_controls', array('label'=>esc_html__('Show Controls','themeflex'),'type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes'));
        $this->add_control('allow_scroll', array('label'=>esc_html__('Scroll to Zoom','themeflex'),'type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'no'));

        $this->add_control('api_key_notice', array(
            'type' => \Elementor\Controls_Manager::RAW_HTML,
            'raw'  => '<small>' . esc_html__('Set your Google Maps API key under Appearance → Customizer → General Settings.', 'themeflex') . '</small>',
            'content_classes' => 'elementor-descriptor',
        ));

        $this->end_controls_section();

        $this->start_controls_section('style_map', array('label'=>esc_html__('Style','themeflex'),'tab'=>\Elementor\Controls_Manager::TAB_STYLE));
        $this->add_control('radius', array('label'=>esc_html__('Border Radius','themeflex'),'type'=>\Elementor\Controls_Manager::SLIDER,'size_units'=>array('px'),'default'=>array('unit'=>'px','size'=>12),'selectors'=>array('{{WRAPPER}} .sf-gmap-wrap'=>'border-radius:{{SIZE}}{{UNIT}};overflow:hidden;')));
        $this->add_group_control(\Elementor\Group_Control_Box_Shadow::get_type(), array('name'=>'map_shadow','selector'=>'{{WRAPPER}} .sf-gmap-wrap'));
        $this->end_controls_section();
    }

    protected function render() {
        $s       = $this->get_settings_for_display();
        $address = rawurlencode( $s['address'] );
        $zoom    = absint($s['zoom']) ?: 14;
        $type    = in_array($s['map_type'], array('roadmap','satellite','hybrid','terrain'), true) ? $s['map_type'] : 'roadmap';
        $ctrl    = 'yes' === ($s['show_controls'] ?? 'yes') ? 1 : 0;
        $scroll  = 'yes' === ($s['allow_scroll'] ?? 'no')  ? 1 : 0;
        $api_key = get_theme_mod('themeflex_google_maps_api_key', '');

        $embed_url = 'https://www.google.com/maps/embed/v1/place?q=' . $address . '&zoom=' . $zoom . '&maptype=' . $type;
        if ($api_key) $embed_url .= '&key=' . rawurlencode($api_key);

        echo '<div class="sf-gmap-wrap"><iframe class="sf-gmap-frame" src="' . esc_url($embed_url) . '" allowfullscreen loading="lazy" referrerpolicy="no-referrer-when-downgrade" title="' . esc_attr($s['address']) . '"></iframe></div>';
        ?>
        <style>
        .sf-gmap-wrap{width:100%;overflow:hidden;}
        .sf-gmap-frame{width:100%;border:none;display:block;}
        </style>
        <?php
    }
}
