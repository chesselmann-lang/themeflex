<?php
/**
 * Horizontal Scroll Section Widget
 * Pinned Scroll — Seite scrollt vertikal, Inhalt bewegt sich seitlich. SaaS-Standard 2024/25.
 * @package ThemeFlex
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Horizontal_Scroll_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'sf_horizontal_scroll'; }
    public function get_title() { return esc_html__('Horizontal Scroll','themeflex'); }
    public function get_icon()  { return 'eicon-slider-album'; }
    public function get_categories() { return ['themeflex']; }
    public function get_keywords()   { return ['horizontal','scroll','animation','pinned','parallax','reveal']; }

    protected function register_controls() {
        $this->start_controls_section('section_slides',['label'=>'Slides']);
        $repeater = new \Elementor\Repeater();
        $repeater->add_control('slide_title',['label'=>'Title','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Step One']);
        $repeater->add_control('slide_number',['label'=>'Number','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'01']);
        $repeater->add_control('slide_desc',['label'=>'Description','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>'Describe this step or feature in a compelling way.']);
        $repeater->add_control('slide_icon',['label'=>'Icon','type'=>\Elementor\Controls_Manager::ICONS]);
        $repeater->add_control('slide_bg',['label'=>'Slide Background','type'=>\Elementor\Controls_Manager::COLOR,'default'=>'']);
        $this->add_control('slides',[
            'type'=>\Elementor\Controls_Manager::REPEATER,'fields'=>$repeater->get_controls(),
            'default'=>[
                ['slide_title'=>'Discover','slide_number'=>'01','slide_desc'=>'Explore our powerful features and find the perfect fit for your workflow.'],
                ['slide_title'=>'Design','slide_number'=>'02','slide_desc'=>'Create stunning layouts with our intuitive drag-and-drop builder.'],
                ['slide_title'=>'Launch','slide_number'=>'03','slide_desc'=>'Go live in minutes with one-click demo import and instant deploy.'],
                ['slide_title'=>'Grow','slide_number'=>'04','slide_desc'=>'Scale your business with built-in analytics and conversion tools.'],
            ],
            'title_field'=>'{{{ slide_number }}} — {{{ slide_title }}}',
        ]);
        $this->add_control('sticky_height_vh',['label'=>'Sticky Height (vh per slide)','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['vh'=>['min'=>50,'max'=>200]],'default'=>['size'=>100]]);
        $this->end_controls_section();
        $this->start_controls_section('section_style',['label'=>'Style','tab'=>\Elementor\Controls_Manager::TAB_STYLE]);
        $this->add_control('section_bg',['label'=>'Background','type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#06021D','selectors'=>['{{WRAPPER}} .sf-hscroll-outer'=>'background:{{VALUE}};']]);
        $this->add_control('number_color',['label'=>'Number Color','type'=>\Elementor\Controls_Manager::COLOR,'selectors'=>['{{WRAPPER}} .sf-hscroll-num'=>'color:{{VALUE}};']]);
        $this->end_controls_section();
    }

    protected function render() {
        $s      = $this->get_settings_for_display();
        $uid    = 'sf-hs-'.$this->get_id();
        $slides = $s['slides'];
        $svh    = (int)($s['sticky_height_vh']['size'] ?? 100);
        $total  = count($slides);
        $height_vh = $total * $svh;
        ?>
        <div class="sf-hscroll-outer" id="<?php echo esc_attr($uid); ?>" style="height:<?php echo $height_vh; ?>vh;position:relative;">
            <div class="sf-hscroll-sticky" style="position:sticky;top:0;height:100vh;overflow:hidden;">
                <div class="sf-hscroll-track" id="<?php echo esc_attr($uid); ?>-track" style="display:flex;height:100%;will-change:transform;transform:translateX(0);">
                    <?php foreach($slides as $i => $slide):
                        $bg = !empty($slide['slide_bg']) ? 'background:'.$slide['slide_bg'].';' : '';
                        $icon = !empty($slide['slide_icon']['value']) ? $slide['slide_icon']['value'] : '';
                    ?>
                    <div class="sf-hscroll-slide" style="min-width:100vw;height:100%;display:flex;align-items:center;justify-content:center;<?php echo esc_attr($bg); ?>">
                        <div style="max-width:600px;padding:40px;text-align:center;">
                            <div class="sf-hscroll-num" style="font-family:'Inter Tight',sans-serif;font-size:clamp(80px,15vw,160px);font-weight:900;line-height:1;color:rgba(255,255,255,.06);margin-bottom:-20px;user-select:none;"><?php echo esc_html($slide['slide_number']); ?></div>
                            <?php if($icon): ?>
                            <div style="width:64px;height:64px;border-radius:16px;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));display:flex;align-items:center;justify-content:center;font-size:28px;color:#fff;margin:0 auto 20px;">
                                <i class="<?php echo esc_attr($icon); ?>" aria-hidden="true"></i>
                            </div>
                            <?php endif; ?>
                            <h3 style="font-family:'Inter Tight',sans-serif;font-size:clamp(28px,5vw,48px);font-weight:800;color:#fff;margin-bottom:16px;"><?php echo esc_html($slide['slide_title']); ?></h3>
                            <p style="font-size:18px;color:rgba(255,255,255,.65);line-height:1.7;"><?php echo esc_html($slide['slide_desc']); ?></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <!-- Progress dots -->
                <div style="position:absolute;bottom:32px;left:50%;transform:translateX(-50%);display:flex;gap:8px;" id="<?php echo esc_attr($uid); ?>-dots">
                    <?php for($i=0;$i<$total;$i++): ?>
                    <div style="width:8px;height:8px;border-radius:50%;background:rgba(255,255,255,<?php echo $i===0?'1':'.3'; ?>);transition:all .3s;" id="<?php echo esc_attr($uid.'-dot-'.$i); ?>"></div>
                    <?php endfor; ?>
                </div>
                <!-- Progress bar -->
                <div style="position:absolute;top:0;left:0;right:0;height:3px;background:rgba(255,255,255,.1);">
                    <div id="<?php echo esc_attr($uid); ?>-bar" style="height:100%;background:var(--sf-gradient,linear-gradient(90deg,#FF5E2E,#00D4FF));width:0;transition:width .1s linear;"></div>
                </div>
            </div>
        </div>
        <script>
        (function(){
            var outer=document.getElementById('<?php echo esc_js($uid); ?>');
            var track=document.getElementById('<?php echo esc_js($uid); ?>-track');
            var bar=document.getElementById('<?php echo esc_js($uid); ?>-bar');
            var total=<?php echo $total; ?>;
            if(!outer||!track)return;
            function update(){
                var rect=outer.getBoundingClientRect();
                var progress=Math.max(0,Math.min(1,-rect.top/(rect.height-window.innerHeight)));
                var tx=progress*(total-1)*100;
                track.style.transform='translateX(-'+tx+'vw)';
                if(bar)bar.style.width=(progress*100)+'%';
                var active=Math.round(progress*(total-1));
                for(var i=0;i<total;i++){
                    var d=document.getElementById('<?php echo esc_js($uid); ?>-dot-'+i);
                    if(d)d.style.background=i===active?'rgba(255,255,255,1)':'rgba(255,255,255,.3)';
                }
            }
            window.addEventListener('scroll',update,{passive:true});
            update();
        })();
        </script>
        <?php
    }
}
