<?php
/**
 * Elementor Hotspot Image Widget
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Hotspot Image Widget Class
 *
 * @since 1.0.0
 */
class ThemeFlex_Hotspot_Image_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'themeflex_hotspot_image';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Hotspot Image', 'themeflex' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-image';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'themeflex' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Base Image
		$this->add_control(
			'base_image',
			array(
				'label'   => esc_html__( 'Image', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => array(
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				),
			)
		);

		// Hotspots Repeater
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'hotspot_position_x',
			array(
				'label'   => esc_html__( 'Position X (%)', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 50,
				),
				'range'   => array(
					'%' => array(
						'min' => 0,
						'max' => 100,
					),
				),
			)
		);

		$repeater->add_control(
			'hotspot_position_y',
			array(
				'label'   => esc_html__( 'Position Y (%)', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 50,
				),
				'range'   => array(
					'%' => array(
						'min' => 0,
						'max' => 100,
					),
				),
			)
		);

		$repeater->add_control(
			'hotspot_title',
			array(
				'label'       => esc_html__( 'Title', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Hotspot Title', 'themeflex' ),
			)
		);

		$repeater->add_control(
			'hotspot_content',
			array(
				'label'       => esc_html__( 'Content', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Hotspot content text', 'themeflex' ),
			)
		);

		$repeater->add_control(
			'hotspot_icon',
			array(
				'label'   => esc_html__( 'Icon', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::ICONS,
				'default' => array(
					'value'   => 'fas fa-info-circle',
					'library' => 'fa-solid',
				),
			)
		);

		$this->add_control(
			'hotspots',
			array(
				'label'      => esc_html__( 'Hotspots', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::REPEATER,
				'fields'     => $repeater->get_controls(),
				'title_field' => '{{{ hotspot_title }}}',
			)
		);

		$this->end_controls_section();

		// Hotspot Style Section
		$this->start_controls_section(
			'hotspot_style_section',
			array(
				'label' => esc_html__( 'Hotspot Style', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'hotspot_size',
			array(
				'label'   => esc_html__( 'Hotspot Size (px)', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 40,
				),
				'range'   => array(
					'px' => array(
						'min' => 20,
						'max' => 100,
					),
				),
			)
		);

		$this->add_control(
			'hotspot_color',
			array(
				'label'     => esc_html__( 'Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#0066cc',
				'selectors' => array(
					'{{WRAPPER}} .hotspot-marker' => 'background-color: {{VALUE}}; border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'hotspot_pulse_animation',
			array(
				'label'        => esc_html__( 'Pulse Animation', 'themeflex' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'themeflex' ),
				'label_off'    => esc_html__( 'No', 'themeflex' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->end_controls_section();

		// Tooltip Style Section
		$this->start_controls_section(
			'tooltip_style_section',
			array(
				'label' => esc_html__( 'Tooltip', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'tooltip_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .hotspot-tooltip' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'tooltip_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#333333',
				'selectors' => array(
					'{{WRAPPER}} .hotspot-tooltip' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$base_image = isset( $settings['base_image']['url'] ) ? $settings['base_image']['url'] : '';
		$hotspots = isset( $settings['hotspots'] ) ? $settings['hotspots'] : array();
		$hotspot_size = isset( $settings['hotspot_size']['size'] ) ? intval( $settings['hotspot_size']['size'] ) : 40;
		$pulse_animation = isset( $settings['hotspot_pulse_animation'] ) && 'yes' === $settings['hotspot_pulse_animation'];

		if ( empty( $base_image ) ) {
			echo '<p>' . esc_html__( 'Please select an image', 'themeflex' ) . '</p>';
			return;
		}

		?>
		<div class="hotspot-image-wrapper" style="--hotspot-size: <?php echo esc_attr( $hotspot_size ); ?>px;">
			<img src="<?php echo esc_url( $base_image ); ?>" alt="<?php esc_attr_e( 'Hotspot Image', 'themeflex' ); ?>" class="hotspot-base-image" />
			<div class="hotspots-container">
				<?php foreach ( $hotspots as $index => $hotspot ) : ?>
					<?php
					$x_pos = isset( $hotspot['hotspot_position_x']['size'] ) ? intval( $hotspot['hotspot_position_x']['size'] ) : 50;
					$y_pos = isset( $hotspot['hotspot_position_y']['size'] ) ? intval( $hotspot['hotspot_position_y']['size'] ) : 50;
					$title = isset( $hotspot['hotspot_title'] ) ? $hotspot['hotspot_title'] : '';
					$content = isset( $hotspot['hotspot_content'] ) ? $hotspot['hotspot_content'] : '';
					$icon = isset( $hotspot['hotspot_icon']['value'] ) ? $hotspot['hotspot_icon']['value'] : 'fas fa-info-circle';
					$pulse_class = $pulse_animation ? ' with-pulse' : '';
					?>
					<div class="hotspot-item" style="left: <?php echo esc_attr( $x_pos ); ?>%; top: <?php echo esc_attr( $y_pos ); ?>%;">
						<div class="hotspot-marker<?php echo esc_attr( $pulse_class ); ?>" role="button" aria-expanded="false" tabindex="0">
							<i class="<?php echo esc_attr( $icon ); ?>"></i>
						</div>
						<div class="hotspot-tooltip" role="tooltip">
							<?php if ( ! empty( $title ) ) : ?>
								<h4 class="hotspot-tooltip-title"><?php echo esc_html( $title ); ?></h4>
							<?php endif; ?>
							<?php if ( ! empty( $content ) ) : ?>
								<p class="hotspot-tooltip-content"><?php echo wp_kses_post( $content ); ?></p>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}
}
