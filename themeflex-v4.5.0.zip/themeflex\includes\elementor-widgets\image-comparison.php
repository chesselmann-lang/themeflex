<?php
/**
 * Image Comparison Slider Widget
 * Drag-handle zwischen zwei Bildern (Before/After mit Swiper-Logik).
 *
 * @package ThemeFlex
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class ThemeFlex_Image_Comparison_Widget extends \Elementor\Widget_Base {

	public function get_name()  { return 'sf_image_comparison'; }
	public function get_title() { return esc_html__( 'Image Comparison', 'themeflex' ); }
	public function get_icon()  { return 'eicon-image-before-after'; }
	public function get_categories() { return [ 'themeflex' ]; }
	public function get_keywords()   { return [ 'before', 'after', 'comparison', 'slider', 'image' ]; }

	protected function register_controls() {
		/* ── Content ── */
		$this->start_controls_section( 'section_content', [
			'label' => esc_html__( 'Images', 'themeflex' ),
		] );

		$this->add_control( 'before_image', [
			'label'   => esc_html__( 'Before Image', 'themeflex' ),
			'type'    => \Elementor\Controls_Manager::MEDIA,
			'default' => [ 'url' => \Elementor\Utils::get_placeholder_image_src() ],
		] );
		$this->add_control( 'before_label', [
			'label'   => esc_html__( 'Before Label', 'themeflex' ),
			'type'    => \Elementor\Controls_Manager::TEXT,
			'default' => 'Before',
		] );
		$this->add_control( 'after_image', [
			'label'   => esc_html__( 'After Image', 'themeflex' ),
			'type'    => \Elementor\Controls_Manager::MEDIA,
			'default' => [ 'url' => \Elementor\Utils::get_placeholder_image_src() ],
		] );
		$this->add_control( 'after_label', [
			'label'   => esc_html__( 'After Label', 'themeflex' ),
			'type'    => \Elementor\Controls_Manager::TEXT,
			'default' => 'After',
		] );
		$this->add_control( 'initial_offset', [
			'label'   => esc_html__( 'Initial Position (%)', 'themeflex' ),
			'type'    => \Elementor\Controls_Manager::SLIDER,
			'range'   => [ '%' => [ 'min' => 5, 'max' => 95 ] ],
			'default' => [ 'unit' => '%', 'size' => 50 ],
		] );

		$this->end_controls_section();

		/* ── Style ── */
		$this->start_controls_section( 'section_style', [
			'label' => esc_html__( 'Style', 'themeflex' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		] );
		$this->add_responsive_control( 'height', [
			'label'      => esc_html__( 'Height', 'themeflex' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => [ 'px', 'vh' ],
			'range'      => [ 'px' => [ 'min' => 200, 'max' => 900 ], 'vh' => [ 'min' => 20, 'max' => 100 ] ],
			'default'    => [ 'unit' => 'px', 'size' => 460 ],
			'selectors'  => [ '{{WRAPPER}} .sf-ic-wrapper' => 'height: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'handle_color', [
			'label'     => esc_html__( 'Handle Color', 'themeflex' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'default'   => '',
			'selectors' => [
				'{{WRAPPER}} .sf-ic-handle' => 'background: {{VALUE}};',
				'{{WRAPPER}} .sf-ic-line'   => 'background: {{VALUE}};',
			],
		] );
		$this->add_control( 'border_radius', [
			'label'     => esc_html__( 'Border Radius', 'themeflex' ),
			'type'      => \Elementor\Controls_Manager::SLIDER,
			'range'     => [ 'px' => [ 'min' => 0, 'max' => 40 ] ],
			'default'   => [ 'size' => 12 ],
			'selectors' => [ '{{WRAPPER}} .sf-ic-wrapper' => 'border-radius: {{SIZE}}px; overflow: hidden;' ],
		] );
		$this->end_controls_section();
	}

	protected function render() {
		$s       = $this->get_settings_for_display();
		$before  = esc_url( $s['before_image']['url'] );
		$after   = esc_url( $s['after_image']['url'] );
		$offset  = isset( $s['initial_offset']['size'] ) ? (int) $s['initial_offset']['size'] : 50;
		$uid     = 'sf-ic-' . $this->get_id();
		?>
		<div class="sf-ic-wrapper" id="<?php echo esc_attr( $uid ); ?>" style="position:relative;overflow:hidden;user-select:none;">
			<!-- After (background) -->
			<div class="sf-ic-after" style="position:absolute;inset:0;background:url('<?php echo $after; ?>') center/cover no-repeat;"></div>
			<!-- Before (clipped) -->
			<div class="sf-ic-before" style="position:absolute;inset:0;overflow:hidden;width:<?php echo $offset; ?>%;">
				<div style="position:absolute;inset:0;background:url('<?php echo $before; ?>') left center/auto 100% no-repeat;min-width:<?php echo round(10000/$offset,2); ?>px;"></div>
			</div>
			<!-- Labels -->
			<?php if ( $s['before_label'] ) : ?>
			<span class="sf-ic-label sf-ic-label--before" style="position:absolute;top:16px;left:16px;"><?php echo esc_html( $s['before_label'] ); ?></span>
			<?php endif; ?>
			<?php if ( $s['after_label'] ) : ?>
			<span class="sf-ic-label sf-ic-label--after" style="position:absolute;top:16px;right:16px;"><?php echo esc_html( $s['after_label'] ); ?></span>
			<?php endif; ?>
			<!-- Drag line + handle -->
			<div class="sf-ic-line" style="position:absolute;top:0;bottom:0;left:<?php echo $offset; ?>%;width:3px;background:var(--sf-color-primary,#FF5E2E);transform:translateX(-50%);pointer-events:none;"></div>
			<div class="sf-ic-handle" tabindex="0" role="slider" aria-label="<?php esc_attr_e('Drag to compare','themeflex'); ?>" aria-valuenow="<?php echo $offset; ?>" aria-valuemin="0" aria-valuemax="100"
				style="position:absolute;top:50%;left:<?php echo $offset; ?>%;transform:translate(-50%,-50%);width:44px;height:44px;background:var(--sf-color-primary,#FF5E2E);border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:ew-resize;box-shadow:0 2px 12px rgba(0,0,0,.25);">
				<svg width="20" height="20" viewBox="0 0 24 24" fill="#fff"><path d="M8 5l-5 7 5 7M16 5l5 7-5 7" stroke="#fff" stroke-width="2" fill="none" stroke-linecap="round"/></svg>
			</div>
		</div>
		<style>
		.sf-ic-label{background:rgba(0,0,0,.5);color:#fff;font-size:12px;font-weight:700;padding:4px 10px;border-radius:4px;pointer-events:none;}
		</style>
		<script>
		(function(){
			var wrap=document.getElementById('<?php echo esc_js($uid); ?>');
			if(!wrap)return;
			var before=wrap.querySelector('.sf-ic-before');
			var line=wrap.querySelector('.sf-ic-line');
			var handle=wrap.querySelector('.sf-ic-handle');
			var dragging=false;
			function setPos(pct){
				pct=Math.max(2,Math.min(98,pct));
				before.style.width=pct+'%';
				line.style.left=pct+'%';
				handle.style.left=pct+'%';
				handle.setAttribute('aria-valuenow',Math.round(pct));
			}
			function getX(e){return (e.touches?e.touches[0].clientX:e.clientX);}
			handle.addEventListener('mousedown',function(e){dragging=true;e.preventDefault();});
			handle.addEventListener('touchstart',function(e){dragging=true;},{passive:true});
			document.addEventListener('mousemove',function(e){if(!dragging)return;var r=wrap.getBoundingClientRect();setPos((getX(e)-r.left)/r.width*100);});
			document.addEventListener('touchmove',function(e){if(!dragging)return;var r=wrap.getBoundingClientRect();setPos((getX(e)-r.left)/r.width*100);},{passive:true});
			document.addEventListener('mouseup',function(){dragging=false;});
			document.addEventListener('touchend',function(){dragging=false;});
			handle.addEventListener('keydown',function(e){
				var cur=parseFloat(handle.style.left);
				if(e.key==='ArrowLeft')setPos(cur-2);
				if(e.key==='ArrowRight')setPos(cur+2);
			});
		})();
		</script>
		<?php
	}
}
