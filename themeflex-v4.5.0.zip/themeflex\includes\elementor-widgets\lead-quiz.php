<?php
/**
 * Lead Quiz Widget — Multi-Step Quiz mit Email-Capture.
 * @package ThemeFlex
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Lead_Quiz_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'sf_lead_quiz'; }
    public function get_title() { return esc_html__('Lead Quiz','themeflex'); }
    public function get_icon()  { return 'eicon-help-o'; }
    public function get_categories() { return ['themeflex']; }
    public function get_keywords()   { return ['quiz','lead','form','survey','questions','conversion']; }

    protected function register_controls() {
        $this->start_controls_section('s_header',['label'=>'Header']);
        $this->add_control('quiz_title',['label'=>'Quiz Title','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'What type of website do you need?']);
        $this->add_control('quiz_subtitle',['label'=>'Subtitle','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>'Answer 3 quick questions and get a personalized recommendation.']);
        $this->add_control('result_title',['label'=>'Result Heading','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Your Perfect Solution']);
        $this->add_control('email_label',['label'=>'Email Step Label','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Get your personalized recommendation']);
        $this->add_control('email_placeholder',['label'=>'Email Placeholder','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'your@email.com']);
        $this->add_control('submit_text',['label'=>'Submit Button','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'See My Results →']);
        $this->add_control('thank_you_text',['label'=>'Thank You Message','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>'Thanks! Check your inbox — we sent your personalized plan.']);
        $this->end_controls_section();

        $this->start_controls_section('s_questions',['label'=>'Questions']);
        $q_rep = new \Elementor\Repeater();
        $q_rep->add_control('question',['label'=>'Question','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'What is your goal?']);
        $a_rep = new \Elementor\Repeater();
        $a_rep->add_control('answer_text',['label'=>'Answer','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Option A']);
        $a_rep->add_control('answer_emoji',['label'=>'Emoji','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'🎯']);
        $q_rep->add_control('answers',['type'=>\Elementor\Controls_Manager::REPEATER,'fields'=>$a_rep->get_controls(),'default'=>[
            ['answer_text'=>'Option A','answer_emoji'=>'🎯'],['answer_text'=>'Option B','answer_emoji'=>'🚀'],['answer_text'=>'Option C','answer_emoji'=>'💡'],
        ],'title_field'=>'{{{ answer_text }}}']);
        $this->add_control('questions',['type'=>\Elementor\Controls_Manager::REPEATER,'fields'=>$q_rep->get_controls(),'default'=>[
            ['question'=>'What is your main goal?','answers'=>[['answer_text'=>'Get more clients','answer_emoji'=>'💼'],['answer_text'=>'Sell products online','answer_emoji'=>'🛒'],['answer_text'=>'Share my portfolio','answer_emoji'=>'🎨']]],
            ['question'=>'What is your timeline?','answers'=>[['answer_text'=>'ASAP — this week','answer_emoji'=>'⚡'],['answer_text'=>'Within a month','answer_emoji'=>'📅'],['answer_text'=>'No rush','answer_emoji'=>'😊']]],
            ['question'=>'What is your budget?','answers'=>[['answer_text'=>'Under €500','answer_emoji'=>'💰'],['answer_text'=>'€500–2000','answer_emoji'=>'💳'],['answer_text'=>'€2000+','answer_emoji'=>'🏆']]],
        ],'title_field'=>'{{{ question }}}']);
        $this->end_controls_section();
    }

    protected function render() {
        $s   = $this->get_settings_for_display();
        $uid = 'sfq-'.$this->get_id();
        $qs  = $s['questions'];
        $total = count($qs);
        ?>
        <div class="sf-quiz" id="<?php echo esc_attr($uid); ?>" style="max-width:640px;margin:0 auto;">
            <!-- Progress Bar -->
            <div style="height:4px;background:var(--sf-border,#e5e7eb);border-radius:2px;margin-bottom:32px;overflow:hidden;">
                <div id="<?php echo esc_attr($uid); ?>-prog" style="height:100%;width:0;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));border-radius:2px;transition:width .4s ease;"></div>
            </div>
            <!-- Steps -->
            <?php foreach ($qs as $qi => $q): ?>
            <div class="sf-quiz-step" id="<?php echo esc_attr($uid.'-step-'.$qi); ?>" style="display:<?php echo $qi===0?'block':'none'; ?>">
                <div style="font-size:12px;font-weight:700;color:var(--sf-meta,#94a3b8);text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;"><?php echo sprintf(esc_html__('Question %d of %d','themeflex'), $qi+1, $total); ?></div>
                <h3 style="font-size:1.4rem;font-weight:800;color:var(--sf-title,#1e293b);margin-bottom:24px;"><?php echo esc_html($q['question']); ?></h3>
                <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px;">
                    <?php foreach ($q['answers'] as $ai => $ans): ?>
                    <button class="sf-quiz-ans" onclick="sfQuizAnswer('<?php echo esc_js($uid); ?>',<?php echo $qi; ?>,<?php echo $total; ?>)"
                        style="padding:20px 16px;border:2px solid var(--sf-border,#e5e7eb);border-radius:12px;background:var(--sf-bg,#fff);cursor:pointer;text-align:center;transition:all .2s;font-family:inherit;"
                        onmouseover="this.style.borderColor='var(--sf-color-primary,#FF5E2E)';this.style.background='rgba(255,94,46,.05)'"
                        onmouseout="this.style.borderColor='var(--sf-border,#e5e7eb)';this.style.background='var(--sf-bg,#fff)'">
                        <div style="font-size:28px;margin-bottom:8px;"><?php echo esc_html($ans['answer_emoji']); ?></div>
                        <div style="font-size:14px;font-weight:600;color:var(--sf-title,#1e293b);"><?php echo esc_html($ans['answer_text']); ?></div>
                    </button>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
            <!-- Email Step -->
            <div id="<?php echo esc_attr($uid.'-email'); ?>" style="display:none;text-align:center;">
                <div style="font-size:48px;margin-bottom:16px;">✨</div>
                <h3 style="font-size:1.4rem;font-weight:800;color:var(--sf-title,#1e293b);margin-bottom:8px;"><?php echo esc_html($s['email_label']); ?></h3>
                <p style="color:var(--sf-text,#64748b);margin-bottom:24px;"><?php echo esc_html($s['quiz_subtitle']); ?></p>
                <div style="display:flex;gap:8px;max-width:400px;margin:0 auto;">
                    <input type="email" id="<?php echo esc_attr($uid.'-email-input'); ?>" placeholder="<?php echo esc_attr($s['email_placeholder']); ?>"
                        style="flex:1;padding:12px 16px;border:1px solid var(--sf-border,#e5e7eb);border-radius:10px;font-size:15px;background:var(--sf-bg,#fff);color:var(--sf-title,#1e293b);outline:none;font-family:inherit;" />
                    <button onclick="sfQuizSubmit('<?php echo esc_js($uid); ?>')"
                        style="padding:12px 20px;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;border:none;border-radius:10px;font-weight:700;font-size:14px;cursor:pointer;white-space:nowrap;font-family:inherit;">
                        <?php echo esc_html($s['submit_text']); ?>
                    </button>
                </div>
            </div>
            <!-- Thank You -->
            <div id="<?php echo esc_attr($uid.'-thanks'); ?>" style="display:none;text-align:center;padding:48px 0;">
                <div style="font-size:64px;margin-bottom:20px;">🎉</div>
                <h3 style="font-size:1.5rem;font-weight:800;color:var(--sf-title,#1e293b);margin-bottom:12px;"><?php echo esc_html($s['result_title']); ?></h3>
                <p style="color:var(--sf-text,#64748b);font-size:15px;"><?php echo esc_html($s['thank_you_text']); ?></p>
            </div>
        </div>
        <script>
        window.sfQuizAnswer=function(id,step,total){
            document.getElementById(id+'-step-'+step).style.display='none';
            var next=step+1;
            var pct=Math.round((next/total)*100);
            document.getElementById(id+'-prog').style.width=pct+'%';
            if(next>=total){document.getElementById(id+'-email').style.display='block';}
            else{document.getElementById(id+'-step-'+next).style.display='block';}
        };
        window.sfQuizSubmit=function(id){
            var email=document.getElementById(id+'-email-input').value;
            if(!email||!email.includes('@')){document.getElementById(id+'-email-input').style.borderColor='#ef4444';return;}
            document.getElementById(id+'-prog').style.width='100%';
            document.getElementById(id+'-email').style.display='none';
            document.getElementById(id+'-thanks').style.display='block';
            console.log('Quiz email captured:',email);
        };
        </script>
        <?php
    }
}
