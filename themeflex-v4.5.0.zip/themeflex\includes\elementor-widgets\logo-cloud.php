<?php
/**
 * Logo Cloud Widget — Client/Partner Logos Raster mit Hover.
 * @package ThemeFlex
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Logo_Cloud_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'sf_logo_cloud'; }
    public function get_title() { return esc_html__('Logo Cloud','themeflex'); }
    public function get_icon()  { return 'eicon-image'; }
    public function get_categories() { return ['themeflex']; }
    public function get_keywords()   { return ['logos','clients','partners','brands','trust']; }

    protected function register_controls() {
        $this->start_controls_section('s_header',['label'=>'Header']);
        $this->add_control('title',['label'=>'Title','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Trusted by industry leaders']);
        $this->add_control('show_title',['label'=>'Show Title','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes']);
        $this->end_controls_section();

        $this->start_controls_section('s_logos',['label'=>'Logos']);
        $rep = new \Elementor\Repeater();
        $rep->add_control('logo_image',['label'=>'Logo','type'=>\Elementor\Controls_Manager::MEDIA]);
        $rep->add_control('logo_name',['label'=>'Company Name','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Company']);
        $rep->add_control('logo_url',['label'=>'Link','type'=>\Elementor\Controls_Manager::URL]);
        $this->add_control('logos',['type'=>\Elementor\Controls_Manager::REPEATER,'fields'=>$rep->get_controls(),'default'=>[
            ['logo_name'=>'Acme Corp'],['logo_name'=>'TechFlow'],['logo_name'=>'Brandify'],
            ['logo_name'=>'Nexus Co'],['logo_name'=>'Pinnacle'],['logo_name'=>'Orbit Inc'],
        ],'title_field'=>'{{{ logo_name }}}']);
        $this->add_responsive_control('columns',['label'=>'Columns','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['3'=>'3','4'=>'4','5'=>'5','6'=>'6'],'default'=>'5','tablet_default'=>'3','mobile_default'=>'2']);
        $this->add_control('logo_height',['label'=>'Logo Height (px)','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['px'=>['min'=>24,'max'=>100]],'default'=>['size'=>48],'selectors'=>['{{WRAPPER}} .sf-logo-item img'=>'height:{{SIZE}}px;']]);
        $this->add_control('grayscale',['label'=>'Grayscale (hover to color)','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes']);
        $this->add_control('show_dividers',['label'=>'Show Dividers','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'no']);
        $this->end_controls_section();
    }

    protected function render() {
        $s    = $this->get_settings_for_display();
        $cols = (int)($s['columns'] ?? 5);
        $gray = 'yes' === ($s['grayscale'] ?? 'yes');
        $div  = 'yes' === ($s['show_dividers'] ?? 'no');
        ?>
        <?php if('yes' === ($s['show_title'] ?? 'yes') && $s['title']): ?>
        <p style="text-align:center;font-size:13px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--sf-meta,#94a3b8);margin-bottom:32px;"><?php echo esc_html($s['title']); ?></p>
        <?php endif; ?>
        <div style="display:grid;grid-template-columns:repeat(<?php echo $cols; ?>,1fr);<?php echo $div?'border:1px solid var(--sf-border,#e5e7eb);border-radius:12px;overflow:hidden;':'gap:24px;'; ?>">
            <?php foreach($s['logos'] as $i => $logo):
                $img = !empty($logo['logo_image']['url']) ? $logo['logo_image']['url'] : '';
                $url = !empty($logo['logo_url']['url']) ? esc_url($logo['logo_url']['url']) : '';
                $ext = !empty($logo['logo_url']['is_external']) ? 'target="_blank" rel="noopener noreferrer"' : '';
                $el  = $url ? 'a' : 'div';
                $border = $div ? 'border-right:1px solid var(--sf-border,#e5e7eb);border-bottom:1px solid var(--sf-border,#e5e7eb);' : '';
            ?>
            <<?php echo $el; ?> class="sf-logo-item" <?php echo $url?"href=\"$url\" $ext":''; ?>
                style="display:flex;align-items:center;justify-content:center;padding:24px 16px;<?php echo $border; ?>text-decoration:none;transition:all .25s;"
                onmouseover="this.style.background='var(--sf-bg-2,#f8fafc)'"
                onmouseout="this.style.background=''">
                <?php if($img): ?>
                <img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr($logo['logo_name']); ?>"
                     style="height:48px;width:auto;object-fit:contain;display:block;<?php echo $gray?'filter:grayscale(1) opacity(.6);transition:filter .3s,opacity .3s;':''; ?>"
                     <?php echo $gray?'onmouseover="this.style.filter=\'none\';this.style.opacity=\'1\'"onmouseout="this.style.filter=\'grayscale(1) opacity(.6)\'"':''; ?>
                     loading="lazy" />
                <?php else: ?>
                <div style="font-weight:800;font-size:16px;color:var(--sf-meta,#94a3b8);<?php echo $gray?'opacity:.5;':''; ?>"><?php echo esc_html($logo['logo_name']); ?></div>
                <?php endif; ?>
            </<?php echo $el; ?>>
            <?php endforeach; ?>
        </div>
        <style>@media(max-width:640px){.sf-logo-item{padding:16px 12px!important}}</style>
        <?php
    }
}
