<?php
/**
 * Elementor Lottie Animation Widget
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Lottie Animation Widget Class
 *
 * @since 1.0.0
 */
class ThemeFlex_Lottie_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'themeflex_lottie';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Lottie Animation', 'themeflex' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-animation';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'themeflex' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// JSON Source
		$this->add_control(
			'json_source',
			array(
				'label'   => esc_html__( 'JSON Source', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'url',
				'options' => array(
					'url'    => esc_html__( 'URL', 'themeflex' ),
					'upload' => esc_html__( 'Upload JSON', 'themeflex' ),
				),
			)
		);

		// JSON URL
		$this->add_control(
			'json_url',
			array(
				'label'       => esc_html__( 'JSON URL', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'https://example.com/animation.json', 'themeflex' ),
				'condition'   => array(
					'json_source' => 'url',
				),
			)
		);

		// JSON Upload
		$this->add_control(
			'json_upload',
			array(
				'label'      => esc_html__( 'JSON File', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::MEDIA,
				'media_type' => 'application/json',
				'condition'  => array(
					'json_source' => 'upload',
				),
			)
		);

		// Trigger Type
		$this->add_control(
			'trigger_type',
			array(
				'label'   => esc_html__( 'Trigger Type', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'none',
				'options' => array(
					'none'     => esc_html__( 'Always Playing', 'themeflex' ),
					'scroll'   => esc_html__( 'On Scroll', 'themeflex' ),
					'hover'    => esc_html__( 'On Hover', 'themeflex' ),
					'click'    => esc_html__( 'On Click', 'themeflex' ),
				),
			)
		);

		// Loop
		$this->add_control(
			'loop',
			array(
				'label'        => esc_html__( 'Loop', 'themeflex' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'themeflex' ),
				'label_off'    => esc_html__( 'No', 'themeflex' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		// Speed
		$this->add_control(
			'speed',
			array(
				'label'   => esc_html__( 'Speed', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 1,
				),
				'range'   => array(
					'px' => array(
						'min'  => 0.5,
						'max'  => 3,
						'step' => 0.1,
					),
				),
			)
		);

		// Direction
		$this->add_control(
			'direction',
			array(
				'label'   => esc_html__( 'Direction', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1'  => esc_html__( 'Forward', 'themeflex' ),
					'-1' => esc_html__( 'Reverse', 'themeflex' ),
				),
			)
		);

		// Autoplay
		$this->add_control(
			'autoplay',
			array(
				'label'        => esc_html__( 'Autoplay', 'themeflex' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'themeflex' ),
				'label_off'    => esc_html__( 'No', 'themeflex' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->end_controls_section();

		// Size Section
		$this->start_controls_section(
			'size_section',
			array(
				'label' => esc_html__( 'Size', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'animation_width',
			array(
				'label'      => esc_html__( 'Width', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%', 'em' ),
				'default'    => array(
					'unit' => 'px',
					'size' => 300,
				),
				'range'      => array(
					'px' => array(
						'min' => 50,
						'max' => 1000,
					),
					'%'  => array(
						'min' => 10,
						'max' => 100,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .lottie-animation' => 'width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'animation_height',
			array(
				'label'      => esc_html__( 'Height', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%', 'em' ),
				'default'    => array(
					'unit' => 'px',
					'size' => 300,
				),
				'range'      => array(
					'px' => array(
						'min' => 50,
						'max' => 1000,
					),
					'%'  => array(
						'min' => 10,
						'max' => 100,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .lottie-animation' => 'height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'alignment',
			array(
				'label'   => esc_html__( 'Alignment', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::CHOOSE,
				'options' => array(
					'flex-start'    => array(
						'title' => esc_html__( 'Left', 'themeflex' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center'        => array(
						'title' => esc_html__( 'Center', 'themeflex' ),
						'icon'  => 'eicon-text-align-center',
					),
					'flex-end'      => array(
						'title' => esc_html__( 'Right', 'themeflex' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'default' => 'center',
				'selectors' => array(
					'{{WRAPPER}}' => 'display: flex; justify-content: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$json_source  = isset( $settings['json_source'] ) ? $settings['json_source'] : 'url';
		$json_url     = isset( $settings['json_url'] ) ? trim( $settings['json_url'] ) : '';
		$json_upload  = isset( $settings['json_upload']['url'] ) ? $settings['json_upload']['url'] : '';
		$trigger_type = isset( $settings['trigger_type'] ) ? $settings['trigger_type'] : 'none';
		$loop         = isset( $settings['loop'] ) && 'yes' === $settings['loop'];
		$speed        = isset( $settings['speed']['size'] ) ? floatval( $settings['speed']['size'] ) : 1;
		$direction    = isset( $settings['direction'] ) ? intval( $settings['direction'] ) : 1;
		$autoplay     = isset( $settings['autoplay'] ) && 'yes' === $settings['autoplay'];

		$animation_src = 'url' === $json_source ? $json_url : $json_upload;

		if ( empty( $animation_src ) ) {
			?>
			<div class="sf-lottie-placeholder" style="display:flex;align-items:center;justify-content:center;padding:40px;border:2px dashed var(--sf-border,#e5e7eb);border-radius:var(--sf-radius,12px);color:var(--sf-muted,#94a3b8);font-size:.9rem;gap:12px;">
				<i class="eicon-animation" aria-hidden="true"></i>
				<?php echo esc_html__( 'Please enter a Lottie JSON URL or upload a file.', 'themeflex' ); ?>
			</div>
			<?php
			return;
		}

		$uid          = 'sflottie-' . $this->get_id();
		$loop_attr    = $loop     ? 'loop'     : '';
		$autoplay_attr = $autoplay ? 'autoplay' : '';
		// lottie-player direction attribute: 1 = forward, -1 = reverse
		$dir_attr     = -1 === $direction ? 'reverse' : 'normal';

		// trigger-based: if not autoplay trigger, we manage via JS
		$should_autoplay = $autoplay && 'none' === $trigger_type;
		?>
		<div class="sf-lottie-wrapper" id="<?php echo esc_attr( $uid ); ?>" style="display:flex;align-items:center;justify-content:center;">
			<lottie-player
				class="lottie-animation"
				src="<?php echo esc_url( $animation_src ); ?>"
				background="transparent"
				speed="<?php echo esc_attr( number_format( $speed, 1 ) ); ?>"
				direction="<?php echo esc_attr( -1 === $direction ? '-1' : '1' ); ?>"
				<?php echo $loop ? 'loop' : ''; ?>
				<?php echo $should_autoplay ? 'autoplay' : ''; ?>
				style="width:100%;height:100%;">
			</lottie-player>
		</div>

		<?php // Load lottie-player from CDN if not already loaded ?>
		<script>
		(function() {
			if (typeof window.__sfLottiePlayerLoaded !== 'undefined') {
				window.__sfLottiePlayerLoaded();
				return;
			}
			if (customElements.get('lottie-player')) return;
			var s = document.createElement('script');
			s.src = 'https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js';
			s.async = true;
			s.onload = function() {
				if (typeof window.__sfLottiePlayerLoaded === 'function') window.__sfLottiePlayerLoaded();
			};
			document.head.appendChild(s);
		})();

		<?php if ( 'scroll' === $trigger_type ) : ?>
		(function() {
			var uid = '<?php echo esc_js( $uid ); ?>';
			function initScrollTrigger() {
				var wrapper = document.getElementById(uid);
				if (!wrapper) return;
				var player = wrapper.querySelector('lottie-player');
				if (!player) return;
				var played = false;
				var obs = new IntersectionObserver(function(entries) {
					entries.forEach(function(e) {
						if (e.isIntersecting && !played) {
							if (player.play) player.play();
							played = <?php echo $loop ? 'false' : 'true'; ?>;
						} else if (!e.isIntersecting && <?php echo $loop ? 'true' : 'false'; ?>) {
							if (player.stop) player.stop();
							played = false;
						}
					});
				}, { threshold: 0.3 });
				obs.observe(wrapper);
			}
			if (customElements.get('lottie-player')) { initScrollTrigger(); }
			else { var prev = window.__sfLottiePlayerLoaded; window.__sfLottiePlayerLoaded = function(){ initScrollTrigger(); if(prev) prev(); }; }
		})();
		<?php elseif ( 'hover' === $trigger_type ) : ?>
		(function() {
			var uid = '<?php echo esc_js( $uid ); ?>';
			function initHoverTrigger() {
				var wrapper = document.getElementById(uid);
				if (!wrapper) return;
				var player = wrapper.querySelector('lottie-player');
				if (!player) return;
				wrapper.addEventListener('mouseenter', function() { if (player.play) player.play(); });
				wrapper.addEventListener('mouseleave', function() { if (player.stop) player.stop(); });
			}
			if (customElements.get('lottie-player')) { initHoverTrigger(); }
			else { var prev = window.__sfLottiePlayerLoaded; window.__sfLottiePlayerLoaded = function(){ initHoverTrigger(); if(prev) prev(); }; }
		})();
		<?php elseif ( 'click' === $trigger_type ) : ?>
		(function() {
			var uid = '<?php echo esc_js( $uid ); ?>';
			var playing = false;
			function initClickTrigger() {
				var wrapper = document.getElementById(uid);
				if (!wrapper) return;
				var player = wrapper.querySelector('lottie-player');
				if (!player) return;
				wrapper.style.cursor = 'pointer';
				wrapper.addEventListener('click', function() {
					if (playing) { if (player.stop) player.stop(); playing = false; }
					else { if (player.play) player.play(); playing = true; }
				});
			}
			if (customElements.get('lottie-player')) { initClickTrigger(); }
			else { var prev = window.__sfLottiePlayerLoaded; window.__sfLottiePlayerLoaded = function(){ initClickTrigger(); if(prev) prev(); }; }
		})();
		<?php endif; ?>
		</script>
		<?php
	}
}
