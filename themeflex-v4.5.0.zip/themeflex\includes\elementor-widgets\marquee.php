<?php
/**
 * Elementor Marquee Ticker Widget
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Marquee Ticker Widget Class
 *
 * @since 1.0.0
 */
class ThemeFlex_Marquee_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'themeflex_marquee';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Marquee Ticker', 'themeflex' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-scroll';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'themeflex' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Marquee Items Repeater
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'item_type',
			array(
				'label'   => esc_html__( 'Type', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'text',
				'options' => array(
					'text'  => esc_html__( 'Text', 'themeflex' ),
					'image' => esc_html__( 'Image', 'themeflex' ),
					'icon'  => esc_html__( 'Icon', 'themeflex' ),
				),
			)
		);

		$repeater->add_control(
			'item_text',
			array(
				'label'       => esc_html__( 'Text', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter text', 'themeflex' ),
				'condition'   => array(
					'item_type' => 'text',
				),
			)
		);

		$repeater->add_control(
			'item_image',
			array(
				'label'     => esc_html__( 'Image', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::MEDIA,
				'condition' => array(
					'item_type' => 'image',
				),
			)
		);

		$repeater->add_control(
			'item_icon',
			array(
				'label'     => esc_html__( 'Icon', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::ICONS,
				'default'   => array(
					'value'   => 'fas fa-star',
					'library' => 'fa-solid',
				),
				'condition' => array(
					'item_type' => 'icon',
				),
			)
		);

		$repeater->add_control(
			'item_link',
			array(
				'label'       => esc_html__( 'Link', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://example.com', 'themeflex' ),
			)
		);

		$this->add_control(
			'marquee_items',
			array(
				'label'      => esc_html__( 'Items', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::REPEATER,
				'fields'     => $repeater->get_controls(),
				'title_field' => '{{{ item_text }}}',
				'default'    => array(
					array(
						'item_type' => 'text',
						'item_text' => 'Marquee Item 1',
					),
					array(
						'item_type' => 'text',
						'item_text' => 'Marquee Item 2',
					),
				),
			)
		);

		$this->end_controls_section();

		// Settings Section
		$this->start_controls_section(
			'settings_section',
			array(
				'label' => esc_html__( 'Settings', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Speed
		$this->add_control(
			'speed',
			array(
				'label'   => esc_html__( 'Speed (seconds)', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 20,
				),
				'range'   => array(
					'px' => array(
						'min' => 5,
						'max' => 100,
					),
				),
			)
		);

		// Direction
		$this->add_control(
			'direction',
			array(
				'label'   => esc_html__( 'Direction', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'left',
				'options' => array(
					'left'  => esc_html__( 'Left to Right', 'themeflex' ),
					'right' => esc_html__( 'Right to Left', 'themeflex' ),
				),
			)
		);

		// Pause on Hover
		$this->add_control(
			'pause_on_hover',
			array(
				'label'        => esc_html__( 'Pause on Hover', 'themeflex' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'themeflex' ),
				'label_off'    => esc_html__( 'No', 'themeflex' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		// Separator
		$this->add_control(
			'separator_type',
			array(
				'label'   => esc_html__( 'Separator', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'text',
				'options' => array(
					'none' => esc_html__( 'None', 'themeflex' ),
					'text' => esc_html__( 'Text', 'themeflex' ),
					'icon' => esc_html__( 'Icon', 'themeflex' ),
				),
			)
		);

		$this->add_control(
			'separator_text',
			array(
				'label'       => esc_html__( 'Separator Text', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '|',
				'placeholder' => esc_html__( 'Enter separator', 'themeflex' ),
				'condition'   => array(
					'separator_type' => 'text',
				),
			)
		);

		$this->add_control(
			'separator_icon',
			array(
				'label'     => esc_html__( 'Separator Icon', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::ICONS,
				'default'   => array(
					'value'   => 'fas fa-circle',
					'library' => 'fa-solid',
				),
				'condition' => array(
					'separator_type' => 'icon',
				),
			)
		);

		$this->end_controls_section();

		// Style Section
		$this->start_controls_section(
			'style_section',
			array(
				'label' => esc_html__( 'Style', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#f5f5f5',
				'selectors' => array(
					'{{WRAPPER}} .marquee-ticker' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#333333',
				'selectors' => array(
					'{{WRAPPER}} .marquee-item' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'height',
			array(
				'label'      => esc_html__( 'Height (px)', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'default'    => array(
					'size' => 60,
				),
				'range'      => array(
					'px' => array(
						'min' => 30,
						'max' => 200,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .marquee-ticker' => 'height: {{SIZE}}px;',
				),
			)
		);

		$this->add_control(
			'gap',
			array(
				'label'      => esc_html__( 'Gap Between Items (px)', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'default'    => array(
					'size' => 30,
				),
				'range'      => array(
					'px' => array(
						'min' => 10,
						'max' => 100,
					),
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Build a single set of marquee items HTML
	 *
	 * @param array  $items          Marquee items array.
	 * @param string $separator_type Separator type.
	 * @param string $separator_text Separator text.
	 * @param string $separator_icon Separator icon class.
	 * @param int    $gap            Gap between items in px.
	 * @return string HTML string.
	 */
	private function build_marquee_items( $items, $separator_type, $separator_text, $separator_icon, $gap ) {
		$html = '';
		$count = count( $items );
		foreach ( $items as $index => $item ) {
			$item_type  = isset( $item['item_type'] ) ? $item['item_type'] : 'text';
			$item_text  = isset( $item['item_text'] ) ? $item['item_text'] : '';
			$item_image = isset( $item['item_image']['url'] ) ? $item['item_image']['url'] : '';
			$item_icon  = isset( $item['item_icon']['value'] ) ? $item['item_icon']['value'] : 'fas fa-star';
			$item_link  = isset( $item['item_link']['url'] ) ? $item['item_link']['url'] : '';
			$tag        = ! empty( $item_link ) ? 'a' : 'span';
			$link_attr  = ! empty( $item_link ) ? ' href="' . esc_url( $item_link ) . '"' : '';

			$html .= '<' . esc_attr( $tag ) . ' class="marquee-item marquee-item-' . esc_attr( $item_type ) . '" style="display:inline-flex;align-items:center;flex-shrink:0;text-decoration:none;"' . $link_attr . '>';
			if ( 'text' === $item_type ) {
				$html .= esc_html( $item_text );
			} elseif ( 'image' === $item_type && $item_image ) {
				$html .= '<img src="' . esc_url( $item_image ) . '" alt="' . esc_attr( $item_text ?: 'Marquee item' ) . '" style="height:40px;width:auto;object-fit:contain;" loading="lazy" />';
			} elseif ( 'icon' === $item_type ) {
				$html .= '<i class="' . esc_attr( $item_icon ) . '" aria-hidden="true"></i>';
			}
			$html .= '</' . esc_attr( $tag ) . '>';

			// Separator between items
			if ( $index < $count - 1 && 'none' !== $separator_type ) {
				if ( 'text' === $separator_type ) {
					$html .= '<span class="marquee-separator" style="display:inline-block;flex-shrink:0;">' . esc_html( $separator_text ) . '</span>';
				} elseif ( 'icon' === $separator_type ) {
					$html .= '<i class="marquee-separator-icon ' . esc_attr( $separator_icon ) . '" aria-hidden="true" style="flex-shrink:0;"></i>';
				}
			}
		}
		return $html;
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$marquee_items  = isset( $settings['marquee_items'] ) ? $settings['marquee_items'] : array();
		$speed          = isset( $settings['speed']['size'] ) ? absint( $settings['speed']['size'] ) : 20;
		$direction      = isset( $settings['direction'] ) ? $settings['direction'] : 'left';
		$pause_on_hover = isset( $settings['pause_on_hover'] ) && 'yes' === $settings['pause_on_hover'];
		$separator_type = isset( $settings['separator_type'] ) ? $settings['separator_type'] : 'text';
		$separator_text = isset( $settings['separator_text'] ) ? $settings['separator_text'] : '|';
		$separator_icon = isset( $settings['separator_icon']['value'] ) ? $settings['separator_icon']['value'] : 'fas fa-circle';
		$gap            = isset( $settings['gap']['size'] ) ? absint( $settings['gap']['size'] ) : 30;

		if ( empty( $marquee_items ) ) {
			echo '<p>' . esc_html__( 'Please add marquee items.', 'themeflex' ) . '</p>';
			return;
		}

		$uid         = 'sfmq-' . $this->get_id();
		$anim_name   = 'sfMarquee' . $this->get_id();
		$anim_dir    = 'right' === $direction ? 'reverse' : 'normal';
		$pause_css   = $pause_on_hover ? '.marquee-ticker:hover .marquee-track{animation-play-state:paused;}' : '';

		// Build item HTML (duplicated for seamless loop)
		$items_html = $this->build_marquee_items( $marquee_items, $separator_type, $separator_text, $separator_icon, $gap );
		?>
		<div class="marquee-ticker sf-marquee-ticker" id="<?php echo esc_attr( $uid ); ?>"
		     style="overflow:hidden;width:100%;display:flex;align-items:center;">
			<div class="marquee-track"
			     style="display:flex;flex-shrink:0;align-items:center;gap:<?php echo absint( $gap ); ?>px;animation:<?php echo esc_attr( $anim_name ); ?> <?php echo absint( $speed ); ?>s linear infinite <?php echo esc_attr( $anim_dir ); ?>;will-change:transform;">
				<?php echo $items_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- already escaped in build method ?>
			</div>
			<!-- Duplicate for seamless loop -->
			<div class="marquee-track" aria-hidden="true"
			     style="display:flex;flex-shrink:0;align-items:center;gap:<?php echo absint( $gap ); ?>px;animation:<?php echo esc_attr( $anim_name ); ?> <?php echo absint( $speed ); ?>s linear infinite <?php echo esc_attr( $anim_dir ); ?>;will-change:transform;">
				<?php echo $items_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>
		</div>
		<style>
		@keyframes <?php echo esc_attr( $anim_name ); ?> {
			from { transform: translateX(0); }
			to   { transform: translateX(-100%); }
		}
		#<?php echo esc_attr( $uid ); ?> { display: flex; }
		#<?php echo esc_attr( $uid ); ?> .marquee-item { white-space: nowrap; }
		<?php echo $pause_css; ?>
		</style>
		<?php
	}
}
