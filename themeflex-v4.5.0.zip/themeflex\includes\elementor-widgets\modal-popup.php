<?php
/**
 * Modal Popup Widget
 * Trigger: Button, Image, Icon, Auto-Open. Inhalt: Text, Video, HTML.
 *
 * @package ThemeFlex
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class ThemeFlex_Modal_Popup_Widget extends \Elementor\Widget_Base {

	public function get_name()  { return 'sf_modal_popup'; }
	public function get_title() { return esc_html__( 'Modal Popup', 'themeflex' ); }
	public function get_icon()  { return 'eicon-lightbox'; }
	public function get_categories() { return [ 'themeflex' ]; }
	public function get_keywords()   { return [ 'modal', 'popup', 'lightbox', 'overlay' ]; }

	protected function register_controls() {
		/* Trigger */
		$this->start_controls_section( 'section_trigger', [ 'label' => esc_html__( 'Trigger', 'themeflex' ) ] );
		$this->add_control( 'trigger_type', [
			'label'   => esc_html__( 'Trigger', 'themeflex' ),
			'type'    => \Elementor\Controls_Manager::SELECT,
			'options' => [ 'button' => 'Button', 'image' => 'Image', 'auto' => 'Auto Open' ],
			'default' => 'button',
		] );
		$this->add_control( 'button_text', [
			'label'     => esc_html__( 'Button Text', 'themeflex' ),
			'type'      => \Elementor\Controls_Manager::TEXT,
			'default'   => 'Open Modal',
			'condition' => [ 'trigger_type' => 'button' ],
		] );
		$this->add_control( 'button_icon', [
			'label'     => esc_html__( 'Button Icon', 'themeflex' ),
			'type'      => \Elementor\Controls_Manager::ICONS,
			'condition' => [ 'trigger_type' => 'button' ],
		] );
		$this->add_control( 'trigger_image', [
			'label'     => esc_html__( 'Trigger Image', 'themeflex' ),
			'type'      => \Elementor\Controls_Manager::MEDIA,
			'condition' => [ 'trigger_type' => 'image' ],
		] );
		$this->add_control( 'auto_delay', [
			'label'     => esc_html__( 'Delay (seconds)', 'themeflex' ),
			'type'      => \Elementor\Controls_Manager::SLIDER,
			'range'     => [ 'px' => [ 'min' => 0, 'max' => 30 ] ],
			'default'   => [ 'size' => 3 ],
			'condition' => [ 'trigger_type' => 'auto' ],
		] );
		$this->end_controls_section();

		/* Content */
		$this->start_controls_section( 'section_content', [ 'label' => esc_html__( 'Modal Content', 'themeflex' ) ] );
		$this->add_control( 'modal_title', [
			'label'   => esc_html__( 'Title', 'themeflex' ),
			'type'    => \Elementor\Controls_Manager::TEXT,
			'default' => 'Modal Title',
		] );
		$this->add_control( 'content_type', [
			'label'   => esc_html__( 'Content Type', 'themeflex' ),
			'type'    => \Elementor\Controls_Manager::SELECT,
			'options' => [ 'text' => 'Text/HTML', 'video' => 'Video', 'image' => 'Image' ],
			'default' => 'text',
		] );
		$this->add_control( 'modal_content', [
			'label'     => esc_html__( 'Content', 'themeflex' ),
			'type'      => \Elementor\Controls_Manager::WYSIWYG,
			'default'   => 'Add your modal content here.',
			'condition' => [ 'content_type' => 'text' ],
		] );
		$this->add_control( 'video_url', [
			'label'       => esc_html__( 'Video URL', 'themeflex' ),
			'type'        => \Elementor\Controls_Manager::URL,
			'placeholder' => 'https://www.youtube.com/watch?v=...',
			'condition'   => [ 'content_type' => 'video' ],
		] );
		$this->add_control( 'modal_image', [
			'label'     => esc_html__( 'Image', 'themeflex' ),
			'type'      => \Elementor\Controls_Manager::MEDIA,
			'condition' => [ 'content_type' => 'image' ],
		] );
		$this->add_control( 'max_width', [
			'label'     => esc_html__( 'Max Width', 'themeflex' ),
			'type'      => \Elementor\Controls_Manager::SLIDER,
			'range'     => [ 'px' => [ 'min' => 300, 'max' => 1200 ] ],
			'default'   => [ 'size' => 700 ],
			'selectors' => [ '{{WRAPPER}} .sf-modal-box' => 'max-width: {{SIZE}}px;' ],
		] );
		$this->end_controls_section();
	}

	protected function render() {
		$s   = $this->get_settings_for_display();
		$uid = 'sfm-' . $this->get_id();
		$bid = $uid . '-btn';
		$mid = $uid . '-modal';

		// Convert video URL to embed
		$video_embed = '';
		if ( 'video' === $s['content_type'] && ! empty( $s['video_url']['url'] ) ) {
			$url = $s['video_url']['url'];
			if ( strpos( $url, 'youtube.com' ) !== false || strpos( $url, 'youtu.be' ) !== false ) {
				preg_match( '/(?:v=|youtu\.be\/)([A-Za-z0-9_-]+)/', $url, $m );
				if ( isset( $m[1] ) ) {
					$video_embed = 'https://www.youtube-nocookie.com/embed/' . $m[1] . '?autoplay=1';
				}
			} elseif ( strpos( $url, 'vimeo.com' ) !== false ) {
				preg_match( '/vimeo\.com\/(\d+)/', $url, $m );
				if ( isset( $m[1] ) ) {
					$video_embed = 'https://player.vimeo.com/video/' . $m[1] . '?autoplay=1';
				}
			}
		}
		?>
		<!-- Trigger -->
		<?php if ( 'button' === $s['trigger_type'] ) : ?>
		<button class="sf-modal-trigger sf-btn-primary" id="<?php echo esc_attr( $bid ); ?>" aria-haspopup="dialog" onclick="sfOpenModal('<?php echo esc_js($mid); ?>')">
			<?php if ( ! empty( $s['button_icon']['value'] ) ) : ?><i class="<?php echo esc_attr($s['button_icon']['value']); ?>" aria-hidden="true"></i> <?php endif; ?>
			<?php echo esc_html( $s['button_text'] ); ?>
		</button>
		<?php elseif ( 'image' === $s['trigger_type'] && ! empty( $s['trigger_image']['url'] ) ) : ?>
		<img src="<?php echo esc_url($s['trigger_image']['url']); ?>" alt="" class="sf-modal-trigger-img" style="cursor:pointer;" onclick="sfOpenModal('<?php echo esc_js($mid); ?>')" />
		<?php endif; ?>

		<!-- Modal -->
		<div id="<?php echo esc_attr($mid); ?>" class="sf-popup-modal" role="dialog" aria-modal="true" aria-label="<?php echo esc_attr($s['modal_title']); ?>" aria-hidden="true"
			style="display:none;position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.6);align-items:center;justify-content:center;">
			<div class="sf-modal-box" style="background:#fff;border-radius:12px;width:90%;position:relative;box-shadow:0 24px 80px rgba(0,0,0,.3);animation:sfModalIn .25s ease;">
				<button class="sf-modal-x" onclick="sfCloseModal('<?php echo esc_js($mid); ?>')" aria-label="<?php esc_attr_e('Close','themeflex'); ?>"
					style="position:absolute;top:12px;right:12px;width:32px;height:32px;border-radius:50%;background:rgba(0,0,0,.08);border:none;cursor:pointer;font-size:18px;line-height:32px;text-align:center;z-index:1;">&times;</button>
				<?php if ( $s['modal_title'] ) : ?>
				<div style="padding:24px 40px 0;"><h3 style="margin:0;font-size:1.3rem;"><?php echo esc_html($s['modal_title']); ?></h3></div>
				<?php endif; ?>
				<div class="sf-modal-body" style="padding:24px 40px 32px;">
					<?php if ( 'text' === $s['content_type'] ) :
						echo wp_kses_post( $s['modal_content'] );
					elseif ( 'video' === $s['content_type'] && $video_embed ) : ?>
					<div style="position:relative;padding-bottom:56.25%;height:0;overflow:hidden;border-radius:8px;">
						<iframe class="sf-modal-iframe" style="position:absolute;inset:0;width:100%;height:100%;" frameborder="0" allowfullscreen allow="autoplay; fullscreen"></iframe>
					</div>
					<?php elseif ( 'image' === $s['content_type'] && ! empty($s['modal_image']['url']) ) : ?>
					<img src="<?php echo esc_url($s['modal_image']['url']); ?>" alt="" style="max-width:100%;border-radius:8px;" />
					<?php endif; ?>
				</div>
			</div>
		</div>

		<style>
		@keyframes sfModalIn{from{opacity:0;transform:scale(.94)}to{opacity:1;transform:scale(1)}}
		[data-theme="dark"] .sf-modal-box{background:#1e293b;color:#e2e8f0;}
		</style>
		<script>
		window.sfOpenModal=function(id){
			var m=document.getElementById(id);if(!m)return;
			m.style.display='flex';m.setAttribute('aria-hidden','false');
			document.body.style.overflow='hidden';
			var iframe=m.querySelector('.sf-modal-iframe');
			if(iframe&&iframe.dataset.src)iframe.src=iframe.dataset.src;
			<?php if ( $video_embed ) : ?>
			var ifr=m.querySelector('.sf-modal-iframe');
			if(ifr&&!ifr.src)ifr.src='<?php echo esc_js($video_embed); ?>';
			<?php endif; ?>
			var first=m.querySelector('button,a,[tabindex]');if(first)first.focus();
		};
		window.sfCloseModal=function(id){
			var m=document.getElementById(id);if(!m)return;
			m.style.display='none';m.setAttribute('aria-hidden','true');
			document.body.style.overflow='';
			var ifr=m.querySelector('.sf-modal-iframe');if(ifr)ifr.src='';
		};
		document.addEventListener('keydown',function(e){if(e.key==='Escape'){document.querySelectorAll('.sf-popup-modal[aria-hidden="false"]').forEach(function(m){sfCloseModal(m.id);});}});
		document.querySelectorAll('.sf-popup-modal').forEach(function(m){m.addEventListener('click',function(e){if(e.target===m)sfCloseModal(m.id);});});
		<?php if ( 'auto' === $s['trigger_type'] ) :
			$delay = ! empty( $s['auto_delay']['size'] ) ? (float) $s['auto_delay']['size'] : 3;
		?>
		setTimeout(function(){sfOpenModal('<?php echo esc_js($mid); ?>');},<?php echo (int)($delay*1000); ?>);
		<?php endif; ?>
		</script>
		<?php
	}
}
