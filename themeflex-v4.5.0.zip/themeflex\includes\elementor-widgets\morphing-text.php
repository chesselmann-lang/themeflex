<?php
/**
 * Morphing Text Widget
 * @package ThemeFlex
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Morphing_Text_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'morphing_text'; }
    public function get_title() { return esc_html__('Morphing Text','themeflex'); }
    public function get_icon()  { return 'eicon-animated-headline'; }
    public function get_categories() { return ['themeflex']; }
    public function get_keywords()   { return ['morphing','text','animation','headline','svg','effect']; }

    protected function register_controls() {
        $this->start_controls_section('s1',['label'=>'Content']);
        $this->add_control('before',['label'=>'Before Text','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'We are']);
        $repeater=new \Elementor\Repeater();
        $repeater->add_control('word',['label'=>'Word','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Creative']);
        $this->add_control('words',['type'=>\Elementor\Controls_Manager::REPEATER,'fields'=>$repeater->get_controls(),'default'=>[['word'=>'Creative'],['word'=>'Innovative'],['word'=>'Powerful'],['word'=>'Unstoppable']],'title_field'=>'{{{ word }}}']);
        $this->add_control('after',['label'=>'After Text','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'']);
        $this->add_control('tag',['label'=>'HTML Tag','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['h1'=>'H1','h2'=>'H2','h3'=>'H3','p'=>'P'],'default'=>'h2']);
        $this->add_control('morph_duration',['label'=>'Morph Duration (ms)','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['ms'=>['min'=>300,'max'=>2000]],'default'=>['size'=>800]]);
        $this->add_control('pause_duration',['label'=>'Pause Duration (ms)','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['ms'=>['min'=>500,'max'=>4000]],'default'=>['size'=>2000]]);
        $this->end_controls_section();
        $this->start_controls_section('s2',['label'=>'Style','tab'=>\Elementor\Controls_Manager::TAB_STYLE]);
        $this->add_control('text_align',['label'=>'Alignment','type'=>\Elementor\Controls_Manager::CHOOSE,'options'=>['left'=>['icon'=>'eicon-text-align-left','title'=>'Left'],'center'=>['icon'=>'eicon-text-align-center','title'=>'Center'],'right'=>['icon'=>'eicon-text-align-right','title'=>'Right']],'default'=>'center','selectors'=>['{{WRAPPER}} .sf-morph-wrap'=>'text-align:{{VALUE}};']]);
        $this->add_control('morph_color',['label'=>'Animated Word Color','type'=>\Elementor\Controls_Manager::COLOR,'selectors'=>['{{WRAPPER}} .sf-morph-word'=>'color:{{VALUE}};']]);
        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(),['name'=>'heading_typo','selector'=>'{{WRAPPER}} .sf-morph-heading']);
        $this->end_controls_section();
    }

    protected function render() {
        $s     = $this->get_settings_for_display();
        $uid   = 'sfmt-' . $this->get_id();
        $words = array_column( $s['words'], 'word' );
        $tag   = in_array( $s['tag'] ?? 'h2', array( 'h1', 'h2', 'h3', 'p' ), true ) ? $s['tag'] : 'h2';
        $dur   = (int) ( $s['morph_duration']['size'] ?? 800 );
        $pause = (int) ( $s['pause_duration']['size'] ?? 2000 );

        if ( empty( $words ) ) {
            echo '<p>' . esc_html__( 'Please add words to animate.', 'themeflex' ) . '</p>';
            return;
        }
        ?>
        <div class="sf-morph-wrap" id="<?php echo esc_attr( $uid ); ?>">
            <<?php echo esc_attr( $tag ); ?> class="sf-morph-heading" style="font-weight:900;line-height:1.1;color:var(--sf-title,#1e293b);">
                <?php if ( ! empty( $s['before'] ) ) : ?><?php echo esc_html( $s['before'] ); ?> <?php endif; ?><span
                    class="sf-morph-word"
                    id="<?php echo esc_attr( $uid ); ?>-w"
                    style="color:var(--sf-primary,#FF5E2E);display:inline-block;filter:blur(0);opacity:1;transition:filter <?php echo absint( $dur / 2 ); ?>ms ease,opacity <?php echo absint( $dur / 2 ); ?>ms ease;"
                    aria-live="polite"><?php echo esc_html( $words[0] ); ?></span><?php if ( ! empty( $s['after'] ) ) : ?> <?php echo esc_html( $s['after'] ); ?><?php endif; ?>
            </<?php echo esc_attr( $tag ); ?>>
        </div>
        <script>
        (function(){
            var words = <?php echo wp_json_encode( $words ); ?>;
            var el = document.getElementById('<?php echo esc_js( $uid ); ?>-w');
            if (!el || words.length < 2) return;
            var i = 0, dur = <?php echo absint( $dur ); ?>, pause = <?php echo absint( $pause ); ?>;
            function morph() {
                el.style.filter = 'blur(8px)';
                el.style.opacity = '0';
                setTimeout(function() {
                    i = (i + 1) % words.length;
                    el.textContent = words[i];
                    el.style.filter = 'blur(0)';
                    el.style.opacity = '1';
                }, dur / 2);
            }
            setInterval(morph, pause + dur);
        })();
        </script>
        <?php
    }
}
