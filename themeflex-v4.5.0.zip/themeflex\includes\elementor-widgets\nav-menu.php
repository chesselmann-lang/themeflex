<?php
/**
 * Elementor Nav Menu Widget
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;

/**
 * ThemeFlex Nav Menu Widget
 *
 * Elementor widget for displaying navigation menus with mega menu support.
 *
 * @since 1.0.0
 */
class ThemeFlex_Nav_Menu_Widget extends Widget_Base {

	/**
	 * Widget name.
	 *
	 * @var string
	 */
	public $widget_name = 'sf-nav-menu';

	/**
	 * Get widget name.
	 *
	 * @since 1.0.0
	 * @return string Widget name.
	 */
	public function get_name() {
		return $this->widget_name;
	}

	/**
	 * Get widget title.
	 *
	 * @since 1.0.0
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Navigation Menu', 'themeflex' );
	}

	/**
	 * Get widget icon.
	 *
	 * @since 1.0.0
	 * @return string Widget icon class.
	 */
	public function get_icon() {
		return 'eicon-menu-bar';
	}

	/**
	 * Get widget categories.
	 *
	 * @since 1.0.0
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return array( 'themeflex' );
	}

	/**
	 * Register controls.
	 *
	 * @since 1.0.0
	 */
	protected function register_controls() {
		// Content Tab
		$this->start_controls_section(
			'section_content',
			array(
				'label' => esc_html__( 'Menu', 'themeflex' ),
			)
		);

		// Menu Select
		$menus = wp_get_nav_menus();
		$menu_options = array();

		foreach ( $menus as $menu ) {
			$menu_options[ $menu->term_id ] = $menu->name;
		}

		$this->add_control(
			'nav_menu',
			array(
				'label'       => esc_html__( 'Select Menu', 'themeflex' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => $menu_options,
				'default'     => key( $menu_options ),
				'description' => esc_html__( 'Select a WordPress menu', 'themeflex' ),
			)
		);

		// Layout
		$this->add_control(
			'layout',
			array(
				'label'   => esc_html__( 'Layout', 'themeflex' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'horizontal' => esc_html__( 'Horizontal', 'themeflex' ),
					'vertical'   => esc_html__( 'Vertical', 'themeflex' ),
				),
				'default' => 'horizontal',
			)
		);

		// Alignment
		$this->add_control(
			'alignment',
			array(
				'label'   => esc_html__( 'Alignment', 'themeflex' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => array(
					'flex-start'   => array(
						'title' => esc_html__( 'Start', 'themeflex' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center'       => array(
						'title' => esc_html__( 'Center', 'themeflex' ),
						'icon'  => 'eicon-text-align-center',
					),
					'flex-end'     => array(
						'title' => esc_html__( 'End', 'themeflex' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'default'   => 'flex-start',
				'selectors' => array(
					'{{WRAPPER}} .sf-nav-menu' => 'justify-content: {{VALUE}};',
				),
			)
		);

		// Enable Mega Menu
		$this->add_control(
			'enable_mega_menu',
			array(
				'label'        => esc_html__( 'Enable Mega Menu', 'themeflex' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'themeflex' ),
				'label_off'    => esc_html__( 'No', 'themeflex' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->end_controls_section();

		// Mobile Settings
		$this->start_controls_section(
			'section_mobile',
			array(
				'label' => esc_html__( 'Mobile', 'themeflex' ),
			)
		);

		// Mobile Breakpoint
		$this->add_control(
			'mobile_breakpoint',
			array(
				'label'       => esc_html__( 'Mobile Breakpoint (px)', 'themeflex' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => array( 'px' ),
				'range'       => array(
					'px' => array(
						'min' => 320,
						'max' => 1024,
					),
				),
				'default'     => array(
					'unit' => 'px',
					'size' => 768,
				),
			)
		);

		// Hamburger Icon
		$this->add_control(
			'show_hamburger',
			array(
				'label'        => esc_html__( 'Show Hamburger Icon on Mobile', 'themeflex' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'themeflex' ),
				'label_off'    => esc_html__( 'No', 'themeflex' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		// Hamburger Color
		$this->add_control(
			'hamburger_color',
			array(
				'label'     => esc_html__( 'Hamburger Color', 'themeflex' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#333333',
				'selectors' => array(
					'{{WRAPPER}} .sf-hamburger' => 'color: {{VALUE}};',
				),
				'condition' => array(
					'show_hamburger' => 'yes',
				),
			)
		);

		$this->end_controls_section();

		// Style Tab - Menu Items
		$this->start_controls_section(
			'section_style_menu',
			array(
				'label' => esc_html__( 'Menu Items', 'themeflex' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		// Menu Item Typography
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'menu_typography',
				'label'    => esc_html__( 'Typography', 'themeflex' ),
				'selector' => '{{WRAPPER}} .sf-nav-menu .menu-item > a',
			)
		);

		// Normal Color
		$this->add_control(
			'menu_color',
			array(
				'label'     => esc_html__( 'Text Color', 'themeflex' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#333333',
				'selectors' => array(
					'{{WRAPPER}} .sf-nav-menu .menu-item > a' => 'color: {{VALUE}};',
				),
			)
		);

		// Hover Color
		$this->add_control(
			'menu_color_hover',
			array(
				'label'     => esc_html__( 'Hover Color', 'themeflex' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#FF5E2E',
				'selectors' => array(
					'{{WRAPPER}} .sf-nav-menu .menu-item > a:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .sf-nav-menu .menu-item.current-menu-item > a' => 'color: {{VALUE}};',
				),
			)
		);

		// Menu Spacing
		$this->add_control(
			'menu_item_spacing',
			array(
				'label'      => esc_html__( 'Item Spacing', 'themeflex' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 50,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 20,
				),
				'selectors'  => array(
					'{{WRAPPER}} .sf-nav-menu .menu-item' => 'margin-right: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		// Style Tab - Dropdown
		$this->start_controls_section(
			'section_style_dropdown',
			array(
				'label' => esc_html__( 'Dropdown', 'themeflex' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		// Dropdown Background
		$this->add_control(
			'dropdown_bg',
			array(
				'label'     => esc_html__( 'Background Color', 'themeflex' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .sub-menu' => 'background-color: {{VALUE}};',
				),
			)
		);

		// Dropdown Item Color
		$this->add_control(
			'dropdown_color',
			array(
				'label'     => esc_html__( 'Text Color', 'themeflex' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#333333',
				'selectors' => array(
					'{{WRAPPER}} .sub-menu .menu-item > a' => 'color: {{VALUE}};',
				),
			)
		);

		// Dropdown Border
		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'dropdown_border',
				'label'    => esc_html__( 'Border', 'themeflex' ),
				'selector' => '{{WRAPPER}} .sub-menu',
			)
		);

		// Dropdown Animation
		$this->add_control(
			'dropdown_animation',
			array(
				'label'   => esc_html__( 'Animation', 'themeflex' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'fade'       => esc_html__( 'Fade In', 'themeflex' ),
					'slide-down' => esc_html__( 'Slide Down', 'themeflex' ),
					'scale'      => esc_html__( 'Scale', 'themeflex' ),
				),
				'default' => 'fade',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['nav_menu'] ) ) {
			echo esc_html__( 'Please select a menu', 'themeflex' );
			return;
		}

		$menu_id = $settings['nav_menu'];
		$layout = isset( $settings['layout'] ) ? $settings['layout'] : 'horizontal';
		$enable_mega = isset( $settings['enable_mega_menu'] ) && 'yes' === $settings['enable_mega_menu'];
		$animation = isset( $settings['dropdown_animation'] ) ? $settings['dropdown_animation'] : 'fade';

		$classes = array(
			'sf-nav-menu',
			'layout-' . $layout,
			'animation-' . $animation,
		);

		if ( $enable_mega ) {
			$classes[] = 'mega-menu-enabled';
		}

		?>
		<nav class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" role="navigation">
			<?php
			wp_nav_menu(
				array(
					'menu'            => $menu_id,
					'fallback_cb'     => '__return_empty_string',
					'container'       => false,
					'items_wrap'      => '<ul class="menu-items">%3$s</ul>',
					'depth'           => 0,
					'walker'          => $enable_mega ? new ThemeFlex_Mega_Menu_Walker() : null,
				)
			);
			?>
			<?php if ( 'yes' === $settings['show_hamburger'] ) : ?>
				<button class="sf-hamburger" aria-label="<?php esc_attr_e( 'Toggle menu', 'themeflex' ); ?>">
					<span></span>
					<span></span>
					<span></span>
				</button>
			<?php endif; ?>
		</nav>
		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * @since 1.0.0
	 */
	protected function content_template() {
		?>
		<nav class="sf-nav-menu">
			<div class="placeholder"><?php esc_html_e( 'Menu preview not available in editor', 'themeflex' ); ?></div>
		</nav>
		<?php
	}
}
