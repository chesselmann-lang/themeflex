<?php
/**
 * Newsletter Form Widget — Mailchimp/ConvertKit ready Signup.
 * @package ThemeFlex
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Newsletter_Form_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'sf_newsletter_form'; }
    public function get_title() { return esc_html__('Newsletter Form','themeflex'); }
    public function get_icon()  { return 'eicon-email'; }
    public function get_categories() { return ['themeflex']; }
    public function get_keywords()   { return ['newsletter','email','subscribe','mailchimp','form','list']; }

    protected function register_controls() {
        $this->start_controls_section('s_content',['label'=>'Content']);
        $this->add_control('layout',['label'=>'Layout','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['inline'=>'Inline (row)','stacked'=>'Stacked (column)','card'=>'Card with background'],'default'=>'inline']);
        $this->add_control('badge',['label'=>'Badge Text','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Newsletter']);
        $this->add_control('title',['label'=>'Heading','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Stay in the loop']);
        $this->add_control('subtitle',['label'=>'Subtitle','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>'Get the latest tips, tutorials, and offers — straight to your inbox. No spam, ever.']);
        $this->add_control('name_field',['label'=>'Show Name Field','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'no']);
        $this->add_control('email_placeholder',['label'=>'Email Placeholder','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Enter your email address']);
        $this->add_control('button_text',['label'=>'Button Text','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Subscribe']);
        $this->add_control('privacy_text',['label'=>'Privacy Note','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'We respect your privacy. Unsubscribe anytime.']);
        $this->add_control('success_text',['label'=>'Success Message','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'🎉 Welcome aboard! Check your inbox.']);
        $this->add_control('action_url',['label'=>'Form Action URL','type'=>\Elementor\Controls_Manager::URL,'description'=>'Mailchimp/ConvertKit POST endpoint or leave empty for built-in AJAX.']);
        $this->end_controls_section();

        $this->start_controls_section('s_style',['label'=>'Style','tab'=>\Elementor\Controls_Manager::TAB_STYLE]);
        $this->add_control('bg_color',['label'=>'Background','type'=>\Elementor\Controls_Manager::COLOR,'selectors'=>['{{WRAPPER}} .sf-nl-card'=>'background:{{VALUE}};']]);
        $this->add_control('btn_color',['label'=>'Button Color','type'=>\Elementor\Controls_Manager::COLOR,'selectors'=>['{{WRAPPER}} .sf-nl-btn'=>'background:{{VALUE}};border-color:{{VALUE}};']]);
        $this->end_controls_section();
    }

    protected function render() {
        $s   = $this->get_settings_for_display();
        $uid = 'sfnl-'.$this->get_id();
        $layout  = $s['layout'] ?? 'inline';
        $action  = !empty($s['action_url']['url']) ? esc_url($s['action_url']['url']) : '';
        $is_card = 'card' === $layout;
        $card_style = $is_card ? 'background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:20px;padding:48px 40px;text-align:center;' : '';
        $inline_flex = 'inline' === $layout ? 'display:flex;gap:8px;flex-wrap:wrap;' : 'display:flex;flex-direction:column;gap:10px;';
        ?>
        <div class="sf-nl-card" style="<?php echo $card_style; ?>">
            <?php if($is_card): ?>
            <?php if($s['badge']): ?><span style="display:inline-block;padding:4px 14px;border-radius:20px;background:rgba(255,94,46,.1);color:var(--sf-color-primary,#FF5E2E);font-size:12px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;margin-bottom:16px;"><?php echo esc_html($s['badge']); ?></span><?php endif; ?>
            <?php if($s['title']): ?><h3 style="font-family:'Inter Tight',sans-serif;font-size:2rem;font-weight:800;color:var(--sf-title,#1e293b);margin:0 0 12px;letter-spacing:-.3px;"><?php echo esc_html($s['title']); ?></h3><?php endif; ?>
            <?php if($s['subtitle']): ?><p style="color:var(--sf-text,#64748b);margin:0 0 28px;max-width:480px;margin-left:auto;margin-right:auto;line-height:1.7;"><?php echo esc_html($s['subtitle']); ?></p><?php endif; ?>
            <?php endif; ?>

            <form id="<?php echo esc_attr($uid); ?>-form" onsubmit="sfNlSubmit(event,'<?php echo esc_js($uid); ?>')" style="<?php echo $is_card?'max-width:480px;margin:0 auto;':''; ?>">
                <?php if('yes' === ($s['name_field'] ?? 'no')): ?>
                <input type="text" name="FNAME" placeholder="<?php esc_attr_e('Your name','themeflex'); ?>"
                    style="width:100%;padding:13px 16px;border:1px solid var(--sf-border,#e5e7eb);border-radius:10px;font-size:15px;background:var(--sf-bg,#fff);color:var(--sf-title,#1e293b);margin-bottom:8px;box-sizing:border-box;font-family:inherit;outline:none;" />
                <?php endif; ?>
                <div style="<?php echo $inline_flex; ?>align-items:stretch;">
                    <input type="email" name="EMAIL" required id="<?php echo esc_attr($uid); ?>-email"
                        placeholder="<?php echo esc_attr($s['email_placeholder'] ?? 'Enter your email'); ?>"
                        style="flex:1;min-width:220px;padding:13px 16px;border:1px solid var(--sf-border,#e5e7eb);border-radius:10px;font-size:15px;background:var(--sf-bg,#fff);color:var(--sf-title,#1e293b);font-family:inherit;outline:none;transition:border-color .2s;"
                        onfocus="this.style.borderColor='var(--sf-color-primary,#FF5E2E)'"
                        onblur="this.style.borderColor='var(--sf-border,#e5e7eb)'" />
                    <button type="submit" class="sf-nl-btn"
                        style="padding:13px 24px;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;border:none;border-radius:10px;font-weight:700;font-size:15px;cursor:pointer;white-space:nowrap;font-family:inherit;transition:opacity .2s;"
                        onmouseover="this.style.opacity='.9'" onmouseout="this.style.opacity='1'">
                        <?php echo esc_html($s['button_text'] ?? 'Subscribe'); ?>
                    </button>
                </div>
                <?php if($s['privacy_text']): ?>
                <p style="font-size:12px;color:var(--sf-meta,#94a3b8);margin:10px 0 0;<?php echo $is_card?'text-align:center;':''; ?>"><?php echo esc_html($s['privacy_text']); ?></p>
                <?php endif; ?>
                <?php if($action): ?><input type="hidden" name="action_url" value="<?php echo $action; ?>" /><?php endif; ?>
            </form>
            <div id="<?php echo esc_attr($uid); ?>-success" style="display:none;text-align:center;padding:16px;font-weight:600;color:#10b981;font-size:16px;"><?php echo esc_html($s['success_text'] ?? '🎉 Welcome!'); ?></div>
        </div>
        <script>
        window.sfNlSubmit=window.sfNlSubmit||function(e,id){
            e.preventDefault();
            var form=e.target;var email=document.getElementById(id+'-email').value;
            if(!email)return;
            var actionUrl=form.action_url?form.action_url.value:'';
            form.style.opacity='.5';form.style.pointerEvents='none';
            var done=function(){form.style.display='none';document.getElementById(id+'-success').style.display='block';};
            if(actionUrl){
                fetch(actionUrl,{method:'POST',body:new FormData(form)}).then(done).catch(done);
            } else {
                var fd=new FormData();fd.append('action','sf_newsletter_subscribe');fd.append('email',email);fd.append('nonce','<?php echo wp_create_nonce('sf_nl_nonce'); ?>');
                fetch('<?php echo admin_url('admin-ajax.php'); ?>',{method:'POST',body:fd}).then(done).catch(done);
            }
        };
        </script>
        <?php
    }
}
