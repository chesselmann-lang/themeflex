<?php
/**
 * Interactive Pricing Calculator Widget
 * Kunden konfigurieren live ihren Preis — Echtzeit via JS.
 * @package ThemeFlex
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Pricing_Calculator_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'sf_pricing_calculator'; }
    public function get_title() { return esc_html__('Pricing Calculator','themeflex'); }
    public function get_icon()  { return 'eicon-counter'; }
    public function get_categories() { return ['themeflex']; }
    public function get_keywords()   { return ['pricing','calculator','configurator','quote','cost']; }

    protected function register_controls() {
        $this->start_controls_section('section_header',['label'=>esc_html__('Header','themeflex')]);
        $this->add_control('title',['label'=>'Title','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Calculate Your Price']);
        $this->add_control('subtitle',['label'=>'Subtitle','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>'Drag the sliders to build your custom plan.']);
        $this->add_control('currency',['label'=>'Currency Symbol','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'$']);
        $this->add_control('price_label',['label'=>'Price Label','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'/ month']);
        $this->add_control('cta_text',['label'=>'CTA Text','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Get Started']);
        $this->add_control('cta_url',['label'=>'CTA URL','type'=>\Elementor\Controls_Manager::URL]);
        $this->end_controls_section();

        $this->start_controls_section('section_sliders',['label'=>esc_html__('Sliders','themeflex')]);
        $repeater = new \Elementor\Repeater();
        $repeater->add_control('label',['label'=>'Label','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Users']);
        $repeater->add_control('min',['label'=>'Min','type'=>\Elementor\Controls_Manager::NUMBER,'default'=>1]);
        $repeater->add_control('max',['label'=>'Max','type'=>\Elementor\Controls_Manager::NUMBER,'default'=>100]);
        $repeater->add_control('step',['label'=>'Step','type'=>\Elementor\Controls_Manager::NUMBER,'default'=>1]);
        $repeater->add_control('default_val',['label'=>'Default','type'=>\Elementor\Controls_Manager::NUMBER,'default'=>10]);
        $repeater->add_control('price_per_unit',['label'=>'Price per unit','type'=>\Elementor\Controls_Manager::NUMBER,'default'=>2]);
        $repeater->add_control('unit_label',['label'=>'Unit label','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'users']);
        $this->add_control('sliders',[
            'type'=>\Elementor\Controls_Manager::REPEATER,'fields'=>$repeater->get_controls(),
            'default'=>[
                ['label'=>'Team Members','min'=>1,'max'=>50,'step'=>1,'default_val'=>5,'price_per_unit'=>10,'unit_label'=>'members'],
                ['label'=>'Storage (GB)','min'=>5,'max'=>500,'step'=>5,'default_val'=>50,'price_per_unit'=>0.1,'unit_label'=>'GB'],
                ['label'=>'Monthly Emails','min'=>100,'max'=>50000,'step'=>100,'default_val'=>1000,'price_per_unit'=>0.005,'unit_label'=>'emails'],
            ],
            'title_field'=>'{{{ label }}}',
        ]);
        $this->add_control('base_price',['label'=>'Base Price','type'=>\Elementor\Controls_Manager::NUMBER,'default'=>9]);
        $this->end_controls_section();

        $this->start_controls_section('section_style',['label'=>'Style','tab'=>\Elementor\Controls_Manager::TAB_STYLE]);
        $this->add_control('bg_color',['label'=>'Card Background','type'=>\Elementor\Controls_Manager::COLOR,'selectors'=>['{{WRAPPER}} .sf-calc-card'=>'background:{{VALUE}};']]);
        $this->add_control('accent_color',['label'=>'Accent Color','type'=>\Elementor\Controls_Manager::COLOR,'selectors'=>['{{WRAPPER}} .sf-calc-slider-fill, {{WRAPPER}} .sf-calc-price'=>'color:{{VALUE}};','{{WRAPPER}} .sf-calc-track-fill'=>'background:{{VALUE}};']]);
        $this->end_controls_section();
    }

    protected function render() {
        $s   = $this->get_settings_for_display();
        $uid = 'sf-calc-'.$this->get_id();
        $sliders_json = wp_json_encode(array_map(function($sl) {
            return ['label'=>$sl['label'],'min'=>(float)$sl['min'],'max'=>(float)$sl['max'],'step'=>(float)$sl['step'],'val'=>(float)$sl['default_val'],'ppu'=>(float)$sl['price_per_unit'],'unit'=>$sl['unit_label']];
        }, $s['sliders']));
        $base  = (float)($s['base_price'] ?? 9);
        $cur   = esc_html($s['currency'] ?? '$');
        $plbl  = esc_html($s['price_label'] ?? '/ month');
        $cta_url = !empty($s['cta_url']['url']) ? esc_url($s['cta_url']['url']) : '#';
        ?>
        <div class="sf-calc-card" id="<?php echo esc_attr($uid); ?>" style="background:var(--sf-bg-2,#f8fafc);border:1px solid var(--sf-border,#e5e7eb);border-radius:16px;padding:40px;max-width:640px;margin:0 auto;">
            <?php if($s['title']): ?><h3 style="font-size:1.5rem;font-weight:800;color:var(--sf-title,#1e293b);margin-bottom:8px;"><?php echo esc_html($s['title']); ?></h3><?php endif; ?>
            <?php if($s['subtitle']): ?><p style="color:var(--sf-text,#64748b);margin-bottom:32px;"><?php echo esc_html($s['subtitle']); ?></p><?php endif; ?>
            <div class="sf-calc-sliders" id="<?php echo esc_attr($uid); ?>-sliders"></div>
            <div style="display:flex;align-items:center;justify-content:space-between;margin-top:32px;padding-top:24px;border-top:1px solid var(--sf-border,#e5e7eb);flex-wrap:wrap;gap:16px;">
                <div>
                    <div style="font-size:13px;color:var(--sf-meta,#94a3b8);margin-bottom:4px;">Your total</div>
                    <div class="sf-calc-price" style="font-size:3rem;font-weight:900;color:var(--sf-color-primary,#FF5E2E);line-height:1;">
                        <span class="sf-calc-cur"><?php echo $cur; ?></span><span class="sf-calc-num" id="<?php echo esc_attr($uid); ?>-total"><?php echo number_format($base, 2); ?></span>
                        <span style="font-size:1rem;font-weight:400;color:var(--sf-meta,#94a3b8);margin-left:4px;"><?php echo $plbl; ?></span>
                    </div>
                </div>
                <a href="<?php echo $cta_url; ?>" class="sf-btn-primary" style="background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;padding:14px 28px;border-radius:10px;font-weight:700;text-decoration:none;font-size:15px;display:inline-block;">
                    <?php echo esc_html($s['cta_text'] ?? 'Get Started'); ?>
                </a>
            </div>
        </div>
        <style>
        .sf-calc-slider-wrap{margin-bottom:24px}
        .sf-calc-slider-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;font-size:14px}
        .sf-calc-slider-label{font-weight:600;color:var(--sf-title,#1e293b)}
        .sf-calc-slider-val{color:var(--sf-color-primary,#FF5E2E);font-weight:700}
        .sf-calc-range{position:relative;height:6px;background:var(--sf-border,#e5e7eb);border-radius:3px;margin:8px 0}
        .sf-calc-track-fill{position:absolute;left:0;top:0;height:100%;border-radius:3px;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));pointer-events:none;transition:width .1s}
        input[type=range].sf-calc-input{position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:pointer;margin:0}
        input[type=range].sf-calc-input::-webkit-slider-thumb{-webkit-appearance:none;width:18px;height:18px;border-radius:50%;background:#fff;border:2px solid var(--sf-color-primary,#FF5E2E);box-shadow:0 1px 4px rgba(0,0,0,.2);cursor:pointer}
        .sf-calc-thumb{position:absolute;top:50%;transform:translate(-50%,-50%);width:18px;height:18px;border-radius:50%;background:#fff;border:2px solid var(--sf-color-primary,#FF5E2E);box-shadow:0 1px 4px rgba(0,0,0,.2);pointer-events:none;transition:left .1s}
        [data-theme=dark] .sf-calc-card{background:var(--sf-alt-bg-2,#1e293b)!important;border-color:var(--sf-alt-border,rgba(255,255,255,.08))!important}
        [data-theme=dark] .sf-calc-slider-label,[data-theme=dark] .sf-calc-price{color:var(--sf-alt-title,#f1f5f9)}
        </style>
        <script>
        (function(){
            var uid='<?php echo esc_js($uid); ?>';
            var sliders=<?php echo $sliders_json; ?>;
            var base=<?php echo $base; ?>;
            var cont=document.getElementById(uid+'-sliders');
            var totalEl=document.getElementById(uid+'-total');
            if(!cont||!totalEl)return;
            function calcTotal(){
                var t=base;
                sliders.forEach(function(sl){t+=sl.val*sl.ppu;});
                totalEl.textContent=t.toFixed(2);
            }
            sliders.forEach(function(sl,i){
                var pct=((sl.val-sl.min)/(sl.max-sl.min)*100).toFixed(1);
                var wrap=document.createElement('div');wrap.className='sf-calc-slider-wrap';
                wrap.innerHTML='<div class="sf-calc-slider-header"><span class="sf-calc-slider-label">'+sl.label+'</span><span class="sf-calc-slider-val" id="'+uid+'-v'+i+'">'+sl.val+' '+sl.unit+'</span></div><div class="sf-calc-range"><div class="sf-calc-track-fill" id="'+uid+'-f'+i+'" style="width:'+pct+'%"></div><input type="range" class="sf-calc-input" min="'+sl.min+'" max="'+sl.max+'" step="'+sl.step+'" value="'+sl.val+'" data-idx="'+i+'" /><div class="sf-calc-thumb" id="'+uid+'-t'+i+'" style="left:'+pct+'%"></div></div>';
                cont.appendChild(wrap);
            });
            cont.addEventListener('input',function(e){
                var input=e.target;if(!input.dataset.idx)return;
                var i=parseInt(input.dataset.idx);
                sliders[i].val=parseFloat(input.value);
                var pct=((sliders[i].val-sliders[i].min)/(sliders[i].max-sliders[i].min)*100).toFixed(1);
                document.getElementById(uid+'-v'+i).textContent=sliders[i].val+' '+sliders[i].unit;
                document.getElementById(uid+'-f'+i).style.width=pct+'%';
                document.getElementById(uid+'-t'+i).style.left=pct+'%';
                calcTotal();
            });
            calcTotal();
        })();
        </script>
        <?php
    }
}
