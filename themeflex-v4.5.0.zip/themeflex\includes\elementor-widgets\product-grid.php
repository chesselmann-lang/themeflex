<?php
/**
 * WooCommerce Product Grid Widget
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Elementor\Widget_Base' ) ) {
	return;
}

class ThemeFlex_Product_Grid_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 */
	public function get_name() {
		return 'sf-product-grid';
	}

	/**
	 * Get widget title
	 */
	public function get_title() {
		return esc_html__( 'WooCommerce Product Grid', 'themeflex' );
	}

	/**
	 * Get widget icon
	 */
	public function get_icon() {
		return 'eicon-products';
	}

	/**
	 * Get widget categories
	 */
	public function get_categories() {
		return array( 'themeflex-woo' );
	}

	/**
	 * Get widget keywords
	 */
	public function get_keywords() {
		return array( 'product', 'grid', 'woocommerce', 'shop' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {

		// Query Section
		$this->start_controls_section(
			'section_query',
			array(
				'label' => esc_html__( 'Query', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'query_type',
			array(
				'label'   => esc_html__( 'Query Type', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'latest',
				'options' => array(
					'latest'       => esc_html__( 'Latest Products', 'themeflex' ),
					'featured'     => esc_html__( 'Featured Products', 'themeflex' ),
					'sale'         => esc_html__( 'Sale Products', 'themeflex' ),
					'best_selling' => esc_html__( 'Best Selling', 'themeflex' ),
					'top_rated'    => esc_html__( 'Top Rated', 'themeflex' ),
					'by_category'  => esc_html__( 'By Category', 'themeflex' ),
				),
			)
		);

		$this->add_control(
			'category',
			array(
				'label'       => esc_html__( 'Category', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'multiple'    => true,
				'options'     => self::get_product_categories(),
				'condition'   => array(
					'query_type' => 'by_category',
				),
			)
		);

		$this->add_control(
			'columns',
			array(
				'label'   => esc_html__( 'Columns', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => '3',
				'options' => array(
					'2' => esc_html__( '2 Columns', 'themeflex' ),
					'3' => esc_html__( '3 Columns', 'themeflex' ),
					'4' => esc_html__( '4 Columns', 'themeflex' ),
					'5' => esc_html__( '5 Columns', 'themeflex' ),
					'6' => esc_html__( '6 Columns', 'themeflex' ),
				),
			)
		);

		$this->add_control(
			'posts_per_page',
			array(
				'label'   => esc_html__( 'Products Per Page', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 12,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			)
		);

		$this->add_control(
			'orderby',
			array(
				'label'   => esc_html__( 'Order By', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'date',
				'options' => array(
					'date'       => esc_html__( 'Date', 'themeflex' ),
					'title'      => esc_html__( 'Title', 'themeflex' ),
					'price'      => esc_html__( 'Price', 'themeflex' ),
					'popularity' => esc_html__( 'Popularity', 'themeflex' ),
					'rating'     => esc_html__( 'Rating', 'themeflex' ),
					'rand'       => esc_html__( 'Random', 'themeflex' ),
				),
			)
		);

		$this->add_control(
			'order',
			array(
				'label'   => esc_html__( 'Order', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'desc',
				'options' => array(
					'asc'  => esc_html__( 'Ascending', 'themeflex' ),
					'desc' => esc_html__( 'Descending', 'themeflex' ),
				),
			)
		);

		$this->end_controls_section();

		// Display Section
		$this->start_controls_section(
			'section_display',
			array(
				'label' => esc_html__( 'Display Options', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'show_title',
			array(
				'label'   => esc_html__( 'Show Title', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'show_price',
			array(
				'label'   => esc_html__( 'Show Price', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'show_rating',
			array(
				'label'   => esc_html__( 'Show Rating', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'show_add_to_cart',
			array(
				'label'   => esc_html__( 'Show Add to Cart Button', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'show_badge',
			array(
				'label'   => esc_html__( 'Show Sale Badge', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'card_style',
			array(
				'label'   => esc_html__( 'Card Style', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'classic',
				'options' => array(
					'classic'  => esc_html__( 'Classic', 'themeflex' ),
					'minimal'  => esc_html__( 'Minimal', 'themeflex' ),
					'overlay'  => esc_html__( 'Overlay', 'themeflex' ),
					'featured' => esc_html__( 'Featured', 'themeflex' ),
				),
			)
		);

		$this->add_control(
			'hover_effect',
			array(
				'label'   => esc_html__( 'Hover Effect', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'zoom',
				'options' => array(
					'none'       => esc_html__( 'None', 'themeflex' ),
					'zoom'       => esc_html__( 'Zoom', 'themeflex' ),
					'fade'       => esc_html__( 'Fade', 'themeflex' ),
					'slide'      => esc_html__( 'Slide', 'themeflex' ),
					'lift'       => esc_html__( 'Lift', 'themeflex' ),
				),
			)
		);

		$this->end_controls_section();

		// Style Section
		$this->start_controls_section(
			'section_style',
			array(
				'label' => esc_html__( 'Style', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'grid_spacing',
			array(
				'label'      => esc_html__( 'Grid Spacing', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'default'    => array(
					'size' => 20,
				),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 60,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .sf-product-grid' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'card_bg_color',
			array(
				'label'     => esc_html__( 'Card Background Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .sf-product-card' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'card_border_color',
			array(
				'label'     => esc_html__( 'Card Border Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#eeeeee',
				'selectors' => array(
					'{{WRAPPER}} .sf-product-card' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Get product categories
	 */
	public static function get_product_categories() {
		$categories = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
			)
		);

		$options = array();

		if ( ! is_wp_error( $categories ) ) {
			foreach ( $categories as $category ) {
				$options[ $category->slug ] = $category->name;
			}
		}

		return $options;
	}

	/**
	 * Render widget
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( ! class_exists( 'WooCommerce' ) ) {
			echo wp_kses_post( '<div class="sf-notice error"><p>' . esc_html__( 'WooCommerce is not installed', 'themeflex' ) . '</p></div>' );
			return;
		}

		// Build query args
		$args = array(
			'post_type'      => 'product',
			'posts_per_page' => intval( $settings['posts_per_page'] ),
			'orderby'        => $settings['orderby'],
			'order'          => strtoupper( $settings['order'] ),
		);

		// Handle query type
		$query_type = $settings['query_type'];

		if ( 'featured' === $query_type ) {
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'product_visibility',
					'field'    => 'name',
					'terms'    => 'featured',
					'operator' => 'IN',
				),
			);
		} elseif ( 'sale' === $query_type ) {
			$args['meta_query'] = array(
				array(
					'key'     => '_sale_price',
					'value'   => 0,
					'compare' => '>',
				),
			);
		} elseif ( 'best_selling' === $query_type ) {
			$args['meta_key'] = 'total_sales';
			$args['orderby']  = 'meta_value_num';
		} elseif ( 'top_rated' === $query_type ) {
			$args['orderby'] = 'meta_value_num';
			$args['meta_key'] = '_wc_average_rating';
		} elseif ( 'by_category' === $query_type && ! empty( $settings['category'] ) ) {
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'product_cat',
					'field'    => 'slug',
					'terms'    => $settings['category'],
				),
			);
		}

		// Execute query
		$products = new WP_Query( $args );

		// Render grid
		?>
		<div class="sf-product-grid sf-card-style-<?php echo esc_attr( $settings['card_style'] ); ?> sf-hover-<?php echo esc_attr( $settings['hover_effect'] ); ?>" style="display: grid; grid-template-columns: repeat(<?php echo intval( $settings['columns'] ); ?>, 1fr);">
			<?php
			if ( $products->have_posts() ) {
				while ( $products->have_posts() ) {
					$products->the_post();
					$product = wc_get_product( get_the_ID() );

					if ( ! $product ) {
						continue;
					}

					$this->render_product_card( $product, $settings );
				}
				wp_reset_postdata();
			} else {
				?>
				<div class="sf-no-products">
					<?php esc_html_e( 'No products found', 'themeflex' ); ?>
				</div>
				<?php
			}
			?>
		</div>
		<?php
	}

	/**
	 * Render product card
	 */
	private function render_product_card( $product, $settings ) {
		$show_title     = 'yes' === $settings['show_title'];
		$show_price     = 'yes' === $settings['show_price'];
		$show_rating    = 'yes' === $settings['show_rating'];
		$show_add_cart  = 'yes' === $settings['show_add_to_cart'];
		$show_badge     = 'yes' === $settings['show_badge'];
		$card_style     = $settings['card_style'];
		?>
		<div class="sf-product-card sf-<?php echo esc_attr( $card_style ); ?>">
			<?php if ( $show_badge && $product->is_on_sale() ) : ?>
				<div class="sf-product-badge"><?php esc_html_e( 'Sale', 'themeflex' ); ?></div>
			<?php endif; ?>

			<div class="sf-product-image">
				<?php echo wp_kses_post( $product->get_image( 'woocommerce_thumbnail' ) ); ?>
			</div>

			<div class="sf-product-content">
				<?php if ( $show_title ) : ?>
					<h3 class="sf-product-title">
						<a href="<?php echo esc_url( $product->get_permalink() ); ?>">
							<?php echo esc_html( $product->get_name() ); ?>
						</a>
					</h3>
				<?php endif; ?>

				<?php if ( $show_rating ) : ?>
					<div class="sf-product-rating">
						<?php echo wp_kses_post( wc_get_rating_html( $product->get_average_rating() ) ); ?>
					</div>
				<?php endif; ?>

				<?php if ( $show_price ) : ?>
					<div class="sf-product-price">
						<?php echo wp_kses_post( $product->get_price_html() ); ?>
					</div>
				<?php endif; ?>

				<?php if ( $show_add_cart ) : ?>
					<div class="sf-product-add-to-cart">
						<?php echo wp_kses_post( apply_filters( 'woocommerce_loop_add_to_cart_link', sprintf( '<a href="%s" data-quantity="1" class="button %s" %s>%s</a>', esc_url( $product->add_to_cart_url() ), esc_attr( implode( ' ', wc_get_product_class( '', $product ) ) ), isset( $args['attributes'] ) ? wc_implode_html_attributes( $args['attributes'] ) : '', esc_html( $product->add_to_cart_text() ) ), $product ) ); ?>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}
}
