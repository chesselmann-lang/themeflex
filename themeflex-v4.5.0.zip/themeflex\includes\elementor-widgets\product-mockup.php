<?php
/**
 * Device/Product Mockup Widget — Screenshot in Browser/Phone/Tablet Frame.
 * @package ThemeFlex
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Product_Mockup_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'sf_product_mockup'; }
    public function get_title() { return esc_html__('Device Mockup','themeflex'); }
    public function get_icon()  { return 'eicon-device-desktop'; }
    public function get_categories() { return ['themeflex']; }
    public function get_keywords()   { return ['mockup','device','browser','phone','screenshot','preview']; }

    protected function register_controls() {
        $this->start_controls_section('s_content',['label'=>'Content']);
        $this->add_control('device',['label'=>'Device','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['browser'=>'Browser Window','phone'=>'Smartphone','tablet'=>'Tablet','laptop'=>'Laptop Frame'],'default'=>'browser']);
        $this->add_control('screenshot',['label'=>'Screenshot','type'=>\Elementor\Controls_Manager::MEDIA,'default'=>['url'=>\Elementor\Utils::get_placeholder_image_src()]]);
        $this->add_control('browser_url',['label'=>'Browser URL Text','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'https://yourdomain.com','condition'=>['device'=>'browser']]);
        $this->add_control('shadow',['label'=>'Drop Shadow','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes']);
        $this->add_control('float_animation',['label'=>'Float Animation','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes']);
        $this->end_controls_section();
        $this->start_controls_section('s_style',['label'=>'Style','tab'=>\Elementor\Controls_Manager::TAB_STYLE]);
        $this->add_responsive_control('max_width',['label'=>'Max Width','type'=>\Elementor\Controls_Manager::SLIDER,'size_units'=>['px','%'],'range'=>['px'=>['min'=>200,'max'=>1200],'%'=>['min'=>20,'max'=>100]],'default'=>['unit'=>'px','size'=>720],'selectors'=>['{{WRAPPER}} .sf-mockup-outer'=>'max-width:{{SIZE}}{{UNIT}};']]);
        $this->add_control('align',['label'=>'Align','type'=>\Elementor\Controls_Manager::CHOOSE,'options'=>['flex-start'=>['title'=>'Left','icon'=>'eicon-h-align-left'],'center'=>['title'=>'Center','icon'=>'eicon-h-align-center'],'flex-end'=>['title'=>'Right','icon'=>'eicon-h-align-right']],'default'=>'center','selectors'=>['{{WRAPPER}}'.'.sf-mockup-wrap'=>'display:flex;justify-content:{{VALUE}};']]);
        $this->end_controls_section();
    }

    protected function render() {
        $s   = $this->get_settings_for_display();
        $uid = 'sfmk-'.$this->get_id();
        $img = !empty($s['screenshot']['url']) ? esc_url($s['screenshot']['url']) : \Elementor\Utils::get_placeholder_image_src();
        $dev = $s['device'] ?? 'browser';
        $shadow = 'yes' === ($s['shadow'] ?? 'yes') ? '0 40px 100px rgba(0,0,0,.25)' : 'none';
        $float  = 'yes' === ($s['float_animation'] ?? 'yes') ? 'animation:sfFloat 4s ease-in-out infinite;' : '';
        ?>
        <div class="sf-mockup-wrap" style="display:flex;justify-content:center;">
            <div class="sf-mockup-outer" style="width:100%;max-width:720px;<?php echo $float; ?>">
                <?php if('browser' === $dev): ?>
                <div style="background:#1e293b;border-radius:12px 12px 0 0;padding:12px 16px;display:flex;align-items:center;gap:8px;">
                    <div style="display:flex;gap:5px;">
                        <div style="width:11px;height:11px;border-radius:50%;background:#ff5f57;"></div>
                        <div style="width:11px;height:11px;border-radius:50%;background:#ffbd2e;"></div>
                        <div style="width:11px;height:11px;border-radius:50%;background:#28ca41;"></div>
                    </div>
                    <div style="flex:1;background:#0f172a;border-radius:6px;padding:5px 12px;font-size:12px;color:#64748b;font-family:monospace;"><?php echo esc_html($s['browser_url'] ?? 'https://yourdomain.com'); ?></div>
                </div>
                <div style="border-radius:0 0 12px 12px;overflow:hidden;box-shadow:<?php echo $shadow; ?>;">
                    <img src="<?php echo $img; ?>" alt="<?php esc_attr_e('Website Preview','themeflex'); ?>" style="width:100%;height:auto;display:block;" loading="lazy" />
                </div>

                <?php elseif('phone' === $dev): ?>
                <div style="max-width:320px;margin:0 auto;background:#1e293b;border-radius:40px;padding:12px;box-shadow:<?php echo $shadow; ?>;">
                    <div style="background:#0f172a;border-radius:32px;padding:8px 0 0;overflow:hidden;">
                        <div style="width:80px;height:6px;border-radius:3px;background:#1e293b;margin:0 auto 8px;"></div>
                        <img src="<?php echo $img; ?>" alt="" style="width:100%;height:auto;display:block;border-radius:0 0 28px 28px;" loading="lazy" />
                    </div>
                    <div style="width:60px;height:6px;border-radius:3px;background:#0f172a;margin:8px auto 0;"></div>
                </div>

                <?php elseif('tablet' === $dev): ?>
                <div style="max-width:560px;margin:0 auto;background:#1e293b;border-radius:24px;padding:16px;box-shadow:<?php echo $shadow; ?>;">
                    <div style="background:#0f172a;border-radius:12px;overflow:hidden;">
                        <img src="<?php echo $img; ?>" alt="" style="width:100%;height:auto;display:block;" loading="lazy" />
                    </div>
                    <div style="width:40px;height:6px;border-radius:3px;background:#0f172a;margin:10px auto 0;"></div>
                </div>

                <?php else: /* laptop */ ?>
                <div style="box-shadow:<?php echo $shadow; ?>;">
                    <div style="background:#1e293b;border-radius:12px 12px 0 0;padding:10px 16px;display:flex;align-items:center;gap:6px;">
                        <div style="width:10px;height:10px;border-radius:50%;background:#ff5f57;"></div>
                        <div style="width:10px;height:10px;border-radius:50%;background:#ffbd2e;"></div>
                        <div style="width:10px;height:10px;border-radius:50%;background:#28ca41;"></div>
                    </div>
                    <div style="border:2px solid #1e293b;border-top:none;border-radius:0 0 8px 8px;overflow:hidden;">
                        <img src="<?php echo $img; ?>" alt="" style="width:100%;height:auto;display:block;" loading="lazy" />
                    </div>
                    <div style="background:#2d3748;height:12px;border-radius:0 0 4px 4px;margin:0 -8px;"></div>
                    <div style="background:#374151;height:4px;border-radius:0 0 8px 8px;margin:0 -16px;"></div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <style>
        @keyframes sfFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-12px)}}
        </style>
        <?php
    }
}
