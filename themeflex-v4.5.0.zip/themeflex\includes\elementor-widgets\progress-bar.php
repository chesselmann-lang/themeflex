<?php
/**
 * Elementor Progress Bar Widget
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Progress Bar Widget Class
 *
 * @since 1.0.0
 */
class ThemeFlex_Progress_Bar_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'themeflex_progress_bar';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Progress Bar', 'themeflex' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-skill-bar';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'themeflex' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Skills', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Skills Repeater
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'skill_name',
			array(
				'label'       => esc_html__( 'Skill Name', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Skill', 'themeflex' ),
				'placeholder' => esc_html__( 'e.g., HTML/CSS', 'themeflex' ),
			)
		);

		$repeater->add_control(
			'skill_percentage',
			array(
				'label'   => esc_html__( 'Percentage', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 50,
				),
				'range'   => array(
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
			)
		);

		$this->add_control(
			'skills',
			array(
				'label'       => esc_html__( 'Skills', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => array(
					array(
						'skill_name'       => esc_html__( 'HTML/CSS', 'themeflex' ),
						'skill_percentage' => array( 'size' => 90 ),
					),
					array(
						'skill_name'       => esc_html__( 'JavaScript', 'themeflex' ),
						'skill_percentage' => array( 'size' => 80 ),
					),
					array(
						'skill_name'       => esc_html__( 'PHP', 'themeflex' ),
						'skill_percentage' => array( 'size' => 75 ),
					),
				),
				'title_field' => '{{{ skill_name }}}',
			)
		);

		// Show percentage text
		$this->add_control(
			'show_percentage_text',
			array(
				'label'        => esc_html__( 'Show Percentage Text', 'themeflex' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'themeflex' ),
				'label_off'    => esc_html__( 'No', 'themeflex' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->end_controls_section();

		// Style Section - Bar
		$this->start_controls_section(
			'bar_style_section',
			array(
				'label' => esc_html__( 'Bar Style', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'bar_height',
			array(
				'label'   => esc_html__( 'Bar Height (px)', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 10,
				'min'     => 2,
				'max'     => 50,
			)
		);

		$this->add_control(
			'bar_background_color',
			array(
				'label'     => esc_html__( 'Background Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#e8e8e8',
				'selectors' => array(
					'{{WRAPPER}} .progress-background' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'bar_color',
			array(
				'label'     => esc_html__( 'Fill Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#0066cc',
				'selectors' => array(
					'{{WRAPPER}} .progress-fill' => 'background-color: {{VALUE}}',
				),
			)
		);

		// Gradient Fill
		$this->add_control(
			'use_gradient',
			array(
				'label'        => esc_html__( 'Use Gradient', 'themeflex' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'themeflex' ),
				'label_off'    => esc_html__( 'No', 'themeflex' ),
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			array(
				'name'       => 'bar_gradient',
				'label'      => esc_html__( 'Gradient', 'themeflex' ),
				'types'      => array( 'gradient' ),
				'selector'   => '{{WRAPPER}} .progress-fill.gradient',
				'condition'  => array(
					'use_gradient' => 'yes',
				),
			)
		);

		$this->add_control(
			'bar_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'default'    => array(
					'top'    => '5',
					'right'  => '5',
					'bottom' => '5',
					'left'   => '5',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .progress-background' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .progress-fill'       => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Typography
		$this->start_controls_section(
			'typography_section',
			array(
				'label' => esc_html__( 'Typography', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'skill_name_typography',
				'label'    => esc_html__( 'Skill Name Typography', 'themeflex' ),
				'selector' => '{{WRAPPER}} .skill-name',
			)
		);

		$this->add_control(
			'skill_name_color',
			array(
				'label'     => esc_html__( 'Skill Name Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#333333',
				'selectors' => array(
					'{{WRAPPER}} .skill-name' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'percentage_typography',
				'label'    => esc_html__( 'Percentage Typography', 'themeflex' ),
				'selector' => '{{WRAPPER}} .skill-percentage-text',
			)
		);

		$this->add_control(
			'percentage_color',
			array(
				'label'     => esc_html__( 'Percentage Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#666666',
				'selectors' => array(
					'{{WRAPPER}} .skill-percentage-text' => 'color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Spacing
		$this->start_controls_section(
			'spacing_section',
			array(
				'label' => esc_html__( 'Spacing', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'skill_spacing',
			array(
				'label'   => esc_html__( 'Space Between Skills', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 30,
				),
				'range'   => array(
					'px' => array(
						'min' => 5,
						'max' => 100,
					),
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['skills'] ) ) {
			echo '<p>' . esc_html__( 'Please add skills to the progress bar', 'themeflex' ) . '</p>';
			return;
		}

		$show_percentage = isset( $settings['show_percentage_text'] ) ? $settings['show_percentage_text'] : 'yes';
		$bar_height = isset( $settings['bar_height'] ) ? intval( $settings['bar_height'] ) : 10;
		$use_gradient = isset( $settings['use_gradient'] ) ? $settings['use_gradient'] : '';
		$skill_spacing = isset( $settings['skill_spacing']['size'] ) ? intval( $settings['skill_spacing']['size'] ) : 30;

		echo '<div class="progress-bars-container" style="--skill-spacing: ' . esc_attr( $skill_spacing ) . 'px; --bar-height: ' . esc_attr( $bar_height ) . 'px;">';

		foreach ( $settings['skills'] as $index => $skill ) {
			$skill_name = isset( $skill['skill_name'] ) ? $skill['skill_name'] : '';
			$skill_percentage = isset( $skill['skill_percentage']['size'] ) ? intval( $skill['skill_percentage']['size'] ) : 50;

			// Ensure percentage is between 0 and 100
			$skill_percentage = max( 0, min( 100, $skill_percentage ) );

			echo '<div class="skill-item" data-percentage="' . esc_attr( $skill_percentage ) . '">';

			// Skill name and percentage header
			echo '<div class="skill-header">';
			if ( ! empty( $skill_name ) ) {
				printf(
					'<span class="skill-name">%s</span>',
					esc_html( $skill_name )
				);
			}
			if ( 'yes' === $show_percentage ) {
				printf(
					'<span class="skill-percentage-text">%d%%</span>',
					esc_attr( $skill_percentage )
				);
			}
			echo '</div>';

			// Progress bar
			echo '<div class="progress-background">';
			$fill_class = 'yes' === $use_gradient ? 'progress-fill gradient' : 'progress-fill';
			printf(
				'<div class="%s" style="width: 0%;" data-target="%d"></div>',
				esc_attr( $fill_class ),
				esc_attr( $skill_percentage )
			);
			echo '</div>';

			echo '</div>';
		}

		echo '</div>';
	}
}
