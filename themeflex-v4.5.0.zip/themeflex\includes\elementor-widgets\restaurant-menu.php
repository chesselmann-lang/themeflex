<?php
/**
 * Restaurant Menu Card Widget
 * @package ThemeFlex
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Restaurant_Menu_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'restaurant_menu'; }
    public function get_title() { return esc_html__('Restaurant Menu Card','themeflex'); }
    public function get_icon()  { return 'eicon-menu-bar'; }
    public function get_categories() { return ['themeflex']; }
    public function get_keywords()   { return ['restaurant','menu','food','dish','price list','cafe']; }

    protected function register_controls() {
        $this->start_controls_section('s1',['label'=>'Menu']);
        $repeater=new \Elementor\Repeater();
        $repeater->add_control('section_title',['label'=>'Section Title','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Starters']);
        $items_rep=new \Elementor\Repeater();
        $items_rep->add_control('dish_name',['label'=>'Dish','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Caesar Salad']);
        $items_rep->add_control('dish_desc',['label'=>'Description','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>'Romaine lettuce, parmesan, croutons']);
        $items_rep->add_control('dish_price',['label'=>'Price','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'12.90']);
        $items_rep->add_control('dish_badge',['label'=>'Badge (Vegan/New/etc)','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'']);
        $items_rep->add_control('dish_image',['label'=>'Image','type'=>\Elementor\Controls_Manager::MEDIA]);
        $repeater->add_control('dishes',['type'=>\Elementor\Controls_Manager::REPEATER,'fields'=>$items_rep->get_controls(),'default'=>[
            ['dish_name'=>'Caesar Salad','dish_desc'=>'Romaine, parmesan, croutons, Caesar dressing','dish_price'=>'12.90'],
            ['dish_name'=>'Tomato Soup','dish_desc'=>'Roasted tomato, basil, cream','dish_price'=>'8.50','dish_badge'=>'Vegan'],
        ],'title_field'=>'{{{ dish_name }}}']);
        $this->add_control('sections',['type'=>\Elementor\Controls_Manager::REPEATER,'fields'=>$repeater->get_controls(),'default'=>[
            ['section_title'=>'Starters'],['section_title'=>'Mains'],
        ],'title_field'=>'{{{ section_title }}}']);
        $this->add_control('currency',['label'=>'Currency','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'€']);
        $this->add_control('show_images',['label'=>'Show Dish Images','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'no']);
        $this->end_controls_section();
    }

    protected function render() {
        $s=$this->get_settings_for_display();$cur=esc_html($s['currency']??'€');
        $show_img='yes'===($s['show_images']??'no');
        ?>
        <div class="sf-menu-wrap">
        <?php foreach($s['sections'] as $sec): if(empty($sec['dishes']))continue;?>
        <div class="sf-menu-section" style="margin-bottom:40px;">
            <h4 style="font-family:'Inter Tight',sans-serif;font-size:1.2rem;font-weight:800;color:var(--sf-title,#1e293b);margin-bottom:16px;padding-bottom:10px;border-bottom:2px solid var(--sf-color-primary,#FF5E2E);"><?php echo esc_html($sec['section_title']);?></h4>
            <?php foreach($sec['dishes'] as $d):
                $img=!empty($d['dish_image']['url'])?$d['dish_image']['url']:'';
            ?>
            <div style="display:flex;gap:12px;align-items:flex-start;padding:14px 0;border-bottom:1px solid var(--sf-border,#e5e7eb);">
                <?php if($show_img&&$img):?><img src="<?php echo esc_url($img);?>" alt="" style="width:64px;height:64px;border-radius:8px;object-fit:cover;flex-shrink:0;" loading="lazy"/><?php endif;?>
                <div style="flex:1;min-width:0;">
                    <div style="display:flex;align-items:center;gap:8px;margin-bottom:3px;">
                        <span style="font-weight:700;font-size:15px;color:var(--sf-title,#1e293b);"><?php echo esc_html($d['dish_name']);?></span>
                        <?php if(!empty($d['dish_badge'])):?><span style="font-size:10px;font-weight:700;padding:2px 6px;border-radius:4px;background:rgba(16,185,129,.12);color:#059669;text-transform:uppercase;"><?php echo esc_html($d['dish_badge']);?></span><?php endif;?>
                    </div>
                    <?php if($d['dish_desc']):?><p style="font-size:13px;color:var(--sf-text,#64748b);line-height:1.5;margin:0;"><?php echo esc_html($d['dish_desc']);?></p><?php endif;?>
                </div>
                <div style="font-weight:800;font-size:15px;color:var(--sf-color-primary,#FF5E2E);white-space:nowrap;flex-shrink:0;"><?php echo$cur.esc_html($d['dish_price']);?></div>
            </div>
            <?php endforeach;?>
        </div>
        <?php endforeach;?>
        </div>
        <?php
    }
}
