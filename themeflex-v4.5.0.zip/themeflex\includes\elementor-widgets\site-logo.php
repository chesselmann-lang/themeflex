<?php
/**
 * Elementor Site Logo Widget
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * ThemeFlex Site Logo Widget
 *
 * Elementor widget for displaying site logo.
 *
 * @since 1.0.0
 */
class ThemeFlex_Site_Logo_Widget extends Widget_Base {

	/**
	 * Widget name.
	 *
	 * @var string
	 */
	public $widget_name = 'sf-site-logo';

	/**
	 * Get widget name.
	 *
	 * @since 1.0.0
	 * @return string Widget name.
	 */
	public function get_name() {
		return $this->widget_name;
	}

	/**
	 * Get widget title.
	 *
	 * @since 1.0.0
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Site Logo', 'themeflex' );
	}

	/**
	 * Get widget icon.
	 *
	 * @since 1.0.0
	 * @return string Widget icon class.
	 */
	public function get_icon() {
		return 'eicon-logo';
	}

	/**
	 * Get widget categories.
	 *
	 * @since 1.0.0
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return array( 'themeflex' );
	}

	/**
	 * Register controls.
	 *
	 * @since 1.0.0
	 */
	protected function register_controls() {
		// Content Tab
		$this->start_controls_section(
			'section_content',
			array(
				'label' => esc_html__( 'Logo', 'themeflex' ),
			)
		);

		// Logo Source
		$this->add_control(
			'logo_source',
			array(
				'label'   => esc_html__( 'Logo Source', 'themeflex' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'site-logo'     => esc_html__( 'Site Logo (Customizer)', 'themeflex' ),
					'custom-image'  => esc_html__( 'Custom Image', 'themeflex' ),
				),
				'default' => 'site-logo',
			)
		);

		// Custom Image
		$this->add_control(
			'custom_logo',
			array(
				'label'     => esc_html__( 'Logo Image', 'themeflex' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => array(
					'url' => '',
				),
				'condition' => array(
					'logo_source' => 'custom-image',
				),
			)
		);

		// Dark Mode Logo
		$this->add_control(
			'dark_mode_logo',
			array(
				'label'     => esc_html__( 'Dark Mode Logo', 'themeflex' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => array(
					'url' => '',
				),
				'condition' => array(
					'logo_source' => 'custom-image',
				),
			)
		);

		// Link
		$this->add_control(
			'link_to',
			array(
				'label'   => esc_html__( 'Link To', 'themeflex' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'home'   => esc_html__( 'Home URL', 'themeflex' ),
					'custom' => esc_html__( 'Custom URL', 'themeflex' ),
					'none'   => esc_html__( 'None', 'themeflex' ),
				),
				'default' => 'home',
			)
		);

		// Custom URL
		$this->add_control(
			'custom_link',
			array(
				'label'       => esc_html__( 'Custom URL', 'themeflex' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => 'https://example.com',
				'condition'   => array(
					'link_to' => 'custom',
				),
			)
		);

		$this->end_controls_section();

		// Size Settings
		$this->start_controls_section(
			'section_size',
			array(
				'label' => esc_html__( 'Size', 'themeflex' ),
			)
		);

		// Logo Width
		$this->add_control(
			'logo_width',
			array(
				'label'      => esc_html__( 'Width', 'themeflex' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array(
						'min' => 20,
						'max' => 500,
					),
					'%'  => array(
						'min' => 10,
						'max' => 100,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 200,
				),
				'selectors'  => array(
					'{{WRAPPER}} .sf-site-logo img' => 'width: {{SIZE}}{{UNIT}}; height: auto;',
				),
			)
		);

		// Max Width
		$this->add_control(
			'logo_max_width',
			array(
				'label'      => esc_html__( 'Max Width', 'themeflex' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array(
						'min' => 20,
						'max' => 500,
					),
					'%'  => array(
						'min' => 10,
						'max' => 100,
					),
				),
				'default'    => array(
					'unit' => '%',
					'size' => 100,
				),
				'selectors'  => array(
					'{{WRAPPER}} .sf-site-logo' => 'max-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		// Style Tab
		$this->start_controls_section(
			'section_style',
			array(
				'label' => esc_html__( 'Style', 'themeflex' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		// Alignment
		$this->add_control(
			'alignment',
			array(
				'label'   => esc_html__( 'Alignment', 'themeflex' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'themeflex' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'themeflex' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'themeflex' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'default'   => 'left',
				'selectors' => array(
					'{{WRAPPER}} .sf-site-logo' => 'text-align: {{VALUE}};',
				),
			)
		);

		// Margin
		$this->add_control(
			'margin',
			array(
				'label'      => esc_html__( 'Margin', 'themeflex' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em' ),
				'default'    => array(
					'top'      => 0,
					'right'    => 20,
					'bottom'   => 0,
					'left'     => 0,
					'unit'     => 'px',
					'isLinked' => false,
				),
				'selectors'  => array(
					'{{WRAPPER}} .sf-site-logo' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		// Padding
		$this->add_control(
			'padding',
			array(
				'label'      => esc_html__( 'Padding', 'themeflex' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .sf-site-logo' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		// Border
		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'border',
				'label'    => esc_html__( 'Border', 'themeflex' ),
				'selector' => '{{WRAPPER}} .sf-site-logo img',
			)
		);

		// Box Shadow
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'box_shadow',
				'label'    => esc_html__( 'Box Shadow', 'themeflex' ),
				'selector' => '{{WRAPPER}} .sf-site-logo img',
			)
		);

		// Border Radius
		$this->add_control(
			'border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'themeflex' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .sf-site-logo img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$logo_source = isset( $settings['logo_source'] ) ? $settings['logo_source'] : 'site-logo';
		$link_to = isset( $settings['link_to'] ) ? $settings['link_to'] : 'home';

		// Determine logo URL and attributes
		$logo_url = '';
		$logo_alt = get_bloginfo( 'name' );

		if ( 'site-logo' === $logo_source ) {
			$logo_id = get_theme_mod( 'custom_logo' );
			if ( $logo_id ) {
				$logo_url = wp_get_attachment_image_url( $logo_id, 'full' );
				$logo_alt = get_post_meta( $logo_id, '_wp_attachment_image_alt', true ) ?: $logo_alt;
			}
		} else {
			if ( ! empty( $settings['custom_logo']['url'] ) ) {
				$logo_url = $settings['custom_logo']['url'];
			}
		}

		// Determine link
		$link_url = '';
		switch ( $link_to ) {
			case 'home':
				$link_url = home_url();
				break;
			case 'custom':
				$link_url = ! empty( $settings['custom_link']['url'] ) ? $settings['custom_link']['url'] : '';
				break;
		}

		// Render
		?>
		<div class="sf-site-logo">
			<?php if ( ! empty( $link_url ) ) : ?>
				<a href="<?php echo esc_url( $link_url ); ?>" class="logo-link">
			<?php endif; ?>

			<?php if ( ! empty( $logo_url ) ) : ?>
				<img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( $logo_alt ); ?>" class="logo-image" />
			<?php else : ?>
				<span class="logo-placeholder"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
			<?php endif; ?>

			<?php if ( ! empty( $link_url ) ) : ?>
				</a>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * @since 1.0.0
	 */
	protected function content_template() {
		?>
		<div class="sf-site-logo">
			<span class="logo-placeholder">
				<?php esc_html_e( 'Site Logo', 'themeflex' ); ?>
			</span>
		</div>
		<?php
	}
}
