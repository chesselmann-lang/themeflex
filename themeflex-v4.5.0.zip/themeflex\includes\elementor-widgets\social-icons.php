<?php
/**
 * Elementor Social Icons Widget
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Social Icons Widget Class
 *
 * @since 1.0.0
 */
class ThemeFlex_Social_Icons_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'themeflex_social_icons';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Social Icons', 'themeflex' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'themeflex' );
	}

	/**
	 * Get platform options
	 *
	 * @return array
	 */
	private function get_platform_options() {
		return array(
			'facebook'     => esc_html__( 'Facebook', 'themeflex' ),
			'twitter'      => esc_html__( 'Twitter/X', 'themeflex' ),
			'instagram'    => esc_html__( 'Instagram', 'themeflex' ),
			'linkedin'     => esc_html__( 'LinkedIn', 'themeflex' ),
			'youtube'      => esc_html__( 'YouTube', 'themeflex' ),
			'tiktok'       => esc_html__( 'TikTok', 'themeflex' ),
			'github'       => esc_html__( 'GitHub', 'themeflex' ),
			'dribbble'     => esc_html__( 'Dribbble', 'themeflex' ),
			'behance'      => esc_html__( 'Behance', 'themeflex' ),
			'pinterest'    => esc_html__( 'Pinterest', 'themeflex' ),
			'whatsapp'     => esc_html__( 'WhatsApp', 'themeflex' ),
			'telegram'     => esc_html__( 'Telegram', 'themeflex' ),
			'email'        => esc_html__( 'Email', 'themeflex' ),
		);
	}

	/**
	 * Get icon class for platform
	 *
	 * @param string $platform Platform name.
	 * @return string
	 */
	private function get_icon_class( $platform ) {
		$icons = array(
			'facebook'     => 'eicon-social-facebook',
			'twitter'      => 'eicon-social-twitter',
			'instagram'    => 'eicon-social-instagram',
			'linkedin'     => 'eicon-social-linkedin',
			'youtube'      => 'eicon-social-youtube',
			'tiktok'       => 'fab fa-tiktok',
			'github'       => 'eicon-social-github',
			'dribbble'     => 'fab fa-dribbble',
			'behance'      => 'fab fa-behance',
			'pinterest'    => 'eicon-social-pinterest',
			'whatsapp'     => 'fab fa-whatsapp',
			'telegram'     => 'fab fa-telegram',
			'email'        => 'eicon-mail',
		);

		return isset( $icons[ $platform ] ) ? $icons[ $platform ] : 'eicon-link';
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Social Accounts', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Social Links Repeater
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'platform',
			array(
				'label'   => esc_html__( 'Platform', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'facebook',
				'options' => $this->get_platform_options(),
			)
		);

		$repeater->add_control(
			'url',
			array(
				'label'       => esc_html__( 'URL', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://example.com', 'themeflex' ),
				'default'     => array(
					'url' => '',
				),
			)
		);

		$this->add_control(
			'social_links',
			array(
				'label'       => esc_html__( 'Social Links', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => array(
					array(
						'platform' => 'facebook',
						'url'      => array( 'url' => '#' ),
					),
					array(
						'platform' => 'twitter',
						'url'      => array( 'url' => '#' ),
					),
					array(
						'platform' => 'instagram',
						'url'      => array( 'url' => '#' ),
					),
				),
				'title_field' => '{{{ platform }}}',
			)
		);

		$this->end_controls_section();

		// Settings Section
		$this->start_controls_section(
			'settings_section',
			array(
				'label' => esc_html__( 'Settings', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Icon Shape
		$this->add_control(
			'icon_shape',
			array(
				'label'   => esc_html__( 'Icon Shape', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'circle',
				'options' => array(
					'circle'  => esc_html__( 'Circle', 'themeflex' ),
					'square'  => esc_html__( 'Square', 'themeflex' ),
					'rounded' => esc_html__( 'Rounded', 'themeflex' ),
				),
			)
		);

		// Layout
		$this->add_control(
			'layout',
			array(
				'label'   => esc_html__( 'Layout', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'horizontal',
				'options' => array(
					'horizontal' => esc_html__( 'Horizontal', 'themeflex' ),
					'vertical'   => esc_html__( 'Vertical', 'themeflex' ),
				),
			)
		);

		// Hover Animation
		$this->add_control(
			'hover_animation',
			array(
				'label'   => esc_html__( 'Hover Animation', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'scale',
				'options' => array(
					'none'        => esc_html__( 'None', 'themeflex' ),
					'bounce'      => esc_html__( 'Bounce', 'themeflex' ),
					'scale'       => esc_html__( 'Scale', 'themeflex' ),
					'color-change' => esc_html__( 'Color Change', 'themeflex' ),
				),
			)
		);

		// Open in new tab
		$this->add_control(
			'open_in_new_tab',
			array(
				'label'        => esc_html__( 'Open in New Tab', 'themeflex' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'themeflex' ),
				'label_off'    => esc_html__( 'No', 'themeflex' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->end_controls_section();

		// Style Section - Icons
		$this->start_controls_section(
			'icons_style_section',
			array(
				'label' => esc_html__( 'Icons', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'icon_size',
			array(
				'label'   => esc_html__( 'Icon Size (px)', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 20,
				),
				'range'   => array(
					'px' => array(
						'min' => 10,
						'max' => 100,
					),
				),
			)
		);

		$this->add_control(
			'container_size',
			array(
				'label'   => esc_html__( 'Container Size (px)', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 50,
				),
				'range'   => array(
					'px' => array(
						'min' => 20,
						'max' => 150,
					),
				),
			)
		);

		$this->add_control(
			'icon_color',
			array(
				'label'     => esc_html__( 'Icon Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FFFFFF',
				'selectors' => array(
					'{{WRAPPER}} .social-icon' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'background_color',
			array(
				'label'     => esc_html__( 'Background Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#0066cc',
				'selectors' => array(
					'{{WRAPPER}} .social-icon' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'hover_color',
			array(
				'label'     => esc_html__( 'Hover Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#004da3',
				'selectors' => array(
					'{{WRAPPER}} .social-icon:hover' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Spacing
		$this->start_controls_section(
			'spacing_style_section',
			array(
				'label' => esc_html__( 'Spacing', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'icon_spacing',
			array(
				'label'   => esc_html__( 'Space Between Icons', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'default' => array(
					'size' => 10,
				),
				'range'   => array(
					'px' => array(
						'min' => 0,
						'max' => 50,
					),
				),
			)
		);

		$this->end_controls_section();

		// Style Section - Border
		$this->start_controls_section(
			'border_style_section',
			array(
				'label' => esc_html__( 'Border', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'icon_border',
				'label'    => esc_html__( 'Border', 'themeflex' ),
				'selector' => '{{WRAPPER}} .social-icon',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Get brand color for platform
	 *
	 * @param string $platform Platform name.
	 * @return string Hex color.
	 */
	private function get_brand_color( $platform ) {
		$colors = array(
			'facebook'  => '#1877f2',
			'twitter'   => '#000000',
			'instagram' => '#e1306c',
			'linkedin'  => '#0a66c2',
			'youtube'   => '#ff0000',
			'tiktok'    => '#010101',
			'github'    => '#24292e',
			'dribbble'  => '#ea4c89',
			'behance'   => '#1769ff',
			'pinterest' => '#e60023',
			'whatsapp'  => '#25d366',
			'telegram'  => '#2aabee',
			'email'     => '#64748b',
		);
		return isset( $colors[ $platform ] ) ? $colors[ $platform ] : '#475569';
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['social_links'] ) ) {
			echo '<p>' . esc_html__( 'Please add social links.', 'themeflex' ) . '</p>';
			return;
		}

		$icon_shape      = isset( $settings['icon_shape'] ) ? $settings['icon_shape'] : 'circle';
		$layout          = isset( $settings['layout'] ) ? $settings['layout'] : 'horizontal';
		$hover_animation = isset( $settings['hover_animation'] ) ? $settings['hover_animation'] : 'scale';
		$open_in_new_tab = isset( $settings['open_in_new_tab'] ) ? $settings['open_in_new_tab'] : 'yes';
		$icon_size       = isset( $settings['icon_size']['size'] ) ? absint( $settings['icon_size']['size'] ) : 20;
		$container_size  = isset( $settings['container_size']['size'] ) ? absint( $settings['container_size']['size'] ) : 50;
		$icon_spacing    = isset( $settings['icon_spacing']['size'] ) ? absint( $settings['icon_spacing']['size'] ) : 10;
		$icon_color      = isset( $settings['icon_color'] ) ? $settings['icon_color'] : '#ffffff';
		$bg_color        = isset( $settings['background_color'] ) ? $settings['background_color'] : '';
		$uid             = 'sfsi-' . $this->get_id();

		// Border radius per shape
		$border_radius = 'circle' === $icon_shape ? '50%' : ( 'rounded' === $icon_shape ? '8px' : '0' );

		// Flex direction per layout
		$flex_dir = 'vertical' === $layout ? 'column' : 'row';

		$wrapper_style = 'display:flex;flex-direction:' . $flex_dir . ';flex-wrap:wrap;gap:' . $icon_spacing . 'px;align-items:center;';
		?>
		<div class="sf-social-icons sf-social-layout-<?php echo esc_attr( $layout ); ?>" id="<?php echo esc_attr( $uid ); ?>" style="<?php echo esc_attr( $wrapper_style ); ?>">
			<?php foreach ( $settings['social_links'] as $link ) :
				$platform = isset( $link['platform'] ) ? $link['platform'] : 'facebook';
				$url      = isset( $link['url']['url'] ) ? $link['url']['url'] : '';

				if ( empty( $url ) ) continue;

				$icon_name   = $this->get_icon_class( $platform );
				$brand_color = $this->get_brand_color( $platform );
				$item_bg     = $bg_color ?: $brand_color;
				$target      = 'yes' === $open_in_new_tab ? ' target="_blank" rel="noopener noreferrer"' : '';
				$label       = $this->get_platform_options()[ $platform ] ?? ucfirst( $platform );

				$item_style = 'display:inline-flex;align-items:center;justify-content:center;'
				            . 'width:' . $container_size . 'px;height:' . $container_size . 'px;'
				            . 'border-radius:' . $border_radius . ';'
				            . 'background:' . esc_attr( $item_bg ) . ';'
				            . 'color:' . esc_attr( $icon_color ) . ';'
				            . 'font-size:' . $icon_size . 'px;'
				            . 'text-decoration:none;'
				            . 'transition:transform .2s ease,filter .2s ease,box-shadow .2s ease;'
				            . 'flex-shrink:0;';
				?>
				<a href="<?php echo esc_url( $url ); ?>"
				   class="social-icon sf-si-<?php echo esc_attr( $platform ); ?>"
				   style="<?php echo esc_attr( $item_style ); ?>"
				   title="<?php echo esc_attr( $label ); ?>"
				   aria-label="<?php echo esc_attr( $label ); ?>"<?php echo $target; ?>
				   <?php if ( 'scale' === $hover_animation ) : ?>
				   onmouseover="this.style.transform='scale(1.12)';this.style.boxShadow='0 4px 16px rgba(0,0,0,.2)'"
				   onmouseout="this.style.transform='scale(1)';this.style.boxShadow='none'"
				   <?php elseif ( 'bounce' === $hover_animation ) : ?>
				   onmouseover="this.style.transform='translateY(-4px)'"
				   onmouseout="this.style.transform='translateY(0)'"
				   <?php elseif ( 'color-change' === $hover_animation ) : ?>
				   onmouseover="this.style.filter='brightness(1.2)'"
				   onmouseout="this.style.filter='brightness(1)'"
				   <?php endif; ?>>
					<i class="<?php echo esc_attr( $icon_name ); ?>" aria-hidden="true"></i>
				</a>
			<?php endforeach; ?>
		</div>
		<?php
	}
}
