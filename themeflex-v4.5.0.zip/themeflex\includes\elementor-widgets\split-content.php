<?php
/**
 * Split Content Widget — 50/50 layout mit Image + Content nebeneinander.
 * @package ThemeFlex
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Split_Content_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'sf_split_content'; }
    public function get_title() { return esc_html__('Split Content','themeflex'); }
    public function get_icon()  { return 'eicon-columns'; }
    public function get_categories() { return ['themeflex']; }
    public function get_keywords()   { return ['split','two column','image text','about','feature']; }

    protected function register_controls() {
        $this->start_controls_section('s_content',['label'=>'Content']);
        $this->add_control('tag',['label'=>'Tag','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'About Us']);
        $this->add_control('title',['label'=>'Title','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>'We build websites that actually convert']);
        $this->add_control('description',['label'=>'Description','type'=>\Elementor\Controls_Manager::WYSIWYG,'default'=>'<p>Our team combines design excellence with conversion-focused strategy. Every pixel serves a purpose — from the first impression to the final click.</p>']);
        $this->add_control('image',['label'=>'Image','type'=>\Elementor\Controls_Manager::MEDIA,'default'=>['url'=>\Elementor\Utils::get_placeholder_image_src()]]);
        $this->add_control('image_position',['label'=>'Image Position','type'=>\Elementor\Controls_Manager::CHOOSE,'options'=>['left'=>['title'=>'Left','icon'=>'eicon-arrow-left'],'right'=>['title'=>'Right','icon'=>'eicon-arrow-right']],'default'=>'right']);
        $this->add_control('cta_text',['label'=>'CTA Text','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Learn More']);
        $this->add_control('cta_url',['label'=>'CTA URL','type'=>\Elementor\Controls_Manager::URL]);
        $this->add_control('cta_style',['label'=>'CTA Style','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['primary'=>'Primary Button','ghost'=>'Ghost Button','link'=>'Text Link'],'default'=>'primary']);
        $this->end_controls_section();

        $this->start_controls_section('s_features',['label'=>'Feature List (optional)']);
        $rep = new \Elementor\Repeater();
        $rep->add_control('feat',['label'=>'Feature','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Feature item']);
        $rep->add_control('feat_icon',['label'=>'Icon','type'=>\Elementor\Controls_Manager::ICONS]);
        $this->add_control('features',['type'=>\Elementor\Controls_Manager::REPEATER,'fields'=>$rep->get_controls(),'default'=>[
            ['feat'=>'100% custom design tailored to your brand'],
            ['feat'=>'Mobile-first, lightning-fast performance'],
            ['feat'=>'SEO-optimized from day one'],
        ],'title_field'=>'{{{ feat }}}']);
        $this->end_controls_section();

        $this->start_controls_section('s_style',['label'=>'Style','tab'=>\Elementor\Controls_Manager::TAB_STYLE]);
        $this->add_control('bg',['label'=>'Background','type'=>\Elementor\Controls_Manager::COLOR,'selectors'=>['{{WRAPPER}} .sf-split-wrap'=>'background:{{VALUE}};']]);
        $this->add_responsive_control('gap',['label'=>'Column Gap','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['px'=>['min'=>0,'max'=>120]],'default'=>['size'=>64],'selectors'=>['{{WRAPPER}} .sf-split-inner'=>'gap:{{SIZE}}px;']]);
        $this->add_control('image_radius',['label'=>'Image Border Radius','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['px'=>['min'=>0,'max'=>48]],'default'=>['size'=>16],'selectors'=>['{{WRAPPER}} .sf-split-img img'=>'border-radius:{{SIZE}}px;']]);
        $this->end_controls_section();
    }

    protected function render() {
        $s   = $this->get_settings_for_display();
        $rev = 'left' === ($s['image_position'] ?? 'right') ? 'flex-direction:row;' : 'flex-direction:row-reverse;';
        $cta_url = !empty($s['cta_url']['url']) ? esc_url($s['cta_url']['url']) : '#';
        $cta_ext = !empty($s['cta_url']['is_external']) ? 'target="_blank" rel="noopener noreferrer"' : '';
        $cta_styles = [
            'primary'=>'display:inline-flex;align-items:center;gap:8px;padding:13px 28px;border-radius:10px;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#ED4C1C));color:#fff;font-weight:700;font-size:15px;text-decoration:none;',
            'ghost'  =>'display:inline-flex;align-items:center;gap:8px;padding:11px 26px;border-radius:10px;border:2px solid var(--sf-color-primary,#FF5E2E);color:var(--sf-color-primary,#FF5E2E);font-weight:700;font-size:15px;text-decoration:none;',
            'link'   =>'display:inline-flex;align-items:center;gap:6px;color:var(--sf-color-primary,#FF5E2E);font-weight:700;font-size:15px;text-decoration:none;',
        ];
        $cta_style = $cta_styles[$s['cta_style'] ?? 'primary'];
        ?>
        <div class="sf-split-wrap" style="padding:80px 0;">
            <div class="sf-split-inner" style="display:flex;<?php echo $rev; ?>align-items:center;gap:64px;flex-wrap:wrap;">
                <!-- Image -->
                <div class="sf-split-img" style="flex:1;min-width:280px;">
                    <?php if(!empty($s['image']['url'])): ?>
                    <img src="<?php echo esc_url($s['image']['url']); ?>" alt="<?php echo esc_attr($s['title']); ?>"
                         style="width:100%;height:auto;display:block;border-radius:16px;box-shadow:0 24px 80px rgba(0,0,0,.12);" loading="lazy" />
                    <?php endif; ?>
                </div>
                <!-- Content -->
                <div class="sf-split-content" style="flex:1;min-width:280px;">
                    <?php if($s['tag']): ?>
                    <div style="display:inline-flex;align-items:center;gap:8px;background:rgba(255,94,46,.08);border:1px solid rgba(255,94,46,.2);padding:4px 14px;border-radius:20px;margin-bottom:20px;">
                        <div style="width:6px;height:6px;border-radius:50%;background:var(--sf-color-primary,#FF5E2E);"></div>
                        <span style="font-size:12px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--sf-color-primary,#FF5E2E);"><?php echo esc_html($s['tag']); ?></span>
                    </div>
                    <?php endif; ?>
                    <h2 style="font-family:'Inter Tight',sans-serif;font-size:clamp(28px,3.5vw,44px);font-weight:800;color:var(--sf-title,#1e293b);line-height:1.15;letter-spacing:-.5px;margin-bottom:20px;"><?php echo esc_html($s['title']); ?></h2>
                    <div style="font-size:16px;color:var(--sf-text,#64748b);line-height:1.8;margin-bottom:28px;"><?php echo wp_kses_post($s['description']); ?></div>
                    <?php if(!empty($s['features'])): ?>
                    <ul style="list-style:none;padding:0;margin:0 0 32px;display:flex;flex-direction:column;gap:12px;">
                        <?php foreach($s['features'] as $f):
                            $icon = !empty($f['feat_icon']['value']) ? $f['feat_icon']['value'] : 'fa-solid fa-check';
                        ?>
                        <li style="display:flex;align-items:center;gap:12px;font-size:15px;color:var(--sf-title,#1e293b);font-weight:500;">
                            <span style="width:24px;height:24px;border-radius:50%;background:rgba(16,185,129,.1);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                                <i class="<?php echo esc_attr($icon); ?>" style="color:#10b981;font-size:11px;" aria-hidden="true"></i>
                            </span>
                            <?php echo esc_html($f['feat']); ?>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php endif; ?>
                    <?php if($s['cta_text']): ?>
                    <a href="<?php echo $cta_url; ?>" <?php echo $cta_ext; ?> style="<?php echo $cta_style; ?>">
                        <?php echo esc_html($s['cta_text']); ?>
                        <?php if('link' === ($s['cta_style'] ?? 'primary')): ?>→<?php endif; ?>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <style>
        @media(max-width:768px){.sf-split-inner{flex-direction:column!important}}
        [data-theme=dark] .sf-split-content h2,[data-theme=dark] .sf-split-content li{color:var(--sf-alt-title,#f1f5f9)!important}
        [data-theme=dark] .sf-split-content div{color:var(--sf-alt-text,#b8bcc4)!important}
        </style>
        <?php
    }
}
