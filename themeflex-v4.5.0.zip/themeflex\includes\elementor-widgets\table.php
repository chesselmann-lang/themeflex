<?php
/**
 * Elementor Advanced Table Widget
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Advanced Table Widget Class
 *
 * @since 1.0.0
 */
class ThemeFlex_Table_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'themeflex_table';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Advanced Table', 'themeflex' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-table';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'themeflex' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Header Row
		$this->add_control(
			'header_cells',
			array(
				'label'       => esc_html__( 'Header Cells', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Column 1 | Column 2 | Column 3', 'themeflex' ),
				'description' => esc_html__( 'Separate cells with |', 'themeflex' ),
				'default'     => 'Name | Description | Price',
			)
		);

		// Table Rows Repeater
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'row_cells',
			array(
				'label'       => esc_html__( 'Row Cells', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Cell 1 | Cell 2 | Cell 3', 'themeflex' ),
				'description' => esc_html__( 'Separate cells with |', 'themeflex' ),
			)
		);

		$this->add_control(
			'rows',
			array(
				'label'      => esc_html__( 'Rows', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::REPEATER,
				'fields'     => $repeater->get_controls(),
				'title_field' => esc_html__( 'Row', 'themeflex' ),
				'default'    => array(
					array(
						'row_cells' => 'Item 1 | Description | $19.99',
					),
					array(
						'row_cells' => 'Item 2 | Description | $29.99',
					),
				),
			)
		);

		$this->end_controls_section();

		// Features Section
		$this->start_controls_section(
			'features_section',
			array(
				'label' => esc_html__( 'Features', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'sortable',
			array(
				'label'        => esc_html__( 'Sortable Columns', 'themeflex' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'themeflex' ),
				'label_off'    => esc_html__( 'No', 'themeflex' ),
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'striped_rows',
			array(
				'label'        => esc_html__( 'Striped Rows', 'themeflex' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'themeflex' ),
				'label_off'    => esc_html__( 'No', 'themeflex' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'hover_highlight',
			array(
				'label'        => esc_html__( 'Hover Highlight', 'themeflex' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'themeflex' ),
				'label_off'    => esc_html__( 'No', 'themeflex' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'responsive_behavior',
			array(
				'label'   => esc_html__( 'Mobile Behavior', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'scroll',
				'options' => array(
					'scroll' => esc_html__( 'Horizontal Scroll', 'themeflex' ),
					'stack'  => esc_html__( 'Stack Rows', 'themeflex' ),
				),
			)
		);

		$this->end_controls_section();

		// Style Section
		$this->start_controls_section(
			'style_section',
			array(
				'label' => esc_html__( 'Style', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'header_bg_color',
			array(
				'label'     => esc_html__( 'Header Background', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#0066cc',
				'selectors' => array(
					'{{WRAPPER}} .advanced-table thead' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'header_text_color',
			array(
				'label'     => esc_html__( 'Header Text Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .advanced-table thead' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#dddddd',
				'selectors' => array(
					'{{WRAPPER}} .advanced-table' => 'border-color: {{VALUE}}; --table-border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'striped_color',
			array(
				'label'     => esc_html__( 'Striped Row Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#f9f9f9',
				'selectors' => array(
					'{{WRAPPER}} .advanced-table tbody tr:nth-child(even)' => 'background-color: {{VALUE}};',
				),
				'condition' => array(
					'striped_rows' => 'yes',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$header_cells_str = isset( $settings['header_cells'] ) ? $settings['header_cells'] : '';
		$rows = isset( $settings['rows'] ) ? $settings['rows'] : array();
		$sortable = isset( $settings['sortable'] ) && 'yes' === $settings['sortable'];
		$striped = isset( $settings['striped_rows'] ) && 'yes' === $settings['striped_rows'];
		$hover = isset( $settings['hover_highlight'] ) && 'yes' === $settings['hover_highlight'];
		$responsive = isset( $settings['responsive_behavior'] ) ? $settings['responsive_behavior'] : 'scroll';

		$header_cells = array_map( 'trim', explode( '|', $header_cells_str ) );

		if ( empty( $rows ) ) {
			echo '<p>' . esc_html__( 'Please add table rows', 'themeflex' ) . '</p>';
			return;
		}

		$classes = 'advanced-table';
		if ( $striped ) {
			$classes .= ' striped';
		}
		if ( $hover ) {
			$classes .= ' hover-highlight';
		}
		if ( $sortable ) {
			$classes .= ' sortable';
		}
		$classes .= ' responsive-' . esc_attr( $responsive );

		$uid = 'sftbl-' . $this->get_id();
		?>
		<div class="table-wrapper sf-table-wrapper" id="<?php echo esc_attr( $uid ); ?>" style="overflow-x:auto;border-radius:var(--sf-radius,8px);border:1px solid var(--sf-border,#e5e7eb);">
			<table class="<?php echo esc_attr( $classes ); ?>" role="table"
			       style="width:100%;border-collapse:collapse;min-width:320px;">
				<thead role="rowgroup">
					<tr role="row">
						<?php foreach ( $header_cells as $index => $cell ) : ?>
							<th role="columnheader"
							    scope="col"
							    <?php echo $sortable ? 'data-col="' . absint( $index ) . '" tabindex="0"' : ''; ?>
							    style="padding:14px 18px;font-weight:700;font-size:.875rem;text-align:left;white-space:nowrap;<?php echo $sortable ? 'cursor:pointer;user-select:none;' : ''; ?>">
								<?php echo esc_html( trim( $cell ) ); ?>
								<?php if ( $sortable ) : ?>
									<span class="sort-icon" aria-hidden="true" style="display:inline-block;margin-left:4px;opacity:.5;font-size:.7em;">&#9650;&#9660;</span>
								<?php endif; ?>
							</th>
						<?php endforeach; ?>
					</tr>
				</thead>
				<tbody role="rowgroup">
					<?php foreach ( $rows as $row_index => $row ) : ?>
						<?php
						$row_cells_str = isset( $row['row_cells'] ) ? $row['row_cells'] : '';
						$cells         = array_map( 'trim', explode( '|', $row_cells_str ) );
						?>
						<tr role="row"
						    <?php if ( $hover ) : ?>
						    onmouseover="this.style.background='var(--sf-alt-bg,#f8fafc)'"
						    onmouseout="this.style.background=''"
						    <?php endif; ?>>
							<?php foreach ( $cells as $cell_index => $cell ) : ?>
								<td role="cell"
								    data-column="<?php echo esc_attr( isset( $header_cells[ $cell_index ] ) ? trim( $header_cells[ $cell_index ] ) : '' ); ?>"
								    style="padding:12px 18px;border-top:1px solid var(--sf-border,#e5e7eb);font-size:.9rem;vertical-align:middle;">
									<?php echo wp_kses_post( $cell ); ?>
								</td>
							<?php endforeach; ?>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

		<?php if ( 'stack' === $responsive ) : ?>
		<style>
		@media(max-width:640px){
			#<?php echo esc_attr( $uid ); ?> .advanced-table thead{display:none;}
			#<?php echo esc_attr( $uid ); ?> .advanced-table tr{display:block;border-bottom:2px solid var(--sf-border,#e5e7eb);margin-bottom:8px;}
			#<?php echo esc_attr( $uid ); ?> .advanced-table td{display:flex;justify-content:space-between;gap:12px;border-top:1px solid var(--sf-border,#e5e7eb);padding:8px 12px;}
			#<?php echo esc_attr( $uid ); ?> .advanced-table td::before{content:attr(data-column);font-weight:700;font-size:.8rem;color:var(--sf-muted,#94a3b8);flex-shrink:0;}
		}
		</style>
		<?php endif; ?>

		<?php if ( $sortable ) : ?>
		<script>
		(function() {
			var tbl = document.querySelector('#<?php echo esc_js( $uid ); ?> .advanced-table');
			if (!tbl) return;
			var ths = tbl.querySelectorAll('thead th[data-col]');
			ths.forEach(function(th) {
				th.addEventListener('click', sortByCol);
				th.addEventListener('keydown', function(e){ if (e.key==='Enter'||e.key===' ') sortByCol.call(th, e); });
			});
			var sortDir = {};
			function sortByCol() {
				var col = parseInt(this.getAttribute('data-col'));
				var asc = sortDir[col] !== true;
				sortDir[col] = asc;
				var tbody = tbl.querySelector('tbody');
				var rows = Array.from(tbody.querySelectorAll('tr'));
				rows.sort(function(a, b) {
					var aText = (a.cells[col] ? a.cells[col].textContent : '').trim();
					var bText = (b.cells[col] ? b.cells[col].textContent : '').trim();
					var aNum = parseFloat(aText.replace(/[^0-9.\-]/g, ''));
					var bNum = parseFloat(bText.replace(/[^0-9.\-]/g, ''));
					var cmp = (!isNaN(aNum) && !isNaN(bNum)) ? aNum - bNum : aText.localeCompare(bText);
					return asc ? cmp : -cmp;
				});
				rows.forEach(function(r){ tbody.appendChild(r); });
				// Update sort indicators
				ths.forEach(function(t){ var ic = t.querySelector('.sort-icon'); if(ic){ ic.style.opacity='.3'; } });
				var myIcon = this.querySelector('.sort-icon');
				if (myIcon) { myIcon.style.opacity='1'; myIcon.textContent = asc ? '\u25b2' : '\u25bc'; }
			}
		})();
		</script>
		<?php endif; ?>
		<?php
	}
}
