<?php
/**
 * Advanced Tabs Widget
 * Horizontal/Vertical, Icon-Support, animierte Indicator-Linie.
 *
 * @package ThemeFlex
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class ThemeFlex_Tabs_Advanced_Widget extends \Elementor\Widget_Base {

	public function get_name()  { return 'sf_tabs_advanced'; }
	public function get_title() { return esc_html__( 'Advanced Tabs', 'themeflex' ); }
	public function get_icon()  { return 'eicon-tabs'; }
	public function get_categories() { return [ 'themeflex' ]; }
	public function get_keywords()   { return [ 'tabs', 'accordion', 'toggle', 'content' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'section_tabs', [ 'label' => esc_html__( 'Tabs', 'themeflex' ) ] );

		$repeater = new \Elementor\Repeater();
		$repeater->add_control( 'tab_title', [
			'label'   => esc_html__( 'Title', 'themeflex' ),
			'type'    => \Elementor\Controls_Manager::TEXT,
			'default' => 'Tab Title',
		] );
		$repeater->add_control( 'tab_icon', [
			'label' => esc_html__( 'Icon', 'themeflex' ),
			'type'  => \Elementor\Controls_Manager::ICONS,
		] );
		$repeater->add_control( 'tab_content', [
			'label'      => esc_html__( 'Content', 'themeflex' ),
			'type'       => \Elementor\Controls_Manager::WYSIWYG,
			'default'    => 'Tab content goes here.',
			'show_label' => false,
		] );

		$this->add_control( 'tabs', [
			'type'        => \Elementor\Controls_Manager::REPEATER,
			'fields'      => $repeater->get_controls(),
			'default'     => [
				[ 'tab_title' => 'Features',    'tab_content' => 'Describe your key features here.' ],
				[ 'tab_title' => 'Benefits',    'tab_content' => 'Explain the main benefits here.' ],
				[ 'tab_title' => 'How It Works','tab_content' => 'Step-by-step explanation.' ],
			],
			'title_field' => '{{{ tab_title }}}',
		] );

		$this->add_control( 'layout', [
			'label'   => esc_html__( 'Layout', 'themeflex' ),
			'type'    => \Elementor\Controls_Manager::SELECT,
			'options' => [
				'horizontal' => 'Horizontal',
				'vertical'   => 'Vertical',
			],
			'default' => 'horizontal',
		] );

		$this->end_controls_section();

		/* ── Style ── */
		$this->start_controls_section( 'section_style', [
			'label' => esc_html__( 'Style', 'themeflex' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		] );
		$this->add_control( 'active_color', [
			'label'     => esc_html__( 'Active Tab Color', 'themeflex' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .sf-tab-btn.active' => 'color: {{VALUE}};', '{{WRAPPER}} .sf-tab-indicator' => 'background: {{VALUE}};' ],
		] );
		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
			'name'     => 'tab_typography',
			'selector' => '{{WRAPPER}} .sf-tab-btn',
		] );
		$this->end_controls_section();
	}

	protected function render() {
		$s      = $this->get_settings_for_display();
		$tabs   = $s['tabs'];
		$layout = $s['layout'];
		$uid    = 'sf-tabs-' . $this->get_id();
		if ( empty( $tabs ) ) return;
		?>
		<div class="sf-tabs-advanced sf-tabs--<?php echo esc_attr( $layout ); ?>" id="<?php echo esc_attr( $uid ); ?>">
			<div class="sf-tabs-nav" role="tablist">
				<?php foreach ( $tabs as $i => $tab ) :
					$active = ( 0 === $i ) ? ' active' : '';
					$tid    = $uid . '-tab-' . $i;
					$pid    = $uid . '-panel-' . $i;
				?>
				<button class="sf-tab-btn<?php echo $active; ?>" role="tab"
					id="<?php echo esc_attr( $tid ); ?>"
					aria-controls="<?php echo esc_attr( $pid ); ?>"
					aria-selected="<?php echo $active ? 'true' : 'false'; ?>"
					onclick="sfTabSwitch(this)"
					tabindex="<?php echo $active ? '0' : '-1'; ?>">
					<?php if ( ! empty( $tab['tab_icon']['value'] ) ) : ?>
						<span class="sf-tab-icon"><i class="<?php echo esc_attr( $tab['tab_icon']['value'] ); ?>" aria-hidden="true"></i></span>
					<?php endif; ?>
					<?php echo esc_html( $tab['tab_title'] ); ?>
				</button>
				<?php endforeach; ?>
				<span class="sf-tab-indicator" aria-hidden="true"></span>
			</div>
			<div class="sf-tabs-content">
				<?php foreach ( $tabs as $i => $tab ) :
					$active = ( 0 === $i ) ? ' active' : '';
					$tid    = $uid . '-tab-' . $i;
					$pid    = $uid . '-panel-' . $i;
				?>
				<div class="sf-tab-panel<?php echo $active; ?>"
					id="<?php echo esc_attr( $pid ); ?>"
					role="tabpanel"
					aria-labelledby="<?php echo esc_attr( $tid ); ?>"
					<?php echo $active ? '' : 'hidden'; ?>>
					<?php echo wp_kses_post( $tab['tab_content'] ); ?>
				</div>
				<?php endforeach; ?>
			</div>
		</div>
		<style>
		.sf-tabs-advanced{--sf-tab-primary:var(--sf-color-primary,#FF5E2E);}
		.sf-tabs-nav{display:flex;position:relative;border-bottom:2px solid #e5e7eb;}
		.sf-tabs--vertical{display:flex;gap:0;}
		.sf-tabs--vertical .sf-tabs-nav{flex-direction:column;border-bottom:none;border-right:2px solid #e5e7eb;min-width:180px;}
		.sf-tabs--vertical .sf-tabs-content{flex:1;padding-left:24px;}
		.sf-tab-btn{padding:12px 20px;background:none;border:none;font-weight:600;color:#64748b;cursor:pointer;display:flex;align-items:center;gap:8px;white-space:nowrap;transition:color .2s;position:relative;}
		.sf-tab-btn:hover,.sf-tab-btn.active{color:var(--sf-tab-primary);}
		.sf-tab-indicator{position:absolute;bottom:-2px;left:0;height:2px;background:var(--sf-tab-primary);transition:left .25s ease,width .25s ease;}
		.sf-tabs--vertical .sf-tab-indicator{bottom:auto;right:-2px;left:auto;top:0;width:2px;height:0;transition:top .25s ease,height .25s ease;}
		.sf-tab-panel{animation:sfFadeIn .2s ease;line-height:1.7;}
		.sf-tab-icon{font-size:.9em;}
		@keyframes sfFadeIn{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}
		</style>
		<script>
		(function(){
			function sfUpdateIndicator(nav){
				var active=nav.querySelector('.sf-tab-btn.active');
				var ind=nav.querySelector('.sf-tab-indicator');
				if(!active||!ind)return;
				var isVert=nav.closest('.sf-tabs--vertical');
				if(isVert){
					ind.style.top=active.offsetTop+'px';
					ind.style.height=active.offsetHeight+'px';
				}else{
					ind.style.left=active.offsetLeft+'px';
					ind.style.width=active.offsetWidth+'px';
				}
			}
			window.sfTabSwitch=function(btn){
				var nav=btn.closest('.sf-tabs-nav');
				var wrap=btn.closest('.sf-tabs-advanced');
				if(!nav||!wrap)return;
				nav.querySelectorAll('.sf-tab-btn').forEach(function(b){
					b.classList.remove('active');
					b.setAttribute('aria-selected','false');
					b.setAttribute('tabindex','-1');
				});
				btn.classList.add('active');
				btn.setAttribute('aria-selected','true');
				btn.setAttribute('tabindex','0');
				var panelId=btn.getAttribute('aria-controls');
				wrap.querySelectorAll('.sf-tab-panel').forEach(function(p){
					if(p.id===panelId){p.classList.add('active');p.removeAttribute('hidden');}
					else{p.classList.remove('active');p.setAttribute('hidden','');}
				});
				sfUpdateIndicator(nav);
			};
			document.querySelectorAll('.sf-tabs-advanced').forEach(function(wrap){
				var nav=wrap.querySelector('.sf-tabs-nav');
				if(nav) sfUpdateIndicator(nav);
			});
			// Keyboard nav
			document.addEventListener('keydown',function(e){
				if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key))return;
				var btn=e.target;if(!btn.classList.contains('sf-tab-btn'))return;
				var btns=Array.from(btn.closest('.sf-tabs-nav').querySelectorAll('.sf-tab-btn'));
				var idx=btns.indexOf(btn);
				var next=(e.key==='ArrowRight'||e.key==='ArrowDown')?(idx+1)%btns.length:(idx-1+btns.length)%btns.length;
				btns[next].focus();sfTabSwitch(btns[next]);
				e.preventDefault();
			});
		})();
		</script>
		<?php
	}
}
