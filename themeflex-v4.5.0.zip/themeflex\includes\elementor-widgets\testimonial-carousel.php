<?php
/**
 * Testimonial Carousel Widget
 * Multi-Card Auto-Slide mit Paginierung und Sternbewertung.
 *
 * @package ThemeFlex
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class ThemeFlex_Testimonial_Carousel_Widget extends \Elementor\Widget_Base {

	public function get_name()  { return 'sf_testimonial_carousel'; }
	public function get_title() { return esc_html__( 'Testimonial Carousel', 'themeflex' ); }
	public function get_icon()  { return 'eicon-testimonial-carousel'; }
	public function get_categories() { return [ 'themeflex' ]; }
	public function get_keywords()   { return [ 'testimonial', 'review', 'carousel', 'slider', 'quote' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'section_items', [ 'label' => esc_html__( 'Reviews', 'themeflex' ) ] );

		$repeater = new \Elementor\Repeater();
		$repeater->add_control( 'author_name',   [ 'label' => 'Name',    'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Jane Doe' ] );
		$repeater->add_control( 'author_role',   [ 'label' => 'Role',    'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'CEO, Acme Corp' ] );
		$repeater->add_control( 'author_image',  [ 'label' => 'Photo',   'type' => \Elementor\Controls_Manager::MEDIA ] );
		$repeater->add_control( 'rating',        [ 'label' => 'Stars',   'type' => \Elementor\Controls_Manager::SELECT, 'options' => [ '5'=>'★★★★★','4'=>'★★★★','3'=>'★★★','2'=>'★★','1'=>'★' ], 'default' => '5' ] );
		$repeater->add_control( 'quote',         [ 'label' => 'Quote',   'type' => \Elementor\Controls_Manager::TEXTAREA, 'default' => 'This product changed my life. Highly recommended!' ] );

		$this->add_control( 'items', [
			'type'        => \Elementor\Controls_Manager::REPEATER,
			'fields'      => $repeater->get_controls(),
			'default'     => [
				[ 'author_name' => 'Sarah Miller',  'author_role' => 'Marketing Director', 'rating' => '5', 'quote' => 'Absolutely incredible results. Our conversion rate doubled within weeks.' ],
				[ 'author_name' => 'James Chen',    'author_role' => 'Startup Founder',    'rating' => '5', 'quote' => 'The best investment we made this year. The team is responsive and professional.' ],
				[ 'author_name' => 'Anna Schmidt',  'author_role' => 'E-Commerce Manager', 'rating' => '5', 'quote' => 'Seamless onboarding, beautiful design, and excellent support. 10/10.' ],
			],
			'title_field' => '{{{ author_name }}}',
		] );

		$this->add_control( 'columns', [
			'label'   => esc_html__( 'Cards per Row', 'themeflex' ),
			'type'    => \Elementor\Controls_Manager::SELECT,
			'options' => [ '1' => '1', '2' => '2', '3' => '3' ],
			'default' => '2',
		] );
		$this->add_control( 'autoplay', [ 'label' => 'Autoplay', 'type' => \Elementor\Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'autoplay_speed', [ 'label' => 'Speed (ms)', 'type' => \Elementor\Controls_Manager::SLIDER, 'range' => [ 'ms' => [ 'min' => 1000, 'max' => 8000 ] ], 'default' => [ 'size' => 4000 ], 'condition' => [ 'autoplay' => 'yes' ] ] );

		$this->end_controls_section();

		$this->start_controls_section( 'section_style', [ 'label' => 'Style', 'tab' => \Elementor\Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'card_bg', [ 'label' => 'Card Background', 'type' => \Elementor\Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .sf-tc-card' => 'background: {{VALUE}};' ] ] );
		$this->add_control( 'star_color', [ 'label' => 'Star Color', 'type' => \Elementor\Controls_Manager::COLOR, 'default' => '#f59e0b', 'selectors' => [ '{{WRAPPER}} .sf-tc-stars' => 'color: {{VALUE}};' ] ] );
		$this->end_controls_section();
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$uid  = 'sf-tc-' . $this->get_id();
		$cols = (int) $s['columns'];
		$auto = 'yes' === $s['autoplay'];
		$spd  = ! empty( $s['autoplay_speed']['size'] ) ? (int) $s['autoplay_speed']['size'] : 4000;
		$items = $s['items'];
		if ( empty( $items ) ) return;

		// Group items into slides of $cols
		$slides = array_chunk( $items, $cols );
		?>
		<div class="sf-tc-wrap" id="<?php echo esc_attr($uid); ?>" style="--sf-tc-cols:<?php echo $cols; ?>;" data-autoplay="<?php echo $auto ? 'true' : 'false'; ?>" data-speed="<?php echo $spd; ?>">
			<div class="sf-tc-track" style="display:flex;transition:transform .5s ease;will-change:transform;">
				<?php foreach ( $slides as $slide ) : ?>
				<div class="sf-tc-slide" style="min-width:100%;display:grid;grid-template-columns:repeat(<?php echo $cols; ?>,1fr);gap:24px;">
					<?php foreach ( $slide as $item ) :
						$stars = str_repeat( '<i class="fa-solid fa-star" aria-hidden="true"></i>', (int) $item['rating'] );
						$img   = ! empty( $item['author_image']['url'] ) ? $item['author_image']['url'] : '';
					?>
					<div class="sf-tc-card" style="background:#f8fafc;border:1px solid #e5e7eb;border-radius:12px;padding:28px 24px;">
						<div class="sf-tc-stars" style="color:#f59e0b;font-size:14px;margin-bottom:12px;"><?php echo $stars; ?></div>
						<blockquote style="margin:0 0 20px;font-size:15px;line-height:1.7;color:#334155;font-style:italic;">&ldquo;<?php echo esc_html($item['quote']); ?>&rdquo;</blockquote>
						<div style="display:flex;align-items:center;gap:12px;">
							<?php if ( $img ) : ?>
							<img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr($item['author_name']); ?>" style="width:44px;height:44px;border-radius:50%;object-fit:cover;border:2px solid var(--sf-color-primary,#FF5E2E);" loading="lazy" />
							<?php else : ?>
							<div style="width:44px;height:44px;border-radius:50%;background:var(--sf-gradient,linear-gradient(135deg,#FF5E2E,#00D4FF));display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:16px;"><?php echo esc_html( mb_substr($item['author_name'],0,1) ); ?></div>
							<?php endif; ?>
							<div>
								<div style="font-weight:700;font-size:14px;color:#1e293b;"><?php echo esc_html($item['author_name']); ?></div>
								<div style="font-size:12px;color:#64748b;"><?php echo esc_html($item['author_role']); ?></div>
							</div>
						</div>
					</div>
					<?php endforeach; ?>
				</div>
				<?php endforeach; ?>
			</div>
			<?php if ( count($slides) > 1 ) : ?>
			<div class="sf-tc-dots" style="display:flex;justify-content:center;gap:8px;margin-top:24px;">
				<?php foreach ( $slides as $i => $_ ) : ?>
				<button class="sf-tc-dot<?php echo 0 === $i ? ' active' : ''; ?>" data-idx="<?php echo $i; ?>" aria-label="Slide <?php echo $i+1; ?>" style="width:10px;height:10px;border-radius:50%;border:none;cursor:pointer;background:<?php echo 0===$i?'var(--sf-color-primary,#FF5E2E)':'#cbd5e1'; ?>;transition:background .3s;"></button>
				<?php endforeach; ?>
			</div>
			<button class="sf-tc-prev" aria-label="Previous" style="position:absolute;left:-20px;top:50%;transform:translateY(-50%);width:40px;height:40px;border-radius:50%;border:1px solid #e5e7eb;background:#fff;cursor:pointer;font-size:16px;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,.1);">&#8592;</button>
			<button class="sf-tc-next" aria-label="Next"     style="position:absolute;right:-20px;top:50%;transform:translateY(-50%);width:40px;height:40px;border-radius:50%;border:1px solid #e5e7eb;background:#fff;cursor:pointer;font-size:16px;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,.1);">&#8594;</button>
			<?php endif; ?>
		</div>
		<style>
		#<?php echo esc_attr($uid); ?>{position:relative;overflow:hidden;}
		[data-theme="dark"] .sf-tc-card{background:#1e293b!important;border-color:rgba(255,255,255,.08)!important;}
		[data-theme="dark"] .sf-tc-card blockquote{color:#94a3b8!important;}
		[data-theme="dark"] .sf-tc-card div{color:#e2e8f0!important;}
		</style>
		<script>
		(function(){
			var wrap=document.getElementById('<?php echo esc_js($uid); ?>');
			if(!wrap)return;
			var track=wrap.querySelector('.sf-tc-track');
			var dots=wrap.querySelectorAll('.sf-tc-dot');
			var total=<?php echo count($slides); ?>;
			var cur=0;var timer=null;
			function go(n){
				cur=(n+total)%total;
				track.style.transform='translateX(-'+cur*100+'%)';
				dots.forEach(function(d,i){
					d.style.background=i===cur?'var(--sf-color-primary,#FF5E2E)':'#cbd5e1';
					d.classList.toggle('active',i===cur);
				});
			}
			dots.forEach(function(d){d.addEventListener('click',function(){go(parseInt(d.dataset.idx));});});
			var prev=wrap.querySelector('.sf-tc-prev');
			var next=wrap.querySelector('.sf-tc-next');
			if(prev)prev.addEventListener('click',function(){go(cur-1);});
			if(next)next.addEventListener('click',function(){go(cur+1);});
			if('<?php echo $auto ? 'true' : 'false'; ?>'==='true'){
				timer=setInterval(function(){go(cur+1);},<?php echo $spd; ?>);
				wrap.addEventListener('mouseenter',function(){clearInterval(timer);});
				wrap.addEventListener('mouseleave',function(){timer=setInterval(function(){go(cur+1);},<?php echo $spd; ?>);});
			}
		})();
		</script>
		<?php
	}
}
