<?php
/**
 * Elementor Testimonial Widget
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Testimonial Widget Class
 *
 * @since 1.0.0
 */
class ThemeFlex_Testimonial_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'themeflex_testimonial';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Testimonial', 'themeflex' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-testimonial';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'themeflex' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Author Image
		$this->add_control(
			'author_image',
			array(
				'label'   => esc_html__( 'Author Image', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => array(
					'url' => '',
				),
			)
		);

		// Testimonial Text
		$this->add_control(
			'testimonial_text',
			array(
				'label'       => esc_html__( 'Testimonial', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'This is a great product! I highly recommend it.', 'themeflex' ),
				'placeholder' => esc_html__( 'Enter testimonial text', 'themeflex' ),
			)
		);

		// Author Name
		$this->add_control(
			'author_name',
			array(
				'label'       => esc_html__( 'Author Name', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'John Doe', 'themeflex' ),
				'placeholder' => esc_html__( 'Enter author name', 'themeflex' ),
			)
		);

		// Author Title/Position
		$this->add_control(
			'author_title',
			array(
				'label'       => esc_html__( 'Author Title', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Customer', 'themeflex' ),
				'placeholder' => esc_html__( 'e.g., CEO, Manager, Customer', 'themeflex' ),
			)
		);

		// Rating
		$this->add_control(
			'rating',
			array(
				'label'   => esc_html__( 'Rating', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => '5',
				'options' => array(
					'1' => esc_html__( '1 Star', 'themeflex' ),
					'2' => esc_html__( '2 Stars', 'themeflex' ),
					'3' => esc_html__( '3 Stars', 'themeflex' ),
					'4' => esc_html__( '4 Stars', 'themeflex' ),
					'5' => esc_html__( '5 Stars', 'themeflex' ),
				),
			)
		);

		$this->end_controls_section();

		// Style Section
		$this->start_controls_section(
			'style_section',
			array(
				'label' => esc_html__( 'Style', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Background Color
		$this->add_control(
			'bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FFFFFF',
				'selectors' => array(
					'{{WRAPPER}} .testimonial-box' => 'background-color: {{VALUE}}',
				),
			)
		);

		// Text Color
		$this->add_control(
			'text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#4B5563',
				'selectors' => array(
					'{{WRAPPER}} .testimonial-text' => 'color: {{VALUE}}',
				),
			)
		);

		// Border Radius
		$this->add_control(
			'border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array(
					'top'    => '8',
					'right'  => '8',
					'bottom' => '8',
					'left'   => '8',
					'unit'   => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .testimonial-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$rating = isset( $settings['rating'] ) ? intval( $settings['rating'] ) : 5;

		echo '<div class="testimonial-box">';

		// Author Image
		if ( ! empty( $settings['author_image']['url'] ) ) {
			printf(
				'<div class="testimonial-author-image"><img src="%s" alt="%s" /></div>',
				esc_url( $settings['author_image']['url'] ),
				esc_attr( $settings['author_name'] )
			);
		}

		// Stars Rating
		echo '<div class="testimonial-rating">';
		for ( $i = 0; $i < $rating; $i++ ) {
			echo '<span class="star star-filled">★</span>';
		}
		for ( $i = $rating; $i < 5; $i++ ) {
			echo '<span class="star">☆</span>';
		}
		echo '</div>';

		// Testimonial Text
		if ( ! empty( $settings['testimonial_text'] ) ) {
			printf(
				'<p class="testimonial-text">"%s"</p>',
				esc_html( $settings['testimonial_text'] )
			);
		}

		// Author Info
		echo '<div class="testimonial-author">';

		if ( ! empty( $settings['author_name'] ) ) {
			printf(
				'<h4 class="author-name">%s</h4>',
				esc_html( $settings['author_name'] )
			);
		}

		if ( ! empty( $settings['author_title'] ) ) {
			printf(
				'<p class="author-title">%s</p>',
				esc_html( $settings['author_title'] )
			);
		}

		echo '</div>';

		echo '</div>';
	}
}
