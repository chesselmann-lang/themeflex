<?php
/**
 * Text Reveal Widget — Scroll-triggered Wort-für-Wort Highlight-Animation.
 * @package ThemeFlex
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Text_Reveal_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'sf_text_reveal'; }
    public function get_title() { return esc_html__('Text Reveal Animation','themeflex'); }
    public function get_icon()  { return 'eicon-scroll'; }
    public function get_categories() { return ['themeflex']; }
    public function get_keywords()   { return ['text','reveal','animation','scroll','highlight','kinetic']; }

    protected function register_controls() {
        $this->start_controls_section('s_content',['label'=>'Content']);
        $this->add_control('text',['label'=>'Text','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>'We create websites that inspire. We build brands that convert. We deliver results that matter.','description'=>'Each word will animate in on scroll.']);
        $this->add_control('tag',['label'=>'HTML Tag','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['h1'=>'H1','h2'=>'H2','h3'=>'H3','p'=>'P','div'=>'Div'],'default'=>'h2']);
        $this->add_control('animation',['label'=>'Animation','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['fade-up'=>'Fade Up','fade-in'=>'Fade In','scale'=>'Scale In','highlight'=>'Word Highlight'],'default'=>'fade-up']);
        $this->add_control('stagger',['label'=>'Stagger Delay (ms)','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['ms'=>['min'=>20,'max'=>200,'step'=>10]],'default'=>['size'=>60]]);
        $this->add_control('highlight_color',['label'=>'Highlight Color','type'=>\Elementor\Controls_Manager::COLOR,'default'=>'','condition'=>['animation'=>'highlight'],'selectors'=>['{{WRAPPER}} .sf-tr-word.revealed'=>'color:{{VALUE}};']]);
        $this->end_controls_section();

        $this->start_controls_section('s_style',['label'=>'Style','tab'=>\Elementor\Controls_Manager::TAB_STYLE]);
        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(),['name'=>'text_typo','selector'=>'{{WRAPPER}} .sf-text-reveal']);
        $this->add_control('text_align',['label'=>'Align','type'=>\Elementor\Controls_Manager::CHOOSE,'options'=>['left'=>['icon'=>'eicon-text-align-left','title'=>'Left'],'center'=>['icon'=>'eicon-text-align-center','title'=>'Center'],'right'=>['icon'=>'eicon-text-align-right','title'=>'Right']],'default'=>'center','selectors'=>['{{WRAPPER}} .sf-text-reveal'=>'text-align:{{VALUE}};']]);
        $this->end_controls_section();
    }

    protected function render() {
        $s   = $this->get_settings_for_display();
        $uid = 'sftr-'.$this->get_id();
        $tag = esc_attr($s['tag'] ?? 'h2');
        $anim = $s['animation'] ?? 'fade-up';
        $stagger = !empty($s['stagger']['size']) ? (int)$s['stagger']['size'] : 60;
        $words = explode(' ', $s['text'] ?? '');
        $hl_color = !empty($s['highlight_color']) ? $s['highlight_color'] : 'var(--sf-color-primary,#FF5E2E)';
        ?>
        <<?php echo $tag; ?> class="sf-text-reveal" id="<?php echo esc_attr($uid); ?>" style="line-height:1.4;font-family:'Inter Tight',sans-serif;font-size:clamp(28px,4vw,52px);font-weight:800;color:var(--sf-title,#1e293b);">
            <?php foreach($words as $i => $word): ?>
            <span class="sf-tr-word" data-idx="<?php echo $i; ?>"
                  style="display:inline-block;transition:all .5s ease;<?php
                    if('fade-up'===$anim) echo 'opacity:0;transform:translateY(20px);';
                    elseif('fade-in'===$anim) echo 'opacity:0;';
                    elseif('scale'===$anim) echo 'opacity:0;transform:scale(.8);';
                    else echo 'color:var(--sf-meta,#94a3b8);';
                  ?>margin-right:0.25em;">
                <?php echo esc_html($word); ?>
            </span>
            <?php endforeach; ?>
        </<?php echo $tag; ?>>
        <script>
        (function(){
            var wrap=document.getElementById('<?php echo esc_js($uid); ?>');
            if(!wrap||!('IntersectionObserver' in window))return;
            var words=wrap.querySelectorAll('.sf-tr-word');
            var anim='<?php echo esc_js($anim); ?>';
            var stagger=<?php echo $stagger; ?>;
            var hl='<?php echo esc_js($hl_color); ?>';
            var revealed=false;
            new IntersectionObserver(function(entries){
                if(revealed||!entries[0].isIntersecting)return;
                revealed=true;
                words.forEach(function(w,i){
                    setTimeout(function(){
                        w.classList.add('revealed');
                        if(anim==='fade-up'){w.style.opacity='1';w.style.transform='none';}
                        else if(anim==='fade-in'){w.style.opacity='1';}
                        else if(anim==='scale'){w.style.opacity='1';w.style.transform='scale(1)';}
                        else{w.style.color=hl;}
                    },i*stagger);
                });
            },{threshold:0.2}).observe(wrap);
        })();
        </script>
        <?php
    }
}
