<?php
/**
 * Elementor Timeline Widget
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Timeline Widget Class
 *
 * @since 1.0.0
 */
class ThemeFlex_Timeline_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'themeflex_timeline';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Timeline', 'themeflex' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-time-line';
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'themeflex' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Content Section
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		// Direction
		$this->add_control(
			'direction',
			array(
				'label'   => esc_html__( 'Direction', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'vertical',
				'options' => array(
					'vertical'   => esc_html__( 'Vertical', 'themeflex' ),
					'horizontal' => esc_html__( 'Horizontal', 'themeflex' ),
				),
			)
		);

		// Timeline Items Repeater
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'timeline_date',
			array(
				'label'       => esc_html__( 'Date', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'January 2024', 'themeflex' ),
			)
		);

		$repeater->add_control(
			'timeline_title',
			array(
				'label'       => esc_html__( 'Title', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Timeline Item Title', 'themeflex' ),
			)
		);

		$repeater->add_control(
			'timeline_content',
			array(
				'label'       => esc_html__( 'Content', 'themeflex' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Timeline item content text', 'themeflex' ),
			)
		);

		$repeater->add_control(
			'timeline_icon',
			array(
				'label'   => esc_html__( 'Icon', 'themeflex' ),
				'type'    => \Elementor\Controls_Manager::ICONS,
				'default' => array(
					'value'   => 'fas fa-circle',
					'library' => 'fa-solid',
				),
			)
		);

		$repeater->add_control(
			'timeline_image',
			array(
				'label' => esc_html__( 'Image', 'themeflex' ),
				'type'  => \Elementor\Controls_Manager::MEDIA,
			)
		);

		$this->add_control(
			'timeline_items',
			array(
				'label'      => esc_html__( 'Timeline Items', 'themeflex' ),
				'type'       => \Elementor\Controls_Manager::REPEATER,
				'fields'     => $repeater->get_controls(),
				'title_field' => '{{{ timeline_title }}}',
				'default'    => array(
					array(
						'timeline_date'  => esc_html__( 'January 2024', 'themeflex' ),
						'timeline_title' => esc_html__( 'Milestone 1', 'themeflex' ),
						'timeline_content' => esc_html__( 'First timeline item', 'themeflex' ),
					),
					array(
						'timeline_date'  => esc_html__( 'February 2024', 'themeflex' ),
						'timeline_title' => esc_html__( 'Milestone 2', 'themeflex' ),
						'timeline_content' => esc_html__( 'Second timeline item', 'themeflex' ),
					),
				),
			)
		);

		$this->end_controls_section();

		// Style Section
		$this->start_controls_section(
			'style_section',
			array(
				'label' => esc_html__( 'Style', 'themeflex' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'icon_color',
			array(
				'label'     => esc_html__( 'Icon Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#0066cc',
				'selectors' => array(
					'{{WRAPPER}} .timeline-icon' => 'background-color: {{VALUE}}; border-color: {{VALUE}};',
					'{{WRAPPER}} .timeline-icon i' => 'color: #ffffff;',
				),
			)
		);

		$this->add_control(
			'line_color',
			array(
				'label'     => esc_html__( 'Line Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#dddddd',
				'selectors' => array(
					'{{WRAPPER}} .timeline-line' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'title_color',
			array(
				'label'     => esc_html__( 'Title Color', 'themeflex' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#333333',
				'selectors' => array(
					'{{WRAPPER}} .timeline-title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$direction = isset( $settings['direction'] ) ? $settings['direction'] : 'vertical';
		$timeline_items = isset( $settings['timeline_items'] ) ? $settings['timeline_items'] : array();

		if ( empty( $timeline_items ) ) {
			echo '<p>' . esc_html__( 'Please add timeline items', 'themeflex' ) . '</p>';
			return;
		}

		?>
		<div class="timeline-wrapper" data-direction="<?php echo esc_attr( $direction ); ?>">
			<div class="timeline-container <?php echo esc_attr( 'timeline-' . $direction ); ?>">
				<div class="timeline-line"></div>
				<?php
				foreach ( $timeline_items as $index => $item ) :
					$date = isset( $item['timeline_date'] ) ? $item['timeline_date'] : '';
					$title = isset( $item['timeline_title'] ) ? $item['timeline_title'] : '';
					$content = isset( $item['timeline_content'] ) ? $item['timeline_content'] : '';
					$icon = isset( $item['timeline_icon']['value'] ) ? $item['timeline_icon']['value'] : 'fas fa-circle';
					$image = isset( $item['timeline_image']['url'] ) ? $item['timeline_image']['url'] : '';
					$align_class = 'horizontal' === $direction ? '' : ( 0 === $index % 2 ? 'timeline-left' : 'timeline-right' );
					?>
					<div class="timeline-item <?php echo esc_attr( $align_class ); ?>" data-animate="true">
						<div class="timeline-marker">
							<div class="timeline-icon">
								<i class="<?php echo esc_attr( $icon ); ?>"></i>
							</div>
						</div>
						<div class="timeline-content">
							<?php if ( ! empty( $image ) ) : ?>
								<img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $title ); ?>" class="timeline-image" />
							<?php endif; ?>
							<?php if ( ! empty( $date ) ) : ?>
								<div class="timeline-date"><?php echo esc_html( $date ); ?></div>
							<?php endif; ?>
							<?php if ( ! empty( $title ) ) : ?>
								<h3 class="timeline-title"><?php echo esc_html( $title ); ?></h3>
							<?php endif; ?>
							<?php if ( ! empty( $content ) ) : ?>
								<p class="timeline-text"><?php echo wp_kses_post( $content ); ?></p>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}
}
