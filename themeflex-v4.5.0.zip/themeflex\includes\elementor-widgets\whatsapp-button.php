<?php
/**
 * WhatsApp / Chat Button Widget
 * @package ThemeFlex
 */
if (!defined('ABSPATH')) exit;

class ThemeFlex_Whatsapp_Button_Widget extends \Elementor\Widget_Base {
    public function get_name()  { return 'whatsapp_button'; }
    public function get_title() { return esc_html__('WhatsApp / Chat Button','themeflex'); }
    public function get_icon()  { return 'eicon-button'; }
    public function get_categories() { return ['themeflex']; }
    public function get_keywords()   { return ['whatsapp','chat','contact','floating','button','support']; }

    protected function register_controls() {
        $this->start_controls_section('s1',['label'=>'Settings']);
        $this->add_control('phone',['label'=>'Phone (intl format)','type'=>\Elementor\Controls_Manager::TEXT,'placeholder'=>'+4917612345678','default'=>'']);
        $this->add_control('message',['label'=>'Pre-filled Message','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>'Hi, I have a question about your services.']);
        $this->add_control('tooltip',['label'=>'Tooltip Text','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Chat with us']);
        $this->add_control('position',['label'=>'Position','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['bottom-right'=>'Bottom Right','bottom-left'=>'Bottom Left'],'default'=>'bottom-right']);
        $this->add_control('color',['label'=>'Button Color','type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#25D366']);
        $this->end_controls_section();
    }

    protected function render() {
        $s     = $this->get_settings_for_display();
        $phone = preg_replace( '/[^0-9+]/', '', $s['phone'] ?? '' );
        $msg   = rawurlencode( $s['message'] ?? 'Hi, I have a question about your services.' );
        $href  = 'https://wa.me/' . $phone . '?text=' . $msg;
        $pos   = $s['position'] ?? 'bottom-right';
        $ph    = ( strpos( $pos, 'left' ) !== false ) ? 'left' : 'right';
        $pv    = ( strpos( $pos, 'bottom' ) !== false ) ? 'bottom' : 'top';
        $color = ! empty( $s['color'] ) ? $s['color'] : '#25D366';
        $tip   = ! empty( $s['tooltip'] ) ? $s['tooltip'] : esc_html__( 'Chat with us', 'themeflex' );
        ?>
        <a href="<?php echo esc_url( $href ); ?>"
           target="_blank"
           rel="noopener noreferrer"
           title="<?php echo esc_attr( $tip ); ?>"
           aria-label="<?php echo esc_attr( $tip ); ?>"
           style="position:fixed;<?php echo esc_attr( $pv ); ?>:24px;<?php echo esc_attr( $ph ); ?>:24px;z-index:9990;width:56px;height:56px;border-radius:50%;background:<?php echo esc_attr( $color ); ?>;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 20px rgba(0,0,0,.25);transition:transform .2s ease,box-shadow .2s ease;text-decoration:none;"
           onmouseover="this.style.transform='scale(1.12)';this.style.boxShadow='0 6px 28px rgba(0,0,0,.35)'"
           onmouseout="this.style.transform='scale(1)';this.style.boxShadow='0 4px 20px rgba(0,0,0,.25)'">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="#fff" aria-hidden="true" focusable="false">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
                <path d="M12 0C5.373 0 0 5.373 0 12c0 2.123.553 4.117 1.522 5.85L.057 23.9a.5.5 0 0 0 .609.61l6.098-1.466A11.953 11.953 0 0 0 12 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22c-1.9 0-3.68-.513-5.21-1.41l-.374-.213-3.873.932.947-3.826-.232-.383A9.951 9.951 0 0 1 2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/>
            </svg>
        </a>
        <?php
    }
}
