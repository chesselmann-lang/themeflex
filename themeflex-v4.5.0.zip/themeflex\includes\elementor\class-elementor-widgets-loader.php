<?php
/**
 * Elementor Widgets Loader
 *
 * Registers and loads all custom Elementor widgets
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Elementor Widgets Loader Class
 *
 * @since 1.0.0
 */
class ThemeFlex_Elementor_Widgets_Loader {

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		// Register widgets when Elementor is loaded
		add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );

		// Register widget category
		add_action( 'elementor/elements/categories_registered', array( $this, 'register_category' ) );

		// Enqueue frontend assets
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_frontend_assets' ) );

		// Enqueue editor assets
		add_action( 'elementor/editor/after_enqueue_scripts', array( $this, 'enqueue_editor_assets' ) );
	}

	/**
	 * Register widget category
	 *
	 * @param \Elementor\Elements_Manager $elements_manager Elements manager instance.
	 * @since 1.0.0
	 */
	public function register_category( $elements_manager ) {
		$elements_manager->add_category(
			'themeflex',
			array(
				'title' => esc_html__( 'ThemeFlex', 'themeflex' ),
				'icon'  => 'fa fa-plug',
			)
		);
	}

	/**
	 * Register all widgets
	 *
	 * @param \Elementor\Widgets_Manager $widgets_manager Widgets manager instance.
	 * @since 1.0.0
	 */
	public function register_widgets( $widgets_manager ) {
		$widgets = array(
			'hero-section',
			'image-gallery',
			'blog-carousel',
			'slider',
			'progress-bar',
			'countdown',
			'social-icons',
			'before-after',
			'lottie',
			'hotspot-image',
			'timeline',
			'price-list',
			'table',
			'flip-box',
			'marquee',
			'video-popup',
			'breadcrumbs-widget',
		);

		foreach ( $widgets as $widget ) {
			$this->register_widget( $widgets_manager, $widget );
		}
	}

	/**
	 * Register a single widget
	 *
	 * @param \Elementor\Widgets_Manager $widgets_manager Widgets manager instance.
	 * @param string                      $widget         Widget slug.
	 * @since 1.0.0
	 */
	private function register_widget( $widgets_manager, $widget ) {
		$file = dirname( __FILE__ ) . '/../elementor-widgets/' . $widget . '.php';

		if ( ! file_exists( $file ) ) {
			return;
		}

		require_once $file;

		// Convert slug to class name
		$class_name = $this->get_widget_class_name( $widget );

		if ( class_exists( $class_name ) ) {
			$widgets_manager->register( new $class_name() );
		}
	}

	/**
	 * Convert widget slug to class name
	 *
	 * @param string $widget Widget slug.
	 * @return string Class name.
	 * @since 1.0.0
	 */
	private function get_widget_class_name( $widget ) {
		$parts = explode( '-', $widget );
		$class_parts = array( 'Starter_Flavor' );

		foreach ( $parts as $part ) {
			$class_parts[] = ucfirst( $part );
		}

		$class_parts[] = 'Widget';

		return implode( '_', $class_parts );
	}

	/**
	 * Enqueue frontend assets
	 *
	 * @since 1.0.0
	 */
	public function enqueue_frontend_assets() {
		// Only enqueue if Elementor is active and we're on a page with Elementor content
		if ( ! did_action( 'elementor/loaded' ) ) {
			return;
		}

		$css_file = THEMEFLEX_ASSETS_DIR . 'css/elementor-widgets.css';
		$js_file  = THEMEFLEX_ASSETS_DIR . 'js/elementor-widgets.js';
		$css_pro_file = THEMEFLEX_ASSETS_DIR . 'css/elementor-widgets-pro.css';
		$js_pro_file  = THEMEFLEX_ASSETS_DIR . 'js/elementor-widgets-pro.js';

		// Enqueue CSS
		if ( file_exists( $css_file ) ) {
			wp_enqueue_style(
				'themeflex-elementor-widgets',
				THEMEFLEX_ASSETS_URL . 'css/elementor-widgets.css',
				array(),
				THEMEFLEX_VERSION,
				'all'
			);
		}

		// Enqueue Pro CSS
		if ( file_exists( $css_pro_file ) ) {
			wp_enqueue_style(
				'themeflex-elementor-widgets-pro',
				THEMEFLEX_ASSETS_URL . 'css/elementor-widgets-pro.css',
				array( 'themeflex-elementor-widgets' ),
				THEMEFLEX_VERSION,
				'all'
			);
		}

		// Enqueue JS
		if ( file_exists( $js_file ) ) {
			wp_enqueue_script(
				'themeflex-elementor-widgets',
				THEMEFLEX_ASSETS_URL . 'js/elementor-widgets.js',
				array(),
				THEMEFLEX_VERSION,
				true
			);
		}

		// Enqueue Pro JS
		if ( file_exists( $js_pro_file ) ) {
			wp_enqueue_script(
				'themeflex-elementor-widgets-pro',
				THEMEFLEX_ASSETS_URL . 'js/elementor-widgets-pro.js',
				array( 'themeflex-elementor-widgets' ),
				THEMEFLEX_VERSION,
				true
			);
		}

		// Enqueue Lottie library for Lottie animations
		wp_enqueue_script(
			'lottie-web',
			get_template_directory_uri() . '/assets/js/vendor/lottie.min.js',
			array(),
			'5.12.2',
			true
		);
	}

	/**
	 * Enqueue editor assets
	 *
	 * @since 1.0.0
	 */
	public function enqueue_editor_assets() {
		// Enqueue Elementor icons if needed
		wp_enqueue_style( 'elementor-icons' );
	}
}

// Initialize the loader
new ThemeFlex_Elementor_Widgets_Loader();
