<?php
/**
 * MetForm Plugin Integration
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add MetForm support
 *
 * @since 1.0.0
 */
function themeflex_metform_setup() {
	if ( ! function_exists( 'metform' ) ) {
		return;
	}

	// Enqueue MetForm styles
	add_action( 'wp_enqueue_scripts', 'themeflex_metform_enqueue_styles' );
}
add_action( 'plugins_loaded', 'themeflex_metform_setup' );

/**
 * Enqueue MetForm theme styles
 *
 * @since 1.0.0
 */
function themeflex_metform_enqueue_styles() {
	if ( ! function_exists( 'metform' ) ) {
		return;
	}

	wp_enqueue_style(
		'themeflex-metform',
		THEMEFLEX_URL . '/assets/css/metform.css',
		array(),
		THEMEFLEX_VERSION
	);
}

/**
 * Customize MetForm form styling
 *
 * @since 1.0.0
 * @param array $form_args Form arguments.
 * @return array
 */
function themeflex_metform_form_args( $form_args ) {
	if ( ! is_array( $form_args ) ) {
		return $form_args;
	}

	// Add theme-specific form classes
	$form_args['form_class'] = isset( $form_args['form_class'] )
		? $form_args['form_class'] . ' themeflex-form'
		: 'themeflex-form';

	return $form_args;
}
add_filter( 'metform_form_args', 'themeflex_metform_form_args' );

/**
 * Customize MetForm input field styling
 *
 * @since 1.0.0
 * @param string $html The field HTML.
 * @param array  $field The field data.
 * @return string
 */
function themeflex_metform_field_html( $html, $field ) {
	if ( ! is_array( $field ) ) {
		return $html;
	}

	// Add custom classes to inputs
	$html = str_replace(
		'class="mf-input',
		'class="mf-input themeflex-input',
		$html
	);

	return $html;
}
add_filter( 'metform_form_field_html', 'themeflex_metform_field_html', 10, 2 );

/**
 * Customize MetForm button styling
 *
 * @since 1.0.0
 * @param string $html The button HTML.
 * @return string
 */
function themeflex_metform_submit_button( $html ) {
	// Add custom classes to submit button
	$html = str_replace(
		'class="mf-button',
		'class="mf-button themeflex-submit-btn',
		$html
	);

	return $html;
}
add_filter( 'metform_form_submit_button', 'themeflex_metform_submit_button' );

/**
 * Customize MetForm validation messages
 *
 * @since 1.0.0
 * @param string $message The validation message.
 * @param string $field_name The field name.
 * @return string
 */
function themeflex_metform_validation_message( $message, $field_name ) {
	// Add custom error styling
	return '<span class="themeflex-error-message">' . esc_html( $message ) . '</span>';
}
add_filter( 'metform_field_validation_message', 'themeflex_metform_validation_message', 10, 2 );

/**
 * Add form grid layout support
 *
 * @since 1.0.0
 * @param string $html The form HTML.
 * @param int    $form_id The form ID.
 * @return string
 */
function themeflex_metform_form_wrapper( $html, $form_id ) {
	$form_layout = themeflex_get_theme_option( 'metform_form_layout', 'default' );

	// Add layout class
	$html = str_replace(
		'class="metform-container',
		'class="metform-container layout-' . esc_attr( $form_layout ) . ' ',
		$html
	);

	return $html;
}
add_filter( 'metform_form_wrapper', 'themeflex_metform_form_wrapper', 10, 2 );

/**
 * Customize form success message
 *
 * @since 1.0.0
 * @param string $message The success message.
 * @param int    $form_id The form ID.
 * @return string
 */
function themeflex_metform_success_message( $message, $form_id ) {
	return '<div class="metform-success-message themeflex-success">' . wp_kses_post( $message ) . '</div>';
}
add_filter( 'metform_response_success_message', 'themeflex_metform_success_message', 10, 2 );

/**
 * Customize form error message
 *
 * @since 1.0.0
 * @param string $message The error message.
 * @param int    $form_id The form ID.
 * @return string
 */
function themeflex_metform_error_message( $message, $form_id ) {
	return '<div class="metform-error-message themeflex-error">' . wp_kses_post( $message ) . '</div>';
}
add_filter( 'metform_response_error_message', 'themeflex_metform_error_message', 10, 2 );

/**
 * Add form customizer settings
 *
 * @since 1.0.0
 * @param WP_Customize_Manager $wp_customize The customizer object.
 */
function themeflex_metform_customizer_settings( $wp_customize ) {
	if ( ! function_exists( 'metform' ) ) {
		return;
	}

	// Add MetForm panel
	$wp_customize->add_panel(
		'themeflex_metform',
		array(
			'title'       => esc_html__( 'MetForm Settings', 'themeflex' ),
			'description' => esc_html__( 'Customize form appearance', 'themeflex' ),
			'priority'    => 55,
		)
	);

	// Form layout
	$wp_customize->add_setting(
		'themeflex_metform_form_layout',
		array(
			'default'           => 'default',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

	$wp_customize->add_control(
		'themeflex_metform_form_layout',
		array(
			'label'    => esc_html__( 'Form Layout', 'themeflex' ),
			'section'  => 'themeflex_metform',
			'type'     => 'select',
			'panel'    => 'themeflex_metform',
			'choices'  => array(
				'default'   => esc_html__( 'Default', 'themeflex' ),
				'two-column' => esc_html__( 'Two Column', 'themeflex' ),
				'three-column' => esc_html__( 'Three Column', 'themeflex' ),
			),
		)
	);

	// Input border style
	$wp_customize->add_setting(
		'themeflex_metform_input_border',
		array(
			'default'           => 'solid',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

	$wp_customize->add_control(
		'themeflex_metform_input_border',
		array(
			'label'    => esc_html__( 'Input Border Style', 'themeflex' ),
			'section'  => 'themeflex_metform',
			'type'     => 'select',
			'panel'    => 'themeflex_metform',
			'choices'  => array(
				'none'   => esc_html__( 'None', 'themeflex' ),
				'solid'  => esc_html__( 'Solid', 'themeflex' ),
				'dashed' => esc_html__( 'Dashed', 'themeflex' ),
			),
		)
	);

	// Input background color
	$wp_customize->add_setting(
		'themeflex_metform_input_bg_color',
		array(
			'default'           => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'themeflex_metform_input_bg_color',
			array(
				'label'    => esc_html__( 'Input Background Color', 'themeflex' ),
				'section'  => 'themeflex_metform',
				'panel'    => 'themeflex_metform',
			)
		)
	);

	// Button style
	$wp_customize->add_setting(
		'themeflex_metform_button_style',
		array(
			'default'           => 'solid',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

	$wp_customize->add_control(
		'themeflex_metform_button_style',
		array(
			'label'    => esc_html__( 'Button Style', 'themeflex' ),
			'section'  => 'themeflex_metform',
			'type'     => 'select',
			'panel'    => 'themeflex_metform',
			'choices'  => array(
				'solid'   => esc_html__( 'Solid', 'themeflex' ),
				'outline' => esc_html__( 'Outline', 'themeflex' ),
				'ghost'   => esc_html__( 'Ghost', 'themeflex' ),
			),
		)
	);

	// Button border radius
	$wp_customize->add_setting(
		'themeflex_metform_button_radius',
		array(
			'default'           => '4',
			'sanitize_callback' => 'absint',
		)
	);

	$wp_customize->add_control(
		'themeflex_metform_button_radius',
		array(
			'label'    => esc_html__( 'Button Border Radius (px)', 'themeflex' ),
			'section'  => 'themeflex_metform',
			'type'     => 'number',
			'panel'    => 'themeflex_metform',
			'input_attrs' => array(
				'min' => 0,
				'max' => 50,
			),
		)
	);
}
add_action( 'customize_register', 'themeflex_metform_customizer_settings' );

/**
 * Output dynamic form styles based on customizer settings
 *
 * @since 1.0.0
 */
function themeflex_metform_dynamic_styles() {
	if ( ! function_exists( 'metform' ) ) {
		return;
	}

	$input_bg = themeflex_get_theme_option( 'metform_input_bg_color', '#ffffff' );
	$button_radius = themeflex_get_theme_option( 'metform_button_radius', 4 );
	$button_style = themeflex_get_theme_option( 'metform_button_style', 'solid' );

	$css = '';

	// Input styles
	if ( $input_bg ) {
		$css .= '.themeflex-input { background-color: ' . sanitize_hex_color( $input_bg ) . '; }';
	}

	// Button radius
	$css .= '.themeflex-submit-btn { border-radius: ' . absint( $button_radius ) . 'px; }';

	// Button style
	if ( 'outline' === $button_style ) {
		$css .= '.themeflex-submit-btn { background: transparent; border: 2px solid var(--color-primary, #FF5E2E); }';
	} elseif ( 'ghost' === $button_style ) {
		$css .= '.themeflex-submit-btn { background: transparent; border: none; }';
	}

	if ( ! empty( $css ) ) {
		wp_add_inline_style( 'themeflex-metform', $css );
	}
}
add_action( 'wp_enqueue_scripts', 'themeflex_metform_dynamic_styles' );
