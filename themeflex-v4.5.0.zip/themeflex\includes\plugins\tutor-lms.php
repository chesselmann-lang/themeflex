<?php
/**
 * Tutor LMS Plugin Integration
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add Tutor LMS support
 *
 * @since 1.0.0
 */
function themeflex_tutor_lms_setup() {
	if ( ! function_exists( 'tutor' ) ) {
		return;
	}

	// Enqueue Tutor LMS styles
	add_action( 'wp_enqueue_scripts', 'themeflex_tutor_enqueue_styles' );
}
add_action( 'plugins_loaded', 'themeflex_tutor_lms_setup' );

/**
 * Enqueue Tutor LMS theme styles
 *
 * @since 1.0.0
 */
function themeflex_tutor_enqueue_styles() {
	if ( ! function_exists( 'tutor' ) ) {
		return;
	}

	// Check if we're on Tutor LMS pages
	if ( ! is_singular( 'courses' ) && ! is_singular( 'lessons' ) && ! is_tax( 'course-category' ) ) {
		return;
	}

	wp_enqueue_style(
		'themeflex-tutor-lms',
		THEMEFLEX_URL . '/assets/css/tutor-lms.css',
		array(),
		THEMEFLEX_VERSION
	);
}

/**
 * Customize course grid layout
 *
 * @since 1.0.0
 * @param int $columns Number of columns.
 * @return int
 */
function themeflex_tutor_course_columns( $columns ) {
	return themeflex_get_theme_option( 'tutor_course_columns', 3 );
}
add_filter( 'tutor_course_grid_col', 'themeflex_tutor_course_columns' );

/**
 * Add custom course card class
 *
 * @since 1.0.0
 */
function themeflex_course_card_wrapper_start() {
	echo '<div class="themeflex-course-card">';
}
add_action( 'tutor_course/before_card', 'themeflex_course_card_wrapper_start' );

/**
 * Close course card wrapper
 *
 * @since 1.0.0
 */
function themeflex_course_card_wrapper_end() {
	echo '</div>';
}
add_action( 'tutor_course/after_card', 'themeflex_course_card_wrapper_end' );

/**
 * Custom course card styling
 *
 * @since 1.0.0
 */
function themeflex_course_card_styles() {
	if ( ! is_singular( 'courses' ) && ! is_tax( 'course-category' ) && ! function_exists( 'tutor' ) ) {
		return;
	}

	echo '<!-- Tutor LMS Course Card Styling -->';
}
add_action( 'wp_head', 'themeflex_course_card_styles' );

/**
 * Register course sidebar
 *
 * @since 1.0.0
 */
function themeflex_register_course_sidebar() {
	register_sidebar( array(
		'name'          => esc_html__( 'Course Sidebar', 'themeflex' ),
		'id'            => 'tutor-course-sidebar',
		'description'   => esc_html__( 'Sidebar for course pages', 'themeflex' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'themeflex_register_course_sidebar' );

/**
 * Display course sidebar on single course page
 *
 * @since 1.0.0
 */
function themeflex_course_sidebar() {
	if ( ! is_singular( 'courses' ) ) {
		return;
	}

	if ( is_active_sidebar( 'tutor-course-sidebar' ) ) {
		echo '<aside class="course-sidebar">';
		dynamic_sidebar( 'tutor-course-sidebar' );
		echo '</aside>';
	}
}

/**
 * Add body class for Tutor LMS pages
 *
 * @since 1.0.0
 * @param array $classes Body classes.
 * @return array
 */
function themeflex_tutor_body_classes( $classes ) {
	if ( ! function_exists( 'tutor' ) ) {
		return $classes;
	}

	if ( is_singular( 'courses' ) ) {
		$classes[] = 'tutor-single-course-page';
	} elseif ( is_singular( 'lessons' ) ) {
		$classes[] = 'tutor-lesson-page';
	} elseif ( is_tax( 'course-category' ) ) {
		$classes[] = 'tutor-courses-archive';
	}

	return $classes;
}
add_filter( 'body_class', 'themeflex_tutor_body_classes' );

/**
 * Customize course list per page
 *
 * @since 1.0.0
 * @param int $per_page Courses per page.
 * @return int
 */
function themeflex_tutor_courses_per_page( $per_page ) {
	return themeflex_get_theme_option( 'tutor_courses_per_page', 12 );
}
add_filter( 'tutor_course_pagination_per_page', 'themeflex_tutor_courses_per_page' );

/**
 * Tutor LMS - Elementor Widget Integration
 *
 * @since 1.0.0
 */
function themeflex_register_tutor_elementor_widget() {
	if ( ! did_action( 'elementor/loaded' ) ) {
		return;
	}

	// Create a simple course grid widget
	$widget_file = THEMEFLEX_DIR . '/includes/elementor/widgets/tutor-courses.php';

	if ( file_exists( $widget_file ) ) {
		require_once $widget_file;
	}
}
add_action( 'elementor/widgets/register', 'themeflex_register_tutor_elementor_widget' );

/**
 * Customize enrollment button
 *
 * @since 1.0.0
 * @param string $button_html The button HTML.
 * @return string
 */
function themeflex_custom_enrollment_button( $button_html ) {
	// Add custom class to enrollment button
	$button_html = str_replace(
		'class="',
		'class="themeflex-enroll-btn ',
		$button_html
	);

	return $button_html;
}
add_filter( 'tutor_enroll_button_html', 'themeflex_custom_enrollment_button' );
