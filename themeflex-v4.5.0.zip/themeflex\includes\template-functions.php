<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Output Open Graph and Twitter Card meta tags.
 *
 * Moved here from header.php (v3.1.0) — template files must not define functions
 * to avoid "Cannot redeclare" fatal errors on theme-check or multi-call scenarios.
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'themeflex_output_og_tags' ) ) {
	function themeflex_output_og_tags() {
		global $post;

		$site_name = get_bloginfo( 'name' );
		$og_url    = esc_url( home_url( add_query_arg( array() ) ) );
		$og_type   = ( is_singular() && ! is_front_page() ) ? 'article' : 'website';
		$og_title  = wp_get_document_title();
		$og_desc   = '';
		$og_image  = '';

		if ( is_singular() && ! empty( $post ) ) {
			$og_desc = wp_trim_words(
				wp_strip_all_tags( get_the_excerpt( $post ) ?: get_the_content( null, false, $post ) ),
				30,
				'…'
			);
			if ( has_post_thumbnail( $post ) ) {
				$img = wp_get_attachment_image_src( get_post_thumbnail_id( $post ), 'large' );
				if ( $img ) {
					$og_image = esc_url( $img[0] );
				}
			}
		} elseif ( is_front_page() ) {
			$og_desc = esc_html( get_bloginfo( 'description' ) );
		}

		if ( ! $og_image ) {
			$og_image = esc_url( get_template_directory_uri() . '/screenshot.png' );
		}
		if ( ! $og_desc ) {
			$og_desc = esc_html( get_bloginfo( 'description' ) );
		}
		?>
		<!-- Open Graph -->
		<meta property="og:type"         content="<?php echo esc_attr( $og_type ); ?>">
		<meta property="og:title"        content="<?php echo esc_attr( $og_title ); ?>">
		<meta property="og:description"  content="<?php echo esc_attr( $og_desc ); ?>">
		<meta property="og:url"          content="<?php echo esc_url( $og_url ); ?>">
		<meta property="og:site_name"    content="<?php echo esc_attr( $site_name ); ?>">
		<meta property="og:image"        content="<?php echo esc_url( $og_image ); ?>">
		<meta property="og:image:width"  content="1200">
		<meta property="og:image:height" content="628">
		<!-- Twitter Card -->
		<meta name="twitter:card"        content="summary_large_image">
		<meta name="twitter:title"       content="<?php echo esc_attr( $og_title ); ?>">
		<meta name="twitter:description" content="<?php echo esc_attr( $og_desc ); ?>">
		<meta name="twitter:image"       content="<?php echo esc_url( $og_image ); ?>">
		<?php
	}
	add_action( 'wp_head', 'themeflex_output_og_tags', 1 );
}

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function themeflex_body_classes_filter( $classes ) {
	// Adds a class of hfeed to non-singular content.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	// Adds a class if the site has a custom logo.
	if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
		$classes[] = 'has-logo';
	}

	return $classes;
}
add_filter( 'body_class', 'themeflex_body_classes_filter' );

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 *
 * @since 1.0.0
 */
function themeflex_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'themeflex_pingback_header' );

/**
 * Filter the excerpt length
 *
 * @param int $length The excerpt length.
 * @return int
 */
function themeflex_excerpt_length_filter( $length ) {
	if ( is_admin() ) {
		return $length;
	}
	return 20;
}
add_filter( 'excerpt_length', 'themeflex_excerpt_length_filter' );

/**
 * Filter the excerpt more link
 *
 * @param string $more The more link.
 * @return string
 */
if ( ! function_exists( 'themeflex_excerpt_more' ) ) {
	function themeflex_excerpt_more( $more ) {
		if ( is_admin() ) {
			return $more;
		}
		return ' ... <a href="' . esc_url( get_permalink() ) . '" class="read-more">' . esc_html__( 'Read More', 'themeflex' ) . '</a>';
	}
	add_filter( 'excerpt_more', 'themeflex_excerpt_more' );
}

/**
 * Enqueue editor styles for the block editor
 *
 * @since 1.0.0
 */
function themeflex_block_editor_styles() {
	wp_enqueue_style(
		'themeflex-editor-styles',
		THEMEFLEX_URL . '/styles/editor-style.css',
		array(),
		THEMEFLEX_VERSION
	);
}
add_action( 'enqueue_block_editor_assets', 'themeflex_block_editor_styles' );

/**
 * WebP-aware <picture> helper
 *
 * Outputs a <picture> element that serves a WebP version when available,
 * falling back to the original image.  This gives a free performance win
 * without any server-side conversion — just upload both formats.
 *
 * Usage:
 *   sf_picture( 300, 'hero-team', 'My team', 'sf-team-photo', 'lazy' );
 *   sf_picture( $attachment_id );  // minimal usage
 *
 * @param int    $attachment_id  WordPress attachment ID.
 * @param string $size           Image size slug (default: 'large').
 * @param string $alt            Alt text override. Falls back to attachment alt.
 * @param string $class          CSS class on the <img>.
 * @param string $loading        'lazy' | 'eager' (default: 'lazy').
 * @param string $decoding       'async' | 'sync' | 'auto' (default: 'async').
 * @return string                HTML <picture> markup.
 *
 * @since 1.1.0
 */
function sf_picture( $attachment_id, $size = 'large', $alt = '', $class = '', $loading = 'lazy', $decoding = 'async' ) {
	if ( ! $attachment_id ) {
		return '';
	}

	$img_src  = wp_get_attachment_image_url( $attachment_id, $size );
	$img_meta = wp_get_attachment_image_src( $attachment_id, $size );

	if ( ! $img_src ) {
		return '';
	}

	$width  = $img_meta ? (int) $img_meta[1] : 0;
	$height = $img_meta ? (int) $img_meta[2] : 0;

	// Derive WebP path: /path/to/image.jpg → /path/to/image.jpg.webp
	// Works with Imagify, ShortPixel, Smush, etc.
	$webp_src = $img_src . '.webp';

	// Also check for filename-based WebP: image.jpg → image.webp
	$webp_alt = preg_replace( '/\.(jpe?g|png)$/i', '.webp', $img_src );

	if ( ! $alt ) {
		$alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
	}

	$alt_attr   = esc_attr( $alt );
	$class_attr = $class ? ' class="' . esc_attr( $class ) . '"' : '';
	$size_attr  = ( $width && $height ) ? ' width="' . $width . '" height="' . $height . '"' : '';
	$load_attr  = $loading ? ' loading="' . esc_attr( $loading ) . '"' : '';
	$dec_attr   = $decoding ? ' decoding="' . esc_attr( $decoding ) . '"' : '';
	$srcset     = wp_get_attachment_image_srcset( $attachment_id, $size );
	$srcset_attr = $srcset ? ' srcset="' . esc_attr( $srcset ) . '"' : '';

	ob_start();
	?>
	<picture>
		<?php if ( $webp_src !== $webp_alt ) : ?>
		<source type="image/webp" srcset="<?php echo esc_url( $webp_alt ); ?>">
		<?php endif; ?>
		<source type="image/webp" srcset="<?php echo esc_url( $webp_src ); ?>">
		<img
			src="<?php echo esc_url( $img_src ); ?>"
			alt="<?php echo $alt_attr; ?>"
			<?php echo $class_attr . $size_attr . $srcset_attr . $load_attr . $dec_attr; ?>
		>
	</picture>
	<?php
	return ob_get_clean();
}

/**
 * Shorthand echo version of sf_picture().
 *
 * @param int    $attachment_id  WordPress attachment ID.
 * @param string $size           Image size slug (default: 'large').
 * @param string $alt            Alt text override.
 * @param string $class          CSS class on the <img>.
 * @param string $loading        'lazy' | 'eager'.
 *
 * @since 1.1.0
 */
function sf_the_picture( $attachment_id, $size = 'large', $alt = '', $class = '', $loading = 'lazy' ) {
	echo sf_picture( $attachment_id, $size, $alt, $class, $loading ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}
