<?php
/**
 * The main template file
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// NOTE: home.php handles the blog posts page (is_home()).
// This file is only reached for categories, tags, search, date archives, etc.

get_header();

do_action( 'themeflex_before_loop' );

if ( have_posts() ) :
	do_action( 'themeflex_before_posts' );

	$layout_mode  = themeflex_get_theme_option( 'blog_layout', 'grid' );
	$grid_columns = intval( themeflex_get_theme_option( 'blog_grid_columns', 3 ) );
	?>
	<div class="posts-list posts-layout-<?php echo esc_attr( $layout_mode ); ?><?php echo $layout_mode === 'grid' ? ' posts-grid-' . esc_attr( $grid_columns ) : ''; ?>"
	     role="region" aria-label="<?php esc_attr_e( 'Posts', 'themeflex' ); ?>">
		<?php
		while ( have_posts() ) :
			the_post();
			if ( $layout_mode === 'grid' && locate_template( 'template-parts/content-grid.php' ) ) {
				get_template_part( 'template-parts/content', 'grid' );
			} else {
				get_template_part( 'template-parts/content', get_post_type() );
			}
		endwhile;
		?>
	</div>

	<?php
	do_action( 'themeflex_after_posts' );
	?>

	<nav class="posts-navigation pagination" role="navigation"
	     aria-label="<?php esc_attr_e( 'Posts', 'themeflex' ); ?>">
		<h2 class="screen-reader-text"><?php esc_html_e( 'Posts navigation', 'themeflex' ); ?></h2>
		<div class="nav-links">
			<?php echo wp_kses_post( paginate_links( [
				'type'      => 'list',
				'prev_text' => '<span class="nav-previous">' . esc_html__( '← Newer Posts', 'themeflex' ) . '</span>',
				'next_text' => '<span class="nav-next">' . esc_html__( 'Older Posts →', 'themeflex' ) . '</span>',
			] ) ); ?>
		</div>
	</nav>

<?php else :
	get_template_part( 'template-parts/content', 'none' );
endif;

do_action( 'themeflex_after_loop' );

get_footer();
