/**
 * Navigation Module
 * Vanilla JS - No jQuery dependency
 * ThemeFlex Theme
 */

(function() {
  'use strict';

  // Configuration
  const config = {
    desktopHoverDelay: 300,
    scrollStickyThreshold: 100,
    searchToggleDuration: 300,
  };

  // State
  const state = {
    mobileMenuOpen: false,
    activeSubmenu: null,
    hoverTimeouts: {},
  };

  /**
   * Initialize Navigation Module
   */
  function init() {
    setupMobileMenuToggle();
    setupDesktopMenus();
    setupMobileSubmenus();
    setupKeyboardNavigation();
    setupStickyHeader();
    setupAnchorLinks();
    setupSearchToggle();
    setupSideMenu();
    setupBackToTopButton();
  }

  /**
   * Mobile Menu Toggle (Burger Icon)
   */
  function setupMobileMenuToggle() {
    const toggle = document.querySelector('.menu-toggle');
    const nav = document.querySelector('.primary-navigation');

    if (!toggle || !nav) return;

    toggle.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();

      state.mobileMenuOpen = !state.mobileMenuOpen;
      toggle.classList.toggle('active', state.mobileMenuOpen);
      nav.classList.toggle('active', state.mobileMenuOpen);
      document.body.classList.toggle('menu-open', state.mobileMenuOpen);
    });

    // Close menu on outside click
    document.addEventListener('click', function(e) {
      if (state.mobileMenuOpen && !nav.contains(e.target) && !toggle.contains(e.target)) {
        closeMobileMenu();
      }
    });

    // Close menu on escape key
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape' && state.mobileMenuOpen) {
        closeMobileMenu();
      }
    });
  }

  /**
   * Close Mobile Menu
   */
  function closeMobileMenu() {
    state.mobileMenuOpen = false;
    const toggle = document.querySelector('.menu-toggle');
    const nav = document.querySelector('.primary-navigation');

    if (toggle) toggle.classList.remove('active');
    if (nav) nav.classList.remove('active');
    document.body.classList.remove('menu-open');
  }

  /**
   * Desktop Menu Hover Effects
   */
  function setupDesktopMenus() {
    if (window.innerWidth < 768) return;

    const menuItems = document.querySelectorAll('.primary-navigation li');

    menuItems.forEach(item => {
      const submenu = item.querySelector('.submenu');
      if (!submenu) return;

      // Hover delay for opening submenu
      item.addEventListener('mouseenter', function() {
        clearTimeout(state.hoverTimeouts[item]);
        state.hoverTimeouts[item] = setTimeout(() => {
          submenu.classList.add('active');
        }, config.desktopHoverDelay);
      });

      // Close submenu on mouse leave
      item.addEventListener('mouseleave', function() {
        clearTimeout(state.hoverTimeouts[item]);
        submenu.classList.remove('active');
      });
    });
  }

  /**
   * Mobile Submenu Accordion
   */
  function setupMobileSubmenus() {
    const menuItems = document.querySelectorAll('.primary-navigation li');

    menuItems.forEach(item => {
      const submenu = item.querySelector('.submenu');
      if (!submenu) return;

      // Create toggle button for submenu
      const link = item.querySelector('a');
      if (!link) return;

      link.addEventListener('click', function(e) {
        // Only prevent default if there are submenus
        if (submenu && submenu.children.length > 0) {
          if (window.innerWidth < 768) {
            e.preventDefault();
            e.stopPropagation();
            toggleSubmenu(item, submenu);
          }
        }
      });
    });
  }

  /**
   * Toggle Submenu with Smooth Height Animation
   */
  function toggleSubmenu(item, submenu) {
    const isActive = submenu.classList.contains('active');

    if (isActive) {
      // Collapse
      submenu.style.maxHeight = '0px';
      submenu.classList.remove('active');
      setTimeout(() => {
        submenu.style.maxHeight = '';
      }, 300);
    } else {
      // Expand
      submenu.classList.add('active');
      submenu.style.maxHeight = submenu.scrollHeight + 'px';

      // Update height when content changes
      const observer = new ResizeObserver(() => {
        if (submenu.classList.contains('active')) {
          submenu.style.maxHeight = submenu.scrollHeight + 'px';
        }
      });
      observer.observe(submenu);
    }
  }

  /**
   * Keyboard Navigation
   */
  function setupKeyboardNavigation() {
    const nav = document.querySelector('.primary-navigation');
    if (!nav) return;

    const links = nav.querySelectorAll('a');

    links.forEach((link, index) => {
      // Tab Navigation
      link.addEventListener('keydown', function(e) {
        if (e.key === 'Tab') {
          handleTabKey(e, link, links);
        }
        // Escape Key
        else if (e.key === 'Escape') {
          closeMobileMenu();
        }
        // Arrow Keys
        else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
          handleArrowKeys(e, link, links);
        }
      });
    });
  }

  /**
   * Handle Tab Key Navigation
   */
  function handleTabKey(e, link, links) {
    if (e.shiftKey) {
      // Shift+Tab - move to previous
      if (link === links[0]) {
        closeMobileMenu();
      }
    } else {
      // Tab - move to next
      if (link === links[links.length - 1]) {
        closeMobileMenu();
      }
    }
  }

  /**
   * Handle Arrow Keys
   */
  function handleArrowKeys(e, link, links) {
    const currentIndex = Array.from(links).indexOf(link);
    let nextIndex;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      nextIndex = currentIndex + 1 < links.length ? currentIndex + 1 : 0;
      links[nextIndex].focus();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      nextIndex = currentIndex - 1 >= 0 ? currentIndex - 1 : links.length - 1;
      links[nextIndex].focus();
    }
  }

  /**
   * Sticky Header on Scroll
   */
  function setupStickyHeader() {
    const header = document.querySelector('.site-header');
    if (!header) return;

    let lastScrollY = 0;

    function checkStickyHeader() {
      const scrollY = window.scrollY || window.pageYOffset;

      if (scrollY > config.scrollStickyThreshold) {
        header.classList.add('is-sticky');
        document.body.classList.add('has-sticky-header');
      } else {
        header.classList.remove('is-sticky');
        document.body.classList.remove('has-sticky-header');
      }

      lastScrollY = scrollY;
    }

    // Use requestAnimationFrame for smooth performance
    function throttledScroll() {
      requestAnimationFrame(checkStickyHeader);
    }

    window.addEventListener('scroll', throttledScroll, { passive: true });

    // Initial check
    checkStickyHeader();
  }

  /**
   * Smooth Scroll for Anchor Links
   */
  function setupAnchorLinks() {
    document.addEventListener('click', function(e) {
      const link = e.target.closest('a[href^="#"]');
      if (!link) return;

      const href = link.getAttribute('href');
      if (href === '#') return;

      const target = document.querySelector(href);
      if (!target) return;

      e.preventDefault();

      // Close mobile menu if open
      if (state.mobileMenuOpen) {
        closeMobileMenu();
      }

      // Smooth scroll to target
      target.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
      });

      // Update URL without page jump
      window.history.pushState(null, '', href);
    });
  }

  /**
   * Search Toggle Functionality
   */
  function setupSearchToggle() {
    const searchButton = document.querySelector('.search-toggle');
    const searchForm = document.querySelector('.search-form');

    if (!searchButton || !searchForm) return;

    searchButton.addEventListener('click', function(e) {
      e.preventDefault();
      searchForm.classList.toggle('active');

      const searchInput = searchForm.querySelector('input[type="search"]');
      if (searchInput && searchForm.classList.contains('active')) {
        searchInput.focus();
      }
    });

    // Close search on escape
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape' && searchForm.classList.contains('active')) {
        searchForm.classList.remove('active');
      }
    });
  }

  /**
   * Side Menu Open/Close
   */
  function setupSideMenu() {
    const sideMenu = document.querySelector('.side-menu');
    const sideMenuToggle = document.querySelector('[data-toggle="side-menu"]');
    const sideMenuClose = document.querySelector('.side-menu-close');
    const sideMenuOverlay = document.querySelector('.side-menu-overlay');

    if (!sideMenu) return;

    // Open side menu
    if (sideMenuToggle) {
      sideMenuToggle.addEventListener('click', function(e) {
        e.preventDefault();
        openSideMenu();
      });
    }

    // Close side menu
    if (sideMenuClose) {
      sideMenuClose.addEventListener('click', function(e) {
        e.preventDefault();
        closeSideMenu();
      });
    }

    // Close on overlay click
    if (sideMenuOverlay) {
      sideMenuOverlay.addEventListener('click', function() {
        closeSideMenu();
      });
    }

    // Close on escape key
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape' && sideMenu.classList.contains('active')) {
        closeSideMenu();
      }
    });

    // Close on menu link click
    const sideMenuLinks = sideMenu.querySelectorAll('a');
    sideMenuLinks.forEach(link => {
      link.addEventListener('click', function() {
        closeSideMenu();
      });
    });
  }

  /**
   * Open Side Menu
   */
  function openSideMenu() {
    const sideMenu = document.querySelector('.side-menu');
    const overlay = document.querySelector('.side-menu-overlay');

    if (!sideMenu) return;

    sideMenu.classList.add('active');
    if (overlay) overlay.classList.add('active');
    document.body.classList.add('side-menu-open');
  }

  /**
   * Close Side Menu
   */
  function closeSideMenu() {
    const sideMenu = document.querySelector('.side-menu');
    const overlay = document.querySelector('.side-menu-overlay');

    if (!sideMenu) return;

    sideMenu.classList.remove('active');
    if (overlay) overlay.classList.remove('active');
    document.body.classList.remove('side-menu-open');
  }

  /**
   * Back to Top Button
   */
  function setupBackToTopButton() {
    const backToTopBtn = document.querySelector('.back-to-top');
    if (!backToTopBtn) return;

    function checkBackToTop() {
      if (window.scrollY > 600) {
        backToTopBtn.classList.add('visible');
      } else {
        backToTopBtn.classList.remove('visible');
      }
    }

    window.addEventListener('scroll', function() {
      requestAnimationFrame(checkBackToTop);
    }, { passive: true });

    backToTopBtn.addEventListener('click', function(e) {
      e.preventDefault();
      window.scrollTo({
        top: 0,
        behavior: 'smooth',
      });
    });

    // Initial check
    checkBackToTop();
  }

  /**
   * Update Active Menu Item on Scroll
   */
  function setupActiveMenuScroll() {
    const menuItems = document.querySelectorAll('.primary-navigation a[href^="#"]');
    if (!menuItems.length) return;

    function updateActiveMenu() {
      menuItems.forEach(item => {
        const section = document.querySelector(item.getAttribute('href'));
        if (!section) return;

        const rect = section.getBoundingClientRect();
        if (rect.top <= 150 && rect.bottom >= 150) {
          menuItems.forEach(m => m.classList.remove('active'));
          item.classList.add('active');
        }
      });
    }

    window.addEventListener('scroll', function() {
      requestAnimationFrame(updateActiveMenu);
    }, { passive: true });
  }

  /**
   * Handle Window Resize
   */
  function setupResizeHandler() {
    let resizeTimeout;

    window.addEventListener('resize', function() {
      clearTimeout(resizeTimeout);
      resizeTimeout = setTimeout(function() {
        // Reinitialize on resize
        if (window.innerWidth >= 768 && state.mobileMenuOpen) {
          closeMobileMenu();
        }
      }, 250);
    });
  }

  /**
   * Initialize on DOM Ready
   */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  setupResizeHandler();
  setupActiveMenuScroll();

  // Expose public API
  window.ThemeFlexNav = {
    closeMobileMenu: closeMobileMenu,
    openSideMenu: openSideMenu,
    closeSideMenu: closeSideMenu,
  };

})();
