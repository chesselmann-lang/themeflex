/**
 * Skip Link Focus Fix
 * Accessibility enhancement for keyboard navigation
 * ThemeFlex Theme
 *
 * Allows the skip link to properly focus on the main content area,
 * even when the content area is not typically focusable.
 */

(function() {
  'use strict';

  // Check if the page is still loading
  if ('loading' === document.readyState) {
    document.addEventListener('DOMContentLoaded', fixSkipLinkFocus);
  } else {
    fixSkipLinkFocus();
  }

  /**
   * Fix Skip Link Focus
   * Makes the target of skip links focusable if it isn't already
   */
  function fixSkipLinkFocus() {
    // Get all skip links on the page
    const skipLinks = document.querySelectorAll('a.skip-link');

    skipLinks.forEach(function(skipLink) {
      // Get the href attribute
      const href = skipLink.getAttribute('href');

      // If no href, skip this link
      if (!href || href === '#') {
        return;
      }

      // Get the target element
      const target = document.querySelector(href);

      // If no target found, skip this link
      if (!target) {
        return;
      }

      // Listen for click on the skip link
      skipLink.addEventListener('click', function(e) {
        // Focus the target element
        target.focus();

        // Optionally prevent the default scroll behavior
        // This allows custom scroll handling if needed
      });

      // Add tabindex if the target is not a natural focusable element
      const isFocusable = isNaturallyFocusable(target);

      if (!isFocusable) {
        // Set tabindex to -1 so it can be focused programmatically
        // but won't be in the normal tab order
        target.setAttribute('tabindex', '-1');

        // Remove tabindex when user tabs away (mouse users won't see the outline)
        target.addEventListener('blur', function() {
          target.removeAttribute('tabindex');
        });

        // Also remove the outline when focused to reduce visual distraction
        // (You can customize this behavior)
        target.style.outline = 'none';
      }
    });
  }

  /**
   * Check if an element is naturally focusable
   * @param {HTMLElement} element - The element to check
   * @returns {boolean} True if the element is naturally focusable
   */
  function isNaturallyFocusable(element) {
    const focusableElements = [
      'a[href]',
      'button:not([disabled])',
      'input:not([disabled])',
      'select:not([disabled])',
      'textarea:not([disabled])',
      '[tabindex]',
      'audio[controls]',
      'video[controls]',
      'details',
    ];

    // Check if the element matches any focusable selector
    for (let i = 0; i < focusableElements.length; i++) {
      if (element.matches(focusableElements[i])) {
        return true;
      }
    }

    return false;
  }

})();
