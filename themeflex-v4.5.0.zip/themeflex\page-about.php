<?php
/**
 * Page Template: About
 *
 * Best-in-class About page — animated hero orbs, stats counter, story
 * timeline, values grid, team cards, client logo strip, awards, and CTA.
 *
 * Template Name: About Page
 *
 * @package ThemeFlex
 * @since   3.0.0
 */
?>
<style>
/* ══════════════════════════════════════════════════════════════════════
   THEMEFLEX — ABOUT PAGE  v3.0
   Dark-first premium layout with CSS animations & vanilla JS counters
   ══════════════════════════════════════════════════════════════════════ */

/* ── Reset & base ──────────────────────────────────────────────────── */
.tf-about { --tf-accent: #ff5e2e; --tf-bg: #06021d; --tf-bg-2: #0a0f1e;
  --tf-border: rgba(255,255,255,.07); --tf-text: #f1f5f9;
  --tf-muted: #64748b; color: var(--tf-text); }
.tf-about *, .tf-about *::before, .tf-about *::after { box-sizing: border-box; }
.tf-about section { position: relative; }
.tf-about p { margin: 0; }
.tf-about a { text-decoration: none; }

/* ── Layout helpers ────────────────────────────────────────────────── */
.tf-wrap  { max-width: 1200px; margin: 0 auto; padding: 0 24px; }
.tf-wrap--narrow { max-width: 860px; margin: 0 auto; padding: 0 24px; }
.tf-sec   { padding: 110px 0; }
.tf-sec-hd { text-align: center; margin-bottom: 72px; }
.tf-sec-hd h2 {
  font-family: 'Inter Tight', sans-serif;
  font-size: clamp(2rem, 3.2vw, 2.8rem);
  font-weight: 900; letter-spacing: -.04em; line-height: 1.1;
  color: var(--tf-text); margin: 0 0 14px;
}
.tf-sec-hd p { color: var(--tf-muted); font-size: .95rem; line-height: 1.75; max-width: 500px; margin: 0 auto; }

/* Eyebrow pill */
.tf-pill {
  display: inline-flex; align-items: center; gap: 7px;
  font-size: .65rem; font-weight: 800; letter-spacing: .15em; text-transform: uppercase;
  padding: 5px 16px; border-radius: 100px; margin-bottom: 20px;
  border: 1px solid; white-space: nowrap;
}
.tf-pill--accent { background: rgba(255,94,46,.1); border-color: rgba(255,94,46,.3); color: #ff7a54; }
.tf-pill--violet { background: rgba(139,92,246,.1); border-color: rgba(139,92,246,.3); color: #a78bfa; }
.tf-pill--teal   { background: rgba(20,184,166,.1);  border-color: rgba(20,184,166,.3);  color: #2dd4bf; }
.tf-pill--blue   { background: rgba(59,130,246,.1);  border-color: rgba(59,130,246,.3);  color: #60a5fa; }
.tf-pill--green  { background: rgba(16,185,129,.1);  border-color: rgba(16,185,129,.3);  color: #34d399; }
.tf-pill--gold   { background: rgba(245,158,11,.1);  border-color: rgba(245,158,11,.3);  color: #fbbf24; }

/* Gradient text */
.tf-gtext {
  background: linear-gradient(135deg, #ff5e2e 0%, #ff9d5e 45%, #a855f7 100%);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
}

/* ── @keyframes ────────────────────────────────────────────────────── */
@keyframes tf-orb-drift {
  0%   { transform: translate(0, 0) scale(1); }
  33%  { transform: translate(60px, -40px) scale(1.08); }
  66%  { transform: translate(-40px, 50px) scale(.95); }
  100% { transform: translate(0, 0) scale(1); }
}
@keyframes tf-orb-drift-2 {
  0%   { transform: translate(0, 0) scale(1); }
  50%  { transform: translate(-70px, 30px) scale(1.12); }
  100% { transform: translate(0, 0) scale(1); }
}
@keyframes tf-orb-drift-3 {
  0%   { transform: translate(0, 0) scale(1); }
  40%  { transform: translate(40px, 60px) scale(.9); }
  80%  { transform: translate(-30px, -20px) scale(1.05); }
  100% { transform: translate(0, 0) scale(1); }
}
@keyframes tf-fade-up {
  from { opacity: 0; transform: translateY(32px); }
  to   { opacity: 1; transform: translateY(0); }
}
@keyframes tf-pulse-ring {
  0%   { transform: scale(1); opacity: .6; }
  100% { transform: scale(1.4); opacity: 0; }
}
@keyframes tf-counter-bg-shift {
  0%   { background-position: 0% 50%; }
  50%  { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}
@keyframes tf-logo-scroll {
  from { transform: translateX(0); }
  to   { transform: translateX(-50%); }
}

/* ════════════════════════════════════════════════════════════════════
   1. HERO
   ════════════════════════════════════════════════════════════════════ */
.tf-hero {
  min-height: 92vh;
  background: var(--tf-bg);
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  text-align: center;
  padding: 160px 24px 120px;
  overflow: hidden;
}
/* Animated orbs */
.tf-hero__orbs { position: absolute; inset: 0; pointer-events: none; z-index: 0; }
.tf-hero__orb {
  position: absolute; border-radius: 50%;
  filter: blur(80px); opacity: .5;
}
.tf-hero__orb--1 {
  width: 700px; height: 700px;
  top: -200px; left: -100px;
  background: radial-gradient(circle, rgba(255,94,46,.22) 0%, transparent 65%);
  animation: tf-orb-drift 18s ease-in-out infinite;
}
.tf-hero__orb--2 {
  width: 600px; height: 600px;
  top: -100px; right: -150px;
  background: radial-gradient(circle, rgba(139,92,246,.18) 0%, transparent 65%);
  animation: tf-orb-drift-2 22s ease-in-out infinite;
}
.tf-hero__orb--3 {
  width: 500px; height: 500px;
  bottom: -100px; left: 40%;
  background: radial-gradient(circle, rgba(59,130,246,.15) 0%, transparent 65%);
  animation: tf-orb-drift-3 26s ease-in-out infinite;
}
/* Dot grid overlay */
.tf-hero::after {
  content: '';
  position: absolute; inset: 0; z-index: 1;
  background-image: radial-gradient(rgba(255,255,255,.022) 1px, transparent 1px);
  background-size: 36px 36px;
  pointer-events: none;
}
.tf-hero__inner {
  position: relative; z-index: 2;
  max-width: 820px; margin: 0 auto;
  animation: tf-fade-up .8s cubic-bezier(.16,1,.3,1) both;
}
.tf-hero__h1 {
  font-family: 'Inter Tight', sans-serif;
  font-size: clamp(2.6rem, 5.5vw, 4.5rem);
  font-weight: 900; letter-spacing: -.05em; line-height: 1.06;
  color: var(--tf-text); margin: 0 0 24px;
}
.tf-hero__sub {
  font-size: clamp(.95rem, 1.5vw, 1.15rem);
  color: #94a3b8; line-height: 1.8;
  max-width: 600px; margin: 0 auto 48px;
}
/* Mini stats inline */
.tf-hero__stats {
  display: flex; align-items: center; justify-content: center;
  gap: 0; flex-wrap: wrap;
}
.tf-hero__stat {
  display: flex; flex-direction: column; align-items: center;
  padding: 20px 40px;
  border-left: 1px solid rgba(255,255,255,.08);
}
.tf-hero__stat:first-child { border-left: none; }
.tf-hero__stat-num {
  font-family: 'Inter Tight', sans-serif;
  font-size: 1.5rem; font-weight: 900; letter-spacing: -.04em;
  color: var(--tf-text); line-height: 1;
}
.tf-hero__stat-lbl {
  font-size: .72rem; font-weight: 700; letter-spacing: .08em;
  text-transform: uppercase; color: var(--tf-muted); margin-top: 5px;
}
/* Wave divider */
.tf-hero__wave {
  position: absolute; bottom: -1px; left: 0; right: 0; z-index: 3;
  overflow: hidden; pointer-events: none; line-height: 0;
}

/* ════════════════════════════════════════════════════════════════════
   2. STATS BAR
   ════════════════════════════════════════════════════════════════════ */
.tf-statsbar {
  background: var(--tf-bg-2);
  border-top: 1px solid var(--tf-border);
  border-bottom: 1px solid var(--tf-border);
  padding: 0;
}
.tf-statsbar__grid {
  display: grid; grid-template-columns: repeat(4, 1fr);
}
.tf-statsbar__item {
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  padding: 52px 24px;
  border-right: 1px solid var(--tf-border);
  text-align: center; position: relative; overflow: hidden;
  transition: background .3s;
}
.tf-statsbar__item:last-child { border-right: none; }
.tf-statsbar__item::before {
  content: '';
  position: absolute; bottom: 0; left: 50%; transform: translateX(-50%);
  width: 60%; height: 2px;
  background: var(--sb-color, var(--tf-accent));
  opacity: 0; transition: opacity .3s;
}
.tf-statsbar__item:hover { background: rgba(255,255,255,.02); }
.tf-statsbar__item:hover::before { opacity: 1; }
.tf-statsbar__num {
  font-family: 'Inter Tight', sans-serif;
  font-size: clamp(2.2rem, 4vw, 3.2rem);
  font-weight: 900; letter-spacing: -.05em; line-height: 1;
  color: var(--tf-text); display: flex; align-items: flex-start; gap: 2px;
}
.tf-statsbar__suffix {
  font-size: .6em; font-weight: 900; color: var(--sb-color, var(--tf-accent));
  margin-top: .15em;
}
.tf-statsbar__lbl {
  font-size: .78rem; font-weight: 700; letter-spacing: .1em;
  text-transform: uppercase; color: var(--tf-muted); margin-top: 10px;
}
.tf-statsbar__icon {
  width: 40px; height: 40px; border-radius: 12px; margin-bottom: 16px;
  display: flex; align-items: center; justify-content: center;
  background: rgba(255,255,255,.04); border: 1px solid var(--tf-border);
  color: var(--sb-color, var(--tf-accent));
}
.tf-statsbar__icon svg { display: block; }

/* ════════════════════════════════════════════════════════════════════
   3. OUR STORY
   ════════════════════════════════════════════════════════════════════ */
.tf-story { background: var(--tf-bg); }
.tf-story__grid {
  display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: start;
}
.tf-story__text h2 {
  font-family: 'Inter Tight', sans-serif;
  font-size: clamp(1.9rem, 2.8vw, 2.6rem);
  font-weight: 900; letter-spacing: -.04em; line-height: 1.1;
  color: var(--tf-text); margin: 0 0 24px;
}
.tf-story__text p {
  color: var(--tf-muted); font-size: .95rem; line-height: 1.85; margin-bottom: 18px;
}
.tf-story__text p:last-of-type { margin-bottom: 0; }

/* Timeline in right column */
.tf-timeline { padding-left: 28px; position: relative; }
.tf-timeline::before {
  content: '';
  position: absolute; left: 0; top: 8px; bottom: 8px; width: 2px;
  background: linear-gradient(180deg,
    #3b82f6 0%, #8b5cf6 33%, #ff5e2e 66%, #10b981 100%);
  opacity: .45; border-radius: 2px;
}
.tf-tl-item {
  position: relative; padding: 0 0 48px 32px;
  opacity: 0; transform: translateX(-18px);
  transition: opacity .55s ease, transform .55s ease;
}
.tf-tl-item.is-visible { opacity: 1; transform: none; }
.tf-tl-item:nth-child(1) { transition-delay: 0s; }
.tf-tl-item:nth-child(2) { transition-delay: .1s; }
.tf-tl-item:nth-child(3) { transition-delay: .2s; }
.tf-tl-item:nth-child(4) { transition-delay: .3s; }
.tf-tl-item:last-child { padding-bottom: 0; }
/* Dot */
.tf-tl-item::before {
  content: '';
  position: absolute; left: -8px; top: 5px;
  width: 18px; height: 18px; border-radius: 50%;
  background: var(--tl-c, #3b82f6);
  box-shadow: 0 0 0 4px var(--tf-bg), 0 0 0 6px var(--tl-c, #3b82f6);
}
/* Pulse ring */
.tf-tl-item::after {
  content: '';
  position: absolute; left: -8px; top: 5px;
  width: 18px; height: 18px; border-radius: 50%;
  background: transparent;
  border: 2px solid var(--tl-c, #3b82f6);
  opacity: 0;
}
.tf-tl-item.is-visible::after {
  animation: tf-pulse-ring 1.8s ease-out 0.4s infinite;
}
.tf-tl-year {
  font-size: .68rem; font-weight: 800; letter-spacing: .14em;
  text-transform: uppercase; color: var(--tl-c, #3b82f6); margin-bottom: 6px;
}
.tf-tl-title {
  font-family: 'Inter Tight', sans-serif;
  font-size: 1.05rem; font-weight: 900;
  color: var(--tf-text); letter-spacing: -.02em; margin: 0 0 8px;
}
.tf-tl-desc { font-size: .87rem; color: var(--tf-muted); line-height: 1.7; margin: 0; }

/* ════════════════════════════════════════════════════════════════════
   4. VALUES GRID
   ════════════════════════════════════════════════════════════════════ */
.tf-values { background: var(--tf-bg-2); }
.tf-values__grid {
  display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px;
}
.tf-val-card {
  background: rgba(255,255,255,.025);
  border: 1px solid var(--tf-border);
  border-radius: 22px; padding: 36px 30px;
  transition: transform .3s cubic-bezier(.16,1,.3,1), box-shadow .3s,
              border-color .3s, background .3s;
  position: relative; overflow: hidden;
}
.tf-val-card::after {
  content: '';
  position: absolute; inset: 0; border-radius: 22px;
  background: radial-gradient(circle at 50% 0%, var(--vc-color, rgba(255,94,46,.12)) 0%, transparent 70%);
  opacity: 0; transition: opacity .4s;
}
.tf-val-card:hover {
  transform: translateY(-6px);
  box-shadow: 0 24px 60px rgba(0,0,0,.35);
  border-color: rgba(255,255,255,.12);
}
.tf-val-card:hover::after { opacity: 1; }
.tf-val-icon {
  width: 56px; height: 56px; border-radius: 16px;
  display: flex; align-items: center; justify-content: center;
  margin-bottom: 22px; position: relative; z-index: 1;
}
.tf-val-icon svg { display: block; }
.tf-val-name {
  font-family: 'Inter Tight', sans-serif;
  font-size: 1.05rem; font-weight: 900;
  color: var(--tf-text); letter-spacing: -.02em;
  margin: 0 0 10px; position: relative; z-index: 1;
}
.tf-val-desc {
  font-size: .88rem; color: var(--tf-muted); line-height: 1.72;
  position: relative; z-index: 1;
}

/* ════════════════════════════════════════════════════════════════════
   5. TEAM
   ════════════════════════════════════════════════════════════════════ */
.tf-team { background: var(--tf-bg); }
.tf-team__grid {
  display: grid; grid-template-columns: repeat(3, 1fr); gap: 22px;
}
.tf-team-card {
  background: rgba(255,255,255,.025);
  border: 1px solid var(--tf-border);
  border-radius: 22px; padding: 36px 26px;
  text-align: center;
  opacity: 0; transform: translateY(24px);
  transition: opacity .5s ease, transform .5s ease, box-shadow .3s, border-color .3s;
}
.tf-team-card.is-visible { opacity: 1; transform: none; }
.tf-team-card:hover {
  box-shadow: 0 20px 50px rgba(0,0,0,.35);
  border-color: rgba(255,255,255,.11);
}
.tf-team-card:nth-child(1) { transition-delay: 0s; }
.tf-team-card:nth-child(2) { transition-delay: .07s; }
.tf-team-card:nth-child(3) { transition-delay: .14s; }
.tf-team-card:nth-child(4) { transition-delay: .21s; }
.tf-team-card:nth-child(5) { transition-delay: .28s; }
.tf-team-card:nth-child(6) { transition-delay: .35s; }
.tf-team-avatar {
  width: 80px; height: 80px; border-radius: 50%;
  margin: 0 auto 18px;
  display: flex; align-items: center; justify-content: center;
  font-family: 'Inter Tight', sans-serif;
  font-size: 1.3rem; font-weight: 900; letter-spacing: -.02em;
  color: #fff;
  border: 2px solid rgba(255,255,255,.1);
  position: relative;
}
.tf-team-avatar::after {
  content: '';
  position: absolute; inset: -4px; border-radius: 50%;
  border: 1px solid rgba(255,255,255,.07);
}
.tf-team-name {
  font-family: 'Inter Tight', sans-serif;
  font-size: .98rem; font-weight: 900;
  color: var(--tf-text); margin: 0 0 4px; letter-spacing: -.02em;
}
.tf-team-role {
  font-size: .78rem; color: var(--tf-muted); font-weight: 600;
  margin: 0 0 10px; letter-spacing: .03em;
}
.tf-team-bio {
  font-size: .83rem; color: #475569; line-height: 1.65;
  margin: 0 0 18px;
}
.tf-team-links { display: flex; justify-content: center; gap: 8px; }
.tf-team-link {
  width: 32px; height: 32px; border-radius: 9px;
  background: rgba(255,255,255,.04);
  border: 1px solid var(--tf-border);
  display: flex; align-items: center; justify-content: center;
  color: var(--tf-muted); transition: background .2s, color .2s, border-color .2s;
}
.tf-team-link:hover {
  background: rgba(255,94,46,.12);
  color: var(--tf-accent); border-color: rgba(255,94,46,.3);
}
.tf-team-link svg { display: block; }

/* ════════════════════════════════════════════════════════════════════
   6. CLIENT LOGO STRIP
   ════════════════════════════════════════════════════════════════════ */
.tf-clients {
  background: var(--tf-bg-2);
  border-top: 1px solid var(--tf-border);
  border-bottom: 1px solid var(--tf-border);
  padding: 72px 0;
  overflow: hidden;
}
.tf-clients__hd {
  text-align: center; margin-bottom: 44px;
}
.tf-clients__hd p {
  font-size: .82rem; font-weight: 700; letter-spacing: .12em;
  text-transform: uppercase; color: var(--tf-muted);
}
.tf-clients__track-wrap {
  overflow: hidden; mask-image: linear-gradient(to right, transparent, black 12%, black 88%, transparent);
  -webkit-mask-image: linear-gradient(to right, transparent, black 12%, black 88%, transparent);
}
.tf-clients__track {
  display: flex; gap: 16px;
  width: max-content;
  animation: tf-logo-scroll 22s linear infinite;
}
.tf-clients__track:hover { animation-play-state: paused; }
.tf-logo-chip {
  flex: none;
  display: flex; align-items: center; gap: 10px;
  padding: 14px 22px; border-radius: 14px;
  background: rgba(255,255,255,.03);
  border: 1px solid var(--tf-border);
  transition: border-color .2s, background .2s;
  white-space: nowrap;
}
.tf-logo-chip:hover { background: rgba(255,255,255,.06); border-color: rgba(255,255,255,.12); }
.tf-logo-chip__badge {
  width: 34px; height: 34px; border-radius: 9px;
  display: flex; align-items: center; justify-content: center;
  font-family: 'Inter Tight', sans-serif;
  font-size: .7rem; font-weight: 900; letter-spacing: .04em;
  color: #fff;
}
.tf-logo-chip__name {
  font-size: .82rem; font-weight: 700; color: #94a3b8; letter-spacing: .02em;
}

/* ════════════════════════════════════════════════════════════════════
   7. AWARDS
   ════════════════════════════════════════════════════════════════════ */
.tf-awards { background: var(--tf-bg); }
.tf-awards__grid {
  display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px;
}
.tf-award-card {
  background: rgba(255,255,255,.025);
  border: 1px solid var(--tf-border);
  border-radius: 22px; padding: 40px 32px;
  display: flex; flex-direction: column; gap: 18px;
  transition: transform .3s, box-shadow .3s, border-color .3s;
  position: relative; overflow: hidden;
}
.tf-award-card::before {
  content: '';
  position: absolute; top: 0; left: 0; right: 0; height: 2px;
  background: linear-gradient(90deg, transparent, var(--tf-accent), transparent);
  opacity: 0; transition: opacity .3s;
}
.tf-award-card:hover { transform: translateY(-5px); box-shadow: 0 28px 64px rgba(0,0,0,.3); border-color: rgba(255,94,46,.18); }
.tf-award-card:hover::before { opacity: 1; }
.tf-award-icon {
  width: 52px; height: 52px; border-radius: 14px;
  display: flex; align-items: center; justify-content: center;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.2);
  color: var(--tf-accent);
}
.tf-award-icon svg { display: block; }
.tf-award-name {
  font-family: 'Inter Tight', sans-serif;
  font-size: 1.1rem; font-weight: 900;
  color: var(--tf-text); letter-spacing: -.025em; line-height: 1.2;
  margin: 0;
}
.tf-award-meta {
  display: flex; align-items: center; gap: 10px; margin-top: auto;
}
.tf-award-year {
  font-family: 'Inter Tight', sans-serif;
  font-size: .75rem; font-weight: 800;
  color: var(--tf-accent); letter-spacing: .1em; text-transform: uppercase;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.2);
  padding: 3px 10px; border-radius: 100px;
}
.tf-award-body { font-size: .82rem; color: var(--tf-muted); font-weight: 600; }

/* ════════════════════════════════════════════════════════════════════
   8. CTA BANNER
   ════════════════════════════════════════════════════════════════════ */
.tf-cta {
  background: var(--tf-bg-2);
  border-top: 1px solid var(--tf-border);
  padding: 120px 24px;
  text-align: center;
  position: relative; overflow: hidden;
}
/* Mesh gradient background */
.tf-cta::before {
  content: '';
  position: absolute; inset: 0;
  background:
    radial-gradient(ellipse 60% 60% at 20% 50%, rgba(255,94,46,.08) 0%, transparent 60%),
    radial-gradient(ellipse 50% 70% at 80% 50%, rgba(139,92,246,.07) 0%, transparent 60%),
    radial-gradient(ellipse 40% 40% at 50% 100%, rgba(59,130,246,.06) 0%, transparent 60%);
  pointer-events: none;
}
.tf-cta::after {
  content: '';
  position: absolute; inset: 0;
  background-image: radial-gradient(rgba(255,255,255,.018) 1px, transparent 1px);
  background-size: 32px 32px;
  pointer-events: none;
}
.tf-cta__inner { position: relative; z-index: 1; max-width: 700px; margin: 0 auto; }
.tf-cta__inner h2 {
  font-family: 'Inter Tight', sans-serif;
  font-size: clamp(2rem, 4vw, 3.4rem);
  font-weight: 900; letter-spacing: -.05em; line-height: 1.08;
  color: var(--tf-text); margin: 0 0 18px;
}
.tf-cta__inner p {
  font-size: 1.05rem; color: #94a3b8; line-height: 1.75;
  max-width: 500px; margin: 0 auto 44px;
}
.tf-cta__btns { display: flex; justify-content: center; align-items: center; gap: 14px; flex-wrap: wrap; }
.tf-btn-primary {
  display: inline-flex; align-items: center; gap: 10px;
  background: var(--tf-accent); color: #fff;
  font-size: .95rem; font-weight: 800; letter-spacing: .015em;
  padding: 17px 38px; border-radius: 100px;
  box-shadow: 0 8px 36px rgba(255,94,46,.38);
  transition: transform .2s, box-shadow .2s;
}
.tf-btn-primary:hover { transform: translateY(-3px); box-shadow: 0 16px 52px rgba(255,94,46,.48); color: #fff; }
.tf-btn-secondary {
  display: inline-flex; align-items: center; gap: 8px;
  border: 1.5px solid rgba(255,255,255,.13); color: #94a3b8;
  font-size: .9rem; font-weight: 700;
  padding: 16px 32px; border-radius: 100px;
  transition: border-color .2s, color .2s;
}
.tf-btn-secondary:hover { border-color: rgba(255,94,46,.45); color: var(--tf-accent); }

/* ════════════════════════════════════════════════════════════════════
   RESPONSIVE
   ════════════════════════════════════════════════════════════════════ */
@media (max-width: 1024px) {
  .tf-statsbar__grid   { grid-template-columns: repeat(2, 1fr); }
  .tf-statsbar__item:nth-child(2) { border-right: none; }
  .tf-statsbar__item:nth-child(3) { border-top: 1px solid var(--tf-border); }
  .tf-statsbar__item:nth-child(4) { border-top: 1px solid var(--tf-border); }
  .tf-story__grid      { grid-template-columns: 1fr; gap: 56px; }
  .tf-values__grid     { grid-template-columns: repeat(2, 1fr); }
  .tf-team__grid       { grid-template-columns: repeat(2, 1fr); }
  .tf-awards__grid     { grid-template-columns: 1fr; max-width: 520px; margin: 0 auto; }
}
@media (max-width: 768px) {
  .tf-sec { padding: 80px 0; }
  .tf-hero { min-height: auto; padding: 130px 20px 90px; }
  .tf-hero__stats { gap: 0; }
  .tf-hero__stat  { padding: 16px 22px; }
  .tf-statsbar__grid   { grid-template-columns: repeat(2, 1fr); }
  .tf-values__grid     { grid-template-columns: 1fr; }
  .tf-team__grid       { grid-template-columns: repeat(2, 1fr); }
  .tf-awards__grid     { grid-template-columns: 1fr; max-width: 100%; }
}
@media (max-width: 480px) {
  .tf-hero__stats { flex-direction: column; gap: 0; }
  .tf-hero__stat  { border-left: none; border-top: 1px solid rgba(255,255,255,.07); width: 100%; }
  .tf-hero__stat:first-child { border-top: none; }
  .tf-statsbar__grid   { grid-template-columns: 1fr; }
  .tf-statsbar__item   { border-right: none !important; border-top: 1px solid var(--tf-border); }
  .tf-statsbar__item:first-child { border-top: none; }
  .tf-team__grid       { grid-template-columns: 1fr; }
}
</style>

<?php get_header(); ?>

<main id="tf-main" class="tf-about" role="main">

<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

<!-- ════════════════════════════════════════════════════════════════
     1. PAGE HERO
     ════════════════════════════════════════════════════════════════ -->
<section class="tf-hero" aria-labelledby="tf-hero-h1">
  <div class="tf-hero__orbs" aria-hidden="true">
    <div class="tf-hero__orb tf-hero__orb--1"></div>
    <div class="tf-hero__orb tf-hero__orb--2"></div>
    <div class="tf-hero__orb tf-hero__orb--3"></div>
  </div>

  <div class="tf-hero__inner">
    <div class="tf-pill tf-pill--accent" aria-label="<?php esc_attr_e( 'About Us', 'themeflex' ); ?>">
      <?php echo tf_icon_get( 'rocket', 14 ); ?>
      <?php esc_html_e( 'About Us', 'themeflex' ); ?>
    </div>

    <h1 class="tf-hero__h1" id="tf-hero-h1">
      <?php esc_html_e( 'We build digital experiences', 'themeflex' ); ?><br>
      <span class="tf-gtext"><?php esc_html_e( 'that move people', 'themeflex' ); ?></span>
    </h1>

    <p class="tf-hero__sub">
      <?php esc_html_e( 'ThemeFlex is a boutique digital studio obsessed with craft, clarity, and performance.', 'themeflex' ); ?><br>
      <?php esc_html_e( 'We design and build WordPress products that are as fast as they are beautiful.', 'themeflex' ); ?>
    </p>

    <div class="tf-hero__stats" role="list" aria-label="<?php esc_attr_e( 'Key facts', 'themeflex' ); ?>">
      <div class="tf-hero__stat" role="listitem">
        <span class="tf-hero__stat-num"><?php esc_html_e( 'Founded 2015', 'themeflex' ); ?></span>
        <span class="tf-hero__stat-lbl"><?php esc_html_e( 'Est.', 'themeflex' ); ?></span>
      </div>
      <div class="tf-hero__stat" role="listitem">
        <span class="tf-hero__stat-num"><?php esc_html_e( '120+', 'themeflex' ); ?></span>
        <span class="tf-hero__stat-lbl"><?php esc_html_e( 'Projects', 'themeflex' ); ?></span>
      </div>
      <div class="tf-hero__stat" role="listitem">
        <span class="tf-hero__stat-num"><?php esc_html_e( '98%', 'themeflex' ); ?></span>
        <span class="tf-hero__stat-lbl"><?php esc_html_e( 'Satisfaction', 'themeflex' ); ?></span>
      </div>
    </div>
  </div>

  <div class="tf-hero__wave" aria-hidden="true">
    <svg viewBox="0 0 1440 64" preserveAspectRatio="none"
         xmlns="http://www.w3.org/2000/svg"
         style="display:block;width:100%;height:64px">
      <path d="M0,40 C240,70 480,10 720,38 C960,66 1200,12 1440,36 L1440,64 L0,64 Z"
            fill="#0a0f1e"/>
    </svg>
  </div>
</section>


<!-- ════════════════════════════════════════════════════════════════
     2. ANIMATED STATS BAR
     ════════════════════════════════════════════════════════════════ -->
<section class="tf-statsbar" aria-label="<?php esc_attr_e( 'Company statistics', 'themeflex' ); ?>">
  <div class="tf-wrap">
    <div class="tf-statsbar__grid">

      <div class="tf-statsbar__item" style="--sb-color:#ff5e2e">
        <div class="tf-statsbar__icon" aria-hidden="true">
          <?php echo tf_icon_get( 'briefcase', 20 ); ?>
        </div>
        <div class="tf-statsbar__num">
          <span class="tf-counter" data-target="120" data-suffix="+">0</span><span class="tf-statsbar__suffix">+</span>
        </div>
        <div class="tf-statsbar__lbl"><?php esc_html_e( 'Projects Delivered', 'themeflex' ); ?></div>
      </div>

      <div class="tf-statsbar__item" style="--sb-color:#8b5cf6">
        <div class="tf-statsbar__icon" aria-hidden="true">
          <?php echo tf_icon_get( 'globe', 20 ); ?>
        </div>
        <div class="tf-statsbar__num">
          <span class="tf-counter" data-target="15">0</span><span class="tf-statsbar__suffix" style="color:#8b5cf6">+</span>
        </div>
        <div class="tf-statsbar__lbl"><?php esc_html_e( 'Industries Served', 'themeflex' ); ?></div>
      </div>

      <div class="tf-statsbar__item" style="--sb-color:#10b981">
        <div class="tf-statsbar__icon" aria-hidden="true">
          <?php echo tf_icon_get( 'trending-up', 20 ); ?>
        </div>
        <div class="tf-statsbar__num">
          <span class="tf-counter" data-target="98">0</span><span class="tf-statsbar__suffix" style="color:#10b981">%</span>
        </div>
        <div class="tf-statsbar__lbl"><?php esc_html_e( 'Client Satisfaction', 'themeflex' ); ?></div>
      </div>

      <div class="tf-statsbar__item" style="--sb-color:#f59e0b">
        <div class="tf-statsbar__icon" aria-hidden="true">
          <?php echo tf_icon_get( 'award', 20 ); ?>
        </div>
        <div class="tf-statsbar__num">
          <span class="tf-counter" data-target="8">0</span><span class="tf-statsbar__suffix" style="color:#f59e0b"> <?php esc_html_e( 'Yrs', 'themeflex' ); ?></span>
        </div>
        <div class="tf-statsbar__lbl"><?php esc_html_e( 'Years Experience', 'themeflex' ); ?></div>
      </div>

    </div>
  </div>
</section>


<!-- ════════════════════════════════════════════════════════════════
     3. OUR STORY
     ════════════════════════════════════════════════════════════════ -->
<section class="tf-story tf-sec" aria-labelledby="tf-story-h2">
  <div class="tf-wrap">
    <div class="tf-story__grid">

      <!-- Left: text -->
      <div class="tf-story__text">
        <div class="tf-pill tf-pill--violet" aria-label="<?php esc_attr_e( 'Our Story', 'themeflex' ); ?>">
          <?php echo tf_icon_get( 'milestone', 14 ); ?>
          <?php esc_html_e( 'Our Story', 'themeflex' ); ?>
        </div>
        <h2 id="tf-story-h2">
          <?php esc_html_e( 'From a small studio to a global team', 'themeflex' ); ?>
        </h2>
        <p>
          <?php esc_html_e( 'ThemeFlex was born in 2015 from a single frustration: the web had grown powerful but bloated. We believed great design and blazing performance were not trade-offs — they were the baseline. With two laptops and relentless conviction, we shipped our first theme and never looked back.', 'themeflex' ); ?>
        </p>
        <p>
          <?php esc_html_e( 'By 2018 we had grown into a full-service studio, taking on clients who needed more than a template — they needed a strategic partner. From e-commerce re-platforms to venture-backed SaaS front-ends, we refined a process built around speed, clarity, and zero technical debt.', 'themeflex' ); ?>
        </p>
        <p>
          <?php esc_html_e( 'Today our team spans three continents and fourteen disciplines. We have delivered more than 120 projects in 15+ industries, earned a 98% satisfaction rate, and continue to push the boundaries of what a WordPress-powered product can achieve.', 'themeflex' ); ?>
        </p>
      </div>

      <!-- Right: timeline -->
      <div>
        <div class="tf-pill tf-pill--blue" aria-label="<?php esc_attr_e( 'Milestones', 'themeflex' ); ?>" style="margin-bottom:36px">
          <?php echo tf_icon_get( 'layers', 14 ); ?>
          <?php esc_html_e( 'Milestones', 'themeflex' ); ?>
        </div>
        <div class="tf-timeline" role="list" aria-label="<?php esc_attr_e( 'Company milestones', 'themeflex' ); ?>">

          <?php
          $milestones = [
            [
              'year'  => esc_html__( '2015', 'themeflex' ),
              'title' => esc_html__( 'Founded in Berlin', 'themeflex' ),
              'desc'  => esc_html__( 'Launched with two people and one idea: dark, fast, beautiful WordPress themes built with obsessive care.', 'themeflex' ),
              'color' => '#3b82f6',
            ],
            [
              'year'  => esc_html__( '2018', 'themeflex' ),
              'title' => esc_html__( 'First 50 Clients', 'themeflex' ),
              'desc'  => esc_html__( 'Hit 50 active clients and expanded our team. Launched our first Elementor widget library, still powering hundreds of sites today.', 'themeflex' ),
              'color' => '#8b5cf6',
            ],
            [
              'year'  => esc_html__( '2021', 'themeflex' ),
              'title' => esc_html__( 'Expanded to 12 Countries', 'themeflex' ),
              'desc'  => esc_html__( 'Went fully remote-first and scaled globally. Onboarded talent across Europe, North America, and Asia — 12 countries, one culture.', 'themeflex' ),
              'color' => '#ff5e2e',
            ],
            [
              'year'  => esc_html__( '2024', 'themeflex' ),
              'title' => esc_html__( 'Launched ThemeFlex', 'themeflex' ),
              'desc'  => esc_html__( 'Released ThemeFlex — our next-generation theme framework. The product of eight years of client feedback, obsessive iteration, and genuine craftsmanship.', 'themeflex' ),
              'color' => '#10b981',
            ],
          ];
          foreach ( $milestones as $ms ) : ?>
          <div class="tf-tl-item" style="--tl-c:<?php echo esc_attr( $ms['color'] ); ?>" role="listitem">
            <div class="tf-tl-year"><?php echo $ms['year']; ?></div>
            <h3 class="tf-tl-title"><?php echo $ms['title']; ?></h3>
            <p class="tf-tl-desc"><?php echo $ms['desc']; ?></p>
          </div>
          <?php endforeach; ?>

        </div>
      </div>

    </div>
  </div>
</section>


<!-- ════════════════════════════════════════════════════════════════
     4. VALUES GRID
     ════════════════════════════════════════════════════════════════ -->
<section class="tf-values tf-sec" aria-labelledby="tf-values-h2">
  <div class="tf-wrap">

    <div class="tf-sec-hd">
      <div class="tf-pill tf-pill--accent" aria-label="<?php esc_attr_e( 'Core Values', 'themeflex' ); ?>">
        <?php echo tf_icon_get( 'sparkles', 14 ); ?>
        <?php esc_html_e( 'Core Values', 'themeflex' ); ?>
      </div>
      <h2 id="tf-values-h2"><?php esc_html_e( 'What we stand for', 'themeflex' ); ?></h2>
      <p><?php esc_html_e( 'Six principles that guide every decision, every pixel, and every line of code we ship.', 'themeflex' ); ?></p>
    </div>

    <div class="tf-values__grid">

      <?php
      $values = [
        [
          'icon'  => 'palette',
          'name'  => esc_html__( 'Craft', 'themeflex' ),
          'desc'  => esc_html__( 'We treat UI as a craft. Every spacing decision, every transition, every micro-interaction is deliberate and refined until it feels inevitable.', 'themeflex' ),
          'color' => '#ff5e2e',
          'bg'    => 'rgba(255,94,46,.12)',
        ],
        [
          'icon'  => 'shield-check',
          'name'  => esc_html__( 'Transparency', 'themeflex' ),
          'desc'  => esc_html__( 'No hidden fees, no surprise scope. We communicate blockers early, share progress openly, and treat your budget like our own.', 'themeflex' ),
          'color' => '#3b82f6',
          'bg'    => 'rgba(59,130,246,.12)',
        ],
        [
          'icon'  => 'zap',
          'name'  => esc_html__( 'Innovation', 'themeflex' ),
          'desc'  => esc_html__( 'We stay ahead of the curve — from cutting-edge CSS features to emerging WordPress APIs — so our clients always ship with the best tools available.', 'themeflex' ),
          'color' => '#f59e0b',
          'bg'    => 'rgba(245,158,11,.12)',
        ],
        [
          'icon'  => 'heart',
          'name'  => esc_html__( 'People First', 'themeflex' ),
          'desc'  => esc_html__( 'Great products are built by fulfilled people. We invest in our team\'s growth, wellbeing, and autonomy — and that energy flows directly to clients.', 'themeflex' ),
          'color' => '#ec4899',
          'bg'    => 'rgba(236,72,153,.12)',
        ],
        [
          'icon'  => 'award',
          'name'  => esc_html__( 'Excellence', 'themeflex' ),
          'desc'  => esc_html__( 'We refuse to ship something we are not proud of. 90+ PageSpeed is our floor, not our ceiling. Documentation is as important as the code itself.', 'themeflex' ),
          'color' => '#8b5cf6',
          'bg'    => 'rgba(139,92,246,.12)',
        ],
        [
          'icon'  => 'trending-up',
          'name'  => esc_html__( 'Impact', 'themeflex' ),
          'desc'  => esc_html__( 'We measure success in business outcomes, not deliverables. Every project ends with a retrospective on the actual results it drove for the client.', 'themeflex' ),
          'color' => '#10b981',
          'bg'    => 'rgba(16,185,129,.12)',
        ],
      ];
      foreach ( $values as $val ) : ?>
      <div class="tf-val-card"
           style="--vc-color:<?php echo esc_attr( $val['bg'] ); ?>"
           role="article">
        <div class="tf-val-icon"
             style="background:<?php echo esc_attr( $val['bg'] ); ?>;color:<?php echo esc_attr( $val['color'] ); ?>"
             aria-hidden="true">
          <?php echo tf_icon_get( $val['icon'], 24 ); ?>
        </div>
        <h3 class="tf-val-name"><?php echo $val['name']; ?></h3>
        <p class="tf-val-desc"><?php echo $val['desc']; ?></p>
      </div>
      <?php endforeach; ?>

    </div>
  </div>
</section>


<!-- ════════════════════════════════════════════════════════════════
     5. TEAM
     ════════════════════════════════════════════════════════════════ -->
<section class="tf-team tf-sec" aria-labelledby="tf-team-h2">
  <div class="tf-wrap">

    <div class="tf-sec-hd">
      <div class="tf-pill tf-pill--green" aria-label="<?php esc_attr_e( 'The Team', 'themeflex' ); ?>">
        <?php echo tf_icon_get( 'users', 14 ); ?>
        <?php esc_html_e( 'The Team', 'themeflex' ); ?>
      </div>
      <h2 id="tf-team-h2"><?php esc_html_e( 'The people behind the pixels', 'themeflex' ); ?></h2>
      <p><?php esc_html_e( 'Six core leads, dozens of collaborators, one shared conviction: design and engineering are not separate disciplines.', 'themeflex' ); ?></p>
    </div>

    <div class="tf-team__grid">

      <?php
      $team = [
        [
          'initials' => 'AM',
          'name'     => esc_html__( 'Alex M.', 'themeflex' ),
          'role'     => esc_html__( 'CEO & Co-founder', 'themeflex' ),
          'bio'      => esc_html__( 'Sets vision, obsesses over performance metrics, and still reviews every PR before shipping to production.', 'themeflex' ),
          'grad'     => 'linear-gradient(135deg, #ff5e2e 0%, #c2410c 100%)',
          'linkedin' => '#',
        ],
        [
          'initials' => 'SK',
          'name'     => esc_html__( 'Sara K.', 'themeflex' ),
          'role'     => esc_html__( 'Design Lead', 'themeflex' ),
          'bio'      => esc_html__( 'Turns briefs into systems. Keeps the design language coherent across every touchpoint in every project.', 'themeflex' ),
          'grad'     => 'linear-gradient(135deg, #8b5cf6 0%, #6d28d9 100%)',
          'linkedin' => '#',
        ],
        [
          'initials' => 'TR',
          'name'     => esc_html__( 'Tom R.', 'themeflex' ),
          'role'     => esc_html__( 'Dev Lead', 'themeflex' ),
          'bio'      => esc_html__( 'Architected the ThemeFlex core. Fluent in PHP, JS, and the dark arts of WordPress query optimisation.', 'themeflex' ),
          'grad'     => 'linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%)',
          'linkedin' => '#',
        ],
        [
          'initials' => 'NP',
          'name'     => esc_html__( 'Nina P.', 'themeflex' ),
          'role'     => esc_html__( 'Head of Strategy', 'themeflex' ),
          'bio'      => esc_html__( 'Runs discovery, competitive research, and makes sure every project has a north-star metric before a pixel is drawn.', 'themeflex' ),
          'grad'     => 'linear-gradient(135deg, #10b981 0%, #047857 100%)',
          'linkedin' => '#',
        ],
        [
          'initials' => 'KL',
          'name'     => esc_html__( 'Kai L.', 'themeflex' ),
          'role'     => esc_html__( 'Marketing Lead', 'themeflex' ),
          'bio'      => esc_html__( 'Grows the ThemeFlex community, runs product launches, and writes copy that converts without sounding like a robot.', 'themeflex' ),
          'grad'     => 'linear-gradient(135deg, #f59e0b 0%, #b45309 100%)',
          'linkedin' => '#',
        ],
        [
          'initials' => 'JW',
          'name'     => esc_html__( 'Jess W.', 'themeflex' ),
          'role'     => esc_html__( 'Head of Operations', 'themeflex' ),
          'bio'      => esc_html__( 'Keeps 120+ projects on-time and on-budget. The secret engine that makes everything else possible.', 'themeflex' ),
          'grad'     => 'linear-gradient(135deg, #ec4899 0%, #9d174d 100%)',
          'linkedin' => '#',
        ],
      ];

      // LinkedIn SVG path
      $li_icon = '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>';

      foreach ( $team as $member ) : ?>
      <div class="tf-team-card" role="article">
        <div class="tf-team-avatar"
             style="background:<?php echo esc_attr( $member['grad'] ); ?>"
             aria-label="<?php echo esc_attr( $member['name'] ); ?>">
          <?php echo esc_html( $member['initials'] ); ?>
        </div>
        <div class="tf-team-name"><?php echo $member['name']; ?></div>
        <div class="tf-team-role"><?php echo $member['role']; ?></div>
        <p class="tf-team-bio"><?php echo $member['bio']; ?></p>
        <div class="tf-team-links">
          <a href="<?php echo esc_url( $member['linkedin'] ); ?>"
             class="tf-team-link"
             aria-label="<?php echo esc_attr( sprintf( __( '%s on LinkedIn', 'themeflex' ), $member['name'] ) ); ?>">
            <?php echo $li_icon; ?>
          </a>
        </div>
      </div>
      <?php endforeach; ?>

    </div>
  </div>
</section>


<!-- ════════════════════════════════════════════════════════════════
     6. CLIENT LOGO STRIP
     ════════════════════════════════════════════════════════════════ -->
<section class="tf-clients" aria-label="<?php esc_attr_e( 'Trusted clients', 'themeflex' ); ?>">
  <div class="tf-clients__hd">
    <p><?php esc_html_e( 'Trusted by 120+ clients worldwide', 'themeflex' ); ?></p>
  </div>

  <?php
  $logos = [
    [ 'initials' => 'AC', 'name' => esc_html__( 'Acme Corp', 'themeflex' ),    'bg' => '#1e40af' ],
    [ 'initials' => 'ST', 'name' => esc_html__( 'Startup Co', 'themeflex' ),   'bg' => '#7c3aed' ],
    [ 'initials' => 'MB', 'name' => esc_html__( 'MegaBrand', 'themeflex' ),    'bg' => '#b91c1c' ],
    [ 'initials' => 'TH', 'name' => esc_html__( 'TechHub', 'themeflex' ),      'bg' => '#065f46' ],
    [ 'initials' => 'NV', 'name' => esc_html__( 'Nova Inc', 'themeflex' ),     'bg' => '#92400e' ],
    [ 'initials' => 'PL', 'name' => esc_html__( 'Pulse Lab', 'themeflex' ),    'bg' => '#831843' ],
    [ 'initials' => 'DG', 'name' => esc_html__( 'Digital Go', 'themeflex' ),   'bg' => '#164e63' ],
    [ 'initials' => 'FX', 'name' => esc_html__( 'FlexCorp', 'themeflex' ),     'bg' => '#3f3f46' ],
  ];

  // Duplicate logos for infinite scroll
  $logos_doubled = array_merge( $logos, $logos );
  ?>
  <div class="tf-clients__track-wrap">
    <div class="tf-clients__track" aria-hidden="true">
      <?php foreach ( $logos_doubled as $logo ) : ?>
      <div class="tf-logo-chip">
        <div class="tf-logo-chip__badge"
             style="background:<?php echo esc_attr( $logo['bg'] ); ?>">
          <?php echo esc_html( $logo['initials'] ); ?>
        </div>
        <span class="tf-logo-chip__name"><?php echo $logo['name']; ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>


<!-- ════════════════════════════════════════════════════════════════
     7. AWARDS & RECOGNITION
     ════════════════════════════════════════════════════════════════ -->
<section class="tf-awards tf-sec" aria-labelledby="tf-awards-h2">
  <div class="tf-wrap">

    <div class="tf-sec-hd">
      <div class="tf-pill tf-pill--gold" aria-label="<?php esc_attr_e( 'Awards', 'themeflex' ); ?>">
        <?php echo tf_icon_get( 'award', 14 ); ?>
        <?php esc_html_e( 'Awards & Recognition', 'themeflex' ); ?>
      </div>
      <h2 id="tf-awards-h2"><?php esc_html_e( 'Recognised for excellence', 'themeflex' ); ?></h2>
      <p><?php esc_html_e( 'Independent recognition that validates the work and the way we work.', 'themeflex' ); ?></p>
    </div>

    <div class="tf-awards__grid">

      <?php
      $awards = [
        [
          'name' => esc_html__( 'Best Design Theme 2024', 'themeflex' ),
          'year' => '2024',
          'body' => esc_html__( 'ThemeForest Choice Award', 'themeflex' ),
        ],
        [
          'name' => esc_html__( 'Top Performer 2023', 'themeflex' ),
          'year' => '2023',
          'body' => esc_html__( 'Envato Community', 'themeflex' ),
        ],
        [
          'name' => esc_html__( 'Innovation Award 2022', 'themeflex' ),
          'year' => '2022',
          'body' => esc_html__( 'WP Awards', 'themeflex' ),
        ],
      ];
      foreach ( $awards as $award ) : ?>
      <div class="tf-award-card" role="article">
        <div class="tf-award-icon" aria-hidden="true">
          <?php echo tf_icon_get( 'award', 24 ); ?>
        </div>
        <h3 class="tf-award-name"><?php echo $award['name']; ?></h3>
        <div class="tf-award-meta">
          <span class="tf-award-year"><?php echo esc_html( $award['year'] ); ?></span>
          <span class="tf-award-body"><?php echo $award['body']; ?></span>
        </div>
      </div>
      <?php endforeach; ?>

    </div>
  </div>
</section>


<!-- ════════════════════════════════════════════════════════════════
     8. CTA BANNER
     ════════════════════════════════════════════════════════════════ -->
<section class="tf-cta" aria-labelledby="tf-cta-h2">
  <div class="tf-cta__inner">
    <div class="tf-pill tf-pill--accent" style="margin-bottom:28px"
         aria-label="<?php esc_attr_e( "Let's work together", 'themeflex' ); ?>">
      <?php echo tf_icon_get( 'sparkles', 14 ); ?>
      <?php esc_html_e( "Let's work together", 'themeflex' ); ?>
    </div>
    <h2 id="tf-cta-h2">
      <?php esc_html_e( 'Ready to build something', 'themeflex' ); ?><br>
      <span class="tf-gtext"><?php esc_html_e( 'remarkable?', 'themeflex' ); ?></span>
    </h2>
    <p>
      <?php esc_html_e( 'Book a free 30-minute discovery call. No pitch, no pressure — just an honest conversation about what you need and whether we are the right fit to build it.', 'themeflex' ); ?>
    </p>
    <div class="tf-cta__btns">
      <a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"
         class="tf-btn-primary">
        <?php echo tf_icon_get( 'rocket', 16 ); ?>
        <?php esc_html_e( 'Start a Project', 'themeflex' ); ?>
      </a>
      <a href="<?php echo esc_url( home_url( '/portfolio/' ) ); ?>"
         class="tf-btn-secondary">
        <?php echo tf_icon_get( 'layers', 16 ); ?>
        <?php esc_html_e( 'View Our Work', 'themeflex' ); ?>
      </a>
    </div>
  </div>
</section>


<?php endwhile; endif; ?>

</main><!-- /#tf-main -->

<script>
/* ── ThemeFlex About Page — Vanilla JS ── */
(function () {
  'use strict';

  var IO = ('IntersectionObserver' in window);

  /* ──────────────────────────────────────────────────────────────
     Counter animation
  ────────────────────────────────────────────────────────────── */
  function animateCounter(el) {
    var target   = parseInt(el.getAttribute('data-target'), 10);
    var duration = 1800;
    var start    = null;
    var easeOut  = function (t) { return 1 - Math.pow(1 - t, 3); };

    requestAnimationFrame(function tick(ts) {
      if (!start) start = ts;
      var elapsed  = ts - start;
      var progress = Math.min(elapsed / duration, 1);
      el.textContent = Math.round(easeOut(progress) * target);
      if (progress < 1) {
        requestAnimationFrame(tick);
      } else {
        el.textContent = target;
      }
    });
  }

  var counters    = document.querySelectorAll('.tf-counter');
  var countersFired = false;

  if (IO && counters.length) {
    var statsBar = document.querySelector('.tf-statsbar');
    var obsStats = new IntersectionObserver(function (entries) {
      if (countersFired) return;
      if (entries[0].isIntersecting) {
        countersFired = true;
        counters.forEach(function (c) { animateCounter(c); });
        obsStats.disconnect();
      }
    }, { threshold: 0.35 });
    if (statsBar) obsStats.observe(statsBar);
  } else {
    /* Fallback: show final values immediately */
    counters.forEach(function (c) {
      c.textContent = c.getAttribute('data-target');
    });
  }

  /* ──────────────────────────────────────────────────────────────
     Timeline reveal
  ────────────────────────────────────────────────────────────── */
  var tlItems = document.querySelectorAll('.tf-tl-item');

  if (IO && tlItems.length) {
    var obsTL = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          obsTL.unobserve(entry.target);
        }
      });
    }, { threshold: 0.18 });
    tlItems.forEach(function (el) { obsTL.observe(el); });
  } else {
    tlItems.forEach(function (el) { el.classList.add('is-visible'); });
  }

  /* ──────────────────────────────────────────────────────────────
     Team cards reveal
  ────────────────────────────────────────────────────────────── */
  var teamCards = document.querySelectorAll('.tf-team-card');

  if (IO && teamCards.length) {
    var obsTeam = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          obsTeam.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });
    teamCards.forEach(function (el) { obsTeam.observe(el); });
  } else {
    teamCards.forEach(function (el) { el.classList.add('is-visible'); });
  }

})();
</script>

<?php get_footer(); ?>
