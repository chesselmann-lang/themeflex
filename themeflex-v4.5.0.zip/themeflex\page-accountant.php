<?php
/**
 * Template Name: TF — Accounting & Financial Services
 *
 * Halcyon Partners — Chartered Accountants & Financial Advisors
 * City of London, established 1994
 *
 * @package ThemeFlex
 */

srand(crc32(get_the_permalink()));
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,300;0,700;1,300&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
/* ============================================================
   HALCYON PARTNERS — CSS CUSTOM PROPERTIES
   ============================================================ */
:root {
  --ac-forest:    #1A2E1A;   /* deep forest green          */
  --ac-forest-md: #223A22;   /* mid forest                 */
  --ac-forest-lt: #2E5030;   /* lighter forest             */
  --ac-gold:      #B8962A;   /* warm gold                  */
  --ac-gold-lt:   #D4B050;   /* light gold                 */
  --ac-cream:     #F8F5EE;   /* warm cream                 */
  --ac-ivory:     #F0ECE2;   /* antique ivory              */
  --ac-stone:     #7A7060;   /* warm stone                 */
  --ac-charcoal:  #1C1C1C;   /* near-black charcoal        */
  --ac-slate:     #4A5568;
  --ac-white:     #FFFFFF;

  --ac-serif: 'Merriweather', Georgia, serif;
  --ac-sans:  'Inter', system-ui, sans-serif;

  --ac-radius: 3px;
  --ac-shadow: 0 10px 40px rgba(26,46,26,.14);
}

/* ============================================================
   RESET & BASE
   ============================================================ */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; }
body.page-template-page-accountant {
  font-family: var(--ac-sans);
  background: var(--ac-cream);
  color: var(--ac-charcoal);
  line-height: 1.7;
  overflow-x: hidden;
}
.ac-container { max-width: 1200px; margin: 0 auto; padding: 0 36px; }
.ac-section { padding: 96px 0; }
.ac-tag {
  display: inline-block;
  font-size: .7rem;
  font-weight: 600;
  letter-spacing: .22em;
  text-transform: uppercase;
  color: var(--ac-gold);
  margin-bottom: 14px;
}
.ac-heading {
  font-family: var(--ac-serif);
  font-size: clamp(1.9rem, 3.8vw, 3rem);
  font-weight: 700;
  line-height: 1.25;
  color: var(--ac-forest);
}
.ac-heading em { font-style: italic; color: var(--ac-gold); font-weight: 300; }
.ac-lead {
  font-size: .98rem;
  color: var(--ac-stone);
  line-height: 1.85;
  max-width: 580px;
}
.ac-btn {
  display: inline-block;
  padding: 13px 32px;
  font-family: var(--ac-sans);
  font-size: .8rem;
  font-weight: 600;
  letter-spacing: .1em;
  text-transform: uppercase;
  text-decoration: none;
  border-radius: var(--ac-radius);
  transition: all .25s ease;
  cursor: pointer;
  border: none;
}
.ac-btn-primary {
  background: var(--ac-forest);
  color: var(--ac-cream);
}
.ac-btn-primary:hover { background: var(--ac-forest-lt); transform: translateY(-2px); box-shadow: 0 6px 24px rgba(26,46,26,.3); }
.ac-btn-gold {
  background: var(--ac-gold);
  color: var(--ac-forest);
}
.ac-btn-gold:hover { background: var(--ac-gold-lt); transform: translateY(-2px); }
.ac-btn-ghost {
  background: transparent;
  color: var(--ac-cream);
  border: 1px solid rgba(248,245,238,.35);
}
.ac-btn-ghost:hover { border-color: var(--ac-cream); background: rgba(248,245,238,.08); }
.ac-btn-outline {
  background: transparent;
  color: var(--ac-forest);
  border: 1px solid rgba(26,46,26,.3);
}
.ac-btn-outline:hover { background: rgba(26,46,26,.06); border-color: var(--ac-forest); }

/* ============================================================
   HERO — CITY TRADING FLOOR / OFFICE AT NIGHT
   ============================================================ */
.ac-hero {
  position: relative;
  min-height: 100vh;
  background: var(--ac-forest);
  display: flex;
  align-items: center;
  overflow: hidden;
}

/* Night sky with city glow */
.ac-city-bg {
  position: absolute;
  inset: 0;
  background: linear-gradient(180deg,
    #060A06 0%,
    #0C1A0C 25%,
    #101E10 50%,
    #162416 70%,
    #1A2E1A 100%);
  z-index: 0;
}

/* City skyline silhouette — back row */
.ac-skyline-back {
  position: absolute;
  bottom: 25%; left: 0; right: 0;
  height: 30%;
  z-index: 1;
}
<?php
/* Generate a skyline of buildings */
$bldgs_back = [];
$x = 0;
while ($x < 100):
  $w  = 3 + rand(0,6);
  $h  = 20 + rand(0,55);
  $bldgs_back[] = ['x'=>$x, 'w'=>$w, 'h'=>$h, 'lit'=>rand(0,3)>0];
  $x += $w + rand(0,2);
endwhile;

$bldgs_front = [];
$x = 0;
while ($x < 100):
  $w  = 4 + rand(0,8);
  $h  = 30 + rand(0,50);
  $bldgs_front[] = ['x'=>$x, 'w'=>$w, 'h'=>$h, 'lit'=>rand(0,2)>0];
  $x += $w + rand(0,1);
endwhile;
?>
<?php foreach ($bldgs_back as $bi => $bg):?>
.ac-bb-<?php echo $bi; ?> {
  position: absolute;
  bottom: 0;
  left: <?php echo $bg['x']; ?>%;
  width: <?php echo $bg['w']; ?>%;
  height: <?php echo $bg['h']; ?>%;
  background: #0A120A;
  <?php if ($bg['lit']): ?>
  background: repeating-linear-gradient(
    0deg,
    #0A120A 0px, #0A120A 8px,
    rgba(255,230,100,.06) 8px, rgba(255,230,100,.06) 10px
  );
  <?php endif; ?>
}
<?php endforeach; ?>

/* City skyline front row */
.ac-skyline-front {
  position: absolute;
  bottom: 22%; left: 0; right: 0;
  height: 35%;
  z-index: 2;
}
<?php foreach ($bldgs_front as $bi => $bg):?>
.ac-bf-<?php echo $bi; ?> {
  position: absolute;
  bottom: 0;
  left: <?php echo $bg['x']; ?>%;
  width: <?php echo $bg['w']; ?>%;
  height: <?php echo $bg['h']; ?>%;
  background: #0E180E;
  <?php if ($bg['lit']): ?>
  background: repeating-linear-gradient(
    0deg,
    #0E180E 0px, #0E180E 9px,
    rgba(255,220,80,.08) 9px, rgba(255,220,80,.08) 11px
  );
  <?php endif; ?>
}
<?php endforeach; ?>

/* River (Thames) at bottom of skyline */
.ac-river {
  position: absolute;
  bottom: 22%; left: 0; right: 0;
  height: 28px;
  background: linear-gradient(180deg, #0C1A1A 0%, #081212 100%);
  z-index: 3;
}
.ac-river::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 3px;
  background: linear-gradient(90deg, transparent 0%, rgba(184,150,42,.35) 40%, rgba(184,150,42,.5) 50%, rgba(184,150,42,.35) 60%, transparent 100%);
}
/* River reflections */
.ac-river::after {
  content: '';
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    90deg,
    transparent 0px, transparent 30px,
    rgba(255,220,80,.04) 30px, rgba(255,220,80,.04) 32px
  );
}

/* Street / foreground */
.ac-street {
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 22%;
  background: linear-gradient(180deg, #0A1008 0%, #060A06 100%);
  z-index: 4;
}
.ac-street::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 3px;
  background: rgba(184,150,42,.2);
}
.ac-street::after {
  content: '';
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    90deg,
    transparent 0px, transparent 100px,
    rgba(255,255,255,.015) 100px, rgba(255,255,255,.015) 102px
  );
}

/* Halcyon Partners office tower (hero building) */
.ac-office-tower {
  position: absolute;
  bottom: 22%; left: 50%; transform: translateX(-50%);
  width: 18%;
  height: 70%;
  background: #0E1A0E;
  z-index: 5;
  border-top: 3px solid rgba(184,150,42,.5);
}
/* Tower facade windows */
<?php
for ($fl = 0; $fl < 12; $fl++):
  for ($wc = 0; $wc < 4; $wc++):
    $lit = rand(0,10) > 3;
    $wl  = 6 + $wc * 23;
    $wt  = 3 + $fl * 8;
    ?>
.ac-tw-<?php echo $fl; ?>-<?php echo $wc; ?> {
  position: absolute;
  width: 17%;
  height: 5%;
  left: <?php echo $wl; ?>%;
  top: <?php echo $wt; ?>%;
  background: <?php echo $lit ? 'rgba(255,220,80,.25)' : 'rgba(255,255,255,.04)'; ?>;
  border: 1px solid rgba(255,255,255,.06);
}
<?php endfor; endfor; ?>
/* Tower logo / sign on upper floors */
.ac-tower-sign {
  position: absolute;
  top: 3%; left: 50%; transform: translateX(-50%);
  width: 80%;
  height: 5%;
  background: rgba(184,150,42,.15);
  border: 1px solid rgba(184,150,42,.3);
  border-radius: 1px;
  z-index: 6;
  display: flex; align-items: center; justify-content: center;
}
/* Entrance lobby — ground floor */
.ac-tower-lobby {
  position: absolute;
  bottom: 0; left: 20%; right: 20%;
  height: 12%;
  background: rgba(30,50,20,.8);
  border-top: 2px solid rgba(184,150,42,.4);
  z-index: 6;
}
.ac-tower-lobby::before {
  content: '';
  position: absolute;
  top: 10%; left: 50%; transform: translateX(-50%);
  width: 30%;
  height: 80%;
  background: rgba(255,220,80,.12);
  border: 1px solid rgba(255,220,80,.2);
  border-radius: 1px 1px 0 0;
}

/* Street elements: benches, a black cab */
.ac-cab {
  position: absolute;
  bottom: 22%; right: 12%;
  z-index: 6;
}
.ac-cab-body {
  width: 120px;
  height: 42px;
  background: linear-gradient(180deg, #111 0%, #080808 100%);
  border-radius: 8px 8px 3px 3px;
  position: relative;
}
.ac-cab-body::before {
  content: '';
  position: absolute;
  top: -22px; left: 15%; right: 15%;
  height: 26px;
  background: linear-gradient(180deg, #1A1A1A 0%, #111 100%);
  border-radius: 6px 6px 0 0;
}
.ac-cab-body::after {
  content: '';
  position: absolute;
  top: -14px; left: 18%; right: 18%;
  height: 14px;
  background: rgba(80,140,220,.1);
  border: 1px solid rgba(80,140,220,.2);
  border-radius: 3px 3px 0 0;
}
/* Taxi light */
.ac-cab-sign {
  position: absolute;
  top: -6px; right: 8px;
  width: 20px; height: 8px;
  background: rgba(255,220,80,.6);
  border-radius: 1px;
  font-size: .4rem; line-height: 8px; text-align: center;
  color: rgba(0,0,0,.8); font-weight: 700;
}
.ac-cab-wheels {
  display: flex;
  gap: 60px;
  margin-top: -5px;
  padding-left: 8px;
}
.ac-cab-wheel {
  width: 22px; height: 22px;
  border-radius: 50%;
  background: radial-gradient(circle, #333 0%, #111 60%, #222 100%);
  border: 2px solid #3A3A3A;
}
.ac-cab-wheel::before {
  content: '';
  display: block;
  width: 8px; height: 8px;
  margin: 5px auto;
  border-radius: 50%;
  background: #444;
}

/* Umbrella man on street */
.ac-umbrella {
  position: absolute;
  bottom: calc(22% + 2px); left: 18%;
  z-index: 6;
}
/* Umbrella canopy */
.ac-umbrella::before {
  content: '';
  display: block;
  width: 50px; height: 22px;
  background: linear-gradient(180deg, #1A2E1A 0%, #0A1A0A 100%);
  border-radius: 50% 50% 0 0;
  border: 1px solid rgba(184,150,42,.3);
  margin: 0 auto;
}
/* Handle */
.ac-umbrella::after {
  content: '';
  display: block;
  width: 2px; height: 40px;
  background: #555;
  margin: 0 auto;
  border-radius: 0 0 2px 2px;
}
/* Little person body */
.ac-umbrella-body {
  width: 12px; height: 28px;
  background: linear-gradient(180deg, #222 0%, #111 100%);
  margin: 0 auto;
  border-radius: 2px;
}
.ac-umbrella-body::before {
  content: '';
  position: absolute;
  top: -8px; left: 50%; transform: translateX(-50%);
  width: 12px; height: 14px;
  background: radial-gradient(ellipse at 40% 35%, #D0A878 0%, #A87850 100%);
  border-radius: 50%;
}

/* City light glow from skyline */
.ac-city-glow {
  position: absolute;
  bottom: 22%; left: 0; right: 0;
  height: 180px;
  background: radial-gradient(ellipse at 50% 100%,
    rgba(30,60,20,.4) 0%,
    rgba(184,150,42,.06) 40%,
    transparent 70%);
  z-index: 2;
  pointer-events: none;
}

/* Gold accent line at skyline top */
.ac-skyline-line {
  position: absolute;
  bottom: calc(22% + 28px); left: 0; right: 0;
  height: 1px;
  background: linear-gradient(90deg, transparent 0%, rgba(184,150,42,.3) 30%, rgba(184,150,42,.5) 50%, rgba(184,150,42,.3) 70%, transparent 100%);
  z-index: 10;
}

/* Hero overlay */
.ac-hero-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(120deg,
    rgba(26,46,26,.95) 0%,
    rgba(26,46,26,.75) 50%,
    transparent 100%);
  z-index: 11;
}

.ac-hero-content {
  position: relative;
  z-index: 15;
  max-width: 640px;
}
.ac-hero-badge {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  font-size: .7rem;
  font-weight: 600;
  letter-spacing: .2em;
  text-transform: uppercase;
  color: var(--ac-gold-lt);
  margin-bottom: 24px;
}
.ac-hero-badge::before { content: '—'; }
.ac-hero-title {
  font-family: var(--ac-serif);
  font-size: clamp(2.4rem, 5vw, 4.4rem);
  font-weight: 700;
  line-height: 1.15;
  color: var(--ac-cream);
  margin-bottom: 12px;
}
.ac-hero-title em {
  font-style: italic;
  font-weight: 300;
  color: var(--ac-gold-lt);
}
.ac-hero-subtitle {
  font-family: var(--ac-serif);
  font-size: clamp(.95rem, 1.8vw, 1.25rem);
  font-style: italic;
  font-weight: 300;
  color: rgba(248,245,238,.65);
  margin-bottom: 28px;
  line-height: 1.6;
}
.ac-hero-desc {
  font-size: .92rem;
  color: rgba(248,245,238,.5);
  line-height: 1.85;
  margin-bottom: 40px;
}
.ac-hero-btns { display: flex; gap: 14px; flex-wrap: wrap; }

/* Credentials strip in hero */
.ac-credentials {
  position: absolute;
  bottom: 0; left: 0; right: 0;
  background: rgba(26,46,26,.7);
  backdrop-filter: blur(8px);
  border-top: 1px solid rgba(184,150,42,.2);
  padding: 16px 0;
  z-index: 15;
}
.ac-creds-inner {
  display: flex;
  gap: 40px;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
}
.ac-cred {
  font-size: .7rem;
  font-weight: 600;
  letter-spacing: .15em;
  text-transform: uppercase;
  color: rgba(184,150,42,.7);
}
.ac-cred::before { content: '◆ '; font-size: .5rem; }

/* ============================================================
   STATS BAR
   ============================================================ */
.ac-stats-bar {
  background: var(--ac-forest);
  border-top: 2px solid var(--ac-gold);
  padding: 48px 0;
}
.ac-stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  text-align: center;
}
.ac-stat {
  padding: 12px 20px;
  border-right: 1px solid rgba(255,255,255,.07);
}
.ac-stat:last-child { border-right: none; }
.ac-stat-number {
  font-family: var(--ac-serif);
  font-size: 2.6rem;
  font-weight: 700;
  color: var(--ac-gold);
  line-height: 1;
  margin-bottom: 6px;
}
.ac-stat-label {
  font-size: .7rem;
  font-weight: 500;
  letter-spacing: .12em;
  text-transform: uppercase;
  color: rgba(248,245,238,.4);
}

/* ============================================================
   SERVICES
   ============================================================ */
.ac-services { background: var(--ac-cream); }
.ac-section-header { margin-bottom: 56px; }
.ac-services-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 2px;
  background: rgba(26,46,26,.08);
  border: 1px solid rgba(26,46,26,.08);
  border-radius: var(--ac-radius);
  overflow: hidden;
}
.ac-service-card {
  background: var(--ac-cream);
  padding: 36px 28px;
  position: relative;
  transition: background .25s ease;
}
.ac-service-card:hover { background: var(--ac-ivory); }
.ac-service-card::before {
  content: '';
  position: absolute;
  top: 0; left: 0;
  width: 3px;
  height: 0;
  background: var(--ac-gold);
  transition: height .3s ease;
}
.ac-service-card:hover::before { height: 100%; }
.ac-service-icon-wrap {
  width: 52px; height: 52px;
  background: rgba(26,46,26,.08);
  border-radius: var(--ac-radius);
  display: flex; align-items: center; justify-content: center;
  font-size: 1.4rem;
  margin-bottom: 18px;
  transition: background .25s ease;
}
.ac-service-card:hover .ac-service-icon-wrap { background: rgba(184,150,42,.12); }
.ac-service-card h3 {
  font-family: var(--ac-serif);
  font-size: 1.1rem;
  font-weight: 700;
  color: var(--ac-forest);
  margin-bottom: 10px;
}
.ac-service-card p {
  font-size: .86rem;
  color: var(--ac-stone);
  line-height: 1.72;
}

/* ============================================================
   ABOUT — PARTNERS + PHILOSOPHY
   ============================================================ */
.ac-about { background: var(--ac-ivory); }
.ac-about-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 80px;
  align-items: center;
}
/* CSS financial chart scene */
.ac-chart-scene {
  height: 420px;
  background: var(--ac-forest);
  border-radius: var(--ac-radius);
  position: relative;
  overflow: hidden;
}
/* Chart grid lines */
.ac-chart-scene::before {
  content: '';
  position: absolute;
  inset: 40px 40px 60px 60px;
  background: repeating-linear-gradient(
    180deg,
    transparent 0px, transparent 48px,
    rgba(255,255,255,.06) 48px, rgba(255,255,255,.06) 49px
  );
}
.ac-chart-scene::after {
  content: '';
  position: absolute;
  inset: 40px 40px 60px 60px;
  background: repeating-linear-gradient(
    90deg,
    transparent 0px, transparent 58px,
    rgba(255,255,255,.04) 58px, rgba(255,255,255,.04) 59px
  );
}
/* Y axis */
.ac-chart-y {
  position: absolute;
  bottom: 60px; left: 60px;
  top: 40px;
  width: 2px;
  background: rgba(255,255,255,.15);
  z-index: 2;
}
/* X axis */
.ac-chart-x {
  position: absolute;
  bottom: 60px; left: 60px; right: 40px;
  height: 2px;
  background: rgba(255,255,255,.15);
  z-index: 2;
}
/* Y axis labels */
<?php
$ylabels = ['100','80','60','40','20'];
foreach ($ylabels as $yi => $yl):
  $ypos = 40 + $yi * 48;
?>
.ac-yl-<?php echo $yi; ?> {
  position: absolute;
  top: <?php echo $ypos; ?>px;
  left: 16px;
  font-size: .6rem;
  color: rgba(255,255,255,.3);
  z-index: 3;
}
<?php endforeach; ?>
/* X axis labels */
<?php
$xlabels = ['2020','2021','2022','2023','2024'];
foreach ($xlabels as $xi => $xl):
  $xpos = 60 + $xi * 58;
?>
.ac-xl-<?php echo $xi; ?> {
  position: absolute;
  bottom: 36px;
  left: <?php echo $xpos; ?>px;
  font-size: .58rem;
  color: rgba(255,255,255,.3);
  z-index: 3;
  transform: translateX(-50%);
}
<?php endforeach; ?>
/* Line chart — green upward trend */
.ac-chart-line {
  position: absolute;
  bottom: 62px; left: 60px; right: 40px;
  height: 240px;
  z-index: 4;
}
/* SVG-like polyline using CSS clip-path */
.ac-line-path {
  position: absolute;
  inset: 0;
  background: linear-gradient(180deg, rgba(46,80,48,.4) 0%, transparent 100%);
  clip-path: polygon(
    0% 80%,
    10% 72%,
    20% 65%,
    28% 58%,
    38% 50%,
    48% 42%,
    58% 35%,
    68% 25%,
    78% 18%,
    88% 12%,
    100% 6%,
    100% 100%,
    0% 100%
  );
}
/* Line itself */
.ac-line-path::before {
  content: '';
  position: absolute;
  inset: 0;
  background: transparent;
  border-bottom: 0;
  /* Approximate the line with a thin strip at the clip edge */
}
/* Data points */
<?php
$datapts = [
  ['x'=>0,   'y'=>80],
  ['x'=>10,  'y'=>72],
  ['x'=>20,  'y'=>65],
  ['x'=>28,  'y'=>58],
  ['x'=>38,  'y'=>50],
  ['x'=>48,  'y'=>42],
  ['x'=>58,  'y'=>35],
  ['x'=>68,  'y'=>25],
  ['x'=>78,  'y'=>18],
  ['x'=>88,  'y'=>12],
  ['x'=>100, 'y'=>6],
];
foreach ($datapts as $di => $dp):?>
.ac-dp-<?php echo $di; ?> {
  position: absolute;
  left: <?php echo $dp['x']; ?>%;
  top: <?php echo $dp['y']; ?>%;
  width: 8px; height: 8px;
  background: var(--ac-gold);
  border: 2px solid var(--ac-forest);
  border-radius: 50%;
  z-index: 5;
  transform: translate(-50%,-50%);
}
<?php endforeach; ?>
/* Second line (comparison/benchmark) */
.ac-line-path2 {
  position: absolute;
  inset: 0;
  background: transparent;
  clip-path: polygon(
    0% 90%,
    10% 86%,
    20% 82%,
    28% 78%,
    38% 74%,
    48% 70%,
    58% 66%,
    68% 60%,
    78% 55%,
    88% 50%,
    100% 44%,
    100% 100%,
    0% 100%
  );
  background: linear-gradient(180deg, rgba(184,150,42,.1) 0%, transparent 100%);
}
/* Legend */
.ac-chart-legend {
  position: absolute;
  top: 12px; right: 12px;
  display: flex;
  gap: 16px;
  z-index: 6;
}
.ac-legend-item {
  display: flex; align-items: center; gap: 6px;
  font-size: .6rem;
  font-weight: 500;
  letter-spacing: .08em;
  text-transform: uppercase;
  color: rgba(255,255,255,.5);
}
.ac-legend-dot {
  width: 8px; height: 8px;
  border-radius: 50%;
}

/* Chart title */
.ac-chart-title {
  position: absolute;
  top: 12px; left: 16px;
  font-family: var(--ac-serif);
  font-size: .7rem;
  font-style: italic;
  color: rgba(184,150,42,.6);
  z-index: 6;
}

.ac-about-text {}
.ac-about-values {
  display: flex;
  flex-direction: column;
  gap: 28px;
  margin-top: 36px;
}
.ac-value {
  display: flex; gap: 16px; align-items: flex-start;
  padding-left: 16px;
  border-left: 2px solid var(--ac-gold);
}
.ac-value-body h4 {
  font-family: var(--ac-serif);
  font-size: 1rem;
  font-weight: 700;
  color: var(--ac-forest);
  margin-bottom: 4px;
}
.ac-value-body p {
  font-size: .86rem;
  color: var(--ac-stone);
  line-height: 1.7;
}

/* ============================================================
   PACKAGES / PRICING TIERS
   ============================================================ */
.ac-packages { background: var(--ac-cream); }
.ac-packages-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
  margin-top: 52px;
}
.ac-package-card {
  background: var(--ac-ivory);
  border: 1px solid rgba(26,46,26,.1);
  border-radius: var(--ac-radius);
  padding: 36px 28px;
  position: relative;
  transition: transform .25s ease, box-shadow .25s ease;
}
.ac-package-card:hover { transform: translateY(-4px); box-shadow: var(--ac-shadow); }
.ac-package-card.featured {
  background: var(--ac-forest);
  border-color: var(--ac-gold);
}
.ac-pkg-badge {
  position: absolute;
  top: -13px; left: 50%; transform: translateX(-50%);
  background: var(--ac-gold);
  color: var(--ac-forest);
  font-size: .65rem;
  font-weight: 700;
  letter-spacing: .14em;
  text-transform: uppercase;
  padding: 4px 14px;
  border-radius: 20px;
  white-space: nowrap;
}
.ac-pkg-name {
  font-family: var(--ac-serif);
  font-size: 1rem;
  font-weight: 700;
  color: var(--ac-forest);
  text-align: center;
  margin-bottom: 6px;
}
.ac-package-card.featured .ac-pkg-name { color: var(--ac-cream); }
.ac-pkg-price {
  font-family: var(--ac-serif);
  font-size: 2.4rem;
  font-weight: 700;
  color: var(--ac-gold);
  text-align: center;
  line-height: 1;
  margin: 14px 0 4px;
}
.ac-pkg-unit {
  font-size: .72rem;
  color: var(--ac-stone);
  text-align: center;
  margin-bottom: 22px;
  text-transform: uppercase;
  letter-spacing: .08em;
}
.ac-package-card.featured .ac-pkg-unit { color: rgba(248,245,238,.45); }
.ac-pkg-divider {
  height: 1px;
  background: rgba(26,46,26,.1);
  margin-bottom: 22px;
}
.ac-package-card.featured .ac-pkg-divider { background: rgba(255,255,255,.08); }
.ac-pkg-features {
  list-style: none;
  margin-bottom: 28px;
}
.ac-pkg-features li {
  display: flex; gap: 10px; align-items: flex-start;
  font-size: .84rem;
  color: var(--ac-stone);
  margin-bottom: 10px;
  line-height: 1.5;
}
.ac-package-card.featured .ac-pkg-features li { color: rgba(248,245,238,.65); }
.ac-pkg-features li::before {
  content: '✓';
  color: var(--ac-gold);
  font-size: .8rem;
  flex-shrink: 0;
  margin-top: 1px;
}

/* ============================================================
   PROCESS
   ============================================================ */
.ac-process { background: var(--ac-ivory); }
.ac-process-steps {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 32px;
  margin-top: 56px;
  position: relative;
}
.ac-process-steps::before {
  content: '';
  position: absolute;
  top: 28px; left: 12.5%; right: 12.5%;
  height: 1px;
  background: linear-gradient(90deg, var(--ac-gold) 0%, rgba(184,150,42,.1) 100%);
}
.ac-process-step { text-align: center; }
.ac-step-num {
  width: 56px; height: 56px;
  border-radius: 50%;
  background: var(--ac-forest);
  border: 1px solid var(--ac-gold);
  display: flex; align-items: center; justify-content: center;
  font-family: var(--ac-serif);
  font-size: 1.1rem;
  font-weight: 700;
  color: var(--ac-gold);
  margin: 0 auto 18px;
  position: relative; z-index: 2;
}
.ac-step-title {
  font-family: var(--ac-serif);
  font-size: .98rem;
  font-weight: 700;
  color: var(--ac-forest);
  margin-bottom: 8px;
}
.ac-step-desc {
  font-size: .82rem;
  color: var(--ac-stone);
  line-height: 1.65;
}

/* ============================================================
   CSS ACCOUNTANT FIGURES
   ============================================================ */
.ac-team-section {
  background: var(--ac-forest);
  padding: 96px 0;
  overflow: hidden;
}
.ac-team-section .ac-tag { color: var(--ac-gold-lt); }
.ac-team-section .ac-heading { color: var(--ac-cream); }
.ac-team-row {
  display: flex;
  justify-content: center;
  gap: 64px;
  margin-top: 56px;
}
.ac-partner-figure {
  display: flex; flex-direction: column; align-items: center;
}
/* Head */
.ac-partner-head {
  width: 36px; height: 40px;
  background: radial-gradient(ellipse at 40% 35%, #ECC88A 0%, #C09048 100%);
  border-radius: 50% 50% 44% 44%;
  position: relative;
}
.ac-partner-head::before {
  content: '';
  position: absolute;
  top: -4px; left: -2px; right: -2px;
  height: 14px;
  background: #2A1E10;
  border-radius: 50% 50% 0 0;
  clip-path: polygon(0% 100%, 0% 50%, 50% 0%, 100% 50%, 100% 100%);
}
/* Glasses */
.ac-partner-head::after {
  content: '';
  position: absolute;
  top: 40%; left: 14%; right: 14%;
  height: 6px;
  background: transparent;
  border: 1.5px solid rgba(80,50,20,.6);
  border-radius: 2px;
  box-shadow: 0 0 0 1px rgba(80,50,20,.2);
}
.ac-partner-neck {
  width: 12px; height: 8px;
  background: #C09048;
  margin: 0 auto;
}
/* Dark charcoal suit */
.ac-partner-suit {
  width: 58px; height: 68px;
  background: linear-gradient(180deg, #1C1C1C 0%, #111 100%);
  border-radius: 5px 5px 2px 2px;
  position: relative;
}
/* Pinstripe */
.ac-partner-suit::before {
  content: '';
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    90deg,
    transparent 0px, transparent 14px,
    rgba(255,255,255,.04) 14px, rgba(255,255,255,.04) 15px
  );
  border-radius: inherit;
}
/* White shirt + lapels */
.ac-partner-suit::after {
  content: '';
  position: absolute;
  top: 0; left: 50%; transform: translateX(-50%);
  width: 16px; height: 100%;
  background: linear-gradient(180deg, #F0EDE6 0%, #E0DDD5 100%);
  clip-path: polygon(0% 0%, 100% 0%, 82% 100%, 18% 100%);
}
/* Tie — forest green */
.ac-partner-tie {
  position: absolute;
  top: 3px; left: 50%; transform: translateX(-50%);
  width: 7px; height: 36px;
  background: linear-gradient(180deg, var(--ac-forest-lt) 0%, var(--ac-forest) 100%);
  clip-path: polygon(20% 0%, 80% 0%, 95% 70%, 50% 100%, 5% 70%);
  z-index: 2;
}
/* Arms */
.ac-partner-arm-l {
  position: absolute;
  top: 3px; left: -13px;
  width: 13px; height: 50px;
  background: linear-gradient(180deg, #1C1C1C 0%, #111 100%);
  border-radius: 6px 3px 3px 6px;
  transform: rotate(5deg);
  transform-origin: top center;
}
.ac-partner-arm-l::before {
  content: '';
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 7px;
  background: #E0DDD5;
  border-radius: 2px;
}
.ac-partner-arm-r {
  position: absolute;
  top: 3px; right: -12px;
  width: 13px; height: 48px;
  background: linear-gradient(180deg, #1C1C1C 0%, #111 100%);
  border-radius: 3px 6px 6px 3px;
  transform: rotate(-5deg);
  transform-origin: top center;
}
.ac-partner-arm-r::before {
  content: '';
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 7px;
  background: #E0DDD5;
  border-radius: 2px;
}
/* Document / folder in right hand */
.ac-partner-arm-r::after {
  content: '';
  position: absolute;
  bottom: -12px; left: 50%; transform: translateX(-50%);
  width: 22px; height: 16px;
  background: linear-gradient(180deg, #F5F0E8 0%, #E8E3D8 100%);
  border: 1px solid rgba(184,150,42,.3);
  border-radius: 1px;
}
/* Legs */
.ac-partner-legs {
  width: 58px; height: 60px; position: relative;
}
.ac-partner-leg-l, .ac-partner-leg-r {
  position: absolute; bottom: 0;
  width: 22px; height: 56px;
  background: linear-gradient(180deg, #1C1C1C 0%, #111 100%);
  border-radius: 2px 2px 0 0;
}
.ac-partner-leg-l { left: 3px; }
.ac-partner-leg-r { right: 3px; }
.ac-partner-leg-l::after, .ac-partner-leg-r::after {
  content: '';
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 9px;
  background: #080808;
  border-radius: 0 0 2px 2px;
}
.ac-partner-name {
  margin-top: 14px;
  font-family: var(--ac-serif);
  font-size: .9rem;
  font-style: italic;
  color: rgba(248,245,238,.7);
  text-align: center;
}
.ac-partner-role {
  font-size: .65rem;
  font-weight: 600;
  letter-spacing: .12em;
  text-transform: uppercase;
  color: var(--ac-gold);
  margin-top: 2px;
  text-align: center;
}
.ac-partner-qual {
  font-size: .62rem;
  color: rgba(248,245,238,.35);
  margin-top: 2px;
  text-align: center;
  font-style: italic;
}

/* ============================================================
   TESTIMONIALS
   ============================================================ */
.ac-testimonials { background: var(--ac-cream); }
.ac-testi-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
  margin-top: 52px;
}
.ac-testi-card {
  background: var(--ac-ivory);
  border: 1px solid rgba(26,46,26,.08);
  border-top: 3px solid var(--ac-gold);
  border-radius: var(--ac-radius);
  padding: 30px 26px;
}
.ac-testi-stars { color: var(--ac-gold); font-size: .82rem; margin-bottom: 14px; }
.ac-testi-text {
  font-family: var(--ac-serif);
  font-style: italic;
  font-weight: 300;
  font-size: .94rem;
  color: var(--ac-forest);
  line-height: 1.75;
  margin-bottom: 18px;
}
.ac-testi-author {
  font-weight: 600;
  font-size: .78rem;
  color: var(--ac-stone);
  text-transform: uppercase;
  letter-spacing: .08em;
}
.ac-testi-biz {
  font-size: .74rem;
  color: var(--ac-gold);
  margin-top: 2px;
}

/* ============================================================
   FAQ
   ============================================================ */
.ac-faq { background: var(--ac-ivory); }
.ac-faq-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 52px;
  align-items: start;
  margin-top: 52px;
}
.ac-faq-list { display: flex; flex-direction: column; gap: 10px; }
.ac-faq-item {
  background: var(--ac-cream);
  border: 1px solid rgba(26,46,26,.08);
  border-radius: var(--ac-radius);
  overflow: hidden;
}
.ac-faq-q {
  display: flex; justify-content: space-between; align-items: center;
  padding: 17px 20px;
  cursor: pointer;
  font-family: var(--ac-serif);
  font-size: .94rem;
  font-weight: 700;
  color: var(--ac-forest);
  user-select: none;
  transition: color .2s;
}
.ac-faq-q:hover { color: var(--ac-gold); }
.ac-faq-icon {
  width: 20px; height: 20px;
  border: 1px solid rgba(184,150,42,.4);
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .8rem;
  color: var(--ac-gold);
  flex-shrink: 0;
  transition: transform .3s ease;
}
.ac-faq-item.open .ac-faq-icon { transform: rotate(45deg); }
.ac-faq-a { max-height: 0; overflow: hidden; transition: max-height .35s ease; }
.ac-faq-a-inner {
  padding: 0 20px 16px;
  font-size: .85rem;
  color: var(--ac-stone);
  line-height: 1.78;
}
.ac-faq-item.open .ac-faq-a { max-height: 280px; }

.ac-faq-cta {
  background: var(--ac-forest);
  border-radius: var(--ac-radius);
  padding: 36px 30px;
  display: flex; flex-direction: column; gap: 18px;
}
.ac-faq-cta h3 {
  font-family: var(--ac-serif);
  font-size: 1.4rem;
  font-style: italic;
  font-weight: 300;
  color: var(--ac-cream);
  line-height: 1.3;
}
.ac-faq-cta p {
  font-size: .86rem;
  color: rgba(248,245,238,.5);
  line-height: 1.75;
}
.ac-faq-contact { display: flex; flex-direction: column; gap: 8px; }
.ac-faq-contact a {
  color: var(--ac-gold-lt);
  text-decoration: none;
  font-size: .86rem;
  display: flex; align-items: center; gap: 8px;
  transition: color .2s;
}
.ac-faq-contact a:hover { color: var(--ac-cream); }

/* ============================================================
   ENQUIRY FORM
   ============================================================ */
.ac-enquiry { background: var(--ac-forest); }
.ac-enquiry .ac-tag   { color: var(--ac-gold-lt); }
.ac-enquiry .ac-heading { color: var(--ac-cream); }
.ac-enquiry .ac-heading em { color: var(--ac-gold-lt); }
.ac-enquiry .ac-lead { color: rgba(248,245,238,.5); }
.ac-form-wrapper {
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(184,150,42,.18);
  border-radius: var(--ac-radius);
  padding: 48px 44px;
  margin-top: 48px;
  max-width: 860px;
  margin-left: auto;
  margin-right: auto;
}
.ac-form-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 22px;
  margin-bottom: 22px;
}
.ac-form-group { display: flex; flex-direction: column; gap: 8px; }
.ac-form-group.full { grid-column: 1/-1; }
.ac-form-group label {
  font-size: .7rem;
  font-weight: 600;
  letter-spacing: .12em;
  text-transform: uppercase;
  color: rgba(248,245,238,.4);
}
.ac-form-group input,
.ac-form-group select,
.ac-form-group textarea {
  background: rgba(255,255,255,.06);
  border: 1px solid rgba(255,255,255,.09);
  border-radius: var(--ac-radius);
  padding: 12px 15px;
  font-family: var(--ac-sans);
  font-size: .9rem;
  color: var(--ac-cream);
  transition: border-color .2s;
  outline: none;
  width: 100%;
}
.ac-form-group input::placeholder,
.ac-form-group textarea::placeholder { color: rgba(248,245,238,.22); }
.ac-form-group input:focus,
.ac-form-group select:focus,
.ac-form-group textarea:focus { border-color: var(--ac-gold); }
.ac-form-group select { cursor: pointer; }
.ac-form-group select option { background: var(--ac-forest); }
.ac-form-group textarea { resize: vertical; min-height: 110px; }
.ac-form-actions {
  display: flex; align-items: center; gap: 18px; margin-top: 8px;
}
.ac-form-note {
  font-size: .74rem;
  color: rgba(248,245,238,.28);
  line-height: 1.5;
}
.ac-form-success { display: none; text-align: center; padding: 32px; color: var(--ac-cream); }
.ac-form-success h3 {
  font-family: var(--ac-serif);
  font-size: 1.5rem;
  font-style: italic;
  font-weight: 300;
  color: var(--ac-gold-lt);
  margin-bottom: 8px;
}

/* ============================================================
   FOOTER
   ============================================================ */
.ac-footer {
  background: #0A100A;
  padding: 56px 0 28px;
  border-top: 1px solid rgba(184,150,42,.15);
}
.ac-footer-inner {
  display: grid;
  grid-template-columns: 2fr 1fr 1fr;
  gap: 56px;
  margin-bottom: 44px;
}
.ac-footer-brand h3 {
  font-family: var(--ac-serif);
  font-size: 1.3rem;
  font-style: italic;
  font-weight: 300;
  color: var(--ac-cream);
  margin-bottom: 4px;
}
.ac-footer-brand > span {
  font-size: .65rem;
  font-weight: 600;
  letter-spacing: .2em;
  text-transform: uppercase;
  color: var(--ac-gold);
  display: block;
  margin-bottom: 14px;
}
.ac-footer-brand p {
  font-size: .8rem;
  color: rgba(248,245,238,.32);
  line-height: 1.7;
  max-width: 300px;
}
.ac-footer-col h4 {
  font-size: .65rem;
  font-weight: 600;
  letter-spacing: .18em;
  text-transform: uppercase;
  color: var(--ac-gold);
  margin-bottom: 14px;
}
.ac-footer-col ul { list-style: none; }
.ac-footer-col ul li { margin-bottom: 8px; }
.ac-footer-col ul li a {
  font-size: .8rem;
  color: rgba(248,245,238,.32);
  text-decoration: none;
  transition: color .2s;
}
.ac-footer-col ul li a:hover { color: var(--ac-cream); }
.ac-footer-bottom {
  border-top: 1px solid rgba(255,255,255,.05);
  padding-top: 22px;
  display: flex; justify-content: space-between; align-items: center;
}
.ac-footer-bottom p { font-size: .72rem; color: rgba(248,245,238,.2); }
.ac-footer-bottom a { font-size: .72rem; color: rgba(184,150,42,.35); text-decoration: none; transition: color .2s; }
.ac-footer-bottom a:hover { color: var(--ac-gold); }

/* ============================================================
   RESPONSIVE
   ============================================================ */
@media (max-width: 1024px) {
  .ac-about-grid     { grid-template-columns: 1fr; gap: 48px; }
  .ac-services-grid  { grid-template-columns: repeat(2, 1fr); }
  .ac-packages-grid  { grid-template-columns: 1fr; }
  .ac-footer-inner   { grid-template-columns: 1fr 1fr; }
}
@media (max-width: 768px) {
  .ac-section { padding: 64px 0; }
  .ac-container { padding: 0 20px; }
  .ac-stats-grid     { grid-template-columns: repeat(2, 1fr); }
  .ac-services-grid  { grid-template-columns: 1fr; }
  .ac-process-steps  { grid-template-columns: repeat(2, 1fr); }
  .ac-process-steps::before { display: none; }
  .ac-testi-grid     { grid-template-columns: 1fr; }
  .ac-faq-grid       { grid-template-columns: 1fr; }
  .ac-form-grid      { grid-template-columns: 1fr; }
  .ac-team-row       { flex-wrap: wrap; gap: 32px; }
  .ac-footer-inner   { grid-template-columns: 1fr; gap: 28px; }
  .ac-footer-bottom  { flex-direction: column; gap: 12px; text-align: center; }
  .ac-creds-inner    { gap: 20px; }
}
</style>
<?php get_header(); ?>
<div class="page-template-page-accountant">
>

<!-- HERO -->
<section class="ac-hero">
  <div class="ac-city-bg"></div>

  <!-- Skyline back -->
  <div class="ac-skyline-back">
    <?php foreach ($bldgs_back as $bi => $bg): ?>
    <div class="ac-bb-<?php echo $bi; ?>"></div>
    <?php endforeach; ?>
  </div>

  <!-- Skyline front -->
  <div class="ac-skyline-front">
    <?php foreach ($bldgs_front as $bi => $bg): ?>
    <div class="ac-bf-<?php echo $bi; ?>"></div>
    <?php endforeach; ?>
  </div>

  <div class="ac-city-glow"></div>
  <div class="ac-skyline-line"></div>

  <!-- Office tower -->
  <div class="ac-office-tower">
    <?php for ($fl = 0; $fl < 12; $fl++):
      for ($wc = 0; $wc < 4; $wc++): ?>
    <div class="ac-tw-<?php echo $fl; ?>-<?php echo $wc; ?>"></div>
    <?php endfor; endfor; ?>
    <div class="ac-tower-sign"></div>
    <div class="ac-tower-lobby"></div>
  </div>

  <div class="ac-river"></div>
  <div class="ac-street"></div>

  <!-- Cab -->
  <div class="ac-cab">
    <div class="ac-cab-body">
      <div class="ac-cab-sign">TAXI</div>
      <div class="ac-cab-lights">
        <div class="ac-car-light" style="width:14px;height:8px;background:rgba(255,220,80,.15);border-radius:2px;"></div>
        <div class="ac-car-light" style="width:14px;height:8px;background:rgba(255,100,80,.1);border-radius:2px;"></div>
      </div>
    </div>
    <div class="ac-cab-wheels">
      <div class="ac-cab-wheel"></div>
      <div class="ac-cab-wheel"></div>
    </div>
  </div>

  <!-- Umbrella figure -->
  <div class="ac-umbrella" style="position:absolute;bottom:calc(22% + 2px);left:18%;z-index:6;">
    <div style="width:52px;height:24px;background:linear-gradient(180deg,#1A2E1A 0%,#0A1A0A 100%);border-radius:50% 50% 0 0;border:1px solid rgba(184,150,42,.3);margin:0 auto;"></div>
    <div style="width:2px;height:36px;background:#555;margin:0 auto;"></div>
    <div style="width:14px;height:28px;background:linear-gradient(180deg,#222 0%,#111 100%);border-radius:2px;margin:0 auto;position:relative;">
      <div style="position:absolute;top:-16px;left:50%;transform:translateX(-50%);width:14px;height:16px;background:radial-gradient(ellipse at 40% 35%,#D0A878 0%,#A87850 100%);border-radius:50%;"></div>
    </div>
  </div>

  <!-- Y-axis labels -->
  <?php foreach ($ylabels as $yi => $yl): ?>
  <div class="ac-yl-<?php echo $yi; ?>" style="display:none;"><?php echo esc_html($yl); ?></div>
  <?php endforeach; ?>

  <div class="ac-hero-overlay"></div>

  <div class="ac-container" style="position:relative;z-index:15;width:100%;padding-bottom:80px;">
    <div class="ac-hero-content">
      <div class="ac-hero-badge">City of London · Est. 1994</div>
      <h1 class="ac-hero-title">
        Financial Clarity.<br><em>Strategic</em> Precision.
      </h1>
      <p class="ac-hero-subtitle">Chartered accountants and financial advisors to growth businesses and individuals</p>
      <p class="ac-hero-desc">
        Halcyon Partners provides comprehensive accounting, tax, and financial advisory services to ambitious companies and high-net-worth individuals across the UK and internationally.
      </p>
      <div class="ac-hero-btns">
        <a href="#enquiry" class="ac-btn ac-btn-gold">Book a Consultation</a>
        <a href="#services" class="ac-btn ac-btn-ghost">Our Services</a>
      </div>
    </div>
  </div>

  <!-- Professional credentials strip -->
  <div class="ac-credentials">
    <div class="ac-container">
      <div class="ac-creds-inner">
        <?php foreach (['ICAEW Member Firm','ACCA Accredited','HMRC Agent Authorised','FCA Regulated','CIOT Member','Member of ICAS'] as $cred):?>
        <span class="ac-cred"><?php echo esc_html($cred); ?></span>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- STATS BAR -->
<section class="ac-stats-bar">
  <div class="ac-container">
    <div class="ac-stats-grid">
      <?php
      $stats = [
        ['val'=>'30yrs',  'lbl'=>'City of London Experience'],
        ['val'=>'850+',   'lbl'=>'Business Clients'],
        ['val'=>'£1.2B+', 'lbl'=>'Tax Savings Delivered'],
        ['val'=>'4.9★',   'lbl'=>'Client Satisfaction'],
      ];
      foreach ($stats as $st):?>
      <div class="ac-stat">
        <div class="ac-stat-number" data-target="<?php echo esc_attr($st['val']); ?>"><?php echo esc_html($st['val']); ?></div>
        <div class="ac-stat-label"><?php echo esc_html($st['lbl']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- SERVICES -->
<section class="ac-services ac-section" id="services">
  <div class="ac-container">
    <div class="ac-section-header">
      <span class="ac-tag">What We Do</span>
      <h2 class="ac-heading">Our Core <em>Services</em></h2>
      <p class="ac-lead" style="margin-top:16px;">From day-to-day bookkeeping to complex international tax structuring, we deliver the full spectrum of financial services.</p>
    </div>
    <div class="ac-services-grid">
      <?php
      $services = [
        ['icon'=>'📊','name'=>'Statutory Accounts',     'desc'=>'Year-end accounts preparation, filing, and Companies House compliance for limited companies of all sizes.'],
        ['icon'=>'💰','name'=>'Corporate Tax',           'desc'=>'Corporation tax returns, R&D tax relief claims, loss utilisation, and group tax planning strategies.'],
        ['icon'=>'📋','name'=>'VAT & Indirect Tax',     'desc'=>'VAT registration, return preparation, Making Tax Digital compliance, and customs duty advice.'],
        ['icon'=>'👤','name'=>'Personal Tax',            'desc'=>'Self-assessment returns, capital gains tax planning, non-domicile advisory, and HMRC enquiry defence.'],
        ['icon'=>'📈','name'=>'Financial Advisory',      'desc'=>'Business valuations, cash flow forecasting, KPI dashboards, and growth strategy advisory.'],
        ['icon'=>'⚖️','name'=>'Payroll & Employer',     'desc'=>'RTI payroll, benefits-in-kind reporting, auto-enrolment, IR35 compliance, and PAYE enquiries.'],
      ];
      foreach ($services as $svc):?>
      <div class="ac-service-card">
        <div class="ac-service-icon-wrap"><?php echo $svc['icon']; ?></div>
        <h3><?php echo esc_html($svc['name']); ?></h3>
        <p><?php echo esc_html($svc['desc']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ABOUT -->
<section class="ac-about ac-section" id="about">
  <div class="ac-container">
    <div class="ac-about-grid">
      <!-- CSS Chart scene -->
      <div class="ac-chart-scene">
        <div class="ac-chart-y"></div>
        <div class="ac-chart-x"></div>
        <?php foreach ($ylabels as $yi => $yl): ?>
        <div class="ac-yl-<?php echo $yi; ?>"><?php echo esc_html($yl); ?></div>
        <?php endforeach; ?>
        <?php foreach ($xlabels as $xi => $xl): ?>
        <div class="ac-xl-<?php echo $xi; ?>"><?php echo esc_html($xl); ?></div>
        <?php endforeach; ?>
        <div class="ac-chart-line">
          <div class="ac-line-path"></div>
          <div class="ac-line-path2"></div>
          <?php foreach ($datapts as $di => $dp): ?>
          <div class="ac-dp-<?php echo $di; ?>"></div>
          <?php endforeach; ?>
        </div>
        <div class="ac-chart-legend">
          <div class="ac-legend-item">
            <div class="ac-legend-dot" style="background:var(--ac-gold);"></div>
            Client Growth
          </div>
          <div class="ac-legend-item">
            <div class="ac-legend-dot" style="background:rgba(184,150,42,.5);"></div>
            Market Average
          </div>
        </div>
        <div class="ac-chart-title">Halcyon Client Performance Index</div>
      </div>

      <div class="ac-about-text">
        <span class="ac-tag">Our Firm</span>
        <h2 class="ac-heading">Numbers-Driven. <em>Relationship-Led.</em></h2>
        <p class="ac-lead" style="margin-top:18px;">Since 1994 we have been trusted by growth businesses, owner-managed companies, and high-net-worth families to provide not just compliance — but genuine strategic advantage.</p>
        <div class="ac-about-values">
          <?php
          $vals = [
            ['title'=>'Proactive Advisory',    'desc'=>'We don\'t wait for year-end. Our partners engage with clients quarterly to identify opportunities and mitigate risk before they arise.'],
            ['title'=>'Technology-Forward',     'desc'=>'Xero Platinum Partner, QuickBooks Certified, and early adopters of Making Tax Digital — we ensure clients are ahead of every regulatory change.'],
            ['title'=>'Sector Expertise',       'desc'=>'Deep specialism in property, professional services, tech startups, creative industries, and international trade.'],
          ];
          foreach ($vals as $v):?>
          <div class="ac-value">
            <div class="ac-value-body">
              <h4><?php echo esc_html($v['title']); ?></h4>
              <p><?php echo esc_html($v['desc']); ?></p>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- PACKAGES -->
<section class="ac-packages ac-section" id="packages">
  <div class="ac-container">
    <div class="ac-section-header">
      <span class="ac-tag">Pricing</span>
      <h2 class="ac-heading">Transparent <em>Fee Packages</em></h2>
      <p class="ac-lead" style="margin-top:16px;">Fixed monthly retainers — no surprise invoices, no hourly billing. All packages include a dedicated partner contact and quarterly review meetings.</p>
    </div>
    <div class="ac-packages-grid">
      <?php
      $pkgs = [
        [
          'name'     => 'Foundation',
          'price'    => '£295',
          'unit'     => 'per month + VAT',
          'featured' => false,
          'badge'    => '',
          'features' => [
            'Annual statutory accounts',
            'Corporation tax return',
            'VAT returns (quarterly)',
            'Self-assessment (1 director)',
            'Companies House filing',
            'Xero subscription included',
            'Email & phone support',
          ],
        ],
        [
          'name'     => 'Growth',
          'price'    => '£595',
          'unit'     => 'per month + VAT',
          'featured' => true,
          'badge'    => 'Most Popular',
          'features' => [
            'Everything in Foundation',
            'Monthly management accounts',
            'Payroll up to 10 employees',
            'Quarterly planning meetings',
            'R&D tax relief assessment',
            'Cash flow forecasting',
            'Same-day response guarantee',
          ],
        ],
        [
          'name'     => 'Enterprise',
          'price'    => 'Custom',
          'unit'     => 'tailored to you',
          'featured' => false,
          'badge'    => '',
          'features' => [
            'Everything in Growth',
            'Full finance function support',
            'Unlimited payroll employees',
            'International tax structuring',
            'Group consolidations',
            'Due diligence & M&A advisory',
            'Dedicated senior partner team',
          ],
        ],
      ];
      foreach ($pkgs as $pkg):?>
      <div class="ac-package-card<?php echo $pkg['featured'] ? ' featured' : ''; ?>">
        <?php if ($pkg['badge']): ?>
        <div class="ac-pkg-badge"><?php echo esc_html($pkg['badge']); ?></div>
        <?php endif; ?>
        <div class="ac-pkg-name"><?php echo esc_html($pkg['name']); ?></div>
        <div class="ac-pkg-price"><?php echo esc_html($pkg['price']); ?></div>
        <div class="ac-pkg-unit"><?php echo esc_html($pkg['unit']); ?></div>
        <div class="ac-pkg-divider"></div>
        <ul class="ac-pkg-features">
          <?php foreach ($pkg['features'] as $feat):?>
          <li><?php echo esc_html($feat); ?></li>
          <?php endforeach; ?>
        </ul>
        <a href="#enquiry" class="ac-btn <?php echo $pkg['featured'] ? 'ac-btn-gold' : 'ac-btn-outline'; ?>" style="width:100%;text-align:center;"><?php echo $pkg['name']==='Enterprise' ? 'Get a Quote' : 'Get Started'; ?></a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- PROCESS -->
<section class="ac-process ac-section">
  <div class="ac-container">
    <div class="ac-section-header">
      <span class="ac-tag">Getting Started</span>
      <h2 class="ac-heading">Our <em>Onboarding</em> Process</h2>
      <p class="ac-lead" style="margin-top:16px;">Switching accountants is simpler than you think. We handle the transition — including all communication with HMRC and your previous accountant.</p>
    </div>
    <div class="ac-process-steps">
      <?php
      $steps = [
        ['n'=>'01','title'=>'Discovery Call',      'desc'=>'A free 30-minute consultation to understand your business and current pain points.'],
        ['n'=>'02','title'=>'Proposal & Scope',    'desc'=>'We present a fixed-fee proposal within 48 hours, tailored to your exact requirements.'],
        ['n'=>'03','title'=>'Seamless Transition', 'desc'=>'We contact HMRC, Companies House, and your previous accountant to transfer authority.'],
        ['n'=>'04','title'=>'Ongoing Partnership', 'desc'=>'Quarterly reviews, proactive tax planning, and a dedicated partner — from day one.'],
      ];
      foreach ($steps as $stp):?>
      <div class="ac-process-step">
        <div class="ac-step-num"><?php echo esc_html($stp['n']); ?></div>
        <h3 class="ac-step-title"><?php echo esc_html($stp['title']); ?></h3>
        <p class="ac-step-desc"><?php echo esc_html($stp['desc']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- PARTNERS TEAM -->
<section class="ac-team-section">
  <div class="ac-container">
    <div class="ac-section-header" style="margin-bottom:0;">
      <span class="ac-tag">Our Partners</span>
      <h2 class="ac-heading">The <em>Halcyon</em> Partnership</h2>
    </div>
    <div class="ac-team-row">
      <?php
      $partners = [
        ['name'=>'Richard Halcyon',    'role'=>'Senior Partner',         'qual'=>'FCA · ICAEW · 30yrs'],
        ['name'=>'Sophie Chen',         'role'=>'Tax Partner',             'qual'=>'ATT · CTA · 18yrs'],
        ['name'=>'Marcus Okafor',       'role'=>'Corporate Finance',       'qual'=>'ACA · CF · 14yrs'],
        ['name'=>'Priya Nair',          'role'=>'Private Client Partner',  'qual'=>'ACCA · 16yrs'],
      ];
      foreach ($partners as $pt):?>
      <div class="ac-partner-figure">
        <div class="ac-partner-head"></div>
        <div class="ac-partner-neck"></div>
        <div class="ac-partner-suit" style="position:relative;">
          <div class="ac-partner-arm-l"></div>
          <div class="ac-partner-arm-r"></div>
          <div class="ac-partner-tie"></div>
        </div>
        <div class="ac-partner-legs">
          <div class="ac-partner-leg-l"></div>
          <div class="ac-partner-leg-r"></div>
        </div>
        <div class="ac-partner-name"><?php echo esc_html($pt['name']); ?></div>
        <div class="ac-partner-role"><?php echo esc_html($pt['role']); ?></div>
        <div class="ac-partner-qual"><?php echo esc_html($pt['qual']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="ac-testimonials ac-section">
  <div class="ac-container">
    <div class="ac-section-header">
      <span class="ac-tag">Client Stories</span>
      <h2 class="ac-heading">Trusted by <em>Growing Businesses</em></h2>
    </div>
    <div class="ac-testi-grid">
      <?php
      $testis = [
        ['text'=>'Switching to Halcyon was the best business decision we made last year. They identified £180,000 in R&D tax relief we had completely missed, and their quarterly reporting has transformed our visibility.','author'=>'James McAllister','biz'=>'CEO · Brightfield Technologies · 45 Employees'],
        ['text'=>'Richard and the team handle everything from our monthly management accounts to our complex group structure. Their proactive approach means we never face a tax surprise.','author'=>'Victoria Pemberton','biz'=>'Director · Pemberton Property Group'],
        ['text'=>'As a non-domiciled individual with interests across three jurisdictions, finding an accountancy firm with the depth of knowledge Halcyon has was transformational. Genuinely exceptional.','author'=>'Andreas Stavros','biz'=>'Private Client · International Entrepreneur'],
      ];
      foreach ($testis as $tt):?>
      <div class="ac-testi-card">
        <div class="ac-testi-stars">★★★★★</div>
        <p class="ac-testi-text"><?php echo esc_html($tt['text']); ?></p>
        <div class="ac-testi-author"><?php echo esc_html($tt['author']); ?></div>
        <div class="ac-testi-biz"><?php echo esc_html($tt['biz']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- FAQ -->
<section class="ac-faq ac-section">
  <div class="ac-container">
    <div class="ac-section-header">
      <span class="ac-tag">Questions</span>
      <h2 class="ac-heading">Common <em>Questions</em></h2>
    </div>
    <div class="ac-faq-grid">
      <div class="ac-faq-list">
        <?php
        $faqs = [
          ['q'=>'How do your fixed fees compare to my current accountant?','a'=>'Our fixed-fee retainers typically save clients 15–30% compared to hourly billing, and the certainty of a known monthly cost makes financial planning far easier. We\'re happy to review your current invoice history and provide a direct comparison.'],
          ['q'=>'Can you handle Making Tax Digital (MTD)?','a'=>'Yes — we are MTD-ready for VAT, and are preparing all clients for MTD for Income Tax (due 2026) and corporation tax. All clients are set up on compatible software, with bridging software available where needed.'],
          ['q'=>'Do you work with startups and early-stage companies?','a'=>'Absolutely. We have a dedicated startup package that includes company formation advice, SEIS/EIS structuring, early-stage R&D claims, and monthly management accounts from pre-revenue stage.'],
          ['q'=>'What sectors do you specialise in?','a'=>'Our deepest expertise is in property investment and development, professional services, technology and SaaS, creative industries, hospitality, and international trade. We also serve a large private client base including UHNWIs and non-doms.'],
          ['q'=>'How quickly can we switch to Halcyon Partners?','a'=>'Our dedicated onboarding team can typically complete a full transition within 3–4 weeks — including authority transfers with HMRC, Companies House filings, software migrations, and retrieval of records from your previous accountant.'],
        ];
        foreach ($faqs as $fi => $faq):?>
        <div class="ac-faq-item">
          <div class="ac-faq-q" aria-expanded="false" role="button" tabindex="0">
            <?php echo esc_html($faq['q']); ?>
            <span class="ac-faq-icon">+</span>
          </div>
          <div class="ac-faq-a">
            <div class="ac-faq-a-inner"><?php echo esc_html($faq['a']); ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <div class="ac-faq-cta">
        <h3>Ready to take control of your finances?</h3>
        <p>Book a complimentary 30-minute discovery call with one of our partners. No commitment, no sales pressure — just honest advice.</p>
        <div class="ac-faq-contact">
          <a href="tel:+442072341994">📞 +44 (0)20 7234 1994</a>
          <a href="mailto:hello@halcyonpartners.co.uk">✉ hello@halcyonpartners.co.uk</a>
          <a href="#">📍 8 Finsbury Square, London EC2A 1AF</a>
        </div>
        <a href="#enquiry" class="ac-btn ac-btn-gold">Book Free Consultation</a>
      </div>
    </div>
  </div>
</section>

<!-- ENQUIRY -->
<section class="ac-enquiry ac-section" id="enquiry">
  <div class="ac-container">
    <div class="ac-section-header">
      <span class="ac-tag">Get Started</span>
      <h2 class="ac-heading">Book Your <em>Free</em> Consultation</h2>
      <p class="ac-lead" style="margin-top:16px;">Complete the form and a partner will be in touch within one business day to arrange your complimentary 30-minute discovery call.</p>
    </div>
    <div class="ac-form-wrapper">
      <div class="ac-form-success" id="ac-success">
        <h3>Enquiry Received</h3>
        <p>A partner will contact you within one business day to arrange your consultation.</p>
      </div>
      <form id="ac-enquiry-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <?php wp_nonce_field('tf_ac_enquiry','tf_ac_nonce'); ?>
        <input type="hidden" name="action" value="tf_ac_enquiry">
        <div class="ac-form-grid">
          <div class="ac-form-group">
            <label for="ac-name">Your Name *</label>
            <input type="text" id="ac-name" name="ac_name" placeholder="Richard Halcyon" required>
          </div>
          <div class="ac-form-group">
            <label for="ac-company">Company Name</label>
            <input type="text" id="ac-company" name="ac_company" placeholder="Acme Ltd">
          </div>
          <div class="ac-form-group">
            <label for="ac-email">Email Address *</label>
            <input type="email" id="ac-email" name="ac_email" placeholder="richard@acme.co.uk" required>
          </div>
          <div class="ac-form-group">
            <label for="ac-phone">Phone Number</label>
            <input type="tel" id="ac-phone" name="ac_phone" placeholder="+44 (0)20 7000 0000">
          </div>
          <div class="ac-form-group">
            <label for="ac-service">Service Required *</label>
            <select id="ac-service" name="ac_service" required>
              <option value="">Select primary need</option>
              <option value="accounts">Annual Accounts & Tax</option>
              <option value="vat">VAT & Indirect Tax</option>
              <option value="payroll">Payroll Services</option>
              <option value="rd">R&D Tax Relief</option>
              <option value="management">Management Accounts</option>
              <option value="personal">Personal Tax / Self-Assessment</option>
              <option value="corporate">Corporate Finance / M&A</option>
              <option value="other">General Enquiry</option>
            </select>
          </div>
          <div class="ac-form-group">
            <label for="ac-turnover">Annual Turnover (approx)</label>
            <select id="ac-turnover" name="ac_turnover">
              <option value="">Select range</option>
              <option value="pre">Pre-revenue / startup</option>
              <option value="<250k">Under £250k</option>
              <option value="250-1m">£250k – £1m</option>
              <option value="1-5m">£1m – £5m</option>
              <option value="5-20m">£5m – £20m</option>
              <option value="20m+">£20m+</option>
            </select>
          </div>
          <div class="ac-form-group full">
            <label for="ac-notes">Tell Us More</label>
            <textarea id="ac-notes" name="ac_notes" placeholder="Please share any relevant background — industry, current accountant, specific challenges, or upcoming deadlines we should be aware of…"></textarea>
          </div>
        </div>
        <div class="ac-form-actions">
          <button type="submit" class="ac-btn ac-btn-gold">Book Consultation</button>
          <p class="ac-form-note">All information is treated in confidence. Regulated by ICAEW and ACCA.</p>
        </div>
      </form>
    </div>
  </div>
</section>

<!-- FOOTER -->
<footer class="ac-footer">
  <div class="ac-container">
    <div class="ac-footer-inner">
      <div class="ac-footer-brand">
        <h3>Halcyon Partners</h3>
        <span>Chartered Accountants · Est. 1994</span>
        <p>Proactive accountancy and financial advisory for growth businesses and private clients across the UK. ICAEW member firm. FCA authorised. ACCA accredited.</p>
      </div>
      <div class="ac-footer-col">
        <h4>Services</h4>
        <ul>
          <li><a href="#">Statutory Accounts</a></li>
          <li><a href="#">Corporate Tax</a></li>
          <li><a href="#">VAT & Indirect Tax</a></li>
          <li><a href="#">Personal Tax</a></li>
          <li><a href="#">Financial Advisory</a></li>
        </ul>
      </div>
      <div class="ac-footer-col">
        <h4>Contact</h4>
        <ul>
          <li><a href="tel:+442072341994">+44 (0)20 7234 1994</a></li>
          <li><a href="mailto:hello@halcyonpartners.co.uk">hello@halcyonpartners.co.uk</a></li>
          <li><a href="#">8 Finsbury Square</a></li>
          <li><a href="#">London EC2A 1AF</a></li>
        </ul>
      </div>
    </div>
    <div class="ac-footer-bottom">
      <p>© <?php echo date('Y'); ?> Halcyon Partners LLP. Registered in England No. OC341294. Authorised and regulated by the FCA.</p>
      <a href="#">Privacy Policy</a>
    </div>
  </div>
</footer>

<script>
(function(){
  // ---- FAQ ----
  document.querySelectorAll('.ac-faq-q').forEach(function(btn){
    btn.addEventListener('click',function(){
      var item=this.closest('.ac-faq-item'),open=item.classList.contains('open');
      document.querySelectorAll('.ac-faq-item.open').forEach(function(o){
        o.classList.remove('open');
        o.querySelector('.ac-faq-q').setAttribute('aria-expanded','false');
      });
      if(!open){item.classList.add('open');this.setAttribute('aria-expanded','true');}
    });
    btn.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();this.click();}});
  });

  // ---- Animated counters ----
  var easeOut=function(t){return 1-Math.pow(1-t,3);};
  var obs=new IntersectionObserver(function(entries){
    entries.forEach(function(entry){
      if(!entry.isIntersecting)return;
      var el=entry.target;
      var raw=el.getAttribute('data-target')||'';
      var num=parseFloat(raw.replace(/[^0-9.]/g,''));
      if(isNaN(num)){obs.unobserve(el);return;}
      var isFloat=raw.indexOf('.')!==-1;
      var dur=1400,start=null;
      function tick(now){
        if(!start)start=now;
        var p=Math.min((now-start)/dur,1);
        var v=easeOut(p)*num;
        var prefix=raw.match(/^[£$€]/)?raw[0]:'';
        var suffix=raw.replace(/^[£$€]?[0-9.,]+/,'');
        el.textContent=prefix+(isFloat?v.toFixed(1):Math.floor(v).toLocaleString())+suffix;
        if(p<1)requestAnimationFrame(tick);
        else el.textContent=raw;
      }
      requestAnimationFrame(tick);
      obs.unobserve(el);
    });
  },{threshold:.4});
  document.querySelectorAll('.ac-stat-number').forEach(function(c){obs.observe(c);});

  // ---- Form ----
  var form=document.getElementById('ac-enquiry-form');
  var succ=document.getElementById('ac-success');
  if(form){form.addEventListener('submit',function(e){e.preventDefault();form.style.display='none';succ.style.display='block';});}
})();
</script>
</body>
</html>
</div><!-- .page-template-page-accountant -->
<?php get_footer(); ?>
