<?php
/**
 * Template Name: Acupuncturist
 *
 * Premium landing page for acupuncturists and TCM practitioners.
 * Palette: deep jade #1B4D3E / soft gold #D4A843 / pale cloud #F2EDE4 / warm white #FAF9F6 / terracotta #C97B4B
 * Fonts: Cinzel + Lato
 * Namespace: --ac-*
 *
 * @package ThemeFlex
 */

if ( ! defined( 'ABSPATH' ) ) exit;

srand( crc32( get_the_permalink() ) );

$ac_treatments = [
    [ 'icon' => '🧘', 'title' => 'Pain Management',        'desc' => 'Effective acupuncture for back pain, neck pain, sciatica, arthritis and chronic musculoskeletal conditions.' ],
    [ 'icon' => '😴', 'title' => 'Stress & Anxiety',       'desc' => 'Calming treatments that regulate the nervous system, reduce cortisol and restore emotional equilibrium.' ],
    [ 'icon' => '🌙', 'title' => 'Insomnia & Sleep',       'desc' => 'Address the root causes of poor sleep through targeted point selection and lifestyle guidance.' ],
    [ 'icon' => '🤰', 'title' => 'Fertility & IVF Support','desc' => 'Specialist acupuncture to support natural conception and optimise IVF outcomes before, during and after treatment.' ],
    [ 'icon' => '💆', 'title' => 'Migraines & Headaches',  'desc' => 'Evidence-based acupuncture protocols recognised by NICE for the prevention of chronic headache and migraine.' ],
    [ 'icon' => '🫁', 'title' => 'Digestive Health',        'desc' => 'Treatment for IBS, bloating, nausea, acid reflux and other functional gastrointestinal conditions.' ],
    [ 'icon' => '♀️', 'title' => "Women's Health",         'desc' => 'Hormonal balance, menstrual irregularities, PCOS, endometriosis and menopause support through TCM.' ],
    [ 'icon' => '⚡', 'title' => 'Fatigue & ME/CFS',       'desc' => 'Gentle, restorative treatment protocols designed specifically for post-viral fatigue and chronic exhaustion.' ],
];

$ac_conditions = [
    'Back Pain','Neck & Shoulder Pain','Sciatica','Fibromyalgia','Arthritis','Sports Injuries',
    'Anxiety & Depression','Stress','Insomnia','Migraines','Headaches','Fatigue',
    'IBS & Digestive Issues','Fertility','IVF Support','PCOS','Endometriosis','Menopause',
    'Immune Support','Post-COVID Recovery','Chemotherapy Support',
];

$ac_steps = [
    [ 'num' => '01', 'title' => 'Initial Consultation',  'desc' => 'A 75-minute first appointment covering your full health history, TCM tongue and pulse diagnosis.' ],
    [ 'num' => '02', 'title' => 'Treatment Protocol',    'desc' => 'A personalised acupuncture treatment with typically 10–20 fine needles retained for 20–30 minutes.' ],
    [ 'num' => '03', 'title' => 'Adjunct Therapies',     'desc' => 'May include moxibustion, cupping therapy, gua sha or tui na massage depending on your presentation.' ],
    [ 'num' => '04', 'title' => 'Herbal Medicine',       'desc' => 'Bespoke Chinese herbal prescriptions formulated and dispensed in-house to complement acupuncture.' ],
    [ 'num' => '05', 'title' => 'Lifestyle Guidance',    'desc' => 'TCM dietary advice, Qi Gong exercises and self-care strategies to support your healing between sessions.' ],
];

$ac_gallery = [
    [ 'label' => 'Treatment Room',     'c1' => '#1B4D3E', 'c2' => '#0f3028' ],
    [ 'label' => 'Herbal Dispensary',  'c1' => '#C97B4B', 'c2' => '#a05830' ],
    [ 'label' => 'Cupping Therapy',    'c1' => '#D4A843', 'c2' => '#a07820' ],
    [ 'label' => 'Moxa Therapy',       'c1' => '#8B6BA0', 'c2' => '#6a4a80' ],
    [ 'label' => 'Relaxation Suite',   'c1' => '#4A7B6F', 'c2' => '#2a5b50' ],
    [ 'label' => 'Pulse Diagnosis',    'c1' => '#2C3E50', 'c2' => '#1a2b3a' ],
];

$ac_packages = [
    [
        'name'     => 'First Visit',
        'price'    => '£95',
        'sub'      => '75-minute consultation',
        'featured' => false,
        'items'    => [ 'Full health history intake', 'TCM pulse & tongue diagnosis', 'First acupuncture treatment', 'Personalised treatment plan', 'Lifestyle advice & resources' ],
    ],
    [
        'name'     => 'Course of 5',
        'price'    => '£350',
        'sub'      => 'Most popular · save £25',
        'featured' => true,
        'items'    => [ '5 × 45-min follow-up sessions', 'Personalised point protocol', 'Progress reviews each visit', 'Adjunct therapies as needed', 'Email support between sessions', 'TCM dietary guidance' ],
    ],
    [
        'name'     => 'Monthly Maintenance',
        'price'    => '£75',
        'sub'      => 'Per session · ongoing',
        'featured' => false,
        'items'    => [ '45-min monthly treatment', 'Preventative health focus', 'Seasonal protocol adjustments', 'Flexible scheduling', 'Priority booking access' ],
    ],
];

$ac_testimonials = [
    [ 'name' => 'Helen K.',   'loc' => 'Bristol', 'stars' => 5, 'text' => 'After ten years of chronic back pain I\'d tried everything. Six sessions of acupuncture have reduced my pain by 80%. I wish I\'d come sooner — truly remarkable.' ],
    [ 'name' => 'James W.',   'loc' => 'Bristol', 'stars' => 5, 'text' => 'I was deeply sceptical but came at my wife\'s insistence. My insomnia has completely resolved after four sessions. The science clearly works — I\'m a convert.' ],
    [ 'name' => 'Amelia T.',  'loc' => 'Bristol', 'stars' => 5, 'text' => 'Acupuncture during IVF was recommended by my consultant. We had a successful transfer on the second cycle. I genuinely believe these sessions made the difference.' ],
];

// Meridian/energy line particles
$ac_particles = [];
$qi_chars = ['○','◎','◯','⊙','⬡','✦','∘','⊕','◇','⊗','·','∙'];
for ($i = 0; $i < 16; $i++) {
    $ac_particles[] = [
        'char'  => $qi_chars[array_rand($qi_chars)],
        'x'     => rand(3,97),
        'y'     => rand(3,95),
        'size'  => rand(8,20),
        'op'    => rand(8,28)/100,
        'dur'   => rand(70,140)/10,
        'delay' => rand(0,90)/10,
        'depth' => rand(10,45)/10,
    ];
}

// Herb jar colors
$herb_jars = [
    ['c'=>'#8B6040','label'=>'Ginger'],
    ['c'=>'#2E5A2E','label'=>'Astragalus'],
    ['c'=>'#6B3A2A','label'=>'Reishi'],
    ['c'=>'#C97B4B','label'=>'Turmeric'],
    ['c'=>'#1B4D3E','label'=>'Dong Quai'],
    ['c'=>'#5A3A6A','label'=>'Goji'],
    ['c'=>'#3A6040','label'=>'Schisandra'],
];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;500;600;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
<style>
/* =========================================================
   ACUPUNCTURIST — CSS Custom Properties  (--ac-* namespace)
   ========================================================= */
:root {
    --ac-jade:    #1B4D3E;
    --ac-jade-d:  #0f3028;
    --ac-gold:    #D4A843;
    --ac-gold-d:  #a07820;
    --ac-cloud:   #F2EDE4;
    --ac-warm:    #FAF9F6;
    --ac-terra:   #C97B4B;
    --ac-text:    #2C2C24;
    --ac-muted:   #6b6b5a;
    --ac-ff-head: 'Cinzel', Georgia, serif;
    --ac-ff-body: 'Lato', system-ui, sans-serif;
    --ac-radius:  8px;
    --ac-shadow:  0 8px 32px rgba(27,77,62,.1);
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{font-family:var(--ac-ff-body);color:var(--ac-text);background:var(--ac-warm);-webkit-font-smoothing:antialiased}
img{max-width:100%;height:auto;display:block}
a{color:inherit;text-decoration:none}
ul{list-style:none}

/* ── Utility ── */
.ac-container{max-width:1160px;margin:0 auto;padding:0 24px}
.ac-section{padding:90px 0}
.ac-eyebrow{font-family:var(--ac-ff-body);font-size:.7rem;font-weight:700;letter-spacing:.22em;text-transform:uppercase;color:var(--ac-gold);margin-bottom:14px;display:block}
.ac-heading{font-family:var(--ac-ff-head);font-size:clamp(1.8rem,3.8vw,3rem);font-weight:500;line-height:1.2;color:var(--ac-jade);margin-bottom:20px;letter-spacing:.04em}
.ac-heading--light{color:#fff}
.ac-lead{font-size:.98rem;line-height:1.8;color:var(--ac-muted);max-width:640px;font-weight:300}
.ac-btn{display:inline-flex;align-items:center;gap:8px;padding:13px 30px;border-radius:3px;font-family:var(--ac-ff-body);font-size:.82rem;font-weight:700;letter-spacing:.1em;cursor:pointer;transition:all .25s;border:1.5px solid transparent;text-transform:uppercase}
.ac-btn--primary{background:var(--ac-jade);color:#fff;border-color:var(--ac-jade)}
.ac-btn--primary:hover{background:var(--ac-jade-d);transform:translateY(-2px)}
.ac-btn--gold{background:var(--ac-gold);color:#fff;border-color:var(--ac-gold)}
.ac-btn--gold:hover{background:var(--ac-gold-d);transform:translateY(-2px)}
.ac-btn--outline{background:transparent;color:#fff;border-color:rgba(255,255,255,.5)}
.ac-btn--outline:hover{background:rgba(255,255,255,.08);border-color:#fff}
.ac-btn--outline-jade{background:transparent;color:var(--ac-jade);border-color:var(--ac-jade)}
.ac-btn--outline-jade:hover{background:var(--ac-jade);color:#fff}
.ac-center{text-align:center}
.ac-center .ac-lead{margin-inline:auto}

/* =========================================================
   HERO — treatment room with Eastern aesthetic
   ========================================================= */
.ac-hero{position:relative;min-height:100vh;overflow:hidden;background:var(--ac-jade);display:flex;align-items:center}

/* Room background */
.ac-room{position:absolute;inset:0;overflow:hidden}

/* Natural wall — warm rice paper texture */
.ac-room__wall{position:absolute;inset:0;background:linear-gradient(180deg,#f5efe2,#ede5d5)}
.ac-room__wall::before{content:'';position:absolute;inset:0;background-image:repeating-linear-gradient(0deg,rgba(180,140,80,.04) 0,rgba(180,140,80,.04) 1px,transparent 1px,transparent 60px),repeating-linear-gradient(90deg,rgba(180,140,80,.04) 0,rgba(180,140,80,.04) 1px,transparent 1px,transparent 60px)}
.ac-room__wall::after{content:'';position:absolute;inset:0;background:radial-gradient(ellipse at 65% 50%,rgba(212,168,67,.06) 0%,transparent 55%)}

/* Bamboo divider on left */
.ac-bamboo{position:absolute;left:4%;top:0;bottom:0;width:50px;display:flex;gap:8px;align-items:stretch}
.ac-bamboo__stalk{flex:1;background:repeating-linear-gradient(180deg,#5a8a40 0,#5a8a40 60px,#4a7a30 60px,#4a7a30 62px,#6a9a50 62px,#6a9a50 120px);border-radius:3px;opacity:.35}

/* Tatami-style floor */
.ac-room__floor{position:absolute;bottom:0;left:0;right:0;height:20%;background:linear-gradient(180deg,#c8a870,#a88850)}
.ac-room__floor::before{content:'';position:absolute;inset:0;background-image:repeating-linear-gradient(90deg,rgba(255,255,255,.08) 0,rgba(255,255,255,.08) 1px,transparent 1px,transparent 80px),repeating-linear-gradient(0deg,rgba(0,0,0,.05) 0,rgba(0,0,0,.05) 1px,transparent 1px,transparent 40px)}
.ac-room__floor::after{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,transparent,rgba(255,255,255,.3),transparent)}
.ac-room__skirting{position:absolute;bottom:20%;left:0;right:0;height:6px;background:linear-gradient(180deg,#8a6a40,#6a4a20)}

/* Treatment table -->*/
.ac-table{position:absolute;bottom:20%;left:50%;transform:translateX(-50%);width:300px;pointer-events:none}
.ac-table__legs{display:flex;justify-content:space-between;padding:0 20px;height:60px}
.ac-table__leg{width:10px;background:linear-gradient(90deg,#7a5a30,#5a3a18);border-radius:2px}
.ac-table__frame{height:10px;background:linear-gradient(180deg,#8a6a40,#6a4a20)}
.ac-table__surface{height:16px;background:linear-gradient(180deg,#f0e8d8,#e8dcc8);border-radius:3px 3px 0 0;position:relative;box-shadow:0 4px 12px rgba(0,0,0,.15)}
.ac-table__surface::before{content:'';position:absolute;top:4px;left:20px;right:20px;height:2px;background:rgba(255,255,255,.4);border-radius:1px}

/* Patient lying down */
.ac-patient{position:absolute;bottom:20%;left:50%;transform:translateX(-50%);pointer-events:none;width:300px}
.ac-patient__body{position:absolute;bottom:88px;left:50%;transform:translateX(-50%);display:flex;align-items:center;gap:2px}
.ac-patient__head{width:28px;height:28px;background:radial-gradient(circle at 40% 35%,#f0c890,#d4a060);border-radius:50%;flex-shrink:0}
.ac-patient__torso{width:80px;height:20px;background:linear-gradient(180deg,#e8e0d8,#d8cfc4);border-radius:4px 2px 2px 4px}
.ac-patient__legs{width:100px;height:14px;background:linear-gradient(180deg,#c8b8a0,#b8a890);border-radius:0 4px 4px 0}

/* Needles on patient */
.ac-needle{position:absolute;width:1px;height:14px;background:linear-gradient(180deg,rgba(192,192,192,.8),rgba(210,210,210,.6));border-top:3px solid rgba(192,192,192,.9)}

/* Practitioner figure */
.ac-practitioner{position:absolute;bottom:20%;right:18%;display:flex;flex-direction:column;align-items:center;pointer-events:none}
.ac-practitioner__head{width:28px;height:30px;background:radial-gradient(circle at 40% 35%,#ffe0b2,#d4a070);border-radius:50%;position:relative;margin-bottom:2px}
.ac-practitioner__head::before{content:'';position:absolute;top:-8px;left:50%;transform:translateX(-50%);width:30px;height:12px;background:#2C2C24;border-radius:50% 50% 0 0;clip-path:ellipse(50% 100% at 50% 100%)}
.ac-practitioner__body{width:42px;height:60px;background:linear-gradient(180deg,#fff,#f5f0e8);border-radius:4px 4px 0 0;position:relative}
.ac-practitioner__body::before{content:'';position:absolute;top:0;left:50%;transform:translateX(-50%);width:30px;height:60px;background:linear-gradient(180deg,var(--ac-jade),var(--ac-jade-d));border-radius:2px;opacity:.9}

/* Herbal shelf */
.ac-herb-shelf{position:absolute;top:16%;right:7%;width:150px}
.ac-herb-shelf__board{height:8px;background:linear-gradient(180deg,#8a6a40,#6a4a20);border-radius:1px;box-shadow:2px 2px 6px rgba(0,0,0,.2)}
.ac-herb-shelf__items{display:flex;gap:4px;align-items:flex-end;height:52px;padding:0 6px}
.ac-herb-jar{border-radius:4px 4px 6px 6px;position:relative}
.ac-herb-jar::before{content:'';position:absolute;top:-6px;left:50%;transform:translateX(-50%);width:8px;height:8px;background:#555;border-radius:50% 50% 0 0}

/* Scroll artwork on wall */
.ac-scroll{position:absolute;top:8%;right:25%;width:60px;height:160px}
.ac-scroll__top{height:10px;background:linear-gradient(90deg,#8a6a40,#c8a870,#8a6a40);border-radius:3px}
.ac-scroll__body{width:100%;height:140px;background:linear-gradient(180deg,#f5e8d0,#ede0c0);padding:10px 8px;display:flex;flex-direction:column;align-items:center;gap:6px}
.ac-scroll__line{height:1px;width:80%;background:rgba(100,70,20,.3)}
.ac-scroll__char{font-size:1.8rem;color:rgba(27,77,62,.5);line-height:1;font-family:serif}
.ac-scroll__bottom{height:10px;background:linear-gradient(90deg,#8a6a40,#c8a870,#8a6a40);border-radius:3px}

/* Floating Qi particles */
.ac-particle{position:absolute;font-size:var(--sz);opacity:var(--op);color:var(--ac-gold);animation:ac-qi var(--dur)s ease-in-out var(--delay)s infinite alternate;pointer-events:none;will-change:transform}
@keyframes ac-qi{0%{transform:translateY(0) scale(1)}50%{transform:translateY(-10px) scale(1.05)}100%{transform:translateY(-18px) scale(.95) rotate(8deg)}}

/* Dark overlay for text */
.ac-hero__overlay{position:absolute;inset:0;background:linear-gradient(90deg,rgba(15,48,40,.94) 0%,rgba(15,48,40,.78) 45%,rgba(15,48,40,.15) 70%,transparent 100%)}

/* Hero content */
.ac-hero__content{position:relative;z-index:10;padding:0 5%;max-width:580px}
.ac-hero__badge{display:inline-block;background:rgba(212,168,67,.15);border:1px solid rgba(212,168,67,.35);color:var(--ac-gold);font-size:.68rem;font-weight:700;letter-spacing:.18em;text-transform:uppercase;padding:6px 16px;border-radius:2px;margin-bottom:24px;backdrop-filter:blur(4px);font-family:var(--ac-ff-body)}
.ac-hero__title{font-family:var(--ac-ff-head);font-size:clamp(2.2rem,5vw,4rem);font-weight:500;line-height:1.1;color:#fff;margin-bottom:8px;letter-spacing:.06em}
.ac-hero__sub{font-family:var(--ac-ff-head);font-size:clamp(.9rem,1.5vw,1.1rem);font-weight:400;letter-spacing:.12em;color:var(--ac-gold);margin-bottom:24px;text-transform:uppercase}
.ac-hero__body{font-size:.93rem;line-height:1.8;color:rgba(255,255,255,.78);font-weight:300;margin-bottom:36px;max-width:480px}
.ac-hero__ctas{display:flex;flex-wrap:wrap;gap:12px}
.ac-hero__trust{display:flex;flex-wrap:wrap;gap:10px;margin-top:28px}
.ac-hero__trust-item{font-size:.76rem;color:rgba(255,255,255,.65);font-weight:400;display:flex;align-items:center;gap:6px}
.ac-hero__trust-item::before{content:'○';color:var(--ac-gold);font-size:.6rem}

/* Trust bar */
.ac-trust{background:var(--ac-jade-d);padding:20px 0;border-top:1px solid rgba(212,168,67,.2)}
.ac-trust__inner{display:flex;flex-wrap:wrap;justify-content:center;gap:6px 28px}
.ac-trust__item{font-size:.78rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.7);display:flex;align-items:center;gap:8px;font-family:var(--ac-ff-body)}
.ac-trust__item::before{content:'✦';color:var(--ac-gold);font-size:.6rem}

/* =========================================================
   TREATMENTS
   ========================================================= */
.ac-treatments{background:var(--ac-warm)}
.ac-treatments__grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:24px;margin-top:52px}
.ac-treat-card{background:#fff;border-radius:var(--ac-radius);padding:30px 24px;border:1px solid rgba(27,77,62,.08);transition:all .3s;position:relative;overflow:hidden}
.ac-treat-card::after{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:linear-gradient(180deg,var(--ac-jade),var(--ac-gold));transform:scaleY(0);transition:transform .3s;transform-origin:top}
.ac-treat-card:hover{box-shadow:var(--ac-shadow);transform:translateY(-4px)}
.ac-treat-card:hover::after{transform:scaleY(1)}
.ac-treat-card__icon{font-size:1.8rem;margin-bottom:12px;display:block}
.ac-treat-card__title{font-family:var(--ac-ff-head);font-size:1rem;font-weight:500;letter-spacing:.04em;color:var(--ac-jade);margin-bottom:8px}
.ac-treat-card__desc{font-size:.86rem;line-height:1.72;color:var(--ac-muted);font-weight:300}

/* =========================================================
   CONDITIONS
   ========================================================= */
.ac-conditions{background:var(--ac-cloud)}
.ac-conditions__grid{display:grid;grid-template-columns:1fr 1fr;gap:52px;align-items:center}
.ac-conditions__visual{position:relative;height:360px;border-radius:var(--ac-radius);overflow:hidden;background:linear-gradient(160deg,var(--ac-warm),#ede5d5)}
/* Meridian diagram art */
.ac-meridian{position:relative;width:100%;height:100%;display:flex;align-items:center;justify-content:center}
.ac-body-outline{position:relative;display:flex;flex-direction:column;align-items:center;gap:3px}
.ac-body-outline__head{width:40px;height:46px;background:none;border:2px solid rgba(27,77,62,.3);border-radius:50%;position:relative}
.ac-body-outline__neck{width:14px;height:12px;border-left:2px solid rgba(27,77,62,.3);border-right:2px solid rgba(27,77,62,.3)}
.ac-body-outline__torso{width:60px;height:76px;border:2px solid rgba(27,77,62,.3);border-radius:4px}
.ac-body-outline__hips{width:66px;height:24px;border:2px solid rgba(27,77,62,.3);border-radius:4px}
.ac-body-outline__legs{display:flex;gap:8px}
.ac-body-outline__leg{width:22px;height:80px;border:2px solid rgba(27,77,62,.3);border-radius:0 0 6px 6px}
/* Meridian lines */
.ac-mline{position:absolute;background:rgba(27,77,62,.2);border-radius:1px}
/* Acupoints */
.ac-point{position:absolute;width:10px;height:10px;background:var(--ac-gold);border-radius:50%;border:2px solid #fff;box-shadow:0 0 6px rgba(212,168,67,.6);animation:ac-glow 2.5s ease-in-out infinite}
@keyframes ac-glow{0%,100%{box-shadow:0 0 6px rgba(212,168,67,.6)}50%{box-shadow:0 0 14px rgba(212,168,67,.9)}}
.ac-conditions__tags{margin-top:16px}
.ac-conditions__tag{display:inline-block;background:#fff;border:1px solid rgba(27,77,62,.12);color:var(--ac-jade);font-size:.78rem;padding:5px 12px;border-radius:20px;margin:3px;transition:all .22s;cursor:default;font-weight:400}
.ac-conditions__tag:hover{background:var(--ac-jade);color:#fff;border-color:var(--ac-jade)}

/* =========================================================
   APPROACH
   ========================================================= */
.ac-approach{background:var(--ac-jade);padding:90px 0}
.ac-approach .ac-eyebrow{color:var(--ac-gold)}
.ac-approach__grid{display:grid;grid-template-columns:repeat(5,1fr);gap:20px;margin-top:52px;position:relative}
.ac-approach__grid::before{content:'';position:absolute;top:26px;left:8%;right:8%;height:1px;background:linear-gradient(90deg,transparent,rgba(212,168,67,.3),rgba(212,168,67,.3),transparent)}
.ac-astep{text-align:center;padding:28px 14px}
.ac-astep__num{font-family:var(--ac-ff-head);font-size:2.5rem;font-weight:400;color:rgba(212,168,67,.25);line-height:1;margin-bottom:-10px;letter-spacing:.04em}
.ac-astep__title{font-family:var(--ac-ff-head);font-size:.95rem;font-weight:500;color:#fff;letter-spacing:.06em;margin-bottom:10px;position:relative;z-index:1}
.ac-astep__desc{font-size:.82rem;line-height:1.65;color:rgba(255,255,255,.58);font-weight:300}

/* =========================================================
   GALLERY
   ========================================================= */
.ac-gallery{background:#fff}
.ac-gallery__grid{display:grid;grid-template-columns:repeat(3,1fr);grid-template-rows:220px 220px;gap:10px;margin-top:52px}
.ac-gallery__item{border-radius:var(--ac-radius);overflow:hidden;position:relative;cursor:pointer}
.ac-gallery__item:first-child{grid-column:span 2}
.ac-gallery__item:nth-child(5){grid-column:span 2}
.ac-gallery__art{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-family:var(--ac-ff-head);font-size:.85rem;letter-spacing:.1em;color:rgba(255,255,255,.7);position:relative;overflow:hidden}
.ac-gallery__art::before{content:'';position:absolute;inset:0;background:inherit;filter:brightness(.68);transition:filter .4s}
.ac-gallery__item:hover .ac-gallery__art::before{filter:brightness(.48)}
.ac-gallery__label{position:relative;z-index:1;background:rgba(0,0,0,.35);padding:7px 16px;border-radius:2px}

/* =========================================================
   COUNTERS
   ========================================================= */
.ac-counters{background:linear-gradient(135deg,var(--ac-gold),var(--ac-gold-d));padding:80px 0}
.ac-counters__grid{display:grid;grid-template-columns:repeat(4,1fr);gap:40px;text-align:center}
.ac-counter__val{font-family:var(--ac-ff-head);font-size:clamp(2.5rem,4.5vw,4rem);font-weight:500;color:#fff;line-height:1;letter-spacing:.04em}
.ac-counter__label{font-family:var(--ac-ff-body);font-size:.72rem;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.78);margin-top:8px;font-weight:700}

/* =========================================================
   ABOUT
   ========================================================= */
.ac-about{background:var(--ac-cloud)}
.ac-about__grid{display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:center}
.ac-about__visual{position:relative}
.ac-credential-card{width:100%;max-width:380px;background:var(--ac-jade);border-radius:var(--ac-radius);padding:36px 32px;box-shadow:var(--ac-shadow),0 0 0 1px rgba(212,168,67,.15)}
.ac-credential-card__top{display:flex;align-items:center;gap:14px;margin-bottom:28px;padding-bottom:20px;border-bottom:1px solid rgba(255,255,255,.1)}
.ac-credential-card__seal{width:48px;height:48px;background:var(--ac-gold);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.4rem}
.ac-credential-card__name{font-family:var(--ac-ff-head);font-size:1rem;letter-spacing:.06em;color:#fff}
.ac-credential-card__title{font-size:.7rem;color:rgba(255,255,255,.55);margin-top:3px;letter-spacing:.04em}
.ac-cred-row{display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;padding-bottom:14px;border-bottom:1px solid rgba(255,255,255,.06)}
.ac-cred-row:last-child{border-bottom:none;margin-bottom:0;padding-bottom:0}
.ac-cred-row__label{font-size:.72rem;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.5);font-weight:700}
.ac-cred-row__val{font-size:.85rem;color:#fff;font-weight:300}
.ac-about__badge{position:absolute;bottom:-16px;right:-16px;background:#fff;border-radius:var(--ac-radius);padding:14px 20px;box-shadow:var(--ac-shadow);border-left:3px solid var(--ac-gold);min-width:140px}
.ac-about__badge-val{font-family:var(--ac-ff-head);font-size:1.6rem;color:var(--ac-jade);line-height:1}
.ac-about__badge-label{font-size:.7rem;letter-spacing:.08em;text-transform:uppercase;color:var(--ac-muted);margin-top:4px}
.ac-about__content .ac-lead{margin-bottom:20px}
.ac-about__bio{font-size:.93rem;line-height:1.8;color:var(--ac-muted);font-weight:300;margin-bottom:16px}
.ac-about__quote{font-family:var(--ac-ff-head);font-size:1.05rem;font-weight:400;color:var(--ac-jade);border-left:2px solid var(--ac-gold);padding-left:18px;margin:24px 0;line-height:1.6;letter-spacing:.02em}

/* =========================================================
   PACKAGES
   ========================================================= */
.ac-packages{background:#fff}
.ac-packages__grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:52px}
.ac-pkg{background:var(--ac-warm);border-radius:var(--ac-radius);padding:36px 28px;border:1.5px solid rgba(27,77,62,.1);transition:all .3s;position:relative}
.ac-pkg:hover{box-shadow:var(--ac-shadow)}
.ac-pkg--featured{border-color:var(--ac-jade);background:linear-gradient(180deg,rgba(27,77,62,.04),var(--ac-warm))}
.ac-pkg--featured::before{content:'Most Popular';position:absolute;top:-14px;left:50%;transform:translateX(-50%);background:var(--ac-jade);color:#fff;font-size:.62rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;padding:4px 16px;border-radius:20px;white-space:nowrap;font-family:var(--ac-ff-body)}
.ac-pkg__name{font-family:var(--ac-ff-head);font-size:1.3rem;letter-spacing:.06em;color:var(--ac-jade);margin-bottom:4px}
.ac-pkg__sub{font-size:.78rem;color:var(--ac-muted);margin-bottom:20px;font-weight:300}
.ac-pkg__price{font-family:var(--ac-ff-head);font-size:2.2rem;color:var(--ac-jade);margin-bottom:24px;line-height:1;letter-spacing:.04em}
.ac-pkg__list{display:flex;flex-direction:column;gap:10px;margin-bottom:28px}
.ac-pkg__list li{display:flex;align-items:flex-start;gap:8px;font-size:.86rem;color:var(--ac-text);line-height:1.5;font-weight:300}
.ac-pkg__list li::before{content:'○';color:var(--ac-gold);flex-shrink:0;font-size:.7rem;margin-top:3px}

/* =========================================================
   TESTIMONIALS
   ========================================================= */
.ac-testimonials{background:var(--ac-cloud)}
.ac-testi-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:52px}
.ac-testi{background:#fff;border-radius:var(--ac-radius);padding:30px 26px;border-top:2px solid var(--ac-gold);box-shadow:0 4px 16px rgba(27,77,62,.06)}
.ac-testi__stars{color:var(--ac-gold);font-size:.9rem;letter-spacing:2px;margin-bottom:14px}
.ac-testi__text{font-family:var(--ac-ff-head);font-size:.95rem;font-weight:400;line-height:1.7;color:var(--ac-jade);font-style:italic;margin-bottom:18px}
.ac-testi__author{font-size:.78rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--ac-text);font-family:var(--ac-ff-body)}
.ac-testi__loc{font-size:.74rem;color:var(--ac-muted);font-weight:300}

/* =========================================================
   BOOKING
   ========================================================= */
.ac-booking{background:linear-gradient(135deg,var(--ac-jade),var(--ac-jade-d));padding:90px 0}
.ac-booking .ac-eyebrow{color:var(--ac-gold)}
.ac-booking__grid{display:grid;grid-template-columns:1fr 1.6fr;gap:60px;align-items:start;margin-top:52px}
.ac-booking__info-item{display:flex;align-items:flex-start;gap:14px;margin-bottom:22px}
.ac-booking__info-icon{font-size:1.3rem;flex-shrink:0;margin-top:2px}
.ac-booking__info-label{font-size:.7rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.55);margin-bottom:4px;font-family:var(--ac-ff-body)}
.ac-booking__info-text{font-size:.85rem;line-height:1.6;color:rgba(255,255,255,.65);font-weight:300}
.ac-booking__notice{background:rgba(212,168,67,.12);border:1px solid rgba(212,168,67,.3);border-radius:var(--ac-radius);padding:18px;margin-bottom:24px;font-size:.83rem;line-height:1.65;color:rgba(255,255,255,.75);font-weight:300}
.ac-booking__notice strong{color:var(--ac-gold);font-weight:700;display:block;margin-bottom:4px}
.ac-form{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--ac-radius);padding:38px 34px;backdrop-filter:blur(8px)}
.ac-form__row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.ac-form__group{margin-bottom:16px;display:flex;flex-direction:column;gap:6px}
.ac-form__group label{font-size:.7rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.6);font-family:var(--ac-ff-body)}
.ac-form__group input,
.ac-form__group select,
.ac-form__group textarea{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.14);border-radius:3px;padding:11px 14px;font-family:var(--ac-ff-body);font-size:.88rem;color:#fff;outline:none;transition:border-color .25s;width:100%;font-weight:300}
.ac-form__group input::placeholder,
.ac-form__group textarea::placeholder{color:rgba(255,255,255,.3)}
.ac-form__group input:focus,
.ac-form__group select:focus,
.ac-form__group textarea:focus{border-color:var(--ac-gold);background:rgba(255,255,255,.1)}
.ac-form__group select option{background:#0f3028;color:#fff}
.ac-form__group textarea{resize:vertical;min-height:100px}
.ac-form__submit{width:100%;padding:15px;background:var(--ac-gold);border:none;border-radius:3px;font-family:var(--ac-ff-body);font-size:.9rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#fff;cursor:pointer;transition:all .25s;margin-top:6px}
.ac-form__submit:hover{background:var(--ac-gold-d);transform:translateY(-2px)}
.ac-form__consent{font-size:.7rem;color:rgba(255,255,255,.4);margin-top:10px;line-height:1.6;text-align:center;font-weight:300}

/* =========================================================
   FOOTER
   ========================================================= */
.ac-footer{background:#081e16;padding:26px 0}
.ac-footer__inner{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:16px}
.ac-footer__copy{font-size:.76rem;color:rgba(255,255,255,.35);font-weight:300}
.ac-footer__links{display:flex;gap:20px}
.ac-footer__links a{font-size:.76rem;color:rgba(255,255,255,.35);transition:color .2s;font-weight:300}
.ac-footer__links a:hover{color:var(--ac-gold)}

/* =========================================================
   RESPONSIVE
   ========================================================= */
@media(max-width:960px){
    .ac-conditions__grid,.ac-about__grid,.ac-booking__grid{grid-template-columns:1fr}
    .ac-packages__grid,.ac-testi-grid{grid-template-columns:1fr}
    .ac-counters__grid{grid-template-columns:repeat(2,1fr)}
    .ac-approach__grid{grid-template-columns:repeat(3,1fr)}
    .ac-gallery__grid{grid-template-columns:1fr 1fr}
    .ac-gallery__item:first-child,.ac-gallery__item:nth-child(5){grid-column:span 1}
    .ac-approach__grid::before{display:none}
}
@media(max-width:600px){
    .ac-section{padding:60px 0}
    .ac-form__row{grid-template-columns:1fr}
    .ac-approach__grid{grid-template-columns:repeat(2,1fr)}
}
</style>
<?php get_header(); ?>
<div class="ac-page">
>

<!-- ═══════════════════════════════════════════════
     HERO
═══════════════════════════════════════════════ -->
<section class="ac-hero" id="ac-hero">
    <div class="ac-room" aria-hidden="true">
        <div class="ac-room__wall"></div>

        <!-- Bamboo -->
        <div class="ac-bamboo">
            <div class="ac-bamboo__stalk"></div>
            <div class="ac-bamboo__stalk" style="opacity:.2"></div>
            <div class="ac-bamboo__stalk" style="opacity:.28"></div>
        </div>

        <!-- Wall scroll artwork -->
        <div class="ac-scroll">
            <div class="ac-scroll__top"></div>
            <div class="ac-scroll__body">
                <div class="ac-scroll__char">氣</div>
                <?php for($sl=0;$sl<6;$sl++): ?>
                <div class="ac-scroll__line"></div>
                <?php endfor; ?>
            </div>
            <div class="ac-scroll__bottom"></div>
        </div>

        <!-- Herb shelf -->
        <div class="ac-herb-shelf">
            <div class="ac-herb-shelf__items">
                <?php foreach ($herb_jars as $idx => $jar): ?>
                <div class="ac-herb-jar" style="background:<?php echo esc_attr($jar['c']); ?>;width:<?php echo (14+($idx%2)*2); ?>px;height:<?php echo (38+($idx%3)*6); ?>px" title="<?php echo esc_attr($jar['label']); ?>"></div>
                <?php endforeach; ?>
            </div>
            <div class="ac-herb-shelf__board"></div>
        </div>

        <!-- Floor -->
        <div class="ac-room__skirting"></div>
        <div class="ac-room__floor"></div>

        <!-- Treatment table -->
        <div class="ac-table">
            <div class="ac-table__legs">
                <div class="ac-table__leg"></div>
                <div class="ac-table__leg"></div>
            </div>
            <div class="ac-table__frame"></div>
            <div class="ac-table__surface"></div>
        </div>

        <!-- Patient on table -->
        <div class="ac-patient">
            <div class="ac-patient__body">
                <div class="ac-patient__head"></div>
                <div class="ac-patient__torso"></div>
                <div class="ac-patient__legs"></div>
            </div>
            <!-- Needles -->
            <?php
            $needle_pos = [
                ['left'=>'62%','bottom'=>'110px'],
                ['left'=>'67%','bottom'=>'112px'],
                ['left'=>'72%','bottom'=>'110px'],
                ['left'=>'77%','bottom'=>'113px'],
                ['left'=>'58%','bottom'=>'108px'],
            ];
            foreach ($needle_pos as $np): ?>
            <div class="ac-needle" style="left:<?php echo $np['left']; ?>;bottom:<?php echo $np['bottom']; ?>"></div>
            <?php endforeach; ?>
        </div>

        <!-- Practitioner -->
        <div class="ac-practitioner">
            <div class="ac-practitioner__head"></div>
            <div class="ac-practitioner__body"></div>
        </div>

        <!-- Qi particles -->
        <?php foreach ($ac_particles as $p): ?>
        <div class="ac-particle"
             style="left:<?php echo $p['x']; ?>%;top:<?php echo $p['y']; ?>%;--sz:<?php echo $p['size']; ?>px;--op:<?php echo $p['op']; ?>;--dur:<?php echo $p['dur']; ?>;--delay:<?php echo $p['delay']; ?>s"
             data-depth="<?php echo $p['depth']; ?>"><?php echo $p['char']; ?></div>
        <?php endforeach; ?>
    </div>

    <!-- Overlay -->
    <div class="ac-hero__overlay" aria-hidden="true"></div>

    <!-- Content -->
    <div class="ac-container">
        <div class="ac-hero__content">
            <span class="ac-hero__badge">BAcC Registered Acupuncturist · Bristol</span>
            <h1 class="ac-hero__title">Ancient Wisdom.<br>Modern Healing.</h1>
            <p class="ac-hero__sub">Traditional Chinese Acupuncture & Herbal Medicine</p>
            <p class="ac-hero__body">
                Rooted in over 2,500 years of Traditional Chinese Medicine, our evidence-based acupuncture practice helps you find lasting relief from pain, stress, insomnia and a wide range of chronic health conditions — naturally and holistically.
            </p>
            <div class="ac-hero__ctas">
                <a href="#ac-booking" class="ac-btn ac-btn--gold">Book a Consultation</a>
                <a href="#ac-treatments" class="ac-btn ac-btn--outline">What We Treat</a>
            </div>
            <div class="ac-hero__trust">
                <span class="ac-hero__trust-item">BAcC Registered</span>
                <span class="ac-hero__trust-item">NICE-Approved Protocols</span>
                <span class="ac-hero__trust-item">Insurance Accepted</span>
                <span class="ac-hero__trust-item">Herbal Dispensary On-Site</span>
            </div>
        </div>
    </div>
</section>

<!-- Trust bar -->
<div class="ac-trust">
    <div class="ac-container">
        <div class="ac-trust__inner">
            <?php
            $ac_trust = ['BAcC Registered','NICE-Endorsed for Pain & Headache','All Major Insurers Accepted','Fertility Specialist','Herbal Dispensary On-Site','Same-Week Appointments'];
            foreach ($ac_trust as $ti): ?>
            <span class="ac-trust__item"><?php echo esc_html($ti); ?></span>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ═══════════════════════════════════════════════
     TREATMENTS
═══════════════════════════════════════════════ -->
<section class="ac-section ac-treatments" id="ac-treatments">
    <div class="ac-container">
        <div class="ac-center">
            <span class="ac-eyebrow">Specialisms</span>
            <h2 class="ac-heading">Conditions We Treat</h2>
            <p class="ac-lead">TCM treats the whole person — not just the symptom. These are some of the conditions our patients most commonly seek help with.</p>
        </div>
        <div class="ac-treatments__grid">
            <?php foreach ($ac_treatments as $treat): ?>
            <article class="ac-treat-card">
                <span class="ac-treat-card__icon"><?php echo esc_html($treat['icon']); ?></span>
                <h3 class="ac-treat-card__title"><?php echo esc_html($treat['title']); ?></h3>
                <p class="ac-treat-card__desc"><?php echo esc_html($treat['desc']); ?></p>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     CONDITIONS
═══════════════════════════════════════════════ -->
<section class="ac-section ac-conditions" id="ac-conditions">
    <div class="ac-container">
        <div class="ac-conditions__grid">
            <div>
                <span class="ac-eyebrow">Full Conditions List</span>
                <h2 class="ac-heading">We Help With Over 40 Conditions</h2>
                <p class="ac-lead" style="margin-bottom:24px">Acupuncture has a broad therapeutic reach. If you don't see your condition below, please get in touch — we're happy to discuss whether treatment may help.</p>
                <div class="ac-conditions__tags">
                    <?php foreach ($ac_conditions as $cond): ?>
                    <span class="ac-conditions__tag"><?php echo esc_html($cond); ?></span>
                    <?php endforeach; ?>
                </div>
                <div style="margin-top:30px">
                    <a href="#ac-booking" class="ac-btn ac-btn--primary">Book Your First Session →</a>
                </div>
            </div>
            <div>
                <div class="ac-conditions__visual">
                    <div class="ac-meridian">
                        <div class="ac-body-outline">
                            <div class="ac-body-outline__head"></div>
                            <div class="ac-body-outline__neck"></div>
                            <div class="ac-body-outline__torso"></div>
                            <div class="ac-body-outline__hips"></div>
                            <div class="ac-body-outline__legs">
                                <div class="ac-body-outline__leg"></div>
                                <div class="ac-body-outline__leg"></div>
                            </div>
                        </div>
                        <!-- Meridian lines -->
                        <div class="ac-mline" style="left:50%;top:20%;width:1px;height:60%;transform:translateX(-50%)"></div>
                        <div class="ac-mline" style="left:42%;top:28%;width:1px;height:45%;transform:translateX(-50%)"></div>
                        <div class="ac-mline" style="left:58%;top:28%;width:1px;height:45%;transform:translateX(-50%)"></div>
                        <!-- Acupoints -->
                        <div class="ac-point" style="top:23%;left:49%" title="GV20"></div>
                        <div class="ac-point" style="top:35%;left:47%" title="LI4"></div>
                        <div class="ac-point" style="top:48%;left:50%" title="CV12"></div>
                        <div class="ac-point" style="top:58%;left:43%" title="SP6"></div>
                        <div class="ac-point" style="top:68%;left:51%" title="ST36"></div>
                        <div class="ac-point" style="top:78%;left:46%" title="KD1"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     APPROACH
═══════════════════════════════════════════════ -->
<section class="ac-approach" id="ac-approach">
    <div class="ac-container">
        <div class="ac-center">
            <span class="ac-eyebrow">Your Visit</span>
            <h2 class="ac-heading ac-heading--light">What to Expect</h2>
            <p class="ac-lead" style="color:rgba(255,255,255,.65);margin-inline:auto">Every patient is unique. Our diagnostic approach goes far beyond the presenting complaint to understand the patterns of imbalance at the root of your condition.</p>
        </div>
        <div class="ac-approach__grid">
            <?php foreach ($ac_steps as $step): ?>
            <div class="ac-astep">
                <div class="ac-astep__num"><?php echo esc_html($step['num']); ?></div>
                <h3 class="ac-astep__title"><?php echo esc_html($step['title']); ?></h3>
                <p class="ac-astep__desc"><?php echo esc_html($step['desc']); ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     GALLERY
═══════════════════════════════════════════════ -->
<section class="ac-section ac-gallery" id="ac-gallery">
    <div class="ac-container">
        <div class="ac-center">
            <span class="ac-eyebrow">The Clinic</span>
            <h2 class="ac-heading">A Place of Healing</h2>
        </div>
        <div class="ac-gallery__grid">
            <?php foreach ($ac_gallery as $gitem): ?>
            <div class="ac-gallery__item">
                <div class="ac-gallery__art" style="background:linear-gradient(135deg,<?php echo esc_attr($gitem['c1']); ?>,<?php echo esc_attr($gitem['c2']); ?>)">
                    <span class="ac-gallery__label"><?php echo esc_html($gitem['label']); ?></span>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     COUNTERS
═══════════════════════════════════════════════ -->
<section class="ac-counters" aria-label="Clinic statistics">
    <div class="ac-container">
        <div class="ac-counters__grid">
            <div class="ac-counter">
                <div class="ac-counter__val" data-target="20" data-suffix="yrs">0</div>
                <div class="ac-counter__label">Clinical Experience</div>
            </div>
            <div class="ac-counter">
                <div class="ac-counter__val" data-target="3800" data-suffix="+">0</div>
                <div class="ac-counter__label">Patients Treated</div>
            </div>
            <div class="ac-counter">
                <div class="ac-counter__val" data-target="4.9" data-suffix="★" data-float="1">0</div>
                <div class="ac-counter__label">Average Rating</div>
            </div>
            <div class="ac-counter">
                <div class="ac-counter__val" data-target="95" data-suffix="%">0</div>
                <div class="ac-counter__label">Report Improvement</div>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     ABOUT
═══════════════════════════════════════════════ -->
<section class="ac-section ac-about" id="ac-about">
    <div class="ac-container">
        <div class="ac-about__grid">
            <div class="ac-about__visual">
                <div class="ac-credential-card">
                    <div class="ac-credential-card__top">
                        <div class="ac-credential-card__seal">🌿</div>
                        <div>
                            <div class="ac-credential-card__name">DR. LI MING CHEN</div>
                            <div class="ac-credential-card__title">BAcC Registered Acupuncturist · TCM Doctor</div>
                        </div>
                    </div>
                    <div class="ac-cred-row"><div class="ac-cred-row__label">Qualification</div><div class="ac-cred-row__val">MBAcC · MATCM</div></div>
                    <div class="ac-cred-row"><div class="ac-cred-row__label">Registered</div><div class="ac-cred-row__val">BAcC · RCHM</div></div>
                    <div class="ac-cred-row"><div class="ac-cred-row__label">Training</div><div class="ac-cred-row__val">Beijing University TCM</div></div>
                    <div class="ac-cred-row"><div class="ac-cred-row__label">Specialisms</div><div class="ac-cred-row__val">Fertility · Pain · Neurology</div></div>
                    <div class="ac-cred-row"><div class="ac-cred-row__label">Experience</div><div class="ac-cred-row__val">20 years clinical practice</div></div>
                </div>
                <div class="ac-about__badge">
                    <div class="ac-about__badge-val">3,800+</div>
                    <div class="ac-about__badge-label">Patients Treated</div>
                </div>
            </div>
            <div class="ac-about__content">
                <span class="ac-eyebrow">Your Practitioner</span>
                <h2 class="ac-heading">Dr. Li Ming Chen<br><small style="font-size:.5em;color:var(--ac-muted);font-weight:300;letter-spacing:.04em">MBAcC · BAcC Registered · 20 Years' Experience</small></h2>
                <p class="ac-about__bio">
                    Trained at Beijing University of TCM and holding a Masters in British Acupuncture, Dr. Chen brings a rare depth of classical training combined with modern evidence-based practice. Her specialisms include fertility, chronic pain and neurological conditions.
                </p>
                <p class="ac-about__bio">
                    She founded Bristol Acupuncture Centre in 2004 with a vision of making traditional Chinese medicine accessible, evidence-based and compassionate. Each patient receives the time and attention their healing deserves.
                </p>
                <blockquote class="ac-about__quote">
                    "In TCM, we do not treat diseases — we treat people. The body has an extraordinary capacity to heal when its natural equilibrium is restored."
                </blockquote>
                <a href="#ac-booking" class="ac-btn ac-btn--primary">Book with Dr. Chen →</a>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     PACKAGES
═══════════════════════════════════════════════ -->
<section class="ac-section ac-packages" id="ac-packages">
    <div class="ac-container">
        <div class="ac-center">
            <span class="ac-eyebrow">Treatment Plans</span>
            <h2 class="ac-heading">Choose Your Plan</h2>
            <p class="ac-lead">Most conditions require a course of treatment for lasting results. Our package pricing reflects this and offers significant savings on individual sessions.</p>
        </div>
        <div class="ac-packages__grid">
            <?php foreach ($ac_packages as $pkg): ?>
            <div class="ac-pkg<?php echo $pkg['featured'] ? ' ac-pkg--featured' : ''; ?>">
                <div class="ac-pkg__name"><?php echo esc_html($pkg['name']); ?></div>
                <div class="ac-pkg__sub"><?php echo esc_html($pkg['sub']); ?></div>
                <div class="ac-pkg__price"><?php echo esc_html($pkg['price']); ?></div>
                <ul class="ac-pkg__list">
                    <?php foreach ($pkg['items'] as $item): ?>
                    <li><?php echo esc_html($item); ?></li>
                    <?php endforeach; ?>
                </ul>
                <a href="#ac-booking" class="ac-btn ac-btn--<?php echo $pkg['featured'] ? 'primary' : 'outline-jade'; ?>" style="width:100%;justify-content:center">Book Now</a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     TESTIMONIALS
═══════════════════════════════════════════════ -->
<section class="ac-section ac-testimonials" id="ac-testimonials">
    <div class="ac-container">
        <div class="ac-center">
            <span class="ac-eyebrow">Patient Stories</span>
            <h2 class="ac-heading">Transformed by TCM</h2>
        </div>
        <div class="ac-testi-grid">
            <?php foreach ($ac_testimonials as $testi): ?>
            <div class="ac-testi">
                <div class="ac-testi__stars"><?php echo str_repeat('★',$testi['stars']); ?></div>
                <p class="ac-testi__text">"<?php echo esc_html($testi['text']); ?>"</p>
                <div class="ac-testi__author"><?php echo esc_html($testi['name']); ?></div>
                <div class="ac-testi__loc"><?php echo esc_html($testi['loc']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     BOOKING
═══════════════════════════════════════════════ -->
<section class="ac-booking" id="ac-booking">
    <div class="ac-container">
        <div class="ac-center">
            <span class="ac-eyebrow">Book an Appointment</span>
            <h2 class="ac-heading ac-heading--light">Begin Your Healing</h2>
            <p class="ac-lead" style="color:rgba(255,255,255,.65);margin-inline:auto">Take the first step toward balance and wellbeing. Same-week appointments available, with weekday evening clinics.</p>
        </div>
        <div class="ac-booking__grid">
            <div>
                <div class="ac-booking__notice">
                    <strong>First Visit Information</strong>
                    Please allow 75 minutes for your initial appointment. Wear loose, comfortable clothing. Avoid heavy meals 2 hours before treatment.
                </div>
                <div class="ac-booking__info-item">
                    <span class="ac-booking__info-icon">📍</span>
                    <div>
                        <div class="ac-booking__info-label">Clinic Address</div>
                        <div class="ac-booking__info-text">12 Clifton Road, Bristol BS8 1AF<br>On-street parking available</div>
                    </div>
                </div>
                <div class="ac-booking__info-item">
                    <span class="ac-booking__info-icon">🕐</span>
                    <div>
                        <div class="ac-booking__info-label">Clinic Hours</div>
                        <div class="ac-booking__info-text">Mon–Fri: 8am – 8pm<br>Sat: 9am – 4pm</div>
                    </div>
                </div>
                <div class="ac-booking__info-item">
                    <span class="ac-booking__info-icon">💳</span>
                    <div>
                        <div class="ac-booking__info-label">Insurance</div>
                        <div class="ac-booking__info-text">BUPA, AXA Health, Cigna, Vitality and most major insurers accepted.</div>
                    </div>
                </div>
                <div class="ac-booking__info-item">
                    <span class="ac-booking__info-icon">📞</span>
                    <div>
                        <div class="ac-booking__info-label">Contact</div>
                        <div class="ac-booking__info-text">0117 946 0000<br>hello@bristolacupuncture.co.uk</div>
                    </div>
                </div>
            </div>
            <div>
                <form class="ac-form" method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
                    <?php wp_nonce_field('tf_ac_booking','tf_ac_nonce'); ?>
                    <input type="hidden" name="action" value="tf_ac_booking">
                    <div class="ac-form__row">
                        <div class="ac-form__group">
                            <label for="ac-name">Full Name *</label>
                            <input type="text" id="ac-name" name="ac_name" required placeholder="Your full name">
                        </div>
                        <div class="ac-form__group">
                            <label for="ac-email">Email Address *</label>
                            <input type="email" id="ac-email" name="ac_email" required placeholder="your@email.com">
                        </div>
                    </div>
                    <div class="ac-form__row">
                        <div class="ac-form__group">
                            <label for="ac-phone">Phone Number *</label>
                            <input type="tel" id="ac-phone" name="ac_phone" required placeholder="07700 900000">
                        </div>
                        <div class="ac-form__group">
                            <label for="ac-dob">Date of Birth</label>
                            <input type="date" id="ac-dob" name="ac_dob">
                        </div>
                    </div>
                    <div class="ac-form__group">
                        <label for="ac-condition">Main Condition / Reason for Referral *</label>
                        <select id="ac-condition" name="ac_condition" required>
                            <option value="">Select…</option>
                            <option>Back / Neck Pain</option>
                            <option>Stress / Anxiety</option>
                            <option>Insomnia</option>
                            <option>Fertility / IVF Support</option>
                            <option>Migraines / Headaches</option>
                            <option>Digestive Issues</option>
                            <option>Women's Health / Hormonal</option>
                            <option>Fatigue / ME/CFS</option>
                            <option>Sports Injury</option>
                            <option>Other (please specify below)</option>
                        </select>
                    </div>
                    <div class="ac-form__row">
                        <div class="ac-form__group">
                            <label for="ac-previous">Previous Acupuncture?</label>
                            <select id="ac-previous" name="ac_previous">
                                <option value="">Select…</option>
                                <option>No — first time</option>
                                <option>Yes — some experience</option>
                                <option>Yes — regular previously</option>
                            </select>
                        </div>
                        <div class="ac-form__group">
                            <label for="ac-date">Preferred Date</label>
                            <input type="date" id="ac-date" name="ac_date">
                        </div>
                    </div>
                    <div class="ac-form__group">
                        <label for="ac-notes">Health Background / Notes</label>
                        <textarea id="ac-notes" name="ac_notes" placeholder="Please share any relevant health history, current medications or anything else you'd like us to know before your appointment…"></textarea>
                    </div>
                    <button type="submit" class="ac-form__submit">Request Appointment →</button>
                    <p class="ac-form__consent">Your information is kept strictly confidential and will only be used in relation to your healthcare.</p>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     FOOTER
═══════════════════════════════════════════════ -->
<footer class="ac-footer">
    <div class="ac-container">
        <div class="ac-footer__inner">
            <p class="ac-footer__copy">&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All rights reserved. BAcC Registered Acupuncturist.</p>
            <nav class="ac-footer__links" aria-label="Footer navigation">
                <a href="<?php echo esc_url(home_url('/privacy-policy')); ?>">Privacy Policy</a>
                <a href="<?php echo esc_url(home_url('/terms')); ?>">Terms</a>
                <a href="<?php echo esc_url(home_url('/accessibility')); ?>">Accessibility</a>
            </nav>
        </div>
    </div>
</footer>


<script>
(function(){
    /* ── Animated Counters ── */
    const counters = document.querySelectorAll('.ac-counter__val[data-target]');
    const easeOut = t => 1 - Math.pow(1 - t, 3);
    const io = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (!entry.isIntersecting) return;
            const el = entry.target;
            const target = parseFloat(el.dataset.target);
            const suffix = el.dataset.suffix || '';
            const isFloat = el.dataset.float === '1';
            if (isNaN(target)) return;
            const dur = 1800;
            let start = null;
            function tick(ts) {
                if (!start) start = ts;
                const prog = Math.min((ts - start) / dur, 1);
                const val = target * easeOut(prog);
                el.textContent = (isFloat ? val.toFixed(1) : Math.round(val)) + suffix;
                if (prog < 1) requestAnimationFrame(tick);
            }
            requestAnimationFrame(tick);
            io.unobserve(el);
        });
    }, { threshold: 0.4 });
    counters.forEach(c => io.observe(c));

    /* ── Mouse parallax on Qi particles ── */
    const particles = document.querySelectorAll('.ac-particle');
    document.getElementById('ac-hero')?.addEventListener('mousemove', e => {
        const rect = e.currentTarget.getBoundingClientRect();
        const dx = (e.clientX - rect.width / 2) / rect.width;
        const dy = (e.clientY - rect.height / 2) / rect.height;
        particles.forEach(p => {
            const d = parseFloat(p.dataset.depth) || 20;
            p.style.transform = `translate(${dx * d}px, ${dy * d}px)`;
        });
    });
})();
</script>
</body>
</html>
</div><!-- .ac-page -->
<?php get_footer(); ?>
