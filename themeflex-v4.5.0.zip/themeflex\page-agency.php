<?php
/**
 * Template Name: Agency Homepage
 * Template Post Type: page
 *
 * Premium Creative Agency template — Forma Studio
 * Namespace: --ag-*  |  Fonts: Syne + Inter
 * Palette: Obsidian #0C0C0C / Cream #F5F0E8 / Coral #FF5A36 / Sand #D4C5B0 / Fog #9E9E9E
 */
defined('ABSPATH') || exit;
get_header();

srand(crc32('forma-studio-agency'));
$ag_works = [
    ['Brand Identity','Luminos Energy','Brand overhaul for a clean-energy scale-up — identity, motion, and a Webby-winning site.','#FF5A36'],
    ['Campaign','Vela Sportswear','A global OOH + digital campaign reaching 48M impressions across 22 markets.','#D4C5B0'],
    ['Product Design','Arcana Finance','Full UX/UI design system for a Series B fintech — from 0 to 4.2M users in 14 months.','#0C0C0C'],
    ['Motion','Nord Music App','Identity motion system and launch film — 12M views in the first week.','#9E9E9E'],
    ['Website','Celeste Hotels','A story-driven site for a boutique hotel group — 34% conversion uplift post-launch.','#FF5A36'],
    ['Packaging','Root Botanics','Sustainable packaging design for a D2C wellness brand — shortlisted for D&AD.','#D4C5B0'],
];
?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>
:root {
  --ag-obsidian: #0C0C0C;
  --ag-cream:    #F5F0E8;
  --ag-coral:    #FF5A36;
  --ag-sand:     #D4C5B0;
  --ag-fog:      #9E9E9E;
  --ag-panel:    #161616;
  --ag-border:   rgba(255,255,255,.1);
  --ag-serif:    'Syne', sans-serif;
  --ag-sans:     'Inter', system-ui, sans-serif;
  --ag-r:        4px;
  --ag-trans:    all .3s cubic-bezier(.4,0,.2,1);
}
.ag-page *, .ag-page *::before, .ag-page *::after { box-sizing:border-box; margin:0; padding:0; }
.ag-page { font-family:var(--ag-sans); background:var(--ag-obsidian); color:var(--ag-cream); overflow-x:hidden; }
.ag-page a { color:inherit; text-decoration:none; }
.ag-page button { cursor:pointer; border:none; background:none; font-family:inherit; }

/* layout */
.ag-wrap { max-width:1280px; margin:0 auto; padding:0 2.5rem; }
.ag-section { padding:7rem 0; }
.ag-section--light { background:var(--ag-cream); color:var(--ag-obsidian); }
.ag-section--panel { background:var(--ag-panel); }

.ag-eyebrow {
  font-family:var(--ag-serif); font-size:.7rem; font-weight:700;
  letter-spacing:.25em; text-transform:uppercase; color:var(--ag-coral);
  margin-bottom:.75rem; display:block;
}
.ag-h1 { font-family:var(--ag-serif); font-size:clamp(3.5rem,7vw,7rem); font-weight:800; line-height:.95; letter-spacing:-.03em; }
.ag-h2 { font-family:var(--ag-serif); font-size:clamp(2.2rem,5vw,4.5rem); font-weight:700; line-height:1.05; letter-spacing:-.02em; }
.ag-h3 { font-family:var(--ag-serif); font-size:1.4rem; font-weight:600; }
.ag-lead { font-size:1.05rem; line-height:1.8; color:var(--ag-fog); max-width:58ch; }
.ag-lead--dark { color:rgba(12,12,12,.6); }

.ag-btn {
  display:inline-flex; align-items:center; gap:.6rem;
  padding:.85rem 2rem; border-radius:0;
  font-family:var(--ag-serif); font-size:.8rem; font-weight:700; letter-spacing:.08em; text-transform:uppercase;
  transition:var(--ag-trans);
}
.ag-btn--coral { background:var(--ag-coral); color:#fff; }
.ag-btn--coral:hover { background:#FF3D1A; }
.ag-btn--outline-light { border:1.5px solid rgba(245,240,232,.3); color:var(--ag-cream); }
.ag-btn--outline-light:hover { border-color:var(--ag-coral); color:var(--ag-coral); }
.ag-btn--outline-dark { border:1.5px solid rgba(12,12,12,.25); color:var(--ag-obsidian); }
.ag-btn--outline-dark:hover { border-color:var(--ag-coral); color:var(--ag-coral); }

.ag-reveal { opacity:0; transform:translateY(28px); transition:opacity .65s ease, transform .65s ease; }
.ag-reveal.ag-visible { opacity:1; transform:none; }

/* NAV */
.ag-nav {
  position:fixed; top:0; left:0; right:0; z-index:100;
  display:flex; align-items:center; justify-content:space-between;
  padding:1.4rem 3rem;
  background:rgba(12,12,12,.88); backdrop-filter:blur(14px);
  border-bottom:1px solid rgba(255,255,255,.06);
}
.ag-nav__logo { font-family:var(--ag-serif); font-size:1.2rem; font-weight:800; letter-spacing:-.02em; }
.ag-nav__logo span { color:var(--ag-coral); }
.ag-nav__links { display:flex; gap:2.5rem; list-style:none; }
.ag-nav__links a { font-size:.8rem; font-weight:500; color:var(--ag-fog); transition:color .25s; }
.ag-nav__links a:hover { color:var(--ag-cream); }

/* HERO */
.ag-hero {
  min-height:100vh; padding-top:80px;
  display:flex; flex-direction:column; justify-content:flex-end;
  padding-bottom:5rem;
  position:relative; overflow:hidden;
  background:var(--ag-obsidian);
}
/* large rotated typography background */
.ag-hero__bg-text {
  position:absolute; top:50%; left:50%; transform:translate(-50%,-50%);
  font-family:var(--ag-serif); font-size:28vw; font-weight:800;
  color:rgba(245,240,232,.03); white-space:nowrap; letter-spacing:-.04em;
  pointer-events:none; user-select:none;
  line-height:1;
}
/* abstract shape blobs */
.ag-hero__blob {
  position:absolute; border-radius:50%; pointer-events:none;
  filter:blur(80px);
}
.ag-hero__blob--1 { width:500px; height:500px; background:rgba(255,90,54,.12); top:-100px; right:-80px; }
.ag-hero__blob--2 { width:360px; height:360px; background:rgba(212,197,176,.08); bottom:0; left:-60px; }

/* CSS composition / mood board in hero top area */
.ag-hero__composition {
  position:absolute; top:80px; right:5%; width:420px; height:520px;
}
/* colour blocks — abstract poster fragments */
.ag-comp-block {
  position:absolute; transition:transform 6s ease;
}
.ag-comp-block--a { top:0; right:60px; width:200px; height:260px; background:var(--ag-coral); }
.ag-comp-block--a::before {
  content:'FORMA'; position:absolute; bottom:20px; right:16px;
  font-family:var(--ag-serif); font-size:1.8rem; font-weight:800; color:rgba(255,255,255,.18);
  letter-spacing:-.02em;
}
.ag-comp-block--b { top:40px; right:0; width:50px; height:180px; background:var(--ag-sand); }
.ag-comp-block--c { top:220px; right:50px; width:300px; height:180px; background:rgba(245,240,232,.06); border:1px solid rgba(255,255,255,.1); }
.ag-comp-block--d { top:200px; left:0; width:90px; height:90px; background:rgba(255,90,54,.6); border-radius:50%; }
.ag-comp-block--e { bottom:40px; right:10px; width:180px; height:60px; background:rgba(245,240,232,.08); }
/* grid lines overlay */
.ag-comp-grid {
  position:absolute; inset:0; pointer-events:none;
  background:
    repeating-linear-gradient(0deg, transparent 0, transparent 49px, rgba(255,255,255,.04) 49px, rgba(255,255,255,.04) 50px),
    repeating-linear-gradient(90deg, transparent 0, transparent 49px, rgba(255,255,255,.04) 49px, rgba(255,255,255,.04) 50px);
}

/* type below */
.ag-hero__inner { position:relative; z-index:2; }
.ag-hero__tag { display:inline-flex; align-items:center; gap:.6rem; margin-bottom:2rem; }
.ag-hero__tag-dot { width:8px; height:8px; border-radius:50%; background:var(--ag-coral); animation:ag-pulse 2s ease infinite; }
@keyframes ag-pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:.5;transform:scale(.7)} }
.ag-hero__tag-text { font-family:var(--ag-serif); font-size:.72rem; font-weight:700; letter-spacing:.2em; text-transform:uppercase; color:var(--ag-fog); }

.ag-hero__h1-wrap { display:flex; flex-direction:column; margin-bottom:2.5rem; }
.ag-hero__h1-line { overflow:hidden; }
.ag-hero__h1-line em { font-style:italic; color:var(--ag-coral); }

.ag-hero__bottom { display:flex; align-items:flex-end; justify-content:space-between; margin-top:4rem; }
.ag-hero__copy { max-width:42ch; }
.ag-hero__actions { display:flex; gap:1rem; }
.ag-hero__awards { display:flex; gap:1.5rem; }
.ag-hero__award {
  border:1px solid rgba(255,255,255,.1); padding:.6rem 1rem; border-radius:2px;
  text-align:center;
}
.ag-hero__award-val { font-family:var(--ag-serif); font-size:1.2rem; font-weight:700; color:var(--ag-coral); display:block; }
.ag-hero__award-label { font-size:.65rem; letter-spacing:.1em; text-transform:uppercase; color:var(--ag-fog); }

/* MARQUEE */
.ag-marquee-wrap { overflow:hidden; border-top:1px solid rgba(255,255,255,.08); border-bottom:1px solid rgba(255,255,255,.08); padding:.7rem 0; }
.ag-marquee { display:flex; gap:3rem; animation:ag-scroll 20s linear infinite; white-space:nowrap; }
.ag-marquee-item { font-family:var(--ag-serif); font-size:1rem; font-weight:700; text-transform:uppercase; letter-spacing:.12em; color:rgba(245,240,232,.2); flex-shrink:0; }
.ag-marquee-item span { color:var(--ag-coral); margin:0 1rem; }
@keyframes ag-scroll { from{transform:translateX(0)} to{transform:translateX(-50%)} }

/* STATS */
.ag-stats { display:grid; grid-template-columns:repeat(4,1fr); border-top:1px solid rgba(255,255,255,.08); }
.ag-stat { padding:3rem 2rem; border-right:1px solid rgba(255,255,255,.08); }
.ag-stat:last-child { border-right:none; }
.ag-stat__num { font-family:var(--ag-serif); font-size:3.5rem; font-weight:800; line-height:1; display:block; margin-bottom:.25rem; }
.ag-stat__num .ag-coral { color:var(--ag-coral); }
.ag-stat__label { font-size:.72rem; letter-spacing:.12em; text-transform:uppercase; color:var(--ag-fog); }

/* WORK GRID */
.ag-work { display:grid; grid-template-columns:repeat(3,1fr); gap:2px; }
.ag-work-item {
  position:relative; overflow:hidden; cursor:pointer;
  aspect-ratio:1/1;
}
.ag-work-item:nth-child(1) { grid-column:1/3; aspect-ratio:2/1; }
.ag-work-item__bg {
  position:absolute; inset:0; transition:transform .6s ease;
}
.ag-work-item:hover .ag-work-item__bg { transform:scale(1.05); }
.ag-work-item__overlay {
  position:absolute; inset:0;
  background:linear-gradient(to top, rgba(12,12,12,.9) 0%, rgba(12,12,12,.3) 50%, transparent 100%);
  opacity:0; transition:opacity .35s; display:flex; flex-direction:column; justify-content:flex-end; padding:2rem;
}
.ag-work-item:hover .ag-work-item__overlay { opacity:1; }
.ag-work-item__cat { font-family:var(--ag-serif); font-size:.65rem; font-weight:700; letter-spacing:.2em; text-transform:uppercase; color:var(--ag-coral); margin-bottom:.3rem; }
.ag-work-item__title { font-family:var(--ag-serif); font-size:1.4rem; font-weight:700; color:var(--ag-cream); }

/* SERVICES */
.ag-services { display:grid; grid-template-columns:repeat(2,1fr); gap:2rem; }
.ag-service {
  padding:2.5rem;
  border:1px solid rgba(255,255,255,.08);
  position:relative; overflow:hidden;
  transition:border-color .3s;
}
.ag-service:hover { border-color:var(--ag-coral); }
.ag-service__num {
  font-family:var(--ag-serif); font-size:4rem; font-weight:800;
  color:rgba(245,240,232,.05); position:absolute; top:.5rem; right:1.5rem;
  line-height:1;
}
.ag-service__icon { font-size:1.6rem; margin-bottom:1.2rem; display:block; }
.ag-service__title { color:var(--ag-cream); margin-bottom:.75rem; }
.ag-service__text { font-size:.88rem; line-height:1.75; color:var(--ag-fog); margin-bottom:1.25rem; }
.ag-service__tags { display:flex; gap:.4rem; flex-wrap:wrap; }
.ag-service__tag {
  font-size:.65rem; letter-spacing:.08em; text-transform:uppercase;
  padding:.2rem .55rem; border-radius:2px;
  background:rgba(255,90,54,.1); color:var(--ag-coral);
}

/* ABOUT */
.ag-about { display:grid; grid-template-columns:1fr 1fr; gap:6rem; align-items:center; }
.ag-about__vis {
  position:relative; height:500px;
  background:var(--ag-panel);
  border:1px solid rgba(255,255,255,.06);
}
/* CSS figure: art director */
.ag-about__figure { position:absolute; bottom:0; left:50%; transform:translateX(-50%); display:flex; flex-direction:column; align-items:center; }
.ag-fig__head { width:64px; height:70px; background:#B87A5A; border-radius:50%; position:relative; }
.ag-fig__head::before { content:''; position:absolute; top:-14px; left:-2px; right:-2px; height:28px; background:#1A0E06; border-radius:50% 50% 0 0; }
.ag-fig__head::after { content:''; position:absolute; top:6px; left:-6px; width:8px; height:8px; background:rgba(255,90,54,.5); border-radius:50%; box-shadow:68px 0 0 rgba(255,90,54,.5); }
.ag-fig__neck { width:20px; height:14px; background:#B87A5A; margin:0 auto; }
.ag-fig__body { width:88px; height:110px; background:linear-gradient(180deg,#FF5A36 0%,#CC4020 100%); border-radius:4px 4px 0 0; position:relative; }
.ag-fig__body::before { content:''; position:absolute; top:14px; left:14px; right:14px; height:2px; background:rgba(255,255,255,.25); box-shadow:0 20px 0 rgba(255,255,255,.15); }
.ag-fig__arm-r { position:absolute; top:14px; right:-16px; width:14px; height:56px; background:#CC4020; border-radius:7px; transform:rotate(12deg); transform-origin:top center; }
.ag-fig__arm-l { position:absolute; top:14px; left:-12px; width:12px; height:50px; background:#B87A5A; border-radius:6px; transform:rotate(-15deg); transform-origin:top center; }
.ag-fig__hand { position:absolute; bottom:-10px; right:-8px; width:16px; height:16px; background:#B87A5A; border-radius:50%; }
.ag-fig__skirt { width:100px; height:80px; background:linear-gradient(180deg,#1A1A1A 0%,#0C0C0C 100%); clip-path:polygon(5%0%,95%0%,100%100%,0%100%); }
.ag-fig__legs { display:flex; gap:8px; justify-content:center; }
.ag-fig__leg { width:14px; height:34px; background:#1A1A1A; }
.ag-fig__foot { width:20px; height:8px; background:#333; border-radius:0 3px 3px 0; }
/* colour swatches floating in visual */
.ag-about__swatches { position:absolute; top:2rem; right:2rem; display:flex; flex-direction:column; gap:.5rem; }
.ag-about__swatch { width:32px; height:32px; border-radius:2px; box-shadow:0 2px 8px rgba(0,0,0,.4); }
.ag-about__caption { position:absolute; bottom:2rem; left:2rem; right:2rem; background:var(--ag-obsidian); border:1px solid rgba(255,255,255,.08); padding:1rem 1.2rem; }
.ag-about__caption-name { font-family:var(--ag-serif); font-size:1rem; font-weight:700; }
.ag-about__caption-role { font-size:.7rem; letter-spacing:.1em; text-transform:uppercase; color:var(--ag-fog); margin-top:.25rem; }
.ag-about__content .ag-h2 { margin-bottom:1rem; }
.ag-about__content .ag-lead { margin-bottom:2rem; }
.ag-about__values { display:grid; grid-template-columns:1fr 1fr; gap:1rem; margin-bottom:2rem; }
.ag-value { padding:1rem; border:1px solid rgba(255,255,255,.08); }
.ag-value__title { font-family:var(--ag-serif); font-size:.9rem; font-weight:700; margin-bottom:.3rem; }
.ag-value__text { font-size:.8rem; line-height:1.6; color:var(--ag-fog); }

/* PACKAGES */
.ag-packages { display:grid; grid-template-columns:repeat(3,1fr); gap:1.5rem; }
.ag-pkg {
  border:1px solid rgba(255,255,255,.08);
  padding:2.5rem; position:relative;
  transition:border-color .3s;
}
.ag-pkg:hover { border-color:rgba(255,90,54,.5); }
.ag-pkg--featured {
  border-color:var(--ag-coral);
  background:linear-gradient(135deg, rgba(255,90,54,.05) 0%, transparent 60%);
  transform:scale(1.03);
}
.ag-pkg__badge { position:absolute; top:-1px; left:50%; transform:translateX(-50%); background:var(--ag-coral); color:#fff; font-family:var(--ag-serif); font-size:.6rem; font-weight:700; letter-spacing:.15em; text-transform:uppercase; padding:.28rem 1rem; }
.ag-pkg__name { font-family:var(--ag-serif); font-size:1.5rem; font-weight:700; margin-bottom:.5rem; }
.ag-pkg__desc { font-size:.83rem; color:var(--ag-fog); line-height:1.65; margin-bottom:1.5rem; }
.ag-pkg__price { font-family:var(--ag-serif); font-size:2.6rem; font-weight:800; line-height:1; }
.ag-pkg__price sup { font-size:1.2rem; vertical-align:super; }
.ag-pkg__price sub { font-size:.85rem; color:var(--ag-fog); }
.ag-pkg__note { font-size:.72rem; color:var(--ag-fog); margin-bottom:1.5rem; padding-bottom:1.5rem; border-bottom:1px solid rgba(255,255,255,.08); }
.ag-pkg__features { list-style:none; display:flex; flex-direction:column; gap:.55rem; margin-bottom:2rem; }
.ag-pkg__feature { font-size:.84rem; color:var(--ag-fog); display:flex; gap:.6rem; }
.ag-pkg__feature::before { content:'✦'; color:var(--ag-coral); flex-shrink:0; font-size:.55rem; padding-top:.2rem; }

/* TESTIMONIALS */
.ag-testis { display:grid; grid-template-columns:repeat(3,1fr); gap:1.5rem; }
.ag-testi { padding:2.5rem; border:1px solid rgba(255,255,255,.08); position:relative; }
.ag-testi__mark { font-family:var(--ag-serif); font-size:4rem; font-weight:800; color:var(--ag-coral); opacity:.25; line-height:1; margin-bottom:.5rem; }
.ag-testi__text { font-size:.88rem; line-height:1.8; color:var(--ag-fog); margin-bottom:1.5rem; }
.ag-testi__author { display:flex; align-items:center; gap:.8rem; }
.ag-testi__avatar { width:38px; height:38px; border-radius:2px; display:flex; align-items:center; justify-content:center; font-family:var(--ag-serif); font-size:.95rem; font-weight:700; flex-shrink:0; }
.ag-testi__name { font-family:var(--ag-serif); font-size:.95rem; font-weight:700; display:block; }
.ag-testi__role { font-size:.7rem; letter-spacing:.08em; text-transform:uppercase; color:var(--ag-fog); }

/* FAQ */
.ag-faq-list { max-width:800px; margin:0 auto; }
.ag-faq { border-bottom:1px solid rgba(255,255,255,.08); }
.ag-faq__q {
  width:100%; display:flex; justify-content:space-between; align-items:center;
  padding:1.4rem 0; font-family:var(--ag-serif); font-size:1.05rem; font-weight:600;
  color:var(--ag-cream); text-align:left; background:none; border:none; transition:color .25s;
}
.ag-faq__q:hover { color:var(--ag-coral); }
.ag-faq__icon { font-size:1.4rem; color:var(--ag-coral); transition:transform .3s; flex-shrink:0; }
.ag-faq.ag-open .ag-faq__icon { transform:rotate(45deg); }
.ag-faq__a { max-height:0; overflow:hidden; transition:max-height .4s ease; }
.ag-faq__a-inner { padding-bottom:1.25rem; font-size:.88rem; line-height:1.8; color:var(--ag-fog); }

/* CONTACT */
.ag-contact { display:grid; grid-template-columns:1fr 1fr; gap:6rem; align-items:start; }
.ag-contact__info .ag-h2 { margin-bottom:1rem; }
.ag-contact__info .ag-lead { margin-bottom:2rem; }
.ag-contact__links { display:flex; flex-direction:column; gap:1rem; }
.ag-contact__link { display:flex; gap:1rem; align-items:center; padding:1rem 1.25rem; border:1px solid rgba(255,255,255,.08); transition:border-color .25s; }
.ag-contact__link:hover { border-color:var(--ag-coral); }
.ag-contact__link-icon { font-size:1rem; }
.ag-contact__link-label { font-size:.65rem; letter-spacing:.1em; text-transform:uppercase; color:var(--ag-fog); display:block; }
.ag-contact__link-val { font-size:.9rem; color:var(--ag-cream); }

.ag-form { display:flex; flex-direction:column; gap:1.1rem; }
.ag-form-row { display:grid; grid-template-columns:1fr 1fr; gap:1.1rem; }
.ag-field { display:flex; flex-direction:column; gap:.35rem; }
.ag-label { font-family:var(--ag-serif); font-size:.65rem; font-weight:700; letter-spacing:.15em; text-transform:uppercase; color:var(--ag-fog); }
.ag-input, .ag-select, .ag-textarea {
  width:100%; padding:.85rem 1rem;
  background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.1);
  border-radius:0; color:var(--ag-cream);
  font-family:var(--ag-sans); font-size:.9rem;
  transition:border-color .25s; appearance:none;
}
.ag-input::placeholder { color:rgba(158,158,158,.5); }
.ag-input:focus, .ag-select:focus, .ag-textarea:focus { outline:none; border-color:var(--ag-coral); }
.ag-select option { background:var(--ag-obsidian); }
.ag-textarea { resize:vertical; min-height:120px; }

/* CTA */
.ag-cta-banner {
  text-align:center; padding:7rem 0;
  background:var(--ag-coral);
  color:#fff;
}
.ag-cta-banner .ag-h2 { margin-bottom:1rem; color:#fff; }
.ag-cta-banner .ag-lead { color:rgba(255,255,255,.8); margin:0 auto 2.5rem; }
.ag-cta-banner__actions { display:flex; gap:1rem; justify-content:center; }
.ag-btn--white { background:#fff; color:var(--ag-coral); }
.ag-btn--white:hover { background:var(--ag-cream); }
.ag-btn--outline-white { border:1.5px solid rgba(255,255,255,.5); color:#fff; }
.ag-btn--outline-white:hover { background:rgba(255,255,255,.1); }

/* FOOTER */
.ag-footer { background:var(--ag-obsidian); border-top:1px solid rgba(255,255,255,.06); padding:4rem 0 2rem; }
.ag-footer__top { display:grid; grid-template-columns:2fr 1fr 1fr 1fr; gap:3rem; margin-bottom:3rem; }
.ag-footer__brand .ag-nav__logo { display:inline-block; margin-bottom:1rem; font-family:var(--ag-serif); font-size:1.2rem; font-weight:800; }
.ag-footer__brand p { font-size:.83rem; line-height:1.7; color:var(--ag-fog); max-width:30ch; }
.ag-footer__col-title { font-family:var(--ag-serif); font-size:.65rem; font-weight:700; letter-spacing:.18em; text-transform:uppercase; color:var(--ag-coral); margin-bottom:.75rem; }
.ag-footer__links { list-style:none; display:flex; flex-direction:column; gap:.45rem; }
.ag-footer__links a { font-size:.83rem; color:var(--ag-fog); transition:color .25s; }
.ag-footer__links a:hover { color:var(--ag-cream); }
.ag-footer__bottom { padding-top:2rem; border-top:1px solid rgba(255,255,255,.06); display:flex; justify-content:space-between; align-items:center; font-size:.75rem; color:rgba(158,158,158,.5); }

/* responsive */
@media(max-width:1024px){
  .ag-hero__composition { display:none; }
  .ag-work { grid-template-columns:1fr 1fr; }
  .ag-work-item:nth-child(1) { grid-column:1/3; }
  .ag-about { grid-template-columns:1fr; }
  .ag-contact { grid-template-columns:1fr; }
  .ag-footer__top { grid-template-columns:1fr 1fr; }
}
@media(max-width:768px){
  .ag-nav__links { display:none; }
  .ag-stats { grid-template-columns:1fr 1fr; }
  .ag-work { grid-template-columns:1fr; }
  .ag-work-item:nth-child(1) { grid-column:1; aspect-ratio:1/1; }
  .ag-services { grid-template-columns:1fr; }
  .ag-packages { grid-template-columns:1fr; }
  .ag-pkg--featured { transform:none; }
  .ag-testis { grid-template-columns:1fr; }
  .ag-form-row { grid-template-columns:1fr; }
  .ag-footer__top { grid-template-columns:1fr; }
  .ag-footer__bottom { flex-direction:column; gap:.5rem; }
}
</style>

<div class="ag-page">

<!-- NAV ──────────────────────────────────────────────── -->
<nav class="ag-nav" role="navigation" aria-label="<?php esc_attr_e('Main navigation','themeflex'); ?>">
  <a href="<?php echo esc_url(home_url('/')); ?>" class="ag-nav__logo">FORMA<span>.</span></a>
  <ul class="ag-nav__links">
    <li><a href="#work"><?php esc_html_e('Work','themeflex'); ?></a></li>
    <li><a href="#services"><?php esc_html_e('Services','themeflex'); ?></a></li>
    <li><a href="#about"><?php esc_html_e('Studio','themeflex'); ?></a></li>
    <li><a href="#packages"><?php esc_html_e('Packages','themeflex'); ?></a></li>
    <li><a href="#contact"><?php esc_html_e('Contact','themeflex'); ?></a></li>
  </ul>
  <a href="#contact" class="ag-btn ag-btn--coral"><?php esc_html_e('Start a Project','themeflex'); ?></a>
</nav>

<!-- HERO ──────────────────────────────────────────────── -->
<section class="ag-hero" aria-label="<?php esc_attr_e('Hero','themeflex'); ?>">
  <div class="ag-hero__bg-text" aria-hidden="true">FORMA</div>
  <div class="ag-hero__blob ag-hero__blob--1" aria-hidden="true"></div>
  <div class="ag-hero__blob ag-hero__blob--2" aria-hidden="true"></div>

  <!-- abstract composition -->
  <div class="ag-hero__composition" aria-hidden="true">
    <div class="ag-comp-grid"></div>
    <div class="ag-comp-block ag-comp-block--a"></div>
    <div class="ag-comp-block ag-comp-block--b"></div>
    <div class="ag-comp-block ag-comp-block--c"></div>
    <div class="ag-comp-block ag-comp-block--d"></div>
    <div class="ag-comp-block ag-comp-block--e"></div>
  </div>

  <div class="ag-wrap">
    <div class="ag-hero__inner">
      <div class="ag-hero__tag">
        <span class="ag-hero__tag-dot" aria-hidden="true"></span>
        <span class="ag-hero__tag-text"><?php esc_html_e('Creative Studio · Est. 2009 · London & Berlin','themeflex'); ?></span>
      </div>
      <div class="ag-hero__h1-wrap">
        <h1 class="ag-h1">
          <?php esc_html_e('Ideas That','themeflex'); ?><br>
          <em><?php esc_html_e('Move','themeflex'); ?></em> <?php esc_html_e('People.','themeflex'); ?><br>
          <?php esc_html_e('Brands That','themeflex'); ?><br>
          <?php esc_html_e('Endure.','themeflex'); ?>
        </h1>
      </div>
      <div class="ag-hero__bottom">
        <div>
          <p class="ag-lead"><?php esc_html_e('Forma is a strategic creative studio. We build brand identities, campaigns, and digital experiences that earn attention and drive growth.','themeflex'); ?></p>
          <div class="ag-hero__actions" style="margin-top:1.5rem;">
            <a href="#work"    class="ag-btn ag-btn--coral"><?php esc_html_e('View Work','themeflex'); ?></a>
            <a href="#contact" class="ag-btn ag-btn--outline-light"><?php esc_html_e('Talk to Us','themeflex'); ?></a>
          </div>
        </div>
        <div class="ag-hero__awards" aria-label="<?php esc_attr_e('Awards','themeflex'); ?>">
          <?php foreach (['D&AD','Webby','Cannes Lions'] as $award): ?>
          <div class="ag-hero__award">
            <span class="ag-hero__award-val"><?php echo esc_html($award); ?></span>
            <span class="ag-hero__award-label"><?php esc_html_e('Winner','themeflex'); ?></span>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- MARQUEE ─────────────────────────────────────────── -->
<div class="ag-marquee-wrap" aria-hidden="true">
  <div class="ag-marquee">
    <?php
    $ag_marquee = ['Brand Identity','Campaign Strategy','UI/UX Design','Motion Design','Digital Experiences','Packaging','Art Direction','Brand Strategy'];
    $ag_marquee = array_merge($ag_marquee, $ag_marquee);
    foreach ($ag_marquee as $m):
    ?><span class="ag-marquee-item"><?php echo esc_html($m); ?> <span>✦</span></span><?php endforeach; ?>
  </div>
</div>

<!-- STATS ───────────────────────────────────────────── -->
<section class="ag-section ag-section--panel" aria-label="<?php esc_attr_e('Studio statistics','themeflex'); ?>">
  <div class="ag-wrap">
    <div class="ag-stats">
      <?php foreach ([['320+','Projects Delivered'],['15yr','Studio Experience'],['D&AD','Gold Award x4'],['48M','Campaign Impressions']] as $i => [$v,$l]): ?>
      <div class="ag-stat ag-reveal" style="transition-delay:<?php echo $i*.08; ?>s">
        <span class="ag-stat__num"><?php echo esc_html($v); ?></span>
        <span class="ag-stat__label"><?php echo esc_html($l); ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- WORK ────────────────────────────────────────────── -->
<section id="work" class="ag-section" style="padding:0" aria-labelledby="ag-work-title">
  <div class="ag-wrap" style="padding-top:5rem;padding-bottom:3rem;">
    <header class="ag-reveal" style="margin-bottom:3rem;">
      <span class="ag-eyebrow"><?php esc_html_e('Selected Projects','themeflex'); ?></span>
      <h2 class="ag-h2" id="ag-work-title"><?php esc_html_e('Our Work','themeflex'); ?></h2>
    </header>
  </div>
  <div class="ag-work" role="list">
    <?php foreach ($ag_works as $i => $work): ?>
    <div class="ag-work-item ag-reveal" role="listitem" style="transition-delay:<?php echo $i*.07; ?>s">
      <div class="ag-work-item__bg" style="background:linear-gradient(135deg, <?php echo esc_attr($work[3]); ?> 0%, rgba(12,12,12,.8) 100%);"></div>
      <div class="ag-work-item__overlay">
        <p class="ag-work-item__cat"><?php echo esc_html($work[0]); ?></p>
        <h3 class="ag-work-item__title"><?php echo esc_html($work[1]); ?></h3>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <div style="text-align:center;padding:3rem 0;">
    <a href="#contact" class="ag-btn ag-btn--outline-light"><?php esc_html_e('See Full Portfolio','themeflex'); ?></a>
  </div>
</section>

<!-- SERVICES ─────────────────────────────────────────── -->
<section id="services" class="ag-section ag-section--panel" aria-labelledby="ag-svc-title">
  <div class="ag-wrap">
    <header style="margin-bottom:3.5rem;" class="ag-reveal">
      <span class="ag-eyebrow"><?php esc_html_e('What We Do','themeflex'); ?></span>
      <h2 class="ag-h2" id="ag-svc-title"><?php esc_html_e('Studio Disciplines','themeflex'); ?></h2>
    </header>
    <div class="ag-services">
      <?php
      $ag_svcs = [
        ['🎨','Brand Strategy & Identity','From brand audits and naming through visual identity, tone of voice, and guidelines — we build brands that mean something.',
         ['Brand Architecture','Visual Identity','Naming','Brand Books']],
        ['📱','Digital & UX Design','Research-led digital products and websites that are beautiful, fast, and conversion-optimised.',
         ['UX Research','Interface Design','Design Systems','Webflow/Next.js']],
        ['🎬','Campaigns & Content','Multi-channel campaigns — concept, art direction, film, OOH, and social — with measurable outcomes.',
         ['Art Direction','Campaign Strategy','Video Production','Social Content']],
        ['🖋','Motion & Interaction','Bringing identities to life through motion — titles, brand films, micro-interactions, and UI animation.',
         ['Brand Motion','UI Animation','Title Sequences','3D & AR']],
      ];
      foreach ($ag_svcs as $i => [$icon, $title, $text, $tags]):
      ?>
      <div class="ag-service ag-reveal" style="transition-delay:<?php echo $i*.08; ?>s">
        <span class="ag-service__num" aria-hidden="true">0<?php echo $i+1; ?></span>
        <span class="ag-service__icon" aria-hidden="true"><?php echo $icon; ?></span>
        <h3 class="ag-service__title"><?php echo esc_html($title); ?></h3>
        <p class="ag-service__text"><?php echo esc_html($text); ?></p>
        <div class="ag-service__tags">
          <?php foreach ($tags as $t): ?><span class="ag-service__tag"><?php echo esc_html($t); ?></span><?php endforeach; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ABOUT ─────────────────────────────────────────────── -->
<section id="about" class="ag-section" aria-labelledby="ag-about-title">
  <div class="ag-wrap">
    <div class="ag-about">
      <div class="ag-about__vis ag-reveal" aria-label="<?php esc_attr_e('Studio founder Mia Thornton','themeflex'); ?>">
        <!-- CSS designer figure -->
        <div class="ag-about__figure">
          <div class="ag-fig__head"></div>
          <div class="ag-fig__neck"></div>
          <div class="ag-fig__body">
            <div class="ag-fig__arm-l"></div>
            <div class="ag-fig__arm-r"><div class="ag-fig__hand"></div></div>
          </div>
          <div class="ag-fig__skirt"></div>
          <div class="ag-fig__legs"><div class="ag-fig__leg"></div><div class="ag-fig__leg"></div></div>
          <div class="ag-fig__foot"></div>
        </div>
        <!-- colour swatches -->
        <div class="ag-about__swatches" aria-hidden="true">
          <?php foreach (['#FF5A36','#D4C5B0','#0C0C0C','#9E9E9E','#F5F0E8'] as $s): ?>
          <div class="ag-about__swatch" style="background:<?php echo esc_attr($s); ?>;"></div>
          <?php endforeach; ?>
        </div>
        <!-- nameplate -->
        <div class="ag-about__caption">
          <p class="ag-about__caption-name">Mia Thornton</p>
          <p class="ag-about__caption-role"><?php esc_html_e('Founder & Executive Creative Director','themeflex'); ?></p>
        </div>
      </div>
      <div class="ag-about__content ag-reveal" style="transition-delay:.12s">
        <span class="ag-eyebrow"><?php esc_html_e('The Studio','themeflex'); ?></span>
        <h2 class="ag-h2" id="ag-about-title"><?php esc_html_e('We Make Work That Matters','themeflex'); ?></h2>
        <p class="ag-lead"><?php esc_html_e('Founded in London in 2009, Forma is an independent creative studio of 28 strategists, designers, directors, and technologists. We\'ve partnered with start-ups, cultural institutions, FTSE 100 companies, and global NGOs — united by a belief that great creative should be both beautiful and effective.','themeflex'); ?></p>
        <div class="ag-about__values">
          <?php foreach ([['Strategic First','Craft without strategy is decoration.'],['Honest Work','No award bait. We measure success in business outcomes.'],['Radical Collaboration','Your team and ours, in the same room.'],['Independent Always','Employee-owned since day one.']] as [$t,$d]): ?>
          <div class="ag-value">
            <p class="ag-value__title"><?php echo esc_html($t); ?></p>
            <p class="ag-value__text"><?php echo esc_html($d); ?></p>
          </div>
          <?php endforeach; ?>
        </div>
        <a href="#contact" class="ag-btn ag-btn--coral"><?php esc_html_e('Meet the Studio','themeflex'); ?></a>
      </div>
    </div>
  </div>
</section>

<!-- PACKAGES ─────────────────────────────────────────── -->
<section id="packages" class="ag-section ag-section--panel" aria-labelledby="ag-pkg-title">
  <div class="ag-wrap">
    <header style="text-align:center;margin-bottom:4rem;" class="ag-reveal">
      <span class="ag-eyebrow"><?php esc_html_e('Engagement','themeflex'); ?></span>
      <h2 class="ag-h2" id="ag-pkg-title"><?php esc_html_e('How We Work Together','themeflex'); ?></h2>
      <p class="ag-lead" style="margin:1rem auto 0;"><?php esc_html_e('Three engagement models designed around your brief, your timeline, and how much strategy you need before creative begins.','themeflex'); ?></p>
    </header>
    <div class="ag-packages">
      <?php
      $ag_pkgs = [
        ['Sprint','£8,500','one-time','For teams who need sharp creative fast — identity refresh, campaign concept, or a landing page.',false,null,
         ['3-week sprint','Lead designer + strategist','Two concept directions','2 rounds of revisions','Final asset delivery']],
        ['Partnership','£14,000','/ month','Our flagship model — full-studio creative partnership for clients with ongoing creative needs.',true,'Most Popular',
         ['Dedicated creative team','Weekly sprint reviews','Unlimited projects in scope','Priority scheduling','Brand stewardship','Monthly strategy session']],
        ['Transformation','Custom','pricing','Enterprise-grade brand or product transformation — research through launch, all disciplines.',false,null,
         ['Full Forma studio','Discovery & research phase','Multi-channel deliverables','Launch support','6-month post-launch review']],
      ];
      foreach ($ag_pkgs as [$name, $price, $unit, $desc, $feat, $badge, $features]):
      ?>
      <div class="ag-pkg ag-reveal<?php echo $feat?' ag-pkg--featured':''; ?>">
        <?php if($badge):?><div class="ag-pkg__badge"><?php echo esc_html($badge);?></div><?php endif;?>
        <div class="ag-pkg__name"><?php echo esc_html($name);?></div>
        <div class="ag-pkg__desc"><?php echo esc_html($desc);?></div>
        <div class="ag-pkg__price"><?php if($price!=='Custom'):?><sup>£</sup><?php echo esc_html(ltrim($price,'£'));?><sub> <?php echo esc_html($unit);?></sub><?php else:echo esc_html($price);endif;?></div>
        <div class="ag-pkg__note"><?php if($price==='Custom') esc_html_e('Contact for a tailored proposal','themeflex'); else esc_html_e('All projects from this rate','themeflex');?></div>
        <ul class="ag-pkg__features">
          <?php foreach($features as $f):?><li class="ag-pkg__feature"><?php echo esc_html($f);?></li><?php endforeach;?>
        </ul>
        <a href="#contact" class="ag-btn <?php echo $feat?'ag-btn--coral':'ag-btn--outline-light';?>" style="width:100%;justify-content:center;"><?php esc_html_e('Enquire','themeflex');?></a>
      </div>
      <?php endforeach;?>
    </div>
  </div>
</section>

<!-- TESTIMONIALS ─────────────────────────────────────── -->
<section class="ag-section" aria-labelledby="ag-testi-title">
  <div class="ag-wrap">
    <header style="margin-bottom:3rem;" class="ag-reveal">
      <span class="ag-eyebrow"><?php esc_html_e('Clients','themeflex');?></span>
      <h2 class="ag-h2" id="ag-testi-title"><?php esc_html_e('What They Say','themeflex');?></h2>
    </header>
    <div class="ag-testis">
      <?php
      $ag_ts=[
        ['#FF5A36','J','James M.','CMO, Luminos Energy','Forma rebuilt our entire brand in eight weeks. The result was unrecognisable from what we had before — in the best possible way. We walked away from that rebrand with an identity that felt earned.'],
        ['#D4C5B0','S','Sasha O.','Head of Brand, Vela Sportswear','The campaign they made for our SS24 collection was the best creative we\'ve ever produced. Forma pushed us harder than we pushed ourselves. The 48M impressions didn\'t hurt either.'],
        ['#9E9E9E','D','David P.','CEO, Arcana Finance','I was sceptical about spending on brand at Series B. Forma convinced us, and our NPS went from 32 to 67 in six months. I now believe brand is the highest-ROI investment a scale-up can make.'],
      ];
      foreach($ag_ts as $i=>[$bg,$init,$name,$role,$text]):?>
      <div class="ag-testi ag-reveal" style="transition-delay:<?php echo $i*.1;?>s">
        <div class="ag-testi__mark">"</div>
        <p class="ag-testi__text"><?php echo esc_html($text);?></p>
        <div class="ag-testi__author">
          <div class="ag-testi__avatar" style="background:<?php echo esc_attr($bg);?>;color:<?php echo $bg==='#D4C5B0'?'#0C0C0C':'#fff';?>"><?php echo esc_html($init);?></div>
          <div><span class="ag-testi__name"><?php echo esc_html($name);?></span><span class="ag-testi__role"><?php echo esc_html($role);?></span></div>
        </div>
      </div>
      <?php endforeach;?>
    </div>
  </div>
</section>

<!-- FAQ ──────────────────────────────────────────────── -->
<section class="ag-section ag-section--panel" aria-labelledby="ag-faq-title">
  <div class="ag-wrap">
    <header style="text-align:center;margin-bottom:3rem;" class="ag-reveal">
      <span class="ag-eyebrow"><?php esc_html_e('Questions','themeflex');?></span>
      <h2 class="ag-h2" id="ag-faq-title"><?php esc_html_e('Common Questions','themeflex');?></h2>
    </header>
    <div class="ag-faq-list">
      <?php
      $ag_faqs=[
        ['How long does a brand identity project take?','A full brand identity — strategy, naming, visual identity, and guidelines — typically takes 8–14 weeks depending on decision-making speed and scope. Sprint projects can turn around core assets in 3 weeks.'],
        ['Do you work with early-stage companies?','Yes. We love working with founders who are still figuring out their story — it\'s some of our most interesting work. Series A and B companies are a significant portion of our client roster.'],
        ['Can we see your pricing before committing?','We\'ve published indicative pricing above. All engagements start with a 45-minute discovery call, after which we provide a detailed scope and investment proposal within 3 working days.'],
        ['Do you do one-off projects or only retainers?','Both. Our Sprint package is designed for one-off, time-boxed projects. Our Partnership model is for clients who benefit from a long-term creative relationship. Many clients start with a Sprint and move to Partnership.'],
        ['Who would be working on our account?','Every Forma client gets a Creative Director, Senior Designer, and Strategist as their core team. We don\'t hand off to juniors once the pitch is won.'],
        ['Where are you based and do you work internationally?','Our studios are in London (Shoreditch) and Berlin (Mitte). We work with clients globally — we\'ve delivered projects across 18 countries.'],
      ];
      foreach($ag_faqs as $k=>[$q,$a]):
        $fid='ag-faq-'.$k;?>
      <div class="ag-faq" id="<?php echo esc_attr($fid);?>">
        <button class="ag-faq__q" aria-expanded="false" aria-controls="<?php echo esc_attr($fid.'-a');?>">
          <?php echo esc_html($q);?>
          <span class="ag-faq__icon" aria-hidden="true">+</span>
        </button>
        <div class="ag-faq__a" id="<?php echo esc_attr($fid.'-a');?>" role="region">
          <p class="ag-faq__a-inner"><?php echo esc_html($a);?></p>
        </div>
      </div>
      <?php endforeach;?>
    </div>
  </div>
</section>

<!-- TEAM ─────────────────────────────────────────────── -->
<section class="ag-section" aria-labelledby="ag-team-title">
  <div class="ag-wrap">
    <header style="margin-bottom:3.5rem;" class="ag-reveal">
      <span class="ag-eyebrow"><?php esc_html_e('The People','themeflex');?></span>
      <h2 class="ag-h2" id="ag-team-title"><?php esc_html_e('Creative Leadership','themeflex');?></h2>
      <p class="ag-lead"><?php esc_html_e('Our senior team is hands-on. Every client project is led by a director — not handed off to a team you never met during the pitch.','themeflex');?></p>
    </header>
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:1.5rem;">
      <?php
      $ag_team=[
        ['Mia Thornton','Founder & ECD','15 years building brands for global clients. Previously at Pentagram London.','#FF5A36','M'],
        ['Oscar Ruiz','Creative Director','Art direction and campaign lead. Ex-Wieden+Kennedy Amsterdam.','#D4C5B0','O'],
        ['Nadia Osei','Strategy Director','Brand and comms strategy from challenger brand to market leader.','#9E9E9E','N'],
        ['Kai Nakamura','Design Director','UX, design systems, and digital experience. Former design lead at Figma.','#FF5A36','K'],
      ];
      foreach($ag_team as $i=>[$name,$role,$bio,$col,$init]):
      ?>
      <div class="ag-reveal" style="transition-delay:<?php echo $i*.08;?>s">
        <div style="height:220px;background:var(--ag-panel);border:1px solid rgba(255,255,255,.08);display:flex;flex-direction:column;align-items:center;justify-content:flex-end;padding:1.5rem;margin-bottom:1rem;position:relative;overflow:hidden;">
          <!-- abstract colour bar at top -->
          <div style="position:absolute;top:0;left:0;right:0;height:4px;background:<?php echo esc_attr($col);?>;"></div>
          <!-- initial circle -->
          <div style="width:64px;height:64px;border-radius:50%;background:<?php echo esc_attr($col);?>;display:flex;align-items:center;justify-content:center;font-family:var(--ag-serif);font-size:1.6rem;font-weight:800;color:<?php echo $col==='#D4C5B0'?'#0C0C0C':'#fff';?>;margin-bottom:.75rem;"><?php echo esc_html($init);?></div>
          <p style="font-family:var(--ag-serif);font-size:.65rem;font-weight:700;letter-spacing:.15em;text-transform:uppercase;color:<?php echo esc_attr($col);?>;text-align:center;"><?php echo esc_html($role);?></p>
        </div>
        <h3 style="font-family:var(--ag-serif);font-size:1.1rem;font-weight:700;margin-bottom:.4rem;"><?php echo esc_html($name);?></h3>
        <p style="font-size:.82rem;line-height:1.65;color:var(--ag-fog);"><?php echo esc_html($bio);?></p>
      </div>
      <?php endforeach;?>
    </div>
    <div style="margin-top:3rem;padding:2rem;border:1px solid rgba(255,255,255,.08);display:flex;align-items:center;justify-content:space-between;gap:2rem;">
      <div>
        <p style="font-family:var(--ag-serif);font-size:1.1rem;font-weight:700;margin-bottom:.4rem;"><?php esc_html_e('28 people across London and Berlin.','themeflex');?></p>
        <p style="font-size:.88rem;color:var(--ag-fog);"><?php esc_html_e('Strategists, designers, directors, developers, producers, and writers — all in-house, all under one roof.','themeflex');?></p>
      </div>
      <a href="<?php echo esc_url(home_url('/careers'));?>" class="ag-btn ag-btn--outline-light" style="flex-shrink:0;"><?php esc_html_e('We\'re Hiring','themeflex');?></a>
    </div>
  </div>
</section>

<!-- CTA ──────────────────────────────────────────────── -->
<section class="ag-cta-banner ag-reveal" aria-labelledby="ag-cta-title">
  <div class="ag-wrap">
    <h2 class="ag-h2" id="ag-cta-title"><?php esc_html_e('Ready to Make Something Great?','themeflex');?></h2>
    <p class="ag-lead"><?php esc_html_e('Tell us about your brief. We\'ll come back to you within 24 hours with questions worth answering.','themeflex');?></p>
    <div class="ag-cta-banner__actions">
      <a href="#contact" class="ag-btn ag-btn--white"><?php esc_html_e('Start the Conversation','themeflex');?></a>
      <a href="#work" class="ag-btn ag-btn--outline-white"><?php esc_html_e('See More Work','themeflex');?></a>
    </div>
  </div>
</section>

<!-- CONTACT ──────────────────────────────────────────── -->
<section id="contact" class="ag-section" aria-labelledby="ag-contact-title">
  <div class="ag-wrap">
    <div class="ag-contact">
      <div class="ag-reveal">
        <span class="ag-eyebrow"><?php esc_html_e('New Business','themeflex');?></span>
        <h2 class="ag-h2" id="ag-contact-title"><?php esc_html_e('Let\'s Talk','themeflex');?></h2>
        <p class="ag-lead"><?php esc_html_e('Tell us your brief — rough or complete — and we\'ll set up a 45-minute discovery call. No commitments, no pitch decks (from us anyway).','themeflex');?></p>
        <div class="ag-contact__links" style="margin-top:2rem;">
          <?php foreach([['✉️','New Business','newbiz@forma.studio'],['📍','London Studio','36 Curtain Rd, Shoreditch EC2A 3NH'],['🌐','Berlin Studio','Torstr. 14, 10119 Berlin Mitte']] as [$icon,$label,$val]):?>
          <div class="ag-contact__link">
            <span class="ag-contact__link-icon"><?php echo $icon;?></span>
            <div><span class="ag-contact__link-label"><?php echo esc_html($label);?></span><span class="ag-contact__link-val"><?php echo esc_html($val);?></span></div>
          </div>
          <?php endforeach;?>
        </div>
      </div>
      <div class="ag-reveal" style="transition-delay:.12s">
        <form class="ag-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>" novalidate>
          <?php wp_nonce_field('tf_ag_booking','tf_ag_nonce');?>
          <input type="hidden" name="action" value="tf_ag_enquiry">
          <div class="ag-form-row">
            <div class="ag-field"><label class="ag-label" for="ag-name"><?php esc_html_e('Name *','themeflex');?></label><input class="ag-input" id="ag-name" name="name" type="text" required placeholder="<?php esc_attr_e('Mia Thornton','themeflex');?>"></div>
            <div class="ag-field"><label class="ag-label" for="ag-company"><?php esc_html_e('Company','themeflex');?></label><input class="ag-input" id="ag-company" name="company" type="text" placeholder="<?php esc_attr_e('Forma Studio','themeflex');?>"></div>
          </div>
          <div class="ag-form-row">
            <div class="ag-field"><label class="ag-label" for="ag-email"><?php esc_html_e('Email *','themeflex');?></label><input class="ag-input" id="ag-email" name="email" type="email" required placeholder="<?php esc_attr_e('mia@forma.studio','themeflex');?>"></div>
            <div class="ag-field"><label class="ag-label" for="ag-budget"><?php esc_html_e('Budget','themeflex');?></label>
              <select class="ag-select" id="ag-budget" name="budget">
                <option value=""><?php esc_html_e('Select range…','themeflex');?></option>
                <option><?php esc_html_e('Under £10,000','themeflex');?></option>
                <option><?php esc_html_e('£10,000 – £30,000','themeflex');?></option>
                <option><?php esc_html_e('£30,000 – £80,000','themeflex');?></option>
                <option><?php esc_html_e('£80,000+','themeflex');?></option>
              </select>
            </div>
          </div>
          <div class="ag-field"><label class="ag-label" for="ag-service"><?php esc_html_e('Service Interest','themeflex');?></label>
            <select class="ag-select" id="ag-service" name="service">
              <option value=""><?php esc_html_e('Select a service…','themeflex');?></option>
              <option><?php esc_html_e('Brand Strategy & Identity','themeflex');?></option>
              <option><?php esc_html_e('Digital & UX Design','themeflex');?></option>
              <option><?php esc_html_e('Campaign & Content','themeflex');?></option>
              <option><?php esc_html_e('Motion & Interaction','themeflex');?></option>
              <option><?php esc_html_e('Full Transformation','themeflex');?></option>
            </select>
          </div>
          <div class="ag-field"><label class="ag-label" for="ag-brief"><?php esc_html_e('Tell Us About Your Brief *','themeflex');?></label><textarea class="ag-textarea" id="ag-brief" name="message" required rows="5" placeholder="<?php esc_attr_e('What are you trying to achieve? What\'s the challenge? What would success look like?','themeflex');?>"></textarea></div>
          <button type="submit" class="ag-btn ag-btn--coral"><?php esc_html_e('Send Brief','themeflex');?></button>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- FOOTER ───────────────────────────────────────────── -->
<footer class="ag-footer" role="contentinfo">
  <div class="ag-wrap">
    <div class="ag-footer__top">
      <div class="ag-footer__brand">
        <a href="<?php echo esc_url(home_url('/'));?>" class="ag-nav__logo">FORMA<span style="color:var(--ag-coral)">.</span></a>
        <p><?php esc_html_e('Independent creative studio. London & Berlin. Employee-owned since 2009.','themeflex');?></p>
      </div>
      <div><p class="ag-footer__col-title"><?php esc_html_e('Work','themeflex');?></p><ul class="ag-footer__links"><li><a href="#work"><?php esc_html_e('Brand Identity','themeflex');?></a></li><li><a href="#work"><?php esc_html_e('Campaigns','themeflex');?></a></li><li><a href="#work"><?php esc_html_e('Digital','themeflex');?></a></li><li><a href="#work"><?php esc_html_e('Motion','themeflex');?></a></li><li><a href="#work"><?php esc_html_e('Packaging','themeflex');?></a></li></ul></div>
      <div><p class="ag-footer__col-title"><?php esc_html_e('Studio','themeflex');?></p><ul class="ag-footer__links"><li><a href="#about"><?php esc_html_e('About','themeflex');?></a></li><li><a href="#services"><?php esc_html_e('Services','themeflex');?></a></li><li><a href="<?php echo esc_url(home_url('/journal'));?>"><?php esc_html_e('Journal','themeflex');?></a></li><li><a href="<?php echo esc_url(home_url('/careers'));?>"><?php esc_html_e('Careers','themeflex');?></a></li><li><a href="#contact"><?php esc_html_e('Press','themeflex');?></a></li></ul></div>
      <div><p class="ag-footer__col-title"><?php esc_html_e('Follow','themeflex');?></p><ul class="ag-footer__links"><li><a href="#" rel="noopener noreferrer">Instagram</a></li><li><a href="#" rel="noopener noreferrer">LinkedIn</a></li><li><a href="#" rel="noopener noreferrer">Behance</a></li><li><a href="#" rel="noopener noreferrer">Dribbble</a></li></ul></div>
    </div>
    <div class="ag-footer__bottom">
      <span>&copy; <?php echo esc_html(date('Y'));?> Forma Creative Studio Ltd.</span>
      <span><?php esc_html_e('D&AD Gold · Webby Award · Cannes Lions · Employee-Owned','themeflex');?></span>
    </div>
  </div>
</footer>

</div><!-- /.ag-page -->

<script>
(function(){
  'use strict';
  var agObs=new IntersectionObserver(function(e){e.forEach(function(el){if(el.isIntersecting){el.target.classList.add('ag-visible');agObs.unobserve(el.target);}});},{threshold:.12});
  document.querySelectorAll('.ag-reveal').forEach(function(el){agObs.observe(el);});

  document.querySelectorAll('.ag-faq__q').forEach(function(btn){
    btn.addEventListener('click',function(){
      var faq=btn.closest('.ag-faq'),ans=faq.querySelector('.ag-faq__a'),inn=faq.querySelector('.ag-faq__a-inner'),open=faq.classList.contains('ag-open');
      document.querySelectorAll('.ag-faq.ag-open').forEach(function(f){f.querySelector('.ag-faq__a').style.maxHeight='0';f.classList.remove('ag-open');f.querySelector('.ag-faq__q').setAttribute('aria-expanded','false');});
      if(!open){ans.style.maxHeight=inn.scrollHeight+'px';faq.classList.add('ag-open');btn.setAttribute('aria-expanded','true');}
    });
  });

  var agNav=document.querySelector('.ag-nav');
  window.addEventListener('scroll',function(){agNav.style.boxShadow=window.scrollY>10?'0 4px 30px rgba(0,0,0,.5)':'';},{passive:true});
})();
</script>

<?php get_footer(); ?>
