<?php
/**
 * Template Name: Architect — Architecture & Design Studio
 *
 * Premium architecture practice page for ThemeFlex.
 * Concept : Minimal modernist drawing studio at blue hour — drafting table,
 *           architectural section model, blueprint elevation, steel ruler,
 *           floating geometric wireframe forms.
 * Palette : Pure white / graphite / slate / cobalt accent.
 * Fonts   : Cormorant (headings, thin-italic elegance) + Inter (body).
 * Namespace: --ar-*
 *
 * @package ThemeFlex
 */

if ( ! defined( 'ABSPATH' ) ) exit;

srand( crc32( get_the_permalink() ) );

/* ── hero floating geometry ─────────────────── */
$ar_shapes = [];
for($i=0;$i<18;$i++){
    $ar_shapes[]=[
        'left'  => rand(5,95),
        'top'   => rand(8,85),
        'size'  => rand(16,56),
        'delay' => rand(0,8000),
        'dur'   => rand(5000,12000),
        'type'  => rand(0,3), // 0=square 1=triangle 2=circle 3=cross
        'rot'   => rand(0,180),
    ];
}

/* ── blueprint grid lines (random density) ──── */
$ar_grid_cols = rand(8,12);
$ar_grid_rows = rand(6,9);

/* ── stats ──────────────────────────────────── */
$ar_stats=[
    ['val'=>63,  'suffix'=>'',  'label'=>'Award-Winning Projects'],
    ['val'=>22,  'suffix'=>'yrs','label'=>'Studio Founded'],
    ['val'=>4.9, 'suffix'=>'★', 'label'=>'Client Satisfaction'],
    ['val'=>14,  'suffix'=>'',  'label'=>'International Awards'],
];

/* ── services ───────────────────────────────── */
$ar_services=[
    ['icon'=>'🏛','name'=>'New Build Residential', 'desc'=>'From concept to completion — bespoke homes that respond to place, light and the way you live.'],
    ['icon'=>'🏢','name'=>'Commercial & Mixed Use',  'desc'=>'Workplace, retail and mixed-use buildings that balance functionality, brand identity and sustainability.'],
    ['icon'=>'🔄','name'=>'Refurbishment & Extension','desc'=>'Sensitive interventions that breathe new life into existing buildings while respecting their architectural character.'],
    ['icon'=>'🌿','name'=>'Sustainable Design',       'desc'=>'Passive house, BREEAM and net-zero strategies embedded from the very first sketch.'],
    ['icon'=>'🗺','name'=>'Masterplanning',           'desc'=>'Large-scale visioning and planning frameworks for urban regeneration and mixed-use developments.'],
    ['icon'=>'📐','name'=>'Interior Architecture',    'desc'=>'Spatial layouts, material palettes and bespoke joinery that make interiors as considered as the envelope.'],
];

/* ── portfolio projects ─────────────────────── */
$ar_projects=[
    ['name'=>'The Meridian House',    'type'=>'Private Residence',    'loc'=>'Hampstead, London',    'year'=>'2024'],
    ['name'=>'Silo Arts Quarter',     'type'=>'Cultural / Mixed-Use', 'loc'=>'Bristol',              'year'=>'2023'],
    ['name'=>'Cascade Pavilion',      'type'=>'Public Pavilion',      'loc'=>'Edinburgh',            'year'=>'2023'],
    ['name'=>'West Yard Apartments',  'type'=>'Residential',          'loc'=>'Manchester',           'year'=>'2022'],
    ['name'=>'The Glass Reading Room','type'=>'Library Extension',     'loc'=>'Cambridge',            'year'=>'2022'],
    ['name'=>'Tidal Office Park',     'type'=>'Commercial',           'loc'=>'Cardiff Bay',          'year'=>'2021'],
];

/* ── project palette for CSS art scenes ─────── */
$ar_proj_scenes=[
    ['bg'=>'#F0EEE8','wall'=>'#E8E4DC','accent'=>'#2B5BE8'],
    ['bg'=>'#1A2030','wall'=>'#242C40','accent'=>'#E87828'],
    ['bg'=>'#E8EDE8','wall'=>'#D8E0D8','accent'=>'#2E8028'],
    ['bg'=>'#F4F0F8','wall'=>'#EAE4F0','accent'=>'#7828C8'],
    ['bg'=>'#FFF8F0','wall'=>'#F4ECD8','accent'=>'#C84828'],
    ['bg'=>'#E8F4F8','wall'=>'#D4EAF0','accent'=>'#1890C8'],
];

/* ── team ───────────────────────────────────── */
$ar_team=[
    ['name'=>'Eleanor Ashby',    'role'=>'Founding Director',   'qual'=>'ARB · RIBA · MA Arch (Bartlett)'],
    ['name'=>'Thomas Kern',      'role'=>'Associate Director',  'qual'=>'ARB · RIBA · MArch (ETH Zurich)'],
    ['name'=>'Imogen Patel',     'role'=>'Senior Architect',    'qual'=>'ARB · RIBA · MArch (Edinburgh)'],
    ['name'=>'Rafi Osei',        'role'=>'Sustainability Lead',  'qual'=>'ARB · BREEAM AP · MArch (UCL)'],
];

/* ── process ────────────────────────────────── */
$ar_process=[
    ['n'=>'01','t'=>'Briefing & Vision',   'd'=>'We listen first. Careful briefing ensures every design decision serves your needs, aspirations and budget.'],
    ['n'=>'02','t'=>'Concept & Feasibility','d'=>'Initial sketches, massing studies and planning research establish what is possible — and what is compelling.'],
    ['n'=>'03','t'=>'Design Development',   'd'=>'Concepts are refined through drawings, models and material boards until every detail feels inevitable.'],
    ['n'=>'04','t'=>'Delivery & Completion','d'=>'Contract administration, site visits and quality control to ensure the building is realised to its full potential.'],
];

/* ── testimonials ───────────────────────────── */
$ar_testimonials=[
    ['name'=>'Robert & Lily Crane','role'=>'Private Residence Client','text'=>'Eleanor and the team transformed a difficult plot into a home we never could have imagined. Their ability to hold the big vision while obsessing over every detail is genuinely extraordinary.'],
    ['name'=>'Claire Morrow, CEO','role'=>'Silo Arts Quarter',       'text'=>'Ashby Kern delivered a building that became a landmark for the city. On budget, on time, and with an approach to community engagement that went far beyond what we expected.'],
    ['name'=>'Prof. James Aldrich','role'=>'Cambridge Library Extension','text'=>'The Glass Reading Room sits beside a listed building with extraordinary confidence. The planning process was complex and they navigated it brilliantly.'],
];

/* ── awards ─────────────────────────────────── */
$ar_awards=[
    'RIBA National Award 2024',
    'AJ Architecture Awards — Housing 2023',
    'Civic Trust Award 2023',
    'BD Architect of the Year — Shortlist 2022',
    'RICS Building Conservation Award 2022',
    'Dezeen Award — Residential 2021',
];

/* ── FAQs ───────────────────────────────────── */
$ar_faqs=[
    ['q'=>'How much does it cost to commission an architect?',
     'a'=>'Our fees are typically a percentage of the construction cost — usually between 8% and 15% depending on project type and complexity. We provide a fixed fee proposal after an initial consultation so there are no surprises.'],
    ['q'=>'Do you handle planning permission?',
     'a'=>'Yes. We prepare and submit all planning applications, liaise with local authorities and manage the appeal process if required. Our planning success rate is 94%.'],
    ['q'=>'How long does the design process take?',
     'a'=>'A typical residential project runs 12–18 months from first meeting to planning approval. Construction adds 6–18 months depending on size. We provide a detailed programme at the outset so you know exactly what to expect.'],
    ['q'=>'Do you work on listed buildings or conservation areas?',
     'a'=>'Yes — heritage and conservation work is a studio strength. We have extensive experience with listed building consent and have a strong track record with heritage bodies.'],
    ['q'=>'Can I commission just one phase of work?',
     'a'=>'Absolutely. We can be engaged for concept only, through to planning, through to full delivery — or any combination. Many clients begin with a feasibility study before committing to the full project.'],
];

get_header();
?>

<style>
/* ══════════════════════════════════════════
   ARCHITECT — CSS DESIGN SYSTEM
   Namespace: --ar-*
══════════════════════════════════════════ */
@import url('https://fonts.googleapis.com/css2?family=Cormorant:ital,wght@0,300;0,400;0,500;1,300;1,400&family=Inter:wght@300;400;500;600&display=swap');

:root{
    --ar-white   : #FFFFFF;
    --ar-chalk   : #F5F3EF;
    --ar-light   : #EAE7E2;
    --ar-smoke   : #C8C4BC;
    --ar-mid     : #8C8880;
    --ar-graphite: #3C3A38;
    --ar-dark    : #1C1A18;
    --ar-black   : #0E0C0A;
    --ar-cobalt  : #1E4ED8;
    --ar-cobalt-l: #3B6EF0;
    --ar-r       : 0px;
    --ar-font-h  : 'Cormorant', serif;
    --ar-font-b  : 'Inter', sans-serif;
    --ar-shadow  : 0 24px 80px rgba(0,0,0,.14);
    --ar-border  : #D8D4CC;
}

.ar-wrap *{ box-sizing:border-box; margin:0; padding:0; }
.ar-wrap{ font-family:var(--ar-font-b); color:var(--ar-graphite); background:var(--ar-white); line-height:1.7; }
.ar-container{ max-width:1200px; margin:0 auto; padding:0 40px; }

/* ── Typography ─────────────────────────── */
.ar-h1{ font-family:var(--ar-font-h); font-size:clamp(3.2rem,7vw,6.4rem); font-weight:300; font-style:italic; line-height:1.05; color:var(--ar-dark); letter-spacing:-.01em; }
.ar-h2{ font-family:var(--ar-font-h); font-size:clamp(2rem,4.5vw,3.2rem); font-weight:300; color:var(--ar-dark); }
.ar-h3{ font-family:var(--ar-font-h); font-size:1.5rem; font-weight:400; color:var(--ar-dark); }
.ar-lead{ font-size:1rem; color:var(--ar-mid); font-weight:300; max-width:580px; line-height:1.8; }
.ar-overline{ font-family:var(--ar-font-b); font-size:.7rem; font-weight:600; letter-spacing:.22em; color:var(--ar-cobalt); text-transform:uppercase; display:block; margin-bottom:1rem; }
.ar-accent{ color:var(--ar-cobalt); font-style:italic; }

/* ── Buttons ────────────────────────────── */
.ar-btn{
    display:inline-flex; align-items:center; gap:.5rem;
    font-family:var(--ar-font-b); font-size:.8rem; font-weight:500; letter-spacing:.14em;
    padding:.85rem 2rem; background:var(--ar-dark); color:var(--ar-white);
    border:none; cursor:pointer; text-decoration:none; text-transform:uppercase;
    transition:background .25s, transform .2s;
}
.ar-btn:hover{ background:var(--ar-cobalt); transform:translateY(-2px); }
.ar-btn-outline{
    background:transparent; border:1.5px solid var(--ar-dark); color:var(--ar-dark);
}
.ar-btn-outline:hover{ background:var(--ar-dark); color:var(--ar-white); }

/* ── Section spacing ────────────────────── */
.ar-section{ padding:100px 0; }
.ar-section-alt{ background:var(--ar-chalk); }
.ar-section-dark{ background:var(--ar-dark); }
.ar-section-header{ margin-bottom:64px; }
.ar-section-header.center{ text-align:center; }
.ar-section-header.center .ar-lead{ margin:16px auto 0; }
.ar-divider{
    display:inline-block; width:48px; height:2px; background:var(--ar-cobalt); margin:24px 0;
}

/* ══════════════════════════════════════════
   HERO — Architectural drawing studio at blue hour
══════════════════════════════════════════ */
.ar-hero{
    position:relative; min-height:100vh;
    background:linear-gradient(160deg,#EEF1F8 0%, #E4E8F2 40%, #D8DFF0 100%);
    overflow:hidden; display:flex; align-items:center;
}

/* blueprint grid overlay */
.ar-blueprint{
    position:absolute; inset:0;
    background-image:
        linear-gradient(rgba(30,78,216,.07) 1px, transparent 1px),
        linear-gradient(90deg, rgba(30,78,216,.07) 1px, transparent 1px);
    background-size:60px 60px;
    pointer-events:none;
}
/* blueprint axis lines */
.ar-blueprint::before{
    content:''; position:absolute; top:50%; left:0; right:0; height:1px;
    background:rgba(30,78,216,.18);
}
.ar-blueprint::after{
    content:''; position:absolute; left:50%; top:0; bottom:0; width:1px;
    background:rgba(30,78,216,.18);
}

/* drafting table */
.ar-table{
    position:absolute; bottom:0; left:-4%; right:-4%; height:35%;
    background:linear-gradient(180deg,#D4C8A8 0%,#C4B898 100%);
    border-top:4px solid #B8A878;
    transform:perspective(800px) rotateX(18deg); transform-origin:bottom;
}
/* table underside */
.ar-table::before{
    content:''; position:absolute; top:-2px; left:0; right:0;
    height:6px; background:#A89868;
}
/* table grid / drawing */
.ar-table::after{
    content:''; position:absolute; inset:0;
    background-image:
        linear-gradient(rgba(30,78,216,.15) 1px, transparent 1px),
        linear-gradient(90deg,rgba(30,78,216,.15) 1px, transparent 1px);
    background-size:40px 40px;
}

/* parallel rule */
.ar-rule{
    position:absolute; bottom:34%; left:8%; width:52%; height:8px;
    background:linear-gradient(90deg,#B0C8E8,#D0DFF4,#B0C8E8);
    border:1px solid #8090B0;
    box-shadow:0 2px 6px rgba(0,0,0,.2);
}
/* ruler markings */
.ar-rule::before{
    content:''; position:absolute; top:0; left:0; right:0; bottom:0;
    background-image:repeating-linear-gradient(90deg,rgba(0,0,0,.3) 0,rgba(0,0,0,.3) 1px,transparent 1px,transparent 10px);
}

/* set square */
.ar-setsquare{
    position:absolute; bottom:35%; left:38%; width:0; height:0;
    border-left:80px solid transparent;
    border-bottom:100px solid rgba(30,78,216,.18);
    filter:drop-shadow(2px 4px 8px rgba(0,0,0,.2));
}

/* architectural section/elevation on table */
.ar-elevation{
    position:absolute; bottom:38%; left:12%; width:36%; height:44%;
    border:2px solid rgba(30,78,216,.5);
    background:rgba(255,255,255,.5);
}
/* floor lines */
.ar-elevation::before{
    content:''; position:absolute;
    top:30%; left:0; right:0; height:1.5px; background:rgba(30,78,216,.4);
    box-shadow:0 1px 0 rgba(30,78,216,.2), 0 52px 0 rgba(30,78,216,.4), 0 53px 0 rgba(30,78,216,.2);
}
/* elevation windows */
.ar-el-win{
    position:absolute; background:rgba(30,78,216,.15);
    border:1px solid rgba(30,78,216,.5);
}
/* elevation roof triangle */
.ar-el-roof{
    position:absolute; top:-22px; left:20%; right:20%; height:0;
    border-left:calc(30% / 2) solid transparent;
    border-right:calc(30% / 2) solid transparent;
    border-bottom:22px solid rgba(30,78,216,.5);
    left:0; right:0;
}

/* 3-D model wireframe box */
.ar-model{
    position:absolute; bottom:42%; right:8%;
    width:120px; height:120px;
    border:2px solid rgba(30,78,216,.55);
    transform:rotateX(-20deg) rotateY(35deg);
    transform-style:preserve-3d;
    background:transparent;
}
.ar-model::before{
    content:''; position:absolute; top:-40px; left:-40px;
    width:120px; height:120px;
    border:2px solid rgba(30,78,216,.3);
    transform:translateZ(-80px);
    background:rgba(30,78,216,.04);
}
.ar-model::after{
    content:''; position:absolute; top:0; left:0; right:0; bottom:0;
    background:rgba(30,78,216,.06);
}
/* model top */
.ar-model-top{
    position:absolute; top:-42px; left:-2px; right:-2px;
    height:42px; border-top:2px solid rgba(30,78,216,.45);
    border-left:2px solid rgba(30,78,216,.35);
    transform:skewX(-40deg);
    background:rgba(30,78,216,.07);
}
/* model side */
.ar-model-side{
    position:absolute; top:-2px; right:-42px; bottom:-2px;
    width:42px; border-top:2px solid rgba(30,78,216,.35);
    border-right:2px solid rgba(30,78,216,.45);
    transform:skewY(-50deg);
    background:rgba(30,78,216,.09);
}

/* pencil on table */
.ar-pencil{
    position:absolute; bottom:36%; left:52%; width:160px; height:8px;
    background:linear-gradient(90deg,#F5C842 0%,#F5C842 85%,#FDD8A0 85%,#FDD8A0 90%,#2A2A2A 90%);
    border-radius:0 4px 4px 0;
    transform:rotate(-8deg);
    box-shadow:0 2px 6px rgba(0,0,0,.25);
}
.ar-pencil::before{
    content:''; position:absolute; left:-6px; top:-4px;
    border-top:8px solid transparent;
    border-bottom:8px solid transparent;
    border-right:10px solid #F5C842;
}

/* floating geometric shapes */
.ar-shape{
    position:absolute; pointer-events:none; opacity:.18;
    border:1.5px solid var(--ar-cobalt);
    animation:ar-shape-drift var(--sd) ease-in-out var(--sde) infinite alternate;
}
.ar-shape.sq{}
.ar-shape.circ{ border-radius:50%; }
.ar-shape.tri{
    border:none; width:0; height:0;
    background:transparent;
    border-left:calc(var(--ss)/2) solid transparent;
    border-right:calc(var(--ss)/2) solid transparent;
    border-bottom:calc(var(--ss) * .87) solid rgba(30,78,216,.25);
}
.ar-shape.cross{
    background:rgba(30,78,216,.18); border:none;
    clip-path:polygon(38% 0,62% 0,62% 38%,100% 38%,100% 62%,62% 62%,62% 100%,38% 100%,38% 62%,0 62%,0 38%,38% 38%);
}

/* ── hero layout ─────────────────────────── */
.ar-hero-inner{
    position:relative; z-index:10;
    display:grid; grid-template-columns:1fr 1fr; gap:80px; align-items:center;
    max-width:1200px; margin:0 auto; padding:140px 40px 80px;
    width:100%;
}
.ar-hero-kicker{ display:flex; align-items:center; gap:12px; margin-bottom:24px; }
.ar-hero-kicker-line{ width:40px; height:1.5px; background:var(--ar-cobalt); }
.ar-hero-actions{ display:flex; gap:16px; flex-wrap:wrap; margin-top:40px; }
.ar-hero-meta{ margin-top:48px; display:flex; gap:40px; }
.ar-hero-meta-item{ }
.ar-hero-meta-val{ font-family:var(--ar-font-h); font-size:2rem; font-weight:300; color:var(--ar-dark); }
.ar-hero-meta-label{ font-size:.72rem; letter-spacing:.15em; text-transform:uppercase; color:var(--ar-mid); }

/* scene card */
.ar-scene-card{
    position:relative; background:var(--ar-white);
    border:1.5px solid var(--ar-border);
    aspect-ratio:3/4; overflow:hidden;
    box-shadow:var(--ar-shadow);
}
.ar-sc-inner{
    position:absolute; inset:0;
    background:linear-gradient(160deg,#EEF1F8 0%,#D8DFF0 100%);
    overflow:hidden;
}
/* card blueprint grid */
.ar-sc-inner::before{
    content:''; position:absolute; inset:0;
    background-image:
        linear-gradient(rgba(30,78,216,.1) 1px, transparent 1px),
        linear-gradient(90deg,rgba(30,78,216,.1) 1px, transparent 1px);
    background-size:24px 24px;
}
/* card drafting surface */
.ar-sc-table{
    position:absolute; bottom:0; left:0; right:0; height:30%;
    background:linear-gradient(180deg,#D4C8A8,#C4B898);
    border-top:3px solid #B8A878;
}
/* card elevation drawing */
.ar-sc-elev{
    position:absolute; bottom:32%; left:8%; right:30%; height:38%;
    border:1.5px solid rgba(30,78,216,.55);
    background:rgba(255,255,255,.4);
}
/* card model */
.ar-sc-model{
    position:absolute; bottom:38%; right:6%; width:60px; height:60px;
    border:1.5px solid rgba(30,78,216,.55);
    transform:rotateX(-20deg) rotateY(35deg);
    transform-style:preserve-3d;
    background:rgba(30,78,216,.06);
}
.ar-sc-model::before{
    content:''; position:absolute; top:-20px; left:-20px;
    width:60px; height:60px;
    border:1.5px solid rgba(30,78,216,.3);
    transform:translateZ(-40px);
}
.ar-float-badge{
    position:absolute; bottom:16px; left:16px; right:16px;
    background:var(--ar-dark); color:var(--ar-white);
    font-family:var(--ar-font-b); font-size:.7rem; font-weight:500;
    letter-spacing:.12em; text-transform:uppercase;
    padding:10px 16px; display:flex; align-items:center; gap:8px;
    animation:ar-float 3s ease-in-out infinite;
}
.ar-float-badge::before{ content:'✦'; color:var(--ar-cobalt); }

/* ══════════════════════════════════════════
   STATS BAR
══════════════════════════════════════════ */
.ar-stats-bar{ background:var(--ar-dark); padding:56px 0; }
.ar-stats-grid{ display:grid; grid-template-columns:repeat(4,1fr); gap:0; }
.ar-stat-cell{
    text-align:center; padding:0 32px;
    border-right:1px solid rgba(255,255,255,.1);
}
.ar-stat-cell:last-child{ border-right:none; }
.ar-stat-val{
    font-family:var(--ar-font-h); font-size:3.2rem; font-weight:300;
    color:var(--ar-white); display:block; letter-spacing:-.01em;
}
.ar-stat-label{
    font-size:.7rem; letter-spacing:.18em; text-transform:uppercase;
    color:rgba(255,255,255,.5); margin-top:6px;
}

/* ══════════════════════════════════════════
   ABOUT / PHILOSOPHY
══════════════════════════════════════════ */
.ar-about-grid{ display:grid; grid-template-columns:1fr 1fr; gap:100px; align-items:center; }
.ar-about-visual{
    position:relative; aspect-ratio:3/4;
    background:var(--ar-light); border:1px solid var(--ar-border);
    overflow:hidden;
}
/* architectural plan silhouette */
.ar-plan{
    position:absolute; inset:20px;
    border:1.5px solid rgba(30,78,216,.35);
    background:rgba(255,255,255,.6);
}
.ar-plan::before{
    content:''; position:absolute; inset:16px;
    border:1px solid rgba(30,78,216,.2);
    background:
        linear-gradient(90deg,rgba(30,78,216,.12) 1px,transparent 1px),
        linear-gradient(rgba(30,78,216,.12) 1px,transparent 1px);
    background-size:20px 20px;
}
/* room partition lines */
.ar-room-h{ position:absolute; left:0; right:0; height:1.5px; background:rgba(30,78,216,.5); }
.ar-room-v{ position:absolute; top:0; bottom:0; width:1.5px; background:rgba(30,78,216,.5); }
/* door arc */
.ar-door-arc{
    position:absolute; width:28px; height:28px;
    border:1px solid rgba(30,78,216,.5);
    border-radius:0 100% 0 0;
}
.ar-about-label{
    position:absolute; bottom:-1px; left:-1px; right:-1px;
    background:var(--ar-cobalt); color:var(--ar-white);
    font-family:var(--ar-font-b); font-size:.7rem; letter-spacing:.14em; text-transform:uppercase;
    padding:10px 16px;
}
.ar-values{ margin-top:40px; display:flex; flex-direction:column; gap:20px; }
.ar-value{ display:flex; gap:20px; align-items:flex-start; }
.ar-value-num{ font-family:var(--ar-font-h); font-size:2.2rem; font-weight:300; color:var(--ar-cobalt); flex-shrink:0; line-height:1; }
.ar-value-title{ font-family:var(--ar-font-h); font-size:1.1rem; color:var(--ar-dark); margin-bottom:4px; }
.ar-value-desc{ font-size:.88rem; color:var(--ar-mid); line-height:1.7; }

/* ══════════════════════════════════════════
   SERVICES
══════════════════════════════════════════ */
.ar-srv-grid{
    display:grid; grid-template-columns:repeat(3,1fr);
    border:1px solid var(--ar-border);
}
.ar-srv-card{
    padding:40px 32px;
    border-right:1px solid var(--ar-border);
    border-bottom:1px solid var(--ar-border);
    transition:background .25s;
    position:relative;
}
.ar-srv-card:nth-child(3n){ border-right:none; }
.ar-srv-card:nth-child(4),.ar-srv-card:nth-child(5),.ar-srv-card:nth-child(6){ border-bottom:none; }
.ar-srv-card:hover{ background:var(--ar-chalk); }
.ar-srv-card::before{
    content:''; position:absolute; bottom:0; left:0; width:0; height:2px;
    background:var(--ar-cobalt); transition:width .4s ease;
}
.ar-srv-card:hover::before{ width:100%; }
.ar-srv-icon{ font-size:1.8rem; display:block; margin-bottom:20px; }
.ar-srv-name{ font-family:var(--ar-font-h); font-size:1.3rem; color:var(--ar-dark); margin-bottom:12px; }
.ar-srv-desc{ font-size:.88rem; color:var(--ar-mid); line-height:1.75; }

/* ══════════════════════════════════════════
   PORTFOLIO
══════════════════════════════════════════ */
.ar-port-grid{
    display:grid; grid-template-columns:repeat(3,1fr); gap:2px;
    background:var(--ar-border);
}
.ar-port-card{
    position:relative; aspect-ratio:4/3; overflow:hidden;
    background:var(--ar-light);
}
/* CSS architectural room scene per card */
.ar-pc-scene{
    position:absolute; inset:0;
    background:var(--ar-sc-bg);
}
.ar-pc-wall{
    position:absolute; top:0; left:0; right:0; bottom:35%;
    background:var(--ar-sc-wall);
}
.ar-pc-floor{
    position:absolute; bottom:0; left:0; right:0; height:35%;
    background:
        linear-gradient(90deg,rgba(0,0,0,.05) 50%,transparent 50%),
        var(--ar-sc-wall);
    background-size:40px 100%;
}
.ar-pc-win{
    position:absolute; top:15%; left:50%; transform:translateX(-50%);
    width:30%; height:40%;
    border:2px solid rgba(0,0,0,.15);
    background:linear-gradient(180deg,rgba(200,220,255,.4),rgba(200,220,255,.1));
}
.ar-pc-win::before{
    content:''; position:absolute; top:50%; left:0; right:0; height:1px;
    background:rgba(0,0,0,.15);
}
.ar-pc-win::after{
    content:''; position:absolute; top:0; bottom:0; left:50%; width:1px;
    background:rgba(0,0,0,.15);
}
.ar-pc-furniture{
    position:absolute; bottom:35%; left:20%;
    width:30%; height:22%;
    background:var(--ar-sc-accent); opacity:.7;
    clip-path:polygon(0 20%,100% 0,100% 80%,0 100%);
}
.ar-port-overlay{
    position:absolute; inset:0;
    background:rgba(14,12,10,.82);
    display:flex; flex-direction:column; justify-content:flex-end;
    padding:24px; opacity:0; transition:opacity .35s;
}
.ar-port-card:hover .ar-port-overlay{ opacity:1; }
.ar-port-name{ font-family:var(--ar-font-h); font-size:1.3rem; font-weight:400; color:var(--ar-white); margin-bottom:6px; }
.ar-port-meta{ font-size:.75rem; letter-spacing:.12em; text-transform:uppercase; color:rgba(255,255,255,.55); }
.ar-port-type{
    display:inline-block; background:var(--ar-cobalt); color:var(--ar-white);
    font-size:.68rem; letter-spacing:.14em; text-transform:uppercase;
    padding:3px 10px; margin-bottom:10px;
}

/* ══════════════════════════════════════════
   PROCESS
══════════════════════════════════════════ */
.ar-process-grid{
    display:grid; grid-template-columns:repeat(4,1fr); gap:0;
    border-top:1px solid var(--ar-border);
}
.ar-process-step{
    padding:48px 32px;
    border-right:1px solid var(--ar-border);
    position:relative;
}
.ar-process-step:last-child{ border-right:none; }
.ar-process-num{
    font-family:var(--ar-font-h); font-size:5rem; font-weight:300;
    color:var(--ar-light); line-height:1; margin-bottom:16px;
}
.ar-process-title{ font-family:var(--ar-font-h); font-size:1.2rem; color:var(--ar-dark); margin-bottom:12px; }
.ar-process-desc{ font-size:.85rem; color:var(--ar-mid); line-height:1.75; }
/* cobalt marker */
.ar-process-step::before{
    content:''; position:absolute; top:0; left:32px; width:2px; height:3px;
    background:var(--ar-cobalt);
    transition:height .4s ease;
}
.ar-process-step:hover::before{ height:40px; }

/* ══════════════════════════════════════════
   TEAM
══════════════════════════════════════════ */
.ar-team-grid{ display:grid; grid-template-columns:repeat(4,1fr); gap:24px; }
.ar-team-card{
    border:1px solid var(--ar-border); overflow:hidden;
    transition:box-shadow .25s;
}
.ar-team-card:hover{ box-shadow:0 12px 40px rgba(0,0,0,.12); }
/* CSS architectural figure */
.ar-team-fig{
    height:220px; background:var(--ar-chalk);
    display:flex; align-items:flex-end; justify-content:center; overflow:hidden;
    position:relative;
}
.ar-team-fig-accent{
    position:absolute; top:0; left:0; right:0; height:3px;
    background:var(--ar-cobalt);
}
.ar-figure-ar{
    position:relative; width:80px; height:190px;
}
.ar-fa-head{
    width:32px; height:32px; border-radius:50%;
    background:#D4A878; margin:0 auto;
    position:absolute; top:10px; left:50%; transform:translateX(-50%);
}
.ar-fa-body{
    position:absolute; top:46px; left:50%; transform:translateX(-50%);
    width:40px; height:54px;
    background:#2C2C2C; /* dark suit jacket */
}
/* lapels */
.ar-fa-body::before{
    content:''; position:absolute; top:0; left:4px;
    width:14px; height:20px;
    background:#E8E4DC; /* white shirt */
    clip-path:polygon(0 0,100% 0,0 100%);
}
.ar-fa-body::after{
    content:''; position:absolute; top:0; right:4px;
    width:14px; height:20px;
    background:#E8E4DC;
    clip-path:polygon(0 0,100% 0,100% 100%);
}
.ar-fa-arm-l,.ar-fa-arm-r{
    position:absolute; width:10px; height:48px;
    background:#2C2C2C; border-radius:5px;
}
.ar-fa-arm-l{ top:46px; left:calc(50% - 30px); transform:rotate(6deg); transform-origin:top center; }
.ar-fa-arm-r{ top:46px; right:calc(50% - 30px); transform:rotate(-6deg); transform-origin:top center; }
/* tube roll held in right arm */
.ar-fa-roll{
    position:absolute; top:78px; right:calc(50% - 44px);
    width:24px; height:8px;
    background:#D4C8A8; border-radius:4px;
    transform:rotate(-6deg);
}
.ar-fa-leg-l,.ar-fa-leg-r{
    position:absolute; width:14px; height:52px;
    background:#1A1A2E; border-radius:3px 3px 6px 6px;
}
.ar-fa-leg-l{ top:98px; left:calc(50% - 17px); }
.ar-fa-leg-r{ top:98px; right:calc(50% - 17px); }
.ar-fa-shoe-l,.ar-fa-shoe-r{
    position:absolute; width:18px; height:8px;
    background:#1A1A1A; border-radius:0 4px 4px 0;
}
.ar-fa-shoe-l{ top:146px; left:calc(50% - 20px); }
.ar-fa-shoe-r{ top:146px; right:calc(50% - 20px); transform:scaleX(-1); }
.ar-team-info{ padding:20px; border-top:1px solid var(--ar-border); }
.ar-team-name{ font-family:var(--ar-font-h); font-size:1.15rem; color:var(--ar-dark); margin-bottom:4px; }
.ar-team-role{ font-size:.72rem; letter-spacing:.14em; text-transform:uppercase; color:var(--ar-cobalt); font-weight:600; margin-bottom:6px; }
.ar-team-qual{ font-size:.8rem; color:var(--ar-mid); }

/* ══════════════════════════════════════════
   AWARDS
══════════════════════════════════════════ */
.ar-awards-inner{
    display:grid; grid-template-columns:repeat(3,1fr); gap:1px;
    background:rgba(255,255,255,.1);
}
.ar-award-item{
    padding:28px 32px;
    border-left:3px solid transparent;
    background:var(--ar-dark);
    color:rgba(255,255,255,.7);
    font-family:var(--ar-font-h); font-size:1.05rem;
    transition:border-color .25s, color .25s;
}
.ar-award-item:hover{ border-left-color:var(--ar-cobalt); color:var(--ar-white); }
.ar-award-item::before{ content:'✦ '; color:var(--ar-cobalt); }

/* ══════════════════════════════════════════
   TESTIMONIALS
══════════════════════════════════════════ */
.ar-testi-grid{ display:grid; grid-template-columns:repeat(3,1fr); gap:24px; }
.ar-testi-card{
    background:var(--ar-white); border:1px solid var(--ar-border); padding:36px;
    position:relative;
}
.ar-testi-card::before{
    content:'\201C'; position:absolute; top:20px; right:24px;
    font-family:var(--ar-font-h); font-size:5rem; font-weight:300;
    color:var(--ar-light); line-height:1;
}
.ar-testi-text{ font-family:var(--ar-font-h); font-size:1.05rem; font-style:italic; color:var(--ar-graphite); line-height:1.8; margin-bottom:24px; }
.ar-testi-divider{ width:32px; height:1.5px; background:var(--ar-cobalt); margin-bottom:16px; }
.ar-testi-name{ font-family:var(--ar-font-h); font-size:1rem; color:var(--ar-dark); margin-bottom:4px; }
.ar-testi-role{ font-size:.72rem; letter-spacing:.14em; text-transform:uppercase; color:var(--ar-mid); }

/* ══════════════════════════════════════════
   FAQ
══════════════════════════════════════════ */
.ar-faq-list{ max-width:760px; margin:0 auto; display:flex; flex-direction:column; }
.ar-faq-item{ border-bottom:1px solid var(--ar-border); }
.ar-faq-item:first-child{ border-top:1px solid var(--ar-border); }
.ar-faq-btn{
    width:100%; text-align:left; padding:22px 0;
    font-family:var(--ar-font-h); font-size:1.1rem; color:var(--ar-dark);
    background:none; border:none; cursor:pointer;
    display:flex; justify-content:space-between; align-items:center; gap:16px;
}
.ar-faq-icon{ font-size:1.2rem; color:var(--ar-cobalt); flex-shrink:0; transition:transform .3s; }
.ar-faq-item.open .ar-faq-icon{ transform:rotate(45deg); }
.ar-faq-body{ max-height:0; overflow:hidden; transition:max-height .4s ease; }
.ar-faq-body-inner{ padding:0 0 24px; font-size:.92rem; color:var(--ar-mid); line-height:1.8; }

/* ══════════════════════════════════════════
   CONTACT / ENQUIRY FORM
══════════════════════════════════════════ */
.ar-contact-grid{ display:grid; grid-template-columns:1fr 1fr; gap:80px; align-items:start; }
.ar-contact-details{ display:flex; flex-direction:column; gap:28px; margin-top:32px; }
.ar-contact-item{ display:flex; gap:16px; }
.ar-contact-icon-box{
    width:44px; height:44px; border:1px solid var(--ar-border);
    display:flex; align-items:center; justify-content:center;
    font-size:1.1rem; flex-shrink:0;
}
.ar-contact-label{ font-size:.7rem; letter-spacing:.16em; text-transform:uppercase; color:var(--ar-mid); margin-bottom:4px; }
.ar-contact-val{ font-size:.9rem; color:var(--ar-graphite); }

.ar-form{ display:flex; flex-direction:column; gap:20px; }
.ar-form-row{ display:grid; grid-template-columns:1fr 1fr; gap:20px; }
.ar-field label{
    display:block; font-size:.7rem; font-weight:600; letter-spacing:.16em;
    color:var(--ar-mid); text-transform:uppercase; margin-bottom:8px;
}
.ar-field input, .ar-field select, .ar-field textarea{
    width:100%; padding:13px 16px;
    background:var(--ar-white); border:1px solid var(--ar-border);
    color:var(--ar-graphite); font-family:var(--ar-font-b); font-size:.92rem;
    transition:border-color .25s;
}
.ar-field input:focus, .ar-field select:focus, .ar-field textarea:focus{
    outline:none; border-color:var(--ar-cobalt);
}
.ar-field select{
    appearance:none;
    background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath d='M1 1l4 4 4-4' stroke='%231E4ED8' fill='none' stroke-width='1.5'/%3E%3C/svg%3E");
    background-repeat:no-repeat; background-position:calc(100% - 14px) 50%;
    padding-right:36px;
}
.ar-field textarea{ resize:vertical; min-height:120px; }
.ar-form-note{ font-size:.78rem; color:var(--ar-mid); }
.ar-form-note a{ color:var(--ar-cobalt); }

/* ══════════════════════════════════════════
   FOOTER CTA
══════════════════════════════════════════ */
.ar-footer-cta{
    background:var(--ar-dark); padding:80px 0; text-align:center;
    border-top:3px solid var(--ar-cobalt);
}
.ar-footer-cta-title{ font-family:var(--ar-font-h); font-size:clamp(2rem,4vw,3.2rem); font-weight:300; font-style:italic; color:var(--ar-white); margin-bottom:16px; }
.ar-footer-cta-sub{ font-size:.9rem; color:rgba(255,255,255,.5); margin-bottom:40px; letter-spacing:.06em; }

/* ══════════════════════════════════════════
   KEYFRAMES
══════════════════════════════════════════ */
@keyframes ar-shape-drift{
    0%  { transform:rotate(var(--sr)) translateY(0); }
    100%{ transform:rotate(calc(var(--sr) + 12deg)) translateY(-18px); }
}
@keyframes ar-float{
    0%,100%{ transform:translateY(0); }
    50%    { transform:translateY(-5px); }
}

/* ══════════════════════════════════════════
   RESPONSIVE
══════════════════════════════════════════ */
@media(max-width:1024px){
    .ar-hero-inner,.ar-about-grid,.ar-contact-grid{ grid-template-columns:1fr; gap:48px; }
    .ar-stats-grid{ grid-template-columns:repeat(2,1fr); }
    .ar-stats-grid .ar-stat-cell:nth-child(2){ border-right:none; }
    .ar-stats-grid .ar-stat-cell:nth-child(3){ border-right:1px solid rgba(255,255,255,.1); }
    .ar-srv-grid{ grid-template-columns:repeat(2,1fr); }
    .ar-srv-card:nth-child(2n){ border-right:none; }
    .ar-srv-card:nth-child(5),.ar-srv-card:nth-child(6){ border-bottom:none; }
    .ar-port-grid{ grid-template-columns:repeat(2,1fr); }
    .ar-process-grid{ grid-template-columns:repeat(2,1fr); }
    .ar-process-step:nth-child(2){ border-right:none; }
    .ar-team-grid{ grid-template-columns:repeat(2,1fr); }
    .ar-testi-grid{ grid-template-columns:1fr; }
    .ar-awards-inner{ grid-template-columns:repeat(2,1fr); }
}
@media(max-width:640px){
    .ar-srv-grid,.ar-port-grid,.ar-team-grid,.ar-awards-inner{ grid-template-columns:1fr; }
    .ar-form-row{ grid-template-columns:1fr; }
    .ar-process-grid{ grid-template-columns:1fr; }
    .ar-process-step{ border-right:none; border-bottom:1px solid var(--ar-border); }
    .ar-stats-grid{ grid-template-columns:1fr; }
    .ar-stat-cell{ border-right:none; border-bottom:1px solid rgba(255,255,255,.1); }
}
</style>

<div class="ar-wrap">

<!-- ══════════════════════════════════════
     HERO
══════════════════════════════════════ -->
<section class="ar-hero">

    <!-- blueprint grid -->
    <div class="ar-blueprint"></div>

    <!-- studio furniture -->
    <div class="ar-table"></div>
    <div class="ar-rule"></div>
    <div class="ar-setsquare"></div>
    <div class="ar-pencil"></div>

    <!-- elevation drawing -->
    <div class="ar-elevation">
        <div class="ar-el-roof"></div>
        <div class="ar-el-win" style="top:18%;left:12%;width:18%;height:24%;"></div>
        <div class="ar-el-win" style="top:18%;left:38%;width:18%;height:24%;"></div>
        <div class="ar-el-win" style="top:18%;left:64%;width:18%;height:24%;"></div>
        <div class="ar-el-win" style="top:55%;left:38%;width:22%;height:30%;"></div>
    </div>

    <!-- 3-D wireframe model -->
    <div class="ar-model">
        <div class="ar-model-top"></div>
        <div class="ar-model-side"></div>
    </div>

    <!-- floating geometric shapes -->
    <?php foreach($ar_shapes as $sh):
        $type_cls = ['sq','sq','circ','tri','cross'][$sh['type'] % 5];
    ?>
    <div class="ar-shape <?php echo $type_cls; ?>"
         style="
            left:<?php echo $sh['left']; ?>%;
            top:<?php echo $sh['top']; ?>%;
            width:<?php echo $sh['size']; ?>px;
            height:<?php echo $sh['size']; ?>px;
            --ss:<?php echo $sh['size']; ?>px;
            --sr:<?php echo $sh['rot']; ?>deg;
            --sd:<?php echo $sh['dur']; ?>ms;
            --sde:<?php echo $sh['delay']; ?>ms;
         ">
    </div>
    <?php endforeach; ?>

    <!-- hero content -->
    <div class="ar-hero-inner">
        <div>
            <div class="ar-hero-kicker">
                <div class="ar-hero-kicker-line"></div>
                <span class="ar-overline" style="margin:0;">Architecture &amp; Design Studio · London</span>
            </div>
            <h1 class="ar-h1">
                Architecture<br>
                that <em class="ar-accent">endures.</em>
            </h1>
            <p class="ar-lead" style="margin-top:24px;">
                Ashby Kern Architects creates considered, lasting buildings rooted in
                place, purpose and the deep pleasure of well-made things.
                ARB registered · RIBA Chartered.
            </p>
            <div class="ar-hero-actions">
                <a href="#enquiry" class="ar-btn">Begin a Conversation</a>
                <a href="#portfolio" class="ar-btn ar-btn-outline">View Portfolio</a>
            </div>
            <div class="ar-hero-meta">
                <div class="ar-hero-meta-item">
                    <div class="ar-hero-meta-val">63</div>
                    <div class="ar-hero-meta-label">Projects Completed</div>
                </div>
                <div class="ar-hero-meta-item">
                    <div class="ar-hero-meta-val">14</div>
                    <div class="ar-hero-meta-label">International Awards</div>
                </div>
                <div class="ar-hero-meta-item">
                    <div class="ar-hero-meta-val">4.9★</div>
                    <div class="ar-hero-meta-label">Client Rating</div>
                </div>
            </div>
        </div>

        <!-- scene card -->
        <div>
            <div class="ar-scene-card">
                <div class="ar-sc-inner">
                    <div class="ar-sc-table"></div>
                    <div class="ar-sc-elev"></div>
                    <div class="ar-sc-model">
                        <div style="position:absolute;top:-15px;left:-15px;width:60px;height:60px;border:1.5px solid rgba(30,78,216,.3);transform:translateZ(-30px);"></div>
                    </div>
                </div>
                <div class="ar-float-badge">Ashby Kern Architects · Est. 2003</div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     STATS BAR
══════════════════════════════════════ -->
<div class="ar-stats-bar">
    <div class="ar-container">
        <div class="ar-stats-grid">
            <?php foreach($ar_stats as $st):
                $isf = floor($st['val']) !== (float)$st['val']; ?>
            <div class="ar-stat-cell">
                <span class="ar-stat-val"
                      data-target="<?php echo $st['val']; ?>"
                      data-suffix="<?php echo esc_attr($st['suffix']); ?>"
                      data-float="<?php echo $isf?'1':'0'; ?>">
                    0<?php echo esc_html($st['suffix']); ?>
                </span>
                <div class="ar-stat-label"><?php echo esc_html($st['label']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ══════════════════════════════════════
     ABOUT / PHILOSOPHY
══════════════════════════════════════ -->
<section class="ar-section">
    <div class="ar-container">
        <div class="ar-about-grid">
            <!-- plan graphic -->
            <div class="ar-about-visual">
                <div class="ar-plan">
                    <!-- horizontal partition -->
                    <div class="ar-room-h" style="top:42%;"></div>
                    <!-- vertical partition -->
                    <div class="ar-room-v" style="left:55%; top:0; bottom:58%;"></div>
                    <!-- door arcs -->
                    <div class="ar-door-arc" style="top:40%;left:16%;"></div>
                    <div class="ar-door-arc" style="top:41%;left:57%;transform:scaleX(-1);"></div>
                </div>
                <div class="ar-about-label">Site Plan — Meridian House 2024</div>
            </div>

            <div>
                <span class="ar-overline">Our Philosophy</span>
                <h2 class="ar-h2">
                    Buildings that belong<br>
                    to their <em class="ar-accent">place.</em>
                </h2>
                <div class="ar-divider"></div>
                <p class="ar-lead" style="max-width:100%;">
                    Founded in 2003, Ashby Kern Architects is a London practice with an
                    international reputation for architecture that is quietly rigorous,
                    deeply contextual and beautifully crafted. We believe great buildings
                    are collaborative — formed from an honest conversation between client,
                    site and architect.
                </p>
                <div class="ar-values">
                    <div class="ar-value">
                        <div class="ar-value-num">01</div>
                        <div>
                            <div class="ar-value-title">Context Over Formula</div>
                            <p class="ar-value-desc">Every site has a story. We read it carefully before we draw a single line.</p>
                        </div>
                    </div>
                    <div class="ar-value">
                        <div class="ar-value-num">02</div>
                        <div>
                            <div class="ar-value-title">Sustainability by Design</div>
                            <p class="ar-value-desc">Passive strategies, biophilic planning and low-carbon materials from concept stage, not as an afterthought.</p>
                        </div>
                    </div>
                    <div class="ar-value">
                        <div class="ar-value-num">03</div>
                        <div>
                            <div class="ar-value-title">Built to Last</div>
                            <p class="ar-value-desc">We design for a hundred years. Enduring buildings justify the effort, the craft and the patience they require.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     SERVICES
══════════════════════════════════════ -->
<section class="ar-section ar-section-alt">
    <div class="ar-container">
        <div class="ar-section-header center">
            <span class="ar-overline">Services</span>
            <h2 class="ar-h2">What We <em class="ar-accent">Do</em></h2>
            <p class="ar-lead">From a single-family home to a city block — we bring the same care to every scale.</p>
        </div>
        <div class="ar-srv-grid">
            <?php foreach($ar_services as $s): ?>
            <div class="ar-srv-card">
                <span class="ar-srv-icon"><?php echo $s['icon']; ?></span>
                <div class="ar-srv-name"><?php echo esc_html($s['name']); ?></div>
                <p class="ar-srv-desc"><?php echo esc_html($s['desc']); ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     PORTFOLIO
══════════════════════════════════════ -->
<section class="ar-section" id="portfolio">
    <div class="ar-container">
        <div class="ar-section-header">
            <span class="ar-overline">Selected Work</span>
            <h2 class="ar-h2">Recent <em class="ar-accent">Projects</em></h2>
        </div>
    </div>
    <div style="max-width:1200px;margin:0 auto;padding:0 40px;">
        <div class="ar-port-grid">
            <?php foreach($ar_projects as $i=>$proj):
                $sc = $ar_proj_scenes[$i % count($ar_proj_scenes)];
            ?>
            <div class="ar-port-card"
                 style="--ar-sc-bg:<?php echo $sc['bg']; ?>;--ar-sc-wall:<?php echo $sc['wall']; ?>;--ar-sc-accent:<?php echo $sc['accent']; ?>;">
                <div class="ar-pc-scene">
                    <div class="ar-pc-wall"></div>
                    <div class="ar-pc-floor"></div>
                    <div class="ar-pc-win"></div>
                    <div class="ar-pc-furniture"></div>
                </div>
                <div class="ar-port-overlay">
                    <div class="ar-port-type"><?php echo esc_html($proj['type']); ?></div>
                    <div class="ar-port-name"><?php echo esc_html($proj['name']); ?></div>
                    <div class="ar-port-meta"><?php echo esc_html($proj['loc']); ?> · <?php echo esc_html($proj['year']); ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     PROCESS
══════════════════════════════════════ -->
<section class="ar-section ar-section-alt">
    <div class="ar-container">
        <div class="ar-section-header center">
            <span class="ar-overline">How We Work</span>
            <h2 class="ar-h2">The Design <em class="ar-accent">Process</em></h2>
        </div>
        <div class="ar-process-grid">
            <?php foreach($ar_process as $p): ?>
            <div class="ar-process-step">
                <div class="ar-process-num"><?php echo esc_html($p['n']); ?></div>
                <div class="ar-process-title"><?php echo esc_html($p['t']); ?></div>
                <p class="ar-process-desc"><?php echo esc_html($p['d']); ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     TEAM
══════════════════════════════════════ -->
<section class="ar-section">
    <div class="ar-container">
        <div class="ar-section-header center">
            <span class="ar-overline">The Studio</span>
            <h2 class="ar-h2">Our <em class="ar-accent">Team</em></h2>
        </div>
        <div class="ar-team-grid">
            <?php foreach($ar_team as $m): ?>
            <div class="ar-team-card">
                <div class="ar-team-fig">
                    <div class="ar-team-fig-accent"></div>
                    <div class="ar-figure-ar">
                        <div class="ar-fa-head"></div>
                        <div class="ar-fa-body"></div>
                        <div class="ar-fa-arm-l"></div>
                        <div class="ar-fa-arm-r"></div>
                        <div class="ar-fa-roll"></div>
                        <div class="ar-fa-leg-l"></div>
                        <div class="ar-fa-leg-r"></div>
                        <div class="ar-fa-shoe-l"></div>
                        <div class="ar-fa-shoe-r"></div>
                    </div>
                </div>
                <div class="ar-team-info">
                    <div class="ar-team-name"><?php echo esc_html($m['name']); ?></div>
                    <div class="ar-team-role"><?php echo esc_html($m['role']); ?></div>
                    <div class="ar-team-qual"><?php echo esc_html($m['qual']); ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     AWARDS
══════════════════════════════════════ -->
<section class="ar-section ar-section-dark">
    <div class="ar-container">
        <div class="ar-section-header" style="margin-bottom:48px;">
            <span class="ar-overline" style="color:var(--ar-cobalt-l);">Recognition</span>
            <h2 class="ar-h2" style="color:var(--ar-white);">Awards &amp; <em class="ar-accent">Accolades</em></h2>
        </div>
        <div class="ar-awards-inner">
            <?php foreach($ar_awards as $aw): ?>
            <div class="ar-award-item"><?php echo esc_html($aw); ?></div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     TESTIMONIALS
══════════════════════════════════════ -->
<section class="ar-section">
    <div class="ar-container">
        <div class="ar-section-header center">
            <span class="ar-overline">Client Words</span>
            <h2 class="ar-h2">What Clients <em class="ar-accent">Say</em></h2>
        </div>
        <div class="ar-testi-grid">
            <?php foreach($ar_testimonials as $t): ?>
            <div class="ar-testi-card">
                <p class="ar-testi-text"><?php echo esc_html($t['text']); ?></p>
                <div class="ar-testi-divider"></div>
                <div class="ar-testi-name"><?php echo esc_html($t['name']); ?></div>
                <div class="ar-testi-role"><?php echo esc_html($t['role']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     FAQ
══════════════════════════════════════ -->
<section class="ar-section ar-section-alt">
    <div class="ar-container">
        <div class="ar-section-header center">
            <span class="ar-overline">FAQ</span>
            <h2 class="ar-h2">Common <em class="ar-accent">Questions</em></h2>
        </div>
        <div class="ar-faq-list">
            <?php foreach($ar_faqs as $i=>$faq): ?>
            <div class="ar-faq-item" id="ar-faq-<?php echo $i; ?>">
                <button class="ar-faq-btn"
                        aria-expanded="false"
                        aria-controls="ar-faq-body-<?php echo $i; ?>">
                    <?php echo esc_html($faq['q']); ?>
                    <span class="ar-faq-icon">+</span>
                </button>
                <div class="ar-faq-body" id="ar-faq-body-<?php echo $i; ?>" role="region">
                    <div class="ar-faq-body-inner"><?php echo esc_html($faq['a']); ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     ENQUIRY FORM
══════════════════════════════════════ -->
<section class="ar-section" id="enquiry">
    <div class="ar-container">
        <div class="ar-contact-grid">

            <div>
                <span class="ar-overline">Get in Touch</span>
                <h2 class="ar-h2" style="margin-bottom:16px;">
                    Start a <em class="ar-accent">Conversation</em>
                </h2>
                <div class="ar-divider"></div>
                <p class="ar-lead" style="max-width:100%;">
                    We welcome enquiries at any stage — from early feasibility to a
                    fully-formed brief. Initial consultations are complimentary and
                    without obligation.
                </p>
                <div class="ar-contact-details">
                    <div class="ar-contact-item">
                        <div class="ar-contact-icon-box">📍</div>
                        <div>
                            <div class="ar-contact-label">Studio</div>
                            <div class="ar-contact-val">27 Floral Street, Covent Garden, London WC2E 9DP</div>
                        </div>
                    </div>
                    <div class="ar-contact-item">
                        <div class="ar-contact-icon-box">✉</div>
                        <div>
                            <div class="ar-contact-label">Email</div>
                            <div class="ar-contact-val">studio@ashbykern.co.uk</div>
                        </div>
                    </div>
                    <div class="ar-contact-item">
                        <div class="ar-contact-icon-box">📞</div>
                        <div>
                            <div class="ar-contact-label">Telephone</div>
                            <div class="ar-contact-val">+44 (0)20 7240 8800</div>
                        </div>
                    </div>
                    <div class="ar-contact-item">
                        <div class="ar-contact-icon-box">🏛</div>
                        <div>
                            <div class="ar-contact-label">Registration</div>
                            <div class="ar-contact-val">ARB Registered · RIBA Chartered Practice</div>
                        </div>
                    </div>
                </div>
            </div>

            <form class="ar-form"
                  method="post"
                  action="<?php echo esc_url(admin_url('admin-post.php')); ?>">

                <?php wp_nonce_field('tf_ar_enquiry','tf_ar_nonce'); ?>
                <input type="hidden" name="action" value="tf_ar_enquiry">

                <div class="ar-form-row">
                    <div class="ar-field">
                        <label for="ar-name">Full Name <span style="color:var(--ar-cobalt)">*</span></label>
                        <input type="text" id="ar-name" name="ar_name" required placeholder="Eleanor Ashby">
                    </div>
                    <div class="ar-field">
                        <label for="ar-org">Organisation / Company</label>
                        <input type="text" id="ar-org" name="ar_org" placeholder="Ashby Kern Architects">
                    </div>
                </div>

                <div class="ar-form-row">
                    <div class="ar-field">
                        <label for="ar-email">Email Address <span style="color:var(--ar-cobalt)">*</span></label>
                        <input type="email" id="ar-email" name="ar_email" required placeholder="hello@email.com">
                    </div>
                    <div class="ar-field">
                        <label for="ar-phone">Telephone</label>
                        <input type="tel" id="ar-phone" name="ar_phone" placeholder="+44 7700 900 000">
                    </div>
                </div>

                <div class="ar-field">
                    <label for="ar-type">Project Type <span style="color:var(--ar-cobalt)">*</span></label>
                    <select id="ar-type" name="ar_type" required>
                        <option value="" disabled selected>Select project type…</option>
                        <option>New Build Residential</option>
                        <option>Commercial / Mixed-Use</option>
                        <option>Refurbishment / Extension</option>
                        <option>Masterplanning</option>
                        <option>Interior Architecture</option>
                        <option>Feasibility Study</option>
                        <option>Other</option>
                    </select>
                </div>

                <div class="ar-form-row">
                    <div class="ar-field">
                        <label for="ar-location">Project Location</label>
                        <input type="text" id="ar-location" name="ar_location" placeholder="London, UK">
                    </div>
                    <div class="ar-field">
                        <label for="ar-budget">Approximate Budget</label>
                        <select id="ar-budget" name="ar_budget">
                            <option value="" disabled selected>Select range…</option>
                            <option>Under £250k</option>
                            <option>£250k – £500k</option>
                            <option>£500k – £1m</option>
                            <option>£1m – £3m</option>
                            <option>£3m – £10m</option>
                            <option>£10m+</option>
                            <option>Not yet determined</option>
                        </select>
                    </div>
                </div>

                <div class="ar-field">
                    <label for="ar-message">Brief Project Description <span style="color:var(--ar-cobalt)">*</span></label>
                    <textarea id="ar-message" name="ar_message" required
                              placeholder="Tell us about your project — the site, what you're hoping to achieve, and where you are in the process…"></textarea>
                </div>

                <p class="ar-form-note">
                    All enquiries are handled in strict confidence. By submitting this form
                    you agree to our <a href="#">Privacy Policy</a>.
                </p>

                <button type="submit" class="ar-btn" style="width:100%; justify-content:center;">
                    Send Enquiry →
                </button>
            </form>

        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     FOOTER CTA
══════════════════════════════════════ -->
<div class="ar-footer-cta">
    <div class="ar-container">
        <div class="ar-footer-cta-title">Ready to build something <em>remarkable?</em></div>
        <p class="ar-footer-cta-sub">
            ARB Registered · RIBA Chartered · London · Est. 2003
        </p>
        <div style="display:flex;gap:16px;justify-content:center;flex-wrap:wrap;">
            <a href="#enquiry" class="ar-btn" style="background:var(--ar-cobalt);">Begin a Conversation</a>
            <a href="#portfolio" class="ar-btn ar-btn-outline" style="border-color:rgba(255,255,255,.3);color:rgba(255,255,255,.7);">View Portfolio</a>
        </div>
    </div>
</div>

</div><!-- /.ar-wrap -->

<script>
(function(){
    /* ── Animated counters ─────────────────────── */
    const easeOut = t => 1 - Math.pow(1 - t, 3);
    const counterEls = document.querySelectorAll('.ar-stat-val[data-target]');
    const seen = new Set();
    const obs = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if(!entry.isIntersecting || seen.has(entry.target)) return;
            seen.add(entry.target);
            const el     = entry.target;
            const target = parseFloat(el.dataset.target);
            const suffix = el.dataset.suffix || '';
            const isFloat= el.dataset.float === '1';
            if(isNaN(target)) return;
            const dur = 1800, start = performance.now();
            const tick = now => {
                const t = Math.min((now - start) / dur, 1);
                const v = easeOut(t) * target;
                el.textContent = (isFloat ? v.toFixed(1) : Math.round(v)) + suffix;
                if(t < 1) requestAnimationFrame(tick);
            };
            requestAnimationFrame(tick);
        });
    }, { threshold: 0.4 });
    counterEls.forEach(el => obs.observe(el));

    /* ── FAQ accordion ─────────────────────────── */
    document.querySelectorAll('.ar-faq-btn').forEach(btn => {
        btn.addEventListener('click', function(){
            const item = this.closest('.ar-faq-item');
            const body = item.querySelector('.ar-faq-body');
            const open = item.classList.contains('open');
            document.querySelectorAll('.ar-faq-item.open').forEach(i => {
                i.classList.remove('open');
                i.querySelector('.ar-faq-body').style.maxHeight = '0';
                i.querySelector('.ar-faq-btn').setAttribute('aria-expanded','false');
            });
            if(!open){
                item.classList.add('open');
                body.style.maxHeight = body.scrollHeight + 'px';
                this.setAttribute('aria-expanded','true');
            }
        });
    });
})();
</script>

<?php get_footer(); ?>
