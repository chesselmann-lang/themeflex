<?php
/**
 * Template Name: Architecture Studio Homepage
 *
 * Premium architecture & design studio landing page.
 * Dark concrete aesthetic · CSS blueprint hero · portfolio grid ·
 * services · awards · team · commission form.
 *
 * @package ThemeFlex
 * @since   2.9.0
 */

get_header();
?>

<style>
/* ============================================================
   ARCHITECTURE PAGE — DESIGN TOKENS
   ============================================================ */
.tf-arch-page {
  --arch-bg:        #0d0d0d;
  --arch-surface:   #141414;
  --arch-card:      #1a1a1a;
  --arch-border:    rgba(255,255,255,.07);
  --arch-accent:    #c8a87a;       /* warm copper / sand */
  --arch-accent2:   #8fa99e;       /* sage / slate green */
  --arch-accent3:   #e8e8e8;       /* light concrete */
  --arch-text:      #e8e5e0;
  --arch-muted:     #7a7671;
  --arch-hero-h:    clamp(560px, 88vh, 860px);
}

.tf-arch-page {
  background: var(--arch-bg);
  color: var(--arch-text);
  font-family: var(--tf-font-body, 'Inter','Helvetica Neue',sans-serif);
  line-height: 1.6;
}

/* ============================================================
   HERO
   ============================================================ */
.arch-hero {
  position: relative;
  min-height: var(--arch-hero-h);
  display: grid;
  grid-template-columns: 1fr 1fr;
  overflow: hidden;
  background: var(--arch-bg);
}

/* — left copy — */
.arch-hero__copy {
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 6rem 4rem 6rem 6rem;
  position: relative;
  z-index: 2;
}
.arch-hero__eyebrow {
  display: flex;
  align-items: center;
  gap: .75rem;
  font-size: .7rem;
  letter-spacing: .2em;
  text-transform: uppercase;
  color: var(--arch-accent);
  margin-bottom: 1.75rem;
}
.arch-hero__eyebrow-line {
  width: 2.5rem;
  height: 1px;
  background: var(--arch-accent);
}
.arch-hero__h1 {
  font-family: var(--tf-font-heading, 'Cormorant Garamond','Georgia',serif);
  font-size: clamp(3.2rem, 6vw, 6rem);
  font-weight: 300;
  line-height: 1.05;
  letter-spacing: -.02em;
  color: var(--arch-text);
  margin: 0 0 1.5rem;
}
.arch-hero__h1 em {
  font-style: italic;
  color: var(--arch-accent);
}
.arch-hero__sub {
  font-size: 1.05rem;
  color: var(--arch-muted);
  max-width: 36ch;
  margin: 0 0 2.5rem;
  line-height: 1.7;
}
.arch-hero__ctas {
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
}
.arch-btn {
  display: inline-flex;
  align-items: center;
  gap: .5rem;
  padding: .85rem 1.8rem;
  border-radius: 0;
  font-size: .85rem;
  font-weight: 500;
  letter-spacing: .05em;
  text-transform: uppercase;
  text-decoration: none;
  transition: all .25s ease;
  cursor: pointer;
  border: none;
}
.arch-btn--primary {
  background: var(--arch-accent);
  color: #0d0d0d;
}
.arch-btn--primary:hover { background: #d4b88c; color: #0d0d0d; }
.arch-btn--outline {
  background: transparent;
  color: var(--arch-text);
  border: 1px solid rgba(255,255,255,.2);
}
.arch-btn--outline:hover { border-color: var(--arch-accent); color: var(--arch-accent); }

.arch-hero__stats {
  display: flex;
  gap: 2.5rem;
  margin-top: 3rem;
  padding-top: 2.5rem;
  border-top: 1px solid var(--arch-border);
}
.arch-hero__stat-val {
  font-family: var(--tf-font-heading, 'Cormorant Garamond','Georgia',serif);
  font-size: 2.4rem;
  font-weight: 300;
  color: var(--arch-accent);
  line-height: 1;
  margin-bottom: .25rem;
}
.arch-hero__stat-lbl {
  font-size: .7rem;
  letter-spacing: .12em;
  text-transform: uppercase;
  color: var(--arch-muted);
}

/* — right CSS blueprint hero — */
.arch-hero__visual {
  position: relative;
  background: #0a0a0a;
  overflow: hidden;
  border-left: 1px solid var(--arch-border);
}

/* Blueprint grid */
.arch-blueprint {
  position: absolute;
  inset: 0;
  overflow: hidden;
}
.arch-blueprint__grid {
  position: absolute;
  inset: 0;
  background-image:
    linear-gradient(rgba(200,168,122,.04) 1px, transparent 1px),
    linear-gradient(90deg, rgba(200,168,122,.04) 1px, transparent 1px);
  background-size: 40px 40px;
}
.arch-blueprint__grid-major {
  position: absolute;
  inset: 0;
  background-image:
    linear-gradient(rgba(200,168,122,.1) 1px, transparent 1px),
    linear-gradient(90deg, rgba(200,168,122,.1) 1px, transparent 1px);
  background-size: 200px 200px;
}

/* Main building wireframe */
.arch-building {
  position: absolute;
  bottom: 10%;
  left: 50%;
  transform: translateX(-50%);
  width: 380px;
  height: 420px;
}

/* Building silhouette via CSS shapes */
.arch-bld-base {
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 280px;
  height: 340px;
  border: 1.5px solid rgba(200,168,122,.6);
  background: rgba(200,168,122,.03);
}

/* Floors */
.arch-bld-floors {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
}
.arch-bld-floor {
  flex: 1;
  border-bottom: 1px solid rgba(200,168,122,.15);
  display: flex;
  align-items: center;
  padding: 0 16px;
  gap: 8px;
}
.arch-bld-floor:last-child { border-bottom: none; }

/* Windows in floors */
.arch-bld-win {
  width: 28px;
  height: 38px;
  border: 1px solid rgba(200,168,122,.3);
  background: rgba(200,168,122,.04);
  flex-shrink: 0;
  position: relative;
}
.arch-bld-win.lit {
  background: rgba(200,168,122,.12);
  border-color: rgba(200,168,122,.5);
  box-shadow: 0 0 12px rgba(200,168,122,.2);
  animation: arch-win-pulse 3s ease-in-out infinite var(--d, 0s);
}
@keyframes arch-win-pulse {
  0%,100% { opacity:1; }
  50% { opacity: .6; }
}

/* Tower section */
.arch-bld-tower {
  position: absolute;
  top: -100px;
  left: 50%;
  transform: translateX(-50%);
  width: 120px;
  height: 100px;
  border: 1.5px solid rgba(200,168,122,.5);
  border-bottom: none;
  background: rgba(200,168,122,.04);
}
.arch-bld-tower-floors {
  position: absolute;
  inset: 0;
}
.arch-bld-tower-floor {
  width: 100%;
  border-bottom: 1px solid rgba(200,168,122,.15);
  height: 33.33%;
}
.arch-bld-spire {
  position: absolute;
  top: -44px;
  left: 50%;
  transform: translateX(-50%);
  width: 0;
  height: 0;
  border-left: 16px solid transparent;
  border-right: 16px solid transparent;
  border-bottom: 44px solid rgba(200,168,122,.4);
}
.arch-bld-spire::after {
  content: '';
  position: absolute;
  top: -2px;
  left: 50%;
  transform: translateX(-50%);
  width: 2px;
  height: 18px;
  background: var(--arch-accent);
  top: -18px;
}

/* Dimension lines */
.arch-dim {
  position: absolute;
  display: flex;
  align-items: center;
  gap: 4px;
}
.arch-dim--h {
  bottom: 5%;
  left: 5%;
  right: 5%;
  height: 1px;
  background: rgba(200,168,122,.25);
}
.arch-dim--h::before,
.arch-dim--h::after {
  content: '';
  position: absolute;
  width: 1px;
  height: 12px;
  background: rgba(200,168,122,.4);
  top: -6px;
}
.arch-dim--h::before { left: 0; }
.arch-dim--h::after { right: 0; }

.arch-dim--v {
  right: 5%;
  top: 10%;
  bottom: 10%;
  width: 1px;
  background: rgba(200,168,122,.25);
}
.arch-dim--v::before,
.arch-dim--v::after {
  content: '';
  position: absolute;
  height: 1px;
  width: 12px;
  background: rgba(200,168,122,.4);
  right: -6px;
}
.arch-dim--v::before { top: 0; }
.arch-dim--v::after { bottom: 0; }

.arch-dim-label {
  position: absolute;
  font-size: .6rem;
  letter-spacing: .08em;
  color: rgba(200,168,122,.6);
  font-family: 'Courier New', monospace;
  background: #0a0a0a;
  padding: 2px 6px;
}
.arch-dim--h .arch-dim-label { left: 50%; transform: translateX(-50%); top: 6px; }
.arch-dim--v .arch-dim-label {
  writing-mode: vertical-lr;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
}

/* Annotation dots */
.arch-anno {
  position: absolute;
  display: flex;
  align-items: center;
  gap: 8px;
}
.arch-anno__dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--arch-accent);
  flex-shrink: 0;
  box-shadow: 0 0 0 3px rgba(200,168,122,.2);
}
.arch-anno__line {
  width: 40px;
  height: 1px;
  background: rgba(200,168,122,.4);
}
.arch-anno__text {
  font-size: .6rem;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: rgba(200,168,122,.7);
  font-family: 'Courier New', monospace;
  white-space: nowrap;
}

.arch-anno--1 { top: 22%; right: 12%; }
.arch-anno--2 { top: 38%; right: 8%; }
.arch-anno--3 { top: 55%; right: 14%; }

/* Cross-hair markers */
.arch-crosshair {
  position: absolute;
  width: 16px;
  height: 16px;
}
.arch-crosshair::before {
  content: '';
  position: absolute;
  left: 50%;
  top: 0;
  bottom: 0;
  width: 1px;
  background: rgba(200,168,122,.35);
}
.arch-crosshair::after {
  content: '';
  position: absolute;
  top: 50%;
  left: 0;
  right: 0;
  height: 1px;
  background: rgba(200,168,122,.35);
}
.arch-crosshair--1 { top: 15%; left: 18%; }
.arch-crosshair--2 { bottom: 18%; right: 22%; }

/* Compass rose */
.arch-compass {
  position: absolute;
  top: 1.5rem;
  right: 1.5rem;
  width: 48px;
  height: 48px;
  border: 1px solid rgba(200,168,122,.25);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}
.arch-compass::before {
  content: 'N';
  font-family: 'Courier New', monospace;
  font-size: .55rem;
  color: var(--arch-accent);
  letter-spacing: .05em;
}

/* Scale bar */
.arch-scale {
  position: absolute;
  bottom: 1.5rem;
  left: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.arch-scale__bar {
  display: flex;
  height: 4px;
}
.arch-scale__seg {
  width: 30px;
  height: 100%;
}
.arch-scale__seg:nth-child(odd) { background: rgba(200,168,122,.6); }
.arch-scale__seg:nth-child(even) { background: rgba(200,168,122,.2); }
.arch-scale__label {
  font-family: 'Courier New', monospace;
  font-size: .55rem;
  color: rgba(200,168,122,.5);
  letter-spacing: .08em;
}

/* Project badge top-left */
.arch-project-badge {
  position: absolute;
  top: 1.5rem;
  left: 1.5rem;
  background: rgba(200,168,122,.1);
  border: 1px solid rgba(200,168,122,.25);
  padding: .5rem .85rem;
  font-family: 'Courier New', monospace;
  font-size: .6rem;
  letter-spacing: .12em;
  color: rgba(200,168,122,.7);
  text-transform: uppercase;
}

/* ============================================================
   MARQUEE / RECOGNITION STRIP
   ============================================================ */
.arch-strip {
  border-top: 1px solid var(--arch-border);
  border-bottom: 1px solid var(--arch-border);
  padding: .9rem 0;
  overflow: hidden;
  background: var(--arch-surface);
}
.arch-strip__track {
  display: flex;
  gap: 0;
  animation: arch-strip-scroll 30s linear infinite;
  width: max-content;
}
@keyframes arch-strip-scroll {
  0%   { transform: translateX(0); }
  100% { transform: translateX(-50%); }
}
.arch-strip__track:hover { animation-play-state: paused; }
.arch-strip__item {
  display: flex;
  align-items: center;
  gap: .75rem;
  padding: 0 2.5rem;
  white-space: nowrap;
  font-size: .7rem;
  letter-spacing: .15em;
  text-transform: uppercase;
  color: var(--arch-muted);
}
.arch-strip__item svg { flex-shrink: 0; color: var(--arch-accent); }
.arch-strip__sep {
  width: 1px;
  height: 12px;
  background: var(--arch-border);
  align-self: center;
}

/* ============================================================
   SECTIONS — SHARED
   ============================================================ */
.arch-section {
  padding: 7rem 0;
}
.arch-container {
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 2.5rem;
}
.arch-label {
  display: inline-flex;
  align-items: center;
  gap: .6rem;
  font-size: .68rem;
  letter-spacing: .2em;
  text-transform: uppercase;
  color: var(--arch-accent);
  margin-bottom: 1.25rem;
}
.arch-label-line {
  display: inline-block;
  width: 2rem;
  height: 1px;
  background: var(--arch-accent);
}
.arch-h2 {
  font-family: var(--tf-font-heading, 'Cormorant Garamond','Georgia',serif);
  font-size: clamp(2.2rem, 4.5vw, 4rem);
  font-weight: 300;
  line-height: 1.1;
  letter-spacing: -.02em;
  color: var(--arch-text);
  margin: 0 0 1rem;
}
.arch-h2 em { font-style: italic; color: var(--arch-accent); }
.arch-lead {
  font-size: 1.05rem;
  color: var(--arch-muted);
  max-width: 52ch;
  line-height: 1.75;
}

/* ============================================================
   PORTFOLIO GRID
   ============================================================ */
.arch-portfolio {
  background: var(--arch-surface);
}
.arch-portfolio__header {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 2rem;
  margin-bottom: 4rem;
  flex-wrap: wrap;
}
.arch-portfolio__grid {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  grid-template-rows: auto auto;
  gap: 1px;
  background: var(--arch-border);
}

/* Large featured project */
.arch-project {
  background: var(--arch-card);
  position: relative;
  overflow: hidden;
  cursor: pointer;
  text-decoration: none;
  display: block;
}
.arch-project--large {
  grid-column: 1 / 3;
  grid-row: 1 / 2;
}
.arch-project--tall {
  grid-column: 3 / 4;
  grid-row: 1 / 3;
}

/* CSS art placeholder for each project */
.arch-project__thumb {
  aspect-ratio: 16/10;
  position: relative;
  overflow: hidden;
  background: #111;
}
.arch-project--tall .arch-project__thumb {
  aspect-ratio: unset;
  height: 100%;
  min-height: 500px;
}
.arch-project--large .arch-project__thumb {
  aspect-ratio: 16/8;
}

/* Animated gradient overlays as project visuals */
.arch-project__bg {
  position: absolute;
  inset: 0;
  transition: transform .8s cubic-bezier(.16,1,.3,1);
}
.arch-project:hover .arch-project__bg { transform: scale(1.04); }

/* Project 1 — glass tower */
.arch-project--1 .arch-project__bg {
  background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
}
.arch-proj1-lines {
  position: absolute;
  inset: 0;
  overflow: hidden;
}
.arch-proj1-lines::before {
  content: '';
  position: absolute;
  left: 38%;
  top: 0;
  width: 24%;
  height: 100%;
  background: repeating-linear-gradient(
    180deg,
    transparent,
    transparent 18px,
    rgba(100,160,255,.12) 18px,
    rgba(100,160,255,.12) 19px
  );
}
.arch-proj1-lines::after {
  content: '';
  position: absolute;
  left: 35%;
  top: 0;
  bottom: 0;
  width: 30%;
  border-left: 1px solid rgba(100,160,255,.3);
  border-right: 1px solid rgba(100,160,255,.3);
}

/* Project 2 — concrete pavilion */
.arch-project--2 .arch-project__bg {
  background: linear-gradient(160deg, #1c1810 0%, #2a2318 60%, #1c1810 100%);
}
.arch-proj2-form {
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 70%;
  height: 65%;
  background: rgba(200,168,122,.08);
  border: 1px solid rgba(200,168,122,.2);
}
.arch-proj2-form::before {
  content: '';
  position: absolute;
  top: -30%;
  left: -10%;
  right: -10%;
  height: 30%;
  background: rgba(200,168,122,.05);
  border: 1px solid rgba(200,168,122,.15);
  border-bottom: none;
}

/* Project 3 — cultural center (tall) */
.arch-project--3 .arch-project__bg {
  background: linear-gradient(200deg, #0d1f15 0%, #102418 50%, #0d1f15 100%);
}
.arch-proj3-wrap {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
}
.arch-proj3-form {
  width: 55%;
  height: 60%;
  border: 1.5px solid rgba(143,169,158,.35);
  background: rgba(143,169,158,.05);
  position: relative;
}
.arch-proj3-form::before {
  content: '';
  position: absolute;
  top: -15%;
  left: 10%;
  right: 10%;
  height: 15%;
  background: rgba(143,169,158,.08);
  border: 1px solid rgba(143,169,158,.25);
  border-bottom: none;
}
.arch-proj3-grid {
  position: absolute;
  inset: 0;
  background-image:
    linear-gradient(rgba(143,169,158,.1) 1px, transparent 1px),
    linear-gradient(90deg, rgba(143,169,158,.1) 1px, transparent 1px);
  background-size: 20% 25%;
}

/* Project 4 & 5 */
.arch-project--4 .arch-project__bg {
  background: linear-gradient(120deg, #1a0e1a 0%, #1f0f2a 100%);
}
.arch-proj4-arc {
  position: absolute;
  bottom: -20%;
  left: 50%;
  transform: translateX(-50%);
  width: 120%;
  height: 80%;
  border-radius: 50% 50% 0 0;
  border: 1.5px solid rgba(180,120,200,.25);
  background: rgba(180,120,200,.04);
}

.arch-project--5 .arch-project__bg {
  background: linear-gradient(155deg, #111a18 0%, #0e1a18 100%);
}
.arch-proj5-grid {
  position: absolute;
  inset: 0;
  background-image:
    linear-gradient(rgba(200,168,122,.06) 1px, transparent 1px),
    linear-gradient(90deg, rgba(200,168,122,.06) 1px, transparent 1px);
  background-size: 15% 20%;
}
.arch-proj5-mark {
  position: absolute;
  top: 30%;
  left: 20%;
  right: 20%;
  bottom: 20%;
  border: 1px solid rgba(200,168,122,.2);
}

/* Project overlay */
.arch-project__overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(to top, rgba(10,10,10,.95) 0%, rgba(10,10,10,.3) 50%, transparent 100%);
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  padding: 2rem 2.5rem;
  transition: background .4s;
}
.arch-project:hover .arch-project__overlay {
  background: linear-gradient(to top, rgba(10,10,10,.98) 0%, rgba(10,10,10,.5) 50%, rgba(10,10,10,.1) 100%);
}
.arch-project__cat {
  font-size: .65rem;
  letter-spacing: .18em;
  text-transform: uppercase;
  color: var(--arch-accent);
  margin-bottom: .5rem;
}
.arch-project__name {
  font-family: var(--tf-font-heading, 'Cormorant Garamond','Georgia',serif);
  font-size: 1.65rem;
  font-weight: 300;
  line-height: 1.2;
  color: var(--arch-text);
  margin: 0 0 .35rem;
  transition: color .3s;
}
.arch-project:hover .arch-project__name { color: #fff; }
.arch-project__meta {
  display: flex;
  gap: 1rem;
  font-size: .7rem;
  letter-spacing: .08em;
  color: var(--arch-muted);
}
.arch-project__arrow {
  position: absolute;
  top: 1.75rem;
  right: 1.75rem;
  width: 36px;
  height: 36px;
  border: 1px solid rgba(255,255,255,.15);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--arch-text);
  opacity: 0;
  transform: scale(.8) rotate(-45deg);
  transition: all .35s cubic-bezier(.34,1.56,.64,1);
}
.arch-project:hover .arch-project__arrow {
  opacity: 1;
  transform: scale(1) rotate(0deg);
}

/* ============================================================
   SERVICES
   ============================================================ */
.arch-services {
  background: var(--arch-bg);
}
.arch-services__grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 1px;
  background: var(--arch-border);
  margin-top: 4rem;
}
.arch-service-card {
  background: var(--arch-card);
  padding: 3rem;
  position: relative;
  overflow: hidden;
  transition: background .3s;
}
.arch-service-card:hover { background: #1f1f1f; }
.arch-service-card__num {
  font-family: var(--tf-font-heading, 'Cormorant Garamond','Georgia',serif);
  font-size: 4.5rem;
  font-weight: 300;
  color: rgba(200,168,122,.08);
  line-height: 1;
  margin-bottom: 1.5rem;
  display: block;
  letter-spacing: -.04em;
  transition: color .3s;
}
.arch-service-card:hover .arch-service-card__num { color: rgba(200,168,122,.14); }
.arch-service-card__icon {
  width: 44px;
  height: 44px;
  border: 1px solid rgba(200,168,122,.3);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--arch-accent);
  margin-bottom: 1.25rem;
}
.arch-service-card__title {
  font-family: var(--tf-font-heading, 'Cormorant Garamond','Georgia',serif);
  font-size: 1.5rem;
  font-weight: 400;
  color: var(--arch-text);
  margin: 0 0 .85rem;
}
.arch-service-card__desc {
  font-size: .9rem;
  color: var(--arch-muted);
  line-height: 1.75;
  margin: 0 0 1.5rem;
}
.arch-service-card__tags {
  display: flex;
  flex-wrap: wrap;
  gap: .5rem;
}
.arch-service-tag {
  font-size: .65rem;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: var(--arch-accent);
  border: 1px solid rgba(200,168,122,.25);
  padding: .25rem .65rem;
}
.arch-service-card__line {
  position: absolute;
  bottom: 0;
  left: 0;
  height: 2px;
  width: 0;
  background: var(--arch-accent);
  transition: width .4s ease;
}
.arch-service-card:hover .arch-service-card__line { width: 100%; }

/* ============================================================
   PHILOSOPHY / ABOUT SPLIT
   ============================================================ */
.arch-about {
  background: var(--arch-surface);
}
.arch-about__inner {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 5rem;
  align-items: center;
}
.arch-about__visual {
  position: relative;
}

/* CSS floor-plan art */
.arch-floorplan {
  width: 100%;
  aspect-ratio: 1;
  background: #0a0a0a;
  border: 1px solid var(--arch-border);
  position: relative;
  overflow: hidden;
}
.arch-fp-grid {
  position: absolute;
  inset: 0;
  background-image:
    linear-gradient(rgba(200,168,122,.05) 1px, transparent 1px),
    linear-gradient(90deg, rgba(200,168,122,.05) 1px, transparent 1px);
  background-size: 24px 24px;
}

/* Rooms */
.arch-fp-room {
  position: absolute;
  border: 1.5px solid rgba(200,168,122,.35);
  background: rgba(200,168,122,.03);
}
.arch-fp-room--living  { top: 10%; left: 8%;  width: 45%; height: 38%; }
.arch-fp-room--kitchen { top: 10%; left: 56%; width: 36%; height: 25%; }
.arch-fp-room--dining  { top: 37%; left: 56%; width: 36%; height: 20%; }
.arch-fp-room--bed1    { top: 52%; left: 8%;  width: 30%; height: 38%; }
.arch-fp-room--bed2    { top: 52%; left: 41%; width: 24%; height: 28%; }
.arch-fp-room--bath    { top: 52%; left: 68%; width: 24%; height: 16%; }
.arch-fp-room--bath2   { top: 70%; left: 68%; width: 24%; height: 10%; }

/* Door openings */
.arch-fp-door {
  position: absolute;
  background: #0a0a0a;
}
.arch-fp-door::after {
  content: '';
  position: absolute;
  border: 1px solid rgba(200,168,122,.35);
  border-radius: 100% 0 0 0;
}
.arch-fp-door--1 {
  bottom: -1px; left: 30%; width: 18px; height: 3px;
}
.arch-fp-door--1::after {
  width: 14px; height: 14px;
  bottom: 0; left: 0;
  border-radius: 0 0 100% 0;
}

/* Room labels */
.arch-fp-label {
  position: absolute;
  font-family: 'Courier New', monospace;
  font-size: .5rem;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: rgba(200,168,122,.45);
  white-space: nowrap;
}
.arch-fp-label--living  { top: 24%; left: 13%; }
.arch-fp-label--kitchen { top: 17%; left: 60%; }
.arch-fp-label--dining  { top: 43%; left: 60%; }
.arch-fp-label--bed1    { top: 67%; left: 12%; }
.arch-fp-label--bed2    { top: 62%; left: 43%; }
.arch-fp-label--bath    { top: 58%; left: 71%; }

/* Furniture silhouettes */
.arch-fp-sofa {
  position: absolute;
  top: 20%; left: 12%;
  width: 32%; height: 14%;
  border: 1px solid rgba(200,168,122,.2);
  background: rgba(200,168,122,.04);
}
.arch-fp-table {
  position: absolute;
  top: 42%; left: 60%;
  width: 22%; height: 12%;
  border-radius: 50%;
  border: 1px solid rgba(200,168,122,.2);
  background: rgba(200,168,122,.04);
}

/* Accent dot markers */
.arch-fp-dot {
  position: absolute;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--arch-accent);
  box-shadow: 0 0 8px rgba(200,168,122,.4);
}
.arch-fp-dot--1 { top: 10%; left: 8%; }
.arch-fp-dot--2 { top: 10%; right: 8%; }
.arch-fp-dot--3 { bottom: 10%; left: 8%; }
.arch-fp-dot--4 { bottom: 10%; right: 8%; }

.arch-about__founded {
  position: absolute;
  top: -1rem;
  right: -1rem;
  background: var(--arch-card);
  border: 1px solid var(--arch-border);
  padding: 1.25rem 1.75rem;
  text-align: center;
}
.arch-about__founded-year {
  font-family: var(--tf-font-heading, 'Cormorant Garamond','Georgia',serif);
  font-size: 3.5rem;
  font-weight: 300;
  color: var(--arch-accent);
  line-height: 1;
  display: block;
}
.arch-about__founded-lbl {
  font-size: .6rem;
  letter-spacing: .15em;
  text-transform: uppercase;
  color: var(--arch-muted);
  margin-top: .25rem;
  display: block;
}

.arch-about__copy { display: flex; flex-direction: column; }
.arch-about__quote {
  font-family: var(--tf-font-heading, 'Cormorant Garamond','Georgia',serif);
  font-size: 1.45rem;
  font-weight: 300;
  font-style: italic;
  color: var(--arch-text);
  line-height: 1.5;
  border-left: 2px solid var(--arch-accent);
  padding-left: 1.5rem;
  margin: 2rem 0;
}
.arch-about__values {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.5rem;
  margin-top: 2rem;
}
.arch-value {
  display: flex;
  flex-direction: column;
  gap: .35rem;
}
.arch-value__title {
  font-size: .85rem;
  font-weight: 600;
  color: var(--arch-text);
  letter-spacing: .03em;
}
.arch-value__desc {
  font-size: .8rem;
  color: var(--arch-muted);
  line-height: 1.6;
}

/* ============================================================
   AWARDS STRIP
   ============================================================ */
.arch-awards {
  background: var(--arch-bg);
  border-top: 1px solid var(--arch-border);
  border-bottom: 1px solid var(--arch-border);
  padding: 3.5rem 0;
}
.arch-awards__inner {
  display: flex;
  align-items: center;
  gap: 0;
  flex-wrap: wrap;
}
.arch-award {
  flex: 1;
  min-width: 200px;
  padding: 1rem 2.5rem;
  border-right: 1px solid var(--arch-border);
  display: flex;
  align-items: center;
  gap: 1.25rem;
}
.arch-award:last-child { border-right: none; }
.arch-award__icon {
  width: 40px;
  height: 40px;
  background: rgba(200,168,122,.1);
  border: 1px solid rgba(200,168,122,.25);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--arch-accent);
  flex-shrink: 0;
}
.arch-award__name {
  font-size: .8rem;
  font-weight: 600;
  color: var(--arch-text);
  margin-bottom: .15rem;
}
.arch-award__year {
  font-size: .68rem;
  color: var(--arch-muted);
  letter-spacing: .06em;
}

/* ============================================================
   TEAM
   ============================================================ */
.arch-team {
  background: var(--arch-surface);
}
.arch-team__grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 1px;
  background: var(--arch-border);
  margin-top: 4rem;
}
.arch-team-card {
  background: var(--arch-card);
  padding: 2.5rem 2rem;
  position: relative;
  overflow: hidden;
  transition: background .3s;
}
.arch-team-card:hover { background: #1f1f1f; }
.arch-team-card__avatar {
  width: 64px;
  height: 64px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: var(--tf-font-heading, 'Cormorant Garamond','Georgia',serif);
  font-size: 1.5rem;
  font-weight: 400;
  color: #0d0d0d;
  margin-bottom: 1.25rem;
  flex-shrink: 0;
}
.arch-team-card__name {
  font-family: var(--tf-font-heading, 'Cormorant Garamond','Georgia',serif);
  font-size: 1.25rem;
  font-weight: 400;
  color: var(--arch-text);
  margin: 0 0 .25rem;
}
.arch-team-card__role {
  font-size: .72rem;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: var(--arch-accent);
  margin-bottom: 1rem;
}
.arch-team-card__bio {
  font-size: .82rem;
  color: var(--arch-muted);
  line-height: 1.7;
  margin-bottom: 1.25rem;
}
.arch-team-card__creds {
  display: flex;
  flex-direction: column;
  gap: .4rem;
}
.arch-team-card__cred {
  font-size: .7rem;
  color: var(--arch-muted);
  display: flex;
  align-items: center;
  gap: .45rem;
}
.arch-team-card__cred svg { color: var(--arch-accent); flex-shrink: 0; }
.arch-team-card__bg-num {
  position: absolute;
  bottom: -1rem;
  right: -1rem;
  font-family: var(--tf-font-heading, 'Cormorant Garamond','Georgia',serif);
  font-size: 6rem;
  font-weight: 300;
  color: rgba(200,168,122,.04);
  line-height: 1;
  pointer-events: none;
  user-select: none;
}

/* ============================================================
   PROCESS
   ============================================================ */
.arch-process {
  background: var(--arch-bg);
}
.arch-process__steps {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 0;
  margin-top: 4rem;
  position: relative;
}
.arch-process__steps::before {
  content: '';
  position: absolute;
  top: 2rem;
  left: 2rem;
  right: 2rem;
  height: 1px;
  background: linear-gradient(90deg, var(--arch-accent) 0%, rgba(200,168,122,.15) 100%);
  z-index: 0;
}
.arch-process-step {
  padding: 0 2rem;
  position: relative;
  z-index: 1;
}
.arch-process-step__num {
  width: 40px;
  height: 40px;
  border: 1px solid var(--arch-accent);
  background: var(--arch-bg);
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: var(--tf-font-heading, 'Cormorant Garamond','Georgia',serif);
  font-size: 1.1rem;
  font-weight: 300;
  color: var(--arch-accent);
  margin-bottom: 1.5rem;
}
.arch-process-step__title {
  font-size: .85rem;
  font-weight: 600;
  color: var(--arch-text);
  margin-bottom: .5rem;
  letter-spacing: .02em;
}
.arch-process-step__desc {
  font-size: .78rem;
  color: var(--arch-muted);
  line-height: 1.7;
}

/* ============================================================
   STATS BAR
   ============================================================ */
.arch-stats-bar {
  background: var(--arch-card);
  border-top: 1px solid var(--arch-border);
  border-bottom: 1px solid var(--arch-border);
  padding: 3rem 0;
}
.arch-stats-bar__inner {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 0;
}
.arch-stat {
  text-align: center;
  padding: 1rem 2rem;
  border-right: 1px solid var(--arch-border);
  position: relative;
}
.arch-stat:last-child { border-right: none; }
.arch-stat__val {
  font-family: var(--tf-font-heading, 'Cormorant Garamond','Georgia',serif);
  font-size: 3.5rem;
  font-weight: 300;
  color: var(--arch-accent);
  line-height: 1;
  margin-bottom: .35rem;
}
.arch-stat__val sup {
  font-size: 1.5rem;
  vertical-align: super;
}
.arch-stat__lbl {
  font-size: .7rem;
  letter-spacing: .15em;
  text-transform: uppercase;
  color: var(--arch-muted);
}

/* ============================================================
   COMMISSION / CONTACT
   ============================================================ */
.arch-commission {
  background: var(--arch-surface);
}
.arch-commission__inner {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 5rem;
  align-items: start;
}
.arch-commission__info { padding-top: 1rem; }
.arch-commission__promise {
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
  margin-top: 2.5rem;
}
.arch-promise {
  display: flex;
  gap: 1rem;
  align-items: flex-start;
}
.arch-promise__icon {
  width: 32px;
  height: 32px;
  border: 1px solid rgba(200,168,122,.3);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--arch-accent);
  flex-shrink: 0;
  margin-top: .1rem;
}
.arch-promise__title {
  font-size: .85rem;
  font-weight: 600;
  color: var(--arch-text);
  margin-bottom: .2rem;
}
.arch-promise__desc {
  font-size: .8rem;
  color: var(--arch-muted);
  line-height: 1.6;
}

/* Form */
.arch-form { display: flex; flex-direction: column; gap: 1.5rem; }
.arch-form__row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
.arch-field { display: flex; flex-direction: column; gap: .5rem; }
.arch-field label {
  font-size: .72rem;
  letter-spacing: .12em;
  text-transform: uppercase;
  color: var(--arch-muted);
}
.arch-field input,
.arch-field select,
.arch-field textarea {
  background: var(--arch-card);
  border: 1px solid var(--arch-border);
  color: var(--arch-text);
  padding: .85rem 1rem;
  font-size: .9rem;
  font-family: inherit;
  outline: none;
  transition: border-color .2s;
  border-radius: 0;
  width: 100%;
  box-sizing: border-box;
  -webkit-appearance: none;
}
.arch-field input:focus,
.arch-field select:focus,
.arch-field textarea:focus {
  border-color: var(--arch-accent);
}
.arch-field select option { background: #1a1a1a; }
.arch-field textarea { resize: vertical; min-height: 120px; }
.arch-form__budget {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: .75rem;
}
.arch-budget-opt { display: none; }
.arch-budget-opt + label {
  display: block;
  border: 1px solid var(--arch-border);
  padding: .6rem;
  text-align: center;
  font-size: .72rem;
  letter-spacing: .08em;
  text-transform: uppercase;
  color: var(--arch-muted);
  cursor: pointer;
  transition: all .2s;
}
.arch-budget-opt:checked + label {
  border-color: var(--arch-accent);
  color: var(--arch-accent);
  background: rgba(200,168,122,.06);
}
.arch-budget-opt + label:hover { border-color: rgba(200,168,122,.4); color: var(--arch-text); }
.arch-form__note {
  font-size: .73rem;
  color: var(--arch-muted);
  line-height: 1.6;
  border-left: 2px solid rgba(200,168,122,.3);
  padding-left: .75rem;
}
.arch-form__submit {
  display: flex;
  align-items: center;
  gap: 1rem;
}

/* ============================================================
   FOOTER CTA
   ============================================================ */
.arch-cta {
  background: var(--arch-accent);
  padding: 5rem 0;
  text-align: center;
  position: relative;
  overflow: hidden;
}
.arch-cta::before {
  content: '';
  position: absolute;
  inset: 0;
  background-image:
    linear-gradient(rgba(0,0,0,.08) 1px, transparent 1px),
    linear-gradient(90deg, rgba(0,0,0,.08) 1px, transparent 1px);
  background-size: 40px 40px;
}
.arch-cta__inner { position: relative; z-index: 1; }
.arch-cta__eyebrow {
  font-size: .7rem;
  letter-spacing: .2em;
  text-transform: uppercase;
  color: rgba(0,0,0,.6);
  margin-bottom: 1rem;
}
.arch-cta__h2 {
  font-family: var(--tf-font-heading, 'Cormorant Garamond','Georgia',serif);
  font-size: clamp(2.5rem, 5vw, 4.5rem);
  font-weight: 300;
  color: #0d0d0d;
  line-height: 1.1;
  letter-spacing: -.02em;
  margin: 0 0 1.25rem;
}
.arch-cta__sub {
  font-size: 1rem;
  color: rgba(0,0,0,.65);
  margin: 0 0 2.5rem;
  max-width: 44ch;
  margin-left: auto;
  margin-right: auto;
}
.arch-btn--dark {
  background: #0d0d0d;
  color: var(--arch-accent);
}
.arch-btn--dark:hover { background: #1a1a1a; }
.arch-btn--ghost-dark {
  background: transparent;
  color: #0d0d0d;
  border: 1px solid rgba(0,0,0,.3);
}
.arch-btn--ghost-dark:hover { background: rgba(0,0,0,.08); }

/* ============================================================
   RESPONSIVE
   ============================================================ */
@media (max-width: 1200px) {
  .arch-hero { grid-template-columns: 1fr 1fr; }
  .arch-team__grid { grid-template-columns: repeat(2, 1fr); }
  .arch-process__steps { grid-template-columns: repeat(3, 1fr); gap: 2rem; }
  .arch-process__steps::before { display: none; }
}
@media (max-width: 960px) {
  .arch-hero { grid-template-columns: 1fr; min-height: auto; }
  .arch-hero__visual { display: none; }
  .arch-hero__copy { padding: 5rem 2.5rem; }
  .arch-about__inner { grid-template-columns: 1fr; gap: 3rem; }
  .arch-commission__inner { grid-template-columns: 1fr; gap: 3rem; }
  .arch-portfolio__grid {
    grid-template-columns: 1fr 1fr;
    grid-template-rows: auto;
  }
  .arch-project--large { grid-column: 1 / 3; }
  .arch-project--tall { grid-column: 1 / 3; }
  .arch-services__grid { grid-template-columns: 1fr; }
  .arch-stats-bar__inner { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 640px) {
  .arch-container { padding: 0 1.5rem; }
  .arch-section { padding: 4rem 0; }
  .arch-hero__copy { padding: 4rem 1.5rem; }
  .arch-hero__stats { gap: 1.5rem; }
  .arch-portfolio__grid { grid-template-columns: 1fr; }
  .arch-project--large,
  .arch-project--tall { grid-column: 1; grid-row: auto; }
  .arch-team__grid { grid-template-columns: 1fr; }
  .arch-process__steps { grid-template-columns: 1fr; }
  .arch-stats-bar__inner { grid-template-columns: 1fr 1fr; }
  .arch-about__values { grid-template-columns: 1fr; }
  .arch-form__row { grid-template-columns: 1fr; }
  .arch-form__budget { grid-template-columns: 1fr 1fr; }
  .arch-award { flex: 0 0 100%; border-right: none; border-bottom: 1px solid var(--arch-border); }
  .arch-award:last-child { border-bottom: none; }
  .arch-awards__inner { flex-direction: column; }
}
</style>

<main class="tf-arch-page" id="main">

  <?php
  // ============================================================
  // SECTION 1 — HERO
  // ============================================================
  ?>
  <section class="arch-hero" aria-label="<?php esc_attr_e( 'Architecture Studio Hero', 'themeflex' ); ?>">

    <!-- Copy -->
    <div class="arch-hero__copy">
      <div class="arch-hero__eyebrow" aria-hidden="true">
        <span class="arch-hero__eyebrow-line"></span>
        <?php esc_html_e( 'Architecture &amp; Design Studio', 'themeflex' ); ?>
      </div>

      <h1 class="arch-hero__h1">
        <?php esc_html_e( 'We Build', 'themeflex' ); ?><br>
        <em><?php esc_html_e( 'Spaces That', 'themeflex' ); ?></em><br>
        <?php esc_html_e( 'Endure', 'themeflex' ); ?>
      </h1>

      <p class="arch-hero__sub">
        <?php esc_html_e( 'Forma Studio is an award-winning architecture practice creating places of purpose and beauty — from civic landmarks to intimate residences — since 1998.', 'themeflex' ); ?>
      </p>

      <div class="arch-hero__ctas">
        <a href="#commission" class="arch-btn arch-btn--primary">
          <?php tf_icon( 'mail', 18 ); ?>
          <?php esc_html_e( 'Commission a Project', 'themeflex' ); ?>
        </a>
        <a href="#portfolio" class="arch-btn arch-btn--outline">
          <?php tf_icon( 'grid', 18 ); ?>
          <?php esc_html_e( 'View Portfolio', 'themeflex' ); ?>
        </a>
      </div>

      <div class="arch-hero__stats" aria-label="<?php esc_attr_e( 'Studio statistics', 'themeflex' ); ?>">
        <div>
          <div class="arch-hero__stat-val" data-counter="26" data-suffix="yrs">26yrs</div>
          <div class="arch-hero__stat-lbl"><?php esc_html_e( 'Established', 'themeflex' ); ?></div>
        </div>
        <div>
          <div class="arch-hero__stat-val" data-counter="340" data-suffix="+">340+</div>
          <div class="arch-hero__stat-lbl"><?php esc_html_e( 'Projects Built', 'themeflex' ); ?></div>
        </div>
        <div>
          <div class="arch-hero__stat-val" data-counter="28" data-suffix="">28</div>
          <div class="arch-hero__stat-lbl"><?php esc_html_e( 'International Awards', 'themeflex' ); ?></div>
        </div>
      </div>
    </div><!-- .arch-hero__copy -->

    <!-- Blueprint Visual -->
    <div class="arch-hero__visual" aria-hidden="true">
      <div class="arch-blueprint">
        <div class="arch-blueprint__grid"></div>
        <div class="arch-blueprint__grid-major"></div>
      </div>

      <!-- Project identifier badge -->
      <div class="arch-project-badge">REF: FS-2024-CIVIC-087 · REVISION 04</div>

      <!-- Compass -->
      <div class="arch-compass" aria-hidden="true"></div>

      <!-- Building wireframe -->
      <div class="arch-building" aria-hidden="true">
        <!-- Main body -->
        <div class="arch-bld-base">
          <div class="arch-bld-floors">
            <?php
            // 8 floors with window patterns
            $floor_patterns = [
              [ true,  false, true,  true,  false ],
              [ false, true,  true,  false, true  ],
              [ true,  true,  false, true,  false ],
              [ false, true,  false, true,  true  ],
              [ true,  false, true,  false, true  ],
              [ false, true,  true,  true,  false ],
              [ true,  true,  false, false, true  ],
              [ false, false, true,  true,  true  ],
            ];
            foreach ( $floor_patterns as $fi => $wins ) :
            ?>
            <div class="arch-bld-floor">
              <?php foreach ( $wins as $wi => $lit ) : ?>
              <div class="arch-bld-win<?php echo $lit ? ' lit' : ''; ?>"
                   style="--d:<?php echo esc_attr( ( $fi * 5 + $wi * 2 ) / 10 ); ?>s"></div>
              <?php endforeach; ?>
            </div>
            <?php endforeach; ?>
          </div>
        </div>

        <!-- Tower -->
        <div class="arch-bld-tower">
          <div class="arch-bld-tower-floors">
            <div class="arch-bld-tower-floor"></div>
            <div class="arch-bld-tower-floor"></div>
            <div class="arch-bld-tower-floor"></div>
          </div>
          <div class="arch-bld-spire"></div>
        </div>
      </div>

      <!-- Dimension lines -->
      <div class="arch-dim arch-dim--h" aria-hidden="true">
        <span class="arch-dim-label">42.8 m</span>
      </div>
      <div class="arch-dim arch-dim--v" aria-hidden="true">
        <span class="arch-dim-label">118.6 m</span>
      </div>

      <!-- Annotation callouts -->
      <div class="arch-anno arch-anno--1" aria-hidden="true">
        <div class="arch-anno__dot"></div>
        <div class="arch-anno__line"></div>
        <span class="arch-anno__text">Curtain Wall · Low-E Glass</span>
      </div>
      <div class="arch-anno arch-anno--2" aria-hidden="true">
        <div class="arch-anno__dot"></div>
        <div class="arch-anno__line"></div>
        <span class="arch-anno__text">Structural Core</span>
      </div>
      <div class="arch-anno arch-anno--3" aria-hidden="true">
        <div class="arch-anno__dot"></div>
        <div class="arch-anno__line"></div>
        <span class="arch-anno__text">Lobby Atrium</span>
      </div>

      <!-- Crosshairs -->
      <div class="arch-crosshair arch-crosshair--1" aria-hidden="true"></div>
      <div class="arch-crosshair arch-crosshair--2" aria-hidden="true"></div>

      <!-- Scale bar -->
      <div class="arch-scale" aria-hidden="true">
        <div class="arch-scale__bar">
          <div class="arch-scale__seg"></div>
          <div class="arch-scale__seg"></div>
          <div class="arch-scale__seg"></div>
          <div class="arch-scale__seg"></div>
        </div>
        <span class="arch-scale__label">0 &nbsp; 10 &nbsp; 20 &nbsp; 40 m</span>
      </div>
    </div><!-- .arch-hero__visual -->

  </section><!-- .arch-hero -->

  <?php
  // ============================================================
  // RECOGNITION STRIP
  // ============================================================
  $strip_items = [
    [ 'icon' => 'award',  'text' => 'AIA Gold Medal 2023' ],
    [ 'icon' => 'star',   'text' => 'Dezeen Award Winner' ],
    [ 'icon' => 'trophy', 'text' => 'RIBA International Prize' ],
    [ 'icon' => 'globe',  'text' => 'Archmarathon Prize' ],
    [ 'icon' => 'award',  'text' => 'WAF World Architecture Festival' ],
    [ 'icon' => 'star',   'text' => 'Frame Awards — Best Workplace' ],
    [ 'icon' => 'trophy', 'text' => 'Architizer A+ Award' ],
    [ 'icon' => 'globe',  'text' => 'BD Architect of the Year' ],
  ];
  ?>
  <div class="arch-strip" aria-label="<?php esc_attr_e( 'Awards and recognition', 'themeflex' ); ?>">
    <div class="arch-strip__track" aria-hidden="true">
      <?php
      // Duplicate for seamless loop
      $all = array_merge( $strip_items, $strip_items );
      foreach ( $all as $item ) :
      ?>
      <div class="arch-strip__item">
        <?php tf_icon( $item['icon'], 14 ); ?>
        <?php echo esc_html( $item['text'] ); ?>
      </div>
      <div class="arch-strip__sep" aria-hidden="true"></div>
      <?php endforeach; ?>
    </div>
  </div>

  <?php
  // ============================================================
  // SECTION 2 — PORTFOLIO
  // ============================================================
  $projects = [
    [
      'class'    => 'arch-project--large arch-project--1',
      'bg_class' => '',
      'cat'      => 'Commercial · Munich',
      'name'     => 'Westpark Tower',
      'meta'     => [ '38 Floors', '2023', '€ 420M' ],
    ],
    [
      'class'    => 'arch-project--tall arch-project--3',
      'bg_class' => '',
      'cat'      => 'Cultural · Berlin',
      'name'     => 'Stadtbibliothek Mitte',
      'meta'     => [ '6 Floors', '2022', 'RIBA Award' ],
    ],
    [
      'class'    => 'arch-project--2',
      'bg_class' => '',
      'cat'      => 'Residential · Vienna',
      'name'     => 'Belvedere Residences',
      'meta'     => [ '48 Units', '2024', 'AIA Award' ],
    ],
    [
      'class'    => 'arch-project--4',
      'bg_class' => '',
      'cat'      => 'Civic · Hamburg',
      'name'     => 'Hafenkonzerthaus',
      'meta'     => [ '1,800 Seats', '2021', 'Dezeen Award' ],
    ],
    [
      'class'    => 'arch-project--5',
      'bg_class' => '',
      'cat'      => 'Mixed-Use · Zürich',
      'name'     => 'Limmatquai Complex',
      'meta'     => [ '12 Floors', '2024', '€ 180M' ],
    ],
  ];
  ?>
  <section class="arch-section arch-portfolio" id="portfolio"
           aria-labelledby="arch-portfolio-h">
    <div class="arch-container">
      <div class="arch-portfolio__header">
        <div>
          <div class="arch-label">
            <span class="arch-label-line" aria-hidden="true"></span>
            <?php esc_html_e( 'Selected Work', 'themeflex' ); ?>
          </div>
          <h2 class="arch-h2" id="arch-portfolio-h">
            <?php esc_html_e( 'Built', 'themeflex' ); ?> <em><?php esc_html_e( 'Portfolio', 'themeflex' ); ?></em>
          </h2>
        </div>
        <a href="#" class="arch-btn arch-btn--outline">
          <?php esc_html_e( 'All Projects', 'themeflex' ); ?>
          <?php tf_icon( 'arrow-right', 16 ); ?>
        </a>
      </div>

      <div class="arch-portfolio__grid">
        <?php foreach ( $projects as $idx => $proj ) : ?>
        <a href="#" class="arch-project <?php echo esc_attr( $proj['class'] ); ?>"
           aria-label="<?php echo esc_attr( $proj['name'] ); ?>">
          <div class="arch-project__thumb">
            <div class="arch-project__bg"></div>
            <?php if ( $idx === 0 ) : ?>
            <div class="arch-proj1-lines" aria-hidden="true"></div>
            <?php elseif ( $idx === 1 ) : ?>
            <?php /* proj3 = cultural, uses .arch-proj3-wrap */ ?>
            <div class="arch-proj3-wrap" aria-hidden="true">
              <div class="arch-proj3-form">
                <div class="arch-proj3-grid"></div>
              </div>
            </div>
            <?php elseif ( $idx === 2 ) : ?>
            <div class="arch-proj2-form" aria-hidden="true"></div>
            <?php elseif ( $idx === 3 ) : ?>
            <div class="arch-proj4-arc" aria-hidden="true"></div>
            <?php elseif ( $idx === 4 ) : ?>
            <div class="arch-proj5-grid" aria-hidden="true"></div>
            <div class="arch-proj5-mark" aria-hidden="true"></div>
            <?php endif; ?>

            <div class="arch-project__overlay">
              <p class="arch-project__cat"><?php echo esc_html( $proj['cat'] ); ?></p>
              <h3 class="arch-project__name"><?php echo esc_html( $proj['name'] ); ?></h3>
              <div class="arch-project__meta">
                <?php foreach ( $proj['meta'] as $m ) : ?>
                <span><?php echo esc_html( $m ); ?></span>
                <?php endforeach; ?>
              </div>
            </div>
            <div class="arch-project__arrow" aria-hidden="true">
              <?php tf_icon( 'arrow-up-right', 16 ); ?>
            </div>
          </div>
        </a>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // SECTION 3 — STATS BAR
  // ============================================================
  $stats = [
    [ 'val' => '340', 'suffix' => '+', 'lbl' => __( 'Projects Completed', 'themeflex' ) ],
    [ 'val' => '28',  'suffix' => '',  'lbl' => __( 'International Awards', 'themeflex' ) ],
    [ 'val' => '18',  'suffix' => '',  'lbl' => __( 'Countries Built In', 'themeflex' ) ],
    [ 'val' => '98',  'suffix' => '%', 'lbl' => __( 'Client Satisfaction', 'themeflex' ) ],
  ];
  ?>
  <div class="arch-stats-bar" role="region"
       aria-label="<?php esc_attr_e( 'Studio statistics', 'themeflex' ); ?>">
    <div class="arch-container">
      <div class="arch-stats-bar__inner">
        <?php foreach ( $stats as $s ) : ?>
        <div class="arch-stat">
          <div class="arch-stat__val"
               data-counter="<?php echo esc_attr( $s['val'] ); ?>"
               data-suffix="<?php echo esc_attr( $s['suffix'] ); ?>">
            <?php echo esc_html( $s['val'] . $s['suffix'] ); ?>
          </div>
          <div class="arch-stat__lbl"><?php echo esc_html( $s['lbl'] ); ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <?php
  // ============================================================
  // SECTION 4 — SERVICES
  // ============================================================
  $services = [
    [
      'icon'  => 'building-2',
      'title' => __( 'Architecture', 'themeflex' ),
      'desc'  => __( 'From concept to completion — we design buildings that respond to their context, brief, and the people who inhabit them. Residential, commercial, civic, and mixed-use typologies.', 'themeflex' ),
      'tags'  => [ 'Concept Design', 'Schematic Design', 'Construction Documents', 'Site Supervision' ],
    ],
    [
      'icon'  => 'sofa',
      'title' => __( 'Interior Design', 'themeflex' ),
      'desc'  => __( 'Spaces calibrated to the human scale — material palettes, lighting choreography, bespoke furniture design, and FF&E specification from concept through installation.', 'themeflex' ),
      'tags'  => [ 'Space Planning', 'Material Palette', 'FF&E Specification', 'Lighting Design' ],
    ],
    [
      'icon'  => 'trees',
      'title' => __( 'Landscape Architecture', 'themeflex' ),
      'desc'  => __( 'Outdoor environments as deliberate extensions of the built work — planting strategies, hard landscaping, water features, and urban realm public space design.', 'themeflex' ),
      'tags'  => [ 'Masterplanning', 'Planting Design', 'Public Realm', 'Urban Greening' ],
    ],
    [
      'icon'  => 'map',
      'title' => __( 'Urban Planning', 'themeflex' ),
      'desc'  => __( 'Large-scale thinking — neighbourhood frameworks, mixed-use masterplans, transportation nodes, and adaptive re-use strategies for post-industrial sites and city centres.', 'themeflex' ),
      'tags'  => [ 'Masterplanning', 'Zoning Strategy', 'Mixed-Use', 'Feasibility' ],
    ],
  ];
  ?>
  <section class="arch-section arch-services"
           aria-labelledby="arch-services-h">
    <div class="arch-container">
      <div class="arch-label">
        <span class="arch-label-line" aria-hidden="true"></span>
        <?php esc_html_e( 'What We Do', 'themeflex' ); ?>
      </div>
      <h2 class="arch-h2" id="arch-services-h">
        <?php esc_html_e( 'Our', 'themeflex' ); ?> <em><?php esc_html_e( 'Services', 'themeflex' ); ?></em>
      </h2>

      <div class="arch-services__grid">
        <?php foreach ( $services as $idx => $srv ) : ?>
        <div class="arch-service-card">
          <span class="arch-service-card__num" aria-hidden="true">
            0<?php echo intval( $idx + 1 ); ?>
          </span>
          <div class="arch-service-card__icon" aria-hidden="true">
            <?php tf_icon( $srv['icon'], 20 ); ?>
          </div>
          <h3 class="arch-service-card__title"><?php echo esc_html( $srv['title'] ); ?></h3>
          <p class="arch-service-card__desc"><?php echo esc_html( $srv['desc'] ); ?></p>
          <div class="arch-service-card__tags">
            <?php foreach ( $srv['tags'] as $tag ) : ?>
            <span class="arch-service-tag"><?php echo esc_html( $tag ); ?></span>
            <?php endforeach; ?>
          </div>
          <div class="arch-service-card__line" aria-hidden="true"></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // SECTION 5 — PHILOSOPHY / ABOUT
  // ============================================================
  ?>
  <section class="arch-section arch-about"
           aria-labelledby="arch-about-h">
    <div class="arch-container">
      <div class="arch-about__inner">

        <!-- Floor plan visual -->
        <div class="arch-about__visual">
          <div class="arch-floorplan" role="img"
               aria-label="<?php esc_attr_e( 'Architectural floor plan illustration', 'themeflex' ); ?>">
            <div class="arch-fp-grid"></div>

            <!-- Rooms -->
            <div class="arch-fp-room arch-fp-room--living"></div>
            <div class="arch-fp-room arch-fp-room--kitchen"></div>
            <div class="arch-fp-room arch-fp-room--dining"></div>
            <div class="arch-fp-room arch-fp-room--bed1"></div>
            <div class="arch-fp-room arch-fp-room--bed2"></div>
            <div class="arch-fp-room arch-fp-room--bath"></div>
            <div class="arch-fp-room arch-fp-room--bath2"></div>

            <!-- Furniture -->
            <div class="arch-fp-sofa"></div>
            <div class="arch-fp-table"></div>

            <!-- Labels -->
            <span class="arch-fp-label arch-fp-label--living">Living</span>
            <span class="arch-fp-label arch-fp-label--kitchen">Kitchen</span>
            <span class="arch-fp-label arch-fp-label--dining">Dining</span>
            <span class="arch-fp-label arch-fp-label--bed1">Bed 1</span>
            <span class="arch-fp-label arch-fp-label--bed2">Bed 2</span>
            <span class="arch-fp-label arch-fp-label--bath">Bath</span>

            <!-- Corner dots -->
            <div class="arch-fp-dot arch-fp-dot--1"></div>
            <div class="arch-fp-dot arch-fp-dot--2"></div>
            <div class="arch-fp-dot arch-fp-dot--3"></div>
            <div class="arch-fp-dot arch-fp-dot--4"></div>
          </div>

          <div class="arch-about__founded" aria-hidden="true">
            <span class="arch-about__founded-year">1998</span>
            <span class="arch-about__founded-lbl">Founded</span>
          </div>
        </div>

        <!-- Copy -->
        <div class="arch-about__copy">
          <div class="arch-label">
            <span class="arch-label-line" aria-hidden="true"></span>
            <?php esc_html_e( 'Studio Philosophy', 'themeflex' ); ?>
          </div>
          <h2 class="arch-h2" id="arch-about-h">
            <?php esc_html_e( 'Architecture as', 'themeflex' ); ?>
            <em><?php esc_html_e( 'Civic Art', 'themeflex' ); ?></em>
          </h2>
          <p class="arch-lead">
            <?php esc_html_e( 'We believe every building is an act of stewardship — of its site, its users, and its era. Forma Studio was founded in Munich in 1998 with the conviction that rigorous design thinking and material honesty produce architecture that outlasts its own making.', 'themeflex' ); ?>
          </p>

          <blockquote class="arch-about__quote">
            <?php esc_html_e( '"The best architecture is the kind that makes you feel as though it could not have been otherwise — as though the building grew from the land rather than was placed upon it."', 'themeflex' ); ?>
          </blockquote>
          <p style="font-size:.78rem;color:var(--arch-muted);margin:-.75rem 0 1.5rem;">
            — <?php esc_html_e( 'Dr. Lukas Bauer, Founding Partner', 'themeflex' ); ?>
          </p>

          <div class="arch-about__values">
            <?php
            $values = [
              [ 'title' => __( 'Context First', 'themeflex' ),     'desc' => __( 'Every site tells a story. We listen before we draw.', 'themeflex' ) ],
              [ 'title' => __( 'Material Honesty', 'themeflex' ),  'desc' => __( 'Concrete, glass, and timber expressed truthfully.', 'themeflex' ) ],
              [ 'title' => __( 'Civic Responsibility', 'themeflex' ), 'desc' => __( 'Buildings serve a community, not only a client.', 'themeflex' ) ],
              [ 'title' => __( 'Long-Term Thinking', 'themeflex' ), 'desc' => __( 'We design for adaptability and the century ahead.', 'themeflex' ) ],
            ];
            foreach ( $values as $v ) :
            ?>
            <div class="arch-value">
              <div class="arch-value__title"><?php echo esc_html( $v['title'] ); ?></div>
              <div class="arch-value__desc"><?php echo esc_html( $v['desc'] ); ?></div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>

      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // AWARDS STRIP
  // ============================================================
  $awards = [
    [ 'icon' => 'award',  'name' => __( 'AIA Gold Medal', 'themeflex' ),         'year' => '2023' ],
    [ 'icon' => 'star',   'name' => __( 'Dezeen Award', 'themeflex' ),            'year' => '2022 · Best Public Building' ],
    [ 'icon' => 'trophy', 'name' => __( 'RIBA International Prize', 'themeflex' ), 'year' => '2021' ],
    [ 'icon' => 'medal',  'name' => __( 'Architizer A+', 'themeflex' ),           'year' => '2024 · Public Architecture' ],
    [ 'icon' => 'globe',  'name' => __( 'WAF World Building of the Year', 'themeflex' ), 'year' => '2023' ],
  ];
  ?>
  <div class="arch-awards" role="region"
       aria-label="<?php esc_attr_e( 'Awards and accolades', 'themeflex' ); ?>">
    <div class="arch-container">
      <div class="arch-awards__inner">
        <?php foreach ( $awards as $aw ) : ?>
        <div class="arch-award">
          <div class="arch-award__icon" aria-hidden="true">
            <?php tf_icon( $aw['icon'], 18 ); ?>
          </div>
          <div>
            <div class="arch-award__name"><?php echo esc_html( $aw['name'] ); ?></div>
            <div class="arch-award__year"><?php echo esc_html( $aw['year'] ); ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <?php
  // ============================================================
  // SECTION 6 — TEAM
  // ============================================================
  $team = [
    [
      'initials' => 'LB',
      'bg'       => 'linear-gradient(135deg,#c8a87a,#a37c38)',
      'name'     => 'Dr. Lukas Bauer',
      'role'     => __( 'Founding Partner', 'themeflex' ),
      'bio'      => __( 'Graduated ETH Zürich, PhD TU Munich. Lukas has led the studio since its founding, winning the RIBA International Prize in 2021 for the Stadtbibliothek Mitte.', 'themeflex' ),
      'creds'    => [
        __( 'ETH Zürich — M.Arch', 'themeflex' ),
        __( 'RIBA Fellow — 2018', 'themeflex' ),
        __( 'BDA Bund Deutscher Architekten', 'themeflex' ),
      ],
    ],
    [
      'initials' => 'SK',
      'bg'       => 'linear-gradient(135deg,#8fa99e,#4d7a6f)',
      'name'     => 'Sophia Klein',
      'role'     => __( 'Design Director', 'themeflex' ),
      'bio'      => __( 'A specialist in civic and cultural typologies, Sophia joined the studio in 2005 and led the Hafenkonzerthaus project from competition through construction.', 'themeflex' ),
      'creds'    => [
        __( 'Bartlett School of Architecture', 'themeflex' ),
        __( 'Dezeen Award Jury — 2023', 'themeflex' ),
        __( 'ARB Registered Architect', 'themeflex' ),
      ],
    ],
    [
      'initials' => 'MH',
      'bg'       => 'linear-gradient(135deg,#b5c1c9,#6b8090)',
      'name'     => 'Markus Hess',
      'role'     => __( 'Technical Director', 'themeflex' ),
      'bio'      => __( 'With 18 years of construction delivery experience, Markus ensures every project meets its technical, sustainability, and compliance milestones on time and on budget.', 'themeflex' ),
      'creds'    => [
        __( 'TU Munich — Structural Engineering', 'themeflex' ),
        __( 'LEED AP — Green Building', 'themeflex' ),
        __( 'Ingenieurkammer Bayern', 'themeflex' ),
      ],
    ],
    [
      'initials' => 'AV',
      'bg'       => 'linear-gradient(135deg,#d4a0a0,#a05050)',
      'name'     => 'Ana Vasić',
      'role'     => __( 'Head of Interiors', 'themeflex' ),
      'bio'      => __( 'Ana leads the interior architecture practice, bringing a refined material sensibility and an expertise in bespoke furniture design to every residential and hospitality commission.', 'themeflex' ),
      'creds'    => [
        __( 'Politecnico di Milano — Interior Design', 'themeflex' ),
        __( 'BIID Member', 'themeflex' ),
        __( 'Elle Décor Interiors Award 2022', 'themeflex' ),
      ],
    ],
  ];
  ?>
  <section class="arch-section arch-team"
           aria-labelledby="arch-team-h">
    <div class="arch-container">
      <div class="arch-label">
        <span class="arch-label-line" aria-hidden="true"></span>
        <?php esc_html_e( 'The Team', 'themeflex' ); ?>
      </div>
      <h2 class="arch-h2" id="arch-team-h">
        <?php esc_html_e( 'Principal', 'themeflex' ); ?> <em><?php esc_html_e( 'Architects', 'themeflex' ); ?></em>
      </h2>

      <div class="arch-team__grid">
        <?php foreach ( $team as $idx => $member ) : ?>
        <div class="arch-team-card">
          <div class="arch-team-card__avatar"
               style="background:<?php echo esc_attr( $member['bg'] ); ?>;"
               aria-hidden="true">
            <?php echo esc_html( $member['initials'] ); ?>
          </div>
          <h3 class="arch-team-card__name"><?php echo esc_html( $member['name'] ); ?></h3>
          <p class="arch-team-card__role"><?php echo esc_html( $member['role'] ); ?></p>
          <p class="arch-team-card__bio"><?php echo esc_html( $member['bio'] ); ?></p>
          <div class="arch-team-card__creds" aria-label="<?php esc_attr_e( 'Credentials', 'themeflex' ); ?>">
            <?php foreach ( $member['creds'] as $cred ) : ?>
            <span class="arch-team-card__cred">
              <?php tf_icon( 'check', 12 ); ?>
              <?php echo esc_html( $cred ); ?>
            </span>
            <?php endforeach; ?>
          </div>
          <div class="arch-team-card__bg-num" aria-hidden="true">
            0<?php echo intval( $idx + 1 ); ?>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // SECTION 7 — PROCESS
  // ============================================================
  $steps = [
    [
      'num'   => '01',
      'title' => __( 'Discovery', 'themeflex' ),
      'desc'  => __( 'Site visit, brief analysis, precedent research, and stakeholder interviews to establish the project\'s foundational ambitions.', 'themeflex' ),
    ],
    [
      'num'   => '02',
      'title' => __( 'Concept', 'themeflex' ),
      'desc'  => __( 'Massing studies, material explorations, and design options presented in workshop format with full client dialogue.', 'themeflex' ),
    ],
    [
      'num'   => '03',
      'title' => __( 'Schematic Design', 'themeflex' ),
      'desc'  => __( 'Developed floor plans, sections, elevations, and a material palette resolving the primary design intent.', 'themeflex' ),
    ],
    [
      'num'   => '04',
      'title' => __( 'Documentation', 'themeflex' ),
      'desc'  => __( 'Technical drawings, specifications, and tender packages sufficient for procurement and planning submission.', 'themeflex' ),
    ],
    [
      'num'   => '05',
      'title' => __( 'Delivery', 'themeflex' ),
      'desc'  => __( 'Contract administration, site inspection, and post-occupancy evaluation ensuring the built work matches the intent.', 'themeflex' ),
    ],
  ];
  ?>
  <section class="arch-section arch-process"
           aria-labelledby="arch-process-h">
    <div class="arch-container">
      <div class="arch-label">
        <span class="arch-label-line" aria-hidden="true"></span>
        <?php esc_html_e( 'How We Work', 'themeflex' ); ?>
      </div>
      <h2 class="arch-h2" id="arch-process-h">
        <?php esc_html_e( 'Design', 'themeflex' ); ?> <em><?php esc_html_e( 'Process', 'themeflex' ); ?></em>
      </h2>

      <div class="arch-process__steps">
        <?php foreach ( $steps as $step ) : ?>
        <div class="arch-process-step">
          <div class="arch-process-step__num" aria-hidden="true">
            <?php echo esc_html( $step['num'] ); ?>
          </div>
          <h3 class="arch-process-step__title"><?php echo esc_html( $step['title'] ); ?></h3>
          <p class="arch-process-step__desc"><?php echo esc_html( $step['desc'] ); ?></p>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // SECTION 8 — COMMISSION FORM
  // ============================================================
  ?>
  <section class="arch-section arch-commission" id="commission"
           aria-labelledby="arch-commission-h">
    <div class="arch-container">
      <div class="arch-commission__inner">

        <!-- Info -->
        <div class="arch-commission__info">
          <div class="arch-label">
            <span class="arch-label-line" aria-hidden="true"></span>
            <?php esc_html_e( 'Start a Conversation', 'themeflex' ); ?>
          </div>
          <h2 class="arch-h2" id="arch-commission-h">
            <?php esc_html_e( 'Commission', 'themeflex' ); ?><br>
            <em><?php esc_html_e( 'Your Project', 'themeflex' ); ?></em>
          </h2>
          <p class="arch-lead">
            <?php esc_html_e( 'Every great building begins with a conversation. Tell us about your site, your programme, and your ambitions — and we will respond within two business days.', 'themeflex' ); ?>
          </p>

          <div class="arch-commission__promise">
            <?php
            $promises = [
              [
                'icon'  => 'calendar',
                'title' => __( 'Free Initial Consultation', 'themeflex' ),
                'desc'  => __( '60-minute discovery call or studio visit at no charge.', 'themeflex' ),
              ],
              [
                'icon'  => 'shield',
                'title' => __( 'NDA on Request', 'themeflex' ),
                'desc'  => __( 'We treat all project briefs as confidential as a matter of policy.', 'themeflex' ),
              ],
              [
                'icon'  => 'clock',
                'title' => __( '48-Hour Response', 'themeflex' ),
                'desc'  => __( 'A partner-level response to every serious enquiry within two business days.', 'themeflex' ),
              ],
              [
                'icon'  => 'file-text',
                'title' => __( 'Fixed-Fee Proposals', 'themeflex' ),
                'desc'  => __( 'Transparent fee proposals before any work begins.', 'themeflex' ),
              ],
            ];
            foreach ( $promises as $p ) :
            ?>
            <div class="arch-promise">
              <div class="arch-promise__icon" aria-hidden="true">
                <?php tf_icon( $p['icon'], 16 ); ?>
              </div>
              <div>
                <div class="arch-promise__title"><?php echo esc_html( $p['title'] ); ?></div>
                <div class="arch-promise__desc"><?php echo esc_html( $p['desc'] ); ?></div>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>

        <!-- Form -->
        <div>
          <form class="arch-form" method="post" novalidate
                aria-label="<?php esc_attr_e( 'Commission enquiry form', 'themeflex' ); ?>">
            <?php wp_nonce_field( 'arch_commission_enquiry', 'arch_commission_nonce' ); ?>

            <div class="arch-form__row">
              <div class="arch-field">
                <label for="arch-first"><?php esc_html_e( 'First Name', 'themeflex' ); ?></label>
                <input type="text" id="arch-first" name="first_name"
                       placeholder="<?php esc_attr_e( 'Lukas', 'themeflex' ); ?>"
                       required autocomplete="given-name">
              </div>
              <div class="arch-field">
                <label for="arch-last"><?php esc_html_e( 'Last Name', 'themeflex' ); ?></label>
                <input type="text" id="arch-last" name="last_name"
                       placeholder="<?php esc_attr_e( 'Bauer', 'themeflex' ); ?>"
                       required autocomplete="family-name">
              </div>
            </div>

            <div class="arch-form__row">
              <div class="arch-field">
                <label for="arch-email"><?php esc_html_e( 'Email Address', 'themeflex' ); ?></label>
                <input type="email" id="arch-email" name="email"
                       placeholder="hello@example.com"
                       required autocomplete="email">
              </div>
              <div class="arch-field">
                <label for="arch-phone"><?php esc_html_e( 'Phone', 'themeflex' ); ?></label>
                <input type="tel" id="arch-phone" name="phone"
                       placeholder="+49 89 123 456"
                       autocomplete="tel">
              </div>
            </div>

            <div class="arch-field">
              <label for="arch-project-type"><?php esc_html_e( 'Project Type', 'themeflex' ); ?></label>
              <select id="arch-project-type" name="project_type">
                <option value="" disabled selected><?php esc_html_e( 'Select project type…', 'themeflex' ); ?></option>
                <?php
                $types = [
                  'residential-private'  => __( 'Private Residence', 'themeflex' ),
                  'residential-multi'    => __( 'Multi-Family / Apartment', 'themeflex' ),
                  'commercial-office'    => __( 'Commercial Office', 'themeflex' ),
                  'hospitality'          => __( 'Hospitality / Hotel', 'themeflex' ),
                  'cultural-civic'       => __( 'Cultural / Civic Building', 'themeflex' ),
                  'mixed-use'            => __( 'Mixed-Use Development', 'themeflex' ),
                  'interior'             => __( 'Interior Design Only', 'themeflex' ),
                  'masterplan'           => __( 'Masterplan / Urban Design', 'themeflex' ),
                ];
                foreach ( $types as $val => $lbl ) :
                ?>
                <option value="<?php echo esc_attr( $val ); ?>">
                  <?php echo esc_html( $lbl ); ?>
                </option>
                <?php endforeach; ?>
              </select>
            </div>

            <div class="arch-field">
              <label><?php esc_html_e( 'Estimated Budget', 'themeflex' ); ?></label>
              <div class="arch-form__budget" role="group"
                   aria-label="<?php esc_attr_e( 'Select budget range', 'themeflex' ); ?>">
                <?php
                $budgets = [
                  'b1' => [ 'val' => 'under-500k',  'label' => 'Under €500K'   ],
                  'b2' => [ 'val' => '500k-2m',     'label' => '€500K – €2M'   ],
                  'b3' => [ 'val' => '2m-10m',      'label' => '€2M – €10M'    ],
                  'b4' => [ 'val' => '10m-50m',     'label' => '€10M – €50M'   ],
                  'b5' => [ 'val' => 'over-50m',    'label' => 'Over €50M'      ],
                  'b6' => [ 'val' => 'to-discuss',  'label' => 'To Discuss'     ],
                ];
                foreach ( $budgets as $id => $b ) :
                ?>
                <input type="radio" class="arch-budget-opt" name="budget"
                       id="arch-<?php echo esc_attr( $id ); ?>"
                       value="<?php echo esc_attr( $b['val'] ); ?>">
                <label for="arch-<?php echo esc_attr( $id ); ?>">
                  <?php echo esc_html( $b['label'] ); ?>
                </label>
                <?php endforeach; ?>
              </div>
            </div>

            <div class="arch-field">
              <label for="arch-location"><?php esc_html_e( 'Project Location', 'themeflex' ); ?></label>
              <input type="text" id="arch-location" name="location"
                     placeholder="<?php esc_attr_e( 'City, Country', 'themeflex' ); ?>">
            </div>

            <div class="arch-field">
              <label for="arch-brief"><?php esc_html_e( 'Project Brief', 'themeflex' ); ?></label>
              <textarea id="arch-brief" name="brief" rows="5"
                        placeholder="<?php esc_attr_e( 'Tell us about your site, programme, timeline, and any specific aspirations or challenges…', 'themeflex' ); ?>"></textarea>
            </div>

            <p class="arch-form__note">
              <?php esc_html_e( 'All enquiries are treated as strictly confidential. We do not share your information with third parties. By submitting this form you agree to be contacted regarding your commission enquiry.', 'themeflex' ); ?>
            </p>

            <div class="arch-form__submit">
              <button type="submit" class="arch-btn arch-btn--primary">
                <?php tf_icon( 'send', 16 ); ?>
                <?php esc_html_e( 'Send Enquiry', 'themeflex' ); ?>
              </button>
              <span style="font-size:.75rem;color:var(--arch-muted);">
                <?php esc_html_e( 'We respond within 48 hrs', 'themeflex' ); ?>
              </span>
            </div>

          </form>
        </div>

      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // SECTION 9 — CTA BANNER
  // ============================================================
  ?>
  <section class="arch-cta" aria-label="<?php esc_attr_e( 'Call to action', 'themeflex' ); ?>">
    <div class="arch-container arch-cta__inner">
      <p class="arch-cta__eyebrow">
        <?php esc_html_e( 'Ready to Build Something Extraordinary?', 'themeflex' ); ?>
      </p>
      <h2 class="arch-cta__h2">
        <?php esc_html_e( 'Let\'s Begin', 'themeflex' ); ?>
      </h2>
      <p class="arch-cta__sub">
        <?php esc_html_e( 'From a single family home to a city-scale masterplan — every Forma Studio project begins with a conversation. Reach out and we\'ll set up your complimentary consultation.', 'themeflex' ); ?>
      </p>
      <div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap;">
        <a href="#commission" class="arch-btn arch-btn--dark">
          <?php tf_icon( 'mail', 18 ); ?>
          <?php esc_html_e( 'Commission a Project', 'themeflex' ); ?>
        </a>
        <a href="tel:+498912345678" class="arch-btn arch-btn--ghost-dark">
          <?php tf_icon( 'phone', 18 ); ?>
          +49 89 1234 5678
        </a>
      </div>
    </div>
  </section>

</main><!-- .tf-arch-page -->

<script>
/* Architecture page — animated stat counters */
(function(){
  'use strict';
  function animateCounter(el){
    const target = parseInt(el.dataset.counter,10);
    const suffix = el.dataset.suffix||'';
    const dur = 1800;
    let start;
    function step(ts){
      if(!start) start=ts;
      const p=Math.min((ts-start)/dur,1);
      const ease=1-Math.pow(1-p,3);
      el.textContent=Math.round(ease*target)+suffix;
      if(p<1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }
  const counters=document.querySelectorAll('.tf-arch-page [data-counter]');
  if(!counters.length) return;
  const obs=new IntersectionObserver(function(entries){
    entries.forEach(function(e){
      if(e.isIntersecting){
        animateCounter(e.target);
        obs.unobserve(e.target);
      }
    });
  },{threshold:0.5});
  counters.forEach(function(c){obs.observe(c);});
})();
</script>

<?php get_footer(); ?>
