<?php
/**
 * Template Name: TF — Automotive Dealership
 *
 * Premium luxury / performance car dealership homepage template.
 * Namespace : --auto-*
 * Fonts     : Barlow Condensed + Inter (Google Fonts)
 * Palette   : carbon #0d0d0d · chrome #d0d4d8 · red #c8202e · slate #3a4550 · silver #f2f4f6
 *
 * @package ThemeFlex
 */

defined('ABSPATH') || exit;

/* ── deterministic randomness ───────────────────────────────────────── */
srand(crc32(get_the_permalink()));

/* ── PHP data ───────────────────────────────────────────────────────── */
$vehicles = [
    ['name'=>'Apex GT-R 550',    'cat'=>'sports',  'year'=>2024,'km'=>0,    'power'=>550,'price'=>'124.900','img_color'=>'#c8202e','body_color'=>'#a81818'],
    ['name'=>'Veloce Turismo S', 'cat'=>'sports',  'year'=>2024,'km'=>0,    'power'=>480,'price'=>'98.500', 'img_color'=>'#1a3a6a','body_color'=>'#0f2a52'],
    ['name'=>'Urban Legend AWD', 'cat'=>'suv',     'year'=>2024,'km'=>0,    'power'=>380,'price'=>'79.900', 'img_color'=>'#3a4550','body_color'=>'#2a3540'],
    ['name'=>'Ranger XL Diesel', 'cat'=>'suv',     'year'=>2023,'km'=>18500,'power'=>240,'price'=>'52.400', 'img_color'=>'#5a6a50','body_color'=>'#3a4a30'],
    ['name'=>'Executive E-400',  'cat'=>'sedan',   'year'=>2024,'km'=>0,    'power'=>400,'price'=>'87.200', 'img_color'=>'#0d0d0d','body_color'=>'#1a1a1a'],
    ['name'=>'Business Class LX','cat'=>'sedan',   'year'=>2023,'km'=>8200, 'power'=>320,'price'=>'64.800', 'img_color'=>'#c8c0b0','body_color'=>'#a8a098'],
];

$brands = ['BMW','Mercedes-Benz','Audi','Porsche','Volkswagen','Lamborghini','Ferrari','McLaren','Bentley','Maserati'];

$services = [
    ['icon'=>'🔧','title'=>__('Workshop & Service','themeflex'),'desc'=>__('Factory-trained technicians. Manufacturer-certified parts. Digital service records synced to your account.','themeflex')],
    ['icon'=>'💳','title'=>__('Finance & Leasing','themeflex'),'desc'=>__('Flexible packages from 0% APR, balloon payments, and long-term lease agreements tailored to you.','themeflex')],
    ['icon'=>'🛡','title'=>__('Warranty & Protection','themeflex'),'desc'=>__('Up to 5-year extended warranty. Comprehensive gap cover, paint protection film and alloy insurance.','themeflex')],
    ['icon'=>'🚗','title'=>__('Trade-In Programme','themeflex'),'desc'=>__('Drive in with your current vehicle. Instant valuation. Seamless handover with no haggling required.','themeflex')],
];

$team = [
    ['name'=>'Marcus Weber',    'role'=>__('Sales Director','themeflex'),    'years'=>14],
    ['name'=>'Julia Hoffmann',  'role'=>__('Finance Advisor','themeflex'),   'years'=>9],
    ['name'=>'Daniel Krause',   'role'=>__('Head of Service','themeflex'),   'years'=>17],
    ['name'=>'Sophia Müller',   'role'=>__('Brand Specialist','themeflex'),  'years'=>6],
];

$testimonials = [
    ['q'=>'Bought my third car from Marcus this year. The team genuinely listen, never pressure, and always deliver exactly what was promised. Outstanding.','n'=>'Klaus B.','loc'=>'Stuttgart'],
    ['q'=>'The test drive experience was like nothing I\'ve had elsewhere. Private road, no time limit, a full tank. They sold the car by just letting it speak.','n'=>'Petra S.','loc'=>'Frankfurt'],
    ['q'=>'Finance arranged in 40 minutes. I picked up my car two days later. Faultless process from enquiry to handover. Will not go anywhere else.','n'=>'André F.','loc'=>'Munich'],
];

$awards = ['Dealer of the Year 2024','5-Star Google Rating','Porsche Centre Certified','BMW Premium Partner','ADAC Top Dealer','Best Finance 2023','TÜV-geprüft','AutoBild Ausgezeichnet'];

/* ── PHP-generated CSS road markings ── */
$dashes = [];
for($i=0;$i<12;$i++){
    $dashes[] = [
        'y'  => 62 + $i * 3.2,
        'op' => rand(15,40)/100,
    ];
}

/* ── PHP-generated star field ── */
$stars = [];
for($i=0;$i<60;$i++){
    $stars[] = [
        'x'  => rand(1,99),
        'y'  => rand(1,55),
        'r'  => rand(1,3)/10+0.5,
        'op' => rand(30,80)/100,
        'del'=> rand(0,3000),
    ];
}

get_header(); ?>
<!-- ================================================================
     GOOGLE FONTS
================================================================ -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@300;400;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
/* ================================================================
   ROOT TOKENS — AUTOMOTIVE
================================================================ */
:root{
  --auto-carbon:  #0d0d0d;
  --auto-chrome:  #d0d4d8;
  --auto-red:     #c8202e;
  --auto-slate:   #3a4550;
  --auto-silver:  #f2f4f6;
  --auto-dark:    #060606;
  --auto-mid:     #1e242c;
  --auto-muted:   #8a9aa8;
  --auto-gold:    #c8a852;
  --auto-ff-cond: 'Barlow Condensed', 'Impact', sans-serif;
  --auto-ff-body: 'Inter', system-ui, sans-serif;
  --auto-r:       4px;
  --auto-trans:   .28s ease;
}

/* ================================================================
   GLOBAL RESET
================================================================ */
.auto-page *{box-sizing:border-box;margin:0;padding:0;}
.auto-page{font-family:var(--auto-ff-body);color:var(--auto-chrome);background:var(--auto-carbon);overflow-x:hidden;}
.auto-container{max-width:1280px;margin:0 auto;padding:0 2rem;}
.auto-section{padding:6rem 0;}
.auto-section--light{background:var(--auto-silver);color:var(--auto-carbon);}
.auto-section--mid{background:var(--auto-mid);}

/* ================================================================
   HERO — full-viewport dark showroom
================================================================ */
.auto-hero{
  min-height:100vh;
  background:radial-gradient(ellipse 80% 60% at 50% 100%,#1e2830 0%,#0d0d0d 65%);
  display:grid;
  grid-template-rows:1fr auto;
  position:relative;
  overflow:hidden;
}
.auto-hero__scene{
  display:grid;
  grid-template-columns:1fr 1fr;
  align-items:center;
  gap:3rem;
  padding:9rem 2rem 2rem;
  max-width:1280px;
  margin:0 auto;
  width:100%;
}

/* ── stars ── */
.auto-star{
  position:absolute;
  border-radius:50%;
  background:#fff;
  animation:auto-twinkle var(--auto-td,2s) ease-in-out infinite;
}
@keyframes auto-twinkle{
  0%,100%{opacity:var(--auto-op,.5);}
  50%{opacity:calc(var(--auto-op,.5)*.3);}
}

/* ── hero copy ── */
.auto-hero__eyebrow{
  display:inline-flex;align-items:center;gap:.8rem;
  font-family:var(--auto-ff-body);font-size:.72rem;font-weight:600;
  letter-spacing:.22em;text-transform:uppercase;color:var(--auto-red);
  margin-bottom:1.4rem;
}
.auto-hero__eyebrow::before{
  content:'';display:inline-block;width:2rem;height:1px;background:var(--auto-red);
}
.auto-hero__h1{
  font-family:var(--auto-ff-cond);font-size:clamp(3.5rem,7vw,7rem);
  font-weight:800;line-height:.95;text-transform:uppercase;letter-spacing:-.01em;
  color:#fff;margin-bottom:1.5rem;
}
.auto-hero__h1 .accent{color:var(--auto-red);}
.auto-hero__lead{
  font-size:1rem;line-height:1.7;color:var(--auto-muted);
  max-width:44ch;margin-bottom:2.5rem;
}
.auto-hero__ctas{display:flex;gap:1rem;flex-wrap:wrap;}
.auto-btn{
  display:inline-flex;align-items:center;gap:.5rem;
  padding:.85rem 2rem;border-radius:var(--auto-r);
  font-family:var(--auto-ff-body);font-size:.88rem;font-weight:600;
  letter-spacing:.04em;text-decoration:none;cursor:pointer;
  border:1.5px solid transparent;transition:var(--auto-trans);
}
.auto-btn--primary{background:var(--auto-red);color:#fff;border-color:var(--auto-red);}
.auto-btn--primary:hover{background:#a81828;border-color:#a81828;transform:translateY(-2px);}
.auto-btn--ghost{border-color:rgba(255,255,255,.25);color:#fff;}
.auto-btn--ghost:hover{border-color:#fff;background:rgba(255,255,255,.06);}

/* ── hero car art ── */
.auto-hero__art{
  position:relative;height:380px;display:flex;align-items:flex-end;justify-content:center;
}

/* Road */
.auto-road{
  position:absolute;bottom:0;left:-10%;right:-10%;height:80px;
  background:linear-gradient(180deg,#1a2028 0%,#121820 100%);
}
.auto-road-line{
  position:absolute;height:4px;left:10%;right:10%;
  background:rgba(255,255,255,.08);border-radius:2px;
}
.auto-road-dash{
  position:absolute;height:3px;background:rgba(255,255,255,.6);border-radius:2px;
}

/* Showroom floor reflection */
.auto-floor-glow{
  position:absolute;bottom:72px;left:50%;transform:translateX(-50%);
  width:480px;height:30px;
  background:radial-gradient(ellipse at 50% 100%,rgba(200,32,46,.18) 0%,transparent 70%);
  filter:blur(4px);
}

/* ── CSS Car ── */
.auto-car{
  position:absolute;bottom:78px;left:50%;transform:translateX(-50%);
  width:380px;height:160px;
}

/* Body shell */
.auto-car__body{
  position:absolute;bottom:30px;left:30px;right:30px;height:80px;
  background:linear-gradient(180deg,var(--auto-body-hi,#d0202e) 0%,var(--auto-body-lo,#901018) 100%);
  border-radius:8px 8px 4px 4px;
}

/* Cabin / greenhouse */
.auto-car__cabin{
  position:absolute;bottom:95px;left:90px;right:100px;height:60px;
  background:linear-gradient(170deg,#2a3038 0%,#1a2028 100%);
  border-radius:18px 14px 0 0;
  clip-path:polygon(8% 100%,0% 0%,100% 0%,92% 100%);
}

/* Windshield */
.auto-car__windshield{
  position:absolute;bottom:100px;left:96px;right:140px;height:50px;
  background:linear-gradient(135deg,rgba(100,160,200,.35) 0%,rgba(40,80,120,.55) 100%);
  border-radius:10px 8px 0 0;
  clip-path:polygon(10% 100%,0% 0%,100% 0%,90% 100%);
  border-top:1px solid rgba(255,255,255,.15);
}

/* Rear window */
.auto-car__rear-window{
  position:absolute;bottom:100px;left:148px;right:98px;height:46px;
  background:linear-gradient(135deg,rgba(60,100,140,.3) 0%,rgba(20,50,80,.5) 100%);
  clip-path:polygon(10% 100%,0% 0%,100% 0%,90% 100%);
  border-top:1px solid rgba(255,255,255,.08);
}

/* A-pillar chrome strip */
.auto-car__pillar{
  position:absolute;bottom:110px;
  width:3px;height:44px;
  background:linear-gradient(180deg,rgba(255,255,255,.3) 0%,transparent 100%);
}
.auto-car__pillar--a{left:96px;transform:skewX(-12deg);}
.auto-car__pillar--c{right:97px;transform:skewX(12deg);}

/* Side body line highlight */
.auto-car__line{
  position:absolute;bottom:90px;left:34px;right:34px;height:1.5px;
  background:linear-gradient(90deg,transparent 0%,rgba(255,255,255,.25) 30%,rgba(255,255,255,.4) 50%,rgba(255,255,255,.15) 80%,transparent 100%);
  border-radius:1px;
}

/* Headlights */
.auto-car__headlight{
  position:absolute;bottom:50px;
  width:36px;height:14px;
  background:linear-gradient(90deg,rgba(255,240,200,.9) 0%,rgba(255,220,100,.6) 100%);
  border-radius:3px;
  box-shadow:0 0 18px 6px rgba(255,230,100,.35),0 0 4px 2px rgba(255,240,200,.5);
}
.auto-car__headlight--f{left:32px;}
.auto-car__headlight--r{right:32px;background:linear-gradient(90deg,rgba(220,50,50,.7) 0%,rgba(255,80,80,.9) 100%);box-shadow:0 0 12px 4px rgba(255,50,50,.3);}

/* DRL strip */
.auto-car__drl{
  position:absolute;bottom:62px;left:36px;width:30px;height:3px;
  background:rgba(255,240,180,.7);border-radius:2px;
  box-shadow:0 0 6px rgba(255,240,180,.5);
}

/* Front grille */
.auto-car__grille{
  position:absolute;bottom:34px;left:34px;
  width:44px;height:22px;
  border:1.5px solid rgba(255,255,255,.2);border-radius:2px;
  background:repeating-linear-gradient(
    90deg,
    rgba(255,255,255,.07) 0,rgba(255,255,255,.07) 3px,
    transparent 3px,transparent 8px
  );
}
.auto-car__grille::before{
  content:'';position:absolute;top:50%;left:0;right:0;height:1px;
  background:rgba(255,255,255,.12);
}

/* Logo badge */
.auto-car__badge{
  position:absolute;bottom:44px;left:54px;
  width:14px;height:14px;
  border:2px solid rgba(255,255,255,.4);
  border-radius:50%;
  background:rgba(255,255,255,.08);
}

/* Hood line */
.auto-car__hood{
  position:absolute;bottom:108px;left:34px;width:80px;height:4px;
  background:linear-gradient(90deg,rgba(255,255,255,.06) 0%,rgba(255,255,255,.18) 100%);
  border-radius:2px;
  clip-path:polygon(0 100%,0 0,100% 0,95% 100%);
}

/* Roof rack / spoiler */
.auto-car__spoiler{
  position:absolute;bottom:154px;right:100px;
  width:50px;height:6px;
  background:linear-gradient(180deg,rgba(255,255,255,.1) 0%,rgba(255,255,255,.04) 100%);
  border-radius:2px;
  border-top:1px solid rgba(255,255,255,.15);
}
.auto-car__spoiler::before,.auto-car__spoiler::after{
  content:'';position:absolute;bottom:0;
  width:4px;height:10px;
  background:rgba(255,255,255,.12);
  border-radius:1px;
}
.auto-car__spoiler::before{left:8px;}
.auto-car__spoiler::after{right:8px;}

/* Wheels */
.auto-wheel{
  position:absolute;bottom:14px;
  width:58px;height:58px;
  border-radius:50%;
  background:radial-gradient(circle at 42% 38%,#3a4048 0%,#1a1e24 60%,#0a0c10 100%);
  border:6px solid #4a5060;
  box-shadow:0 4px 12px rgba(0,0,0,.5),inset 0 1px 3px rgba(255,255,255,.08);
}
.auto-wheel::before{
  content:'';position:absolute;inset:8px;
  border-radius:50%;
  border:2px solid rgba(255,255,255,.12);
}
.auto-wheel--f{left:34px;}
.auto-wheel--r{right:34px;}

/* Tyre sidewall shine */
.auto-wheel::after{
  content:'';position:absolute;top:3px;left:3px;
  width:22px;height:12px;
  background:rgba(255,255,255,.07);
  border-radius:50%;
  transform:rotate(-30deg);
}

/* Ground shadow */
.auto-shadow{
  position:absolute;bottom:10px;left:50%;transform:translateX(-50%);
  width:360px;height:16px;
  background:radial-gradient(ellipse at 50% 50%,rgba(0,0,0,.6) 0%,transparent 70%);
  filter:blur(6px);
}

/* ── Showroom spotlights ── */
.auto-spot{
  position:absolute;top:-20px;
  width:3px;height:340px;
  background:linear-gradient(180deg,rgba(255,255,255,.12) 0%,transparent 100%);
  transform-origin:top;
  pointer-events:none;
}
.auto-spot::after{
  content:'';position:absolute;top:0;left:50%;transform:translateX(-50%);
  width:8px;height:8px;border-radius:50%;
  background:rgba(255,255,255,.6);
  box-shadow:0 0 12px 4px rgba(255,255,255,.3);
}

/* ── Speedometer gauge art ── */
.auto-gauge{
  position:absolute;top:20px;right:20px;
  width:100px;height:100px;
}

/* ── hero stats row ── */
.auto-hero__stats{
  background:rgba(255,255,255,.04);
  border-top:1px solid rgba(255,255,255,.06);
  padding:1.5rem 2rem;
}
.auto-hero__stats-inner{
  max-width:1280px;margin:0 auto;
  display:flex;gap:3rem;flex-wrap:wrap;align-items:center;
}
.auto-hero__stat{display:flex;flex-direction:column;gap:.2rem;}
.auto-hero__stat-num{
  font-family:var(--auto-ff-cond);font-size:1.9rem;font-weight:800;
  color:#fff;letter-spacing:-.01em;
}
.auto-hero__stat-label{
  font-size:.72rem;font-weight:600;letter-spacing:.14em;text-transform:uppercase;
  color:var(--auto-muted);
}

/* ================================================================
   BRANDS MARQUEE
================================================================ */
.auto-marquee-wrap{
  background:#111;border-top:1px solid rgba(255,255,255,.05);
  padding:.85rem 0;overflow:hidden;
}
.auto-marquee-track{
  display:flex;align-items:center;width:max-content;
  animation:auto-marquee 28s linear infinite;
}
.auto-marquee-track:hover{animation-play-state:paused;}
@keyframes auto-marquee{to{transform:translateX(-50%);}}
.auto-marquee-item{
  display:flex;align-items:center;gap:.6rem;padding:0 2.5rem;white-space:nowrap;
  font-family:var(--auto-ff-cond);font-size:1rem;font-weight:700;
  letter-spacing:.14em;text-transform:uppercase;color:rgba(210,212,216,.45);
}
.auto-marquee-item::before{
  content:'◆';font-size:.5rem;color:var(--auto-red);
}

/* ================================================================
   SECTION HEADER
================================================================ */
.auto-section-header{text-align:center;margin-bottom:3.5rem;}
.auto-section-header__label{
  display:inline-flex;align-items:center;gap:.7rem;
  font-size:.72rem;font-weight:600;letter-spacing:.2em;text-transform:uppercase;
  color:var(--auto-red);margin-bottom:.8rem;
}
.auto-section-header__label::before,.auto-section-header__label::after{
  content:'';display:inline-block;width:1.5rem;height:1px;background:var(--auto-red);
}
.auto-section-header__h2{
  font-family:var(--auto-ff-cond);font-size:clamp(2.2rem,4vw,3.5rem);
  font-weight:800;text-transform:uppercase;letter-spacing:.02em;
  color:#fff;margin-bottom:.6rem;
}
.auto-section--light .auto-section-header__h2{color:var(--auto-carbon);}
.auto-section-header__h2 .accent{color:var(--auto-red);}
.auto-section-header__sub{
  font-size:.95rem;line-height:1.75;color:var(--auto-muted);max-width:55ch;margin:0 auto;
}
.auto-section--light .auto-section-header__sub{color:var(--auto-slate);}

/* ================================================================
   VEHICLE INVENTORY
================================================================ */
.auto-filter-bar{
  display:flex;justify-content:center;gap:.5rem;flex-wrap:wrap;margin-bottom:2.5rem;
}
.auto-filter-btn{
  padding:.5rem 1.4rem;border:1px solid rgba(255,255,255,.12);border-radius:var(--auto-r);
  font-family:var(--auto-ff-body);font-size:.8rem;font-weight:600;letter-spacing:.06em;text-transform:uppercase;
  background:transparent;color:var(--auto-muted);cursor:pointer;transition:var(--auto-trans);
}
.auto-filter-btn:hover,.auto-filter-btn.active{
  border-color:var(--auto-red);background:var(--auto-red);color:#fff;
}
.auto-vehicle-grid{
  display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:2rem;
}
.auto-vehicle-grid .hidden{display:none;}
.auto-vehicle-card{
  background:var(--auto-mid);border-radius:8px;overflow:hidden;
  border:1px solid rgba(255,255,255,.07);
  transition:var(--auto-trans);
  position:relative;
}
.auto-vehicle-card:hover{transform:translateY(-4px);border-color:rgba(200,32,46,.3);box-shadow:0 12px 40px rgba(0,0,0,.5);}
.auto-vehicle-card--new::before{
  content:'NEW';position:absolute;top:14px;right:14px;
  font-family:var(--auto-ff-cond);font-size:.7rem;font-weight:800;letter-spacing:.14em;
  padding:.25rem .65rem;background:var(--auto-red);color:#fff;border-radius:2px;
  z-index:1;
}

/* Card art */
.auto-vehicle-art{
  height:200px;display:flex;align-items:flex-end;justify-content:center;
  position:relative;overflow:hidden;padding-bottom:1rem;
}

/* Mini car in card */
.auto-mini-car{
  position:relative;width:220px;height:80px;
}
.auto-mini-body{
  position:absolute;bottom:12px;left:16px;right:16px;height:42px;
  border-radius:4px 4px 2px 2px;
}
.auto-mini-cabin{
  position:absolute;bottom:45px;left:50px;right:55px;height:32px;
  background:rgba(20,30,40,.8);
  clip-path:polygon(8% 100%,0% 0%,100% 0%,92% 100%);
  border-radius:6px 6px 0 0;
}
.auto-mini-wheel{
  position:absolute;bottom:4px;
  width:28px;height:28px;border-radius:50%;
  background:radial-gradient(circle at 40% 35%,#3a4048,#0a0c10);
  border:4px solid #4a5060;
}
.auto-mini-wheel--f{left:18px;}
.auto-mini-wheel--r{right:18px;}
.auto-mini-hl{
  position:absolute;bottom:22px;
  width:18px;height:8px;border-radius:2px;
}
.auto-mini-hl--f{left:18px;background:rgba(255,240,200,.8);box-shadow:0 0 8px rgba(255,230,100,.3);}
.auto-mini-hl--r{right:18px;background:rgba(220,50,50,.8);box-shadow:0 0 6px rgba(220,50,50,.2);}

/* Card body */
.auto-vehicle-body{padding:1.5rem;}
.auto-vehicle-name{
  font-family:var(--auto-ff-cond);font-size:1.4rem;font-weight:800;
  text-transform:uppercase;letter-spacing:.03em;color:#fff;margin-bottom:.3rem;
}
.auto-vehicle-specs{
  display:flex;gap:1.2rem;flex-wrap:wrap;margin-bottom:1rem;
}
.auto-vehicle-spec{
  font-size:.75rem;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:var(--auto-muted);
  display:flex;align-items:center;gap:.3rem;
}
.auto-vehicle-spec::before{
  content:'';display:inline-block;width:3px;height:3px;border-radius:50%;background:var(--auto-red);
}
.auto-vehicle-footer{
  display:flex;align-items:center;justify-content:space-between;
  padding-top:1rem;border-top:1px solid rgba(255,255,255,.07);
}
.auto-vehicle-price{
  font-family:var(--auto-ff-cond);font-size:1.6rem;font-weight:800;color:#fff;
}
.auto-vehicle-price span{font-size:.75rem;font-weight:400;color:var(--auto-muted);}
.auto-vehicle-cta{
  padding:.5rem 1.2rem;background:transparent;border:1px solid var(--auto-red);
  color:var(--auto-red);border-radius:var(--auto-r);
  font-size:.8rem;font-weight:600;letter-spacing:.06em;text-transform:uppercase;
  cursor:pointer;transition:var(--auto-trans);
}
.auto-vehicle-cta:hover{background:var(--auto-red);color:#fff;}

/* ================================================================
   SERVICES
================================================================ */
.auto-services-grid{
  display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:1.5rem;
}
.auto-service-card{
  padding:2rem;border-radius:8px;background:rgba(255,255,255,.03);
  border:1px solid rgba(255,255,255,.06);
  transition:var(--auto-trans);position:relative;overflow:hidden;
}
.auto-service-card::before{
  content:'';position:absolute;top:0;left:0;right:0;height:2px;
  background:var(--auto-red);transform:scaleX(0);transform-origin:left;
  transition:transform .35s ease;
}
.auto-service-card:hover::before{transform:scaleX(1);}
.auto-service-card:hover{background:rgba(255,255,255,.05);}
.auto-service-icon{font-size:2rem;margin-bottom:1rem;display:block;}
.auto-service-title{
  font-family:var(--auto-ff-cond);font-size:1.2rem;font-weight:800;
  text-transform:uppercase;color:#fff;margin-bottom:.6rem;letter-spacing:.03em;
}
.auto-service-desc{font-size:.88rem;line-height:1.7;color:var(--auto-muted);}

/* ================================================================
   STATS
================================================================ */
.auto-stats{background:#080a0c;padding:5rem 0;border-top:1px solid rgba(255,255,255,.04);}
.auto-stats__grid{
  display:grid;grid-template-columns:repeat(4,1fr);gap:2rem;text-align:center;
}
.auto-stat-num{
  font-family:var(--auto-ff-cond);font-size:clamp(3rem,5vw,5rem);
  font-weight:800;color:#fff;letter-spacing:-.02em;display:block;margin-bottom:.3rem;
}
.auto-stat-accent{color:var(--auto-red);}
.auto-stat-label{
  font-size:.72rem;font-weight:600;letter-spacing:.14em;text-transform:uppercase;
  color:var(--auto-muted);
}

/* ================================================================
   TEAM
================================================================ */
.auto-team-grid{
  display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:1.8rem;
}
.auto-team-card{
  background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);
  border-radius:8px;overflow:hidden;text-align:center;transition:var(--auto-trans);
}
.auto-team-card:hover{transform:translateY(-4px);border-color:rgba(200,32,46,.25);}
.auto-team-portrait{
  height:180px;background:var(--auto-mid);
  display:flex;align-items:flex-end;justify-content:center;
}
.auto-team-body{padding:1.2rem 1rem 1.5rem;}
.auto-team-name{
  font-family:var(--auto-ff-cond);font-size:1.15rem;font-weight:800;
  text-transform:uppercase;color:#fff;letter-spacing:.04em;margin-bottom:.2rem;
}
.auto-team-role{
  font-size:.75rem;font-weight:600;letter-spacing:.12em;text-transform:uppercase;
  color:var(--auto-red);margin-bottom:.6rem;
}
.auto-team-years{font-size:.82rem;color:var(--auto-muted);}

/* ================================================================
   TESTIMONIALS
================================================================ */
.auto-testi-grid{
  display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:1.8rem;
}
.auto-testi-card{
  padding:2rem;border-radius:8px;
  background:rgba(255,255,255,.02);
  border-left:3px solid var(--auto-red);
  border-right:1px solid rgba(255,255,255,.05);
  border-top:1px solid rgba(255,255,255,.05);
  border-bottom:1px solid rgba(255,255,255,.05);
  transition:var(--auto-trans);
}
.auto-testi-card:hover{background:rgba(255,255,255,.04);}
.auto-testi-text{
  font-size:.95rem;font-style:italic;line-height:1.75;
  color:rgba(210,212,216,.8);margin-bottom:1.2rem;
}
.auto-testi-author{
  font-family:var(--auto-ff-cond);font-size:1rem;font-weight:700;
  text-transform:uppercase;letter-spacing:.05em;color:#fff;
}
.auto-testi-loc{font-size:.75rem;color:var(--auto-muted);margin-top:.2rem;}

/* ================================================================
   TEST-DRIVE FORM
================================================================ */
.auto-form-section{background:var(--auto-mid);padding:6rem 0;}
.auto-form-inner{
  max-width:820px;margin:0 auto;
  background:rgba(255,255,255,.03);
  border:1px solid rgba(255,255,255,.07);
  border-radius:8px;padding:3rem;
}
.auto-form-title{
  font-family:var(--auto-ff-cond);font-size:2.5rem;font-weight:800;
  text-transform:uppercase;letter-spacing:.03em;color:#fff;margin-bottom:.4rem;
}
.auto-form-subtitle{font-size:.9rem;color:var(--auto-muted);margin-bottom:2.5rem;}
.auto-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:1rem;}
.auto-fg{display:flex;flex-direction:column;gap:.35rem;}
.auto-fg--full{grid-column:1/-1;}
.auto-label{
  font-size:.72rem;font-weight:600;letter-spacing:.12em;text-transform:uppercase;
  color:rgba(210,212,216,.55);
}
.auto-input,.auto-select,.auto-textarea{
  padding:.82rem 1rem;border-radius:var(--auto-r);
  border:1px solid rgba(255,255,255,.1);
  background:rgba(255,255,255,.05);color:#fff;
  font-family:var(--auto-ff-body);font-size:.9rem;
  transition:var(--auto-trans);
}
.auto-input::placeholder,.auto-textarea::placeholder{color:rgba(210,212,216,.25);}
.auto-input:focus,.auto-select:focus,.auto-textarea:focus{
  outline:none;border-color:var(--auto-red);background:rgba(255,255,255,.08);
}
.auto-select option{background:#1e242c;color:#fff;}
.auto-consent{
  display:flex;align-items:flex-start;gap:.7rem;
  font-size:.83rem;color:rgba(210,212,216,.5);line-height:1.5;
}
.auto-consent input{margin-top:.2rem;accent-color:var(--auto-red);}
.auto-submit{
  padding:1rem 2.8rem;background:var(--auto-red);color:#fff;
  border:none;border-radius:var(--auto-r);
  font-family:var(--auto-ff-cond);font-size:1.1rem;font-weight:800;
  letter-spacing:.08em;text-transform:uppercase;
  cursor:pointer;transition:var(--auto-trans);margin-top:.8rem;
}
.auto-submit:hover{background:#a81828;transform:translateY(-2px);}

/* ================================================================
   SCROLL REVEAL
================================================================ */
.auto-reveal{opacity:0;transform:translateY(24px);transition:opacity .65s ease,transform .65s ease;}
.auto-reveal.visible{opacity:1;transform:none;}

/* ================================================================
   RESPONSIVE
================================================================ */
@media(max-width:960px){
  .auto-hero__scene{grid-template-columns:1fr;padding:8rem 1.5rem 2rem;}
  .auto-hero__art{height:300px;margin:0 auto;max-width:480px;width:100%;}
  .auto-stats__grid{grid-template-columns:repeat(2,1fr);}
  .auto-form-grid{grid-template-columns:1fr;}
}
@media(max-width:600px){
  .auto-section{padding:4rem 0;}
  .auto-hero__stats-inner{gap:1.5rem;}
  .auto-stats__grid{grid-template-columns:1fr 1fr;}
  .auto-form-inner{padding:2rem 1.2rem;}
}
</style>

<!-- ================================================================
     PAGE WRAPPER
================================================================ -->
<div class="auto-page">

<!-- ================================================================
     HERO
================================================================ -->
<section class="auto-hero" aria-label="<?php esc_attr_e('Premium Car Dealership','themeflex'); ?>">

  <!-- Star field -->
  <?php foreach($stars as $s): ?>
  <div class="auto-star" style="
    left:<?php echo $s['x']; ?>%;
    top:<?php echo $s['y']; ?>%;
    width:<?php echo $s['r']*2; ?>px;
    height:<?php echo $s['r']*2; ?>px;
    --auto-op:<?php echo $s['op']; ?>;
    --auto-td:<?php echo rand(15,35)/10; ?>s;
    animation-delay:<?php echo $s['del']; ?>ms;
  " aria-hidden="true"></div>
  <?php endforeach; ?>

  <!-- Spotlights -->
  <?php for($i=0;$i<4;$i++): ?>
  <div class="auto-spot" style="
    left:<?php echo [22,36,58,76][$i]; ?>%;
    transform:rotate(<?php echo [-8,-3,3,9][$i]; ?>deg);
    opacity:<?php echo [.5,.35,.35,.5][$i]; ?>;
  " aria-hidden="true"></div>
  <?php endfor; ?>

  <div class="auto-hero__scene">
    <!-- Copy -->
    <div class="auto-hero__copy">
      <p class="auto-hero__eyebrow"><?php esc_html_e('Munich\'s Premier Showroom','themeflex'); ?></p>
      <h1 class="auto-hero__h1">
        <?php esc_html_e('Drive the','themeflex'); ?><br>
        <span class="accent"><?php esc_html_e('Extraordinary','themeflex'); ?></span>
      </h1>
      <p class="auto-hero__lead">
        <?php esc_html_e('Curated performance and luxury vehicles. Transparent pricing. Tailored finance. An experience worthy of the car you deserve.','themeflex'); ?>
      </p>
      <div class="auto-hero__ctas">
        <a href="#inventory" class="auto-btn auto-btn--primary"><?php esc_html_e('View Inventory','themeflex'); ?></a>
        <a href="#test-drive" class="auto-btn auto-btn--ghost"><?php esc_html_e('Book Test Drive','themeflex'); ?></a>
      </div>
    </div>

    <!-- CSS Car Scene -->
    <div class="auto-hero__art" aria-hidden="true">
      <!-- Road -->
      <div class="auto-road">
        <div class="auto-road-line" style="bottom:40px;"></div>
        <?php foreach($dashes as $d): ?>
        <div class="auto-road-dash" style="
          bottom:<?php echo $d['y']; ?>%;
          left:<?php echo rand(5,50); ?>%;
          width:<?php echo rand(20,60); ?>px;
          opacity:<?php echo $d['op']; ?>;
        "></div>
        <?php endforeach; ?>
      </div>

      <!-- Floor glow -->
      <div class="auto-floor-glow"></div>

      <!-- Car -->
      <div class="auto-car">
        <!-- Body -->
        <div class="auto-car__body"></div>
        <!-- Cabin -->
        <div class="auto-car__cabin"></div>
        <!-- Windshield -->
        <div class="auto-car__windshield"></div>
        <!-- Rear window -->
        <div class="auto-car__rear-window"></div>
        <!-- A/C pillars -->
        <div class="auto-car__pillar auto-car__pillar--a"></div>
        <div class="auto-car__pillar auto-car__pillar--c"></div>
        <!-- Body line -->
        <div class="auto-car__line"></div>
        <!-- Hood -->
        <div class="auto-car__hood"></div>
        <!-- Headlights -->
        <div class="auto-car__headlight auto-car__headlight--f"></div>
        <div class="auto-car__headlight auto-car__headlight--r"></div>
        <div class="auto-car__drl"></div>
        <!-- Grille + badge -->
        <div class="auto-car__grille"></div>
        <div class="auto-car__badge"></div>
        <!-- Spoiler -->
        <div class="auto-car__spoiler"></div>
        <!-- Wheels -->
        <div class="auto-wheel auto-wheel--f"></div>
        <div class="auto-wheel auto-wheel--r"></div>
        <!-- Shadow -->
        <div class="auto-shadow"></div>
      </div>

      <!-- Speedometer SVG -->
      <svg class="auto-gauge" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
        <circle cx="50" cy="50" r="44" fill="#0d0d12" stroke="rgba(255,255,255,.06)" stroke-width="2"/>
        <path d="M14 72 A40 40 0 0 1 86 72" fill="none" stroke="rgba(255,255,255,.08)" stroke-width="4" stroke-linecap="round"/>
        <path d="M14 72 A40 40 0 0 1 72 20" fill="none" stroke="var(--auto-red)" stroke-width="4" stroke-linecap="round" stroke-dasharray="95 200"/>
        <text x="50" y="62" text-anchor="middle" font-family="Barlow Condensed,sans-serif" font-size="14" font-weight="800" fill="white">550</text>
        <text x="50" y="72" text-anchor="middle" font-family="Inter,sans-serif" font-size="6" fill="rgba(210,212,216,.5)">KM/H</text>
        <line x1="50" y1="50" x2="28" y2="30" stroke="var(--auto-red)" stroke-width="2" stroke-linecap="round"/>
        <circle cx="50" cy="50" r="4" fill="#fff"/>
      </svg>
    </div>
  </div>

  <!-- Stats ribbon -->
  <div class="auto-hero__stats">
    <div class="auto-hero__stats-inner">
      <?php
      $hstats = [
        ['num'=>'320+','lbl'=>__('Vehicles in Stock','themeflex')],
        ['num'=>'0%',  'lbl'=>__('Finance Available','themeflex')],
        ['num'=>'18yrs','lbl'=>__('In Business','themeflex')],
        ['num'=>'4.9★','lbl'=>__('Google Rating','themeflex')],
      ];
      foreach($hstats as $hs): ?>
      <div class="auto-hero__stat">
        <span class="auto-hero__stat-num"><?php echo esc_html($hs['num']); ?></span>
        <span class="auto-hero__stat-label"><?php echo esc_html($hs['lbl']); ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ================================================================
     BRANDS MARQUEE
================================================================ -->
<div class="auto-marquee-wrap" aria-label="<?php esc_attr_e('Brands we carry','themeflex'); ?>">
  <div class="auto-marquee-track" aria-hidden="true">
    <?php foreach(array_merge($brands,$brands) as $b): ?>
    <span class="auto-marquee-item"><?php echo esc_html($b); ?></span>
    <?php endforeach; ?>
  </div>
</div>

<!-- ================================================================
     INVENTORY
================================================================ -->
<section id="inventory" class="auto-section">
  <div class="auto-container">
    <div class="auto-section-header auto-reveal">
      <p class="auto-section-header__label"><?php esc_html_e('Current Stock','themeflex'); ?></p>
      <h2 class="auto-section-header__h2"><?php esc_html_e('Our','themeflex'); ?> <span class="accent"><?php esc_html_e('Inventory','themeflex'); ?></span></h2>
      <p class="auto-section-header__sub"><?php esc_html_e('Handpicked, fully inspected, transparently priced. Every vehicle backed by our 5-year warranty programme.','themeflex'); ?></p>
    </div>

    <div class="auto-filter-bar" role="group" aria-label="<?php esc_attr_e('Filter by type','themeflex'); ?>">
      <button class="auto-filter-btn active" data-filter="all" aria-pressed="true"><?php esc_html_e('All','themeflex'); ?></button>
      <button class="auto-filter-btn" data-filter="sports" aria-pressed="false"><?php esc_html_e('Sports','themeflex'); ?></button>
      <button class="auto-filter-btn" data-filter="suv" aria-pressed="false"><?php esc_html_e('SUV','themeflex'); ?></button>
      <button class="auto-filter-btn" data-filter="sedan" aria-pressed="false"><?php esc_html_e('Sedan','themeflex'); ?></button>
    </div>

    <div class="auto-vehicle-grid">
      <?php foreach($vehicles as $v):
        $new = $v['km']===0;
        $bg_hi = $v['img_color'];
        $bg_lo = $v['body_color'];
        $car_cls = $new ? 'auto-vehicle-card--new' : '';
        $bg_grad = "background:radial-gradient(ellipse 80% 60% at 50% 80%,{$bg_hi}22 0%,{$bg_lo}11 60%,transparent 100%)";
      ?>
      <article class="auto-vehicle-card <?php echo esc_attr($car_cls); ?> auto-reveal" data-cat="<?php echo esc_attr($v['cat']); ?>">
        <div class="auto-vehicle-art" style="<?php echo esc_attr($bg_grad); ?>">
          <!-- Mini car -->
          <div class="auto-mini-car">
            <div class="auto-mini-body" style="background:linear-gradient(180deg,<?php echo esc_attr($bg_hi); ?> 0%,<?php echo esc_attr($bg_lo); ?> 100%);"></div>
            <div class="auto-mini-cabin"></div>
            <div class="auto-mini-wheel auto-mini-wheel--f"></div>
            <div class="auto-mini-wheel auto-mini-wheel--r"></div>
            <div class="auto-mini-hl auto-mini-hl--f"></div>
            <div class="auto-mini-hl auto-mini-hl--r"></div>
          </div>
        </div>
        <div class="auto-vehicle-body">
          <div class="auto-vehicle-name"><?php echo esc_html($v['name']); ?></div>
          <div class="auto-vehicle-specs">
            <span class="auto-vehicle-spec"><?php echo esc_html($v['year']); ?></span>
            <span class="auto-vehicle-spec"><?php echo $v['km'] > 0 ? esc_html(number_format($v['km'],0,',','.').' km') : esc_html__('New','themeflex'); ?></span>
            <span class="auto-vehicle-spec"><?php echo esc_html($v['power']); ?> <?php esc_html_e('HP','themeflex'); ?></span>
          </div>
          <div class="auto-vehicle-footer">
            <div class="auto-vehicle-price">€ <?php echo esc_html($v['price']); ?> <span>inkl. MwSt.</span></div>
            <button class="auto-vehicle-cta" type="button"><?php esc_html_e('Details','themeflex'); ?></button>
          </div>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ================================================================
     SERVICES
================================================================ -->
<section class="auto-section auto-section--mid">
  <div class="auto-container">
    <div class="auto-section-header auto-reveal">
      <p class="auto-section-header__label"><?php esc_html_e('Full Service','themeflex'); ?></p>
      <h2 class="auto-section-header__h2"><?php esc_html_e('Beyond the','themeflex'); ?> <span class="accent"><?php esc_html_e('Sale','themeflex'); ?></span></h2>
      <p class="auto-section-header__sub"><?php esc_html_e('Our relationship starts when you collect your car, not when you pay for it. We\'re here for the lifetime of your vehicle.','themeflex'); ?></p>
    </div>
    <div class="auto-services-grid">
      <?php foreach($services as $s): ?>
      <div class="auto-service-card auto-reveal">
        <span class="auto-service-icon" aria-hidden="true"><?php echo $s['icon']; ?></span>
        <div class="auto-service-title"><?php echo esc_html($s['title']); ?></div>
        <p class="auto-service-desc"><?php echo esc_html($s['desc']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ================================================================
     STATS
================================================================ -->
<section class="auto-stats" aria-label="<?php esc_attr_e('Dealership stats','themeflex'); ?>">
  <div class="auto-container">
    <div class="auto-stats__grid">
      <?php
      $stats = [
        ['val'=>4200,'suf'=>'+','lbl'=>__('Happy Customers','themeflex')],
        ['val'=>320, 'suf'=>'+','lbl'=>__('Cars in Stock','themeflex')],
        ['val'=>18,  'suf'=>'yrs','lbl'=>__('In Business','themeflex')],
        ['val'=>99,  'suf'=>'%','lbl'=>__('Recommend Us','themeflex')],
      ];
      foreach($stats as $s): ?>
      <div class="auto-reveal" style="text-align:center;">
        <span class="auto-stat-num" data-target="<?php echo $s['val']; ?>" data-suffix="<?php echo esc_attr($s['suf']); ?>">0</span>
        <span class="auto-stat-label"><?php echo esc_html($s['lbl']); ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ================================================================
     TEAM
================================================================ -->
<section class="auto-section auto-section--mid">
  <div class="auto-container">
    <div class="auto-section-header auto-reveal">
      <p class="auto-section-header__label"><?php esc_html_e('Expert Team','themeflex'); ?></p>
      <h2 class="auto-section-header__h2"><?php esc_html_e('People Who','themeflex'); ?> <span class="accent"><?php esc_html_e('Know Cars','themeflex'); ?></span></h2>
    </div>
    <div class="auto-team-grid">
      <?php foreach($team as $i => $m):
        $suit_colors = ['#2a3a4a','#1a2a3a','#2a2a3a','#1a3a2a'];
        $sc = $suit_colors[$i % count($suit_colors)];
      ?>
      <div class="auto-team-card auto-reveal">
        <div class="auto-team-portrait">
          <svg width="120" height="160" viewBox="0 0 120 160" xmlns="http://www.w3.org/2000/svg" aria-label="<?php echo esc_attr($m['name']); ?>">
            <!-- Suit body -->
            <rect x="28" y="90" width="64" height="70" rx="4" fill="<?php echo esc_attr($sc); ?>"/>
            <!-- Shirt -->
            <rect x="48" y="90" width="24" height="45" rx="1" fill="#e8e0d0"/>
            <!-- Tie -->
            <polygon points="57,92 63,92 65,125 60,130 55,125" fill="<?php echo esc_attr($sc === '#2a3a4a' ? '#c8202e' : '#a81828'); ?>"/>
            <!-- Lapels -->
            <polygon points="48,90 28,110 48,120" fill="<?php echo esc_attr($sc); ?>" opacity=".85"/>
            <polygon points="72,90 92,110 72,120" fill="<?php echo esc_attr($sc); ?>" opacity=".85"/>
            <!-- Arms -->
            <rect x="10" y="90" width="20" height="52" rx="6" fill="<?php echo esc_attr($sc); ?>"/>
            <rect x="90" y="90" width="20" height="52" rx="6" fill="<?php echo esc_attr($sc); ?>"/>
            <!-- Hands -->
            <ellipse cx="20" cy="146" rx="9" ry="7" fill="#c8956a"/>
            <ellipse cx="100" cy="146" rx="9" ry="7" fill="#c8956a"/>
            <!-- Head -->
            <ellipse cx="60" cy="60" rx="26" ry="28" fill="#c8956a"/>
            <!-- Hair -->
            <ellipse cx="60" cy="38" rx="26" ry="12" fill="<?php echo ($i%2===0)?'#1a0c06':'#5a3a20'; ?>"/>
            <!-- Eyes -->
            <ellipse cx="51" cy="57" rx="3" ry="3.5" fill="#3a2010"/>
            <ellipse cx="69" cy="57" rx="3" ry="3.5" fill="#3a2010"/>
            <!-- Smile -->
            <path d="M50 70 Q60 77 70 70" fill="none" stroke="#8a5030" stroke-width="1.8" stroke-linecap="round"/>
            <?php if($i % 2 === 1): ?>
            <!-- Glasses -->
            <rect x="43" y="53" width="14" height="10" rx="4" fill="none" stroke="#888" stroke-width="1.5"/>
            <rect x="63" y="53" width="14" height="10" rx="4" fill="none" stroke="#888" stroke-width="1.5"/>
            <line x1="57" y1="58" x2="63" y2="58" stroke="#888" stroke-width="1.5"/>
            <?php endif; ?>
          </svg>
        </div>
        <div class="auto-team-body">
          <div class="auto-team-name"><?php echo esc_html($m['name']); ?></div>
          <div class="auto-team-role"><?php echo esc_html($m['role']); ?></div>
          <div class="auto-team-years"><?php printf(esc_html__('%d years experience','themeflex'),$m['years']); ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ================================================================
     TESTIMONIALS
================================================================ -->
<section class="auto-section">
  <div class="auto-container">
    <div class="auto-section-header auto-reveal">
      <p class="auto-section-header__label"><?php esc_html_e('Customer Stories','themeflex'); ?></p>
      <h2 class="auto-section-header__h2"><?php esc_html_e('Real','themeflex'); ?> <span class="accent"><?php esc_html_e('Reviews','themeflex'); ?></span></h2>
    </div>
    <div class="auto-testi-grid">
      <?php foreach($testimonials as $t): ?>
      <div class="auto-testi-card auto-reveal">
        <p class="auto-testi-text">&ldquo;<?php echo esc_html($t['q']); ?>&rdquo;</p>
        <div class="auto-testi-author"><?php echo esc_html($t['n']); ?></div>
        <div class="auto-testi-loc"><?php echo esc_html($t['loc']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ================================================================
     TEST-DRIVE FORM
================================================================ -->
<div id="test-drive" class="auto-form-section">
  <div class="auto-container">
    <div class="auto-form-inner auto-reveal">
      <h2 class="auto-form-title"><?php esc_html_e('Book a Test Drive','themeflex'); ?></h2>
      <p class="auto-form-subtitle"><?php esc_html_e('Private road. Full tank. No time pressure. Experience the car the way it was meant to be driven.','themeflex'); ?></p>

      <form method="post" action="" class="auto-form-grid" novalidate>
        <?php wp_nonce_field('tf_auto_testdrive','tf_auto_nonce'); ?>

        <div class="auto-fg">
          <label class="auto-label" for="auto-fname"><?php esc_html_e('First Name','themeflex'); ?></label>
          <input class="auto-input" type="text" id="auto-fname" name="auto_fname" placeholder="<?php esc_attr_e('Marcus','themeflex'); ?>" required>
        </div>
        <div class="auto-fg">
          <label class="auto-label" for="auto-lname"><?php esc_html_e('Last Name','themeflex'); ?></label>
          <input class="auto-input" type="text" id="auto-lname" name="auto_lname" placeholder="<?php esc_attr_e('Weber','themeflex'); ?>" required>
        </div>
        <div class="auto-fg">
          <label class="auto-label" for="auto-email"><?php esc_html_e('Email','themeflex'); ?></label>
          <input class="auto-input" type="email" id="auto-email" name="auto_email" placeholder="<?php esc_attr_e('marcus@example.com','themeflex'); ?>" required>
        </div>
        <div class="auto-fg">
          <label class="auto-label" for="auto-phone"><?php esc_html_e('Phone','themeflex'); ?></label>
          <input class="auto-input" type="tel" id="auto-phone" name="auto_phone" placeholder="<?php esc_attr_e('+49 89 …','themeflex'); ?>">
        </div>
        <div class="auto-fg auto-fg--full">
          <label class="auto-label" for="auto-vehicle"><?php esc_html_e('Vehicle of Interest','themeflex'); ?></label>
          <select class="auto-select" id="auto-vehicle" name="auto_vehicle">
            <option value=""><?php esc_html_e('Choose a vehicle…','themeflex'); ?></option>
            <?php foreach($vehicles as $v): ?>
            <option value="<?php echo esc_attr($v['name']); ?>"><?php echo esc_html($v['name'].' ('.$v['year'].') — €'.$v['price']); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="auto-fg">
          <label class="auto-label" for="auto-date"><?php esc_html_e('Preferred Date','themeflex'); ?></label>
          <input class="auto-input" type="date" id="auto-date" name="auto_date">
        </div>
        <div class="auto-fg">
          <label class="auto-label" for="auto-time"><?php esc_html_e('Preferred Time','themeflex'); ?></label>
          <select class="auto-select" id="auto-time" name="auto_time">
            <option value=""><?php esc_html_e('Choose a time…','themeflex'); ?></option>
            <?php foreach(['09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00'] as $t): ?>
            <option value="<?php echo esc_attr($t); ?>"><?php echo esc_html($t); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="auto-fg auto-fg--full">
          <label class="auto-label" for="auto-finance"><?php esc_html_e('Finance Interest','themeflex'); ?></label>
          <select class="auto-select" id="auto-finance" name="auto_finance">
            <option value="none"><?php esc_html_e('No finance needed — cash purchase','themeflex'); ?></option>
            <option value="hp"><?php esc_html_e('Hire Purchase','themeflex'); ?></option>
            <option value="pcp"><?php esc_html_e('PCP / Balloon Finance','themeflex'); ?></option>
            <option value="lease"><?php esc_html_e('Long-Term Lease','themeflex'); ?></option>
          </select>
        </div>
        <div class="auto-fg auto-fg--full">
          <label class="auto-label" for="auto-notes"><?php esc_html_e('Additional Notes','themeflex'); ?></label>
          <textarea class="auto-textarea" id="auto-notes" name="auto_notes" rows="3" placeholder="<?php esc_attr_e('Trade-in? Specific colour preferences? Questions?','themeflex'); ?>"></textarea>
        </div>
        <div class="auto-fg auto-fg--full">
          <label class="auto-consent">
            <input type="checkbox" name="auto_consent" required>
            <?php esc_html_e('I agree to being contacted regarding my test drive enquiry. Data used solely for this purpose.','themeflex'); ?>
          </label>
        </div>
        <div class="auto-fg auto-fg--full">
          <button type="submit" class="auto-submit"><?php esc_html_e('Request Test Drive','themeflex'); ?></button>
        </div>
      </form>
    </div>
  </div>
</div>

</div><!-- /auto-page -->

<!-- ================================================================
     JAVASCRIPT
================================================================ -->
<script>
(function(){
  'use strict';

  /* ── Scroll reveal ── */
  const rev = document.querySelectorAll('.auto-reveal');
  const obs = new IntersectionObserver(es=>{
    es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');obs.unobserve(e.target);}});
  },{threshold:.1,rootMargin:'0px 0px -40px 0px'});
  rev.forEach(el=>obs.observe(el));

  /* ── Counters ── */
  const easeOut = t=>1-Math.pow(1-t,3);
  const counters = document.querySelectorAll('.auto-stat-num[data-target]');
  const cObs = new IntersectionObserver(es=>{
    es.forEach(e=>{
      if(!e.isIntersecting) return;
      const el=e.target, end=+el.dataset.target, suf=el.dataset.suffix||'';
      const dur=1800, t0=performance.now();
      (function tick(now){
        const p=Math.min((now-t0)/dur,1);
        el.textContent=Math.round(easeOut(p)*end)+suf;
        if(p<1)requestAnimationFrame(tick);
        else el.textContent=end+suf;
      })(t0);
      cObs.unobserve(el);
    });
  },{threshold:.5});
  counters.forEach(el=>cObs.observe(el));

  /* ── Inventory filter ── */
  const btns = document.querySelectorAll('.auto-filter-btn');
  const cards = document.querySelectorAll('.auto-vehicle-card');
  btns.forEach(btn=>{
    btn.addEventListener('click',()=>{
      btns.forEach(b=>{b.classList.remove('active');b.setAttribute('aria-pressed','false');});
      btn.classList.add('active');btn.setAttribute('aria-pressed','true');
      const f=btn.dataset.filter;
      cards.forEach(c=>c.classList.toggle('hidden',f!=='all'&&c.dataset.cat!==f));
    });
  });

  /* ── Vehicle card detail button feedback ── */
  document.querySelectorAll('.auto-vehicle-cta').forEach(btn=>{
    btn.addEventListener('click',()=>{
      const orig=btn.textContent;
      btn.textContent='→ Enquiry';
      setTimeout(()=>{btn.textContent=orig;},2000);
    });
  });

})();
</script>

<?php get_footer(); ?>
