<?php
/**
 * Template Name: TF — Artisan Bakery & Café
 * Description:   Full-page premium template for artisan bakeries and neighbourhood cafés.
 *                CSS bakery shopfront at dawn hero, illustrated loaves, product grid,
 *                seasonal specials, about story, team, testimonials, FAQ, order form.
 * Version:       1.0.0
 */
defined('ABSPATH') || exit;

/* ── Seeded randomness ───────────────────────────────────────────── */
srand(crc32(get_the_permalink()));

/* ── Steam wisps data ─────────────────────────────────────────────── */
$steam_wisps = [];
for ($i = 0; $i < 12; $i++) {
    $steam_wisps[] = [
        'x'     => rand(5, 90),
        'delay' => rand(0, 40) / 10,
        'dur'   => 3 + rand(0, 20) / 10,
        'size'  => rand(6, 14),
    ];
}

/* ── Bread loaves for hero display shelf ─────────────────────────── */
$bak_loaves = [
    ['w'=>52,'h'=>38,'col'=>'#8a4a20','top_col'=>'#6a3010','label'=>'Sourdough','crack'=>true,'seeds'=>false,'oval'=>false],
    ['w'=>44,'h'=>50,'col'=>'#c8702a','top_col'=>'#a05018','label'=>'Baguette','crack'=>false,'seeds'=>false,'oval'=>false,'baguette'=>true],
    ['w'=>58,'h'=>42,'col'=>'#7a3a18','top_col'=>'#5a2808','label'=>'Rye Loaf','crack'=>true,'seeds'=>true,'oval'=>false],
    ['w'=>48,'h'=>36,'col'=>'#d4841e','top_col'=>'#b06010','label'=>'Brioche','crack'=>false,'seeds'=>false,'oval'=>true],
    ['w'=>54,'h'=>44,'col'=>'#9a5228','top_col'=>'#7a3a14','label'=>'Multigrain','crack'=>false,'seeds'=>true,'oval'=>false],
    ['w'=>40,'h'=>60,'col'=>'#c26020','top_col'=>'#9a4010','label'=>'Pain de Campagne','crack'=>true,'seeds'=>false,'oval'=>false],
];

/* ── Pastry items for pastry case ────────────────────────────────── */
$pastries = [
    ['name'=>'Almond Croissant',    'price'=>'£3.50','col'=>'#d4a050','shape'=>'crescent', 'desc'=>'Flaky all-butter pastry filled with frangipane and toasted almonds'],
    ['name'=>'Pain au Chocolat',    'price'=>'£3.20','col'=>'#b8782a','shape'=>'rectangle','desc'=>'Two batons of dark Valrhona chocolate in laminated dough'],
    ['name'=>'Kouign-Amann',        'price'=>'£4.00','col'=>'#c87830','shape'=>'round',    'desc'=>'Caramelised Breton pastry — crisp, layered and deeply buttery'],
    ['name'=>'Lemon Tart',          'price'=>'£4.50','col'=>'#e8d060','shape'=>'tart',     'desc'=>'Sharp lemon curd in a crisp shortcrust shell, glazed to a shine'],
    ['name'=>'Cannelé Bordelais',   'price'=>'£2.80','col'=>'#7a3a10','shape'=>'cannele',  'desc'=>'Dark lacquered shell with a custardy, rum-scented centre'],
    ['name'=>'Seasonal Danish',     'price'=>'£4.20','col'=>'#e8a050','shape'=>'danish',   'desc'=>'Laminated pastry with seasonal fruit compote and vanilla custard'],
];

/* ── Bread categories / product range ────────────────────────────── */
$bread_range = [
    [
        'cat'  => 'Sourdough',
        'icon' => '🌾',
        'desc' => 'Our sourdough loaves are cold-proofed overnight for a complex, open crumb and signature tang.',
        'items'=> ['Classic White Sourdough — £6.50','Whole Wheat &amp; Honey — £6.80','Dark Rye &amp; Caraway — £7.00','Olive &amp; Rosemary — £7.20'],
    ],
    [
        'cat'  => 'French Classics',
        'icon' => '🥐',
        'desc' => 'Hand-rolled each morning using 48-hour laminated dough and AOP Charentes butter.',
        'items'=> ['Classic Croissant — £2.80','Almond Croissant — £3.50','Pain au Chocolat — £3.20','Kouign-Amann — £4.00'],
    ],
    [
        'cat'  => 'Baguettes',
        'icon' => '🥖',
        'desc' => 'Baked twice daily using Type 55 flour, fermented long and slow for authentic flavour.',
        'items'=> ['Tradition Baguette — £2.20','Seeded Baguette — £2.40','Olive Baguette — £2.80','Walnut &amp; Raisin — £3.00'],
    ],
    [
        'cat'  => 'Celebration Cakes',
        'icon' => '🎂',
        'desc' => 'Bespoke layer cakes, tarts and gâteaux crafted to order for any occasion.',
        'items'=> ['Victoria Sponge — from £28','Lemon Drizzle — from £30','Chocolate Fondant Tart — from £35','Custom Celebration — POA'],
    ],
    [
        'cat'  => 'Café',
        'icon' => '☕',
        'desc' => 'Single-origin Monmouth beans, brewed to order. Served with a house-made biscuit.',
        'items'=> ['Flat White — £3.20','Oat Cortado — £3.40','Filter (seasonal) — £2.80','Hot Chocolate — £3.80'],
    ],
    [
        'cat'  => 'Seasonal Specials',
        'icon' => '🌸',
        'desc' => 'Our specials board changes weekly with whatever is best from the market.',
        'items'=> ['Ask in-store or check Instagram','@sevengrainsartisan','New items every Friday morning','Sign up for the weekly newsletter'],
    ],
];

/* ── Team members ─────────────────────────────────────────────────── */
$team = [
    [
        'name'   => 'Émile Fontaine',
        'role'   => 'Head Baker & Co-founder',
        'origin' => 'Trained in Lyon & Paris',
        'bio'    => 'Émile spent twelve years in Michelin-starred kitchens before returning to his first love — bread. He mixes, shapes and bakes every loaf personally.',
        'skin'   => '#d4a870',
        'hair'   => '#3a2010',
        'top'    => '#fff',
        'apron'  => '#e8e0d0',
    ],
    [
        'name'   => 'Clara Fontaine',
        'role'   => 'Pâtissière & Co-founder',
        'origin' => 'Trained in Lyon & London',
        'bio'    => 'Clara leads the patisserie counter with Cordon Bleu precision and a keen eye for seasonal beauty. Her tarts and Danishes sell out before 09:00.',
        'skin'   => '#e0b880',
        'hair'   => '#5a3018',
        'top'    => '#fff',
        'apron'  => '#e8e0d0',
    ],
    [
        'name'   => 'Tom Okafor',
        'role'   => 'Café Manager',
        'origin' => 'SCA-certified Barista',
        'bio'    => 'Tom curates our seasonal coffee menu and trains the floor team. He sources two to three single-origin beans each quarter and talks about coffee with infectious enthusiasm.',
        'skin'   => '#8a5030',
        'hair'   => '#1a0a00',
        'top'    => '#2a4a6a',
        'apron'  => '#1a3a5a',
    ],
];

/* ── Testimonials ─────────────────────────────────────────────────── */
$testimonials = [
    [
        'name'  => 'Laura B.',
        'loc'   => 'Regular customer since 2019',
        'quote' => 'Seven Grains ruined me for any other sourdough. The dark rye is extraordinary — I genuinely plan my Saturday morning around picking it up.',
        'stars' => 5,
    ],
    [
        'name'  => 'Marcus &amp; Jess',
        'loc'   => 'Wedding cake clients',
        'quote' => 'Émile and Clara created the most beautiful lemon &amp; elderflower cake for our wedding. Every guest commented on the flavour. We wept a little. Highly recommended.',
        'stars' => 5,
    ],
    [
        'name'  => 'Dr. K. Patel',
        'loc'   => 'Monthly subscriber',
        'quote' => 'The bread subscription has been one of the best lifestyle additions I\'ve made. Fresh sourdough every Thursday — it practically disappeared within hours of arriving.',
        'stars' => 5,
    ],
];

/* ── FAQs ─────────────────────────────────────────────────────────── */
$faqs = [
    ['q'=>'What time do you open and are you open every day?',
     'a'=>'We open Tuesday to Sunday from 07:30. We bake through the night so the first loaves are out by 08:00. We close on Mondays to let the team rest (and bake preparation begins again on Monday afternoon).'],
    ['q'=>'Can I order a celebration cake or bespoke bake?',
     'a'=>'Absolutely. We take custom orders with a minimum of 10 days\' notice. Please use the order form below or call us to discuss your requirements. We\'ll always arrange a tasting before confirming larger orders.'],
    ['q'=>'Do you offer a bread subscription?',
     'a'=>'Yes — our weekly bread subscription delivers one large sourdough loaf and two pastries to your door every Thursday morning. Subscribers receive a 15% discount and early access to specials. Sign up via the form below.'],
    ['q'=>'Are your products suitable for people with dietary requirements?',
     'a'=>'Our kitchen handles wheat, eggs, dairy, nuts and sesame. We can accommodate some requirements with advance notice but cannot guarantee an allergen-free environment. Please speak to us before ordering if you have a severe allergy.'],
    ['q'=>'Do you wholesale to restaurants or cafés?',
     'a'=>'We supply a small number of local restaurants and food shops. Wholesale enquiries are welcome — please email us with your requirements and we\'ll discuss what we can offer.'],
];

?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400;1,600&family=Source+Sans+3:wght@300;400;600&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════════════════
   ARTISAN BAKERY — CSS CUSTOM PROPERTIES
═══════════════════════════════════════════════════════════════════ */
:root{
  --bak-flour:      #faf6f0;
  --bak-cream:      #f5ede0;
  --bak-wheat:      #d4943a;
  --bak-wheat-lt:   #e8b860;
  --bak-crust:      #8a4a1a;
  --bak-crust-dk:   #5a2a08;
  --bak-chocolate:  #3a1a08;
  --bak-sage:       #6a8a6a;
  --bak-red:        #b83030;
  --bak-dawn-top:   #1a0c04;
  --bak-dawn-mid:   #3a1a08;
  --bak-dawn-bot:   #c87030;
  --bak-ink:        #1e1208;
  --bak-stone:      #8a7a6a;
  --ff-head:        'Playfair Display', Georgia, serif;
  --ff-body:        'Source Sans 3', sans-serif;
  --rad:            10px;
  --trans:          .35s cubic-bezier(.4,0,.2,1);
}

/* ─── Reset & base ───────────────────────────────────────────────── */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth;font-size:16px}
body.bak-page{
  font-family:var(--ff-body);
  color:var(--bak-ink);
  background:var(--bak-flour);
  overflow-x:hidden;
}
.bak-wrap{max-width:1140px;margin:0 auto;padding:0 24px}

/* ─── Typography ─────────────────────────────────────────────────── */
.bak-eyebrow{
  font-family:var(--ff-body);
  font-size:.72rem;
  font-weight:600;
  letter-spacing:.2em;
  text-transform:uppercase;
  color:var(--bak-wheat);
  display:block;
  margin-bottom:.6rem;
}
.bak-h2{
  font-family:var(--ff-head);
  font-size:clamp(2rem,3.5vw,2.9rem);
  font-weight:400;
  color:var(--bak-ink);
  line-height:1.2;
}
.bak-h2 em{
  font-style:italic;
  color:var(--bak-crust);
}
.bak-lead{
  font-size:1.03rem;
  line-height:1.8;
  color:#5a3a20;
  max-width:640px;
}
.bak-centre{text-align:center}
.bak-centre .bak-lead{margin:0 auto}

/* ─── Ornament ───────────────────────────────────────────────────── */
.bak-ornament{
  display:flex;
  align-items:center;
  gap:12px;
  margin:.8rem 0 1.8rem;
}
.bak-ornament-line{
  flex:1;
  height:1px;
  background:linear-gradient(90deg,transparent,var(--bak-wheat),transparent);
}
.bak-ornament-sym{
  font-size:1rem;
  color:var(--bak-wheat);
}

/* ─── Buttons ────────────────────────────────────────────────────── */
.bak-btn{
  display:inline-flex;
  align-items:center;
  gap:8px;
  padding:13px 30px;
  border-radius:4px;
  font-family:var(--ff-body);
  font-weight:600;
  font-size:.88rem;
  letter-spacing:.06em;
  text-transform:uppercase;
  text-decoration:none;
  border:none;
  cursor:pointer;
  transition:var(--trans);
}
.bak-btn-primary{
  background:linear-gradient(135deg,var(--bak-crust),#b06030);
  color:#fff;
  box-shadow:0 4px 18px rgba(138,74,26,.35);
}
.bak-btn-primary:hover{transform:translateY(-2px);box-shadow:0 8px 26px rgba(138,74,26,.45)}
.bak-btn-ghost{
  background:transparent;
  color:#fff;
  border:2px solid rgba(255,255,255,.6);
}
.bak-btn-ghost:hover{background:rgba(255,255,255,.12);border-color:#fff}
.bak-btn-wheat{
  background:linear-gradient(135deg,var(--bak-wheat),var(--bak-wheat-lt));
  color:var(--bak-ink);
  font-weight:700;
}
.bak-btn-wheat:hover{transform:translateY(-2px);box-shadow:0 8px 26px rgba(212,148,58,.4)}

/* ═══════════════════════════════════════════════════════════════════
   HERO — BAKERY SHOPFRONT AT DAWN
═══════════════════════════════════════════════════════════════════ */
.bak-hero{
  position:relative;
  height:100vh;
  min-height:640px;
  max-height:960px;
  overflow:hidden;
  display:flex;
  align-items:center;
  justify-content:center;
}

/* Sky */
.bak-hero-sky{
  position:absolute;
  inset:0;
  background:linear-gradient(180deg,
    var(--bak-dawn-top) 0%,
    var(--bak-dawn-mid) 35%,
    #8a4010 65%,
    var(--bak-dawn-bot) 85%,
    #f0c070 100%
  );
}

/* Cobblestone street */
.bak-street{
  position:absolute;
  bottom:0;left:0;right:0;
  height:22%;
  background:repeating-linear-gradient(
    0deg,
    #3a3028 0px,2px,
    #4a4038 2px,22px
  ),
  repeating-linear-gradient(
    90deg,
    #3a3028 0px,1px,
    #4a4038 1px,38px
  );
  background-blend-mode:multiply;
  background-color:#4a4038;
}

/* Pavement */
.bak-pavement{
  position:absolute;
  bottom:18%;left:0;right:0;
  height:6%;
  background:linear-gradient(180deg,#8a8070,#6a6058);
  border-top:3px solid #5a5048;
}

/* Street lamp */
.bak-lamp{
  position:absolute;
  bottom:24%;
}
.bak-lamp-pole{
  width:8px;
  border-radius:4px 4px 0 0;
  background:linear-gradient(90deg,#5a5050,#3a3028,#5a5050);
}
.bak-lamp-arm{
  position:absolute;
  top:0;
  width:36px;height:3px;
  background:#3a3028;
  border-radius:2px;
}
.bak-lamp-head{
  position:absolute;
  top:-22px;
  width:22px;height:28px;
  background:linear-gradient(180deg,#2a2020,#4a3020);
  border-radius:4px 4px 6px 6px;
  box-shadow:0 0 20px rgba(255,180,60,.6),0 0 40px rgba(255,160,40,.2);
}
.bak-lamp-head::before{
  content:'';
  position:absolute;
  inset:4px;
  background:radial-gradient(circle,rgba(255,220,120,.9),rgba(255,160,40,.4));
  border-radius:3px;
  animation:bak-lamp-glow 2.5s ease-in-out infinite alternate;
}
@keyframes bak-lamp-glow{from{opacity:.7}to{opacity:1}}
.bak-lamp-glow{
  position:absolute;
  top:-10px;
  width:60px;height:60px;
  border-radius:50%;
  background:radial-gradient(circle,rgba(255,200,80,.25),transparent 70%);
  left:50%;
  transform:translateX(-50%);
}

/* Awning */
.bak-awning{
  position:absolute;
  width:min(580px,80vw);
}
.bak-awning-frame{
  height:50px;
  background:repeating-linear-gradient(
    90deg,
    #b83030 0px,32px,
    #e8e0d0 32px,64px
  );
  border-radius:2px;
  position:relative;
}
.bak-awning-frame::after{
  content:'';
  position:absolute;
  bottom:-16px;left:0;right:0;
  height:18px;
  background:inherit;
  clip-path:polygon(0 0,100% 0,97% 100%,93% 60%,89% 100%,85% 60%,81% 100%,77% 60%,73% 100%,69% 60%,65% 100%,61% 60%,57% 100%,53% 60%,49% 100%,45% 60%,41% 100%,37% 60%,33% 100%,29% 60%,25% 100%,21% 60%,17% 100%,13% 60%,9% 100%,5% 60%,1% 100%);
}
.bak-awning-valance{
  height:18px;
  /* created by ::after above */
}

/* Shopfront */
.bak-shopfront{
  position:absolute;
  bottom:24%;
  left:50%;
  transform:translateX(-50%);
  width:min(560px,78vw);
  display:flex;
  flex-direction:column;
  align-items:center;
}
.bak-facade-top{
  width:100%;
  height:30px;
  background:linear-gradient(180deg,#5a3010,#4a2008);
  border-radius:2px 2px 0 0;
  display:flex;
  align-items:center;
  justify-content:center;
}
.bak-facade-sign{
  font-family:var(--ff-head);
  font-size:.85rem;
  font-style:italic;
  color:var(--bak-wheat-lt);
  letter-spacing:.12em;
}
.bak-facade-body{
  width:100%;
  background:linear-gradient(180deg,#d8caba,#c4b4a0);
  display:flex;
  gap:6px;
  padding:6px;
  align-items:stretch;
  position:relative;
}
/* Main window */
.bak-main-window{
  flex:1;
  min-height:130px;
  background:linear-gradient(180deg,rgba(255,230,180,.25),rgba(255,210,140,.15));
  border:3px solid #5a3010;
  position:relative;
  overflow:hidden;
  display:flex;
  flex-direction:column;
}
.bak-window-light{
  position:absolute;
  inset:0;
  background:radial-gradient(ellipse at 50% 0%,rgba(255,220,140,.3),transparent 70%);
}
/* Display shelf in window */
.bak-shelf{
  position:absolute;
  bottom:20px;
  left:8px;right:8px;
  height:6px;
  background:linear-gradient(180deg,#7a5030,#5a3010);
  border-radius:1px;
}
.bak-shelf-loaves{
  position:absolute;
  bottom:26px;
  left:10px;
  right:10px;
  display:flex;
  gap:3px;
  align-items:flex-end;
  justify-content:center;
}
/* Loaf CSS shapes */
.bak-loaf{
  position:relative;
  border-radius:50% 50% 30% 30%;
  flex-shrink:0;
}
.bak-loaf-top{
  position:absolute;
  top:0;left:50%;
  transform:translateX(-50%);
  border-radius:50%;
  width:90%;
  height:55%;
}
.bak-loaf-score{
  position:absolute;
  top:25%;left:25%;right:25%;
  height:1px;
  background:rgba(0,0,0,.25);
}
.bak-loaf-seeds{
  position:absolute;
  top:15%;left:0;right:0;
  display:flex;
  justify-content:center;
  gap:3px;
}
.bak-seed{
  width:2px;height:4px;
  border-radius:50%;
  background:rgba(50,20,5,.6);
  transform:rotate(45deg);
}
.bak-loaf-label{
  position:absolute;
  bottom:-14px;
  left:50%;
  transform:translateX(-50%);
  font-size:6px;
  white-space:nowrap;
  color:rgba(255,255,255,.7);
  font-family:var(--ff-body);
  font-weight:600;
}
/* Baguette shape */
.bak-baguette{
  width:12px;
  border-radius:50%;
  transform:rotate(-15deg);
  transform-origin:bottom center;
}
/* Door */
.bak-door-wrap{
  width:80px;
  border:3px solid #5a3010;
  background:linear-gradient(180deg,#6a4020,#4a2808);
  position:relative;
  display:flex;
  flex-direction:column;
  border-radius:2px 2px 0 0;
}
.bak-door-glass{
  flex:1;
  margin:6px;
  background:linear-gradient(180deg,rgba(255,220,140,.2),rgba(255,180,80,.1));
  border:1px solid rgba(255,200,120,.3);
  border-radius:2px;
}
.bak-door-handle{
  position:absolute;
  right:10px;
  top:45%;
  width:6px;height:12px;
  background:var(--bak-wheat);
  border-radius:3px;
}
.bak-door-mat{
  height:8px;
  background:repeating-linear-gradient(90deg,#3a2018 0px,3px,#5a3828 3px,6px);
  border-radius:0 0 2px 2px;
}
.bak-facade-base{
  width:100%;
  height:12px;
  background:linear-gradient(180deg,#4a2808,#3a1a04);
}

/* Potted plants flanking door */
.bak-plant{
  position:absolute;
  bottom:0;
  display:flex;
  flex-direction:column;
  align-items:center;
}
.bak-plant-pot{
  width:24px;height:18px;
  background:linear-gradient(180deg,#8a4a2a,#6a3018);
  clip-path:polygon(10% 0,90% 0,100% 100%,0 100%);
}
.bak-plant-bush{
  width:34px;height:34px;
  border-radius:50%;
  background:radial-gradient(circle at 40% 40%,#7aaa5a,#4a7a3a);
  margin-bottom:-2px;
}
.bak-plant-l{left:-20px}
.bak-plant-r{right:-20px}

/* Awning sits above shopfront */
.bak-awning{
  margin-bottom:-2px;
}

/* Steam wisps above chimney or warm air */
.bak-steam{
  position:absolute;
  background:rgba(255,255,255,.15);
  border-radius:50%;
  animation:bak-steam-rise var(--sdur,4s) var(--sdel,0s) ease-in-out infinite;
}
@keyframes bak-steam-rise{
  0%{transform:translateY(0) scaleX(1);opacity:0}
  15%{opacity:.6}
  60%{transform:translateY(-60px) scaleX(1.5);opacity:.3}
  100%{transform:translateY(-120px) scaleX(.5);opacity:0}
}

/* Hero content */
.bak-hero-content{
  position:relative;
  z-index:10;
  text-align:center;
  padding:0 24px;
}
.bak-hero-badge{
  display:inline-flex;
  align-items:center;
  gap:8px;
  background:rgba(30,12,0,.5);
  backdrop-filter:blur(8px);
  border:1px solid rgba(255,200,100,.3);
  border-radius:4px;
  padding:6px 18px;
  font-family:var(--ff-body);
  font-size:.72rem;
  font-weight:600;
  letter-spacing:.15em;
  text-transform:uppercase;
  color:var(--bak-wheat-lt);
  margin-bottom:1.4rem;
}
.bak-hero-h1{
  font-family:var(--ff-head);
  font-size:clamp(2.6rem,7vw,5.5rem);
  font-weight:400;
  letter-spacing:.02em;
  color:#fff;
  line-height:1.1;
  text-shadow:0 3px 24px rgba(30,12,0,.6);
  margin-bottom:.6rem;
}
.bak-hero-h1 em{
  font-style:italic;
  color:var(--bak-wheat-lt);
}
.bak-hero-sub{
  font-family:var(--ff-head);
  font-size:clamp(.95rem,1.8vw,1.2rem);
  font-style:italic;
  color:rgba(255,255,255,.75);
  margin-bottom:2.2rem;
  letter-spacing:.04em;
}
.bak-hero-btns{
  display:flex;
  gap:14px;
  justify-content:center;
  flex-wrap:wrap;
}

/* Hours ribbon */
.bak-hours-ribbon{
  position:absolute;
  bottom:0;left:0;right:0;
  z-index:10;
  background:rgba(20,10,0,.8);
  backdrop-filter:blur(8px);
  padding:14px 24px;
  display:flex;
  justify-content:center;
  align-items:center;
  gap:8px;
  flex-wrap:wrap;
}
.bak-hours-item{
  display:flex;
  align-items:center;
  gap:6px;
  color:rgba(255,255,255,.85);
  font-size:.82rem;
}
.bak-hours-sep{
  color:var(--bak-wheat);
  margin:0 6px;
}
.bak-hours-item strong{color:var(--bak-wheat-lt)}

/* ═══════════════════════════════════════════════════════════════════
   STATS BAND
═══════════════════════════════════════════════════════════════════ */
.bak-stats{
  background:var(--bak-crust-dk);
  padding:30px 0;
}
.bak-stats-grid{
  display:grid;
  grid-template-columns:repeat(4,1fr);
  gap:0;
}
.bak-stat{
  text-align:center;
  padding:16px 12px;
  border-right:1px solid rgba(255,255,255,.08);
}
.bak-stat:last-child{border-right:none}
.bak-stat-num{
  font-family:var(--ff-head);
  font-size:2.4rem;
  font-weight:400;
  color:var(--bak-wheat-lt);
  display:block;
  line-height:1;
}
.bak-stat-suf{font-size:1.4rem;color:var(--bak-stone)}
.bak-stat-label{
  font-size:.75rem;
  color:rgba(255,255,255,.5);
  letter-spacing:.08em;
  text-transform:uppercase;
  margin-top:6px;
  display:block;
}

/* ═══════════════════════════════════════════════════════════════════
   PRODUCT RANGE
═══════════════════════════════════════════════════════════════════ */
.bak-range-sec{
  padding:100px 0;
  background:var(--bak-cream);
}
.bak-range-header{text-align:center;margin-bottom:52px}
.bak-range-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:24px;
}
.bak-range-card{
  background:#fff;
  border-radius:var(--rad);
  padding:28px 22px;
  box-shadow:0 2px 16px rgba(90,60,20,.06);
  transition:var(--trans);
}
.bak-range-card:hover{
  transform:translateY(-3px);
  box-shadow:0 8px 28px rgba(90,60,20,.12);
}
.bak-range-icon{
  font-size:2rem;
  display:block;
  margin-bottom:10px;
}
.bak-range-cat{
  font-family:var(--ff-head);
  font-size:1.15rem;
  font-weight:600;
  color:var(--bak-ink);
  margin-bottom:8px;
}
.bak-range-desc{
  font-size:.85rem;
  line-height:1.65;
  color:#6a4a28;
  margin-bottom:14px;
}
.bak-range-list{
  list-style:none;
  display:flex;
  flex-direction:column;
  gap:5px;
}
.bak-range-list li{
  font-size:.82rem;
  color:#5a3a18;
  display:flex;
  gap:8px;
  align-items:baseline;
}
.bak-range-list li::before{
  content:'—';
  color:var(--bak-wheat);
  flex-shrink:0;
}

/* ═══════════════════════════════════════════════════════════════════
   PASTRY CASE (showcase grid)
═══════════════════════════════════════════════════════════════════ */
.bak-pastry-sec{
  padding:100px 0;
  background:var(--bak-flour);
}
.bak-pastry-header{text-align:center;margin-bottom:52px}
.bak-pastry-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:20px;
}
.bak-pastry-card{
  background:#fff;
  border-radius:var(--rad);
  overflow:hidden;
  box-shadow:0 2px 14px rgba(90,60,20,.07);
  transition:var(--trans);
}
.bak-pastry-card:hover{transform:translateY(-3px);box-shadow:0 8px 26px rgba(90,60,20,.13)}
/* CSS pastry illustration */
.bak-pastry-art{
  height:110px;
  display:flex;
  align-items:center;
  justify-content:center;
  position:relative;
  overflow:hidden;
}
.bak-pastry-shape{position:relative}
/* Croissant shape */
.bak-pastry-crescent{
  width:80px;height:40px;
  border-radius:50% 50% 0 0 / 60% 60% 0 0;
  background:linear-gradient(135deg,#d4a050,#b07828);
  transform:rotate(-20deg);
  box-shadow:inset 0 -4px 8px rgba(0,0,0,.2);
  position:relative;
}
.bak-pastry-crescent::before{
  content:'';
  position:absolute;
  right:-20px;top:5px;
  width:44px;height:26px;
  border-radius:50% 50% 0 0 / 60% 60% 0 0;
  background:linear-gradient(135deg,#c89040,#a06820);
  transform:rotate(40deg);
}
.bak-pastry-crescent::after{
  content:'';
  position:absolute;
  left:-20px;top:5px;
  width:44px;height:26px;
  border-radius:50% 50% 0 0 / 60% 60% 0 0;
  background:linear-gradient(135deg,#c89040,#a06820);
  transform:rotate(-40deg);
}
/* Rectangle (pain au choc) */
.bak-pastry-rectangle{
  width:70px;height:46px;
  background:linear-gradient(180deg,#b8782a,#8a5018);
  border-radius:3px;
  box-shadow:inset 0 4px 6px rgba(255,200,100,.15);
  position:relative;
}
.bak-pastry-rectangle::before{
  content:'';
  position:absolute;
  top:35%;left:10%;right:10%;
  height:2px;
  background:rgba(60,20,5,.4);
}
.bak-pastry-rectangle::after{
  content:'';
  position:absolute;
  top:55%;left:10%;right:10%;
  height:2px;
  background:rgba(60,20,5,.4);
}
/* Round */
.bak-pastry-round{
  width:68px;height:68px;
  border-radius:50%;
  background:radial-gradient(circle at 40% 40%,#c87830,#7a3a10);
  box-shadow:inset 0 4px 8px rgba(255,180,80,.2);
  position:relative;
}
.bak-pastry-round::before{
  content:'';
  position:absolute;
  top:20%;left:20%;right:20%;bottom:20%;
  border-radius:50%;
  border:2px solid rgba(255,200,100,.2);
}
/* Tart */
.bak-pastry-tart{
  width:70px;height:70px;
  border-radius:50%;
  background:radial-gradient(circle,#e8d060 40%,#c4a428 41%,#b8921c 70%,#9a7010 100%);
  border:3px solid #8a6010;
  box-shadow:inset 0 -4px 8px rgba(0,0,0,.15);
}
/* Cannelé */
.bak-pastry-cannele{
  width:40px;height:60px;
  background:linear-gradient(180deg,#4a1a04,#7a3010);
  border-radius:4px 4px 50% 50%;
  box-shadow:inset 2px 0 4px rgba(255,180,80,.1);
  position:relative;
}
.bak-pastry-cannele::before{
  content:'';
  position:absolute;
  top:0;left:6px;right:6px;height:12px;
  background:rgba(255,160,40,.2);
  border-radius:0 0 4px 4px;
}
/* Danish */
.bak-pastry-danish{
  width:72px;height:72px;
  border-radius:4px;
  background:linear-gradient(135deg,#e8a050,#c07828);
  position:relative;
}
.bak-pastry-danish::before{
  content:'';
  position:absolute;
  top:15%;left:15%;right:15%;bottom:15%;
  border-radius:50%;
  background:radial-gradient(circle,#e85030,#c03018);
}
.bak-pastry-danish::after{
  content:'';
  position:absolute;
  top:5%;left:5%;right:5%;bottom:5%;
  border:2px solid rgba(255,220,150,.3);
  border-radius:3px;
}
.bak-pastry-body{padding:16px 18px}
.bak-pastry-name{
  font-family:var(--ff-head);
  font-size:1rem;
  font-weight:600;
  color:var(--bak-ink);
  margin-bottom:3px;
}
.bak-pastry-price{
  font-size:.85rem;
  font-weight:600;
  color:var(--bak-wheat);
  margin-bottom:8px;
}
.bak-pastry-desc{
  font-size:.8rem;
  line-height:1.6;
  color:#6a4a28;
}

/* ═══════════════════════════════════════════════════════════════════
   ABOUT STORY
═══════════════════════════════════════════════════════════════════ */
.bak-about-sec{
  padding:100px 0;
  background:var(--bak-cream);
}
.bak-about-grid{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:70px;
  align-items:center;
}
/* CSS oven illustration */
.bak-oven-art{
  height:360px;
  position:relative;
  display:flex;
  align-items:flex-end;
  justify-content:center;
}
.bak-oven-body{
  width:220px;
  background:linear-gradient(180deg,#4a4038,#2a2018);
  border-radius:8px 8px 0 0;
  position:relative;
  overflow:hidden;
}
.bak-oven-top{
  height:30px;
  background:linear-gradient(180deg,#5a5040,#3a3028);
  border-radius:8px 8px 0 0;
  display:flex;
  align-items:center;
  justify-content:center;
  gap:8px;
}
.bak-oven-knob{
  width:14px;height:14px;
  border-radius:50%;
  background:radial-gradient(circle,#8a7058,#4a3820);
  border:2px solid #2a1a08;
  position:relative;
}
.bak-oven-knob::after{
  content:'';
  position:absolute;
  top:50%;left:50%;
  width:4px;height:4px;
  border-radius:50%;
  background:#c8a060;
  transform:translate(-50%,-50%);
}
.bak-oven-door{
  height:160px;
  margin:10px 14px;
  background:linear-gradient(180deg,#2a1a10,#1a1008);
  border-radius:4px;
  border:3px solid #5a4030;
  position:relative;
  overflow:hidden;
}
.bak-oven-glass{
  position:absolute;
  inset:6px;
  background:radial-gradient(ellipse,rgba(255,140,30,.25),rgba(255,80,10,.1),transparent 70%);
  border-radius:2px;
  animation:bak-oven-heat 3s ease-in-out infinite alternate;
}
@keyframes bak-oven-heat{
  from{opacity:.5}
  to{opacity:1}
}
.bak-oven-shelf-art{
  position:absolute;
  bottom:40px;left:10%;right:10%;
  height:4px;
  background:repeating-linear-gradient(90deg,#5a4030 0px,3px,transparent 3px,7px);
}
.bak-oven-loaf-art{
  position:absolute;
  bottom:44px;left:50%;
  transform:translateX(-50%);
  width:60px;height:28px;
  background:linear-gradient(180deg,#8a4a20,#6a3010);
  border-radius:50% 50% 30% 30%;
}
.bak-oven-bottom{
  height:20px;
  background:linear-gradient(180deg,#3a3028,#2a2018);
  border-radius:0 0 8px 8px;
}
/* Bread on counter */
.bak-counter-art{
  position:absolute;
  bottom:60px;
  left:0;right:0;
  display:flex;
  align-items:flex-end;
  justify-content:center;
  gap:12px;
}
.bak-counter-loaf{
  border-radius:50% 50% 30% 30%;
  position:relative;
}
.bak-counter-top{
  position:absolute;
  top:0;left:50%;
  transform:translateX(-50%);
  border-radius:50%;
}
.bak-flour-dusting{
  position:absolute;
  bottom:58px;left:10%;right:10%;
  height:2px;
  background:rgba(255,255,255,.2);
  border-radius:1px;
}
/* Steam above oven */
.bak-oven-steam{
  position:absolute;
  top:60px;
  width:100%;
  display:flex;
  justify-content:center;
  gap:24px;
}
.bak-oven-steam-wisp{
  width:6px;height:6px;
  border-radius:50%;
  background:rgba(255,255,255,.4);
  animation:bak-steam-rise 3s ease-in-out infinite;
}

.bak-about-text .bak-h2{margin-bottom:.4rem}
.bak-about-milestones{
  margin-top:28px;
  display:flex;
  flex-direction:column;
  gap:0;
}
.bak-milestone{
  display:flex;
  gap:16px;
  padding:16px 0;
  border-bottom:1px solid rgba(138,74,26,.1);
}
.bak-milestone:last-child{border-bottom:none}
.bak-milestone-year{
  font-family:var(--ff-head);
  font-weight:600;
  font-size:1.15rem;
  color:var(--bak-wheat);
  min-width:54px;
  padding-top:2px;
}
.bak-milestone-body{flex:1}
.bak-milestone-title{
  font-family:var(--ff-head);
  font-weight:600;
  font-size:.92rem;
  color:var(--bak-ink);
  margin-bottom:2px;
}
.bak-milestone-desc{font-size:.85rem;line-height:1.6;color:#6a4a28}

/* ═══════════════════════════════════════════════════════════════════
   TEAM
═══════════════════════════════════════════════════════════════════ */
.bak-team-sec{
  padding:100px 0;
  background:var(--bak-crust-dk);
}
.bak-team-header{text-align:center;margin-bottom:48px}
.bak-team-header .bak-h2,.bak-team-header .bak-lead{color:rgba(255,255,255,.9)}
.bak-team-header .bak-eyebrow{color:var(--bak-wheat-lt)}
.bak-team-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:28px;
}
.bak-team-card{
  background:rgba(255,255,255,.06);
  border:1px solid rgba(255,255,255,.1);
  border-radius:var(--rad);
  overflow:hidden;
  transition:var(--trans);
}
.bak-team-card:hover{
  background:rgba(255,255,255,.1);
  transform:translateY(-3px);
}
/* CSS baker figure */
.bak-baker-art{
  height:160px;
  background:linear-gradient(180deg,#2a1a0a,#1a0c04);
  display:flex;
  align-items:flex-end;
  justify-content:center;
  position:relative;
  overflow:hidden;
}
.bak-baker-art::before{
  content:'';
  position:absolute;
  bottom:0;left:0;right:0;
  height:30px;
  background:linear-gradient(180deg,transparent,rgba(255,180,60,.08));
}
.bak-baker-fig{
  display:flex;
  flex-direction:column;
  align-items:center;
  position:relative;
}
/* Chef hat */
.bak-chef-hat-brim{
  width:54px;height:8px;
  background:#f0ece4;
  border-radius:4px;
  position:relative;
  z-index:2;
}
.bak-chef-hat-tall{
  width:36px;height:38px;
  background:#f0ece4;
  border-radius:50% 50% 0 0 / 60% 60% 0 0;
  margin:0 auto -1px;
  position:relative;
  z-index:1;
}
.bak-chef-hat-tall::before{
  content:'';
  position:absolute;
  top:4px;left:50%;
  transform:translateX(-50%);
  width:26px;height:20px;
  border-radius:50%;
  background:rgba(255,255,255,.3);
}
.bak-baker-head{
  width:34px;height:34px;
  border-radius:50%;
  margin-top:-1px;
  z-index:2;
  position:relative;
}
.bak-baker-body{
  width:52px;height:60px;
  border-radius:4px 4px 0 0;
  position:relative;
}
.bak-baker-apron{
  position:absolute;
  top:4px;left:50%;
  transform:translateX(-50%);
  width:32px;
  bottom:0;
  border-radius:2px 2px 0 0;
}
.bak-baker-apron::before{
  content:'';
  position:absolute;
  top:0;left:50%;
  transform:translateX(-50%);
  width:2px;height:100%;
  background:rgba(0,0,0,.08);
}
.bak-baker-arms{
  position:absolute;
  top:0;left:0;right:0;
  height:100%;
  pointer-events:none;
}
.bak-baker-arm{
  position:absolute;
  width:9px;height:36px;
  border-radius:4px;
  top:6px;
}
.bak-baker-arm-l{left:-12px;transform:rotate(-12deg);transform-origin:top}
.bak-baker-arm-r{right:-12px;transform:rotate(12deg);transform-origin:top}
/* Bread loaf held by baker */
.bak-held-loaf{
  position:absolute;
  right:-24px;top:18px;
  width:26px;height:16px;
  border-radius:50% 50% 30% 30%;
  background:linear-gradient(180deg,#8a4a20,#6a3010);
}
.bak-team-body{padding:18px 16px}
.bak-team-name{
  font-family:var(--ff-head);
  font-size:1.05rem;
  font-weight:600;
  color:#fff;
  margin-bottom:3px;
}
.bak-team-role{
  font-size:.8rem;
  color:var(--bak-wheat-lt);
  margin-bottom:4px;
  font-style:italic;
}
.bak-team-origin{
  font-size:.75rem;
  color:rgba(255,255,255,.45);
  letter-spacing:.05em;
  margin-bottom:10px;
}
.bak-team-bio{
  font-size:.85rem;
  line-height:1.65;
  color:rgba(255,255,255,.7);
}

/* ═══════════════════════════════════════════════════════════════════
   TESTIMONIALS
═══════════════════════════════════════════════════════════════════ */
.bak-test-sec{
  padding:100px 0;
  background:var(--bak-flour);
}
.bak-test-header{text-align:center;margin-bottom:48px}
.bak-test-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:22px;
}
.bak-test-card{
  background:#fff;
  border-radius:var(--rad);
  padding:26px 22px;
  box-shadow:0 2px 14px rgba(90,60,20,.06);
  position:relative;
}
.bak-test-card::before{
  content:'\201C';
  position:absolute;
  top:14px;right:18px;
  font-size:3.5rem;
  font-family:Georgia,serif;
  color:var(--bak-cream);
  line-height:1;
}
.bak-test-stars{color:var(--bak-wheat);font-size:1rem;margin-bottom:12px}
.bak-test-quote{
  font-size:.88rem;
  line-height:1.72;
  color:#4a3018;
  font-style:italic;
  margin-bottom:16px;
}
.bak-test-name{
  font-family:var(--ff-head);
  font-weight:600;
  font-size:.88rem;
  color:var(--bak-ink);
}
.bak-test-loc{font-size:.75rem;color:var(--bak-stone)}

/* ═══════════════════════════════════════════════════════════════════
   FAQ
═══════════════════════════════════════════════════════════════════ */
.bak-faq-sec{
  padding:100px 0;
  background:var(--bak-cream);
}
.bak-faq-inner{max-width:740px;margin:0 auto}
.bak-faq-header{text-align:center;margin-bottom:48px}
.bak-faq-item{border-bottom:1px solid rgba(138,100,40,.12)}
.bak-faq-q{
  width:100%;background:none;border:none;
  text-align:left;padding:18px 0;
  display:flex;align-items:center;justify-content:space-between;gap:14px;
  font-family:var(--ff-head);font-size:.98rem;font-weight:600;color:var(--bak-ink);
  cursor:pointer;transition:color var(--trans);
}
.bak-faq-q:hover{color:var(--bak-crust)}
.bak-faq-icon{
  width:24px;height:24px;border-radius:50%;
  background:var(--bak-cream);
  display:flex;align-items:center;justify-content:center;
  flex-shrink:0;transition:var(--trans);
  font-size:.9rem;color:var(--bak-wheat);
}
.bak-faq-item.open .bak-faq-icon{
  transform:rotate(45deg);
  background:var(--bak-wheat);
  color:#fff;
}
.bak-faq-a{overflow:hidden;max-height:0;transition:max-height .4s ease}
.bak-faq-a-inner{
  padding:0 0 18px;
  font-size:.9rem;line-height:1.75;color:#6a4a28;
}

/* ═══════════════════════════════════════════════════════════════════
   ORDER / ENQUIRY FORM
═══════════════════════════════════════════════════════════════════ */
.bak-order-sec{
  padding:100px 0;
  background:linear-gradient(135deg,var(--bak-crust) 0%,var(--bak-crust-dk) 60%,#1a0c04 100%);
}
.bak-order-wrap{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:60px;
  align-items:start;
}
.bak-order-info .bak-h2,.bak-order-info .bak-eyebrow{color:rgba(255,255,255,.95)}
.bak-order-info .bak-eyebrow{color:var(--bak-wheat-lt)}
.bak-order-info .bak-lead{color:rgba(255,255,255,.75)}
.bak-order-details{
  margin-top:28px;
  display:flex;
  flex-direction:column;
  gap:12px;
}
.bak-detail-row{
  display:flex;
  align-items:center;
  gap:12px;
  color:rgba(255,255,255,.8);
  font-size:.88rem;
}
.bak-detail-icon{
  width:32px;height:32px;border-radius:50%;
  background:rgba(255,255,255,.1);
  display:flex;align-items:center;justify-content:center;
  font-size:.95rem;flex-shrink:0;
}
.bak-form-card{
  background:#fff;
  border-radius:calc(var(--rad)*1.5);
  padding:34px 30px;
  box-shadow:0 20px 60px rgba(0,0,0,.25);
}
.bak-form-title{
  font-family:var(--ff-head);
  font-size:1.2rem;font-weight:600;
  color:var(--bak-ink);margin-bottom:20px;
}
.bak-field{margin-bottom:16px}
.bak-field label{
  display:block;font-size:.75rem;font-weight:600;
  letter-spacing:.06em;text-transform:uppercase;
  color:var(--bak-crust);margin-bottom:6px;
}
.bak-field input,
.bak-field select,
.bak-field textarea{
  width:100%;padding:10px 13px;
  border:1.5px solid #d8c8b0;border-radius:6px;
  font-family:var(--ff-body);font-size:.88rem;
  color:var(--bak-ink);background:#fff;
  transition:border-color var(--trans),box-shadow var(--trans);
}
.bak-field input:focus,
.bak-field select:focus,
.bak-field textarea:focus{
  outline:none;border-color:var(--bak-wheat);
  box-shadow:0 0 0 3px rgba(212,148,58,.12);
}
.bak-field-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.bak-field textarea{resize:vertical;min-height:80px}
.bak-form-submit{
  width:100%;padding:13px;border-radius:4px;
  font-family:var(--ff-body);font-weight:700;font-size:.88rem;
  letter-spacing:.08em;text-transform:uppercase;
  border:none;cursor:pointer;
  background:linear-gradient(135deg,var(--bak-crust),#b06030);
  color:#fff;
  box-shadow:0 4px 18px rgba(138,74,26,.35);
  transition:var(--trans);
}
.bak-form-submit:hover{transform:translateY(-2px);box-shadow:0 8px 26px rgba(138,74,26,.45)}
.bak-form-note{
  font-size:.72rem;color:#8a7060;text-align:center;
  margin-top:10px;line-height:1.5;
}

/* ═══════════════════════════════════════════════════════════════════
   RESPONSIVE
═══════════════════════════════════════════════════════════════════ */
@media(max-width:900px){
  .bak-stats-grid{grid-template-columns:repeat(2,1fr)}
  .bak-range-grid{grid-template-columns:repeat(2,1fr)}
  .bak-pastry-grid{grid-template-columns:repeat(2,1fr)}
  .bak-about-grid{grid-template-columns:1fr;gap:40px}
  .bak-oven-art{height:260px}
  .bak-team-grid{grid-template-columns:1fr}
  .bak-test-grid{grid-template-columns:1fr}
  .bak-order-wrap{grid-template-columns:1fr}
}
@media(max-width:600px){
  .bak-stats-grid{grid-template-columns:repeat(2,1fr)}
  .bak-range-grid{grid-template-columns:1fr}
  .bak-pastry-grid{grid-template-columns:1fr}
  .bak-hero-btns{flex-direction:column;align-items:center}
  .bak-field-row{grid-template-columns:1fr}
}
</style>
<?php get_header(); ?>
<div class="bak-page">
>
<?php wp_body_open(); ?>

<!-- ═══════════════════════════════════════════════════════════════
     HERO — BAKERY SHOPFRONT AT DAWN
═══════════════════════════════════════════════════════════════════ -->
<section class="bak-hero" aria-label="Hero">
  <div class="bak-hero-sky"></div>

  <!-- Street & pavement -->
  <div class="bak-pavement" aria-hidden="true"></div>
  <div class="bak-street" aria-hidden="true"></div>

  <!-- Street lamps -->
  <div class="bak-lamp" style="left:8%" aria-hidden="true">
    <div class="bak-lamp-glow"></div>
    <div class="bak-lamp-arm" style="right:0"></div>
    <div class="bak-lamp-head" style="right:-8px"></div>
    <div class="bak-lamp-pole" style="height:120px"></div>
  </div>
  <div class="bak-lamp" style="right:8%" aria-hidden="true">
    <div class="bak-lamp-glow"></div>
    <div class="bak-lamp-arm" style="left:0"></div>
    <div class="bak-lamp-head" style="left:-8px"></div>
    <div class="bak-lamp-pole" style="height:120px"></div>
  </div>

  <!-- Shopfront structure -->
  <div class="bak-shopfront" aria-hidden="true">
    <!-- Awning above -->
    <div class="bak-awning" style="width:100%">
      <div class="bak-awning-frame">
        <span style="position:relative;z-index:1;font-family:'Playfair Display',serif;font-size:.8rem;font-style:italic;color:rgba(255,240,200,.9);letter-spacing:.12em">Seven Grains Artisan Bakery</span>
      </div>
    </div>

    <div class="bak-facade-top">
      <span class="bak-facade-sign">Est. 2011 · Borough Market</span>
    </div>
    <div class="bak-facade-body">
      <!-- Left window with bread display -->
      <div class="bak-main-window" style="max-width:220px">
        <div class="bak-window-light"></div>
        <div style="position:absolute;top:6px;left:0;right:0;text-align:center">
          <span style="font-size:8px;color:rgba(255,220,140,.6);font-family:'Playfair Display',serif;font-style:italic;letter-spacing:.08em">Today's Fresh Bakes</span>
        </div>
        <!-- Cross dividers -->
        <div style="position:absolute;top:0;bottom:0;left:50%;width:1px;background:rgba(90,48,16,.4)"></div>
        <div style="position:absolute;top:50%;left:0;right:0;height:1px;background:rgba(90,48,16,.4)"></div>
        <div class="bak-shelf-loaves">
          <?php foreach (array_slice($bak_loaves,0,4) as $loaf):
            $hw = isset($loaf['baguette']) ? 14 : $loaf['w'];
            $hh = isset($loaf['baguette']) ? 55 : $loaf['h'];
          ?>
          <div class="bak-loaf" style="width:<?= $hw ?>px;height:<?= $hh ?>px;background:<?= $loaf['col'] ?>;<?= isset($loaf['baguette']) ? 'border-radius:6px;transform:rotate(-10deg)' : '' ?>">
            <div class="bak-loaf-top" style="background:<?= $loaf['top_col'] ?>;width:<?= $loaf['oval'] ? '85%':'90%' ?>;height:<?= $loaf['oval'] ? '70%':'55%' ?>;border-radius:<?= $loaf['oval'] ? '50%':'50%' ?>"></div>
            <?php if ($loaf['crack']): ?>
            <div class="bak-loaf-score"></div>
            <?php endif; ?>
            <?php if ($loaf['seeds']): ?>
            <div class="bak-loaf-seeds">
              <div class="bak-seed"></div><div class="bak-seed"></div><div class="bak-seed"></div>
            </div>
            <?php endif; ?>
          </div>
          <?php endforeach; ?>
        </div>
        <div class="bak-shelf"></div>
      </div>

      <!-- Door with plants -->
      <div class="bak-door-wrap" style="flex:0;min-height:130px">
        <div class="bak-plant bak-plant-l">
          <div class="bak-plant-bush"></div>
          <div class="bak-plant-pot"></div>
        </div>
        <div class="bak-plant bak-plant-r">
          <div class="bak-plant-bush"></div>
          <div class="bak-plant-pot"></div>
        </div>
        <div class="bak-door-glass"></div>
        <div class="bak-door-handle"></div>
        <div class="bak-door-mat"></div>
      </div>

      <!-- Right window with pastry display -->
      <div class="bak-main-window" style="max-width:220px">
        <div class="bak-window-light"></div>
        <div style="position:absolute;top:6px;left:0;right:0;text-align:center">
          <span style="font-size:8px;color:rgba(255,220,140,.6);font-family:'Playfair Display',serif;font-style:italic;letter-spacing:.08em">Pâtisserie du Jour</span>
        </div>
        <div style="position:absolute;top:0;bottom:0;left:50%;width:1px;background:rgba(90,48,16,.4)"></div>
        <div style="position:absolute;top:50%;left:0;right:0;height:1px;background:rgba(90,48,16,.4)"></div>
        <div class="bak-shelf-loaves">
          <!-- Pastry shapes in window -->
          <div style="width:32px;height:20px;background:linear-gradient(135deg,#d4a050,#b07828);border-radius:50% 50% 0 0;transform:rotate(-15deg)"></div>
          <div style="width:26px;height:22px;background:linear-gradient(180deg,#b8782a,#8a5018);border-radius:2px"></div>
          <div style="width:28px;height:28px;background:radial-gradient(circle,#e8d060,#c4a428);border-radius:50%;border:2px solid #8a6010"></div>
          <div style="width:18px;height:30px;background:linear-gradient(180deg,#4a1a04,#7a3010);border-radius:3px 3px 50% 50%"></div>
        </div>
        <div class="bak-shelf"></div>
      </div>
    </div>
    <div class="bak-facade-base"></div>
  </div>

  <!-- Steam wisps from bakery -->
  <?php foreach (array_slice($steam_wisps, 0, 8) as $sw): ?>
  <div class="bak-steam" style="
    left:<?= $sw['x'] ?>%;
    bottom:28%;
    width:<?= $sw['size'] ?>px;
    height:<?= $sw['size'] ?>px;
    --sdur:<?= $sw['dur'] ?>s;
    --sdel:<?= $sw['delay'] ?>s;
  " aria-hidden="true"></div>
  <?php endforeach; ?>

  <!-- Hero content -->
  <div class="bak-hero-content">
    <span class="bak-hero-badge">🥖 Artisan Bakery &amp; Café · Borough Market</span>
    <h1 class="bak-hero-h1">Baked with<br><em>love &amp; tradition</em></h1>
    <p class="bak-hero-sub">Fresh from the oven since half past seven.</p>
    <div class="bak-hero-btns">
      <a href="#order" class="bak-btn bak-btn-primary">Place an Order</a>
      <a href="#range" class="bak-btn bak-btn-ghost">Explore the Bakery</a>
    </div>
  </div>

  <!-- Opening hours ribbon -->
  <div class="bak-hours-ribbon" aria-label="Opening hours">
    <div class="bak-hours-item"><span>☕</span> <span><strong>Tue – Fri</strong> 07:30 – 17:00</span></div>
    <span class="bak-hours-sep">·</span>
    <div class="bak-hours-item"><span>🌅</span> <span><strong>Sat – Sun</strong> 07:00 – 15:00</span></div>
    <span class="bak-hours-sep">·</span>
    <div class="bak-hours-item"><span>🚪</span> <span><strong>Monday</strong> Closed</span></div>
    <span class="bak-hours-sep">·</span>
    <div class="bak-hours-item"><span>📍</span> <span>Borough Market, London SE1</span></div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     STATS BAND
═══════════════════════════════════════════════════════════════════ -->
<section class="bak-stats" aria-label="Bakery at a glance">
  <div class="bak-wrap">
    <div class="bak-stats-grid">
      <div class="bak-stat">
        <span class="bak-stat-num"><span class="bak-counter" data-target="14">0</span></span>
        <span class="bak-stat-label">Years of Baking</span>
      </div>
      <div class="bak-stat">
        <span class="bak-stat-num"><span class="bak-counter" data-target="4.9">0</span></span>
        <span class="bak-stat-label">Google Rating</span>
      </div>
      <div class="bak-stat">
        <span class="bak-stat-num"><span class="bak-counter" data-target="240">0</span><span class="bak-stat-suf">+</span></span>
        <span class="bak-stat-label">Loaves Baked Daily</span>
      </div>
      <div class="bak-stat">
        <span class="bak-stat-num"><span class="bak-counter" data-target="32">0</span></span>
        <span class="bak-stat-label">Products on Our Menu</span>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     PRODUCT RANGE
═══════════════════════════════════════════════════════════════════ -->
<section class="bak-range-sec" id="range" aria-labelledby="bak-range-h">
  <div class="bak-wrap">
    <div class="bak-range-header">
      <span class="bak-eyebrow">What We Make</span>
      <h2 class="bak-h2" id="bak-range-h">Crafted with the <em>finest ingredients</em></h2>
      <div class="bak-ornament" style="justify-content:center"><div class="bak-ornament-line"></div><span class="bak-ornament-sym">🌾</span><div class="bak-ornament-line"></div></div>
      <p class="bak-lead bak-centre">Everything in our bakery is made by hand in small batches, using stoneground British flours, wild yeasts and traditional methods passed down through years of craft.</p>
    </div>
    <div class="bak-range-grid">
      <?php foreach ($bread_range as $cat): ?>
      <div class="bak-range-card">
        <span class="bak-range-icon"><?= $cat['icon'] ?></span>
        <div class="bak-range-cat"><?= esc_html($cat['cat']) ?></div>
        <p class="bak-range-desc"><?= esc_html($cat['desc']) ?></p>
        <ul class="bak-range-list">
          <?php foreach ($cat['items'] as $item): ?>
          <li><?= $item /* contains pre-escaped HTML entities */ ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     PASTRY SHOWCASE
═══════════════════════════════════════════════════════════════════ -->
<section class="bak-pastry-sec" aria-labelledby="bak-pastry-h">
  <div class="bak-wrap">
    <div class="bak-pastry-header">
      <span class="bak-eyebrow">From the Pastry Counter</span>
      <h2 class="bak-h2" id="bak-pastry-h">Pâtisserie by <em>Clara Fontaine</em></h2>
      <div class="bak-ornament" style="justify-content:center"><div class="bak-ornament-line"></div><span class="bak-ornament-sym">🥐</span><div class="bak-ornament-line"></div></div>
      <p class="bak-lead bak-centre">Our pastry counter opens at 08:00. Quantities are limited — we recommend arriving early for your favourites.</p>
    </div>
    <div class="bak-pastry-grid">
      <?php foreach ($pastries as $p): ?>
      <div class="bak-pastry-card">
        <div class="bak-pastry-art" style="background:linear-gradient(180deg,var(--bak-cream),var(--bak-flour))">
          <div class="bak-pastry-shape">
            <div class="bak-pastry-<?= $p['shape'] ?>"></div>
          </div>
        </div>
        <div class="bak-pastry-body">
          <div class="bak-pastry-name"><?= esc_html($p['name']) ?></div>
          <div class="bak-pastry-price"><?= esc_html($p['price']) ?></div>
          <p class="bak-pastry-desc"><?= esc_html($p['desc']) ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     ABOUT / OUR STORY
═══════════════════════════════════════════════════════════════════ -->
<section class="bak-about-sec" aria-labelledby="bak-about-h">
  <div class="bak-wrap">
    <div class="bak-about-grid">

      <!-- CSS oven illustration -->
      <div class="bak-oven-art" aria-hidden="true">
        <!-- Steam above oven -->
        <div class="bak-oven-steam">
          <?php foreach([0,.8,1.6] as $sd): ?>
          <div class="bak-oven-steam-wisp" style="animation-delay:<?= $sd ?>s"></div>
          <?php endforeach; ?>
        </div>
        <!-- Oven -->
        <div class="bak-oven-body" style="width:240px">
          <div class="bak-oven-top">
            <div class="bak-oven-knob"></div>
            <div class="bak-oven-knob" style="background:radial-gradient(circle,#e87820,#c04810)"></div>
            <div class="bak-oven-knob"></div>
            <div class="bak-oven-knob"></div>
          </div>
          <div class="bak-oven-door">
            <div class="bak-oven-glass"></div>
            <div class="bak-oven-shelf-art"></div>
            <div class="bak-oven-loaf-art"></div>
          </div>
          <div class="bak-oven-bottom"></div>
        </div>
        <!-- Bread on counter around oven -->
        <div class="bak-counter-art">
          <div class="bak-counter-loaf" style="width:54px;height:36px;background:#8a4a1a">
            <div class="bak-counter-top" style="background:#6a3010;width:90%;height:55%;border-radius:50%"></div>
          </div>
          <div class="bak-counter-loaf" style="width:42px;height:50px;background:#c8702a;border-radius:6px;transform:rotate(-8deg)">
          </div>
          <div class="bak-counter-loaf" style="width:60px;height:38px;background:#7a3a18">
            <div class="bak-counter-top" style="background:#5a2808;width:90%;height:55%;border-radius:50%"></div>
          </div>
        </div>
        <div class="bak-flour-dusting"></div>
      </div>

      <!-- Story text -->
      <div class="bak-about-text">
        <span class="bak-eyebrow">Our Story</span>
        <h2 class="bak-h2" id="bak-about-h">Bread baked <em>the long way</em></h2>
        <div class="bak-ornament"><div class="bak-ornament-line"></div><span class="bak-ornament-sym">🌾</span><div class="bak-ornament-line"></div></div>
        <p class="bak-lead">Seven Grains began in 2011 when Émile and Clara left their positions in starred restaurants and opened a market stall at Borough with twelve loaves and a folding table. The queue stretched around the corner by noon, and the rest, as they say, is dough.</p>
        <p class="bak-lead" style="margin-top:14px">Today we bake more than 240 loaves and 180 pastries every day, but the philosophy has never changed: slow fermentation, premium ingredients, and the same wild starter Émile brought from Lyon.</p>
        <div class="bak-about-milestones">
          <div class="bak-milestone">
            <div class="bak-milestone-year">2011</div>
            <div class="bak-milestone-body">
              <div class="bak-milestone-title">Borough Market stall opens</div>
              <div class="bak-milestone-desc">12 sourdough loaves. Sold out in 90 minutes. We knew something was there.</div>
            </div>
          </div>
          <div class="bak-milestone">
            <div class="bak-milestone-year">2014</div>
            <div class="bak-milestone-body">
              <div class="bak-milestone-title">Permanent bakery opens</div>
              <div class="bak-milestone-desc">We moved from the market stall into our current premises, adding the wood-fired oven.</div>
            </div>
          </div>
          <div class="bak-milestone">
            <div class="bak-milestone-year">2018</div>
            <div class="bak-milestone-body">
              <div class="bak-milestone-title">Great Taste 3-Star Award</div>
              <div class="bak-milestone-desc">Our classic white sourdough was awarded the highest distinction by the Guild of Fine Food.</div>
            </div>
          </div>
          <div class="bak-milestone">
            <div class="bak-milestone-year">2022</div>
            <div class="bak-milestone-body">
              <div class="bak-milestone-title">Bread subscription launches</div>
              <div class="bak-milestone-desc">Weekly subscriptions now serve 620+ households across London every Thursday.</div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     TEAM
═══════════════════════════════════════════════════════════════════ -->
<section class="bak-team-sec" aria-labelledby="bak-team-h">
  <div class="bak-wrap">
    <div class="bak-team-header">
      <span class="bak-eyebrow">The People Behind the Bread</span>
      <h2 class="bak-h2" id="bak-team-h">Made by <em>human hands</em></h2>
      <div class="bak-ornament" style="justify-content:center"><div class="bak-ornament-line" style="background:linear-gradient(90deg,transparent,rgba(212,148,58,.4),transparent)"></div><span class="bak-ornament-sym" style="color:var(--bak-wheat)">🌾</span><div class="bak-ornament-line" style="background:linear-gradient(90deg,transparent,rgba(212,148,58,.4),transparent)"></div></div>
    </div>
    <div class="bak-team-grid">
      <?php foreach ($team as $idx => $m): ?>
      <div class="bak-team-card">
        <div class="bak-baker-art">
          <div class="bak-baker-fig">
            <div class="bak-chef-hat-tall"></div>
            <div class="bak-chef-hat-brim"></div>
            <div class="bak-baker-head" style="background:<?= esc_attr($m['skin']) ?>"></div>
            <div class="bak-baker-body" style="background:<?= esc_attr($m['top']) ?>">
              <div class="bak-baker-apron" style="background:<?= esc_attr($m['apron']) ?>"></div>
              <div class="bak-baker-arms">
                <div class="bak-baker-arm bak-baker-arm-l" style="background:<?= esc_attr($m['skin']) ?>"></div>
                <div class="bak-baker-arm bak-baker-arm-r" style="background:<?= esc_attr($m['skin']) ?>"></div>
              </div>
              <?php if ($idx === 0): ?>
              <div class="bak-held-loaf"></div>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <div class="bak-team-body">
          <div class="bak-team-name"><?= esc_html($m['name']) ?></div>
          <div class="bak-team-role"><?= esc_html($m['role']) ?></div>
          <div class="bak-team-origin"><?= esc_html($m['origin']) ?></div>
          <p class="bak-team-bio"><?= esc_html($m['bio']) ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     TESTIMONIALS
═══════════════════════════════════════════════════════════════════ -->
<section class="bak-test-sec" aria-labelledby="bak-test-h">
  <div class="bak-wrap">
    <div class="bak-test-header">
      <span class="bak-eyebrow">Customer Stories</span>
      <h2 class="bak-h2" id="bak-test-h">From the mouths of <em>happy customers</em></h2>
      <div class="bak-ornament" style="justify-content:center"><div class="bak-ornament-line"></div><span class="bak-ornament-sym">🥐</span><div class="bak-ornament-line"></div></div>
    </div>
    <div class="bak-test-grid">
      <?php foreach ($testimonials as $t): ?>
      <div class="bak-test-card">
        <div class="bak-test-stars"><?= str_repeat('★', $t['stars']) ?></div>
        <p class="bak-test-quote"><?= $t['quote'] /* pre-escaped in PHP data */ ?></p>
        <div class="bak-test-name"><?= $t['name'] ?></div>
        <div class="bak-test-loc"><?= esc_html($t['loc']) ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     FAQ
═══════════════════════════════════════════════════════════════════ -->
<section class="bak-faq-sec" aria-labelledby="bak-faq-h">
  <div class="bak-wrap">
    <div class="bak-faq-inner">
      <div class="bak-faq-header">
        <span class="bak-eyebrow">Your Questions Answered</span>
        <h2 class="bak-h2" id="bak-faq-h">Good things are worth <em>asking about</em></h2>
        <div class="bak-ornament" style="justify-content:center"><div class="bak-ornament-line"></div><span class="bak-ornament-sym">🌾</span><div class="bak-ornament-line"></div></div>
      </div>
      <div class="bak-faq-list">
        <?php foreach ($faqs as $fi => $faq): ?>
        <div class="bak-faq-item" id="bak-faq-<?= $fi ?>">
          <button class="bak-faq-q" aria-expanded="false" aria-controls="bak-faq-a-<?= $fi ?>">
            <span><?= esc_html($faq['q']) ?></span>
            <span class="bak-faq-icon" aria-hidden="true">+</span>
          </button>
          <div class="bak-faq-a" id="bak-faq-a-<?= $fi ?>" role="region">
            <div class="bak-faq-a-inner"><?= esc_html($faq['a']) ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     ORDER / ENQUIRY FORM
═══════════════════════════════════════════════════════════════════ -->
<section class="bak-order-sec" id="order" aria-labelledby="bak-order-h">
  <div class="bak-wrap">
    <div class="bak-order-wrap">

      <div class="bak-order-info">
        <span class="bak-eyebrow">Get in Touch</span>
        <h2 class="bak-h2" id="bak-order-h">Order something <em>special</em></h2>
        <div class="bak-ornament"><div class="bak-ornament-line" style="background:linear-gradient(90deg,transparent,rgba(255,255,255,.3),transparent)"></div><span class="bak-ornament-sym" style="color:var(--bak-wheat-lt)">🌾</span><div class="bak-ornament-line" style="background:linear-gradient(90deg,transparent,rgba(255,255,255,.3),transparent)"></div></div>
        <p class="bak-lead">Celebration cakes, wholesale enquiries, bread subscriptions or just a question — we'd love to hear from you. We respond to all enquiries within one working day.</p>
        <div class="bak-order-details">
          <div class="bak-detail-row"><div class="bak-detail-icon">📍</div><span>Borough Market, 8 Southwark St, London SE1 1TL</span></div>
          <div class="bak-detail-row"><div class="bak-detail-icon">📞</div><span>+44 (0)20 7407 0000</span></div>
          <div class="bak-detail-row"><div class="bak-detail-icon">✉️</div><span>hello@sevengrainsartisan.co.uk</span></div>
          <div class="bak-detail-row"><div class="bak-detail-icon">⏰</div><span>Custom orders require 10 days' notice minimum</span></div>
        </div>
      </div>

      <div class="bak-form-card">
        <div class="bak-form-title">Send Us an Enquiry</div>
        <form method="post" action="" novalidate>
          <?php wp_nonce_field('tf_bak_enquiry','tf_bak_nonce'); ?>
          <div class="bak-field-row">
            <div class="bak-field">
              <label for="bak-fname">First Name</label>
              <input type="text" id="bak-fname" name="tf_first_name" required autocomplete="given-name" placeholder="e.g. Laura">
            </div>
            <div class="bak-field">
              <label for="bak-lname">Last Name</label>
              <input type="text" id="bak-lname" name="tf_last_name" required autocomplete="family-name" placeholder="e.g. Bennett">
            </div>
          </div>
          <div class="bak-field">
            <label for="bak-email">Email Address</label>
            <input type="email" id="bak-email" name="tf_email" required autocomplete="email" placeholder="you@example.com">
          </div>
          <div class="bak-field">
            <label for="bak-phone">Phone Number (optional)</label>
            <input type="tel" id="bak-phone" name="tf_phone" autocomplete="tel" placeholder="+44 7700 000000">
          </div>
          <div class="bak-field">
            <label for="bak-enquiry">Type of Enquiry</label>
            <select id="bak-enquiry" name="tf_enquiry_type">
              <option value="">— Please select —</option>
              <option value="celebration_cake">Celebration Cake Order</option>
              <option value="subscription">Bread Subscription</option>
              <option value="wholesale">Wholesale Enquiry</option>
              <option value="event_catering">Event Catering</option>
              <option value="custom_order">Custom Order</option>
              <option value="general">General Question</option>
            </select>
          </div>
          <div class="bak-field">
            <label for="bak-date">Required By (if applicable)</label>
            <input type="date" id="bak-date" name="tf_required_date" min="<?= esc_attr(date('Y-m-d', strtotime('+10 days'))) ?>">
          </div>
          <div class="bak-field">
            <label for="bak-message">Tell Us More</label>
            <textarea id="bak-message" name="tf_message" placeholder="Please describe your order or question in as much detail as possible — quantity, flavours, dietary requirements…"></textarea>
          </div>
          <button type="submit" class="bak-form-submit">Send Enquiry</button>
          <p class="bak-form-note">We respond within one working day. Custom orders require a minimum of 10 days' notice.</p>
        </form>
      </div>

    </div>
  </div>
</section>
<script>
(function(){
  /* ── Animated counters ────────────────────────────────────────── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  document.querySelectorAll('.bak-counter').forEach(el => {
    const raw = el.dataset.target;
    if (!raw) return;
    const isFloat = raw.indexOf('.') !== -1;
    const target  = parseFloat(raw);
    if (isNaN(target)) return;
    let started = false;
    const obs = new IntersectionObserver(entries => {
      if (!entries[0].isIntersecting || started) return;
      started = true; obs.disconnect();
      const dur = 1800, start = performance.now();
      const tick = now => {
        const t   = Math.min((now - start) / dur, 1);
        const val = target * easeOut(t);
        el.textContent = isFloat ? val.toFixed(1) : Math.round(val).toLocaleString();
        if (t < 1) requestAnimationFrame(tick);
        else el.textContent = isFloat ? target.toFixed(1) : target.toLocaleString();
      };
      requestAnimationFrame(tick);
    }, {threshold:.3});
    obs.observe(el);
  });

  /* ── FAQ accordion ────────────────────────────────────────────── */
  document.querySelectorAll('.bak-faq-q').forEach(btn => {
    btn.addEventListener('click', () => {
      const item   = btn.closest('.bak-faq-item');
      const answer = item.querySelector('.bak-faq-a');
      const isOpen = item.classList.contains('open');
      document.querySelectorAll('.bak-faq-item.open').forEach(op => {
        op.classList.remove('open');
        op.querySelector('.bak-faq-a').style.maxHeight = '0';
        op.querySelector('.bak-faq-q').setAttribute('aria-expanded','false');
      });
      if (!isOpen) {
        item.classList.add('open');
        answer.style.maxHeight = answer.scrollHeight + 'px';
        btn.setAttribute('aria-expanded','true');
      }
    });
  });
})();
</script>
</div><!-- .bak-page -->
<?php get_footer(); ?>
