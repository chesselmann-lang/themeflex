<?php
/**
 * Template Name: TF — Beauty Salon & Spa
 *
 * Premium beauty salon & day spa homepage template.
 * Namespace : --bty-*
 * Fonts     : Italiana + Nunito Sans (Google Fonts)
 * Palette   : blush #f5d8d0 · charcoal #2a2a2a · rose-gold #c8947a · sage #8a9a7a · cream #faf6f2
 *
 * @package ThemeFlex
 */

defined('ABSPATH') || exit;

/* ── deterministic randomness ───────────────────────────────────────── */
srand(crc32(get_the_permalink()));

/* ── PHP data ───────────────────────────────────────────────────────── */
$services = [
    ['cat'=>'face',  'name'=>__('Signature Facial','themeflex'),         'duration'=>75, 'price'=>'145','desc'=>__('Deep-cleansing, customised to your skin type. Extractions, hydration mask and facial massage.','themeflex')],
    ['cat'=>'face',  'name'=>__('Anti-Age Vitamin C','themeflex'),       'duration'=>60, 'price'=>'165','desc'=>__('Brightening Vitamin C serum infusion with micro-current lifting. Instant glow, long-term firmness.','themeflex')],
    ['cat'=>'body',  'name'=>__('Rasul Mud Ritual','themeflex'),         'duration'=>90, 'price'=>'185','desc'=>__('Two-phase volcanic mud treatment in our private steam chamber. Detox, soften, renew.','themeflex')],
    ['cat'=>'body',  'name'=>__('Hot Stone Massage','themeflex'),        'duration'=>80, 'price'=>'145','desc'=>__('Basalt stones warmed to 55°C combined with a full-body oil massage. Deep relaxation.','themeflex')],
    ['cat'=>'nails', 'name'=>__('Luxury Manicure','themeflex'),          'duration'=>50, 'price'=>'68', 'desc'=>__('Soak, scrub, cuticle care, nail shaping and your choice of gel or classic polish.','themeflex')],
    ['cat'=>'nails', 'name'=>__('Paraffin Pedicure','themeflex'),        'duration'=>65, 'price'=>'85', 'desc'=>__('Warm paraffin wrap, exfoliation, callus removal and a nourishing foot massage.','themeflex')],
    ['cat'=>'hair',  'name'=>__('Colour & Style','themeflex'),           'duration'=>120,'price'=>'195','desc'=>__('Full colour service, toner, blow-dry and finish by our senior colourist.','themeflex')],
    ['cat'=>'hair',  'name'=>__('Keratin Treatment','themeflex'),        'duration'=>150,'price'=>'245','desc'=>__('Brazilian keratin smoothing for frizz-free, glossy hair lasting up to 4 months.','themeflex')],
];

$packages = [
    [
        'name'     =>__('Rose Gold Ritual','themeflex'),
        'duration' =>3,
        'price'    =>'320',
        'includes' =>['Signature Facial (75 min)','Hot Stone Full-Body Massage (80 min)','Luxury Manicure','Glass of Prosecco & Light Snack'],
        'tag'      =>'Best Seller',
        'color'    =>'#c8947a',
    ],
    [
        'name'     =>__('Pure Radiance Day','themeflex'),
        'duration' =>5,
        'price'    =>'490',
        'includes' =>['Anti-Age Facial (60 min)','Rasul Mud Ritual (90 min)','Paraffin Pedicure','Colour & Blow-Dry','3-Course Spa Lunch'],
        'tag'      =>'',
        'color'    =>'#8a9a7a',
    ],
    [
        'name'     =>__('Bridal Preparation','themeflex'),
        'duration' =>6,
        'price'    =>'680',
        'includes' =>['Full Day for Bride + 2 Guests','Signature Facial each','Luxury Mani & Pedi each','Professional Bridal Makeup','Champagne & Petit Fours','Complimentary Photo Session'],
        'tag'      =>'',
        'color'    =>'#b890c8',
    ],
];

$team = [
    ['name'=>'Sophie Laurent',  'role'=>__('Lead Therapist','themeflex'),       'years'=>11,'cert'=>'CIDESCO, ITEC'],
    ['name'=>'Mia Richter',     'role'=>__('Skin Specialist','themeflex'),       'years'=>7, 'cert'=>'VTCT Level 4'],
    ['name'=>'Lara Weber',      'role'=>__('Hair Colourist','themeflex'),        'years'=>9, 'cert'=>'L\'Oréal Expert'],
    ['name'=>'Emma Fischer',    'role'=>__('Nail Technician','themeflex'),       'years'=>6, 'cert'=>'OPI Certified'],
];

$testimonials = [
    ['q'=>'Sophie\'s Signature Facial is the most relaxing hour of my month. My skin has never looked this healthy. The whole experience is pure luxury from start to finish.','n'=>'Klara B.','city'=>'Munich'],
    ['q'=>'The Rose Gold Ritual package was a birthday gift and it was absolutely perfect. Three hours of complete bliss. I left feeling like a completely different person.','n'=>'Franziska L.','city'=>'Augsburg'],
    ['q'=>'Lara is simply the best colourist in Bavaria. She understood exactly what I wanted, delivered it perfectly and the blow-dry alone was worth the trip.','n'=>'Nina S.','city'=>'Garmisch'],
];

$awards = ['CIDESCO Recognised','Vogue Beauty Award','OPI Signature Salon','Spas of Germany Partner','Allure Best Salon 2024','ITEC Gold Standard','WaxPro Certified','Dermalogica Partner'];

/* ── PHP-generated floating petals ── */
$petals = [];
for($i=0;$i<20;$i++){
    $petals[] = [
        'x'  =>rand(2,98),
        'y'  =>rand(5,90),
        's'  =>rand(8,20),
        'op' =>rand(10,30)/100,
        'rot'=>rand(0,360),
        'dur'=>rand(30,60)/10,
        'del'=>rand(0,5000),
    ];
}

/* ── PHP-generated bokeh blobs ── */
$bokeh = [];
for($i=0;$i<14;$i++){
    $bokeh[] = [
        'x'  =>rand(2,98),
        'y'  =>rand(2,98),
        's'  =>rand(40,120),
        'op' =>rand(3,10)/100,
        'del'=>rand(0,4000),
    ];
}

get_header(); ?>
<!-- ================================================================
     GOOGLE FONTS
================================================================ -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Italiana&family=Nunito+Sans:ital,wght@0,300;0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">

<style>
/* ================================================================
   ROOT TOKENS — BEAUTY
================================================================ */
:root{
  --bty-blush:  #f5d8d0;
  --bty-char:   #2a2a2a;
  --bty-rg:     #c8947a;
  --bty-sage:   #8a9a7a;
  --bty-cream:  #faf6f2;
  --bty-warm:   #f2ede7;
  --bty-muted:  #8a7a72;
  --bty-dark:   #1a1410;
  --bty-mauve:  #b890c8;
  --bty-ff-ser: 'Italiana', Georgia, serif;
  --bty-ff-san: 'Nunito Sans', system-ui, sans-serif;
  --bty-r:      8px;
  --bty-trans:  .3s ease;
}

/* ================================================================
   GLOBAL RESET
================================================================ */
.bty-page *{box-sizing:border-box;margin:0;padding:0;}
.bty-page{font-family:var(--bty-ff-san);color:var(--bty-char);background:var(--bty-cream);overflow-x:hidden;}
.bty-container{max-width:1180px;margin:0 auto;padding:0 2rem;}
.bty-section{padding:6rem 0;}
.bty-section--alt{background:var(--bty-warm);}
.bty-section--dark{background:var(--bty-char);color:var(--bty-cream);}

/* ================================================================
   HERO
================================================================ */
.bty-hero{
  min-height:100vh;
  background:linear-gradient(150deg,#fcf0ec 0%,#f5d8d0 40%,#ead0c8 70%,#e0c4b8 100%);
  display:grid;
  grid-template-columns:1fr 1fr;
  align-items:center;
  gap:3rem;
  padding:9rem 2rem 5rem;
  max-width:1180px;
  margin:0 auto;
  position:relative;
}

/* Petals */
.bty-petal{
  position:fixed;
  border-radius:60% 40% 70% 30% / 50% 60% 40% 70%;
  background:var(--bty-rg);
  pointer-events:none;z-index:0;
  animation:bty-drift var(--bty-dur,4s) ease-in-out var(--bty-del,0ms) infinite alternate;
}
@keyframes bty-drift{
  from{transform:translateY(0) rotate(0deg);}
  to{transform:translateY(-15px) rotate(15deg);}
}

/* Bokeh blobs */
.bty-bokeh{
  position:fixed;border-radius:50%;
  background:radial-gradient(circle,rgba(200,148,122,.25) 0%,transparent 70%);
  pointer-events:none;z-index:0;
  animation:bty-pulse 4s ease-in-out infinite alternate;
}
@keyframes bty-pulse{from{transform:scale(1);}to{transform:scale(1.3);}}

/* ── Hero copy ── */
.bty-hero__copy{position:relative;z-index:1;}
.bty-hero__eyebrow{
  display:inline-flex;align-items:center;gap:.7rem;
  font-family:var(--bty-ff-san);font-size:.72rem;font-weight:700;
  letter-spacing:.22em;text-transform:uppercase;color:var(--bty-rg);
  margin-bottom:1.2rem;
}
.bty-hero__eyebrow::before{content:'';display:inline-block;width:2rem;height:1px;background:var(--bty-rg);}
.bty-hero__h1{
  font-family:var(--bty-ff-ser);font-size:clamp(3.5rem,6vw,6rem);
  font-weight:400;line-height:1.05;color:var(--bty-char);
  margin-bottom:1.4rem;
}
.bty-hero__h1 em{color:var(--bty-rg);}
.bty-hero__lead{
  font-size:1rem;line-height:1.8;color:var(--bty-muted);max-width:46ch;margin-bottom:2.2rem;
}
.bty-hero__ctas{display:flex;gap:1rem;flex-wrap:wrap;}
.bty-btn{
  display:inline-flex;align-items:center;gap:.5rem;
  padding:.85rem 2rem;border-radius:30px;
  font-family:var(--bty-ff-san);font-size:.85rem;font-weight:700;
  letter-spacing:.06em;text-decoration:none;cursor:pointer;
  border:1.5px solid transparent;transition:var(--bty-trans);
}
.bty-btn--primary{background:var(--bty-rg);color:#fff;}
.bty-btn--primary:hover{background:#b87a60;transform:translateY(-2px);}
.bty-btn--outline{border-color:var(--bty-rg);color:var(--bty-rg);}
.bty-btn--outline:hover{background:var(--bty-rg);color:#fff;}

/* ── Hero art: CSS vanity table ── */
.bty-hero__art{
  position:relative;height:500px;display:flex;align-items:flex-end;justify-content:center;
  z-index:1;
}

/* Mirror */
.bty-mirror{
  position:absolute;top:10px;left:50%;transform:translateX(-50%);
  width:180px;height:220px;
  border-radius:90px 90px 16px 16px;
  background:linear-gradient(160deg,#f0e8f0 0%,#e0d0d8 50%,#d8c8d0 100%);
  border:5px solid #c8947a;
  box-shadow:4px 4px 0 #b07858,0 0 30px rgba(200,148,122,.25),inset 0 2px 8px rgba(255,255,255,.5);
  overflow:hidden;
  z-index:2;
}
.bty-mirror::before{
  content:'';position:absolute;top:10px;left:10px;right:10px;bottom:10px;
  border-radius:80px 80px 10px 10px;
  background:linear-gradient(150deg,rgba(255,255,255,.3) 0%,rgba(255,255,255,.05) 100%);
  border:1px solid rgba(255,255,255,.4);
}
.bty-mirror::after{
  content:'';position:absolute;top:15px;left:15px;
  width:30px;height:50px;
  background:rgba(255,255,255,.25);
  border-radius:50%;
  transform:rotate(-20deg);
}
/* Mirror bulbs (Hollywood style) */
.bty-mirror-bulbs{
  position:absolute;top:0;left:0;right:0;bottom:0;
  pointer-events:none;
}
.bty-bulb{
  position:absolute;
  width:10px;height:10px;
  border-radius:50%;
  background:radial-gradient(circle at 38% 35%,#fff9e0,#f0c848);
  box-shadow:0 0 6px 3px rgba(255,220,100,.45);
}

/* Mirror stand / base */
.bty-mirror-stand{
  position:absolute;top:222px;left:50%;transform:translateX(-50%);
  width:4px;height:22px;
  background:var(--bty-rg);
}
.bty-mirror-base{
  position:absolute;top:242px;left:50%;transform:translateX(-50%);
  width:60px;height:10px;
  background:linear-gradient(180deg,#c8947a 0%,#a87858 100%);
  border-radius:5px;
}

/* Vanity table */
.bty-table{
  position:absolute;bottom:0;left:50%;transform:translateX(-50%);
  width:360px;height:120px;
}
.bty-table__top{
  position:absolute;top:0;left:0;right:0;height:16px;
  background:linear-gradient(180deg,#e8dac8 0%,#d8c8b0 100%);
  border-radius:8px 8px 0 0;
  box-shadow:0 2px 8px rgba(0,0,0,.1);
}
.bty-table__body{
  position:absolute;top:16px;left:0;right:0;bottom:0;
  background:linear-gradient(180deg,#d8c8b0 0%,#c8b098 100%);
}
.bty-table__drawer{
  position:absolute;top:26px;left:10%;width:80%;height:32px;
  border:1px solid rgba(200,148,122,.3);border-radius:3px;
  background:rgba(255,255,255,.08);display:flex;align-items:center;justify-content:center;
}
.bty-table__knob{
  width:16px;height:6px;border-radius:3px;
  background:var(--bty-rg);box-shadow:0 1px 3px rgba(0,0,0,.15);
}
/* Legs */
.bty-table__legs{
  position:absolute;bottom:-16px;left:0;right:0;
  display:flex;justify-content:space-between;padding:0 20px;
}
.bty-table__leg{
  width:8px;height:18px;
  background:linear-gradient(180deg,#c8b098 0%,#a89070 100%);
  border-radius:2px;
}

/* Items on table */
/* Perfume bottle */
.bty-perfume{
  position:absolute;bottom:16px;left:18%;
}
.bty-perfume__cap{
  width:20px;height:12px;
  background:linear-gradient(180deg,#d4a880 0%,#c8947a 100%);
  border-radius:3px 3px 0 0;margin:0 auto;
}
.bty-perfume__neck{
  width:14px;height:8px;
  background:linear-gradient(180deg,#e8d8c0 0%,#d8c8a8 100%);
  border:1px solid rgba(200,148,122,.3);margin:0 auto;
}
.bty-perfume__bottle{
  width:32px;height:42px;
  background:linear-gradient(135deg,#e0d0f8 0%,#c8b8e8 50%,#a890c8 100%);
  border-radius:4px;
  border:1px solid rgba(200,148,122,.2);
  box-shadow:inset 2px 2px 6px rgba(255,255,255,.4),2px 2px 6px rgba(0,0,0,.08);
  position:relative;overflow:hidden;
}
.bty-perfume__bottle::before{
  content:'';position:absolute;top:6px;left:5px;width:8px;height:20px;
  background:rgba(255,255,255,.2);border-radius:50%;
}
.bty-perfume__label{
  position:absolute;bottom:8px;left:3px;right:3px;height:14px;
  background:rgba(255,255,255,.3);border-radius:2px;
  font-family:var(--bty-ff-ser);font-size:5px;display:flex;align-items:center;justify-content:center;
  color:rgba(100,60,80,.6);letter-spacing:.04em;
}

/* Lipstick -->
.bty-lipstick{
  position:absolute;bottom:16px;left:30%;
  display:flex;flex-direction:column;align-items:center;
}
.bty-lipstick__tube{
  width:14px;height:34px;
  background:linear-gradient(180deg,#c82040 0%,#901030 100%);
  border-radius:7px 7px 2px 2px;
  position:relative;
  box-shadow:1px 1px 4px rgba(0,0,0,.15);
}
.bty-lipstick__tube::before{
  content:'';position:absolute;top:2px;left:3px;width:3px;height:12px;
  background:rgba(255,255,255,.2);border-radius:50%;
}
.bty-lipstick__base{
  width:18px;height:28px;
  background:linear-gradient(180deg,#a8a098 0%,#888078 100%);
  border-radius:2px;
}
.bty-lipstick__cap{
  position:absolute;bottom:0;left:-2px;right:-2px;height:10px;
  background:linear-gradient(180deg,#a8a098 0%,#888078 100%);
  border-radius:2px;
}

/* Makeup brush */
.bty-brush{
  position:absolute;bottom:14px;right:25%;
  transform:rotate(-15deg);
  transform-origin:bottom center;
  display:flex;flex-direction:column;align-items:center;
}
.bty-brush__bristles{
  width:16px;height:28px;
  background:linear-gradient(180deg,#d4b8a8 0%,#c8a898 100%);
  border-radius:50% 50% 30% 30%;
}
.bty-brush__ferrule{
  width:10px;height:8px;
  background:linear-gradient(90deg,#c8c0b8,#b8b0a8);
  border-radius:1px;
}
.bty-brush__handle{
  width:8px;height:60px;
  background:linear-gradient(180deg,#2a2a2a 0%,#1a1a1a 100%);
  border-radius:4px;
}

/* Foundation bottle */
.bty-foundation{
  position:absolute;bottom:16px;right:14%;
}
.bty-foundation__bottle{
  width:28px;height:52px;
  background:linear-gradient(180deg,#f0e8d8 0%,#e0d0b8 100%);
  border-radius:14px 14px 4px 4px;
  border:1px solid rgba(200,148,122,.25);
  position:relative;
  box-shadow:1px 1px 6px rgba(0,0,0,.08);
}
.bty-foundation__pump{
  position:absolute;top:-16px;left:50%;transform:translateX(-50%);
  width:4px;height:18px;background:var(--bty-rg);border-radius:2px;
}
.bty-foundation__pump::before{
  content:'';position:absolute;top:-4px;left:50%;transform:translateX(-50%);
  width:10px;height:6px;background:var(--bty-rg);border-radius:2px 2px 0 0;
}

/* Candle */
.bty-candle{
  position:absolute;bottom:16px;right:32%;
}
.bty-candle__body{
  width:22px;height:38px;
  background:linear-gradient(180deg,#f8f0e8 0%,#e8d8c0 100%);
  border-radius:3px;
  position:relative;
}
.bty-candle__wax{
  position:absolute;top:0;left:0;right:0;height:6px;
  background:radial-gradient(ellipse at 50% 0%,#f0e0c8 0%,#d8c8a8 100%);
  border-radius:50%;
}
.bty-candle__wick{
  position:absolute;top:-8px;left:50%;transform:translateX(-50%);
  width:1.5px;height:8px;background:#3a2010;
}
.bty-candle__flame{
  position:absolute;top:-20px;left:50%;transform:translateX(-50%);
  width:8px;height:14px;
  background:radial-gradient(ellipse at 50% 80%,#f0c820 0%,#f07820 60%,#c84000 100%);
  border-radius:50% 50% 30% 30%;
  animation:bty-flame .4s ease-in-out infinite alternate;
}
@keyframes bty-flame{
  from{transform:translateX(-50%) scaleX(1);}
  to{transform:translateX(-50%) scaleX(.8);}
}

/* Rose */
.bty-rose{
  position:absolute;bottom:14px;left:10%;
}
.bty-rose__stem{
  width:2px;height:36px;background:#5a8a4a;
}
.bty-rose__head{
  position:absolute;top:-18px;left:50%;transform:translateX(-50%);
  width:22px;height:20px;
  background:radial-gradient(ellipse at 50% 60%,#f0a8b0 0%,#d84060 60%,#b82040 100%);
  border-radius:50% 50% 40% 40%;
  box-shadow:0 2px 6px rgba(180,30,60,.2);
}
.bty-rose__leaf{
  position:absolute;top:20px;left:-10px;
  width:12px;height:8px;background:#5a8a4a;border-radius:50%;
  transform:rotate(-30deg);
}

/* Scattered petals on table */
.bty-table-petal{
  position:absolute;bottom:18px;
  border-radius:60% 40% 70% 30% / 50% 60% 40% 70%;
  background:rgba(200,148,122,.4);
}

/* Vanity stool */
.bty-stool{
  position:absolute;bottom:-30px;left:50%;transform:translateX(-50%);
}
.bty-stool__seat{
  width:100px;height:28px;
  background:linear-gradient(180deg,#e8c8c0 0%,#d8b0a8 100%);
  border-radius:50px;
  box-shadow:0 3px 8px rgba(0,0,0,.1);
}
.bty-stool__legs-wrap{
  display:flex;justify-content:center;gap:40px;margin-top:2px;
}
.bty-stool__leg{
  width:6px;height:24px;
  background:linear-gradient(180deg,#c8947a 0%,#a87858 100%);
  border-radius:3px;transform:rotate(6deg);
}
.bty-stool__leg:last-child{transform:rotate(-6deg);}

/* ================================================================
   AWARDS MARQUEE
================================================================ */
.bty-marquee-wrap{
  background:var(--bty-rg);padding:.8rem 0;overflow:hidden;
}
.bty-marquee-track{
  display:flex;align-items:center;width:max-content;
  animation:bty-marquee 26s linear infinite;
}
.bty-marquee-track:hover{animation-play-state:paused;}
@keyframes bty-marquee{to{transform:translateX(-50%);}}
.bty-marquee-item{
  padding:0 2.2rem;white-space:nowrap;
  font-family:var(--bty-ff-san);font-size:.75rem;font-weight:700;
  letter-spacing:.16em;text-transform:uppercase;color:rgba(255,255,255,.85);
  display:flex;align-items:center;gap:1rem;
}
.bty-marquee-item::before{content:'✿';font-size:.6rem;}

/* ================================================================
   SECTION HEADER
================================================================ */
.bty-section-header{text-align:center;margin-bottom:3.5rem;}
.bty-section-header__label{
  display:inline-flex;align-items:center;gap:.6rem;
  font-size:.7rem;font-weight:700;letter-spacing:.22em;text-transform:uppercase;
  color:var(--bty-rg);margin-bottom:.8rem;
}
.bty-section-header__label::before,.bty-section-header__label::after{
  content:'';display:inline-block;width:1.8rem;height:1px;background:var(--bty-rg);
}
.bty-section-header__h2{
  font-family:var(--bty-ff-ser);font-size:clamp(2.2rem,4vw,3.5rem);
  font-weight:400;color:var(--bty-char);margin-bottom:.6rem;
}
.bty-section--dark .bty-section-header__h2{color:var(--bty-cream);}
.bty-section-header__h2 em{font-style:italic;color:var(--bty-rg);}
.bty-section-header__sub{font-size:.95rem;line-height:1.75;color:var(--bty-muted);max-width:55ch;margin:0 auto;}
.bty-section--dark .bty-section-header__sub{color:rgba(250,246,242,.5);}

/* ================================================================
   SERVICES
================================================================ */
.bty-filter-bar{
  display:flex;justify-content:center;gap:.6rem;flex-wrap:wrap;margin-bottom:2.5rem;
}
.bty-filter-btn{
  padding:.45rem 1.3rem;border:1px solid #d8c8bc;border-radius:30px;
  font-family:var(--bty-ff-san);font-size:.78rem;font-weight:600;
  background:transparent;color:var(--bty-muted);cursor:pointer;transition:var(--bty-trans);
}
.bty-filter-btn:hover,.bty-filter-btn.active{
  border-color:var(--bty-rg);background:var(--bty-rg);color:#fff;
}
.bty-services-grid{
  display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:1.5rem;
}
.bty-services-grid .hidden{display:none;}
.bty-service-card{
  background:#fff;border-radius:var(--bty-r);padding:1.8rem;
  box-shadow:0 2px 20px rgba(42,26,16,.05);
  border-top:3px solid var(--bty-blush);
  transition:var(--bty-trans);position:relative;overflow:hidden;
}
.bty-service-card::after{
  content:'';position:absolute;top:0;left:0;right:0;height:3px;
  background:var(--bty-rg);transform:scaleX(0);transform-origin:left;transition:transform .35s ease;
}
.bty-service-card:hover::after{transform:scaleX(1);}
.bty-service-card:hover{transform:translateY(-3px);}
.bty-service-name{
  font-family:var(--bty-ff-ser);font-size:1.25rem;color:var(--bty-char);margin-bottom:.3rem;
}
.bty-service-meta{
  display:flex;gap:1rem;margin-bottom:.8rem;
}
.bty-service-dur,.bty-service-price{
  font-size:.75rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;
}
.bty-service-dur{color:var(--bty-sage);}
.bty-service-price{color:var(--bty-rg);}
.bty-service-desc{font-size:.87rem;line-height:1.7;color:var(--bty-muted);}

/* ================================================================
   PACKAGES
================================================================ */
.bty-packages-grid{
  display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:2rem;
}
.bty-pkg{
  background:#fff;border-radius:var(--bty-r);overflow:hidden;
  box-shadow:0 4px 30px rgba(42,26,16,.08);
  transition:var(--bty-trans);position:relative;
}
.bty-pkg:hover{transform:translateY(-4px);}
.bty-pkg__top{
  padding:1.8rem 2rem 1.5rem;
  background:linear-gradient(135deg,var(--bty-blush) 0%,#f0d0c8 100%);
  border-bottom:2px solid var(--bty-pkg-color,var(--bty-rg));
  position:relative;
}
.bty-pkg__tag{
  position:absolute;top:14px;right:14px;
  font-size:.65rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;
  padding:.2rem .65rem;border-radius:20px;
  background:var(--bty-rg);color:#fff;
}
.bty-pkg__name{
  font-family:var(--bty-ff-ser);font-size:1.6rem;color:var(--bty-char);margin-bottom:.5rem;
}
.bty-pkg__duration{
  font-size:.78rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;
  color:var(--bty-muted);margin-bottom:.3rem;
}
.bty-pkg__price{
  font-family:var(--bty-ff-ser);font-size:2.5rem;color:var(--bty-char);line-height:1;
}
.bty-pkg__price sup{font-size:1rem;vertical-align:top;margin-top:.4rem;display:inline-block;}
.bty-pkg__body{padding:1.5rem 2rem 2rem;}
.bty-pkg__includes{list-style:none;display:flex;flex-direction:column;gap:.6rem;margin-bottom:1.5rem;}
.bty-pkg__include{
  display:flex;align-items:flex-start;gap:.6rem;
  font-size:.88rem;line-height:1.5;color:var(--bty-muted);
}
.bty-pkg__include::before{
  content:'✓';color:var(--bty-rg);font-size:.8rem;font-weight:700;flex-shrink:0;margin-top:.1rem;
}
.bty-pkg__cta{
  display:block;width:100%;padding:.85rem;text-align:center;
  background:var(--bty-pkg-color,var(--bty-rg));color:#fff;
  border:none;border-radius:30px;
  font-family:var(--bty-ff-san);font-size:.85rem;font-weight:700;
  letter-spacing:.06em;cursor:pointer;transition:var(--bty-trans);text-decoration:none;
}
.bty-pkg__cta:hover{filter:brightness(1.1);transform:translateY(-1px);}

/* ================================================================
   STATS
================================================================ */
.bty-stats{background:var(--bty-char);padding:4.5rem 0;}
.bty-stats__grid{
  display:grid;grid-template-columns:repeat(4,1fr);gap:2rem;text-align:center;
}
.bty-stat-num{
  font-family:var(--bty-ff-ser);font-size:clamp(2.8rem,5vw,4.5rem);
  color:var(--bty-rg);display:block;margin-bottom:.3rem;
}
.bty-stat-label{
  font-size:.72rem;font-weight:700;letter-spacing:.16em;text-transform:uppercase;
  color:rgba(250,246,242,.4);
}

/* ================================================================
   TEAM
================================================================ */
.bty-team-grid{
  display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:2rem;
}
.bty-team-card{
  background:#fff;border-radius:var(--bty-r);overflow:hidden;
  box-shadow:0 2px 20px rgba(42,26,16,.06);text-align:center;
  transition:var(--bty-trans);
}
.bty-team-card:hover{transform:translateY(-4px);}
.bty-team-portrait{
  height:200px;display:flex;align-items:flex-end;justify-content:center;
  position:relative;overflow:hidden;
}
.bty-team-portrait--0{background:linear-gradient(180deg,#f8e8e0 0%,#f0d8d0 100%);}
.bty-team-portrait--1{background:linear-gradient(180deg,#f0e8f8 0%,#e0d0f0 100%);}
.bty-team-portrait--2{background:linear-gradient(180deg,#e8f0e0 0%,#d8e8c8 100%);}
.bty-team-portrait--3{background:linear-gradient(180deg,#f8f0e0 0%,#f0e0c8 100%);}
.bty-team-body{padding:1.4rem 1rem 1.6rem;}
.bty-team-name{font-family:var(--bty-ff-ser);font-size:1.25rem;color:var(--bty-char);margin-bottom:.2rem;}
.bty-team-role{font-size:.75rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--bty-rg);margin-bottom:.5rem;}
.bty-team-cert{font-size:.8rem;color:var(--bty-muted);}

/* ================================================================
   TESTIMONIALS
================================================================ */
.bty-testi-grid{
  display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:2rem;
}
.bty-testi-card{
  background:#fff;border-radius:var(--bty-r);padding:2rem;
  box-shadow:0 2px 20px rgba(42,26,16,.05);
  position:relative;border-bottom:2px solid var(--bty-blush);
}
.bty-testi-mark{
  font-family:var(--bty-ff-ser);font-size:5rem;line-height:.7;
  color:rgba(200,148,122,.15);position:absolute;top:1rem;left:1.4rem;
  pointer-events:none;user-select:none;
}
.bty-testi-text{
  font-family:var(--bty-ff-ser);font-size:1.05rem;font-style:italic;
  line-height:1.75;color:var(--bty-char);margin-bottom:1.2rem;padding-top:.5rem;position:relative;
}
.bty-testi-name{font-size:.85rem;font-weight:700;color:var(--bty-char);}
.bty-testi-city{font-size:.78rem;color:var(--bty-muted);}

/* ================================================================
   BOOKING FORM
================================================================ */
.bty-form-section{background:var(--bty-warm);padding:6rem 0;}
.bty-form-inner{
  max-width:780px;margin:0 auto;
  background:#fff;border-radius:var(--bty-r);padding:3rem;
  box-shadow:0 4px 40px rgba(42,26,16,.08);
}
.bty-form-title{
  font-family:var(--bty-ff-ser);font-size:2.5rem;color:var(--bty-char);margin-bottom:.4rem;
}
.bty-form-sub{font-size:.9rem;color:var(--bty-muted);margin-bottom:2.5rem;}
.bty-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:1rem;}
.bty-fg{display:flex;flex-direction:column;gap:.35rem;}
.bty-fg--full{grid-column:1/-1;}
.bty-label{font-size:.7rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--bty-muted);}
.bty-input,.bty-select,.bty-textarea{
  padding:.82rem 1rem;border-radius:var(--bty-r);
  border:1.5px solid #e8ddd8;background:#fff;
  color:var(--bty-char);font-family:var(--bty-ff-san);font-size:.9rem;
  transition:var(--bty-trans);
}
.bty-input::placeholder,.bty-textarea::placeholder{color:rgba(138,122,114,.35);}
.bty-input:focus,.bty-select:focus,.bty-textarea:focus{
  outline:none;border-color:var(--bty-rg);box-shadow:0 0 0 3px rgba(200,148,122,.1);
}
.bty-consent{
  display:flex;align-items:flex-start;gap:.7rem;
  font-size:.83rem;color:var(--bty-muted);line-height:1.5;
}
.bty-consent input{margin-top:.2rem;accent-color:var(--bty-rg);}
.bty-submit{
  padding:1rem 2.5rem;background:var(--bty-rg);color:#fff;
  border:none;border-radius:30px;
  font-family:var(--bty-ff-san);font-size:.9rem;font-weight:700;
  cursor:pointer;transition:var(--bty-trans);margin-top:.8rem;
}
.bty-submit:hover{background:#b87a60;transform:translateY(-2px);}

/* ================================================================
   SCROLL REVEAL
================================================================ */
.bty-reveal{opacity:0;transform:translateY(24px);transition:opacity .7s ease,transform .7s ease;}
.bty-reveal.visible{opacity:1;transform:none;}

/* ================================================================
   RESPONSIVE
================================================================ */
@media(max-width:900px){
  .bty-hero{grid-template-columns:1fr;padding:8rem 1.5rem 3rem;}
  .bty-hero__art{height:380px;max-width:400px;margin:0 auto;width:100%;}
  .bty-stats__grid{grid-template-columns:repeat(2,1fr);}
  .bty-form-grid{grid-template-columns:1fr;}
}
@media(max-width:600px){
  .bty-section{padding:4rem 0;}
  .bty-stats__grid{grid-template-columns:1fr 1fr;}
  .bty-form-inner{padding:2rem 1.2rem;}
}
</style>

<!-- ================================================================
     PAGE WRAPPER
================================================================ -->
<div class="bty-page">

<!-- ================================================================
     FLOATING PETALS + BOKEH
================================================================ -->
<?php foreach($petals as $p): ?>
<div class="bty-petal" style="
  left:<?php echo $p['x']; ?>%;
  top:<?php echo $p['y']; ?>%;
  width:<?php echo $p['s']; ?>px;
  height:<?php echo $p['s']*0.7; ?>px;
  opacity:<?php echo $p['op']; ?>;
  --bty-dur:<?php echo $p['dur']; ?>s;
  --bty-del:<?php echo $p['del']; ?>ms;
" aria-hidden="true"></div>
<?php endforeach; ?>

<?php foreach($bokeh as $b): ?>
<div class="bty-bokeh" style="
  left:<?php echo $b['x']; ?>%;
  top:<?php echo $b['y']; ?>%;
  width:<?php echo $b['s']; ?>px;
  height:<?php echo $b['s']; ?>px;
  opacity:<?php echo $b['op']; ?>;
  animation-delay:<?php echo $b['del']; ?>ms;
" aria-hidden="true"></div>
<?php endforeach; ?>

<!-- ================================================================
     HERO
================================================================ -->
<section aria-label="<?php esc_attr_e('Beauty Salon Hero','themeflex'); ?>">
<div class="bty-hero">
  <!-- Copy -->
  <div class="bty-hero__copy">
    <p class="bty-hero__eyebrow"><?php esc_html_e('Premium Beauty & Wellbeing','themeflex'); ?></p>
    <h1 class="bty-hero__h1">
      <?php esc_html_e('Where Beauty','themeflex'); ?><br>
      <?php esc_html_e('Meets','themeflex'); ?> <em><?php esc_html_e('Ritual','themeflex'); ?></em>
    </h1>
    <p class="bty-hero__lead">
      <?php esc_html_e('An intimate sanctuary in the heart of Munich. Expert therapists. Curated treatments. A space designed for women who understand that self-care is not indulgence — it is essential.','themeflex'); ?>
    </p>
    <div class="bty-hero__ctas">
      <a href="#services" class="bty-btn bty-btn--primary"><?php esc_html_e('Explore Services','themeflex'); ?></a>
      <a href="#booking" class="bty-btn bty-btn--outline"><?php esc_html_e('Book Now','themeflex'); ?></a>
    </div>
  </div>

  <!-- CSS Vanity Scene -->
  <div class="bty-hero__art" aria-hidden="true">

    <!-- Hollywood Mirror -->
    <div class="bty-mirror">
      <div class="bty-mirror-bulbs">
        <?php
        // Generate bulb positions around mirror oval
        $bulb_positions = [];
        for($angle=-80;$angle<=80;$angle+=20){
            $rad = deg2rad($angle);
            $x = 90 + sin($rad)*88;
            $y = 110 - cos($rad)*108;
            $bulb_positions[] = [$x, $y];
        }
        // Left side
        for($angle=100;$angle<=260;$angle+=20){
            $rad = deg2rad($angle);
            $x = 90 + sin($rad)*88;
            $y = 110 - cos($rad)*108;
            $bulb_positions[] = [$x, $y];
        }
        foreach($bulb_positions as $bp): ?>
        <div class="bty-bulb" style="
          left:<?php echo round($bp[0]-5); ?>px;
          top:<?php echo round($bp[1]-5); ?>px;
        "></div>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="bty-mirror-stand"></div>
    <div class="bty-mirror-base"></div>

    <!-- Vanity Table -->
    <div class="bty-table">
      <div class="bty-table__top"></div>
      <div class="bty-table__body">
        <div class="bty-table__drawer"><div class="bty-table__knob"></div></div>
      </div>
      <div class="bty-table__legs">
        <div class="bty-table__leg"></div>
        <div class="bty-table__leg"></div>
        <div class="bty-table__leg"></div>
      </div>

      <!-- Items on table surface -->
      <!-- Rose -->
      <div class="bty-rose">
        <div class="bty-rose__head"></div>
        <div class="bty-rose__leaf"></div>
        <div class="bty-rose__stem"></div>
      </div>

      <!-- Perfume -->
      <div class="bty-perfume">
        <div class="bty-perfume__cap"></div>
        <div class="bty-perfume__neck"></div>
        <div class="bty-perfume__bottle">
          <div class="bty-perfume__label">Eau de Parfum</div>
        </div>
      </div>

      <!-- Lipstick -->
      <div class="bty-lipstick">
        <div class="bty-lipstick__tube"></div>
        <div class="bty-lipstick__base">
          <div class="bty-lipstick__cap"></div>
        </div>
      </div>

      <!-- Candle -->
      <div class="bty-candle">
        <div class="bty-candle__flame"></div>
        <div class="bty-candle__wick"></div>
        <div class="bty-candle__body">
          <div class="bty-candle__wax"></div>
        </div>
      </div>

      <!-- Makeup brush -->
      <div class="bty-brush">
        <div class="bty-brush__bristles"></div>
        <div class="bty-brush__ferrule"></div>
        <div class="bty-brush__handle"></div>
      </div>

      <!-- Foundation -->
      <div class="bty-foundation">
        <div class="bty-foundation__pump"></div>
        <div class="bty-foundation__bottle"></div>
      </div>

      <!-- Scattered petals on table -->
      <?php
      $tpetals = [[60,14],[90,16],[220,12],[280,14],[190,18]];
      foreach($tpetals as $tp): ?>
      <div class="bty-table-petal" style="
        left:<?php echo $tp[0]; ?>px;
        width:<?php echo $tp[1]; ?>px;
        height:<?php echo $tp[1]*0.7; ?>px;
        transform:rotate(<?php echo rand(0,60); ?>deg);
      "></div>
      <?php endforeach; ?>
    </div>

    <!-- Stool -->
    <div class="bty-stool">
      <div class="bty-stool__seat"></div>
      <div class="bty-stool__legs-wrap">
        <div class="bty-stool__leg"></div>
        <div class="bty-stool__leg"></div>
      </div>
    </div>

  </div><!-- /art -->
</div>
</section>

<!-- ================================================================
     AWARDS MARQUEE
================================================================ -->
<div class="bty-marquee-wrap" aria-label="<?php esc_attr_e('Awards & certifications','themeflex'); ?>">
  <div class="bty-marquee-track" aria-hidden="true">
    <?php foreach(array_merge($awards,$awards) as $a): ?>
    <span class="bty-marquee-item"><?php echo esc_html($a); ?></span>
    <?php endforeach; ?>
  </div>
</div>

<!-- ================================================================
     SERVICES
================================================================ -->
<section id="services" class="bty-section">
  <div class="bty-container">
    <div class="bty-section-header bty-reveal">
      <p class="bty-section-header__label"><?php esc_html_e('Treatment Menu','themeflex'); ?></p>
      <h2 class="bty-section-header__h2"><?php esc_html_e('Our','themeflex'); ?> <em><?php esc_html_e('Services','themeflex'); ?></em></h2>
      <p class="bty-section-header__sub"><?php esc_html_e('Every treatment is performed by a certified specialist using professional-grade products. All timings shown are full treatment times — no filler.','themeflex'); ?></p>
    </div>

    <div class="bty-filter-bar" role="group" aria-label="<?php esc_attr_e('Filter services','themeflex'); ?>">
      <button class="bty-filter-btn active" data-filter="all" aria-pressed="true"><?php esc_html_e('All','themeflex'); ?></button>
      <button class="bty-filter-btn" data-filter="face"  aria-pressed="false"><?php esc_html_e('Face','themeflex'); ?></button>
      <button class="bty-filter-btn" data-filter="body"  aria-pressed="false"><?php esc_html_e('Body','themeflex'); ?></button>
      <button class="bty-filter-btn" data-filter="nails" aria-pressed="false"><?php esc_html_e('Nails','themeflex'); ?></button>
      <button class="bty-filter-btn" data-filter="hair"  aria-pressed="false"><?php esc_html_e('Hair','themeflex'); ?></button>
    </div>

    <div class="bty-services-grid">
      <?php foreach($services as $s): ?>
      <div class="bty-service-card bty-reveal" data-cat="<?php echo esc_attr($s['cat']); ?>">
        <div class="bty-service-name"><?php echo esc_html($s['name']); ?></div>
        <div class="bty-service-meta">
          <span class="bty-service-dur"><?php echo esc_html($s['duration']); ?> <?php esc_html_e('min','themeflex'); ?></span>
          <span class="bty-service-price">€<?php echo esc_html($s['price']); ?></span>
        </div>
        <p class="bty-service-desc"><?php echo esc_html($s['desc']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ================================================================
     PACKAGES
================================================================ -->
<section class="bty-section bty-section--alt">
  <div class="bty-container">
    <div class="bty-section-header bty-reveal">
      <p class="bty-section-header__label"><?php esc_html_e('Curated Packages','themeflex'); ?></p>
      <h2 class="bty-section-header__h2"><?php esc_html_e('Signature','themeflex'); ?> <em><?php esc_html_e('Rituals','themeflex'); ?></em></h2>
      <p class="bty-section-header__sub"><?php esc_html_e('Our most-loved treatments combined into immersive experiences. Priced to reflect exceptional value — not a compromise.','themeflex'); ?></p>
    </div>
    <div class="bty-packages-grid">
      <?php foreach($packages as $pkg): ?>
      <div class="bty-pkg bty-reveal" style="--bty-pkg-color:<?php echo esc_attr($pkg['color']); ?>;">
        <div class="bty-pkg__top">
          <?php if($pkg['tag']): ?>
          <div class="bty-pkg__tag"><?php echo esc_html($pkg['tag']); ?></div>
          <?php endif; ?>
          <div class="bty-pkg__name"><?php echo esc_html($pkg['name']); ?></div>
          <div class="bty-pkg__duration"><?php printf(esc_html__('%d hours','themeflex'),$pkg['duration']); ?></div>
          <div class="bty-pkg__price"><sup>€</sup><?php echo esc_html($pkg['price']); ?></div>
        </div>
        <div class="bty-pkg__body">
          <ul class="bty-pkg__includes">
            <?php foreach($pkg['includes'] as $inc): ?>
            <li class="bty-pkg__include"><?php echo esc_html($inc); ?></li>
            <?php endforeach; ?>
          </ul>
          <a href="#booking" class="bty-pkg__cta"><?php esc_html_e('Book this Ritual','themeflex'); ?></a>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ================================================================
     STATS
================================================================ -->
<section class="bty-stats" aria-label="<?php esc_attr_e('Salon statistics','themeflex'); ?>">
  <div class="bty-container">
    <div class="bty-stats__grid">
      <?php
      $stats = [
        ['val'=>8400,'suf'=>'+','lbl'=>__('Treatments This Year','themeflex')],
        ['val'=>16,  'suf'=>'yrs','lbl'=>__('Established Since','themeflex')],
        ['val'=>5,   'suf'=>'★',  'lbl'=>__('Average Review','themeflex')],
        ['val'=>98,  'suf'=>'%',  'lbl'=>__('Client Return Rate','themeflex')],
      ];
      foreach($stats as $s): ?>
      <div class="bty-reveal" style="text-align:center;">
        <span class="bty-stat-num" data-target="<?php echo $s['val']; ?>" data-suffix="<?php echo esc_attr($s['suf']); ?>">0</span>
        <span class="bty-stat-label"><?php echo esc_html($s['lbl']); ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ================================================================
     TEAM
================================================================ -->
<section class="bty-section bty-section--alt">
  <div class="bty-container">
    <div class="bty-section-header bty-reveal">
      <p class="bty-section-header__label"><?php esc_html_e('Our Specialists','themeflex'); ?></p>
      <h2 class="bty-section-header__h2"><?php esc_html_e('Meet the','themeflex'); ?> <em><?php esc_html_e('Team','themeflex'); ?></em></h2>
    </div>
    <div class="bty-team-grid">
      <?php foreach($team as $i => $m):
        $dress_colors = ['#c8947a','#9888c8','#7a9a78','#c8b870'];
        $dc = $dress_colors[$i % count($dress_colors)];
        $hair_colors  = ['#3a1a10','#6a3a10','#1a1a1a','#a87830'];
        $hc = $hair_colors[$i % count($hair_colors)];
      ?>
      <div class="bty-team-card bty-reveal">
        <div class="bty-team-portrait bty-team-portrait--<?php echo $i; ?>">
          <svg width="120" height="185" viewBox="0 0 120 185" xmlns="http://www.w3.org/2000/svg" aria-label="<?php echo esc_attr($m['name']); ?>">
            <!-- Dress / uniform -->
            <path d="M20 100 L32 88 L60 95 L88 88 L100 100 L104 185 L16 185 Z"
              fill="<?php echo esc_attr($dc); ?>" opacity=".9"/>
            <!-- Collar / neckline -->
            <path d="M44 88 Q60 100 76 88" fill="rgba(255,255,255,.2)" stroke="rgba(255,255,255,.3)" stroke-width="1"/>
            <!-- Arms -->
            <path d="M20 100 L8 148" stroke="<?php echo esc_attr($dc); ?>" stroke-width="20" stroke-linecap="round" fill="none" opacity=".85"/>
            <path d="M100 100 L112 148" stroke="<?php echo esc_attr($dc); ?>" stroke-width="20" stroke-linecap="round" fill="none" opacity=".85"/>
            <!-- Hands -->
            <ellipse cx="8" cy="151" rx="8" ry="6" fill="#c8956a"/>
            <ellipse cx="112" cy="151" rx="8" ry="6" fill="#c8956a"/>
            <!-- Neck -->
            <rect x="50" y="74" width="20" height="18" rx="6" fill="#c8956a"/>
            <!-- Head -->
            <ellipse cx="60" cy="56" rx="25" ry="26" fill="#c8956a"/>
            <!-- Hair long -->
            <ellipse cx="60" cy="35" rx="25" ry="12" fill="<?php echo esc_attr($hc); ?>"/>
            <rect x="35" y="35" width="10" height="42" rx="5"
              fill="<?php echo esc_attr($hc); ?>" opacity=".9"/>
            <rect x="75" y="35" width="10" height="42" rx="5"
              fill="<?php echo esc_attr($hc); ?>" opacity=".9"/>
            <!-- Eyes (almond shape, feminine) -->
            <ellipse cx="49" cy="53" rx="5" ry="3.5" fill="white"/>
            <ellipse cx="49" cy="53" rx="3.5" ry="2.5" fill="#3a2010"/>
            <ellipse cx="71" cy="53" rx="5" ry="3.5" fill="white"/>
            <ellipse cx="71" cy="53" rx="3.5" ry="2.5" fill="#3a2010"/>
            <!-- Lashes -->
            <line x1="44" y1="50" x2="42" y2="47" stroke="#2a1010" stroke-width="1"/>
            <line x1="47" y1="49" x2="46" y2="46" stroke="#2a1010" stroke-width="1"/>
            <line x1="54" y1="49" x2="54" y2="46" stroke="#2a1010" stroke-width="1"/>
            <line x1="66" y1="49" x2="66" y2="46" stroke="#2a1010" stroke-width="1"/>
            <line x1="73" y1="49" x2="74" y2="46" stroke="#2a1010" stroke-width="1"/>
            <line x1="76" y1="50" x2="78" y2="47" stroke="#2a1010" stroke-width="1"/>
            <!-- Lips (rose) -->
            <path d="M52 66 Q60 73 68 66 Q64 71 56 71 Z" fill="#d08090"/>
            <!-- Blush -->
            <ellipse cx="44" cy="61" rx="7" ry="4" fill="rgba(220,120,130,.2)"/>
            <ellipse cx="76" cy="61" rx="7" ry="4" fill="rgba(220,120,130,.2)"/>
            <!-- Earrings -->
            <circle cx="35" cy="60" r="3" fill="<?php echo esc_attr($dc); ?>" opacity=".8"/>
            <circle cx="85" cy="60" r="3" fill="<?php echo esc_attr($dc); ?>" opacity=".8"/>
          </svg>
        </div>
        <div class="bty-team-body">
          <div class="bty-team-name"><?php echo esc_html($m['name']); ?></div>
          <div class="bty-team-role"><?php echo esc_html($m['role']); ?></div>
          <div class="bty-team-cert"><?php echo esc_html($m['cert']); ?> · <?php printf(esc_html__('%d years','themeflex'),$m['years']); ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ================================================================
     TESTIMONIALS
================================================================ -->
<section class="bty-section">
  <div class="bty-container">
    <div class="bty-section-header bty-reveal">
      <p class="bty-section-header__label"><?php esc_html_e('Client Love','themeflex'); ?></p>
      <h2 class="bty-section-header__h2"><?php esc_html_e('What Our','themeflex'); ?> <em><?php esc_html_e('Clients Say','themeflex'); ?></em></h2>
    </div>
    <div class="bty-testi-grid">
      <?php foreach($testimonials as $t): ?>
      <div class="bty-testi-card bty-reveal">
        <div class="bty-testi-mark" aria-hidden="true">&ldquo;</div>
        <p class="bty-testi-text"><?php echo esc_html($t['q']); ?></p>
        <div class="bty-testi-name"><?php echo esc_html($t['n']); ?></div>
        <div class="bty-testi-city"><?php echo esc_html($t['city']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ================================================================
     BOOKING FORM
================================================================ -->
<div id="booking" class="bty-form-section">
  <div class="bty-container">
    <div class="bty-form-inner bty-reveal">
      <h2 class="bty-form-title"><?php esc_html_e('Book Your Treatment','themeflex'); ?></h2>
      <p class="bty-form-sub"><?php esc_html_e('Reserve online and receive a 10% new-client discount on your first visit.','themeflex'); ?></p>

      <form method="post" action="" class="bty-form-grid" novalidate>
        <?php wp_nonce_field('tf_bty_booking','tf_bty_nonce'); ?>

        <div class="bty-fg">
          <label class="bty-label" for="bty-name"><?php esc_html_e('Your Name','themeflex'); ?></label>
          <input class="bty-input" type="text" id="bty-name" name="bty_name" placeholder="<?php esc_attr_e('Sophie Müller','themeflex'); ?>" required>
        </div>
        <div class="bty-fg">
          <label class="bty-label" for="bty-email"><?php esc_html_e('Email Address','themeflex'); ?></label>
          <input class="bty-input" type="email" id="bty-email" name="bty_email" placeholder="<?php esc_attr_e('sophie@example.com','themeflex'); ?>" required>
        </div>
        <div class="bty-fg">
          <label class="bty-label" for="bty-phone"><?php esc_html_e('Phone','themeflex'); ?></label>
          <input class="bty-input" type="tel" id="bty-phone" name="bty_phone" placeholder="<?php esc_attr_e('+49 89 …','themeflex'); ?>">
        </div>
        <div class="bty-fg">
          <label class="bty-label" for="bty-date"><?php esc_html_e('Preferred Date','themeflex'); ?></label>
          <input class="bty-input" type="date" id="bty-date" name="bty_date">
        </div>
        <div class="bty-fg bty-fg--full">
          <label class="bty-label" for="bty-service"><?php esc_html_e('Treatment','themeflex'); ?></label>
          <select class="bty-select" id="bty-service" name="bty_service">
            <option value=""><?php esc_html_e('Select a treatment…','themeflex'); ?></option>
            <optgroup label="<?php esc_attr_e('Individual Treatments','themeflex'); ?>">
              <?php foreach($services as $s): ?>
              <option value="<?php echo esc_attr($s['name']); ?>"><?php echo esc_html($s['name'].' ('.$s['duration'].' min) — €'.$s['price']); ?></option>
              <?php endforeach; ?>
            </optgroup>
            <optgroup label="<?php esc_attr_e('Signature Packages','themeflex'); ?>">
              <?php foreach($packages as $p): ?>
              <option value="<?php echo esc_attr($p['name']); ?>"><?php echo esc_html($p['name'].' ('.$p['duration'].' hrs) — €'.$p['price']); ?></option>
              <?php endforeach; ?>
            </optgroup>
          </select>
        </div>
        <div class="bty-fg">
          <label class="bty-label" for="bty-therapist"><?php esc_html_e('Preferred Therapist','themeflex'); ?></label>
          <select class="bty-select" id="bty-therapist" name="bty_therapist">
            <option value="any"><?php esc_html_e('No preference','themeflex'); ?></option>
            <?php foreach($team as $tm): ?>
            <option value="<?php echo esc_attr($tm['name']); ?>"><?php echo esc_html($tm['name'].' — '.$tm['role']); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="bty-fg">
          <label class="bty-label" for="bty-time"><?php esc_html_e('Preferred Time','themeflex'); ?></label>
          <select class="bty-select" id="bty-time" name="bty_time">
            <option value=""><?php esc_html_e('Choose a time…','themeflex'); ?></option>
            <?php foreach(['09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00','18:00'] as $t): ?>
            <option value="<?php echo esc_attr($t); ?>"><?php echo esc_html($t); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="bty-fg bty-fg--full">
          <label class="bty-label" for="bty-notes"><?php esc_html_e('Notes / Skin Concerns','themeflex'); ?></label>
          <textarea class="bty-textarea" id="bty-notes" name="bty_notes" rows="3" placeholder="<?php esc_attr_e('Allergies, skin conditions, any concerns or requests…','themeflex'); ?>"></textarea>
        </div>
        <div class="bty-fg bty-fg--full">
          <label class="bty-consent">
            <input type="checkbox" name="bty_consent" required>
            <?php esc_html_e('I agree to my data being processed solely to handle my booking request.','themeflex'); ?>
          </label>
        </div>
        <div class="bty-fg bty-fg--full">
          <button type="submit" class="bty-submit"><?php esc_html_e('Request Appointment','themeflex'); ?></button>
        </div>
      </form>
    </div>
  </div>
</div>

</div><!-- /bty-page -->

<!-- ================================================================
     JAVASCRIPT
================================================================ -->
<script>
(function(){
  'use strict';

  /* ── Scroll reveal ── */
  const rev=document.querySelectorAll('.bty-reveal');
  const obs=new IntersectionObserver(es=>{
    es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');obs.unobserve(e.target);}});
  },{threshold:.1,rootMargin:'0px 0px -40px 0px'});
  rev.forEach(el=>obs.observe(el));

  /* ── Animated counters ── */
  const easeOut=t=>1-Math.pow(1-t,3);
  const counters=document.querySelectorAll('.bty-stat-num[data-target]');
  const cObs=new IntersectionObserver(es=>{
    es.forEach(e=>{
      if(!e.isIntersecting)return;
      const el=e.target,end=+el.dataset.target,suf=el.dataset.suffix||'';
      const dur=1800,t0=performance.now();
      (function tick(now){
        const p=Math.min((now-t0)/dur,1);
        el.textContent=Math.round(easeOut(p)*end)+suf;
        if(p<1)requestAnimationFrame(tick);
        else el.textContent=end+suf;
      })(t0);
      cObs.unobserve(el);
    });
  },{threshold:.5});
  counters.forEach(el=>cObs.observe(el));

  /* ── Service filter ── */
  const btns=document.querySelectorAll('.bty-filter-btn');
  const cards=document.querySelectorAll('.bty-service-card');
  btns.forEach(btn=>{
    btn.addEventListener('click',()=>{
      btns.forEach(b=>{b.classList.remove('active');b.setAttribute('aria-pressed','false');});
      btn.classList.add('active');btn.setAttribute('aria-pressed','true');
      const f=btn.dataset.filter;
      cards.forEach(c=>c.classList.toggle('hidden',f!=='all'&&c.dataset.cat!==f));
    });
  });

  /* ── Package CTAs smooth scroll to booking ── */
  document.querySelectorAll('.bty-pkg__cta').forEach(a=>{
    a.addEventListener('click',e=>{
      e.preventDefault();
      document.querySelector('#booking')?.scrollIntoView({behavior:'smooth'});
    });
  });

})();
</script>

<?php get_footer(); ?>
