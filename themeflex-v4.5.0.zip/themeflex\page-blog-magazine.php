<?php
/**
 * Template Name: Blog Magazine Homepage
 *
 * Premium editorial magazine-style homepage for ThemeFlex.
 * Dark-first, featured hero article, category ribbon, editorial grid,
 * trending sidebar, newsletter CTA, and author spotlight.
 *
 * @package ThemeFlex
 * @since   2.8.0
 */

get_header();
?>

<div class="tf-mag-page">

<style>
/* ─── Design Tokens ───────────────────────────────────────────── */
.tf-mag-page {
  --mag-bg:       #0c0c0f;
  --mag-surface:  #111116;
  --mag-card:     #16161c;
  --mag-border:   rgba(255,255,255,.07);
  --mag-accent:   #f97316;   /* editorial orange */
  --mag-accent2:  #06b6d4;   /* cyan for tags */
  --mag-accent3:  #a855f7;   /* violet category */
  --mag-text:     #f0f0f5;
  --mag-muted:    #8888a0;
  --mag-radius:   10px;
  background: var(--mag-bg);
  color: var(--mag-text);
  font-family: var(--tf-font-body, 'Inter', sans-serif);
}

/* ─── Shared ──────────────────────────────────────────────────── */
.tf-mag-page .mag-container {
  max-width: 1240px;
  margin: 0 auto;
  padding: 0 24px;
}
.tf-mag-page .mag-section { padding: 80px 0; }
.tf-mag-page .mag-label {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: .7rem;
  font-weight: 700;
  letter-spacing: .12em;
  text-transform: uppercase;
  background: var(--mag-accent);
  color: #000;
  padding: 4px 10px;
  border-radius: 4px;
}
.tf-mag-page .mag-section-title {
  font-family: var(--tf-font-heading, 'Inter Tight', sans-serif);
  font-size: clamp(1.6rem, 3vw, 2rem);
  font-weight: 700;
  margin: 0 0 32px;
  display: flex;
  align-items: center;
  gap: 16px;
}
.tf-mag-page .mag-section-title::after {
  content: '';
  flex: 1;
  height: 1px;
  background: var(--mag-border);
}
.tf-mag-page .mag-tag {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: .7rem;
  font-weight: 700;
  letter-spacing: .1em;
  text-transform: uppercase;
  padding: 3px 9px;
  border-radius: 4px;
  text-decoration: none;
}
.tf-mag-page .mag-tag-orange { background: rgba(249,115,22,.15); color: var(--mag-accent); }
.tf-mag-page .mag-tag-cyan   { background: rgba(6,182,212,.15);  color: var(--mag-accent2); }
.tf-mag-page .mag-tag-violet { background: rgba(168,85,247,.15); color: var(--mag-accent3); }
.tf-mag-page .mag-tag-green  { background: rgba(16,185,129,.15); color: #10b981; }
.tf-mag-page .mag-tag-red    { background: rgba(239,68,68,.15);  color: #ef4444; }

.tf-mag-page .mag-read-time {
  font-size: .75rem; color: var(--mag-muted);
  display: inline-flex; align-items: center; gap: 5px;
}
.tf-mag-page .mag-date {
  font-size: .75rem; color: var(--mag-muted);
}

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   1. BREAKING TICKER
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-mag-page .mag-ticker {
  background: var(--mag-accent);
  padding: 0;
  overflow: hidden;
  display: flex;
  align-items: center;
  height: 38px;
}
.tf-mag-page .mag-ticker-label {
  background: rgba(0,0,0,.3);
  color: #000;
  font-size: .7rem;
  font-weight: 800;
  letter-spacing: .12em;
  padding: 0 16px;
  height: 100%;
  display: flex;
  align-items: center;
  white-space: nowrap;
  flex-shrink: 0;
}
.tf-mag-page .mag-ticker-track {
  display: flex;
  gap: 0;
  animation: mag-scroll 28s linear infinite;
  white-space: nowrap;
  align-items: center;
  height: 100%;
}
.tf-mag-page .mag-ticker-track:hover { animation-play-state: paused; }
@keyframes mag-scroll {
  from { transform: translateX(0); }
  to   { transform: translateX(-50%); }
}
.tf-mag-page .mag-ticker-item {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 0 24px;
  height: 100%;
  font-size: .8rem;
  font-weight: 700;
  color: #000;
  text-decoration: none;
  border-right: 1px solid rgba(0,0,0,.2);
  transition: background .15s;
}
.tf-mag-page .mag-ticker-item:hover { background: rgba(0,0,0,.1); }

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   2. HERO — FEATURED STORY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-mag-page .mag-hero {
  padding: 0;
  position: relative;
  overflow: hidden;
}
.tf-mag-page .mag-hero-inner {
  display: grid;
  grid-template-columns: 1fr 400px;
  min-height: 560px;
}
/* CSS Art — Abstract editorial illustration */
.tf-mag-page .mag-hero-visual {
  position: relative;
  overflow: hidden;
  background: linear-gradient(145deg, #1a0a00 0%, #0c0c0f 100%);
}
.tf-mag-page .mag-hero-visual::before {
  content: '';
  position: absolute; inset: 0;
  background:
    radial-gradient(ellipse 60% 60% at 30% 40%, rgba(249,115,22,.15) 0%, transparent 70%),
    radial-gradient(ellipse 40% 40% at 80% 70%, rgba(168,85,247,.1) 0%, transparent 70%);
}
.tf-mag-page .mag-hero-visual-art {
  position: absolute; inset: 0;
  display: flex; flex-direction: column;
  padding: 40px;
  justify-content: flex-end;
  background: linear-gradient(to top, rgba(0,0,0,.85) 0%, transparent 50%);
}
.tf-mag-page .mag-hero-visual-label {
  display: flex; align-items: center; gap: 10px; margin-bottom: 20px;
}
/* Typography Art: Big editorial quote mark */
.tf-mag-page .mag-hero-art-quote {
  position: absolute;
  top: 20px; left: 30px;
  font-size: 18rem;
  line-height: 1;
  color: rgba(249,115,22,.06);
  font-family: Georgia, serif;
  pointer-events: none;
  user-select: none;
}
/* Floating stat chips */
.tf-mag-page .mag-hero-chip {
  position: absolute;
  background: rgba(249,115,22,.9);
  color: #000;
  font-size: .75rem;
  font-weight: 800;
  padding: 8px 14px;
  border-radius: 100px;
  display: flex; align-items: center; gap: 6px;
}
.tf-mag-page .mag-hero-chip-1 { top: 60px; right: 40px; animation: mag-float 5s ease-in-out infinite; }
.tf-mag-page .mag-hero-chip-2 { top: 110px; right: 20px; animation: mag-float 5s ease-in-out infinite .8s; background: rgba(168,85,247,.9); }
@keyframes mag-float {
  0%,100% { transform: translateY(0); }
  50%      { transform: translateY(-6px); }
}
.tf-mag-page .mag-hero-headline {
  font-family: var(--tf-font-heading, 'Inter Tight', serif);
  font-size: clamp(1.8rem, 3.5vw, 2.75rem);
  font-weight: 800;
  line-height: 1.15;
  margin: 0 0 14px;
  color: #fff;
}
.tf-mag-page .mag-hero-desc {
  font-size: 1rem; color: rgba(255,255,255,.7); line-height: 1.7; margin-bottom: 20px;
}
.tf-mag-page .mag-hero-meta {
  display: flex; flex-wrap: wrap; align-items: center; gap: 16px;
}
.tf-mag-page .mag-hero-author {
  display: flex; align-items: center; gap: 10px;
}
.tf-mag-page .mag-hero-author-avatar {
  width: 32px; height: 32px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .7rem; font-weight: 700;
  background: var(--mag-accent); color: #000;
}
.tf-mag-page .mag-hero-author-name { font-size: .82rem; color: rgba(255,255,255,.8); font-weight: 600; }
/* Sidebar story list */
.tf-mag-page .mag-hero-sidebar {
  background: var(--mag-surface);
  border-left: 1px solid var(--mag-border);
  display: flex;
  flex-direction: column;
}
.tf-mag-page .mag-hero-sidebar-title {
  padding: 20px 24px 16px;
  font-size: .7rem;
  font-weight: 700;
  letter-spacing: .12em;
  text-transform: uppercase;
  color: var(--mag-muted);
  border-bottom: 1px solid var(--mag-border);
}
.tf-mag-page .mag-sidebar-story {
  display: flex;
  gap: 14px;
  padding: 16px 24px;
  border-bottom: 1px solid var(--mag-border);
  text-decoration: none;
  transition: background .15s;
}
.tf-mag-page .mag-sidebar-story:last-child { border-bottom: none; }
.tf-mag-page .mag-sidebar-story:hover { background: var(--mag-card); }
.tf-mag-page .mag-sidebar-story-num {
  font-size: 1.5rem; font-weight: 800;
  color: rgba(249,115,22,.2);
  font-family: var(--tf-font-heading, monospace);
  flex-shrink: 0; width: 28px; line-height: 1;
}
.tf-mag-page .mag-sidebar-story-content h4 {
  font-size: .875rem; font-weight: 700; color: var(--mag-text);
  margin: 0 0 4px; line-height: 1.4;
}
.tf-mag-page .mag-sidebar-story-content p {
  font-size: .75rem; color: var(--mag-muted); margin: 0;
}

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   3. CATEGORY RIBBON
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-mag-page .mag-cat-ribbon {
  background: var(--mag-surface);
  border-top: 1px solid var(--mag-border);
  border-bottom: 1px solid var(--mag-border);
  padding: 0;
}
.tf-mag-page .mag-cat-ribbon .inner {
  display: flex; flex-wrap: wrap; gap: 0;
  overflow-x: auto; scrollbar-width: none;
}
.tf-mag-page .mag-cat-ribbon .inner::-webkit-scrollbar { display: none; }
.tf-mag-page .mag-cat-link {
  display: flex; align-items: center; gap: 8px;
  padding: 16px 24px;
  font-size: .82rem; font-weight: 600;
  color: var(--mag-muted);
  text-decoration: none;
  border-right: 1px solid var(--mag-border);
  white-space: nowrap;
  transition: all .2s;
}
.tf-mag-page .mag-cat-link:hover { color: var(--mag-accent); background: rgba(249,115,22,.05); }
.tf-mag-page .mag-cat-link.active { color: var(--mag-accent); border-bottom: 2px solid var(--mag-accent); }
.tf-mag-page .mag-cat-link .cat-count {
  background: var(--mag-card); border-radius: 100px;
  padding: 2px 7px; font-size: .65rem; color: var(--mag-muted);
}

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   4. MAIN EDITORIAL GRID + SIDEBAR
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-mag-page .mag-main-layout {
  display: grid;
  grid-template-columns: 1fr 340px;
  gap: 40px;
  align-items: start;
}
/* Editorial article card */
.tf-mag-page .mag-article-card {
  display: flex;
  flex-direction: column;
  background: var(--mag-card);
  border: 1.5px solid var(--mag-border);
  border-radius: var(--mag-radius);
  overflow: hidden;
  transition: all .2s;
  text-decoration: none;
}
.tf-mag-page .mag-article-card:hover {
  border-color: rgba(249,115,22,.3);
  transform: translateY(-3px);
  box-shadow: 0 16px 32px rgba(0,0,0,.3);
}
.tf-mag-page .mag-article-thumb {
  height: 200px;
  display: flex; align-items: center; justify-content: center;
  font-size: 2.5rem; font-weight: 800;
  position: relative;
  overflow: hidden;
}
.tf-mag-page .mag-article-thumb .thumb-cat-badge {
  position: absolute; top: 12px; left: 12px;
}
.tf-mag-page .mag-article-body { padding: 20px; flex: 1; display: flex; flex-direction: column; }
.tf-mag-page .mag-article-body h3 {
  font-size: 1.05rem; font-weight: 700; margin: 0 0 10px;
  color: var(--mag-text); line-height: 1.4;
}
.tf-mag-page .mag-article-body p {
  font-size: .85rem; color: var(--mag-muted); line-height: 1.6; flex: 1; margin-bottom: 16px;
}
.tf-mag-page .mag-article-foot {
  display: flex; align-items: center; justify-content: space-between;
  font-size: .75rem; color: var(--mag-muted);
  border-top: 1px solid var(--mag-border); padding-top: 14px;
}
.tf-mag-page .mag-article-foot .author {
  display: flex; align-items: center; gap: 6px;
}
.tf-mag-page .mag-article-foot .author-dot {
  width: 24px; height: 24px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .6rem; font-weight: 700;
}
/* Primary large card */
.tf-mag-page .mag-article-card.large .mag-article-thumb { height: 280px; }
.tf-mag-page .mag-article-card.large .mag-article-body h3 { font-size: 1.3rem; }
/* Grid layout */
.tf-mag-page .mag-articles-primary {
  display: grid; grid-template-columns: 1fr 1fr; gap: 20px;
}
.tf-mag-page .mag-articles-primary .mag-article-card:first-child {
  grid-column: 1 / -1;
}

/* ─── Sidebar ──────────────────────────────────────────────────── */
.tf-mag-page .mag-sidebar { display: flex; flex-direction: column; gap: 28px; }
/* Trending widget */
.tf-mag-page .mag-widget {
  background: var(--mag-card);
  border: 1.5px solid var(--mag-border);
  border-radius: var(--mag-radius);
  overflow: hidden;
}
.tf-mag-page .mag-widget-header {
  padding: 14px 18px;
  border-bottom: 1px solid var(--mag-border);
  display: flex; align-items: center; justify-content: space-between;
}
.tf-mag-page .mag-widget-header h4 {
  font-size: .8rem; font-weight: 700; margin: 0;
  text-transform: uppercase; letter-spacing: .1em; color: var(--mag-text);
  display: flex; align-items: center; gap: 8px;
}
.tf-mag-page .mag-widget-header a {
  font-size: .72rem; color: var(--mag-accent); text-decoration: none; font-weight: 600;
}
.tf-mag-page .mag-trending-item {
  display: flex; gap: 12px; align-items: flex-start;
  padding: 14px 18px;
  border-bottom: 1px solid var(--mag-border);
  text-decoration: none;
  transition: background .15s;
}
.tf-mag-page .mag-trending-item:last-child { border-bottom: none; }
.tf-mag-page .mag-trending-item:hover { background: rgba(255,255,255,.03); }
.tf-mag-page .mag-trending-num {
  font-size: 1.4rem; font-weight: 800;
  color: rgba(249,115,22,.2);
  font-family: var(--tf-font-heading, monospace);
  flex-shrink: 0; line-height: 1;
}
.tf-mag-page .mag-trending-text h5 {
  font-size: .85rem; font-weight: 700; color: var(--mag-text); margin: 0 0 4px; line-height: 1.4;
}
.tf-mag-page .mag-trending-text span { font-size: .72rem; color: var(--mag-muted); }
/* Tags cloud widget */
.tf-mag-page .mag-tags-cloud {
  padding: 16px;
  display: flex; flex-wrap: wrap; gap: 8px;
}
/* Newsletter widget */
.tf-mag-page .mag-newsletter-widget { padding: 20px; }
.tf-mag-page .mag-newsletter-widget p { font-size: .85rem; color: var(--mag-muted); margin: 0 0 14px; line-height: 1.6; }
.tf-mag-page .mag-nl-input-row { display: flex; flex-direction: column; gap: 8px; }
.tf-mag-page .mag-nl-input-row input {
  width: 100%; background: var(--mag-surface); border: 1.5px solid var(--mag-border);
  border-radius: 6px; padding: 11px 14px; color: var(--mag-text);
  font-size: .875rem; font-family: inherit; transition: border-color .2s; box-sizing: border-box;
}
.tf-mag-page .mag-nl-input-row input:focus { outline: none; border-color: var(--mag-accent); }
.tf-mag-page .mag-nl-input-row button {
  width: 100%; padding: 11px; background: var(--mag-accent); color: #000;
  font-size: .875rem; font-weight: 700; border: none; border-radius: 6px; cursor: pointer;
  display: flex; align-items: center; justify-content: center; gap: 6px; transition: background .2s;
}
.tf-mag-page .mag-nl-input-row button:hover { background: #fb923c; }

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   5. EDITOR'S PICK — FULL-WIDTH ROW
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-mag-page .mag-editors-pick { background: var(--mag-surface); }
.tf-mag-page .mag-editors-grid {
  display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px;
}

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   6. AUTHOR SPOTLIGHT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-mag-page .mag-authors-grid {
  display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px;
}
.tf-mag-page .mag-author-card {
  background: var(--mag-card);
  border: 1.5px solid var(--mag-border);
  border-radius: var(--mag-radius);
  padding: 24px;
  text-align: center;
  transition: all .2s;
}
.tf-mag-page .mag-author-card:hover { border-color: rgba(249,115,22,.3); transform: translateY(-3px); }
.tf-mag-page .mag-author-avatar {
  width: 64px; height: 64px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: 1.2rem; font-weight: 800; margin: 0 auto 14px;
}
.tf-mag-page .mag-author-card h4 { font-size: .95rem; font-weight: 700; margin: 0 0 4px; }
.tf-mag-page .mag-author-card .author-beat { font-size: .78rem; color: var(--mag-accent); font-weight: 600; margin-bottom: 10px; }
.tf-mag-page .mag-author-card p { font-size: .8rem; color: var(--mag-muted); line-height: 1.6; margin-bottom: 14px; }
.tf-mag-page .mag-author-stats { display: flex; justify-content: center; gap: 20px; margin-bottom: 14px; }
.tf-mag-page .mag-author-stats span { font-size: .75rem; color: var(--mag-muted); text-align: center; }
.tf-mag-page .mag-author-stats strong { display: block; font-size: .95rem; color: var(--mag-text); }
.tf-mag-page .mag-author-follow {
  display: inline-flex; align-items: center; gap: 6px;
  background: transparent; border: 1.5px solid var(--mag-border);
  color: var(--mag-text); font-size: .8rem; font-weight: 600;
  padding: 8px 18px; border-radius: 6px; text-decoration: none; cursor: pointer;
  transition: all .2s;
}
.tf-mag-page .mag-author-follow:hover { border-color: var(--mag-accent); color: var(--mag-accent); }

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   7. NEWSLETTER FULL CTA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
.tf-mag-page .mag-nl-section {
  background: linear-gradient(135deg, #1a0a00 0%, #0c0c0f 100%);
  border-top: 1px solid var(--mag-border);
  border-bottom: 1px solid var(--mag-border);
  text-align: center;
  position: relative;
  overflow: hidden;
}
.tf-mag-page .mag-nl-section::before {
  content: '';
  position: absolute; inset: 0;
  background: radial-gradient(ellipse 70% 80% at 50% 50%, rgba(249,115,22,.07) 0%, transparent 70%);
  pointer-events: none;
}
.tf-mag-page .mag-nl-section h2 {
  font-family: var(--tf-font-heading, 'Inter Tight', sans-serif);
  font-size: clamp(1.8rem, 4vw, 2.5rem);
  font-weight: 800; margin: 0 0 16px;
}
.tf-mag-page .mag-nl-section h2 em {
  font-style: normal;
  background: linear-gradient(135deg, var(--mag-accent), #fb923c);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
}
.tf-mag-page .mag-nl-section p {
  font-size: 1.05rem; color: var(--mag-muted); margin: 0 auto 36px; max-width: 520px; line-height: 1.7;
}
.tf-mag-page .mag-nl-form {
  display: flex; gap: 0; max-width: 480px; margin: 0 auto 20px; border-radius: 8px; overflow: hidden;
  border: 1.5px solid var(--mag-border);
}
.tf-mag-page .mag-nl-form input {
  flex: 1; background: var(--mag-card); border: none; padding: 15px 18px;
  color: var(--mag-text); font-size: .95rem; font-family: inherit;
}
.tf-mag-page .mag-nl-form input:focus { outline: none; }
.tf-mag-page .mag-nl-form button {
  background: var(--mag-accent); color: #000; border: none;
  padding: 15px 22px; font-size: .9rem; font-weight: 700; cursor: pointer;
  display: flex; align-items: center; gap: 6px; transition: background .2s; white-space: nowrap;
}
.tf-mag-page .mag-nl-form button:hover { background: #fb923c; }
.tf-mag-page .mag-nl-proof {
  display: flex; align-items: center; justify-content: center; gap: 20px;
  font-size: .8rem; color: var(--mag-muted); flex-wrap: wrap;
}
.tf-mag-page .mag-nl-proof span { display: flex; align-items: center; gap: 5px; }

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   Responsive
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
@media (max-width: 1024px) {
  .tf-mag-page .mag-main-layout { grid-template-columns: 1fr; }
  .tf-mag-page .mag-authors-grid { grid-template-columns: repeat(2, 1fr); }
  .tf-mag-page .mag-editors-grid { grid-template-columns: repeat(2, 1fr); }
  .tf-mag-page .mag-hero-inner { grid-template-columns: 1fr; }
  .tf-mag-page .mag-hero-sidebar { display: none; }
}
@media (max-width: 640px) {
  .tf-mag-page .mag-articles-primary { grid-template-columns: 1fr; }
  .tf-mag-page .mag-articles-primary .mag-article-card:first-child { grid-column: 1; }
  .tf-mag-page .mag-editors-grid { grid-template-columns: 1fr; }
  .tf-mag-page .mag-authors-grid { grid-template-columns: 1fr; }
  .tf-mag-page .mag-nl-form { flex-direction: column; border-radius: 8px; }
  .tf-mag-page .mag-nl-form button { justify-content: center; }
}
</style>

<?php
/* ─────────────────────────────────────────────────────────────────
   Helper: render a fake article card (uses WP-style data, could
   be replaced with WP_Query output in a real installation)
───────────────────────────────────────────────────────────────── */

/**
 * Render a magazine article card
 *
 * @param array  $args {
 *   thumb_bg    string  CSS gradient for placeholder thumb
 *   thumb_icon  string  Lucide icon name
 *   thumb_color string  icon color
 *   tag_class   string  CSS class for the tag chip
 *   tag_label   string  Category label
 *   heading     string  Article headline
 *   excerpt     string  Short excerpt
 *   author_init string  Author initials
 *   author_bg   string  Author avatar background
 *   author_name string  Author display name
 *   date        string  Formatted date string
 *   read_time   string  Reading time string
 *   size        string  '' | 'large'
 * }
 */
function tf_mag_article_card( array $args ) : void {
  $size = isset( $args['size'] ) ? esc_attr( $args['size'] ) : '';
  ?>
  <a href="#" class="mag-article-card <?php echo $size; ?>" aria-label="<?php echo esc_attr( $args['heading'] ); ?>">
    <div class="mag-article-thumb" style="background:<?php echo esc_attr( $args['thumb_bg'] ); ?>;color:<?php echo esc_attr( $args['thumb_color'] ); ?>;"
         aria-hidden="true">
      <?php echo tf_icon_get( esc_attr( $args['thumb_icon'] ), 48 ); ?>
      <span class="thumb-cat-badge">
        <span class="mag-tag <?php echo esc_attr( $args['tag_class'] ); ?>"><?php echo esc_html( $args['tag_label'] ); ?></span>
      </span>
    </div>
    <div class="mag-article-body">
      <h3><?php echo esc_html( $args['heading'] ); ?></h3>
      <p><?php echo esc_html( $args['excerpt'] ); ?></p>
      <div class="mag-article-foot">
        <div class="author">
          <div class="author-dot" style="background:<?php echo esc_attr( $args['author_bg'] ); ?>;color:#000;" aria-hidden="true">
            <?php echo esc_html( $args['author_init'] ); ?>
          </div>
          <span><?php echo esc_html( $args['author_name'] ); ?></span>
        </div>
        <div style="display:flex;gap:12px;align-items:center;">
          <span class="mag-date"><?php echo esc_html( $args['date'] ); ?></span>
          <span class="mag-read-time"><?php echo tf_icon_get( 'clock', 12 ); ?> <?php echo esc_html( $args['read_time'] ); ?></span>
        </div>
      </div>
    </div>
  </a>
  <?php
}
?>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     1. BREAKING NEWS TICKER
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<div class="mag-ticker" role="marquee" aria-label="<?php esc_attr_e( 'Breaking news ticker', 'themeflex' ); ?>">
  <div class="mag-ticker-label"><?php esc_html_e( 'BREAKING', 'themeflex' ); ?></div>
  <?php
  $ticker_items = [
    __( 'AI regulation framework expected to pass EU Parliament — vote set for Thursday', 'themeflex' ),
    __( 'Global markets reach record highs as tech sector leads Q1 rally', 'themeflex' ),
    __( 'Breakthrough in quantum computing: 1,000-qubit processor demonstrated', 'themeflex' ),
    __( 'Climate summit yields binding agreements on methane emission cuts', 'themeflex' ),
    __( 'Space agency confirms first commercial crewed mission to lunar orbit', 'themeflex' ),
    __( 'Central bank holds rates steady amid cooling inflation data', 'themeflex' ),
  ];
  // Duplicate for seamless loop
  $all_items = array_merge( $ticker_items, $ticker_items );
  ?>
  <div class="mag-ticker-track" aria-hidden="true">
    <?php foreach ( $all_items as $item ) : ?>
      <a href="#" class="mag-ticker-item">
        <?php echo tf_icon_get( 'radio', 12 ); ?>
        <?php echo esc_html( $item ); ?>
      </a>
    <?php endforeach; ?>
  </div>
</div>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     2. HERO — FEATURED STORY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="mag-hero" aria-label="<?php esc_attr_e( 'Featured story', 'themeflex' ); ?>">
  <div class="mag-hero-inner">
    <!-- Main featured article -->
    <div class="mag-hero-visual">
      <div class="mag-hero-art-quote" aria-hidden="true">&ldquo;</div>

      <!-- Floating chips -->
      <div class="mag-hero-chip mag-hero-chip-1" aria-hidden="true">
        <?php echo tf_icon_get( 'trending-up', 14 ); ?>
        <?php esc_html_e( '#1 Today', 'themeflex' ); ?>
      </div>
      <div class="mag-hero-chip mag-hero-chip-2" aria-hidden="true">
        <?php echo tf_icon_get( 'clock', 12 ); ?>
        <?php esc_html_e( '8 min read', 'themeflex' ); ?>
      </div>

      <div class="mag-hero-visual-art">
        <div class="mag-hero-visual-label">
          <span class="mag-tag mag-tag-orange"><?php esc_html_e( 'Cover Story', 'themeflex' ); ?></span>
          <span class="mag-tag mag-tag-cyan"><?php esc_html_e( 'Technology', 'themeflex' ); ?></span>
        </div>

        <h1 class="mag-hero-headline">
          <?php esc_html_e( 'The Next Wave of AI: Why Every Industry Is About to Change Forever', 'themeflex' ); ?>
        </h1>
        <p class="mag-hero-desc">
          <?php esc_html_e( 'From healthcare diagnostics to legal research, autonomous AI agents are quietly reshaping how work gets done. Here is who is winning, who is at risk, and what comes next.', 'themeflex' ); ?>
        </p>

        <div class="mag-hero-meta">
          <div class="mag-hero-author">
            <div class="mag-hero-author-avatar" aria-hidden="true">EK</div>
            <span class="mag-hero-author-name"><?php esc_html_e( 'Elena Kovač', 'themeflex' ); ?></span>
          </div>
          <span class="mag-date"><?php esc_html_e( 'Apr 26, 2026', 'themeflex' ); ?></span>
          <span class="mag-read-time"><?php echo tf_icon_get( 'clock', 13 ); ?> <?php esc_html_e( '8 min', 'themeflex' ); ?></span>
        </div>
      </div>
    </div>

    <!-- Top Stories Sidebar -->
    <aside class="mag-hero-sidebar" aria-label="<?php esc_attr_e( 'Top stories', 'themeflex' ); ?>">
      <div class="mag-hero-sidebar-title"><?php esc_html_e( 'Top Stories', 'themeflex' ); ?></div>

      <?php
      $top_stories = [
        [
          'num'  => '02',
          'head' => __( 'SpaceX Reveals Starship Upgrade Capable of Reaching Mars Orbit', 'themeflex' ),
          'meta' => __( 'Space · 5 min read', 'themeflex' ),
        ],
        [
          'num'  => '03',
          'head' => __( 'Global Carbon Market Hits $1 Trillion for the First Time', 'themeflex' ),
          'meta' => __( 'Climate · 4 min read', 'themeflex' ),
        ],
        [
          'num'  => '04',
          'head' => __( 'Inside the Lab That Grows Meat Without Animals', 'themeflex' ),
          'meta' => __( 'Science · 6 min read', 'themeflex' ),
        ],
        [
          'num'  => '05',
          'head' => __( 'The Quiet Revolution in Decentralised Finance', 'themeflex' ),
          'meta' => __( 'Finance · 7 min read', 'themeflex' ),
        ],
        [
          'num'  => '06',
          'head' => __( 'How Generational Wealth Is Being Redefined in 2026', 'themeflex' ),
          'meta' => __( 'Economy · 5 min read', 'themeflex' ),
        ],
      ];
      foreach ( $top_stories as $s ) :
      ?>
        <a href="#" class="mag-sidebar-story" aria-label="<?php echo esc_attr( $s['head'] ); ?>">
          <span class="mag-sidebar-story-num" aria-hidden="true"><?php echo esc_html( $s['num'] ); ?></span>
          <div class="mag-sidebar-story-content">
            <h4><?php echo esc_html( $s['head'] ); ?></h4>
            <p><?php echo esc_html( $s['meta'] ); ?></p>
          </div>
        </a>
      <?php endforeach; ?>
    </aside>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     3. CATEGORY RIBBON
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<nav class="mag-cat-ribbon" aria-label="<?php esc_attr_e( 'Browse by category', 'themeflex' ); ?>">
  <div class="mag-container">
    <div class="inner" role="list">
      <?php
      $categories = [
        [ 'label' => __( 'All Stories', 'themeflex' ), 'count' => 248, 'active' => true,  'icon' => 'layout-grid' ],
        [ 'label' => __( 'Technology', 'themeflex' ),  'count' => 84,  'active' => false, 'icon' => 'cpu' ],
        [ 'label' => __( 'Business', 'themeflex' ),    'count' => 61,  'active' => false, 'icon' => 'briefcase' ],
        [ 'label' => __( 'Science', 'themeflex' ),     'count' => 47,  'active' => false, 'icon' => 'flask-conical' ],
        [ 'label' => __( 'Climate', 'themeflex' ),     'count' => 33,  'active' => false, 'icon' => 'leaf' ],
        [ 'label' => __( 'Culture', 'themeflex' ),     'count' => 29,  'active' => false, 'icon' => 'palette' ],
        [ 'label' => __( 'Politics', 'themeflex' ),    'count' => 52,  'active' => false, 'icon' => 'landmark' ],
        [ 'label' => __( 'Opinion', 'themeflex' ),     'count' => 18,  'active' => false, 'icon' => 'message-square' ],
      ];
      foreach ( $categories as $cat ) :
      ?>
        <a href="#" class="mag-cat-link <?php echo $cat['active'] ? 'active' : ''; ?>"
           aria-current="<?php echo $cat['active'] ? 'page' : 'false'; ?>"
           role="listitem">
          <?php echo tf_icon_get( esc_attr( $cat['icon'] ), 15 ); ?>
          <?php echo esc_html( $cat['label'] ); ?>
          <span class="cat-count"><?php echo esc_html( $cat['count'] ); ?></span>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</nav>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     4. MAIN EDITORIAL GRID + SIDEBAR
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="mag-section">
  <div class="mag-container">
    <div class="mag-main-layout">
      <!-- Article Grid -->
      <div>
        <h2 class="mag-section-title">
          <?php esc_html_e( 'Latest Stories', 'themeflex' ); ?>
        </h2>

        <div class="mag-articles-primary">
          <?php
          $articles = [
            [
              'thumb_bg'    => 'linear-gradient(135deg,rgba(6,182,212,.15),rgba(6,182,212,.03))',
              'thumb_icon'  => 'cpu',
              'thumb_color' => '#06b6d4',
              'tag_class'   => 'mag-tag-cyan',
              'tag_label'   => __( 'Technology', 'themeflex' ),
              'heading'     => __( 'Quantum Supremacy Milestone: IBM Demonstrates 1,000-Qubit Processor in Real-World Conditions', 'themeflex' ),
              'excerpt'     => __( 'For the first time, a commercially available quantum computer has solved an optimization problem faster than the world\'s top classical supercomputers — opening the door to cryptography-breaking and drug discovery at scale.', 'themeflex' ),
              'author_init' => 'MR',
              'author_bg'   => '#06b6d4',
              'author_name' => __( 'Marcus R.', 'themeflex' ),
              'date'        => __( 'Apr 26, 2026', 'themeflex' ),
              'read_time'   => __( '9 min', 'themeflex' ),
              'size'        => 'large',
            ],
            [
              'thumb_bg'    => 'linear-gradient(135deg,rgba(168,85,247,.15),rgba(168,85,247,.03))',
              'thumb_icon'  => 'trending-up',
              'thumb_color' => '#a855f7',
              'tag_class'   => 'mag-tag-violet',
              'tag_label'   => __( 'Finance', 'themeflex' ),
              'heading'     => __( 'The Trillion-Dollar Question: Is the AI Boom a Bubble?', 'themeflex' ),
              'excerpt'     => __( 'Valuations of AI-focused companies have quintupled since 2024. Three leading economists weigh in.', 'themeflex' ),
              'author_init' => 'JS',
              'author_bg'   => '#a855f7',
              'author_name' => __( 'Julia S.', 'themeflex' ),
              'date'        => __( 'Apr 25, 2026', 'themeflex' ),
              'read_time'   => __( '6 min', 'themeflex' ),
              'size'        => '',
            ],
            [
              'thumb_bg'    => 'linear-gradient(135deg,rgba(16,185,129,.15),rgba(16,185,129,.03))',
              'thumb_icon'  => 'leaf',
              'thumb_color' => '#10b981',
              'tag_class'   => 'mag-tag-green',
              'tag_label'   => __( 'Climate', 'themeflex' ),
              'heading'     => __( 'Direct Air Capture Costs Drop 40% in Two Years — Are We Finally Close?', 'themeflex' ),
              'excerpt'     => __( 'New modular carbon-capture plants are changing the economics of removing CO₂ directly from the atmosphere.', 'themeflex' ),
              'author_init' => 'AH',
              'author_bg'   => '#10b981',
              'author_name' => __( 'Anna H.', 'themeflex' ),
              'date'        => __( 'Apr 24, 2026', 'themeflex' ),
              'read_time'   => __( '5 min', 'themeflex' ),
              'size'        => '',
            ],
            [
              'thumb_bg'    => 'linear-gradient(135deg,rgba(239,68,68,.15),rgba(239,68,68,.03))',
              'thumb_icon'  => 'landmark',
              'thumb_color' => '#ef4444',
              'tag_class'   => 'mag-tag-red',
              'tag_label'   => __( 'Politics', 'themeflex' ),
              'heading'     => __( 'EU AI Act Enforcement: Which Companies Are Scrambling to Comply?', 'themeflex' ),
              'excerpt'     => __( 'The first wave of audits begins next month. Legal teams are working overtime across Silicon Valley and London.', 'themeflex' ),
              'author_init' => 'TP',
              'author_bg'   => '#ef4444',
              'author_name' => __( 'Tom P.', 'themeflex' ),
              'date'        => __( 'Apr 23, 2026', 'themeflex' ),
              'read_time'   => __( '7 min', 'themeflex' ),
              'size'        => '',
            ],
            [
              'thumb_bg'    => 'linear-gradient(135deg,rgba(249,115,22,.15),rgba(249,115,22,.03))',
              'thumb_icon'  => 'palette',
              'thumb_color' => '#f97316',
              'tag_class'   => 'mag-tag-orange',
              'tag_label'   => __( 'Culture', 'themeflex' ),
              'heading'     => __( 'When AI Writes the Script: Hollywood\'s Unexpected Reckoning', 'themeflex' ),
              'excerpt'     => __( 'Two years after the writers\' strike, studios are using AI tools openly. How writers are adapting — or not.', 'themeflex' ),
              'author_init' => 'CL',
              'author_bg'   => '#f97316',
              'author_name' => __( 'Chloe L.', 'themeflex' ),
              'date'        => __( 'Apr 22, 2026', 'themeflex' ),
              'read_time'   => __( '10 min', 'themeflex' ),
              'size'        => '',
            ],
          ];
          foreach ( $articles as $art ) {
            tf_mag_article_card( $art );
          }
          ?>
        </div>

        <div style="text-align:center;margin-top:32px;">
          <a href="#" class="mag-author-follow" style="font-size:.9rem;padding:12px 28px;">
            <?php echo tf_icon_get( 'refresh-cw', 16 ); ?>
            <?php esc_html_e( 'Load More Stories', 'themeflex' ); ?>
          </a>
        </div>
      </div>

      <!-- Sidebar -->
      <aside class="mag-sidebar" aria-label="<?php esc_attr_e( 'Sidebar', 'themeflex' ); ?>">
        <!-- Trending -->
        <div class="mag-widget">
          <div class="mag-widget-header">
            <h4><?php echo tf_icon_get( 'flame', 15 ); ?> <?php esc_html_e( 'Trending', 'themeflex' ); ?></h4>
            <a href="#"><?php esc_html_e( 'See all', 'themeflex' ); ?></a>
          </div>
          <?php
          $trending = [
            [ 'num' => '01', 'head' => __( 'AI Agents Replace 30% of Entry-Level Jobs by 2028, Study Warns', 'themeflex' ),   'meta' => __( 'Technology · 1.2M reads', 'themeflex' ) ],
            [ 'num' => '02', 'head' => __( 'Inside the Secret Race to Build a Room-Temperature Superconductor', 'themeflex' ), 'meta' => __( 'Science · 840K reads', 'themeflex' ) ],
            [ 'num' => '03', 'head' => __( 'How Three Founders Turned a Side Project Into a $4B Company', 'themeflex' ),       'meta' => __( 'Business · 620K reads', 'themeflex' ) ],
            [ 'num' => '04', 'head' => __( 'The Mental Health Crisis No One Is Talking About', 'themeflex' ),                  'meta' => __( 'Health · 510K reads', 'themeflex' ) ],
            [ 'num' => '05', 'head' => __( 'Crypto Returns? Why Institutional Money Is Back', 'themeflex' ),                  'meta' => __( 'Finance · 480K reads', 'themeflex' ) ],
          ];
          foreach ( $trending as $t ) :
          ?>
            <a href="#" class="mag-trending-item" aria-label="<?php echo esc_attr( $t['head'] ); ?>">
              <span class="mag-trending-num" aria-hidden="true"><?php echo esc_html( $t['num'] ); ?></span>
              <div class="mag-trending-text">
                <h5><?php echo esc_html( $t['head'] ); ?></h5>
                <span><?php echo esc_html( $t['meta'] ); ?></span>
              </div>
            </a>
          <?php endforeach; ?>
        </div>

        <!-- Tags Cloud -->
        <div class="mag-widget">
          <div class="mag-widget-header">
            <h4><?php echo tf_icon_get( 'tag', 15 ); ?> <?php esc_html_e( 'Popular Topics', 'themeflex' ); ?></h4>
          </div>
          <div class="mag-tags-cloud">
            <?php
            $tags = [
              [ 'label' => 'Artificial Intelligence', 'class' => 'mag-tag-cyan' ],
              [ 'label' => 'Startups',                'class' => 'mag-tag-orange' ],
              [ 'label' => 'Climate Change',          'class' => 'mag-tag-green' ],
              [ 'label' => 'Quantum Computing',       'class' => 'mag-tag-violet' ],
              [ 'label' => 'Space Exploration',       'class' => 'mag-tag-cyan' ],
              [ 'label' => 'Geopolitics',             'class' => 'mag-tag-red' ],
              [ 'label' => 'Fintech',                 'class' => 'mag-tag-orange' ],
              [ 'label' => 'Mental Health',           'class' => 'mag-tag-violet' ],
              [ 'label' => 'Future of Work',          'class' => 'mag-tag-green' ],
              [ 'label' => 'Biotechnology',           'class' => 'mag-tag-cyan' ],
            ];
            foreach ( $tags as $tag ) :
            ?>
              <a href="#" class="mag-tag <?php echo esc_attr( $tag['class'] ); ?>">
                <?php echo esc_html( $tag['label'] ); ?>
              </a>
            <?php endforeach; ?>
          </div>
        </div>

        <!-- Newsletter widget -->
        <div class="mag-widget">
          <div class="mag-widget-header">
            <h4><?php echo tf_icon_get( 'mail', 15 ); ?> <?php esc_html_e( 'Newsletter', 'themeflex' ); ?></h4>
          </div>
          <div class="mag-newsletter-widget">
            <p><?php esc_html_e( 'Get the most important stories delivered to your inbox every morning.', 'themeflex' ); ?></p>
            <form action="#" method="post" class="mag-nl-input-row" aria-label="<?php esc_attr_e( 'Newsletter signup', 'themeflex' ); ?>">
              <?php wp_nonce_field( 'mag_newsletter', 'mag_nl_nonce' ); ?>
              <input type="email" name="email" required
                     placeholder="<?php esc_attr_e( 'your@email.com', 'themeflex' ); ?>"
                     autocomplete="email"
                     aria-label="<?php esc_attr_e( 'Your email address', 'themeflex' ); ?>">
              <button type="submit">
                <?php echo tf_icon_get( 'send', 16 ); ?>
                <?php esc_html_e( 'Subscribe Free', 'themeflex' ); ?>
              </button>
            </form>
            <p style="font-size:.72rem;margin-top:10px;"><?php esc_html_e( 'No spam. Unsubscribe any time.', 'themeflex' ); ?></p>
          </div>
        </div>
      </aside>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     5. EDITOR'S PICK
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="mag-section mag-editors-pick">
  <div class="mag-container">
    <h2 class="mag-section-title">
      <span class="mag-label"><?php esc_html_e( "Editor's Pick", 'themeflex' ); ?></span>
    </h2>

    <div class="mag-editors-grid">
      <?php
      $editors = [
        [
          'thumb_bg'    => 'linear-gradient(135deg,rgba(249,115,22,.2),rgba(249,115,22,.05))',
          'thumb_icon'  => 'zap',
          'thumb_color' => '#f97316',
          'tag_class'   => 'mag-tag-orange',
          'tag_label'   => __( 'Opinion', 'themeflex' ),
          'heading'     => __( 'Why the Next Decade Belongs to Those Who Master Human-AI Collaboration', 'themeflex' ),
          'excerpt'     => __( 'The companies thriving in 2026 are not replacing humans with AI — they are building new rituals where both excel.', 'themeflex' ),
          'author_init' => 'RB',
          'author_bg'   => '#f97316',
          'author_name' => __( 'Rina B.', 'themeflex' ),
          'date'        => __( 'Apr 20, 2026', 'themeflex' ),
          'read_time'   => __( '12 min', 'themeflex' ),
          'size'        => '',
        ],
        [
          'thumb_bg'    => 'linear-gradient(135deg,rgba(6,182,212,.2),rgba(6,182,212,.05))',
          'thumb_icon'  => 'flask-conical',
          'thumb_color' => '#06b6d4',
          'tag_class'   => 'mag-tag-cyan',
          'tag_label'   => __( 'Science', 'themeflex' ),
          'heading'     => __( 'The Protein-Folding Revolution Is Just Getting Started', 'themeflex' ),
          'excerpt'     => __( 'AlphaFold3 cracked structural biology. Now a new generation of researchers is using it to design drugs from scratch.', 'themeflex' ),
          'author_init' => 'LN',
          'author_bg'   => '#06b6d4',
          'author_name' => __( 'Lena N.', 'themeflex' ),
          'date'        => __( 'Apr 18, 2026', 'themeflex' ),
          'read_time'   => __( '8 min', 'themeflex' ),
          'size'        => '',
        ],
        [
          'thumb_bg'    => 'linear-gradient(135deg,rgba(16,185,129,.2),rgba(16,185,129,.05))',
          'thumb_icon'  => 'globe',
          'thumb_color' => '#10b981',
          'tag_class'   => 'mag-tag-green',
          'tag_label'   => __( 'Economy', 'themeflex' ),
          'heading'     => __( 'Universal Basic Income: The Countries Running Real-World Tests', 'themeflex' ),
          'excerpt'     => __( 'Finland, Kenya, and California have run pilots. What did we actually learn — and what do the numbers really show?', 'themeflex' ),
          'author_init' => 'DW',
          'author_bg'   => '#10b981',
          'author_name' => __( 'David W.', 'themeflex' ),
          'date'        => __( 'Apr 16, 2026', 'themeflex' ),
          'read_time'   => __( '9 min', 'themeflex' ),
          'size'        => '',
        ],
      ];
      foreach ( $editors as $ed ) {
        tf_mag_article_card( $ed );
      }
      ?>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     6. AUTHOR SPOTLIGHT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="mag-section">
  <div class="mag-container">
    <h2 class="mag-section-title"><?php esc_html_e( 'Our Writers', 'themeflex' ); ?></h2>

    <div class="mag-authors-grid">
      <?php
      $authors = [
        [
          'init'    => 'EK',
          'bg'      => 'linear-gradient(135deg,#f97316,#ea580c)',
          'name'    => __( 'Elena Kovač', 'themeflex' ),
          'beat'    => __( 'AI & Technology', 'themeflex' ),
          'bio'     => __( 'Former Google researcher turned journalist. Covers the intersection of artificial intelligence and society.', 'themeflex' ),
          'pieces'  => 94,
          'readers' => '1.2M',
        ],
        [
          'init'    => 'MR',
          'bg'      => 'linear-gradient(135deg,#06b6d4,#0891b2)',
          'name'    => __( 'Marcus Reid', 'themeflex' ),
          'beat'    => __( 'Science & Space', 'themeflex' ),
          'bio'     => __( 'PhD in astrophysics. Contributed to Nature, Science, and Wired before joining this publication.', 'themeflex' ),
          'pieces'  => 71,
          'readers' => '860K',
        ],
        [
          'init'    => 'JS',
          'bg'      => 'linear-gradient(135deg,#a855f7,#7c3aed)',
          'name'    => __( 'Julia Stern', 'themeflex' ),
          'beat'    => __( 'Finance & Markets', 'themeflex' ),
          'bio'     => __( 'Ex-Goldman Sachs analyst. Breaks down complex financial stories for a general audience.', 'themeflex' ),
          'pieces'  => 58,
          'readers' => '720K',
        ],
        [
          'init'    => 'AH',
          'bg'      => 'linear-gradient(135deg,#10b981,#059669)',
          'name'    => __( 'Anna Huber', 'themeflex' ),
          'beat'    => __( 'Climate & Policy', 'themeflex' ),
          'bio'     => __( 'Environmental journalist and Pulitzer Prize finalist covering global climate negotiations and clean-tech.', 'themeflex' ),
          'pieces'  => 83,
          'readers' => '940K',
        ],
      ];
      foreach ( $authors as $au ) :
      ?>
        <article class="mag-author-card">
          <div class="mag-author-avatar" style="background:<?php echo esc_attr( $au['bg'] ); ?>;color:#000;" aria-hidden="true">
            <?php echo esc_html( $au['init'] ); ?>
          </div>
          <h4><?php echo esc_html( $au['name'] ); ?></h4>
          <div class="author-beat"><?php echo esc_html( $au['beat'] ); ?></div>
          <p><?php echo esc_html( $au['bio'] ); ?></p>
          <div class="mag-author-stats">
            <span>
              <strong><?php echo esc_html( $au['pieces'] ); ?></strong>
              <?php esc_html_e( 'pieces', 'themeflex' ); ?>
            </span>
            <span>
              <strong><?php echo esc_html( $au['readers'] ); ?></strong>
              <?php esc_html_e( 'readers', 'themeflex' ); ?>
            </span>
          </div>
          <a href="#" class="mag-author-follow" aria-label="<?php printf( esc_attr__( 'Follow %s', 'themeflex' ), esc_attr( $au['name'] ) ); ?>">
            <?php echo tf_icon_get( 'user-plus', 14 ); ?>
            <?php esc_html_e( 'Follow', 'themeflex' ); ?>
          </a>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     7. NEWSLETTER CTA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ -->
<section class="mag-section mag-nl-section">
  <div class="mag-container" style="position:relative;z-index:1;">
    <div class="mag-label" style="margin-bottom:20px;"><?php esc_html_e( 'Free Newsletter', 'themeflex' ); ?></div>
    <h2>
      <?php esc_html_e( 'Stay Ahead of the', 'themeflex' ); ?>
      <em><?php esc_html_e( 'Story', 'themeflex' ); ?></em>
    </h2>
    <p><?php esc_html_e( 'Join 240,000 readers who get the most important stories, data, and insights in their inbox every weekday morning.', 'themeflex' ); ?></p>

    <form class="mag-nl-form" action="#" method="post" aria-label="<?php esc_attr_e( 'Newsletter signup form', 'themeflex' ); ?>">
      <?php wp_nonce_field( 'mag_newsletter_main', 'mag_nl_main_nonce' ); ?>
      <input type="email" name="email" required
             placeholder="<?php esc_attr_e( 'Enter your email address', 'themeflex' ); ?>"
             autocomplete="email"
             aria-label="<?php esc_attr_e( 'Your email address', 'themeflex' ); ?>">
      <button type="submit">
        <?php echo tf_icon_get( 'send', 16 ); ?>
        <?php esc_html_e( 'Subscribe Free', 'themeflex' ); ?>
      </button>
    </form>

    <div class="mag-nl-proof">
      <span><?php echo tf_icon_get( 'users', 14 ); ?> <?php esc_html_e( '240K+ subscribers', 'themeflex' ); ?></span>
      <span><?php echo tf_icon_get( 'shield-check', 14 ); ?> <?php esc_html_e( 'No spam, ever', 'themeflex' ); ?></span>
      <span><?php echo tf_icon_get( 'x-circle', 14 ); ?> <?php esc_html_e( 'Unsubscribe in one click', 'themeflex' ); ?></span>
      <span><?php echo tf_icon_get( 'star', 14 ); ?> <?php esc_html_e( '4.9★ reader satisfaction', 'themeflex' ); ?></span>
    </div>
  </div>
</section>

</div><!-- /.tf-mag-page -->

<?php get_footer(); ?>
