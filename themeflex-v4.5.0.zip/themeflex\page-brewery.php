<?php
/**
 * Template Name: Brewery – Craft Brewery & Taproom
 *
 * Premium page template for a craft brewery and taproom.
 * Namespace : --brw-*
 * Fonts     : Bebas Neue (headings) + Karla (body)
 * Palette   : midnight #0d1117, charcoal #181f28, slate #232e3c,
 *             copper #c8702a, gold #e8a84a, cream #f5ede0, foam #faf5ee
 * Hero      : CSS brewery interior – copper kettles, grain sacks,
 *             steam pipes, hops vines, amber backlighting
 */

srand(crc32(get_the_permalink()));

/* ── PHP data ───────────────────────────────────────────── */

$beers = [
    ['name'=>'Iron Foundry Stout',      'style'=>'Imperial Stout',    'abv'=>'9.2','ibu'=>'68','desc'=>'Roasted espresso and dark chocolate, velvety body with a warming finish of aged oak and vanilla.','badge'=>'Year-Round','color'=>'#1a0a00'],
    ['name'=>'Copper Kettle Amber',     'style'=>'American Amber Ale','abv'=>'5.6','ibu'=>'32','desc'=>'Caramel malt backbone, balanced citrus hops, clean and approachable with a toasted biscuit aroma.','badge'=>'Flagship','color'=>'#c8702a'],
    ['name'=>'Harvest Wheat',           'style'=>'Hefeweizen',        'abv'=>'4.8','ibu'=>'14','desc'=>'Unfiltered Bavarian wheat, banana-clove esters, soft and refreshing with a cloud-white head.','badge'=>'Seasonal','color'=>'#e8c060'],
    ['name'=>'Ridgeline IPA',           'style'=>'West Coast IPA',    'abv'=>'6.8','ibu'=>'72','desc'=>'Cascade and Centennial hops deliver pine resin and tropical citrus over a crisp, dry malt base.','badge'=>'Year-Round','color'=>'#b87820'],
    ['name'=>'Midnight Porter',         'style'=>'Robust Porter',     'abv'=>'5.9','ibu'=>'38','desc'=>'Cold-brew coffee notes, hints of molasses and toffee, dry-hopped for a subtle floral lift at the close.','badge'=>'Autumn','color'=>'#2a1400'],
    ['name'=>'Fog Machine Hazy',        'style'=>'New England IPA',   'abv'=>'7.1','ibu'=>'45','desc'=>'Juicy mango, peach and passionfruit burst forth in this opaque, pillowy-soft double dry-hopped NEIPA.','badge'=>'Limited','color'=>'#d4a840'],
];

$food = [
    ['cat'=>'Snacks & Starters', 'items'=>[
        ['n'=>'Pretzel Board',         'p'=>'£9',  'd'=>'House-baked soft pretzels, whole-grain mustard, beer cheese fondue'],
        ['n'=>'Hop-Dusted Wings',      'p'=>'£12', 'd'=>'12 wings, double-smoked, three house sauces, celery & blue cheese'],
        ['n'=>'Pickled Veg Jar',       'p'=>'£6',  'd'=>'Seasonal pickles brined in spent grain malt, bread & butter style'],
    ]],
    ['cat'=>'Mains', 'items'=>[
        ['n'=>'Smoked Brisket Bap',    'p'=>'£14', 'd'=>'12-hour oak-smoked brisket, copper ale BBQ, brioche bun, slaw'],
        ['n'=>'Brewery Burger',        'p'=>'£15', 'd'=>'8oz chuck blend, amber ale cheddar, caramelised onion, brioche'],
        ['n'=>'Grain Bowl',            'p'=>'£13', 'd'=>'Farro, roasted root veg, tahini, toasted seeds, hop oil drizzle'],
    ]],
    ['cat'=>'Desserts', 'items'=>[
        ['n'=>'Stout Brownie',         'p'=>'£7',  'd'=>'Imperial stout baked into fudgy dark chocolate, vanilla gelato'],
        ['n'=>'Spent-Grain Cookie',    'p'=>'£4',  'd'=>'Golden oat & spent malt cookie with salted caramel dip'],
    ]],
];

$tours = [
    ['time'=>'12:00','days'=>'Sat & Sun',     'slots'=>8, 'price'=>'£18'],
    ['time'=>'14:30','days'=>'Fri – Sun',     'slots'=>12,'price'=>'£18'],
    ['time'=>'17:00','days'=>'Fri & Sat',     'slots'=>10,'price'=>'£22'],
    ['time'=>'19:30','days'=>'Saturday Only', 'slots'=>8, 'price'=>'£25'],
];

$team = [
    ['name'=>'Declan Harte',     'role'=>'Head Brewer',        'note'=>'15 years craft-brewing across Ireland, Germany and the Pacific North-West.'],
    ['name'=>'Saoirse Brennan',  'role'=>'Lead Cellar Manager','note'=>'Specialist in barrel ageing and mixed-fermentation wild ales.'],
    ['name'=>'Marcus Webb',      'role'=>'Taproom Manager',    'note'=>'Curates seasonal rotating taps and manages our cask programme.'],
    ['name'=>'Fiona Lau',        'role'=>'Head Chef',          'note'=>'Designs a food menu that matches every beer style on the board.'],
];

$awards = [
    ['yr'=>'2024','comp'=>'Great British Beer Festival',    'beer'=>'Iron Foundry Stout',   'medal'=>'Gold'],
    ['yr'=>'2024','comp'=>'CAMRA Champions Awards',         'beer'=>'Copper Kettle Amber',  'medal'=>'Silver'],
    ['yr'=>'2023','comp'=>'World Beer Awards – UK',         'beer'=>'Fog Machine Hazy',     'medal'=>'Gold'],
    ['yr'=>'2023','comp'=>'Independent Beer & Wine Awards', 'beer'=>'Ridgeline IPA',        'medal'=>'Bronze'],
    ['yr'=>'2022','comp'=>'Great British Beer Festival',    'beer'=>'Midnight Porter',      'medal'=>'Gold'],
    ['yr'=>'2022','comp'=>'Craft Beer Awards',              'beer'=>'Harvest Wheat',        'medal'=>'Silver'],
];

$faqs = [
    ['q'=>'Do you accept walk-ins to the taproom?','a'=>'Yes — the taproom is open Tuesday–Sunday from 12:00 to 22:00 (23:00 on Fri & Sat). No reservation needed for casual pints, though we recommend booking for groups of 8 or more.'],
    ['q'=>'Are brewery tours child-friendly?','a'=>'Tours welcome visitors aged 16 and over. Under-18s must be accompanied by a responsible adult. Our tasting sessions are strictly 18+.'],
    ['q'=>'Can I order your beers online?','a'=>'Absolutely — we ship cases of 12 across mainland UK via our online shop. We also do local home delivery within a 15-mile radius every Thursday.'],
    ['q'=>'Do you offer private hire?','a'=>'Yes. The taproom can be exclusively hired for events of up to 120 guests. We offer bespoke tasting flights, paired food menus and live entertainment packages.'],
    ['q'=>'What\'s on tap right now?','a'=>'Our rotating tap board features 16 lines. Six are permanent core beers; the remaining ten change with the season and limited-batch releases. Check our social media for the live tap list.'],
];

/* ── PHP hero assets ─────────────────────────────────────── */

// Hop vine leaves (left and right columns)
$left_hops  = [];
$right_hops = [];
for ($i = 0; $i < 9; $i++) {
    $left_hops[]  = ['top' => rand(5, 90), 'size' => rand(18, 32), 'r' => rand(-30, 30), 'delay' => rand(0, 4000)];
    $right_hops[] = ['top' => rand(5, 90), 'size' => rand(18, 32), 'r' => rand(-30, 30), 'delay' => rand(0, 4000)];
}

// Hops cones
$hop_cones = [];
for ($i = 0; $i < 14; $i++) {
    $hop_cones[] = ['left' => rand(5, 95), 'top' => rand(10, 85), 'delay' => rand(0, 3000)];
}

// Steam puffs
$steam_puffs = [];
for ($i = 0; $i < 6; $i++) {
    $steam_puffs[] = ['left' => rand(25, 70), 'delay' => rand(0, 3500), 'size' => rand(18, 34), 'dur' => rand(3000, 5500)];
}

// Bubbles in kettles
$bubbles = [];
for ($i = 0; $i < 20; $i++) {
    $bubbles[] = ['left' => rand(10, 90), 'size' => rand(4, 12), 'delay' => rand(0, 3000), 'dur' => rand(1500, 3500)];
}

// Stars / spark particles in amber backlight
$sparks = [];
for ($i = 0; $i < 30; $i++) {
    $sparks[] = ['left' => rand(0, 100), 'top' => rand(0, 100), 'delay' => rand(0, 5000), 'dur' => rand(2000, 6000), 'size' => rand(2, 5)];
}

?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Karla:ital,wght@0,300;0,400;0,500;0,700;1,400&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════
   BREWERY – CRAFT BREWERY & TAPROOM
   Namespace: --brw-*
═══════════════════════════════════════════════ */
:root{
  --brw-midnight:#0d1117;
  --brw-charcoal:#181f28;
  --brw-slate:#232e3c;
  --brw-copper:#c8702a;
  --brw-copper-lt:#e0894a;
  --brw-copper-dk:#8c4e1c;
  --brw-gold:#e8a84a;
  --brw-cream:#f5ede0;
  --brw-foam:#faf5ee;
  --brw-amber:#d4740e;
  --brw-r:16px;
  --brw-ff-head:'Bebas Neue',sans-serif;
  --brw-ff-body:'Karla',sans-serif;
}

*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}

.brw-page{
  background:var(--brw-midnight);
  color:var(--brw-cream);
  font-family:var(--brw-ff-body);
  font-size:16px;
  line-height:1.7;
  overflow-x:hidden;
}

/* ── NAV ─────────────────────────────────────── */
.brw-nav{
  position:fixed;top:0;left:0;right:0;z-index:1000;
  display:flex;align-items:center;justify-content:space-between;
  padding:0 48px;height:72px;
  background:linear-gradient(180deg,rgba(13,17,23,.97) 0%,rgba(13,17,23,.85) 100%);
  border-bottom:1px solid rgba(200,112,42,.25);
  backdrop-filter:blur(10px);
}
.brw-nav-logo{
  font-family:var(--brw-ff-head);
  font-size:26px;letter-spacing:.08em;
  color:var(--brw-cream);text-decoration:none;
}
.brw-nav-logo span{color:var(--brw-copper);}
.brw-nav-links{display:flex;gap:32px;list-style:none;}
.brw-nav-links a{
  color:rgba(245,237,224,.8);text-decoration:none;
  font-size:13px;font-weight:500;letter-spacing:.06em;text-transform:uppercase;
  transition:color .2s;
}
.brw-nav-links a:hover{color:var(--brw-gold);}
.brw-nav-cta{
  display:inline-flex;align-items:center;gap:8px;
  padding:10px 22px;border-radius:4px;
  background:var(--brw-copper);color:var(--brw-cream);
  font-size:13px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
  text-decoration:none;transition:background .2s;
}
.brw-nav-cta:hover{background:var(--brw-copper-lt);}

/* ── HERO ─────────────────────────────────────── */
.brw-hero{
  position:relative;min-height:100vh;
  display:flex;align-items:center;
  overflow:hidden;
  background:linear-gradient(180deg,
    #080b0f 0%,
    #0d1117 20%,
    #131a26 55%,
    #1a2a1a 75%,
    #0e1810 100%
  );
}

/* Amber backlight glow */
.brw-hero-glow{
  position:absolute;inset:0;pointer-events:none;
  background:
    radial-gradient(ellipse 60% 50% at 50% 60%, rgba(200,112,42,.18) 0%, transparent 70%),
    radial-gradient(ellipse 30% 30% at 30% 55%, rgba(232,168,74,.10) 0%, transparent 60%),
    radial-gradient(ellipse 30% 30% at 70% 55%, rgba(232,168,74,.10) 0%, transparent 60%);
}

/* Floating sparks */
.brw-spark{
  position:absolute;
  border-radius:50%;
  background:rgba(232,168,74,.7);
  pointer-events:none;
  animation:brw-spark-float linear infinite;
}
@keyframes brw-spark-float{
  0%{transform:translateY(0) scale(1);opacity:.8}
  50%{opacity:.3}
  100%{transform:translateY(-60px) scale(0);opacity:0}
}

/* Brewery interior scene */
.brw-scene{
  position:absolute;inset:0;
  display:flex;align-items:flex-end;
  pointer-events:none;
}

/* Floor */
.brw-floor{
  position:absolute;bottom:0;left:0;right:0;
  height:180px;
  background:repeating-linear-gradient(
    90deg,
    #1a1208 0px,#1a1208 48px,
    #221810 48px,#221810 50px
  ),
  repeating-linear-gradient(
    0deg,
    transparent 0px,transparent 48px,
    rgba(0,0,0,.4) 48px,rgba(0,0,0,.4) 50px
  );
  background-color:#161008;
  border-top:3px solid rgba(200,112,42,.3);
}

/* Back wall */
.brw-wall{
  position:absolute;top:72px;left:0;right:0;bottom:180px;
  background:linear-gradient(180deg,#0a0e14 0%,#111820 100%);
}
.brw-wall::before{
  content:'';position:absolute;inset:0;
  background:repeating-linear-gradient(
    90deg,
    transparent 0px,transparent 59px,
    rgba(255,255,255,.03) 59px,rgba(255,255,255,.03) 60px
  ),
  repeating-linear-gradient(
    0deg,
    transparent 0px,transparent 59px,
    rgba(255,255,255,.03) 59px,rgba(255,255,255,.03) 60px
  );
}

/* Hops vine columns */
.brw-hops-col{
  position:absolute;top:72px;bottom:180px;
  width:60px;
}
.brw-hops-col.left{ left:40px;}
.brw-hops-col.right{right:40px;}

/* Vine stem */
.brw-hops-col::before{
  content:'';position:absolute;
  top:0;bottom:0;left:50%;transform:translateX(-50%);
  width:3px;
  background:linear-gradient(180deg,transparent 0%,#3a5a1a 10%,#2e4a12 90%,transparent 100%);
}

.brw-hop-leaf{
  position:absolute;
  border-radius:50% 10% 50% 10%;
  background:radial-gradient(circle at 40% 40%, #5a8a2a, #2e4a12);
  transform-origin:50% 100%;
  animation:brw-leaf-sway 4s ease-in-out infinite alternate;
}
@keyframes brw-leaf-sway{
  from{transform:rotate(-8deg)}
  to{transform:rotate(8deg)}
}

.brw-hop-cone{
  position:absolute;
  width:10px;height:16px;
  border-radius:50% 50% 40% 40%;
  background:radial-gradient(circle at 40% 30%, #8ab840, #5a7a20);
  animation:brw-cone-bob 3s ease-in-out infinite alternate;
}
@keyframes brw-cone-bob{
  from{transform:translateY(0)}
  to{transform:translateY(-4px)}
}

/* Copper kettles */
.brw-kettles{
  position:absolute;
  bottom:180px;left:50%;transform:translateX(-50%);
  display:flex;gap:48px;align-items:flex-end;
}

/* Individual kettle */
.brw-kettle{
  position:relative;
  display:flex;flex-direction:column;align-items:center;
}

.brw-kettle-body{
  width:130px;height:180px;
  border-radius:50% 50% 45% 45% / 30% 30% 60% 60%;
  background:
    radial-gradient(ellipse 70% 60% at 35% 35%, rgba(255,220,150,.25), transparent 60%),
    linear-gradient(160deg,#b86020 0%,#8c4e1c 30%,#6a3010 60%,#4a2008 100%);
  position:relative;
  box-shadow:
    inset -8px -8px 20px rgba(0,0,0,.5),
    inset 4px 4px 12px rgba(255,200,100,.15),
    0 4px 30px rgba(200,112,42,.3),
    0 0 60px rgba(200,112,42,.15);
}
.brw-kettle-body::before{
  content:'';position:absolute;
  top:8px;left:12px;right:12px;height:60%;
  border-radius:50%;
  background:radial-gradient(ellipse at 40% 35%, rgba(255,220,130,.2) 0%, transparent 70%);
}

/* Kettle top ring */
.brw-kettle-top{
  width:150px;height:24px;
  border-radius:50%;
  background:linear-gradient(180deg,#d48030,#8c4e1c);
  box-shadow:0 2px 8px rgba(0,0,0,.4);
  position:relative;z-index:2;
  margin-bottom:-6px;
}
.brw-kettle-top::before{
  content:'';position:absolute;
  top:50%;left:50%;transform:translate(-50%,-50%);
  width:60%;height:12px;
  border-radius:50%;
  background:rgba(200,160,80,.3);
}

/* Kettle neck pipe */
.brw-kettle-neck{
  width:36px;height:40px;
  background:linear-gradient(180deg,#8c4e1c,#6a3010);
  margin-bottom:-2px;
  position:relative;z-index:1;
}
.brw-kettle-neck::before,
.brw-kettle-neck::after{
  content:'';position:absolute;
  left:50%;transform:translateX(-50%);
  width:50px;height:8px;
  background:linear-gradient(90deg,#a0601e,#8c4e1c);
  border-radius:3px;
}
.brw-kettle-neck::before{top:0;}
.brw-kettle-neck::after{bottom:0;}

/* Kettle stand legs */
.brw-kettle-legs{
  width:120px;height:48px;
  position:relative;
}
.brw-kettle-legs::before,
.brw-kettle-legs::after{
  content:'';position:absolute;
  bottom:0;width:14px;height:100%;
  background:linear-gradient(180deg,#5a3010,#3a1e08);
  border-radius:3px 3px 0 0;
}
.brw-kettle-legs::before{left:18px;transform:rotate(-6deg);}
.brw-kettle-legs::after{right:18px;transform:rotate(6deg);}

/* Kettle size variants */
.brw-kettle.large .brw-kettle-body{width:170px;height:230px;}
.brw-kettle.large .brw-kettle-top{width:195px;}
.brw-kettle.large .brw-kettle-legs{width:160px;}
.brw-kettle.small .brw-kettle-body{width:100px;height:140px;}
.brw-kettle.small .brw-kettle-top{width:118px;}
.brw-kettle.small .brw-kettle-legs{width:95px;}

/* Kettle label */
.brw-kettle-label{
  position:absolute;top:45%;left:50%;
  transform:translate(-50%,-50%);
  font-family:var(--brw-ff-head);
  font-size:13px;letter-spacing:.1em;
  color:rgba(245,237,224,.6);
  text-align:center;
  pointer-events:none;
  white-space:nowrap;
}

/* Pipe network */
.brw-pipes{
  position:absolute;
  bottom:180px;left:0;right:0;
  height:80px;
  pointer-events:none;
}
.brw-pipe-h{
  position:absolute;
  height:10px;
  background:linear-gradient(180deg,#8c4e1c,#6a3010);
  border-radius:5px;
  box-shadow:0 2px 6px rgba(0,0,0,.4);
}
.brw-pipe-v{
  position:absolute;
  width:10px;
  background:linear-gradient(90deg,#8c4e1c,#6a3010);
  border-radius:5px;
  box-shadow:2px 0 6px rgba(0,0,0,.4);
}
.brw-pipe-joint{
  position:absolute;
  width:18px;height:18px;
  border-radius:50%;
  background:radial-gradient(circle at 35% 35%, #c87030, #6a3010);
  transform:translate(-50%,-50%);
  box-shadow:0 2px 6px rgba(0,0,0,.4);
}

/* Grain sacks */
.brw-sack{
  position:absolute;bottom:180px;
  width:72px;height:90px;
  border-radius:40% 40% 48% 48% / 30% 30% 60% 60%;
  background:
    repeating-linear-gradient(
      45deg,
      rgba(255,255,255,.04) 0px,rgba(255,255,255,.04) 2px,
      transparent 2px,transparent 10px
    ),
    linear-gradient(160deg,#6b4420,#4a2e14);
  box-shadow:inset -4px -6px 12px rgba(0,0,0,.4);
}
.brw-sack::before{
  content:'';position:absolute;
  top:18px;left:12px;right:12px;
  height:3px;border-radius:2px;
  background:rgba(200,160,80,.5);
  box-shadow:0 14px 0 rgba(200,160,80,.4),0 28px 0 rgba(200,160,80,.3);
}
.brw-sack::after{
  content:'MALT';
  position:absolute;
  top:50%;left:50%;transform:translate(-50%,-50%);
  font-family:var(--brw-ff-head);
  font-size:10px;letter-spacing:.15em;
  color:rgba(245,237,224,.4);
}

/* Beer tap bar */
.brw-tap-bar{
  position:absolute;
  bottom:140px;left:50%;
  transform:translateX(-50%);
  width:340px;height:40px;
  background:linear-gradient(90deg,#3a1e08,#5a3010,#3a1e08);
  border-radius:6px 6px 0 0;
  box-shadow:0 -2px 10px rgba(0,0,0,.4);
}
.brw-tap-bar::before{
  content:'';position:absolute;
  bottom:100%;left:50%;transform:translateX(-50%);
  width:380px;height:8px;
  background:linear-gradient(90deg,#2e1806,#4a2a0e,#2e1806);
  border-radius:4px;
}

/* Individual taps */
.brw-taps{
  position:absolute;
  bottom:178px;left:50%;
  transform:translateX(-50%);
  display:flex;gap:52px;
}
.brw-tap{
  display:flex;flex-direction:column;align-items:center;
}
.brw-tap-handle{
  width:14px;height:72px;
  border-radius:7px 7px 3px 3px;
  position:relative;
}
.brw-tap-handle::before{
  content:'';position:absolute;
  top:-10px;left:50%;transform:translateX(-50%);
  width:22px;height:14px;
  border-radius:50% 50% 30% 30%;
  background:inherit;
  box-shadow:0 -2px 6px rgba(0,0,0,.3);
}
.brw-tap-handle::after{
  content:'';position:absolute;
  bottom:0;left:50%;transform:translateX(-50%);
  width:8px;height:28px;
  background:linear-gradient(90deg,#8c4e1c,#6a3010);
  border-radius:0 0 3px 3px;
}
.brw-tap-nozzle{
  width:12px;height:16px;
  border-radius:3px 3px 6px 6px;
  background:linear-gradient(90deg,#4a4a4a,#2a2a2a);
  margin-top:-2px;
}

/* Steam effect */
.brw-steam{
  position:absolute;
  border-radius:50%;
  background:rgba(200,200,200,.12);
  filter:blur(8px);
  animation:brw-steam-rise linear infinite;
  pointer-events:none;
}
@keyframes brw-steam-rise{
  0%{transform:translateY(0) scaleX(1);opacity:.6}
  50%{transform:translateY(-60px) scaleX(1.4);opacity:.25}
  100%{transform:translateY(-120px) scaleX(2);opacity:0}
}

/* Bubbles */
.brw-bubble{
  position:absolute;bottom:0;
  border-radius:50%;
  border:1px solid rgba(232,168,74,.5);
  background:transparent;
  animation:brw-bubble-rise linear infinite;
  pointer-events:none;
}
@keyframes brw-bubble-rise{
  0%{transform:translateY(0);opacity:.6}
  100%{transform:translateY(-200px);opacity:0}
}

/* Chalkboard sign */
.brw-chalkboard{
  position:absolute;
  top:100px;right:80px;
  width:180px;
  background:#1e2a18;
  border:5px solid #3a2a10;
  border-radius:4px;
  padding:16px 14px;
  box-shadow:4px 4px 12px rgba(0,0,0,.5);
}
.brw-chalkboard::before{
  content:'TODAY\'S SPECIALS';
  display:block;
  font-family:var(--brw-ff-head);
  font-size:12px;letter-spacing:.12em;
  color:rgba(245,237,224,.7);
  border-bottom:1px solid rgba(245,237,224,.3);
  padding-bottom:6px;margin-bottom:8px;
}
.brw-chalkboard-item{
  font-size:10px;line-height:1.6;
  color:rgba(245,237,224,.6);
  font-family:var(--brw-ff-body);
}
.brw-chalkboard-abv{
  color:var(--brw-gold);font-weight:700;
}

/* Hero overlay */
.brw-hero-overlay{
  position:absolute;inset:0;
  background:linear-gradient(
    135deg,
    rgba(13,17,23,.65) 0%,
    rgba(13,17,23,.3) 40%,
    rgba(13,17,23,.1) 65%,
    rgba(13,17,23,.5) 100%
  );
}

/* Hero content */
.brw-hero-content{
  position:relative;z-index:10;
  max-width:680px;
  padding:140px 48px 80px;
}
.brw-hero-eyebrow{
  display:inline-flex;align-items:center;gap:10px;
  font-size:12px;font-weight:700;letter-spacing:.15em;text-transform:uppercase;
  color:var(--brw-gold);margin-bottom:20px;
}
.brw-hero-eyebrow::before{
  content:'';display:block;width:36px;height:2px;
  background:var(--brw-copper);
}
.brw-hero-h1{
  font-family:var(--brw-ff-head);
  font-size:clamp(64px,9vw,110px);
  line-height:.95;letter-spacing:.03em;
  color:var(--brw-foam);margin-bottom:28px;
}
.brw-hero-h1 span{color:var(--brw-copper);}
.brw-hero-sub{
  font-size:18px;font-weight:300;line-height:1.65;
  color:rgba(245,237,224,.8);
  max-width:500px;margin-bottom:40px;
}
.brw-hero-actions{display:flex;gap:16px;flex-wrap:wrap;}
.brw-btn-primary{
  display:inline-flex;align-items:center;gap:10px;
  padding:16px 36px;border-radius:4px;
  background:var(--brw-copper);color:var(--brw-foam);
  font-family:var(--brw-ff-head);font-size:18px;letter-spacing:.08em;
  text-decoration:none;transition:background .2s,transform .15s;
}
.brw-btn-primary:hover{background:var(--brw-copper-lt);transform:translateY(-2px);}
.brw-btn-outline{
  display:inline-flex;align-items:center;gap:10px;
  padding:15px 32px;border-radius:4px;
  border:2px solid rgba(245,237,224,.4);color:var(--brw-cream);
  font-family:var(--brw-ff-head);font-size:18px;letter-spacing:.08em;
  text-decoration:none;transition:border-color .2s,color .2s;
}
.brw-btn-outline:hover{border-color:var(--brw-gold);color:var(--brw-gold);}

/* Hero bottom scroll */
.brw-scroll-hint{
  position:absolute;bottom:32px;left:50%;transform:translateX(-50%);
  display:flex;flex-direction:column;align-items:center;gap:8px;
  color:rgba(245,237,224,.4);font-size:10px;letter-spacing:.12em;text-transform:uppercase;
  animation:brw-bounce .5s ease-in-out infinite alternate;
  z-index:10;
}
@keyframes brw-bounce{from{transform:translateX(-50%) translateY(0)}to{transform:translateX(-50%) translateY(6px)}}
.brw-scroll-arrow{
  width:22px;height:22px;
  border-right:2px solid rgba(245,237,224,.35);
  border-bottom:2px solid rgba(245,237,224,.35);
  transform:rotate(45deg);
}

/* ── SECTION BASE ─────────────────────────────── */
.brw-section{
  padding:100px 48px;max-width:1320px;
  margin:0 auto;
}
.brw-section-full{padding:100px 0;}

.brw-label{
  display:inline-flex;align-items:center;gap:10px;
  font-size:11px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;
  color:var(--brw-copper);margin-bottom:14px;
}
.brw-label::before{
  content:'';display:block;width:28px;height:2px;
  background:var(--brw-copper);
}
.brw-h2{
  font-family:var(--brw-ff-head);
  font-size:clamp(44px,6vw,72px);
  line-height:1;letter-spacing:.04em;
  color:var(--brw-foam);margin-bottom:20px;
}
.brw-h2 span{color:var(--brw-copper);}
.brw-lead{
  font-size:17px;font-weight:300;color:rgba(245,237,224,.7);
  max-width:640px;line-height:1.7;margin-bottom:64px;
}

/* ── STATS BAR ────────────────────────────────── */
.brw-stats{
  background:linear-gradient(90deg,var(--brw-copper-dk),var(--brw-copper),var(--brw-amber),var(--brw-copper),var(--brw-copper-dk));
  padding:48px;
}
.brw-stats-inner{
  max-width:1200px;margin:0 auto;
  display:grid;grid-template-columns:repeat(4,1fr);gap:0;
}
.brw-stat{
  text-align:center;
  border-right:1px solid rgba(13,17,23,.25);
  padding:0 24px;
}
.brw-stat:last-child{border-right:none;}
.brw-stat-val{
  font-family:var(--brw-ff-head);
  font-size:clamp(52px,7vw,80px);
  line-height:1;color:var(--brw-midnight);
  letter-spacing:.02em;
}
.brw-stat-suf{font-size:.55em;vertical-align:.1em;}
.brw-stat-lbl{
  font-size:12px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;
  color:rgba(13,17,23,.7);margin-top:6px;
}

/* ── BEERS ON TAP ─────────────────────────────── */
.brw-beers-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:2px;
  background:rgba(255,255,255,.04);
}
.brw-beer-card{
  background:var(--brw-charcoal);
  padding:40px 32px;
  position:relative;overflow:hidden;
  transition:background .25s;
  cursor:default;
}
.brw-beer-card:hover{background:var(--brw-slate);}
.brw-beer-card::before{
  content:'';position:absolute;
  left:0;top:0;bottom:0;width:4px;
  background:var(--brw-beer-color, var(--brw-copper));
  transition:width .25s;
}
.brw-beer-card:hover::before{width:8px;}
.brw-beer-badge{
  display:inline-block;
  padding:3px 10px;border-radius:2px;
  font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;
  background:rgba(200,112,42,.2);color:var(--brw-gold);
  margin-bottom:16px;
}
.brw-beer-name{
  font-family:var(--brw-ff-head);
  font-size:26px;letter-spacing:.04em;
  color:var(--brw-foam);margin-bottom:4px;
}
.brw-beer-style{
  font-size:12px;font-weight:500;letter-spacing:.08em;text-transform:uppercase;
  color:var(--brw-copper);margin-bottom:16px;
}
.brw-beer-desc{
  font-size:14px;color:rgba(245,237,224,.65);
  line-height:1.6;margin-bottom:20px;
}
.brw-beer-stats{
  display:flex;gap:20px;
}
.brw-beer-stat-item{
  display:flex;flex-direction:column;align-items:center;
  background:rgba(255,255,255,.05);
  padding:8px 16px;border-radius:3px;
}
.brw-beer-stat-val{
  font-family:var(--brw-ff-head);
  font-size:22px;color:var(--brw-gold);
  letter-spacing:.04em;
}
.brw-beer-stat-key{
  font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;
  color:rgba(245,237,224,.4);
}

/* ABV gauge */
.brw-abv-gauge{
  margin-top:16px;
  height:4px;border-radius:2px;
  background:rgba(255,255,255,.1);
  overflow:hidden;
}
.brw-abv-gauge-fill{
  height:100%;border-radius:2px;
  background:linear-gradient(90deg,var(--brw-copper),var(--brw-gold));
}

/* ── FOOD MENU ─────────────────────────────────── */
.brw-menu-bg{
  background:linear-gradient(180deg,var(--brw-charcoal) 0%,var(--brw-midnight) 100%);
  padding:100px 48px;
}
.brw-menu-inner{max-width:1200px;margin:0 auto;}
.brw-menu-grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:48px;
}
.brw-menu-cat-title{
  font-family:var(--brw-ff-head);
  font-size:28px;letter-spacing:.06em;color:var(--brw-copper);
  border-bottom:1px solid rgba(200,112,42,.3);
  padding-bottom:12px;margin-bottom:24px;
}
.brw-menu-item{
  padding:20px 0;
  border-bottom:1px solid rgba(255,255,255,.06);
  display:flex;flex-direction:column;gap:6px;
}
.brw-menu-item:last-child{border-bottom:none;}
.brw-menu-item-head{
  display:flex;justify-content:space-between;align-items:baseline;
}
.brw-menu-item-name{
  font-weight:700;font-size:15px;color:var(--brw-foam);
}
.brw-menu-item-price{
  font-family:var(--brw-ff-head);font-size:19px;
  color:var(--brw-gold);letter-spacing:.04em;
}
.brw-menu-item-desc{
  font-size:13px;color:rgba(245,237,224,.55);line-height:1.6;
}

/* ── BREWERY TOURS ─────────────────────────────── */
.brw-tours-grid{
  display:grid;grid-template-columns:repeat(4,1fr);gap:24px;
  margin-top:60px;
}
.brw-tour-card{
  background:var(--brw-charcoal);
  border:1px solid rgba(200,112,42,.2);
  border-radius:var(--brw-r);
  padding:36px 28px;
  text-align:center;
  transition:border-color .25s,transform .2s;
}
.brw-tour-card:hover{border-color:var(--brw-copper);transform:translateY(-4px);}
.brw-tour-time{
  font-family:var(--brw-ff-head);
  font-size:48px;letter-spacing:.04em;
  color:var(--brw-gold);
}
.brw-tour-days{
  font-size:12px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;
  color:rgba(245,237,224,.5);margin:6px 0 20px;
}
.brw-tour-divider{
  width:40px;height:2px;background:var(--brw-copper);
  margin:0 auto 20px;
}
.brw-tour-slots{
  font-size:14px;color:rgba(245,237,224,.7);margin-bottom:8px;
}
.brw-tour-price{
  font-family:var(--brw-ff-head);font-size:32px;
  color:var(--brw-copper);letter-spacing:.04em;
  margin-bottom:24px;
}
.brw-tour-btn{
  display:block;padding:12px 24px;border-radius:4px;
  background:rgba(200,112,42,.15);
  border:1px solid rgba(200,112,42,.4);
  color:var(--brw-cream);
  font-size:13px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;
  text-decoration:none;
  transition:background .2s,border-color .2s;
}
.brw-tour-btn:hover{background:var(--brw-copper);border-color:var(--brw-copper);}

/* ── BREWING PROCESS ──────────────────────────── */
.brw-process-bg{
  background:var(--brw-charcoal);
  padding:100px 48px;
}
.brw-process-inner{max-width:1200px;margin:0 auto;}
.brw-process-steps{
  display:grid;grid-template-columns:repeat(5,1fr);gap:0;
  margin-top:60px;
  position:relative;
}
.brw-process-steps::before{
  content:'';position:absolute;
  top:36px;left:10%;right:10%;height:2px;
  background:linear-gradient(90deg,var(--brw-copper),var(--brw-gold),var(--brw-copper));
}
.brw-process-step{
  display:flex;flex-direction:column;align-items:center;
  text-align:center;padding:0 12px;
  position:relative;
}
.brw-step-icon{
  width:72px;height:72px;border-radius:50%;
  background:var(--brw-midnight);
  border:3px solid var(--brw-copper);
  display:flex;align-items:center;justify-content:center;
  font-family:var(--brw-ff-head);
  font-size:28px;color:var(--brw-gold);
  margin-bottom:20px;
  position:relative;z-index:1;
}
.brw-step-name{
  font-family:var(--brw-ff-head);
  font-size:18px;letter-spacing:.06em;
  color:var(--brw-cream);margin-bottom:8px;
}
.brw-step-desc{
  font-size:12px;color:rgba(245,237,224,.55);
  line-height:1.6;
}

/* ── TEAM ─────────────────────────────────────── */
.brw-team-grid{
  display:grid;grid-template-columns:repeat(4,1fr);gap:28px;
  margin-top:60px;
}
.brw-team-card{
  background:var(--brw-charcoal);
  border-radius:var(--brw-r);
  overflow:hidden;
  transition:transform .2s;
}
.brw-team-card:hover{transform:translateY(-6px);}
.brw-team-portrait{
  height:200px;
  position:relative;
  background:linear-gradient(160deg,var(--brw-slate),var(--brw-midnight));
  display:flex;align-items:flex-end;justify-content:center;
  overflow:hidden;
}

/* CSS brewer figure */
.brw-brewer-fig{
  position:relative;
  width:80px;height:160px;
  margin-bottom:0;
}
/* apron/body */
.brw-brewer-body{
  position:absolute;bottom:0;left:50%;transform:translateX(-50%);
  width:56px;height:110px;
  border-radius:8px 8px 4px 4px;
  background:linear-gradient(160deg,#c8d0d8,#9aa0a8);
}
.brw-brewer-body::before{
  content:'';position:absolute;
  top:0;left:50%;transform:translateX(-50%);
  width:28px;height:100%;
  background:linear-gradient(160deg,#e8ede0,#c8d0b8);
  border-radius:4px;
}
.brw-brewer-body::after{
  content:'';position:absolute;
  top:28px;left:50%;transform:translateX(-50%);
  width:20px;height:2px;
  background:rgba(0,0,0,.15);
  box-shadow:0 10px 0 rgba(0,0,0,.15),0 20px 0 rgba(0,0,0,.15);
}
/* head */
.brw-brewer-head{
  position:absolute;
  bottom:108px;left:50%;transform:translateX(-50%);
  width:32px;height:32px;border-radius:50%;
  background:radial-gradient(circle at 40% 35%,#d4a870,#b08040);
}
/* hat */
.brw-brewer-hat{
  position:absolute;
  bottom:136px;left:50%;transform:translateX(-50%);
}
.brw-brewer-hat::before{
  content:'';display:block;
  width:42px;height:6px;
  background:#f0f0e8;
  border-radius:3px;
  position:absolute;left:50%;transform:translateX(-50%);
  top:0;
}
.brw-brewer-hat::after{
  content:'';display:block;
  width:28px;height:20px;
  background:linear-gradient(180deg,#f0f0e8,#e0e0d0);
  border-radius:3px 3px 0 0;
  position:absolute;left:50%;transform:translateX(-50%);
  top:-20px;
}
/* arms with mug */
.brw-brewer-mug{
  position:absolute;
  bottom:60px;left:calc(50% + 20px);
  width:18px;height:22px;
  border-radius:3px 3px 4px 4px;
  background:linear-gradient(160deg,#d4a040,#a07020);
  box-shadow:inset -2px -2px 4px rgba(0,0,0,.3);
}
.brw-brewer-mug::before{
  content:'';position:absolute;
  right:-8px;top:4px;
  width:8px;height:12px;
  border:2px solid #a07020;
  border-left:none;
  border-radius:0 4px 4px 0;
}
/* foam on mug */
.brw-brewer-mug::after{
  content:'';position:absolute;
  top:-6px;left:-2px;right:-2px;height:10px;
  background:radial-gradient(circle at 30% 40%,#fff,#e8e8e8);
  border-radius:50%;
}

.brw-team-info{padding:24px;}
.brw-team-name{
  font-family:var(--brw-ff-head);font-size:22px;
  letter-spacing:.04em;color:var(--brw-foam);
  margin-bottom:4px;
}
.brw-team-role{
  font-size:12px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;
  color:var(--brw-copper);margin-bottom:12px;
}
.brw-team-note{
  font-size:13px;color:rgba(245,237,224,.6);line-height:1.6;
}

/* ── AWARDS ───────────────────────────────────── */
.brw-awards-bg{
  background:var(--brw-charcoal);
  padding:100px 48px;
}
.brw-awards-inner{max-width:900px;margin:0 auto;}
.brw-awards-table{width:100%;border-collapse:collapse;}
.brw-awards-table th{
  font-family:var(--brw-ff-head);font-size:15px;letter-spacing:.1em;
  color:var(--brw-copper);text-align:left;
  padding:12px 20px;border-bottom:2px solid rgba(200,112,42,.4);
}
.brw-awards-table td{
  padding:18px 20px;
  border-bottom:1px solid rgba(255,255,255,.06);
  font-size:14px;color:rgba(245,237,224,.75);
}
.brw-awards-table tr:hover td{background:rgba(255,255,255,.03);}
.brw-medal{
  display:inline-block;
  padding:3px 10px;border-radius:2px;
  font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;
}
.brw-medal.gold{background:rgba(232,168,74,.2);color:#e8c84a;}
.brw-medal.silver{background:rgba(192,192,192,.2);color:#c0c8d0;}
.brw-medal.bronze{background:rgba(180,100,40,.2);color:#c87840;}

/* ── TESTIMONIALS ─────────────────────────────── */
.brw-testi-grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:28px;
  margin-top:60px;
}
.brw-testi-card{
  background:var(--brw-charcoal);
  border-radius:var(--brw-r);
  padding:40px 36px;
  position:relative;
}
.brw-testi-card::before{
  content:'❝';
  font-family:Georgia,serif;font-size:80px;
  color:var(--brw-copper);opacity:.2;
  position:absolute;top:16px;left:28px;
  line-height:1;
}
.brw-testi-stars{
  color:var(--brw-gold);font-size:16px;
  letter-spacing:3px;margin-bottom:16px;
}
.brw-testi-text{
  font-size:15px;font-style:italic;
  color:rgba(245,237,224,.8);line-height:1.7;
  margin-bottom:24px;
  position:relative;z-index:1;
}
.brw-testi-name{
  font-weight:700;font-size:14px;color:var(--brw-cream);
}
.brw-testi-tag{
  font-size:12px;color:var(--brw-copper);
}

/* ── FAQ ──────────────────────────────────────── */
.brw-faq-list{max-width:860px;margin:60px auto 0;}
.brw-faq-item{
  border-bottom:1px solid rgba(255,255,255,.08);
}
.brw-faq-q{
  width:100%;background:none;border:none;cursor:pointer;
  display:flex;justify-content:space-between;align-items:center;
  padding:24px 0;gap:24px;
  font-family:var(--brw-ff-body);
  font-size:16px;font-weight:600;
  color:var(--brw-cream);text-align:left;
}
.brw-faq-q:hover{color:var(--brw-gold);}
.brw-faq-icon{
  flex-shrink:0;
  width:28px;height:28px;border-radius:50%;
  background:rgba(200,112,42,.15);
  border:1px solid rgba(200,112,42,.4);
  display:flex;align-items:center;justify-content:center;
  font-size:18px;color:var(--brw-copper);
  transition:transform .25s,background .2s;
}
.brw-faq-item.open .brw-faq-icon{transform:rotate(45deg);background:var(--brw-copper);color:var(--brw-foam);}
.brw-faq-a{
  max-height:0;overflow:hidden;
  transition:max-height .35s ease;
}
.brw-faq-a-inner{
  padding:0 0 24px;
  font-size:15px;color:rgba(245,237,224,.7);line-height:1.7;
}

/* ── BOOKING FORM ─────────────────────────────── */
.brw-booking-bg{
  background:linear-gradient(135deg,var(--brw-charcoal) 0%,var(--brw-midnight) 100%);
  padding:100px 48px;
}
.brw-booking-inner{
  max-width:700px;margin:0 auto;
  background:var(--brw-slate);
  border:1px solid rgba(200,112,42,.25);
  border-radius:var(--brw-r);
  padding:60px;
}
.brw-form-grid{
  display:grid;grid-template-columns:1fr 1fr;gap:24px;
  margin-top:36px;
}
.brw-form-group{display:flex;flex-direction:column;gap:8px;}
.brw-form-group.full{grid-column:1/-1;}
.brw-form-label{
  font-size:12px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;
  color:rgba(245,237,224,.6);
}
.brw-form-input,
.brw-form-select,
.brw-form-textarea{
  background:rgba(255,255,255,.06);
  border:1px solid rgba(255,255,255,.12);
  border-radius:6px;
  padding:14px 16px;
  color:var(--brw-cream);
  font-family:var(--brw-ff-body);font-size:15px;
  transition:border-color .2s;
}
.brw-form-input:focus,
.brw-form-select:focus,
.brw-form-textarea:focus{
  outline:none;
  border-color:var(--brw-copper);
}
.brw-form-select{appearance:none;cursor:pointer;}
.brw-form-textarea{resize:vertical;min-height:100px;}
.brw-form-submit{
  margin-top:24px;
  width:100%;padding:18px;
  background:var(--brw-copper);color:var(--brw-foam);
  font-family:var(--brw-ff-head);font-size:20px;letter-spacing:.08em;
  border:none;border-radius:6px;cursor:pointer;
  transition:background .2s;
}
.brw-form-submit:hover{background:var(--brw-copper-lt);}

/* ── FOOTER ───────────────────────────────────── */
.brw-footer{
  background:var(--brw-midnight);
  border-top:1px solid rgba(200,112,42,.2);
  padding:64px 48px 32px;
}
.brw-footer-inner{
  max-width:1200px;margin:0 auto;
  display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:48px;
  padding-bottom:48px;
  border-bottom:1px solid rgba(255,255,255,.07);
}
.brw-footer-logo{
  font-family:var(--brw-ff-head);font-size:30px;letter-spacing:.08em;
  color:var(--brw-cream);margin-bottom:14px;
}
.brw-footer-logo span{color:var(--brw-copper);}
.brw-footer-desc{
  font-size:14px;color:rgba(245,237,224,.5);
  line-height:1.7;max-width:280px;
}
.brw-footer-col-title{
  font-family:var(--brw-ff-head);font-size:16px;letter-spacing:.1em;
  color:var(--brw-copper);margin-bottom:16px;
}
.brw-footer-list{list-style:none;display:flex;flex-direction:column;gap:10px;}
.brw-footer-list a{
  color:rgba(245,237,224,.55);text-decoration:none;font-size:14px;
  transition:color .2s;
}
.brw-footer-list a:hover{color:var(--brw-gold);}
.brw-footer-bottom{
  max-width:1200px;margin:28px auto 0;
  display:flex;justify-content:space-between;align-items:center;
  font-size:12px;color:rgba(245,237,224,.3);
}
.brw-footer-bottom a{color:rgba(245,237,224,.4);text-decoration:none;}
.brw-footer-bottom a:hover{color:var(--brw-copper);}

/* Responsive */
@media(max-width:1024px){
  .brw-beers-grid{grid-template-columns:repeat(2,1fr);}
  .brw-menu-grid{grid-template-columns:1fr;}
  .brw-tours-grid{grid-template-columns:repeat(2,1fr);}
  .brw-process-steps{grid-template-columns:repeat(3,1fr);}
  .brw-process-steps::before{display:none;}
  .brw-team-grid{grid-template-columns:repeat(2,1fr);}
  .brw-testi-grid{grid-template-columns:1fr;}
  .brw-footer-inner{grid-template-columns:1fr 1fr;}
}
@media(max-width:768px){
  .brw-nav-links,.brw-nav-cta{display:none;}
  .brw-hero-content{padding:120px 24px 60px;}
  .brw-section,.brw-menu-bg,.brw-process-bg,.brw-awards-bg,.brw-booking-bg,.brw-footer{padding-left:24px;padding-right:24px;}
  .brw-stats-inner{grid-template-columns:repeat(2,1fr);}
  .brw-beers-grid{grid-template-columns:1fr;}
  .brw-tours-grid{grid-template-columns:1fr;}
  .brw-process-steps{grid-template-columns:1fr;}
  .brw-team-grid{grid-template-columns:1fr;}
  .brw-form-grid{grid-template-columns:1fr;}
  .brw-booking-inner{padding:36px 24px;}
  .brw-chalkboard{display:none;}
}
</style>
<?php get_header(); ?>
<div class="brw-page">
>

<!-- NAV -->
<nav class="brw-nav" role="navigation" aria-label="Main navigation">
  <a href="<?php echo esc_url(home_url('/')); ?>" class="brw-nav-logo">
    ANVIL<span>&amp;</span>GRAIN
  </a>
  <ul class="brw-nav-links">
    <li><a href="#beers">Our Beers</a></li>
    <li><a href="#food">Food</a></li>
    <li><a href="#tours">Tours</a></li>
    <li><a href="#team">Team</a></li>
    <li><a href="#faq">FAQ</a></li>
  </ul>
  <a href="#booking" class="brw-nav-cta">Book a Tour</a>
</nav>

<!-- HERO -->
<header class="brw-hero" role="banner">

  <!-- Amber backlight -->
  <div class="brw-hero-glow" aria-hidden="true"></div>

  <!-- Floating sparks -->
  <?php foreach($sparks as $sp): ?>
  <div class="brw-spark" aria-hidden="true" style="
    left:<?php echo $sp['left']; ?>%;
    top:<?php echo $sp['top']; ?>%;
    width:<?php echo $sp['size']; ?>px;
    height:<?php echo $sp['size']; ?>px;
    animation-duration:<?php echo $sp['dur']; ?>ms;
    animation-delay:-<?php echo $sp['delay']; ?>ms;
  "></div>
  <?php endforeach; ?>

  <!-- Back wall -->
  <div class="brw-wall" aria-hidden="true"></div>

  <!-- Chalkboard specials sign -->
  <div class="brw-chalkboard" aria-hidden="true">
    <?php
    $specials = array_slice($beers, 0, 3);
    foreach($specials as $sp_beer):
    ?>
    <div class="brw-chalkboard-item">
      <?php echo esc_html($sp_beer['name']); ?>
      <span class="brw-chalkboard-abv"><?php echo esc_html($sp_beer['abv']); ?>%</span>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Floor -->
  <div class="brw-floor" aria-hidden="true"></div>

  <!-- Hop vine – left -->
  <div class="brw-hops-col left" aria-hidden="true">
    <?php foreach($left_hops as $lh): ?>
    <div class="brw-hop-leaf" style="
      top:<?php echo $lh['top']; ?>%;
      left:<?php echo rand(20,60); ?>%;
      width:<?php echo $lh['size']; ?>px;
      height:<?php echo intval($lh['size']*.75); ?>px;
      transform:rotate(<?php echo $lh['r']; ?>deg);
      animation-delay:<?php echo $lh['delay']; ?>ms;
    "></div>
    <?php endforeach; ?>
    <?php foreach(array_slice($hop_cones,0,7) as $hc): ?>
    <div class="brw-hop-cone" style="
      top:<?php echo $hc['top']; ?>%;
      left:<?php echo rand(15,65); ?>%;
      animation-delay:<?php echo $hc['delay']; ?>ms;
    "></div>
    <?php endforeach; ?>
  </div>

  <!-- Hop vine – right -->
  <div class="brw-hops-col right" aria-hidden="true">
    <?php foreach($right_hops as $rh): ?>
    <div class="brw-hop-leaf" style="
      top:<?php echo $rh['top']; ?>%;
      left:<?php echo rand(20,60); ?>%;
      width:<?php echo $rh['size']; ?>px;
      height:<?php echo intval($rh['size']*.75); ?>px;
      transform:rotate(<?php echo $rh['r']; ?>deg);
      animation-delay:<?php echo $rh['delay']; ?>ms;
    "></div>
    <?php endforeach; ?>
    <?php foreach(array_slice($hop_cones,7) as $hc): ?>
    <div class="brw-hop-cone" style="
      top:<?php echo $hc['top']; ?>%;
      left:<?php echo rand(15,65); ?>%;
      animation-delay:<?php echo $hc['delay']; ?>ms;
    "></div>
    <?php endforeach; ?>
  </div>

  <!-- Horizontal pipe network -->
  <div class="brw-pipes" aria-hidden="true">
    <div class="brw-pipe-h" style="left:22%;right:22%;top:20px;height:10px;"></div>
    <div class="brw-pipe-v" style="left:35%;top:0;height:40px;"></div>
    <div class="brw-pipe-v" style="left:50%;top:0;height:40px;"></div>
    <div class="brw-pipe-v" style="left:65%;top:0;height:40px;"></div>
    <div class="brw-pipe-joint" style="left:35%;top:20px;"></div>
    <div class="brw-pipe-joint" style="left:50%;top:20px;"></div>
    <div class="brw-pipe-joint" style="left:65%;top:20px;"></div>
    <div class="brw-pipe-h" style="left:28%;right:28%;bottom:20px;height:10px;"></div>
  </div>

  <!-- Kettles -->
  <div class="brw-kettles" aria-hidden="true">
    <div class="brw-kettle small">
      <div class="brw-kettle-top"></div>
      <div class="brw-kettle-body">
        <span class="brw-kettle-label">MASH<br>TUN</span>
        <?php foreach(array_slice($bubbles,0,6) as $b): ?>
        <div class="brw-bubble" style="
          left:<?php echo $b['left']; ?>%;
          width:<?php echo $b['size']; ?>px;height:<?php echo $b['size']; ?>px;
          animation-duration:<?php echo $b['dur']; ?>ms;
          animation-delay:-<?php echo $b['delay']; ?>ms;
        "></div>
        <?php endforeach; ?>
      </div>
      <div class="brw-kettle-neck"></div>
      <div class="brw-kettle-legs"></div>
    </div>

    <div class="brw-kettle large">
      <div class="brw-kettle-top"></div>
      <div class="brw-kettle-body">
        <span class="brw-kettle-label">COPPER<br>KETTLE</span>
        <?php foreach(array_slice($bubbles,6,8) as $b): ?>
        <div class="brw-bubble" style="
          left:<?php echo $b['left']; ?>%;
          width:<?php echo $b['size']; ?>px;height:<?php echo $b['size']; ?>px;
          animation-duration:<?php echo $b['dur']; ?>ms;
          animation-delay:-<?php echo $b['delay']; ?>ms;
        "></div>
        <?php endforeach; ?>
      </div>
      <div class="brw-kettle-neck"></div>
      <div class="brw-kettle-legs"></div>
    </div>

    <div class="brw-kettle">
      <div class="brw-kettle-top"></div>
      <div class="brw-kettle-body">
        <span class="brw-kettle-label">WHIRL<br>POOL</span>
        <?php foreach(array_slice($bubbles,14,6) as $b): ?>
        <div class="brw-bubble" style="
          left:<?php echo $b['left']; ?>%;
          width:<?php echo $b['size']; ?>px;height:<?php echo $b['size']; ?>px;
          animation-duration:<?php echo $b['dur']; ?>ms;
          animation-delay:-<?php echo $b['delay']; ?>ms;
        "></div>
        <?php endforeach; ?>
      </div>
      <div class="brw-kettle-neck"></div>
      <div class="brw-kettle-legs"></div>
    </div>
  </div>

  <!-- Steam -->
  <?php foreach($steam_puffs as $st): ?>
  <div class="brw-steam" aria-hidden="true" style="
    left:<?php echo $st['left']; ?>%;
    bottom:<?php echo rand(340,380); ?>px;
    width:<?php echo $st['size']; ?>px;
    height:<?php echo $st['size']; ?>px;
    animation-duration:<?php echo $st['dur']; ?>ms;
    animation-delay:-<?php echo $st['delay']; ?>ms;
  "></div>
  <?php endforeach; ?>

  <!-- Grain sacks -->
  <div class="brw-sack" aria-hidden="true" style="left:8%;"></div>
  <div class="brw-sack" aria-hidden="true" style="left:11%;top:-20px;"></div>
  <div class="brw-sack" aria-hidden="true" style="right:8%;"></div>

  <!-- Beer taps -->
  <div class="brw-tap-bar" aria-hidden="true"></div>
  <div class="brw-taps" aria-hidden="true">
    <?php
    $tap_colors = ['#1a0a00','#c8702a','#e8c060','#b87820','#2a1400'];
    foreach($tap_colors as $tc): ?>
    <div class="brw-tap">
      <div class="brw-tap-handle" style="background:linear-gradient(160deg,<?php echo esc_attr($tc); ?>,<?php echo esc_attr($tc); ?>88);"></div>
      <div class="brw-tap-nozzle"></div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Overlay -->
  <div class="brw-hero-overlay" aria-hidden="true"></div>

  <!-- Content -->
  <div class="brw-hero-content">
    <div class="brw-hero-eyebrow">Craft Brewery &amp; Taproom · Est. 2009</div>
    <h1 class="brw-hero-h1">
      BREWED<br>WITH<br><span>PASSION</span>
    </h1>
    <p class="brw-hero-sub">
      Small-batch craft beers made from the finest malts, whole-cone hops
      and pure artesian water. Sixteen rotating taps, a full kitchen, and
      a welcome as warm as the mash tun.
    </p>
    <div class="brw-hero-actions">
      <a href="#beers" class="brw-btn-primary">See Our Beers</a>
      <a href="#tours" class="brw-btn-outline">Book a Tour</a>
    </div>
  </div>

  <div class="brw-scroll-hint" aria-hidden="true">
    <span>SCROLL</span>
    <div class="brw-scroll-arrow"></div>
  </div>
</header>

<!-- STATS -->
<section class="brw-stats" aria-label="Brewery statistics">
  <div class="brw-stats-inner">
    <div class="brw-stat">
      <div class="brw-stat-val" data-target="16" data-suffix="+">0<span class="brw-stat-suf">+</span></div>
      <div class="brw-stat-lbl">Taps On Rotation</div>
    </div>
    <div class="brw-stat">
      <div class="brw-stat-val" data-target="85">0<span class="brw-stat-suf"></span></div>
      <div class="brw-stat-lbl">Unique Recipes Brewed</div>
    </div>
    <div class="brw-stat">
      <div class="brw-stat-val" data-target="22" data-suffix="+">0<span class="brw-stat-suf">+</span></div>
      <div class="brw-stat-lbl">Awards &amp; Medals</div>
    </div>
    <div class="brw-stat">
      <div class="brw-stat-val" data-target="15">0<span class="brw-stat-suf"></span></div>
      <div class="brw-stat-lbl">Years Brewing</div>
    </div>
  </div>
</section>

<!-- BEERS ON TAP -->
<section id="beers" class="brw-section" aria-labelledby="brw-beers-heading">
  <div class="brw-label">On Tap</div>
  <h2 class="brw-h2" id="brw-beers-heading">OUR <span>BEERS</span></h2>
  <p class="brw-lead">
    From session ales to imperial stouts — every pint hand-crafted
    on site with locally sourced ingredients and obsessive attention to detail.
  </p>

  <div class="brw-beers-grid">
    <?php foreach($beers as $beer):
      $abv_float = (float)$beer['abv'];
      $abv_pct   = min(100, ($abv_float / 12) * 100);
    ?>
    <article class="brw-beer-card" style="--brw-beer-color:<?php echo esc_attr($beer['color']); ?>;">
      <div class="brw-beer-badge"><?php echo esc_html($beer['badge']); ?></div>
      <div class="brw-beer-name"><?php echo esc_html($beer['name']); ?></div>
      <div class="brw-beer-style"><?php echo esc_html($beer['style']); ?></div>
      <p class="brw-beer-desc"><?php echo esc_html($beer['desc']); ?></p>
      <div class="brw-beer-stats">
        <div class="brw-beer-stat-item">
          <div class="brw-beer-stat-val"><?php echo esc_html($beer['abv']); ?>%</div>
          <div class="brw-beer-stat-key">ABV</div>
        </div>
        <div class="brw-beer-stat-item">
          <div class="brw-beer-stat-val"><?php echo esc_html($beer['ibu']); ?></div>
          <div class="brw-beer-stat-key">IBU</div>
        </div>
      </div>
      <div class="brw-abv-gauge">
        <div class="brw-abv-gauge-fill" style="width:<?php echo round($abv_pct); ?>%;"></div>
      </div>
    </article>
    <?php endforeach; ?>
  </div>
</section>

<!-- FOOD MENU -->
<div id="food" class="brw-menu-bg" role="region" aria-labelledby="brw-food-heading">
  <div class="brw-menu-inner">
    <div class="brw-label">Kitchen</div>
    <h2 class="brw-h2" id="brw-food-heading">TAPROOM <span>KITCHEN</span></h2>
    <p class="brw-lead">
      Great beer deserves great food. Our kitchen serves honest,
      hearty fare designed to pair with everything on tap.
    </p>
    <div class="brw-menu-grid">
      <?php foreach($food as $cat): ?>
      <div class="brw-menu-cat">
        <div class="brw-menu-cat-title"><?php echo esc_html($cat['cat']); ?></div>
        <?php foreach($cat['items'] as $item): ?>
        <div class="brw-menu-item">
          <div class="brw-menu-item-head">
            <span class="brw-menu-item-name"><?php echo esc_html($item['n']); ?></span>
            <span class="brw-menu-item-price"><?php echo esc_html($item['p']); ?></span>
          </div>
          <p class="brw-menu-item-desc"><?php echo esc_html($item['d']); ?></p>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- TOURS -->
<section id="tours" class="brw-section" aria-labelledby="brw-tours-heading">
  <div class="brw-label">Behind the Scenes</div>
  <h2 class="brw-h2" id="brw-tours-heading">BREWERY <span>TOURS</span></h2>
  <p class="brw-lead">
    Follow your guide through the full brewing process — from grain delivery
    to conditioning tank — and finish with a three-beer tutored tasting.
  </p>
  <div class="brw-tours-grid">
    <?php foreach($tours as $tour): ?>
    <div class="brw-tour-card">
      <div class="brw-tour-time"><?php echo esc_html($tour['time']); ?></div>
      <div class="brw-tour-days"><?php echo esc_html($tour['days']); ?></div>
      <div class="brw-tour-divider"></div>
      <div class="brw-tour-slots"><?php echo esc_html($tour['slots']); ?> guests max</div>
      <div class="brw-tour-price"><?php echo esc_html($tour['price']); ?></div>
      <a href="#booking" class="brw-tour-btn">Book This Slot</a>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- BREWING PROCESS -->
<div class="brw-process-bg" role="region" aria-labelledby="brw-process-heading">
  <div class="brw-process-inner">
    <div class="brw-label">How It's Made</div>
    <h2 class="brw-h2" id="brw-process-heading">THE BREWING <span>PROCESS</span></h2>
    <p class="brw-lead">From raw grain to cold pint — five transformative stages, all under one roof.</p>
    <div class="brw-process-steps">
      <?php
      $steps = [
        ['n'=>'01','title'=>'Milling','desc'=>'Whole malted barley is cracked to expose the starchy interior while preserving the husk.'],
        ['n'=>'02','title'=>'Mashing','desc'=>'Milled grain steeped in hot liquor converts starches into fermentable sugars — the wort is born.'],
        ['n'=>'03','title'=>'Boiling','desc'=>'Wort is boiled with whole-cone hops for bitterness, aroma and natural sterilisation.'],
        ['n'=>'04','title'=>'Fermenting','desc'=>'Yeast is pitched into cooled wort. Over 7–14 days sugars become alcohol and CO₂.'],
        ['n'=>'05','title'=>'Conditioning','desc'=>'Beer rests in cold tanks, clarifying and carbonating to perfection before packaging.'],
      ];
      foreach($steps as $step): ?>
      <div class="brw-process-step">
        <div class="brw-step-icon"><?php echo esc_html($step['n']); ?></div>
        <div class="brw-step-name"><?php echo esc_html($step['title']); ?></div>
        <p class="brw-step-desc"><?php echo esc_html($step['desc']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- TEAM -->
<section id="team" class="brw-section" aria-labelledby="brw-team-heading">
  <div class="brw-label">The People</div>
  <h2 class="brw-h2" id="brw-team-heading">MEET THE <span>TEAM</span></h2>
  <p class="brw-lead">The talent behind every pint.</p>
  <div class="brw-team-grid">
    <?php foreach($team as $member): ?>
    <div class="brw-team-card">
      <div class="brw-team-portrait" aria-hidden="true">
        <!-- CSS brewer figure -->
        <div class="brw-brewer-fig">
          <div class="brw-brewer-body"></div>
          <div class="brw-brewer-head"></div>
          <div class="brw-brewer-hat"></div>
          <div class="brw-brewer-mug"></div>
        </div>
      </div>
      <div class="brw-team-info">
        <div class="brw-team-name"><?php echo esc_html($member['name']); ?></div>
        <div class="brw-team-role"><?php echo esc_html($member['role']); ?></div>
        <p class="brw-team-note"><?php echo esc_html($member['note']); ?></p>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- AWARDS -->
<div class="brw-awards-bg" role="region" aria-labelledby="brw-awards-heading">
  <div class="brw-awards-inner">
    <div class="brw-label" style="justify-content:center;">Recognition</div>
    <h2 class="brw-h2" style="text-align:center;" id="brw-awards-heading">AWARD <span>HISTORY</span></h2>
    <p class="brw-lead" style="margin:0 auto 48px;text-align:center;">
      Our beers have been judged among the finest in the UK by the country's
      most respected brewing competitions.
    </p>
    <table class="brw-awards-table" role="table">
      <thead>
        <tr>
          <th scope="col">Year</th>
          <th scope="col">Competition</th>
          <th scope="col">Beer</th>
          <th scope="col">Medal</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($awards as $aw): ?>
        <tr>
          <td><?php echo esc_html($aw['yr']); ?></td>
          <td><?php echo esc_html($aw['comp']); ?></td>
          <td><?php echo esc_html($aw['beer']); ?></td>
          <td>
            <span class="brw-medal <?php echo esc_attr(strtolower($aw['medal'])); ?>">
              <?php echo esc_html($aw['medal']); ?>
            </span>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- TESTIMONIALS -->
<section class="brw-section" aria-labelledby="brw-testi-heading">
  <div class="brw-label">Regulars Say</div>
  <h2 class="brw-h2" id="brw-testi-heading">WHAT PEOPLE <span>SAY</span></h2>
  <div class="brw-testi-grid">
    <?php
    $testis = [
      ['text'=>'The Ridgeline IPA is the best West Coast IPA I\'ve had this side of Portland. Absolutely stunning hop character with that razor-clean finish. The taproom atmosphere is second to none.','name'=>'Jamie Torrance','tag'=>'Regular · Edinburgh'],
      ['text'=>'Came for a birthday tour and honestly it was one of the best evenings we\'ve had. The guide was knowledgeable and funny, the tasting was generous, and the food pairing suggestions were spot on.','name'=>'Priya Nath','tag'=>'Tour Guest · London'],
      ['text'=>'Iron Foundry Stout is genuinely world-class. Rich, complex, warming — it gave me chills in the best possible way. Can\'t believe this is brewed in our backyard. Huge congratulations.','name'=>'Owen Fitzgerald','tag'=>'CAMRA Member · Manchester'],
    ];
    foreach($testis as $t): ?>
    <article class="brw-testi-card">
      <div class="brw-testi-stars" aria-label="5 stars">★★★★★</div>
      <p class="brw-testi-text"><?php echo esc_html($t['text']); ?></p>
      <div class="brw-testi-name"><?php echo esc_html($t['name']); ?></div>
      <div class="brw-testi-tag"><?php echo esc_html($t['tag']); ?></div>
    </article>
    <?php endforeach; ?>
  </div>
</section>

<!-- FAQ -->
<section id="faq" class="brw-section" aria-labelledby="brw-faq-heading">
  <div class="brw-label" style="justify-content:center;">Questions</div>
  <h2 class="brw-h2" style="text-align:center;" id="brw-faq-heading">FREQUENTLY <span>ASKED</span></h2>
  <div class="brw-faq-list" role="list">
    <?php foreach($faqs as $fi => $faq): ?>
    <div class="brw-faq-item" role="listitem">
      <button
        class="brw-faq-q"
        aria-expanded="false"
        aria-controls="brw-faq-a-<?php echo $fi; ?>"
        id="brw-faq-q-<?php echo $fi; ?>"
      >
        <?php echo esc_html($faq['q']); ?>
        <span class="brw-faq-icon" aria-hidden="true">+</span>
      </button>
      <div
        class="brw-faq-a"
        id="brw-faq-a-<?php echo $fi; ?>"
        role="region"
        aria-labelledby="brw-faq-q-<?php echo $fi; ?>"
      >
        <div class="brw-faq-a-inner"><?php echo esc_html($faq['a']); ?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- BOOKING FORM -->
<div id="booking" class="brw-booking-bg" role="region" aria-labelledby="brw-booking-heading">
  <div class="brw-booking-inner">
    <div class="brw-label">Reservations</div>
    <h2 class="brw-h2" id="brw-booking-heading">BOOK YOUR <span>TOUR</span></h2>
    <p style="font-size:15px;color:rgba(245,237,224,.65);margin-top:12px;">
      Reserve your place on a brewery tour or enquire about private group hire.
      We'll confirm your booking within 24 hours.
    </p>
    <form class="brw-form-grid" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" novalidate>
      <?php wp_nonce_field('tf_brw_booking','tf_brw_nonce'); ?>
      <input type="hidden" name="action" value="tf_brw_booking">

      <div class="brw-form-group">
        <label class="brw-form-label" for="brw-fname">First Name</label>
        <input class="brw-form-input" type="text" id="brw-fname" name="first_name" placeholder="Alex" required>
      </div>
      <div class="brw-form-group">
        <label class="brw-form-label" for="brw-lname">Last Name</label>
        <input class="brw-form-input" type="text" id="brw-lname" name="last_name" placeholder="MacPherson" required>
      </div>
      <div class="brw-form-group">
        <label class="brw-form-label" for="brw-email">Email Address</label>
        <input class="brw-form-input" type="email" id="brw-email" name="email" placeholder="alex@example.com" required>
      </div>
      <div class="brw-form-group">
        <label class="brw-form-label" for="brw-phone">Phone Number</label>
        <input class="brw-form-input" type="tel" id="brw-phone" name="phone" placeholder="+44 7700 900000">
      </div>
      <div class="brw-form-group">
        <label class="brw-form-label" for="brw-guests">Number of Guests</label>
        <select class="brw-form-select" id="brw-guests" name="guests">
          <option value="">Select group size</option>
          <?php for($g=1;$g<=12;$g++): ?>
          <option value="<?php echo $g; ?>"><?php echo $g; ?> <?php echo $g===1?'guest':'guests'; ?></option>
          <?php endfor; ?>
          <option value="private">Private hire (13+)</option>
        </select>
      </div>
      <div class="brw-form-group">
        <label class="brw-form-label" for="brw-tour-slot">Preferred Tour Slot</label>
        <select class="brw-form-select" id="brw-tour-slot" name="tour_slot">
          <option value="">Select a slot</option>
          <?php foreach($tours as $ts): ?>
          <option value="<?php echo esc_attr($ts['time']); ?>">
            <?php echo esc_html($ts['time'].' – '.$ts['days'].' ('.$ts['price'].')'); ?>
          </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="brw-form-group">
        <label class="brw-form-label" for="brw-date">Preferred Date</label>
        <input class="brw-form-input" type="date" id="brw-date" name="preferred_date">
      </div>
      <div class="brw-form-group">
        <label class="brw-form-label" for="brw-dietary">Dietary Requirements</label>
        <input class="brw-form-input" type="text" id="brw-dietary" name="dietary" placeholder="e.g. gluten-free, vegan">
      </div>
      <div class="brw-form-group full">
        <label class="brw-form-label" for="brw-notes">Additional Notes</label>
        <textarea class="brw-form-textarea" id="brw-notes" name="notes" placeholder="Special occasions, accessibility needs, any questions…"></textarea>
      </div>
      <div class="brw-form-group full">
        <button type="submit" class="brw-form-submit">RESERVE MY PLACE</button>
      </div>
    </form>
  </div>
</div>

<!-- FOOTER -->
<footer class="brw-footer" role="contentinfo">
  <div class="brw-footer-inner">
    <div>
      <div class="brw-footer-logo">ANVIL<span>&</span>GRAIN</div>
      <p class="brw-footer-desc">
        Independently owned craft brewery and taproom. Brewing small-batch,
        big-flavour beers since 2009. Come in, pull up a stool, stay a while.
      </p>
    </div>
    <div>
      <div class="brw-footer-col-title">Visit Us</div>
      <ul class="brw-footer-list">
        <li><a href="#">Opening Hours</a></li>
        <li><a href="#">Find Us</a></li>
        <li><a href="#">Accessibility</a></li>
        <li><a href="#">Parking</a></li>
      </ul>
    </div>
    <div>
      <div class="brw-footer-col-title">Explore</div>
      <ul class="brw-footer-list">
        <li><a href="#beers">Our Beers</a></li>
        <li><a href="#food">Kitchen Menu</a></li>
        <li><a href="#tours">Tours</a></li>
        <li><a href="#">Online Shop</a></li>
      </ul>
    </div>
    <div>
      <div class="brw-footer-col-title">Connect</div>
      <ul class="brw-footer-list">
        <li><a href="#">Instagram</a></li>
        <li><a href="#">Untappd</a></li>
        <li><a href="#">Facebook</a></li>
        <li><a href="#">Newsletter</a></li>
      </ul>
    </div>
  </div>
  <div class="brw-footer-bottom">
    <span>&copy; <?php echo date('Y'); ?> Anvil &amp; Grain Brewery. All rights reserved.</span>
    <span>
      <a href="#">Privacy Policy</a> &nbsp;·&nbsp;
      <a href="#">Terms</a> &nbsp;·&nbsp;
      <a href="#">Allergen Info</a>
    </span>
  </div>
</footer>

<script>
(function(){
  'use strict';

  /* ── Animated counters ───────────────────────── */
  var counters = document.querySelectorAll('[data-target]');
  var easeOut  = function(t){ return 1 - Math.pow(1-t,3); };

  var animateCounter = function(el){
    var target = parseFloat(el.dataset.target);
    var suffix = el.dataset.suffix || '';
    if(isNaN(target) || target === 0) return;
    var sufEl = el.querySelector('.brw-stat-suf');
    var start = null;
    var dur   = 1800;
    var tick  = function(ts){
      if(!start) start = ts;
      var prog = Math.min((ts - start)/dur, 1);
      var val  = Math.round(easeOut(prog) * target);
      el.childNodes[0].nodeValue = val;
      if(sufEl) sufEl.textContent = suffix;
      if(prog < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  };

  if('IntersectionObserver' in window){
    var obs = new IntersectionObserver(function(entries){
      entries.forEach(function(e){
        if(e.isIntersecting){ animateCounter(e.target); obs.unobserve(e.target); }
      });
    },{threshold:.4});
    counters.forEach(function(c){ obs.observe(c); });
  } else {
    counters.forEach(animateCounter);
  }

  /* ── FAQ accordion ───────────────────────────── */
  var faqItems = document.querySelectorAll('.brw-faq-item');
  faqItems.forEach(function(item){
    var btn = item.querySelector('.brw-faq-q');
    var ans = item.querySelector('.brw-faq-a');
    btn.addEventListener('click', function(){
      var isOpen = item.classList.contains('open');
      faqItems.forEach(function(other){
        other.classList.remove('open');
        other.querySelector('.brw-faq-q').setAttribute('aria-expanded','false');
        other.querySelector('.brw-faq-a').style.maxHeight = '0';
      });
      if(!isOpen){
        item.classList.add('open');
        btn.setAttribute('aria-expanded','true');
        ans.style.maxHeight = ans.scrollHeight + 'px';
      }
    });
  });

  /* ── Date input minimum ──────────────────────── */
  var dateEl = document.getElementById('brw-date');
  if(dateEl){
    dateEl.min = new Date().toISOString().split('T')[0];
  }

})();
</script>

</body>
</html>
</div><!-- .brw-page -->
<?php get_footer(); ?>
