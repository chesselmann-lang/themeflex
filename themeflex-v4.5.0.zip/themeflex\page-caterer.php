<?php
/**
 * Template Name: TF — Event Catering & Private Chef
 *
 * Saffron & Stone Catering — Belgravia, London
 * Luxury event catering, private dining & bespoke chef experiences
 *
 * @package ThemeFlex
 */

srand(crc32(get_the_permalink()));
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&family=Source+Sans+3:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
/* ============================================================
   SAFFRON & STONE — CSS CUSTOM PROPERTIES
   ============================================================ */
:root {
  --ct-charcoal:   #1C1814;   /* deep kitchen charcoal     */
  --ct-slate:      #2D2926;   /* warm slate                 */
  --ct-saffron:    #C8890A;   /* rich saffron gold          */
  --ct-saffron-lt: #E8A820;   /* light saffron              */
  --ct-cream:      #FAF6EF;   /* warm cream                 */
  --ct-ivory:      #F2EDE4;   /* antique ivory              */
  --ct-stone:      #8C7B6B;   /* warm stone                 */
  --ct-copper:     #B5622A;   /* burnished copper           */
  --ct-herb:       #3D5A3E;   /* fresh herb green           */
  --ct-white:      #FFFFFF;

  --ct-serif:  'Libre Baskerville', Georgia, serif;
  --ct-sans:   'Source Sans 3', system-ui, sans-serif;

  --ct-radius: 4px;
  --ct-shadow: 0 8px 40px rgba(28,24,20,.18);
}

/* ============================================================
   RESET & BASE
   ============================================================ */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; }
body.page-template-page-caterer {
  font-family: var(--ct-sans);
  background: var(--ct-cream);
  color: var(--ct-charcoal);
  line-height: 1.7;
  overflow-x: hidden;
}
.ct-container { max-width: 1200px; margin: 0 auto; padding: 0 32px; }
.ct-section { padding: 96px 0; }
.ct-tag {
  display: inline-block;
  font-family: var(--ct-sans);
  font-size: .72rem;
  font-weight: 600;
  letter-spacing: .2em;
  text-transform: uppercase;
  color: var(--ct-saffron);
  margin-bottom: 16px;
}
.ct-heading {
  font-family: var(--ct-serif);
  font-size: clamp(2rem, 4vw, 3.2rem);
  font-weight: 700;
  line-height: 1.2;
  color: var(--ct-charcoal);
}
.ct-heading em { font-style: italic; color: var(--ct-saffron); }
.ct-subheading {
  font-family: var(--ct-serif);
  font-size: clamp(1.3rem, 2.5vw, 1.9rem);
  font-weight: 400;
  font-style: italic;
  color: var(--ct-charcoal);
  line-height: 1.3;
}
.ct-lead {
  font-size: 1.08rem;
  color: var(--ct-stone);
  line-height: 1.8;
  max-width: 640px;
}
.ct-btn {
  display: inline-block;
  padding: 14px 36px;
  font-family: var(--ct-sans);
  font-size: .88rem;
  font-weight: 600;
  letter-spacing: .1em;
  text-transform: uppercase;
  text-decoration: none;
  border-radius: var(--ct-radius);
  transition: all .25s ease;
  cursor: pointer;
  border: none;
}
.ct-btn-primary {
  background: var(--ct-saffron);
  color: var(--ct-charcoal);
}
.ct-btn-primary:hover { background: var(--ct-saffron-lt); transform: translateY(-2px); box-shadow: 0 6px 24px rgba(200,137,10,.35); }
.ct-btn-outline {
  background: transparent;
  color: var(--ct-cream);
  border: 2px solid rgba(250,246,239,.5);
}
.ct-btn-outline:hover { background: rgba(250,246,239,.1); border-color: var(--ct-cream); }

/* ============================================================
   HERO — PROFESSIONAL KITCHEN AT DUSK
   ============================================================ */
.ct-hero {
  position: relative;
  min-height: 100vh;
  background: var(--ct-charcoal);
  display: flex;
  align-items: center;
  overflow: hidden;
}

/* Kitchen scene */
.ct-kitchen {
  position: absolute;
  inset: 0;
}

/* Kitchen ceiling — dark with recessed panels */
.ct-kitchen-ceiling {
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 18%;
  background: #130F0B;
  z-index: 1;
}
.ct-kitchen-ceiling::before {
  content: '';
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    90deg,
    transparent 0px, transparent 180px,
    rgba(255,255,255,.04) 180px, rgba(255,255,255,.04) 182px
  );
}
.ct-kitchen-ceiling::after {
  content: '';
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 6px;
  background: linear-gradient(90deg,
    rgba(255,255,255,.06) 0%,
    rgba(255,255,255,.03) 50%,
    rgba(255,255,255,.06) 100%);
}

/* Back kitchen wall — tile texture */
.ct-kitchen-wall {
  position: absolute;
  top: 18%; left: 0; right: 0;
  height: 48%;
  background: #1F1A15;
  z-index: 1;
}
.ct-kitchen-wall::before {
  content: '';
  position: absolute;
  inset: 0;
  /* Horizontal tile grout lines */
  background: repeating-linear-gradient(
    180deg,
    transparent 0px, transparent 58px,
    rgba(255,255,255,.06) 58px, rgba(255,255,255,.06) 60px
  );
}
.ct-kitchen-wall::after {
  content: '';
  position: absolute;
  inset: 0;
  /* Vertical tile grout lines */
  background: repeating-linear-gradient(
    90deg,
    transparent 0px, transparent 88px,
    rgba(255,255,255,.04) 88px, rgba(255,255,255,.04) 90px
  );
}

/* Kitchen floor — stone */
.ct-kitchen-floor {
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 34%;
  background: #151210;
  z-index: 1;
}
.ct-kitchen-floor::before {
  content: '';
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    180deg,
    transparent 0px, transparent 38px,
    rgba(255,255,255,.05) 38px, rgba(255,255,255,.05) 40px
  );
}
.ct-kitchen-floor::after {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 4px;
  background: rgba(200,137,10,.25);
}

/* Stainless steel prep counter — central */
.ct-counter {
  position: absolute;
  bottom: 34%; left: 50%; transform: translateX(-50%);
  width: 62%;
  height: 52px;
  background: linear-gradient(180deg, #A0A8A6 0%, #6E7876 30%, #4A5250 100%);
  z-index: 6;
  border-radius: 2px 2px 0 0;
}
.ct-counter::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 6px;
  background: linear-gradient(180deg, #D0D8D6 0%, #B0B8B6 100%);
  border-radius: 2px 2px 0 0;
}
.ct-counter::after {
  content: '';
  position: absolute;
  bottom: -200px; left: 10%; right: 10%;
  height: 200px;
  background: linear-gradient(180deg, #4A5250 0%, #2A2E2C 100%);
}

/* Counter lip edge shadow */
.ct-counter-shadow {
  position: absolute;
  bottom: calc(34% - 16px); left: 50%; transform: translateX(-50%);
  width: 64%;
  height: 16px;
  background: linear-gradient(180deg, rgba(0,0,0,.35) 0%, transparent 100%);
  z-index: 5;
}

/* Chef's range — left side */
.ct-range {
  position: absolute;
  bottom: 34%; left: 6%;
  width: 22%;
  height: 68%;
  background: linear-gradient(180deg, #1A1A1A 0%, #111111 100%);
  z-index: 4;
  border-top: 3px solid #333;
}
.ct-range::before {
  content: '';
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    180deg,
    transparent 0px, transparent 44px,
    rgba(255,255,255,.04) 44px, rgba(255,255,255,.04) 46px
  );
}
/* Range burners — top */
.ct-range-top {
  position: absolute;
  top: 4%; left: 10%; right: 10%;
  height: 30%;
  background: #0D0D0D;
  border-radius: 2px;
}
/* 6 burner circles */
<?php
for ($br = 0; $br < 6; $br++):
  $brow = $br < 3 ? 0 : 1;
  $bcol = $br % 3;
  $bleft = 6 + $bcol * 31;
  $btop  = 8 + $brow * 46;
?>
.ct-burner-<?php echo $br; ?> {
  position: absolute;
  width: 24%; aspect-ratio: 1;
  left: <?php echo $bleft; ?>%;
  top: <?php echo $btop; ?>%;
  border-radius: 50%;
  background: radial-gradient(circle, #222 0%, #111 60%, #0A0A0A 100%);
  border: 2px solid #333;
  z-index: 5;
}
.ct-burner-<?php echo $br; ?>::before {
  content: '';
  position: absolute;
  inset: 22%;
  border-radius: 50%;
  border: 2px solid #444;
}
<?php endfor; ?>

/* Extraction hood over range */
.ct-hood {
  position: absolute;
  top: 18%; left: 4%;
  width: 26%;
  height: 18%;
  background: linear-gradient(180deg, #2A2A2A 0%, #1A1A1A 100%);
  z-index: 4;
  clip-path: polygon(8% 0%, 92% 0%, 100% 100%, 0% 100%);
}
.ct-hood::before {
  content: '';
  position: absolute;
  bottom: 0; left: 5%; right: 5%;
  height: 4px;
  background: linear-gradient(90deg, transparent, var(--ct-saffron), transparent);
  opacity: .6;
}
/* Hood duct */
.ct-hood-duct {
  position: absolute;
  top: 18%; left: 10%;
  width: 10%;
  height: 14%;
  background: #222;
  z-index: 3;
  border-left: 2px solid #333;
  border-right: 2px solid #333;
}

/* Hanging rack with pots — right upper area */
.ct-pot-rack {
  position: absolute;
  top: 18%; right: 4%;
  width: 28%;
  height: 32%;
  z-index: 5;
}
/* Rack bar */
.ct-pot-rack::before {
  content: '';
  position: absolute;
  top: 8%; left: 0; right: 0;
  height: 10px;
  background: linear-gradient(180deg, #6A6A6A 0%, #3A3A3A 100%);
  border-radius: 5px;
}
/* Ceiling mounts */
.ct-pot-rack::after {
  content: '';
  position: absolute;
  top: 0; left: 20%; right: 20%;
  height: 9%;
  background: rgba(80,80,80,.6);
  clip-path: polygon(20% 0%, 80% 0%, 80% 100%, 20% 100%);
}

/* Individual hanging pots */
<?php
$pots = [
  ['l'=>'6%',  'c'=>'#4A4A4A', 'h'=>'62px', 'w'=>'46px'],
  ['l'=>'24%', 'c'=>'#3A3A3A', 'h'=>'52px', 'w'=>'40px'],
  ['l'=>'42%', 'c'=>'#5A5A5A', 'h'=>'70px', 'w'=>'54px'],
  ['l'=>'60%', 'c'=>'#424242', 'h'=>'56px', 'w'=>'44px'],
  ['l'=>'78%', 'c'=>'#3E3E3E', 'h'=>'64px', 'w'=>'50px'],
];
foreach ($pots as $pi => $pot):?>
.ct-pot-<?php echo $pi; ?> {
  position: absolute;
  top: calc(8% + 10px);
  left: <?php echo $pot['l']; ?>;
  width: <?php echo $pot['w']; ?>;
  z-index: 5;
}
/* Hook line */
.ct-pot-<?php echo $pi; ?>::before {
  content: '';
  display: block;
  width: 2px;
  height: 24px;
  background: #888;
  margin: 0 auto;
}
/* Pot body */
.ct-pot-<?php echo $pi; ?>-body {
  width: 100%;
  height: <?php echo $pot['h']; ?>;
  background: radial-gradient(ellipse at 30% 30%, #6A6A6A 0%, <?php echo $pot['c']; ?> 60%, #1A1A1A 100%);
  border-radius: 4px 4px 8px 8px;
  position: relative;
}
.ct-pot-<?php echo $pi; ?>-body::before {
  content: '';
  position: absolute;
  top: -6px; left: -6px; right: -6px;
  height: 12px;
  background: linear-gradient(180deg, #555 0%, #333 100%);
  border-radius: 3px;
}
.ct-pot-<?php echo $pi; ?>-body::after {
  content: '';
  position: absolute;
  top: 15%; left: 5%; right: 5%;
  height: 4px;
  background: rgba(255,255,255,.08);
  border-radius: 2px;
}
<?php endforeach; ?>

/* Knife block on counter */
.ct-knife-block {
  position: absolute;
  bottom: calc(34% + 52px);
  right: 24%;
  width: 52px;
  height: 80px;
  background: linear-gradient(180deg, #4A3018 0%, #2E1C0C 100%);
  border-radius: 4px 4px 0 0;
  z-index: 7;
}
.ct-knife-block::before {
  content: '';
  position: absolute;
  top: 8%; left: 12%; right: 12%;
  height: 84%;
  background: repeating-linear-gradient(
    180deg,
    rgba(0,0,0,.3) 0px, rgba(0,0,0,.3) 1px,
    transparent 1px, transparent 10px
  );
}
/* Knife handles sticking up */
<?php
$knives = [10, 24, 38];
foreach ($knives as $ki => $kl):?>
.ct-knife-<?php echo $ki; ?> {
  position: absolute;
  top: -38px;
  left: <?php echo $kl; ?>px;
  width: 6px;
  height: 42px;
  background: linear-gradient(180deg, #A09090 0%, #C0C0C0 40%, #888 100%);
  z-index: 8;
  border-radius: 0 0 1px 1px;
}
.ct-knife-<?php echo $ki; ?>::before {
  content: '';
  position: absolute;
  bottom: 0;
  left: -1px; right: -1px;
  height: 14px;
  background: linear-gradient(180deg, #3A2010 0%, #5A3010 100%);
  border-radius: 1px;
}
<?php endforeach; ?>

/* Herb garden on windowsill left */
.ct-herb-pots {
  position: absolute;
  bottom: calc(34% + 52px);
  left: 28%;
  display: flex;
  gap: 10px;
  z-index: 7;
  align-items: flex-end;
}
<?php
$herbs = [
  ['c' => '#2A5A2C', 'h' => '44px', 'n' => 'basil'],
  ['c' => '#3A6A28', 'h' => '36px', 'n' => 'thyme'],
  ['c' => '#488A30', 'h' => '50px', 'n' => 'rosemary'],
];
foreach ($herbs as $hi => $herb):?>
.ct-herb-<?php echo $hi; ?> {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0;
}
.ct-herb-<?php echo $hi; ?>-plant {
  width: 36px;
  height: <?php echo $herb['h']; ?>;
  background: radial-gradient(ellipse at 50% 60%, <?php echo $herb['c']; ?> 0%, #1A3A1A 100%);
  border-radius: 50% 50% 30% 30%;
  position: relative;
}
.ct-herb-<?php echo $hi; ?>-plant::before {
  content: '';
  position: absolute;
  bottom: 0; left: 50%; transform: translateX(-50%);
  width: 2px;
  height: 40%;
  background: #2A4A1A;
}
.ct-herb-<?php echo $hi; ?>-pot {
  width: 32px;
  height: 22px;
  background: linear-gradient(180deg, #8B5E3C 0%, #6A4020 100%);
  border-radius: 0 0 4px 4px;
  clip-path: polygon(5% 0%, 95% 0%, 90% 100%, 10% 100%);
}
<?php endforeach; ?>

/* Overhead kitchen lights — pendant lights */
<?php
$lights = [22, 42, 62, 80];
foreach ($lights as $lk => $ll):?>
.ct-plight-<?php echo $lk; ?> {
  position: absolute;
  top: 18%;
  left: <?php echo $ll; ?>%;
  width: 2px;
  height: 70px;
  background: #555;
  z-index: 8;
  transform: translateX(-50%);
}
.ct-plight-<?php echo $lk; ?>::before {
  content: '';
  position: absolute;
  bottom: 0; left: 50%; transform: translateX(-50%);
  width: 0;
  height: 0;
  border-left: 18px solid transparent;
  border-right: 18px solid transparent;
  border-top: 30px solid #333;
}
.ct-plight-<?php echo $lk; ?>::after {
  content: '';
  position: absolute;
  bottom: -30px; left: 50%; transform: translateX(-50%);
  width: 70px;
  height: 120px;
  background: radial-gradient(ellipse at 50% 0%, rgba(255,220,120,.12) 0%, transparent 70%);
}
<?php endforeach; ?>

/* Steam rising from pans */
<?php
$steams = [];
for ($s = 0; $s < 12; $s++):
  $steams[] = [
    'left' => (8 + rand(0,26)) . '%',
    'bot'  => (36 + rand(0,8))  . '%',
    'dur'  => (18 + rand(0,12)) / 10,
    'del'  => rand(0,20) / 10,
    'w'    => 4 + rand(0,6),
    'h'    => 20 + rand(0,30),
  ];
endfor;
foreach ($steams as $si => $st):?>
.ct-steam-<?php echo $si; ?> {
  position: absolute;
  left: <?php echo $st['left']; ?>;
  bottom: <?php echo $st['bot']; ?>;
  width: <?php echo $st['w']; ?>px;
  height: <?php echo $st['h']; ?>px;
  background: radial-gradient(ellipse, rgba(255,255,255,.22) 0%, transparent 70%);
  border-radius: 50%;
  z-index: 9;
  animation: ct-steam-rise <?php echo $st['dur']; ?>s ease-in infinite;
  animation-delay: <?php echo $st['del']; ?>s;
}
<?php endforeach; ?>

@keyframes ct-steam-rise {
  0%   { transform: translateY(0) scaleX(1); opacity: .7; }
  50%  { transform: translateY(-30px) scaleX(1.4); opacity: .3; }
  100% { transform: translateY(-70px) scaleX(.6); opacity: 0; }
}

/* Ambient warm light from range */
.ct-range-glow {
  position: absolute;
  bottom: 18%; left: 6%;
  width: 28%;
  height: 60%;
  background: radial-gradient(ellipse at 50% 80%, rgba(200,100,10,.18) 0%, transparent 65%);
  z-index: 3;
  pointer-events: none;
}

/* Gold accent strip */
.ct-gold-strip {
  position: absolute;
  top: 18%; left: 0; right: 0;
  height: 3px;
  background: linear-gradient(90deg, transparent 0%, var(--ct-saffron) 30%, var(--ct-saffron-lt) 50%, var(--ct-saffron) 70%, transparent 100%);
  z-index: 10;
  opacity: .5;
}

/* Hero content overlay */
.ct-hero-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, rgba(28,24,20,.92) 0%, rgba(28,24,20,.6) 60%, transparent 100%);
  z-index: 15;
}

.ct-hero-content {
  position: relative;
  z-index: 20;
  max-width: 640px;
}
.ct-hero-badge {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  background: rgba(200,137,10,.15);
  border: 1px solid rgba(200,137,10,.4);
  border-radius: 2px;
  padding: 8px 18px;
  font-family: var(--ct-sans);
  font-size: .72rem;
  font-weight: 600;
  letter-spacing: .2em;
  text-transform: uppercase;
  color: var(--ct-saffron-lt);
  margin-bottom: 28px;
}
.ct-hero-badge::before {
  content: '✦';
  font-size: .85rem;
}
.ct-hero-title {
  font-family: var(--ct-serif);
  font-size: clamp(2.4rem, 5vw, 4.2rem);
  font-weight: 700;
  line-height: 1.15;
  color: var(--ct-cream);
  margin-bottom: 10px;
}
.ct-hero-title em {
  font-style: italic;
  color: var(--ct-saffron-lt);
}
.ct-hero-subtitle {
  font-family: var(--ct-serif);
  font-size: clamp(1.1rem, 2vw, 1.5rem);
  font-weight: 400;
  font-style: italic;
  color: rgba(250,246,239,.75);
  margin-bottom: 24px;
}
.ct-hero-desc {
  font-size: 1rem;
  color: rgba(250,246,239,.65);
  line-height: 1.8;
  margin-bottom: 40px;
}
.ct-hero-actions { display: flex; gap: 16px; flex-wrap: wrap; }

/* Hero scene card (bottom right) */
.ct-kitchen-card {
  position: absolute;
  bottom: 40px; right: 40px;
  width: 200px;
  height: 130px;
  background: rgba(28,24,20,.85);
  border: 1px solid rgba(200,137,10,.3);
  border-radius: var(--ct-radius);
  overflow: hidden;
  z-index: 20;
  backdrop-filter: blur(4px);
}
.ct-kc-wall {
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 60%;
  background: #1F1A15;
}
.ct-kc-wall::before {
  content: '';
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    180deg, transparent 0px, transparent 14px,
    rgba(255,255,255,.06) 14px, rgba(255,255,255,.06) 15px
  );
}
.ct-kc-floor {
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 40%;
  background: #151210;
  border-top: 2px solid rgba(200,137,10,.3);
}
/* Mini counter in card */
.ct-kc-counter {
  position: absolute;
  bottom: 40%; left: 15%; right: 15%;
  height: 12px;
  background: linear-gradient(180deg, #8A9290 0%, #4A5250 100%);
  border-radius: 1px;
  z-index: 2;
}
/* Mini pots in card */
<?php foreach ([28, 52, 76] as $mpi => $mpl):?>
.ct-kc-pot-<?php echo $mpi; ?> {
  position: absolute;
  bottom: calc(40% + 12px);
  left: <?php echo $mpl; ?>%;
  width: 14px;
  height: 18px;
  background: radial-gradient(ellipse at 30% 30%, #666 0%, #333 100%);
  border-radius: 2px 2px 4px 4px;
  z-index: 3;
}
.ct-kc-pot-<?php echo $mpi; ?>::before {
  content: '';
  position: absolute;
  top: -3px; left: -2px; right: -2px;
  height: 5px;
  background: #555;
  border-radius: 1px;
}
<?php endforeach;?>
/* Mini light in card */
.ct-kc-light {
  position: absolute;
  top: 0; left: 50%;
  width: 1px;
  height: 20px;
  background: #444;
  transform: translateX(-50%);
  z-index: 4;
}
.ct-kc-light::before {
  content: '';
  position: absolute;
  bottom: 0; left: 50%; transform: translateX(-50%);
  width: 0; height: 0;
  border-left: 8px solid transparent;
  border-right: 8px solid transparent;
  border-top: 12px solid #222;
}
.ct-kc-light::after {
  content: '';
  position: absolute;
  bottom: -12px; left: 50%; transform: translateX(-50%);
  width: 40px; height: 50px;
  background: radial-gradient(ellipse at 50% 0%, rgba(255,220,120,.2) 0%, transparent 70%);
}
.ct-kc-label {
  position: absolute;
  bottom: 8px; left: 0; right: 0;
  text-align: center;
  font-family: var(--ct-serif);
  font-style: italic;
  font-size: .62rem;
  color: rgba(200,137,10,.8);
  z-index: 5;
  letter-spacing: .05em;
}

/* ============================================================
   STATS BAR
   ============================================================ */
.ct-stats-bar {
  background: var(--ct-charcoal);
  padding: 40px 0;
  border-top: 2px solid var(--ct-saffron);
}
.ct-stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 0;
  text-align: center;
}
.ct-stat-item {
  padding: 16px 24px;
  border-right: 1px solid rgba(255,255,255,.08);
}
.ct-stat-item:last-child { border-right: none; }
.ct-stat-number {
  font-family: var(--ct-serif);
  font-size: 2.8rem;
  font-weight: 700;
  color: var(--ct-saffron);
  line-height: 1;
  margin-bottom: 6px;
}
.ct-stat-label {
  font-size: .78rem;
  font-weight: 500;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: rgba(250,246,239,.5);
}

/* ============================================================
   ABOUT / PHILOSOPHY
   ============================================================ */
.ct-about {
  background: var(--ct-cream);
}
.ct-about-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 80px;
  align-items: center;
}
.ct-about-image {
  position: relative;
  height: 480px;
}
/* Chef's plating scene */
.ct-plate-scene {
  position: absolute;
  inset: 0;
  background: var(--ct-charcoal);
  border-radius: 8px;
  overflow: hidden;
}
/* Table surface */
.ct-ps-table {
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 55%;
  background: linear-gradient(180deg, #4A3018 0%, #2E1C0C 100%);
}
.ct-ps-table::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 5px;
  background: linear-gradient(90deg, #6A4820, #8A6030, #6A4820);
}
/* White plate */
.ct-ps-plate {
  position: absolute;
  bottom: 52%;
  left: 50%; transform: translateX(-50%);
  width: 160px;
  height: 16px;
  background: radial-gradient(ellipse at 50% 50%, #F8F8F6 0%, #E0DDD8 100%);
  border-radius: 50%;
  z-index: 3;
  box-shadow: 0 4px 20px rgba(0,0,0,.4);
}
.ct-ps-plate::before {
  content: '';
  position: absolute;
  top: 50%; left: 50%; transform: translate(-50%,-50%);
  width: 80%;
  height: 60%;
  border-radius: 50%;
  background: radial-gradient(ellipse, #FAFAF8 0%, #E8E5E0 100%);
}
/* Food on plate */
.ct-ps-food {
  position: absolute;
  bottom: calc(52% + 12px);
  left: 50%; transform: translateX(-50%);
  width: 80px;
  height: 30px;
  background: radial-gradient(ellipse at 40% 40%, #C06828 0%, #8A3E18 100%);
  border-radius: 50% 50% 30% 30%;
  z-index: 4;
}
.ct-ps-food::before {
  content: '';
  position: absolute;
  top: -14px; left: 30%; right: 30%;
  height: 20px;
  background: linear-gradient(180deg, #488A30 0%, #2A6020 100%);
  clip-path: polygon(50% 0%, 80% 60%, 100% 100%, 0% 100%, 20% 60%);
}
.ct-ps-food::after {
  content: '';
  position: absolute;
  bottom: -4px; right: -16px;
  width: 30px;
  height: 6px;
  background: linear-gradient(90deg, #D4B87A 0%, #C09840 100%);
  border-radius: 3px;
  transform: rotate(-15deg);
}
/* Sauce drizzle */
.ct-ps-sauce {
  position: absolute;
  bottom: calc(52% + 8px);
  left: calc(50% + 20px);
  width: 50px;
  height: 3px;
  background: linear-gradient(90deg, #8A1A1A 0%, #C03030 100%);
  border-radius: 2px;
  z-index: 5;
  transform: rotate(20deg);
}
.ct-ps-sauce::before {
  content: '';
  position: absolute;
  top: -10px; left: 0;
  width: 3px;
  height: 14px;
  background: #C03030;
  border-radius: 2px;
  transform: rotate(-20deg);
}
/* Microgreens garnish */
<?php for ($mg = 0; $mg < 5; $mg++):
  $mgl = 30 + $mg * 10;
  $mgh = 8 + rand(0,8);
?>
.ct-mg-<?php echo $mg; ?> {
  position: absolute;
  bottom: calc(52% + 42px);
  left: calc(50% - 40px + <?php echo $mgl; ?>px);
  width: 2px;
  height: <?php echo $mgh; ?>px;
  background: #488A30;
  z-index: 6;
  transform: rotate(<?php echo rand(-20,20); ?>deg);
  transform-origin: bottom center;
}
.ct-mg-<?php echo $mg; ?>::before {
  content: '';
  position: absolute;
  top: 0; left: -3px;
  width: 8px;
  height: 5px;
  background: #5AAA38;
  border-radius: 50% 50% 0 0;
  transform: rotate(<?php echo rand(-30,30); ?>deg);
}
<?php endfor; ?>
/* Wine glass */
.ct-ps-glass {
  position: absolute;
  bottom: 52%;
  right: 16%;
  z-index: 4;
}
.ct-ps-glass-bowl {
  width: 40px;
  height: 50px;
  background: linear-gradient(180deg,
    rgba(180,130,80,.2) 0%,
    rgba(120,80,40,.35) 60%,
    rgba(180,130,80,.15) 100%);
  border: 1px solid rgba(255,255,255,.25);
  border-radius: 0 0 50% 50%;
  position: relative;
}
.ct-ps-glass-stem {
  width: 2px;
  height: 40px;
  background: rgba(255,255,255,.2);
  margin: 0 auto;
}
.ct-ps-glass-base {
  width: 30px;
  height: 4px;
  background: rgba(255,255,255,.2);
  border-radius: 2px;
  margin: 0 auto;
}

/* Ambient candle light */
.ct-ps-candle {
  position: absolute;
  top: 10%; right: 10%;
  z-index: 4;
}
.ct-ps-candle-body {
  width: 14px;
  height: 60px;
  background: linear-gradient(180deg, #F8F0D8 0%, #E0D0A8 100%);
  border-radius: 2px;
  margin: 0 auto;
  position: relative;
}
.ct-ps-candle-body::before {
  content: '';
  position: absolute;
  top: -16px; left: 50%; transform: translateX(-50%);
  width: 8px;
  height: 18px;
  background: radial-gradient(ellipse at 50% 30%,
    rgba(255,255,180,.9) 0%,
    rgba(255,160,0,.7) 50%,
    rgba(200,80,0,.4) 100%);
  border-radius: 50% 50% 20% 20%;
  animation: ct-flame 1.4s ease-in-out infinite alternate;
}
@keyframes ct-flame {
  0%   { transform: translateX(-50%) scaleX(1) scaleY(1); }
  100% { transform: translateX(-52%) scaleX(.85) scaleY(1.12); }
}
.ct-ps-candle-base {
  width: 22px;
  height: 6px;
  background: #888;
  border-radius: 2px;
  margin: 0 auto;
}
.ct-ps-glow {
  position: absolute;
  top: 5%; right: 6%;
  width: 80px;
  height: 100px;
  background: radial-gradient(ellipse, rgba(255,160,40,.2) 0%, transparent 70%);
  z-index: 3;
  pointer-events: none;
}

.ct-about-text {}
.ct-about-values {
  display: flex;
  flex-direction: column;
  gap: 32px;
  margin-top: 36px;
}
.ct-value-item {
  display: flex;
  gap: 20px;
  align-items: flex-start;
}
.ct-value-icon {
  width: 48px;
  height: 48px;
  background: rgba(200,137,10,.1);
  border: 1px solid rgba(200,137,10,.3);
  border-radius: var(--ct-radius);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.3rem;
  flex-shrink: 0;
  color: var(--ct-saffron);
}
.ct-value-body h4 {
  font-family: var(--ct-serif);
  font-size: 1.1rem;
  font-weight: 700;
  color: var(--ct-charcoal);
  margin-bottom: 6px;
}
.ct-value-body p {
  font-size: .9rem;
  color: var(--ct-stone);
  line-height: 1.7;
}

/* ============================================================
   SERVICES / OFFERINGS
   ============================================================ */
.ct-services {
  background: var(--ct-ivory);
}
.ct-section-header {
  text-align: center;
  margin-bottom: 60px;
}
.ct-section-header .ct-lead {
  margin: 16px auto 0;
}
.ct-services-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 28px;
}
.ct-service-card {
  background: var(--ct-cream);
  border: 1px solid rgba(140,123,107,.15);
  border-radius: var(--ct-radius);
  padding: 36px 28px;
  position: relative;
  overflow: hidden;
  transition: transform .25s ease, box-shadow .25s ease;
}
.ct-service-card:hover {
  transform: translateY(-4px);
  box-shadow: var(--ct-shadow);
}
.ct-service-card::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 3px;
  background: linear-gradient(90deg, var(--ct-saffron), var(--ct-saffron-lt));
  transform: scaleX(0);
  transform-origin: left;
  transition: transform .3s ease;
}
.ct-service-card:hover::before { transform: scaleX(1); }
.ct-service-icon {
  font-size: 2rem;
  margin-bottom: 16px;
  display: block;
}
.ct-service-card h3 {
  font-family: var(--ct-serif);
  font-size: 1.2rem;
  font-weight: 700;
  color: var(--ct-charcoal);
  margin-bottom: 10px;
}
.ct-service-card p {
  font-size: .88rem;
  color: var(--ct-stone);
  line-height: 1.7;
}
.ct-service-card .ct-service-guests {
  display: inline-block;
  margin-top: 14px;
  font-size: .75rem;
  font-weight: 600;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: var(--ct-saffron);
}

/* ============================================================
   SIGNATURE MENUS
   ============================================================ */
.ct-menus {
  background: var(--ct-charcoal);
}
.ct-menus .ct-tag { color: var(--ct-saffron-lt); }
.ct-menus .ct-heading { color: var(--ct-cream); }
.ct-menus .ct-heading em { color: var(--ct-saffron-lt); }
.ct-menus-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 28px;
  margin-top: 52px;
}
.ct-menu-card {
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(200,137,10,.2);
  border-radius: var(--ct-radius);
  overflow: hidden;
  transition: transform .25s ease, border-color .25s ease;
}
.ct-menu-card:hover {
  transform: translateY(-4px);
  border-color: rgba(200,137,10,.5);
}
.ct-menu-header {
  padding: 28px 24px 20px;
  border-bottom: 1px solid rgba(255,255,255,.06);
  position: relative;
}
.ct-menu-season {
  display: inline-block;
  font-size: .7rem;
  font-weight: 600;
  letter-spacing: .15em;
  text-transform: uppercase;
  color: var(--ct-saffron);
  margin-bottom: 8px;
}
.ct-menu-card h3 {
  font-family: var(--ct-serif);
  font-size: 1.35rem;
  font-weight: 700;
  font-style: italic;
  color: var(--ct-cream);
  line-height: 1.3;
}
.ct-menu-courses {
  padding: 20px 24px;
}
.ct-course {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 10px 0;
  border-bottom: 1px solid rgba(255,255,255,.05);
}
.ct-course:last-child { border-bottom: none; }
.ct-course-num {
  font-size: .68rem;
  font-weight: 600;
  letter-spacing: .15em;
  text-transform: uppercase;
  color: var(--ct-saffron);
}
.ct-course-name {
  font-family: var(--ct-serif);
  font-size: .98rem;
  font-style: italic;
  color: var(--ct-cream);
}
.ct-course-desc {
  font-size: .8rem;
  color: rgba(250,246,239,.45);
  line-height: 1.5;
}
.ct-menu-footer {
  padding: 16px 24px;
  background: rgba(200,137,10,.07);
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.ct-menu-price {
  font-family: var(--ct-serif);
  font-size: 1.3rem;
  color: var(--ct-saffron-lt);
  font-weight: 700;
}
.ct-menu-ppx {
  font-size: .72rem;
  color: rgba(250,246,239,.4);
  text-transform: uppercase;
  letter-spacing: .08em;
}

/* ============================================================
   PROCESS / HOW IT WORKS
   ============================================================ */
.ct-process {
  background: var(--ct-cream);
}
.ct-process-steps {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 40px;
  margin-top: 60px;
  position: relative;
}
.ct-process-steps::before {
  content: '';
  position: absolute;
  top: 36px; left: calc(12.5% + 20px); right: calc(12.5% + 20px);
  height: 1px;
  background: linear-gradient(90deg, var(--ct-saffron), transparent);
}
.ct-process-step {
  text-align: center;
}
.ct-step-num {
  width: 72px;
  height: 72px;
  border-radius: 50%;
  background: var(--ct-charcoal);
  border: 2px solid var(--ct-saffron);
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: var(--ct-serif);
  font-size: 1.5rem;
  font-weight: 700;
  color: var(--ct-saffron);
  margin: 0 auto 20px;
  position: relative;
  z-index: 2;
}
.ct-step-title {
  font-family: var(--ct-serif);
  font-size: 1.1rem;
  font-weight: 700;
  color: var(--ct-charcoal);
  margin-bottom: 8px;
}
.ct-step-desc {
  font-size: .85rem;
  color: var(--ct-stone);
  line-height: 1.65;
}

/* ============================================================
   PACKAGES / PRICING
   ============================================================ */
.ct-packages {
  background: var(--ct-ivory);
}
.ct-packages-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 28px;
  margin-top: 52px;
}
.ct-package-card {
  background: var(--ct-cream);
  border: 2px solid rgba(140,123,107,.15);
  border-radius: var(--ct-radius);
  padding: 40px 32px;
  position: relative;
  transition: transform .25s ease, box-shadow .25s ease;
}
.ct-package-card:hover {
  transform: translateY(-4px);
  box-shadow: var(--ct-shadow);
}
.ct-package-card.featured {
  background: var(--ct-charcoal);
  border-color: var(--ct-saffron);
}
.ct-pkg-badge {
  position: absolute;
  top: -14px; left: 50%; transform: translateX(-50%);
  background: var(--ct-saffron);
  color: var(--ct-charcoal);
  font-size: .68rem;
  font-weight: 700;
  letter-spacing: .15em;
  text-transform: uppercase;
  padding: 4px 16px;
  border-radius: 20px;
  white-space: nowrap;
}
.ct-pkg-name {
  font-family: var(--ct-serif);
  font-size: 1.1rem;
  font-weight: 700;
  color: var(--ct-charcoal);
  margin-bottom: 6px;
  text-align: center;
}
.ct-package-card.featured .ct-pkg-name { color: var(--ct-cream); }
.ct-pkg-price {
  font-family: var(--ct-serif);
  font-size: 2.4rem;
  font-weight: 700;
  color: var(--ct-saffron);
  text-align: center;
  line-height: 1;
  margin: 16px 0 4px;
}
.ct-pkg-unit {
  font-size: .78rem;
  color: var(--ct-stone);
  text-align: center;
  margin-bottom: 24px;
  text-transform: uppercase;
  letter-spacing: .08em;
}
.ct-package-card.featured .ct-pkg-unit { color: rgba(250,246,239,.5); }
.ct-pkg-divider {
  height: 1px;
  background: rgba(140,123,107,.15);
  margin-bottom: 24px;
}
.ct-package-card.featured .ct-pkg-divider { background: rgba(255,255,255,.08); }
.ct-pkg-features {
  list-style: none;
  margin-bottom: 32px;
}
.ct-pkg-features li {
  display: flex;
  gap: 10px;
  align-items: flex-start;
  font-size: .88rem;
  color: var(--ct-stone);
  margin-bottom: 10px;
  line-height: 1.5;
}
.ct-package-card.featured .ct-pkg-features li { color: rgba(250,246,239,.7); }
.ct-pkg-features li::before {
  content: '✦';
  color: var(--ct-saffron);
  font-size: .7rem;
  margin-top: 3px;
  flex-shrink: 0;
}

/* ============================================================
   CSS CHEF FIGURES
   ============================================================ */
.ct-chefs-section {
  background: var(--ct-charcoal);
  padding: 96px 0;
  overflow: hidden;
}
.ct-chefs-section .ct-tag  { color: var(--ct-saffron-lt); }
.ct-chefs-section .ct-heading { color: var(--ct-cream); }
.ct-chefs-section .ct-lead { color: rgba(250,246,239,.55); }
.ct-chefs-row {
  display: flex;
  gap: 48px;
  justify-content: center;
  margin-top: 64px;
}
.ct-chef-figure {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0;
}
/* Chef's toque */
.ct-chef-toque {
  width: 40px;
  height: 32px;
  background: linear-gradient(180deg, #F8F8F8 0%, #E8E8E8 100%);
  border-radius: 50% 50% 0 0 / 60% 60% 0 0;
  position: relative;
}
.ct-chef-toque::before {
  content: '';
  position: absolute;
  bottom: 0; left: -2px; right: -2px;
  height: 6px;
  background: #E0E0E0;
  border-radius: 0 0 2px 2px;
}
.ct-chef-toque::after {
  content: '';
  position: absolute;
  top: 4px; left: 4px; right: 4px;
  height: 60%;
  background: repeating-linear-gradient(
    180deg,
    rgba(255,255,255,.5) 0px, rgba(255,255,255,.5) 2px,
    transparent 2px, transparent 5px
  );
  border-radius: 50% 50% 0 0 / 60% 60% 0 0;
}
/* Head */
.ct-chef-head {
  width: 36px;
  height: 38px;
  background: radial-gradient(ellipse at 40% 35%, #F5D5A8 0%, #D4A068 100%);
  border-radius: 50% 50% 45% 45%;
  position: relative;
}
.ct-chef-head::before {
  content: '';
  position: absolute;
  bottom: 4px; left: 20%; right: 20%;
  height: 5px;
  background: rgba(120,70,30,.2);
  border-radius: 0 0 6px 6px;
}
/* Neck */
.ct-chef-neck {
  width: 14px;
  height: 10px;
  background: #D4A068;
  margin: 0 auto;
}
/* White chef jacket */
.ct-chef-jacket {
  width: 60px;
  height: 72px;
  background: linear-gradient(180deg, #F4F4F4 0%, #E8E8E8 100%);
  border-radius: 6px 6px 4px 4px;
  position: relative;
}
/* Double-breasted buttons */
.ct-chef-jacket::before {
  content: '';
  position: absolute;
  top: 12px; left: 50%; transform: translateX(-50%);
  width: 2px;
  height: 48px;
  background: repeating-linear-gradient(
    180deg,
    #C0C0C0 0px, #C0C0C0 4px,
    transparent 4px, transparent 14px
  );
}
/* Jacket collar / lapels */
.ct-chef-jacket::after {
  content: '';
  position: absolute;
  top: 0; left: 50%; transform: translateX(-50%);
  width: 0; height: 0;
  border-left: 8px solid transparent;
  border-right: 8px solid transparent;
  border-top: 16px solid var(--ct-stone);
}
/* Left arm */
.ct-chef-arm-l {
  position: absolute;
  top: 4px; left: -16px;
  width: 16px;
  height: 52px;
  background: linear-gradient(180deg, #E8E8E8 0%, #D0D0D0 100%);
  border-radius: 8px 4px 4px 8px;
  transform: rotate(8deg);
  transform-origin: top center;
}
/* Right arm (holding ladle) */
.ct-chef-arm-r {
  position: absolute;
  top: 4px; right: -14px;
  width: 16px;
  height: 48px;
  background: linear-gradient(180deg, #E8E8E8 0%, #D0D0D0 100%);
  border-radius: 4px 8px 8px 4px;
  transform: rotate(-18deg);
  transform-origin: top center;
}
/* Ladle on right arm */
.ct-chef-arm-r::before {
  content: '';
  position: absolute;
  bottom: -18px; left: 50%; transform: translateX(-50%);
  width: 3px;
  height: 22px;
  background: #888;
}
.ct-chef-arm-r::after {
  content: '';
  position: absolute;
  bottom: -36px; left: 50%; transform: translateX(-60%);
  width: 18px;
  height: 10px;
  background: radial-gradient(ellipse, #A0A0A0 0%, #707070 100%);
  border-radius: 0 0 50% 50%;
}
/* Legs */
.ct-chef-legs {
  width: 60px;
  height: 60px;
  position: relative;
}
.ct-chef-leg-l, .ct-chef-leg-r {
  position: absolute;
  bottom: 0;
  width: 22px;
  height: 56px;
  background: linear-gradient(180deg, #1A1A1A 0%, #2A2A2A 100%);
  border-radius: 4px 4px 0 0;
}
.ct-chef-leg-l { left: 4px; }
.ct-chef-leg-r { right: 4px; }
.ct-chef-leg-l::after, .ct-chef-leg-r::after {
  content: '';
  position: absolute;
  bottom: 0;
  width: 100%;
  height: 10px;
  background: #111;
  border-radius: 0 0 3px 3px;
}
/* Chef apron */
.ct-chef-apron {
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 58px;
  background: linear-gradient(180deg, rgba(200,137,10,.3) 0%, rgba(200,137,10,.15) 100%);
  clip-path: polygon(15% 0%, 85% 0%, 90% 100%, 10% 100%);
}
.ct-chef-name {
  margin-top: 16px;
  font-family: var(--ct-serif);
  font-size: .9rem;
  font-style: italic;
  color: rgba(250,246,239,.7);
  text-align: center;
}
.ct-chef-role {
  font-size: .72rem;
  font-weight: 600;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: var(--ct-saffron);
  text-align: center;
  margin-top: 2px;
}

/* ============================================================
   TESTIMONIALS
   ============================================================ */
.ct-testimonials {
  background: var(--ct-cream);
}
.ct-testi-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 28px;
  margin-top: 52px;
}
.ct-testi-card {
  background: var(--ct-ivory);
  border: 1px solid rgba(140,123,107,.2);
  border-radius: var(--ct-radius);
  padding: 32px 28px;
  position: relative;
}
.ct-testi-card::before {
  content: '"';
  position: absolute;
  top: 16px; left: 24px;
  font-family: var(--ct-serif);
  font-size: 4rem;
  color: rgba(200,137,10,.2);
  line-height: 1;
}
.ct-testi-stars {
  color: var(--ct-saffron);
  font-size: .85rem;
  margin-bottom: 14px;
}
.ct-testi-text {
  font-family: var(--ct-serif);
  font-style: italic;
  font-size: .98rem;
  color: var(--ct-charcoal);
  line-height: 1.7;
  margin-bottom: 20px;
}
.ct-testi-author {
  font-weight: 600;
  font-size: .82rem;
  color: var(--ct-stone);
  text-transform: uppercase;
  letter-spacing: .08em;
}
.ct-testi-event {
  font-size: .78rem;
  color: var(--ct-saffron);
  margin-top: 2px;
}

/* ============================================================
   FAQ
   ============================================================ */
.ct-faq {
  background: var(--ct-ivory);
}
.ct-faq-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 48px;
  align-items: start;
  margin-top: 52px;
}
.ct-faq-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.ct-faq-item {
  background: var(--ct-cream);
  border: 1px solid rgba(140,123,107,.15);
  border-radius: var(--ct-radius);
  overflow: hidden;
}
.ct-faq-q {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 18px 22px;
  cursor: pointer;
  font-family: var(--ct-serif);
  font-size: .98rem;
  font-weight: 700;
  color: var(--ct-charcoal);
  user-select: none;
  transition: color .2s;
}
.ct-faq-q:hover { color: var(--ct-saffron); }
.ct-faq-icon {
  width: 22px; height: 22px;
  border: 1px solid rgba(200,137,10,.4);
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .85rem;
  color: var(--ct-saffron);
  flex-shrink: 0;
  transition: transform .3s ease;
}
.ct-faq-item.open .ct-faq-icon { transform: rotate(45deg); }
.ct-faq-a {
  max-height: 0;
  overflow: hidden;
  transition: max-height .35s ease;
}
.ct-faq-a-inner {
  padding: 0 22px 18px;
  font-size: .88rem;
  color: var(--ct-stone);
  line-height: 1.75;
}
.ct-faq-item.open .ct-faq-a { max-height: 300px; }

/* FAQ sidebar CTA */
.ct-faq-cta {
  background: var(--ct-charcoal);
  border-radius: var(--ct-radius);
  padding: 40px 32px;
  display: flex;
  flex-direction: column;
  gap: 20px;
}
.ct-faq-cta h3 {
  font-family: var(--ct-serif);
  font-size: 1.5rem;
  font-style: italic;
  color: var(--ct-cream);
  line-height: 1.3;
}
.ct-faq-cta p {
  font-size: .9rem;
  color: rgba(250,246,239,.6);
  line-height: 1.7;
}
.ct-faq-contact {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.ct-faq-contact a {
  color: var(--ct-saffron-lt);
  text-decoration: none;
  font-size: .88rem;
  display: flex;
  align-items: center;
  gap: 8px;
}
.ct-faq-contact a:hover { color: var(--ct-cream); }

/* ============================================================
   ENQUIRY FORM
   ============================================================ */
.ct-enquiry {
  background: var(--ct-charcoal);
}
.ct-enquiry .ct-tag  { color: var(--ct-saffron-lt); }
.ct-enquiry .ct-heading { color: var(--ct-cream); }
.ct-enquiry .ct-lead { color: rgba(250,246,239,.55); }
.ct-form-wrapper {
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(200,137,10,.2);
  border-radius: var(--ct-radius);
  padding: 52px 48px;
  margin-top: 52px;
  max-width: 880px;
  margin-left: auto;
  margin-right: auto;
}
.ct-form-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 24px;
  margin-bottom: 24px;
}
.ct-form-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.ct-form-group.full { grid-column: 1 / -1; }
.ct-form-group label {
  font-size: .78rem;
  font-weight: 600;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: rgba(250,246,239,.5);
}
.ct-form-group input,
.ct-form-group select,
.ct-form-group textarea {
  background: rgba(255,255,255,.06);
  border: 1px solid rgba(255,255,255,.1);
  border-radius: var(--ct-radius);
  padding: 13px 16px;
  font-family: var(--ct-sans);
  font-size: .92rem;
  color: var(--ct-cream);
  transition: border-color .2s;
  outline: none;
  width: 100%;
}
.ct-form-group input::placeholder,
.ct-form-group textarea::placeholder { color: rgba(250,246,239,.3); }
.ct-form-group input:focus,
.ct-form-group select:focus,
.ct-form-group textarea:focus {
  border-color: var(--ct-saffron);
}
.ct-form-group select { cursor: pointer; }
.ct-form-group select option { background: var(--ct-charcoal); color: var(--ct-cream); }
.ct-form-group textarea { resize: vertical; min-height: 120px; }
.ct-form-actions {
  display: flex;
  align-items: center;
  gap: 20px;
  margin-top: 8px;
}
.ct-form-note {
  font-size: .78rem;
  color: rgba(250,246,239,.3);
  line-height: 1.5;
}
.ct-form-success {
  display: none;
  text-align: center;
  padding: 32px;
  color: var(--ct-cream);
}
.ct-form-success h3 {
  font-family: var(--ct-serif);
  font-size: 1.5rem;
  font-style: italic;
  color: var(--ct-saffron-lt);
  margin-bottom: 8px;
}

/* ============================================================
   FOOTER
   ============================================================ */
.ct-footer {
  background: #110D09;
  padding: 60px 0 32px;
  border-top: 1px solid rgba(200,137,10,.2);
}
.ct-footer-inner {
  display: grid;
  grid-template-columns: 2fr 1fr 1fr;
  gap: 60px;
  margin-bottom: 48px;
}
.ct-footer-brand h3 {
  font-family: var(--ct-serif);
  font-size: 1.4rem;
  font-style: italic;
  color: var(--ct-cream);
  margin-bottom: 6px;
}
.ct-footer-brand span {
  font-size: .72rem;
  font-weight: 600;
  letter-spacing: .2em;
  text-transform: uppercase;
  color: var(--ct-saffron);
  display: block;
  margin-bottom: 14px;
}
.ct-footer-brand p {
  font-size: .85rem;
  color: rgba(250,246,239,.4);
  line-height: 1.7;
  max-width: 300px;
}
.ct-footer-col h4 {
  font-size: .72rem;
  font-weight: 700;
  letter-spacing: .15em;
  text-transform: uppercase;
  color: var(--ct-saffron);
  margin-bottom: 16px;
}
.ct-footer-col ul { list-style: none; }
.ct-footer-col ul li {
  margin-bottom: 8px;
}
.ct-footer-col ul li a {
  font-size: .85rem;
  color: rgba(250,246,239,.4);
  text-decoration: none;
  transition: color .2s;
}
.ct-footer-col ul li a:hover { color: var(--ct-cream); }
.ct-footer-bottom {
  border-top: 1px solid rgba(255,255,255,.06);
  padding-top: 24px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.ct-footer-bottom p {
  font-size: .78rem;
  color: rgba(250,246,239,.25);
}
.ct-footer-bottom a {
  font-size: .78rem;
  color: rgba(200,137,10,.5);
  text-decoration: none;
}
.ct-footer-bottom a:hover { color: var(--ct-saffron); }

/* ============================================================
   RESPONSIVE
   ============================================================ */
@media (max-width: 1024px) {
  .ct-about-grid    { grid-template-columns: 1fr; gap: 48px; }
  .ct-about-image   { height: 320px; }
  .ct-services-grid { grid-template-columns: repeat(2, 1fr); }
  .ct-menus-grid    { grid-template-columns: 1fr; gap: 20px; }
  .ct-packages-grid { grid-template-columns: 1fr; gap: 20px; }
  .ct-footer-inner  { grid-template-columns: 1fr 1fr; }
}
@media (max-width: 768px) {
  .ct-section { padding: 64px 0; }
  .ct-container { padding: 0 20px; }
  .ct-hero-content { padding: 0 20px; }
  .ct-stats-grid   { grid-template-columns: repeat(2, 1fr); }
  .ct-services-grid { grid-template-columns: 1fr; }
  .ct-process-steps { grid-template-columns: repeat(2, 1fr); }
  .ct-process-steps::before { display: none; }
  .ct-testi-grid   { grid-template-columns: 1fr; }
  .ct-faq-grid     { grid-template-columns: 1fr; }
  .ct-form-grid    { grid-template-columns: 1fr; }
  .ct-chefs-row    { flex-wrap: wrap; gap: 32px; }
  .ct-footer-inner { grid-template-columns: 1fr; gap: 32px; }
  .ct-kitchen-card { display: none; }
  .ct-footer-bottom { flex-direction: column; gap: 12px; text-align: center; }
}
</style>
<?php get_header(); ?>
<div class="page-template-page-caterer">
>

<!-- HERO -->
<section class="ct-hero">
  <div class="ct-kitchen">
    <div class="ct-kitchen-ceiling"></div>
    <div class="ct-kitchen-wall"></div>
    <div class="ct-kitchen-floor"></div>
    <div class="ct-range">
      <div class="ct-range-top">
        <?php for ($br = 0; $br < 6; $br++): ?>
        <div class="ct-burner-<?php echo $br; ?>"></div>
        <?php endfor; ?>
      </div>
    </div>
    <div class="ct-hood-duct"></div>
    <div class="ct-hood"></div>
    <div class="ct-range-glow"></div>
    <div class="ct-counter"></div>
    <div class="ct-counter-shadow"></div>
    <div class="ct-pot-rack">
      <?php foreach ($pots as $pi => $pot): ?>
      <div class="ct-pot-<?php echo $pi; ?>">
        <div class="ct-pot-<?php echo $pi; ?>-body"></div>
      </div>
      <?php endforeach; ?>
    </div>
    <div class="ct-knife-block">
      <?php foreach ($knives as $ki => $kl): ?>
      <div class="ct-knife-<?php echo $ki; ?>"></div>
      <?php endforeach; ?>
    </div>
    <div class="ct-herb-pots">
      <?php foreach ($herbs as $hi => $herb): ?>
      <div class="ct-herb-<?php echo $hi; ?>">
        <div class="ct-herb-<?php echo $hi; ?>-plant"></div>
        <div class="ct-herb-<?php echo $hi; ?>-pot"></div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php foreach ([22, 42, 62, 80] as $lk => $ll): ?>
    <div class="ct-plight-<?php echo $lk; ?>"></div>
    <?php endforeach; ?>
    <?php foreach ($steams as $si => $st): ?>
    <div class="ct-steam-<?php echo $si; ?>"></div>
    <?php endforeach; ?>
    <div class="ct-gold-strip"></div>
  </div>

  <div class="ct-hero-overlay"></div>

  <div class="ct-container" style="position:relative;z-index:20;width:100%;">
    <div class="ct-hero-content">
      <div class="ct-hero-badge">Belgravia, London · Est. 1998</div>
      <h1 class="ct-hero-title">
        Where Culinary <em>Artistry</em><br>Meets Your Table
      </h1>
      <p class="ct-hero-subtitle">Luxury event catering & private chef experiences</p>
      <p class="ct-hero-desc">
        Saffron & Stone brings the precision of a Michelin kitchen to your most cherished occasions — weddings, corporate galas, intimate dinners, and everything in between.
      </p>
      <div class="ct-hero-actions">
        <a href="#enquiry" class="ct-btn ct-btn-primary">Begin Your Event</a>
        <a href="#menus" class="ct-btn ct-btn-outline">View Menus</a>
      </div>
    </div>
  </div>

  <!-- Kitchen scene card -->
  <div class="ct-kitchen-card">
    <div class="ct-kc-wall"></div>
    <div class="ct-kc-floor"></div>
    <div class="ct-kc-counter"></div>
    <?php foreach ([28, 52, 76] as $mpi => $mpl): ?>
    <div class="ct-kc-pot-<?php echo $mpi; ?>"></div>
    <?php endforeach; ?>
    <div class="ct-kc-light"></div>
    <div class="ct-kc-label">✦ Saffron & Stone Kitchen</div>
  </div>
</section>

<!-- STATS BAR -->
<section class="ct-stats-bar">
  <div class="ct-container">
    <div class="ct-stats-grid">
      <?php
      $stats = [
        ['val'=>'1,200+', 'lbl'=>'Events Catered'],
        ['val'=>'26yrs',  'lbl'=>'Culinary Excellence'],
        ['val'=>'4.9★',   'lbl'=>'Average Rating'],
        ['val'=>'98%',    'lbl'=>'Client Return Rate'],
      ];
      foreach ($stats as $st):?>
      <div class="ct-stat-item">
        <div class="ct-stat-number" data-target="<?php echo esc_attr($st['val']); ?>"><?php echo esc_html($st['val']); ?></div>
        <div class="ct-stat-label"><?php echo esc_html($st['lbl']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ABOUT -->
<section class="ct-about ct-section" id="about">
  <div class="ct-container">
    <div class="ct-about-grid">
      <!-- Plating scene -->
      <div class="ct-about-image">
        <div class="ct-plate-scene">
          <div class="ct-ps-table"></div>
          <div class="ct-ps-plate"></div>
          <div class="ct-ps-food"></div>
          <div class="ct-ps-sauce"></div>
          <?php for ($mg = 0; $mg < 5; $mg++): ?>
          <div class="ct-mg-<?php echo $mg; ?>"></div>
          <?php endfor; ?>
          <div class="ct-ps-glass">
            <div class="ct-ps-glass-bowl"></div>
            <div class="ct-ps-glass-stem"></div>
            <div class="ct-ps-glass-base"></div>
          </div>
          <div class="ct-ps-candle">
            <div class="ct-ps-candle-body"></div>
            <div class="ct-ps-candle-base"></div>
          </div>
          <div class="ct-ps-glow"></div>
        </div>
      </div>
      <div class="ct-about-text">
        <span class="ct-tag">Our Story</span>
        <h2 class="ct-heading">Twenty-Six Years of <em>Gastronomic</em> Excellence</h2>
        <p class="ct-lead" style="margin-top:20px;">
          Founded in 1998 by head chef Antoine Saffron, we have spent over two decades perfecting the art of bespoke catering — crafting menus that celebrate seasonal British produce and global inspiration.
        </p>
        <div class="ct-about-values">
          <?php
          $values = [
            ['icon'=>'🌿', 'title'=>'Provenance & Seasonality',  'desc'=>'Every ingredient is selected at its peak from trusted British suppliers, farmers\' markets, and our own kitchen garden.'],
            ['icon'=>'🍽️', 'title'=>'Precision & Craft',          'desc'=>'Our brigade of chefs brings Michelin-level technique to every plate — whether for 10 guests or 1,000.'],
            ['icon'=>'✦',  'title'=>'Bespoke Every Time',         'desc'=>'No two menus are alike. We collaborate closely with each client to create a culinary narrative unique to their event.'],
          ];
          foreach ($values as $v):?>
          <div class="ct-value-item">
            <div class="ct-value-icon"><?php echo $v['icon']; ?></div>
            <div class="ct-value-body">
              <h4><?php echo esc_html($v['title']); ?></h4>
              <p><?php echo esc_html($v['desc']); ?></p>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- SERVICES -->
<section class="ct-services ct-section" id="services">
  <div class="ct-container">
    <div class="ct-section-header">
      <span class="ct-tag">What We Do</span>
      <h2 class="ct-heading">Our <em>Services</em></h2>
      <p class="ct-lead">From intimate supper clubs to grand celebrations, we bring the same uncompromising standard to every occasion.</p>
    </div>
    <div class="ct-services-grid">
      <?php
      $services = [
        ['icon'=>'💍','name'=>'Wedding Catering',       'desc'=>'Bespoke wedding breakfasts, reception canapés, and seated dinners designed around your story and style.','guests'=>'10 – 500 guests'],
        ['icon'=>'🏢','name'=>'Corporate Events',        'desc'=>'Executive lunches, product launches, boardroom dining, and large-scale gala dinners executed with precision.','guests'=>'10 – 2,000 guests'],
        ['icon'=>'🍾','name'=>'Private Dining',          'desc'=>'A private chef for your home or villa, crafting a multi-course tasting menu with full front-of-house service.','guests'=>'4 – 30 guests'],
        ['icon'=>'🥂','name'=>'Champagne Receptions',   'desc'=>'Elegant canapé and cocktail receptions with bespoke drinks pairings and theatrical food stations.','guests'=>'20 – 800 guests'],
        ['icon'=>'🎉','name'=>'Birthday & Celebrations','desc'=>'From milestone birthdays to anniversary dinners, we create unforgettable celebratory feasts.','guests'=>'6 – 200 guests'],
        ['icon'=>'🎓','name'=>'Pop-Up & Supper Clubs',  'desc'=>'Unique culinary experiences, exclusive dining events, and immersive chef's table evenings.','guests'=>'12 – 60 guests'],
      ];
      foreach ($services as $svc):?>
      <div class="ct-service-card">
        <span class="ct-service-icon"><?php echo $svc['icon']; ?></span>
        <h3><?php echo esc_html($svc['name']); ?></h3>
        <p><?php echo esc_html($svc['desc']); ?></p>
        <span class="ct-service-guests"><?php echo esc_html($svc['guests']); ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- SIGNATURE MENUS -->
<section class="ct-menus ct-section" id="menus">
  <div class="ct-container">
    <div class="ct-section-header">
      <span class="ct-tag">Signature Menus</span>
      <h2 class="ct-heading">Curated <em>Seasonal</em> Offerings</h2>
    </div>
    <div class="ct-menus-grid">
      <?php
      $menus = [
        [
          'season' => 'Spring / Summer',
          'name'   => 'The Garden Table',
          'courses'=> [
            ['num'=>'Amuse-Bouche','name'=>'Chilled Cucumber Velouté','desc'=>'lovage oil, crab royale'],
            ['num'=>'First','name'=>'Heritage Tomato & Burrata','desc'=>'basil oil, aged balsamic, sourdough crisp'],
            ['num'=>'Main','name'=>'Cornish Sea Bass','desc'=>'asparagus, lemon beurre blanc, samphire, caviar'],
            ['num'=>'Dessert','name'=>'Elderflower Panna Cotta','desc'=>'strawberry consommé, meringue shards'],
          ],
          'price'  => '£140',
        ],
        [
          'season' => 'Autumn / Winter',
          'name'   => 'The Manor Feast',
          'courses'=> [
            ['num'=>'Amuse-Bouche','name'=>'Truffle Arancini','desc'=>'aged parmesan foam, chestnut crumb'],
            ['num'=>'First','name'=>'Slow-Braised Ox Cheek','desc'=>'celeriac purée, pickled walnut, micro herbs'],
            ['num'=>'Main','name'=>'Roast Herdwick Lamb Rack','desc'=>'dauphinoise, haricot verts, rosemary jus'],
            ['num'=>'Dessert','name'=>'Valrhona Chocolate Délice','desc'=>'salted caramel, candied hazelnut praline'],
          ],
          'price'  => '£165',
        ],
        [
          'season' => 'Year-Round Signature',
          'name'   => 'The Prestige',
          'courses'=> [
            ['num'=>'Canapés','name'=>'Oscietra Caviar Blini','desc'=>'crème fraîche, chive, warm potato'],
            ['num'=>'First','name'=>'Foie Gras Terrine','desc'=>'Sauternes jelly, brioche, apple chutney'],
            ['num'=>'Main','name'=>'Dry-Aged Beef Wellington','desc'=>'truffle duxelles, sauce périgueux, wilted spinach'],
            ['num'=>'Dessert','name'=>'Grand Cru Soufflé','desc'=>'served à la minute, double cream, tuile'],
          ],
          'price'  => '£220',
        ],
      ];
      foreach ($menus as $mn):?>
      <div class="ct-menu-card">
        <div class="ct-menu-header">
          <span class="ct-menu-season"><?php echo esc_html($mn['season']); ?></span>
          <h3><?php echo esc_html($mn['name']); ?></h3>
        </div>
        <div class="ct-menu-courses">
          <?php foreach ($mn['courses'] as $co):?>
          <div class="ct-course">
            <span class="ct-course-num"><?php echo esc_html($co['num']); ?></span>
            <span class="ct-course-name"><?php echo esc_html($co['name']); ?></span>
            <span class="ct-course-desc"><?php echo esc_html($co['desc']); ?></span>
          </div>
          <?php endforeach; ?>
        </div>
        <div class="ct-menu-footer">
          <div>
            <div class="ct-menu-price"><?php echo esc_html($mn['price']); ?></div>
            <div class="ct-menu-ppx">per person</div>
          </div>
          <a href="#enquiry" class="ct-btn ct-btn-primary" style="padding:10px 22px;font-size:.78rem;">Enquire</a>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- PROCESS -->
<section class="ct-process ct-section" id="process">
  <div class="ct-container">
    <div class="ct-section-header">
      <span class="ct-tag">How It Works</span>
      <h2 class="ct-heading">From Vision to <em>Feast</em></h2>
      <p class="ct-lead">Our four-step consultation process ensures every element of your event is considered, crafted, and flawlessly executed.</p>
    </div>
    <div class="ct-process-steps">
      <?php
      $steps = [
        ['n'=>'01','title'=>'Initial Consultation','desc'=>'We meet to understand your vision, guest profile, venue, and any dietary requirements.'],
        ['n'=>'02','title'=>'Menu Design',          'desc'=>'Our chef composes a bespoke menu tailored to your occasion, season, and palate.'],
        ['n'=>'03','title'=>'Tasting Session',      'desc'=>'A private tasting at our Belgravia kitchen to refine and confirm every course.'],
        ['n'=>'04','title'=>'Flawless Execution',   'desc'=>'Our full brigade and service team delivers an impeccable experience from arrival to final course.'],
      ];
      foreach ($steps as $stp):?>
      <div class="ct-process-step">
        <div class="ct-step-num"><?php echo esc_html($stp['n']); ?></div>
        <h3 class="ct-step-title"><?php echo esc_html($stp['title']); ?></h3>
        <p class="ct-step-desc"><?php echo esc_html($stp['desc']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- PACKAGES -->
<section class="ct-packages ct-section" id="packages">
  <div class="ct-container">
    <div class="ct-section-header">
      <span class="ct-tag">Packages</span>
      <h2 class="ct-heading">Catering <em>Packages</em></h2>
      <p class="ct-lead">All packages include our full brigade, front-of-house team, equipment, and post-event clean-up. Menu consultation included.</p>
    </div>
    <div class="ct-packages-grid">
      <?php
      $packages = [
        [
          'name'     => 'The Gathering',
          'price'    => '£95',
          'unit'     => 'per person · min. 20',
          'featured' => false,
          'badge'    => '',
          'features' => [
            'Canapé & reception service (1.5hrs)',
            'Three-course seated dinner',
            'Sommelier wine pairing',
            'Front-of-house service team',
            'Equipment & linen hire',
            'Post-event clean-down',
          ],
        ],
        [
          'name'     => 'The Celebration',
          'price'    => '£150',
          'unit'     => 'per person · min. 30',
          'featured' => true,
          'badge'    => 'Most Popular',
          'features' => [
            'Champagne arrival reception',
            'Five-course tasting menu',
            'Paired fine wines & digestifs',
            'Head chef attendance',
            'Dedicated event manager',
            'Full equipment & furniture hire',
            'Post-event clean-down',
          ],
        ],
        [
          'name'     => 'The Prestige',
          'price'    => '£240',
          'unit'     => 'per person · min. 20',
          'featured' => false,
          'badge'    => '',
          'features' => [
            'Bespoke multi-day consultation',
            'Seven-course grand tasting menu',
            'Signature live stations',
            'Private sommelier & bar team',
            'Full furniture & décor hire',
            'On-site chef\'s kitchen setup',
            'Overnight preparation support',
          ],
        ],
      ];
      foreach ($packages as $pkg):?>
      <div class="ct-package-card<?php echo $pkg['featured'] ? ' featured' : ''; ?>">
        <?php if ($pkg['badge']): ?>
        <div class="ct-pkg-badge"><?php echo esc_html($pkg['badge']); ?></div>
        <?php endif; ?>
        <div class="ct-pkg-name"><?php echo esc_html($pkg['name']); ?></div>
        <div class="ct-pkg-price"><?php echo esc_html($pkg['price']); ?></div>
        <div class="ct-pkg-unit"><?php echo esc_html($pkg['unit']); ?></div>
        <div class="ct-pkg-divider"></div>
        <ul class="ct-pkg-features">
          <?php foreach ($pkg['features'] as $feat): ?>
          <li><?php echo esc_html($feat); ?></li>
          <?php endforeach; ?>
        </ul>
        <a href="#enquiry" class="ct-btn <?php echo $pkg['featured'] ? 'ct-btn-primary' : 'ct-btn-outline'; ?>" style="width:100%;text-align:center;<?php echo !$pkg['featured'] ? 'border-color:var(--ct-saffron);color:var(--ct-saffron);' : ''; ?>">Enquire Now</a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- CHEF FIGURES -->
<section class="ct-chefs-section">
  <div class="ct-container">
    <div class="ct-section-header">
      <span class="ct-tag">Our Brigade</span>
      <h2 class="ct-heading">The <em>Team</em> Behind Your Table</h2>
      <p class="ct-lead" style="margin:16px auto 0;">Our award-winning brigade brings together decades of experience from some of Europe's finest kitchens.</p>
    </div>
    <div class="ct-chefs-row">
      <?php
      $chefs = [
        ['name'=>'Antoine Saffron',   'role'=>'Head Chef & Founder'],
        ['name'=>'Isabelle Laurent',   'role'=>'Pastry Chef'],
        ['name'=>'Marcus Chen',        'role'=>'Sous Chef'],
        ['name'=>'Priya Kapoor',       'role'=>'Private Dining Chef'],
      ];
      foreach ($chefs as $ch):?>
      <div class="ct-chef-figure">
        <div class="ct-chef-toque"></div>
        <div class="ct-chef-head"></div>
        <div class="ct-chef-neck"></div>
        <div class="ct-chef-jacket" style="position:relative;">
          <div class="ct-chef-arm-l"></div>
          <div class="ct-chef-arm-r"></div>
          <div class="ct-chef-apron"></div>
        </div>
        <div class="ct-chef-legs">
          <div class="ct-chef-leg-l"></div>
          <div class="ct-chef-leg-r"></div>
        </div>
        <div class="ct-chef-name"><?php echo esc_html($ch['name']); ?></div>
        <div class="ct-chef-role"><?php echo esc_html($ch['role']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="ct-testimonials ct-section">
  <div class="ct-container">
    <div class="ct-section-header">
      <span class="ct-tag">Client Stories</span>
      <h2 class="ct-heading">Words From <em>Our Guests</em></h2>
    </div>
    <div class="ct-testi-grid">
      <?php
      $testis = [
        ['text'=>'Saffron & Stone transformed our wedding reception into something utterly magical. Every course drew gasps from our guests — the Wellington alone was worth every penny.','author'=>'Victoria & James Hargreaves','event'=>'Wedding Dinner · 180 Guests · Cotswolds Manor'],
        ['text'=>'We\'ve used many caterers for our corporate gala over the years, but nothing has ever compared to this. Antoine\'s team handled 400 guests with the quiet efficiency of a Swiss watch.','author'=>'Richard Ashworth','event'=>'Annual Gala · 400 Guests · The Guildhall'],
        ['text'=>'Hosting a private chef\'s table at home felt completely out of reach until we found Saffron & Stone. The seven-course menu was stunning — we\'re already planning the next one.','author'=>'Claudia Mendes-Fonseca','event'=>'Private Dining · 12 Guests · Chelsea'],
      ];
      foreach ($testis as $tt):?>
      <div class="ct-testi-card">
        <div class="ct-testi-stars">★★★★★</div>
        <p class="ct-testi-text"><?php echo esc_html($tt['text']); ?></p>
        <div class="ct-testi-author"><?php echo esc_html($tt['author']); ?></div>
        <div class="ct-testi-event"><?php echo esc_html($tt['event']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- FAQ -->
<section class="ct-faq ct-section">
  <div class="ct-container">
    <div class="ct-section-header">
      <span class="ct-tag">Questions</span>
      <h2 class="ct-heading">Frequently <em>Asked</em></h2>
    </div>
    <div class="ct-faq-grid">
      <div class="ct-faq-list">
        <?php
        $faqs = [
          ['q'=>'How far in advance should I book?','a'=>'We recommend booking at least 3–6 months ahead for weddings and large events, and 4–6 weeks for private dining. We do accommodate shorter lead times for smaller events subject to availability.'],
          ['q'=>'Do you cater outside London?','a'=>'Yes — we regularly travel across the UK and Europe. Travel and accommodation costs are quoted separately for events outside a 30-mile radius of our Belgravia base.'],
          ['q'=>'Can you accommodate dietary requirements?','a'=>'Absolutely. Every menu is designed with your guests\' requirements in mind. We cater for vegetarian, vegan, gluten-free, halal, kosher, and all common allergens.'],
          ['q'=>'Is a private tasting included?','a'=>'Tasting sessions are included for all Celebration and Prestige package bookings. For smaller or bespoke packages, tastings can be arranged at our Belgravia kitchen for a nominal fee applied against your booking.'],
          ['q'=>'What does your service team include?','a'=>'All packages include our front-of-house team: event manager, head server, and waiting staff scaled to guest numbers — typically one server per 10–12 guests.'],
        ];
        foreach ($faqs as $fi => $faq):?>
        <div class="ct-faq-item" data-faq="<?php echo $fi; ?>">
          <div class="ct-faq-q" aria-expanded="false" role="button" tabindex="0">
            <?php echo esc_html($faq['q']); ?>
            <span class="ct-faq-icon">+</span>
          </div>
          <div class="ct-faq-a" role="region">
            <div class="ct-faq-a-inner"><?php echo esc_html($faq['a']); ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <div class="ct-faq-cta">
        <h3>A question not answered here?</h3>
        <p>Our team is delighted to discuss your event in detail. Reach us directly or submit an enquiry and we will respond within one business day.</p>
        <div class="ct-faq-contact">
          <a href="tel:+442071234567">📞 +44 (0)20 7123 4567</a>
          <a href="mailto:hello@saffronstone.co.uk">✉ hello@saffronstone.co.uk</a>
          <a href="#">📍 14 Wilton Place, Belgravia, SW1X 8RL</a>
        </div>
        <a href="#enquiry" class="ct-btn ct-btn-primary">Begin Your Event</a>
      </div>
    </div>
  </div>
</section>

<!-- ENQUIRY FORM -->
<section class="ct-enquiry ct-section" id="enquiry">
  <div class="ct-container">
    <div class="ct-section-header">
      <span class="ct-tag">Get In Touch</span>
      <h2 class="ct-heading">Begin Your <em>Culinary Journey</em></h2>
      <p class="ct-lead" style="margin:16px auto 0;">Complete the form below and one of our event consultants will be in touch within 24 hours to discuss your vision.</p>
    </div>
    <div class="ct-form-wrapper">
      <div class="ct-form-success" id="ct-success">
        <h3>Enquiry Received</h3>
        <p>Thank you — we will be in touch within one business day to begin crafting your event.</p>
      </div>
      <form id="ct-enquiry-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <?php wp_nonce_field('tf_ct_enquiry','tf_ct_nonce'); ?>
        <input type="hidden" name="action" value="tf_ct_enquiry">
        <div class="ct-form-grid">
          <div class="ct-form-group">
            <label for="ct-name">Your Name *</label>
            <input type="text" id="ct-name" name="ct_name" placeholder="Antoine Saffron" required>
          </div>
          <div class="ct-form-group">
            <label for="ct-email">Email Address *</label>
            <input type="email" id="ct-email" name="ct_email" placeholder="hello@yourevent.com" required>
          </div>
          <div class="ct-form-group">
            <label for="ct-phone">Phone Number</label>
            <input type="tel" id="ct-phone" name="ct_phone" placeholder="+44 (0)20 7123 4567">
          </div>
          <div class="ct-form-group">
            <label for="ct-date">Event Date *</label>
            <input type="date" id="ct-date" name="ct_date" required>
          </div>
          <div class="ct-form-group">
            <label for="ct-type">Type of Event *</label>
            <select id="ct-type" name="ct_type" required>
              <option value="">Select event type</option>
              <option value="wedding">Wedding</option>
              <option value="corporate">Corporate Event</option>
              <option value="private">Private Dining</option>
              <option value="reception">Champagne Reception</option>
              <option value="birthday">Birthday / Celebration</option>
              <option value="popup">Pop-Up / Supper Club</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div class="ct-form-group">
            <label for="ct-guests">Guest Count *</label>
            <select id="ct-guests" name="ct_guests" required>
              <option value="">Estimated guest numbers</option>
              <option value="1-20">1 – 20 guests</option>
              <option value="21-50">21 – 50 guests</option>
              <option value="51-100">51 – 100 guests</option>
              <option value="101-200">101 – 200 guests</option>
              <option value="201-500">201 – 500 guests</option>
              <option value="500+">500+ guests</option>
            </select>
          </div>
          <div class="ct-form-group">
            <label for="ct-package">Package Interest</label>
            <select id="ct-package" name="ct_package">
              <option value="">Interested package (optional)</option>
              <option value="gathering">The Gathering — from £95pp</option>
              <option value="celebration">The Celebration — from £150pp</option>
              <option value="prestige">The Prestige — from £240pp</option>
              <option value="bespoke">Bespoke Quotation</option>
            </select>
          </div>
          <div class="ct-form-group">
            <label for="ct-venue">Venue / Location</label>
            <input type="text" id="ct-venue" name="ct_venue" placeholder="Venue name or postcode">
          </div>
          <div class="ct-form-group full">
            <label for="ct-notes">Tell Us About Your Event</label>
            <textarea id="ct-notes" name="ct_notes" placeholder="Please share any details about your vision, theme, dietary requirements, or anything else that would help us prepare for our consultation…"></textarea>
          </div>
        </div>
        <div class="ct-form-actions">
          <button type="submit" class="ct-btn ct-btn-primary">Send Enquiry</button>
          <p class="ct-form-note">We respond within one business day. All enquiries are treated with complete discretion.</p>
        </div>
      </form>
    </div>
  </div>
</section>

<!-- FOOTER -->
<footer class="ct-footer">
  <div class="ct-container">
    <div class="ct-footer-inner">
      <div class="ct-footer-brand">
        <h3>Saffron & Stone</h3>
        <span>Fine Event Catering · Est. 1998</span>
        <p>Luxury event catering and private chef experiences from our Belgravia kitchen. Michelin-level cuisine for every occasion.</p>
      </div>
      <div class="ct-footer-col">
        <h4>Services</h4>
        <ul>
          <li><a href="#">Wedding Catering</a></li>
          <li><a href="#">Corporate Events</a></li>
          <li><a href="#">Private Dining</a></li>
          <li><a href="#">Champagne Receptions</a></li>
          <li><a href="#">Supper Clubs</a></li>
        </ul>
      </div>
      <div class="ct-footer-col">
        <h4>Contact</h4>
        <ul>
          <li><a href="tel:+442071234567">+44 (0)20 7123 4567</a></li>
          <li><a href="mailto:hello@saffronstone.co.uk">hello@saffronstone.co.uk</a></li>
          <li><a href="#">14 Wilton Place</a></li>
          <li><a href="#">Belgravia, SW1X 8RL</a></li>
        </ul>
      </div>
    </div>
    <div class="ct-footer-bottom">
      <p>© <?php echo date('Y'); ?> Saffron & Stone Catering Ltd. All rights reserved.</p>
      <a href="#">Privacy Policy</a>
    </div>
  </div>
</footer>

<script>
(function(){
  // ---- FAQ Accordion ----
  document.querySelectorAll('.ct-faq-q').forEach(function(btn){
    btn.addEventListener('click', function(){
      var item = this.closest('.ct-faq-item');
      var isOpen = item.classList.contains('open');
      document.querySelectorAll('.ct-faq-item.open').forEach(function(o){
        o.classList.remove('open');
        o.querySelector('.ct-faq-q').setAttribute('aria-expanded','false');
      });
      if(!isOpen){
        item.classList.add('open');
        this.setAttribute('aria-expanded','true');
      }
    });
    btn.addEventListener('keydown', function(e){
      if(e.key==='Enter'||e.key===' '){e.preventDefault();this.click();}
    });
  });

  // ---- Animated counters ----
  var counters = document.querySelectorAll('.ct-stat-number');
  var easeOut  = function(t){ return 1 - Math.pow(1-t,3); };
  var obs = new IntersectionObserver(function(entries){
    entries.forEach(function(entry){
      if(!entry.isIntersecting) return;
      var el  = entry.target;
      var raw = el.getAttribute('data-target')||'';
      var num = parseFloat(raw.replace(/[^0-9.]/g,''));
      if(isNaN(num)){ obs.unobserve(el); return; }
      var isFloat   = raw.indexOf('.')!==-1;
      var suffix    = raw.replace(/[0-9.,]/g,'');
      var prefix    = '';
      if(raw.indexOf('£')!==-1){ prefix='£'; }
      var duration  = 1400;
      var startTime = null;
      function tick(now){
        if(!startTime) startTime = now;
        var p = Math.min((now-startTime)/duration, 1);
        var v = easeOut(p) * num;
        var display = isFloat ? v.toFixed(1) : Math.floor(v).toLocaleString();
        el.textContent = prefix + display + suffix;
        if(p < 1) requestAnimationFrame(tick);
        else el.textContent = raw;
      }
      requestAnimationFrame(tick);
      obs.unobserve(el);
    });
  },{threshold:.4});
  counters.forEach(function(c){ obs.observe(c); });

  // ---- Form submit ----
  var form    = document.getElementById('ct-enquiry-form');
  var success = document.getElementById('ct-success');
  if(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      form.style.display = 'none';
      success.style.display = 'block';
    });
  }
})();
</script>
</body>
</html>
</div><!-- .page-template-page-caterer -->
<?php get_footer(); ?>
