<?php
/**
 * Template Name: Celebrant — Wedding / Naming / Funeral
 *
 * Premium landing page for a professional celebrant.
 * Hero: CSS ceremony arch scene — flower arch, couple silhouettes, confetti, celebrant figure.
 * Namespace: --cb-* | Fonts: Playfair Display + Josefin Sans | Palette: gold/rose/ivory/navy
 *
 * @package ThemeFlex
 */

get_header(); ?>

<style>
/* ── Fonts ─────────────────────────────────────────────────── */
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=Josefin+Sans:wght@300;400;500;600&display=swap');

/* ── Token System ───────────────────────────────────────────── */
:root {
  --cb-gold:    #C9A84C;
  --cb-gold-lt: #E2C97E;
  --cb-gold-dk: #8B6914;
  --cb-rose:    #C2677E;
  --cb-rose-lt: #E8A0B2;
  --cb-rose-lx: #FAEEF1;
  --cb-navy:    #1E2D4A;
  --cb-navy-lt: #2E4270;
  --cb-ivory:   #FAF7F0;
  --cb-cream:   #F5F0E8;
  --cb-white:   #FFFFFF;
  --cb-text:    #1A1520;
  --cb-text-lt: #5A505A;
  --cb-shadow:  rgba(26,21,32,0.13);

  --cb-r:    8px;
  --cb-r-lg: 16px;
  --cb-r-xl: 24px;

  --ff-serif: 'Playfair Display', Georgia, serif;
  --ff-sans:  'Josefin Sans', system-ui, sans-serif;
}

/* ── Reset ─────────────────────────────────────────────────── */
.cb-page *, .cb-page *::before, .cb-page *::after { box-sizing: border-box; margin: 0; padding: 0; }
.cb-page { font-family: var(--ff-sans); color: var(--cb-text); background: var(--cb-ivory); overflow-x: hidden; }
.cb-page a { color: inherit; text-decoration: none; }

/* ── Layout ─────────────────────────────────────────────────── */
.cb-wrap    { max-width: 1140px; margin: 0 auto; padding: 0 24px; }
.cb-section { padding: 80px 0; }
.cb-section--alt { background: var(--cb-white); }

/* ── Typography ─────────────────────────────────────────────── */
.cb-eyebrow {
  font-family: var(--ff-sans); font-size: .72rem; font-weight: 600;
  letter-spacing: .16em; text-transform: uppercase; color: var(--cb-gold); margin-bottom: 10px;
}
.cb-h1 { font-family: var(--ff-serif); font-size: clamp(2.6rem,5.5vw,4rem); font-weight: 700; line-height: 1.15; }
.cb-h2 { font-family: var(--ff-serif); font-size: clamp(1.9rem,3.5vw,2.9rem); font-weight: 600; line-height: 1.2; margin-bottom: 16px; }
.cb-h3 { font-family: var(--ff-serif); font-size: 1.3rem; font-weight: 600; margin-bottom: 8px; }
.cb-lead { font-size: 1.05rem; line-height: 1.8; color: var(--cb-text-lt); }

/* ── Ornament divider ── */
.cb-ornament { text-align: center; font-size: 1.4rem; color: var(--cb-gold); margin: 12px 0; letter-spacing: .2em; }

/* ── Buttons ─────────────────────────────────────────────────── */
.cb-btn {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 14px 32px; border-radius: 50px; font-family: var(--ff-sans);
  font-size: .92rem; font-weight: 600; letter-spacing: .06em;
  cursor: pointer; transition: transform .2s, box-shadow .2s; border: none;
}
.cb-btn--primary {
  background: var(--cb-gold); color: var(--cb-white);
  box-shadow: 0 4px 18px rgba(201,168,76,.4);
}
.cb-btn--primary:hover { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(201,168,76,.55); }
.cb-btn--rose {
  background: var(--cb-rose); color: var(--cb-white);
  box-shadow: 0 4px 18px rgba(194,103,126,.35);
}
.cb-btn--rose:hover { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(194,103,126,.5); }
.cb-btn--outline {
  background: transparent; color: var(--cb-white);
  border: 2px solid rgba(255,255,255,.65);
}
.cb-btn--outline:hover { background: rgba(255,255,255,.12); transform: translateY(-2px); }

/* ============================================================
   HERO — CEREMONY ARCH SCENE
   ============================================================ */
.cb-hero {
  position: relative; overflow: hidden;
  min-height: 100vh; display: flex; align-items: center;
  background: linear-gradient(160deg,
    #1E2D4A 0%,
    #2E4270 30%,
    #6B3D5A 65%,
    #C2677E 100%
  );
}

/* ── Sky / bokeh ── */
.cb-bokeh {
  position: absolute; border-radius: 50%; filter: blur(50px); opacity: .2;
}
.cb-bokeh--1 { width: 300px; height: 300px; top: 5%;  right: 10%; background: var(--cb-gold); }
.cb-bokeh--2 { width: 200px; height: 200px; bottom: 15%; left: 5%;  background: var(--cb-rose); }
.cb-bokeh--3 { width: 160px; height: 160px; top: 40%; right: 30%; background: #FFD9E8; }

/* ── Confetti pieces ── */
.cb-confetti {
  position: absolute; border-radius: 2px;
  animation: cb-confetti-fall linear infinite;
}
@keyframes cb-confetti-fall {
  from { transform: translateY(-20px) rotate(0deg); opacity: 1; }
  to   { transform: translateY(110vh) rotate(720deg); opacity: 0; }
}

/* ── Wedding arch ── */
.cb-arch {
  position: absolute; right: 10%; top: 50%;
  transform: translateY(-50%);
  width: 200px;
}
/* Arch pillars */
.cb-arch__pillar-l, .cb-arch__pillar-r {
  position: absolute; width: 18px; border-radius: 9px 9px 0 0;
  background: linear-gradient(180deg, #F5E6D3, #D7C4B0);
  box-shadow: 2px 0 8px rgba(0,0,0,.2);
  bottom: 0; height: 240px;
}
.cb-arch__pillar-l { left: 10px; }
.cb-arch__pillar-r { right: 10px; }

/* Arch curve */
.cb-arch__curve {
  position: absolute; top: 0; left: 10px; right: 10px; height: 120px;
  border: 18px solid #F5E6D3;
  border-bottom: none;
  border-radius: 90px 90px 0 0;
  box-shadow: 2px -2px 12px rgba(0,0,0,.15);
}

/* Flower clusters on arch */
.cb-arch-flowers {
  position: absolute; display: flex; flex-wrap: wrap; gap: 5px;
}
.cb-arch-flowers--top {
  top: -20px; left: -20px; right: -20px;
  justify-content: center;
}
.cb-arch-flowers--left  { left: -15px; top: 30px; flex-direction: column; }
.cb-arch-flowers--right { right: -15px; top: 30px; flex-direction: column; }

.cb-arch-flower {
  width: 22px; height: 22px; border-radius: 50%;
  position: relative;
  box-shadow: 0 2px 4px rgba(0,0,0,.2);
}
.cb-arch-flower::before, .cb-arch-flower::after {
  content:''; position: absolute; border-radius: 50%;
  width: 10px; height: 10px;
  background: rgba(255,255,255,.5);
}
.cb-arch-flower::before { top: 0; left: 50%; transform: translateX(-50%); }
.cb-arch-flower::after  { bottom: 0; left: 50%; transform: translateX(-50%); }

/* Flower colour variants */
.cb-af--pink   { background: radial-gradient(circle at 35% 35%, #F8BBD0, var(--cb-rose)); }
.cb-af--cream  { background: radial-gradient(circle at 35% 35%, #FFFFFF, #F5E6D3); }
.cb-af--gold   { background: radial-gradient(circle at 35% 35%, #FFF9C4, var(--cb-gold)); }
.cb-af--white  { background: radial-gradient(circle at 35% 35%, #FFFFFF, #F0F0F0); }
.cb-af--blush  { background: radial-gradient(circle at 35% 35%, #FCE4EC, #F48FB1); }

/* Leaves interspersed */
.cb-af-leaf {
  width: 16px; height: 10px; border-radius: 50% 0;
  background: linear-gradient(135deg, #81C784, #2E7D32);
}

/* Ground base */
.cb-arch__base {
  position: absolute; bottom: -12px; left: -20px; right: -20px;
  height: 16px; border-radius: 50%;
  background: rgba(255,255,255,.15);
}

/* ── Couple silhouettes ── */
.cb-couple {
  position: absolute; bottom: calc(50% - 120px); right: calc(10% + 55px);
  display: flex; gap: 12px; align-items: flex-end;
}
/* Person 1 (taller) */
.cb-person--1, .cb-person--2 {
  display: flex; flex-direction: column; align-items: center;
}
.cb-person__head { border-radius: 50%; }
.cb-person__body { border-radius: 4px 4px 0 0; }

.cb-person--1 .cb-person__head { width: 22px; height: 22px; background: rgba(255,255,255,.85); }
.cb-person--1 .cb-person__body { width: 28px; height: 60px; background: rgba(255,255,255,.75); margin-top: -2px; clip-path: polygon(0 0,100% 0,90% 100%,10% 100%); }

.cb-person--2 .cb-person__head { width: 20px; height: 20px; background: rgba(255,255,255,.9); }
.cb-person--2 .cb-person__body {
  width: 36px; height: 52px;
  background: rgba(255,255,255,.85); margin-top: -2px;
  clip-path: polygon(0 0,100% 0,100% 60%,60% 100%,40% 100%,0 60%); /* dress silhouette */
}

/* ── Celebrant figure ── */
.cb-celebrant-fig {
  position: absolute; bottom: calc(50% - 120px); right: calc(10% + 20px);
  display: flex; flex-direction: column; align-items: center;
}
.cb-celebrant-fig__head { width: 20px; height: 22px; border-radius: 50%; background: #FFE0B2; }
.cb-celebrant-fig__body {
  width: 26px; height: 44px; border-radius: 4px 4px 0 0;
  background: linear-gradient(180deg,#37474F,#263238); margin-top: -2px; position: relative;
}
/* Book/script held up */
.cb-celebrant-fig__book {
  position: absolute; top: 4px; left: -16px;
  width: 18px; height: 22px; border-radius: 2px;
  background: var(--cb-ivory); border: 2px solid #BDBDBD;
}
.cb-celebrant-fig__legs { display: flex; gap: 4px; }
.cb-celebrant-fig__leg  { width: 11px; height: 20px; border-radius: 0 0 4px 4px; background: #263238; }

/* ── Hero content ── */
.cb-hero__inner {
  position: relative; z-index: 10;
  max-width: 580px; padding: 40px 24px 40px 60px;
}
.cb-hero__script {
  font-family: var(--ff-serif); font-size: 1.05rem; font-style: italic;
  color: var(--cb-gold-lt); margin-bottom: 14px; display: block;
}
.cb-hero__title { color: var(--cb-white); text-shadow: 0 2px 20px rgba(0,0,0,.45); margin-bottom: 18px; }
.cb-hero__sub   { font-size: 1.1rem; color: rgba(255,255,255,.88); line-height: 1.75; margin-bottom: 30px; }
.cb-hero__ctas  { display: flex; gap: 14px; flex-wrap: wrap; }

/* ceremony type pills */
.cb-ceremony-pills {
  display: flex; flex-wrap: wrap; gap: 8px; margin-top: 24px;
}
.cb-ceremony-pill {
  background: rgba(255,255,255,.12); border: 1px solid rgba(255,255,255,.25);
  color: rgba(255,255,255,.85); border-radius: 50px;
  font-size: .78rem; font-weight: 600; padding: 5px 14px; letter-spacing: .06em;
}

/* ============================================================
   STATS
   ============================================================ */
.cb-stats { background: var(--cb-navy); padding: 40px 0; }
.cb-stats__grid { display: grid; grid-template-columns: repeat(4,1fr); }
.cb-stat {
  text-align: center; padding: 16px;
  border-right: 1px solid rgba(255,255,255,.1);
}
.cb-stat:last-child { border-right: none; }
.cb-stat__number { font-family: var(--ff-serif); font-size: 2.6rem; font-weight: 700; color: var(--cb-gold-lt); line-height: 1; }
.cb-stat__label  { font-size: .82rem; color: rgba(255,255,255,.65); margin-top: 6px; }

/* ============================================================
   ABOUT
   ============================================================ */
.cb-about__grid { display: grid; grid-template-columns: 1fr 1fr; gap: 64px; align-items: center; }
.cb-about__visual {
  position: relative; height: 460px; border-radius: var(--cb-r-xl);
  overflow: hidden; box-shadow: 0 12px 48px var(--cb-shadow);
  background: linear-gradient(145deg, #FAF0F3, #F5E6EC);
}
/* Gold ring decoration */
.cb-ring {
  position: absolute; border-radius: 50%;
  border: 6px solid var(--cb-gold);
  opacity: .3;
}
.cb-ring--1 { width: 140px; height: 140px; top: 20%; left: 20%; }
.cb-ring--2 { width: 100px; height: 100px; top: 25%; left: 28%; }
/* Overlapping = interlocked rings */
.cb-rings-visual {
  position: absolute; top: 50%; left: 50%; transform: translate(-50%,-60%);
}
.cb-ring-large {
  width: 140px; height: 140px; border-radius: 50%;
  border: 12px solid var(--cb-gold); display: inline-block;
  box-shadow: 0 4px 16px rgba(201,168,76,.3);
}
.cb-ring-large--2 {
  margin-left: -50px;
  border-color: var(--cb-rose);
  box-shadow: 0 4px 16px rgba(194,103,126,.3);
}

.cb-about__badge {
  position: absolute; bottom: 16px; left: 16px; right: 16px;
  background: var(--cb-navy); color: var(--cb-white);
  border-radius: var(--cb-r-lg); padding: 12px 18px;
}
.cb-about__badge-name { font-family: var(--ff-serif); font-size: 1.2rem; font-weight: 600; margin-bottom: 4px; }
.cb-about__badge-cred { font-size: .78rem; color: rgba(255,255,255,.7); }
.cb-about__cert {
  position: absolute; top: 14px; right: 14px;
  background: var(--cb-white); border-radius: var(--cb-r);
  padding: 8px 12px; font-size: .78rem; font-weight: 600; color: var(--cb-gold-dk);
  box-shadow: 0 2px 10px var(--cb-shadow);
}

.cb-about__full-name { font-family: var(--ff-serif); font-size: 2rem; font-weight: 700; margin: 12px 0 6px; }
.cb-about__credential {
  display: inline-block; background: var(--cb-rose-lx); color: var(--cb-rose);
  border-radius: 50px; font-size: .78rem; font-weight: 600; padding: 4px 14px; margin-bottom: 18px;
}
.cb-about__body { font-size: 1.02rem; line-height: 1.82; color: var(--cb-text-lt); margin-bottom: 16px; }
.cb-about__quals { list-style: none; margin-bottom: 28px; }
.cb-about__quals li {
  padding: 8px 0 8px 26px; border-bottom: 1px solid #EEE;
  font-size: .93rem; color: var(--cb-text-lt); position: relative;
}
.cb-about__quals li::before { content: '✦'; position: absolute; left: 0; top: 8px; color: var(--cb-gold); font-size: .8rem; }

/* ============================================================
   CEREMONY TYPES
   ============================================================ */
.cb-ceremonies { background: var(--cb-navy); padding: 80px 0; }
.cb-ceremonies .cb-eyebrow { color: var(--cb-gold-lt); }
.cb-ceremonies .cb-h2 { color: var(--cb-white); }
.cb-ceremonies__grid { display: grid; grid-template-columns: repeat(auto-fit,minmax(260px,1fr)); gap: 24px; margin-top: 40px; }

.cb-ceremony-card {
  border-radius: var(--cb-r-xl); overflow: hidden;
  background: rgba(255,255,255,.07); border: 1px solid rgba(255,255,255,.12);
  backdrop-filter: blur(8px); transition: background .2s, transform .25s;
}
.cb-ceremony-card:hover { background: rgba(255,255,255,.13); transform: translateY(-4px); }

.cb-ceremony-card__header {
  padding: 24px; border-bottom: 1px solid rgba(255,255,255,.1);
}
.cb-ceremony-card__icon   { font-size: 2.2rem; margin-bottom: 10px; display: block; }
.cb-ceremony-card__title  { font-family: var(--ff-serif); font-size: 1.4rem; font-weight: 600; color: var(--cb-white); margin-bottom: 4px; }
.cb-ceremony-card__sub    { font-size: .82rem; color: var(--cb-gold-lt); }
.cb-ceremony-card__body   { padding: 20px 24px 26px; }
.cb-ceremony-card__desc   { font-size: .92rem; line-height: 1.65; color: rgba(255,255,255,.72); margin-bottom: 16px; }
.cb-ceremony-card__feats  { list-style: none; }
.cb-ceremony-card__feats li {
  font-size: .85rem; color: rgba(255,255,255,.6); padding: 4px 0 4px 20px; position: relative;
}
.cb-ceremony-card__feats li::before { content:'✦'; position: absolute; left: 0; color: var(--cb-gold-lt); font-size: .7rem; top: 5px; }

/* ============================================================
   PROCESS
   ============================================================ */
.cb-process__steps { display: grid; grid-template-columns: repeat(5,1fr); gap: 0; margin-top: 48px; position: relative; }
.cb-process__steps::before {
  content:''; position: absolute;
  top: 32px; left: 10%; right: 10%; height: 2px;
  background: linear-gradient(90deg, var(--cb-gold), var(--cb-rose));
  z-index: 0;
}
.cb-step { text-align: center; position: relative; z-index: 1; padding: 0 10px; }
.cb-step__num {
  width: 64px; height: 64px; border-radius: 50%;
  background: linear-gradient(135deg, var(--cb-gold), var(--cb-gold-dk));
  color: var(--cb-white);
  font-family: var(--ff-serif); font-size: 1.5rem; font-weight: 700;
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto 16px; box-shadow: 0 4px 16px rgba(201,168,76,.4);
}
.cb-step__title { font-family: var(--ff-serif); font-size: 1rem; font-weight: 600; margin-bottom: 6px; }
.cb-step__desc  { font-size: .82rem; line-height: 1.55; color: var(--cb-text-lt); }

/* ============================================================
   PACKAGES
   ============================================================ */
.cb-packages__grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 28px; margin-top: 48px; align-items: start; }
.cb-pkg {
  border-radius: var(--cb-r-xl); overflow: hidden;
  box-shadow: 0 6px 28px var(--cb-shadow); background: var(--cb-white);
  transition: transform .25s;
}
.cb-pkg:hover { transform: translateY(-4px); }
.cb-pkg--featured { transform: scale(1.04); box-shadow: 0 12px 48px rgba(201,168,76,.35); }
.cb-pkg--featured:hover { transform: scale(1.04) translateY(-4px); }

.cb-pkg__header { padding: 28px 28px 20px; text-align: center; }
.cb-pkg--elopement .cb-pkg__header { background: linear-gradient(135deg, var(--cb-rose-lt), var(--cb-rose)); }
.cb-pkg--featured  .cb-pkg__header { background: linear-gradient(135deg, var(--cb-gold-lt), var(--cb-gold-dk)); }
.cb-pkg--full      .cb-pkg__header { background: linear-gradient(135deg, var(--cb-navy-lt), var(--cb-navy)); }

.cb-pkg__badge { display: inline-block; background: rgba(255,255,255,.95); color: var(--cb-gold-dk); border-radius: 50px; font-size: .72rem; font-weight: 700; padding: 3px 12px; margin-bottom: 10px; letter-spacing: .08em; text-transform: uppercase; }
.cb-pkg__name  { font-family: var(--ff-serif); font-size: 1.5rem; font-weight: 700; color: var(--cb-white); }
.cb-pkg__price { font-family: var(--ff-serif); font-size: 2.4rem; font-weight: 700; color: var(--cb-white); margin: 12px 0 4px; }
.cb-pkg__unit  { font-size: .82rem; color: rgba(255,255,255,.75); }

.cb-pkg__body { padding: 24px 28px 28px; }
.cb-pkg__desc { font-size: .92rem; color: var(--cb-text-lt); margin-bottom: 18px; line-height: 1.6; }
.cb-pkg__features { list-style: none; margin-bottom: 24px; }
.cb-pkg__features li { padding: 6px 0 6px 26px; position: relative; font-size: .9rem; color: var(--cb-text-lt); border-bottom: 1px solid #F5F0EA; }
.cb-pkg__features li::before { content:'✦'; position: absolute; left: 0; color: var(--cb-gold); font-size: .75rem; top: 7px; }
.cb-pkg__cta { display: block; text-align: center; padding: 13px; border-radius: 50px; font-family: var(--ff-sans); font-size: .92rem; font-weight: 600; cursor: pointer; border: none; transition: opacity .2s; color: var(--cb-white); letter-spacing: .06em; }
.cb-pkg--elopement .cb-pkg__cta { background: var(--cb-rose); }
.cb-pkg--featured  .cb-pkg__cta { background: var(--cb-gold); }
.cb-pkg--full      .cb-pkg__cta { background: var(--cb-navy); }
.cb-pkg__cta:hover { opacity: .88; }

/* ============================================================
   TESTIMONIALS
   ============================================================ */
.cb-testimonials { background: var(--cb-cream); }
.cb-testimonials__grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; margin-top: 40px; }
.cb-testi {
  background: var(--cb-white); border-radius: var(--cb-r-lg);
  padding: 28px; box-shadow: 0 4px 20px var(--cb-shadow);
  position: relative;
}
.cb-testi::before {
  content: '❝'; position: absolute; top: 12px; left: 20px;
  font-size: 3rem; color: var(--cb-gold-lt); line-height: 1; opacity: .5;
}
.cb-testi__stars  { color: var(--cb-gold); font-size: 1rem; margin-bottom: 12px; }
.cb-testi__quote  { font-family: var(--ff-serif); font-size: 1.02rem; font-style: italic; line-height: 1.78; color: var(--cb-text-lt); margin-bottom: 16px; padding-top: 20px; }
.cb-testi__author { font-weight: 600; font-size: .9rem; }
.cb-testi__meta   { font-size: .82rem; color: var(--cb-text-lt); }

/* ============================================================
   FAQs
   ============================================================ */
.cb-faqs__list { max-width: 780px; margin: 40px auto 0; }
.cb-faq { border-bottom: 1px solid #EDE8E0; }
.cb-faq__q {
  width: 100%; background: none; border: none; cursor: pointer;
  display: flex; justify-content: space-between; align-items: center;
  padding: 20px 0; font-family: var(--ff-serif); font-size: 1.1rem;
  font-weight: 600; color: var(--cb-text); text-align: left; gap: 16px;
}
.cb-faq__icon { font-size: 1.4rem; color: var(--cb-gold); transition: transform .3s; flex-shrink: 0; }
.cb-faq__q[aria-expanded="true"] .cb-faq__icon { transform: rotate(45deg); }
.cb-faq__a { display: none; padding: 0 0 20px; font-size: .97rem; line-height: 1.75; color: var(--cb-text-lt); }
.cb-faq__a.is-open { display: block; }

/* ============================================================
   BOOKING FORM
   ============================================================ */
.cb-booking { background: linear-gradient(145deg, var(--cb-navy), #3A2550); padding: 80px 0; }
.cb-booking .cb-eyebrow { color: var(--cb-gold-lt); }
.cb-booking .cb-h2  { color: var(--cb-white); }
.cb-booking .cb-lead { color: rgba(255,255,255,.78); }

.cb-form { background: var(--cb-white); border-radius: var(--cb-r-xl); padding: 48px; margin-top: 40px; box-shadow: 0 12px 48px rgba(0,0,0,.25); }
.cb-form__grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
.cb-form__full { grid-column: 1/-1; }
.cb-label { display: block; font-size: .82rem; font-weight: 600; letter-spacing: .06em; margin-bottom: 6px; color: var(--cb-text-lt); text-transform: uppercase; }
.cb-input, .cb-select, .cb-textarea {
  width: 100%; padding: 12px 16px;
  border: 1.5px solid #DDD; border-radius: var(--cb-r);
  font-family: var(--ff-sans); font-size: .97rem; color: var(--cb-text);
  background: #FAFAFA; transition: border-color .2s;
}
.cb-input:focus, .cb-select:focus, .cb-textarea:focus { outline: none; border-color: var(--cb-gold); background: var(--cb-white); }
.cb-textarea { min-height: 120px; resize: vertical; }
.cb-form__submit { text-align: center; margin-top: 32px; }
.cb-form__note   { text-align: center; font-size: .82rem; color: var(--cb-text-lt); margin-top: 10px; }

/* ============================================================
   FOOTER CTA
   ============================================================ */
.cb-footer-cta {
  background: linear-gradient(135deg, var(--cb-gold-dk) 0%, var(--cb-gold) 100%);
  padding: 60px 0; text-align: center;
}
.cb-footer-cta .cb-h2  { color: var(--cb-white); margin-bottom: 10px; }
.cb-footer-cta .cb-lead { color: rgba(255,255,255,.88); margin-bottom: 28px; }

/* ============================================================
   SCROLL REVEAL
   ============================================================ */
.cb-reveal { opacity: 0; transform: translateY(28px); transition: opacity .65s, transform .65s; }
.cb-reveal.is-visible { opacity: 1; transform: none; }

/* ============================================================
   RESPONSIVE
   ============================================================ */
@media (max-width: 900px) {
  .cb-about__grid    { grid-template-columns: 1fr; }
  .cb-packages__grid { grid-template-columns: 1fr; }
  .cb-pkg--featured  { transform: none; }
  .cb-process__steps { grid-template-columns: repeat(2,1fr); }
  .cb-process__steps::before { display: none; }
  .cb-stats__grid    { grid-template-columns: 1fr 1fr; }
  .cb-testimonials__grid { grid-template-columns: 1fr; }
}
@media (max-width: 600px) {
  .cb-hero__inner { padding: 40px 24px; }
  .cb-form__grid  { grid-template-columns: 1fr; }
  .cb-process__steps { grid-template-columns: 1fr; }
}
</style>

<div class="cb-page">

  <!-- ── HERO ─────────────────────────────────────────────── -->
  <section class="cb-hero" aria-label="Celebrant hero">

    <!-- Bokeh -->
    <div class="cb-bokeh cb-bokeh--1" aria-hidden="true"></div>
    <div class="cb-bokeh cb-bokeh--2" aria-hidden="true"></div>
    <div class="cb-bokeh cb-bokeh--3" aria-hidden="true"></div>

    <!-- Confetti shower -->
    <?php
    srand(crc32('celebrant-confetti'));
    $confetti_colours = ['#C9A84C','#E8A0B2','#FAF7F0','#F48FB1','#FFE082','#CE93D8'];
    for ($i = 0; $i < 30; $i++) {
      $left     = rand(0,100);
      $delay    = rand(0,80)/10;
      $dur      = rand(40,90)/10;
      $size_w   = rand(6,14);
      $size_h   = rand(4,9);
      $colour   = $confetti_colours[array_rand($confetti_colours)];
      echo '<div class="cb-confetti" aria-hidden="true" style="left:'.$left.'%;width:'.$size_w.'px;height:'.$size_h.'px;background:'.$colour.';animation-duration:'.$dur.'s;animation-delay:-'.$delay.'s;"></div>';
    }
    srand();
    ?>

    <!-- Wedding Arch -->
    <div class="cb-arch" aria-hidden="true">
      <!-- Flower clusters -->
      <div class="cb-arch-flowers cb-arch-flowers--top">
        <div class="cb-arch-flower cb-af--pink"></div>
        <div class="cb-arch-flower cb-af--cream"></div>
        <div class="cb-af-leaf"></div>
        <div class="cb-arch-flower cb-af--gold"></div>
        <div class="cb-arch-flower cb-af--white"></div>
        <div class="cb-af-leaf"></div>
        <div class="cb-arch-flower cb-af--blush"></div>
        <div class="cb-arch-flower cb-af--pink"></div>
      </div>
      <div class="cb-arch-flowers cb-arch-flowers--left">
        <div class="cb-arch-flower cb-af--pink"></div>
        <div class="cb-af-leaf"></div>
        <div class="cb-arch-flower cb-af--blush"></div>
        <div class="cb-arch-flower cb-af--cream"></div>
      </div>
      <div class="cb-arch-flowers cb-arch-flowers--right">
        <div class="cb-arch-flower cb-af--gold"></div>
        <div class="cb-af-leaf"></div>
        <div class="cb-arch-flower cb-af--white"></div>
        <div class="cb-arch-flower cb-af--pink"></div>
      </div>
      <!-- Arch structure -->
      <div style="position:relative; height:240px; margin-top:20px;">
        <div class="cb-arch__curve"></div>
        <div class="cb-arch__pillar-l"></div>
        <div class="cb-arch__pillar-r"></div>
      </div>
      <div class="cb-arch__base"></div>
    </div>

    <!-- Couple -->
    <div class="cb-couple" aria-hidden="true">
      <div class="cb-person--1">
        <div class="cb-person__head"></div>
        <div class="cb-person__body"></div>
      </div>
      <div class="cb-person--2">
        <div class="cb-person__head"></div>
        <div class="cb-person__body"></div>
      </div>
    </div>

    <!-- Celebrant with book -->
    <div class="cb-celebrant-fig" aria-hidden="true">
      <div class="cb-celebrant-fig__head"></div>
      <div class="cb-celebrant-fig__body">
        <div class="cb-celebrant-fig__book"></div>
      </div>
      <div class="cb-celebrant-fig__legs">
        <div class="cb-celebrant-fig__leg"></div>
        <div class="cb-celebrant-fig__leg"></div>
      </div>
    </div>

    <!-- Hero copy -->
    <div class="cb-hero__inner">
      <em class="cb-hero__script">Ceremonies that tell your story</em>
      <h1 class="cb-h1 cb-hero__title">
        Your Ceremony.<br>Your Words.<br><span style="color:var(--cb-gold-lt);">Perfectly Yours.</span>
      </h1>
      <p class="cb-hero__sub">Award-winning, fully personalised ceremonies for weddings, civil partnerships, naming days, vow renewals, and life tributes — across England &amp; Wales.</p>
      <div class="cb-hero__ctas">
        <a href="#booking" class="cb-btn cb-btn--primary">✦ Begin Your Ceremony</a>
        <a href="#ceremonies" class="cb-btn cb-btn--outline">Explore Ceremonies</a>
      </div>
      <div class="cb-ceremony-pills">
        <span class="cb-ceremony-pill">💍 Weddings</span>
        <span class="cb-ceremony-pill">🌸 Naming Days</span>
        <span class="cb-ceremony-pill">🕊️ Funerals</span>
        <span class="cb-ceremony-pill">💞 Vow Renewals</span>
        <span class="cb-ceremony-pill">🌈 Civil Partnerships</span>
      </div>
    </div>
  </section>

  <!-- ── STATS ─────────────────────────────────────────────── -->
  <section class="cb-stats" aria-label="Key figures">
    <div class="cb-wrap">
      <div class="cb-stats__grid">
        <div class="cb-stat">
          <div class="cb-stat__number" data-target="16" aria-label="16 years experience">0</div>
          <div class="cb-stat__label">Years Celebranting</div>
        </div>
        <div class="cb-stat">
          <div class="cb-stat__number" data-target="950" aria-label="950+ ceremonies">0</div>
          <div class="cb-stat__label">Ceremonies Performed</div>
        </div>
        <div class="cb-stat">
          <div class="cb-stat__number" data-target="5" data-float="1" aria-label="5.0 star rating">0</div>
          <div class="cb-stat__label">★ Google Rating</div>
        </div>
        <div class="cb-stat">
          <div class="cb-stat__number" data-target="100" aria-label="100% bespoke">0</div>
          <div class="cb-stat__label">% Bespoke Ceremonies</div>
        </div>
      </div>
    </div>
  </section>

  <!-- ── ABOUT ─────────────────────────────────────────────── -->
  <section class="cb-section cb-section--alt" id="about" aria-labelledby="cb-about-heading">
    <div class="cb-wrap">
      <div class="cb-about__grid">

        <div class="cb-about__visual cb-reveal" aria-hidden="true">
          <!-- Interlocked rings visual -->
          <div class="cb-rings-visual">
            <div class="cb-ring-large" style="display:inline-block;"></div>
            <div class="cb-ring-large cb-ring-large--2" style="display:inline-block;"></div>
          </div>
          <div class="cb-about__cert">✦ Humanist UK Accredited</div>
          <div class="cb-about__badge">
            <div class="cb-about__badge-name">Isabelle Fontaine</div>
            <div class="cb-about__badge-cred">Accredited Celebrant · CelebrantUK Qualified</div>
          </div>
        </div>

        <div class="cb-about__content cb-reveal">
          <p class="cb-eyebrow">About Your Celebrant</p>
          <h2 class="cb-about__full-name" id="cb-about-heading">Isabelle Fontaine</h2>
          <span class="cb-about__credential">Humanist UK · CelebrantUK · 16 Years Experience</span>
          <p class="cb-about__body">
            I am a fully accredited celebrant with a simple, heartfelt belief: every ceremony should feel genuinely, unmistakably like you. Not a template, not a script borrowed from a registry office — but a celebration of the people involved, told in their own words and shaped around their values.
          </p>
          <p class="cb-about__body">
            I serve couples and families across Oxfordshire, Buckinghamshire, Berkshire, and London. I am equally comfortable leading an intimate garden wedding for twenty guests and a marquee celebration for four hundred — what matters is that every person in the room feels the significance of the moment.
          </p>
          <ul class="cb-about__quals">
            <li>Humanist UK Accredited Celebrant</li>
            <li>CelebrantUK Diploma (Distinction)</li>
            <li>Institute of Civil Funerals — Funeral Celebrant</li>
            <li>Naming Ceremonies UK registered celebrant</li>
            <li>Professional Development Certificate — Bereavement Support</li>
          </ul>
          <a href="#booking" class="cb-btn cb-btn--primary">✦ Begin Your Ceremony</a>
        </div>
      </div>
    </div>
  </section>

  <!-- ── CEREMONY TYPES ─────────────────────────────────────── -->
  <section class="cb-ceremonies" id="ceremonies" aria-labelledby="cb-ceremonies-heading">
    <div class="cb-wrap">
      <p class="cb-eyebrow">What I Offer</p>
      <h2 class="cb-h2" id="cb-ceremonies-heading">Ceremony Types</h2>
      <p class="cb-lead" style="color:rgba(255,255,255,.75)">Every ceremony is written from scratch, guided by your story, your words, and what matters most to you.</p>

      <div class="cb-ceremonies__grid">

        <div class="cb-ceremony-card cb-reveal">
          <div class="cb-ceremony-card__header">
            <span class="cb-ceremony-card__icon">💍</span>
            <div class="cb-ceremony-card__title">Weddings</div>
            <div class="cb-ceremony-card__sub">Civil &amp; humanist ceremonies</div>
          </div>
          <div class="cb-ceremony-card__body">
            <p class="cb-ceremony-card__desc">Your love story, told exactly as it happened — with readings, rituals, humour, or tears, in whatever measure feels right.</p>
            <ul class="cb-ceremony-card__feats">
              <li>Fully bespoke script</li>
              <li>Unlimited rewrites</li>
              <li>Rehearsal included</li>
              <li>Legal legality advice (if required)</li>
            </ul>
          </div>
        </div>

        <div class="cb-ceremony-card cb-reveal">
          <div class="cb-ceremony-card__header">
            <span class="cb-ceremony-card__icon">🌈</span>
            <div class="cb-ceremony-card__title">Civil Partnerships</div>
            <div class="cb-ceremony-card__sub">Inclusive &amp; affirming ceremonies</div>
          </div>
          <div class="cb-ceremony-card__body">
            <p class="cb-ceremony-card__desc">A joyful, inclusive celebration of your commitment — an explicitly queer-affirming space with no assumptions and no templates.</p>
            <ul class="cb-ceremony-card__feats">
              <li>LGBTQ+ specialist experience</li>
              <li>Custom vows coaching</li>
              <li>Inclusive ritual suggestions</li>
              <li>Pronouns &amp; language your way</li>
            </ul>
          </div>
        </div>

        <div class="cb-ceremony-card cb-reveal">
          <div class="cb-ceremony-card__header">
            <span class="cb-ceremony-card__icon">🌸</span>
            <div class="cb-ceremony-card__title">Naming Days</div>
            <div class="cb-ceremony-card__sub">Welcome ceremonies for new arrivals</div>
          </div>
          <div class="cb-ceremony-card__body">
            <p class="cb-ceremony-card__desc">A warm, joyful welcome for a new person in the world — for all family structures, with or without religious affiliation.</p>
            <ul class="cb-ceremony-card__feats">
              <li>Naming &amp; promising rituals</li>
              <li>Godparent / guide person promises</li>
              <li>Keepsake script provided</li>
              <li>Sibling inclusion options</li>
            </ul>
          </div>
        </div>

        <div class="cb-ceremony-card cb-reveal">
          <div class="cb-ceremony-card__header">
            <span class="cb-ceremony-card__icon">🕊️</span>
            <div class="cb-ceremony-card__title">Funerals &amp; Tributes</div>
            <div class="cb-ceremony-card__sub">Meaningful farewells</div>
          </div>
          <div class="cb-ceremony-card__body">
            <p class="cb-ceremony-card__desc">A compassionate, personalised tribute that truly reflects the life of the person who has died — written with care and delivered with warmth.</p>
            <ul class="cb-ceremony-card__feats">
              <li>Home or funeral director visit</li>
              <li>Full life tribute eulogy</li>
              <li>Family readings coordinated</li>
              <li>Music &amp; ritual guidance</li>
            </ul>
          </div>
        </div>

        <div class="cb-ceremony-card cb-reveal">
          <div class="cb-ceremony-card__header">
            <span class="cb-ceremony-card__icon">💞</span>
            <div class="cb-ceremony-card__title">Vow Renewals</div>
            <div class="cb-ceremony-card__sub">Celebrating the journey so far</div>
          </div>
          <div class="cb-ceremony-card__body">
            <p class="cb-ceremony-card__desc">A chance to stand together again and say, "I still choose you" — celebrating anniversaries or simply life's chapters with intention.</p>
            <ul class="cb-ceremony-card__feats">
              <li>Fresh vows written together</li>
              <li>Milestone anniversary focus</li>
              <li>Children / family integration</li>
              <li>Intimate or large gatherings</li>
            </ul>
          </div>
        </div>

        <div class="cb-ceremony-card cb-reveal">
          <div class="cb-ceremony-card__header">
            <span class="cb-ceremony-card__icon">✨</span>
            <div class="cb-ceremony-card__title">Bespoke Ceremonies</div>
            <div class="cb-ceremony-card__sub">Celebrations that defy category</div>
          </div>
          <div class="cb-ceremony-card__body">
            <p class="cb-ceremony-card__desc">Retirement ceremonies, coming-of-age celebrations, memorial gatherings, house blessings — if it matters, it deserves a ceremony.</p>
            <ul class="cb-ceremony-card__feats">
              <li>Completely custom design</li>
              <li>Any location, any size</li>
              <li>Ritual and symbol guidance</li>
              <li>Consultation included</li>
            </ul>
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- ── PROCESS ────────────────────────────────────────────── -->
  <section class="cb-section cb-section--alt" aria-labelledby="cb-process-heading">
    <div class="cb-wrap">
      <p class="cb-eyebrow" style="text-align:center">From First Meeting to Your Big Moment</p>
      <h2 class="cb-h2" id="cb-process-heading" style="text-align:center">The Ceremony Journey</h2>
      <div class="cb-process__steps">
        <div class="cb-step cb-reveal">
          <div class="cb-step__num">1</div>
          <h3 class="cb-step__title">Free Discovery Call</h3>
          <p class="cb-step__desc">A relaxed 30-minute call to find out about you, your ceremony vision, and confirm we're the right fit.</p>
        </div>
        <div class="cb-step cb-reveal">
          <div class="cb-step__num">2</div>
          <h3 class="cb-step__title">Planning Meeting</h3>
          <p class="cb-step__desc">A detailed meeting — in person, online, or at your venue — to capture your full story, rituals, and ideas.</p>
        </div>
        <div class="cb-step cb-reveal">
          <div class="cb-step__num">3</div>
          <h3 class="cb-step__title">Bespoke Script</h3>
          <p class="cb-step__desc">Your ceremony script is written and shared with you for review — with unlimited tweaks until it's perfect.</p>
        </div>
        <div class="cb-step cb-reveal">
          <div class="cb-step__num">4</div>
          <h3 class="cb-step__title">Rehearsal</h3>
          <p class="cb-step__desc">A venue rehearsal to ensure everyone knows their moment and your day runs beautifully.</p>
        </div>
        <div class="cb-step cb-reveal">
          <div class="cb-step__num">5</div>
          <h3 class="cb-step__title">Your Ceremony Day</h3>
          <p class="cb-step__desc">I arrive early, keep the day running calmly, and deliver your ceremony with warmth and precision.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- ── PACKAGES ───────────────────────────────────────────── -->
  <section class="cb-section" id="packages" aria-labelledby="cb-packages-heading">
    <div class="cb-wrap">
      <p class="cb-eyebrow" style="text-align:center">Investment</p>
      <h2 class="cb-h2" id="cb-packages-heading" style="text-align:center">Ceremony Packages</h2>
      <p class="cb-lead" style="text-align:center">All packages include unlimited script revisions and a complimentary keepsake copy of your ceremony.</p>

      <div class="cb-packages__grid">

        <div class="cb-pkg cb-pkg--elopement cb-reveal">
          <div class="cb-pkg__header">
            <div class="cb-pkg__name">Intimate Elopement</div>
            <div class="cb-pkg__price">£595</div>
            <div class="cb-pkg__unit">up to 20 guests</div>
          </div>
          <div class="cb-pkg__body">
            <p class="cb-pkg__desc">Perfect for intimate ceremonies that are no less meaningful for their size — exquisitely personal, beautifully delivered.</p>
            <ul class="cb-pkg__features">
              <li>Free discovery call</li>
              <li>1 × planning meeting (video)</li>
              <li>Fully bespoke ceremony script</li>
              <li>Unlimited script revisions</li>
              <li>Ceremony delivery (up to 1 hour)</li>
              <li>Keepsake printed script</li>
              <li>Travel up to 30 miles included</li>
            </ul>
            <button class="cb-pkg__cta" onclick="document.getElementById('booking').scrollIntoView({behavior:'smooth'})">Enquire Now</button>
          </div>
        </div>

        <div class="cb-pkg cb-pkg--featured cb-reveal">
          <div class="cb-pkg__header">
            <div class="cb-pkg__badge">Most Popular</div>
            <div class="cb-pkg__name">Signature Ceremony</div>
            <div class="cb-pkg__price">£985</div>
            <div class="cb-pkg__unit">all guest numbers</div>
          </div>
          <div class="cb-pkg__body">
            <p class="cb-pkg__desc">The full experience — a deeply personal ceremony for any size of gathering, with venue visit and full rehearsal included.</p>
            <ul class="cb-pkg__features">
              <li>Free discovery call</li>
              <li>2 × planning meetings (inc. venue)</li>
              <li>Full ceremony rehearsal</li>
              <li>Bespoke ceremony script</li>
              <li>Unlimited revisions</li>
              <li>Ceremony delivery (up to 1.5 hrs)</li>
              <li>Ceremony coordination on the day</li>
              <li>Keepsake hand-bound script</li>
              <li>Travel up to 75 miles included</li>
            </ul>
            <button class="cb-pkg__cta" onclick="document.getElementById('booking').scrollIntoView({behavior:'smooth'})">Reserve Your Date</button>
          </div>
        </div>

        <div class="cb-pkg cb-pkg--full cb-reveal">
          <div class="cb-pkg__header">
            <div class="cb-pkg__name">Full-Day Celebration</div>
            <div class="cb-pkg__price">£1,450</div>
            <div class="cb-pkg__unit">ceremony + full day coordination</div>
          </div>
          <div class="cb-pkg__body">
            <p class="cb-pkg__desc">For those who want me on hand throughout — ceremony, drinks reception, and toasts — ensuring your entire day flows with grace.</p>
            <ul class="cb-pkg__features">
              <li>Everything in Signature Ceremony</li>
              <li>Master of Ceremonies on the day</li>
              <li>Drinks reception coordination</li>
              <li>Speeches &amp; toasts introduction</li>
              <li>Supplier coordination support</li>
              <li>Timeline creation &amp; management</li>
              <li>Full day (up to 10 hours)</li>
              <li>Travel up to 100 miles included</li>
            </ul>
            <button class="cb-pkg__cta" onclick="document.getElementById('booking').scrollIntoView({behavior:'smooth'})">Enquire Now</button>
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- ── TESTIMONIALS ───────────────────────────────────────── -->
  <section class="cb-section cb-testimonials" aria-labelledby="cb-testi-heading">
    <div class="cb-wrap">
      <p class="cb-eyebrow" style="text-align:center">Words from Couples &amp; Families</p>
      <h2 class="cb-h2" id="cb-testi-heading" style="text-align:center">What They Say</h2>

      <div class="cb-testimonials__grid">

        <blockquote class="cb-testi cb-reveal">
          <div class="cb-testi__stars" aria-label="5 stars">★★★★★</div>
          <p class="cb-testi__quote">Isabelle captured us perfectly. Every guest said it was the most personal ceremony they'd ever attended. People were laughing and crying in equal measure — and that's exactly what we wanted.</p>
          <footer>
            <div class="cb-testi__author">Emma &amp; Sophie Hargreaves</div>
            <div class="cb-testi__meta">Civil Partnership · Signature Ceremony · Oxfordshire</div>
          </footer>
        </blockquote>

        <blockquote class="cb-testi cb-reveal">
          <div class="cb-testi__stars" aria-label="5 stars">★★★★★</div>
          <p class="cb-testi__quote">We gave Isabelle the roughest of outlines and she turned it into something that had the whole room in floods. Mum's funeral was the celebration of her life she truly deserved.</p>
          <footer>
            <div class="cb-testi__author">The Whitaker Family</div>
            <div class="cb-testi__meta">Funeral Tribute · Bespoke</div>
          </footer>
        </blockquote>

        <blockquote class="cb-testi cb-reveal">
          <div class="cb-testi__stars" aria-label="5 stars">★★★★★</div>
          <p class="cb-testi__quote">We've been to dozens of weddings and ours was the only one where the ceremony itself was the highlight. Isabelle's presence was so warm and professional. We will never forget it.</p>
          <footer>
            <div class="cb-testi__author">James &amp; Priya Nair</div>
            <div class="cb-testi__meta">Wedding · Full-Day Celebration · London</div>
          </footer>
        </blockquote>

      </div>
    </div>
  </section>

  <!-- ── FAQs ───────────────────────────────────────────────── -->
  <section class="cb-section cb-section--alt" aria-labelledby="cb-faq-heading">
    <div class="cb-wrap">
      <p class="cb-eyebrow" style="text-align:center">Questions</p>
      <h2 class="cb-h2" id="cb-faq-heading" style="text-align:center">Frequently Asked Questions</h2>
      <div class="cb-faqs__list">

        <div class="cb-faq">
          <button class="cb-faq__q" aria-expanded="false" aria-controls="cb-faq-1">
            Is a humanist ceremony legally binding?
            <span class="cb-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="cb-faq__a" id="cb-faq-1" role="region">
            In England and Wales, humanist and civil ceremonies are not currently legally recognised as marriages — though legislation is progressing. Couples choose to complete a short, private legal registration (usually at a register office before or after their celebrant ceremony) and then hold their meaningful, personal ceremony with me. This way you get both the legal standing and the ceremony you truly want. I provide full guidance on this process.
          </div>
        </div>

        <div class="cb-faq">
          <button class="cb-faq__q" aria-expanded="false" aria-controls="cb-faq-2">
            How far in advance should I book?
            <span class="cb-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="cb-faq__a" id="cb-faq-2" role="region">
            Popular dates (spring, summer Saturdays) are often booked 12–18 months in advance. I occasionally have availability for shorter timescales — particularly for weekday and winter dates — so please always get in touch even if you're planning something sooner than you think is realistic.
          </div>
        </div>

        <div class="cb-faq">
          <button class="cb-faq__q" aria-expanded="false" aria-controls="cb-faq-3">
            Can we write our own vows?
            <span class="cb-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="cb-faq__a" id="cb-faq-3" role="region">
            Absolutely — and I actively encourage it. Writing your own vows is one of the most meaningful things you will do. I offer a full vow-writing guide and coaching to help you say exactly what you mean without the blank-page panic. If you'd prefer I write them on your behalf, that's equally wonderful.
          </div>
        </div>

        <div class="cb-faq">
          <button class="cb-faq__q" aria-expanded="false" aria-controls="cb-faq-4">
            Do you travel outside your listed area?
            <span class="cb-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="cb-faq__a" id="cb-faq-4" role="region">
            Yes — I love destination ceremonies and travel throughout the UK and, in some cases, internationally. Travel beyond the included mileage is charged at a per-mile rate plus accommodation where overnight stays are required. Please enquire and I'll provide a transparent quote.
          </div>
        </div>

        <div class="cb-faq">
          <button class="cb-faq__q" aria-expanded="false" aria-controls="cb-faq-5">
            What happens if you're ill on our wedding day?
            <span class="cb-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="cb-faq__a" id="cb-faq-5" role="region">
            I hold professional insurance and maintain a trusted network of equally experienced celebrants who can step in if the unthinkable happens. I have never missed a ceremony in sixteen years — but your peace of mind matters, and I ensure it is protected.
          </div>
        </div>

        <div class="cb-faq">
          <button class="cb-faq__q" aria-expanded="false" aria-controls="cb-faq-6">
            Can children and pets be included?
            <span class="cb-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="cb-faq__a" id="cb-faq-6" role="region">
            Absolutely. I have incorporated ring-bearing dogs, flower-carrying toddlers, sibling unity candles, and family sand ceremonies into many ceremonies. Including the whole family — in whatever form that takes — makes a ceremony richer, and I will help you do it beautifully.
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- ── BOOKING FORM ───────────────────────────────────────── -->
  <section class="cb-booking" id="booking" aria-labelledby="cb-booking-heading">
    <div class="cb-wrap">
      <div class="cb-ornament" style="color:var(--cb-gold-lt);">✦ ✦ ✦</div>
      <p class="cb-eyebrow" style="text-align:center">Let's Start Your Story</p>
      <h2 class="cb-h2" id="cb-booking-heading" style="text-align:center">Begin Your Ceremony Enquiry</h2>
      <p class="cb-lead" style="text-align:center">Fill in the form and I'll be in touch within 24 hours — often sooner.</p>

      <div class="cb-form">
        <?php if ( function_exists( 'wp_nonce_field' ) ) : ?>
        <form method="post" action="" novalidate>
          <?php wp_nonce_field( 'tf_cb_booking', 'tf_cb_nonce' ); ?>

          <div class="cb-form__grid">

            <div>
              <label class="cb-label" for="cb-name">Your Name(s) *</label>
              <input class="cb-input" type="text" id="cb-name" name="cb_name" required placeholder="e.g. Emma &amp; Jack Hargreaves" autocomplete="name">
            </div>

            <div>
              <label class="cb-label" for="cb-email">Email Address *</label>
              <input class="cb-input" type="email" id="cb-email" name="cb_email" required placeholder="you@example.com" autocomplete="email">
            </div>

            <div>
              <label class="cb-label" for="cb-phone">Phone Number</label>
              <input class="cb-input" type="tel" id="cb-phone" name="cb_phone" placeholder="07xxx xxxxxx" autocomplete="tel">
            </div>

            <div>
              <label class="cb-label" for="cb-ceremony-type">Ceremony Type *</label>
              <select class="cb-select" id="cb-ceremony-type" name="cb_ceremony_type" required>
                <option value="">Please select…</option>
                <option>Wedding</option>
                <option>Civil Partnership</option>
                <option>Naming Day / Welcoming Ceremony</option>
                <option>Funeral / Life Tribute</option>
                <option>Vow Renewal</option>
                <option>Bespoke / Other</option>
              </select>
            </div>

            <div>
              <label class="cb-label" for="cb-date">Ceremony Date (or approximate)</label>
              <input class="cb-input" type="text" id="cb-date" name="cb_date" placeholder="e.g. 14 June 2026 or Summer 2026">
            </div>

            <div>
              <label class="cb-label" for="cb-location">Ceremony Location *</label>
              <input class="cb-input" type="text" id="cb-location" name="cb_location" required placeholder="Venue name or town / county">
            </div>

            <div>
              <label class="cb-label" for="cb-guests">Approximate Guest Numbers</label>
              <select class="cb-select" id="cb-guests" name="cb_guests">
                <option value="">Not sure yet</option>
                <option>Elopement (under 20)</option>
                <option>Intimate (20–50)</option>
                <option>Medium (50–100)</option>
                <option>Large (100–200)</option>
                <option>Very large (200+)</option>
              </select>
            </div>

            <div>
              <label class="cb-label" for="cb-package">Package Interest</label>
              <select class="cb-select" id="cb-package" name="cb_package">
                <option value="">Not sure — tell me more!</option>
                <option>Intimate Elopement (£595)</option>
                <option>Signature Ceremony (£985)</option>
                <option>Full-Day Celebration (£1,450)</option>
              </select>
            </div>

            <div class="cb-form__full">
              <label class="cb-label" for="cb-story">Tell me a little about your ceremony — what matters most to you? *</label>
              <textarea class="cb-textarea" id="cb-story" name="cb_story" required placeholder="The more you share, the better I can picture your perfect ceremony…"></textarea>
            </div>

          </div>

          <div class="cb-form__submit">
            <button type="submit" class="cb-btn cb-btn--primary">✦ Send My Enquiry</button>
          </div>
          <p class="cb-form__note">Free discovery call · No obligation · Replies within 24 hours</p>

        </form>
        <?php endif; ?>
      </div>
    </div>
  </section>

  <!-- ── FOOTER CTA ─────────────────────────────────────────── -->
  <section class="cb-footer-cta" aria-label="Call to action">
    <div class="cb-wrap">
      <div class="cb-ornament" style="color:rgba(255,255,255,.6);">✦ ✦ ✦</div>
      <h2 class="cb-h2">Every Ceremony Is a Once-in-a-Lifetime Moment</h2>
      <p class="cb-lead">Let's make yours unforgettable.</p>
      <a href="#booking" class="cb-btn cb-btn--outline">Begin Your Ceremony ↗</a>
    </div>
  </section>

</div><!-- .cb-page -->

<script>
(function () {
  'use strict';

  /* ── Animated counters ──────────────────────────────────── */
  var easeOut = function (t) { return 1 - Math.pow(1 - t, 3); };
  var dur = 1800;
  function animCounter(el) {
    var target = parseFloat(el.getAttribute('data-target'));
    var isFloat = el.getAttribute('data-float') === '1';
    if (isNaN(target)) return;
    var start = null;
    function tick(ts) {
      if (!start) start = ts;
      var p = Math.min((ts - start) / dur, 1);
      var v = target * easeOut(p);
      el.textContent = isFloat ? v.toFixed(1) : Math.floor(v).toLocaleString();
      if (p < 1) requestAnimationFrame(tick);
      else el.textContent = isFloat ? target.toFixed(1) : target.toLocaleString();
    }
    requestAnimationFrame(tick);
  }
  var cObs = new IntersectionObserver(function (entries, obs) {
    entries.forEach(function (e) { if (e.isIntersecting) { animCounter(e.target); obs.unobserve(e.target); } });
  }, { threshold: 0.5 });
  document.querySelectorAll('[data-target]').forEach(function (el) { cObs.observe(el); });

  /* ── FAQ accordion ──────────────────────────────────────── */
  document.querySelectorAll('.cb-faq__q').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var expanded = this.getAttribute('aria-expanded') === 'true';
      var id = this.getAttribute('aria-controls');
      document.querySelectorAll('.cb-faq__q').forEach(function (b) { b.setAttribute('aria-expanded','false'); });
      document.querySelectorAll('.cb-faq__a').forEach(function (a) { a.classList.remove('is-open'); });
      if (!expanded) {
        this.setAttribute('aria-expanded','true');
        var a = document.getElementById(id); if (a) a.classList.add('is-open');
      }
    });
  });

  /* ── Scroll reveal ──────────────────────────────────────── */
  var rObs = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('is-visible'); rObs.unobserve(e.target); } });
  }, { threshold: 0.12 });
  document.querySelectorAll('.cb-reveal').forEach(function (el) { rObs.observe(el); });

  /* ── Smooth scroll ──────────────────────────────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      var t = document.querySelector(this.getAttribute('href'));
      if (t) { e.preventDefault(); t.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    });
  });

})();
</script>

<?php get_footer(); ?>
