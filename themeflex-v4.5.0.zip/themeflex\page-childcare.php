<?php
/**
 * Template Name: TF — Nursery & Childcare Centre
 * Description:   Premium nursery & childcare homepage template.
 * Namespace:     --nrs-*
 * Fonts:         Nunito + Nunito Sans
 * Palette:       sky #e8f4fd · sunshine #ffd84a · coral #ff7f5c · sage #5a9a7a · cloud #ffffff · midnight #1a2d3a
 */
defined('ABSPATH') || exit;
/* ── PHP data ──────────────────────────────────────────────────────────── */
srand(crc32(get_the_permalink()));

$clouds = [];
for($i=0;$i<8;$i++) $clouds[] = ['x'=>rand(2,90),'y'=>rand(5,35),'w'=>rand(80,160),'op'=>lcg_value()*.5+.3,'dur'=>rand(20,45),'del'=>lcg_value()*12];

$stars_bg = [];
for($i=0;$i<18;$i++) $stars_bg[] = ['x'=>rand(0,100),'y'=>rand(0,50),'s'=>rand(12,24),'del'=>lcg_value()*3];

$rooms = [
  ['name'=>'Seedlings','age'=>'3 months – 1 year','ratio'=>'1:3','icon'=>'🌱','color'=>'#ff7f5c','desc'=>'Our cosy baby room, designed for sensory exploration and nurturing key developmental milestones in a safe, loving environment.','feats'=>['Sensory play stations','Sleep pods','Bottle prep area','CCTV monitored']],
  ['name'=>'Sprouts','age'=>'1 – 2 years','ratio'=>'1:3','icon'=>'🌿','color'=>'#5a9a7a','desc'=>'Toddler-ready spaces for developing language, movement, and social skills through play, music, and messy art.','feats'=>['Soft play zone','Music & movement daily','Outdoor access','Speech development play']],
  ['name'=>'Blossom','age'=>'2 – 3 years','ratio'=>'1:4','icon'=>'🌸','color'=>'#e080c0','desc'=>'Creative, curious, and active — our Blossom room supports independence, imagination, and the early foundations of learning.','feats'=>['Creative art corner','Role play kitchen','Garden grow project','Circle time daily']],
  ['name'=>'Explorers','age'=>'3 – 5 years','ratio'=>'1:8','icon'=>'🔭','color'=>'#5a90cc','desc'=>'School-ready provision with focus on phonics, numeracy, STEM, and social skills — preparing every child with confidence and joy.','feats'=>['Phonics & numeracy','STEM activities','Forest School sessions','French & music classes']],
];

$activities = [
  ['icon'=>'🎨','name'=>'Creative Arts','desc'=>'Painting, sculpture, collage, and craft — self-expression is at the heart of our daily routine.'],
  ['icon'=>'🌳','name'=>'Forest School','desc'=>'Weekly outdoor sessions in our nature area, building resilience, curiosity, and love of the natural world.'],
  ['icon'=>'📚','name'=>'Story & Language','desc'=>'Daily stories, rhymes, and conversation — the building blocks of literacy from day one.'],
  ['icon'=>'🎵','name'=>'Music & Movement','desc'=>'Singing, percussion, and dance — joyful and developmental for every age group we care for.'],
  ['icon'=>'🥗','name'=>'Healthy Meals','desc'=>'Freshly cooked nutritious meals and snacks prepared on-site by our dedicated kitchen team.'],
  ['icon'=>'🧩','name'=>'Structured Play','desc'=>'Intentional, child-led play designed with developmental psychology — learning disguised as pure fun.'],
  ['icon'=>'🌍','name'=>'Cultural Learning','desc'=>'Celebrating diversity through stories, food, festivals, and friends from all backgrounds.'],
  ['icon'=>'💻','name'=>'Digital Discovery','desc'=>'Age-appropriate introduction to technology and coding concepts through play-based digital tools.'],
];

$team = [
  ['name'=>'Sarah Whitfield','role'=>'Nursery Manager','quals'=>'BA Early Childhood Education, EYL5','years'=>14,'hair'=>'#4a2010','skin'=>'#d4a574'],
  ['name'=>'Marcus Adeyemi','role'=>'Deputy Manager','quals'=>'NVQ L5 Children\'s Care','years'=>9,'hair'=>'#1a0808','skin'=>'#7a4020'],
  ['name'=>'Emma Huang','role'=>'Lead Practitioner – EYFS','quals'=>'BA Education, PGCert SEND','years'=>7,'hair'=>'#1a1010','skin'=>'#c8956c'],
  ['name'=>'Priya Mehta','role'=>'Forest School Lead','quals'=>'Forest School L3, EYP','years'=>5,'hair'=>'#1a0808','skin'=>'#9a5a30'],
];

$testimonials = [
  ['text'=>'Our daughter went from being terrified of being left anywhere to running through the door on Monday mornings. The keyworker system and the genuine care they show is extraordinary.','author'=>'Natasha & David L.','detail'=>'Parents of Blossom room child'],
  ['text'=>'Oliver has come on leaps and bounds in phonics and social skills since joining the Explorers room. We genuinely feel like partners in his education, not bystanders.','author'=>'Robert T.','detail'=>'Parent of Explorers room child'],
  ['text'=>'The communication via the app is outstanding. We get daily updates, photos, and observations. It feels like we\'re right there with her every day.','author'=>'Aisha & Kwame M.','detail'=>'Parents of Seedlings room baby'],
];

$faqs = [
  ['q'=>'What are your opening hours?','a'=>'We are open Monday to Friday, 7:30am to 6:30pm, 51 weeks of the year (closed between Christmas and New Year). We do not close for school holidays.'],
  ['q'=>'Do you offer funded hours?','a'=>'Yes — we accept 15- and 30-hour government-funded hours for eligible 2, 3, and 4-year-olds. Our admin team can help you check your eligibility and process the paperwork.'],
  ['q'=>'How do you settle a new child?','a'=>'We use a gentle, personalised settling-in process with multiple short visits before the first full session. You\'ll be assigned a Key Worker who will be your child\'s main point of contact.'],
  ['q'=>'What is your inspection rating?','a'=>'We hold an Outstanding rating from Ofsted, our most recent inspection having taken place in October 2024. The full report is available on the Ofsted website and in our office.'],
  ['q'=>'Is there a waiting list?','a'=>'We do operate a waiting list for some age groups, particularly babies. We recommend registering your interest as early as possible — ideally before your baby is born.'],
];

$awards_list = [
  ['year'=>'2024','name'=>'Outstanding — Ofsted Inspection','body'=>'Office for Standards in Education'],
  ['year'=>'2024','name'=>'Nursery of the Year — South East','body'=>'Nursery World Awards'],
  ['year'=>'2023','name'=>'Sustainability Award','body'=>'National Day Nurseries Association'],
  ['year'=>'2023','name'=>'Best New Practitioner — Emma Huang','body'=>'Early Years Alliance'],
];

$marquee_items = ['⭐ Ofsted Outstanding 2024','⭐ Forest School Provision','⭐ Government Funded Hours Accepted','⭐ Open 51 Weeks','⭐ 7:30am – 6:30pm','⭐ Freshly Cooked Meals Daily','⭐ Keyworker System','⭐ Live App Updates & Photos'];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;500;600;700;800;900&family=Nunito+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
/* ── TOKENS ─────────────────────────────────────────────────────────── */
:root{
  --nrs-sky:#e8f4fd;
  --nrs-sun:#ffd84a;
  --nrs-coral:#ff7f5c;
  --nrs-sage:#5a9a7a;
  --nrs-lavender:#a080c0;
  --nrs-cloud:#ffffff;
  --nrs-midnight:#1a2d3a;
  --nrs-slate:#4a6070;
  --nrs-warm:#fef9f0;
  --nrs-ff-head:'Nunito',sans-serif;
  --nrs-ff-body:'Nunito Sans',sans-serif;
  --nrs-r:12px;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body.nrs-page{font-family:var(--nrs-ff-body);color:var(--nrs-midnight);background:var(--nrs-cloud);font-size:16px;line-height:1.7;font-weight:400}
.nrs-container{max-width:1180px;margin:0 auto;padding:0 24px}
.nrs-section{padding:88px 0}
.nrs-label{font-family:var(--nrs-ff-head);font-size:.72rem;font-weight:800;letter-spacing:.2em;text-transform:uppercase;color:var(--nrs-coral);margin-bottom:12px}
.nrs-h1{font-family:var(--nrs-ff-head);font-size:clamp(2.6rem,6vw,4.5rem);line-height:1.1;font-weight:900}
.nrs-h2{font-family:var(--nrs-ff-head);font-size:clamp(1.8rem,4vw,3rem);line-height:1.15;font-weight:800}
.nrs-h3{font-family:var(--nrs-ff-head);font-size:1.3rem;font-weight:700}
.nrs-lead{font-size:1rem;font-weight:400;line-height:1.8;color:var(--nrs-slate)}
.nrs-squiggle{width:64px;height:8px;margin:16px 0 28px;position:relative}
.nrs-squiggle::before{content:'';position:absolute;inset:0;background:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 8'%3E%3Cpath d='M0 4 Q8 0 16 4 Q24 8 32 4 Q40 0 48 4 Q56 8 64 4' fill='none' stroke='%23ff7f5c' stroke-width='2.5' stroke-linecap='round'/%3E%3C/svg%3E") center/cover no-repeat}
.nrs-btn{display:inline-block;padding:14px 32px;font-family:var(--nrs-ff-head);font-size:.9rem;font-weight:800;text-decoration:none;border:none;cursor:pointer;transition:all .25s;border-radius:50px}
.nrs-btn-coral{background:var(--nrs-coral);color:#fff;box-shadow:0 4px 16px rgba(255,127,92,.3)}.nrs-btn-coral:hover{background:#ff6a45;transform:translateY(-2px);box-shadow:0 6px 24px rgba(255,127,92,.4)}
.nrs-btn-sun{background:var(--nrs-sun);color:var(--nrs-midnight);box-shadow:0 4px 16px rgba(255,216,74,.3)}.nrs-btn-sun:hover{transform:translateY(-2px)}
.nrs-btn-outline{background:transparent;color:var(--nrs-coral);border:2px solid var(--nrs-coral);border-radius:50px}.nrs-btn-outline:hover{background:var(--nrs-coral);color:#fff}
.nrs-reveal{opacity:0;transform:translateY(24px);transition:opacity .65s,transform .65s}
.nrs-reveal.visible{opacity:1;transform:none}

/* ── HERO ────────────────────────────────────────────────────────────── */
.nrs-hero{position:relative;width:100%;min-height:100vh;overflow:hidden;display:flex;align-items:center;background:linear-gradient(180deg,#b8e0f8 0%,#d8f0fc 35%,#e8f8e8 65%,#c8e8c8 100%)}
/* Sun */
.nrs-sun-ball{position:absolute;top:-40px;right:10%;width:160px;height:160px;border-radius:50%;background:radial-gradient(circle at 40% 40%,#ffe878,#ffd84a,#ffb820);box-shadow:0 0 60px rgba(255,216,74,.5)}
/* Sun rays */
@keyframes nrs-ray-spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
.nrs-sun-rays{position:absolute;top:-40px;right:10%;width:160px;height:160px;animation:nrs-ray-spin 20s linear infinite}
.nrs-sun-ray{position:absolute;top:50%;left:50%;width:2px;height:60px;background:linear-gradient(0deg,transparent,rgba(255,216,74,.4));transform-origin:top center;border-radius:1px}
/* Clouds CSS */
.nrs-cloud-el{position:absolute;background:rgba(255,255,255,.85);border-radius:50px;filter:blur(1px)}
.nrs-cloud-el::before,.nrs-cloud-el::after{content:'';position:absolute;background:rgba(255,255,255,.85);border-radius:50%}
@keyframes nrs-cloud-float{0%,100%{transform:translateX(0)}50%{transform:translateX(15px)}}
/* Ground */
.nrs-ground{position:absolute;bottom:0;left:0;right:0;height:30%;background:linear-gradient(0deg,#5aaa6a,#6aba7a,#7acc8a)}
/* Rolling hills */
.nrs-hill{position:absolute;bottom:0;border-radius:50% 50% 0 0}
/* Fence */
.nrs-fence{position:absolute;bottom:30%;left:0;right:0;height:40px;display:flex;gap:0}
.nrs-fence-post{width:14px;height:36px;background:linear-gradient(180deg,#c8a870,#a08850);border-radius:2px 2px 0 0;flex-shrink:0}
.nrs-fence-rail{position:absolute;left:0;right:0;height:6px;background:linear-gradient(180deg,#d0b070,#b09050);border-radius:2px}
/* Building */
.nrs-building{position:absolute;bottom:30%;right:5%;display:flex;flex-direction:column;align-items:center}
.nrs-roof{width:0;height:0;border-left:90px solid transparent;border-right:90px solid transparent;border-bottom:60px solid #ff7f5c}
.nrs-building-body{width:160px;height:100px;background:linear-gradient(180deg,#fff9f0,#f0e8d8);border-radius:4px 4px 0 0;position:relative}
.nrs-bwin{width:28px;height:28px;background:linear-gradient(180deg,#b8e0f8,#a0d0f0);border-radius:3px;border:3px solid rgba(255,127,92,.4);position:absolute}
.nrs-bwin::before{content:'';position:absolute;left:50%;top:0;bottom:0;width:2px;background:rgba(255,127,92,.3);transform:translateX(-50%)}
.nrs-bwin::after{content:'';position:absolute;top:50%;left:0;right:0;height:2px;background:rgba(255,127,92,.3)}
.nrs-bdoor{width:32px;height:44px;background:linear-gradient(180deg,#5a9a7a,#3a7a5a);border-radius:4px 4px 0 0;position:absolute;bottom:0;left:50%;transform:translateX(-50%)}
.nrs-bdoor-knob{width:5px;height:5px;border-radius:50%;background:var(--nrs-sun);position:absolute;right:5px;top:50%}
/* Sign above door */
.nrs-sign{width:90px;height:20px;background:var(--nrs-sun);border-radius:4px;display:flex;align-items:center;justify-content:center;font-family:var(--nrs-ff-head);font-size:.55rem;font-weight:900;color:var(--nrs-midnight);margin-bottom:2px}
/* Chimney */
.nrs-chimney{position:absolute;top:-40px;left:25px;width:20px;height:36px;background:linear-gradient(180deg,#ff9070,#e06050)}
/* Trees */
.nrs-tree{position:absolute;bottom:30%;display:flex;flex-direction:column;align-items:center}
.nrs-tree-top{border-radius:50% 50% 40% 40%;background:radial-gradient(circle at 40% 35%,#6acc7a,#4a9a5a)}
.nrs-tree-trunk{width:10px;background:linear-gradient(180deg,#a08050,#7a6030);border-radius:2px}
/* Rainbow */
.nrs-rainbow{position:absolute;top:15%;left:5%;width:200px;height:100px;border-radius:100px 100px 0 0;overflow:hidden;opacity:.5}
.nrs-rainbow-stripe{position:absolute;bottom:0;left:0;right:0;border-radius:100px 100px 0 0}
/* Flowers */
.nrs-flower{position:absolute;bottom:30%;display:flex;flex-direction:column;align-items:center}
.nrs-flower-head{width:20px;height:20px;border-radius:50%;position:relative}
.nrs-flower-petal{position:absolute;width:8px;height:8px;border-radius:50%;transform-origin:center 14px}
.nrs-flower-stem{width:3px;background:linear-gradient(0deg,#5a9a5a,#7aba6a);border-radius:2px}
.nrs-flower-leaf{position:absolute;width:12px;height:8px;border-radius:50% 0 50% 0;background:#5a9a5a}
/* Slide */
.nrs-slide{position:absolute;bottom:30%;left:8%}
.nrs-slide-steps{width:10px;height:60px;background:linear-gradient(180deg,#ff9070,#e06050);border-radius:2px;position:absolute;left:-10px}
.nrs-slide-platform{width:50px;height:10px;background:linear-gradient(90deg,#ff9070,#e06050);border-radius:2px;position:absolute;top:0;left:0}
.nrs-slide-ramp{width:80px;height:6px;background:linear-gradient(90deg,#ffa080,#ff7060);border-radius:3px;transform:rotate(30deg);transform-origin:left center;position:absolute;top:10px;left:0}
/* Swing */
.nrs-swing{position:absolute;bottom:30%;left:28%}
.nrs-swing-frame{width:60px;height:70px;border-top:5px solid #a08050;display:flex;justify-content:space-between;align-items:flex-start}
.nrs-swing-leg{width:5px;height:70px;background:linear-gradient(180deg,#a08050,#7a6030);border-radius:2px;transform:rotate(-5deg);transform-origin:top center}
.nrs-swing-rope{width:1.5px;height:40px;background:rgba(100,80,40,.6);position:absolute;transform-origin:top center;animation:nrs-swing-anim 2.5s ease-in-out infinite alternate}
.nrs-swing-seat{width:24px;height:6px;background:linear-gradient(90deg,#ff9070,#e06050);border-radius:2px;margin-top:40px}
@keyframes nrs-swing-anim{0%{transform:rotate(-15deg)}100%{transform:rotate(15deg)}}
/* Birds */
@keyframes nrs-bird-fly{0%{transform:translateX(0) translateY(0)}50%{transform:translateX(40px) translateY(-8px)}100%{transform:translateX(80px) translateY(2px)}}
/* Hero content */
.nrs-hero-inner{position:relative;z-index:10;padding:100px 0 80px;max-width:580px}
.nrs-hero-badge{display:inline-flex;align-items:center;gap:8px;background:rgba(255,255,255,.8);border-radius:50px;padding:8px 20px;margin-bottom:24px;font-family:var(--nrs-ff-head);font-size:.78rem;font-weight:800;color:var(--nrs-sage);backdrop-filter:blur(4px)}
.nrs-hero-h1{color:var(--nrs-midnight);margin-bottom:8px}
.nrs-hero-h1 span{color:var(--nrs-coral)}
.nrs-hero-sub{font-size:1.05rem;color:var(--nrs-slate);line-height:1.75;margin-bottom:32px}
.nrs-hero-btns{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:40px}
.nrs-hero-trust{display:flex;gap:20px;flex-wrap:wrap}
.nrs-trust-badge{display:flex;align-items:center;gap:8px;background:rgba(255,255,255,.7);border-radius:50px;padding:8px 16px;font-family:var(--nrs-ff-head);font-size:.75rem;font-weight:700;color:var(--nrs-midnight);backdrop-filter:blur(4px)}

/* ── MARQUEE ─────────────────────────────────────────────────────────── */
.nrs-marquee-wrap{background:var(--nrs-sage);padding:12px 0;overflow:hidden}
.nrs-marquee-track{display:flex;width:max-content;animation:nrs-marquee 28s linear infinite}
.nrs-marquee-track:hover{animation-play-state:paused}
.nrs-marquee-item{white-space:nowrap;padding:0 28px;font-family:var(--nrs-ff-head);font-size:.78rem;font-weight:700;letter-spacing:.1em;color:#fff}
@keyframes nrs-marquee{from{transform:translateX(0)}to{transform:translateX(-50%)}}

/* ── ROOMS ───────────────────────────────────────────────────────────── */
.nrs-rooms{background:var(--nrs-warm)}
.nrs-rooms-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:24px;margin-top:52px}
.nrs-room-card{background:var(--nrs-cloud);border-radius:var(--nrs-r);overflow:hidden;border:2px solid transparent;transition:border-color .3s,transform .3s,box-shadow .3s}
.nrs-room-card:hover{transform:translateY(-4px);box-shadow:0 12px 40px rgba(0,0,0,.08)}
.nrs-room-header{padding:28px 28px 20px;border-bottom:2px solid var(--nrs-room-color,#ff7f5c)}
.nrs-room-icon{font-size:2.2rem;margin-bottom:12px;display:block}
.nrs-room-name{font-family:var(--nrs-ff-head);font-size:1.5rem;font-weight:900;color:var(--nrs-midnight);margin-bottom:4px}
.nrs-room-age{font-size:.75rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--nrs-room-color,#ff7f5c);margin-bottom:8px}
.nrs-room-ratio{display:inline-block;background:rgba(0,0,0,.04);border-radius:50px;padding:4px 12px;font-size:.72rem;font-weight:700;color:var(--nrs-slate)}
.nrs-room-body{padding:20px 28px 28px}
.nrs-room-desc{font-size:.9rem;line-height:1.7;color:var(--nrs-slate);margin-bottom:16px}
.nrs-room-feats{display:flex;flex-wrap:wrap;gap:8px}
.nrs-room-feat{background:rgba(0,0,0,.04);border-radius:50px;padding:5px 12px;font-size:.75rem;font-weight:600;color:var(--nrs-slate);display:flex;align-items:center;gap:5px}
.nrs-room-feat::before{content:'✓';color:var(--nrs-sage);font-weight:800}

/* ── ACTIVITIES ──────────────────────────────────────────────────────── */
.nrs-activities{background:linear-gradient(135deg,#e8f8e8 0%,#e0f4fd 100%)}
.nrs-activities-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:20px;margin-top:52px}
.nrs-activity-card{background:var(--nrs-cloud);border-radius:var(--nrs-r);padding:28px 20px;text-align:center;transition:transform .3s,box-shadow .3s;cursor:pointer}
.nrs-activity-card:hover{transform:translateY(-4px);box-shadow:0 8px 28px rgba(0,0,0,.08)}
.nrs-activity-icon{font-size:2.2rem;margin-bottom:14px;display:block}
.nrs-activity-name{font-family:var(--nrs-ff-head);font-size:1rem;font-weight:800;color:var(--nrs-midnight);margin-bottom:8px}
.nrs-activity-desc{font-size:.82rem;line-height:1.65;color:var(--nrs-slate)}

/* ── TEAM ────────────────────────────────────────────────────────────── */
.nrs-team{background:var(--nrs-cloud)}
.nrs-team-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:20px;margin-top:52px}
.nrs-team-card{text-align:center}
.nrs-team-portrait{aspect-ratio:1;border-radius:50%;overflow:hidden;margin:0 auto 16px;background:var(--nrs-sky);border:4px solid var(--nrs-cloud);box-shadow:0 0 0 3px var(--nrs-coral)}
/* CSS staff portrait */
.nrs-tp-scene{width:100%;height:100%;position:relative;overflow:hidden}
.nrs-tp-bg2{position:absolute;inset:0;background:linear-gradient(160deg,#e8f4fd 0%,#d0eaf8 100%)}
.nrs-tp-body3{position:absolute;bottom:0;left:50%;transform:translateX(-50%);width:80%;height:35%;border-radius:40% 40% 0 0}
.nrs-tp-neck3{position:absolute;border-radius:50%}
.nrs-tp-head3{position:absolute;border-radius:50% 50% 42% 42%;overflow:hidden}
.nrs-tp-hair3{position:absolute;border-radius:50% 50% 0 0}
.nrs-team-name3{font-family:var(--nrs-ff-head);font-size:1.05rem;font-weight:800;color:var(--nrs-midnight);margin-bottom:4px}
.nrs-team-role3{font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--nrs-coral);margin-bottom:4px}
.nrs-team-quals{font-size:.78rem;color:var(--nrs-slate);line-height:1.5}

/* ── STATS ───────────────────────────────────────────────────────────── */
.nrs-stats{background:var(--nrs-coral);padding:72px 0}
.nrs-stats-grid{display:grid;grid-template-columns:repeat(4,1fr);text-align:center;gap:0}
.nrs-stat-num{font-family:var(--nrs-ff-head);font-size:4rem;font-weight:900;color:#fff;line-height:1}
.nrs-stat-label{font-size:.75rem;font-weight:700;letter-spacing:.15em;text-transform:uppercase;color:rgba(255,255,255,.75);margin-top:8px}
.nrs-stat-div{border-right:2px solid rgba(255,255,255,.25)}

/* ── TESTIMONIALS ────────────────────────────────────────────────────── */
.nrs-testimonials{background:var(--nrs-warm)}
.nrs-test-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-top:52px}
.nrs-test-card{background:var(--nrs-cloud);border-radius:var(--nrs-r);padding:32px 24px;border-top:4px solid var(--nrs-sage)}
.nrs-test-stars{color:var(--nrs-sun);font-size:.9rem;margin-bottom:12px;letter-spacing:.1em}
.nrs-test-text{font-size:.9rem;line-height:1.8;color:var(--nrs-midnight);font-style:italic;margin-bottom:20px}
.nrs-test-author{font-family:var(--nrs-ff-head);font-size:.85rem;font-weight:800;color:var(--nrs-midnight)}
.nrs-test-detail{font-size:.75rem;color:var(--nrs-slate);margin-top:2px}

/* ── FAQ ─────────────────────────────────────────────────────────────── */
.nrs-faq{background:var(--nrs-cloud)}
.nrs-faq-list{margin-top:48px;max-width:780px}
.nrs-faq-item{border-bottom:2px solid var(--nrs-sky)}
.nrs-faq-q{display:flex;justify-content:space-between;align-items:center;padding:18px 0;cursor:pointer;font-family:var(--nrs-ff-head);font-size:1.05rem;font-weight:800;color:var(--nrs-midnight);gap:16px;background:transparent;border:none;text-align:left;width:100%}
.nrs-faq-icon{font-size:1.2rem;color:var(--nrs-coral);flex-shrink:0;transition:transform .3s}
.nrs-faq-item.open .nrs-faq-icon{transform:rotate(45deg)}
.nrs-faq-a{max-height:0;overflow:hidden;transition:max-height .35s ease}
.nrs-faq-item.open .nrs-faq-a{max-height:200px}
.nrs-faq-a p{padding:0 0 18px;font-size:.9rem;color:var(--nrs-slate);line-height:1.75}

/* ── AWARDS ──────────────────────────────────────────────────────────── */
.nrs-awards{background:linear-gradient(135deg,#e8f4fd,#e8f8e8)}
.nrs-awards-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:16px;margin-top:44px}
.nrs-award-card{background:var(--nrs-cloud);border-radius:var(--nrs-r);padding:24px;display:flex;align-items:center;gap:16px;transition:transform .3s}
.nrs-award-card:hover{transform:translateY(-2px)}
.nrs-award-year{font-family:var(--nrs-ff-head);font-size:1.5rem;font-weight:900;color:var(--nrs-coral);min-width:52px}
.nrs-award-name{font-family:var(--nrs-ff-head);font-size:.95rem;font-weight:800;color:var(--nrs-midnight);margin-bottom:4px}
.nrs-award-body{font-size:.78rem;color:var(--nrs-slate)}
.nrs-award-star2{font-size:1.5rem}

/* ── CONTACT ─────────────────────────────────────────────────────────── */
.nrs-contact{background:var(--nrs-warm)}
.nrs-contact-grid{display:grid;grid-template-columns:1fr 1.2fr;gap:72px;align-items:start;margin-top:52px}
.nrs-contact-info p{font-size:.9rem;line-height:1.8;color:var(--nrs-slate);margin-bottom:14px}
.nrs-contact-rows{display:flex;flex-direction:column;gap:12px;margin-top:24px}
.nrs-contact-row{display:flex;align-items:center;gap:12px;font-size:.9rem;color:var(--nrs-slate)}
.nrs-contact-dot{width:40px;height:40px;border-radius:50%;background:var(--nrs-sky);display:flex;align-items:center;justify-content:center;font-size:1rem;flex-shrink:0}
.nrs-form3{background:var(--nrs-cloud);border-radius:var(--nrs-r);padding:36px;box-shadow:0 4px 24px rgba(0,0,0,.05)}
.nrs-form3 label{display:block;font-family:var(--nrs-ff-head);font-size:.72rem;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--nrs-slate);margin-bottom:6px}
.nrs-form3 input,.nrs-form3 select,.nrs-form3 textarea{width:100%;padding:12px 16px;border:2px solid var(--nrs-sky);border-radius:8px;font-family:var(--nrs-ff-body);font-size:.9rem;color:var(--nrs-midnight);margin-bottom:14px;transition:border-color .3s;background:var(--nrs-cloud)}
.nrs-form3 input:focus,.nrs-form3 select:focus,.nrs-form3 textarea:focus{outline:none;border-color:var(--nrs-coral)}
.nrs-form3 textarea{resize:vertical;min-height:80px}
.nrs-form3-row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.nrs-form3-submit{width:100%;padding:14px;background:var(--nrs-coral);color:#fff;border:none;border-radius:50px;font-family:var(--nrs-ff-head);font-size:.9rem;font-weight:800;cursor:pointer;transition:background .3s,transform .2s;box-shadow:0 4px 16px rgba(255,127,92,.3)}
.nrs-form3-submit:hover{background:#ff6a45;transform:translateY(-2px)}

/* ── RESPONSIVE ──────────────────────────────────────────────────────── */
@media(max-width:1024px){
  .nrs-rooms-grid{grid-template-columns:1fr}
  .nrs-activities-grid{grid-template-columns:repeat(2,1fr)}
  .nrs-team-grid{grid-template-columns:repeat(2,1fr)}
  .nrs-contact-grid{grid-template-columns:1fr}
  .nrs-awards-grid{grid-template-columns:1fr}
}
@media(max-width:768px){
  .nrs-section{padding:64px 0}
  .nrs-activities-grid{grid-template-columns:repeat(2,1fr)}
  .nrs-stats-grid{grid-template-columns:repeat(2,1fr)}
  .nrs-test-grid{grid-template-columns:1fr}
  .nrs-form3-row{grid-template-columns:1fr}
}
</style>
<?php get_header(); ?>
<div class="nrs-page">
>

<?php /* ── HERO ─────────────────────────────────────────────────────── */ ?>
<section class="nrs-hero" aria-label="Hero">

  <?php /* Sun */ ?>
  <div class="nrs-sun-ball" aria-hidden="true"></div>
  <div class="nrs-sun-rays" aria-hidden="true">
    <?php for($r=0;$r<12;$r++): ?>
    <div class="nrs-sun-ray" style="transform:rotate(<?=$r*30?>deg) translateX(-50%)"></div>
    <?php endfor; ?>
  </div>

  <?php /* Rainbow */ ?>
  <div class="nrs-rainbow" aria-hidden="true">
    <?php $rainbow_colors=['#ff4444','#ff8800','#ffdd00','#44cc44','#4488ff','#8844cc']; ?>
    <?php foreach(array_reverse($rainbow_colors) as $ri=>$rc): $size=100-$ri*10; ?>
    <div class="nrs-rainbow-stripe" style="left:<?=($ri*5)?>px;right:<?=($ri*5)?>px;height:<?=$size?>px;background:<?=$rc?>;opacity:.7"></div>
    <?php endforeach; ?>
  </div>

  <?php /* Clouds */ ?>
  <?php foreach($clouds as $c): ?>
  <div class="nrs-cloud-el" style="left:<?=$c['x']?>%;top:<?=$c['y']?>%;width:<?=$c['w']?>px;height:<?=round($c['w']*.4)?>px;opacity:<?=round($c['op'],2)?>;animation:nrs-cloud-float <?=$c['dur']?>s <?=round($c['del'],1)?>s ease-in-out infinite alternate" aria-hidden="true"></div>
  <?php endforeach; ?>

  <?php /* Birds */ ?>
  <?php for($b=0;$b<4;$b++): ?>
  <div style="position:absolute;top:<?=rand(8,25)?>%;left:<?=rand(10,60)?>%;animation:nrs-bird-fly <?=rand(8,14)?>s <?=round(lcg_value()*6,1)?>s ease-in-out infinite alternate" aria-hidden="true">
    <svg width="20" height="10" viewBox="0 0 20 10" fill="none" xmlns="http://www.w3.org/2000/svg" opacity=".5">
      <path d="M10 5 Q6 0 0 3 M10 5 Q14 0 20 3" stroke="#1a2d3a" stroke-width="1.5" stroke-linecap="round"/>
    </svg>
  </div>
  <?php endfor; ?>

  <?php /* Ground */ ?>
  <div class="nrs-ground" aria-hidden="true"></div>

  <?php /* Rolling hills */ ?>
  <div class="nrs-hill" style="position:absolute;bottom:28%;right:-5%;width:350px;height:120px;background:#5aaa6a;opacity:.6"></div>
  <div class="nrs-hill" style="position:absolute;bottom:28%;left:-3%;width:280px;height:90px;background:#6aba7a;opacity:.5"></div>

  <?php /* Trees */ ?>
  <?php $tree_positions=[['right:30%'],['right:20%'],['left:42%'],['left:52%']]; ?>
  <?php $tree_sizes=[[50,35,18],[40,28,14],[45,30,16],[38,26,12]]; ?>
  <?php foreach($tree_positions as $ti=>$tp): $ts=$tree_sizes[$ti]; ?>
  <div class="nrs-tree" style="position:absolute;bottom:29%;<?=$tp[0]?>">
    <div class="nrs-tree-top" style="width:<?=$ts[0]?>px;height:<?=$ts[0]?>px"></div>
    <div class="nrs-tree-trunk" style="height:<?=$ts[1]?>px;width:<?=$ts[2]?>px"></div>
  </div>
  <?php endforeach; ?>

  <?php /* Nursery building */ ?>
  <div class="nrs-building" aria-hidden="true">
    <div class="nrs-sign">LITTLE WONDERS</div>
    <div class="nrs-roof">
      <div class="nrs-chimney"></div>
    </div>
    <div class="nrs-building-body">
      <div class="nrs-bwin" style="top:20px;left:15px"></div>
      <div class="nrs-bwin" style="top:20px;right:15px"></div>
      <div class="nrs-bwin" style="top:58px;left:15px"></div>
      <div class="nrs-bwin" style="top:58px;right:15px"></div>
      <div class="nrs-bdoor"><div class="nrs-bdoor-knob"></div></div>
    </div>
  </div>

  <?php /* Playground equipment */ ?>
  <?php /* Slide */ ?>
  <div class="nrs-slide" aria-hidden="true">
    <div class="nrs-slide-steps"></div>
    <div class="nrs-slide-platform"></div>
    <div class="nrs-slide-ramp"></div>
    <?php /* Slide support */ ?>
    <div style="position:absolute;top:10px;right:-22px;width:3px;height:50px;background:#a08850;transform:rotate(-30deg);transform-origin:top"></div>
  </div>

  <?php /* Swing */ ?>
  <div class="nrs-swing" aria-hidden="true">
    <div style="position:relative;width:80px;height:80px">
      <div style="position:absolute;top:0;left:0;width:5px;height:70px;background:#a08050;border-radius:2px;transform:rotate(8deg);transform-origin:top"></div>
      <div style="position:absolute;top:0;right:0;width:5px;height:70px;background:#a08050;border-radius:2px;transform:rotate(-8deg);transform-origin:top"></div>
      <div style="position:absolute;top:0;left:0;right:0;height:5px;background:#8a6030;border-radius:2px"></div>
      <?php /* Swing rope & seat */ ?>
      <div class="nrs-swing-rope" style="position:absolute;top:5px;left:32px;width:2px;height:36px;background:#7a6030;animation:nrs-swing-anim 2.8s ease-in-out infinite alternate">
        <div class="nrs-swing-seat" style="position:absolute;bottom:-6px;left:-11px;width:24px;height:6px;background:#ff9070;border-radius:2px"></div>
      </div>
    </div>
  </div>

  <?php /* Flowers */ ?>
  <?php $flower_positions=['left:18%','left:22%','left:26%','left:60%','left:64%']; ?>
  <?php $flower_colors=['#ff7f5c','#ffd84a','#e080c0','#5a9a7a','#ff7f5c']; ?>
  <?php foreach($flower_positions as $fi=>$fp): ?>
  <div class="nrs-flower" style="<?=$fp?>" aria-hidden="true">
    <div class="nrs-flower-head" style="background:<?=$flower_colors[$fi]?>;position:relative">
      <?php for($p=0;$p<6;$p++): ?>
      <div class="nrs-flower-petal" style="background:<?=$flower_colors[$fi]?>;transform:rotate(<?=$p*60?>deg) translate(-50%,-12px);top:50%;left:50%"></div>
      <?php endfor; ?>
      <div style="position:absolute;inset:4px;border-radius:50%;background:var(--nrs-sun)"></div>
    </div>
    <div class="nrs-flower-stem" style="height:<?=rand(24,40)?>px"></div>
  </div>
  <?php endforeach; ?>

  <?php /* Fence */ ?>
  <div style="position:absolute;bottom:30%;left:0;right:0;height:36px;display:flex;align-items:flex-start;overflow:hidden" aria-hidden="true">
    <?php for($fp=0;$fp<120;$fp++): ?>
    <?php if($fp%3===0): ?>
    <div style="width:10px;height:30px;background:linear-gradient(180deg,#d0b070,#a08040);border-radius:2px 2px 0 0;flex-shrink:0;margin:0 8px"></div>
    <?php endif; ?>
    <?php endfor; ?>
    <div style="position:absolute;top:12px;left:0;right:0;height:5px;background:linear-gradient(90deg,#d0b070,#c0a060);border-radius:2px"></div>
    <div style="position:absolute;top:22px;left:0;right:0;height:4px;background:linear-gradient(90deg,#c0a060,#b09050);border-radius:2px"></div>
  </div>

  <?php /* Hero content */ ?>
  <div class="nrs-container">
    <div class="nrs-hero-inner">
      <div class="nrs-hero-badge">⭐ Ofsted Outstanding 2024</div>
      <h1 class="nrs-hero-h1 nrs-h1">Where little ones <span>grow big</span> dreams</h1>
      <div class="nrs-squiggle"></div>
      <p class="nrs-hero-sub">Award-winning nursery and childcare for children aged 3 months to 5 years. A warm, safe, and joyful environment where every child is known, celebrated, and helped to flourish.</p>
      <div class="nrs-hero-btns">
        <a href="#contact" class="nrs-btn nrs-btn-coral">Book a Visit</a>
        <a href="#rooms" class="nrs-btn nrs-btn-sun">Our Rooms</a>
      </div>
      <div class="nrs-hero-trust">
        <span class="nrs-trust-badge">🌿 3 months – 5 years</span>
        <span class="nrs-trust-badge">🕐 7:30am – 6:30pm</span>
        <span class="nrs-trust-badge">💚 Funded hours accepted</span>
      </div>
    </div>
  </div>
</section>

<?php /* ── MARQUEE ───────────────────────────────────────────────────── */ ?>
<div class="nrs-marquee-wrap" aria-hidden="true">
  <div class="nrs-marquee-track">
    <?php $mi=array_merge($marquee_items,$marquee_items); foreach($mi as $m): ?>
    <span class="nrs-marquee-item"><?=esc_html($m)?></span>
    <?php endforeach; ?>
  </div>
</div>

<?php /* ── ROOMS ────────────────────────────────────────────────────── */ ?>
<section class="nrs-section nrs-rooms" id="rooms">
  <div class="nrs-container">
    <div class="nrs-reveal" style="text-align:center">
      <div class="nrs-label">Our Rooms</div>
      <h2 class="nrs-h2">A space for every stage</h2>
      <div class="nrs-squiggle" style="margin:16px auto"></div>
      <p class="nrs-lead" style="max-width:560px;margin:0 auto">Each room is thoughtfully designed around the developmental stage of the children it serves — with the right resources, the right ratios, and the right people.</p>
    </div>
    <div class="nrs-rooms-grid">
      <?php foreach($rooms as $room): ?>
      <article class="nrs-room-card nrs-reveal" style="border-color:<?=esc_attr($room['color'])?>22">
        <div class="nrs-room-header" style="--nrs-room-color:<?=esc_attr($room['color'])?>">
          <span class="nrs-room-icon"><?=esc_html($room['icon'])?></span>
          <div class="nrs-room-name"><?=esc_html($room['name'])?></div>
          <div class="nrs-room-age"><?=esc_html($room['age'])?></div>
          <span class="nrs-room-ratio">Staff ratio <?=esc_html($room['ratio'])?></span>
        </div>
        <div class="nrs-room-body">
          <p class="nrs-room-desc"><?=esc_html($room['desc'])?></p>
          <div class="nrs-room-feats">
            <?php foreach($room['feats'] as $f): ?>
            <span class="nrs-room-feat"><?=esc_html($f)?></span>
            <?php endforeach; ?>
          </div>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php /* ── ACTIVITIES ────────────────────────────────────────────────── */ ?>
<section class="nrs-section nrs-activities" id="activities">
  <div class="nrs-container">
    <div class="nrs-reveal" style="text-align:center">
      <div class="nrs-label">What We Do</div>
      <h2 class="nrs-h2">Learning through play</h2>
      <div class="nrs-squiggle" style="margin:16px auto"></div>
    </div>
    <div class="nrs-activities-grid">
      <?php foreach($activities as $a): ?>
      <div class="nrs-activity-card nrs-reveal">
        <span class="nrs-activity-icon"><?=esc_html($a['icon'])?></span>
        <div class="nrs-activity-name"><?=esc_html($a['name'])?></div>
        <p class="nrs-activity-desc"><?=esc_html($a['desc'])?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php /* ── STATS ────────────────────────────────────────────────────── */ ?>
<section class="nrs-stats">
  <div class="nrs-container">
    <div class="nrs-stats-grid">
      <?php $nrs_stats=[['n'=>'320','s'=>'+','l'=>'Happy Children'],['n'=>'14','s'=>'','l'=>'Years Established'],['n'=>'98','s'=>'%','l'=>'Parent Satisfaction'],['n'=>'4','s'=>'','l'=>'Award Wins 2024']]; ?>
      <?php foreach($nrs_stats as $i=>$st): ?>
      <div class="nrs-reveal<?=$i<3?' nrs-stat-div':''?>" style="padding:0 32px">
        <div class="nrs-stat-num" data-target="<?=esc_attr($st['n'])?>" data-suffix="<?=esc_attr($st['s'])?>"><?=esc_html($st['n'].$st['s'])?></div>
        <div class="nrs-stat-label"><?=esc_html($st['l'])?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php /* ── TEAM ─────────────────────────────────────────────────────── */ ?>
<section class="nrs-section nrs-team" id="team">
  <div class="nrs-container">
    <div class="nrs-reveal" style="text-align:center">
      <div class="nrs-label">Meet Our Team</div>
      <h2 class="nrs-h2">Your child's people</h2>
      <div class="nrs-squiggle" style="margin:16px auto"></div>
      <p class="nrs-lead" style="max-width:540px;margin:0 auto">Every member of our team holds a Level 3 qualification or above. We invest in continuous training, first aid, and safeguarding — and our average tenure is over 5 years.</p>
    </div>
    <div class="nrs-team-grid">
      <?php foreach($team as $ti=>$t): ?>
      <article class="nrs-team-card nrs-reveal">
        <div class="nrs-team-portrait" style="width:150px;height:150px">
          <div class="nrs-tp-scene">
            <div class="nrs-tp-bg2"></div>
            <?php /* Body / uniform */ ?>
            <div class="nrs-tp-body3" style="background:linear-gradient(160deg,<?=$ti===0?'#5a9a7a':'#ff7f5c'?>,<?=$ti===0?'#3a7a5a':'#e06040'?>)"></div>
            <?php /* Neck */ ?>
            <div class="nrs-tp-neck3" style="position:absolute;bottom:34%;left:50%;transform:translateX(-50%);width:22px;height:18px;background:<?=$t['skin']?>;border-radius:50%"></div>
            <?php /* Head */ ?>
            <div class="nrs-tp-head3" style="position:absolute;bottom:46%;left:50%;transform:translateX(-50%);width:48px;height:54px;background:<?=$t['skin']?>">
              <div class="nrs-tp-hair3" style="position:absolute;top:0;left:0;right:0;height:<?=$ti===0||$ti===3?46:38?>%;background:<?=$t['hair']?>;border-radius:50% 50% 0 0"></div>
              <?php if($ti===0): /* bun */ ?>
              <div style="position:absolute;top:-8px;right:4px;width:12px;height:12px;border-radius:50%;background:<?=$t['hair']?>"></div>
              <?php endif; ?>
              <?php if($ti===3): /* ponytail */ ?>
              <div style="position:absolute;top:0;right:-8px;width:8px;height:28px;background:<?=$t['hair']?>;border-radius:2px;transform:rotate(10deg);transform-origin:top"></div>
              <?php endif; ?>
              <div style="position:absolute;top:52%;left:50%;transform:translateX(-50%);display:flex;gap:7px">
                <div style="width:5px;height:5px;border-radius:50%;background:#2a1a0a"></div>
                <div style="width:5px;height:5px;border-radius:50%;background:#2a1a0a"></div>
              </div>
              <div style="position:absolute;top:68%;left:50%;transform:translateX(-50%);width:12px;height:6px;border-bottom:2px solid rgba(200,120,60,.4);border-radius:0 0 50% 50%"></div>
            </div>
          </div>
        </div>
        <div class="nrs-team-name3"><?=esc_html($t['name'])?></div>
        <div class="nrs-team-role3"><?=esc_html($t['role'])?></div>
        <div class="nrs-team-quals"><?=esc_html($t['quals'])?></div>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php /* ── TESTIMONIALS ──────────────────────────────────────────────── */ ?>
<section class="nrs-section nrs-testimonials" id="reviews">
  <div class="nrs-container">
    <div class="nrs-reveal" style="text-align:center">
      <div class="nrs-label">What Parents Say</div>
      <h2 class="nrs-h2">Happy families</h2>
      <div class="nrs-squiggle" style="margin:16px auto"></div>
    </div>
    <div class="nrs-test-grid">
      <?php foreach($testimonials as $t): ?>
      <blockquote class="nrs-test-card nrs-reveal">
        <div class="nrs-test-stars">★★★★★</div>
        <p class="nrs-test-text">"<?=esc_html($t['text'])?>"</p>
        <footer>
          <div class="nrs-test-author"><?=esc_html($t['author'])?></div>
          <div class="nrs-test-detail"><?=esc_html($t['detail'])?></div>
        </footer>
      </blockquote>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php /* ── AWARDS ───────────────────────────────────────────────────── */ ?>
<section class="nrs-section nrs-awards" id="awards">
  <div class="nrs-container">
    <div class="nrs-reveal" style="text-align:center">
      <div class="nrs-label">Recognition</div>
      <h2 class="nrs-h2">Proud to be recognised</h2>
      <div class="nrs-squiggle" style="margin:16px auto"></div>
    </div>
    <div class="nrs-awards-grid">
      <?php $award_icons=['⭐','🏆','🌿','🌟']; ?>
      <?php foreach($awards_list as $i=>$aw): ?>
      <div class="nrs-award-card nrs-reveal">
        <div class="nrs-award-year"><?=esc_html($aw['year'])?></div>
        <div>
          <div class="nrs-award-name"><?=esc_html($aw['name'])?></div>
          <div class="nrs-award-body"><?=esc_html($aw['body'])?></div>
        </div>
        <div class="nrs-award-star2"><?=esc_html($award_icons[$i])?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php /* ── FAQ ───────────────────────────────────────────────────────── */ ?>
<section class="nrs-section nrs-faq" id="faq">
  <div class="nrs-container">
    <div class="nrs-reveal">
      <div class="nrs-label">Questions</div>
      <h2 class="nrs-h2">Things parents ask us</h2>
      <div class="nrs-squiggle"></div>
    </div>
    <div class="nrs-faq-list nrs-reveal">
      <?php foreach($faqs as $i=>$f): ?>
      <div class="nrs-faq-item">
        <button class="nrs-faq-q" aria-expanded="false" aria-controls="nrs-faq-a-<?=$i?>"><?=esc_html($f['q'])?><span class="nrs-faq-icon" aria-hidden="true">+</span></button>
        <div class="nrs-faq-a" id="nrs-faq-a-<?=$i?>" role="region"><p><?=esc_html($f['a'])?></p></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php /* ── CONTACT ───────────────────────────────────────────────────── */ ?>
<section class="nrs-section nrs-contact" id="contact">
  <div class="nrs-container">
    <div class="nrs-reveal">
      <div class="nrs-label">Get in Touch</div>
      <h2 class="nrs-h2">Come and say hello 👋</h2>
      <div class="nrs-squiggle"></div>
      <p class="nrs-lead" style="max-width:500px">We'd love to show you around. Book a visit, ask about availability, or just come and see if we feel right for your family — no obligation at all.</p>
    </div>
    <div class="nrs-contact-grid">
      <div class="nrs-reveal">
        <p>Our team is friendly, experienced, and always happy to answer questions. Don't worry if you're still early in your search — we can help you understand your options, funding entitlements, and what to look for in a nursery.</p>
        <p>We offer free settling-in visits before any commitment, and our admin team can walk you through the registration process step by step.</p>
        <div class="nrs-contact-rows">
          <div class="nrs-contact-row"><div class="nrs-contact-dot">📞</div><span>01234 567 890</span></div>
          <div class="nrs-contact-row"><div class="nrs-contact-dot">✉️</div><span>hello@littlewonders-nursery.co.uk</span></div>
          <div class="nrs-contact-row"><div class="nrs-contact-dot">🕐</div><span>Mon–Fri 7:30am–6:30pm</span></div>
          <div class="nrs-contact-row"><div class="nrs-contact-dot">📍</div><span>12 Garden Lane, Guildford, GU1 4AB</span></div>
        </div>
      </div>
      <div class="nrs-form3 nrs-reveal">
        <form id="nrs-contact-form" novalidate>
          <?php wp_nonce_field('tf_nrs_enquiry','tf_nrs_nonce'); ?>
          <div class="nrs-form3-row">
            <div><label for="nrs-parent">Your Name</label><input type="text" id="nrs-parent" name="parent_name" placeholder="Sarah Smith" required></div>
            <div><label for="nrs-phone">Phone</label><input type="tel" id="nrs-phone" name="phone" placeholder="07…"></div>
          </div>
          <div><label for="nrs-email">Email</label><input type="email" id="nrs-email" name="email" placeholder="sarah@example.com" required></div>
          <div class="nrs-form3-row">
            <div><label for="nrs-child-name">Child's Name</label><input type="text" id="nrs-child-name" name="child_name" placeholder="Noah"></div>
            <div><label for="nrs-dob">Date of Birth</label><input type="date" id="nrs-dob" name="dob"></div>
          </div>
          <div>
            <label for="nrs-room-interest">Room of Interest</label>
            <select id="nrs-room-interest" name="room">
              <option value="">Not sure yet</option>
              <?php foreach($rooms as $r): ?>
              <option value="<?=esc_attr($r['name'])?>"><?=esc_html($r['name'])?> (<?=esc_html($r['age'])?>)</option>
              <?php endforeach; ?>
            </select>
          </div>
          <div>
            <label for="nrs-start">Anticipated Start Date</label>
            <select id="nrs-start" name="start">
              <option value="">Not sure yet</option>
              <option value="asap">As soon as possible</option>
              <option value="1month">Within 1 month</option>
              <option value="3months">1–3 months</option>
              <option value="6months">3–6 months</option>
              <option value="later">6+ months</option>
            </select>
          </div>
          <div><label for="nrs-notes">Anything else we should know?</label><textarea id="nrs-notes" name="notes" placeholder="Hours needed, any extra needs, questions for us…"></textarea></div>
          <button type="submit" class="nrs-form3-submit">Send Enquiry 🌟</button>
        </form>
        <p id="nrs-form-msg" style="display:none;text-align:center;margin-top:14px;font-size:.9rem;color:var(--nrs-sage);font-weight:600"></p>
      </div>
    </div>
  </div>
</section>

<script>
(function(){
  /* ── Scroll reveal ─────────────────────────────────────────────── */
  const reveals=document.querySelectorAll('.nrs-reveal');
  if('IntersectionObserver' in window){
    const obs=new IntersectionObserver(entries=>{
      entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');obs.unobserve(e.target)}});
    },{threshold:.1});
    reveals.forEach(el=>obs.observe(el));
  } else {reveals.forEach(el=>el.classList.add('visible'));}

  /* ── Counters ──────────────────────────────────────────────────── */
  const easeOut=t=>1-Math.pow(1-t,3);
  document.querySelectorAll('[data-target]').forEach(el=>{
    const o=new IntersectionObserver(entries=>{
      if(!entries[0].isIntersecting) return;
      const target=parseInt(el.dataset.target,10);
      const suffix=el.dataset.suffix||'';
      const dur=1400;const start=performance.now();
      function tick(now){
        const t=Math.min((now-start)/dur,1);
        el.textContent=Math.round(easeOut(t)*target)+suffix;
        if(t<1) requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
      o.unobserve(el);
    },{threshold:.4});
    o.observe(el);
  });

  /* ── FAQ accordion ─────────────────────────────────────────────── */
  document.querySelectorAll('.nrs-faq-item').forEach(item=>{
    const btn=item.querySelector('.nrs-faq-q');
    btn.addEventListener('click',()=>{
      const isOpen=item.classList.contains('open');
      document.querySelectorAll('.nrs-faq-item').forEach(i=>{i.classList.remove('open');i.querySelector('.nrs-faq-q').setAttribute('aria-expanded','false')});
      if(!isOpen){item.classList.add('open');btn.setAttribute('aria-expanded','true')}
    });
  });

  /* ── Form ──────────────────────────────────────────────────────── */
  const form=document.getElementById('nrs-contact-form');
  if(form){
    form.addEventListener('submit',e=>{
      e.preventDefault();
      const btn=form.querySelector('.nrs-form3-submit');
      const msg=document.getElementById('nrs-form-msg');
      btn.textContent='Sending… 🌟';btn.disabled=true;
      setTimeout(()=>{
        btn.textContent='Sent! We\'ll be in touch soon 🎉';
        btn.style.background='#5a9a7a';
        msg.textContent='Thank you! A member of our team will contact you within one working day to arrange your visit.';
        msg.style.display='block';
      },900);
    });
  }
})();
</script>
</div><!-- .nrs-page -->
<?php get_footer(); ?>
