<?php
/**
 * Template Name: Childminder
 * Description: Premium Childminder / Childcare page template — full CSS art-directed hero
 */
get_header(); ?>

<!-- GOOGLE FONTS: Nunito + Poppins -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,400;0,600;0,700;0,800;1,400&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>
/* ============================================================
   CHILDMINDER TEMPLATE — --cm-* namespace
   Palette: sunshine #FFD600 / sky #42A5F5 / grass #66BB6A / rose #F48FB1 / peach #FFAB91 / cream #FFFDF0
   ============================================================ */
:root {
  --cm-sun:      #FFD600;
  --cm-sun-dk:   #F9A825;
  --cm-sky:      #42A5F5;
  --cm-sky-dk:   #1E88E5;
  --cm-sky-lt:   #90CAF9;
  --cm-grass:    #66BB6A;
  --cm-grass-dk: #43A047;
  --cm-rose:     #F48FB1;
  --cm-rose-dk:  #E91E63;
  --cm-peach:    #FFAB91;
  --cm-cream:    #FFFDF0;
  --cm-white:    #FFFFFF;
  --cm-charcoal: #3E3E4A;
  --cm-grey:     #7B7B8D;
  --cm-radius:   16px;
  --cm-shadow:   0 8px 32px rgba(66,165,245,0.15);
  --cm-font-head:'Nunito', system-ui, sans-serif;
  --cm-font-body:'Poppins', system-ui, sans-serif;
}

.cm-wrap * { box-sizing: border-box; margin: 0; padding: 0; }
.cm-wrap { font-family: var(--cm-font-body); color: var(--cm-charcoal); background: var(--cm-white); }

/* ── HERO ── */
.cm-hero {
  position: relative;
  min-height: 100vh;
  background: linear-gradient(160deg, var(--cm-sky-dk) 0%, var(--cm-sky) 40%, #81D4FA 70%, #E1F5FE 100%);
  overflow: hidden;
  display: flex;
  align-items: center;
}

/* Floating clouds */
.cm-cloud {
  position: absolute;
  background: rgba(255,255,255,0.7);
  border-radius: 50px;
}
.cm-cloud::before,
.cm-cloud::after {
  content: '';
  position: absolute;
  background: rgba(255,255,255,0.7);
  border-radius: 50%;
}
.cm-cloud-1 { width: 120px; height: 40px; top: 12%; left: 8%; animation: cm-cloud-drift 18s linear infinite; }
.cm-cloud-1::before { width: 60px; height: 60px; top: -30px; left: 20px; }
.cm-cloud-1::after  { width: 40px; height: 40px; top: -20px; left: 55px; }
.cm-cloud-2 { width: 90px; height: 30px; top: 20%; left: 55%; animation: cm-cloud-drift 24s linear infinite 5s; }
.cm-cloud-2::before { width: 45px; height: 45px; top: -22px; left: 15px; }
.cm-cloud-2::after  { width: 30px; height: 30px; top: -14px; left: 45px; }
.cm-cloud-3 { width: 70px; height: 24px; top: 8%; right: 15%; animation: cm-cloud-drift 20s linear infinite 10s; }
.cm-cloud-3::before { width: 36px; height: 36px; top: -18px; left: 12px; }
.cm-cloud-3::after  { width: 24px; height: 24px; top: -10px; left: 36px; }
@keyframes cm-cloud-drift {
  from { transform: translateX(-50px); }
  to   { transform: translateX(50px); }
}

/* Sun */
.cm-sun {
  position: absolute;
  top: 8%;
  right: 8%;
  width: 90px;
  height: 90px;
  background: var(--cm-sun);
  border-radius: 50%;
  box-shadow: 0 0 0 15px rgba(255,214,0,0.15), 0 0 0 30px rgba(255,214,0,0.08);
  animation: cm-sun-pulse 4s ease-in-out infinite;
}
.cm-sun::before {
  content: '';
  position: absolute;
  inset: -20px;
  background: repeating-conic-gradient(transparent 0deg, transparent 30deg, rgba(255,214,0,0.3) 30deg, rgba(255,214,0,0.3) 36deg);
  border-radius: 50%;
  animation: cm-sun-spin 20s linear infinite;
}
@keyframes cm-sun-pulse {
  0%, 100% { box-shadow: 0 0 0 15px rgba(255,214,0,0.15), 0 0 0 30px rgba(255,214,0,0.08); }
  50%       { box-shadow: 0 0 0 20px rgba(255,214,0,0.2),  0 0 0 40px rgba(255,214,0,0.1); }
}
@keyframes cm-sun-spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }

/* Colourful balloons */
.cm-balloon {
  position: absolute;
  width: 40px;
  height: 50px;
  border-radius: 50% 50% 50% 50% / 60% 60% 40% 40%;
  animation: cm-balloon-drift 6s ease-in-out infinite alternate;
}
.cm-balloon::after {
  content: '';
  position: absolute;
  bottom: -20px;
  left: 50%;
  transform: translateX(-50%);
  width: 1px;
  height: 22px;
  background: rgba(0,0,0,0.2);
}
.cm-balloon-1 { background: var(--cm-rose-dk);  left: 5%;  top: 25%; animation-delay: 0s; }
.cm-balloon-2 { background: var(--cm-grass);     left: 12%; top: 35%; animation-delay: 1s; }
.cm-balloon-3 { background: var(--cm-sun-dk);    left: 7%;  top: 18%; animation-delay: 2s; }
@keyframes cm-balloon-drift {
  from { transform: translateY(0) rotate(-5deg); }
  to   { transform: translateY(-20px) rotate(5deg); }
}

/* CSS PLAYROOM SCENE */
.cm-scene {
  position: absolute;
  right: 4%;
  bottom: 0;
  width: 460px;
  height: 560px;
}

/* Grass ground */
.cm-ground {
  position: absolute;
  bottom: 0;
  left: -40px;
  right: -40px;
  height: 90px;
  background: linear-gradient(180deg, var(--cm-grass) 0%, var(--cm-grass-dk) 100%);
  border-radius: 20px 20px 0 0;
}
.cm-ground::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 12px;
  background: repeating-linear-gradient(90deg,
    transparent 0px, transparent 18px,
    rgba(102,187,106,0.5) 18px, rgba(102,187,106,0.5) 20px
  );
  border-radius: 20px 20px 0 0;
}

/* House */
.cm-house {
  position: absolute;
  bottom: 88px;
  left: 30px;
  width: 200px;
}
.cm-house-roof {
  width: 0;
  height: 0;
  border-left: 110px solid transparent;
  border-right: 110px solid transparent;
  border-bottom: 80px solid #E53935;
  position: relative;
  left: -10px;
}
.cm-house-body {
  width: 200px;
  height: 120px;
  background: linear-gradient(180deg, #FFECB3 0%, #FFE082 100%);
  border-radius: 0 0 8px 8px;
  position: relative;
  border: 3px solid #F9A825;
}
/* Window */
.cm-window {
  position: absolute;
  width: 50px;
  height: 50px;
  background: linear-gradient(135deg, var(--cm-sky-lt) 0%, var(--cm-sky) 100%);
  border: 3px solid #FFB300;
  border-radius: 8px;
  top: 20px;
  left: 16px;
}
.cm-window::before {
  content: '';
  position: absolute;
  inset: 4px;
  background: transparent;
  border: 1px solid rgba(255,255,255,0.5);
}
/* Door */
.cm-door {
  position: absolute;
  width: 40px;
  height: 60px;
  background: linear-gradient(180deg, #8D6E63 0%, #6D4C41 100%);
  border-radius: 20px 20px 0 0;
  bottom: 0;
  right: 24px;
  border: 2px solid #5D4037;
}
.cm-door::before {
  content: '';
  position: absolute;
  width: 8px;
  height: 8px;
  background: #FFD600;
  border-radius: 50%;
  top: 50%;
  left: 4px;
}

/* Childminder figure */
.cm-figure {
  position: absolute;
  bottom: 86px;
  right: 60px;
}
.cm-fig-head {
  width: 54px;
  height: 54px;
  background: linear-gradient(180deg, #FFCCBC 0%, #FFAB91 100%);
  border-radius: 50%;
  margin: 0 auto 2px;
  position: relative;
}
.cm-fig-hair {
  position: absolute;
  top: -4px;
  left: 5px;
  right: 5px;
  height: 24px;
  background: #795548;
  border-radius: 50% 50% 0 0;
}
.cm-fig-hair::after {
  content: '';
  position: absolute;
  bottom: -6px;
  left: -4px;
  width: 12px;
  height: 16px;
  background: #795548;
  border-radius: 0 0 6px 8px;
}
.cm-fig-head::after {
  content: '😊';
  position: absolute;
  bottom: 8px;
  left: 50%;
  transform: translateX(-50%);
  font-size: 1.1rem;
}
.cm-fig-body {
  width: 64px;
  height: 90px;
  background: linear-gradient(180deg, var(--cm-rose) 0%, var(--cm-rose-dk) 100%);
  border-radius: 12px 12px 6px 6px;
  margin: 0 auto;
  position: relative;
  border-bottom: 4px solid #C2185B;
}
/* Apron */
.cm-fig-body::before {
  content: '';
  position: absolute;
  top: 8px;
  left: 50%;
  transform: translateX(-50%);
  width: 28px;
  height: 60px;
  background: var(--cm-white);
  border-radius: 6px;
  opacity: 0.8;
}
.cm-fig-body::after {
  content: '★';
  position: absolute;
  top: 14px;
  left: 50%;
  transform: translateX(-50%);
  font-size: 0.8rem;
  color: var(--cm-sun);
  z-index: 1;
}

/* Child figure (held hand) */
.cm-child-fig {
  position: absolute;
  bottom: 86px;
  right: 128px;
}
.cm-child-head {
  width: 36px;
  height: 36px;
  background: linear-gradient(180deg, #FFCCBC 0%, #FFAB91 100%);
  border-radius: 50%;
  position: relative;
}
.cm-child-hair {
  position: absolute;
  top: -4px;
  left: 3px;
  right: 3px;
  height: 16px;
  background: #FF8F00;
  border-radius: 50% 50% 0 0;
}
.cm-child-head::after {
  content: '😄';
  position: absolute;
  bottom: 4px;
  left: 50%;
  transform: translateX(-50%);
  font-size: 0.75rem;
}
.cm-child-body {
  width: 36px;
  height: 50px;
  background: linear-gradient(180deg, #42A5F5 0%, #1E88E5 100%);
  border-radius: 8px 8px 4px 4px;
  margin: 0 auto;
}

/* Arm connecting figures */
.cm-holding-arm {
  position: absolute;
  bottom: 110px;
  right: 122px;
  width: 50px;
  height: 10px;
  background: linear-gradient(90deg, #FFCCBC 0%, var(--cm-rose) 100%);
  border-radius: 5px;
  transform: rotate(-5deg);
}

/* Toy / ball on ground */
.cm-ball {
  position: absolute;
  bottom: 92px;
  left: 50px;
  width: 30px;
  height: 30px;
  border-radius: 50%;
  background: linear-gradient(135deg, var(--cm-rose-dk) 0%, var(--cm-peach) 100%);
  animation: cm-ball-bounce 1.5s ease-in-out infinite;
}
@keyframes cm-ball-bounce {
  0%, 100% { transform: translateY(0); }
  50%       { transform: translateY(-12px); }
}

/* Floating stars */
<?php srand(crc32('cm-stars')); ?>
.cm-star {
  position: absolute;
  color: var(--cm-sun);
  font-size: 1.2rem;
  animation: cm-star-twinkle 2s ease-in-out infinite alternate;
  pointer-events: none;
}
@keyframes cm-star-twinkle {
  from { opacity: 0.3; transform: scale(0.8); }
  to   { opacity: 1;   transform: scale(1.2); }
}

/* Floating info pills */
.cm-pill {
  position: absolute;
  background: rgba(255,255,255,0.9);
  backdrop-filter: blur(6px);
  border-radius: 50px;
  padding: 8px 16px;
  font-family: var(--cm-font-head);
  font-size: 0.8rem;
  font-weight: 800;
  color: var(--cm-charcoal);
  box-shadow: 0 4px 16px rgba(0,0,0,0.12);
  animation: cm-pill-float 5s ease-in-out infinite alternate;
}
.cm-pill-1 { top: 80px;  left: 10px; animation-delay: 0s; color: var(--cm-sky-dk); }
.cm-pill-2 { top: 160px; left: 20px; animation-delay: 1.5s; color: var(--cm-grass-dk); }
.cm-pill-3 { top: 240px; left: 5px;  animation-delay: 3s; color: var(--cm-rose-dk); }
@keyframes cm-pill-float {
  from { transform: translateY(0); }
  to   { transform: translateY(-14px); }
}

/* Hero content */
.cm-hero-inner {
  position: relative;
  z-index: 2;
  max-width: 1280px;
  margin: 0 auto;
  padding: 120px 5% 80px;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 60px;
  align-items: center;
  width: 100%;
}
.cm-hero-text { color: var(--cm-white); }
.cm-hero-tag {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: rgba(255,255,255,0.2);
  border: 1px solid rgba(255,255,255,0.4);
  border-radius: 50px;
  padding: 6px 18px;
  font-size: 0.8rem;
  font-weight: 800;
  letter-spacing: 0.06em;
  margin-bottom: 20px;
}
.cm-hero h1 {
  font-family: var(--cm-font-head);
  font-size: clamp(2.4rem, 5vw, 3.8rem);
  font-weight: 800;
  line-height: 1.1;
  margin-bottom: 20px;
  text-shadow: 0 2px 12px rgba(0,0,0,0.15);
}
.cm-hero h1 span { color: var(--cm-sun); }
.cm-hero-sub {
  font-size: 1.05rem;
  opacity: 0.92;
  line-height: 1.7;
  margin-bottom: 32px;
  max-width: 500px;
}
.cm-hero-ctas { display: flex; gap: 14px; flex-wrap: wrap; }
.cm-btn-primary {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: var(--cm-sun);
  color: var(--cm-charcoal);
  padding: 16px 32px;
  border-radius: 50px;
  font-family: var(--cm-font-head);
  font-weight: 800;
  font-size: 1rem;
  text-decoration: none;
  transition: all 0.3s;
  box-shadow: 0 4px 20px rgba(255,214,0,0.4);
}
.cm-btn-primary:hover { background: var(--cm-sun-dk); transform: translateY(-2px); box-shadow: 0 8px 28px rgba(255,214,0,0.5); }
.cm-btn-secondary {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: rgba(255,255,255,0.2);
  border: 2px solid rgba(255,255,255,0.6);
  color: var(--cm-white);
  padding: 14px 26px;
  border-radius: 50px;
  font-family: var(--cm-font-head);
  font-weight: 800;
  font-size: 1rem;
  text-decoration: none;
  transition: all 0.3s;
}
.cm-btn-secondary:hover { background: rgba(255,255,255,0.3); }

.cm-hero-stats {
  display: flex;
  gap: 32px;
  margin-top: 44px;
  padding-top: 28px;
  border-top: 1px solid rgba(255,255,255,0.25);
}
.cm-hero-stat { color: var(--cm-white); }
.cm-hero-stat-num {
  font-family: var(--cm-font-head);
  font-size: 2rem;
  font-weight: 800;
  display: block;
  text-shadow: 0 2px 8px rgba(0,0,0,0.15);
}
.cm-hero-stat-lbl {
  font-size: 0.78rem;
  opacity: 0.8;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  font-weight: 600;
}

/* ── TRUST RAINBOW BAR ── */
.cm-trust {
  background: var(--cm-charcoal);
  padding: 18px 5%;
}
.cm-trust-inner {
  max-width: 1280px;
  margin: 0 auto;
  display: flex;
  align-items: center;
  gap: 32px;
  flex-wrap: wrap;
  justify-content: center;
}
.cm-trust-item {
  color: rgba(255,255,255,0.8);
  font-size: 0.82rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 8px;
}

/* ── SECTION BASE ── */
.cm-section { padding: 90px 5%; }
.cm-section-inner { max-width: 1280px; margin: 0 auto; }
.cm-section-tag {
  display: inline-block;
  background: rgba(66,165,245,0.12);
  color: var(--cm-sky-dk);
  font-size: 0.72rem;
  font-weight: 700;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  padding: 5px 14px;
  border-radius: 50px;
  margin-bottom: 10px;
}
.cm-section-title {
  font-family: var(--cm-font-head);
  font-size: clamp(1.8rem, 3.5vw, 2.7rem);
  font-weight: 800;
  color: var(--cm-charcoal);
  margin-bottom: 14px;
  line-height: 1.2;
}
.cm-section-sub {
  color: var(--cm-grey);
  font-size: 1rem;
  line-height: 1.7;
  max-width: 580px;
}

/* ── WHY CHOOSE ── */
.cm-why { background: var(--cm-cream); }
.cm-why-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 24px;
  margin-top: 48px;
}
.cm-why-card {
  background: var(--cm-white);
  border-radius: var(--cm-radius);
  padding: 30px 24px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.06);
  transition: all 0.3s;
  text-align: center;
}
.cm-why-card:hover { transform: translateY(-6px); box-shadow: var(--cm-shadow); }
.cm-why-icon {
  font-size: 2.4rem;
  display: block;
  margin-bottom: 14px;
}
.cm-why-card h3 {
  font-family: var(--cm-font-head);
  font-weight: 800;
  font-size: 1.05rem;
  margin-bottom: 8px;
  color: var(--cm-charcoal);
}
.cm-why-card p { font-size: 0.86rem; color: var(--cm-grey); line-height: 1.6; }

/* ── DAILY ROUTINE ── */
.cm-routine-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 20px;
  margin-top: 48px;
}
.cm-routine-item {
  text-align: center;
  padding: 24px 16px;
  border-radius: var(--cm-radius);
  transition: all 0.3s;
  position: relative;
}
.cm-routine-item:nth-child(1) { background: rgba(255,214,0,0.12); border: 2px solid rgba(255,214,0,0.3); }
.cm-routine-item:nth-child(2) { background: rgba(66,165,245,0.1);  border: 2px solid rgba(66,165,245,0.25); }
.cm-routine-item:nth-child(3) { background: rgba(102,187,106,0.1); border: 2px solid rgba(102,187,106,0.25); }
.cm-routine-item:nth-child(4) { background: rgba(244,143,177,0.1); border: 2px solid rgba(244,143,177,0.3); }
.cm-routine-item:nth-child(5) { background: rgba(255,171,145,0.1); border: 2px solid rgba(255,171,145,0.3); }
.cm-routine-item:nth-child(6) { background: rgba(66,165,245,0.1);  border: 2px solid rgba(66,165,245,0.25); }
.cm-routine-item:hover { transform: translateY(-4px); }
.cm-routine-time {
  font-family: var(--cm-font-head);
  font-size: 0.78rem;
  font-weight: 800;
  color: var(--cm-grey);
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-bottom: 8px;
}
.cm-routine-icon { font-size: 2rem; display: block; margin-bottom: 10px; }
.cm-routine-item h3 {
  font-family: var(--cm-font-head);
  font-weight: 800;
  font-size: 0.95rem;
  color: var(--cm-charcoal);
  margin-bottom: 6px;
}
.cm-routine-item p { font-size: 0.82rem; color: var(--cm-grey); line-height: 1.5; }

/* ── ABOUT ── */
.cm-about { background: var(--cm-cream); }
.cm-about-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 80px;
  align-items: center;
}
.cm-about-visual {
  position: relative;
  height: 400px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.cm-about-bg {
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, #E3F2FD 0%, #FFF9C4 100%);
  border-radius: 20px;
}
/* Big smiley */
.cm-big-smiley {
  position: absolute;
  font-size: 7rem;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -60%);
  animation: cm-bounce-soft 3s ease-in-out infinite;
}
@keyframes cm-bounce-soft {
  0%, 100% { transform: translate(-50%, -60%) rotate(-5deg); }
  50%       { transform: translate(-50%, -65%) rotate(5deg); }
}
/* Stars around it */
.cm-about-star {
  position: absolute;
  font-size: 1.5rem;
  animation: cm-star-spin 8s linear infinite;
}
@keyframes cm-star-spin {
  from { transform: rotate(0deg) translateX(100px) rotate(0deg); }
  to   { transform: rotate(360deg) translateX(100px) rotate(-360deg); }
}
.cm-about-star:nth-child(2) { animation-delay: -2s; }
.cm-about-star:nth-child(3) { animation-delay: -4s; }
.cm-about-star:nth-child(4) { animation-delay: -6s; }
/* Ofsted badge */
.cm-ofsted-badge {
  position: absolute;
  bottom: 20px;
  right: 20px;
  background: var(--cm-white);
  border-radius: 12px;
  padding: 14px 18px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.12);
  text-align: center;
  font-family: var(--cm-font-head);
}
.cm-ofsted-badge .cm-big { font-size: 1.8rem; font-weight: 800; color: var(--cm-grass-dk); display: block; }
.cm-ofsted-badge .cm-lbl { font-size: 0.7rem; font-weight: 700; color: var(--cm-grey); text-transform: uppercase; }

.cm-about-text .cm-section-sub { max-width: 100%; }
.cm-about-quals {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin: 24px 0;
}
.cm-qual-row {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 0.88rem;
  color: var(--cm-charcoal);
}
.cm-qual-row::before { content: '✓'; color: var(--cm-grass-dk); font-weight: 800; width: 18px; flex-shrink: 0; }
.cm-about-quote {
  background: linear-gradient(135deg, var(--cm-sky-dk) 0%, var(--cm-sky) 100%);
  color: var(--cm-white);
  padding: 22px 26px;
  border-radius: var(--cm-radius);
  font-family: var(--cm-font-head);
  font-size: 0.95rem;
  font-style: italic;
  line-height: 1.65;
  margin-top: 16px;
}

/* ── ACTIVITIES ── */
.cm-activities-section {
  background: linear-gradient(135deg, var(--cm-charcoal) 0%, #2C3E50 100%);
}
.cm-activities-section .cm-section-tag { background: rgba(255,214,0,0.15); color: var(--cm-sun); }
.cm-activities-section .cm-section-title { color: var(--cm-white); }
.cm-activities-section .cm-section-sub { color: rgba(255,255,255,0.7); }
.cm-activities-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 16px;
  margin-top: 48px;
}
.cm-activity-tile {
  background: rgba(255,255,255,0.07);
  border: 1px solid rgba(255,255,255,0.12);
  border-radius: var(--cm-radius);
  padding: 24px 16px;
  text-align: center;
  transition: all 0.3s;
}
.cm-activity-tile:hover { background: rgba(255,255,255,0.15); transform: translateY(-4px); }
.cm-activity-tile .cm-act-icon { font-size: 2rem; display: block; margin-bottom: 10px; }
.cm-activity-tile p { font-size: 0.82rem; color: rgba(255,255,255,0.8); font-weight: 600; }

/* ── PACKAGES ── */
.cm-packages-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
  margin-top: 52px;
}
.cm-package {
  border-radius: var(--cm-radius);
  padding: 32px 24px;
  border: 2px solid #EEF0F3;
  background: var(--cm-white);
  transition: all 0.3s;
  position: relative;
}
.cm-package:hover { box-shadow: var(--cm-shadow); }
.cm-package-featured {
  background: linear-gradient(135deg, var(--cm-sky-dk) 0%, var(--cm-sky) 100%);
  border-color: var(--cm-sky);
  transform: scale(1.03);
}
.cm-package-featured:hover { transform: scale(1.06); }
.cm-pkg-badge {
  position: absolute;
  top: -13px;
  left: 50%;
  transform: translateX(-50%);
  background: var(--cm-rose-dk);
  color: var(--cm-white);
  font-size: 0.68rem;
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  padding: 4px 14px;
  border-radius: 50px;
  white-space: nowrap;
}
.cm-package h3 {
  font-family: var(--cm-font-head);
  font-size: 1.2rem;
  font-weight: 800;
  margin-bottom: 6px;
  color: var(--cm-charcoal);
}
.cm-package-featured h3 { color: var(--cm-white); }
.cm-pkg-price {
  font-family: var(--cm-font-head);
  font-size: 2.2rem;
  font-weight: 800;
  color: var(--cm-sky-dk);
  margin: 14px 0 4px;
  line-height: 1;
}
.cm-package-featured .cm-pkg-price { color: var(--cm-sun); }
.cm-pkg-per { font-size: 0.85rem; color: var(--cm-grey); }
.cm-package-featured .cm-pkg-per { color: rgba(255,255,255,0.7); }
.cm-pkg-features { list-style: none; margin: 16px 0 24px; }
.cm-pkg-features li {
  padding: 7px 0;
  border-bottom: 1px solid #EEF0F3;
  font-size: 0.86rem;
  display: flex;
  align-items: center;
  gap: 8px;
}
.cm-package-featured .cm-pkg-features li { border-bottom-color: rgba(255,255,255,0.15); color: rgba(255,255,255,0.9); }
.cm-pkg-features li::before { content: '✓'; color: var(--cm-grass-dk); font-weight: 800; }
.cm-package-featured .cm-pkg-features li::before { color: var(--cm-sun); }
.cm-pkg-btn {
  display: block;
  text-align: center;
  padding: 13px;
  border-radius: 50px;
  font-family: var(--cm-font-head);
  font-weight: 800;
  font-size: 0.9rem;
  text-decoration: none;
  transition: all 0.3s;
  background: var(--cm-cream);
  color: var(--cm-sky-dk);
  border: 2px solid var(--cm-sky);
}
.cm-pkg-btn:hover { background: var(--cm-sky-dk); color: var(--cm-white); }
.cm-package-featured .cm-pkg-btn { background: var(--cm-white); color: var(--cm-sky-dk); border-color: var(--cm-white); }
.cm-package-featured .cm-pkg-btn:hover { background: var(--cm-sun); color: var(--cm-charcoal); border-color: var(--cm-sun); }

/* ── TESTIMONIALS ── */
.cm-testimonials { background: var(--cm-cream); }
.cm-testimonials-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
  margin-top: 48px;
}
.cm-testimonial {
  background: var(--cm-white);
  border-radius: var(--cm-radius);
  padding: 28px 24px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.06);
  border-top: 4px solid var(--cm-sun);
}
.cm-testimonial:nth-child(2) { border-top-color: var(--cm-sky); }
.cm-testimonial:nth-child(3) { border-top-color: var(--cm-grass); }
.cm-stars { color: #FFB300; font-size: 1rem; margin-bottom: 10px; }
.cm-testimonial p { font-size: 0.88rem; color: var(--cm-charcoal); line-height: 1.7; margin-bottom: 18px; font-style: italic; }
.cm-testi-author { display: flex; align-items: center; gap: 10px; }
.cm-testi-avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.2rem;
  background: var(--cm-cream);
}
.cm-testi-name { font-family: var(--cm-font-head); font-weight: 800; font-size: 0.88rem; }
.cm-testi-role { font-size: 0.76rem; color: var(--cm-grey); }

/* ── FAQ ── */
.cm-faqs { max-width: 760px; margin: 48px auto 0; }
.cm-faq-item { border-bottom: 1px solid #EEF0F3; }
.cm-faq-q {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 18px 0;
  cursor: pointer;
  font-family: var(--cm-font-head);
  font-weight: 700;
  font-size: 0.95rem;
  color: var(--cm-charcoal);
  user-select: none;
}
.cm-faq-q::after { content: '+'; font-size: 1.4rem; color: var(--cm-sky-dk); transition: transform 0.3s; flex-shrink: 0; }
.cm-faq-item.cm-open .cm-faq-q::after { transform: rotate(45deg); }
.cm-faq-a { max-height: 0; overflow: hidden; transition: max-height 0.4s ease; }
.cm-faq-a-inner { padding: 0 0 18px; color: var(--cm-grey); font-size: 0.88rem; line-height: 1.7; }

/* ── BOOKING ── */
.cm-booking-section {
  background: linear-gradient(135deg, var(--cm-sky-dk) 0%, var(--cm-sky) 100%);
}
.cm-booking-section .cm-section-tag { background: rgba(255,255,255,0.15); color: var(--cm-white); }
.cm-booking-section .cm-section-title { color: var(--cm-white); }
.cm-booking-section .cm-section-sub { color: rgba(255,255,255,0.8); }
.cm-booking-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 60px;
  margin-top: 48px;
  align-items: start;
}
.cm-booking-info { color: var(--cm-white); }
.cm-booking-info h3 { font-family: var(--cm-font-head); font-size: 1.3rem; font-weight: 800; margin-bottom: 16px; }
.cm-booking-info ul { list-style: none; display: flex; flex-direction: column; gap: 10px; }
.cm-booking-info li { display: flex; align-items: flex-start; gap: 10px; font-size: 0.88rem; opacity: 0.92; }
.cm-booking-info li::before { content: '🌟'; flex-shrink: 0; }
.cm-contact-box {
  background: rgba(255,255,255,0.12);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: var(--cm-radius);
  padding: 18px 22px;
  margin-top: 24px;
}
.cm-contact-box h4 { font-size: 0.8rem; font-weight: 700; color: rgba(255,255,255,0.7); text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 12px; }
.cm-contact-item { display: flex; align-items: center; gap: 10px; font-size: 0.88rem; color: rgba(255,255,255,0.9); margin-bottom: 8px; }

.cm-form {
  background: var(--cm-white);
  border-radius: 16px;
  padding: 32px 28px;
  box-shadow: 0 20px 60px rgba(0,0,0,0.2);
}
.cm-form h3 {
  font-family: var(--cm-font-head);
  font-size: 1.25rem;
  font-weight: 800;
  color: var(--cm-charcoal);
  margin-bottom: 20px;
}
.cm-form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
.cm-form-group { display: flex; flex-direction: column; gap: 5px; }
.cm-form-group.cm-full { grid-column: 1/-1; }
.cm-form-group label { font-size: 0.78rem; font-weight: 700; color: var(--cm-charcoal); }
.cm-form-group input,
.cm-form-group select,
.cm-form-group textarea {
  padding: 11px 14px;
  border: 2px solid #EEF0F3;
  border-radius: 10px;
  font-family: var(--cm-font-body);
  font-size: 0.88rem;
  color: var(--cm-charcoal);
  transition: border-color 0.3s;
  background: var(--cm-white);
}
.cm-form-group input:focus,
.cm-form-group select:focus,
.cm-form-group textarea:focus { outline: none; border-color: var(--cm-sky-dk); }
.cm-form-group textarea { resize: vertical; min-height: 80px; }
.cm-form-submit {
  width: 100%;
  padding: 15px;
  background: linear-gradient(135deg, var(--cm-sun) 0%, var(--cm-sun-dk) 100%);
  color: var(--cm-charcoal);
  border: none;
  border-radius: 50px;
  font-family: var(--cm-font-head);
  font-size: 1rem;
  font-weight: 800;
  cursor: pointer;
  transition: all 0.3s;
  margin-top: 8px;
  box-shadow: 0 4px 16px rgba(255,214,0,0.4);
}
.cm-form-submit:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(255,214,0,0.5); }
.cm-form-note { font-size: 0.76rem; color: var(--cm-grey); text-align: center; margin-top: 10px; }

/* ── RESPONSIVE ── */
@media (max-width: 1024px) {
  .cm-hero-inner { grid-template-columns: 1fr; }
  .cm-scene { display: none; }
  .cm-about-grid { grid-template-columns: 1fr; }
  .cm-about-visual { height: 220px; }
  .cm-packages-grid { grid-template-columns: 1fr; }
  .cm-package-featured { transform: none; }
  .cm-testimonials-grid { grid-template-columns: 1fr; }
  .cm-booking-grid { grid-template-columns: 1fr; }
}
@media (max-width: 640px) {
  .cm-section { padding: 60px 5%; }
  .cm-hero h1 { font-size: 2.1rem; }
  .cm-why-grid { grid-template-columns: 1fr; }
  .cm-routine-grid { grid-template-columns: repeat(2, 1fr); }
  .cm-activities-grid { grid-template-columns: repeat(2, 1fr); }
  .cm-form-grid { grid-template-columns: 1fr; }
  .cm-hero-stats { gap: 16px; }
}
</style>

<div class="cm-wrap">

<!-- ═══════════════════════════════
     HERO
════════════════════════════════ -->
<section class="cm-hero">

  <!-- Clouds -->
  <div class="cm-cloud cm-cloud-1"></div>
  <div class="cm-cloud cm-cloud-2"></div>
  <div class="cm-cloud cm-cloud-3"></div>

  <!-- Sun -->
  <div class="cm-sun"></div>

  <!-- Balloons -->
  <div class="cm-balloon cm-balloon-1"></div>
  <div class="cm-balloon cm-balloon-2"></div>
  <div class="cm-balloon cm-balloon-3"></div>

  <!-- Hero Text -->
  <div class="cm-hero-inner">
    <div class="cm-hero-text">
      <div class="cm-hero-tag">⭐ Ofsted Outstanding Childminder</div>
      <h1>A <span>Safe, Nurturing Home</span><br>Away from Home</h1>
      <p class="cm-hero-sub">Professional, OFSTED-registered childminding in a warm, stimulating environment. Flexible hours, packed schedules, and genuine love for every child in our care.</p>
      <div class="cm-hero-ctas">
        <a href="#booking" class="cm-btn-primary">🌟 Enquire About Places</a>
        <a href="#about" class="cm-btn-secondary">Meet Your Childminder →</a>
      </div>
      <div class="cm-hero-stats">
        <div class="cm-hero-stat">
          <span class="cm-hero-stat-num" data-target="12" data-suffix="yrs">0yrs</span>
          <span class="cm-hero-stat-lbl">Experience</span>
        </div>
        <div class="cm-hero-stat">
          <span class="cm-hero-stat-num" data-target="85" data-suffix="+">0+</span>
          <span class="cm-hero-stat-lbl">Children Cared For</span>
        </div>
        <div class="cm-hero-stat">
          <span class="cm-hero-stat-num" data-target="5.0" data-float="1" data-suffix="★">0★</span>
          <span class="cm-hero-stat-lbl">Parent Rating</span>
        </div>
        <div class="cm-hero-stat">
          <span class="cm-hero-stat-num" data-target="100" data-suffix="%">0%</span>
          <span class="cm-hero-stat-lbl">Ofsted Outstanding</span>
        </div>
      </div>
    </div>
  </div>

  <!-- CSS Playhouse Scene -->
  <div class="cm-scene">
    <?php
    srand(crc32('cm-stars'));
    $star_positions = [[15,60],[75,40],[60,75],[30,85],[80,20]];
    $star_emojis = ['⭐','🌟','✨','💫','⭐'];
    foreach ($star_positions as $k => $pos) {
      echo "<div class='cm-star' style='left:{$pos[0]}%;top:{$pos[1]}%;animation-delay:". ($k * 1.5) ."s;'>{$star_emojis[$k]}</div>";
    }
    ?>
    <div class="cm-ground"></div>
    <div class="cm-house">
      <div class="cm-house-roof"></div>
      <div class="cm-house-body">
        <div class="cm-window"></div>
        <div class="cm-door"></div>
      </div>
    </div>
    <div class="cm-child-fig">
      <div class="cm-child-head"><div class="cm-child-hair"></div></div>
      <div class="cm-child-body"></div>
    </div>
    <div class="cm-holding-arm"></div>
    <div class="cm-figure">
      <div class="cm-fig-head"><div class="cm-fig-hair"></div></div>
      <div class="cm-fig-body"></div>
    </div>
    <div class="cm-ball"></div>
    <div class="cm-pill cm-pill-1">✓ OFSTED Registered</div>
    <div class="cm-pill cm-pill-2">✓ Paediatric First Aid</div>
    <div class="cm-pill cm-pill-3">✓ DBS Checked</div>
  </div>

</section>

<!-- TRUST BAR -->
<div class="cm-trust">
  <div class="cm-trust-inner">
    <div class="cm-trust-item">⭐ OFSTED Outstanding</div>
    <div class="cm-trust-item">🛡️ Fully DBS Checked</div>
    <div class="cm-trust-item">🏥 Paediatric First Aid</div>
    <div class="cm-trust-item">📋 EYFS Qualified</div>
    <div class="cm-trust-item">🔒 Fully Insured</div>
    <div class="cm-trust-item">🍎 NCMA Member</div>
  </div>
</div>

<!-- ═══════════════════════════════
     WHY CHOOSE US
════════════════════════════════ -->
<section class="cm-section cm-why">
  <div class="cm-section-inner">
    <div class="cm-section-tag">Why Choose Us</div>
    <h2 class="cm-section-title">Childcare Built on Love, Safety &amp; Learning</h2>
    <p class="cm-section-sub">We combine the cosiness of home with professional early years education — giving your child the very best start.</p>

    <div class="cm-why-grid">
      <div class="cm-why-card">
        <span class="cm-why-icon">🏡</span>
        <h3>Home-from-Home Setting</h3>
        <p>A warm, safe domestic environment with outdoor garden space — far more personal than nursery, with smaller ratios for individual attention.</p>
      </div>
      <div class="cm-why-card">
        <span class="cm-why-icon">📚</span>
        <h3>EYFS-Aligned Learning</h3>
        <p>All activities are carefully planned around the Early Years Foundation Stage framework to support your child's developmental milestones.</p>
      </div>
      <div class="cm-why-card">
        <span class="cm-why-icon">🕐</span>
        <h3>Flexible Hours</h3>
        <p>Tailored hours to suit your work schedule — early starts from 7am, late finishes to 7pm, and occasional weekend care available.</p>
      </div>
      <div class="cm-why-card">
        <span class="cm-why-icon">🥗</span>
        <h3>Healthy, Home-Cooked Meals</h3>
        <p>All meals and snacks are freshly prepared, nutritionally balanced, and adapted for dietary requirements and allergies.</p>
      </div>
      <div class="cm-why-card">
        <span class="cm-why-icon">📱</span>
        <h3>Daily Parent Updates</h3>
        <p>Real-time photo updates, activity logs, and nap/feed records via the Famly app — you're always in the loop, even at work.</p>
      </div>
      <div class="cm-why-card">
        <span class="cm-why-icon">🌿</span>
        <h3>Outdoor &amp; Nature Play</h3>
        <p>Regular outdoor sessions in the garden and local parks, forest school activities, and nature-based discovery every week.</p>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     DAILY ROUTINE
════════════════════════════════ -->
<section class="cm-section">
  <div class="cm-section-inner">
    <div class="cm-section-tag">A Typical Day</div>
    <h2 class="cm-section-title">Structure, Fun &amp; Rest</h2>
    <p class="cm-section-sub">Every day follows a nurturing routine that balances active play, creative exploration, meals, and quiet time.</p>

    <div class="cm-routine-grid">
      <div class="cm-routine-item">
        <div class="cm-routine-time">7:30 – 9:00</div>
        <span class="cm-routine-icon">☀️</span>
        <h3>Morning Welcome</h3>
        <p>Arrival, free play, breakfast, and settling-in time</p>
      </div>
      <div class="cm-routine-item">
        <div class="cm-routine-time">9:00 – 10:30</div>
        <span class="cm-routine-icon">🎨</span>
        <h3>Creative Activity</h3>
        <p>Structured EYFS play: arts &amp; crafts, sensory, messy play</p>
      </div>
      <div class="cm-routine-item">
        <div class="cm-routine-time">10:30 – 12:00</div>
        <span class="cm-routine-icon">🌳</span>
        <h3>Outdoor Adventure</h3>
        <p>Garden play, local park visits, nature walks, and physical activity</p>
      </div>
      <div class="cm-routine-item">
        <div class="cm-routine-time">12:00 – 13:00</div>
        <span class="cm-routine-icon">🍽️</span>
        <h3>Lunch &amp; Story Time</h3>
        <p>Hot home-cooked lunch followed by relaxing book time</p>
      </div>
      <div class="cm-routine-item">
        <div class="cm-routine-time">13:00 – 15:00</div>
        <span class="cm-routine-icon">😴</span>
        <h3>Rest &amp; Quiet Play</h3>
        <p>Nap or quiet activities based on age and individual needs</p>
      </div>
      <div class="cm-routine-item">
        <div class="cm-routine-time">15:00 – 18:00</div>
        <span class="cm-routine-icon">🎮</span>
        <h3>Afternoon Fun</h3>
        <p>Free play, snack time, activities, and collection time</p>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     ABOUT
════════════════════════════════ -->
<section class="cm-section cm-about" id="about">
  <div class="cm-section-inner">
    <div class="cm-about-grid">
      <div class="cm-about-visual">
        <div class="cm-about-bg"></div>
        <div class="cm-big-smiley">👩‍🏫</div>
        <div class="cm-about-star" style="left:50%;top:50%;animation-delay:0s;">⭐</div>
        <div class="cm-about-star" style="left:50%;top:50%;animation-delay:-2s;">🌟</div>
        <div class="cm-about-star" style="left:50%;top:50%;animation-delay:-4s;">💛</div>
        <div class="cm-about-star" style="left:50%;top:50%;animation-delay:-6s;">✨</div>
        <div class="cm-ofsted-badge">
          <span class="cm-big">Outstanding</span>
          <span class="cm-lbl">Ofsted Rating</span>
        </div>
      </div>
      <div class="cm-about-text">
        <div class="cm-section-tag">About Your Childminder</div>
        <h2 class="cm-section-title">Sarah Whitmore</h2>
        <p class="cm-section-sub">With 12 years of professional childminding experience and a background in nursery nursing, Sarah creates a home full of laughter, learning, and security. She is passionate about early childhood development and takes genuine pride in building trusting relationships with every family she works with.</p>

        <div class="cm-about-quals">
          <div class="cm-qual-row">CACHE Level 3 in Childcare &amp; Education</div>
          <div class="cm-qual-row">Paediatric First Aid (renewed annually)</div>
          <div class="cm-qual-row">DBS Enhanced Certificate (updated 2024)</div>
          <div class="cm-qual-row">OFSTED Registered — Outstanding in all areas</div>
          <div class="cm-qual-row">Food Hygiene Certificate Level 2</div>
          <div class="cm-qual-row">NCMA Professional Membership</div>
        </div>
        <div class="cm-about-quote">
          "Every child deserves a safe, happy place to grow. I pour my whole heart into giving children an experience that helps them flourish — and into giving parents the peace of mind to focus on their day."
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     ACTIVITIES
════════════════════════════════ -->
<section class="cm-section cm-activities-section">
  <div class="cm-section-inner">
    <div class="cm-section-tag">Activities &amp; Learning</div>
    <h2 class="cm-section-title">Packed with Discovery Every Day</h2>
    <p class="cm-section-sub">A rich variety of activities designed to develop every area of your child's growth and confidence.</p>

    <div class="cm-activities-grid">
      <div class="cm-activity-tile"><span class="cm-act-icon">🎨</span><p>Arts &amp; Crafts</p></div>
      <div class="cm-activity-tile"><span class="cm-act-icon">🌿</span><p>Nature &amp; Forest School</p></div>
      <div class="cm-activity-tile"><span class="cm-act-icon">📚</span><p>Phonics &amp; Storytime</p></div>
      <div class="cm-activity-tile"><span class="cm-act-icon">🎵</span><p>Music &amp; Movement</p></div>
      <div class="cm-activity-tile"><span class="cm-act-icon">🏃</span><p>Physical Play</p></div>
      <div class="cm-activity-tile"><span class="cm-act-icon">🧩</span><p>Puzzles &amp; Problem Solving</p></div>
      <div class="cm-activity-tile"><span class="cm-act-icon">🌱</span><p>Gardening</p></div>
      <div class="cm-activity-tile"><span class="cm-act-icon">🍳</span><p>Simple Cooking</p></div>
      <div class="cm-activity-tile"><span class="cm-act-icon">🦋</span><p>Science Discovery</p></div>
      <div class="cm-activity-tile"><span class="cm-act-icon">🎭</span><p>Role Play &amp; Drama</p></div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     PACKAGES / SESSIONS
════════════════════════════════ -->
<section class="cm-section">
  <div class="cm-section-inner">
    <div class="cm-section-tag">Sessions &amp; Pricing</div>
    <h2 class="cm-section-title">Flexible, Affordable Childcare</h2>
    <p class="cm-section-sub">Transparent pricing with no hidden extras. Government-funded 15–30 hour places accepted for eligible families.</p>

    <div class="cm-packages-grid">
      <div class="cm-package">
        <h3>Part-Time</h3>
        <div class="cm-pkg-price">£6.50</div>
        <div class="cm-pkg-per">per hour · up to 25 hrs/wk</div>
        <ul class="cm-pkg-features">
          <li>All meals &amp; snacks included</li>
          <li>Daily parent app updates</li>
          <li>EYFS learning activities</li>
          <li>Outdoor play sessions</li>
          <li>Government funding accepted</li>
        </ul>
        <a href="#booking" class="cm-pkg-btn">Enquire Now</a>
      </div>
      <div class="cm-package cm-package-featured">
        <div class="cm-pkg-badge">Most Popular</div>
        <h3>Full-Time</h3>
        <div class="cm-pkg-price">£5.80</div>
        <div class="cm-pkg-per">per hour · 25–50 hrs/wk</div>
        <ul class="cm-pkg-features">
          <li>All meals &amp; snacks included</li>
          <li>Daily parent app updates</li>
          <li>Structured EYFS programme</li>
          <li>Forest school &amp; park sessions</li>
          <li>Monthly progress reports</li>
          <li>Government funding accepted</li>
        </ul>
        <a href="#booking" class="cm-pkg-btn">Enquire Now</a>
      </div>
      <div class="cm-package">
        <h3>Ad-Hoc / Occasional</h3>
        <div class="cm-pkg-price">£8.50</div>
        <div class="cm-pkg-per">per hour · flexible dates</div>
        <ul class="cm-pkg-features">
          <li>All meals &amp; snacks included</li>
          <li>Daily parent updates</li>
          <li>EYFS activities</li>
          <li>Book by the session</li>
          <li>Subject to availability</li>
        </ul>
        <a href="#booking" class="cm-pkg-btn">Enquire Now</a>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     TESTIMONIALS
════════════════════════════════ -->
<section class="cm-section cm-testimonials">
  <div class="cm-section-inner">
    <div class="cm-section-tag">Parent Reviews</div>
    <h2 class="cm-section-title">Trusted by Local Families</h2>

    <div class="cm-testimonials-grid">
      <div class="cm-testimonial">
        <div class="cm-stars">★★★★★</div>
        <p>Leaving our daughter with Sarah was one of the best decisions we've ever made. She comes home happy, full of stories, and having clearly learned so much. The daily photo updates keep us completely at ease — we can actually concentrate at work!</p>
        <div class="cm-testi-author">
          <div class="cm-testi-avatar">👩</div>
          <div>
            <div class="cm-testi-name">Emma &amp; James T.</div>
            <div class="cm-testi-role">Parents of Isla, age 3</div>
          </div>
        </div>
      </div>
      <div class="cm-testimonial">
        <div class="cm-stars">★★★★★</div>
        <p>Our son has autism and needed very careful, patient care. Sarah went above and beyond to understand his needs and create a routine that works beautifully for him. The OFSTED outstanding rating is absolutely deserved.</p>
        <div class="cm-testi-author">
          <div class="cm-testi-avatar">👨</div>
          <div>
            <div class="cm-testi-name">David R.</div>
            <div class="cm-testi-role">Parent of Oliver, age 4</div>
          </div>
        </div>
      </div>
      <div class="cm-testimonial">
        <div class="cm-stars">★★★★★</div>
        <p>Sarah has been our childminder for three years and we've watched our twins absolutely thrive. The home-cooked meals, outdoor adventures, and gentle approach to learning are everything we hoped for. She's genuinely irreplaceable.</p>
        <div class="cm-testi-author">
          <div class="cm-testi-avatar">👩</div>
          <div>
            <div class="cm-testi-name">Claire M.</div>
            <div class="cm-testi-role">Parent of Lily &amp; Finn, age 5</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     FAQ
════════════════════════════════ -->
<section class="cm-section">
  <div class="cm-section-inner">
    <div style="text-align:center;">
      <div class="cm-section-tag">FAQ</div>
      <h2 class="cm-section-title">Questions from Parents</h2>
    </div>
    <div class="cm-faqs">
      <div class="cm-faq-item">
        <div class="cm-faq-q">Do you accept government-funded childcare hours?</div>
        <div class="cm-faq-a"><div class="cm-faq-a-inner">Yes — we accept the 15-hour universal entitlement for 3–4 year olds and the 30-hour extended entitlement for eligible working parents. Funded hours can be used across part-time and full-time sessions, and we'll help you with the registration process.</div></div>
      </div>
      <div class="cm-faq-item">
        <div class="cm-faq-q">What is the settling-in process?</div>
        <div class="cm-faq-a"><div class="cm-faq-a-inner">We offer free settling-in visits — typically two to three sessions where you stay with your child while they get comfortable. We then do a gradual handover so your child feels confident and secure. There's no rushing — we go at your child's pace.</div></div>
      </div>
      <div class="cm-faq-item">
        <div class="cm-faq-q">How do you handle dietary requirements and allergies?</div>
        <div class="cm-faq-a"><div class="cm-faq-a-inner">We cater for all dietary requirements including vegetarian, vegan, gluten-free, dairy-free, and religious dietary needs. All allergies are documented in your child's care plan and we maintain a strict allergen-free kitchen environment where needed.</div></div>
      </div>
      <div class="cm-faq-item">
        <div class="cm-faq-q">What happens if my child is unwell?</div>
        <div class="cm-faq-a"><div class="cm-faq-a-inner">We follow the UK Health Security Agency exclusion guidelines. Children with contagious illness or high temperature should be kept home. We'll contact you immediately if your child becomes unwell during the day and have a clear illness policy outlined in our contract.</div></div>
      </div>
      <div class="cm-faq-item">
        <div class="cm-faq-q">Do you offer school runs?</div>
        <div class="cm-faq-a"><div class="cm-faq-a-inner">Yes — we provide morning drop-off and afternoon collection from local primary schools, subject to location. We also offer wrap-around care for school-age children during holidays and INSET days.</div></div>
      </div>
      <div class="cm-faq-item">
        <div class="cm-faq-q">Are there any spaces currently available?</div>
        <div class="cm-faq-a"><div class="cm-faq-a-inner">Spaces are limited as we maintain small ratios for quality care. Please get in touch to check current availability and join our waiting list. We recommend enquiring as early as possible, especially for September start dates.</div></div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     BOOKING / ENQUIRY FORM
════════════════════════════════ -->
<section class="cm-section cm-booking-section" id="booking">
  <div class="cm-section-inner">
    <div class="cm-section-tag">Enquire About a Place</div>
    <h2 class="cm-section-title">Start Your Child's Journey</h2>
    <p class="cm-section-sub">Spaces are limited — get in touch today to check availability and arrange a visit.</p>

    <div class="cm-booking-grid">
      <div class="cm-booking-info">
        <h3>What Happens Next?</h3>
        <ul>
          <li>We'll reply within 24 hours to confirm availability</li>
          <li>You're invited for a free home visit and Q&amp;A session</li>
          <li>We discuss your child's individual needs and routine</li>
          <li>Settling-in sessions are arranged at your pace</li>
          <li>Contract and care plan are completed together</li>
          <li>Your child's place is confirmed with a small deposit</li>
        </ul>
        <div class="cm-contact-box">
          <h4>Get in Touch</h4>
          <div class="cm-contact-item">📍 Knutsford, Cheshire WA16</div>
          <div class="cm-contact-item">📞 07812 345 678</div>
          <div class="cm-contact-item">📧 sarah@whitmorchildminding.co.uk</div>
          <div class="cm-contact-item">🕐 Mon–Fri: 7:00am – 6:30pm</div>
        </div>
      </div>

      <div class="cm-form">
        <h3>📝 Enquiry Form</h3>
        <?php if ( function_exists( 'get_the_permalink' ) ) : ?>
        <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
          <?php wp_nonce_field( 'tf_cm_booking', 'tf_cm_nonce' ); ?>
          <input type="hidden" name="action" value="tf_cm_booking">
          <div class="cm-form-grid">
            <div class="cm-form-group">
              <label for="cm_parent">Parent / Guardian Name *</label>
              <input type="text" id="cm_parent" name="parent_name" required placeholder="Emma Thompson">
            </div>
            <div class="cm-form-group">
              <label for="cm_phone">Phone Number *</label>
              <input type="tel" id="cm_phone" name="phone" required placeholder="07900 000 000">
            </div>
            <div class="cm-form-group cm-full">
              <label for="cm_email">Email Address *</label>
              <input type="email" id="cm_email" name="email" required placeholder="emma@email.com">
            </div>
            <div class="cm-form-group">
              <label for="cm_child_name">Child's Name *</label>
              <input type="text" id="cm_child_name" name="child_name" required placeholder="Isla">
            </div>
            <div class="cm-form-group">
              <label for="cm_child_dob">Child's Date of Birth *</label>
              <input type="date" id="cm_child_dob" name="child_dob" required>
            </div>
            <div class="cm-form-group">
              <label for="cm_session">Session Type Required</label>
              <select id="cm_session" name="session_type">
                <option value="">— Select —</option>
                <option>Part-Time (up to 25hrs/wk)</option>
                <option>Full-Time (25–50hrs/wk)</option>
                <option>Ad-Hoc / Occasional</option>
                <option>School Wrap-Around Care</option>
              </select>
            </div>
            <div class="cm-form-group">
              <label for="cm_start">Ideal Start Date</label>
              <input type="date" id="cm_start" name="start_date">
            </div>
            <div class="cm-form-group cm-full">
              <label for="cm_notes">Tell us about your child &amp; your needs</label>
              <textarea id="cm_notes" name="notes" placeholder="Routine, dietary needs, favourite activities, any additional support requirements..."></textarea>
            </div>
          </div>
          <button type="submit" class="cm-form-submit">🌟 Send My Enquiry</button>
          <p class="cm-form-note">🔒 Your details are handled confidentially in line with our Privacy Policy and GDPR. We respond within 24 hours.</p>
        </form>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

</div><!-- .cm-wrap -->

<script>
(function(){
  /* ── ANIMATED COUNTERS ── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  const counters = document.querySelectorAll('[data-target]');
  if (!counters.length) return;
  const obs = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const target = parseFloat(el.dataset.target);
      if (isNaN(target)) return;
      const suffix  = el.dataset.suffix || '';
      const isFloat = el.dataset.float === '1';
      const dur     = 1800;
      let start = null;
      function tick(ts) {
        if (!start) start = ts;
        const prog = Math.min((ts - start) / dur, 1);
        const val  = easeOut(prog) * target;
        el.textContent = (isFloat ? val.toFixed(1) : Math.floor(val).toLocaleString()) + suffix;
        if (prog < 1) requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
      obs.unobserve(el);
    });
  }, { threshold: 0.5 });
  counters.forEach(c => obs.observe(c));

  /* ── FAQ ACCORDION ── */
  document.querySelectorAll('.cm-faq-q').forEach(q => {
    q.addEventListener('click', () => {
      const item = q.parentElement;
      const ans  = item.querySelector('.cm-faq-a');
      const open = item.classList.contains('cm-open');
      document.querySelectorAll('.cm-faq-item.cm-open').forEach(o => {
        o.classList.remove('cm-open');
        o.querySelector('.cm-faq-a').style.maxHeight = '0';
      });
      if (!open) {
        item.classList.add('cm-open');
        ans.style.maxHeight = ans.scrollHeight + 'px';
      }
    });
  });

  /* ── SCROLL REVEAL ── */
  const reveals = document.querySelectorAll('.cm-why-card,.cm-routine-item,.cm-activity-tile,.cm-testimonial,.cm-package');
  const revObs  = new IntersectionObserver(entries => {
    entries.forEach((e, i) => {
      if (e.isIntersecting) {
        setTimeout(() => {
          e.target.style.opacity   = '1';
          e.target.style.transform = e.target.classList.contains('cm-package-featured') ? 'scale(1.03)' : 'translateY(0)';
        }, (i % 5) * 70);
        revObs.unobserve(e.target);
      }
    });
  }, { threshold: 0.1 });
  reveals.forEach(r => {
    r.style.opacity   = '0';
    r.style.transform = r.classList.contains('cm-package-featured') ? 'scale(0.98)' : 'translateY(22px)';
    r.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    revObs.observe(r);
  });

  /* ── SMOOTH SCROLL ── */
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const target = document.querySelector(a.getAttribute('href'));
      if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    });
  });
})();
</script>

<?php get_footer(); ?>
