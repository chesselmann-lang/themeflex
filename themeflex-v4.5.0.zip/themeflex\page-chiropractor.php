<?php
/**
 * Template Name: TF — Chiropractic & Musculoskeletal Clinic
 * Description:   Full-page premium template for chiropractic and physiotherapy clinics.
 *                CSS anatomy-inspired hero with spine and skeletal art, clinic interior scene,
 *                services, conditions treated, team, testimonials, FAQ, appointment form.
 * Version:       1.0.0
 */
defined('ABSPATH') || exit;

/* ── Seeded randomness ───────────────────────────────────────────── */
srand(crc32(get_the_permalink()));

/* ── PHP float helper ────────────────────────────────────────────── */
function chi_rand_float(float $min, float $max, int $dec = 1): string {
    return number_format($min + (mt_rand() / mt_getrandmax()) * ($max - $min), $dec, '.', '');
}

/* ── Floating healing particles ──────────────────────────────────── */
$chi_particles = [];
for ($i = 0; $i < 22; $i++) {
    $chi_particles[] = [
        'x'     => rand(0, 100),
        'size'  => rand(3, 8),
        'delay' => chi_rand_float(0, 10.0),
        'dur'   => chi_rand_float(6.0, 16.0),
        'op'    => rand(20, 55),
    ];
}

/* ── Vertebrae data for spine illustration ───────────────────────── */
$vertebrae = [
    // [width_px, height_px, label, col_variant]
    ['w'=>52,'h'=>18,'label'=>'C1','col'=>'#4a7a9a','type'=>'cervical'],
    ['w'=>54,'h'=>18,'label'=>'C2','col'=>'#4a7a9a','type'=>'cervical'],
    ['w'=>56,'h'=>18,'label'=>'C3','col'=>'#4a7a9a','type'=>'cervical'],
    ['w'=>56,'h'=>18,'label'=>'C4','col'=>'#4a7a9a','type'=>'cervical'],
    ['w'=>58,'h'=>18,'label'=>'C5','col'=>'#4a7a9a','type'=>'cervical'],
    ['w'=>58,'h'=>18,'label'=>'C6','col'=>'#4a7a9a','type'=>'cervical'],
    ['w'=>60,'h'=>18,'label'=>'C7','col'=>'#4a7a9a','type'=>'cervical'],
    ['w'=>62,'h'=>20,'label'=>'T1','col'=>'#3a6a8a','type'=>'thoracic'],
    ['w'=>64,'h'=>20,'label'=>'T2','col'=>'#3a6a8a','type'=>'thoracic'],
    ['w'=>66,'h'=>20,'label'=>'T3','col'=>'#3a6a8a','type'=>'thoracic'],
    ['w'=>68,'h'=>20,'label'=>'T4','col'=>'#3a6a8a','type'=>'thoracic'],
    ['w'=>68,'h'=>20,'label'=>'T5','col'=>'#3a6a8a','type'=>'thoracic'],
    ['w'=>70,'h'=>20,'label'=>'T6','col'=>'#3a6a8a','type'=>'thoracic'],
    ['w'=>72,'h'=>22,'label'=>'L1','col'=>'#2a5a7a','type'=>'lumbar'],
    ['w'=>74,'h'=>24,'label'=>'L2','col'=>'#2a5a7a','type'=>'lumbar'],
    ['w'=>76,'h'=>24,'label'=>'L3','col'=>'#2a5a7a','type'=>'lumbar'],
    ['w'=>78,'h'=>26,'label'=>'L4','col'=>'#2a5a7a','type'=>'lumbar'],
    ['w'=>80,'h'=>26,'label'=>'L5','col'=>'#2a5a7a','type'=>'lumbar'],
    ['w'=>76,'h'=>50,'label'=>'Sacrum','col'=>'#1a4a6a','type'=>'sacrum'],
];

/* ── Services ─────────────────────────────────────────────────────── */
$services = [
    [
        'name'  => 'Chiropractic Adjustment',
        'icon'  => '🦴',
        'desc'  => 'Precise spinal manipulation to restore joint mobility, relieve nerve irritation and re-establish optimal biomechanical function.',
        'time'  => '30 – 45 min',
        'price' => 'from £55',
    ],
    [
        'name'  => 'Sports Injury Rehab',
        'icon'  => '🏃',
        'desc'  => 'Assessment, diagnosis and structured rehabilitation programmes for acute and chronic sports injuries — from sprains to overuse syndromes.',
        'time'  => '45 – 60 min',
        'price' => 'from £65',
    ],
    [
        'name'  => 'Dry Needling',
        'icon'  => '💉',
        'desc'  => 'Intramuscular stimulation targeting myofascial trigger points to release tension, reduce pain and restore muscular function.',
        'time'  => '30 min',
        'price' => 'from £50',
    ],
    [
        'name'  => 'Soft Tissue Therapy',
        'icon'  => '✋',
        'desc'  => 'Advanced manual techniques — including deep tissue, myofascial release and IASTM — to address muscle and connective tissue dysfunction.',
        'time'  => '45 min',
        'price' => 'from £55',
    ],
    [
        'name'  => 'Postural Assessment',
        'icon'  => '📏',
        'desc'  => 'Comprehensive postural and movement screening to identify imbalances and design a personalised corrective exercise programme.',
        'time'  => '60 min',
        'price' => 'from £75',
    ],
    [
        'name'  => 'Ergonomic Consultancy',
        'icon'  => '💺',
        'desc'  => 'On-site or video workplace assessments to reduce occupational strain and prevent repetitive stress injuries.',
        'time'  => '60 – 90 min',
        'price' => 'from £85',
    ],
];

/* ── Conditions treated ───────────────────────────────────────────── */
$conditions = [
    ['name'=>'Lower Back Pain',      'icon'=>'🔴','common'=>true],
    ['name'=>'Neck Pain & Stiffness','icon'=>'🔴','common'=>true],
    ['name'=>'Sciatica',             'icon'=>'🔴','common'=>true],
    ['name'=>'Headaches & Migraines','icon'=>'🟠','common'=>true],
    ['name'=>'Shoulder Impingement', 'icon'=>'🟠','common'=>false],
    ['name'=>'Tennis & Golfer\'s Elbow','icon'=>'🟡','common'=>false],
    ['name'=>'Hip & Knee Pain',      'icon'=>'🟠','common'=>false],
    ['name'=>'Plantar Fasciitis',    'icon'=>'🟡','common'=>false],
    ['name'=>'Disc Herniation',      'icon'=>'🔴','common'=>true],
    ['name'=>'Scoliosis Management', 'icon'=>'🟡','common'=>false],
    ['name'=>'Whiplash',             'icon'=>'🔴','common'=>false],
    ['name'=>'Postural Dysfunction', 'icon'=>'🟡','common'=>true],
    ['name'=>'Sports Injuries',      'icon'=>'🟠','common'=>true],
    ['name'=>'Repetitive Strain',    'icon'=>'🟡','common'=>false],
    ['name'=>'Piriformis Syndrome',  'icon'=>'🟡','common'=>false],
    ['name'=>'Sacroiliac Joint Pain','icon'=>'🟠','common'=>false],
];

/* ── Team ─────────────────────────────────────────────────────────── */
$team = [
    [
        'name'   => 'Dr. Sarah Holden',
        'role'   => 'Principal Chiropractor & Clinical Director',
        'quals'  => 'DC (AECC), MSc (Sports Med), MRCC',
        'exp'    => '14 years',
        'bio'    => 'Sarah holds a Masters in Sports Medicine and has worked with elite athletes across rugby, athletics and cycling. She specialises in complex spinal presentations and sports performance.',
        'skin'   => '#d4a870',
        'hair'   => '#3a1a08',
        'top'    => '#3a6a8a',
        'coat'   => true,
    ],
    [
        'name'   => 'Dr. Marcus Webb',
        'role'   => 'Senior Chiropractor',
        'quals'  => 'DC (WIOC), PG Cert (Paeds), MRCC',
        'exp'    => '10 years',
        'bio'    => 'Marcus has a postgraduate certificate in paediatric chiropractic and a particular interest in headache management, whiplash and occupational health presentations.',
        'skin'   => '#c08060',
        'hair'   => '#2a1a08',
        'top'    => '#2a5a7a',
        'coat'   => true,
    ],
    [
        'name'   => 'Lucy Farnsworth',
        'role'   => 'Physiotherapist & Soft Tissue Specialist',
        'quals'  => 'BSc (Physiotherapy), HCPC, CSP',
        'exp'    => '8 years',
        'bio'    => 'Lucy combines physiotherapy with advanced soft tissue and dry needling techniques. She leads the clinic\'s rehabilitation and corrective exercise programmes.',
        'skin'   => '#e0b880',
        'hair'   => '#8a5020',
        'top'    => '#4a7a6a',
        'coat'   => false,
    ],
];

/* ── Why us stats ─────────────────────────────────────────────────── */
$why_items = [
    ['icon'=>'✅','title'=>'GCC Registered Chiropractors','desc'=>'All our chiropractors are registered with the General Chiropractic Council (GCC) and adhere to its Code of Practice.'],
    ['icon'=>'🏥','title'=>'BUPA & AXA PPP Recognised','desc'=>'We accept referrals from most major private health insurers. Please check with your insurer before booking.'],
    ['icon'=>'📅','title'=>'Same-Day Appointments','desc'=>'We understand that pain doesn\'t keep office hours. We keep urgent appointment slots available throughout the week.'],
    ['icon'=>'📊','title'=>'Evidence-Based Practice','desc'=>'Our treatment protocols follow current NICE guidelines and are updated in line with the latest clinical research.'],
];

/* ── Testimonials ─────────────────────────────────────────────────── */
$testimonials = [
    [
        'name'  => 'James R.',
        'loc'   => 'Patient for 3 years',
        'cond'  => 'Chronic lower back pain',
        'quote' => 'I had suffered with lower back pain for six years before seeing Dr. Holden. Within eight sessions I had more mobility than I\'d had in a decade. I now come in for maintenance every six weeks.',
        'stars' => 5,
    ],
    [
        'name'  => 'Anna M.',
        'loc'   => 'Marathon runner',
        'cond'  => 'Sciatica',
        'quote' => 'Sciatica was threatening my training ahead of London Marathon. Marcus diagnosed the issue quickly, and Lucy\'s rehab programme got me to the start line in better shape than before.',
        'stars' => 5,
    ],
    [
        'name'  => 'Peter &amp; Gill C.',
        'loc'   => 'Referred by GP',
        'cond'  => 'Neck pain &amp; migraines',
        'quote' => 'My migraines have reduced from twice a week to once a month since starting chiropractic care. The team explained everything clearly at every step. We wouldn\'t go anywhere else.',
        'stars' => 5,
    ],
];

/* ── FAQs ─────────────────────────────────────────────────────────── */
$faqs = [
    ['q'=>'Is chiropractic treatment safe?',
     'a'=>'Chiropractic is widely considered safe when performed by a qualified, GCC-registered chiropractor. As with any manual therapy, minor soreness after treatment is normal and temporary. We carry out a full health history and examination before any treatment.'],
    ['q'=>'Do I need a GP referral to see a chiropractor?',
     'a'=>'No — you can refer yourself directly. You don\'t need a GP referral to book an appointment. However, if you have private health insurance, your insurer may require a GP referral for claim purposes.'],
    ['q'=>'How many sessions will I need?',
     'a'=>'This depends on your condition, how long you\'ve had it and how your body responds to treatment. Most acute presentations respond significantly within 4–6 sessions. Chronic or complex conditions may require a longer programme. We always discuss realistic expectations at your initial consultation.'],
    ['q'=>'What should I wear to my appointment?',
     'a'=>'Comfortable, loose-fitting clothing is ideal. If you\'re attending for a lower back or hip complaint, gym shorts or leggings work well. For neck or shoulder issues, a vest or loose-fitting top is helpful. We have gowns available if needed.'],
    ['q'=>'Do you treat children?',
     'a'=>'Yes — Dr. Webb holds a postgraduate certificate in paediatric chiropractic and we see patients from infancy through to adolescence. All paediatric appointments include a parent or guardian.'],
];

?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Crimson+Pro:ital,wght@0,400;0,600;1,400&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════════════════
   CHIROPRACTIC CLINIC — CSS CUSTOM PROPERTIES
═══════════════════════════════════════════════════════════════════ */
:root{
  --chi-deep:     #0a1a2a;
  --chi-navy:     #0f2a42;
  --chi-teal:     #1a5a7a;
  --chi-teal-lt:  #2a7a9a;
  --chi-sky:      #3a9aaa;
  --chi-ice:      #d8eef4;
  --chi-white:    #f8fafb;
  --chi-warm:     #f5f0ea;
  --chi-ink:      #0d1a2a;
  --chi-body:     #c8d8e8;
  --chi-bone:     #e8e0d0;
  --chi-disc:     #a8c8d8;
  --chi-red:      #c84040;
  --chi-amber:    #c88020;
  --chi-green:    #3a8a5a;
  --ff-head:      'Inter', sans-serif;
  --ff-serif:     'Crimson Pro', Georgia, serif;
  --rad:          8px;
  --trans:        .3s cubic-bezier(.4,0,.2,1);
}

/* ─── Reset & base ───────────────────────────────────────────────── */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth;font-size:16px}
body.chi-page{
  font-family:var(--ff-head);
  color:var(--chi-ink);
  background:var(--chi-white);
  overflow-x:hidden;
}
.chi-wrap{max-width:1140px;margin:0 auto;padding:0 24px}

/* ─── Typography ─────────────────────────────────────────────────── */
.chi-eyebrow{
  font-size:.7rem;
  font-weight:600;
  letter-spacing:.18em;
  text-transform:uppercase;
  color:var(--chi-sky);
  display:block;
  margin-bottom:.6rem;
}
.chi-h2{
  font-family:var(--ff-head);
  font-size:clamp(1.8rem,3vw,2.7rem);
  font-weight:300;
  color:var(--chi-ink);
  line-height:1.2;
}
.chi-h2 strong{font-weight:700}
.chi-lead{
  font-size:1rem;
  line-height:1.78;
  color:#3a5a6a;
  max-width:640px;
}
.chi-centre{text-align:center}
.chi-centre .chi-lead{margin:0 auto}

/* ─── Rule ───────────────────────────────────────────────────────── */
.chi-rule{
  display:flex;
  align-items:center;
  gap:10px;
  margin:.8rem 0 1.8rem;
}
.chi-rule-line{flex:1;height:1px;background:linear-gradient(90deg,transparent,var(--chi-teal),transparent)}
.chi-rule-dot{
  width:6px;height:6px;
  border-radius:50%;
  background:var(--chi-teal);
  flex-shrink:0;
}

/* ─── Buttons ────────────────────────────────────────────────────── */
.chi-btn{
  display:inline-flex;
  align-items:center;
  gap:8px;
  padding:13px 28px;
  border-radius:50px;
  font-weight:600;
  font-size:.87rem;
  letter-spacing:.04em;
  text-decoration:none;
  border:none;
  cursor:pointer;
  transition:var(--trans);
}
.chi-btn-primary{
  background:linear-gradient(135deg,var(--chi-teal),var(--chi-teal-lt));
  color:#fff;
  box-shadow:0 4px 18px rgba(26,90,122,.35);
}
.chi-btn-primary:hover{transform:translateY(-2px);box-shadow:0 8px 26px rgba(26,90,122,.45)}
.chi-btn-ghost{
  background:transparent;
  color:#fff;
  border:2px solid rgba(255,255,255,.6);
  border-radius:50px;
}
.chi-btn-ghost:hover{background:rgba(255,255,255,.12);border-color:#fff}
.chi-btn-ice{
  background:var(--chi-ice);
  color:var(--chi-teal);
  font-weight:700;
}
.chi-btn-ice:hover{background:#fff;box-shadow:0 4px 18px rgba(26,90,122,.2)}

/* ═══════════════════════════════════════════════════════════════════
   HERO — CLINIC ANATOMY SCENE
═══════════════════════════════════════════════════════════════════ */
.chi-hero{
  position:relative;
  height:100vh;
  min-height:640px;
  max-height:960px;
  overflow:hidden;
  display:flex;
  align-items:center;
}

/* Gradient bg — deep clinical blue */
.chi-hero-bg{
  position:absolute;
  inset:0;
  background:linear-gradient(135deg,var(--chi-deep) 0%,var(--chi-navy) 40%,#0d3050 70%,var(--chi-teal) 100%);
}

/* Cross pattern overlay */
.chi-hero-pattern{
  position:absolute;
  inset:0;
  background-image:
    repeating-linear-gradient(0deg,rgba(255,255,255,.025) 0px,1px,transparent 1px,60px),
    repeating-linear-gradient(90deg,rgba(255,255,255,.025) 0px,1px,transparent 1px,60px);
}

/* Floating particles */
.chi-particle{
  position:absolute;
  border-radius:50%;
  background:rgba(200,220,240,.6);
  animation:chi-float var(--pf-dur,10s) var(--pf-del,0s) ease-in-out infinite alternate;
}
@keyframes chi-float{
  from{transform:translateY(0) scale(1);opacity:0}
  20%{opacity:1}
  80%{opacity:.6}
  100%{transform:translateY(-80px) scale(1.2);opacity:0}
}

/* CSS Spine illustration */
.chi-spine-art{
  position:absolute;
  right:8%;
  top:50%;
  transform:translateY(-50%);
  display:flex;
  flex-direction:column;
  align-items:center;
  gap:2px;
  opacity:.65;
}
.chi-vertebra{
  border-radius:3px;
  position:relative;
  display:flex;
  align-items:center;
  justify-content:center;
}
/* Disc between vertebrae */
.chi-disc{
  height:5px;
  border-radius:3px;
  background:var(--chi-disc);
  width:85%;
  opacity:.7;
}
.chi-vertebra-label{
  position:absolute;
  right:calc(100% + 6px);
  font-size:6px;
  font-weight:600;
  letter-spacing:.05em;
  color:rgba(200,220,240,.4);
  white-space:nowrap;
}
/* Spinal cord line */
.chi-spinal-cord{
  position:absolute;
  top:0;bottom:0;
  width:4px;
  background:linear-gradient(180deg,var(--chi-teal-lt),var(--chi-teal),var(--chi-teal-lt));
  border-radius:2px;
  left:50%;
  transform:translateX(-50%);
  opacity:.5;
}
/* Nerve roots */
.chi-nerve{
  position:absolute;
  top:50%;
  height:1px;
  background:rgba(200,220,240,.35);
  transform:translateY(-50%);
}
.chi-nerve-l{left:0;transform-origin:left center;transform:translateY(-50%) rotate(-20deg)}
.chi-nerve-r{right:0;transform-origin:right center;transform:translateY(-50%) rotate(20deg)}

/* Human silhouette outline */
.chi-human-outline{
  position:absolute;
  right:22%;
  top:50%;
  transform:translateY(-50%);
  opacity:.08;
}
/* CSS human body parts */
.chi-human-head{
  width:50px;height:50px;
  border-radius:50%;
  background:#fff;
  margin:0 auto;
}
.chi-human-neck{
  width:16px;height:20px;
  background:#fff;
  margin:0 auto;
}
.chi-human-torso{
  width:80px;height:120px;
  border-radius:20px 20px 10px 10px;
  background:#fff;
  margin:0 auto;
  position:relative;
}
.chi-human-hip{
  width:90px;height:40px;
  border-radius:0 0 30px 30px;
  background:#fff;
  margin:-10px auto 0;
}
.chi-human-legs{
  display:flex;
  justify-content:center;
  gap:6px;
}
.chi-human-leg{
  width:26px;height:100px;
  border-radius:0 0 13px 13px;
  background:#fff;
}

/* Glowing pulse rings */
.chi-pulse{
  position:absolute;
  border-radius:50%;
  border:1px solid rgba(58,154,170,.4);
  animation:chi-pulse-ring var(--pd,4s) var(--pdl,0s) ease-out infinite;
}
@keyframes chi-pulse-ring{
  0%{transform:translate(-50%,-50%) scale(.5);opacity:.8}
  100%{transform:translate(-50%,-50%) scale(2.5);opacity:0}
}

/* Hero text */
.chi-hero-content{
  position:relative;
  z-index:10;
  padding:0 0 0 8%;
  max-width:580px;
}
.chi-hero-badge{
  display:inline-flex;
  align-items:center;
  gap:8px;
  background:rgba(26,90,122,.3);
  backdrop-filter:blur(8px);
  border:1px solid rgba(58,154,170,.4);
  border-radius:50px;
  padding:6px 18px;
  font-size:.72rem;
  font-weight:600;
  letter-spacing:.14em;
  text-transform:uppercase;
  color:var(--chi-ice);
  margin-bottom:1.6rem;
}
.chi-hero-h1{
  font-family:var(--ff-head);
  font-size:clamp(2.4rem,5vw,4.5rem);
  font-weight:700;
  color:#fff;
  line-height:1.1;
  text-shadow:0 2px 24px rgba(10,26,42,.6);
  margin-bottom:.5rem;
}
.chi-hero-h1 span{
  color:var(--chi-sky);
  font-weight:300;
}
.chi-hero-sub{
  font-family:var(--ff-serif);
  font-size:clamp(1rem,1.8vw,1.2rem);
  font-style:italic;
  color:rgba(216,238,244,.75);
  margin-bottom:2.2rem;
  letter-spacing:.02em;
  line-height:1.65;
}
.chi-hero-btns{display:flex;gap:14px;flex-wrap:wrap}
.chi-hero-trust{
  margin-top:24px;
  display:flex;
  gap:18px;
  flex-wrap:wrap;
}
.chi-trust-item{
  display:flex;
  align-items:center;
  gap:7px;
  font-size:.78rem;
  color:rgba(216,238,244,.65);
}
.chi-trust-icon{font-size:.9rem}

/* ═══════════════════════════════════════════════════════════════════
   STATS BAND
═══════════════════════════════════════════════════════════════════ */
.chi-stats{
  background:var(--chi-navy);
  padding:28px 0;
}
.chi-stats-grid{
  display:grid;
  grid-template-columns:repeat(4,1fr);
  gap:0;
}
.chi-stat{
  text-align:center;
  padding:16px 12px;
  border-right:1px solid rgba(255,255,255,.07);
}
.chi-stat:last-child{border-right:none}
.chi-stat-num{
  font-size:2.2rem;
  font-weight:700;
  color:var(--chi-sky);
  display:block;line-height:1;
}
.chi-stat-suf{font-size:1.2rem;font-weight:300;color:var(--chi-disc)}
.chi-stat-label{
  font-size:.72rem;
  color:rgba(255,255,255,.45);
  letter-spacing:.08em;
  text-transform:uppercase;
  margin-top:6px;
  display:block;
}

/* ═══════════════════════════════════════════════════════════════════
   WHY US
═══════════════════════════════════════════════════════════════════ */
.chi-why-sec{
  padding:80px 0;
  background:var(--chi-white);
}
.chi-why-grid{
  display:grid;
  grid-template-columns:repeat(4,1fr);
  gap:20px;
}
.chi-why-card{
  text-align:center;
  padding:24px 16px;
  background:#fff;
  border:1px solid rgba(26,90,122,.1);
  border-radius:var(--rad);
  box-shadow:0 2px 14px rgba(10,26,42,.05);
  transition:var(--trans);
}
.chi-why-card:hover{
  transform:translateY(-3px);
  box-shadow:0 8px 26px rgba(10,26,42,.1);
  border-color:rgba(26,90,122,.25);
}
.chi-why-icon{font-size:1.8rem;display:block;margin-bottom:12px}
.chi-why-title{
  font-weight:700;
  font-size:.9rem;
  color:var(--chi-ink);
  margin-bottom:8px;
}
.chi-why-desc{font-size:.82rem;line-height:1.65;color:#4a6070}

/* ═══════════════════════════════════════════════════════════════════
   SERVICES
═══════════════════════════════════════════════════════════════════ */
.chi-services-sec{
  padding:100px 0;
  background:var(--chi-warm);
}
.chi-services-header{text-align:center;margin-bottom:52px}
.chi-services-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:22px;
}
.chi-service-card{
  background:#fff;
  border-radius:var(--rad);
  padding:28px 22px;
  border-top:3px solid var(--chi-teal);
  box-shadow:0 2px 16px rgba(10,26,42,.06);
  transition:var(--trans);
}
.chi-service-card:hover{
  transform:translateY(-3px);
  box-shadow:0 8px 28px rgba(10,26,42,.12);
}
.chi-service-icon{font-size:1.8rem;display:block;margin-bottom:12px}
.chi-service-name{
  font-weight:700;
  font-size:1rem;
  color:var(--chi-ink);
  margin-bottom:8px;
}
.chi-service-desc{
  font-size:.84rem;
  line-height:1.7;
  color:#4a6070;
  margin-bottom:14px;
}
.chi-service-meta{
  display:flex;
  gap:10px;
  flex-wrap:wrap;
}
.chi-service-tag{
  display:inline-flex;
  align-items:center;
  gap:5px;
  padding:4px 12px;
  border-radius:20px;
  font-size:.72rem;
  font-weight:600;
}
.chi-tag-time{background:var(--chi-ice);color:var(--chi-teal)}
.chi-tag-price{background:#f0f4e8;color:#3a6a3a}

/* ═══════════════════════════════════════════════════════════════════
   CONDITIONS TREATED
═══════════════════════════════════════════════════════════════════ */
.chi-conditions-sec{
  padding:100px 0;
  background:var(--chi-navy);
}
.chi-cond-header{text-align:center;margin-bottom:48px}
.chi-cond-header .chi-h2,.chi-cond-header .chi-lead{color:rgba(255,255,255,.9)}
.chi-cond-header .chi-eyebrow{color:var(--chi-sky)}
.chi-cond-header .chi-rule-line{background:linear-gradient(90deg,transparent,rgba(58,154,170,.4),transparent)}
.chi-cond-grid{
  display:flex;
  flex-wrap:wrap;
  gap:10px;
  justify-content:center;
}
.chi-cond-item{
  display:inline-flex;
  align-items:center;
  gap:8px;
  padding:10px 18px;
  background:rgba(255,255,255,.07);
  border:1px solid rgba(255,255,255,.1);
  border-radius:50px;
  font-size:.85rem;
  color:rgba(255,255,255,.85);
  transition:var(--trans);
  cursor:default;
}
.chi-cond-item:hover{
  background:rgba(58,154,170,.2);
  border-color:rgba(58,154,170,.5);
}
.chi-cond-item.chi-cond-common{
  background:rgba(58,154,170,.12);
  border-color:rgba(58,154,170,.3);
}
.chi-cond-icon{font-size:.75rem}

/* Spine diagram section */
.chi-spine-sec{
  padding:80px 0 0;
  background:var(--chi-navy);
}
.chi-spine-diagram{
  display:flex;
  gap:60px;
  align-items:center;
  justify-content:center;
}
.chi-spine-visual{
  display:flex;
  flex-direction:column;
  align-items:center;
  gap:2px;
  position:relative;
}
.chi-spine-label-col{
  position:absolute;
  left:calc(100% + 12px);
  top:0;bottom:0;
  display:flex;
  flex-direction:column;
  justify-content:space-around;
}
.chi-spine-section-label{
  font-size:.72rem;
  font-weight:700;
  letter-spacing:.08em;
  text-transform:uppercase;
}
.chi-spine-text{max-width:360px}
.chi-spine-text h3{
  font-family:var(--ff-head);
  font-size:1.5rem;
  font-weight:600;
  color:#fff;
  margin-bottom:14px;
}
.chi-spine-text p{
  font-size:.9rem;
  line-height:1.75;
  color:rgba(255,255,255,.65);
  margin-bottom:14px;
}
.chi-spine-regions{
  display:flex;
  flex-direction:column;
  gap:8px;
  margin-top:18px;
}
.chi-region-item{
  display:flex;
  align-items:center;
  gap:10px;
}
.chi-region-dot{
  width:10px;height:10px;
  border-radius:50%;
  flex-shrink:0;
}
.chi-region-text{font-size:.82rem;color:rgba(255,255,255,.7)}

/* ═══════════════════════════════════════════════════════════════════
   TEAM
═══════════════════════════════════════════════════════════════════ */
.chi-team-sec{
  padding:100px 0;
  background:var(--chi-white);
}
.chi-team-header{text-align:center;margin-bottom:52px}
.chi-team-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:26px;
}
.chi-team-card{
  background:#fff;
  border-radius:var(--rad);
  overflow:hidden;
  box-shadow:0 2px 18px rgba(10,26,42,.07);
  transition:var(--trans);
}
.chi-team-card:hover{
  transform:translateY(-4px);
  box-shadow:0 12px 36px rgba(10,26,42,.13);
}
/* CSS clinician figure */
.chi-clinician-art{
  height:170px;
  background:linear-gradient(180deg,var(--chi-ice),#eaf4f8);
  display:flex;
  align-items:flex-end;
  justify-content:center;
  position:relative;
  overflow:hidden;
}
.chi-clin-fig{
  display:flex;
  flex-direction:column;
  align-items:center;
  position:relative;
}
.chi-clin-head{
  width:36px;height:36px;
  border-radius:50%;
  position:relative;
  z-index:2;
  margin-bottom:-2px;
}
.chi-clin-hair{
  position:absolute;
  top:-4px;left:50%;
  transform:translateX(-50%);
  border-radius:50% 50% 0 0;
  z-index:3;
}
.chi-clin-body{
  width:52px;height:62px;
  border-radius:4px 4px 0 0;
  position:relative;
}
/* White coat */
.chi-clin-coat{
  position:absolute;
  top:0;left:-4px;right:-4px;bottom:0;
  background:#fff;
  border-radius:4px 4px 0 0;
  border-left:3px solid #e0e8f0;
  border-right:3px solid #e0e8f0;
}
.chi-clin-coat::before{
  content:'';
  position:absolute;
  top:2px;left:50%;
  transform:translateX(-50%);
  width:16px;height:4px;
  background:#d0dae4;
  border-radius:2px;
}
/* Stethoscope */
.chi-stethoscope{
  position:absolute;
  top:4px;
  left:50%;
  transform:translateX(-50%);
  width:28px;height:20px;
  border-bottom:3px solid #8aaa9a;
  border-radius:0 0 14px 14px;
}
.chi-stethoscope::before{
  content:'';
  position:absolute;
  bottom:-6px;left:50%;
  transform:translateX(-50%);
  width:8px;height:8px;
  border-radius:50%;
  background:#6a9a8a;
  border:2px solid #4a7a6a;
}
.chi-clin-arms{
  position:absolute;
  top:0;left:0;right:0;height:100%;
}
.chi-clin-arm{
  position:absolute;
  width:8px;height:34px;
  border-radius:4px;
  top:8px;
}
.chi-clin-arm-l{left:-10px;transform:rotate(-14deg);transform-origin:top}
.chi-clin-arm-r{right:-10px;transform:rotate(14deg);transform-origin:top}
.chi-team-body{padding:18px 16px}
.chi-team-name{
  font-weight:700;
  font-size:1rem;
  color:var(--chi-ink);
  margin-bottom:2px;
}
.chi-team-role{
  font-size:.8rem;
  color:var(--chi-teal);
  margin-bottom:4px;
  font-style:italic;
}
.chi-team-quals{
  font-size:.72rem;
  color:#7a8a9a;
  letter-spacing:.04em;
  margin-bottom:4px;
  font-weight:600;
}
.chi-team-exp{
  font-size:.72rem;
  color:var(--chi-sky);
  font-weight:600;
  margin-bottom:10px;
}
.chi-team-bio{
  font-size:.83rem;
  line-height:1.65;
  color:#4a6070;
}

/* ═══════════════════════════════════════════════════════════════════
   TESTIMONIALS
═══════════════════════════════════════════════════════════════════ */
.chi-test-sec{
  padding:100px 0;
  background:var(--chi-ice);
}
.chi-test-header{text-align:center;margin-bottom:48px}
.chi-test-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:22px;
}
.chi-test-card{
  background:#fff;
  border-radius:var(--rad);
  padding:26px 22px;
  box-shadow:0 2px 14px rgba(10,26,42,.06);
  position:relative;
}
.chi-test-card::before{
  content:'❝';
  position:absolute;
  top:14px;right:18px;
  font-size:3rem;
  color:var(--chi-ice);
  line-height:1;
  font-family:Georgia,serif;
}
.chi-test-cond{
  display:inline-block;
  padding:3px 10px;
  background:var(--chi-ice);
  border-radius:20px;
  font-size:.7rem;
  font-weight:600;
  color:var(--chi-teal);
  margin-bottom:12px;
}
.chi-test-stars{color:#c8a030;font-size:1rem;margin-bottom:12px}
.chi-test-quote{
  font-family:var(--ff-serif);
  font-size:.95rem;
  line-height:1.7;
  color:#3a5060;
  font-style:italic;
  margin-bottom:16px;
}
.chi-test-name{font-weight:700;font-size:.88rem;color:var(--chi-ink)}
.chi-test-loc{font-size:.75rem;color:#7a8a9a}

/* ═══════════════════════════════════════════════════════════════════
   FAQ
═══════════════════════════════════════════════════════════════════ */
.chi-faq-sec{
  padding:100px 0;
  background:var(--chi-white);
}
.chi-faq-inner{max-width:740px;margin:0 auto}
.chi-faq-header{text-align:center;margin-bottom:48px}
.chi-faq-item{border-bottom:1px solid rgba(10,26,42,.09)}
.chi-faq-q{
  width:100%;background:none;border:none;
  text-align:left;padding:18px 0;
  display:flex;align-items:center;justify-content:space-between;gap:14px;
  font-size:.96rem;font-weight:600;color:var(--chi-ink);
  cursor:pointer;transition:color var(--trans);
}
.chi-faq-q:hover{color:var(--chi-teal)}
.chi-faq-icon{
  width:24px;height:24px;border-radius:50%;
  background:var(--chi-ice);
  display:flex;align-items:center;justify-content:center;
  flex-shrink:0;transition:var(--trans);
  font-size:.9rem;color:var(--chi-teal);
}
.chi-faq-item.open .chi-faq-icon{transform:rotate(45deg);background:var(--chi-teal);color:#fff}
.chi-faq-a{overflow:hidden;max-height:0;transition:max-height .4s ease}
.chi-faq-a-inner{padding:0 0 18px;font-size:.9rem;line-height:1.75;color:#4a6070}

/* ═══════════════════════════════════════════════════════════════════
   APPOINTMENT FORM
═══════════════════════════════════════════════════════════════════ */
.chi-appt-sec{
  padding:100px 0;
  background:linear-gradient(135deg,var(--chi-deep) 0%,var(--chi-teal) 100%);
}
.chi-appt-wrap{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:60px;
  align-items:start;
}
.chi-appt-info .chi-h2{color:#fff}
.chi-appt-info .chi-eyebrow{color:var(--chi-sky)}
.chi-appt-info .chi-rule-line{background:linear-gradient(90deg,transparent,rgba(58,154,170,.4),transparent)}
.chi-appt-info .chi-rule-dot{background:var(--chi-sky)}
.chi-appt-info .chi-lead{color:rgba(255,255,255,.7)}
.chi-appt-details{
  margin-top:26px;
  display:flex;
  flex-direction:column;
  gap:12px;
}
.chi-detail-row{
  display:flex;align-items:flex-start;gap:12px;
  color:rgba(255,255,255,.75);font-size:.87rem;line-height:1.5;
}
.chi-detail-icon{
  width:32px;height:32px;border-radius:50%;
  background:rgba(255,255,255,.1);
  display:flex;align-items:center;justify-content:center;
  font-size:.95rem;flex-shrink:0;margin-top:1px;
}
.chi-form-card{
  background:#fff;
  border-radius:calc(var(--rad)*1.5);
  padding:34px 30px;
  box-shadow:0 20px 60px rgba(0,0,0,.25);
}
.chi-form-title{
  font-size:1.15rem;font-weight:700;
  color:var(--chi-ink);margin-bottom:6px;
}
.chi-form-sub{
  font-family:var(--ff-serif);
  font-size:.88rem;font-style:italic;
  color:#7a8a9a;margin-bottom:20px;
}
.chi-field{margin-bottom:16px}
.chi-field label{
  display:block;font-size:.72rem;font-weight:700;
  letter-spacing:.06em;text-transform:uppercase;
  color:var(--chi-teal);margin-bottom:6px;
}
.chi-field input,
.chi-field select,
.chi-field textarea{
  width:100%;padding:10px 13px;
  border:1.5px solid #d0dce4;border-radius:6px;
  font-family:var(--ff-head);font-size:.88rem;
  color:var(--chi-ink);background:#fff;
  transition:border-color var(--trans),box-shadow var(--trans);
}
.chi-field input:focus,
.chi-field select:focus,
.chi-field textarea:focus{
  outline:none;border-color:var(--chi-teal);
  box-shadow:0 0 0 3px rgba(26,90,122,.1);
}
.chi-field-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.chi-field textarea{resize:vertical;min-height:80px}
.chi-form-submit{
  width:100%;padding:13px;border-radius:50px;
  font-weight:700;font-size:.88rem;letter-spacing:.06em;text-transform:uppercase;
  border:none;cursor:pointer;
  background:linear-gradient(135deg,var(--chi-teal),var(--chi-teal-lt));
  color:#fff;
  box-shadow:0 4px 18px rgba(26,90,122,.35);
  transition:var(--trans);
}
.chi-form-submit:hover{transform:translateY(-2px);box-shadow:0 8px 26px rgba(26,90,122,.45)}
.chi-form-note{font-size:.72rem;color:#8a9aaa;text-align:center;margin-top:10px;line-height:1.5}

/* ═══════════════════════════════════════════════════════════════════
   RESPONSIVE
═══════════════════════════════════════════════════════════════════ */
@media(max-width:1000px){
  .chi-why-grid{grid-template-columns:repeat(2,1fr)}
  .chi-services-grid{grid-template-columns:repeat(2,1fr)}
  .chi-spine-diagram{flex-direction:column}
}
@media(max-width:900px){
  .chi-stats-grid{grid-template-columns:repeat(2,1fr)}
  .chi-team-grid{grid-template-columns:1fr}
  .chi-test-grid{grid-template-columns:1fr}
  .chi-appt-wrap{grid-template-columns:1fr}
  .chi-hero-content{padding-left:5%}
  .chi-spine-art{display:none}
  .chi-human-outline{display:none}
}
@media(max-width:600px){
  .chi-services-grid{grid-template-columns:1fr}
  .chi-why-grid{grid-template-columns:1fr}
  .chi-hero-btns{flex-direction:column}
  .chi-field-row{grid-template-columns:1fr}
}
</style>
<?php get_header(); ?>
<div class="chi-page">
>
<?php wp_body_open(); ?>

<!-- ═══════════════════════════════════════════════════════════════
     HERO — CLINICAL ANATOMY SCENE
═══════════════════════════════════════════════════════════════════ -->
<section class="chi-hero" aria-label="Hero">
  <div class="chi-hero-bg"></div>
  <div class="chi-hero-pattern"></div>

  <!-- Floating particles -->
  <?php foreach ($chi_particles as $p): ?>
  <div class="chi-particle" style="
    left:<?= $p['x'] ?>%;
    bottom:5%;
    width:<?= $p['size'] ?>px;
    height:<?= $p['size'] ?>px;
    opacity:<?= $p['op'] / 100 ?>;
    --pf-dur:<?= $p['dur'] ?>s;
    --pf-del:<?= $p['delay'] ?>s;
  " aria-hidden="true"></div>
  <?php endforeach; ?>

  <!-- Human silhouette outline -->
  <div class="chi-human-outline" aria-hidden="true">
    <div class="chi-human-head"></div>
    <div class="chi-human-neck"></div>
    <div class="chi-human-torso"></div>
    <div class="chi-human-hip"></div>
    <div class="chi-human-legs">
      <div class="chi-human-leg"></div>
      <div class="chi-human-leg"></div>
    </div>
  </div>

  <!-- Spine illustration -->
  <div class="chi-spine-art" aria-hidden="true">
    <div class="chi-spinal-cord"></div>
    <?php
    $prev_type = '';
    foreach ($vertebrae as $vt):
      if ($prev_type && $prev_type !== $vt['type']):
    ?>
    <div class="chi-disc" style="width:<?= intval($vt['w'] * .85) ?>px"></div>
    <?php endif; $prev_type = $vt['type']; ?>
    <div class="chi-vertebra" style="width:<?= $vt['w'] ?>px;height:<?= $vt['h'] ?>px;background:<?= $vt['col'] ?>;border-radius:<?= ($vt['type']==='sacrum') ? '4px 4px 12px 12px' : '3px' ?>">
      <div class="chi-nerve chi-nerve-l" style="width:<?= intval($vt['w'] * .4) ?>px"></div>
      <div class="chi-nerve chi-nerve-r" style="width:<?= intval($vt['w'] * .4) ?>px"></div>
      <span class="chi-vertebra-label"><?= esc_html($vt['label']) ?></span>
    </div>
    <?php if ($vt['type'] !== 'sacrum'): ?>
    <div class="chi-disc" style="width:<?= intval($vt['w'] * .7) ?>px"></div>
    <?php endif; endforeach; ?>
  </div>

  <!-- Pulse rings -->
  <div class="chi-pulse" style="width:80px;height:80px;top:45%;right:14%;--pd:3s;--pdl:0s" aria-hidden="true"></div>
  <div class="chi-pulse" style="width:80px;height:80px;top:45%;right:14%;--pd:3s;--pdl:1s" aria-hidden="true"></div>
  <div class="chi-pulse" style="width:80px;height:80px;top:45%;right:14%;--pd:3s;--pdl:2s" aria-hidden="true"></div>

  <!-- Hero content -->
  <div class="chi-hero-content">
    <span class="chi-hero-badge">🏥 GCC Registered · London</span>
    <h1 class="chi-hero-h1">Move<br><span>without</span><br>pain</h1>
    <p class="chi-hero-sub">Expert chiropractic care, physiotherapy and sports injury rehabilitation — delivered by GCC-registered clinicians.</p>
    <div class="chi-hero-btns">
      <a href="#appointment" class="chi-btn chi-btn-primary">Book an Appointment</a>
      <a href="#services" class="chi-btn chi-btn-ghost">Our Services</a>
    </div>
    <div class="chi-hero-trust">
      <div class="chi-trust-item"><span class="chi-trust-icon">✅</span> GCC Registered</div>
      <div class="chi-trust-item"><span class="chi-trust-icon">🏥</span> BUPA Recognised</div>
      <div class="chi-trust-item"><span class="chi-trust-icon">📅</span> Same-Day Appointments</div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     STATS BAND
═══════════════════════════════════════════════════════════════════ -->
<section class="chi-stats" aria-label="Clinic at a glance">
  <div class="chi-wrap">
    <div class="chi-stats-grid">
      <div class="chi-stat">
        <span class="chi-stat-num"><span class="chi-counter" data-target="4800">0</span><span class="chi-stat-suf">+</span></span>
        <span class="chi-stat-label">Patients Treated</span>
      </div>
      <div class="chi-stat">
        <span class="chi-stat-num"><span class="chi-counter" data-target="4.9">0</span></span>
        <span class="chi-stat-label">Google Rating</span>
      </div>
      <div class="chi-stat">
        <span class="chi-stat-num"><span class="chi-counter" data-target="18">0</span></span>
        <span class="chi-stat-label">Years of Practice</span>
      </div>
      <div class="chi-stat">
        <span class="chi-stat-num"><span class="chi-counter" data-target="96">0</span><span class="chi-stat-suf">%</span></span>
        <span class="chi-stat-label">Patient Satisfaction</span>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     WHY US
═══════════════════════════════════════════════════════════════════ -->
<section class="chi-why-sec" aria-labelledby="chi-why-h">
  <div class="chi-wrap">
    <div style="text-align:center;margin-bottom:40px">
      <span class="chi-eyebrow">Why Choose Us</span>
      <h2 class="chi-h2" id="chi-why-h">Care you can <strong>trust</strong></h2>
      <div class="chi-rule" style="justify-content:center"><div class="chi-rule-line"></div><div class="chi-rule-dot"></div><div class="chi-rule-line"></div></div>
    </div>
    <div class="chi-why-grid">
      <?php foreach ($why_items as $w): ?>
      <div class="chi-why-card">
        <span class="chi-why-icon"><?= $w['icon'] ?></span>
        <div class="chi-why-title"><?= esc_html($w['title']) ?></div>
        <p class="chi-why-desc"><?= esc_html($w['desc']) ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     SERVICES
═══════════════════════════════════════════════════════════════════ -->
<section class="chi-services-sec" id="services" aria-labelledby="chi-srv-h">
  <div class="chi-wrap">
    <div class="chi-services-header">
      <span class="chi-eyebrow">Our Treatments</span>
      <h2 class="chi-h2" id="chi-srv-h">What we <strong>treat</strong></h2>
      <div class="chi-rule" style="justify-content:center"><div class="chi-rule-line"></div><div class="chi-rule-dot"></div><div class="chi-rule-line"></div></div>
      <p class="chi-lead chi-centre">Every treatment plan is tailored to the individual — combining manual therapy, rehabilitation exercises and lifestyle guidance to achieve lasting results.</p>
    </div>
    <div class="chi-services-grid">
      <?php foreach ($services as $srv): ?>
      <div class="chi-service-card">
        <span class="chi-service-icon"><?= $srv['icon'] ?></span>
        <div class="chi-service-name"><?= esc_html($srv['name']) ?></div>
        <p class="chi-service-desc"><?= esc_html($srv['desc']) ?></p>
        <div class="chi-service-meta">
          <span class="chi-service-tag chi-tag-time">⏱ <?= esc_html($srv['time']) ?></span>
          <span class="chi-service-tag chi-tag-price"><?= esc_html($srv['price']) ?></span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     CONDITIONS TREATED
═══════════════════════════════════════════════════════════════════ -->
<section class="chi-conditions-sec" aria-labelledby="chi-cond-h">
  <div class="chi-wrap">
    <div class="chi-cond-header">
      <span class="chi-eyebrow">Conditions We Treat</span>
      <h2 class="chi-h2" id="chi-cond-h">Pain has many <strong>forms</strong></h2>
      <div class="chi-rule" style="justify-content:center"><div class="chi-rule-line"></div><div class="chi-rule-dot" style="background:var(--chi-sky)"></div><div class="chi-rule-line"></div></div>
      <p class="chi-lead chi-centre" style="color:rgba(255,255,255,.65)">We treat a wide range of musculoskeletal conditions. Common presentations are highlighted — but please contact us if you don't see your condition listed.</p>
    </div>
    <div class="chi-cond-grid">
      <?php foreach ($conditions as $cond): ?>
      <div class="chi-cond-item <?= $cond['common'] ? 'chi-cond-common' : '' ?>">
        <span class="chi-cond-icon"><?= $cond['icon'] ?></span>
        <span><?= esc_html($cond['name']) ?></span>
        <?php if ($cond['common']): ?>
        <span style="font-size:.65rem;opacity:.6;margin-left:2px">↑</span>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Mini spine diagram explanation -->
    <div class="chi-spine-diagram" style="margin-top:60px;padding-top:60px;border-top:1px solid rgba(255,255,255,.08)">
      <div class="chi-spine-visual" aria-hidden="true">
        <?php
        $zones = [
          ['label'=>'Cervical','col'=>'#4a7a9a','verts'=>7,'h'=>14,'w_start'=>40,'w_end'=>48],
          ['label'=>'Thoracic','col'=>'#3a6a8a','verts'=>6,'h'=>14,'w_start'=>50,'w_end'=>56],
          ['label'=>'Lumbar', 'col'=>'#2a5a7a','verts'=>5,'h'=>18,'w_start'=>58,'w_end'=>66],
          ['label'=>'Sacrum', 'col'=>'#1a4a6a','verts'=>1,'h'=>38,'w_start'=>60,'w_end'=>60],
        ];
        foreach ($zones as $zone):
          $vstep = ($zone['w_end'] - $zone['w_start']) / max(1, $zone['verts'] - 1);
        ?>
        <?php for ($vi = 0; $vi < $zone['verts']; $vi++): $vw = intval($zone['w_start'] + $vi * $vstep); ?>
        <div style="width:<?= $vw ?>px;height:<?= $zone['h'] ?>px;background:<?= $zone['col'] ?>;border-radius:<?= ($zone['label']==='Sacrum') ? '3px 3px 10px 10px' : '2px' ?>;margin:1px 0"></div>
        <?php endfor; ?>
        <?php endforeach; ?>
      </div>
      <div class="chi-spine-text">
        <h3>Your spine: the foundation of movement</h3>
        <p>The spine consists of 33 vertebrae in five regions — each playing a critical role in protecting the spinal cord, bearing load and enabling movement. Chiropractic care addresses dysfunction at any level of this system.</p>
        <div class="chi-spine-regions">
          <div class="chi-region-item"><div class="chi-region-dot" style="background:#4a7a9a"></div><span class="chi-region-text">Cervical (C1–C7) — Neck &amp; head movement</span></div>
          <div class="chi-region-item"><div class="chi-region-dot" style="background:#3a6a8a"></div><span class="chi-region-text">Thoracic (T1–T12) — Rib cage &amp; organ protection</span></div>
          <div class="chi-region-item"><div class="chi-region-dot" style="background:#2a5a7a"></div><span class="chi-region-text">Lumbar (L1–L5) — Load bearing &amp; trunk rotation</span></div>
          <div class="chi-region-item"><div class="chi-region-dot" style="background:#1a4a6a"></div><span class="chi-region-text">Sacrum &amp; Coccyx — Pelvic stability &amp; weight transfer</span></div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     TEAM
═══════════════════════════════════════════════════════════════════ -->
<section class="chi-team-sec" aria-labelledby="chi-team-h">
  <div class="chi-wrap">
    <div class="chi-team-header">
      <span class="chi-eyebrow">Our Clinical Team</span>
      <h2 class="chi-h2" id="chi-team-h">Expert hands, <strong>genuine care</strong></h2>
      <div class="chi-rule" style="justify-content:center"><div class="chi-rule-line"></div><div class="chi-rule-dot"></div><div class="chi-rule-line"></div></div>
    </div>
    <div class="chi-team-grid">
      <?php foreach ($team as $m): ?>
      <div class="chi-team-card">
        <div class="chi-clinician-art">
          <div class="chi-clin-fig">
            <div class="chi-clin-hair" style="background:<?= esc_attr($m['hair']) ?>;width:40px;height:16px"></div>
            <div class="chi-clin-head" style="background:<?= esc_attr($m['skin']) ?>"></div>
            <div class="chi-clin-body" style="background:<?= esc_attr($m['top']) ?>">
              <?php if ($m['coat']): ?><div class="chi-clin-coat"></div><?php endif; ?>
              <div class="chi-stethoscope"></div>
              <div class="chi-clin-arms">
                <div class="chi-clin-arm chi-clin-arm-l" style="background:<?= esc_attr($m['skin']) ?>"></div>
                <div class="chi-clin-arm chi-clin-arm-r" style="background:<?= esc_attr($m['skin']) ?>"></div>
              </div>
            </div>
          </div>
        </div>
        <div class="chi-team-body">
          <div class="chi-team-name"><?= esc_html($m['name']) ?></div>
          <div class="chi-team-role"><?= esc_html($m['role']) ?></div>
          <div class="chi-team-quals"><?= esc_html($m['quals']) ?></div>
          <div class="chi-team-exp"><?= esc_html($m['exp']) ?> clinical experience</div>
          <p class="chi-team-bio"><?= esc_html($m['bio']) ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     TESTIMONIALS
═══════════════════════════════════════════════════════════════════ -->
<section class="chi-test-sec" aria-labelledby="chi-test-h">
  <div class="chi-wrap">
    <div class="chi-test-header">
      <span class="chi-eyebrow">Patient Stories</span>
      <h2 class="chi-h2" id="chi-test-h">Real results, <strong>real patients</strong></h2>
      <div class="chi-rule" style="justify-content:center"><div class="chi-rule-line"></div><div class="chi-rule-dot"></div><div class="chi-rule-line"></div></div>
    </div>
    <div class="chi-test-grid">
      <?php foreach ($testimonials as $t): ?>
      <div class="chi-test-card">
        <span class="chi-test-cond"><?= $t['cond'] ?></span>
        <div class="chi-test-stars"><?= str_repeat('★', $t['stars']) ?></div>
        <p class="chi-test-quote"><?= esc_html($t['quote']) ?></p>
        <div class="chi-test-name"><?= $t['name'] ?></div>
        <div class="chi-test-loc"><?= esc_html($t['loc']) ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     FAQ
═══════════════════════════════════════════════════════════════════ -->
<section class="chi-faq-sec" aria-labelledby="chi-faq-h">
  <div class="chi-wrap">
    <div class="chi-faq-inner">
      <div class="chi-faq-header">
        <span class="chi-eyebrow">Frequently Asked</span>
        <h2 class="chi-h2" id="chi-faq-h">Your questions <strong>answered</strong></h2>
        <div class="chi-rule" style="justify-content:center"><div class="chi-rule-line"></div><div class="chi-rule-dot"></div><div class="chi-rule-line"></div></div>
      </div>
      <div class="chi-faq-list">
        <?php foreach ($faqs as $fi => $faq): ?>
        <div class="chi-faq-item" id="chi-faq-<?= $fi ?>">
          <button class="chi-faq-q" aria-expanded="false" aria-controls="chi-faq-a-<?= $fi ?>">
            <span><?= esc_html($faq['q']) ?></span>
            <span class="chi-faq-icon" aria-hidden="true">+</span>
          </button>
          <div class="chi-faq-a" id="chi-faq-a-<?= $fi ?>" role="region">
            <div class="chi-faq-a-inner"><?= esc_html($faq['a']) ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     APPOINTMENT FORM
═══════════════════════════════════════════════════════════════════ -->
<section class="chi-appt-sec" id="appointment" aria-labelledby="chi-appt-h">
  <div class="chi-wrap">
    <div class="chi-appt-wrap">

      <div class="chi-appt-info">
        <span class="chi-eyebrow">Book an Appointment</span>
        <h2 class="chi-h2" id="chi-appt-h">Take the first <strong>step</strong></h2>
        <div class="chi-rule"><div class="chi-rule-line"></div><div class="chi-rule-dot" style="background:var(--chi-sky)"></div><div class="chi-rule-line"></div></div>
        <p class="chi-lead">Ready to move without pain? Complete the form and our reception team will confirm your appointment within one working day — or call us for same-day bookings.</p>
        <div class="chi-appt-details">
          <div class="chi-detail-row"><div class="chi-detail-icon">📍</div><span>14 Harley Street, Marylebone, London W1G 9PH</span></div>
          <div class="chi-detail-row"><div class="chi-detail-icon">📞</div><span>+44 (0)20 7224 0000 (Mon–Fri 08:00–20:00, Sat 09:00–14:00)</span></div>
          <div class="chi-detail-row"><div class="chi-detail-icon">✉️</div><span>hello@alignclinic.co.uk</span></div>
          <div class="chi-detail-row"><div class="chi-detail-icon">🏥</div><span>BUPA, AXA PPP, Vitality &amp; Cigna recognised</span></div>
          <div class="chi-detail-row"><div class="chi-detail-icon">⏰</div><span>Same-day urgent appointments available — call to check availability</span></div>
        </div>
      </div>

      <div class="chi-form-card">
        <div class="chi-form-title">Request an Appointment</div>
        <div class="chi-form-sub">We'll call to confirm within one working day</div>
        <form method="post" action="" novalidate>
          <?php wp_nonce_field('tf_chi_appointment','tf_chi_nonce'); ?>
          <div class="chi-field-row">
            <div class="chi-field">
              <label for="chi-fname">First Name</label>
              <input type="text" id="chi-fname" name="tf_first_name" required autocomplete="given-name" placeholder="e.g. James">
            </div>
            <div class="chi-field">
              <label for="chi-lname">Last Name</label>
              <input type="text" id="chi-lname" name="tf_last_name" required autocomplete="family-name" placeholder="e.g. Roberts">
            </div>
          </div>
          <div class="chi-field">
            <label for="chi-email">Email Address</label>
            <input type="email" id="chi-email" name="tf_email" required autocomplete="email" placeholder="you@example.com">
          </div>
          <div class="chi-field">
            <label for="chi-phone">Phone Number</label>
            <input type="tel" id="chi-phone" name="tf_phone" required autocomplete="tel" placeholder="+44 7700 000000">
          </div>
          <div class="chi-field">
            <label for="chi-treatment">Treatment Required</label>
            <select id="chi-treatment" name="tf_treatment">
              <option value="">— Select treatment —</option>
              <?php foreach ($services as $srv): ?>
              <option value="<?= esc_attr(sanitize_title($srv['name'])) ?>"><?= esc_html($srv['name']) ?></option>
              <?php endforeach; ?>
              <option value="not_sure">Not sure — need advice</option>
            </select>
          </div>
          <div class="chi-field">
            <label for="chi-urgency">How urgent is your need?</label>
            <select id="chi-urgency" name="tf_urgency">
              <option value="">— Select urgency —</option>
              <option value="same_day">Same day if possible</option>
              <option value="this_week">This week</option>
              <option value="next_week">Next week</option>
              <option value="flexible">Flexible — any time</option>
            </select>
          </div>
          <div class="chi-field">
            <label for="chi-insurance">Private Health Insurance (if applicable)</label>
            <select id="chi-insurance" name="tf_insurance">
              <option value="">— Select insurer or self-pay —</option>
              <option value="self_pay">Self-pay</option>
              <option value="bupa">BUPA</option>
              <option value="axa">AXA PPP</option>
              <option value="vitality">Vitality Health</option>
              <option value="cigna">Cigna</option>
              <option value="other">Other insurer</option>
            </select>
          </div>
          <div class="chi-field">
            <label for="chi-symptoms">Describe your symptoms</label>
            <textarea id="chi-symptoms" name="tf_symptoms" placeholder="Please describe your main complaint, how long you've had it, and anything you know about what caused it…"></textarea>
          </div>
          <button type="submit" class="chi-form-submit">Request Appointment</button>
          <p class="chi-form-note">Your personal data is handled in accordance with our Privacy Policy and used solely for appointment scheduling.</p>
        </form>
      </div>

    </div>
  </div>
</section>
<script>
(function(){
  /* ── Animated counters ────────────────────────────────────────── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  document.querySelectorAll('.chi-counter').forEach(el => {
    const raw = el.dataset.target;
    if (!raw) return;
    const isFloat = raw.indexOf('.') !== -1;
    const target  = parseFloat(raw);
    if (isNaN(target)) return;
    let started = false;
    const obs = new IntersectionObserver(entries => {
      if (!entries[0].isIntersecting || started) return;
      started = true; obs.disconnect();
      const dur = 1800, start = performance.now();
      const tick = now => {
        const t   = Math.min((now - start) / dur, 1);
        const val = target * easeOut(t);
        el.textContent = isFloat ? val.toFixed(1) : Math.round(val).toLocaleString();
        if (t < 1) requestAnimationFrame(tick);
        else el.textContent = isFloat ? target.toFixed(1) : target.toLocaleString();
      };
      requestAnimationFrame(tick);
    }, {threshold:.3});
    obs.observe(el);
  });

  /* ── FAQ accordion ────────────────────────────────────────────── */
  document.querySelectorAll('.chi-faq-q').forEach(btn => {
    btn.addEventListener('click', () => {
      const item   = btn.closest('.chi-faq-item');
      const answer = item.querySelector('.chi-faq-a');
      const isOpen = item.classList.contains('open');
      document.querySelectorAll('.chi-faq-item.open').forEach(op => {
        op.classList.remove('open');
        op.querySelector('.chi-faq-a').style.maxHeight = '0';
        op.querySelector('.chi-faq-q').setAttribute('aria-expanded','false');
      });
      if (!isOpen) {
        item.classList.add('open');
        answer.style.maxHeight = answer.scrollHeight + 'px';
        btn.setAttribute('aria-expanded','true');
      }
    });
  });
})();
</script>
</div><!-- .chi-page -->
<?php get_footer(); ?>
