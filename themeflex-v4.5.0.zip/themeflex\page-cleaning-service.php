<?php
/**
 * Template Name: Cleaning Service
 *
 * Premium landing page for a professional home & office cleaning company.
 * Hero: CSS sparkle/bubble scene — cleaning figure with mop, suds, shine rays, bubbles.
 * Namespace: --cs-* | Fonts: Exo 2 + Open Sans | Palette: sky blue / teal / white / lemon
 *
 * @package ThemeFlex
 */

get_header(); ?>

<style>
/* ── Fonts ─────────────────────────────────────────────────── */
@import url('https://fonts.googleapis.com/css2?family=Exo+2:wght@300;400;500;600;700;800&family=Open+Sans:wght@300;400;500;600&display=swap');

/* ── Token System ───────────────────────────────────────────── */
:root {
  --cs-sky:    #0288D1;
  --cs-sky-lt: #29B6F6;
  --cs-sky-dk: #01579B;
  --cs-teal:   #00897B;
  --cs-teal-lt:#26A69A;
  --cs-teal-dk:#00695C;
  --cs-lemon:  #FDD835;
  --cs-white:  #FFFFFF;
  --cs-cream:  #F7FBFE;
  --cs-light:  #E3F2FD;
  --cs-text:   #0D1B2A;
  --cs-text-lt:#3F5A72;
  --cs-shadow: rgba(13,27,42,0.12);

  --cs-r:    8px;
  --cs-r-lg: 16px;
  --cs-r-xl: 24px;

  --ff-head: 'Exo 2', system-ui, sans-serif;
  --ff-body: 'Open Sans', system-ui, sans-serif;
}

/* ── Reset ─────────────────────────────────────────────────── */
.cs-page *, .cs-page *::before, .cs-page *::after { box-sizing: border-box; margin: 0; padding: 0; }
.cs-page { font-family: var(--ff-body); color: var(--cs-text); background: var(--cs-cream); overflow-x: hidden; }
.cs-page a { color: inherit; text-decoration: none; }

/* ── Layout ─────────────────────────────────────────────────── */
.cs-wrap    { max-width: 1160px; margin: 0 auto; padding: 0 24px; }
.cs-section { padding: 80px 0; }
.cs-section--alt { background: var(--cs-white); }

/* ── Typography ─────────────────────────────────────────────── */
.cs-eyebrow { font-family: var(--ff-head); font-size: .73rem; font-weight: 700; letter-spacing: .14em; text-transform: uppercase; color: var(--cs-sky); margin-bottom: 10px; }
.cs-h1 { font-family: var(--ff-head); font-size: clamp(2.4rem,5.2vw,3.8rem); font-weight: 800; line-height: 1.12; }
.cs-h2 { font-family: var(--ff-head); font-size: clamp(1.8rem,3.5vw,2.7rem); font-weight: 700; line-height: 1.18; margin-bottom: 16px; }
.cs-h3 { font-family: var(--ff-head); font-size: 1.25rem; font-weight: 600; margin-bottom: 8px; }
.cs-lead { font-size: 1.07rem; line-height: 1.78; color: var(--cs-text-lt); }

/* ── Buttons ─────────────────────────────────────────────────── */
.cs-btn {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 14px 32px; border-radius: 50px; font-family: var(--ff-head);
  font-size: .95rem; font-weight: 700; cursor: pointer;
  transition: transform .2s, box-shadow .2s; border: none; letter-spacing: .04em;
}
.cs-btn--primary { background: var(--cs-sky); color: var(--cs-white); box-shadow: 0 4px 18px rgba(2,136,209,.4); }
.cs-btn--primary:hover { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(2,136,209,.55); }
.cs-btn--teal   { background: var(--cs-teal); color: var(--cs-white); box-shadow: 0 4px 18px rgba(0,137,123,.35); }
.cs-btn--teal:hover   { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(0,137,123,.5); }
.cs-btn--outline { background: transparent; color: var(--cs-white); border: 2px solid rgba(255,255,255,.7); }
.cs-btn--outline:hover { background: rgba(255,255,255,.12); transform: translateY(-2px); }

/* ============================================================
   HERO — SPARKLE / CLEAN SCENE
   ============================================================ */
.cs-hero {
  position: relative; overflow: hidden;
  min-height: 100vh; display: flex; align-items: center;
  background: linear-gradient(140deg, var(--cs-sky-dk) 0%, var(--cs-sky) 50%, var(--cs-teal-lt) 100%);
}

/* ── Animated bubbles ── */
.cs-bubble {
  position: absolute; border-radius: 50%;
  border: 2px solid rgba(255,255,255,.4);
  background: radial-gradient(circle at 30% 30%, rgba(255,255,255,.35), rgba(255,255,255,.05));
  animation: cs-bubble-rise linear infinite;
}
@keyframes cs-bubble-rise {
  from { transform: translateY(0) scale(1); opacity: .8; }
  to   { transform: translateY(-100vh) scale(1.2); opacity: 0; }
}

/* ── Shine rays ── */
.cs-shine {
  position: absolute; width: 3px;
  background: linear-gradient(180deg, rgba(253,216,53,.9), transparent);
  transform-origin: bottom center;
  animation: cs-shine-pulse 2.5s ease-in-out infinite;
}
@keyframes cs-shine-pulse {
  0%,100% { opacity: .7; transform: scaleY(1); }
  50%      { opacity: 1;  transform: scaleY(1.15); }
}

/* ── Floor / wall ── */
.cs-hero__floor {
  position: absolute; bottom: 0; left: 0; right: 0; height: 28%;
  background: linear-gradient(180deg, #E3F2FD, #BBDEFB);
}
.cs-hero__floor::before {
  content:''; position: absolute; top: 0; left: 0; right: 0; height: 6px;
  background: rgba(2,136,209,.3);
}
/* Floor tile pattern */
.cs-hero__floor::after {
  content:''; position: absolute; inset: 6px 0 0;
  background: repeating-linear-gradient(
    90deg,
    transparent, transparent 79px,
    rgba(2,136,209,.08) 79px, rgba(2,136,209,.08) 80px
  ),
  repeating-linear-gradient(
    0deg,
    transparent, transparent 59px,
    rgba(2,136,209,.08) 59px, rgba(2,136,209,.08) 60px
  );
}

/* ── Bucket ── */
.cs-bucket {
  position: absolute; bottom: 28%; right: 28%;
}
.cs-bucket__body {
  width: 48px; height: 44px;
  background: linear-gradient(180deg, var(--cs-lemon), #F9A825);
  clip-path: polygon(5% 0%, 95% 0%, 88% 100%, 12% 100%);
  border-radius: 0 0 6px 6px; position: relative;
}
.cs-bucket__handle {
  position: absolute; top: -14px; left: 50%;
  width: 34px; height: 18px; border-radius: 50%;
  border: 4px solid #E65100;
  transform: translateX(-50%);
}
/* Suds on bucket */
.cs-bucket__suds {
  position: absolute; top: -8px; left: 50%;
  transform: translateX(-50%);
  width: 54px; display: flex; gap: 4px; justify-content: center;
}
.cs-suds-blob {
  border-radius: 50%;
  background: rgba(255,255,255,.9);
  animation: cs-suds-bob 2s ease-in-out infinite;
}
.cs-suds-blob:nth-child(1) { width: 16px; height: 14px; animation-delay: 0s; }
.cs-suds-blob:nth-child(2) { width: 12px; height: 12px; animation-delay: -.5s; }
.cs-suds-blob:nth-child(3) { width: 14px; height: 16px; animation-delay: -1s; }
.cs-suds-blob:nth-child(4) { width: 10px; height: 10px; animation-delay: -1.5s; }
@keyframes cs-suds-bob {
  0%,100% { transform: translateY(0) scale(1); }
  50%      { transform: translateY(-4px) scale(1.1); }
}

/* ── Mop / cleaning person ── */
.cs-cleaner {
  position: absolute; bottom: 28%; right: 22%;
  display: flex; flex-direction: column; align-items: center;
}
/* Head */
.cs-cleaner__head {
  width: 32px; height: 36px; border-radius: 50% 50% 45% 45%;
  background: #FFCCBC; position: relative;
}
.cs-cleaner__head::before {
  content:''; position: absolute;
  width: 7px; height: 7px; border-radius: 50%; background: #3E2723;
  top: 38%; left: 17%; box-shadow: 12px 0 0 #3E2723;
}
.cs-cleaner__head::after {
  content:''; position: absolute;
  width: 14px; height: 7px;
  border: 2px solid #3E2723; border-top: none; border-radius: 0 0 50% 50%;
  bottom: 22%; left: 50%; transform: translateX(-50%);
}
/* Bandana / hair */
.cs-cleaner__bandana {
  position: absolute; width: 36px; height: 16px; border-radius: 50% 50% 0 0;
  background: var(--cs-sky); top: -10px; left: -2px;
}
.cs-cleaner__body {
  width: 40px; height: 48px; border-radius: 6px 6px 0 0;
  background: var(--cs-teal); margin-top: -2px; position: relative;
}
/* Logo on uniform */
.cs-cleaner__body::before {
  content:'✦'; position: absolute; top: 6px; left: 50%;
  transform: translateX(-50%); color: rgba(255,255,255,.6); font-size: .75rem;
}
/* Arm holding mop handle */
.cs-cleaner__arm {
  position: absolute; width: 12px; height: 38px; border-radius: 6px;
  background: var(--cs-teal); top: 4px; right: -10px;
  transform: rotate(25deg); transform-origin: top center;
}
/* Legs */
.cs-cleaner__legs { display: flex; gap: 5px; }
.cs-cleaner__leg  { width: 17px; height: 28px; border-radius: 0 0 5px 5px; background: #546E7A; }
/* Shoes */
.cs-cleaner__shoes { display: flex; gap: 5px; }
.cs-cleaner__shoe  { width: 19px; height: 10px; border-radius: 0 8px 8px 0; background: #263238; margin-top: -2px; }
.cs-cleaner__shoe:first-child { border-radius: 8px 0 0 8px; }

/* Mop */
.cs-mop {
  position: absolute; bottom: 28%; right: calc(22% - 14px);
}
.cs-mop__handle { width: 6px; height: 80px; background: #A1887F; border-radius: 3px; }
.cs-mop__head {
  width: 36px; height: 14px; border-radius: 4px; background: #90CAF9;
  margin-left: -15px; margin-top: -2px; position: relative;
  box-shadow: 0 4px 8px rgba(2,136,209,.3);
}
/* Wet streak on floor */
.cs-mop__streak {
  position: absolute; bottom: -8px; left: -4px;
  width: 44px; height: 10px; border-radius: 50%;
  background: rgba(41,182,246,.25); filter: blur(2px);
}

/* ── Sparkle stars near cleaned area ── */
.cs-sparkle {
  position: absolute; font-size: 1rem; color: var(--cs-lemon);
  animation: cs-sparkle-pop 1.8s ease-in-out infinite;
}
@keyframes cs-sparkle-pop {
  0%,100% { transform: scale(1) rotate(0deg); opacity: 1; }
  50%      { transform: scale(1.4) rotate(20deg); opacity: .6; }
}

/* ── Hero copy ── */
.cs-hero__inner {
  position: relative; z-index: 10;
  max-width: 580px; padding: 40px 24px 40px 60px;
}
.cs-hero__rating {
  display: inline-flex; align-items: center; gap: 6px;
  background: rgba(255,255,255,.12); backdrop-filter: blur(8px);
  border: 1px solid rgba(255,255,255,.25); border-radius: 50px;
  font-size: .82rem; font-weight: 600; color: rgba(255,255,255,.9);
  padding: 6px 16px; margin-bottom: 20px;
}
.cs-hero__title { color: var(--cs-white); text-shadow: 0 2px 16px rgba(0,0,0,.3); margin-bottom: 18px; }
.cs-hero__sub   { font-size: 1.1rem; color: rgba(255,255,255,.88); line-height: 1.75; margin-bottom: 30px; }
.cs-hero__ctas  { display: flex; gap: 14px; flex-wrap: wrap; }

/* Trust badges */
.cs-trust { display: flex; flex-wrap: wrap; gap: 12px; margin-top: 26px; }
.cs-trust-badge {
  background: rgba(255,255,255,.15); border: 1px solid rgba(255,255,255,.25);
  border-radius: var(--cs-r); padding: 7px 14px;
  font-size: .8rem; font-weight: 600; color: rgba(255,255,255,.9);
}

/* ============================================================
   STATS
   ============================================================ */
.cs-stats { background: var(--cs-sky-dk); padding: 40px 0; }
.cs-stats__grid { display: grid; grid-template-columns: repeat(4,1fr); }
.cs-stat { text-align: center; padding: 16px; border-right: 1px solid rgba(255,255,255,.12); }
.cs-stat:last-child { border-right: none; }
.cs-stat__number { font-family: var(--ff-head); font-size: 2.6rem; font-weight: 800; color: var(--cs-lemon); line-height: 1; }
.cs-stat__label  { font-size: .82rem; color: rgba(255,255,255,.68); margin-top: 6px; }

/* ============================================================
   WHY CHOOSE US (USPs)
   ============================================================ */
.cs-usps { display: grid; grid-template-columns: repeat(auto-fit,minmax(240px,1fr)); gap: 24px; margin-top: 48px; }
.cs-usp {
  background: var(--cs-white); border-radius: var(--cs-r-xl); padding: 30px 26px;
  box-shadow: 0 4px 20px var(--cs-shadow); text-align: center;
  border-top: 4px solid var(--cs-sky); transition: transform .25s;
}
.cs-usp:nth-child(2n) { border-top-color: var(--cs-teal); }
.cs-usp:nth-child(3n) { border-top-color: var(--cs-lemon); }
.cs-usp:hover { transform: translateY(-4px); }
.cs-usp__icon  { font-size: 2.4rem; margin-bottom: 14px; display: block; }
.cs-usp__title { font-family: var(--ff-head); font-size: 1.15rem; font-weight: 600; margin-bottom: 8px; }
.cs-usp__desc  { font-size: .92rem; line-height: 1.65; color: var(--cs-text-lt); }

/* ============================================================
   SERVICES
   ============================================================ */
.cs-services__grid { display: grid; grid-template-columns: repeat(auto-fit,minmax(280px,1fr)); gap: 24px; margin-top: 40px; }
.cs-service {
  background: var(--cs-white); border-radius: var(--cs-r-lg);
  padding: 28px; box-shadow: 0 4px 20px var(--cs-shadow);
  border-left: 4px solid var(--cs-sky); transition: transform .25s;
}
.cs-service:nth-child(even) { border-left-color: var(--cs-teal); }
.cs-service:hover { transform: translateY(-4px); }
.cs-service__icon  { font-size: 2rem; margin-bottom: 12px; display: block; }
.cs-service__title { font-family: var(--ff-head); font-size: 1.2rem; font-weight: 600; margin-bottom: 8px; }
.cs-service__desc  { font-size: .92rem; line-height: 1.65; color: var(--cs-text-lt); margin-bottom: 12px; }
.cs-service__price { display: inline-block; background: var(--cs-light); color: var(--cs-sky-dk); border-radius: 50px; font-size: .8rem; font-weight: 700; padding: 4px 14px; }

/* ============================================================
   HOW IT WORKS
   ============================================================ */
.cs-how { background: var(--cs-sky-dk); padding: 80px 0; }
.cs-how .cs-eyebrow { color: var(--cs-lemon); }
.cs-how .cs-h2 { color: var(--cs-white); }
.cs-how__steps { display: grid; grid-template-columns: repeat(4,1fr); gap: 0; margin-top: 48px; position: relative; }
.cs-how__steps::before {
  content:''; position: absolute; top: 32px; left: 12%; right: 12%; height: 3px;
  background: linear-gradient(90deg,var(--cs-sky-lt),var(--cs-teal-lt)); z-index: 0;
}
.cs-how-step { text-align: center; position: relative; z-index: 1; padding: 0 16px; }
.cs-how-step__num {
  width: 64px; height: 64px; border-radius: 50%;
  background: linear-gradient(135deg,var(--cs-sky-lt),var(--cs-sky));
  color: var(--cs-white); font-family: var(--ff-head); font-size: 1.5rem; font-weight: 800;
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto 16px; box-shadow: 0 4px 16px rgba(41,182,246,.4);
}
.cs-how-step__title { font-family: var(--ff-head); font-size: 1rem; font-weight: 600; color: var(--cs-white); margin-bottom: 6px; }
.cs-how-step__desc  { font-size: .83rem; line-height: 1.55; color: rgba(255,255,255,.68); }

/* ============================================================
   PACKAGES
   ============================================================ */
.cs-packages__grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 28px; margin-top: 48px; align-items: start; }
.cs-pkg {
  border-radius: var(--cs-r-xl); overflow: hidden;
  box-shadow: 0 6px 28px var(--cs-shadow); background: var(--cs-white);
  transition: transform .25s;
}
.cs-pkg:hover { transform: translateY(-4px); }
.cs-pkg--featured { transform: scale(1.04); box-shadow: 0 12px 48px rgba(2,136,209,.3); }
.cs-pkg--featured:hover { transform: scale(1.04) translateY(-4px); }

.cs-pkg__header { padding: 28px 28px 20px; text-align: center; }
.cs-pkg--basic    .cs-pkg__header { background: linear-gradient(135deg,var(--cs-teal-lt),var(--cs-teal-dk)); }
.cs-pkg--featured .cs-pkg__header { background: linear-gradient(135deg,var(--cs-sky-lt),var(--cs-sky-dk)); }
.cs-pkg--premium  .cs-pkg__header { background: linear-gradient(135deg,#5E35B1,#311B92); }

.cs-pkg__badge { display: inline-block; background: var(--cs-lemon); color: #333; border-radius: 50px; font-size: .72rem; font-weight: 700; padding: 3px 12px; margin-bottom: 10px; letter-spacing: .08em; text-transform: uppercase; }
.cs-pkg__name  { font-family: var(--ff-head); font-size: 1.5rem; font-weight: 700; color: var(--cs-white); }
.cs-pkg__price { font-family: var(--ff-head); font-size: 2.4rem; font-weight: 800; color: var(--cs-white); margin: 12px 0 4px; }
.cs-pkg__unit  { font-size: .82rem; color: rgba(255,255,255,.75); }

.cs-pkg__body { padding: 24px 28px 28px; }
.cs-pkg__desc { font-size: .92rem; color: var(--cs-text-lt); margin-bottom: 18px; line-height: 1.6; }
.cs-pkg__features { list-style: none; margin-bottom: 24px; }
.cs-pkg__features li { padding: 6px 0 6px 26px; position: relative; font-size: .9rem; color: var(--cs-text-lt); border-bottom: 1px solid #F0F8FF; }
.cs-pkg__features li::before { content:'✓'; position: absolute; left: 0; color: var(--cs-sky); font-weight: 700; }
.cs-pkg__cta { display: block; text-align: center; padding: 13px; border-radius: 50px; font-family: var(--ff-head); font-size: .95rem; font-weight: 700; cursor: pointer; border: none; transition: opacity .2s; color: var(--cs-white); }
.cs-pkg--basic    .cs-pkg__cta { background: var(--cs-teal); }
.cs-pkg--featured .cs-pkg__cta { background: var(--cs-sky); }
.cs-pkg--premium  .cs-pkg__cta { background: #4527A0; }
.cs-pkg__cta:hover { opacity: .88; }

/* ============================================================
   TESTIMONIALS
   ============================================================ */
.cs-testimonials { background: var(--cs-light); }
.cs-testimonials__grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; margin-top: 40px; }
.cs-testi { background: var(--cs-white); border-radius: var(--cs-r-lg); padding: 28px; box-shadow: 0 4px 20px var(--cs-shadow); }
.cs-testi__stars  { color: var(--cs-lemon); font-size: 1rem; margin-bottom: 12px; }
.cs-testi__quote  { font-size: .97rem; font-style: italic; line-height: 1.75; color: var(--cs-text-lt); margin-bottom: 16px; }
.cs-testi__author { font-weight: 600; font-size: .9rem; }
.cs-testi__meta   { font-size: .82rem; color: var(--cs-text-lt); }

/* ============================================================
   FAQs
   ============================================================ */
.cs-faqs__list { max-width: 780px; margin: 40px auto 0; }
.cs-faq { border-bottom: 1px solid #DCE8F0; }
.cs-faq__q {
  width: 100%; background: none; border: none; cursor: pointer;
  display: flex; justify-content: space-between; align-items: center;
  padding: 20px 0; font-family: var(--ff-head); font-size: 1.07rem;
  font-weight: 600; color: var(--cs-text); text-align: left; gap: 16px;
}
.cs-faq__icon { font-size: 1.4rem; color: var(--cs-sky); transition: transform .3s; flex-shrink: 0; }
.cs-faq__q[aria-expanded="true"] .cs-faq__icon { transform: rotate(45deg); }
.cs-faq__a { display: none; padding: 0 0 20px; font-size: .97rem; line-height: 1.75; color: var(--cs-text-lt); }
.cs-faq__a.is-open { display: block; }

/* ============================================================
   BOOKING / QUOTE FORM
   ============================================================ */
.cs-booking { background: linear-gradient(135deg,var(--cs-sky-dk),var(--cs-teal-dk)); padding: 80px 0; }
.cs-booking .cs-eyebrow { color: var(--cs-lemon); }
.cs-booking .cs-h2  { color: var(--cs-white); }
.cs-booking .cs-lead { color: rgba(255,255,255,.78); }

.cs-form { background: var(--cs-white); border-radius: var(--cs-r-xl); padding: 48px; margin-top: 40px; box-shadow: 0 12px 48px rgba(0,0,0,.2); }
.cs-form__grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
.cs-form__full { grid-column: 1/-1; }
.cs-label { display: block; font-size: .82rem; font-weight: 600; letter-spacing: .05em; margin-bottom: 6px; color: var(--cs-text-lt); }
.cs-input, .cs-select, .cs-textarea {
  width: 100%; padding: 12px 16px;
  border: 1.5px solid #DDD; border-radius: var(--cs-r);
  font-family: var(--ff-body); font-size: .97rem; color: var(--cs-text);
  background: #FAFAFA; transition: border-color .2s;
}
.cs-input:focus, .cs-select:focus, .cs-textarea:focus { outline: none; border-color: var(--cs-sky); background: var(--cs-white); }
.cs-textarea { min-height: 110px; resize: vertical; }
.cs-form__submit { text-align: center; margin-top: 32px; }
.cs-form__note   { text-align: center; font-size: .82rem; color: var(--cs-text-lt); margin-top: 10px; }
.cs-form__guarantee {
  margin-top: 20px; background: var(--cs-light); border: 1px solid #B3E5FC;
  border-radius: var(--cs-r); padding: 14px 18px;
  font-size: .85rem; color: var(--cs-sky-dk); line-height: 1.6;
}
.cs-form__guarantee strong { display: block; margin-bottom: 3px; }

/* ============================================================
   FOOTER CTA
   ============================================================ */
.cs-footer-cta { background: var(--cs-teal-dk); padding: 60px 0; text-align: center; }
.cs-footer-cta .cs-h2  { color: var(--cs-white); margin-bottom: 10px; }
.cs-footer-cta .cs-lead { color: rgba(255,255,255,.85); margin-bottom: 28px; }

/* ============================================================
   SCROLL REVEAL
   ============================================================ */
.cs-reveal { opacity: 0; transform: translateY(28px); transition: opacity .65s, transform .65s; }
.cs-reveal.is-visible { opacity: 1; transform: none; }

/* ============================================================
   RESPONSIVE
   ============================================================ */
@media (max-width: 900px) {
  .cs-packages__grid { grid-template-columns: 1fr; }
  .cs-pkg--featured  { transform: none; }
  .cs-how__steps     { grid-template-columns: 1fr 1fr; }
  .cs-how__steps::before { display: none; }
  .cs-stats__grid    { grid-template-columns: 1fr 1fr; }
  .cs-testimonials__grid { grid-template-columns: 1fr; }
}
@media (max-width: 600px) {
  .cs-hero__inner { padding: 40px 24px; }
  .cs-form__grid  { grid-template-columns: 1fr; }
  .cs-how__steps  { grid-template-columns: 1fr; }
}
</style>

<div class="cs-page">

  <!-- ── HERO ─────────────────────────────────────────────── -->
  <section class="cs-hero" aria-label="Cleaning service hero">

    <!-- Bubbles -->
    <?php
    srand(crc32('cleaning-bubbles'));
    for ($i = 0; $i < 20; $i++) {
      $left  = rand(40,98);
      $size  = rand(20,55);
      $delay = rand(0,90)/10;
      $dur   = rand(50,120)/10;
      echo '<div class="cs-bubble" aria-hidden="true" style="left:'.$left.'%;bottom:-'.$size.'px;width:'.$size.'px;height:'.$size.'px;animation-duration:'.$dur.'s;animation-delay:-'.$delay.'s;"></div>';
    }
    srand();
    ?>

    <!-- Shine rays from a clean spot on the floor -->
    <?php
    $ray_angles = [-40,-25,-12,0,12,25,40];
    foreach ($ray_angles as $i => $ang) {
      $h = rand(50,100);
      echo '<div class="cs-shine" aria-hidden="true" style="height:'.$h.'px;bottom:28%;right:calc(22% + 8px);transform:rotate('.$ang.'deg);animation-delay:-'.($i*.3).'s;opacity:.65;"></div>';
    }
    ?>

    <!-- Sparkles -->
    <div class="cs-sparkle" style="bottom:calc(28% + 30px);right:calc(22% + 30px);animation-delay:0s;" aria-hidden="true">✦</div>
    <div class="cs-sparkle" style="bottom:calc(28% + 50px);right:calc(22% - 10px);animation-delay:-.7s;" aria-hidden="true">✧</div>
    <div class="cs-sparkle" style="bottom:calc(28% + 20px);right:calc(22% - 30px);animation-delay:-1.4s;" aria-hidden="true">✦</div>

    <!-- Floor -->
    <div class="cs-hero__floor" aria-hidden="true"></div>

    <!-- Bucket with suds -->
    <div class="cs-bucket" aria-hidden="true">
      <div class="cs-bucket__suds">
        <div class="cs-suds-blob"></div>
        <div class="cs-suds-blob"></div>
        <div class="cs-suds-blob"></div>
        <div class="cs-suds-blob"></div>
      </div>
      <div class="cs-bucket__body">
        <div class="cs-bucket__handle"></div>
      </div>
    </div>

    <!-- Mop -->
    <div class="cs-mop" aria-hidden="true">
      <div class="cs-mop__handle"></div>
      <div class="cs-mop__head">
        <div class="cs-mop__streak"></div>
      </div>
    </div>

    <!-- Cleaner figure -->
    <div class="cs-cleaner" aria-hidden="true">
      <div class="cs-cleaner__bandana"></div>
      <div class="cs-cleaner__head"></div>
      <div class="cs-cleaner__body" style="position:relative;">
        <div class="cs-cleaner__arm"></div>
      </div>
      <div class="cs-cleaner__legs">
        <div class="cs-cleaner__leg"></div>
        <div class="cs-cleaner__leg"></div>
      </div>
      <div class="cs-cleaner__shoes">
        <div class="cs-cleaner__shoe"></div>
        <div class="cs-cleaner__shoe"></div>
      </div>
    </div>

    <!-- Hero copy -->
    <div class="cs-hero__inner">
      <div class="cs-hero__rating">⭐⭐⭐⭐⭐ &nbsp; Rated 4.9 / 5 from 1,200+ Reviews</div>
      <h1 class="cs-h1 cs-hero__title">
        Spotless Every Time.<br><span style="color:var(--cs-lemon);">Guaranteed.</span>
      </h1>
      <p class="cs-hero__sub">Professional home and office cleaning across Greater Manchester — eco-friendly products, fully vetted staff, and a 100% satisfaction guarantee on every clean.</p>
      <div class="cs-hero__ctas">
        <a href="#booking" class="cs-btn cs-btn--primary">🧹 Get a Free Quote</a>
        <a href="#services" class="cs-btn cs-btn--outline">Our Services</a>
      </div>
      <div class="cs-trust">
        <span class="cs-trust-badge">✓ DBS Checked Staff</span>
        <span class="cs-trust-badge">✓ Fully Insured £5M</span>
        <span class="cs-trust-badge">✓ Eco-Friendly</span>
        <span class="cs-trust-badge">✓ 100% Guarantee</span>
      </div>
    </div>
  </section>

  <!-- ── STATS ─────────────────────────────────────────────── -->
  <section class="cs-stats" aria-label="Key figures">
    <div class="cs-wrap">
      <div class="cs-stats__grid">
        <div class="cs-stat">
          <div class="cs-stat__number" data-target="12" aria-label="12 years in business">0</div>
          <div class="cs-stat__label">Years in Business</div>
        </div>
        <div class="cs-stat">
          <div class="cs-stat__number" data-target="14000" aria-label="14000+ homes cleaned">0</div>
          <div class="cs-stat__label">Homes &amp; Offices Cleaned</div>
        </div>
        <div class="cs-stat">
          <div class="cs-stat__number" data-target="4" data-float="1" aria-label="4.9 star rating">0</div>
          <div class="cs-stat__label">★ Average Rating</div>
        </div>
        <div class="cs-stat">
          <div class="cs-stat__number" data-target="98" aria-label="98% satisfaction">0</div>
          <div class="cs-stat__label">% Satisfaction Rate</div>
        </div>
      </div>
    </div>
  </section>

  <!-- ── WHY US ─────────────────────────────────────────────── -->
  <section class="cs-section cs-section--alt" aria-labelledby="cs-why-heading">
    <div class="cs-wrap">
      <p class="cs-eyebrow" style="text-align:center">Why SparkleClean</p>
      <h2 class="cs-h2" id="cs-why-heading" style="text-align:center">The SparkleClean Difference</h2>
      <p class="cs-lead" style="text-align:center;max-width:600px;margin:0 auto;">We don't just clean — we care. Every detail of our service is designed to give you total peace of mind.</p>
      <div class="cs-usps">
        <div class="cs-usp cs-reveal">
          <span class="cs-usp__icon">🔒</span>
          <h3 class="cs-usp__title">Fully Vetted &amp; Insured</h3>
          <p class="cs-usp__desc">Every cleaner undergoes an enhanced DBS check, reference verification, and our own thorough vetting process before entering your home.</p>
        </div>
        <div class="cs-usp cs-reveal">
          <span class="cs-usp__icon">🌿</span>
          <h3 class="cs-usp__title">Eco-Friendly Products</h3>
          <p class="cs-usp__desc">We use only plant-based, biodegradable cleaning products — safe for children, pets, and the planet without compromising on clean.</p>
        </div>
        <div class="cs-usp cs-reveal">
          <span class="cs-usp__icon">⭐</span>
          <h3 class="cs-usp__title">Satisfaction Guaranteed</h3>
          <p class="cs-usp__desc">Not happy? We'll come back and re-clean for free — no arguments, no hassle. We stand behind every single clean we do.</p>
        </div>
        <div class="cs-usp cs-reveal">
          <span class="cs-usp__icon">📱</span>
          <h3 class="cs-usp__title">Easy Online Booking</h3>
          <p class="cs-usp__desc">Book, reschedule, or cancel online in under two minutes. Get real-time notifications and cleaner arrival updates direct to your phone.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- ── SERVICES ───────────────────────────────────────────── -->
  <section class="cs-section" id="services" aria-labelledby="cs-services-heading">
    <div class="cs-wrap">
      <p class="cs-eyebrow">What We Clean</p>
      <h2 class="cs-h2" id="cs-services-heading">Our Cleaning Services</h2>
      <p class="cs-lead">From weekly home cleans to one-off deep cleans — we cover it all.</p>
      <div class="cs-services__grid">

        <article class="cs-service cs-reveal">
          <span class="cs-service__icon">🏠</span>
          <h3 class="cs-service__title">Regular Home Clean</h3>
          <p class="cs-service__desc">Weekly or fortnightly maintenance cleans keeping your home consistently fresh. Customise which rooms and tasks matter most to you.</p>
          <span class="cs-service__price">from £18/hr</span>
        </article>

        <article class="cs-service cs-reveal">
          <span class="cs-service__icon">✨</span>
          <h3 class="cs-service__title">Deep Clean</h3>
          <p class="cs-service__desc">A comprehensive, top-to-bottom clean covering every corner, inside appliances, grout, skirting boards, and all those places a regular clean doesn't reach.</p>
          <span class="cs-service__price">from £180</span>
        </article>

        <article class="cs-service cs-reveal">
          <span class="cs-service__icon">🔑</span>
          <h3 class="cs-service__title">End-of-Tenancy Clean</h3>
          <p class="cs-service__desc">Landlord and letting-agent approved deep cleans to ensure full deposit return. Oven cleaning, carpet cleaning, and limescale removal included.</p>
          <span class="cs-service__price">from £220</span>
        </article>

        <article class="cs-service cs-reveal">
          <span class="cs-service__icon">🏢</span>
          <h3 class="cs-service__title">Office &amp; Commercial</h3>
          <p class="cs-service__desc">Daily, weekly, or after-hours office cleaning for workspaces of all sizes — sanitised communal areas, kitchen facilities, and desk cleaning.</p>
          <span class="cs-service__price">Bespoke quote</span>
        </article>

        <article class="cs-service cs-reveal">
          <span class="cs-service__icon">🪟</span>
          <h3 class="cs-service__title">Window Cleaning</h3>
          <p class="cs-service__desc">Internal and external window cleaning using purified water-fed pole system — streak-free results on all window types and heights.</p>
          <span class="cs-service__price">from £45</span>
        </article>

        <article class="cs-service cs-reveal">
          <span class="cs-service__icon">🛋️</span>
          <h3 class="cs-service__title">Carpet &amp; Upholstery</h3>
          <p class="cs-service__desc">Professional hot-water extraction carpet cleaning and upholstery treatment — removing allergens, stains, and odours for a genuinely fresh finish.</p>
          <span class="cs-service__price">from £60/room</span>
        </article>

        <article class="cs-service cs-reveal">
          <span class="cs-service__icon">🏗️</span>
          <h3 class="cs-service__title">After-Build Clean</h3>
          <p class="cs-service__desc">Post-construction and renovation cleaning — dust, debris, paint splatter, and adhesive residue removed to leave your new space gleaming.</p>
          <span class="cs-service__price">Bespoke quote</span>
        </article>

        <article class="cs-service cs-reveal">
          <span class="cs-service__icon">🎄</span>
          <h3 class="cs-service__title">One-Off / Event Clean</h3>
          <p class="cs-service__desc">Pre-party prep, post-event tidy-up, or seasonal deep clean — any one-off clean tackled with the same care as our regular service.</p>
          <span class="cs-service__price">from £95</span>
        </article>

      </div>
    </div>
  </section>

  <!-- ── HOW IT WORKS ───────────────────────────────────────── -->
  <section class="cs-how" aria-labelledby="cs-how-heading">
    <div class="cs-wrap">
      <p class="cs-eyebrow">Simple Process</p>
      <h2 class="cs-h2" id="cs-how-heading">Book in 60 Seconds</h2>
      <div class="cs-how__steps">
        <div class="cs-how-step cs-reveal">
          <div class="cs-how-step__num">1</div>
          <h3 class="cs-how-step__title">Get a Quote</h3>
          <p class="cs-how-step__desc">Fill in our simple form — instant online quote, no phone call needed.</p>
        </div>
        <div class="cs-how-step cs-reveal">
          <div class="cs-how-step__num">2</div>
          <h3 class="cs-how-step__title">Choose Your Date</h3>
          <p class="cs-how-step__desc">Pick a time that suits you — morning, afternoon, or evening slots available.</p>
        </div>
        <div class="cs-how-step cs-reveal">
          <div class="cs-how-step__num">3</div>
          <h3 class="cs-how-step__title">We Arrive</h3>
          <p class="cs-how-step__desc">Your vetted cleaner arrives on time with all equipment and eco products.</p>
        </div>
        <div class="cs-how-step cs-reveal">
          <div class="cs-how-step__num">4</div>
          <h3 class="cs-how-step__title">Enjoy Your Home</h3>
          <p class="cs-how-step__desc">Relax in a sparkling clean space — or rate your clean in the app.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- ── PACKAGES ───────────────────────────────────────────── -->
  <section class="cs-section" id="packages" aria-labelledby="cs-packages-heading">
    <div class="cs-wrap">
      <p class="cs-eyebrow" style="text-align:center">Pricing Plans</p>
      <h2 class="cs-h2" id="cs-packages-heading" style="text-align:center">Choose Your Plan</h2>
      <p class="cs-lead" style="text-align:center">All plans include insured, vetted cleaners and eco-friendly products. Cancel any time.</p>
      <div class="cs-packages__grid">

        <div class="cs-pkg cs-pkg--basic cs-reveal">
          <div class="cs-pkg__header">
            <div class="cs-pkg__name">Occasional</div>
            <div class="cs-pkg__price">£18</div>
            <div class="cs-pkg__unit">per hour · pay-as-you-go</div>
          </div>
          <div class="cs-pkg__body">
            <p class="cs-pkg__desc">Ideal for one-off cleans or irregular scheduling — book when you need us with no commitment.</p>
            <ul class="cs-pkg__features">
              <li>Fully vetted cleaner</li>
              <li>Eco-friendly products supplied</li>
              <li>All equipment provided</li>
              <li>Online booking & rescheduling</li>
              <li>100% satisfaction guarantee</li>
              <li>No contract required</li>
            </ul>
            <button class="cs-pkg__cta" onclick="document.getElementById('booking').scrollIntoView({behavior:'smooth'})">Get a Quote</button>
          </div>
        </div>

        <div class="cs-pkg cs-pkg--featured cs-reveal">
          <div class="cs-pkg__header">
            <div class="cs-pkg__badge">Best Value</div>
            <div class="cs-pkg__name">Regular</div>
            <div class="cs-pkg__price">£15</div>
            <div class="cs-pkg__unit">per hour · weekly or fortnightly</div>
          </div>
          <div class="cs-pkg__body">
            <p class="cs-pkg__desc">Your own dedicated cleaner on a consistent weekly or fortnightly schedule — at a reduced rate.</p>
            <ul class="cs-pkg__features">
              <li>Same cleaner every visit</li>
              <li>Discounted rate (£15/hr)</li>
              <li>Personalised cleaning checklist</li>
              <li>Priority booking</li>
              <li>Key holding available</li>
              <li>Free deep-clean credit every 6 months</li>
              <li>24-hour rescheduling window</li>
            </ul>
            <button class="cs-pkg__cta" onclick="document.getElementById('booking').scrollIntoView({behavior:'smooth'})">Start Regular Plan</button>
          </div>
        </div>

        <div class="cs-pkg cs-pkg--premium cs-reveal">
          <div class="cs-pkg__header">
            <div class="cs-pkg__name">Premium Home</div>
            <div class="cs-pkg__price">£22</div>
            <div class="cs-pkg__unit">per hour · twice-weekly concierge</div>
          </div>
          <div class="cs-pkg__body">
            <p class="cs-pkg__desc">Twice-weekly cleans with additional ironing, laundry management, and a dedicated account manager.</p>
            <ul class="cs-pkg__features">
              <li>2 × weekly cleans</li>
              <li>Ironing service included</li>
              <li>Laundry fold & put away</li>
              <li>Inside fridge & oven monthly</li>
              <li>Dedicated account manager</li>
              <li>Quarterly deep-clean included</li>
              <li>Emergency clean slots reserved</li>
            </ul>
            <button class="cs-pkg__cta" onclick="document.getElementById('booking').scrollIntoView({behavior:'smooth'})">Enquire Premium</button>
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- ── TESTIMONIALS ───────────────────────────────────────── -->
  <section class="cs-section cs-testimonials" aria-labelledby="cs-testi-heading">
    <div class="cs-wrap">
      <p class="cs-eyebrow" style="text-align:center">Customer Love</p>
      <h2 class="cs-h2" id="cs-testi-heading" style="text-align:center">What Our Customers Say</h2>
      <div class="cs-testimonials__grid">

        <blockquote class="cs-testi cs-reveal">
          <div class="cs-testi__stars" aria-label="5 stars">★★★★★</div>
          <p class="cs-testi__quote">"Sarah has been cleaning our house for eight months and I genuinely can't imagine life without SparkleClean now. The house looks incredible every single time and she notices details I'd never have thought to mention."</p>
          <footer>
            <div class="cs-testi__author">Rachel & Tom D.</div>
            <div class="cs-testi__meta">Regular Plan · Didsbury, Manchester</div>
          </footer>
        </blockquote>

        <blockquote class="cs-testi cs-reveal">
          <div class="cs-testi__stars" aria-label="5 stars">★★★★★</div>
          <p class="cs-testi__quote">"Booked an end-of-tenancy clean and got our full deposit back — my landlord said it was the cleanest he'd seen the flat. Worth every penny and the booking was so easy."</p>
          <footer>
            <div class="cs-testi__author">James O.</div>
            <div class="cs-testi__meta">End-of-Tenancy · Chorlton</div>
          </footer>
        </blockquote>

        <blockquote class="cs-testi cs-reveal">
          <div class="cs-testi__stars" aria-label="5 stars">★★★★★</div>
          <p class="cs-testi__quote">"We use SparkleClean for our office — 20 staff, 3,500 sq ft — every evening. Reliable, professional, and the team are so lovely. Not once in three years have we had to raise a concern."</p>
          <footer>
            <div class="cs-testi__author">Lisa N., Office Manager</div>
            <div class="cs-testi__meta">Commercial Contract · City Centre</div>
          </footer>
        </blockquote>

      </div>
    </div>
  </section>

  <!-- ── FAQs ───────────────────────────────────────────────── -->
  <section class="cs-section cs-section--alt" aria-labelledby="cs-faq-heading">
    <div class="cs-wrap">
      <p class="cs-eyebrow" style="text-align:center">Questions</p>
      <h2 class="cs-h2" id="cs-faq-heading" style="text-align:center">Frequently Asked Questions</h2>
      <div class="cs-faqs__list">

        <div class="cs-faq">
          <button class="cs-faq__q" aria-expanded="false" aria-controls="cs-faq-1">
            Do I need to provide cleaning products?
            <span class="cs-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="cs-faq__a" id="cs-faq-1" role="region">
            No — we bring everything. Our cleaners arrive with all equipment and our full range of eco-friendly, biodegradable cleaning products included in the price. If you have preferred products you'd like us to use, that's absolutely fine too — just let us know when you book.
          </div>
        </div>

        <div class="cs-faq">
          <button class="cs-faq__q" aria-expanded="false" aria-controls="cs-faq-2">
            Do I need to be home during the clean?
            <span class="cs-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="cs-faq__a" id="cs-faq-2" role="region">
            Not at all. Many of our regular customers provide a key or use a key safe. We operate a strict key-holding policy with full audit trails, and all keys are stored securely. Of course, you're equally welcome to be home — many clients prefer to be present for their first clean.
          </div>
        </div>

        <div class="cs-faq">
          <button class="cs-faq__q" aria-expanded="false" aria-controls="cs-faq-3">
            Are your cleaners DBS checked?
            <span class="cs-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="cs-faq__a" id="cs-faq-3" role="region">
            Yes — every SparkleClean cleaner undergoes an enhanced DBS (Disclosure and Barring Service) check, two reference checks, a face-to-face interview, and a practical cleaning assessment before they join our team. We are also fully insured to £5 million public liability.
          </div>
        </div>

        <div class="cs-faq">
          <button class="cs-faq__q" aria-expanded="false" aria-controls="cs-faq-4">
            What is your cancellation policy?
            <span class="cs-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="cs-faq__a" id="cs-faq-4" role="region">
            We ask for 24 hours' notice to reschedule or cancel without charge. Cancellations with less than 24 hours' notice may incur a 50% fee. Regular plan customers can reschedule via the app at any time up to 24 hours before their clean at no cost.
          </div>
        </div>

        <div class="cs-faq">
          <button class="cs-faq__q" aria-expanded="false" aria-controls="cs-faq-5">
            What if I'm not happy with my clean?
            <span class="cs-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="cs-faq__a" id="cs-faq-5" role="region">
            We offer a 100% satisfaction guarantee. If you're not completely happy, contact us within 24 hours and we will return to rectify any issues — free of charge. We take quality seriously and will not consider the job done until you are satisfied.
          </div>
        </div>

        <div class="cs-faq">
          <button class="cs-faq__q" aria-expanded="false" aria-controls="cs-faq-6">
            Do you clean on weekends?
            <span class="cs-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="cs-faq__a" id="cs-faq-6" role="region">
            Yes — we offer cleaning slots seven days a week, including Saturdays and Sundays. Weekend slots are popular and book up quickly, so we recommend booking a few days in advance to secure your preferred time. Availability varies by postcode.
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- ── BOOKING / QUOTE FORM ───────────────────────────────── -->
  <section class="cs-booking" id="booking" aria-labelledby="cs-booking-heading">
    <div class="cs-wrap">
      <p class="cs-eyebrow" style="text-align:center">Free Instant Quote</p>
      <h2 class="cs-h2" id="cs-booking-heading" style="text-align:center">Book Your Clean Today</h2>
      <p class="cs-lead" style="text-align:center">Get a free, no-obligation quote in under 60 seconds.</p>

      <div class="cs-form">
        <?php if ( function_exists( 'wp_nonce_field' ) ) : ?>
        <form method="post" action="" novalidate>
          <?php wp_nonce_field( 'tf_cs_booking', 'tf_cs_nonce' ); ?>

          <div class="cs-form__grid">

            <div>
              <label class="cs-label" for="cs-name">Full Name *</label>
              <input class="cs-input" type="text" id="cs-name" name="cs_name" required placeholder="Your full name" autocomplete="name">
            </div>

            <div>
              <label class="cs-label" for="cs-email">Email Address *</label>
              <input class="cs-input" type="email" id="cs-email" name="cs_email" required placeholder="you@example.com" autocomplete="email">
            </div>

            <div>
              <label class="cs-label" for="cs-phone">Phone Number *</label>
              <input class="cs-input" type="tel" id="cs-phone" name="cs_phone" required placeholder="07xxx xxxxxx" autocomplete="tel">
            </div>

            <div>
              <label class="cs-label" for="cs-postcode">Postcode *</label>
              <input class="cs-input" type="text" id="cs-postcode" name="cs_postcode" required placeholder="e.g. M20 2EQ" autocomplete="postal-code">
            </div>

            <div>
              <label class="cs-label" for="cs-service-type">Service Type *</label>
              <select class="cs-select" id="cs-service-type" name="cs_service_type" required>
                <option value="">Please select…</option>
                <option>Regular Home Clean</option>
                <option>Deep Clean</option>
                <option>End-of-Tenancy Clean</option>
                <option>Office / Commercial</option>
                <option>Window Cleaning</option>
                <option>Carpet & Upholstery</option>
                <option>After-Build Clean</option>
                <option>One-Off / Event Clean</option>
              </select>
            </div>

            <div>
              <label class="cs-label" for="cs-frequency">Cleaning Frequency</label>
              <select class="cs-select" id="cs-frequency" name="cs_frequency">
                <option value="">One-off</option>
                <option>Weekly</option>
                <option>Fortnightly</option>
                <option>Monthly</option>
                <option>Twice weekly</option>
              </select>
            </div>

            <div>
              <label class="cs-label" for="cs-bedrooms">Number of Bedrooms</label>
              <select class="cs-select" id="cs-bedrooms" name="cs_bedrooms">
                <option value="">Please select…</option>
                <option>Studio / 1 bedroom</option>
                <option>2 bedrooms</option>
                <option>3 bedrooms</option>
                <option>4 bedrooms</option>
                <option>5+ bedrooms</option>
                <option>Commercial premises</option>
              </select>
            </div>

            <div>
              <label class="cs-label" for="cs-date">Preferred Start Date</label>
              <input class="cs-input" type="text" id="cs-date" name="cs_date" placeholder="e.g. 15 May 2026 or ASAP">
            </div>

            <div class="cs-form__full">
              <label class="cs-label" for="cs-notes">Anything else we should know?</label>
              <textarea class="cs-textarea" id="cs-notes" name="cs_notes" placeholder="Pets, access arrangements, specific areas to focus on, or any other details…"></textarea>
            </div>

          </div>

          <div class="cs-form__guarantee">
            <strong>🛡️ 100% Satisfaction Guarantee</strong>
            Not happy with your clean? We'll come back and re-clean at no charge — your satisfaction is our promise.
          </div>

          <div class="cs-form__submit">
            <button type="submit" class="cs-btn cs-btn--primary">🧹 Get My Free Quote</button>
          </div>
          <p class="cs-form__note">Free quote · No obligation · Reply within 2 hours · 7 days a week</p>

        </form>
        <?php endif; ?>
      </div>
    </div>
  </section>

  <!-- ── FOOTER CTA ─────────────────────────────────────────── -->
  <section class="cs-footer-cta" aria-label="Call to action">
    <div class="cs-wrap">
      <h2 class="cs-h2">Life's Too Short to Spend It Cleaning</h2>
      <p class="cs-lead">Let us take cleaning off your list — and put your time back in your hands.</p>
      <a href="#booking" class="cs-btn cs-btn--outline">Get Your Free Quote ↗</a>
    </div>
  </section>

</div><!-- .cs-page -->

<script>
(function () {
  'use strict';

  /* ── Animated counters ──────────────────────────────────── */
  var easeOut = function (t) { return 1 - Math.pow(1 - t, 3); };
  var dur = 1800;
  function animCounter(el) {
    var target = parseFloat(el.getAttribute('data-target'));
    var isFloat = el.getAttribute('data-float') === '1';
    if (isNaN(target)) return;
    var start = null;
    function tick(ts) {
      if (!start) start = ts;
      var p = Math.min((ts - start) / dur, 1);
      var v = target * easeOut(p);
      el.textContent = isFloat ? v.toFixed(1) : Math.floor(v).toLocaleString();
      if (p < 1) requestAnimationFrame(tick);
      else el.textContent = isFloat ? target.toFixed(1) : target.toLocaleString();
    }
    requestAnimationFrame(tick);
  }
  var cObs = new IntersectionObserver(function (entries, obs) {
    entries.forEach(function (e) { if (e.isIntersecting) { animCounter(e.target); obs.unobserve(e.target); } });
  }, { threshold: 0.5 });
  document.querySelectorAll('[data-target]').forEach(function (el) { cObs.observe(el); });

  /* ── FAQ accordion ──────────────────────────────────────── */
  document.querySelectorAll('.cs-faq__q').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var expanded = this.getAttribute('aria-expanded') === 'true';
      var id = this.getAttribute('aria-controls');
      document.querySelectorAll('.cs-faq__q').forEach(function (b) { b.setAttribute('aria-expanded','false'); });
      document.querySelectorAll('.cs-faq__a').forEach(function (a) { a.classList.remove('is-open'); });
      if (!expanded) {
        this.setAttribute('aria-expanded','true');
        var a = document.getElementById(id); if (a) a.classList.add('is-open');
      }
    });
  });

  /* ── Scroll reveal ──────────────────────────────────────── */
  var rObs = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('is-visible'); rObs.unobserve(e.target); } });
  }, { threshold: 0.12 });
  document.querySelectorAll('.cs-reveal').forEach(function (el) { rObs.observe(el); });

  /* ── Smooth scroll ──────────────────────────────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      var t = document.querySelector(this.getAttribute('href'));
      if (t) { e.preventDefault(); t.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    });
  });

})();
</script>

<?php get_footer(); ?>
