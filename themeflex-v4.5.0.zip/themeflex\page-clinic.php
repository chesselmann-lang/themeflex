<?php
/**
 * Template Name: TF — Psychology & Therapy Practice
 * Description:   Premium mental health & therapy clinic homepage template.
 * Namespace:     --cln-*
 * Fonts:         Lora + Source Sans 3
 * Palette:       sage #5a7a6a · warm-white #faf8f5 · clay #c4896a · mist #e8f0eb · midnight #1e2d28
 */
defined('ABSPATH') || exit;
/* ── PHP data ──────────────────────────────────────────────────────────── */
srand(crc32(get_the_permalink()));

$leaf_particles = [];
for($i=0;$i<22;$i++) $leaf_particles[] = ['x'=>rand(5,95),'y'=>rand(5,95),'s'=>rand(6,16),'op'=>lcg_value()*.3+.08,'dur'=>lcg_value()*12+8,'del'=>lcg_value()*8,'rot'=>rand(0,360)];

$services = [
  ['icon'=>'🧠','title'=>'Individual Therapy','desc'=>'One-to-one sessions tailored to your specific needs, drawing on evidence-based approaches including CBT, psychodynamic therapy, and EMDR.','duration'=>'50 min sessions','approach'=>'CBT · Psychodynamic · EMDR'],
  ['icon'=>'💑','title'=>'Couples Counselling','desc'=>'Structured sessions to improve communication, rebuild trust, and navigate conflict — whether preparing for marriage or working through difficulty.','duration'=>'60 min sessions','approach'=>'EFT · Gottman Method'],
  ['icon'=>'👨‍👩‍👧','title'=>'Family Therapy','desc'=>'Whole-family work that addresses systemic patterns, improves dynamics, and helps every member feel heard and understood.','duration'=>'75 min sessions','approach'=>'Systemic · Narrative'],
  ['icon'=>'🧒','title'=>'Child & Adolescent','desc'=>'Specialist therapy for young people aged 5–17, using play therapy, creative approaches, and CBT adapted for younger minds.','duration'=>'45 min sessions','approach'=>'Play Therapy · CBT-Y'],
  ['icon'=>'🏢','title'=>'Workplace Wellbeing','desc'=>'Employee assistance programmes, burnout prevention, and leadership coaching — delivered in-practice or on-site at your organisation.','duration'=>'Flexible','approach'=>'ACT · Coaching Psychology'],
  ['icon'=>'🌿','title'=>'Mindfulness & Stress','desc'=>'MBSR and MBCT programmes, breathwork, and somatic approaches for managing anxiety, chronic stress, and exhaustion.','duration'=>'8-week programmes','approach'=>'MBSR · MBCT · Somatic'],
];

$therapists = [
  ['name'=>'Dr. Helena Marsh','role'=>'Clinical Psychologist','quals'=>'DClinPsych, BPS Chartered','spec'=>'Trauma & PTSD, Anxiety Disorders','years'=>14,'hair'=>'#4a3020','skin'=>'#c8956c','blouse'=>'#5a7a6a'],
  ['name'=>'James Okafor','role'=>'Psychotherapist','quals'=>'MBACP (Accredited), MA Counselling','spec'=>'Grief, Depression, Relationships','years'=>10,'hair'=>'#1a0a0a','skin'=>'#6b3a20','blouse'=>'#7a8a5a'],
  ['name'=>'Dr. Priya Anand','role'=>'Consultant Psychiatrist','quals'=>'MRCPsych, FRCPsych','spec'=>'Complex Mental Health, Neurodiversity','years'=>18,'hair'=>'#1a0808','skin'=>'#8b5a2b','blouse'=>'#8a6a5a'],
  ['name'=>'Sophie Crane','role'=>'CBT Therapist & Supervisor','quals'=>'BABCP Accredited, MSc CBT','spec'=>'OCD, Health Anxiety, Phobias','years'=>9,'hair'=>'#3a2010','skin'=>'#d4a574','blouse'=>'#6a7a8a'],
];

$approaches = [
  ['abbr'=>'CBT','name'=>'Cognitive Behavioural Therapy','desc'=>'Evidence-based therapy that explores how thoughts, feelings, and behaviours influence each other, building practical tools for change.'],
  ['abbr'=>'EMDR','name'=>'Eye Movement Desensitisation','desc'=>'A structured approach for processing traumatic memories and reducing the distress associated with difficult experiences.'],
  ['abbr'=>'ACT','name'=>'Acceptance & Commitment','desc'=>'Develops psychological flexibility — helping you live in alignment with your values even when difficult thoughts and feelings arise.'],
  ['abbr'=>'EFT','name'=>'Emotionally Focused Therapy','desc'=>'Attachment-based therapy that strengthens emotional bonds in couples and families, creating secure, lasting connection.'],
  ['abbr'=>'MBCT','name'=>'Mindfulness-Based Cognitive','desc'=>'Combines mindfulness practices with cognitive therapy, shown to reduce relapse in recurrent depression by up to 50%.'],
  ['abbr'=>'IFS','name'=>'Internal Family Systems','desc'=>'A compassionate, non-pathologising model that explores the different parts of ourselves and their roles in our wellbeing.'],
];

$faqs = [
  ['q'=>'What happens in the first session?','a'=>'The first session is an assessment — a chance for you and your therapist to understand what\'s brought you here, what you\'re hoping to achieve, and whether we\'re the right fit. There\'s no pressure to share more than you\'re comfortable with.'],
  ['q'=>'How long will I need therapy?','a'=>'This varies enormously. Some people benefit from six to eight sessions; others find longer-term work more helpful. Your therapist will discuss this with you in the early sessions and review regularly.'],
  ['q'=>'Is everything I say confidential?','a'=>'Yes — confidentiality is a cornerstone of therapy. There are narrow exceptions, primarily when there is serious risk of harm, and these will be explained clearly at your first session.'],
  ['q'=>'Do you offer video or phone sessions?','a'=>'Yes. We offer face-to-face sessions at our practice and secure video therapy for those who prefer remote working. Most of our therapists offer both.'],
  ['q'=>'How do I know which therapist is right for me?','a'=>'Our admin team will match you based on your presenting concerns, preferred approach, and availability. You\'re also welcome to request a 15-minute introductory call with any therapist before committing.'],
];

$testimonials = [
  ['text'=>'Dr. Marsh changed the way I understand myself. After years of feeling stuck, I finally have tools that work. I cannot recommend this practice highly enough.','author'=>'A.T.','detail'=>'Individual therapy, 9 months'],
  ['text'=>'We were on the verge of separating. James helped us both feel heard for the first time in years. We\'re still together and genuinely happy.','author'=>'M. & L.','detail'=>'Couples counselling, 6 months'],
  ['text'=>'My daughter came to Sophie after years of school anxiety. The change in her confidence has been remarkable. The whole approach was so warm and non-judgmental.','author'=>'Parent of a client','detail'=>'Child therapy, 4 months'],
];

$process_steps = [
  ['num'=>'01','title'=>'Get in Touch','desc'=>'Call or complete the referral form. Our admin team will respond within one working day.'],
  ['num'=>'02','title'=>'Intake Assessment','desc'=>'A 20-minute telephone call to understand your needs and match you with the right therapist.'],
  ['num'=>'03','title'=>'First Session','desc'=>'An unhurried first meeting. No pressure — just a chance to talk and see how it feels.'],
  ['num'=>'04','title'=>'Your Programme','desc'=>'Together you\'ll agree a plan — frequency, duration, and approach — that fits your life.'],
];

$marquee_items = ['✦ BACP Accredited Practice','✦ NHS-Experienced Clinicians','✦ Sliding Scale Fees Available','✦ Video & In-Person Sessions','✦ GDPR-Compliant & Confidential','✦ Evening & Weekend Appointments','✦ Child & Adult Specialists','✦ Trauma-Informed Practice'];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,500;0,600;1,400;1,500&family=Source+Sans+3:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
/* ── TOKENS ─────────────────────────────────────────────────────────── */
:root{
  --cln-sage:#5a7a6a;
  --cln-sage2:#4a6a5a;
  --cln-warm:#faf8f5;
  --cln-clay:#c4896a;
  --cln-clay2:#a07050;
  --cln-mist:#e8f0eb;
  --cln-mist2:#d0e0d5;
  --cln-midnight:#1e2d28;
  --cln-slate:#4a5a52;
  --cln-ff-head:'Lora',Georgia,serif;
  --cln-ff-body:'Source Sans 3',sans-serif;
  --cln-r:6px;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body.cln-page{font-family:var(--cln-ff-body);color:var(--cln-midnight);background:var(--cln-warm);font-size:16px;line-height:1.75;font-weight:400}
.cln-container{max-width:1160px;margin:0 auto;padding:0 24px}
.cln-section{padding:96px 0}
.cln-label{font-family:var(--cln-ff-body);font-size:.7rem;font-weight:600;letter-spacing:.2em;text-transform:uppercase;color:var(--cln-clay);margin-bottom:14px}
.cln-h1{font-family:var(--cln-ff-head);font-size:clamp(2.5rem,5.5vw,4rem);line-height:1.15;font-weight:500}
.cln-h2{font-family:var(--cln-ff-head);font-size:clamp(1.8rem,3.5vw,2.8rem);line-height:1.2;font-weight:500}
.cln-h3{font-family:var(--cln-ff-head);font-size:1.25rem;font-weight:500}
.cln-lead{font-size:1.05rem;font-weight:300;line-height:1.8;color:var(--cln-slate)}
.cln-sage-bar{width:48px;height:3px;background:linear-gradient(90deg,var(--cln-sage),var(--cln-clay));margin:18px 0 28px;border-radius:2px}
.cln-btn{display:inline-block;padding:13px 32px;font-family:var(--cln-ff-body);font-size:.85rem;font-weight:600;letter-spacing:.08em;text-decoration:none;border-radius:var(--cln-r);cursor:pointer;border:none;transition:all .3s}
.cln-btn-sage{background:var(--cln-sage);color:#fff}.cln-btn-sage:hover{background:var(--cln-sage2);transform:translateY(-2px)}
.cln-btn-outline{background:transparent;color:var(--cln-sage);border:1.5px solid var(--cln-sage)}.cln-btn-outline:hover{background:var(--cln-sage);color:#fff}
.cln-btn-clay{background:var(--cln-clay);color:#fff}.cln-btn-clay:hover{background:var(--cln-clay2)}
.cln-reveal{opacity:0;transform:translateY(20px);transition:opacity .7s,transform .7s}
.cln-reveal.visible{opacity:1;transform:none}

/* ── HERO ────────────────────────────────────────────────────────────── */
.cln-hero{position:relative;width:100%;min-height:100vh;display:flex;align-items:center;overflow:hidden;background:linear-gradient(150deg,#e8f0eb 0%,#faf8f5 50%,#f0e8e0 100%)}
/* Leaf particles */
.cln-leaf{position:absolute;border-radius:50% 0 50% 0;background:var(--cln-sage)}
@keyframes cln-leaf-drift{0%{transform:rotate(var(--cln-lr)) translate(0,0);opacity:var(--cln-lop)}50%{transform:rotate(calc(var(--cln-lr) + 30deg)) translate(10px,20px);opacity:calc(var(--cln-lop)*1.2)}100%{transform:rotate(calc(var(--cln-lr) + 15deg)) translate(-5px,40px);opacity:0}}
/* Circles - abstract organic shapes */
.cln-circle{position:absolute;border-radius:50%;border:1px solid rgba(90,122,106,.12)}
/* Hero layout */
.cln-hero-inner{position:relative;z-index:5;display:grid;grid-template-columns:1fr 480px;gap:80px;align-items:center;padding:120px 0 80px}
.cln-hero-content .cln-label{color:var(--cln-sage)}
.cln-hero-h1{color:var(--cln-midnight);margin-bottom:12px}
.cln-hero-h1 em{font-style:italic;color:var(--cln-sage)}
.cln-hero-sub{font-size:1.05rem;color:var(--cln-slate);line-height:1.8;margin-bottom:32px;max-width:500px;font-weight:300}
.cln-hero-btns{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:40px}
.cln-hero-assurances{display:flex;flex-direction:column;gap:10px}
.cln-hero-assurance{display:flex;align-items:center;gap:10px;font-size:.88rem;color:var(--cln-slate);font-weight:300}
.cln-hero-assurance::before{content:'✓';color:var(--cln-sage);font-weight:700;font-size:.8rem;flex-shrink:0}

/* CSS therapy room art */
.cln-room-art{width:100%;aspect-ratio:4/5;position:relative;border-radius:16px;overflow:hidden}
.cln-room-bg{position:absolute;inset:0;background:linear-gradient(160deg,#f0ece4 0%,#e4ddd4 100%)}
.cln-room-floor3{position:absolute;bottom:0;left:0;right:0;height:28%;background:linear-gradient(0deg,#c4a888,#d4b898)}
/* Floor planks */
.cln-room-rug2{position:absolute;bottom:28%;left:50%;transform:translateX(-50%);width:75%;height:5%;background:radial-gradient(ellipse,rgba(90,122,106,.2),transparent 80%);border-radius:50%}
/* Couch / therapy sofa */
.cln-couch{position:absolute;bottom:28%;left:50%;transform:translateX(-50%);display:flex;flex-direction:column;align-items:center;width:70%}
.cln-couch-back{width:100%;height:45px;background:linear-gradient(160deg,#7a5a48,#5a3828);border-radius:4px 4px 0 0}
.cln-couch-back::before{content:'';position:absolute;left:10%;width:30%;height:100%;background:rgba(255,255,255,.06);border-radius:4px 4px 0 0}
.cln-couch-back::after{content:'';position:absolute;left:48%;width:30%;height:100%;background:rgba(255,255,255,.04);border-radius:4px 4px 0 0}
.cln-couch-seat{width:95%;height:28px;background:linear-gradient(180deg,#6a4a36,#4a2e1e);border-radius:2px}
.cln-couch-arm{width:14px;height:34px;background:linear-gradient(180deg,#6a4a36,#4a2e1e);border-radius:4px;position:absolute;bottom:28px}
.cln-couch-leg2{width:6px;height:16px;background:#3a2010;border-radius:0 0 2px 2px}
.cln-couch-cushion{position:absolute;top:3px;width:28%;height:36px;background:linear-gradient(135deg,#c4896a,#a07050);border-radius:3px;opacity:.7}
/* Armchair */
.cln-armchair{position:absolute;bottom:28%;right:5%}
.cln-ac-back{width:60px;height:60px;background:linear-gradient(160deg,#5a7a6a,#3a5a4a);border-radius:4px 4px 0 0;position:relative}
.cln-ac-seat{width:66px;height:24px;background:linear-gradient(180deg,#4a6a5a,#2a4a3a);border-radius:2px}
.cln-ac-arm2{width:10px;height:28px;background:linear-gradient(180deg,#4a6a5a,#2a4a3a);border-radius:3px;position:absolute;bottom:24px}
.cln-ac-cushion{position:absolute;top:6px;left:8px;width:44px;height:40px;background:linear-gradient(135deg,#6a9a7a,#4a7a5a);border-radius:2px;opacity:.6}
/* Plant - large floor plant */
.cln-plant2{position:absolute;bottom:28%;left:3%}
.cln-plant2-pot{width:36px;height:30px;background:linear-gradient(180deg,#c4896a,#a07050);border-radius:0 0 6px 6px;border-top:4px solid #d4a878}
.cln-plant2-stem{width:3px;height:50px;background:#4a6a3a;margin:0 auto}
.cln-plant2-leaf{position:absolute;background:linear-gradient(135deg,#5a8a4a,#3a6a30);border-radius:50% 0 50% 0}
/* Window */
.cln-room-window2{position:absolute;top:8%;left:50%;transform:translateX(-50%);width:120px;height:140px;background:linear-gradient(180deg,#c8dce4,#b0ccd4);border:5px solid #c4b89a;border-radius:2px}
.cln-room-window2::before{content:'';position:absolute;left:50%;top:0;bottom:0;width:4px;background:#c4b89a;transform:translateX(-50%)}
.cln-room-window2::after{content:'';position:absolute;top:50%;left:0;right:0;height:4px;background:#c4b89a}
/* Curtain panels */
.cln-curtain2{position:absolute;top:5%;width:44px;height:44%;background:linear-gradient(180deg,rgba(90,122,106,.6),rgba(60,90,70,.4));border-radius:0 0 20% 0}
.cln-curtain2-l{left:calc(50% - 100px)}
.cln-curtain2-r{right:calc(50% - 100px);transform:scaleX(-1)}
/* Wall art */
.cln-wall-frame{position:absolute;top:18%;right:8%;width:70px;height:55px;border:4px solid #b4a888;background:#e8e0d0;display:flex;align-items:center;justify-content:center}
.cln-wall-art-circle{width:30px;height:30px;border-radius:50%;border:3px solid rgba(90,122,106,.4)}
.cln-wall-art-dot{width:8px;height:8px;border-radius:50%;background:rgba(196,137,106,.5)}
/* Side table lamp */
.cln-lamp2{position:absolute;bottom:calc(28% + 28px);right:calc(5% + 70px)}
.cln-lamp2-shade{width:0;height:0;border-left:16px solid transparent;border-right:16px solid transparent;border-bottom:26px solid rgba(245,224,144,.8);filter:drop-shadow(0 0 8px rgba(245,224,144,.3))}
.cln-lamp2-stem2{width:2px;height:40px;background:#8a6a5a;margin:0 auto}
.cln-lamp2-base2{width:18px;height:5px;background:#6a4a38;border-radius:3px;margin:0 auto}
/* Books on shelf */
.cln-shelf{position:absolute;top:12%;left:5%;width:55px;height:90px}
.cln-shelf-plank{position:absolute;bottom:0;width:100%;height:6px;background:#b4a880;border-radius:1px}
.cln-book{position:absolute;bottom:6px;width:10px;border-radius:1px 1px 0 0}

/* ── MARQUEE ─────────────────────────────────────────────────────────── */
.cln-marquee-wrap{background:var(--cln-sage);padding:13px 0;overflow:hidden}
.cln-marquee-track{display:flex;width:max-content;animation:cln-marquee 32s linear infinite}
.cln-marquee-track:hover{animation-play-state:paused}
.cln-marquee-item{white-space:nowrap;padding:0 28px;font-size:.78rem;font-weight:600;letter-spacing:.15em;text-transform:uppercase;color:#fff}
@keyframes cln-marquee{from{transform:translateX(0)}to{transform:translateX(-50%)}}

/* ── SERVICES ────────────────────────────────────────────────────────── */
.cln-services{background:var(--cln-mist)}
.cln-services-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-top:52px}
.cln-service-card{background:var(--cln-warm);padding:36px 28px;border-radius:var(--cln-r);border-bottom:3px solid var(--cln-sage);transition:transform .3s,box-shadow .3s}
.cln-service-card:hover{transform:translateY(-4px);box-shadow:0 12px 36px rgba(30,45,40,.08)}
.cln-service-icon{font-size:2rem;margin-bottom:18px;display:block}
.cln-service-title{font-family:var(--cln-ff-head);font-size:1.15rem;margin-bottom:10px;color:var(--cln-midnight)}
.cln-service-desc{font-size:.9rem;line-height:1.75;color:var(--cln-slate);margin-bottom:16px;font-weight:300}
.cln-service-meta{font-size:.75rem;font-weight:600;color:var(--cln-sage);letter-spacing:.05em}

/* ── APPROACHES ──────────────────────────────────────────────────────── */
.cln-approaches{background:var(--cln-warm)}
.cln-approaches-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:2px;margin-top:52px}
.cln-approach-card{background:var(--cln-mist);padding:32px 28px;transition:background .3s}
.cln-approach-card:hover{background:var(--cln-mist2)}
.cln-approach-abbr{font-family:var(--cln-ff-head);font-size:2.5rem;color:var(--cln-sage);font-weight:500;line-height:1;margin-bottom:8px;font-style:italic}
.cln-approach-name{font-size:.75rem;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:var(--cln-slate);margin-bottom:12px}
.cln-approach-desc{font-size:.88rem;line-height:1.7;color:var(--cln-slate);font-weight:300}

/* ── PROCESS ─────────────────────────────────────────────────────────── */
.cln-process{background:var(--cln-midnight);padding:80px 0}
.cln-process .cln-label{color:var(--cln-clay)}
.cln-process .cln-h2{color:#fff}
.cln-process .cln-sage-bar{background:linear-gradient(90deg,var(--cln-clay),var(--cln-sage))}
.cln-process-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:0;margin-top:52px;position:relative}
.cln-process-grid::before{content:'';position:absolute;top:32px;left:calc(12.5% + 16px);right:calc(12.5% + 16px);height:1px;background:linear-gradient(90deg,var(--cln-sage),var(--cln-clay));opacity:.4}
.cln-process-step{padding:0 20px;text-align:center}
.cln-step-num{width:64px;height:64px;border-radius:50%;border:1.5px solid var(--cln-sage);display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-family:var(--cln-ff-head);font-size:1.1rem;color:var(--cln-sage);background:var(--cln-midnight);position:relative;z-index:1}
.cln-step-title{font-family:var(--cln-ff-head);font-size:1.1rem;color:#fff;margin-bottom:10px;font-weight:500}
.cln-step-desc{font-size:.85rem;color:rgba(255,255,255,.5);line-height:1.65;font-weight:300}

/* ── THERAPISTS ──────────────────────────────────────────────────────── */
.cln-therapists{background:var(--cln-mist)}
.cln-therapists-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:20px;margin-top:52px}
.cln-therapist-card{background:var(--cln-warm);border-radius:var(--cln-r);overflow:hidden;transition:transform .3s,box-shadow .3s}
.cln-therapist-card:hover{transform:translateY(-4px);box-shadow:0 12px 36px rgba(30,45,40,.1)}
.cln-therapist-portrait2{aspect-ratio:1;position:relative;overflow:hidden}
/* CSS therapist portrait */
.cln-tp-scene{width:100%;height:100%;position:relative}
.cln-tp-bg{position:absolute;inset:0;background:linear-gradient(160deg,#e8f0eb 0%,#d8e8dc 100%)}
.cln-tp-shelf-scene{position:absolute;bottom:0;left:0;right:0;height:15%;background:linear-gradient(0deg,#c8b898,#d8c8a8)}
.cln-tp-body2{position:absolute;bottom:13%;left:50%;transform:translateX(-50%);width:68%;height:38%;border-radius:40% 40% 0 0}
.cln-tp-neck2{position:absolute;border-radius:50%}
.cln-tp-head2{position:absolute;border-radius:50% 50% 42% 42%;overflow:hidden}
.cln-tp-hair2{position:absolute;border-radius:50% 50% 0 0}
.cln-tp-eyes2{position:absolute;display:flex;gap:8px;justify-content:center;width:100%}
.cln-tp-eye2{width:5px;height:5px;border-radius:50%;background:#2a1a10}
.cln-tp-smile2{width:14px;height:7px;border-bottom:1.5px solid rgba(160,100,60,.5);border-radius:0 0 50% 50%}
/* Glasses detail - optional per therapist */
.cln-therapist-info{padding:20px}
.cln-therapist-name2{font-family:var(--cln-ff-head);font-size:1rem;font-weight:500;color:var(--cln-midnight);margin-bottom:2px}
.cln-therapist-role2{font-size:.75rem;font-weight:600;text-transform:uppercase;letter-spacing:.08em;color:var(--cln-sage);margin-bottom:6px}
.cln-therapist-quals{font-size:.78rem;color:var(--cln-slate);font-weight:300;margin-bottom:8px}
.cln-therapist-spec{font-size:.8rem;color:var(--cln-clay);font-style:italic}

/* ── STATS ───────────────────────────────────────────────────────────── */
.cln-stats{background:var(--cln-sage);padding:72px 0}
.cln-stats-grid{display:grid;grid-template-columns:repeat(4,1fr);text-align:center;gap:0}
.cln-stat-divider2{border-right:1px solid rgba(255,255,255,.25)}
.cln-stat-num2{font-family:var(--cln-ff-head);font-size:3.5rem;font-weight:500;color:#fff;line-height:1;font-style:italic}
.cln-stat-label2{font-size:.75rem;font-weight:600;letter-spacing:.15em;text-transform:uppercase;color:rgba(255,255,255,.7);margin-top:8px}

/* ── TESTIMONIALS ────────────────────────────────────────────────────── */
.cln-testimonials{background:var(--cln-warm)}
.cln-test-header{text-align:center;margin-bottom:52px}
.cln-test-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
.cln-test-card{background:var(--cln-mist);padding:36px 28px;border-radius:var(--cln-r);border-left:3px solid var(--cln-sage)}
.cln-test-quote2{font-family:var(--cln-ff-head);font-size:3rem;color:var(--cln-sage);opacity:.2;line-height:1;margin-bottom:6px}
.cln-test-text2{font-size:.92rem;line-height:1.8;color:var(--cln-midnight);font-style:italic;font-family:var(--cln-ff-head);margin-bottom:20px;font-weight:400}
.cln-test-author2{font-size:.8rem;font-weight:600;color:var(--cln-midnight);text-transform:uppercase;letter-spacing:.06em}
.cln-test-detail2{font-size:.75rem;color:var(--cln-slate);font-weight:300;margin-top:2px}

/* ── FAQ ─────────────────────────────────────────────────────────────── */
.cln-faq{background:var(--cln-mist)}
.cln-faq-grid{display:grid;grid-template-columns:1fr 1fr;gap:48px;margin-top:52px;align-items:start}
.cln-faq-list{display:flex;flex-direction:column;gap:0}
.cln-faq-item2{border-bottom:1px solid var(--cln-mist2)}
.cln-faq-q2{display:flex;justify-content:space-between;align-items:flex-start;padding:18px 0;cursor:pointer;font-family:var(--cln-ff-head);font-size:1rem;font-weight:500;color:var(--cln-midnight);gap:16px;background:transparent;border:none;text-align:left;width:100%}
.cln-faq-icon2{font-size:1.1rem;color:var(--cln-sage);flex-shrink:0;transition:transform .3s;margin-top:2px}
.cln-faq-item2.open .cln-faq-icon2{transform:rotate(45deg)}
.cln-faq-a2{max-height:0;overflow:hidden;transition:max-height .35s ease}
.cln-faq-item2.open .cln-faq-a2{max-height:180px}
.cln-faq-a2 p{padding:0 0 18px;font-size:.9rem;color:var(--cln-slate);line-height:1.75;font-weight:300}
/* FAQ art side */
.cln-faq-art{position:relative;height:100%;min-height:400px}
.cln-faq-scene{width:100%;height:100%;background:linear-gradient(135deg,#e8f0eb,#d8e8dc);border-radius:12px;position:relative;overflow:hidden;display:flex;align-items:center;justify-content:center}
/* Abstract growth/wellbeing illustration */
.cln-growth-root{position:absolute;bottom:0;left:50%;transform:translateX(-50%);width:6px;height:50%;background:linear-gradient(0deg,var(--cln-midnight),var(--cln-sage));border-radius:3px}
.cln-growth-branch{position:absolute;background:var(--cln-sage);border-radius:3px;transform-origin:left center}
.cln-growth-leaf{position:absolute;background:linear-gradient(135deg,#6a9a6a,#4a7a4a);border-radius:50% 0 50% 0}
.cln-growth-circle2{position:absolute;border-radius:50%;border:2px solid rgba(90,122,106,.2)}

/* ── BOOKING FORM ────────────────────────────────────────────────────── */
.cln-booking{background:var(--cln-warm)}
.cln-booking-grid{display:grid;grid-template-columns:1fr 1.2fr;gap:80px;align-items:start;margin-top:52px}
.cln-booking-info p{color:var(--cln-slate);font-size:.95rem;line-height:1.8;font-weight:300;margin-bottom:16px}
.cln-contact-list{display:flex;flex-direction:column;gap:12px;margin-top:28px}
.cln-contact-row{display:flex;align-items:center;gap:14px;font-size:.9rem;color:var(--cln-slate);font-weight:300}
.cln-contact-dot{width:36px;height:36px;border-radius:50%;background:var(--cln-mist);display:flex;align-items:center;justify-content:center;font-size:.9rem;flex-shrink:0}
.cln-form2{background:var(--cln-mist);border-radius:var(--cln-r);padding:40px}
.cln-form2 .cln-form-group{margin-bottom:16px}
.cln-form2 label{display:block;font-size:.75rem;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:var(--cln-slate);margin-bottom:6px}
.cln-form2 input,.cln-form2 select,.cln-form2 textarea{width:100%;padding:12px 14px;background:var(--cln-warm);border:1.5px solid var(--cln-mist2);border-radius:var(--cln-r);color:var(--cln-midnight);font-family:var(--cln-ff-body);font-size:.9rem;transition:border-color .3s}
.cln-form2 input:focus,.cln-form2 select:focus,.cln-form2 textarea:focus{outline:none;border-color:var(--cln-sage)}
.cln-form2 textarea{resize:vertical;min-height:90px}
.cln-form2-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.cln-form2-submit{width:100%;padding:14px;background:var(--cln-sage);color:#fff;border:none;border-radius:var(--cln-r);font-family:var(--cln-ff-body);font-size:.88rem;font-weight:600;letter-spacing:.08em;cursor:pointer;transition:background .3s,transform .2s;margin-top:4px}
.cln-form2-submit:hover{background:var(--cln-sage2);transform:translateY(-1px)}
.cln-privacy-note{font-size:.75rem;color:var(--cln-slate);text-align:center;margin-top:12px;font-weight:300;font-style:italic}

/* ── RESPONSIVE ──────────────────────────────────────────────────────── */
@media(max-width:1024px){
  .cln-hero-inner{grid-template-columns:1fr;gap:48px}
  .cln-room-art{max-width:420px;margin:0 auto}
  .cln-services-grid{grid-template-columns:repeat(2,1fr)}
  .cln-approaches-grid{grid-template-columns:repeat(2,1fr)}
  .cln-therapists-grid{grid-template-columns:repeat(2,1fr)}
  .cln-faq-grid{grid-template-columns:1fr}
  .cln-booking-grid{grid-template-columns:1fr}
  .cln-process-grid{grid-template-columns:repeat(2,1fr)}
}
@media(max-width:768px){
  .cln-section{padding:64px 0}
  .cln-services-grid,.cln-approaches-grid{grid-template-columns:1fr}
  .cln-stats-grid{grid-template-columns:repeat(2,1fr)}
  .cln-test-grid{grid-template-columns:1fr}
  .cln-form2-row{grid-template-columns:1fr}
}
</style>
<?php get_header(); ?>
<div class="cln-page">
>

<?php /* ── HERO ─────────────────────────────────────────────────────── */ ?>
<section class="cln-hero" aria-label="Hero">

  <?php /* Organic circles */ ?>
  <?php $circles=[['top'=>'-10%','left'=>'-5%','size'=>350],['top'=>'60%','right'=>'-8%','size'=>280],['top'=>'20%','right'=>'20%','size'=>160],['top'=>'5%','left'=>'40%','size'=>120]]; ?>
  <?php foreach($circles as $c): $pos=isset($c['right'])?"right:{$c['right']}":"left:{$c['left']}"; ?>
  <div class="cln-circle" style="position:absolute;top:<?=$c['top']?>;<?=$pos?>;width:<?=$c['size']?>px;height:<?=$c['size']?>px;border-radius:50%"></div>
  <?php endforeach; ?>

  <?php /* Leaf particles */ ?>
  <?php foreach($leaf_particles as $l): ?>
  <div class="cln-leaf" style="left:<?=$l['x']?>%;top:<?=$l['y']?>%;width:<?=$l['s']?>px;height:<?=$l['s']?>px;--cln-lr:<?=$l['rot']?>deg;--cln-lop:<?=round($l['op'],2)?>;animation:cln-leaf-drift <?=round($l['dur'],1)?>s <?=round($l['del'],1)?>s ease-in-out infinite alternate" aria-hidden="true"></div>
  <?php endforeach; ?>

  <div class="cln-container">
    <div class="cln-hero-inner">
      <div class="cln-hero-content">
        <div class="cln-label">Accredited Therapy Practice</div>
        <h1 class="cln-hero-h1 cln-h1">A space to <em>think,<br>feel,</em> and heal</h1>
        <div class="cln-sage-bar"></div>
        <p class="cln-hero-sub">We offer evidence-based therapy for individuals, couples, and families. Warm, non-judgmental, and entirely confidential — whether you're struggling with anxiety, grief, trauma, or simply feel it's time to talk.</p>
        <div class="cln-hero-btns">
          <a href="#booking" class="cln-btn cln-btn-sage">Book a Consultation</a>
          <a href="#services" class="cln-btn cln-btn-outline">Our Services</a>
        </div>
        <div class="cln-hero-assurances">
          <span class="cln-hero-assurance">BACP Accredited therapists</span>
          <span class="cln-hero-assurance">Fully confidential — no data shared</span>
          <span class="cln-hero-assurance">Evening &amp; weekend availability</span>
          <span class="cln-hero-assurance">Sliding scale fees available</span>
        </div>
      </div>

      <?php /* Therapy room CSS art */ ?>
      <div class="cln-room-art cln-reveal" aria-hidden="true">
        <div class="cln-room-bg"></div>
        <div class="cln-room-floor3"></div>
        <div class="cln-room-rug2"></div>

        <?php /* Book shelf */ ?>
        <div class="cln-shelf">
          <div class="cln-shelf-plank"></div>
          <?php $book_colors=['#5a7a6a','#c4896a','#6a7a8a','#8a7a5a','#7a5a8a','#4a6a5a']; ?>
          <?php foreach($book_colors as $bi=>$bc): ?>
          <div class="cln-book" style="left:<?=$bi*9?>px;height:<?=50+rand(0,20)?>px;background:<?=$bc?>"></div>
          <?php endforeach; ?>
        </div>

        <?php /* Window */ ?>
        <div class="cln-room-window2"></div>
        <div class="cln-curtain2 cln-curtain2-l"></div>
        <div class="cln-curtain2 cln-curtain2-r"></div>

        <?php /* Wall frame */ ?>
        <div class="cln-wall-frame">
          <div style="position:relative;display:flex;align-items:center;justify-content:center;gap:6px">
            <div class="cln-wall-art-circle"></div>
            <div class="cln-wall-art-dot" style="position:absolute"></div>
          </div>
        </div>

        <?php /* Floor plant */ ?>
        <div class="cln-plant2">
          <div style="position:relative;height:80px;width:60px">
            <div class="cln-plant2-stem"></div>
            <?php /* Leaves at various heights */ ?>
            <?php $leaf_defs=[[30,12,-30,'left:8px'],  [50,14,15,'right:6px'], [65,16,-20,'left:5px'], [80,18,10,'right:4px']]; ?>
            <?php foreach($leaf_defs as $ld): ?>
            <div class="cln-plant2-leaf" style="position:absolute;bottom:<?=$ld[0]?>px;width:<?=$ld[1]?>px;height:<?=$ld[1]+4?>px;transform:rotate(<?=$ld[2]?>deg);<?=$ld[3]?>"></div>
            <?php endforeach; ?>
          </div>
          <div class="cln-plant2-pot"></div>
        </div>

        <?php /* Therapy couch */ ?>
        <div class="cln-couch">
          <div style="position:relative;width:100%">
            <div class="cln-couch-back"></div>
            <?php /* Cushions */ ?>
            <div class="cln-couch-cushion" style="left:5%"></div>
            <div class="cln-couch-cushion" style="left:37%"></div>
            <div class="cln-couch-cushion" style="left:69%"></div>
          </div>
          <div class="cln-couch-seat" style="position:relative">
            <div class="cln-couch-arm" style="left:0"></div>
            <div class="cln-couch-arm" style="right:0"></div>
          </div>
          <div style="display:flex;justify-content:space-around;width:90%">
            <div class="cln-couch-leg2"></div>
            <div class="cln-couch-leg2"></div>
            <div class="cln-couch-leg2"></div>
            <div class="cln-couch-leg2"></div>
          </div>
        </div>

        <?php /* Therapist armchair */ ?>
        <div class="cln-armchair">
          <div class="cln-ac-back" style="position:relative">
            <div class="cln-ac-cushion"></div>
          </div>
          <div class="cln-ac-seat" style="position:relative">
            <div class="cln-ac-arm2" style="left:-8px"></div>
            <div class="cln-ac-arm2" style="right:-8px"></div>
          </div>
          <div style="display:flex;justify-content:space-around;width:60px">
            <div style="width:5px;height:12px;background:#2a4a3a;border-radius:0 0 2px 2px"></div>
            <div style="width:5px;height:12px;background:#2a4a3a;border-radius:0 0 2px 2px"></div>
          </div>
        </div>

        <?php /* Side lamp */ ?>
        <div class="cln-lamp2">
          <div class="cln-lamp2-shade"></div>
          <div class="cln-lamp2-stem2"></div>
          <div class="cln-lamp2-base2"></div>
        </div>

        <?php /* Tissue box (classic therapy detail!) */ ?>
        <div style="position:absolute;bottom:calc(28% + 32px);left:calc(5% + 26px);width:22px;height:16px;background:#e8e0d0;border-radius:1px;border:1px solid #d0c8b8">
          <div style="position:absolute;top:-4px;left:4px;width:14px;height:8px;background:rgba(255,255,255,.6);border-radius:0 0 50% 50%"></div>
        </div>

        <?php /* Soft ambient glow */ ?>
        <div style="position:absolute;top:5%;left:50%;transform:translateX(-50%);width:200px;height:160px;background:radial-gradient(ellipse,rgba(200,220,210,.3),transparent 70%);pointer-events:none"></div>
      </div>
    </div>
  </div>
</section>

<?php /* ── MARQUEE ───────────────────────────────────────────────────── */ ?>
<div class="cln-marquee-wrap" aria-hidden="true">
  <div class="cln-marquee-track">
    <?php $mi=array_merge($marquee_items,$marquee_items); foreach($mi as $m): ?>
    <span class="cln-marquee-item"><?=esc_html($m)?></span>
    <?php endforeach; ?>
  </div>
</div>

<?php /* ── SERVICES ──────────────────────────────────────────────────── */ ?>
<section class="cln-section cln-services" id="services">
  <div class="cln-container">
    <div class="cln-reveal" style="text-align:center">
      <div class="cln-label">What We Offer</div>
      <h2 class="cln-h2">Therapy for Every Journey</h2>
      <div class="cln-sage-bar" style="margin:18px auto 28px"></div>
      <p class="cln-lead" style="max-width:560px;margin:0 auto">We work with a broad range of presenting concerns and life stages. All therapeutic work is evidence-based and regularly reviewed with the client.</p>
    </div>
    <div class="cln-services-grid">
      <?php foreach($services as $s): ?>
      <article class="cln-service-card cln-reveal">
        <span class="cln-service-icon"><?=esc_html($s['icon'])?></span>
        <h3 class="cln-service-title cln-h3"><?=esc_html($s['title'])?></h3>
        <p class="cln-service-desc"><?=esc_html($s['desc'])?></p>
        <div class="cln-service-meta"><?=esc_html($s['duration'])?> &nbsp;·&nbsp; <?=esc_html($s['approach'])?></div>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php /* ── PROCESS ───────────────────────────────────────────────────── */ ?>
<section class="cln-process">
  <div class="cln-container">
    <div class="cln-reveal" style="text-align:center">
      <div class="cln-label">How It Works</div>
      <h2 class="cln-h2">Getting Started Is Simple</h2>
      <div class="cln-sage-bar" style="margin:18px auto 0"></div>
    </div>
    <div class="cln-process-grid">
      <?php foreach($process_steps as $step): ?>
      <div class="cln-process-step cln-reveal">
        <div class="cln-step-num"><?=esc_html($step['num'])?></div>
        <h3 class="cln-step-title"><?=esc_html($step['title'])?></h3>
        <p class="cln-step-desc"><?=esc_html($step['desc'])?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php /* ── APPROACHES ────────────────────────────────────────────────── */ ?>
<section class="cln-section cln-approaches" id="approaches">
  <div class="cln-container">
    <div class="cln-reveal">
      <div class="cln-label">Our Approach</div>
      <h2 class="cln-h2">Evidence-Based Methods</h2>
      <div class="cln-sage-bar"></div>
      <p class="cln-lead" style="max-width:560px">Every therapist is trained in multiple modalities and will draw on the approach — or combination of approaches — best suited to your needs and goals.</p>
    </div>
    <div class="cln-approaches-grid" style="margin-top:52px">
      <?php foreach($approaches as $ap): ?>
      <div class="cln-approach-card cln-reveal">
        <div class="cln-approach-abbr"><?=esc_html($ap['abbr'])?></div>
        <div class="cln-approach-name"><?=esc_html($ap['name'])?></div>
        <p class="cln-approach-desc"><?=esc_html($ap['desc'])?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php /* ── STATS ────────────────────────────────────────────────────── */ ?>
<section class="cln-stats">
  <div class="cln-container">
    <div class="cln-stats-grid">
      <?php $cln_stats=[['n'=>'2400','s'=>'+','l'=>'Clients Supported'],['n'=>'94','s'=>'%','l'=>'Report Improvement'],['n'=>'12','s'=>'','l'=>'Accredited Therapists'],['n'=>'18','s'=>'yr','l'=>'In Practice']]; ?>
      <?php foreach($cln_stats as $i=>$st): ?>
      <div class="cln-reveal<?=$i<3?' cln-stat-divider2':''?>" style="padding:0 32px">
        <div class="cln-stat-num2" data-target="<?=esc_attr($st['n'])?>" data-suffix="<?=esc_attr($st['s'])?>"><?=esc_html($st['n'].$st['s'])?></div>
        <div class="cln-stat-label2"><?=esc_html($st['l'])?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php /* ── THERAPISTS ────────────────────────────────────────────────── */ ?>
<section class="cln-section cln-therapists" id="team">
  <div class="cln-container">
    <div class="cln-reveal" style="text-align:center">
      <div class="cln-label">Meet the Team</div>
      <h2 class="cln-h2">Your Therapists</h2>
      <div class="cln-sage-bar" style="margin:18px auto 20px"></div>
      <p class="cln-lead" style="max-width:540px;margin:0 auto">Every therapist at our practice is registered with their relevant professional body and committed to ongoing clinical supervision and development.</p>
    </div>
    <div class="cln-therapists-grid">
      <?php foreach($therapists as $ti=>$t): ?>
      <article class="cln-therapist-card cln-reveal">
        <div class="cln-therapist-portrait2">
          <div class="cln-tp-scene">
            <div class="cln-tp-bg"></div>
            <div class="cln-tp-shelf-scene"></div>
            <?php /* Body / blouse */ ?>
            <div class="cln-tp-body2" style="background:linear-gradient(160deg,<?=$t['blouse']?>,<?=$t['blouse']?>bb)"></div>
            <?php /* Neck */ ?>
            <div class="cln-tp-neck2" style="position:absolute;bottom:calc(13% + 36%);left:50%;transform:translateX(-50%);width:24px;height:20px;background:<?=$t['skin']?>;border-radius:50%"></div>
            <?php /* Head */ ?>
            <div class="cln-tp-head2" style="position:absolute;bottom:calc(13% + 48%);left:50%;transform:translateX(-50%);width:52px;height:58px;background:<?=$t['skin']?>">
              <div class="cln-tp-hair2" style="position:absolute;top:0;left:0;right:0;height:<?=$ti===0||$ti===2?45:38?>%;background:<?=$t['hair']?>;border-radius:50% 50% 0 0"></div>
              <?php if($ti===0): /* Bun */ ?>
              <div style="position:absolute;top:-8px;right:6px;width:14px;height:14px;border-radius:50%;background:<?=$t['hair']?>"></div>
              <?php endif; ?>
              <div class="cln-tp-eyes2" style="position:absolute;top:50%;left:0;right:0">
                <div class="cln-tp-eye2"></div>
                <div class="cln-tp-eye2"></div>
              </div>
              <?php if($ti===3): /* Glasses */ ?>
              <div style="position:absolute;top:46%;left:50%;transform:translateX(-50%);display:flex;gap:2px">
                <div style="width:13px;height:9px;border:1.5px solid rgba(80,60,40,.4);border-radius:2px"></div>
                <div style="width:3px;height:1px;background:rgba(80,60,40,.3);margin:auto"></div>
                <div style="width:13px;height:9px;border:1.5px solid rgba(80,60,40,.4);border-radius:2px"></div>
              </div>
              <?php endif; ?>
              <div class="cln-tp-smile2" style="position:absolute;top:68%;left:50%;transform:translateX(-50%)"></div>
            </div>
            <?php /* Small plant on shelf for warmth */ ?>
            <div style="position:absolute;bottom:14%;right:12%;width:16px;height:24px">
              <div style="width:10px;height:10px;border-radius:50% 50% 0 50%;background:#5a7a4a;position:absolute;bottom:8px;right:0"></div>
              <div style="width:10px;height:10px;border-radius:50% 0 50% 50%;background:#4a6a3a;position:absolute;bottom:8px;left:0"></div>
              <div style="width:10px;height:10px;background:#c4896a;border-radius:0 0 3px 3px;position:absolute;bottom:0;left:3px"></div>
            </div>
          </div>
        </div>
        <div class="cln-therapist-info">
          <div class="cln-therapist-name2"><?=esc_html($t['name'])?></div>
          <div class="cln-therapist-role2"><?=esc_html($t['role'])?></div>
          <div class="cln-therapist-quals"><?=esc_html($t['quals'])?></div>
          <div class="cln-therapist-spec"><?=esc_html($t['spec'])?></div>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php /* ── TESTIMONIALS ──────────────────────────────────────────────── */ ?>
<section class="cln-section cln-testimonials" id="stories">
  <div class="cln-container">
    <div class="cln-test-header cln-reveal">
      <div class="cln-label">Client Experiences</div>
      <h2 class="cln-h2">What Our Clients Say</h2>
      <div class="cln-sage-bar" style="margin:18px auto"></div>
      <p class="cln-lead" style="max-width:520px;margin:0 auto;font-style:italic">All testimonials are shared with permission and have been anonymised to protect client confidentiality.</p>
    </div>
    <div class="cln-test-grid">
      <?php foreach($testimonials as $t): ?>
      <blockquote class="cln-test-card cln-reveal">
        <div class="cln-test-quote2">"</div>
        <p class="cln-test-text2"><?=esc_html($t['text'])?></p>
        <footer>
          <div class="cln-test-author2"><?=esc_html($t['author'])?></div>
          <div class="cln-test-detail2"><?=esc_html($t['detail'])?></div>
        </footer>
      </blockquote>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php /* ── FAQ ───────────────────────────────────────────────────────── */ ?>
<section class="cln-section cln-faq" id="faq">
  <div class="cln-container">
    <div class="cln-reveal">
      <div class="cln-label">Your Questions</div>
      <h2 class="cln-h2">Before You Begin</h2>
      <div class="cln-sage-bar"></div>
    </div>
    <div class="cln-faq-grid">
      <div class="cln-faq-list">
        <?php foreach($faqs as $i=>$f): ?>
        <div class="cln-faq-item2 cln-reveal" id="cln-faq-<?=$i?>">
          <button class="cln-faq-q2" aria-expanded="false" aria-controls="cln-faq-a2-<?=$i?>"><?=esc_html($f['q'])?><span class="cln-faq-icon2" aria-hidden="true">+</span></button>
          <div class="cln-faq-a2" id="cln-faq-a2-<?=$i?>" role="region"><p><?=esc_html($f['a'])?></p></div>
        </div>
        <?php endforeach; ?>
      </div>
      <div class="cln-faq-art cln-reveal">
        <div class="cln-faq-scene">
          <?php /* Abstract growth plant illustration */ ?>
          <div class="cln-growth-root"></div>
          <?php /* Branches */ ?>
          <?php $branches=[['bottom'=>'58%','left'=>'calc(50% + 3px)','width'=>60,'angle'=>-40,'h'=>5],['bottom'=>'72%','left'=>'calc(50% + 3px)','width'=>50,'angle'=>40,'h'=>5],['bottom'=>'80%','left'=>'calc(50% + 3px)','width'=>40,'angle'=>-30,'h'=>4]]; ?>
          <?php foreach($branches as $b): ?>
          <div class="cln-growth-branch" style="position:absolute;bottom:<?=$b['bottom']?>;left:<?=$b['left']?>;width:<?=$b['width']?>px;height:<?=$b['h']?>px;transform:rotate(<?=$b['angle']?>deg)"></div>
          <?php endforeach; ?>
          <?php /* Leaves on branches */ ?>
          <?php $glleaves=[['bottom'=>'65%','left'=>'calc(50% + 50px)','w'=>24,'rot'=>-30],['bottom'=>'79%','left'=>'calc(50% + 42px)','w'=>20,'rot'=>30],['bottom'=>'87%','left'=>'calc(50% + 35px)','w'=>18,'rot'=>-25],['bottom'=>'90%','left'=>'calc(50% + 3px)','w'=>16,'rot'=>15]]; ?>
          <?php foreach($glleaves as $gl): ?>
          <div class="cln-growth-leaf" style="position:absolute;bottom:<?=$gl['bottom']?>;left:<?=$gl['left']?>;width:<?=$gl['w']?>px;height:<?=$gl['w']+6?>px;transform:rotate(<?=$gl['rot']?>deg)"></div>
          <?php endforeach; ?>
          <?php /* Concentric aura circles at base */ ?>
          <?php for($ci=0;$ci<3;$ci++): $cs=80+$ci*60; ?>
          <div class="cln-growth-circle2" style="position:absolute;bottom:0;left:50%;transform:translateX(-50%) translateY(50%);width:<?=$cs?>px;height:<?=$cs?>px;opacity:<?=round(.5-$ci*.12,2)?>"></div>
          <?php endfor; ?>
          <?php /* Caption */ ?>
          <div style="position:absolute;bottom:24px;left:50%;transform:translateX(-50%);font-family:var(--cln-ff-head);font-size:.85rem;font-style:italic;color:var(--cln-sage);white-space:nowrap">Growth takes time.</div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php /* ── BOOKING ───────────────────────────────────────────────────── */ ?>
<section class="cln-section cln-booking" id="booking">
  <div class="cln-container">
    <div class="cln-reveal">
      <div class="cln-label">Get in Touch</div>
      <h2 class="cln-h2">Book a Consultation</h2>
      <div class="cln-sage-bar"></div>
      <p class="cln-lead" style="max-width:560px">The first step is often the hardest. Complete the form below and a member of our admin team will call you within one working day — no commitment required.</p>
    </div>
    <div class="cln-booking-grid">
      <div class="cln-reveal">
        <p>We know reaching out can feel daunting. Our admin team is warm, discreet, and trained to help you find the right therapist. Every conversation is strictly confidential.</p>
        <p>We offer a free 15-minute telephone consultation before your first appointment so you can ask any questions and ensure it feels right.</p>
        <p>Sessions are available in-practice (central location), via secure video, or by telephone.</p>
        <div class="cln-contact-list">
          <div class="cln-contact-row"><div class="cln-contact-dot">📞</div><span>+44 20 7123 4567</span></div>
          <div class="cln-contact-row"><div class="cln-contact-dot">✉️</div><span>hello@mindspace-therapy.co.uk</span></div>
          <div class="cln-contact-row"><div class="cln-contact-dot">🕐</div><span>Mon–Fri 9am–7pm · Sat 9am–2pm</span></div>
          <div class="cln-contact-row"><div class="cln-contact-dot">📍</div><span>42 Harley Street, London W1G 9PW</span></div>
        </div>
      </div>
      <div class="cln-form2 cln-reveal">
        <form id="cln-booking-form" novalidate>
          <?php wp_nonce_field('tf_cln_referral','tf_cln_nonce'); ?>
          <div class="cln-form2-row">
            <div class="cln-form-group"><label for="cln-fname">First Name</label><input type="text" id="cln-fname" name="first_name" placeholder="Helena" required></div>
            <div class="cln-form-group"><label for="cln-lname">Last Name</label><input type="text" id="cln-lname" name="last_name" placeholder="Marsh" required></div>
          </div>
          <div class="cln-form-group"><label for="cln-email">Email</label><input type="email" id="cln-email" name="email" placeholder="you@example.com" required></div>
          <div class="cln-form-group"><label for="cln-phone">Phone (preferred for first contact)</label><input type="tel" id="cln-phone" name="phone" placeholder="+44 7…"></div>
          <div class="cln-form-group">
            <label for="cln-service">Type of Support</label>
            <select id="cln-service" name="service">
              <option value="">I'm not sure yet</option>
              <option value="individual">Individual Therapy</option>
              <option value="couples">Couples Counselling</option>
              <option value="family">Family Therapy</option>
              <option value="child">Child / Adolescent</option>
              <option value="workplace">Workplace Wellbeing</option>
              <option value="mindfulness">Mindfulness / Stress</option>
            </select>
          </div>
          <div class="cln-form-group">
            <label for="cln-format">Session Format</label>
            <select id="cln-format" name="format">
              <option value="either">No preference</option>
              <option value="inperson">In-person (London)</option>
              <option value="video">Secure video</option>
              <option value="phone">Telephone</option>
            </select>
          </div>
          <div class="cln-form-group">
            <label for="cln-availability">Best Time to Call</label>
            <select id="cln-availability" name="availability">
              <option value="">Flexible</option>
              <option value="morning">Morning (9am–12pm)</option>
              <option value="afternoon">Afternoon (12pm–5pm)</option>
              <option value="evening">Evening (5pm–7pm)</option>
            </select>
          </div>
          <div class="cln-form-group"><label for="cln-notes">Anything You'd Like Us to Know</label><textarea id="cln-notes" name="notes" placeholder="Briefly share what's brought you here, or any questions you have…"></textarea></div>
          <button type="submit" class="cln-form2-submit">Send Referral</button>
          <p class="cln-privacy-note">Your information is handled with complete discretion and will never be shared with third parties.</p>
        </form>
        <p id="cln-form-msg" style="display:none;text-align:center;margin-top:16px;font-size:.9rem;color:var(--cln-sage)"></p>
      </div>
    </div>
  </div>
</section>

<script>
(function(){
  /* ── Scroll reveal ─────────────────────────────────────────────── */
  const reveals = document.querySelectorAll('.cln-reveal');
  if('IntersectionObserver' in window){
    const obs = new IntersectionObserver(entries=>{
      entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');obs.unobserve(e.target)}});
    },{threshold:.1});
    reveals.forEach(el=>obs.observe(el));
  } else {
    reveals.forEach(el=>el.classList.add('visible'));
  }

  /* ── Animated counters ─────────────────────────────────────────── */
  const easeOut = t=>1-Math.pow(1-t,3);
  document.querySelectorAll('[data-target]').forEach(el=>{
    const obs2 = new IntersectionObserver(entries=>{
      if(!entries[0].isIntersecting) return;
      const target=parseInt(el.dataset.target,10);
      const suffix=el.dataset.suffix||'';
      const dur=1500;const start=performance.now();
      function tick(now){
        const t=Math.min((now-start)/dur,1);
        el.textContent=Math.round(easeOut(t)*target)+suffix;
        if(t<1) requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
      obs2.unobserve(el);
    },{threshold:.4});
    obs2.observe(el);
  });

  /* ── FAQ accordion ─────────────────────────────────────────────── */
  document.querySelectorAll('.cln-faq-item2').forEach(item=>{
    const btn=item.querySelector('.cln-faq-q2');
    btn.addEventListener('click',()=>{
      const isOpen=item.classList.contains('open');
      document.querySelectorAll('.cln-faq-item2').forEach(i=>{i.classList.remove('open');i.querySelector('.cln-faq-q2').setAttribute('aria-expanded','false')});
      if(!isOpen){item.classList.add('open');btn.setAttribute('aria-expanded','true')}
    });
  });

  /* ── Form handler ──────────────────────────────────────────────── */
  const form = document.getElementById('cln-booking-form');
  if(form){
    form.addEventListener('submit',function(e){
      e.preventDefault();
      const btn=form.querySelector('.cln-form2-submit');
      const msg=document.getElementById('cln-form-msg');
      btn.textContent='Sending…';btn.disabled=true;
      setTimeout(()=>{
        btn.textContent='Sent ✓ We\'ll be in touch shortly';
        btn.style.background='#4a6a5a';
        msg.textContent='Thank you for reaching out. A member of our team will call you within one working day.';
        msg.style.display='block';
      },900);
    });
  }
})();
</script>
</div><!-- .cln-page -->
<?php get_footer(); ?>
