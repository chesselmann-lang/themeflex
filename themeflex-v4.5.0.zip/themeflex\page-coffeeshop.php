<?php
/**
 * Template Name: Premium – Specialty Coffee Shop
 *
 * @package ThemeFlex
 */

defined('ABSPATH') || exit;

srand(crc32(get_the_permalink()));

/* ── Menu ───────────────────────────────────────────────────── */
$cof_menu = [
  'Espresso Bar' => [
    ['name'=>'Single Origin Espresso','desc'=>'Rotating single-farm selection, pulled to taste.','price'=>'£3.20'],
    ['name'=>'Flat White','desc'=>'27ml espresso, 130ml textured whole milk.','price'=>'£3.80'],
    ['name'=>'Filter Pour-Over','desc'=>'V60 or Kalita Wave, brewed to order.','price'=>'£4.20'],
    ['name'=>'Cold Brew','desc'=>'18-hour slow-steeped, served over ice.','price'=>'£4.50'],
  ],
  'Seasonal Specials' => [
    ['name'=>'Honey Cardamom Latte','desc'=>'House-infused honey, freshly ground cardamom, oat milk.','price'=>'£4.80'],
    ['name'=>'Mango Cold Brew','desc'=>'Cold brew with fresh mango reduction and coconut water.','price'=>'£5.20'],
    ['name'=>'Lavender Cortado','desc'=>'Dried lavender syrup, equal parts espresso and milk.','price'=>'£4.40'],
    ['name'=>'Cascara Spritz','desc'=>'Coffee cherry tea, sparkling water, orange peel.','price'=>'£4.60'],
  ],
  'Food' => [
    ['name'=>'Sourdough Toast','desc'=>'House-baked loaf, cultured butter, seasonal jam.','price'=>'£4.50'],
    ['name'=>'Banana & Walnut Loaf','desc'=>'Served warm with crème fraîche.','price'=>'£3.80'],
    ['name'=>'Shakshuka','desc'=>'Spiced tomato, poached eggs, feta, sourdough.','price'=>'£10.50'],
    ['name'=>'Avocado Toast','desc'=>'Smashed avocado, dukkah, chilli flakes, lemon.','price'=>'£8.50'],
  ],
];

/* ── Origins — coffee source countries ──────────────────────── */
$cof_origins = [
    ['country'=>'Ethiopia','region'=>'Yirgacheffe','notes'=>'Jasmine · Bergamot · Stone Fruit','process'=>'Natural','altitude'=>'2,200m','color'=>'#6b3a2a'],
    ['country'=>'Colombia','region'=>'Huila','notes'=>'Dark Chocolate · Caramel · Red Cherry','process'=>'Washed','altitude'=>'1,900m','color'=>'#8b4a2a'],
    ['country'=>'Kenya','region'=>'Nyeri','notes'=>'Blackcurrant · Tomato · Brown Sugar','process'=>'Washed','altitude'=>'1,800m','color'=>'#5a3a1a'],
    ['country'=>'Guatemala','region'=>'Antigua','notes'=>'Toffee · Macadamia · Mild Citrus','process'=>'Honey','altitude'=>'1,700m','color'=>'#7a4a1a'],
];

/* ── Brew methods ────────────────────────────────────────────── */
$cof_methods = [
    ['icon'=>'☕','name'=>'Espresso','desc'=>'9 bar pressure, 27 seconds, 27ml yield. The foundation of our bar.','ratio'=>'1:2'],
    ['icon'=>'🫗','name'=>'V60 Pour-Over','desc'=>'Precise water temperature and spiral pour for clean clarity.','ratio'=>'1:15'],
    ['icon'=>'🧊','name'=>'Cold Brew','desc'=>'18-hour immersion at 4°C for natural sweetness with zero bitterness.','ratio'=>'1:8'],
    ['icon'=>'🔵','name'=>'AeroPress','desc'=>'2-minute total brew time. Best for bold, experimental extractions.','ratio'=>'1:12'],
];

/* ── Stats ──────────────────────────────────────────────────── */
$cof_stats = [
    ['val'=>'18','suffix'=>'','label'=>'Origins Sourced'],
    ['val'=>'400','suffix'=>'kg+','label'=>'Roasted Monthly'],
    ['val'=>'6','suffix'=>'','label'=>'Years Open'],
    ['val'=>'98','suffix'=>'%','label'=>'Single-Farm Coffee'],
];

/* ── Events ─────────────────────────────────────────────────── */
$cof_events = [
    ['day'=>'Every Tuesday','title'=>'Brew Method Workshop','time'=>'18:30 – 20:00','spots'=>'8 seats','price'=>'£22'],
    ['day'=>'Every Friday','title'=>'Origin Tasting Flight','time'=>'17:00 – 18:30','spots'=>'10 seats','price'=>'£18'],
    ['day'=>'First Saturday','title'=>'Roastery Tour & Cupping','time'=>'10:00 – 12:00','spots'=>'6 seats','price'=>'£28'],
];

/* ── Team ────────────────────────────────────────────────────── */
$cof_team = [
    ['name'=>'Saoirse Dunne','role'=>'Head Roaster','desc'=>'SCA Q Grader. Travels twice yearly to source farms directly.','color'=>'#5a3a2a'],
    ['name'=>'Rafael Moreno','role'=>'Head Barista','desc'=>'UK Barista Champion 2022. Obsessive about extraction curves.','color'=>'#3a5a2a'],
    ['name'=>'Mei Lin','role'=>'Café Director','desc'=>'Former pastry chef. Designs seasonal food & drink pairings.','color'=>'#2a3a5a'],
    ['name'=>'James Okafor','role'=>'Training Lead','desc'=>'Runs all workshops and leads staff development.','color'=>'#5a2a4a'],
];

/* ── Testimonials ────────────────────────────────────────────── */
$cof_testimonials = [
    ['quote'=>'The best flat white in London. I\'ve tried them all — this is it. The Yirgacheffe espresso has a jasmine note so clear it stops you mid-sip.','author'=>'Eleanor B.','tag'=>'Regular since 2020'],
    ['quote'=>'The Tuesday brew workshops changed how I make coffee at home completely. Rafael explains extraction in a way that actually makes sense.','author'=>'Tom K.','tag'=>'Workshop Attendee'],
    ['quote'=>'We buy our beans here for the office. The difference in quality from supermarket coffee is extraordinary. Our team now actually enjoys Monday mornings.','author'=>'Priya N.','tag'=>'Wholesale Customer'],
];

/* ── FAQ ─────────────────────────────────────────────────────── */
$cof_faqs = [
    ['q'=>'Do you sell your coffee beans to take home?','a'=>'Yes — all of our rotating single-origins are available to buy as whole beans or freshly ground to your brew method of choice. We recommend buying whole bean for maximum freshness.'],
    ['q'=>'Can I get a wholesale supply for my business?','a'=>'Absolutely. We supply offices, restaurants and independent cafés with weekly roasted single-origins. Get in touch via our wholesale enquiry form and we\'ll arrange a complimentary tasting session.'],
    ['q'=>'Are all your coffees traceable to a single farm?','a'=>'98% of our offering is single-farm traceable. We publish full transparency data including farm name, farmer, altitude, process and harvest season for every lot we stock.'],
    ['q'=>'Do you cater for dairy-free and vegan customers?','a'=>'Yes. We stock oat, almond, soya and coconut milk alternatives. Our food menu clearly labels all vegan and dairy-free items, and most baked goods have vegan alternatives available.'],
    ['q'=>'Can I hire the café for a private event?','a'=>'The café is available for private hire on Sunday evenings from 6pm. We can accommodate up to 30 guests with a custom brew station, tasting menu and optional workshop element.'],
];

get_header();
?>

<!– Specialty Coffee Shop — ThemeFlex Premium Template –>
<style>
@import url('https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,700;1,9..144,300;1,9..144,700&family=DM+Sans:wght@300;400;500;700&display=swap');

:root {
  --cof-espresso: #1a0f0a;
  --cof-roast:    #2d1c10;
  --cof-brown:    #5a3a1e;
  --cof-caramel:  #c4813a;
  --cof-cream:    #f5ede0;
  --cof-ivory:    #fdf9f3;
  --cof-steam:    #e8ddd0;
  --cof-sage:     #6a7a5a;
  --cof-slate:    #4a4540;
  --cof-border:   rgba(196,129,58,0.2);
  --cof-serif:    'Fraunces', Georgia, serif;
  --cof-sans:     'DM Sans', system-ui, sans-serif;
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

.cof-wrap { font-family: var(--cof-sans); color: var(--cof-espresso); background: var(--cof-ivory); overflow-x: hidden; }

/* ── HERO ──────────────────────────────────────────────────── */
.cof-hero {
  position: relative;
  min-height: 100vh;
  background: var(--cof-espresso);
  display: flex;
  align-items: center;
  overflow: hidden;
}

/* Warm background gradient */
.cof-hero-bg {
  position: absolute; inset: 0;
  background: radial-gradient(ellipse at 30% 60%, rgba(196,129,58,0.12) 0%, transparent 60%),
              radial-gradient(ellipse at 80% 20%, rgba(90,58,30,0.2) 0%, transparent 50%);
}

/* CSS Café Interior Scene */
.cof-interior {
  position: absolute;
  right: 0; top: 0; bottom: 0;
  width: 52%;
  overflow: hidden;
}

/* Wall */
.cof-wall {
  position: absolute; inset: 0;
  background: linear-gradient(180deg, #2a1a0e 0%, #1e1208 100%);
}

/* Exposed brick pattern */
.cof-bricks {
  position: absolute; inset: 0;
  background-image:
    repeating-linear-gradient(0deg, transparent, transparent 22px, rgba(60,30,10,0.3) 22px, rgba(60,30,10,0.3) 24px),
    repeating-linear-gradient(90deg, transparent, transparent 48px, rgba(60,30,10,0.2) 48px, rgba(60,30,10,0.2) 50px);
}

/* Wooden shelf */
.cof-shelf {
  position: absolute;
  left: 40px;
  width: 320px; height: 12px;
  background: linear-gradient(180deg, #6b4a22 0%, #4a3010 100%);
  border-radius: 2px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.4);
}
.cof-shelf::after {
  content: '';
  position: absolute;
  bottom: -20px; left: 8px; right: 8px;
  height: 20px;
  background: #3a2010;
  clip-path: polygon(0 0, 100% 0, 90% 100%, 10% 100%);
}

/* Coffee equipment on shelf */
.cof-aeropress {
  position: absolute;
  bottom: 14px; left: 20px;
  width: 22px; height: 60px;
  background: linear-gradient(180deg, #d0ccc8 0%, #a0a0a0 100%);
  border-radius: 4px 4px 0 0;
}
.cof-aeropress::before {
  content: '';
  position: absolute;
  bottom: 0; left: 50%;
  transform: translateX(-50%);
  width: 28px; height: 4px;
  background: #888;
  border-radius: 2px;
}

.cof-grinder {
  position: absolute;
  bottom: 14px; left: 52px;
  width: 36px; height: 70px;
  background: linear-gradient(180deg, #c0bab4 0%, #888880 100%);
  border-radius: 4px 4px 8px 8px;
}
.cof-grinder::before {
  content: '';
  position: absolute;
  top: -12px; left: 50%;
  transform: translateX(-50%);
  width: 28px; height: 24px;
  background: #a0a098;
  border-radius: 50% 50% 0 0;
}

/* Coffee bags */
.cof-bag {
  position: absolute;
  bottom: 14px;
  width: 28px;
  border-radius: 3px 3px 0 0;
}
.cof-bag::before {
  content: '';
  position: absolute;
  top: -6px; left: 20%;
  width: 60%; height: 8px;
  background: rgba(0,0,0,0.3);
  border-radius: 2px 2px 0 0;
}

/* Large window */
.cof-window {
  position: absolute;
  top: 60px; right: 30px;
  width: 200px; height: 260px;
  border: 8px solid #6b4a22;
  background: linear-gradient(180deg,
    rgba(135,180,220,0.4) 0%,
    rgba(180,210,240,0.3) 50%,
    rgba(220,200,160,0.3) 100%
  );
  box-shadow: inset 0 0 40px rgba(0,0,0,0.2);
}
/* Window cross bars */
.cof-window::before {
  content: '';
  position: absolute;
  top: 50%; left: 0; right: 0;
  height: 6px;
  background: #6b4a22;
  margin-top: -3px;
}
.cof-window::after {
  content: '';
  position: absolute;
  top: 0; bottom: 0; left: 50%;
  width: 6px;
  background: #6b4a22;
  margin-left: -3px;
}
/* Window light spill */
.cof-window-light {
  position: absolute;
  top: 60px; right: 30px;
  width: 200px; height: 260px;
  background: radial-gradient(ellipse at 50% 50%, rgba(245,230,180,0.15) 0%, transparent 70%);
  pointer-events: none;
}

/* Espresso machine */
.cof-machine {
  position: absolute;
  bottom: 0; left: 40px;
  width: 180px; height: 140px;
}
.cof-machine-body {
  position: absolute;
  bottom: 0; left: 0;
  width: 180px; height: 110px;
  background: linear-gradient(180deg, #e0dcd8 0%, #c8c4c0 100%);
  border-radius: 8px 8px 0 0;
  border-top: 3px solid #b0aca8;
}
/* Machine group heads */
.cof-machine-head {
  position: absolute;
  bottom: 40px;
  width: 44px; height: 44px;
  background: #888;
  border-radius: 50%;
  border: 3px solid #606060;
}
.cof-machine-head::before {
  content: '';
  position: absolute;
  bottom: -12px; left: 50%;
  transform: translateX(-50%);
  width: 6px; height: 14px;
  background: #606060;
}
.cof-machine-head::after {
  content: '';
  position: absolute;
  bottom: -20px; left: 50%;
  transform: translateX(-50%);
  width: 32px; height: 4px;
  background: #505050;
  border-radius: 0 0 2px 2px;
}
/* Steam wand */
.cof-steam-wand {
  position: absolute;
  bottom: 60px; right: 20px;
  width: 4px; height: 60px;
  background: #888;
  transform: rotate(15deg);
  transform-origin: bottom center;
  border-radius: 2px;
}
.cof-steam-wand::after {
  content: '';
  position: absolute;
  bottom: 0; left: -4px;
  width: 12px; height: 8px;
  background: #606060;
  border-radius: 4px;
}
/* Steam particles */
.cof-steam-particle {
  position: absolute;
  width: 6px; height: 6px;
  background: rgba(245,237,224,0.4);
  border-radius: 50%;
  animation: cof-steam-rise 2s ease-out infinite;
}
@keyframes cof-steam-rise {
  0% { transform: translateY(0) scale(0.5); opacity: 0.6; }
  100% { transform: translateY(-60px) scale(1.5); opacity: 0; }
}

/* Counter / bar */
.cof-counter {
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 80px;
  background: linear-gradient(180deg, #8b5a2a 0%, #6b3a1a 100%);
  border-top: 4px solid #a06030;
}
.cof-counter-front {
  position: absolute;
  top: 4px; left: 0; right: 0; bottom: 0;
  background: repeating-linear-gradient(90deg, rgba(0,0,0,0.1) 0px, rgba(0,0,0,0.1) 1px, transparent 1px, transparent 60px);
}

/* Hanging pendant lights */
.cof-pendant {
  position: absolute;
  top: 0;
}
.cof-pendant-cord {
  width: 2px;
  background: rgba(255,255,255,0.2);
  margin: 0 auto;
}
.cof-pendant-shade {
  width: 30px; height: 20px;
  background: linear-gradient(180deg, #c8a050 0%, #f0c860 100%);
  border-radius: 50% 50% 40% 40% / 30% 30% 60% 60%;
  box-shadow: 0 0 30px rgba(248,220,100,0.4), 0 0 60px rgba(248,220,100,0.15);
  margin: 0 auto;
}
.cof-pendant-glow {
  position: absolute;
  bottom: 0; left: 50%;
  transform: translateX(-50%);
  width: 120px; height: 80px;
  background: radial-gradient(ellipse at 50% 0%, rgba(248,220,100,0.2) 0%, transparent 70%);
}

/* Plants on counter */
.cof-plant-pot {
  position: absolute;
  width: 20px; height: 16px;
  background: #8b3a1a;
  border-radius: 0 0 4px 4px;
  clip-path: polygon(10% 0%, 90% 0%, 100% 100%, 0% 100%);
}
.cof-plant-leaf {
  position: absolute;
  background: var(--cof-sage);
  border-radius: 50%;
  transform-origin: bottom center;
}

/* Chalkboard */
.cof-chalkboard {
  position: absolute;
  top: 50px; left: 260px;
  width: 140px; height: 180px;
  background: #1a2a1a;
  border: 6px solid #3a2a10;
  display: flex;
  align-items: center;
  justify-content: center;
}
.cof-chalk-text {
  color: rgba(255,255,255,0.7);
  font-family: var(--cof-serif);
  font-style: italic;
  font-size: 0.7rem;
  text-align: center;
  line-height: 1.6;
  padding: 8px;
}

/* Hero left content */
.cof-hero-content {
  position: relative;
  z-index: 5;
  max-width: 600px;
  padding: 80px 60px;
}

.cof-hero-eyebrow {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-bottom: 24px;
}
.cof-eyebrow-bean {
  font-size: 1.1rem;
}
.cof-eyebrow-text {
  font-size: 0.68rem;
  font-weight: 700;
  letter-spacing: 0.25em;
  text-transform: uppercase;
  color: var(--cof-caramel);
}

.cof-hero h1 {
  font-family: var(--cof-serif);
  font-size: clamp(3rem, 5.5vw, 5.5rem);
  font-weight: 700;
  line-height: 1.05;
  color: var(--cof-cream);
  margin-bottom: 8px;
}
.cof-hero h1 em {
  font-style: italic;
  font-weight: 300;
  color: var(--cof-caramel);
}

.cof-hero-sub {
  font-family: var(--cof-serif);
  font-size: 1.2rem;
  font-style: italic;
  font-weight: 300;
  color: rgba(245,237,224,0.65);
  margin-bottom: 32px;
}
.cof-hero-desc {
  font-size: 0.95rem;
  line-height: 1.75;
  color: rgba(245,237,224,0.6);
  max-width: 440px;
  margin-bottom: 48px;
}

.cof-hero-ctas {
  display: flex;
  gap: 14px;
  flex-wrap: wrap;
}
.cof-btn-primary {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 15px 30px;
  background: var(--cof-caramel);
  color: var(--cof-espresso);
  font-family: var(--cof-sans); font-size: 0.82rem; font-weight: 700;
  letter-spacing: 0.1em; text-transform: uppercase; text-decoration: none;
  border: none; cursor: pointer; transition: background 0.25s, transform 0.2s;
}
.cof-btn-primary:hover { background: #d49248; transform: translateY(-2px); }
.cof-btn-ghost {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 14px 30px;
  background: transparent;
  color: var(--cof-cream);
  font-family: var(--cof-sans); font-size: 0.82rem; font-weight: 600;
  letter-spacing: 0.1em; text-transform: uppercase; text-decoration: none;
  border: 1px solid rgba(245,237,224,0.25);
  transition: border-color 0.25s, color 0.25s, transform 0.2s;
}
.cof-btn-ghost:hover { border-color: var(--cof-caramel); color: var(--cof-caramel); transform: translateY(-2px); }

/* Origin tags strip at hero bottom */
.cof-hero-origins {
  position: absolute;
  bottom: 0; left: 0; right: 0;
  background: rgba(26,15,10,0.92);
  border-top: 1px solid var(--cof-border);
  backdrop-filter: blur(6px);
  display: flex;
  justify-content: center;
  z-index: 5;
}
.cof-origin-tag {
  padding: 16px 36px;
  border-right: 1px solid var(--cof-border);
  display: flex;
  align-items: center;
  gap: 10px;
}
.cof-origin-tag:last-child { border-right: none; }
.cof-origin-flag { font-size: 1.2rem; }
.cof-origin-name { font-size: 0.72rem; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: var(--cof-caramel); }
.cof-origin-note { font-size: 0.65rem; color: rgba(245,237,224,0.5); margin-top: 2px; }

/* ── GENERAL ─────────────────────────────────────────────────  */
.cof-section { padding: 100px 60px; max-width: 1280px; margin: 0 auto; }
.cof-section-full { padding: 100px 60px; }
.cof-section-label {
  display: flex; align-items: center; gap: 12px; margin-bottom: 14px;
}
.cof-label-dot {
  width: 6px; height: 6px; border-radius: 50%; background: var(--cof-caramel);
}
.cof-label-text {
  font-size: 0.68rem; font-weight: 700; letter-spacing: 0.22em; text-transform: uppercase; color: var(--cof-caramel);
}
.cof-section-title {
  font-family: var(--cof-serif); font-size: clamp(1.8rem, 3vw, 2.8rem); font-weight: 700;
  line-height: 1.2; color: var(--cof-espresso); margin-bottom: 14px;
}
.cof-section-title em { font-style: italic; font-weight: 300; color: var(--cof-brown); }
.cof-section-intro {
  font-size: 1rem; line-height: 1.75; color: var(--cof-slate); max-width: 580px; margin-bottom: 60px;
}

/* ── REVEAL ──────────────────────────────────────────────────  */
.cof-reveal {
  opacity: 0; transform: translateY(24px);
  transition: opacity 0.6s ease, transform 0.6s ease;
}
.cof-reveal.visible { opacity: 1; transform: translateY(0); }

/* ── MENU ────────────────────────────────────────────────────  */
.cof-menu-section { background: var(--cof-ivory); }
.cof-menu-tabs {
  display: flex; gap: 0; margin-bottom: 48px;
  border-bottom: 2px solid var(--cof-border);
}
.cof-menu-tab {
  padding: 14px 28px; background: none; border: none; cursor: pointer;
  font-family: var(--cof-sans); font-size: 0.82rem; font-weight: 600;
  letter-spacing: 0.08em; text-transform: uppercase;
  color: var(--cof-slate); position: relative;
  transition: color 0.25s;
}
.cof-menu-tab::after {
  content: ''; position: absolute; bottom: -2px; left: 0; right: 0; height: 2px;
  background: var(--cof-caramel); transform: scaleX(0); transition: transform 0.3s;
}
.cof-menu-tab.active, .cof-menu-tab:hover { color: var(--cof-espresso); }
.cof-menu-tab.active::after { transform: scaleX(1); }

.cof-menu-panel { display: none; }
.cof-menu-panel.active { display: grid; grid-template-columns: 1fr 1fr; gap: 0; background: rgba(196,129,58,0.07); }
.cof-menu-item {
  background: var(--cof-ivory); padding: 28px 32px;
  border-bottom: 1px solid rgba(196,129,58,0.1);
  display: flex; align-items: flex-start; justify-content: space-between; gap: 16px;
  transition: background 0.2s;
}
.cof-menu-item:hover { background: #fdf7ef; }
.cof-menu-item-info { flex: 1; }
.cof-menu-item-name {
  font-family: var(--cof-serif); font-size: 1rem; font-weight: 700;
  color: var(--cof-espresso); margin-bottom: 6px;
}
.cof-menu-item-desc { font-size: 0.82rem; color: var(--cof-slate); line-height: 1.5; }
.cof-menu-price {
  font-family: var(--cof-serif); font-size: 1.1rem; font-weight: 700;
  color: var(--cof-caramel); flex-shrink: 0; white-space: nowrap;
}

/* ── ORIGINS ─────────────────────────────────────────────────  */
.cof-origins-section { background: var(--cof-roast); }
.cof-origins-grid {
  display: grid; grid-template-columns: repeat(4, 1fr); gap: 2px;
  background: rgba(196,129,58,0.1);
}
.cof-origin-card {
  background: var(--cof-roast); padding: 40px 32px; position: relative;
  border-top: 3px solid transparent; transition: border-color 0.3s;
  overflow: hidden;
}
.cof-origin-card:hover { border-top-color: var(--cof-caramel); }
.cof-origin-card-country {
  font-family: var(--cof-serif); font-size: 1.4rem; font-weight: 700;
  color: var(--cof-cream); margin-bottom: 4px;
}
.cof-origin-card-region {
  font-size: 0.72rem; font-weight: 600; letter-spacing: 0.12em;
  text-transform: uppercase; color: var(--cof-caramel); margin-bottom: 20px;
}
.cof-origin-card-notes {
  font-family: var(--cof-serif); font-style: italic;
  font-size: 0.9rem; color: rgba(245,237,224,0.7); line-height: 1.6; margin-bottom: 20px;
}
.cof-origin-detail {
  display: flex; gap: 16px; flex-wrap: wrap;
}
.cof-origin-badge {
  font-size: 0.68rem; font-weight: 600; letter-spacing: 0.08em;
  text-transform: uppercase; color: rgba(245,237,224,0.5);
  border: 1px solid rgba(196,129,58,0.25); padding: 4px 10px; border-radius: 2px;
}
/* Large background country initial */
.cof-origin-card::after {
  content: attr(data-country);
  position: absolute; bottom: -20px; right: -10px;
  font-family: var(--cof-serif); font-size: 7rem; font-weight: 700;
  color: rgba(196,129,58,0.05); pointer-events: none; line-height: 1;
}

/* ── BREW METHODS ────────────────────────────────────────────  */
.cof-methods-section { background: var(--cof-cream); }
.cof-methods-grid {
  display: grid; grid-template-columns: repeat(4, 1fr); gap: 28px;
}
.cof-method-card {
  background: var(--cof-ivory); padding: 40px 28px; text-align: center;
  border: 1px solid rgba(196,129,58,0.1); transition: box-shadow 0.3s, transform 0.3s;
}
.cof-method-card:hover { box-shadow: 0 12px 40px rgba(90,58,30,0.1); transform: translateY(-4px); }
.cof-method-icon { font-size: 2.4rem; display: block; margin-bottom: 16px; }
.cof-method-name {
  font-family: var(--cof-serif); font-size: 1.1rem; font-weight: 700;
  color: var(--cof-espresso); margin-bottom: 12px;
}
.cof-method-desc { font-size: 0.84rem; line-height: 1.7; color: var(--cof-slate); margin-bottom: 18px; }
.cof-method-ratio {
  display: inline-block; padding: 6px 16px;
  background: var(--cof-caramel); color: var(--cof-espresso);
  font-size: 0.78rem; font-weight: 700; letter-spacing: 0.08em;
}

/* ── STATS ───────────────────────────────────────────────────  */
.cof-stats-section {
  background: var(--cof-caramel); padding: 80px 60px; position: relative; overflow: hidden;
}
.cof-stats-section::before {
  content: '☕';
  position: absolute; right: 5%; top: 50%; transform: translateY(-50%);
  font-size: 260px; opacity: 0.08; pointer-events: none;
}
.cof-stats-grid {
  display: grid; grid-template-columns: repeat(4, 1fr); gap: 0;
  border: 1px solid rgba(26,15,10,0.15); max-width: 900px; margin: 0 auto;
}
.cof-stat-item {
  padding: 48px 32px; text-align: center;
  border-right: 1px solid rgba(26,15,10,0.15);
}
.cof-stat-item:last-child { border-right: none; }
.cof-stat-val {
  font-family: var(--cof-serif); font-size: 3.5rem; font-weight: 700;
  color: var(--cof-espresso); line-height: 1; display: block;
}
.cof-stat-label {
  font-size: 0.72rem; font-weight: 600; letter-spacing: 0.12em;
  text-transform: uppercase; color: rgba(26,15,10,0.6); margin-top: 8px; display: block;
}

/* ── EVENTS ──────────────────────────────────────────────────  */
.cof-events-section { background: var(--cof-ivory); }
.cof-events-grid {
  display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px;
}
.cof-event-card {
  background: var(--cof-cream); padding: 36px 32px; position: relative;
  border-top: 3px solid var(--cof-caramel); transition: box-shadow 0.3s;
}
.cof-event-card:hover { box-shadow: 0 12px 32px rgba(90,58,30,0.1); }
.cof-event-day {
  font-size: 0.7rem; font-weight: 700; letter-spacing: 0.15em;
  text-transform: uppercase; color: var(--cof-caramel); margin-bottom: 10px;
}
.cof-event-title {
  font-family: var(--cof-serif); font-size: 1.2rem; font-weight: 700;
  color: var(--cof-espresso); margin-bottom: 16px;
}
.cof-event-details {
  display: flex; flex-direction: column; gap: 6px; margin-bottom: 24px;
}
.cof-event-detail {
  font-size: 0.8rem; color: var(--cof-slate); display: flex; align-items: center; gap: 8px;
}
.cof-event-price {
  font-family: var(--cof-serif); font-size: 1.3rem; font-weight: 700;
  color: var(--cof-caramel); display: flex; align-items: baseline; gap: 4px;
}
.cof-event-price span { font-size: 0.72rem; color: var(--cof-slate); font-family: var(--cof-sans); font-weight: 400; }
.cof-event-book {
  position: absolute; top: 24px; right: 24px;
  font-size: 0.68rem; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase;
  color: var(--cof-espresso); text-decoration: none;
  padding: 6px 14px; border: 1px solid var(--cof-espresso);
  transition: background 0.2s, color 0.2s;
}
.cof-event-book:hover { background: var(--cof-espresso); color: var(--cof-cream); }

/* ── TEAM ────────────────────────────────────────────────────  */
.cof-team-section { background: var(--cof-cream); }
.cof-team-grid {
  display: grid; grid-template-columns: repeat(4, 1fr); gap: 24px;
}
.cof-team-card {
  background: var(--cof-ivory); padding: 32px 24px; text-align: center;
  border: 1px solid rgba(196,129,58,0.12); transition: transform 0.3s;
}
.cof-team-card:hover { transform: translateY(-4px); }

/* CSS team portrait */
.cof-team-portrait {
  width: 80px; height: 80px; border-radius: 50%;
  margin: 0 auto 20px; position: relative; overflow: hidden;
  border: 2px solid var(--cof-caramel);
}
.cof-tp-bg { position: absolute; inset: 0; border-radius: 50%; }
.cof-tp-head {
  position: absolute; top: 14px; left: 50%;
  transform: translateX(-50%);
  width: 30px; height: 30px; background: #d4a574; border-radius: 50%;
}
.cof-tp-body {
  position: absolute; bottom: 0; left: 50%;
  transform: translateX(-50%);
  width: 70px; height: 36px;
  border-radius: 50% 50% 0 0 / 30% 30% 0 0;
}
/* Apron for barista uniform */
.cof-tp-apron {
  position: absolute; bottom: 4px; left: 50%;
  transform: translateX(-50%);
  width: 36px; height: 28px;
  background: rgba(245,237,224,0.4);
  clip-path: polygon(10% 0%, 90% 0%, 100% 100%, 0% 100%);
}
.cof-team-name {
  font-family: var(--cof-serif); font-size: 1rem; font-weight: 700;
  color: var(--cof-espresso); margin-bottom: 4px;
}
.cof-team-role {
  font-size: 0.7rem; font-weight: 700; letter-spacing: 0.1em;
  text-transform: uppercase; color: var(--cof-caramel); margin-bottom: 12px;
}
.cof-team-desc {
  font-size: 0.8rem; line-height: 1.65; color: var(--cof-slate);
}

/* ── TESTIMONIALS ────────────────────────────────────────────  */
.cof-testi-section { background: var(--cof-ivory); }
.cof-testi-grid {
  display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px;
}
.cof-testi-card {
  background: var(--cof-cream); padding: 36px 32px;
  border-radius: 0; position: relative;
}
.cof-testi-stars {
  color: var(--cof-caramel); font-size: 0.9rem; letter-spacing: 3px;
  margin-bottom: 16px; display: block;
}
.cof-testi-text {
  font-family: var(--cof-serif); font-style: italic;
  font-size: 0.95rem; line-height: 1.75; color: var(--cof-slate); margin-bottom: 20px;
}
.cof-testi-author { font-size: 0.82rem; font-weight: 700; color: var(--cof-espresso); }
.cof-testi-tag { font-size: 0.7rem; color: var(--cof-caramel); margin-top: 3px; }

/* ── FAQ ─────────────────────────────────────────────────────  */
.cof-faq-section { background: var(--cof-cream); }
.cof-faq-list { max-width: 780px; }
.cof-faq-item { border-bottom: 1px solid rgba(196,129,58,0.2); }
.cof-faq-trigger {
  width: 100%; background: none; border: none;
  display: flex; align-items: center; justify-content: space-between;
  gap: 14px; padding: 22px 0; cursor: pointer; text-align: left;
}
.cof-faq-q {
  font-family: var(--cof-serif); font-size: 1rem; font-weight: 700;
  color: var(--cof-espresso); line-height: 1.35;
}
.cof-faq-icon {
  flex-shrink: 0; width: 26px; height: 26px; border-radius: 50%;
  border: 1px solid var(--cof-caramel);
  display: flex; align-items: center; justify-content: center;
  font-size: 1rem; color: var(--cof-caramel);
  transition: transform 0.3s, background 0.3s;
}
.cof-faq-item.open .cof-faq-icon { transform: rotate(45deg); background: var(--cof-caramel); color: var(--cof-espresso); }
.cof-faq-body { overflow: hidden; max-height: 0; transition: max-height 0.4s ease; }
.cof-faq-body-inner { padding: 0 0 22px; font-size: 0.88rem; line-height: 1.75; color: var(--cof-slate); }

/* ── CONTACT / VISIT ─────────────────────────────────────────  */
.cof-visit-section { background: var(--cof-espresso); padding: 100px 60px; }
.cof-visit-inner {
  max-width: 1280px; margin: 0 auto;
  display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: start;
}
.cof-visit-title {
  font-family: var(--cof-serif); font-size: clamp(1.8rem, 2.8vw, 2.6rem);
  font-weight: 700; color: var(--cof-cream); line-height: 1.2; margin-bottom: 20px;
}
.cof-visit-title em { font-style: italic; font-weight: 300; color: var(--cof-caramel); }
.cof-visit-intro { font-size: 0.95rem; line-height: 1.75; color: rgba(245,237,224,0.6); margin-bottom: 40px; }
.cof-visit-info { display: flex; flex-direction: column; gap: 20px; }
.cof-visit-info-row { display: flex; gap: 14px; align-items: flex-start; }
.cof-visit-info-icon {
  width: 36px; height: 36px; border: 1px solid var(--cof-border);
  display: flex; align-items: center; justify-content: center; font-size: 0.9rem; flex-shrink: 0;
}
.cof-visit-info-text { font-size: 0.84rem; color: rgba(245,237,224,0.6); line-height: 1.65; }
.cof-visit-info-text strong { display: block; color: var(--cof-cream); font-size: 0.72rem; letter-spacing: 0.1em; text-transform: uppercase; margin-bottom: 3px; }

.cof-form { background: rgba(255,255,255,0.05); border: 1px solid var(--cof-border); padding: 44px 40px; }
.cof-form-group { margin-bottom: 18px; }
.cof-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 18px; }
.cof-form-label { display: block; font-size: 0.66rem; font-weight: 700; letter-spacing: 0.15em; text-transform: uppercase; color: rgba(245,237,224,0.5); margin-bottom: 7px; }
.cof-form-control {
  width: 100%; background: rgba(255,255,255,0.06); border: 1px solid rgba(196,129,58,0.2);
  color: var(--cof-cream); padding: 12px 15px; font-family: var(--cof-sans); font-size: 0.88rem; outline: none; transition: border-color 0.25s;
}
.cof-form-control:focus { border-color: var(--cof-caramel); }
.cof-form-control::placeholder { color: rgba(245,237,224,0.25); }
select.cof-form-control option { background: var(--cof-roast); }
textarea.cof-form-control { min-height: 96px; resize: vertical; }
.cof-form-submit {
  width: 100%; padding: 16px; background: var(--cof-caramel); color: var(--cof-espresso);
  border: none; font-family: var(--cof-sans); font-size: 0.8rem; font-weight: 700;
  letter-spacing: 0.15em; text-transform: uppercase; cursor: pointer;
  transition: background 0.25s, transform 0.2s; margin-top: 8px;
}
.cof-form-submit:hover { background: #d49248; transform: translateY(-2px); }
.cof-form-success { display: none; text-align: center; padding: 40px; }
.cof-success-icon { font-size: 3rem; display: block; margin-bottom: 16px; }
.cof-form-success p { font-family: var(--cof-serif); font-size: 1.1rem; font-style: italic; color: var(--cof-cream); }

@media (max-width: 1100px) {
  .cof-origins-grid { grid-template-columns: repeat(2, 1fr); }
  .cof-methods-grid { grid-template-columns: repeat(2, 1fr); }
  .cof-team-grid { grid-template-columns: repeat(2, 1fr); }
  .cof-visit-inner { grid-template-columns: 1fr; }
}
@media (max-width: 768px) {
  .cof-hero-content { padding: 60px 24px 120px; }
  .cof-interior { opacity: 0.12; }
  .cof-menu-panel.active { grid-template-columns: 1fr; }
  .cof-origins-grid { grid-template-columns: 1fr; }
  .cof-methods-grid { grid-template-columns: 1fr; }
  .cof-stats-grid { grid-template-columns: repeat(2, 1fr); }
  .cof-events-grid { grid-template-columns: 1fr; }
  .cof-team-grid { grid-template-columns: 1fr; }
  .cof-testi-grid { grid-template-columns: 1fr; }
  .cof-form-row { grid-template-columns: 1fr; }
  .cof-form { padding: 28px 20px; }
  .cof-hero-origins { flex-wrap: wrap; }
  .cof-origin-tag { flex: 1 1 50%; border-right: none; border-bottom: 1px solid var(--cof-border); }
}
</style>

<div class="cof-wrap">

  <!-- ═══ HERO ══════════════════════════════════════════════════ -->
  <section class="cof-hero">
    <div class="cof-hero-bg"></div>

    <!-- CSS Café Interior -->
    <div class="cof-interior" aria-hidden="true">
      <div class="cof-wall"></div>
      <div class="cof-bricks"></div>

      <!-- Pendant lights -->
      <?php
      $cof_pendants = [[80, 80], [200, 120], [330, 100], [440, 140]];
      foreach ($cof_pendants as [$px, $ph]):
      ?>
      <div class="cof-pendant" style="left:<?= $px ?>px;">
        <div class="cof-pendant-cord" style="height:<?= $ph ?>px;"></div>
        <div class="cof-pendant-shade"></div>
        <div class="cof-pendant-glow"></div>
      </div>
      <?php endforeach; ?>

      <!-- Window -->
      <div class="cof-window"></div>
      <div class="cof-window-light"></div>

      <!-- Top shelf with items -->
      <div class="cof-shelf" style="top:220px;">
        <div class="cof-aeropress"></div>
        <div class="cof-grinder"></div>
        <!-- Coffee bags -->
        <?php
        $cof_bag_colors = ['#8b0000','#1a3a5c','#2d4a1e','#6b3a00'];
        for ($bi = 0; $bi < 4; $bi++):
          $bh3 = rand(52, 72);
        ?>
        <div class="cof-bag" style="background:<?= $cof_bag_colors[$bi] ?>;height:<?= $bh3 ?>px;left:<?= 96 + $bi * 36 ?>px;bottom:14px;"></div>
        <?php endfor; ?>
      </div>

      <!-- Middle shelf -->
      <div class="cof-shelf" style="top:360px;">
        <!-- Books / reference -->
        <?php
        $cof_sh_colors = ['#5a3a1e','#1a2a3a','#3a1a1a'];
        for ($bi = 0; $bi < 3; $bi++): ?>
        <div style="position:absolute;bottom:14px;left:<?= 14 + $bi * 40 ?>px;width:28px;height:<?= rand(55,75) ?>px;background:<?= $cof_sh_colors[$bi] ?>;border-right:2px solid rgba(0,0,0,0.2);"></div>
        <?php endfor; ?>
        <!-- Small plant pots -->
        <?php for ($pi = 0; $pi < 3; $pi++): ?>
        <div style="position:absolute;bottom:14px;left:<?= 140 + $pi * 56 ?>px;">
          <div class="cof-plant-pot"></div>
          <?php for ($li2 = 0; $li2 < 3; $li2++): ?>
          <div class="cof-plant-leaf" style="
            bottom:14px;left:<?= 2 + $li2 * 5 ?>px;
            width:<?= 10 + $li2 * 3 ?>px;height:<?= 8 + $li2 * 4 ?>px;
            transform:rotate(<?= -20 + $li2 * 20 ?>deg);
          "></div>
          <?php endfor; ?>
        </div>
        <?php endfor; ?>
      </div>

      <!-- Chalkboard menu -->
      <div class="cof-chalkboard">
        <div class="cof-chalk-text">
          Today's<br>Filter<br>—<br>Ethiopia<br>Yirgacheffe<br><br>£4.20
        </div>
      </div>

      <!-- Counter and espresso machine -->
      <div class="cof-counter">
        <div class="cof-counter-front"></div>
      </div>
      <div class="cof-machine">
        <div class="cof-machine-body">
          <!-- Group heads -->
          <div class="cof-machine-head" style="left:28px;"></div>
          <div class="cof-machine-head" style="left:96px;"></div>
          <!-- Steam wand -->
          <div class="cof-steam-wand">
            <?php for ($si = 0; $si < 3; $si++): ?>
            <div class="cof-steam-particle" style="
              top:-<?= 10 + $si * 12 ?>px;left:<?= -4 + $si * 6 ?>px;
              animation-delay:<?= $si * 0.6 ?>s;
              animation-duration:<?= 1.8 + $si * 0.4 ?>s;
            "></div>
            <?php endfor; ?>
          </div>
          <!-- Display panel -->
          <div style="position:absolute;top:8px;left:50%;transform:translateX(-50%);width:70px;height:20px;background:#222;border-radius:2px;border:1px solid #444;"></div>
        </div>
      </div>
    </div>

    <!-- Hero content -->
    <div class="cof-hero-content">
      <div class="cof-hero-eyebrow">
        <span class="cof-eyebrow-bean">☕</span>
        <span class="cof-eyebrow-text">Groundwork Specialty Coffee</span>
      </div>
      <h1>Coffee Worth<br><em>Pausing</em><br>For.</h1>
      <p class="cof-hero-sub">Single-origin. Transparently sourced. Obsessively brewed.</p>
      <p class="cof-hero-desc">We travel to the farms, taste alongside the farmers and roast with intention. Every cup is a story — and we'll tell you all of it.</p>
      <div class="cof-hero-ctas">
        <a href="#menu" class="cof-btn-primary">See Our Menu ☕</a>
        <a href="#origins" class="cof-btn-ghost">Our Origins</a>
      </div>
    </div>

    <!-- Origins strip at bottom -->
    <div class="cof-hero-origins">
      <div class="cof-origin-tag">
        <span class="cof-origin-flag">🇪🇹</span>
        <div><div class="cof-origin-name">Ethiopia</div><div class="cof-origin-note">Yirgacheffe · Natural</div></div>
      </div>
      <div class="cof-origin-tag">
        <span class="cof-origin-flag">🇨🇴</span>
        <div><div class="cof-origin-name">Colombia</div><div class="cof-origin-note">Huila · Washed</div></div>
      </div>
      <div class="cof-origin-tag">
        <span class="cof-origin-flag">🇰🇪</span>
        <div><div class="cof-origin-name">Kenya</div><div class="cof-origin-note">Nyeri · Washed</div></div>
      </div>
      <div class="cof-origin-tag">
        <span class="cof-origin-flag">🇬🇹</span>
        <div><div class="cof-origin-name">Guatemala</div><div class="cof-origin-note">Antigua · Honey</div></div>
      </div>
    </div>
  </section>

  <!-- ═══ MENU ═══════════════════════════════════════════════════ -->
  <section id="menu" class="cof-menu-section cof-section-full">
    <div class="cof-section" style="padding-bottom:0">
      <div class="cof-section-label cof-reveal">
        <div class="cof-label-dot"></div>
        <span class="cof-label-text">What We Serve</span>
      </div>
      <h2 class="cof-section-title cof-reveal">Our <em>Menu</em></h2>
      <p class="cof-section-intro cof-reveal">Everything on our menu is made with the same intention: the best possible version of each drink, using the best possible ingredients.</p>
    </div>
    <div class="cof-section">
      <div class="cof-menu-tabs">
        <?php foreach (array_keys($cof_menu) as $ti => $tab_name): ?>
        <button class="cof-menu-tab <?= $ti === 0 ? 'active' : '' ?>" data-tab="<?= esc_attr($tab_name) ?>">
          <?= esc_html($tab_name) ?>
        </button>
        <?php endforeach; ?>
      </div>
      <?php foreach ($cof_menu as $tab_name => $items): ?>
      <div class="cof-menu-panel <?= array_keys($cof_menu)[0] === $tab_name ? 'active' : '' ?>" data-panel="<?= esc_attr($tab_name) ?>">
        <?php foreach ($items as $item): ?>
        <div class="cof-menu-item">
          <div class="cof-menu-item-info">
            <div class="cof-menu-item-name"><?= esc_html($item['name']) ?></div>
            <div class="cof-menu-item-desc"><?= esc_html($item['desc']) ?></div>
          </div>
          <div class="cof-menu-price"><?= esc_html($item['price']) ?></div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- ═══ ORIGINS ═══════════════════════════════════════════════ -->
  <section id="origins" class="cof-section-full">
    <div class="cof-section" style="background:var(--cof-roast);padding-bottom:0;max-width:100%">
      <div class="cof-section-label cof-reveal">
        <div class="cof-label-dot" style="background:var(--cof-caramel)"></div>
        <span class="cof-label-text">Where We Source</span>
      </div>
      <h2 class="cof-section-title cof-reveal" style="color:var(--cof-cream)">Our <em>Origins</em></h2>
      <p class="cof-section-intro cof-reveal" style="color:rgba(245,237,224,0.65)">We visit every farm we buy from. The cup in your hand was grown by someone we've shaken hands with.</p>
    </div>
    <div class="cof-origins-grid">
      <?php foreach ($cof_origins as $oi => $origin): ?>
      <div class="cof-origin-card cof-reveal" data-country="<?= esc_attr(substr($origin['country'],0,2)) ?>" style="transition-delay:<?= $oi * 0.1 ?>s">
        <div class="cof-origin-card-country"><?= esc_html($origin['country']) ?></div>
        <div class="cof-origin-card-region"><?= esc_html($origin['region']) ?></div>
        <p class="cof-origin-card-notes"><?= esc_html($origin['notes']) ?></p>
        <div class="cof-origin-detail">
          <span class="cof-origin-badge"><?= esc_html($origin['process']) ?></span>
          <span class="cof-origin-badge"><?= esc_html($origin['altitude']) ?></span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- ═══ BREW METHODS ══════════════════════════════════════════ -->
  <section class="cof-methods-section cof-section-full">
    <div class="cof-section" style="padding-bottom:0">
      <div class="cof-section-label cof-reveal">
        <div class="cof-label-dot"></div>
        <span class="cof-label-text">Craft & Technique</span>
      </div>
      <h2 class="cof-section-title cof-reveal">How We <em>Brew</em></h2>
      <p class="cof-section-intro cof-reveal">Extraction ratios, water temperature, grind size — the details matter. Here's why we brew the way we do.</p>
    </div>
    <div class="cof-section">
      <div class="cof-methods-grid">
        <?php foreach ($cof_methods as $mi => $method): ?>
        <div class="cof-method-card cof-reveal" style="transition-delay:<?= $mi * 0.1 ?>s">
          <span class="cof-method-icon"><?= $method['icon'] ?></span>
          <div class="cof-method-name"><?= esc_html($method['name']) ?></div>
          <p class="cof-method-desc"><?= esc_html($method['desc']) ?></p>
          <span class="cof-method-ratio">Ratio <?= esc_html($method['ratio']) ?></span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ═══ STATS ═════════════════════════════════════════════════ -->
  <section class="cof-stats-section">
    <div class="cof-stats-grid">
      <?php foreach ($cof_stats as $si => $stat): ?>
      <div class="cof-stat-item cof-reveal" style="transition-delay:<?= $si * 0.1 ?>s">
        <span class="cof-stat-val" data-target="<?= preg_replace('/[^0-9]/','',$stat['val']) ?>" data-suffix="<?= esc_attr(preg_replace('/[0-9]/','', $stat['val']) . $stat['suffix']) ?>">
          <?= esc_html($stat['val'] . $stat['suffix']) ?>
        </span>
        <span class="cof-stat-label"><?= esc_html($stat['label']) ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- ═══ EVENTS ════════════════════════════════════════════════ -->
  <section class="cof-events-section cof-section-full">
    <div class="cof-section" style="padding-bottom:0">
      <div class="cof-section-label cof-reveal">
        <div class="cof-label-dot"></div>
        <span class="cof-label-text">Workshops & Events</span>
      </div>
      <h2 class="cof-section-title cof-reveal">Learn to <em>Love Coffee</em> Better</h2>
      <p class="cof-section-intro cof-reveal">Hands-on sessions for curious coffee drinkers. Small groups, expert hosts, real equipment.</p>
    </div>
    <div class="cof-section">
      <div class="cof-events-grid">
        <?php foreach ($cof_events as $ei => $evt): ?>
        <div class="cof-event-card cof-reveal" style="transition-delay:<?= $ei * 0.1 ?>s">
          <a href="#contact" class="cof-event-book">Book</a>
          <div class="cof-event-day"><?= esc_html($evt['day']) ?></div>
          <div class="cof-event-title"><?= esc_html($evt['title']) ?></div>
          <div class="cof-event-details">
            <div class="cof-event-detail">🕐 <?= esc_html($evt['time']) ?></div>
            <div class="cof-event-detail">👥 <?= esc_html($evt['spots']) ?></div>
          </div>
          <div class="cof-event-price"><?= esc_html($evt['price']) ?><span>per person</span></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ═══ TEAM ══════════════════════════════════════════════════ -->
  <section class="cof-team-section cof-section-full">
    <div class="cof-section" style="padding-bottom:0">
      <div class="cof-section-label cof-reveal">
        <div class="cof-label-dot"></div>
        <span class="cof-label-text">The People</span>
      </div>
      <h2 class="cof-section-title cof-reveal">The Crew Behind <em>Every Cup</em></h2>
    </div>
    <div class="cof-section">
      <div class="cof-team-grid">
        <?php foreach ($cof_team as $ti2 => $member): ?>
        <div class="cof-team-card cof-reveal" style="transition-delay:<?= $ti2 * 0.1 ?>s">
          <div class="cof-team-portrait">
            <div class="cof-tp-bg" style="background:<?= esc_attr($member['color']) ?>;"></div>
            <div class="cof-tp-head"></div>
            <div class="cof-tp-body" style="background:<?= esc_attr($member['color']) ?>;"></div>
            <div class="cof-tp-apron"></div>
          </div>
          <div class="cof-team-name"><?= esc_html($member['name']) ?></div>
          <div class="cof-team-role"><?= esc_html($member['role']) ?></div>
          <p class="cof-team-desc"><?= esc_html($member['desc']) ?></p>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ═══ TESTIMONIALS ══════════════════════════════════════════ -->
  <section class="cof-testi-section cof-section-full">
    <div class="cof-section" style="padding-bottom:0">
      <div class="cof-section-label cof-reveal">
        <div class="cof-label-dot"></div>
        <span class="cof-label-text">Our Regulars</span>
      </div>
      <h2 class="cof-section-title cof-reveal">What People <em>Say</em></h2>
    </div>
    <div class="cof-section">
      <div class="cof-testi-grid">
        <?php foreach ($cof_testimonials as $ti3 => $tm): ?>
        <div class="cof-testi-card cof-reveal" style="transition-delay:<?= $ti3 * 0.1 ?>s">
          <span class="cof-testi-stars">★★★★★</span>
          <p class="cof-testi-text"><?= esc_html($tm['quote']) ?></p>
          <div class="cof-testi-author"><?= esc_html($tm['author']) ?></div>
          <div class="cof-testi-tag"><?= esc_html($tm['tag']) ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ═══ FAQ ═══════════════════════════════════════════════════ -->
  <section class="cof-faq-section cof-section-full">
    <div class="cof-section">
      <div class="cof-section-label cof-reveal">
        <div class="cof-label-dot"></div>
        <span class="cof-label-text">Questions</span>
      </div>
      <h2 class="cof-section-title cof-reveal">Frequently Asked <em>Questions</em></h2>
      <div class="cof-faq-list" style="margin-top:40px">
        <?php foreach ($cof_faqs as $fi => $faq): ?>
        <div class="cof-faq-item cof-reveal" style="transition-delay:<?= $fi * 0.07 ?>s">
          <button class="cof-faq-trigger" aria-expanded="false">
            <span class="cof-faq-q"><?= esc_html($faq['q']) ?></span>
            <span class="cof-faq-icon" aria-hidden="true">+</span>
          </button>
          <div class="cof-faq-body">
            <div class="cof-faq-body-inner"><?= esc_html($faq['a']) ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ═══ VISIT / CONTACT ═══════════════════════════════════════ -->
  <section id="contact" class="cof-visit-section">
    <div class="cof-visit-inner">
      <div>
        <div class="cof-section-label cof-reveal" style="margin-bottom:16px">
          <div class="cof-label-dot" style="background:var(--cof-caramel)"></div>
          <span class="cof-label-text">Find Us</span>
        </div>
        <h2 class="cof-visit-title cof-reveal">Come In &amp; <em>Say Hello</em></h2>
        <p class="cof-visit-intro cof-reveal">The kettle's always on. Pull up a stool, ask our baristas anything and let us make you something worth stopping for.</p>
        <div class="cof-visit-info cof-reveal">
          <div class="cof-visit-info-row">
            <div class="cof-visit-info-icon">📍</div>
            <div class="cof-visit-info-text"><strong>Address</strong>14 Roastery Lane, Hackney, London E8 4PQ</div>
          </div>
          <div class="cof-visit-info-row">
            <div class="cof-visit-info-icon">🕐</div>
            <div class="cof-visit-info-text"><strong>Hours</strong>Mon–Fri: 7:30am – 5:30pm · Sat: 8am – 6pm · Sun: 9am – 4pm</div>
          </div>
          <div class="cof-visit-info-row">
            <div class="cof-visit-info-icon">📞</div>
            <div class="cof-visit-info-text"><strong>Phone</strong>+44 (0)20 8765 4321</div>
          </div>
          <div class="cof-visit-info-row">
            <div class="cof-visit-info-icon">📦</div>
            <div class="cof-visit-info-text"><strong>Wholesale & Subscriptions</strong>wholesale@groundworkcoffee.co.uk</div>
          </div>
        </div>
      </div>
      <div class="cof-reveal">
        <div class="cof-form" id="cof-form-wrap">
          <form id="cof-form" novalidate>
            <?php wp_nonce_field('tf_cof_enquiry', 'tf_cof_nonce'); ?>
            <div class="cof-form-row">
              <div class="cof-form-group">
                <label class="cof-form-label" for="cof-name">Your Name <span style="color:var(--cof-caramel)">*</span></label>
                <input type="text" id="cof-name" name="name" class="cof-form-control" placeholder="Rafael Moreno" required>
              </div>
              <div class="cof-form-group">
                <label class="cof-form-label" for="cof-email">Email <span style="color:var(--cof-caramel)">*</span></label>
                <input type="email" id="cof-email" name="email" class="cof-form-control" placeholder="you@email.com" required>
              </div>
            </div>
            <div class="cof-form-group">
              <label class="cof-form-label" for="cof-enquiry-type">Enquiry Type</label>
              <select id="cof-enquiry-type" name="enquiry_type" class="cof-form-control">
                <option value="">Select…</option>
                <option>Workshop booking</option>
                <option>Wholesale / trade enquiry</option>
                <option>Bean subscription</option>
                <option>Private event hire</option>
                <option>General question</option>
              </select>
            </div>
            <div class="cof-form-group">
              <label class="cof-form-label" for="cof-message">Message</label>
              <textarea id="cof-message" name="message" class="cof-form-control" placeholder="Tell us what you need…"></textarea>
            </div>
            <button type="submit" class="cof-form-submit">Send Message ☕</button>
          </form>
          <div class="cof-form-success" id="cof-form-success">
            <span class="cof-success-icon">☕</span>
            <p>Thanks — we'll be in touch shortly. In the meantime, come say hello.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

</div><!-- .cof-wrap -->

<script>
(function () {
  'use strict';

  /* ── Scroll Reveal ────────────────────────────────────────── */
  const rObs = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); rObs.unobserve(e.target); } });
  }, { threshold: 0.1 });
  document.querySelectorAll('.cof-reveal').forEach(el => rObs.observe(el));

  /* ── Counters ─────────────────────────────────────────────── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  const cObs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (!e.isIntersecting) return; cObs.unobserve(e.target);
      const el = e.target;
      const target = parseInt(el.dataset.target, 10);
      const suffix = el.dataset.suffix || '';
      const dur = 1800; const t0 = performance.now();
      (function tick(now) {
        const p = Math.min((now - t0) / dur, 1);
        el.textContent = Math.round(easeOut(p) * target) + suffix;
        if (p < 1) requestAnimationFrame(tick);
      })(t0);
    });
  }, { threshold: 0.5 });
  document.querySelectorAll('[data-target]').forEach(el => cObs.observe(el));

  /* ── Menu Tabs ────────────────────────────────────────────── */
  document.querySelectorAll('.cof-menu-tab').forEach(tab => {
    tab.addEventListener('click', function () {
      document.querySelectorAll('.cof-menu-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.cof-menu-panel').forEach(p => p.classList.remove('active'));
      this.classList.add('active');
      document.querySelector('[data-panel="' + this.dataset.tab + '"]').classList.add('active');
    });
  });

  /* ── FAQ Accordion ────────────────────────────────────────── */
  document.querySelectorAll('.cof-faq-trigger').forEach(btn => {
    btn.addEventListener('click', function () {
      const item = this.closest('.cof-faq-item');
      const body = item.querySelector('.cof-faq-body');
      const isOpen = item.classList.contains('open');
      document.querySelectorAll('.cof-faq-item').forEach(i => {
        i.classList.remove('open');
        i.querySelector('.cof-faq-trigger').setAttribute('aria-expanded','false');
        i.querySelector('.cof-faq-body').style.maxHeight = '0';
      });
      if (!isOpen) {
        item.classList.add('open');
        this.setAttribute('aria-expanded','true');
        body.style.maxHeight = body.scrollHeight + 'px';
      }
    });
  });

  /* ── Contact Form ─────────────────────────────────────────── */
  const form = document.getElementById('cof-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      const btn = this.querySelector('.cof-form-submit');
      btn.textContent = 'Sending…'; btn.disabled = true;
      setTimeout(() => {
        form.style.display = 'none';
        document.getElementById('cof-form-success').style.display = 'block';
      }, 900);
    });
  }
})();
</script>

<?php get_footer(); ?>
