<?php
/**
 * Template Name: ThemeFlex – Construction & Architecture Firm
 *
 * Premium single-file page template for a construction / architecture company.
 * Palette : Anthracite #1c1c1c · Safety yellow #f5a623 · Concrete #8a8a8a · White #ffffff
 * Fonts   : Rajdhani (headings) · DM Sans (body)
 * Namespace: --con-*
 *
 * @package ThemeFlex
 */

defined('ABSPATH') || exit;

/* ── PHP data ─────────────────────────────────────────────── */

$con_projects = [
  ['title'=>'Skyline Tower','cat'=>'hochbau','location'=>'Frankfurt','year'=>'2024','size'=>'42 Stockwerke','img_color'=>'#2a3a4a'],
  ['title'=>'Brücke A3 Sanierung','cat'=>'tiefbau','location'=>'Köln','year'=>'2023','size'=>'620m Spannbreite','img_color'=>'#3a3a2a'],
  ['title'=>'Wohnkomplex Mitte','cat'=>'wohnbau','location'=>'Berlin','year'=>'2024','size'=>'280 Einheiten','img_color'=>'#2a2a3a'],
  ['title'=>'Logistikzentrum Nord','cat'=>'gewerbebau','location'=>'Hamburg','year'=>'2023','size'=>'18.000 m²','img_color'=>'#3a2a2a'],
  ['title'=>'Stadthalle Renovierung','cat'=>'sanierung','location'=>'München','year'=>'2023','size'=>'Denkmalschutz','img_color'=>'#2a3a2a'],
  ['title'=>'Autobahn A7 Erweiterung','cat'=>'tiefbau','location'=>'Bayern','year'=>'2024','size'=>'34 km','img_color'=>'#3a3020'],
];

$con_cats = ['Alle','hochbau','tiefbau','wohnbau','gewerbebau','sanierung'];
$con_cat_labels = ['Alle'=>'Alle','hochbau'=>'Hochbau','tiefbau'=>'Tiefbau','wohnbau'=>'Wohnbau','gewerbebau'=>'Gewerbebau','sanierung'=>'Sanierung'];

$con_services = [
  ['icon'=>'🏗️','title'=>'Hochbau','desc'=>'Schlüsselfertige Gebäude von der Planung bis zur Übergabe — Bürotürme, Wohnanlagen, Industriebauten.'],
  ['icon'=>'🛣️','title'=>'Tiefbau','desc'=>'Straßen, Brücken, Tunnel und unterirdische Infrastruktur — zuverlässig und termingerecht.'],
  ['icon'=>'🔧','title'=>'Sanierung','desc'=>'Denkmalgerechte Restaurierung und energetische Modernisierung bestehender Gebäude.'],
  ['icon'=>'📐','title'=>'Architektur','desc'=>'Eigenes Planungsbüro für Entwurf, Genehmigung und Bauleitung — alles aus einer Hand.'],
  ['icon'=>'⚡','title'=>'TGA','desc'=>'Technische Gebäudeausrüstung: Elektro, Heizung, Lüftung und Sanitär nach neuesten Standards.'],
  ['icon'=>'🏠','title'=>'Schlüsselfertig','desc'=>'Komplettumsetzung inklusive Innenausbau — Sie erhalten den Schlüssel, wir erledigen alles andere.'],
];

$con_process = [
  ['num'=>'01','title'=>'Erstgespräch & Analyse','desc'=>'Wir verstehen Ihr Projekt, Ihre Ziele und Ihren Zeitrahmen in einem kostenlosen Beratungsgespräch.'],
  ['num'=>'02','title'=>'Planung & Kalkulation','desc'=>'Unser Architektenteam erstellt detaillierte Pläne, Ausführungszeichnungen und ein verbindliches Angebot.'],
  ['num'=>'03','title'=>'Genehmigung','desc'=>'Wir übernehmen alle behördlichen Abstimmungen und Genehmigungsverfahren eigenverantwortlich.'],
  ['num'=>'04','title'=>'Bauausführung','desc'=>'Professionelle Umsetzung mit eigenem Fachpersonal und geprüften Nachunternehmern unter straffer Bauleitung.'],
  ['num'=>'05','title'=>'Übergabe & Gewährleistung','desc'=>'Mangelfreie Abnahme und 5 Jahre Gewährleistung — Ihr Projekt in besten Händen, auch danach.'],
];

$con_team = [
  ['name'=>'Markus Baumann','title'=>'Geschäftsführer / Bauingenieur','exp'=>'22 Jahre','color'=>'#f5a623'],
  ['name'=>'Julia Kraft','title'=>'Leitende Architektin','exp'=>'14 Jahre','color'=>'#7a9e7e'],
  ['name'=>'Thomas Heck','title'=>'Projektleiter Tiefbau','exp'=>'18 Jahre','color'=>'#7a8e9e'],
  ['name'=>'Sandra Meier','title'=>'TGA-Planerin','exp'=>'11 Jahre','color'=>'#c4a0a0'],
];

srand(19);
// Building windows grid
$con_windows = [];
for ($f = 0; $f < 8; $f++) {
  $row = [];
  for ($w = 0; $w < 5; $w++) {
    $row[] = rand(0, 3) > 0; // 75% lit
  }
  $con_windows[] = $row;
}

// Crane arm segments
$con_crane_segments = 12;

// Ground rubble/debris elements
$con_rubble = [];
for ($r = 0; $r < 6; $r++) {
  $con_rubble[] = [
    'x'  => 5 + $r * 15 + rand(-4, 4),
    'w'  => 20 + rand(0, 24),
    'h'  => 6 + rand(0, 8),
  ];
}

?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;500;600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
/* ── Reset & tokens ───────────────────────────────────────── */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --con-black:#1c1c1c;
  --con-dark:#2a2a2a;
  --con-mid:#8a8a8a;
  --con-light:#c4c4c4;
  --con-white:#ffffff;
  --con-yellow:#f5a623;
  --con-yellow-d:#d08810;
  --con-concrete:#e8e4de;
  --con-concrete-d:#c8c4bc;
  --con-ff-head:'Rajdhani',system-ui,sans-serif;
  --con-ff-body:'DM Sans',system-ui,sans-serif;
  --con-r:6px;
  --con-r-lg:12px;
  --con-shadow:0 4px 24px rgba(0,0,0,.15);
  --con-shadow-lg:0 12px 48px rgba(0,0,0,.22);
}
html{scroll-behavior:smooth}
body{font-family:var(--con-ff-body);color:var(--con-black);background:var(--con-white);-webkit-font-smoothing:antialiased}
img{max-width:100%;height:auto;display:block}
a{color:inherit;text-decoration:none}
ul{list-style:none}
button{cursor:pointer;border:none;background:none;font-family:inherit}

/* ── Utility ──────────────────────────────────────────────── */
.con-container{max-width:1200px;margin:0 auto;padding:0 24px}
.con-section{padding:96px 0}
.con-label{font-size:.72rem;letter-spacing:.22em;text-transform:uppercase;color:var(--con-yellow);font-family:var(--con-ff-head);font-weight:700;margin-bottom:10px;display:block}
.con-h2{font-family:var(--con-ff-head);font-size:clamp(2.2rem,4.5vw,3.4rem);font-weight:700;line-height:1.08;text-transform:uppercase;letter-spacing:-.01em;color:var(--con-black)}
.con-h2 span{color:var(--con-yellow)}
.con-lead{font-size:1rem;color:var(--con-mid);max-width:540px;line-height:1.75;margin-top:16px}
.con-btn{display:inline-flex;align-items:center;gap:10px;padding:14px 32px;font-family:var(--con-ff-head);font-weight:700;font-size:1rem;letter-spacing:.05em;text-transform:uppercase;transition:all .25s}
.con-btn-yellow{background:var(--con-yellow);color:var(--con-black)}
.con-btn-yellow:hover{background:var(--con-yellow-d);transform:translateY(-2px)}
.con-btn-outline{border:2px solid var(--con-black);color:var(--con-black)}
.con-btn-outline:hover{background:var(--con-black);color:#fff}
.con-btn-white{background:#fff;color:var(--con-black)}
.con-btn-white:hover{background:var(--con-yellow);transform:translateY(-2px)}
.con-divider{width:56px;height:3px;background:var(--con-yellow);margin:16px 0 28px}
.con-reveal{opacity:0;transform:translateY(28px);transition:opacity .55s,transform .55s}
.con-reveal.visible{opacity:1;transform:none}

/* ── Nav ──────────────────────────────────────────────────── */
#con-nav{position:fixed;top:0;left:0;right:0;z-index:1000;background:rgba(28,28,28,.96);backdrop-filter:blur(8px);border-bottom:2px solid var(--con-yellow);padding:0}
.con-nav-inner{display:flex;align-items:center;justify-content:space-between;height:68px}
.con-logo{font-family:var(--con-ff-head);font-size:1.5rem;font-weight:700;color:#fff;letter-spacing:.04em;text-transform:uppercase}
.con-logo span{color:var(--con-yellow)}
.con-nav-links{display:flex;gap:8px;align-items:center}
.con-nav-links a{font-family:var(--con-ff-head);font-size:.85rem;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.65);padding:8px 16px;transition:color .2s}
.con-nav-links a:hover{color:#fff}
.con-nav-cta{background:var(--con-yellow)!important;color:var(--con-black)!important;padding:10px 22px!important;font-weight:700!important}
.con-nav-cta:hover{background:var(--con-yellow-d)!important}
.con-hamburger{display:none;flex-direction:column;gap:5px;padding:4px}
.con-hamburger span{width:24px;height:2px;background:#fff;display:block}
@media(max-width:768px){.con-nav-links{display:none}.con-hamburger{display:flex}}

/* ── Hero ─────────────────────────────────────────────────── */
#con-hero{min-height:100svh;background:var(--con-black);display:grid;grid-template-columns:1fr 1fr;align-items:center;gap:0;padding-top:68px;overflow:hidden;position:relative}
#con-hero::before{content:'';position:absolute;inset:0;background:repeating-linear-gradient(0deg,transparent,transparent 40px,rgba(255,255,255,.015) 40px,rgba(255,255,255,.015) 41px),repeating-linear-gradient(90deg,transparent,transparent 40px,rgba(255,255,255,.015) 40px,rgba(255,255,255,.015) 41px)}
.con-hero-text{padding:80px 60px;position:relative;z-index:1}
.con-hero-tag{display:inline-flex;align-items:center;gap:8px;background:var(--con-yellow);color:var(--con-black);font-family:var(--con-ff-head);font-weight:700;font-size:.75rem;letter-spacing:.18em;text-transform:uppercase;padding:6px 18px;margin-bottom:28px}
.con-hero-h1{font-family:var(--con-ff-head);font-size:clamp(3rem,6vw,5rem);font-weight:700;line-height:1;text-transform:uppercase;letter-spacing:-.02em;color:#fff;margin-bottom:24px}
.con-hero-h1 span{color:var(--con-yellow)}
.con-hero-sub{font-size:1rem;color:rgba(255,255,255,.55);line-height:1.75;max-width:420px;margin-bottom:40px}
.con-hero-actions{display:flex;gap:16px;flex-wrap:wrap}
.con-hero-facts{display:flex;gap:40px;margin-top:56px;flex-wrap:wrap}
.con-hero-fact{}
.con-hero-fact-val{font-family:var(--con-ff-head);font-size:2.4rem;font-weight:700;color:var(--con-yellow);line-height:1}
.con-hero-fact-lbl{font-size:.75rem;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.4);margin-top:4px}

/* ── CSS Building / Crane Scene ───────────────────────────── */
.con-scene{position:relative;height:100%;min-height:calc(100svh - 68px);display:flex;align-items:flex-end;justify-content:center;overflow:hidden}
.con-scene-sky{position:absolute;inset:0;background:linear-gradient(180deg,#0a0f1a 0%,#1a2540 40%,#2a3550 70%,#3a4060 100%)}
/* Stars */
.con-scene-sky::before{content:'';position:absolute;inset:0;background-image:
  radial-gradient(1px 1px at 10% 15%,rgba(255,255,255,.8),transparent),
  radial-gradient(1px 1px at 25% 8%,rgba(255,255,255,.6),transparent),
  radial-gradient(1px 1px at 40% 20%,rgba(255,255,255,.9),transparent),
  radial-gradient(1px 1px at 55% 5%,rgba(255,255,255,.7),transparent),
  radial-gradient(1px 1px at 70% 18%,rgba(255,255,255,.8),transparent),
  radial-gradient(1px 1px at 82% 12%,rgba(255,255,255,.5),transparent),
  radial-gradient(1.5px 1.5px at 18% 30%,rgba(255,255,255,.6),transparent),
  radial-gradient(1.5px 1.5px at 60% 35%,rgba(255,255,255,.4),transparent),
  radial-gradient(1px 1px at 90% 25%,rgba(255,255,255,.7),transparent)}
/* Moon */
.con-moon{position:absolute;top:8%;right:18%;width:52px;height:52px;border-radius:50%;background:radial-gradient(ellipse at 35% 35%,#fff5e0,#ffecc0 40%,#e8d890 80%,#c8b860);box-shadow:0 0 30px rgba(255,236,160,.3)}
.con-moon::before{content:'';position:absolute;top:8px;left:12px;width:36px;height:36px;border-radius:50%;background:rgba(0,0,0,.08)}
/* Ground */
.con-ground{position:absolute;bottom:0;left:0;right:0;height:40px;background:linear-gradient(180deg,#2a2a2a,#1a1a1a)}
/* Rubble */
.con-rubble-el{position:absolute;bottom:38px;background:linear-gradient(180deg,#4a4a4a,#3a3a3a);border-radius:2px}
/* Tower building */
.con-tower{position:absolute;bottom:40px;left:50%;transform:translateX(-65%);width:90px;display:flex;flex-direction:column;align-items:center}
.con-tower-body{width:90px;background:linear-gradient(90deg,#2a3545,#1e2a3a,#2a3545);position:relative}
.con-tower-top{width:90px;height:16px;background:linear-gradient(90deg,#2a3545,#1e2a3a);position:relative}
.con-tower-top::before{content:'';position:absolute;top:-8px;left:50%;transform:translateX(-50%);width:6px;height:8px;background:#3a4555}
.con-tower-top::after{content:'';position:absolute;top:-20px;left:50%;transform:translateX(-50%);width:2px;height:12px;background:var(--con-yellow);box-shadow:0 0 8px var(--con-yellow)}
/* Windows on tower */
.con-win-row{display:flex;gap:6px;margin-bottom:5px;justify-content:center}
.con-win{width:12px;height:14px;border-radius:1px}
.con-win.lit{background:rgba(255,220,100,.85);box-shadow:0 0 6px rgba(255,220,100,.4)}
.con-win.dark{background:rgba(30,40,60,.8);border:1px solid rgba(255,255,255,.05)}
/* Scaffold on right side */
.con-scaffold{position:absolute;bottom:40px;left:50%;transform:translateX(10%);width:14px;background:rgba(180,140,80,.6)}
.con-scaffold-bar{position:absolute;right:100%;width:40px;height:2px;background:rgba(180,140,80,.5)}
/* Crane */
.con-crane{position:absolute;bottom:40px;left:50%;transform:translateX(40%)}
.con-crane-mast{width:8px;background:repeating-linear-gradient(180deg,#f5a623 0px,#f5a623 12px,#1c1c1c 12px,#1c1c1c 14px);position:relative}
.con-crane-arm-h{position:absolute;top:0;left:50%;transform:translateX(-20%);height:5px;background:#f5a623;transform-origin:30% 50%}
.con-crane-arm-back{position:absolute;top:0;left:50%;height:5px;background:#d08810}
.con-crane-cabin{position:absolute;top:4px;left:50%;transform:translateX(-50%);width:18px;height:14px;background:linear-gradient(180deg,#f5a623,#d08810);border-radius:2px}
.con-crane-cable{position:absolute;top:5px;width:1.5px;background:rgba(255,255,255,.6);transform-origin:top center}
.con-crane-hook{position:absolute;width:10px;height:10px;border:2px solid rgba(255,255,255,.7);border-top:none;border-radius:0 0 6px 6px}
/* Smaller building left */
.con-bld-left{position:absolute;bottom:40px;left:8%;width:50px;background:linear-gradient(90deg,#232830,#1a2030);display:flex;flex-direction:column;align-items:center;padding-top:6px;gap:4px}
/* Foreground barrier */
.con-barrier{position:absolute;bottom:38px;width:100%;display:flex;gap:12px;padding:0 20px;align-items:flex-end}
.con-barrier-post{width:8px;background:repeating-linear-gradient(180deg,#f5a623 0px,#f5a623 8px,#1c1c1c 8px,#1c1c1c 16px);border-radius:2px}
.con-barrier-rail{flex:1;height:4px;background:#f5a623;margin-bottom:12px;border-radius:2px}
/* Safety light blink */
@keyframes con-blink{0%,100%{opacity:1}50%{opacity:.1}}
.con-safety-light{width:6px;height:6px;border-radius:50%;background:var(--con-yellow);animation:con-blink 1.4s step-start infinite;box-shadow:0 0 8px var(--con-yellow)}
@keyframes con-swing{
  0%,100%{transform:rotate(-4deg) translateX(-50%)}
  50%{transform:rotate(4deg) translateX(-50%)}
}

/* ── Yellow bar ───────────────────────────────────────────── */
.con-bar{background:var(--con-yellow);padding:20px 0}
.con-bar-inner{display:flex;align-items:center;gap:48px;overflow:hidden}
.con-bar-item{white-space:nowrap;font-family:var(--con-ff-head);font-weight:700;font-size:.95rem;letter-spacing:.08em;text-transform:uppercase;color:var(--con-black);display:flex;align-items:center;gap:12px;flex-shrink:0}
.con-bar-item::after{content:'▸';opacity:.4}
.con-bar-track{display:flex;width:max-content;animation:con-marquee 30s linear infinite}
@keyframes con-marquee{0%{transform:translateX(0)}100%{transform:translateX(-50%)}}

/* ── Services ─────────────────────────────────────────────── */
#con-services{background:var(--con-concrete)}
.con-services-header{max-width:640px;margin-bottom:64px}
.con-services-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:2px}
.con-svc{background:var(--con-white);padding:40px 36px;border-left:4px solid transparent;transition:all .25s;position:relative;overflow:hidden}
.con-svc::after{content:'';position:absolute;top:0;left:0;width:4px;height:0;background:var(--con-yellow);transition:height .3s}
.con-svc:hover::after{height:100%}
.con-svc:hover{transform:translateY(-4px);box-shadow:var(--con-shadow-lg)}
.con-svc-icon{font-size:2rem;margin-bottom:16px;display:block}
.con-svc-title{font-family:var(--con-ff-head);font-size:1.4rem;font-weight:700;text-transform:uppercase;margin-bottom:10px}
.con-svc-desc{font-size:.88rem;color:var(--con-mid);line-height:1.7}

/* ── Projects ─────────────────────────────────────────────── */
#con-projects{background:var(--con-white)}
.con-projects-header{display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:48px;gap:24px;flex-wrap:wrap}
.con-proj-filter{display:flex;gap:8px;flex-wrap:wrap}
.con-proj-btn{padding:8px 20px;border:2px solid var(--con-concrete-d);font-family:var(--con-ff-head);font-weight:700;font-size:.82rem;letter-spacing:.1em;text-transform:uppercase;color:var(--con-mid);background:transparent;transition:all .2s;cursor:pointer}
.con-proj-btn.active,.con-proj-btn:hover{background:var(--con-black);border-color:var(--con-black);color:#fff}
.con-projects-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
.con-project{position:relative;border-radius:var(--con-r);overflow:hidden;cursor:pointer;transition:transform .3s}
.con-project:hover{transform:scale(1.02)}
.con-project.hidden{display:none}
.con-proj-img{height:240px;display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden}
.con-proj-overlay{position:absolute;inset:0;background:linear-gradient(180deg,transparent 30%,rgba(0,0,0,.85))}
.con-proj-icon{font-size:3rem;z-index:1;position:relative}
/* CSS building silhouette per project */
.con-proj-building{position:absolute;bottom:0;left:50%;transform:translateX(-50%);display:flex;align-items:flex-end;gap:3px}
.con-proj-bld-el{background:rgba(255,255,255,.12);border-radius:2px 2px 0 0}
.con-proj-info{position:absolute;bottom:0;left:0;right:0;padding:20px;color:#fff;z-index:2}
.con-proj-title{font-family:var(--con-ff-head);font-size:1.25rem;font-weight:700;text-transform:uppercase;margin-bottom:4px}
.con-proj-meta{font-size:.78rem;color:rgba(255,255,255,.65);display:flex;gap:12px}
.con-proj-tag{background:var(--con-yellow);color:var(--con-black);font-family:var(--con-ff-head);font-weight:700;font-size:.68rem;letter-spacing:.12em;text-transform:uppercase;padding:3px 10px;position:absolute;top:16px;left:16px;z-index:2}

/* ── Process ──────────────────────────────────────────────── */
#con-process{background:var(--con-black)}
.con-process-header{text-align:center;margin-bottom:72px}
.con-process-header .con-h2{color:#fff}
.con-process-header .con-divider{margin:16px auto 0}
.con-process-steps{display:grid;grid-template-columns:repeat(5,1fr);gap:0;position:relative}
.con-process-steps::before{content:'';position:absolute;top:36px;left:10%;right:10%;height:2px;background:linear-gradient(90deg,var(--con-yellow),rgba(245,166,35,.3))}
.con-step{text-align:center;padding:0 16px;position:relative}
.con-step-num{width:72px;height:72px;border-radius:50%;background:var(--con-yellow);display:flex;align-items:center;justify-content:center;font-family:var(--con-ff-head);font-size:1.4rem;font-weight:700;color:var(--con-black);margin:0 auto 24px;position:relative;z-index:1}
.con-step-title{font-family:var(--con-ff-head);font-size:1rem;font-weight:700;text-transform:uppercase;color:#fff;margin-bottom:10px;letter-spacing:.04em}
.con-step-desc{font-size:.82rem;color:rgba(255,255,255,.45);line-height:1.65}

/* ── Stats ────────────────────────────────────────────────── */
.con-stats{background:var(--con-yellow);padding:60px 0}
.con-stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:24px;text-align:center}
.con-stat-val{font-family:var(--con-ff-head);font-size:3.4rem;font-weight:700;color:var(--con-black);line-height:1;margin-bottom:6px}
.con-stat-lbl{font-size:.75rem;letter-spacing:.14em;text-transform:uppercase;color:rgba(28,28,28,.6);font-weight:700}

/* ── Team ─────────────────────────────────────────────────── */
#con-team{background:var(--con-concrete)}
.con-team-header{max-width:580px;margin-bottom:56px}
.con-team-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:24px}
.con-member{background:var(--con-white);border-radius:var(--con-r);overflow:hidden;transition:transform .3s;box-shadow:var(--con-shadow)}
.con-member:hover{transform:translateY(-6px)}
.con-member-portrait{height:180px;position:relative;overflow:hidden;display:flex;align-items:flex-end;justify-content:center}
/* CSS portrait figure */
.con-fig{position:relative;display:flex;flex-direction:column;align-items:center;margin-bottom:8px}
.con-fig-head{width:52px;height:60px;border-radius:50% 50% 42% 42% / 52% 52% 48% 48%;background:linear-gradient(180deg,#f5d5b5,#ecc59a);position:relative;margin-bottom:-4px}
.con-fig-hair{position:absolute;top:0;left:50%;transform:translateX(-50%);width:56px;height:28px;border-radius:50% 50% 0 0}
.con-fig-face-eyes{position:absolute;top:22px;left:50%;transform:translateX(-50%);display:flex;gap:12px}
.con-fig-eye{width:4px;height:4px;background:#3a2818;border-radius:50%}
.con-fig-suit{width:70px;height:60px;border-radius:4px 4px 0 0;position:relative;overflow:hidden}
.con-fig-suit::before{content:'';position:absolute;top:0;left:50%;transform:translateX(-50%);width:10px;height:60px;background:rgba(255,255,255,.15)}
.con-fig-hard-hat{position:absolute;top:-8px;left:50%;transform:translateX(-50%);width:44px;height:14px;border-radius:14px 14px 0 0}
.con-fig-hard-hat::after{content:'';position:absolute;bottom:-2px;left:-4px;right:-4px;height:4px;border-radius:2px;background:inherit;filter:brightness(.85)}
.con-member-info{padding:20px}
.con-member-name{font-family:var(--con-ff-head);font-size:1.05rem;font-weight:700;text-transform:uppercase;margin-bottom:3px;letter-spacing:.03em}
.con-member-title{font-size:.78rem;color:var(--con-mid);margin-bottom:8px}
.con-member-exp{display:inline-block;background:var(--con-concrete);font-size:.72rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--con-black);padding:4px 10px}

/* ── Certifications ───────────────────────────────────────── */
.con-certs{background:var(--con-white);padding:56px 0}
.con-certs-inner{display:flex;align-items:center;gap:48px;flex-wrap:wrap;justify-content:center}
.con-cert{display:flex;align-items:center;gap:14px;padding:16px 28px;border:2px solid var(--con-concrete-d);border-radius:var(--con-r);transition:border-color .2s}
.con-cert:hover{border-color:var(--con-yellow)}
.con-cert-icon{font-size:1.8rem}
.con-cert-text{font-family:var(--con-ff-head);font-weight:700;font-size:.85rem;text-transform:uppercase;letter-spacing:.06em;line-height:1.3}
.con-cert-text small{display:block;font-weight:400;text-transform:none;letter-spacing:0;color:var(--con-mid);font-size:.75rem}

/* ── Contact ──────────────────────────────────────────────── */
#con-contact{background:var(--con-black);padding:96px 0}
.con-contact-wrap{display:grid;grid-template-columns:1fr 1fr;gap:80px;align-items:start}
.con-contact-left .con-h2{color:#fff}
.con-contact-left .con-lead{color:rgba(255,255,255,.5)}
.con-contact-detail{margin-top:40px;display:flex;flex-direction:column;gap:20px}
.con-detail-row{display:flex;gap:16px;align-items:flex-start}
.con-detail-icon{width:40px;height:40px;background:var(--con-yellow);display:flex;align-items:center;justify-content:center;font-size:1rem;flex-shrink:0}
.con-detail-text strong{display:block;font-family:var(--con-ff-head);font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#fff;margin-bottom:2px;font-size:.85rem}
.con-detail-text span{font-size:.88rem;color:rgba(255,255,255,.5)}
/* Form */
.con-form{background:#fff}
.con-form-inner{padding:44px}
.con-form h3{font-family:var(--con-ff-head);font-size:1.8rem;font-weight:700;text-transform:uppercase;margin-bottom:4px}
.con-form-sub{font-size:.85rem;color:var(--con-mid);margin-bottom:32px}
.con-form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.con-field{margin-bottom:18px}
.con-field label{display:block;font-size:.72rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--con-mid);margin-bottom:6px}
.con-field input,.con-field select,.con-field textarea{width:100%;padding:12px 16px;border:2px solid var(--con-concrete-d);font-family:var(--con-ff-body);font-size:.92rem;color:var(--con-black);background:var(--con-concrete);outline:none;transition:border .2s}
.con-field input:focus,.con-field select:focus,.con-field textarea:focus{border-color:var(--con-yellow);background:#fff}
.con-field textarea{resize:vertical;min-height:100px}
.con-form-submit{width:100%;padding:16px;background:var(--con-yellow);color:var(--con-black);font-family:var(--con-ff-head);font-size:1.1rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;cursor:pointer;border:none;transition:all .25s}
.con-form-submit:hover{background:var(--con-yellow-d);transform:translateY(-2px)}

/* ── Footer ───────────────────────────────────────────────── */
#con-footer{background:#111;padding:64px 0 28px}
.con-footer-top{display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:48px;margin-bottom:48px}
.con-footer-brand{font-family:var(--con-ff-head);font-size:1.6rem;font-weight:700;color:#fff;text-transform:uppercase;margin-bottom:12px}
.con-footer-brand span{color:var(--con-yellow)}
.con-footer-tagline{font-size:.85rem;color:rgba(255,255,255,.35);line-height:1.75;margin-bottom:20px}
.con-footer-cert-strip{display:flex;gap:8px;flex-wrap:wrap}
.con-footer-cert-badge{background:rgba(245,166,35,.12);border:1px solid rgba(245,166,35,.25);color:var(--con-yellow);font-size:.68rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;padding:4px 10px}
.con-footer-col h4{font-size:.72rem;letter-spacing:.18em;text-transform:uppercase;color:rgba(255,255,255,.3);font-weight:700;margin-bottom:16px}
.con-footer-col a,.con-footer-col p{display:block;font-size:.85rem;color:rgba(255,255,255,.45);margin-bottom:10px;transition:color .2s;line-height:1.5}
.con-footer-col a:hover{color:var(--con-yellow)}
.con-footer-bottom{border-top:1px solid rgba(255,255,255,.08);padding-top:24px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;font-size:.75rem;color:rgba(255,255,255,.25)}
.con-footer-bottom a{color:rgba(255,255,255,.35);transition:color .2s}
.con-footer-bottom a:hover{color:var(--con-yellow)}

/* ── Responsive ───────────────────────────────────────────── */
@media(max-width:1024px){
  #con-hero{grid-template-columns:1fr;min-height:auto}
  .con-scene{height:360px;min-height:360px}
  .con-process-steps{grid-template-columns:1fr;gap:32px}
  .con-process-steps::before{display:none}
  .con-step{text-align:left;display:flex;gap:20px;align-items:flex-start}
  .con-step-num{margin:0;flex-shrink:0}
  .con-team-grid{grid-template-columns:repeat(2,1fr)}
  .con-stats-grid{grid-template-columns:repeat(2,1fr)}
  .con-contact-wrap{grid-template-columns:1fr}
  .con-footer-top{grid-template-columns:1fr 1fr}
  .con-services-grid{grid-template-columns:repeat(2,1fr)}
}
@media(max-width:640px){
  .con-hero-text{padding:48px 24px}
  .con-projects-grid{grid-template-columns:1fr}
  .con-team-grid{grid-template-columns:1fr 1fr}
  .con-stats-grid{grid-template-columns:1fr 1fr}
  .con-footer-top{grid-template-columns:1fr}
  .con-form-row{grid-template-columns:1fr}
  .con-services-grid{grid-template-columns:1fr}
}
</style>
<?php get_header(); ?>
<div class="con-page">

<!-- ── Nav ──────────────────────────────────────────────────── -->
<nav id="con-nav" role="navigation" aria-label="Hauptnavigation">
  <div class="con-container">
    <div class="con-nav-inner">
      <a href="#" class="con-logo">Bau<span>Meister</span></a>
      <ul class="con-nav-links" role="list">
        <li><a href="#con-services">Leistungen</a></li>
        <li><a href="#con-projects">Projekte</a></li>
        <li><a href="#con-process">Ablauf</a></li>
        <li><a href="#con-team">Team</a></li>
        <li><a href="#con-contact" class="con-nav-cta">Angebot anfragen</a></li>
      </ul>
      <button class="con-hamburger" aria-label="Menü" aria-expanded="false">
        <span></span><span></span><span></span>
      </button>
    </div>
  </div>
</nav>

<!-- ── Hero ─────────────────────────────────────────────────── -->
<section id="con-hero" aria-label="Hero">
  <div class="con-hero-text">
    <div class="con-hero-tag">🏗 Seit 1998 · Zertifizierter Fachbetrieb</div>
    <h1 class="con-hero-h1">Wir bauen<br><span>Zukunft.</span><br>Stein für<br>Stein.</h1>
    <p class="con-hero-sub">Über 25 Jahre Erfahrung im Hoch-, Tief- und Schlüsselfertigbau. Termintreu, transparent und mit eigenem Fachpersonal.</p>
    <div class="con-hero-actions">
      <a href="#con-contact" class="con-btn con-btn-yellow">Kostenlos anfragen →</a>
      <a href="#con-projects" class="con-btn con-btn-outline" style="color:#fff;border-color:rgba(255,255,255,.3)">Projekte ansehen</a>
    </div>
    <div class="con-hero-facts">
      <div class="con-hero-fact">
        <div class="con-hero-fact-val" data-target="25" data-suffix="+">0</div>
        <div class="con-hero-fact-lbl">Jahre Erfahrung</div>
      </div>
      <div class="con-hero-fact">
        <div class="con-hero-fact-val" data-target="340" data-suffix="+">0</div>
        <div class="con-hero-fact-lbl">Projekte</div>
      </div>
      <div class="con-hero-fact">
        <div class="con-hero-fact-val" data-target="120" data-suffix="">0</div>
        <div class="con-hero-fact-lbl">Fachkräfte</div>
      </div>
    </div>
  </div>

  <!-- CSS Building / Night Scene -->
  <div class="con-scene" aria-hidden="true">
    <div class="con-scene-sky">
      <div class="con-moon"></div>
    </div>

    <!-- Rubble/ground elements -->
    <?php foreach ($con_rubble as $rb): ?>
    <div class="con-rubble-el" style="left:<?php echo $rb['x']; ?>%;width:<?php echo $rb['w']; ?>px;height:<?php echo $rb['h']; ?>px"></div>
    <?php endforeach; ?>

    <!-- Smaller building left -->
    <div class="con-bld-left" style="height:160px">
      <?php for ($r = 0; $r < 6; $r++): ?>
      <div class="con-win-row">
        <?php for ($w = 0; $w < 3; $w++): ?>
        <div class="con-win <?php echo (($r + $w) % 3 !== 0) ? 'lit' : 'dark'; ?>"></div>
        <?php endfor; ?>
      </div>
      <?php endfor; ?>
    </div>

    <!-- Main tower -->
    <div class="con-tower">
      <div class="con-tower-top">
        <div style="position:absolute;top:-30px;left:50%;transform:translateX(-50%)" class="con-safety-light"></div>
      </div>
      <div class="con-tower-body" style="height:320px;padding-top:10px">
        <?php foreach ($con_windows as $frow): ?>
        <div class="con-win-row">
          <?php foreach ($frow as $lit): ?>
          <div class="con-win <?php echo $lit ? 'lit' : 'dark'; ?>"></div>
          <?php endfor; ?>
        </div>
        <?php endfor; ?>
      </div>
    </div>

    <!-- Scaffold -->
    <div class="con-scaffold" style="height:200px">
      <?php for ($s = 0; $s < 5; $s++): ?>
      <div class="con-scaffold-bar" style="bottom:<?php echo 30 + $s * 38; ?>px"></div>
      <?php endfor; ?>
    </div>

    <!-- Crane -->
    <div class="con-crane">
      <div class="con-crane-mast" style="height:220px">
        <div class="con-crane-arm-h" style="width:130px;top:-5px"></div>
        <div class="con-crane-arm-back" style="width:40px;top:-5px;left:50%;transform-origin:left;transform:rotate(180deg)"></div>
        <div class="con-crane-cabin"></div>
        <div class="con-crane-cable" style="height:80px;left:4px;top:-5px;animation:con-swing 4s ease-in-out infinite">
          <div class="con-crane-hook" style="bottom:-10px;left:-4px"></div>
        </div>
      </div>
    </div>

    <!-- Safety barrier -->
    <div class="con-barrier" style="bottom:36px;position:absolute">
      <?php for ($b = 0; $b < 5; $b++): ?>
      <div class="con-barrier-post" style="height:<?php echo 28 + ($b % 2) * 4; ?>px"></div>
      <?php if ($b < 4): ?>
      <div class="con-barrier-rail"></div>
      <?php endif; ?>
      <?php endfor; ?>
    </div>

    <div class="con-ground"></div>
  </div>
</section>

<!-- ── Yellow bar ─────────────────────────────────────────── -->
<div class="con-bar" aria-hidden="true">
  <div class="con-container">
    <div class="con-bar-inner">
      <div class="con-bar-track">
        <?php
        $con_bar_items = ['Hochbau','Tiefbau','Schlüsselfertig','Sanierung','TGA','Architektur','Gewerbebau','Wohnbau','Brückenbau'];
        $bar_dup = array_merge($con_bar_items, $con_bar_items);
        foreach ($bar_dup as $bi): ?>
        <span class="con-bar-item"><?php echo esc_html($bi); ?></span>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<!-- ── Services ─────────────────────────────────────────────── -->
<section id="con-services" class="con-section">
  <div class="con-container">
    <div class="con-services-header con-reveal">
      <span class="con-label">Unsere Leistungen</span>
      <h2 class="con-h2">Alles aus <span>einer Hand</span></h2>
      <div class="con-divider"></div>
      <p class="con-lead">Von der Planung bis zur schlüsselfertigen Übergabe bieten wir das vollständige Leistungsspektrum moderner Bauunternehmen.</p>
    </div>
    <div class="con-services-grid">
      <?php foreach ($con_services as $idx => $svc): ?>
      <div class="con-svc con-reveal" style="transition-delay:<?php echo $idx * .08; ?>s">
        <span class="con-svc-icon"><?php echo $svc['icon']; ?></span>
        <h3 class="con-svc-title"><?php echo esc_html($svc['title']); ?></h3>
        <p class="con-svc-desc"><?php echo esc_html($svc['desc']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── Projects ──────────────────────────────────────────────── -->
<section id="con-projects" class="con-section">
  <div class="con-container">
    <div class="con-projects-header">
      <div class="con-reveal">
        <span class="con-label">Referenzprojekte</span>
        <h2 class="con-h2">Unsere <span>Projekte</span></h2>
        <div class="con-divider"></div>
      </div>
      <div class="con-proj-filter" role="group" aria-label="Projektfilter">
        <?php foreach ($con_cats as $cat): ?>
        <button class="con-proj-btn <?php echo $cat === 'Alle' ? 'active' : ''; ?>"
                data-cat="<?php echo esc_attr($cat); ?>"
                aria-pressed="<?php echo $cat === 'Alle' ? 'true' : 'false'; ?>">
          <?php echo esc_html($con_cat_labels[$cat]); ?>
        </button>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="con-projects-grid" id="con-projects-grid">
      <?php
      // building silhouette heights per project
      $con_bld_profiles = [
        [60,90,50,70,80,40],
        [40,55,80,45,70,35],
        [70,50,60,80,40,65],
        [45,80,55,70,50,75],
        [65,45,75,50,85,40],
        [50,70,40,80,55,65],
      ];
      foreach ($con_projects as $pi => $proj): ?>
      <article class="con-project con-reveal"
               data-cat="<?php echo esc_attr($proj['cat']); ?>"
               style="transition-delay:<?php echo $pi * .06; ?>s">
        <div class="con-proj-img" style="background:<?php echo esc_attr($proj['img_color']); ?>">
          <div class="con-proj-building">
            <?php foreach ($con_bld_profiles[$pi] as $bh): ?>
            <div class="con-proj-bld-el" style="width:14px;height:<?php echo $bh; ?>px"></div>
            <?php endforeach; ?>
          </div>
          <div class="con-proj-overlay"></div>
        </div>
        <div class="con-proj-tag"><?php echo esc_html($con_cat_labels[$proj['cat']]); ?></div>
        <div class="con-proj-info">
          <h3 class="con-proj-title"><?php echo esc_html($proj['title']); ?></h3>
          <div class="con-proj-meta">
            <span>📍 <?php echo esc_html($proj['location']); ?></span>
            <span>📅 <?php echo esc_html($proj['year']); ?></span>
            <span>📐 <?php echo esc_html($proj['size']); ?></span>
          </div>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── Process ───────────────────────────────────────────────── -->
<section id="con-process" class="con-section">
  <div class="con-container">
    <div class="con-process-header con-reveal">
      <span class="con-label" style="color:var(--con-yellow)">Unser Ablauf</span>
      <h2 class="con-h2">Von der Idee<br>zum <span>fertigen Bau</span></h2>
      <div class="con-divider"></div>
    </div>
    <div class="con-process-steps">
      <?php foreach ($con_process as $idx => $step): ?>
      <div class="con-step con-reveal" style="transition-delay:<?php echo $idx * .1; ?>s">
        <div class="con-step-num"><?php echo esc_html($step['num']); ?></div>
        <div>
          <h3 class="con-step-title"><?php echo esc_html($step['title']); ?></h3>
          <p class="con-step-desc"><?php echo esc_html($step['desc']); ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── Stats ─────────────────────────────────────────────────── -->
<div class="con-stats" aria-label="Kennzahlen">
  <div class="con-container">
    <div class="con-stats-grid">
      <div><div class="con-stat-val" data-target="25" data-suffix="+">0</div><div class="con-stat-lbl">Jahre Erfahrung</div></div>
      <div><div class="con-stat-val" data-target="340" data-suffix="+">0</div><div class="con-stat-lbl">Abgeschlossene Projekte</div></div>
      <div><div class="con-stat-val" data-target="120" data-suffix="">0</div><div class="con-stat-lbl">Fachkräfte im Team</div></div>
      <div><div class="con-stat-val" data-target="4" data-suffix=" Mrd.+">0</div><div class="con-stat-lbl">€ Bauvolumen</div></div>
    </div>
  </div>
</div>

<!-- ── Team ──────────────────────────────────────────────────── -->
<section id="con-team" class="con-section">
  <div class="con-container">
    <div class="con-team-header con-reveal">
      <span class="con-label">Unser Team</span>
      <h2 class="con-h2">Experten mit <span>Erfahrung</span></h2>
      <div class="con-divider"></div>
      <p class="con-lead">Qualifizierte Fachkräfte, moderne Maschinen und ein eingespieltes Team — das ist das Fundament unseres Erfolgs.</p>
    </div>
    <div class="con-team-grid">
      <?php foreach ($con_team as $idx => $member): ?>
      <div class="con-member con-reveal" style="transition-delay:<?php echo $idx * .1; ?>s">
        <div class="con-member-portrait" style="background:linear-gradient(180deg,<?php echo esc_attr($member['color']); ?>22,<?php echo esc_attr($member['color']); ?>11)">
          <div class="con-fig">
            <!-- Hard hat -->
            <div class="con-fig-hard-hat" style="background:<?php echo esc_attr($member['color']); ?>;width:48px;height:16px;border-radius:14px 14px 0 0;position:relative;top:8px;z-index:2"></div>
            <div class="con-fig-head">
              <div class="con-fig-face-eyes"><div class="con-fig-eye"></div><div class="con-fig-eye"></div></div>
            </div>
            <div class="con-fig-suit" style="background:linear-gradient(180deg,<?php echo esc_attr($member['color']); ?>88,<?php echo esc_attr($member['color']); ?>44)"></div>
          </div>
        </div>
        <div class="con-member-info">
          <h3 class="con-member-name"><?php echo esc_html($member['name']); ?></h3>
          <div class="con-member-title"><?php echo esc_html($member['title']); ?></div>
          <span class="con-member-exp"><?php echo esc_html($member['exp']); ?> Erfahrung</span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── Certifications ─────────────────────────────────────────── -->
<div class="con-certs">
  <div class="con-container">
    <div class="con-certs-inner">
      <?php
      $con_certs = [
        ['🏅','ISO 9001','Qualitätsmanagement'],
        ['🔒','ISO 14001','Umweltmanagement'],
        ['⚡','DGNB','Nachhaltigkeitsnachweis'],
        ['🏗️','SiGeKo','Sicherheitskoordination'],
        ['📜','Meisterbetrieb','Handwerkskammer'],
      ];
      foreach ($con_certs as $cert): ?>
      <div class="con-cert">
        <span class="con-cert-icon"><?php echo $cert[0]; ?></span>
        <div class="con-cert-text">
          <?php echo esc_html($cert[1]); ?>
          <small><?php echo esc_html($cert[2]); ?></small>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- ── Contact ───────────────────────────────────────────────── -->
<section id="con-contact">
  <div class="con-container">
    <div class="con-contact-wrap">
      <div class="con-contact-left con-reveal">
        <span class="con-label">Kontakt</span>
        <h2 class="con-h2" style="color:#fff">Starten Sie Ihr<br><span>Projekt</span> jetzt</h2>
        <div class="con-divider"></div>
        <p class="con-lead">Ob Neubau, Sanierung oder Ausbau — wir erstellen Ihnen ein unverbindliches Angebot innerhalb von 48 Stunden.</p>
        <div class="con-contact-detail">
          <div class="con-detail-row">
            <div class="con-detail-icon">📞</div>
            <div class="con-detail-text">
              <strong>Telefon</strong>
              <span>+49 30 9876 5432</span>
            </div>
          </div>
          <div class="con-detail-row">
            <div class="con-detail-icon">📧</div>
            <div class="con-detail-text">
              <strong>E-Mail</strong>
              <span>anfrage@baumeister-gmbh.de</span>
            </div>
          </div>
          <div class="con-detail-row">
            <div class="con-detail-icon">📍</div>
            <div class="con-detail-text">
              <strong>Büro</strong>
              <span>Industriestraße 42, 10317 Berlin</span>
            </div>
          </div>
          <div class="con-detail-row">
            <div class="con-detail-icon">🕐</div>
            <div class="con-detail-text">
              <strong>Bürozeiten</strong>
              <span>Mo–Fr: 7:00–18:00 Uhr</span>
            </div>
          </div>
        </div>
      </div>

      <div class="con-form con-reveal" style="transition-delay:.15s">
        <div class="con-form-inner">
          <h3>Angebot anfragen</h3>
          <p class="con-form-sub">Kostenlos und unverbindlich — Antwort in 48 h.</p>
          <form method="post" action="" novalidate>
            <?php wp_nonce_field('tf_con_contact', 'tf_con_nonce'); ?>
            <div class="con-form-row">
              <div class="con-field">
                <label for="con-fname">Vorname</label>
                <input type="text" id="con-fname" name="con_fname" autocomplete="given-name" required>
              </div>
              <div class="con-field">
                <label for="con-lname">Nachname</label>
                <input type="text" id="con-lname" name="con_lname" autocomplete="family-name" required>
              </div>
            </div>
            <div class="con-form-row">
              <div class="con-field">
                <label for="con-email">E-Mail</label>
                <input type="email" id="con-email" name="con_email" autocomplete="email" required>
              </div>
              <div class="con-field">
                <label for="con-phone">Telefon</label>
                <input type="tel" id="con-phone" name="con_phone" autocomplete="tel">
              </div>
            </div>
            <div class="con-field">
              <label for="con-company">Unternehmen / Auftraggeber</label>
              <input type="text" id="con-company" name="con_company" autocomplete="organization">
            </div>
            <div class="con-field">
              <label for="con-type">Leistungsbereich</label>
              <select id="con-type" name="con_type">
                <option value="">Bitte wählen …</option>
                <?php foreach ($con_services as $svc): ?>
                <option value="<?php echo esc_attr($svc['title']); ?>"><?php echo esc_html($svc['title']); ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="con-field">
              <label for="con-budget">Geschätztes Budget</label>
              <select id="con-budget" name="con_budget">
                <option value="">Bitte wählen …</option>
                <option>Unter 100.000 €</option>
                <option>100.000 – 500.000 €</option>
                <option>500.000 – 2 Mio. €</option>
                <option>2 – 10 Mio. €</option>
                <option>Über 10 Mio. €</option>
              </select>
            </div>
            <div class="con-field">
              <label for="con-msg">Projektbeschreibung</label>
              <textarea id="con-msg" name="con_msg" placeholder="Kurze Beschreibung Ihres Vorhabens, Standort, Zeitrahmen …" required></textarea>
            </div>
            <button type="submit" class="con-form-submit">Anfrage absenden ▸</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ── Footer ────────────────────────────────────────────────── -->
<footer id="con-footer" role="contentinfo">
  <div class="con-container">
    <div class="con-footer-top">
      <div>
        <div class="con-footer-brand">Bau<span>Meister</span></div>
        <p class="con-footer-tagline">Solide gebaut seit 1998. Ihr Partner für Hoch-, Tief- und Schlüsselfertigbau in ganz Deutschland.</p>
        <div class="con-footer-cert-strip">
          <span class="con-footer-cert-badge">ISO 9001</span>
          <span class="con-footer-cert-badge">ISO 14001</span>
          <span class="con-footer-cert-badge">DGNB</span>
          <span class="con-footer-cert-badge">Meisterbetrieb</span>
        </div>
      </div>
      <div class="con-footer-col">
        <h4>Leistungen</h4>
        <a href="#con-services">Hochbau</a>
        <a href="#con-services">Tiefbau</a>
        <a href="#con-services">Sanierung</a>
        <a href="#con-services">TGA</a>
        <a href="#con-services">Architektur</a>
      </div>
      <div class="con-footer-col">
        <h4>Unternehmen</h4>
        <a href="#">Über uns</a>
        <a href="#con-team">Team</a>
        <a href="#con-projects">Projekte</a>
        <a href="#">Karriere</a>
        <a href="#">Presse</a>
      </div>
      <div class="con-footer-col">
        <h4>Kontakt</h4>
        <p>Industriestraße 42<br>10317 Berlin</p>
        <p>+49 30 9876 5432</p>
        <p>anfrage@baumeister-gmbh.de</p>
        <p>Mo–Fr: 7–18 Uhr</p>
      </div>
    </div>
    <div class="con-footer-bottom">
      <span>© <?php echo date('Y'); ?> BauMeister GmbH</span>
      <span>
        <a href="/datenschutz">Datenschutz</a> ·
        <a href="/impressum">Impressum</a> ·
        <a href="/agb">AGB</a>
      </span>
    </div>
  </div>
</footer>

<script>
(function(){
  'use strict';

  /* Project filter */
  const projBtns = document.querySelectorAll('.con-proj-btn');
  const projItems = document.querySelectorAll('#con-projects-grid .con-project');
  projBtns.forEach(btn=>{
    btn.addEventListener('click',()=>{
      const cat = btn.dataset.cat;
      projBtns.forEach(b=>{
        const a = b===btn;
        b.classList.toggle('active',a);
        b.setAttribute('aria-pressed',a?'true':'false');
      });
      projItems.forEach(item=>{
        const match = cat==='Alle' || item.dataset.cat===cat;
        item.classList.toggle('hidden',!match);
      });
    });
  });

  /* IntersectionObserver scroll reveal */
  const reveals = document.querySelectorAll('.con-reveal');
  const io = new IntersectionObserver(entries=>{
    entries.forEach(e=>{
      if(e.isIntersecting){e.target.classList.add('visible');io.unobserve(e.target);}
    });
  },{threshold:.1});
  reveals.forEach(el=>io.observe(el));

  /* Counter animation */
  const easeOut = t=>1-Math.pow(1-t,3);
  document.querySelectorAll('[data-target]').forEach(el=>{
    const cio = new IntersectionObserver(entries=>{
      if(!entries[0].isIntersecting) return;
      const target = parseInt(el.dataset.target,10);
      const suffix = el.dataset.suffix||'';
      const dur = 1600;
      let start = null;
      function tick(ts){
        if(!start) start=ts;
        const prog = Math.min((ts-start)/dur,1);
        el.textContent = Math.round(easeOut(prog)*target) + suffix;
        if(prog<1) requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
      cio.unobserve(el);
    },{threshold:.4});
    cio.observe(el);
  });

  /* Form stub */
  document.querySelector('.con-form form')?.addEventListener('submit',e=>{
    e.preventDefault();
    const btn = e.target.querySelector('.con-form-submit');
    if(btn){btn.textContent='Anfrage gesendet ✓';btn.style.background='#2a6a2a';btn.style.color='#fff';}
  });

})();
</script>
</div><!-- .con-page -->
<?php get_footer(); ?>
