<?php
/**
 * Template Name: Business Consultant Homepage
 * Template Post Type: page
 *
 * Premium Business & Management Consulting template for ThemeFlex.
 * Namespace : --co-*
 * Fonts     : Libre Baskerville (headings) + Inter (body)
 * Palette   : Midnight #0F172A / Sapphire #1E40AF / Platinum #F8FAFC / Amber #F59E0B / Slate #64748B
 */
defined('ABSPATH') || exit;
get_header();
?>

<!-- ============================================================
     CONSULTANT PAGE — STYLES
     ============================================================ -->
<style>
@import url('https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&family=Inter:wght@300;400;500;600;700&display=swap');

/* ── Tokens ── */
:root{
  --co-midnight:#0F172A;
  --co-sapphire:#1E40AF;
  --co-saphire-light:#3B82F6;
  --co-platinum:#F8FAFC;
  --co-amber:#F59E0B;
  --co-amber-light:#FDE68A;
  --co-slate:#64748B;
  --co-slate-light:#CBD5E1;
  --co-white:#FFFFFF;
  --co-serif:'Libre Baskerville',Georgia,serif;
  --co-sans:'Inter',system-ui,sans-serif;
  --co-radius:6px;
  --co-shadow:0 4px 24px rgba(15,23,42,.12);
  --co-shadow-lg:0 12px 48px rgba(15,23,42,.18);
}

/* ── Reset ── */
.co-page *,
.co-page *::before,
.co-page *::after{box-sizing:border-box;margin:0;padding:0}
.co-page{font-family:var(--co-sans);color:var(--co-midnight);background:var(--co-platinum);line-height:1.6;overflow-x:hidden}
.co-page a{color:inherit;text-decoration:none}
.co-page img{max-width:100%;display:block}

/* ── Layout ── */
.co-wrap{max-width:1160px;margin:0 auto;padding:0 24px}
.co-section{padding:88px 0}
.co-section--dark{background:var(--co-midnight);color:var(--co-platinum)}
.co-section--mid{background:#1E293B;color:var(--co-platinum)}
.co-section--amber{background:linear-gradient(135deg,#FFFBEB 0%,#FEF3C7 100%)}

/* ── Typography ── */
.co-eyebrow{font-family:var(--co-sans);font-size:.75rem;font-weight:700;letter-spacing:.18em;text-transform:uppercase;color:var(--co-amber);margin-bottom:12px}
.co-section--dark .co-eyebrow,.co-section--mid .co-eyebrow{color:var(--co-amber)}
.co-h1{font-family:var(--co-serif);font-size:clamp(2.4rem,5vw,3.8rem);line-height:1.15;color:var(--co-white)}
.co-h2{font-family:var(--co-serif);font-size:clamp(1.8rem,3.5vw,2.8rem);line-height:1.2;color:var(--co-midnight)}
.co-section--dark .co-h2,.co-section--mid .co-h2{color:var(--co-white)}
.co-lead{font-size:1.125rem;color:var(--co-slate);max-width:680px;margin:0 auto}
.co-section--dark .co-lead,.co-section--mid .co-lead{color:var(--co-slate-light)}
.co-center{text-align:center}
.co-hgroup{margin-bottom:56px}

/* ── Buttons ── */
.co-btn{display:inline-flex;align-items:center;gap:8px;padding:14px 32px;border-radius:var(--co-radius);font-family:var(--co-sans);font-size:.95rem;font-weight:600;cursor:pointer;border:none;transition:all .25s}
.co-btn--primary{background:var(--co-sapphire);color:var(--co-white)}
.co-btn--primary:hover{background:#1D4ED8;transform:translateY(-2px);box-shadow:0 8px 24px rgba(30,64,175,.35)}
.co-btn--outline{background:transparent;color:var(--co-white);border:2px solid rgba(255,255,255,.5)}
.co-btn--outline:hover{border-color:var(--co-white);background:rgba(255,255,255,.08)}
.co-btn--amber{background:var(--co-amber);color:var(--co-midnight)}
.co-btn--amber:hover{background:#D97706;transform:translateY(-2px);box-shadow:0 8px 24px rgba(245,158,11,.35)}

/* ═══════════════════════════════════════════
   HERO
═══════════════════════════════════════════ */
.co-hero{
  position:relative;
  min-height:100vh;
  background:var(--co-midnight);
  display:flex;align-items:center;
  overflow:hidden;
  padding:80px 0 60px;
}

/* Grid background */
.co-hero__grid{
  position:absolute;inset:0;
  background-image:
    linear-gradient(rgba(59,130,246,.07) 1px,transparent 1px),
    linear-gradient(90deg,rgba(59,130,246,.07) 1px,transparent 1px);
  background-size:60px 60px;
  pointer-events:none;
}
.co-hero__grid::after{
  content:'';position:absolute;inset:0;
  background:radial-gradient(ellipse 60% 60% at 50% 50%,transparent 30%,var(--co-midnight) 80%);
}

/* Ambient glow */
.co-hero__glow{
  position:absolute;
  width:600px;height:600px;
  border-radius:50%;
  background:radial-gradient(circle,rgba(30,64,175,.25) 0%,transparent 70%);
  top:-150px;right:-100px;
  pointer-events:none;
}
.co-hero__glow2{
  position:absolute;
  width:400px;height:400px;
  border-radius:50%;
  background:radial-gradient(circle,rgba(245,158,11,.12) 0%,transparent 70%);
  bottom:-100px;left:-50px;
  pointer-events:none;
}

.co-hero__inner{
  position:relative;z-index:2;
  display:grid;
  grid-template-columns:1fr 480px;
  gap:64px;
  align-items:center;
  max-width:1160px;margin:0 auto;padding:0 24px;
}

/* ── Hero Copy ── */
.co-hero__badge{
  display:inline-flex;align-items:center;gap:8px;
  background:rgba(30,64,175,.25);border:1px solid rgba(59,130,246,.35);
  border-radius:24px;padding:6px 16px;
  font-size:.8rem;font-weight:600;color:var(--co-saphire-light);
  margin-bottom:28px;
}
.co-hero__badge::before{content:'';width:8px;height:8px;border-radius:50%;background:var(--co-saphire-light);animation:co-pulse 2s infinite}
@keyframes co-pulse{0%,100%{opacity:1}50%{opacity:.4}}

.co-hero__tagline{
  font-family:var(--co-sans);font-size:.85rem;font-weight:500;
  color:var(--co-amber);letter-spacing:.12em;text-transform:uppercase;
  margin-bottom:16px;
}
.co-h1 em{color:var(--co-amber);font-style:italic}
.co-hero__desc{
  font-size:1.05rem;color:rgba(248,250,252,.7);
  line-height:1.75;margin:24px 0 36px;max-width:520px;
}
.co-hero__ctas{display:flex;gap:16px;flex-wrap:wrap}

/* ── Hero Scene: Office ── */
.co-hero__scene{
  position:relative;
  width:480px;height:460px;
  flex-shrink:0;
}

/* Desk */
.co-desk{
  position:absolute;
  bottom:40px;left:50%;transform:translateX(-50%);
  width:340px;height:18px;
  background:linear-gradient(180deg,#4A3728 0%,#2D2118 100%);
  border-radius:4px 4px 0 0;
  box-shadow:0 4px 12px rgba(0,0,0,.5);
}
.co-desk::before{/* desk legs */
  content:'';position:absolute;
  bottom:-60px;left:20px;right:20px;height:60px;
  background:linear-gradient(180deg,#2D2118 0%,#1A120D 100%);
  clip-path:polygon(0 0,100% 0,90% 100%,10% 100%);
}

/* Monitor */
.co-monitor{
  position:absolute;
  bottom:58px;left:50%;transform:translateX(-50%);
  width:200px;height:130px;
  background:linear-gradient(160deg,#0F172A 0%,#1E293B 100%);
  border:3px solid #334155;border-radius:8px;
  box-shadow:0 0 30px rgba(59,130,246,.2),0 8px 24px rgba(0,0,0,.5);
  overflow:hidden;
}
/* Screen glow */
.co-monitor::before{
  content:'';position:absolute;inset:0;
  background:linear-gradient(135deg,rgba(30,64,175,.3) 0%,rgba(15,23,42,.8) 60%);
}
/* Screen data lines */
.co-monitor::after{
  content:'';position:absolute;
  top:16px;left:16px;right:16px;
  height:3px;
  background:rgba(59,130,246,.7);
  border-radius:2px;
  box-shadow:
    0 14px 0 rgba(245,158,11,.6),
    0 28px 0 rgba(59,130,246,.4),
    0 42px 0 rgba(100,116,139,.4),
    0 56px 0 rgba(245,158,11,.3),
    0 70px 0 rgba(59,130,246,.3);
}
/* Monitor stand */
.co-monitor-stand{
  position:absolute;
  bottom:46px;left:50%;transform:translateX(-50%);
  width:50px;height:14px;
  background:#1E293B;border-radius:0 0 4px 4px;
}
.co-monitor-base{
  position:absolute;
  bottom:56px;left:50%;transform:translateX(-50%);
  width:80px;height:6px;
  background:#334155;border-radius:3px;
}

/* Chart bars on screen */
.co-screen-bars{
  position:absolute;
  bottom:8px;left:16px;
  display:flex;align-items:flex-end;gap:5px;
}
.co-screen-bar{
  width:14px;
  background:rgba(59,130,246,.7);
  border-radius:2px 2px 0 0;
  animation:co-bar-grow 1.5s ease-out forwards;
}
@keyframes co-bar-grow{from{height:0}to{height:var(--co-bh)}}

/* Laptop */
.co-laptop{
  position:absolute;
  bottom:58px;right:40px;
  width:110px;
}
.co-laptop__lid{
  width:110px;height:70px;
  background:linear-gradient(160deg,#1E293B,#0F172A);
  border:2px solid #334155;border-radius:5px 5px 0 0;
  position:relative;overflow:hidden;
}
.co-laptop__lid::before{/* screen reflection */
  content:'';position:absolute;top:6px;left:6px;right:6px;bottom:6px;
  background:linear-gradient(135deg,rgba(30,64,175,.4),rgba(15,23,42,.9));
  border-radius:3px;
}
.co-laptop__lid::after{/* screen content glow */
  content:'';position:absolute;
  top:12px;left:12px;right:12px;height:2px;
  background:rgba(245,158,11,.6);
  box-shadow:0 8px 0 rgba(59,130,246,.5),0 18px 0 rgba(245,158,11,.4);
}
.co-laptop__base{
  width:110px;height:8px;
  background:linear-gradient(180deg,#334155,#1E293B);
  border-radius:0 0 4px 4px;
}

/* Coffee */
.co-coffee{
  position:absolute;
  bottom:60px;left:34px;
}
.co-coffee__cup{
  width:32px;height:36px;
  background:linear-gradient(180deg,#F8FAFC,#E2E8F0);
  border-radius:2px 2px 6px 6px;
  position:relative;
}
.co-coffee__cup::before{/* coffee liquid */
  content:'';position:absolute;
  top:8px;left:4px;right:4px;bottom:4px;
  background:#3D1A0A;
  border-radius:1px 1px 4px 4px;
}
.co-coffee__cup::after{/* handle */
  content:'';position:absolute;
  top:8px;right:-10px;
  width:10px;height:14px;
  border:3px solid #CBD5E1;
  border-left:none;
  border-radius:0 6px 6px 0;
}
.co-coffee__steam{
  position:absolute;
  top:-18px;left:8px;
  display:flex;gap:6px;
}
.co-coffee__steam span{
  width:3px;height:14px;
  background:rgba(248,250,252,.25);
  border-radius:3px;
  animation:co-steam .8s ease-in-out infinite alternate;
}
.co-coffee__steam span:nth-child(2){animation-delay:.2s}
.co-coffee__steam span:nth-child(3){animation-delay:.4s}
@keyframes co-steam{from{transform:translateY(0) scaleX(1)}to{transform:translateY(-6px) scaleX(.6);opacity:0}}

/* Document stack */
.co-docs{
  position:absolute;
  bottom:58px;left:66px;
  width:55px;
}
.co-doc{
  width:50px;height:64px;
  background:var(--co-platinum);
  border-radius:2px;
  position:absolute;
  box-shadow:2px 2px 6px rgba(0,0,0,.3);
}
.co-doc:nth-child(1){transform:rotate(-4deg);top:0;left:0;background:#EFF6FF}
.co-doc:nth-child(2){transform:rotate(2deg);top:0;left:2px;background:#FEF3C7}
.co-doc:nth-child(3){transform:rotate(0deg);top:0;left:4px;background:var(--co-platinum)}
.co-doc::before{
  content:'';position:absolute;
  top:10px;left:8px;right:8px;height:2px;
  background:#94A3B8;
  box-shadow:0 8px 0 #CBD5E1,0 16px 0 #CBD5E1,0 24px 0 #94A3B8,0 32px 0 #E2E8F0;
}

/* Pen */
.co-pen{
  position:absolute;
  bottom:62px;left:124px;
  width:4px;height:50px;
  background:linear-gradient(180deg,#1E40AF,#3B82F6,#1E40AF,#F8FAFC);
  border-radius:2px 2px 0 0;
  transform:rotate(15deg);
}
.co-pen::after{
  content:'';position:absolute;
  bottom:-4px;left:-1px;
  width:6px;height:8px;
  background:#C0C0C8;
  clip-path:polygon(0 0,100% 0,50% 100%);
}

/* CSS Consultant Figure */
.co-cfig{
  position:absolute;
  bottom:58px;right:130px;
}
.co-cfig__head{
  width:36px;height:38px;
  background:#D4A574;
  border-radius:50% 50% 45% 45%;
  position:relative;
  margin:0 auto;
}
.co-cfig__head::before{/* hair */
  content:'';position:absolute;
  top:-4px;left:-2px;right:-2px;height:16px;
  background:#1A0A00;
  border-radius:8px 8px 4px 4px;
}
.co-cfig__head::after{/* glasses */
  content:'';position:absolute;
  top:16px;left:4px;right:4px;height:6px;
  border:2px solid #1E293B;
  border-radius:2px;
}
.co-cfig__neck{
  width:10px;height:8px;
  background:#C8956B;
  margin:0 auto;
}
.co-cfig__body{
  width:50px;height:64px;
  background:linear-gradient(180deg,#1E3A8A,#1E40AF);/* navy suit */
  border-radius:6px 6px 2px 2px;
  position:relative;margin:0 auto;
}
.co-cfig__body::before{/* shirt / tie */
  content:'';position:absolute;
  top:0;left:50%;transform:translateX(-50%);
  width:14px;height:40px;
  background:linear-gradient(180deg,#F8FAFC 0%,#F8FAFC 20%,var(--co-amber) 20%,var(--co-amber) 100%);
  border-radius:0 0 3px 3px;
}
.co-cfig__body::after{/* suit lapels */
  content:'';position:absolute;
  top:0;left:4px;right:4px;height:24px;
  background:linear-gradient(135deg,#1E3A8A 45%,transparent 45%,transparent 55%,#1E3A8A 55%);
}
.co-cfig__arm-l{
  position:absolute;
  top:8px;left:-12px;
  width:10px;height:44px;
  background:#1E40AF;
  border-radius:5px;
  transform-origin:top center;
  transform:rotate(-15deg);
}
.co-cfig__arm-r{
  position:absolute;
  top:8px;right:-14px;
  width:10px;height:44px;
  background:#1E40AF;
  border-radius:5px;
  transform-origin:top center;
  transform:rotate(30deg);
  animation:co-pointer 3s ease-in-out infinite;
}
@keyframes co-pointer{0%,100%{transform:rotate(30deg)}50%{transform:rotate(20deg)}}
/* pointer hand */
.co-cfig__arm-r::after{
  content:'👉';
  position:absolute;bottom:-12px;left:-4px;
  font-size:16px;
  animation:co-pointer 3s ease-in-out infinite;
}
.co-cfig__legs{
  display:flex;gap:6px;justify-content:center;
}
.co-cfig__leg{
  width:16px;height:44px;
  background:#0F172A;/* dark trousers */
  border-radius:2px 2px 4px 4px;
  position:relative;
}
.co-cfig__leg::after{/* shoes */
  content:'';position:absolute;
  bottom:-6px;left:-3px;
  width:22px;height:8px;
  background:#0A0A0A;
  border-radius:2px 4px 4px 2px;
}

/* Whiteboard */
.co-whiteboard{
  position:absolute;
  top:30px;left:50%;transform:translateX(-50%);
  width:220px;height:130px;
  background:#F8FAFC;
  border:4px solid #334155;
  border-radius:4px;
  box-shadow:var(--co-shadow);
  overflow:hidden;
}
.co-whiteboard::before{/* frame top */
  content:'';position:absolute;
  top:-4px;left:-4px;right:-4px;height:16px;
  background:#334155;
}
/* Drawn chart on whiteboard */
.co-wb-chart{
  position:absolute;
  bottom:12px;left:12px;right:12px;top:20px;
}
.co-wb-bar{
  position:absolute;bottom:0;
  background:var(--co-sapphire);
  border-radius:2px 2px 0 0;
  opacity:.7;
}
.co-wb-line{
  position:absolute;
  top:4px;left:0;right:0;height:2px;
  background:var(--co-amber);opacity:.8;
  border-radius:1px;
}
.co-wb-arrow{
  position:absolute;
  top:12px;right:8px;
  font-size:18px;
}
/* Whiteboard stand */
.co-whiteboard-stand{
  position:absolute;
  top:168px;left:50%;transform:translateX(-50%);
  width:6px;height:40px;
  background:#334155;
}
.co-whiteboard-stand::before{
  content:'';position:absolute;
  bottom:0;left:-24px;right:-24px;height:6px;
  background:#334155;
  border-radius:3px;
}

/* Floating KPI badges */
.co-kpi-badge{
  position:absolute;
  background:rgba(30,64,175,.15);
  border:1px solid rgba(59,130,246,.3);
  backdrop-filter:blur(8px);
  border-radius:8px;
  padding:10px 14px;
  font-family:var(--co-sans);
  animation:co-float 4s ease-in-out infinite;
}
@keyframes co-float{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}
.co-kpi-badge__val{font-size:1.1rem;font-weight:700;color:var(--co-amber)}
.co-kpi-badge__lbl{font-size:.65rem;color:rgba(248,250,252,.6);margin-top:2px}
.co-kpi-badge:nth-child(1){top:30px;left:8px;animation-delay:.5s}
.co-kpi-badge:nth-child(2){top:100px;right:6px;animation-delay:1.2s}
.co-kpi-badge:nth-child(3){bottom:100px;left:14px;animation-delay:2s}

/* ── Hero Stats bar ── */
.co-hero__stats{
  position:relative;z-index:2;
  max-width:1160px;margin:48px auto 0;padding:0 24px;
  display:flex;gap:0;
}
.co-hero__stat{
  flex:1;text-align:center;
  padding:20px 16px;
  border-right:1px solid rgba(248,250,252,.1);
}
.co-hero__stat:last-child{border-right:none}
.co-hero__stat-val{
  font-family:var(--co-serif);font-size:2rem;font-weight:700;
  color:var(--co-amber);
  display:block;
}
.co-hero__stat-lbl{font-size:.8rem;color:rgba(248,250,252,.55);margin-top:4px}

/* ═══════════════════════════════════════════
   TRUST BAND
═══════════════════════════════════════════ */
.co-trust{
  background:var(--co-sapphire);
  padding:20px 0;
}
.co-trust__inner{
  max-width:1160px;margin:0 auto;padding:0 24px;
  display:flex;align-items:center;gap:32px;flex-wrap:wrap;
}
.co-trust__label{
  font-size:.75rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;
  color:rgba(255,255,255,.6);white-space:nowrap;
}
.co-trust__items{
  display:flex;gap:32px;flex-wrap:wrap;align-items:center;
}
.co-trust__item{
  font-size:.85rem;font-weight:600;color:rgba(255,255,255,.85);
  display:flex;align-items:center;gap:8px;
}
.co-trust__item::before{content:'✓';color:var(--co-amber-light);font-weight:700}

/* ═══════════════════════════════════════════
   SERVICES
═══════════════════════════════════════════ */
.co-services{}
.co-services__grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:28px;
  margin-top:56px;
}
.co-svc-card{
  background:var(--co-white);
  border:1px solid #E2E8F0;
  border-radius:10px;
  padding:36px 28px;
  transition:all .3s;
  position:relative;overflow:hidden;
}
.co-svc-card::before{
  content:'';position:absolute;
  top:0;left:0;right:0;height:4px;
  background:linear-gradient(90deg,var(--co-sapphire),var(--co-saphire-light));
  transform:scaleX(0);transform-origin:left;
  transition:transform .3s;
}
.co-svc-card:hover{box-shadow:var(--co-shadow-lg);transform:translateY(-4px);border-color:transparent}
.co-svc-card:hover::before{transform:scaleX(1)}
.co-svc-icon{
  width:54px;height:54px;
  background:linear-gradient(135deg,#EFF6FF,#DBEAFE);
  border-radius:12px;
  display:flex;align-items:center;justify-content:center;
  font-size:1.5rem;
  margin-bottom:20px;
}
.co-svc-card h3{font-family:var(--co-serif);font-size:1.2rem;margin-bottom:12px;color:var(--co-midnight)}
.co-svc-card p{font-size:.9rem;color:var(--co-slate);line-height:1.65}
.co-svc-card ul{list-style:none;margin-top:16px}
.co-svc-card ul li{
  font-size:.85rem;color:var(--co-slate);padding:5px 0;
  display:flex;align-items:center;gap:8px;
}
.co-svc-card ul li::before{content:'→';color:var(--co-sapphire);font-weight:700;flex-shrink:0}

/* ═══════════════════════════════════════════
   APPROACH / PROCESS
═══════════════════════════════════════════ */
.co-approach{background:#F1F5F9}
.co-approach__steps{
  display:grid;
  grid-template-columns:repeat(4,1fr);
  gap:24px;
  margin-top:56px;
  position:relative;
}
.co-approach__steps::before{
  content:'';position:absolute;
  top:32px;left:calc(12.5% + 16px);right:calc(12.5% + 16px);height:2px;
  background:linear-gradient(90deg,var(--co-sapphire),var(--co-amber));
}
.co-step{text-align:center;position:relative}
.co-step__num{
  width:64px;height:64px;
  background:var(--co-sapphire);
  border-radius:50%;
  display:flex;align-items:center;justify-content:center;
  font-family:var(--co-serif);font-size:1.3rem;font-weight:700;color:var(--co-white);
  margin:0 auto 20px;
  position:relative;z-index:1;
  box-shadow:0 0 0 6px var(--co-platinum),0 0 0 8px rgba(30,64,175,.3);
  transition:all .3s;
}
.co-step:hover .co-step__num{background:var(--co-amber);box-shadow:0 0 0 6px var(--co-platinum),0 0 0 8px rgba(245,158,11,.3)}
.co-step h3{font-family:var(--co-serif);font-size:1.05rem;margin-bottom:10px;color:var(--co-midnight)}
.co-step p{font-size:.875rem;color:var(--co-slate);line-height:1.6}

/* ═══════════════════════════════════════════
   RESULTS / IMPACT
═══════════════════════════════════════════ */
.co-results{background:var(--co-midnight)}
.co-results__grid{
  display:grid;
  grid-template-columns:repeat(4,1fr);
  gap:32px;
  margin-top:56px;
}
.co-result-card{
  text-align:center;
  padding:36px 20px;
  background:rgba(255,255,255,.04);
  border:1px solid rgba(255,255,255,.08);
  border-radius:10px;
  transition:all .3s;
}
.co-result-card:hover{background:rgba(30,64,175,.15);border-color:rgba(59,130,246,.3);transform:translateY(-4px)}
.co-result-card__val{
  font-family:var(--co-serif);font-size:2.6rem;font-weight:700;
  color:var(--co-amber);display:block;
}
.co-result-card__lbl{font-size:.875rem;color:rgba(248,250,252,.55);margin-top:8px;line-height:1.5}

/* ═══════════════════════════════════════════
   TEAM
═══════════════════════════════════════════ */
.co-team__grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:28px;
  margin-top:56px;
}
.co-team-card{
  background:var(--co-white);
  border:1px solid #E2E8F0;
  border-radius:10px;
  overflow:hidden;
  transition:all .3s;
}
.co-team-card:hover{box-shadow:var(--co-shadow-lg);transform:translateY(-4px)}
.co-team-card__portrait{
  height:180px;
  position:relative;
  overflow:hidden;
}

/* CSS Partner Figures */
.co-pfig{position:relative;display:flex;flex-direction:column;align-items:center;padding-top:20px}
.co-pfig__head{
  width:60px;height:64px;
  border-radius:50% 50% 45% 45%;
  position:relative;
}
.co-pfig__head::before{/* hair */
  content:'';position:absolute;
  top:-5px;left:-3px;right:-3px;height:22px;
  border-radius:8px 8px 3px 3px;
}
.co-pfig__head::after{/* eyes + expression */
  content:'';position:absolute;
  top:22px;left:12px;right:12px;height:5px;
  background:rgba(30,23,42,.6);
  border-radius:2px;
  box-shadow:0 0 0 4px rgba(30,23,42,.1),16px 0 0 0 rgba(30,23,42,.6);
}
.co-pfig__body{
  width:74px;height:60px;
  border-radius:6px 6px 2px 2px;
  position:relative;
  margin-top:4px;
}
/* Partner 1 — Marcus Webb — dark suit */
.co-pfig--p1 .co-pfig__head{background:#C8956B}
.co-pfig--p1 .co-pfig__head::before{background:#1A0A00}
.co-pfig--p1 .co-pfig__body{background:linear-gradient(180deg,#0F172A,#1E293B)}
.co-pfig--p1 .co-pfig__body::before{
  content:'';position:absolute;top:0;left:50%;transform:translateX(-50%);
  width:16px;height:36px;
  background:linear-gradient(180deg,#F8FAFC 0%,#F8FAFC 25%,#1E40AF 25%,#1E40AF 100%);
  border-radius:0 0 3px 3px;
}
/* Partner 2 — Claire Osei — grey blazer */
.co-pfig--p2 .co-pfig__head{background:#8B5E3C}
.co-pfig--p2 .co-pfig__head::before{background:#0A0A0A}
.co-pfig--p2 .co-pfig__body{background:linear-gradient(180deg,#475569,#64748B)}
.co-pfig--p2 .co-pfig__body::before{
  content:'';position:absolute;top:0;left:50%;transform:translateX(-50%);
  width:14px;height:32px;
  background:linear-gradient(180deg,#F8FAFC 0%,#F8FAFC 20%,var(--co-sapphire) 20%);
  border-radius:0 0 3px 3px;
}
/* Partner 3 — Rohan Mehta — navy */
.co-pfig--p3 .co-pfig__head{background:#D4A574}
.co-pfig--p3 .co-pfig__head::before{background:#2D1507}
.co-pfig--p3 .co-pfig__body{background:linear-gradient(180deg,#1E3A8A,#1D4ED8)}
.co-pfig--p3 .co-pfig__body::before{
  content:'';position:absolute;top:0;left:50%;transform:translateX(-50%);
  width:16px;height:36px;
  background:linear-gradient(180deg,#F8FAFC 0%,#F8FAFC 22%,var(--co-amber) 22%,var(--co-amber) 100%);
  border-radius:0 0 3px 3px;
}
.co-pfig__portrait-bg{
  position:absolute;inset:0;
  display:flex;flex-direction:column;align-items:center;
  justify-content:flex-end;
}

.co-team-card__info{padding:24px}
.co-team-card__info h3{font-family:var(--co-serif);font-size:1.1rem;margin-bottom:4px}
.co-team-card__role{font-size:.8rem;font-weight:600;color:var(--co-sapphire);text-transform:uppercase;letter-spacing:.08em;margin-bottom:10px}
.co-team-card__bio{font-size:.85rem;color:var(--co-slate);line-height:1.6}
.co-team-card__tags{display:flex;gap:6px;flex-wrap:wrap;margin-top:12px}
.co-team-card__tag{
  background:#EFF6FF;color:var(--co-sapphire);
  font-size:.72rem;font-weight:600;
  padding:3px 10px;border-radius:12px;
}

/* ═══════════════════════════════════════════
   PACKAGES
═══════════════════════════════════════════ */
.co-packages{background:#F1F5F9}
.co-packages__grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:28px;
  margin-top:56px;
  align-items:start;
}
.co-pkg{
  background:var(--co-white);
  border:2px solid #E2E8F0;
  border-radius:12px;
  padding:36px 28px;
  position:relative;
  transition:all .3s;
}
.co-pkg:hover{box-shadow:var(--co-shadow)}
.co-pkg--featured{
  border-color:var(--co-sapphire);
  transform:scale(1.04);
  box-shadow:var(--co-shadow-lg);
  background:linear-gradient(160deg,#EFF6FF 0%,#DBEAFE 100%);
}
.co-pkg__badge{
  position:absolute;top:-14px;left:50%;transform:translateX(-50%);
  background:var(--co-sapphire);color:var(--co-white);
  font-size:.72rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;
  padding:5px 18px;border-radius:12px;white-space:nowrap;
}
.co-pkg__name{font-family:var(--co-serif);font-size:1.2rem;margin-bottom:8px}
.co-pkg__price{
  font-family:var(--co-serif);font-size:2.4rem;font-weight:700;
  color:var(--co-sapphire);margin:16px 0 4px;
}
.co-pkg--featured .co-pkg__price{color:var(--co-midnight)}
.co-pkg__price span{font-size:.95rem;color:var(--co-slate);font-family:var(--co-sans);font-weight:400}
.co-pkg__desc{font-size:.875rem;color:var(--co-slate);margin-bottom:20px;line-height:1.6}
.co-pkg__divider{height:1px;background:#E2E8F0;margin:20px 0}
.co-pkg__features{list-style:none}
.co-pkg__features li{
  font-size:.875rem;color:var(--co-slate);
  padding:7px 0;display:flex;align-items:flex-start;gap:10px;
}
.co-pkg__features li::before{content:'✓';color:var(--co-sapphire);font-weight:700;flex-shrink:0;margin-top:1px}
.co-pkg__cta{margin-top:28px;width:100%;justify-content:center}

/* ═══════════════════════════════════════════
   TESTIMONIALS
═══════════════════════════════════════════ */
.co-testimonials{background:var(--co-midnight)}
.co-testi-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:24px;
  margin-top:56px;
}
.co-testi{
  background:rgba(255,255,255,.05);
  border:1px solid rgba(255,255,255,.08);
  border-radius:10px;
  padding:32px;
  position:relative;
}
.co-testi::before{
  content:'\201C';
  position:absolute;top:16px;left:24px;
  font-family:var(--co-serif);font-size:4rem;
  color:var(--co-sapphire);opacity:.5;line-height:1;
}
.co-testi__text{
  font-size:.95rem;color:rgba(248,250,252,.8);
  line-height:1.7;margin-bottom:24px;padding-top:24px;
}
.co-testi__author{display:flex;align-items:center;gap:14px}
.co-testi__avatar{
  width:44px;height:44px;border-radius:50%;
  display:flex;align-items:center;justify-content:center;
  font-family:var(--co-serif);font-weight:700;color:var(--co-white);font-size:1rem;
  flex-shrink:0;
}
.co-testi__name{font-weight:600;color:var(--co-white);font-size:.9rem}
.co-testi__role{font-size:.78rem;color:rgba(248,250,252,.5);margin-top:2px}
.co-testi__stars{margin-bottom:12px}
.co-star{color:var(--co-amber)}

/* ═══════════════════════════════════════════
   CASE STUDY BAND
═══════════════════════════════════════════ */
.co-cases{background:#F1F5F9}
.co-cases__grid{
  display:grid;
  grid-template-columns:repeat(2,1fr);
  gap:28px;
  margin-top:56px;
}
.co-case{
  background:var(--co-white);
  border:1px solid #E2E8F0;
  border-radius:10px;
  padding:32px;
  display:grid;
  grid-template-columns:1fr auto;
  gap:20px;
  align-items:start;
  transition:all .3s;
}
.co-case:hover{box-shadow:var(--co-shadow);transform:translateY(-3px)}
.co-case__industry{
  font-size:.72rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;
  color:var(--co-sapphire);margin-bottom:8px;
}
.co-case h3{font-family:var(--co-serif);font-size:1.05rem;margin-bottom:10px}
.co-case p{font-size:.875rem;color:var(--co-slate);line-height:1.65}
.co-case__metric{
  background:linear-gradient(135deg,#EFF6FF,#DBEAFE);
  border:1px solid #BFDBFE;
  border-radius:8px;padding:16px 20px;text-align:center;
  white-space:nowrap;flex-shrink:0;
}
.co-case__metric-val{
  font-family:var(--co-serif);font-size:1.8rem;font-weight:700;
  color:var(--co-sapphire);display:block;
}
.co-case__metric-lbl{font-size:.72rem;color:var(--co-slate);margin-top:4px}

/* ═══════════════════════════════════════════
   FAQ
═══════════════════════════════════════════ */
.co-faq{}
.co-faq__list{max-width:760px;margin:48px auto 0}
.co-faq-item{
  border-bottom:1px solid #E2E8F0;
}
.co-faq-q{
  width:100%;background:none;border:none;
  display:flex;justify-content:space-between;align-items:center;
  padding:22px 0;cursor:pointer;text-align:left;
  font-family:var(--co-sans);font-size:1rem;font-weight:600;color:var(--co-midnight);
  gap:16px;
  transition:color .2s;
}
.co-faq-q:hover{color:var(--co-sapphire)}
.co-faq-icon{
  width:28px;height:28px;border-radius:50%;
  background:var(--co-sapphire);color:var(--co-white);
  display:flex;align-items:center;justify-content:center;
  font-size:1.1rem;flex-shrink:0;
  transition:transform .3s,background .2s;
}
.co-faq-item.co-open .co-faq-icon{transform:rotate(45deg);background:var(--co-amber)}
.co-faq-a{
  max-height:0;overflow:hidden;
  transition:max-height .4s ease;
}
.co-faq-a p{padding:0 0 20px;font-size:.925rem;color:var(--co-slate);line-height:1.7}

/* ═══════════════════════════════════════════
   CONTACT
═══════════════════════════════════════════ */
.co-contact{background:var(--co-midnight)}
.co-contact__inner{
  display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:start;
}
.co-contact__info h2{color:var(--co-white)}
.co-contact__info .co-lead{color:rgba(248,250,252,.6);margin:20px 0 32px;text-align:left}
.co-contact__item{
  display:flex;align-items:flex-start;gap:14px;
  margin-bottom:24px;
}
.co-contact__item-icon{
  width:42px;height:42px;
  background:rgba(30,64,175,.25);border:1px solid rgba(59,130,246,.3);
  border-radius:8px;display:flex;align-items:center;justify-content:center;
  font-size:1.1rem;flex-shrink:0;
}
.co-contact__item-text strong{display:block;color:var(--co-white);font-size:.9rem;margin-bottom:3px}
.co-contact__item-text span{color:rgba(248,250,252,.5);font-size:.85rem}

/* Form */
.co-form{
  background:rgba(255,255,255,.04);
  border:1px solid rgba(255,255,255,.08);
  border-radius:12px;padding:40px;
}
.co-form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.co-field{margin-bottom:20px}
.co-field label{
  display:block;font-size:.8rem;font-weight:600;
  color:rgba(248,250,252,.6);margin-bottom:8px;letter-spacing:.04em;
}
.co-field input,
.co-field select,
.co-field textarea{
  width:100%;background:rgba(255,255,255,.06);
  border:1px solid rgba(255,255,255,.12);border-radius:var(--co-radius);
  padding:12px 16px;font-family:var(--co-sans);font-size:.9rem;
  color:var(--co-platinum);outline:none;
  transition:border-color .2s,background .2s;
}
.co-field input::placeholder,
.co-field textarea::placeholder{color:rgba(248,250,252,.3)}
.co-field input:focus,
.co-field select:focus,
.co-field textarea:focus{border-color:var(--co-sapphire);background:rgba(30,64,175,.08)}
.co-field select option{background:var(--co-midnight);color:var(--co-platinum)}
.co-field textarea{resize:vertical;min-height:120px}
.co-form .co-btn{width:100%;justify-content:center;margin-top:8px}

/* ═══════════════════════════════════════════
   FOOTER CTA
═══════════════════════════════════════════ */
.co-footer-cta{
  background:linear-gradient(135deg,var(--co-sapphire) 0%,#1D4ED8 100%);
  padding:72px 0;text-align:center;
}
.co-footer-cta h2{
  font-family:var(--co-serif);font-size:clamp(1.8rem,3vw,2.6rem);
  color:var(--co-white);margin-bottom:16px;
}
.co-footer-cta p{color:rgba(255,255,255,.75);font-size:1.05rem;margin-bottom:36px}
.co-footer-cta .co-btn--amber{font-size:1.05rem;padding:16px 40px}

/* ═══════════════════════════════════════════
   SCROLL REVEAL
═══════════════════════════════════════════ */
.co-reveal{opacity:0;transform:translateY(28px);transition:opacity .65s ease,transform .65s ease}
.co-reveal.co-visible{opacity:1;transform:none}

/* ── RESPONSIVE ── */
@media(max-width:960px){
  .co-hero__inner{grid-template-columns:1fr;text-align:center}
  .co-hero__scene{display:none}
  .co-hero__ctas{justify-content:center}
  .co-hero__desc{margin-left:auto;margin-right:auto}
  .co-services__grid{grid-template-columns:1fr 1fr}
  .co-approach__steps{grid-template-columns:1fr 1fr}
  .co-approach__steps::before{display:none}
  .co-results__grid{grid-template-columns:1fr 1fr}
  .co-team__grid{grid-template-columns:1fr 1fr}
  .co-packages__grid{grid-template-columns:1fr}
  .co-pkg--featured{transform:none}
  .co-testi-grid{grid-template-columns:1fr}
  .co-cases__grid{grid-template-columns:1fr}
  .co-contact__inner{grid-template-columns:1fr}
  .co-hero__stats{flex-wrap:wrap}
  .co-hero__stat{flex:0 0 50%}
}
@media(max-width:600px){
  .co-section{padding:60px 0}
  .co-services__grid{grid-template-columns:1fr}
  .co-team__grid{grid-template-columns:1fr}
  .co-form-row{grid-template-columns:1fr}
  .co-results__grid{grid-template-columns:1fr 1fr}
}
</style>

<!-- ============================================================
     PAGE WRAPPER
     ============================================================ -->
<div class="co-page">

<!-- ════════════════════════════════════════
     HERO
════════════════════════════════════════ -->
<section class="co-hero">
  <div class="co-hero__grid"></div>
  <div class="co-hero__glow"></div>
  <div class="co-hero__glow2"></div>

  <div class="co-hero__inner">
    <!-- Copy -->
    <div class="co-hero__copy">
      <div class="co-hero__badge">Trusted by 200+ organisations across 14 countries</div>
      <p class="co-hero__tagline">Strategic Management Consulting</p>
      <h1 class="co-h1">Transform Strategy<br>Into <em>Measurable</em> Results</h1>
      <p class="co-hero__desc">We partner with ambitious businesses to unlock growth, improve operational performance, and build competitive advantage — with data-driven clarity at every step.</p>
      <div class="co-hero__ctas">
        <a href="#contact" class="co-btn co-btn--primary">Book a Strategy Call</a>
        <a href="#cases" class="co-btn co-btn--outline">View Case Studies</a>
      </div>
    </div>

    <!-- Scene -->
    <div class="co-hero__scene" aria-hidden="true">
      <!-- Floating KPI badges -->
      <div class="co-kpi-badge">
        <div class="co-kpi-badge__val">+34%</div>
        <div class="co-kpi-badge__lbl">Revenue Growth</div>
      </div>
      <div class="co-kpi-badge">
        <div class="co-kpi-badge__val">£2.8M</div>
        <div class="co-kpi-badge__lbl">Cost Saved</div>
      </div>
      <div class="co-kpi-badge">
        <div class="co-kpi-badge__val">18mo</div>
        <div class="co-kpi-badge__lbl">Avg. Payback</div>
      </div>

      <!-- Whiteboard -->
      <div class="co-whiteboard">
        <div class="co-wb-chart">
          <div class="co-wb-bar" style="left:4%;width:10%;height:30%;background:rgba(30,64,175,.5)"></div>
          <div class="co-wb-bar" style="left:18%;width:10%;height:50%;background:rgba(30,64,175,.6)"></div>
          <div class="co-wb-bar" style="left:32%;width:10%;height:40%;background:rgba(30,64,175,.5)"></div>
          <div class="co-wb-bar" style="left:46%;width:10%;height:70%;background:rgba(30,64,175,.7)"></div>
          <div class="co-wb-bar" style="left:60%;width:10%;height:85%;background:rgba(245,158,11,.7)"></div>
          <div class="co-wb-line"></div>
          <div class="co-wb-arrow">📈</div>
        </div>
      </div>
      <div class="co-whiteboard-stand"></div>

      <!-- Desk -->
      <div class="co-desk"></div>
      <div class="co-monitor-stand"></div>
      <div class="co-monitor-base"></div>

      <!-- Monitor with bar chart -->
      <div class="co-monitor">
        <div class="co-screen-bars">
          <?php
          $co_bars = [38,55,45,70,88,60];
          foreach($co_bars as $bh):
          ?>
          <div class="co-screen-bar" style="--co-bh:<?php echo $bh; ?>px"></div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Documents -->
      <div class="co-docs">
        <div class="co-doc"></div>
        <div class="co-doc"></div>
        <div class="co-doc"></div>
      </div>
      <div class="co-pen"></div>

      <!-- Laptop -->
      <div class="co-laptop">
        <div class="co-laptop__lid"></div>
        <div class="co-laptop__base"></div>
      </div>

      <!-- Coffee -->
      <div class="co-coffee">
        <div class="co-coffee__steam">
          <span></span><span></span><span></span>
        </div>
        <div class="co-coffee__cup"></div>
      </div>

      <!-- Consultant figure -->
      <div class="co-cfig">
        <div class="co-cfig__head"></div>
        <div class="co-cfig__neck"></div>
        <div class="co-cfig__body" style="position:relative">
          <div class="co-cfig__arm-l"></div>
          <div class="co-cfig__arm-r"></div>
        </div>
        <div class="co-cfig__legs">
          <div class="co-cfig__leg"></div>
          <div class="co-cfig__leg"></div>
        </div>
      </div>
    </div>
  </div>

  <!-- Stats bar -->
  <div class="co-hero__stats">
    <div class="co-hero__stat">
      <span class="co-hero__stat-val co-counter" data-target="200" data-suffix="+">0</span>
      <div class="co-hero__stat-lbl">Client Organisations</div>
    </div>
    <div class="co-hero__stat">
      <span class="co-hero__stat-val co-counter" data-target="94" data-suffix="%">0</span>
      <div class="co-hero__stat-lbl">Client Satisfaction</div>
    </div>
    <div class="co-hero__stat">
      <span class="co-hero__stat-val co-counter" data-prefix="£" data-target="480" data-suffix="M+">0</span>
      <div class="co-hero__stat-lbl">Value Delivered</div>
    </div>
    <div class="co-hero__stat">
      <span class="co-hero__stat-val co-counter" data-target="22" data-suffix=" yrs">0</span>
      <div class="co-hero__stat-lbl">Industry Experience</div>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     TRUST BAND
════════════════════════════════════════ -->
<div class="co-trust">
  <div class="co-trust__inner">
    <span class="co-trust__label">Certifications &amp; Affiliations</span>
    <div class="co-trust__items">
      <span class="co-trust__item">CMC Certified</span>
      <span class="co-trust__item">ISO 9001:2015</span>
      <span class="co-trust__item">FCA Registered</span>
      <span class="co-trust__item">ICF Accredited Coaches</span>
      <span class="co-trust__item">B Corp Pending</span>
    </div>
  </div>
</div>

<!-- ════════════════════════════════════════
     SERVICES
════════════════════════════════════════ -->
<section class="co-section co-services" id="services">
  <div class="co-wrap">
    <div class="co-hgroup co-center">
      <p class="co-eyebrow">What We Do</p>
      <h2 class="co-h2">Consulting Services Built for Impact</h2>
      <p class="co-lead">From strategy to execution, we deliver end-to-end consulting across the disciplines that matter most to sustainable business growth.</p>
    </div>
    <div class="co-services__grid">

      <?php
      $co_svcs = [
        ['icon'=>'📊','title'=>'Strategy & Growth','desc'=>'Define where you play and how to win. We build evidence-based strategies that align ambition with capability.','items'=>['Market opportunity mapping','Competitive positioning','3–5 year growth roadmaps','M&A and partnership strategy']],
        ['icon'=>'⚙️','title'=>'Operational Excellence','desc'=>'Eliminate waste, accelerate throughput, and build the systems that let your organisation scale reliably.','items'=>['Process re-engineering','Lean Six Sigma methods','Supply chain optimisation','Cost reduction programmes']],
        ['icon'=>'💡','title'=>'Innovation & Transformation','desc'=>'Navigate change with confidence. We design and deliver transformation programmes that stick.','items'=>['Digital transformation','Change management','Innovation frameworks','Agile at scale']],
        ['icon'=>'👥','title'=>'People & Organisation','desc'=>'Your people are your competitive advantage. We align talent, culture, and structure with strategic intent.','items'=>['Organisational design','Leadership development','Workforce planning','Culture diagnostics']],
        ['icon'=>'📈','title'=>'Finance & Performance','desc'=>'Sharpen financial management and reporting to give leadership the clarity needed for confident decisions.','items'=>['CFO advisory services','Financial modelling','Board reporting frameworks','Investor readiness']],
        ['icon'=>'🌐','title'=>'Market Entry & Internationalisation','desc'=>'Enter new markets with precision. We validate opportunities and build the local playbooks you need to succeed.','items'=>['Country market analysis','Regulatory navigation','Go-to-market strategy','Distribution partnerships']],
      ];
      foreach($co_svcs as $svc):
      ?>
      <div class="co-svc-card co-reveal">
        <div class="co-svc-icon"><?php echo $svc['icon']; ?></div>
        <h3><?php echo $svc['title']; ?></h3>
        <p><?php echo $svc['desc']; ?></p>
        <ul>
          <?php foreach($svc['items'] as $item): ?>
          <li><?php echo $item; ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
      <?php endforeach; ?>

    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     APPROACH
════════════════════════════════════════ -->
<section class="co-section co-approach" id="approach">
  <div class="co-wrap">
    <div class="co-hgroup co-center">
      <p class="co-eyebrow">Our Approach</p>
      <h2 class="co-h2">How We Deliver Results</h2>
      <p class="co-lead">A structured, collaborative process that moves fast without cutting corners — from insight to implementation in four disciplined phases.</p>
    </div>
    <div class="co-approach__steps">
      <?php
      $co_steps = [
        ['num'=>'01','title'=>'Diagnose','desc'=>'Rapid immersion to understand your business, market, constraints, and opportunities. No assumptions — just evidence.'],
        ['num'=>'02','title'=>'Design','desc'=>'Co-develop strategies and solutions with your team. We bring frameworks; you bring context. The best answers emerge together.'],
        ['num'=>'03','title'=>'Deploy','desc'=>'Hands-on implementation support. We work alongside your teams — not from the sidelines — to make change happen.'],
        ['num'=>'04','title'=>'Sustain','desc'=>'Embed capability, track KPIs, and refine. Engagements end when outcomes are locked in, not when the retainer runs out.'],
      ];
      foreach($co_steps as $step):
      ?>
      <div class="co-step co-reveal">
        <div class="co-step__num"><?php echo $step['num']; ?></div>
        <h3><?php echo $step['title']; ?></h3>
        <p><?php echo $step['desc']; ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     RESULTS
════════════════════════════════════════ -->
<section class="co-section co-results co-section--dark">
  <div class="co-wrap">
    <div class="co-hgroup co-center">
      <p class="co-eyebrow">Proven Impact</p>
      <h2 class="co-h2">Results That Speak for Themselves</h2>
      <p class="co-lead">Numbers drawn from verified client outcomes, independently audited. Because accountability should be as rigorous as our advice.</p>
    </div>
    <div class="co-results__grid">
      <?php
      $co_results = [
        ['val'=>34,'suffix'=>'%','lbl'=>'Average revenue uplift across growth engagements'],
        ['val'=>2.8,'prefix'=>'£','suffix'=>'M','lbl'=>'Average annualised cost savings per operational transformation'],
        ['val'=>18,'suffix'=>' wks','lbl'=>'Average time from engagement start to measurable results'],
        ['val'=>88,'suffix'=>'%','lbl'=>'Clients who re-engage within 24 months'],
      ];
      foreach($co_results as $r):
      ?>
      <div class="co-result-card co-reveal">
        <span class="co-result-card__val co-counter"
          data-target="<?php echo $r['val']; ?>"
          <?php if(!empty($r['prefix'])): ?>data-prefix="<?php echo $r['prefix']; ?>"<?php endif; ?>
          data-suffix="<?php echo $r['suffix']; ?>">0</span>
        <div class="co-result-card__lbl"><?php echo $r['lbl']; ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     TEAM
════════════════════════════════════════ -->
<section class="co-section" id="team">
  <div class="co-wrap">
    <div class="co-hgroup co-center">
      <p class="co-eyebrow">Our Partners</p>
      <h2 class="co-h2">Senior Expertise at Every Level</h2>
      <p class="co-lead">You won't be handed off to juniors. Every engagement is led by a senior partner who owns the outcomes as personally as you do.</p>
    </div>
    <div class="co-team__grid">

      <!-- Partner 1 -->
      <div class="co-team-card co-reveal">
        <div class="co-team-card__portrait" style="background:linear-gradient(135deg,#0F172A,#1E293B)">
          <div class="co-pfig co-pfig--p1" style="position:absolute;bottom:0;left:50%;transform:translateX(-50%)">
            <div class="co-pfig__head"></div>
            <div class="co-pfig__body"></div>
          </div>
        </div>
        <div class="co-team-card__info">
          <h3>Marcus Webb</h3>
          <div class="co-team-card__role">Managing Partner — Strategy</div>
          <p class="co-team-card__bio">20 years advising FTSE 100 boards on growth strategy, M&A, and market entry. Former McKinsey Principal. MBA, London Business School.</p>
          <div class="co-team-card__tags">
            <span class="co-team-card__tag">Corporate Strategy</span>
            <span class="co-team-card__tag">M&A</span>
            <span class="co-team-card__tag">Retail</span>
          </div>
        </div>
      </div>

      <!-- Partner 2 -->
      <div class="co-team-card co-reveal">
        <div class="co-team-card__portrait" style="background:linear-gradient(135deg,#1E293B,#334155)">
          <div class="co-pfig co-pfig--p2" style="position:absolute;bottom:0;left:50%;transform:translateX(-50%)">
            <div class="co-pfig__head"></div>
            <div class="co-pfig__body"></div>
          </div>
        </div>
        <div class="co-team-card__info">
          <h3>Claire Osei</h3>
          <div class="co-team-card__role">Partner — Operations</div>
          <p class="co-team-card__bio">Operational transformation specialist with deep expertise in manufacturing, logistics and shared services. Lean Six Sigma Black Belt. 16 years' experience.</p>
          <div class="co-team-card__tags">
            <span class="co-team-card__tag">Lean Six Sigma</span>
            <span class="co-team-card__tag">Supply Chain</span>
            <span class="co-team-card__tag">Manufacturing</span>
          </div>
        </div>
      </div>

      <!-- Partner 3 -->
      <div class="co-team-card co-reveal">
        <div class="co-team-card__portrait" style="background:linear-gradient(135deg,#0F172A,#1E3A8A)">
          <div class="co-pfig co-pfig--p3" style="position:absolute;bottom:0;left:50%;transform:translateX(-50%)">
            <div class="co-pfig__head"></div>
            <div class="co-pfig__body"></div>
          </div>
        </div>
        <div class="co-team-card__info">
          <h3>Rohan Mehta</h3>
          <div class="co-team-card__role">Partner — Digital &amp; Innovation</div>
          <p class="co-team-card__bio">Technology-enabled transformation leader. Former Chief Digital Officer at a listed financial services group. Specialises in AI adoption, data strategy, and digital product.</p>
          <div class="co-team-card__tags">
            <span class="co-team-card__tag">Digital Strategy</span>
            <span class="co-team-card__tag">AI &amp; Data</span>
            <span class="co-team-card__tag">FinTech</span>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     PACKAGES
════════════════════════════════════════ -->
<section class="co-section co-packages" id="packages">
  <div class="co-wrap">
    <div class="co-hgroup co-center">
      <p class="co-eyebrow">Engagement Models</p>
      <h2 class="co-h2">Flexible Ways to Work Together</h2>
      <p class="co-lead">Whether you need a focused sprint, a full transformation programme, or ongoing advisory access, we have a model that fits your needs and budget.</p>
    </div>
    <div class="co-packages__grid">

      <div class="co-pkg co-reveal">
        <div class="co-pkg__name">Strategy Sprint</div>
        <p class="co-pkg__desc">Intensive 4-week engagement to diagnose a specific challenge and deliver a clear, prioritised action plan.</p>
        <div class="co-pkg__price">£18,000 <span>fixed fee</span></div>
        <hr class="co-pkg__divider">
        <ul class="co-pkg__features">
          <li>Senior partner–led</li>
          <li>Discovery & data analysis</li>
          <li>Stakeholder interviews (up to 8)</li>
          <li>Strategic options report</li>
          <li>Prioritised implementation roadmap</li>
          <li>2 x board presentation sessions</li>
        </ul>
        <a href="#contact" class="co-btn co-btn--primary co-pkg__cta">Enquire Now</a>
      </div>

      <div class="co-pkg co-pkg--featured co-reveal">
        <div class="co-pkg__badge">Most Popular</div>
        <div class="co-pkg__name">Transformation Programme</div>
        <p class="co-pkg__desc">End-to-end programme design and delivery — from strategy through to embedded organisational change.</p>
        <div class="co-pkg__price">£9,500 <span>/ month</span></div>
        <hr class="co-pkg__divider">
        <ul class="co-pkg__features">
          <li>Dedicated senior partner + analyst team</li>
          <li>Full diagnostic &amp; strategy phase</li>
          <li>Implementation planning &amp; oversight</li>
          <li>Weekly leadership steering calls</li>
          <li>Change management &amp; comms support</li>
          <li>KPI dashboard &amp; reporting</li>
          <li>Capability building workshops</li>
          <li>Monthly board updates</li>
        </ul>
        <a href="#contact" class="co-btn co-btn--primary co-pkg__cta">Book Discovery Call</a>
      </div>

      <div class="co-pkg co-reveal">
        <div class="co-pkg__name">Executive Advisory</div>
        <p class="co-pkg__desc">Retained senior advisory access for CEOs and boards who need a trusted thinking partner on an ongoing basis.</p>
        <div class="co-pkg__price">£4,200 <span>/ month</span></div>
        <hr class="co-pkg__divider">
        <ul class="co-pkg__features">
          <li>4 x strategic advisory sessions/month</li>
          <li>Direct partner access by email/phone</li>
          <li>Quarterly strategy reviews</li>
          <li>Ad hoc research &amp; analysis</li>
          <li>Network introductions</li>
          <li>Investor/board meeting support</li>
        </ul>
        <a href="#contact" class="co-btn co-btn--primary co-pkg__cta">Enquire Now</a>
      </div>

    </div>
    <p style="text-align:center;margin-top:32px;font-size:.875rem;color:var(--co-slate)">All engagements begin with a complimentary 60-minute diagnostic call. No commitment required.</p>
  </div>
</section>

<!-- ════════════════════════════════════════
     CASE STUDIES
════════════════════════════════════════ -->
<section class="co-section co-cases" id="cases">
  <div class="co-wrap">
    <div class="co-hgroup co-center">
      <p class="co-eyebrow">Case Studies</p>
      <h2 class="co-h2">Real Problems. Real Results.</h2>
      <p class="co-lead">A selection of recent engagements — names changed for confidentiality, outcomes independently verified.</p>
    </div>
    <div class="co-cases__grid">

      <?php
      $co_cases = [
        ['industry'=>'Retail &amp; Consumer','title'=>'Turning Around a £120M Retailer Facing Margin Collapse','desc'=>'A multi-site UK retailer was haemorrhaging margin through an outdated pricing architecture and bloated cost base. We redesigned their category strategy, renegotiated supplier terms, and replatformed their markdown logic — restoring profitability in 14 months.','val'=>'£4.1M','lbl'=>'Margin recovered annually'],
        ['industry'=>'Professional Services','title'=>'Scaling a Law Firm from 40 to 120 Partners in 3 Years','desc'=>'A mid-tier law firm wanted aggressive growth without compromising culture or client quality. We built their M&A pipeline playbook, designed the lateral hire framework, and restructured their service line P&L — enabling a controlled tripling of partner headcount.','val'=>'+198%','lbl'=>'Fee income growth'],
        ['industry'=>'Manufacturing','title'=>'OEE Improvement Programme for a Precision Parts Manufacturer','desc'=>'Chronic unplanned downtime and scrap rates were eroding competitiveness for a £65M precision manufacturer. A 6-month Lean deployment raised OEE from 58% to 79% and cut scrap by 44%.','val'=>'+21pts','lbl'=>'OEE improvement'],
        ['industry'=>'Technology','title'=>'Market Entry Strategy — Entering the German Mid-Market','desc'=>'A UK SaaS business sought to expand into Germany but lacked in-market knowledge and channel relationships. We validated demand, recruited a country lead, and launched with a pipeline of 38 qualified opportunities inside 90 days.','val'=>'90 days','lbl'=>'Time to first pipeline'],
      ];
      foreach($co_cases as $c):
      ?>
      <div class="co-case co-reveal">
        <div>
          <div class="co-case__industry"><?php echo $c['industry']; ?></div>
          <h3><?php echo $c['title']; ?></h3>
          <p><?php echo $c['desc']; ?></p>
        </div>
        <div class="co-case__metric">
          <span class="co-case__metric-val"><?php echo $c['val']; ?></span>
          <div class="co-case__metric-lbl"><?php echo $c['lbl']; ?></div>
        </div>
      </div>
      <?php endforeach; ?>

    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     TESTIMONIALS
════════════════════════════════════════ -->
<section class="co-section co-testimonials co-section--dark">
  <div class="co-wrap">
    <div class="co-hgroup co-center">
      <p class="co-eyebrow">Client Voices</p>
      <h2 class="co-h2">What Our Clients Say</h2>
    </div>
    <div class="co-testi-grid">

      <?php
      $co_testis = [
        ['text'=>'Marcus and the team didn\'t just hand us a report and leave. They stayed through the hard part — the implementation — and that\'s where every penny of value was created. We\'re a different business.','name'=>'Sarah Hollingsworth','role'=>'CEO, Meridian Consumer Brands','col'=>'#1E40AF'],
        ['text'=>'The operational programme Claire led transformed our factory floor. We\'d tried to fix our OEE problems for two years internally and got nowhere. In six months they achieved what we couldn\'t in six years.','name'=>'David Chen','role'=>'COO, Precision Components Ltd','col'=>'#0F172A'],
        ['text'=>'Rohan helped us see our data strategy through a completely different lens. What we thought was a technology problem turned out to be a governance and culture problem. The diagnosis alone was worth the engagement fee.','name'=>'Nadia Rossi','role'=>'CDTO, HarbourPoint Financial','col'=>'#1D4ED8'],
      ];
      foreach($co_testis as $t):
      ?>
      <div class="co-testi co-reveal">
        <div class="co-testi__stars"><?php echo str_repeat('<span class="co-star">★</span>',5); ?></div>
        <p class="co-testi__text"><?php echo $t['text']; ?></p>
        <div class="co-testi__author">
          <div class="co-testi__avatar" style="background:<?php echo $t['col']; ?>"><?php echo mb_substr($t['name'],0,1); ?></div>
          <div>
            <div class="co-testi__name"><?php echo $t['name']; ?></div>
            <div class="co-testi__role"><?php echo $t['role']; ?></div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>

    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     FAQ
════════════════════════════════════════ -->
<section class="co-section co-faq" id="faq">
  <div class="co-wrap">
    <div class="co-hgroup co-center">
      <p class="co-eyebrow">FAQ</p>
      <h2 class="co-h2">Common Questions</h2>
    </div>
    <div class="co-faq__list">

      <?php
      $co_faqs = [
        ['q'=>'How quickly can we get started?','a'=>'We can typically begin an engagement within two to three weeks of signing the agreement. We\'ll schedule an onboarding call within 48 hours of receipt of contract to align on access, stakeholders, and logistics so that no time is lost.'],
        ['q'=>'Do you work with SMEs or only large corporates?','a'=>'We work with ambitious organisations of all sizes — from £5M turnover owner-managed businesses to FTSE 250 groups. The size of the engagement scales with the organisation; the quality of thinking and seniority of the team does not.'],
        ['q'=>'How do you measure and report impact?','a'=>'We agree a measurement framework at the outset — defining the KPIs that will prove the value of the engagement. We track and report against these metrics monthly, and conduct a formal impact audit at engagement close.'],
        ['q'=>'What industries do you specialise in?','a'=>'We have the deepest expertise in retail & consumer, professional services, manufacturing, and financial services — but our strategic and operational methodologies are sector-agnostic. We\'ve delivered results across 18 industries in the past five years.'],
        ['q'=>'How do you price your engagements?','a'=>'Our engagement models are outlined above. For bespoke programmes, we scope based on the complexity, duration, and team configuration required. We are transparent on fees and do not levy unexpected overages — our quotes are fixed-price wherever possible.'],
        ['q'=>'Can we start with a smaller commitment to test the relationship?','a'=>'Absolutely. Our Strategy Sprint is designed precisely for this — a bounded, high-value engagement that delivers tangible output in four weeks and gives both parties a chance to assess the fit before committing to a longer programme.'],
      ];
      foreach($co_faqs as $i => $faq):
      ?>
      <div class="co-faq-item">
        <button class="co-faq-q" aria-expanded="false">
          <?php echo $faq['q']; ?>
          <span class="co-faq-icon" aria-hidden="true">+</span>
        </button>
        <div class="co-faq-a" role="region">
          <p><?php echo $faq['a']; ?></p>
        </div>
      </div>
      <?php endforeach; ?>

    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     CONTACT
════════════════════════════════════════ -->
<section class="co-section co-contact co-section--dark" id="contact">
  <div class="co-wrap">
    <div class="co-contact__inner">
      <div class="co-contact__info">
        <p class="co-eyebrow">Get In Touch</p>
        <h2 class="co-h2">Start a Conversation</h2>
        <p class="co-lead">Tell us about your challenge. We'll respond within one working day with an honest assessment of how — and whether — we can help.</p>
        <div class="co-contact__item">
          <div class="co-contact__item-icon">📍</div>
          <div class="co-contact__item-text">
            <strong>Offices</strong>
            <span>London (HQ) · Manchester · Edinburgh · Brussels</span>
          </div>
        </div>
        <div class="co-contact__item">
          <div class="co-contact__item-icon">✉️</div>
          <div class="co-contact__item-text">
            <strong>Email</strong>
            <span>enquiries@webboseigroup.com</span>
          </div>
        </div>
        <div class="co-contact__item">
          <div class="co-contact__item-icon">📞</div>
          <div class="co-contact__item-text">
            <strong>Phone</strong>
            <span>+44 20 7946 0800</span>
          </div>
        </div>
        <div class="co-contact__item">
          <div class="co-contact__item-icon">🕐</div>
          <div class="co-contact__item-text">
            <strong>Response Time</strong>
            <span>Within 1 working day, guaranteed</span>
          </div>
        </div>
      </div>

      <div class="co-form">
        <form method="post" action="">
          <?php wp_nonce_field('tf_co_booking','tf_co_nonce'); ?>
          <div class="co-form-row">
            <div class="co-field">
              <label for="co-fname">First Name *</label>
              <input type="text" id="co-fname" name="co_fname" placeholder="Marcus" required>
            </div>
            <div class="co-field">
              <label for="co-lname">Last Name *</label>
              <input type="text" id="co-lname" name="co_lname" placeholder="Webb" required>
            </div>
          </div>
          <div class="co-field">
            <label for="co-email">Business Email *</label>
            <input type="email" id="co-email" name="co_email" placeholder="you@company.com" required>
          </div>
          <div class="co-form-row">
            <div class="co-field">
              <label for="co-company">Company Name *</label>
              <input type="text" id="co-company" name="co_company" placeholder="Acme Ltd" required>
            </div>
            <div class="co-field">
              <label for="co-revenue">Annual Revenue</label>
              <select id="co-revenue" name="co_revenue">
                <option value="">Select range…</option>
                <option>Under £5M</option>
                <option>£5M – £25M</option>
                <option>£25M – £100M</option>
                <option>£100M – £500M</option>
                <option>Over £500M</option>
              </select>
            </div>
          </div>
          <div class="co-field">
            <label for="co-service">Area of Interest</label>
            <select id="co-service" name="co_service">
              <option value="">Select service…</option>
              <option>Strategy &amp; Growth</option>
              <option>Operational Excellence</option>
              <option>Innovation &amp; Transformation</option>
              <option>People &amp; Organisation</option>
              <option>Finance &amp; Performance</option>
              <option>Market Entry</option>
              <option>Not sure — I need a diagnosis</option>
            </select>
          </div>
          <div class="co-field">
            <label for="co-message">Tell Us About Your Challenge *</label>
            <textarea id="co-message" name="co_message" placeholder="Describe the problem or opportunity you're facing…" required></textarea>
          </div>
          <div class="co-field">
            <label for="co-budget">Indicative Budget</label>
            <select id="co-budget" name="co_budget">
              <option value="">Select range…</option>
              <option>Up to £20,000</option>
              <option>£20,000 – £50,000</option>
              <option>£50,000 – £150,000</option>
              <option>£150,000+</option>
              <option>Prefer to discuss</option>
            </select>
          </div>
          <button type="submit" class="co-btn co-btn--primary co-pkg__cta">Send Enquiry →</button>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     FOOTER CTA
════════════════════════════════════════ -->
<div class="co-footer-cta">
  <div class="co-wrap">
    <h2>Ready to Unlock Your Organisation's Potential?</h2>
    <p>Book a complimentary 60-minute diagnostic call with a senior partner. No sales pitch — just honest, expert thinking.</p>
    <a href="#contact" class="co-btn co-btn--amber">Book Your Free Discovery Call</a>
  </div>
</div>

</div><!-- .co-page -->

<!-- ============================================================
     SCRIPTS
     ============================================================ -->
<script>
(function(){
  'use strict';

  /* ── Animated Counters ── */
  function coEase(t){return 1-Math.pow(1-t,3)}
  document.querySelectorAll('.co-counter').forEach(function(el){
    var target = parseFloat(el.dataset.target);
    if(isNaN(target)) return;
    var prefix = el.dataset.prefix||'';
    var suffix = el.dataset.suffix||'';
    var isFloat = (target%1!==0);
    var started = false;
    var obs = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(entry.isIntersecting && !started){
          started = true;
          var start = performance.now();
          var dur = 1800;
          function tick(now){
            var t = Math.min((now-start)/dur,1);
            var val = coEase(t)*target;
            el.textContent = prefix+(isFloat?val.toFixed(1):Math.round(val))+suffix;
            if(t<1) requestAnimationFrame(tick);
          }
          requestAnimationFrame(tick);
          obs.disconnect();
        }
      });
    },{threshold:.3});
    obs.observe(el);
  });

  /* ── Scroll Reveal ── */
  var reveals = document.querySelectorAll('.co-reveal');
  if(reveals.length){
    var revObs = new IntersectionObserver(function(entries){
      entries.forEach(function(entry,i){
        if(entry.isIntersecting){
          setTimeout(function(){
            entry.target.classList.add('co-visible');
          }, i*80);
          revObs.unobserve(entry.target);
        }
      });
    },{threshold:.12});
    reveals.forEach(function(el){revObs.observe(el);});
  }

  /* ── FAQ Accordion ── */
  document.querySelectorAll('.co-faq-q').forEach(function(btn){
    btn.addEventListener('click',function(){
      var item = btn.closest('.co-faq-item');
      var answer = item.querySelector('.co-faq-a');
      var isOpen = item.classList.contains('co-open');
      /* close all */
      document.querySelectorAll('.co-faq-item.co-open').forEach(function(oi){
        oi.classList.remove('co-open');
        oi.querySelector('.co-faq-a').style.maxHeight='0';
        oi.querySelector('.co-faq-q').setAttribute('aria-expanded','false');
      });
      if(!isOpen){
        item.classList.add('co-open');
        answer.style.maxHeight = answer.scrollHeight+'px';
        btn.setAttribute('aria-expanded','true');
      }
    });
  });

  /* ── Smooth scroll for anchor links ── */
  document.querySelectorAll('a[href^="#"]').forEach(function(a){
    a.addEventListener('click',function(e){
      var target = document.querySelector(a.getAttribute('href'));
      if(target){e.preventDefault();target.scrollIntoView({behavior:'smooth',block:'start'});}
    });
  });

})();
</script>

<?php get_footer(); ?>
