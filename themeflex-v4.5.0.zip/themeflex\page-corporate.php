<?php
/**
 * Template Name: Corporate Homepage
 * Template Post Type: page
 *
 * Premium dark-first Corporate landing page — professional multi-column hero
 * with CSS dashboard art, animated stats bar, services overview, case studies
 * grid, leadership team, client logos marquee, testimonials, CTA banner.
 * Zero Elementor dependency. Vanilla CSS + minimal inline JS.
 *
 * @package ThemeFlex
 * @since   2.8.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
get_header(); ?>

<main id="primary" class="tf-corp-page" aria-label="<?php esc_attr_e( 'Corporate Homepage', 'themeflex' ); ?>">
<style>
/* ══════════════════════════════════════════════════════════════════════
   ThemeFlex — Corporate Homepage Template
   Scoped under .tf-corp-page — zero global overrides
   ══════════════════════════════════════════════════════════════════════ */

.tf-corp-page {
  --corp-bg:      #06021d;
  --corp-bg2:     #0a0f1e;
  --corp-bg3:     #0f1623;
  --corp-bg4:     #111827;
  --corp-accent:  #2563eb;
  --corp-accent2: #3b82f6;
  --corp-gold:    #f59e0b;
  --corp-green:   #10b981;
  --corp-border:  rgba(255,255,255,.07);
  --corp-title:   #f1f5f9;
  --corp-txt:     #94a3b8;
  --corp-meta:    #64748b;
  --corp-r:       12px;
  font-family: 'Inter Tight', system-ui, sans-serif;
  background: var(--corp-bg);
  color: var(--corp-txt);
  overflow-x: hidden;
}

/* ── Layout helpers ── */
.tf-corp-section { padding: 96px 0; }
.tf-corp-section--alt { background: var(--corp-bg2); }
.tf-corp-section--dark { background: var(--corp-bg3); }
.tf-corp-container { max-width: 1200px; margin: 0 auto; padding: 0 24px; }
.tf-corp-label {
  display: inline-flex; align-items: center; gap: 8px;
  font-size: .75rem; font-weight: 600; letter-spacing: .12em;
  text-transform: uppercase; color: var(--corp-accent2);
  margin-bottom: 16px;
}
.tf-corp-label svg { width: 14px; height: 14px; }
.tf-corp-title {
  font-size: clamp(2rem, 4vw, 3rem); font-weight: 800;
  line-height: 1.15; color: var(--corp-title); margin: 0 0 20px;
}
.tf-corp-title .tf-corp-accent { color: var(--corp-accent2); }
.tf-corp-body { font-size: 1.0625rem; line-height: 1.75; color: var(--corp-txt); max-width: 560px; }
.tf-corp-btn {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 13px 28px; border-radius: 8px; font-weight: 600;
  font-size: .9375rem; text-decoration: none; transition: all .2s;
}
.tf-corp-btn--primary { background: var(--corp-accent); color: #fff; }
.tf-corp-btn--primary:hover { background: var(--corp-accent2); transform: translateY(-1px); }
.tf-corp-btn--outline {
  background: transparent; color: var(--corp-title);
  border: 1px solid var(--corp-border);
}
.tf-corp-btn--outline:hover { border-color: var(--corp-accent2); color: var(--corp-accent2); }
.tf-corp-card {
  background: var(--corp-bg2); border: 1px solid var(--corp-border);
  border-radius: var(--corp-r); padding: 28px; transition: all .25s;
}
.tf-corp-card:hover { border-color: rgba(37,99,235,.3); transform: translateY(-2px); }

/* ══════════════════════════════
   §1 HERO
   ══════════════════════════════ */
.tf-corp-hero {
  padding: 100px 0 80px;
  background: var(--corp-bg);
  position: relative; overflow: hidden;
}
.tf-corp-hero::before {
  content: '';
  position: absolute; inset: 0;
  background: radial-gradient(ellipse 70% 60% at 60% 40%, rgba(37,99,235,.12) 0%, transparent 70%);
  pointer-events: none;
}
.tf-corp-hero-inner {
  display: grid; grid-template-columns: 1fr 480px; gap: 64px;
  align-items: center; position: relative;
}
.tf-corp-hero-badge {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(37,99,235,.12); border: 1px solid rgba(37,99,235,.25);
  border-radius: 100px; padding: 6px 14px;
  font-size: .75rem; font-weight: 600; color: var(--corp-accent2);
  margin-bottom: 24px;
}
.tf-corp-hero-title {
  font-size: clamp(2.25rem, 5vw, 3.75rem); font-weight: 800;
  line-height: 1.1; color: var(--corp-title); margin: 0 0 24px;
}
.tf-corp-hero-title span {
  background: linear-gradient(135deg, var(--corp-accent2), #60a5fa);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  background-clip: text;
}
.tf-corp-hero-sub {
  font-size: 1.125rem; line-height: 1.7; color: var(--corp-txt);
  max-width: 520px; margin: 0 0 36px;
}
.tf-corp-hero-actions { display: flex; gap: 14px; flex-wrap: wrap; }
.tf-corp-hero-trust {
  display: flex; align-items: center; gap: 12px;
  margin-top: 32px; padding-top: 32px;
  border-top: 1px solid var(--corp-border);
}
.tf-corp-hero-trust-avatars {
  display: flex;
}
.tf-corp-hero-trust-avatar {
  width: 32px; height: 32px; border-radius: 50%;
  border: 2px solid var(--corp-bg);
  background: linear-gradient(135deg, var(--corp-accent), #60a5fa);
  display: flex; align-items: center; justify-content: center;
  font-size: .6875rem; font-weight: 700; color: #fff;
  margin-left: -8px;
}
.tf-corp-hero-trust-avatar:first-child { margin-left: 0; }
.tf-corp-hero-trust-text { font-size: .875rem; color: var(--corp-txt); }
.tf-corp-hero-trust-text strong { color: var(--corp-title); }

/* CSS Dashboard Mockup */
.tf-corp-dashboard {
  background: var(--corp-bg2); border: 1px solid var(--corp-border);
  border-radius: 16px; overflow: hidden; box-shadow: 0 32px 80px rgba(0,0,0,.5);
}
.tf-corp-dash-topbar {
  background: var(--corp-bg3); padding: 12px 20px;
  display: flex; align-items: center; gap: 12px;
  border-bottom: 1px solid var(--corp-border);
}
.tf-corp-dash-dots { display: flex; gap: 6px; }
.tf-corp-dash-dot {
  width: 10px; height: 10px; border-radius: 50%;
}
.tf-corp-dash-dot:nth-child(1) { background: #ef4444; }
.tf-corp-dash-dot:nth-child(2) { background: var(--corp-gold); }
.tf-corp-dash-dot:nth-child(3) { background: var(--corp-green); }
.tf-corp-dash-title {
  font-size: .75rem; color: var(--corp-meta);
  margin: 0 auto 0 0;
}
.tf-corp-dash-body { padding: 20px; }
.tf-corp-dash-kpis {
  display: grid; grid-template-columns: repeat(3,1fr); gap: 10px;
  margin-bottom: 16px;
}
.tf-corp-dash-kpi {
  background: var(--corp-bg3); border: 1px solid var(--corp-border);
  border-radius: 8px; padding: 12px;
}
.tf-corp-dash-kpi-val {
  font-size: 1.25rem; font-weight: 800; color: var(--corp-title);
  display: block;
}
.tf-corp-dash-kpi-val--up { color: var(--corp-green); }
.tf-corp-dash-kpi-label { font-size: .6875rem; color: var(--corp-meta); }
/* Mini bar chart */
.tf-corp-dash-chart {
  background: var(--corp-bg3); border: 1px solid var(--corp-border);
  border-radius: 8px; padding: 14px; margin-bottom: 12px;
}
.tf-corp-dash-chart-title { font-size: .6875rem; color: var(--corp-meta); margin-bottom: 10px; }
.tf-corp-dash-bars {
  display: flex; align-items: flex-end; gap: 5px; height: 64px;
}
.tf-corp-dash-bar {
  flex: 1; border-radius: 3px 3px 0 0;
  background: rgba(37,99,235,.25);
  transition: height .4s ease;
}
.tf-corp-dash-bar--active { background: var(--corp-accent); }
/* Activity feed */
.tf-corp-dash-feed { display: flex; flex-direction: column; gap: 8px; }
.tf-corp-dash-feed-item {
  display: flex; align-items: center; gap: 10px;
  background: var(--corp-bg3); border: 1px solid var(--corp-border);
  border-radius: 6px; padding: 8px 10px;
}
.tf-corp-dash-feed-dot {
  width: 6px; height: 6px; border-radius: 50%;
  flex-shrink: 0;
}
.tf-corp-dash-feed-text { font-size: .6875rem; color: var(--corp-txt); }
.tf-corp-dash-feed-time { font-size: .625rem; color: var(--corp-meta); margin-left: auto; white-space: nowrap; }

/* ══════════════════════════════
   §2 STATS BAR
   ══════════════════════════════ */
.tf-corp-stats {
  background: var(--corp-bg3);
  border-top: 1px solid var(--corp-border);
  border-bottom: 1px solid var(--corp-border);
  padding: 48px 0;
}
.tf-corp-stats-grid {
  display: grid; grid-template-columns: repeat(4,1fr); gap: 0;
}
.tf-corp-stat {
  text-align: center; padding: 0 24px;
  border-right: 1px solid var(--corp-border);
}
.tf-corp-stat:last-child { border-right: none; }
.tf-corp-stat-val {
  font-size: 2.5rem; font-weight: 800;
  color: var(--corp-title); line-height: 1;
  display: block; margin-bottom: 6px;
}
.tf-corp-stat-suffix { color: var(--corp-accent2); }
.tf-corp-stat-label { font-size: .875rem; color: var(--corp-meta); }

/* ══════════════════════════════
   §3 SERVICES
   ══════════════════════════════ */
.tf-corp-services-grid {
  display: grid; grid-template-columns: repeat(3,1fr); gap: 24px;
  margin-top: 48px;
}
.tf-corp-service-card {
  background: var(--corp-bg2); border: 1px solid var(--corp-border);
  border-radius: var(--corp-r); padding: 32px;
  transition: all .25s; position: relative; overflow: hidden;
}
.tf-corp-service-card::before {
  content: ''; position: absolute; top: 0; left: 0; right: 0; height: 2px;
  background: var(--card-accent, var(--corp-accent));
  transform: scaleX(0); transform-origin: left; transition: transform .3s;
}
.tf-corp-service-card:hover::before { transform: scaleX(1); }
.tf-corp-service-card:hover { transform: translateY(-4px); border-color: rgba(37,99,235,.2); }
.tf-corp-service-icon {
  width: 48px; height: 48px; border-radius: 10px;
  background: var(--card-icon-bg, rgba(37,99,235,.1));
  display: flex; align-items: center; justify-content: center;
  margin-bottom: 20px;
  color: var(--card-accent, var(--corp-accent2));
}
.tf-corp-service-icon svg { width: 22px; height: 22px; }
.tf-corp-service-title {
  font-size: 1.125rem; font-weight: 700;
  color: var(--corp-title); margin: 0 0 10px;
}
.tf-corp-service-desc { font-size: .9375rem; line-height: 1.6; margin-bottom: 20px; }
.tf-corp-service-link {
  display: inline-flex; align-items: center; gap: 6px;
  font-size: .875rem; font-weight: 600;
  color: var(--card-accent, var(--corp-accent2));
  text-decoration: none; transition: gap .2s;
}
.tf-corp-service-link:hover { gap: 10px; }
.tf-corp-service-link svg { width: 14px; height: 14px; }

/* ══════════════════════════════
   §4 ABOUT / STORY SPLIT
   ══════════════════════════════ */
.tf-corp-about-inner {
  display: grid; grid-template-columns: 1fr 1fr; gap: 80px;
  align-items: center;
}
.tf-corp-milestones { margin-top: 32px; }
.tf-corp-milestone {
  display: flex; gap: 20px; margin-bottom: 28px;
  position: relative;
}
.tf-corp-milestone::before {
  content: '';
  position: absolute; left: 19px; top: 36px; bottom: -28px;
  width: 1px; background: var(--corp-border);
}
.tf-corp-milestone:last-child::before { display: none; }
.tf-corp-milestone-year {
  width: 40px; height: 40px; border-radius: 50%;
  background: rgba(37,99,235,.15); border: 1px solid rgba(37,99,235,.3);
  display: flex; align-items: center; justify-content: center;
  font-size: .6875rem; font-weight: 700; color: var(--corp-accent2);
  flex-shrink: 0;
}
.tf-corp-milestone-text {}
.tf-corp-milestone-title { font-size: 1rem; font-weight: 700; color: var(--corp-title); margin-bottom: 4px; }
.tf-corp-milestone-desc { font-size: .875rem; line-height: 1.6; }

/* CSS Office Mockup */
.tf-corp-office {
  position: relative;
}
.tf-corp-office-card {
  background: var(--corp-bg2); border: 1px solid var(--corp-border);
  border-radius: 16px; padding: 32px;
  box-shadow: 0 24px 64px rgba(0,0,0,.4);
}
.tf-corp-office-map {
  height: 180px; border-radius: 10px;
  background: var(--corp-bg3);
  position: relative; overflow: hidden;
  margin-bottom: 20px;
  display: flex; align-items: center; justify-content: center;
}
.tf-corp-office-map::before {
  content: '';
  position: absolute; inset: 0;
  background:
    repeating-linear-gradient(0deg, rgba(37,99,235,.04) 0, rgba(37,99,235,.04) 1px, transparent 1px, transparent 32px),
    repeating-linear-gradient(90deg, rgba(37,99,235,.04) 0, rgba(37,99,235,.04) 1px, transparent 1px, transparent 32px);
}
.tf-corp-office-map-pin {
  position: relative; z-index: 1;
  display: flex; flex-direction: column; align-items: center; gap: 4px;
}
.tf-corp-office-map-pin-dot {
  width: 16px; height: 16px; border-radius: 50%;
  background: var(--corp-accent);
  box-shadow: 0 0 0 6px rgba(37,99,235,.2);
  animation: corp-ping 2s ease-in-out infinite;
}
@keyframes corp-ping {
  0%, 100% { box-shadow: 0 0 0 4px rgba(37,99,235,.2); }
  50% { box-shadow: 0 0 0 10px rgba(37,99,235,.08); }
}
.tf-corp-office-map-pin-label {
  font-size: .6875rem; font-weight: 600; color: var(--corp-accent2);
  background: var(--corp-bg2); border: 1px solid var(--corp-border);
  padding: 2px 8px; border-radius: 4px;
}
.tf-corp-office-locations {
  display: grid; grid-template-columns: 1fr 1fr; gap: 10px;
}
.tf-corp-office-loc {
  background: var(--corp-bg3); border: 1px solid var(--corp-border);
  border-radius: 8px; padding: 12px;
  display: flex; align-items: center; gap: 10px;
}
.tf-corp-office-loc svg { width: 16px; height: 16px; color: var(--corp-accent2); flex-shrink: 0; }
.tf-corp-office-loc-city { font-size: .875rem; font-weight: 600; color: var(--corp-title); }
.tf-corp-office-loc-role { font-size: .75rem; color: var(--corp-meta); }
.tf-corp-office-float {
  position: absolute; top: -20px; right: -20px;
  background: var(--corp-bg2); border: 1px solid var(--corp-border);
  border-radius: 10px; padding: 14px 18px;
  display: flex; align-items: center; gap: 10px;
  box-shadow: 0 8px 24px rgba(0,0,0,.3);
}
.tf-corp-office-float-icon {
  width: 36px; height: 36px; border-radius: 8px;
  background: rgba(16,185,129,.12);
  display: flex; align-items: center; justify-content: center;
  color: var(--corp-green);
}
.tf-corp-office-float-icon svg { width: 18px; height: 18px; }
.tf-corp-office-float-val { font-size: 1.125rem; font-weight: 800; color: var(--corp-title); }
.tf-corp-office-float-sub { font-size: .6875rem; color: var(--corp-meta); }

/* ══════════════════════════════
   §5 CASE STUDIES
   ══════════════════════════════ */
.tf-corp-cases-header {
  display: flex; align-items: flex-end; justify-content: space-between;
  margin-bottom: 40px; flex-wrap: wrap; gap: 20px;
}
.tf-corp-cases-grid {
  display: grid; grid-template-columns: repeat(3,1fr); gap: 24px;
}
.tf-corp-case {
  background: var(--corp-bg2); border: 1px solid var(--corp-border);
  border-radius: var(--corp-r); overflow: hidden;
  transition: all .25s;
}
.tf-corp-case:hover { transform: translateY(-4px); border-color: rgba(37,99,235,.25); }
.tf-corp-case-img {
  height: 160px; position: relative; overflow: hidden;
  background: var(--corp-bg3);
  display: flex; align-items: center; justify-content: center;
}
.tf-corp-case-img-art {
  width: 100%; height: 100%;
  display: flex; align-items: center; justify-content: center;
}
.tf-corp-case-img-art svg { width: 40px; height: 40px; opacity: .15; }
.tf-corp-case-badge {
  position: absolute; top: 12px; left: 12px;
  background: rgba(37,99,235,.9); backdrop-filter: blur(8px);
  border-radius: 100px; padding: 4px 10px;
  font-size: .6875rem; font-weight: 700; color: #fff;
}
.tf-corp-case-body { padding: 20px; }
.tf-corp-case-client { font-size: .75rem; color: var(--corp-meta); margin-bottom: 6px; }
.tf-corp-case-title {
  font-size: 1.0625rem; font-weight: 700;
  color: var(--corp-title); margin: 0 0 10px; line-height: 1.4;
}
.tf-corp-case-result {
  font-size: .8125rem; line-height: 1.5; margin-bottom: 16px;
}
.tf-corp-case-metrics { display: flex; gap: 16px; }
.tf-corp-case-metric {}
.tf-corp-case-metric-val {
  font-size: 1.25rem; font-weight: 800; color: var(--corp-green);
  display: block; line-height: 1;
}
.tf-corp-case-metric-label { font-size: .6875rem; color: var(--corp-meta); }

/* ══════════════════════════════
   §6 CLIENTS MARQUEE
   ══════════════════════════════ */
.tf-corp-clients { padding: 60px 0; }
.tf-corp-clients-title {
  text-align: center; font-size: .875rem; color: var(--corp-meta);
  margin-bottom: 32px; text-transform: uppercase; letter-spacing: .08em;
}
.tf-corp-marquee-wrap { overflow: hidden; position: relative; }
.tf-corp-marquee-wrap::before,
.tf-corp-marquee-wrap::after {
  content: ''; position: absolute; top: 0; bottom: 0; width: 80px; z-index: 2;
}
.tf-corp-marquee-wrap::before { left: 0; background: linear-gradient(to right, var(--corp-bg2), transparent); }
.tf-corp-marquee-wrap::after  { right: 0; background: linear-gradient(to left, var(--corp-bg2), transparent); }
.tf-corp-marquee {
  display: flex; gap: 16px; width: max-content;
  animation: corp-marquee 28s linear infinite;
}
@keyframes corp-marquee { from { transform: translateX(0); } to { transform: translateX(-50%); } }
.tf-corp-marquee:hover { animation-play-state: paused; }
.tf-corp-client-chip {
  background: var(--corp-bg3); border: 1px solid var(--corp-border);
  border-radius: 8px; padding: 14px 24px; white-space: nowrap;
  display: flex; align-items: center; gap: 10px;
  font-size: .9375rem; font-weight: 700; color: var(--corp-meta);
  transition: all .2s;
}
.tf-corp-client-chip:hover { color: var(--corp-title); border-color: rgba(37,99,235,.3); }
.tf-corp-client-chip-icon {
  width: 28px; height: 28px; border-radius: 6px;
  display: flex; align-items: center; justify-content: center;
  font-size: .8125rem; font-weight: 800; color: #fff;
}

/* ══════════════════════════════
   §7 TEAM
   ══════════════════════════════ */
.tf-corp-team-grid {
  display: grid; grid-template-columns: repeat(4,1fr); gap: 24px;
  margin-top: 48px;
}
.tf-corp-team-card {
  background: var(--corp-bg2); border: 1px solid var(--corp-border);
  border-radius: var(--corp-r); padding: 28px 24px; text-align: center;
  transition: all .25s;
}
.tf-corp-team-card:hover { transform: translateY(-4px); border-color: rgba(37,99,235,.25); }
.tf-corp-team-avatar {
  width: 72px; height: 72px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: 1.25rem; font-weight: 800; color: #fff;
  margin: 0 auto 16px; font-family: 'Inter Tight', sans-serif;
}
.tf-corp-team-name { font-size: 1rem; font-weight: 700; color: var(--corp-title); margin-bottom: 4px; }
.tf-corp-team-role { font-size: .875rem; color: var(--corp-meta); margin-bottom: 16px; }
.tf-corp-team-socials { display: flex; justify-content: center; gap: 8px; }
.tf-corp-team-social {
  width: 32px; height: 32px; border-radius: 6px;
  background: var(--corp-bg3); border: 1px solid var(--corp-border);
  display: flex; align-items: center; justify-content: center;
  color: var(--corp-meta); transition: all .2s; text-decoration: none;
}
.tf-corp-team-social:hover { color: var(--corp-accent2); border-color: rgba(37,99,235,.3); }
.tf-corp-team-social svg { width: 14px; height: 14px; }

/* ══════════════════════════════
   §8 TESTIMONIALS
   ══════════════════════════════ */
.tf-corp-testi-grid {
  display: grid; grid-template-columns: repeat(3,1fr); gap: 24px;
  margin-top: 48px;
}
.tf-corp-testi {
  background: var(--corp-bg2); border: 1px solid var(--corp-border);
  border-radius: var(--corp-r); padding: 28px;
}
.tf-corp-testi-stars { display: flex; gap: 3px; margin-bottom: 16px; }
.tf-corp-testi-star { color: var(--corp-gold); }
.tf-corp-testi-star svg { width: 16px; height: 16px; }
.tf-corp-testi-text {
  font-size: .9375rem; line-height: 1.7;
  color: var(--corp-title); margin-bottom: 20px; font-style: italic;
}
.tf-corp-testi-meta { display: flex; align-items: center; gap: 12px; }
.tf-corp-testi-avatar {
  width: 40px; height: 40px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .75rem; font-weight: 800; color: #fff; flex-shrink: 0;
}
.tf-corp-testi-name { font-size: .9375rem; font-weight: 700; color: var(--corp-title); }
.tf-corp-testi-company { font-size: .8125rem; color: var(--corp-meta); }
.tf-corp-testi-badge {
  margin-left: auto; background: rgba(16,185,129,.1); border: 1px solid rgba(16,185,129,.2);
  border-radius: 100px; padding: 3px 10px;
  font-size: .6875rem; font-weight: 700; color: var(--corp-green);
}

/* ══════════════════════════════
   §9 CTA BANNER
   ══════════════════════════════ */
.tf-corp-cta {
  background: linear-gradient(135deg, rgba(37,99,235,.15) 0%, rgba(37,99,235,.05) 50%, transparent 100%);
  border: 1px solid rgba(37,99,235,.2);
  border-radius: 20px; padding: 64px;
  text-align: center; position: relative; overflow: hidden;
}
.tf-corp-cta::before {
  content: '';
  position: absolute; inset: 0;
  background: radial-gradient(ellipse 60% 80% at 50% 0%, rgba(37,99,235,.12) 0%, transparent 70%);
  pointer-events: none;
}
.tf-corp-cta-title {
  font-size: clamp(1.75rem, 3vw, 2.5rem); font-weight: 800;
  color: var(--corp-title); margin: 0 0 16px; position: relative;
}
.tf-corp-cta-sub {
  font-size: 1.0625rem; color: var(--corp-txt); max-width: 500px;
  margin: 0 auto 36px; position: relative;
}
.tf-corp-cta-actions { display: flex; gap: 14px; justify-content: center; flex-wrap: wrap; position: relative; }
.tf-corp-cta-meta {
  margin-top: 20px; font-size: .875rem; color: var(--corp-meta);
  display: flex; align-items: center; justify-content: center; gap: 20px;
}
.tf-corp-cta-meta-item { display: flex; align-items: center; gap: 6px; }
.tf-corp-cta-meta-item svg { width: 14px; height: 14px; color: var(--corp-green); }

/* ── Responsive ── */
@media (max-width:1024px) {
  .tf-corp-hero-inner { grid-template-columns: 1fr; }
  .tf-corp-dashboard { display: none; }
  .tf-corp-hero-title { font-size: 2.5rem; }
  .tf-corp-services-grid,
  .tf-corp-cases-grid { grid-template-columns: 1fr 1fr; }
  .tf-corp-team-grid { grid-template-columns: repeat(2,1fr); }
  .tf-corp-stats-grid { grid-template-columns: repeat(2,1fr); }
  .tf-corp-stat { border-bottom: 1px solid var(--corp-border); padding: 20px 24px; }
  .tf-corp-stat:nth-child(odd) { border-right: 1px solid var(--corp-border); }
  .tf-corp-stat:nth-child(even) { border-right: none; }
  .tf-corp-stat:nth-child(3),
  .tf-corp-stat:nth-child(4) { border-bottom: none; }
  .tf-corp-about-inner { grid-template-columns: 1fr; }
  .tf-corp-testi-grid { grid-template-columns: 1fr 1fr; }
}
@media (max-width:640px) {
  .tf-corp-section { padding: 64px 0; }
  .tf-corp-services-grid,
  .tf-corp-cases-grid,
  .tf-corp-team-grid,
  .tf-corp-testi-grid { grid-template-columns: 1fr; }
  .tf-corp-cta { padding: 40px 24px; }
  .tf-corp-office-float { display: none; }
}
</style>

<!-- ══════════════════════════════════════════════════════
     §1 HERO
     ══════════════════════════════════════════════════════ -->
<section class="tf-corp-hero" aria-label="<?php esc_attr_e( 'Hero', 'themeflex' ); ?>">
  <div class="tf-corp-container">
    <div class="tf-corp-hero-inner">

      <!-- Text Side -->
      <div class="tf-corp-hero-text">
        <div class="tf-corp-hero-badge" aria-label="<?php esc_attr_e( 'Award badge', 'themeflex' ); ?>">
          <?php echo tf_icon_get( 'award', 14 ); ?>
          <?php esc_html_e( 'Global Business Leader 2024', 'themeflex' ); ?>
        </div>
        <h1 class="tf-corp-hero-title">
          <?php esc_html_e( 'Building Enterprises', 'themeflex' ); ?><br>
          <span><?php esc_html_e( 'That Stand the Test', 'themeflex' ); ?></span><br>
          <?php esc_html_e( 'of Time', 'themeflex' ); ?>
        </h1>
        <p class="tf-corp-hero-sub">
          <?php esc_html_e( 'We partner with ambitious organizations worldwide to deliver strategic transformation, operational excellence, and sustainable growth that outlasts trends.', 'themeflex' ); ?>
        </p>
        <div class="tf-corp-hero-actions">
          <a href="#contact" class="tf-corp-btn tf-corp-btn--primary">
            <?php echo tf_icon_get( 'phone', 16 ); ?>
            <?php esc_html_e( 'Schedule a Consultation', 'themeflex' ); ?>
          </a>
          <a href="#case-studies" class="tf-corp-btn tf-corp-btn--outline">
            <?php echo tf_icon_get( 'folder-open', 16 ); ?>
            <?php esc_html_e( 'View Case Studies', 'themeflex' ); ?>
          </a>
        </div>
        <div class="tf-corp-hero-trust">
          <div class="tf-corp-hero-trust-avatars" aria-hidden="true">
            <?php
            $initials = [ ['MK', '#2563eb'], ['SR', '#7c3aed'], ['AL', '#0891b2'], ['TN', '#059669'], ['PW', '#dc2626'] ];
            foreach ( $initials as $i ) :
            ?>
              <div class="tf-corp-hero-trust-avatar" style="background:<?php echo esc_attr( $i[1] ); ?>"><?php echo esc_html( $i[0] ); ?></div>
            <?php endforeach; ?>
          </div>
          <p class="tf-corp-hero-trust-text">
            <?php esc_html_e( 'Trusted by', 'themeflex' ); ?>
            <strong><?php esc_html_e( '500+ executives', 'themeflex' ); ?></strong>
            <?php esc_html_e( 'across 45 countries', 'themeflex' ); ?>
          </p>
        </div>
      </div>

      <!-- CSS Dashboard Mockup -->
      <div class="tf-corp-dashboard" aria-hidden="true" role="presentation">
        <div class="tf-corp-dash-topbar">
          <div class="tf-corp-dash-dots">
            <div class="tf-corp-dash-dot"></div>
            <div class="tf-corp-dash-dot"></div>
            <div class="tf-corp-dash-dot"></div>
          </div>
          <span class="tf-corp-dash-title"><?php esc_html_e( 'Executive Dashboard', 'themeflex' ); ?></span>
          <?php echo tf_icon_get( 'refresh-cw', 12 ); ?>
        </div>
        <div class="tf-corp-dash-body">
          <!-- KPIs -->
          <div class="tf-corp-dash-kpis">
            <div class="tf-corp-dash-kpi">
              <span class="tf-corp-dash-kpi-val tf-corp-dash-kpi-val--up">$2.4B</span>
              <span class="tf-corp-dash-kpi-label"><?php esc_html_e( 'Revenue', 'themeflex' ); ?></span>
            </div>
            <div class="tf-corp-dash-kpi">
              <span class="tf-corp-dash-kpi-val">94%</span>
              <span class="tf-corp-dash-kpi-label"><?php esc_html_e( 'Retention', 'themeflex' ); ?></span>
            </div>
            <div class="tf-corp-dash-kpi">
              <span class="tf-corp-dash-kpi-val">+38%</span>
              <span class="tf-corp-dash-kpi-label"><?php esc_html_e( 'Growth YoY', 'themeflex' ); ?></span>
            </div>
          </div>
          <!-- Bar Chart -->
          <div class="tf-corp-dash-chart">
            <div class="tf-corp-dash-chart-title"><?php esc_html_e( 'Quarterly Performance', 'themeflex' ); ?></div>
            <div class="tf-corp-dash-bars">
              <?php
              $bars = [ ['Q1','55%',false], ['Q2','70%',false], ['Q3','60%',false], ['Q4','88%',true], ['Q5','75%',false], ['Q6','92%',true], ['Q7','80%',false], ['Q8','100%',true] ];
              foreach ( $bars as $b ) :
              ?>
                <div class="tf-corp-dash-bar<?php echo $b[2] ? ' tf-corp-dash-bar--active' : ''; ?>" style="height:<?php echo esc_attr($b[1]); ?>" title="<?php echo esc_attr($b[0]); ?>"></div>
              <?php endforeach; ?>
            </div>
          </div>
          <!-- Activity Feed -->
          <div class="tf-corp-dash-feed" role="list">
            <?php
            $feeds = [
              [ '#10b981', __('New enterprise contract signed — APAC', 'themeflex'), __('2m ago', 'themeflex') ],
              [ '#2563eb', __('Board presentation scheduled', 'themeflex'),           __('1h ago', 'themeflex') ],
              [ '#f59e0b', __('Q3 report review in progress', 'themeflex'),            __('3h ago', 'themeflex') ],
            ];
            foreach ( $feeds as $item ) :
            ?>
              <div class="tf-corp-dash-feed-item" role="listitem">
                <div class="tf-corp-dash-feed-dot" style="background:<?php echo esc_attr($item[0]); ?>"></div>
                <span class="tf-corp-dash-feed-text"><?php echo esc_html($item[1]); ?></span>
                <span class="tf-corp-dash-feed-time"><?php echo esc_html($item[2]); ?></span>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════════════════
     §2 STATS BAR
     ══════════════════════════════════════════════════════ -->
<section class="tf-corp-stats" aria-label="<?php esc_attr_e( 'Key statistics', 'themeflex' ); ?>">
  <div class="tf-corp-container">
    <div class="tf-corp-stats-grid">
      <?php
      $stats = [
        [ '30', '+', __( 'Years of Excellence', 'themeflex' ), 30 ],
        [ '500', '+', __( 'Enterprise Clients', 'themeflex' ), 500 ],
        [ '45', '',  __( 'Countries Served', 'themeflex' ), 45 ],
        [ '98', '%', __( 'Client Satisfaction', 'themeflex' ), 98 ],
      ];
      foreach ( $stats as $s ) :
      ?>
        <div class="tf-corp-stat">
          <span class="tf-corp-stat-val"
                data-counter="<?php echo esc_attr( $s[3] ); ?>"
                aria-label="<?php echo esc_attr( $s[0] . $s[1] ); ?>">
            0<span class="tf-corp-stat-suffix"><?php echo esc_html( $s[1] ); ?></span>
          </span>
          <span class="tf-corp-stat-label"><?php echo esc_html( $s[2] ); ?></span>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════════════════
     §3 SERVICES
     ══════════════════════════════════════════════════════ -->
<section class="tf-corp-section" aria-labelledby="corp-services-heading">
  <div class="tf-corp-container">
    <div class="tf-corp-label">
      <?php echo tf_icon_get( 'briefcase', 14 ); ?>
      <?php esc_html_e( 'What We Do', 'themeflex' ); ?>
    </div>
    <h2 id="corp-services-heading" class="tf-corp-title">
      <?php esc_html_e( 'End-to-End', 'themeflex' ); ?>
      <span class="tf-corp-accent"><?php esc_html_e( 'Corporate Solutions', 'themeflex' ); ?></span>
    </h2>
    <p class="tf-corp-body">
      <?php esc_html_e( 'From strategy through execution, our integrated service lines address every dimension of enterprise performance.', 'themeflex' ); ?>
    </p>
    <div class="tf-corp-services-grid">
      <?php
      $services = [
        [ 'strategy',        __( 'Corporate Strategy', 'themeflex' ),       __( 'Enterprise-wide roadmaps, competitive positioning, M&A advisory, and market entry strategy for sustained competitive advantage.', 'themeflex' ), '#2563eb', 'rgba(37,99,235,.1)' ],
        [ 'trending-up',     __( 'Financial Advisory', 'themeflex' ),       __( 'Capital structure optimization, treasury management, risk governance, and investor relations support for CFOs and boards.', 'themeflex' ), '#10b981', 'rgba(16,185,129,.1)' ],
        [ 'cpu',             __( 'Digital Transformation', 'themeflex' ),   __( 'Technology strategy, ERP implementations, cloud migration, and AI adoption frameworks that modernize your operations.', 'themeflex' ), '#7c3aed', 'rgba(124,58,237,.1)' ],
        [ 'users',           __( 'People & Organization', 'themeflex' ),    __( 'Leadership development, talent strategy, organizational redesign, and culture transformation to build high-performance teams.', 'themeflex' ), '#f59e0b', 'rgba(245,158,11,.1)' ],
        [ 'globe',           __( 'Global Operations', 'themeflex' ),        __( 'Supply chain optimization, procurement transformation, shared services setup, and operational excellence programmes.', 'themeflex' ), '#0891b2', 'rgba(8,145,178,.1)' ],
        [ 'shield-check',    __( 'Governance & Risk', 'themeflex' ),        __( 'Board advisory, ESG strategy, regulatory compliance, enterprise risk management, and crisis preparedness frameworks.', 'themeflex' ), '#dc2626', 'rgba(220,38,38,.1)' ],
      ];
      foreach ( $services as $svc ) :
      ?>
        <div class="tf-corp-service-card" style="--card-accent:<?php echo esc_attr($svc[3]); ?>; --card-icon-bg:<?php echo esc_attr($svc[4]); ?>">
          <div class="tf-corp-service-icon" aria-hidden="true">
            <?php echo tf_icon_get( $svc[0], 22 ); ?>
          </div>
          <h3 class="tf-corp-service-title"><?php echo esc_html( $svc[1] ); ?></h3>
          <p class="tf-corp-service-desc"><?php echo esc_html( $svc[2] ); ?></p>
          <a href="#contact" class="tf-corp-service-link">
            <?php esc_html_e( 'Learn more', 'themeflex' ); ?>
            <?php echo tf_icon_get( 'arrow-right', 14 ); ?>
          </a>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════════════════
     §4 ABOUT / STORY
     ══════════════════════════════════════════════════════ -->
<section class="tf-corp-section tf-corp-section--alt" aria-labelledby="corp-about-heading">
  <div class="tf-corp-container">
    <div class="tf-corp-about-inner">

      <!-- Story + Timeline -->
      <div>
        <div class="tf-corp-label">
          <?php echo tf_icon_get( 'book-open', 14 ); ?>
          <?php esc_html_e( 'Our Story', 'themeflex' ); ?>
        </div>
        <h2 id="corp-about-heading" class="tf-corp-title">
          <?php esc_html_e( 'Three Decades of', 'themeflex' ); ?><br>
          <span class="tf-corp-accent"><?php esc_html_e( 'Shaping Enterprises', 'themeflex' ); ?></span>
        </h2>
        <p class="tf-corp-body">
          <?php esc_html_e( 'Founded in 1994 with a single principle — that great strategy must be grounded in operational reality. Today we are a 2,000-person firm with offices across six continents.', 'themeflex' ); ?>
        </p>
        <div class="tf-corp-milestones" role="list">
          <?php
          $milestones = [
            [ '1994', __( 'Founded in Frankfurt', 'themeflex' ),       __( 'Started as a 12-person boutique advisory firm focused on mid-market restructuring in Germany and the Benelux.', 'themeflex' ) ],
            [ '2003', __( 'Global Expansion', 'themeflex' ),           __( 'Opened offices in New York, Singapore, and Dubai. Grew to 400 consultants across three practices.', 'themeflex' ) ],
            [ '2012', __( 'Digital Practice Launch', 'themeflex' ),    __( 'Established dedicated Digital Transformation practice. Named to Financial Times top management consultancies list for the first time.', 'themeflex' ) ],
            [ '2024', __( 'AI-First Advisory', 'themeflex' ),          __( 'Launched proprietary AI advisory platform. Over 500 enterprise clients, 2,000 consultants, operations in 45 countries.', 'themeflex' ) ],
          ];
          foreach ( $milestones as $ms ) :
          ?>
            <div class="tf-corp-milestone" role="listitem">
              <div class="tf-corp-milestone-year" aria-label="<?php echo esc_attr( $ms[0] ); ?>"><?php echo esc_html( $ms[0] ); ?></div>
              <div class="tf-corp-milestone-text">
                <div class="tf-corp-milestone-title"><?php echo esc_html( $ms[1] ); ?></div>
                <p><?php echo esc_html( $ms[2] ); ?></p>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- CSS Office / Global Presence Card -->
      <div class="tf-corp-office">
        <div class="tf-corp-office-card">
          <div class="tf-corp-office-map" aria-hidden="true" role="presentation">
            <div class="tf-corp-office-map-pin">
              <div class="tf-corp-office-map-pin-dot"></div>
              <div class="tf-corp-office-map-pin-label"><?php esc_html_e( 'Global HQ — Frankfurt', 'themeflex' ); ?></div>
            </div>
          </div>
          <div class="tf-corp-office-locations">
            <?php
            $offices = [
              [ 'map-pin', __('Frankfurt', 'themeflex'), __('Global HQ', 'themeflex') ],
              [ 'map-pin', __('New York', 'themeflex'),  __('Americas', 'themeflex') ],
              [ 'map-pin', __('Singapore', 'themeflex'), __('Asia-Pacific', 'themeflex') ],
              [ 'map-pin', __('Dubai', 'themeflex'),     __('Middle East', 'themeflex') ],
            ];
            foreach ( $offices as $off ) :
            ?>
              <div class="tf-corp-office-loc">
                <?php echo tf_icon_get( $off[0], 16 ); ?>
                <div>
                  <div class="tf-corp-office-loc-city"><?php echo esc_html( $off[1] ); ?></div>
                  <div class="tf-corp-office-loc-role"><?php echo esc_html( $off[2] ); ?></div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
        <!-- Float badge -->
        <div class="tf-corp-office-float" aria-hidden="true">
          <div class="tf-corp-office-float-icon">
            <?php echo tf_icon_get( 'users', 18 ); ?>
          </div>
          <div>
            <div class="tf-corp-office-float-val">2,000+</div>
            <div class="tf-corp-office-float-sub"><?php esc_html_e( 'Consultants worldwide', 'themeflex' ); ?></div>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════════════════
     §5 CASE STUDIES
     ══════════════════════════════════════════════════════ -->
<section id="case-studies" class="tf-corp-section" aria-labelledby="corp-cases-heading">
  <div class="tf-corp-container">
    <div class="tf-corp-cases-header">
      <div>
        <div class="tf-corp-label">
          <?php echo tf_icon_get( 'folder-open', 14 ); ?>
          <?php esc_html_e( 'Case Studies', 'themeflex' ); ?>
        </div>
        <h2 id="corp-cases-heading" class="tf-corp-title" style="margin:0">
          <?php esc_html_e( 'Proven', 'themeflex' ); ?>
          <span class="tf-corp-accent"><?php esc_html_e( 'Results', 'themeflex' ); ?></span>
        </h2>
      </div>
      <a href="#contact" class="tf-corp-btn tf-corp-btn--outline">
        <?php esc_html_e( 'All Case Studies', 'themeflex' ); ?>
        <?php echo tf_icon_get( 'arrow-right', 16 ); ?>
      </a>
    </div>
    <div class="tf-corp-cases-grid">
      <?php
      $cases = [
        [
          'bg'      => 'linear-gradient(135deg, #1e3a5f 0%, #0f2847 100%)',
          'icon'    => 'trending-up',
          'badge'   => __( 'Financial Services', 'themeflex' ),
          'client'  => __( 'Global Investment Bank', 'themeflex' ),
          'title'   => __( 'Cost Reduction & Operating Model Redesign', 'themeflex' ),
          'result'  => __( 'Led a two-year transformation program across 12 business units, delivering sustained OPEX reduction without compromising growth.', 'themeflex' ),
          'metrics' => [ ['+42%', __('EBITDA', 'themeflex')], ['€180M', __('Savings', 'themeflex')] ],
        ],
        [
          'bg'      => 'linear-gradient(135deg, #1a1a3e 0%, #0d0d2b 100%)',
          'icon'    => 'cpu',
          'badge'   => __( 'Manufacturing', 'themeflex' ),
          'client'  => __( 'European Industrial Group', 'themeflex' ),
          'title'   => __( 'Industry 4.0 Digital Transformation', 'themeflex' ),
          'result'  => __( 'End-to-end smart factory rollout across 8 production sites — IoT integration, AI quality control, and predictive maintenance platforms.', 'themeflex' ),
          'metrics' => [ ['+31%', __('Efficiency', 'themeflex')], ['24%', __('Defect Reduction', 'themeflex')] ],
        ],
        [
          'bg'      => 'linear-gradient(135deg, #1e1a00 0%, #2d2600 100%)',
          'icon'    => 'globe',
          'badge'   => __( 'Energy', 'themeflex' ),
          'client'  => __( 'MENA Energy Conglomerate', 'themeflex' ),
          'title'   => __( 'ESG Strategy & Sustainability Transformation', 'themeflex' ),
          'result'  => __( 'Developed and executed a 5-year ESG roadmap achieving Scope 1 & 2 carbon neutrality ahead of schedule with shareholder ROI intact.', 'themeflex' ),
          'metrics' => [ ['-55%', __('Carbon', 'themeflex')], ['AA', __('ESG Rating', 'themeflex')] ],
        ],
      ];
      foreach ( $cases as $case ) :
      ?>
        <article class="tf-corp-case">
          <div class="tf-corp-case-img" style="background:<?php echo esc_attr( $case['bg'] ); ?>" aria-hidden="true">
            <div class="tf-corp-case-img-art">
              <?php echo tf_icon_get( $case['icon'], 48 ); ?>
            </div>
            <div class="tf-corp-case-badge"><?php echo esc_html( $case['badge'] ); ?></div>
          </div>
          <div class="tf-corp-case-body">
            <div class="tf-corp-case-client"><?php echo esc_html( $case['client'] ); ?></div>
            <h3 class="tf-corp-case-title"><?php echo esc_html( $case['title'] ); ?></h3>
            <p class="tf-corp-case-result"><?php echo esc_html( $case['result'] ); ?></p>
            <div class="tf-corp-case-metrics">
              <?php foreach ( $case['metrics'] as $m ) : ?>
                <div class="tf-corp-case-metric">
                  <span class="tf-corp-case-metric-val"><?php echo esc_html( $m[0] ); ?></span>
                  <span class="tf-corp-case-metric-label"><?php echo esc_html( $m[1] ); ?></span>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════════════════
     §6 CLIENT LOGOS MARQUEE
     ══════════════════════════════════════════════════════ -->
<section class="tf-corp-clients tf-corp-section--alt" aria-label="<?php esc_attr_e( 'Our clients', 'themeflex' ); ?>">
  <div class="tf-corp-container">
    <p class="tf-corp-clients-title"><?php esc_html_e( 'Trusted by world-leading organizations', 'themeflex' ); ?></p>
  </div>
  <div class="tf-corp-marquee-wrap" aria-hidden="true" role="presentation">
    <?php
    $clients = [
      [ 'DT', '#e20074', 'Deutsche Telekom'  ],
      [ 'SB', '#1d4ed8', 'Siemens'           ],
      [ 'AL', '#0f766e', 'Allianz'            ],
      [ 'MU', '#b91c1c', 'Munich Re'          ],
      [ 'BA', '#1e40af', 'BASF'               ],
      [ 'VO', '#166534', 'Volkswagen'         ],
      [ 'BM', '#1e3a5f', 'BMW Group'          ],
      [ 'RW', '#7c3aed', 'RWE'                ],
      [ 'BT', '#374151', 'Bayer'              ],
      [ 'HE', '#0891b2', 'Henkel'             ],
    ];
    // Double for seamless loop
    $all = array_merge( $clients, $clients );
    ?>
    <div class="tf-corp-marquee">
      <?php foreach ( $all as $cl ) : ?>
        <div class="tf-corp-client-chip">
          <div class="tf-corp-client-chip-icon" style="background:<?php echo esc_attr( $cl[1] ); ?>">
            <?php echo esc_html( $cl[0] ); ?>
          </div>
          <?php echo esc_html( $cl[2] ); ?>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════════════════
     §7 LEADERSHIP TEAM
     ══════════════════════════════════════════════════════ -->
<section class="tf-corp-section" aria-labelledby="corp-team-heading">
  <div class="tf-corp-container">
    <div style="text-align:center; max-width:600px; margin:0 auto 48px;">
      <div class="tf-corp-label" style="justify-content:center">
        <?php echo tf_icon_get( 'users', 14 ); ?>
        <?php esc_html_e( 'Leadership', 'themeflex' ); ?>
      </div>
      <h2 id="corp-team-heading" class="tf-corp-title"><?php esc_html_e( 'The Team Behind the Results', 'themeflex' ); ?></h2>
      <p class="tf-corp-body" style="margin:0 auto">
        <?php esc_html_e( 'Our partners bring deep sector expertise and hands-on transformation experience from across the globe.', 'themeflex' ); ?>
      </p>
    </div>
    <div class="tf-corp-team-grid">
      <?php
      $team = [
        [ 'MK', '#2563eb', __( 'Dr. Marcus Klein', 'themeflex' ),    __( 'Managing Partner', 'themeflex' ),        __( 'Strategy & M&A', 'themeflex' ) ],
        [ 'SR', '#7c3aed', __( 'Sophia Rüdiger', 'themeflex' ),      __( 'Partner, Digital', 'themeflex' ),         __( 'Technology', 'themeflex' ) ],
        [ 'AT', '#0891b2', __( 'Alistair Thornton', 'themeflex' ),   __( 'Partner, Americas', 'themeflex' ),        __( 'Operations', 'themeflex' ) ],
        [ 'NP', '#059669', __( 'Neha Pillai', 'themeflex' ),         __( 'Partner, Asia-Pacific', 'themeflex' ),    __( 'People & Org', 'themeflex' ) ],
      ];
      foreach ( $team as $t ) :
      ?>
        <div class="tf-corp-team-card">
          <div class="tf-corp-team-avatar" style="background:<?php echo esc_attr($t[1]); ?>" aria-label="<?php echo esc_attr( $t[2] ); ?>">
            <?php echo esc_html( $t[0] ); ?>
          </div>
          <div class="tf-corp-team-name"><?php echo esc_html( $t[2] ); ?></div>
          <div class="tf-corp-team-role"><?php echo esc_html( $t[3] ); ?></div>
          <div class="tf-corp-team-role" style="font-size:.75rem; color:var(--corp-accent2)"><?php echo esc_html( $t[4] ); ?></div>
          <div class="tf-corp-team-socials">
            <a href="#" class="tf-corp-team-social" aria-label="<?php echo esc_attr( sprintf( __( '%s on LinkedIn', 'themeflex' ), $t[2] ) ); ?>">
              <?php echo tf_icon_get( 'linkedin', 14 ); ?>
            </a>
            <a href="#" class="tf-corp-team-social" aria-label="<?php echo esc_attr( sprintf( __( 'Email %s', 'themeflex' ), $t[2] ) ); ?>">
              <?php echo tf_icon_get( 'mail', 14 ); ?>
            </a>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════════════════
     §8 TESTIMONIALS
     ══════════════════════════════════════════════════════ -->
<section class="tf-corp-section tf-corp-section--alt" aria-labelledby="corp-testi-heading">
  <div class="tf-corp-container">
    <div style="text-align:center; max-width:600px; margin:0 auto 0;">
      <div class="tf-corp-label" style="justify-content:center">
        <?php echo tf_icon_get( 'message-square', 14 ); ?>
        <?php esc_html_e( 'Client Voices', 'themeflex' ); ?>
      </div>
      <h2 id="corp-testi-heading" class="tf-corp-title"><?php esc_html_e( 'What Our Clients Say', 'themeflex' ); ?></h2>
    </div>
    <div class="tf-corp-testi-grid">
      <?php
      $testis = [
        [
          'text'    => __( '"Their strategic acumen combined with an ability to mobilize entire organizations is exceptional. We achieved results in 18 months that would have taken us five years alone."', 'themeflex' ),
          'name'    => __( 'Friedrich Weber', 'themeflex' ),
          'company' => __( 'CEO, Industriegruppe Weber AG', 'themeflex' ),
          'color'   => '#2563eb',
          'initials'=> 'FW',
        ],
        [
          'text'    => __( '"Not just consultants — true partners. They challenged our thinking, brought world-class expertise, and stayed through implementation. The ROI has been outstanding."', 'themeflex' ),
          'name'    => __( 'Catherine Lemaire', 'themeflex' ),
          'company' => __( 'CFO, Groupe Energie SA', 'themeflex' ),
          'color'   => '#7c3aed',
          'initials'=> 'CL',
        ],
        [
          'text'    => __( '"In 30 years of working with advisory firms, this is the most impactful engagement I have experienced. The team operates as an extension of our own leadership."', 'themeflex' ),
          'name'    => __( 'Rajesh Nair', 'themeflex' ),
          'company' => __( 'Chairman, NairCorp International', 'themeflex' ),
          'color'   => '#059669',
          'initials'=> 'RN',
        ],
      ];
      foreach ( $testis as $t ) :
      ?>
        <div class="tf-corp-testi">
          <div class="tf-corp-testi-stars" aria-label="<?php esc_attr_e( '5 stars', 'themeflex' ); ?>">
            <?php for ( $i = 0; $i < 5; $i++ ) : ?>
              <span class="tf-corp-testi-star" aria-hidden="true">
                <?php echo tf_icon_get( 'star', 16 ); ?>
              </span>
            <?php endfor; ?>
          </div>
          <p class="tf-corp-testi-text"><?php echo esc_html( $t['text'] ); ?></p>
          <div class="tf-corp-testi-meta">
            <div class="tf-corp-testi-avatar" style="background:<?php echo esc_attr($t['color']); ?>" aria-hidden="true">
              <?php echo esc_html( $t['initials'] ); ?>
            </div>
            <div>
              <div class="tf-corp-testi-name"><?php echo esc_html( $t['name'] ); ?></div>
              <div class="tf-corp-testi-company"><?php echo esc_html( $t['company'] ); ?></div>
            </div>
            <span class="tf-corp-testi-badge"><?php esc_html_e( 'Verified Client', 'themeflex' ); ?></span>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════════════════
     §9 CTA BANNER
     ══════════════════════════════════════════════════════ -->
<section id="contact" class="tf-corp-section" aria-labelledby="corp-cta-heading">
  <div class="tf-corp-container">
    <div class="tf-corp-cta">
      <div class="tf-corp-label" style="justify-content:center">
        <?php echo tf_icon_get( 'calendar', 14 ); ?>
        <?php esc_html_e( 'Get Started', 'themeflex' ); ?>
      </div>
      <h2 id="corp-cta-heading" class="tf-corp-cta-title">
        <?php esc_html_e( 'Ready to Transform Your Business?', 'themeflex' ); ?>
      </h2>
      <p class="tf-corp-cta-sub">
        <?php esc_html_e( 'Schedule a confidential consultation with one of our senior partners. No commitment, just clarity on your next strategic move.', 'themeflex' ); ?>
      </p>
      <div class="tf-corp-cta-actions">
        <a href="tel:+496920000000" class="tf-corp-btn tf-corp-btn--primary">
          <?php echo tf_icon_get( 'phone', 16 ); ?>
          <?php esc_html_e( 'Call +49 69 2000 0000', 'themeflex' ); ?>
        </a>
        <a href="mailto:hello@example.com" class="tf-corp-btn tf-corp-btn--outline">
          <?php echo tf_icon_get( 'mail', 16 ); ?>
          <?php esc_html_e( 'Send an Enquiry', 'themeflex' ); ?>
        </a>
      </div>
      <div class="tf-corp-cta-meta">
        <div class="tf-corp-cta-meta-item">
          <?php echo tf_icon_get( 'check-circle', 14 ); ?>
          <?php esc_html_e( 'Response within 24 hours', 'themeflex' ); ?>
        </div>
        <div class="tf-corp-cta-meta-item">
          <?php echo tf_icon_get( 'check-circle', 14 ); ?>
          <?php esc_html_e( 'Senior partner access', 'themeflex' ); ?>
        </div>
        <div class="tf-corp-cta-meta-item">
          <?php echo tf_icon_get( 'check-circle', 14 ); ?>
          <?php esc_html_e( 'NDA available on request', 'themeflex' ); ?>
        </div>
      </div>
    </div>
  </div>
</section>

</main><!-- .tf-corp-page -->

<script>
/* ThemeFlex Corporate — Animated Counters (IntersectionObserver) */
(function() {
  'use strict';
  const counters = document.querySelectorAll('[data-counter]');
  if (!counters.length || !('IntersectionObserver' in window)) return;
  const obs = new IntersectionObserver(function(entries) {
    entries.forEach(function(entry) {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const target = parseInt(el.getAttribute('data-counter'), 10);
      const suffix = el.querySelector('.tf-corp-stat-suffix');
      const suffixText = suffix ? suffix.outerHTML : '';
      let start = 0;
      const duration = 1800;
      const step = Math.ceil(target / (duration / 16));
      const tick = function() {
        start = Math.min(start + step, target);
        el.innerHTML = start + suffixText;
        if (start < target) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      obs.unobserve(el);
    });
  }, { threshold: 0.5 });
  counters.forEach(function(c) { obs.observe(c); });
})();
</script>

<?php get_footer(); ?>
