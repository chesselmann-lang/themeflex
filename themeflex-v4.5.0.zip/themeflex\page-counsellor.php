<?php
/**
 * Template Name: Counsellor / Psychotherapist
 *
 * Premium landing page for a counsellor or psychotherapist.
 * Hero: CSS calm room scene — armchair, plant, abstract mind ripples, therapist figure.
 * Namespace: --cp-* | Fonts: Cormorant Garamond + Nunito | Palette: sage/indigo/warm cream
 *
 * @package ThemeFlex
 */

get_header(); ?>

<style>
/* ── Fonts ─────────────────────────────────────────────────── */
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;0,700;1,400&family=Nunito:wght@300;400;500;600;700&display=swap');

/* ── Token System ───────────────────────────────────────────── */
:root {
  --cp-sage:     #7E9E8A;
  --cp-sage-lt:  #A8C3B2;
  --cp-sage-dk:  #4A6B58;
  --cp-indigo:   #3D4F7C;
  --cp-indigo-lt:#6074A8;
  --cp-indigo-dk:#252F4A;
  --cp-warm:     #E8B89A;
  --cp-blush:    #F3D5C7;
  --cp-cream:    #FAF7F3;
  --cp-white:    #FFFFFF;
  --cp-text:     #1F1F2E;
  --cp-text-lt:  #5A5A72;
  --cp-shadow:   rgba(31,31,46,0.12);

  --cp-r:    8px;
  --cp-r-lg: 16px;
  --cp-r-xl: 24px;

  --ff-serif: 'Cormorant Garamond', Georgia, serif;
  --ff-body:  'Nunito', system-ui, sans-serif;
}

/* ── Reset ─────────────────────────────────────────────────── */
.cp-page *, .cp-page *::before, .cp-page *::after { box-sizing: border-box; margin: 0; padding: 0; }
.cp-page { font-family: var(--ff-body); color: var(--cp-text); background: var(--cp-cream); overflow-x: hidden; }
.cp-page a { color: inherit; text-decoration: none; }

/* ── Layout ─────────────────────────────────────────────────── */
.cp-wrap    { max-width: 1140px; margin: 0 auto; padding: 0 24px; }
.cp-section { padding: 80px 0; }
.cp-section--alt { background: var(--cp-white); }

/* ── Typography ─────────────────────────────────────────────── */
.cp-eyebrow {
  font-family: var(--ff-body); font-size: .75rem; font-weight: 700;
  letter-spacing: .12em; text-transform: uppercase; color: var(--cp-sage); margin-bottom: 10px;
}
.cp-h1 { font-family: var(--ff-serif); font-size: clamp(2.4rem,5vw,3.8rem); font-weight: 700; line-height: 1.15; }
.cp-h2 { font-family: var(--ff-serif); font-size: clamp(1.8rem,3.5vw,2.8rem); font-weight: 600; line-height: 1.2; margin-bottom: 16px; }
.cp-h3 { font-family: var(--ff-serif); font-size: 1.3rem; font-weight: 600; margin-bottom: 8px; }
.cp-lead { font-size: 1.08rem; line-height: 1.8; color: var(--cp-text-lt); }

/* ── Buttons ─────────────────────────────────────────────────── */
.cp-btn {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 14px 32px; border-radius: 50px; font-family: var(--ff-body);
  font-size: .95rem; font-weight: 600; cursor: pointer;
  transition: transform .2s, box-shadow .2s; border: none;
}
.cp-btn--primary {
  background: var(--cp-sage); color: var(--cp-white);
  box-shadow: 0 4px 18px rgba(126,158,138,.4);
}
.cp-btn--primary:hover { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(126,158,138,.55); }
.cp-btn--secondary {
  background: var(--cp-indigo); color: var(--cp-white);
  box-shadow: 0 4px 18px rgba(61,79,124,.35);
}
.cp-btn--secondary:hover { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(61,79,124,.45); }
.cp-btn--outline {
  background: transparent; color: var(--cp-white);
  border: 2px solid rgba(255,255,255,.65);
}
.cp-btn--outline:hover { background: rgba(255,255,255,.12); transform: translateY(-2px); }

/* ============================================================
   HERO — THERAPY ROOM SCENE
   ============================================================ */
.cp-hero {
  position: relative; overflow: hidden;
  min-height: 100vh; display: flex; align-items: center;
  background: linear-gradient(145deg,
    #252F4A 0%,
    #3D4F7C 40%,
    #4A6B58 75%,
    #7E9E8A 100%
  );
}

/* ── Concentric mind-calm ripples ── */
.cp-ripple {
  position: absolute; border-radius: 50%;
  border: 1.5px solid rgba(255,255,255,.12);
  top: 50%; left: 62%; transform: translate(-50%,-50%);
  animation: cp-ripple-pulse 6s ease-in-out infinite;
}
.cp-ripple--1 { width: 120px; height: 120px; animation-delay: 0s; }
.cp-ripple--2 { width: 220px; height: 220px; animation-delay: -.8s; }
.cp-ripple--3 { width: 340px; height: 340px; animation-delay: -1.6s; }
.cp-ripple--4 { width: 480px; height: 480px; animation-delay: -2.4s; }
.cp-ripple--5 { width: 640px; height: 640px; animation-delay: -3.2s; }
@keyframes cp-ripple-pulse {
  0%,100% { opacity: .35; transform: translate(-50%,-50%) scale(1); }
  50%      { opacity: .15; transform: translate(-50%,-50%) scale(1.04); }
}

/* ── Room elements ── */
/* Floor */
.cp-floor {
  position: absolute; bottom: 0; left: 0; right: 0; height: 30%;
  background: linear-gradient(180deg, #3D2E24 0%, #2A1F18 100%);
}
/* Skirting board */
.cp-floor::before {
  content:''; position: absolute; top: 0; left: 0; right: 0; height: 8px;
  background: #5D4037;
}
/* Wall */
.cp-wall {
  position: absolute; bottom: 30%; left: 0; right: 0; top: 0;
  background: linear-gradient(180deg, rgba(37,47,74,.6) 0%, rgba(74,107,88,.3) 100%);
}

/* Armchair */
.cp-armchair {
  position: absolute; bottom: 30%; right: 16%;
}
.cp-armchair__seat {
  width: 130px; height: 60px; border-radius: 12px 12px 0 0;
  background: linear-gradient(180deg, #8D6E63, #6D4C41);
  position: relative;
}
.cp-armchair__seat::before { /* seat cushion */
  content:''; position: absolute; inset: 6px;
  border-radius: 8px; background: #A1887F;
  box-shadow: inset 0 3px 6px rgba(0,0,0,.2);
}
.cp-armchair__back {
  width: 130px; height: 90px; border-radius: 12px 12px 0 0;
  background: linear-gradient(180deg, #6D4C41, #5D4037);
  position: relative; margin-top: -2px;
}
.cp-armchair__back::before { /* back cushion texture */
  content:''; position: absolute; inset: 8px;
  border-radius: 8px; background: #795548;
  box-shadow: inset 0 2px 8px rgba(0,0,0,.25);
}
/* Arm rests */
.cp-armchair__arm {
  position: absolute; width: 18px; height: 80px; border-radius: 6px;
  background: #5D4037; top: 0;
}
.cp-armchair__arm--l { left: -14px; }
.cp-armchair__arm--r { right: -14px; }
/* Legs */
.cp-armchair__legs { display: flex; justify-content: space-between; padding: 0 20px; }
.cp-armchair__leg  { width: 12px; height: 22px; background: #3E2723; border-radius: 0 0 4px 4px; }

/* Therapist in chair (seated figure) */
.cp-therapist {
  position: absolute; bottom: calc(30% + 58px); right: calc(16% + 22px);
  display: flex; flex-direction: column; align-items: center;
}
.cp-therapist__head {
  width: 30px; height: 34px; border-radius: 50%;
  background: #FFCCBC; position: relative;
}
.cp-therapist__head::before {
  content:''; position: absolute;
  width: 7px; height: 7px; border-radius: 50%;
  background: #4E342E; top: 40%; left: 18%;
  box-shadow: 10px 0 0 #4E342E;
}
.cp-therapist__hair {
  position: absolute; width: 34px; height: 18px;
  border-radius: 50% 50% 0 0; background: #5D4037;
  top: -8px; left: -2px;
}
/* Body — blouse / smart top */
.cp-therapist__body {
  width: 38px; height: 36px; border-radius: 6px 6px 0 0;
  background: var(--cp-sage); margin-top: -2px; position: relative;
}
/* Clipboard / notepad */
.cp-therapist__notepad {
  position: absolute; right: -22px; top: 4px;
  width: 20px; height: 26px; border-radius: 3px;
  background: #FFF9E3; border: 2px solid #BDBDBD;
  box-shadow: 2px 5px 0 -1px #E0E0E0, 2px 9px 0 -1px #E0E0E0;
}
.cp-therapist__lap {
  width: 50px; height: 18px; border-radius: 0 0 8px 8px;
  background: #546E7A; /* trousers */
}

/* Plant / monstera */
.cp-plant {
  position: absolute; bottom: 30%; right: 8%;
}
.cp-plant__pot {
  width: 38px; height: 28px; border-radius: 0 0 6px 6px;
  background: linear-gradient(180deg,#A0522D,#6D3A1A);
  clip-path: polygon(8% 0%,92% 0%,82% 100%,18% 100%);
}
.cp-plant__soil { width: 42px; height: 8px; background: #3E2723; border-radius: 50% 50% 0 0 / 100% 100% 0 0; margin-top: -4px; }
.cp-plant__stem {
  width: 4px; height: 50px; background: #4CAF50;
  border-radius: 2px; margin: 0 auto;
}
/* Monstera leaves via clip-path */
.cp-plant__leaf {
  position: absolute; border-radius: 0 60% 40% 60%;
  background: radial-gradient(circle at 30% 30%, #81C784, #2E7D32);
  box-shadow: 2px 2px 6px rgba(0,0,0,.2);
}
.cp-plant__leaf--1 { width: 50px; height: 36px; top: -28px; left: -36px; transform: rotate(-30deg); }
.cp-plant__leaf--2 { width: 44px; height: 32px; top: -36px; left: 2px;  transform: rotate(20deg);  }
.cp-plant__leaf--3 { width: 40px; height: 28px; top: -48px; left: -20px; transform: rotate(-60deg); }

/* Bookshelf */
.cp-shelf {
  position: absolute; bottom: calc(30% + 120px); left: 8%;
  width: 90px;
}
.cp-shelf__plank { height: 8px; background: #5D4037; border-radius: 2px; margin-bottom: 2px; }
.cp-shelf__books { display: flex; gap: 2px; margin-bottom: 8px; }
.cp-book {
  width: 12px; height: 52px; border-radius: 2px 2px 0 0;
  position: relative;
}
.cp-book:nth-child(1) { background: #7B1FA2; }
.cp-book:nth-child(2) { background: #1565C0; height: 44px; }
.cp-book:nth-child(3) { background: #2E7D32; }
.cp-book:nth-child(4) { background: #E65100; height: 48px; }
.cp-book:nth-child(5) { background: #37474F; }
.cp-book:nth-child(6) { background: #880E4F; height: 40px; }

/* Candle / diffuser on shelf */
.cp-candle {
  position: absolute; bottom: calc(30% + 128px); left: calc(8% + 70px);
}
.cp-candle__body { width: 12px; height: 24px; background: #F5F5DC; border-radius: 3px; }
.cp-candle__flame {
  width: 8px; height: 12px; background: radial-gradient(ellipse, #FFF9C4, #FF8F00);
  border-radius: 50% 50% 40% 40%;
  margin: -2px auto 0;
  animation: cp-flame-flicker .6s ease-in-out infinite alternate;
}
@keyframes cp-flame-flicker {
  from { transform: scaleY(1) rotate(-2deg); opacity: 1; }
  to   { transform: scaleY(.85) rotate(2deg); opacity: .85; }
}
/* Smoke wisps */
.cp-smoke {
  position: absolute; width: 3px; height: 20px;
  border-radius: 50%; top: -22px; left: 50%;
  transform: translateX(-50%);
  background: rgba(255,255,255,.3);
  animation: cp-smoke-rise 2s ease-out infinite;
}
@keyframes cp-smoke-rise {
  from { transform: translateX(-50%) translateY(0) scaleX(1); opacity: .5; }
  to   { transform: translateX(-40%) translateY(-24px) scaleX(2); opacity: 0; }
}

/* ── Stars / ambient particles ── */
.cp-star {
  position: absolute; border-radius: 50%;
  background: rgba(255,255,255,.6);
  animation: cp-star-twinkle 4s ease-in-out infinite;
}
@keyframes cp-star-twinkle {
  0%,100% { opacity: .6; transform: scale(1); }
  50%      { opacity: .2; transform: scale(.7); }
}

/* ── Hero content ── */
.cp-hero__inner {
  position: relative; z-index: 10;
  max-width: 580px; padding: 40px 24px 40px 60px;
}
.cp-hero__tagline {
  display: inline-block; background: rgba(126,158,138,.25); backdrop-filter: blur(8px);
  color: var(--cp-sage-lt); border: 1px solid rgba(168,195,178,.3);
  border-radius: 50px; font-size: .8rem; font-weight: 600;
  padding: 6px 16px; letter-spacing: .08em; margin-bottom: 18px;
}
.cp-hero__title { color: var(--cp-white); text-shadow: 0 2px 20px rgba(0,0,0,.4); margin-bottom: 18px; }
.cp-hero__sub   { font-size: 1.1rem; color: rgba(255,255,255,.85); line-height: 1.75; margin-bottom: 30px; }
.cp-hero__ctas  { display: flex; gap: 14px; flex-wrap: wrap; }

/* Trust signals */
.cp-trust {
  display: flex; gap: 20px; flex-wrap: wrap; margin-top: 28px;
}
.cp-trust__item {
  display: flex; align-items: center; gap: 6px;
  font-size: .82rem; color: rgba(255,255,255,.75); font-weight: 500;
}
.cp-trust__item::before { content: '✓'; color: var(--cp-sage-lt); font-weight: 700; }

/* ============================================================
   STATS
   ============================================================ */
.cp-stats { background: var(--cp-indigo-dk); padding: 40px 0; }
.cp-stats__grid { display: grid; grid-template-columns: repeat(4,1fr); }
.cp-stat {
  text-align: center; padding: 16px;
  border-right: 1px solid rgba(255,255,255,.1);
}
.cp-stat:last-child { border-right: none; }
.cp-stat__number {
  font-family: var(--ff-serif); font-size: 2.6rem; font-weight: 700;
  color: var(--cp-sage-lt); line-height: 1;
}
.cp-stat__label { font-size: .82rem; color: rgba(255,255,255,.65); margin-top: 6px; }

/* ============================================================
   ABOUT
   ============================================================ */
.cp-about__grid { display: grid; grid-template-columns: 1fr 1fr; gap: 64px; align-items: center; }

.cp-about__visual {
  position: relative; height: 460px; border-radius: var(--cp-r-xl);
  overflow: hidden; box-shadow: 0 12px 48px var(--cp-shadow);
  background: linear-gradient(145deg, var(--cp-indigo-dk), var(--cp-indigo));
}
/* Abstract calm waves in visual card */
.cp-wave {
  position: absolute; border-radius: 50%;
  border: 1px solid rgba(126,158,138,.3);
  top: 50%; left: 50%; transform: translate(-50%,-50%);
  animation: cp-wave-expand 6s ease-out infinite;
}
.cp-wave--1 { width: 80px;  height: 80px;  animation-delay: 0s; }
.cp-wave--2 { width: 160px; height: 160px; animation-delay: -1.5s; }
.cp-wave--3 { width: 260px; height: 260px; animation-delay: -3s; }
.cp-wave--4 { width: 380px; height: 380px; animation-delay: -4.5s; }
@keyframes cp-wave-expand {
  0%   { opacity: .5; transform: translate(-50%,-50%) scale(.8); }
  100% { opacity: 0;  transform: translate(-50%,-50%) scale(1.2); }
}

.cp-about__name-card {
  position: absolute; bottom: 20px; left: 20px; right: 20px;
  background: rgba(255,255,255,.1); backdrop-filter: blur(12px);
  border: 1px solid rgba(255,255,255,.15);
  border-radius: var(--cp-r-lg); padding: 16px 20px;
}
.cp-about__name { font-family: var(--ff-serif); font-size: 1.5rem; color: var(--cp-white); font-weight: 600; margin-bottom: 4px; }
.cp-about__credential-pill {
  display: inline-block; background: var(--cp-sage); color: var(--cp-white);
  border-radius: 50px; font-size: .75rem; font-weight: 600; padding: 3px 12px;
}
.cp-about__cert {
  position: absolute; top: 16px; right: 16px;
  background: rgba(255,255,255,.12); border: 1px solid rgba(255,255,255,.2);
  color: rgba(255,255,255,.85);
  border-radius: var(--cp-r); padding: 8px 14px; font-size: .78rem; font-weight: 600;
}
/* Calm central orb in card */
.cp-orb {
  position: absolute; top: 50%; left: 50%; transform: translate(-50%,-55%);
  width: 100px; height: 100px; border-radius: 50%;
  background: radial-gradient(circle at 35% 35%, rgba(168,195,178,.6), rgba(126,158,138,.2));
  border: 2px solid rgba(168,195,178,.3);
  box-shadow: 0 0 40px rgba(126,158,138,.2);
  animation: cp-orb-breathe 5s ease-in-out infinite;
}
@keyframes cp-orb-breathe {
  0%,100% { transform: translate(-50%,-55%) scale(1); box-shadow: 0 0 40px rgba(126,158,138,.2); }
  50%      { transform: translate(-50%,-55%) scale(1.1); box-shadow: 0 0 60px rgba(126,158,138,.35); }
}

.cp-about__content { }
.cp-about__full-name { font-family: var(--ff-serif); font-size: 2rem; font-weight: 700; margin: 12px 0 6px; }
.cp-about__title {
  display: inline-block; background: rgba(126,158,138,.15); color: var(--cp-sage-dk);
  border-radius: 50px; font-size: .78rem; font-weight: 600; padding: 4px 14px; margin-bottom: 18px;
}
.cp-about__body { font-size: 1.02rem; line-height: 1.8; color: var(--cp-text-lt); margin-bottom: 16px; }
.cp-about__quals { list-style: none; margin-bottom: 28px; }
.cp-about__quals li {
  padding: 8px 0 8px 26px; border-bottom: 1px solid #EEE;
  font-size: .93rem; color: var(--cp-text-lt); position: relative;
}
.cp-about__quals li::before { content: '🌿'; position: absolute; left: 0; top: 8px; font-size: .8rem; }

/* ============================================================
   MODALITIES / APPROACHES
   ============================================================ */
.cp-approaches { background: var(--cp-indigo); padding: 72px 0; }
.cp-approaches .cp-eyebrow { color: var(--cp-sage-lt); }
.cp-approaches .cp-h2 { color: var(--cp-white); }
.cp-approaches__grid { display: grid; grid-template-columns: repeat(auto-fit,minmax(220px,1fr)); gap: 20px; margin-top: 40px; }
.cp-approach {
  background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.12);
  border-radius: var(--cp-r-lg); padding: 26px 22px;
  backdrop-filter: blur(8px); transition: background .2s;
}
.cp-approach:hover { background: rgba(255,255,255,.14); }
.cp-approach__icon  { font-size: 1.8rem; margin-bottom: 12px; display: block; }
.cp-approach__title { font-family: var(--ff-serif); font-size: 1.15rem; font-weight: 600; color: var(--cp-white); margin-bottom: 8px; }
.cp-approach__desc  { font-size: .88rem; line-height: 1.6; color: rgba(255,255,255,.7); }

/* ============================================================
   SERVICES / ISSUES
   ============================================================ */
.cp-services__grid { display: grid; grid-template-columns: repeat(auto-fit,minmax(260px,1fr)); gap: 24px; margin-top: 40px; }
.cp-service {
  background: var(--cp-white); border-radius: var(--cp-r-lg);
  padding: 28px; box-shadow: 0 4px 20px var(--cp-shadow);
  border-top: 4px solid var(--cp-sage);
  transition: transform .25s;
}
.cp-service:nth-child(3n+2) { border-top-color: var(--cp-indigo-lt); }
.cp-service:nth-child(3n)   { border-top-color: var(--cp-warm); }
.cp-service:hover { transform: translateY(-4px); }
.cp-service__icon  { font-size: 2rem; margin-bottom: 12px; display: block; }
.cp-service__title { font-family: var(--ff-serif); font-size: 1.2rem; font-weight: 600; margin-bottom: 8px; }
.cp-service__desc  { font-size: .92rem; line-height: 1.65; color: var(--cp-text-lt); }

/* ============================================================
   PROCESS
   ============================================================ */
.cp-process__steps { display: grid; grid-template-columns: repeat(5,1fr); gap: 0; margin-top: 48px; position: relative; }
.cp-process__steps::before {
  content:''; position: absolute;
  top: 32px; left: 10%; right: 10%; height: 2px;
  background: linear-gradient(90deg, var(--cp-sage), var(--cp-indigo-lt));
  z-index: 0;
}
.cp-step { text-align: center; position: relative; z-index: 1; padding: 0 12px; }
.cp-step__num {
  width: 64px; height: 64px; border-radius: 50%;
  background: var(--cp-sage); color: var(--cp-white);
  font-family: var(--ff-serif); font-size: 1.5rem; font-weight: 700;
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto 16px; box-shadow: 0 4px 16px rgba(126,158,138,.35);
}
.cp-step__title { font-family: var(--ff-serif); font-size: 1rem; font-weight: 600; margin-bottom: 6px; }
.cp-step__desc  { font-size: .82rem; line-height: 1.55; color: var(--cp-text-lt); }

/* ============================================================
   PACKAGES
   ============================================================ */
.cp-packages__grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 28px; margin-top: 48px; align-items: start; }
.cp-pkg {
  border-radius: var(--cp-r-xl); overflow: hidden;
  box-shadow: 0 6px 28px var(--cp-shadow); background: var(--cp-white);
  transition: transform .25s;
}
.cp-pkg:hover { transform: translateY(-4px); }
.cp-pkg--featured { transform: scale(1.04); box-shadow: 0 12px 48px rgba(61,79,124,.3); }
.cp-pkg--featured:hover { transform: scale(1.04) translateY(-4px); }

.cp-pkg__header { padding: 28px 28px 20px; text-align: center; }
.cp-pkg--single   .cp-pkg__header { background: linear-gradient(135deg,var(--cp-sage-lt),var(--cp-sage)); }
.cp-pkg--featured .cp-pkg__header { background: linear-gradient(135deg,var(--cp-indigo-lt),var(--cp-indigo-dk)); }
.cp-pkg--ongoing  .cp-pkg__header { background: linear-gradient(135deg,#A0527D,#6B2248); }

.cp-pkg__badge { display: inline-block; background: #FFD600; color: #333; border-radius: 50px; font-size: .72rem; font-weight: 700; padding: 3px 12px; margin-bottom: 10px; letter-spacing: .08em; text-transform: uppercase; }
.cp-pkg__name  { font-family: var(--ff-serif); font-size: 1.5rem; font-weight: 700; color: var(--cp-white); }
.cp-pkg__price { font-family: var(--ff-serif); font-size: 2.4rem; font-weight: 700; color: var(--cp-white); margin: 12px 0 4px; }
.cp-pkg__unit  { font-size: .82rem; color: rgba(255,255,255,.75); }

.cp-pkg__body { padding: 24px 28px 28px; }
.cp-pkg__desc { font-size: .92rem; color: var(--cp-text-lt); margin-bottom: 18px; line-height: 1.6; }
.cp-pkg__features { list-style: none; margin-bottom: 24px; }
.cp-pkg__features li { padding: 6px 0 6px 26px; position: relative; font-size: .9rem; color: var(--cp-text-lt); border-bottom: 1px solid #F5F5F5; }
.cp-pkg__features li::before { content:'✓'; position: absolute; left: 0; color: var(--cp-sage); font-weight: 700; }
.cp-pkg__cta { display: block; text-align: center; padding: 13px; border-radius: 50px; font-family: var(--ff-body); font-size: .95rem; font-weight: 600; cursor: pointer; border: none; transition: opacity .2s; color: var(--cp-white); }
.cp-pkg--single   .cp-pkg__cta { background: var(--cp-sage); }
.cp-pkg--featured .cp-pkg__cta { background: var(--cp-indigo); }
.cp-pkg--ongoing  .cp-pkg__cta { background: #880E4F; }
.cp-pkg__cta:hover { opacity: .88; }

/* ============================================================
   TESTIMONIALS
   ============================================================ */
.cp-testimonials { background: var(--cp-cream); }
.cp-testimonials__grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; margin-top: 40px; }
.cp-testi { background: var(--cp-white); border-radius: var(--cp-r-lg); padding: 28px; box-shadow: 0 4px 20px var(--cp-shadow); }
.cp-testi__stars { color: #FFD600; font-size: 1rem; margin-bottom: 12px; }
.cp-testi__quote { font-family: var(--ff-serif); font-size: 1.02rem; font-style: italic; line-height: 1.75; color: var(--cp-text-lt); margin-bottom: 16px; }
.cp-testi__author { font-weight: 600; font-size: .9rem; }
.cp-testi__meta   { font-size: .82rem; color: var(--cp-text-lt); }

/* ============================================================
   FAQs
   ============================================================ */
.cp-faqs__list { max-width: 780px; margin: 40px auto 0; }
.cp-faq { border-bottom: 1px solid #E5E5EE; }
.cp-faq__q {
  width: 100%; background: none; border: none; cursor: pointer;
  display: flex; justify-content: space-between; align-items: center;
  padding: 20px 0; font-family: var(--ff-serif); font-size: 1.1rem;
  font-weight: 600; color: var(--cp-text); text-align: left; gap: 16px;
}
.cp-faq__icon { font-size: 1.4rem; color: var(--cp-sage); transition: transform .3s; flex-shrink: 0; }
.cp-faq__q[aria-expanded="true"] .cp-faq__icon { transform: rotate(45deg); }
.cp-faq__a { display: none; padding: 0 0 20px; font-size: .97rem; line-height: 1.75; color: var(--cp-text-lt); }
.cp-faq__a.is-open { display: block; }

/* ============================================================
   BOOKING FORM
   ============================================================ */
.cp-booking { background: linear-gradient(145deg, var(--cp-indigo-dk), var(--cp-indigo)); padding: 80px 0; }
.cp-booking .cp-eyebrow { color: var(--cp-sage-lt); }
.cp-booking .cp-h2  { color: var(--cp-white); }
.cp-booking .cp-lead { color: rgba(255,255,255,.78); }

.cp-form { background: var(--cp-white); border-radius: var(--cp-r-xl); padding: 48px; margin-top: 40px; box-shadow: 0 12px 48px rgba(0,0,0,.25); }
.cp-form__grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
.cp-form__full { grid-column: 1/-1; }
.cp-label { display: block; font-size: .85rem; font-weight: 600; margin-bottom: 6px; color: var(--cp-text-lt); }
.cp-input, .cp-select, .cp-textarea {
  width: 100%; padding: 12px 16px;
  border: 1.5px solid #DDD; border-radius: var(--cp-r);
  font-family: var(--ff-body); font-size: .97rem; color: var(--cp-text);
  background: #FAFAFA; transition: border-color .2s;
}
.cp-input:focus, .cp-select:focus, .cp-textarea:focus { outline: none; border-color: var(--cp-sage); background: var(--cp-white); }
.cp-textarea { min-height: 120px; resize: vertical; }
.cp-form__submit { text-align: center; margin-top: 32px; }
.cp-form__note   { text-align: center; font-size: .82rem; color: var(--cp-text-lt); margin-top: 10px; }

/* ── Confidentiality note ── */
.cp-confidential {
  background: rgba(126,158,138,.12); border: 1px solid rgba(126,158,138,.25);
  border-radius: var(--cp-r); padding: 14px 18px; margin-top: 20px;
  font-size: .85rem; color: var(--cp-sage-dk); line-height: 1.6;
}
.cp-confidential strong { display: block; margin-bottom: 4px; }

/* ============================================================
   FOOTER CTA
   ============================================================ */
.cp-footer-cta {
  background: var(--cp-sage-dk); padding: 60px 0; text-align: center;
}
.cp-footer-cta .cp-h2  { color: var(--cp-white); margin-bottom: 10px; }
.cp-footer-cta .cp-lead { color: rgba(255,255,255,.82); margin-bottom: 28px; }

/* ============================================================
   SCROLL REVEAL
   ============================================================ */
.cp-reveal { opacity: 0; transform: translateY(28px); transition: opacity .65s, transform .65s; }
.cp-reveal.is-visible { opacity: 1; transform: none; }

/* ============================================================
   RESPONSIVE
   ============================================================ */
@media (max-width: 900px) {
  .cp-about__grid    { grid-template-columns: 1fr; }
  .cp-packages__grid { grid-template-columns: 1fr; }
  .cp-pkg--featured  { transform: none; }
  .cp-process__steps { grid-template-columns: repeat(2,1fr); }
  .cp-process__steps::before { display: none; }
  .cp-stats__grid    { grid-template-columns: 1fr 1fr; }
  .cp-testimonials__grid { grid-template-columns: 1fr; }
}
@media (max-width: 600px) {
  .cp-hero__inner { padding: 40px 24px; }
  .cp-form__grid  { grid-template-columns: 1fr; }
  .cp-approaches__grid { grid-template-columns: 1fr; }
  .cp-process__steps { grid-template-columns: 1fr; }
}
</style>

<div class="cp-page">

  <!-- ── HERO ─────────────────────────────────────────────── -->
  <section class="cp-hero" aria-label="Counsellor hero">

    <!-- Room elements -->
    <div class="cp-wall" aria-hidden="true"></div>
    <div class="cp-floor" aria-hidden="true"></div>

    <!-- Mind ripples -->
    <div class="cp-ripple cp-ripple--1" aria-hidden="true"></div>
    <div class="cp-ripple cp-ripple--2" aria-hidden="true"></div>
    <div class="cp-ripple cp-ripple--3" aria-hidden="true"></div>
    <div class="cp-ripple cp-ripple--4" aria-hidden="true"></div>
    <div class="cp-ripple cp-ripple--5" aria-hidden="true"></div>

    <!-- Ambient stars -->
    <?php
    srand(crc32('counsellor-stars'));
    for ($i = 0; $i < 18; $i++) {
      $top  = rand(5,75); $left = rand(45,95);
      $size = rand(2,5);  $delay = rand(0,40) / 10;
      echo '<div class="cp-star" aria-hidden="true" style="top:'.$top.'%;left:'.$left.'%;width:'.$size.'px;height:'.$size.'px;animation-delay:-'.$delay.'s;"></div>';
    }
    srand();
    ?>

    <!-- Bookshelf -->
    <div class="cp-shelf" aria-hidden="true">
      <div class="cp-shelf__books">
        <div class="cp-book"></div>
        <div class="cp-book"></div>
        <div class="cp-book"></div>
        <div class="cp-book"></div>
        <div class="cp-book"></div>
        <div class="cp-book"></div>
      </div>
      <div class="cp-shelf__plank"></div>
    </div>

    <!-- Candle -->
    <div class="cp-candle" aria-hidden="true">
      <div class="cp-candle__flame">
        <div class="cp-smoke"></div>
      </div>
      <div class="cp-candle__body"></div>
    </div>

    <!-- Armchair + therapist -->
    <div class="cp-armchair" aria-hidden="true">
      <div class="cp-armchair__back" style="position:relative;">
        <div class="cp-armchair__arm cp-armchair__arm--l"></div>
        <div class="cp-armchair__arm cp-armchair__arm--r"></div>
      </div>
      <div class="cp-armchair__seat"></div>
      <div class="cp-armchair__legs">
        <div class="cp-armchair__leg"></div>
        <div class="cp-armchair__leg"></div>
      </div>
    </div>
    <div class="cp-therapist" aria-hidden="true">
      <div class="cp-therapist__hair"></div>
      <div class="cp-therapist__head"></div>
      <div class="cp-therapist__body">
        <div class="cp-therapist__notepad"></div>
      </div>
      <div class="cp-therapist__lap"></div>
    </div>

    <!-- Plant -->
    <div class="cp-plant" aria-hidden="true">
      <div style="position:relative; width:4px; height:50px; background:#4CAF50; border-radius:2px; margin:0 auto;">
        <div class="cp-plant__leaf cp-plant__leaf--1"></div>
        <div class="cp-plant__leaf cp-plant__leaf--2"></div>
        <div class="cp-plant__leaf cp-plant__leaf--3"></div>
      </div>
      <div class="cp-plant__soil"></div>
      <div class="cp-plant__pot"></div>
    </div>

    <!-- Hero copy -->
    <div class="cp-hero__inner">
      <span class="cp-hero__tagline">BACP Accredited · 18+ Years Experience</span>
      <h1 class="cp-h1 cp-hero__title">
        A Space to Be<br><em>Truly Heard</em>
      </h1>
      <p class="cp-hero__sub">Compassionate, person-centred counselling and psychotherapy for adults navigating anxiety, depression, grief, trauma, and life transitions. Online and in-person, Bristol.</p>
      <div class="cp-hero__ctas">
        <a href="#booking" class="cp-btn cp-btn--primary">Begin Your Journey</a>
        <a href="#services" class="cp-btn cp-btn--outline">How I Can Help</a>
      </div>
      <div class="cp-trust">
        <div class="cp-trust__item">BACP Accredited</div>
        <div class="cp-trust__item">Fully Insured</div>
        <div class="cp-trust__item">Free 20-min call</div>
        <div class="cp-trust__item">Online &amp; In-person</div>
      </div>
    </div>
  </section>

  <!-- ── STATS ─────────────────────────────────────────────── -->
  <section class="cp-stats" aria-label="Key figures">
    <div class="cp-wrap">
      <div class="cp-stats__grid">
        <div class="cp-stat">
          <div class="cp-stat__number" data-target="18" aria-label="18 years experience">0</div>
          <div class="cp-stat__label">Years in Practice</div>
        </div>
        <div class="cp-stat">
          <div class="cp-stat__number" data-target="900" aria-label="900+ clients helped">0</div>
          <div class="cp-stat__label">People Supported</div>
        </div>
        <div class="cp-stat">
          <div class="cp-stat__number" data-target="4" data-float="1" aria-label="4.9 star rating">0</div>
          <div class="cp-stat__label">★ Average Rating</div>
        </div>
        <div class="cp-stat">
          <div class="cp-stat__number" data-target="92" aria-label="92% recommend">0</div>
          <div class="cp-stat__label">% Would Recommend</div>
        </div>
      </div>
    </div>
  </section>

  <!-- ── ABOUT ─────────────────────────────────────────────── -->
  <section class="cp-section cp-section--alt" id="about" aria-labelledby="cp-about-heading">
    <div class="cp-wrap">
      <div class="cp-about__grid">

        <div class="cp-about__visual cp-reveal" aria-hidden="true">
          <div class="cp-wave cp-wave--1"></div>
          <div class="cp-wave cp-wave--2"></div>
          <div class="cp-wave cp-wave--3"></div>
          <div class="cp-wave cp-wave--4"></div>
          <div class="cp-orb"></div>
          <div class="cp-about__cert">🏅 BACP Senior Accredited</div>
          <div class="cp-about__name-card">
            <div class="cp-about__name">Sarah Collingwood</div>
            <span class="cp-about__credential-pill">MBACP Accredited · MSc Counselling Psychology</span>
          </div>
        </div>

        <div class="cp-about__content cp-reveal">
          <p class="cp-eyebrow">Your Therapist</p>
          <h2 class="cp-about__full-name" id="cp-about-heading">Sarah Collingwood MBACP</h2>
          <span class="cp-about__title">MSc Counselling Psychology · Senior Accredited</span>
          <p class="cp-about__body">
            I believe that change begins when you feel genuinely understood — not diagnosed, not advised, but truly heard. My work is grounded in the Person-Centred approach with integrative elements drawn from CBT, psychodynamic thinking, and mindfulness-based practices.
          </p>
          <p class="cp-about__body">
            I see clients at my consulting room in Clifton, Bristol, and online via secure video. Whatever brings you here — anxiety, depression, grief, relationship difficulties, or simply a feeling that something isn't right — you will find a warm, non-judgmental space in which to explore it.
          </p>
          <ul class="cp-about__quals">
            <li>MSc Counselling Psychology, University of Bristol</li>
            <li>BACP Senior Accredited Member (MBACP Accred.)</li>
            <li>Certificate in Trauma-Informed Practice (EMDR)</li>
            <li>Gottman Level 2 — Couples Therapy</li>
            <li>Bereavement & Loss specialist training</li>
          </ul>
          <a href="#booking" class="cp-btn cp-btn--primary">Book a Free Consultation</a>
        </div>
      </div>
    </div>
  </section>

  <!-- ── APPROACHES / MODALITIES ───────────────────────────── -->
  <section class="cp-approaches" aria-labelledby="cp-approaches-heading">
    <div class="cp-wrap">
      <p class="cp-eyebrow">Therapeutic Approaches</p>
      <h2 class="cp-h2" id="cp-approaches-heading">How We Work Together</h2>
      <p class="cp-lead" style="color:rgba(255,255,255,.75)">An integrative approach means I draw on whichever modality best serves you — not one rigid model.</p>

      <div class="cp-approaches__grid">
        <div class="cp-approach cp-reveal">
          <span class="cp-approach__icon">🤝</span>
          <h3 class="cp-approach__title">Person-Centred</h3>
          <p class="cp-approach__desc">You are the expert on your own life. My role is to offer unconditional positive regard and a safe, non-directive space for you to explore at your pace.</p>
        </div>
        <div class="cp-approach cp-reveal">
          <span class="cp-approach__icon">🧠</span>
          <h3 class="cp-approach__title">CBT</h3>
          <p class="cp-approach__desc">Cognitive Behavioural Therapy helps identify unhelpful thought patterns and develop practical strategies for managing anxiety, depression, and stress.</p>
        </div>
        <div class="cp-approach cp-reveal">
          <span class="cp-approach__icon">⏪</span>
          <h3 class="cp-approach__title">Psychodynamic</h3>
          <p class="cp-approach__desc">Understanding how past experiences, relationships, and unconscious patterns shape present-day feelings and behaviour.</p>
        </div>
        <div class="cp-approach cp-reveal">
          <span class="cp-approach__icon">🌊</span>
          <h3 class="cp-approach__title">EMDR</h3>
          <p class="cp-approach__desc">Eye Movement Desensitisation and Reprocessing — an evidence-based treatment for trauma, PTSD, and distressing memories.</p>
        </div>
        <div class="cp-approach cp-reveal">
          <span class="cp-approach__icon">🧘</span>
          <h3 class="cp-approach__title">Mindfulness-Based</h3>
          <p class="cp-approach__desc">Developing present-moment awareness and compassionate attention towards your own thoughts, feelings, and bodily sensations.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- ── SERVICES / ISSUES ───────────────────────────────────── -->
  <section class="cp-section" id="services" aria-labelledby="cp-services-heading">
    <div class="cp-wrap">
      <p class="cp-eyebrow">Areas of Support</p>
      <h2 class="cp-h2" id="cp-services-heading">What I Work With</h2>
      <p class="cp-lead">Whether you're facing a specific crisis or a general sense that something is off — you are welcome here.</p>
      <div class="cp-services__grid">

        <article class="cp-service cp-reveal">
          <span class="cp-service__icon">😰</span>
          <h3 class="cp-service__title">Anxiety &amp; Panic</h3>
          <p class="cp-service__desc">Generalised anxiety, panic disorder, social anxiety, health anxiety, and phobias — understanding and gently dismantling the cycles that keep you stuck.</p>
        </article>

        <article class="cp-service cp-reveal">
          <span class="cp-service__icon">🌧️</span>
          <h3 class="cp-service__title">Depression</h3>
          <p class="cp-service__desc">Low mood, emptiness, loss of motivation, persistent sadness — exploring what lies beneath and rebuilding connection with yourself and your life.</p>
        </article>

        <article class="cp-service cp-reveal">
          <span class="cp-service__icon">💔</span>
          <h3 class="cp-service__title">Grief &amp; Loss</h3>
          <p class="cp-service__desc">Bereavement, relationship endings, job loss, identity loss, infertility — all losses deserve space. There is no timeline for grief.</p>
        </article>

        <article class="cp-service cp-reveal">
          <span class="cp-service__icon">⚡</span>
          <h3 class="cp-service__title">Trauma &amp; PTSD</h3>
          <p class="cp-service__desc">Trauma-informed therapy at a pace that feels safe — for acute incidents, childhood trauma, complex PTSD, and the effects of long-term stress.</p>
        </article>

        <article class="cp-service cp-reveal">
          <span class="cp-service__icon">👥</span>
          <h3 class="cp-service__title">Relationship Issues</h3>
          <p class="cp-service__desc">Individual therapy to explore patterns in relationships — attachment, communication, intimacy, boundaries, and breaking cycles that no longer serve you.</p>
        </article>

        <article class="cp-service cp-reveal">
          <span class="cp-service__icon">🔄</span>
          <h3 class="cp-service__title">Life Transitions</h3>
          <p class="cp-service__desc">Career change, parenthood, retirement, illness, identity shifts — navigating the disorientation of change with clarity and support.</p>
        </article>

        <article class="cp-service cp-reveal">
          <span class="cp-service__icon">🪞</span>
          <h3 class="cp-service__title">Self-Esteem &amp; Identity</h3>
          <p class="cp-service__desc">Perfectionism, inner critic, imposter syndrome, low self-worth, and questions of identity — learning to relate to yourself with more kindness and compassion.</p>
        </article>

        <article class="cp-service cp-reveal">
          <span class="cp-service__icon">🏳️‍🌈</span>
          <h3 class="cp-service__title">LGBTQ+ Affirmative</h3>
          <p class="cp-service__desc">A fully inclusive, gender and sexuality-affirming space. I have specialist experience working with gender identity, coming out, and minority stress.</p>
        </article>

      </div>
    </div>
  </section>

  <!-- ── PROCESS ────────────────────────────────────────────── -->
  <section class="cp-section cp-section--alt" aria-labelledby="cp-process-heading">
    <div class="cp-wrap">
      <p class="cp-eyebrow" style="text-align:center">Starting Therapy</p>
      <h2 class="cp-h2" id="cp-process-heading" style="text-align:center">What Happens Next</h2>
      <div class="cp-process__steps">
        <div class="cp-step cp-reveal">
          <div class="cp-step__num">1</div>
          <h3 class="cp-step__title">Free Consultation</h3>
          <p class="cp-step__desc">A 20-minute phone or video call to discuss what's brought you here and how I might help.</p>
        </div>
        <div class="cp-step cp-reveal">
          <div class="cp-step__num">2</div>
          <h3 class="cp-step__title">Assessment Session</h3>
          <p class="cp-step__desc">A 50-minute initial assessment exploring your background, current difficulties, and therapy goals.</p>
        </div>
        <div class="cp-step cp-reveal">
          <div class="cp-step__num">3</div>
          <h3 class="cp-step__title">Regular Sessions</h3>
          <p class="cp-step__desc">Weekly 50-minute sessions at a consistent time — the regularity matters as much as the content.</p>
        </div>
        <div class="cp-step cp-reveal">
          <div class="cp-step__num">4</div>
          <h3 class="cp-step__title">Review &amp; Progress</h3>
          <p class="cp-step__desc">Regular reviews to ensure the work is moving in a direction that feels meaningful to you.</p>
        </div>
        <div class="cp-step cp-reveal">
          <div class="cp-step__num">5</div>
          <h3 class="cp-step__title">Thoughtful Ending</h3>
          <p class="cp-step__desc">When you're ready, we plan a careful, supported ending that consolidates the work you've done.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- ── PACKAGES ───────────────────────────────────────────── -->
  <section class="cp-section" id="packages" aria-labelledby="cp-packages-heading">
    <div class="cp-wrap">
      <p class="cp-eyebrow" style="text-align:center">Fees</p>
      <h2 class="cp-h2" id="cp-packages-heading" style="text-align:center">Therapy Options</h2>
      <p class="cp-lead" style="text-align:center">All packages include a free 20-minute introductory call. Concessions available — please ask.</p>
      <div class="cp-packages__grid">

        <div class="cp-pkg cp-pkg--single cp-reveal">
          <div class="cp-pkg__header">
            <div class="cp-pkg__name">Single Session</div>
            <div class="cp-pkg__price">£85</div>
            <div class="cp-pkg__unit">per 50-minute session</div>
          </div>
          <div class="cp-pkg__body">
            <p class="cp-pkg__desc">Pay-as-you-go individual sessions, ideal for those wanting to experience therapy before committing to a block.</p>
            <ul class="cp-pkg__features">
              <li>50-minute session</li>
              <li>Online or in-person (Bristol)</li>
              <li>Flexible scheduling</li>
              <li>No minimum commitment</li>
              <li>Free 20-min intro call</li>
            </ul>
            <button class="cp-pkg__cta" onclick="document.getElementById('booking').scrollIntoView({behavior:'smooth'})">Book a Session</button>
          </div>
        </div>

        <div class="cp-pkg cp-pkg--featured cp-reveal">
          <div class="cp-pkg__header">
            <div class="cp-pkg__badge">Best Value</div>
            <div class="cp-pkg__name">6-Session Block</div>
            <div class="cp-pkg__price">£460</div>
            <div class="cp-pkg__unit">saving £50 vs. individual sessions</div>
          </div>
          <div class="cp-pkg__body">
            <p class="cp-pkg__desc">A focused block of six weekly sessions — enough time to make meaningful progress on a specific issue or explore what's present with depth.</p>
            <ul class="cp-pkg__features">
              <li>6 × 50-minute sessions</li>
              <li>Consistent weekly slot</li>
              <li>Online or in-person</li>
              <li>Mid-block review conversation</li>
              <li>Secure client portal access</li>
              <li>Free 20-min intro call</li>
              <li>£50 saving on individual rate</li>
            </ul>
            <button class="cp-pkg__cta" onclick="document.getElementById('booking').scrollIntoView({behavior:'smooth'})">Reserve Your Block</button>
          </div>
        </div>

        <div class="cp-pkg cp-pkg--ongoing cp-reveal">
          <div class="cp-pkg__header">
            <div class="cp-pkg__name">Ongoing Therapy</div>
            <div class="cp-pkg__price">£75</div>
            <div class="cp-pkg__unit">per session (open-ended)</div>
          </div>
          <div class="cp-pkg__body">
            <p class="cp-pkg__desc">For those who want to engage in deeper, longer-term therapeutic work without a defined end point — at a discounted weekly rate.</p>
            <ul class="cp-pkg__features">
              <li>Unlimited weekly sessions</li>
              <li>Discounted rate (£75 vs. £85)</li>
              <li>Deep relational work</li>
              <li>Online or in-person</li>
              <li>Thoughtful planned endings</li>
              <li>Quarterly review sessions</li>
            </ul>
            <button class="cp-pkg__cta" onclick="document.getElementById('booking').scrollIntoView({behavior:'smooth'})">Enquire</button>
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- ── TESTIMONIALS ───────────────────────────────────────── -->
  <section class="cp-section cp-testimonials" aria-labelledby="cp-testi-heading">
    <div class="cp-wrap">
      <p class="cp-eyebrow" style="text-align:center">Client Reflections</p>
      <h2 class="cp-h2" id="cp-testi-heading" style="text-align:center">What Clients Say</h2>
      <div class="cp-testimonials__grid">

        <blockquote class="cp-testi cp-reveal">
          <div class="cp-testi__stars" aria-label="5 stars">★★★★★</div>
          <p class="cp-testi__quote">"Sarah has a rare gift for making you feel completely at ease from the very first session. I came with anxiety I'd carried for thirty years and, through her patient, compassionate approach, I have finally found a way to live with far less fear."</p>
          <footer>
            <div class="cp-testi__author">Anonymous client</div>
            <div class="cp-testi__meta">Ongoing therapy · Anxiety</div>
          </footer>
        </blockquote>

        <blockquote class="cp-testi cp-reveal">
          <div class="cp-testi__stars" aria-label="5 stars">★★★★★</div>
          <p class="cp-testi__quote">"After the loss of my husband I didn't know how to put one foot in front of the other. Sarah gave me a place to grieve without judgement and without any pressure to be further along than I was. She was a lifeline."</p>
          <footer>
            <div class="cp-testi__author">Anonymous client</div>
            <div class="cp-testi__meta">6-session block · Bereavement</div>
          </footer>
        </blockquote>

        <blockquote class="cp-testi cp-reveal">
          <div class="cp-testi__stars" aria-label="5 stars">★★★★★</div>
          <p class="cp-testi__quote">"I had tried therapy before and not found it helpful. With Sarah it was completely different — she tailored the approach to me, used EMDR for my trauma, and within three months I felt more like myself than I had in years."</p>
          <footer>
            <div class="cp-testi__author">Anonymous client</div>
            <div class="cp-testi__meta">Ongoing therapy · Trauma / PTSD</div>
          </footer>
        </blockquote>

      </div>
    </div>
  </section>

  <!-- ── FAQs ───────────────────────────────────────────────── -->
  <section class="cp-section cp-section--alt" aria-labelledby="cp-faq-heading">
    <div class="cp-wrap">
      <p class="cp-eyebrow" style="text-align:center">Questions</p>
      <h2 class="cp-h2" id="cp-faq-heading" style="text-align:center">Frequently Asked Questions</h2>
      <div class="cp-faqs__list">

        <div class="cp-faq">
          <button class="cp-faq__q" aria-expanded="false" aria-controls="cp-faq-1">
            Is everything I say confidential?
            <span class="cp-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="cp-faq__a" id="cp-faq-1" role="region">
            Yes — everything you share in sessions is held in strict confidence. The only exceptions are the standard legal and ethical exceptions: where there is serious risk of harm to yourself or others, where a court order requires disclosure, or where safeguarding a child is involved. I will always explain these limits before we begin work.
          </div>
        </div>

        <div class="cp-faq">
          <button class="cp-faq__q" aria-expanded="false" aria-controls="cp-faq-2">
            How long will I need therapy?
            <span class="cp-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="cp-faq__a" id="cp-faq-2" role="region">
            There is no single answer — it depends on the nature and depth of what you want to explore. Some people find significant benefit in six to twelve sessions; others work with me for a year or more on deeper relational or developmental themes. I will always be transparent about my view of what might be useful and respect your right to decide.
          </div>
        </div>

        <div class="cp-faq">
          <button class="cp-faq__q" aria-expanded="false" aria-controls="cp-faq-3">
            Do you work with couples?
            <span class="cp-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="cp-faq__a" id="cp-faq-3" role="region">
            I work with individuals, not couples, in my private practice. If you are experiencing relationship difficulties, I can provide individual therapy to support you in exploring your own patterns, needs, and responses. For couples counselling I am happy to provide referrals.
          </div>
        </div>

        <div class="cp-faq">
          <button class="cp-faq__q" aria-expanded="false" aria-controls="cp-faq-4">
            What is the difference between counselling and psychotherapy?
            <span class="cp-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="cp-faq__a" id="cp-faq-4" role="region">
            In practice, the terms are often used interchangeably. Psychotherapy tends to connote longer-term, deeper exploratory work, while counselling is sometimes associated with shorter-term, issue-focused support. I am trained and experienced in both and will calibrate the depth of our work to what feels right for you.
          </div>
        </div>

        <div class="cp-faq">
          <button class="cp-faq__q" aria-expanded="false" aria-controls="cp-faq-5">
            What happens in the first session?
            <span class="cp-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="cp-faq__a" id="cp-faq-5" role="region">
            The first session is an assessment — a chance for me to understand what has brought you to therapy and for you to experience how it feels to be in the room with me. There is no pressure to share more than you are comfortable with. At the end we will discuss whether we feel a good fit and, if so, arrange regular sessions.
          </div>
        </div>

        <div class="cp-faq">
          <button class="cp-faq__q" aria-expanded="false" aria-controls="cp-faq-6">
            Do you offer reduced-fee places?
            <span class="cp-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="cp-faq__a" id="cp-faq-6" role="region">
            I hold a small number of concession places for people who are experiencing genuine financial hardship. Please mention this when you get in touch — I will always try to find a way to make therapy accessible. I believe that cost should not be an insurmountable barrier to getting support.
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- ── BOOKING FORM ───────────────────────────────────────── -->
  <section class="cp-booking" id="booking" aria-labelledby="cp-booking-heading">
    <div class="cp-wrap">
      <p class="cp-eyebrow" style="text-align:center">Take the First Step</p>
      <h2 class="cp-h2" id="cp-booking-heading" style="text-align:center">Book Your Free Consultation</h2>
      <p class="cp-lead" style="text-align:center">Fill in the form below and I'll be in touch within two working days.</p>

      <div class="cp-form">
        <?php if ( function_exists( 'wp_nonce_field' ) ) : ?>
        <form method="post" action="" novalidate>
          <?php wp_nonce_field( 'tf_cp_booking', 'tf_cp_nonce' ); ?>

          <div class="cp-form__grid">

            <div>
              <label class="cp-label" for="cp-name">First Name *</label>
              <input class="cp-input" type="text" id="cp-name" name="cp_name" required placeholder="Your first name" autocomplete="given-name">
            </div>

            <div>
              <label class="cp-label" for="cp-email">Email Address *</label>
              <input class="cp-input" type="email" id="cp-email" name="cp_email" required placeholder="you@example.com" autocomplete="email">
            </div>

            <div>
              <label class="cp-label" for="cp-phone">Phone Number</label>
              <input class="cp-input" type="tel" id="cp-phone" name="cp_phone" placeholder="07xxx xxxxxx" autocomplete="tel">
            </div>

            <div>
              <label class="cp-label" for="cp-format">Preferred Format *</label>
              <select class="cp-select" id="cp-format" name="cp_format" required>
                <option value="">Please select…</option>
                <option>Online (video call)</option>
                <option>In-person (Bristol, Clifton)</option>
                <option>No preference</option>
              </select>
            </div>

            <div>
              <label class="cp-label" for="cp-concern">What brings you to therapy? *</label>
              <select class="cp-select" id="cp-concern" name="cp_concern" required>
                <option value="">Please select a broad area…</option>
                <option>Anxiety / Panic</option>
                <option>Depression / Low Mood</option>
                <option>Grief / Bereavement</option>
                <option>Trauma / PTSD</option>
                <option>Relationship Difficulties</option>
                <option>Life Transition</option>
                <option>Self-Esteem / Identity</option>
                <option>LGBTQ+ Issues</option>
                <option>Other / Not Sure</option>
              </select>
            </div>

            <div>
              <label class="cp-label" for="cp-option">Therapy Option Interest</label>
              <select class="cp-select" id="cp-option" name="cp_option">
                <option value="">Not sure yet</option>
                <option>Single session (£85)</option>
                <option>6-session block (£460)</option>
                <option>Ongoing therapy (£75/session)</option>
                <option>Would like to discuss</option>
              </select>
            </div>

            <div>
              <label class="cp-label" for="cp-heard">How did you find me?</label>
              <select class="cp-select" id="cp-heard" name="cp_heard">
                <option value="">Prefer not to say</option>
                <option>Google / Online search</option>
                <option>Psychology Today</option>
                <option>BACP Directory</option>
                <option>Counselling Directory</option>
                <option>GP referral</option>
                <option>Friend / Family recommendation</option>
                <option>Social media</option>
              </select>
            </div>

            <div>
              <label class="cp-label" for="cp-concession">Do you need a concession rate?</label>
              <select class="cp-select" id="cp-concession" name="cp_concession">
                <option value="">No, standard rate is fine</option>
                <option>Yes, I'd like to discuss this</option>
                <option>Prefer not to say</option>
              </select>
            </div>

            <div class="cp-form__full">
              <label class="cp-label" for="cp-message">Anything you'd like me to know before we speak?</label>
              <textarea class="cp-textarea" id="cp-message" name="cp_message" placeholder="This is completely optional — even a few words can be helpful, but please only share what feels comfortable."></textarea>
            </div>

          </div>

          <div class="cp-confidential">
            <strong>🔒 A note on confidentiality</strong>
            The information you share on this form is held securely, used only to arrange your consultation, and will not be shared with any third parties. You can read my full privacy notice on request.
          </div>

          <div class="cp-form__submit">
            <button type="submit" class="cp-btn cp-btn--secondary">Send Enquiry</button>
          </div>
          <p class="cp-form__note">Free 20-min consultation · No obligation · Response within 2 working days</p>

        </form>
        <?php endif; ?>
      </div>
    </div>
  </section>

  <!-- ── FOOTER CTA ─────────────────────────────────────────── -->
  <section class="cp-footer-cta" aria-label="Call to action">
    <div class="cp-wrap">
      <h2 class="cp-h2">The Bravest Thing Is Asking for Help</h2>
      <p class="cp-lead">You don't have to figure it all out alone. I'm here.</p>
      <a href="#booking" class="cp-btn cp-btn--outline">Begin Your Journey ↗</a>
    </div>
  </section>

</div><!-- .cp-page -->

<script>
(function () {
  'use strict';

  /* ── Animated counters ──────────────────────────────────── */
  var easeOut = function (t) { return 1 - Math.pow(1 - t, 3); };
  var dur = 1800;
  function animCounter(el) {
    var target = parseFloat(el.getAttribute('data-target'));
    var isFloat = el.getAttribute('data-float') === '1';
    if (isNaN(target)) return;
    var start = null;
    function tick(ts) {
      if (!start) start = ts;
      var p = Math.min((ts - start) / dur, 1);
      var v = target * easeOut(p);
      el.textContent = isFloat ? v.toFixed(1) : Math.floor(v).toLocaleString();
      if (p < 1) requestAnimationFrame(tick);
      else el.textContent = isFloat ? target.toFixed(1) : target.toLocaleString();
    }
    requestAnimationFrame(tick);
  }
  var cObs = new IntersectionObserver(function (entries, o) {
    entries.forEach(function (e) { if (e.isIntersecting) { animCounter(e.target); o.unobserve(e.target); } });
  }, { threshold: 0.5 });
  document.querySelectorAll('[data-target]').forEach(function (el) { cObs.observe(el); });

  /* ── FAQ accordion ──────────────────────────────────────── */
  document.querySelectorAll('.cp-faq__q').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var expanded = this.getAttribute('aria-expanded') === 'true';
      var id = this.getAttribute('aria-controls');
      document.querySelectorAll('.cp-faq__q').forEach(function (b) { b.setAttribute('aria-expanded','false'); });
      document.querySelectorAll('.cp-faq__a').forEach(function (a) { a.classList.remove('is-open'); });
      if (!expanded) {
        this.setAttribute('aria-expanded','true');
        var a = document.getElementById(id); if (a) a.classList.add('is-open');
      }
    });
  });

  /* ── Scroll reveal ──────────────────────────────────────── */
  var rObs = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('is-visible'); rObs.unobserve(e.target); } });
  }, { threshold: 0.12 });
  document.querySelectorAll('.cp-reveal').forEach(function (el) { rObs.observe(el); });

  /* ── Smooth scroll ──────────────────────────────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      var t = document.querySelector(this.getAttribute('href'));
      if (t) { e.preventDefault(); t.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    });
  });

})();
</script>

<?php get_footer(); ?>
