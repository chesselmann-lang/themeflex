<?php
/**
 * Template Name: ThemeFlex – Coworking Space
 *
 * Premium coworking space / shared office template for ThemeFlex.
 * Namespace : --cw-*
 * Fonts     : Plus Jakarta Sans (headings) + Outfit (body)
 * Palette   : Ink #1C1C2E / Tangerine #FF6B35 / Sky #E8F4FD / Mint #2DD4BF / Pearl #F9F7F4
 */
defined('ABSPATH') || exit;
get_header();
?>

<style>
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Outfit:wght@300;400;500;600&display=swap');

/* ── Tokens ── */
:root{
  --cw-ink:#1C1C2E;
  --cw-ink-mid:#2D2D42;
  --cw-tangerine:#FF6B35;
  --cw-tangerine-pale:#FFF0EB;
  --cw-sky:#E8F4FD;
  --cw-mint:#2DD4BF;
  --cw-mint-pale:#CCFBF1;
  --cw-pearl:#F9F7F4;
  --cw-stone:#6B7280;
  --cw-stone-light:#D1D5DB;
  --cw-white:#FFFFFF;
  --cw-head:'Plus Jakarta Sans',system-ui,sans-serif;
  --cw-body:'Outfit',system-ui,sans-serif;
  --cw-radius:8px;
  --cw-radius-lg:16px;
  --cw-shadow:0 4px 24px rgba(28,28,46,.08);
  --cw-shadow-lg:0 12px 48px rgba(28,28,46,.14);
}

/* ── Reset ── */
.cw-page *,
.cw-page *::before,
.cw-page *::after{box-sizing:border-box;margin:0;padding:0}
.cw-page{font-family:var(--cw-body);color:var(--cw-ink);background:var(--cw-pearl);line-height:1.65;overflow-x:hidden}
.cw-page a{color:inherit;text-decoration:none}

/* ── Layout ── */
.cw-wrap{max-width:1160px;margin:0 auto;padding:0 24px}
.cw-section{padding:88px 0}
.cw-section--ink{background:var(--cw-ink);color:var(--cw-white)}
.cw-section--sky{background:var(--cw-sky)}
.cw-section--pearl{background:var(--cw-pearl)}

/* ── Typography ── */
.cw-eyebrow{font-family:var(--cw-body);font-size:.72rem;font-weight:600;letter-spacing:.18em;text-transform:uppercase;color:var(--cw-tangerine);margin-bottom:12px;display:block}
.cw-section--ink .cw-eyebrow{color:var(--cw-mint)}
.cw-h1{font-family:var(--cw-head);font-size:clamp(2.4rem,5vw,3.9rem);line-height:1.1;font-weight:800}
.cw-h2{font-family:var(--cw-head);font-size:clamp(1.8rem,3.5vw,2.8rem);line-height:1.18;font-weight:700}
.cw-section--ink .cw-h2{color:var(--cw-white)}
.cw-lead{font-size:1.05rem;color:var(--cw-stone);max-width:680px;margin:0 auto;line-height:1.8}
.cw-section--ink .cw-lead{color:rgba(255,255,255,.6)}
.cw-center{text-align:center}
.cw-hgroup{margin-bottom:56px}

/* ── Buttons ── */
.cw-btn{display:inline-flex;align-items:center;gap:8px;padding:14px 32px;border-radius:var(--cw-radius);font-family:var(--cw-head);font-size:.9rem;font-weight:700;cursor:pointer;border:none;transition:all .25s;text-decoration:none}
.cw-btn--primary{background:var(--cw-tangerine);color:var(--cw-white)}
.cw-btn--primary:hover{background:#E55A25;transform:translateY(-2px);box-shadow:0 8px 24px rgba(255,107,53,.35)}
.cw-btn--outline{background:transparent;color:var(--cw-ink);border:2px solid var(--cw-ink)}
.cw-btn--outline:hover{background:var(--cw-ink);color:var(--cw-white)}
.cw-btn--ghost{background:transparent;color:var(--cw-white);border:2px solid rgba(255,255,255,.3)}
.cw-btn--ghost:hover{border-color:var(--cw-mint);color:var(--cw-mint)}
.cw-btn--mint{background:var(--cw-mint);color:var(--cw-ink)}
.cw-btn--mint:hover{background:#14B8A6;transform:translateY(-2px);box-shadow:0 8px 24px rgba(45,212,191,.35)}

/* ═══════════════════════════════════════════
   HERO
═══════════════════════════════════════════ */
.cw-hero{
  position:relative;min-height:100vh;
  background:var(--cw-ink);
  display:flex;align-items:center;
  overflow:hidden;padding:80px 0 60px;
}

/* Abstract shapes */
.cw-hero__shape{position:absolute;pointer-events:none;border-radius:50%}
.cw-hero__shape--1{
  width:500px;height:500px;
  background:radial-gradient(circle,rgba(255,107,53,.15) 0%,transparent 65%);
  top:-150px;right:-100px;
}
.cw-hero__shape--2{
  width:360px;height:360px;
  background:radial-gradient(circle,rgba(45,212,191,.1) 0%,transparent 65%);
  bottom:-80px;left:-60px;
}
.cw-hero__shape--3{
  width:180px;height:180px;
  background:rgba(255,107,53,.06);
  top:30%;right:55%;
  animation:cw-rot 20s linear infinite;
}
@keyframes cw-rot{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}

.cw-hero__inner{
  position:relative;z-index:2;
  display:grid;grid-template-columns:1fr 500px;
  gap:60px;align-items:center;
  max-width:1160px;margin:0 auto;padding:0 24px;
}

/* ── Hero Copy ── */
.cw-hero__tag{
  display:inline-flex;align-items:center;gap:8px;
  background:rgba(255,107,53,.15);border:1px solid rgba(255,107,53,.3);
  border-radius:20px;padding:6px 16px;
  font-size:.78rem;font-weight:600;color:var(--cw-tangerine);
  margin-bottom:24px;
}
.cw-hero__tag::before{content:'📍';font-size:.9rem}
.cw-h1 span{color:var(--cw-tangerine)}
.cw-hero__desc{
  font-size:1.05rem;color:rgba(255,255,255,.65);
  line-height:1.8;margin:22px 0 36px;max-width:520px;
}
.cw-hero__ctas{display:flex;gap:14px;flex-wrap:wrap}
.cw-hero__perks{
  display:flex;gap:20px;flex-wrap:wrap;margin-top:28px;
}
.cw-hero__perk{
  font-size:.8rem;color:rgba(255,255,255,.5);
  display:flex;align-items:center;gap:6px;
}
.cw-hero__perk::before{content:'✓';color:var(--cw-mint);font-weight:700}

/* ── Hero Scene: Coworking Interior ── */
.cw-hero__scene{
  position:relative;
  width:500px;height:440px;flex-shrink:0;
}

/* Room floor & ceiling */
.cw-room{
  position:absolute;inset:0;
  background:linear-gradient(180deg,#2A2A3E 0%,#1C1C2E 40%,#2A2318 60%,#3D3220 100%);
  border-radius:12px;
  overflow:hidden;
}
/* Ceiling */
.cw-ceiling{
  position:absolute;top:0;left:0;right:0;height:60px;
  background:linear-gradient(180deg,#1A1A2E,#222234);
  border-bottom:2px solid rgba(255,255,255,.04);
}
/* Exposed brick wall texture strip */
.cw-brick-wall{
  position:absolute;
  top:60px;left:0;right:0;height:100px;
  background:repeating-linear-gradient(0deg,transparent 0px,transparent 18px,rgba(255,255,255,.03) 18px,rgba(255,255,255,.03) 20px),
             repeating-linear-gradient(90deg,rgba(255,255,255,.02) 0px,rgba(255,255,255,.02) 40px,transparent 40px,transparent 80px);
}
/* Floor */
.cw-floor{
  position:absolute;bottom:0;left:0;right:0;height:55px;
  background:linear-gradient(180deg,#3D3220 0%,#2A2318 100%);
  border-top:1px solid rgba(255,255,255,.08);
}
/* Floor planks */
.cw-floor::before{
  content:'';position:absolute;
  top:0;left:0;right:0;bottom:0;
  background:repeating-linear-gradient(90deg,transparent 0px,transparent 80px,rgba(255,255,255,.03) 80px,rgba(255,255,255,.03) 82px);
}

/* Pendant lamps */
.cw-pendant{
  position:absolute;
  top:0;
}
.cw-pendant__cord{
  width:2px;
  background:rgba(255,255,255,.15);
  margin:0 auto;
}
.cw-pendant__shade{
  width:28px;height:18px;
  background:linear-gradient(180deg,#C8A878,#8B7355);
  border-radius:0 0 14px 14px;
  box-shadow:0 8px 20px rgba(255,200,100,.2);
}
.cw-pendant:nth-child(1){left:80px}
.cw-pendant:nth-child(1) .cw-pendant__cord{height:45px}
.cw-pendant:nth-child(2){left:200px}
.cw-pendant:nth-child(2) .cw-pendant__cord{height:60px}
.cw-pendant:nth-child(3){left:330px}
.cw-pendant:nth-child(3) .cw-pendant__cord{height:50px}

/* Long desk / work table */
.cw-table{
  position:absolute;
  bottom:55px;left:20px;right:20px;height:16px;
  background:linear-gradient(180deg,#C8A878 0%,#8B7355 100%);
  border-radius:4px 4px 0 0;
  box-shadow:0 4px 12px rgba(0,0,0,.3);
}
.cw-table::before{/* table legs */
  content:'';position:absolute;
  bottom:-50px;left:30px;right:30px;height:50px;
  background:#5A3A1A;
  clip-path:polygon(0 0,100% 0,95% 100%,5% 100%);
}

/* Monitor screens on desk */
.cw-monitor{
  position:absolute;
  bottom:71px;
  width:70px;
}
.cw-monitor__screen{
  width:70px;height:48px;
  background:#0D1117;border:2px solid #334155;
  border-radius:4px;overflow:hidden;position:relative;
}
/* Glowing screen content */
.cw-monitor__screen::before{
  content:'';position:absolute;inset:0;
  background:linear-gradient(135deg,rgba(30,64,175,.4),rgba(13,17,23,.9));
}
.cw-monitor__screen::after{/* screen lines */
  content:'';position:absolute;
  top:8px;left:8px;right:8px;height:2px;
  background:rgba(255,107,53,.6);
  box-shadow:0 8px 0 rgba(45,212,191,.5),0 16px 0 rgba(255,107,53,.3),0 24px 0 rgba(255,255,255,.15);
}
.cw-monitor__stand{
  width:20px;height:8px;background:#1E293B;margin:0 auto;
}
.cw-monitor__base{
  width:32px;height:4px;background:#334155;border-radius:2px;margin:0 auto;
}
.cw-monitor--1{left:40px}
.cw-monitor--2{left:140px}
.cw-monitor--3{left:290px}
.cw-monitor--4{left:390px}

/* Laptop on desk */
.cw-laptop{
  position:absolute;
  bottom:71px;left:240px;
  width:80px;
}
.cw-laptop__lid{
  width:80px;height:52px;
  background:#1E293B;border:2px solid #334155;border-radius:4px 4px 0 0;
  position:relative;overflow:hidden;
}
.cw-laptop__lid::before{
  content:'';position:absolute;inset:0;
  background:linear-gradient(135deg,rgba(45,212,191,.3),rgba(13,17,23,.8));
}
.cw-laptop__lid::after{
  content:'';position:absolute;
  top:8px;left:8px;right:8px;height:2px;
  background:rgba(45,212,191,.6);
  box-shadow:0 7px 0 rgba(255,107,53,.4),0 16px 0 rgba(45,212,191,.3);
}
.cw-laptop__base{
  width:80px;height:6px;background:#334155;border-radius:0 0 3px 3px;
}

/* Plant */
.cw-plant{
  position:absolute;
  bottom:71px;right:28px;
}
.cw-plant__pot{
  width:28px;height:22px;
  background:linear-gradient(180deg,#C8A878,#8B5A2A);
  border-radius:2px 2px 4px 4px;
}
.cw-plant__soil{
  width:28px;height:6px;
  background:#3D2510;
  border-radius:2px 2px 0 0;
  margin-top:-4px;
}
.cw-plant__stem{
  width:3px;height:24px;background:#2A6E2A;
  margin:0 auto;border-radius:2px;
}
.cw-plant__leaf-l,.cw-plant__leaf-r{
  position:absolute;
  width:18px;height:10px;
  background:#2A6E2A;border-radius:50% 0;
}
.cw-plant__leaf-l{bottom:28px;left:-12px;transform:rotate(30deg)}
.cw-plant__leaf-r{bottom:24px;right:-12px;transform:rotate(-30deg) scaleX(-1)}

/* CSS co-working figures (3 people at desk) */
.cw-fig{
  position:absolute;
  bottom:71px;
  display:flex;flex-direction:column;align-items:center;
}
.cw-fig__head{
  width:24px;height:26px;
  border-radius:50%;
  position:relative;
}
.cw-fig__head::after{/* eyes */
  content:'';position:absolute;
  top:12px;left:5px;width:5px;height:3px;
  border-radius:50%;background:rgba(28,28,46,.6);
  box-shadow:8px 0 0 rgba(28,28,46,.6);
}
.cw-fig__body{
  width:32px;height:36px;
  border-radius:4px 4px 2px 2px;
  margin-top:-2px;
}
/* Typing arms */
.cw-fig__arms{
  position:absolute;
  top:30px;left:-6px;right:-6px;height:10px;
  display:flex;gap:2px;
}
.cw-fig__arm{width:8px;height:6px;border-radius:3px}
/* Figure variants */
.cw-fig--a .cw-fig__head{background:#D4A574}
.cw-fig--a .cw-fig__body{background:#2563EB}/* blue shirt */
.cw-fig--b .cw-fig__head{background:#C8956B}
.cw-fig--b .cw-fig__body{background:#4B5563}/* grey */
.cw-fig--c .cw-fig__head{background:#8B5E3C}
.cw-fig--c .cw-fig__body{background:#DC2626}/* red */
.cw-fig__head::before{content:'';position:absolute;top:-6px;left:0;right:0;height:10px;border-radius:4px 4px 0 0}
.cw-fig--a .cw-fig__head::before{background:#1A0A00}
.cw-fig--b .cw-fig__head::before{background:#2D1507}
.cw-fig--c .cw-fig__head::before{background:#0A0A0A}
.cw-fig--1{left:70px}
.cw-fig--2{left:180px}
.cw-fig--3{left:355px}

/* Floating "available" badge */
.cw-avail-badge{
  position:absolute;top:70px;right:20px;
  background:rgba(45,212,191,.15);border:1px solid rgba(45,212,191,.4);
  border-radius:8px;padding:10px 14px;
  font-family:var(--cw-head);font-size:.72rem;font-weight:700;
  animation:cw-float 3.5s ease-in-out infinite;
}
@keyframes cw-float{0%,100%{transform:translateY(0)}50%{transform:translateY(-7px)}}
.cw-avail-badge__label{color:var(--cw-mint)}
.cw-avail-badge__val{font-size:1rem;color:var(--cw-white);margin-top:2px}

/* Wifi symbol */
.cw-wifi{
  position:absolute;top:80px;left:28px;
  font-size:1.4rem;
  animation:cw-float 4s ease-in-out infinite 1s;
}
.cw-wifi__lbl{font-size:.55rem;font-family:var(--cw-head);color:rgba(255,255,255,.4);text-align:center;margin-top:2px;letter-spacing:.05em}

/* ── Hero Stats ── */
.cw-hero__stats{
  position:relative;z-index:2;
  max-width:1160px;margin:44px auto 0;padding:24px 24px 0;
  border-top:1px solid rgba(255,255,255,.07);
  display:flex;
}
.cw-hero__stat{
  flex:1;text-align:center;
  padding:0 16px;
  border-right:1px solid rgba(255,255,255,.07);
}
.cw-hero__stat:last-child{border-right:none}
.cw-stat-val{font-family:var(--cw-head);font-size:1.9rem;font-weight:800;color:var(--cw-tangerine)}
.cw-stat-lbl{font-size:.78rem;color:rgba(255,255,255,.45);margin-top:4px}

/* ═══════════════════════════════════════════
   SPACE TYPES
═══════════════════════════════════════════ */
.cw-spaces__grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:56px;
}
.cw-space-card{
  background:var(--cw-white);border:1px solid rgba(28,28,46,.08);
  border-radius:var(--cw-radius-lg);
  overflow:hidden;transition:all .3s;
}
.cw-space-card:hover{box-shadow:var(--cw-shadow-lg);transform:translateY(-5px)}

/* CSS space scene illustrations */
.cw-space-scene{
  height:160px;position:relative;
  display:flex;align-items:flex-end;justify-content:center;
  padding-bottom:16px;
}
.cw-space-scene--hot{background:linear-gradient(135deg,#FFF0EB,#FFE4D6)}
.cw-space-scene--private{background:linear-gradient(135deg,#E0F2FE,#BAE6FD)}
.cw-space-scene--meeting{background:linear-gradient(135deg,#F0FDF4,#DCFCE7)}
/* Desk icons inside scenes */
.cw-mini-desk{
  width:60px;height:8px;
  background:#8B7355;border-radius:2px;
  position:relative;
}
.cw-mini-desk::before{content:'';position:absolute;bottom:-20px;left:4px;right:4px;height:20px;background:#5A3A1A;clip-path:polygon(0 0,100% 0,88% 100%,12% 100%)}
.cw-mini-screen{width:36px;height:24px;background:#1C1C2E;border-radius:3px;position:absolute;bottom:8px;left:12px}
.cw-mini-laptop{width:40px;height:5px;background:#334155;border-radius:2px;position:absolute;bottom:8px;left:30px}

.cw-space-card__info{padding:24px}
.cw-space-card__info h3{font-family:var(--cw-head);font-size:1.1rem;font-weight:700;margin-bottom:8px}
.cw-space-card__info p{font-size:.875rem;color:var(--cw-stone);line-height:1.65;margin-bottom:14px}
.cw-space-card__price{
  font-family:var(--cw-head);font-size:1.3rem;font-weight:800;color:var(--cw-tangerine);
}
.cw-space-card__price span{font-size:.85rem;color:var(--cw-stone);font-weight:400}
.cw-space-card__features{list-style:none;margin-top:12px}
.cw-space-card__features li{
  font-size:.82rem;color:var(--cw-stone);padding:5px 0;
  display:flex;align-items:center;gap:8px;
  border-bottom:1px solid rgba(28,28,46,.05);
}
.cw-space-card__features li:last-child{border-bottom:none}
.cw-space-card__features li::before{content:'✓';color:var(--cw-mint);font-weight:700;flex-shrink:0}

/* ═══════════════════════════════════════════
   AMENITIES
═══════════════════════════════════════════ */
.cw-amenities{background:var(--cw-sky)}
.cw-amenities__grid{
  display:grid;grid-template-columns:repeat(4,1fr);gap:20px;margin-top:52px;
}
.cw-amenity{
  background:var(--cw-white);border-radius:var(--cw-radius-lg);
  padding:28px 20px;text-align:center;
  box-shadow:var(--cw-shadow);transition:all .3s;
}
.cw-amenity:hover{transform:translateY(-4px);box-shadow:var(--cw-shadow-lg)}
.cw-amenity__icon{font-size:2rem;margin-bottom:12px;display:block}
.cw-amenity h3{font-family:var(--cw-head);font-size:.95rem;font-weight:700;margin-bottom:6px}
.cw-amenity p{font-size:.8rem;color:var(--cw-stone);line-height:1.6}

/* ═══════════════════════════════════════════
   MEMBERSHIP PLANS
═══════════════════════════════════════════ */
.cw-plans{background:var(--cw-pearl)}
.cw-plans__grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:56px;align-items:start;
}
.cw-plan{
  background:var(--cw-white);border:2px solid rgba(28,28,46,.08);
  border-radius:var(--cw-radius-lg);padding:36px 28px;
  position:relative;transition:all .3s;
}
.cw-plan:hover{box-shadow:var(--cw-shadow-lg)}
.cw-plan--featured{
  border-color:var(--cw-tangerine);
  transform:scale(1.04);
  box-shadow:var(--cw-shadow-lg),0 0 0 4px rgba(255,107,53,.08);
}
.cw-plan__badge{
  position:absolute;top:-14px;left:50%;transform:translateX(-50%);
  background:var(--cw-tangerine);color:var(--cw-white);
  font-family:var(--cw-head);font-size:.68rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;
  padding:5px 18px;border-radius:20px;white-space:nowrap;
}
.cw-plan__icon{font-size:1.6rem;margin-bottom:16px;display:block}
.cw-plan__name{font-family:var(--cw-head);font-size:1.2rem;font-weight:700;margin-bottom:6px}
.cw-plan__price{
  font-family:var(--cw-head);font-size:2.4rem;font-weight:800;color:var(--cw-tangerine);
  margin:14px 0 4px;
}
.cw-plan__price sup{font-size:1rem;vertical-align:top;margin-top:8px}
.cw-plan__price span{font-size:.875rem;color:var(--cw-stone);font-family:var(--cw-body);font-weight:400}
.cw-plan__desc{font-size:.85rem;color:var(--cw-stone);line-height:1.6;margin-bottom:20px}
.cw-plan__divider{height:1px;background:rgba(28,28,46,.07);margin:20px 0}
.cw-plan__features{list-style:none}
.cw-plan__features li{
  font-size:.85rem;color:var(--cw-stone);padding:8px 0;
  display:flex;align-items:flex-start;gap:10px;
  border-bottom:1px solid rgba(28,28,46,.05);
}
.cw-plan__features li:last-child{border-bottom:none}
.cw-plan__features li.cw-inc::before{content:'✓';color:var(--cw-mint);font-weight:700;flex-shrink:0}
.cw-plan__features li.cw-not{color:var(--cw-stone-light)}
.cw-plan__features li.cw-not::before{content:'—';color:var(--cw-stone-light);flex-shrink:0}
.cw-plan .cw-btn{width:100%;justify-content:center;margin-top:24px}

/* ═══════════════════════════════════════════
   VIRTUAL TOUR / GALLERY MOSAIC
═══════════════════════════════════════════ */
.cw-gallery{background:var(--cw-ink)}
.cw-gallery__mosaic{
  display:grid;
  grid-template-columns:repeat(4,1fr);
  grid-template-rows:180px 180px;
  gap:12px;margin-top:48px;
}
.cw-gallery__tile{
  background:linear-gradient(135deg,#2D2D42,#1C1C2E);
  border-radius:var(--cw-radius);
  position:relative;overflow:hidden;
  display:flex;align-items:flex-end;padding:16px;
  transition:all .3s;
}
.cw-gallery__tile:hover{transform:scale(.98);filter:brightness(1.1)}
.cw-gallery__tile:nth-child(1){grid-column:span 2;grid-row:span 2;background:linear-gradient(135deg,rgba(255,107,53,.15),rgba(28,28,46,1))}
.cw-gallery__tile:nth-child(4){grid-column:span 2}
.cw-gallery__tile__label{
  font-family:var(--cw-head);font-size:.75rem;font-weight:600;color:rgba(255,255,255,.6);
}

/* Decorative content inside tiles */
<?php
$cw_tile_cols = ['rgba(255,107,53,.08)','rgba(45,212,191,.06)','rgba(59,130,246,.07)','rgba(132,204,22,.06)','rgba(255,107,53,.1)'];
?>
.cw-gallery__tile::before{
  content:'';position:absolute;inset:0;
  background-image:repeating-linear-gradient(0deg,rgba(255,255,255,.02) 0px,rgba(255,255,255,.02) 1px,transparent 1px,transparent 40px),
                   repeating-linear-gradient(90deg,rgba(255,255,255,.02) 0px,rgba(255,255,255,.02) 1px,transparent 1px,transparent 40px);
}

/* ═══════════════════════════════════════════
   COMMUNITY / ABOUT
═══════════════════════════════════════════ */
.cw-community{background:var(--cw-pearl)}
.cw-community__inner{
  display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:center;
}
.cw-community__text h2{margin-bottom:16px}
.cw-community__text p{font-size:.95rem;color:var(--cw-stone);line-height:1.8;margin-bottom:18px}
.cw-community__items{list-style:none;margin:24px 0}
.cw-community__items li{
  display:flex;align-items:flex-start;gap:12px;
  padding:10px 0;border-bottom:1px solid rgba(28,28,46,.06);
}
.cw-community__items li:last-child{border-bottom:none}
.cw-community__items li::before{
  content:'→';color:var(--cw-tangerine);font-weight:700;font-size:1.1rem;flex-shrink:0;
}
.cw-community__items li span{font-size:.9rem;color:var(--cw-stone);line-height:1.6}

/* CSS community scene */
.cw-community__scene{
  position:relative;height:340px;
  background:linear-gradient(135deg,var(--cw-tangerine-pale),var(--cw-mint-pale));
  border-radius:var(--cw-radius-lg);overflow:hidden;
}
.cw-comm-dots{position:absolute;inset:0}
.cw-comm-dot{
  position:absolute;border-radius:50%;
  animation:cw-float var(--cw-dur,4s) ease-in-out infinite;
  animation-delay:var(--cw-dly,0s);
}
/* Member cards floating */
.cw-member-card{
  position:absolute;
  background:var(--cw-white);border-radius:10px;
  padding:12px 16px;
  box-shadow:0 4px 16px rgba(28,28,46,.1);
  display:flex;align-items:center;gap:10px;
  animation:cw-float 4s ease-in-out infinite;
}
.cw-member-card__av{
  width:36px;height:36px;border-radius:50%;
  display:flex;align-items:center;justify-content:center;
  font-family:var(--cw-head);font-weight:700;color:var(--cw-white);font-size:.875rem;
  flex-shrink:0;
}
.cw-member-card__name{font-family:var(--cw-head);font-size:.8rem;font-weight:700}
.cw-member-card__role{font-size:.7rem;color:var(--cw-stone)}

/* ═══════════════════════════════════════════
   TESTIMONIALS
═══════════════════════════════════════════ */
.cw-testis{background:var(--cw-sky)}
.cw-testi-grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-top:52px;
}
.cw-testi{
  background:var(--cw-white);border-radius:var(--cw-radius-lg);
  padding:28px;box-shadow:var(--cw-shadow);transition:all .3s;
}
.cw-testi:hover{box-shadow:var(--cw-shadow-lg);transform:translateY(-3px)}
.cw-testi__stars{color:#FBBF24;font-size:.85rem;margin-bottom:12px}
.cw-testi__text{font-size:.9rem;color:var(--cw-stone);line-height:1.75;margin-bottom:20px}
.cw-testi__author{display:flex;align-items:center;gap:12px}
.cw-testi__av{
  width:40px;height:40px;border-radius:50%;
  display:flex;align-items:center;justify-content:center;
  font-family:var(--cw-head);font-weight:700;color:var(--cw-white);font-size:.875rem;
  flex-shrink:0;
}
.cw-testi__name{font-family:var(--cw-head);font-weight:700;font-size:.875rem}
.cw-testi__role{font-size:.75rem;color:var(--cw-stone);margin-top:2px}

/* ═══════════════════════════════════════════
   FAQ
═══════════════════════════════════════════ */
.cw-faq{background:var(--cw-pearl)}
.cw-faq__list{max-width:720px;margin:44px auto 0}
.cw-faq-item{border-bottom:1px solid rgba(28,28,46,.09)}
.cw-faq-q{
  width:100%;background:none;border:none;
  display:flex;justify-content:space-between;align-items:center;
  padding:20px 0;cursor:pointer;text-align:left;
  font-family:var(--cw-head);font-size:.975rem;font-weight:700;color:var(--cw-ink);
  gap:16px;transition:color .2s;
}
.cw-faq-q:hover{color:var(--cw-tangerine)}
.cw-faq-icon{
  width:28px;height:28px;border-radius:50%;
  background:var(--cw-tangerine-pale);color:var(--cw-tangerine);
  display:flex;align-items:center;justify-content:center;
  font-size:1rem;flex-shrink:0;transition:transform .3s,background .2s;
}
.cw-faq-item.cw-open .cw-faq-icon{transform:rotate(45deg);background:var(--cw-tangerine);color:var(--cw-white)}
.cw-faq-a{max-height:0;overflow:hidden;transition:max-height .4s ease}
.cw-faq-a p{padding:0 0 20px;font-size:.9rem;color:var(--cw-stone);line-height:1.75}

/* ═══════════════════════════════════════════
   CONTACT / TOUR FORM
═══════════════════════════════════════════ */
.cw-contact{background:var(--cw-ink)}
.cw-contact__inner{
  display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:start;
}
.cw-contact__info h2{color:var(--cw-white);margin-bottom:16px}
.cw-contact__info .cw-lead{color:rgba(255,255,255,.55);text-align:left;margin:0 0 32px}
.cw-contact__detail{display:flex;align-items:flex-start;gap:14px;margin-bottom:20px}
.cw-contact__detail-icon{
  width:42px;height:42px;border-radius:var(--cw-radius);flex-shrink:0;
  background:rgba(255,107,53,.15);border:1px solid rgba(255,107,53,.25);
  display:flex;align-items:center;justify-content:center;font-size:1.1rem;
}
.cw-contact__detail-text strong{display:block;color:var(--cw-white);font-size:.9rem;margin-bottom:3px}
.cw-contact__detail-text span{color:rgba(255,255,255,.45);font-size:.82rem}
.cw-contact__hours{
  background:rgba(45,212,191,.08);border:1px solid rgba(45,212,191,.2);
  border-radius:var(--cw-radius);padding:16px;margin-top:20px;
}
.cw-contact__hours h4{font-family:var(--cw-head);font-size:.82rem;color:var(--cw-mint);margin-bottom:8px}
.cw-contact__hours table{width:100%;font-size:.78rem;color:rgba(255,255,255,.5)}
.cw-contact__hours td{padding:3px 0}
.cw-contact__hours td:first-child{color:rgba(255,255,255,.7)}

.cw-cform{
  background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);
  border-radius:var(--cw-radius-lg);padding:36px;
}
.cw-cf-row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.cw-cf{margin-bottom:18px}
.cw-cf label{display:block;font-size:.78rem;font-weight:600;color:rgba(255,255,255,.45);margin-bottom:7px;letter-spacing:.04em}
.cw-cf input,
.cw-cf select,
.cw-cf textarea{
  width:100%;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);
  border-radius:var(--cw-radius);padding:11px 14px;
  font-family:var(--cw-body);font-size:.875rem;color:var(--cw-white);outline:none;
  transition:border-color .2s;
}
.cw-cf input::placeholder,.cw-cf textarea::placeholder{color:rgba(255,255,255,.22)}
.cw-cf input:focus,.cw-cf select:focus,.cw-cf textarea:focus{border-color:var(--cw-tangerine)}
.cw-cf select option{background:var(--cw-ink-mid)}
.cw-cf textarea{resize:vertical;min-height:100px}
.cw-cform .cw-btn{width:100%;justify-content:center;margin-top:6px}

/* ── Footer CTA ── */
.cw-footer-cta{
  background:linear-gradient(135deg,var(--cw-tangerine) 0%,#E55A25 100%);
  padding:72px 0;text-align:center;
}
.cw-footer-cta h2{font-family:var(--cw-head);font-size:clamp(1.8rem,3vw,2.6rem);color:var(--cw-white);font-weight:800;margin-bottom:14px}
.cw-footer-cta p{color:rgba(255,255,255,.8);font-size:1rem;margin-bottom:32px}
.cw-footer-cta .cw-btn{background:var(--cw-white);color:var(--cw-tangerine);font-size:1rem;padding:15px 40px}
.cw-footer-cta .cw-btn:hover{background:var(--cw-pearl);transform:translateY(-2px)}

/* ── Reveal ── */
.cw-reveal{opacity:0;transform:translateY(22px);transition:opacity .6s ease,transform .6s ease}
.cw-reveal.cw-visible{opacity:1;transform:none}

/* ── Responsive ── */
@media(max-width:960px){
  .cw-hero__inner{grid-template-columns:1fr;text-align:center}
  .cw-hero__scene{display:none}
  .cw-hero__ctas,.cw-hero__perks{justify-content:center}
  .cw-hero__desc{margin:16px auto 28px}
  .cw-spaces__grid{grid-template-columns:1fr 1fr}
  .cw-amenities__grid{grid-template-columns:1fr 1fr}
  .cw-plans__grid{grid-template-columns:1fr}
  .cw-plan--featured{transform:none}
  .cw-gallery__mosaic{grid-template-columns:1fr 1fr;grid-template-rows:auto}
  .cw-gallery__tile:nth-child(1){grid-column:span 2;grid-row:span 1}
  .cw-gallery__tile:nth-child(4){grid-column:span 2}
  .cw-community__inner{grid-template-columns:1fr}
  .cw-testi-grid{grid-template-columns:1fr}
  .cw-contact__inner{grid-template-columns:1fr}
  .cw-hero__stats{flex-wrap:wrap}
  .cw-hero__stat{flex:0 0 50%;padding:10px}
}
@media(max-width:600px){
  .cw-section{padding:60px 0}
  .cw-spaces__grid{grid-template-columns:1fr}
  .cw-amenities__grid{grid-template-columns:1fr 1fr}
  .cw-cf-row{grid-template-columns:1fr}
}
</style>

<div class="cw-page">

<!-- ════════════════════════════════════════
     HERO
════════════════════════════════════════ -->
<section class="cw-hero">
  <div class="cw-hero__shape cw-hero__shape--1" aria-hidden="true"></div>
  <div class="cw-hero__shape cw-hero__shape--2" aria-hidden="true"></div>
  <div class="cw-hero__shape cw-hero__shape--3" aria-hidden="true"></div>

  <div class="cw-hero__inner">
    <!-- Copy -->
    <div class="cw-hero__copy">
      <div class="cw-hero__tag">Shoreditch, London — EC2A</div>
      <h1 class="cw-h1">Work Smarter.<br><span>Connect Better.</span></h1>
      <p class="cw-hero__desc">Basecamp is more than a coworking space — it's a community of 600+ freelancers, startups, and remote teams who come here to do their best work. Flexible desks to private studios, all in the heart of East London.</p>
      <div class="cw-hero__ctas">
        <a href="#contact" class="cw-btn cw-btn--primary">Book a Free Tour</a>
        <a href="#plans" class="cw-btn cw-btn--ghost">See Plans &amp; Pricing</a>
      </div>
      <div class="cw-hero__perks">
        <span class="cw-hero__perk">No lock-in contracts</span>
        <span class="cw-hero__perk">24/7 access available</span>
        <span class="cw-hero__perk">1Gbps fibre Wi-Fi</span>
        <span class="cw-hero__perk">From £15/day</span>
      </div>
    </div>

    <!-- Scene -->
    <div class="cw-hero__scene" aria-hidden="true">
      <div class="cw-room">
        <div class="cw-ceiling"></div>
        <div class="cw-brick-wall"></div>
        <div class="cw-floor"></div>

        <!-- Pendant lamps -->
        <div class="cw-pendant"><div class="cw-pendant__cord"></div><div class="cw-pendant__shade"></div></div>
        <div class="cw-pendant"><div class="cw-pendant__cord"></div><div class="cw-pendant__shade"></div></div>
        <div class="cw-pendant"><div class="cw-pendant__cord"></div><div class="cw-pendant__shade"></div></div>

        <!-- Desk -->
        <div class="cw-table"></div>

        <!-- Monitors -->
        <div class="cw-monitor cw-monitor--1">
          <div class="cw-monitor__screen"></div>
          <div class="cw-monitor__stand"></div>
          <div class="cw-monitor__base"></div>
        </div>
        <div class="cw-monitor cw-monitor--2">
          <div class="cw-monitor__screen"></div>
          <div class="cw-monitor__stand"></div>
          <div class="cw-monitor__base"></div>
        </div>
        <div class="cw-monitor cw-monitor--3">
          <div class="cw-monitor__screen"></div>
          <div class="cw-monitor__stand"></div>
          <div class="cw-monitor__base"></div>
        </div>
        <div class="cw-monitor cw-monitor--4">
          <div class="cw-monitor__screen"></div>
          <div class="cw-monitor__stand"></div>
          <div class="cw-monitor__base"></div>
        </div>

        <!-- Laptop -->
        <div class="cw-laptop">
          <div class="cw-laptop__lid"></div>
          <div class="cw-laptop__base"></div>
        </div>

        <!-- Plant -->
        <div class="cw-plant" style="position:absolute;bottom:55px;right:28px">
          <div class="cw-plant__stem" style="position:relative">
            <div class="cw-plant__leaf-l"></div>
            <div class="cw-plant__leaf-r"></div>
          </div>
          <div class="cw-plant__soil"></div>
          <div class="cw-plant__pot"></div>
        </div>

        <!-- Worker figures -->
        <div class="cw-fig cw-fig--a cw-fig--1">
          <div class="cw-fig__head"></div>
          <div class="cw-fig__body" style="position:relative">
            <div style="position:absolute;top:24px;left:-5px;right:-5px;height:10px;display:flex;gap:2px">
              <div style="width:8px;height:6px;background:#1A40AF;border-radius:3px"></div>
              <div style="width:8px;height:6px;background:#1A40AF;border-radius:3px"></div>
            </div>
          </div>
        </div>
        <div class="cw-fig cw-fig--b cw-fig--2">
          <div class="cw-fig__head"></div>
          <div class="cw-fig__body"></div>
        </div>
        <div class="cw-fig cw-fig--c cw-fig--3">
          <div class="cw-fig__head"></div>
          <div class="cw-fig__body"></div>
        </div>
      </div>

      <!-- Available badge -->
      <div class="cw-avail-badge">
        <div class="cw-avail-badge__label">🟢 Desks Available</div>
        <div class="cw-avail-badge__val">12 open today</div>
      </div>

      <!-- Wifi -->
      <div class="cw-wifi">
        <div>📶</div>
        <div class="cw-wifi__lbl">1Gbps</div>
      </div>
    </div>
  </div>

  <!-- Stats -->
  <div class="cw-hero__stats">
    <div class="cw-hero__stat">
      <div class="cw-stat-val cw-counter" data-target="600" data-suffix="+">0</div>
      <div class="cw-stat-lbl">Active Members</div>
    </div>
    <div class="cw-hero__stat">
      <div class="cw-stat-val cw-counter" data-target="12" data-suffix=" locations">0</div>
      <div class="cw-stat-lbl">London Spaces</div>
    </div>
    <div class="cw-hero__stat">
      <div class="cw-stat-val cw-counter" data-target="98" data-suffix="%">0</div>
      <div class="cw-stat-lbl">Member Satisfaction</div>
    </div>
    <div class="cw-hero__stat">
      <div class="cw-stat-val cw-counter" data-target="24" data-suffix="/7">0</div>
      <div class="cw-stat-lbl">Access Available</div>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     SPACE TYPES
════════════════════════════════════════ -->
<section class="cw-section cw-section--pearl" id="spaces">
  <div class="cw-wrap">
    <div class="cw-hgroup cw-center">
      <span class="cw-eyebrow">Space Options</span>
      <h2 class="cw-h2">Find Your Perfect Workspace</h2>
      <p class="cw-lead">Whether you need a desk for a day, a dedicated office for your team, or a professional meeting room — Basecamp has exactly what you need.</p>
    </div>
    <div class="cw-spaces__grid">
      <?php
      $cw_spaces = [
        ['bg'=>'--hot','name'=>'Hot Desk','desc'=>'Flexible daily or monthly desk access in our open-plan workspace. Perfect for freelancers and remote workers who value community and flexibility.','price'=>'From £15','per'=>'/ day','features'=>['Access to shared workspace','High-speed fibre Wi-Fi','Unlimited coffee &amp; tea','Locker storage available','Access to communal breakout areas']],
        ['bg'=>'--private','name'=>'Dedicated Desk','desc'=>'Your own reserved desk in a shared space — same desk, every day, with personal storage. The reliability of a fixed workspace, the energy of a community.','price'=>'From £280','per'=>'/ month','features'=>['Reserved personal desk','Dedicated locker included','24/7 building access','Mail handling service','Meeting room credits (4hrs/mo)']],
        ['bg'=>'--meeting','name'=>'Private Office','desc'=>'Self-contained private offices for teams of 2–20. Your own lockable space with all amenities included — set up and ready to use from day one.','price'=>'From £850','per'=>'/ month','features'=>['Fully furnished private office','Branded glass door option','24/7 dedicated access','Reception &amp; call handling','Meeting room credits (8hrs/mo)','Broadband &amp; IT support included']],
      ];
      foreach($cw_spaces as $s): ?>
      <div class="cw-space-card cw-reveal">
        <div class="cw-space-scene cw-space-scene<?php echo $s['bg']; ?>">
          <!-- Mini desk illustration -->
          <div style="position:relative">
            <div class="cw-mini-desk">
              <div class="cw-mini-screen"></div>
            </div>
          </div>
        </div>
        <div class="cw-space-card__info">
          <h3><?php echo $s['name']; ?></h3>
          <p><?php echo $s['desc']; ?></p>
          <div class="cw-space-card__price"><?php echo $s['price']; ?> <span><?php echo $s['per']; ?></span></div>
          <ul class="cw-space-card__features">
            <?php foreach($s['features'] as $f): ?>
            <li><?php echo $f; ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     AMENITIES
════════════════════════════════════════ -->
<section class="cw-section cw-amenities" id="amenities">
  <div class="cw-wrap">
    <div class="cw-hgroup cw-center">
      <span class="cw-eyebrow">Included Amenities</span>
      <h2 class="cw-h2">Everything You Need. Nothing You Don't.</h2>
      <p class="cw-lead">Every Basecamp membership includes access to a full suite of professional amenities — designed to help you focus on your work, not your workspace.</p>
    </div>
    <div class="cw-amenities__grid">
      <?php
      $cw_amens = [
        ['icon'=>'📶','title'=>'1Gbps Fibre Wi-Fi','desc'=>'Redundant symmetric gigabit internet. Wired ethernet at every desk. Zero throttling.'],
        ['icon'=>'☕','title'=>'Unlimited Coffee & Tea','desc'=>'Speciality coffee machine, herbal teas, and filtered still/sparkling water all day.'],
        ['icon'=>'🖨️','title'=>'Print & Copy','desc'=>'Black and white and colour printing, scanning, and photocopying on every floor.'],
        ['icon'=>'🔒','title'=>'Secure Storage','desc'=>'Individual lockers for daily use. Dedicated filing for permanent members.'],
        ['icon'=>'📞','title'=>'Phone Booths','desc'=>'Soundproofed private call booths — bookable or walk-in — across every floor.'],
        ['icon'=>'🤝','title'=>'Meeting Rooms','desc'=>'10 fully equipped meeting rooms, bookable via app, seating 4–16 people.'],
        ['icon'=>'🚿','title'=>'Shower Facilities','desc'=>'On-site shower rooms with towels — perfect for cyclists and runners.'],
        ['icon'=>'🌿','title'=>'Roof Terrace','desc'=>'Members-only garden terrace with seating — open April through October.'],
        ['icon'=>'📬','title'=>'Business Address','desc'=>'Use Basecamp\'s EC2A address as your registered business address.'],
        ['icon'=>'🚴','title'=>'Bike Storage','desc'=>'Secure underground cycle storage with 80+ spaces and pump station.'],
        ['icon'=>'🎉','title'=>'Community Events','desc'=>'Weekly socials, monthly guest speakers, quarterly networking evenings.'],
        ['icon'=>'🛎️','title'=>'Reception Team','desc'=>'Friendly front-of-house team Mon–Fri 8am–7pm. Call handling available.'],
      ];
      foreach($cw_amens as $a): ?>
      <div class="cw-amenity cw-reveal">
        <span class="cw-amenity__icon"><?php echo $a['icon']; ?></span>
        <h3><?php echo $a['title']; ?></h3>
        <p><?php echo $a['desc']; ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     MEMBERSHIP PLANS
════════════════════════════════════════ -->
<section class="cw-section cw-plans" id="plans">
  <div class="cw-wrap">
    <div class="cw-hgroup cw-center">
      <span class="cw-eyebrow">Membership Plans</span>
      <h2 class="cw-h2">Flexible Plans, No Lock-In</h2>
      <p class="cw-lead">Roll monthly, commit annually and save. All plans include our full amenity suite — you choose the level of space and access you need.</p>
    </div>
    <div class="cw-plans__grid">
      <div class="cw-plan cw-reveal">
        <span class="cw-plan__icon">💻</span>
        <div class="cw-plan__name">Flexible</div>
        <p class="cw-plan__desc">For freelancers and remote workers who need a professional base without daily commitment.</p>
        <div class="cw-plan__price"><sup>£</sup>149 <span>/ month</span></div>
        <hr class="cw-plan__divider">
        <ul class="cw-plan__features">
          <li class="cw-inc">10 hot desk days per month</li>
          <li class="cw-inc">1Gbps Wi-Fi included</li>
          <li class="cw-inc">Unlimited coffee &amp; tea</li>
          <li class="cw-inc">Locker (shared, daily)</li>
          <li class="cw-inc">Access to member events</li>
          <li class="cw-not">Dedicated desk</li>
          <li class="cw-not">24/7 access</li>
          <li class="cw-not">Meeting room credits</li>
        </ul>
        <a href="#contact" class="cw-btn cw-btn--outline">Get Started</a>
      </div>

      <div class="cw-plan cw-plan--featured cw-reveal">
        <div class="cw-plan__badge">Most Popular</div>
        <span class="cw-plan__icon">🌟</span>
        <div class="cw-plan__name">Pro Member</div>
        <p class="cw-plan__desc">Your own desk, your own storage, your own community. The full Basecamp experience.</p>
        <div class="cw-plan__price"><sup>£</sup>349 <span>/ month</span></div>
        <hr class="cw-plan__divider">
        <ul class="cw-plan__features">
          <li class="cw-inc">Dedicated reserved desk</li>
          <li class="cw-inc">1Gbps Wi-Fi + wired ethernet</li>
          <li class="cw-inc">Personal locker (yours, always)</li>
          <li class="cw-inc">24/7 key fob access</li>
          <li class="cw-inc">4 hrs meeting room credits/month</li>
          <li class="cw-inc">Mail handling service</li>
          <li class="cw-inc">Business address use</li>
          <li class="cw-inc">Priority event access</li>
        </ul>
        <a href="#contact" class="cw-btn cw-btn--primary">Book a Tour</a>
      </div>

      <div class="cw-plan cw-reveal">
        <span class="cw-plan__icon">🏢</span>
        <div class="cw-plan__name">Private Office</div>
        <p class="cw-plan__desc">Your own branded office for teams of 2–20. Fully serviced, fully flexible, ready from day one.</p>
        <div class="cw-plan__price"><span style="font-size:1rem">From</span> <sup>£</sup>850 <span>/ month</span></div>
        <hr class="cw-plan__divider">
        <ul class="cw-plan__features">
          <li class="cw-inc">Private lockable office</li>
          <li class="cw-inc">All Pro Member benefits</li>
          <li class="cw-inc">8 hrs meeting room credits/month</li>
          <li class="cw-inc">Reception &amp; call handling</li>
          <li class="cw-inc">IT support on-site</li>
          <li class="cw-inc">Optional branding on door</li>
          <li class="cw-inc">Flexible team sizing</li>
          <li class="cw-inc">Bespoke terms available</li>
        </ul>
        <a href="#contact" class="cw-btn cw-btn--outline">Get a Quote</a>
      </div>
    </div>
    <p style="text-align:center;margin-top:28px;font-size:.82rem;color:var(--cw-stone)">Annual commitment saves 15% on all plans. Day passes available from £15 — no membership required. Student &amp; charity rates available.</p>
  </div>
</section>

<!-- ════════════════════════════════════════
     GALLERY / SPACE SHOWCASE
════════════════════════════════════════ -->
<section class="cw-section cw-gallery cw-section--ink" id="tour">
  <div class="cw-wrap">
    <div class="cw-hgroup cw-center">
      <span class="cw-eyebrow">The Space</span>
      <h2 class="cw-h2">See Basecamp for Yourself</h2>
      <p class="cw-lead">Eight floors of beautifully designed workspace in a converted Victorian warehouse — exposed brick, original timber, filled with natural light.</p>
    </div>
    <div class="cw-gallery__mosaic">
      <?php
      $cw_tiles = [
        ['label'=>'Main Coworking Floor','col'=>'rgba(255,107,53,.12)'],
        ['label'=>'Private Phone Booths','col'=>'rgba(45,212,191,.08)'],
        ['label'=>'Meeting Suite 4','col'=>'rgba(59,130,246,.08)'],
        ['label'=>'Members Kitchen','col'=>'rgba(132,204,22,.08)'],
        ['label'=>'Roof Terrace','col'=>'rgba(255,107,53,.1)'],
        ['label'=>'Reception &amp; Lounge','col'=>'rgba(45,212,191,.1)'],
      ];
      foreach($cw_tiles as $tile): ?>
      <div class="cw-gallery__tile" style="background:linear-gradient(135deg,<?php echo $tile['col']; ?>,rgba(28,28,46,.95))">
        <div class="cw-gallery__tile__label"><?php echo $tile['label']; ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center;margin-top:32px">
      <a href="#contact" class="cw-btn cw-btn--ghost">Book a Free In-Person Tour →</a>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     COMMUNITY
════════════════════════════════════════ -->
<section class="cw-section cw-community cw-section--pearl" id="community">
  <div class="cw-wrap">
    <div class="cw-community__inner">
      <div class="cw-community__text cw-reveal">
        <span class="cw-eyebrow">Our Community</span>
        <h2 class="cw-h2">More Than a Desk. A Network.</h2>
        <p>At Basecamp, we believe your workspace should open doors as much as it provides them. Our 600+ member community spans every industry — from tech and creative to finance and law — creating genuine connections and unexpected collaborations every day.</p>
        <ul class="cw-community__items">
          <li><span><strong>Weekly socials</strong> — Thursday evening drinks, open to all members and guests.</span></li>
          <li><span><strong>Monthly speaker series</strong> — industry leaders, founders, and specialists sharing real insight.</span></li>
          <li><span><strong>Member directory</strong> — discover and connect with fellow Basecamp members in our app.</span></li>
          <li><span><strong>Skill swap &amp; workshops</strong> — members teach members. From Excel to personal branding.</span></li>
          <li><span><strong>Partner perks</strong> — exclusive deals with local restaurants, gyms, and service providers.</span></li>
        </ul>
        <a href="#contact" class="cw-btn cw-btn--primary">Join the Community</a>
      </div>
      <div class="cw-community__scene cw-reveal">
        <!-- Floating member cards -->
        <div class="cw-member-card" style="top:24px;left:20px;animation-delay:.3s">
          <div class="cw-member-card__av" style="background:#6D28D9">M</div>
          <div><div class="cw-member-card__name">Maya Okafor</div><div class="cw-member-card__role">UX Designer — Freelance</div></div>
        </div>
        <div class="cw-member-card" style="top:110px;right:16px;animation-delay:1.2s">
          <div class="cw-member-card__av" style="background:#0891B2">T</div>
          <div><div class="cw-member-card__name">Tom Barker</div><div class="cw-member-card__role">CTO, Stacklane</div></div>
        </div>
        <div class="cw-member-card" style="top:200px;left:30px;animation-delay:2s">
          <div class="cw-member-card__av" style="background:#059669">P</div>
          <div><div class="cw-member-card__name">Priya Shah</div><div class="cw-member-card__role">Founder, GreenThread</div></div>
        </div>
        <div class="cw-member-card" style="bottom:40px;right:20px;animation-delay:.8s">
          <div class="cw-member-card__av" style="background:#D97706">L</div>
          <div><div class="cw-member-card__name">Leo Weiss</div><div class="cw-member-card__role">Journalist — Remote</div></div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     TESTIMONIALS
════════════════════════════════════════ -->
<section class="cw-section cw-testis cw-section--sky">
  <div class="cw-wrap">
    <div class="cw-hgroup cw-center">
      <span class="cw-eyebrow">Member Stories</span>
      <h2 class="cw-h2">What Our Members Say</h2>
    </div>
    <div class="cw-testi-grid">
      <?php
      $cw_testis = [
        ['text'=>'I\'ve tried five coworking spaces in London. Basecamp is the only one where I\'ve actually made friends, not just LinkedIn connections. The community events make the membership worth it alone.','name'=>'Aisha Mensah','role'=>'Freelance Brand Strategist','av'=>'A','col'=>'#6D28D9'],
        ['text'=>'We moved from a traditional office lease to a Basecamp private office and it\'s one of the best decisions we\'ve made. Half the cost, twice the energy, and we can scale our space as we grow.','name'=>'Ben Hartley','role'=>'Co-founder, NovaTech','av'=>'B','col'=>'#0891B2'],
        ['text'=>'The internet speed is genuinely what it says on the tin — 1Gbps, every time, on any device. As a developer, that\'s non-negotiable. Basecamp delivers, every single day.','name'=>'Camille Fontaine','role'=>'Senior Engineer, Remote','av'=>'C','col'=>'#059669'],
      ];
      foreach($cw_testis as $t): ?>
      <div class="cw-testi cw-reveal">
        <div class="cw-testi__stars">★★★★★</div>
        <p class="cw-testi__text"><?php echo $t['text']; ?></p>
        <div class="cw-testi__author">
          <div class="cw-testi__av" style="background:<?php echo $t['col']; ?>"><?php echo $t['av']; ?></div>
          <div>
            <div class="cw-testi__name"><?php echo $t['name']; ?></div>
            <div class="cw-testi__role"><?php echo $t['role']; ?></div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     FAQ
════════════════════════════════════════ -->
<section class="cw-section cw-faq cw-section--pearl">
  <div class="cw-wrap">
    <div class="cw-hgroup cw-center">
      <span class="cw-eyebrow">FAQ</span>
      <h2 class="cw-h2">Your Questions, Answered</h2>
    </div>
    <div class="cw-faq__list">
      <?php
      $cw_faqs = [
        ['q'=>'Can I come for a day without a membership?','a'=>'Absolutely. Day passes are available from £15 and include full access to the coworking space, Wi-Fi, coffee and all shared amenities. Book online or just turn up — we always have capacity for walk-ins. Pro members get day pass discounts for guests.'],
        ['q'=>'Is there a minimum contract length?','a'=>'No lock-in. All our monthly memberships run month-to-month — just give us one month\'s notice to cancel or downgrade. Annual plans are available with a 15% discount if you prefer the commitment. Private office contracts start at 3 months.'],
        ['q'=>'What are the access hours?','a'=>'Our reception team is on-site Monday to Friday, 8am to 7pm. Pro Members and Private Office teams get 24/7 key-fob access to their space. The building is also open Saturday 9am–5pm for flexible members.'],
        ['q'=>'Can I use Basecamp as my business address?','a'=>'Yes. From the Dedicated Desk plan upward, you can use our EC2A address as your registered business or trading address. This includes mail handling — we sign for packages and notify you immediately by app.'],
        ['q'=>'Do you have parking?','a'=>'There\'s no on-site parking (we\'re in the heart of Shoreditch), but we have 80+ secure cycle spaces, a shower room, and we\'re 5 minutes from Liverpool Street, Shoreditch High Street, and Old Street stations.'],
        ['q'=>'Can my team visit if I\'m a member?','a'=>'Yes — members can bring guests into the coworking space at no charge for up to 3 days per month. Meeting rooms can be booked for client meetings at standard rates (included in monthly credits on Pro plans). Private offices accommodate your whole team with no guest restrictions.'],
      ];
      foreach($cw_faqs as $faq): ?>
      <div class="cw-faq-item">
        <button class="cw-faq-q" aria-expanded="false">
          <?php echo $faq['q']; ?>
          <span class="cw-faq-icon" aria-hidden="true">+</span>
        </button>
        <div class="cw-faq-a">
          <p><?php echo $faq['a']; ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     CONTACT / TOUR BOOKING
════════════════════════════════════════ -->
<section class="cw-section cw-contact cw-section--ink" id="contact">
  <div class="cw-wrap">
    <div class="cw-contact__inner">
      <div class="cw-contact__info">
        <span class="cw-eyebrow">Book a Tour</span>
        <h2 class="cw-h2">Come and See for Yourself</h2>
        <p class="cw-lead">Free tours run daily at 10am, 12pm, and 3pm — or book a private showing at any time. Coffee's on us.</p>
        <div class="cw-contact__detail">
          <div class="cw-contact__detail-icon">📍</div>
          <div class="cw-contact__detail-text">
            <strong>Address</strong>
            <span>42 Curtain Road, Shoreditch, London EC2A 3NH</span>
          </div>
        </div>
        <div class="cw-contact__detail">
          <div class="cw-contact__detail-icon">📞</div>
          <div class="cw-contact__detail-text">
            <strong>Phone</strong>
            <span>020 7946 1234</span>
          </div>
        </div>
        <div class="cw-contact__detail">
          <div class="cw-contact__detail-icon">✉️</div>
          <div class="cw-contact__detail-text">
            <strong>Email</strong>
            <span>hello@basecamplondon.co</span>
          </div>
        </div>
        <div class="cw-contact__hours">
          <h4>⏰ Opening Hours</h4>
          <table>
            <tr><td>Monday – Friday</td><td style="text-align:right">8:00am – 10:00pm</td></tr>
            <tr><td>Saturday</td><td style="text-align:right">9:00am – 6:00pm</td></tr>
            <tr><td>Sunday</td><td style="text-align:right">10:00am – 5:00pm</td></tr>
            <tr><td>24/7 Pro Access</td><td style="text-align:right">Always open</td></tr>
          </table>
        </div>
      </div>

      <div class="cw-cform">
        <form method="post" action="">
          <?php wp_nonce_field('tf_cw_booking','tf_cw_nonce'); ?>
          <div class="cw-cf-row">
            <div class="cw-cf">
              <label for="cw-fname">First Name *</label>
              <input type="text" id="cw-fname" name="cw_fname" placeholder="Maya" required>
            </div>
            <div class="cw-cf">
              <label for="cw-lname">Last Name *</label>
              <input type="text" id="cw-lname" name="cw_lname" placeholder="Okafor" required>
            </div>
          </div>
          <div class="cw-cf">
            <label for="cw-email">Email Address *</label>
            <input type="email" id="cw-email" name="cw_email" placeholder="maya@example.com" required>
          </div>
          <div class="cw-cf">
            <label for="cw-phone">Phone Number</label>
            <input type="tel" id="cw-phone" name="cw_phone" placeholder="07xxx xxxxxx">
          </div>
          <div class="cw-cf-row">
            <div class="cw-cf">
              <label for="cw-interest">I'm Interested In</label>
              <select id="cw-interest" name="cw_interest">
                <option>Hot Desk / Day Pass</option>
                <option>Dedicated Desk</option>
                <option>Private Office</option>
                <option>Meeting Room Hire</option>
                <option>Just browsing!</option>
              </select>
            </div>
            <div class="cw-cf">
              <label for="cw-team">Team Size</label>
              <select id="cw-team" name="cw_team">
                <option>Solo / 1 person</option>
                <option>2–5 people</option>
                <option>6–15 people</option>
                <option>16–30 people</option>
                <option>30+ people</option>
              </select>
            </div>
          </div>
          <div class="cw-cf">
            <label for="cw-message">Anything else? Questions, special requirements…</label>
            <textarea id="cw-message" name="cw_message" placeholder="Tell us anything that would help us prepare for your visit…"></textarea>
          </div>
          <button type="submit" class="cw-btn cw-btn--primary">Book My Free Tour →</button>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     FOOTER CTA
════════════════════════════════════════ -->
<div class="cw-footer-cta">
  <div class="cw-wrap">
    <h2>Your best work starts here.</h2>
    <p>Join 600+ professionals who chose Basecamp as their workspace. No lock-in — just great space, fast internet, and an incredible community.</p>
    <a href="#contact" class="cw-btn">Book a Free Tour Today →</a>
  </div>
</div>

</div><!-- .cw-page -->

<script>
(function(){
  'use strict';
  /* ── Counters ── */
  function cwEase(t){return 1-Math.pow(1-t,3)}
  document.querySelectorAll('.cw-counter').forEach(function(el){
    var target=parseFloat(el.dataset.target);
    if(isNaN(target))return;
    var prefix=el.dataset.prefix||'';var suffix=el.dataset.suffix||'';
    var started=false;
    var obs=new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(entry.isIntersecting&&!started){
          started=true;var start=performance.now();var dur=1600;
          function tick(now){
            var t=Math.min((now-start)/dur,1);
            var val=cwEase(t)*target;
            el.textContent=prefix+Math.round(val)+suffix;
            if(t<1)requestAnimationFrame(tick);
          }
          requestAnimationFrame(tick);obs.disconnect();
        }
      });
    },{threshold:.3});
    obs.observe(el);
  });
  /* ── Reveal ── */
  var reveals=document.querySelectorAll('.cw-reveal');
  if(reveals.length){
    var ro=new IntersectionObserver(function(entries){
      entries.forEach(function(entry,i){
        if(entry.isIntersecting){
          setTimeout(function(){entry.target.classList.add('cw-visible');},i*75);
          ro.unobserve(entry.target);
        }
      });
    },{threshold:.12});
    reveals.forEach(function(el){ro.observe(el);});
  }
  /* ── FAQ ── */
  document.querySelectorAll('.cw-faq-q').forEach(function(btn){
    btn.addEventListener('click',function(){
      var item=btn.closest('.cw-faq-item');
      var ans=item.querySelector('.cw-faq-a');
      var isOpen=item.classList.contains('cw-open');
      document.querySelectorAll('.cw-faq-item.cw-open').forEach(function(oi){
        oi.classList.remove('cw-open');
        oi.querySelector('.cw-faq-a').style.maxHeight='0';
        oi.querySelector('.cw-faq-q').setAttribute('aria-expanded','false');
      });
      if(!isOpen){
        item.classList.add('cw-open');
        ans.style.maxHeight=ans.scrollHeight+'px';
        btn.setAttribute('aria-expanded','true');
      }
    });
  });
  /* ── Smooth scroll ── */
  document.querySelectorAll('a[href^="#"]').forEach(function(a){
    a.addEventListener('click',function(e){
      var t=document.querySelector(a.getAttribute('href'));
      if(t){e.preventDefault();t.scrollIntoView({behavior:'smooth',block:'start'});}
    });
  });
})();
</script>

<?php get_footer(); ?>
