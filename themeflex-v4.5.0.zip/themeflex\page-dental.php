<?php
/**
 * Template Name: Premium – Dental Clinic & Implant Centre
 *
 * Namespace : --dnt-*
 * Fonts     : Nunito + Plus Jakarta Sans
 * Palette   : aqua #0097a7 · midnight #0d1f2d · pearl #f0f8fa · slate #3a4a54 · mint #e0f5f7
 */
?>

<?php
/* ── deterministic seed ── */
srand(crc32(get_the_permalink()));

/* ── PHP data ── */
$bubble_data = [];
for($i=0;$i<28;$i++) $bubble_data[] = [
  rand(2,98), rand(10,90),
  rand(8,28),
  rand(15,50)/10,
  rand(0,30)/10,
  rand(30,80)/100
];

$cross_data = [];
for($i=0;$i<12;$i++) $cross_data[] = [rand(2,98),rand(5,90),rand(14,22)/10,rand(0,30)/10];

$services = [
  ['Dental Implants',     'implants',  'Replace missing teeth with titanium implants that look, feel, and function like natural teeth. Lifetime guarantee.',     '€ 1,290','🦷','#0097a7'],
  ['Teeth Whitening',     'cosmetic',  'Professional Philips ZOOM in-chair whitening — up to 8 shades brighter in a single 60-minute appointment.',              '€ 299',  '✨','#00bcd4'],
  ['Invisalign',          'ortho',     'Straighten your smile with virtually invisible aligners. Includes all refinements and a retainer at the end.',             '€ 3,490','😁','#0097a7'],
  ['Composite Veneers',   'cosmetic',  'Same-day smile transformation using tooth-coloured composite resin. No grinding of healthy enamel required.',             '€ 350',  '💎','#26c6da'],
  ['Root Canal Therapy',  'restorative','Painless, precise endodontic treatment under microscope magnification. Same-day appointments often available.',           '€ 490',  '🔬','#0097a7'],
  ['Dental Hygiene',      'prevention','Scale, polish, and air-flow cleaning. 6-month recall with personalised prevention plan and oral cancer screening.',       '€ 89',   '🪥','#00acc1'],
  ['Porcelain Crowns',    'restorative','CEREC same-day ceramic crowns milled in-house. No temporary crowns, no second appointments.',                            '€ 890',  '👑','#0097a7'],
  ['Paediatric Dentistry','prevention','Gentle, child-friendly care. We make first dental experiences positive to build lifelong oral health habits.',            '€ 69',   '🌟','#26c6da'],
];

$team = [
  ['Dr. Lena Kaufmann','Principal Dentist, Implantology','DDS Charité Berlin. 2400+ implants placed. ITI Fellow. Invisalign Diamond Provider.','#0097a7'],
  ['Dr. Marco Ferretti','Cosmetic & Restorative','DDS Roma La Sapienza. Specialist in smile design, veneers, and full-mouth rehabilitation.','#00838f'],
  ['Dr. Aisha Rahman','Orthodontist','MSc Orthodontics UCL London. Invisalign, fixed braces, and lingual orthodontics.','#00bcd4'],
  ['Jana Sommer','Lead Dental Hygienist','15 years clinical experience. Periodontal therapist. Airflow certified.','#007c91'],
];

$testimonials = [
  ['Dr. Kaufmann replaced all four of my missing teeth with implants. The procedure was completely painless and the results are indistinguishable from my natural teeth.','Thomas B., 52','Berlin','★★★★★'],
  ['I was terrified of the dentist for 20 years. The team\'s patience and the sedation option made the whole experience surprisingly comfortable.','Maria L., 38','Hamburg','★★★★★'],
  ['My Invisalign treatment finished 2 weeks ahead of schedule and my smile has completely changed. Worth every cent.','Kai S., 29','München','★★★★★'],
];

$faqs = [
  ['Are dental implants painful?','The procedure is performed under local anaesthesia. Most patients report only mild pressure. Post-operative discomfort is typically managed with over-the-counter pain relief.'],
  ['How long do dental implants last?','With proper care, dental implants can last a lifetime. We provide a 10-year structural guarantee and lifetime aftercare support.'],
  ['Do you offer payment plans?','Yes. We partner with MediCredit to offer 0% finance over 12 months and low-rate finance up to 60 months for qualifying treatments.'],
  ['How white will teeth whitening make my teeth?','Results vary by individual. Most patients achieve 4–8 shades of improvement in a single in-chair session.'],
];
?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;500;600;700;800&family=Plus+Jakarta+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap" rel="stylesheet">
<style>
/* ════════════════════════════════════════════════
   DNT TOKEN SYSTEM
════════════════════════════════════════════════ */
:root{
  --dnt-aqua:#0097a7;
  --dnt-dark-aqua:#00838f;
  --dnt-midnight:#0d1f2d;
  --dnt-pearl:#f0f8fa;
  --dnt-slate:#3a4a54;
  --dnt-mint:#e0f5f7;
  --dnt-white:#ffffff;
  --dnt-light:#f7fbfc;
  --dnt-serif:'Plus Jakarta Sans',sans-serif;
  --dnt-sans:'Nunito',sans-serif;
  --dnt-radius:16px;
  --dnt-transition:0.35s ease;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
html{scroll-behavior:smooth;}
body.page-template-page-dental{
  font-family:var(--dnt-sans);
  background:var(--dnt-light);
  color:var(--dnt-slate);
  overflow-x:hidden;
}

/* ════ HERO ════ */
.dnt-hero{
  position:relative;
  width:100%;
  height:100vh;
  min-height:680px;
  background:var(--dnt-midnight);
  overflow:hidden;
  display:flex;
  align-items:center;
  justify-content:center;
}
/* Radial bg glow */
.dnt-hero::before{
  content:'';
  position:absolute;
  top:-10%;left:50%;
  transform:translateX(-50%);
  width:120%;height:120%;
  background:radial-gradient(ellipse at 50% 40%,rgba(0,151,167,.18),transparent 65%);
  pointer-events:none;
}

/* Floating bubbles */
.dnt-bubble{
  position:absolute;
  border-radius:50%;
  background:radial-gradient(circle at 35% 35%,rgba(255,255,255,.25),rgba(0,151,167,.12));
  border:1px solid rgba(0,188,212,.25);
  animation:dnt-float var(--dnt-bd,4s) ease-in-out infinite alternate;
  pointer-events:none;
}
@keyframes dnt-float{
  from{transform:translateY(0) translateX(0);}
  to{transform:translateY(var(--dnt-by,-18px)) translateX(var(--dnt-bx,8px));}
}

/* Plus / cross decorations */
.dnt-cross{
  position:absolute;
  color:rgba(0,151,167,.3);
  font-size:var(--dnt-cs,18px);
  font-weight:300;
  line-height:1;
  animation:dnt-spin var(--dnt-cr,8s) linear infinite;
  pointer-events:none;
}
@keyframes dnt-spin{from{transform:rotate(0deg);}to{transform:rotate(360deg);}}

/* ── Tooth illustration ── */
.dnt-tooth-wrap{
  position:absolute;
  right:8%;
  top:50%;
  transform:translateY(-50%);
  width:280px;
  height:320px;
}

/* Glow rings */
.dnt-glow-ring{
  position:absolute;
  top:50%;left:50%;
  transform:translate(-50%,-50%);
  border-radius:50%;
  border:1px solid rgba(0,151,167,.2);
  animation:dnt-ring-pulse 3s ease-in-out infinite alternate;
}
@keyframes dnt-ring-pulse{
  from{opacity:.3;transform:translate(-50%,-50%) scale(.95);}
  to{opacity:.7;transform:translate(-50%,-50%) scale(1.05);}
}

/* DNA helix - decorative left side */
.dnt-helix{
  position:absolute;
  left:3%;
  top:50%;
  transform:translateY(-50%);
  opacity:.18;
}

/* ── Hero copy ── */
.dnt-hero-copy{
  position:relative;
  z-index:10;
  max-width:580px;
  padding:2rem;
  color:var(--dnt-white);
}
.dnt-hero-eyebrow{
  display:inline-flex;
  align-items:center;
  gap:0.5rem;
  background:rgba(0,151,167,.18);
  border:1px solid rgba(0,188,212,.3);
  border-radius:30px;
  padding:0.35rem 1rem;
  font-family:var(--dnt-sans);
  font-size:0.72rem;
  font-weight:600;
  letter-spacing:0.18em;
  text-transform:uppercase;
  color:rgba(0,188,212,.9);
  margin-bottom:1.75rem;
}
.dnt-hero-title{
  font-family:var(--dnt-serif);
  font-size:clamp(2.4rem,6vw,4.5rem);
  font-weight:700;
  line-height:1.1;
  margin-bottom:1.25rem;
}
.dnt-hero-title span{color:var(--dnt-aqua);}
.dnt-hero-sub{
  font-size:1.05rem;
  font-weight:300;
  line-height:1.75;
  opacity:.7;
  margin-bottom:2.5rem;
}
.dnt-hero-ctas{display:flex;gap:1rem;flex-wrap:wrap;}
.dnt-cta{
  display:inline-block;
  padding:0.9rem 2rem;
  border-radius:8px;
  font-family:var(--dnt-sans);
  font-size:0.85rem;
  font-weight:700;
  letter-spacing:0.05em;
  text-decoration:none;
  transition:var(--dnt-transition);
}
.dnt-cta.primary{background:var(--dnt-aqua);color:#fff;}
.dnt-cta.primary:hover{background:var(--dnt-dark-aqua);transform:translateY(-1px);}
.dnt-cta.outline{border:2px solid rgba(0,188,212,.5);color:rgba(0,188,212,.9);}
.dnt-cta.outline:hover{border-color:var(--dnt-aqua);background:rgba(0,151,167,.1);}

/* Trust badges */
.dnt-trust-row{
  display:flex;
  flex-wrap:wrap;
  gap:1rem;
  margin-top:2rem;
}
.dnt-trust-badge{
  display:flex;
  align-items:center;
  gap:0.4rem;
  font-size:0.78rem;
  color:rgba(255,255,255,.55);
}
.dnt-trust-badge::before{
  content:'✓';
  color:var(--dnt-aqua);
  font-weight:700;
}

/* ════ MARQUEE ════ */
.dnt-marquee-wrap{
  background:var(--dnt-aqua);
  overflow:hidden;
  padding:0.8rem 0;
}
.dnt-marquee-track{
  display:flex;
  width:max-content;
  animation:dnt-marquee 26s linear infinite;
}
.dnt-marquee-track:hover{animation-play-state:paused;}
@keyframes dnt-marquee{from{transform:translateX(0);}to{transform:translateX(-50%);}}
.dnt-marquee-item{
  white-space:nowrap;
  font-family:var(--dnt-sans);
  font-size:0.72rem;
  font-weight:700;
  letter-spacing:0.2em;
  text-transform:uppercase;
  color:rgba(255,255,255,.8);
  padding:0 2rem;
}
.dnt-marquee-sep{color:rgba(255,255,255,.4);}

/* ════ SECTION BASE ════ */
.dnt-section{padding:6rem 1.5rem;}
.dnt-container{max-width:1080px;margin:0 auto;}
.dnt-label{
  font-family:var(--dnt-sans);
  font-size:0.68rem;
  font-weight:800;
  letter-spacing:0.3em;
  text-transform:uppercase;
  color:var(--dnt-aqua);
  margin-bottom:0.75rem;
}
.dnt-section-title{
  font-family:var(--dnt-serif);
  font-size:clamp(1.8rem,3.5vw,2.6rem);
  font-weight:700;
  line-height:1.2;
  color:var(--dnt-midnight);
  margin-bottom:1rem;
}
.dnt-section-title.light{color:var(--dnt-white);}
.dnt-lead{
  font-size:1rem;
  line-height:1.75;
  color:rgba(58,74,84,.7);
  max-width:600px;
  margin-bottom:3rem;
}

/* Reveal */
.dnt-reveal{opacity:0;transform:translateY(22px);transition:opacity .6s ease,transform .6s ease;}
.dnt-reveal.visible{opacity:1;transform:none;}

/* ════ SERVICES ════ */
.dnt-services-section{background:var(--dnt-light);}
.dnt-services-head{
  display:flex;justify-content:space-between;align-items:flex-end;
  flex-wrap:wrap;gap:1.5rem;margin-bottom:3rem;
}
.dnt-filter-bar{display:flex;gap:0.5rem;flex-wrap:wrap;}
.dnt-filter-btn{
  padding:0.45rem 1.1rem;
  border:1.5px solid rgba(0,151,167,.2);
  background:transparent;
  border-radius:30px;
  font-family:var(--dnt-sans);
  font-size:0.75rem;
  font-weight:600;
  letter-spacing:0.08em;
  cursor:pointer;
  transition:var(--dnt-transition);
  color:var(--dnt-slate);
}
.dnt-filter-btn.active,.dnt-filter-btn:hover{
  background:var(--dnt-aqua);
  color:#fff;
  border-color:var(--dnt-aqua);
}
.dnt-services-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(260px,1fr));
  gap:1.25rem;
}
.dnt-service-card{
  background:#fff;
  border-radius:var(--dnt-radius);
  padding:2rem;
  border:1.5px solid rgba(0,151,167,.08);
  transition:var(--dnt-transition);
  position:relative;
  overflow:hidden;
}
.dnt-service-card.hidden{display:none;}
.dnt-service-card::before{
  content:'';
  position:absolute;
  top:0;left:0;right:0;
  height:3px;
  background:var(--dnt-svc-color,var(--dnt-aqua));
  transform:scaleX(0);
  transform-origin:left;
  transition:var(--dnt-transition);
}
.dnt-service-card:hover{
  border-color:rgba(0,151,167,.25);
  box-shadow:0 8px 32px rgba(0,151,167,.12);
  transform:translateY(-3px);
}
.dnt-service-card:hover::before{transform:scaleX(1);}
.dnt-service-icon{
  font-size:2.2rem;
  margin-bottom:1rem;
  display:block;
}
.dnt-service-name{
  font-family:var(--dnt-serif);
  font-size:1.1rem;
  font-weight:700;
  color:var(--dnt-midnight);
  margin-bottom:0.6rem;
}
.dnt-service-desc{
  font-size:0.85rem;
  line-height:1.7;
  color:rgba(58,74,84,.65);
  margin-bottom:1rem;
}
.dnt-service-price{
  font-family:var(--dnt-serif);
  font-size:1.15rem;
  font-weight:700;
  color:var(--dnt-aqua);
}
.dnt-service-price small{
  font-family:var(--dnt-sans);
  font-size:0.7rem;
  font-weight:400;
  color:rgba(58,74,84,.5);
  margin-left:0.25rem;
}

/* ════ WHY US ════ */
.dnt-why-section{background:var(--dnt-midnight);}
.dnt-why-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(220px,1fr));
  gap:2rem;
  margin-top:3rem;
}
.dnt-why-card{
  padding:2rem;
  border:1px solid rgba(0,151,167,.15);
  border-radius:12px;
  background:rgba(255,255,255,.03);
  transition:var(--dnt-transition);
}
.dnt-why-card:hover{border-color:rgba(0,151,167,.4);background:rgba(0,151,167,.06);}
.dnt-why-icon{
  font-size:2.5rem;
  margin-bottom:1rem;
  display:block;
}
.dnt-why-title{
  font-family:var(--dnt-serif);
  font-size:1rem;
  font-weight:700;
  color:var(--dnt-white);
  margin-bottom:0.6rem;
}
.dnt-why-desc{
  font-size:0.83rem;
  line-height:1.7;
  color:rgba(240,248,250,.45);
}

/* ════ ABOUT ════ */
.dnt-about-section{background:var(--dnt-pearl);}
.dnt-about-grid{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:4rem;
  align-items:center;
}
@media(max-width:768px){.dnt-about-grid{grid-template-columns:1fr;gap:3rem;}}

/* CSS clinic art */
.dnt-clinic-art{
  position:relative;
  height:400px;
  background:linear-gradient(135deg,#e8f8fa,#d0f0f4);
  border-radius:20px;
  overflow:hidden;
}
/* Dental chair */
.dnt-chair-base{
  position:absolute;
  bottom:20px;left:50%;
  transform:translateX(-50%);
  width:220px;height:14px;
  background:linear-gradient(90deg,#b0c8d0,#d0e8ec);
  border-radius:7px;
}
.dnt-chair-pole{
  position:absolute;
  bottom:34px;left:50%;
  transform:translateX(-50%);
  width:10px;height:70px;
  background:linear-gradient(90deg,#90a8b0,#b0c8d0);
  border-radius:5px;
}
.dnt-chair-seat{
  position:absolute;
  bottom:104px;left:50%;
  transform:translateX(-50%);
  width:180px;height:28px;
  background:linear-gradient(180deg,#c8e8f0,#a8c8d0);
  border-radius:8px;
}
.dnt-chair-back{
  position:absolute;
  bottom:104px;
  left:calc(50% + 70px);
  width:28px;height:90px;
  background:linear-gradient(90deg,#a8c8d0,#c8e8f0);
  border-radius:4px 8px 4px 4px;
}
.dnt-chair-headrest{
  position:absolute;
  bottom:190px;
  left:calc(50% + 66px);
  width:36px;height:22px;
  background:linear-gradient(90deg,#b8d8e0,#d8f0f4);
  border-radius:6px;
}
.dnt-chair-arm{
  position:absolute;
  bottom:132px;
  width:100px;height:10px;
  background:linear-gradient(180deg,#b0c8d0,#90a8b0);
  border-radius:5px;
}
.dnt-arm-l{left:calc(50% - 160px);}
.dnt-arm-r{left:calc(50% + 62px);}
/* Lamp arm */
.dnt-lamp-arm{
  position:absolute;
  top:80px;
  left:calc(50% + 40px);
  width:4px;height:80px;
  background:linear-gradient(90deg,#8a9aa0,#aabac0);
  transform-origin:top;
  transform:rotate(20deg);
}
.dnt-lamp-head{
  position:absolute;
  top:148px;
  left:calc(50% + 72px);
  width:50px;height:24px;
  background:linear-gradient(90deg,#b0c8d0,#d0e8ec);
  border-radius:4px 12px 12px 4px;
}
.dnt-lamp-head::after{
  content:'';
  position:absolute;
  top:50%;left:8px;
  transform:translateY(-50%);
  width:16px;height:16px;
  border-radius:50%;
  background:radial-gradient(circle,rgba(255,250,220,.9),rgba(255,220,120,.6));
  box-shadow:0 0 12px 4px rgba(255,230,100,.3);
}
/* Tray */
.dnt-tray{
  position:absolute;
  bottom:160px;
  left:calc(50% - 130px);
  width:90px;height:6px;
  background:linear-gradient(180deg,#d0e8ec,#b0c8d0);
  border-radius:3px;
}
.dnt-tray-pole{
  position:absolute;
  bottom:166px;
  left:calc(50% - 100px);
  width:6px;height:50px;
  background:#aabac0;
  border-radius:3px;
}
/* Monitor */
.dnt-monitor{
  position:absolute;
  top:50px;right:30px;
  width:70px;height:50px;
  background:#0d1f2d;
  border-radius:6px;
  border:2px solid #2a3a44;
}
.dnt-monitor::before{
  content:'';
  position:absolute;
  inset:5px;
  border-radius:3px;
  background:linear-gradient(135deg,#0a3a4a,#0d5a6a);
}
.dnt-monitor::after{
  content:'';
  position:absolute;
  bottom:-12px;left:50%;
  transform:translateX(-50%);
  width:30px;height:10px;
  background:#1a2a34;
  border-radius:2px;
}
/* Tooth on shelf */
.dnt-shelf-tooth{
  position:absolute;
  top:50px;left:30px;
}
/* Wall decor */
.dnt-wall-cross{
  position:absolute;
  font-size:1.5rem;
  color:rgba(0,151,167,.25);
}

.dnt-about-text p{
  font-size:1rem;
  line-height:1.85;
  color:rgba(58,74,84,.75);
  margin-bottom:1.25rem;
}
.dnt-certs{
  display:flex;
  flex-wrap:wrap;
  gap:0.75rem;
  margin-top:1.5rem;
}
.dnt-cert{
  display:inline-block;
  padding:0.35rem 0.9rem;
  background:var(--dnt-mint);
  border-radius:30px;
  font-size:0.72rem;
  font-weight:700;
  letter-spacing:0.08em;
  color:var(--dnt-dark-aqua);
}

/* ════ STATS ════ */
.dnt-stats-section{background:var(--dnt-aqua);}
.dnt-stats-grid{
  display:grid;
  grid-template-columns:repeat(4,1fr);
  gap:1px;
  background:rgba(255,255,255,.15);
}
@media(max-width:600px){.dnt-stats-grid{grid-template-columns:repeat(2,1fr);}}
.dnt-stat{
  background:var(--dnt-aqua);
  padding:3rem 1.5rem;
  text-align:center;
}
.dnt-stat-num{
  font-family:var(--dnt-serif);
  font-size:clamp(2.5rem,5vw,3.5rem);
  font-weight:800;
  color:#fff;
  display:block;
  line-height:1;
  margin-bottom:0.5rem;
}
.dnt-stat-label{
  font-family:var(--dnt-sans);
  font-size:0.72rem;
  font-weight:600;
  letter-spacing:0.18em;
  text-transform:uppercase;
  color:rgba(255,255,255,.65);
}

/* ════ TEAM ════ */
.dnt-team-section{background:var(--dnt-light);}
.dnt-team-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(240px,1fr));
  gap:1.5rem;
  margin-top:3rem;
}
.dnt-team-card{
  background:#fff;
  border-radius:var(--dnt-radius);
  overflow:hidden;
  border:1.5px solid rgba(0,151,167,.07);
  transition:var(--dnt-transition);
}
.dnt-team-card:hover{box-shadow:0 8px 32px rgba(0,151,167,.12);transform:translateY(-2px);}
.dnt-team-avatar{
  height:190px;
  background:var(--dnt-midnight);
  display:flex;align-items:center;justify-content:center;
  position:relative;
  overflow:hidden;
}
.dnt-team-avatar::before{
  content:'';
  position:absolute;
  bottom:0;left:0;right:0;
  height:50px;
  background:linear-gradient(0deg,rgba(0,151,167,.25),transparent);
}
.dnt-team-body{padding:1.5rem;}
.dnt-team-name{
  font-family:var(--dnt-serif);
  font-size:1.1rem;
  font-weight:700;
  color:var(--dnt-midnight);
  margin-bottom:0.2rem;
}
.dnt-team-role{
  font-size:0.7rem;
  font-weight:700;
  letter-spacing:0.15em;
  text-transform:uppercase;
  color:var(--dnt-aqua);
  margin-bottom:0.7rem;
}
.dnt-team-bio{font-size:.83rem;line-height:1.65;color:rgba(58,74,84,.65);}

/* ════ TESTIMONIALS ════ */
.dnt-testi-section{background:var(--dnt-mint);}
.dnt-testi-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(300px,1fr));
  gap:1.5rem;
  margin-top:3rem;
}
.dnt-testi-card{
  background:#fff;
  border-radius:var(--dnt-radius);
  padding:2rem;
  transition:var(--dnt-transition);
}
.dnt-testi-card:hover{box-shadow:0 6px 24px rgba(0,151,167,.1);}
.dnt-testi-stars{color:var(--dnt-aqua);font-size:.9rem;letter-spacing:.08em;margin-bottom:1rem;}
.dnt-testi-quote{
  font-family:var(--dnt-serif);
  font-style:italic;
  font-size:1rem;
  line-height:1.7;
  color:var(--dnt-midnight);
  margin-bottom:1.25rem;
}
.dnt-testi-author{font-family:var(--dnt-sans);font-size:.78rem;font-weight:700;color:var(--dnt-slate);}
.dnt-testi-loc{font-size:.72rem;color:rgba(58,74,84,.5);margin-top:.15rem;}

/* ════ FAQ ════ */
.dnt-faq-section{background:var(--dnt-pearl);}
.dnt-faq-list{max-width:720px;margin:0 auto;}
.dnt-faq-item{
  border-bottom:1px solid rgba(0,151,167,.12);
  padding:1.5rem 0;
}
.dnt-faq-q{
  font-family:var(--dnt-serif);
  font-size:1.05rem;
  font-weight:700;
  color:var(--dnt-midnight);
  cursor:pointer;
  display:flex;
  justify-content:space-between;
  align-items:center;
  gap:1rem;
}
.dnt-faq-q::after{
  content:'+';
  font-size:1.5rem;
  font-weight:300;
  color:var(--dnt-aqua);
  flex-shrink:0;
  transition:transform var(--dnt-transition);
}
.dnt-faq-item.open .dnt-faq-q::after{transform:rotate(45deg);}
.dnt-faq-a{
  font-size:.9rem;
  line-height:1.75;
  color:rgba(58,74,84,.72);
  max-height:0;
  overflow:hidden;
  transition:max-height .4s ease,padding .4s ease;
}
.dnt-faq-item.open .dnt-faq-a{max-height:200px;padding-top:1rem;}

/* ════ APPOINTMENT ════ */
.dnt-appt-section{background:var(--dnt-midnight);}
.dnt-appt-wrap{
  display:grid;
  grid-template-columns:1fr 1.4fr;
  gap:5rem;
  align-items:start;
}
@media(max-width:768px){.dnt-appt-wrap{grid-template-columns:1fr;gap:2.5rem;}}
.dnt-appt-info p{
  font-size:.95rem;line-height:1.75;
  color:rgba(240,248,250,.5);margin-bottom:1.5rem;
}
.dnt-contact-item{
  display:flex;gap:.9rem;align-items:flex-start;
  margin-bottom:1.25rem;
  font-size:.88rem;color:rgba(240,248,250,.6);
}
.dnt-contact-icon{
  width:36px;height:36px;
  border-radius:8px;
  background:rgba(0,151,167,.2);
  display:flex;align-items:center;justify-content:center;
  flex-shrink:0;color:rgba(0,188,212,.9);font-size:1.1rem;
}
.dnt-form .dnt-field{
  width:100%;
  padding:.85rem 1rem;
  background:rgba(255,255,255,.06);
  border:1.5px solid rgba(0,151,167,.2);
  border-radius:8px;
  font-family:var(--dnt-sans);
  font-size:.9rem;
  color:var(--dnt-pearl);
  transition:border-color var(--dnt-transition);
}
.dnt-form .dnt-field::placeholder{color:rgba(240,248,250,.3);}
.dnt-form .dnt-field:focus{outline:none;border-color:var(--dnt-aqua);}
.dnt-form-row{display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin-bottom:1rem;}
@media(max-width:500px){.dnt-form-row{grid-template-columns:1fr;}}
.dnt-form-group{margin-bottom:1rem;}
.dnt-form-label{
  display:block;font-size:.68rem;
  font-weight:700;letter-spacing:.18em;
  text-transform:uppercase;
  color:rgba(240,248,250,.4);margin-bottom:.4rem;
}
.dnt-form-check{
  display:flex;gap:.75rem;align-items:flex-start;
  font-size:.83rem;color:rgba(240,248,250,.4);
  margin-bottom:1.5rem;
}
.dnt-submit{
  width:100%;padding:1rem;
  background:var(--dnt-aqua);
  color:#fff;border:none;
  border-radius:8px;
  font-family:var(--dnt-sans);
  font-size:.85rem;font-weight:800;
  letter-spacing:.1em;text-transform:uppercase;
  cursor:pointer;transition:var(--dnt-transition);
}
.dnt-submit:hover{background:var(--dnt-dark-aqua);transform:translateY(-1px);}

@media(max-width:900px){.dnt-tooth-wrap{display:none;}}
</style>
<?php get_header(); ?>
<div class="page-template-page-dental">
>

<!-- ═══════════════════════════════
     HERO
═══════════════════════════════ -->
<section class="dnt-hero" aria-label="<?php esc_attr_e('Hero','themeflex'); ?>">

  <!-- Bubbles -->
  <?php foreach($bubble_data as $b): ?>
  <div class="dnt-bubble" style="left:<?= $b[0] ?>%;top:<?= $b[1] ?>%;width:<?= $b[2] ?>px;height:<?= $b[2] ?>px;opacity:<?= $b[5] ?>;--dnt-bd:<?= $b[3] ?>s;--dnt-by:<?= (rand(0,1)?'-':'') . rand(10,22) ?>px;--dnt-bx:<?= (rand(0,1)?'-':'') . rand(4,12) ?>px;animation-delay:<?= $b[4] ?>s;"></div>
  <?php endforeach; ?>

  <!-- Crosses -->
  <?php foreach($cross_data as $c): ?>
  <span class="dnt-cross" aria-hidden="true" style="left:<?= $c[0] ?>%;top:<?= $c[1] ?>%;--dnt-cs:<?= $c[2]*10 ?>px;--dnt-cr:<?= rand(6,14) ?>s;animation-delay:<?= $c[3] ?>s;">+</span>
  <?php endforeach; ?>

  <!-- DNA Helix -->
  <div class="dnt-helix" aria-hidden="true">
    <svg width="60" height="400" viewBox="0 0 60 400">
      <?php for($i=0;$i<20;$i++): $y=$i*20; $x1=30+sin($i*0.7)*24; $x2=30-sin($i*0.7)*24; ?>
      <circle cx="<?= $x1 ?>" cy="<?= $y ?>" r="4" fill="rgba(0,188,212,.6)"/>
      <circle cx="<?= $x2 ?>" cy="<?= $y ?>" r="4" fill="rgba(0,151,167,.5)"/>
      <line x1="<?= $x1 ?>" y1="<?= $y ?>" x2="<?= $x2 ?>" y2="<?= $y ?>" stroke="rgba(0,188,212,.2)" stroke-width="1.5"/>
      <?php endfor; ?>
    </svg>
  </div>

  <!-- Tooth illustration -->
  <div class="dnt-tooth-wrap" aria-hidden="true">
    <!-- Glow rings -->
    <div class="dnt-glow-ring" style="width:200px;height:200px;animation-delay:0s;"></div>
    <div class="dnt-glow-ring" style="width:280px;height:280px;animation-delay:.8s;"></div>
    <div class="dnt-glow-ring" style="width:360px;height:360px;animation-delay:1.6s;"></div>
    <!-- Tooth SVG -->
    <svg width="280" height="320" viewBox="0 0 280 320" style="position:relative;z-index:2;">
      <!-- Main tooth shape -->
      <defs>
        <radialGradient id="toothGrad" cx="40%" cy="30%" r="60%">
          <stop offset="0%" stop-color="#ffffff"/>
          <stop offset="60%" stop-color="#e8f8fa"/>
          <stop offset="100%" stop-color="#c0e8f0"/>
        </radialGradient>
        <radialGradient id="toothShine" cx="30%" cy="20%" r="50%">
          <stop offset="0%" stop-color="rgba(255,255,255,.9)"/>
          <stop offset="100%" stop-color="rgba(255,255,255,0)"/>
        </radialGradient>
      </defs>
      <!-- Crown -->
      <path d="M60 160 Q50 80 80 40 Q100 10 140 10 Q180 10 200 40 Q230 80 220 160 Q210 200 200 220 Q185 240 170 240 Q160 240 155 230 Q150 220 140 220 Q130 220 125 230 Q120 240 110 240 Q95 240 80 220 Q70 200 60 160 Z" fill="url(#toothGrad)" stroke="rgba(0,151,167,.3)" stroke-width="2"/>
      <!-- Shine overlay -->
      <path d="M60 160 Q50 80 80 40 Q100 10 140 10 Q180 10 200 40 Q230 80 220 160 Q210 200 200 220 Q185 240 170 240 Q160 240 155 230 Q150 220 140 220 Q130 220 125 230 Q120 240 110 240 Q95 240 80 220 Q70 200 60 160 Z" fill="url(#toothShine)"/>
      <!-- Roots -->
      <path d="M110 240 Q105 270 100 300 Q98 315 105 315 Q115 315 118 295 Q120 270 125 240" fill="url(#toothGrad)" stroke="rgba(0,151,167,.2)" stroke-width="1.5"/>
      <path d="M130 230 Q128 265 128 290 Q128 310 138 310 Q148 310 148 290 Q148 265 146 230" fill="url(#toothGrad)" stroke="rgba(0,151,167,.2)" stroke-width="1.5"/>
      <path d="M155 240 Q160 270 162 295 Q165 315 172 315 Q179 315 177 300 Q175 270 170 240" fill="url(#toothGrad)" stroke="rgba(0,151,167,.2)" stroke-width="1.5"/>
      <!-- Grooves / cusps -->
      <path d="M90 60 Q110 40 140 50" stroke="rgba(0,151,167,.2)" stroke-width="2" fill="none" stroke-linecap="round"/>
      <path d="M155 45 Q175 38 195 55" stroke="rgba(0,151,167,.15)" stroke-width="1.5" fill="none" stroke-linecap="round"/>
      <!-- Aqua glow outline -->
      <path d="M60 160 Q50 80 80 40 Q100 10 140 10 Q180 10 200 40 Q230 80 220 160 Q210 200 200 220 Q185 240 170 240 Q160 240 155 230 Q150 220 140 220 Q130 220 125 230 Q120 240 110 240 Q95 240 80 220 Q70 200 60 160 Z" fill="none" stroke="rgba(0,188,212,.4)" stroke-width="3" filter="url(#glow)"/>
      <!-- Star sparkles -->
      <text x="38" y="100" font-size="16" fill="rgba(0,188,212,.7)">✦</text>
      <text x="222" y="80" font-size="12" fill="rgba(0,188,212,.5)">✦</text>
      <text x="200" y="180" font-size="8" fill="rgba(0,188,212,.4)">✦</text>
    </svg>
  </div>

  <!-- Hero Copy -->
  <div class="dnt-hero-copy">
    <div class="dnt-hero-eyebrow">
      <span>🦷</span>
      <?php esc_html_e('Award-winning dental care','themeflex'); ?>
    </div>
    <h1 class="dnt-hero-title">
      <?php esc_html_e('Your','themeflex'); ?> <span><?php esc_html_e('Perfect Smile','themeflex'); ?></span><br>
      <?php esc_html_e('Starts Here','themeflex'); ?>
    </h1>
    <p class="dnt-hero-sub"><?php esc_html_e('Premium implantology, cosmetic dentistry, and preventive care. Painless treatments, same-day solutions, and results you\'ll love.','themeflex'); ?></p>
    <div class="dnt-hero-ctas">
      <a href="#appointment" class="dnt-cta primary"><?php esc_html_e('Book Free Consultation','themeflex'); ?></a>
      <a href="#services" class="dnt-cta outline"><?php esc_html_e('View Treatments','themeflex'); ?></a>
    </div>
    <div class="dnt-trust-row">
      <span class="dnt-trust-badge"><?php esc_html_e('0% Finance Available','themeflex'); ?></span>
      <span class="dnt-trust-badge"><?php esc_html_e('Painless Guarantee','themeflex'); ?></span>
      <span class="dnt-trust-badge"><?php esc_html_e('Same-Day Implants','themeflex'); ?></span>
      <span class="dnt-trust-badge"><?php esc_html_e('BDIZ · DGZMK Members','themeflex'); ?></span>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     MARQUEE
═══════════════════════════════ -->
<div class="dnt-marquee-wrap" aria-hidden="true">
  <div class="dnt-marquee-track">
    <?php
    $awards = ['Invisalign Diamond Provider','Nobel Biocare Partner','Philips ZOOM Certified','BDIZ Elite Member','CEREC Certified','ITI Fellow','Digital Smile Design','Sedation Dentistry'];
    $dup = array_merge($awards,$awards);
    foreach($dup as $a): ?>
    <span class="dnt-marquee-item"><?= esc_html($a) ?> <span class="dnt-marquee-sep">✦</span></span>
    <?php endforeach; ?>
  </div>
</div>

<!-- ═══════════════════════════════
     SERVICES
═══════════════════════════════ -->
<section class="dnt-section dnt-services-section" id="services">
  <div class="dnt-container">
    <div class="dnt-services-head dnt-reveal">
      <div>
        <p class="dnt-label"><?php esc_html_e('Our Treatments','themeflex'); ?></p>
        <h2 class="dnt-section-title"><?php esc_html_e('Everything for Your Smile','themeflex'); ?></h2>
        <p class="dnt-lead"><?php esc_html_e('From a single tooth implant to a complete smile makeover — we offer the full spectrum of modern dentistry under one roof.','themeflex'); ?></p>
      </div>
      <div class="dnt-filter-bar" role="group" aria-label="<?php esc_attr_e('Filter treatments','themeflex'); ?>">
        <button class="dnt-filter-btn active" data-filter="all" aria-pressed="true"><?php esc_html_e('All','themeflex'); ?></button>
        <button class="dnt-filter-btn" data-filter="implants" aria-pressed="false"><?php esc_html_e('Implants','themeflex'); ?></button>
        <button class="dnt-filter-btn" data-filter="cosmetic" aria-pressed="false"><?php esc_html_e('Cosmetic','themeflex'); ?></button>
        <button class="dnt-filter-btn" data-filter="ortho" aria-pressed="false"><?php esc_html_e('Ortho','themeflex'); ?></button>
        <button class="dnt-filter-btn" data-filter="prevention" aria-pressed="false"><?php esc_html_e('Prevention','themeflex'); ?></button>
        <button class="dnt-filter-btn" data-filter="restorative" aria-pressed="false"><?php esc_html_e('Restorative','themeflex'); ?></button>
      </div>
    </div>
    <div class="dnt-services-grid" role="list">
      <?php foreach($services as $s): ?>
      <article class="dnt-service-card dnt-reveal" data-cat="<?= esc_attr($s[1]) ?>" style="--dnt-svc-color:<?= esc_attr($s[5]) ?>;" role="listitem">
        <span class="dnt-service-icon" aria-hidden="true"><?= esc_html($s[4]) ?></span>
        <h3 class="dnt-service-name"><?= esc_html($s[0]) ?></h3>
        <p class="dnt-service-desc"><?= esc_html($s[2]) ?></p>
        <p class="dnt-service-price"><?= esc_html($s[3]) ?> <small><?php esc_html_e('from','themeflex'); ?></small></p>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     WHY US
═══════════════════════════════ -->
<section class="dnt-section dnt-why-section">
  <div class="dnt-container">
    <div class="dnt-reveal" style="text-align:center;">
      <p class="dnt-label"><?php esc_html_e('Why Choose Us','themeflex'); ?></p>
      <h2 class="dnt-section-title light"><?php esc_html_e('A Different Kind of Dental Practice','themeflex'); ?></h2>
      <p style="color:rgba(240,248,250,.5);font-size:.95rem;line-height:1.75;max-width:560px;margin:1rem auto 0;"><?php esc_html_e('We combine clinical excellence with genuine patient comfort. No waiting lists, no rushing — just world-class care at your pace.','themeflex'); ?></p>
    </div>
    <div class="dnt-why-grid">
      <?php
      $whys = [
        ['🔬','Microscope Precision','All complex procedures performed under 25× magnification for unrivalled accuracy and outcomes.'],
        ['😴','Sedation Available','IV and oral sedation for anxious patients. You can be completely relaxed while we do the work.'],
        ['⚡','Same-Day Treatment','CEREC crowns, emergency extractions, and urgent implants — often completed on the same day you call.'],
        ['🌿','Metal-Free Options','Zirconia implants, ceramic restorations, and BPA-free composites for patients who prefer metal-free solutions.'],
        ['💳','0% Finance','Spread the cost of treatment with our 0% finance plans over 12 months, or low-rate finance up to 60 months.'],
        ['📱','Digital Smile Preview','See your new smile before treatment begins with our digital simulation technology.'],
      ];
      foreach($whys as $w): ?>
      <div class="dnt-why-card dnt-reveal">
        <span class="dnt-why-icon" aria-hidden="true"><?= esc_html($w[0]) ?></span>
        <h3 class="dnt-why-title"><?= esc_html($w[1]) ?></h3>
        <p class="dnt-why-desc"><?= esc_html($w[2]) ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     ABOUT
═══════════════════════════════ -->
<section class="dnt-section dnt-about-section">
  <div class="dnt-container">
    <div class="dnt-about-grid">
      <!-- CSS clinic art -->
      <div class="dnt-clinic-art dnt-reveal" aria-hidden="true">
        <!-- Wall decorations -->
        <div class="dnt-wall-cross" style="top:20px;left:15px;">+</div>
        <div class="dnt-wall-cross" style="top:30px;right:20px;font-size:1rem;">+</div>
        <!-- Monitor -->
        <div class="dnt-monitor"></div>
        <!-- Shelf tooth -->
        <div class="dnt-shelf-tooth">
          <svg width="36" height="40" viewBox="0 0 36 40">
            <path d="M5 24 Q4 12 10 5 Q14 0 18 0 Q22 0 26 5 Q32 12 31 24 Q30 30 28 33 Q26 36 22 36 Q20 36 19 34 Q18 32 18 32 Q18 32 17 34 Q16 36 14 36 Q10 36 8 33 Q6 30 5 24 Z" fill="rgba(240,248,250,.9)" stroke="rgba(0,151,167,.3)" stroke-width="1"/>
            <path d="M10 38 L8 48" stroke="rgba(0,151,167,.2)" stroke-width="1.5" stroke-linecap="round"/>
            <path d="M18 36 L18 46" stroke="rgba(0,151,167,.2)" stroke-width="1.5" stroke-linecap="round"/>
            <path d="M26 38 L28 48" stroke="rgba(0,151,167,.2)" stroke-width="1.5" stroke-linecap="round"/>
          </svg>
        </div>
        <!-- Tray pole -->
        <div class="dnt-tray-pole"></div>
        <div class="dnt-tray"></div>
        <!-- Lamp -->
        <div class="dnt-lamp-arm"></div>
        <div class="dnt-lamp-head"></div>
        <!-- Chair -->
        <div class="dnt-chair-headrest"></div>
        <div class="dnt-chair-back"></div>
        <div class="dnt-chair-arm dnt-arm-l"></div>
        <div class="dnt-chair-arm dnt-arm-r"></div>
        <div class="dnt-chair-seat"></div>
        <div class="dnt-chair-pole"></div>
        <div class="dnt-chair-base"></div>
        <!-- Aqua floor gradient -->
        <div style="position:absolute;bottom:0;left:0;right:0;height:20px;background:linear-gradient(0deg,rgba(0,151,167,.15),transparent);"></div>
      </div>
      <div class="dnt-about-text dnt-reveal">
        <p class="dnt-label"><?php esc_html_e('About Our Practice','themeflex'); ?></p>
        <h2 class="dnt-section-title"><?php esc_html_e('Excellence in Every Detail','themeflex'); ?></h2>
        <p><?php esc_html_e('Founded in 2008 by Dr. Lena Kaufmann, our practice has grown into one of Germany\'s most respected dental centres. We have placed over 2,400 implants and completed more than 800 full smile makeovers, earning a reputation for meticulous technique and outstanding results.','themeflex'); ?></p>
        <p><?php esc_html_e('We invest continuously in the latest technology — from 3D cone beam CT scanning for precise implant planning, to in-house CEREC milling for same-day ceramic restorations. Every treatment is planned digitally before a single instrument touches a tooth.','themeflex'); ?></p>
        <p><?php esc_html_e('Above all, we believe dentistry should be comfortable. Our entire team is trained in gentle techniques and anxiety management. 94% of our fearful patients rate their experience as "much better than expected".','themeflex'); ?></p>
        <div class="dnt-certs">
          <span class="dnt-cert">BDIZ Elite</span>
          <span class="dnt-cert">ITI Fellow</span>
          <span class="dnt-cert">Nobel Biocare Partner</span>
          <span class="dnt-cert">Invisalign Diamond</span>
          <span class="dnt-cert">ISO 9001</span>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     STATS
═══════════════════════════════ -->
<section class="dnt-section dnt-stats-section" aria-label="<?php esc_attr_e('Key statistics','themeflex'); ?>">
  <div class="dnt-container">
    <div class="dnt-stats-grid">
      <div class="dnt-stat dnt-reveal"><span class="dnt-stat-num" data-target="2400" data-suffix="+">2400+</span><span class="dnt-stat-label"><?php esc_html_e('Implants Placed','themeflex'); ?></span></div>
      <div class="dnt-stat dnt-reveal"><span class="dnt-stat-num" data-target="16" data-suffix="">16</span><span class="dnt-stat-label"><?php esc_html_e('Years of Excellence','themeflex'); ?></span></div>
      <div class="dnt-stat dnt-reveal"><span class="dnt-stat-num" data-target="98" data-suffix="%">98%</span><span class="dnt-stat-label"><?php esc_html_e('Patient Satisfaction','themeflex'); ?></span></div>
      <div class="dnt-stat dnt-reveal"><span class="dnt-stat-num" data-target="4" data-suffix="">4</span><span class="dnt-stat-label"><?php esc_html_e('Specialist Dentists','themeflex'); ?></span></div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     TEAM
═══════════════════════════════ -->
<section class="dnt-section dnt-team-section" aria-labelledby="dnt-team-title">
  <div class="dnt-container">
    <div class="dnt-reveal" style="text-align:center;">
      <p class="dnt-label"><?php esc_html_e('Our Specialists','themeflex'); ?></p>
      <h2 class="dnt-section-title" id="dnt-team-title"><?php esc_html_e('Meet the Team','themeflex'); ?></h2>
      <p class="dnt-lead" style="margin:0 auto 3rem;"><?php esc_html_e('Board-certified specialists with decades of combined clinical experience — all under one roof.','themeflex'); ?></p>
    </div>
    <div class="dnt-team-grid">
      <?php foreach($team as $i => $m): ?>
      <div class="dnt-team-card dnt-reveal">
        <div class="dnt-team-avatar">
          <svg width="120" height="170" viewBox="0 0 120 170" aria-hidden="true">
            <!-- Scrubs body -->
            <path d="M25 80 Q16 94 14 160 L106 160 Q104 94 95 80 Z" fill="<?= esc_attr($m[3]) ?>"/>
            <!-- White coat overlay -->
            <path d="M25 80 L30 160 L14 160 Q16 94 25 80 Z" fill="rgba(255,255,255,.2)"/>
            <path d="M95 80 L90 160 L106 160 Q104 94 95 80 Z" fill="rgba(255,255,255,.15)"/>
            <!-- Stethoscope -->
            <path d="M48 90 Q42 110 45 120 Q48 128 55 125 Q62 122 60 114 Q58 108 54 108" stroke="rgba(255,255,255,.5)" stroke-width="3" fill="none" stroke-linecap="round"/>
            <circle cx="54" cy="108" r="5" fill="none" stroke="rgba(255,255,255,.5)" stroke-width="2"/>
            <!-- Pocket -->
            <rect x="72" y="110" width="20" height="18" rx="3" fill="rgba(255,255,255,.12)" stroke="rgba(255,255,255,.15)" stroke-width="1"/>
            <!-- Pen in pocket -->
            <rect x="79" y="104" width="2.5" height="14" rx="1" fill="rgba(255,255,255,.5)"/>
            <!-- Arms -->
            <rect x="4" y="83" width="20" height="46" rx="9" fill="<?= esc_attr($m[3]) ?>"/>
            <rect x="96" y="83" width="20" height="46" rx="9" fill="<?= esc_attr($m[3]) ?>"/>
            <!-- Hands -->
            <ellipse cx="14" cy="131" rx="9" ry="7" fill="#e8c8a0"/>
            <ellipse cx="106" cy="131" rx="9" ry="7" fill="#e8c8a0"/>
            <!-- Neck -->
            <rect x="53" y="66" width="14" height="17" rx="6" fill="#e8c8a0"/>
            <!-- Head -->
            <ellipse cx="60" cy="50" rx="24" ry="26" fill="#e8c8a0"/>
            <!-- Eyes -->
            <ellipse cx="52" cy="46" rx="3.2" ry="3.6" fill="#3a2a1a"/>
            <ellipse cx="68" cy="46" rx="3.2" ry="3.6" fill="#3a2a1a"/>
            <circle cx="53" cy="44.5" r="1.2" fill="#fff"/>
            <circle cx="69" cy="44.5" r="1.2" fill="#fff"/>
            <!-- Smile -->
            <path d="M54 58 Q60 64 66 58" stroke="#8a5a3a" stroke-width="1.5" fill="none" stroke-linecap="round"/>
            <!-- Hair -->
            <?php if($i===0||$i===2): ?>
            <!-- Female - longer hair -->
            <ellipse cx="60" cy="26" rx="24" ry="14" fill="<?= $i===0?'#4a2a1a':'#1a1a1a' ?>"/>
            <rect x="36" y="22" width="9" height="40" rx="4.5" fill="<?= $i===0?'#4a2a1a':'#1a1a1a' ?>"/>
            <rect x="75" y="22" width="9" height="40" rx="4.5" fill="<?= $i===0?'#4a2a1a':'#1a1a1a' ?>"/>
            <?php else: ?>
            <!-- Male hair -->
            <ellipse cx="60" cy="26" rx="24" ry="13" fill="#3a2a1a"/>
            <rect x="36" y="24" width="7" height="24" rx="3.5" fill="#3a2a1a"/>
            <rect x="77" y="24" width="7" height="24" rx="3.5" fill="#3a2a1a"/>
            <?php endif; ?>
            <?php if($i===1): ?>
            <!-- Glasses -->
            <circle cx="52" cy="46" r="8" fill="none" stroke="#3a2a1a" stroke-width="1.5"/>
            <circle cx="68" cy="46" r="8" fill="none" stroke="#3a2a1a" stroke-width="1.5"/>
            <line x1="60" y1="46" x2="60" y2="46" stroke="#3a2a1a" stroke-width="1.5"/>
            <line x1="44" y1="46" x2="38" y2="48" stroke="#3a2a1a" stroke-width="1.5"/>
            <line x1="76" y1="46" x2="82" y2="48" stroke="#3a2a1a" stroke-width="1.5"/>
            <?php endif; ?>
            <!-- Surgical mask (Jana) -->
            <?php if($i===3): ?>
            <rect x="38" y="55" width="44" height="20" rx="5" fill="rgba(0,151,167,.7)" opacity=".85"/>
            <path d="M38 62 Q60 70 82 62" stroke="rgba(0,151,167,.5)" stroke-width="1" fill="none"/>
            <line x1="38" y1="59" x2="28" y2="55" stroke="rgba(0,151,167,.5)" stroke-width="1.5"/>
            <line x1="82" y1="59" x2="92" y2="55" stroke="rgba(0,151,167,.5)" stroke-width="1.5"/>
            <?php endif; ?>
          </svg>
        </div>
        <div class="dnt-team-body">
          <h3 class="dnt-team-name"><?= esc_html($m[0]) ?></h3>
          <p class="dnt-team-role"><?= esc_html($m[1]) ?></p>
          <p class="dnt-team-bio"><?= esc_html($m[2]) ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     TESTIMONIALS
═══════════════════════════════ -->
<section class="dnt-section dnt-testi-section" aria-labelledby="dnt-testi-title">
  <div class="dnt-container">
    <div class="dnt-reveal" style="text-align:center;">
      <p class="dnt-label"><?php esc_html_e('Patient Stories','themeflex'); ?></p>
      <h2 class="dnt-section-title" id="dnt-testi-title"><?php esc_html_e('Real Results, Real Smiles','themeflex'); ?></h2>
    </div>
    <div class="dnt-testi-grid">
      <?php foreach($testimonials as $t): ?>
      <blockquote class="dnt-testi-card dnt-reveal">
        <p class="dnt-testi-stars"><?= esc_html($t[3]) ?></p>
        <p class="dnt-testi-quote"><?= esc_html($t[0]) ?></p>
        <footer>
          <p class="dnt-testi-author"><?= esc_html($t[1]) ?></p>
          <p class="dnt-testi-loc"><?= esc_html($t[2]) ?></p>
        </footer>
      </blockquote>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     FAQ
═══════════════════════════════ -->
<section class="dnt-section dnt-faq-section" aria-labelledby="dnt-faq-title">
  <div class="dnt-container">
    <div class="dnt-reveal" style="text-align:center;margin-bottom:3rem;">
      <p class="dnt-label"><?php esc_html_e('FAQ','themeflex'); ?></p>
      <h2 class="dnt-section-title" id="dnt-faq-title"><?php esc_html_e('Common Questions','themeflex'); ?></h2>
    </div>
    <div class="dnt-faq-list">
      <?php foreach($faqs as $f): ?>
      <div class="dnt-faq-item dnt-reveal">
        <button class="dnt-faq-q" aria-expanded="false"><?= esc_html($f[0]) ?></button>
        <div class="dnt-faq-a" role="region"><?= esc_html($f[1]) ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     APPOINTMENT
═══════════════════════════════ -->
<section class="dnt-section dnt-appt-section" id="appointment" aria-labelledby="dnt-appt-title">
  <div class="dnt-container">
    <div class="dnt-appt-wrap">
      <div class="dnt-appt-info dnt-reveal">
        <p class="dnt-label"><?php esc_html_e('Book an Appointment','themeflex'); ?></p>
        <h2 class="dnt-section-title light" id="dnt-appt-title"><?php esc_html_e('Free Consultation — No Obligation','themeflex'); ?></h2>
        <div style="width:55px;height:2px;background:var(--dnt-aqua);margin:1.5rem 0 2.5rem;"></div>
        <p><?php esc_html_e('All new patient consultations are free. We\'ll review your dental history, take digital X-rays, and create a personalised treatment plan with transparent pricing before you commit to anything.','themeflex'); ?></p>
        <div class="dnt-contact-item">
          <div class="dnt-contact-icon">📞</div>
          <span>+49 30 000 0000</span>
        </div>
        <div class="dnt-contact-item">
          <div class="dnt-contact-icon">✉</div>
          <span><?php esc_html_e('smile@zahnklinik-kaufmann.de','themeflex'); ?></span>
        </div>
        <div class="dnt-contact-item">
          <div class="dnt-contact-icon">📍</div>
          <span>Kurfürstendamm 42, 10707 Berlin</span>
        </div>
        <div class="dnt-contact-item">
          <div class="dnt-contact-icon">🕐</div>
          <div>
            <span style="display:block;"><?php esc_html_e('Mon–Fri: 08:00 – 19:00','themeflex'); ?></span>
            <span style="display:block;"><?php esc_html_e('Saturday: 09:00 – 14:00','themeflex'); ?></span>
          </div>
        </div>
      </div>
      <div class="dnt-reveal">
        <form class="dnt-form" method="post" action="#appointment" novalidate>
          <?php wp_nonce_field('tf_dnt_appointment','tf_dnt_nonce'); ?>
          <div class="dnt-form-row">
            <div class="dnt-form-group">
              <label class="dnt-form-label" for="dnt_fname"><?php esc_html_e('First Name','themeflex'); ?> *</label>
              <input class="dnt-field" id="dnt_fname" name="dnt_fname" type="text" required autocomplete="given-name">
            </div>
            <div class="dnt-form-group">
              <label class="dnt-form-label" for="dnt_lname"><?php esc_html_e('Last Name','themeflex'); ?> *</label>
              <input class="dnt-field" id="dnt_lname" name="dnt_lname" type="text" required autocomplete="family-name">
            </div>
          </div>
          <div class="dnt-form-row">
            <div class="dnt-form-group">
              <label class="dnt-form-label" for="dnt_email"><?php esc_html_e('Email','themeflex'); ?> *</label>
              <input class="dnt-field" id="dnt_email" name="dnt_email" type="email" required autocomplete="email">
            </div>
            <div class="dnt-form-group">
              <label class="dnt-form-label" for="dnt_phone"><?php esc_html_e('Phone','themeflex'); ?> *</label>
              <input class="dnt-field" id="dnt_phone" name="dnt_phone" type="tel" required autocomplete="tel">
            </div>
          </div>
          <div class="dnt-form-row">
            <div class="dnt-form-group">
              <label class="dnt-form-label" for="dnt_date"><?php esc_html_e('Preferred Date','themeflex'); ?></label>
              <input class="dnt-field" id="dnt_date" name="dnt_date" type="date">
            </div>
            <div class="dnt-form-group">
              <label class="dnt-form-label" for="dnt_time"><?php esc_html_e('Preferred Time','themeflex'); ?></label>
              <select class="dnt-field" id="dnt_time" name="dnt_time">
                <option value=""><?php esc_html_e('Any time','themeflex'); ?></option>
                <option value="morning"><?php esc_html_e('Morning (08:00–12:00)','themeflex'); ?></option>
                <option value="afternoon"><?php esc_html_e('Afternoon (12:00–16:00)','themeflex'); ?></option>
                <option value="evening"><?php esc_html_e('Evening (16:00–19:00)','themeflex'); ?></option>
              </select>
            </div>
          </div>
          <div class="dnt-form-group">
            <label class="dnt-form-label" for="dnt_treatment"><?php esc_html_e('Treatment of Interest','themeflex'); ?></label>
            <select class="dnt-field" id="dnt_treatment" name="dnt_treatment">
              <option value=""><?php esc_html_e('Select treatment','themeflex'); ?></option>
              <option value="implants"><?php esc_html_e('Dental Implants','themeflex'); ?></option>
              <option value="whitening"><?php esc_html_e('Teeth Whitening','themeflex'); ?></option>
              <option value="invisalign"><?php esc_html_e('Invisalign','themeflex'); ?></option>
              <option value="veneers"><?php esc_html_e('Veneers','themeflex'); ?></option>
              <option value="hygiene"><?php esc_html_e('Hygiene Appointment','themeflex'); ?></option>
              <option value="other"><?php esc_html_e('General / Other','themeflex'); ?></option>
            </select>
          </div>
          <div class="dnt-form-group">
            <label class="dnt-form-label" for="dnt_notes"><?php esc_html_e('Tell Us About Your Concerns','themeflex'); ?></label>
            <textarea class="dnt-field" id="dnt_notes" name="dnt_notes" rows="4" style="resize:vertical;"></textarea>
          </div>
          <div class="dnt-form-check">
            <input type="checkbox" id="dnt_consent" name="dnt_consent" required style="margin-top:2px;">
            <label for="dnt_consent"><?php esc_html_e('I consent to my data being processed for the purpose of booking this appointment, in accordance with GDPR and the practice\'s privacy policy.','themeflex'); ?></label>
          </div>
          <button type="submit" class="dnt-submit" name="dnt_submit"><?php esc_html_e('Book Free Consultation','themeflex'); ?></button>
        </form>
      </div>
    </div>
  </div>
</section>

<script>
(function(){
  'use strict';
  /* ── Scroll reveal ── */
  const obs = new IntersectionObserver(entries=>{
    entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');obs.unobserve(e.target);}});
  },{threshold:.1});
  document.querySelectorAll('.dnt-reveal').forEach(el=>obs.observe(el));

  /* ── Service filter ── */
  const btns  = document.querySelectorAll('.dnt-filter-btn');
  const cards = document.querySelectorAll('.dnt-service-card');
  btns.forEach(btn=>{
    btn.addEventListener('click',()=>{
      btns.forEach(b=>{b.classList.remove('active');b.setAttribute('aria-pressed','false');});
      btn.classList.add('active');
      btn.setAttribute('aria-pressed','true');
      const f = btn.dataset.filter;
      cards.forEach(c=>c.classList.toggle('hidden',f!=='all'&&c.dataset.cat!==f));
    });
  });

  /* ── FAQ accordion ── */
  document.querySelectorAll('.dnt-faq-q').forEach(q=>{
    q.addEventListener('click',()=>{
      const item = q.closest('.dnt-faq-item');
      const open = item.classList.contains('open');
      document.querySelectorAll('.dnt-faq-item.open').forEach(i=>i.classList.remove('open'));
      document.querySelectorAll('.dnt-faq-q').forEach(qq=>qq.setAttribute('aria-expanded','false'));
      if(!open){item.classList.add('open');q.setAttribute('aria-expanded','true');}
    });
  });

  /* ── Animated counters ── */
  const easeOut = t=>1-Math.pow(1-t,3);
  const cobs = new IntersectionObserver(entries=>{
    entries.forEach(e=>{
      if(!e.isIntersecting) return;
      const el = e.target;
      const target = parseFloat(el.dataset.target);
      const suffix = el.dataset.suffix||'';
      const dur = 1800;
      const t0 = performance.now();
      const tick = now=>{
        const p = Math.min((now-t0)/dur,1);
        el.textContent = Math.round(easeOut(p)*target)+suffix;
        if(p<1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      cobs.unobserve(el);
    });
  },{threshold:.5});
  document.querySelectorAll('.dnt-stat-num[data-target]').forEach(el=>cobs.observe(el));
})();
</script>

</body>
</html>
</div><!-- .page-template-page-dental -->
<?php get_footer(); ?>
