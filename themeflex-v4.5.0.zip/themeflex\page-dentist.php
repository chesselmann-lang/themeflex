<?php
/**
 * Template Name: Dentist – Modern Dental Practice & Smile Clinic
 *
 * Premium cosmetic dental practice page template for ThemeFlex.
 * Clarity Dental — Cosmetic & Restorative Dentistry, Chelsea London
 *
 * @package ThemeFlex
 */

defined('ABSPATH') || exit;

srand(crc32(get_the_permalink()));

// PHP-generated particle dots for hero (clinical clean aesthetic)
$dt_particles = [];
for ($i = 0; $i < 18; $i++) {
    $dt_particles[] = [
        'top'   => rand(8, 90),
        'left'  => rand(4, 94),
        'size'  => rand(2, 6),
        'delay' => rand(0, 4000),
        'dur'   => 3000 + rand(0, 3000),
        'opacity' => (rand(1,4) / 10),
    ];
}

// Treatment list
$dt_treatments = [
  ['icon'=>'◈', 'name'=>'Teeth Whitening',      'desc'=>'Enlighten & Zoom professional whitening — up to 16 shades brighter, with guaranteed results in a single visit.',          'from'=>'From £495'],
  ['icon'=>'◉', 'name'=>'Porcelain Veneers',     'desc'=>'Ultra-thin, custom-crafted porcelain laminates that transform the shape, colour and alignment of your smile permanently.', 'from'=>'From £1,200/tooth'],
  ['icon'=>'◎', 'name'=>'Dental Implants',       'desc'=>'Titanium-root permanent tooth replacement with a natural porcelain crown. The gold standard in missing tooth restoration.',  'from'=>'From £2,800'],
  ['icon'=>'◇', 'name'=>'Invisalign',            'desc'=>'Clear aligner orthodontics for discreet teeth straightening. Diamond-tier Invisalign provider — fastest results available.',  'from'=>'From £2,400'],
  ['icon'=>'◈', 'name'=>'Composite Bonding',     'desc'=>'Same-day smile transformation using artistically applied tooth-coloured composite resin. No drilling, no anaesthetic.',       'from'=>'From £350/tooth'],
  ['icon'=>'◑', 'name'=>'Full Smile Makeover',   'desc'=>'A comprehensive, bespoke treatment plan combining multiple procedures to achieve your perfect smile from first consultation.', 'from'=>'From £6,500'],
];

// Team members
$dt_team = [
  ['name'=>'Dr Isabelle Laurent',  'role'=>'Principal Dentist',          'spec'=>'Cosmetic & Restorative · GDC 123456 · BDS (Hons) UCL, MJDF RCSEng'],
  ['name'=>'Dr Marcus Chen',       'role'=>'Implant & Oral Surgeon',     'spec'=>'Implantology · GDC 234567 · BDS Newcastle, PgDip Implantology'],
  ['name'=>'Dr Amara Osei-Bonsu',  'role'=>'Orthodontist',               'spec'=>'Invisalign Diamond · GDC 345678 · BDS UCL, MOrth RCSEd'],
  ['name'=>'Dr Sophie Whitmore',   'role'=>'Hygiene & Prevention Lead',  'spec'=>'Periodontics · GDC 456789 · BDS (Hons) Kings College'],
];

// Smile process steps
$dt_steps = [
  ['num'=>'01', 'title'=>'Smile Consultation',    'text'=>'A comprehensive 60-minute consultation including digital smile design and radiographs. We listen first, advise second.'],
  ['num'=>'02', 'title'=>'Bespoke Treatment Plan', 'text'=>'Your personalised, phased treatment plan with transparent pricing and no surprises — reviewed together before anything begins.'],
  ['num'=>'03', 'title'=>'Expert Treatment',       'text'=>'Every procedure performed in our state-of-the-art Chelsea suite using the latest materials and technology.'],
  ['num'=>'04', 'title'=>'Smile for Life',         'text'=>'Aftercare guidance, maintenance appointments, and ongoing support. Your new smile is guaranteed — for life.'],
];

// Packages
$dt_packages = [
  [
    'tier'  => 'Starter',
    'name'  => 'Smile Refresh',
    'price' => '£895',
    'per'   => 'Single visit',
    'feat'  => ['Professional clean & polish', 'Zoom whitening session', 'Digital smile assessment', 'Aftercare kit & maintenance guide', 'Follow-up review appointment'],
    'featured' => false,
  ],
  [
    'tier'  => 'Transformation',
    'name'  => 'Smile Makeover',
    'price' => '£3,800',
    'per'   => 'Starting from · finance available',
    'feat'  => ['Everything in Smile Refresh', 'Digital Smile Design visualisation', 'Composite bonding (up to 8 teeth)', 'Gum contouring if required', 'Invisalign Lite (minor corrections)', '12-month aftercare programme'],
    'featured' => true,
  ],
  [
    'tier'  => 'Complete',
    'name'  => 'Full Smile Design',
    'price' => 'POA',
    'per'   => 'Fully bespoke · finance available',
    'feat'  => ['Full diagnostic workup & DSD', 'Porcelain veneers or full-arch crowns', 'Dental implants where required', 'Orthodontics included if needed', 'Gum treatment & recontouring', 'Lifetime guarantee on all work'],
    'featured' => false,
  ],
];

?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,300;0,400;0,500;0,600;1,300&family=Lora:ital,wght@0,400;0,600;1,400;1,600&display=swap" rel="stylesheet">
<style>
/* ============================================================
   CLARITY DENTAL — CSS DESIGN SYSTEM
   Namespace: --dt-*  |  No external image dependencies
   Clinical-luxury: pure white, sky blue, soft gold accents
   ============================================================ */

:root {
  --dt-white:      #FFFFFF;
  --dt-snow:       #F8FAFB;
  --dt-frost:      #EEF4F8;
  --dt-sky:        #D4E8F4;
  --dt-blue:       #2A7BB5;
  --dt-blue-deep:  #1A5A8A;
  --dt-blue-pale:  #E8F3FA;
  --dt-navy:       #0E2A40;
  --dt-slate:      #4A6070;
  --dt-mist:       #8FA8B8;
  --dt-gold:       #C8A850;
  --dt-gold-pale:  #F0E0B0;
  --dt-charcoal:   #1A2A34;

  --dt-serif:  'Lora', Georgia, serif;
  --dt-sans:   'Plus Jakarta Sans', system-ui, sans-serif;

  --dt-ease:   cubic-bezier(.22,.68,0,1.2);
  --dt-dur:    .4s;
  --dt-r:      4px;
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; }

body.dt-body {
  font-family: var(--dt-sans);
  background: var(--dt-white);
  color: var(--dt-charcoal);
  overflow-x: hidden;
  -webkit-font-smoothing: antialiased;
}

/* ── NAV ──────────────────────────────────────────────────── */
.dt-nav {
  position: fixed; top: 0; left: 0; right: 0; z-index: 200;
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 56px; height: 72px;
  background: rgba(255,255,255,.96);
  backdrop-filter: blur(14px);
  border-bottom: 1px solid rgba(42,123,181,.1);
  box-shadow: 0 1px 20px rgba(14,42,64,.06);
}
.dt-nav__logo {
  display: flex; align-items: center; gap: 12px;
}
.dt-nav__icon {
  width: 36px; height: 36px;
  background: var(--dt-blue);
  border-radius: 8px;
  display: flex; align-items: center; justify-content: center;
  font-size: 1.1rem; color: var(--dt-white);
}
.dt-nav__wordmark { display: flex; flex-direction: column; gap: 1px; }
.dt-nav__name {
  font-family: var(--dt-serif); font-size: 1.1rem;
  font-weight: 600; color: var(--dt-navy); letter-spacing: .02em;
}
.dt-nav__tagline {
  font-size: .6rem; letter-spacing: .22em;
  color: var(--dt-blue); text-transform: uppercase;
}
.dt-nav__links { display: flex; gap: 32px; list-style: none; }
.dt-nav__links a {
  font-size: .8rem; font-weight: 500; letter-spacing: .04em;
  color: var(--dt-slate); text-decoration: none;
  transition: color var(--dt-dur);
}
.dt-nav__links a:hover { color: var(--dt-blue); }
.dt-nav__cta {
  padding: 10px 26px; border-radius: var(--dt-r);
  background: var(--dt-blue); color: var(--dt-white);
  font-family: var(--dt-sans); font-size: .8rem; font-weight: 500;
  letter-spacing: .06em; text-decoration: none;
  transition: background var(--dt-dur);
}
.dt-nav__cta:hover { background: var(--dt-blue-deep); }

/* ── HERO ─────────────────────────────────────────────────── */
.dt-hero {
  position: relative; width: 100%; height: 100vh; min-height: 700px;
  overflow: hidden; background: var(--dt-navy);
  display: flex; align-items: flex-end;
}

/* Clinical ceiling */
.dt-ceiling {
  position: absolute; top: 0; left: 0; right: 0; height: 20%;
  background: linear-gradient(180deg, #0A1E30 0%, #0E2A40 100%);
  border-bottom: 1px solid rgba(212,232,244,.06);
}
.dt-ceiling::before {
  content: '';
  position: absolute; inset: 0;
  background: repeating-linear-gradient(
    90deg,
    transparent 0, transparent 59px,
    rgba(255,255,255,.02) 59px, rgba(255,255,255,.02) 60px
  );
}

/* Clinical walls */
.dt-wall {
  position: absolute; top: 0; bottom: 22%; left: 0; right: 0;
  background: linear-gradient(180deg, #0E2A40 0%, #142C40 60%, #1A3048 100%);
}
.dt-wall::before {
  content: '';
  position: absolute; inset: 0;
  background: radial-gradient(ellipse 80% 80% at 50% 20%, rgba(212,232,244,.04) 0%, transparent 70%);
}

/* Tile dado lower wall */
.dt-dado {
  position: absolute;
  bottom: 22%; left: 0; right: 0; height: 30%;
  background: linear-gradient(180deg, #F0F8FE 0%, #E8F4FA 100%);
  border-top: 2px solid #D0E8F4;
}
.dt-dado::before {
  content: '';
  position: absolute; inset: 0;
  background:
    repeating-linear-gradient(90deg, transparent 0, transparent 59px, rgba(42,123,181,.08) 59px, rgba(42,123,181,.08) 60px),
    repeating-linear-gradient(180deg, transparent 0, transparent 59px, rgba(42,123,181,.08) 59px, rgba(42,123,181,.08) 60px);
}

/* Clinical floor */
.dt-floor {
  position: absolute; bottom: 0; left: 0; right: 0; height: 22%;
  background: linear-gradient(180deg, #F4F8FC 0%, #E8F0F8 100%);
  border-top: 1px solid #D0E0F0;
}
.dt-floor::before {
  content: '';
  position: absolute; inset: 0;
  background:
    repeating-linear-gradient(90deg, transparent 0, transparent 79px, rgba(42,123,181,.06) 79px, rgba(42,123,181,.06) 80px),
    repeating-linear-gradient(180deg, transparent 0, transparent 39px, rgba(42,123,181,.06) 39px, rgba(42,123,181,.06) 40px);
}

/* ── DENTAL CHAIR ─────────────────────────────────────────── */
.dt-chair-wrap {
  position: absolute;
  bottom: 22%;
  right: 18%;
  display: flex; flex-direction: column; align-items: center;
}
.dt-chair-back {
  position: relative;
  width: 120px; height: 160px;
  background: linear-gradient(180deg, #F8FAFB 0%, #EEF4F8 100%);
  border-radius: 8px 8px 2px 2px;
  border: 1px solid rgba(42,123,181,.15);
}
.dt-chair-back::before { /* headrest */
  content: '';
  position: absolute; top: -18px; left: 50%; transform: translateX(-50%);
  width: 70px; height: 22px;
  background: linear-gradient(180deg, #F0F8FE 0%, #E0EEF8 100%);
  border-radius: 11px 11px 0 0;
  border: 1px solid rgba(42,123,181,.12);
  border-bottom: none;
}
.dt-chair-back::after { /* control panel on right side */
  content: '';
  position: absolute; top: 30px; right: -24px;
  width: 20px; height: 80px;
  background: linear-gradient(180deg, #E8F0F8 0%, #D8E8F0 100%);
  border-radius: 4px;
  border: 1px solid rgba(42,123,181,.12);
}
.dt-chair-seat {
  width: 140px; height: 36px;
  background: linear-gradient(180deg, #EEF4F8 0%, #E0EEF8 100%);
  border-radius: 2px;
  border: 1px solid rgba(42,123,181,.12);
  border-top: none;
  position: relative;
}
.dt-chair-arm {
  position: absolute; top: 20px;
  width: 34px; height: 12px;
  background: linear-gradient(180deg, #E8F0F8 0%, #D8E8F0 100%);
  border-radius: 6px;
  border: 1px solid rgba(42,123,181,.1);
}
.dt-chair-arm--l { left: -34px; }
.dt-chair-arm--r { right: -34px; }
.dt-chair-pedestal {
  width: 20px; height: 60px;
  background: linear-gradient(180deg, #D0D8E0 0%, #B8C4CC 100%);
  border-radius: 2px;
}
.dt-chair-base {
  width: 80px; height: 12px;
  background: linear-gradient(180deg, #C8D4DC 0%, #B0BCC8 100%);
  border-radius: 4px;
}

/* Patient figure reclined in chair */
.dt-patient {
  position: absolute;
  top: 18px; left: 50%; transform: translateX(-50%);
  display: flex; flex-direction: column; align-items: center;
}
.dt-patient__head {
  width: 36px; height: 36px; border-radius: 50%;
  background: radial-gradient(circle at 38% 35%, #E8C8A8 0%, #C8A888 50%, #9A7860 100%);
  position: relative;
}
.dt-patient__head::before { /* hair */
  content: '';
  position: absolute; top: -3px; left: -2px; right: -2px; height: 22px;
  background: #5A3820;
  border-radius: 18px 18px 0 0;
  clip-path: polygon(0 80%, 0 20%, 50% 0%, 100% 20%, 100% 80%);
}
.dt-patient__body {
  width: 100px; height: 100px;
  background: linear-gradient(180deg, #E8EEF4 0%, #D8E4EE 100%); /* gown */
  border-radius: 4px 4px 0 0;
  border: 1px solid rgba(42,123,181,.1);
}

/* ── OVERHEAD LIGHT ───────────────────────────────────────── */
.dt-overhead-light {
  position: absolute;
  top: 18%; left: 50%; transform: translateX(-20%);
  display: flex; flex-direction: column; align-items: center;
  z-index: 5;
}
.dt-light-arm {
  width: 3px; height: 80px;
  background: linear-gradient(180deg, #4A6070 0%, #5A7080 100%);
}
.dt-light-arm-h {
  width: 60px; height: 3px;
  background: linear-gradient(90deg, #5A7080 0%, #4A6070 100%);
  margin-top: -3px;
}
.dt-light-head {
  position: relative;
  width: 90px; height: 32px;
  background: linear-gradient(180deg, #F8FAFB 0%, #E8F0F8 100%);
  border-radius: 4px;
  border: 1px solid rgba(42,123,181,.15);
  margin-top: -3px;
}
.dt-light-head::before { /* inner LED panel */
  content: '';
  position: absolute; inset: 4px;
  background: linear-gradient(180deg, #FFFEF8 0%, #F8F8E8 100%);
  border-radius: 2px;
  box-shadow: 0 0 16px rgba(255,255,200,.6), 0 0 40px rgba(255,255,200,.3);
}
.dt-light-cone {
  width: 0; height: 0;
  border-left: 70px solid transparent;
  border-right: 70px solid transparent;
  border-top: 120px solid rgba(255,255,200,.08);
  filter: blur(8px);
}

/* ── INSTRUMENT TRAY ──────────────────────────────────────── */
.dt-tray {
  position: absolute;
  bottom: calc(22% + 4px);
  left: 14%;
  width: 140px; height: 28px;
  background: linear-gradient(180deg, #E8F0F8 0%, #D8E8F0 100%);
  border: 1px solid rgba(42,123,181,.2);
  border-radius: 4px;
  display: flex; align-items: center; justify-content: space-around;
  padding: 0 10px;
}
.dt-instrument {
  height: 18px; width: 3px;
  background: linear-gradient(180deg, #B8C8D8 0%, #8A9AAA 100%);
  border-radius: 1.5px;
  position: relative;
}
.dt-instrument::before {
  content: '';
  position: absolute; bottom: 0; left: 50%; transform: translateX(-50%);
  width: 8px; height: 5px;
  background: inherit;
  border-radius: 0 0 2px 2px;
}

/* ── XRAY LIGHTBOX ────────────────────────────────────────── */
.dt-xray-box {
  position: absolute;
  top: 22%; left: 6%;
  width: 110px; height: 90px;
  background: linear-gradient(180deg, #D8E8F0 0%, #C8D8E8 100%);
  border: 1px solid rgba(42,123,181,.25);
  border-radius: 2px;
  overflow: hidden;
}
.dt-xray-box::before { /* backlight glow */
  content: '';
  position: absolute; inset: 0;
  background: radial-gradient(ellipse 70% 70% at 50% 40%, rgba(255,255,255,.5) 0%, transparent 70%);
}
.dt-xray-teeth {
  position: absolute;
  bottom: 10px; left: 50%; transform: translateX(-50%);
  display: flex; gap: 2px;
}
.dt-xray-tooth {
  background: rgba(255,255,255,.7);
  border-radius: 1px 1px 2px 2px;
}
.dt-xray-box__label {
  position: absolute; top: 6px; left: 0; right: 0;
  font-size: .46rem; letter-spacing: .14em;
  color: rgba(42,123,181,.7); text-align: center; text-transform: uppercase;
}

/* ── PARTICLE DOTS ────────────────────────────────────────── */
.dt-particle {
  position: absolute;
  border-radius: 50%;
  background: var(--dt-blue);
  pointer-events: none;
}

/* ── HERO TEXT ────────────────────────────────────────────── */
.dt-hero__content {
  position: relative; z-index: 10;
  padding: 0 7% 80px; max-width: 620px;
}
.dt-hero__eyebrow {
  display: flex; align-items: center; gap: 14px; margin-bottom: 20px;
}
.dt-hero__badge {
  background: var(--dt-blue);
  color: var(--dt-white);
  font-size: .62rem; letter-spacing: .18em;
  text-transform: uppercase;
  padding: 5px 14px; border-radius: 2px;
}
.dt-hero__rating {
  font-size: .78rem; color: var(--dt-sky); font-weight: 300;
}
.dt-hero__title {
  font-family: var(--dt-serif);
  font-size: clamp(2.4rem, 4.8vw, 4.2rem);
  font-weight: 600; line-height: 1.15;
  color: var(--dt-white); margin-bottom: 20px;
}
.dt-hero__title em { font-style: italic; color: var(--dt-sky); }
.dt-hero__tagline {
  font-size: 1rem; font-weight: 300; line-height: 1.75;
  color: var(--dt-mist); margin-bottom: 38px; max-width: 460px;
}
.dt-hero__actions { display: flex; gap: 14px; flex-wrap: wrap; }
.dt-btn {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 13px 32px; border-radius: var(--dt-r);
  font-family: var(--dt-sans); font-size: .82rem;
  font-weight: 500; letter-spacing: .06em;
  text-decoration: none; cursor: pointer; border: none;
  transition: all var(--dt-dur);
}
.dt-btn--blue { background: var(--dt-blue); color: var(--dt-white); }
.dt-btn--blue:hover { background: var(--dt-blue-deep); }
.dt-btn--outline {
  background: transparent; border: 1.5px solid rgba(212,232,244,.4);
  color: var(--dt-sky);
}
.dt-btn--outline:hover { border-color: var(--dt-sky); color: var(--dt-white); }
.dt-btn--white { background: var(--dt-white); color: var(--dt-navy); }
.dt-btn--white:hover { background: var(--dt-frost); }

/* Booking card */
.dt-book-card {
  position: absolute; bottom: 48px; right: 5%; z-index: 10;
  width: 220px;
  background: rgba(255,255,255,.97);
  border-radius: var(--dt-r);
  box-shadow: 0 8px 40px rgba(14,42,64,.3);
  padding: 22px 24px;
}
.dt-book-card__badge {
  display: inline-block;
  background: #E8F6EC; color: #2A8A4A;
  font-size: .6rem; letter-spacing: .16em; text-transform: uppercase;
  padding: 3px 10px; border-radius: 2px; margin-bottom: 14px;
}
.dt-book-card__title {
  font-family: var(--dt-serif); font-size: 1rem; font-weight: 600;
  color: var(--dt-navy); margin-bottom: 4px;
}
.dt-book-card__sub {
  font-size: .78rem; color: var(--dt-slate); margin-bottom: 14px;
}
.dt-book-card__row {
  display: flex; justify-content: space-between; margin-bottom: 6px;
  font-size: .78rem;
}
.dt-book-card__day { color: var(--dt-slate); font-weight: 300; }
.dt-book-card__time { color: var(--dt-charcoal); font-weight: 500; }
.dt-book-card__sep { height: 1px; background: rgba(42,123,181,.1); margin: 12px 0; }
.dt-book-card__cta {
  display: block; text-align: center; padding: 10px;
  background: var(--dt-blue); color: var(--dt-white);
  border-radius: var(--dt-r); font-size: .78rem; font-weight: 500;
  text-decoration: none; transition: background .3s;
}
.dt-book-card__cta:hover { background: var(--dt-blue-deep); }

/* ── TRUST BAR ────────────────────────────────────────────── */
.dt-trust {
  background: var(--dt-blue); padding: 0;
  display: grid; grid-template-columns: repeat(4,1fr);
}
.dt-trust-item {
  padding: 28px 20px; text-align: center;
  border-right: 1px solid rgba(255,255,255,.12);
}
.dt-trust-item:last-child { border-right: none; }
.dt-trust-item__val {
  font-family: var(--dt-serif); font-size: 2.2rem; font-weight: 600;
  color: var(--dt-white); line-height: 1; margin-bottom: 4px;
}
.dt-trust-item__lbl {
  font-size: .66rem; letter-spacing: .16em;
  color: rgba(255,255,255,.65); text-transform: uppercase;
}

/* ── SECTION UTILS ────────────────────────────────────────── */
.dt-section { padding: 96px 7%; }
.dt-section--snow  { background: var(--dt-snow); }
.dt-section--frost { background: var(--dt-frost); }
.dt-section--blue  { background: var(--dt-blue); color: var(--dt-white); }
.dt-section--navy  { background: var(--dt-navy); color: var(--dt-white); }
.dt-section--white { background: var(--dt-white); }

.dt-section-label { display: flex; align-items: center; gap: 12px; margin-bottom: 14px; }
.dt-section-label__dot {
  width: 8px; height: 8px; border-radius: 50%;
  background: var(--dt-blue);
}
.dt-section-label__text {
  font-size: .68rem; letter-spacing: .22em;
  color: var(--dt-blue); text-transform: uppercase; font-weight: 500;
}
.dt-section--navy .dt-section-label__text,
.dt-section--blue .dt-section-label__text { color: var(--dt-sky); }
.dt-section--navy .dt-section-label__dot,
.dt-section--blue .dt-section-label__dot { background: var(--dt-sky); }

.dt-h2 {
  font-family: var(--dt-serif); font-size: clamp(1.9rem, 3.2vw, 2.8rem);
  font-weight: 600; line-height: 1.2; margin-bottom: 16px;
}
.dt-h2 em { font-style: italic; }
.dt-lead {
  font-size: .98rem; font-weight: 300; line-height: 1.75;
  color: var(--dt-slate); max-width: 540px;
}
.dt-section--navy .dt-lead,
.dt-section--blue .dt-lead { color: rgba(212,232,244,.8); }

/* ── TREATMENTS GRID ──────────────────────────────────────── */
.dt-treatments__grid {
  display: grid; grid-template-columns: repeat(3,1fr);
  gap: 2px; margin-top: 48px;
}
.dt-treatment-card {
  background: var(--dt-white); padding: 40px 32px;
  border: 1px solid rgba(42,123,181,.08);
  position: relative; overflow: hidden;
  transition: border-color .3s, box-shadow .3s;
}
.dt-treatment-card:hover {
  border-color: rgba(42,123,181,.25);
  box-shadow: 0 4px 24px rgba(42,123,181,.08);
}
.dt-treatment-card::before {
  content: '';
  position: absolute; top: 0; left: 0; right: 0; height: 3px;
  background: var(--dt-blue);
  transform: scaleX(0); transform-origin: left;
  transition: transform .45s var(--dt-ease);
}
.dt-treatment-card:hover::before { transform: scaleX(1); }
.dt-treatment-card__icon {
  width: 44px; height: 44px; border-radius: 8px;
  background: var(--dt-blue-pale);
  display: flex; align-items: center; justify-content: center;
  font-size: 1.1rem; color: var(--dt-blue);
  margin-bottom: 20px;
}
.dt-treatment-card__name {
  font-family: var(--dt-serif); font-size: 1.2rem; font-weight: 600;
  color: var(--dt-navy); margin-bottom: 10px;
}
.dt-treatment-card__desc {
  font-size: .88rem; line-height: 1.7; color: var(--dt-slate); margin-bottom: 18px;
}
.dt-treatment-card__price {
  font-size: .82rem; font-weight: 500;
  color: var(--dt-blue); letter-spacing: .04em;
}

/* ── ABOUT SPLIT ──────────────────────────────────────────── */
.dt-about {
  display: grid; grid-template-columns: 1fr 1fr; min-height: 580px;
}
.dt-about__visual {
  background: var(--dt-navy); position: relative; overflow: hidden; min-height: 520px;
}
.dt-about__text {
  padding: 80px 60px; background: var(--dt-white);
  display: flex; flex-direction: column; justify-content: center;
}

/* CSS digital smile design screen */
.dt-dsd-scene {
  position: absolute; inset: 0;
  display: flex; align-items: center; justify-content: center;
}
.dt-monitor {
  width: 320px; height: 220px;
  background: linear-gradient(180deg, #1A2A3A 0%, #0E1E2E 100%);
  border: 1px solid rgba(42,123,181,.3);
  border-radius: 6px;
  position: relative;
}
.dt-monitor::before { /* screen bezel */
  content: '';
  position: absolute; inset: 8px;
  background: #0A1820;
  border-radius: 3px;
}
.dt-monitor__screen {
  position: absolute; inset: 8px; border-radius: 3px;
  overflow: hidden;
  background: linear-gradient(180deg, #061018 0%, #0A1822 100%);
}
/* CSS smile on the screen */
.dt-screen-smile {
  position: absolute; inset: 0;
  display: flex; align-items: center; justify-content: center;
}
.dt-smile-arc {
  width: 180px; height: 60px;
  border: 2px solid rgba(42,123,181,.5);
  border-bottom: 2px solid rgba(42,123,181,.5);
  border-top: none;
  border-radius: 0 0 90px 90px;
  position: relative;
}
.dt-smile-arc::before { /* teeth row */
  content: '';
  position: absolute; top: 0; left: 10px; right: 10px; height: 28px;
  background: repeating-linear-gradient(
    90deg,
    rgba(255,255,255,.85) 0, rgba(255,255,255,.85) 14px,
    rgba(42,123,181,.2) 14px, rgba(42,123,181,.2) 16px
  );
  border-radius: 0;
}
.dt-smile-arc::after { /* gum line */
  content: '';
  position: absolute; top: -6px; left: 0; right: 0; height: 8px;
  background: rgba(200,80,80,.3);
  border-radius: 4px 4px 0 0;
}
/* Grid overlay on screen */
.dt-screen-grid {
  position: absolute; inset: 0;
  background:
    repeating-linear-gradient(90deg, transparent 0, transparent 29px, rgba(42,123,181,.08) 29px, rgba(42,123,181,.08) 30px),
    repeating-linear-gradient(180deg, transparent 0, transparent 29px, rgba(42,123,181,.08) 29px, rgba(42,123,181,.08) 30px);
}
.dt-screen-label {
  position: absolute; top: 10px; left: 12px;
  font-size: .5rem; letter-spacing: .18em; color: rgba(42,123,181,.7);
  text-transform: uppercase;
}
.dt-monitor-stand {
  position: absolute; bottom: -28px; left: 50%; transform: translateX(-50%);
  width: 4px; height: 24px;
  background: linear-gradient(180deg, #4A6070 0%, #3A5060 100%);
}
.dt-monitor-base {
  position: absolute; bottom: -36px; left: 50%; transform: translateX(-50%);
  width: 60px; height: 8px;
  background: linear-gradient(180deg, #4A6070 0%, #3A5060 100%);
  border-radius: 4px;
}

/* Accreditation badges */
.dt-about__accreds {
  display: flex; flex-wrap: wrap; gap: 10px; margin-top: 28px;
}
.dt-accred-badge {
  padding: 6px 14px;
  background: var(--dt-blue-pale);
  border: 1px solid rgba(42,123,181,.2);
  border-radius: var(--dt-r);
  font-size: .68rem; font-weight: 500;
  color: var(--dt-blue); letter-spacing: .06em;
}

.dt-about__points {
  list-style: none; margin-top: 24px;
  display: flex; flex-direction: column; gap: 12px;
}
.dt-about__point {
  display: flex; gap: 12px; align-items: flex-start;
}
.dt-about__point-tick {
  width: 20px; height: 20px; flex-shrink: 0; margin-top: 1px;
  background: var(--dt-blue); border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  color: var(--dt-white); font-size: .65rem;
}
.dt-about__point-text { font-size: .9rem; line-height: 1.6; color: var(--dt-slate); }

/* ── TEAM GRID ────────────────────────────────────────────── */
.dt-team__grid {
  display: grid; grid-template-columns: repeat(4,1fr);
  gap: 24px; margin-top: 52px;
}
.dt-team-card {
  background: var(--dt-white);
  border: 1px solid rgba(42,123,181,.08);
  border-radius: var(--dt-r);
  overflow: hidden;
  transition: box-shadow .35s;
}
.dt-team-card:hover { box-shadow: 0 8px 32px rgba(42,123,181,.1); }
.dt-team-card__avatar {
  height: 180px; position: relative; overflow: hidden;
  background: var(--dt-frost);
}

/* CSS clinical portrait scenes */
.dt-portrait-scene {
  position: absolute; inset: 0;
  display: flex; align-items: flex-end; justify-content: center;
}
.dt-portrait-bg--1 { background: linear-gradient(180deg, #EEF4F8 0%, #D8ECF8 100%); }
.dt-portrait-bg--2 { background: linear-gradient(180deg, #E8F4EE 0%, #D0ECD8 100%); }
.dt-portrait-bg--3 { background: linear-gradient(180deg, #F0EEF8 0%, #DCD8F0 100%); }
.dt-portrait-bg--4 { background: linear-gradient(180deg, #F8F4E8 0%, #F0E8D0 100%); }

/* Shared clinical figure */
.dt-doc-fig {
  display: flex; flex-direction: column; align-items: center;
  position: relative;
}
.dt-doc-fig__head {
  width: 48px; height: 48px; border-radius: 50%;
  position: relative; margin-bottom: -2px;
}
.dt-doc-fig__neck {
  width: 18px; height: 14px;
}
.dt-doc-fig__body {
  width: 90px; height: 80px;
  border-radius: 4px 4px 0 0;
  position: relative;
}
/* White coat */
.dt-doc-fig__body::before {
  content: '';
  position: absolute; top: 0; left: 4px; right: 4px; bottom: 0;
  background: linear-gradient(180deg, #FAFAF8 0%, #F0EEE8 100%);
  border-radius: 3px 3px 0 0;
  clip-path: polygon(0 0, 44% 0, 44% 30%, 50% 35%, 56% 30%, 56% 0, 100% 0, 100% 100%, 0 100%);
}
/* Stethoscope */
.dt-doc-fig__steth {
  position: absolute;
  top: 10px; left: 50%; transform: translateX(-50%);
  width: 32px; height: 20px;
  border: 2px solid #4A6070;
  border-top: none;
  border-radius: 0 0 12px 12px;
}
.dt-doc-fig__steth::before {
  content: '';
  position: absolute; bottom: -5px; left: 50%; transform: translateX(-50%);
  width: 8px; height: 8px; border-radius: 50%;
  background: #3A5060;
}

/* Doctor colour variants */
.dt-doc-fig--1 .dt-doc-fig__head {
  background: radial-gradient(circle at 38% 35%, #D4B090 0%, #A88060 50%, #7A5840 100%);
}
.dt-doc-fig--1 .dt-doc-fig__neck { background: #A88060; }
.dt-doc-fig--1 .dt-doc-fig__body { background: linear-gradient(180deg, #3A5A8A 0%, #2A4A7A 100%); }
.dt-doc-fig--1 .dt-doc-fig__head::before { /* dark bob hair */
  content: '';
  position: absolute; top: -5px; left: -3px; right: -3px; height: 26px;
  background: #1A0E08;
  border-radius: 24px 24px 0 0;
  clip-path: polygon(0 70%, 0 20%, 50% 0%, 100% 20%, 100% 70%, 92% 100%, 8% 100%);
}

.dt-doc-fig--2 .dt-doc-fig__head {
  background: radial-gradient(circle at 38% 35%, #D4B898 0%, #B09070 50%, #806040 100%);
}
.dt-doc-fig--2 .dt-doc-fig__neck { background: #B09070; }
.dt-doc-fig--2 .dt-doc-fig__body { background: linear-gradient(180deg, #3A8A5A 0%, #2A6A4A 100%); }
.dt-doc-fig--2 .dt-doc-fig__head::before { /* short dark hair */
  content: '';
  position: absolute; top: -3px; left: 0; right: 0; height: 20px;
  background: #1A1008;
  border-radius: 22px 22px 0 0;
  clip-path: polygon(5% 60%, 0 10%, 50% 0%, 100% 10%, 95% 60%, 100% 100%, 0 100%);
}

.dt-doc-fig--3 .dt-doc-fig__head {
  background: radial-gradient(circle at 38% 35%, #EAD0B0 0%, #C8A880 50%, #A08060 100%);
}
.dt-doc-fig--3 .dt-doc-fig__neck { background: #C8A880; }
.dt-doc-fig--3 .dt-doc-fig__body { background: linear-gradient(180deg, #5A4A8A 0%, #4A3A7A 100%); }
.dt-doc-fig--3 .dt-doc-fig__head::before { /* afro hair */
  content: '';
  position: absolute; top: -10px; left: -6px; right: -6px; height: 32px;
  background: #0A0806;
  border-radius: 50%;
  clip-path: ellipse(55% 65% at 50% 50%);
}

.dt-doc-fig--4 .dt-doc-fig__head {
  background: radial-gradient(circle at 38% 35%, #F0D8C0 0%, #D4B898 50%, #A88070 100%);
}
.dt-doc-fig--4 .dt-doc-fig__neck { background: #D4B898; }
.dt-doc-fig--4 .dt-doc-fig__body { background: linear-gradient(180deg, #2A5A8A 0%, #1A4A7A 100%); }
.dt-doc-fig--4 .dt-doc-fig__head::before { /* blonde updo */
  content: '';
  position: absolute; top: -6px; left: -1px; right: -1px; height: 26px;
  background: #D4A830;
  border-radius: 22px 22px 0 0;
  clip-path: polygon(5% 70%, 5% 15%, 50% 0%, 95% 15%, 95% 70%, 85% 100%, 15% 100%);
}

.dt-team-card__info { padding: 18px 20px 22px; }
.dt-team-card__name {
  font-family: var(--dt-serif); font-size: 1rem; font-weight: 600;
  color: var(--dt-navy); margin-bottom: 3px;
}
.dt-team-card__role {
  font-size: .68rem; font-weight: 500; letter-spacing: .1em;
  color: var(--dt-blue); text-transform: uppercase; margin-bottom: 8px;
}
.dt-team-card__spec {
  font-size: .78rem; line-height: 1.55; color: var(--dt-slate);
}

/* ── SMILE TRANSFORM COMPARISON ───────────────────────────── */
.dt-transform__grid {
  display: grid; grid-template-columns: repeat(3,1fr);
  gap: 24px; margin-top: 52px;
}
.dt-transform-card {
  border-radius: var(--dt-r); overflow: hidden;
  box-shadow: 0 4px 20px rgba(14,42,64,.08);
}
.dt-transform-card__before,
.dt-transform-card__after {
  height: 120px; position: relative;
  display: flex; align-items: center; justify-content: center;
}
.dt-transform-card__before {
  background: linear-gradient(180deg, #E8DDD0 0%, #D8CCC0 100%);
}
.dt-transform-card__after {
  background: linear-gradient(180deg, #E8F4EA 0%, #D8EEE0 100%);
}
/* CSS before teeth */
.dt-teeth-before {
  display: flex; gap: 2px; align-items: flex-end;
}
.dt-tooth-b {
  background: linear-gradient(180deg, #D8CCA0 0%, #C0B488 100%);
  border-radius: 2px 2px 3px 3px;
  border: 1px solid rgba(0,0,0,.08);
}
/* CSS after teeth */
.dt-teeth-after {
  display: flex; gap: 2px; align-items: flex-end;
}
.dt-tooth-a {
  background: linear-gradient(180deg, #FFFFFF 0%, #F4F8FC 100%);
  border-radius: 2px 2px 3px 3px;
  border: 1px solid rgba(42,123,181,.12);
  box-shadow: 0 1px 4px rgba(255,255,255,.8);
}
.dt-transform-label {
  position: absolute; top: 8px; left: 10px;
  font-size: .58rem; letter-spacing: .14em; font-weight: 600;
  text-transform: uppercase;
}
.dt-transform-card__before .dt-transform-label { color: rgba(0,0,0,.4); }
.dt-transform-card__after  .dt-transform-label { color: var(--dt-blue); }
.dt-transform-card__divider {
  height: 2px;
  background: linear-gradient(90deg, var(--dt-blue), var(--dt-gold));
}
.dt-transform-card__info { padding: 14px 16px; background: var(--dt-white); }
.dt-transform-card__treatment {
  font-family: var(--dt-serif); font-size: .95rem; font-weight: 600;
  color: var(--dt-navy); margin-bottom: 3px;
}
.dt-transform-card__detail { font-size: .78rem; color: var(--dt-slate); }

/* ── PACKAGES ─────────────────────────────────────────────── */
.dt-packages__grid {
  display: grid; grid-template-columns: repeat(3,1fr);
  gap: 16px; margin-top: 52px;
}
.dt-package {
  background: var(--dt-white);
  border: 1.5px solid rgba(42,123,181,.12);
  border-radius: var(--dt-r);
  padding: 40px 32px;
  position: relative; transition: box-shadow .35s, border-color .35s;
}
.dt-package:hover { border-color: rgba(42,123,181,.3); box-shadow: 0 8px 32px rgba(42,123,181,.1); }
.dt-package--featured {
  background: var(--dt-blue);
  border-color: var(--dt-blue);
  color: var(--dt-white);
}
.dt-package--featured:hover { box-shadow: 0 12px 40px rgba(42,123,181,.4); }
.dt-package__badge {
  position: absolute; top: -1px; right: 24px;
  background: var(--dt-gold); color: var(--dt-navy);
  font-size: .58rem; letter-spacing: .16em; text-transform: uppercase;
  padding: 4px 12px; border-radius: 0 0 4px 4px; font-weight: 600;
}
.dt-package__tier {
  font-size: .65rem; letter-spacing: .22em; font-weight: 600;
  color: var(--dt-blue); text-transform: uppercase; margin-bottom: 10px;
}
.dt-package--featured .dt-package__tier { color: rgba(212,232,244,.8); }
.dt-package__name {
  font-family: var(--dt-serif); font-size: 1.6rem; font-weight: 600;
  color: var(--dt-navy); margin-bottom: 8px;
}
.dt-package--featured .dt-package__name { color: var(--dt-white); }
.dt-package__price {
  font-family: var(--dt-serif); font-size: 2.4rem; font-weight: 600;
  color: var(--dt-navy); line-height: 1; margin-bottom: 4px;
}
.dt-package--featured .dt-package__price { color: var(--dt-white); }
.dt-package__per {
  font-size: .76rem; color: var(--dt-slate); margin-bottom: 24px;
}
.dt-package--featured .dt-package__per { color: rgba(212,232,244,.7); }
.dt-package__sep {
  height: 1px; background: rgba(42,123,181,.1); margin-bottom: 22px;
}
.dt-package--featured .dt-package__sep { background: rgba(255,255,255,.15); }
.dt-package__features {
  list-style: none; display: flex; flex-direction: column;
  gap: 9px; margin-bottom: 28px;
}
.dt-package__feature {
  display: flex; gap: 10px; align-items: flex-start;
  font-size: .86rem; line-height: 1.5;
  color: var(--dt-slate);
}
.dt-package--featured .dt-package__feature { color: rgba(212,232,244,.9); }
.dt-package__feature::before {
  content: '✓'; flex-shrink: 0; margin-top: 1px;
  font-weight: 600; font-size: .75rem;
  color: var(--dt-blue);
}
.dt-package--featured .dt-package__feature::before { color: var(--dt-gold-pale); }

/* ── PROCESS ──────────────────────────────────────────────── */
.dt-process__steps {
  display: grid; grid-template-columns: repeat(4,1fr);
  gap: 0; margin-top: 52px; position: relative;
}
.dt-process__steps::before {
  content: '';
  position: absolute; top: 20px; left: 12.5%; right: 12.5%;
  height: 1px; background: rgba(42,123,181,.2);
}
.dt-process-step { text-align: center; padding: 0 24px; }
.dt-process-step__num {
  width: 40px; height: 40px; border-radius: 50%;
  background: var(--dt-blue); color: var(--dt-white);
  font-size: .82rem; font-weight: 600;
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto 20px;
  position: relative; z-index: 1;
}
.dt-process-step__title {
  font-family: var(--dt-serif); font-size: 1.05rem; font-weight: 600;
  color: var(--dt-navy); margin-bottom: 8px;
}
.dt-section--navy .dt-process-step__title { color: var(--dt-sky); }
.dt-process-step__text { font-size: .84rem; line-height: 1.65; color: var(--dt-slate); }
.dt-section--navy .dt-process-step__text { color: rgba(212,232,244,.7); }
.dt-section--navy .dt-process-step__num { background: rgba(255,255,255,.12); border: 1px solid rgba(212,232,244,.3); }

/* ── TESTIMONIALS ─────────────────────────────────────────── */
.dt-testimonials__grid {
  display: grid; grid-template-columns: repeat(3,1fr);
  gap: 20px; margin-top: 52px;
}
.dt-testimonial {
  background: var(--dt-white);
  border-radius: var(--dt-r);
  padding: 32px 28px;
  border: 1px solid rgba(42,123,181,.08);
  box-shadow: 0 2px 12px rgba(14,42,64,.04);
}
.dt-testimonial__stars { color: var(--dt-gold); font-size: .9rem; letter-spacing: 2px; margin-bottom: 14px; }
.dt-testimonial__text {
  font-family: var(--dt-serif); font-style: italic;
  font-size: .98rem; line-height: 1.7; color: var(--dt-charcoal); margin-bottom: 18px;
}
.dt-testimonial__author { font-size: .78rem; color: var(--dt-slate); }
.dt-testimonial__author strong {
  display: block; font-style: normal;
  font-family: var(--dt-sans); font-weight: 600;
  color: var(--dt-navy); margin-bottom: 2px;
}

/* ── BOOKING FORM ─────────────────────────────────────────── */
.dt-booking {
  display: grid; grid-template-columns: 1fr 1.2fr; min-height: 580px;
}
.dt-booking__info {
  background: var(--dt-blue); padding: 80px 7%;
  display: flex; flex-direction: column; justify-content: center;
}
.dt-booking__form-wrap {
  background: var(--dt-white); padding: 80px 7%;
  display: flex; flex-direction: column; justify-content: center;
}
.dt-booking__highlight {
  margin-top: 28px; padding: 20px 24px;
  background: rgba(255,255,255,.12); border-radius: var(--dt-r);
}
.dt-booking__highlight-title {
  font-size: .68rem; letter-spacing: .18em; font-weight: 600;
  color: var(--dt-sky); text-transform: uppercase; margin-bottom: 10px;
}
.dt-booking__highlight-items {
  list-style: none; display: flex; flex-direction: column; gap: 6px;
}
.dt-booking__highlight-items li {
  font-size: .86rem; color: rgba(212,232,244,.85);
  display: flex; gap: 8px; align-items: center;
}
.dt-booking__highlight-items li::before {
  content: '✓'; color: var(--dt-gold-pale); font-weight: 600;
}
.dt-form { display: flex; flex-direction: column; gap: 16px; }
.dt-field-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.dt-field { display: flex; flex-direction: column; gap: 5px; }
.dt-field label {
  font-size: .68rem; font-weight: 500; letter-spacing: .1em;
  color: var(--dt-slate); text-transform: uppercase;
}
.dt-field input,
.dt-field select,
.dt-field textarea {
  background: var(--dt-frost);
  border: 1.5px solid rgba(42,123,181,.15);
  border-radius: var(--dt-r);
  padding: 10px 14px;
  font-family: var(--dt-sans); font-size: .9rem;
  color: var(--dt-charcoal); outline: none;
  transition: border-color .3s; width: 100%;
}
.dt-field input:focus,
.dt-field select:focus,
.dt-field textarea:focus {
  border-color: var(--dt-blue);
  background: var(--dt-white);
}
.dt-field textarea { resize: vertical; min-height: 80px; }
.dt-field select { cursor: pointer; appearance: none; }
.dt-form .dt-btn { align-self: flex-start; margin-top: 4px; }

/* ── FOOTER ───────────────────────────────────────────────── */
.dt-footer {
  background: var(--dt-navy); padding: 64px 7% 32px;
  border-top: 1px solid rgba(42,123,181,.1);
}
.dt-footer__top {
  display: grid; grid-template-columns: 1.4fr 1fr 1fr 1fr;
  gap: 48px; padding-bottom: 48px;
  border-bottom: 1px solid rgba(42,123,181,.08);
}
.dt-footer__name {
  font-family: var(--dt-serif); font-size: 1.25rem; font-weight: 600;
  color: var(--dt-white); margin-bottom: 4px;
}
.dt-footer__tagline {
  font-size: .62rem; letter-spacing: .24em;
  color: var(--dt-blue); text-transform: uppercase;
  margin-bottom: 16px; font-weight: 500;
}
.dt-footer__text { font-size: .84rem; line-height: 1.65; color: var(--dt-mist); }
.dt-footer__col-title {
  font-size: .65rem; letter-spacing: .22em; font-weight: 600;
  color: var(--dt-blue); text-transform: uppercase; margin-bottom: 16px;
}
.dt-footer__links { list-style: none; display: flex; flex-direction: column; gap: 8px; }
.dt-footer__links a {
  font-size: .84rem; color: var(--dt-mist); text-decoration: none; transition: color .3s;
}
.dt-footer__links a:hover { color: var(--dt-white); }
.dt-footer__bottom {
  display: flex; justify-content: space-between; align-items: center;
  padding-top: 28px; font-size: .74rem; color: var(--dt-mist);
  flex-wrap: wrap; gap: 12px;
}
.dt-footer__bottom-links { display: flex; gap: 24px; }
.dt-footer__bottom-links a { color: var(--dt-mist); text-decoration: none; transition: color .3s; }
.dt-footer__bottom-links a:hover { color: var(--dt-blue); }

/* ── ANIMATIONS ───────────────────────────────────────────── */
@keyframes dt-particle-float {
  0%, 100% { opacity: 0; transform: translateY(0); }
  20%, 80%  { opacity: var(--dt-op, .08); }
  50%       { transform: translateY(-12px); }
}
@keyframes dt-light-pulse {
  0%, 100% { opacity: .7; }
  50%       { opacity: 1; }
}
.dt-overhead-light .dt-light-head { animation: dt-light-pulse 3s ease-in-out infinite; }

/* ── RESPONSIVE ───────────────────────────────────────────── */
@media (max-width: 1100px) {
  .dt-treatments__grid { grid-template-columns: repeat(2,1fr); }
  .dt-team__grid { grid-template-columns: repeat(2,1fr); }
  .dt-packages__grid { grid-template-columns: 1fr; }
  .dt-transform__grid { grid-template-columns: repeat(2,1fr); }
  .dt-process__steps { grid-template-columns: repeat(2,1fr); gap: 40px; }
  .dt-footer__top { grid-template-columns: 1fr 1fr; }
}
@media (max-width: 768px) {
  .dt-nav { padding: 0 24px; }
  .dt-nav__links { display: none; }
  .dt-hero__content { padding: 0 24px 80px; }
  .dt-book-card { display: none; }
  .dt-about { grid-template-columns: 1fr; }
  .dt-booking { grid-template-columns: 1fr; }
  .dt-testimonials__grid { grid-template-columns: 1fr; }
  .dt-treatments__grid { grid-template-columns: 1fr; }
  .dt-transform__grid { grid-template-columns: 1fr; }
  .dt-team__grid { grid-template-columns: 1fr 1fr; }
  .dt-process__steps { grid-template-columns: 1fr; }
  .dt-field-row { grid-template-columns: 1fr; }
  .dt-section { padding: 64px 24px; }
  .dt-footer__top { grid-template-columns: 1fr; }
}
</style>
<?php get_header(); ?>
<div class="dt-body">
">

<!-- NAV -->
<nav class="dt-nav" role="navigation" aria-label="Main navigation">
  <div class="dt-nav__logo">
    <div class="dt-nav__icon" aria-hidden="true">✦</div>
    <div class="dt-nav__wordmark">
      <span class="dt-nav__name">Clarity Dental</span>
      <span class="dt-nav__tagline">Cosmetic &amp; Restorative Dentistry · Chelsea</span>
    </div>
  </div>
  <ul class="dt-nav__links">
    <li><a href="#treatments">Treatments</a></li>
    <li><a href="#about">About</a></li>
    <li><a href="#team">Our Team</a></li>
    <li><a href="#packages">Packages</a></li>
    <li><a href="#booking">Book</a></li>
  </ul>
  <a href="#booking" class="dt-nav__cta">Book Consultation</a>
</nav>

<!-- HERO -->
<section class="dt-hero" aria-label="Hero — Cosmetic Dental Practice">

  <div class="dt-ceiling" aria-hidden="true"></div>
  <div class="dt-wall" aria-hidden="true"></div>
  <div class="dt-dado" aria-hidden="true"></div>
  <div class="dt-floor" aria-hidden="true"></div>

  <!-- PHP particle dots -->
  <?php foreach ($dt_particles as $p) : ?>
  <div class="dt-particle" aria-hidden="true" style="
    top: <?php echo $p['top']; ?>%;
    left: <?php echo $p['left']; ?>%;
    width: <?php echo $p['size']; ?>px;
    height: <?php echo $p['size']; ?>px;
    --dt-op: <?php echo $p['opacity']; ?>;
    animation: dt-particle-float <?php echo $p['dur']; ?>ms ease-in-out <?php echo $p['delay']; ?>ms infinite;
    opacity: 0;
  "></div>
  <?php endforeach; ?>

  <!-- X-ray lightbox -->
  <div class="dt-xray-box" aria-hidden="true" role="img" aria-label="Dental X-ray">
    <div class="dt-xray-box__label">Periapical Radiograph</div>
    <div class="dt-xray-teeth">
      <?php
      $tooth_sizes = [[6,26],[7,28],[8,30],[9,32],[9,30],[8,28],[7,26],[6,24]];
      foreach ($tooth_sizes as $ts) {
          echo '<div class="dt-xray-tooth" style="width:'.$ts[0].'px; height:'.$ts[1].'px;"></div>';
      }
      ?>
    </div>
  </div>

  <!-- Overhead lamp -->
  <div class="dt-overhead-light" aria-hidden="true">
    <div class="dt-light-arm"></div>
    <div class="dt-light-arm-h"></div>
    <div class="dt-light-head"></div>
    <div class="dt-light-cone"></div>
  </div>

  <!-- Dental chair with patient -->
  <div class="dt-chair-wrap" aria-hidden="true" role="img" aria-label="Dental treatment chair">
    <div class="dt-chair-back" style="position:relative;">
      <div class="dt-patient">
        <div class="dt-patient__head"></div>
        <div class="dt-patient__body"></div>
      </div>
      <div class="dt-chair-arm dt-chair-arm--l"></div>
      <div class="dt-chair-arm dt-chair-arm--r"></div>
    </div>
    <div class="dt-chair-seat"></div>
    <div class="dt-chair-pedestal"></div>
    <div class="dt-chair-base"></div>
  </div>

  <!-- Instrument tray -->
  <div class="dt-tray" aria-hidden="true" role="img" aria-label="Dental instrument tray">
    <?php for ($i = 0; $i < 7; $i++) : ?>
    <div class="dt-instrument" style="height: <?php echo 14 + rand(0,8); ?>px;"></div>
    <?php endfor; ?>
  </div>

  <!-- Hero text -->
  <div class="dt-hero__content">
    <div class="dt-hero__eyebrow">
      <span class="dt-hero__badge">Chelsea, London</span>
      <span class="dt-hero__rating">★★★★★ &nbsp;4.9 / 5 — 840+ reviews</span>
    </div>
    <h1 class="dt-hero__title">
      Your perfect<br><em>smile</em> starts<br>here
    </h1>
    <p class="dt-hero__tagline">
      Award-winning cosmetic and restorative dentistry in Chelsea.
      From same-day whitening to full smile transformations — every treatment
      delivered with precision, artistry, and genuine care.
    </p>
    <div class="dt-hero__actions">
      <a href="#booking" class="dt-btn dt-btn--blue">Book Free Consultation</a>
      <a href="#treatments" class="dt-btn dt-btn--outline">View Treatments</a>
    </div>
  </div>

  <!-- Booking card -->
  <div class="dt-book-card" aria-label="Appointment availability">
    <div class="dt-book-card__badge">✓ Accepting New Patients</div>
    <div class="dt-book-card__title">Next Available</div>
    <div class="dt-book-card__sub">Free smile consultation</div>
    <div class="dt-book-card__row">
      <span class="dt-book-card__day">Mon – Fri</span>
      <span class="dt-book-card__time">8am – 7pm</span>
    </div>
    <div class="dt-book-card__row">
      <span class="dt-book-card__day">Saturday</span>
      <span class="dt-book-card__time">9am – 5pm</span>
    </div>
    <div class="dt-book-card__row">
      <span class="dt-book-card__day">Sunday</span>
      <span class="dt-book-card__time">Emergency only</span>
    </div>
    <div class="dt-book-card__sep"></div>
    <a href="#booking" class="dt-book-card__cta">Book Now — It's Free</a>
  </div>

</section>

<!-- TRUST BAR -->
<div class="dt-trust" aria-label="Practice achievements">
  <div class="dt-trust-item">
    <div class="dt-trust-item__val" data-target="18">18</div>
    <div class="dt-trust-item__lbl">Years in Chelsea</div>
  </div>
  <div class="dt-trust-item">
    <div class="dt-trust-item__val" data-target="9400">9,400+</div>
    <div class="dt-trust-item__lbl">Happy Patients</div>
  </div>
  <div class="dt-trust-item">
    <div class="dt-trust-item__val" data-target="4.9">4.9★</div>
    <div class="dt-trust-item__lbl">Average Rating</div>
  </div>
  <div class="dt-trust-item">
    <div class="dt-trust-item__val" data-target="100">100%</div>
    <div class="dt-trust-item__lbl">Recommend Us</div>
  </div>
</div>

<!-- TREATMENTS -->
<section id="treatments" class="dt-section dt-section--white" aria-labelledby="dt-treatments-heading">
  <div class="dt-section-label">
    <div class="dt-section-label__dot"></div>
    <span class="dt-section-label__text">What We Do</span>
  </div>
  <h2 id="dt-treatments-heading" class="dt-h2">
    Our <em>Treatments</em>
  </h2>
  <p class="dt-lead">
    From a simple polish to a complete smile transformation — every treatment is planned,
    priced and performed with complete transparency and a genuine commitment to your comfort.
  </p>

  <div class="dt-treatments__grid" role="list">
    <?php foreach ($dt_treatments as $t) : ?>
    <article class="dt-treatment-card" role="listitem">
      <div class="dt-treatment-card__icon" aria-hidden="true"><?php echo esc_html($t['icon']); ?></div>
      <h3 class="dt-treatment-card__name"><?php echo esc_html($t['name']); ?></h3>
      <p class="dt-treatment-card__desc"><?php echo esc_html($t['desc']); ?></p>
      <div class="dt-treatment-card__price"><?php echo esc_html($t['from']); ?></div>
    </article>
    <?php endforeach; ?>
  </div>
</section>

<!-- SMILE TRANSFORMATIONS -->
<section class="dt-section dt-section--frost" aria-labelledby="dt-transform-heading">
  <div class="dt-section-label">
    <div class="dt-section-label__dot"></div>
    <span class="dt-section-label__text">Results</span>
  </div>
  <h2 id="dt-transform-heading" class="dt-h2">
    Smile <em>Transformations</em>
  </h2>
  <p class="dt-lead">
    The proof is in the result. Our before-and-after cases illustrate what's possible
    with the right treatment plan and the right team.
  </p>

  <div class="dt-transform__grid" role="list">
    <?php
    $transforms = [
      ['treatment'=>'Composite Bonding', 'detail'=>'8 teeth · single visit · no anaesthetic'],
      ['treatment'=>'Porcelain Veneers', 'detail'=>'10 veneers · 2 visits · Emax porcelain'],
      ['treatment'=>'Invisalign + Whitening', 'detail'=>'12 months alignment · Zoom whitening finish'],
    ];
    $before_teeth = [[7,24],[8,26],[9,28],[10,30],[10,28],[9,26],[8,24],[7,22]];
    $after_teeth  = [[7,26],[8,28],[9,30],[10,32],[10,30],[9,28],[8,26],[7,24]];
    foreach ($transforms as $tr) : ?>
    <div class="dt-transform-card" role="listitem">
      <div class="dt-transform-card__before">
        <span class="dt-transform-label">Before</span>
        <div class="dt-teeth-before" aria-hidden="true">
          <?php foreach ($before_teeth as $bt) : ?>
          <div class="dt-tooth-b" style="width:<?php echo $bt[0]; ?>px; height:<?php echo rand((int)($bt[1]*.8),(int)$bt[1]); ?>px;"></div>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="dt-transform-card__divider"></div>
      <div class="dt-transform-card__after">
        <span class="dt-transform-label">After</span>
        <div class="dt-teeth-after" aria-hidden="true">
          <?php foreach ($after_teeth as $at) : ?>
          <div class="dt-tooth-a" style="width:<?php echo $at[0]; ?>px; height:<?php echo $at[1]; ?>px;"></div>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="dt-transform-card__info">
        <div class="dt-transform-card__treatment"><?php echo esc_html($tr['treatment']); ?></div>
        <div class="dt-transform-card__detail"><?php echo esc_html($tr['detail']); ?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- ABOUT -->
<section id="about" class="dt-about" aria-labelledby="dt-about-heading">
  <div class="dt-about__visual" aria-hidden="true">
    <div class="dt-dsd-scene">
      <div class="dt-monitor">
        <div class="dt-monitor__screen">
          <div class="dt-screen-grid"></div>
          <div class="dt-screen-label">Digital Smile Design — v2.4</div>
          <div class="dt-screen-smile">
            <div class="dt-smile-arc"></div>
          </div>
        </div>
        <div class="dt-monitor-stand"></div>
        <div class="dt-monitor-base"></div>
      </div>
    </div>
    <div style="position:absolute; bottom:24px; left:0; right:0; text-align:center; font-size:.62rem; letter-spacing:.2em; color:var(--dt-mist); text-transform:uppercase;">Digital Smile Design Technology</div>
  </div>
  <div class="dt-about__text">
    <div class="dt-section-label">
      <div class="dt-section-label__dot"></div>
      <span class="dt-section-label__text">The Practice</span>
    </div>
    <h2 id="dt-about-heading" class="dt-h2">
      Chelsea's most <em>trusted</em> dental team
    </h2>
    <p class="dt-lead">
      Clarity Dental has served the Chelsea community since 2007, building a reputation
      for clinical excellence, genuine patient care, and results that speak for themselves.
      We were among the first UK practices to adopt Digital Smile Design technology.
    </p>
    <ul class="dt-about__points">
      <li class="dt-about__point">
        <div class="dt-about__point-tick" aria-hidden="true">✓</div>
        <span class="dt-about__point-text">State-of-the-art 6-surgery practice with CBCT 3D scanning, iTero digital impressions and intra-oral cameras</span>
      </li>
      <li class="dt-about__point">
        <div class="dt-about__point-tick" aria-hidden="true">✓</div>
        <span class="dt-about__point-text">Invisalign Diamond-tier provider — top 1% globally. Fastest treatment timelines, best clinical outcomes</span>
      </li>
      <li class="dt-about__point">
        <div class="dt-about__point-tick" aria-hidden="true">✓</div>
        <span class="dt-about__point-text">Finance available at 0% APR for 12 months and flexible plans for longer-term treatment programmes</span>
      </li>
      <li class="dt-about__point">
        <div class="dt-about__point-tick" aria-hidden="true">✓</div>
        <span class="dt-about__point-text">Evening and Saturday appointments available. Same-day emergency slots reserved every day</span>
      </li>
    </ul>
    <div class="dt-about__accreds" aria-label="Professional accreditations">
      <span class="dt-accred-badge">GDC Registered</span>
      <span class="dt-accred-badge">CQC Compliant</span>
      <span class="dt-accred-badge">BDA Good Practice</span>
      <span class="dt-accred-badge">Invisalign Diamond</span>
      <span class="dt-accred-badge">ITI Member</span>
    </div>
  </div>
</section>

<!-- TEAM -->
<section id="team" class="dt-section dt-section--snow" aria-labelledby="dt-team-heading">
  <div class="dt-section-label">
    <div class="dt-section-label__dot"></div>
    <span class="dt-section-label__text">Our Dentists</span>
  </div>
  <h2 id="dt-team-heading" class="dt-h2">
    Meet the <em>Team</em>
  </h2>
  <p class="dt-lead">
    Four lead clinicians, each a specialist in their field — all united by the same
    commitment to patient-centred care and outstanding clinical results.
  </p>

  <div class="dt-team__grid" role="list">
    <?php foreach ($dt_team as $i => $member) : ?>
    <article class="dt-team-card" role="listitem">
      <div class="dt-team-card__avatar" aria-label="Portrait of <?php echo esc_attr($member['name']); ?>">
        <div class="dt-portrait-scene dt-portrait-bg--<?php echo $i+1; ?>" aria-hidden="true">
          <div class="dt-doc-fig dt-doc-fig--<?php echo $i+1; ?>">
            <div class="dt-doc-fig__head"></div>
            <div class="dt-doc-fig__neck"></div>
            <div class="dt-doc-fig__body">
              <div class="dt-doc-fig__steth"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="dt-team-card__info">
        <div class="dt-team-card__name"><?php echo esc_html($member['name']); ?></div>
        <div class="dt-team-card__role"><?php echo esc_html($member['role']); ?></div>
        <div class="dt-team-card__spec"><?php echo esc_html($member['spec']); ?></div>
      </div>
    </article>
    <?php endforeach; ?>
  </div>
</section>

<!-- PACKAGES -->
<section id="packages" class="dt-section dt-section--white" aria-labelledby="dt-packages-heading">
  <div class="dt-section-label">
    <div class="dt-section-label__dot"></div>
    <span class="dt-section-label__text">Investment</span>
  </div>
  <h2 id="dt-packages-heading" class="dt-h2">
    Smile <em>Packages</em>
  </h2>
  <p class="dt-lead">
    Three curated packages that combine our most popular treatments into a single, clear
    investment — with 0% finance available on all packages.
  </p>

  <div class="dt-packages__grid" role="list">
    <?php foreach ($dt_packages as $pkg) : ?>
    <article class="dt-package <?php echo $pkg['featured'] ? 'dt-package--featured' : ''; ?>" role="listitem">
      <?php if ($pkg['featured']) : ?>
      <div class="dt-package__badge">Most Popular</div>
      <?php endif; ?>
      <div class="dt-package__tier"><?php echo esc_html($pkg['tier']); ?></div>
      <div class="dt-package__name"><?php echo esc_html($pkg['name']); ?></div>
      <div class="dt-package__price"><?php echo esc_html($pkg['price']); ?></div>
      <div class="dt-package__per"><?php echo esc_html($pkg['per']); ?></div>
      <div class="dt-package__sep"></div>
      <ul class="dt-package__features">
        <?php foreach ($pkg['feat'] as $f) : ?>
        <li class="dt-package__feature"><?php echo esc_html($f); ?></li>
        <?php endforeach; ?>
      </ul>
      <a href="#booking" class="dt-btn <?php echo $pkg['featured'] ? 'dt-btn--white' : 'dt-btn--blue'; ?>">
        <?php echo $pkg['featured'] ? 'Book This Package' : 'Enquire Now'; ?>
      </a>
    </article>
    <?php endforeach; ?>
  </div>
</section>

<!-- PROCESS -->
<section class="dt-section dt-section--navy" aria-labelledby="dt-process-heading">
  <div class="dt-section-label">
    <div class="dt-section-label__dot"></div>
    <span class="dt-section-label__text">Your Journey</span>
  </div>
  <h2 id="dt-process-heading" class="dt-h2">
    How it <em>works</em>
  </h2>

  <div class="dt-process__steps" role="list">
    <?php foreach ($dt_steps as $step) : ?>
    <div class="dt-process-step" role="listitem">
      <div class="dt-process-step__num" aria-hidden="true"><?php echo esc_html($step['num']); ?></div>
      <h3 class="dt-process-step__title"><?php echo esc_html($step['title']); ?></h3>
      <p class="dt-process-step__text"><?php echo esc_html($step['text']); ?></p>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="dt-section dt-section--snow" aria-labelledby="dt-testimonials-heading">
  <div class="dt-section-label">
    <div class="dt-section-label__dot"></div>
    <span class="dt-section-label__text">Patient Stories</span>
  </div>
  <h2 id="dt-testimonials-heading" class="dt-h2">
    What our patients <em>say</em>
  </h2>
  <div class="dt-testimonials__grid" role="list">
    <blockquote class="dt-testimonial" role="listitem">
      <div class="dt-testimonial__stars" aria-label="5 stars">★★★★★</div>
      <p class="dt-testimonial__text">
        "I had my veneers done by Dr Laurent and I genuinely cannot stop smiling.
        The attention to detail, the care taken to match the shape and shade — it's a
        completely different smile and yet it looks entirely natural."
      </p>
      <footer class="dt-testimonial__author">
        <strong>Arabella M.</strong>Porcelain Veneers Patient
      </footer>
    </blockquote>
    <blockquote class="dt-testimonial" role="listitem">
      <div class="dt-testimonial__stars" aria-label="5 stars">★★★★★</div>
      <p class="dt-testimonial__text">
        "After years of being too self-conscious to smile in photos, Invisalign
        has completely changed my confidence. The team at Clarity made the whole
        process so straightforward and the results are beyond my expectations."
      </p>
      <footer class="dt-testimonial__author">
        <strong>James T.</strong>Invisalign Patient
      </footer>
    </blockquote>
    <blockquote class="dt-testimonial" role="listitem">
      <div class="dt-testimonial__stars" aria-label="5 stars">★★★★★</div>
      <p class="dt-testimonial__text">
        "My implant was done by Dr Chen and from start to finish it was an
        exceptional experience. I was terrified beforehand — completely unnecessary.
        The result looks and feels entirely like a natural tooth."
      </p>
      <footer class="dt-testimonial__author">
        <strong>Charlotte H.</strong>Dental Implant Patient
      </footer>
    </blockquote>
  </div>
</section>

<!-- BOOKING -->
<section id="booking" class="dt-booking" aria-labelledby="dt-booking-heading">
  <div class="dt-booking__info">
    <div class="dt-section-label">
      <div class="dt-section-label__dot"></div>
      <span class="dt-section-label__text">Get Started</span>
    </div>
    <h2 id="dt-booking-heading" class="dt-h2" style="color:var(--dt-white);">
      Book your free<br><em>consultation</em>
    </h2>
    <p style="font-size:.98rem; font-weight:300; line-height:1.75; color:rgba(212,232,244,.85); margin-top:10px;">
      Your 60-minute smile consultation is completely free and carries no obligation.
      We will examine your teeth, discuss your goals, and give you a clear, detailed
      treatment plan with transparent pricing.
    </p>
    <div class="dt-booking__highlight">
      <div class="dt-booking__highlight-title">Your free consultation includes</div>
      <ul class="dt-booking__highlight-items">
        <li>Full clinical examination</li>
        <li>Digital photos &amp; smile analysis</li>
        <li>Personalised treatment options</li>
        <li>Written quote with no hidden fees</li>
        <li>Finance options explained</li>
      </ul>
    </div>
  </div>
  <div class="dt-booking__form-wrap">
    <div class="dt-section-label">
      <div class="dt-section-label__dot"></div>
      <span class="dt-section-label__text">Request an Appointment</span>
    </div>
    <h3 style="font-family:var(--dt-serif); font-size:1.6rem; font-weight:600; margin-bottom:24px; color:var(--dt-navy);">
      We'll call to confirm your slot
    </h3>
    <form class="dt-form" method="post" action="" novalidate aria-label="Appointment booking form">
      <?php wp_nonce_field('tf_dt_booking', 'tf_dt_nonce'); ?>
      <div class="dt-field-row">
        <div class="dt-field">
          <label for="dt-first-name">First Name <span aria-hidden="true">*</span></label>
          <input type="text" id="dt-first-name" name="dt_first_name" required autocomplete="given-name">
        </div>
        <div class="dt-field">
          <label for="dt-last-name">Last Name <span aria-hidden="true">*</span></label>
          <input type="text" id="dt-last-name" name="dt_last_name" required autocomplete="family-name">
        </div>
      </div>
      <div class="dt-field-row">
        <div class="dt-field">
          <label for="dt-email">Email <span aria-hidden="true">*</span></label>
          <input type="email" id="dt-email" name="dt_email" required autocomplete="email">
        </div>
        <div class="dt-field">
          <label for="dt-phone">Phone <span aria-hidden="true">*</span></label>
          <input type="tel" id="dt-phone" name="dt_phone" required autocomplete="tel">
        </div>
      </div>
      <div class="dt-field">
        <label for="dt-interest">Primary Interest <span aria-hidden="true">*</span></label>
        <select id="dt-interest" name="dt_interest" required>
          <option value="">Please select…</option>
          <option value="whitening">Teeth Whitening</option>
          <option value="veneers">Porcelain Veneers</option>
          <option value="implants">Dental Implants</option>
          <option value="invisalign">Invisalign</option>
          <option value="bonding">Composite Bonding</option>
          <option value="makeover">Full Smile Makeover</option>
          <option value="general">General Check-up</option>
          <option value="unsure">Not sure — need advice</option>
        </select>
      </div>
      <div class="dt-field-row">
        <div class="dt-field">
          <label for="dt-preferred-day">Preferred Day</label>
          <select id="dt-preferred-day" name="dt_preferred_day">
            <option value="">Any day</option>
            <option value="mon">Monday</option>
            <option value="tue">Tuesday</option>
            <option value="wed">Wednesday</option>
            <option value="thu">Thursday</option>
            <option value="fri">Friday</option>
            <option value="sat">Saturday</option>
          </select>
        </div>
        <div class="dt-field">
          <label for="dt-preferred-time">Preferred Time</label>
          <select id="dt-preferred-time" name="dt_preferred_time">
            <option value="">Any time</option>
            <option value="morning">Morning (8am–12pm)</option>
            <option value="afternoon">Afternoon (12pm–5pm)</option>
            <option value="evening">Evening (5pm–7pm)</option>
          </select>
        </div>
      </div>
      <div class="dt-field">
        <label for="dt-notes">Anything else we should know?</label>
        <textarea id="dt-notes" name="dt_notes" rows="3"
                  placeholder="Any dental anxiety, previous treatment history, or specific concerns…"></textarea>
      </div>
      <button type="submit" class="dt-btn dt-btn--blue" aria-label="Submit booking request">
        Request Free Consultation
      </button>
      <p style="font-size:.75rem; color:var(--dt-slate); margin-top:8px; line-height:1.5;">
        We'll call you within 2 hours during working hours to confirm your appointment.
        No card details required.
      </p>
    </form>
  </div>
</section>

<!-- FOOTER -->
<footer class="dt-footer" role="contentinfo" aria-label="Site footer">
  <div class="dt-footer__top">
    <div>
      <div class="dt-footer__name">Clarity Dental</div>
      <div class="dt-footer__tagline">Cosmetic &amp; Restorative · Chelsea, London</div>
      <p class="dt-footer__text">
        Award-winning cosmetic and restorative dentistry in Chelsea since 2007.
        Accepting new patients — free consultations available.
      </p>
    </div>
    <div>
      <div class="dt-footer__col-title">Treatments</div>
      <ul class="dt-footer__links">
        <li><a href="#treatments">Teeth Whitening</a></li>
        <li><a href="#treatments">Porcelain Veneers</a></li>
        <li><a href="#treatments">Dental Implants</a></li>
        <li><a href="#treatments">Invisalign</a></li>
        <li><a href="#treatments">Composite Bonding</a></li>
        <li><a href="#treatments">Smile Makeovers</a></li>
      </ul>
    </div>
    <div>
      <div class="dt-footer__col-title">Practice</div>
      <ul class="dt-footer__links">
        <li><a href="#about">About Us</a></li>
        <li><a href="#team">Our Team</a></li>
        <li><a href="#packages">Packages</a></li>
        <li><a href="#booking">Book Now</a></li>
        <li><a href="#">Patient Finance</a></li>
        <li><a href="#">Emergency Dental</a></li>
      </ul>
    </div>
    <div>
      <div class="dt-footer__col-title">Visit Us</div>
      <p style="font-size:.84rem; color:var(--dt-mist); line-height:1.7;">
        18 Sloane Avenue<br>
        Chelsea<br>
        London SW3 3JD<br><br>
        020 7946 0556<br>
        hello@claritydental.co.uk
      </p>
    </div>
  </div>
  <div class="dt-footer__bottom">
    <span>© <?php echo date('Y'); ?> Clarity Dental Ltd. GDC Registered Practice. All rights reserved.</span>
    <div class="dt-footer__bottom-links">
      <a href="#">Privacy Policy</a>
      <a href="#">Complaints Policy</a>
      <a href="#">Cookie Preferences</a>
    </div>
  </div>
</footer>

<script>
(function () {
  'use strict';

  /* ── Counter animation ─────────────────────────────────── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  const isFloat = v => !isNaN(v) && v % 1 !== 0;

  document.querySelectorAll('.dt-trust-item__val[data-target]').forEach(el => {
    const raw    = el.dataset.target;
    const target = parseFloat(raw);
    if (isNaN(target)) return;
    const duration = 1800;
    const start    = performance.now();
    const suffix   = el.textContent.replace(String(raw), '').trim();
    const tick = now => {
      const t   = Math.min((now - start) / duration, 1);
      const val = target * easeOut(t);
      el.textContent = (isFloat(target) ? val.toFixed(1) : Math.round(val).toLocaleString())
                       + (suffix ? suffix : '');
      if (t < 1) requestAnimationFrame(tick);
    };
    const obs = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) { requestAnimationFrame(tick); obs.disconnect(); }
    }, { threshold: 0.5 });
    obs.observe(el);
  });

  /* ── Nav scroll ─────────────────────────────────────────── */
  const nav = document.querySelector('.dt-nav');
  if (nav) {
    window.addEventListener('scroll', () => {
      nav.style.boxShadow = window.scrollY > 60
        ? '0 2px 30px rgba(14,42,64,.12)'
        : '0 1px 20px rgba(14,42,64,.06)';
    }, { passive: true });
  }

  /* ── Form ───────────────────────────────────────────────── */
  const form = document.querySelector('.dt-form');
  if (form) {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const btn = form.querySelector('button[type="submit"]');
      btn.textContent = 'Submitting…';
      btn.disabled = true;
      setTimeout(() => {
        btn.textContent = '✓ Request Received — We\'ll call you shortly';
        btn.style.background = '#2A8A4A';
      }, 1200);
    });
  }

})();
</script>

</body>
</html>
</div><!-- .dt-body -->
<?php get_footer(); ?>
