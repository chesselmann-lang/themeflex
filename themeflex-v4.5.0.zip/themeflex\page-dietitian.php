<?php
/**
 * Template Name: Dietitian
 * Description: Premium page template for Registered Dietitian / Nutritional Therapist
 *
 * @package ThemeFlex
 */

// Fonts: Poppins + Lato
// Namespace: --dt-*
// Hero: CSS plate/bowl scene with animated food icons orbiting a central plate, nutrient ring chart
// Palette: fresh leaf #2D7D46 / warm citrus #F5841F / light cream #FFFDF5 / deep soil #3D2B1F / sky blue #5BB8D4

if ( ! defined( 'ABSPATH' ) ) exit;
srand( crc32( get_the_permalink() ) );

$dt_services = [
    [ 'icon' => '⚖️', 'title' => 'Weight Management',         'desc' => 'Evidence-based, personalised plans for sustainable weight loss or gain — no fad diets, no calorie obsession.' ],
    [ 'icon' => '🩺', 'title' => 'Medical Nutrition Therapy', 'desc' => 'Clinical dietetic support for diabetes, IBS, Crohn\'s, coeliac disease, kidney disease and heart conditions.' ],
    [ 'icon' => '🏃', 'title' => 'Sports Nutrition',          'desc' => 'Performance nutrition, periodised eating, hydration strategies and supplement analysis for athletes at all levels.' ],
    [ 'icon' => '👶', 'title' => 'Paediatric Dietetics',      'desc' => 'Specialist support for childhood growth, picky eating, food allergies, tube feeding and neurodivergent diets.' ],
    [ 'icon' => '🥗', 'title' => 'Plant-Based Eating',        'desc' => 'Vegan and vegetarian nutrition planning to ensure complete macro and micronutrient sufficiency.' ],
    [ 'icon' => '😰', 'title' => 'Disordered Eating',         'desc' => 'Compassionate, non-diet approach to healing your relationship with food — working alongside your clinical team.' ],
    [ 'icon' => '🤰', 'title' => 'Pregnancy & Postnatal',     'desc' => 'Nutrition during pregnancy, breastfeeding, hyperemesis gravidarum and postnatal recovery — evidence-based guidance.' ],
    [ 'icon' => '🧠', 'title' => 'Gut & Mental Health',       'desc' => 'Gut-brain axis nutrition, Low FODMAP protocol for IBS and the relationship between diet and mood.' ],
];

$dt_conditions = [
    'Type 1 Diabetes', 'Type 2 Diabetes', 'Gestational Diabetes', 'Irritable Bowel Syndrome',
    'Coeliac Disease', 'Crohn\'s Disease', 'Ulcerative Colitis', 'GORD / Acid Reflux',
    'Food Allergies', 'Food Intolerances', 'PCOS', 'Hypothyroidism',
    'Kidney Disease (CKD)', 'High Cholesterol', 'High Blood Pressure', 'Heart Disease',
    'Eating Disorders', 'Disordered Eating', 'ARFID', 'Orthorexia',
    'Cancer Nutrition', 'Sarcopenia',
];

$dt_process = [
    [ 'step' => '01', 'title' => 'Free Discovery',      'desc' => 'A 20-minute call to hear your goals, medical history and concerns — and to decide whether we\'re the right fit.' ],
    [ 'step' => '02', 'title' => 'Full Assessment',     'desc' => 'A detailed dietary assessment, medical and social history, review of blood results and current eating patterns.' ],
    [ 'step' => '03', 'title' => 'Bespoke Plan',        'desc' => 'A written, personalised nutrition plan with specific, achievable goals and practical meal and shopping guidance.' ],
    [ 'step' => '04', 'title' => 'Guided Support',      'desc' => 'Regular check-in sessions to adjust the plan, troubleshoot obstacles and celebrate progress — not to judge.' ],
    [ 'step' => '05', 'title' => 'Long-Term Skills',    'desc' => 'Leaving you with the nutrition knowledge and confidence to sustain healthy habits entirely on your own terms.' ],
];

$dt_testimonials = [
    [ 'name' => 'Lisa Chambers',  'role' => 'IBS Patient · Edinburgh',       'text' => 'After years of pain and restriction I finally have a clear, evidence-based plan. The Low FODMAP reintroduction was guided brilliantly — I\'m now eating more variety than ever before with barely any symptoms.' ],
    [ 'name' => 'Ben Hartley',    'role' => 'Triathlete · Manchester',       'text' => 'The sports nutrition consultation genuinely transformed my training. Fuelling strategies, race-day nutrition, carb periodisation — all explained clearly and implemented with amazing results.' ],
    [ 'name' => 'Priya Nair',     'role' => 'Parent · Coventry',             'text' => 'Our daughter had severe food allergies and extremely limited eating. The paediatric dietitian was patient, creative and understood our whole family situation. We\'ve made more progress in 3 months than in 3 years.' ],
];

$dt_packages = [
    [
        'name'     => 'Single Consultation',
        'price'    => '£95',
        'period'   => '60-minute session',
        'featured' => false,
        'items'    => [ 'Full dietary assessment', 'Medical history review', 'Personalised plan', 'Written summary report', 'Recipe & resource pack' ],
    ],
    [
        'name'     => 'Transformation Programme',
        'price'    => '£380',
        'period'   => '6 sessions over 12 weeks',
        'featured' => true,
        'items'    => [ 'Full assessment session', '5 follow-up sessions', 'Personalised meal plans', 'Blood result review', 'Supplement review', 'App-based food diary access', 'Email support between sessions', 'Exit skills review' ],
    ],
    [
        'name'     => 'Sports Performance',
        'price'    => '£220',
        'period'   => '3 specialist sessions',
        'featured' => false,
        'items'    => [ 'Resting metabolic rate test', 'Fuelling strategy plan', 'Periodised nutrition protocol', 'Hydration & supplement review', 'Race / competition plan', 'Post-session wrap-up report' ],
    ],
];

$dt_counters = [
    [ 'value' => 14,    'suffix' => 'yrs',  'label' => 'Clinical Experience', 'float' => false ],
    [ 'value' => 3400,  'suffix' => '+',    'label' => 'Clients Supported',   'float' => false ],
    [ 'value' => 4.9,   'suffix' => '★',   'label' => 'Google Rating',       'float' => true  ],
    [ 'value' => 94,    'suffix' => '%',    'label' => 'Goal Achievement',    'float' => false ],
];

// Food orbit items around the plate
$dt_foods = [
    [ 'emoji' => '🥦', 'label' => 'Fibre',      'angle' => 0   ],
    [ 'emoji' => '🐟', 'label' => 'Omega-3',    'angle' => 45  ],
    [ 'emoji' => '🫐', 'label' => 'Antioxidants','angle' => 90  ],
    [ 'emoji' => '🥑', 'label' => 'Healthy Fats','angle' => 135 ],
    [ 'emoji' => '🍎', 'label' => 'Vitamins',   'angle' => 180 ],
    [ 'emoji' => '🥕', 'label' => 'Carotenoids','angle' => 225 ],
    [ 'emoji' => '🌾', 'label' => 'Complex Carbs','angle' => 270 ],
    [ 'emoji' => '🥚', 'label' => 'Protein',    'angle' => 315 ],
];

// Floating veggie/fruit particles
$dt_particles = [];
$dt_emojis = ['🌿','✿','❋','○','◇','▷','◉'];
for ( $i = 0; $i < 20; $i++ ) {
    $dt_particles[] = [
        'x'     => rand( 0, 100 ),
        'y'     => rand( 0, 100 ),
        'size'  => rand( 8, 16 ),
        'dur'   => rand( 3000, 7000 ),
        'delay' => rand( 0, 5000 ),
        'char'  => $dt_emojis[ rand( 0, count($dt_emojis)-1 ) ],
    ];
}

// Nutrient bar data (% of recommended daily intake illustration)
$dt_nutrients = [
    [ 'name' => 'Protein',    'pct' => 88, 'color' => '#2D7D46' ],
    [ 'name' => 'Fibre',      'pct' => 64, 'color' => '#5BB8D4' ],
    [ 'name' => 'Vitamin D',  'pct' => 42, 'color' => '#F5841F' ],
    [ 'name' => 'Iron',       'pct' => 75, 'color' => '#C0392B' ],
    [ 'name' => 'Omega-3',    'pct' => 55, 'color' => '#8E44AD' ],
];
?>
?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
<style>
/* ============================================================
   DIETITIAN TEMPLATE — --dt-* namespace
   Poppins + Lato
   Palette: leaf #2D7D46 / citrus #F5841F / cream #FFFDF5 / soil #3D2B1F / sky #5BB8D4
   ============================================================ */

:root {
    --dt-leaf    : #2D7D46;
    --dt-citrus  : #F5841F;
    --dt-cream   : #FFFDF5;
    --dt-soil    : #3D2B1F;
    --dt-sky     : #5BB8D4;
    --dt-dark    : #1A2F1F;
    --dt-mid     : #22402B;
    --dt-muted   : #7A9B82;
    --dt-border  : rgba(45,125,70,.2);
    --dt-font-h  : 'Poppins', sans-serif;
    --dt-font-b  : 'Lato', sans-serif;
    --dt-radius  : 12px;
    --dt-shadow  : 0 4px 24px rgba(0,0,0,.1);
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
.dt-page { font-family: var(--dt-font-b); color: var(--dt-soil); background: var(--dt-cream); line-height: 1.65; }
.dt-page h1, .dt-page h2, .dt-page h3, .dt-page h4 { font-family: var(--dt-font-h); font-weight: 700; }
.dt-container { max-width: 1200px; margin: 0 auto; padding: 0 24px; }
.dt-section    { padding: 88px 0; }
.dt-section--dark  { background: var(--dt-dark);  color: #fff; }
.dt-section--mid   { background: var(--dt-mid);   color: #fff; }
.dt-section--light { background: #F0FBF3; }
.dt-btn {
    display: inline-block; padding: 14px 32px; border-radius: 50px;
    font-family: var(--dt-font-h); font-size: .95rem; font-weight: 600; letter-spacing: .04em;
    text-decoration: none; cursor: pointer; border: none; transition: transform .2s, box-shadow .2s;
}
.dt-btn:hover { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(0,0,0,.18); }
.dt-btn--leaf    { background: var(--dt-leaf);   color: #fff; }
.dt-btn--citrus  { background: var(--dt-citrus); color: #fff; }
.dt-btn--outline { background: transparent; border: 2px solid rgba(45,125,70,.5); color: var(--dt-leaf); }
.dt-section-label {
    font-family: var(--dt-font-h); font-size: .75rem; font-weight: 700;
    letter-spacing: .16em; color: var(--dt-leaf); text-transform: uppercase; margin-bottom: 10px;
}
.dt-section-title { font-size: clamp(1.9rem, 3.5vw, 2.6rem); margin-bottom: 16px; line-height: 1.2; }
.dt-section-sub   { font-size: 1.02rem; opacity: .7; max-width: 560px; line-height: 1.75; }

/* ---- HERO ---- */
.dt-hero {
    position: relative; min-height: 100vh; overflow: hidden;
    background: linear-gradient(135deg, var(--dt-dark) 0%, #1F3A28 55%, #152E1C 100%);
    display: flex; align-items: center;
}
/* Organic blob shapes */
.dt-hero::before {
    content: ''; position: absolute; top: -20%; right: -15%;
    width: 60vw; height: 60vw; border-radius: 40% 60% 70% 30% / 40% 50% 60% 50%;
    background: rgba(45,125,70,.1); pointer-events: none;
}
/* Floating symbols */
.dt-particle {
    position: absolute; pointer-events: none; opacity: .4;
    color: rgba(45,125,70,.7); font-size: 1rem;
}
@keyframes dt-drift {
    0%  { transform: translateY(0) rotate(0deg); opacity: .4; }
    50% { transform: translateY(-28px) rotate(180deg); opacity: .65; }
    100%{ transform: translateY(0) rotate(360deg); opacity: .4; }
}
.dt-particle { animation: dt-drift var(--dt-pdur,4s) var(--dt-pdelay,0ms) infinite ease-in-out; }

.dt-hero__inner {
    position: relative; z-index: 2;
    display: grid; grid-template-columns: 1fr 480px; gap: 60px; align-items: center;
    max-width: 1200px; margin: 0 auto; padding: 120px 24px 80px; width: 100%;
}
.dt-hero__badge {
    display: inline-flex; align-items: center; gap: 8px;
    background: rgba(45,125,70,.15); border: 1px solid rgba(45,125,70,.35);
    border-radius: 20px; padding: 6px 16px; margin-bottom: 20px;
    font-size: .78rem; font-weight: 600; letter-spacing: .08em; color: #7ED89A;
    font-family: var(--dt-font-h);
}
.dt-hero__heading { font-size: clamp(2.4rem,5vw,3.6rem); line-height: 1.1; color: #fff; margin-bottom: 20px; }
.dt-hero__heading em { color: var(--dt-citrus); font-style: normal; }
.dt-hero__sub { font-size: 1.08rem; color: rgba(255,255,255,.72); margin-bottom: 32px; line-height: 1.75; }
.dt-hero__cta { display: flex; gap: 16px; flex-wrap: wrap; }

/* ---- FOOD PLATE ORBIT SCENE ---- */
.dt-plate-scene {
    position: relative; width: 480px; height: 480px; flex-shrink: 0;
}
/* Orbit rings */
.dt-orbit-ring {
    position: absolute; border-radius: 50%;
    border: 1px dashed rgba(45,125,70,.3);
    top: 50%; left: 50%; transform: translate(-50%,-50%);
}
.dt-orbit-ring--1 { width: 300px; height: 300px; }
.dt-orbit-ring--2 { width: 420px; height: 420px; border-color: rgba(91,184,212,.2); }

/* Central plate */
.dt-plate {
    position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%);
    width: 140px; height: 140px; border-radius: 50%;
    background: radial-gradient(circle, #fff 60%, #f0ede8 100%);
    border: 8px solid #e8e4df;
    box-shadow: 0 0 40px rgba(45,125,70,.2), var(--dt-shadow);
    display: flex; align-items: center; justify-content: center;
    flex-direction: column; gap: 2px;
}
.dt-plate__label {
    font-family: var(--dt-font-h); font-size: .55rem; font-weight: 700;
    letter-spacing: .1em; color: var(--dt-leaf); text-transform: uppercase;
}
.dt-plate__bowl { font-size: 2.2rem; }
@keyframes dt-plate-glow {
    0%,100%{ box-shadow: 0 0 30px rgba(45,125,70,.2); }
    50%    { box-shadow: 0 0 50px rgba(45,125,70,.4); }
}
.dt-plate { animation: dt-plate-glow 3s infinite; }

/* Orbiting food items */
.dt-food-item {
    position: absolute; top: 50%; left: 50%;
    width: 56px; height: 56px; border-radius: 50%;
    background: rgba(255,255,255,.08); border: 2px solid rgba(255,255,255,.2);
    display: flex; align-items: center; justify-content: center;
    font-size: 1.6rem;
    transform-origin: 0 0;
}
.dt-food-item__label {
    position: absolute; bottom: -22px; left: 50%; transform: translateX(-50%);
    font-size: .45rem; font-family: var(--dt-font-h); font-weight: 600;
    letter-spacing: .08em; color: rgba(255,255,255,.6); white-space: nowrap;
}
@keyframes dt-orbit {
    from { transform: rotate(var(--dt-ang)) translateX(150px) rotate(calc(-1 * var(--dt-ang))); }
    to   { transform: rotate(calc(var(--dt-ang) + 360deg)) translateX(150px) rotate(calc(-1 * (var(--dt-ang) + 360deg))); }
}
.dt-food-item { animation: dt-orbit 20s linear infinite; }

/* Nutrient progress bars (inside scene, bottom) */
.dt-nutrient-panel {
    position: absolute; bottom: 10px; left: 0; right: 0;
    background: rgba(0,0,0,.25); border: 1px solid rgba(45,125,70,.25);
    border-radius: 8px; padding: 14px 16px;
    backdrop-filter: blur(4px);
}
.dt-nutrient-panel__title {
    font-family: var(--dt-font-h); font-size: .6rem; font-weight: 700;
    letter-spacing: .1em; color: rgba(255,255,255,.5); margin-bottom: 10px;
    text-transform: uppercase;
}
.dt-nutrient-row { margin-bottom: 8px; }
.dt-nutrient-row:last-child { margin-bottom: 0; }
.dt-nutrient-row__header {
    display: flex; justify-content: space-between; margin-bottom: 3px;
    font-family: var(--dt-font-h); font-size: .55rem; font-weight: 600;
    color: rgba(255,255,255,.7); letter-spacing: .04em;
}
.dt-nutrient-bar-bg {
    width: 100%; height: 5px; background: rgba(255,255,255,.1); border-radius: 3px;
}
.dt-nutrient-bar-fill {
    height: 100%; border-radius: 3px; transition: width 1.5s ease;
    width: 0;
}

/* ---- TRUST BAR ---- */
.dt-trust-bar { background: var(--dt-leaf); padding: 14px 0; }
.dt-trust-bar__inner {
    display: flex; justify-content: center; align-items: center;
    gap: 48px; flex-wrap: wrap;
}
.dt-trust-item {
    display: flex; align-items: center; gap: 9px;
    font-family: var(--dt-font-h); font-size: .85rem; font-weight: 600;
    letter-spacing: .04em; color: #fff;
}
.dt-trust-item span { font-size: 1.1rem; }

/* ---- COUNTERS ---- */
.dt-counters { background: var(--dt-mid); padding: 56px 0; }
.dt-counters__grid {
    display: grid; grid-template-columns: repeat(4,1fr); gap: 24px;
    max-width: 1000px; margin: 0 auto; padding: 0 24px;
}
.dt-counter-card {
    text-align: center; padding: 32px 16px;
    background: rgba(255,255,255,.05); border: 1px solid var(--dt-border);
    border-radius: var(--dt-radius);
}
.dt-counter-card__val {
    font-family: var(--dt-font-h); font-size: 2.8rem; font-weight: 800;
    color: #7ED89A; line-height: 1.1;
    display: flex; align-items: baseline; justify-content: center; gap: 2px;
}
.dt-counter-card__suffix { font-size: 1.4rem; }
.dt-counter-card__label  { font-size: .84rem; color: rgba(255,255,255,.55); margin-top: 6px; }

/* ---- SERVICES ---- */
.dt-services-grid {
    display: grid; grid-template-columns: repeat(auto-fill,minmax(260px,1fr)); gap: 24px;
    margin-top: 48px;
}
.dt-service-card {
    background: #fff; border: 1px solid rgba(0,0,0,.07);
    border-radius: var(--dt-radius); padding: 28px; position: relative; overflow: hidden;
    transition: transform .25s, box-shadow .25s;
}
.dt-service-card::before {
    content: ''; position: absolute; inset: 0 0 auto 0;
    height: 4px; background: linear-gradient(90deg, var(--dt-leaf), var(--dt-citrus));
}
.dt-service-card:hover { transform: translateY(-4px); box-shadow: 0 12px 32px rgba(0,0,0,.1); }
.dt-service-card__icon  { font-size: 2.2rem; margin-bottom: 14px; }
.dt-service-card__title { font-size: 1rem; margin-bottom: 10px; color: var(--dt-soil); }
.dt-service-card__desc  { font-size: .87rem; color: #666; line-height: 1.65; }

/* ---- CONDITIONS CLOUD ---- */
.dt-conditions { background: var(--dt-dark); }
.dt-tags-cloud  { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 32px; }
.dt-tag {
    background: rgba(45,125,70,.12); border: 1px solid rgba(45,125,70,.28);
    color: rgba(255,255,255,.8); border-radius: 20px;
    padding: 6px 14px; font-size: .82rem; transition: background .2s;
}
.dt-tag:hover { background: rgba(45,125,70,.25); color: #7ED89A; }

/* ---- PROCESS ---- */
.dt-process { background: var(--dt-mid); }
.dt-process__steps {
    display: grid; grid-template-columns: repeat(5,1fr); gap: 0;
    position: relative; margin-top: 56px;
}
.dt-process__steps::before {
    content: ''; position: absolute; top: 28px; left: 10%; right: 10%; height: 3px;
    background: linear-gradient(90deg, var(--dt-leaf), var(--dt-citrus), var(--dt-leaf));
    z-index: 0;
}
.dt-step { text-align: center; position: relative; z-index: 1; padding: 0 12px; }
.dt-step__num {
    width: 56px; height: 56px; border-radius: 50%; margin: 0 auto 20px;
    display: flex; align-items: center; justify-content: center;
    font-family: var(--dt-font-h); font-size: 1.1rem; font-weight: 800;
    background: var(--dt-mid); border: 3px solid var(--dt-leaf); color: #7ED89A;
    box-shadow: 0 0 16px rgba(45,125,70,.3);
}
.dt-step__title { font-family: var(--dt-font-h); font-size: .88rem; font-weight: 700; color: #fff; margin-bottom: 8px; }
.dt-step__desc  { font-size: .78rem; color: rgba(255,255,255,.55); line-height: 1.6; }

/* ---- DIETITIAN CREDENTIAL ---- */
.dt-dietitian-section { background: var(--dt-dark); }
.dt-dietitian-wrap { display: grid; grid-template-columns: 300px 1fr; gap: 56px; align-items: center; }
/* CSS dietitian figure */
.dt-dt-figure { position: relative; height: 280px; }
.dt-dti__body {
    position: absolute; bottom: 0; left: 50%; transform: translateX(-50%);
    width: 72px; height: 125px;
    background: var(--dt-leaf); border-radius: 8px 8px 4px 4px;
}
/* White lab coat */
.dt-dti__body::before {
    content: ''; position: absolute; top: 0; left: -5px; right: -5px; height: 85px;
    background: rgba(255,255,255,.92); border-radius: 6px 6px 0 0;
    border-bottom: 3px solid rgba(45,125,70,.3);
}
.dt-dti__body::after {
    content: '🥗'; position: absolute; top: 16px; left: 50%; transform: translateX(-50%);
    font-size: .8rem; z-index: 1;
}
.dt-dti__legs {
    position: absolute; bottom: 0; left: 50%; transform: translateX(-50%);
    display: flex; gap: 8px;
}
.dt-dti__leg {
    width: 26px; height: 55px;
    background: var(--dt-soil); border-radius: 0 0 4px 4px;
}
.dt-dti__head {
    position: absolute; bottom: 123px; left: 50%; transform: translateX(-50%);
    width: 46px; height: 46px;
    background: #C9956A; border-radius: 50%;
}
.dt-dti__head::before {
    content: ''; position: absolute; top: -6px; left: -3px; right: -3px; height: 22px;
    background: var(--dt-soil); border-radius: 50% 50% 0 0;
}
.dt-dti__arm {
    position: absolute; bottom: 70px;
    width: 16px; height: 66px;
    background: rgba(255,255,255,.9); border-radius: 6px;
}
.dt-dti__arm--l { left: calc(50% - 52px); transform: rotate(12deg); transform-origin: top; }
.dt-dti__arm--r { right: calc(50% - 52px); transform: rotate(-18deg); transform-origin: top; }
.dt-dti__clipboard {
    position: absolute; bottom: 10px; right: calc(50% - 72px);
    width: 24px; height: 32px;
    background: #fff; border: 2px solid var(--dt-leaf); border-radius: 3px;
    font-size: .55rem; display: flex; align-items: center; justify-content: center;
    color: var(--dt-leaf); font-family: var(--dt-font-h); font-weight: 700;
}

.dt-dietitian-info h3 { font-size: 1.8rem; color: #fff; margin-bottom: 4px; }
.dt-dietitian-info h4 { font-size: .88rem; color: #7ED89A; font-family: var(--dt-font-h); letter-spacing: .06em; margin-bottom: 20px; font-weight: 600; }
.dt-dietitian-info p  { color: rgba(255,255,255,.72); line-height: 1.75; margin-bottom: 20px; }
.dt-dietitian-badges  { display: flex; flex-wrap: wrap; gap: 10px; }
.dt-badge {
    display: inline-flex; align-items: center; gap: 6px;
    background: rgba(45,125,70,.12); border: 1px solid rgba(45,125,70,.28);
    border-radius: 20px; padding: 6px 14px;
    font-size: .78rem; font-weight: 700; font-family: var(--dt-font-h);
    letter-spacing: .04em; color: #7ED89A;
}

/* ---- PACKAGES ---- */
.dt-packages-grid {
    display: grid; grid-template-columns: repeat(3,1fr); gap: 24px;
    margin-top: 48px; align-items: start;
}
.dt-package {
    background: #fff; border: 2px solid rgba(0,0,0,.07);
    border-radius: var(--dt-radius); padding: 32px; position: relative;
}
.dt-package--featured {
    background: var(--dt-dark); border-color: var(--dt-leaf);
    box-shadow: 0 0 32px rgba(45,125,70,.2); transform: scale(1.03);
}
.dt-package__badge {
    position: absolute; top: -14px; left: 50%; transform: translateX(-50%);
    background: var(--dt-leaf); color: #fff;
    font-family: var(--dt-font-h); font-size: .72rem; font-weight: 700;
    letter-spacing: .1em; padding: 4px 16px; border-radius: 20px; white-space: nowrap;
}
.dt-package__name { font-size: 1.1rem; margin-bottom: 6px; }
.dt-package--featured .dt-package__name { color: #fff; }
.dt-package__price { font-family: var(--dt-font-h); font-size: 2.2rem; font-weight: 800; color: var(--dt-leaf); margin: 12px 0 4px; }
.dt-package--featured .dt-package__price { color: #7ED89A; }
.dt-package__period { font-size: .78rem; color: var(--dt-muted); margin-bottom: 20px; }
.dt-package--featured .dt-package__period { color: rgba(255,255,255,.5); }
.dt-package__items { list-style: none; margin-bottom: 28px; }
.dt-package__items li {
    padding: 7px 0; font-size: .87rem; border-bottom: 1px solid rgba(0,0,0,.06);
    display: flex; gap: 8px;
}
.dt-package--featured .dt-package__items li { border-color: rgba(255,255,255,.08); color: rgba(255,255,255,.82); }
.dt-package__items li::before { content: '✓'; color: var(--dt-leaf); font-weight: 700; flex-shrink: 0; }
.dt-package--featured .dt-package__items li::before { color: #7ED89A; }
.dt-package__cta { display: block; text-align: center; }

/* ---- TESTIMONIALS ---- */
.dt-testi-grid {
    display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; margin-top: 48px;
}
.dt-testi {
    background: #fff; border: 1px solid rgba(0,0,0,.07);
    border-radius: var(--dt-radius); padding: 28px;
}
.dt-testi__quote { font-size: 2.8rem; line-height: 1; color: var(--dt-leaf); opacity: .35; margin-bottom: 6px; }
.dt-testi__stars { color: #F5A623; margin-bottom: 10px; }
.dt-testi__text  { font-size: .88rem; color: #555; line-height: 1.7; margin-bottom: 18px; }
.dt-testi__name  { font-weight: 700; font-size: .88rem; color: var(--dt-soil); font-family: var(--dt-font-h); }
.dt-testi__role  { font-size: .78rem; color: var(--dt-muted); }

/* ---- BOOKING ---- */
.dt-booking { background: var(--dt-dark); }
.dt-booking__wrap { display: grid; grid-template-columns: 1fr 1fr; gap: 56px; align-items: start; }
.dt-booking__info h2 { color: #fff; margin-bottom: 16px; }
.dt-booking__info p  { color: rgba(255,255,255,.68); line-height: 1.75; margin-bottom: 24px; }
.dt-booking__bullets { list-style: none; }
.dt-booking__bullets li {
    padding: 10px 0; border-bottom: 1px solid rgba(255,255,255,.07);
    color: rgba(255,255,255,.75); font-size: .9rem;
    display: flex; gap: 10px;
}
.dt-booking__bullets li::before { content: '🥗'; flex-shrink: 0; }

.dt-form {
    background: var(--dt-mid); border: 1px solid var(--dt-border);
    border-radius: var(--dt-radius); padding: 36px;
}
.dt-form h3 { color: #fff; font-size: 1.35rem; margin-bottom: 24px; }
.dt-field    { margin-bottom: 18px; }
.dt-field label {
    display: block; font-size: .78rem; font-weight: 700; letter-spacing: .06em;
    color: rgba(255,255,255,.6); margin-bottom: 6px; text-transform: uppercase;
    font-family: var(--dt-font-h);
}
.dt-field input, .dt-field select, .dt-field textarea {
    width: 100%; padding: 11px 14px; border-radius: var(--dt-radius);
    background: var(--dt-dark); border: 1px solid var(--dt-border);
    color: #fff; font-family: var(--dt-font-b); font-size: .92rem;
    outline: none; transition: border-color .2s;
}
.dt-field input:focus, .dt-field select:focus, .dt-field textarea:focus { border-color: var(--dt-leaf); }
.dt-field textarea { resize: vertical; min-height: 100px; }
.dt-field select option { background: var(--dt-dark); }
.dt-field-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.dt-form__submit {
    width: 100%; padding: 15px; background: var(--dt-leaf); color: #fff;
    border: none; border-radius: 50px; font-family: var(--dt-font-h);
    font-size: 1rem; font-weight: 700; letter-spacing: .06em; cursor: pointer;
    transition: filter .2s, transform .2s;
}
.dt-form__submit:hover { filter: brightness(1.1); transform: translateY(-1px); }

/* ---- FOOTER ---- */
.dt-footer {
    background: var(--dt-dark); padding: 40px 0; text-align: center;
    border-top: 1px solid rgba(255,255,255,.05);
}
.dt-footer p { font-size: .82rem; color: rgba(255,255,255,.35); margin-bottom: 4px; }
.dt-footer__phone { font-family: var(--dt-font-h); font-size: 1.6rem; color: var(--dt-leaf); margin-bottom: 8px; }
.dt-footer__disclaimer {
    margin-top: 16px; font-size: .7rem; color: rgba(255,255,255,.28); line-height: 1.5;
    max-width: 700px; margin-left: auto; margin-right: auto;
}

/* ---- RESPONSIVE ---- */
@media (max-width: 900px) {
    .dt-hero__inner     { grid-template-columns: 1fr; padding-top: 100px; }
    .dt-plate-scene     { width: 100%; max-width: 400px; height: 400px; margin: 0 auto; }
    .dt-counters__grid  { grid-template-columns: repeat(2,1fr); }
    .dt-process__steps  { grid-template-columns: 1fr; gap: 32px; }
    .dt-process__steps::before { display: none; }
    .dt-dietitian-wrap  { grid-template-columns: 1fr; }
    .dt-dt-figure       { height: 200px; margin: 0 auto 32px; }
    .dt-packages-grid   { grid-template-columns: 1fr; }
    .dt-package--featured { transform: none; }
    .dt-testi-grid      { grid-template-columns: 1fr; }
    .dt-booking__wrap   { grid-template-columns: 1fr; }
}
</style>
<?php get_header(); ?>

<div class="">

>

<!-- ═══════════════════════════════════════════════════════
     HERO — Food Orbit / Plate Scene
     ═══════════════════════════════════════════════════════ -->
<section class="dt-hero" aria-label="Hero">

    <!-- Floating particles -->
    <?php foreach ( $dt_particles as $pp ) : ?>
        <div class="dt-particle" aria-hidden="true" style="
            left:<?php echo esc_attr($pp['x']); ?>%;
            top:<?php echo esc_attr($pp['y']); ?>%;
            font-size:<?php echo esc_attr($pp['size']); ?>px;
            --dt-pdur:<?php echo esc_attr($pp['dur']); ?>ms;
            --dt-pdelay:<?php echo esc_attr($pp['delay']); ?>ms;
        "><?php echo esc_html($pp['char']); ?></div>
    <?php endforeach; ?>

    <div class="dt-hero__inner">
        <!-- Text -->
        <div>
            <div class="dt-hero__badge">🏅 HCPC Registered Dietitians</div>
            <h1 class="dt-hero__heading">
                Eat Well.<br>Live <em>Better</em>.<br>Feel the Difference.
            </h1>
            <p class="dt-hero__sub">Evidence-based, personalised nutrition from HCPC registered dietitians. Whether you have a medical condition, sporting goal or simply want to eat better — we'll show you how.</p>
            <div class="dt-hero__cta">
                <a href="#booking" class="dt-btn dt-btn--leaf">Book a Consultation</a>
                <a href="#booking" class="dt-btn dt-btn--outline">20-Min Free Discovery</a>
            </div>
        </div>

        <!-- Food orbit scene -->
        <div class="dt-plate-scene" aria-hidden="true">
            <div class="dt-orbit-ring dt-orbit-ring--1"></div>
            <div class="dt-orbit-ring dt-orbit-ring--2"></div>

            <!-- Central plate -->
            <div class="dt-plate">
                <div class="dt-plate__bowl">🥣</div>
                <div class="dt-plate__label">Balanced Plate</div>
            </div>

            <!-- Orbiting food items -->
            <?php foreach ( $dt_foods as $food ) :
                $rad = deg2rad( $food['angle'] );
                $r = 150; // orbit radius
                $cx = 240; $cy = 240; // scene centre
                $tx = $cx + $r * cos($rad);
                $ty = $cy + $r * sin($rad);
            ?>
                <div class="dt-food-item" style="
                    left:<?php echo esc_attr( round($tx) ); ?>px;
                    top:<?php echo esc_attr( round($ty) ); ?>px;
                    transform: translate(-50%,-50%);
                    --dt-ang:<?php echo esc_attr($food['angle']); ?>deg;
                    animation: dt-orbit 20s linear infinite;
                    animation-delay: calc(<?php echo esc_attr($food['angle']); ?>deg / 360deg * -20s);
                ">
                    <?php echo esc_html($food['emoji']); ?>
                    <span class="dt-food-item__label"><?php echo esc_html($food['label']); ?></span>
                </div>
            <?php endforeach; ?>

            <!-- Nutrient progress panel -->
            <div class="dt-nutrient-panel" id="dt-nutrient-panel">
                <div class="dt-nutrient-panel__title">Today's Nutrient Snapshot</div>
                <?php foreach ( $dt_nutrients as $nt ) : ?>
                    <div class="dt-nutrient-row">
                        <div class="dt-nutrient-row__header">
                            <span><?php echo esc_html($nt['name']); ?></span>
                            <span><?php echo esc_attr($nt['pct']); ?>% RDI</span>
                        </div>
                        <div class="dt-nutrient-bar-bg">
                            <div class="dt-nutrient-bar-fill"
                                 data-width="<?php echo esc_attr($nt['pct']); ?>"
                                 style="background:<?php echo esc_attr($nt['color']); ?>;width:0%;">
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     TRUST BAR
     ═══════════════════════════════════════════════════════ -->
<div class="dt-trust-bar" role="complementary">
    <div class="dt-trust-bar__inner dt-container">
        <div class="dt-trust-item"><span>🏅</span> HCPC Registered</div>
        <div class="dt-trust-item"><span>🩺</span> BDA Members</div>
        <div class="dt-trust-item"><span>📋</span> Non-Diet Approach</div>
        <div class="dt-trust-item"><span>⭐</span> Evidence-Based</div>
        <div class="dt-trust-item"><span>🛡️</span> Fully Insured</div>
    </div>
</div>

<!-- ═══════════════════════════════════════════════════════
     COUNTERS
     ═══════════════════════════════════════════════════════ -->
<section class="dt-counters" aria-label="Key figures">
    <div class="dt-counters__grid">
        <?php foreach ( $dt_counters as $ctr ) : ?>
            <div class="dt-counter-card">
                <div class="dt-counter-card__val">
                    <span class="dt-counter-num"
                          data-target="<?php echo esc_attr($ctr['value']); ?>"
                          data-suffix="<?php echo esc_attr($ctr['suffix']); ?>"
                          <?php if($ctr['float']) echo 'data-float="1"'; ?>>0</span>
                    <span class="dt-counter-card__suffix"><?php echo esc_html($ctr['suffix']); ?></span>
                </div>
                <div class="dt-counter-card__label"><?php echo esc_html($ctr['label']); ?></div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     SERVICES
     ═══════════════════════════════════════════════════════ -->
<section class="dt-section dt-section--light" aria-labelledby="dt-services-title">
    <div class="dt-container">
        <div class="dt-section-label">What We Do</div>
        <h2 class="dt-section-title" id="dt-services-title">Nutrition & Dietetic Services</h2>
        <p class="dt-section-sub">Personalised, evidence-based nutrition support for a wide range of health goals and medical conditions — from one-off advice to ongoing programmes.</p>
        <div class="dt-services-grid">
            <?php foreach ( $dt_services as $svc ) : ?>
                <div class="dt-service-card">
                    <div class="dt-service-card__icon"><?php echo esc_html($svc['icon']); ?></div>
                    <h3 class="dt-service-card__title"><?php echo esc_html($svc['title']); ?></h3>
                    <p class="dt-service-card__desc"><?php echo esc_html($svc['desc']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     CONDITIONS CLOUD
     ═══════════════════════════════════════════════════════ -->
<section class="dt-section dt-conditions" aria-labelledby="dt-conditions-title">
    <div class="dt-container">
        <div class="dt-section-label" style="color:#7ED89A;">We Support</div>
        <h2 class="dt-section-title" id="dt-conditions-title" style="color:#fff;">Conditions We Specialise In</h2>
        <p class="dt-section-sub" style="color:rgba(255,255,255,.6);">From IBS to eating disorders, diabetes to sports performance — our dietitians have specialist expertise across the full clinical spectrum.</p>
        <div class="dt-tags-cloud" role="list">
            <?php foreach ( $dt_conditions as $cond ) : ?>
                <span class="dt-tag" role="listitem"><?php echo esc_html($cond); ?></span>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     PROCESS
     ═══════════════════════════════════════════════════════ -->
<section class="dt-section dt-process" aria-labelledby="dt-process-title">
    <div class="dt-container">
        <div class="dt-section-label" style="color:#7ED89A;">Your Journey</div>
        <h2 class="dt-section-title" id="dt-process-title" style="color:#fff;">How We Work Together</h2>
        <p class="dt-section-sub" style="color:rgba(255,255,255,.58);">A gentle, non-judgemental process that puts your wellbeing — not a number on a scale — at the centre of everything.</p>
        <div class="dt-process__steps">
            <?php foreach ( $dt_process as $ps ) : ?>
                <div class="dt-step">
                    <div class="dt-step__num"><?php echo esc_html($ps['step']); ?></div>
                    <div class="dt-step__title"><?php echo esc_html($ps['title']); ?></div>
                    <p class="dt-step__desc"><?php echo esc_html($ps['desc']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     LEAD DIETITIAN CREDENTIAL
     ═══════════════════════════════════════════════════════ -->
<section class="dt-section dt-dietitian-section" aria-labelledby="dt-dietitian-title">
    <div class="dt-container">
        <div class="dt-dietitian-wrap">
            <div class="dt-dt-figure" aria-hidden="true">
                <div class="dt-dti__arm dt-dti__arm--l"></div>
                <div class="dt-dti__arm dt-dti__arm--r"></div>
                <div class="dt-dti__body"></div>
                <div class="dt-dti__legs">
                    <div class="dt-dti__leg"></div>
                    <div class="dt-dti__leg"></div>
                </div>
                <div class="dt-dti__head"></div>
                <div class="dt-dti__clipboard">📋</div>
            </div>
            <div class="dt-dietitian-info">
                <div class="dt-section-label">Lead Dietitian</div>
                <h3 id="dt-dietitian-title">Dr. Emily Forsythe</h3>
                <h4>BSc (Hons) Dietetics · MSc Nutrition Science · HCPC Registered · BDA Member</h4>
                <p>
                    Emily has practised clinical dietetics for <?php echo date('Y') - 2010; ?> years across NHS gastroenterology, community diabetes services and now private practice. She holds an MSc in Nutrition Science from King's College London and holds specialist credentials in Low FODMAP therapy and eating disorder dietetics.
                </p>
                <p>
                    Our team are all HCPC registered, BDA members and hold full professional indemnity insurance. We use a non-diet, Health at Every Size (HAES) aligned approach — treating the whole person, not just a number on a scale.
                </p>
                <div class="dt-dietitian-badges">
                    <span class="dt-badge">🏅 HCPC Registered</span>
                    <span class="dt-badge">🩺 BDA Member</span>
                    <span class="dt-badge">📋 MSc Nutrition</span>
                    <span class="dt-badge">🫁 Low FODMAP Cert</span>
                    <span class="dt-badge">💚 HAES Aligned</span>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     PACKAGES
     ═══════════════════════════════════════════════════════ -->
<section class="dt-section" aria-labelledby="dt-packages-title">
    <div class="dt-container">
        <div class="dt-section-label">Pricing</div>
        <h2 class="dt-section-title" id="dt-packages-title">Transparent Pricing</h2>
        <p class="dt-section-sub">No hidden fees, no upsells. All packages include a written plan and email follow-up as standard.</p>
        <div class="dt-packages-grid">
            <?php foreach ( $dt_packages as $pkg ) : ?>
                <div class="dt-package <?php echo $pkg['featured'] ? 'dt-package--featured' : ''; ?>">
                    <?php if ( $pkg['featured'] ) : ?>
                        <div class="dt-package__badge">BEST VALUE</div>
                    <?php endif; ?>
                    <h3 class="dt-package__name"><?php echo esc_html($pkg['name']); ?></h3>
                    <div class="dt-package__price"><?php echo esc_html($pkg['price']); ?></div>
                    <div class="dt-package__period"><?php echo esc_html($pkg['period']); ?></div>
                    <ul class="dt-package__items">
                        <?php foreach ( $pkg['items'] as $item ) : ?>
                            <li><?php echo esc_html($item); ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <a href="#booking" class="dt-btn dt-btn--leaf dt-package__cta">Book This Package</a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     TESTIMONIALS
     ═══════════════════════════════════════════════════════ -->
<section class="dt-section dt-section--light" aria-labelledby="dt-testi-title">
    <div class="dt-container">
        <div class="dt-section-label">Patient Stories</div>
        <h2 class="dt-section-title" id="dt-testi-title">Real People, Real Results</h2>
        <p class="dt-section-sub">Our clients come to us with complex histories and leave with the skills and confidence to eat well for life.</p>
        <div class="dt-testi-grid">
            <?php foreach ( $dt_testimonials as $t ) : ?>
                <blockquote class="dt-testi">
                    <div class="dt-testi__quote" aria-hidden="true">❝</div>
                    <div class="dt-testi__stars" aria-label="5 stars">★★★★★</div>
                    <p class="dt-testi__text"><?php echo esc_html($t['text']); ?></p>
                    <footer>
                        <div class="dt-testi__name"><?php echo esc_html($t['name']); ?></div>
                        <div class="dt-testi__role"><?php echo esc_html($t['role']); ?></div>
                    </footer>
                </blockquote>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     BOOKING FORM
     ═══════════════════════════════════════════════════════ -->
<section class="dt-section dt-booking" id="booking" aria-labelledby="dt-booking-title">
    <div class="dt-container">
        <div class="dt-booking__wrap">
            <div class="dt-booking__info">
                <div class="dt-section-label" style="color:#7ED89A;">Book a Session</div>
                <h2 id="dt-booking-title" style="color:#fff;">Start Your Nutrition Journey</h2>
                <p>Book a free 20-minute discovery call or go straight to your first full consultation. No obligation, no judgement — just expert support at your own pace.</p>
                <ul class="dt-booking__bullets">
                    <li>Free 20-min discovery call available</li>
                    <li>Video and in-person sessions offered</li>
                    <li>Evening &amp; weekend appointments</li>
                    <li>No GP referral required</li>
                    <li>Most private health insurers accepted</li>
                    <li>HCPC registered &amp; fully insured</li>
                </ul>
            </div>
            <div class="dt-form">
                <h3>Book a Consultation</h3>
                <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" novalidate>
                    <?php wp_nonce_field( 'tf_dt_booking', 'tf_dt_nonce' ); ?>
                    <input type="hidden" name="action" value="tf_dt_booking">

                    <div class="dt-field-row">
                        <div class="dt-field">
                            <label for="dt-name">Full Name *</label>
                            <input type="text" id="dt-name" name="dt_name" required placeholder="Jane Smith">
                        </div>
                        <div class="dt-field">
                            <label for="dt-phone">Phone *</label>
                            <input type="tel" id="dt-phone" name="dt_phone" required placeholder="07700 900123">
                        </div>
                    </div>

                    <div class="dt-field">
                        <label for="dt-email">Email Address *</label>
                        <input type="email" id="dt-email" name="dt_email" required placeholder="jane@example.com">
                    </div>

                    <div class="dt-field">
                        <label for="dt-reason">Main Reason for Referral *</label>
                        <select id="dt-reason" name="dt_reason" required>
                            <option value="">— Select primary goal or concern —</option>
                            <option value="weight">Weight Management</option>
                            <option value="ibs">IBS / Gut Health</option>
                            <option value="diabetes">Diabetes / Blood Sugar</option>
                            <option value="eating">Eating Disorder / Disordered Eating</option>
                            <option value="sports">Sports &amp; Performance Nutrition</option>
                            <option value="allergy">Food Allergy / Intolerance</option>
                            <option value="paediatric">Paediatric / Child Nutrition</option>
                            <option value="heart">Heart Health / Cholesterol</option>
                            <option value="pregnancy">Pregnancy / Postnatal</option>
                            <option value="plant">Plant-Based / Vegan Nutrition</option>
                            <option value="other">Other / General Wellbeing</option>
                        </select>
                    </div>

                    <div class="dt-field-row">
                        <div class="dt-field">
                            <label for="dt-session">Session Type</label>
                            <select id="dt-session" name="dt_session">
                                <option value="discovery">Free Discovery Call (20 min)</option>
                                <option value="initial">Initial Consultation (60 min)</option>
                                <option value="followup">Follow-Up Session (45 min)</option>
                            </select>
                        </div>
                        <div class="dt-field">
                            <label for="dt-format">Format</label>
                            <select id="dt-format" name="dt_format">
                                <option value="video">Video Call</option>
                                <option value="inperson">In Person</option>
                                <option value="phone">Telephone</option>
                            </select>
                        </div>
                    </div>

                    <div class="dt-field">
                        <label for="dt-insurance">Private Health Insurance?</label>
                        <select id="dt-insurance" name="dt_insurance">
                            <option value="self-pay">Self-pay</option>
                            <option value="bupa">BUPA</option>
                            <option value="axa">AXA Health</option>
                            <option value="aviva">Aviva</option>
                            <option value="vitality">Vitality</option>
                            <option value="other">Other Insurer</option>
                        </select>
                    </div>

                    <div class="dt-field">
                        <label for="dt-notes">Tell Us a Little More</label>
                        <textarea id="dt-notes" name="dt_notes" placeholder="Briefly describe your situation, health history or goals — this helps us pair you with the right dietitian..."></textarea>
                    </div>

                    <button type="submit" class="dt-form__submit">🥗 Book My Consultation</button>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     FOOTER
     ═══════════════════════════════════════════════════════ -->
<footer class="dt-footer" role="contentinfo">
    <div class="dt-container">
        <p>Forsythe Nutrition &amp; Dietetics &nbsp;·&nbsp; HCPC Registered &nbsp;·&nbsp; BDA Members</p>
        <div class="dt-footer__phone">📞 01234 567 890</div>
        <p><?php echo esc_html( get_bloginfo('name') ); ?> &copy; <?php echo date('Y'); ?> &nbsp;·&nbsp; All dietitians are HCPC registered and hold professional indemnity insurance</p>
        <p class="dt-footer__disclaimer">The information provided on this website is for general educational purposes and does not constitute individual dietary or medical advice. Please consult a registered dietitian or your GP for personalised guidance.</p>
    </div>
</footer>

<script>
(function(){
    'use strict';

    /* IntersectionObserver counter animation */
    var easeOut = function(t){ return 1 - Math.pow(1-t,3); };
    var counters = document.querySelectorAll('.dt-counter-num');
    if(counters.length){
        var observer = new IntersectionObserver(function(entries){
            entries.forEach(function(entry){
                if(!entry.isIntersecting) return;
                observer.unobserve(entry.target);
                var el = entry.target;
                var target = parseFloat(el.dataset.target);
                var isFloat = el.dataset.float === '1';
                if(isNaN(target)) return;
                var start = null, dur = 1800;
                function tick(ts){
                    if(!start) start = ts;
                    var prog = Math.min((ts-start)/dur,1);
                    var val = easeOut(prog)*target;
                    el.textContent = isFloat ? val.toFixed(1) : Math.floor(val).toLocaleString();
                    if(prog<1) requestAnimationFrame(tick);
                    else el.textContent = isFloat ? target.toFixed(1) : target.toLocaleString();
                }
                requestAnimationFrame(tick);
            });
        }, {threshold:0.3});
        counters.forEach(function(c){ observer.observe(c); });
    }

    /* Animate nutrient bars on page load */
    setTimeout(function(){
        document.querySelectorAll('.dt-nutrient-bar-fill').forEach(function(bar){
            var w = bar.dataset.width || 0;
            bar.style.width = w + '%';
        });
    }, 800);

    /* Orbit keyframe injection via JS (supplement CSS custom property approach) */
    var foods = document.querySelectorAll('.dt-food-item');
    foods.forEach(function(food, i){
        var ang = parseFloat(food.style.getPropertyValue('--dt-ang')) || i * 45;
        food.style.animation = 'dt-orbit 20s linear infinite';
        food.style.animationDelay = (-ang / 360 * 20) + 's';
    });

})();
</script>

</div><!-- . -->

<?php get_footer(); ?>
