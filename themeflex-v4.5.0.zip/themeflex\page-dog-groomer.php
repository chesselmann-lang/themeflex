<?php
/**
 * Template Name: Dog Groomer — Pawfect Grooming
 *
 * Premium dog grooming salon page template.
 * Palette  : sky teal #2A8B8B / warm cream #FDF9F4 / coral #E8704A / sand #F5EFE6 / navy #1A2F4A
 * Fonts    : Nunito (headings + body) + Fraunces (accent serif)
 * Namespace: --dg-*
 *
 * @package ThemeFlex
 */

if ( ! defined( 'ABSPATH' ) ) exit;

srand( crc32( get_the_permalink() ) );

/* ── helpers ── */
$site  = get_bloginfo( 'name' ) ?: 'Pawfect Grooming';
$phone = get_theme_mod( 'tf_phone', '+44 20 7946 0633' );
$email = get_theme_mod( 'tf_email', 'hello@pawfectgrooming.co.uk' );
$addr  = get_theme_mod( 'tf_address', '14 Blossom Lane, Chelsea, London SW3' );

/* ── floating paw prints ── */
$paw_sizes  = [28, 22, 34, 26, 20, 32, 24, 30, 18, 36, 22, 28, 24, 20, 32];
$paw_pos    = [
  ['top:6%','left:4%'],  ['top:12%','left:88%'], ['top:25%','left:92%'],
  ['top:38%','left:2%'], ['top:55%','left:6%'],  ['top:68%','left:90%'],
  ['top:78%','left:15%'],['top:85%','left:82%'], ['top:72%','left:48%'],
  ['top:15%','left:55%'],['top:44%','left:78%'], ['top:30%','left:18%'],
  ['top:60%','left:35%'],['top:90%','left:62%'], ['top:8%','left:72%'],
];

/* ── services ── */
$services = [
  [ 'icon' => '✂️', 'title' => 'Full Groom',           'price' => 'from £55', 'desc' => 'Bath, blow-dry, breed-specific cut, ear clean, nail trim, and finishing spritz. The full luxury treatment.' ],
  [ 'icon' => '🛁', 'title' => 'Bath & Dry',            'price' => 'from £35', 'desc' => 'Premium shampoo and conditioner, blow-dry, brush-out, and a spritz of our signature pet-safe cologne.' ],
  [ 'icon' => '💅', 'title' => 'Puppy First Groom',     'price' => 'from £30', 'desc' => 'Gentle introduction for puppies under 6 months. Short, positive sessions to build confidence and trust.' ],
  [ 'icon' => '🐾', 'title' => 'Nail Trim & File',      'price' => '£15',      'desc' => 'Quick, stress-free nail trim and smooth filing. Can be added to any groom or booked standalone.' ],
  [ 'icon' => '🌿', 'title' => 'De-Shedding Treatment', 'price' => 'from £45', 'desc' => 'High-velocity blow-out, de-shedding shampoo, and undercoat removal for double-coated breeds.' ],
  [ 'icon' => '⭐', 'title' => 'Spa Add-Ons',           'price' => 'from £10', 'desc' => 'Blueberry facial, teeth brushing, paw balm massage, and luxury conditioning treatments.' ],
];

/* ── dog breeds / size chart ── */
$sizes = [
  [ 'label' => 'XS / Toy',     'example' => 'Chihuahua, Pom, Maltese',      'full' => '£55', 'bath' => '£35' ],
  [ 'label' => 'Small',        'example' => 'Shih Tzu, Bichon, Dachshund',  'full' => '£65', 'bath' => '£42' ],
  [ 'label' => 'Medium',       'example' => 'Cocker, Westie, Schnauzer',     'full' => '£78', 'bath' => '£52' ],
  [ 'label' => 'Large',        'example' => 'Labrador, Golden, Springer',    'full' => '£90', 'bath' => '£62' ],
  [ 'label' => 'XL / Giant',   'example' => 'Bernese, Newfie, St. Bernard',  'full' => 'POA', 'bath' => 'POA' ],
];

/* ── groomers team ── */
$team = [
  [ 'name' => 'Sophie Clarke',   'title' => 'Lead Groomer & Founder', 'years' => '14 yrs', 'spec' => 'Doodles & Poodles' ],
  [ 'name' => 'Olivia Marsh',    'title' => 'Senior Dog Groomer',      'years' => '9 yrs',  'spec' => 'Spaniels & Terriers' ],
  [ 'name' => 'Chloe Baxter',    'title' => 'Puppy Specialist',        'years' => '5 yrs',  'spec' => 'First-Groom Pups' ],
  [ 'name' => 'Erin Blackwood',  'title' => 'Creative Groomer',        'years' => '7 yrs',  'spec' => 'Asian Fusion Style' ],
];

/* ── testimonials ── */
$testimonials = [
  [
    'quote' => 'Bertie used to shake the entire car journey to his old groomer. Now he pulls me towards Pawfect — wagging tail, the lot. The team here is absolutely magic with anxious dogs. We would never go anywhere else.',
    'name'  => 'Hannah T.',
    'breed' => 'Owner of Bertie, Miniature Schnauzer',
    'stars' => 5,
  ],
  [
    'quote' => 'The most professional, caring grooming salon I\'ve visited in twelve years of dog ownership. Our golden came out smelling incredible and looking like she\'d stepped off a photoshoot. Worth every penny.',
    'name'  => 'David K.',
    'breed' => 'Owner of Honey, Golden Retriever',
    'stars' => 5,
  ],
  [
    'quote' => 'Brought our three cockapoos for their first ever groom. Sophie was endlessly patient, explained every step, and sent us progress photos. All three were calm and happy at the end. Outstanding.',
    'name'  => 'Priya M.',
    'breed' => 'Owner of Biscuit, Marmite & Pickle',
    'stars' => 5,
  ],
];

/* ── breed-specific highlights ── */
$breeds = [
  'Doodle','Poodle','Spaniel','Terrier','Shih Tzu','Bichon','Schnauzer',
  'Cavapoo','Cockapoo','Labrador','Golden','Yorkshire','Westie','Lhasa Apso',
  'Maltese','Pomeranian','Chihuahua','Bernese','Husky','Border Collie',
];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,300;0,400;0,600;0,700;0,800;1,600&family=Fraunces:ital,wght@0,400;0,600;1,400;1,600&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════
   PAWFECT GROOMING — CSS CUSTOM PROPERTIES
   ═══════════════════════════════════════════ */
:root {
  --dg-teal:    #2A8B8B;
  --dg-teal2:   #1E6E6E;
  --dg-coral:   #E8704A;
  --dg-coral2:  #F08060;
  --dg-cream:   #FDF9F4;
  --dg-sand:    #F5EFE6;
  --dg-navy:    #1A2F4A;
  --dg-text:    #2D3748;
  --dg-muted:   #718096;
  --dg-white:   #FFFFFF;
  --dg-rad:     14px;
  --dg-rad-lg:  22px;
  --dg-shadow:  0 4px 24px rgba(42,139,139,.12);
  --dg-shadow2: 0 16px 52px rgba(42,139,139,.2);
  --dg-font-h:  'Nunito', system-ui, sans-serif;
  --dg-font-b:  'Nunito', system-ui, sans-serif;
  --dg-font-s:  'Fraunces', Georgia, serif;
  --dg-ease:    cubic-bezier(.4,0,.2,1);
}
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: var(--dg-font-b); color: var(--dg-text); background: var(--dg-cream); overflow-x: hidden; }
img  { max-width: 100%; display: block; }
a    { color: inherit; text-decoration: none; }
.dg-wrap  { max-width: 1200px; margin: 0 auto; padding: 0 24px; }
.dg-sec   { padding: 96px 0; }
.dg-sec--alt  { background: var(--dg-sand); }
.dg-sec--teal { background: var(--dg-teal); color: var(--dg-white); }
.dg-sec--navy { background: var(--dg-navy); color: var(--dg-white); }
.dg-eyebrow {
  display: inline-block;
  font-size: .73rem; font-weight: 800;
  letter-spacing: .14em; text-transform: uppercase;
  color: var(--dg-teal);
  margin-bottom: 12px;
}
.dg-sec--teal .dg-eyebrow { color: rgba(255,255,255,.7); }
.dg-sec--navy .dg-eyebrow { color: var(--dg-coral2); }
.dg-h2 {
  font-family: var(--dg-font-h);
  font-size: clamp(1.9rem, 3.8vw, 3rem);
  font-weight: 800;
  line-height: 1.2;
  margin-bottom: 18px;
}
.dg-lead {
  font-size: 1.05rem; line-height: 1.75;
  color: var(--dg-muted);
  max-width: 620px;
}
.dg-sec--teal .dg-lead { color: rgba(255,255,255,.78); }
.dg-sec--navy .dg-lead { color: rgba(255,255,255,.65); }
.dg-center { text-align: center; }
.dg-center .dg-lead { margin: 0 auto; }

/* ════════════════════════════════
   NAVBAR
   ════════════════════════════════ */
.dg-nav {
  position: fixed; top: 0; left: 0; width: 100%; z-index: 1000;
  background: rgba(253,249,244,.97);
  backdrop-filter: blur(10px);
  border-bottom: 2px solid rgba(42,139,139,.12);
  transition: box-shadow .3s;
}
.dg-nav__inner {
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 24px; height: 70px; max-width: 1200px; margin: 0 auto;
}
.dg-nav__logo {
  font-family: var(--dg-font-h);
  font-size: 1.45rem; font-weight: 800;
  color: var(--dg-navy);
}
.dg-nav__logo .dg-paw { color: var(--dg-coral); }
.dg-nav__links { display: flex; gap: 28px; align-items: center; }
.dg-nav__links a {
  font-size: .88rem; font-weight: 700;
  color: var(--dg-text);
  transition: color .2s;
}
.dg-nav__links a:hover { color: var(--dg-teal); }
.dg-nav__cta {
  background: var(--dg-coral) !important;
  color: var(--dg-white) !important;
  padding: 10px 22px;
  border-radius: 50px;
  font-weight: 800 !important;
  transition: background .25s, transform .25s !important;
}
.dg-nav__cta:hover { background: var(--dg-coral2) !important; transform: translateY(-1px); }

/* ════════════════════════════════
   HERO
   ════════════════════════════════ */
.dg-hero {
  position: relative;
  height: 100vh; min-height: 680px;
  background: linear-gradient(135deg, #E8F8F8 0%, #D0EDED 50%, #F5EFE6 100%);
  overflow: hidden;
  display: flex; align-items: center;
  padding-top: 70px;
}

/* ── floating paw prints ── */
.dg-hero__paws { position: absolute; inset: 0; pointer-events: none; }
.dg-paw-print {
  position: absolute;
  opacity: .12;
  animation: dg-paw-drift 8s ease-in-out infinite;
}
@keyframes dg-paw-drift {
  0%, 100% { transform: translateY(0) rotate(0deg); }
  50%       { transform: translateY(-18px) rotate(12deg); }
}

/* ── CSS grooming salon scene ── */
.dg-hero__scene {
  position: absolute;
  right: 0; top: 0; bottom: 0;
  width: 52%;
  overflow: hidden;
}

/* wall */
.dg-scene__wall {
  position: absolute;
  top: 0; left: 0; right: 0; height: 65%;
  background: linear-gradient(180deg, #E8F5F5 0%, #D8EDED 100%);
}
/* wall tile border */
.dg-scene__wall::after {
  content: '';
  position: absolute;
  bottom: 0; left: 0; right: 0; height: 8px;
  background: repeating-linear-gradient(90deg, var(--dg-teal) 0px, var(--dg-teal) 20px, rgba(42,139,139,.3) 20px, rgba(42,139,139,.3) 22px);
}

/* floor */
.dg-scene__floor {
  position: absolute;
  bottom: 0; left: 0; right: 0; height: 35%;
  background: repeating-linear-gradient(
    0deg,
    #E8E0D8 0px, #E8E0D8 40px,
    #D8D0C8 40px, #D8D0C8 41px
  );
}

/* grooming table */
.dg-scene__table {
  position: absolute;
  bottom: 33%; left: 15%;
  width: 50%; height: 6%;
  background: linear-gradient(180deg, #8B6E3A 0%, #6B5020 100%);
  border-radius: 6px 6px 0 0;
  border: 2px solid rgba(0,0,0,.08);
}
/* table legs */
.dg-scene__table::before {
  content: '';
  position: absolute;
  bottom: -200%; left: 8%;
  width: 6%; height: 200%;
  background: #5A4020;
  box-shadow: 540% 0 0 #5A4020;
}

/* grooming arm */
.dg-scene__arm {
  position: absolute;
  bottom: 58%; left: 35%;
  width: 2%; height: 26%;
  background: linear-gradient(180deg, #B0B8C0 0%, #8090A0 100%);
  border-radius: 4px;
}
.dg-scene__arm::after {
  content: '';
  position: absolute;
  top: -10px; left: 50%; transform: translateX(-50%);
  width: 200%; height: 10px;
  background: #8090A0;
  border-radius: 10px;
}

/* dog on table */
.dg-scene__dog {
  position: absolute;
  bottom: 39%; left: 22%;
}
/* dog body */
.dg-scene__dog-body {
  position: relative;
  width: 90px; height: 52px;
  background: #E8D8C0;
  border-radius: 46px 46px 20px 20px;
}
/* dog head */
.dg-scene__dog-body::before {
  content: '';
  position: absolute;
  top: -32px; left: -8px;
  width: 48px; height: 40px;
  background: #E8D8C0;
  border-radius: 50% 50% 40% 40%;
}
/* dog ears */
.dg-scene__dog-body::after {
  content: '';
  position: absolute;
  top: -32px; left: -18px;
  width: 20px; height: 30px;
  background: #C8A880;
  border-radius: 50% 10% 50% 10%;
  box-shadow: 48px 0 0 #C8A880;
}
/* dog tail */
.dg-scene__dog-tail {
  position: absolute;
  bottom: 24px; right: -18px;
  width: 22px; height: 10px;
  background: #E8D8C0;
  border-radius: 10px;
  transform: rotate(30deg);
  transform-origin: left center;
  animation: dg-wag 0.8s ease-in-out infinite alternate;
}
@keyframes dg-wag {
  from { transform: rotate(20deg); }
  to   { transform: rotate(50deg); }
}
/* dog towel */
.dg-scene__dog-towel {
  position: absolute;
  top: -4px; left: 30px;
  width: 50px; height: 20px;
  background: var(--dg-teal);
  border-radius: 4px;
  opacity: .7;
}

/* groomer figure */
.dg-scene__groomer {
  position: absolute;
  bottom: 33%; left: 60%;
}
.dg-scene__groomer-body {
  position: relative;
  width: 48px; height: 90px;
  background: var(--dg-teal);
  border-radius: 6px 6px 0 0;
}
/* apron */
.dg-scene__groomer-body::before {
  content: '';
  position: absolute;
  top: 10px; left: 50%; transform: translateX(-50%);
  width: 36px; height: 70px;
  background: rgba(255,255,255,.25);
  border-radius: 4px;
}
/* groomer head */
.dg-scene__groomer-head {
  position: absolute;
  top: -48px; left: 50%; transform: translateX(-50%);
  width: 38px; height: 38px;
  background: #C8956A;
  border-radius: 50%;
}
/* groomer hair */
.dg-scene__groomer-head::before {
  content: '';
  position: absolute;
  top: -6px; left: 50%; transform: translateX(-50%);
  width: 40px; height: 20px;
  background: #2A1A0A;
  border-radius: 50% 50% 0 0;
}
/* groomer bun */
.dg-scene__groomer-head::after {
  content: '';
  position: absolute;
  top: -10px; right: -4px;
  width: 14px; height: 14px;
  background: #2A1A0A;
  border-radius: 50%;
}
/* groomer arm with scissors */
.dg-scene__groomer-arm {
  position: absolute;
  top: 20px; left: -22px;
  width: 22px; height: 8px;
  background: var(--dg-teal);
  border-radius: 4px;
  transform: rotate(-25deg);
}
.dg-scene__groomer-arm::before {
  content: '✂';
  position: absolute;
  left: -16px; top: -8px;
  font-size: 14px;
  color: #8090A0;
  transform: rotate(25deg) scaleX(-1);
}

/* shelf with products */
.dg-scene__products {
  position: absolute;
  top: 12%; right: 5%;
  width: 22%; height: 40%;
  background: rgba(255,255,255,.5);
  border: 2px solid rgba(42,139,139,.2);
  border-radius: 6px;
}
/* shelf board */
.dg-scene__products::before {
  content: '';
  position: absolute;
  left: 0; right: 0; top: 40%;
  height: 3px;
  background: rgba(42,139,139,.3);
  box-shadow: 0 calc(60% - 40%) 0 rgba(42,139,139,.3);
}

/* window */
.dg-scene__window {
  position: absolute;
  top: 8%; left: 5%;
  width: 26%; height: 42%;
  background: linear-gradient(180deg, #C0E8F0 0%, #A0D8E8 100%);
  border: 3px solid #A0C8D0;
  border-radius: 4px;
}
/* window cross */
.dg-scene__window::before {
  content: '';
  position: absolute;
  top: 0; left: 50%; width: 3px; bottom: 0;
  background: #A0C8D0;
}
.dg-scene__window::after {
  content: '';
  position: absolute;
  left: 0; top: 50%; height: 3px; right: 0;
  background: #A0C8D0;
}

/* paw print poster on wall */
.dg-scene__poster {
  position: absolute;
  top: 10%; left: 36%;
  width: 16%; height: 28%;
  background: var(--dg-white);
  border: 2px solid rgba(42,139,139,.2);
  border-radius: 4px;
  display: flex; align-items: center; justify-content: center;
  font-size: 2.2rem;
}

/* ── hero text ── */
.dg-hero__content {
  position: relative; z-index: 2;
  max-width: 540px;
  padding: 0 24px 0 60px;
}
.dg-hero__eyebrow {
  display: inline-flex; align-items: center; gap: 8px;
  font-size: .73rem; font-weight: 800;
  letter-spacing: .14em; text-transform: uppercase;
  color: var(--dg-teal);
  margin-bottom: 18px;
}
.dg-hero__eyebrow::before { content: '🐾'; }
.dg-hero__h1 {
  font-family: var(--dg-font-h);
  font-size: clamp(2.4rem, 4.5vw, 3.8rem);
  font-weight: 800;
  line-height: 1.15;
  color: var(--dg-navy);
  margin-bottom: 20px;
}
.dg-hero__h1 span { color: var(--dg-coral); }
.dg-hero__tag {
  font-size: 1.05rem; line-height: 1.75;
  color: var(--dg-muted);
  margin-bottom: 32px;
  max-width: 440px;
}
.dg-hero__pills {
  display: flex; flex-wrap: wrap; gap: 8px;
  margin-bottom: 32px;
}
.dg-hero__pill {
  padding: 6px 14px;
  background: rgba(42,139,139,.1);
  border: 1px solid rgba(42,139,139,.2);
  border-radius: 50px;
  font-size: .78rem; font-weight: 700;
  color: var(--dg-teal);
}
.dg-hero__actions { display: flex; gap: 14px; flex-wrap: wrap; }

/* ── buttons ── */
.dg-btn {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 14px 26px;
  border-radius: 50px;
  font-family: var(--dg-font-b);
  font-size: .9rem; font-weight: 800;
  cursor: pointer;
  transition: all .3s var(--dg-ease);
  border: none;
}
.dg-btn--coral { background: var(--dg-coral); color: var(--dg-white); }
.dg-btn--coral:hover { background: var(--dg-coral2); transform: translateY(-2px); box-shadow: 0 8px 24px rgba(232,112,74,.35); }
.dg-btn--teal { background: var(--dg-teal); color: var(--dg-white); }
.dg-btn--teal:hover  { background: var(--dg-teal2); transform: translateY(-2px); }
.dg-btn--ghost { background: transparent; border: 2px solid var(--dg-teal); color: var(--dg-teal); }
.dg-btn--ghost:hover { background: var(--dg-teal); color: var(--dg-white); }

/* ════════════════════════════════
   TRUST BAR
   ════════════════════════════════ */
.dg-trust {
  background: var(--dg-teal);
  padding: 20px 0;
}
.dg-trust__inner {
  display: flex; flex-wrap: wrap; justify-content: center;
  gap: 10px 36px;
  max-width: 1200px; margin: 0 auto; padding: 0 24px;
}
.dg-trust__item {
  display: flex; align-items: center; gap: 8px;
  font-size: .85rem; font-weight: 700;
  color: rgba(255,255,255,.9);
}
.dg-trust__item::before { content: attr(data-icon); font-size: 1rem; }

/* ════════════════════════════════
   SERVICES GRID
   ════════════════════════════════ */
.dg-services__grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px,1fr));
  gap: 24px;
  margin-top: 52px;
}
.dg-service {
  background: var(--dg-white);
  border-radius: var(--dg-rad-lg);
  padding: 36px 30px;
  box-shadow: var(--dg-shadow);
  transition: transform .3s var(--dg-ease), box-shadow .3s var(--dg-ease);
  border-bottom: 3px solid transparent;
  position: relative; overflow: hidden;
}
.dg-service::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0; height: 3px;
  background: linear-gradient(90deg, var(--dg-teal), var(--dg-coral));
  transform: scaleX(0);
  transition: transform .3s var(--dg-ease);
  transform-origin: left;
}
.dg-service:hover { transform: translateY(-6px); box-shadow: var(--dg-shadow2); }
.dg-service:hover::before { transform: scaleX(1); }
.dg-service__icon { font-size: 2.2rem; margin-bottom: 16px; display: block; }
.dg-service__top { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px; }
.dg-service__title { font-size: 1.15rem; font-weight: 800; color: var(--dg-navy); }
.dg-service__price { font-size: .85rem; font-weight: 700; color: var(--dg-teal); background: rgba(42,139,139,.1); padding: 4px 10px; border-radius: 20px; }
.dg-service__desc { font-size: .9rem; line-height: 1.7; color: var(--dg-muted); }

/* ════════════════════════════════
   BREEDS CLOUD
   ════════════════════════════════ */
.dg-breeds { display: flex; flex-wrap: wrap; justify-content: center; gap: 10px; margin-top: 40px; }
.dg-breed-tag {
  padding: 8px 18px;
  background: var(--dg-white);
  border: 2px solid rgba(42,139,139,.2);
  border-radius: 50px;
  font-size: .85rem; font-weight: 700;
  color: var(--dg-navy);
  transition: all .25s;
}
.dg-breed-tag:hover { background: var(--dg-teal); color: var(--dg-white); border-color: var(--dg-teal); }

/* ════════════════════════════════
   COUNTERS
   ════════════════════════════════ */
.dg-counters__grid {
  display: grid; grid-template-columns: repeat(4,1fr); gap: 2px;
}
.dg-counter {
  text-align: center; padding: 56px 20px;
  background: rgba(255,255,255,.08);
  border: 1px solid rgba(255,255,255,.1);
}
.dg-counter__num {
  font-family: var(--dg-font-h);
  font-size: clamp(2.4rem,5vw,3.8rem); font-weight: 800;
  color: var(--dg-white); display: block; line-height: 1;
  margin-bottom: 8px;
}
.dg-counter__label {
  font-size: .8rem; font-weight: 700;
  letter-spacing: .08em; text-transform: uppercase;
  color: rgba(255,255,255,.65);
}

/* ════════════════════════════════
   PRICING TABLE
   ════════════════════════════════ */
.dg-pricing { margin-top: 52px; border-radius: var(--dg-rad-lg); overflow: hidden; box-shadow: var(--dg-shadow); }
.dg-pricing__head {
  display: grid; grid-template-columns: 2fr 1fr 1fr;
  background: var(--dg-navy); color: var(--dg-white);
  padding: 18px 28px;
  font-size: .8rem; font-weight: 800; letter-spacing: .08em; text-transform: uppercase;
}
.dg-pricing__row {
  display: grid; grid-template-columns: 2fr 1fr 1fr;
  padding: 18px 28px;
  background: var(--dg-white);
  border-bottom: 1px solid rgba(42,139,139,.08);
  align-items: center;
  transition: background .2s;
}
.dg-pricing__row:last-child { border-bottom: none; }
.dg-pricing__row:hover { background: rgba(42,139,139,.04); }
.dg-pricing__size { font-weight: 800; color: var(--dg-navy); }
.dg-pricing__example { font-size: .78rem; color: var(--dg-muted); margin-top: 2px; }
.dg-pricing__price { font-weight: 800; color: var(--dg-teal); }

/* ════════════════════════════════
   TEAM
   ════════════════════════════════ */
.dg-team__grid {
  display: grid; grid-template-columns: repeat(4,1fr); gap: 24px; margin-top: 52px;
}
.dg-team-card {
  background: var(--dg-white);
  border-radius: var(--dg-rad-lg);
  padding: 32px 24px;
  box-shadow: var(--dg-shadow);
  text-align: center;
  transition: transform .3s, box-shadow .3s;
}
.dg-team-card:hover { transform: translateY(-6px); box-shadow: var(--dg-shadow2); }
/* CSS groomer avatar */
.dg-team-card__avatar {
  width: 90px; height: 90px;
  border-radius: 50%;
  margin: 0 auto 20px;
  position: relative;
  background: linear-gradient(135deg, var(--dg-teal) 0%, var(--dg-teal2) 100%);
  border: 3px solid rgba(42,139,139,.2);
}
.dg-team-card__avatar::before {
  content: '👩';
  position: absolute;
  top: 50%; left: 50%; transform: translate(-50%,-50%);
  font-size: 2.4rem;
  line-height: 1;
}
.dg-team-card:nth-child(3) .dg-team-card__avatar::before { content: '🧖'; }
.dg-team-card:nth-child(4) .dg-team-card__avatar::before { content: '👩‍🎨'; }
.dg-team-card__name { font-size: 1rem; font-weight: 800; color: var(--dg-navy); margin-bottom: 4px; }
.dg-team-card__title { font-size: .8rem; color: var(--dg-teal); font-weight: 700; margin-bottom: 10px; }
.dg-team-card__meta { font-size: .78rem; color: var(--dg-muted); line-height: 1.6; }
.dg-team-card__spec {
  display: inline-block; margin-top: 10px;
  padding: 4px 12px;
  background: rgba(42,139,139,.1);
  border-radius: 20px;
  font-size: .72rem; font-weight: 700; color: var(--dg-teal);
}

/* ════════════════════════════════
   TESTIMONIALS
   ════════════════════════════════ */
.dg-testimonials__grid {
  display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; margin-top: 52px;
}
.dg-testimonial {
  background: var(--dg-white);
  border-radius: var(--dg-rad-lg);
  padding: 36px 28px;
  box-shadow: var(--dg-shadow);
  position: relative;
  transition: transform .3s;
}
.dg-testimonial:hover { transform: translateY(-4px); }
.dg-testimonial::before {
  content: '"';
  position: absolute; top: 12px; left: 20px;
  font-family: var(--dg-font-s);
  font-size: 5rem; line-height: 1;
  color: rgba(42,139,139,.12);
  font-weight: 600;
}
.dg-testimonial__stars { display: flex; gap: 3px; margin-bottom: 16px; }
.dg-testimonial__stars span { color: var(--dg-coral); font-size: 1rem; }
.dg-testimonial__quote {
  font-size: .92rem; line-height: 1.75;
  color: var(--dg-text);
  margin-bottom: 20px;
  font-style: italic;
  position: relative; z-index: 1;
}
.dg-testimonial__author { display: flex; align-items: center; gap: 12px; }
.dg-testimonial__paw {
  width: 42px; height: 42px; border-radius: 50%;
  background: rgba(232,112,74,.12);
  display: flex; align-items: center; justify-content: center;
  font-size: 1.3rem; flex-shrink: 0;
}
.dg-testimonial__name { font-weight: 800; font-size: .88rem; color: var(--dg-navy); }
.dg-testimonial__breed { font-size: .75rem; color: var(--dg-muted); margin-top: 2px; }

/* ════════════════════════════════
   BOOKING FORM
   ════════════════════════════════ */
.dg-booking { background: var(--dg-sand); }
.dg-booking__grid {
  display: grid; grid-template-columns: 1fr 1.3fr; gap: 64px; align-items: start;
}
.dg-booking__info h3 {
  font-family: var(--dg-font-h);
  font-size: 1.7rem; font-weight: 800;
  color: var(--dg-navy); margin-bottom: 16px;
}
.dg-booking__info p { font-size: .95rem; line-height: 1.75; color: var(--dg-muted); margin-bottom: 24px; }
.dg-booking__why { list-style: none; }
.dg-booking__why li {
  padding: 10px 0;
  font-size: .88rem; color: var(--dg-text);
  display: flex; align-items: flex-start; gap: 10px;
  border-bottom: 1px solid rgba(42,139,139,.1);
}
.dg-booking__why li:last-child { border-bottom: none; }
.dg-booking__why li::before { content: '🐾'; flex-shrink: 0; }
.dg-booking__contact {
  margin-top: 28px; padding: 20px 24px;
  background: var(--dg-white);
  border-radius: var(--dg-rad);
  box-shadow: var(--dg-shadow);
}
.dg-booking__contact div { font-size: .85rem; color: var(--dg-muted); line-height: 2.1; }
.dg-form {
  background: var(--dg-white);
  border-radius: var(--dg-rad-lg);
  padding: 40px;
  box-shadow: var(--dg-shadow2);
}
.dg-form__row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.dg-form__group { margin-bottom: 18px; }
.dg-form__group label {
  display: block;
  font-size: .75rem; font-weight: 800;
  letter-spacing: .06em; text-transform: uppercase;
  color: var(--dg-navy); margin-bottom: 7px;
}
.dg-form__group input,
.dg-form__group select,
.dg-form__group textarea {
  width: 100%;
  border: 2px solid rgba(42,139,139,.15);
  border-radius: 10px;
  padding: 11px 14px;
  font-family: var(--dg-font-b);
  font-size: .9rem; color: var(--dg-text);
  outline: none;
  background: var(--dg-cream);
  transition: border-color .25s, background .25s;
}
.dg-form__group input:focus,
.dg-form__group select:focus,
.dg-form__group textarea:focus {
  border-color: var(--dg-teal);
  background: var(--dg-white);
}
.dg-form__group textarea { resize: vertical; min-height: 90px; }
.dg-form__submit {
  width: 100%; padding: 16px;
  background: var(--dg-coral);
  color: var(--dg-white); border: none;
  border-radius: 50px;
  font-family: var(--dg-font-b);
  font-size: 1rem; font-weight: 800;
  cursor: pointer; letter-spacing: .02em;
  transition: all .3s var(--dg-ease);
  box-shadow: 0 4px 18px rgba(232,112,74,.3);
}
.dg-form__submit:hover { background: var(--dg-coral2); transform: translateY(-2px); box-shadow: 0 10px 28px rgba(232,112,74,.4); }

/* ════════════════════════════════
   FOOTER
   ════════════════════════════════ */
.dg-footer {
  background: var(--dg-navy);
  padding: 28px 0;
  border-top: 3px solid var(--dg-teal);
}
.dg-footer__inner {
  display: flex; align-items: center;
  justify-content: space-between; flex-wrap: wrap;
  gap: 14px;
  max-width: 1200px; margin: 0 auto; padding: 0 24px;
}
.dg-footer__logo { font-size: 1.1rem; font-weight: 800; color: var(--dg-white); }
.dg-footer__logo .dg-paw { color: var(--dg-coral); }
.dg-footer__copy { font-size: .78rem; color: rgba(255,255,255,.4); }
.dg-footer__links { display: flex; gap: 20px; }
.dg-footer__links a { font-size: .78rem; color: rgba(255,255,255,.5); transition: color .2s; }
.dg-footer__links a:hover { color: var(--dg-coral2); }

/* ════════════════════════════════
   ANIMATION
   ════════════════════════════════ */
.dg-reveal { opacity: 0; transform: translateY(28px); transition: opacity .65s var(--dg-ease), transform .65s var(--dg-ease); }
.dg-reveal.is-visible { opacity: 1; transform: translateY(0); }

/* ════════════════════════════════
   RESPONSIVE
   ════════════════════════════════ */
@media (max-width: 1024px) {
  .dg-team__grid { grid-template-columns: repeat(2,1fr); }
  .dg-booking__grid { grid-template-columns: 1fr; gap: 40px; }
}
@media (max-width: 768px) {
  .dg-sec { padding: 68px 0; }
  .dg-hero__scene { display: none; }
  .dg-hero__content { padding: 0 24px; max-width: 100%; }
  .dg-nav__links { display: none; }
  .dg-counters__grid { grid-template-columns: repeat(2,1fr); }
  .dg-testimonials__grid { grid-template-columns: 1fr; }
  .dg-form__row { grid-template-columns: 1fr; }
}
@media (max-width: 480px) {
  .dg-counters__grid { grid-template-columns: 1fr 1fr; }
  .dg-team__grid { grid-template-columns: 1fr 1fr; }
}
</style>
<?php get_header(); ?>
<div class="dg-page">
>

<!-- ══════════════════════════════════════════
     NAVBAR
     ══════════════════════════════════════════ -->
<nav class="dg-nav" aria-label="Main navigation">
  <div class="dg-nav__inner">
    <a href="<?php echo esc_url( home_url('/') ); ?>" class="dg-nav__logo">
      Pawfect <span class="dg-paw">🐾</span> Grooming
    </a>
    <div class="dg-nav__links">
      <a href="#services">Services</a>
      <a href="#pricing">Pricing</a>
      <a href="#team">Our Team</a>
      <a href="#booking" class="dg-nav__cta">Book a Groom</a>
    </div>
  </div>
</nav>

<!-- ══════════════════════════════════════════
     HERO
     ══════════════════════════════════════════ -->
<section class="dg-hero" aria-label="Hero">

  <!-- floating paw prints -->
  <div class="dg-hero__paws" aria-hidden="true">
    <?php foreach ( $paw_pos as $i => $pos ) :
      $sz    = $paw_sizes[ $i % count($paw_sizes) ];
      $delay = round( $i * 0.6 % 5, 1 );
      $dur   = round( 6 + $i * 0.4 % 3, 1 );
      $col   = ( $i % 2 === 0 ) ? 'rgba(42,139,139,1)' : 'rgba(232,112,74,1)';
    ?>
    <svg class="dg-paw-print"
         style="top:<?php echo esc_attr($pos[0]); ?>;<?php echo esc_attr($pos[1]); ?>;animation-delay:<?php echo esc_attr($delay); ?>s;animation-duration:<?php echo esc_attr($dur); ?>s;"
         width="<?php echo esc_attr($sz); ?>" height="<?php echo esc_attr($sz); ?>" viewBox="0 0 40 40" fill="<?php echo esc_attr($col); ?>" aria-hidden="true">
      <!-- main pad -->
      <ellipse cx="20" cy="28" rx="9" ry="7"/>
      <!-- toe pads -->
      <ellipse cx="11" cy="18" rx="4" ry="5"/>
      <ellipse cx="20" cy="14" rx="4" ry="5"/>
      <ellipse cx="29" cy="18" rx="4" ry="5"/>
      <ellipse cx="9"  cy="27" rx="3" ry="3.5"/>
    </svg>
    <?php endforeach; ?>
  </div>

  <!-- CSS grooming salon -->
  <div class="dg-hero__scene" aria-hidden="true">
    <div class="dg-scene__wall"></div>
    <div class="dg-scene__window"></div>
    <div class="dg-scene__poster">🐾</div>
    <div class="dg-scene__products">
      <?php
      $prod_cols = ['#2A8B8B','#E8704A','#F5EFE6','#1A2F4A','#4AABAB','#F09060'];
      for ($p = 0; $p < 6; $p++) :
        $ph = 30 + rand(0,20);
        $pl = 6 + $p * 16;
        $pc = $prod_cols[$p % count($prod_cols)];
        $pt = ($p < 3) ? 35 : 62;
      ?>
      <div style="position:absolute;top:<?php echo esc_attr($pt); ?>%;left:<?php echo esc_attr($pl); ?>px;width:12px;height:<?php echo esc_attr($ph); ?>px;background:<?php echo esc_attr($pc); ?>;border-radius:3px 3px 0 0;"></div>
      <?php endfor; ?>
    </div>
    <div class="dg-scene__floor"></div>
    <div class="dg-scene__table"></div>
    <div class="dg-scene__arm"></div>
    <div class="dg-scene__dog">
      <div class="dg-scene__dog-body">
        <div class="dg-scene__dog-towel"></div>
        <div class="dg-scene__dog-tail"></div>
      </div>
    </div>
    <div class="dg-scene__groomer">
      <div class="dg-scene__groomer-body">
        <div class="dg-scene__groomer-head"></div>
        <div class="dg-scene__groomer-arm"></div>
      </div>
    </div>
  </div>

  <!-- hero text -->
  <div class="dg-hero__content">
    <div class="dg-hero__eyebrow">Award-Winning Dog Grooming · Chelsea, London</div>
    <h1 class="dg-hero__h1">
      Your Dog Deserves<br>
      to Look <span>Pawfect</span>
    </h1>
    <p class="dg-hero__tag">
      Expert grooming with a gentle touch. Every session is calm, personalised,
      and designed to leave your dog looking and feeling their absolute best.
    </p>
    <div class="dg-hero__pills">
      <span class="dg-hero__pill">All Breeds Welcome</span>
      <span class="dg-hero__pill">Anxiety-Friendly</span>
      <span class="dg-hero__pill">Breed-Certified Groomers</span>
      <span class="dg-hero__pill">Progress Photos</span>
    </div>
    <div class="dg-hero__actions">
      <a href="#booking" class="dg-btn dg-btn--coral">Book a Groom 🐾</a>
      <a href="#services" class="dg-btn dg-btn--ghost">See Services</a>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════
     TRUST BAR
     ══════════════════════════════════════════ -->
<div class="dg-trust" aria-label="Trust indicators">
  <div class="dg-trust__inner">
    <span class="dg-trust__item" data-icon="🐾">City &amp; Guilds Certified</span>
    <span class="dg-trust__item" data-icon="🐾">4.9★ on Google (340+ reviews)</span>
    <span class="dg-trust__item" data-icon="🐾">10,000+ Happy Dogs</span>
    <span class="dg-trust__item" data-icon="🐾">Dog-Safe Products Only</span>
    <span class="dg-trust__item" data-icon="🐾">Progress Photos Sent</span>
  </div>
</div>

<!-- ══════════════════════════════════════════
     SERVICES
     ══════════════════════════════════════════ -->
<section id="services" class="dg-sec">
  <div class="dg-wrap">
    <div class="dg-center">
      <span class="dg-eyebrow">What We Offer</span>
      <h2 class="dg-h2">Grooming Services Tailored<br>to Every Dog &amp; Breed</h2>
      <p class="dg-lead">
        From a quick nail trim to a full luxury groom, every service is delivered with
        patience, expertise, and a whole lot of love.
      </p>
    </div>
    <div class="dg-services__grid">
      <?php foreach ( $services as $i => $svc ) : ?>
      <div class="dg-service dg-reveal" style="transition-delay:<?php echo esc_attr( $i * 80 ); ?>ms;">
        <span class="dg-service__icon" aria-hidden="true"><?php echo $svc['icon']; ?></span>
        <div class="dg-service__top">
          <h3 class="dg-service__title"><?php echo esc_html( $svc['title'] ); ?></h3>
          <span class="dg-service__price"><?php echo esc_html( $svc['price'] ); ?></span>
        </div>
        <p class="dg-service__desc"><?php echo esc_html( $svc['desc'] ); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════
     BREEDS WE LOVE
     ══════════════════════════════════════════ -->
<section class="dg-sec dg-sec--alt" id="breeds">
  <div class="dg-wrap">
    <div class="dg-center">
      <span class="dg-eyebrow">All Breeds Welcome</span>
      <h2 class="dg-h2">We've Groomed Them All 🐕</h2>
      <p class="dg-lead">
        From teacup Chihuahuas to giant Newfoundlands — our groomers are breed-certified
        specialists who know exactly how to handle every coat type and temperament.
      </p>
      <div class="dg-breeds">
        <?php foreach ( $breeds as $breed ) : ?>
        <span class="dg-breed-tag"><?php echo esc_html( $breed ); ?></span>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════
     COUNTERS
     ══════════════════════════════════════════ -->
<section class="dg-sec--teal" aria-label="Stats" style="padding:0;">
  <div class="dg-counters__grid">
    <div class="dg-counter dg-reveal">
      <span class="dg-counter__num" data-target="12" data-suffix="yrs">0</span>
      <span class="dg-counter__label">Years in Business</span>
    </div>
    <div class="dg-counter dg-reveal" style="transition-delay:100ms;">
      <span class="dg-counter__num" data-target="10000" data-suffix="+">0</span>
      <span class="dg-counter__label">Dogs Groomed</span>
    </div>
    <div class="dg-counter dg-reveal" style="transition-delay:200ms;">
      <span class="dg-counter__num" data-target="4.9" data-suffix="★" data-float="1">0</span>
      <span class="dg-counter__label">Average Rating</span>
    </div>
    <div class="dg-counter dg-reveal" style="transition-delay:300ms;">
      <span class="dg-counter__num" data-target="98" data-suffix="%">0</span>
      <span class="dg-counter__label">Clients Return</span>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════
     PRICING TABLE
     ══════════════════════════════════════════ -->
<section id="pricing" class="dg-sec">
  <div class="dg-wrap">
    <div class="dg-center">
      <span class="dg-eyebrow">Transparent Pricing</span>
      <h2 class="dg-h2">Simple Prices. No Surprises.</h2>
      <p class="dg-lead">
        Our pricing is based on your dog's size and coat type. Quotes confirmed at booking.
        All prices include shampoo, conditioning, and finish.
      </p>
    </div>
    <div class="dg-pricing dg-reveal">
      <div class="dg-pricing__head">
        <div>Dog Size</div>
        <div>Full Groom</div>
        <div>Bath &amp; Dry</div>
      </div>
      <?php foreach ( $sizes as $row ) : ?>
      <div class="dg-pricing__row">
        <div>
          <div class="dg-pricing__size"><?php echo esc_html( $row['label'] ); ?></div>
          <div class="dg-pricing__example"><?php echo esc_html( $row['example'] ); ?></div>
        </div>
        <div class="dg-pricing__price"><?php echo esc_html( $row['full'] ); ?></div>
        <div class="dg-pricing__price"><?php echo esc_html( $row['bath'] ); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <p style="text-align:center; margin-top:20px; font-size:.82rem; color:var(--dg-muted);">
      Prices may vary for extremely matted, double-coated, or difficult-to-handle dogs. Quotes given at consultation.
    </p>
  </div>
</section>

<!-- ══════════════════════════════════════════
     TEAM
     ══════════════════════════════════════════ -->
<section id="team" class="dg-sec dg-sec--alt">
  <div class="dg-wrap">
    <div class="dg-center">
      <span class="dg-eyebrow">Meet the Team</span>
      <h2 class="dg-h2">Groomers Who Truly<br>Love Their Work 🐾</h2>
      <p class="dg-lead">
        Every member of our team is City &amp; Guilds certified, DBS checked, and genuinely
        passionate about animals. Your dog is in the best possible hands.
      </p>
    </div>
    <div class="dg-team__grid">
      <?php foreach ( $team as $i => $member ) : ?>
      <div class="dg-team-card dg-reveal" style="transition-delay:<?php echo esc_attr( $i * 80 ); ?>ms;">
        <div class="dg-team-card__avatar" aria-hidden="true"></div>
        <div class="dg-team-card__name"><?php echo esc_html( $member['name'] ); ?></div>
        <div class="dg-team-card__title"><?php echo esc_html( $member['title'] ); ?></div>
        <div class="dg-team-card__meta"><?php echo esc_html( $member['years'] ); ?> experience</div>
        <span class="dg-team-card__spec"><?php echo esc_html( $member['spec'] ); ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════
     TESTIMONIALS
     ══════════════════════════════════════════ -->
<section id="testimonials" class="dg-sec">
  <div class="dg-wrap">
    <div class="dg-center">
      <span class="dg-eyebrow">Happy Clients</span>
      <h2 class="dg-h2">Tails Are Wagging 🐕</h2>
      <p class="dg-lead">
        Don't just take our word for it — hear what London's dog owners say about their
        Pawfect experience.
      </p>
    </div>
    <div class="dg-testimonials__grid">
      <?php foreach ( $testimonials as $t ) : ?>
      <div class="dg-testimonial dg-reveal">
        <div class="dg-testimonial__stars">
          <?php for ($s = 0; $s < $t['stars']; $s++) echo '<span>★</span>'; ?>
        </div>
        <blockquote class="dg-testimonial__quote">
          <?php echo esc_html( $t['quote'] ); ?>
        </blockquote>
        <div class="dg-testimonial__author">
          <div class="dg-testimonial__paw" aria-hidden="true">🐾</div>
          <div>
            <div class="dg-testimonial__name"><?php echo esc_html( $t['name'] ); ?></div>
            <div class="dg-testimonial__breed"><?php echo esc_html( $t['breed'] ); ?></div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════
     BOOKING FORM
     ══════════════════════════════════════════ -->
<section id="booking" class="dg-sec dg-booking">
  <div class="dg-wrap">
    <div class="dg-booking__grid">
      <div class="dg-booking__info">
        <span class="dg-eyebrow">Book a Session</span>
        <h3>Ready to Book Your Dog's Next Groom?</h3>
        <p>Fill in the form and we'll be in touch within one business day to confirm your appointment and advise on the best service for your dog's breed and coat.</p>
        <ul class="dg-booking__why">
          <li>We cater to nervous and first-time dogs</li>
          <li>All-natural, pet-safe shampoos and products</li>
          <li>Progress photos sent during the groom</li>
          <li>No cage drying — always hand dried</li>
          <li>Full after-care advice on every visit</li>
        </ul>
        <div class="dg-booking__contact">
          <div>
            📞 <?php echo esc_html( $phone ); ?><br>
            ✉️ <?php echo esc_html( $email ); ?><br>
            📍 <?php echo esc_html( $addr ); ?><br>
            🕘 Mon–Sat 9am–6pm
          </div>
        </div>
      </div>

      <div class="dg-form">
        <form method="post" action="" novalidate>
          <?php wp_nonce_field( 'tf_dg_booking', 'tf_dg_nonce' ); ?>

          <div class="dg-form__row">
            <div class="dg-form__group">
              <label for="dg_owner">Your Name</label>
              <input type="text" id="dg_owner" name="dg_owner" placeholder="Jane Smith" required>
            </div>
            <div class="dg-form__group">
              <label for="dg_dog">Dog's Name</label>
              <input type="text" id="dg_dog" name="dg_dog" placeholder="Bertie" required>
            </div>
          </div>

          <div class="dg-form__row">
            <div class="dg-form__group">
              <label for="dg_email">Email Address</label>
              <input type="email" id="dg_email" name="dg_email" placeholder="you@email.com" required>
            </div>
            <div class="dg-form__group">
              <label for="dg_phone">Phone Number</label>
              <input type="tel" id="dg_phone" name="dg_phone" placeholder="+44 7700 000000">
            </div>
          </div>

          <div class="dg-form__row">
            <div class="dg-form__group">
              <label for="dg_breed">Dog Breed</label>
              <input type="text" id="dg_breed" name="dg_breed" placeholder="Cavapoo, Labrador…">
            </div>
            <div class="dg-form__group">
              <label for="dg_size">Dog Size</label>
              <select id="dg_size" name="dg_size">
                <option value="">Select size…</option>
                <option value="xs">XS / Toy (under 5kg)</option>
                <option value="sm">Small (5–10kg)</option>
                <option value="md">Medium (10–20kg)</option>
                <option value="lg">Large (20–35kg)</option>
                <option value="xl">XL / Giant (35kg+)</option>
              </select>
            </div>
          </div>

          <div class="dg-form__group">
            <label for="dg_service">Service Required</label>
            <select id="dg_service" name="dg_service">
              <option value="">Select a service…</option>
              <option value="full">Full Groom</option>
              <option value="bath">Bath &amp; Dry</option>
              <option value="puppy">Puppy First Groom</option>
              <option value="nails">Nail Trim &amp; File</option>
              <option value="deshed">De-Shedding Treatment</option>
              <option value="spa">Spa Add-Ons</option>
            </select>
          </div>

          <div class="dg-form__group">
            <label for="dg_notes">Anything we should know? (anxiety, health issues, last groom)</label>
            <textarea id="dg_notes" name="dg_notes" placeholder="e.g. Bertie is nervous around clippers, or has sensitive skin…"></textarea>
          </div>

          <button type="submit" name="tf_dg_submit" class="dg-form__submit">
            Book My Dog's Groom 🐾
          </button>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════
     FOOTER
     ══════════════════════════════════════════ -->
<footer class="dg-footer" role="contentinfo">
  <div class="dg-footer__inner">
    <div class="dg-footer__logo">Pawfect <span class="dg-paw">🐾</span> Grooming</div>
    <p class="dg-footer__copy">
      &copy; <?php echo esc_html( date('Y') ); ?> <?php bloginfo('name'); ?>. Premium Dog Grooming, London. All rights reserved.
    </p>
    <nav class="dg-footer__links" aria-label="Footer navigation">
      <a href="#">Privacy</a>
      <a href="#">Terms</a>
      <a href="#booking">Contact</a>
    </nav>
  </div>
</footer>

<!-- ══════════════════════════════════════════
     JAVASCRIPT
     ══════════════════════════════════════════ -->
<script>
(function () {
  'use strict';

  const easeOut = t => 1 - Math.pow(1 - t, 3);

  function animateCounter(el) {
    const target  = parseFloat(el.dataset.target);
    const suffix  = el.dataset.suffix  || '';
    const isFloat = el.dataset.float   === '1';
    if (isNaN(target)) return;
    const dur = 1800; let start = null;
    (function tick(ts) {
      if (!start) start = ts;
      const p = Math.min((ts - start) / dur, 1);
      const v = easeOut(p) * target;
      el.textContent = isFloat ? v.toFixed(1) + suffix : Math.round(v) + suffix;
      if (p < 1) requestAnimationFrame(tick);
    })(performance.now());
  }

  const io = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (!entry.isIntersecting) return;
      entry.target.classList.add('is-visible');
      entry.target.querySelectorAll('[data-target]').forEach(animateCounter);
      if (entry.target.dataset && entry.target.dataset.target) animateCounter(entry.target);
      io.unobserve(entry.target);
    });
  }, { threshold: 0.15 });

  document.querySelectorAll('.dg-reveal, .dg-counter__num[data-target]')
    .forEach(function (el) { io.observe(el); });

  /* smooth scroll */
  document.querySelectorAll('a[href^="#"]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      const t = document.querySelector(this.getAttribute('href'));
      if (!t) return;
      e.preventDefault();
      window.scrollTo({ top: t.getBoundingClientRect().top + window.pageYOffset - 78, behavior: 'smooth' });
    });
  });

  /* navbar shadow */
  const nav = document.querySelector('.dg-nav');
  window.addEventListener('scroll', function () {
    nav.style.boxShadow = window.scrollY > 40 ? '0 4px 28px rgba(42,139,139,.15)' : 'none';
  }, { passive: true });

  /* stagger breed tags */
  document.querySelectorAll('.dg-breed-tag').forEach(function (tag, i) {
    tag.style.transitionDelay = (i * 30) + 'ms';
    tag.style.transition = 'all .25s';
  });

  /* form validation */
  const form = document.querySelector('.dg-form form');
  if (form) {
    form.addEventListener('submit', function (e) {
      const em = form.querySelector('#dg_email');
      if (em && !em.value.includes('@')) {
        e.preventDefault();
        em.focus();
        em.style.borderColor = '#e74c3c';
        setTimeout(function () { em.style.borderColor = ''; }, 2000);
      }
    });
  }

})();
</script>

</body>
</html>
</div><!-- .dg-page -->
<?php get_footer(); ?>
