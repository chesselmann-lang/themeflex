<?php
/**
 * Template Name: Dog Trainer
 * Description: Premium dog trainer / canine behaviourist homepage template
 *
 * @package ThemeFlex
 */

// ── Deterministic randomness ────────────────────────────────────────────────
srand( crc32( get_the_permalink() ) );

// ── Trainer data ────────────────────────────────────────────────────────────
$trainer = [
    'name'        => 'Marcus Reid',
    'title'       => 'CCPDT-KA Certified Dog Trainer & Canine Behaviourist',
    'location'    => 'Brighton & East Sussex · Home Visits & Online',
    'tagline'     => 'Transforming Dogs, Empowering Owners',
    'bio'         => 'With 15 years of hands-on experience, Marcus has helped over 3,200 dogs and their families build confident, joyful relationships. Holding CCPDT-KA certification and a BSc in Animal Behaviour, he uses exclusively force-free, science-based methods that create lasting change without fear or punishment.',
    'bio2'        => 'From boisterous puppies to reactive adults, Marcus tailors every programme to the individual dog — working with their instincts, not against them. His "Calm, Connected, Confident" methodology is now taught at six UK rescue centres.',
    'years'       => 15,
    'dogs'        => 3200,
    'rating'      => 4.9,
    'success'     => 98,
];

// ── Services ─────────────────────────────────────────────────────────────────
$services = [
    [ 'icon' => '🐶', 'title' => 'Puppy Foundation',    'desc' => 'Essential life skills for dogs under 6 months: sit, stay, recall, crate & toilet training.' ],
    [ 'icon' => '🎓', 'title' => 'Basic Obedience',     'desc' => 'Six core commands taught with positive reinforcement — perfect for adolescent and adult dogs.' ],
    [ 'icon' => '🏆', 'title' => 'Advanced Skills',     'desc' => 'Off-lead reliability, distance commands, distraction proofing and trick training for confident dogs.' ],
    [ 'icon' => '⚡', 'title' => 'Reactive Dog',        'desc' => 'Counter-conditioning & desensitisation programmes for dogs that lunge, bark or overreact on lead.' ],
    [ 'icon' => '🔔', 'title' => 'Recall Mastery',      'desc' => 'Build a bombproof recall in any environment — even around squirrels, dogs and BBQs.' ],
    [ 'icon' => '🚶', 'title' => 'Loose-Lead Walking',  'desc' => 'Stop the pulling! Enjoyable, relaxed walks for both ends of the lead.' ],
    [ 'icon' => '🏠', 'title' => 'Separation Anxiety',  'desc' => 'Structured desensitisation protocol to help dogs feel safe and calm when alone.' ],
    [ 'icon' => '🧠', 'title' => 'Behaviour Consult',   'desc' => 'Full 90-min assessment plus written action plan for complex behaviour challenges.' ],
];

// ── Packages ─────────────────────────────────────────────────────────────────
$packages = [
    [
        'name'     => 'Puppy Start',
        'price'    => '£295',
        'period'   => '6 weeks',
        'colour'   => 'sky',
        'features' => [
            '6 × 45-min sessions',
            'Puppy-specific curriculum',
            'Toilet & crate training guide',
            'Between-session support',
            'Puppy progress report',
        ],
        'featured' => false,
    ],
    [
        'name'     => 'Canine Excellence',
        'price'    => '£495',
        'period'   => '8 weeks',
        'colour'   => 'green',
        'features' => [
            '8 × 60-min sessions',
            'Full obedience curriculum',
            'Reactive dog sub-programme',
            'WhatsApp video feedback',
            'Home visit + 2 public training walks',
            'Written training plan',
            'Lifetime community access',
        ],
        'featured' => true,
    ],
    [
        'name'     => 'Behaviour SOS',
        'price'    => '£750',
        'period'   => '12 weeks',
        'colour'   => 'brown',
        'features' => [
            '90-min behaviour assessment',
            '10 × 60-min follow-up sessions',
            'Full written behaviour plan',
            'Vet liaison letter if needed',
            'Family coaching session',
            'Unlimited email support',
            'Follow-up review at 6 months',
        ],
        'featured' => false,
    ],
];

// ── Process steps ─────────────────────────────────────────────────────────────
$steps = [
    [ 'num' => '01', 'title' => 'Free Discovery Call',    'desc' => '15 minutes to discuss your dog, your goals and which programme fits best.' ],
    [ 'num' => '02', 'title' => 'Behaviour Assessment',   'desc' => 'First session evaluates your dog\'s temperament, triggers and learning style.' ],
    [ 'num' => '03', 'title' => 'Custom Training Plan',   'desc' => 'A written, week-by-week programme designed for your dog specifically.' ],
    [ 'num' => '04', 'title' => 'Consistent Sessions',    'desc' => 'Regular sessions at home, in the park or online — wherever works for you.' ],
    [ 'num' => '05', 'title' => 'Graduate & Maintain',    'desc' => 'Celebrate your dog\'s progress and join the alumni community for ongoing support.' ],
];

// ── FAQs ─────────────────────────────────────────────────────────────────────
$faqs = [
    [
        'q' => 'What training methods do you use?',
        'a' => 'Marcus uses exclusively force-free, positive reinforcement methods aligned with LIMA (Least Intrusive, Minimally Aversive) principles. No choke chains, prong collars or punishment-based techniques.',
    ],
    [
        'q' => 'What age can my puppy start training?',
        'a' => 'The sooner the better! Puppies as young as 8 weeks can begin learning. The Puppy Foundation programme is ideal for dogs up to 6 months and we can work around vaccination schedules.',
    ],
    [
        'q' => 'Do you work with all breeds?',
        'a' => 'Yes — from Chihuahuas to Great Danes, terriers to spaniels. Breed tendencies are factored into the training plan but every dog is assessed as an individual.',
    ],
    [
        'q' => 'Can training help my reactive dog?',
        'a' => 'Absolutely. Reactivity responds very well to counter-conditioning when done consistently. Most reactive dogs show significant improvement within 4–6 weeks of the programme.',
    ],
    [
        'q' => 'Do you offer online sessions?',
        'a' => 'Yes, all programmes are available fully online or as a hybrid. Video sessions are excellent for training inside the home and reviewing progress footage.',
    ],
    [
        'q' => 'What results can I realistically expect?',
        'a' => '98% of clients report meaningful improvement by the end of their programme. Dogs learn at their own pace and continued daily practice between sessions is key to lasting results.',
    ],
];

// ── Paw print positions ──────────────────────────────────────────────────────
$paws = [];
for ( $i = 0; $i < 16; $i++ ) {
    $paws[] = [
        'top'   => rand( 10, 85 ),
        'left'  => rand( 5, 92 ),
        'rot'   => rand( -40, 40 ),
        'delay' => round( $i * 0.35, 2 ),
        'size'  => rand( 14, 28 ),
        'op'    => round( rand( 10, 30 ) / 100, 2 ),
    ];
}

// ── Training cones ────────────────────────────────────────────────────────────
$cones = [ 20, 35, 50, 65, 80 ];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════════════════════════
   DOG TRAINER TEMPLATE  —  namespace: --dg-*
   ═══════════════════════════════════════════════════════════════════════════ */
:root {
  --dg-green:  #2E7D32;
  --dg-sky:    #1E88E5;
  --dg-tan:    #D4A574;
  --dg-brown:  #4A2C17;
  --dg-yellow: #FFC107;
  --dg-cream:  #FAF8F3;
  --dg-slate:  #2D3A2E;
  --dg-mid:    #5C6E5D;
  --dg-light:  #EEF5EE;
  --dg-shadow: rgba(46,125,50,.14);
  --dg-r:      14px;
  --dg-ff:     'Nunito', sans-serif;
  --dg-ff2:    'Roboto', sans-serif;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body.dg-page{font-family:var(--dg-ff2);color:var(--dg-slate);background:var(--dg-cream);line-height:1.7}
img{max-width:100%;display:block}
a{color:inherit;text-decoration:none}
.dg-page h1,.dg-page h2,.dg-page h3,.dg-page h4{font-family:var(--dg-ff);font-weight:800;line-height:1.25}

/* ── LAYOUT ── */
.dg-wrap{max-width:1180px;margin:0 auto;padding:0 24px}
.dg-section{padding:96px 0}
.dg-section--alt{background:#fff}
.dg-section--dark{background:var(--dg-slate);color:#fff}
.dg-section--light{background:var(--dg-light)}
.dg-tag{display:inline-block;font-family:var(--dg-ff);font-size:.75rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--dg-green);background:rgba(46,125,50,.1);padding:6px 16px;border-radius:99px;margin-bottom:18px}
.dg-tag--sky{color:var(--dg-sky);background:rgba(30,136,229,.1)}

/* ── HERO ── */
.dg-hero{position:relative;min-height:100vh;display:flex;align-items:center;overflow:hidden;background:linear-gradient(160deg,#0a1a0c 0%,#1a3a1c 40%,#0d2a10 100%)}
.dg-hero::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse 60% 50% at 50% 80%,rgba(46,125,50,.25) 0%,transparent 70%)}

/* sky gradient */
.dg-sky-bg{position:absolute;top:0;left:0;right:0;height:45%;background:linear-gradient(180deg,#0a1520 0%,#1a3a4a 60%,transparent 100%);z-index:0}
.dg-sun{position:absolute;top:6%;left:50%;transform:translateX(-50%);width:90px;height:90px;background:radial-gradient(circle,#FFF176 30%,#FFC107 60%,transparent 80%);border-radius:50%;opacity:.7;animation:dg-sun-glow 4s ease-in-out infinite alternate}
@keyframes dg-sun-glow{from{box-shadow:0 0 30px 10px rgba(255,193,7,.4)}to{box-shadow:0 0 60px 25px rgba(255,193,7,.6)}}

/* ground / grass */
.dg-ground{position:absolute;bottom:0;left:0;right:0;height:42%;z-index:1}
.dg-grass{position:absolute;bottom:0;left:0;right:0;height:100%;background:linear-gradient(180deg,#2E7D32 0%,#1B5E20 100%);border-radius:80% 80% 0 0 / 40px 40px 0 0}
.dg-grass::before{content:'';position:absolute;top:-12px;left:0;right:0;height:24px;background:repeating-linear-gradient(90deg,#388E3C 0,#388E3C 8px,#2E7D32 8px,#2E7D32 16px)}
.dg-path{position:absolute;bottom:0;left:50%;transform:translateX(-50%);width:120px;height:100%;background:linear-gradient(180deg,#8D6E63 0%,#6D4C41 100%);clip-path:polygon(30% 0,70% 0,100% 100%,0 100%)}

/* paw prints */
.dg-paw{position:absolute;z-index:2;font-size:var(--paw-sz,20px);opacity:var(--paw-op,.15);transform:rotate(var(--paw-r,0deg));animation:dg-paw-bounce 3s ease-in-out var(--paw-d,0s) infinite alternate}
@keyframes dg-paw-bounce{0%{transform:rotate(var(--paw-r,0deg)) translateY(0)}100%{transform:rotate(var(--paw-r,0deg)) translateY(-8px)}}

/* agility cones */
.dg-cone-row{position:absolute;bottom:38%;left:0;right:0;display:flex;justify-content:space-evenly;z-index:3}
.dg-cone{width:0;height:0;border-left:12px solid transparent;border-right:12px solid transparent;border-bottom:28px solid var(--dg-yellow);filter:drop-shadow(0 2px 4px rgba(0,0,0,.4));animation:dg-cone-bob 2.5s ease-in-out var(--cone-d,0s) infinite alternate}
.dg-cone::after{content:'';position:absolute;bottom:-28px;left:-14px;width:28px;height:6px;background:#E65100;border-radius:3px}
@keyframes dg-cone-bob{0%{transform:translateY(0) scale(1)}100%{transform:translateY(-4px) scale(1.05)}}

/* dog silhouette */
.dg-dog{position:absolute;bottom:38%;right:22%;z-index:5;width:110px;height:80px;animation:dg-dog-wag 1.2s ease-in-out infinite alternate}
@keyframes dg-dog-wag{0%{transform:rotate(-1deg) translateY(0)}100%{transform:rotate(1deg) translateY(-4px)}}
.dg-dog-body{position:absolute;bottom:0;left:10px;width:80px;height:44px;background:#D4A574;border-radius:50% 40% 40% 50%;border:3px solid #A0785A}
.dg-dog-head{position:absolute;top:0;right:0;width:46px;height:42px;background:#D4A574;border-radius:50%;border:3px solid #A0785A}
.dg-dog-ear{position:absolute;top:6px;right:-4px;width:22px;height:28px;background:#A0785A;border-radius:50% 50% 30% 70%;transform:rotate(20deg)}
.dg-dog-eye{position:absolute;top:14px;right:10px;width:8px;height:8px;background:#2D1A0E;border-radius:50%}
.dg-dog-nose{position:absolute;top:22px;right:5px;width:10px;height:6px;background:#2D1A0E;border-radius:50% 50% 40% 40%}
.dg-dog-tail{position:absolute;bottom:24px;left:-14px;width:28px;height:10px;background:#D4A574;border-radius:99px;transform-origin:right center;animation:dg-tail-wag .5s ease-in-out infinite alternate;border:2px solid #A0785A}
@keyframes dg-tail-wag{0%{transform:rotate(-30deg)}100%{transform:rotate(30deg)}}
.dg-dog-leg{position:absolute;bottom:-16px;width:12px;height:20px;background:#C49060;border-radius:4px;border:2px solid #A0785A}
.dg-dog-leg:nth-child(1){left:14px}
.dg-dog-leg:nth-child(2){left:30px}
.dg-dog-leg:nth-child(3){right:14px}
.dg-dog-leg:nth-child(4){right:30px}

/* trainer figure */
.dg-trainer-fig{position:absolute;bottom:36%;left:22%;z-index:5;width:60px;height:130px}
.dg-tf-head{position:absolute;top:0;left:50%;transform:translateX(-50%);width:32px;height:32px;background:#F5CBA7;border-radius:50%;border:2px solid #D4A030}
.dg-tf-hair{position:absolute;top:0;left:50%;transform:translateX(-50%);width:32px;height:18px;background:#4A2C10;border-radius:50% 50% 0 0}
.dg-tf-body{position:absolute;top:30px;left:50%;transform:translateX(-50%);width:40px;height:52px;background:var(--dg-green);border-radius:8px 8px 4px 4px;border:2px solid #1B5E20}
.dg-tf-badge{position:absolute;top:10px;left:4px;width:14px;height:14px;background:var(--dg-yellow);border-radius:3px;font-size:7px;color:#333;display:flex;align-items:center;justify-content:center;font-weight:900}
.dg-tf-arm-l{position:absolute;top:34px;left:6px;width:14px;height:38px;background:var(--dg-green);border-radius:99px;transform:rotate(-15deg);transform-origin:top center;border:2px solid #1B5E20}
.dg-tf-arm-r{position:absolute;top:34px;right:4px;width:14px;height:38px;background:var(--dg-green);border-radius:99px;transform:rotate(15deg);transform-origin:top center;border:2px solid #1B5E20;animation:dg-arm-signal 1.5s ease-in-out infinite alternate}
@keyframes dg-arm-signal{0%{transform:rotate(15deg)}100%{transform:rotate(-20deg)}}
.dg-tf-hand{position:absolute;bottom:-6px;left:50%;transform:translateX(-50%);width:14px;height:14px;background:#F5CBA7;border-radius:50%}
.dg-tf-leg{position:absolute;bottom:0;width:16px;height:42px;background:#5D4037;border-radius:4px;border:2px solid #3E2723}
.dg-tf-leg-l{left:6px}
.dg-tf-leg-r{right:6px}
.dg-tf-shoe{position:absolute;bottom:-4px;width:20px;height:10px;background:#212121;border-radius:99px 99px 50% 50%}
.dg-tf-shoe-l{left:-2px}
.dg-tf-shoe-r{right:-2px}
/* treat pouch */
.dg-tf-pouch{position:absolute;top:52px;right:0;width:14px;height:18px;background:var(--dg-tan);border-radius:4px;border:2px solid #A0785A}

/* lead between trainer and dog */
.dg-lead{position:absolute;bottom:42%;left:28%;z-index:4}
.dg-lead svg{overflow:visible}

/* hero content */
.dg-hero__content{position:relative;z-index:10;max-width:600px;padding:40px 0 200px}
.dg-hero__eyebrow{font-family:var(--dg-ff);font-size:.8rem;font-weight:700;letter-spacing:.15em;text-transform:uppercase;color:var(--dg-yellow);margin-bottom:16px}
.dg-hero__title{font-family:var(--dg-ff);font-size:clamp(2.2rem,5vw,3.8rem);font-weight:900;color:#fff;line-height:1.1;margin-bottom:20px}
.dg-hero__title span{color:var(--dg-yellow)}
.dg-hero__sub{font-size:1.15rem;color:rgba(255,255,255,.82);max-width:460px;margin-bottom:36px}
.dg-hero__ctas{display:flex;gap:16px;flex-wrap:wrap}
.dg-btn{display:inline-flex;align-items:center;gap:8px;font-family:var(--dg-ff);font-weight:800;font-size:.95rem;padding:15px 32px;border-radius:99px;cursor:pointer;border:none;transition:transform .2s,box-shadow .2s}
.dg-btn--primary{background:var(--dg-yellow);color:var(--dg-brown)}
.dg-btn--primary:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(255,193,7,.45)}
.dg-btn--ghost{background:transparent;color:#fff;border:2px solid rgba(255,255,255,.45)}
.dg-btn--ghost:hover{background:rgba(255,255,255,.1)}

/* ── TRUST BADGES ── */
.dg-badges{display:flex;gap:28px;flex-wrap:wrap;padding:32px 0;margin-top:24px;border-top:1px solid rgba(255,255,255,.15)}
.dg-badge{display:flex;align-items:center;gap:10px;color:rgba(255,255,255,.9)}
.dg-badge__icon{font-size:1.5rem}
.dg-badge__text{font-size:.8rem;line-height:1.3;font-weight:600}
.dg-badge__text strong{display:block;font-size:.95rem;color:#fff}

/* ── COUNTERS ── */
.dg-counters{display:grid;grid-template-columns:repeat(4,1fr);gap:32px}
.dg-counter{text-align:center;padding:36px 20px;background:#fff;border-radius:var(--dg-r);box-shadow:0 4px 20px var(--dg-shadow)}
.dg-counter__num{font-family:var(--dg-ff);font-size:2.6rem;font-weight:900;color:var(--dg-green);line-height:1}
.dg-counter__label{font-size:.88rem;color:var(--dg-mid);margin-top:8px;font-weight:500}

/* ── SERVICES ── */
.dg-services-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:28px;margin-top:52px}
.dg-service-card{background:#fff;border-radius:var(--dg-r);padding:32px 28px;box-shadow:0 4px 20px var(--dg-shadow);border-top:4px solid var(--dg-green);transition:transform .25s,box-shadow .25s}
.dg-service-card:hover{transform:translateY(-4px);box-shadow:0 12px 32px var(--dg-shadow)}
.dg-service-card__icon{font-size:2.2rem;margin-bottom:16px}
.dg-service-card__title{font-family:var(--dg-ff);font-size:1.05rem;font-weight:800;color:var(--dg-slate);margin-bottom:10px}
.dg-service-card__desc{font-size:.9rem;color:var(--dg-mid);line-height:1.65}

/* ── ABOUT ── */
.dg-about{display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:center}
.dg-about__figure{position:relative;display:flex;justify-content:center}
.dg-about__scene{width:300px;height:340px;background:linear-gradient(145deg,var(--dg-light) 0%,#fff 100%);border-radius:var(--dg-r);position:relative;overflow:hidden;box-shadow:0 8px 32px var(--dg-shadow);border:3px solid rgba(46,125,50,.15)}
/* park scene inside about card */
.dg-sc-grass{position:absolute;bottom:0;left:0;right:0;height:50%;background:linear-gradient(180deg,#43A047 0%,#2E7D32 100%)}
.dg-sc-sky{position:absolute;top:0;left:0;right:0;height:52%;background:linear-gradient(180deg,#E3F2FD 0%,#BBDEFB 100%)}
.dg-sc-sun{position:absolute;top:18px;right:30px;width:44px;height:44px;background:var(--dg-yellow);border-radius:50%;box-shadow:0 0 20px rgba(255,193,7,.5)}
.dg-sc-tree{position:absolute;bottom:48%;left:16px}
.dg-sc-tree-trunk{width:14px;height:36px;background:#5D4037;border-radius:3px;margin:0 auto}
.dg-sc-tree-top{width:50px;height:60px;background:#2E7D32;border-radius:50% 50% 30% 30%;margin:0 auto;transform:translateY(6px)}
.dg-sc-dog-sm{position:absolute;bottom:50%;right:30px;width:54px;height:36px}
.dg-sc-dog-sm-body{width:38px;height:22px;background:var(--dg-tan);border-radius:50% 40% 40% 50%;border:2px solid #A0785A;position:absolute;bottom:0;left:8px}
.dg-sc-dog-sm-head{width:22px;height:20px;background:var(--dg-tan);border-radius:50%;border:2px solid #A0785A;position:absolute;top:0;right:0}
.dg-sc-dog-sm-tail{width:14px;height:6px;background:var(--dg-tan);border-radius:99px;position:absolute;bottom:14px;left:-6px;transform:rotate(-30deg);animation:dg-tail-wag .5s ease-in-out infinite alternate;border:1px solid #A0785A}
/* trainer small */
.dg-sc-trainer-sm{position:absolute;bottom:49%;left:50%;transform:translateX(-50%);display:flex;flex-direction:column;align-items:center}
.dg-sc-t-head{width:18px;height:18px;background:#F5CBA7;border-radius:50%;border:2px solid #D4A030}
.dg-sc-t-body{width:22px;height:28px;background:var(--dg-green);border-radius:6px;border:2px solid #1B5E20}
.dg-sc-t-legs{display:flex;gap:2px;margin-top:1px}
.dg-sc-t-leg{width:8px;height:20px;background:#5D4037;border-radius:3px}
/* credentials */
.dg-about__creds{display:flex;flex-direction:column;gap:14px;margin-top:28px}
.dg-cred{display:flex;align-items:center;gap:14px;padding:14px 18px;background:var(--dg-light);border-radius:10px;border-left:3px solid var(--dg-green)}
.dg-cred__icon{font-size:1.3rem}
.dg-cred__text{font-size:.9rem;font-weight:700;color:var(--dg-slate)}

/* ── PROCESS ── */
.dg-process{display:flex;flex-direction:column;gap:0}
.dg-step{display:flex;gap:28px;align-items:flex-start;padding:28px 0;border-bottom:1px solid rgba(46,125,50,.12)}
.dg-step:last-child{border-bottom:none}
.dg-step__num{flex-shrink:0;width:52px;height:52px;background:var(--dg-green);color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:var(--dg-ff);font-weight:900;font-size:.95rem}
.dg-step__body h4{font-family:var(--dg-ff);font-size:1.05rem;font-weight:800;color:var(--dg-slate);margin-bottom:6px}
.dg-step__body p{font-size:.92rem;color:var(--dg-mid)}

/* ── PACKAGES ── */
.dg-packages{display:grid;grid-template-columns:repeat(3,1fr);gap:32px;margin-top:56px;align-items:start}
.dg-pkg{border-radius:var(--dg-r);padding:40px 32px;background:#fff;box-shadow:0 4px 20px var(--dg-shadow);position:relative;transition:transform .25s}
.dg-pkg:hover{transform:translateY(-4px)}
.dg-pkg--featured{background:var(--dg-green);color:#fff;box-shadow:0 12px 40px rgba(46,125,50,.4);transform:scale(1.04)}
.dg-pkg--featured:hover{transform:scale(1.04) translateY(-4px)}
.dg-pkg--featured .dg-pkg__name{color:#fff}
.dg-pkg--featured .dg-pkg__price{color:var(--dg-yellow)}
.dg-pkg--featured .dg-pkg__period{color:rgba(255,255,255,.75)}
.dg-pkg--featured .dg-pkg__feature{color:rgba(255,255,255,.9)}
.dg-pkg--featured .dg-pkg__feature::before{color:var(--dg-yellow)}
.dg-pkg__ribbon{position:absolute;top:-1px;right:24px;background:var(--dg-yellow);color:var(--dg-brown);font-family:var(--dg-ff);font-size:.7rem;font-weight:900;padding:6px 16px;border-radius:0 0 10px 10px;letter-spacing:.05em}
.dg-pkg__name{font-family:var(--dg-ff);font-size:1.15rem;font-weight:900;color:var(--dg-slate);margin-bottom:8px}
.dg-pkg__price{font-family:var(--dg-ff);font-size:2.6rem;font-weight:900;color:var(--dg-green);line-height:1}
.dg-pkg__period{font-size:.85rem;color:var(--dg-mid);margin-bottom:28px}
.dg-pkg__features{list-style:none;display:flex;flex-direction:column;gap:10px;margin-bottom:32px}
.dg-pkg__feature{font-size:.9rem;padding-left:22px;position:relative}
.dg-pkg__feature::before{content:'✓';position:absolute;left:0;color:var(--dg-green);font-weight:900}
.dg-pkg__btn{display:block;text-align:center;padding:14px;border-radius:99px;font-family:var(--dg-ff);font-weight:800;font-size:.9rem;cursor:pointer;border:none;transition:opacity .2s}
.dg-pkg--sky .dg-pkg__btn{background:var(--dg-sky);color:#fff}
.dg-pkg--green .dg-pkg__btn{background:var(--dg-yellow);color:var(--dg-brown)}
.dg-pkg--brown .dg-pkg__btn{background:var(--dg-brown);color:#fff}
.dg-pkg__btn:hover{opacity:.88}

/* ── BREEDS CLOUD ── */
.dg-breeds{display:flex;flex-wrap:wrap;gap:10px;margin-top:40px}
.dg-breed-tag{padding:8px 18px;background:#fff;border-radius:99px;font-size:.85rem;font-weight:700;color:var(--dg-slate);box-shadow:0 2px 8px var(--dg-shadow);border:1px solid rgba(46,125,50,.15);font-family:var(--dg-ff)}

/* ── TESTIMONIALS ── */
.dg-testimonials{display:grid;grid-template-columns:repeat(3,1fr);gap:28px;margin-top:52px}
.dg-testimonial{background:#fff;border-radius:var(--dg-r);padding:28px;box-shadow:0 4px 16px var(--dg-shadow);position:relative}
.dg-testimonial::before{content:'"';position:absolute;top:12px;left:18px;font-size:3rem;color:var(--dg-green);opacity:.2;font-family:Georgia,serif;line-height:1}
.dg-testimonial__text{font-size:.92rem;line-height:1.7;color:var(--dg-mid);margin-bottom:20px;padding-top:16px}
.dg-testimonial__author{display:flex;align-items:center;gap:12px}
.dg-testimonial__avatar{width:44px;height:44px;border-radius:50%;background:var(--dg-light);display:flex;align-items:center;justify-content:center;font-size:1.4rem}
.dg-testimonial__name{font-weight:700;font-family:var(--dg-ff);font-size:.92rem;color:var(--dg-slate)}
.dg-testimonial__dog{font-size:.8rem;color:var(--dg-mid)}
.dg-stars{color:var(--dg-yellow);font-size:.85rem;letter-spacing:2px}

/* ── FAQs ── */
.dg-faq-list{display:flex;flex-direction:column;gap:12px;margin-top:48px}
.dg-faq{border:1px solid rgba(46,125,50,.18);border-radius:10px;overflow:hidden;background:#fff}
.dg-faq__q{padding:20px 24px;font-family:var(--dg-ff);font-size:1rem;font-weight:700;color:var(--dg-slate);cursor:pointer;display:flex;justify-content:space-between;align-items:center;gap:16px}
.dg-faq__q::after{content:'＋';font-size:1.2rem;color:var(--dg-green);flex-shrink:0;transition:transform .25s}
.dg-faq.open .dg-faq__q::after{transform:rotate(45deg)}
.dg-faq__a{max-height:0;overflow:hidden;transition:max-height .35s ease}
.dg-faq.open .dg-faq__a{max-height:300px}
.dg-faq__a-inner{padding:0 24px 20px;font-size:.92rem;color:var(--dg-mid);line-height:1.7}

/* ── BOOKING FORM ── */
.dg-form-wrap{background:var(--dg-slate);border-radius:var(--dg-r);padding:56px 52px;box-shadow:0 12px 48px rgba(0,0,0,.25)}
.dg-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}
.dg-form-grid .dg-fg--full{grid-column:1/-1}
.dg-field label{display:block;font-size:.82rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:rgba(255,255,255,.65);margin-bottom:8px}
.dg-field input,.dg-field select,.dg-field textarea{width:100%;padding:13px 16px;background:rgba(255,255,255,.08);border:1.5px solid rgba(255,255,255,.18);border-radius:8px;color:#fff;font-size:.95rem;font-family:var(--dg-ff2);transition:border-color .2s}
.dg-field input::placeholder,.dg-field textarea::placeholder{color:rgba(255,255,255,.35)}
.dg-field input:focus,.dg-field select:focus,.dg-field textarea:focus{outline:none;border-color:var(--dg-yellow)}
.dg-field select option{background:var(--dg-slate);color:#fff}
.dg-field textarea{resize:vertical;min-height:100px}
.dg-form-submit{margin-top:8px}
.dg-form-note{font-size:.8rem;color:rgba(255,255,255,.45);margin-top:12px}

/* ── CTA STRIP ── */
.dg-cta-strip{background:var(--dg-green);padding:64px 0;text-align:center}
.dg-cta-strip h2{font-family:var(--dg-ff);font-size:2.2rem;font-weight:900;color:#fff;margin-bottom:16px}
.dg-cta-strip p{color:rgba(255,255,255,.82);font-size:1.05rem;margin-bottom:32px}

/* ── FOOTER NAV ── */
.dg-footer-strip{background:var(--dg-brown);padding:28px 0;text-align:center}
.dg-footer-strip p{color:rgba(255,255,255,.5);font-size:.85rem}

/* ── SECTION TITLES ── */
.dg-section-title{font-family:var(--dg-ff);font-size:clamp(1.8rem,3.5vw,2.6rem);font-weight:900;color:var(--dg-slate);margin-bottom:16px}
.dg-section-sub{font-size:1.05rem;color:var(--dg-mid);max-width:580px}

/* ── SCROLL REVEAL ── */
.dg-reveal{opacity:0;transform:translateY(28px);transition:opacity .65s,transform .65s}
.dg-reveal.visible{opacity:1;transform:none}

/* ── RESPONSIVE ── */
@media(max-width:900px){
  .dg-counters{grid-template-columns:repeat(2,1fr)}
  .dg-packages{grid-template-columns:1fr}
  .dg-pkg--featured{transform:none}
  .dg-about{grid-template-columns:1fr}
  .dg-testimonials{grid-template-columns:1fr}
  .dg-form-grid{grid-template-columns:1fr}
}
@media(max-width:600px){
  .dg-section{padding:64px 0}
  .dg-form-wrap{padding:36px 24px}
  .dg-counters{grid-template-columns:1fr 1fr}
}
</style>
<?php get_header(); ?>
<div class="dg-page">
>
<?php wp_body_open(); ?>

<!-- ═══════════ HERO ═══════════ -->
<section class="dg-hero" id="home">
  <div class="dg-sky-bg"></div>
  <div class="dg-sun"></div>

  <!-- Paw prints -->
  <?php foreach ( $paws as $p ) : ?>
    <div class="dg-paw" style="top:<?php echo $p['top']; ?>%;left:<?php echo $p['left']; ?>%;--paw-sz:<?php echo $p['size']; ?>px;--paw-op:<?php echo $p['op']; ?>;--paw-r:<?php echo $p['rot']; ?>deg;--paw-d:<?php echo $p['delay']; ?>s">🐾</div>
  <?php endforeach; ?>

  <!-- Ground & grass -->
  <div class="dg-ground">
    <div class="dg-grass"></div>
    <div class="dg-path"></div>
  </div>

  <!-- Agility cones -->
  <div class="dg-cone-row">
    <?php foreach ( $cones as $ci => $pos ) : ?>
      <div class="dg-cone" style="--cone-d:<?php echo $ci * 0.4; ?>s;position:relative;left:<?php echo $pos - 50; ?>%"></div>
    <?php endforeach; ?>
  </div>

  <!-- Trainer figure -->
  <div class="dg-trainer-fig">
    <div class="dg-tf-head">
      <div class="dg-tf-hair"></div>
    </div>
    <div class="dg-tf-body">
      <div class="dg-tf-badge">🐕</div>
      <div class="dg-tf-pouch"></div>
    </div>
    <div class="dg-tf-arm-l"><div class="dg-tf-hand"></div></div>
    <div class="dg-tf-arm-r"><div class="dg-tf-hand"></div></div>
    <div class="dg-tf-leg dg-tf-leg-l"><div class="dg-tf-shoe dg-tf-shoe-l"></div></div>
    <div class="dg-tf-leg dg-tf-leg-r"><div class="dg-tf-shoe dg-tf-shoe-r"></div></div>
  </div>

  <!-- Dog silhouette -->
  <div class="dg-dog">
    <div class="dg-dog-tail"></div>
    <div class="dg-dog-body"></div>
    <div class="dg-dog-head">
      <div class="dg-dog-ear"></div>
      <div class="dg-dog-eye"></div>
      <div class="dg-dog-nose"></div>
    </div>
    <div class="dg-dog-leg"></div>
    <div class="dg-dog-leg"></div>
    <div class="dg-dog-leg"></div>
    <div class="dg-dog-leg"></div>
  </div>

  <!-- SVG Lead -->
  <div class="dg-lead">
    <svg width="180" height="60" viewBox="0 0 180 60" fill="none">
      <path d="M10 10 Q90 55 170 10" stroke="#D4A574" stroke-width="3" stroke-dasharray="8 4" opacity=".7" fill="none"/>
    </svg>
  </div>

  <div class="dg-wrap">
    <div class="dg-hero__content">
      <p class="dg-hero__eyebrow">Force-Free · CCPDT-KA Certified · Brighton & East Sussex</p>
      <h1 class="dg-hero__title">
        <?php echo esc_html( $trainer['tagline'] ); ?><br>
        <span>One Command at a Time</span>
      </h1>
      <p class="dg-hero__sub">
        Science-based dog training that creates calm, connected dogs and confident owners — no fear, no force, no shortcuts.
      </p>
      <div class="dg-hero__ctas">
        <a href="#booking" class="dg-btn dg-btn--primary">🐕 Book a Free Call</a>
        <a href="#services" class="dg-btn dg-btn--ghost">View Programmes</a>
      </div>
      <div class="dg-badges">
        <div class="dg-badge">
          <span class="dg-badge__icon">🎓</span>
          <div class="dg-badge__text"><strong>CCPDT-KA</strong>Certified Professional</div>
        </div>
        <div class="dg-badge">
          <span class="dg-badge__icon">🐾</span>
          <div class="dg-badge__text"><strong>3,200+ Dogs</strong>Trained & Transformed</div>
        </div>
        <div class="dg-badge">
          <span class="dg-badge__icon">🚫</span>
          <div class="dg-badge__text"><strong>100% Force-Free</strong>LIMA Principles</div>
        </div>
        <div class="dg-badge">
          <span class="dg-badge__icon">⭐</span>
          <div class="dg-badge__text"><strong>4.9 / 5 Stars</strong>Google & Trustpilot</div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ COUNTERS ═══════════ -->
<section class="dg-section dg-section--alt">
  <div class="dg-wrap">
    <div class="dg-counters">
      <div class="dg-counter dg-reveal">
        <div class="dg-counter__num" data-target="<?php echo $trainer['years']; ?>">0</div>
        <div class="dg-counter__label">Years Experience</div>
      </div>
      <div class="dg-counter dg-reveal">
        <div class="dg-counter__num" data-target="<?php echo $trainer['dogs']; ?>" data-suffix="+">0</div>
        <div class="dg-counter__label">Dogs Trained</div>
      </div>
      <div class="dg-counter dg-reveal">
        <div class="dg-counter__num" data-target="<?php echo $trainer['rating']; ?>" data-float="1" data-suffix="★">0</div>
        <div class="dg-counter__label">Average Rating</div>
      </div>
      <div class="dg-counter dg-reveal">
        <div class="dg-counter__num" data-target="<?php echo $trainer['success']; ?>" data-suffix="%">0</div>
        <div class="dg-counter__label">Success Rate</div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ SERVICES ═══════════ -->
<section class="dg-section dg-section--light" id="services">
  <div class="dg-wrap">
    <div class="dg-tag">Training Programmes</div>
    <h2 class="dg-section-title">Every Dog Deserves the Right Programme</h2>
    <p class="dg-section-sub">From mischievous puppies to complex behaviour challenges — Marcus has a science-backed solution.</p>
    <div class="dg-services-grid">
      <?php foreach ( $services as $svc ) : ?>
      <div class="dg-service-card dg-reveal">
        <div class="dg-service-card__icon"><?php echo $svc['icon']; ?></div>
        <h3 class="dg-service-card__title"><?php echo esc_html( $svc['title'] ); ?></h3>
        <p class="dg-service-card__desc"><?php echo esc_html( $svc['desc'] ); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════ ABOUT ═══════════ -->
<section class="dg-section dg-section--alt" id="about">
  <div class="dg-wrap">
    <div class="dg-about">
      <div class="dg-about__figure">
        <div class="dg-about__scene">
          <div class="dg-sc-sky"></div>
          <div class="dg-sc-sun"></div>
          <div class="dg-sc-grass"></div>
          <div class="dg-sc-tree">
            <div class="dg-sc-tree-top"></div>
            <div class="dg-sc-tree-trunk"></div>
          </div>
          <div class="dg-sc-trainer-sm">
            <div class="dg-sc-t-head"></div>
            <div class="dg-sc-t-body"></div>
            <div class="dg-sc-t-legs">
              <div class="dg-sc-t-leg"></div>
              <div class="dg-sc-t-leg"></div>
            </div>
          </div>
          <div class="dg-sc-dog-sm">
            <div class="dg-sc-dog-sm-tail"></div>
            <div class="dg-sc-dog-sm-body"></div>
            <div class="dg-sc-dog-sm-head"></div>
          </div>
          <div style="position:absolute;bottom:16px;left:0;right:0;text-align:center">
            <p style="font-family:var(--dg-ff);font-size:.75rem;font-weight:800;color:#1B5E20">Marcus Reid CCPDT-KA</p>
            <p style="font-size:.65rem;color:var(--dg-mid)">Canine Behaviourist</p>
          </div>
        </div>
      </div>
      <div class="dg-about__content">
        <div class="dg-tag">Meet Your Trainer</div>
        <h2 class="dg-section-title"><?php echo esc_html( $trainer['name'] ); ?></h2>
        <p style="font-size:.9rem;font-weight:700;color:var(--dg-green);margin-bottom:20px"><?php echo esc_html( $trainer['title'] ); ?></p>
        <p style="color:var(--dg-mid);line-height:1.8;margin-bottom:18px"><?php echo esc_html( $trainer['bio'] ); ?></p>
        <p style="color:var(--dg-mid);line-height:1.8;margin-bottom:28px"><?php echo esc_html( $trainer['bio2'] ); ?></p>
        <div class="dg-about__creds">
          <div class="dg-cred"><span class="dg-cred__icon">🎓</span><span class="dg-cred__text">CCPDT-KA Certified Professional Dog Trainer</span></div>
          <div class="dg-cred"><span class="dg-cred__icon">🔬</span><span class="dg-cred__text">BSc Animal Behaviour, University of Sussex</span></div>
          <div class="dg-cred"><span class="dg-cred__icon">🐾</span><span class="dg-cred__text">PPG Member — Pet Professional Guild</span></div>
          <div class="dg-cred"><span class="dg-cred__icon">🏅</span><span class="dg-cred__text">RSPCA Approved Training Partner</span></div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ PROCESS ═══════════ -->
<section class="dg-section dg-section--light" id="process">
  <div class="dg-wrap">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:start">
      <div>
        <div class="dg-tag">How It Works</div>
        <h2 class="dg-section-title">Your Path to a Calmer, Happier Dog</h2>
        <p class="dg-section-sub" style="margin-bottom:40px">A structured, proven journey from first call to confident, connected dog.</p>
        <div class="dg-process">
          <?php foreach ( $steps as $step ) : ?>
          <div class="dg-step dg-reveal">
            <div class="dg-step__num"><?php echo $step['num']; ?></div>
            <div class="dg-step__body">
              <h4><?php echo esc_html( $step['title'] ); ?></h4>
              <p><?php echo esc_html( $step['desc'] ); ?></p>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <div>
        <div class="dg-tag dg-tag--sky">Breeds I Work With</div>
        <h2 class="dg-section-title" style="font-size:1.7rem">All Breeds Welcome</h2>
        <p style="color:var(--dg-mid);margin-bottom:24px">Every dog is unique. The programme adapts to the individual, not the breed.</p>
        <div class="dg-breeds">
          <?php
          $breeds = [ 'Labrador', 'Golden Retriever', 'Border Collie', 'Cocker Spaniel', 'French Bulldog', 'German Shepherd', 'Dachshund', 'Beagle', 'Springer Spaniel', 'Poodle', 'Staffordshire Bull Terrier', 'Cavapoo', 'Cockapoo', 'Husky', 'Jack Russell', 'Vizsla', 'Weimaraner', 'Lurcher', 'Mixed Breeds', '+ more' ];
          foreach ( $breeds as $breed ) : ?>
          <span class="dg-breed-tag"><?php echo esc_html( $breed ); ?></span>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ PACKAGES ═══════════ -->
<section class="dg-section dg-section--alt" id="packages">
  <div class="dg-wrap">
    <div style="text-align:center;max-width:640px;margin:0 auto 8px">
      <div class="dg-tag">Programmes & Pricing</div>
      <h2 class="dg-section-title">Choose the Right Programme</h2>
      <p class="dg-section-sub" style="margin:0 auto">Transparent pricing, no hidden fees. All programmes include support between sessions.</p>
    </div>
    <div class="dg-packages">
      <?php foreach ( $packages as $pkg ) : ?>
      <div class="dg-pkg dg-pkg--<?php echo $pkg['colour']; ?><?php echo $pkg['featured'] ? ' dg-pkg--featured' : ''; ?> dg-reveal">
        <?php if ( $pkg['featured'] ) : ?><div class="dg-pkg__ribbon">⭐ Most Popular</div><?php endif; ?>
        <div class="dg-pkg__name"><?php echo esc_html( $pkg['name'] ); ?></div>
        <div class="dg-pkg__price"><?php echo esc_html( $pkg['price'] ); ?></div>
        <div class="dg-pkg__period"><?php echo esc_html( $pkg['period'] ); ?></div>
        <ul class="dg-pkg__features">
          <?php foreach ( $pkg['features'] as $feat ) : ?>
          <li class="dg-pkg__feature"><?php echo esc_html( $feat ); ?></li>
          <?php endforeach; ?>
        </ul>
        <a href="#booking" class="dg-pkg__btn">Book <?php echo esc_html( $pkg['name'] ); ?></a>
      </div>
      <?php endforeach; ?>
    </div>
    <p style="text-align:center;margin-top:28px;font-size:.88rem;color:var(--dg-mid)">All prices include VAT. Payment plans available. Rescue dogs receive a 15% discount.</p>
  </div>
</section>

<!-- ═══════════ TESTIMONIALS ═══════════ -->
<section class="dg-section dg-section--light">
  <div class="dg-wrap">
    <div class="dg-tag">Client Stories</div>
    <h2 class="dg-section-title">Real Dogs, Real Results</h2>
    <div class="dg-testimonials">
      <?php
      $testimonials = [
        [ 'emoji' => '👩', 'text' => 'After just 4 sessions our reactive Springer was walking calmly past other dogs. Marcus\'s patience and knowledge are incredible — he explained the science behind every exercise so we understood exactly what we were doing and why.', 'name' => 'Sarah T.', 'dog' => 'Springer Spaniel, 2 years' ],
        [ 'emoji' => '👨', 'text' => 'Our puppy Archie used to bite everything and everyone. Six weeks into the Puppy Start programme and he\'s a completely different dog. The between-session support via WhatsApp made all the difference.', 'name' => 'James & Emma K.', 'dog' => 'Labrador Puppy, 4 months' ],
        [ 'emoji' => '👩‍🦳', 'text' => 'I rescued a 5-year-old GSD with severe separation anxiety. Marcus\'s Behaviour SOS programme literally saved his life — we went from 0 to 3 hours alone in 8 weeks. I cannot recommend him highly enough.', 'name' => 'Margaret O.', 'dog' => 'German Shepherd, 5 years' ],
      ];
      foreach ( $testimonials as $t ) : ?>
      <div class="dg-testimonial dg-reveal">
        <p class="dg-testimonial__text"><?php echo esc_html( $t['text'] ); ?></p>
        <div class="dg-testimonial__author">
          <div class="dg-testimonial__avatar"><?php echo $t['emoji']; ?></div>
          <div>
            <div class="dg-testimonial__name"><?php echo esc_html( $t['name'] ); ?></div>
            <div class="dg-testimonial__dog"><?php echo esc_html( $t['dog'] ); ?></div>
            <div class="dg-stars">★★★★★</div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════ FAQs ═══════════ -->
<section class="dg-section dg-section--alt" id="faq">
  <div class="dg-wrap">
    <div style="max-width:760px;margin:0 auto">
      <div class="dg-tag">FAQs</div>
      <h2 class="dg-section-title">Common Questions</h2>
      <div class="dg-faq-list">
        <?php foreach ( $faqs as $faq ) : ?>
        <div class="dg-faq">
          <div class="dg-faq__q"><?php echo esc_html( $faq['q'] ); ?></div>
          <div class="dg-faq__a"><div class="dg-faq__a-inner"><?php echo esc_html( $faq['a'] ); ?></div></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ CTA STRIP ═══════════ -->
<div class="dg-cta-strip">
  <div class="dg-wrap">
    <h2>Ready to Start Your Dog's Transformation?</h2>
    <p>Book a free 15-minute discovery call — no commitment, just clarity.</p>
    <a href="#booking" class="dg-btn dg-btn--primary">🐾 Book Free Call Now</a>
  </div>
</div>

<!-- ═══════════ BOOKING FORM ═══════════ -->
<section class="dg-section dg-section--light" id="booking">
  <div class="dg-wrap">
    <div style="max-width:820px;margin:0 auto">
      <div class="dg-tag">Get in Touch</div>
      <h2 class="dg-section-title">Book Your Free Discovery Call</h2>
      <p style="color:var(--dg-mid);margin-bottom:40px">Tell Marcus about your dog and he'll get in touch within 24 hours to arrange a free 15-minute call.</p>
      <div class="dg-form-wrap">
        <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
          <?php wp_nonce_field( 'tf_dg_booking', 'tf_dg_nonce' ); ?>
          <input type="hidden" name="action" value="tf_dg_booking">
          <div class="dg-form-grid">
            <div class="dg-field">
              <label for="dg-owner-name">Your Name *</label>
              <input type="text" id="dg-owner-name" name="owner_name" placeholder="Your full name" required>
            </div>
            <div class="dg-field">
              <label for="dg-email">Email Address *</label>
              <input type="email" id="dg-email" name="email" placeholder="you@example.com" required>
            </div>
            <div class="dg-field">
              <label for="dg-phone">Phone Number</label>
              <input type="tel" id="dg-phone" name="phone" placeholder="+44 7700 000000">
            </div>
            <div class="dg-field">
              <label for="dg-location">Your Location</label>
              <input type="text" id="dg-location" name="location" placeholder="Town / City">
            </div>
            <div class="dg-field">
              <label for="dg-dog-name">Dog's Name *</label>
              <input type="text" id="dg-dog-name" name="dog_name" placeholder="Dog's name" required>
            </div>
            <div class="dg-field">
              <label for="dg-breed">Breed</label>
              <input type="text" id="dg-breed" name="breed" placeholder="e.g. Labrador, Mixed Breed">
            </div>
            <div class="dg-field">
              <label for="dg-dog-age">Dog's Age *</label>
              <select id="dg-dog-age" name="dog_age" required>
                <option value="" disabled selected>Select age range</option>
                <option value="puppy">Puppy (under 6 months)</option>
                <option value="adolescent">Adolescent (6–18 months)</option>
                <option value="adult">Adult (18 months – 7 years)</option>
                <option value="senior">Senior (7+ years)</option>
              </select>
            </div>
            <div class="dg-field">
              <label for="dg-programme">Programme of Interest</label>
              <select id="dg-programme" name="programme">
                <option value="" disabled selected>Which programme?</option>
                <option>Puppy Start (6 weeks)</option>
                <option>Canine Excellence (8 weeks)</option>
                <option>Behaviour SOS (12 weeks)</option>
                <option>Not sure — need advice</option>
              </select>
            </div>
            <div class="dg-field">
              <label for="dg-format">Preferred Format</label>
              <select id="dg-format" name="format">
                <option value="" disabled selected>How would you like to work?</option>
                <option>Home visits (Brighton & East Sussex)</option>
                <option>Online / video sessions</option>
                <option>Mixed (home + online)</option>
              </select>
            </div>
            <div class="dg-field">
              <label for="dg-main-issue">Main Challenge</label>
              <select id="dg-main-issue" name="main_issue">
                <option value="" disabled selected>What's the main issue?</option>
                <option>Pulling on lead</option>
                <option>Recall / running off</option>
                <option>Reactivity / aggression</option>
                <option>Jumping up</option>
                <option>Separation anxiety</option>
                <option>Destructive behaviour</option>
                <option>Puppy basics</option>
                <option>Multiple issues</option>
                <option>Other</option>
              </select>
            </div>
            <div class="dg-field dg-fg--full">
              <label for="dg-notes">Tell Marcus About Your Dog</label>
              <textarea id="dg-notes" name="notes" placeholder="Share anything that might help Marcus prepare — history, previous training, behaviour triggers, your goals..."></textarea>
            </div>
          </div>
          <div class="dg-form-submit" style="margin-top:24px">
            <button type="submit" class="dg-btn dg-btn--primary" style="width:100%;justify-content:center;font-size:1rem;padding:18px">🐾 Send Enquiry</button>
          </div>
          <p class="dg-form-note">Marcus responds within 24 hours. Free 15-minute discovery call included. No payment required to enquire.</p>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ FOOTER ═══════════ -->
<div class="dg-footer-strip">
  <div class="dg-wrap">
    <p>🐾 <?php echo esc_html( $trainer['name'] ); ?> — CCPDT-KA Certified Dog Trainer · <?php echo esc_html( $trainer['location'] ); ?> · <?php echo date('Y'); ?></p>
  </div>
</div>

<script>
(function () {
  'use strict';

  /* ── Counters ──────────────────────────────────────────────────── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  const DURATION = 1800;

  function animateCounter(el) {
    const raw     = parseFloat(el.dataset.target);
    if (isNaN(raw)) return;
    const isFloat = el.dataset.float === '1';
    const suffix  = el.dataset.suffix || '';
    const start   = performance.now();

    (function tick(now) {
      const p   = Math.min((now - start) / DURATION, 1);
      const val = raw * easeOut(p);
      el.textContent = (isFloat ? val.toFixed(1) : Math.floor(val)) + suffix;
      if (p < 1) requestAnimationFrame(tick);
    })(start);
  }

  const counterObs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      animateCounter(e.target);
      counterObs.unobserve(e.target);
    });
  }, { threshold: 0.5 });

  document.querySelectorAll('.dg-counter__num[data-target]').forEach(el => counterObs.observe(el));

  /* ── FAQ Accordion ─────────────────────────────────────────────── */
  document.querySelectorAll('.dg-faq__q').forEach(q => {
    q.addEventListener('click', () => {
      const faq = q.closest('.dg-faq');
      const wasOpen = faq.classList.contains('open');
      document.querySelectorAll('.dg-faq.open').forEach(f => f.classList.remove('open'));
      if (!wasOpen) faq.classList.add('open');
    });
  });

  /* ── Scroll Reveal ─────────────────────────────────────────────── */
  const revealObs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('visible'); revealObs.unobserve(e.target); }
    });
  }, { threshold: 0.12 });
  document.querySelectorAll('.dg-reveal').forEach(el => revealObs.observe(el));

  /* ── Smooth scroll for anchor links ───────────────────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const target = document.querySelector(a.getAttribute('href'));
      if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    });
  });

  /* ── Form validation ───────────────────────────────────────────── */
  const form = document.querySelector('.dg-form-wrap form');
  if (form) {
    form.addEventListener('submit', e => {
      const nonce = form.querySelector('[name="tf_dg_nonce"]');
      if (!nonce || !nonce.value) { e.preventDefault(); alert('Security check failed. Please reload.'); }
    });
  }
})();
</script>

</body>
</html>
</div><!-- .dg-page -->
<?php get_footer(); ?>
