<?php
/**
 * Template Name: Driving Instructor
 *
 * Premium landing page for driving instructors and driving schools.
 * Palette: road black #1A1A2E / signal red #E63946 / asphalt grey #4A5568 / bright white #FFFFFF / amber #F59E0B
 * Fonts: Barlow Condensed + Inter
 * Namespace: --di-*
 *
 * @package ThemeFlex
 */

if ( ! defined( 'ABSPATH' ) ) exit;

srand( crc32( get_the_permalink() ) );

$di_services = [
    [ 'icon' => '🚗', 'title' => 'Beginner Lessons',     'desc' => 'Patient, structured lessons for complete beginners. We build confidence from your very first time in the driver\'s seat.' ],
    [ 'icon' => '🛣️', 'title' => 'Pass Plus',            'desc' => 'Six-module post-test course covering motorways, dual carriageways, all-weather driving, and rural roads.' ],
    [ 'icon' => '🌙', 'title' => 'Night Driving',        'desc' => 'Dedicated sessions covering night-time hazards, lighting, road marking visibility and junction confidence after dark.' ],
    [ 'icon' => '🅿️', 'title' => 'Manoeuvres Training',  'desc' => 'Master parallel parking, bay parking, turning in the road and emergency stops with calm, clear instruction.' ],
    [ 'icon' => '⚡', 'title' => 'Intensive Courses',    'desc' => 'Pass in as little as one week with our intensive crash courses — ideal if you need your licence quickly.' ],
    [ 'icon' => '♿', 'title' => 'Refresher Lessons',    'desc' => 'Regain confidence after a break from driving or following an accident with tailored refresher tuition.' ],
];

$di_lessons = [
    [ 'type' => 'Manual',    'duration' => '1 hour',   'price' => '£38', 'badge' => '' ],
    [ 'type' => 'Automatic', 'duration' => '1 hour',   'price' => '£40', 'badge' => '' ],
    [ 'type' => '2-Hour Block', 'duration' => '2 hours', 'price' => '£72', 'badge' => 'Best Value' ],
    [ 'type' => '10-Lesson Bundle', 'duration' => '10 × 1hr', 'price' => '£350', 'badge' => 'Most Popular' ],
    [ 'type' => 'Intensive Week', 'duration' => '30 hours', 'price' => '£980', 'badge' => 'Fastest Route' ],
    [ 'type' => 'Pass Plus',  'duration' => '6 modules', 'price' => '£280', 'badge' => '' ],
];

$di_stats = [
    [ 'val' => '92',  'suffix' => '%',  'label' => 'First-Time Pass Rate',  'float' => '' ],
    [ 'val' => '15',  'suffix' => 'yrs','label' => 'Teaching Experience',   'float' => '' ],
    [ 'val' => '4.9', 'suffix' => '★',  'label' => 'Google Rating',         'float' => '1' ],
    [ 'val' => '1800','suffix' => '+',  'label' => 'Pupils Passed',          'float' => '' ],
];

$di_steps = [
    [ 'num' => '01', 'title' => 'Free Assessment',     'desc' => 'Start with a free 20-minute assessment to gauge your current ability and plan the right number of lessons.' ],
    [ 'num' => '02', 'title' => 'Structured Lessons',  'desc' => 'Build skills systematically using the DVSA Driver\'s Record — always knowing exactly where you are.' ],
    [ 'num' => '03', 'title' => 'Mock Test',           'desc' => 'A full DVSA-standard mock test with detailed feedback before your real test booking.' ],
    [ 'num' => '04', 'title' => 'Test Day Support',    'desc' => 'Your instructor picks you up, warms you up with a pre-test lesson, and accompanies you to the test centre.' ],
    [ 'num' => '05', 'title' => 'Pass & Beyond',       'desc' => 'Pass Plus and motorway lessons available to develop your skills for a lifetime of safe, confident driving.' ],
];

$di_gallery = [
    [ 'label' => 'Dual-Control Corsa', 'c1' => '#E63946', 'c2' => '#b02030' ],
    [ 'label' => 'Town Driving',       'c1' => '#1A1A2E', 'c2' => '#2a2a4e' ],
    [ 'label' => 'Motorway Lesson',    'c1' => '#4A5568', 'c2' => '#2d3748' ],
    [ 'label' => 'Roundabout Practice','c1' => '#F59E0B', 'c2' => '#d48709' ],
    [ 'label' => 'Parking Manoeuvres', 'c1' => '#2E8B7A', 'c2' => '#1a6b5a' ],
    [ 'label' => 'Test Centre Run',    'c1' => '#6B52B0', 'c2' => '#4a3890' ],
];

$di_testimonials = [
    [ 'name' => 'Charlotte B.',   'loc' => 'Edinburgh', 'stars' => 5, 'text' => 'Passed first time! I was so nervous but my instructor made me feel completely at ease from lesson one. His calm, clear teaching style made all the difference.' ],
    [ 'name' => 'Mohammed A.',    'loc' => 'Glasgow',   'stars' => 5, 'text' => 'Failed twice with another school then switched here. Passed on my first attempt. The mock tests were incredibly helpful — the real thing felt easy by comparison.' ],
    [ 'name' => 'Sophie M.',      'loc' => 'Edinburgh', 'stars' => 5, 'text' => 'Brilliant intensive course — passed in 8 days! Clear structure, great feedback after every session. Genuinely the best driving instructor I could have asked for.' ],
];

// Road particles
$di_road_particles = [];
$road_chars = ['→','⟶','›','»','▸','▶'];
for ( $i = 0; $i < 12; $i++ ) {
    $di_road_particles[] = [
        'char'  => $road_chars[ array_rand( $road_chars ) ],
        'x'     => rand( 5, 95 ),
        'y'     => rand( 5, 90 ),
        'size'  => rand( 10, 22 ),
        'op'    => rand( 10, 35 ) / 100,
        'dur'   => rand( 50, 110 ) / 10,
        'delay' => rand( 0, 60 ) / 10,
        'depth' => rand( 10, 40 ) / 10,
    ];
}
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;600;700;800;900&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
/* =========================================================
   DRIVING INSTRUCTOR — CSS Custom Properties  (--di-* namespace)
   ========================================================= */
:root {
    --di-black:  #1A1A2E;
    --di-red:    #E63946;
    --di-red-d:  #b02030;
    --di-grey:   #4A5568;
    --di-asph:   #2d3748;
    --di-amber:  #F59E0B;
    --di-white:  #ffffff;
    --di-cream:  #F8F9FA;
    --di-light:  #EDF2F7;
    --di-text:   #2D3748;
    --di-muted:  #718096;
    --di-ff-head:'Barlow Condensed', 'Arial Narrow', sans-serif;
    --di-ff-body:'Inter', system-ui, sans-serif;
    --di-radius: 8px;
    --di-shadow: 0 8px 32px rgba(26,26,46,.12);
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{font-family:var(--di-ff-body);color:var(--di-text);background:var(--di-cream);-webkit-font-smoothing:antialiased}
img{max-width:100%;height:auto;display:block}
a{color:inherit;text-decoration:none}
ul{list-style:none}

/* ── Utility ── */
.di-container{max-width:1160px;margin:0 auto;padding:0 24px}
.di-section{padding:90px 0}
.di-eyebrow{font-family:var(--di-ff-body);font-size:.72rem;font-weight:700;letter-spacing:.18em;text-transform:uppercase;color:var(--di-red);margin-bottom:12px;display:block}
.di-heading{font-family:var(--di-ff-head);font-size:clamp(2.4rem,5vw,3.8rem);font-weight:800;line-height:1.05;color:var(--di-black);margin-bottom:20px;letter-spacing:.01em;text-transform:uppercase}
.di-heading--light{color:#fff}
.di-lead{font-size:1.05rem;line-height:1.75;color:var(--di-muted);max-width:640px}
.di-btn{display:inline-flex;align-items:center;gap:8px;padding:14px 32px;border-radius:4px;font-family:var(--di-ff-body);font-size:.9rem;font-weight:700;letter-spacing:.06em;cursor:pointer;transition:all .25s;border:2px solid transparent;text-transform:uppercase}
.di-btn--primary{background:var(--di-red);color:#fff;border-color:var(--di-red)}
.di-btn--primary:hover{background:var(--di-red-d);transform:translateY(-2px)}
.di-btn--outline{background:transparent;color:#fff;border-color:rgba(255,255,255,.6)}
.di-btn--outline:hover{background:rgba(255,255,255,.12);border-color:#fff}
.di-btn--dark{background:var(--di-black);color:#fff;border-color:var(--di-black)}
.di-btn--dark:hover{background:#0e0e1e;transform:translateY(-2px)}
.di-btn--amber{background:var(--di-amber);color:var(--di-black);border-color:var(--di-amber)}
.di-btn--amber:hover{background:#d48709;transform:translateY(-2px)}
.di-center{text-align:center}
.di-center .di-lead{margin-inline:auto}

/* =========================================================
   HERO — road scene
   ========================================================= */
.di-hero{position:relative;min-height:100vh;overflow:hidden;background:#0e0e1e;display:flex;align-items:center}

/* Sky */
.di-sky{position:absolute;inset:0;background:linear-gradient(180deg,#1a1a2e 0%,#16213e 45%,#0f3460 75%,#1a3a5a 100%)}

/* Stars */
.di-stars{position:absolute;top:0;left:0;right:0;height:55%;overflow:hidden}
.di-star{position:absolute;background:#fff;border-radius:50%;animation:di-twinkle var(--dur)s ease-in-out var(--delay)s infinite alternate}
@keyframes di-twinkle{0%{opacity:var(--op)}100%{opacity:var(--op2)}}

/* Road surface */
.di-road{position:absolute;bottom:0;left:0;right:0;height:38%;background:linear-gradient(180deg,#2d3748,#1a202c);perspective:600px}
.di-road::before{content:'';position:absolute;inset:0;background-image:repeating-linear-gradient(180deg,rgba(255,255,255,.08) 0,rgba(255,255,255,.08) 2px,transparent 2px,transparent 30px)}
.di-road__centre{position:absolute;top:0;bottom:0;left:50%;transform:translateX(-50%);width:6px;background:repeating-linear-gradient(180deg,#F59E0B 0,#F59E0B 20px,transparent 20px,transparent 40px);animation:di-road-scroll 1s linear infinite}
@keyframes di-road-scroll{from{background-position:0 0}to{background-position:0 40px}}
/* Road markings */
.di-road__kerb{position:absolute;top:0;left:0;right:0;height:6px;background:repeating-linear-gradient(90deg,#fff 0,#fff 16px,transparent 16px,transparent 32px)}

/* Horizon glow */
.di-horizon{position:absolute;bottom:38%;left:0;right:0;height:40px;background:linear-gradient(180deg,transparent,rgba(230,57,70,.12),transparent)}

/* Buildings silhouette */
.di-cityline{position:absolute;bottom:38%;left:0;right:0;height:180px;display:flex;align-items:flex-end;gap:0}
.di-building{position:absolute;bottom:0;background:#0a0a1a}
/* Windows in buildings */
.di-win{position:absolute;background:#F59E0B;border-radius:1px;opacity:.7}

/* Traffic lights */
.di-tlight{position:absolute;bottom:38%;right:22%}
.di-tlight__pole{width:6px;height:90px;background:linear-gradient(90deg,#555,#3a3a3a);margin:0 auto}
.di-tlight__box{width:22px;height:60px;background:#111;border-radius:4px;margin:0 auto;display:flex;flex-direction:column;align-items:center;justify-content:space-evenly;padding:4px 0;border:2px solid #222}
.di-tlight__lamp{width:14px;height:14px;border-radius:50%;position:relative}
.di-tlight__lamp--red{background:#E63946;box-shadow:0 0 8px #E63946}
.di-tlight__lamp--amber{background:#333}
.di-tlight__lamp--green{background:#333}

/* Car (CSS) */
.di-car{position:absolute;bottom:38%;left:50%;transform:translateX(-50%);pointer-events:none}
.di-car__body{width:140px;height:40px;background:linear-gradient(180deg,#E63946,#c02030);border-radius:8px 8px 4px 4px;position:relative;margin-bottom:0}
.di-car__roof{width:88px;height:30px;background:linear-gradient(180deg,#d02535,#E63946);border-radius:8px 8px 0 0;position:absolute;top:-28px;left:22px}
.di-car__roof::before{content:'L';position:absolute;top:4px;left:8px;font-size:10px;font-weight:900;color:rgba(255,255,255,.5);font-family:var(--di-ff-head)}
.di-car__windscreen{position:absolute;top:-22px;left:28px;width:36px;height:22px;background:rgba(160,210,255,.6);border-radius:4px 4px 0 0;border:1px solid rgba(255,255,255,.3)}
.di-car__window-r{position:absolute;top:-22px;right:20px;width:28px;height:20px;background:rgba(160,210,255,.5);border-radius:2px;border:1px solid rgba(255,255,255,.2)}
.di-car__headlight{position:absolute;right:-4px;top:8px;width:10px;height:14px;background:#fff;border-radius:2px;box-shadow:0 0 12px rgba(255,255,255,.8),0 0 30px rgba(255,255,255,.4)}
.di-car__taillight{position:absolute;left:-4px;top:10px;width:8px;height:12px;background:#E63946;border-radius:1px;box-shadow:0 0 8px #E63946}
.di-car__wheel{width:26px;height:26px;background:radial-gradient(circle,#555 30%,#222 30%,#222 60%,#888 60%,#888 70%,#222 70%);border-radius:50%;position:absolute;bottom:-13px}
.di-car__wheel--f{right:14px}
.di-car__wheel--r{left:14px}
.di-car__plate{position:absolute;bottom:4px;left:50%;transform:translateX(-50%);background:#F59E0B;padding:2px 8px;border-radius:2px;font-size:7px;font-weight:700;font-family:monospace;color:#000;letter-spacing:.1em}
.di-car__L-plate{position:absolute;top:-24px;right:-12px;width:16px;height:16px;background:#fff;border:2px solid #E63946;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:10px;color:#E63946;font-family:var(--di-ff-head)}

/* Road particles */
.di-rparticle{position:absolute;font-size:var(--sz);opacity:var(--op);color:rgba(255,255,255,.6);animation:di-float var(--dur)s ease-in-out var(--delay)s infinite alternate;pointer-events:none}
@keyframes di-float{0%{transform:translateX(0) translateY(0)}100%{transform:translateX(12px) translateY(-10px)}}

/* Overlay gradient for text */
.di-hero__overlay{position:absolute;inset:0;background:linear-gradient(90deg,rgba(14,14,30,.95) 0%,rgba(14,14,30,.75) 50%,rgba(14,14,30,.15) 100%)}

/* Hero content */
.di-hero__content{position:relative;z-index:10;padding:0 5%;max-width:580px}
.di-hero__eyebrow{display:inline-block;background:rgba(230,57,70,.2);border:1px solid rgba(230,57,70,.5);color:var(--di-red);font-size:.7rem;font-weight:700;letter-spacing:.18em;text-transform:uppercase;padding:6px 16px;border-radius:2px;margin-bottom:24px;backdrop-filter:blur(4px)}
.di-hero__title{font-family:var(--di-ff-head);font-size:clamp(3rem,7vw,5.5rem);font-weight:900;line-height:1;color:#fff;margin-bottom:8px;text-transform:uppercase;letter-spacing:.02em}
.di-hero__title span{color:var(--di-red)}
.di-hero__subtitle{font-family:var(--di-ff-body);font-size:1rem;font-weight:500;letter-spacing:.1em;text-transform:uppercase;color:var(--di-amber);margin-bottom:24px}
.di-hero__body{font-size:.95rem;line-height:1.75;color:rgba(255,255,255,.78);margin-bottom:36px;max-width:480px}
.di-hero__ctas{display:flex;flex-wrap:wrap;gap:12px}
.di-hero__badges{display:flex;flex-wrap:wrap;gap:10px;margin-top:28px}
.di-hero__badge{font-size:.78rem;color:rgba(255,255,255,.7);background:rgba(255,255,255,.06);padding:7px 14px;border-radius:3px;border:1px solid rgba(255,255,255,.12);backdrop-filter:blur(4px)}

/* Trust bar */
.di-trust{background:var(--di-red);padding:18px 0}
.di-trust__inner{display:flex;flex-wrap:wrap;justify-content:center;gap:6px 28px}
.di-trust__item{font-family:var(--di-ff-head);font-size:.9rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:rgba(255,255,255,.9);display:flex;align-items:center;gap:8px}
.di-trust__item::before{content:'✓';color:#fff}

/* =========================================================
   SERVICES
   ========================================================= */
.di-services{background:#fff}
.di-services__grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:24px;margin-top:52px}
.di-service-card{border-radius:var(--di-radius);padding:30px 24px;border:2px solid var(--di-light);transition:all .3s;position:relative;overflow:hidden}
.di-service-card::after{content:'';position:absolute;bottom:0;left:0;right:0;height:3px;background:var(--di-red);transform:scaleX(0);transition:transform .3s;transform-origin:left}
.di-service-card:hover{border-color:rgba(230,57,70,.2);box-shadow:var(--di-shadow);transform:translateY(-4px)}
.di-service-card:hover::after{transform:scaleX(1)}
.di-service-card__icon{font-size:2rem;margin-bottom:14px;display:block}
.di-service-card__title{font-family:var(--di-ff-head);font-size:1.3rem;font-weight:700;color:var(--di-black);margin-bottom:8px;text-transform:uppercase;letter-spacing:.02em}
.di-service-card__desc{font-size:.88rem;line-height:1.7;color:var(--di-muted)}

/* =========================================================
   PRICING
   ========================================================= */
.di-pricing{background:var(--di-cream)}
.di-pricing__grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-top:52px}
.di-price-card{background:#fff;border-radius:var(--di-radius);padding:28px 22px;border:2px solid var(--di-light);position:relative;transition:all .3s}
.di-price-card:hover{border-color:var(--di-red);box-shadow:var(--di-shadow)}
.di-price-card__badge{position:absolute;top:-12px;left:50%;transform:translateX(-50%);background:var(--di-red);color:#fff;font-size:.65rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;padding:4px 14px;border-radius:20px;white-space:nowrap}
.di-price-card__badge--amber{background:var(--di-amber);color:var(--di-black)}
.di-price-card__badge--dark{background:var(--di-black)}
.di-price-card__type{font-family:var(--di-ff-head);font-size:1.2rem;font-weight:700;color:var(--di-black);text-transform:uppercase;letter-spacing:.04em;margin-bottom:4px}
.di-price-card__duration{font-size:.8rem;color:var(--di-muted);margin-bottom:16px}
.di-price-card__price{font-family:var(--di-ff-head);font-size:2.6rem;font-weight:800;color:var(--di-red);line-height:1;margin-bottom:20px}

/* =========================================================
   APPROACH
   ========================================================= */
.di-approach{background:var(--di-black);padding:90px 0}
.di-approach .di-eyebrow{color:var(--di-amber)}
.di-approach__grid{display:grid;grid-template-columns:repeat(5,1fr);gap:20px;margin-top:52px}
.di-step{text-align:center;padding:28px 16px;position:relative}
.di-step__num{font-family:var(--di-ff-head);font-size:3.5rem;font-weight:900;color:rgba(230,57,70,.15);line-height:1;margin-bottom:-16px}
.di-step__title{font-family:var(--di-ff-head);font-size:1.1rem;font-weight:700;color:#fff;text-transform:uppercase;letter-spacing:.04em;margin-bottom:10px;position:relative;z-index:1}
.di-step__desc{font-size:.82rem;line-height:1.65;color:rgba(255,255,255,.6)}

/* =========================================================
   GALLERY
   ========================================================= */
.di-gallery{background:var(--di-light)}
.di-gallery__grid{display:grid;grid-template-columns:repeat(3,1fr);grid-template-rows:220px 220px;gap:10px;margin-top:52px}
.di-gallery__item{border-radius:var(--di-radius);overflow:hidden;position:relative;cursor:pointer}
.di-gallery__item:first-child{grid-column:span 2}
.di-gallery__item:nth-child(4){grid-column:span 2}
.di-gallery__art{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-family:var(--di-ff-head);font-size:.9rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.7);position:relative;overflow:hidden}
.di-gallery__art::before{content:'';position:absolute;inset:0;background:inherit;filter:brightness(.75);transition:filter .4s}
.di-gallery__item:hover .di-gallery__art::before{filter:brightness(.5)}
.di-gallery__label{position:relative;z-index:1;background:rgba(0,0,0,.4);padding:7px 16px;border-radius:3px}

/* =========================================================
   COUNTERS
   ========================================================= */
.di-counters{background:linear-gradient(135deg,var(--di-red),var(--di-red-d));padding:80px 0}
.di-counters__grid{display:grid;grid-template-columns:repeat(4,1fr);gap:40px;text-align:center}
.di-counter__val{font-family:var(--di-ff-head);font-size:clamp(3rem,5vw,4.5rem);font-weight:900;color:#fff;line-height:1}
.di-counter__label{font-family:var(--di-ff-body);font-size:.75rem;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.75);margin-top:8px}

/* =========================================================
   ABOUT
   ========================================================= */
.di-about{background:#fff}
.di-about__grid{display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:center}
.di-about__visual{position:relative}
.di-id-card{width:100%;max-width:340px;background:linear-gradient(160deg,var(--di-black),var(--di-asph));border-radius:12px;padding:32px 28px;box-shadow:var(--di-shadow),0 0 0 1px rgba(255,255,255,.06)}
.di-id-card__header{display:flex;align-items:center;gap:12px;margin-bottom:24px;padding-bottom:20px;border-bottom:1px solid rgba(255,255,255,.1)}
.di-id-card__logo{width:36px;height:36px;background:var(--di-red);border-radius:6px;display:flex;align-items:center;justify-content:center;font-family:var(--di-ff-head);font-weight:900;font-size:1rem;color:#fff}
.di-id-card__name{font-family:var(--di-ff-head);font-size:1rem;font-weight:700;color:#fff;letter-spacing:.04em}
.di-id-card__reg{font-size:.7rem;color:rgba(255,255,255,.5);margin-top:2px}
.di-id-photo{width:80px;height:96px;background:linear-gradient(180deg,#ffe0b2,#f0c080);border-radius:4px;margin:0 auto 16px;position:relative;overflow:hidden}
.di-id-photo::before{content:'';position:absolute;bottom:0;left:50%;transform:translateX(-50%);width:60px;height:50px;background:linear-gradient(180deg,#fff,#f0f0f0);border-radius:4px 4px 0 0}
.di-id-photo::after{content:'';position:absolute;bottom:28px;left:50%;transform:translateX(-50%);width:30px;height:30px;background:radial-gradient(circle,#f0c080,#d4a060);border-radius:50%}
.di-id-card__detail{font-size:.78rem;color:rgba(255,255,255,.7);margin-bottom:8px;display:flex;justify-content:space-between}
.di-id-card__detail span{color:#fff;font-weight:600}
.di-id-card__badges{display:flex;gap:8px;margin-top:20px;flex-wrap:wrap}
.di-id-card__chip{background:rgba(230,57,70,.2);border:1px solid rgba(230,57,70,.4);color:var(--di-red);font-size:.65rem;font-weight:700;letter-spacing:.08em;padding:4px 10px;border-radius:3px;text-transform:uppercase}
.di-about__content .di-lead{margin-bottom:20px}
.di-about__fact{display:flex;align-items:center;gap:12px;padding:14px 0;border-bottom:1px solid var(--di-light)}
.di-about__fact-icon{font-size:1.4rem;flex-shrink:0}
.di-about__fact-text{font-size:.9rem;color:var(--di-text);line-height:1.5}
.di-about__fact-text strong{color:var(--di-black);display:block;font-size:.8rem;text-transform:uppercase;letter-spacing:.06em;margin-bottom:2px}

/* =========================================================
   TESTIMONIALS
   ========================================================= */
.di-testimonials{background:var(--di-cream)}
.di-testi-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:52px}
.di-testi{background:#fff;border-radius:var(--di-radius);padding:30px 26px;border-left:4px solid var(--di-red);box-shadow:var(--di-shadow)}
.di-testi__stars{color:var(--di-amber);font-size:1rem;letter-spacing:2px;margin-bottom:14px}
.di-testi__text{font-size:.95rem;line-height:1.72;color:var(--di-grey);font-style:italic;margin-bottom:18px}
.di-testi__author{font-size:.82rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--di-black)}
.di-testi__loc{font-size:.78rem;color:var(--di-muted)}

/* =========================================================
   BOOKING
   ========================================================= */
.di-booking{background:linear-gradient(135deg,var(--di-black),var(--di-asph));padding:90px 0}
.di-booking .di-eyebrow{color:var(--di-amber)}
.di-booking__grid{display:grid;grid-template-columns:1fr 1.6fr;gap:60px;align-items:start;margin-top:52px}
.di-booking__highlight{background:rgba(230,57,70,.12);border:1px solid rgba(230,57,70,.3);border-radius:var(--di-radius);padding:24px;margin-bottom:24px}
.di-booking__highlight-title{font-family:var(--di-ff-head);font-size:1.1rem;font-weight:700;color:var(--di-red);text-transform:uppercase;letter-spacing:.04em;margin-bottom:8px}
.di-booking__highlight-text{font-size:.85rem;color:rgba(255,255,255,.7);line-height:1.6}
.di-booking__info-item{display:flex;align-items:flex-start;gap:14px;margin-bottom:22px}
.di-booking__info-icon{font-size:1.3rem;flex-shrink:0;margin-top:2px}
.di-booking__info-title{font-size:.82rem;font-weight:700;color:#fff;margin-bottom:4px;letter-spacing:.06em;text-transform:uppercase}
.di-booking__info-text{font-size:.83rem;line-height:1.6;color:rgba(255,255,255,.6)}
.di-form{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:var(--di-radius);padding:38px 34px;backdrop-filter:blur(8px)}
.di-form__row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.di-form__group{margin-bottom:16px;display:flex;flex-direction:column;gap:6px}
.di-form__group label{font-size:.72rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.7)}
.di-form__group input,
.di-form__group select,
.di-form__group textarea{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.16);border-radius:4px;padding:11px 14px;font-family:var(--di-ff-body);font-size:.9rem;color:#fff;outline:none;transition:border-color .25s;width:100%}
.di-form__group input::placeholder,
.di-form__group textarea::placeholder{color:rgba(255,255,255,.35)}
.di-form__group input:focus,
.di-form__group select:focus,
.di-form__group textarea:focus{border-color:var(--di-red);background:rgba(255,255,255,.11)}
.di-form__group select option{background:#1a202c;color:#fff}
.di-form__group textarea{resize:vertical;min-height:90px}
.di-form__submit{width:100%;padding:15px;background:var(--di-red);border:none;border-radius:4px;font-family:var(--di-ff-head);font-size:1.1rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#fff;cursor:pointer;transition:all .25s;margin-top:6px}
.di-form__submit:hover{background:var(--di-red-d);transform:translateY(-2px)}
.di-form__consent{font-size:.72rem;color:rgba(255,255,255,.45);margin-top:10px;line-height:1.6;text-align:center}

/* =========================================================
   FOOTER
   ========================================================= */
.di-footer{background:#0a0a18;padding:26px 0}
.di-footer__inner{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:16px}
.di-footer__copy{font-size:.78rem;color:rgba(255,255,255,.4)}
.di-footer__links{display:flex;gap:20px}
.di-footer__links a{font-size:.78rem;color:rgba(255,255,255,.4);transition:color .2s}
.di-footer__links a:hover{color:var(--di-red)}

/* =========================================================
   RESPONSIVE
   ========================================================= */
@media(max-width:960px){
    .di-pricing__grid{grid-template-columns:repeat(2,1fr)}
    .di-approach__grid{grid-template-columns:repeat(3,1fr)}
    .di-about__grid,.di-booking__grid{grid-template-columns:1fr}
    .di-testi-grid{grid-template-columns:1fr}
    .di-counters__grid{grid-template-columns:repeat(2,1fr)}
    .di-gallery__grid{grid-template-columns:1fr 1fr}
    .di-gallery__item:first-child,.di-gallery__item:nth-child(4){grid-column:span 1}
}
@media(max-width:600px){
    .di-section{padding:60px 0}
    .di-form__row{grid-template-columns:1fr}
    .di-pricing__grid{grid-template-columns:1fr}
    .di-approach__grid{grid-template-columns:repeat(2,1fr)}
}
</style>
<?php get_header(); ?>
<div class="di-page">
>

<!-- ═══════════════════════════════════════════════
     HERO
═══════════════════════════════════════════════ -->
<section class="di-hero" id="di-hero">

    <!-- Night sky scene -->
    <div class="di-sky" aria-hidden="true">

        <!-- Stars -->
        <div class="di-stars">
            <?php for ($s = 0; $s < 60; $s++):
                $sx = rand(0,100); $sy = rand(0,100);
                $ss = rand(1,3);
                $op1 = rand(40,90)/100; $op2 = rand(10,50)/100;
                $sdur = rand(15,40)/10; $sdel = rand(0,60)/10;
            ?>
            <div class="di-star" style="left:<?php echo $sx; ?>%;top:<?php echo $sy; ?>%;width:<?php echo $ss; ?>px;height:<?php echo $ss; ?>px;--op:<?php echo $op1; ?>;--op2:<?php echo $op2; ?>;--dur:<?php echo $sdur; ?>;--delay:<?php echo $sdel; ?>s"></div>
            <?php endfor; ?>
        </div>

        <!-- City silhouette -->
        <div class="di-cityline" aria-hidden="true">
            <?php
            $buildings = [
                ['left'=>'5%',  'width'=>'80px',  'height'=>'120px'],
                ['left'=>'12%', 'width'=>'60px',  'height'=>'160px'],
                ['left'=>'20%', 'width'=>'100px', 'height'=>'90px'],
                ['left'=>'28%', 'width'=>'70px',  'height'=>'140px'],
                ['left'=>'36%', 'width'=>'55px',  'height'=>'200px'],
                ['left'=>'45%', 'width'=>'90px',  'height'=>'110px'],
                ['left'=>'55%', 'width'=>'65px',  'height'=>'170px'],
                ['left'=>'63%', 'width'=>'110px', 'height'=>'130px'],
                ['left'=>'72%', 'width'=>'75px',  'height'=>'190px'],
                ['left'=>'80%', 'width'=>'85px',  'height'=>'100px'],
                ['left'=>'88%', 'width'=>'60px',  'height'=>'150px'],
            ];
            foreach ($buildings as $b):
                // Windows
                $wincols = (int)(intval($b['width'])/20);
                $winrows = (int)(intval($b['height'])/22);
            ?>
            <div class="di-building" style="left:<?php echo $b['left']; ?>;width:<?php echo $b['width']; ?>;height:<?php echo $b['height']; ?>">
                <?php for ($wr=0;$wr<$winrows;$wr++): for ($wc=0;$wc<$wincols;$wc++):
                    $lit = rand(0,1); if (!$lit) continue; ?>
                <div class="di-win" style="left:<?php echo 8+$wc*20; ?>px;top:<?php echo 10+$wr*20; ?>px;width:8px;height:10px"></div>
                <?php endfor; endfor; ?>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Traffic lights -->
        <div class="di-tlight" aria-hidden="true">
            <div class="di-tlight__box">
                <div class="di-tlight__lamp di-tlight__lamp--red"></div>
                <div class="di-tlight__lamp di-tlight__lamp--amber"></div>
                <div class="di-tlight__lamp di-tlight__lamp--green"></div>
            </div>
            <div class="di-tlight__pole"></div>
        </div>

        <!-- Horizon glow -->
        <div class="di-horizon"></div>

        <!-- Road -->
        <div class="di-road">
            <div class="di-road__kerb"></div>
            <div class="di-road__centre"></div>
        </div>

        <!-- Car -->
        <div class="di-car" aria-label="Red L-plate driving school car">
            <div class="di-car__body">
                <div class="di-car__roof">
                    <div class="di-car__windscreen"></div>
                    <div class="di-car__window-r"></div>
                    <div class="di-car__L-plate">L</div>
                </div>
                <div class="di-car__headlight"></div>
                <div class="di-car__taillight"></div>
                <div class="di-car__wheel di-car__wheel--f"></div>
                <div class="di-car__wheel di-car__wheel--r"></div>
                <div class="di-car__plate">AB21 CDR</div>
            </div>
        </div>

        <!-- Floating particles -->
        <?php foreach ( $di_road_particles as $rp ) : ?>
        <div class="di-rparticle"
             style="left:<?php echo $rp['x']; ?>%;top:<?php echo $rp['y']; ?>%;--sz:<?php echo $rp['size']; ?>px;--op:<?php echo $rp['op']; ?>;--dur:<?php echo $rp['dur']; ?>;--delay:<?php echo $rp['delay']; ?>s"
             data-depth="<?php echo $rp['depth']; ?>"><?php echo $rp['char']; ?></div>
        <?php endforeach; ?>
    </div>

    <!-- Dark overlay -->
    <div class="di-hero__overlay" aria-hidden="true"></div>

    <!-- Hero content -->
    <div class="di-container">
        <div class="di-hero__content">
            <span class="di-hero__eyebrow">DVSA Approved Driving Instructor · ADI Grade A</span>
            <h1 class="di-hero__title">Drive with<br><span>Confidence.</span><br>Pass First Time.</h1>
            <p class="di-hero__subtitle">Professional Driving Instruction · Edinburgh & Lothians</p>
            <p class="di-hero__body">
                With a 92% first-time pass rate and over 1,800 pupils passed, we provide patient, structured driving lessons designed to build real confidence — not just pass the test. Manual, automatic, intensive and refresher courses available.
            </p>
            <div class="di-hero__ctas">
                <a href="#di-booking" class="di-btn di-btn--primary">Book a Free Assessment</a>
                <a href="#di-pricing" class="di-btn di-btn--outline">View Lesson Prices</a>
            </div>
            <div class="di-hero__badges">
                <span class="di-hero__badge">🏅 DVSA Grade A ADI</span>
                <span class="di-hero__badge">⭐ 4.9 Google Rating</span>
                <span class="di-hero__badge">🚗 Dual-Control Vehicle</span>
                <span class="di-hero__badge">📋 Free First Assessment</span>
            </div>
        </div>
    </div>
</section>

<!-- Trust bar -->
<div class="di-trust">
    <div class="di-container">
        <div class="di-trust__inner">
            <?php
            $di_trust = ['92% First-Time Pass Rate','DVSA Approved Grade A','Free Cancellation 24hrs Notice','Manual & Automatic','Flexible Hours 7am–9pm','Insurance Included'];
            foreach ($di_trust as $ti): ?>
            <span class="di-trust__item"><?php echo esc_html($ti); ?></span>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ═══════════════════════════════════════════════
     SERVICES
═══════════════════════════════════════════════ -->
<section class="di-section di-services" id="di-services">
    <div class="di-container">
        <div class="di-center">
            <span class="di-eyebrow">What We Offer</span>
            <h2 class="di-heading">Driving Lessons & Courses</h2>
            <p class="di-lead">From complete beginners to experienced drivers wanting to refresh — we have a course tailored to your exact needs and learning style.</p>
        </div>
        <div class="di-services__grid">
            <?php foreach ( $di_services as $svc ) : ?>
            <article class="di-service-card">
                <span class="di-service-card__icon"><?php echo esc_html( $svc['icon'] ); ?></span>
                <h3 class="di-service-card__title"><?php echo esc_html( $svc['title'] ); ?></h3>
                <p class="di-service-card__desc"><?php echo esc_html( $svc['desc'] ); ?></p>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     PRICING
═══════════════════════════════════════════════ -->
<section class="di-section di-pricing" id="di-pricing">
    <div class="di-container">
        <div class="di-center">
            <span class="di-eyebrow">Transparent Pricing</span>
            <h2 class="di-heading">Lesson Prices</h2>
            <p class="di-lead">No hidden extras. The price you see is the price you pay — including dual-control vehicle, fuel and full DVSA-standard instruction.</p>
        </div>
        <div class="di-pricing__grid">
            <?php foreach ( $di_lessons as $lesson ) :
                $badge_class = $lesson['badge'] === 'Most Popular' ? 'di-price-card__badge' : ($lesson['badge'] === 'Best Value' ? 'di-price-card__badge di-price-card__badge--amber' : 'di-price-card__badge di-price-card__badge--dark');
            ?>
            <div class="di-price-card">
                <?php if ( $lesson['badge'] ) : ?>
                <div class="<?php echo esc_attr($badge_class); ?>"><?php echo esc_html($lesson['badge']); ?></div>
                <?php endif; ?>
                <div class="di-price-card__type"><?php echo esc_html($lesson['type']); ?></div>
                <div class="di-price-card__duration"><?php echo esc_html($lesson['duration']); ?></div>
                <div class="di-price-card__price"><?php echo esc_html($lesson['price']); ?></div>
                <a href="#di-booking" class="di-btn di-btn--primary" style="width:100%;justify-content:center;font-size:.82rem;padding:11px 20px">Book Now</a>
            </div>
            <?php endforeach; ?>
        </div>
        <p style="text-align:center;color:var(--di-muted);font-size:.82rem;margin-top:24px">Block bookings and intensive courses available. <a href="#di-booking" style="color:var(--di-red);font-weight:600">Contact us for bespoke packages →</a></p>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     APPROACH
═══════════════════════════════════════════════ -->
<section class="di-approach" id="di-approach">
    <div class="di-container">
        <div class="di-center">
            <span class="di-eyebrow">The Journey</span>
            <h2 class="di-heading di-heading--light">From Learner to Driver</h2>
            <p class="di-lead" style="color:rgba(255,255,255,.65);margin-inline:auto">A proven five-step programme using the DVSA Driver's Record — so you always know exactly where you are and what's next.</p>
        </div>
        <div class="di-approach__grid">
            <?php foreach ( $di_steps as $step ) : ?>
            <div class="di-step">
                <div class="di-step__num"><?php echo esc_html($step['num']); ?></div>
                <h3 class="di-step__title"><?php echo esc_html($step['title']); ?></h3>
                <p class="di-step__desc"><?php echo esc_html($step['desc']); ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     GALLERY
═══════════════════════════════════════════════ -->
<section class="di-section di-gallery" id="di-gallery">
    <div class="di-container">
        <div class="di-center">
            <span class="di-eyebrow">On the Road</span>
            <h2 class="di-heading">Learning in Action</h2>
        </div>
        <div class="di-gallery__grid">
            <?php foreach ( $di_gallery as $gitem ) : ?>
            <div class="di-gallery__item">
                <div class="di-gallery__art" style="background:linear-gradient(135deg,<?php echo esc_attr($gitem['c1']); ?>,<?php echo esc_attr($gitem['c2']); ?>)">
                    <span class="di-gallery__label"><?php echo esc_html($gitem['label']); ?></span>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     COUNTERS
═══════════════════════════════════════════════ -->
<section class="di-counters" aria-label="School statistics">
    <div class="di-container">
        <div class="di-counters__grid">
            <?php foreach ( $di_stats as $stat ) : ?>
            <div class="di-counter">
                <div class="di-counter__val" data-target="<?php echo esc_attr($stat['val']); ?>" data-suffix="<?php echo esc_attr($stat['suffix']); ?>"<?php echo $stat['float'] ? ' data-float="1"' : ''; ?>>0</div>
                <div class="di-counter__label"><?php echo esc_html($stat['label']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     ABOUT
═══════════════════════════════════════════════ -->
<section class="di-section di-about" id="di-about">
    <div class="di-container">
        <div class="di-about__grid">
            <div class="di-about__visual">
                <div class="di-id-card">
                    <div class="di-id-card__header">
                        <div class="di-id-card__logo">ADI</div>
                        <div>
                            <div class="di-id-card__name">DVSA APPROVED</div>
                            <div class="di-id-card__reg">Registration No. 12345678 · Grade A</div>
                        </div>
                    </div>
                    <div class="di-id-photo"></div>
                    <div class="di-id-card__detail">Name <span>James Robertson</span></div>
                    <div class="di-id-card__detail">Grade <span>A (Highest)</span></div>
                    <div class="di-id-card__detail">Transmission <span>Manual & Automatic</span></div>
                    <div class="di-id-card__detail">Qualified Since <span>2009</span></div>
                    <div class="di-id-card__detail">Pupils Passed <span>1,800+</span></div>
                    <div class="di-id-card__badges">
                        <span class="di-id-card__chip">DVSA Grade A</span>
                        <span class="di-id-card__chip">DIA Member</span>
                        <span class="di-id-card__chip">Pass Plus</span>
                    </div>
                </div>
            </div>
            <div class="di-about__content">
                <span class="di-eyebrow">Your Instructor</span>
                <h2 class="di-heading">James Robertson<br><small style="font-size:.45em;color:var(--di-muted);letter-spacing:.04em;text-transform:none;font-weight:400">DVSA Approved Driving Instructor · Grade A</small></h2>
                <p class="di-lead" style="margin-bottom:24px">
                    With 15 years' experience and over 1,800 pupils passed, James is one of Edinburgh's most experienced and highly rated driving instructors. His calm, patient approach and structured teaching method consistently deliver outstanding pass rates.
                </p>
                <div class="di-about__fact">
                    <span class="di-about__fact-icon">🎓</span>
                    <div class="di-about__fact-text"><strong>DVSA Grade A Instructor</strong>Awarded the highest possible grade by the Driver and Vehicle Standards Agency.</div>
                </div>
                <div class="di-about__fact">
                    <span class="di-about__fact-icon">🚗</span>
                    <div class="di-about__fact-text"><strong>Dual-Control Vauxhall Corsa</strong>Modern, comfortable, fully insured dual-control vehicle — manual and automatic available.</div>
                </div>
                <div class="di-about__fact">
                    <span class="di-about__fact-icon">📋</span>
                    <div class="di-about__fact-text"><strong>DVSA Driver's Record</strong>Structured lesson-by-lesson tracking so you always know your progress towards test standard.</div>
                </div>
                <div class="di-about__fact" style="border-bottom:none">
                    <span class="di-about__fact-icon">💬</span>
                    <div class="di-about__fact-text"><strong>Anxiety-Friendly Teaching</strong>Specialising in nervous learners and those who have failed previous tests with other schools.</div>
                </div>
                <div style="margin-top:28px">
                    <a href="#di-booking" class="di-btn di-btn--primary">Book with James →</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     TESTIMONIALS
═══════════════════════════════════════════════ -->
<section class="di-section di-testimonials" id="di-testimonials">
    <div class="di-container">
        <div class="di-center">
            <span class="di-eyebrow">Success Stories</span>
            <h2 class="di-heading">Pupils Who Passed</h2>
        </div>
        <div class="di-testi-grid">
            <?php foreach ( $di_testimonials as $testi ) : ?>
            <div class="di-testi">
                <div class="di-testi__stars"><?php echo str_repeat('★',$testi['stars']); ?></div>
                <p class="di-testi__text">"<?php echo esc_html($testi['text']); ?>"</p>
                <div class="di-testi__author"><?php echo esc_html($testi['name']); ?></div>
                <div class="di-testi__loc"><?php echo esc_html($testi['loc']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     BOOKING
═══════════════════════════════════════════════ -->
<section class="di-booking" id="di-booking">
    <div class="di-container">
        <div class="di-center">
            <span class="di-eyebrow">Get Started</span>
            <h2 class="di-heading di-heading--light">Book Your Lessons</h2>
            <p class="di-lead" style="color:rgba(255,255,255,.65);margin-inline:auto">Start with a free no-obligation assessment — we'll gauge your current ability and recommend the right package for you.</p>
        </div>
        <div class="di-booking__grid">
            <div>
                <div class="di-booking__highlight">
                    <div class="di-booking__highlight-title">🎉 Free First Assessment</div>
                    <div class="di-booking__highlight-text">All new pupils start with a free 20-minute assessment so we can recommend the right lesson package. No charge, no commitment.</div>
                </div>
                <div class="di-booking__info-item">
                    <span class="di-booking__info-icon">📍</span>
                    <div>
                        <div class="di-booking__info-title">Collection Area</div>
                        <div class="di-booking__info-text">Edinburgh, Leith, Musselburgh, Portobello, Dalkeith, Bonnyrigg</div>
                    </div>
                </div>
                <div class="di-booking__info-item">
                    <span class="di-booking__info-icon">🕐</span>
                    <div>
                        <div class="di-booking__info-title">Available Hours</div>
                        <div class="di-booking__info-text">Monday–Saturday 7am–8pm<br>Sunday by arrangement</div>
                    </div>
                </div>
                <div class="di-booking__info-item">
                    <span class="di-booking__info-icon">📞</span>
                    <div>
                        <div class="di-booking__info-title">Call or Text</div>
                        <div class="di-booking__info-text">07700 900 000<br>Usually responds within 2 hours</div>
                    </div>
                </div>
            </div>
            <div>
                <form class="di-form" method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
                    <?php wp_nonce_field('tf_di_booking','tf_di_nonce'); ?>
                    <input type="hidden" name="action" value="tf_di_booking">
                    <div class="di-form__row">
                        <div class="di-form__group">
                            <label for="di-name">Full Name *</label>
                            <input type="text" id="di-name" name="di_name" required placeholder="Your full name">
                        </div>
                        <div class="di-form__group">
                            <label for="di-email">Email *</label>
                            <input type="email" id="di-email" name="di_email" required placeholder="your@email.com">
                        </div>
                    </div>
                    <div class="di-form__row">
                        <div class="di-form__group">
                            <label for="di-phone">Phone Number *</label>
                            <input type="tel" id="di-phone" name="di_phone" required placeholder="07700 900000">
                        </div>
                        <div class="di-form__group">
                            <label for="di-age">Age</label>
                            <input type="number" id="di-age" name="di_age" min="16" max="99" placeholder="e.g. 17">
                        </div>
                    </div>
                    <div class="di-form__row">
                        <div class="di-form__group">
                            <label for="di-transmission">Transmission *</label>
                            <select id="di-transmission" name="di_transmission" required>
                                <option value="">Select…</option>
                                <option>Manual</option>
                                <option>Automatic</option>
                                <option>Not Sure Yet</option>
                            </select>
                        </div>
                        <div class="di-form__group">
                            <label for="di-experience">Current Experience *</label>
                            <select id="di-experience" name="di_experience" required>
                                <option value="">Select…</option>
                                <option>Complete Beginner</option>
                                <option>Some Previous Lessons</option>
                                <option>Test Failure — Refresher</option>
                                <option>Returning Driver</option>
                                <option>Pass Plus / Post-Test</option>
                            </select>
                        </div>
                    </div>
                    <div class="di-form__group">
                        <label for="di-course">Interested Course</label>
                        <select id="di-course" name="di_course">
                            <option value="">Select course type…</option>
                            <option>Single Lessons (pay as you go)</option>
                            <option>10-Lesson Block Bundle</option>
                            <option>Intensive Crash Course</option>
                            <option>Pass Plus</option>
                            <option>Night Driving Course</option>
                            <option>Refresher Lessons</option>
                        </select>
                    </div>
                    <div class="di-form__group">
                        <label for="di-message">Anything Else?</label>
                        <textarea id="di-message" name="di_message" placeholder="Tell us anything useful — test history, anxiety, preferred lesson times, postcode for collection…"></textarea>
                    </div>
                    <button type="submit" class="di-form__submit">Request Free Assessment →</button>
                    <p class="di-form__consent">We'll respond within 2 hours during working hours. Your details are kept strictly confidential.</p>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     FOOTER
═══════════════════════════════════════════════ -->
<footer class="di-footer">
    <div class="di-container">
        <div class="di-footer__inner">
            <p class="di-footer__copy">&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All rights reserved. DVSA Approved Driving Instructor.</p>
            <nav class="di-footer__links" aria-label="Footer navigation">
                <a href="<?php echo esc_url(home_url('/privacy-policy')); ?>">Privacy Policy</a>
                <a href="<?php echo esc_url(home_url('/terms')); ?>">Terms</a>
                <a href="<?php echo esc_url(home_url('/accessibility')); ?>">Accessibility</a>
            </nav>
        </div>
    </div>
</footer>


<script>
(function(){
    /* ── Animated Counters ── */
    const counters = document.querySelectorAll('.di-counter__val[data-target]');
    const easeOut = t => 1 - Math.pow(1 - t, 3);
    const io = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (!entry.isIntersecting) return;
            const el = entry.target;
            const target = parseFloat(el.dataset.target);
            const suffix = el.dataset.suffix || '';
            const isFloat = el.dataset.float === '1';
            if (isNaN(target)) return;
            const dur = 1800;
            let start = null;
            function tick(ts) {
                if (!start) start = ts;
                const prog = Math.min((ts - start) / dur, 1);
                const val = target * easeOut(prog);
                el.textContent = (isFloat ? val.toFixed(1) : Math.round(val)) + suffix;
                if (prog < 1) requestAnimationFrame(tick);
            }
            requestAnimationFrame(tick);
            io.unobserve(el);
        });
    }, { threshold: 0.4 });
    counters.forEach(c => io.observe(c));

    /* ── Parallax on hero particles ── */
    const particles = document.querySelectorAll('.di-rparticle');
    document.getElementById('di-hero')?.addEventListener('mousemove', e => {
        const rect = e.currentTarget.getBoundingClientRect();
        const dx = (e.clientX - rect.width / 2) / rect.width;
        const dy = (e.clientY - rect.height / 2) / rect.height;
        particles.forEach(p => {
            const d = parseFloat(p.dataset.depth) || 20;
            p.style.transform = `translate(${dx * d}px, ${dy * d}px)`;
        });
    });

    /* ── Animated road scroll on car scene ── */
    // Traffic light cycle animation
    const lamps = document.querySelectorAll('.di-tlight__lamp');
    if (lamps.length === 3) {
        let phase = 0; // 0=red, 1=amber, 2=green
        const colors = ['#E63946','#F59E0B','#22c55e'];
        const labels = [0,1,2];
        function cycleLights() {
            lamps.forEach((l,i) => {
                l.style.background = i === phase ? colors[i] : '#333';
                l.style.boxShadow = i === phase ? `0 0 8px ${colors[i]}` : 'none';
            });
            const delays = [4000, 1500, 5000];
            setTimeout(() => {
                phase = (phase + 1) % 3;
                cycleLights();
            }, delays[phase]);
        }
        cycleLights();
    }
})();
</script>
</body>
</html>
</div><!-- .di-page -->
<?php get_footer(); ?>
