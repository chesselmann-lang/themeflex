<?php
/**
 * Template Name: E-Commerce Brand Homepage
 * Template Post Type: page
 *
 * Premium Fashion / Lifestyle E-Commerce template — Velour
 * Namespace: --ec-*  |  Fonts: Playfair Display + Nunito Sans
 * Palette: Noir #111111 / Blush #F2D9D9 / Dusty Rose #C4969A / Sage #7D9B76 / Cream #FAF6F1
 */
defined('ABSPATH') || exit;
get_header();

srand(crc32('velour-ecommerce'));
$ec_featured = [
    ['Noir Blazer','Limited Edition','£285','#111111','#FAF6F1','NB'],
    ['Blush Slip','Bestseller','£89','#F2D9D9','#111111','BS'],
    ['Sage Wrap','New Season','£142','#7D9B76','#FAF6F1','SW'],
    ['Ivory Trench','Staff Pick','£320','#FAF6F1','#111111','IT'],
];
$ec_categories = ['All','Tops','Dresses','Outerwear','Accessories','Sale'];
$ec_benefits   = [
    ['🚚','Free Delivery','Free UK delivery on all orders over £80. Express next-day available.'],
    ['🔄','Easy Returns','30-day free returns on all full-price items. No questions asked.'],
    ['🌿','Sustainable','GOTS certified fabrics. Carbon-neutral shipping since 2022.'],
    ['💳','Flexible Pay','Pay in 3 interest-free with Klarna. Pay in full and save 5%.'],
];
?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,700;1,400;1,500&family=Nunito+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>
:root {
  --ec-noir:   #111111;
  --ec-blush:  #F2D9D9;
  --ec-rose:   #C4969A;
  --ec-sage:   #7D9B76;
  --ec-cream:  #FAF6F1;
  --ec-light:  #F7F3EF;
  --ec-muted:  #7A7A7A;
  --ec-border: rgba(17,17,17,.1);
  --ec-serif:  'Playfair Display', Georgia, serif;
  --ec-sans:   'Nunito Sans', system-ui, sans-serif;
  --ec-r:      2px;
  --ec-trans:  all .3s cubic-bezier(.4,0,.2,1);
}
.ec-page *, .ec-page *::before, .ec-page *::after { box-sizing:border-box; margin:0; padding:0; }
.ec-page { font-family:var(--ec-sans); background:var(--ec-cream); color:var(--ec-noir); overflow-x:hidden; }
.ec-page a { color:inherit; text-decoration:none; }
.ec-page button { cursor:pointer; border:none; background:none; font-family:inherit; }
.ec-wrap { max-width:1280px; margin:0 auto; padding:0 2rem; }
.ec-wrap--wide { max-width:1400px; margin:0 auto; padding:0 2rem; }
.ec-section { padding:5.5rem 0; }
.ec-section--dark { background:var(--ec-noir); color:var(--ec-cream); }
.ec-section--light { background:var(--ec-light); }
.ec-section--blush { background:var(--ec-blush); }

.ec-eyebrow { font-family:var(--ec-sans); font-size:.65rem; font-weight:700; letter-spacing:.25em; text-transform:uppercase; color:var(--ec-rose); margin-bottom:.6rem; display:block; }
.ec-h1 { font-family:var(--ec-serif); font-size:clamp(3rem,7vw,6.5rem); font-weight:400; line-height:.95; letter-spacing:-.01em; }
.ec-h2 { font-family:var(--ec-serif); font-size:clamp(2rem,4.5vw,3.8rem); font-weight:400; line-height:1.1; }
.ec-h3 { font-family:var(--ec-serif); font-size:1.5rem; font-weight:500; }
.ec-lead { font-size:1rem; line-height:1.8; color:var(--ec-muted); max-width:52ch; }

.ec-btn {
  display:inline-flex; align-items:center; gap:.5rem;
  padding:.8rem 2rem; border-radius:0;
  font-family:var(--ec-sans); font-size:.78rem; font-weight:700; letter-spacing:.1em; text-transform:uppercase;
  transition:var(--ec-trans);
}
.ec-btn--dark { background:var(--ec-noir); color:var(--ec-cream); }
.ec-btn--dark:hover { background:#333; }
.ec-btn--rose { background:var(--ec-rose); color:#fff; }
.ec-btn--rose:hover { background:var(--ec-ec-rose, #B08690); filter:brightness(1.1); }
.ec-btn--outline { border:1.5px solid var(--ec-noir); color:var(--ec-noir); }
.ec-btn--outline:hover { background:var(--ec-noir); color:var(--ec-cream); }
.ec-btn--outline-light { border:1.5px solid rgba(250,246,241,.4); color:var(--ec-cream); }
.ec-btn--outline-light:hover { background:var(--ec-cream); color:var(--ec-noir); }

.ec-reveal { opacity:0; transform:translateY(20px); transition:opacity .65s ease, transform .65s ease; }
.ec-reveal.ec-visible { opacity:1; transform:none; }

/* NAV */
.ec-nav {
  position:fixed; top:0; left:0; right:0; z-index:100;
  background:rgba(250,246,241,.95); backdrop-filter:blur(12px);
  border-bottom:1px solid var(--ec-border);
}
.ec-nav__top {
  display:flex; align-items:center; justify-content:space-between;
  padding:.9rem 3rem;
}
.ec-nav__logo { font-family:var(--ec-serif); font-size:1.6rem; font-weight:700; letter-spacing:.05em; }
.ec-nav__logo span { color:var(--ec-rose); }
.ec-nav__actions { display:flex; gap:1.5rem; align-items:center; }
.ec-nav__action { font-size:.78rem; font-weight:600; letter-spacing:.06em; color:var(--ec-muted); transition:color .25s; }
.ec-nav__action:hover { color:var(--ec-noir); }
.ec-nav__cart {
  background:var(--ec-noir); color:var(--ec-cream);
  padding:.55rem 1.2rem;
  font-size:.72rem; font-weight:700; letter-spacing:.1em; text-transform:uppercase;
  position:relative;
}
.ec-nav__cart-count {
  position:absolute; top:-6px; right:-6px;
  width:16px; height:16px; border-radius:50%;
  background:var(--ec-rose); color:#fff;
  font-size:.55rem; font-weight:700;
  display:flex; align-items:center; justify-content:center;
}
.ec-nav__cats {
  display:flex; justify-content:center; gap:2.5rem;
  padding:.5rem 3rem;
  border-top:1px solid var(--ec-border);
  list-style:none;
}
.ec-nav__cats a { font-size:.75rem; font-weight:600; letter-spacing:.1em; text-transform:uppercase; color:var(--ec-muted); transition:color .25s; }
.ec-nav__cats a:hover { color:var(--ec-noir); }

/* HERO */
.ec-hero {
  min-height:100vh; padding-top:100px;
  display:grid; grid-template-columns:1fr 1fr;
  background:var(--ec-cream);
  overflow:hidden;
}
.ec-hero__left {
  display:flex; flex-direction:column; justify-content:center;
  padding:5rem 4rem 5rem 5rem;
}
.ec-hero__left .ec-h1 { margin-bottom:1.5rem; }
.ec-hero__left .ec-lead { margin-bottom:2rem; }
.ec-hero__actions { display:flex; gap:1rem; flex-wrap:wrap; margin-bottom:2.5rem; }
.ec-hero__trust { display:flex; gap:2rem; }
.ec-hero__trust-item { font-size:.72rem; letter-spacing:.08em; text-transform:uppercase; color:var(--ec-muted); display:flex; align-items:center; gap:.35rem; }
.ec-hero__trust-item::before { content:'✓'; color:var(--ec-sage); }

/* CSS fashion editorial right */
.ec-hero__right {
  position:relative;
  background:linear-gradient(160deg, #EEE5DE 0%, #E8DDD6 100%);
  overflow:hidden;
}
/* decorative circles */
.ec-hero__circle {
  position:absolute; border-radius:50%; pointer-events:none;
}
.ec-hero__circle--1 { width:320px; height:320px; top:-80px; right:-80px; background:rgba(196,150,154,.2); }
.ec-hero__circle--2 { width:200px; height:200px; bottom:80px; left:-60px; background:rgba(125,155,118,.15); }
/* product card in hero */
.ec-hero__product {
  position:absolute; bottom:10%; left:50%; transform:translateX(-50%);
  width:220px;
  background:#FAF6F1;
  box-shadow:0 20px 60px rgba(17,17,17,.2);
}
.ec-hero__product-img { height:280px; background:linear-gradient(160deg, #111111 0%, #2A2A2A 100%); position:relative; overflow:hidden; }
.ec-hero__product-img::before { /* garment silhouette */
  content:'';
  position:absolute; top:20px; left:50%; transform:translateX(-50%);
  width:100px; height:180px;
  background:rgba(250,246,241,.12);
  clip-path:polygon(30%0%,70%0%,85%100%,15%100%);
}
.ec-hero__product-img::after { /* label */
  content:'VELOUR';
  position:absolute; bottom:20px; right:12px;
  font-family:var(--ec-serif); font-size:.7rem; letter-spacing:.2em; color:rgba(250,246,241,.4);
  writing-mode:vertical-lr;
}
.ec-hero__product-info { padding:1rem 1.2rem; }
.ec-hero__product-name { font-family:var(--ec-serif); font-size:.95rem; margin-bottom:.2rem; }
.ec-hero__product-price { font-size:.8rem; font-weight:700; color:var(--ec-rose); }

/* floating size badge */
.ec-hero__size-badge {
  position:absolute; top:30%; right:8%;
  background:#FAF6F1;
  padding:.5rem .9rem; box-shadow:0 4px 16px rgba(17,17,17,.12);
  font-size:.7rem; font-weight:700; letter-spacing:.1em; text-transform:uppercase;
  animation:ec-float 4s ease-in-out infinite;
}
.ec-hero__size-badge strong { color:var(--ec-rose); }

/* floating discount badge */
.ec-hero__discount {
  position:absolute; top:18%; left:8%;
  width:70px; height:70px; border-radius:50%;
  background:var(--ec-rose); color:#fff;
  display:flex; flex-direction:column; align-items:center; justify-content:center;
  font-family:var(--ec-serif);
  animation:ec-float 3.5s ease-in-out infinite;
  animation-delay:.5s;
}
.ec-hero__discount-val { font-size:1.3rem; font-weight:700; line-height:1; }
.ec-hero__discount-label { font-size:.5rem; letter-spacing:.08em; text-transform:uppercase; }

@keyframes ec-float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }

/* editorial typography overlay */
.ec-hero__editorial {
  position:absolute; top:15%; right:5%;
  font-family:var(--ec-serif); font-size:5rem; font-weight:700; font-style:italic;
  color:rgba(17,17,17,.05); line-height:1; letter-spacing:-.02em;
  pointer-events:none;
}

/* ANNOUNCEMENT BAR */
.ec-announcement {
  background:var(--ec-noir); color:var(--ec-cream);
  text-align:center; padding:.65rem 2rem;
  font-size:.75rem; letter-spacing:.1em; text-transform:uppercase;
  font-weight:600;
}
.ec-announcement span { color:var(--ec-rose); }

/* FEATURED GRID */
.ec-featured-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:1.5rem; }
.ec-product-card { position:relative; cursor:pointer; }
.ec-product-card__img {
  aspect-ratio:3/4;
  position:relative; overflow:hidden;
  margin-bottom:1rem;
}
.ec-product-card__bg { position:absolute; inset:0; transition:transform .5s ease; }
.ec-product-card:hover .ec-product-card__bg { transform:scale(1.04); }
.ec-product-card__badge {
  position:absolute; top:1rem; left:1rem; z-index:1;
  background:var(--ec-rose); color:#fff;
  font-size:.6rem; font-weight:700; letter-spacing:.1em; text-transform:uppercase;
  padding:.25rem .7rem;
}
.ec-product-card__wishlist {
  position:absolute; top:1rem; right:1rem; z-index:1;
  width:32px; height:32px; border-radius:50%;
  background:rgba(250,246,241,.9);
  display:flex; align-items:center; justify-content:center;
  font-size:.9rem;
  opacity:0; transition:opacity .3s;
}
.ec-product-card:hover .ec-product-card__wishlist { opacity:1; }
.ec-product-card__quick {
  position:absolute; bottom:0; left:0; right:0; z-index:1;
  background:var(--ec-noir); color:var(--ec-cream);
  text-align:center; padding:.7rem;
  font-size:.7rem; font-weight:700; letter-spacing:.12em; text-transform:uppercase;
  transform:translateY(100%); transition:transform .3s;
}
.ec-product-card:hover .ec-product-card__quick { transform:none; }
.ec-product-card__name { font-family:var(--ec-serif); font-size:1.05rem; margin-bottom:.2rem; }
.ec-product-card__price { font-size:.85rem; font-weight:700; }
.ec-product-card__price .ec-old { text-decoration:line-through; color:var(--ec-muted); margin-right:.5rem; font-weight:400; }
.ec-product-card__colors { display:flex; gap:.3rem; margin-top:.35rem; }
.ec-product-card__color { width:14px; height:14px; border-radius:50%; border:1.5px solid rgba(17,17,17,.1); cursor:pointer; }
.ec-product-card__color:hover { border-color:var(--ec-noir); }

/* CATEGORY STRIP */
.ec-cat-strip { display:grid; grid-template-columns:repeat(3,1fr); gap:3px; }
.ec-cat-item { position:relative; overflow:hidden; cursor:pointer; aspect-ratio:4/3; }
.ec-cat-item__bg { position:absolute; inset:0; transition:transform .5s; }
.ec-cat-item:hover .ec-cat-item__bg { transform:scale(1.05); }
.ec-cat-item__label {
  position:absolute; bottom:1.5rem; left:1.5rem;
  font-family:var(--ec-serif); font-size:1.5rem; font-weight:700;
  color:#fff; text-shadow:0 2px 8px rgba(0,0,0,.3);
}
.ec-cat-item__link {
  position:absolute; bottom:1.5rem; right:1.5rem;
  font-size:.65rem; font-weight:700; letter-spacing:.1em; text-transform:uppercase;
  color:#fff; border-bottom:1px solid rgba(255,255,255,.5);
  padding-bottom:.2rem;
}

/* BENEFITS */
.ec-benefits { display:grid; grid-template-columns:repeat(4,1fr); gap:2rem; }
.ec-benefit { text-align:center; padding:2rem; }
.ec-benefit__icon { font-size:2rem; margin-bottom:1rem; display:block; }
.ec-benefit__title { font-family:var(--ec-serif); font-size:1.05rem; margin-bottom:.5rem; }
.ec-benefit__text { font-size:.83rem; line-height:1.7; color:var(--ec-muted); }

/* EDITORIAL FEATURE */
.ec-editorial { display:grid; grid-template-columns:1fr 1fr; gap:0; }
.ec-editorial__img {
  min-height:500px; position:relative;
  background:linear-gradient(135deg, #C4969A 0%, #8A6A6E 100%);
  overflow:hidden;
}
.ec-editorial__img::before {
  content:'S/S 2025';
  position:absolute; top:40%; left:50%; transform:translate(-50%,-50%);
  font-family:var(--ec-serif); font-size:4rem; font-weight:700; font-style:italic;
  color:rgba(255,255,255,.12); white-space:nowrap; letter-spacing:-.02em;
}
/* CSS model figure in editorial */
.ec-editorial__figure { position:absolute; bottom:0; left:50%; transform:translateX(-50%); display:flex; flex-direction:column; align-items:center; }
.ec-ed-fig__head { width:44px; height:48px; background:#C4956A; border-radius:50%; position:relative; }
.ec-ed-fig__head::before { content:''; position:absolute; top:-10px; left:-2px; right:-2px; height:18px; background:#1A0E06; border-radius:50% 50% 0 0; }
.ec-ed-fig__body { width:56px; height:100px; background:linear-gradient(180deg, #F2D9D9 0%, #E8CECE 100%); margin-top:2px; position:relative; }
.ec-ed-fig__body::before { content:''; position:absolute; top:12px; left:8px; right:8px; height:60px; background:rgba(196,150,154,.3); border-radius:2px; }
.ec-ed-fig__skirt { width:80px; height:120px; background:linear-gradient(180deg, #C4969A 0%, #A07070 100%); clip-path:polygon(10%0%,90%0%,100%100%,0%100%); }
.ec-ed-fig__arm-l { position:absolute; top:14px; left:-16px; width:14px; height:60px; background:#F2D9D9; border-radius:7px; transform:rotate(-12deg); transform-origin:top center; }
.ec-ed-fig__arm-r { position:absolute; top:14px; right:-14px; width:12px; height:54px; background:#C4956A; border-radius:6px; transform:rotate(10deg); transform-origin:top center; }

.ec-editorial__content { background:var(--ec-noir); color:var(--ec-cream); display:flex; flex-direction:column; justify-content:center; padding:5rem; }
.ec-editorial__content .ec-eyebrow { color:var(--ec-rose); }
.ec-editorial__content .ec-h2 { margin-bottom:1.2rem; }
.ec-editorial__content .ec-lead { color:rgba(250,246,241,.6); margin-bottom:2rem; }
.ec-editorial__content .ec-lead { max-width:44ch; }

/* TESTIMONIALS */
.ec-testis { display:grid; grid-template-columns:repeat(3,1fr); gap:1.5rem; }
.ec-testi { background:var(--ec-cream); border:1px solid var(--ec-border); padding:2rem; }
.ec-testi__stars { color:var(--ec-rose); font-size:.8rem; letter-spacing:.1em; margin-bottom:.75rem; }
.ec-testi__text { font-family:var(--ec-serif); font-size:1rem; font-style:italic; line-height:1.75; color:var(--ec-noir); margin-bottom:1.2rem; }
.ec-testi__author { display:flex; align-items:center; gap:.75rem; }
.ec-testi__avatar { width:36px; height:36px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-family:var(--ec-serif); font-weight:700; font-size:.9rem; flex-shrink:0; }
.ec-testi__name { font-size:.85rem; font-weight:700; display:block; }
.ec-testi__meta { font-size:.72rem; color:var(--ec-muted); }

/* EMAIL SIGNUP */
.ec-signup {
  background:var(--ec-noir); color:var(--ec-cream);
  padding:5rem 0; text-align:center;
}
.ec-signup .ec-h2 { margin-bottom:1rem; }
.ec-signup .ec-lead { margin:0 auto 2rem; color:rgba(250,246,241,.6); }
.ec-signup__form { display:flex; gap:0; max-width:460px; margin:0 auto; }
.ec-signup__input {
  flex:1; padding:.9rem 1.2rem;
  background:rgba(255,255,255,.08); border:1px solid rgba(255,255,255,.15);
  border-right:none;
  color:var(--ec-cream); font-family:var(--ec-sans); font-size:.9rem;
}
.ec-signup__input::placeholder { color:rgba(250,246,241,.35); }
.ec-signup__input:focus { outline:none; border-color:var(--ec-rose); }
.ec-signup__btn {
  padding:.9rem 1.8rem;
  background:var(--ec-rose); color:#fff;
  font-family:var(--ec-sans); font-size:.75rem; font-weight:700; letter-spacing:.1em; text-transform:uppercase;
  cursor:pointer; border:none; transition:background .25s;
}
.ec-signup__btn:hover { background:#B08690; }
.ec-signup__note { font-size:.72rem; color:rgba(250,246,241,.35); margin-top:.75rem; }

/* FAQ */
.ec-faq-grid { display:grid; grid-template-columns:1fr 1fr; gap:0 4rem; }
.ec-faq { border-bottom:1px solid var(--ec-border); }
.ec-faq__q { width:100%; display:flex; justify-content:space-between; align-items:center; padding:1.2rem 0; font-size:.95rem; font-weight:600; color:var(--ec-noir); text-align:left; background:none; border:none; transition:color .25s; cursor:pointer; }
.ec-faq__q:hover { color:var(--ec-rose); }
.ec-faq__icon { color:var(--ec-rose); font-size:1.2rem; transition:transform .3s; flex-shrink:0; }
.ec-faq.ec-open .ec-faq__icon { transform:rotate(45deg); }
.ec-faq__a { max-height:0; overflow:hidden; transition:max-height .4s ease; }
.ec-faq__a-inner { padding-bottom:1.1rem; font-size:.85rem; line-height:1.75; color:var(--ec-muted); }

/* CONTACT / ABOUT STRIP */
.ec-about-strip { display:grid; grid-template-columns:2fr 1fr; gap:5rem; align-items:center; }
.ec-about-strip .ec-h2 { margin-bottom:1rem; }
.ec-about-strip .ec-lead { margin-bottom:2rem; }
.ec-about-strip__logos { display:flex; flex-direction:column; gap:1rem; }
.ec-about__cert { padding:1.2rem; border:1px solid var(--ec-border); display:flex; align-items:center; gap:1rem; }
.ec-about__cert-icon { font-size:1.4rem; }
.ec-about__cert-text { font-size:.82rem; line-height:1.5; }
.ec-about__cert-title { font-weight:700; display:block; }

/* FOOTER */
.ec-footer { background:var(--ec-noir); color:var(--ec-cream); padding:4rem 0 2rem; border-top:1px solid rgba(255,255,255,.06); }
.ec-footer__top { display:grid; grid-template-columns:2fr 1fr 1fr 1fr; gap:3rem; margin-bottom:3rem; }
.ec-footer__brand .ec-nav__logo { display:inline-block; margin-bottom:1rem; color:var(--ec-cream); }
.ec-footer__brand p { font-size:.82rem; line-height:1.7; color:rgba(250,246,241,.45); max-width:28ch; }
.ec-footer__col-title { font-size:.65rem; font-weight:700; letter-spacing:.18em; text-transform:uppercase; color:var(--ec-rose); margin-bottom:.75rem; }
.ec-footer__links { list-style:none; display:flex; flex-direction:column; gap:.45rem; }
.ec-footer__links a { font-size:.82rem; color:rgba(250,246,241,.45); transition:color .25s; }
.ec-footer__links a:hover { color:var(--ec-cream); }
.ec-footer__bottom { padding-top:2rem; border-top:1px solid rgba(255,255,255,.06); display:flex; justify-content:space-between; align-items:center; font-size:.75rem; color:rgba(250,246,241,.25); }
.ec-footer__payment { display:flex; gap:.5rem; }
.ec-payment-pill { font-size:.65rem; font-weight:700; padding:.2rem .55rem; border:1px solid rgba(255,255,255,.15); border-radius:3px; color:rgba(250,246,241,.5); }

/* responsive */
@media(max-width:1024px){
  .ec-hero { grid-template-columns:1fr; min-height:auto; }
  .ec-hero__right { height:70vw; }
  .ec-featured-grid { grid-template-columns:repeat(2,1fr); }
  .ec-editorial { grid-template-columns:1fr; }
  .ec-editorial__img { min-height:360px; }
  .ec-about-strip { grid-template-columns:1fr; }
  .ec-footer__top { grid-template-columns:1fr 1fr; }
}
@media(max-width:768px){
  .ec-nav__cats { display:none; }
  .ec-benefits { grid-template-columns:1fr 1fr; }
  .ec-cat-strip { grid-template-columns:1fr; }
  .ec-featured-grid { grid-template-columns:1fr 1fr; }
  .ec-faq-grid { grid-template-columns:1fr; }
  .ec-testis { grid-template-columns:1fr; }
  .ec-footer__top { grid-template-columns:1fr; }
  .ec-footer__bottom { flex-direction:column; gap:.75rem; }
}
</style>

<div class="ec-page">

<!-- ANNOUNCEMENT ─────────────────────────────────── -->
<div class="ec-announcement" role="status">
  <?php esc_html_e('New Season In ✦ Free UK Delivery Over £80 ✦ Use','themeflex'); ?>
  <span><?php esc_html_e('VELOUR10','themeflex'); ?></span>
  <?php esc_html_e('for 10% off your first order','themeflex'); ?>
</div>

<!-- NAV ─────────────────────────────────────────── -->
<nav class="ec-nav" role="navigation" aria-label="<?php esc_attr_e('Main navigation','themeflex'); ?>">
  <div class="ec-nav__top">
    <a href="<?php echo esc_url(home_url('/')); ?>" class="ec-nav__logo">VELOUR<span>.</span></a>
    <div class="ec-nav__actions">
      <a href="#" class="ec-nav__action"><?php esc_html_e('Sign In','themeflex'); ?></a>
      <a href="#" class="ec-nav__action"><?php esc_html_e('Wishlist','themeflex'); ?> ♡</a>
      <a href="#" class="ec-nav__cart">
        <?php esc_html_e('Bag','themeflex'); ?>
        <span class="ec-nav__cart-count" aria-label="<?php esc_attr_e('2 items in bag','themeflex'); ?>">2</span>
      </a>
    </div>
  </div>
  <ul class="ec-nav__cats">
    <?php foreach ($ec_categories as $cat): ?>
    <li><a href="#"><?php echo esc_html($cat); ?></a></li>
    <?php endforeach; ?>
    <li><a href="#" style="color:var(--ec-rose);"><?php esc_html_e('New In','themeflex'); ?></a></li>
  </ul>
</nav>

<!-- HERO ─────────────────────────────────────────── -->
<section class="ec-hero" aria-label="<?php esc_attr_e('Hero','themeflex'); ?>">
  <div class="ec-hero__left">
    <span class="ec-eyebrow"><?php esc_html_e('Spring / Summer 2025','themeflex'); ?></span>
    <h1 class="ec-h1">
      <?php esc_html_e('Effortless','themeflex'); ?><br>
      <em style="font-style:italic;color:var(--ec-rose)"><?php esc_html_e('Elegance,','themeflex'); ?></em><br>
      <?php esc_html_e('Every Day.','themeflex'); ?>
    </h1>
    <p class="ec-lead"><?php esc_html_e('Velour is a contemporary womenswear label designed for the way you actually live. Sustainably made, beautifully cut, and priced honestly.','themeflex'); ?></p>
    <div class="ec-hero__actions">
      <a href="#collection" class="ec-btn ec-btn--dark"><?php esc_html_e('Shop New In','themeflex'); ?></a>
      <a href="#editorial"  class="ec-btn ec-btn--outline"><?php esc_html_e('View Lookbook','themeflex'); ?></a>
    </div>
    <div class="ec-hero__trust">
      <?php foreach ([esc_html__('Free Returns','themeflex'),esc_html__('Ethical Fabrics','themeflex'),esc_html__('Pay in 3','themeflex')] as $t): ?>
      <span class="ec-hero__trust-item"><?php echo $t; ?></span>
      <?php endforeach; ?>
    </div>
  </div>
  <div class="ec-hero__right" aria-hidden="true">
    <div class="ec-hero__circle ec-hero__circle--1"></div>
    <div class="ec-hero__circle ec-hero__circle--2"></div>
    <div class="ec-hero__editorial">Velour</div>
    <div class="ec-hero__discount">
      <span class="ec-hero__discount-val">-15%</span>
      <span class="ec-hero__discount-label"><?php esc_html_e('New arrivals','themeflex'); ?></span>
    </div>
    <div class="ec-hero__size-badge"><?php esc_html_e('Sizes','themeflex'); ?> <strong>XS–3XL</strong></div>
    <div class="ec-hero__product">
      <div class="ec-hero__product-img"></div>
      <div class="ec-hero__product-info">
        <p class="ec-hero__product-name"><?php esc_html_e('Noir Tailored Blazer','themeflex'); ?></p>
        <p class="ec-hero__product-price">£285</p>
      </div>
    </div>
  </div>
</section>

<!-- BENEFITS ──────────────────────────────────────── -->
<section class="ec-section ec-section--light" aria-label="<?php esc_attr_e('Shopping benefits','themeflex'); ?>">
  <div class="ec-wrap">
    <div class="ec-benefits">
      <?php foreach ($ec_benefits as $i => [$icon, $title, $text]): ?>
      <div class="ec-benefit ec-reveal" style="transition-delay:<?php echo $i*.08; ?>s">
        <span class="ec-benefit__icon" aria-hidden="true"><?php echo $icon; ?></span>
        <h3 class="ec-benefit__title"><?php echo esc_html($title); ?></h3>
        <p class="ec-benefit__text"><?php echo esc_html($text); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- FEATURED COLLECTION ───────────────────────────── -->
<section id="collection" class="ec-section" aria-labelledby="ec-coll-title">
  <div class="ec-wrap">
    <header style="display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:2.5rem;" class="ec-reveal">
      <div>
        <span class="ec-eyebrow"><?php esc_html_e('New Season','themeflex'); ?></span>
        <h2 class="ec-h2" id="ec-coll-title"><?php esc_html_e('Fresh Arrivals','themeflex'); ?></h2>
      </div>
      <a href="#" class="ec-btn ec-btn--outline"><?php esc_html_e('View All','themeflex'); ?></a>
    </header>
    <div class="ec-featured-grid">
      <?php foreach ($ec_featured as $i => [$name, $badge, $price, $bg, $fg, $init]): ?>
      <div class="ec-product-card ec-reveal" style="transition-delay:<?php echo $i*.07; ?>s">
        <div class="ec-product-card__img">
          <div class="ec-product-card__bg" style="background:linear-gradient(160deg,<?php echo esc_attr($bg); ?> 0%,<?php echo adjustShade($bg, -15); ?> 100%);"></div>
          <span class="ec-product-card__badge"><?php echo esc_html($badge); ?></span>
          <span class="ec-product-card__wishlist" aria-label="<?php esc_attr_e('Add to wishlist','themeflex'); ?>">♡</span>
          <div class="ec-product-card__quick"><?php esc_html_e('Quick Add','themeflex'); ?></div>
          <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-family:var(--ec-serif);font-size:3rem;font-weight:700;color:<?php echo esc_attr($fg); ?>;opacity:.2;"><?php echo esc_html($init); ?></div>
        </div>
        <h3 class="ec-product-card__name"><?php echo esc_html($name); ?></h3>
        <div class="ec-product-card__price"><?php echo esc_html($price); ?></div>
        <div class="ec-product-card__colors" aria-label="<?php esc_attr_e('Available colours','themeflex'); ?>">
          <?php foreach (['#111111','#F2D9D9','#7D9B76'] as $c): ?>
          <span class="ec-product-card__color" style="background:<?php echo esc_attr($c); ?>;" aria-label="<?php echo esc_attr($c); ?>"></span>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- CATEGORY STRIP ────────────────────────────────── -->
<section class="ec-section" style="padding:0;" aria-label="<?php esc_attr_e('Shop by category','themeflex'); ?>">
  <div class="ec-cat-strip">
    <?php
    $ec_cats_display = [
      ['Dresses','linear-gradient(135deg,#C4969A 0%,#8A6A6E 100%)'],
      ['Outerwear','linear-gradient(135deg,#111111 0%,#2A2A2A 100%)'],
      ['Accessories','linear-gradient(135deg,#7D9B76 0%,#5A7853 100%)'],
    ];
    foreach ($ec_cats_display as [$name, $bg]):
    ?>
    <div class="ec-cat-item">
      <div class="ec-cat-item__bg" style="background:<?php echo $bg; ?>;"></div>
      <span class="ec-cat-item__label"><?php echo esc_html($name); ?></span>
      <span class="ec-cat-item__link"><?php esc_html_e('Shop Now','themeflex'); ?></span>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- EDITORIAL FEATURE ─────────────────────────────── -->
<section id="editorial" class="ec-editorial ec-reveal" aria-label="<?php esc_attr_e('S/S 2025 editorial','themeflex'); ?>">
  <div class="ec-editorial__img">
    <div class="ec-editorial__figure">
      <div class="ec-ed-fig__head"></div>
      <div class="ec-ed-fig__body">
        <div class="ec-ed-fig__arm-l"></div>
        <div class="ec-ed-fig__arm-r"></div>
      </div>
      <div class="ec-ed-fig__skirt"></div>
    </div>
  </div>
  <div class="ec-editorial__content">
    <span class="ec-eyebrow"><?php esc_html_e('Lookbook','themeflex'); ?></span>
    <h2 class="ec-h2"><?php esc_html_e('The S/S 2025 Collection: Soften','themeflex'); ?></h2>
    <p class="ec-lead"><?php esc_html_e('Our new season is built around contrast: crisp tailoring softened with floaty separates, neutral palettes disrupted by a single shot of rose. Shop the full collection or explore the editorial.','themeflex'); ?></p>
    <div style="display:flex;gap:1rem;flex-wrap:wrap;">
      <a href="#collection" class="ec-btn ec-btn--rose"><?php esc_html_e('Shop the Edit','themeflex'); ?></a>
      <a href="#" class="ec-btn ec-btn--outline-light"><?php esc_html_e('View Lookbook','themeflex'); ?></a>
    </div>
  </div>
</section>

<!-- TESTIMONIALS ──────────────────────────────────── -->
<section class="ec-section ec-section--light" aria-labelledby="ec-testi-title">
  <div class="ec-wrap">
    <header style="text-align:center;margin-bottom:3rem;" class="ec-reveal">
      <span class="ec-eyebrow"><?php esc_html_e('Customer Love','themeflex'); ?></span>
      <h2 class="ec-h2" id="ec-testi-title"><?php esc_html_e('What Our Customers Say','themeflex'); ?></h2>
    </header>
    <div class="ec-testis">
      <?php
      $ec_ts=[
        ['#C4969A','A','Anna M.','Verified Buyer · Silk Cami','I\'ve ordered from Velour three times now and every piece has been exactly as described — quality that you can actually feel. The cami is the most-complimented thing I own.'],
        ['#7D9B76','L','Laura K.','Verified Buyer · Sage Wrap Dress','Returned my usual size and they handled it flawlessly — refund landed in two days. The replacement fit perfectly. Honestly the best returns experience in fashion retail.'],
        ['#111111','S','Sophie D.','Verified Buyer · Noir Blazer','I wear this blazer to work, on weekends, and on dates. It is the most versatile piece of clothing I own. The cut is immaculate. Worth every penny.'],
      ];
      foreach($ec_ts as $i=>[$bg,$init,$name,$role,$text]):?>
      <div class="ec-testi ec-reveal" style="transition-delay:<?php echo $i*.1;?>s">
        <div class="ec-testi__stars" aria-label="<?php esc_attr_e('5 stars','themeflex');?>">★★★★★</div>
        <p class="ec-testi__text">"<?php echo esc_html($text);?>"</p>
        <div class="ec-testi__author">
          <div class="ec-testi__avatar" style="background:<?php echo esc_attr($bg);?>;color:<?php echo $bg==='#111111'?'#FAF6F1':'#111111';?>"><?php echo esc_html($init);?></div>
          <div><span class="ec-testi__name"><?php echo esc_html($name);?></span><span class="ec-testi__meta"><?php echo esc_html($role);?></span></div>
        </div>
      </div>
      <?php endforeach;?>
    </div>
  </div>
</section>

<!-- ABOUT / SUSTAINABILITY ─────────────────────────── -->
<section class="ec-section" aria-labelledby="ec-about-title">
  <div class="ec-wrap">
    <div class="ec-about-strip">
      <div class="ec-reveal">
        <span class="ec-eyebrow"><?php esc_html_e('Our Story','themeflex');?></span>
        <h2 class="ec-h2" id="ec-about-title"><?php esc_html_e('Fashion That Respects the Planet','themeflex');?></h2>
        <p class="ec-lead"><?php esc_html_e('Velour was founded in 2018 with a simple brief: make clothes women genuinely want to wear, made in ways we can be proud of. Every piece is produced in Portugal and Turkey under fair-wage agreements. Our fabrics are GOTS certified and our shipping has been carbon-neutral since 2022.','themeflex');?></p>
        <div style="margin-top:1.5rem;display:flex;gap:1rem;">
          <a href="#" class="ec-btn ec-btn--outline"><?php esc_html_e('Our Commitments','themeflex');?></a>
          <a href="#" class="ec-btn ec-btn--dark"><?php esc_html_e('About the Brand','themeflex');?></a>
        </div>
      </div>
      <div class="ec-about-strip__logos ec-reveal" style="transition-delay:.12s">
        <?php foreach([['🌿','GOTS Certified','Organic textile standard — 100% of our cotton and linen.'],['🏭','Made in Europe','Portugal & Turkey — audited factories, fair wages.'],['📦','Carbon Neutral','Scope 1+2 emissions offset since 2022.'],['♻️','Circular Returns','All returned items repaired or donated — zero landfill.']] as [$icon,$title,$text]):?>
        <div class="ec-about__cert">
          <span class="ec-about__cert-icon"><?php echo $icon;?></span>
          <div class="ec-about__cert-text"><span class="ec-about__cert-title"><?php echo esc_html($title);?></span><?php echo esc_html($text);?></div>
        </div>
        <?php endforeach;?>
      </div>
    </div>
  </div>
</section>

<!-- SECOND COLLECTION ROW ─────────────────────────── -->
<section class="ec-section ec-section--dark" aria-labelledby="ec-sale-title">
  <div class="ec-wrap">
    <header style="display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:2.5rem;" class="ec-reveal">
      <div>
        <span class="ec-eyebrow"><?php esc_html_e('End of Season','themeflex');?></span>
        <h2 class="ec-h2" id="ec-sale-title" style="color:var(--ec-cream);"><?php esc_html_e('Sale — Up to 50% Off','themeflex');?></h2>
      </div>
      <a href="#" class="ec-btn ec-btn--outline-light"><?php esc_html_e('View All Sale','themeflex');?></a>
    </header>
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:1.5rem;">
      <?php
      $ec_sale_items=[
        ['Silk Shirt','£45','£90','#F2D9D9','#111111'],
        ['Linen Trousers','£62','£125','#7D9B76','#FAF6F1'],
        ['Cashmere Beanie','£28','£65','#111111','#FAF6F1'],
        ['Wrap Midi','£55','£110','#C4969A','#FAF6F1'],
      ];
      foreach($ec_sale_items as $i=>[$name,$sale,$was,$bg,$fg]):?>
      <div class="ec-product-card ec-reveal" style="transition-delay:<?php echo $i*.07;?>s">
        <div class="ec-product-card__img">
          <div class="ec-product-card__bg" style="background:linear-gradient(160deg,<?php echo esc_attr($bg);?> 0%,<?php echo adjustShade($bg,-20);?> 100%);"></div>
          <span class="ec-product-card__badge" style="background:var(--ec-sage);"><?php esc_html_e('Sale','themeflex');?></span>
          <span class="ec-product-card__wishlist">♡</span>
          <div class="ec-product-card__quick" style="background:var(--ec-rose);"><?php esc_html_e('Quick Add','themeflex');?></div>
        </div>
        <h3 class="ec-product-card__name" style="color:var(--ec-cream);"><?php echo esc_html($name);?></h3>
        <div class="ec-product-card__price" style="color:var(--ec-rose);"><?php echo esc_html($sale);?> <span class="ec-old" style="color:rgba(250,246,241,.4)"><?php echo esc_html($was);?></span></div>
      </div>
      <?php endforeach;?>
    </div>
    <div style="margin-top:3rem;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);padding:2rem;display:flex;align-items:center;justify-content:space-between;gap:2rem;">
      <div>
        <p style="font-family:var(--ec-serif);font-size:1.3rem;font-weight:500;color:var(--ec-cream);margin-bottom:.4rem;"><?php esc_html_e('Extra 10% off with code INSIDER','themeflex');?></p>
        <p style="font-size:.83rem;color:rgba(250,246,241,.5);"><?php esc_html_e('For newsletter subscribers only. Applied automatically at checkout.','themeflex');?></p>
      </div>
      <a href="#" class="ec-btn ec-btn--rose"><?php esc_html_e('Shop Sale','themeflex');?></a>
    </div>
  </div>
</section>

<!-- STYLE GUIDE / HOW TO STYLE ────────────────────── -->
<section class="ec-section" aria-labelledby="ec-style-title">
  <div class="ec-wrap">
    <header style="text-align:center;margin-bottom:3.5rem;" class="ec-reveal">
      <span class="ec-eyebrow"><?php esc_html_e('Style Notes','themeflex');?></span>
      <h2 class="ec-h2" id="ec-style-title"><?php esc_html_e('How to Wear It','themeflex');?></h2>
      <p class="ec-lead" style="margin:1rem auto 0;"><?php esc_html_e('Three outfits from our S/S edit — mix, match, and make them your own.','themeflex');?></p>
    </header>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:2rem;">
      <?php
      $ec_styles=[
        ['The Office Edit','Tailored blazer + straight-leg trousers + leather mule. Understated, deliberate, done.','#111111','#FAF6F1'],
        ['Weekend Ease','Linen wide-leg + cotton tee + basket bag. The uniform of the girl who makes it look effortless.','#F2D9D9','#111111'],
        ['Evening Out','Silk slip + blazer thrown over + heeled boot. Classic formula, endlessly adaptable.','#7D9B76','#FAF6F1'],
      ];
      foreach($ec_styles as $i=>[$title,$text,$bg,$fg]):?>
      <div class="ec-reveal" style="transition-delay:<?php echo $i*.08;?>s">
        <div style="height:300px;background:linear-gradient(160deg,<?php echo esc_attr($bg);?> 0%,<?php echo adjustShade($bg,-20);?> 100%);margin-bottom:1.2rem;display:flex;align-items:flex-end;padding:1.5rem;position:relative;overflow:hidden;">
          <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-family:var(--ec-serif);font-size:5rem;font-weight:700;color:<?php echo esc_attr($fg);?>;opacity:.07;white-space:nowrap;">VELOUR</div>
          <p style="font-size:.65rem;font-weight:700;letter-spacing:.18em;text-transform:uppercase;color:<?php echo esc_attr($fg);?>;opacity:.7;position:relative;z-index:1;"><?php esc_html_e('Shop the look →','themeflex');?></p>
        </div>
        <h3 style="font-family:var(--ec-serif);font-size:1.2rem;font-weight:500;margin-bottom:.5rem;"><?php echo esc_html($title);?></h3>
        <p style="font-size:.85rem;line-height:1.7;color:var(--ec-muted);"><?php echo esc_html($text);?></p>
      </div>
      <?php endforeach;?>
    </div>
  </div>
</section>

<!-- EMAIL SIGNUP ──────────────────────────────────── -->
<div class="ec-signup ec-reveal" aria-label="<?php esc_attr_e('Newsletter signup','themeflex');?>">
  <div class="ec-wrap">
    <span class="ec-eyebrow" style="color:var(--ec-rose);"><?php esc_html_e('The Insider','themeflex');?></span>
    <h2 class="ec-h2"><?php esc_html_e('First Access, Every Season','themeflex');?></h2>
    <p class="ec-lead"><?php esc_html_e('Sign up for early access to new arrivals, exclusive edits, and 15% off your first order.','themeflex');?></p>
    <form class="ec-signup__form" method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>" novalidate>
      <?php wp_nonce_field('tf_ec_signup','tf_ec_nonce');?>
      <input type="hidden" name="action" value="tf_ec_signup">
      <input class="ec-signup__input" type="email" name="email" placeholder="<?php esc_attr_e('your@email.com','themeflex');?>" required autocomplete="email">
      <button type="submit" class="ec-signup__btn"><?php esc_html_e('Subscribe','themeflex');?></button>
    </form>
    <p class="ec-signup__note"><?php esc_html_e('No spam. Unsubscribe anytime. We hate clutter as much as you do.','themeflex');?></p>
  </div>
</div>

<!-- FAQ ──────────────────────────────────────────── -->
<section class="ec-section ec-section--light" aria-labelledby="ec-faq-title">
  <div class="ec-wrap">
    <header style="text-align:center;margin-bottom:3rem;" class="ec-reveal">
      <span class="ec-eyebrow"><?php esc_html_e('Help','themeflex');?></span>
      <h2 class="ec-h2" id="ec-faq-title"><?php esc_html_e('Common Questions','themeflex');?></h2>
    </header>
    <div class="ec-faq-grid">
      <?php
      $ec_faqs=[
        ['How do I find my size?','Our size guide is available on every product page. We recommend taking your measurements and comparing to our chart rather than going by your usual label size, as cuts vary. If you\'re between sizes, we generally recommend sizing up for a relaxed fit or down for a tailored look.'],
        ['What is your returns policy?','We accept free returns on all full-price items within 30 days of delivery. Sale items can be returned for exchange or credit within 14 days. Items must be unworn, unwashed, and in original packaging with all tags attached.'],
        ['How long does delivery take?','Standard UK delivery is 3-5 business days and is free on orders over £80. Express next-day delivery costs £5.95 if ordered before 1pm. International delivery is available to 40+ countries — see our delivery page for rates and timescales.'],
        ['Are your clothes sustainable?','All cotton and linen pieces use GOTS-certified organic fabric. We produce in Portugal and Turkey under Fair Wear Foundation member terms. Our shipping is offset through Climate Partner. We publish an annual impact report on our sustainability page.'],
        ['Can I pay in instalments?','Yes — we partner with Klarna to offer Pay in 3 (interest-free). This is available on orders between £30 and £1,500 and is subject to Klarna\'s standard eligibility criteria.'],
        ['How do I care for my Velour pieces?','Most pieces are machine washable at 30°C on a gentle cycle. Silks and delicate fabrics should be hand washed or dry cleaned. Specific care instructions are printed on the label of every garment and listed on the product page.'],
      ];
      foreach($ec_faqs as $k=>[$q,$a]):
        $fid='ec-faq-'.$k;?>
      <div class="ec-faq" id="<?php echo esc_attr($fid);?>">
        <button class="ec-faq__q" aria-expanded="false" aria-controls="<?php echo esc_attr($fid.'-a');?>">
          <?php echo esc_html($q);?>
          <span class="ec-faq__icon" aria-hidden="true">+</span>
        </button>
        <div class="ec-faq__a" id="<?php echo esc_attr($fid.'-a');?>" role="region">
          <p class="ec-faq__a-inner"><?php echo esc_html($a);?></p>
        </div>
      </div>
      <?php endforeach;?>
    </div>
  </div>
</section>

<!-- FOOTER ───────────────────────────────────────── -->
<footer class="ec-footer" role="contentinfo">
  <div class="ec-wrap">
    <div class="ec-footer__top">
      <div class="ec-footer__brand">
        <a href="<?php echo esc_url(home_url('/'));?>" class="ec-nav__logo">VELOUR<span style="color:var(--ec-rose)">.</span></a>
        <p><?php esc_html_e('Contemporary womenswear made ethically in Europe. Sustainably sourced, beautifully designed, honestly priced.','themeflex');?></p>
      </div>
      <div><p class="ec-footer__col-title"><?php esc_html_e('Shop','themeflex');?></p><ul class="ec-footer__links"><li><a href="#"><?php esc_html_e('New In','themeflex');?></a></li><li><a href="#"><?php esc_html_e('Dresses','themeflex');?></a></li><li><a href="#"><?php esc_html_e('Tops','themeflex');?></a></li><li><a href="#"><?php esc_html_e('Outerwear','themeflex');?></a></li><li><a href="#"><?php esc_html_e('Sale','themeflex');?></a></li></ul></div>
      <div><p class="ec-footer__col-title"><?php esc_html_e('Help','themeflex');?></p><ul class="ec-footer__links"><li><a href="#"><?php esc_html_e('Size Guide','themeflex');?></a></li><li><a href="#"><?php esc_html_e('Returns','themeflex');?></a></li><li><a href="#"><?php esc_html_e('Delivery','themeflex');?></a></li><li><a href="#"><?php esc_html_e('Contact Us','themeflex');?></a></li></ul></div>
      <div><p class="ec-footer__col-title"><?php esc_html_e('About','themeflex');?></p><ul class="ec-footer__links"><li><a href="#"><?php esc_html_e('Our Story','themeflex');?></a></li><li><a href="#"><?php esc_html_e('Sustainability','themeflex');?></a></li><li><a href="#"><?php esc_html_e('Press','themeflex');?></a></li><li><a href="#"><?php esc_html_e('Instagram','themeflex');?></a></li></ul></div>
    </div>
    <div class="ec-footer__bottom">
      <span>&copy; <?php echo esc_html(date('Y'));?> Velour Ltd. <?php esc_html_e('All rights reserved.','themeflex');?></span>
      <div class="ec-footer__payment">
        <?php foreach(['Visa','Mastercard','Amex','Klarna','Apple Pay'] as $p):?><span class="ec-payment-pill"><?php echo esc_html($p);?></span><?php endforeach;?>
      </div>
    </div>
  </div>
</footer>

</div><!-- /.ec-page -->

<?php
/* Helper: darken a hex colour slightly for gradient ends */
function adjustShade($hex, $amount=0) {
    $hex = ltrim($hex,'#');
    if (strlen($hex) === 3) $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    $r = hexdec(substr($hex,0,2)); $g = hexdec(substr($hex,2,2)); $b = hexdec(substr($hex,4,2));
    $r = max(0,min(255,$r+$amount)); $g = max(0,min(255,$g+$amount)); $b = max(0,min(255,$b+$amount));
    return sprintf('#%02x%02x%02x',$r,$g,$b);
}
?>
<script>
(function(){
  'use strict';
  var obs=new IntersectionObserver(function(e){e.forEach(function(el){if(el.isIntersecting){el.target.classList.add('ec-visible');obs.unobserve(el.target);}});},{threshold:.1});
  document.querySelectorAll('.ec-reveal').forEach(function(el){obs.observe(el);});

  document.querySelectorAll('.ec-faq__q').forEach(function(btn){
    btn.addEventListener('click',function(){
      var faq=btn.closest('.ec-faq'),ans=faq.querySelector('.ec-faq__a'),inn=faq.querySelector('.ec-faq__a-inner'),open=faq.classList.contains('ec-open');
      document.querySelectorAll('.ec-faq.ec-open').forEach(function(f){f.querySelector('.ec-faq__a').style.maxHeight='0';f.classList.remove('ec-open');f.querySelector('.ec-faq__q').setAttribute('aria-expanded','false');});
      if(!open){ans.style.maxHeight=inn.scrollHeight+'px';faq.classList.add('ec-open');btn.setAttribute('aria-expanded','true');}
    });
  });
})();
</script>


<?php
/* ─────────────────────────────────────────────────────────────
   LOOKBOOK SECTION
   ───────────────────────────────────────────────────────────── */
$ec_looks = [
  ['title'=>'The Parisian Edit','sub'=>'Effortless French-inspired dressing for everyday elegance','tag'=>'SS 2026','color'=>'#C4969A','accent'=>'#7D9B76'],
  ['title'=>'Garden Party','sub'=>'Floral silhouettes and botanical hues for outdoor occasions','tag'=>'Limited','color'=>'#7D9B76','accent'=>'#C4969A'],
  ['title'=>'Midnight Luxe','sub'=>'Rich textures and deep tones for evenings worth remembering','tag'=>'Evening','color'=>'#111111','accent'=>'#F2D9D9'],
  ['title'=>'Cote d\'Azur','sub'=>'Sun-bleached linens and nautical refinement','tag'=>'Resort','color'=>'#C9B99A','accent'=>'#7D9B76'],
  ['title'=>'The Modern Office','sub'=>'Tailored power dressing redefined for contemporary workplaces','tag'=>'Work','color'=>'#475569','accent'=>'#F2D9D9'],
  ['title'=>'Weekend Wanderer','sub'=>'Relaxed ease from city mornings to countryside afternoons','tag'=>'Casual','color'=>'#8B7355','accent'=>'#FAF6F1'],
];
srand(crc32('ec-lookbook'));
?>
<!-- LOOKBOOK ─────────────────────────────────────────────── -->
<section class="ec-section" aria-labelledby="ec-lookbook-title" style="background:#FAF6F1;padding:7rem 0;">
  <div class="ec-container">
    <div class="ec-section-header ec-reveal" style="text-align:center;margin-bottom:4rem;">
      <p class="ec-section-eyebrow" style="letter-spacing:.2em;font-size:.7rem;text-transform:uppercase;color:#C4969A;margin-bottom:.75rem;font-family:'Nunito Sans',sans-serif;">Season 2026</p>
      <h2 id="ec-lookbook-title" style="font-family:'Playfair Display',Georgia,serif;font-size:clamp(2rem,4vw,3.2rem);color:#111111;font-weight:400;margin:0 0 1rem;">The Velour Lookbook</h2>
      <p style="color:#6b7280;font-size:1rem;max-width:520px;margin:0 auto;line-height:1.7;font-family:'Nunito Sans',sans-serif;">Six curated edits, each a complete world. Find the one that speaks to your season.</p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:1.5rem;">
      <?php foreach($ec_looks as $i=>$look):
        $delay = $i * 80;
        $h = 320 + ($i % 3) * 30;
      ?>
      <article class="ec-reveal" style="transition-delay:<?php echo $delay; ?>ms;border-radius:4px;overflow:hidden;cursor:pointer;position:relative;background:<?php echo esc_attr($look['color']); ?>;min-height:<?php echo $h; ?>px;display:flex;flex-direction:column;justify-content:flex-end;padding:2rem 1.75rem;">
        <div style="position:absolute;inset:0;background:linear-gradient(180deg,transparent 30%,rgba(0,0,0,.55) 100%);pointer-events:none;"></div>
        <div style="position:absolute;top:1.25rem;right:1.25rem;background:rgba(255,255,255,.15);backdrop-filter:blur(6px);border:1px solid rgba(255,255,255,.25);border-radius:2px;padding:.25rem .75rem;font-size:.65rem;letter-spacing:.15em;text-transform:uppercase;color:#ffffff;font-family:'Nunito Sans',sans-serif;"><?php echo esc_html($look['tag']); ?></div>
        <div aria-hidden="true" style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-family:'Playfair Display',Georgia,serif;font-size:9rem;font-weight:700;color:rgba(255,255,255,.06);line-height:1;user-select:none;"><?php echo str_pad($i+1,2,'0',STR_PAD_LEFT); ?></div>
        <div style="position:relative;z-index:1;">
          <h3 style="font-family:'Playfair Display',Georgia,serif;font-size:1.35rem;color:#ffffff;font-weight:400;margin:0 0 .4rem;"><?php echo esc_html($look['title']); ?></h3>
          <p style="font-family:'Nunito Sans',sans-serif;font-size:.8rem;color:rgba(255,255,255,.78);margin:0 0 1rem;line-height:1.5;"><?php echo esc_html($look['sub']); ?></p>
          <a href="<?php echo esc_url(home_url('/collections/'.sanitize_title($look['title']))); ?>" style="display:inline-flex;align-items:center;gap:.5rem;font-family:'Nunito Sans',sans-serif;font-size:.75rem;letter-spacing:.1em;text-transform:uppercase;color:#ffffff;text-decoration:none;border-bottom:1px solid rgba(255,255,255,.4);padding-bottom:2px;">Shop the edit <span aria-hidden="true">&#8594;</span></a>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php
/* ─────────────────────────────────────────────────────────────
   AS SEEN IN / PRESS
   ───────────────────────────────────────────────────────────── */
$ec_press = [
  ['name'=>'Vogue','quote'=>'"The label redefining British minimalism for a new generation."','issue'=>'March 2026'],
  ['name'=>"Harper's Bazaar",'quote'=>'"Investment pieces that outlast every trend cycle."','issue'=>'February 2026'],
  ['name'=>'The Telegraph','quote'=>'"Sustainable luxury without the compromise."','issue'=>'January 2026'],
  ['name'=>'Grazia','quote'=>'"The brand your wardrobe has been waiting for."','issue'=>'April 2026'],
  ['name'=>'Wallpaper*','quote'=>'"Where fashion meets considered design thinking."','issue'=>'March 2026'],
];
?>
<!-- PRESS ────────────────────────────────────────────────── -->
<section class="ec-section" aria-labelledby="ec-press-title" style="background:#111111;padding:5rem 0;">
  <div class="ec-container">
    <p class="ec-reveal" style="text-align:center;font-family:'Nunito Sans',sans-serif;font-size:.7rem;letter-spacing:.25em;text-transform:uppercase;color:#C4969A;margin-bottom:3rem;">As seen in</p>
    <div style="display:flex;gap:0;border-top:1px solid rgba(255,255,255,.08);border-bottom:1px solid rgba(255,255,255,.08);">
      <?php foreach($ec_press as $pi=>$p): ?>
      <div class="ec-reveal" style="transition-delay:<?php echo $pi*70; ?>ms;flex:1;padding:2.5rem 2rem;border-left:<?php echo $pi===0?'none':'1px solid rgba(255,255,255,.08)'; ?>;text-align:center;">
        <p style="font-family:'Playfair Display',Georgia,serif;font-size:1.4rem;font-weight:700;color:rgba(255,255,255,.15);letter-spacing:-.02em;margin:0 0 1.2rem;"><?php echo esc_html($p['name']); ?></p>
        <p style="font-family:'Playfair Display',Georgia,serif;font-style:italic;font-size:.85rem;color:rgba(255,255,255,.55);line-height:1.6;margin:0 0 1rem;"><?php echo esc_html($p['quote']); ?></p>
        <p style="font-family:'Nunito Sans',sans-serif;font-size:.65rem;letter-spacing:.15em;text-transform:uppercase;color:#C4969A;"><?php echo esc_html($p['issue']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php
/* ─────────────────────────────────────────────────────────────
   LOYALTY / REWARDS PROGRAMME
   ───────────────────────────────────────────────────────────── */
$ec_tiers = [
  ['name'=>'Petal','min'=>'0','pts'=>'1pt / 1 spent','perks'=>['Early access to new arrivals','Birthday gift','Members newsletter'],'color'=>'#F2D9D9','txt'=>'#111111','featured'=>false],
  ['name'=>'Rose','min'=>'500/yr','pts'=>'1.5pts / 1 spent','perks'=>['All Petal perks','Free returns always','Priority customer care','Seasonal edit preview'],'color'=>'#C4969A','txt'=>'#ffffff','featured'=>true],
  ['name'=>'Noir','min'=>'1500/yr','pts'=>'2pts / 1 spent','perks'=>['All Rose perks','Complimentary alterations','Personal stylist session','Invite-only events','Free express shipping'],'color'=>'#111111','txt'=>'#ffffff','featured'=>false],
];
?>
<!-- REWARDS ──────────────────────────────────────────────── -->
<section class="ec-section" aria-labelledby="ec-rewards-title" style="background:#FAF6F1;padding:7rem 0;">
  <div class="ec-container">
    <div class="ec-reveal" style="text-align:center;margin-bottom:4rem;">
      <p style="font-family:'Nunito Sans',sans-serif;font-size:.7rem;letter-spacing:.25em;text-transform:uppercase;color:#C4969A;margin-bottom:.75rem;">Members Programme</p>
      <h2 id="ec-rewards-title" style="font-family:'Playfair Display',Georgia,serif;font-size:clamp(2rem,4vw,3rem);color:#111111;font-weight:400;margin:0 0 1rem;">Velour Rewards</h2>
      <p style="color:#6b7280;font-size:1rem;max-width:500px;margin:0 auto;line-height:1.7;font-family:'Nunito Sans',sans-serif;">Every purchase brings you closer to exclusive benefits. Three tiers, one community of people who love beautiful things.</p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:1.5rem;margin-bottom:4rem;align-items:start;">
      <?php foreach($ec_tiers as $ti=>$tier): ?>
      <div class="ec-reveal" style="transition-delay:<?php echo $ti*100; ?>ms;background:<?php echo esc_attr($tier['color']); ?>;border-radius:6px;padding:2.5rem 2rem;position:relative;overflow:hidden;<?php if($tier['featured']) echo 'transform:scale(1.04);box-shadow:0 20px 60px rgba(196,150,154,.3);'; ?>">
        <div aria-hidden="true" style="position:absolute;bottom:-1rem;right:-1rem;font-family:'Playfair Display',Georgia,serif;font-size:7rem;font-weight:700;color:rgba(<?php echo $ti===2?'255,255,255':'0,0,0'; ?>,.05);line-height:1;user-select:none;"><?php echo esc_html($tier['name']); ?></div>
        <?php if($tier['featured']): ?>
        <div style="position:absolute;top:1rem;right:1rem;background:rgba(255,255,255,.2);border-radius:2px;padding:.2rem .6rem;font-family:'Nunito Sans',sans-serif;font-size:.6rem;letter-spacing:.1em;text-transform:uppercase;color:#ffffff;">Popular</div>
        <?php endif; ?>
        <p style="font-family:'Nunito Sans',sans-serif;font-size:.65rem;letter-spacing:.2em;text-transform:uppercase;color:<?php echo $ti===0?'#C4969A':'rgba(255,255,255,.65)'; ?>;margin:0 0 .75rem;">From £<?php echo esc_html($tier['min']); ?></p>
        <h3 style="font-family:'Playfair Display',Georgia,serif;font-size:2rem;font-weight:400;color:<?php echo esc_attr($tier['txt']); ?>;margin:0 0 .5rem;"><?php echo esc_html($tier['name']); ?></h3>
        <p style="font-family:'Nunito Sans',sans-serif;font-size:.8rem;color:<?php echo $ti===0?'#6b7280':'rgba(255,255,255,.65)'; ?>;margin:0 0 2rem;"><?php echo esc_html($tier['pts']); ?></p>
        <ul style="list-style:none;padding:0;margin:0 0 2rem;display:flex;flex-direction:column;gap:.75rem;">
          <?php foreach($tier['perks'] as $perk): ?>
          <li style="display:flex;align-items:flex-start;gap:.6rem;font-family:'Nunito Sans',sans-serif;font-size:.85rem;color:<?php echo $ti===0?'#374151':'rgba(255,255,255,.85)'; ?>;line-height:1.4;">
            <span aria-hidden="true" style="color:<?php echo $ti===0?'#C4969A':'rgba(255,255,255,.5)'; ?>;margin-top:2px;">&#10003;</span>
            <?php echo esc_html($perk); ?>
          </li>
          <?php endforeach; ?>
        </ul>
        <a href="<?php echo esc_url(home_url('/join-rewards')); ?>" style="display:block;text-align:center;padding:.85rem 1.5rem;background:<?php echo $ti===0?'#111111':($ti===2?'#F2D9D9':'#111111'); ?>;color:<?php echo $ti===0?'#ffffff':($ti===2?'#111111':'#ffffff'); ?>;font-family:'Nunito Sans',sans-serif;font-size:.75rem;letter-spacing:.1em;text-transform:uppercase;text-decoration:none;border-radius:2px;position:relative;z-index:1;">Join <?php echo esc_html($tier['name']); ?></a>
      </div>
      <?php endforeach; ?>
    </div>
    <div class="ec-reveal" style="background:#ffffff;border:1px solid #e5e7eb;border-radius:4px;padding:2rem 2.5rem;display:flex;align-items:center;justify-content:space-between;gap:2rem;flex-wrap:wrap;">
      <div>
        <h3 style="font-family:'Playfair Display',Georgia,serif;font-size:1.2rem;font-weight:400;color:#111111;margin:0 0 .3rem;">Already a member?</h3>
        <p style="font-family:'Nunito Sans',sans-serif;font-size:.875rem;color:#6b7280;margin:0;">Sign in to check your points balance and exclusive offers.</p>
      </div>
      <div style="display:flex;gap:1rem;flex-shrink:0;">
        <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>" style="padding:.75rem 1.75rem;background:#111111;color:#ffffff;font-family:'Nunito Sans',sans-serif;font-size:.75rem;letter-spacing:.1em;text-transform:uppercase;text-decoration:none;border-radius:2px;">Sign in</a>
        <a href="<?php echo esc_url(home_url('/rewards/faq')); ?>" style="padding:.75rem 1.75rem;border:1px solid #d1d5db;color:#374151;font-family:'Nunito Sans',sans-serif;font-size:.75rem;letter-spacing:.1em;text-transform:uppercase;text-decoration:none;border-radius:2px;">Learn more</a>
      </div>
    </div>
  </div>
</section>

<?php
/* ─────────────────────────────────────────────────────────────
   TESTIMONIALS / COMMUNITY REVIEWS
   ───────────────────────────────────────────────────────────── */
$ec_reviews = [
  ['name'=>'Amelia C.','loc'=>'London','stars'=>5,'text'=>"I've been shopping with Velour for two years and the quality is unmatched. The silk blouse I bought last spring still looks brand new, worth every penny.",'item'=>'Ivory Silk Blouse'],
  ['name'=>'Sophie R.','loc'=>'Edinburgh','stars'=>5,'text'=>"Finally a brand that thinks about how clothes actually feel, not just how they photograph. The cashmere is genuinely the softest I've owned.",'item'=>'Dove Grey Cashmere'],
  ['name'=>'Charlotte M.','loc'=>'Bristol','stars'=>5,'text'=>"The personal stylist session through the Noir tier was a revelation. I now buy fewer pieces but love everything I own.",'item'=>'Noir Membership'],
  ['name'=>'Isabelle T.','loc'=>'Manchester','stars'=>5,'text'=>"Returns are effortless and the packaging is so beautiful I kept the box. Little things that show the brand genuinely cares.",'item'=>'Linen Wide Trousers'],
];
?>
<!-- REVIEWS ──────────────────────────────────────────────── -->
<section class="ec-section" aria-labelledby="ec-reviews-title" style="background:#111111;padding:6rem 0;">
  <div class="ec-container">
    <div class="ec-reveal" style="text-align:center;margin-bottom:4rem;">
      <p style="font-family:'Nunito Sans',sans-serif;font-size:.7rem;letter-spacing:.25em;text-transform:uppercase;color:#C4969A;margin-bottom:.75rem;">Our Community</p>
      <h2 id="ec-reviews-title" style="font-family:'Playfair Display',Georgia,serif;font-size:clamp(2rem,4vw,3rem);color:#ffffff;font-weight:400;margin:0 0 .5rem;">Worn &amp; Loved</h2>
      <div style="display:flex;align-items:center;justify-content:center;gap:.4rem;margin-bottom:.5rem;" aria-label="Average rating 4.9 out of 5">
        <?php for($s=0;$s<5;$s++) echo '<span aria-hidden="true" style="color:#C4969A;font-size:1.1rem;">&#9733;</span>'; ?>
      </div>
      <p style="font-family:'Nunito Sans',sans-serif;font-size:.85rem;color:rgba(255,255,255,.45);">4.9 / 5 from 2,847 verified reviews</p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:1.5rem;">
      <?php foreach($ec_reviews as $ri=>$rev): ?>
      <blockquote class="ec-reveal" style="transition-delay:<?php echo $ri*80; ?>ms;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:6px;padding:2.25rem 2rem;margin:0;position:relative;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem;">
          <div style="display:flex;align-items:center;gap:.75rem;">
            <div style="width:44px;height:44px;border-radius:50%;background:linear-gradient(135deg,#C4969A,#7D9B76);display:flex;align-items:center;justify-content:center;font-family:'Playfair Display',Georgia,serif;font-size:1rem;color:#ffffff;font-weight:700;"><?php echo esc_html(substr($rev['name'],0,1)); ?></div>
            <div>
              <p style="font-family:'Nunito Sans',sans-serif;font-size:.875rem;font-weight:700;color:#ffffff;margin:0 0 .15rem;"><?php echo esc_html($rev['name']); ?></p>
              <p style="font-family:'Nunito Sans',sans-serif;font-size:.75rem;color:rgba(255,255,255,.4);margin:0;"><?php echo esc_html($rev['loc']); ?></p>
            </div>
          </div>
          <div style="text-align:right;">
            <div aria-label="<?php echo esc_attr($rev['stars']); ?> stars" style="color:#C4969A;font-size:.9rem;"><?php echo str_repeat('&#9733;',$rev['stars']); ?></div>
            <p style="font-family:'Nunito Sans',sans-serif;font-size:.65rem;color:rgba(255,255,255,.35);margin:.2rem 0 0;letter-spacing:.05em;">Verified &middot; <?php echo esc_html($rev['item']); ?></p>
          </div>
        </div>
        <p style="font-family:'Playfair Display',Georgia,serif;font-style:italic;font-size:1rem;color:rgba(255,255,255,.75);line-height:1.7;margin:0;"><?php echo esc_html($rev['text']); ?></p>
        <span aria-hidden="true" style="position:absolute;top:1.5rem;right:2rem;font-family:'Playfair Display',Georgia,serif;font-size:5rem;color:rgba(255,255,255,.03);line-height:1;">&ldquo;</span>
      </blockquote>
      <?php endforeach; ?>
    </div>
    <div class="ec-reveal" style="text-align:center;margin-top:3rem;">
      <a href="<?php echo esc_url(home_url('/reviews')); ?>" style="display:inline-block;padding:.875rem 2.5rem;border:1px solid rgba(255,255,255,.2);color:rgba(255,255,255,.75);font-family:'Nunito Sans',sans-serif;font-size:.75rem;letter-spacing:.1em;text-transform:uppercase;text-decoration:none;border-radius:2px;">Read all reviews</a>
    </div>
  </div>
</section>

<?php get_footer(); ?>
