<?php
/**
 * Template Name: Education & University Homepage
 *
 * Premium university / higher-education landing page.
 * Dark indigo aesthetic · CSS campus hero · program grid ·
 * faculty · events · research · alumni testimonials · enroll form.
 *
 * @package ThemeFlex
 * @since   3.0.0
 */

get_header();
?>

<style>
/* ============================================================
   EDUCATION PAGE — DESIGN TOKENS
   ============================================================ */
.tf-edu-page {
  --edu-bg:       #09090f;
  --edu-surface:  #0f0f1a;
  --edu-card:     #131322;
  --edu-border:   rgba(255,255,255,.07);
  --edu-accent:   #7c6ae8;     /* indigo */
  --edu-accent2:  #f4c842;     /* gold */
  --edu-accent3:  #34d399;     /* emerald */
  --edu-text:     #e8e6f0;
  --edu-muted:    #6b6880;
}

.tf-edu-page {
  background: var(--edu-bg);
  color: var(--edu-text);
  font-family: var(--tf-font-body,'Inter','Helvetica Neue',sans-serif);
  line-height: 1.6;
}

/* ============================================================
   HERO
   ============================================================ */
.edu-hero {
  position: relative;
  min-height: clamp(580px,88vh,860px);
  display: grid;
  grid-template-columns: 1fr 1fr;
  overflow: hidden;
  background: var(--edu-bg);
}
.edu-hero::before {
  content: '';
  position: absolute;
  inset: 0;
  background: radial-gradient(ellipse 60% 50% at 75% 50%, rgba(124,106,232,.12) 0%, transparent 70%);
  pointer-events: none;
}

/* copy */
.edu-hero__copy {
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 6rem 4rem 6rem 6rem;
  position: relative;
  z-index: 2;
}
.edu-hero__badge {
  display: inline-flex;
  align-items: center;
  gap: .6rem;
  background: rgba(124,106,232,.12);
  border: 1px solid rgba(124,106,232,.3);
  color: var(--edu-accent);
  font-size: .7rem;
  letter-spacing: .18em;
  text-transform: uppercase;
  padding: .4rem .9rem;
  border-radius: 2rem;
  margin-bottom: 1.75rem;
  width: fit-content;
}
.edu-hero__badge svg { flex-shrink: 0; }
.edu-hero__h1 {
  font-family: var(--tf-font-heading,'Plus Jakarta Sans','Inter',sans-serif);
  font-size: clamp(2.8rem,5.5vw,5.2rem);
  font-weight: 700;
  line-height: 1.08;
  letter-spacing: -.03em;
  color: var(--edu-text);
  margin: 0 0 1.5rem;
}
.edu-hero__h1 span {
  background: linear-gradient(135deg, var(--edu-accent) 0%, var(--edu-accent2) 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
.edu-hero__sub {
  font-size: 1.05rem;
  color: var(--edu-muted);
  max-width: 38ch;
  margin: 0 0 2.5rem;
  line-height: 1.75;
}
.edu-hero__ctas { display: flex; gap: 1rem; flex-wrap: wrap; }

.edu-btn {
  display: inline-flex;
  align-items: center;
  gap: .5rem;
  padding: .85rem 1.75rem;
  border-radius: 6px;
  font-size: .88rem;
  font-weight: 600;
  text-decoration: none;
  transition: all .25s ease;
  cursor: pointer;
  border: none;
  letter-spacing: .01em;
}
.edu-btn--primary {
  background: var(--edu-accent);
  color: #fff;
  box-shadow: 0 0 24px rgba(124,106,232,.35);
}
.edu-btn--primary:hover { background: #6a58d6; box-shadow: 0 0 32px rgba(124,106,232,.5); }
.edu-btn--outline {
  background: transparent;
  color: var(--edu-text);
  border: 1px solid var(--edu-border);
}
.edu-btn--outline:hover { border-color: var(--edu-accent); color: var(--edu-accent); }

.edu-hero__trust {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-top: 2.5rem;
  padding-top: 2rem;
  border-top: 1px solid var(--edu-border);
}
.edu-hero__trust-avatars {
  display: flex;
}
.edu-hero__trust-av {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  border: 2px solid var(--edu-bg);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: .6rem;
  font-weight: 700;
  margin-left: -10px;
  flex-shrink: 0;
}
.edu-hero__trust-av:first-child { margin-left: 0; }
.edu-hero__trust-text { font-size: .82rem; color: var(--edu-muted); line-height: 1.4; }
.edu-hero__trust-text strong { color: var(--edu-text); }

/* visual */
.edu-hero__visual {
  position: relative;
  background: #07070e;
  border-left: 1px solid var(--edu-border);
  overflow: hidden;
}

/* CSS campus building */
.edu-campus {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: flex-end;
  justify-content: center;
  padding-bottom: 8%;
}

/* Main building */
.edu-bld {
  position: relative;
  width: 320px;
  display: flex;
  flex-direction: column;
  align-items: center;
}

/* Dome */
.edu-dome {
  width: 120px;
  height: 60px;
  border-radius: 120px 120px 0 0;
  border: 1.5px solid rgba(124,106,232,.5);
  border-bottom: none;
  background: rgba(124,106,232,.06);
  position: relative;
  margin-bottom: -1px;
}
.edu-dome::before {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 10px;
  height: 28px;
  background: rgba(124,106,232,.4);
  border-radius: 2px 2px 0 0;
}
.edu-dome-glow {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%,-50%);
  width: 60px;
  height: 60px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(124,106,232,.2) 0%, transparent 70%);
  animation: edu-dome-pulse 3s ease-in-out infinite;
}
@keyframes edu-dome-pulse {
  0%,100% { opacity:1; transform: translate(-50%,-50%) scale(1); }
  50% { opacity:.5; transform: translate(-50%,-50%) scale(1.3); }
}

/* Portico columns */
.edu-portico {
  width: 280px;
  height: 40px;
  display: flex;
  align-items: flex-end;
  justify-content: center;
  gap: 20px;
  background: rgba(124,106,232,.04);
  border: 1.5px solid rgba(124,106,232,.35);
  border-bottom: none;
  position: relative;
}
.edu-col {
  width: 8px;
  height: 50px;
  border-radius: 4px 4px 0 0;
  background: rgba(124,106,232,.3);
  position: relative;
  bottom: 0;
}

/* Main body */
.edu-body {
  width: 300px;
  height: 240px;
  border: 1.5px solid rgba(124,106,232,.4);
  background: rgba(124,106,232,.04);
  position: relative;
  overflow: hidden;
}

/* Window grid */
.edu-windows {
  position: absolute;
  inset: 12px;
  display: grid;
  grid-template-columns: repeat(5,1fr);
  grid-template-rows: repeat(4,1fr);
  gap: 8px;
}
.edu-win {
  border: 1px solid rgba(124,106,232,.2);
  background: rgba(124,106,232,.04);
  border-radius: 2px;
  transition: background .3s;
}
.edu-win.lit {
  background: rgba(244,200,66,.12);
  border-color: rgba(244,200,66,.4);
  box-shadow: 0 0 10px rgba(244,200,66,.15);
  animation: edu-win-flicker var(--dur,4s) ease-in-out infinite var(--del,0s);
}
@keyframes edu-win-flicker {
  0%,90%,100% { opacity:1; }
  95% { opacity:.4; }
}

/* Entry door */
.edu-door {
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 36px;
  height: 52px;
  border: 1.5px solid rgba(124,106,232,.5);
  border-bottom: none;
  border-radius: 4px 4px 0 0;
  background: rgba(124,106,232,.1);
}

/* Side wings */
.edu-wing {
  width: 340px;
  height: 120px;
  border: 1.5px solid rgba(124,106,232,.3);
  background: rgba(124,106,232,.02);
  position: absolute;
  bottom: 0;
  display: grid;
  grid-template-columns: repeat(5,1fr);
  padding: 12px;
  gap: 6px;
  align-content: start;
}
.edu-wing--left  { right: calc(100% - 22px); }
.edu-wing--right { left: calc(100% - 22px); }
.edu-wing-win {
  border: 1px solid rgba(124,106,232,.15);
  background: rgba(124,106,232,.03);
}
.edu-wing-win.lit {
  background: rgba(124,106,232,.12);
  border-color: rgba(124,106,232,.35);
}

/* Ground / steps */
.edu-steps {
  width: 360px;
  height: 16px;
  display: flex;
  flex-direction: column;
  gap: 0;
}
.edu-step {
  height: 5px;
  background: rgba(124,106,232,.2);
  border: 1px solid rgba(124,106,232,.25);
  margin: 0 auto;
}
.edu-step:nth-child(1) { width: 100%; }
.edu-step:nth-child(2) { width: 90%; }
.edu-step:nth-child(3) { width: 80%; }

/* Sky elements */
.edu-sky-grid {
  position: absolute;
  inset: 0;
  background-image:
    linear-gradient(rgba(124,106,232,.04) 1px, transparent 1px),
    linear-gradient(90deg, rgba(124,106,232,.04) 1px, transparent 1px);
  background-size: 40px 40px;
}
.edu-star {
  position: absolute;
  width: 2px;
  height: 2px;
  border-radius: 50%;
  background: rgba(255,255,255,.5);
  animation: edu-star-twinkle var(--d,3s) ease-in-out infinite var(--dl,0s);
}
@keyframes edu-star-twinkle {
  0%,100% { opacity:.5; }
  50% { opacity:.1; }
}

/* Floating info card */
.edu-hero__card {
  position: absolute;
  top: 1.5rem;
  right: 1.5rem;
  background: rgba(19,19,34,.9);
  border: 1px solid rgba(124,106,232,.3);
  border-radius: 10px;
  padding: 1rem 1.25rem;
  backdrop-filter: blur(12px);
  min-width: 180px;
  animation: edu-card-float 5s ease-in-out infinite;
}
@keyframes edu-card-float {
  0%,100% { transform: translateY(0); }
  50% { transform: translateY(-8px); }
}
.edu-hero__card-title {
  font-size: .65rem;
  letter-spacing: .12em;
  text-transform: uppercase;
  color: var(--edu-muted);
  margin-bottom: .5rem;
}
.edu-hero__card-stat {
  display: flex;
  align-items: center;
  gap: .5rem;
  margin-bottom: .35rem;
}
.edu-hero__card-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  flex-shrink: 0;
}
.edu-hero__card-lbl { font-size: .75rem; color: var(--edu-text); }
.edu-hero__card-val { font-size: .75rem; font-weight: 700; margin-left: auto; }

/* Acceptance rate pill */
.edu-accept-pill {
  position: absolute;
  bottom: 1.5rem;
  left: 1.5rem;
  background: rgba(52,211,153,.12);
  border: 1px solid rgba(52,211,153,.3);
  border-radius: 2rem;
  padding: .4rem .9rem;
  display: flex;
  align-items: center;
  gap: .5rem;
  font-size: .72rem;
  color: var(--edu-accent3);
}

/* ============================================================
   SHARED SECTION STYLES
   ============================================================ */
.edu-section { padding: 7rem 0; }
.edu-container { max-width: 1280px; margin: 0 auto; padding: 0 2.5rem; }
.edu-label {
  display: inline-flex;
  align-items: center;
  gap: .6rem;
  font-size: .68rem;
  letter-spacing: .2em;
  text-transform: uppercase;
  color: var(--edu-accent);
  margin-bottom: 1rem;
}
.edu-label-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--edu-accent);
}
.edu-h2 {
  font-family: var(--tf-font-heading,'Plus Jakarta Sans','Inter',sans-serif);
  font-size: clamp(2rem,4vw,3.5rem);
  font-weight: 700;
  line-height: 1.12;
  letter-spacing: -.03em;
  color: var(--edu-text);
  margin: 0 0 1rem;
}
.edu-lead {
  font-size: 1rem;
  color: var(--edu-muted);
  max-width: 52ch;
  line-height: 1.75;
}

/* ============================================================
   STATS BAR
   ============================================================ */
.edu-stats-bar {
  background: var(--edu-accent);
  padding: 2.5rem 0;
}
.edu-stats-bar__inner {
  display: grid;
  grid-template-columns: repeat(4,1fr);
  gap: 0;
}
.edu-stat {
  text-align: center;
  padding: .75rem 1.5rem;
  border-right: 1px solid rgba(255,255,255,.2);
}
.edu-stat:last-child { border-right: none; }
.edu-stat__val {
  font-family: var(--tf-font-heading,'Plus Jakarta Sans','Inter',sans-serif);
  font-size: 2.8rem;
  font-weight: 800;
  color: #fff;
  line-height: 1;
  margin-bottom: .25rem;
}
.edu-stat__lbl {
  font-size: .72rem;
  letter-spacing: .12em;
  text-transform: uppercase;
  color: rgba(255,255,255,.7);
}

/* ============================================================
   PROGRAMS
   ============================================================ */
.edu-programs { background: var(--edu-surface); }
.edu-programs__header {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 2rem;
  margin-bottom: 3rem;
  flex-wrap: wrap;
}
.edu-programs__grid {
  display: grid;
  grid-template-columns: repeat(3,1fr);
  gap: 1.5rem;
}
.edu-program-card {
  background: var(--edu-card);
  border: 1px solid var(--edu-border);
  border-radius: 12px;
  padding: 2rem;
  position: relative;
  overflow: hidden;
  transition: border-color .3s, transform .3s;
  text-decoration: none;
  display: block;
}
.edu-program-card:hover {
  border-color: rgba(124,106,232,.4);
  transform: translateY(-4px);
}
.edu-program-card__icon {
  width: 48px;
  height: 48px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 1.25rem;
  flex-shrink: 0;
}
.edu-program-card__level {
  font-size: .65rem;
  letter-spacing: .14em;
  text-transform: uppercase;
  color: var(--edu-muted);
  margin-bottom: .4rem;
}
.edu-program-card__name {
  font-family: var(--tf-font-heading,'Plus Jakarta Sans','Inter',sans-serif);
  font-size: 1.15rem;
  font-weight: 700;
  color: var(--edu-text);
  margin: 0 0 .6rem;
  line-height: 1.3;
}
.edu-program-card__desc {
  font-size: .83rem;
  color: var(--edu-muted);
  line-height: 1.65;
  margin-bottom: 1.25rem;
}
.edu-program-card__meta {
  display: flex;
  gap: 1.25rem;
  font-size: .75rem;
  color: var(--edu-muted);
}
.edu-program-card__meta-item {
  display: flex;
  align-items: center;
  gap: .35rem;
}
.edu-program-card__meta-item svg { color: var(--edu-accent); flex-shrink: 0; }
.edu-program-card__glow {
  position: absolute;
  inset: 0;
  border-radius: inherit;
  opacity: 0;
  transition: opacity .4s;
  pointer-events: none;
}
.edu-program-card:hover .edu-program-card__glow { opacity: 1; }

/* ============================================================
   EVENTS STRIP
   ============================================================ */
.edu-events {
  background: var(--edu-bg);
  border-top: 1px solid var(--edu-border);
  border-bottom: 1px solid var(--edu-border);
  padding: 4rem 0;
}
.edu-events__inner {
  display: grid;
  grid-template-columns: 240px 1fr;
  gap: 4rem;
  align-items: start;
}
.edu-events__label { margin-bottom: 0; }
.edu-events__list { display: flex; flex-direction: column; gap: 0; }
.edu-event {
  display: grid;
  grid-template-columns: 60px 1fr auto;
  gap: 1.5rem;
  align-items: center;
  padding: 1.25rem 0;
  border-bottom: 1px solid var(--edu-border);
  text-decoration: none;
}
.edu-event:last-child { border-bottom: none; }
.edu-event:hover .edu-event__title { color: var(--edu-accent); }
.edu-event__date {
  text-align: center;
  flex-shrink: 0;
}
.edu-event__day {
  font-family: var(--tf-font-heading,'Plus Jakarta Sans','Inter',sans-serif);
  font-size: 1.8rem;
  font-weight: 800;
  color: var(--edu-accent);
  line-height: 1;
}
.edu-event__month {
  font-size: .65rem;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: var(--edu-muted);
}
.edu-event__type {
  font-size: .65rem;
  letter-spacing: .12em;
  text-transform: uppercase;
  color: var(--edu-accent2);
  margin-bottom: .25rem;
}
.edu-event__title {
  font-size: .92rem;
  font-weight: 600;
  color: var(--edu-text);
  margin-bottom: .2rem;
  transition: color .2s;
}
.edu-event__meta {
  font-size: .75rem;
  color: var(--edu-muted);
  display: flex;
  gap: .75rem;
}
.edu-event__arrow { color: var(--edu-muted); flex-shrink: 0; }

/* ============================================================
   FACULTY
   ============================================================ */
.edu-faculty { background: var(--edu-surface); }
.edu-faculty__grid {
  display: grid;
  grid-template-columns: repeat(4,1fr);
  gap: 1.5rem;
  margin-top: 3.5rem;
}
.edu-faculty-card {
  background: var(--edu-card);
  border: 1px solid var(--edu-border);
  border-radius: 12px;
  padding: 1.75rem;
  transition: border-color .3s;
}
.edu-faculty-card:hover { border-color: rgba(124,106,232,.3); }
.edu-faculty-card__av {
  width: 56px;
  height: 56px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 1.1rem;
  color: #fff;
  margin-bottom: 1rem;
  flex-shrink: 0;
}
.edu-faculty-card__name {
  font-size: 1rem;
  font-weight: 700;
  color: var(--edu-text);
  margin-bottom: .2rem;
}
.edu-faculty-card__dept {
  font-size: .72rem;
  letter-spacing: .08em;
  text-transform: uppercase;
  color: var(--edu-accent);
  margin-bottom: .75rem;
}
.edu-faculty-card__bio {
  font-size: .8rem;
  color: var(--edu-muted);
  line-height: 1.65;
  margin-bottom: 1rem;
}
.edu-faculty-card__badge {
  display: inline-flex;
  align-items: center;
  gap: .4rem;
  font-size: .68rem;
  background: rgba(124,106,232,.1);
  border: 1px solid rgba(124,106,232,.25);
  color: var(--edu-accent);
  border-radius: 20px;
  padding: .25rem .65rem;
}

/* ============================================================
   RESEARCH HIGHLIGHTS
   ============================================================ */
.edu-research { background: var(--edu-bg); }
.edu-research__inner {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 5rem;
  align-items: center;
}

/* CSS stat visualization */
.edu-research__viz {
  background: var(--edu-card);
  border: 1px solid var(--edu-border);
  border-radius: 16px;
  padding: 2rem;
  position: relative;
  overflow: hidden;
}
.edu-research__viz::before {
  content: '';
  position: absolute;
  top: -50%;
  right: -20%;
  width: 300px;
  height: 300px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(124,106,232,.08) 0%, transparent 70%);
  pointer-events: none;
}
.edu-viz-title {
  font-size: .7rem;
  letter-spacing: .15em;
  text-transform: uppercase;
  color: var(--edu-muted);
  margin-bottom: 1.5rem;
  display: flex;
  align-items: center;
  gap: .5rem;
}
.edu-viz-title svg { color: var(--edu-accent); }
.edu-research-bars { display: flex; flex-direction: column; gap: 1.25rem; }
.edu-res-bar { }
.edu-res-bar__header {
  display: flex;
  justify-content: space-between;
  margin-bottom: .4rem;
  font-size: .8rem;
}
.edu-res-bar__label { color: var(--edu-text); font-weight: 500; }
.edu-res-bar__val { color: var(--edu-accent); font-weight: 700; }
.edu-res-bar__track {
  height: 6px;
  background: var(--edu-border);
  border-radius: 3px;
  overflow: hidden;
}
.edu-res-bar__fill {
  height: 100%;
  border-radius: 3px;
  transform-origin: left;
  animation: edu-bar-grow 1.4s cubic-bezier(.34,1.56,.64,1) forwards var(--del,0s);
  transform: scaleX(0);
}
@keyframes edu-bar-grow { to { transform: scaleX(1); } }

.edu-research__stats {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  margin-top: 1.5rem;
}
.edu-res-stat {
  background: var(--edu-surface);
  border: 1px solid var(--edu-border);
  border-radius: 8px;
  padding: 1rem;
  text-align: center;
}
.edu-res-stat__val {
  font-family: var(--tf-font-heading,'Plus Jakarta Sans','Inter',sans-serif);
  font-size: 2rem;
  font-weight: 800;
  color: var(--edu-accent);
  line-height: 1;
  margin-bottom: .25rem;
}
.edu-res-stat__lbl {
  font-size: .68rem;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: var(--edu-muted);
}

.edu-research__copy { display: flex; flex-direction: column; }
.edu-research__areas {
  display: flex;
  flex-direction: column;
  gap: .85rem;
  margin-top: 2rem;
}
.edu-research-area {
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  padding: 1rem 1.25rem;
  background: var(--edu-card);
  border: 1px solid var(--edu-border);
  border-radius: 8px;
  border-left: 3px solid transparent;
  transition: border-color .3s;
}
.edu-research-area:hover { border-left-color: var(--edu-accent); }
.edu-research-area__icon {
  width: 32px;
  height: 32px;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.edu-research-area__name { font-size: .88rem; font-weight: 600; color: var(--edu-text); margin-bottom: .2rem; }
.edu-research-area__sub { font-size: .77rem; color: var(--edu-muted); }

/* ============================================================
   TESTIMONIALS / ALUMNI
   ============================================================ */
.edu-testimonials { background: var(--edu-surface); }
.edu-testimonials__grid {
  display: grid;
  grid-template-columns: repeat(3,1fr);
  gap: 1.5rem;
  margin-top: 3.5rem;
}
.edu-testi-card {
  background: var(--edu-card);
  border: 1px solid var(--edu-border);
  border-radius: 12px;
  padding: 2rem;
  position: relative;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}
.edu-testi-card__quote-icon {
  font-family: var(--tf-font-heading,'Plus Jakarta Sans','Inter',sans-serif);
  font-size: 5rem;
  font-weight: 800;
  color: rgba(124,106,232,.15);
  line-height: .8;
  margin-bottom: -.5rem;
  display: block;
  user-select: none;
}
.edu-testi-card__text {
  font-size: .9rem;
  color: var(--edu-text);
  line-height: 1.75;
  flex: 1;
  margin-bottom: 1.5rem;
  font-style: italic;
}
.edu-testi-card__footer {
  display: flex;
  align-items: center;
  gap: .85rem;
}
.edu-testi-card__av {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: .75rem;
  font-weight: 700;
  color: #fff;
  flex-shrink: 0;
}
.edu-testi-card__name { font-size: .85rem; font-weight: 600; color: var(--edu-text); }
.edu-testi-card__role { font-size: .72rem; color: var(--edu-muted); }
.edu-testi-card__outcome {
  margin-left: auto;
  background: rgba(52,211,153,.1);
  border: 1px solid rgba(52,211,153,.25);
  border-radius: 20px;
  padding: .25rem .7rem;
  font-size: .65rem;
  letter-spacing: .08em;
  color: var(--edu-accent3);
  white-space: nowrap;
}

/* ============================================================
   ENROLL FORM
   ============================================================ */
.edu-enroll { background: var(--edu-bg); }
.edu-enroll__inner {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 5rem;
  align-items: start;
}
.edu-enroll__info { padding-top: .5rem; }
.edu-checklist { display: flex; flex-direction: column; gap: 1rem; margin-top: 2rem; }
.edu-check {
  display: flex;
  gap: .85rem;
  align-items: flex-start;
}
.edu-check__icon {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background: rgba(124,106,232,.15);
  border: 1px solid rgba(124,106,232,.3);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--edu-accent);
  flex-shrink: 0;
  margin-top: .1rem;
}
.edu-check__title { font-size: .88rem; font-weight: 600; color: var(--edu-text); margin-bottom: .15rem; }
.edu-check__desc { font-size: .8rem; color: var(--edu-muted); line-height: 1.6; }

.edu-form {
  background: var(--edu-card);
  border: 1px solid var(--edu-border);
  border-radius: 16px;
  padding: 2.5rem;
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
}
.edu-form__title {
  font-family: var(--tf-font-heading,'Plus Jakarta Sans','Inter',sans-serif);
  font-size: 1.35rem;
  font-weight: 700;
  color: var(--edu-text);
  margin: 0 0 .25rem;
}
.edu-form__sub { font-size: .83rem; color: var(--edu-muted); margin: 0 0 1rem; }
.edu-form__row { display: grid; grid-template-columns: 1fr 1fr; gap: .85rem; }
.edu-field { display: flex; flex-direction: column; gap: .4rem; }
.edu-field label {
  font-size: .72rem;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: var(--edu-muted);
}
.edu-field input,
.edu-field select,
.edu-field textarea {
  background: var(--edu-surface);
  border: 1px solid var(--edu-border);
  color: var(--edu-text);
  padding: .75rem 1rem;
  font-size: .88rem;
  font-family: inherit;
  outline: none;
  border-radius: 8px;
  transition: border-color .2s;
  box-sizing: border-box;
  width: 100%;
  -webkit-appearance: none;
}
.edu-field input:focus,
.edu-field select:focus,
.edu-field textarea:focus { border-color: var(--edu-accent); }
.edu-field select option { background: var(--edu-card); }
.edu-field textarea { resize: vertical; min-height: 90px; }
.edu-form__privacy { font-size: .73rem; color: var(--edu-muted); line-height: 1.6; }

/* ============================================================
   CTA
   ============================================================ */
.edu-cta {
  background: linear-gradient(135deg, #1a1540 0%, #0f0f1a 100%);
  padding: 6rem 0;
  text-align: center;
  border-top: 1px solid rgba(124,106,232,.2);
  position: relative;
  overflow: hidden;
}
.edu-cta::before {
  content: '';
  position: absolute;
  top: -50%;
  left: 50%;
  transform: translateX(-50%);
  width: 600px;
  height: 600px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(124,106,232,.15) 0%, transparent 70%);
  pointer-events: none;
}
.edu-cta__inner { position: relative; z-index: 1; }
.edu-cta__eyebrow {
  font-size: .7rem;
  letter-spacing: .2em;
  text-transform: uppercase;
  color: var(--edu-accent);
  margin-bottom: 1rem;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: .5rem;
}
.edu-cta__h2 {
  font-family: var(--tf-font-heading,'Plus Jakarta Sans','Inter',sans-serif);
  font-size: clamp(2.2rem,5vw,4rem);
  font-weight: 800;
  color: var(--edu-text);
  letter-spacing: -.03em;
  margin: 0 0 1rem;
}
.edu-cta__sub {
  font-size: 1rem;
  color: var(--edu-muted);
  max-width: 44ch;
  margin: 0 auto 2.5rem;
  line-height: 1.7;
}
.edu-cta__btns { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; }
.edu-btn--gold {
  background: var(--edu-accent2);
  color: #0d0d0d;
  box-shadow: 0 0 24px rgba(244,200,66,.3);
}
.edu-btn--gold:hover { background: #f0be30; }
.edu-btn--ghost {
  background: transparent;
  color: var(--edu-text);
  border: 1px solid var(--edu-border);
}
.edu-btn--ghost:hover { border-color: var(--edu-accent); color: var(--edu-accent); }

/* ============================================================
   RESPONSIVE
   ============================================================ */
@media (max-width: 1100px) {
  .edu-faculty__grid { grid-template-columns: repeat(2,1fr); }
  .edu-programs__grid { grid-template-columns: repeat(2,1fr); }
}
@media (max-width: 960px) {
  .edu-hero { grid-template-columns: 1fr; }
  .edu-hero__visual { display: none; }
  .edu-hero__copy { padding: 5rem 2.5rem; }
  .edu-research__inner { grid-template-columns: 1fr; gap: 3rem; }
  .edu-enroll__inner { grid-template-columns: 1fr; gap: 3rem; }
  .edu-events__inner { grid-template-columns: 1fr; gap: 2rem; }
  .edu-testimonials__grid { grid-template-columns: 1fr 1fr; }
}
@media (max-width: 640px) {
  .edu-container { padding: 0 1.5rem; }
  .edu-section { padding: 4rem 0; }
  .edu-programs__grid { grid-template-columns: 1fr; }
  .edu-testimonials__grid { grid-template-columns: 1fr; }
  .edu-faculty__grid { grid-template-columns: 1fr; }
  .edu-stats-bar__inner { grid-template-columns: 1fr 1fr; }
  .edu-research__stats { grid-template-columns: 1fr 1fr; }
  .edu-form__row { grid-template-columns: 1fr; }
}
</style>

<main class="tf-edu-page" id="main">

  <?php
  // ============================================================
  // HERO
  // ============================================================
  ?>
  <section class="edu-hero" aria-label="<?php esc_attr_e( 'University homepage hero', 'themeflex' ); ?>">

    <!-- Copy -->
    <div class="edu-hero__copy">
      <div class="edu-hero__badge">
        <?php tf_icon( 'award', 13 ); ?>
        <?php esc_html_e( '#1 Research University — Germany 2024', 'themeflex' ); ?>
      </div>

      <h1 class="edu-hero__h1">
        <?php esc_html_e( 'Shape the', 'themeflex' ); ?><br>
        <span><?php esc_html_e( 'Future', 'themeflex' ); ?></span><br>
        <?php esc_html_e( 'With Us', 'themeflex' ); ?>
      </h1>

      <p class="edu-hero__sub">
        <?php esc_html_e( 'Universität Nordica is a world-leading research university offering 240+ programmes across science, humanities, business, and engineering — ranked top 50 globally.', 'themeflex' ); ?>
      </p>

      <div class="edu-hero__ctas">
        <a href="#enroll" class="edu-btn edu-btn--primary">
          <?php tf_icon( 'graduation-cap', 18 ); ?>
          <?php esc_html_e( 'Apply Now', 'themeflex' ); ?>
        </a>
        <a href="#programs" class="edu-btn edu-btn--outline">
          <?php tf_icon( 'book-open', 18 ); ?>
          <?php esc_html_e( 'Explore Programs', 'themeflex' ); ?>
        </a>
      </div>

      <div class="edu-hero__trust">
        <div class="edu-hero__trust-avatars" aria-hidden="true">
          <?php
          $av_colors = ['#7c6ae8','#f4c842','#34d399','#ec4899','#3b82f6'];
          $av_inits  = ['M','S','J','A','T'];
          foreach ( $av_inits as $i => $init ) :
          ?>
          <div class="edu-hero__trust-av"
               style="background:<?php echo esc_attr( $av_colors[ $i ] ); ?>;">
            <?php echo esc_html( $init ); ?>
          </div>
          <?php endforeach; ?>
        </div>
        <div class="edu-hero__trust-text">
          <strong>38,000+</strong> students enrolled<br>
          <?php esc_html_e( 'across 12 schools and faculties', 'themeflex' ); ?>
        </div>
      </div>
    </div>

    <!-- Visual -->
    <div class="edu-hero__visual" aria-hidden="true">
      <!-- Stars -->
      <?php
      $star_positions = [
        ['top'=>'12%','left'=>'15%','d'=>'3s','dl'=>'0s'],
        ['top'=>'25%','left'=>'72%','d'=>'5s','dl'=>'1s'],
        ['top'=>'8%','left'=>'88%','d'=>'4s','dl'=>'.5s'],
        ['top'=>'45%','left'=>'92%','d'=>'3.5s','dl'=>'1.5s'],
        ['top'=>'18%','left'=>'45%','d'=>'6s','dl'=>'.2s'],
      ];
      foreach ( $star_positions as $sp ) :
      ?>
      <div class="edu-star"
           style="top:<?php echo esc_attr($sp['top']); ?>;left:<?php echo esc_attr($sp['left']); ?>;--d:<?php echo esc_attr($sp['d']); ?>;--dl:<?php echo esc_attr($sp['dl']); ?>;"></div>
      <?php endforeach; ?>

      <div class="edu-sky-grid"></div>

      <div class="edu-campus">
        <div class="edu-bld">
          <!-- Wings -->
          <div class="edu-wing edu-wing--left">
            <?php for($i=0;$i<10;$i++): ?>
            <div class="edu-wing-win<?php echo ($i%3===0)?' lit':''; ?>"></div>
            <?php endfor; ?>
          </div>
          <div class="edu-wing edu-wing--right">
            <?php for($i=0;$i<10;$i++): ?>
            <div class="edu-wing-win<?php echo ($i%4===1)?' lit':''; ?>"></div>
            <?php endfor; ?>
          </div>

          <!-- Dome -->
          <div class="edu-dome">
            <div class="edu-dome-glow"></div>
          </div>

          <!-- Portico -->
          <div class="edu-portico">
            <?php for($i=0;$i<7;$i++): ?>
            <div class="edu-col"></div>
            <?php endfor; ?>
          </div>

          <!-- Body -->
          <div class="edu-body">
            <div class="edu-windows">
              <?php
              $win_lit = [0,2,5,7,9,10,13,14,16,18];
              for ($i=0; $i<20; $i++):
              $delay = ($i * 0.3) . 's';
              $dur = (3 + ($i % 4)) . 's';
              ?>
              <div class="edu-win<?php echo in_array($i,$win_lit)?' lit':''; ?>"
                   style="--dur:<?php echo esc_attr($dur); ?>;--del:<?php echo esc_attr($delay); ?>;"></div>
              <?php endfor; ?>
            </div>
            <div class="edu-door"></div>
          </div>

          <!-- Steps -->
          <div class="edu-steps">
            <div class="edu-step"></div>
            <div class="edu-step"></div>
            <div class="edu-step"></div>
          </div>
        </div>
      </div>

      <!-- Floating info card -->
      <div class="edu-hero__card">
        <div class="edu-hero__card-title"><?php esc_html_e( 'Acceptance Rates', 'themeflex' ); ?></div>
        <?php
        $rates = [
          [ 'dot' => '#7c6ae8', 'lbl' => __( 'Engineering', 'themeflex' ), 'val' => '12%' ],
          [ 'dot' => '#f4c842', 'lbl' => __( 'Business',    'themeflex' ), 'val' => '18%' ],
          [ 'dot' => '#34d399', 'lbl' => __( 'Medicine',    'themeflex' ), 'val' => '6%'  ],
          [ 'dot' => '#ec4899', 'lbl' => __( 'Law',         'themeflex' ), 'val' => '15%' ],
        ];
        foreach ($rates as $r):
        ?>
        <div class="edu-hero__card-stat">
          <div class="edu-hero__card-dot" style="background:<?php echo esc_attr($r['dot']); ?>;"></div>
          <div class="edu-hero__card-lbl"><?php echo esc_html($r['lbl']); ?></div>
          <div class="edu-hero__card-val" style="color:<?php echo esc_attr($r['dot']); ?>;"><?php echo esc_html($r['val']); ?></div>
        </div>
        <?php endforeach; ?>
      </div>

      <!-- Acceptance pill -->
      <div class="edu-accept-pill">
        <?php tf_icon( 'check-circle', 14 ); ?>
        <?php esc_html_e( 'Applications Open · Winter 2026', 'themeflex' ); ?>
      </div>
    </div>

  </section><!-- .edu-hero -->

  <?php
  // ============================================================
  // STATS BAR
  // ============================================================
  $stats = [
    [ 'val' => '38000', 'suffix' => '+', 'lbl' => __( 'Students Enrolled', 'themeflex' ) ],
    [ 'val' => '240',   'suffix' => '+', 'lbl' => __( 'Degree Programmes', 'themeflex' ) ],
    [ 'val' => '4800',  'suffix' => '+', 'lbl' => __( 'Faculty Members',   'themeflex' ) ],
    [ 'val' => '98',    'suffix' => '%', 'lbl' => __( 'Graduate Employment','themeflex') ],
  ];
  ?>
  <div class="edu-stats-bar" role="region"
       aria-label="<?php esc_attr_e( 'University statistics', 'themeflex' ); ?>">
    <div class="edu-container">
      <div class="edu-stats-bar__inner">
        <?php foreach ($stats as $s): ?>
        <div class="edu-stat">
          <div class="edu-stat__val"
               data-counter="<?php echo esc_attr($s['val']); ?>"
               data-suffix="<?php echo esc_attr($s['suffix']); ?>">
            <?php echo esc_html($s['val'].$s['suffix']); ?>
          </div>
          <div class="edu-stat__lbl"><?php echo esc_html($s['lbl']); ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <?php
  // ============================================================
  // PROGRAMS
  // ============================================================
  $programs = [
    [
      'icon' => 'cpu', 'icon_bg' => 'rgba(124,106,232,.15)', 'icon_col' => '#7c6ae8',
      'glow' => 'rgba(124,106,232,.06)',
      'level' => __( 'Bachelor · Master · PhD', 'themeflex' ),
      'name'  => __( 'Computer Science & AI', 'themeflex' ),
      'desc'  => __( 'From algorithms and systems to machine learning and robotics — a programme shaping the engineers behind tomorrow\'s breakthroughs.', 'themeflex' ),
      'meta'  => [ [ 'icon'=>'clock', 'text' => '3–5 Years' ], [ 'icon'=>'users', 'text' => '840 Students' ] ],
    ],
    [
      'icon' => 'flask-conical', 'icon_bg' => 'rgba(52,211,153,.12)', 'icon_col' => '#34d399',
      'glow' => 'rgba(52,211,153,.06)',
      'level' => __( 'Bachelor · Master · PhD', 'themeflex' ),
      'name'  => __( 'Life Sciences & Medicine', 'themeflex' ),
      'desc'  => __( 'Top-ranked medical faculty with world-class research facilities, clinical partnerships, and an 100% match rate for residency placements.', 'themeflex' ),
      'meta'  => [ [ 'icon'=>'clock', 'text' => '4–6 Years' ], [ 'icon'=>'users', 'text' => '1,200 Students' ] ],
    ],
    [
      'icon' => 'trending-up', 'icon_bg' => 'rgba(244,200,66,.12)', 'icon_col' => '#f4c842',
      'glow' => 'rgba(244,200,66,.06)',
      'level' => __( 'Bachelor · MBA · PhD', 'themeflex' ),
      'name'  => __( 'Business & Economics', 'themeflex' ),
      'desc'  => __( 'Triple-accredited (AACSB, EQUIS, AMBA) school producing entrepreneurs and executives with a global alumni network in 90 countries.', 'themeflex' ),
      'meta'  => [ [ 'icon'=>'clock', 'text' => '2–4 Years' ], [ 'icon'=>'users', 'text' => '2,400 Students' ] ],
    ],
    [
      'icon' => 'landmark', 'icon_bg' => 'rgba(236,72,153,.1)', 'icon_col' => '#ec4899',
      'glow' => 'rgba(236,72,153,.05)',
      'level' => __( 'Bachelor · Master · PhD', 'themeflex' ),
      'name'  => __( 'Law &amp; Political Science', 'themeflex' ),
      'desc'  => __( 'A faculty combining the rigour of German legal tradition with international perspectives — bar-passage rate of 96% across graduating classes.', 'themeflex' ),
      'meta'  => [ [ 'icon'=>'clock', 'text' => '4–5 Years' ], [ 'icon'=>'users', 'text' => '960 Students' ] ],
    ],
    [
      'icon' => 'zap', 'icon_bg' => 'rgba(59,130,246,.12)', 'icon_col' => '#3b82f6',
      'glow' => 'rgba(59,130,246,.05)',
      'level' => __( 'Bachelor · Master · PhD', 'themeflex' ),
      'name'  => __( 'Engineering & Physics', 'themeflex' ),
      'desc'  => __( 'Ranked 8th globally in mechanical and civil engineering — with industry-integrated labs, semester projects, and direct pathways to leading firms.', 'themeflex' ),
      'meta'  => [ [ 'icon'=>'clock', 'text' => '3–5 Years' ], [ 'icon'=>'users', 'text' => '1,800 Students' ] ],
    ],
    [
      'icon' => 'palette', 'icon_bg' => 'rgba(251,146,60,.1)', 'icon_col' => '#fb923c',
      'glow' => 'rgba(251,146,60,.05)',
      'level' => __( 'Bachelor · Master', 'themeflex' ),
      'name'  => __( 'Arts, Design & Architecture', 'themeflex' ),
      'desc'  => __( 'An internationally renowned faculty producing practising artists, architects, and designers — with studios, galleries, and an annual graduate showcase.', 'themeflex' ),
      'meta'  => [ [ 'icon'=>'clock', 'text' => '3–4 Years' ], [ 'icon'=>'users', 'text' => '620 Students' ] ],
    ],
  ];
  ?>
  <section class="edu-section edu-programs" id="programs"
           aria-labelledby="edu-programs-h">
    <div class="edu-container">
      <div class="edu-programs__header">
        <div>
          <div class="edu-label">
            <span class="edu-label-dot" aria-hidden="true"></span>
            <?php esc_html_e( 'Academic Programmes', 'themeflex' ); ?>
          </div>
          <h2 class="edu-h2" id="edu-programs-h">
            <?php esc_html_e( 'Find Your Programme', 'themeflex' ); ?>
          </h2>
          <p class="edu-lead">
            <?php esc_html_e( '240+ degree programmes across 12 faculties — from bachelor\'s to doctoral level.', 'themeflex' ); ?>
          </p>
        </div>
        <a href="#" class="edu-btn edu-btn--outline">
          <?php esc_html_e( 'All Programmes', 'themeflex' ); ?>
          <?php tf_icon( 'arrow-right', 16 ); ?>
        </a>
      </div>

      <div class="edu-programs__grid">
        <?php foreach ($programs as $prog): ?>
        <a href="#" class="edu-program-card">
          <div class="edu-program-card__glow"
               style="background:radial-gradient(circle at 50% 100%, <?php echo esc_attr($prog['glow']); ?> 0%, transparent 60%);"></div>
          <div class="edu-program-card__icon"
               style="background:<?php echo esc_attr($prog['icon_bg']); ?>;"
               aria-hidden="true">
            <span style="color:<?php echo esc_attr($prog['icon_col']); ?>;">
              <?php tf_icon( $prog['icon'], 22 ); ?>
            </span>
          </div>
          <div class="edu-program-card__level"><?php echo esc_html($prog['level']); ?></div>
          <h3 class="edu-program-card__name"><?php echo wp_kses_post($prog['name']); ?></h3>
          <p class="edu-program-card__desc"><?php echo esc_html($prog['desc']); ?></p>
          <div class="edu-program-card__meta">
            <?php foreach ($prog['meta'] as $m): ?>
            <div class="edu-program-card__meta-item">
              <?php tf_icon( $m['icon'], 13 ); ?>
              <?php echo esc_html($m['text']); ?>
            </div>
            <?php endforeach; ?>
          </div>
        </a>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // EVENTS STRIP
  // ============================================================
  $events = [
    [ 'day'=>'14', 'month'=>'May', 'type'=>__('Open Day','themeflex'),    'title'=>__('Undergraduate Open Campus Day — All Faculties','themeflex'), 'meta'=>[__('9:00 – 17:00','themeflex'), __('Main Campus','themeflex')] ],
    [ 'day'=>'22', 'month'=>'May', 'type'=>__('Lecture','themeflex'),     'title'=>__('Distinguished Lecture: The Future of Quantum Computing','themeflex'), 'meta'=>[__('18:30','themeflex'), __('Audimax Hall','themeflex')] ],
    [ 'day'=>'03', 'month'=>'Jun', 'type'=>__('Career Fair','themeflex'), 'title'=>__('STEM Career & Internship Fair 2026','themeflex'), 'meta'=>[__('10:00 – 16:00','themeflex'), __('Sports Pavilion','themeflex')] ],
    [ 'day'=>'12', 'month'=>'Jun', 'type'=>__('Symposium','themeflex'),   'title'=>__('International Climate & Sustainability Symposium','themeflex'), 'meta'=>[__('Full Day','themeflex'), __('Conference Centre','themeflex')] ],
  ];
  ?>
  <div class="edu-events" role="region"
       aria-label="<?php esc_attr_e( 'Upcoming campus events', 'themeflex' ); ?>">
    <div class="edu-container">
      <div class="edu-events__inner">
        <div>
          <div class="edu-label">
            <span class="edu-label-dot" aria-hidden="true"></span>
            <?php esc_html_e( 'Campus Events', 'themeflex' ); ?>
          </div>
          <h2 class="edu-h2" style="font-size:clamp(1.6rem,2.5vw,2.2rem);">
            <?php esc_html_e( "What's On", 'themeflex' ); ?>
          </h2>
          <a href="#" class="edu-btn edu-btn--outline" style="margin-top:1.5rem;">
            <?php esc_html_e( 'Full Calendar', 'themeflex' ); ?>
            <?php tf_icon( 'calendar', 16 ); ?>
          </a>
        </div>
        <div class="edu-events__list">
          <?php foreach ($events as $ev): ?>
          <a href="#" class="edu-event">
            <div class="edu-event__date">
              <div class="edu-event__day"><?php echo esc_html($ev['day']); ?></div>
              <div class="edu-event__month"><?php echo esc_html($ev['month']); ?></div>
            </div>
            <div>
              <div class="edu-event__type"><?php echo esc_html($ev['type']); ?></div>
              <div class="edu-event__title"><?php echo esc_html($ev['title']); ?></div>
              <div class="edu-event__meta">
                <?php foreach ($ev['meta'] as $m): ?>
                <span><?php echo esc_html($m); ?></span>
                <?php endforeach; ?>
              </div>
            </div>
            <div class="edu-event__arrow" aria-hidden="true">
              <?php tf_icon('arrow-right',16); ?>
            </div>
          </a>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>

  <?php
  // ============================================================
  // FACULTY
  // ============================================================
  $faculty = [
    [ 'initials'=>'PK','bg'=>'linear-gradient(135deg,#7c6ae8,#4f46e5)','name'=>'Prof. Dr. Klaus Weber','dept'=>__('Computer Science','themeflex'),'bio'=>__('Head of AI & Robotics Lab, 200+ publications, former Google Brain research lead.','themeflex'),'badge'=>__('IEEE Fellow','themeflex') ],
    [ 'initials'=>'MS','bg'=>'linear-gradient(135deg,#34d399,#059669)','name'=>'Prof. Dr. Maria Schaefer','dept'=>__('Molecular Biology','themeflex'),'bio'=>__('ERC Advanced Grant laureate. Her protein folding research has been cited 14,000+ times.','themeflex'),'badge'=>__('ERC Laureate','themeflex') ],
    [ 'initials'=>'JB','bg'=>'linear-gradient(135deg,#f4c842,#d97706)','name'=>'Prof. Dr. Jonas Braun','dept'=>__('Economics','themeflex'),'bio'=>__('Former ECB advisor. Author of three foundational macroeconomics textbooks used across Europe.','themeflex'),'badge'=>__('ECB Advisor','themeflex') ],
    [ 'initials'=>'AL','bg'=>'linear-gradient(135deg,#ec4899,#be185d)','name'=>'Prof. Dr. Anna Lenz','dept'=>__('International Law','themeflex'),'bio'=>__('UN Special Rapporteur on digital rights. Award-winning legal scholar and published author of seven books.','themeflex'),'badge'=>__('UN Rapporteur','themeflex') ],
  ];
  ?>
  <section class="edu-section edu-faculty"
           aria-labelledby="edu-faculty-h">
    <div class="edu-container">
      <div class="edu-label">
        <span class="edu-label-dot" aria-hidden="true"></span>
        <?php esc_html_e( 'Faculty', 'themeflex' ); ?>
      </div>
      <h2 class="edu-h2" id="edu-faculty-h"><?php esc_html_e( 'World-Class Professors', 'themeflex' ); ?></h2>
      <p class="edu-lead"><?php esc_html_e( 'Learn from Nobel laureates, ERC grant holders, and leading practitioners at the forefront of their fields.', 'themeflex' ); ?></p>

      <div class="edu-faculty__grid">
        <?php foreach ($faculty as $f): ?>
        <div class="edu-faculty-card">
          <div class="edu-faculty-card__av" style="background:<?php echo esc_attr($f['bg']); ?>;">
            <?php echo esc_html($f['initials']); ?>
          </div>
          <div class="edu-faculty-card__name"><?php echo esc_html($f['name']); ?></div>
          <div class="edu-faculty-card__dept"><?php echo esc_html($f['dept']); ?></div>
          <p class="edu-faculty-card__bio"><?php echo esc_html($f['bio']); ?></p>
          <span class="edu-faculty-card__badge">
            <?php tf_icon('star',12); ?>
            <?php echo esc_html($f['badge']); ?>
          </span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // RESEARCH
  // ============================================================
  ?>
  <section class="edu-section edu-research"
           aria-labelledby="edu-research-h">
    <div class="edu-container">
      <div class="edu-research__inner">
        <!-- Visualization -->
        <div class="edu-research__viz">
          <div class="edu-viz-title">
            <?php tf_icon('bar-chart-2',15); ?>
            <?php esc_html_e( 'Research Output by Field (2025)', 'themeflex' ); ?>
          </div>
          <div class="edu-research-bars">
            <?php
            $bars = [
              [ 'label'=>__('Life Sciences & Medicine','themeflex'), 'pct'=>88, 'color'=>'#34d399', 'del'=>'0s'  ],
              [ 'label'=>__('Engineering & Technology', 'themeflex'), 'pct'=>76, 'color'=>'#7c6ae8', 'del'=>'.15s' ],
              [ 'label'=>__('Economics & Finance',      'themeflex'), 'pct'=>64, 'color'=>'#f4c842', 'del'=>'.3s'  ],
              [ 'label'=>__('Law & Social Sciences',    'themeflex'), 'pct'=>52, 'color'=>'#ec4899', 'del'=>'.45s' ],
              [ 'label'=>__('Arts & Humanities',        'themeflex'), 'pct'=>38, 'color'=>'#fb923c', 'del'=>'.6s'  ],
            ];
            foreach ($bars as $b):
            ?>
            <div class="edu-res-bar">
              <div class="edu-res-bar__header">
                <span class="edu-res-bar__label"><?php echo esc_html($b['label']); ?></span>
                <span class="edu-res-bar__val" style="color:<?php echo esc_attr($b['color']); ?>;"><?php echo intval($b['pct']); ?>%</span>
              </div>
              <div class="edu-res-bar__track">
                <div class="edu-res-bar__fill"
                     style="width:<?php echo intval($b['pct']); ?>%;background:<?php echo esc_attr($b['color']); ?>;--del:<?php echo esc_attr($b['del']); ?>;"></div>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
          <div class="edu-research__stats">
            <?php
            $res_stats = [
              [ 'val'=>'€480M', 'lbl'=>__('Research Funding','themeflex') ],
              [ 'val'=>'12,400','lbl'=>__('Publications / yr','themeflex') ],
              [ 'val'=>'340',   'lbl'=>__('Active Projects', 'themeflex') ],
              [ 'val'=>'62',    'lbl'=>__('Industry Partners','themeflex') ],
            ];
            foreach ($res_stats as $rs):
            ?>
            <div class="edu-res-stat">
              <div class="edu-res-stat__val"><?php echo esc_html($rs['val']); ?></div>
              <div class="edu-res-stat__lbl"><?php echo esc_html($rs['lbl']); ?></div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>

        <!-- Copy -->
        <div class="edu-research__copy">
          <div class="edu-label">
            <span class="edu-label-dot" aria-hidden="true"></span>
            <?php esc_html_e( 'Research Excellence', 'themeflex' ); ?>
          </div>
          <h2 class="edu-h2" id="edu-research-h">
            <?php esc_html_e( 'Advancing the Boundaries of Knowledge', 'themeflex' ); ?>
          </h2>
          <p class="edu-lead">
            <?php esc_html_e( 'With €480M in annual research funding and 12,400 peer-reviewed publications, Universität Nordica is one of Europe\'s most productive research ecosystems.', 'themeflex' ); ?>
          </p>

          <div class="edu-research__areas">
            <?php
            $areas = [
              [ 'icon'=>'cpu',        'bg'=>'rgba(124,106,232,.1)', 'col'=>'#7c6ae8', 'name'=>__('Artificial Intelligence & Robotics','themeflex'), 'sub'=>__('NLP, computer vision, autonomous systems, HRI','themeflex') ],
              [ 'icon'=>'heart-pulse','bg'=>'rgba(52,211,153,.1)',  'col'=>'#34d399', 'name'=>__('Biomedical Research & Genomics','themeflex'),     'sub'=>__('CRISPR, oncology, personalised medicine','themeflex') ],
              [ 'icon'=>'leaf',       'bg'=>'rgba(244,200,66,.1)',  'col'=>'#f4c842', 'name'=>__('Climate Science & Sustainability','themeflex'),    'sub'=>__('Energy transition, carbon capture, urban ecology','themeflex') ],
              [ 'icon'=>'globe',      'bg'=>'rgba(236,72,153,.1)',  'col'=>'#ec4899', 'name'=>__('Global Governance & Digital Rights','themeflex'), 'sub'=>__('AI regulation, data sovereignty, international law','themeflex') ],
            ];
            foreach ($areas as $ar):
            ?>
            <div class="edu-research-area">
              <div class="edu-research-area__icon"
                   style="background:<?php echo esc_attr($ar['bg']); ?>;color:<?php echo esc_attr($ar['col']); ?>;"
                   aria-hidden="true">
                <?php tf_icon($ar['icon'],18); ?>
              </div>
              <div>
                <div class="edu-research-area__name"><?php echo esc_html($ar['name']); ?></div>
                <div class="edu-research-area__sub"><?php echo esc_html($ar['sub']); ?></div>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // ALUMNI TESTIMONIALS
  // ============================================================
  $testimonials = [
    [ 'text'=>__('The professors at Nordica are truly world-class. My AI seminar with Prof. Weber directly led to me co-founding a startup that\'s now valued at €40M. I could not have done it without this foundation.','themeflex'), 'initials'=>'TK','bg'=>'#7c6ae8','name'=>'Dr. Thomas Klein','role'=>__('CEO, NeuralVox GmbH · MSc AI 2019','themeflex'), 'outcome'=>__('€40M Startup','themeflex') ],
    [ 'text'=>__('The research facilities and clinical partnerships I had access to during my medical doctorate were extraordinary. I published three papers before graduating and matched into my first-choice residency.','themeflex'), 'initials'=>'LH','bg'=>'#34d399','name'=>'Dr. Laura Hoffmann','role'=>__('Cardiologist, Charité Berlin · MD 2020','themeflex'), 'outcome'=>__('Charité Residency','themeflex') ],
    [ 'text'=>__('My MBA at Nordica gave me the international perspective and the network to transition from consulting into venture capital. Three portfolio companies later, it remains the best investment I ever made.','themeflex'), 'initials'=>'MR','bg'=>'#f4c842','name'=>'Marcus Richter','role'=>__('Partner, Alpine Ventures · MBA 2017','themeflex'), 'outcome'=>__('€120M VC Portfolio','themeflex') ],
  ];
  ?>
  <section class="edu-section edu-testimonials"
           aria-labelledby="edu-testi-h">
    <div class="edu-container">
      <div class="edu-label">
        <span class="edu-label-dot" aria-hidden="true"></span>
        <?php esc_html_e( 'Alumni Stories', 'themeflex' ); ?>
      </div>
      <h2 class="edu-h2" id="edu-testi-h"><?php esc_html_e( 'Graduates Who Changed the World', 'themeflex' ); ?></h2>

      <div class="edu-testimonials__grid">
        <?php foreach ($testimonials as $t): ?>
        <div class="edu-testi-card">
          <span class="edu-testi-card__quote-icon" aria-hidden="true">"</span>
          <p class="edu-testi-card__text"><?php echo esc_html($t['text']); ?></p>
          <div class="edu-testi-card__footer">
            <div class="edu-testi-card__av" style="background:<?php echo esc_attr($t['bg']); ?>;">
              <?php echo esc_html($t['initials']); ?>
            </div>
            <div>
              <div class="edu-testi-card__name"><?php echo esc_html($t['name']); ?></div>
              <div class="edu-testi-card__role"><?php echo esc_html($t['role']); ?></div>
            </div>
            <span class="edu-testi-card__outcome"><?php echo esc_html($t['outcome']); ?></span>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // ENROLL FORM
  // ============================================================
  ?>
  <section class="edu-section edu-enroll" id="enroll"
           aria-labelledby="edu-enroll-h">
    <div class="edu-container">
      <div class="edu-enroll__inner">

        <!-- Info -->
        <div class="edu-enroll__info">
          <div class="edu-label">
            <span class="edu-label-dot" aria-hidden="true"></span>
            <?php esc_html_e( 'Start Your Application', 'themeflex' ); ?>
          </div>
          <h2 class="edu-h2" id="edu-enroll-h">
            <?php esc_html_e( 'Apply for Winter Semester 2026', 'themeflex' ); ?>
          </h2>
          <p class="edu-lead">
            <?php esc_html_e( 'Applications are now open. Our admissions team will guide you through every step — from choosing a programme to submitting your documents.', 'themeflex' ); ?>
          </p>

          <div class="edu-checklist">
            <?php
            $checks = [
              [ 'title'=>__('Free Application','themeflex'),        'desc'=>__('No application fee for all bachelor\'s and master\'s programmes.','themeflex') ],
              [ 'title'=>__('Rolling Admissions','themeflex'),       'desc'=>__('Applications reviewed on a rolling basis until 31 July 2026.','themeflex') ],
              [ 'title'=>__('Scholarships Available','themeflex'),   'desc'=>__('Merit and need-based scholarships cover up to 100% of tuition.','themeflex') ],
              [ 'title'=>__('International Welcome','themeflex'),    'desc'=>__('180+ nationalities represented. English-track programmes available.','themeflex') ],
              [ 'title'=>__('Response in 10 Business Days','themeflex'), 'desc'=>__('Preliminary admission decisions returned within 10 business days of complete application.','themeflex') ],
            ];
            foreach ($checks as $c):
            ?>
            <div class="edu-check">
              <div class="edu-check__icon" aria-hidden="true">
                <?php tf_icon('check',12); ?>
              </div>
              <div>
                <div class="edu-check__title"><?php echo esc_html($c['title']); ?></div>
                <div class="edu-check__desc"><?php echo esc_html($c['desc']); ?></div>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>

        <!-- Form -->
        <form class="edu-form" method="post" novalidate
              aria-label="<?php esc_attr_e( 'Application enquiry form', 'themeflex' ); ?>">
          <?php wp_nonce_field('edu_enroll_enquiry','edu_enroll_nonce'); ?>

          <h3 class="edu-form__title"><?php esc_html_e( 'Request Information', 'themeflex' ); ?></h3>
          <p class="edu-form__sub"><?php esc_html_e( "Fill in your details and we'll send you a personalised programme guide.", 'themeflex' ); ?></p>

          <div class="edu-form__row">
            <div class="edu-field">
              <label for="edu-first"><?php esc_html_e('First Name','themeflex'); ?></label>
              <input type="text" id="edu-first" name="first_name"
                     placeholder="<?php esc_attr_e('Maria','themeflex'); ?>"
                     required autocomplete="given-name">
            </div>
            <div class="edu-field">
              <label for="edu-last"><?php esc_html_e('Last Name','themeflex'); ?></label>
              <input type="text" id="edu-last" name="last_name"
                     placeholder="<?php esc_attr_e('Müller','themeflex'); ?>"
                     required autocomplete="family-name">
            </div>
          </div>

          <div class="edu-field">
            <label for="edu-email"><?php esc_html_e('Email Address','themeflex'); ?></label>
            <input type="email" id="edu-email" name="email"
                   placeholder="maria@example.com" required autocomplete="email">
          </div>

          <div class="edu-form__row">
            <div class="edu-field">
              <label for="edu-degree"><?php esc_html_e('Degree Level','themeflex'); ?></label>
              <select id="edu-degree" name="degree_level">
                <option value="" disabled selected><?php esc_html_e('Select level…','themeflex'); ?></option>
                <option value="bachelor"><?php esc_html_e('Bachelor\'s','themeflex'); ?></option>
                <option value="master"><?php esc_html_e('Master\'s','themeflex'); ?></option>
                <option value="mba"><?php esc_html_e('MBA','themeflex'); ?></option>
                <option value="phd"><?php esc_html_e('PhD / Doctoral','themeflex'); ?></option>
              </select>
            </div>
            <div class="edu-field">
              <label for="edu-program"><?php esc_html_e('Area of Study','themeflex'); ?></label>
              <select id="edu-program" name="program">
                <option value="" disabled selected><?php esc_html_e('Select area…','themeflex'); ?></option>
                <?php
                $areas_opt = [
                  'cs-ai'     => __('Computer Science & AI','themeflex'),
                  'medicine'  => __('Life Sciences & Medicine','themeflex'),
                  'business'  => __('Business & Economics','themeflex'),
                  'law'       => __('Law & Political Science','themeflex'),
                  'engineering'=>__('Engineering & Physics','themeflex'),
                  'arts'      => __('Arts, Design & Architecture','themeflex'),
                ];
                foreach ($areas_opt as $val=>$lbl):
                ?>
                <option value="<?php echo esc_attr($val); ?>"><?php echo esc_html($lbl); ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <div class="edu-field">
            <label for="edu-country"><?php esc_html_e('Country of Residence','themeflex'); ?></label>
            <input type="text" id="edu-country" name="country"
                   placeholder="<?php esc_attr_e('Germany','themeflex'); ?>" autocomplete="country-name">
          </div>

          <p class="edu-form__privacy">
            <?php esc_html_e('Your data is processed pursuant to GDPR. We will only use your information to respond to your enquiry and send programme information. You may unsubscribe at any time.','themeflex'); ?>
          </p>

          <button type="submit" class="edu-btn edu-btn--primary">
            <?php tf_icon('send',16); ?>
            <?php esc_html_e('Request Programme Guide','themeflex'); ?>
          </button>
        </form>

      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // CTA
  // ============================================================
  ?>
  <section class="edu-cta" aria-label="<?php esc_attr_e('Call to action','themeflex'); ?>">
    <div class="edu-container edu-cta__inner">
      <div class="edu-cta__eyebrow">
        <?php tf_icon('star',14); ?>
        <?php esc_html_e('Ranked Top 50 Globally — QS World University Rankings 2025','themeflex'); ?>
      </div>
      <h2 class="edu-cta__h2"><?php esc_html_e('Your Future Starts Here','themeflex'); ?></h2>
      <p class="edu-cta__sub">
        <?php esc_html_e('Join 38,000 students from 180+ countries studying at one of Europe\'s finest research universities. Applications for Winter 2026 are open.','themeflex'); ?>
      </p>
      <div class="edu-cta__btns">
        <a href="#enroll" class="edu-btn edu-btn--gold">
          <?php tf_icon('graduation-cap',18); ?>
          <?php esc_html_e('Apply Now — Free','themeflex'); ?>
        </a>
        <a href="#programs" class="edu-btn edu-btn--ghost">
          <?php esc_html_e('Explore All Programmes','themeflex'); ?>
          <?php tf_icon('arrow-right',16); ?>
        </a>
      </div>
    </div>
  </section>

</main>

<script>
/* Education page — animated stat counters */
(function(){
  'use strict';
  function animateCounter(el){
    const raw = el.dataset.counter;
    const num = parseInt(raw.replace(/\D/g,''),10);
    const suffix = el.dataset.suffix||'';
    // Preserve non-numeric prefix (e.g. '€')
    const prefix = raw.match(/^[^0-9]*/)[0];
    const dur = 1600;
    let start;
    function step(ts){
      if(!start) start=ts;
      const p=Math.min((ts-start)/dur,1);
      const ease=1-Math.pow(1-p,3);
      el.textContent=prefix+Math.round(ease*num).toLocaleString('de-DE')+suffix;
      if(p<1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }
  const counters=document.querySelectorAll('.tf-edu-page [data-counter]');
  if(!counters.length) return;
  const obs=new IntersectionObserver(function(entries){
    entries.forEach(function(e){
      if(e.isIntersecting){ animateCounter(e.target); obs.unobserve(e.target); }
    });
  },{threshold:0.5});
  counters.forEach(function(c){obs.observe(c);});
})();
</script>

<?php get_footer(); ?>
