<?php
/**
 * Template Name: Electrician
 * Description: Premium page template for Electrician / Electrical Contractor businesses
 *
 * @package ThemeFlex
 */

// Fonts: Oswald + Nunito Sans
// Namespace: --el-*
// Hero: CSS circuit board / live fuse box scene — glowing circuit traces, breaker panel, lightning bolt
// Palette: deep charcoal #1A1A2E / electric yellow #FFD700 / volt orange #FF6B35 / steel blue #4A90D9 / cool white #F0F4F8

if ( ! defined( 'ABSPATH' ) ) exit;
srand( crc32( get_the_permalink() ) );

$el_services = [
    [ 'icon' => '⚡', 'title' => 'Rewiring & Upgrades',       'desc' => 'Full property rewiring, consumer unit upgrades and electrical panel replacements to modern standards.' ],
    [ 'icon' => '🔌', 'title' => 'New Installations',          'desc' => 'Sockets, lighting, circuits and first-fix electrical work for new builds and extensions.' ],
    [ 'icon' => '🏠', 'title' => 'Domestic Electrical',        'desc' => 'Complete home electrical services from fault finding to full installations, all Part P compliant.' ],
    [ 'icon' => '🏢', 'title' => 'Commercial Electrical',      'desc' => 'Office fit-outs, retail electrics, three-phase supply installations and commercial testing.' ],
    [ 'icon' => '🔦', 'title' => 'Fault Finding & Repairs',    'desc' => 'Expert diagnosis of tripping circuits, power failures, RCD faults and nuisance trips.' ],
    [ 'icon' => '🛡️', 'title' => 'EICR Testing',              'desc' => 'Electrical Installation Condition Reports for landlords, homeowners and property sales.' ],
    [ 'icon' => '☀️', 'title' => 'EV Charger Installation',    'desc' => 'Home and workplace EV charging point installation — OZEV approved installer.' ],
    [ 'icon' => '💡', 'title' => 'Smart Lighting & Controls',  'desc' => 'Hue, DALI, KNX and bespoke smart lighting systems for modern living and commercial spaces.' ],
];

$el_scenarios = [
    'Tripping MCBs', 'No power to sockets', 'Flickering lights', 'Burning smell from panel',
    'Consumer unit upgrade', 'Extension wiring', 'Garden lighting', 'Outdoor sockets',
    'EICR landlord cert', 'Smoke detector install', 'Security lighting', 'Data cabling',
    'Three-phase supply', 'EV charger install', 'Solar battery storage', 'Night storage heaters',
    'Bathroom zone 1 lighting', 'Kitchen appliance circuits', 'Boiler wiring', 'Alarm system wiring',
    'LED retrofit project', 'Emergency lighting',
];

$el_process = [
    [ 'step' => '01', 'title' => 'Free Survey',      'desc' => 'We visit your property, assess the electrical installation and provide a clear, itemised no-obligation quote.' ],
    [ 'step' => '02', 'title' => 'Scope & Plan',     'desc' => 'Our engineer designs the works, orders materials and schedules your job to minimise disruption.' ],
    [ 'step' => '03', 'title' => 'Safe Isolation',   'desc' => 'We isolate the circuits safely, lock off the board and brief all site occupants before work begins.' ],
    [ 'step' => '04', 'title' => 'Installation',     'desc' => 'Quality installation using industry-grade materials — cables, enclosures and accessories from Crabtree, Hager and MK.' ],
    [ 'step' => '05', 'title' => 'Test & Certify',   'desc' => 'Full testing with Megger instruments, Building Regulations notification and Part P certificate issued.' ],
];

$el_testimonials = [
    [ 'name' => 'David Chen',    'role' => 'Landlord · Manchester',   'text' => 'Booked an EICR on short notice. Engineer arrived on time, tested all 14 circuits thoroughly and issued the certificate same day. Exactly what I needed for my new tenants.' ],
    [ 'name' => 'Fiona Walsh',   'role' => 'Homeowner · Sheffield',   'text' => 'Had a nightmare with a tripping RCD for months. Traced it to a faulty immersion heater cable in under an hour. Brilliant fault-finding skills — no mess, no fuss.' ],
    [ 'name' => 'Marcus Reid',   'role' => 'Café Owner · Leeds',      'text' => 'Rewired our entire commercial kitchen to accommodate new equipment. Three-phase supply installed perfectly. Health & Safety inspector was very impressed with the paperwork too.' ],
];

$el_packages = [
    [
        'name'     => 'EICR Report',
        'price'    => '£149',
        'period'   => 'one-off',
        'featured' => false,
        'items'    => [ 'Up to 10 circuits', 'Full visual inspection', 'Megger insulation test', 'Part P certificate', 'Digital report same day' ],
    ],
    [
        'name'     => 'Rewire Package',
        'price'    => '£2,400',
        'period'   => 'avg. 3-bed',
        'featured' => true,
        'items'    => [ 'Full property rewire', 'New consumer unit', 'All sockets & switches', 'Lighting circuits', 'Part P notification', 'EICR certificate included', '10-year workmanship guarantee' ],
    ],
    [
        'name'     => 'EV Charger Bundle',
        'price'    => '£799',
        'period'   => 'inc. charger unit',
        'featured' => false,
        'items'    => [ 'OZEV approved install', 'Smart charger unit', 'Load management system', 'App & scheduling', 'Manufacturer warranty', 'Part P certificate' ],
    ],
];

$el_counters = [
    [ 'value' => 24,     'suffix' => 'yrs',  'label' => 'Trading', 'float' => false ],
    [ 'value' => 14000,  'suffix' => '+',    'label' => 'Jobs Done', 'float' => false ],
    [ 'value' => 4.9,    'suffix' => '★',   'label' => 'Google Rating', 'float' => true ],
    [ 'value' => 100,    'suffix' => '%',    'label' => 'Part P Compliant', 'float' => false ],
];

// Circuit board traces: random positions for SVG-like CSS lines
$el_traces = [];
for ( $i = 0; $i < 18; $i++ ) {
    $el_traces[] = [
        'x'      => rand( 2, 95 ),
        'y'      => rand( 5, 90 ),
        'w'      => rand( 40, 140 ),
        'rot'    => [ 0, 90 ][ rand( 0, 1 ) ],
        'bright' => rand( 0, 1 ),
        'delay'  => rand( 0, 3000 ),
    ];
}
// Circuit nodes (junction dots)
$el_nodes = [];
for ( $j = 0; $j < 12; $j++ ) {
    $el_nodes[] = [
        'x'     => rand( 5, 92 ),
        'y'     => rand( 8, 88 ),
        'delay' => rand( 0, 2500 ),
    ];
}

// Breaker switches (12 breakers in panel)
$el_breakers = [];
$breaker_labels = ['Main','L1','L2','L3','Ring A','Ring B','Lighting 1','Lighting 2','Immersion','Cooker','EV Charger','Spare'];
for ( $k = 0; $k < 12; $k++ ) {
    $el_breakers[] = [
        'label' => $breaker_labels[ $k ],
        'on'    => ( $k < 10 ) ? true : false, // last 2 off
        'delay' => $k * 120,
    ];
}

// Floating spark particles
$el_sparks = [];
for ( $s = 0; $s < 20; $s++ ) {
    $el_sparks[] = [
        'x'     => rand( 0, 100 ),
        'y'     => rand( 0, 100 ),
        'size'  => rand( 2, 6 ),
        'dur'   => rand( 2500, 5000 ),
        'delay' => rand( 0, 4000 ),
        'type'  => [ 'spark', 'dot' ][ rand( 0, 1 ) ],
    ];
}
?>
?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Nunito+Sans:wght@300;400;600;700;800&display=swap" rel="stylesheet">
<style>
/* ============================================================
   ELECTRICIAN TEMPLATE — --el-* namespace
   Oswald + Nunito Sans
   Palette: charcoal #1A1A2E / yellow #FFD700 / orange #FF6B35 / blue #4A90D9 / white #F0F4F8
   ============================================================ */

:root {
    --el-charcoal : #1A1A2E;
    --el-yellow   : #FFD700;
    --el-orange   : #FF6B35;
    --el-blue     : #4A90D9;
    --el-white    : #F0F4F8;
    --el-dark     : #0D0D1A;
    --el-mid      : #252540;
    --el-muted    : #8A9BB5;
    --el-font-h   : 'Oswald', sans-serif;
    --el-font-b   : 'Nunito Sans', sans-serif;
    --el-radius   : 6px;
    --el-shadow   : 0 4px 24px rgba(0,0,0,.35);
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

.el-page { font-family: var(--el-font-b); color: var(--el-charcoal); background: var(--el-white); line-height: 1.6; }
.el-page h1,
.el-page h2,
.el-page h3,
.el-page h4 { font-family: var(--el-font-h); font-weight: 600; letter-spacing: .04em; }
.el-container { max-width: 1200px; margin: 0 auto; padding: 0 24px; }
.el-section { padding: 88px 0; }
.el-section--dark { background: var(--el-charcoal); color: var(--el-white); }
.el-section--mid  { background: var(--el-mid); color: var(--el-white); }
.el-btn {
    display: inline-block; padding: 14px 32px; border-radius: var(--el-radius);
    font-family: var(--el-font-h); font-size: 1rem; font-weight: 600; letter-spacing: .06em;
    text-decoration: none; cursor: pointer; border: none; transition: transform .2s, box-shadow .2s;
}
.el-btn:hover { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(0,0,0,.3); }
.el-btn--yellow  { background: var(--el-yellow); color: var(--el-charcoal); }
.el-btn--outline { background: transparent; border: 2px solid var(--el-yellow); color: var(--el-yellow); }
.el-tag {
    display: inline-block; padding: 4px 12px; border-radius: 20px;
    font-size: .78rem; font-weight: 700; letter-spacing: .04em; margin: 3px;
}
.el-section-label {
    font-family: var(--el-font-h); font-size: .8rem; font-weight: 600; letter-spacing: .14em;
    color: var(--el-yellow); text-transform: uppercase; margin-bottom: 10px;
}
.el-section-title { font-size: clamp(1.9rem, 3.5vw, 2.6rem); margin-bottom: 16px; }
.el-section-sub   { font-size: 1.05rem; opacity: .75; max-width: 560px; line-height: 1.7; }

/* ---- HERO ---- */
.el-hero {
    position: relative; min-height: 100vh;
    background: var(--el-dark);
    overflow: hidden; display: flex; align-items: center;
}
/* Circuit board background */
.el-circuit-bg {
    position: absolute; inset: 0; overflow: hidden; pointer-events: none;
}
.el-trace {
    position: absolute;
    height: 2px;
    background: var(--el-yellow);
    opacity: .12;
    transform-origin: left center;
    transition: opacity .6s;
}
.el-trace--bright { opacity: .55; }
.el-trace--bright.el-trace--glow {
    box-shadow: 0 0 8px 2px var(--el-yellow);
}
@keyframes el-pulse-trace {
    0%,100% { opacity: .12; }
    50%      { opacity: .55; box-shadow: 0 0 8px 2px var(--el-yellow); }
}
.el-trace { animation: el-pulse-trace var(--el-tdur,3s) var(--el-tdelay,0ms) infinite; }
.el-node {
    position: absolute; width: 8px; height: 8px;
    border-radius: 50%;
    background: var(--el-yellow);
    transform: translate(-50%,-50%);
}
@keyframes el-node-glow {
    0%,100% { opacity: .3; box-shadow: none; }
    50%      { opacity: 1; box-shadow: 0 0 10px 3px var(--el-yellow); }
}
.el-node { animation: el-node-glow var(--el-ndur,2.5s) var(--el-ndelay,0ms) infinite; }

/* Spark particles */
.el-spark {
    position: absolute;
    border-radius: 50%;
    background: var(--el-yellow);
    pointer-events: none;
}
@keyframes el-drift {
    0%   { transform: translateY(0) scale(1); opacity: .7; }
    50%  { transform: translateY(-28px) scale(1.3); opacity: 1; }
    100% { transform: translateY(-60px) scale(.5); opacity: 0; }
}
.el-spark { animation: el-drift var(--el-sdur,3.5s) var(--el-sdelay,0ms) infinite; }

/* Hero layout */
.el-hero__inner {
    position: relative; z-index: 2;
    display: grid; grid-template-columns: 1fr 480px; gap: 60px; align-items: center;
    max-width: 1200px; margin: 0 auto; padding: 120px 24px 80px;
    width: 100%;
}
.el-hero__badge {
    display: inline-flex; align-items: center; gap: 8px;
    background: rgba(255,215,0,.12); border: 1px solid rgba(255,215,0,.35);
    border-radius: 20px; padding: 6px 16px; margin-bottom: 20px;
    font-size: .8rem; font-weight: 700; letter-spacing: .08em; color: var(--el-yellow);
    font-family: var(--el-font-h);
}
.el-hero__badge::before {
    content: ''; width: 8px; height: 8px; border-radius: 50%;
    background: var(--el-orange);
    box-shadow: 0 0 8px var(--el-orange);
    animation: el-blink 1.2s infinite;
}
@keyframes el-blink { 0%,100%{opacity:1;} 50%{opacity:.2;} }
.el-hero__heading {
    font-size: clamp(2.4rem,5vw,3.8rem); line-height: 1.1;
    color: var(--el-white); margin-bottom: 20px;
}
.el-hero__heading span { color: var(--el-yellow); }
.el-hero__sub { font-size: 1.1rem; color: rgba(240,244,248,.75); margin-bottom: 32px; line-height: 1.7; }
.el-hero__cta { display: flex; gap: 16px; flex-wrap: wrap; }

/* ---- FUSE BOX SCENE ---- */
.el-fuse-scene {
    position: relative; width: 480px; height: 420px; flex-shrink: 0;
}
/* Main panel box */
.el-panel {
    position: absolute; left: 50%; top: 50%;
    transform: translate(-50%,-50%);
    width: 240px; height: 300px;
    background: #2A2A3E;
    border: 3px solid #444460;
    border-radius: 8px;
    box-shadow: 0 0 40px rgba(255,215,0,.15), var(--el-shadow);
    overflow: hidden;
}
.el-panel__header {
    background: var(--el-charcoal);
    padding: 8px 12px;
    border-bottom: 2px solid var(--el-yellow);
    font-family: var(--el-font-h); font-size: .65rem; font-weight: 700;
    letter-spacing: .12em; color: var(--el-yellow); text-align: center;
}
.el-panel__body {
    display: grid; grid-template-columns: 1fr 1fr; gap: 4px;
    padding: 10px 8px;
}
/* Individual breaker */
.el-breaker {
    background: #1A1A2E; border-radius: 3px; padding: 4px 5px;
    border: 1px solid #333350;
    display: flex; flex-direction: column; align-items: center; gap: 3px;
}
.el-breaker__label {
    font-size: .45rem; color: var(--el-muted); font-family: var(--el-font-h);
    letter-spacing: .06em; text-align: center; line-height: 1.2;
}
.el-breaker__switch {
    width: 14px; height: 22px; border-radius: 3px;
    position: relative; cursor: default;
}
.el-breaker__switch--on  { background: var(--el-yellow); box-shadow: 0 0 6px rgba(255,215,0,.6); }
.el-breaker__switch--off { background: #555; }
.el-breaker__switch::after {
    content: ''; position: absolute;
    left: 50%; transform: translateX(-50%);
    width: 6px; height: 6px; border-radius: 1px;
    background: rgba(0,0,0,.4);
}
.el-breaker__switch--on::after  { top: 3px; }
.el-breaker__switch--off::after { bottom: 3px; }

/* Lightning bolt overlay */
.el-bolt {
    position: absolute; top: 18px; right: 30px;
    font-size: 3.5rem; line-height: 1;
    filter: drop-shadow(0 0 12px var(--el-yellow)) drop-shadow(0 0 24px var(--el-orange));
    animation: el-bolt-flash 2.2s infinite;
}
@keyframes el-bolt-flash {
    0%,100%{opacity:1;filter:drop-shadow(0 0 12px var(--el-yellow)) drop-shadow(0 0 24px var(--el-orange));}
    45%{opacity:.5;filter:drop-shadow(0 0 4px var(--el-yellow));}
    50%{opacity:1;filter:drop-shadow(0 0 20px var(--el-yellow)) drop-shadow(0 0 40px var(--el-orange));}
}

/* Wires coming out of panel */
.el-wire {
    position: absolute;
    border: 3px solid;
    border-radius: 0 0 20px 20px;
    border-top: none;
}
.el-wire--yellow { border-color: var(--el-yellow); opacity: .6; }
.el-wire--blue   { border-color: var(--el-blue);   opacity: .5; }
.el-wire--red    { border-color: #e55; opacity: .4; }

/* Voltmeter display */
.el-voltmeter {
    position: absolute; bottom: 20px; left: 20px;
    background: #0D0D1A; border: 2px solid var(--el-yellow);
    border-radius: 6px; padding: 10px 14px;
    font-family: 'Courier New', monospace; font-size: .9rem;
    color: var(--el-yellow); text-align: center; min-width: 90px;
    box-shadow: 0 0 16px rgba(255,215,0,.2);
}
.el-voltmeter__label { font-size: .55rem; letter-spacing: .1em; color: var(--el-muted); margin-bottom: 2px; }
.el-voltmeter__val   { font-size: 1.3rem; font-weight: 700; letter-spacing: .05em; }
@keyframes el-volt-flicker {
    0%,95%,100%{ opacity:1; }
    96%{ opacity:.7; }
    97%{ opacity:1; }
    98%{ opacity:.4; }
    99%{ opacity:1; }
}
.el-voltmeter { animation: el-volt-flicker 4s infinite; }

/* Safety label */
.el-safety-sticker {
    position: absolute; top: 20px; left: 16px;
    background: #E63946; color: #fff; border-radius: 4px;
    font-family: var(--el-font-h); font-size: .55rem; font-weight: 700;
    letter-spacing: .1em; padding: 4px 8px; transform: rotate(-8deg);
    box-shadow: 0 2px 8px rgba(0,0,0,.4);
}

/* Neon "LIVE" sign */
.el-live-sign {
    position: absolute; top: 20px; right: 16px;
    background: transparent; border: 2px solid var(--el-orange);
    border-radius: 4px; padding: 4px 10px;
    font-family: var(--el-font-h); font-size: .65rem; font-weight: 700;
    letter-spacing: .14em; color: var(--el-orange);
    text-shadow: 0 0 8px var(--el-orange);
    box-shadow: 0 0 8px rgba(255,107,53,.4), inset 0 0 8px rgba(255,107,53,.1);
    animation: el-neon-live 1.8s infinite;
}
@keyframes el-neon-live {
    0%,100%{
        color:var(--el-orange);
        text-shadow:0 0 8px var(--el-orange);
        box-shadow:0 0 8px rgba(255,107,53,.4),inset 0 0 8px rgba(255,107,53,.1);
    }
    45%{
        color:rgba(255,107,53,.5);
        text-shadow:none;
        box-shadow:none;
    }
    55%{
        color:var(--el-orange);
        text-shadow:0 0 12px var(--el-orange);
        box-shadow:0 0 14px rgba(255,107,53,.6),inset 0 0 14px rgba(255,107,53,.2);
    }
}

/* ---- TRUST BAR ---- */
.el-trust-bar {
    background: var(--el-yellow); padding: 14px 0;
}
.el-trust-bar__inner {
    display: flex; align-items: center; justify-content: center;
    gap: 48px; flex-wrap: wrap;
}
.el-trust-item {
    display: flex; align-items: center; gap: 9px;
    font-family: var(--el-font-h); font-size: .85rem; font-weight: 600;
    letter-spacing: .06em; color: var(--el-charcoal);
}
.el-trust-item span { font-size: 1.1rem; }

/* ---- COUNTERS ---- */
.el-counters { background: var(--el-mid); padding: 56px 0; }
.el-counters__grid {
    display: grid; grid-template-columns: repeat(4,1fr); gap: 24px;
    max-width: 1000px; margin: 0 auto; padding: 0 24px;
}
.el-counter-card {
    text-align: center; padding: 32px 16px;
    background: rgba(255,255,255,.05); border: 1px solid rgba(255,215,0,.18);
    border-radius: var(--el-radius);
}
.el-counter-card__val {
    font-family: var(--el-font-h); font-size: 2.8rem; font-weight: 700;
    color: var(--el-yellow); line-height: 1.1; display: flex; align-items: baseline;
    justify-content: center; gap: 2px;
}
.el-counter-card__suffix { font-size: 1.4rem; }
.el-counter-card__label { font-size: .85rem; color: rgba(240,244,248,.6); margin-top: 6px; letter-spacing: .04em; }

/* ---- SERVICES ---- */
.el-services-grid {
    display: grid; grid-template-columns: repeat(auto-fill,minmax(260px,1fr)); gap: 24px;
    margin-top: 48px;
}
.el-service-card {
    background: #fff; border: 1px solid rgba(0,0,0,.08);
    border-radius: var(--el-radius); padding: 28px; position: relative;
    transition: transform .25s, box-shadow .25s; overflow: hidden;
}
.el-service-card::before {
    content: ''; position: absolute; inset: 0 0 auto 0;
    height: 4px; background: var(--el-yellow);
}
.el-service-card:hover { transform: translateY(-4px); box-shadow: 0 12px 32px rgba(0,0,0,.12); }
.el-service-card__icon { font-size: 2rem; margin-bottom: 14px; }
.el-service-card__title { font-size: 1.05rem; margin-bottom: 10px; color: var(--el-charcoal); }
.el-service-card__desc  { font-size: .88rem; color: #666; line-height: 1.65; }

/* ---- SCENARIOS ---- */
.el-scenarios { background: var(--el-charcoal); }
.el-tags-cloud { display: flex; flex-wrap: wrap; gap: 4px; margin-top: 32px; }
.el-tag--scenario {
    background: rgba(255,215,0,.1); border: 1px solid rgba(255,215,0,.25);
    color: rgba(240,244,248,.85); border-radius: 20px;
    padding: 6px 14px; font-size: .82rem;
}
.el-tag--scenario:hover { background: rgba(255,215,0,.2); color: var(--el-yellow); }

/* ---- PROCESS ---- */
.el-process { background: var(--el-mid); }
.el-process__steps {
    position: relative; margin-top: 56px;
    display: grid; grid-template-columns: repeat(5,1fr); gap: 0;
}
.el-process__steps::before {
    content: ''; position: absolute; top: 28px; left: 10%; right: 10%; height: 3px;
    background: linear-gradient(90deg, var(--el-yellow), var(--el-orange), var(--el-yellow));
    z-index: 0;
}
.el-step { text-align: center; position: relative; z-index: 1; padding: 0 12px; }
.el-step__num {
    width: 56px; height: 56px; border-radius: 50%; margin: 0 auto 20px;
    display: flex; align-items: center; justify-content: center;
    font-family: var(--el-font-h); font-size: 1.2rem; font-weight: 700;
    background: var(--el-mid); border: 3px solid var(--el-yellow); color: var(--el-yellow);
    box-shadow: 0 0 16px rgba(255,215,0,.3);
}
.el-step__title { font-family: var(--el-font-h); font-size: .9rem; font-weight: 600; color: var(--el-white); margin-bottom: 8px; letter-spacing: .04em; }
.el-step__desc  { font-size: .78rem; color: rgba(240,244,248,.6); line-height: 1.6; }

/* ---- ENGINEER CARD ---- */
.el-engineer-section { background: var(--el-charcoal); }
.el-engineer-wrap {
    display: grid; grid-template-columns: 320px 1fr; gap: 56px; align-items: center;
}
/* CSS engineer figure */
.el-engineer-figure { position: relative; height: 280px; }
.el-eng__body {
    position: absolute; bottom: 0; left: 50%; transform: translateX(-50%);
    width: 80px; height: 130px;
    background: #FF6B35; /* Hi-vis orange */
    border-radius: 8px 8px 4px 4px;
    box-shadow: 0 4px 16px rgba(0,0,0,.3);
}
/* Hi-vis yellow strips */
.el-eng__body::before {
    content: ''; position: absolute; top: 30px; left: 0; right: 0;
    height: 12px; background: var(--el-yellow);
}
.el-eng__body::after {
    content: '⚡'; position: absolute; top: 8px; left: 50%;
    transform: translateX(-50%); font-size: .7rem;
    color: var(--el-charcoal); font-weight: 900;
}
.el-eng__legs {
    position: absolute; bottom: 0; left: 50%; transform: translateX(-50%);
    display: flex; gap: 8px;
}
.el-eng__leg {
    width: 28px; height: 60px;
    background: #1A1A2E; border-radius: 0 0 4px 4px;
}
.el-eng__head {
    position: absolute; bottom: 128px; left: 50%; transform: translateX(-50%);
    width: 48px; height: 48px;
    background: #D4956A; border-radius: 50%;
}
/* Hard hat */
.el-eng__hat {
    position: absolute; top: -20px; left: 50%; transform: translateX(-50%);
    width: 58px; height: 22px;
    background: var(--el-yellow);
    border-radius: 50% 50% 0 0;
    box-shadow: 0 0 10px rgba(255,215,0,.4);
}
.el-eng__hat::after {
    content: ''; position: absolute; bottom: 0; left: -6px; right: -6px;
    height: 6px; background: var(--el-yellow); border-radius: 0 0 3px 3px;
}
/* Tool belt */
.el-eng__belt {
    position: absolute; bottom: 60px; left: 50%; transform: translateX(-50%);
    width: 88px; height: 12px;
    background: var(--el-charcoal); border-radius: 2px;
}
.el-eng__belt::after {
    content: '🔧'; position: absolute; left: 50%; transform: translateX(-50%) translateY(-50%);
    font-size: .6rem; top: 50%;
}
/* Arms */
.el-eng__arm {
    position: absolute; bottom: 80px;
    width: 18px; height: 70px;
    background: #FF6B35; border-radius: 6px;
}
.el-eng__arm--l { left: calc(50% - 56px); transform: rotate(15deg); transform-origin: top center; }
.el-eng__arm--r { right: calc(50% - 56px); transform: rotate(-25deg); transform-origin: top center; }
/* Voltmeter tool in hand */
.el-eng__tool {
    position: absolute; bottom: 12px; right: calc(50% - 74px);
    width: 20px; height: 28px;
    background: #333; border: 2px solid var(--el-yellow);
    border-radius: 4px; font-size: .4rem; color: var(--el-yellow);
    display: flex; align-items: center; justify-content: center;
    font-family: 'Courier New', monospace; font-weight: 700;
}

.el-engineer-info h3  { font-size: 1.8rem; color: var(--el-white); margin-bottom: 4px; }
.el-engineer-info h4  { font-size: .9rem; color: var(--el-yellow); font-family: var(--el-font-h); letter-spacing: .08em; margin-bottom: 20px; font-weight: 500; }
.el-engineer-info p   { color: rgba(240,244,248,.75); line-height: 1.75; margin-bottom: 20px; }
.el-engineer-badges   { display: flex; flex-wrap: wrap; gap: 10px; }
.el-badge {
    display: inline-flex; align-items: center; gap: 6px;
    background: rgba(255,215,0,.1); border: 1px solid rgba(255,215,0,.3);
    border-radius: 20px; padding: 6px 14px;
    font-size: .78rem; font-weight: 700; font-family: var(--el-font-h);
    letter-spacing: .06em; color: var(--el-yellow);
}

/* ---- PACKAGES ---- */
.el-packages-grid {
    display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; margin-top: 48px;
    align-items: start;
}
.el-package {
    background: #fff; border: 2px solid rgba(0,0,0,.08);
    border-radius: var(--el-radius); padding: 32px; position: relative;
}
.el-package--featured {
    background: var(--el-charcoal); border-color: var(--el-yellow);
    box-shadow: 0 0 32px rgba(255,215,0,.2); transform: scale(1.02);
}
.el-package__badge {
    position: absolute; top: -14px; left: 50%; transform: translateX(-50%);
    background: var(--el-yellow); color: var(--el-charcoal);
    font-family: var(--el-font-h); font-size: .72rem; font-weight: 700;
    letter-spacing: .1em; padding: 4px 16px; border-radius: 20px;
    white-space: nowrap;
}
.el-package__name  { font-size: 1.1rem; margin-bottom: 6px; color: inherit; }
.el-package--featured .el-package__name { color: var(--el-white); }
.el-package__price {
    font-family: var(--el-font-h); font-size: 2.2rem; font-weight: 700;
    color: var(--el-yellow); margin: 12px 0 4px;
}
.el-package__period { font-size: .78rem; color: var(--el-muted); margin-bottom: 20px; }
.el-package__items  { list-style: none; margin-bottom: 28px; }
.el-package__items li {
    padding: 6px 0; font-size: .88rem; border-bottom: 1px solid rgba(0,0,0,.06);
    display: flex; gap: 8px; align-items: flex-start;
    color: inherit;
}
.el-package--featured .el-package__items li { border-color: rgba(255,255,255,.08); color: rgba(240,244,248,.85); }
.el-package__items li::before { content: '✓'; color: var(--el-yellow); font-weight: 700; flex-shrink: 0; }
.el-package__cta { display: block; text-align: center; }

/* ---- TESTIMONIALS ---- */
.el-testimonials { background: var(--el-white); }
.el-testi-grid {
    display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; margin-top: 48px;
}
.el-testi {
    background: #fff; border: 1px solid rgba(0,0,0,.08);
    border-radius: var(--el-radius); padding: 28px; position: relative;
}
.el-testi__quote {
    font-size: 3rem; line-height: 1; color: var(--el-yellow);
    font-family: var(--el-font-h); margin-bottom: 8px; opacity: .5;
}
.el-testi__text  { font-size: .9rem; color: #555; line-height: 1.7; margin-bottom: 20px; }
.el-testi__stars { color: var(--el-yellow); font-size: 1rem; margin-bottom: 10px; }
.el-testi__name  { font-weight: 700; font-size: .9rem; color: var(--el-charcoal); }
.el-testi__role  { font-size: .8rem; color: var(--el-muted); }

/* ---- BOOKING FORM ---- */
.el-booking { background: var(--el-dark); }
.el-booking__wrap {
    display: grid; grid-template-columns: 1fr 1fr; gap: 56px; align-items: start;
}
.el-booking__info h2  { color: var(--el-white); margin-bottom: 16px; }
.el-booking__info p   { color: rgba(240,244,248,.7); line-height: 1.75; margin-bottom: 24px; }
.el-booking__bullets  { list-style: none; }
.el-booking__bullets li {
    padding: 10px 0; border-bottom: 1px solid rgba(255,255,255,.08);
    color: rgba(240,244,248,.8); font-size: .9rem;
    display: flex; gap: 10px; align-items: flex-start;
}
.el-booking__bullets li::before { content: '⚡'; flex-shrink: 0; }

.el-form {
    background: var(--el-mid); border: 1px solid rgba(255,215,0,.15);
    border-radius: var(--el-radius); padding: 36px;
}
.el-form h3 { color: var(--el-white); font-size: 1.4rem; margin-bottom: 24px; }
.el-field { margin-bottom: 18px; }
.el-field label {
    display: block; font-size: .82rem; font-weight: 700; letter-spacing: .04em;
    color: rgba(240,244,248,.7); margin-bottom: 6px; font-family: var(--el-font-h);
    text-transform: uppercase;
}
.el-field input,
.el-field select,
.el-field textarea {
    width: 100%; padding: 11px 14px; border-radius: var(--el-radius);
    background: var(--el-dark); border: 1px solid rgba(255,215,0,.2);
    color: var(--el-white); font-family: var(--el-font-b); font-size: .92rem;
    outline: none; transition: border-color .2s;
}
.el-field input:focus,
.el-field select:focus,
.el-field textarea:focus { border-color: var(--el-yellow); }
.el-field textarea { resize: vertical; min-height: 100px; }
.el-field select option { background: var(--el-dark); color: var(--el-white); }
.el-field-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.el-form__submit {
    width: 100%; padding: 15px; background: var(--el-yellow); color: var(--el-charcoal);
    border: none; border-radius: var(--el-radius); font-family: var(--el-font-h);
    font-size: 1rem; font-weight: 700; letter-spacing: .08em; cursor: pointer;
    transition: filter .2s, transform .2s;
}
.el-form__submit:hover { filter: brightness(1.1); transform: translateY(-1px); }

/* ---- NICEIC BANNER ---- */
.el-cert-bar {
    background: var(--el-charcoal); border-top: 1px solid rgba(255,215,0,.15);
    padding: 20px 0;
}
.el-cert-bar__inner {
    display: flex; justify-content: center; align-items: center;
    gap: 40px; flex-wrap: wrap;
}
.el-cert-item {
    display: flex; align-items: center; gap: 10px;
    font-family: var(--el-font-h); font-size: .8rem; font-weight: 600;
    letter-spacing: .08em; color: rgba(240,244,248,.65);
}
.el-cert-item span { font-size: 1.4rem; }

/* ---- FOOTER ---- */
.el-footer {
    background: var(--el-dark); padding: 40px 0; text-align: center;
    border-top: 1px solid rgba(255,255,255,.06);
}
.el-footer p { font-size: .82rem; color: rgba(240,244,248,.4); margin-bottom: 4px; }
.el-footer__phone {
    font-family: var(--el-font-h); font-size: 1.8rem; color: var(--el-yellow);
    letter-spacing: .04em; margin-bottom: 8px;
    text-shadow: 0 0 16px rgba(255,215,0,.3);
}

/* ---- RESPONSIVE ---- */
@media (max-width: 900px) {
    .el-hero__inner        { grid-template-columns: 1fr; padding-top: 100px; }
    .el-fuse-scene         { width: 100%; height: 300px; }
    .el-panel              { width: 200px; height: 260px; }
    .el-counters__grid     { grid-template-columns: repeat(2,1fr); }
    .el-process__steps     { grid-template-columns: 1fr; gap: 32px; }
    .el-process__steps::before { display: none; }
    .el-engineer-wrap      { grid-template-columns: 1fr; }
    .el-engineer-figure    { height: 200px; margin: 0 auto 32px; }
    .el-packages-grid      { grid-template-columns: 1fr; }
    .el-package--featured  { transform: none; }
    .el-testi-grid         { grid-template-columns: 1fr; }
    .el-booking__wrap      { grid-template-columns: 1fr; }
    .el-trust-bar__inner   { gap: 24px; }
}
</style>
<?php get_header(); ?>

<div class="">

>

<!-- ═══════════════════════════════════════════════════════
     HERO — Circuit Board + Fuse Box Scene
     ═══════════════════════════════════════════════════════ -->
<section class="el-hero" aria-label="Hero">

    <!-- Circuit board background traces -->
    <div class="el-circuit-bg" aria-hidden="true">
        <?php foreach ( $el_traces as $tr ) :
            $is_bright = $tr['bright'] ? 'el-trace--bright' : '';
            $dur = rand( 2000, 5000 );
            $style = sprintf(
                'left:%s%%;top:%s%%;width:%spx;transform:rotate(%sdeg);--el-tdur:%sms;--el-tdelay:%sms;',
                esc_attr( $tr['x'] ), esc_attr( $tr['y'] ), esc_attr( $tr['w'] ),
                esc_attr( $tr['rot'] ), $dur, esc_attr( $tr['delay'] )
            );
        ?>
            <div class="el-trace <?php echo esc_attr( $is_bright ); ?>" style="<?php echo $style; ?>"></div>
        <?php endforeach; ?>

        <?php foreach ( $el_nodes as $nd ) :
            $ndur = rand( 1800, 3500 );
            $style = sprintf(
                'left:%s%%;top:%s%%;--el-ndur:%sms;--el-ndelay:%sms;',
                esc_attr( $nd['x'] ), esc_attr( $nd['y'] ), $ndur, esc_attr( $nd['delay'] )
            );
        ?>
            <div class="el-node" style="<?php echo $style; ?>"></div>
        <?php endforeach; ?>

        <?php foreach ( $el_sparks as $sp ) :
            $style = sprintf(
                'left:%s%%;top:%s%%;width:%spx;height:%spx;--el-sdur:%sms;--el-sdelay:%sms;',
                esc_attr( $sp['x'] ), esc_attr( $sp['y'] ),
                esc_attr( $sp['size'] ), esc_attr( $sp['size'] ),
                esc_attr( $sp['dur'] ), esc_attr( $sp['delay'] )
            );
        ?>
            <div class="el-spark" style="<?php echo $style; ?>"></div>
        <?php endforeach; ?>
    </div>

    <div class="el-hero__inner">
        <!-- Text side -->
        <div class="el-hero__text">
            <div class="el-hero__badge">24/7 EMERGENCY CALLOUT</div>
            <h1 class="el-hero__heading">
                Your Local<br>
                <span>Certified</span><br>
                Electrician
            </h1>
            <p class="el-hero__sub">
                NICEIC approved contractor. Part P certified. Domestic, commercial and industrial electrical work across the region — from a single socket to a full rewire.
            </p>
            <div class="el-hero__cta">
                <a href="#booking" class="el-btn el-btn--yellow">Get a Free Quote</a>
                <a href="tel:+441234567890" class="el-btn el-btn--outline">📞 Emergency Line</a>
            </div>
        </div>

        <!-- Fuse box scene -->
        <div class="el-fuse-scene" aria-hidden="true">
            <!-- Decorative stickers -->
            <div class="el-safety-sticker">⚠ DANGER 240V</div>
            <div class="el-bolt">⚡</div>
            <div class="el-live-sign">● LIVE</div>

            <!-- Main consumer unit panel -->
            <div class="el-panel">
                <div class="el-panel__header">CONSUMER UNIT — 100A</div>
                <div class="el-panel__body">
                    <?php foreach ( $el_breakers as $br ) : ?>
                        <div class="el-breaker">
                            <div class="el-breaker__label"><?php echo esc_html( $br['label'] ); ?></div>
                            <div class="el-breaker__switch el-breaker__switch--<?php echo $br['on'] ? 'on' : 'off'; ?>"></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Wires out of panel -->
            <div class="el-wire el-wire--yellow" style="position:absolute;bottom:30px;left:calc(50% - 60px);width:100px;height:60px;"></div>
            <div class="el-wire el-wire--blue"   style="position:absolute;bottom:30px;left:calc(50% + 10px);width:70px;height:40px;"></div>
            <div class="el-wire el-wire--red"    style="position:absolute;bottom:30px;right:calc(50% - 50px);width:80px;height:50px;"></div>

            <!-- Voltmeter -->
            <div class="el-voltmeter">
                <div class="el-voltmeter__label">VOLTS AC</div>
                <div class="el-voltmeter__val">230V</div>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     TRUST BAR
     ═══════════════════════════════════════════════════════ -->
<div class="el-trust-bar" role="complementary" aria-label="Trust signals">
    <div class="el-trust-bar__inner el-container">
        <div class="el-trust-item"><span>🏅</span> NICEIC Approved Contractor</div>
        <div class="el-trust-item"><span>📋</span> Part P Registered</div>
        <div class="el-trust-item"><span>⚡</span> 24/7 Emergency Response</div>
        <div class="el-trust-item"><span>🛡️</span> £5M Public Liability</div>
        <div class="el-trust-item"><span>✅</span> 10-Year Guarantee</div>
    </div>
</div>

<!-- ═══════════════════════════════════════════════════════
     COUNTERS
     ═══════════════════════════════════════════════════════ -->
<section class="el-counters" aria-label="Key statistics">
    <div class="el-counters__grid">
        <?php foreach ( $el_counters as $ctr ) : ?>
            <div class="el-counter-card">
                <div class="el-counter-card__val">
                    <span class="el-counter-num"
                          data-target="<?php echo esc_attr( $ctr['value'] ); ?>"
                          data-suffix="<?php echo esc_attr( $ctr['suffix'] ); ?>"
                          <?php if ( $ctr['float'] ) echo 'data-float="1"'; ?>>
                        0
                    </span>
                    <span class="el-counter-card__suffix"><?php echo esc_html( $ctr['suffix'] ); ?></span>
                </div>
                <div class="el-counter-card__label"><?php echo esc_html( $ctr['label'] ); ?></div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     SERVICES
     ═══════════════════════════════════════════════════════ -->
<section class="el-section" aria-labelledby="el-services-title">
    <div class="el-container">
        <div class="el-section-label">What We Do</div>
        <h2 class="el-section-title" id="el-services-title">Electrical Services</h2>
        <p class="el-section-sub">From emergency fault-finding to complete rewires, our NICEIC-approved engineers cover every aspect of domestic and commercial electrics.</p>
        <div class="el-services-grid">
            <?php foreach ( $el_services as $svc ) : ?>
                <div class="el-service-card">
                    <div class="el-service-card__icon"><?php echo esc_html( $svc['icon'] ); ?></div>
                    <h3 class="el-service-card__title"><?php echo esc_html( $svc['title'] ); ?></h3>
                    <p class="el-service-card__desc"><?php echo esc_html( $svc['desc'] ); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     SCENARIOS TAG CLOUD
     ═══════════════════════════════════════════════════════ -->
<section class="el-section el-scenarios" aria-labelledby="el-scenarios-title">
    <div class="el-container">
        <div class="el-section-label" style="color:var(--el-yellow);">We Handle</div>
        <h2 class="el-section-title" id="el-scenarios-title" style="color:var(--el-white);">Every Electrical Situation</h2>
        <p class="el-section-sub">No job too small or too complex. Here are some of the situations our engineers tackle every day.</p>
        <div class="el-tags-cloud" role="list" aria-label="Electrical scenarios we handle">
            <?php foreach ( $el_scenarios as $sc ) : ?>
                <span class="el-tag el-tag--scenario" role="listitem"><?php echo esc_html( $sc ); ?></span>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     PROCESS
     ═══════════════════════════════════════════════════════ -->
<section class="el-section el-process" aria-labelledby="el-process-title">
    <div class="el-container">
        <div class="el-section-label" style="color:var(--el-yellow);">How It Works</div>
        <h2 class="el-section-title" id="el-process-title" style="color:var(--el-white);">Our 5-Step Process</h2>
        <p class="el-section-sub" style="color:rgba(240,244,248,.65);">Safe, methodical, fully compliant — every time.</p>
        <div class="el-process__steps">
            <?php foreach ( $el_process as $ps ) : ?>
                <div class="el-step">
                    <div class="el-step__num"><?php echo esc_html( $ps['step'] ); ?></div>
                    <div class="el-step__title"><?php echo esc_html( $ps['title'] ); ?></div>
                    <p class="el-step__desc"><?php echo esc_html( $ps['desc'] ); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     LEAD ENGINEER CREDENTIAL CARD
     ═══════════════════════════════════════════════════════ -->
<section class="el-section el-engineer-section" aria-labelledby="el-engineer-title">
    <div class="el-container">
        <div class="el-engineer-wrap">
            <!-- CSS engineer figure -->
            <div class="el-engineer-figure" aria-hidden="true">
                <div class="el-eng__arm el-eng__arm--l"></div>
                <div class="el-eng__arm el-eng__arm--r"></div>
                <div class="el-eng__tool">🔌</div>
                <div class="el-eng__body"></div>
                <div class="el-eng__legs">
                    <div class="el-eng__leg"></div>
                    <div class="el-eng__leg"></div>
                </div>
                <div class="el-eng__head">
                    <div class="el-eng__hat"></div>
                </div>
                <div class="el-eng__belt"></div>
            </div>

            <!-- Info -->
            <div class="el-engineer-info">
                <div class="el-section-label">Lead Engineer</div>
                <h3 id="el-engineer-title">James Hartwell</h3>
                <h4>NICEIC Approved · ECS Gold Card · 18th Edition Qualified</h4>
                <p>
                    James founded the business in <?php echo date('Y') - 24; ?> after a decade with a national contractor. He and his team of five qualified electricians cover domestic, commercial and light industrial installations across the area. Every job is personally overseen and signed off by a qualified engineer.
                </p>
                <p>
                    All engineers hold ECS Gold Cards, are CRB checked and carry £5 million public liability insurance on every visit. We are proud members of the NICEIC, ELECSA and the Electrical Contractors' Association.
                </p>
                <div class="el-engineer-badges">
                    <span class="el-badge">🏅 NICEIC Approved</span>
                    <span class="el-badge">⚡ 18th Edition</span>
                    <span class="el-badge">📋 ECS Gold Card</span>
                    <span class="el-badge">🛡️ Part P Registered</span>
                    <span class="el-badge">✅ ELECSA Member</span>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     PACKAGES
     ═══════════════════════════════════════════════════════ -->
<section class="el-section" aria-labelledby="el-packages-title">
    <div class="el-container">
        <div class="el-section-label">Pricing</div>
        <h2 class="el-section-title" id="el-packages-title">Clear, Fixed Pricing</h2>
        <p class="el-section-sub">No call-out fees. No hidden charges. All prices include labour, materials and certification.</p>
        <div class="el-packages-grid">
            <?php foreach ( $el_packages as $pkg ) : ?>
                <div class="el-package <?php echo $pkg['featured'] ? 'el-package--featured' : ''; ?>">
                    <?php if ( $pkg['featured'] ) : ?>
                        <div class="el-package__badge">MOST POPULAR</div>
                    <?php endif; ?>
                    <h3 class="el-package__name"><?php echo esc_html( $pkg['name'] ); ?></h3>
                    <div class="el-package__price"><?php echo esc_html( $pkg['price'] ); ?></div>
                    <div class="el-package__period"><?php echo esc_html( $pkg['period'] ); ?></div>
                    <ul class="el-package__items">
                        <?php foreach ( $pkg['items'] as $item ) : ?>
                            <li><?php echo esc_html( $item ); ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <a href="#booking" class="el-btn el-btn--yellow el-package__cta">
                        Book This Package
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     TESTIMONIALS
     ═══════════════════════════════════════════════════════ -->
<section class="el-section el-testimonials" aria-labelledby="el-testi-title">
    <div class="el-container">
        <div class="el-section-label">Reviews</div>
        <h2 class="el-section-title" id="el-testi-title">What Our Customers Say</h2>
        <p class="el-section-sub">Trusted by thousands of homeowners, landlords and businesses across the region.</p>
        <div class="el-testi-grid">
            <?php foreach ( $el_testimonials as $t ) : ?>
                <blockquote class="el-testi">
                    <div class="el-testi__quote" aria-hidden="true">❝</div>
                    <div class="el-testi__stars" aria-label="5 stars">★★★★★</div>
                    <p class="el-testi__text"><?php echo esc_html( $t['text'] ); ?></p>
                    <footer>
                        <div class="el-testi__name"><?php echo esc_html( $t['name'] ); ?></div>
                        <div class="el-testi__role"><?php echo esc_html( $t['role'] ); ?></div>
                    </footer>
                </blockquote>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     BOOKING FORM
     ═══════════════════════════════════════════════════════ -->
<section class="el-section el-booking" id="booking" aria-labelledby="el-booking-title">
    <div class="el-container">
        <div class="el-booking__wrap">
            <div class="el-booking__info">
                <div class="el-section-label">Get In Touch</div>
                <h2 id="el-booking-title">Book a Free Survey</h2>
                <p>Tell us about your electrical project and we'll get back to you within 2 hours with a clear, itemised quote. No call-out charge. No obligation.</p>
                <ul class="el-booking__bullets">
                    <li>Free, no-obligation site survey</li>
                    <li>Same-day response to enquiries</li>
                    <li>Emergency callouts available 24/7</li>
                    <li>Fixed prices — no surprise extras</li>
                    <li>Part P certificates issued on completion</li>
                    <li>10-year workmanship guarantee on rewires</li>
                </ul>
            </div>

            <div class="el-form">
                <h3>Request a Quote</h3>
                <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" novalidate>
                    <?php wp_nonce_field( 'tf_el_booking', 'tf_el_nonce' ); ?>
                    <input type="hidden" name="action" value="tf_el_booking">

                    <div class="el-field-row">
                        <div class="el-field">
                            <label for="el-name">Full Name *</label>
                            <input type="text" id="el-name" name="el_name" required placeholder="Jane Smith">
                        </div>
                        <div class="el-field">
                            <label for="el-phone">Phone Number *</label>
                            <input type="tel" id="el-phone" name="el_phone" required placeholder="07700 900123">
                        </div>
                    </div>

                    <div class="el-field">
                        <label for="el-email">Email Address *</label>
                        <input type="email" id="el-email" name="el_email" required placeholder="jane@example.com">
                    </div>

                    <div class="el-field">
                        <label for="el-service">Service Required *</label>
                        <select id="el-service" name="el_service" required>
                            <option value="">— Select a service —</option>
                            <option value="rewire">Full Rewire</option>
                            <option value="consumer-unit">Consumer Unit Upgrade</option>
                            <option value="eicr">EICR Testing</option>
                            <option value="fault">Fault Finding</option>
                            <option value="new-circuit">New Circuit / Sockets</option>
                            <option value="ev-charger">EV Charger Installation</option>
                            <option value="smart-lighting">Smart Lighting</option>
                            <option value="commercial">Commercial Electrical</option>
                            <option value="other">Other / Not Sure</option>
                        </select>
                    </div>

                    <div class="el-field-row">
                        <div class="el-field">
                            <label for="el-property">Property Type</label>
                            <select id="el-property" name="el_property">
                                <option value="">— Select —</option>
                                <option value="terraced">Terraced House</option>
                                <option value="semi">Semi-Detached</option>
                                <option value="detached">Detached House</option>
                                <option value="flat">Flat / Apartment</option>
                                <option value="commercial">Commercial Unit</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        <div class="el-field">
                            <label for="el-urgency">Urgency</label>
                            <select id="el-urgency" name="el_urgency">
                                <option value="emergency">Emergency — ASAP</option>
                                <option value="week" selected>Within a Week</option>
                                <option value="month">Within a Month</option>
                                <option value="flexible">Flexible</option>
                            </select>
                        </div>
                    </div>

                    <div class="el-field">
                        <label for="el-notes">Brief Description of Work</label>
                        <textarea id="el-notes" name="el_notes" placeholder="Describe the electrical work you need — the more detail the better..."></textarea>
                    </div>

                    <button type="submit" class="el-form__submit">⚡ Request Free Quote</button>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     CERTIFICATION BAR
     ═══════════════════════════════════════════════════════ -->
<div class="el-cert-bar" aria-label="Certifications">
    <div class="el-cert-bar__inner el-container">
        <div class="el-cert-item"><span>🏅</span> NICEIC Approved Contractor</div>
        <div class="el-cert-item"><span>⚡</span> ELECSA Registered</div>
        <div class="el-cert-item"><span>📋</span> ECA Member</div>
        <div class="el-cert-item"><span>🔌</span> 18th Edition BS 7671</div>
        <div class="el-cert-item"><span>🛡️</span> £5M Public Liability</div>
        <div class="el-cert-item"><span>🚗</span> OZEV EV Installer</div>
    </div>
</div>

<!-- ═══════════════════════════════════════════════════════
     FOOTER
     ═══════════════════════════════════════════════════════ -->
<footer class="el-footer" role="contentinfo">
    <div class="el-container">
        <p>Emergency line — available 24 hours, 7 days</p>
        <div class="el-footer__phone">📞 0800 123 4567</div>
        <p>Hartwell Electrical Services Ltd &nbsp;·&nbsp; NICEIC Approved Contractor &nbsp;·&nbsp; <?php echo esc_html( get_bloginfo('name') ); ?></p>
        <p style="margin-top:16px;"><?php echo esc_html( get_bloginfo('name') ); ?> &copy; <?php echo date('Y'); ?> &nbsp;·&nbsp; All electrical work carried out to BS 7671:2018 &nbsp;·&nbsp; Part P Building Regulations compliant</p>
    </div>
</footer>

<script>
/* Electrician template JS — counter animation + no extra deps */
(function(){
    'use strict';

    /* IntersectionObserver counter animation */
    var easeOut = function(t){ return 1 - Math.pow(1 - t, 3); };
    var counters = document.querySelectorAll('.el-counter-num');

    if(!counters.length) return;

    var observer = new IntersectionObserver(function(entries){
        entries.forEach(function(entry){
            if(!entry.isIntersecting) return;
            observer.unobserve(entry.target);
            var el      = entry.target;
            var target  = parseFloat(el.dataset.target);
            var isFloat = el.dataset.float === '1';
            if(isNaN(target)) return;
            var start = null;
            var dur   = 1800;
            function tick(ts){
                if(!start) start = ts;
                var prog = Math.min((ts - start) / dur, 1);
                var val  = easeOut(prog) * target;
                el.textContent = isFloat ? val.toFixed(1) : Math.floor(val).toLocaleString();
                if(prog < 1) requestAnimationFrame(tick);
                else el.textContent = isFloat ? target.toFixed(1) : target.toLocaleString();
            }
            requestAnimationFrame(tick);
        });
    }, { threshold: 0.3 });

    counters.forEach(function(c){ observer.observe(c); });

    /* Voltmeter random flicker value */
    var voltVal = document.querySelector('.el-voltmeter__val');
    if(voltVal){
        setInterval(function(){
            var base = 230;
            var wobble = (Math.random() * 4 - 2).toFixed(0);
            voltVal.textContent = (base + parseInt(wobble)) + 'V';
        }, 3200);
    }

})();
</script>

</div><!-- . -->

<?php get_footer(); ?>
