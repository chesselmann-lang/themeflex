<?php
/**
 * Template Name: TF — Luxury Estate Agency & Property
 *
 * Ashby Stern Property — Kensington, London
 * Prime residential property consultancy since 1987
 *
 * @package ThemeFlex
 */

srand(crc32(get_the_permalink()));
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Bodoni+Moda:ital,wght@0,400;0,600;1,400&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
/* ============================================================
   ASHBY STERN PROPERTY — CSS CUSTOM PROPERTIES
   ============================================================ */
:root {
  --ea-navy:      #0D1B2A;   /* deep estate navy              */
  --ea-navy-md:   #152235;   /* mid navy                      */
  --ea-navy-lt:   #1D3050;   /* lighter navy                  */
  --ea-gold:      #B8952A;   /* polished gold                 */
  --ea-gold-lt:   #D4AE50;   /* light gold                    */
  --ea-pearl:     #F8F4EE;   /* warm pearl                    */
  --ea-ivory:     #F0EBE2;   /* antique ivory                 */
  --ea-stone:     #8A7E72;   /* warm stone                    */
  --ea-slate:     #4A5568;   /* blue-grey slate               */
  --ea-glass:     rgba(13,27,42,.85);

  --ea-serif: 'Bodoni Moda', 'Georgia', serif;
  --ea-sans:  'DM Sans', system-ui, sans-serif;

  --ea-radius: 2px;
  --ea-shadow: 0 12px 48px rgba(13,27,42,.18);
}

/* ============================================================
   RESET & BASE
   ============================================================ */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; }
body.page-template-page-estate-agent {
  font-family: var(--ea-sans);
  background: var(--ea-pearl);
  color: var(--ea-navy);
  line-height: 1.7;
  overflow-x: hidden;
}
.ea-container { max-width: 1200px; margin: 0 auto; padding: 0 36px; }
.ea-section { padding: 96px 0; }
.ea-tag {
  display: inline-block;
  font-size: .72rem;
  font-weight: 500;
  letter-spacing: .22em;
  text-transform: uppercase;
  color: var(--ea-gold);
  margin-bottom: 14px;
}
.ea-heading {
  font-family: var(--ea-serif);
  font-size: clamp(2rem, 4vw, 3.2rem);
  font-weight: 600;
  line-height: 1.2;
  color: var(--ea-navy);
}
.ea-heading em { font-style: italic; color: var(--ea-gold); }
.ea-lead {
  font-size: 1rem;
  color: var(--ea-stone);
  line-height: 1.85;
  max-width: 580px;
}
.ea-btn {
  display: inline-block;
  padding: 13px 32px;
  font-family: var(--ea-sans);
  font-size: .82rem;
  font-weight: 500;
  letter-spacing: .12em;
  text-transform: uppercase;
  text-decoration: none;
  border-radius: var(--ea-radius);
  transition: all .25s ease;
  cursor: pointer;
  border: none;
}
.ea-btn-primary {
  background: var(--ea-gold);
  color: var(--ea-navy);
}
.ea-btn-primary:hover { background: var(--ea-gold-lt); transform: translateY(-1px); box-shadow: 0 6px 24px rgba(184,149,42,.3); }
.ea-btn-ghost {
  background: transparent;
  color: var(--ea-pearl);
  border: 1px solid rgba(248,244,238,.35);
}
.ea-btn-ghost:hover { border-color: var(--ea-pearl); background: rgba(248,244,238,.08); }
.ea-btn-outline {
  background: transparent;
  color: var(--ea-gold);
  border: 1px solid rgba(184,149,42,.4);
}
.ea-btn-outline:hover { background: rgba(184,149,42,.06); border-color: var(--ea-gold); }

/* ============================================================
   HERO — GEORGIAN TOWNHOUSE EXTERIOR AT DUSK
   ============================================================ */
.ea-hero {
  position: relative;
  min-height: 100vh;
  background: var(--ea-navy);
  display: flex;
  align-items: center;
  overflow: hidden;
}

/* Sky at dusk */
.ea-sky {
  position: absolute;
  inset: 0;
  background: linear-gradient(180deg,
    #0A0E1A 0%,
    #1A2A4A 30%,
    #2A3A6A 55%,
    #3A3A5A 70%,
    #2A2230 85%,
    #1A1520 100%);
  z-index: 0;
}

/* Stars in upper sky */
<?php
$stars = [];
for ($s = 0; $s < 30; $s++):
  $stars[] = [
    'top'  => rand(2, 40),
    'left' => rand(0, 100),
    'size' => rand(1,3),
    'op'   => 3 + rand(0,5),
  ];
endfor;
foreach ($stars as $si => $sr):?>
.ea-star-<?php echo $si; ?> {
  position: absolute;
  top: <?php echo $sr['top']; ?>%;
  left: <?php echo $sr['left']; ?>%;
  width: <?php echo $sr['size']; ?>px;
  height: <?php echo $sr['size']; ?>px;
  background: rgba(255,255,240,<?php echo '0.'.$sr['op']; ?>);
  border-radius: 50%;
  z-index: 1;
}
<?php endforeach; ?>

/* Horizon glow */
.ea-horizon-glow {
  position: absolute;
  bottom: 30%; left: 0; right: 0;
  height: 200px;
  background: radial-gradient(ellipse at 50% 100%,
    rgba(100,80,160,.25) 0%,
    transparent 70%);
  z-index: 1;
  pointer-events: none;
}

/* Street — pavement */
.ea-pavement {
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 22%;
  background: linear-gradient(180deg, #1A1A22 0%, #0D0D14 100%);
  z-index: 2;
}
.ea-pavement::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 5px;
  background: linear-gradient(90deg,
    transparent 0%,
    rgba(184,149,42,.3) 40%,
    rgba(184,149,42,.5) 50%,
    rgba(184,149,42,.3) 60%,
    transparent 100%);
}
.ea-pavement::after {
  content: '';
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    90deg,
    transparent 0px, transparent 80px,
    rgba(255,255,255,.025) 80px, rgba(255,255,255,.025) 82px
  );
}

/* ===== GEORGIAN TERRACE ROW ===== */
.ea-terrace {
  position: absolute;
  bottom: 22%; left: 0; right: 0;
  z-index: 3;
  display: flex;
  align-items: flex-end;
  justify-content: center;
  gap: 0;
}

/* Individual townhouse */
<?php
$houses = [
  ['w'=>'14%','h'=>'70%','floors'=>4,'win_per_floor'=>2,'lit'=>true, 'side'=>'l','stucco'=>'#1E2A38','offset'=>'0px'],
  ['w'=>'12%','h'=>'62%','floors'=>3,'win_per_floor'=>2,'lit'=>false,'side'=>'l','stucco'=>'#18222E','offset'=>'0px'],
  ['w'=>'18%','h'=>'82%','floors'=>5,'win_per_floor'=>3,'lit'=>true, 'side'=>'c','stucco'=>'#1C2836','offset'=>'0px'],  /* hero house */
  ['w'=>'12%','h'=>'60%','floors'=>3,'win_per_floor'=>2,'lit'=>false,'side'=>'r','stucco'=>'#18222E','offset'=>'0px'],
  ['w'=>'14%','h'=>'68%','floors'=>4,'win_per_floor'=>2,'lit'=>true, 'side'=>'r','stucco'=>'#1A2630','offset'=>'0px'],
];
?>

/* Shared house styles */
.ea-house {
  flex-shrink: 0;
  position: relative;
  display: flex;
  flex-direction: column;
}
/* Stucco facade */
.ea-house-facade {
  position: absolute;
  inset: 0;
}
/* Parapet / cornice at top */
.ea-house-cornice {
  position: absolute;
  top: -10px; left: -4px; right: -4px;
  height: 14px;
  background: linear-gradient(180deg, #283848 0%, #1C2835 100%);
  border-radius: 1px 1px 0 0;
  z-index: 2;
}
.ea-house-cornice::before {
  content: '';
  position: absolute;
  bottom: 0; left: 4px; right: 4px;
  height: 4px;
  background: rgba(255,255,255,.06);
}

/* Front door */
.ea-door {
  position: absolute;
  bottom: 0;
  left: 50%; transform: translateX(-50%);
  width: 13%;
  height: 24%;
  z-index: 5;
}
.ea-door-surround {
  position: absolute;
  inset: -4px;
  border: 2px solid rgba(184,149,42,.4);
  border-radius: 2px 2px 0 0;
  clip-path: polygon(0 8%, 50% 0%, 100% 8%, 100% 100%, 0 100%);
}
.ea-door-body {
  position: absolute;
  inset: 0;
  background: linear-gradient(180deg, #2A1A0A 0%, #1A0A04 100%);
  border-radius: 2px 2px 0 0;
  clip-path: polygon(0 6%, 50% 0%, 100% 6%, 100% 100%, 0 100%);
}
.ea-door-fanlight {
  position: absolute;
  top: 0; left: 50%; transform: translateX(-50%);
  width: 60%;
  height: 22%;
  border-radius: 50% 50% 0 0;
  background: rgba(255,200,80,.18);
  border: 1px solid rgba(255,200,80,.3);
}
/* Door steps */
.ea-door-steps {
  position: absolute;
  bottom: -12px; left: 50%; transform: translateX(-50%);
  width: 160%;
  z-index: 6;
}
.ea-step {
  height: 6px;
  background: linear-gradient(180deg, #3A3A4A 0%, #282830 100%);
  margin: 0 auto;
  border-radius: 1px;
}

/* Wrought iron railings */
.ea-railings {
  position: absolute;
  bottom: -2px; left: -40px; right: -40px;
  height: 48px;
  z-index: 6;
  display: flex;
  justify-content: space-around;
  align-items: flex-end;
}
.ea-rail-post {
  width: 3px;
  height: 44px;
  background: linear-gradient(180deg, #4A4A5A 0%, #2A2A3A 100%);
  border-radius: 1px 1px 0 0;
  position: relative;
}
.ea-rail-post::before {
  content: '';
  position: absolute;
  top: -5px; left: 50%; transform: translateX(-50%);
  width: 7px;
  height: 7px;
  background: #C4943A;
  clip-path: polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%);
}
.ea-rail-bar {
  position: absolute;
  left: 0; right: 0;
  top: 30%;
  height: 2px;
  background: rgba(74,74,90,.7);
}

/* Window styles */
.ea-win {
  position: absolute;
  border: 1px solid rgba(255,255,255,.08);
  border-radius: 1px 1px 0 0;
  background: rgba(255,220,100,.0);
  overflow: hidden;
}
/* Lit window */
.ea-win.lit {
  background: radial-gradient(ellipse at 50% 80%,
    rgba(255,210,80,.3) 0%,
    rgba(200,150,40,.12) 60%,
    transparent 100%);
  box-shadow: inset 0 0 8px rgba(255,200,60,.1), 0 0 12px rgba(255,180,40,.08);
}
/* Window sash lines */
.ea-win::before {
  content: '';
  position: absolute;
  top: 50%; left: 0; right: 0;
  height: 1px;
  background: rgba(255,255,255,.1);
}
.ea-win::after {
  content: '';
  position: absolute;
  top: 0; bottom: 0; left: 50%;
  width: 1px;
  background: rgba(255,255,255,.1);
}
/* Window arch (for top-floor Venetian windows) */
.ea-win.arch {
  border-radius: 50% 50% 0 0 / 30% 30% 0 0;
  clip-path: ellipse(50% 70% at 50% 50%);
}
/* Window sill */
.ea-win-sill {
  position: absolute;
  bottom: -4px; left: -3px; right: -3px;
  height: 4px;
  background: rgba(255,255,255,.06);
}

/* Lamp posts on pavement */
<?php foreach ([20, 45, 72] as $lpi => $lpl):?>
.ea-lamppost-<?php echo $lpi; ?> {
  position: absolute;
  bottom: 22%; left: <?php echo $lpl; ?>%;
  z-index: 8;
}
.ea-lamppost-<?php echo $lpi; ?>-pole {
  width: 4px;
  height: 180px;
  background: linear-gradient(180deg, #444 0%, #222 100%);
  margin: 0 auto;
}
.ea-lamppost-<?php echo $lpi; ?>-arm {
  width: 40px;
  height: 3px;
  background: #333;
  position: absolute;
  top: 0; left: 50%; transform: translateX(-60%);
  border-radius: 2px;
}
.ea-lamppost-<?php echo $lpi; ?>-lamp {
  position: absolute;
  top: -10px; left: calc(50% - 24px);
  width: 20px;
  height: 18px;
  background: radial-gradient(ellipse, rgba(255,220,120,.9) 0%, rgba(200,160,60,.6) 60%, transparent 100%);
  border-radius: 2px;
}
.ea-lamppost-<?php echo $lpi; ?>-glow {
  position: absolute;
  top: -12px; left: calc(50% - 50px);
  width: 60px;
  height: 100px;
  background: radial-gradient(ellipse at 50% 0%, rgba(255,200,80,.18) 0%, transparent 70%);
  pointer-events: none;
}
<?php endforeach; ?>

/* Parked car (art-deco silhouette) */
.ea-car {
  position: absolute;
  bottom: 22%; right: 8%;
  z-index: 7;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.ea-car-body {
  width: 160px;
  height: 36px;
  background: linear-gradient(180deg, #1A1A2A 0%, #0D0D18 100%);
  border-radius: 12px 12px 4px 4px;
  position: relative;
}
.ea-car-body::before {
  content: '';
  position: absolute;
  top: -20px; left: 20%; right: 20%;
  height: 24px;
  background: linear-gradient(180deg, #252535 0%, #1A1A2A 100%);
  border-radius: 8px 8px 0 0;
}
.ea-car-body::after {
  content: '';
  position: absolute;
  top: -14px; left: 24%; right: 24%;
  height: 14px;
  background: rgba(100,140,220,.15);
  border-radius: 4px 4px 0 0;
}
.ea-car-wheels {
  display: flex;
  gap: 80px;
  margin-top: -6px;
}
.ea-car-wheel {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  background: radial-gradient(circle, #333 0%, #111 60%, #222 100%);
  border: 2px solid #444;
}
.ea-car-wheel::before {
  content: '';
  display: block;
  width: 10px;
  height: 10px;
  margin: 7px auto;
  border-radius: 50%;
  background: #555;
}
/* Headlights */
.ea-car-lights {
  position: absolute;
  top: 18px; left: -4px; right: -4px;
  display: flex;
  justify-content: space-between;
}
.ea-car-light {
  width: 12px;
  height: 8px;
  background: rgba(255,230,100,.15);
  border-radius: 2px;
}

/* FOR SALE board */
.ea-sign {
  position: absolute;
  bottom: calc(22% + 2px);
  left: 36%;
  z-index: 9;
}
.ea-sign-post {
  width: 4px;
  height: 100px;
  background: linear-gradient(180deg, #666 0%, #333 100%);
  margin: 0 auto;
}
.ea-sign-board {
  width: 110px;
  height: 56px;
  background: var(--ea-navy);
  border: 2px solid var(--ea-gold);
  border-radius: 2px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  margin-left: -53px;
  position: relative;
}
.ea-sign-board::before {
  content: 'ASHBY STERN';
  font-family: var(--ea-serif);
  font-size: .42rem;
  font-weight: 600;
  letter-spacing: .18em;
  color: var(--ea-gold);
  display: block;
  margin-bottom: 3px;
}
.ea-sign-board::after {
  content: 'FOR SALE';
  font-size: .72rem;
  font-weight: 500;
  letter-spacing: .15em;
  color: var(--ea-pearl);
  display: block;
}

/* Hero content */
.ea-hero-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(125deg, rgba(13,27,42,.9) 0%, rgba(13,27,42,.65) 55%, transparent 100%);
  z-index: 10;
}
.ea-hero-content {
  position: relative;
  z-index: 15;
  max-width: 620px;
}
.ea-hero-kicker {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  font-size: .7rem;
  font-weight: 500;
  letter-spacing: .22em;
  text-transform: uppercase;
  color: var(--ea-gold-lt);
  margin-bottom: 24px;
}
.ea-hero-kicker::before { content: '—'; }
.ea-hero-title {
  font-family: var(--ea-serif);
  font-size: clamp(2.6rem, 5.5vw, 4.8rem);
  font-weight: 600;
  line-height: 1.12;
  color: var(--ea-pearl);
  margin-bottom: 12px;
}
.ea-hero-title em { font-style: italic; color: var(--ea-gold-lt); }
.ea-hero-subtitle {
  font-family: var(--ea-serif);
  font-size: clamp(1rem, 2vw, 1.35rem);
  font-style: italic;
  color: rgba(248,244,238,.65);
  margin-bottom: 28px;
}
.ea-hero-desc {
  font-size: .95rem;
  color: rgba(248,244,238,.55);
  line-height: 1.85;
  margin-bottom: 40px;
}
.ea-hero-btns { display: flex; gap: 14px; flex-wrap: wrap; }

/* Search bar widget */
.ea-search-bar {
  position: absolute;
  bottom: 48px; left: 50%; transform: translateX(-50%);
  width: 90%; max-width: 800px;
  background: var(--ea-glass);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(184,149,42,.25);
  border-radius: var(--ea-radius);
  padding: 20px 24px;
  z-index: 15;
  display: flex;
  gap: 12px;
  align-items: flex-end;
}
.ea-search-field {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.ea-search-field label {
  font-size: .65rem;
  font-weight: 500;
  letter-spacing: .15em;
  text-transform: uppercase;
  color: rgba(184,149,42,.7);
}
.ea-search-field select,
.ea-search-field input {
  background: rgba(255,255,255,.06);
  border: 1px solid rgba(255,255,255,.1);
  border-radius: var(--ea-radius);
  padding: 10px 14px;
  font-family: var(--ea-sans);
  font-size: .85rem;
  color: var(--ea-pearl);
  outline: none;
  transition: border-color .2s;
}
.ea-search-field select option { background: var(--ea-navy); }
.ea-search-field select:focus,
.ea-search-field input:focus { border-color: var(--ea-gold); }

/* Property card (bottom right) */
.ea-prop-card {
  position: absolute;
  bottom: 48px; right: 36px;
  width: 210px;
  background: var(--ea-glass);
  border: 1px solid rgba(184,149,42,.3);
  border-radius: var(--ea-radius);
  overflow: hidden;
  z-index: 15;
  backdrop-filter: blur(6px);
}
.ea-prop-card-thumb {
  height: 90px;
  background: linear-gradient(180deg, #1C2836 0%, #0D1420 100%);
  position: relative;
  overflow: hidden;
}
/* Mini house in card */
.ea-pct-sky {
  position: absolute;
  inset: 0;
  background: linear-gradient(180deg, #1A2A4A 0%, #2A3A6A 80%, #1A1520 100%);
}
.ea-pct-house {
  position: absolute;
  bottom: 0; left: 50%; transform: translateX(-50%);
  width: 90px;
  height: 60px;
  background: #1C2836;
  border-top: 3px solid rgba(184,149,42,.4);
}
.ea-pct-house::before {
  content: '';
  position: absolute;
  bottom: 4px; left: 50%; transform: translateX(-50%);
  width: 16px;
  height: 24px;
  background: linear-gradient(180deg, #2A1A0A 0%, #1A0A04 100%);
  border-radius: 1px 1px 0 0;
}
<?php for ($pw = 0; $pw < 4; $pw++): $pwl = 8 + $pw * 22; $pwy = 10; ?>
.ea-pct-win-<?php echo $pw; ?> {
  position: absolute;
  width: 12px; height: 14px;
  left: <?php echo $pwl; ?>px;
  top: <?php echo $pwy; ?>px;
  background: rgba(255,200,80,<?php echo rand(1,4)/10; ?>);
  border: 1px solid rgba(255,255,255,.1);
}
<?php endfor; ?>
.ea-prop-card-info {
  padding: 14px 16px;
}
.ea-prop-card-price {
  font-family: var(--ea-serif);
  font-size: 1.1rem;
  font-weight: 600;
  color: var(--ea-gold-lt);
  margin-bottom: 4px;
}
.ea-prop-card-addr {
  font-size: .75rem;
  color: rgba(248,244,238,.55);
  margin-bottom: 8px;
  line-height: 1.4;
}
.ea-prop-card-specs {
  display: flex;
  gap: 10px;
  font-size: .68rem;
  font-weight: 500;
  letter-spacing: .06em;
  color: rgba(184,149,42,.8);
  text-transform: uppercase;
}

/* ============================================================
   STATS BAR
   ============================================================ */
.ea-stats-bar {
  background: var(--ea-navy-md);
  border-top: 2px solid rgba(184,149,42,.4);
  border-bottom: 1px solid rgba(255,255,255,.04);
  padding: 48px 0;
}
.ea-stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  text-align: center;
}
.ea-stat {
  padding: 12px 20px;
  border-right: 1px solid rgba(255,255,255,.06);
}
.ea-stat:last-child { border-right: none; }
.ea-stat-number {
  font-family: var(--ea-serif);
  font-size: 2.8rem;
  font-weight: 600;
  color: var(--ea-gold);
  line-height: 1;
  margin-bottom: 6px;
}
.ea-stat-label {
  font-size: .72rem;
  font-weight: 500;
  letter-spacing: .12em;
  text-transform: uppercase;
  color: rgba(248,244,238,.4);
}

/* ============================================================
   FEATURED PROPERTIES
   ============================================================ */
.ea-properties {
  background: var(--ea-pearl);
}
.ea-section-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  margin-bottom: 52px;
}
.ea-properties-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 28px;
}
.ea-property-card {
  background: var(--ea-ivory);
  border: 1px solid rgba(138,126,114,.12);
  border-radius: var(--ea-radius);
  overflow: hidden;
  transition: transform .25s ease, box-shadow .25s ease;
  cursor: pointer;
}
.ea-property-card:hover {
  transform: translateY(-4px);
  box-shadow: var(--ea-shadow);
}
/* Property CSS illustration */
.ea-prop-thumb {
  height: 200px;
  position: relative;
  overflow: hidden;
}
/* Each property has its own palette via inline CSS variables */
.ea-prop-sky-area {
  position: absolute;
  inset: 0;
  z-index: 0;
}
.ea-prop-facade {
  position: absolute;
  bottom: 0; left: 50%; transform: translateX(-50%);
  z-index: 2;
}
.ea-prop-door-pill {
  position: absolute;
  bottom: 0; left: 50%; transform: translateX(-50%);
  z-index: 4;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.ea-prop-badge {
  position: absolute;
  top: 12px; left: 12px;
  background: rgba(13,27,42,.8);
  color: var(--ea-gold-lt);
  font-size: .62rem;
  font-weight: 500;
  letter-spacing: .12em;
  text-transform: uppercase;
  padding: 4px 10px;
  border-radius: 2px;
  z-index: 5;
}
.ea-prop-info { padding: 22px 22px 26px; }
.ea-prop-price {
  font-family: var(--ea-serif);
  font-size: 1.4rem;
  font-weight: 600;
  color: var(--ea-navy);
  margin-bottom: 4px;
}
.ea-prop-address {
  font-size: .85rem;
  color: var(--ea-stone);
  margin-bottom: 14px;
  line-height: 1.4;
}
.ea-prop-specs {
  display: flex;
  gap: 16px;
  font-size: .75rem;
  font-weight: 500;
  color: var(--ea-slate);
  letter-spacing: .04em;
  margin-bottom: 16px;
}
.ea-prop-spec::before { margin-right: 4px; }
.ea-prop-tags {
  display: flex;
  gap: 6px;
  flex-wrap: wrap;
}
.ea-prop-tag {
  background: rgba(184,149,42,.1);
  color: var(--ea-gold);
  font-size: .64rem;
  font-weight: 500;
  letter-spacing: .1em;
  text-transform: uppercase;
  padding: 3px 8px;
  border-radius: 2px;
}

/* ============================================================
   ABOUT / PHILOSOPHY
   ============================================================ */
.ea-about {
  background: var(--ea-navy);
}
.ea-about .ea-tag { color: var(--ea-gold-lt); }
.ea-about .ea-heading { color: var(--ea-pearl); }
.ea-about .ea-heading em { color: var(--ea-gold-lt); }
.ea-about .ea-lead { color: rgba(248,244,238,.55); }
.ea-about-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 80px;
  align-items: center;
}
.ea-about-stats {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 24px;
  margin-top: 40px;
}
.ea-about-stat {
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(184,149,42,.2);
  border-radius: var(--ea-radius);
  padding: 24px 20px;
}
.ea-about-stat-n {
  font-family: var(--ea-serif);
  font-size: 2rem;
  font-weight: 600;
  color: var(--ea-gold);
  line-height: 1;
  margin-bottom: 4px;
}
.ea-about-stat-l {
  font-size: .75rem;
  font-weight: 500;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: rgba(248,244,238,.4);
}

/* London map illustration */
.ea-london-map {
  position: relative;
  height: 380px;
  background: rgba(255,255,255,.03);
  border: 1px solid rgba(184,149,42,.15);
  border-radius: var(--ea-radius);
  overflow: hidden;
}
.ea-map-grid {
  position: absolute;
  inset: 0;
}
.ea-map-grid::before {
  content: '';
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    0deg,
    rgba(255,255,255,.04) 0px, rgba(255,255,255,.04) 1px,
    transparent 1px, transparent 50px
  );
}
.ea-map-grid::after {
  content: '';
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    90deg,
    rgba(255,255,255,.04) 0px, rgba(255,255,255,.04) 1px,
    transparent 1px, transparent 60px
  );
}
/* Thames river suggestion */
.ea-thames {
  position: absolute;
  bottom: 20%; left: 0; right: 0;
  height: 22px;
  background: rgba(30,60,120,.35);
  border-top: 1px solid rgba(60,100,160,.4);
  border-bottom: 1px solid rgba(60,100,160,.3);
}
/* Location pins */
<?php
$pins = [
  ['name'=>'Kensington',   'top'=>28,'left'=>30,'size'=>'lg'],
  ['name'=>'Chelsea',      'top'=>38,'left'=>38,'size'=>'md'],
  ['name'=>'Belgravia',    'top'=>42,'left'=>46,'size'=>'md'],
  ['name'=>'Mayfair',      'top'=>22,'left'=>52,'size'=>'md'],
  ['name'=>'Notting Hill', 'top'=>20,'left'=>22,'size'=>'sm'],
  ['name'=>'Fulham',       'top'=>58,'left'=>25,'size'=>'sm'],
  ['name'=>'South Ken',    'top'=>50,'left'=>32,'size'=>'sm'],
];
foreach ($pins as $pni => $pn):
  $sz = $pn['size']==='lg' ? 14 : ($pn['size']==='md' ? 10 : 7);
  ?>
.ea-pin-<?php echo $pni; ?> {
  position: absolute;
  top: <?php echo $pn['top']; ?>%;
  left: <?php echo $pn['left']; ?>%;
  z-index: 3;
}
.ea-pin-<?php echo $pni; ?>-dot {
  width: <?php echo $sz; ?>px;
  height: <?php echo $sz; ?>px;
  background: var(--ea-gold);
  border-radius: 50%;
  border: 2px solid rgba(184,149,42,.3);
  box-shadow: 0 0 12px rgba(184,149,42,<?php echo $pn['size']==='lg'?'.5':'.3'; ?>);
}
.ea-pin-<?php echo $pni; ?>-label {
  font-size: .58rem;
  font-weight: 500;
  letter-spacing: .08em;
  text-transform: uppercase;
  color: rgba(248,244,238,.6);
  margin-top: 4px;
  white-space: nowrap;
}
<?php endforeach; ?>
/* Map title */
.ea-map-title {
  position: absolute;
  top: 14px; left: 16px;
  font-family: var(--ea-serif);
  font-size: .72rem;
  font-style: italic;
  color: rgba(184,149,42,.7);
  letter-spacing: .1em;
}

/* ============================================================
   SERVICES
   ============================================================ */
.ea-services {
  background: var(--ea-ivory);
}
.ea-services-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 28px;
  margin-top: 52px;
}
.ea-service-card {
  background: var(--ea-pearl);
  border-top: 3px solid transparent;
  border-radius: var(--ea-radius);
  padding: 36px 28px;
  transition: border-color .25s ease, box-shadow .25s ease, transform .25s ease;
}
.ea-service-card:hover {
  border-top-color: var(--ea-gold);
  box-shadow: var(--ea-shadow);
  transform: translateY(-4px);
}
.ea-service-num {
  font-family: var(--ea-serif);
  font-size: 2.4rem;
  font-weight: 600;
  font-style: italic;
  color: rgba(184,149,42,.2);
  line-height: 1;
  margin-bottom: 14px;
}
.ea-service-card h3 {
  font-family: var(--ea-serif);
  font-size: 1.15rem;
  font-weight: 600;
  color: var(--ea-navy);
  margin-bottom: 10px;
}
.ea-service-card p {
  font-size: .88rem;
  color: var(--ea-stone);
  line-height: 1.7;
}

/* ============================================================
   PROCESS
   ============================================================ */
.ea-process { background: var(--ea-pearl); }
.ea-process-steps {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 32px;
  margin-top: 60px;
  position: relative;
}
.ea-process-steps::before {
  content: '';
  position: absolute;
  top: 28px; left: 12.5%; right: 12.5%;
  height: 1px;
  background: linear-gradient(90deg, var(--ea-gold) 0%, rgba(184,149,42,.1) 100%);
}
.ea-step {
  text-align: center;
  position: relative;
}
.ea-step-dot {
  width: 56px; height: 56px;
  border-radius: 50%;
  background: var(--ea-navy);
  border: 1px solid var(--ea-gold);
  display: flex; align-items: center; justify-content: center;
  font-family: var(--ea-serif);
  font-size: 1.2rem;
  font-style: italic;
  color: var(--ea-gold);
  margin: 0 auto 20px;
  position: relative; z-index: 2;
}
.ea-step-title {
  font-family: var(--ea-serif);
  font-size: 1rem;
  font-weight: 600;
  color: var(--ea-navy);
  margin-bottom: 8px;
}
.ea-step-desc {
  font-size: .82rem;
  color: var(--ea-stone);
  line-height: 1.65;
}

/* ============================================================
   CSS AGENT FIGURES
   ============================================================ */
.ea-team-section {
  background: var(--ea-navy-md);
  padding: 96px 0;
  overflow: hidden;
}
.ea-team-section .ea-tag   { color: var(--ea-gold-lt); }
.ea-team-section .ea-heading { color: var(--ea-pearl); }
.ea-team-row {
  display: flex;
  justify-content: center;
  gap: 60px;
  margin-top: 60px;
}
.ea-agent-figure {
  display: flex;
  flex-direction: column;
  align-items: center;
}
/* Head */
.ea-agent-head {
  width: 40px; height: 44px;
  background: radial-gradient(ellipse at 40% 35%, #F0D0A0 0%, #C8A060 100%);
  border-radius: 50% 50% 45% 45%;
  position: relative;
}
/* Hair */
.ea-agent-head::before {
  content: '';
  position: absolute;
  top: -4px; left: -2px; right: -2px;
  height: 14px;
  background: #3A2A1A;
  border-radius: 50% 50% 0 0;
  clip-path: polygon(0 100%, 0 40%, 50% 0%, 100% 40%, 100% 100%);
}
/* Neck */
.ea-agent-neck {
  width: 14px; height: 10px;
  background: #C8A060;
  margin: 0 auto;
}
/* Dark suit jacket */
.ea-agent-suit {
  width: 64px; height: 76px;
  background: linear-gradient(180deg, #1E2840 0%, #141C2E 100%);
  border-radius: 6px 6px 2px 2px;
  position: relative;
}
/* White shirt front */
.ea-agent-suit::before {
  content: '';
  position: absolute;
  top: 0; left: 50%; transform: translateX(-50%);
  width: 18px;
  height: 100%;
  background: linear-gradient(180deg, #F0EEE8 0%, #E0DDD5 100%);
  clip-path: polygon(0 0%, 100% 0%, 85% 100%, 15% 100%);
}
/* Lapels */
.ea-agent-suit::after {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 32px;
  background: linear-gradient(135deg, #1E2840 0%, #1E2840 40%, transparent 40%),
              linear-gradient(-135deg, #1E2840 0%, #1E2840 40%, transparent 40%);
  background-position: left, right;
  background-size: 50% 100%;
  background-repeat: no-repeat;
}
/* Tie */
.ea-agent-tie {
  position: absolute;
  top: 4px; left: 50%; transform: translateX(-50%);
  width: 8px; height: 40px;
  background: linear-gradient(180deg, #B8952A 0%, #8A6A10 100%);
  clip-path: polygon(20% 0%, 80% 0%, 100% 75%, 50% 100%, 0% 75%);
  z-index: 2;
}
/* Arms */
.ea-agent-arm-l {
  position: absolute;
  top: 4px; left: -14px;
  width: 14px; height: 54px;
  background: linear-gradient(180deg, #1E2840 0%, #141C2E 100%);
  border-radius: 7px 4px 4px 7px;
  transform: rotate(4deg);
  transform-origin: top center;
}
/* Cuff */
.ea-agent-arm-l::before {
  content: '';
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 8px;
  background: #E0DDD5;
  border-radius: 2px;
}
.ea-agent-arm-r {
  position: absolute;
  top: 4px; right: -14px;
  width: 14px; height: 50px;
  background: linear-gradient(180deg, #1E2840 0%, #141C2E 100%);
  border-radius: 4px 7px 7px 4px;
  transform: rotate(-6deg);
  transform-origin: top center;
}
.ea-agent-arm-r::before {
  content: '';
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 8px;
  background: #E0DDD5;
  border-radius: 2px;
}
/* Briefcase */
.ea-agent-arm-r::after {
  content: '';
  position: absolute;
  bottom: -14px; left: 50%; transform: translateX(-50%);
  width: 24px; height: 18px;
  background: linear-gradient(180deg, #4A3018 0%, #2E1C0C 100%);
  border: 1px solid rgba(184,149,42,.4);
  border-radius: 2px;
}
/* Legs */
.ea-agent-legs {
  width: 64px; height: 64px; position: relative;
}
.ea-agent-leg-l, .ea-agent-leg-r {
  position: absolute;
  bottom: 0;
  width: 24px; height: 60px;
  background: linear-gradient(180deg, #1E2840 0%, #141C2E 100%);
  border-radius: 2px 2px 0 0;
}
.ea-agent-leg-l { left: 4px; }
.ea-agent-leg-r { right: 4px; }
.ea-agent-leg-l::after, .ea-agent-leg-r::after {
  content: '';
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 10px;
  background: #111;
  border-radius: 0 0 2px 2px;
}
.ea-agent-name {
  margin-top: 14px;
  font-family: var(--ea-serif);
  font-size: .95rem;
  font-style: italic;
  color: rgba(248,244,238,.7);
  text-align: center;
}
.ea-agent-role {
  font-size: .68rem;
  font-weight: 500;
  letter-spacing: .12em;
  text-transform: uppercase;
  color: var(--ea-gold);
  margin-top: 2px;
  text-align: center;
}

/* ============================================================
   TESTIMONIALS
   ============================================================ */
.ea-testimonials { background: var(--ea-pearl); }
.ea-testi-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 28px;
  margin-top: 52px;
}
.ea-testi-card {
  background: var(--ea-ivory);
  border-left: 3px solid var(--ea-gold);
  border-radius: 0 var(--ea-radius) var(--ea-radius) 0;
  padding: 32px 28px;
}
.ea-testi-stars { color: var(--ea-gold); font-size: .85rem; margin-bottom: 14px; }
.ea-testi-text {
  font-family: var(--ea-serif);
  font-style: italic;
  font-size: .95rem;
  color: var(--ea-navy);
  line-height: 1.75;
  margin-bottom: 20px;
}
.ea-testi-author {
  font-weight: 500;
  font-size: .8rem;
  color: var(--ea-stone);
  text-transform: uppercase;
  letter-spacing: .08em;
}
.ea-testi-prop {
  font-size: .75rem;
  color: var(--ea-gold);
  margin-top: 2px;
}

/* ============================================================
   FAQ
   ============================================================ */
.ea-faq { background: var(--ea-ivory); }
.ea-faq-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 52px;
  align-items: start;
  margin-top: 52px;
}
.ea-faq-list { display: flex; flex-direction: column; gap: 10px; }
.ea-faq-item {
  background: var(--ea-pearl);
  border: 1px solid rgba(138,126,114,.15);
  border-radius: var(--ea-radius);
  overflow: hidden;
}
.ea-faq-q {
  display: flex; justify-content: space-between; align-items: center;
  padding: 18px 22px;
  cursor: pointer;
  font-family: var(--ea-serif);
  font-size: .96rem;
  font-weight: 600;
  color: var(--ea-navy);
  user-select: none;
  transition: color .2s;
}
.ea-faq-q:hover { color: var(--ea-gold); }
.ea-faq-icon {
  width: 22px; height: 22px;
  border: 1px solid rgba(184,149,42,.4);
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .85rem;
  color: var(--ea-gold);
  flex-shrink: 0;
  transition: transform .3s ease;
}
.ea-faq-item.open .ea-faq-icon { transform: rotate(45deg); }
.ea-faq-a { max-height: 0; overflow: hidden; transition: max-height .35s ease; }
.ea-faq-a-inner {
  padding: 0 22px 18px;
  font-size: .86rem;
  color: var(--ea-stone);
  line-height: 1.78;
}
.ea-faq-item.open .ea-faq-a { max-height: 300px; }

.ea-faq-cta {
  background: var(--ea-navy);
  border-radius: var(--ea-radius);
  padding: 40px 32px;
  display: flex; flex-direction: column; gap: 20px;
}
.ea-faq-cta h3 {
  font-family: var(--ea-serif);
  font-size: 1.5rem;
  font-style: italic;
  color: var(--ea-pearl);
  line-height: 1.3;
}
.ea-faq-cta p {
  font-size: .88rem;
  color: rgba(248,244,238,.55);
  line-height: 1.75;
}
.ea-faq-contact { display: flex; flex-direction: column; gap: 10px; }
.ea-faq-contact a {
  color: var(--ea-gold-lt);
  text-decoration: none;
  font-size: .88rem;
  display: flex; align-items: center; gap: 8px;
  transition: color .2s;
}
.ea-faq-contact a:hover { color: var(--ea-pearl); }

/* ============================================================
   VALUATION / ENQUIRY FORM
   ============================================================ */
.ea-enquiry { background: var(--ea-navy); }
.ea-enquiry .ea-tag   { color: var(--ea-gold-lt); }
.ea-enquiry .ea-heading { color: var(--ea-pearl); }
.ea-enquiry .ea-lead { color: rgba(248,244,238,.5); }
.ea-form-wrapper {
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(184,149,42,.2);
  border-radius: var(--ea-radius);
  padding: 52px 48px;
  margin-top: 52px;
  max-width: 860px;
  margin-left: auto;
  margin-right: auto;
}
.ea-form-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 22px;
  margin-bottom: 22px;
}
.ea-form-group { display: flex; flex-direction: column; gap: 8px; }
.ea-form-group.full { grid-column: 1/-1; }
.ea-form-group label {
  font-size: .72rem;
  font-weight: 500;
  letter-spacing: .12em;
  text-transform: uppercase;
  color: rgba(248,244,238,.45);
}
.ea-form-group input,
.ea-form-group select,
.ea-form-group textarea {
  background: rgba(255,255,255,.06);
  border: 1px solid rgba(255,255,255,.1);
  border-radius: var(--ea-radius);
  padding: 13px 16px;
  font-family: var(--ea-sans);
  font-size: .9rem;
  color: var(--ea-pearl);
  transition: border-color .2s;
  outline: none; width: 100%;
}
.ea-form-group input::placeholder,
.ea-form-group textarea::placeholder { color: rgba(248,244,238,.25); }
.ea-form-group input:focus,
.ea-form-group select:focus,
.ea-form-group textarea:focus { border-color: var(--ea-gold); }
.ea-form-group select { cursor: pointer; }
.ea-form-group select option { background: var(--ea-navy); }
.ea-form-group textarea { resize: vertical; min-height: 110px; }
.ea-form-actions {
  display: flex; align-items: center; gap: 20px; margin-top: 8px;
}
.ea-form-note {
  font-size: .75rem;
  color: rgba(248,244,238,.3);
  line-height: 1.5;
}
.ea-form-success { display: none; text-align: center; padding: 32px; color: var(--ea-pearl); }
.ea-form-success h3 {
  font-family: var(--ea-serif);
  font-size: 1.5rem;
  font-style: italic;
  color: var(--ea-gold-lt);
  margin-bottom: 8px;
}

/* ============================================================
   FOOTER
   ============================================================ */
.ea-footer {
  background: #070D15;
  padding: 60px 0 32px;
  border-top: 1px solid rgba(184,149,42,.15);
}
.ea-footer-inner {
  display: grid;
  grid-template-columns: 2fr 1fr 1fr;
  gap: 60px;
  margin-bottom: 48px;
}
.ea-footer-brand h3 {
  font-family: var(--ea-serif);
  font-size: 1.4rem;
  font-style: italic;
  color: var(--ea-pearl);
  margin-bottom: 4px;
}
.ea-footer-brand > span {
  font-size: .68rem;
  font-weight: 500;
  letter-spacing: .2em;
  text-transform: uppercase;
  color: var(--ea-gold);
  display: block;
  margin-bottom: 14px;
}
.ea-footer-brand p {
  font-size: .82rem;
  color: rgba(248,244,238,.35);
  line-height: 1.7;
  max-width: 300px;
}
.ea-footer-col h4 {
  font-size: .68rem;
  font-weight: 500;
  letter-spacing: .18em;
  text-transform: uppercase;
  color: var(--ea-gold);
  margin-bottom: 16px;
}
.ea-footer-col ul { list-style: none; }
.ea-footer-col ul li { margin-bottom: 8px; }
.ea-footer-col ul li a {
  font-size: .82rem;
  color: rgba(248,244,238,.35);
  text-decoration: none;
  transition: color .2s;
}
.ea-footer-col ul li a:hover { color: var(--ea-pearl); }
.ea-footer-bottom {
  border-top: 1px solid rgba(255,255,255,.05);
  padding-top: 24px;
  display: flex; justify-content: space-between; align-items: center;
}
.ea-footer-bottom p { font-size: .75rem; color: rgba(248,244,238,.2); }
.ea-footer-bottom a { font-size: .75rem; color: rgba(184,149,42,.4); text-decoration: none; transition: color .2s; }
.ea-footer-bottom a:hover { color: var(--ea-gold); }

/* ============================================================
   RESPONSIVE
   ============================================================ */
@media (max-width: 1024px) {
  .ea-about-grid     { grid-template-columns: 1fr; gap: 48px; }
  .ea-london-map     { height: 260px; }
  .ea-properties-grid { grid-template-columns: repeat(2, 1fr); }
  .ea-services-grid  { grid-template-columns: repeat(2, 1fr); }
  .ea-footer-inner   { grid-template-columns: 1fr 1fr; }
  .ea-search-bar     { bottom: 24px; flex-wrap: wrap; }
}
@media (max-width: 768px) {
  .ea-section { padding: 64px 0; }
  .ea-container { padding: 0 20px; }
  .ea-stats-grid     { grid-template-columns: repeat(2, 1fr); }
  .ea-properties-grid { grid-template-columns: 1fr; }
  .ea-services-grid  { grid-template-columns: 1fr; }
  .ea-process-steps  { grid-template-columns: repeat(2, 1fr); }
  .ea-process-steps::before { display: none; }
  .ea-testi-grid     { grid-template-columns: 1fr; }
  .ea-faq-grid       { grid-template-columns: 1fr; }
  .ea-form-grid      { grid-template-columns: 1fr; }
  .ea-team-row       { flex-wrap: wrap; gap: 32px; }
  .ea-footer-inner   { grid-template-columns: 1fr; gap: 28px; }
  .ea-footer-bottom  { flex-direction: column; gap: 12px; text-align: center; }
  .ea-prop-card      { display: none; }
  .ea-search-bar     { display: none; }
  .ea-section-header { flex-direction: column; align-items: flex-start; gap: 16px; }
}
</style>
<?php get_header(); ?>
<div class="page-template-page-estate-agent">
>

<!-- HERO -->
<section class="ea-hero">
  <!-- Sky & stars -->
  <div class="ea-sky"></div>
  <?php foreach ($stars as $si => $sr): ?>
  <div class="ea-star-<?php echo $si; ?>"></div>
  <?php endforeach; ?>
  <div class="ea-horizon-glow"></div>
  <div class="ea-pavement"></div>

  <!-- Terrace row -->
  <div class="ea-terrace" style="position:absolute;bottom:22%;left:0;right:0;z-index:3;display:flex;align-items:flex-end;justify-content:center;">
    <?php foreach ($houses as $hi => $hse):
      $is_hero = $hse['side']==='c';
      $floors   = $hse['floors'];
      $wpf      = $hse['win_per_floor'];
    ?>
    <div class="ea-house" style="width:<?php echo $hse['w'];?>;height:<?php echo $hse['h'];?>;background:<?php echo $hse['stucco'];?>;">
      <div class="ea-house-cornice"></div>
      <?php if ($is_hero): ?>
      <!-- Hero house windows: arched top floor, sash below -->
      <?php for ($fl = 0; $fl < $floors; $fl++):
        $bot  = (100 / ($floors + 1)) * ($fl + 1);
        $top  = 100 - $bot - 14;
        $arch = ($fl === $floors - 1);
        for ($wi = 0; $wi < $wpf; $wi++):
          $wl   = 10 + $wi * (80 / $wpf);
          $lit  = rand(0,1) ? 'lit' : '';
      ?>
      <div class="ea-win <?php echo $lit; ?><?php echo $arch?' arch':''; ?>"
        style="width:<?php echo 62/$wpf;?>%;left:<?php echo $wl;?>%;top:<?php echo $top;?>%;height:14%;"></div>
      <?php endfor; endfor; ?>
      <!-- Front door -->
      <div class="ea-door">
        <div class="ea-door-surround"></div>
        <div class="ea-door-body"></div>
        <div class="ea-door-fanlight"></div>
        <div class="ea-door-steps">
          <?php foreach ([100, 88, 76] as $sw): ?>
          <div class="ea-step" style="width:<?php echo $sw;?>%;"></div>
          <?php endforeach; ?>
        </div>
      </div>
      <!-- Railings -->
      <div class="ea-railings">
        <?php for ($rp = 0; $rp < 12; $rp++): ?>
        <div class="ea-rail-post"><div class="ea-rail-bar"></div></div>
        <?php endfor; ?>
      </div>
      <?php else: ?>
      <!-- Side houses: regular sash windows -->
      <?php for ($fl = 0; $fl < $floors; $fl++):
        $bot = (100 / ($floors + 1)) * ($fl + 1);
        $top = 100 - $bot - 16;
        for ($wi = 0; $wi < $wpf; $wi++):
          $wl  = 12 + $wi * (70 / $wpf);
          $lit = $hse['lit'] && rand(0,2) ? 'lit' : '';
      ?>
      <div class="ea-win <?php echo $lit; ?>"
        style="width:<?php echo 55/$wpf;?>%;left:<?php echo $wl;?>%;top:<?php echo $top;?>%;height:15%;"></div>
      <?php endfor; endfor; ?>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Lamp posts -->
  <?php foreach ([20, 45, 72] as $lpi => $lpl): ?>
  <div class="ea-lamppost-<?php echo $lpi; ?>">
    <div class="ea-lamppost-<?php echo $lpi; ?>-arm"></div>
    <div class="ea-lamppost-<?php echo $lpi; ?>-lamp"></div>
    <div class="ea-lamppost-<?php echo $lpi; ?>-glow"></div>
    <div class="ea-lamppost-<?php echo $lpi; ?>-pole"></div>
  </div>
  <?php endforeach; ?>

  <!-- Parked car -->
  <div class="ea-car">
    <div class="ea-car-body">
      <div class="ea-car-lights">
        <div class="ea-car-light"></div>
        <div class="ea-car-light"></div>
      </div>
    </div>
    <div class="ea-car-wheels">
      <div class="ea-car-wheel"></div>
      <div class="ea-car-wheel"></div>
    </div>
  </div>

  <!-- FOR SALE sign -->
  <div class="ea-sign">
    <div class="ea-sign-board"></div>
    <div class="ea-sign-post"></div>
  </div>

  <div class="ea-hero-overlay"></div>

  <div class="ea-container" style="position:relative;z-index:15;width:100%;">
    <div class="ea-hero-content">
      <div class="ea-hero-kicker">Kensington · London · Est. 1987</div>
      <h1 class="ea-hero-title">
        Prime London<br><em>Property</em>,<br>Perfectly Placed
      </h1>
      <p class="ea-hero-subtitle">Residential sales, lettings & investment consultancy</p>
      <p class="ea-hero-desc">
        For over thirty-seven years Ashby Stern has guided discerning buyers and vendors through London's most sought-after neighbourhoods — with discretion, expertise, and an unmatched network.
      </p>
      <div class="ea-hero-btns">
        <a href="#properties" class="ea-btn ea-btn-primary">View Properties</a>
        <a href="#valuation" class="ea-btn ea-btn-ghost">Request Valuation</a>
      </div>
    </div>
  </div>

  <!-- Property card -->
  <div class="ea-prop-card">
    <div class="ea-prop-card-thumb">
      <div class="ea-pct-sky"></div>
      <div class="ea-pct-house">
        <?php for ($pw = 0; $pw < 4; $pw++): ?>
        <div class="ea-pct-win-<?php echo $pw; ?>"></div>
        <?php endfor; ?>
      </div>
    </div>
    <div class="ea-prop-card-info">
      <div class="ea-prop-card-price">£4,750,000</div>
      <div class="ea-prop-card-addr">Montpelier Square<br>Knightsbridge, SW7</div>
      <div class="ea-prop-card-specs">
        <span>5 bed</span>
        <span>3 bath</span>
        <span>3,200 sq ft</span>
      </div>
    </div>
  </div>

  <!-- Property search bar -->
  <div class="ea-search-bar">
    <div class="ea-search-field">
      <label>Location</label>
      <select>
        <option>All Prime Locations</option>
        <option>Kensington</option>
        <option>Chelsea</option>
        <option>Mayfair</option>
        <option>Belgravia</option>
        <option>Notting Hill</option>
        <option>Holland Park</option>
      </select>
    </div>
    <div class="ea-search-field">
      <label>Property Type</label>
      <select>
        <option>All Types</option>
        <option>Townhouse</option>
        <option>Apartment</option>
        <option>Penthouse</option>
        <option>Mews House</option>
        <option>Country Residence</option>
      </select>
    </div>
    <div class="ea-search-field">
      <label>Budget</label>
      <select>
        <option>All Prices</option>
        <option>Under £2m</option>
        <option>£2m – £5m</option>
        <option>£5m – £10m</option>
        <option>£10m – £20m</option>
        <option>£20m+</option>
      </select>
    </div>
    <div class="ea-search-field">
      <label>Bedrooms</label>
      <select>
        <option>Any</option>
        <option>1+</option><option>2+</option>
        <option>3+</option><option>4+</option><option>5+</option>
      </select>
    </div>
    <a href="#properties" class="ea-btn ea-btn-primary" style="white-space:nowrap;flex-shrink:0;">Search</a>
  </div>
</section>

<!-- STATS BAR -->
<section class="ea-stats-bar">
  <div class="ea-container">
    <div class="ea-stats-grid">
      <?php
      $stats = [
        ['val'=>'£2.4B+',  'lbl'=>'Properties Sold'],
        ['val'=>'37yrs',   'lbl'=>'London Expertise'],
        ['val'=>'4.9★',    'lbl'=>'Client Rating'],
        ['val'=>'1,800+',  'lbl'=>'Transactions Completed'],
      ];
      foreach ($stats as $st):?>
      <div class="ea-stat">
        <div class="ea-stat-number" data-target="<?php echo esc_attr($st['val']); ?>"><?php echo esc_html($st['val']); ?></div>
        <div class="ea-stat-label"><?php echo esc_html($st['lbl']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- FEATURED PROPERTIES -->
<section class="ea-properties ea-section" id="properties">
  <div class="ea-container">
    <div class="ea-section-header">
      <div>
        <span class="ea-tag">Current Listings</span>
        <h2 class="ea-heading">Featured <em>Properties</em></h2>
      </div>
      <a href="#" class="ea-btn ea-btn-outline">View All Listings</a>
    </div>
    <div class="ea-properties-grid">
      <?php
      $props = [
        [
          'price'   => '£6,950,000',
          'address' => 'Pelham Crescent, South Kensington, SW7',
          'beds'    => 6,'baths'=>4,'sqft'=>'4,100',
          'tags'    => ['Freehold','Garden','Mews Garage'],
          'badge'   => 'Sole Agent',
          'sky'     => '#1A2A4A', 'wall' => '#1C2836', 'win_lit' => .55,
        ],
        [
          'price'   => '£3,250,000',
          'address' => 'Carlyle Square, Chelsea, SW3',
          'beds'    => 4,'baths'=>3,'sqft'=>'2,450',
          'tags'    => ['Period','Terrace','EPC B'],
          'badge'   => 'New Listing',
          'sky'     => '#182238', 'wall' => '#18202E', 'win_lit' => .7,
        ],
        [
          'price'   => '£11,750,000',
          'address' => 'Chester Square, Belgravia, SW1W',
          'beds'    => 7,'baths'=>5,'sqft'=>'5,800',
          'tags'    => ['Listed','Stucco','Staff Flat'],
          'badge'   => 'Price on Application',
          'sky'     => '#1C2442', 'wall' => '#1E2A40', 'win_lit' => .4,
        ],
      ];
      foreach ($props as $pi => $prop):?>
      <div class="ea-property-card">
        <div class="ea-prop-thumb" style="background:<?php echo $prop['sky'];?>;">
          <!-- Mini property illustration -->
          <div style="position:absolute;bottom:0;left:50%;transform:translateX(-50%);width:80%;height:70%;background:<?php echo $prop['wall'];?>;z-index:2;">
            <?php for ($fl = 0; $fl < 3; $fl++):
              for ($wi2 = 0; $wi2 < 2; $wi2++):
                $wl2 = 15 + $wi2*42;
                $wt2 = 8 + $fl*30;
                $lit2 = (rand(0,100)/100) < $prop['win_lit'] ? 'rgba(255,210,80,.35)' : 'transparent';
            ?>
            <div style="position:absolute;width:20%;height:20%;left:<?php echo $wl2;?>%;top:<?php echo $wt2;?>%;background:<?php echo $lit2;?>;border:1px solid rgba(255,255,255,.1);"></div>
            <?php endfor; endfor; ?>
            <!-- Door -->
            <div style="position:absolute;bottom:0;left:50%;transform:translateX(-50%);width:12%;height:28%;background:#2A1A0A;border-radius:1px 1px 0 0;z-index:3;"></div>
          </div>
          <!-- Cornice line -->
          <div style="position:absolute;bottom:70%;left:10%;right:10%;height:2px;background:rgba(184,149,42,.4);z-index:3;"></div>
          <div class="ea-prop-badge"><?php echo esc_html($prop['badge']); ?></div>
        </div>
        <div class="ea-prop-info">
          <div class="ea-prop-price"><?php echo esc_html($prop['price']); ?></div>
          <div class="ea-prop-address"><?php echo esc_html($prop['address']); ?></div>
          <div class="ea-prop-specs">
            <span class="ea-prop-spec">🛏 <?php echo $prop['beds']; ?> bed</span>
            <span class="ea-prop-spec">🛁 <?php echo $prop['baths']; ?> bath</span>
            <span class="ea-prop-spec">📐 <?php echo $prop['sqft']; ?> sq ft</span>
          </div>
          <div class="ea-prop-tags">
            <?php foreach ($prop['tags'] as $tag): ?>
            <span class="ea-prop-tag"><?php echo esc_html($tag); ?></span>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ABOUT -->
<section class="ea-about ea-section" id="about">
  <div class="ea-container">
    <div class="ea-about-grid">
      <div>
        <span class="ea-tag">Our Firm</span>
        <h2 class="ea-heading">London's Most <em>Trusted</em> Property Advisors</h2>
        <p class="ea-lead" style="margin-top:20px;">Founded in Kensington in 1987, Ashby Stern has guided over £2.4 billion of prime London residential transactions. We combine deep local knowledge with a discreet, client-first approach.</p>
        <div class="ea-about-stats">
          <?php
          $as = [
            ['n'=>'37','l'=>'Years Established'],
            ['n'=>'#1','l'=>'Kensington Agent 2023'],
            ['n'=>'98%','l'=>'Client Satisfaction'],
            ['n'=>'£8.2M','l'=>'Average Sale Price'],
          ];
          foreach ($as as $a):?>
          <div class="ea-about-stat">
            <div class="ea-about-stat-n"><?php echo esc_html($a['n']); ?></div>
            <div class="ea-about-stat-l"><?php echo esc_html($a['l']); ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <!-- London map -->
      <div class="ea-london-map">
        <div class="ea-map-grid"></div>
        <div class="ea-thames"></div>
        <?php foreach ($pins as $pni => $pn): ?>
        <div class="ea-pin-<?php echo $pni; ?>">
          <div class="ea-pin-<?php echo $pni; ?>-dot"></div>
          <div class="ea-pin-<?php echo $pni; ?>-label"><?php echo esc_html($pn['name']); ?></div>
        </div>
        <?php endforeach; ?>
        <div class="ea-map-title">Prime London Coverage</div>
      </div>
    </div>
  </div>
</section>

<!-- SERVICES -->
<section class="ea-services ea-section" id="services">
  <div class="ea-container">
    <div class="ea-section-header">
      <div>
        <span class="ea-tag">Our Services</span>
        <h2 class="ea-heading">End-to-End <em>Property</em> Expertise</h2>
      </div>
    </div>
    <div class="ea-services-grid">
      <?php
      $svcs = [
        ['n'=>'01','title'=>'Residential Sales',    'desc'=>'Expert marketing, negotiation, and sale management for prime London properties, from instruction through to completion.'],
        ['n'=>'02','title'=>'Prime Lettings',        'desc'=>'Tenant finding, referencing, tenancy management, and block lettings for landlords and corporate clients.'],
        ['n'=>'03','title'=>'Property Search',       'desc'=>'A fully bespoke buying service — we source, vet, and acquire the right property entirely on your behalf.'],
        ['n'=>'04','title'=>'Investment Advisory',   'desc'=>'Portfolio strategy, yield analysis, and off-market sourcing for private investors and family offices.'],
        ['n'=>'05','title'=>'Valuations',            'desc'=>'Formal RICS-grade valuations and market appraisals, conducted by our chartered surveyors.'],
        ['n'=>'06','title'=>'New Development',       'desc'=>'Developer sales and consultancy from land acquisition and planning through to off-plan marketing and launch.'],
      ];
      foreach ($svcs as $sv):?>
      <div class="ea-service-card">
        <div class="ea-service-num"><?php echo esc_html($sv['n']); ?></div>
        <h3><?php echo esc_html($sv['title']); ?></h3>
        <p><?php echo esc_html($sv['desc']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- PROCESS -->
<section class="ea-process ea-section">
  <div class="ea-container">
    <div class="ea-section-header">
      <div>
        <span class="ea-tag">How We Work</span>
        <h2 class="ea-heading">The Ashby Stern <em>Approach</em></h2>
      </div>
    </div>
    <div class="ea-process-steps">
      <?php
      $steps = [
        ['n'=>'I',  'title'=>'Initial Consultation','desc'=>'A confidential meeting to understand your objectives, timeline, and requirements.'],
        ['n'=>'II', 'title'=>'Bespoke Strategy',    'desc'=>'We craft a personalised plan — whether selling, buying, or investing — with realistic market guidance.'],
        ['n'=>'III','title'=>'Active Search & Match','desc'=>'Access to on-market and discreet off-market opportunities, with honest shortlisting.'],
        ['n'=>'IV', 'title'=>'Exchange & Completion','desc'=>'Full support through survey, legal process, and exchange — until your keys are in hand.'],
      ];
      foreach ($steps as $stp):?>
      <div class="ea-step">
        <div class="ea-step-dot"><?php echo esc_html($stp['n']); ?></div>
        <h3 class="ea-step-title"><?php echo esc_html($stp['title']); ?></h3>
        <p class="ea-step-desc"><?php echo esc_html($stp['desc']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- TEAM -->
<section class="ea-team-section">
  <div class="ea-container">
    <div class="ea-section-header" style="margin-bottom:0;">
      <div>
        <span class="ea-tag">Our People</span>
        <h2 class="ea-heading">The <em>Ashby Stern</em> Team</h2>
      </div>
    </div>
    <div class="ea-team-row">
      <?php
      $agents = [
        ['name'=>'Charles Ashby',      'role'=>'Senior Partner'],
        ['name'=>'Victoria Stern',      'role'=>'Managing Director'],
        ['name'=>'James Pemberton',     'role'=>'Head of Sales'],
        ['name'=>'Amara Oyelaran',      'role'=>'Investment Advisory'],
      ];
      foreach ($agents as $ag):?>
      <div class="ea-agent-figure">
        <div class="ea-agent-head"></div>
        <div class="ea-agent-neck"></div>
        <div class="ea-agent-suit" style="position:relative;">
          <div class="ea-agent-arm-l"></div>
          <div class="ea-agent-arm-r"></div>
          <div class="ea-agent-tie"></div>
        </div>
        <div class="ea-agent-legs">
          <div class="ea-agent-leg-l"></div>
          <div class="ea-agent-leg-r"></div>
        </div>
        <div class="ea-agent-name"><?php echo esc_html($ag['name']); ?></div>
        <div class="ea-agent-role"><?php echo esc_html($ag['role']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="ea-testimonials ea-section">
  <div class="ea-container">
    <div class="ea-section-header">
      <div>
        <span class="ea-tag">Client Testimonials</span>
        <h2 class="ea-heading">What Our <em>Clients</em> Say</h2>
      </div>
    </div>
    <div class="ea-testi-grid">
      <?php
      $testis = [
        ['text'=>'Ashby Stern handled the sale of our Chelsea townhouse with absolute discretion and achieved well above asking price. Charles is simply the finest agent in London.','author'=>'Lord & Lady Carrington-Smythe','prop'=>'Chelsea Townhouse · Sold £4.2m'],
        ['text'=>'We searched for two years before engaging Victoria on a property search. Within six weeks she had found us the perfect Kensington home — off-market, naturally.','author'=>'Mr & Mrs Hoffmann','prop'=>'Kensington Villa · Purchased £7.8m'],
        ['text'=>'As a returning client from 2018 and again in 2024, I wouldn\'t consider using anyone else. Their knowledge of Belgravia is simply unrivalled.','author'=>'Alexander Petrova','prop'=>'Belgravia Apartment · Sold & Repurchased'],
      ];
      foreach ($testis as $tt):?>
      <div class="ea-testi-card">
        <div class="ea-testi-stars">★★★★★</div>
        <p class="ea-testi-text"><?php echo esc_html($tt['text']); ?></p>
        <div class="ea-testi-author"><?php echo esc_html($tt['author']); ?></div>
        <div class="ea-testi-prop"><?php echo esc_html($tt['prop']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- FAQ -->
<section class="ea-faq ea-section">
  <div class="ea-container">
    <div class="ea-section-header">
      <div>
        <span class="ea-tag">Questions</span>
        <h2 class="ea-heading">Common <em>Queries</em></h2>
      </div>
    </div>
    <div class="ea-faq-grid">
      <div class="ea-faq-list">
        <?php
        $faqs = [
          ['q'=>'Do you operate exclusively in central London?','a'=>'Our core focus is prime central London — Kensington, Chelsea, Belgravia, Mayfair, Notting Hill, Holland Park, and Fulham. We also handle select country and overseas assignments for established clients.'],
          ['q'=>'What does a property search service cost?','a'=>'Our property search retainer is typically 1–2% of the agreed purchase price, with an upfront search fee. We work exclusively for the buyer with no conflict of interest from vendors.'],
          ['q'=>'How quickly can you sell my property?','a'=>'Our average time from instruction to exchange is 11 weeks, though many properties exchange in under 6 weeks with the right preparation and pricing strategy.'],
          ['q'=>'Can you handle off-market transactions?','a'=>'Absolutely — a significant proportion of our transactions are conducted discreetly, off-market. Our 37-year network of vendors, developers, and fellow agents provides access that no portal can replicate.'],
          ['q'=>'Do you offer a lettings management service?','a'=>'Yes — our lettings team provides tenant-finding, reference checking, tenancy agreement drafting, rent collection, and full property management for landlords who prefer a hands-off approach.'],
        ];
        foreach ($faqs as $fi => $faq):?>
        <div class="ea-faq-item">
          <div class="ea-faq-q" aria-expanded="false" role="button" tabindex="0">
            <?php echo esc_html($faq['q']); ?>
            <span class="ea-faq-icon">+</span>
          </div>
          <div class="ea-faq-a">
            <div class="ea-faq-a-inner"><?php echo esc_html($faq['a']); ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <div class="ea-faq-cta">
        <h3>Speak to an advisor directly</h3>
        <p>Every enquiry is handled personally by one of our senior partners. No call centres, no junior staff — just direct access to London's most experienced property professionals.</p>
        <div class="ea-faq-contact">
          <a href="tel:+442078881987">📞 +44 (0)20 7888 1987</a>
          <a href="mailto:enquiries@ashbystern.co.uk">✉ enquiries@ashbystern.co.uk</a>
          <a href="#">📍 14 Kensington Court, London W8 5DL</a>
        </div>
        <a href="#valuation" class="ea-btn ea-btn-primary">Request Valuation</a>
      </div>
    </div>
  </div>
</section>

<!-- VALUATION / ENQUIRY -->
<section class="ea-enquiry ea-section" id="valuation">
  <div class="ea-container">
    <div class="ea-section-header" style="flex-direction:column;align-items:flex-start;">
      <span class="ea-tag">Get in Touch</span>
      <h2 class="ea-heading">Request a <em>Valuation</em> or Consultation</h2>
      <p class="ea-lead" style="margin-top:14px;">Whether you are considering selling, seeking to purchase, or simply curious about the current value of your property, we welcome your enquiry.</p>
    </div>
    <div class="ea-form-wrapper">
      <div class="ea-form-success" id="ea-success">
        <h3>Enquiry Received</h3>
        <p>A senior partner will be in touch within one business day.</p>
      </div>
      <form id="ea-enquiry-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <?php wp_nonce_field('tf_ea_enquiry','tf_ea_nonce'); ?>
        <input type="hidden" name="action" value="tf_ea_enquiry">
        <div class="ea-form-grid">
          <div class="ea-form-group">
            <label for="ea-name">Full Name *</label>
            <input type="text" id="ea-name" name="ea_name" placeholder="Charles Ashworth" required>
          </div>
          <div class="ea-form-group">
            <label for="ea-email">Email Address *</label>
            <input type="email" id="ea-email" name="ea_email" placeholder="charles@example.com" required>
          </div>
          <div class="ea-form-group">
            <label for="ea-phone">Telephone</label>
            <input type="tel" id="ea-phone" name="ea_phone" placeholder="+44 (0)20 7000 0000">
          </div>
          <div class="ea-form-group">
            <label for="ea-enquiry-type">Nature of Enquiry *</label>
            <select id="ea-enquiry-type" name="ea_enquiry_type" required>
              <option value="">Please select</option>
              <option value="valuation">Sales Valuation</option>
              <option value="buy">Buy / Property Search</option>
              <option value="let">Lettings Enquiry</option>
              <option value="invest">Investment Advisory</option>
              <option value="offmarket">Off-Market Opportunity</option>
              <option value="other">General Enquiry</option>
            </select>
          </div>
          <div class="ea-form-group">
            <label for="ea-location">Preferred Location(s)</label>
            <input type="text" id="ea-location" name="ea_location" placeholder="e.g. Kensington, Chelsea">
          </div>
          <div class="ea-form-group">
            <label for="ea-budget">Budget / Estimated Value</label>
            <select id="ea-budget" name="ea_budget">
              <option value="">Select range</option>
              <option value="<2m">Under £2 million</option>
              <option value="2-5m">£2m – £5m</option>
              <option value="5-10m">£5m – £10m</option>
              <option value="10-20m">£10m – £20m</option>
              <option value="20m+">£20m+</option>
            </select>
          </div>
          <div class="ea-form-group full">
            <label for="ea-notes">Additional Notes</label>
            <textarea id="ea-notes" name="ea_notes" placeholder="Please share any additional details about your requirements, timeframe, or specific property address for valuation…"></textarea>
          </div>
        </div>
        <div class="ea-form-actions">
          <button type="submit" class="ea-btn ea-btn-primary">Submit Enquiry</button>
          <p class="ea-form-note">All enquiries are handled with complete discretion. We will never share your details with third parties.</p>
        </div>
      </form>
    </div>
  </div>
</section>

<!-- FOOTER -->
<footer class="ea-footer">
  <div class="ea-container">
    <div class="ea-footer-inner">
      <div class="ea-footer-brand">
        <h3>Ashby Stern Property</h3>
        <span>Residential Consultancy · Est. 1987</span>
        <p>Prime central London sales, lettings, and property search. Authorised and regulated by the Property Ombudsman. Members of RICS and NAEA Propertymark.</p>
      </div>
      <div class="ea-footer-col">
        <h4>Services</h4>
        <ul>
          <li><a href="#">Residential Sales</a></li>
          <li><a href="#">Prime Lettings</a></li>
          <li><a href="#">Property Search</a></li>
          <li><a href="#">Investment Advisory</a></li>
          <li><a href="#">New Development</a></li>
        </ul>
      </div>
      <div class="ea-footer-col">
        <h4>Contact</h4>
        <ul>
          <li><a href="tel:+442078881987">+44 (0)20 7888 1987</a></li>
          <li><a href="mailto:enquiries@ashbystern.co.uk">enquiries@ashbystern.co.uk</a></li>
          <li><a href="#">14 Kensington Court</a></li>
          <li><a href="#">London W8 5DL</a></li>
        </ul>
      </div>
    </div>
    <div class="ea-footer-bottom">
      <p>© <?php echo date('Y'); ?> Ashby Stern Property Ltd. All rights reserved. Registered in England No. 2134567.</p>
      <a href="#">Privacy & Cookie Policy</a>
    </div>
  </div>
</footer>

<script>
(function(){
  // ---- FAQ ----
  document.querySelectorAll('.ea-faq-q').forEach(function(btn){
    btn.addEventListener('click',function(){
      var item=this.closest('.ea-faq-item'),open=item.classList.contains('open');
      document.querySelectorAll('.ea-faq-item.open').forEach(function(o){
        o.classList.remove('open');
        o.querySelector('.ea-faq-q').setAttribute('aria-expanded','false');
      });
      if(!open){item.classList.add('open');this.setAttribute('aria-expanded','true');}
    });
    btn.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();this.click();}});
  });

  // ---- Counters ----
  var easeOut=function(t){return 1-Math.pow(1-t,3);};
  var obs=new IntersectionObserver(function(entries){
    entries.forEach(function(entry){
      if(!entry.isIntersecting)return;
      var el=entry.target;
      var raw=el.getAttribute('data-target')||'';
      var num=parseFloat(raw.replace(/[^0-9.]/g,''));
      if(isNaN(num)){obs.unobserve(el);return;}
      var isFloat=raw.indexOf('.')!==-1;
      var dur=1400,start=null;
      function tick(now){
        if(!start)start=now;
        var p=Math.min((now-start)/dur,1);
        var v=easeOut(p)*num;
        var prefix=raw.match(/^[£$€]/)?raw[0]:'';
        var suffix=raw.replace(/^[£$€]?[0-9.,]+/,'');
        el.textContent=prefix+(isFloat?v.toFixed(1):Math.floor(v).toLocaleString())+suffix;
        if(p<1)requestAnimationFrame(tick);
        else el.textContent=raw;
      }
      requestAnimationFrame(tick);
      obs.unobserve(el);
    });
  },{threshold:.4});
  document.querySelectorAll('.ea-stat-number').forEach(function(c){obs.observe(c);});

  // ---- Form ----
  var form=document.getElementById('ea-enquiry-form');
  var succ=document.getElementById('ea-success');
  if(form){form.addEventListener('submit',function(e){e.preventDefault();form.style.display='none';succ.style.display='block';});}
})();
</script>
</body>
</html>
</div><!-- .page-template-page-estate-agent -->
<?php get_footer(); ?>
