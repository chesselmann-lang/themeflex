<?php
/**
 * Template Name: Event Planner — Prestige Events
 *
 * Premium event planning & management page template.
 * Palette  : champagne #E8D5A0 / deep charcoal #1E1E2A / rose gold #C0806A / ivory #FAFAF5 / slate #3A4050
 * Fonts    : Great Vibes (script) + Josefin Sans (headings/body)
 * Namespace: --ep-*
 *
 * @package ThemeFlex
 */

if ( ! defined( 'ABSPATH' ) ) exit;

srand( crc32( get_the_permalink() ) );

/* ── helpers ── */
$site  = get_bloginfo( 'name' ) ?: 'Prestige Events';
$phone = get_theme_mod( 'tf_phone', '+44 20 7946 0844' );
$email = get_theme_mod( 'tf_email', 'hello@prestigeevents.co.uk' );
$addr  = get_theme_mod( 'tf_address', 'Mayfair, London W1K' );

/* ── event types / services ── */
$services = [
  [ 'icon' => '💍', 'title' => 'Weddings',            'desc' => 'Intimate garden ceremonies to grand ballroom celebrations — every detail orchestrated to perfection.' ],
  [ 'icon' => '🏢', 'title' => 'Corporate Events',    'desc' => 'Product launches, galas, and award evenings that impress clients, reward teams, and build your brand.' ],
  [ 'icon' => '🎂', 'title' => 'Milestone Birthdays', 'desc' => 'Turning 30, 40, 50 or beyond — celebrations tailored to the personality that deserves to be honoured.' ],
  [ 'icon' => '🎊', 'title' => 'Private Parties',     'desc' => 'Garden parties, rooftop soirées, intimate dinners — every occasion elevated beyond expectation.' ],
  [ 'icon' => '🎤', 'title' => 'Charity Galas',       'desc' => 'High-profile fundraising events that move hearts, open wallets, and leave your cause unforgettable.' ],
  [ 'icon' => '✈️', 'title' => 'Destination Events',  'desc' => 'From Tuscany to Santorini — we plan, coordinate, and execute flawlessly wherever in the world you choose.' ],
];

/* ── process steps ── */
$steps = [
  [ 'num' => '01', 'title' => 'Discovery',     'desc' => 'An initial consultation to understand your vision, budget, guest count, and the feeling you want your event to create.' ],
  [ 'num' => '02', 'title' => 'Concept',       'desc' => 'We develop a bespoke creative concept — mood boards, venue shortlists, and theme proposals tailored to you.' ],
  [ 'num' => '03', 'title' => 'Planning',      'desc' => 'Every vendor, timeline, logistics chain, and supplier is secured, contracted, and briefed. Nothing is left to chance.' ],
  [ 'num' => '04', 'title' => 'Production',    'desc' => 'Décor, AV, catering, entertainment — all managed by our team as your event transforms from plan to reality.' ],
  [ 'num' => '05', 'title' => 'Your Event',    'desc' => 'We are on-site from first set-up to final goodbye, managing everything so you are free to be fully present.' ],
  [ 'num' => '06', 'title' => 'Wrap & Review', 'desc' => 'Post-event debrief, vendor settlements, and supplier recommendations for future events — completely handled.' ],
];

/* ── packages ── */
$packages = [
  [
    'name'     => 'Day-Of Coordination',
    'price'    => 'from £1,800',
    'period'   => 'one-day event',
    'featured' => false,
    'features' => [ 'Final 4-week planning hand-off', 'Vendor liaison & confirmation', 'Full day-of coordination', 'Timeline management', 'Supplier payment on your behalf', 'Post-event report' ],
  ],
  [
    'name'     => 'Full Planning',
    'price'    => 'from £4,500',
    'period'   => 'end-to-end',
    'featured' => true,
    'features' => [ 'Unlimited planning consultations', 'Bespoke concept & mood boards', 'Vendor sourcing & negotiations', 'Budget management & tracking', 'Guest management system', 'Full day-of coordination', 'Post-event report & gifting' ],
  ],
  [
    'name'     => 'Destination Package',
    'price'    => 'POA',
    'period'   => 'worldwide',
    'featured' => false,
    'features' => [ 'International venue sourcing', 'Logistics & travel coordination', 'Local supplier network', 'Language & cultural liaison', 'Extended on-site team', 'Post-event coverage' ],
  ],
];

/* ── testimonials ── */
$testimonials = [
  [
    'quote' => 'Our daughter\'s wedding was beyond anything we dared to dream. Prestige Events handled 340 guests across two venues flawlessly. We didn\'t deal with a single issue — because they had already solved everything before we knew it existed. Extraordinary.',
    'name'  => 'The Henderson Family',
    'event' => 'Wedding — Blenheim Palace, Oxfordshire',
    'stars' => 5,
  ],
  [
    'quote' => 'We\'ve worked with event agencies across Europe for fifteen years. Prestige Events is on another level — creative, responsive, precise, and always ten steps ahead. Our annual gala has never looked better. They are our exclusive partner going forward.',
    'name'  => 'Victoria C.',
    'event' => 'Director, Henderson Capital Partners',
    'stars' => 5,
  ],
  [
    'quote' => 'My 50th birthday was the best night of my life. I arrived to a room that made me gasp. Every detail — from the hand-painted menus to the surprise act — was perfectly me. I had to do nothing except enjoy myself. Which I absolutely did.',
    'name'  => 'Diana M.',
    'event' => 'Private Birthday — Claridge\'s, London',
    'stars' => 5,
  ],
];

/* ── event stats ── */
$gallery_items = [
  ['linear-gradient(135deg,#2A1A20 0%,#4A2A30 100%)','Wedding Gala'],
  ['linear-gradient(135deg,#1A1A2A 0%,#2A2A3A 100%)','Corporate Launch'],
  ['linear-gradient(135deg,#2A1A10 0%,#5A3A20 100%)','Birthday Soirée'],
  ['linear-gradient(135deg,#1A2A2A 0%,#2A3A3A 100%)','Charity Gala'],
  ['linear-gradient(135deg,#2A2010 0%,#4A3810 100%)','Destination Wedding'],
  ['linear-gradient(135deg,#2A1520 0%,#3A2030 100%)','Private Party'],
];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Josefin+Sans:ital,wght@0,100;0,300;0,400;0,600;0,700;1,300&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════
   PRESTIGE EVENTS — CSS CUSTOM PROPERTIES
   ═══════════════════════════════════════════ */
:root {
  --ep-champ:  #E8D5A0;
  --ep-champ2: #D4C080;
  --ep-dark:   #1E1E2A;
  --ep-dark2:  #14141E;
  --ep-rose:   #C0806A;
  --ep-rose2:  #D09070;
  --ep-ivory:  #FAFAF5;
  --ep-slate:  #3A4050;
  --ep-text:   #2A2A35;
  --ep-muted:  #6B7280;
  --ep-white:  #FFFFFF;
  --ep-rad:    6px;
  --ep-rad-lg: 14px;
  --ep-shadow: 0 4px 24px rgba(30,30,42,.1);
  --ep-shadow2:0 16px 52px rgba(30,30,42,.2);
  --ep-font-s: 'Great Vibes', cursive;
  --ep-font-h: 'Josefin Sans', system-ui, sans-serif;
  --ep-ease:   cubic-bezier(.4,0,.2,1);
}
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: var(--ep-font-h); color: var(--ep-text); background: var(--ep-ivory); overflow-x: hidden; }
img  { max-width: 100%; display: block; }
a    { color: inherit; text-decoration: none; }
.ep-wrap  { max-width: 1200px; margin: 0 auto; padding: 0 24px; }
.ep-sec   { padding: 100px 0; }
.ep-sec--alt  { background: #F5F0E8; }
.ep-sec--dark { background: var(--ep-dark); color: var(--ep-white); }
.ep-sec--dark2 { background: var(--ep-dark2); color: var(--ep-white); }
.ep-eyebrow {
  display: inline-flex; align-items: center; gap: 12px;
  font-size: .68rem; font-weight: 600;
  letter-spacing: .2em; text-transform: uppercase;
  color: var(--ep-champ2);
  margin-bottom: 12px;
}
.ep-eyebrow::before, .ep-eyebrow::after { content: ''; display: block; width: 20px; height: 1px; background: var(--ep-champ2); opacity: .5; }
.ep-h2 {
  font-family: var(--ep-font-h);
  font-size: clamp(1.9rem,3.8vw,3rem); font-weight: 100;
  letter-spacing: .08em; line-height: 1.25; margin-bottom: 18px;
}
.ep-h2 strong { font-weight: 600; }
.ep-lead {
  font-size: 1rem; line-height: 1.8; font-weight: 300;
  color: var(--ep-muted); max-width: 620px;
}
.ep-sec--dark .ep-lead, .ep-sec--dark2 .ep-lead { color: rgba(255,255,255,.55); }
.ep-center { text-align: center; }
.ep-center .ep-lead { margin: 0 auto; }
.ep-center .ep-eyebrow { justify-content: center; }

/* ════════════════════════════════
   NAVBAR
   ════════════════════════════════ */
.ep-nav {
  position: fixed; top: 0; left: 0; width: 100%; z-index: 1000;
  background: rgba(30,30,42,.95);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid rgba(232,213,160,.15);
}
.ep-nav__inner {
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 32px; height: 72px; max-width: 1300px; margin: 0 auto;
}
.ep-nav__logo {
  font-family: var(--ep-font-s);
  font-size: 2rem; color: var(--ep-champ);
}
.ep-nav__links { display: flex; gap: 30px; align-items: center; }
.ep-nav__links a {
  font-size: .72rem; font-weight: 600; letter-spacing: .12em; text-transform: uppercase;
  color: rgba(250,250,245,.6); transition: color .25s;
}
.ep-nav__links a:hover { color: var(--ep-champ); }
.ep-nav__cta {
  border: 1px solid rgba(232,213,160,.4) !important;
  color: var(--ep-champ) !important;
  padding: 9px 22px; border-radius: 2px;
  transition: all .25s !important;
}
.ep-nav__cta:hover { background: rgba(232,213,160,.1) !important; }

/* ════════════════════════════════
   HERO
   ════════════════════════════════ */
.ep-hero {
  position: relative;
  height: 100vh; min-height: 700px;
  background: var(--ep-dark2);
  overflow: hidden;
  display: flex; align-items: center; justify-content: center;
}

/* ── CSS event venue scene ── */
.ep-hero__scene { position: absolute; inset: 0; overflow: hidden; }

/* dark ballroom walls */
.ep-scene__wall {
  position: absolute; inset: 0;
  background: linear-gradient(180deg, #0A0A14 0%, #14141E 40%, #1E1E2A 100%);
}

/* wainscoting panels */
.ep-scene__panels {
  position: absolute;
  bottom: 0; left: 0; right: 0; height: 35%;
  background:
    repeating-linear-gradient(
      90deg,
      transparent 0px, transparent 90px,
      rgba(232,213,160,.06) 90px, rgba(232,213,160,.06) 92px
    );
  border-top: 2px solid rgba(232,213,160,.12);
}

/* floor */
.ep-scene__floor {
  position: absolute;
  bottom: 0; left: 0; right: 0; height: 22%;
  background: repeating-linear-gradient(
    90deg,
    #1A1408 0px, #1A1408 80px,
    #201A0A 80px, #201A0A 82px
  );
}
/* floor reflection */
.ep-scene__floor::after {
  content: '';
  position: absolute;
  top: 0; left: 20%; right: 20%; height: 60%;
  background: radial-gradient(ellipse at center, rgba(232,213,160,.06) 0%, transparent 70%);
}

/* chandelier */
.ep-scene__chandelier {
  position: absolute;
  top: 2%; left: 50%; transform: translateX(-50%);
  width: 220px;
}
/* chain */
.ep-scene__chandelier::before {
  content: '';
  position: absolute;
  top: 0; left: 50%; transform: translateX(-50%);
  width: 2px; height: 40px;
  background: rgba(232,213,160,.4);
}
/* main body */
.ep-scene__chandelier-body {
  position: absolute;
  top: 40px; left: 50%; transform: translateX(-50%);
  width: 80px; height: 24px;
  background: linear-gradient(180deg, rgba(232,213,160,.6) 0%, rgba(200,160,80,.4) 100%);
  border-radius: 4px;
}
/* chandelier tier 1 */
.ep-scene__chandelier-t1 {
  position: absolute;
  top: 56px; left: 50%; transform: translateX(-50%);
  width: 140px; height: 14px;
  background: rgba(232,213,160,.25);
  border-radius: 2px;
}
/* tier 1 drops */
.ep-scene__chandelier-t1::before {
  content: '';
  position: absolute;
  bottom: -24px; left: 50%; transform: translateX(-50%);
  width: 160px; height: 24px;
  background-image: repeating-linear-gradient(
    90deg,
    transparent 0px, transparent 12px,
    rgba(232,213,160,.5) 12px, rgba(232,213,160,.5) 14px
  );
}
/* chandelier tier 2 */
.ep-scene__chandelier-t2 {
  position: absolute;
  top: 94px; left: 50%; transform: translateX(-50%);
  width: 200px; height: 10px;
  background: rgba(232,213,160,.2);
  border-radius: 2px;
}
.ep-scene__chandelier-t2::before {
  content: '';
  position: absolute;
  bottom: -30px; left: 50%; transform: translateX(-50%);
  width: 220px; height: 30px;
  background-image: repeating-linear-gradient(
    90deg,
    transparent 0px, transparent 10px,
    rgba(232,213,160,.4) 10px, rgba(232,213,160,.4) 12px
  );
}
/* chandelier glow */
.ep-scene__chandelier-glow {
  position: absolute;
  top: 0; left: 50%; transform: translateX(-50%);
  width: 400px; height: 300px;
  background: radial-gradient(ellipse at center top, rgba(232,213,160,.12) 0%, transparent 65%);
  pointer-events: none;
}

/* round tables with linen */
.ep-scene__table {
  position: absolute;
  bottom: 22%;
}
.ep-scene__table-top {
  position: absolute;
  bottom: 0;
  width: 100%; height: 20px;
  background: linear-gradient(180deg, #F5EFE0 0%, #E8E0CC 100%);
  border-radius: 50%;
  border: 1px solid rgba(232,213,160,.3);
}
.ep-scene__table-cloth {
  position: absolute;
  bottom: -4px; left: -8px; right: -8px;
  height: 28px;
  background: rgba(250,248,240,.95);
  border-radius: 50%;
  border: 1px solid rgba(232,213,160,.2);
}
.ep-scene__table-leg {
  position: absolute;
  bottom: -40px; left: 50%; transform: translateX(-50%);
  width: 10px; height: 40px;
  background: #8B7040;
  border-radius: 5px;
}
.ep-scene__table-base {
  position: absolute;
  bottom: -46px; left: 50%; transform: translateX(-50%);
  width: 50px; height: 6px;
  background: #6B5030;
  border-radius: 3px;
}

/* chair near each table */
.ep-scene__chair {
  position: absolute;
  bottom: 22%;
}
.ep-scene__chair-back {
  position: absolute;
  bottom: 28px; left: 50%; transform: translateX(-50%);
  width: 24px; height: 36px;
  background: rgba(30,20,15,.8);
  border-radius: 3px 3px 0 0;
  border: 1px solid rgba(232,213,160,.15);
}
.ep-scene__chair-seat {
  position: absolute;
  bottom: 22px; left: 50%; transform: translateX(-50%);
  width: 28px; height: 8px;
  background: rgba(40,30,20,.9);
  border-radius: 2px;
}
/* chair sash */
.ep-scene__chair-back::after {
  content: '';
  position: absolute;
  top: 40%; left: 50%; transform: translate(-50%,-50%);
  width: 100%; height: 8px;
  background: rgba(192,128,106,.5);
  border-radius: 2px;
}

/* floral centrepiece */
.ep-scene__centrepiece {
  position: absolute;
  bottom: 22%;
}
.ep-scene__cp-vase {
  position: absolute;
  bottom: 0; left: 50%; transform: translateX(-50%);
  width: 12px; height: 20px;
  background: linear-gradient(180deg, rgba(250,248,240,.9) 0%, rgba(220,200,160,.7) 100%);
  border-radius: 3px 3px 5px 5px;
}
.ep-scene__cp-flowers {
  position: absolute;
  bottom: 18px; left: 50%; transform: translateX(-50%);
  width: 40px; height: 30px;
  background: radial-gradient(ellipse, rgba(192,128,106,.7) 0%, rgba(176,80,112,.5) 50%, rgba(232,213,160,.4) 100%);
  border-radius: 50% 50% 30% 30%;
}

/* floating candles / lights */
.ep-scene__fairy-lights {
  position: absolute;
  top: 8%; left: 3%; right: 3%;
  height: 2px;
  background: linear-gradient(90deg, transparent, rgba(232,213,160,.3) 30%, rgba(232,213,160,.6) 50%, rgba(232,213,160,.3) 70%, transparent);
}
.ep-scene__fairy-lights::after {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0; height: 100%;
  background-image: repeating-linear-gradient(
    90deg,
    transparent 0px, transparent 22px,
    rgba(232,213,160,.9) 22px, rgba(232,213,160,.9) 26px
  );
  animation: ep-lights-twinkle 3s ease-in-out infinite alternate;
}
@keyframes ep-lights-twinkle {
  from { opacity: .6; }
  to   { opacity: 1; }
}
/* second string */
.ep-scene__fairy-lights-2 {
  position: absolute;
  top: 14%; left: 8%; right: 8%;
  height: 1px;
  background: rgba(232,213,160,.2);
}
.ep-scene__fairy-lights-2::after {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  background-image: repeating-linear-gradient(
    90deg,
    transparent 0px, transparent 18px,
    rgba(232,213,160,.7) 18px, rgba(232,213,160,.7) 21px
  );
  height: 100%;
  animation: ep-lights-twinkle 2.5s ease-in-out infinite alternate;
  animation-delay: .8s;
}

/* arch entrance with draping */
.ep-scene__arch {
  position: absolute;
  top: 0; left: 50%; transform: translateX(-50%);
  width: 32%; height: 70%;
  border-left: 2px solid rgba(232,213,160,.2);
  border-right: 2px solid rgba(232,213,160,.2);
  border-radius: 50% 50% 0 0 / 20% 20% 0 0;
}
.ep-scene__arch::before {
  content: '';
  position: absolute;
  top: 4%; left: 8%; right: 8%; bottom: 0;
  border-left: 1px solid rgba(232,213,160,.1);
  border-right: 1px solid rgba(232,213,160,.1);
  border-radius: 50% 50% 0 0 / 20% 20% 0 0;
}
/* curtains framing arch */
.ep-scene__curtain-l {
  position: absolute;
  top: 0; left: 10%;
  width: 10%; height: 65%;
  background: linear-gradient(180deg, rgba(30,20,42,.8) 0%, rgba(20,14,28,.6) 100%);
  transform-origin: top center;
  transform: perspective(300px) rotateY(12deg);
  border-right: 1px solid rgba(232,213,160,.1);
}
.ep-scene__curtain-r {
  position: absolute;
  top: 0; right: 10%;
  width: 10%; height: 65%;
  background: linear-gradient(180deg, rgba(30,20,42,.8) 0%, rgba(20,14,28,.6) 100%);
  transform-origin: top center;
  transform: perspective(300px) rotateY(-12deg);
  border-left: 1px solid rgba(232,213,160,.1);
}

/* ── hero text ── */
.ep-hero__content {
  position: relative; z-index: 2;
  text-align: center; padding: 0 24px;
  color: var(--ep-white);
}
.ep-hero__script {
  font-family: var(--ep-font-s);
  font-size: clamp(3.5rem,8vw,7rem);
  color: var(--ep-champ);
  line-height: 1; margin-bottom: 10px;
  animation: ep-fade-up 1.4s ease .3s both;
}
@keyframes ep-fade-up {
  from { opacity: 0; transform: translateY(24px); }
  to   { opacity: 1; transform: translateY(0); }
}
.ep-hero__sub {
  font-family: var(--ep-font-h);
  font-size: clamp(1rem,2.2vw,1.6rem); font-weight: 100;
  letter-spacing: .22em; text-transform: uppercase;
  color: rgba(250,250,245,.7); margin-bottom: 22px;
}
.ep-hero__tag {
  font-size: .72rem; font-weight: 400;
  letter-spacing: .15em; text-transform: uppercase;
  color: rgba(232,213,160,.5); margin-bottom: 40px;
}
.ep-hero__actions { display: flex; gap: 16px; justify-content: center; flex-wrap: wrap; }

/* ── buttons ── */
.ep-btn {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 13px 30px; border-radius: 2px;
  font-family: var(--ep-font-h);
  font-size: .72rem; font-weight: 600;
  letter-spacing: .14em; text-transform: uppercase;
  cursor: pointer; border: none;
  transition: all .3s var(--ep-ease);
}
.ep-btn--champ { background: var(--ep-champ); color: var(--ep-dark); }
.ep-btn--champ:hover { background: var(--ep-champ2); transform: translateY(-2px); box-shadow: 0 8px 24px rgba(232,213,160,.3); }
.ep-btn--ghost { background: transparent; border: 1px solid rgba(232,213,160,.4); color: var(--ep-champ); }
.ep-btn--ghost:hover { background: rgba(232,213,160,.08); border-color: var(--ep-champ); }
.ep-btn--dark { background: var(--ep-dark); color: var(--ep-white); }
.ep-btn--dark:hover { background: var(--ep-dark2); }

/* ════════════════════════════════
   TRUST BAR
   ════════════════════════════════ */
.ep-trust { background: var(--ep-dark); padding: 20px 0; border-top: 1px solid rgba(232,213,160,.12); }
.ep-trust__inner {
  display: flex; flex-wrap: wrap; justify-content: center; gap: 10px 36px;
  max-width: 1200px; margin: 0 auto; padding: 0 24px;
}
.ep-trust__item {
  display: flex; align-items: center; gap: 8px;
  font-size: .7rem; font-weight: 600;
  letter-spacing: .1em; text-transform: uppercase;
  color: rgba(232,213,160,.65);
}
.ep-trust__item::before { content: '✦'; font-size: .6rem; color: var(--ep-champ); }

/* ════════════════════════════════
   SERVICES GRID
   ════════════════════════════════ */
.ep-services__grid {
  display: grid; grid-template-columns: repeat(auto-fit, minmax(300px,1fr)); gap: 24px; margin-top: 56px;
}
.ep-service {
  background: var(--ep-white);
  border-radius: var(--ep-rad-lg); padding: 36px 30px;
  box-shadow: var(--ep-shadow);
  border-bottom: 3px solid transparent;
  transition: all .3s var(--ep-ease); position: relative; overflow: hidden;
}
.ep-service::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0; height: 2px;
  background: linear-gradient(90deg, var(--ep-champ), var(--ep-rose));
  transform: scaleX(0); transition: transform .3s; transform-origin: left;
}
.ep-service:hover { transform: translateY(-6px); box-shadow: var(--ep-shadow2); border-bottom-color: var(--ep-champ2); }
.ep-service:hover::before { transform: scaleX(1); }
.ep-service__icon { font-size: 2.2rem; margin-bottom: 16px; display: block; }
.ep-service__title { font-size: 1.05rem; font-weight: 700; letter-spacing: .06em; text-transform: uppercase; color: var(--ep-dark); margin-bottom: 10px; }
.ep-service__desc { font-size: .9rem; line-height: 1.75; color: var(--ep-muted); font-weight: 300; }

/* ════════════════════════════════
   GALLERY
   ════════════════════════════════ */
.ep-gallery__grid {
  display: grid;
  grid-template-columns: repeat(3,1fr);
  grid-template-rows: repeat(2, 240px);
  gap: 4px; margin-top: 52px;
}
.ep-gallery__item { position: relative; overflow: hidden; }
.ep-gallery__item:nth-child(1) { grid-column: span 2; }
.ep-gallery__item:nth-child(4) { grid-column: span 2; }
.ep-gallery__panel { width: 100%; height: 100%; transition: transform .5s var(--ep-ease); }
.ep-gallery__item:hover .ep-gallery__panel { transform: scale(1.05); }
.ep-gallery__label {
  position: absolute; bottom: 16px; left: 18px;
  font-family: var(--ep-font-h);
  font-size: .72rem; font-weight: 600;
  letter-spacing: .1em; text-transform: uppercase;
  color: rgba(232,213,160,.8);
  opacity: 0; transition: opacity .3s;
}
.ep-gallery__item:hover .ep-gallery__label { opacity: 1; }

/* ════════════════════════════════
   COUNTERS
   ════════════════════════════════ */
.ep-counters__grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 2px; }
.ep-counter {
  text-align: center; padding: 56px 20px;
  background: rgba(232,213,160,.04); border: 1px solid rgba(232,213,160,.1);
}
.ep-counter__num {
  font-family: var(--ep-font-h);
  font-size: clamp(2.4rem,5vw,3.8rem); font-weight: 100;
  color: var(--ep-champ); display: block; line-height: 1; margin-bottom: 8px;
}
.ep-counter__label {
  font-size: .7rem; font-weight: 600;
  letter-spacing: .1em; text-transform: uppercase;
  color: rgba(232,213,160,.45);
}

/* ════════════════════════════════
   PROCESS
   ════════════════════════════════ */
.ep-process__grid {
  display: grid; grid-template-columns: repeat(3,1fr); gap: 0; margin-top: 56px;
}
.ep-step {
  padding: 40px 32px; border: 1px solid rgba(232,213,160,.08);
  transition: background .25s;
}
.ep-step:hover { background: rgba(232,213,160,.04); }
.ep-step__num {
  font-family: var(--ep-font-s);
  font-size: 3.5rem; color: rgba(232,213,160,.2);
  display: block; line-height: 1; margin-bottom: 12px;
}
.ep-step__title {
  font-size: .88rem; font-weight: 700;
  letter-spacing: .12em; text-transform: uppercase;
  color: var(--ep-champ2); margin-bottom: 12px;
}
.ep-step__desc { font-size: .87rem; line-height: 1.75; color: rgba(255,255,255,.5); font-weight: 300; }

/* ════════════════════════════════
   PACKAGES
   ════════════════════════════════ */
.ep-packages__grid {
  display: grid; grid-template-columns: repeat(3,1fr); gap: 28px; margin-top: 56px; align-items: start;
}
.ep-package {
  background: var(--ep-white); border-radius: var(--ep-rad-lg);
  padding: 40px 32px; box-shadow: var(--ep-shadow);
  border: 2px solid transparent; transition: all .3s var(--ep-ease); position: relative;
}
.ep-package:hover { transform: translateY(-4px); box-shadow: var(--ep-shadow2); }
.ep-package--featured {
  background: linear-gradient(145deg, var(--ep-dark) 0%, #28283A 100%);
  color: var(--ep-white); border-color: rgba(232,213,160,.3);
  box-shadow: 0 12px 48px rgba(30,30,42,.25); transform: scale(1.04);
}
.ep-package--featured:hover { transform: scale(1.04) translateY(-4px); }
.ep-package__badge {
  position: absolute; top: -14px; left: 50%; transform: translateX(-50%);
  background: var(--ep-champ); color: var(--ep-dark);
  font-size: .66rem; font-weight: 700; letter-spacing: .14em; text-transform: uppercase;
  padding: 6px 18px; border-radius: 20px; white-space: nowrap;
}
.ep-package__name {
  font-size: 1.1rem; font-weight: 700;
  letter-spacing: .08em; text-transform: uppercase;
  margin-bottom: 10px; color: var(--ep-dark);
}
.ep-package--featured .ep-package__name { color: var(--ep-white); }
.ep-package__price {
  font-family: var(--ep-font-h);
  font-size: 1.9rem; font-weight: 300;
  color: var(--ep-champ2); line-height: 1; margin-bottom: 4px;
}
.ep-package__period { font-size: .78rem; color: var(--ep-muted); margin-bottom: 24px; font-weight: 300; }
.ep-package--featured .ep-package__period { color: rgba(255,255,255,.5); }
.ep-package__divider { height: 1px; background: rgba(30,30,42,.08); margin-bottom: 22px; }
.ep-package--featured .ep-package__divider { background: rgba(232,213,160,.12); }
.ep-package__features { list-style: none; margin-bottom: 30px; }
.ep-package__features li {
  padding: 8px 0; font-size: .88rem; font-weight: 300;
  display: flex; align-items: center; gap: 10px; color: var(--ep-muted);
  border-bottom: 1px solid rgba(30,30,42,.06);
}
.ep-package__features li:last-child { border-bottom: none; }
.ep-package--featured .ep-package__features li { color: rgba(255,255,255,.7); border-color: rgba(232,213,160,.06); }
.ep-package__features li::before { content: '✦'; color: var(--ep-champ2); font-size: .65rem; flex-shrink: 0; }
.ep-package__cta {
  display: block; width: 100%; padding: 13px; border-radius: var(--ep-rad);
  text-align: center; font-family: var(--ep-font-h);
  font-size: .72rem; font-weight: 700; letter-spacing: .1em; text-transform: uppercase;
  cursor: pointer; border: none; transition: all .3s var(--ep-ease);
}
.ep-package__cta--outline { background: transparent; border: 1px solid rgba(30,30,42,.2); color: var(--ep-dark); }
.ep-package__cta--outline:hover { border-color: var(--ep-dark); background: var(--ep-dark); color: var(--ep-white); }
.ep-package__cta--champ { background: var(--ep-champ); color: var(--ep-dark); }
.ep-package__cta--champ:hover { background: var(--ep-champ2); }

/* ════════════════════════════════
   TESTIMONIALS
   ════════════════════════════════ */
.ep-testimonials__grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; margin-top: 52px; }
.ep-testimonial {
  background: rgba(255,255,255,.04); border: 1px solid rgba(232,213,160,.12);
  border-radius: var(--ep-rad-lg); padding: 40px 28px;
  position: relative; transition: transform .3s;
}
.ep-testimonial:hover { transform: translateY(-4px); border-color: rgba(232,213,160,.25); }
.ep-testimonial::before {
  content: '"';
  position: absolute; top: 14px; left: 20px;
  font-family: var(--ep-font-s); font-size: 5rem; line-height: 1;
  color: rgba(232,213,160,.15);
}
.ep-testimonial__stars { display: flex; gap: 3px; margin-bottom: 16px; }
.ep-testimonial__stars span { color: var(--ep-champ); font-size: .9rem; }
.ep-testimonial__quote {
  font-family: var(--ep-font-h); font-style: italic; font-weight: 300;
  font-size: .95rem; line-height: 1.8;
  color: rgba(250,250,245,.75); margin-bottom: 22px;
  position: relative; z-index: 1;
}
.ep-testimonial__name  { font-weight: 700; font-size: .85rem; color: var(--ep-champ2); }
.ep-testimonial__event { font-size: .72rem; color: rgba(255,255,255,.35); font-weight: 300; margin-top: 4px; }

/* ════════════════════════════════
   BOOKING FORM
   ════════════════════════════════ */
.ep-booking { background: var(--ep-dark); }
.ep-booking__grid { display: grid; grid-template-columns: 1fr 1.3fr; gap: 64px; align-items: start; }
.ep-booking__info h3 {
  font-family: var(--ep-font-h);
  font-size: 1.8rem; font-weight: 100;
  letter-spacing: .08em; text-transform: uppercase;
  color: var(--ep-white); margin-bottom: 18px;
}
.ep-booking__info p { font-size: .9rem; line-height: 1.85; font-weight: 300; color: rgba(255,255,255,.55); margin-bottom: 24px; }
.ep-booking__promise { list-style: none; }
.ep-booking__promise li {
  padding: 10px 0; font-size: .85rem; font-weight: 300;
  color: rgba(255,255,255,.6);
  display: flex; align-items: flex-start; gap: 10px;
  border-bottom: 1px solid rgba(232,213,160,.08);
}
.ep-booking__promise li:last-child { border-bottom: none; }
.ep-booking__promise li::before { content: '✦'; color: var(--ep-champ); flex-shrink: 0; font-size: .65rem; margin-top: 3px; }
.ep-booking__contact {
  margin-top: 28px; padding: 20px 24px;
  background: rgba(232,213,160,.06); border: 1px solid rgba(232,213,160,.15);
  border-radius: var(--ep-rad);
  font-size: .82rem; font-weight: 300; color: rgba(255,255,255,.45); line-height: 2.2;
}
.ep-form {
  background: rgba(255,255,255,.04); border: 1px solid rgba(232,213,160,.18);
  border-radius: var(--ep-rad-lg); padding: 40px; backdrop-filter: blur(8px);
}
.ep-form__row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.ep-form__group { margin-bottom: 18px; }
.ep-form__group label {
  display: block; font-size: .66rem; font-weight: 700;
  letter-spacing: .12em; text-transform: uppercase;
  color: rgba(232,213,160,.6); margin-bottom: 8px;
}
.ep-form__group input,
.ep-form__group select,
.ep-form__group textarea {
  width: 100%;
  background: rgba(255,255,255,.05); border: 1px solid rgba(232,213,160,.15);
  border-radius: var(--ep-rad);
  padding: 12px 14px;
  font-family: var(--ep-font-h); font-size: .88rem; font-weight: 300;
  color: var(--ep-white); outline: none;
  transition: border-color .25s, background .25s;
}
.ep-form__group input::placeholder,
.ep-form__group textarea::placeholder { color: rgba(255,255,255,.25); }
.ep-form__group input:focus,
.ep-form__group select:focus,
.ep-form__group textarea:focus { border-color: var(--ep-champ); background: rgba(255,255,255,.07); }
.ep-form__group select option { background: var(--ep-dark); color: var(--ep-white); }
.ep-form__group textarea { resize: vertical; min-height: 100px; }
.ep-form__submit {
  width: 100%; padding: 15px;
  background: var(--ep-champ); color: var(--ep-dark);
  border: none; border-radius: var(--ep-rad);
  font-family: var(--ep-font-h); font-size: .78rem; font-weight: 700;
  letter-spacing: .12em; text-transform: uppercase;
  cursor: pointer; transition: all .3s var(--ep-ease);
  box-shadow: 0 4px 18px rgba(232,213,160,.2);
}
.ep-form__submit:hover { background: var(--ep-champ2); transform: translateY(-2px); box-shadow: 0 10px 28px rgba(232,213,160,.35); }

/* ════════════════════════════════
   FOOTER
   ════════════════════════════════ */
.ep-footer { background: var(--ep-dark2); padding: 28px 0; border-top: 1px solid rgba(232,213,160,.1); }
.ep-footer__inner {
  display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap;
  gap: 14px; max-width: 1200px; margin: 0 auto; padding: 0 24px;
}
.ep-footer__logo { font-family: var(--ep-font-s); font-size: 1.7rem; color: var(--ep-champ); }
.ep-footer__copy { font-size: .72rem; color: rgba(255,255,255,.25); font-weight: 300; }
.ep-footer__links { display: flex; gap: 20px; }
.ep-footer__links a { font-size: .72rem; color: rgba(255,255,255,.35); transition: color .2s; }
.ep-footer__links a:hover { color: var(--ep-champ); }

/* ════════════════════════════════
   ANIMATION
   ════════════════════════════════ */
.ep-reveal { opacity: 0; transform: translateY(28px); transition: opacity .65s var(--ep-ease), transform .65s var(--ep-ease); }
.ep-reveal.is-visible { opacity: 1; transform: translateY(0); }

/* ════════════════════════════════
   RESPONSIVE
   ════════════════════════════════ */
@media (max-width: 1024px) {
  .ep-booking__grid { grid-template-columns: 1fr; gap: 40px; }
  .ep-process__grid { grid-template-columns: repeat(2,1fr); }
}
@media (max-width: 768px) {
  .ep-sec { padding: 70px 0; }
  .ep-nav__links { display: none; }
  .ep-counters__grid { grid-template-columns: repeat(2,1fr); }
  .ep-packages__grid { grid-template-columns: 1fr; }
  .ep-package--featured { transform: none; }
  .ep-testimonials__grid { grid-template-columns: 1fr; }
  .ep-form__row { grid-template-columns: 1fr; }
  .ep-gallery__grid { grid-template-columns: 1fr 1fr; grid-template-rows: auto; }
  .ep-gallery__item:nth-child(1),
  .ep-gallery__item:nth-child(4) { grid-column: span 1; }
  .ep-process__grid { grid-template-columns: 1fr; }
}
</style>
<?php get_header(); ?>
<div class="ep-page">
>

<!-- NAVBAR -->
<nav class="ep-nav" aria-label="Main navigation">
  <div class="ep-nav__inner">
    <a href="<?php echo esc_url( home_url('/') ); ?>" class="ep-nav__logo">Prestige Events</a>
    <div class="ep-nav__links">
      <a href="#services">Services</a>
      <a href="#events">Portfolio</a>
      <a href="#packages">Investment</a>
      <a href="#booking" class="ep-nav__cta">Enquire</a>
    </div>
  </div>
</nav>

<!-- HERO -->
<section class="ep-hero" aria-label="Hero">
  <div class="ep-hero__scene" aria-hidden="true">
    <div class="ep-scene__wall"></div>
    <div class="ep-scene__panels"></div>
    <div class="ep-scene__fairy-lights"></div>
    <div class="ep-scene__fairy-lights-2"></div>
    <div class="ep-scene__chandelier-glow"></div>
    <div class="ep-scene__chandelier">
      <div class="ep-scene__chandelier-body"></div>
      <div class="ep-scene__chandelier-t1"></div>
      <div class="ep-scene__chandelier-t2"></div>
    </div>
    <div class="ep-scene__curtain-l"></div>
    <div class="ep-scene__curtain-r"></div>
    <div class="ep-scene__arch"></div>
    <div class="ep-scene__floor"></div>

    <?php
    /* tables + chairs + centrepieces */
    $tables = [
      ['15%','25%'], ['55%','20%'], ['76%','28%'],
      ['28%','60%'], ['62%','62%'],
    ];
    foreach ( $tables as $i => $t ) : ?>
    <div class="ep-scene__table" style="left:<?php echo esc_attr($t[0]); ?>;bottom:<?php echo esc_attr($t[1]); ?>;">
      <div class="ep-scene__table-cloth">
        <div class="ep-scene__table-top"></div>
      </div>
      <div class="ep-scene__table-leg"></div>
      <div class="ep-scene__table-base"></div>
    </div>
    <div class="ep-scene__centrepiece" style="left:calc(<?php echo esc_attr($t[0]); ?> + 2%);bottom:calc(<?php echo esc_attr($t[1]); ?> + 4%);">
      <div class="ep-scene__cp-vase"></div>
      <div class="ep-scene__cp-flowers"></div>
    </div>
    <div class="ep-scene__chair" style="left:calc(<?php echo esc_attr($t[0]); ?> + 6%);bottom:<?php echo esc_attr($t[1]); ?>;">
      <div class="ep-scene__chair-back"></div>
      <div class="ep-scene__chair-seat"></div>
    </div>
    <?php endforeach; ?>
  </div>

  <div class="ep-hero__content">
    <div class="ep-hero__script">Prestige Events</div>
    <p class="ep-hero__sub">Luxury Event Planning &amp; Management</p>
    <p class="ep-hero__tag">London &amp; Worldwide · Weddings · Corporate · Private</p>
    <div class="ep-hero__actions">
      <a href="#services" class="ep-btn ep-btn--champ">Explore Our Services</a>
      <a href="#booking"  class="ep-btn ep-btn--ghost">Begin Your Event</a>
    </div>
  </div>
</section>

<!-- TRUST BAR -->
<div class="ep-trust" aria-label="Trust indicators">
  <div class="ep-trust__inner">
    <span class="ep-trust__item">800+ Events Delivered</span>
    <span class="ep-trust__item">15 Years of Excellence</span>
    <span class="ep-trust__item">Preferred Venue Partner</span>
    <span class="ep-trust__item">4.9★ Google Rating</span>
    <span class="ep-trust__item">Destination Worldwide</span>
  </div>
</div>

<!-- SERVICES -->
<section id="services" class="ep-sec">
  <div class="ep-wrap">
    <div class="ep-center">
      <span class="ep-eyebrow">What We Do</span>
      <h2 class="ep-h2"><strong>Events</strong> That Become Memories</h2>
      <p class="ep-lead">From intimate gatherings to grand galas — we plan, produce, and perfect every experience we touch.</p>
    </div>
    <div class="ep-services__grid">
      <?php foreach ( $services as $i => $svc ) : ?>
      <div class="ep-service ep-reveal" style="transition-delay:<?php echo esc_attr( $i * 80 ); ?>ms;">
        <span class="ep-service__icon" aria-hidden="true"><?php echo $svc['icon']; ?></span>
        <h3 class="ep-service__title"><?php echo esc_html( $svc['title'] ); ?></h3>
        <p class="ep-service__desc"><?php echo esc_html( $svc['desc'] ); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- GALLERY -->
<section id="events" class="ep-sec ep-sec--alt" style="padding-bottom: 0;">
  <div class="ep-wrap">
    <div class="ep-center">
      <span class="ep-eyebrow">Portfolio</span>
      <h2 class="ep-h2">Events We've Had the Honour of Creating</h2>
    </div>
  </div>
  <div style="padding: 40px 0 0; max-width:1400px; margin:0 auto; padding-left:24px; padding-right:24px;">
    <div class="ep-gallery__grid ep-reveal">
      <?php foreach ( $gallery_items as $gi ) : ?>
      <div class="ep-gallery__item">
        <div class="ep-gallery__panel" style="background:<?php echo esc_attr($gi[0]); ?>;"></div>
        <div class="ep-gallery__label"><?php echo esc_html($gi[1]); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- COUNTERS -->
<section class="ep-sec--dark2" style="padding:0;" aria-label="Stats">
  <div class="ep-counters__grid">
    <div class="ep-counter ep-reveal">
      <span class="ep-counter__num" data-target="15" data-suffix="yrs">0</span>
      <span class="ep-counter__label">Years Planning</span>
    </div>
    <div class="ep-counter ep-reveal" style="transition-delay:100ms;">
      <span class="ep-counter__num" data-target="800" data-suffix="+">0</span>
      <span class="ep-counter__label">Events Delivered</span>
    </div>
    <div class="ep-counter ep-reveal" style="transition-delay:200ms;">
      <span class="ep-counter__num" data-target="4.9" data-suffix="★" data-float="1">0</span>
      <span class="ep-counter__label">Average Rating</span>
    </div>
    <div class="ep-counter ep-reveal" style="transition-delay:300ms;">
      <span class="ep-counter__num" data-target="24" data-suffix="+">0</span>
      <span class="ep-counter__label">Countries Worked In</span>
    </div>
  </div>
</section>

<!-- PROCESS -->
<section id="process" class="ep-sec ep-sec--dark">
  <div class="ep-wrap">
    <div class="ep-center">
      <span class="ep-eyebrow">Our Process</span>
      <h2 class="ep-h2" style="color:var(--ep-white);">How We Bring <strong>Your Vision</strong> to Life</h2>
      <p class="ep-lead">Six stages. Zero compromises. One unforgettable event.</p>
    </div>
    <div class="ep-process__grid" style="margin-top:52px;">
      <?php foreach ( $steps as $i => $s ) : ?>
      <div class="ep-step ep-reveal" style="transition-delay:<?php echo esc_attr($i * 80); ?>ms;">
        <span class="ep-step__num"><?php echo esc_html($s['num']); ?></span>
        <h3 class="ep-step__title"><?php echo esc_html($s['title']); ?></h3>
        <p class="ep-step__desc"><?php echo esc_html($s['desc']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- PACKAGES -->
<section id="packages" class="ep-sec">
  <div class="ep-wrap">
    <div class="ep-center">
      <span class="ep-eyebrow">Investment</span>
      <h2 class="ep-h2">Planning Services &amp; <strong>Packages</strong></h2>
      <p class="ep-lead">Our fees reflect the depth of expertise and personal attention you receive. All packages include a complimentary discovery call.</p>
    </div>
    <div class="ep-packages__grid">
      <?php foreach ( $packages as $pkg ) : ?>
      <div class="ep-package <?php echo $pkg['featured'] ? 'ep-package--featured' : ''; ?> ep-reveal">
        <?php if ( $pkg['featured'] ) : ?>
          <div class="ep-package__badge">Most Popular</div>
        <?php endif; ?>
        <div class="ep-package__name"><?php echo esc_html( $pkg['name'] ); ?></div>
        <div class="ep-package__price"><?php echo esc_html( $pkg['price'] ); ?></div>
        <div class="ep-package__period"><?php echo esc_html( $pkg['period'] ); ?></div>
        <div class="ep-package__divider"></div>
        <ul class="ep-package__features">
          <?php foreach ( $pkg['features'] as $feat ) : ?>
          <li><?php echo esc_html( $feat ); ?></li>
          <?php endforeach; ?>
        </ul>
        <?php if ( $pkg['featured'] ) : ?>
          <a href="#booking" class="ep-package__cta ep-package__cta--champ">Begin Planning</a>
        <?php else : ?>
          <a href="#booking" class="ep-package__cta ep-package__cta--outline">Enquire</a>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section id="testimonials" class="ep-sec ep-sec--dark2">
  <div class="ep-wrap">
    <div class="ep-center">
      <span class="ep-eyebrow">Client Stories</span>
      <h2 class="ep-h2" style="color:var(--ep-white);">What Clients Remember</h2>
      <p class="ep-lead">The greatest measure of our work is the stories people tell afterwards.</p>
    </div>
    <div class="ep-testimonials__grid">
      <?php foreach ( $testimonials as $t ) : ?>
      <div class="ep-testimonial ep-reveal">
        <div class="ep-testimonial__stars">
          <?php for ($s = 0; $s < $t['stars']; $s++) echo '<span>★</span>'; ?>
        </div>
        <blockquote class="ep-testimonial__quote">
          <?php echo esc_html( $t['quote'] ); ?>
        </blockquote>
        <div class="ep-testimonial__name"><?php echo esc_html( $t['name'] ); ?></div>
        <div class="ep-testimonial__event"><?php echo esc_html( $t['event'] ); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- BOOKING FORM -->
<section id="booking" class="ep-sec ep-booking">
  <div class="ep-wrap">
    <div class="ep-booking__grid">
      <div class="ep-booking__info">
        <span class="ep-eyebrow">Get in Touch</span>
        <h3>Let's Create Something Extraordinary</h3>
        <p>Complete the form and we'll be in touch within one business day for a complimentary discovery call. We work with a select number of clients each year to ensure every event receives our full focus and passion.</p>
        <ul class="ep-booking__promise">
          <li>Complimentary 45-minute discovery call</li>
          <li>Honest, transparent pricing from day one</li>
          <li>Full venue access and supplier network</li>
          <li>Dedicated planner for your event</li>
          <li>Available for destination events worldwide</li>
        </ul>
        <div class="ep-booking__contact">
          📞 <?php echo esc_html( $phone ); ?><br>
          ✉️ <?php echo esc_html( $email ); ?><br>
          📍 <?php echo esc_html( $addr ); ?>
        </div>
      </div>

      <div class="ep-form">
        <form method="post" action="" novalidate>
          <?php wp_nonce_field( 'tf_ep_booking', 'tf_ep_nonce' ); ?>

          <div class="ep-form__row">
            <div class="ep-form__group">
              <label for="ep_name">Your Name</label>
              <input type="text" id="ep_name" name="ep_name" placeholder="Victoria Henderson" required>
            </div>
            <div class="ep-form__group">
              <label for="ep_company">Company (if corporate)</label>
              <input type="text" id="ep_company" name="ep_company" placeholder="Henderson Capital Partners">
            </div>
          </div>

          <div class="ep-form__row">
            <div class="ep-form__group">
              <label for="ep_email">Email Address</label>
              <input type="email" id="ep_email" name="ep_email" placeholder="you@email.com" required>
            </div>
            <div class="ep-form__group">
              <label for="ep_phone">Phone Number</label>
              <input type="tel" id="ep_phone" name="ep_phone" placeholder="+44 7700 000000">
            </div>
          </div>

          <div class="ep-form__row">
            <div class="ep-form__group">
              <label for="ep_type">Event Type</label>
              <select id="ep_type" name="ep_type">
                <option value="">Select event type…</option>
                <option value="wedding">Wedding</option>
                <option value="corporate">Corporate Event</option>
                <option value="birthday">Milestone Birthday</option>
                <option value="private">Private Party</option>
                <option value="charity">Charity Gala</option>
                <option value="destination">Destination Event</option>
              </select>
            </div>
            <div class="ep-form__group">
              <label for="ep_date">Approximate Event Date</label>
              <input type="date" id="ep_date" name="ep_date">
            </div>
          </div>

          <div class="ep-form__row">
            <div class="ep-form__group">
              <label for="ep_guests">Approximate Guest Count</label>
              <select id="ep_guests" name="ep_guests">
                <option value="">Select range…</option>
                <option value="u30">Under 30</option>
                <option value="30-60">30–60</option>
                <option value="60-150">60–150</option>
                <option value="150-300">150–300</option>
                <option value="300+">300+</option>
              </select>
            </div>
            <div class="ep-form__group">
              <label for="ep_budget">Approximate Budget</label>
              <select id="ep_budget" name="ep_budget">
                <option value="">Select range…</option>
                <option value="u10">Under £10,000</option>
                <option value="10-25">£10,000–£25,000</option>
                <option value="25-50">£25,000–£50,000</option>
                <option value="50-100">£50,000–£100,000</option>
                <option value="100+">£100,000+</option>
              </select>
            </div>
          </div>

          <div class="ep-form__group">
            <label for="ep_vision">Tell us about your vision</label>
            <textarea id="ep_vision" name="ep_vision" placeholder="Share the feeling, the theme, the must-haves — the more detail the better…"></textarea>
          </div>

          <button type="submit" name="tf_ep_submit" class="ep-form__submit">
            Send My Enquiry ✦
          </button>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- FOOTER -->
<footer class="ep-footer" role="contentinfo">
  <div class="ep-footer__inner">
    <div class="ep-footer__logo">Prestige Events</div>
    <p class="ep-footer__copy">&copy; <?php echo esc_html( date('Y') ); ?> <?php bloginfo('name'); ?>. Luxury Event Planning, London. All rights reserved.</p>
    <nav class="ep-footer__links" aria-label="Footer navigation">
      <a href="#">Privacy</a>
      <a href="#">Gift Vouchers</a>
      <a href="#booking">Contact</a>
    </nav>
  </div>
</footer>

<script>
(function () {
  'use strict';
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  function animateCounter(el) {
    const target  = parseFloat(el.dataset.target);
    const suffix  = el.dataset.suffix  || '';
    const isFloat = el.dataset.float   === '1';
    if (isNaN(target)) return;
    const dur = 1800; let start = null;
    (function tick(ts) {
      if (!start) start = ts;
      const p = Math.min((ts - start) / dur, 1);
      const v = easeOut(p) * target;
      el.textContent = isFloat ? v.toFixed(1) + suffix : Math.round(v) + suffix;
      if (p < 1) requestAnimationFrame(tick);
    })(performance.now());
  }
  const io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (!e.isIntersecting) return;
      e.target.classList.add('is-visible');
      e.target.querySelectorAll('[data-target]').forEach(animateCounter);
      if (e.target.dataset && e.target.dataset.target) animateCounter(e.target);
      io.unobserve(e.target);
    });
  }, { threshold: 0.15 });
  document.querySelectorAll('.ep-reveal, .ep-counter__num[data-target]')
    .forEach(function (el) { io.observe(el); });
  document.querySelectorAll('a[href^="#"]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      const t = document.querySelector(this.getAttribute('href'));
      if (!t) return;
      e.preventDefault();
      window.scrollTo({ top: t.getBoundingClientRect().top + window.pageYOffset - 80, behavior: 'smooth' });
    });
  });
  const nav = document.querySelector('.ep-nav');
  window.addEventListener('scroll', function () {
    nav.style.boxShadow = window.scrollY > 40 ? '0 4px 28px rgba(0,0,0,.35)' : 'none';
  }, { passive: true });
})();
</script>

</body>
</html>
</div><!-- .ep-page -->
<?php get_footer(); ?>
