<?php
/**
 * Template Name: Event & Wedding Venue Homepage
 *
 * Premium Event/Wedding Venue page template for ThemeFlex.
 * Namespace: --evt-*
 * Fonts: Great Vibes (display) + Raleway (headings) + Lora (body)
 * Palette: ivory #faf8f3, champagne #e8d5a3, blush #e8c5c0, deep plum #3d1f3a, gold #c8a43c
 */

/* ─── PHP DATA ───────────────────────────────────────────────────── */

$evt_spaces = [
    ['name'=>'Der Große Ballsaal','cap'=>300,'size'=>600,'desc'=>'Imposanter Hauptsaal mit 7m-Decken, Kronleuchtern und eigenem Catering-Bereich — die perfekte Bühne für unvergessliche Hochzeiten.','features'=>['300 Gäste','Bühne','Galerie','Außenteich'],'color'=>'#3d1f3a'],
    ['name'=>'Die Orangerie','cap'=>120,'size'=>220,'desc'=>'Lichtdurchfluteter Wintergarten mit Blick in den Schlossgarten — perfekt für Standesamtsfeiern und kleine Hochzeiten.','features'=>['120 Gäste','Natürliches Licht','Gartenblick','Pergola'],'color'=>'#c8a43c'],
    ['name'=>'Der Kaminraum','cap'=>40,'size'=>85,'desc'=>'Gemütlicher Salon mit antikem Kamin und Stuck-Decken für private Dinner, Verlobungsfeiern und exklusive Tagungen.','features'=>['40 Gäste','Kamin','Privatbar','Stuck-Decken'],'color'=>'#e8c5c0'],
    ['name'=>'Die Schlossterrasse','cap'=>250,'size'=>450,'desc'=>'Weitläufige Außenterrasse mit Pavillon und Seeblick — für Sommerpartys, Firmenevents und Empfänge unter freiem Himmel.','features'=>['250 Gäste','Pavillon','Seeblick','Barbereich'],'color'=>'#3d1f3a'],
];

$evt_packages = [
    ['name'=>'Ivory','tag'=>'Einstieg','desc'=>'Das ideale Paket für kleinere Feierlichkeiten mit persönlichem Charme.','price'=>'ab 2.800 €','includes'=>['Raum 4h','Grundaustattung','Standardbestuhlung','Koordinatorin'],'popular'=>false],
    ['name'=>'Champagne','tag'=>'Beliebt','desc'=>'Unser meistgebuchtes Paket — für unvergessliche Hochzeiten und Jubiläen.','price'=>'ab 5.900 €','includes'=>['Raum 8h','Blumendekoration','Premium-Bestuhlung','Koordinatorin','Welcome Drink','Menüberatung'],'popular'=>true],
    ['name'=>'Royal','tag'=>'Premium','desc'=>'Das vollständige Luxuspaket ohne Kompromisse — für die schönste Feier Ihres Lebens.','price'=>'ab 11.500 €','includes'=>['Raum 12h','Full Floristry','Exklusives Setup','Hochzeitsplaner','Open Bar','Fotograf 8h','Kutschfahrt'],'popular'=>false],
];

$evt_testimonials = [
    ['couple'=>'Jana & Markus','date'=>'Juni 2024','text'=>'Der Ballsaal war wie aus einem Märchen. Jedes Detail hat gestimmt — wir hätten uns keinen besseren Tag vorstellen können.'],
    ['couple'=>'Sophie & David','date'=>'September 2024','text'=>'Von der ersten Besichtigung bis zum letzten Tanz hat das Team alles perfekt koordiniert. Unsere Gäste schwärmen noch heute davon!'],
    ['couple'=>'Laura & Tim','date'=>'Mai 2024','text'=>'Die Orangerie im Morgenlicht — atemberaubend. Das Catering war köstlich, die Atmosphäre einmalig. 100% weiterempfehlen!'],
];

$evt_gallery_items = [
    ['label'=>'Ballsaal Abend','col'=>2,'row'=>2,'bg'=>'linear-gradient(135deg,#3d1f3a,#5a2e58)'],
    ['label'=>'Tischdeko','col'=>1,'row'=>1,'bg'=>'linear-gradient(135deg,#c8a43c,#a88030)'],
    ['label'=>'Orangerie','col'=>1,'row'=>1,'bg'=>'linear-gradient(135deg,#e8d5a3,#d4b878)'],
    ['label'=>'Brautpaar','col'=>1,'row'=>2,'bg'=>'linear-gradient(135deg,#e8c5c0,#d4a09a)'],
    ['label'=>'Gartenfeier','col'=>2,'row'=>1,'bg'=>'linear-gradient(135deg,#2d4a2a,#3d6038)'],
];

$evt_catering = [
    ['name'=>'Sektempfang & Canapés','desc'=>'Stehempfang mit hauseigenen Canteès und Prosecco — der perfekte Auftakt.'],
    ['name'=>'Gourmet-Menü','desc'=>'Mehrgängiges Dinner mit saisonalen, regionalen Produkten — kreiert von unserem Chefkoch.'],
    ['name'=>'Buffet & Live-Cooking','desc'=>'Interaktives Buffeterlebnis mit Live-Stationen für lockere Atmosphäre.'],
    ['name'=>'Hochzeitstorte','desc'=>'Handgefertigte Torte nach Ihren Wünschen — von unserem hauseigenen Konditor.'],
];

// CSS art
srand(99);
$evt_roses = [];
for($i=0;$i<20;$i++){
    $evt_roses[] = ['x'=>rand(3,97),'y'=>rand(10,90),'s'=>rand(6,14),'o'=>(rand(1,5)/10),'d'=>rand(5,12)];
}
$evt_candles = [];
for($i=0;$i<8;$i++){
    $evt_candles[] = ['x'=>(6 + $i*12.5),'h'=>rand(40,80),'d'=>round($i * 0.3, 1)];
}

?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Raleway:wght@300;400;500;600;700&family=Lora:ital,wght@0,400;0,500;1,400&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════
   EVENT VENUE — CSS CUSTOM PROPERTIES
═══════════════════════════════════════════ */
:root{
  --evt-ivory:#faf8f3;
  --evt-cream:#f2ede2;
  --evt-champagne:#e8d5a3;
  --evt-blush:#e8c5c0;
  --evt-plum:#3d1f3a;
  --evt-plum2:#2d1228;
  --evt-gold:#c8a43c;
  --evt-gold2:#a88030;
  --evt-rose:#b8606c;
  --evt-slate:#6b5e6a;
  --evt-ff-script:'Great Vibes',cursive;
  --evt-ff-head:'Raleway',system-ui,sans-serif;
  --evt-ff-body:'Lora',Georgia,serif;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
.evt-wrap{font-family:var(--evt-ff-body);color:var(--evt-plum);background:var(--evt-ivory);line-height:1.6;overflow-x:hidden}
.evt-wrap *{box-sizing:border-box}
a{color:inherit;text-decoration:none}

/* ─── UTILS ─── */
.evt-container{max-width:1160px;margin:0 auto;padding:0 32px}
.evt-eyebrow{font-family:var(--evt-ff-head);font-size:.68rem;font-weight:700;letter-spacing:.28em;text-transform:uppercase;color:var(--evt-gold);margin-bottom:10px}
.evt-script{font-family:var(--evt-ff-script);font-size:clamp(2.2rem,4.5vw,3.5rem);color:var(--evt-gold);display:block;margin-bottom:4px;line-height:1.2}
.evt-h2{font-family:var(--evt-ff-head);font-size:clamp(1.8rem,3.5vw,2.8rem);font-weight:300;line-height:1.2;color:var(--evt-plum)}
.evt-h2 strong{font-weight:700}
.evt-divider{display:flex;align-items:center;gap:12px;margin:18px 0}
.evt-divider::before,.evt-divider::after{content:'';flex:1;height:1px;background:var(--evt-champagne)}
.evt-divider-icon{color:var(--evt-gold);font-size:.8rem}
.evt-btn{display:inline-block;padding:14px 34px;border-radius:50px;font-family:var(--evt-ff-head);font-size:.78rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;cursor:pointer;transition:all .25s;border:none}
.evt-btn-plum{background:var(--evt-plum);color:var(--evt-ivory);box-shadow:0 4px 16px rgba(61,31,58,.2)}
.evt-btn-plum:hover{background:var(--evt-plum2);transform:translateY(-2px);box-shadow:0 8px 24px rgba(61,31,58,.3)}
.evt-btn-gold{background:var(--evt-gold);color:#fff;box-shadow:0 4px 16px rgba(200,164,60,.25)}
.evt-btn-gold:hover{background:var(--evt-gold2);transform:translateY(-2px)}
.evt-btn-outline{background:transparent;color:var(--evt-ivory);border:1px solid rgba(250,248,243,.4)}
.evt-btn-outline:hover{border-color:var(--evt-champagne);color:var(--evt-champagne)}

/* ─── REVEAL ─── */
.evt-reveal{opacity:0;transform:translateY(22px);transition:opacity .7s ease,transform .7s ease}
.evt-reveal.visible{opacity:1;transform:none}

/* ═══════════════════════════════════════════
   NAV
═══════════════════════════════════════════ */
.evt-nav{position:fixed;top:0;left:0;right:0;z-index:200;padding:18px 0;transition:all .35s}
.evt-nav.scrolled{background:rgba(61,31,58,.92);backdrop-filter:blur(12px);box-shadow:0 2px 24px rgba(0,0,0,.2)}
.evt-nav-inner{display:flex;align-items:center;justify-content:space-between}
.evt-logo{font-family:var(--evt-ff-script);font-size:1.8rem;color:var(--evt-ivory)}
.evt-logo span{color:var(--evt-champagne)}
.evt-nav-links{display:flex;gap:32px;list-style:none}
.evt-nav-links a{font-family:var(--evt-ff-head);font-size:.75rem;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:rgba(250,248,243,.65);transition:color .2s}
.evt-nav-links a:hover{color:var(--evt-champagne)}
.evt-nav-cta{font-family:var(--evt-ff-head);font-size:.72rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;padding:10px 22px;background:var(--evt-gold);color:#fff;border-radius:50px;transition:background .2s}
.evt-nav-cta:hover{background:var(--evt-gold2)}

/* ═══════════════════════════════════════════
   HERO — CSS BALLROOM SCENE
═══════════════════════════════════════════ */
.evt-hero{min-height:100vh;background:linear-gradient(180deg,#1a0818 0%,#2d1228 40%,#3d1f3a 70%,#4a2548 100%);position:relative;display:flex;align-items:center;overflow:hidden}
/* Falling rose petals */
.evt-petal{position:absolute;border-radius:50% 0 50% 0;animation:evt-petal-fall linear infinite}
@keyframes evt-petal-fall{0%{transform:translateY(-10vh) rotate(0deg);opacity:.8}100%{transform:translateY(110vh) rotate(360deg);opacity:0}}
/* Gold dust shimmer */
.evt-hero::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse at 50% 30%,rgba(200,164,60,.08) 0%,transparent 60%);pointer-events:none}
/* Ballroom floor */
.evt-ballroom-floor{position:absolute;bottom:0;left:0;right:0;height:28%;background:linear-gradient(180deg,#1a0818 0%,#0e0410 100%)}
.evt-ballroom-floor::before{content:'';position:absolute;inset:0;background-image:repeating-linear-gradient(45deg,rgba(200,164,60,.04) 0px,rgba(200,164,60,.04) 1px,transparent 1px,transparent 28px),repeating-linear-gradient(-45deg,rgba(200,164,60,.04) 0px,rgba(200,164,60,.04) 1px,transparent 1px,transparent 28px)}
/* Stage area */
.evt-stage{position:absolute;bottom:28%;left:50%;transform:translateX(-50%);width:340px;height:8px;background:linear-gradient(90deg,transparent,rgba(200,164,60,.2),rgba(200,164,60,.4),rgba(200,164,60,.2),transparent)}
/* Candles */
.evt-candle{position:absolute;bottom:28%;display:flex;flex-direction:column;align-items:center}
.evt-candle-body{width:8px;border-radius:2px;background:linear-gradient(180deg,#f0e8d0,#ddd0b0)}
.evt-candle-flame{width:6px;height:10px;background:linear-gradient(180deg,rgba(255,220,80,.9),rgba(255,140,20,.7));border-radius:50% 50% 30% 30%;animation:evt-flame-flicker 1.5s ease-in-out infinite alternate}
.evt-candle-glow{position:absolute;top:0;left:50%;transform:translateX(-50%);width:40px;height:40px;border-radius:50%;background:radial-gradient(circle,rgba(255,200,60,.18) 0%,transparent 70%);animation:evt-glow-pulse 2s ease-in-out infinite alternate}
@keyframes evt-flame-flicker{0%{transform:scaleX(1) scaleY(1);opacity:.9}50%{transform:scaleX(.8) scaleY(1.1)}100%{transform:scaleX(1.1) scaleY(.9);opacity:.7}}
@keyframes evt-glow-pulse{0%{opacity:.6;transform:translateX(-50%) scale(.8)}100%{opacity:1;transform:translateX(-50%) scale(1.2)}}
/* Grand chandelier */
.evt-chandelier{position:absolute;top:0;left:50%;transform:translateX(-50%)}
.evt-ch-chain{width:3px;height:50px;background:linear-gradient(180deg,rgba(200,164,60,.4),rgba(200,164,60,.6));margin:0 auto}
.evt-ch-ring{width:120px;height:16px;border:3px solid rgba(200,164,60,.5);border-radius:50%;margin:0 auto;position:relative}
.evt-ch-ring::before{content:'';position:absolute;top:-3px;left:50%;transform:translateX(-50%);width:60px;height:16px;border:2px solid rgba(200,164,60,.35);border-radius:50%}
.evt-ch-arms-wrap{display:flex;justify-content:center;gap:0;position:relative;width:200px;margin:0 auto}
.evt-ch-arm{width:2px;height:32px;background:rgba(200,164,60,.4);position:relative}
.evt-ch-crystal{position:absolute;bottom:-10px;left:50%;transform:translateX(-50%);width:5px;height:10px;background:rgba(200,164,60,.5);clip-path:polygon(50% 0%,100% 50%,50% 100%,0% 50%)}
.evt-ch-glow{position:absolute;top:100%;left:50%;transform:translate(-50%,0);width:280px;height:180px;background:radial-gradient(ellipse,rgba(200,164,60,.12) 0%,transparent 70%);pointer-events:none}
/* Floral arches */
.evt-arch{position:absolute;border-style:solid;border-color:transparent;border-bottom-color:rgba(200,164,60,.08);border-radius:0;bottom:28%}
.evt-arch-1{width:500px;height:250px;border-width:0 0 250px 250px;left:50%;transform:translateX(-50%)}
/* Hero text */
.evt-hero-inner{position:relative;z-index:10;text-align:center;width:100%;padding:140px 0 120px}
.evt-hero-content{max-width:680px;margin:0 auto}
.evt-hero-script{font-family:var(--evt-ff-script);font-size:clamp(3rem,7vw,6rem);color:var(--evt-champagne);display:block;margin-bottom:4px;text-shadow:0 2px 20px rgba(200,164,60,.3)}
.evt-hero-h1{font-family:var(--evt-ff-head);font-size:clamp(1.6rem,3vw,2.2rem);font-weight:300;letter-spacing:.2em;text-transform:uppercase;color:rgba(250,248,243,.8);margin-bottom:24px}
.evt-hero-tagline{font-family:var(--evt-ff-body);font-style:italic;font-size:1.1rem;color:rgba(250,248,243,.55);margin-bottom:36px;line-height:1.7}
.evt-hero-btns{display:flex;gap:16px;justify-content:center;flex-wrap:wrap;margin-bottom:48px}
/* Floating features row */
.evt-hero-features{display:flex;gap:32px;justify-content:center;flex-wrap:wrap;border-top:1px solid rgba(200,164,60,.2);padding-top:32px}
.evt-hero-feat{display:flex;flex-direction:column;align-items:center;gap:4px}
.evt-hero-feat span:first-child{font-family:var(--evt-ff-head);font-size:1.2rem;font-weight:700;color:var(--evt-champagne)}
.evt-hero-feat span:last-child{font-family:var(--evt-ff-head);font-size:.68rem;font-weight:600;letter-spacing:.16em;text-transform:uppercase;color:rgba(250,248,243,.4)}

/* ═══════════════════════════════════════════
   INTRO / ABOUT
═══════════════════════════════════════════ */
.evt-about{padding:100px 0;background:var(--evt-ivory)}
.evt-about-grid{display:grid;grid-template-columns:1fr 1fr;gap:80px;align-items:center}
/* CSS ballroom interior mini-art */
.evt-art-frame{width:100%;aspect-ratio:4/3;background:linear-gradient(135deg,var(--evt-plum2) 0%,var(--evt-plum) 100%);border-radius:4px;position:relative;overflow:hidden}
.evt-art-floor{position:absolute;bottom:0;left:0;right:0;height:30%;background:linear-gradient(180deg,#1a0818,#0e0410)}
.evt-art-floor::before{content:'';position:absolute;inset:0;background-image:repeating-linear-gradient(45deg,rgba(200,164,60,.05) 0px,rgba(200,164,60,.05) 1px,transparent 1px,transparent 20px)}
.evt-art-table{position:absolute;bottom:30%;left:50%;transform:translateX(-50%);width:100px;height:12px;background:linear-gradient(180deg,#f5e8c0,#e0d090);border-radius:2px}
.evt-art-cloth{position:absolute;bottom:30%;left:50%;transform:translateX(-50%);width:120px;height:6px;background:rgba(232,197,192,.5);top:auto;border-radius:50%;margin-top:6px}
/* Table items */
.evt-art-candle-s{position:absolute;bottom:calc(30% + 12px);display:flex;flex-direction:column;align-items:center}
.evt-art-rose{position:absolute;border-radius:50%;background:radial-gradient(circle,rgba(184,96,108,.8),rgba(164,70,80,.5))}
/* Curtains */
.evt-art-curtain{position:absolute;top:0;width:18%;height:100%;background:linear-gradient(90deg,rgba(61,31,58,.7),transparent)}
.evt-art-curtain-r{right:0;background:linear-gradient(90deg,transparent,rgba(61,31,58,.7))}
/* Flower arch at top */
.evt-art-arch-top{position:absolute;top:0;left:50%;transform:translateX(-50%);width:140px;height:60px;border:3px solid rgba(200,164,60,.2);border-bottom:none;border-radius:70px 70px 0 0}
/* About badge */
.evt-about-badge{position:absolute;bottom:-20px;right:-20px;width:96px;height:96px;border-radius:50%;background:var(--evt-gold);display:flex;flex-direction:column;align-items:center;justify-content:center;box-shadow:0 8px 32px rgba(200,164,60,.3)}
.evt-ab-n{font-family:var(--evt-ff-head);font-size:1.9rem;font-weight:700;color:#fff;line-height:1}
.evt-ab-t{font-family:var(--evt-ff-head);font-size:.58rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.85);text-align:center}

/* ═══════════════════════════════════════════
   SPACES
═══════════════════════════════════════════ */
.evt-spaces{padding:100px 0;background:var(--evt-cream)}
.evt-spaces-header{text-align:center;margin-bottom:56px}
.evt-spaces-header .evt-divider{justify-content:center}
.evt-spaces-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:24px}
.evt-space-card{background:var(--evt-ivory);border-radius:2px;overflow:hidden;box-shadow:0 4px 24px rgba(61,31,58,.06);transition:box-shadow .3s,transform .25s}
.evt-space-card:hover{box-shadow:0 12px 40px rgba(61,31,58,.12);transform:translateY(-3px)}
/* CSS space illustration */
.evt-space-art{height:180px;position:relative;overflow:hidden}
.evt-space-art-bg{position:absolute;inset:0}
.evt-space-art-floor2{position:absolute;bottom:0;left:0;right:0;height:30%;background:rgba(0,0,0,.25)}
.evt-space-art-chairs{position:absolute;bottom:30%;display:flex;gap:4px}
.evt-chair-small{width:10px;height:12px;border-radius:2px 2px 0 0}
.evt-space-art-table2{position:absolute;bottom:30%;left:50%;transform:translateX(-50%);height:6px;background:rgba(255,255,255,.3);border-radius:1px}
.evt-space-tag{position:absolute;top:14px;left:14px;font-family:var(--evt-ff-head);font-size:.65rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;padding:4px 12px;background:var(--evt-gold);color:#fff;border-radius:50px}
.evt-space-body{padding:22px 22px}
.evt-space-name{font-family:var(--evt-ff-head);font-size:1.2rem;font-weight:600;margin-bottom:8px}
.evt-space-cap{font-family:var(--evt-ff-head);font-size:.75rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--evt-gold);margin-bottom:12px}
.evt-space-desc{font-size:.88rem;color:var(--evt-slate);line-height:1.65;margin-bottom:16px}
.evt-space-features{display:flex;gap:8px;flex-wrap:wrap}
.evt-space-feat{font-size:.72rem;font-weight:600;letter-spacing:.08em;text-transform:uppercase;padding:3px 10px;border-radius:50px;background:var(--evt-cream);color:var(--evt-slate)}

/* ═══════════════════════════════════════════
   GALLERY (CSS mosaic)
═══════════════════════════════════════════ */
.evt-gallery{padding:100px 0;background:var(--evt-plum);color:var(--evt-ivory)}
.evt-gallery-header{text-align:center;margin-bottom:48px}
.evt-gallery-header .evt-script{color:var(--evt-champagne)}
.evt-gallery-header .evt-divider::before,.evt-gallery-header .evt-divider::after{background:rgba(232,213,163,.2)}
.evt-mosaic{display:grid;grid-template-columns:repeat(4,1fr);grid-template-rows:repeat(3,120px);gap:6px}
.evt-mosaic-tile{position:relative;overflow:hidden;border-radius:2px;display:flex;align-items:center;justify-content:center;font-family:var(--evt-ff-head);font-size:.75rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:rgba(255,255,255,.6);transition:transform .3s}
.evt-mosaic-tile:hover{transform:scale(1.02);z-index:2}
.evt-mosaic-tile::after{content:attr(data-label);position:absolute;bottom:10px;left:10px;font-size:.65rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.5)}

/* ═══════════════════════════════════════════
   PACKAGES
═══════════════════════════════════════════ */
.evt-packages{padding:100px 0;background:var(--evt-ivory)}
.evt-packages-header{text-align:center;margin-bottom:56px}
.evt-packages-header .evt-divider{justify-content:center}
.evt-packages-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}
.evt-pkg{background:var(--evt-cream);border-radius:2px;padding:40px 30px;border:1px solid rgba(232,213,163,.4);transition:border-color .25s,box-shadow .25s;position:relative}
.evt-pkg.popular{background:var(--evt-plum);color:var(--evt-ivory);border-color:var(--evt-plum)}
.evt-pkg-badge{position:absolute;top:-1px;right:24px;background:var(--evt-gold);color:#fff;font-family:var(--evt-ff-head);font-size:.65rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;padding:5px 14px;border-radius:0 0 6px 6px}
.evt-pkg-name{font-family:var(--evt-ff-script);font-size:2.2rem;margin-bottom:4px;color:var(--evt-gold);display:block}
.evt-pkg-tag{font-family:var(--evt-ff-head);font-size:.68rem;font-weight:700;letter-spacing:.2em;text-transform:uppercase;margin-bottom:14px;opacity:.6}
.evt-pkg.popular .evt-pkg-tag{color:rgba(250,248,243,.6)}
.evt-pkg-price{font-family:var(--evt-ff-head);font-size:1.6rem;font-weight:700;margin-bottom:6px;color:var(--evt-plum)}
.evt-pkg.popular .evt-pkg-price{color:var(--evt-champagne)}
.evt-pkg-desc{font-size:.88rem;line-height:1.65;margin-bottom:20px;border-bottom:1px solid rgba(61,31,58,.1);padding-bottom:20px}
.evt-pkg.popular .evt-pkg-desc{border-color:rgba(250,248,243,.1);color:rgba(250,248,243,.7)}
.evt-pkg-includes{list-style:none;margin-bottom:28px}
.evt-pkg-includes li{font-size:.87rem;padding:7px 0;display:flex;align-items:center;gap:10px;border-bottom:1px solid rgba(61,31,58,.06)}
.evt-pkg.popular .evt-pkg-includes li{border-color:rgba(250,248,243,.06);color:rgba(250,248,243,.85)}
.evt-pkg-includes li::before{content:'♦';color:var(--evt-gold);font-size:.55rem;flex-shrink:0}
.evt-pkg-btn{width:100%;padding:13px;border:none;border-radius:50px;font-family:var(--evt-ff-head);font-size:.78rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;cursor:pointer;transition:all .22s}
.evt-pkg:not(.popular) .evt-pkg-btn{background:var(--evt-plum);color:var(--evt-ivory)}
.evt-pkg:not(.popular) .evt-pkg-btn:hover{background:var(--evt-plum2)}
.evt-pkg.popular .evt-pkg-btn{background:var(--evt-gold);color:#fff}
.evt-pkg.popular .evt-pkg-btn:hover{background:var(--evt-gold2)}

/* ═══════════════════════════════════════════
   CATERING
═══════════════════════════════════════════ */
.evt-catering{padding:80px 0;background:var(--evt-cream)}
.evt-catering-grid{display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:center}
.evt-catering-items{display:flex;flex-direction:column;gap:20px}
.evt-catering-item{display:flex;gap:16px;padding:20px;background:var(--evt-ivory);border-radius:2px;border-left:3px solid var(--evt-gold);transition:box-shadow .25s}
.evt-catering-item:hover{box-shadow:0 4px 20px rgba(61,31,58,.08)}
.evt-catering-icon{font-size:1.3rem;flex-shrink:0;width:36px}
.evt-catering-name{font-family:var(--evt-ff-head);font-size:.95rem;font-weight:700;margin-bottom:4px}
.evt-catering-desc{font-size:.87rem;color:var(--evt-slate);line-height:1.6}

/* ═══════════════════════════════════════════
   TESTIMONIALS
═══════════════════════════════════════════ */
.evt-testimonials{padding:100px 0;background:var(--evt-ivory)}
.evt-testimonials-header{text-align:center;margin-bottom:56px}
.evt-testimonials-header .evt-divider{justify-content:center}
.evt-testi-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}
.evt-testi-card{background:var(--evt-cream);border-radius:2px;padding:32px 28px;border:1px solid rgba(232,213,163,.4);position:relative}
.evt-testi-card::before{content:'\201C';position:absolute;top:14px;left:20px;font-family:Georgia,serif;font-size:4rem;color:rgba(200,164,60,.2);line-height:1}
.evt-testi-stars{display:flex;gap:3px;margin-bottom:14px}
.evt-testi-stars span{color:var(--evt-gold);font-size:.9rem}
.evt-testi-text{font-family:var(--evt-ff-body);font-style:italic;font-size:.92rem;color:var(--evt-slate);line-height:1.7;margin-bottom:18px}
.evt-testi-couple{font-family:var(--evt-ff-script);font-size:1.4rem;color:var(--evt-plum);display:block;margin-bottom:2px}
.evt-testi-date{font-family:var(--evt-ff-head);font-size:.72rem;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:var(--evt-gold)}

/* ═══════════════════════════════════════════
   STATS
═══════════════════════════════════════════ */
.evt-stats{padding:70px 0;background:var(--evt-plum)}
.evt-stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:2px}
.evt-stat{text-align:center;padding:36px 20px;border-right:1px solid rgba(232,213,163,.1)}
.evt-stat:last-child{border-right:none}
.evt-stat-num{font-family:var(--evt-ff-head);font-size:clamp(2rem,4vw,2.8rem);font-weight:700;color:var(--evt-champagne);display:block;margin-bottom:8px;line-height:1}
.evt-stat-label{font-family:var(--evt-ff-head);font-size:.73rem;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:rgba(232,213,163,.45)}

/* ═══════════════════════════════════════════
   INQUIRY FORM
═══════════════════════════════════════════ */
.evt-inquiry{padding:100px 0;background:var(--evt-cream)}
.evt-inquiry-grid{display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:start}
.evt-inquiry-form{background:var(--evt-ivory);border-radius:2px;padding:48px 40px;box-shadow:0 8px 40px rgba(61,31,58,.08)}
.evt-inquiry-form .evt-eyebrow{margin-bottom:8px}
.evt-inquiry-form .evt-script{font-size:2rem}
.evt-inquiry-form .evt-divider{justify-content:flex-start;margin-bottom:28px}
.evt-form-group{margin-bottom:16px}
.evt-form-group label{display:block;font-family:var(--evt-ff-head);font-size:.68rem;font-weight:700;letter-spacing:.16em;text-transform:uppercase;color:var(--evt-slate);margin-bottom:6px}
.evt-form-group input,.evt-form-group select,.evt-form-group textarea{width:100%;padding:12px 16px;background:var(--evt-cream);border:1px solid rgba(232,213,163,.6);border-radius:2px;color:var(--evt-plum);font-family:var(--evt-ff-body);font-size:.9rem;outline:none;transition:border-color .2s}
.evt-form-group input:focus,.evt-form-group select:focus,.evt-form-group textarea:focus{border-color:var(--evt-gold)}
.evt-form-group textarea{min-height:100px;resize:vertical}
.evt-form-row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.evt-form-submit{width:100%;padding:15px;background:var(--evt-plum);border:none;border-radius:50px;font-family:var(--evt-ff-head);font-size:.8rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--evt-ivory);cursor:pointer;transition:all .25s;box-shadow:0 6px 20px rgba(61,31,58,.2)}
.evt-form-submit:hover{background:var(--evt-plum2);transform:translateY(-2px)}
/* Info panel */
.evt-inquiry-info{}
.evt-ii-block{margin-bottom:32px;padding-bottom:32px;border-bottom:1px solid rgba(232,213,163,.4)}
.evt-ii-block:last-child{border-bottom:none}
.evt-ii-label{font-family:var(--evt-ff-head);font-size:.68rem;font-weight:700;letter-spacing:.2em;text-transform:uppercase;color:var(--evt-gold);margin-bottom:8px}
.evt-ii-value{font-family:var(--evt-ff-head);font-size:1.05rem;font-weight:300;line-height:1.6;color:var(--evt-plum)}
.evt-ii-note{font-size:.83rem;color:var(--evt-slate);margin-top:4px}

/* ═══════════════════════════════════════════
   FINAL CTA
═══════════════════════════════════════════ */
.evt-cta{padding:100px 0;background:linear-gradient(135deg,var(--evt-plum2) 0%,var(--evt-plum) 100%);text-align:center;position:relative;overflow:hidden}
.evt-cta::before{content:'';position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:600px;height:400px;background:radial-gradient(ellipse,rgba(200,164,60,.08) 0%,transparent 70%);pointer-events:none}
.evt-cta .evt-script{font-size:clamp(2.5rem,5vw,4rem);color:var(--evt-champagne)}
.evt-cta .evt-h2{color:rgba(250,248,243,.85);margin-bottom:20px}
.evt-cta p{font-size:1rem;color:rgba(250,248,243,.5);max-width:480px;margin:0 auto 36px;line-height:1.7;font-style:italic}
.evt-cta-btns{display:flex;gap:16px;justify-content:center;flex-wrap:wrap}

/* ═══════════════════════════════════════════
   RESPONSIVE
═══════════════════════════════════════════ */
@media(max-width:1024px){
  .evt-about-grid{grid-template-columns:1fr}
  .evt-spaces-grid{grid-template-columns:1fr}
  .evt-packages-grid{grid-template-columns:1fr}
  .evt-catering-grid{grid-template-columns:1fr}
  .evt-testi-grid{grid-template-columns:1fr 1fr}
  .evt-inquiry-grid{grid-template-columns:1fr}
  .evt-stats-grid{grid-template-columns:repeat(2,1fr)}
  .evt-mosaic{grid-template-columns:repeat(2,1fr);grid-template-rows:repeat(3,140px)}
  .evt-nav-links{display:none}
}
@media(max-width:640px){
  .evt-testi-grid{grid-template-columns:1fr}
  .evt-stats-grid{grid-template-columns:repeat(2,1fr)}
  .evt-form-row{grid-template-columns:1fr}
  .evt-hero-features{gap:20px}
  .evt-mosaic{grid-template-columns:1fr 1fr;grid-template-rows:repeat(3,120px)}
}
</style>
<?php get_header(); ?>
<div class="evt-wrap">

<!-- ═══ NAV ═══════════════════════════════════════════ -->
<nav class="evt-nav" id="evtNav">
  <div class="evt-container">
    <div class="evt-nav-inner">
      <a class="evt-logo" href="<?php echo esc_url(home_url('/')); ?>">
        <?php bloginfo('name'); ?>
      </a>
      <ul class="evt-nav-links">
        <li><a href="#raeume">Räume</a></li>
        <li><a href="#pakete">Pakete</a></li>
        <li><a href="#catering">Catering</a></li>
        <li><a href="#anfrage">Anfrage</a></li>
      </ul>
      <a href="#anfrage" class="evt-nav-cta">Termin anfragen</a>
    </div>
  </div>
</nav>

<!-- ═══ HERO ════════════════════════════════════════════ -->
<section class="evt-hero">
  <!-- Rose petals -->
  <?php foreach ($evt_roses as $i => $r): ?>
    <div class="evt-petal" style="left:<?php echo $r['x']; ?>%;top:-5%;width:<?php echo $r['s']; ?>px;height:<?php echo $r['s']*0.7; ?>px;background:rgba(184,96,108,<?php echo $r['o']; ?>);animation-duration:<?php echo $r['d']; ?>s;animation-delay:<?php echo round($i * 0.5, 1); ?>s" aria-hidden="true"></div>
  <?php endforeach; ?>

  <!-- Ballroom floor -->
  <div class="evt-ballroom-floor" aria-hidden="true"></div>
  <div class="evt-stage" aria-hidden="true"></div>

  <!-- Candles along floor -->
  <?php foreach ($evt_candles as $c): ?>
    <div class="evt-candle" style="left:<?php echo $c['x']; ?>%" aria-hidden="true">
      <div class="evt-candle-flame" style="animation-delay:<?php echo $c['d']; ?>s"></div>
      <div class="evt-candle-body" style="height:<?php echo $c['h']; ?>px"></div>
      <div class="evt-candle-glow" style="animation-delay:<?php echo $c['d']; ?>s"></div>
    </div>
  <?php endforeach; ?>

  <!-- Grand chandelier -->
  <div class="evt-chandelier" aria-hidden="true">
    <div class="evt-ch-chain"></div>
    <div class="evt-ch-ring"></div>
    <div class="evt-ch-arms-wrap">
      <?php for($ci=0;$ci<9;$ci++): ?>
        <div class="evt-ch-arm" style="transform:rotate(<?php echo -40+($ci*10); ?>deg);transform-origin:top center;height:<?php echo 24+abs($ci-4)*4; ?>px">
          <div class="evt-ch-crystal"></div>
        </div>
      <?php endfor; ?>
    </div>
    <div class="evt-ch-glow"></div>
  </div>

  <div class="evt-container">
    <div class="evt-hero-inner">
      <div class="evt-hero-content">
        <span class="evt-hero-script">Schloss Bellevue</span>
        <h1 class="evt-hero-h1">Unvergessliche Momente · Exklusiver Rahmen</h1>
        <p class="evt-hero-tagline">Tauchen Sie ein in die Welt des Außergewöhnlichen — für Hochzeiten, Jubiläen und Events, die ein Leben lang in Erinnerung bleiben.</p>
        <div class="evt-hero-btns">
          <a href="#anfrage" class="evt-btn evt-btn-gold">Datum anfragen</a>
          <a href="#raeume" class="evt-btn evt-btn-outline">Unsere Räume</a>
        </div>
        <div class="evt-hero-features">
          <div class="evt-hero-feat">
            <span>1887</span>
            <span>Gegründet</span>
          </div>
          <div class="evt-hero-feat">
            <span>300+</span>
            <span>Gäste max.</span>
          </div>
          <div class="evt-hero-feat">
            <span>4</span>
            <span>Exkl. Räume</span>
          </div>
          <div class="evt-hero-feat">
            <span>★ 5.0</span>
            <span>Bewertung</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══ ABOUT ════════════════════════════════════════════ -->
<section class="evt-about">
  <div class="evt-container">
    <div class="evt-about-grid">
      <div class="evt-reveal" style="position:relative">
        <div class="evt-art-frame" aria-hidden="true">
          <div class="evt-art-floor"></div>
          <div class="evt-art-curtain"></div>
          <div class="evt-art-curtain evt-art-curtain-r"></div>
          <div class="evt-art-arch-top"></div>
          <!-- Table -->
          <div class="evt-art-table"></div>
          <div class="evt-art-cloth"></div>
          <!-- Small candles -->
          <?php for($ci=0;$ci<5;$ci++): ?>
            <div class="evt-art-candle-s" style="left:<?php echo (30 + $ci * 12); ?>%;bottom:calc(30% + 12px)">
              <div style="width:4px;height:6px;background:linear-gradient(180deg,rgba(255,200,50,.9),rgba(255,100,10,.7));border-radius:50% 50% 30% 30%;animation:evt-flame-flicker <?php echo (1.2+$ci*0.2); ?>s ease-in-out infinite alternate;animation-delay:<?php echo ($ci*0.2); ?>s"></div>
              <div style="width:5px;height:<?php echo (20+$ci*5); ?>px;background:linear-gradient(180deg,#f5e8c0,#ddd0b0);border-radius:1px"></div>
            </div>
          <?php endfor; ?>
          <!-- Roses on table -->
          <?php
          $art_roses = [[35,55,12],[50,52,10],[65,56,14],[42,60,8],[58,58,9]];
          foreach ($art_roses as $ar): ?>
            <div class="evt-art-rose" style="left:<?php echo $ar[0]; ?>%;bottom:calc(30% + 18px);width:<?php echo $ar[2]; ?>px;height:<?php echo $ar[2]; ?>px;opacity:.7"></div>
          <?php endforeach; ?>
        </div>
        <div class="evt-about-badge" aria-hidden="true">
          <span class="evt-ab-n">137</span>
          <span class="evt-ab-t">Jahre<br>Magie</span>
        </div>
      </div>
      <div class="evt-reveal">
        <p class="evt-eyebrow">Unsere Geschichte</p>
        <span class="evt-script">Seit 1887</span>
        <h2 class="evt-h2">Wo Träume <strong>wirklich werden</strong></h2>
        <div class="evt-divider"><span class="evt-divider-icon">♦</span></div>
        <p style="color:var(--evt-slate);line-height:1.8;margin-bottom:20px;font-size:.95rem">Seit 1887 ist Schloss Bellevue der magischste Ort für die schönsten Feste Europas. In unserem historischen Gemäuer haben schon Könige, Künstler und unzählige Liebespaare gefeiert.</p>
        <p style="color:var(--evt-slate);line-height:1.8;margin-bottom:32px;font-size:.95rem">Jeder Winkel atmet Geschichte, jeder Raum birgt seine eigene Magie. Unser engagiertes Team macht Ihren Traum-Event zur vollendeten Wirklichkeit.</p>
        <a href="#anfrage" class="evt-btn evt-btn-plum">Beratungsgespräch buchen</a>
      </div>
    </div>
  </div>
</section>

<!-- ═══ SPACES ════════════════════════════════════════════ -->
<section class="evt-spaces" id="raeume">
  <div class="evt-container">
    <div class="evt-spaces-header evt-reveal">
      <p class="evt-eyebrow">Unsere Räumlichkeiten</p>
      <span class="evt-script">Vier einzigartige Bühnen</span>
      <div class="evt-divider"><span class="evt-divider-icon">♦</span></div>
    </div>
    <div class="evt-spaces-grid">
      <?php foreach ($evt_spaces as $space): ?>
        <div class="evt-space-card evt-reveal">
          <div class="evt-space-art">
            <div class="evt-space-art-bg" style="background:<?php echo esc_attr($space['color']); ?>"></div>
            <div class="evt-space-art-floor2"></div>
            <!-- Chairs row -->
            <div class="evt-space-art-chairs" style="left:8%;bottom:30%">
              <?php for($ch=0;$ch<12;$ch++): ?>
                <div class="evt-chair-small" style="background:rgba(255,255,255,.2);height:<?php echo rand(10,14); ?>px"></div>
              <?php endfor; ?>
            </div>
            <div class="evt-space-art-table2" style="width:120px"></div>
            <div class="evt-space-tag"><?php echo esc_html($space['cap']); ?> Gäste</div>
          </div>
          <div class="evt-space-body">
            <h3 class="evt-space-name"><?php echo esc_html($space['name']); ?></h3>
            <p class="evt-space-cap"><?php echo esc_html($space['cap']); ?> Personen · <?php echo esc_html($space['size']); ?> m²</p>
            <p class="evt-space-desc"><?php echo esc_html($space['desc']); ?></p>
            <div class="evt-space-features">
              <?php foreach ($space['features'] as $f): ?>
                <span class="evt-space-feat"><?php echo esc_html($f); ?></span>
              <?php endforeach; ?>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══ GALLERY ══════════════════════════════════════════ -->
<section class="evt-gallery">
  <div class="evt-container">
    <div class="evt-gallery-header evt-reveal">
      <span class="evt-script">Impressionen</span>
      <div class="evt-divider"><span class="evt-divider-icon" style="color:rgba(232,213,163,.5)">♦</span></div>
    </div>
    <div class="evt-mosaic evt-reveal">
      <!-- Tile 1: large -->
      <div class="evt-mosaic-tile" data-label="Ballsaal Abend" style="grid-column:span 2;grid-row:span 2;background:linear-gradient(135deg,#3d1f3a,#5a2e58)">
        <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:8px">
          <span style="font-family:var(--evt-ff-script);font-size:2rem;color:rgba(232,213,163,.5)">Der Ballsaal</span>
        </div>
      </div>
      <!-- Tile 2 -->
      <div class="evt-mosaic-tile" data-label="Tischdeko" style="background:linear-gradient(135deg,#c8a43c,#a88030)"></div>
      <!-- Tile 3 -->
      <div class="evt-mosaic-tile" data-label="Blumen" style="background:linear-gradient(135deg,#e8c5c0,#d4a09a)"></div>
      <!-- Tile 4 -->
      <div class="evt-mosaic-tile" data-label="Orangerie" style="background:linear-gradient(135deg,#e8d5a3,#d4b878)"></div>
      <!-- Tile 5 -->
      <div class="evt-mosaic-tile" data-label="Kaminzimmer" style="background:linear-gradient(135deg,#4a2a3a,#6a3a4a)"></div>
      <!-- Tile 6 -->
      <div class="evt-mosaic-tile" data-label="Terrasse" style="background:linear-gradient(135deg,#2d4a2a,#3d6038);grid-column:span 2"></div>
    </div>
  </div>
</section>

<!-- ═══ PACKAGES ══════════════════════════════════════════ -->
<section class="evt-packages" id="pakete">
  <div class="evt-container">
    <div class="evt-packages-header evt-reveal">
      <p class="evt-eyebrow">Unsere Pakete</p>
      <span class="evt-script">Alles aus einer Hand</span>
      <div class="evt-divider"><span class="evt-divider-icon">♦</span></div>
    </div>
    <div class="evt-packages-grid">
      <?php foreach ($evt_packages as $pkg): ?>
        <div class="evt-pkg<?php echo $pkg['popular'] ? ' popular' : ''; ?> evt-reveal">
          <?php if($pkg['tag']): ?>
            <div class="evt-pkg-badge"><?php echo esc_html($pkg['tag']); ?></div>
          <?php endif; ?>
          <span class="evt-pkg-name"><?php echo esc_html($pkg['name']); ?></span>
          <p class="evt-pkg-tag"><?php echo esc_html($pkg['tag']); ?></p>
          <p class="evt-pkg-price"><?php echo esc_html($pkg['price']); ?></p>
          <p class="evt-pkg-desc"><?php echo esc_html($pkg['desc']); ?></p>
          <ul class="evt-pkg-includes">
            <?php foreach ($pkg['includes'] as $inc): ?>
              <li><?php echo esc_html($inc); ?></li>
            <?php endforeach; ?>
          </ul>
          <a href="#anfrage" class="evt-pkg-btn">Paket anfragen</a>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══ CATERING ═════════════════════════════════════════ -->
<section class="evt-catering" id="catering">
  <div class="evt-container">
    <div class="evt-catering-grid">
      <div class="evt-reveal">
        <p class="evt-eyebrow">Kulinarik</p>
        <span class="evt-script">Gaumenfreuden</span>
        <h2 class="evt-h2">Catering auf <strong>höchstem Niveau</strong></h2>
        <div class="evt-divider"><span class="evt-divider-icon">♦</span></div>
        <p style="color:var(--evt-slate);line-height:1.8;margin-bottom:28px;font-size:.95rem">Unser Küchenchef und sein Team verwandeln Ihr Fest in ein kulinarisches Erlebnis. Von eleganten Canteès bis zum mehrgängigen Gourmet-Menü — jedes Gericht wird mit Leidenschaft und frischen, regionalen Produkten zubereitet.</p>
        <a href="#anfrage" class="evt-btn evt-btn-plum">Menü anfragen</a>
      </div>
      <div class="evt-catering-items evt-reveal">
        <?php
        $catering_icons = ['🥂','🍽','🥘','🎂'];
        foreach ($evt_catering as $ci => $cat): ?>
          <div class="evt-catering-item">
            <div class="evt-catering-icon"><?php echo $catering_icons[$ci]; ?></div>
            <div>
              <h3 class="evt-catering-name"><?php echo esc_html($cat['name']); ?></h3>
              <p class="evt-catering-desc"><?php echo esc_html($cat['desc']); ?></p>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- ═══ STATS ════════════════════════════════════════════ -->
<section class="evt-stats">
  <div class="evt-container">
    <div class="evt-stats-grid">
      <div class="evt-stat evt-reveal">
        <span class="evt-stat-num" data-target="850" data-suffix="+">850+</span>
        <span class="evt-stat-label">Events gefeiert</span>
      </div>
      <div class="evt-stat evt-reveal">
        <span class="evt-stat-num" data-target="137" data-suffix="">137</span>
        <span class="evt-stat-label">Jahre Geschichte</span>
      </div>
      <div class="evt-stat evt-reveal">
        <span class="evt-stat-num" data-target="300" data-suffix="">300</span>
        <span class="evt-stat-label">Gäste maximal</span>
      </div>
      <div class="evt-stat evt-reveal">
        <span class="evt-stat-num" data-target="100" data-suffix="%">100%</span>
        <span class="evt-stat-label">Weiterempfehlung</span>
      </div>
    </div>
  </div>
</section>

<!-- ═══ TESTIMONIALS ══════════════════════════════════════ -->
<section class="evt-testimonials">
  <div class="evt-container">
    <div class="evt-testimonials-header evt-reveal">
      <p class="evt-eyebrow">Stimmen unserer Gäste</p>
      <span class="evt-script">Glückliche Paare</span>
      <div class="evt-divider" style="justify-content:center"><span class="evt-divider-icon">♦</span></div>
    </div>
    <div class="evt-testi-grid">
      <?php foreach ($evt_testimonials as $testi): ?>
        <div class="evt-testi-card evt-reveal">
          <div class="evt-testi-stars">
            <span>★</span><span>★</span><span>★</span><span>★</span><span>★</span>
          </div>
          <p class="evt-testi-text"><?php echo esc_html($testi['text']); ?></p>
          <span class="evt-testi-couple"><?php echo esc_html($testi['couple']); ?></span>
          <span class="evt-testi-date"><?php echo esc_html($testi['date']); ?></span>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══ INQUIRY ══════════════════════════════════════════ -->
<section class="evt-inquiry" id="anfrage">
  <div class="evt-container">
    <div class="evt-inquiry-grid">
      <div class="evt-inquiry-form evt-reveal">
        <p class="evt-eyebrow">Ihr Traumtag</p>
        <span class="evt-script">Datum anfragen</span>
        <div class="evt-divider"><span class="evt-divider-icon">♦</span></div>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
          <?php wp_nonce_field('tf_evt_inquiry','tf_evt_nonce'); ?>
          <input type="hidden" name="action" value="tf_evt_inquiry">
          <div class="evt-form-row">
            <div class="evt-form-group">
              <label for="evt-fname">Vorname</label>
              <input type="text" id="evt-fname" name="first_name" placeholder="Marie" required>
            </div>
            <div class="evt-form-group">
              <label for="evt-lname">Nachname / Partner</label>
              <input type="text" id="evt-lname" name="last_name" placeholder="& Thomas" required>
            </div>
          </div>
          <div class="evt-form-group">
            <label for="evt-email">E-Mail</label>
            <input type="email" id="evt-email" name="email" placeholder="marie@beispiel.de" required>
          </div>
          <div class="evt-form-group">
            <label for="evt-phone">Telefon</label>
            <input type="tel" id="evt-phone" name="phone" placeholder="+49 30 …">
          </div>
          <div class="evt-form-row">
            <div class="evt-form-group">
              <label for="evt-date">Wunschdatum</label>
              <input type="date" id="evt-date" name="event_date" required>
            </div>
            <div class="evt-form-group">
              <label for="evt-guests">Gästeanzahl</label>
              <select id="evt-guests" name="guests">
                <option>bis 40 Personen</option>
                <option>41–100 Personen</option>
                <option>101–200 Personen</option>
                <option>201–300 Personen</option>
              </select>
            </div>
          </div>
          <div class="evt-form-row">
            <div class="evt-form-group">
              <label for="evt-space">Wunschraum</label>
              <select id="evt-space" name="space">
                <?php foreach ($evt_spaces as $sp): ?>
                  <option value="<?php echo esc_attr(sanitize_title($sp['name'])); ?>"><?php echo esc_html($sp['name']); ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="evt-form-group">
              <label for="evt-pkg">Paket</label>
              <select id="evt-pkg" name="package">
                <?php foreach ($evt_packages as $pk): ?>
                  <option value="<?php echo esc_attr(strtolower($pk['name'])); ?>"><?php echo esc_html($pk['name']); ?> (<?php echo esc_html($pk['price']); ?>)</option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
          <div class="evt-form-group">
            <label for="evt-msg">Ihre Wünsche & Träume</label>
            <textarea id="evt-msg" name="message" placeholder="Erzählen Sie uns von Ihrer Traumfeier …"></textarea>
          </div>
          <button type="submit" class="evt-form-submit">Anfrage absenden</button>
        </form>
      </div>
      <div class="evt-reveal">
        <div class="evt-ii-block">
          <p class="evt-ii-label">Adresse</p>
          <p class="evt-ii-value">Schloßallee 1<br>14193 Berlin-Grunewald</p>
        </div>
        <div class="evt-ii-block">
          <p class="evt-ii-label">Telefon</p>
          <p class="evt-ii-value">+49 30 88 77 66 55</p>
          <p class="evt-ii-note">Mo–Fr 9:00–18:00, Sa 10:00–15:00</p>
        </div>
        <div class="evt-ii-block">
          <p class="evt-ii-label">E-Mail</p>
          <p class="evt-ii-value">events@<?php echo esc_html(parse_url(home_url(),PHP_URL_HOST)); ?></p>
        </div>
        <div class="evt-ii-block">
          <p class="evt-ii-label">Besichtigungen</p>
          <p class="evt-ii-value" style="font-size:.9rem;font-family:var(--evt-ff-head);color:var(--evt-slate);line-height:1.8">✦ Kostenlose Besichtigung<br>✦ Persönliche Eventplanerin<br>✦ Exklusivität am Buchungsdatum<br>✦ Full-Service bis Mitternacht</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══ FINAL CTA ═════════════════════════════════════════ -->
<section class="evt-cta">
  <div class="evt-container">
    <span class="evt-script">Ihr großer Tag</span>
    <h2 class="evt-h2">wartet auf Sie</h2>
    <p>Kontaktieren Sie uns für eine unverbindliche Besichtigung und lassen Sie sich von der Magie von Schloss Bellevue verzaubern.</p>
    <div class="evt-cta-btns">
      <a href="#anfrage" class="evt-btn evt-btn-gold">Datum sichern</a>
      <a href="tel:+493088776655" class="evt-btn evt-btn-outline">Jetzt anrufen</a>
    </div>
  </div>
</section>

<!-- ═══ JS ════════════════════════════════════════════════ -->
<script>
(function(){
  'use strict';

  /* Nav scroll */
  const nav = document.getElementById('evtNav');
  window.addEventListener('scroll',()=>{nav.classList.toggle('scrolled',window.scrollY>60);},{passive:true});

  /* Reveal */
  const revEls = document.querySelectorAll('.evt-reveal');
  if('IntersectionObserver' in window){
    const io = new IntersectionObserver(entries=>{
      entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');io.unobserve(e.target);}});
    },{threshold:.1});
    revEls.forEach(el=>io.observe(el));
  } else {
    revEls.forEach(el=>el.classList.add('visible'));
  }

  /* Animated counters */
  const counters = document.querySelectorAll('.evt-stat-num[data-target]');
  const easeOut = t => 1 - Math.pow(1-t,3);
  if('IntersectionObserver' in window){
    const cio = new IntersectionObserver(entries=>{
      entries.forEach(e=>{
        if(!e.isIntersecting) return;
        const el = e.target;
        const target = parseInt(el.dataset.target,10);
        const suffix = el.dataset.suffix || '';
        const dur = 1600;
        const start = performance.now();
        const tick = now => {
          const p = Math.min((now-start)/dur,1);
          const val = Math.round(easeOut(p)*target);
          el.textContent = val.toLocaleString('de-DE') + suffix;
          if(p<1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
        cio.unobserve(el);
      });
    },{threshold:.4});
    counters.forEach(c=>cio.observe(c));
  }

  /* Date min */
  const dateI = document.getElementById('evt-date');
  if(dateI){
    const d = new Date();
    d.setMonth(d.getMonth()+3);
    dateI.min = d.toISOString().split('T')[0];
  }

})();
</script>
</div><!-- .evt-wrap -->
<?php get_footer(); ?>
