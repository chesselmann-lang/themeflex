<?php
/**
 * Template Name: Finance & Wealth Management Homepage
 *
 * Premium wealth management / private banking landing page.
 * Dark navy aesthetic · CSS trading dashboard hero · services grid ·
 * market ticker · advisors · performance chart · consultation form.
 *
 * @package ThemeFlex
 * @since   3.0.0
 */

get_header();
?>

<style>
/* ============================================================
   FINANCE PAGE — DESIGN TOKENS
   ============================================================ */
.tf-fin-page {
  --fin-bg:       #060b14;
  --fin-surface:  #0a1120;
  --fin-card:     #0e1828;
  --fin-border:   rgba(255,255,255,.07);
  --fin-accent:   #22c55e;   /* emerald green */
  --fin-accent2:  #38bdf8;   /* sky blue */
  --fin-accent3:  #f59e0b;   /* amber */
  --fin-red:      #ef4444;
  --fin-text:     #e2eaf5;
  --fin-muted:    #4e6080;
}

.tf-fin-page {
  background: var(--fin-bg);
  color: var(--fin-text);
  font-family: var(--tf-font-body,'Inter','Helvetica Neue',sans-serif);
  line-height: 1.6;
}

/* ============================================================
   HERO
   ============================================================ */
.fin-hero {
  position: relative;
  min-height: clamp(580px,88vh,860px);
  display: grid;
  grid-template-columns: 1fr 1fr;
  overflow: hidden;
}
.fin-hero::before {
  content:'';
  position: absolute;
  inset: 0;
  background: radial-gradient(ellipse 60% 80% at 20% 50%, rgba(34,197,94,.06) 0%, transparent 70%);
  pointer-events: none;
}

/* copy */
.fin-hero__copy {
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 6rem 4rem 6rem 6rem;
  position: relative;
  z-index: 2;
}
.fin-hero__eyebrow {
  display: flex;
  align-items: center;
  gap: .6rem;
  font-size: .7rem;
  letter-spacing: .2em;
  text-transform: uppercase;
  color: var(--fin-accent);
  margin-bottom: 1.5rem;
}
.fin-hero__eyebrow-dot {
  width: 6px; height: 6px;
  border-radius: 50%;
  background: var(--fin-accent);
  box-shadow: 0 0 8px var(--fin-accent);
  animation: fin-dot-pulse 2s ease-in-out infinite;
}
@keyframes fin-dot-pulse {
  0%,100% { box-shadow: 0 0 8px var(--fin-accent); }
  50% { box-shadow: 0 0 16px var(--fin-accent); }
}
.fin-hero__h1 {
  font-family: var(--tf-font-heading,'Plus Jakarta Sans','Inter',sans-serif);
  font-size: clamp(2.8rem,5vw,5rem);
  font-weight: 800;
  line-height: 1.08;
  letter-spacing: -.03em;
  color: var(--fin-text);
  margin: 0 0 1.5rem;
}
.fin-hero__h1 span {
  color: var(--fin-accent);
}
.fin-hero__sub {
  font-size: 1.05rem;
  color: var(--fin-muted);
  max-width: 40ch;
  margin: 0 0 2.5rem;
  line-height: 1.75;
}
.fin-hero__ctas { display: flex; gap: 1rem; flex-wrap: wrap; }

.fin-btn {
  display: inline-flex;
  align-items: center;
  gap: .5rem;
  padding: .85rem 1.75rem;
  border-radius: 6px;
  font-size: .88rem;
  font-weight: 600;
  text-decoration: none;
  transition: all .25s ease;
  cursor: pointer;
  border: none;
}
.fin-btn--primary {
  background: var(--fin-accent);
  color: #fff;
  box-shadow: 0 0 24px rgba(34,197,94,.3);
}
.fin-btn--primary:hover { background: #16a34a; }
.fin-btn--outline {
  background: transparent;
  color: var(--fin-text);
  border: 1px solid var(--fin-border);
}
.fin-btn--outline:hover { border-color: var(--fin-accent); color: var(--fin-accent); }

.fin-hero__badges {
  display: flex;
  gap: .75rem;
  margin-top: 2.5rem;
  flex-wrap: wrap;
}
.fin-badge {
  display: flex;
  align-items: center;
  gap: .4rem;
  font-size: .72rem;
  background: rgba(255,255,255,.04);
  border: 1px solid var(--fin-border);
  border-radius: 4px;
  padding: .35rem .75rem;
  color: var(--fin-muted);
}
.fin-badge svg { color: var(--fin-accent); flex-shrink: 0; }

/* visual */
.fin-hero__visual {
  position: relative;
  background: #04080f;
  border-left: 1px solid var(--fin-border);
  overflow: hidden;
}

/* CSS trading dashboard */
.fin-dashboard {
  position: absolute;
  inset: 1.5rem;
  background: var(--fin-card);
  border: 1px solid var(--fin-border);
  border-radius: 12px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

/* Dashboard topbar */
.fin-dash-topbar {
  padding: .75rem 1.25rem;
  border-bottom: 1px solid var(--fin-border);
  display: flex;
  align-items: center;
  gap: .75rem;
  background: var(--fin-surface);
}
.fin-dash-dot { width: 8px; height: 8px; border-radius: 50%; }
.fin-dash-dot--r { background: #ef4444; }
.fin-dash-dot--y { background: #f59e0b; }
.fin-dash-dot--g { background: #22c55e; }
.fin-dash-title {
  margin-left: auto;
  font-size: .65rem;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: var(--fin-muted);
}
.fin-dash-live {
  display: flex;
  align-items: center;
  gap: .35rem;
  font-size: .62rem;
  color: var(--fin-accent);
  letter-spacing: .1em;
  text-transform: uppercase;
}
.fin-dash-live-dot {
  width: 5px; height: 5px;
  border-radius: 50%;
  background: var(--fin-accent);
  animation: fin-dot-pulse 1.5s ease-in-out infinite;
}

/* Portfolio KPI strip */
.fin-kpi-strip {
  display: grid;
  grid-template-columns: repeat(3,1fr);
  border-bottom: 1px solid var(--fin-border);
}
.fin-kpi {
  padding: .85rem 1rem;
  border-right: 1px solid var(--fin-border);
  text-align: center;
}
.fin-kpi:last-child { border-right: none; }
.fin-kpi__lbl {
  font-size: .58rem;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: var(--fin-muted);
  margin-bottom: .3rem;
}
.fin-kpi__val {
  font-family: var(--tf-font-heading,'Plus Jakarta Sans','Inter',sans-serif);
  font-size: 1.1rem;
  font-weight: 700;
  line-height: 1;
}
.fin-kpi__change {
  font-size: .62rem;
  margin-top: .2rem;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: .2rem;
}
.fin-up   { color: var(--fin-accent); }
.fin-down { color: var(--fin-red); }

/* Chart area */
.fin-chart-area {
  flex: 1;
  padding: 1rem 1.25rem .5rem;
  position: relative;
  overflow: hidden;
}
.fin-chart-lbl {
  font-size: .6rem;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: var(--fin-muted);
  margin-bottom: .6rem;
  display: flex;
  justify-content: space-between;
}

/* SVG candlestick chart */
.fin-chart-svg {
  width: 100%;
  overflow: visible;
}

/* Holdings list */
.fin-holdings {
  border-top: 1px solid var(--fin-border);
  padding: .75rem 1.25rem;
}
.fin-holdings-title {
  font-size: .58rem;
  letter-spacing: .12em;
  text-transform: uppercase;
  color: var(--fin-muted);
  margin-bottom: .6rem;
}
.fin-holding {
  display: grid;
  grid-template-columns: 28px 1fr auto auto;
  gap: .5rem;
  align-items: center;
  padding: .3rem 0;
  border-bottom: 1px solid rgba(255,255,255,.04);
}
.fin-holding:last-child { border-bottom: none; }
.fin-holding__logo {
  width: 22px;
  height: 22px;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: .5rem;
  font-weight: 800;
  color: #fff;
  flex-shrink: 0;
}
.fin-holding__ticker {
  font-size: .68rem;
  font-weight: 700;
  color: var(--fin-text);
  font-family: 'Courier New',monospace;
}
.fin-holding__name {
  font-size: .6rem;
  color: var(--fin-muted);
}
.fin-holding__price {
  font-size: .7rem;
  font-weight: 600;
  color: var(--fin-text);
  font-family: 'Courier New',monospace;
  text-align: right;
}
.fin-holding__change {
  font-size: .62rem;
  font-family: 'Courier New',monospace;
  text-align: right;
  min-width: 44px;
}

/* ============================================================
   TICKER TAPE
   ============================================================ */
.fin-ticker {
  background: var(--fin-surface);
  border-top: 1px solid var(--fin-border);
  border-bottom: 1px solid var(--fin-border);
  padding: .65rem 0;
  overflow: hidden;
}
.fin-ticker__track {
  display: flex;
  animation: fin-ticker-scroll 35s linear infinite;
  width: max-content;
}
.fin-ticker__track:hover { animation-play-state: paused; }
@keyframes fin-ticker-scroll {
  0%   { transform: translateX(0); }
  100% { transform: translateX(-50%); }
}
.fin-ticker__item {
  display: flex;
  align-items: center;
  gap: .5rem;
  padding: 0 2rem;
  white-space: nowrap;
  font-size: .72rem;
  font-family: 'Courier New',monospace;
}
.fin-ticker__symbol { color: var(--fin-text); font-weight: 700; letter-spacing: .05em; }
.fin-ticker__price  { color: var(--fin-muted); }
.fin-ticker__sep    { width: 1px; height: 10px; background: var(--fin-border); }

/* ============================================================
   SHARED SECTION
   ============================================================ */
.fin-section { padding: 7rem 0; }
.fin-container { max-width: 1280px; margin: 0 auto; padding: 0 2.5rem; }
.fin-label {
  display: inline-flex;
  align-items: center;
  gap: .55rem;
  font-size: .68rem;
  letter-spacing: .2em;
  text-transform: uppercase;
  color: var(--fin-accent);
  margin-bottom: 1rem;
}
.fin-label-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--fin-accent); }
.fin-h2 {
  font-family: var(--tf-font-heading,'Plus Jakarta Sans','Inter',sans-serif);
  font-size: clamp(2rem,4vw,3.5rem);
  font-weight: 800;
  line-height: 1.12;
  letter-spacing: -.03em;
  color: var(--fin-text);
  margin: 0 0 1rem;
}
.fin-lead {
  font-size: 1rem;
  color: var(--fin-muted);
  max-width: 52ch;
  line-height: 1.75;
}

/* ============================================================
   STATS
   ============================================================ */
.fin-stats-bar {
  background: var(--fin-surface);
  border-top: 1px solid var(--fin-border);
  border-bottom: 1px solid var(--fin-border);
  padding: 2.5rem 0;
}
.fin-stats-bar__inner {
  display: grid;
  grid-template-columns: repeat(4,1fr);
}
.fin-stat {
  text-align: center;
  padding: .75rem 1.5rem;
  border-right: 1px solid var(--fin-border);
}
.fin-stat:last-child { border-right: none; }
.fin-stat__val {
  font-family: var(--tf-font-heading,'Plus Jakarta Sans','Inter',sans-serif);
  font-size: 2.8rem;
  font-weight: 800;
  color: var(--fin-accent);
  line-height: 1;
  margin-bottom: .25rem;
}
.fin-stat__lbl {
  font-size: .7rem;
  letter-spacing: .12em;
  text-transform: uppercase;
  color: var(--fin-muted);
}

/* ============================================================
   SERVICES
   ============================================================ */
.fin-services { background: var(--fin-bg); }
.fin-services__grid {
  display: grid;
  grid-template-columns: repeat(3,1fr);
  gap: 1.5rem;
  margin-top: 3.5rem;
}
.fin-service-card {
  background: var(--fin-card);
  border: 1px solid var(--fin-border);
  border-radius: 12px;
  padding: 2rem;
  position: relative;
  overflow: hidden;
  transition: border-color .3s, transform .3s;
}
.fin-service-card:hover {
  border-color: rgba(34,197,94,.3);
  transform: translateY(-4px);
}
.fin-service-card__icon {
  width: 48px;
  height: 48px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 1.25rem;
}
.fin-service-card__title {
  font-family: var(--tf-font-heading,'Plus Jakarta Sans','Inter',sans-serif);
  font-size: 1.15rem;
  font-weight: 700;
  color: var(--fin-text);
  margin: 0 0 .65rem;
}
.fin-service-card__desc {
  font-size: .83rem;
  color: var(--fin-muted);
  line-height: 1.7;
  margin-bottom: 1.25rem;
}
.fin-service-card__features { display: flex; flex-direction: column; gap: .5rem; }
.fin-service-card__feat {
  font-size: .78rem;
  color: var(--fin-muted);
  display: flex;
  align-items: center;
  gap: .5rem;
}
.fin-service-card__feat svg { color: var(--fin-accent); flex-shrink: 0; }
.fin-service-card__bar {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 2px;
  background: var(--fin-accent);
  transform: scaleX(0);
  transform-origin: left;
  transition: transform .4s ease;
}
.fin-service-card:hover .fin-service-card__bar { transform: scaleX(1); }

/* ============================================================
   PERFORMANCE / ABOUT
   ============================================================ */
.fin-performance { background: var(--fin-surface); }
.fin-performance__inner {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 5rem;
  align-items: center;
}

/* Performance chart panel */
.fin-perf-panel {
  background: var(--fin-card);
  border: 1px solid var(--fin-border);
  border-radius: 16px;
  padding: 2rem;
}
.fin-perf-panel__header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 1.5rem;
}
.fin-perf-panel__title {
  font-size: .72rem;
  letter-spacing: .12em;
  text-transform: uppercase;
  color: var(--fin-muted);
}
.fin-perf-period {
  display: flex;
  gap: .4rem;
}
.fin-perf-period-btn {
  font-size: .62rem;
  padding: .2rem .5rem;
  border-radius: 4px;
  color: var(--fin-muted);
  cursor: pointer;
  border: 1px solid transparent;
  background: transparent;
}
.fin-perf-period-btn.active {
  background: rgba(34,197,94,.15);
  border-color: rgba(34,197,94,.3);
  color: var(--fin-accent);
}

/* Bar performance chart */
.fin-perf-bars {
  display: flex;
  align-items: flex-end;
  gap: .5rem;
  height: 140px;
  margin-bottom: 1rem;
}
.fin-perf-bar-wrap {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: .3rem;
  height: 100%;
  justify-content: flex-end;
}
.fin-perf-bar {
  width: 100%;
  border-radius: 3px 3px 0 0;
  min-height: 4px;
  animation: fin-bar-rise 1.2s cubic-bezier(.34,1.56,.64,1) forwards var(--del,.1s);
  transform-origin: bottom;
  transform: scaleY(0);
}
@keyframes fin-bar-rise { to { transform: scaleY(1); } }
.fin-perf-bar-lbl {
  font-size: .58rem;
  color: var(--fin-muted);
  font-family: 'Courier New',monospace;
}
.fin-perf-legend {
  display: flex;
  gap: 1.25rem;
  justify-content: center;
}
.fin-legend-item {
  display: flex;
  align-items: center;
  gap: .4rem;
  font-size: .68rem;
  color: var(--fin-muted);
}
.fin-legend-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  flex-shrink: 0;
}

/* Returns summary */
.fin-returns {
  display: grid;
  grid-template-columns: repeat(3,1fr);
  gap: 1rem;
  margin-top: 1.25rem;
}
.fin-return {
  background: var(--fin-surface);
  border: 1px solid var(--fin-border);
  border-radius: 8px;
  padding: .85rem;
  text-align: center;
}
.fin-return__val {
  font-family: var(--tf-font-heading,'Plus Jakarta Sans','Inter',sans-serif);
  font-size: 1.5rem;
  font-weight: 800;
  color: var(--fin-accent);
  line-height: 1;
  margin-bottom: .2rem;
}
.fin-return__lbl { font-size: .65rem; letter-spacing: .1em; text-transform: uppercase; color: var(--fin-muted); }

.fin-performance__copy { display: flex; flex-direction: column; }
.fin-pillars { display: flex; flex-direction: column; gap: 1rem; margin-top: 2rem; }
.fin-pillar {
  display: flex;
  gap: 1rem;
  align-items: flex-start;
  padding: 1.1rem 1.25rem;
  background: var(--fin-card);
  border: 1px solid var(--fin-border);
  border-radius: 8px;
  border-left: 3px solid transparent;
  transition: border-color .3s;
}
.fin-pillar:hover { border-left-color: var(--fin-accent); }
.fin-pillar__icon {
  width: 32px;
  height: 32px;
  border-radius: 6px;
  background: rgba(34,197,94,.1);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--fin-accent);
  flex-shrink: 0;
}
.fin-pillar__title { font-size: .9rem; font-weight: 600; color: var(--fin-text); margin-bottom: .2rem; }
.fin-pillar__desc  { font-size: .8rem; color: var(--fin-muted); line-height: 1.6; }

/* ============================================================
   ADVISORS
   ============================================================ */
.fin-advisors { background: var(--fin-bg); }
.fin-advisors__grid {
  display: grid;
  grid-template-columns: repeat(4,1fr);
  gap: 1.5rem;
  margin-top: 3.5rem;
}
.fin-advisor-card {
  background: var(--fin-card);
  border: 1px solid var(--fin-border);
  border-radius: 12px;
  padding: 1.75rem;
  transition: border-color .3s;
}
.fin-advisor-card:hover { border-color: rgba(34,197,94,.3); }
.fin-advisor-card__av {
  width: 56px;
  height: 56px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.1rem;
  font-weight: 800;
  color: #fff;
  margin-bottom: 1rem;
  flex-shrink: 0;
}
.fin-advisor-card__name { font-size: 1rem; font-weight: 700; color: var(--fin-text); margin-bottom: .2rem; }
.fin-advisor-card__title {
  font-size: .72rem;
  letter-spacing: .08em;
  text-transform: uppercase;
  color: var(--fin-accent);
  margin-bottom: .75rem;
}
.fin-advisor-card__spec { font-size: .8rem; color: var(--fin-muted); line-height: 1.6; margin-bottom: .85rem; }
.fin-advisor-card__aum {
  font-size: .75rem;
  color: var(--fin-text);
  background: rgba(34,197,94,.08);
  border: 1px solid rgba(34,197,94,.2);
  border-radius: 4px;
  padding: .3rem .65rem;
  display: inline-flex;
  align-items: center;
  gap: .4rem;
}
.fin-advisor-card__aum svg { color: var(--fin-accent); }

/* ============================================================
   TESTIMONIALS
   ============================================================ */
.fin-testimonials { background: var(--fin-surface); }
.fin-testimonials__grid {
  display: grid;
  grid-template-columns: repeat(3,1fr);
  gap: 1.5rem;
  margin-top: 3.5rem;
}
.fin-testi-card {
  background: var(--fin-card);
  border: 1px solid var(--fin-border);
  border-radius: 12px;
  padding: 2rem;
  display: flex;
  flex-direction: column;
}
.fin-testi-card__stars {
  display: flex;
  gap: .2rem;
  margin-bottom: 1rem;
  color: var(--fin-accent3);
}
.fin-testi-card__text {
  font-size: .88rem;
  color: var(--fin-text);
  line-height: 1.75;
  font-style: italic;
  flex: 1;
  margin-bottom: 1.5rem;
}
.fin-testi-card__footer { display: flex; align-items: center; gap: .85rem; }
.fin-testi-card__av {
  width: 38px;
  height: 38px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: .7rem;
  font-weight: 800;
  color: #fff;
  flex-shrink: 0;
}
.fin-testi-card__name { font-size: .85rem; font-weight: 600; color: var(--fin-text); }
.fin-testi-card__role { font-size: .72rem; color: var(--fin-muted); }
.fin-testi-card__result {
  margin-left: auto;
  font-size: .65rem;
  letter-spacing: .06em;
  color: var(--fin-accent);
  background: rgba(34,197,94,.08);
  border: 1px solid rgba(34,197,94,.2);
  border-radius: 20px;
  padding: .25rem .65rem;
  white-space: nowrap;
}

/* ============================================================
   CONSULTATION FORM
   ============================================================ */
.fin-consult { background: var(--fin-bg); }
.fin-consult__inner {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 5rem;
  align-items: start;
}
.fin-consult__info { padding-top: .5rem; }
.fin-trust-list { display: flex; flex-direction: column; gap: 1rem; margin-top: 2rem; }
.fin-trust-item {
  display: flex;
  gap: .85rem;
  align-items: flex-start;
}
.fin-trust-item__icon {
  width: 28px;
  height: 28px;
  border-radius: 6px;
  background: rgba(34,197,94,.1);
  border: 1px solid rgba(34,197,94,.2);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--fin-accent);
  flex-shrink: 0;
  margin-top: .1rem;
}
.fin-trust-item__title { font-size: .88rem; font-weight: 600; color: var(--fin-text); margin-bottom: .15rem; }
.fin-trust-item__desc  { font-size: .8rem; color: var(--fin-muted); line-height: 1.6; }

.fin-form {
  background: var(--fin-card);
  border: 1px solid var(--fin-border);
  border-radius: 16px;
  padding: 2.5rem;
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
}
.fin-form__title {
  font-family: var(--tf-font-heading,'Plus Jakarta Sans','Inter',sans-serif);
  font-size: 1.35rem;
  font-weight: 700;
  color: var(--fin-text);
  margin: 0 0 .25rem;
}
.fin-form__sub { font-size: .83rem; color: var(--fin-muted); margin: 0 0 .5rem; }
.fin-form__row { display: grid; grid-template-columns: 1fr 1fr; gap: .85rem; }
.fin-field { display: flex; flex-direction: column; gap: .4rem; }
.fin-field label {
  font-size: .72rem;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: var(--fin-muted);
}
.fin-field input,
.fin-field select,
.fin-field textarea {
  background: var(--fin-surface);
  border: 1px solid var(--fin-border);
  color: var(--fin-text);
  padding: .75rem 1rem;
  font-size: .88rem;
  font-family: inherit;
  outline: none;
  border-radius: 8px;
  transition: border-color .2s;
  box-sizing: border-box;
  width: 100%;
  -webkit-appearance: none;
}
.fin-field input:focus,
.fin-field select:focus,
.fin-field textarea:focus { border-color: var(--fin-accent); }
.fin-field select option { background: var(--fin-card); }
.fin-field textarea { resize: vertical; min-height: 90px; }

.fin-form__assets {
  display: grid;
  grid-template-columns: repeat(3,1fr);
  gap: .75rem;
}
.fin-asset-opt { display: none; }
.fin-asset-opt + label {
  display: block;
  border: 1px solid var(--fin-border);
  border-radius: 6px;
  padding: .6rem;
  text-align: center;
  font-size: .7rem;
  letter-spacing: .06em;
  text-transform: uppercase;
  color: var(--fin-muted);
  cursor: pointer;
  transition: all .2s;
}
.fin-asset-opt:checked + label {
  border-color: var(--fin-accent);
  color: var(--fin-accent);
  background: rgba(34,197,94,.06);
}
.fin-asset-opt + label:hover { border-color: rgba(34,197,94,.3); color: var(--fin-text); }
.fin-form__disclaimer { font-size: .72rem; color: var(--fin-muted); line-height: 1.6; border-left: 2px solid rgba(34,197,94,.3); padding-left: .75rem; }

/* ============================================================
   CTA
   ============================================================ */
.fin-cta {
  background: linear-gradient(135deg, #061a0e 0%, #060b14 100%);
  padding: 6rem 0;
  text-align: center;
  border-top: 1px solid rgba(34,197,94,.15);
  position: relative;
  overflow: hidden;
}
.fin-cta::before {
  content: '';
  position: absolute;
  top: -50%;
  left: 50%;
  transform: translateX(-50%);
  width: 600px;
  height: 600px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(34,197,94,.08) 0%, transparent 70%);
  pointer-events: none;
}
.fin-cta__inner { position: relative; z-index: 1; }
.fin-cta__eyebrow {
  font-size: .7rem;
  letter-spacing: .2em;
  text-transform: uppercase;
  color: var(--fin-accent);
  margin-bottom: 1rem;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: .5rem;
}
.fin-cta__h2 {
  font-family: var(--tf-font-heading,'Plus Jakarta Sans','Inter',sans-serif);
  font-size: clamp(2.2rem,5vw,4rem);
  font-weight: 800;
  color: var(--fin-text);
  letter-spacing: -.03em;
  margin: 0 0 1rem;
}
.fin-cta__sub {
  font-size: 1rem;
  color: var(--fin-muted);
  max-width: 44ch;
  margin: 0 auto 2.5rem;
  line-height: 1.7;
}
.fin-cta__btns { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; }

/* ============================================================
   RESPONSIVE
   ============================================================ */
@media (max-width: 1100px) {
  .fin-advisors__grid { grid-template-columns: repeat(2,1fr); }
  .fin-services__grid { grid-template-columns: repeat(2,1fr); }
}
@media (max-width: 960px) {
  .fin-hero { grid-template-columns: 1fr; }
  .fin-hero__visual { display: none; }
  .fin-hero__copy { padding: 5rem 2.5rem; }
  .fin-performance__inner { grid-template-columns: 1fr; gap: 3rem; }
  .fin-consult__inner { grid-template-columns: 1fr; gap: 3rem; }
  .fin-testimonials__grid { grid-template-columns: 1fr 1fr; }
}
@media (max-width: 640px) {
  .fin-container { padding: 0 1.5rem; }
  .fin-section { padding: 4rem 0; }
  .fin-services__grid { grid-template-columns: 1fr; }
  .fin-advisors__grid { grid-template-columns: 1fr; }
  .fin-testimonials__grid { grid-template-columns: 1fr; }
  .fin-stats-bar__inner { grid-template-columns: 1fr 1fr; }
  .fin-returns { grid-template-columns: 1fr 1fr; }
  .fin-form__row { grid-template-columns: 1fr; }
  .fin-form__assets { grid-template-columns: 1fr 1fr; }
}
</style>

<main class="tf-fin-page" id="main">

  <?php
  // ============================================================
  // HERO
  // ============================================================
  ?>
  <section class="fin-hero" aria-label="<?php esc_attr_e( 'Wealth management hero', 'themeflex' ); ?>">

    <!-- Copy -->
    <div class="fin-hero__copy">
      <div class="fin-hero__eyebrow">
        <div class="fin-hero__eyebrow-dot" aria-hidden="true"></div>
        <?php esc_html_e( 'Private Wealth Management · Est. 1987', 'themeflex' ); ?>
      </div>

      <h1 class="fin-hero__h1">
        <?php esc_html_e( 'Grow &amp; Protect', 'themeflex' ); ?><br>
        <?php esc_html_e( 'Your', 'themeflex' ); ?>
        <span><?php esc_html_e( 'Wealth', 'themeflex' ); ?></span>
      </h1>

      <p class="fin-hero__sub">
        <?php esc_html_e( 'Meridian Capital Partners is a boutique private wealth manager trusted by entrepreneurs, families, and institutions across Europe with over €4.2B in assets under management.', 'themeflex' ); ?>
      </p>

      <div class="fin-hero__ctas">
        <a href="#consult" class="fin-btn fin-btn--primary">
          <?php tf_icon( 'calendar', 18 ); ?>
          <?php esc_html_e( 'Book a Consultation', 'themeflex' ); ?>
        </a>
        <a href="#services" class="fin-btn fin-btn--outline">
          <?php tf_icon( 'briefcase', 18 ); ?>
          <?php esc_html_e( 'Our Services', 'themeflex' ); ?>
        </a>
      </div>

      <div class="fin-hero__badges">
        <?php
        $badges = [
          [ 'icon'=>'shield', 'text'=>__('FCA Regulated','themeflex') ],
          [ 'icon'=>'lock',   'text'=>__('GDPR Compliant','themeflex') ],
          [ 'icon'=>'award',  'text'=>__('PWM Award 2024','themeflex') ],
        ];
        foreach ($badges as $b):
        ?>
        <div class="fin-badge">
          <?php tf_icon($b['icon'],13); ?>
          <?php echo esc_html($b['text']); ?>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Visual dashboard -->
    <div class="fin-hero__visual" aria-hidden="true">
      <div class="fin-dashboard">
        <!-- Topbar -->
        <div class="fin-dash-topbar">
          <div class="fin-dash-dot fin-dash-dot--r"></div>
          <div class="fin-dash-dot fin-dash-dot--y"></div>
          <div class="fin-dash-dot fin-dash-dot--g"></div>
          <span class="fin-dash-title"><?php esc_html_e( 'Portfolio Overview', 'themeflex' ); ?></span>
          <div class="fin-dash-live">
            <div class="fin-dash-live-dot"></div>
            LIVE
          </div>
        </div>

        <!-- KPI Strip -->
        <div class="fin-kpi-strip">
          <div class="fin-kpi">
            <div class="fin-kpi__lbl">Portfolio Value</div>
            <div class="fin-kpi__val" style="color:var(--fin-text);">€ 2.84M</div>
            <div class="fin-kpi__change fin-up"><?php tf_icon('trending-up',10); ?> +14.2% YTD</div>
          </div>
          <div class="fin-kpi">
            <div class="fin-kpi__lbl">Day Gain</div>
            <div class="fin-kpi__val fin-up">+€ 4,820</div>
            <div class="fin-kpi__change fin-up"><?php tf_icon('trending-up',10); ?> +0.17%</div>
          </div>
          <div class="fin-kpi">
            <div class="fin-kpi__lbl">Sharpe Ratio</div>
            <div class="fin-kpi__val" style="color:var(--fin-accent2);">1.84</div>
            <div class="fin-kpi__change" style="color:var(--fin-muted);">Excellent</div>
          </div>
        </div>

        <!-- Chart -->
        <div class="fin-chart-area">
          <div class="fin-chart-lbl">
            <span>PORTFOLIO vs BENCHMARK · 12M</span>
            <span style="color:var(--fin-accent);">+14.2%</span>
          </div>
          <?php
          // Generate SVG candlestick / line chart
          $w = 400; $h = 120;
          // Portfolio line points
          $pts_p = [0,15,8,22,18,32,25,40,35,50,42,58,52,62,68,72,78,82,88,95,100,108,105,115];
          $pts_b = [0,5,4,10,8,16,13,20,18,26,22,30,28,32,34,36,38,40,42,44,46,48,48,50];
          $n = count($pts_p);
          $step = $w / ($n - 1);
          $p_path = '';
          $b_path = '';
          $p_area = "0,{$h} ";
          foreach ($pts_p as $i => $v) {
            $x = $i * $step;
            $y = $h - ($v / 120 * $h);
            $p_path .= ($i===0?"M{$x},{$y} ":"L{$x},{$y} ");
            $p_area .= "{$x},{$y} ";
          }
          $p_area .= "{$w},{$h}";
          foreach ($pts_b as $i => $v) {
            $x = $i * $step;
            $y = $h - ($v / 120 * $h);
            $b_path .= ($i===0?"M{$x},{$y} ":"L{$x},{$y} ");
          }
          ?>
          <svg class="fin-chart-svg" viewBox="0 0 <?php echo intval($w); ?> <?php echo intval($h); ?>" preserveAspectRatio="none" aria-hidden="true">
            <defs>
              <linearGradient id="fin-grad-p" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="#22c55e" stop-opacity=".25"/>
                <stop offset="100%" stop-color="#22c55e" stop-opacity="0"/>
              </linearGradient>
            </defs>
            <!-- horizontal grid lines -->
            <?php for ($g=1;$g<=3;$g++): ?>
            <line x1="0" y1="<?php echo intval($h*$g/4); ?>" x2="<?php echo intval($w); ?>" y2="<?php echo intval($h*$g/4); ?>"
                  stroke="rgba(255,255,255,.05)" stroke-width="1"/>
            <?php endfor; ?>
            <polygon points="<?php echo esc_attr($p_area); ?>" fill="url(#fin-grad-p)"/>
            <path d="<?php echo esc_attr($b_path); ?>" fill="none" stroke="rgba(255,255,255,.2)" stroke-width="1.5" stroke-dasharray="4 3"/>
            <path d="<?php echo esc_attr($p_path); ?>" fill="none" stroke="#22c55e" stroke-width="2"/>
          </svg>
        </div>

        <!-- Holdings -->
        <div class="fin-holdings">
          <div class="fin-holdings-title">Top Holdings</div>
          <?php
          $holdings = [
            [ 'ticker'=>'AAPL', 'logo_bg'=>'#1d1d1f', 'logo_txt'=>'A',  'price'=>'$189.40', 'chg'=>'+1.2%', 'up'=>true ],
            [ 'ticker'=>'MSFT', 'logo_bg'=>'#00a4ef', 'logo_txt'=>'M',  'price'=>'$415.22', 'chg'=>'+0.8%', 'up'=>true ],
            [ 'ticker'=>'NOVO', 'logo_bg'=>'#0032a0', 'logo_txt'=>'N',  'price'=>'DKK 680', 'chg'=>'+2.1%', 'up'=>true ],
            [ 'ticker'=>'NESN', 'logo_bg'=>'#a32020', 'logo_txt'=>'N',  'price'=>'CHF 96.4','chg'=>'-0.4%', 'up'=>false ],
          ];
          foreach ($holdings as $h):
          ?>
          <div class="fin-holding">
            <div class="fin-holding__logo" style="background:<?php echo esc_attr($h['logo_bg']); ?>;"><?php echo esc_html($h['logo_txt']); ?></div>
            <div>
              <div class="fin-holding__ticker"><?php echo esc_html($h['ticker']); ?></div>
            </div>
            <div class="fin-holding__price"><?php echo esc_html($h['price']); ?></div>
            <div class="fin-holding__change <?php echo $h['up']?'fin-up':'fin-down'; ?>"><?php echo esc_html($h['chg']); ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

  </section>

  <?php
  // ============================================================
  // TICKER TAPE
  // ============================================================
  $tickers = [
    [ 's'=>'SPX',  'p'=>'5,204.34', 'c'=>'+0.24%', 'up'=>true  ],
    [ 's'=>'DAX',  'p'=>'18,142.20','c'=>'+0.11%', 'up'=>true  ],
    [ 's'=>'EURUSD','p'=>'1.0842',  'c'=>'-0.06%', 'up'=>false ],
    [ 's'=>'GOLD', 'p'=>'2,324.80', 'c'=>'+0.38%', 'up'=>true  ],
    [ 's'=>'BTC',  'p'=>'63,480',   'c'=>'+1.72%', 'up'=>true  ],
    [ 's'=>'AAPL', 'p'=>'189.40',   'c'=>'+1.20%', 'up'=>true  ],
    [ 's'=>'MSFT', 'p'=>'415.22',   'c'=>'+0.80%', 'up'=>true  ],
    [ 's'=>'NVDA', 'p'=>'878.30',   'c'=>'+3.10%', 'up'=>true  ],
    [ 's'=>'TSLA', 'p'=>'172.48',   'c'=>'-2.40%', 'up'=>false ],
    [ 's'=>'NOVO.B','p'=>'DKK 680','c'=>'+2.10%', 'up'=>true  ],
  ];
  $all_tickers = array_merge($tickers,$tickers);
  ?>
  <div class="fin-ticker" aria-label="<?php esc_attr_e( 'Live market data ticker', 'themeflex' ); ?>"
       role="marquee">
    <div class="fin-ticker__track" aria-hidden="true">
      <?php foreach ($all_tickers as $t): ?>
      <div class="fin-ticker__item">
        <span class="fin-ticker__symbol"><?php echo esc_html($t['s']); ?></span>
        <span class="fin-ticker__price"><?php echo esc_html($t['p']); ?></span>
        <span class="fin-ticker__change <?php echo $t['up']?'fin-up':'fin-down'; ?>">
          <?php echo esc_html($t['c']); ?>
        </span>
      </div>
      <div class="fin-ticker__sep"></div>
      <?php endforeach; ?>
    </div>
  </div>

  <?php
  // ============================================================
  // STATS BAR
  // ============================================================
  $stats = [
    [ 'val'=>'4.2',   'suffix'=>'B+', 'lbl'=>__('Assets Under Management','themeflex') ],
    [ 'val'=>'37',    'suffix'=>'yrs','lbl'=>__('Years of Excellence','themeflex') ],
    [ 'val'=>'1,200', 'suffix'=>'+',  'lbl'=>__('Client Families','themeflex') ],
    [ 'val'=>'12.4',  'suffix'=>'%',  'lbl'=>__('Avg Annual Return','themeflex') ],
  ];
  ?>
  <div class="fin-stats-bar" role="region"
       aria-label="<?php esc_attr_e( 'Key statistics', 'themeflex' ); ?>">
    <div class="fin-container">
      <div class="fin-stats-bar__inner">
        <?php foreach ($stats as $s): ?>
        <div class="fin-stat">
          <div class="fin-stat__val" data-counter="<?php echo esc_attr(str_replace(',','',$s['val'])); ?>"
               data-suffix="<?php echo esc_attr($s['suffix']); ?>">
            <?php echo esc_html($s['val'].$s['suffix']); ?>
          </div>
          <div class="fin-stat__lbl"><?php echo esc_html($s['lbl']); ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <?php
  // ============================================================
  // SERVICES
  // ============================================================
  $services = [
    [
      'icon'=>'trending-up', 'icon_bg'=>'rgba(34,197,94,.1)', 'icon_col'=>'#22c55e',
      'title'=>__('Wealth Management','themeflex'),
      'desc'=>__('Holistic portfolio construction tailored to your risk profile, liquidity needs, and long-term goals — across equities, bonds, alternatives, and real assets.','themeflex'),
      'feats'=>[__('Personalised IPS','themeflex'),__('Discretionary mandate','themeflex'),__('ESG integration','themeflex'),__('Quarterly performance review','themeflex')],
    ],
    [
      'icon'=>'building-2', 'icon_bg'=>'rgba(56,189,248,.1)', 'icon_col'=>'#38bdf8',
      'title'=>__('Private Banking','themeflex'),
      'desc'=>__('A dedicated private banker on call — managing day-to-day banking, credit facilities, foreign exchange, and structured products for sophisticated clients.','themeflex'),
      'feats'=>[__('Dedicated relationship manager','themeflex'),__('Multi-currency accounts','themeflex'),__('Lombard credit','themeflex'),__('24/7 concierge banking','themeflex')],
    ],
    [
      'icon'=>'shield-check', 'icon_bg'=>'rgba(245,158,11,.1)', 'icon_col'=>'#f59e0b',
      'title'=>__('Estate & Tax Planning','themeflex'),
      'desc'=>__('Cross-border estate structuring, trust and foundation administration, and tax-efficient wealth transfer strategies — coordinated with your legal advisors.','themeflex'),
      'feats'=>[__('Trust & foundation setup','themeflex'),__('Cross-border structuring','themeflex'),__('Succession planning','themeflex'),__('Philanthropy advisory','themeflex')],
    ],
    [
      'icon'=>'landmark', 'icon_bg'=>'rgba(168,85,247,.1)', 'icon_col'=>'#a855f7',
      'title'=>__('Alternative Investments','themeflex'),
      'desc'=>__('Access to private equity, hedge funds, infrastructure, and real estate co-investments — the same opportunities reserved for institutional investors.','themeflex'),
      'feats'=>[__('Private equity funds','themeflex'),__('Real estate co-investment','themeflex'),__('Hedge fund allocation','themeflex'),__('Infrastructure lending','themeflex')],
    ],
    [
      'icon'=>'globe', 'icon_bg'=>'rgba(52,211,153,.1)', 'icon_col'=>'#34d399',
      'title'=>__('Family Office Services','themeflex'),
      'desc'=>__('Consolidated reporting, asset aggregation, family governance frameworks, and next-generation education — everything a multigenerational family requires.','themeflex'),
      'feats'=>[__('Consolidated reporting','themeflex'),__('Family governance','themeflex'),__('Next-gen education','themeflex'),__('360° balance sheet','themeflex')],
    ],
    [
      'icon'=>'heart-pulse', 'icon_bg'=>'rgba(239,68,68,.1)', 'icon_col'=>'#ef4444',
      'title'=>__('Pension & Retirement','themeflex'),
      'desc'=>__('Retirement income modelling, pension consolidation, drawdown strategy, and healthcare cost planning — ensuring financial security for life.','themeflex'),
      'feats'=>[__('Retirement income model','themeflex'),__('Pension consolidation','themeflex'),__('Drawdown optimisation','themeflex'),__('Healthcare planning','themeflex')],
    ],
  ];
  ?>
  <section class="fin-section fin-services" id="services"
           aria-labelledby="fin-services-h">
    <div class="fin-container">
      <div class="fin-label">
        <span class="fin-label-dot" aria-hidden="true"></span>
        <?php esc_html_e( 'What We Offer', 'themeflex' ); ?>
      </div>
      <h2 class="fin-h2" id="fin-services-h"><?php esc_html_e( 'Comprehensive Wealth Services', 'themeflex' ); ?></h2>
      <p class="fin-lead"><?php esc_html_e( 'A full spectrum of financial services — from discretionary portfolio management to family office and estate planning.', 'themeflex' ); ?></p>

      <div class="fin-services__grid">
        <?php foreach ($services as $srv): ?>
        <div class="fin-service-card">
          <div class="fin-service-card__icon"
               style="background:<?php echo esc_attr($srv['icon_bg']); ?>;color:<?php echo esc_attr($srv['icon_col']); ?>;"
               aria-hidden="true">
            <?php tf_icon($srv['icon'],22); ?>
          </div>
          <h3 class="fin-service-card__title"><?php echo esc_html($srv['title']); ?></h3>
          <p class="fin-service-card__desc"><?php echo esc_html($srv['desc']); ?></p>
          <div class="fin-service-card__features">
            <?php foreach ($srv['feats'] as $feat): ?>
            <div class="fin-service-card__feat">
              <?php tf_icon('check',13); ?>
              <?php echo esc_html($feat); ?>
            </div>
            <?php endforeach; ?>
          </div>
          <div class="fin-service-card__bar" aria-hidden="true"></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // PERFORMANCE
  // ============================================================
  $years = ['2019','2020','2021','2022','2023','2024'];
  $port  = [14, 12, 18, -4, 16, 13];
  $bench = [7,   9,  12, -8,  9,  8];
  $max   = max(array_merge(array_map('abs',$port),array_map('abs',$bench))) + 4;
  ?>
  <section class="fin-section fin-performance"
           aria-labelledby="fin-perf-h">
    <div class="fin-container">
      <div class="fin-performance__inner">

        <!-- Chart panel -->
        <div class="fin-perf-panel">
          <div class="fin-perf-panel__header">
            <span class="fin-perf-panel__title"><?php esc_html_e( 'Annual Returns', 'themeflex' ); ?></span>
            <div class="fin-perf-period" role="group" aria-label="<?php esc_attr_e( 'Time period', 'themeflex' ); ?>">
              <button class="fin-perf-period-btn" type="button">1Y</button>
              <button class="fin-perf-period-btn" type="button">3Y</button>
              <button class="fin-perf-period-btn active" type="button">5Y</button>
              <button class="fin-perf-period-btn" type="button">All</button>
            </div>
          </div>

          <div class="fin-perf-bars" role="img"
               aria-label="<?php esc_attr_e( 'Bar chart showing annual portfolio vs benchmark returns', 'themeflex' ); ?>">
            <?php foreach ($years as $yi => $yr): ?>
            <?php
            $pv = $port[$yi];
            $bv = $bench[$yi];
            $ph = abs($pv)/$max*100;
            $bh = abs($bv)/$max*100;
            $pc = $pv >= 0 ? '#22c55e' : '#ef4444';
            $bc = 'rgba(56,189,248,.4)';
            $del = ($yi * 0.1) . 's';
            $del2 = ($yi * 0.1 + 0.05) . 's';
            ?>
            <div class="fin-perf-bar-wrap">
              <div class="fin-perf-bar"
                   style="height:<?php echo intval($ph); ?>%;background:<?php echo esc_attr($pc); ?>;--del:<?php echo esc_attr($del); ?>;"
                   aria-label="<?php echo esc_attr($yr.' portfolio '.($pv>0?'+':'').$pv.'%'); ?>"></div>
              <div class="fin-perf-bar"
                   style="height:<?php echo intval($bh); ?>%;background:<?php echo esc_attr($bc); ?>;--del:<?php echo esc_attr($del2); ?>;"
                   aria-label="<?php echo esc_attr($yr.' benchmark '.($bv>0?'+':'').$bv.'%'); ?>"></div>
              <span class="fin-perf-bar-lbl"><?php echo esc_html($yr); ?></span>
            </div>
            <?php endforeach; ?>
          </div>

          <div class="fin-perf-legend">
            <div class="fin-legend-item">
              <div class="fin-legend-dot" style="background:#22c55e;"></div>
              <?php esc_html_e( 'Meridian Portfolio', 'themeflex' ); ?>
            </div>
            <div class="fin-legend-item">
              <div class="fin-legend-dot" style="background:rgba(56,189,248,.5);"></div>
              <?php esc_html_e( 'Benchmark (MSCI World)', 'themeflex' ); ?>
            </div>
          </div>

          <div class="fin-returns">
            <div class="fin-return">
              <div class="fin-return__val">+12.4%</div>
              <div class="fin-return__lbl">5-Year Avg</div>
            </div>
            <div class="fin-return">
              <div class="fin-return__val">1.84</div>
              <div class="fin-return__lbl">Sharpe Ratio</div>
            </div>
            <div class="fin-return">
              <div class="fin-return__val">-8.2%</div>
              <div class="fin-return__lbl">Max Drawdown</div>
            </div>
          </div>
        </div>

        <!-- Copy -->
        <div class="fin-performance__copy">
          <div class="fin-label">
            <span class="fin-label-dot" aria-hidden="true"></span>
            <?php esc_html_e( 'Our Investment Philosophy', 'themeflex' ); ?>
          </div>
          <h2 class="fin-h2" id="fin-perf-h">
            <?php esc_html_e( 'Consistent Outperformance, Managed Risk', 'themeflex' ); ?>
          </h2>
          <p class="fin-lead">
            <?php esc_html_e( 'Our discretionary portfolios have outperformed the MSCI World index by an average of 4.2% per year over the past decade — with a Sharpe ratio of 1.84, reflecting superior risk-adjusted returns.', 'themeflex' ); ?>
          </p>

          <div class="fin-pillars">
            <?php
            $pillars = [
              [ 'icon'=>'pie-chart',      'title'=>__('Strategic Asset Allocation','themeflex'),     'desc'=>__('Evidence-based allocation across asset classes anchored to your long-term goals — not market noise.','themeflex') ],
              [ 'icon'=>'shield',         'title'=>__('Downside Protection','themeflex'),            'desc'=>__('Rigorous drawdown management through diversification, hedging, and volatility overlays.','themeflex') ],
              [ 'icon'=>'leaf',           'title'=>__('ESG & Responsible Investing','themeflex'),   'desc'=>__('Integration of environmental, social, and governance criteria without compromising returns.','themeflex') ],
              [ 'icon'=>'refresh-cw',     'title'=>__('Active Rebalancing','themeflex'),             'desc'=>__('Continuous monitoring and dynamic rebalancing to exploit market opportunities.','themeflex') ],
            ];
            foreach ($pillars as $p):
            ?>
            <div class="fin-pillar">
              <div class="fin-pillar__icon" aria-hidden="true">
                <?php tf_icon($p['icon'],16); ?>
              </div>
              <div>
                <div class="fin-pillar__title"><?php echo esc_html($p['title']); ?></div>
                <div class="fin-pillar__desc"><?php echo esc_html($p['desc']); ?></div>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>

      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // ADVISORS
  // ============================================================
  $advisors = [
    [ 'init'=>'HV','bg'=>'linear-gradient(135deg,#22c55e,#15803d)','name'=>'Dr. Hans Vogt','title'=>__('Chief Investment Officer','themeflex'),'spec'=>__('30 years in institutional asset management. Former CIO at Deutsche Bank Private Bank.','themeflex'),'aum'=>'€1.4B AUM' ],
    [ 'init'=>'SK','bg'=>'linear-gradient(135deg,#38bdf8,#0284c7)','name'=>'Sabine Kohl','title'=>__('Head of Private Banking','themeflex'),'spec'=>__('Specialist in family wealth and cross-border estate planning with clients in 22 countries.','themeflex'),'aum'=>'€980M AUM' ],
    [ 'init'=>'FR','bg'=>'linear-gradient(135deg,#f59e0b,#b45309)','name'=>'Florian Roth','title'=>__('Alternatives Director','themeflex'),'spec'=>__('Private equity, hedge fund, and real asset allocation specialist. 18 years in alternative investing.','themeflex'),'aum'=>'€760M AUM' ],
    [ 'init'=>'AK','bg'=>'linear-gradient(135deg,#a855f7,#7c3aed)','name'=>'Anna Kluge','title'=>__('ESG & Impact Advisor','themeflex'),'spec'=>__('Pioneer in responsible investing. Developed award-winning ESG integration methodology at Meridian.','themeflex'),'aum'=>'€680M AUM' ],
  ];
  ?>
  <section class="fin-section fin-advisors"
           aria-labelledby="fin-advisors-h">
    <div class="fin-container">
      <div class="fin-label">
        <span class="fin-label-dot" aria-hidden="true"></span>
        <?php esc_html_e( 'Your Team', 'themeflex' ); ?>
      </div>
      <h2 class="fin-h2" id="fin-advisors-h"><?php esc_html_e( 'Senior Wealth Advisors', 'themeflex' ); ?></h2>
      <p class="fin-lead"><?php esc_html_e( 'Each client is assigned a dedicated senior advisor — not a call centre, but a trusted partner who knows your full financial picture.', 'themeflex' ); ?></p>

      <div class="fin-advisors__grid">
        <?php foreach ($advisors as $adv): ?>
        <div class="fin-advisor-card">
          <div class="fin-advisor-card__av" style="background:<?php echo esc_attr($adv['bg']); ?>;">
            <?php echo esc_html($adv['init']); ?>
          </div>
          <div class="fin-advisor-card__name"><?php echo esc_html($adv['name']); ?></div>
          <div class="fin-advisor-card__title"><?php echo esc_html($adv['title']); ?></div>
          <p class="fin-advisor-card__spec"><?php echo esc_html($adv['spec']); ?></p>
          <span class="fin-advisor-card__aum">
            <?php tf_icon('trending-up',12); ?>
            <?php echo esc_html($adv['aum']); ?>
          </span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // TESTIMONIALS
  // ============================================================
  $testimonials = [
    [ 'text'=>__('Meridian has been managing my family\'s wealth for 12 years. Our portfolio has doubled in real terms, and Hans always picks up the phone. The level of trust is unlike anything I\'ve experienced elsewhere.','themeflex'), 'init'=>'WB','bg'=>'#22c55e','name'=>'Wolfgang Baum','role'=>__('Entrepreneur & Investor · Client since 2012','themeflex'), 'result'=>'+108% real return' ],
    [ 'text'=>__('After the sale of my business, I needed someone who could manage a complex multi-jurisdiction situation. Sabine\'s estate planning expertise was invaluable. Meridian saved us significant tax and legal costs.','themeflex'), 'init'=>'MF','bg'=>'#38bdf8','name'=>'Martina Fischer','role'=>__('Business Owner · Client since 2018','themeflex'), 'result'=>'€2.4M tax saved' ],
    [ 'text'=>__('The access to private equity co-investments through Florian\'s team has been exceptional. I\'m now in deals I could never access as an individual investor. Returns have consistently beaten my public portfolio.','themeflex'), 'init'=>'TL','bg'=>'#a855f7','name'=>'Thomas Lang','role'=>__('Family Office · Client since 2015','themeflex'), 'result'=>'24% IRR PE portfolio' ],
  ];
  ?>
  <section class="fin-section fin-testimonials"
           aria-labelledby="fin-testi-h">
    <div class="fin-container">
      <div class="fin-label">
        <span class="fin-label-dot" aria-hidden="true"></span>
        <?php esc_html_e( 'Client Stories', 'themeflex' ); ?>
      </div>
      <h2 class="fin-h2" id="fin-testi-h"><?php esc_html_e( 'Trusted by Europe\'s Leading Families', 'themeflex' ); ?></h2>

      <div class="fin-testimonials__grid">
        <?php foreach ($testimonials as $t): ?>
        <div class="fin-testi-card">
          <div class="fin-testi-card__stars" aria-label="5 stars">
            <?php for($i=0;$i<5;$i++) tf_icon('star',14); ?>
          </div>
          <p class="fin-testi-card__text"><?php echo esc_html($t['text']); ?></p>
          <div class="fin-testi-card__footer">
            <div class="fin-testi-card__av" style="background:<?php echo esc_attr($t['bg']); ?>;">
              <?php echo esc_html($t['init']); ?>
            </div>
            <div>
              <div class="fin-testi-card__name"><?php echo esc_html($t['name']); ?></div>
              <div class="fin-testi-card__role"><?php echo esc_html($t['role']); ?></div>
            </div>
            <span class="fin-testi-card__result"><?php echo esc_html($t['result']); ?></span>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // CONSULTATION FORM
  // ============================================================
  ?>
  <section class="fin-section fin-consult" id="consult"
           aria-labelledby="fin-consult-h">
    <div class="fin-container">
      <div class="fin-consult__inner">

        <!-- Info -->
        <div class="fin-consult__info">
          <div class="fin-label">
            <span class="fin-label-dot" aria-hidden="true"></span>
            <?php esc_html_e( 'Begin Your Journey', 'themeflex' ); ?>
          </div>
          <h2 class="fin-h2" id="fin-consult-h">
            <?php esc_html_e( 'Book a Complimentary Consultation', 'themeflex' ); ?>
          </h2>
          <p class="fin-lead">
            <?php esc_html_e( 'Speak with a senior advisor at no obligation. We\'ll review your financial situation, discuss your goals, and outline how Meridian can add meaningful value.', 'themeflex' ); ?>
          </p>

          <div class="fin-trust-list">
            <?php
            $trusts = [
              [ 'icon'=>'calendar',    'title'=>__('60-Minute Discovery Meeting','themeflex'),  'desc'=>__('In-person or video call — your choice. No fee, no commitment.','themeflex') ],
              [ 'icon'=>'shield',      'title'=>__('Strict Confidentiality','themeflex'),       'desc'=>__('All information shared is subject to strict NDA and banking secrecy.','themeflex') ],
              [ 'icon'=>'clock',       'title'=>__('Response within 24 Hours','themeflex'),     'desc'=>__('A senior advisor will contact you the next business day.','themeflex') ],
              [ 'icon'=>'file-text',   'title'=>__('Personalised Portfolio Proposal','themeflex'),'desc'=>__('Within 10 days of our meeting, we deliver a tailored proposal.','themeflex') ],
            ];
            foreach ($trusts as $tr):
            ?>
            <div class="fin-trust-item">
              <div class="fin-trust-item__icon" aria-hidden="true">
                <?php tf_icon($tr['icon'],15); ?>
              </div>
              <div>
                <div class="fin-trust-item__title"><?php echo esc_html($tr['title']); ?></div>
                <div class="fin-trust-item__desc"><?php echo esc_html($tr['desc']); ?></div>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>

        <!-- Form -->
        <form class="fin-form" method="post" novalidate
              aria-label="<?php esc_attr_e( 'Consultation booking form', 'themeflex' ); ?>">
          <?php wp_nonce_field('fin_consult_enquiry','fin_consult_nonce'); ?>

          <h3 class="fin-form__title"><?php esc_html_e( 'Request a Meeting', 'themeflex' ); ?></h3>
          <p class="fin-form__sub"><?php esc_html_e( 'Qualified clients with €500K+ investable assets.', 'themeflex' ); ?></p>

          <div class="fin-form__row">
            <div class="fin-field">
              <label for="fin-first"><?php esc_html_e('First Name','themeflex'); ?></label>
              <input type="text" id="fin-first" name="first_name" required autocomplete="given-name"
                     placeholder="<?php esc_attr_e('Hans','themeflex'); ?>">
            </div>
            <div class="fin-field">
              <label for="fin-last"><?php esc_html_e('Last Name','themeflex'); ?></label>
              <input type="text" id="fin-last" name="last_name" required autocomplete="family-name"
                     placeholder="<?php esc_attr_e('Vogt','themeflex'); ?>">
            </div>
          </div>

          <div class="fin-form__row">
            <div class="fin-field">
              <label for="fin-email"><?php esc_html_e('Email','themeflex'); ?></label>
              <input type="email" id="fin-email" name="email" required autocomplete="email"
                     placeholder="hans@example.com">
            </div>
            <div class="fin-field">
              <label for="fin-phone"><?php esc_html_e('Phone','themeflex'); ?></label>
              <input type="tel" id="fin-phone" name="phone" autocomplete="tel"
                     placeholder="+49 89 123 456">
            </div>
          </div>

          <div class="fin-field">
            <label><?php esc_html_e('Investable Assets','themeflex'); ?></label>
            <div class="fin-form__assets" role="group" aria-label="<?php esc_attr_e('Select asset range','themeflex'); ?>">
              <?php
              $assets = [
                'a1'=>['val'=>'500k-1m',    'label'=>'€500K – €1M'],
                'a2'=>['val'=>'1m-3m',      'label'=>'€1M – €3M'],
                'a3'=>['val'=>'3m-10m',     'label'=>'€3M – €10M'],
                'a4'=>['val'=>'10m-30m',    'label'=>'€10M – €30M'],
                'a5'=>['val'=>'over-30m',   'label'=>'Over €30M'],
                'a6'=>['val'=>'to-discuss', 'label'=>'Prefer to discuss'],
              ];
              foreach ($assets as $id => $a):
              ?>
              <input type="radio" class="fin-asset-opt" name="assets"
                     id="fin-<?php echo esc_attr($id); ?>"
                     value="<?php echo esc_attr($a['val']); ?>">
              <label for="fin-<?php echo esc_attr($id); ?>">
                <?php echo esc_html($a['label']); ?>
              </label>
              <?php endforeach; ?>
            </div>
          </div>

          <div class="fin-field">
            <label for="fin-service"><?php esc_html_e('Primary Interest','themeflex'); ?></label>
            <select id="fin-service" name="service">
              <option value="" disabled selected><?php esc_html_e('Select service…','themeflex'); ?></option>
              <option value="wealth"><?php esc_html_e('Wealth Management','themeflex'); ?></option>
              <option value="banking"><?php esc_html_e('Private Banking','themeflex'); ?></option>
              <option value="estate"><?php esc_html_e('Estate & Tax Planning','themeflex'); ?></option>
              <option value="alternatives"><?php esc_html_e('Alternative Investments','themeflex'); ?></option>
              <option value="family-office"><?php esc_html_e('Family Office Services','themeflex'); ?></option>
              <option value="pension"><?php esc_html_e('Pension & Retirement','themeflex'); ?></option>
            </select>
          </div>

          <p class="fin-form__disclaimer">
            <?php esc_html_e('Past performance is not indicative of future results. All investments involve risk. Meridian Capital Partners is authorised by the FCA. Your information is processed pursuant to GDPR.','themeflex'); ?>
          </p>

          <button type="submit" class="fin-btn fin-btn--primary" style="width:100%;justify-content:center;">
            <?php tf_icon('calendar',16); ?>
            <?php esc_html_e('Book My Complimentary Consultation','themeflex'); ?>
          </button>
        </form>

      </div>
    </div>
  </section>

  <?php
  // ============================================================
  // CTA
  // ============================================================
  ?>
  <section class="fin-cta" aria-label="<?php esc_attr_e('Call to action','themeflex'); ?>">
    <div class="fin-container fin-cta__inner">
      <div class="fin-cta__eyebrow">
        <?php tf_icon('shield-check',14); ?>
        <?php esc_html_e('FCA Regulated · €4.2B AUM · 37 Years of Excellence','themeflex'); ?>
      </div>
      <h2 class="fin-cta__h2"><?php esc_html_e('Your Wealth Deserves Expert Care','themeflex'); ?></h2>
      <p class="fin-cta__sub">
        <?php esc_html_e('More than 1,200 families across Europe trust Meridian Capital Partners to grow, protect, and transfer their wealth. Begin the conversation today.','themeflex'); ?>
      </p>
      <div class="fin-cta__btns">
        <a href="#consult" class="fin-btn fin-btn--primary">
          <?php tf_icon('calendar',18); ?>
          <?php esc_html_e('Book a Consultation','themeflex'); ?>
        </a>
        <a href="tel:+4989123456" class="fin-btn fin-btn--outline">
          <?php tf_icon('phone',18); ?>
          +49 89 123 456
        </a>
      </div>
    </div>
  </section>

</main>

<script>
/* Finance page — animated stat counters */
(function(){
  'use strict';
  function animateCounter(el){
    const rawStr = el.dataset.counter;
    const suffix = el.dataset.suffix||'';
    // Handle decimal numbers
    const hasDecimal = rawStr.includes('.');
    const num = parseFloat(rawStr.replace(/,/g,''));
    const dur = 1600;
    let start;
    function step(ts){
      if(!start) start=ts;
      const p=Math.min((ts-start)/dur,1);
      const ease=1-Math.pow(1-p,3);
      const val = ease*num;
      el.textContent=(hasDecimal?val.toFixed(1):Math.round(val).toLocaleString('de-DE'))+suffix;
      if(p<1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }
  const counters=document.querySelectorAll('.tf-fin-page [data-counter]');
  if(!counters.length) return;
  const obs=new IntersectionObserver(function(entries){
    entries.forEach(function(e){
      if(e.isIntersecting){ animateCounter(e.target); obs.unobserve(e.target); }
    });
  },{threshold:0.5});
  counters.forEach(function(c){obs.observe(c);});
})();
</script>

<?php get_footer(); ?>
