<?php
/**
 * Template Name: Financial Adviser
 * Description: Premium page template for Independent Financial Adviser (IFA) businesses
 *
 * @package ThemeFlex
 */

// Fonts: Libre Baskerville + DM Sans
// Namespace: --fa-*
// Hero: CSS animated compound growth chart — rising line graph with glowing data points, floating coin piles, growth arrow
// Palette: deep forest #1B3A2D / gold leaf #C9A84C / cream stone #F8F5EE / muted sage #5A7A65 / charcoal #2D2D2D

if ( ! defined( 'ABSPATH' ) ) exit;
srand( crc32( get_the_permalink() ) );

$fa_services = [
    [ 'icon' => '🏠', 'title' => 'Pension Planning',          'desc' => 'Workplace pensions, SIPPs, drawdown strategies and retirement income planning to secure the retirement you deserve.' ],
    [ 'icon' => '📈', 'title' => 'Investment Management',     'desc' => 'Discretionary and advisory investment portfolios built around your risk profile, goals and time horizon.' ],
    [ 'icon' => '🛡️', 'title' => 'Protection & Insurance',   'desc' => 'Life insurance, critical illness cover, income protection and business protection to safeguard what matters most.' ],
    [ 'icon' => '🏡', 'title' => 'Mortgage Advice',           'desc' => 'Whole-of-market mortgage sourcing for residential purchase, remortgage, buy-to-let and complex income cases.' ],
    [ 'icon' => '📋', 'title' => 'Inheritance Tax Planning',  'desc' => 'Wills, trusts, gifting strategies and IHT mitigation to protect your estate and pass on more to those you love.' ],
    [ 'icon' => '💼', 'title' => 'Business Financial Planning','desc' => 'Shareholder protection, relevant life policies, auto-enrolment compliance and director\'s pension strategies.' ],
    [ 'icon' => '📊', 'title' => 'ISA & Tax Wrappers',        'desc' => 'Stocks & Shares ISAs, Lifetime ISAs, Junior ISAs and General Investment Accounts — maximising your annual allowances.' ],
    [ 'icon' => '🎓', 'title' => 'Education & Wealth Transfer','desc' => 'Child savings plans, trust arrangements and intergenerational wealth transfer strategies for families.' ],
];

$fa_areas = [
    'Retirement Planning', 'Drawdown Strategy', 'Annuity Options', 'SIPP',
    'Stocks & Shares ISA', 'Lifetime ISA', 'Junior ISA', 'General Investment',
    'Life Insurance', 'Critical Illness', 'Income Protection', 'Relevant Life',
    'IHT Mitigation', 'Trusts & Wills', 'Estate Planning', 'Gifting Strategy',
    'Buy-to-Let Finance', 'Equity Release', 'Business Protection', 'Auto-Enrolment',
    'VCT / EIS', 'Remortgage',
];

$fa_process = [
    [ 'step' => '01', 'title' => 'Discovery Meeting',  'desc' => 'A free, no-obligation 60-minute meeting to understand your goals, assets, liabilities and financial priorities.' ],
    [ 'step' => '02', 'title' => 'Research & Analysis','desc' => 'We carry out a full fact-find, research the whole market and stress-test options against your circumstances.' ],
    [ 'step' => '03', 'title' => 'Bespoke Report',     'desc' => 'A clear, jargon-free personal financial plan setting out our recommendations with full rationale and costs.' ],
    [ 'step' => '04', 'title' => 'Implementation',     'desc' => 'We handle the paperwork, applications and transfers — minimising disruption and keeping you fully informed.' ],
    [ 'step' => '05', 'title' => 'Ongoing Reviews',    'desc' => 'Annual review meetings, quarterly portfolio reports and proactive contact whenever regulation or markets change.' ],
];

$fa_testimonials = [
    [ 'name' => 'Patrick & Ruth Hennessey', 'role' => 'Retiring Couple · Surrey',   'text' => 'We came in with three separate pensions, no strategy and a lot of anxiety about retirement. The team consolidated everything, maximised our income and we retired two years earlier than planned. Couldn\'t recommend highly enough.' ],
    [ 'name' => 'Naomi Clarke',             'role' => 'Business Owner · Manchester', 'text' => 'Brilliant at the complex stuff — director\'s pension, relevant life policy and shareholder protection all sorted in one sitting. The ongoing service is proactive and they actually call us, rather than waiting for us to chase.' ],
    [ 'name' => 'David Tan',                'role' => 'Self-Employed · London',      'text' => 'I\'d been putting off sorting my pension for years. One discovery call and everything was in motion. They explained every option clearly, never oversold, and the outcome has been transformative for my family\'s long-term security.' ],
];

$fa_packages = [
    [
        'name'     => 'One-Off Advice',
        'price'    => '£750',
        'period'   => 'single area of advice',
        'featured' => false,
        'items'    => [ 'Initial fact-find session', 'Research & analysis', 'Written suitability report', 'Implementation support', 'Follow-up Q&A session' ],
    ],
    [
        'name'     => 'Full Financial Plan',
        'price'    => '£1,800',
        'period'   => 'comprehensive review',
        'featured' => true,
        'items'    => [ 'All areas of planning reviewed', 'Full fact-find & risk assessment', 'Written financial plan report', 'Whole-of-market research', 'Implementation & paperwork', 'First annual review included', 'Priority client access' ],
    ],
    [
        'name'     => 'Ongoing Partnership',
        'price'    => '£150/mo',
        'period'   => 'retained service',
        'featured' => false,
        'items'    => [ 'Annual planning review', 'Quarterly portfolio reports', 'Proactive regulatory updates', 'Unlimited ad-hoc queries', 'Tax year planning each April', 'Priority call-back within 4hrs' ],
    ],
];

$fa_counters = [
    [ 'value' => 26,    'suffix' => 'yrs',  'label' => 'Established',          'float' => false ],
    [ 'value' => 340,   'suffix' => 'M+',   'label' => 'Assets Under Advice',  'float' => false ],
    [ 'value' => 4.9,   'suffix' => '★',   'label' => 'Google Rating',         'float' => true  ],
    [ 'value' => 97,    'suffix' => '%',    'label' => 'Client Retention',      'float' => false ],
];

// Growth chart data points (percentage heights for visual chart bars)
$fa_chart_points = [ 18, 22, 19, 27, 31, 29, 38, 43, 40, 52, 58, 56, 67, 73, 71, 82, 88, 85, 94 ];
$fa_chart_labels = [ "'09","'10","'11","'12","'13","'14","'15","'16","'17","'18","'19","'20","'21","'22","'23","'24" ];

// Floating coin particles
$fa_coins = [];
for ( $i = 0; $i < 14; $i++ ) {
    $fa_coins[] = [
        'x'     => rand( 0, 100 ),
        'y'     => rand( 0, 100 ),
        'size'  => rand( 8, 18 ),
        'dur'   => rand( 3000, 6000 ),
        'delay' => rand( 0, 4000 ),
        'char'  => [ '£', '$', '€', '¥' ][ rand(0,3) ],
    ];
}
?>
?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&family=DM+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
/* ============================================================
   FINANCIAL ADVISER TEMPLATE — --fa-* namespace
   Libre Baskerville + DM Sans
   Palette: forest #1B3A2D / gold #C9A84C / cream #F8F5EE / sage #5A7A65 / charcoal #2D2D2D
   ============================================================ */

:root {
    --fa-forest  : #1B3A2D;
    --fa-gold    : #C9A84C;
    --fa-cream   : #F8F5EE;
    --fa-sage    : #5A7A65;
    --fa-charcoal: #2D2D2D;
    --fa-dark    : #0F2218;
    --fa-mid     : #162D22;
    --fa-muted   : #7A9B87;
    --fa-border  : rgba(201,168,76,.22);
    --fa-font-h  : 'Libre Baskerville', Georgia, serif;
    --fa-font-b  : 'DM Sans', sans-serif;
    --fa-radius  : 8px;
    --fa-shadow  : 0 4px 24px rgba(0,0,0,.2);
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
.fa-page { font-family: var(--fa-font-b); color: var(--fa-charcoal); background: var(--fa-cream); line-height: 1.65; }
.fa-page h1, .fa-page h2, .fa-page h3, .fa-page h4 { font-family: var(--fa-font-h); }
.fa-container { max-width: 1200px; margin: 0 auto; padding: 0 24px; }
.fa-section    { padding: 88px 0; }
.fa-section--dark  { background: var(--fa-dark);  color: #fff; }
.fa-section--mid   { background: var(--fa-mid);   color: #fff; }
.fa-section--cream { background: var(--fa-cream); }
.fa-section--white { background: #fff; }
.fa-btn {
    display: inline-block; padding: 14px 32px; border-radius: var(--fa-radius);
    font-family: var(--fa-font-b); font-size: .95rem; font-weight: 600; letter-spacing: .04em;
    text-decoration: none; cursor: pointer; border: none; transition: transform .2s, box-shadow .2s;
}
.fa-btn:hover { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(0,0,0,.2); }
.fa-btn--gold    { background: var(--fa-gold); color: var(--fa-forest); }
.fa-btn--outline { background: transparent; border: 2px solid rgba(201,168,76,.6); color: var(--fa-gold); }
.fa-section-label {
    font-family: var(--fa-font-b); font-size: .75rem; font-weight: 600;
    letter-spacing: .16em; color: var(--fa-gold); text-transform: uppercase; margin-bottom: 10px;
}
.fa-section-title { font-size: clamp(1.9rem, 3.5vw, 2.6rem); margin-bottom: 16px; line-height: 1.2; }
.fa-section-sub   { font-size: 1.02rem; opacity: .72; max-width: 560px; line-height: 1.75; }

/* ---- HERO ---- */
.fa-hero {
    position: relative; min-height: 100vh; overflow: hidden;
    background: var(--fa-forest);
    display: flex; align-items: center;
}
/* Subtle grid overlay */
.fa-hero::before {
    content: ''; position: absolute; inset: 0; pointer-events: none;
    background-image: repeating-linear-gradient(0deg, rgba(255,255,255,.025) 0, rgba(255,255,255,.025) 1px, transparent 1px, transparent 60px),
                      repeating-linear-gradient(90deg, rgba(255,255,255,.025) 0, rgba(255,255,255,.025) 1px, transparent 1px, transparent 60px);
}
/* Floating currency symbols */
.fa-coin {
    position: absolute; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-family: var(--fa-font-h); font-weight: 700; color: var(--fa-gold);
    background: rgba(201,168,76,.08); border: 1px solid rgba(201,168,76,.2);
    pointer-events: none;
}
@keyframes fa-coin-drift {
    0%  { transform: translateY(0) rotate(0deg); opacity: .5; }
    50% { transform: translateY(-24px) rotate(180deg); opacity: .8; }
    100%{ transform: translateY(0) rotate(360deg); opacity: .5; }
}
.fa-coin { animation: fa-coin-drift var(--fa-cdur,4s) var(--fa-cdelay,0ms) infinite ease-in-out; }

.fa-hero__inner {
    position: relative; z-index: 2;
    display: grid; grid-template-columns: 1fr 520px; gap: 60px; align-items: center;
    max-width: 1200px; margin: 0 auto; padding: 120px 24px 80px; width: 100%;
}
.fa-hero__badge {
    display: inline-flex; align-items: center; gap: 8px;
    background: rgba(201,168,76,.12); border: 1px solid rgba(201,168,76,.3);
    border-radius: 4px; padding: 6px 16px; margin-bottom: 20px;
    font-size: .78rem; font-weight: 600; letter-spacing: .1em; color: var(--fa-gold);
    font-family: var(--fa-font-b);
}
.fa-hero__heading {
    font-size: clamp(2.4rem,5vw,3.6rem); line-height: 1.15;
    color: #fff; margin-bottom: 20px; font-weight: 700;
}
.fa-hero__heading em { color: var(--fa-gold); font-style: italic; }
.fa-hero__sub { font-size: 1.08rem; color: rgba(255,255,255,.72); margin-bottom: 32px; line-height: 1.75; }
.fa-hero__cta { display: flex; gap: 16px; flex-wrap: wrap; }
/* FCA disclaimer in hero */
.fa-hero__disclaimer {
    margin-top: 24px; font-size: .72rem; color: rgba(255,255,255,.38); line-height: 1.5;
    max-width: 480px;
}

/* ---- GROWTH CHART SCENE ---- */
.fa-chart-scene {
    position: relative; width: 520px; height: 440px; flex-shrink: 0;
}
/* Chart panel */
.fa-chart-panel {
    position: absolute; inset: 0;
    background: rgba(255,255,255,.04); border: 1px solid rgba(201,168,76,.2);
    border-radius: 12px; overflow: hidden; padding: 24px 20px 48px;
    backdrop-filter: blur(4px);
}
.fa-chart-panel__title {
    font-family: var(--fa-font-b); font-size: .7rem; font-weight: 600;
    letter-spacing: .12em; color: var(--fa-gold); text-transform: uppercase;
    margin-bottom: 4px;
}
.fa-chart-panel__val {
    font-family: var(--fa-font-h); font-size: 1.8rem; color: #fff; margin-bottom: 20px;
}
.fa-chart-panel__val span { font-size: 1rem; color: #5cb85c; margin-left: 6px; }

/* Bars / columns */
.fa-bars {
    display: flex; align-items: flex-end; gap: 4px;
    height: 220px; position: relative;
}
/* Y-axis gridlines */
.fa-bars::before {
    content: ''; position: absolute; inset: 0;
    background: repeating-linear-gradient(0deg, rgba(255,255,255,.08) 0, rgba(255,255,255,.08) 1px, transparent 1px, transparent 25%);
    pointer-events: none;
}
.fa-bar-wrap { display: flex; flex-direction: column; align-items: center; flex: 1; }
.fa-bar {
    width: 100%; border-radius: 3px 3px 0 0;
    background: linear-gradient(180deg, var(--fa-gold) 0%, rgba(201,168,76,.4) 100%);
    position: relative; transition: height 1.2s ease;
}
/* Glow dot at top of bar */
.fa-bar::after {
    content: ''; position: absolute; top: -4px; left: 50%; transform: translateX(-50%);
    width: 8px; height: 8px; border-radius: 50%;
    background: var(--fa-gold); box-shadow: 0 0 8px var(--fa-gold);
}
/* Last bar highlighted */
.fa-bar--latest {
    background: linear-gradient(180deg, #5cb85c 0%, rgba(92,184,92,.4) 100%);
}
.fa-bar--latest::after { background: #5cb85c; box-shadow: 0 0 12px #5cb85c; }

/* X axis */
.fa-x-axis {
    display: flex; gap: 4px; margin-top: 8px; padding: 0 0;
}
.fa-x-label { flex: 1; text-align: center; font-size: .5rem; color: rgba(255,255,255,.4); }

/* Growth arrow overlay */
.fa-growth-arrow {
    position: absolute; top: 30px; right: 20px;
    font-family: var(--fa-font-b); font-size: .78rem; font-weight: 700;
    color: #5cb85c;
    display: flex; align-items: center; gap: 4px;
}
.fa-growth-arrow::before { content: '▲'; }
@keyframes fa-arrow-glow {
    0%,100%{ text-shadow: 0 0 8px rgba(92,184,92,.5); }
    50%     { text-shadow: 0 0 16px rgba(92,184,92,.9); }
}
.fa-growth-arrow { animation: fa-arrow-glow 2s infinite; }

/* Pie / donut chart (decorative allocation chart) */
.fa-donut-scene {
    position: absolute; bottom: 16px; right: 16px;
    width: 110px; height: 110px;
}
.fa-donut {
    width: 100%; height: 100%; border-radius: 50%;
    background: conic-gradient(
        var(--fa-gold) 0% 38%,
        var(--fa-sage) 38% 62%,
        #4A90D9 62% 78%,
        var(--fa-muted) 78% 90%,
        rgba(255,255,255,.2) 90% 100%
    );
    box-shadow: 0 0 20px rgba(0,0,0,.3);
}
.fa-donut::after {
    content: 'Portfolio'; position: absolute; inset: 20px; border-radius: 50%;
    background: #1B3A2D; display: flex; align-items: center; justify-content: center;
    font-size: .5rem; color: rgba(255,255,255,.5); font-weight: 600; letter-spacing: .06em;
    text-align: center; line-height: 1.3;
}

/* ---- TRUST BAR ---- */
.fa-trust-bar { background: var(--fa-gold); padding: 14px 0; }
.fa-trust-bar__inner {
    display: flex; justify-content: center; align-items: center;
    gap: 48px; flex-wrap: wrap;
}
.fa-trust-item {
    display: flex; align-items: center; gap: 9px;
    font-family: var(--fa-font-b); font-size: .85rem; font-weight: 600;
    letter-spacing: .04em; color: var(--fa-forest);
}
.fa-trust-item span { font-size: 1.1rem; }

/* ---- COUNTERS ---- */
.fa-counters { background: var(--fa-mid); padding: 56px 0; }
.fa-counters__grid {
    display: grid; grid-template-columns: repeat(4,1fr); gap: 24px;
    max-width: 1000px; margin: 0 auto; padding: 0 24px;
}
.fa-counter-card {
    text-align: center; padding: 32px 16px;
    background: rgba(255,255,255,.04); border: 1px solid var(--fa-border);
    border-radius: var(--fa-radius);
}
.fa-counter-card__val {
    font-family: var(--fa-font-h); font-size: 2.6rem; font-weight: 700;
    color: var(--fa-gold); line-height: 1.1;
    display: flex; align-items: baseline; justify-content: center; gap: 2px;
}
.fa-counter-card__suffix { font-size: 1.2rem; }
.fa-counter-card__label  { font-size: .84rem; color: rgba(255,255,255,.55); margin-top: 6px; }

/* ---- SERVICES ---- */
.fa-services-grid {
    display: grid; grid-template-columns: repeat(auto-fill,minmax(260px,1fr)); gap: 24px;
    margin-top: 48px;
}
.fa-service-card {
    background: #fff; border: 1px solid rgba(0,0,0,.07);
    border-radius: var(--fa-radius); padding: 28px; position: relative; overflow: hidden;
    transition: transform .25s, box-shadow .25s;
}
.fa-service-card::before {
    content: ''; position: absolute; inset: 0 0 auto 0;
    height: 4px; background: linear-gradient(90deg, var(--fa-gold), var(--fa-sage));
}
.fa-service-card:hover { transform: translateY(-4px); box-shadow: 0 12px 32px rgba(0,0,0,.1); }
.fa-service-card__icon  { font-size: 2rem; margin-bottom: 14px; }
.fa-service-card__title { font-family: var(--fa-font-h); font-size: 1rem; margin-bottom: 10px; }
.fa-service-card__desc  { font-size: .87rem; color: #666; line-height: 1.65; }

/* ---- AREAS CLOUD ---- */
.fa-areas { background: var(--fa-dark); }
.fa-tags-cloud { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 32px; }
.fa-tag {
    background: rgba(201,168,76,.1); border: 1px solid rgba(201,168,76,.22);
    color: rgba(255,255,255,.8); border-radius: 4px;
    padding: 6px 14px; font-size: .82rem; transition: background .2s;
}
.fa-tag:hover { background: rgba(201,168,76,.2); color: var(--fa-gold); }

/* ---- PROCESS ---- */
.fa-process { background: var(--fa-mid); }
.fa-process__steps {
    display: grid; grid-template-columns: repeat(5,1fr); gap: 0;
    position: relative; margin-top: 56px;
}
.fa-process__steps::before {
    content: ''; position: absolute; top: 28px; left: 10%; right: 10%; height: 3px;
    background: linear-gradient(90deg, var(--fa-gold), var(--fa-sage), var(--fa-gold));
    z-index: 0;
}
.fa-step { text-align: center; position: relative; z-index: 1; padding: 0 12px; }
.fa-step__num {
    width: 56px; height: 56px; border-radius: 50%; margin: 0 auto 20px;
    display: flex; align-items: center; justify-content: center;
    font-family: var(--fa-font-h); font-size: 1.1rem; font-weight: 700;
    background: var(--fa-mid); border: 3px solid var(--fa-gold); color: var(--fa-gold);
    box-shadow: 0 0 16px rgba(201,168,76,.25);
}
.fa-step__title { font-family: var(--fa-font-h); font-size: .88rem; font-weight: 700; color: #fff; margin-bottom: 8px; }
.fa-step__desc  { font-size: .78rem; color: rgba(255,255,255,.55); line-height: 1.6; }

/* ---- ADVISER CREDENTIAL ---- */
.fa-adviser-section { background: var(--fa-dark); }
.fa-adviser-wrap { display: grid; grid-template-columns: 300px 1fr; gap: 56px; align-items: center; }
/* CSS adviser figure */
.fa-adviser-figure { position: relative; height: 280px; }
.fa-adv__body {
    position: absolute; bottom: 0; left: 50%; transform: translateX(-50%);
    width: 76px; height: 130px;
    background: var(--fa-forest); border-radius: 8px 8px 4px 4px;
    border: 2px solid rgba(201,168,76,.3);
}
/* Suit jacket lapels */
.fa-adv__body::before {
    content: ''; position: absolute; top: 0; left: -2px; right: -2px; bottom: 50%;
    background: linear-gradient(160deg, var(--fa-forest) 45%, rgba(201,168,76,.25) 45%);
    border-radius: 6px 6px 0 0;
}
/* Tie */
.fa-adv__body::after {
    content: ''; position: absolute; top: 14px; left: 50%; transform: translateX(-50%);
    width: 10px; height: 50px;
    background: var(--fa-gold); clip-path: polygon(20% 0%,80% 0%,100% 60%,50% 100%,0% 60%);
}
.fa-adv__legs {
    position: absolute; bottom: 0; left: 50%; transform: translateX(-50%);
    display: flex; gap: 8px;
}
.fa-adv__leg {
    width: 28px; height: 60px;
    background: #1A1A30; border-radius: 0 0 4px 4px;
}
.fa-adv__head {
    position: absolute; bottom: 128px; left: 50%; transform: translateX(-50%);
    width: 50px; height: 52px;
    background: #C9956A; border-radius: 50% 50% 45% 45%;
}
/* Hair */
.fa-adv__head::before {
    content: ''; position: absolute; top: -4px; left: -3px; right: -3px; height: 22px;
    background: #3A2010; border-radius: 50% 50% 0 0;
}
.fa-adv__arm {
    position: absolute; bottom: 76px;
    width: 18px; height: 72px;
    background: var(--fa-forest); border-radius: 6px;
    border: 1px solid rgba(201,168,76,.2);
}
.fa-adv__arm--l { left: calc(50% - 55px); transform: rotate(12deg); transform-origin: top; }
.fa-adv__arm--r { right: calc(50% - 55px); transform: rotate(-12deg); transform-origin: top; }
/* Briefcase */
.fa-adv__briefcase {
    position: absolute; bottom: 10px; right: calc(50% - 72px);
    width: 30px; height: 24px;
    background: var(--fa-gold); border-radius: 4px;
    border: 2px solid rgba(201,168,76,.6);
}
.fa-adv__briefcase::before {
    content: ''; position: absolute; top: -8px; left: 6px; right: 6px;
    height: 8px; border: 2px solid var(--fa-gold); border-bottom: none;
    border-radius: 4px 4px 0 0;
}
.fa-adv__briefcase::after {
    content: ''; position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%);
    width: 12px; height: 2px; background: rgba(27,58,45,.6);
    box-shadow: 0 4px 0 rgba(27,58,45,.6);
}

.fa-adviser-info h3 { font-size: 1.8rem; color: #fff; margin-bottom: 4px; }
.fa-adviser-info h4 { font-size: .88rem; color: var(--fa-gold); font-family: var(--fa-font-b); letter-spacing: .06em; margin-bottom: 20px; font-weight: 600; }
.fa-adviser-info p  { color: rgba(255,255,255,.72); line-height: 1.75; margin-bottom: 20px; }
.fa-adviser-badges  { display: flex; flex-wrap: wrap; gap: 10px; }
.fa-badge {
    display: inline-flex; align-items: center; gap: 6px;
    background: rgba(201,168,76,.1); border: 1px solid rgba(201,168,76,.25);
    border-radius: 4px; padding: 6px 14px;
    font-size: .78rem; font-weight: 600; font-family: var(--fa-font-b);
    letter-spacing: .04em; color: var(--fa-gold);
}

/* ---- PACKAGES ---- */
.fa-packages-grid {
    display: grid; grid-template-columns: repeat(3,1fr); gap: 24px;
    margin-top: 48px; align-items: start;
}
.fa-package {
    background: #fff; border: 2px solid rgba(0,0,0,.07);
    border-radius: var(--fa-radius); padding: 32px; position: relative;
}
.fa-package--featured {
    background: var(--fa-forest); border-color: var(--fa-gold);
    box-shadow: 0 0 32px rgba(201,168,76,.18); transform: scale(1.03);
}
.fa-package__badge {
    position: absolute; top: -14px; left: 50%; transform: translateX(-50%);
    background: var(--fa-gold); color: var(--fa-forest);
    font-family: var(--fa-font-b); font-size: .72rem; font-weight: 700;
    letter-spacing: .1em; padding: 4px 16px; border-radius: 4px; white-space: nowrap;
}
.fa-package__name { font-family: var(--fa-font-h); font-size: 1.1rem; margin-bottom: 6px; }
.fa-package--featured .fa-package__name { color: #fff; }
.fa-package__price {
    font-family: var(--fa-font-h); font-size: 2.2rem; font-weight: 700;
    color: var(--fa-gold); margin: 12px 0 4px;
}
.fa-package__period { font-size: .78rem; color: #999; margin-bottom: 20px; }
.fa-package--featured .fa-package__period { color: rgba(255,255,255,.5); }
.fa-package__items { list-style: none; margin-bottom: 28px; }
.fa-package__items li {
    padding: 7px 0; font-size: .87rem; border-bottom: 1px solid rgba(0,0,0,.06);
    display: flex; gap: 8px; align-items: flex-start;
}
.fa-package--featured .fa-package__items li { border-color: rgba(255,255,255,.08); color: rgba(255,255,255,.82); }
.fa-package__items li::before { content: '✓'; color: var(--fa-gold); font-weight: 700; flex-shrink: 0; }
.fa-package__cta { display: block; text-align: center; }

/* ---- TESTIMONIALS ---- */
.fa-testi-grid {
    display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; margin-top: 48px;
}
.fa-testi {
    background: var(--fa-cream); border: 1px solid rgba(0,0,0,.07);
    border-radius: var(--fa-radius); padding: 28px;
}
.fa-testi__quote { font-size: 2.8rem; line-height: 1; color: var(--fa-gold); opacity: .4; margin-bottom: 6px; }
.fa-testi__stars { color: var(--fa-gold); margin-bottom: 10px; font-size: 1rem; }
.fa-testi__text  { font-size: .88rem; color: #555; line-height: 1.7; margin-bottom: 18px; font-style: italic; }
.fa-testi__name  { font-family: var(--fa-font-h); font-weight: 700; font-size: .88rem; color: var(--fa-forest); }
.fa-testi__role  { font-size: .78rem; color: var(--fa-muted); }

/* ---- DISCLAIMER ---- */
.fa-disclaimer-section { background: var(--fa-cream); border-top: 1px solid rgba(0,0,0,.08); padding: 40px 0; }
.fa-disclaimer-box {
    background: #fff; border: 1px solid rgba(0,0,0,.1); border-radius: var(--fa-radius);
    padding: 28px; font-size: .78rem; color: #888; line-height: 1.65; max-width: 900px; margin: 0 auto;
}
.fa-disclaimer-box strong { color: var(--fa-charcoal); display: block; margin-bottom: 8px; font-size: .82rem; }

/* ---- BOOKING ---- */
.fa-booking { background: var(--fa-dark); }
.fa-booking__wrap {
    display: grid; grid-template-columns: 1fr 1fr; gap: 56px; align-items: start;
}
.fa-booking__info h2 { color: #fff; margin-bottom: 16px; }
.fa-booking__info p  { color: rgba(255,255,255,.68); line-height: 1.75; margin-bottom: 24px; }
.fa-booking__bullets { list-style: none; }
.fa-booking__bullets li {
    padding: 10px 0; border-bottom: 1px solid rgba(255,255,255,.07);
    color: rgba(255,255,255,.75); font-size: .9rem;
    display: flex; gap: 10px; align-items: flex-start;
}
.fa-booking__bullets li::before { content: '📊'; flex-shrink: 0; }

.fa-form {
    background: var(--fa-mid); border: 1px solid var(--fa-border);
    border-radius: var(--fa-radius); padding: 36px;
}
.fa-form h3 { color: #fff; font-family: var(--fa-font-h); font-size: 1.35rem; margin-bottom: 24px; }
.fa-field    { margin-bottom: 18px; }
.fa-field label {
    display: block; font-size: .78rem; font-weight: 600; letter-spacing: .06em;
    color: rgba(255,255,255,.6); margin-bottom: 6px; text-transform: uppercase;
    font-family: var(--fa-font-b);
}
.fa-field input,
.fa-field select,
.fa-field textarea {
    width: 100%; padding: 11px 14px; border-radius: var(--fa-radius);
    background: var(--fa-dark); border: 1px solid var(--fa-border);
    color: #fff; font-family: var(--fa-font-b); font-size: .92rem;
    outline: none; transition: border-color .2s;
}
.fa-field input:focus,
.fa-field select:focus,
.fa-field textarea:focus { border-color: var(--fa-gold); }
.fa-field textarea { resize: vertical; min-height: 100px; }
.fa-field select option { background: var(--fa-dark); }
.fa-field-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.fa-form__submit {
    width: 100%; padding: 15px; background: var(--fa-gold); color: var(--fa-forest);
    border: none; border-radius: var(--fa-radius); font-family: var(--fa-font-b);
    font-size: 1rem; font-weight: 700; letter-spacing: .05em; cursor: pointer;
    transition: filter .2s, transform .2s;
}
.fa-form__submit:hover { filter: brightness(1.08); transform: translateY(-1px); }

/* ---- FOOTER ---- */
.fa-footer {
    background: var(--fa-dark); padding: 40px 0; text-align: center;
    border-top: 1px solid rgba(255,255,255,.05);
}
.fa-footer p { font-size: .78rem; color: rgba(255,255,255,.35); margin-bottom: 4px; }
.fa-footer__phone { font-family: var(--fa-font-h); font-size: 1.6rem; color: var(--fa-gold); margin-bottom: 8px; }

/* ---- RESPONSIVE ---- */
@media (max-width: 960px) {
    .fa-hero__inner     { grid-template-columns: 1fr; padding-top: 100px; }
    .fa-chart-scene     { width: 100%; max-width: 480px; height: 380px; margin: 0 auto; }
    .fa-counters__grid  { grid-template-columns: repeat(2,1fr); }
    .fa-process__steps  { grid-template-columns: 1fr; gap: 32px; }
    .fa-process__steps::before { display: none; }
    .fa-adviser-wrap    { grid-template-columns: 1fr; }
    .fa-adviser-figure  { height: 200px; margin: 0 auto 32px; }
    .fa-packages-grid   { grid-template-columns: 1fr; }
    .fa-package--featured { transform: none; }
    .fa-testi-grid      { grid-template-columns: 1fr; }
    .fa-booking__wrap   { grid-template-columns: 1fr; }
}
</style>
<?php get_header(); ?>

<div class="">

>

<!-- ═══════════════════════════════════════════════════════
     HERO — Compound Growth Chart Scene
     ═══════════════════════════════════════════════════════ -->
<section class="fa-hero" aria-label="Hero">

    <!-- Floating coins -->
    <?php foreach ( $fa_coins as $fc ) : ?>
        <div class="fa-coin" aria-hidden="true" style="
            left:<?php echo esc_attr($fc['x']); ?>%;
            top:<?php echo esc_attr($fc['y']); ?>%;
            width:<?php echo esc_attr($fc['size']); ?>px;
            height:<?php echo esc_attr($fc['size']); ?>px;
            font-size:<?php echo esc_attr( round($fc['size']*.55) ); ?>px;
            --fa-cdur:<?php echo esc_attr($fc['dur']); ?>ms;
            --fa-cdelay:<?php echo esc_attr($fc['delay']); ?>ms;
        "><?php echo esc_html($fc['char']); ?></div>
    <?php endforeach; ?>

    <div class="fa-hero__inner">
        <!-- Text -->
        <div>
            <div class="fa-hero__badge">FCA Authorised &amp; Regulated · Chartered Financial Planners</div>
            <h1 class="fa-hero__heading">
                <em>Independent</em><br>
                Financial Advice<br>
                Built Around You
            </h1>
            <p class="fa-hero__sub">
                Whole-of-market advice on pensions, investments, protection and estate planning from a Chartered firm with <?php echo date('Y') - 1998; ?> years of client-first service.
            </p>
            <div class="fa-hero__cta">
                <a href="#booking" class="fa-btn fa-btn--gold">Book a Free Consultation</a>
                <a href="tel:+441234567890" class="fa-btn fa-btn--outline">📞 Speak to an Adviser</a>
            </div>
            <p class="fa-hero__disclaimer">Past performance is not a reliable indicator of future results. The value of investments can go down as well as up. You may receive less than you invest.</p>
        </div>

        <!-- Growth chart scene -->
        <div class="fa-chart-scene" aria-hidden="true">
            <div class="fa-chart-panel">
                <div class="fa-chart-panel__title">Illustrative Long-Term Growth</div>
                <div class="fa-chart-panel__val">£348,400 <span>▲ +248%</span></div>

                <div class="fa-growth-arrow">+248% over 15 years</div>

                <div class="fa-bars" id="fa-bars">
                    <?php foreach ( $fa_chart_points as $idx => $ht ) :
                        $is_last = ( $idx === count($fa_chart_points) - 1 );
                    ?>
                        <div class="fa-bar-wrap">
                            <div class="fa-bar <?php echo $is_last ? 'fa-bar--latest' : ''; ?>"
                                 style="height:<?php echo esc_attr($ht); ?>%; transition-delay:<?php echo esc_attr($idx * 60); ?>ms;">
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="fa-x-axis">
                    <?php foreach ( $fa_chart_labels as $lbl ) : ?>
                        <div class="fa-x-label"><?php echo esc_html($lbl); ?></div>
                    <?php endforeach; ?>
                </div>

                <!-- Portfolio donut -->
                <div class="fa-donut-scene">
                    <div class="fa-donut"></div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     TRUST BAR
     ═══════════════════════════════════════════════════════ -->
<div class="fa-trust-bar" role="complementary">
    <div class="fa-trust-bar__inner fa-container">
        <div class="fa-trust-item"><span>🏅</span> Chartered Financial Planners</div>
        <div class="fa-trust-item"><span>🛡️</span> FCA Authorised &amp; Regulated</div>
        <div class="fa-trust-item"><span>📋</span> Whole-of-Market Access</div>
        <div class="fa-trust-item"><span>⭐</span> 26 Years of Service</div>
        <div class="fa-trust-item"><span>✅</span> FSCS Protected</div>
    </div>
</div>

<!-- ═══════════════════════════════════════════════════════
     COUNTERS
     ═══════════════════════════════════════════════════════ -->
<section class="fa-counters" aria-label="Key statistics">
    <div class="fa-counters__grid">
        <?php foreach ( $fa_counters as $ctr ) : ?>
            <div class="fa-counter-card">
                <div class="fa-counter-card__val">
                    <span class="fa-counter-num"
                          data-target="<?php echo esc_attr($ctr['value']); ?>"
                          data-suffix="<?php echo esc_attr($ctr['suffix']); ?>"
                          <?php if($ctr['float']) echo 'data-float="1"'; ?>>0</span>
                    <span class="fa-counter-card__suffix"><?php echo esc_html($ctr['suffix']); ?></span>
                </div>
                <div class="fa-counter-card__label"><?php echo esc_html($ctr['label']); ?></div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     SERVICES
     ═══════════════════════════════════════════════════════ -->
<section class="fa-section fa-section--cream" aria-labelledby="fa-services-title">
    <div class="fa-container">
        <div class="fa-section-label">Areas of Expertise</div>
        <h2 class="fa-section-title" id="fa-services-title">Financial Planning Services</h2>
        <p class="fa-section-sub">Comprehensive, independent advice across every area of personal and business financial planning.</p>
        <div class="fa-services-grid">
            <?php foreach ( $fa_services as $svc ) : ?>
                <div class="fa-service-card">
                    <div class="fa-service-card__icon"><?php echo esc_html($svc['icon']); ?></div>
                    <h3 class="fa-service-card__title"><?php echo esc_html($svc['title']); ?></h3>
                    <p class="fa-service-card__desc"><?php echo esc_html($svc['desc']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     AREAS CLOUD
     ═══════════════════════════════════════════════════════ -->
<section class="fa-section fa-areas" aria-labelledby="fa-areas-title">
    <div class="fa-container">
        <div class="fa-section-label" style="color:var(--fa-gold);">We Advise On</div>
        <h2 class="fa-section-title" id="fa-areas-title" style="color:#fff;">Every Aspect of Your Finances</h2>
        <p class="fa-section-sub" style="color:rgba(255,255,255,.6);">From first-time ISA investors to complex estate planning — our advisers cover the full spectrum of personal and business financial needs.</p>
        <div class="fa-tags-cloud" role="list">
            <?php foreach ( $fa_areas as $area ) : ?>
                <span class="fa-tag" role="listitem"><?php echo esc_html($area); ?></span>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     PROCESS
     ═══════════════════════════════════════════════════════ -->
<section class="fa-section fa-process" aria-labelledby="fa-process-title">
    <div class="fa-container">
        <div class="fa-section-label" style="color:var(--fa-gold);">Our Approach</div>
        <h2 class="fa-section-title" id="fa-process-title" style="color:#fff;">How We Work With You</h2>
        <p class="fa-section-sub" style="color:rgba(255,255,255,.58);">A disciplined, transparent advisory process — from free discovery meeting to ongoing annual review.</p>
        <div class="fa-process__steps">
            <?php foreach ( $fa_process as $ps ) : ?>
                <div class="fa-step">
                    <div class="fa-step__num"><?php echo esc_html($ps['step']); ?></div>
                    <div class="fa-step__title"><?php echo esc_html($ps['title']); ?></div>
                    <p class="fa-step__desc"><?php echo esc_html($ps['desc']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     LEAD ADVISER CREDENTIAL
     ═══════════════════════════════════════════════════════ -->
<section class="fa-section fa-adviser-section" aria-labelledby="fa-adviser-title">
    <div class="fa-container">
        <div class="fa-adviser-wrap">
            <!-- CSS adviser figure -->
            <div class="fa-adviser-figure" aria-hidden="true">
                <div class="fa-adv__arm fa-adv__arm--l"></div>
                <div class="fa-adv__arm fa-adv__arm--r"></div>
                <div class="fa-adv__briefcase"></div>
                <div class="fa-adv__body"></div>
                <div class="fa-adv__legs">
                    <div class="fa-adv__leg"></div>
                    <div class="fa-adv__leg"></div>
                </div>
                <div class="fa-adv__head"></div>
            </div>
            <!-- Info -->
            <div class="fa-adviser-info">
                <div class="fa-section-label">Principal Adviser</div>
                <h3 id="fa-adviser-title">Jonathan Whitfield</h3>
                <h4>Chartered Financial Planner · APFS · Cert CII · FCA Registered</h4>
                <p>
                    Jonathan founded the practice in <?php echo date('Y') - 26; ?> and holds the Chartered Financial Planner designation — the highest qualification in financial planning. He specialises in pre- and post-retirement planning, IHT mitigation and portfolio construction for high-net-worth clients.
                </p>
                <p>
                    Our six-strong advisory team are all FCA registered and hold a minimum of QCF Level 4 qualifications. We are independent — meaning we advise on the whole of market, not a restricted panel. All advice is regulated by the Financial Conduct Authority (FCA No. 123456).
                </p>
                <div class="fa-adviser-badges">
                    <span class="fa-badge">🏅 Chartered FP</span>
                    <span class="fa-badge">📋 APFS Qualified</span>
                    <span class="fa-badge">🛡️ FCA Regulated</span>
                    <span class="fa-badge">✅ FSCS Protected</span>
                    <span class="fa-badge">📈 CII Member</span>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     PACKAGES
     ═══════════════════════════════════════════════════════ -->
<section class="fa-section fa-section--white" aria-labelledby="fa-packages-title">
    <div class="fa-container">
        <div class="fa-section-label">Fee Structure</div>
        <h2 class="fa-section-title" id="fa-packages-title">Transparent, Fixed Fees</h2>
        <p class="fa-section-sub">We charge a clear, agreed fee for our advice — never hidden commissions. All fees are disclosed upfront and agreed before any work begins.</p>
        <div class="fa-packages-grid">
            <?php foreach ( $fa_packages as $pkg ) : ?>
                <div class="fa-package <?php echo $pkg['featured'] ? 'fa-package--featured' : ''; ?>">
                    <?php if ( $pkg['featured'] ) : ?>
                        <div class="fa-package__badge">MOST COMPREHENSIVE</div>
                    <?php endif; ?>
                    <h3 class="fa-package__name"><?php echo esc_html($pkg['name']); ?></h3>
                    <div class="fa-package__price"><?php echo esc_html($pkg['price']); ?></div>
                    <div class="fa-package__period"><?php echo esc_html($pkg['period']); ?></div>
                    <ul class="fa-package__items">
                        <?php foreach ( $pkg['items'] as $item ) : ?>
                            <li><?php echo esc_html($item); ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <a href="#booking" class="fa-btn fa-btn--gold fa-package__cta">Book a Consultation</a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     TESTIMONIALS
     ═══════════════════════════════════════════════════════ -->
<section class="fa-section" aria-labelledby="fa-testi-title">
    <div class="fa-container">
        <div class="fa-section-label">Client Testimonials</div>
        <h2 class="fa-section-title" id="fa-testi-title">Trusted by Families Across the Region</h2>
        <p class="fa-section-sub">Hundreds of families and business owners have trusted us to guide their financial futures — here is what some of them say.</p>
        <div class="fa-testi-grid">
            <?php foreach ( $fa_testimonials as $t ) : ?>
                <blockquote class="fa-testi">
                    <div class="fa-testi__quote" aria-hidden="true">❝</div>
                    <div class="fa-testi__stars" aria-label="5 stars">★★★★★</div>
                    <p class="fa-testi__text"><?php echo esc_html($t['text']); ?></p>
                    <footer>
                        <div class="fa-testi__name"><?php echo esc_html($t['name']); ?></div>
                        <div class="fa-testi__role"><?php echo esc_html($t['role']); ?></div>
                    </footer>
                </blockquote>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     FCA REGULATORY DISCLAIMER
     ═══════════════════════════════════════════════════════ -->
<section class="fa-disclaimer-section" aria-label="Regulatory information">
    <div class="fa-container">
        <div class="fa-disclaimer-box">
            <strong>Important Information &amp; Regulatory Disclosure</strong>
            <?php echo esc_html( get_bloginfo('name') ); ?> is authorised and regulated by the Financial Conduct Authority (FCA). Our FCA registration number is 123456. You can verify our authorisation on the FCA Register at fca.org.uk/register. We are independent financial advisers and as such provide advice across the whole of the market. Your home may be repossessed if you do not keep up repayments on a mortgage or any other debt secured on it. The value of investments and any income from them can fall as well as rise and is not guaranteed. You may get back less than you originally invested. Past performance is not a reliable indicator of future results. Tax treatment depends on individual circumstances and may be subject to future change. The information provided on this website does not constitute financial advice. Equity Release products may affect your entitlement to means-tested benefits and will reduce the value of your estate.
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     BOOKING FORM
     ═══════════════════════════════════════════════════════ -->
<section class="fa-section fa-booking" id="booking" aria-labelledby="fa-booking-title">
    <div class="fa-container">
        <div class="fa-booking__wrap">
            <div class="fa-booking__info">
                <div class="fa-section-label" style="color:var(--fa-gold);">Free Consultation</div>
                <h2 id="fa-booking-title" style="color:#fff;">Start Your Financial Journey</h2>
                <p>Book a no-obligation 60-minute discovery meeting — by phone, video call or at our office. We'll listen first and only recommend if we believe we can genuinely add value.</p>
                <ul class="fa-booking__bullets">
                    <li>Free, no-obligation initial meeting</li>
                    <li>No pressure to proceed — ever</li>
                    <li>Available by phone, video or in-person</li>
                    <li>Evening and Saturday appointments available</li>
                    <li>All advice documented and fully transparent</li>
                    <li>Protected by the FSCS up to £85,000</li>
                </ul>
            </div>
            <div class="fa-form">
                <h3>Book Your Free Meeting</h3>
                <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" novalidate>
                    <?php wp_nonce_field( 'tf_fa_booking', 'tf_fa_nonce' ); ?>
                    <input type="hidden" name="action" value="tf_fa_booking">

                    <div class="fa-field-row">
                        <div class="fa-field">
                            <label for="fa-name">Full Name *</label>
                            <input type="text" id="fa-name" name="fa_name" required placeholder="Jane Smith">
                        </div>
                        <div class="fa-field">
                            <label for="fa-phone">Phone Number *</label>
                            <input type="tel" id="fa-phone" name="fa_phone" required placeholder="07700 900123">
                        </div>
                    </div>

                    <div class="fa-field">
                        <label for="fa-email">Email Address *</label>
                        <input type="email" id="fa-email" name="fa_email" required placeholder="jane@example.com">
                    </div>

                    <div class="fa-field">
                        <label for="fa-topic">Primary Topic *</label>
                        <select id="fa-topic" name="fa_topic" required>
                            <option value="">— What would you like to discuss? —</option>
                            <option value="pension">Pension &amp; Retirement Planning</option>
                            <option value="investment">Investment Portfolio</option>
                            <option value="protection">Life / Protection Insurance</option>
                            <option value="iht">Inheritance Tax / Estate Planning</option>
                            <option value="mortgage">Mortgage Advice</option>
                            <option value="isa">ISA / Savings Strategy</option>
                            <option value="business">Business Financial Planning</option>
                            <option value="other">General Review / Not Sure</option>
                        </select>
                    </div>

                    <div class="fa-field-row">
                        <div class="fa-field">
                            <label for="fa-assets">Approx. Assets / Pension Value</label>
                            <select id="fa-assets" name="fa_assets">
                                <option value="">— Select range —</option>
                                <option value="under50k">Under £50,000</option>
                                <option value="50-150k">£50,000 – £150,000</option>
                                <option value="150-500k">£150,000 – £500,000</option>
                                <option value="500k-1m">£500,000 – £1 million</option>
                                <option value="over1m">Over £1 million</option>
                                <option value="prefer-not">Prefer not to say</option>
                            </select>
                        </div>
                        <div class="fa-field">
                            <label for="fa-meeting">Preferred Meeting Format</label>
                            <select id="fa-meeting" name="fa_meeting">
                                <option value="phone">Telephone</option>
                                <option value="video">Video Call</option>
                                <option value="inperson">In Person — Our Office</option>
                            </select>
                        </div>
                    </div>

                    <div class="fa-field">
                        <label for="fa-notes">Anything Else We Should Know?</label>
                        <textarea id="fa-notes" name="fa_notes" placeholder="Tell us a little about your situation and what you're hoping to achieve..."></textarea>
                    </div>

                    <button type="submit" class="fa-form__submit">📊 Request My Free Consultation</button>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     FOOTER
     ═══════════════════════════════════════════════════════ -->
<footer class="fa-footer" role="contentinfo">
    <div class="fa-container">
        <p>Whitfield Financial Planning Ltd &nbsp;·&nbsp; FCA Authorised &amp; Regulated (No. 123456) &nbsp;·&nbsp; Member of the Personal Finance Society</p>
        <div class="fa-footer__phone">📞 01234 567 890</div>
        <p><?php echo esc_html( get_bloginfo('name') ); ?> &copy; <?php echo date('Y'); ?> &nbsp;·&nbsp; Registered in England &amp; Wales &nbsp;·&nbsp; The value of investments can go down as well as up</p>
    </div>
</footer>

<script>
(function(){
    'use strict';
    /* IntersectionObserver counter animation */
    var easeOut = function(t){ return 1 - Math.pow(1-t,3); };
    var counters = document.querySelectorAll('.fa-counter-num');
    if(counters.length){
        var observer = new IntersectionObserver(function(entries){
            entries.forEach(function(entry){
                if(!entry.isIntersecting) return;
                observer.unobserve(entry.target);
                var el = entry.target;
                var target = parseFloat(el.dataset.target);
                var isFloat = el.dataset.float === '1';
                if(isNaN(target)) return;
                var start = null, dur = 1800;
                function tick(ts){
                    if(!start) start = ts;
                    var prog = Math.min((ts-start)/dur,1);
                    var val = easeOut(prog)*target;
                    el.textContent = isFloat ? val.toFixed(1) : Math.floor(val).toLocaleString();
                    if(prog<1) requestAnimationFrame(tick);
                    else el.textContent = isFloat ? target.toFixed(1) : target.toLocaleString();
                }
                requestAnimationFrame(tick);
            });
        }, {threshold:0.3});
        counters.forEach(function(c){ observer.observe(c); });
    }

    /* Animate chart bars from height:0 on page load */
    var bars = document.querySelectorAll('.fa-bar');
    if(bars.length){
        bars.forEach(function(bar){
            var targetH = bar.style.height;
            bar.style.height = '0%';
            setTimeout(function(){
                bar.style.height = targetH;
            }, 400);
        });
    }
})();
</script>

</div><!-- . -->

<?php get_footer(); ?>
