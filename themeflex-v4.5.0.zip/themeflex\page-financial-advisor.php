<?php
/**
 * Template Name: Financial Advisor
 * Description: Premium independent financial advisor / IFA homepage template
 *
 * @package ThemeFlex
 */

// ── Deterministic randomness ────────────────────────────────────────────────
srand( crc32( get_the_permalink() ) );

// ── Advisor data ─────────────────────────────────────────────────────────────
$advisor = [
    'name'     => 'Jonathan Whitfield',
    'title'    => 'Chartered Financial Planner · FCA Authorised',
    'location' => 'Leeds & Yorkshire · Nationwide Remote',
    'tagline'  => 'Your Wealth, Your Future',
    'bio'      => 'Jonathan Whitfield is a Chartered Financial Planner with 18 years of experience helping individuals, families and business owners build, protect and transfer wealth. Authorised and regulated by the Financial Conduct Authority, he provides truly independent, whole-of-market advice with no hidden commissions.',
    'bio2'     => 'Jonathan believes great financial planning starts with listening. Every recommendation begins with a deep understanding of your values, goals and timelines — not products. His clients describe him as "the advisor who actually speaks English" and "the person who finally made our finances make sense."',
    'years'    => 18,
    'clients'  => 620,
    'aum'      => 95,
    'rating'   => 4.9,
];

// ── Services ─────────────────────────────────────────────────────────────────
$services = [
    [ 'icon' => '🏦', 'title' => 'Retirement Planning',     'desc' => 'Personal pension reviews, SIPP, drawdown and annuity advice to ensure you retire on your own terms.' ],
    [ 'icon' => '📈', 'title' => 'Investment Management',   'desc' => 'Risk-profiled portfolio construction and ongoing management aligned with your goals and timeline.' ],
    [ 'icon' => '🏠', 'title' => 'Mortgage Advice',         'desc' => 'Whole-of-market mortgage and re-mortgage advice including buy-to-let, interest-only and complex cases.' ],
    [ 'icon' => '🛡️', 'title' => 'Protection Planning',    'desc' => 'Life insurance, critical illness, income protection and business assurance to protect what matters most.' ],
    [ 'icon' => '📋', 'title' => 'Estate Planning',         'desc' => 'Inheritance tax planning, wills coordination, trusts and Lasting Powers of Attorney to protect your legacy.' ],
    [ 'icon' => '🏢', 'title' => 'Business Financial',      'desc' => 'Director pension, key person insurance, employee benefits and business succession planning.' ],
    [ 'icon' => '🎓', 'title' => 'Education Planning',      'desc' => 'Junior ISAs, child savings plans and tuition fee funding strategies for your children\'s future.' ],
    [ 'icon' => '💷', 'title' => 'Tax Efficiency',          'desc' => 'ISA allowances, CGT planning, VCT/EIS investments and salary sacrifice optimisation.' ],
];

// ── Packages ─────────────────────────────────────────────────────────────────
$packages = [
    [
        'name'     => 'Financial MOT',
        'price'    => '£395',
        'period'   => 'one-off review',
        'colour'   => 'blue',
        'features' => [
            '90-min in-depth consultation',
            'Full financial health-check',
            'Written action plan',
            'Pension & ISA gap analysis',
            'Protection needs review',
        ],
        'featured' => false,
    ],
    [
        'name'     => 'Full Financial Plan',
        'price'    => '£1,200',
        'period'   => 'one-off planning fee',
        'colour'   => 'gold',
        'features' => [
            'Two planning sessions',
            'Comprehensive written plan',
            'Investment recommendation',
            'Protection & pension advice',
            'Estate planning overview',
            'Cashflow modelling',
            'Three-month review call',
        ],
        'featured' => true,
    ],
    [
        'name'     => 'Ongoing Advisory',
        'price'    => '£175',
        'period'   => 'per month',
        'colour'   => 'navy',
        'features' => [
            'Annual planning review',
            'Quarterly portfolio updates',
            'Unlimited telephone access',
            'Tax year-end planning',
            'Life change consultations',
            'Full implementation support',
            'Priority response SLA',
        ],
        'featured' => false,
    ],
];

// ── Process ───────────────────────────────────────────────────────────────────
$steps = [
    [ 'num' => '01', 'title' => 'Free Discovery Call',    'desc' => 'A 30-minute no-obligation conversation to understand your situation and whether we\'re a good fit.' ],
    [ 'num' => '02', 'title' => 'Fact Find & Goals',      'desc' => 'A comprehensive picture of your finances, priorities and long-term objectives.' ],
    [ 'num' => '03', 'title' => 'Written Suitability Report','desc' => 'A clear, jargon-free report explaining our recommendations and the reasoning behind them.' ],
    [ 'num' => '04', 'title' => 'Implementation',         'desc' => 'Jonathan handles all paperwork and product applications on your behalf.' ],
    [ 'num' => '05', 'title' => 'Ongoing Review',         'desc' => 'Annual reviews ensure your plan stays aligned as your life and the markets evolve.' ],
];

// ── FAQs ─────────────────────────────────────────────────────────────────────
$faqs = [
    [ 'q' => 'What does "independent" advice mean?', 'a' => 'As an independent financial adviser, Jonathan can recommend any financial product from any provider on the market — not just a restricted panel. This means you get genuinely objective advice driven by your needs, not a product quota.' ],
    [ 'q' => 'How does Jonathan get paid?', 'a' => 'Jonathan charges transparent fees for his advice and does not receive commission. Fees are agreed upfront before any work begins. Some investment products include a facilitated adviser charge paid from the plan, which is fully disclosed in advance.' ],
    [ 'q' => 'Is my money protected?', 'a' => 'Jonathan is authorised and regulated by the FCA (FCA ref: 742681). Client assets held through recommended providers are covered by FSCS protection up to £85,000 per institution.' ],
    [ 'q' => 'I already have a pension — can you review it?', 'a' => 'Absolutely. A pension review is one of the most valuable things you can do. Jonathan will assess performance, charges, allocation and whether the plan still suits your retirement goals, and whether consolidation makes sense.' ],
    [ 'q' => 'Do you work with people who are just starting out?', 'a' => 'Yes. Whether you have £10,000 or £10 million, Jonathan believes everyone deserves professional financial guidance. The Financial MOT package is ideal for those earlier in their financial journey.' ],
    [ 'q' => 'How far in advance should I start retirement planning?', 'a' => 'The earlier the better — compound growth rewards time above all else. That said, it\'s never too late to optimise. Jonathan regularly works with clients within 5 years of retirement to significantly improve their income position.' ],
];

// ── Chart bars (CSS hero) ─────────────────────────────────────────────────────
$chart_bars = [];
$heights = [ 28, 42, 38, 55, 50, 68, 62, 78, 72, 88, 82, 95, 90, 100 ];
foreach ( $heights as $i => $h ) {
    $chart_bars[] = [
        'h'     => $h,
        'delay' => round( $i * 0.12, 2 ),
        'col'   => $i < 4 ? '#1E3A5F' : ( $i < 8 ? '#2E5F8A' : ( $i < 11 ? '#3D85C8' : '#F5A623' ) ),
    ];
}

// ── Floating numbers ───────────────────────────────────────────────────────────
$floaters = [
    [ 'val' => '+7.4%', 'top' => 15, 'left' => 60, 'delay' => 0    ],
    [ 'val' => '£2.1M', 'top' => 32, 'left' => 75, 'delay' => 0.8  ],
    [ 'val' => '+12%',  'top' => 50, 'left' => 65, 'delay' => 1.6  ],
    [ 'val' => 'ISA ✓', 'top' => 68, 'left' => 78, 'delay' => 2.4  ],
    [ 'val' => '£850k', 'top' => 22, 'left' => 82, 'delay' => 3.2  ],
];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Merriweather:wght@300;400;700;900&family=Source+Sans+3:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════════════════════════
   FINANCIAL ADVISOR TEMPLATE  —  namespace: --fa-*
   ═══════════════════════════════════════════════════════════════════════════ */
:root {
  --fa-navy:   #1E3A5F;
  --fa-blue:   #2E5F8A;
  --fa-sky:    #3D85C8;
  --fa-gold:   #F5A623;
  --fa-cream:  #F9F7F4;
  --fa-light:  #EEF4FA;
  --fa-mid:    #5A7A8C;
  --fa-warm:   #F2EDE6;
  --fa-shadow: rgba(30,58,95,.13);
  --fa-r:      12px;
  --fa-ff:     'Merriweather', Georgia, serif;
  --fa-ff2:    'Source Sans 3', sans-serif;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body.fa-page{font-family:var(--fa-ff2);color:var(--fa-navy);background:var(--fa-cream);line-height:1.75}
img{max-width:100%;display:block}
a{color:inherit;text-decoration:none}
.fa-page h1,.fa-page h2,.fa-page h3,.fa-page h4{font-family:var(--fa-ff);line-height:1.25}

/* ── LAYOUT ── */
.fa-wrap{max-width:1160px;margin:0 auto;padding:0 24px}
.fa-section{padding:96px 0}
.fa-section--alt{background:#fff}
.fa-section--light{background:var(--fa-light)}
.fa-section--warm{background:var(--fa-warm)}
.fa-tag{display:inline-block;font-family:var(--fa-ff2);font-size:.73rem;font-weight:700;letter-spacing:.13em;text-transform:uppercase;color:var(--fa-blue);background:rgba(46,95,138,.1);padding:6px 18px;border-radius:99px;margin-bottom:18px}
.fa-tag--gold{color:#A06B00;background:rgba(245,166,35,.15)}

/* ── HERO ── */
.fa-hero{position:relative;min-height:100vh;display:flex;align-items:center;overflow:hidden;background:linear-gradient(145deg,#0E1F36 0%,#1E3A5F 50%,#142D4A 100%)}
.fa-hero::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse 50% 60% at 20% 50%,rgba(46,95,138,.22) 0%,transparent 60%)}

/* grid lines */
.fa-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,.03) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.03) 1px,transparent 1px);background-size:60px 60px;z-index:1}

/* bar chart */
.fa-chart{position:absolute;bottom:0;right:5%;z-index:4;display:flex;align-items:flex-end;gap:8px;height:55%;padding-bottom:0}
.fa-bar{border-radius:4px 4px 0 0;width:28px;animation:fa-bar-rise .8s cubic-bezier(.34,1.56,.64,1) var(--bar-d,0s) both}
@keyframes fa-bar-rise{from{transform:scaleY(0);transform-origin:bottom}to{transform:scaleY(1);transform-origin:bottom}}
/* chart axis */
.fa-chart-floor{position:absolute;bottom:0;left:-10px;right:-10px;height:3px;background:rgba(255,255,255,.2);border-radius:1px}
.fa-chart-label{position:absolute;bottom:-22px;left:0;right:0;text-align:center;font-size:.62rem;color:rgba(255,255,255,.45);font-family:var(--fa-ff2)}

/* floating numbers */
.fa-floater{position:absolute;z-index:5;font-family:var(--fa-ff2);font-weight:700;font-size:.82rem;color:#fff;background:rgba(245,166,35,.2);border:1px solid rgba(245,166,35,.4);padding:5px 12px;border-radius:6px;animation:fa-float 3s ease-in-out var(--fl-d,0s) infinite alternate;backdrop-filter:blur(4px)}
@keyframes fa-float{0%{transform:translateY(0)}100%{transform:translateY(-12px)}}

/* advisor figure */
.fa-figure{position:absolute;bottom:0;right:26%;z-index:6;width:100px}
.fa-fig-head{width:42px;height:46px;background:linear-gradient(160deg,#F5D5B0,#EEC298);border-radius:50%;margin:0 auto;position:relative}
.fa-fig-hair{position:absolute;top:0;left:2px;right:2px;height:22px;background:#3A2410;border-radius:50% 50% 0 0}
.fa-fig-eyes{position:absolute;top:20px;left:50%;transform:translateX(-50%);width:26px;display:flex;justify-content:space-between}
.fa-fig-eye{width:6px;height:4px;background:var(--fa-navy);border-radius:50%}
.fa-fig-suit{width:52px;height:60px;background:#1E3A5F;border-radius:6px 6px 4px 4px;margin:0 auto;position:relative;border:2px solid rgba(255,255,255,.06)}
.fa-fig-tie{position:absolute;top:6px;left:50%;transform:translateX(-50%);width:10px;height:36px;background:var(--fa-gold);clip-path:polygon(30% 0,70% 0,100% 40%,50% 100%,0 40%)}
.fa-fig-lapel{position:absolute;top:4px;left:4px;width:14px;height:28px;background:#2E5F8A;border-radius:0 0 0 8px}
.fa-fig-lapel-r{position:absolute;top:4px;right:4px;width:14px;height:28px;background:#2E5F8A;border-radius:0 0 8px 0}
.fa-fig-arm-l{position:absolute;top:8px;left:-13px;width:13px;height:38px;background:#1E3A5F;border-radius:99px}
.fa-fig-arm-r{position:absolute;top:8px;right:-13px;width:13px;height:38px;background:#1E3A5F;border-radius:99px}
.fa-fig-hand{position:absolute;bottom:-5px;left:50%;transform:translateX(-50%);width:11px;height:11px;background:#F5D5B0;border-radius:50%}
.fa-fig-legs{display:flex;justify-content:center;gap:4px;margin-top:2px}
.fa-fig-leg{width:14px;height:42px;background:#162D44;border-radius:3px}
.fa-fig-shoe{width:18px;height:9px;background:#0A1520;border-radius:99px 99px 40% 40%;margin-top:-1px}
/* briefcase */
.fa-fig-brief{position:absolute;bottom:8px;right:-24px;width:26px;height:20px;background:var(--fa-gold);border-radius:3px;border:2px solid #C87F10}
.fa-fig-brief::before{content:'';position:absolute;top:-6px;left:50%;transform:translateX(-50%);width:12px;height:6px;border:2px solid #C87F10;border-bottom:none;border-radius:3px 3px 0 0}

/* hero content */
.fa-hero__content{position:relative;z-index:10;max-width:600px;padding:40px 0 200px}
.fa-hero__eyebrow{font-family:var(--fa-ff2);font-size:.78rem;font-weight:700;letter-spacing:.16em;text-transform:uppercase;color:var(--fa-gold);margin-bottom:18px}
.fa-hero__title{font-family:var(--fa-ff);font-size:clamp(2.2rem,5vw,3.6rem);font-weight:900;color:#fff;line-height:1.1;margin-bottom:22px}
.fa-hero__title span{color:var(--fa-gold)}
.fa-hero__sub{font-size:1.06rem;color:rgba(255,255,255,.78);max-width:480px;margin-bottom:40px}
.fa-hero__ctas{display:flex;gap:16px;flex-wrap:wrap}
.fa-btn{display:inline-flex;align-items:center;gap:8px;font-family:var(--fa-ff2);font-weight:700;font-size:.93rem;padding:14px 30px;border-radius:6px;cursor:pointer;border:none;transition:transform .2s,box-shadow .2s}
.fa-btn--primary{background:var(--fa-gold);color:var(--fa-navy)}
.fa-btn--primary:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(245,166,35,.45)}
.fa-btn--ghost{background:transparent;color:#fff;border:1.5px solid rgba(255,255,255,.4)}
.fa-btn--ghost:hover{background:rgba(255,255,255,.08)}

/* trust strip */
.fa-trust{display:flex;gap:24px;flex-wrap:wrap;margin-top:36px;padding-top:28px;border-top:1px solid rgba(255,255,255,.1)}
.fa-trust-item{display:flex;align-items:center;gap:10px;color:rgba(255,255,255,.82)}
.fa-trust-item__icon{font-size:1.3rem}
.fa-trust-item__text{font-size:.78rem;line-height:1.3}
.fa-trust-item__text strong{display:block;font-size:.88rem;color:#fff}

/* ── COUNTERS ── */
.fa-counters{display:grid;grid-template-columns:repeat(4,1fr);gap:28px}
.fa-counter{text-align:center;padding:36px 18px;background:#fff;border-radius:var(--fa-r);box-shadow:0 4px 20px var(--fa-shadow);position:relative;overflow:hidden}
.fa-counter::before{content:'';position:absolute;top:0;left:0;right:0;height:4px;background:linear-gradient(90deg,var(--fa-navy),var(--fa-sky))}
.fa-counter__num{font-family:var(--fa-ff);font-size:2.5rem;font-weight:900;color:var(--fa-navy);line-height:1}
.fa-counter__suffix{font-size:1.4rem;font-family:var(--fa-ff2);font-weight:700;color:var(--fa-gold);vertical-align:super}
.fa-counter__label{font-size:.86rem;color:var(--fa-mid);margin-top:10px}

/* ── SERVICES ── */
.fa-services-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(255px,1fr));gap:24px;margin-top:52px}
.fa-service-card{background:#fff;border-radius:var(--fa-r);padding:32px 26px;box-shadow:0 4px 20px var(--fa-shadow);transition:transform .25s,box-shadow .25s;border-top:3px solid var(--fa-navy)}
.fa-service-card:hover{transform:translateY(-4px);box-shadow:0 12px 32px var(--fa-shadow)}
.fa-service-card__icon{font-size:2rem;margin-bottom:14px}
.fa-service-card__title{font-family:var(--fa-ff);font-size:.98rem;color:var(--fa-navy);margin-bottom:10px;font-weight:700}
.fa-service-card__desc{font-size:.88rem;color:var(--fa-mid);line-height:1.7}

/* ── ABOUT ── */
.fa-about{display:grid;grid-template-columns:1fr 1fr;gap:72px;align-items:center}
.fa-about__figure{display:flex;justify-content:center}
.fa-about__scene{width:300px;height:360px;border-radius:var(--fa-r);background:linear-gradient(145deg,var(--fa-light),#fff);box-shadow:0 8px 32px var(--fa-shadow);position:relative;overflow:hidden;border:2px solid rgba(30,58,95,.12)}
/* office scene */
.fa-sc-wall{position:absolute;top:0;left:0;right:0;height:55%;background:linear-gradient(180deg,#EEF4FA 0%,#DDE8F5 100%)}
.fa-sc-floor{position:absolute;bottom:0;left:0;right:0;height:47%;background:linear-gradient(180deg,#F5EEE0 0%,#EAE0CE 100%)}
.fa-sc-desk{position:absolute;bottom:38%;left:5%;right:5%;height:18px;background:#5C3A1A;border-radius:3px;box-shadow:0 4px 8px rgba(0,0,0,.2)}
.fa-sc-monitor{position:absolute;bottom:47%;left:50%;transform:translateX(-50%);width:60px;height:44px;background:#1E3A5F;border-radius:4px;border:3px solid #0A1520}
.fa-sc-screen{width:100%;height:100%;background:linear-gradient(145deg,#3D85C8 0%,#1E3A5F 100%);border-radius:2px;position:relative;overflow:hidden}
.fa-sc-chart-mini{position:absolute;bottom:2px;left:2px;right:2px;height:70%;display:flex;align-items:flex-end;gap:2px}
.fa-sc-bar-mini{flex:1;background:var(--fa-gold);border-radius:1px 1px 0 0;opacity:.8}
.fa-sc-advisor{position:absolute;bottom:53%;left:30%;display:flex;flex-direction:column;align-items:center}
.fa-sc-head{width:20px;height:22px;background:linear-gradient(160deg,#F5D5B0,#EEC298);border-radius:50%}
.fa-sc-body{width:24px;height:30px;background:var(--fa-navy);border-radius:5px}
.fa-sc-legs{display:flex;gap:2px;margin-top:1px}
.fa-sc-leg{width:9px;height:16px;background:#142D4A;border-radius:3px}
/* framed cert */
.fa-sc-cert{position:absolute;top:12px;right:16px;width:40px;height:32px;background:#fff;border:2px solid var(--fa-gold);border-radius:3px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px}
.fa-sc-cert-line{width:26px;height:2px;background:#DDD;border-radius:1px}
.fa-sc-cert-line:first-child{background:var(--fa-gold);width:18px}
.fa-about__creds{margin-top:28px;display:flex;flex-direction:column;gap:12px}
.fa-cred{display:flex;align-items:center;gap:12px;padding:13px 18px;border-radius:10px;background:var(--fa-light);border-left:3px solid var(--fa-navy)}
.fa-cred__icon{font-size:1.2rem}
.fa-cred__text{font-size:.88rem;font-weight:600;color:var(--fa-navy)}

/* ── PROCESS ── */
.fa-process{display:flex;flex-direction:column;gap:0}
.fa-step{display:flex;gap:24px;padding:24px 0;border-bottom:1px solid rgba(30,58,95,.1)}
.fa-step:last-child{border-bottom:none}
.fa-step__num{flex-shrink:0;width:48px;height:48px;border-radius:6px;background:var(--fa-navy);display:flex;align-items:center;justify-content:center;font-family:var(--fa-ff2);font-weight:700;font-size:.9rem;color:#fff}
.fa-step__title{font-family:var(--fa-ff);font-size:.98rem;color:var(--fa-navy);margin-bottom:5px;font-weight:700}
.fa-step__desc{font-size:.9rem;color:var(--fa-mid)}

/* ── PACKAGES ── */
.fa-packages{display:grid;grid-template-columns:repeat(3,1fr);gap:28px;margin-top:52px;align-items:start}
.fa-pkg{border-radius:var(--fa-r);padding:40px 30px;background:#fff;box-shadow:0 4px 20px var(--fa-shadow);position:relative;transition:transform .25s}
.fa-pkg:hover{transform:translateY(-4px)}
.fa-pkg--blue{border-top:4px solid var(--fa-sky)}
.fa-pkg--gold{border-top:4px solid var(--fa-gold)}
.fa-pkg--navy{border-top:4px solid var(--fa-navy)}
.fa-pkg--featured{background:var(--fa-navy);color:#fff;box-shadow:0 12px 40px rgba(30,58,95,.4);transform:scale(1.04)}
.fa-pkg--featured:hover{transform:scale(1.04) translateY(-4px)}
.fa-pkg--featured .fa-pkg__name{color:#fff}
.fa-pkg--featured .fa-pkg__price{color:var(--fa-gold)}
.fa-pkg--featured .fa-pkg__period,.fa-pkg--featured .fa-pkg__feature{color:rgba(255,255,255,.82)}
.fa-pkg--featured .fa-pkg__feature::before{color:var(--fa-gold)}
.fa-pkg__ribbon{position:absolute;top:-1px;right:22px;background:var(--fa-gold);color:var(--fa-navy);font-family:var(--fa-ff2);font-size:.7rem;font-weight:700;padding:5px 14px;border-radius:0 0 8px 8px}
.fa-pkg__name{font-family:var(--fa-ff);font-size:1.1rem;font-weight:700;color:var(--fa-navy);margin-bottom:8px}
.fa-pkg__price{font-family:var(--fa-ff);font-size:2.4rem;font-weight:900;color:var(--fa-navy);line-height:1}
.fa-pkg__period{font-size:.82rem;color:var(--fa-mid);margin-bottom:24px}
.fa-pkg__features{list-style:none;display:flex;flex-direction:column;gap:9px;margin-bottom:28px}
.fa-pkg__feature{font-size:.88rem;padding-left:20px;position:relative}
.fa-pkg__feature::before{content:'✓';position:absolute;left:0;color:var(--fa-navy);font-weight:700}
.fa-pkg__btn{display:block;text-align:center;padding:13px;border-radius:6px;font-family:var(--fa-ff2);font-weight:700;font-size:.88rem;transition:opacity .2s;cursor:pointer;border:none}
.fa-pkg--blue .fa-pkg__btn{background:var(--fa-sky);color:#fff}
.fa-pkg--gold .fa-pkg__btn{background:var(--fa-gold);color:var(--fa-navy)}
.fa-pkg--navy .fa-pkg__btn{background:var(--fa-sky);color:#fff}
.fa-pkg__btn:hover{opacity:.85}

/* ── TESTIMONIALS ── */
.fa-testimonials{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:52px}
.fa-testimonial{background:#fff;border-radius:var(--fa-r);padding:28px;box-shadow:0 4px 16px var(--fa-shadow)}
.fa-testimonial__text{font-size:.9rem;line-height:1.75;color:var(--fa-mid);margin-bottom:18px}
.fa-testimonial__name{font-family:var(--fa-ff);font-weight:700;font-size:.9rem;color:var(--fa-navy)}
.fa-testimonial__role{font-size:.78rem;color:var(--fa-mid)}
.fa-stars{color:var(--fa-gold);letter-spacing:2px;font-size:.85rem;margin-top:4px}

/* ── FAQs ── */
.fa-faq-list{display:flex;flex-direction:column;gap:10px;margin-top:44px}
.fa-faq{border:1px solid rgba(30,58,95,.15);border-radius:8px;overflow:hidden;background:#fff}
.fa-faq__q{padding:18px 24px;font-family:var(--fa-ff);font-size:.95rem;color:var(--fa-navy);cursor:pointer;display:flex;justify-content:space-between;align-items:center;gap:16px;font-weight:700}
.fa-faq__q::after{content:'＋';font-size:1.2rem;color:var(--fa-blue);flex-shrink:0;transition:transform .25s;font-family:var(--fa-ff2)}
.fa-faq.open .fa-faq__q::after{transform:rotate(45deg)}
.fa-faq__a{max-height:0;overflow:hidden;transition:max-height .35s ease}
.fa-faq.open .fa-faq__a{max-height:280px}
.fa-faq__a-inner{padding:0 24px 18px;font-size:.9rem;color:var(--fa-mid);line-height:1.72}

/* ── DISCLAIMER ── */
.fa-disclaimer{background:var(--fa-warm);border-left:4px solid var(--fa-gold);padding:20px 24px;border-radius:0 8px 8px 0;margin-top:40px;font-size:.82rem;color:var(--fa-mid)}
.fa-disclaimer strong{color:var(--fa-navy);font-family:var(--fa-ff)}

/* ── BOOKING ── */
.fa-form-wrap{background:var(--fa-navy);border-radius:var(--fa-r);padding:52px 48px;box-shadow:0 12px 48px rgba(0,0,0,.25)}
.fa-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}
.fa-form-grid .fa-fg--full{grid-column:1/-1}
.fa-field label{display:block;font-size:.78rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:rgba(255,255,255,.6);margin-bottom:8px}
.fa-field input,.fa-field select,.fa-field textarea{width:100%;padding:12px 16px;background:rgba(255,255,255,.08);border:1.5px solid rgba(255,255,255,.15);border-radius:6px;color:#fff;font-size:.93rem;font-family:var(--fa-ff2);transition:border-color .2s}
.fa-field input::placeholder,.fa-field textarea::placeholder{color:rgba(255,255,255,.33)}
.fa-field input:focus,.fa-field select:focus,.fa-field textarea:focus{outline:none;border-color:var(--fa-gold)}
.fa-field select option{background:var(--fa-navy);color:#fff}
.fa-field textarea{resize:vertical;min-height:90px}
.fa-form-note{font-size:.78rem;color:rgba(255,255,255,.4);margin-top:10px}

/* ── CTA STRIP ── */
.fa-cta-strip{background:linear-gradient(135deg,var(--fa-navy) 0%,var(--fa-blue) 100%);padding:72px 0;text-align:center}
.fa-cta-strip h2{font-family:var(--fa-ff);font-size:2.2rem;font-weight:900;color:#fff;margin-bottom:14px}
.fa-cta-strip p{color:rgba(255,255,255,.78);margin-bottom:32px}

/* ── FOOTER ── */
.fa-footer-strip{background:#0E1F36;padding:26px 0;text-align:center}
.fa-footer-strip p{color:rgba(255,255,255,.4);font-size:.83rem}

/* ── SECTION TITLES ── */
.fa-section-title{font-family:var(--fa-ff);font-size:clamp(1.8rem,3.5vw,2.5rem);color:var(--fa-navy);margin-bottom:16px}
.fa-section-sub{font-size:1.02rem;color:var(--fa-mid);max-width:560px}

/* ── SCROLL REVEAL ── */
.fa-reveal{opacity:0;transform:translateY(28px);transition:opacity .65s,transform .65s}
.fa-reveal.visible{opacity:1;transform:none}

/* ── RESPONSIVE ── */
@media(max-width:900px){
  .fa-counters{grid-template-columns:repeat(2,1fr)}
  .fa-packages{grid-template-columns:1fr}
  .fa-pkg--featured{transform:none}
  .fa-about{grid-template-columns:1fr}
  .fa-testimonials{grid-template-columns:1fr}
  .fa-form-grid{grid-template-columns:1fr}
}
@media(max-width:600px){
  .fa-section{padding:60px 0}
  .fa-form-wrap{padding:32px 20px}
  .fa-chart{display:none}
}
</style>
<?php get_header(); ?>
<div class="fa-page">
>
<?php wp_body_open(); ?>

<!-- ═══════════ HERO ═══════════ -->
<section class="fa-hero" id="home">
  <div class="fa-grid"></div>

  <!-- Bar chart -->
  <div class="fa-chart">
    <?php foreach ( $chart_bars as $i => $bar ) : ?>
    <div class="fa-bar" style="height:<?php echo $bar['h']; ?>%;background:<?php echo $bar['col']; ?>;--bar-d:<?php echo $bar['delay']; ?>s;position:relative">
      <?php if ( $i === count( $chart_bars ) - 1 ) : ?>
      <span style="position:absolute;top:-22px;left:50%;transform:translateX(-50%);font-size:.65rem;color:var(--fa-gold);font-weight:700;white-space:nowrap">+100%</span>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
    <div class="fa-chart-floor"></div>
    <div class="fa-chart-label">10-Year Portfolio Growth</div>
  </div>

  <!-- Floating number badges -->
  <?php foreach ( $floaters as $fl ) : ?>
  <div class="fa-floater" style="top:<?php echo $fl['top']; ?>%;left:<?php echo $fl['left']; ?>%;--fl-d:<?php echo $fl['delay']; ?>s"><?php echo esc_html( $fl['val'] ); ?></div>
  <?php endforeach; ?>

  <!-- Advisor figure -->
  <div class="fa-figure">
    <div class="fa-fig-head">
      <div class="fa-fig-hair"></div>
      <div class="fa-fig-eyes">
        <div class="fa-fig-eye"></div>
        <div class="fa-fig-eye"></div>
      </div>
    </div>
    <div class="fa-fig-suit">
      <div class="fa-fig-lapel"></div>
      <div class="fa-fig-lapel-r"></div>
      <div class="fa-fig-tie"></div>
      <div class="fa-fig-arm-l"><div class="fa-fig-hand"></div></div>
      <div class="fa-fig-arm-r">
        <div class="fa-fig-brief"></div>
        <div class="fa-fig-hand"></div>
      </div>
    </div>
    <div class="fa-fig-legs">
      <div>
        <div class="fa-fig-leg"></div>
        <div class="fa-fig-shoe"></div>
      </div>
      <div>
        <div class="fa-fig-leg"></div>
        <div class="fa-fig-shoe"></div>
      </div>
    </div>
  </div>

  <div class="fa-wrap">
    <div class="fa-hero__content">
      <p class="fa-hero__eyebrow">Chartered Financial Planner · FCA Authorised · Leeds & UK-Wide</p>
      <h1 class="fa-hero__title">
        <?php echo esc_html( $advisor['tagline'] ); ?><br>
        <span>Truly Independent Advice</span>
      </h1>
      <p class="fa-hero__sub">
        Whole-of-market financial planning from a Chartered adviser with no sales targets, no commissions, no compromises — just expert guidance built around you.
      </p>
      <div class="fa-hero__ctas">
        <a href="#booking" class="fa-btn fa-btn--primary">💷 Book Free Discovery Call</a>
        <a href="#services" class="fa-btn fa-btn--ghost">Our Services</a>
      </div>
      <div class="fa-trust">
        <div class="fa-trust-item">
          <span class="fa-trust-item__icon">🏛</span>
          <div class="fa-trust-item__text"><strong>Chartered</strong>CISI Accredited</div>
        </div>
        <div class="fa-trust-item">
          <span class="fa-trust-item__icon">⚖️</span>
          <div class="fa-trust-item__text"><strong>FCA Authorised</strong>Ref: 742681</div>
        </div>
        <div class="fa-trust-item">
          <span class="fa-trust-item__icon">🌐</span>
          <div class="fa-trust-item__text"><strong>Independent</strong>Whole-of-Market</div>
        </div>
        <div class="fa-trust-item">
          <span class="fa-trust-item__icon">🛡️</span>
          <div class="fa-trust-item__text"><strong>FSCS Protected</strong>Up to £85,000</div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ COUNTERS ═══════════ -->
<section class="fa-section fa-section--alt">
  <div class="fa-wrap">
    <div class="fa-counters">
      <div class="fa-counter fa-reveal">
        <div class="fa-counter__num" data-target="<?php echo $advisor['years']; ?>">0</div>
        <div class="fa-counter__label">Years of Experience</div>
      </div>
      <div class="fa-counter fa-reveal">
        <div class="fa-counter__num" data-target="<?php echo $advisor['clients']; ?>" data-suffix="+">0</div>
        <div class="fa-counter__label">Client Families Served</div>
      </div>
      <div class="fa-counter fa-reveal">
        <div class="fa-counter__num" data-target="<?php echo $advisor['aum']; ?>" data-suffix="M+">0</div>
        <div class="fa-counter__label">Assets Under Advice (£)</div>
      </div>
      <div class="fa-counter fa-reveal">
        <div class="fa-counter__num" data-target="<?php echo $advisor['rating']; ?>" data-float="1" data-suffix="★">0</div>
        <div class="fa-counter__label">Client Satisfaction Rating</div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ SERVICES ═══════════ -->
<section class="fa-section fa-section--light" id="services">
  <div class="fa-wrap">
    <div class="fa-tag">What We Do</div>
    <h2 class="fa-section-title">Comprehensive Financial Planning</h2>
    <p class="fa-section-sub">From protecting your family today to funding your retirement tomorrow — independent advice that covers every area of your financial life.</p>
    <div class="fa-services-grid">
      <?php foreach ( $services as $svc ) : ?>
      <div class="fa-service-card fa-reveal">
        <div class="fa-service-card__icon"><?php echo $svc['icon']; ?></div>
        <h3 class="fa-service-card__title"><?php echo esc_html( $svc['title'] ); ?></h3>
        <p class="fa-service-card__desc"><?php echo esc_html( $svc['desc'] ); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════ ABOUT ═══════════ -->
<section class="fa-section fa-section--alt" id="about">
  <div class="fa-wrap">
    <div class="fa-about">
      <div class="fa-about__figure">
        <div class="fa-about__scene">
          <div class="fa-sc-wall"></div>
          <div class="fa-sc-floor"></div>
          <div class="fa-sc-desk"></div>
          <div class="fa-sc-monitor">
            <div class="fa-sc-screen">
              <div class="fa-sc-chart-mini">
                <?php foreach ( [30,45,40,60,55,75,70,90] as $bh ) : ?>
                <div class="fa-sc-bar-mini" style="height:<?php echo $bh; ?>%"></div>
                <?php endforeach; ?>
              </div>
            </div>
          </div>
          <div class="fa-sc-cert">
            <div class="fa-sc-cert-line"></div>
            <div class="fa-sc-cert-line"></div>
            <div class="fa-sc-cert-line"></div>
          </div>
          <div class="fa-sc-advisor">
            <div class="fa-sc-head"></div>
            <div class="fa-sc-body"></div>
            <div class="fa-sc-legs">
              <div class="fa-sc-leg"></div>
              <div class="fa-sc-leg"></div>
            </div>
          </div>
          <div style="position:absolute;bottom:18px;left:0;right:0;text-align:center">
            <p style="font-family:var(--fa-ff);font-size:.82rem;font-weight:700;color:var(--fa-navy)"><?php echo esc_html( $advisor['name'] ); ?></p>
            <p style="font-size:.7rem;color:var(--fa-mid)">Chartered Financial Planner</p>
          </div>
        </div>
      </div>
      <div>
        <div class="fa-tag">About Jonathan</div>
        <h2 class="fa-section-title"><?php echo esc_html( $advisor['name'] ); ?></h2>
        <p style="font-size:.88rem;font-weight:700;color:var(--fa-blue);margin-bottom:20px"><?php echo esc_html( $advisor['title'] ); ?></p>
        <p style="color:var(--fa-mid);line-height:1.82;margin-bottom:18px"><?php echo esc_html( $advisor['bio'] ); ?></p>
        <p style="color:var(--fa-mid);line-height:1.82;margin-bottom:28px"><?php echo esc_html( $advisor['bio2'] ); ?></p>
        <div class="fa-about__creds">
          <div class="fa-cred"><span class="fa-cred__icon">🏛</span><span class="fa-cred__text">Chartered Financial Planner — CISI (Level 6)</span></div>
          <div class="fa-cred"><span class="fa-cred__icon">⚖️</span><span class="fa-cred__text">FCA Authorised & Regulated — Ref: 742681</span></div>
          <div class="fa-cred"><span class="fa-cred__icon">📜</span><span class="fa-cred__text">Diploma in Financial Planning — CII</span></div>
          <div class="fa-cred"><span class="fa-cred__icon">🌐</span><span class="fa-cred__text">Member — Personal Finance Society (FPFS)</span></div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ PROCESS ═══════════ -->
<section class="fa-section fa-section--light" id="process">
  <div class="fa-wrap">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:72px;align-items:start">
      <div>
        <div class="fa-tag">How It Works</div>
        <h2 class="fa-section-title">Your Financial Planning Journey</h2>
        <p class="fa-section-sub" style="margin-bottom:36px">From first conversation to ongoing partnership — a clear, structured process with no jargon.</p>
        <div class="fa-process">
          <?php foreach ( $steps as $s ) : ?>
          <div class="fa-step fa-reveal">
            <div class="fa-step__num"><?php echo $s['num']; ?></div>
            <div>
              <div class="fa-step__title"><?php echo esc_html( $s['title'] ); ?></div>
              <div class="fa-step__desc"><?php echo esc_html( $s['desc'] ); ?></div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <div>
        <div class="fa-tag fa-tag--gold">Regulatory Standards</div>
        <h2 class="fa-section-title" style="font-size:1.7rem">Regulated, Protected, Independent</h2>
        <p style="color:var(--fa-mid);margin-bottom:24px">Working with a Chartered, FCA-authorised independent adviser means you benefit from the highest standard of regulated financial advice — with your interests at the centre of every recommendation.</p>
        <?php
        $standards = [
            '✓ FCA Authorised & Regulated',
            '✓ No commission — fee-based only',
            '✓ Whole-of-market independence',
            '✓ FSCS protected investments',
            '✓ Written suitability reports on every recommendation',
            '✓ Cashflow modelling included in full plans',
        ];
        foreach ( $standards as $std ) : ?>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;font-size:.9rem;color:var(--fa-navy);font-weight:600">
          <?php echo esc_html( $std ); ?>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ PACKAGES ═══════════ -->
<section class="fa-section fa-section--alt" id="packages">
  <div class="fa-wrap">
    <div style="text-align:center;max-width:620px;margin:0 auto 8px">
      <div class="fa-tag">Fees & Services</div>
      <h2 class="fa-section-title">Transparent, Fixed Fees</h2>
      <p class="fa-section-sub" style="margin:0 auto">No commissions. No surprises. All fees agreed upfront and clearly disclosed before any work begins.</p>
    </div>
    <div class="fa-packages">
      <?php foreach ( $packages as $pkg ) : ?>
      <div class="fa-pkg fa-pkg--<?php echo $pkg['colour']; ?><?php echo $pkg['featured'] ? ' fa-pkg--featured' : ''; ?> fa-reveal">
        <?php if ( $pkg['featured'] ) : ?><div class="fa-pkg__ribbon">⭐ Most Popular</div><?php endif; ?>
        <div class="fa-pkg__name"><?php echo esc_html( $pkg['name'] ); ?></div>
        <div class="fa-pkg__price"><?php echo esc_html( $pkg['price'] ); ?></div>
        <div class="fa-pkg__period"><?php echo esc_html( $pkg['period'] ); ?></div>
        <ul class="fa-pkg__features">
          <?php foreach ( $pkg['features'] as $feat ) : ?>
          <li class="fa-pkg__feature"><?php echo esc_html( $feat ); ?></li>
          <?php endforeach; ?>
        </ul>
        <a href="#booking" class="fa-pkg__btn">Enquire About <?php echo esc_html( $pkg['name'] ); ?></a>
      </div>
      <?php endforeach; ?>
    </div>
    <div class="fa-disclaimer">
      <strong>Important information:</strong> The value of investments can go down as well as up and you may get back less than you invest. The Financial Conduct Authority does not regulate tax planning, estate planning or will writing. Jonathan Whitfield is authorised and regulated by the Financial Conduct Authority.
    </div>
  </div>
</section>

<!-- ═══════════ TESTIMONIALS ═══════════ -->
<section class="fa-section fa-section--light">
  <div class="fa-wrap">
    <div class="fa-tag">Client Testimonials</div>
    <h2 class="fa-section-title">What Clients Say</h2>
    <div class="fa-testimonials">
      <?php
      $testimonials = [
        [ 'text' => '"Jonathan simplified a financial situation that had been overwhelming us for years. He spotted a £40,000 pension that had been lost, consolidated everything and created a retirement plan we can actually understand. He\'s transformed our confidence about the future."', 'name' => 'David & Claire H.', 'role' => 'Retirement Planning Clients' ],
        [ 'text' => '"As a business owner, I\'d never had a proper financial plan — just ad hoc decisions. Jonathan created a complete strategy covering my pension, protection, exit planning and personal investments. The clarity is genuinely life-changing."', 'name' => 'Karen M.', 'role' => 'Director, Technology Sector' ],
        [ 'text' => '"Jonathan reviewed my workplace pension and found I was paying three times what I should in charges for half the performance. Switching to his recommended plan and proper ISA strategy has made a significant difference to our projected retirement income."', 'name' => 'Robert S., 52', 'role' => 'Investment & Pension Client' ],
      ];
      foreach ( $testimonials as $t ) : ?>
      <div class="fa-testimonial fa-reveal">
        <p class="fa-testimonial__text"><?php echo esc_html( $t['text'] ); ?></p>
        <div class="fa-testimonial__name"><?php echo esc_html( $t['name'] ); ?></div>
        <div class="fa-testimonial__role"><?php echo esc_html( $t['role'] ); ?></div>
        <div class="fa-stars">★★★★★</div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════ FAQs ═══════════ -->
<section class="fa-section fa-section--alt" id="faq">
  <div class="fa-wrap">
    <div style="max-width:760px;margin:0 auto">
      <div class="fa-tag">FAQs</div>
      <h2 class="fa-section-title">Common Questions</h2>
      <div class="fa-faq-list">
        <?php foreach ( $faqs as $faq ) : ?>
        <div class="fa-faq">
          <div class="fa-faq__q"><?php echo esc_html( $faq['q'] ); ?></div>
          <div class="fa-faq__a"><div class="fa-faq__a-inner"><?php echo esc_html( $faq['a'] ); ?></div></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ CTA STRIP ═══════════ -->
<div class="fa-cta-strip">
  <div class="fa-wrap">
    <h2>Start Your Financial Journey Today</h2>
    <p>Book a free 30-minute discovery call — no obligation, no hard sell.</p>
    <a href="#booking" class="fa-btn fa-btn--primary">💷 Book Free Discovery Call</a>
  </div>
</div>

<!-- ═══════════ BOOKING ═══════════ -->
<section class="fa-section fa-section--light" id="booking">
  <div class="fa-wrap">
    <div style="max-width:800px;margin:0 auto">
      <div class="fa-tag">Get in Touch</div>
      <h2 class="fa-section-title">Book Your Free Discovery Call</h2>
      <p style="color:var(--fa-mid);margin-bottom:40px">Tell Jonathan a little about your situation and he'll be in touch within one working day to arrange your free 30-minute call.</p>
      <div class="fa-form-wrap">
        <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
          <?php wp_nonce_field( 'tf_fa_booking', 'tf_fa_nonce' ); ?>
          <input type="hidden" name="action" value="tf_fa_booking">
          <div class="fa-form-grid">
            <div class="fa-field">
              <label for="fa-name">Your Name *</label>
              <input type="text" id="fa-name" name="name" placeholder="Your full name" required>
            </div>
            <div class="fa-field">
              <label for="fa-email">Email Address *</label>
              <input type="email" id="fa-email" name="email" placeholder="you@example.com" required>
            </div>
            <div class="fa-field">
              <label for="fa-phone">Phone Number</label>
              <input type="tel" id="fa-phone" name="phone" placeholder="+44 7700 000000">
            </div>
            <div class="fa-field">
              <label for="fa-age">Age Range</label>
              <select id="fa-age" name="age">
                <option value="" disabled selected>Select age range</option>
                <option>Under 35</option>
                <option>35–44</option>
                <option>45–54</option>
                <option>55–64</option>
                <option>65+</option>
              </select>
            </div>
            <div class="fa-field">
              <label for="fa-service">Primary Need *</label>
              <select id="fa-service" name="service" required>
                <option value="" disabled selected>What do you need help with?</option>
                <option>Retirement / Pension Planning</option>
                <option>Investments / ISA</option>
                <option>Mortgage Advice</option>
                <option>Life / Protection Insurance</option>
                <option>Estate / Inheritance Planning</option>
                <option>Business Financial Planning</option>
                <option>General Financial Review</option>
                <option>Not sure yet</option>
              </select>
            </div>
            <div class="fa-field">
              <label for="fa-assets">Approximate Assets</label>
              <select id="fa-assets" name="assets">
                <option value="" disabled selected>Rough ballpark (optional)</option>
                <option>Under £50,000</option>
                <option>£50,000 – £150,000</option>
                <option>£150,000 – £500,000</option>
                <option>£500,000 – £1M</option>
                <option>Over £1M</option>
                <option>Prefer not to say</option>
              </select>
            </div>
            <div class="fa-field">
              <label for="fa-format">Preferred Meeting Format</label>
              <select id="fa-format" name="format">
                <option value="" disabled selected>How would you like to meet?</option>
                <option>In person (Leeds office)</option>
                <option>Video call (Zoom / Teams)</option>
                <option>Phone call</option>
                <option>Either works</option>
              </select>
            </div>
            <div class="fa-field">
              <label for="fa-heard">How Did You Hear About Us?</label>
              <select id="fa-heard" name="heard">
                <option value="" disabled selected>Select an option</option>
                <option>Client referral</option>
                <option>Google search</option>
                <option>Unbiased.co.uk</option>
                <option>VouchedFor</option>
                <option>LinkedIn</option>
                <option>Other</option>
              </select>
            </div>
            <div class="fa-field fa-fg--full">
              <label for="fa-notes">Tell Me About Your Situation</label>
              <textarea id="fa-notes" name="notes" placeholder="Share any context that will help Jonathan prepare for your call — current pensions, investments, key goals, concerns or questions you'd like to address..."></textarea>
            </div>
          </div>
          <div style="margin-top:24px">
            <button type="submit" class="fa-btn fa-btn--primary" style="width:100%;justify-content:center;font-size:1rem;padding:16px">💷 Request Free Discovery Call</button>
          </div>
          <p class="fa-form-note">Jonathan responds within one working day. This is a no-obligation enquiry. No advice will be given until a formal engagement letter has been signed and agreed fees confirmed.</p>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ FOOTER ═══════════ -->
<div class="fa-footer-strip">
  <div class="fa-wrap">
    <p>💷 <?php echo esc_html( $advisor['name'] ); ?> · <?php echo esc_html( $advisor['title'] ); ?> · <?php echo esc_html( $advisor['location'] ); ?> · FCA Ref: 742681 · <?php echo date('Y'); ?></p>
  </div>
</div>

<script>
(function () {
  'use strict';

  /* ── Counters ──────────────────────────────────────────────────── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  const DURATION = 1800;
  function animateCounter(el) {
    const raw     = parseFloat(el.dataset.target);
    if (isNaN(raw)) return;
    const isFloat = el.dataset.float === '1';
    const suffix  = el.dataset.suffix || '';
    const start   = performance.now();
    (function tick(now) {
      const p   = Math.min((now - start) / DURATION, 1);
      const val = raw * easeOut(p);
      el.textContent = (isFloat ? val.toFixed(1) : Math.floor(val)) + suffix;
      if (p < 1) requestAnimationFrame(tick);
    })(start);
  }
  const cObs = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) { animateCounter(e.target); cObs.unobserve(e.target); } });
  }, { threshold: 0.5 });
  document.querySelectorAll('.fa-counter__num[data-target]').forEach(el => cObs.observe(el));

  /* ── FAQ ─────────────────────────────────────────────────────── */
  document.querySelectorAll('.fa-faq__q').forEach(q => {
    q.addEventListener('click', () => {
      const faq  = q.closest('.fa-faq');
      const open = faq.classList.contains('open');
      document.querySelectorAll('.fa-faq.open').forEach(f => f.classList.remove('open'));
      if (!open) faq.classList.add('open');
    });
  });

  /* ── Scroll reveal ─────────────────────────────────────────────── */
  const rObs = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); rObs.unobserve(e.target); } });
  }, { threshold: 0.12 });
  document.querySelectorAll('.fa-reveal').forEach(el => rObs.observe(el));

  /* ── Smooth scroll ─────────────────────────────────────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const t = document.querySelector(a.getAttribute('href'));
      if (t) { e.preventDefault(); t.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    });
  });
})();
</script>

</body>
</html>
</div><!-- .fa-page -->
<?php get_footer(); ?>
