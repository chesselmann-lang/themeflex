<?php
/**
 * Template Name: TF — Fitness Studio
 *
 * Premium gym & fitness studio homepage template.
 * Namespace : --fit-*
 * Fonts     : Bebas Neue + Rubik (Google Fonts)
 * Palette   : midnight #0a0a0f · electric #f0e040 · charcoal #1c1c24 · ash #8a8a9a · white #ffffff
 *
 * @package ThemeFlex
 */

defined('ABSPATH') || exit;

/* ── deterministic randomness ───────────────────────────────────────── */
srand(crc32(get_the_permalink()));

/* ── PHP data ───────────────────────────────────────────────────────── */
$classes = [
    ['name'=>'HIIT Blast',      'cat'=>'cardio',   'time'=>'06:00','duration'=>45,'trainer'=>'Alex','spots'=>12,'total'=>16],
    ['name'=>'Power Lifting',   'cat'=>'strength', 'time'=>'07:30','duration'=>60,'trainer'=>'Maria','spots'=>8, 'total'=>10],
    ['name'=>'Yoga Flow',       'cat'=>'mind',     'time'=>'08:15','duration'=>60,'trainer'=>'Sven', 'spots'=>18,'total'=>20],
    ['name'=>'CrossFit WOD',    'cat'=>'crossfit', 'time'=>'09:00','duration'=>60,'trainer'=>'Alex', 'spots'=>3, 'total'=>14],
    ['name'=>'Spin Cycle',      'cat'=>'cardio',   'time'=>'10:00','duration'=>45,'trainer'=>'Lisa', 'spots'=>14,'total'=>24],
    ['name'=>'Box & Burn',      'cat'=>'combat',   'time'=>'11:30','duration'=>60,'trainer'=>'Tom',  'spots'=>10,'total'=>14],
    ['name'=>'Mobility & Stretch','cat'=>'mind',   'time'=>'12:30','duration'=>45,'trainer'=>'Sven', 'spots'=>20,'total'=>20],
    ['name'=>'Olympic Lifting', 'cat'=>'strength', 'time'=>'17:00','duration'=>90,'trainer'=>'Maria','spots'=>6, 'total'=>8],
    ['name'=>'Evening HIIT',    'cat'=>'cardio',   'time'=>'18:30','duration'=>45,'trainer'=>'Lisa', 'spots'=>9, 'total'=>16],
    ['name'=>'Muay Thai Basics','cat'=>'combat',   'time'=>'19:30','duration'=>60,'trainer'=>'Tom',  'spots'=>12,'total'=>14],
    ['name'=>'Yin Yoga',        'cat'=>'mind',     'time'=>'20:30','duration'=>60,'trainer'=>'Sven', 'spots'=>15,'total'=>18],
    ['name'=>'Night Strength',  'cat'=>'strength', 'time'=>'21:00','duration'=>60,'trainer'=>'Alex', 'spots'=>7, 'total'=>12],
];

$trainers = [
    ['name'=>'Alex Roth',     'specialty'=>'HIIT & CrossFit',     'cert'=>'NASM CPT, CF-L3','years'=>9, 'color'=>'#c83020'],
    ['name'=>'Maria Schneider','specialty'=>'Olympic Lifting',     'cert'=>'NSCA-CSCS, IPF', 'years'=>12,'color'=>'#2060c8'],
    ['name'=>'Sven Koch',     'specialty'=>'Yoga & Mobility',     'cert'=>'RYT-500, FMT',   'years'=>8, 'color'=>'#20a050'],
    ['name'=>'Lisa Bauer',    'specialty'=>'Cycling & Cardio',    'cert'=>'Spinning® Master','years'=>6, 'color'=>'#c820a0'],
    ['name'=>'Tom Fischer',   'specialty'=>'Boxing & Combat',     'cert'=>'WBC Trainer, L2', 'years'=>11,'color'=>'#d08020'],
];

$plans = [
    ['name'=>'Trial',   'price'=>'29','period'=>'month','tag'=>'',          'features'=>['7-day access','All group classes','App access','No commitment'],'highlight'=>false,'cta'=>__('Start Free Trial','themeflex')],
    ['name'=>'Core',    'price'=>'49','period'=>'month','tag'=>'Popular',   'features'=>['Full gym access','All classes','1 PT session/mo','Nutrition guide','App & tracking','Guest pass (1/mo)'],'highlight'=>true,'cta'=>__('Get Core','themeflex')],
    ['name'=>'Elite',   'price'=>'89','period'=>'month','tag'=>'Best Value','features'=>['24/7 access','Unlimited classes','4 PT sessions/mo','Custom programme','Nutrition coaching','Unlimited guest passes','Recovery suite access'],'highlight'=>false,'cta'=>__('Go Elite','themeflex')],
];

$testimonials = [
    ['q'=>'Joined for a month, stayed for two years. The trainers genuinely care. The programming is smart, the community is incredible. I\'ve lost 18 kg and found my sport.','n'=>'Sarah K.','result'=>'−18 kg in 9 months'],
    ['q'=>'Maria\'s lifting coaching transformed my technique. My back squat went from 80 kg to 145 kg in 11 months. Unbelievable what structured coaching does.','n'=>'Tobias M.','result'=>'+65 kg squat in 11 months'],
    ['q'=>'I\'m 58 years old and do Yoga Flow every morning. This gym doesn\'t just cater for the young and strong — everyone is welcome and that makes it special.','n'=>'Gerlinde H.','result'=>'2 years consistent training'],
];

/* ── PHP-generated particle grid ── */
$particles = [];
for($i=0;$i<40;$i++){
    $particles[] = [
        'x'   => rand(1,99),
        'y'   => rand(1,99),
        'size'=> rand(1,4),
        'op'  => rand(5,20)/100,
        'del' => rand(0,5000),
        'dur' => rand(20,50)/10,
    ];
}

/* ── PHP-generated weight plates for hero ── */
$plate_weights = [45,35,25,25,10,10,5,5,2.5,2.5];

get_header(); ?>
<!-- ================================================================
     GOOGLE FONTS
================================================================ -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Rubik:ital,wght@0,300;0,400;0,500;0,700;1,400&display=swap" rel="stylesheet">

<style>
/* ================================================================
   ROOT TOKENS — FITNESS
================================================================ */
:root{
  --fit-midnight: #0a0a0f;
  --fit-electric: #f0e040;
  --fit-charcoal: #1c1c24;
  --fit-ash:      #8a8a9a;
  --fit-white:    #ffffff;
  --fit-orange:   #f04820;
  --fit-dark:     #060609;
  --fit-mid:      #14141c;
  --fit-border:   rgba(255,255,255,.07);
  --fit-ff-head:  'Bebas Neue', 'Impact', sans-serif;
  --fit-ff-body:  'Rubik', system-ui, sans-serif;
  --fit-r:        6px;
  --fit-trans:    .28s ease;
}

/* ================================================================
   GLOBAL RESET
================================================================ */
.fit-page *{box-sizing:border-box;margin:0;padding:0;}
.fit-page{font-family:var(--fit-ff-body);color:var(--fit-white);background:var(--fit-midnight);overflow-x:hidden;}
.fit-container{max-width:1240px;margin:0 auto;padding:0 2rem;}
.fit-section{padding:6rem 0;}
.fit-section--alt{background:var(--fit-charcoal);}
.fit-section--dark{background:var(--fit-dark);}

/* ================================================================
   HERO
================================================================ */
.fit-hero{
  min-height:100vh;
  background:
    radial-gradient(ellipse 70% 50% at 50% 100%,#1a1a2a 0%,transparent 70%),
    radial-gradient(ellipse 40% 30% at 70% 20%,rgba(240,224,64,.04) 0%,transparent 70%),
    var(--fit-midnight);
  display:grid;
  grid-template-columns:1fr 1fr;
  align-items:center;
  gap:3rem;
  padding:9rem 2rem 5rem;
  max-width:1240px;
  margin:0 auto;
  position:relative;
}
.fit-hero::before{
  content:'';position:fixed;inset:0;
  background:
    repeating-linear-gradient(0deg,rgba(255,255,255,.013) 0,rgba(255,255,255,.013) 1px,transparent 1px,transparent 60px),
    repeating-linear-gradient(90deg,rgba(255,255,255,.013) 0,rgba(255,255,255,.013) 1px,transparent 1px,transparent 60px);
  pointer-events:none;z-index:0;
}

/* Particles */
.fit-particle{
  position:fixed;
  border-radius:50%;
  background:var(--fit-electric);
  animation:fit-float var(--fit-dur,3s) ease-in-out infinite alternate;
  pointer-events:none;z-index:0;
}
@keyframes fit-float{
  from{transform:translateY(0);}
  to{transform:translateY(-12px);}
}

/* ── Hero copy ── */
.fit-hero__copy{position:relative;z-index:1;}
.fit-hero__eyebrow{
  display:inline-flex;align-items:center;gap:.6rem;
  font-family:var(--fit-ff-body);font-size:.72rem;font-weight:700;
  letter-spacing:.22em;text-transform:uppercase;color:var(--fit-electric);
  margin-bottom:1.2rem;
}
.fit-hero__eyebrow::before{
  content:'';display:inline-block;width:2rem;height:2px;background:var(--fit-electric);
}
.fit-hero__h1{
  font-family:var(--fit-ff-head);font-size:clamp(5rem,10vw,9.5rem);
  line-height:.9;letter-spacing:.02em;color:var(--fit-white);margin-bottom:1.5rem;
}
.fit-hero__h1 .accent{
  color:var(--fit-electric);
  -webkit-text-stroke:2px var(--fit-electric);
  color:transparent;
}
.fit-hero__lead{
  font-size:1rem;line-height:1.75;color:var(--fit-ash);
  max-width:46ch;margin-bottom:2.5rem;
}
.fit-hero__ctas{display:flex;gap:1rem;flex-wrap:wrap;}
.fit-btn{
  display:inline-flex;align-items:center;gap:.5rem;
  padding:.9rem 2.2rem;border-radius:var(--fit-r);
  font-family:var(--fit-ff-body);font-size:.9rem;font-weight:700;
  letter-spacing:.06em;text-decoration:none;cursor:pointer;
  border:2px solid transparent;transition:var(--fit-trans);
}
.fit-btn--primary{background:var(--fit-electric);color:var(--fit-midnight);}
.fit-btn--primary:hover{background:#fff040;transform:translateY(-2px);}
.fit-btn--ghost{border-color:rgba(255,255,255,.2);color:var(--fit-white);}
.fit-btn--ghost:hover{border-color:var(--fit-electric);color:var(--fit-electric);}

/* ── hero ticker ── */
.fit-hero__ticker{
  margin-top:3rem;padding-top:2rem;
  border-top:1px solid var(--fit-border);
  display:flex;gap:3rem;flex-wrap:wrap;
}
.fit-ticker-item{}
.fit-ticker-num{
  display:block;font-family:var(--fit-ff-head);font-size:2.5rem;
  color:var(--fit-electric);letter-spacing:.03em;line-height:1;
}
.fit-ticker-label{
  font-size:.7rem;font-weight:700;letter-spacing:.15em;
  text-transform:uppercase;color:var(--fit-ash);margin-top:.3rem;
}

/* ================================================================
   CSS GYM HERO ART — BARBELL
================================================================ */
.fit-hero__art{
  position:relative;height:480px;display:flex;align-items:center;justify-content:center;
  z-index:1;
}

/* Barbell */
.fit-barbell-wrap{
  position:relative;width:100%;height:100%;display:flex;align-items:center;justify-content:center;
}

/* The bar (horizontal rod) */
.fit-bar{
  position:absolute;
  width:360px;height:18px;
  background:linear-gradient(180deg,#9a9a9a 0%,#6a6a6a 50%,#7a7a7a 100%);
  border-radius:9px;
  box-shadow:0 4px 16px rgba(0,0,0,.4),inset 0 2px 3px rgba(255,255,255,.2);
  top:50%;transform:translateY(-50%);
  z-index:2;
}
/* Knurling texture on bar */
.fit-bar::before{
  content:'';position:absolute;inset:3px 80px;
  background:repeating-linear-gradient(
    90deg,
    rgba(0,0,0,.15) 0,rgba(0,0,0,.15) 2px,
    transparent 2px,transparent 6px
  );
  border-radius:4px;
}
/* Collar left */
.fit-collar{
  position:absolute;
  width:22px;height:30px;
  background:linear-gradient(180deg,#c0c0c0 0%,#808080 100%);
  border-radius:4px;
  top:50%;transform:translateY(-50%);
  z-index:3;
}
.fit-collar--l{left:calc(50% - 180px - 22px);}
.fit-collar--r{right:calc(50% - 180px - 22px);}

/* Weight plates stack */
.fit-plate-stack{
  position:absolute;top:50%;transform:translateY(-50%);
  display:flex;flex-direction:row;align-items:center;
  z-index:2;
}
.fit-plate-stack--l{left:calc(50% - 180px);flex-direction:row-reverse;}
.fit-plate-stack--r{right:calc(50% - 180px);}

.fit-plate{
  height:var(--fit-ph,100px);
  width:var(--fit-pw,22px);
  background:linear-gradient(90deg,var(--fit-pc1,#c82020) 0%,var(--fit-pc2,#901010) 100%);
  border-radius:4px;
  margin:0 1px;
  box-shadow:2px 0 6px rgba(0,0,0,.3),inset 1px 0 2px rgba(255,255,255,.15);
  position:relative;
}
.fit-plate::after{
  content:'';position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);
  width:30%;height:30%;border-radius:50%;
  background:rgba(0,0,0,.2);
  border:2px solid rgba(255,255,255,.1);
}

/* Ground shadow */
.fit-barbell-shadow{
  position:absolute;bottom:80px;left:50%;transform:translateX(-50%);
  width:380px;height:20px;
  background:radial-gradient(ellipse at 50% 50%,rgba(0,0,0,.55) 0%,transparent 70%);
  filter:blur(8px);
}

/* Weight plates on floor (scattered) */
.fit-floor-plate{
  position:absolute;
  border-radius:50%;
  background:conic-gradient(var(--fit-fpc,#c82020) 0deg,var(--fit-fpc,#c82020) 30deg,transparent 30deg,transparent 60deg,var(--fit-fpc,#c82020) 60deg);
}

/* ── Dumbbells ── */
.fit-dumbbell{
  position:absolute;
  display:flex;align-items:center;
}
.fit-db-plate{
  width:18px;height:36px;border-radius:3px;
}
.fit-db-handle{
  width:36px;height:12px;
  background:linear-gradient(180deg,#9a9a9a 0%,#5a5a5a 100%);
  border-radius:4px;
}
/* Kettlebell */
.fit-kettlebell{
  position:absolute;
}
.fit-kb-ball{
  width:52px;height:52px;border-radius:50%;
  background:radial-gradient(circle at 38% 32%,#4a4a4a 0%,#1a1a1a 80%);
  box-shadow:0 6px 18px rgba(0,0,0,.5),inset 0 2px 4px rgba(255,255,255,.06);
  position:relative;
}
.fit-kb-ball::before{
  content:'';position:absolute;top:6px;left:10px;
  width:14px;height:10px;
  background:rgba(255,255,255,.06);border-radius:50%;
}
.fit-kb-handle{
  position:absolute;top:-22px;left:50%;transform:translateX(-50%);
  width:32px;height:22px;
  border:5px solid #5a5a5a;
  border-bottom:none;border-radius:16px 16px 0 0;
}

/* Heart rate line decoration */
.fit-ecg-wrap{
  position:absolute;bottom:40px;left:0;right:0;
  height:50px;overflow:hidden;opacity:.15;
}
.fit-ecg-wrap svg{width:200%;animation:fit-ecg 3s linear infinite;}
@keyframes fit-ecg{from{transform:translateX(0);}to{transform:translateX(-50%);}}

/* Electric bolt */
.fit-bolt{
  position:absolute;top:30px;right:15%;
  opacity:.08;
}

/* ================================================================
   MARQUEE — classes marquee
================================================================ */
.fit-marquee-wrap{
  background:var(--fit-electric);padding:.65rem 0;overflow:hidden;
}
.fit-marquee-track{
  display:flex;align-items:center;width:max-content;
  animation:fit-marquee 20s linear infinite;
}
@keyframes fit-marquee{to{transform:translateX(-50%);}}
.fit-marquee-item{
  padding:0 2rem;white-space:nowrap;
  font-family:var(--fit-ff-head);font-size:1rem;letter-spacing:.1em;
  color:var(--fit-midnight);
  display:flex;align-items:center;gap:1rem;
}
.fit-marquee-item::before{content:'●';font-size:.5rem;}

/* ================================================================
   SECTION HEADER
================================================================ */
.fit-section-header{text-align:center;margin-bottom:3.5rem;}
.fit-section-header__label{
  display:inline-flex;align-items:center;gap:.7rem;
  font-size:.72rem;font-weight:700;letter-spacing:.22em;text-transform:uppercase;
  color:var(--fit-electric);margin-bottom:.8rem;
}
.fit-section-header__label::before,.fit-section-header__label::after{
  content:'';display:inline-block;width:1.5rem;height:2px;background:var(--fit-electric);
}
.fit-section-header__h2{
  font-family:var(--fit-ff-head);font-size:clamp(2.5rem,5vw,4.5rem);
  letter-spacing:.04em;color:var(--fit-white);margin-bottom:.6rem;
}
.fit-section-header__h2 .accent{color:var(--fit-electric);}
.fit-section-header__sub{
  font-size:.95rem;line-height:1.75;color:var(--fit-ash);max-width:55ch;margin:0 auto;
}

/* ================================================================
   CLASS SCHEDULE
================================================================ */
.fit-filter-bar{
  display:flex;justify-content:center;gap:.5rem;flex-wrap:wrap;margin-bottom:2rem;
}
.fit-filter-btn{
  padding:.5rem 1.4rem;border:1.5px solid var(--fit-border);border-radius:30px;
  font-family:var(--fit-ff-body);font-size:.8rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
  background:transparent;color:var(--fit-ash);cursor:pointer;transition:var(--fit-trans);
}
.fit-filter-btn.active,.fit-filter-btn:hover{
  border-color:var(--fit-electric);color:var(--fit-electric);
}

.fit-schedule{width:100%;border-collapse:collapse;}
.fit-schedule tr.hidden{display:none;}
.fit-schedule thead tr{
  border-bottom:1px solid rgba(240,224,64,.25);
}
.fit-schedule th{
  font-family:var(--fit-ff-body);font-size:.7rem;font-weight:700;letter-spacing:.14em;
  text-transform:uppercase;color:var(--fit-ash);padding:.8rem 1rem;text-align:left;
}
.fit-schedule tbody tr{
  border-bottom:1px solid var(--fit-border);
  transition:var(--fit-trans);
}
.fit-schedule tbody tr:hover{background:rgba(255,255,255,.02);}
.fit-schedule td{padding:.9rem 1rem;font-size:.9rem;color:rgba(255,255,255,.8);}
.fit-schedule td:first-child{
  font-family:var(--fit-ff-head);font-size:1.1rem;letter-spacing:.04em;color:var(--fit-white);
}
.fit-class-cat{
  display:inline-block;padding:.2rem .65rem;border-radius:20px;
  font-size:.7rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;
}
.fit-class-cat--cardio  {background:rgba(240,72,32,.2); color:#f04820;}
.fit-class-cat--strength{background:rgba(32,96,200,.2); color:#4088f0;}
.fit-class-cat--mind    {background:rgba(32,160,80,.2); color:#40c060;}
.fit-class-cat--crossfit{background:rgba(240,224,64,.2);color:var(--fit-electric);}
.fit-class-cat--combat  {background:rgba(200,80,200,.2);color:#e060e0;}
.fit-spots-bar{
  display:flex;align-items:center;gap:.6rem;
}
.fit-spots-bg{
  flex:1;max-width:80px;height:5px;background:rgba(255,255,255,.08);border-radius:3px;overflow:hidden;
}
.fit-spots-fill{height:100%;border-radius:3px;background:var(--fit-electric);transition:width .4s ease;}
.fit-spots-fill--low{background:var(--fit-orange);}
.fit-spots-num{font-size:.75rem;color:var(--fit-ash);}
.fit-book-btn{
  padding:.35rem .9rem;border:1px solid var(--fit-electric);
  color:var(--fit-electric);border-radius:var(--fit-r);
  font-size:.75rem;font-weight:700;cursor:pointer;
  background:transparent;transition:var(--fit-trans);
}
.fit-book-btn:hover{background:var(--fit-electric);color:var(--fit-midnight);}

/* ================================================================
   TRAINERS
================================================================ */
.fit-trainer-grid{
  display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:1.5rem;
}
.fit-trainer-card{
  border-radius:8px;overflow:hidden;background:var(--fit-charcoal);
  border:1px solid var(--fit-border);transition:var(--fit-trans);
  position:relative;
}
.fit-trainer-card:hover{transform:translateY(-4px);border-color:rgba(240,224,64,.2);}
.fit-trainer-card::before{
  content:'';position:absolute;top:0;left:0;right:0;height:3px;
  background:var(--fit-trainer-col,var(--fit-electric));
}
.fit-trainer-portrait{
  height:180px;
  display:flex;align-items:flex-end;justify-content:center;
  overflow:hidden;
  background:var(--fit-mid);
}
.fit-trainer-body{padding:1.2rem 1rem 1.4rem;}
.fit-trainer-name{
  font-family:var(--fit-ff-head);font-size:1.3rem;letter-spacing:.05em;
  color:var(--fit-white);margin-bottom:.2rem;
}
.fit-trainer-spec{
  font-size:.78rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;
  color:var(--fit-trainer-col,var(--fit-electric));margin-bottom:.5rem;
}
.fit-trainer-cert{font-size:.78rem;color:var(--fit-ash);margin-bottom:.3rem;}
.fit-trainer-years{font-size:.75rem;color:var(--fit-ash);}

/* ================================================================
   PRICING
================================================================ */
.fit-plans-grid{
  display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:1.8rem;
  align-items:start;
}
.fit-plan{
  border-radius:10px;overflow:hidden;
  background:var(--fit-charcoal);border:1px solid var(--fit-border);
  position:relative;transition:var(--fit-trans);
}
.fit-plan:hover{transform:translateY(-4px);}
.fit-plan--highlight{
  background:var(--fit-midnight);
  border:2px solid var(--fit-electric);
  box-shadow:0 0 40px rgba(240,224,64,.08);
}
.fit-plan__badge{
  position:absolute;top:14px;right:14px;
  font-family:var(--fit-ff-body);font-size:.68rem;font-weight:700;
  letter-spacing:.1em;text-transform:uppercase;
  padding:.25rem .7rem;border-radius:20px;
  background:var(--fit-electric);color:var(--fit-midnight);
}
.fit-plan__head{padding:2rem 2rem 1.5rem;border-bottom:1px solid var(--fit-border);}
.fit-plan__name{
  font-family:var(--fit-ff-head);font-size:1.8rem;letter-spacing:.08em;
  color:var(--fit-white);margin-bottom:.5rem;
}
.fit-plan__price{
  font-family:var(--fit-ff-head);font-size:3.5rem;color:var(--fit-white);
  line-height:1;letter-spacing:-.01em;
}
.fit-plan--highlight .fit-plan__price{color:var(--fit-electric);}
.fit-plan__price sup{font-size:1.4rem;vertical-align:top;margin-top:.6rem;display:inline-block;}
.fit-plan__price sub{font-family:var(--fit-ff-body);font-size:.8rem;font-weight:400;color:var(--fit-ash);}
.fit-plan__body{padding:1.5rem 2rem 2rem;}
.fit-plan__features{list-style:none;display:flex;flex-direction:column;gap:.7rem;margin-bottom:2rem;}
.fit-plan__feature{
  display:flex;align-items:center;gap:.7rem;
  font-size:.88rem;color:rgba(255,255,255,.75);line-height:1.5;
}
.fit-plan__feature::before{
  content:'✓';display:inline-flex;align-items:center;justify-content:center;
  width:18px;height:18px;border-radius:50%;flex-shrink:0;
  background:rgba(240,224,64,.15);color:var(--fit-electric);font-size:.72rem;font-weight:700;
}
.fit-plan__cta{
  display:block;width:100%;padding:.95rem;text-align:center;
  border-radius:var(--fit-r);border:2px solid;
  font-family:var(--fit-ff-head);font-size:1.2rem;letter-spacing:.06em;
  cursor:pointer;text-decoration:none;transition:var(--fit-trans);
}
.fit-plan--highlight .fit-plan__cta{
  background:var(--fit-electric);color:var(--fit-midnight);border-color:var(--fit-electric);
}
.fit-plan--highlight .fit-plan__cta:hover{background:#fff040;}
.fit-plan:not(.fit-plan--highlight) .fit-plan__cta{
  border-color:rgba(255,255,255,.2);color:var(--fit-white);
}
.fit-plan:not(.fit-plan--highlight) .fit-plan__cta:hover{
  border-color:var(--fit-electric);color:var(--fit-electric);
}

/* ================================================================
   STATS
================================================================ */
.fit-stats{background:var(--fit-electric);padding:4.5rem 0;}
.fit-stats__grid{
  display:grid;grid-template-columns:repeat(4,1fr);gap:2rem;text-align:center;
}
.fit-stat-num{
  font-family:var(--fit-ff-head);font-size:clamp(3rem,6vw,5.5rem);
  color:var(--fit-midnight);display:block;margin-bottom:.2rem;letter-spacing:.02em;
}
.fit-stat-label{
  font-size:.72rem;font-weight:700;letter-spacing:.15em;text-transform:uppercase;
  color:rgba(10,10,15,.55);
}

/* ================================================================
   TESTIMONIALS
================================================================ */
.fit-testi-grid{
  display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:1.8rem;
}
.fit-testi-card{
  background:var(--fit-charcoal);border-radius:8px;padding:2rem;
  border:1px solid var(--fit-border);transition:var(--fit-trans);
  position:relative;overflow:hidden;
}
.fit-testi-card::before{
  content:'';position:absolute;bottom:0;left:0;right:0;height:2px;
  background:var(--fit-electric);transform:scaleX(0);transform-origin:left;
  transition:transform .35s ease;
}
.fit-testi-card:hover::before{transform:scaleX(1);}
.fit-testi-result{
  display:inline-block;padding:.3rem .8rem;border-radius:var(--fit-r);
  background:rgba(240,224,64,.1);color:var(--fit-electric);
  font-size:.72rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;
  margin-bottom:1rem;
}
.fit-testi-text{
  font-size:.95rem;font-style:italic;line-height:1.75;
  color:rgba(255,255,255,.75);margin-bottom:1.2rem;
}
.fit-testi-name{
  font-family:var(--fit-ff-head);font-size:1rem;letter-spacing:.06em;color:var(--fit-white);
}

/* ================================================================
   BOOKING FORM
================================================================ */
.fit-form-section{background:var(--fit-charcoal);padding:6rem 0;}
.fit-form-inner{
  max-width:780px;margin:0 auto;
  padding:3rem;background:var(--fit-midnight);
  border-radius:10px;border:1px solid var(--fit-border);
}
.fit-form-title{
  font-family:var(--fit-ff-head);font-size:3rem;letter-spacing:.04em;
  color:var(--fit-white);margin-bottom:.4rem;
}
.fit-form-title span{color:var(--fit-electric);}
.fit-form-sub{font-size:.9rem;color:var(--fit-ash);margin-bottom:2.5rem;}
.fit-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:1rem;}
.fit-fg{display:flex;flex-direction:column;gap:.35rem;}
.fit-fg--full{grid-column:1/-1;}
.fit-label{
  font-size:.7rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;
  color:rgba(138,138,154,.65);
}
.fit-input,.fit-select,.fit-textarea{
  padding:.82rem 1rem;border-radius:var(--fit-r);
  border:1px solid rgba(255,255,255,.09);
  background:rgba(255,255,255,.04);color:var(--fit-white);
  font-family:var(--fit-ff-body);font-size:.9rem;transition:var(--fit-trans);
}
.fit-input::placeholder,.fit-textarea::placeholder{color:rgba(138,138,154,.3);}
.fit-input:focus,.fit-select:focus,.fit-textarea:focus{
  outline:none;border-color:var(--fit-electric);background:rgba(240,224,64,.05);
}
.fit-select option{background:#1c1c24;color:#fff;}
.fit-consent{
  display:flex;align-items:flex-start;gap:.7rem;
  font-size:.83rem;color:rgba(138,138,154,.6);line-height:1.5;
}
.fit-consent input{margin-top:.2rem;accent-color:var(--fit-electric);}
.fit-submit{
  padding:1rem 2.5rem;background:var(--fit-electric);color:var(--fit-midnight);
  border:none;border-radius:var(--fit-r);
  font-family:var(--fit-ff-head);font-size:1.4rem;letter-spacing:.06em;
  cursor:pointer;transition:var(--fit-trans);margin-top:.8rem;
}
.fit-submit:hover{background:#fff040;transform:translateY(-2px);}

/* ================================================================
   SCROLL REVEAL
================================================================ */
.fit-reveal{opacity:0;transform:translateY(24px);transition:opacity .65s ease,transform .65s ease;}
.fit-reveal.visible{opacity:1;transform:none;}

/* ================================================================
   RESPONSIVE
================================================================ */
@media(max-width:900px){
  .fit-hero{grid-template-columns:1fr;padding:8rem 1.5rem 3rem;}
  .fit-hero__art{height:320px;order:−1;}
  .fit-stats__grid{grid-template-columns:repeat(2,1fr);}
  .fit-form-grid{grid-template-columns:1fr;}
  .fit-bar{width:260px;}
}
@media(max-width:600px){
  .fit-section{padding:4rem 0;}
  .fit-hero__h1{font-size:4rem;}
  .fit-stats__grid{grid-template-columns:1fr 1fr;}
  .fit-form-inner{padding:2rem 1.2rem;}
  .fit-schedule{font-size:.82rem;}
}
</style>

<!-- ================================================================
     PAGE WRAPPER
================================================================ -->
<div class="fit-page">

<!-- ================================================================
     FLOATING PARTICLES (fixed, behind everything)
================================================================ -->
<?php foreach($particles as $p): ?>
<div class="fit-particle" style="
  left:<?php echo $p['x']; ?>%;
  top:<?php echo $p['y']; ?>%;
  width:<?php echo $p['size']; ?>px;
  height:<?php echo $p['size']; ?>px;
  opacity:<?php echo $p['op']; ?>;
  --fit-dur:<?php echo $p['dur']; ?>s;
  animation-delay:<?php echo $p['del']; ?>ms;
" aria-hidden="true"></div>
<?php endforeach; ?>

<!-- ================================================================
     HERO
================================================================ -->
<section aria-label="<?php esc_attr_e('Fitness Studio Hero','themeflex'); ?>">
<div class="fit-hero">
  <!-- Copy -->
  <div class="fit-hero__copy">
    <p class="fit-hero__eyebrow"><?php esc_html_e('Munich\'s Elite Training Hub','themeflex'); ?></p>
    <h1 class="fit-hero__h1">
      <?php esc_html_e('FORGE','themeflex'); ?><br>
      <span class="accent"><?php esc_html_e('YOUR','themeflex'); ?></span><br>
      <?php esc_html_e('LIMIT','themeflex'); ?>
    </h1>
    <p class="fit-hero__lead">
      <?php esc_html_e('State-of-the-art equipment. World-class coaching. A community that shows up. Start your transformation today — no contracts required.','themeflex'); ?>
    </p>
    <div class="fit-hero__ctas">
      <a href="#schedule" class="fit-btn fit-btn--primary"><?php esc_html_e('View Schedule','themeflex'); ?></a>
      <a href="#membership" class="fit-btn fit-btn--ghost"><?php esc_html_e('See Memberships','themeflex'); ?></a>
    </div>
    <div class="fit-hero__ticker">
      <?php
      $tickers = [
        ['num'=>'2,800+','lbl'=>__('Active Members','themeflex')],
        ['num'=>'60+','lbl'=>__('Classes / Week','themeflex')],
        ['num'=>'4.9★','lbl'=>__('Google Rating','themeflex')],
      ];
      foreach($tickers as $tk): ?>
      <div class="fit-ticker-item">
        <span class="fit-ticker-num"><?php echo esc_html($tk['num']); ?></span>
        <span class="fit-ticker-label"><?php echo esc_html($tk['lbl']); ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- CSS Gym Art -->
  <div class="fit-hero__art" aria-hidden="true">

    <!-- Electric bolt -->
    <svg class="fit-bolt" width="80" height="140" viewBox="0 0 80 140">
      <polygon points="50,0 20,70 44,70 30,140 70,52 44,52 60,0" fill="var(--fit-electric)"/>
    </svg>

    <div class="fit-barbell-wrap">
      <!-- Barbell bar -->
      <div class="fit-bar"></div>

      <!-- Collar left -->
      <div class="fit-collar fit-collar--l"></div>
      <div class="fit-collar fit-collar--r"></div>

      <!-- Left plate stack -->
      <div class="fit-plate-stack fit-plate-stack--l">
        <?php
        $plate_defs = [
          ['h'=>110,'w'=>24,'c1'=>'#c82020','c2'=>'#901010'], // 45
          ['h'=>96, 'w'=>21,'c1'=>'#2040c8','c2'=>'#103090'], // 35
          ['h'=>80, 'w'=>18,'c1'=>'#c8c820','c2'=>'#909010'], // 25
          ['h'=>80, 'w'=>18,'c1'=>'#c8c820','c2'=>'#909010'], // 25
          ['h'=>56, 'w'=>14,'c1'=>'#20c820','c2'=>'#109010'], // 10
          ['h'=>56, 'w'=>14,'c1'=>'#20c820','c2'=>'#109010'], // 10
        ];
        foreach($plate_defs as $pd): ?>
        <div class="fit-plate" style="
          --fit-ph:<?php echo $pd['h']; ?>px;
          --fit-pw:<?php echo $pd['w']; ?>px;
          --fit-pc1:<?php echo $pd['c1']; ?>;
          --fit-pc2:<?php echo $pd['c2']; ?>;
        "></div>
        <?php endforeach; ?>
      </div>

      <!-- Right plate stack (mirror) -->
      <div class="fit-plate-stack fit-plate-stack--r">
        <?php foreach($plate_defs as $pd): ?>
        <div class="fit-plate" style="
          --fit-ph:<?php echo $pd['h']; ?>px;
          --fit-pw:<?php echo $pd['w']; ?>px;
          --fit-pc1:<?php echo $pd['c1']; ?>;
          --fit-pc2:<?php echo $pd['c2']; ?>;
        "></div>
        <?php endforeach; ?>
      </div>

      <!-- Shadow -->
      <div class="fit-barbell-shadow"></div>

      <!-- Scattered floor plates (left side) -->
      <?php
      $fp = [
        ['bot'=>'10%','l'=>'4%','s'=>60,'c'=>'#c82020'],
        ['bot'=>'6%','l'=>'2%','s'=>44,'c'=>'#2040c8'],
        ['bot'=>'12%','l'=>'10%','s'=>34,'c'=>'#c8c820'],
      ];
      foreach($fp as $f): ?>
      <div class="fit-floor-plate" style="
        bottom:<?php echo $f['bot']; ?>;
        left:<?php echo $f['l']; ?>;
        width:<?php echo $f['s']; ?>px;
        height:<?php echo $f['s']; ?>px;
        --fit-fpc:<?php echo $f['c']; ?>;
        opacity:.6;
      "></div>
      <?php endforeach; ?>

      <!-- Kettlebell -->
      <div class="fit-kettlebell" style="bottom:18%;right:8%;">
        <div class="fit-kb-handle"></div>
        <div class="fit-kb-ball"></div>
      </div>

      <!-- Small dumbbell -->
      <div class="fit-dumbbell" style="position:absolute;bottom:15%;left:5%;transform:rotate(-20deg);">
        <div class="fit-db-plate" style="background:linear-gradient(90deg,#c82020,#901010);width:14px;height:28px;border-radius:3px;"></div>
        <div class="fit-db-handle"></div>
        <div class="fit-db-plate" style="background:linear-gradient(90deg,#c82020,#901010);width:14px;height:28px;border-radius:3px;"></div>
      </div>
    </div>

    <!-- ECG line -->
    <div class="fit-ecg-wrap">
      <svg viewBox="0 0 400 50" fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none">
        <polyline points="0,25 40,25 50,10 60,40 70,5 80,45 90,25 130,25 145,25 155,10 165,40 175,5 185,45 195,25 235,25 250,25 260,10 270,40 280,5 290,45 300,25 340,25 355,25 365,10 375,40 385,5 395,45 400,25"
          stroke="var(--fit-electric)" stroke-width="2" fill="none"/>
      </svg>
    </div>

  </div>
</div>
</section>

<!-- ================================================================
     MARQUEE
================================================================ -->
<div class="fit-marquee-wrap" aria-hidden="true">
  <div class="fit-marquee-track">
    <?php
    $items = ['HIIT','Strength','CrossFit','Yoga','Boxing','Cycling','Olympic Lifting','Mobility','Nutrition','Recovery','Personal Training','Community'];
    foreach(array_merge($items,$items) as $it): ?>
    <span class="fit-marquee-item"><?php echo esc_html($it); ?></span>
    <?php endforeach; ?>
  </div>
</div>

<!-- ================================================================
     SCHEDULE
================================================================ -->
<section id="schedule" class="fit-section">
  <div class="fit-container">
    <div class="fit-section-header fit-reveal">
      <p class="fit-section-header__label"><?php esc_html_e('Today\'s Classes','themeflex'); ?></p>
      <h2 class="fit-section-header__h2"><?php esc_html_e('Class <span class="accent">Schedule</span>','themeflex'); ?></h2>
      <p class="fit-section-header__sub"><?php esc_html_e('12 classes daily, 7 days a week. Filter by category and book your spot — all included in your membership.','themeflex'); ?></p>
    </div>

    <div class="fit-filter-bar" role="group" aria-label="<?php esc_attr_e('Filter by class type','themeflex'); ?>">
      <button class="fit-filter-btn active" data-filter="all" aria-pressed="true"><?php esc_html_e('All','themeflex'); ?></button>
      <button class="fit-filter-btn" data-filter="cardio"   aria-pressed="false"><?php esc_html_e('Cardio','themeflex'); ?></button>
      <button class="fit-filter-btn" data-filter="strength" aria-pressed="false"><?php esc_html_e('Strength','themeflex'); ?></button>
      <button class="fit-filter-btn" data-filter="crossfit" aria-pressed="false"><?php esc_html_e('CrossFit','themeflex'); ?></button>
      <button class="fit-filter-btn" data-filter="mind"     aria-pressed="false"><?php esc_html_e('Mind & Body','themeflex'); ?></button>
      <button class="fit-filter-btn" data-filter="combat"   aria-pressed="false"><?php esc_html_e('Combat','themeflex'); ?></button>
    </div>

    <div style="overflow-x:auto;">
      <table class="fit-schedule" aria-label="<?php esc_attr_e('Class schedule','themeflex'); ?>">
        <thead>
          <tr>
            <th><?php esc_html_e('Class','themeflex'); ?></th>
            <th><?php esc_html_e('Category','themeflex'); ?></th>
            <th><?php esc_html_e('Time','themeflex'); ?></th>
            <th><?php esc_html_e('Duration','themeflex'); ?></th>
            <th><?php esc_html_e('Trainer','themeflex'); ?></th>
            <th><?php esc_html_e('Spots','themeflex'); ?></th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($classes as $cl):
            $pct = round($cl['spots'] / $cl['total'] * 100);
            $full = $cl['spots']===0;
            $low  = $pct < 30;
            $fill_cls = $low ? 'fit-spots-fill--low' : '';
          ?>
          <tr data-cat="<?php echo esc_attr($cl['cat']); ?>">
            <td><?php echo esc_html($cl['name']); ?></td>
            <td><span class="fit-class-cat fit-class-cat--<?php echo esc_attr($cl['cat']); ?>"><?php echo esc_html($cl['cat']); ?></span></td>
            <td><?php echo esc_html($cl['time']); ?></td>
            <td><?php echo esc_html($cl['duration']); ?> <?php esc_html_e('min','themeflex'); ?></td>
            <td><?php echo esc_html($cl['trainer']); ?></td>
            <td>
              <div class="fit-spots-bar">
                <div class="fit-spots-bg">
                  <div class="fit-spots-fill <?php echo esc_attr($fill_cls); ?>" style="width:<?php echo 100-$pct; ?>%"></div>
                </div>
                <span class="fit-spots-num"><?php echo $full ? esc_html__('Full','themeflex') : esc_html($cl['spots'].' left'); ?></span>
              </div>
            </td>
            <td>
              <?php if(!$full): ?>
              <button class="fit-book-btn" type="button"><?php esc_html_e('Book','themeflex'); ?></button>
              <?php else: ?>
              <button class="fit-book-btn" type="button" disabled style="opacity:.4;cursor:not-allowed;"><?php esc_html_e('Full','themeflex'); ?></button>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</section>

<!-- ================================================================
     TRAINERS
================================================================ -->
<section class="fit-section fit-section--alt">
  <div class="fit-container">
    <div class="fit-section-header fit-reveal">
      <p class="fit-section-header__label"><?php esc_html_e('Expert Coaching','themeflex'); ?></p>
      <h2 class="fit-section-header__h2"><?php esc_html_e('Meet the <span class="accent">Team</span>','themeflex'); ?></h2>
      <p class="fit-section-header__sub"><?php esc_html_e('Every trainer holds multiple international certifications and has competed or coached at elite level. These are not gym instructors — these are performance coaches.','themeflex'); ?></p>
    </div>

    <div class="fit-trainer-grid">
      <?php foreach($trainers as $i => $t):
        $body_colors = ['#c83020','#2060c8','#20a050','#c820a0','#d08020'];
        $bc = $body_colors[$i % count($body_colors)];
      ?>
      <div class="fit-trainer-card fit-reveal" style="--fit-trainer-col:<?php echo esc_attr($t['color']); ?>;">
        <div class="fit-trainer-portrait">
          <svg width="120" height="165" viewBox="0 0 120 165" xmlns="http://www.w3.org/2000/svg" aria-label="<?php echo esc_attr($t['name']); ?>">
            <!-- Tank top body -->
            <rect x="30" y="88" width="60" height="77" rx="5"
              fill="<?php echo esc_attr($bc); ?>" opacity=".9"/>
            <!-- Shoulders (wide) -->
            <ellipse cx="25" cy="92" rx="18" ry="12" fill="<?php echo esc_attr($bc); ?>" opacity=".85"/>
            <ellipse cx="95" cy="92" rx="18" ry="12" fill="<?php echo esc_attr($bc); ?>" opacity=".85"/>
            <!-- Arms (muscular) -->
            <rect x="10" y="88" width="18" height="58" rx="9"
              fill="<?php echo esc_attr($bc); ?>" opacity=".8"/>
            <rect x="92" y="88" width="18" height="58" rx="9"
              fill="<?php echo esc_attr($bc); ?>" opacity=".8"/>
            <!-- Forearms -->
            <rect x="12" y="130" width="14" height="22" rx="6" fill="#c8956a"/>
            <rect x="94" y="130" width="14" height="22" rx="6" fill="#c8956a"/>
            <!-- Hands -->
            <ellipse cx="19" cy="154" rx="8" ry="6" fill="#c8956a"/>
            <ellipse cx="101" cy="154" rx="8" ry="6" fill="#c8956a"/>
            <!-- Chest detail -->
            <rect x="38" y="96" width="20" height="2" rx="1"
              fill="rgba(255,255,255,.15)"/>
            <rect x="62" y="96" width="20" height="2" rx="1"
              fill="rgba(255,255,255,.15)"/>
            <!-- Neck -->
            <rect x="50" y="80" width="20" height="16" rx="6" fill="#c8956a"/>
            <!-- Head -->
            <ellipse cx="60" cy="60" rx="26" ry="26" fill="#c8956a"/>
            <!-- Hair -->
            <ellipse cx="60" cy="38" rx="26" ry="10"
              fill="<?php echo ($i%3===0)?'#1a0a06':($i%3===1?'#3a2010':'#0a0a1a'); ?>"/>
            <!-- Eyes -->
            <ellipse cx="51" cy="58" rx="3.5" ry="3.5" fill="#2a1a10"/>
            <ellipse cx="69" cy="58" rx="3.5" ry="3.5" fill="#2a1a10"/>
            <!-- Smile -->
            <path d="M49 68 Q60 76 71 68" fill="none" stroke="#7a4a28" stroke-width="2" stroke-linecap="round"/>
            <?php if($i % 2 === 0): ?>
            <!-- Headband -->
            <rect x="36" y="46" width="48" height="8" rx="4"
              fill="<?php echo esc_attr($bc); ?>" opacity=".85"/>
            <?php endif; ?>
          </svg>
        </div>
        <div class="fit-trainer-body">
          <div class="fit-trainer-name"><?php echo esc_html($t['name']); ?></div>
          <div class="fit-trainer-spec"><?php echo esc_html($t['specialty']); ?></div>
          <div class="fit-trainer-cert"><?php echo esc_html($t['cert']); ?></div>
          <div class="fit-trainer-years"><?php printf(esc_html__('%d years coaching','themeflex'),$t['years']); ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ================================================================
     STATS
================================================================ -->
<section class="fit-stats" aria-label="<?php esc_attr_e('Fitness studio stats','themeflex'); ?>">
  <div class="fit-container">
    <div class="fit-stats__grid">
      <?php
      $stats=[
        ['val'=>2800,'suf'=>'+','lbl'=>__('Active Members','themeflex')],
        ['val'=>60,  'suf'=>'+','lbl'=>__('Classes per Week','themeflex')],
        ['val'=>12,  'suf'=>'yrs','lbl'=>__('Operating Since','themeflex')],
        ['val'=>97,  'suf'=>'%','lbl'=>__('Renewal Rate','themeflex')],
      ];
      foreach($stats as $s): ?>
      <div class="fit-reveal">
        <span class="fit-stat-num" data-target="<?php echo $s['val']; ?>" data-suffix="<?php echo esc_attr($s['suf']); ?>">0</span>
        <span class="fit-stat-label"><?php echo esc_html($s['lbl']); ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ================================================================
     MEMBERSHIP PLANS
================================================================ -->
<section id="membership" class="fit-section">
  <div class="fit-container">
    <div class="fit-section-header fit-reveal">
      <p class="fit-section-header__label"><?php esc_html_e('No Contracts','themeflex'); ?></p>
      <h2 class="fit-section-header__h2"><?php esc_html_e('Simple <span class="accent">Pricing</span>','themeflex'); ?></h2>
      <p class="fit-section-header__sub"><?php esc_html_e('All plans include full access to the gym floor, every group class, and the locker rooms. Cancel or upgrade anytime.','themeflex'); ?></p>
    </div>
    <div class="fit-plans-grid">
      <?php foreach($plans as $pl): ?>
      <div class="fit-plan<?php echo $pl['highlight'] ? ' fit-plan--highlight' : ''; ?> fit-reveal">
        <?php if($pl['tag']): ?>
        <div class="fit-plan__badge"><?php echo esc_html($pl['tag']); ?></div>
        <?php endif; ?>
        <div class="fit-plan__head">
          <div class="fit-plan__name"><?php echo esc_html($pl['name']); ?></div>
          <div class="fit-plan__price">
            <sup>€</sup><?php echo esc_html($pl['price']); ?><sub>/<?php echo esc_html($pl['period']); ?></sub>
          </div>
        </div>
        <div class="fit-plan__body">
          <ul class="fit-plan__features">
            <?php foreach($pl['features'] as $f): ?>
            <li class="fit-plan__feature"><?php echo esc_html($f); ?></li>
            <?php endforeach; ?>
          </ul>
          <a href="#booking" class="fit-plan__cta"><?php echo esc_html($pl['cta']); ?></a>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ================================================================
     TESTIMONIALS
================================================================ -->
<section class="fit-section fit-section--alt">
  <div class="fit-container">
    <div class="fit-section-header fit-reveal">
      <p class="fit-section-header__label"><?php esc_html_e('Real Results','themeflex'); ?></p>
      <h2 class="fit-section-header__h2"><?php esc_html_e('Member <span class="accent">Stories</span>','themeflex'); ?></h2>
    </div>
    <div class="fit-testi-grid">
      <?php foreach($testimonials as $t): ?>
      <div class="fit-testi-card fit-reveal">
        <div class="fit-testi-result"><?php echo esc_html($t['result']); ?></div>
        <p class="fit-testi-text">&ldquo;<?php echo esc_html($t['q']); ?>&rdquo;</p>
        <div class="fit-testi-name"><?php echo esc_html($t['n']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ================================================================
     BOOKING FORM
================================================================ -->
<div id="booking" class="fit-form-section">
  <div class="fit-container">
    <div class="fit-form-inner fit-reveal">
      <h2 class="fit-form-title"><?php esc_html_e('Start','themeflex'); ?> <span><?php esc_html_e('Today','themeflex'); ?></span></h2>
      <p class="fit-form-sub"><?php esc_html_e('Book a free tour and trial class. No obligation. Just come and train with us.','themeflex'); ?></p>

      <form method="post" action="" class="fit-form-grid" novalidate>
        <?php wp_nonce_field('tf_fit_booking','tf_fit_nonce'); ?>

        <div class="fit-fg">
          <label class="fit-label" for="fit-name"><?php esc_html_e('Full Name','themeflex'); ?></label>
          <input class="fit-input" type="text" id="fit-name" name="fit_name" placeholder="<?php esc_attr_e('Alex Roth','themeflex'); ?>" required>
        </div>
        <div class="fit-fg">
          <label class="fit-label" for="fit-email"><?php esc_html_e('Email','themeflex'); ?></label>
          <input class="fit-input" type="email" id="fit-email" name="fit_email" placeholder="<?php esc_attr_e('alex@example.com','themeflex'); ?>" required>
        </div>
        <div class="fit-fg">
          <label class="fit-label" for="fit-phone"><?php esc_html_e('Phone','themeflex'); ?></label>
          <input class="fit-input" type="tel" id="fit-phone" name="fit_phone" placeholder="+49 89 …">
        </div>
        <div class="fit-fg">
          <label class="fit-label" for="fit-goal"><?php esc_html_e('Primary Goal','themeflex'); ?></label>
          <select class="fit-select" id="fit-goal" name="fit_goal">
            <option value=""><?php esc_html_e('Select your goal…','themeflex'); ?></option>
            <option value="weightloss"><?php esc_html_e('Weight Loss','themeflex'); ?></option>
            <option value="muscle"><?php esc_html_e('Build Muscle','themeflex'); ?></option>
            <option value="endurance"><?php esc_html_e('Improve Endurance','themeflex'); ?></option>
            <option value="strength"><?php esc_html_e('Get Stronger','themeflex'); ?></option>
            <option value="general"><?php esc_html_e('General Fitness','themeflex'); ?></option>
          </select>
        </div>
        <div class="fit-fg">
          <label class="fit-label" for="fit-class"><?php esc_html_e('Trial Class','themeflex'); ?></label>
          <select class="fit-select" id="fit-class" name="fit_class">
            <option value=""><?php esc_html_e('Choose a class…','themeflex'); ?></option>
            <?php foreach($classes as $cl): ?>
            <option value="<?php echo esc_attr($cl['name']); ?>"><?php echo esc_html($cl['name'].' ('.$cl['time'].')'); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="fit-fg">
          <label class="fit-label" for="fit-plan"><?php esc_html_e('Membership Interest','themeflex'); ?></label>
          <select class="fit-select" id="fit-plan" name="fit_plan">
            <option value="trial"><?php esc_html_e('Trial (7 days) — €29','themeflex'); ?></option>
            <option value="core"><?php esc_html_e('Core — €49/month','themeflex'); ?></option>
            <option value="elite"><?php esc_html_e('Elite — €89/month','themeflex'); ?></option>
          </select>
        </div>
        <div class="fit-fg fit-fg--full">
          <label class="fit-label" for="fit-notes"><?php esc_html_e('Tell us about your fitness background','themeflex'); ?></label>
          <textarea class="fit-textarea" id="fit-notes" name="fit_notes" rows="3" placeholder="<?php esc_attr_e('Any injuries, experience level, questions for the team…','themeflex'); ?>"></textarea>
        </div>
        <div class="fit-fg fit-fg--full">
          <label class="fit-consent">
            <input type="checkbox" name="fit_consent" required>
            <?php esc_html_e('I agree to my data being used to process my booking request. I can withdraw consent at any time.','themeflex'); ?>
          </label>
        </div>
        <div class="fit-fg fit-fg--full">
          <button type="submit" class="fit-submit"><?php esc_html_e('BOOK FREE TRIAL','themeflex'); ?></button>
        </div>
      </form>
    </div>
  </div>
</div>

</div><!-- /fit-page -->

<!-- ================================================================
     JAVASCRIPT
================================================================ -->
<script>
(function(){
  'use strict';

  /* ── Scroll reveal ── */
  const rev = document.querySelectorAll('.fit-reveal');
  const obs = new IntersectionObserver(es=>{
    es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');obs.unobserve(e.target);}});
  },{threshold:.1,rootMargin:'0px 0px -40px 0px'});
  rev.forEach(el=>obs.observe(el));

  /* ── Animated counters ── */
  const easeOut = t=>1-Math.pow(1-t,3);
  const counters = document.querySelectorAll('.fit-stat-num[data-target]');
  const cObs = new IntersectionObserver(es=>{
    es.forEach(e=>{
      if(!e.isIntersecting) return;
      const el=e.target, end=+el.dataset.target, suf=el.dataset.suffix||'';
      const dur=1800,t0=performance.now();
      (function tick(now){
        const p=Math.min((now-t0)/dur,1);
        el.textContent=Math.round(easeOut(p)*end)+suf;
        if(p<1)requestAnimationFrame(tick);
        else el.textContent=end+suf;
      })(t0);
      cObs.unobserve(el);
    });
  },{threshold:.5});
  counters.forEach(el=>cObs.observe(el));

  /* ── Class schedule filter ── */
  const btns = document.querySelectorAll('.fit-filter-btn');
  const rows = document.querySelectorAll('.fit-schedule tbody tr');
  btns.forEach(btn=>{
    btn.addEventListener('click',()=>{
      btns.forEach(b=>{b.classList.remove('active');b.setAttribute('aria-pressed','false');});
      btn.classList.add('active');btn.setAttribute('aria-pressed','true');
      const f=btn.dataset.filter;
      rows.forEach(r=>r.classList.toggle('hidden',f!=='all'&&r.dataset.cat!==f));
    });
  });

  /* ── Book button feedback ── */
  document.querySelectorAll('.fit-book-btn:not([disabled])').forEach(btn=>{
    btn.addEventListener('click',()=>{
      const orig=btn.textContent;
      btn.textContent='✓ Booked!';
      btn.style.background='var(--fit-electric)';
      btn.style.color='var(--fit-midnight)';
      setTimeout(()=>{btn.textContent=orig;btn.style.background='';btn.style.color='';},2200);
    });
  });

  /* ── Pricing CTA scroll ── */
  document.querySelectorAll('.fit-plan__cta').forEach(a=>{
    a.addEventListener('click',e=>{
      e.preventDefault();
      const target=document.querySelector('#booking');
      if(target)target.scrollIntoView({behavior:'smooth'});
    });
  });

})();
</script>

<?php get_footer(); ?>
