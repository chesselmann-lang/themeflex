<?php
/**
 * Template Name: Florist – Wedding & Event Flower Studio
 *
 * Premium luxury florist page template for ThemeFlex.
 * Botanica — Fine Flowers & Event Floristry, Notting Hill London Est. 1998
 *
 * @package ThemeFlex
 */

defined('ABSPATH') || exit;

srand(crc32(get_the_permalink()));

// PHP-generated flower stems in hero
$fl_stems = [];
for ($i = 0; $i < 24; $i++) {
    $hue    = [355, 330, 10, 28, 195, 280, 45, 0][$i % 8];
    $fl_stems[] = [
        'left'   => 8 + ($i * 3.6) + rand(-2, 2),
        'height' => 180 + rand(0, 120),
        'hue'    => $hue,
        'sat'    => 55 + rand(0, 30),
        'lit'    => 50 + rand(-10, 15),
        'w'      => 28 + rand(0, 22),
        'petals' => rand(5, 8),
        'type'   => rand(0, 3), // 0=round, 1=spray, 2=tulip, 3=daisy
    ];
}

// PHP-generated falling petals
$fl_petals = [];
for ($i = 0; $i < 22; $i++) {
    $fl_petals[] = [
        'left'  => rand(2, 96),
        'size'  => rand(6, 16),
        'hue'   => [355,330,10,28,280,45][$i % 6],
        'delay' => rand(0, 6000),
        'dur'   => 5000 + rand(0, 5000),
        'rot'   => rand(-45, 45),
    ];
}

// Seasonal collections
$fl_collections = [
  ['name'=>'The Chelsea Garden',   'season'=>'Spring',  'desc'=>'Tulips, ranunculus and sweet peas in the palest rose, lilac and ivory. Gathered as if fresh from an English country garden.', 'palette'=>[355,330,280]],
  ['name'=>'The Midsummer Bower',  'season'=>'Summer',  'desc'=>'Garden roses, peonies and lavender in warm blush and dusty mauve. A celebration of the English summer at its most abundant.', 'palette'=>[340,310,260]],
  ['name'=>'The Harvest Wreath',   'season'=>'Autumn',  'desc'=>'Dahlias, chrysanthemums and berries in amber, terracotta and bronze. Richly textured arrangements that capture autumn\'s palette.', 'palette'=>[28,15,40]],
  ['name'=>'The Frost Collection', 'season'=>'Winter',  'desc'=>'Amaryllis, hellebores and eucalyptus in ivory, blush and forest green. Elegant arrangements for the festive and winter season.',  'palette'=>[355,150,0]],
];

// Services
$fl_services = [
  ['icon'=>'❀', 'name'=>'Wedding Floristry',       'desc'=>'From intimate elopements to grand celebrations — bridal bouquets, ceremony arches, reception centrepieces and on-the-day dressing.', 'from'=>'From £2,400'],
  ['icon'=>'✿', 'name'=>'Event & Corporate',        'desc'=>'Venue dressing, table centrepieces, entrance floral installations and logo florals for corporate events, galas and private parties.', 'from'=>'From £800'],
  ['icon'=>'❁', 'name'=>'Bespoke Arrangements',    'desc'=>'Entirely bespoke hand-tied bouquets and arrangements for any occasion — sourced to your palette, delivered to your door.', 'from'=>'From £180'],
  ['icon'=>'✾', 'name'=>'Seasonal Subscription',   'desc'=>'Weekly or fortnightly seasonal arrangements delivered to your home or office. Curated to the season, always extraordinary.', 'from'=>'From £95/month'],
  ['icon'=>'❃', 'name'=>'Sympathy & Tribute',       'desc'=>'Thoughtfully composed tributes and funeral floristry. We work sensitively with families to create arrangements that truly honour a life.', 'from'=>'From £120'],
  ['icon'=>'❋', 'name'=>'Floral Workshops',         'desc'=>'Intimate hand-tied bouquet workshops for groups of 6–12. Guided by our senior florists — a wonderful gift or team experience.', 'from'=>'From £95/person'],
];

// Vase/vessel shapes for display
$fl_vessels = [
  ['type'=>'tall-cylinder', 'w'=>36, 'h'=>100, 'hue'=>200, 'sat'=>15, 'lit'=>75],
  ['type'=>'wide-urn',      'w'=>70, 'h'=>80,  'hue'=>30,  'sat'=>25, 'lit'=>72],
  ['type'=>'bud-vase',      'w'=>18, 'h'=>110, 'hue'=>220, 'sat'=>10, 'lit'=>80],
  ['type'=>'low-bowl',      'w'=>90, 'h'=>40,  'hue'=>180, 'sat'=>12, 'lit'=>70],
  ['type'=>'terracotta',    'w'=>52, 'h'=>60,  'hue'=>15,  'sat'=>45, 'lit'=>62],
];

?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Italiana&family=Raleway:ital,wght@0,300;0,400;0,500;1,300;1,400&display=swap" rel="stylesheet">
<style>
/* ============================================================
   BOTANICA — FINE FLOWERS CSS DESIGN SYSTEM
   Namespace: --fl-*  |  No external image dependencies
   Palette: warm cream · sage green · dusty rose · antique gold
   ============================================================ */

:root {
  --fl-cream:     #FAF6F0;
  --fl-ivory:     #F5EEE4;
  --fl-parchment: #EDE3D4;
  --fl-sage:      #7A9070;
  --fl-sage-deep: #5A7050;
  --fl-sage-pale: #D8E8D0;
  --fl-rose:      #C87880;
  --fl-rose-pale: #F0D8DC;
  --fl-blush:     #E8C8CC;
  --fl-gold:      #C09050;
  --fl-gold-pale: #E8D4A8;
  --fl-charcoal:  #2A2420;
  --fl-stone:     #6A6058;
  --fl-mist:      #A8A098;
  --fl-green:     #4A6840;

  --fl-serif:  'Italiana', Georgia, serif;
  --fl-sans:   'Raleway', system-ui, sans-serif;

  --fl-ease:   cubic-bezier(.22,.68,0,1.2);
  --fl-dur:    .45s;
  --fl-r:      2px;
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; }

body.fl-body {
  font-family: var(--fl-sans);
  background: var(--fl-cream);
  color: var(--fl-charcoal);
  overflow-x: hidden;
  -webkit-font-smoothing: antialiased;
}

/* ── NAV ──────────────────────────────────────────────────── */
.fl-nav {
  position: fixed; top: 0; left: 0; right: 0; z-index: 200;
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 56px; height: 72px;
  background: rgba(250,246,240,.95);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid rgba(192,144,80,.12);
}
.fl-nav__logo {
  display: flex; flex-direction: column; gap: 1px;
}
.fl-nav__name {
  font-family: var(--fl-serif); font-size: 1.5rem;
  color: var(--fl-charcoal); letter-spacing: .06em;
}
.fl-nav__tagline {
  font-size: .58rem; letter-spacing: .32em;
  color: var(--fl-gold); text-transform: uppercase; font-weight: 500;
}
.fl-nav__links { display: flex; gap: 32px; list-style: none; }
.fl-nav__links a {
  font-size: .78rem; font-weight: 400; letter-spacing: .1em;
  color: var(--fl-stone); text-decoration: none;
  text-transform: uppercase; transition: color var(--fl-dur);
}
.fl-nav__links a:hover { color: var(--fl-rose); }
.fl-nav__cta {
  padding: 10px 26px;
  border: 1px solid var(--fl-rose);
  color: var(--fl-rose);
  font-family: var(--fl-sans); font-size: .76rem;
  font-weight: 500; letter-spacing: .1em;
  text-transform: uppercase; text-decoration: none;
  transition: all var(--fl-dur);
}
.fl-nav__cta:hover { background: var(--fl-rose); color: var(--fl-cream); }

/* ── HERO ─────────────────────────────────────────────────── */
.fl-hero {
  position: relative; width: 100%; height: 100vh; min-height: 700px;
  overflow: hidden; background: var(--fl-ivory);
  display: flex; align-items: flex-end;
}

/* Studio ceiling and walls */
.fl-studio-ceiling {
  position: absolute; top: 0; left: 0; right: 0; height: 20%;
  background: linear-gradient(180deg, #F2EBE0 0%, #EDE3D4 100%);
  border-bottom: 1px solid rgba(192,144,80,.1);
}
.fl-studio-ceiling::before {
  content: '';
  position: absolute; inset: 0;
  background: repeating-linear-gradient(
    90deg,
    transparent 0, transparent 79px,
    rgba(0,0,0,.02) 79px, rgba(0,0,0,.02) 80px
  );
}
.fl-studio-wall {
  position: absolute; top: 0; bottom: 22%; left: 0; right: 0;
  background: linear-gradient(180deg, #EDE3D4 0%, #E8DDD0 60%, #F0E8E0 100%);
}
.fl-studio-wall::before {
  content: '';
  position: absolute; inset: 0;
  background: repeating-linear-gradient(
    180deg,
    transparent 0, transparent 79px,
    rgba(192,144,80,.04) 79px, rgba(192,144,80,.04) 80px
  );
}
/* Dado rail */
.fl-dado-rail {
  position: absolute; bottom: 35%; left: 0; right: 0;
  height: 8px;
  background: linear-gradient(180deg, #D8C8B0 0%, #C8B8A0 100%);
  border-top: 1px solid rgba(255,255,255,.4);
}
/* Lower wall */
.fl-lower-wall {
  position: absolute; bottom: 22%; left: 0; right: 0; height: 13%;
  background: linear-gradient(180deg, #E8E0D4 0%, #EAE2D8 100%);
}
/* Studio floor */
.fl-studio-floor {
  position: absolute; bottom: 0; left: 0; right: 0; height: 22%;
  background: linear-gradient(180deg, #D8CFC4 0%, #CEC4B8 100%);
  border-top: 1px solid rgba(192,144,80,.12);
}
.fl-studio-floor::before {
  content: '';
  position: absolute; inset: 0;
  background:
    repeating-linear-gradient(90deg, transparent 0, transparent 79px, rgba(0,0,0,.04) 79px, rgba(0,0,0,.04) 80px),
    repeating-linear-gradient(180deg, transparent 0, transparent 39px, rgba(0,0,0,.03) 39px, rgba(0,0,0,.03) 40px);
}

/* ── ARRANGING TABLE ──────────────────────────────────────── */
.fl-table {
  position: absolute;
  bottom: 22%; left: 0; right: 0;
  height: 18px;
  background: linear-gradient(180deg, #C8B898 0%, #B8A888 100%);
  border-top: 3px solid rgba(255,255,255,.3);
  z-index: 3;
}
.fl-table::before { /* table underside */
  content: '';
  position: absolute; top: 100%; left: 0; right: 0; height: 28px;
  background: linear-gradient(180deg, #A89880 0%, #988870 100%);
}
.fl-table::after { /* table top highlight */
  content: '';
  position: absolute; top: 0; left: 0; right: 0; height: 3px;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,.4), transparent);
}

/* ── FLOWER STEMS ─────────────────────────────────────────── */
.fl-stem-wrap {
  position: absolute; bottom: calc(22% + 18px); z-index: 4;
  display: flex; flex-direction: column; align-items: center;
  transform-origin: bottom center;
}
.fl-stem {
  width: 2px; background: var(--fl-sage);
  border-radius: 1px;
}

/* Flower heads — round type */
.fl-head--round {
  border-radius: 50%;
  position: relative;
}
.fl-head--round::before { /* highlight */
  content: '';
  position: absolute; top: 15%; left: 20%;
  width: 28%; height: 28%; border-radius: 50%;
  background: rgba(255,255,255,.35);
}
.fl-head--round::after { /* centre dot */
  content: '';
  position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%);
  width: 25%; height: 25%; border-radius: 50%;
  background: rgba(0,0,0,.15);
}

/* Flower heads — spray type */
.fl-head--spray {
  position: relative; border-radius: 50%;
}
.fl-head--spray::before {
  content: '';
  position: absolute; inset: -5px;
  border-radius: 50%;
  background: inherit;
  opacity: .35;
  filter: blur(3px);
}

/* Flower heads — tulip type */
.fl-head--tulip {
  border-radius: 40% 40% 20% 20% / 50% 50% 30% 30%;
  position: relative;
}
.fl-head--tulip::before {
  content: '';
  position: absolute; top: 10%; left: 15%; right: 15%; bottom: 5%;
  background: inherit; opacity: .4;
  border-radius: 35% 35% 15% 15% / 45% 45% 25% 25%;
  filter: brightness(1.2);
}

/* Flower heads — daisy type */
.fl-head--daisy {
  position: relative; border-radius: 50%;
  background: rgba(255,240,100,.85) !important;
}
.fl-head--daisy::before {
  content: '';
  position: absolute; inset: -6px;
  background: repeating-conic-gradient(
    rgba(255,255,255,.7) 0deg 20deg,
    transparent 20deg 36deg
  );
  border-radius: 50%;
  opacity: .8;
}
.fl-head--daisy::after {
  content: '';
  position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%);
  width: 35%; height: 35%; border-radius: 50%;
  background: #C07830;
}

/* ── PENDANT LIGHTS ───────────────────────────────────────── */
.fl-pendant {
  position: absolute; top: 19%;
  display: flex; flex-direction: column; align-items: center;
}
.fl-pendant__wire { width: 1px; background: #8A8078; }
.fl-pendant__shade {
  width: 0; height: 0;
  border-left: solid transparent;
  border-right: solid transparent;
  border-top: solid;
  position: relative;
}
.fl-pendant__shade::before {
  content: '';
  position: absolute; top: -14px; left: 50%; transform: translateX(-50%);
  width: 10px; height: 12px;
  background: linear-gradient(180deg, #C8B898 0%, #A89878 100%);
  border-radius: 2px 2px 0 0;
}
.fl-pendant__glow {
  position: absolute;
  border-left: solid transparent;
  border-right: solid transparent;
  border-top: solid;
  opacity: .08;
  filter: blur(10px);
  pointer-events: none;
}

/* ── FALLING PETALS ───────────────────────────────────────── */
.fl-petal {
  position: absolute; border-radius: 50% 0; pointer-events: none;
}

/* ── SHOP WINDOW (right) ──────────────────────────────────── */
.fl-window {
  position: absolute;
  top: 22%; right: 6%;
  width: 120px; height: 180px;
  z-index: 2;
}
.fl-window__frame {
  position: absolute; inset: 0;
  border: 5px solid #C8B898;
  background: linear-gradient(135deg, #E8F8F0 0%, #D0EAE0 100%);
  border-radius: 4px 4px 0 0;
}
.fl-window__frame::before { /* window pane cross */
  content: '';
  position: absolute; top: 0; bottom: 0; left: 50%; width: 3px;
  background: #C8B898; margin-left: -1.5px;
}
.fl-window__frame::after {
  content: '';
  position: absolute; left: 0; right: 0; top: 50%; height: 3px;
  background: #C8B898; margin-top: -1.5px;
}
.fl-window__sill {
  position: absolute; bottom: -8px; left: -8px; right: -8px;
  height: 10px;
  background: linear-gradient(180deg, #D8C8A8 0%, #C8B898 100%);
  border-radius: 2px;
}
/* Outside foliage through window */
.fl-window__outside {
  position: absolute; inset: 5px;
  background: radial-gradient(ellipse 60% 80% at 50% 60%, #5A8050 0%, #3A6030 60%, #2A4822 100%);
  border-radius: 2px;
  overflow: hidden;
}
.fl-window__outside::before {
  content: '';
  position: absolute; inset: 0;
  background: repeating-linear-gradient(
    30deg,
    transparent 0, transparent 8px,
    rgba(255,255,255,.04) 8px, rgba(255,255,255,.04) 9px
  );
}

/* ── VESSELS ──────────────────────────────────────────────── */
.fl-vessel-wrap {
  position: absolute; bottom: calc(22% + 18px); z-index: 3;
  display: flex; align-items: flex-end;
}
.fl-vessel {
  position: relative;
}
.fl-vessel--tall-cylinder {
  border-radius: 4px 4px 2px 2px;
}
.fl-vessel--wide-urn {
  border-radius: 50% 50% 4px 4px / 20% 20% 4px 4px;
}
.fl-vessel--bud-vase {
  border-radius: 8px 8px 2px 2px;
  clip-path: polygon(25% 0%, 75% 0%, 90% 100%, 10% 100%);
}
.fl-vessel--low-bowl {
  border-radius: 50% 50% 4px 4px / 30% 30% 4px 4px;
}
.fl-vessel--terracotta {
  border-radius: 4px 4px 2px 2px;
}
.fl-vessel::before { /* glaze highlight */
  content: '';
  position: absolute; top: 8%; left: 12%;
  width: 16%; height: 36%; border-radius: 50%;
  background: rgba(255,255,255,.25);
  filter: blur(2px);
}

/* ── FLORIST FIGURE ───────────────────────────────────────── */
.fl-florist {
  position: absolute;
  bottom: calc(22% + 18px);
  right: 22%;
  display: flex; flex-direction: column; align-items: center;
  z-index: 5;
}
.fl-florist__head {
  width: 42px; height: 42px; border-radius: 50%;
  background: radial-gradient(circle at 38% 35%, #D4B090 0%, #A88060 50%, #7A5840 100%);
  position: relative; margin-bottom: -2px;
}
.fl-florist__head::before { /* hair — side bun */
  content: '';
  position: absolute; top: -4px; left: -2px; right: -6px; height: 26px;
  background: #5A3018;
  border-radius: 22px 22px 0 0;
  clip-path: polygon(0 80%, 0 18%, 60% 0%, 100% 22%, 100% 85%, 80% 100%, 0 100%);
}
.fl-florist__head::after { /* bun knot */
  content: '';
  position: absolute; top: -4px; right: -8px;
  width: 14px; height: 14px; border-radius: 50%;
  background: #5A3018;
}
.fl-florist__neck { width: 16px; height: 14px; background: #A88060; }
.fl-florist__body {
  width: 80px; height: 90px;
  background: linear-gradient(180deg, var(--fl-sage) 0%, var(--fl-sage-deep) 100%);
  border-radius: 3px 3px 0 0; position: relative;
}
.fl-florist__body::before { /* apron */
  content: '';
  position: absolute; top: 0; left: 10px; right: 10px; bottom: 0;
  background: linear-gradient(180deg, #E8DDD0 0%, #D8CDBF 100%);
  clip-path: polygon(20% 0%, 80% 0%, 90% 100%, 10% 100%);
}
.fl-florist__arm-r {
  position: absolute; bottom: 20px; right: -26px;
  width: 26px; height: 10px;
  background: var(--fl-sage);
  border-radius: 5px; transform: rotate(-30deg);
}
.fl-florist__arm-r::after { /* bouquet in hand */
  content: '';
  position: absolute; right: -10px; top: -4px;
  width: 14px; height: 22px;
  background: radial-gradient(circle at 50% 30%, #E8A0A8 0%, #C87880 60%, #A05870 100%);
  border-radius: 50% 50% 20% 20%;
  border: 1px solid rgba(192,144,80,.2);
}
.fl-florist__arm-l {
  position: absolute; bottom: 20px; left: -22px;
  width: 22px; height: 10px;
  background: var(--fl-sage);
  border-radius: 5px; transform: rotate(20deg);
}

/* ── HERO TEXT ────────────────────────────────────────────── */
.fl-hero__content {
  position: relative; z-index: 10;
  padding: 0 7% 80px; max-width: 580px;
}
.fl-hero__eyebrow {
  display: flex; align-items: center; gap: 14px; margin-bottom: 20px;
}
.fl-hero__eyebrow-line { width: 32px; height: 1px; background: var(--fl-rose); }
.fl-hero__eyebrow-text {
  font-size: .64rem; letter-spacing: .32em;
  color: var(--fl-rose); text-transform: uppercase; font-weight: 500;
}
.fl-hero__title {
  font-family: var(--fl-serif);
  font-size: clamp(3rem, 6vw, 5.5rem);
  line-height: 1; color: var(--fl-charcoal); margin-bottom: 20px;
  font-weight: 400;
}
.fl-hero__tagline {
  font-size: 1rem; font-weight: 300; line-height: 1.75;
  color: var(--fl-stone); margin-bottom: 36px; max-width: 420px;
}
.fl-hero__actions { display: flex; gap: 14px; flex-wrap: wrap; }
.fl-btn {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 12px 32px;
  font-family: var(--fl-sans); font-size: .78rem;
  font-weight: 500; letter-spacing: .1em;
  text-transform: uppercase; text-decoration: none;
  cursor: pointer; border: none; border-radius: var(--fl-r);
  transition: all var(--fl-dur);
}
.fl-btn--rose { background: var(--fl-rose); color: var(--fl-cream); }
.fl-btn--rose:hover { background: #B86870; }
.fl-btn--outline {
  background: transparent; border: 1px solid var(--fl-rose);
  color: var(--fl-rose);
}
.fl-btn--outline:hover { background: var(--fl-rose); color: var(--fl-cream); }
.fl-btn--sage { background: var(--fl-sage); color: var(--fl-cream); }
.fl-btn--sage:hover { background: var(--fl-sage-deep); }

/* Order card */
.fl-order-card {
  position: absolute; bottom: 48px; right: 5%; z-index: 10;
  width: 210px; padding: 20px 22px;
  background: rgba(250,246,240,.97);
  border: 1px solid rgba(192,144,80,.2);
  border-radius: var(--fl-r);
  box-shadow: 0 8px 32px rgba(42,36,32,.1);
}
.fl-order-card__title {
  font-size: .6rem; letter-spacing: .24em; font-weight: 600;
  color: var(--fl-rose); text-transform: uppercase; margin-bottom: 12px;
}
.fl-order-card__row {
  display: flex; justify-content: space-between; margin-bottom: 6px;
  font-size: .78rem;
}
.fl-order-card__key { color: var(--fl-stone); font-weight: 300; }
.fl-order-card__val { color: var(--fl-charcoal); font-weight: 500; }
.fl-order-card__sep { height: 1px; background: rgba(192,144,80,.12); margin: 12px 0; }
.fl-order-card__avail {
  display: flex; align-items: center; gap: 8px;
  font-size: .72rem; color: var(--fl-stone);
}
.fl-order-card__dot { width: 6px; height: 6px; border-radius: 50%; background: #4CAF50; }

/* ── STATS ────────────────────────────────────────────────── */
.fl-stats {
  background: var(--fl-charcoal);
  display: grid; grid-template-columns: repeat(4,1fr);
}
.fl-stat {
  padding: 32px 20px; text-align: center;
  border-right: 1px solid rgba(192,144,80,.1);
}
.fl-stat:last-child { border-right: none; }
.fl-stat__val {
  font-family: var(--fl-serif); font-size: 2.6rem;
  color: var(--fl-gold-pale); line-height: 1; margin-bottom: 6px;
}
.fl-stat__lbl {
  font-size: .64rem; letter-spacing: .2em; font-weight: 500;
  color: var(--fl-mist); text-transform: uppercase;
}

/* ── SECTION UTILS ────────────────────────────────────────── */
.fl-section { padding: 96px 7%; }
.fl-section--cream  { background: var(--fl-cream); }
.fl-section--ivory  { background: var(--fl-ivory); }
.fl-section--parch  { background: var(--fl-parchment); }
.fl-section--sage   { background: var(--fl-sage-deep); color: var(--fl-cream); }
.fl-section--dark   { background: var(--fl-charcoal); color: var(--fl-cream); }

.fl-section-label { display: flex; align-items: center; gap: 14px; margin-bottom: 16px; }
.fl-section-label__icon { font-size: 1rem; color: var(--fl-rose); }
.fl-section-label__text {
  font-size: .64rem; letter-spacing: .28em; font-weight: 500;
  color: var(--fl-rose); text-transform: uppercase;
}
.fl-section--sage .fl-section-label__text,
.fl-section--dark .fl-section-label__text { color: var(--fl-gold-pale); }
.fl-section--sage .fl-section-label__icon,
.fl-section--dark .fl-section-label__icon { color: var(--fl-gold-pale); }

.fl-h2 {
  font-family: var(--fl-serif);
  font-size: clamp(2.2rem, 4vw, 3.8rem);
  font-weight: 400; line-height: 1.15; margin-bottom: 16px;
}
.fl-lead {
  font-size: 1rem; font-weight: 300; line-height: 1.75;
  color: var(--fl-stone); max-width: 540px;
}
.fl-section--sage .fl-lead,
.fl-section--dark .fl-lead { color: rgba(212,200,188,.8); }

/* ── SEASONAL COLLECTIONS ─────────────────────────────────── */
.fl-collections__grid {
  display: grid; grid-template-columns: repeat(4,1fr);
  gap: 2px; margin-top: 52px;
}
.fl-collection-card {
  position: relative; overflow: hidden; cursor: pointer;
}
.fl-collection-card__visual {
  height: 280px; position: relative; overflow: hidden;
  display: flex; align-items: flex-end; justify-content: center;
  padding-bottom: 20px;
}
.fl-collection-card__visual::before { /* background wash */
  content: '';
  position: absolute; inset: 0;
}
/* Hover colour */
.fl-collection-card:hover .fl-collection-card__visual::after {
  content: '';
  position: absolute; inset: 0;
  background: rgba(0,0,0,.15);
}

/* CSS flower clusters per season */
.fl-season-flowers {
  position: absolute; inset: 0;
  display: flex; align-items: flex-end; justify-content: center;
  padding-bottom: 8px;
}
.fl-season-stem {
  position: absolute; bottom: 8px;
  width: 2px; border-radius: 1px;
  background: var(--fl-sage);
}
.fl-season-head {
  position: absolute; border-radius: 50%;
}

.fl-collection-card__info {
  padding: 22px 20px 26px;
  background: var(--fl-cream);
}
.fl-collection-card__season {
  font-size: .6rem; letter-spacing: .24em; font-weight: 600;
  color: var(--fl-rose); text-transform: uppercase; margin-bottom: 6px;
}
.fl-collection-card__name {
  font-family: var(--fl-serif); font-size: 1.3rem;
  color: var(--fl-charcoal); margin-bottom: 8px;
}
.fl-collection-card__desc {
  font-size: .82rem; line-height: 1.65; color: var(--fl-stone);
}

/* Palette dots */
.fl-palette {
  display: flex; gap: 5px; margin-top: 12px;
}
.fl-palette-dot {
  width: 10px; height: 10px; border-radius: 50%;
  border: 1px solid rgba(0,0,0,.08);
}

/* ── SERVICES GRID ────────────────────────────────────────── */
.fl-services__grid {
  display: grid; grid-template-columns: repeat(3,1fr);
  gap: 24px; margin-top: 52px;
}
.fl-service-card {
  padding: 36px 30px;
  background: var(--fl-cream);
  border: 1px solid rgba(192,144,80,.12);
  transition: border-color .35s, box-shadow .35s;
}
.fl-service-card:hover {
  border-color: rgba(200,120,128,.3);
  box-shadow: 0 4px 24px rgba(200,120,128,.08);
}
.fl-service-card__icon {
  font-size: 1.8rem; color: var(--fl-rose);
  margin-bottom: 18px; display: block;
}
.fl-service-card__name {
  font-family: var(--fl-serif); font-size: 1.3rem;
  color: var(--fl-charcoal); margin-bottom: 10px;
}
.fl-service-card__desc {
  font-size: .88rem; line-height: 1.7; color: var(--fl-stone); margin-bottom: 16px;
}
.fl-service-card__from {
  font-size: .78rem; font-weight: 500; color: var(--fl-sage-deep);
  letter-spacing: .06em;
}

/* ── ABOUT SPLIT ──────────────────────────────────────────── */
.fl-about { display: grid; grid-template-columns: 1fr 1fr; min-height: 560px; }
.fl-about__visual {
  background: var(--fl-parchment); position: relative; overflow: hidden; min-height: 500px;
}
.fl-about__text {
  padding: 80px 60px; background: var(--fl-ivory);
  display: flex; flex-direction: column; justify-content: center;
}

/* CSS studio vessel arrangement in about */
.fl-vessel-scene {
  position: absolute; inset: 0;
  display: flex; align-items: flex-end; justify-content: center;
  padding-bottom: 40px; gap: 12px;
}
.fl-vessel-flower-group {
  display: flex; flex-direction: column; align-items: center;
}
.fl-vessel-blooms {
  position: relative; display: flex; align-items: flex-end;
  margin-bottom: -4px;
}
.fl-vstem {
  width: 2px; height: 80px;
  background: var(--fl-sage); border-radius: 1px;
  position: relative;
}
.fl-vstem::before {
  content: '';
  position: absolute; top: 0; left: 50%; transform: translateX(-50%);
  border-radius: 50%;
}
.fl-vvessel {
  width: 50px; height: 60px;
  border-radius: 4px 4px 2px 2px;
  position: relative;
}
.fl-vvessel::before {
  content: '';
  position: absolute; top: 8px; left: 10px;
  width: 14px; height: 28px;
  border-radius: 50%;
  background: rgba(255,255,255,.2);
}

.fl-about__values {
  list-style: none; margin-top: 24px;
  display: flex; flex-direction: column; gap: 12px;
}
.fl-about__value {
  display: flex; gap: 12px; align-items: flex-start;
}
.fl-about__value-icon { font-size: 1rem; color: var(--fl-rose); flex-shrink: 0; margin-top: 2px; }
.fl-about__value-text { font-size: .9rem; line-height: 1.65; color: var(--fl-stone); }

/* ── WEDDING FEATURE ──────────────────────────────────────── */
.fl-wedding {
  display: grid; grid-template-columns: 1fr 1fr; min-height: 520px;
}
.fl-wedding__text {
  padding: 80px 60px; background: var(--fl-charcoal);
  display: flex; flex-direction: column; justify-content: center;
  color: var(--fl-cream);
}
.fl-wedding__visual {
  background: var(--fl-sage-deep); position: relative; overflow: hidden;
}

/* CSS ceremony arch */
.fl-arch-scene {
  position: absolute; inset: 0;
  display: flex; align-items: center; justify-content: center;
}
.fl-arch {
  position: relative; width: 160px; height: 200px;
}
.fl-arch__left,
.fl-arch__right {
  position: absolute; bottom: 0;
  width: 16px; height: 160px;
  background: linear-gradient(180deg, #C8B898 0%, #A89870 100%);
  border-radius: 8px 8px 2px 2px;
}
.fl-arch__left  { left: 0; }
.fl-arch__right { right: 0; }
.fl-arch__top {
  position: absolute; top: 0; left: 0; right: 0; height: 80px;
  border-radius: 80px 80px 0 0;
  border: 16px solid transparent;
  border-top: 16px solid;
  border-color: #C8B898;
  box-sizing: border-box;
}
/* Florals on arch */
.fl-arch-blooms {
  position: absolute; top: -12px; left: -14px; right: -14px;
  height: 50%;
  overflow: visible;
}
.fl-arch-bloom {
  position: absolute;
  border-radius: 50%;
}
/* Draping foliage */
.fl-arch-foliage {
  position: absolute;
  top: 20px; left: -20px; right: -20px;
}
.fl-arch-leaf {
  position: absolute;
  border-radius: 50% 0;
  background: var(--fl-sage);
  transform-origin: top center;
}

.fl-wedding__include-list {
  list-style: none; margin-top: 20px;
  display: flex; flex-direction: column; gap: 10px;
}
.fl-wedding__include-list li {
  display: flex; gap: 10px; align-items: flex-start;
  font-size: .88rem; line-height: 1.6; color: rgba(212,200,188,.85);
}
.fl-wedding__include-list li::before {
  content: '❀'; flex-shrink: 0; color: var(--fl-gold-pale); font-size: .8rem;
}

/* ── PACKAGES ─────────────────────────────────────────────── */
.fl-packages__grid {
  display: grid; grid-template-columns: repeat(3,1fr);
  gap: 16px; margin-top: 52px;
}
.fl-package {
  padding: 40px 32px;
  background: var(--fl-cream);
  border: 1px solid rgba(192,144,80,.15);
  position: relative;
  transition: border-color .35s;
}
.fl-package:hover { border-color: rgba(200,120,128,.3); }
.fl-package--featured {
  background: var(--fl-charcoal);
  border-color: var(--fl-charcoal); color: var(--fl-cream);
}
.fl-package__badge {
  position: absolute; top: -1px; left: 50%; transform: translateX(-50%);
  background: var(--fl-rose); color: var(--fl-cream);
  font-size: .58rem; letter-spacing: .18em; font-weight: 600;
  text-transform: uppercase; padding: 4px 14px;
}
.fl-package__tier {
  font-size: .62rem; letter-spacing: .24em; font-weight: 600;
  color: var(--fl-rose); text-transform: uppercase; margin-bottom: 10px;
}
.fl-package--featured .fl-package__tier { color: var(--fl-gold-pale); }
.fl-package__name {
  font-family: var(--fl-serif); font-size: 1.7rem;
  color: var(--fl-charcoal); margin-bottom: 6px;
}
.fl-package--featured .fl-package__name { color: var(--fl-cream); }
.fl-package__price {
  font-family: var(--fl-serif); font-size: 2.2rem;
  color: var(--fl-rose); line-height: 1; margin-bottom: 4px;
}
.fl-package--featured .fl-package__price { color: var(--fl-gold-pale); }
.fl-package__per { font-size: .76rem; color: var(--fl-stone); margin-bottom: 22px; }
.fl-package--featured .fl-package__per { color: rgba(212,200,188,.65); }
.fl-package__sep { height: 1px; background: rgba(192,144,80,.12); margin-bottom: 22px; }
.fl-package--featured .fl-package__sep { background: rgba(255,255,255,.08); }
.fl-package__features {
  list-style: none; display: flex; flex-direction: column;
  gap: 9px; margin-bottom: 28px;
}
.fl-package__feature {
  display: flex; gap: 10px; align-items: flex-start;
  font-size: .86rem; line-height: 1.5; color: var(--fl-stone);
}
.fl-package--featured .fl-package__feature { color: rgba(212,200,188,.88); }
.fl-package__feature::before {
  content: '❀'; flex-shrink: 0; color: var(--fl-rose); font-size: .75rem;
}
.fl-package--featured .fl-package__feature::before { color: var(--fl-gold-pale); }

/* ── PROCESS ──────────────────────────────────────────────── */
.fl-process__steps {
  display: grid; grid-template-columns: repeat(4,1fr);
  gap: 0; margin-top: 52px; position: relative;
}
.fl-process__steps::before {
  content: '';
  position: absolute; top: 28px; left: 12.5%; right: 12.5%;
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(200,120,128,.3), rgba(200,120,128,.3), transparent);
}
.fl-process-step { text-align: center; padding: 0 24px; }
.fl-process-step__icon {
  font-size: 1.5rem; color: var(--fl-rose);
  margin-bottom: 18px; display: block;
  width: 56px; height: 56px;
  border: 1px solid rgba(200,120,128,.3);
  border-radius: 50%; line-height: 56px;
  margin: 0 auto 18px;
  background: var(--fl-cream);
  position: relative; z-index: 1;
}
.fl-process-step__title {
  font-family: var(--fl-serif); font-size: 1.1rem;
  color: var(--fl-charcoal); margin-bottom: 8px;
}
.fl-section--dark .fl-process-step__title { color: var(--fl-cream); }
.fl-process-step__text { font-size: .84rem; line-height: 1.65; color: var(--fl-stone); }
.fl-section--dark .fl-process-step__text { color: rgba(212,200,188,.7); }
.fl-section--dark .fl-process-step__icon { background: var(--fl-charcoal); border-color: rgba(192,144,80,.25); color: var(--fl-gold-pale); }

/* ── TESTIMONIALS ─────────────────────────────────────────── */
.fl-testimonials__grid {
  display: grid; grid-template-columns: repeat(3,1fr);
  gap: 20px; margin-top: 52px;
}
.fl-testimonial {
  padding: 32px 28px;
  background: var(--fl-cream);
  border-top: 2px solid var(--fl-rose);
}
.fl-testimonial__stars { font-size: .9rem; letter-spacing: 2px; color: var(--fl-gold); margin-bottom: 14px; }
.fl-testimonial__text {
  font-family: var(--fl-serif); font-style: italic;
  font-size: 1rem; line-height: 1.7; color: var(--fl-charcoal); margin-bottom: 18px;
}
.fl-testimonial__author { font-size: .78rem; color: var(--fl-stone); }
.fl-testimonial__author strong {
  display: block; font-style: normal;
  font-family: var(--fl-sans); font-weight: 600;
  color: var(--fl-charcoal); margin-bottom: 2px;
}

/* ── BOOKING FORM ─────────────────────────────────────────── */
.fl-booking {
  display: grid; grid-template-columns: 1fr 1fr; min-height: 580px;
}
.fl-booking__info {
  background: var(--fl-sage-deep); padding: 80px 7%;
  display: flex; flex-direction: column; justify-content: center;
  color: var(--fl-cream);
}
.fl-booking__form-wrap {
  background: var(--fl-ivory); padding: 80px 7%;
  display: flex; flex-direction: column; justify-content: center;
}
.fl-booking__manifesto {
  font-family: var(--fl-serif); font-size: 1.4rem;
  line-height: 1.5; color: var(--fl-cream); margin-top: 22px;
  padding-left: 18px; border-left: 1px solid rgba(192,144,80,.4);
}
.fl-form { display: flex; flex-direction: column; gap: 16px; }
.fl-field-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.fl-field { display: flex; flex-direction: column; gap: 5px; }
.fl-field label {
  font-size: .65rem; letter-spacing: .14em; font-weight: 500;
  color: var(--fl-stone); text-transform: uppercase;
}
.fl-field input,
.fl-field select,
.fl-field textarea {
  background: transparent; border: none;
  border-bottom: 1px solid rgba(106,96,88,.25);
  padding: 10px 0;
  font-family: var(--fl-sans); font-size: .9rem;
  color: var(--fl-charcoal); outline: none;
  transition: border-color .3s; width: 100%;
}
.fl-field input:focus,
.fl-field select:focus,
.fl-field textarea:focus { border-bottom-color: var(--fl-rose); }
.fl-field textarea { resize: vertical; min-height: 80px; }
.fl-field select { cursor: pointer; appearance: none; }
.fl-form .fl-btn { align-self: flex-start; margin-top: 8px; }

/* ── FOOTER ───────────────────────────────────────────────── */
.fl-footer {
  background: var(--fl-charcoal); padding: 64px 7% 32px;
  border-top: 1px solid rgba(192,144,80,.1);
}
.fl-footer__top {
  display: grid; grid-template-columns: 1.4fr 1fr 1fr 1fr;
  gap: 48px; padding-bottom: 48px;
  border-bottom: 1px solid rgba(192,144,80,.08);
}
.fl-footer__name {
  font-family: var(--fl-serif); font-size: 1.6rem;
  color: var(--fl-cream); margin-bottom: 3px;
}
.fl-footer__tagline {
  font-size: .6rem; letter-spacing: .28em; font-weight: 500;
  color: var(--fl-gold); text-transform: uppercase; margin-bottom: 16px;
}
.fl-footer__text { font-size: .84rem; line-height: 1.65; color: var(--fl-mist); }
.fl-footer__col-title {
  font-size: .62rem; letter-spacing: .24em; font-weight: 600;
  color: var(--fl-rose); text-transform: uppercase; margin-bottom: 16px;
}
.fl-footer__links { list-style: none; display: flex; flex-direction: column; gap: 8px; }
.fl-footer__links a {
  font-size: .84rem; color: var(--fl-mist); text-decoration: none; transition: color .3s;
}
.fl-footer__links a:hover { color: var(--fl-cream); }
.fl-footer__bottom {
  display: flex; justify-content: space-between; align-items: center;
  padding-top: 28px; font-size: .74rem; color: var(--fl-mist);
  flex-wrap: wrap; gap: 12px;
}
.fl-footer__bottom-links { display: flex; gap: 24px; }
.fl-footer__bottom-links a { color: var(--fl-mist); text-decoration: none; transition: color .3s; }
.fl-footer__bottom-links a:hover { color: var(--fl-rose); }

/* ── ANIMATIONS ───────────────────────────────────────────── */
@keyframes fl-petal-fall {
  0%   { opacity: 0; transform: translateY(-20px) rotate(var(--fl-rot,0deg)); }
  10%  { opacity: 1; }
  90%  { opacity: .7; }
  100% { opacity: 0; transform: translateY(100vh) rotate(calc(var(--fl-rot,0deg) + 180deg)); }
}
@keyframes fl-stem-sway {
  0%, 100% { transform: rotate(-2deg); }
  50%       { transform: rotate(2deg); }
}

/* ── RESPONSIVE ───────────────────────────────────────────── */
@media (max-width: 1100px) {
  .fl-collections__grid { grid-template-columns: repeat(2,1fr); }
  .fl-services__grid { grid-template-columns: repeat(2,1fr); }
  .fl-packages__grid { grid-template-columns: 1fr; }
  .fl-process__steps { grid-template-columns: repeat(2,1fr); gap: 40px; }
  .fl-footer__top { grid-template-columns: 1fr 1fr; }
}
@media (max-width: 768px) {
  .fl-nav { padding: 0 24px; }
  .fl-nav__links { display: none; }
  .fl-hero__content { padding: 0 24px 80px; }
  .fl-order-card { display: none; }
  .fl-about { grid-template-columns: 1fr; }
  .fl-wedding { grid-template-columns: 1fr; }
  .fl-booking { grid-template-columns: 1fr; }
  .fl-testimonials__grid { grid-template-columns: 1fr; }
  .fl-services__grid { grid-template-columns: 1fr; }
  .fl-collections__grid { grid-template-columns: 1fr; }
  .fl-field-row { grid-template-columns: 1fr; }
  .fl-process__steps { grid-template-columns: 1fr; }
  .fl-section { padding: 64px 24px; }
  .fl-footer__top { grid-template-columns: 1fr; }
}
</style>
<?php get_header(); ?>
<div class="fl-body">
">

<!-- NAV -->
<nav class="fl-nav" role="navigation" aria-label="Main navigation">
  <div class="fl-nav__logo">
    <span class="fl-nav__name">Botanica</span>
    <span class="fl-nav__tagline">Fine Flowers · Notting Hill, London · Est. 1998</span>
  </div>
  <ul class="fl-nav__links">
    <li><a href="#collections">Collections</a></li>
    <li><a href="#services">Services</a></li>
    <li><a href="#weddings">Weddings</a></li>
    <li><a href="#packages">Packages</a></li>
    <li><a href="#enquiry">Enquire</a></li>
  </ul>
  <a href="#enquiry" class="fl-nav__cta">Enquire Now</a>
</nav>

<!-- HERO -->
<section class="fl-hero" aria-label="Hero — Luxury Flower Studio">
  <div class="fl-studio-ceiling" aria-hidden="true"></div>
  <div class="fl-studio-wall" aria-hidden="true"></div>
  <div class="fl-dado-rail" aria-hidden="true"></div>
  <div class="fl-lower-wall" aria-hidden="true"></div>
  <div class="fl-studio-floor" aria-hidden="true"></div>
  <div class="fl-table" aria-hidden="true"></div>

  <!-- Shop window -->
  <div class="fl-window" aria-hidden="true">
    <div class="fl-window__frame">
      <div class="fl-window__outside"></div>
    </div>
    <div class="fl-window__sill"></div>
  </div>

  <!-- PHP falling petals -->
  <?php foreach ($fl_petals as $p) : ?>
  <div class="fl-petal" aria-hidden="true" style="
    left: <?php echo $p['left']; ?>%;
    top: -20px;
    width: <?php echo $p['size']; ?>px;
    height: <?php echo $p['size']; ?>px;
    background: hsl(<?php echo $p['hue']; ?>, 65%, 75%);
    --fl-rot: <?php echo $p['rot']; ?>deg;
    animation: fl-petal-fall <?php echo $p['dur']; ?>ms ease-in <?php echo $p['delay']; ?>ms infinite;
    opacity: 0;
  "></div>
  <?php endforeach; ?>

  <!-- Pendant lights -->
  <?php
  $pendants = [[15, 90, 24, 16], [35, 120, 20, 14], [55, 100, 22, 15], [75, 80, 24, 16], [90, 110, 20, 14]];
  foreach ($pendants as $pd) :
  ?>
  <div class="fl-pendant" aria-hidden="true" style="left: <?php echo $pd[0]; ?>%;">
    <div class="fl-pendant__wire" style="height: <?php echo $pd[1]; ?>px;"></div>
    <div class="fl-pendant__shade" style="
      border-left-width: <?php echo $pd[2]; ?>px;
      border-right-width: <?php echo $pd[2]; ?>px;
      border-top-width: <?php echo $pd[3]; ?>px;
      border-top-color: hsl(30,25%,60%);
    "></div>
  </div>
  <?php endforeach; ?>

  <!-- PHP flower stems on table -->
  <?php foreach ($fl_stems as $stem) :
    $type_classes = ['fl-head--round', 'fl-head--spray', 'fl-head--tulip', 'fl-head--daisy'];
    $type_cls = $type_classes[$stem['type']];
    $hw = $stem['w'];
    $hh = max(20, (int)($hw * 0.85));
  ?>
  <div class="fl-stem-wrap" aria-hidden="true" style="
    left: <?php echo $stem['left']; ?>%;
    animation: fl-stem-sway <?php echo 3000 + rand(0,2000); ?>ms ease-in-out <?php echo rand(0,1500); ?>ms infinite;
  ">
    <div class="<?php echo esc_attr($type_cls); ?>" style="
      width: <?php echo $hw; ?>px;
      height: <?php echo $hh; ?>px;
      background: hsl(<?php echo $stem['hue']; ?>,<?php echo $stem['sat']; ?>%,<?php echo $stem['lit']; ?>%);
    "></div>
    <div class="fl-stem" style="height: <?php echo $stem['height']; ?>px;"></div>
  </div>
  <?php endforeach; ?>

  <!-- Vessel group left -->
  <div class="fl-vessel-wrap" aria-hidden="true" style="left:4%; gap:6px;">
    <?php
    $vessels_l = [
      ['w'=>40,'h'=>90, 'hue'=>200,'sat'=>18,'lit'=>70, 'cls'=>'fl-vessel--tall-cylinder'],
      ['w'=>60,'h'=>55, 'hue'=>28, 'sat'=>30,'lit'=>68, 'cls'=>'fl-vessel--wide-urn'],
      ['w'=>22,'h'=>100,'hue'=>220,'sat'=>12,'lit'=>78, 'cls'=>'fl-vessel--bud-vase'],
    ];
    foreach ($vessels_l as $v) : ?>
    <div class="fl-vessel <?php echo esc_attr($v['cls']); ?>" style="
      width: <?php echo $v['w']; ?>px; height: <?php echo $v['h']; ?>px;
      background: radial-gradient(circle at 30% 25%,
        hsl(<?php echo $v['hue']; ?>,<?php echo $v['sat']; ?>%,<?php echo min(95,$v['lit']+15); ?>%) 0%,
        hsl(<?php echo $v['hue']; ?>,<?php echo $v['sat']; ?>%,<?php echo $v['lit']; ?>%) 50%,
        hsl(<?php echo $v['hue']; ?>,<?php echo max(0,$v['sat']-5); ?>%,<?php echo max(30,$v['lit']-20); ?>%) 100%
      );
    "></div>
    <?php endforeach; ?>
  </div>

  <!-- Florist figure -->
  <div class="fl-florist" aria-hidden="true" role="img" aria-label="Florist at work">
    <div class="fl-florist__head"></div>
    <div class="fl-florist__neck"></div>
    <div class="fl-florist__body">
      <div class="fl-florist__arm-r"></div>
      <div class="fl-florist__arm-l"></div>
    </div>
  </div>

  <!-- Light spill -->
  <div style="position:absolute; inset:0; background: radial-gradient(ellipse 70% 80% at 50% 10%, rgba(255,248,240,.15) 0%, transparent 60%); pointer-events:none;" aria-hidden="true"></div>

  <!-- Hero text -->
  <div class="fl-hero__content">
    <div class="fl-hero__eyebrow">
      <div class="fl-hero__eyebrow-line"></div>
      <span class="fl-hero__eyebrow-text">Botanica · Est. 1998</span>
    </div>
    <h1 class="fl-hero__title">Flowers as<br>fine art</h1>
    <p class="fl-hero__tagline">
      Twenty-six years of exceptional floristry from our Notting Hill studio.
      Seasonal collections, bespoke arrangements, wedding floristry and
      event installations that stop rooms.
    </p>
    <div class="fl-hero__actions">
      <a href="#collections" class="fl-btn fl-btn--rose">View Collections</a>
      <a href="#enquiry" class="fl-btn fl-btn--outline">Commission a Design</a>
    </div>
  </div>

  <!-- Order card -->
  <div class="fl-order-card" aria-label="Same-day delivery available">
    <div class="fl-order-card__title">Studio Hours</div>
    <div class="fl-order-card__row">
      <span class="fl-order-card__key">Monday – Friday</span>
      <span class="fl-order-card__val">8am – 7pm</span>
    </div>
    <div class="fl-order-card__row">
      <span class="fl-order-card__key">Saturday</span>
      <span class="fl-order-card__val">8am – 5pm</span>
    </div>
    <div class="fl-order-card__row">
      <span class="fl-order-card__key">Sunday</span>
      <span class="fl-order-card__val">10am – 3pm</span>
    </div>
    <div class="fl-order-card__sep"></div>
    <div class="fl-order-card__avail">
      <div class="fl-order-card__dot"></div>
      <span>Same-day delivery available</span>
    </div>
  </div>
</section>

<!-- STATS -->
<div class="fl-stats" aria-label="Botanica achievements">
  <div class="fl-stat">
    <div class="fl-stat__val" data-target="26">26</div>
    <div class="fl-stat__lbl">Years in Notting Hill</div>
  </div>
  <div class="fl-stat">
    <div class="fl-stat__val" data-target="3200">3,200+</div>
    <div class="fl-stat__lbl">Events Dressed</div>
  </div>
  <div class="fl-stat">
    <div class="fl-stat__val" data-target="4.9">4.9★</div>
    <div class="fl-stat__lbl">Client Rating</div>
  </div>
  <div class="fl-stat">
    <div class="fl-stat__val" data-target="42">42</div>
    <div class="fl-stat__lbl">RHS Awards</div>
  </div>
</div>

<!-- SEASONAL COLLECTIONS -->
<section id="collections" class="fl-section fl-section--ivory" aria-labelledby="fl-collections-heading">
  <div class="fl-section-label">
    <span class="fl-section-label__icon">❀</span>
    <span class="fl-section-label__text">The Collections</span>
  </div>
  <h2 id="fl-collections-heading" class="fl-h2">
    Seasonal <em>Arrangements</em>
  </h2>
  <p class="fl-lead">
    Each collection is designed around the flowers naturally at their peak —
    sourced directly from British growers and our partner farms in the Netherlands and Colombia.
  </p>

  <div class="fl-collections__grid" role="list">
    <?php
    $season_bgs = [
      'Spring' => 'linear-gradient(180deg, #F0E8F4 0%, #E0D4EC 100%)',
      'Summer' => 'linear-gradient(180deg, #FAF0E8 0%, #F0E4DC 100%)',
      'Autumn' => 'linear-gradient(180deg, #F8EEE0 0%, #EEE0CC 100%)',
      'Winter' => 'linear-gradient(180deg, #F0F4F8 0%, #E4EEF8 100%)',
    ];
    $bloom_sets = [
      'Spring' => [[355,60,75,18,14],[330,55,72,28,22],[280,45,65,22,18],[355,65,80,14,12],[330,60,68,20,16]],
      'Summer' => [[340,60,68,24,20],[310,50,72,20,16],[260,40,65,16,14],[340,65,75,18,14],[310,55,70,22,18]],
      'Autumn' => [[28,70,60,22,18],[15,75,55,18,15],[40,65,55,20,16],[28,80,65,14,12],[15,70,60,24,20]],
      'Winter' => [[355,50,85,18,14],[150,30,40,20,24],[0,0,90,16,13],[355,45,80,22,18],[150,25,45,16,20]],
    ];
    foreach ($fl_collections as $col) :
      $blooms = $bloom_sets[$col['season']];
    ?>
    <div class="fl-collection-card" role="listitem">
      <div class="fl-collection-card__visual" style="background:<?php echo $season_bgs[$col['season']]; ?>;">
        <div class="fl-season-flowers" aria-hidden="true">
          <?php
          $positions = [12,28,44,60,76];
          foreach ($blooms as $bi => $bloom) :
            $stemH = 80 + rand(0,60);
          ?>
          <div class="fl-season-stem" style="
            left: <?php echo $positions[$bi]; ?>%;
            height: <?php echo $stemH; ?>px;
          "></div>
          <div class="fl-season-head" style="
            bottom: calc(8px + <?php echo $stemH; ?>px);
            left: calc(<?php echo $positions[$bi]; ?>% - <?php echo (int)($bloom[3]/2); ?>px);
            width: <?php echo $bloom[3]; ?>px;
            height: <?php echo $bloom[4]; ?>px;
            background: hsl(<?php echo $bloom[0]; ?>,<?php echo $bloom[1]; ?>%,<?php echo $bloom[2]; ?>%);
            position: absolute;
            border-radius: <?php echo ($col['season']==='Autumn') ? '3px' : '50%'; ?>;
          "></div>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="fl-collection-card__info">
        <div class="fl-collection-card__season"><?php echo esc_html($col['season']); ?></div>
        <div class="fl-collection-card__name"><?php echo esc_html($col['name']); ?></div>
        <p class="fl-collection-card__desc"><?php echo esc_html($col['desc']); ?></p>
        <div class="fl-palette" aria-label="Colour palette">
          <?php foreach ($col['palette'] as $ph) : ?>
          <div class="fl-palette-dot" style="background: hsl(<?php echo $ph; ?>,50%,70%);"></div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- SERVICES -->
<section id="services" class="fl-section fl-section--cream" aria-labelledby="fl-services-heading">
  <div class="fl-section-label">
    <span class="fl-section-label__icon">✿</span>
    <span class="fl-section-label__text">What We Do</span>
  </div>
  <h2 id="fl-services-heading" class="fl-h2">Our Services</h2>
  <p class="fl-lead">
    From a single hand-tied bouquet to a full event transformation — every commission
    receives the same obsessive attention and the same extraordinary flowers.
  </p>

  <div class="fl-services__grid" role="list">
    <?php foreach ($fl_services as $svc) : ?>
    <article class="fl-service-card" role="listitem">
      <span class="fl-service-card__icon" aria-hidden="true"><?php echo esc_html($svc['icon']); ?></span>
      <h3 class="fl-service-card__name"><?php echo esc_html($svc['name']); ?></h3>
      <p class="fl-service-card__desc"><?php echo esc_html($svc['desc']); ?></p>
      <div class="fl-service-card__from"><?php echo esc_html($svc['from']); ?></div>
    </article>
    <?php endforeach; ?>
  </div>
</section>

<!-- ABOUT -->
<section id="about" class="fl-about" aria-labelledby="fl-about-heading">
  <div class="fl-about__visual" aria-hidden="true">
    <div class="fl-vessel-scene">
      <?php
      $vs = [
        ['hue'=>200,'sat'=>18,'lit'=>72,'ww'=>44,'hh'=>90,'blooms'=>[[355,65,72,18,14],[330,60,75,22,18],[280,45,68,16,12]]],
        ['hue'=>30, 'sat'=>28,'lit'=>65,'ww'=>68,'hh'=>60,'blooms'=>[[28,70,62,24,20],[15,75,60,20,16],[28,65,68,16,14]]],
        ['hue'=>180,'sat'=>12,'lit'=>68,'ww'=>30,'hh'=>110,'blooms'=>[[355,55,80,14,10],[330,50,76,18,14]]],
      ];
      foreach ($vs as $vsi) : ?>
      <div class="fl-vessel-flower-group">
        <div class="fl-vessel-blooms" style="height:100px; position:relative; width:<?php echo $vsi['ww']+20; ?>px;">
          <?php
          $bpos = array_map(fn($j) => ($j * (int)($vsi['ww'] / count($vsi['blooms']))) + 10, array_keys($vsi['blooms']));
          foreach ($vsi['blooms'] as $bi2 => $bl) :
            $sth = 55 + rand(0,30);
          ?>
          <div style="
            position:absolute; bottom:0; left:<?php echo $bpos[$bi2]; ?>px;
            width:2px; height:<?php echo $sth; ?>px; background:var(--fl-sage); border-radius:1px;
          "></div>
          <div style="
            position:absolute;
            bottom:<?php echo $sth; ?>px; left:<?php echo $bpos[$bi2]-($bl[3]/2); ?>px;
            width:<?php echo $bl[3]; ?>px; height:<?php echo $bl[4]; ?>px;
            border-radius:50%;
            background:hsl(<?php echo $bl[0]; ?>,<?php echo $bl[1]; ?>%,<?php echo $bl[2]; ?>%);
          "></div>
          <?php endforeach; ?>
        </div>
        <div class="fl-vvessel" style="
          width:<?php echo $vsi['ww']; ?>px; height:<?php echo $vsi['hh']; ?>px;
          background:radial-gradient(circle at 28% 22%,
            hsl(<?php echo $vsi['hue']; ?>,<?php echo $vsi['sat']; ?>%,<?php echo min(95,$vsi['lit']+18); ?>%) 0%,
            hsl(<?php echo $vsi['hue']; ?>,<?php echo $vsi['sat']; ?>%,<?php echo $vsi['lit']; ?>%) 50%,
            hsl(<?php echo $vsi['hue']; ?>,<?php echo max(0,$vsi['sat']-5); ?>%,<?php echo max(30,$vsi['lit']-18); ?>%) 100%
          );
        "></div>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="position:absolute; bottom:20px; left:0; right:0; text-align:center; font-size:.6rem; letter-spacing:.2em; color:var(--fl-stone); text-transform:uppercase;">The Botanica Studio</div>
  </div>
  <div class="fl-about__text">
    <div class="fl-section-label">
      <span class="fl-section-label__icon">❁</span>
      <span class="fl-section-label__text">Our Story</span>
    </div>
    <h2 id="fl-about-heading" class="fl-h2">Rooted in<br>Notting Hill</h2>
    <p class="fl-lead">
      Botanica opened on Ledbury Road in 1998 and has grown, season by season, into one
      of London's most respected flower studios. We work with the best British and Dutch
      growers to bring you flowers at the absolute peak of their beauty.
    </p>
    <ul class="fl-about__values">
      <li class="fl-about__value">
        <span class="fl-about__value-icon" aria-hidden="true">❀</span>
        <span class="fl-about__value-text">Direct relationships with family growers in Kent, Somerset and the Isles of Scilly — seasonal and local wherever possible</span>
      </li>
      <li class="fl-about__value">
        <span class="fl-about__value-icon" aria-hidden="true">❀</span>
        <span class="fl-about__value-text">RHS Chelsea Flower Show exhibitors 2012–2025 with three Gold Medals and a Best in Show</span>
      </li>
      <li class="fl-about__value">
        <span class="fl-about__value-icon" aria-hidden="true">❀</span>
        <span class="fl-about__value-text">Carbon-aware floristry: packaging is 100% compostable, all wires and mechanics recyclable</span>
      </li>
    </ul>
  </div>
</section>

<!-- WEDDINGS -->
<section id="weddings" class="fl-wedding" aria-labelledby="fl-wedding-heading">
  <div class="fl-wedding__text">
    <div class="fl-section-label">
      <span class="fl-section-label__icon">✾</span>
      <span class="fl-section-label__text">Wedding Floristry</span>
    </div>
    <h2 id="fl-wedding-heading" class="fl-h2" style="color:var(--fl-cream);">
      Your wedding,<br>in full bloom
    </h2>
    <p style="font-size:1rem; font-weight:300; line-height:1.75; color:rgba(212,200,188,.85); margin-bottom:20px;">
      We take just thirty weddings a year — so every one receives the full attention
      of our senior team. From initial consultation through to the moment the last
      petal falls, we are with you entirely.
    </p>
    <ul class="fl-wedding__include-list">
      <li>Bridal bouquet, bridesmaid posies &amp; buttonholes</li>
      <li>Ceremony arch, aisle arrangements and altar florals</li>
      <li>Reception centrepieces and table runners</li>
      <li>On-the-day dressing, placement and styling</li>
      <li>Post-ceremony collection and venue restoration</li>
    </ul>
    <a href="#enquiry" class="fl-btn fl-btn--sage" style="margin-top:28px;">Enquire About Your Wedding</a>
  </div>
  <div class="fl-wedding__visual" aria-hidden="true">
    <div class="fl-arch-scene">
      <div class="fl-arch" role="img" aria-label="Floral wedding arch illustration">
        <div class="fl-arch__left"></div>
        <div class="fl-arch__right"></div>
        <div class="fl-arch__top"></div>
        <div class="fl-arch-blooms">
          <?php
          $arch_blooms = [
            [-10,0,22,18,355,65,72], [10,15,18,14,330,60,75], [28,-5,24,20,280,45,65],
            [44,8,20,16,355,55,80], [60,-8,18,14,330,65,70], [78,12,22,18,28,50,65],
            [96,-4,16,12,15,65,60], [110,16,20,16,355,70,75], [128,-8,18,14,280,50,68],
          ];
          foreach ($arch_blooms as $ab) : ?>
          <div class="fl-arch-bloom" style="
            left: <?php echo $ab[0]; ?>px; top: <?php echo $ab[1]; ?>px;
            width: <?php echo $ab[2]; ?>px; height: <?php echo $ab[3]; ?>px;
            background: hsl(<?php echo $ab[4]; ?>,<?php echo $ab[5]; ?>%,<?php echo $ab[6]; ?>%);
            border-radius: 50%;
          "></div>
          <?php endforeach; ?>
          <?php
          // Foliage leaves
          $leaves = [[-15,20,20,30,-30],[0,35,18,26,0],[18,18,20,30,20],[36,38,16,24,-10],[54,15,20,30,-20],[72,40,18,26,15],[90,18,20,30,30],[110,35,16,24,-15],[130,20,18,28,-30]];
          foreach ($leaves as $lf) : ?>
          <div class="fl-arch-leaf" style="
            left: <?php echo $lf[0]; ?>px; top: <?php echo $lf[1]; ?>px;
            width: <?php echo $lf[2]; ?>px; height: <?php echo $lf[3]; ?>px;
            background: hsl(140,<?php echo 40+rand(0,20); ?>%,<?php echo 35+rand(0,15); ?>%);
            transform: rotate(<?php echo $lf[4]; ?>deg);
            border-radius: 50% 0;
          "></div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- PACKAGES -->
<section id="packages" class="fl-section fl-section--parch" aria-labelledby="fl-packages-heading">
  <div class="fl-section-label">
    <span class="fl-section-label__icon">❋</span>
    <span class="fl-section-label__text">Wedding Packages</span>
  </div>
  <h2 id="fl-packages-heading" class="fl-h2">Floral <em>Packages</em></h2>
  <p class="fl-lead">
    Three starting points for your wedding floristry — each customisable
    and priced to give you complete clarity from the very first enquiry.
  </p>

  <div class="fl-packages__grid" role="list">
    <article class="fl-package" role="listitem">
      <div class="fl-package__tier">The Garden Ceremony</div>
      <div class="fl-package__name">Intimate</div>
      <div class="fl-package__price">From £2,400</div>
      <div class="fl-package__per">Up to 30 guests</div>
      <div class="fl-package__sep"></div>
      <ul class="fl-package__features">
        <li class="fl-package__feature">Bridal bouquet — hand-tied, seasonal</li>
        <li class="fl-package__feature">2 bridesmaid posies</li>
        <li class="fl-package__feature">6 buttonholes &amp; corsages</li>
        <li class="fl-package__feature">Ceremony arch or floral frame</li>
        <li class="fl-package__feature">5 reception centrepieces</li>
        <li class="fl-package__feature">On-the-day styling included</li>
      </ul>
      <a href="#enquiry" class="fl-btn fl-btn--outline">Enquire</a>
    </article>
    <article class="fl-package fl-package--featured" role="listitem">
      <div class="fl-package__badge">Most Popular</div>
      <div class="fl-package__tier">The Full Celebration</div>
      <div class="fl-package__name">Classic</div>
      <div class="fl-package__price">From £6,800</div>
      <div class="fl-package__per">Up to 120 guests</div>
      <div class="fl-package__sep"></div>
      <ul class="fl-package__features">
        <li class="fl-package__feature">Bridal bouquet — premium, bespoke</li>
        <li class="fl-package__feature">4 bridesmaid bouquets</li>
        <li class="fl-package__feature">All buttonholes &amp; corsages</li>
        <li class="fl-package__feature">Full ceremony florals &amp; aisle dressing</li>
        <li class="fl-package__feature">16 reception centrepieces</li>
        <li class="fl-package__feature">Welcome arrangement &amp; cake flowers</li>
        <li class="fl-package__feature">Full on-the-day styling team</li>
      </ul>
      <a href="#enquiry" class="fl-btn fl-btn--sage">Begin Planning</a>
    </article>
    <article class="fl-package" role="listitem">
      <div class="fl-package__tier">The Grand Estate</div>
      <div class="fl-package__name">Prestige</div>
      <div class="fl-package__price">POA</div>
      <div class="fl-package__per">Unlimited guests</div>
      <div class="fl-package__sep"></div>
      <ul class="fl-package__features">
        <li class="fl-package__feature">Full floristry direction &amp; design</li>
        <li class="fl-package__feature">Venue consultation &amp; site visit</li>
        <li class="fl-package__feature">Multiple large floral installations</li>
        <li class="fl-package__feature">Hanging installations &amp; canopy work</li>
        <li class="fl-package__feature">Bespoke table &amp; seating arrangements</li>
        <li class="fl-package__feature">Pre-wedding events &amp; day-after florals</li>
        <li class="fl-package__feature">Dedicated creative lead throughout</li>
      </ul>
      <a href="#enquiry" class="fl-btn fl-btn--outline">Request Proposal</a>
    </article>
  </div>
</section>

<!-- PROCESS -->
<section class="fl-section fl-section--dark" aria-labelledby="fl-process-heading">
  <div class="fl-section-label">
    <span class="fl-section-label__icon">❃</span>
    <span class="fl-section-label__text">How It Works</span>
  </div>
  <h2 id="fl-process-heading" class="fl-h2" style="color:var(--fl-cream);">Our Process</h2>

  <div class="fl-process__steps" role="list">
    <div class="fl-process-step" role="listitem">
      <span class="fl-process-step__icon" aria-hidden="true">❀</span>
      <h3 class="fl-process-step__title">Initial Enquiry</h3>
      <p class="fl-process-step__text">Tell us about your event, dates and vision. We'll respond within one working day with initial thoughts and availability.</p>
    </div>
    <div class="fl-process-step" role="listitem">
      <span class="fl-process-step__icon" aria-hidden="true">✿</span>
      <h3 class="fl-process-step__title">Studio Consultation</h3>
      <p class="fl-process-step__text">An in-person or video meeting to explore your ideas, colours and style. We bring mood boards, seasonal blooms and honest guidance.</p>
    </div>
    <div class="fl-process-step" role="listitem">
      <span class="fl-process-step__icon" aria-hidden="true">❁</span>
      <h3 class="fl-process-step__title">Design &amp; Proposal</h3>
      <p class="fl-process-step__text">A detailed written proposal with a full flower breakdown, costings and timeline. No surprises, no hidden extras.</p>
    </div>
    <div class="fl-process-step" role="listitem">
      <span class="fl-process-step__icon" aria-hidden="true">✾</span>
      <h3 class="fl-process-step__title">Your Big Day</h3>
      <p class="fl-process-step__text">Our team arrives early, dresses your venue beautifully, and stays as long as needed. You just need to enjoy it.</p>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="fl-section fl-section--ivory" aria-labelledby="fl-testimonials-heading">
  <div class="fl-section-label">
    <span class="fl-section-label__icon">❀</span>
    <span class="fl-section-label__text">Client Words</span>
  </div>
  <h2 id="fl-testimonials-heading" class="fl-h2">What our clients <em>say</em></h2>
  <div class="fl-testimonials__grid" role="list">
    <blockquote class="fl-testimonial" role="listitem">
      <div class="fl-testimonial__stars" aria-label="5 stars">★★★★★</div>
      <p class="fl-testimonial__text">
        "The arch that Botanica built for our ceremony at Blenheim was quite simply
        the most beautiful thing I have ever seen. Guests are still talking about it.
        Worth every single penny."
      </p>
      <footer class="fl-testimonial__author">
        <strong>Cecilia &amp; James Harrington</strong>Wedding at Blenheim Palace
      </footer>
    </blockquote>
    <blockquote class="fl-testimonial" role="listitem">
      <div class="fl-testimonial__stars" aria-label="5 stars">★★★★★</div>
      <p class="fl-testimonial__text">
        "We used Botanica for our annual gala at the Dorchester — tables of sixty
        dressed with their signature installations. The attention to detail and the
        sheer beauty of the work made the event extraordinary."
      </p>
      <footer class="fl-testimonial__author">
        <strong>Emily Northcott</strong>Events Director, Elysian Foundation
      </footer>
    </blockquote>
    <blockquote class="fl-testimonial" role="listitem">
      <div class="fl-testimonial__stars" aria-label="5 stars">★★★★★</div>
      <p class="fl-testimonial__text">
        "I've had a weekly arrangement from Botanica for twelve years. They have never
        once sent anything less than absolutely stunning. The subscription is the best
        thing I spend money on."
      </p>
      <footer class="fl-testimonial__author">
        <strong>Lady A. Pemberton</strong>Subscription Client, 12 years
      </footer>
    </blockquote>
  </div>
</section>

<!-- ENQUIRY FORM -->
<section id="enquiry" class="fl-booking" aria-labelledby="fl-enquiry-heading">
  <div class="fl-booking__info">
    <div class="fl-section-label">
      <span class="fl-section-label__icon">❃</span>
      <span class="fl-section-label__text">Get in Touch</span>
    </div>
    <h2 id="fl-enquiry-heading" class="fl-h2" style="color:var(--fl-cream);">
      Let us create<br>something beautiful
    </h2>
    <blockquote class="fl-booking__manifesto">
      "Flowers are the music of the ground — and every arrangement is a composition.
      We listen first, then we create."
      <cite style="display:block; margin-top:12px; font-size:.7rem; letter-spacing:.15em; font-style:normal; color:var(--fl-gold-pale);">— SOPHIA BELLAMY, CREATIVE DIRECTOR</cite>
    </blockquote>
    <div style="margin-top:28px; display:flex; flex-direction:column; gap:12px;">
      <div>
        <div style="font-size:.6rem; letter-spacing:.22em; color:var(--fl-gold-pale); text-transform:uppercase; margin-bottom:4px; font-weight:500;">Studio</div>
        <div style="font-size:.88rem; color:rgba(212,200,188,.85); line-height:1.6;">24 Ledbury Road, Notting Hill, London W11 2AB</div>
      </div>
      <div>
        <div style="font-size:.6rem; letter-spacing:.22em; color:var(--fl-gold-pale); text-transform:uppercase; margin-bottom:4px; font-weight:500;">Phone</div>
        <div style="font-size:.88rem; color:rgba(212,200,188,.85);">020 7946 0720</div>
      </div>
      <div>
        <div style="font-size:.6rem; letter-spacing:.22em; color:var(--fl-gold-pale); text-transform:uppercase; margin-bottom:4px; font-weight:500;">Email</div>
        <div style="font-size:.88rem; color:rgba(212,200,188,.85);">hello@botanicaflowers.co.uk</div>
      </div>
    </div>
  </div>
  <div class="fl-booking__form-wrap">
    <div class="fl-section-label">
      <span class="fl-section-label__icon">❀</span>
      <span class="fl-section-label__text">Enquiry Form</span>
    </div>
    <h3 style="font-family:var(--fl-serif); font-size:1.7rem; margin-bottom:26px; color:var(--fl-charcoal);">
      Tell us about your flowers
    </h3>
    <form class="fl-form" method="post" action="" novalidate aria-label="Floristry enquiry form">
      <?php wp_nonce_field('tf_fl_enquiry', 'tf_fl_nonce'); ?>
      <div class="fl-field-row">
        <div class="fl-field">
          <label for="fl-first-name">First Name <span aria-hidden="true">*</span></label>
          <input type="text" id="fl-first-name" name="fl_first_name" required autocomplete="given-name">
        </div>
        <div class="fl-field">
          <label for="fl-last-name">Last Name <span aria-hidden="true">*</span></label>
          <input type="text" id="fl-last-name" name="fl_last_name" required autocomplete="family-name">
        </div>
      </div>
      <div class="fl-field-row">
        <div class="fl-field">
          <label for="fl-email">Email <span aria-hidden="true">*</span></label>
          <input type="email" id="fl-email" name="fl_email" required autocomplete="email">
        </div>
        <div class="fl-field">
          <label for="fl-phone">Phone</label>
          <input type="tel" id="fl-phone" name="fl_phone" autocomplete="tel">
        </div>
      </div>
      <div class="fl-field">
        <label for="fl-service">Type of Enquiry <span aria-hidden="true">*</span></label>
        <select id="fl-service" name="fl_service" required>
          <option value="">Please select…</option>
          <option value="wedding">Wedding Floristry</option>
          <option value="event">Event &amp; Corporate</option>
          <option value="bespoke">Bespoke Arrangement</option>
          <option value="subscription">Seasonal Subscription</option>
          <option value="sympathy">Sympathy &amp; Tribute</option>
          <option value="workshop">Floral Workshop</option>
        </select>
      </div>
      <div class="fl-field-row">
        <div class="fl-field">
          <label for="fl-date">Event Date</label>
          <input type="date" id="fl-date" name="fl_date">
        </div>
        <div class="fl-field">
          <label for="fl-budget">Approximate Budget</label>
          <select id="fl-budget" name="fl_budget">
            <option value="">Please select…</option>
            <option value="under500">Under £500</option>
            <option value="500-2k">£500 – £2,000</option>
            <option value="2k-6k">£2,000 – £6,000</option>
            <option value="6k-plus">£6,000+</option>
            <option value="discuss">Prefer to discuss</option>
          </select>
        </div>
      </div>
      <div class="fl-field">
        <label for="fl-palette">Colour Palette / Style Notes</label>
        <textarea id="fl-palette" name="fl_palette" rows="3"
                  placeholder="E.g. blush and ivory, wildflower meadow style, maximalist, architectural minimalism…"></textarea>
      </div>
      <button type="submit" class="fl-btn fl-btn--rose" aria-label="Submit floristry enquiry">
        Send Enquiry
      </button>
    </form>
  </div>
</section>

<!-- FOOTER -->
<footer class="fl-footer" role="contentinfo" aria-label="Site footer">
  <div class="fl-footer__top">
    <div>
      <div class="fl-footer__name">Botanica</div>
      <div class="fl-footer__tagline">Fine Flowers · Notting Hill · Est. 1998</div>
      <p class="fl-footer__text">
        Award-winning flower studio serving London and beyond since 1998.
        RHS Gold Medalists. Seasonal floristry, weddings and events.
      </p>
    </div>
    <div>
      <div class="fl-footer__col-title">Services</div>
      <ul class="fl-footer__links">
        <li><a href="#services">Wedding Floristry</a></li>
        <li><a href="#services">Events &amp; Corporate</a></li>
        <li><a href="#services">Bespoke Arrangements</a></li>
        <li><a href="#services">Subscriptions</a></li>
        <li><a href="#services">Floral Workshops</a></li>
      </ul>
    </div>
    <div>
      <div class="fl-footer__col-title">Collections</div>
      <ul class="fl-footer__links">
        <li><a href="#collections">Spring</a></li>
        <li><a href="#collections">Summer</a></li>
        <li><a href="#collections">Autumn</a></li>
        <li><a href="#collections">Winter</a></li>
        <li><a href="#enquiry">Custom Palette</a></li>
      </ul>
    </div>
    <div>
      <div class="fl-footer__col-title">Visit Us</div>
      <p style="font-size:.84rem; color:var(--fl-mist); line-height:1.7;">
        24 Ledbury Road<br>
        Notting Hill<br>
        London W11 2AB<br><br>
        020 7946 0720<br>
        hello@botanicaflowers.co.uk
      </p>
    </div>
  </div>
  <div class="fl-footer__bottom">
    <span>© <?php echo date('Y'); ?> Botanica Ltd. All rights reserved.</span>
    <div class="fl-footer__bottom-links">
      <a href="#">Privacy Policy</a>
      <a href="#">Terms of Service</a>
      <a href="#">Cookie Policy</a>
    </div>
  </div>
</footer>

<script>
(function () {
  'use strict';

  /* ── Counter animation ─────────────────────────────────── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  const isFloat = v => !isNaN(v) && v % 1 !== 0;

  document.querySelectorAll('.fl-stat__val[data-target]').forEach(el => {
    const raw    = el.dataset.target;
    const target = parseFloat(raw);
    if (isNaN(target)) return;
    const duration = 1800;
    const start    = performance.now();
    const suffix   = el.textContent.replace(String(raw), '').trim();
    const tick = now => {
      const t   = Math.min((now - start) / duration, 1);
      const val = target * easeOut(t);
      el.textContent = (isFloat(target) ? val.toFixed(1) : Math.round(val).toLocaleString())
                       + (suffix ? suffix : '');
      if (t < 1) requestAnimationFrame(tick);
    };
    const obs = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) { requestAnimationFrame(tick); obs.disconnect(); }
    }, { threshold: 0.5 });
    obs.observe(el);
  });

  /* ── Nav scroll ─────────────────────────────────────────── */
  const nav = document.querySelector('.fl-nav');
  if (nav) {
    window.addEventListener('scroll', () => {
      nav.style.boxShadow = window.scrollY > 60
        ? '0 2px 24px rgba(42,36,32,.1)'
        : 'none';
    }, { passive: true });
  }

  /* ── Form ───────────────────────────────────────────────── */
  const form = document.querySelector('.fl-form');
  if (form) {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const btn = form.querySelector('button[type="submit"]');
      btn.textContent = 'Sending…';
      btn.disabled = true;
      setTimeout(() => {
        btn.textContent = 'Enquiry Sent — We\'ll be in touch shortly ❀';
        btn.style.background = '#5A8050';
        btn.style.borderColor = '#5A8050';
      }, 1200);
    });
  }

})();
</script>

</body>
</html>
</div><!-- .fl-body -->
<?php get_footer(); ?>
