<?php
/**
 * Template Name: Garage – Auto Repair & Car Workshop
 *
 * Premium page template for an auto repair garage and workshop.
 * Namespace : --grg-*
 * Fonts     : Oswald (headings) + Roboto (body)
 * Palette   : steel #1a1f28, iron #252c38, chrome #3a4455, red #c8281e,
 *             orange #e87820, yellow #f0c020, silver #d0d8e0, white #f4f6f8
 * Hero      : CSS garage bay — roller shutter door, car silhouette on lift,
 *             oil stains on concrete, hanging tool rack, neon sign,
 *             tyre stack, headlight beams
 */

srand(crc32(get_the_permalink()));

/* ── PHP data ───────────────────────────────────────────── */

$services = [
    ['icon'=>'⚙','name'=>'Full Service & MOT',        'price'=>'From £149','desc'=>'Comprehensive full-service including oil, filters, brakes, lights and fluid checks. MOT test with free retest on minor failures.','time'=>'Same day'],
    ['icon'=>'◈','name'=>'Brake Repair & Replacement', 'price'=>'From £89', 'desc'=>'Brake pad and disc inspection, replacement and bleeding. All vehicles — including EV and hybrid brake regeneration systems.','time'=>'2–4 hrs'],
    ['icon'=>'◎','name'=>'Tyre Fitting & Alignment',   'price'=>'From £49', 'desc'=>'Supply and fit from all major brands. 4-wheel alignment with digital printout, TPMS reset and balancing.','time'=>'1–2 hrs'],
    ['icon'=>'◇','name'=>'Engine Diagnostics',         'price'=>'From £60', 'desc'=>'Full OBD-II scan plus live data analysis across all makes and models. Diagnostic report provided with every scan.','time'=>'1 hr'],
    ['icon'=>'◆','name'=>'Clutch & Gearbox',           'price'=>'From £350','desc'=>'Clutch replacement, dual-mass flywheel, DMF conversion and gearbox rebuilds. Manual and automatic transmissions.','time'=>'1–2 days'],
    ['icon'=>'⚙','name'=>'Air Conditioning',           'price'=>'From £69', 'desc'=>'Re-gas, leak test, pollen filter and compressor repair. Using R1234yf and R134a refrigerants for all vehicle types.','time'=>'1–2 hrs'],
    ['icon'=>'◈','name'=>'Exhaust & Emissions',        'price'=>'From £95', 'desc'=>'Full exhaust system inspection, DPF regeneration and replacement, CAT converter and emission system repair.','time'=>'2–4 hrs'],
    ['icon'=>'◎','name'=>'Bodywork & Paint',           'price'=>'From £120','desc'=>'Smart repair for minor dents, scratches and scuffs. Full respray available. Approved Thatcham SMART centre.','time'=>'1–5 days'],
];

$packages = [
    [
        'name' =>'Basic Service',
        'price'=>'£149',
        'features'=>[
            'Engine oil and filter change',
            'Air filter inspection',
            'Brake check',
            'Lights & electrics check',
            'Fluid top-up (5 fluids)',
            'Road test',
        ],
        'badge'=>'',
        'featured'=>false,
    ],
    [
        'name' =>'Full Service + MOT',
        'price'=>'£229',
        'features'=>[
            'All Basic Service items',
            'Cabin / pollen filter',
            'Spark plug inspection',
            'Brake fluid test',
            'Battery health check',
            'MOT test included',
            'Free MOT retest',
        ],
        'badge'=>'BEST VALUE',
        'featured'=>true,
    ],
    [
        'name' =>'Premium Service',
        'price'=>'£349',
        'features'=>[
            'All Full Service items',
            'Spark plug replacement',
            'Coolant flush',
            'Transmission fluid check',
            'Driveshaft & CV boots',
            'Suspension inspection',
            'Digital health report',
            'Courtesy car included',
        ],
        'badge'=>'',
        'featured'=>false,
    ],
];

$team = [
    ['name'=>'Declan O\'Reilly', 'role'=>'Master Technician',         'certs'=>'IMI Level 4, City & Guilds, EV Ready'],
    ['name'=>'Sanjay Malik',     'role'=>'MOT Tester & Diagnostics',  'certs'=>'Class 4 & 7 MOT Tester, OBD Specialist'],
    ['name'=>'Tyler Shaw',       'role'=>'Bodywork & Paint Specialist','certs'=>'Thatcham SMART, ATA Accredited'],
    ['name'=>'Priya Anand',      'role'=>'Service Advisor & Manager', 'certs'=>'ATA Accredited, Customer Service NVQ'],
];

$testimonials = [
    ['text'=>'Absolute legends. Diagnosed a fault three other garages missed, fixed it same day and charged me less than half what I expected. My go-to for everything from now on.','name'=>'Jamie Harrington','tag'=>'BMW 3 Series owner'],
    ['text'=>'Had my MOT, service and 4-wheel alignment done in a morning. Friendly staff, spotless workshop, digital health report sent to my phone within an hour. Can\'t fault them.','name'=>'Anita Reddy','tag'=>'Toyota RAV4 owner'],
    ['text'=>'Clutch gave up on the M25. Breakdown, tow, diagnosis and repair — all done the same week. The team were honest, transparent and genuinely went the extra mile.','name'=>'Marcus Webb','tag'=>'VW Golf R owner'],
];

$faqs = [
    ['q'=>'Do you offer a collection and delivery service?','a'=>'Yes — we offer a free collection and delivery service within a 10-mile radius for all booked services. Simply let us know when you make your appointment and we\'ll arrange a convenient time.'],
    ['q'=>'Do you provide a courtesy car?','a'=>'Courtesy cars are available with our Premium Service package and for repairs expected to take longer than one working day. Subject to availability — please request when booking.'],
    ['q'=>'Are your parts genuine or OEM?','a'=>'We use genuine manufacturer parts wherever possible, and OE-equivalent (Original Equipment Manufacturer) parts where genuine parts are not required. We will always discuss options with you before ordering.'],
    ['q'=>'How long does an MOT take?','a'=>'An MOT takes approximately 45–60 minutes. If you\'ve booked a service at the same time, we can often complete both simultaneously, saving you time.'],
    ['q'=>'Do you work on electric and hybrid vehicles?','a'=>'Yes — all our technicians are EV-ready certified and we have the specialist equipment required for high-voltage systems, regenerative braking and battery diagnostics. We work on all EV and hybrid makes.'],
];

/* ── PHP hero assets ─────────────────────────────────────── */

// Roller shutter door slats
$shutter_slats = 22;

// Oil stain positions
$oil_stains = [];
for ($i = 0; $i < 8; $i++) {
    $oil_stains[] = [
        'x'    => rand(5, 85),
        'size' => rand(30, 80),
        'op'   => rand(4, 14),
        'rx'   => rand(80, 140),
        'ry'   => rand(20, 50),
    ];
}

// Tool silhouettes on rack
$tools = [
    ['type'=>'wrench',   'left'=>8,  'h'=>56],
    ['type'=>'spanner',  'left'=>16, 'h'=>48],
    ['type'=>'socket',   'left'=>24, 'h'=>36],
    ['type'=>'wrench',   'left'=>30, 'h'=>52],
    ['type'=>'hammer',   'left'=>38, 'h'=>44],
    ['type'=>'wrench',   'left'=>46, 'h'=>60],
    ['type'=>'screwdr',  'left'=>54, 'h'=>50],
    ['type'=>'wrench',   'left'=>62, 'h'=>48],
    ['type'=>'spanner',  'left'=>70, 'h'=>44],
    ['type'=>'socket',   'left'=>78, 'h'=>38],
    ['type'=>'hammer',   'left'=>86, 'h'=>42],
];

// Headlight beam particles
$beam_particles = [];
for ($i = 0; $i < 12; $i++) {
    $beam_particles[] = [
        'x'     => rand(0, 30),
        'y'     => rand(25, 70),
        'size'  => rand(2, 6),
        'op'    => rand(15, 40),
        'delay' => rand(0, 3000),
        'dur'   => rand(2000, 5000),
    ];
}

?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@300;400;500;600;700&family=Roboto:ital,wght@0,300;0,400;0,700;1,300&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════
   GARAGE – AUTO REPAIR & CAR WORKSHOP
   Namespace: --grg-*
═══════════════════════════════════════════════ */
:root{
  --grg-steel:#1a1f28;
  --grg-iron:#252c38;
  --grg-chrome:#3a4455;
  --grg-mid:#4a5568;
  --grg-red:#c8281e;
  --grg-red-lt:#e83020;
  --grg-orange:#e87820;
  --grg-yellow:#f0c020;
  --grg-silver:#d0d8e0;
  --grg-white:#f4f6f8;
  --grg-r:6px;
  --grg-ff-head:'Oswald',sans-serif;
  --grg-ff-body:'Roboto',sans-serif;
}

*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}

.grg-page{
  background:var(--grg-steel);
  color:var(--grg-silver);
  font-family:var(--grg-ff-body);
  font-size:16px;
  line-height:1.7;
  overflow-x:hidden;
}

/* ── NAV ─────────────────────────────────────── */
.grg-nav{
  position:fixed;top:0;left:0;right:0;z-index:1000;
  display:flex;align-items:center;justify-content:space-between;
  padding:0 48px;height:70px;
  background:rgba(26,31,40,.97);
  border-bottom:3px solid var(--grg-red);
  backdrop-filter:blur(8px);
}
.grg-nav-logo{
  font-family:var(--grg-ff-head);
  font-size:24px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
  color:var(--grg-white);text-decoration:none;
}
.grg-nav-logo span{color:var(--grg-red);}
.grg-nav-links{display:flex;gap:32px;list-style:none;}
.grg-nav-links a{
  color:rgba(244,246,248,.65);text-decoration:none;
  font-size:13px;font-weight:500;letter-spacing:.06em;text-transform:uppercase;
  transition:color .2s;
}
.grg-nav-links a:hover{color:var(--grg-yellow);}
.grg-nav-cta{
  display:inline-flex;align-items:center;gap:8px;
  padding:11px 24px;
  background:var(--grg-red);color:var(--grg-white);
  font-family:var(--grg-ff-head);font-size:15px;font-weight:600;letter-spacing:.06em;
  text-decoration:none;border-radius:var(--grg-r);
  transition:background .2s;
}
.grg-nav-cta:hover{background:var(--grg-red-lt);}

/* ── HERO ─────────────────────────────────────── */
.grg-hero{
  position:relative;min-height:100vh;
  display:flex;align-items:center;
  overflow:hidden;
  background:linear-gradient(180deg,
    #0e1118 0%,
    #141820 30%,
    #1a2030 60%,
    #0e1018 100%
  );
}

/* Concrete floor */
.grg-floor{
  position:absolute;bottom:0;left:0;right:0;
  height:200px;
  background:
    repeating-linear-gradient(
      90deg,
      transparent 0px,transparent 99px,
      rgba(255,255,255,.03) 99px,rgba(255,255,255,.03) 100px
    ),
    repeating-linear-gradient(
      0deg,
      transparent 0px,transparent 49px,
      rgba(255,255,255,.02) 49px,rgba(255,255,255,.02) 50px
    ),
    linear-gradient(180deg,#1e2430,#141820);
}

/* Oil stains */
.grg-oil-stain{
  position:absolute;
  border-radius:50%;
  background:rgba(0,0,0,.8);
  filter:blur(8px);
  pointer-events:none;
}

/* Back wall */
.grg-wall{
  position:absolute;top:70px;left:0;right:0;bottom:200px;
  background:linear-gradient(180deg,#181e28,#1e2430);
}
.grg-wall::before{
  content:'';position:absolute;inset:0;
  background:repeating-linear-gradient(
    90deg,
    transparent 0px,transparent 59px,
    rgba(255,255,255,.02) 59px,rgba(255,255,255,.02) 60px
  );
}

/* Roller shutter door */
.grg-shutter{
  position:absolute;
  top:70px;left:50%;transform:translateX(-50%);
  width:340px;bottom:200px;
  overflow:hidden;
  border:4px solid #2a3040;
  box-shadow:0 0 30px rgba(0,0,0,.5);
}
.grg-shutter-slat{
  height:18px;
  background:linear-gradient(180deg,#2e3848,#242e3a);
  border-bottom:2px solid #1a2030;
  position:relative;
}
.grg-shutter-slat::before{
  content:'';position:absolute;
  top:4px;left:0;right:0;height:4px;
  background:rgba(255,255,255,.04);
}
/* Window in shutter top */
.grg-shutter-window{
  position:absolute;
  top:70px;left:50%;transform:translateX(-50%);
  width:200px;height:80px;
  background:rgba(232,168,20,.06);
  border:2px solid #2a3040;
  z-index:2;
  display:flex;align-items:center;justify-content:center;
}
.grg-shutter-window::before,
.grg-shutter-window::after{
  content:'';position:absolute;
  background:#2a3040;
}
.grg-shutter-window::before{width:2px;height:100%;}
.grg-shutter-window::after{width:100%;height:2px;}

/* Neon sign */
.grg-neon{
  position:absolute;
  top:90px;right:80px;
  font-family:var(--grg-ff-head);
  font-size:28px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;
  color:var(--grg-red);
  text-shadow:
    0 0 6px var(--grg-red),
    0 0 14px var(--grg-red),
    0 0 30px rgba(200,40,30,.4);
  animation:grg-neon-flicker 4s ease-in-out infinite;
  pointer-events:none;
}
@keyframes grg-neon-flicker{
  0%,18%,20%,50%,52%,64%,66%,95%,98%,100%{
    text-shadow:0 0 6px var(--grg-red),0 0 14px var(--grg-red),0 0 30px rgba(200,40,30,.4);
    opacity:1;
  }
  19%,51%,65%{
    text-shadow:none;opacity:.6;
  }
}

/* OPEN sign */
.grg-open-sign{
  position:absolute;
  top:138px;right:80px;
  padding:5px 14px;
  background:var(--grg-yellow);
  font-family:var(--grg-ff-head);
  font-size:14px;font-weight:700;letter-spacing:.12em;
  color:var(--grg-steel);
  border-radius:3px;
  box-shadow:0 0 10px rgba(240,192,32,.4);
}

/* Tool rack on left wall */
.grg-tool-rack{
  position:absolute;
  top:100px;left:40px;
  width:120px;height:220px;
}
/* Rack panel */
.grg-tool-rack::before{
  content:'';position:absolute;inset:0;
  background:linear-gradient(180deg,#2a3040,#1e2830);
  border:2px solid #3a4455;
  border-radius:4px;
}
/* Horizontal rail */
.grg-tool-rack::after{
  content:'';position:absolute;
  top:28px;left:0;right:0;height:6px;
  background:linear-gradient(90deg,#4a5060,#3a4050);
  box-shadow:0 40px 0 #3a4050,0 80px 0 #3a4050,0 120px 0 #3a4050;
}
.grg-tool{
  position:absolute;
  bottom:10px;
  background:linear-gradient(160deg,#9090a0,#606070);
  border-radius:2px;
}
.grg-tool.wrench{width:4px;}
.grg-tool.wrench::before{
  content:'';position:absolute;
  top:0;left:-3px;
  width:10px;height:10px;
  border-radius:50%;
  background:linear-gradient(160deg,#a0a0b0,#606070);
  border:2px solid transparent;
}
.grg-tool.hammer{width:6px;}
.grg-tool.hammer::before{
  content:'';position:absolute;
  top:0;left:-6px;
  width:18px;height:12px;
  border-radius:3px;
  background:linear-gradient(160deg,#a0a0b0,#707080);
}
.grg-tool.socket{width:8px;border-radius:50%;}

/* Tyre stack */
.grg-tyres{
  position:absolute;
  bottom:200px;right:40px;
}
.grg-tyre{
  width:80px;height:22px;
  border-radius:50%;
  background:radial-gradient(ellipse at 50% 30%,#2a2a2a,#0a0a0a);
  border:8px solid #1a1a1a;
  box-shadow:0 -2px 6px rgba(0,0,0,.4),inset 0 2px 4px rgba(255,255,255,.05);
  margin-bottom:-6px;
}

/* Car silhouette on lift */
.grg-lift-scene{
  position:absolute;
  bottom:200px;left:50%;transform:translateX(-50%);
  width:380px;
  pointer-events:none;
}

/* Lift platform */
.grg-lift-platform{
  position:absolute;
  bottom:0;left:0;right:0;
  height:16px;
  background:linear-gradient(90deg,#3a4050,#4a5060,#3a4050);
  border-radius:4px;
  box-shadow:0 4px 10px rgba(0,0,0,.5);
}
/* Lift arm */
.grg-lift-arm{
  position:absolute;
  bottom:16px;
  width:12px;
  background:linear-gradient(180deg,#3a4050,#2a3040);
  border-radius:6px 6px 0 0;
}
.grg-lift-arm.left{left:20%;height:80px;}
.grg-lift-arm.right{right:20%;height:80px;}

/* Car body (generic sedan silhouette) */
.grg-car-body{
  position:absolute;
  bottom:16px;left:0;right:0;
}
/* Chassis */
.grg-car-chassis{
  position:absolute;
  bottom:0;left:10px;right:10px;
  height:56px;
  background:linear-gradient(180deg,var(--grg-red),#a01810);
  border-radius:4px 4px 2px 2px;
  box-shadow:0 4px 16px rgba(200,40,30,.25);
}
/* Cabin */
.grg-car-cabin{
  position:absolute;
  bottom:56px;left:80px;right:80px;
  height:52px;
  background:linear-gradient(160deg,#d02010,#901010);
  border-radius:20px 20px 0 0;
}
/* Windscreen */
.grg-car-cabin::before{
  content:'';position:absolute;
  top:10px;left:14px;right:14px;bottom:0;
  background:rgba(140,180,220,.15);
  border-radius:14px 14px 0 0;
  border:1px solid rgba(255,255,255,.1);
}
/* Headlights */
.grg-car-headlight{
  position:absolute;
  bottom:18px;
  width:28px;height:16px;
  border-radius:3px;
  background:linear-gradient(90deg,rgba(240,220,100,.8),rgba(240,240,200,.6));
  box-shadow:0 0 14px rgba(240,200,80,.5);
}
.grg-car-headlight.left{left:10px;}
.grg-car-headlight.right{right:10px;}
/* Tail lights */
.grg-car-taillight{
  position:absolute;
  top:18px;
  width:24px;height:14px;
  border-radius:3px;
  background:rgba(200,40,30,.9);
  box-shadow:0 0 10px rgba(200,40,30,.5);
}
.grg-car-taillight.left{left:10px;}
.grg-car-taillight.right{right:10px;}
/* Wheels (underneath chassis on lift) */
.grg-car-wheel{
  position:absolute;bottom:-10px;
  width:36px;height:36px;border-radius:50%;
  background:radial-gradient(circle at 40% 35%,#3a3a3a,#0a0a0a);
  border:4px solid #1a1a1a;
  box-shadow:inset 0 0 8px rgba(255,255,255,.05),0 4px 8px rgba(0,0,0,.4);
}
.grg-car-wheel.fl{left:28px;}
.grg-car-wheel.fr{right:28px;}
.grg-car-wheel.rl{left:80px;}
.grg-car-wheel.rr{right:80px;}
/* Wheel rim */
.grg-car-wheel::before{
  content:'';position:absolute;
  top:50%;left:50%;transform:translate(-50%,-50%);
  width:14px;height:14px;border-radius:50%;
  background:radial-gradient(circle at 40% 35%,#8090a0,#5060708);
}

/* Headlight beam (from car) */
.grg-headbeam{
  position:absolute;
  bottom:236px;left:38px;
  width:200px;height:60px;
  clip-path:polygon(0 40%,100% 0%,100% 100%,0 60%);
  background:linear-gradient(90deg,rgba(240,220,80,.2) 0%,transparent 90%);
  pointer-events:none;
}
.grg-headbeam-dot{
  position:absolute;
  border-radius:50%;
  background:rgba(240,220,120,.8);
  pointer-events:none;
  animation:grg-dust-float linear infinite;
}
@keyframes grg-dust-float{
  0%{transform:translateY(0);opacity:.6}
  100%{transform:translateY(-30px);opacity:0}
}

/* Workshop light bars (ceiling) */
.grg-strip-light{
  position:absolute;
  top:70px;
  height:12px;
  background:linear-gradient(180deg,rgba(255,255,255,.05),rgba(255,255,255,.02));
  border-radius:4px;
}
.grg-strip-light::after{
  content:'';position:absolute;
  top:12px;left:10%;right:10%;
  height:100px;
  background:linear-gradient(180deg,rgba(255,255,255,.08),transparent);
  clip-path:polygon(0% 0%,100% 0%,90% 100%,10% 100%);
}

/* Hero overlay */
.grg-hero-overlay{
  position:absolute;inset:0;
  background:linear-gradient(
    100deg,
    rgba(26,31,40,.8) 0%,
    rgba(26,31,40,.5) 40%,
    rgba(26,31,40,.15) 65%,
    rgba(26,31,40,.6) 100%
  );
}

/* Hero content */
.grg-hero-content{
  position:relative;z-index:10;
  max-width:660px;
  padding:130px 48px 80px;
}
.grg-hero-eyebrow{
  display:inline-flex;align-items:center;gap:10px;
  font-size:12px;font-weight:500;letter-spacing:.14em;text-transform:uppercase;
  color:var(--grg-yellow);margin-bottom:20px;
}
.grg-hero-eyebrow::before{
  content:'';display:block;width:30px;height:3px;
  border-radius:2px;background:var(--grg-red);
}
.grg-hero-h1{
  font-family:var(--grg-ff-head);
  font-size:clamp(60px,9vw,110px);
  font-weight:700;line-height:.95;
  letter-spacing:.03em;text-transform:uppercase;
  color:var(--grg-white);margin-bottom:24px;
}
.grg-hero-h1 span{color:var(--grg-red);}
.grg-hero-sub{
  font-size:17px;font-weight:300;line-height:1.7;
  color:rgba(208,216,224,.75);
  max-width:480px;margin-bottom:40px;
}
.grg-hero-actions{display:flex;gap:14px;flex-wrap:wrap;margin-bottom:36px;}
.grg-btn-primary{
  display:inline-flex;align-items:center;gap:8px;
  padding:16px 36px;
  background:var(--grg-red);color:var(--grg-white);
  font-family:var(--grg-ff-head);font-size:19px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;
  text-decoration:none;border-radius:var(--grg-r);
  transition:background .2s,transform .15s;
}
.grg-btn-primary:hover{background:var(--grg-red-lt);transform:translateY(-2px);}
.grg-btn-outline{
  display:inline-flex;align-items:center;gap:8px;
  padding:15px 32px;
  border:2px solid rgba(208,216,224,.3);
  color:var(--grg-silver);
  font-family:var(--grg-ff-head);font-size:19px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;
  text-decoration:none;border-radius:var(--grg-r);
  transition:border-color .2s,color .2s;
}
.grg-btn-outline:hover{border-color:var(--grg-yellow);color:var(--grg-yellow);}
.grg-hero-badges{
  display:flex;gap:16px;flex-wrap:wrap;
}
.grg-hero-badge{
  display:flex;align-items:center;gap:6px;
  font-size:12px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
  color:rgba(208,216,224,.55);
}
.grg-hero-badge-check{
  color:var(--grg-yellow);font-size:14px;
}

/* ── SECTION BASE ─────────────────────────────── */
.grg-section{padding:100px 48px;max-width:1320px;margin:0 auto;}
.grg-label{
  display:inline-flex;align-items:center;gap:10px;
  font-size:11px;font-weight:700;letter-spacing:.16em;text-transform:uppercase;
  color:var(--grg-red);margin-bottom:12px;
}
.grg-label::before{
  content:'';display:block;width:28px;height:3px;
  border-radius:2px;background:var(--grg-red);
}
.grg-h2{
  font-family:var(--grg-ff-head);
  font-size:clamp(42px,6vw,70px);
  font-weight:700;letter-spacing:.04em;text-transform:uppercase;
  color:var(--grg-white);margin-bottom:16px;
}
.grg-h2 span{color:var(--grg-red);}
.grg-lead{
  font-size:17px;font-weight:300;color:rgba(208,216,224,.65);
  max-width:580px;line-height:1.75;margin-bottom:60px;
}

/* ── STATS ────────────────────────────────────── */
.grg-stats-bg{
  background:var(--grg-red);
  padding:48px;
}
.grg-stats-inner{
  max-width:1100px;margin:0 auto;
  display:grid;grid-template-columns:repeat(4,1fr);gap:0;
  text-align:center;
}
.grg-stat{
  padding:0 24px;
  border-right:1px solid rgba(255,255,255,.2);
}
.grg-stat:last-child{border-right:none;}
.grg-stat-val{
  font-family:var(--grg-ff-head);
  font-size:clamp(52px,7vw,80px);
  font-weight:700;
  color:var(--grg-white);letter-spacing:.02em;
}
.grg-stat-suf{font-size:.55em;vertical-align:.12em;}
.grg-stat-lbl{
  font-size:12px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;
  color:rgba(255,255,255,.7);margin-top:6px;
}

/* ── SERVICES ─────────────────────────────────── */
.grg-services-bg{
  background:var(--grg-iron);
  padding:100px 48px;
}
.grg-services-inner{max-width:1280px;margin:0 auto;}
.grg-services-grid{
  display:grid;grid-template-columns:repeat(4,1fr);gap:24px;
  margin-top:60px;
}
.grg-service-card{
  background:var(--grg-steel);
  border:1px solid rgba(58,68,85,.8);
  border-radius:var(--grg-r);
  padding:36px 28px;
  transition:border-color .25s,transform .2s,box-shadow .2s;
  position:relative;overflow:hidden;
}
.grg-service-card:hover{
  border-color:var(--grg-red);
  transform:translateY(-5px);
  box-shadow:0 12px 32px rgba(0,0,0,.3);
}
.grg-service-card::after{
  content:'';position:absolute;
  bottom:0;left:0;right:0;height:3px;
  background:var(--grg-red);
  transform:scaleX(0);transform-origin:left;
  transition:transform .3s;
}
.grg-service-card:hover::after{transform:scaleX(1);}
.grg-svc-icon{
  font-size:24px;color:var(--grg-red);
  margin-bottom:16px;display:block;
}
.grg-svc-name{
  font-family:var(--grg-ff-head);
  font-size:20px;font-weight:600;text-transform:uppercase;
  color:var(--grg-white);margin-bottom:6px;letter-spacing:.04em;
}
.grg-svc-price{
  font-size:13px;font-weight:700;color:var(--grg-yellow);
  margin-bottom:12px;
}
.grg-svc-desc{
  font-size:13px;color:rgba(208,216,224,.6);line-height:1.6;
  margin-bottom:12px;
}
.grg-svc-time{
  font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
  color:rgba(208,216,224,.35);
}

/* ── PACKAGES ─────────────────────────────────── */
.grg-packages-grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:28px;
  margin-top:60px;
}
.grg-pkg-card{
  background:var(--grg-iron);
  border:1px solid rgba(58,68,85,.8);
  border-radius:var(--grg-r);
  padding:48px 36px;
  position:relative;
  transition:border-color .25s,transform .2s;
}
.grg-pkg-card:hover{transform:translateY(-5px);}
.grg-pkg-card.featured{
  border-color:var(--grg-red);
  background:linear-gradient(160deg,#2a1a18,var(--grg-iron));
}
.grg-pkg-badge{
  position:absolute;top:-1px;left:50%;transform:translateX(-50%);
  padding:5px 18px;
  background:var(--grg-red);
  font-family:var(--grg-ff-head);
  font-size:12px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;
  color:var(--grg-white);
  white-space:nowrap;
}
.grg-pkg-name{
  font-family:var(--grg-ff-head);
  font-size:26px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;
  color:var(--grg-white);margin-bottom:16px;
}
.grg-pkg-price{
  font-family:var(--grg-ff-head);
  font-size:56px;font-weight:700;letter-spacing:-.01em;
  color:var(--grg-yellow);line-height:1;margin-bottom:24px;
}
.grg-pkg-divider{
  width:36px;height:3px;border-radius:2px;
  background:var(--grg-red);margin-bottom:24px;
}
.grg-pkg-features{list-style:none;display:flex;flex-direction:column;gap:10px;margin-bottom:32px;}
.grg-pkg-features li{
  font-size:14px;color:rgba(208,216,224,.75);
  display:flex;align-items:center;gap:10px;
}
.grg-pkg-features li::before{
  content:'✓';color:var(--grg-yellow);font-weight:700;flex-shrink:0;
}
.grg-pkg-btn{
  display:block;text-align:center;
  padding:14px 24px;
  background:transparent;
  border:2px solid rgba(208,216,224,.2);
  color:var(--grg-silver);
  font-family:var(--grg-ff-head);font-size:17px;font-weight:600;
  letter-spacing:.06em;text-transform:uppercase;
  text-decoration:none;border-radius:var(--grg-r);
  transition:background .2s,border-color .2s,color .2s;
}
.grg-pkg-btn:hover,
.grg-pkg-card.featured .grg-pkg-btn{
  background:var(--grg-red);border-color:var(--grg-red);color:var(--grg-white);
}

/* ── TEAM ─────────────────────────────────────── */
.grg-team-bg{
  background:var(--grg-iron);
  padding:100px 48px;
}
.grg-team-inner{max-width:1200px;margin:0 auto;}
.grg-team-grid{
  display:grid;grid-template-columns:repeat(4,1fr);gap:24px;
  margin-top:60px;
}
.grg-team-card{
  background:var(--grg-steel);
  border-radius:var(--grg-r);
  overflow:hidden;
  border:1px solid rgba(58,68,85,.8);
  transition:transform .2s;
}
.grg-team-card:hover{transform:translateY(-5px);}
.grg-team-portrait{
  height:200px;
  position:relative;
  background:linear-gradient(145deg,var(--grg-chrome),var(--grg-steel));
  display:flex;align-items:flex-end;justify-content:center;
  overflow:hidden;
}

/* CSS mechanic figure */
.grg-mech-fig{
  position:relative;width:80px;height:170px;
}
.grg-mech-body{
  position:absolute;bottom:0;left:50%;transform:translateX(-50%);
  width:58px;height:110px;
  border-radius:6px 6px 3px 3px;
  background:linear-gradient(160deg,#3a4858,#282e38);
}
/* Coverall bib */
.grg-mech-body::before{
  content:'';position:absolute;
  top:0;left:50%;transform:translateX(-50%);
  width:24px;height:50px;
  background:linear-gradient(180deg,#e87820,#c85810);
  border-radius:3px;
}
/* Tool pocket */
.grg-mech-body::after{
  content:'';position:absolute;
  top:60px;left:8px;
  width:18px;height:20px;
  background:rgba(0,0,0,.2);
  border-radius:2px;
  border:1px solid rgba(255,255,255,.05);
}
.grg-mech-head{
  position:absolute;
  bottom:108px;left:50%;transform:translateX(-50%);
  width:34px;height:36px;border-radius:50%;
  background:radial-gradient(circle at 38% 32%,#d4a870,#b08040);
}
/* Helmet */
.grg-mech-helmet{
  position:absolute;
  bottom:136px;left:50%;transform:translateX(-50%);
}
.grg-mech-helmet::before{
  content:'';display:block;
  width:44px;height:22px;
  border-radius:22px 22px 0 0;
  background:linear-gradient(180deg,#f0c020,#c09010);
  position:absolute;top:-22px;left:50%;transform:translateX(-50%);
}
.grg-mech-helmet::after{
  content:'';display:block;
  width:50px;height:8px;
  background:linear-gradient(90deg,#c09010,#e0b020,#c09010);
  border-radius:3px;
  position:absolute;top:0;left:50%;transform:translateX(-50%);
}
/* Wrench in hand */
.grg-mech-wrench{
  position:absolute;
  bottom:60px;left:calc(50% + 22px);
  width:5px;height:44px;
  background:linear-gradient(90deg,#8090a0,#a0b0c0);
  border-radius:3px;
  transform:rotate(-20deg);
}
.grg-mech-wrench::before{
  content:'';position:absolute;
  top:-4px;left:-5px;
  width:15px;height:14px;
  border:4px solid #a0b0c0;
  border-radius:50%;
}

.grg-team-info{padding:22px;}
.grg-team-name{
  font-family:var(--grg-ff-head);font-size:20px;font-weight:600;text-transform:uppercase;
  color:var(--grg-white);margin-bottom:4px;letter-spacing:.04em;
}
.grg-team-role{
  font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;
  color:var(--grg-red);margin-bottom:8px;
}
.grg-team-certs{
  font-size:12px;color:rgba(208,216,224,.45);line-height:1.5;
}

/* ── TESTIMONIALS ─────────────────────────────── */
.grg-testi-grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:24px;
  margin-top:60px;
}
.grg-testi-card{
  background:var(--grg-iron);
  border-radius:var(--grg-r);
  padding:36px 28px;
  border-left:4px solid var(--grg-red);
  position:relative;
}
.grg-testi-stars{color:var(--grg-yellow);font-size:14px;letter-spacing:2px;margin-bottom:12px;}
.grg-testi-text{
  font-size:15px;font-style:italic;color:rgba(208,216,224,.8);
  line-height:1.7;margin-bottom:18px;
}
.grg-testi-name{font-weight:700;font-size:14px;color:var(--grg-white);}
.grg-testi-tag{font-size:12px;color:var(--grg-orange);margin-top:2px;}

/* ── FAQ ──────────────────────────────────────── */
.grg-faq-list{max-width:820px;margin:60px auto 0;}
.grg-faq-item{border-bottom:1px solid rgba(58,68,85,.8);}
.grg-faq-q{
  width:100%;background:none;border:none;cursor:pointer;
  display:flex;justify-content:space-between;align-items:center;
  padding:22px 0;gap:24px;
  font-family:var(--grg-ff-head);
  font-size:18px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;
  color:var(--grg-silver);text-align:left;
}
.grg-faq-q:hover{color:var(--grg-yellow);}
.grg-faq-icon{
  flex-shrink:0;width:28px;height:28px;
  background:rgba(200,40,30,.15);border:1px solid rgba(200,40,30,.3);
  display:flex;align-items:center;justify-content:center;
  font-size:18px;color:var(--grg-red);
  transition:transform .25s,background .2s;border-radius:3px;
}
.grg-faq-item.open .grg-faq-icon{transform:rotate(45deg);background:var(--grg-red);color:var(--grg-white);}
.grg-faq-a{max-height:0;overflow:hidden;transition:max-height .35s ease;}
.grg-faq-a-inner{
  padding:0 0 22px;
  font-size:15px;color:rgba(208,216,224,.6);line-height:1.7;
}

/* ── BOOKING FORM ─────────────────────────────── */
.grg-booking-bg{
  background:linear-gradient(135deg,var(--grg-iron),var(--grg-steel));
  padding:100px 48px;
}
.grg-booking-inner{
  max-width:700px;margin:0 auto;
  background:var(--grg-chrome);
  border:1px solid rgba(200,40,30,.25);
  border-top:4px solid var(--grg-red);
  border-radius:var(--grg-r);
  padding:60px;
}
.grg-form-grid{
  display:grid;grid-template-columns:1fr 1fr;gap:22px;
  margin-top:36px;
}
.grg-form-group{display:flex;flex-direction:column;gap:7px;}
.grg-form-group.full{grid-column:1/-1;}
.grg-form-label{
  font-size:11px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;
  color:rgba(208,216,224,.5);
}
.grg-form-input,
.grg-form-select,
.grg-form-textarea{
  background:rgba(255,255,255,.05);
  border:1px solid rgba(58,68,85,1);
  border-radius:var(--grg-r);
  padding:13px 16px;
  color:var(--grg-white);
  font-family:var(--grg-ff-body);font-size:15px;
  transition:border-color .2s;
}
.grg-form-input:focus,
.grg-form-select:focus,
.grg-form-textarea:focus{
  outline:none;border-color:var(--grg-red);
}
.grg-form-select{appearance:none;cursor:pointer;}
.grg-form-textarea{resize:vertical;min-height:90px;}
.grg-form-submit{
  margin-top:24px;width:100%;
  padding:18px;
  background:var(--grg-red);color:var(--grg-white);
  font-family:var(--grg-ff-head);font-size:20px;font-weight:700;
  letter-spacing:.08em;text-transform:uppercase;
  border:none;border-radius:var(--grg-r);cursor:pointer;
  transition:background .2s,transform .15s;
}
.grg-form-submit:hover{background:var(--grg-red-lt);transform:translateY(-2px);}

/* ── FOOTER ───────────────────────────────────── */
.grg-footer{
  background:var(--grg-steel);
  border-top:3px solid var(--grg-red);
  padding:64px 48px 32px;
}
.grg-footer-inner{
  max-width:1200px;margin:0 auto;
  display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:48px;
  padding-bottom:48px;
  border-bottom:1px solid rgba(58,68,85,.8);
}
.grg-footer-brand{
  font-family:var(--grg-ff-head);font-size:24px;font-weight:700;
  text-transform:uppercase;letter-spacing:.06em;
  color:var(--grg-white);margin-bottom:12px;
}
.grg-footer-brand span{color:var(--grg-red);}
.grg-footer-desc{
  font-size:14px;color:rgba(208,216,224,.45);
  line-height:1.7;max-width:260px;
}
.grg-footer-col-title{
  font-family:var(--grg-ff-head);font-size:15px;font-weight:600;
  text-transform:uppercase;letter-spacing:.08em;
  color:var(--grg-red);margin-bottom:16px;
}
.grg-footer-list{list-style:none;display:flex;flex-direction:column;gap:10px;}
.grg-footer-list a{
  color:rgba(208,216,224,.45);text-decoration:none;font-size:14px;
  transition:color .2s;
}
.grg-footer-list a:hover{color:var(--grg-yellow);}
.grg-footer-bottom{
  max-width:1200px;margin:28px auto 0;
  display:flex;justify-content:space-between;align-items:center;
  font-size:12px;color:rgba(208,216,224,.25);
}
.grg-footer-bottom a{color:rgba(208,216,224,.3);text-decoration:none;}
.grg-footer-bottom a:hover{color:var(--grg-red);}

/* Responsive */
@media(max-width:1100px){
  .grg-services-grid{grid-template-columns:repeat(2,1fr);}
  .grg-packages-grid{grid-template-columns:1fr;}
  .grg-team-grid{grid-template-columns:repeat(2,1fr);}
  .grg-testi-grid{grid-template-columns:1fr;}
  .grg-footer-inner{grid-template-columns:1fr 1fr;}
}
@media(max-width:768px){
  .grg-nav-links,.grg-nav-cta{display:none;}
  .grg-hero-content{padding:110px 24px 60px;}
  .grg-section,.grg-services-bg,.grg-team-bg,.grg-booking-bg,.grg-footer{padding-left:24px;padding-right:24px;}
  .grg-stats-inner{grid-template-columns:repeat(2,1fr);}
  .grg-services-grid{grid-template-columns:1fr;}
  .grg-team-grid{grid-template-columns:1fr;}
  .grg-form-grid{grid-template-columns:1fr;}
  .grg-booking-inner{padding:36px 24px;}
  .grg-lift-scene,.grg-tool-rack,.grg-tyres,.grg-neon,.grg-open-sign{display:none;}
}
</style>
<?php get_header(); ?>
<div class="grg-page">
>

<!-- NAV -->
<nav class="grg-nav" role="navigation" aria-label="Main navigation">
  <a href="<?php echo esc_url(home_url('/')); ?>" class="grg-nav-logo">
    Iron<span>Gate</span> Garage
  </a>
  <ul class="grg-nav-links">
    <li><a href="#services">Services</a></li>
    <li><a href="#packages">Packages</a></li>
    <li><a href="#team">Team</a></li>
    <li><a href="#faq">FAQ</a></li>
    <li><a href="#booking">Book</a></li>
  </ul>
  <a href="#booking" class="grg-nav-cta">Book Online</a>
</nav>

<!-- HERO -->
<header class="grg-hero" role="banner">

  <!-- Room -->
  <div class="grg-wall" aria-hidden="true"></div>
  <div class="grg-floor" aria-hidden="true"></div>

  <!-- Oil stains on floor -->
  <?php foreach($oil_stains as $os): ?>
  <div class="grg-oil-stain" aria-hidden="true" style="
    left:<?php echo $os['x']; ?>%;
    bottom:<?php echo rand(10, 80); ?>px;
    width:<?php echo $os['rx']; ?>px;
    height:<?php echo $os['ry']; ?>px;
    opacity:<?php echo number_format($os['op']/100,2); ?>;
  "></div>
  <?php endforeach; ?>

  <!-- Strip lights -->
  <div class="grg-strip-light" aria-hidden="true" style="left:15%;width:22%;"></div>
  <div class="grg-strip-light" aria-hidden="true" style="left:42%;width:18%;"></div>
  <div class="grg-strip-light" aria-hidden="true" style="right:12%;width:20%;"></div>

  <!-- Shutter door -->
  <div class="grg-shutter" aria-hidden="true">
    <?php for($s=0;$s<$shutter_slats;$s++): ?>
    <div class="grg-shutter-slat"></div>
    <?php endfor; ?>
  </div>
  <div class="grg-shutter-window" aria-hidden="true"></div>

  <!-- Neon sign -->
  <div class="grg-neon" aria-hidden="true">OPEN 7 DAYS</div>
  <div class="grg-open-sign" aria-hidden="true">MOT &amp; SERVICE</div>

  <!-- Tool rack -->
  <div class="grg-tool-rack" aria-hidden="true">
    <?php foreach($tools as $tl): ?>
    <div class="grg-tool <?php echo esc_attr($tl['type']); ?>" style="
      left:<?php echo $tl['left']; ?>%;
      height:<?php echo $tl['h']; ?>px;
    "></div>
    <?php endforeach; ?>
  </div>

  <!-- Car on lift -->
  <div class="grg-lift-scene" aria-hidden="true">
    <div class="grg-lift-platform"></div>
    <div class="grg-lift-arm left"></div>
    <div class="grg-lift-arm right"></div>
    <div class="grg-car-body">
      <div class="grg-car-chassis">
        <div class="grg-car-headlight left"></div>
        <div class="grg-car-headlight right"></div>
        <div class="grg-car-taillight left"></div>
        <div class="grg-car-taillight right"></div>
      </div>
      <div class="grg-car-cabin"></div>
      <div class="grg-car-wheel fl"></div>
      <div class="grg-car-wheel fr"></div>
      <div class="grg-car-wheel rl"></div>
      <div class="grg-car-wheel rr"></div>
    </div>
  </div>

  <!-- Headlight beam -->
  <div class="grg-headbeam" aria-hidden="true">
    <?php foreach($beam_particles as $bp): ?>
    <div class="grg-headbeam-dot" style="
      left:<?php echo $bp['x']; ?>%;
      top:<?php echo $bp['y']; ?>%;
      width:<?php echo $bp['size']; ?>px;
      height:<?php echo $bp['size']; ?>px;
      opacity:<?php echo number_format($bp['op']/100,2); ?>;
      animation-duration:<?php echo $bp['dur']; ?>ms;
      animation-delay:-<?php echo $bp['delay']; ?>ms;
    "></div>
    <?php endforeach; ?>
  </div>

  <!-- Tyre stack -->
  <div class="grg-tyres" aria-hidden="true">
    <div class="grg-tyre"></div>
    <div class="grg-tyre"></div>
    <div class="grg-tyre"></div>
    <div class="grg-tyre"></div>
  </div>

  <!-- Overlay -->
  <div class="grg-hero-overlay" aria-hidden="true"></div>

  <!-- Content -->
  <div class="grg-hero-content">
    <div class="grg-hero-eyebrow">Trusted Mechanics · London · Since 1997</div>
    <h1 class="grg-hero-h1">
      YOUR CAR<br>IN EXPERT<br><span>HANDS</span>
    </h1>
    <p class="grg-hero-sub">
      MOT testing, full servicing, tyres, diagnostics and bodywork.
      Fixed prices, honest advice and same-day availability — six days a week.
    </p>
    <div class="grg-hero-actions">
      <a href="#booking" class="grg-btn-primary">Book Online</a>
      <a href="tel:+442079460800" class="grg-btn-outline">Call Us Now</a>
    </div>
    <div class="grg-hero-badges">
      <div class="grg-hero-badge"><span class="grg-hero-badge-check">✓</span> DVSA Approved MOT</div>
      <div class="grg-hero-badge"><span class="grg-hero-badge-check">✓</span> IMI Certified</div>
      <div class="grg-hero-badge"><span class="grg-hero-badge-check">✓</span> All Makes Welcome</div>
      <div class="grg-hero-badge"><span class="grg-hero-badge-check">✓</span> EV Ready</div>
    </div>
  </div>
</header>

<!-- STATS -->
<div class="grg-stats-bg" role="region" aria-label="Garage statistics">
  <div class="grg-stats-inner">
    <div class="grg-stat">
      <div class="grg-stat-val" data-target="27">0<span class="grg-stat-suf"></span></div>
      <div class="grg-stat-lbl">Years Trading</div>
    </div>
    <div class="grg-stat">
      <div class="grg-stat-val" data-target="18000" data-suffix="+">0<span class="grg-stat-suf">+</span></div>
      <div class="grg-stat-lbl">Happy Customers</div>
    </div>
    <div class="grg-stat">
      <div class="grg-stat-val" data-target="98" data-suffix="%">0<span class="grg-stat-suf">%</span></div>
      <div class="grg-stat-lbl">First-Time MOT Pass Rate</div>
    </div>
    <div class="grg-stat">
      <div class="grg-stat-val" data-target="4.9">0<span class="grg-stat-suf"></span></div>
      <div class="grg-stat-lbl">Google Rating</div>
    </div>
  </div>
</div>

<!-- SERVICES -->
<div id="services" class="grg-services-bg" role="region" aria-labelledby="grg-svc-heading">
  <div class="grg-services-inner">
    <div class="grg-label">What We Do</div>
    <h2 class="grg-h2" id="grg-svc-heading">OUR <span>SERVICES</span></h2>
    <p class="grg-lead">Comprehensive automotive care under one roof — for all makes and models.</p>
    <div class="grg-services-grid">
      <?php foreach($services as $svc): ?>
      <article class="grg-service-card">
        <span class="grg-svc-icon" aria-hidden="true"><?php echo esc_html($svc['icon']); ?></span>
        <div class="grg-svc-name"><?php echo esc_html($svc['name']); ?></div>
        <div class="grg-svc-price"><?php echo esc_html($svc['price']); ?></div>
        <p class="grg-svc-desc"><?php echo esc_html($svc['desc']); ?></p>
        <div class="grg-svc-time"><?php echo esc_html($svc['time']); ?></div>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- PACKAGES -->
<section id="packages" class="grg-section" aria-labelledby="grg-pkg-heading">
  <div class="grg-label">Service Packages</div>
  <h2 class="grg-h2" id="grg-pkg-heading">CHOOSE YOUR <span>PACKAGE</span></h2>
  <p class="grg-lead">All-inclusive fixed prices. No hidden extras. VAT included.</p>
  <div class="grg-packages-grid">
    <?php foreach($packages as $pkg): ?>
    <div class="grg-pkg-card <?php echo $pkg['featured'] ? 'featured' : ''; ?>">
      <?php if($pkg['badge']): ?>
      <div class="grg-pkg-badge"><?php echo esc_html($pkg['badge']); ?></div>
      <?php endif; ?>
      <div class="grg-pkg-name"><?php echo esc_html($pkg['name']); ?></div>
      <div class="grg-pkg-price"><?php echo esc_html($pkg['price']); ?></div>
      <div class="grg-pkg-divider"></div>
      <ul class="grg-pkg-features">
        <?php foreach($pkg['features'] as $feat): ?>
        <li><?php echo esc_html($feat); ?></li>
        <?php endforeach; ?>
      </ul>
      <a href="#booking" class="grg-pkg-btn">Book This Package</a>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- TEAM -->
<div id="team" class="grg-team-bg" role="region" aria-labelledby="grg-team-heading">
  <div class="grg-team-inner">
    <div class="grg-label">The Experts</div>
    <h2 class="grg-h2" id="grg-team-heading">MEET THE <span>TEAM</span></h2>
    <p class="grg-lead">Qualified, certified and passionate about getting your car right.</p>
    <div class="grg-team-grid">
      <?php foreach($team as $m): ?>
      <div class="grg-team-card">
        <div class="grg-team-portrait" aria-hidden="true">
          <div class="grg-mech-fig">
            <div class="grg-mech-body"></div>
            <div class="grg-mech-head"></div>
            <div class="grg-mech-helmet"></div>
            <div class="grg-mech-wrench"></div>
          </div>
        </div>
        <div class="grg-team-info">
          <div class="grg-team-name"><?php echo esc_html($m['name']); ?></div>
          <div class="grg-team-role"><?php echo esc_html($m['role']); ?></div>
          <div class="grg-team-certs"><?php echo esc_html($m['certs']); ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- TESTIMONIALS -->
<section class="grg-section" aria-labelledby="grg-testi-heading">
  <div class="grg-label">Customer Reviews</div>
  <h2 class="grg-h2" id="grg-testi-heading">WHAT CUSTOMERS <span>SAY</span></h2>
  <div class="grg-testi-grid">
    <?php foreach($testimonials as $t): ?>
    <article class="grg-testi-card">
      <div class="grg-testi-stars" aria-label="5 stars">★★★★★</div>
      <p class="grg-testi-text"><?php echo esc_html($t['text']); ?></p>
      <div class="grg-testi-name"><?php echo esc_html($t['name']); ?></div>
      <div class="grg-testi-tag"><?php echo esc_html($t['tag']); ?></div>
    </article>
    <?php endforeach; ?>
  </div>
</section>

<!-- FAQ -->
<section id="faq" class="grg-section" aria-labelledby="grg-faq-heading">
  <div class="grg-label" style="justify-content:center;">FAQ</div>
  <h2 class="grg-h2" style="text-align:center;" id="grg-faq-heading">COMMON <span>QUESTIONS</span></h2>
  <div class="grg-faq-list" role="list">
    <?php foreach($faqs as $fi => $faq): ?>
    <div class="grg-faq-item" role="listitem">
      <button
        class="grg-faq-q"
        aria-expanded="false"
        aria-controls="grg-faq-a-<?php echo $fi; ?>"
        id="grg-faq-q-<?php echo $fi; ?>"
      >
        <?php echo esc_html($faq['q']); ?>
        <span class="grg-faq-icon" aria-hidden="true">+</span>
      </button>
      <div
        class="grg-faq-a"
        id="grg-faq-a-<?php echo $fi; ?>"
        role="region"
        aria-labelledby="grg-faq-q-<?php echo $fi; ?>"
      >
        <div class="grg-faq-a-inner"><?php echo esc_html($faq['a']); ?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- BOOKING -->
<div id="booking" class="grg-booking-bg" role="region" aria-labelledby="grg-booking-heading">
  <div class="grg-booking-inner">
    <div class="grg-label">Book Online</div>
    <h2 class="grg-h2" id="grg-booking-heading">BOOK YOUR <span>APPOINTMENT</span></h2>
    <p style="font-size:15px;color:rgba(208,216,224,.6);margin-top:10px;">
      Book online 24/7. Same-day appointments available for MOTs and emergency repairs.
      We'll confirm within 30 minutes during opening hours.
    </p>
    <form class="grg-form-grid" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" novalidate>
      <?php wp_nonce_field('tf_grg_booking','tf_grg_nonce'); ?>
      <input type="hidden" name="action" value="tf_grg_booking">

      <div class="grg-form-group">
        <label class="grg-form-label" for="grg-fname">First Name</label>
        <input class="grg-form-input" type="text" id="grg-fname" name="first_name" placeholder="Jamie" required>
      </div>
      <div class="grg-form-group">
        <label class="grg-form-label" for="grg-lname">Last Name</label>
        <input class="grg-form-input" type="text" id="grg-lname" name="last_name" placeholder="Harrington" required>
      </div>
      <div class="grg-form-group">
        <label class="grg-form-label" for="grg-email">Email Address</label>
        <input class="grg-form-input" type="email" id="grg-email" name="email" placeholder="jamie@example.com" required>
      </div>
      <div class="grg-form-group">
        <label class="grg-form-label" for="grg-phone">Phone Number</label>
        <input class="grg-form-input" type="tel" id="grg-phone" name="phone" placeholder="+44 7700 900 000" required>
      </div>
      <div class="grg-form-group">
        <label class="grg-form-label" for="grg-reg">Vehicle Registration</label>
        <input class="grg-form-input" type="text" id="grg-reg" name="vehicle_reg" placeholder="AB12 CDE" style="text-transform:uppercase;" required>
      </div>
      <div class="grg-form-group">
        <label class="grg-form-label" for="grg-make">Make &amp; Model</label>
        <input class="grg-form-input" type="text" id="grg-make" name="vehicle_make" placeholder="e.g. BMW 3 Series">
      </div>
      <div class="grg-form-group">
        <label class="grg-form-label" for="grg-service-type">Service Required</label>
        <select class="grg-form-select" id="grg-service-type" name="service_type">
          <option value="">Please select…</option>
          <option>MOT Test</option>
          <option>Full Service + MOT</option>
          <option>Basic Service</option>
          <option>Premium Service</option>
          <option>Brake Repair</option>
          <option>Tyre Fitting &amp; Alignment</option>
          <option>Engine Diagnostics</option>
          <option>Clutch &amp; Gearbox</option>
          <option>Air Conditioning</option>
          <option>Exhaust &amp; Emissions</option>
          <option>Bodywork &amp; Paint</option>
          <option>Emergency Repair</option>
          <option>Other</option>
        </select>
      </div>
      <div class="grg-form-group">
        <label class="grg-form-label" for="grg-date">Preferred Date</label>
        <input class="grg-form-input" type="date" id="grg-date" name="preferred_date">
      </div>
      <div class="grg-form-group full">
        <label class="grg-form-label" for="grg-notes">Additional Details / Fault Description</label>
        <textarea class="grg-form-textarea" id="grg-notes" name="notes" placeholder="Describe any warning lights, noises or symptoms — the more detail, the better…"></textarea>
      </div>
      <div class="grg-form-group full">
        <button type="submit" class="grg-form-submit">BOOK MY APPOINTMENT</button>
      </div>
    </form>
  </div>
</div>

<!-- FOOTER -->
<footer class="grg-footer" role="contentinfo">
  <div class="grg-footer-inner">
    <div>
      <div class="grg-footer-brand">Iron<span>Gate</span> Garage</div>
      <p class="grg-footer-desc">
        London's trusted independent garage since 1997.
        DVSA approved MOT station. All makes and models.
        Open Mon–Sat 08:00–18:00.
      </p>
    </div>
    <div>
      <div class="grg-footer-col-title">Services</div>
      <ul class="grg-footer-list">
        <li><a href="#services">MOT Testing</a></li>
        <li><a href="#services">Full Service</a></li>
        <li><a href="#services">Tyre Fitting</a></li>
        <li><a href="#services">Diagnostics</a></li>
      </ul>
    </div>
    <div>
      <div class="grg-footer-col-title">Garage</div>
      <ul class="grg-footer-list">
        <li><a href="#team">Meet the Team</a></li>
        <li><a href="#packages">Service Packages</a></li>
        <li><a href="#booking">Book Online</a></li>
        <li><a href="#">Finance Options</a></li>
      </ul>
    </div>
    <div>
      <div class="grg-footer-col-title">Contact</div>
      <ul class="grg-footer-list">
        <li><a href="tel:+442079460800">+44 20 7946 0800</a></li>
        <li><a href="#">info@irongate-garage.co.uk</a></li>
        <li><a href="#">42 Industrial Estate Rd, London E1 6RF</a></li>
        <li><a href="#">Mon–Sat 08:00–18:00</a></li>
      </ul>
    </div>
  </div>
  <div class="grg-footer-bottom">
    <span>&copy; <?php echo date('Y'); ?> IronGate Garage Ltd. All rights reserved. DVSA MOT No. 123456.</span>
    <span>
      <a href="#">Privacy Policy</a> &nbsp;·&nbsp;
      <a href="#">Terms</a> &nbsp;·&nbsp;
      <a href="#">Cookie Policy</a>
    </span>
  </div>
</footer>

<script>
(function(){
  'use strict';

  /* ── Animated counters ───────────────────────── */
  var counters = document.querySelectorAll('[data-target]');
  var easeOut  = function(t){ return 1 - Math.pow(1-t,3); };

  var animateCounter = function(el){
    var raw    = el.dataset.target;
    var target = parseFloat(raw);
    var suffix = el.dataset.suffix || '';
    var isFloat= raw.indexOf('.') !== -1;
    if(isNaN(target) || target === 0) return;
    var sufEl  = el.querySelector('.grg-stat-suf');
    var start  = null;
    var dur    = 1800;
    var tick   = function(ts){
      if(!start) start = ts;
      var prog = Math.min((ts - start)/dur, 1);
      var val  = easeOut(prog) * target;
      el.childNodes[0].nodeValue = isFloat ? val.toFixed(1) : Math.round(val).toLocaleString();
      if(sufEl) sufEl.textContent = suffix;
      if(prog < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  };

  if('IntersectionObserver' in window){
    var obs = new IntersectionObserver(function(entries){
      entries.forEach(function(e){
        if(e.isIntersecting){ animateCounter(e.target); obs.unobserve(e.target); }
      });
    },{threshold:.4});
    counters.forEach(function(c){ obs.observe(c); });
  } else {
    counters.forEach(animateCounter);
  }

  /* ── FAQ accordion ───────────────────────────── */
  var faqItems = document.querySelectorAll('.grg-faq-item');
  faqItems.forEach(function(item){
    var btn = item.querySelector('.grg-faq-q');
    var ans = item.querySelector('.grg-faq-a');
    btn.addEventListener('click', function(){
      var isOpen = item.classList.contains('open');
      faqItems.forEach(function(other){
        other.classList.remove('open');
        other.querySelector('.grg-faq-q').setAttribute('aria-expanded','false');
        other.querySelector('.grg-faq-a').style.maxHeight = '0';
      });
      if(!isOpen){
        item.classList.add('open');
        btn.setAttribute('aria-expanded','true');
        ans.style.maxHeight = ans.scrollHeight + 'px';
      }
    });
  });

  /* ── Date minimum ────────────────────────────── */
  var dateEl = document.getElementById('grg-date');
  if(dateEl) dateEl.min = new Date().toISOString().split('T')[0];

  /* ── Reg field uppercase ─────────────────────── */
  var regEl = document.getElementById('grg-reg');
  if(regEl) regEl.addEventListener('input',function(){ this.value = this.value.toUpperCase(); });

})();
</script>

</body>
</html>
</div><!-- .grg-page -->
<?php get_footer(); ?>
