<?php
/**
 * Template Name: Gardener / Garden Designer
 *
 * Premium landing page for a professional gardener or garden designer.
 * Hero: CSS garden scene — lush lawn, flower beds, topiary, CSS gardener figure with tools.
 * Namespace: --gd-* | Fonts: Crimson Pro + DM Sans | Palette: lawn/earth/bloom/sky
 *
 * @package ThemeFlex
 */

get_header(); ?>

<!-- ============================================================
     GARDENER PAGE — CSS CUSTOM PROPERTIES
     ============================================================ -->
<style>
/* ── Fonts ─────────────────────────────────────────────────── */
@import url('https://fonts.googleapis.com/css2?family=Crimson+Pro:ital,wght@0,300;0,400;0,600;0,700;1,400&family=DM+Sans:wght@300;400;500;600&display=swap');

/* ── Token System ───────────────────────────────────────────── */
:root {
  --gd-lawn:    #2E7D32;
  --gd-lawn-lt: #43A047;
  --gd-lawn-dk: #1B5E20;
  --gd-earth:   #5D4037;
  --gd-earth-lt:#8D6E63;
  --gd-earth-dk:#3E2723;
  --gd-bloom:   #E91E63;
  --gd-bloom-lt:#F06292;
  --gd-bloom-lx:#FCE4EC;
  --gd-sky:     #29B6F6;
  --gd-sky-dk:  #0277BD;
  --gd-sun:     #FDD835;
  --gd-cream:   #F9F6F0;
  --gd-white:   #FFFFFF;
  --gd-text:    #2C1E14;
  --gd-text-lt: #5D4E40;
  --gd-shadow:  rgba(44,30,20,0.15);

  --gd-r:       8px;
  --gd-r-lg:    16px;
  --gd-r-xl:    24px;

  --ff-serif: 'Crimson Pro', Georgia, serif;
  --ff-sans:  'DM Sans', system-ui, sans-serif;
}

/* ── Reset Scope ────────────────────────────────────────────── */
.gd-page *, .gd-page *::before, .gd-page *::after { box-sizing: border-box; margin: 0; padding: 0; }
.gd-page { font-family: var(--ff-sans); color: var(--gd-text); background: var(--gd-cream); overflow-x: hidden; }
.gd-page img { max-width: 100%; height: auto; }
.gd-page a { color: inherit; text-decoration: none; }

/* ── Layout ─────────────────────────────────────────────────── */
.gd-wrap    { max-width: 1160px; margin: 0 auto; padding: 0 24px; }
.gd-section { padding: 80px 0; }
.gd-section--alt { background: var(--gd-white); }

/* ── Typography ─────────────────────────────────────────────── */
.gd-eyebrow {
  font-family: var(--ff-sans);
  font-size: .75rem;
  font-weight: 600;
  letter-spacing: .12em;
  text-transform: uppercase;
  color: var(--gd-lawn);
  margin-bottom: 10px;
}
.gd-h1 { font-family: var(--ff-serif); font-size: clamp(2.4rem,5vw,3.8rem); font-weight: 700; line-height: 1.15; }
.gd-h2 { font-family: var(--ff-serif); font-size: clamp(1.8rem,3.5vw,2.8rem); font-weight: 600; line-height: 1.2; margin-bottom: 16px; }
.gd-h3 { font-family: var(--ff-serif); font-size: 1.35rem; font-weight: 600; margin-bottom: 8px; }
.gd-lead { font-size: 1.15rem; line-height: 1.75; color: var(--gd-text-lt); }

/* ── Buttons ─────────────────────────────────────────────────── */
.gd-btn {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 14px 32px; border-radius: 50px; font-family: var(--ff-sans);
  font-size: .95rem; font-weight: 600; cursor: pointer;
  transition: transform .2s, box-shadow .2s; border: none;
}
.gd-btn--primary {
  background: var(--gd-lawn); color: var(--gd-white);
  box-shadow: 0 4px 18px rgba(46,125,50,.35);
}
.gd-btn--primary:hover { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(46,125,50,.45); }
.gd-btn--outline {
  background: transparent; color: var(--gd-white);
  border: 2px solid rgba(255,255,255,.7);
}
.gd-btn--outline:hover { background: rgba(255,255,255,.12); transform: translateY(-2px); }

/* ============================================================
   HERO — GARDEN SCENE
   ============================================================ */
.gd-hero {
  position: relative; overflow: hidden;
  min-height: 100vh; display: flex; align-items: center;
  background: linear-gradient(180deg,
    #87CEEB 0%,
    #B0E0FF 35%,
    #D4F4D4 60%,
    #2E7D32 60%,
    #1B5E20 100%
  );
}

/* ── Sky elements ── */
.gd-hero__sun {
  position: absolute; top: 8%; left: 15%;
  width: 90px; height: 90px; border-radius: 50%;
  background: radial-gradient(circle, #FFF9C4 0%, #FDD835 40%, #F9A825 100%);
  box-shadow: 0 0 40px 20px rgba(253,216,53,.45);
  animation: gd-sun-rays 6s ease-in-out infinite;
}
@keyframes gd-sun-rays {
  0%,100% { box-shadow: 0 0 40px 20px rgba(253,216,53,.45); }
  50%      { box-shadow: 0 0 60px 30px rgba(253,216,53,.65); }
}

/* Clouds */
.gd-cloud {
  position: absolute; top: 12%; border-radius: 50px;
  background: rgba(255,255,255,.9); filter: blur(1px);
}
.gd-cloud::before, .gd-cloud::after {
  content:''; position: absolute; background: inherit; border-radius: 50%;
}
.gd-cloud--1 { width: 120px; height: 40px; left: 25%; top: 10%; animation: gd-cloud-drift 18s linear infinite; }
.gd-cloud--1::before { width: 60px; height: 55px; top: -25px; left: 15px; }
.gd-cloud--1::after  { width: 45px; height: 45px; top: -18px; left: 50px; }
.gd-cloud--2 { width: 90px; height: 30px; right: 20%; top: 7%; animation: gd-cloud-drift 24s linear infinite reverse; }
.gd-cloud--2::before { width: 45px; height: 42px; top: -20px; left: 12px; }
.gd-cloud--2::after  { width: 36px; height: 36px; top: -14px; left: 42px; }
@keyframes gd-cloud-drift {
  from { transform: translateX(0); }
  to   { transform: translateX(40px); }
}

/* ── Ground plane ── */
.gd-hero__ground {
  position: absolute; bottom: 0; left: 0; right: 0; height: 42%;
  background: linear-gradient(180deg, var(--gd-lawn-lt) 0%, var(--gd-lawn-dk) 100%);
}
/* Lawn texture stripes */
.gd-hero__ground::before {
  content:''; position: absolute; inset: 0;
  background: repeating-linear-gradient(
    90deg,
    rgba(255,255,255,.04) 0px, rgba(255,255,255,.04) 48px,
    transparent 48px, transparent 96px
  );
}

/* ── Pathway ── */
.gd-path {
  position: absolute; bottom: 0; left: 50%; transform: translateX(-50%);
  width: 100px; height: 65%;
  background: linear-gradient(180deg, #BCAAA4 0%, #D7CCC8 100%);
  clip-path: polygon(30% 0%, 70% 0%, 100% 100%, 0% 100%);
}
/* Stepping stones */
.gd-stone {
  position: absolute; border-radius: 50%;
  background: #A1887F;
  box-shadow: inset 0 2px 4px rgba(255,255,255,.3);
}
.gd-stone--1 { width: 36px; height: 22px; bottom: 10%; left: 50%; transform: translateX(-50%); }
.gd-stone--2 { width: 32px; height: 20px; bottom: 25%; left: 50%; transform: translateX(-55%); }
.gd-stone--3 { width: 30px; height: 18px; bottom: 38%; left: 50%; transform: translateX(-50%); }
.gd-stone--4 { width: 28px; height: 17px; bottom: 50%; left: 50%; transform: translateX(-48%); }

/* ── Topiary bushes ── */
.gd-topiary {
  position: absolute; bottom: 40%;
  display: flex; flex-direction: column; align-items: center;
}
.gd-topiary__ball {
  border-radius: 50%;
  background: radial-gradient(circle at 35% 30%, #66BB6A, var(--gd-lawn-dk));
  box-shadow: 4px 4px 12px rgba(0,0,0,.3), inset -4px -4px 8px rgba(0,0,0,.2);
}
.gd-topiary__trunk {
  background: var(--gd-earth); border-radius: 4px;
}
.gd-topiary__pot {
  background: linear-gradient(180deg, #EF9A9A, #C62828);
  clip-path: polygon(10% 0%, 90% 0%, 80% 100%, 20% 100%);
  border-radius: 0 0 4px 4px;
}

.gd-topiary--1 { left: 10%; }
.gd-topiary--1 .gd-topiary__ball  { width: 70px; height: 70px; }
.gd-topiary--1 .gd-topiary__trunk { width: 14px; height: 40px; margin-top: -4px; }
.gd-topiary--1 .gd-topiary__pot   { width: 40px; height: 24px; margin-top: -2px; }

.gd-topiary--2 { right: 12%; }
.gd-topiary--2 .gd-topiary__ball  { width: 55px; height: 55px; }
.gd-topiary--2 .gd-topiary__trunk { width: 12px; height: 32px; margin-top: -4px; }
.gd-topiary--2 .gd-topiary__pot   { width: 34px; height: 20px; margin-top: -2px; }

/* ── Flower beds ── */
.gd-flowerbed {
  position: absolute; bottom: 40%;
  display: flex; gap: 6px; align-items: flex-end;
}
.gd-flowerbed--left  { left: 18%; }
.gd-flowerbed--right { right: 20%; }

.gd-flower { position: relative; display: flex; flex-direction: column; align-items: center; }
.gd-flower__stem {
  width: 3px; border-radius: 2px;
  background: var(--gd-lawn);
}
.gd-flower__head {
  width: 20px; height: 20px; border-radius: 50%;
  position: relative;
}
.gd-flower__head::before {
  content:''; position: absolute; inset: -5px;
  border-radius: 50%;
  background: radial-gradient(circle at 40% 40%, rgba(255,255,255,.4), transparent 60%);
}
/* petals via box-shadow */
.gd-flower__head::after {
  content:''; position: absolute;
  width: 8px; height: 8px; border-radius: 50%;
  background: rgba(255,255,255,.6);
  top: -6px; left: 50%; transform: translateX(-50%);
  box-shadow:
    6px 4px 0 rgba(255,255,255,.55),
    6px -4px 0 rgba(255,255,255,.55),
    -6px 4px 0 rgba(255,255,255,.55),
    -6px -4px 0 rgba(255,255,255,.55);
}

/* Animation: flowers sway */
.gd-flower { animation: gd-sway 3s ease-in-out infinite; transform-origin: bottom center; }
.gd-flower:nth-child(2) { animation-delay: -.8s; }
.gd-flower:nth-child(3) { animation-delay: -1.5s; }
.gd-flower:nth-child(4) { animation-delay: -.3s; }
@keyframes gd-sway {
  0%,100% { transform: rotate(-4deg); }
  50%      { transform: rotate(4deg); }
}

/* Flower colour variants */
.gd-flower--pink   .gd-flower__head { background: radial-gradient(circle at 40% 35%, #F48FB1, var(--gd-bloom)); }
.gd-flower--yellow .gd-flower__head { background: radial-gradient(circle at 40% 35%, #FFF176, #F9A825); }
.gd-flower--white  .gd-flower__head { background: radial-gradient(circle at 40% 35%, #fff, #E0E0E0); }
.gd-flower--purple .gd-flower__head { background: radial-gradient(circle at 40% 35%, #CE93D8, #7B1FA2); }
.gd-flower--red    .gd-flower__head { background: radial-gradient(circle at 40% 35%, #EF9A9A, #C62828); }

.gd-flower--sm .gd-flower__stem { height: 28px; }
.gd-flower--md .gd-flower__stem { height: 38px; }
.gd-flower--lg .gd-flower__stem { height: 48px; }

/* ── CSS Gardener Figure ── */
.gd-gardener {
  position: absolute; bottom: 41%; right: 28%;
  width: 72px; display: flex; flex-direction: column; align-items: center;
}
/* Hat */
.gd-gardener__hat {
  width: 54px; height: 18px; border-radius: 4px;
  background: var(--gd-earth);
  position: relative;
}
.gd-gardener__hat::before { /* brim */
  content:''; position: absolute;
  width: 70px; height: 10px; border-radius: 50%;
  background: var(--gd-earth);
  top: 8px; left: -8px;
}
.gd-gardener__hat::after { /* crown */
  content:''; position: absolute;
  width: 40px; height: 24px; border-radius: 4px 4px 0 0;
  background: var(--gd-earth-dk);
  bottom: 18px; left: 7px;
}
/* Head */
.gd-gardener__head {
  width: 38px; height: 42px; border-radius: 50% 50% 45% 45%;
  background: #FFCCBC;
  margin-top: 2px; position: relative;
}
/* Eyes */
.gd-gardener__head::before {
  content:''; position: absolute;
  width: 8px; height: 8px; border-radius: 50%;
  background: var(--gd-earth-dk);
  top: 40%; left: 20%;
  box-shadow: 14px 0 0 var(--gd-earth-dk);
}
/* Smile */
.gd-gardener__head::after {
  content:''; position: absolute;
  width: 16px; height: 8px;
  border: 2.5px solid var(--gd-earth-dk);
  border-top: none;
  border-radius: 0 0 50% 50%;
  bottom: 22%; left: 50%; transform: translateX(-50%);
}
/* Body / dungarees */
.gd-gardener__body {
  width: 48px; height: 52px; border-radius: 8px 8px 0 0;
  background: var(--gd-lawn-dk);
  margin-top: -2px; position: relative;
}
/* Dungaree bib strap */
.gd-gardener__body::before {
  content:''; position: absolute;
  width: 28px; height: 12px; border-radius: 4px;
  background: var(--gd-lawn-lt);
  top: 4px; left: 50%; transform: translateX(-50%);
}
/* Pocket */
.gd-gardener__body::after {
  content:''; position: absolute;
  width: 12px; height: 10px; border-radius: 3px;
  background: var(--gd-lawn);
  border: 1.5px solid var(--gd-lawn-dk);
  top: 22px; left: 8px;
}
/* Left arm */
.gd-gardener__arm-l {
  position: absolute; width: 14px; height: 40px;
  border-radius: 7px; background: var(--gd-lawn-dk);
  top: 6px; left: -12px;
  transform-origin: top center;
}
/* Right arm — holding spade, waving */
.gd-gardener__arm-r {
  position: absolute; width: 14px; height: 40px;
  border-radius: 7px; background: var(--gd-lawn-dk);
  top: 6px; right: -12px;
  transform: rotate(30deg);
  transform-origin: top center;
  animation: gd-arm-dig 2s ease-in-out infinite;
}
@keyframes gd-arm-dig {
  0%,100% { transform: rotate(30deg); }
  50%      { transform: rotate(50deg); }
}
/* Legs */
.gd-gardener__legs {
  display: flex; gap: 6px; margin-top: -2px;
}
.gd-gardener__leg {
  width: 20px; height: 32px; border-radius: 0 0 6px 6px;
  background: var(--gd-earth);
}
/* Boots */
.gd-gardener__boots { display: flex; gap: 6px; }
.gd-gardener__boot {
  width: 22px; height: 12px; border-radius: 0 8px 8px 0;
  background: var(--gd-earth-dk);
  margin-top: -2px;
}
.gd-gardener__boot:first-child { border-radius: 8px 0 0 8px; }

/* Spade tool */
.gd-spade {
  position: absolute; right: 26%; bottom: 38%;
  display: flex; flex-direction: column; align-items: center;
}
.gd-spade__handle {
  width: 6px; height: 52px; border-radius: 3px;
  background: #A1887F;
}
.gd-spade__head {
  width: 24px; height: 20px; border-radius: 2px 2px 8px 8px;
  background: #90A4AE;
  margin-top: -2px;
}

/* ── Hedge backdrop ── */
.gd-hedge {
  position: absolute; bottom: 68%;
  height: 60px;
  background: radial-gradient(ellipse at center, var(--gd-lawn-lt), var(--gd-lawn-dk));
  border-radius: 50% 50% 0 0 / 80% 80% 0 0;
}
.gd-hedge--1 { width: 120px; left: 2%; }
.gd-hedge--2 { width: 90px;  left: 5%; height: 50px; bottom: 67%; background: var(--gd-lawn-dk); }
.gd-hedge--3 { width: 140px; right: 3%; }
.gd-hedge--4 { width: 100px; right: 6%; height: 50px; bottom: 67%; background: var(--gd-lawn-dk); }

/* ── Butterflies ── */
.gd-butterfly {
  position: absolute;
  animation: gd-butterfly-fly 8s ease-in-out infinite;
}
.gd-butterfly__wing-l, .gd-butterfly__wing-r {
  width: 16px; height: 12px; border-radius: 50%;
  background: var(--gd-bloom-lt);
  display: inline-block;
  animation: gd-wing-flap .4s ease-in-out infinite alternate;
}
.gd-butterfly__wing-r { transform: scaleX(-1); }
.gd-butterfly--1 { top: 50%; left: 30%; }
.gd-butterfly--2 { top: 45%; right: 35%; animation-delay: -3s; }
@keyframes gd-butterfly-fly {
  0%   { transform: translate(0,0); }
  25%  { transform: translate(20px,-15px); }
  50%  { transform: translate(40px,5px); }
  75%  { transform: translate(20px,-10px); }
  100% { transform: translate(0,0); }
}
@keyframes gd-wing-flap {
  from { transform: scaleY(1); }
  to   { transform: scaleY(.3); }
}

/* ── Hero content ── */
.gd-hero__inner {
  position: relative; z-index: 10;
  max-width: 600px; padding: 40px 24px 40px 60px;
}
.gd-hero__title { color: var(--gd-white); text-shadow: 0 2px 12px rgba(0,0,0,.4); margin-bottom: 18px; }
.gd-hero__sub   { font-size: 1.15rem; color: rgba(255,255,255,.88); line-height: 1.7; margin-bottom: 30px; }
.gd-hero__ctas  { display: flex; gap: 14px; flex-wrap: wrap; }

/* ── Badges ── */
.gd-badge {
  position: absolute; border-radius: var(--gd-r-lg);
  background: rgba(255,255,255,.9); backdrop-filter: blur(8px);
  padding: 10px 16px; box-shadow: 0 4px 16px var(--gd-shadow);
  display: flex; align-items: center; gap: 8px;
  font-family: var(--ff-sans); font-size: .82rem; font-weight: 600;
  color: var(--gd-text);
  animation: gd-badge-float 5s ease-in-out infinite;
}
.gd-badge__icon { font-size: 1.1rem; }
.gd-badge--1 { top: 18%; right: 8%; animation-delay: 0s; }
.gd-badge--2 { top: 35%; right: 6%; animation-delay: -1.8s; }
.gd-badge--3 { top: 52%; right: 7%; animation-delay: -3.2s; }
@keyframes gd-badge-float {
  0%,100% { transform: translateY(0); }
  50%      { transform: translateY(-8px); }
}

/* ============================================================
   STATS BAR
   ============================================================ */
.gd-stats { background: var(--gd-lawn-dk); padding: 40px 0; }
.gd-stats__grid {
  display: grid; grid-template-columns: repeat(4,1fr); gap: 0;
}
.gd-stat {
  text-align: center; padding: 16px;
  border-right: 1px solid rgba(255,255,255,.15);
}
.gd-stat:last-child { border-right: none; }
.gd-stat__number {
  font-family: var(--ff-serif); font-size: 2.6rem; font-weight: 700;
  color: var(--gd-sun); line-height: 1;
}
.gd-stat__label { font-size: .82rem; color: rgba(255,255,255,.72); margin-top: 6px; letter-spacing: .04em; }

/* ============================================================
   ABOUT
   ============================================================ */
.gd-about__grid { display: grid; grid-template-columns: 1fr 1fr; gap: 60px; align-items: center; }
.gd-about__visual {
  position: relative; height: 420px;
  border-radius: var(--gd-r-xl);
  overflow: hidden;
  background: linear-gradient(150deg, #C8E6C9, #A5D6A7);
  box-shadow: 0 12px 40px var(--gd-shadow);
}
/* CSS garden illustration inside about card */
.gd-about__lawn {
  position: absolute; bottom: 0; left: 0; right: 0; height: 45%;
  background: linear-gradient(180deg, var(--gd-lawn-lt), var(--gd-lawn-dk));
}
.gd-about__sky {
  position: absolute; top: 0; left: 0; right: 0; height: 55%;
  background: linear-gradient(180deg, #81D4FA, #B3E5FC);
}
/* Mini flowers decoration */
.gd-about__flowers {
  position: absolute; bottom: 43%; left: 0; right: 0;
  display: flex; justify-content: space-around; padding: 0 20px;
}
.gd-about__cert {
  position: absolute; top: 12px; right: 12px;
  background: var(--gd-white); border-radius: var(--gd-r);
  padding: 10px 14px; font-size: .78rem;
  box-shadow: 0 2px 12px var(--gd-shadow);
  text-align: center; font-weight: 600; color: var(--gd-lawn-dk);
}
.gd-about__text-badge {
  position: absolute; bottom: 16px; left: 16px;
  background: var(--gd-lawn); color: var(--gd-white);
  border-radius: var(--gd-r); padding: 8px 14px;
  font-size: .82rem; font-weight: 600;
}

.gd-about__content { }
.gd-about__name {
  font-family: var(--ff-serif); font-size: 2rem;
  font-weight: 700; margin: 12px 0 6px;
}
.gd-about__title-badge {
  display: inline-block; background: var(--gd-bloom-lx);
  color: var(--gd-bloom); border-radius: 50px;
  font-size: .78rem; font-weight: 600; padding: 4px 14px;
  margin-bottom: 18px; letter-spacing: .04em;
}
.gd-about__body { font-size: 1.05rem; line-height: 1.8; color: var(--gd-text-lt); margin-bottom: 18px; }
.gd-about__quals { list-style: none; margin-bottom: 28px; }
.gd-about__quals li {
  padding: 8px 0 8px 28px; border-bottom: 1px solid #EEE; position: relative;
  font-size: .95rem; color: var(--gd-text-lt);
}
.gd-about__quals li::before {
  content:'🌿'; position: absolute; left: 0; top: 8px; font-size: .85rem;
}

/* ============================================================
   SERVICES
   ============================================================ */
.gd-services__grid {
  display: grid; grid-template-columns: repeat(auto-fit,minmax(260px,1fr)); gap: 24px;
  margin-top: 40px;
}
.gd-service-card {
  background: var(--gd-white); border-radius: var(--gd-r-lg);
  padding: 30px 26px; box-shadow: 0 4px 20px var(--gd-shadow);
  border-left: 4px solid var(--gd-lawn); transition: transform .25s, box-shadow .25s;
}
.gd-service-card:hover { transform: translateY(-4px); box-shadow: 0 10px 32px var(--gd-shadow); }
.gd-service-card__icon { font-size: 2rem; margin-bottom: 14px; display: block; }
.gd-service-card__title { font-family: var(--ff-serif); font-size: 1.25rem; font-weight: 600; margin-bottom: 8px; }
.gd-service-card__desc  { font-size: .93rem; line-height: 1.65; color: var(--gd-text-lt); }

/* ============================================================
   PORTFOLIO / GARDEN TYPES
   ============================================================ */
.gd-portfolio { background: var(--gd-lawn-dk); padding: 80px 0; }
.gd-portfolio .gd-eyebrow { color: var(--gd-sun); }
.gd-portfolio .gd-h2 { color: var(--gd-white); }
.gd-portfolio__grid {
  display: grid; grid-template-columns: repeat(auto-fit,minmax(200px,1fr)); gap: 16px;
  margin-top: 40px;
}
.gd-portfolio-card {
  border-radius: var(--gd-r-lg); overflow: hidden;
  aspect-ratio: 4/3; position: relative;
  box-shadow: 0 4px 20px rgba(0,0,0,.3);
  transition: transform .3s;
  cursor: pointer;
}
.gd-portfolio-card:hover { transform: scale(1.04); }
.gd-portfolio-card__bg {
  position: absolute; inset: 0;
}
.gd-portfolio-card__label {
  position: absolute; bottom: 0; left: 0; right: 0;
  padding: 10px 14px; background: rgba(0,0,0,.55);
  color: var(--gd-white); font-size: .85rem; font-weight: 600;
}
/* CSS garden thumbnail illustrations */
.gd-pt--cottage .gd-portfolio-card__bg {
  background: linear-gradient(180deg,#87CEEB 50%,#4CAF50 50%);
}
.gd-pt--formal .gd-portfolio-card__bg {
  background: linear-gradient(180deg,#B3E5FC 50%,#388E3C 50%);
}
.gd-pt--kitchen .gd-portfolio-card__bg {
  background: linear-gradient(180deg,#DCEDC8 50%,#689F38 50%);
}
.gd-pt--contemporary .gd-portfolio-card__bg {
  background: linear-gradient(180deg,#E0F7FA 50%,#00695C 50%);
}
.gd-pt--wildlife .gd-portfolio-card__bg {
  background: linear-gradient(180deg,#E8F5E9 50%,#2E7D32 50%);
}
.gd-pt--childrens .gd-portfolio-card__bg {
  background: linear-gradient(180deg,#FFF9C4 50%,#F9A825 25%,#4CAF50 50%);
}

/* ============================================================
   PROCESS
   ============================================================ */
.gd-process__steps { display: grid; grid-template-columns: repeat(5,1fr); gap: 0; margin-top: 48px; position: relative; }
.gd-process__steps::before {
  content:''; position: absolute;
  top: 32px; left: 10%; right: 10%; height: 3px;
  background: linear-gradient(90deg, var(--gd-lawn), var(--gd-bloom));
  z-index: 0;
}
.gd-step { text-align: center; position: relative; z-index: 1; padding: 0 12px; }
.gd-step__num {
  width: 64px; height: 64px; border-radius: 50%;
  background: var(--gd-lawn); color: var(--gd-white);
  font-family: var(--ff-serif); font-size: 1.5rem; font-weight: 700;
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto 16px; box-shadow: 0 4px 16px rgba(46,125,50,.35);
}
.gd-step__title { font-family: var(--ff-serif); font-size: 1rem; font-weight: 600; margin-bottom: 6px; }
.gd-step__desc  { font-size: .82rem; line-height: 1.5; color: var(--gd-text-lt); }

/* ============================================================
   PACKAGES
   ============================================================ */
.gd-packages__grid {
  display: grid; grid-template-columns: repeat(3,1fr); gap: 28px; margin-top: 48px; align-items: start;
}
.gd-pkg {
  border-radius: var(--gd-r-xl); overflow: hidden;
  box-shadow: 0 6px 28px var(--gd-shadow);
  background: var(--gd-white); transition: transform .25s;
}
.gd-pkg:hover { transform: translateY(-4px); }
.gd-pkg--featured { transform: scale(1.04); box-shadow: 0 12px 48px rgba(46,125,50,.3); }
.gd-pkg--featured:hover { transform: scale(1.04) translateY(-4px); }

.gd-pkg__header {
  padding: 28px 28px 20px; text-align: center;
}
.gd-pkg--basic     .gd-pkg__header { background: var(--gd-sky); }
.gd-pkg--featured  .gd-pkg__header { background: var(--gd-lawn); }
.gd-pkg--premium   .gd-pkg__header { background: var(--gd-earth-dk); }

.gd-pkg__badge {
  display: inline-block; background: var(--gd-sun); color: var(--gd-earth-dk);
  border-radius: 50px; font-size: .72rem; font-weight: 700;
  padding: 3px 12px; margin-bottom: 10px; letter-spacing: .08em;
  text-transform: uppercase;
}
.gd-pkg__name  { font-family: var(--ff-serif); font-size: 1.5rem; font-weight: 700; color: var(--gd-white); }
.gd-pkg__price { font-family: var(--ff-serif); font-size: 2.4rem; font-weight: 700; color: var(--gd-white); margin: 12px 0 4px; }
.gd-pkg__unit  { font-size: .82rem; color: rgba(255,255,255,.75); }

.gd-pkg__body { padding: 24px 28px 28px; }
.gd-pkg__desc { font-size: .92rem; color: var(--gd-text-lt); margin-bottom: 18px; line-height: 1.6; }
.gd-pkg__features { list-style: none; margin-bottom: 24px; }
.gd-pkg__features li {
  padding: 6px 0 6px 26px; position: relative;
  font-size: .9rem; color: var(--gd-text-lt); border-bottom: 1px solid #F5F5F5;
}
.gd-pkg__features li::before { content:'✓'; position: absolute; left: 0; color: var(--gd-lawn); font-weight: 700; }
.gd-pkg__cta {
  display: block; text-align: center; padding: 13px; border-radius: 50px;
  font-family: var(--ff-sans); font-size: .95rem; font-weight: 600;
  transition: opacity .2s; cursor: pointer; border: none;
}
.gd-pkg--basic    .gd-pkg__cta { background: var(--gd-sky);      color: var(--gd-white); }
.gd-pkg--featured .gd-pkg__cta { background: var(--gd-lawn);     color: var(--gd-white); }
.gd-pkg--premium  .gd-pkg__cta { background: var(--gd-earth-dk); color: var(--gd-white); }
.gd-pkg__cta:hover { opacity: .88; }

/* ============================================================
   TESTIMONIALS
   ============================================================ */
.gd-testimonials { background: var(--gd-cream); }
.gd-testimonials__grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; margin-top: 40px; }
.gd-testi {
  background: var(--gd-white); border-radius: var(--gd-r-lg);
  padding: 28px; box-shadow: 0 4px 20px var(--gd-shadow);
}
.gd-testi__stars { color: var(--gd-sun); font-size: 1rem; margin-bottom: 12px; letter-spacing: 2px; }
.gd-testi__quote {
  font-family: var(--ff-serif); font-size: 1.05rem; font-style: italic;
  line-height: 1.75; color: var(--gd-text-lt); margin-bottom: 18px;
}
.gd-testi__author { font-weight: 600; font-size: .9rem; }
.gd-testi__meta   { font-size: .82rem; color: var(--gd-text-lt); }

/* ============================================================
   FAQs
   ============================================================ */
.gd-faqs__list { max-width: 780px; margin: 40px auto 0; }
.gd-faq { border-bottom: 1px solid #E0E0E0; }
.gd-faq__q {
  width: 100%; background: none; border: none; cursor: pointer;
  display: flex; align-items: center; justify-content: space-between;
  padding: 20px 0; font-family: var(--ff-serif); font-size: 1.1rem; font-weight: 600;
  color: var(--gd-text); text-align: left; gap: 16px;
}
.gd-faq__icon { font-size: 1.4rem; flex-shrink: 0; color: var(--gd-lawn); transition: transform .3s; }
.gd-faq__q[aria-expanded="true"] .gd-faq__icon { transform: rotate(45deg); }
.gd-faq__a { display: none; padding: 0 0 20px; font-size: .97rem; line-height: 1.75; color: var(--gd-text-lt); }
.gd-faq__a.is-open { display: block; }

/* ============================================================
   BOOKING FORM
   ============================================================ */
.gd-booking { background: var(--gd-lawn-dk); padding: 80px 0; }
.gd-booking .gd-eyebrow { color: var(--gd-sun); }
.gd-booking .gd-h2 { color: var(--gd-white); }
.gd-booking .gd-lead { color: rgba(255,255,255,.78); }

.gd-form { background: var(--gd-white); border-radius: var(--gd-r-xl); padding: 48px; margin-top: 40px; box-shadow: 0 12px 48px rgba(0,0,0,.25); }
.gd-form__grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
.gd-form__full { grid-column: 1/-1; }

.gd-label {
  display: block; font-size: .85rem; font-weight: 600;
  margin-bottom: 6px; color: var(--gd-text-lt);
}
.gd-input, .gd-select, .gd-textarea {
  width: 100%; padding: 12px 16px;
  border: 1.5px solid #DDD; border-radius: var(--gd-r);
  font-family: var(--ff-sans); font-size: .97rem; color: var(--gd-text);
  background: #FAFAFA; transition: border-color .2s;
}
.gd-input:focus, .gd-select:focus, .gd-textarea:focus {
  outline: none; border-color: var(--gd-lawn);
  background: var(--gd-white);
}
.gd-textarea { min-height: 120px; resize: vertical; }
.gd-form__submit { text-align: center; margin-top: 32px; }
.gd-form__note { text-align: center; font-size: .82rem; color: var(--gd-text-lt); margin-top: 12px; }

/* ============================================================
   FOOTER CTA
   ============================================================ */
.gd-footer-cta {
  background: linear-gradient(135deg, var(--gd-bloom) 0%, #C2185B 100%);
  padding: 60px 0; text-align: center;
}
.gd-footer-cta .gd-h2 { color: var(--gd-white); margin-bottom: 10px; }
.gd-footer-cta .gd-lead { color: rgba(255,255,255,.85); margin-bottom: 28px; }
.gd-footer-cta .gd-btn--outline { border-color: rgba(255,255,255,.8); }

/* ============================================================
   SCROLL REVEAL
   ============================================================ */
.gd-reveal { opacity: 0; transform: translateY(28px); transition: opacity .65s ease, transform .65s ease; }
.gd-reveal.is-visible { opacity: 1; transform: none; }

/* ============================================================
   RESPONSIVE
   ============================================================ */
@media (max-width: 900px) {
  .gd-about__grid    { grid-template-columns: 1fr; }
  .gd-packages__grid { grid-template-columns: 1fr; }
  .gd-packages__grid .gd-pkg--featured { transform: none; }
  .gd-packages__grid .gd-pkg--featured:hover { transform: translateY(-4px); }
  .gd-process__steps { grid-template-columns: repeat(2,1fr); }
  .gd-process__steps::before { display: none; }
  .gd-stats__grid    { grid-template-columns: repeat(2,1fr); }
  .gd-testimonials__grid { grid-template-columns: 1fr; }
}
@media (max-width: 600px) {
  .gd-hero__inner { padding: 40px 24px; }
  .gd-form__grid  { grid-template-columns: 1fr; }
  .gd-stats__grid { grid-template-columns: 1fr 1fr; }
  .gd-portfolio__grid { grid-template-columns: 1fr 1fr; }
  .gd-process__steps { grid-template-columns: 1fr; }
  .gd-badge--2, .gd-badge--3 { display: none; }
}
</style>

<!-- ============================================================
     PAGE WRAPPER
     ============================================================ -->
<div class="gd-page">

  <!-- ── HERO ─────────────────────────────────────────────── -->
  <section class="gd-hero" aria-label="Garden design hero">

    <!-- Sky / atmosphere -->
    <div class="gd-hero__sun" aria-hidden="true"></div>
    <div class="gd-cloud gd-cloud--1" aria-hidden="true"></div>
    <div class="gd-cloud gd-cloud--2" aria-hidden="true"></div>

    <!-- Hedges backdrop -->
    <div class="gd-hedge gd-hedge--1" aria-hidden="true"></div>
    <div class="gd-hedge gd-hedge--2" aria-hidden="true"></div>
    <div class="gd-hedge gd-hedge--3" aria-hidden="true"></div>
    <div class="gd-hedge gd-hedge--4" aria-hidden="true"></div>

    <!-- Ground -->
    <div class="gd-hero__ground" aria-hidden="true"></div>

    <!-- Pathway -->
    <div class="gd-path" aria-hidden="true">
      <div class="gd-stone gd-stone--1"></div>
      <div class="gd-stone gd-stone--2"></div>
      <div class="gd-stone gd-stone--3"></div>
      <div class="gd-stone gd-stone--4"></div>
    </div>

    <!-- Topiaries -->
    <div class="gd-topiary gd-topiary--1" aria-hidden="true">
      <div class="gd-topiary__ball"></div>
      <div class="gd-topiary__trunk"></div>
      <div class="gd-topiary__pot"></div>
    </div>
    <div class="gd-topiary gd-topiary--2" aria-hidden="true">
      <div class="gd-topiary__ball"></div>
      <div class="gd-topiary__trunk"></div>
      <div class="gd-topiary__pot"></div>
    </div>

    <!-- Flower beds -->
    <div class="gd-flowerbed gd-flowerbed--left" aria-hidden="true">
      <div class="gd-flower gd-flower--pink gd-flower--md">
        <div class="gd-flower__stem"></div><div class="gd-flower__head"></div>
      </div>
      <div class="gd-flower gd-flower--yellow gd-flower--lg">
        <div class="gd-flower__stem"></div><div class="gd-flower__head"></div>
      </div>
      <div class="gd-flower gd-flower--white gd-flower--sm">
        <div class="gd-flower__stem"></div><div class="gd-flower__head"></div>
      </div>
      <div class="gd-flower gd-flower--purple gd-flower--md">
        <div class="gd-flower__stem"></div><div class="gd-flower__head"></div>
      </div>
    </div>
    <div class="gd-flowerbed gd-flowerbed--right" aria-hidden="true">
      <div class="gd-flower gd-flower--red gd-flower--lg">
        <div class="gd-flower__stem"></div><div class="gd-flower__head"></div>
      </div>
      <div class="gd-flower gd-flower--pink gd-flower--sm">
        <div class="gd-flower__stem"></div><div class="gd-flower__head"></div>
      </div>
      <div class="gd-flower gd-flower--yellow gd-flower--md">
        <div class="gd-flower__stem"></div><div class="gd-flower__head"></div>
      </div>
    </div>

    <!-- Gardener figure -->
    <div class="gd-gardener" aria-hidden="true">
      <div class="gd-gardener__hat"></div>
      <div class="gd-gardener__head"></div>
      <div class="gd-gardener__body" style="position:relative;">
        <div class="gd-gardener__arm-l"></div>
        <div class="gd-gardener__arm-r"></div>
      </div>
      <div class="gd-gardener__legs">
        <div class="gd-gardener__leg"></div>
        <div class="gd-gardener__leg"></div>
      </div>
      <div class="gd-gardener__boots">
        <div class="gd-gardener__boot"></div>
        <div class="gd-gardener__boot"></div>
      </div>
    </div>

    <!-- Spade -->
    <div class="gd-spade" aria-hidden="true">
      <div class="gd-spade__handle"></div>
      <div class="gd-spade__head"></div>
    </div>

    <!-- Butterflies -->
    <div class="gd-butterfly gd-butterfly--1" aria-hidden="true">
      <span class="gd-butterfly__wing-l"></span>
      <span class="gd-butterfly__wing-r"></span>
    </div>
    <div class="gd-butterfly gd-butterfly--2" aria-hidden="true">
      <span class="gd-butterfly__wing-l"></span>
      <span class="gd-butterfly__wing-r"></span>
    </div>

    <!-- Floating badges -->
    <div class="gd-badge gd-badge--1" aria-hidden="true">
      <span class="gd-badge__icon">🏅</span>
      <span>RHS Qualified</span>
    </div>
    <div class="gd-badge gd-badge--2" aria-hidden="true">
      <span class="gd-badge__icon">⭐</span>
      <span>4.9 / 5.0 Rating</span>
    </div>
    <div class="gd-badge gd-badge--3" aria-hidden="true">
      <span class="gd-badge__icon">🌱</span>
      <span>400+ Gardens</span>
    </div>

    <!-- Hero copy -->
    <div class="gd-hero__inner">
      <p class="gd-eyebrow">Professional Garden Design &amp; Maintenance</p>
      <h1 class="gd-h1 gd-hero__title">
        Gardens That<br><em>Come Alive</em>
      </h1>
      <p class="gd-hero__sub">Award-winning garden design and expert maintenance for Surrey &amp; South London. From intimate courtyard gardens to sweeping rural landscapes.</p>
      <div class="gd-hero__ctas">
        <a href="#booking" class="gd-btn gd-btn--primary">🌿 Book a Consultation</a>
        <a href="#services" class="gd-btn gd-btn--outline">View Services</a>
      </div>
    </div>
  </section>

  <!-- ── STATS ─────────────────────────────────────────────── -->
  <section class="gd-stats" aria-label="Key statistics">
    <div class="gd-wrap">
      <div class="gd-stats__grid">
        <div class="gd-stat">
          <div class="gd-stat__number" data-target="20" aria-label="20 years experience">0</div>
          <div class="gd-stat__label">Years Experience</div>
        </div>
        <div class="gd-stat">
          <div class="gd-stat__number" data-target="420" aria-label="420+ gardens transformed">0</div>
          <div class="gd-stat__label">Gardens Transformed</div>
        </div>
        <div class="gd-stat">
          <div class="gd-stat__number" data-target="4" data-float="1" aria-label="4.9 star rating">0</div>
          <div class="gd-stat__label">★ Average Rating</div>
        </div>
        <div class="gd-stat">
          <div class="gd-stat__number" data-target="97" aria-label="97% client satisfaction">0</div>
          <div class="gd-stat__label">% Client Satisfaction</div>
        </div>
      </div>
    </div>
  </section>

  <!-- ── ABOUT ─────────────────────────────────────────────── -->
  <section class="gd-section gd-section--alt" id="about" aria-labelledby="gd-about-heading">
    <div class="gd-wrap">
      <div class="gd-about__grid">

        <div class="gd-about__visual" aria-hidden="true">
          <div class="gd-about__sky"></div>
          <div class="gd-about__lawn"></div>
          <div class="gd-about__flowers">
            <div class="gd-flower gd-flower--pink gd-flower--lg">
              <div class="gd-flower__stem"></div><div class="gd-flower__head"></div>
            </div>
            <div class="gd-flower gd-flower--yellow gd-flower--md">
              <div class="gd-flower__stem"></div><div class="gd-flower__head"></div>
            </div>
            <div class="gd-flower gd-flower--purple gd-flower--lg">
              <div class="gd-flower__stem"></div><div class="gd-flower__head"></div>
            </div>
          </div>
          <div class="gd-about__cert">🏆 RHS Gold Medalist<br>Chelsea 2021</div>
          <div class="gd-about__text-badge">🌿 Fully Insured & Certified</div>
        </div>

        <div class="gd-about__content gd-reveal">
          <p class="gd-eyebrow">About Your Gardener</p>
          <h2 class="gd-about__name" id="gd-about-heading">Eleanor Whitmore</h2>
          <span class="gd-about__title-badge">RHS Gold Medalist · BSc Horticulture</span>
          <p class="gd-about__body">
            For over twenty years, I have been creating gardens that tell stories — spaces that reflect the lives of the people who inhabit them and change beautifully with every season. My approach blends traditional horticultural knowledge with contemporary design sensibility.
          </p>
          <p class="gd-about__body">
            From a patio makeover in Wimbledon to a three-acre country garden in Sussex, every project receives the same meticulous care: thorough site analysis, deeply considered planting plans, and long-term thinking that ensures your garden thrives for decades.
          </p>
          <ul class="gd-about__quals">
            <li>BSc Horticulture, Royal Agricultural University</li>
            <li>RHS Gold Medal — Chelsea Flower Show 2021</li>
            <li>Member, Society of Garden Designers (SGD)</li>
            <li>City & Guilds Level 3 Horticulture</li>
            <li>PA1 / PA6 Pesticides Application Certification</li>
          </ul>
          <a href="#booking" class="gd-btn gd-btn--primary">Start Your Garden Project</a>
        </div>
      </div>
    </div>
  </section>

  <!-- ── SERVICES ───────────────────────────────────────────── -->
  <section class="gd-section" id="services" aria-labelledby="gd-services-heading">
    <div class="gd-wrap">
      <p class="gd-eyebrow">What I Offer</p>
      <h2 class="gd-h2" id="gd-services-heading">Garden Services</h2>
      <p class="gd-lead">Comprehensive garden care from initial vision to year-round maintenance.</p>

      <div class="gd-services__grid">

        <article class="gd-service-card gd-reveal">
          <span class="gd-service-card__icon">📐</span>
          <h3 class="gd-service-card__title">Garden Design</h3>
          <p class="gd-service-card__desc">Full design service including site survey, concept plan, planting scheme, hard landscaping specification, and installation oversight.</p>
        </article>

        <article class="gd-service-card gd-reveal">
          <span class="gd-service-card__icon">✂️</span>
          <h3 class="gd-service-card__title">Regular Maintenance</h3>
          <p class="gd-service-card__desc">Fortnightly or monthly maintenance visits covering mowing, pruning, weeding, feeding, and seasonal planting.</p>
        </article>

        <article class="gd-service-card gd-reveal">
          <span class="gd-service-card__icon">🌱</span>
          <h3 class="gd-service-card__title">Planting &amp; Replanting</h3>
          <p class="gd-service-card__desc">Thoughtful plant selection and installation tailored to your soil, aspect, and lifestyle — from specimen trees to seasonal colour.</p>
        </article>

        <article class="gd-service-card gd-reveal">
          <span class="gd-service-card__icon">🧱</span>
          <h3 class="gd-service-card__title">Hard Landscaping</h3>
          <p class="gd-service-card__desc">Patios, paths, raised beds, pergolas, water features, and boundary structures — designed and project-managed to the highest standard.</p>
        </article>

        <article class="gd-service-card gd-reveal">
          <span class="gd-service-card__icon">🍅</span>
          <h3 class="gd-service-card__title">Kitchen Gardens</h3>
          <p class="gd-service-card__desc">Productive vegetable and herb gardens designed for year-round harvests, combining beauty with practicality.</p>
        </article>

        <article class="gd-service-card gd-reveal">
          <span class="gd-service-card__icon">🦋</span>
          <h3 class="gd-service-card__title">Wildlife Gardening</h3>
          <p class="gd-service-card__desc">Biodiversity-rich planting schemes attracting pollinators, birds, and beneficial insects while creating a haven for you and your family.</p>
        </article>

        <article class="gd-service-card gd-reveal">
          <span class="gd-service-card__icon">🌊</span>
          <h3 class="gd-service-card__title">Water Features</h3>
          <p class="gd-service-card__desc">Ponds, rills, fountains, and contemporary water walls — designed, installed, and maintained for lasting beauty.</p>
        </article>

        <article class="gd-service-card gd-reveal">
          <span class="gd-service-card__icon">🌙</span>
          <h3 class="gd-service-card__title">Garden Lighting</h3>
          <p class="gd-service-card__desc">Low-voltage LED lighting design that extends the usability of your garden into the evening and highlights key features year-round.</p>
        </article>

      </div>
    </div>
  </section>

  <!-- ── PORTFOLIO (Garden Types) ──────────────────────────── -->
  <section class="gd-portfolio" aria-labelledby="gd-portfolio-heading">
    <div class="gd-wrap">
      <p class="gd-eyebrow">Specialisms</p>
      <h2 class="gd-h2" id="gd-portfolio-heading">Garden Styles</h2>
      <div class="gd-portfolio__grid">

        <div class="gd-portfolio-card gd-pt--cottage gd-reveal" tabindex="0" role="img" aria-label="Cottage garden style">
          <div class="gd-portfolio-card__bg"></div>
          <div class="gd-portfolio-card__label">Cottage Garden</div>
        </div>
        <div class="gd-portfolio-card gd-pt--formal gd-reveal" tabindex="0" role="img" aria-label="Formal garden style">
          <div class="gd-portfolio-card__bg"></div>
          <div class="gd-portfolio-card__label">Formal & Parterre</div>
        </div>
        <div class="gd-portfolio-card gd-pt--kitchen gd-reveal" tabindex="0" role="img" aria-label="Kitchen garden style">
          <div class="gd-portfolio-card__bg"></div>
          <div class="gd-portfolio-card__label">Kitchen Garden</div>
        </div>
        <div class="gd-portfolio-card gd-pt--contemporary gd-reveal" tabindex="0" role="img" aria-label="Contemporary garden style">
          <div class="gd-portfolio-card__bg"></div>
          <div class="gd-portfolio-card__label">Contemporary</div>
        </div>
        <div class="gd-portfolio-card gd-pt--wildlife gd-reveal" tabindex="0" role="img" aria-label="Wildlife garden style">
          <div class="gd-portfolio-card__bg"></div>
          <div class="gd-portfolio-card__label">Wildlife Habitat</div>
        </div>
        <div class="gd-portfolio-card gd-pt--childrens gd-reveal" tabindex="0" role="img" aria-label="Children's garden style">
          <div class="gd-portfolio-card__bg"></div>
          <div class="gd-portfolio-card__label">Family & Children</div>
        </div>

      </div>
    </div>
  </section>

  <!-- ── PROCESS ────────────────────────────────────────────── -->
  <section class="gd-section gd-section--alt" aria-labelledby="gd-process-heading">
    <div class="gd-wrap">
      <p class="gd-eyebrow" style="text-align:center">How It Works</p>
      <h2 class="gd-h2" id="gd-process-heading" style="text-align:center">From Vision to Garden</h2>

      <div class="gd-process__steps">

        <div class="gd-step gd-reveal">
          <div class="gd-step__num">1</div>
          <h3 class="gd-step__title">Discovery Call</h3>
          <p class="gd-step__desc">A free 20-minute phone or video call to understand your garden goals, budget, and timeline.</p>
        </div>

        <div class="gd-step gd-reveal">
          <div class="gd-step__num">2</div>
          <h3 class="gd-step__title">Site Survey</h3>
          <p class="gd-step__desc">A thorough on-site consultation including soil testing, aspect analysis, and existing plant assessment.</p>
        </div>

        <div class="gd-step gd-reveal">
          <div class="gd-step__num">3</div>
          <h3 class="gd-step__title">Design Proposal</h3>
          <p class="gd-step__desc">Concept boards, planting plans, and detailed quotes presented within two weeks of the survey.</p>
        </div>

        <div class="gd-step gd-reveal">
          <div class="gd-step__num">4</div>
          <h3 class="gd-step__title">Installation</h3>
          <p class="gd-step__desc">Expert execution by my trusted team, with daily progress updates and minimal disruption to your home.</p>
        </div>

        <div class="gd-step gd-reveal">
          <div class="gd-step__num">5</div>
          <h3 class="gd-step__title">Aftercare</h3>
          <p class="gd-step__desc">Ongoing maintenance plans, seasonal planting updates, and a direct line to me for any questions.</p>
        </div>

      </div>
    </div>
  </section>

  <!-- ── PACKAGES ───────────────────────────────────────────── -->
  <section class="gd-section" id="packages" aria-labelledby="gd-packages-heading">
    <div class="gd-wrap">
      <p class="gd-eyebrow" style="text-align:center">Pricing</p>
      <h2 class="gd-h2" id="gd-packages-heading" style="text-align:center">Garden Packages</h2>
      <p class="gd-lead" style="text-align:center">Transparent pricing — all packages include a free initial consultation.</p>

      <div class="gd-packages__grid">

        <!-- Garden MOT -->
        <div class="gd-pkg gd-pkg--basic gd-reveal">
          <div class="gd-pkg__header">
            <div class="gd-pkg__name">Garden MOT</div>
            <div class="gd-pkg__price">£295</div>
            <div class="gd-pkg__unit">one-time assessment</div>
          </div>
          <div class="gd-pkg__body">
            <p class="gd-pkg__desc">A thorough health-check of your existing garden with a detailed written report and 12-month action plan.</p>
            <ul class="gd-pkg__features">
              <li>2-hour on-site assessment</li>
              <li>Soil health analysis</li>
              <li>Plant condition audit</li>
              <li>Prioritised improvement list</li>
              <li>Seasonal care calendar</li>
              <li>Written report within 5 days</li>
            </ul>
            <button class="gd-pkg__cta" onclick="document.getElementById('booking').scrollIntoView({behavior:'smooth'})">Book MOT</button>
          </div>
        </div>

        <!-- Full Design -->
        <div class="gd-pkg gd-pkg--featured gd-reveal">
          <div class="gd-pkg__header">
            <div class="gd-pkg__badge">Most Popular</div>
            <div class="gd-pkg__name">Full Garden Design</div>
            <div class="gd-pkg__price">from £1,400</div>
            <div class="gd-pkg__unit">design fee + installation quote</div>
          </div>
          <div class="gd-pkg__body">
            <p class="gd-pkg__desc">Comprehensive design from concept to installation, including all technical drawings and project management.</p>
            <ul class="gd-pkg__features">
              <li>Full site survey & analysis</li>
              <li>Concept mood boards</li>
              <li>Detailed planting plans</li>
              <li>Hard landscaping specifications</li>
              <li>Contractor coordination</li>
              <li>Installation supervision</li>
              <li>3-month aftercare visits</li>
            </ul>
            <button class="gd-pkg__cta" onclick="document.getElementById('booking').scrollIntoView({behavior:'smooth'})">Start Design</button>
          </div>
        </div>

        <!-- Annual Care -->
        <div class="gd-pkg gd-pkg--premium gd-reveal">
          <div class="gd-pkg__header">
            <div class="gd-pkg__name">Annual Care Plan</div>
            <div class="gd-pkg__price">from £180</div>
            <div class="gd-pkg__unit">per month</div>
          </div>
          <div class="gd-pkg__body">
            <p class="gd-pkg__desc">Year-round garden maintenance with a dedicated visit schedule, seasonal planting, and expert care every month.</p>
            <ul class="gd-pkg__features">
              <li>Fortnightly or monthly visits</li>
              <li>Mowing & edging</li>
              <li>Pruning & deadheading</li>
              <li>Fertilising & soil care</li>
              <li>Seasonal bulb planting</li>
              <li>Priority booking for extras</li>
              <li>Annual review consultation</li>
            </ul>
            <button class="gd-pkg__cta" onclick="document.getElementById('booking').scrollIntoView({behavior:'smooth'})">Enquire Now</button>
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- ── TESTIMONIALS ───────────────────────────────────────── -->
  <section class="gd-section gd-testimonials" aria-labelledby="gd-testi-heading">
    <div class="gd-wrap">
      <p class="gd-eyebrow" style="text-align:center">Client Stories</p>
      <h2 class="gd-h2" id="gd-testi-heading" style="text-align:center">What Our Clients Say</h2>

      <div class="gd-testimonials__grid">

        <blockquote class="gd-testi gd-reveal">
          <div class="gd-testi__stars" aria-label="5 stars">★★★★★</div>
          <p class="gd-testi__quote">"Eleanor transformed our overgrown back garden into an absolute paradise. Her plant knowledge is extraordinary and she listened carefully to everything we wanted. We couldn't be happier."</p>
          <footer>
            <div class="gd-testi__author">Sarah & James Pemberton</div>
            <div class="gd-testi__meta">Kingston upon Thames · Full Garden Design</div>
          </footer>
        </blockquote>

        <blockquote class="gd-testi gd-reveal">
          <div class="gd-testi__stars" aria-label="5 stars">★★★★★</div>
          <p class="gd-testi__quote">"We have the monthly maintenance plan and it's been the best decision we've made. The garden looks immaculate every time and Eleanor spots issues before they become problems."</p>
          <footer>
            <div class="gd-testi__author">Dr. Amanda Clarke</div>
            <div class="gd-testi__meta">Wimbledon · Annual Care Plan</div>
          </footer>
        </blockquote>

        <blockquote class="gd-testi gd-reveal">
          <div class="gd-testi__stars" aria-label="5 stars">★★★★★</div>
          <p class="gd-testi__quote">"The kitchen garden Eleanor designed for us has given us the most incredible harvests. She thought of everything — succession planting, pest control, soil health — and it shows."</p>
          <footer>
            <div class="gd-testi__author">Tom &amp; Rachel Ashby</div>
            <div class="gd-testi__meta">Dorking, Surrey · Kitchen Garden Design</div>
          </footer>
        </blockquote>

      </div>
    </div>
  </section>

  <!-- ── FAQs ───────────────────────────────────────────────── -->
  <section class="gd-section gd-section--alt" aria-labelledby="gd-faq-heading">
    <div class="gd-wrap">
      <p class="gd-eyebrow" style="text-align:center">Common Questions</p>
      <h2 class="gd-h2" id="gd-faq-heading" style="text-align:center">Frequently Asked Questions</h2>

      <div class="gd-faqs__list">

        <div class="gd-faq">
          <button class="gd-faq__q" aria-expanded="false" aria-controls="gd-faq-1">
            What areas do you cover?
            <span class="gd-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="gd-faq__a" id="gd-faq-1" role="region">
            I cover all of Surrey, South West London (Wimbledon, Kingston, Richmond, Putney), and parts of West Sussex. For larger design projects I am happy to travel further afield — please do get in touch to discuss.
          </div>
        </div>

        <div class="gd-faq">
          <button class="gd-faq__q" aria-expanded="false" aria-controls="gd-faq-2">
            How long does a full garden design take?
            <span class="gd-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="gd-faq__a" id="gd-faq-2" role="region">
            From initial consultation to completed design pack is typically four to eight weeks depending on garden complexity. Installation timing then depends on contractor availability and season — I always try to align planting with the optimal horticultural window.
          </div>
        </div>

        <div class="gd-faq">
          <button class="gd-faq__q" aria-expanded="false" aria-controls="gd-faq-3">
            Can you work with an existing garden rather than starting from scratch?
            <span class="gd-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="gd-faq__a" id="gd-faq-3" role="region">
            Absolutely — in fact many of my most rewarding projects involve working with and enhancing what is already there. The Garden MOT package is an excellent starting point for established gardens needing a refresh rather than a rebuild.
          </div>
        </div>

        <div class="gd-faq">
          <button class="gd-faq__q" aria-expanded="false" aria-controls="gd-faq-4">
            Do you use sustainable and organic practices?
            <span class="gd-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="gd-faq__a" id="gd-faq-4" role="region">
            Yes — sustainability is central to everything I do. I prioritise peat-free composts, organic fertilisers, rainwater harvesting where possible, and wildlife-friendly planting. I hold the PA1/PA6 pesticide certificates but use them only as a last resort.
          </div>
        </div>

        <div class="gd-faq">
          <button class="gd-faq__q" aria-expanded="false" aria-controls="gd-faq-5">
            What is your minimum project budget for design work?
            <span class="gd-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="gd-faq__a" id="gd-faq-5" role="region">
            The design fee starts at £1,400 for a small garden (up to 60m²). Larger or more complex projects are quoted individually. There is no minimum for the Garden MOT or Annual Care Plan — these are available for gardens of all sizes.
          </div>
        </div>

        <div class="gd-faq">
          <button class="gd-faq__q" aria-expanded="false" aria-controls="gd-faq-6">
            Are you insured?
            <span class="gd-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="gd-faq__a" id="gd-faq-6" role="region">
            Yes — I hold full public liability insurance (£5 million) and professional indemnity insurance as required by the Society of Garden Designers. Copies of all certificates are available on request.
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- ── BOOKING FORM ───────────────────────────────────────── -->
  <section class="gd-booking" id="booking" aria-labelledby="gd-booking-heading">
    <div class="gd-wrap">
      <p class="gd-eyebrow" style="text-align:center">Get In Touch</p>
      <h2 class="gd-h2" id="gd-booking-heading" style="text-align:center">Book a Consultation</h2>
      <p class="gd-lead" style="text-align:center">Tell me about your garden and I'll be in touch within one working day.</p>

      <div class="gd-form">
        <?php if ( function_exists( 'wp_nonce_field' ) ) : ?>
        <form method="post" action="" novalidate>
          <?php wp_nonce_field( 'tf_gd_booking', 'tf_gd_nonce' ); ?>

          <div class="gd-form__grid">

            <div>
              <label class="gd-label" for="gd-name">Full Name *</label>
              <input class="gd-input" type="text" id="gd-name" name="gd_name" required placeholder="Your full name" autocomplete="name">
            </div>

            <div>
              <label class="gd-label" for="gd-email">Email Address *</label>
              <input class="gd-input" type="email" id="gd-email" name="gd_email" required placeholder="you@example.com" autocomplete="email">
            </div>

            <div>
              <label class="gd-label" for="gd-phone">Phone Number</label>
              <input class="gd-input" type="tel" id="gd-phone" name="gd_phone" placeholder="07xxx xxxxxx" autocomplete="tel">
            </div>

            <div>
              <label class="gd-label" for="gd-location">Garden Location *</label>
              <input class="gd-input" type="text" id="gd-location" name="gd_location" required placeholder="Town / postcode">
            </div>

            <div>
              <label class="gd-label" for="gd-size">Approximate Garden Size</label>
              <select class="gd-select" id="gd-size" name="gd_size">
                <option value="">Please select…</option>
                <option>Tiny (under 20m²)</option>
                <option>Small (20–60m²)</option>
                <option>Medium (60–200m²)</option>
                <option>Large (200–500m²)</option>
                <option>Estate / Rural (500m²+)</option>
              </select>
            </div>

            <div>
              <label class="gd-label" for="gd-service">Service Interested In *</label>
              <select class="gd-select" id="gd-service" name="gd_service" required>
                <option value="">Please select…</option>
                <option>Garden MOT</option>
                <option>Full Garden Design</option>
                <option>Annual Care Plan</option>
                <option>Hard Landscaping</option>
                <option>Kitchen Garden</option>
                <option>Wildlife Garden</option>
                <option>Not sure — need advice</option>
              </select>
            </div>

            <div>
              <label class="gd-label" for="gd-budget">Approximate Budget</label>
              <select class="gd-select" id="gd-budget" name="gd_budget">
                <option value="">Prefer not to say</option>
                <option>Under £500</option>
                <option>£500 – £2,000</option>
                <option>£2,000 – £5,000</option>
                <option>£5,000 – £15,000</option>
                <option>£15,000+</option>
              </select>
            </div>

            <div>
              <label class="gd-label" for="gd-timescale">Preferred Timescale</label>
              <select class="gd-select" id="gd-timescale" name="gd_timescale">
                <option value="">Flexible</option>
                <option>Within 1 month</option>
                <option>1–3 months</option>
                <option>3–6 months</option>
                <option>6–12 months</option>
                <option>Just exploring options</option>
              </select>
            </div>

            <div class="gd-form__full">
              <label class="gd-label" for="gd-goals">Your Garden Goals *</label>
              <textarea class="gd-textarea" id="gd-goals" name="gd_goals" required placeholder="Tell me a little about your garden and what you'd love it to become — don't worry if you're not sure where to start!"></textarea>
            </div>

          </div>

          <div class="gd-form__submit">
            <button type="submit" class="gd-btn gd-btn--primary">🌿 Send Enquiry</button>
          </div>
          <p class="gd-form__note">Free initial call · No obligation · Replies within 1 working day</p>

        </form>
        <?php endif; ?>
      </div>
    </div>
  </section>

  <!-- ── FOOTER CTA ─────────────────────────────────────────── -->
  <section class="gd-footer-cta" aria-label="Call to action">
    <div class="gd-wrap">
      <h2 class="gd-h2">Ready to Love Your Garden Again?</h2>
      <p class="gd-lead">Let's create something extraordinary together — one season at a time.</p>
      <a href="#booking" class="gd-btn gd-btn--outline">Book Your Free Call ↗</a>
    </div>
  </section>

</div><!-- .gd-page -->

<!-- ============================================================
     JAVASCRIPT
     ============================================================ -->
<script>
(function () {
  'use strict';

  /* ── Animated counters ──────────────────────────────────── */
  var counters = document.querySelectorAll('[data-target]');
  var easeOut  = function (t) { return 1 - Math.pow(1 - t, 3); };
  var duration = 1800;

  function animateCounter(el) {
    var target  = parseFloat(el.getAttribute('data-target'));
    var isFloat = el.getAttribute('data-float') === '1';
    if (isNaN(target)) return;
    var start = null;

    function tick(ts) {
      if (!start) start = ts;
      var progress = Math.min((ts - start) / duration, 1);
      var value    = target * easeOut(progress);
      el.textContent = isFloat ? value.toFixed(1) : Math.floor(value).toLocaleString();
      if (progress < 1) requestAnimationFrame(tick);
      else el.textContent = isFloat ? target.toFixed(1) : target.toLocaleString();
    }
    requestAnimationFrame(tick);
  }

  var counterObserver = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
        counterObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });

  counters.forEach(function (el) { counterObserver.observe(el); });

  /* ── FAQ accordion ──────────────────────────────────────── */
  document.querySelectorAll('.gd-faq__q').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var expanded = this.getAttribute('aria-expanded') === 'true';
      var answerId = this.getAttribute('aria-controls');
      var answer   = document.getElementById(answerId);

      document.querySelectorAll('.gd-faq__q').forEach(function (b) {
        b.setAttribute('aria-expanded', 'false');
      });
      document.querySelectorAll('.gd-faq__a').forEach(function (a) {
        a.classList.remove('is-open');
      });

      if (!expanded && answer) {
        this.setAttribute('aria-expanded', 'true');
        answer.classList.add('is-open');
      }
    });
  });

  /* ── Scroll reveal ──────────────────────────────────────── */
  var revealObserver = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  document.querySelectorAll('.gd-reveal').forEach(function (el) {
    revealObserver.observe(el);
  });

  /* ── Smooth scroll ──────────────────────────────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener('click', function (e) {
      var target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

})();
</script>

<?php get_footer(); ?>
