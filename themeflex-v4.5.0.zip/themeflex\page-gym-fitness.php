<?php
/**
 * Template Name: TF — Boutique Fitness Studio
 * Description:   Premium boutique fitness / group class studio landing page.
 * Namespace:     --gf-*
 * Google Fonts:  Bebas Neue + Nunito Sans
 * Palette:       Coral #FF5A5F / Charcoal #1E1E2E / Pale #F7F7FF / Teal #00BFA5 / White #FFFFFF
 * Hero scene:    CSS group class scene: instructor on podium, class participants, sound bars, heart rate pulse
 */

defined('ABSPATH') || exit;
get_header();
?>

<!-- ============================================================
     BOUTIQUE FITNESS STUDIO — PREMIUM TEMPLATE
     ============================================================ -->
<div class="gf-wrap">

<!-- ── GOOGLE FONTS ─────────────────────────────────────────── -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Nunito+Sans:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">

<style>
/* ── DESIGN TOKENS ──────────────────────────────────────────── */
:root{
  --gf-coral:#FF5A5F;
  --gf-coral-dk:#E04045;
  --gf-coral-lt:#FF8A8E;
  --gf-charcoal:#1E1E2E;
  --gf-charcoal-lt:#252538;
  --gf-charcoal-mid:#2E2E45;
  --gf-pale:#F7F7FF;
  --gf-pale-dk:#EAEAF5;
  --gf-teal:#00BFA5;
  --gf-teal-dk:#009688;
  --gf-teal-lt:#4DD0C4;
  --gf-white:#FFFFFF;
  --gf-silver:#888898;
  --gf-f-head:'Bebas Neue',sans-serif;
  --gf-f-body:'Nunito Sans',sans-serif;
  --gf-r:6px;
  --gf-r-xl:16px;
  --gf-sh:0 8px 32px rgba(0,0,0,.35);
  --gf-sh-coral:0 4px 24px rgba(255,90,95,.35)
}

/* ── BASE ───────────────────────────────────────────────────── */
.gf-wrap{font-family:var(--gf-f-body);color:var(--gf-charcoal);overflow-x:hidden}
.gf-wrap *,
.gf-wrap *::before,
.gf-wrap *::after{box-sizing:border-box;margin:0;padding:0}
.gf-wrap a{color:inherit;text-decoration:none}

/* ── LAYOUT ─────────────────────────────────────────────────── */
.gf-container{max-width:1180px;margin:0 auto;padding:0 24px}
.gf-section{padding:96px 0}
.gf-section--dark{background:var(--gf-charcoal)}
.gf-section--mid{background:var(--gf-charcoal-mid)}
.gf-section--pale{background:var(--gf-pale)}
.gf-section--pale-dk{background:var(--gf-pale-dk)}
.gf-section--white{background:var(--gf-white)}
.gf-section--teal{background:var(--gf-teal)}

/* ── TYPOGRAPHY ─────────────────────────────────────────────── */
.gf-eyebrow{
  font-family:var(--gf-f-body);font-size:.72rem;
  letter-spacing:.22em;text-transform:uppercase;font-weight:800;
  color:var(--gf-coral);margin-bottom:14px
}
.gf-eyebrow--teal{color:var(--gf-teal)}
.gf-eyebrow--dark{color:var(--gf-charcoal)}
.gf-h1{
  font-family:var(--gf-f-head);
  font-size:clamp(4rem,10vw,9rem);
  line-height:.92;letter-spacing:.02em;color:var(--gf-white)
}
.gf-h1 span{color:var(--gf-coral)}
.gf-h2{
  font-family:var(--gf-f-head);
  font-size:clamp(2.8rem,6vw,5rem);
  line-height:.95;letter-spacing:.03em
}
.gf-h3{
  font-family:var(--gf-f-head);
  font-size:1.8rem;letter-spacing:.03em
}
.gf-lead{font-size:1.05rem;line-height:1.75;font-weight:400}
.gf-sub{font-size:.92rem;line-height:1.7}

/* ── BUTTONS ────────────────────────────────────────────────── */
.gf-btn{
  display:inline-flex;align-items:center;gap:8px;
  font-family:var(--gf-f-body);font-size:.85rem;font-weight:800;
  letter-spacing:.1em;text-transform:uppercase;
  padding:14px 32px;border-radius:99px;
  border:2px solid transparent;cursor:pointer;
  transition:all .25s;white-space:nowrap
}
.gf-btn--coral{
  background:var(--gf-coral);color:var(--gf-white);border-color:var(--gf-coral);
  box-shadow:var(--gf-sh-coral)
}
.gf-btn--coral:hover{background:var(--gf-coral-dk);border-color:var(--gf-coral-dk);transform:translateY(-2px)}
.gf-btn--teal{
  background:var(--gf-teal);color:var(--gf-white);border-color:var(--gf-teal)
}
.gf-btn--teal:hover{background:var(--gf-teal-dk);transform:translateY(-2px)}
.gf-btn--outline-white{
  background:transparent;color:var(--gf-white);border-color:rgba(255,255,255,.4)
}
.gf-btn--outline-white:hover{background:rgba(255,255,255,.1);border-color:var(--gf-white)}

/* ── HERO ───────────────────────────────────────────────────── */
.gf-hero{
  min-height:100vh;position:relative;overflow:hidden;
  background:linear-gradient(150deg,var(--gf-charcoal) 0%,var(--gf-charcoal-lt) 50%,#1a1a30 100%);
  display:flex;align-items:center
}

/* diagonal stripe overlay */
.gf-hero::before{
  content:'';position:absolute;inset:0;
  background:repeating-linear-gradient(
    -55deg,
    transparent 0px,
    transparent 30px,
    rgba(255,90,95,.03) 30px,
    rgba(255,90,95,.03) 31px
  );pointer-events:none
}

/* CSS CLASS SCENE */
.gf-hero-scene{
  position:absolute;right:0;top:0;bottom:0;width:540px;z-index:2
}
.gf-hero-scene::before{
  content:'';position:absolute;inset:0;left:-80px;
  background:linear-gradient(to right,var(--gf-charcoal),transparent 55%);
  z-index:10;pointer-events:none
}

/* studio floor */
.gf-studio-floor{
  position:absolute;bottom:0;left:0;right:0;height:80px;
  background:linear-gradient(to bottom,#1a1a2a,#111);
  border-top:1px solid rgba(255,90,95,.15)
}
/* floor reflection strip */
.gf-studio-floor::before{
  content:'';position:absolute;top:0;left:0;right:0;height:1px;
  background:linear-gradient(to right,transparent,rgba(255,90,95,.4),transparent)
}

/* stage / podium */
.gf-podium{
  position:absolute;bottom:80px;left:50%;transform:translateX(-50%);
  width:90px;height:20px;
  background:linear-gradient(to bottom,var(--gf-coral-dk),#c03035);
  border-radius:4px 4px 0 0
}

/* instructor figure */
@keyframes gf-instructor-pump{
  0%,100%{bottom:100px}
  50%{bottom:118px}
}
.gf-instructor{
  position:absolute;left:calc(50% - 20px);transform:translateX(-50%);
  animation:gf-instructor-pump 1.2s ease-in-out infinite;
  bottom:100px
}
.gf-ins-head{
  width:34px;height:40px;border-radius:50% 50% 45% 45%;
  background:linear-gradient(to bottom,#8B5C30,#c48040);
  position:relative;left:50%;transform:translateX(-50%)
}
/* ponytail */
.gf-ins-head::before{
  content:'';position:absolute;top:0;left:0;right:0;height:18px;
  background:#1a1a1a;border-radius:50% 50% 0 0
}
.gf-ins-head::after{
  content:'';position:absolute;top:10px;right:-10px;
  width:4px;height:20px;background:#1a1a1a;border-radius:2px;
  transform:rotate(30deg)
}
.gf-ins-body{
  width:42px;height:60px;margin:0 auto;
  background:linear-gradient(to bottom,var(--gf-coral),var(--gf-coral-dk));
  border-radius:5px 5px 2px 2px;position:relative
}
/* mic clip */
.gf-ins-body::before{
  content:'🎤';position:absolute;top:-10px;left:-14px;font-size:.9rem
}
/* arm raised for class motivation */
.gf-ins-arm-l{
  position:absolute;top:44px;left:-10px;
  width:12px;height:44px;border-radius:6px;
  background:var(--gf-coral);transform:rotate(-75deg);transform-origin:top center
}
.gf-ins-arm-r{
  position:absolute;top:44px;right:-10px;
  width:12px;height:44px;border-radius:6px;
  background:var(--gf-coral);transform:rotate(30deg);transform-origin:top center
}
.gf-ins-legs{
  width:42px;height:52px;margin:0 auto;
  background:linear-gradient(to bottom,#111,#0a0a0a);position:relative
}
.gf-ins-legs::before,
.gf-ins-legs::after{
  content:'';position:absolute;bottom:0;
  width:18px;height:10px;background:#111;border-radius:0 0 4px 4px
}
.gf-ins-legs::before{left:2px}
.gf-ins-legs::after{right:2px}

/* class participants */
@keyframes gf-jump{
  0%,100%{bottom:80px}
  50%{bottom:98px}
}
.gf-participant{
  position:absolute;bottom:80px
}
.gf-participant:nth-child(1){left:60px;animation:gf-jump 1.1s ease-in-out infinite;animation-delay:.15s}
.gf-participant:nth-child(2){left:130px;animation:gf-jump 1.1s ease-in-out infinite;animation-delay:.4s}
.gf-participant:nth-child(3){right:60px;animation:gf-jump 1.1s ease-in-out infinite;animation-delay:.25s}
.gf-participant:nth-child(4){right:130px;animation:gf-jump 1.1s ease-in-out infinite;animation-delay:.6s}

.gf-pfig{width:30px;position:relative}
.gf-pfig-head{
  width:24px;height:28px;border-radius:50%;
  margin:0 auto;position:relative
}
.gf-pfig-body{
  width:26px;height:40px;margin:0 auto;
  border-radius:4px 4px 2px 2px;position:relative
}
/* arms raised */
.gf-pfig-arm-l{
  position:absolute;top:-30px;left:-6px;
  width:8px;height:28px;border-radius:4px;
  transform:rotate(-50deg);transform-origin:bottom center
}
.gf-pfig-arm-r{
  position:absolute;top:-30px;right:-6px;
  width:8px;height:28px;border-radius:4px;
  transform:rotate(50deg);transform-origin:bottom center
}
.gf-pfig-legs{
  width:26px;height:38px;margin:0 auto;position:relative
}
.gf-pfig-legs::before,
.gf-pfig-legs::after{
  content:'';position:absolute;bottom:0;
  width:11px;height:38px;border-radius:4px 4px 0 0
}
.gf-pfig-legs::before{left:0}
.gf-pfig-legs::after{right:0}

/* participant 1 — coral/teal */
.gf-p1 .gf-pfig-head{background:linear-gradient(to bottom,#c48040,#f0b870)}
.gf-p1 .gf-pfig-body{background:var(--gf-teal)}
.gf-p1 .gf-pfig-arm-l,.gf-p1 .gf-pfig-arm-r{background:var(--gf-teal)}
.gf-p1 .gf-pfig-legs::before,.gf-p1 .gf-pfig-legs::after{background:#111}

/* participant 2 — pale/purple */
.gf-p2 .gf-pfig-head{background:linear-gradient(to bottom,#1a1a1a,#444)}
.gf-p2 .gf-pfig-body{background:#7C3AED}
.gf-p2 .gf-pfig-arm-l,.gf-p2 .gf-pfig-arm-r{background:#7C3AED}
.gf-p2 .gf-pfig-legs::before,.gf-p2 .gf-pfig-legs::after{background:#333}

/* participant 3 — orange */
.gf-p3 .gf-pfig-head{background:linear-gradient(to bottom,#5C3317,#8B5C30)}
.gf-p3 .gf-pfig-body{background:#F59E0B}
.gf-p3 .gf-pfig-arm-l,.gf-p3 .gf-pfig-arm-r{background:#F59E0B}
.gf-p3 .gf-pfig-legs::before,.gf-p3 .gf-pfig-legs::after{background:#1a1a1a}

/* participant 4 — pink/white */
.gf-p4 .gf-pfig-head{background:linear-gradient(to bottom,#f5d5b0,#e8b870)}
.gf-p4 .gf-pfig-body{background:#EC4899}
.gf-p4 .gf-pfig-arm-l,.gf-p4 .gf-pfig-arm-r{background:#EC4899}
.gf-p4 .gf-pfig-legs::before,.gf-p4 .gf-pfig-legs::after{background:#666}

/* heart rate monitor */
@keyframes gf-hr-draw{
  0%{stroke-dashoffset:200}
  100%{stroke-dashoffset:0}
}
.gf-heart-rate{
  position:absolute;top:30px;right:20px;z-index:5;
  background:rgba(30,30,46,.85);border:1px solid rgba(255,90,95,.35);
  border-radius:var(--gf-r);padding:12px 16px;width:150px
}
.gf-hr-label{
  font-family:var(--gf-f-body);font-size:.65rem;font-weight:800;
  letter-spacing:.12em;text-transform:uppercase;color:var(--gf-coral);
  margin-bottom:6px
}
.gf-hr-num{
  font-family:var(--gf-f-head);font-size:2rem;color:var(--gf-white);line-height:1
}
.gf-hr-unit{font-size:.75rem;color:rgba(255,255,255,.5);margin-left:4px}
.gf-hr-line{margin-top:8px}

/* sound equaliser bars */
@keyframes gf-bar-eq{
  0%,100%{height:6px}
  50%{height:var(--gf-bh)}
}
.gf-eq{
  position:absolute;top:20px;left:20px;z-index:5;
  display:flex;align-items:flex-end;gap:3px;height:40px
}
.gf-eq-bar{
  width:5px;border-radius:2px 2px 0 0;
  background:linear-gradient(to top,var(--gf-coral),var(--gf-coral-lt));
  animation:gf-bar-eq .6s ease-in-out infinite alternate
}
<?php
srand(crc32('gf-eq'));
for($i=1;$i<=10;$i++){
  $h=rand(10,36);
  $del=round($i*0.08,2);
  echo ".gf-eq-bar:nth-child({$i}){{--gf-bh:{$h}px;animation-delay:{$del}s}\n";
}
?>

/* floating pill badges */
@keyframes gf-pill-float{
  0%,100%{transform:translateY(0)}
  50%{transform:translateY(-8px)}
}
.gf-hero-pill{
  position:absolute;z-index:5;
  background:rgba(30,30,46,.9);
  border:1px solid rgba(0,191,165,.4);border-radius:99px;
  padding:8px 16px;
  font-family:var(--gf-f-body);font-size:.75rem;font-weight:700;
  text-transform:uppercase;letter-spacing:.1em;color:var(--gf-white);
  animation:gf-pill-float 3s ease-in-out infinite
}
.gf-hero-pill::before{
  content:'';display:inline-block;width:7px;height:7px;border-radius:50%;
  background:var(--gf-teal);margin-right:8px;vertical-align:middle
}

/* hero layout */
.gf-hero-content{position:relative;z-index:3;max-width:560px}
.gf-hero-badge{
  display:inline-flex;align-items:center;gap:8px;
  background:rgba(255,90,95,.12);border:1px solid rgba(255,90,95,.35);
  border-radius:99px;padding:6px 16px;margin-bottom:28px;
  font-size:.78rem;font-weight:800;letter-spacing:.14em;
  text-transform:uppercase;color:var(--gf-coral-lt)
}
.gf-hero-badge::before{content:'💥';font-size:.9rem}
.gf-hero-sub{
  font-size:1.05rem;line-height:1.8;color:rgba(255,255,255,.72);
  margin:24px 0 38px;font-weight:400
}
.gf-hero-btns{display:flex;gap:16px;flex-wrap:wrap}
.gf-hero-strip{
  display:flex;gap:36px;margin-top:48px;padding-top:40px;
  border-top:1px solid rgba(255,255,255,.1);flex-wrap:wrap
}
.gf-hero-strip-item{
  display:flex;align-items:center;gap:8px;
  font-size:.8rem;font-weight:700;text-transform:uppercase;
  letter-spacing:.08em;color:rgba(255,255,255,.6)
}
.gf-hero-strip-item::before{content:'✓';color:var(--gf-teal);font-weight:900}

/* ── TICKER ─────────────────────────────────────────────────── */
.gf-ticker{
  background:var(--gf-coral);overflow:hidden;padding:14px 0;white-space:nowrap
}
@keyframes gf-ticker-scroll{
  0%{transform:translateX(0)}
  100%{transform:translateX(-50%)}
}
.gf-ticker-track{
  display:inline-flex;gap:0;animation:gf-ticker-scroll 22s linear infinite
}
.gf-ticker-item{
  font-family:var(--gf-f-head);font-size:1.1rem;letter-spacing:.08em;
  color:var(--gf-white);padding:0 28px;display:inline-flex;align-items:center;gap:12px
}
.gf-ticker-item::after{content:'✦';font-size:.7rem;opacity:.6}

/* ── STATS ──────────────────────────────────────────────────── */
.gf-stats-grid{
  display:grid;grid-template-columns:repeat(4,1fr);gap:2px;
  background:rgba(255,255,255,.05)
}
.gf-stat-card{
  background:var(--gf-charcoal-lt);padding:44px 24px;text-align:center;
  border-bottom:3px solid transparent;transition:border-color .3s
}
.gf-stat-card:hover{border-bottom-color:var(--gf-coral)}
.gf-stat-num{
  font-family:var(--gf-f-head);font-size:clamp(2.5rem,6vw,4rem);
  color:var(--gf-coral-lt);line-height:1;display:block
}
.gf-stat-label{
  font-size:.75rem;color:var(--gf-silver);text-transform:uppercase;
  letter-spacing:.14em;margin-top:10px;display:block;font-weight:700
}

/* ── CLASS TIMETABLE ────────────────────────────────────────── */
.gf-timetable{
  display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-top:56px
}
.gf-class-card{
  background:var(--gf-pale);border-radius:var(--gf-r-xl);
  overflow:hidden;transition:transform .3s,box-shadow .3s;
  border:2px solid transparent
}
.gf-class-card:hover{
  transform:translateY(-5px);box-shadow:var(--gf-sh);border-color:var(--gf-coral)
}
.gf-class-top{
  padding:28px;position:relative;overflow:hidden
}
.gf-class-icon{font-size:2.5rem;margin-bottom:12px;display:block}
.gf-class-name{
  font-family:var(--gf-f-head);font-size:1.6rem;color:var(--gf-charcoal);margin-bottom:4px
}
.gf-class-duration{
  font-size:.78rem;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:var(--gf-coral)
}
.gf-class-body{
  padding:0 28px 28px
}
.gf-class-desc{font-size:.88rem;color:#555;line-height:1.7;margin-bottom:16px}
.gf-class-intensity{
  display:flex;align-items:center;gap:8px;
  font-size:.75rem;font-weight:800;text-transform:uppercase;
  letter-spacing:.1em;color:var(--gf-charcoal)
}
.gf-intensity-dots{display:flex;gap:3px}
.gf-intensity-dot{
  width:10px;height:10px;border-radius:50%;background:var(--gf-pale-dk)
}
.gf-intensity-dot.gf-active{background:var(--gf-coral)}

/* ── TRAINERS ───────────────────────────────────────────────── */
.gf-trainers-wrap{
  display:grid;grid-template-columns:1fr 1fr;gap:32px;margin-top:56px
}
.gf-trainer-card{
  background:var(--gf-charcoal-lt);border-radius:var(--gf-r-xl);
  overflow:hidden;display:flex;gap:0;transition:transform .3s
}
.gf-trainer-card:hover{transform:translateY(-5px)}
.gf-trainer-avatar{
  width:160px;flex-shrink:0;
  display:flex;align-items:flex-end;justify-content:center;
  padding-bottom:12px;position:relative;overflow:hidden
}
.gf-trainer-info{padding:28px 24px 24px;flex:1}
.gf-trainer-name{
  font-family:var(--gf-f-head);font-size:1.8rem;color:var(--gf-white);margin-bottom:4px
}
.gf-trainer-role{
  font-size:.75rem;font-weight:800;text-transform:uppercase;
  letter-spacing:.12em;color:var(--gf-coral);margin-bottom:12px
}
.gf-trainer-bio{font-size:.88rem;color:rgba(255,255,255,.6);line-height:1.7;margin-bottom:16px}
.gf-trainer-spec-list{display:flex;flex-wrap:wrap;gap:6px}
.gf-trainer-spec{
  font-size:.72rem;font-weight:800;letter-spacing:.08em;text-transform:uppercase;
  padding:3px 10px;border-radius:99px;
  background:rgba(0,191,165,.12);color:var(--gf-teal-lt);
  border:1px solid rgba(0,191,165,.2)
}

/* CSS trainer mini-figures for cards */
.gf-tfig-mini{width:60px;height:120px;position:relative}
.gf-tfig-mini-head{position:absolute;top:0;left:50%;transform:translateX(-50%);width:26px;height:30px;border-radius:50%}
.gf-tfig-mini-body{position:absolute;top:32px;left:50%;transform:translateX(-50%);width:32px;height:48px;border-radius:4px 4px 2px 2px}
.gf-tfig-mini-al,.gf-tfig-mini-ar{position:absolute;top:36px;width:9px;height:32px;border-radius:5px}
.gf-tfig-mini-al{left:4px;transform:rotate(12deg);transform-origin:top center}
.gf-tfig-mini-ar{right:4px;transform:rotate(-12deg);transform-origin:top center}
.gf-tfig-mini-legs{position:absolute;bottom:0;left:50%;transform:translateX(-50%);width:32px;height:42px}
.gf-tfig-mini-ll,.gf-tfig-mini-lr{position:absolute;bottom:0;width:14px;height:42px;border-radius:4px 4px 0 0}
.gf-tfig-mini-ll{left:0}.gf-tfig-mini-lr{right:0}

/* trainer A — coral */
.gf-ta .gf-trainer-avatar{background:linear-gradient(to bottom,#1a0a0a,var(--gf-charcoal-lt))}
.gf-ta .gf-tfig-mini-head{background:linear-gradient(to bottom,#5C3317,#8B5C30)}
.gf-ta .gf-tfig-mini-body{background:linear-gradient(135deg,var(--gf-coral),var(--gf-coral-dk))}
.gf-ta .gf-tfig-mini-al,.gf-ta .gf-tfig-mini-ar{background:var(--gf-coral)}
.gf-ta .gf-tfig-mini-ll,.gf-ta .gf-tfig-mini-lr{background:#111}

/* trainer B — teal */
.gf-tb .gf-trainer-avatar{background:linear-gradient(to bottom,#0a1a18,var(--gf-charcoal-lt))}
.gf-tb .gf-tfig-mini-head{background:linear-gradient(to bottom,#1a1a1a,#444)}
.gf-tb .gf-tfig-mini-body{background:linear-gradient(135deg,var(--gf-teal),var(--gf-teal-dk))}
.gf-tb .gf-tfig-mini-al,.gf-tb .gf-tfig-mini-ar{background:var(--gf-teal)}
.gf-tb .gf-tfig-mini-ll,.gf-tb .gf-tfig-mini-lr{background:#222}

/* trainer C — purple */
.gf-tc .gf-trainer-avatar{background:linear-gradient(to bottom,#0f0a1a,var(--gf-charcoal-lt))}
.gf-tc .gf-tfig-mini-head{background:linear-gradient(to bottom,#c48040,#f0b870)}
.gf-tc .gf-tfig-mini-body{background:linear-gradient(135deg,#7C3AED,#5B21B6)}
.gf-tc .gf-tfig-mini-al,.gf-tc .gf-tfig-mini-ar{background:#7C3AED}
.gf-tc .gf-tfig-mini-ll,.gf-tc .gf-tfig-mini-lr{background:#333}

/* trainer D — amber */
.gf-td .gf-trainer-avatar{background:linear-gradient(to bottom,#1a1200,var(--gf-charcoal-lt))}
.gf-td .gf-tfig-mini-head{background:linear-gradient(to bottom,#f5d5b0,#e8b870)}
.gf-td .gf-tfig-mini-body{background:linear-gradient(135deg,#F59E0B,#D97706)}
.gf-td .gf-tfig-mini-al,.gf-td .gf-tfig-mini-ar{background:#F59E0B}
.gf-td .gf-tfig-mini-ll,.gf-td .gf-tfig-mini-lr{background:#444}

/* ── MEMBERSHIP ─────────────────────────────────────────────── */
.gf-membership-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;align-items:start}
.gf-mem-card{border-radius:var(--gf-r-xl);overflow:hidden;transition:transform .3s}
.gf-mem-card:hover{transform:translateY(-6px)}
.gf-mem-standard{background:var(--gf-charcoal-lt);border:2px solid rgba(255,255,255,.08)}
.gf-mem-featured{
  background:var(--gf-charcoal-mid);border:2px solid var(--gf-coral);
  transform:scale(1.04);box-shadow:var(--gf-sh-coral)
}
.gf-mem-featured:hover{transform:scale(1.04) translateY(-6px)}
.gf-mem-premium{background:var(--gf-charcoal-lt);border:2px solid rgba(255,255,255,.08)}
.gf-mem-top{padding:32px 28px 24px;border-bottom:1px solid rgba(255,255,255,.07)}
.gf-mem-badge{
  display:inline-block;margin-bottom:14px;
  font-size:.68rem;font-weight:800;letter-spacing:.16em;text-transform:uppercase;
  padding:4px 12px;border-radius:99px;
  background:rgba(255,90,95,.12);color:var(--gf-coral-lt)
}
.gf-mem-featured .gf-mem-badge{background:var(--gf-coral);color:var(--gf-white)}
.gf-mem-name{
  font-family:var(--gf-f-head);font-size:2rem;color:var(--gf-white);margin-bottom:8px
}
.gf-mem-price{
  font-family:var(--gf-f-head);font-size:3.5rem;color:var(--gf-coral-lt);line-height:1
}
.gf-mem-price sup{font-size:1.4rem;vertical-align:top;margin-top:.5rem}
.gf-mem-period{font-size:.8rem;color:var(--gf-silver);margin-top:4px}
.gf-mem-body{padding:24px 28px}
.gf-mem-feat{
  display:flex;align-items:flex-start;gap:10px;
  padding:8px 0;border-bottom:1px solid rgba(255,255,255,.06);
  font-size:.9rem;color:rgba(255,255,255,.75)
}
.gf-mem-feat:last-child{border-bottom:none}
.gf-mem-check{color:var(--gf-teal);flex-shrink:0;font-weight:900}
.gf-mem-featured .gf-mem-check{color:var(--gf-coral-lt)}
.gf-mem-btn{display:block;text-align:center;margin-top:20px}

/* ── TESTIMONIALS ───────────────────────────────────────────── */
.gf-testi-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
.gf-testi-card{
  background:var(--gf-pale);border-radius:var(--gf-r-xl);
  padding:32px;border-bottom:3px solid var(--gf-coral);
  transition:transform .3s
}
.gf-testi-card:hover{transform:translateY(-4px)}
.gf-testi-stars{color:var(--gf-coral);font-size:1rem;letter-spacing:2px;margin-bottom:14px}
.gf-testi-text{font-size:.95rem;color:#444;line-height:1.75;margin-bottom:20px;font-style:italic}
.gf-testi-author{display:flex;align-items:center;gap:12px;padding-top:16px;border-top:1px solid var(--gf-pale-dk)}
.gf-testi-avatar{
  width:42px;height:42px;border-radius:50%;
  background:var(--gf-charcoal);display:flex;align-items:center;justify-content:center;
  font-size:1.1rem;flex-shrink:0;border:2px solid var(--gf-coral)
}
.gf-testi-name{font-family:var(--gf-f-head);font-size:1.1rem;color:var(--gf-charcoal)}
.gf-testi-result{font-size:.78rem;color:var(--gf-teal-dk);font-weight:700}

/* ── FAQ ────────────────────────────────────────────────────── */
.gf-faq-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;max-width:960px;margin:0 auto}
.gf-faq-item{background:var(--gf-charcoal-lt);border-radius:var(--gf-r);overflow:hidden}
.gf-faq-q{
  width:100%;background:none;border:none;cursor:pointer;
  display:flex;align-items:center;justify-content:space-between;gap:16px;
  padding:20px 24px;text-align:left;
  font-family:var(--gf-f-body);font-size:.88rem;font-weight:800;
  letter-spacing:.04em;text-transform:uppercase;color:var(--gf-white);
  transition:color .25s
}
.gf-faq-q:hover{color:var(--gf-coral-lt)}
.gf-faq-icon{
  flex-shrink:0;width:26px;height:26px;border-radius:50%;
  border:2px solid rgba(255,255,255,.2);
  display:flex;align-items:center;justify-content:center;
  font-size:1.1rem;transition:all .3s;color:var(--gf-coral-lt)
}
.gf-faq-item.gf-open .gf-faq-icon{
  transform:rotate(45deg);background:var(--gf-coral);color:var(--gf-white);border-color:var(--gf-coral)
}
.gf-faq-a{max-height:0;overflow:hidden;transition:max-height .4s ease}
.gf-faq-a-inner{padding:0 24px 20px;font-size:.9rem;color:rgba(255,255,255,.65);line-height:1.75}

/* ── BOOKING ────────────────────────────────────────────────── */
.gf-booking-wrap{display:grid;grid-template-columns:1fr 1.1fr;gap:80px;align-items:start}
.gf-booking-info h2{color:var(--gf-white);margin-bottom:16px}
.gf-booking-info p{color:rgba(255,255,255,.65);line-height:1.75;margin-bottom:28px}
.gf-booking-perk{
  display:flex;align-items:center;gap:14px;padding:14px 0;
  border-bottom:1px solid rgba(255,255,255,.07)
}
.gf-booking-perk:last-child{border-bottom:none}
.gf-booking-perk-icon{
  width:40px;height:40px;border-radius:var(--gf-r);
  background:rgba(255,90,95,.1);border:1px solid rgba(255,90,95,.2);
  display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0
}
.gf-booking-perk-title{font-size:.82rem;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:var(--gf-white);margin-bottom:2px}
.gf-booking-perk-text{font-size:.88rem;color:rgba(255,255,255,.6)}
.gf-form{background:var(--gf-charcoal-lt);border-radius:var(--gf-r-xl);padding:40px;border:1px solid rgba(255,90,95,.15)}
.gf-form-title{font-family:var(--gf-f-head);font-size:2rem;color:var(--gf-white);margin-bottom:6px}
.gf-form-subtitle{font-size:.85rem;color:rgba(255,255,255,.45);margin-bottom:28px}
.gf-form-row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.gf-field{margin-bottom:16px}
.gf-field label{display:block;margin-bottom:7px;font-size:.72rem;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:rgba(255,255,255,.55)}
.gf-field input,.gf-field select,.gf-field textarea{
  width:100%;padding:12px 16px;border-radius:var(--gf-r);
  border:2px solid rgba(255,255,255,.1);
  background:rgba(255,255,255,.04);color:var(--gf-white);
  font-family:var(--gf-f-body);font-size:.9rem;
  transition:border-color .25s;outline:none
}
.gf-field input:focus,.gf-field select:focus,.gf-field textarea:focus{border-color:var(--gf-coral)}
.gf-field select option{background:var(--gf-charcoal);color:var(--gf-white)}
.gf-field textarea{min-height:100px;resize:vertical}

/* ── FOOTER CTA ─────────────────────────────────────────────── */
.gf-footer-cta{
  padding:72px 0;text-align:center;
  background:var(--gf-coral);position:relative;overflow:hidden
}
.gf-footer-cta::before{
  content:'';position:absolute;inset:0;
  background:repeating-linear-gradient(-45deg,transparent 0px,transparent 20px,rgba(0,0,0,.04) 20px,rgba(0,0,0,.04) 21px);
  pointer-events:none
}
.gf-footer-cta h2{color:var(--gf-white);margin-bottom:12px;position:relative}
.gf-footer-cta p{font-size:1.05rem;color:rgba(255,255,255,.85);max-width:480px;margin:0 auto 32px;position:relative}

/* ── SCROLL REVEAL ──────────────────────────────────────────── */
.gf-reveal{opacity:0;transform:translateY(28px);transition:opacity .6s ease,transform .6s ease}
.gf-reveal.gf-visible{opacity:1;transform:translateY(0)}

/* ── RESPONSIVE ─────────────────────────────────────────────── */
@media(max-width:1050px){.gf-hero-scene{width:400px}}
@media(max-width:880px){
  .gf-hero-scene{display:none}
  .gf-stats-grid{grid-template-columns:repeat(2,1fr)}
  .gf-timetable{grid-template-columns:repeat(2,1fr)}
  .gf-trainers-wrap{grid-template-columns:1fr}
  .gf-membership-grid{grid-template-columns:1fr}
  .gf-mem-featured{transform:none}
  .gf-testi-grid{grid-template-columns:1fr}
  .gf-faq-grid{grid-template-columns:1fr}
  .gf-booking-wrap{grid-template-columns:1fr}
}
@media(max-width:600px){
  .gf-section{padding:64px 0}
  .gf-timetable{grid-template-columns:1fr}
  .gf-stats-grid{grid-template-columns:1fr 1fr}
  .gf-form-row{grid-template-columns:1fr}
  .gf-hero-strip{flex-direction:column;gap:14px}
  .gf-hero-btns{flex-direction:column}
}
</style>

<!-- ── HERO ──────────────────────────────────────────────────── -->
<section class="gf-hero">

  <!-- CSS CLASS SCENE -->
  <div class="gf-hero-scene" aria-hidden="true">

    <!-- EQ bars -->
    <div class="gf-eq">
      <?php for($i=0;$i<10;$i++) echo "<div class='gf-eq-bar'></div>"; ?>
    </div>

    <!-- heart rate monitor -->
    <div class="gf-heart-rate">
      <div class="gf-hr-label">❤ Heart Rate</div>
      <div><span class="gf-hr-num">147</span><span class="gf-hr-unit">bpm</span></div>
      <svg class="gf-hr-line" width="118" height="28" viewBox="0 0 118 28">
        <polyline points="0,14 20,14 28,4 36,24 44,8 52,14 70,14 78,20 86,6 94,14 118,14"
          fill="none" stroke="#FF5A5F" stroke-width="2" stroke-linecap="round"/>
      </svg>
    </div>

    <!-- studio floor -->
    <div class="gf-studio-floor"></div>

    <!-- instructor podium -->
    <div class="gf-podium"></div>

    <!-- instructor -->
    <div class="gf-instructor">
      <div class="gf-ins-head"></div>
      <div class="gf-ins-body" style="position:relative">
        <div class="gf-ins-arm-l"></div>
        <div class="gf-ins-arm-r"></div>
      </div>
      <div class="gf-ins-legs"></div>
    </div>

    <!-- class participants -->
    <div class="gf-participant gf-p1">
      <div class="gf-pfig">
        <div class="gf-pfig-head"></div>
        <div class="gf-pfig-body" style="position:relative">
          <div class="gf-pfig-arm-l"></div>
          <div class="gf-pfig-arm-r"></div>
        </div>
        <div class="gf-pfig-legs"></div>
      </div>
    </div>
    <div class="gf-participant gf-p2">
      <div class="gf-pfig">
        <div class="gf-pfig-head"></div>
        <div class="gf-pfig-body" style="position:relative">
          <div class="gf-pfig-arm-l"></div>
          <div class="gf-pfig-arm-r"></div>
        </div>
        <div class="gf-pfig-legs"></div>
      </div>
    </div>
    <div class="gf-participant gf-p3">
      <div class="gf-pfig">
        <div class="gf-pfig-head"></div>
        <div class="gf-pfig-body" style="position:relative">
          <div class="gf-pfig-arm-l"></div>
          <div class="gf-pfig-arm-r"></div>
        </div>
        <div class="gf-pfig-legs"></div>
      </div>
    </div>
    <div class="gf-participant gf-p4">
      <div class="gf-pfig">
        <div class="gf-pfig-head"></div>
        <div class="gf-pfig-body" style="position:relative">
          <div class="gf-pfig-arm-l"></div>
          <div class="gf-pfig-arm-r"></div>
        </div>
        <div class="gf-pfig-legs"></div>
      </div>
    </div>

    <!-- floating pills -->
    <div class="gf-hero-pill" style="bottom:30%;right:20px;animation-delay:0s">45 min classes</div>
    <div class="gf-hero-pill" style="bottom:48%;right:15px;animation-delay:1.5s">All fitness levels</div>
    <div class="gf-hero-pill" style="bottom:64%;right:25px;animation-delay:3s">Book any class</div>

  </div><!-- /scene -->

  <div class="gf-container" style="position:relative;z-index:3">
    <div class="gf-hero-content">

      <div class="gf-hero-badge">Now Open — Leeds City Centre</div>

      <h1 class="gf-h1">
        SWEAT.<br>
        <span>PUSH.</span><br>
        REPEAT.
      </h1>

      <p class="gf-hero-sub">
        Pulse Fitness is Leeds' most energetic boutique studio — high-intensity group classes,
        world-class instructors and a community that shows up for each other, every single day.
      </p>

      <div class="gf-hero-btns">
        <a href="#booking" class="gf-btn gf-btn--coral">First Class Free</a>
        <a href="#classes" class="gf-btn gf-btn--outline-white">See Classes</a>
      </div>

      <div class="gf-hero-strip">
        <div class="gf-hero-strip-item">No Contracts</div>
        <div class="gf-hero-strip-item">All Levels Welcome</div>
        <div class="gf-hero-strip-item">Pay As You Go</div>
        <div class="gf-hero-strip-item">App Booking</div>
      </div>

    </div>
  </div>

</section><!-- /hero -->

<!-- ── TICKER ─────────────────────────────────────────────────── -->
<div class="gf-ticker" aria-hidden="true">
  <div class="gf-ticker-track">
    <?php
    $items=['HIIT','Barre','Spin','Boxing','Pilates','Yoga Flow','Core Blast','Dance Cardio','Stretch & Recover','Body Pump'];
    $double=array_merge($items,$items);
    foreach($double as $it) echo "<span class='gf-ticker-item'>".esc_html($it)."</span>";
    ?>
  </div>
</div>

<!-- ── STATS ─────────────────────────────────────────────────── -->
<section class="gf-section--dark" style="padding:0">
  <div class="gf-stats-grid">
    <?php
    $stats=[
      ['num'=>3800,'suf'=>'+','label'=>'Active Members'],
      ['num'=>45,'suf'=>'+','label'=>'Weekly Classes'],
      ['num'=>99,'suf'=>'%','label'=>'Satisfaction Score'],
      ['num'=>6,'suf'=>'','label'=>'Years in Leeds'],
    ];
    foreach($stats as $s):?>
    <div class="gf-stat-card">
      <span class="gf-stat-num" data-target="<?=esc_attr($s['num'])?>" data-suffix="<?=esc_attr($s['suf'])?>">0</span>
      <span class="gf-stat-label"><?=esc_html($s['label'])?></span>
    </div>
    <?php endforeach;?>
  </div>
</section>

<!-- ── CLASSES ───────────────────────────────────────────────── -->
<section class="gf-section gf-section--pale" id="classes">
  <div class="gf-container">

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:end;margin-bottom:0">
      <div>
        <div class="gf-eyebrow gf-eyebrow--dark">Our Timetable</div>
        <h2 class="gf-h2">Classes for Every Body</h2>
      </div>
      <p class="gf-lead" style="color:#555">
        From beginner-friendly Barre to sweat-drenched Boxing, we have something on every hour.
        All classes are 45 minutes — because your time is precious.
      </p>
    </div>

    <div class="gf-timetable">
      <?php
      $classes=[
        ['icon'=>'💥','name'=>'HIIT Blast','duration'=>'45 min','desc'=>'High-intensity intervals alternating between strength and cardio. Designed to maximise calorie burn and build functional fitness.','intensity'=>5],
        ['icon'=>'🥊','name'=>'Boxing Fit','duration'=>'45 min','desc'=>'Pad work, bag rounds and shadow boxing. No sparring — just technique, power and serious cardio.','intensity'=>5],
        ['icon'=>'🚴','name'=>'Spin Studio','duration'=>'45 min','desc'=>'Heart-pumping indoor cycling synced to incredible music. Adjust your resistance; your instructor will push you further.','intensity'=>4],
        ['icon'=>'🩰','name'=>'Barre Fusion','duration'=>'45 min','desc'=>'Ballet-inspired toning with a low-impact twist. Builds incredible core strength, flexibility and posture.','intensity'=>2],
        ['icon'=>'🧘','name'=>'Pilates Core','duration'=>'45 min','desc'=>'Mat-based Pilates focused on deep core activation, spinal alignment and breathing. Excellent for injury rehab.','intensity'=>2],
        ['icon'=>'💃','name'=>'Dance Cardio','duration'=>'45 min','desc'=>'The most fun you\'ll ever have exercising. Choreographed to chart hits — zero coordination required, maximum energy.','intensity'=>3],
      ];
      foreach($classes as $c):?>
      <div class="gf-class-card gf-reveal">
        <div class="gf-class-top">
          <span class="gf-class-icon"><?=esc_html($c['icon'])?></span>
          <div class="gf-class-name"><?=esc_html($c['name'])?></div>
          <div class="gf-class-duration"><?=esc_html($c['duration'])?></div>
        </div>
        <div class="gf-class-body">
          <p class="gf-class-desc"><?=esc_html($c['desc'])?></p>
          <div class="gf-class-intensity">
            <span>Intensity</span>
            <div class="gf-intensity-dots">
              <?php for($d=1;$d<=5;$d++): $a=$d<=$c['intensity']?'gf-active':'';?>
              <div class="gf-intensity-dot <?=$a?>"></div>
              <?php endfor;?>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach;?>
    </div>

  </div>
</section>

<!-- ── TRAINERS ──────────────────────────────────────────────── -->
<section class="gf-section gf-section--dark">
  <div class="gf-container">

    <div style="text-align:center;max-width:560px;margin:0 auto 56px">
      <div class="gf-eyebrow">Our Instructors</div>
      <h2 class="gf-h2" style="color:var(--gf-white)">The Team That<br>Pushes You</h2>
    </div>

    <div class="gf-trainers-wrap">

      <div class="gf-trainer-card gf-ta gf-reveal">
        <div class="gf-trainer-avatar">
          <div class="gf-tfig-mini" aria-hidden="true">
            <div class="gf-tfig-mini-head"></div>
            <div class="gf-tfig-mini-body"></div>
            <div class="gf-tfig-mini-al"></div><div class="gf-tfig-mini-ar"></div>
            <div class="gf-tfig-mini-legs"><div class="gf-tfig-mini-ll"></div><div class="gf-tfig-mini-lr"></div></div>
          </div>
        </div>
        <div class="gf-trainer-info">
          <div class="gf-trainer-name">Zara Mitchell</div>
          <div class="gf-trainer-role">Head Instructor — HIIT & Boxing</div>
          <p class="gf-trainer-bio">Former GB athlete and Nike Master Trainer. Zara's HIIT and Boxing Fit classes are consistently oversubscribed — members travel across the city for her sessions.</p>
          <div class="gf-trainer-spec-list">
            <span class="gf-trainer-spec">REPS Level 3</span>
            <span class="gf-trainer-spec">Nike Master Trainer</span>
            <span class="gf-trainer-spec">GB Athletics</span>
          </div>
        </div>
      </div>

      <div class="gf-trainer-card gf-tb gf-reveal">
        <div class="gf-trainer-avatar">
          <div class="gf-tfig-mini" aria-hidden="true">
            <div class="gf-tfig-mini-head"></div>
            <div class="gf-tfig-mini-body"></div>
            <div class="gf-tfig-mini-al"></div><div class="gf-tfig-mini-ar"></div>
            <div class="gf-tfig-mini-legs"><div class="gf-tfig-mini-ll"></div><div class="gf-tfig-mini-lr"></div></div>
          </div>
        </div>
        <div class="gf-trainer-info">
          <div class="gf-trainer-name">Tom Brennan</div>
          <div class="gf-trainer-role">Spin & Cardio Specialist</div>
          <p class="gf-trainer-bio">Competitive cyclist and indoor cycling coach with 9 years in boutique fitness. Tom's Spin sessions combine zone training, live metrics and playlist-perfect pacing.</p>
          <div class="gf-trainer-spec-list">
            <span class="gf-trainer-spec">Mad Dogg Certified</span>
            <span class="gf-trainer-spec">British Cycling Coach</span>
          </div>
        </div>
      </div>

      <div class="gf-trainer-card gf-tc gf-reveal">
        <div class="gf-trainer-avatar">
          <div class="gf-tfig-mini" aria-hidden="true">
            <div class="gf-tfig-mini-head"></div>
            <div class="gf-tfig-mini-body"></div>
            <div class="gf-tfig-mini-al"></div><div class="gf-tfig-mini-ar"></div>
            <div class="gf-tfig-mini-legs"><div class="gf-tfig-mini-ll"></div><div class="gf-tfig-mini-lr"></div></div>
          </div>
        </div>
        <div class="gf-trainer-info">
          <div class="gf-trainer-name">Priya Das</div>
          <div class="gf-trainer-role">Barre & Pilates Instructor</div>
          <p class="gf-trainer-bio">Trained at the Royal Ballet School and certified in STOTT Pilates. Priya brings extraordinary precision and calm to every class — students leave stronger without knowing why.</p>
          <div class="gf-trainer-spec-list">
            <span class="gf-trainer-spec">RAD Certified</span>
            <span class="gf-trainer-spec">STOTT Pilates</span>
            <span class="gf-trainer-spec">Physio Rehab</span>
          </div>
        </div>
      </div>

      <div class="gf-trainer-card gf-td gf-reveal">
        <div class="gf-trainer-avatar">
          <div class="gf-tfig-mini" aria-hidden="true">
            <div class="gf-tfig-mini-head"></div>
            <div class="gf-tfig-mini-body"></div>
            <div class="gf-tfig-mini-al"></div><div class="gf-tfig-mini-ar"></div>
            <div class="gf-tfig-mini-legs"><div class="gf-tfig-mini-ll"></div><div class="gf-tfig-mini-lr"></div></div>
          </div>
        </div>
        <div class="gf-trainer-info">
          <div class="gf-trainer-name">Leah Morgan</div>
          <div class="gf-trainer-role">Dance Cardio & HIIT</div>
          <p class="gf-trainer-bio">West End performer turned fitness instructor. Leah's Dance Cardio classes sell out 8 hours after the timetable drops — her energy is genuinely contagious.</p>
          <div class="gf-trainer-spec-list">
            <span class="gf-trainer-spec">REPS Level 3</span>
            <span class="gf-trainer-spec">West End Performer</span>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- ── MEMBERSHIP ────────────────────────────────────────────── -->
<section class="gf-section gf-section--mid">
  <div class="gf-container">

    <div style="text-align:center;max-width:560px;margin:0 auto 60px">
      <div class="gf-eyebrow">Membership</div>
      <h2 class="gf-h2" style="color:var(--gf-white)">Simple Pricing, No Surprises</h2>
    </div>

    <div class="gf-membership-grid">

      <div class="gf-mem-card gf-mem-standard gf-reveal">
        <div class="gf-mem-top">
          <div class="gf-mem-badge">Casual</div>
          <div class="gf-mem-name">Drop-In</div>
          <div class="gf-mem-price"><sup>£</sup>14</div>
          <div class="gf-mem-period">per class · no commitment</div>
        </div>
        <div class="gf-mem-body">
          <?php foreach(['Any single class','App booking','Towel hire included','Post-class protein bar'] as $f):?>
          <div class="gf-mem-feat"><span class="gf-mem-check">✓</span><span><?=esc_html($f)?></span></div>
          <?php endforeach;?>
          <div class="gf-mem-btn"><a href="#booking" class="gf-btn gf-btn--outline-white" style="width:100%;justify-content:center">Book a Class</a></div>
        </div>
      </div>

      <div class="gf-mem-card gf-mem-featured gf-reveal">
        <div class="gf-mem-top">
          <div class="gf-mem-badge">⚡ Best Value</div>
          <div class="gf-mem-name">Unlimited</div>
          <div class="gf-mem-price"><sup>£</sup>79</div>
          <div class="gf-mem-period">per month · cancel any time</div>
        </div>
        <div class="gf-mem-body">
          <?php foreach(['Unlimited classes every month','Priority 48hr advance booking','Free guest pass each month','Nutrition plan access','Member app & wearable sync','10% off merchandise','Monthly progress check-in'] as $f):?>
          <div class="gf-mem-feat"><span class="gf-mem-check">✓</span><span><?=esc_html($f)?></span></div>
          <?php endforeach;?>
          <div class="gf-mem-btn"><a href="#booking" class="gf-btn gf-btn--coral" style="width:100%;justify-content:center">Join Now</a></div>
        </div>
      </div>

      <div class="gf-mem-card gf-mem-premium gf-reveal">
        <div class="gf-mem-top">
          <div class="gf-mem-badge">Team</div>
          <div class="gf-mem-name">Class Pack</div>
          <div class="gf-mem-price"><sup>£</sup>99</div>
          <div class="gf-mem-period">10 classes · valid 3 months</div>
        </div>
        <div class="gf-mem-body">
          <?php foreach(['10 classes to use flexibly','Valid for 3 months','Shareable with a friend','App tracking included','No monthly commitment'] as $f):?>
          <div class="gf-mem-feat"><span class="gf-mem-check">✓</span><span><?=esc_html($f)?></span></div>
          <?php endforeach;?>
          <div class="gf-mem-btn"><a href="#booking" class="gf-btn gf-btn--teal" style="width:100%;justify-content:center">Get Pack</a></div>
        </div>
      </div>

    </div>
    <p style="text-align:center;margin-top:24px;color:rgba(255,255,255,.4);font-size:.88rem">
      ✨ Your <strong style="color:var(--gf-coral-lt)">first class is completely free</strong> — no card required. Just show up.
    </p>

  </div>
</section>

<!-- ── TESTIMONIALS ──────────────────────────────────────────── -->
<section class="gf-section gf-section--pale">
  <div class="gf-container">

    <div style="text-align:center;max-width:560px;margin:0 auto 56px">
      <div class="gf-eyebrow gf-eyebrow--dark">Real Results</div>
      <h2 class="gf-h2">What Our Members Say</h2>
    </div>

    <div class="gf-testi-grid">
      <?php
      $testis=[
        ['text'=>'I\'ve tried every gym in Leeds and nothing comes close. Zara\'s HIIT class is the hardest 45 minutes of my week and I look forward to it every single time.','name'=>'Chloe Watkins','result'=>'Lost 14kg in 4 months','avatar'=>'💪'],
        ['text'=>'Priya\'s Pilates class completely fixed my back pain after 3 years of suffering. I come twice a week now and I\'ve never felt stronger. This place is genuinely life-changing.','name'=>'James Thornton','result'=>'Chronic back pain resolved','avatar'=>'🧘'],
        ['text'=>'Dance Cardio with Leah is the highlight of my week. I laughed so hard in my first class that I forgot I was exercising. My fitness has transformed without any dread.','name'=>'Naomi Clarke','result'=>'Running a 10K after 3 months','avatar'=>'💃'],
      ];
      foreach($testis as $t):?>
      <div class="gf-testi-card gf-reveal">
        <div class="gf-testi-stars">★★★★★</div>
        <p class="gf-testi-text">"<?=esc_html($t['text'])?>"</p>
        <div class="gf-testi-author">
          <div class="gf-testi-avatar"><?=esc_html($t['avatar'])?></div>
          <div>
            <div class="gf-testi-name"><?=esc_html($t['name'])?></div>
            <div class="gf-testi-result"><?=esc_html($t['result'])?></div>
          </div>
        </div>
      </div>
      <?php endforeach;?>
    </div>

  </div>
</section>

<!-- ── FAQ ───────────────────────────────────────────────────── -->
<section class="gf-section gf-section--dark">
  <div class="gf-container">

    <div style="text-align:center;max-width:560px;margin:0 auto 52px">
      <div class="gf-eyebrow">Questions</div>
      <h2 class="gf-h2" style="color:var(--gf-white)">Got Questions?</h2>
    </div>

    <div class="gf-faq-grid">
      <?php
      $faqs=[
        ['q'=>'Do I need to be fit to join?','a'=>'Absolutely not. Every class is designed to be scalable — our instructors offer modifications for every movement. We see complete beginners thrive alongside seasoned athletes every single day.'],
        ['q'=>'How do I book my first free class?','a'=>'Download the Pulse app or use this website to reserve your free class. No payment details, no commitment. Just pick a class, show up 10 minutes early and introduce yourself at the desk.'],
        ['q'=>'What should I bring?','a'=>'A water bottle and clean trainers are essential. We provide mats, equipment and freshly laundered towels for all classes. There are changing rooms with showers on site.'],
        ['q'=>'Can I cancel if I can\'t make it?','a'=>'Yes — cancel via the app up to 6 hours before your class with no charge. Late cancellations or no-shows will use one credit from your pack or incur a £5 fee for members on Unlimited.'],
        ['q'=>'Is there parking nearby?','a'=>'We\'re a 3-minute walk from Leeds City Station. The NCP on King Street is also 4 minutes on foot — members can grab a discounted parking voucher at the front desk.'],
        ['q'=>'Do you offer corporate memberships?','a'=>'Yes — we offer group corporate packages from 5 employees with dedicated invoicing, usage dashboards and optional on-site taster sessions. Contact us at hello@pulsefitness.co.uk for a quote.'],
      ];
      foreach($faqs as $i=>$f):?>
      <div class="gf-faq-item">
        <button class="gf-faq-q" aria-expanded="false" aria-controls="gf-faq-a-<?=$i?>">
          <?=esc_html($f['q'])?>
          <span class="gf-faq-icon" aria-hidden="true">+</span>
        </button>
        <div class="gf-faq-a" id="gf-faq-a-<?=$i?>" role="region">
          <div class="gf-faq-a-inner"><?=esc_html($f['a'])?></div>
        </div>
      </div>
      <?php endforeach;?>
    </div>

  </div>
</section>

<!-- ── BOOKING ───────────────────────────────────────────────── -->
<section class="gf-section gf-section--mid" id="booking">
  <div class="gf-container">
    <div class="gf-booking-wrap">

      <div class="gf-booking-info gf-reveal">
        <div class="gf-eyebrow">Claim Your Free Class</div>
        <h2 class="gf-h2" style="font-size:clamp(2rem,5vw,3.5rem)">Your First Class Is On Us</h2>
        <p>No payment card. No commitment. Just come and try it. We think you'll be hooked by the end of the warm-up.</p>

        <?php
        $perks=[
          ['icon'=>'⚡','title'=>'Same-Day Booking','text'=>'Classes fill fast — book now and secure your spot today.'],
          ['icon'=>'🎉','title'=>'Zero Obligation','text'=>'Try one class completely free before you decide anything.'],
          ['icon'=>'🤝','title'=>'Friendly Welcome','text'=>'Every new member gets met at the door and introduced to the class.'],
          ['icon'=>'📱','title'=>'App Access','text'=>'Download the Pulse app to view the full timetable and book instantly.'],
        ];
        foreach($perks as $p):?>
        <div class="gf-booking-perk">
          <div class="gf-booking-perk-icon"><?=esc_html($p['icon'])?></div>
          <div>
            <div class="gf-booking-perk-title"><?=esc_html($p['title'])?></div>
            <div class="gf-booking-perk-text"><?=esc_html($p['text'])?></div>
          </div>
        </div>
        <?php endforeach;?>

      </div>

      <div class="gf-form gf-reveal">
        <div class="gf-form-title">Book Free Class</div>
        <div class="gf-form-subtitle">Takes 30 seconds — no card needed</div>

        <form method="post" action="<?=esc_url(admin_url('admin-post.php'))?>">
          <?php wp_nonce_field('tf_gf_booking','tf_gf_nonce'); ?>
          <input type="hidden" name="action" value="tf_gf_booking">

          <div class="gf-form-row">
            <div class="gf-field">
              <label for="gf-fname">First Name</label>
              <input type="text" id="gf-fname" name="first_name" placeholder="Zara" required autocomplete="given-name">
            </div>
            <div class="gf-field">
              <label for="gf-lname">Last Name</label>
              <input type="text" id="gf-lname" name="last_name" placeholder="Mitchell" required autocomplete="family-name">
            </div>
          </div>

          <div class="gf-form-row">
            <div class="gf-field">
              <label for="gf-email">Email</label>
              <input type="email" id="gf-email" name="email" placeholder="you@example.com" required autocomplete="email">
            </div>
            <div class="gf-field">
              <label for="gf-phone">Phone</label>
              <input type="tel" id="gf-phone" name="phone" placeholder="+44 7700 900000" autocomplete="tel">
            </div>
          </div>

          <div class="gf-field">
            <label for="gf-class">Which Class Interests You?</label>
            <select id="gf-class" name="class_type">
              <option value="">— Select a class —</option>
              <option value="hiit">HIIT Blast</option>
              <option value="boxing">Boxing Fit</option>
              <option value="spin">Spin Studio</option>
              <option value="barre">Barre Fusion</option>
              <option value="pilates">Pilates Core</option>
              <option value="dance">Dance Cardio</option>
              <option value="not-sure">Not Sure — Surprise Me!</option>
            </select>
          </div>

          <div class="gf-form-row">
            <div class="gf-field">
              <label for="gf-date">Preferred Date</label>
              <input type="date" id="gf-date" name="preferred_date">
            </div>
            <div class="gf-field">
              <label for="gf-time">Preferred Time</label>
              <select id="gf-time" name="preferred_time">
                <option value="">— Select time —</option>
                <option value="6am">6:00 AM (Early Bird)</option>
                <option value="7am">7:00 AM</option>
                <option value="12pm">12:00 PM (Lunchtime)</option>
                <option value="6pm">6:00 PM (After Work)</option>
                <option value="7pm">7:00 PM</option>
              </select>
            </div>
          </div>

          <div class="gf-field">
            <label for="gf-level">Fitness Level</label>
            <select id="gf-level" name="fitness_level">
              <option value="">— Your current fitness level —</option>
              <option value="beginner">Total Beginner</option>
              <option value="some">Some Exercise</option>
              <option value="regular">Regular Exerciser</option>
              <option value="athlete">Athlete</option>
            </select>
          </div>

          <button type="submit" class="gf-btn gf-btn--coral" style="width:100%;justify-content:center;font-size:.9rem;padding:16px;border-radius:99px">
            💥 Claim My Free Class
          </button>
          <p style="text-align:center;margin-top:12px;font-size:.78rem;color:rgba(255,255,255,.35)">
            NO PAYMENT REQUIRED · CANCEL ANY TIME
          </p>

        </form>
      </div>

    </div>
  </div>
</section>

<!-- ── FOOTER CTA ─────────────────────────────────────────────── -->
<section class="gf-footer-cta">
  <div class="gf-container" style="position:relative;z-index:1">
    <div class="gf-eyebrow" style="color:rgba(255,255,255,.7);justify-content:center;display:flex">Pulse Fitness Studio</div>
    <h2 class="gf-h2">Leeds City Centre</h2>
    <p>14 Boar Lane, Leeds LS1 5DA · Open 7 days · Classes from 6am</p>
    <div style="display:flex;gap:16px;justify-content:center;flex-wrap:wrap">
      <a href="tel:01132340000" class="gf-btn" style="background:rgba(255,255,255,.15);color:#fff;border:2px solid rgba(255,255,255,.4);border-radius:99px">📞 0113 234 0000</a>
      <a href="#booking" class="gf-btn" style="background:var(--gf-charcoal);color:var(--gf-white);border:2px solid var(--gf-charcoal);border-radius:99px">Book Free Class</a>
    </div>
  </div>
</section>

</div><!-- /gf-wrap -->

<!-- ── JAVASCRIPT ─────────────────────────────────────────────── -->
<script>
(function(){

  /* animated counters */
  const easeOut = t => 1 - Math.pow(1-t,3);
  document.querySelectorAll('.gf-stat-num[data-target]').forEach(el=>{
    const target = parseFloat(el.dataset.target);
    const suffix = el.dataset.suffix||'';
    if(isNaN(target)) return;
    const obs = new IntersectionObserver(entries=>{
      entries.forEach(e=>{
        if(!e.isIntersecting) return;
        obs.unobserve(e.target);
        const dur=1800,start=performance.now();
        (function tick(now){
          const t=Math.min((now-start)/dur,1);
          el.textContent=Math.round(easeOut(t)*target).toLocaleString()+suffix;
          if(t<1) requestAnimationFrame(tick);
          else el.textContent=target.toLocaleString()+suffix;
        })(start);
      });
    },{threshold:.4});
    obs.observe(el);
  });

  /* FAQ accordion */
  document.querySelectorAll('.gf-faq-q').forEach(btn=>{
    btn.addEventListener('click',function(){
      const item=this.closest('.gf-faq-item');
      const ans=item.querySelector('.gf-faq-a');
      const open=item.classList.contains('gf-open');
      document.querySelectorAll('.gf-faq-item.gf-open').forEach(o=>{
        o.classList.remove('gf-open');
        o.querySelector('.gf-faq-a').style.maxHeight='0';
        o.querySelector('.gf-faq-q').setAttribute('aria-expanded','false');
      });
      if(!open){
        item.classList.add('gf-open');
        ans.style.maxHeight=ans.scrollHeight+'px';
        this.setAttribute('aria-expanded','true');
      }
    });
  });

  /* scroll reveal */
  const ro=new IntersectionObserver(entries=>{
    entries.forEach((e,i)=>{
      if(!e.isIntersecting) return;
      setTimeout(()=>e.target.classList.add('gf-visible'),i*80);
      ro.unobserve(e.target);
    });
  },{threshold:.1});
  document.querySelectorAll('.gf-reveal').forEach(el=>ro.observe(el));

})();
</script>

<?php get_footer(); ?>
