<?php
/**
 * Template Name: TF — Gym / Fitness
 * Description:   Premium fitness gym & performance centre homepage template.
 * Namespace:     --gy-*
 * Google Fonts:  Barlow Condensed + Rajdhani
 * Palette:       Volt #CFFF04 / Iron #1A1A2E / Steel #2D3561 / Flame #FF4136 / Ash #F5F5F0
 * Hero scene:    CSS weight rack, barbell, dumbbells, athlete figure mid-lift, energy rings
 */

defined('ABSPATH') || exit;
get_header();
?>

<!-- ============================================================
     GYM / FITNESS — PREMIUM TEMPLATE
     ============================================================ -->
<div class="gy-wrap">

<!-- ── GOOGLE FONTS ─────────────────────────────────────────── -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:ital,wght@0,400;0,600;0,700;0,900;1,400;1,700&family=Rajdhani:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>
/* ── DESIGN TOKENS ──────────────────────────────────────────── */
:root{
  --gy-volt:#CFFF04;
  --gy-volt-dk:#A8CC00;
  --gy-iron:#1A1A2E;
  --gy-iron-lt:#16213E;
  --gy-steel:#2D3561;
  --gy-flame:#FF4136;
  --gy-flame-lt:#FF6B6B;
  --gy-ash:#F5F5F0;
  --gy-mid:#888899;
  --gy-white:#FFFFFF;
  --gy-f-head:'Barlow Condensed',sans-serif;
  --gy-f-body:'Rajdhani',sans-serif;
  --gy-r:6px;
  --gy-r-lg:14px;
  --gy-sh:0 4px 24px rgba(0,0,0,.45);
  --gy-sh-volt:0 0 24px rgba(207,255,4,.35);
}

/* ── BASE ───────────────────────────────────────────────────── */
.gy-wrap{font-family:var(--gy-f-body);color:var(--gy-iron);overflow-x:hidden}
.gy-wrap *,
.gy-wrap *::before,
.gy-wrap *::after{box-sizing:border-box;margin:0;padding:0}
.gy-wrap a{color:inherit;text-decoration:none}
.gy-wrap img{max-width:100%;display:block}

/* ── LAYOUT ─────────────────────────────────────────────────── */
.gy-container{max-width:1180px;margin:0 auto;padding:0 24px}
.gy-section{padding:96px 0}
.gy-section--dark{background:var(--gy-iron)}
.gy-section--iron-lt{background:var(--gy-iron-lt)}
.gy-section--steel{background:var(--gy-steel)}
.gy-section--ash{background:var(--gy-ash)}
.gy-section--volt{background:var(--gy-volt)}

/* ── TYPOGRAPHY ─────────────────────────────────────────────── */
.gy-eyebrow{
  font-family:var(--gy-f-head);
  font-size:.75rem;letter-spacing:.2em;text-transform:uppercase;
  color:var(--gy-volt);font-weight:700;
  display:flex;align-items:center;gap:10px;margin-bottom:14px
}
.gy-eyebrow::before{
  content:'';display:inline-block;width:32px;height:2px;background:var(--gy-volt)
}
.gy-eyebrow--flame{color:var(--gy-flame)}
.gy-eyebrow--flame::before{background:var(--gy-flame)}
.gy-eyebrow--dark{color:var(--gy-iron)}
.gy-eyebrow--dark::before{background:var(--gy-iron)}
.gy-h1{
  font-family:var(--gy-f-head);font-size:clamp(3rem,8vw,6.5rem);
  font-weight:900;line-height:.95;text-transform:uppercase;color:var(--gy-white)
}
.gy-h1 em{color:var(--gy-volt);font-style:normal}
.gy-h2{
  font-family:var(--gy-f-head);font-size:clamp(2.2rem,5vw,3.8rem);
  font-weight:900;text-transform:uppercase;line-height:1.05
}
.gy-h3{
  font-family:var(--gy-f-head);font-size:clamp(1.4rem,3vw,2rem);
  font-weight:700;text-transform:uppercase
}
.gy-lead{font-size:1.15rem;line-height:1.7;opacity:.9}
.gy-sub{font-size:.95rem;line-height:1.65}

/* ── BUTTONS ────────────────────────────────────────────────── */
.gy-btn{
  display:inline-flex;align-items:center;gap:8px;
  font-family:var(--gy-f-head);font-size:1rem;font-weight:700;
  text-transform:uppercase;letter-spacing:.08em;
  padding:14px 32px;border-radius:var(--gy-r);
  border:2px solid transparent;cursor:pointer;
  transition:all .25s;white-space:nowrap
}
.gy-btn--volt{
  background:var(--gy-volt);color:var(--gy-iron);border-color:var(--gy-volt);
  box-shadow:var(--gy-sh-volt)
}
.gy-btn--volt:hover{background:var(--gy-volt-dk);border-color:var(--gy-volt-dk);transform:translateY(-2px)}
.gy-btn--outline{
  background:transparent;color:var(--gy-white);border-color:var(--gy-white)
}
.gy-btn--outline:hover{background:var(--gy-white);color:var(--gy-iron)}
.gy-btn--flame{
  background:var(--gy-flame);color:var(--gy-white);border-color:var(--gy-flame)
}
.gy-btn--flame:hover{background:#e0372e;transform:translateY(-2px)}

/* ── HERO ───────────────────────────────────────────────────── */
.gy-hero{
  min-height:100vh;position:relative;overflow:hidden;
  background:linear-gradient(135deg,var(--gy-iron) 0%,var(--gy-iron-lt) 40%,var(--gy-steel) 75%,#1D1040 100%);
  display:flex;align-items:center
}

/* hex grid overlay */
.gy-hero-hex{
  position:absolute;inset:0;pointer-events:none;overflow:hidden
}
.gy-hex{
  position:absolute;opacity:.04;
  width:80px;height:92px;
  background:var(--gy-volt);
  clip-path:polygon(50% 0%,100% 25%,100% 75%,50% 100%,0% 75%,0% 25%)
}

/* energy rings */
@keyframes gy-ring-pulse{
  0%{transform:scale(.8);opacity:.7}
  100%{transform:scale(1.6);opacity:0}
}
.gy-energy-ring{
  position:absolute;border-radius:50%;
  border:2px solid var(--gy-volt);
  animation:gy-ring-pulse 2.4s ease-out infinite
}
.gy-energy-ring:nth-child(2){animation-delay:.8s;border-color:var(--gy-flame)}
.gy-energy-ring:nth-child(3){animation-delay:1.6s;border-color:rgba(255,255,255,.3)}

/* speed lines */
@keyframes gy-speed-line{
  0%{transform:translateX(-100%);opacity:0}
  20%{opacity:.6}
  100%{transform:translateX(200%);opacity:0}
}
.gy-speed-line{
  position:absolute;height:1px;
  background:linear-gradient(to right,transparent,var(--gy-volt),transparent);
  animation:gy-speed-line 2s ease-in infinite
}

/* CSS GYM SCENE */
.gy-hero-scene{
  position:absolute;right:3%;top:50%;transform:translateY(-50%);
  width:480px;height:500px
}

/* weight rack */
.gy-rack{
  position:absolute;bottom:30px;right:10px;
  width:220px;height:180px;
  border:3px solid #444;border-radius:4px;
  background:linear-gradient(to bottom,#333,#222)
}
.gy-rack::before{
  content:'';position:absolute;top:20px;left:-10px;right:-10px;height:4px;
  background:#555;box-shadow:0 30px 0 #555,0 60px 0 #555,0 90px 0 #555,0 120px 0 #555
}
/* plates on rack */
.gy-rack-plate{
  position:absolute;border-radius:3px;
  background:linear-gradient(to right,#666,#888,#666)
}
.gy-rack-plate:nth-child(1){width:14px;height:55px;top:12px;left:14px}
.gy-rack-plate:nth-child(2){width:14px;height:55px;top:12px;left:30px;background:linear-gradient(to right,var(--gy-flame),#cc3328,var(--gy-flame))}
.gy-rack-plate:nth-child(3){width:12px;height:45px;top:17px;left:46px}
.gy-rack-plate:nth-child(4){width:14px;height:65px;top:7px;right:14px}
.gy-rack-plate:nth-child(5){width:14px;height:65px;top:7px;right:30px;background:linear-gradient(to right,var(--gy-volt-dk),#a8cc00,var(--gy-volt-dk))}
.gy-rack-plate:nth-child(6){width:10px;height:40px;top:22px;right:46px}

/* barbell */
.gy-barbell{
  position:absolute;bottom:220px;left:50%;transform:translateX(-50%);
  width:320px;height:18px;
  background:linear-gradient(to bottom,#999,#ccc,#999);
  border-radius:9px;
  box-shadow:0 4px 12px rgba(0,0,0,.5)
}
.gy-barbell::before,
.gy-barbell::after{
  content:'';position:absolute;top:-18px;
  width:28px;height:54px;border-radius:4px;
  background:linear-gradient(to right,#555,#888,#555)
}
.gy-barbell::before{left:-24px}
.gy-barbell::after{right:-24px}

/* barbell extra plates */
.gy-bb-plate{
  position:absolute;top:-22px;border-radius:4px;
  width:18px;height:62px;
  background:linear-gradient(to right,var(--gy-flame),#cc3328,var(--gy-flame))
}
.gy-bb-plate:nth-child(3){left:14px}
.gy-bb-plate:nth-child(4){left:34px}
.gy-bb-plate:nth-child(5){right:14px}
.gy-bb-plate:nth-child(6){right:34px}

/* athlete figure */
@keyframes gy-lift{
  0%,100%{bottom:215px}
  50%{bottom:235px}
}
.gy-athlete{
  position:absolute;left:80px;
  animation:gy-lift 2.8s ease-in-out infinite;
  bottom:215px
}
/* legs */
.gy-athlete-legs{
  position:absolute;bottom:0;left:50%;transform:translateX(-50%);
  width:40px;height:70px;
  background:linear-gradient(to bottom,#2244aa,#1a3388);
  border-radius:4px 4px 0 0
}
.gy-athlete-legs::before,
.gy-athlete-legs::after{
  content:'';position:absolute;bottom:-20px;
  width:18px;height:22px;border-radius:0 0 4px 4px;
  background:#1a3388
}
.gy-athlete-legs::before{left:2px}
.gy-athlete-legs::after{right:2px}
/* torso */
.gy-athlete-torso{
  position:absolute;bottom:65px;left:50%;transform:translateX(-50%);
  width:50px;height:65px;
  background:linear-gradient(135deg,#CC0000,#FF4136);
  border-radius:6px 6px 0 0
}
/* shoulders extra width */
.gy-athlete-torso::before{
  content:'';position:absolute;top:0;left:-8px;right:-8px;height:18px;
  background:inherit;border-radius:6px 6px 0 0
}
/* volt stripe on shirt */
.gy-athlete-torso::after{
  content:'';position:absolute;top:8px;left:50%;transform:translateX(-50%);
  width:4px;height:40px;background:var(--gy-volt);border-radius:2px
}
/* arms up holding barbell */
.gy-athlete-arm-l,
.gy-athlete-arm-r{
  position:absolute;width:14px;border-radius:7px;
  background:linear-gradient(to bottom,#CC0000,#FF4136)
}
.gy-athlete-arm-l{
  height:75px;bottom:118px;left:calc(50% - 42px);transform:rotate(-30deg);
  transform-origin:bottom center
}
.gy-athlete-arm-r{
  height:75px;bottom:118px;right:calc(50% - 42px);transform:rotate(30deg);
  transform-origin:bottom center
}
/* head */
.gy-athlete-head{
  position:absolute;bottom:128px;left:50%;transform:translateX(-50%);
  width:36px;height:42px;border-radius:50% 50% 45% 45%;
  background:linear-gradient(to bottom,#8B5C30,#c48040)
}
/* bandana */
.gy-athlete-head::before{
  content:'';position:absolute;top:6px;left:0;right:0;height:10px;
  background:var(--gy-volt);border-radius:3px 3px 0 0
}
/* determined expression */
.gy-athlete-head::after{
  content:'';position:absolute;bottom:10px;left:50%;transform:translateX(-50%);
  width:18px;height:3px;background:#1A1A2E;border-radius:2px
}

/* energy ring position */
.gy-ring-container{
  position:absolute;left:80px;bottom:220px;
  width:60px;height:60px;transform:translate(-50%,-50%)
}
.gy-energy-ring{
  position:absolute;
  width:80px;height:80px;
  top:50%;left:50%;transform:translate(-50%,-50%) scale(.8)
}

/* dumbbell floating */
@keyframes gy-dumbbell-float{
  0%,100%{transform:translateY(0) rotate(-15deg)}
  50%{transform:translateY(-12px) rotate(-10deg)}
}
.gy-dumbbell{
  position:absolute;top:40px;left:20px;
  animation:gy-dumbbell-float 3.2s ease-in-out infinite
}
.gy-dumbbell-bar{
  width:80px;height:10px;border-radius:5px;
  background:linear-gradient(to bottom,#aaa,#ddd,#aaa);
  position:relative
}
.gy-dumbbell-bar::before,
.gy-dumbbell-bar::after{
  content:'';position:absolute;top:-8px;
  width:14px;height:26px;border-radius:3px;
  background:linear-gradient(to right,#555,#888,#555)
}
.gy-dumbbell-bar::before{left:-10px}
.gy-dumbbell-bar::after{right:-10px}

/* volt particle dots */
@keyframes gy-particle-drift{
  0%{transform:translate(0,0);opacity:0}
  20%{opacity:1}
  100%{transform:translate(var(--gy-px),var(--gy-py));opacity:0}
}
.gy-particle{
  position:absolute;width:4px;height:4px;border-radius:50%;
  background:var(--gy-volt);
  animation:gy-particle-drift 3s ease-out infinite
}

/* hero content */
.gy-hero-content{
  position:relative;z-index:2;
  max-width:560px
}
.gy-hero-tag{
  display:inline-flex;align-items:center;gap:8px;
  background:rgba(207,255,4,.12);border:1px solid rgba(207,255,4,.35);
  border-radius:99px;padding:6px 16px;margin-bottom:28px;
  font-family:var(--gy-f-head);font-size:.8rem;font-weight:700;
  text-transform:uppercase;letter-spacing:.15em;color:var(--gy-volt)
}
.gy-hero-tag::before{
  content:'';width:8px;height:8px;border-radius:50%;
  background:var(--gy-volt);animation:gy-ring-pulse 1.5s ease-out infinite
}
.gy-hero-desc{
  font-size:1.15rem;line-height:1.7;color:rgba(255,255,255,.8);
  margin:20px 0 36px
}
.gy-hero-btns{display:flex;gap:16px;flex-wrap:wrap}
.gy-hero-stats{
  display:flex;gap:40px;margin-top:48px;padding-top:40px;
  border-top:1px solid rgba(255,255,255,.12)
}
.gy-hero-stat-num{
  font-family:var(--gy-f-head);font-size:2.2rem;font-weight:900;
  color:var(--gy-volt);line-height:1
}
.gy-hero-stat-label{
  font-size:.8rem;color:rgba(255,255,255,.6);text-transform:uppercase;
  letter-spacing:.08em;margin-top:4px
}

/* ── TRUST BAR ──────────────────────────────────────────────── */
.gy-trust{
  background:var(--gy-volt);padding:18px 0
}
.gy-trust-inner{
  display:flex;align-items:center;gap:40px;flex-wrap:wrap;justify-content:center
}
.gy-trust-item{
  font-family:var(--gy-f-head);font-size:.9rem;font-weight:700;
  text-transform:uppercase;letter-spacing:.1em;color:var(--gy-iron);
  display:flex;align-items:center;gap:8px
}
.gy-trust-item::before{content:'⚡';font-size:1rem}

/* ── STATS ──────────────────────────────────────────────────── */
.gy-stats-grid{
  display:grid;grid-template-columns:repeat(4,1fr);gap:2px;
  background:rgba(255,255,255,.06)
}
.gy-stat-card{
  background:var(--gy-iron-lt);padding:48px 32px;text-align:center;
  border-bottom:3px solid transparent;
  transition:border-color .3s
}
.gy-stat-card:hover{border-bottom-color:var(--gy-volt)}
.gy-stat-num{
  font-family:var(--gy-f-head);font-size:clamp(2.5rem,6vw,4rem);font-weight:900;
  color:var(--gy-volt);line-height:1;display:block
}
.gy-stat-label{
  font-size:.9rem;color:var(--gy-mid);text-transform:uppercase;
  letter-spacing:.1em;margin-top:10px;display:block
}

/* ── PROGRAMS ───────────────────────────────────────────────── */
.gy-programs-intro{
  display:grid;grid-template-columns:1fr 1fr;gap:80px;align-items:center;
  margin-bottom:72px
}
.gy-programs-grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:24px
}
.gy-program-card{
  background:var(--gy-ash);border-radius:var(--gy-r-lg);
  overflow:hidden;transition:transform .3s,box-shadow .3s;
  border:2px solid transparent
}
.gy-program-card:hover{
  transform:translateY(-6px);box-shadow:var(--gy-sh);
  border-color:var(--gy-volt)
}
.gy-program-top{
  height:120px;display:flex;align-items:center;justify-content:center;
  font-size:3rem
}
.gy-program-body{padding:24px}
.gy-program-name{
  font-family:var(--gy-f-head);font-size:1.3rem;font-weight:900;
  text-transform:uppercase;color:var(--gy-iron);margin-bottom:8px
}
.gy-program-desc{font-size:.9rem;color:#555;line-height:1.6;margin-bottom:16px}
.gy-program-badge{
  display:inline-block;
  font-family:var(--gy-f-head);font-size:.75rem;font-weight:700;
  text-transform:uppercase;letter-spacing:.1em;
  padding:4px 12px;border-radius:99px;
  background:var(--gy-iron);color:var(--gy-volt)
}

/* ── TRAINERS ───────────────────────────────────────────────── */
.gy-trainers-grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:32px
}
.gy-trainer-card{
  background:var(--gy-iron-lt);border-radius:var(--gy-r-lg);
  overflow:hidden;transition:transform .3s
}
.gy-trainer-card:hover{transform:translateY(-6px)}
.gy-trainer-avatar{
  height:220px;display:flex;align-items:flex-end;justify-content:center;
  position:relative;overflow:hidden;padding-bottom:12px
}
.gy-trainer-body{padding:24px}
.gy-trainer-name{
  font-family:var(--gy-f-head);font-size:1.5rem;font-weight:900;
  text-transform:uppercase;color:var(--gy-white);margin-bottom:4px
}
.gy-trainer-role{
  font-size:.85rem;color:var(--gy-volt);text-transform:uppercase;
  letter-spacing:.1em;font-weight:600;margin-bottom:12px
}
.gy-trainer-spec{
  font-size:.9rem;color:rgba(255,255,255,.65);line-height:1.6;margin-bottom:16px
}
.gy-trainer-certs{display:flex;flex-wrap:wrap;gap:6px}
.gy-trainer-cert{
  font-size:.75rem;font-weight:600;
  padding:3px 10px;border-radius:99px;
  background:rgba(207,255,4,.12);color:var(--gy-volt);
  border:1px solid rgba(207,255,4,.25)
}

/* CSS trainer figure */
.gy-tfig{position:relative;width:80px;height:160px}
.gy-tfig-head{
  position:absolute;top:0;left:50%;transform:translateX(-50%);
  width:34px;height:38px;border-radius:50% 50% 45% 45%;
}
.gy-tfig-torso{
  position:absolute;top:40px;left:50%;transform:translateX(-50%);
  width:44px;height:52px;border-radius:5px 5px 3px 3px
}
.gy-tfig-arm-l,
.gy-tfig-arm-r{
  position:absolute;top:44px;width:12px;height:44px;border-radius:6px
}
.gy-tfig-arm-l{left:2px;transform:rotate(10deg);transform-origin:top center}
.gy-tfig-arm-r{right:2px;transform:rotate(-10deg);transform-origin:top center}
.gy-tfig-legs{
  position:absolute;bottom:0;left:50%;transform:translateX(-50%);
  width:40px;height:72px
}
.gy-tfig-leg-l,
.gy-tfig-leg-r{
  position:absolute;bottom:0;width:17px;height:72px;border-radius:4px 4px 0 0
}
.gy-tfig-leg-l{left:0}
.gy-tfig-leg-r{right:0}

/* trainer 1 — Strength: red */
.gy-t1 .gy-trainer-avatar{
  background:linear-gradient(to bottom,#1a0a0a,var(--gy-iron))
}
.gy-t1 .gy-tfig-head{background:linear-gradient(to bottom,#5C3317,#8B5C30)}
.gy-t1 .gy-tfig-torso{background:linear-gradient(135deg,var(--gy-flame),#cc2b22)}
.gy-t1 .gy-tfig-arm-l,
.gy-t1 .gy-tfig-arm-r{background:linear-gradient(to bottom,var(--gy-flame),#cc2b22)}
.gy-t1 .gy-tfig-leg-l,
.gy-t1 .gy-tfig-leg-r{background:linear-gradient(to bottom,#1a2255,#1a3388)}

/* trainer 2 — Cardio: volt */
.gy-t2 .gy-trainer-avatar{
  background:linear-gradient(to bottom,#0a1a0a,var(--gy-iron))
}
.gy-t2 .gy-tfig-head{background:linear-gradient(to bottom,#1a1a1a,#444)}
.gy-t2 .gy-tfig-torso{background:linear-gradient(135deg,var(--gy-volt-dk),#7aaa00)}
.gy-t2 .gy-tfig-arm-l,
.gy-t2 .gy-tfig-arm-r{background:linear-gradient(to bottom,var(--gy-volt-dk),#7aaa00)}
.gy-t2 .gy-tfig-leg-l,
.gy-t2 .gy-tfig-leg-r{background:linear-gradient(to bottom,#2D3561,#3d4880)}

/* trainer 3 — Yoga: teal */
.gy-t3 .gy-trainer-avatar{
  background:linear-gradient(to bottom,#0a0a1a,var(--gy-iron))
}
.gy-t3 .gy-tfig-head{background:linear-gradient(to bottom,#8B5C30,#c48040)}
.gy-t3 .gy-tfig-torso{background:linear-gradient(135deg,#006064,#00838F)}
.gy-t3 .gy-tfig-arm-l{
  transform:rotate(-60deg);transform-origin:top center
}
.gy-t3 .gy-tfig-arm-r{
  transform:rotate(60deg);transform-origin:top center
}
.gy-t3 .gy-tfig-arm-l,
.gy-t3 .gy-tfig-arm-r{background:linear-gradient(to bottom,#006064,#00838F)}
.gy-t3 .gy-tfig-leg-l{transform:rotate(-20deg);transform-origin:top center}
.gy-t3 .gy-tfig-leg-r{transform:rotate(20deg);transform-origin:top center}
.gy-t3 .gy-tfig-leg-l,
.gy-t3 .gy-tfig-leg-r{background:linear-gradient(to bottom,#37474F,#546E7A)}

/* ── FACILITY ───────────────────────────────────────────────── */
.gy-facility-grid{
  display:grid;grid-template-columns:repeat(2,1fr);gap:3px;
  border-radius:var(--gy-r-lg);overflow:hidden
}
.gy-facility-tile{
  position:relative;height:220px;overflow:hidden;cursor:pointer;
  display:flex;align-items:flex-end;padding:20px
}
.gy-facility-tile:first-child{
  grid-column:span 2;height:320px
}
.gy-facility-bg{
  position:absolute;inset:0;transition:transform .5s
}
.gy-facility-tile:hover .gy-facility-bg{transform:scale(1.05)}
.gy-facility-label{
  position:relative;z-index:1;
  font-family:var(--gy-f-head);font-size:1.2rem;font-weight:900;
  text-transform:uppercase;color:var(--gy-white);
  background:rgba(26,26,46,.7);padding:8px 16px;border-radius:var(--gy-r);
  border-left:3px solid var(--gy-volt)
}

/* ── MEMBERSHIP ─────────────────────────────────────────────── */
.gy-membership-grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:24px;
  align-items:start
}
.gy-mem-card{
  border-radius:var(--gy-r-lg);overflow:hidden;
  transition:transform .3s,box-shadow .3s
}
.gy-mem-card:hover{transform:translateY(-6px);box-shadow:var(--gy-sh)}
.gy-mem-card--standard{background:var(--gy-iron-lt);border:2px solid rgba(255,255,255,.1)}
.gy-mem-card--elite{
  background:var(--gy-iron);border:2px solid var(--gy-volt);
  transform:scale(1.04);box-shadow:var(--gy-sh-volt)
}
.gy-mem-card--elite:hover{transform:scale(1.04) translateY(-6px)}
.gy-mem-card--premium{background:var(--gy-iron-lt);border:2px solid rgba(255,255,255,.1)}
.gy-mem-top{
  padding:32px 28px 24px;border-bottom:1px solid rgba(255,255,255,.08)
}
.gy-mem-badge{
  display:inline-block;margin-bottom:16px;
  font-family:var(--gy-f-head);font-size:.7rem;font-weight:700;
  text-transform:uppercase;letter-spacing:.15em;
  padding:4px 12px;border-radius:99px;
  background:rgba(207,255,4,.15);color:var(--gy-volt)
}
.gy-mem-card--elite .gy-mem-badge{
  background:var(--gy-volt);color:var(--gy-iron)
}
.gy-mem-name{
  font-family:var(--gy-f-head);font-size:1.8rem;font-weight:900;
  text-transform:uppercase;color:var(--gy-white);margin-bottom:8px
}
.gy-mem-price{
  font-family:var(--gy-f-head);font-size:3rem;font-weight:900;
  color:var(--gy-volt);line-height:1
}
.gy-mem-price sup{font-size:1.4rem;vertical-align:top;margin-top:.6rem}
.gy-mem-period{font-size:.85rem;color:var(--gy-mid);margin-top:4px}
.gy-mem-body{padding:28px}
.gy-mem-feature{
  display:flex;align-items:flex-start;gap:12px;
  padding:9px 0;border-bottom:1px solid rgba(255,255,255,.06);
  font-size:.95rem;color:rgba(255,255,255,.8)
}
.gy-mem-feature:last-child{border-bottom:none}
.gy-mem-check{
  flex-shrink:0;width:20px;height:20px;border-radius:50%;
  display:flex;align-items:center;justify-content:center;
  font-size:.65rem;background:rgba(207,255,4,.15);color:var(--gy-volt)
}
.gy-mem-card--elite .gy-mem-check{background:var(--gy-volt);color:var(--gy-iron)}
.gy-mem-btn{display:block;text-align:center;margin-top:24px}

/* ── PROCESS ────────────────────────────────────────────────── */
.gy-process-grid{
  display:grid;grid-template-columns:repeat(4,1fr);gap:0;
  position:relative
}
.gy-process-grid::before{
  content:'';position:absolute;top:40px;left:12.5%;right:12.5%;
  height:2px;background:linear-gradient(to right,var(--gy-volt),var(--gy-flame));
  z-index:0
}
.gy-process-step{
  text-align:center;padding:0 20px;position:relative;z-index:1
}
.gy-process-icon{
  width:80px;height:80px;border-radius:50%;
  background:var(--gy-steel);border:3px solid var(--gy-volt);
  display:flex;align-items:center;justify-content:center;
  font-size:2rem;margin:0 auto 24px;
  position:relative
}
.gy-process-num{
  position:absolute;top:-6px;right:-6px;
  width:26px;height:26px;border-radius:50%;
  background:var(--gy-volt);color:var(--gy-iron);
  font-family:var(--gy-f-head);font-size:.8rem;font-weight:900;
  display:flex;align-items:center;justify-content:center
}
.gy-process-title{
  font-family:var(--gy-f-head);font-size:1.2rem;font-weight:900;
  text-transform:uppercase;color:var(--gy-white);margin-bottom:8px
}
.gy-process-desc{font-size:.9rem;color:rgba(255,255,255,.6);line-height:1.6}

/* ── TESTIMONIALS ───────────────────────────────────────────── */
.gy-testi-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}
.gy-testi-card{
  background:var(--gy-iron-lt);border-radius:var(--gy-r-lg);
  padding:32px;border:1px solid rgba(255,255,255,.08);
  transition:transform .3s
}
.gy-testi-card:hover{transform:translateY(-4px)}
.gy-testi-quote{
  font-size:3rem;color:var(--gy-volt);line-height:1;
  font-family:Georgia,serif;margin-bottom:12px
}
.gy-testi-text{
  font-size:1rem;color:rgba(255,255,255,.8);line-height:1.7;
  margin-bottom:24px;font-style:italic
}
.gy-testi-stars{color:var(--gy-volt);font-size:1.1rem;margin-bottom:16px;letter-spacing:2px}
.gy-testi-author{
  display:flex;align-items:center;gap:14px;
  padding-top:16px;border-top:1px solid rgba(255,255,255,.08)
}
.gy-testi-avatar{
  width:46px;height:46px;border-radius:50%;border:2px solid var(--gy-volt);
  display:flex;align-items:center;justify-content:center;
  font-size:1.3rem;background:var(--gy-steel);flex-shrink:0
}
.gy-testi-name{
  font-family:var(--gy-f-head);font-size:1rem;font-weight:700;
  text-transform:uppercase;color:var(--gy-white)
}
.gy-testi-meta{font-size:.8rem;color:var(--gy-volt)}

/* ── FAQ ────────────────────────────────────────────────────── */
.gy-faq-grid{
  display:grid;grid-template-columns:1fr 1fr;gap:16px;
  max-width:960px;margin:0 auto
}
.gy-faq-item{
  background:var(--gy-iron-lt);border-radius:var(--gy-r);
  border:1px solid rgba(255,255,255,.08);overflow:hidden
}
.gy-faq-q{
  width:100%;background:none;border:none;cursor:pointer;
  display:flex;align-items:center;justify-content:space-between;gap:16px;
  padding:22px 24px;text-align:left;
  font-family:var(--gy-f-head);font-size:1rem;font-weight:700;
  text-transform:uppercase;letter-spacing:.04em;color:var(--gy-white);
  transition:color .25s
}
.gy-faq-q:hover{color:var(--gy-volt)}
.gy-faq-icon{
  flex-shrink:0;width:28px;height:28px;border-radius:50%;
  border:2px solid rgba(255,255,255,.2);
  display:flex;align-items:center;justify-content:center;
  font-size:1.2rem;transition:all .3s;color:var(--gy-volt)
}
.gy-faq-item.gy-open .gy-faq-icon{
  transform:rotate(45deg);background:var(--gy-volt);color:var(--gy-iron);
  border-color:var(--gy-volt)
}
.gy-faq-a{
  max-height:0;overflow:hidden;transition:max-height .4s ease
}
.gy-faq-a-inner{
  padding:0 24px 22px;
  font-size:.95rem;color:rgba(255,255,255,.7);line-height:1.7
}

/* ── BOOKING ────────────────────────────────────────────────── */
.gy-booking-wrap{
  display:grid;grid-template-columns:1fr 1fr;gap:80px;align-items:start
}
.gy-booking-info h2{color:var(--gy-volt);margin-bottom:16px}
.gy-booking-info p{color:rgba(255,255,255,.75);line-height:1.7;margin-bottom:28px}
.gy-booking-feature{
  display:flex;align-items:center;gap:14px;
  padding:14px 0;border-bottom:1px solid rgba(255,255,255,.08)
}
.gy-booking-feature:last-child{border-bottom:none}
.gy-booking-feature-icon{
  width:40px;height:40px;border-radius:var(--gy-r);
  background:rgba(207,255,4,.1);border:1px solid rgba(207,255,4,.2);
  display:flex;align-items:center;justify-content:center;
  font-size:1.2rem;flex-shrink:0
}
.gy-booking-feature-text{font-size:.95rem;color:rgba(255,255,255,.75)}
.gy-booking-feature-title{
  font-family:var(--gy-f-head);font-size:.95rem;font-weight:700;
  text-transform:uppercase;color:var(--gy-white);margin-bottom:2px
}

/* form */
.gy-form{
  background:var(--gy-iron-lt);border-radius:var(--gy-r-lg);padding:40px;
  border:1px solid rgba(207,255,4,.12)
}
.gy-form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.gy-field{margin-bottom:20px}
.gy-field label{
  display:block;margin-bottom:8px;
  font-family:var(--gy-f-head);font-size:.8rem;font-weight:700;
  text-transform:uppercase;letter-spacing:.1em;color:rgba(255,255,255,.7)
}
.gy-field input,
.gy-field select,
.gy-field textarea{
  width:100%;padding:13px 16px;border-radius:var(--gy-r);
  border:2px solid rgba(255,255,255,.12);
  background:rgba(255,255,255,.05);color:var(--gy-white);
  font-family:var(--gy-f-body);font-size:.95rem;
  transition:border-color .25s;outline:none
}
.gy-field input:focus,
.gy-field select:focus,
.gy-field textarea:focus{border-color:var(--gy-volt)}
.gy-field select option{background:var(--gy-iron);color:var(--gy-white)}
.gy-field textarea{min-height:110px;resize:vertical}
.gy-form-title{
  font-family:var(--gy-f-head);font-size:1.6rem;font-weight:900;
  text-transform:uppercase;color:var(--gy-white);margin-bottom:8px
}
.gy-form-subtitle{font-size:.9rem;color:rgba(255,255,255,.55);margin-bottom:28px}

/* ── FOOTER CTA ─────────────────────────────────────────────── */
.gy-footer-cta{
  padding:80px 0;text-align:center;
  background:linear-gradient(135deg,var(--gy-iron) 0%,var(--gy-steel) 100%);
  position:relative;overflow:hidden
}
.gy-footer-cta::before{
  content:'TRAIN HARDER';
  position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);
  font-family:var(--gy-f-head);font-size:clamp(5rem,15vw,12rem);font-weight:900;
  color:rgba(255,255,255,.02);white-space:nowrap;pointer-events:none;
  letter-spacing:.1em
}
.gy-footer-cta h2{color:var(--gy-white);margin-bottom:16px}
.gy-footer-cta p{
  font-size:1.1rem;color:rgba(255,255,255,.7);
  max-width:560px;margin:0 auto 36px
}

/* ── SCROLL REVEAL ──────────────────────────────────────────── */
.gy-reveal{
  opacity:0;transform:translateY(30px);
  transition:opacity .6s ease,transform .6s ease
}
.gy-reveal.gy-visible{opacity:1;transform:translateY(0)}

/* ── RESPONSIVE ─────────────────────────────────────────────── */
@media(max-width:1100px){
  .gy-hero-scene{width:360px}
}
@media(max-width:900px){
  .gy-hero-scene{display:none}
  .gy-stats-grid{grid-template-columns:repeat(2,1fr)}
  .gy-programs-intro{grid-template-columns:1fr}
  .gy-programs-grid{grid-template-columns:repeat(2,1fr)}
  .gy-trainers-grid{grid-template-columns:repeat(2,1fr)}
  .gy-membership-grid{grid-template-columns:1fr}
  .gy-mem-card--elite{transform:none}
  .gy-process-grid{grid-template-columns:repeat(2,1fr);gap:32px}
  .gy-process-grid::before{display:none}
  .gy-testi-grid{grid-template-columns:1fr}
  .gy-faq-grid{grid-template-columns:1fr}
  .gy-booking-wrap{grid-template-columns:1fr}
  .gy-facility-grid{grid-template-columns:1fr}
  .gy-facility-tile:first-child{grid-column:span 1}
}
@media(max-width:600px){
  .gy-section{padding:64px 0}
  .gy-stats-grid{grid-template-columns:1fr 1fr}
  .gy-programs-grid{grid-template-columns:1fr}
  .gy-trainers-grid{grid-template-columns:1fr}
  .gy-form-row{grid-template-columns:1fr}
  .gy-hero-stats{flex-direction:column;gap:24px}
  .gy-hero-btns{flex-direction:column}
}
</style>

<!-- ── HERO ──────────────────────────────────────────────────── -->
<section class="gy-hero">

  <!-- hex grid -->
  <div class="gy-hero-hex">
    <?php
    srand(crc32('gy-hero-hex'));
    $cols = 10; $rows = 7;
    for($r=0;$r<$rows;$r++){
      for($c=0;$c<$cols;$c++){
        $x = $c*100 + ($r%2)*50;
        $y = $r*90;
        $op = round((rand(10,40)/100),2);
        echo "<div class='gy-hex' style='left:{$x}px;top:{$y}px;opacity:{$op}'></div>";
      }
    }
    ?>
  </div>

  <!-- speed lines -->
  <?php
  srand(crc32('gy-speed'));
  for($i=0;$i<8;$i++){
    $top = rand(10,90);
    $w   = rand(200,600);
    $del = round(rand(0,2000)/1000,2);
    $dur = round(rand(15,30)/10,1);
    echo "<div class='gy-speed-line' style='top:{$top}%;width:{$w}px;animation-delay:{$del}s;animation-duration:{$dur}s'></div>";
  }
  ?>

  <!-- CSS GYM SCENE -->
  <div class="gy-hero-scene">

    <!-- dumbbell -->
    <div class="gy-dumbbell" aria-hidden="true">
      <div class="gy-dumbbell-bar"></div>
    </div>

    <!-- barbell -->
    <div class="gy-barbell" aria-hidden="true">
      <div class="gy-bb-plate"></div>
      <div class="gy-bb-plate"></div>
      <div class="gy-bb-plate"></div>
      <div class="gy-bb-plate"></div>
    </div>

    <!-- athlete figure -->
    <div class="gy-athlete" aria-hidden="true">
      <div class="gy-athlete-legs"></div>
      <div class="gy-athlete-torso"></div>
      <div class="gy-athlete-arm-l"></div>
      <div class="gy-athlete-arm-r"></div>
      <div class="gy-athlete-head"></div>
    </div>

    <!-- energy rings around lift -->
    <div class="gy-ring-container" aria-hidden="true">
      <div class="gy-energy-ring" style="width:80px;height:80px"></div>
      <div class="gy-energy-ring" style="width:120px;height:120px;animation-delay:.8s"></div>
      <div class="gy-energy-ring" style="width:160px;height:160px;animation-delay:1.6s"></div>
    </div>

    <!-- weight rack -->
    <div class="gy-rack" aria-hidden="true">
      <div class="gy-rack-plate"></div>
      <div class="gy-rack-plate"></div>
      <div class="gy-rack-plate"></div>
      <div class="gy-rack-plate"></div>
      <div class="gy-rack-plate"></div>
      <div class="gy-rack-plate"></div>
    </div>

    <!-- volt particles -->
    <?php
    srand(crc32('gy-particles'));
    for($i=0;$i<12;$i++){
      $top = rand(20,80);
      $left= rand(10,90);
      $px  = rand(-60,60);
      $py  = rand(-80,-20);
      $del = round(rand(0,2500)/1000,2);
      $dur = round(rand(20,35)/10,1);
      echo "<div class='gy-particle' style='top:{$top}%;left:{$left}%;--gy-px:{$px}px;--gy-py:{$py}px;animation-delay:{$del}s;animation-duration:{$dur}s'></div>";
    }
    ?>

  </div><!-- /scene -->

  <div class="gy-container" style="position:relative;z-index:2">
    <div class="gy-hero-content">

      <div class="gy-hero-tag">⚡ Now Open — Manchester City Centre</div>

      <h1 class="gy-h1">
        Forge Your<br>
        <em>Strongest</em><br>
        Body
      </h1>

      <p class="gy-hero-desc">
        Elite strength training, expert coaching and state-of-the-art facilities —
        everything you need to train harder, recover smarter and perform at your absolute best.
      </p>

      <div class="gy-hero-btns">
        <a href="#booking" class="gy-btn gy-btn--volt">Start Free Trial</a>
        <a href="#programs" class="gy-btn gy-btn--outline">View Programs</a>
      </div>

      <div class="gy-hero-stats">
        <?php
        $stats = [
          ['num'=>'4,200','label'=>'Active Members'],
          ['num'=>'18','label'=>'Expert Trainers'],
          ['num'=>'6am–11pm','label'=>'Daily Hours'],
        ];
        foreach($stats as $s):?>
        <div>
          <div class="gy-hero-stat-num"><?=esc_html($s['num'])?></div>
          <div class="gy-hero-stat-label"><?=esc_html($s['label'])?></div>
        </div>
        <?php endforeach;?>
      </div>

    </div>
  </div>

</section><!-- /hero -->

<!-- ── TRUST BAR ─────────────────────────────────────────────── -->
<div class="gy-trust">
  <div class="gy-container">
    <div class="gy-trust-inner">
      <?php
      $trust = ['No Contract Required','Free Induction Session','Personal Trainer Included','25m Swimming Pool','Group Classes Included','Nutrition Coaching'];
      foreach($trust as $t):?>
      <div class="gy-trust-item"><?=esc_html($t)?></div>
      <?php endforeach;?>
    </div>
  </div>
</div>

<!-- ── STATS ─────────────────────────────────────────────────── -->
<section class="gy-section--dark">
  <div class="gy-stats-grid">
    <?php
    $counters = [
      ['num'=>4200,'suf'=>'+','label'=>'Members'],
      ['num'=>18,'suf'=>'','label'=>'Specialist Trainers'],
      ['num'=>98,'suf'=>'%','label'=>'Member Retention'],
      ['num'=>9,'suf'=>'','label'=>'Years in Manchester'],
    ];
    foreach($counters as $c):?>
    <div class="gy-stat-card gy-reveal">
      <span class="gy-stat-num" data-target="<?=esc_attr($c['num'])?>" data-suffix="<?=esc_attr($c['suf'])?>">0</span>
      <span class="gy-stat-label"><?=esc_html($c['label'])?></span>
    </div>
    <?php endforeach;?>
  </div>
</section>

<!-- ── PROGRAMS ──────────────────────────────────────────────── -->
<section class="gy-section gy-section--ash" id="programs">
  <div class="gy-container">

    <div class="gy-programs-intro">
      <div>
        <div class="gy-eyebrow gy-eyebrow--dark">Training Programs</div>
        <h2 class="gy-h2">Train With Purpose</h2>
      </div>
      <div>
        <p class="gy-lead" style="color:#444">
          Whether you're a complete beginner or an experienced athlete,
          our structured programs are designed to deliver measurable results in the shortest time possible.
        </p>
      </div>
    </div>

    <div class="gy-programs-grid">
      <?php
      $programs = [
        ['icon'=>'🏋️','name'=>'Strength & Power','desc'=>'Progressive overload barbell programmes for building raw strength and muscle mass. Includes squat, bench, deadlift coaching.','badge'=>'All Levels'],
        ['icon'=>'🔥','name'=>'HIIT & Cardio','desc'=>'High-intensity interval training to torch calories, improve cardiovascular fitness and build mental toughness in 45-minute sessions.','badge'=>'Beginner Friendly'],
        ['icon'=>'🧘','name'=>'Yoga & Mobility','desc'=>'Flexibility, breath work and mindful movement to complement your training, prevent injury and accelerate recovery.','badge'=>'All Levels'],
        ['icon'=>'🥊','name'=>'Boxing Fitness','desc'=>'Technique-led pad work and bag sessions that build coordination, stamina and upper body power without the sparring.','badge'=>'Beginner Friendly'],
        ['icon'=>'🚴','name'=>'Cycling Studio','desc'=>'Our state-of-the-art spin studio with 45 bikes, motivating instructors and heart-rate zone training.','badge'=>'All Levels'],
        ['icon'=>'🏊','name'=>'Swim & Recover','desc'=>'25m pool for lap swimming, aqua aerobics and post-session recovery. Perfect for low-impact cardio days.','badge'=>'Open Swim'],
      ];
      foreach($programs as $p):?>
      <div class="gy-program-card gy-reveal">
        <div class="gy-program-top" style="background:linear-gradient(135deg,var(--gy-iron) 0%,var(--gy-steel) 100%)">
          <?=esc_html($p['icon'])?>
        </div>
        <div class="gy-program-body">
          <div class="gy-program-name"><?=esc_html($p['name'])?></div>
          <p class="gy-program-desc"><?=esc_html($p['desc'])?></p>
          <span class="gy-program-badge"><?=esc_html($p['badge'])?></span>
        </div>
      </div>
      <?php endforeach;?>
    </div>

  </div>
</section>

<!-- ── TRAINERS ──────────────────────────────────────────────── -->
<section class="gy-section gy-section--dark">
  <div class="gy-container">

    <div style="text-align:center;max-width:600px;margin:0 auto 64px">
      <div class="gy-eyebrow" style="justify-content:center">Expert Coaching</div>
      <h2 class="gy-h2" style="color:var(--gy-white)">Your Coaches</h2>
    </div>

    <div class="gy-trainers-grid">

      <!-- Trainer 1 -->
      <div class="gy-trainer-card gy-t1 gy-reveal">
        <div class="gy-trainer-avatar">
          <div class="gy-tfig" aria-hidden="true">
            <div class="gy-tfig-head"></div>
            <div class="gy-tfig-torso"></div>
            <div class="gy-tfig-arm-l"></div>
            <div class="gy-tfig-arm-r"></div>
            <div class="gy-tfig-legs">
              <div class="gy-tfig-leg-l"></div>
              <div class="gy-tfig-leg-r"></div>
            </div>
          </div>
        </div>
        <div class="gy-trainer-body">
          <div class="gy-trainer-name">Marcus Webb</div>
          <div class="gy-trainer-role">Head Strength Coach</div>
          <p class="gy-trainer-spec">Former GB Powerlifting team coach with 14 years building elite athletes. Specialises in progressive overload and competition prep.</p>
          <div class="gy-trainer-certs">
            <span class="gy-trainer-cert">CSCS</span>
            <span class="gy-trainer-cert">BSc Sports Science</span>
            <span class="gy-trainer-cert">IPF Coach L3</span>
          </div>
        </div>
      </div>

      <!-- Trainer 2 -->
      <div class="gy-trainer-card gy-t2 gy-reveal">
        <div class="gy-trainer-avatar">
          <div class="gy-tfig" aria-hidden="true">
            <div class="gy-tfig-head"></div>
            <div class="gy-tfig-torso"></div>
            <div class="gy-tfig-arm-l"></div>
            <div class="gy-tfig-arm-r"></div>
            <div class="gy-tfig-legs">
              <div class="gy-tfig-leg-l"></div>
              <div class="gy-tfig-leg-r"></div>
            </div>
          </div>
        </div>
        <div class="gy-trainer-body">
          <div class="gy-trainer-name">Jade Okafor</div>
          <div class="gy-trainer-role">Cardio & HIIT Specialist</div>
          <p class="gy-trainer-spec">Marathon runner and former Nike running coach. Her HIIT sessions are legendary for results and her ability to keep you motivated throughout.</p>
          <div class="gy-trainer-certs">
            <span class="gy-trainer-cert">REPs Level 3</span>
            <span class="gy-trainer-cert">Run Leader</span>
            <span class="gy-trainer-cert">Nutrition L2</span>
          </div>
        </div>
      </div>

      <!-- Trainer 3 -->
      <div class="gy-trainer-card gy-t3 gy-reveal">
        <div class="gy-trainer-avatar">
          <div class="gy-tfig" aria-hidden="true">
            <div class="gy-tfig-head"></div>
            <div class="gy-tfig-torso"></div>
            <div class="gy-tfig-arm-l"></div>
            <div class="gy-tfig-arm-r"></div>
            <div class="gy-tfig-legs">
              <div class="gy-tfig-leg-l"></div>
              <div class="gy-tfig-leg-r"></div>
            </div>
          </div>
        </div>
        <div class="gy-trainer-body">
          <div class="gy-trainer-name">Priya Sharma</div>
          <div class="gy-trainer-role">Yoga & Recovery Coach</div>
          <p class="gy-trainer-spec">RYT-500 certified yoga teacher and sports massage therapist. Priya's mobility sessions have transformed injury recovery for hundreds of members.</p>
          <div class="gy-trainer-certs">
            <span class="gy-trainer-cert">RYT-500</span>
            <span class="gy-trainer-cert">Sports Massage</span>
            <span class="gy-trainer-cert">Pilates Cert.</span>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- ── FACILITY ───────────────────────────────────────────────── -->
<section class="gy-section gy-section--ash">
  <div class="gy-container">

    <div style="text-align:center;max-width:600px;margin:0 auto 56px">
      <div class="gy-eyebrow gy-eyebrow--dark" style="justify-content:center">Our Facility</div>
      <h2 class="gy-h2">World-Class Equipment</h2>
      <p style="color:#555;margin-top:16px;line-height:1.7">
        Over 15,000 sq ft of premium training space in the heart of Manchester city centre,
        designed for every goal from beginner to elite.
      </p>
    </div>

    <div class="gy-facility-grid gy-reveal">
      <?php
      $tiles = [
        ['label'=>'Main Strength Floor — 5,000 sq ft of Free Weights & Rack Stations','bg'=>'linear-gradient(135deg,#1A1A2E 0%,#2D3561 100%)','emoji'=>'🏋️‍♀️'],
        ['label'=>'Cardio Zone — 60 Machines with Personal Screens','bg'=>'linear-gradient(135deg,#1A1A2E 0%,#3D1A2E 100%)','emoji'=>'🏃'],
        ['label'=>'Group Studio — Classes Every Hour','bg'=>'linear-gradient(135deg,#1A2E1A 0%,#1A4A1A 100%)','emoji'=>'🧘'],
        ['label'=>'25m Pool & Spa Suite','bg'=>'linear-gradient(135deg,#1A1A2E 0%,#003456 100%)','emoji'=>'🏊'],
      ];
      foreach($tiles as $t):?>
      <div class="gy-facility-tile">
        <div class="gy-facility-bg" style="background:<?=esc_attr($t['bg'])?>"></div>
        <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-size:4rem;opacity:.15"><?=esc_html($t['emoji'])?></div>
        <div class="gy-facility-label"><?=esc_html($t['label'])?></div>
      </div>
      <?php endforeach;?>
    </div>

  </div>
</section>

<!-- ── MEMBERSHIP ────────────────────────────────────────────── -->
<section class="gy-section gy-section--iron-lt" id="membership">
  <div class="gy-container">

    <div style="text-align:center;max-width:600px;margin:0 auto 64px">
      <div class="gy-eyebrow" style="justify-content:center">Membership Plans</div>
      <h2 class="gy-h2" style="color:var(--gy-white)">Choose Your Plan</h2>
      <p style="color:rgba(255,255,255,.65);margin-top:16px;line-height:1.7">No hidden fees. No long-term contracts. Cancel any time.</p>
    </div>

    <div class="gy-membership-grid">

      <!-- Starter -->
      <div class="gy-mem-card gy-mem-card--standard gy-reveal">
        <div class="gy-mem-top">
          <div class="gy-mem-badge">Starter</div>
          <div class="gy-mem-name">Gym Only</div>
          <div class="gy-mem-price"><sup>£</sup>29</div>
          <div class="gy-mem-period">per month, cancel any time</div>
        </div>
        <div class="gy-mem-body">
          <?php
          $features = ['Gym floor access 6am–11pm','Locker room & showers','Induction session included','App-based workout plans','5 guest passes per year'];
          foreach($features as $f):?>
          <div class="gy-mem-feature">
            <div class="gy-mem-check">✓</div>
            <span><?=esc_html($f)?></span>
          </div>
          <?php endforeach;?>
          <div class="gy-mem-btn"><a href="#booking" class="gy-btn gy-btn--outline" style="width:100%;justify-content:center">Get Started</a></div>
        </div>
      </div>

      <!-- Elite (featured) -->
      <div class="gy-mem-card gy-mem-card--elite gy-reveal">
        <div class="gy-mem-top">
          <div class="gy-mem-badge">⭐ Most Popular</div>
          <div class="gy-mem-name">All Access</div>
          <div class="gy-mem-price"><sup>£</sup>59</div>
          <div class="gy-mem-period">per month, no contract</div>
        </div>
        <div class="gy-mem-body">
          <?php
          $features = ['Everything in Gym Only','Unlimited group classes','25m pool & spa access','2 x PT sessions/month','Nutrition coaching included','Priority booking for classes','Free Sports Massage/month'];
          foreach($features as $f):?>
          <div class="gy-mem-feature">
            <div class="gy-mem-check">✓</div>
            <span><?=esc_html($f)?></span>
          </div>
          <?php endforeach;?>
          <div class="gy-mem-btn"><a href="#booking" class="gy-btn gy-btn--volt" style="width:100%;justify-content:center">Join Now</a></div>
        </div>
      </div>

      <!-- Corporate -->
      <div class="gy-mem-card gy-mem-card--premium gy-reveal">
        <div class="gy-mem-top">
          <div class="gy-mem-badge">Business</div>
          <div class="gy-mem-name">Corporate</div>
          <div class="gy-mem-price"><sup>£</sup>44</div>
          <div class="gy-mem-period">per employee per month (5+ staff)</div>
        </div>
        <div class="gy-mem-body">
          <?php
          $features = ['All Access membership for each employee','Dedicated HR wellness dashboard','Quarterly usage reports','Company-branded locker bank','Annual fitness assessment','Flexible invoice billing'];
          foreach($features as $f):?>
          <div class="gy-mem-feature">
            <div class="gy-mem-check">✓</div>
            <span><?=esc_html($f)?></span>
          </div>
          <?php endforeach;?>
          <div class="gy-mem-btn"><a href="#booking" class="gy-btn gy-btn--flame" style="width:100%;justify-content:center">Contact Us</a></div>
        </div>
      </div>

    </div>

    <p style="text-align:center;margin-top:32px;color:rgba(255,255,255,.45);font-size:.9rem">
      💪 Day passes from £12 — perfect for visiting members or trying before you join
    </p>

  </div>
</section>

<!-- ── PROCESS ───────────────────────────────────────────────── -->
<section class="gy-section gy-section--steel">
  <div class="gy-container">

    <div style="text-align:center;max-width:600px;margin:0 auto 72px">
      <div class="gy-eyebrow" style="justify-content:center">Getting Started</div>
      <h2 class="gy-h2" style="color:var(--gy-white)">Your First 30 Days</h2>
    </div>

    <div class="gy-process-grid">
      <?php
      $steps = [
        ['icon'=>'📋','title'=>'Free Trial','desc'=>'Book your complimentary 7-day pass online with no card required.'],
        ['icon'=>'🤝','title'=>'Induction','desc'=>'Meet your trainer for a full induction, health screen and goal-setting session.'],
        ['icon'=>'📅','title'=>'Your Plan','desc'=>'Receive a personalised training and nutrition plan built around your schedule.'],
        ['icon'=>'🔥','title'=>'Transform','desc'=>'Train, track your progress and hit milestones with your coach every step of the way.'],
      ];
      foreach($steps as $i=>$s):?>
      <div class="gy-process-step gy-reveal">
        <div class="gy-process-icon">
          <?=esc_html($s['icon'])?>
          <div class="gy-process-num"><?=$i+1?></div>
        </div>
        <h3 class="gy-process-title"><?=esc_html($s['title'])?></h3>
        <p class="gy-process-desc"><?=esc_html($s['desc'])?></p>
      </div>
      <?php endforeach;?>
    </div>

  </div>
</section>

<!-- ── TESTIMONIALS ──────────────────────────────────────────── -->
<section class="gy-section gy-section--dark">
  <div class="gy-container">

    <div style="text-align:center;max-width:600px;margin:0 auto 64px">
      <div class="gy-eyebrow" style="justify-content:center">Member Results</div>
      <h2 class="gy-h2" style="color:var(--gy-white)">Real People,<br>Real Transformations</h2>
    </div>

    <div class="gy-testi-grid">
      <?php
      $testis = [
        [
          'text'=>'Lost 18kg in 5 months and competed in my first powerlifting meet at 41. Marcus\'s programming is genuinely elite. Never thought I\'d feel this strong.',
          'name'=>'David Callaghan','meta'=>'Lost 18kg · Powerlifting Meet Competitor','avatar'=>'💪'
        ],
        [
          'text'=>'Jade\'s 6am HIIT classes are the reason I get up in the morning. The community here is unlike any gym I\'ve been to. My resting heart rate dropped by 12bpm.',
          'name'=>'Aisha Mohammed','meta'=>'Half Marathon PB · All Access Member','avatar'=>'🏃‍♀️'
        ],
        [
          'text'=>'After my shoulder surgery I was told I\'d never bench heavy again. Priya\'s mobility work and Marcus\'s rehab coaching proved every doctor wrong. Back to 100kg.',
          'name'=>'Tom Harrison','meta'=>'Injury Recovery · Back to 100kg Bench','avatar'=>'🏋️'
        ],
      ];
      foreach($testis as $t):?>
      <div class="gy-testi-card gy-reveal">
        <div class="gy-testi-quote">"</div>
        <p class="gy-testi-text"><?=esc_html($t['text'])?></p>
        <div class="gy-testi-stars">★★★★★</div>
        <div class="gy-testi-author">
          <div class="gy-testi-avatar"><?=esc_html($t['avatar'])?></div>
          <div>
            <div class="gy-testi-name"><?=esc_html($t['name'])?></div>
            <div class="gy-testi-meta"><?=esc_html($t['meta'])?></div>
          </div>
        </div>
      </div>
      <?php endforeach;?>
    </div>

  </div>
</section>

<!-- ── FAQ ───────────────────────────────────────────────────── -->
<section class="gy-section gy-section--iron-lt">
  <div class="gy-container">

    <div style="text-align:center;max-width:560px;margin:0 auto 56px">
      <div class="gy-eyebrow" style="justify-content:center">FAQ</div>
      <h2 class="gy-h2" style="color:var(--gy-white)">Common Questions</h2>
    </div>

    <div class="gy-faq-grid">
      <?php
      $faqs = [
        ['q'=>'Is there a joining fee?','a'=>'No joining fee, ever. Your first payment is your first monthly membership, and you can cancel with 30 days\' notice at any time.'],
        ['q'=>'Do I get a free trial?','a'=>'Yes — we offer a 7-day free pass with no credit card required. Simply book online and come in for your induction session.'],
        ['q'=>'What are your opening hours?','a'=>'We\'re open Monday–Friday 6am–11pm and weekends 7am–9pm. Members with All Access can also use the pool and spa within those hours.'],
        ['q'=>'Is parking available?','a'=>'We have a partner car park directly underneath the building. Members receive 2 hours of free parking per visit with your membership fob.'],
        ['q'=>'Can I freeze my membership?','a'=>'Yes, you can freeze your membership for up to 3 months per year at no cost — ideal for holidays, travel, or injury recovery.'],
        ['q'=>'What\'s included in the induction?','a'=>'Your free 45-minute induction covers a health screen, facility tour, equipment orientation and an initial goal-setting consultation with one of our coaches.'],
      ];
      foreach($faqs as $i=>$f):?>
      <div class="gy-faq-item">
        <button class="gy-faq-q" aria-expanded="false" aria-controls="gy-faq-a-<?=$i?>">
          <?=esc_html($f['q'])?>
          <span class="gy-faq-icon" aria-hidden="true">+</span>
        </button>
        <div class="gy-faq-a" id="gy-faq-a-<?=$i?>" role="region">
          <div class="gy-faq-a-inner"><?=esc_html($f['a'])?></div>
        </div>
      </div>
      <?php endforeach;?>
    </div>

  </div>
</section>

<!-- ── BOOKING ───────────────────────────────────────────────── -->
<section class="gy-section gy-section--dark" id="booking">
  <div class="gy-container">
    <div class="gy-booking-wrap">

      <div class="gy-booking-info gy-reveal">
        <div class="gy-eyebrow">Start Today</div>
        <h2 class="gy-h2" style="color:var(--gy-volt);margin-bottom:16px">Claim Your Free 7-Day Pass</h2>
        <p>Ready to transform your body? Book your free trial today and we'll have everything set up for your first visit. No payment required — just show up and start training.</p>

        <?php
        $bfeats = [
          ['icon'=>'⚡','title'=>'Instant Confirmation','text'=>'You\'ll receive your pass code immediately via email.'],
          ['icon'=>'🏋️','title'=>'No Commitment','text'=>'Try everything for 7 days with absolutely no obligation to join.'],
          ['icon'=>'🤝','title'=>'Personal Welcome','text'=>'Your dedicated coach will meet you for your induction on day one.'],
          ['icon'=>'📱','title'=>'App Access','text'=>'Download our member app and start tracking your workouts from day one.'],
        ];
        foreach($bfeats as $bf):?>
        <div class="gy-booking-feature">
          <div class="gy-booking-feature-icon"><?=esc_html($bf['icon'])?></div>
          <div>
            <div class="gy-booking-feature-title"><?=esc_html($bf['title'])?></div>
            <div class="gy-booking-feature-text"><?=esc_html($bf['text'])?></div>
          </div>
        </div>
        <?php endforeach;?>

      </div>

      <div class="gy-form gy-reveal">
        <div class="gy-form-title">Book Free Trial</div>
        <div class="gy-form-subtitle">Takes 60 seconds — no payment details needed</div>

        <form method="post" action="<?=esc_url(admin_url('admin-post.php'))?>">
          <?php wp_nonce_field('tf_gy_booking','tf_gy_nonce'); ?>
          <input type="hidden" name="action" value="tf_gy_booking">

          <div class="gy-form-row">
            <div class="gy-field">
              <label for="gy-fname">First Name</label>
              <input type="text" id="gy-fname" name="first_name" placeholder="Marcus" required autocomplete="given-name">
            </div>
            <div class="gy-field">
              <label for="gy-lname">Last Name</label>
              <input type="text" id="gy-lname" name="last_name" placeholder="Webb" required autocomplete="family-name">
            </div>
          </div>

          <div class="gy-form-row">
            <div class="gy-field">
              <label for="gy-email">Email Address</label>
              <input type="email" id="gy-email" name="email" placeholder="you@example.com" required autocomplete="email">
            </div>
            <div class="gy-field">
              <label for="gy-phone">Phone Number</label>
              <input type="tel" id="gy-phone" name="phone" placeholder="+44 7700 900000" autocomplete="tel">
            </div>
          </div>

          <div class="gy-field">
            <label for="gy-goal">Your Primary Goal</label>
            <select id="gy-goal" name="goal">
              <option value="">— Select your goal —</option>
              <option value="weight-loss">Weight Loss</option>
              <option value="muscle-gain">Build Muscle</option>
              <option value="strength">Increase Strength</option>
              <option value="fitness">General Fitness</option>
              <option value="sport">Sports Performance</option>
              <option value="rehab">Injury Rehabilitation</option>
            </select>
          </div>

          <div class="gy-field">
            <label for="gy-experience">Training Experience</label>
            <select id="gy-experience" name="experience">
              <option value="">— Select your level —</option>
              <option value="complete-beginner">Complete Beginner</option>
              <option value="some-experience">Some Experience</option>
              <option value="intermediate">Intermediate (1–3 yrs)</option>
              <option value="advanced">Advanced (3+ yrs)</option>
            </select>
          </div>

          <div class="gy-form-row">
            <div class="gy-field">
              <label for="gy-preferred-day">Preferred Start Day</label>
              <input type="date" id="gy-preferred-day" name="preferred_date">
            </div>
            <div class="gy-field">
              <label for="gy-preferred-time">Preferred Time</label>
              <select id="gy-preferred-time" name="preferred_time">
                <option value="">— Select time —</option>
                <option value="early-morning">Early Morning (6–8am)</option>
                <option value="morning">Morning (8–11am)</option>
                <option value="lunch">Lunchtime (11am–2pm)</option>
                <option value="afternoon">Afternoon (2–5pm)</option>
                <option value="evening">Evening (5–9pm)</option>
              </select>
            </div>
          </div>

          <div class="gy-field">
            <label for="gy-message">Anything Else We Should Know?</label>
            <textarea id="gy-message" name="message" placeholder="Injuries, health conditions, specific goals..."></textarea>
          </div>

          <button type="submit" class="gy-btn gy-btn--volt" style="width:100%;justify-content:center;font-size:1.05rem;padding:16px">
            ⚡ Claim My Free Trial
          </button>
          <p style="text-align:center;margin-top:12px;font-size:.8rem;color:rgba(255,255,255,.4)">
            No payment required. No commitment. Cancel any time.
          </p>

        </form>
      </div>

    </div>
  </div>
</section>

<!-- ── FOOTER CTA ─────────────────────────────────────────────── -->
<section class="gy-footer-cta">
  <div class="gy-container" style="position:relative;z-index:1">
    <div class="gy-eyebrow" style="justify-content:center">Iron Works Gym</div>
    <h2 class="gy-h2">Manchester's Premier<br>Fitness Destination</h2>
    <p>Visit us at 14 Spinningfields, Manchester M3 3JE — open 7 days, 365 days a year.</p>
    <div style="display:flex;gap:16px;justify-content:center;flex-wrap:wrap">
      <a href="tel:01612340000" class="gy-btn gy-btn--volt">📞 0161 234 0000</a>
      <a href="#booking" class="gy-btn gy-btn--outline">Book Free Trial</a>
    </div>
  </div>
</section>

</div><!-- /gy-wrap -->

<!-- ── JAVASCRIPT ─────────────────────────────────────────────── -->
<script>
(function(){

  /* animated counters */
  const easeOut = t => 1 - Math.pow(1-t,3);
  document.querySelectorAll('.gy-stat-num[data-target]').forEach(el=>{
    const target = parseFloat(el.dataset.target);
    const suffix = el.dataset.suffix||'';
    if(isNaN(target)) return;
    const obs = new IntersectionObserver(entries=>{
      entries.forEach(e=>{
        if(!e.isIntersecting) return;
        obs.unobserve(e.target);
        const dur=1800, start=performance.now();
        (function tick(now){
          const t = Math.min((now-start)/dur,1);
          el.textContent = Math.round(easeOut(t)*target).toLocaleString() + suffix;
          if(t<1) requestAnimationFrame(tick);
          else el.textContent = target.toLocaleString() + suffix;
        })(start);
      });
    },{threshold:.4});
    obs.observe(el);
  });

  /* FAQ accordion */
  document.querySelectorAll('.gy-faq-q').forEach(btn=>{
    btn.addEventListener('click',function(){
      const item = this.closest('.gy-faq-item');
      const ans  = item.querySelector('.gy-faq-a');
      const open = item.classList.contains('gy-open');
      document.querySelectorAll('.gy-faq-item.gy-open').forEach(o=>{
        o.classList.remove('gy-open');
        o.querySelector('.gy-faq-a').style.maxHeight='0';
        o.querySelector('.gy-faq-q').setAttribute('aria-expanded','false');
      });
      if(!open){
        item.classList.add('gy-open');
        ans.style.maxHeight = ans.scrollHeight+'px';
        this.setAttribute('aria-expanded','true');
      }
    });
  });

  /* scroll reveal */
  const ro = new IntersectionObserver(entries=>{
    entries.forEach((e,i)=>{
      if(!e.isIntersecting) return;
      setTimeout(()=>e.target.classList.add('gy-visible'),i*80);
      ro.unobserve(e.target);
    });
  },{threshold:.12});
  document.querySelectorAll('.gy-reveal').forEach(el=>ro.observe(el));

})();
</script>

<?php get_footer(); ?>
