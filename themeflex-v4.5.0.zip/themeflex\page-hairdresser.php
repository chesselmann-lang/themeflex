<?php
/**
 * Template Name: TF — Luxury Hair Salon
 *
 * Maison Cheveux — Knightsbridge, London
 * Award-winning luxury hairdressing & colour studio
 *
 * @package ThemeFlex
 */

srand(crc32(get_the_permalink()));
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100;0,300;0,600;1,100&family=Crimson+Pro:ital,wght@0,300;0,600;1,300;1,600&display=swap" rel="stylesheet">
<style>
/* ============================================================
   MAISON CHEVEUX — CSS CUSTOM PROPERTIES
   ============================================================ */
:root {
  --hs-black:     #0E0D0C;   /* near-black warm             */
  --hs-dark:      #1A1714;   /* rich dark                   */
  --hs-rose:      #C4848A;   /* dusty rose                  */
  --hs-rose-lt:   #D9A0A6;   /* light rose                  */
  --hs-blush:     #F2E8E5;   /* blush white                 */
  --hs-cream:     #FAF7F4;   /* warm cream                  */
  --hs-ivory:     #F3EDE8;   /* antique ivory               */
  --hs-taupe:     #8A7A72;   /* warm taupe                  */
  --hs-champagne: #C8A870;   /* champagne gold              */
  --hs-champagne-lt: #DEC090; /* light champagne            */
  --hs-mirror:    rgba(255,255,255,.06);

  --hs-serif: 'Crimson Pro', Georgia, serif;
  --hs-sans:  'Josefin Sans', system-ui, sans-serif;

  --hs-radius: 0px;
  --hs-shadow: 0 16px 60px rgba(14,13,12,.18);
}

/* ============================================================
   RESET & BASE
   ============================================================ */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; }
body.page-template-page-hairdresser {
  font-family: var(--hs-sans);
  background: var(--hs-cream);
  color: var(--hs-dark);
  line-height: 1.7;
  overflow-x: hidden;
}
.hs-container { max-width: 1200px; margin: 0 auto; padding: 0 40px; }
.hs-section { padding: 100px 0; }
.hs-tag {
  display: inline-block;
  font-family: var(--hs-sans);
  font-size: .65rem;
  font-weight: 600;
  letter-spacing: .32em;
  text-transform: uppercase;
  color: var(--hs-rose);
  margin-bottom: 16px;
}
.hs-heading {
  font-family: var(--hs-serif);
  font-size: clamp(2rem, 4vw, 3.4rem);
  font-weight: 600;
  line-height: 1.2;
  color: var(--hs-dark);
}
.hs-heading em { font-style: italic; font-weight: 300; color: var(--hs-rose); }
.hs-lead {
  font-size: .94rem;
  color: var(--hs-taupe);
  line-height: 1.9;
  max-width: 580px;
  font-weight: 300;
}
.hs-btn {
  display: inline-block;
  padding: 13px 36px;
  font-family: var(--hs-sans);
  font-size: .72rem;
  font-weight: 600;
  letter-spacing: .2em;
  text-transform: uppercase;
  text-decoration: none;
  transition: all .25s ease;
  cursor: pointer;
  border: none;
}
.hs-btn-primary {
  background: var(--hs-dark);
  color: var(--hs-cream);
}
.hs-btn-primary:hover { background: #2A2320; transform: translateY(-2px); box-shadow: 0 8px 28px rgba(14,13,12,.3); }
.hs-btn-rose {
  background: var(--hs-rose);
  color: var(--hs-cream);
}
.hs-btn-rose:hover { background: var(--hs-rose-lt); }
.hs-btn-ghost {
  background: transparent;
  color: var(--hs-blush);
  border: 1px solid rgba(242,232,229,.4);
}
.hs-btn-ghost:hover { border-color: var(--hs-blush); background: rgba(242,232,229,.08); }
.hs-btn-outline {
  background: transparent;
  color: var(--hs-dark);
  border: 1px solid rgba(14,13,12,.25);
}
.hs-btn-outline:hover { background: rgba(14,13,12,.05); }

/* ============================================================
   HERO — LUXURY SALON INTERIOR AT GOLDEN HOUR
   ============================================================ */
.hs-hero {
  position: relative;
  min-height: 100vh;
  background: var(--hs-dark);
  display: flex;
  align-items: center;
  overflow: hidden;
}

/* Salon background gradient — warm soft light */
.hs-salon-bg {
  position: absolute;
  inset: 0;
  background: linear-gradient(160deg,
    #1A1714 0%,
    #221E1A 25%,
    #2A2218 55%,
    #1E1A14 80%,
    #141210 100%);
  z-index: 0;
}

/* Salon ceiling — coffered plaster with rose gold trim */
.hs-salon-ceiling {
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 16%;
  background: #111008;
  z-index: 1;
}
.hs-salon-ceiling::before {
  content: '';
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    90deg,
    transparent 0px, transparent 120px,
    rgba(200,168,112,.06) 120px, rgba(200,168,112,.06) 122px
  );
}
.hs-salon-ceiling::after {
  content: '';
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 8px;
  background: linear-gradient(180deg, rgba(200,168,112,.2) 0%, transparent 100%);
}

/* Salon wall — herringbone panelling */
.hs-salon-wall {
  position: absolute;
  top: 16%; left: 0; right: 0;
  height: 48%;
  background: #1E1A14;
  z-index: 1;
}
.hs-salon-wall::before {
  content: '';
  position: absolute;
  inset: 0;
  /* Vertical dado panels */
  background: repeating-linear-gradient(
    90deg,
    transparent 0px, transparent 160px,
    rgba(200,168,112,.06) 160px, rgba(200,168,112,.06) 162px
  );
}
/* Dado rail */
.hs-dado-rail {
  position: absolute;
  top: calc(16% + 45%);
  left: 0; right: 0;
  height: 6px;
  background: linear-gradient(180deg, rgba(200,168,112,.3) 0%, rgba(200,168,112,.15) 100%);
  z-index: 3;
}
.hs-dado-rail::before {
  content: '';
  position: absolute;
  top: -3px; left: 0; right: 0;
  height: 3px;
  background: rgba(200,168,112,.15);
}

/* Salon floor — dark herringbone marble */
.hs-salon-floor {
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 36%;
  background: #0E0C0A;
  z-index: 1;
}
.hs-salon-floor::before {
  content: '';
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    45deg,
    transparent 0px, transparent 22px,
    rgba(255,255,255,.025) 22px, rgba(255,255,255,.025) 24px
  );
}
.hs-salon-floor::after {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 5px;
  background: linear-gradient(90deg, transparent 0%, rgba(200,168,112,.2) 50%, transparent 100%);
}

/* Long salon mirror wall — left side */
.hs-mirror-wall {
  position: absolute;
  top: 16%; left: 0;
  width: 42%;
  bottom: 36%;
  z-index: 2;
  display: flex;
  gap: 2px;
}
/* Individual mirrors */
<?php for ($mi = 0; $mi < 3; $mi++):?>
.hs-mirror-<?php echo $mi; ?> {
  flex: 1;
  height: 100%;
  background: linear-gradient(135deg,
    rgba(255,255,255,.06) 0%,
    rgba(255,255,255,.03) 40%,
    rgba(200,168,112,.04) 70%,
    rgba(255,255,255,.02) 100%);
  border: 1px solid rgba(200,168,112,.18);
  position: relative;
}
/* Mirror frame */
.hs-mirror-<?php echo $mi; ?>::before {
  content: '';
  position: absolute;
  inset: 8px;
  border: 1px solid rgba(200,168,112,.1);
}
/* Mirror reflection highlight */
.hs-mirror-<?php echo $mi; ?>::after {
  content: '';
  position: absolute;
  top: 10%; left: 5%;
  width: 20%;
  height: 60%;
  background: linear-gradient(180deg, rgba(255,255,255,.06) 0%, transparent 100%);
  border-radius: 50%;
}
<?php endfor; ?>

/* Hollywood mirror lights (round bulbs around mirror) */
<?php
$bulb_positions = [];
for ($bp = 0; $bp < 14; $bp++):
  $angle = $bp * (360/14) * (M_PI/180);
  $bx = 50 + 44 * cos($angle - M_PI/2);
  $by = 50 + 44 * sin($angle - M_PI/2);
  $bulb_positions[] = ['x'=>round($bx,1), 'y'=>round($by,1)];
endfor;
?>
.hs-hm-wrap {
  position: absolute;
  top: 16%; right: 18%;
  width: 200px;
  height: 200px;
  z-index: 6;
}
.hs-hm-glass {
  position: absolute;
  inset: 22px;
  background: linear-gradient(135deg,
    rgba(255,255,255,.08) 0%,
    rgba(255,255,255,.04) 50%,
    rgba(200,168,112,.05) 100%);
  border: 2px solid rgba(200,168,112,.25);
  border-radius: 50%;
}
.hs-hm-glass::before {
  content: '';
  position: absolute;
  top: 10%; left: 8%;
  width: 25%; height: 40%;
  background: rgba(255,255,255,.07);
  border-radius: 50%;
  transform: rotate(-30deg);
}
<?php foreach ($bulb_positions as $bpi => $bp):?>
.hs-hm-bulb-<?php echo $bpi; ?> {
  position: absolute;
  top: <?php echo $bp['y']; ?>%;
  left: <?php echo $bp['x']; ?>%;
  width: 12px; height: 12px;
  transform: translate(-50%,-50%);
  background: radial-gradient(circle, rgba(255,240,180,.9) 0%, rgba(255,200,80,.6) 40%, transparent 70%);
  border-radius: 50%;
}
.hs-hm-bulb-<?php echo $bpi; ?>::before {
  content: '';
  position: absolute;
  inset: -4px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(255,220,120,.2) 0%, transparent 70%);
}
<?php endforeach; ?>

/* Salon chairs — 3 styling chairs */
<?php
$chairs = [
  ['left'=>'12%', 'scale'=>'.95'],
  ['left'=>'34%', 'scale'=>'1'],
  ['left'=>'56%', 'scale'=>'.9'],
];
foreach ($chairs as $ci => $ch):?>
.hs-chair-<?php echo $ci; ?> {
  position: absolute;
  bottom: 36%; left: <?php echo $ch['left']; ?>;
  transform: scale(<?php echo $ch['scale']; ?>);
  transform-origin: bottom center;
  z-index: 5;
}
/* Chair seat */
.hs-chair-<?php echo $ci; ?>-seat {
  width: 60px;
  height: 20px;
  background: linear-gradient(180deg, #2A2420 0%, #1A1410 100%);
  border-radius: 3px;
  position: relative;
}
.hs-chair-<?php echo $ci; ?>-seat::before {
  content: '';
  position: absolute;
  inset: 0;
  border: 1px solid rgba(200,168,112,.2);
  border-radius: 3px;
}
/* Chair back */
.hs-chair-<?php echo $ci; ?>-back {
  width: 60px;
  height: 80px;
  background: linear-gradient(180deg, #1A1410 0%, #2A2420 100%);
  border-radius: 3px 3px 0 0;
  border: 1px solid rgba(200,168,112,.15);
  margin-bottom: 2px;
  position: relative;
}
/* Headrest */
.hs-chair-<?php echo $ci; ?>-back::before {
  content: '';
  position: absolute;
  top: -12px; left: 50%; transform: translateX(-50%);
  width: 50px; height: 12px;
  background: linear-gradient(180deg, #222 0%, #1A1410 100%);
  border-radius: 2px;
  border: 1px solid rgba(200,168,112,.12);
}
/* Armrests */
.hs-chair-<?php echo $ci; ?>-back::after {
  content: '';
  position: absolute;
  bottom: -10px; left: -8px; right: -8px;
  height: 8px;
  background: linear-gradient(180deg, #222 0%, #1A1410 100%);
  border-radius: 2px;
}
/* Hydraulic base */
.hs-chair-<?php echo $ci; ?>-base {
  width: 8px;
  height: 50px;
  background: linear-gradient(180deg, #555 0%, #333 100%);
  margin: 0 auto;
}
/* Star base */
.hs-chair-<?php echo $ci; ?>-star {
  width: 70px;
  height: 10px;
  background: linear-gradient(180deg, #444 0%, #222 100%);
  border-radius: 0 0 2px 2px;
  clip-path: polygon(5% 0%, 95% 0%, 100% 100%, 0% 100%);
  margin: 0 auto;
}
<?php endforeach; ?>

/* Styling counters / stations below mirrors */
.hs-styling-counter {
  position: absolute;
  bottom: 36%; left: 0;
  width: 42%;
  height: 40px;
  background: linear-gradient(180deg, #2A2420 0%, #1A1410 100%);
  z-index: 4;
  border-top: 2px solid rgba(200,168,112,.25);
}
.hs-styling-counter::before {
  content: '';
  position: absolute;
  bottom: -20px; left: 0; right: 0;
  height: 20px;
  background: linear-gradient(180deg, #1A1410 0%, #111008 100%);
}
/* Product bottles on counter */
<?php
$bottles = [];
for ($b = 0; $b < 12; $b++):
  $bottles[] = [
    'h'   => 28 + rand(0,18),
    'w'   => 7 + rand(0,5),
    'hue' => [340,320,0,20,180,200,280,160][rand(0,7)],
    'l'   => 4 + $b * 8.5,
  ];
endfor;
foreach ($bottles as $bi => $bt):?>
.hs-bottle-<?php echo $bi; ?> {
  position: absolute;
  bottom: calc(36% + 42px);
  left: <?php echo $bt['l']; ?>%;
  width: <?php echo $bt['w']; ?>px;
  height: <?php echo $bt['h']; ?>px;
  background: linear-gradient(180deg,
    hsl(<?php echo $bt['hue']; ?>,20%,18%) 0%,
    hsl(<?php echo $bt['hue']; ?>,15%,12%) 100%);
  border-radius: 1px 1px 0 0;
  z-index: 5;
  border: 1px solid rgba(200,168,112,.12);
}
.hs-bottle-<?php echo $bi; ?>::before {
  content: '';
  position: absolute;
  top: -5px; left: 30%; right: 30%;
  height: 6px;
  background: rgba(200,168,112,.3);
  border-radius: 1px 1px 0 0;
}
<?php endforeach; ?>

/* Hanging plants (eucalyptus) */
<?php for ($pl = 0; $pl < 3; $pl++):
  $pll = 70 + $pl * 10;
?>
.hs-plant-<?php echo $pl; ?> {
  position: absolute;
  top: 16%;
  left: <?php echo $pll; ?>%;
  z-index: 4;
}
.hs-plant-<?php echo $pl; ?>-string {
  width: 1px;
  height: 60px;
  background: rgba(200,168,112,.3);
  margin: 0 auto;
}
.hs-plant-<?php echo $pl; ?>-pot {
  width: 24px; height: 18px;
  background: linear-gradient(180deg, #4A3828 0%, #2E2218 100%);
  border-radius: 0 0 3px 3px;
  clip-path: polygon(5% 0%, 95% 0%, 90% 100%, 10% 100%);
  margin: 0 auto;
}
/* Trailing leaves */
<?php for ($lf = 0; $lf < 6; $lf++):
  $la = -20 + $lf * 9;
  $ll = -8 + $lf * 6;
  $lh = 20 + rand(0,25);
?>
.hs-leaf-<?php echo $pl; ?>-<?php echo $lf; ?> {
  position: absolute;
  top: <?php echo 78 + $lf * 10; ?>px;
  left: <?php echo $ll; ?>px;
  width: 14px;
  height: <?php echo $lh; ?>px;
  background: radial-gradient(ellipse at 50% 30%, #4A6A3A 0%, #2E4A20 100%);
  border-radius: 50% 50% 50% 0;
  transform: rotate(<?php echo $la; ?>deg);
  transform-origin: top right;
}
<?php endfor; endfor; ?>

/* Overhead salon lights — row of pendants */
<?php for ($sl = 0; $sl < 6; $sl++):
  $sll = 8 + $sl * 16;
?>
.hs-sl-<?php echo $sl; ?> {
  position: absolute;
  top: 16%;
  left: <?php echo $sll; ?>%;
  z-index: 6;
}
.hs-sl-<?php echo $sl; ?>-wire {
  width: 1px;
  height: 55px;
  background: rgba(200,168,112,.25);
  margin: 0 auto;
}
.hs-sl-<?php echo $sl; ?>-shade {
  width: 30px;
  height: 0;
  border-left: 15px solid transparent;
  border-right: 15px solid transparent;
  border-top: 20px solid rgba(30,25,18,.9);
  margin: 0 auto;
}
.hs-sl-<?php echo $sl; ?>-glow {
  position: absolute;
  top: 55px; left: 50%; transform: translateX(-50%);
  width: 80px;
  height: 120px;
  background: radial-gradient(ellipse at 50% 0%, rgba(255,220,160,.12) 0%, transparent 70%);
}
<?php endfor; ?>

/* Floating flower petals */
<?php
$petals = [];
for ($p = 0; $p < 20; $p++):
  $petals[] = [
    'left' => rand(0,100),
    'top'  => rand(10,80),
    'size' => 4 + rand(0,8),
    'rot'  => rand(0,360),
    'dur'  => (20 + rand(0,15)) / 10,
    'del'  => rand(0,20) / 10,
    'hue'  => [340,350,0,320,300][rand(0,4)],
    'sat'  => 20 + rand(0,30),
    'lit'  => 65 + rand(0,20),
  ];
endfor;
foreach ($petals as $pi => $pt):?>
.hs-petal-<?php echo $pi; ?> {
  position: absolute;
  top: <?php echo $pt['top']; ?>%;
  left: <?php echo $pt['left']; ?>%;
  width: <?php echo $pt['size']; ?>px;
  height: <?php echo $pt['size'] * 1.5; ?>px;
  background: hsl(<?php echo $pt['hue']; ?>,<?php echo $pt['sat']; ?>%,<?php echo $pt['lit']; ?>%);
  border-radius: 50% 0;
  transform: rotate(<?php echo $pt['rot']; ?>deg);
  opacity: .18;
  z-index: 7;
  animation: hs-petal-drift <?php echo $pt['dur']; ?>s ease-in-out infinite alternate;
  animation-delay: <?php echo $pt['del']; ?>s;
}
<?php endforeach; ?>
@keyframes hs-petal-drift {
  0%   { transform: rotate(var(--r, 0deg)) translateY(0); }
  100% { transform: rotate(calc(var(--r, 0deg) + 15deg)) translateY(-12px); }
}

/* Warm light pool on floor */
.hs-floor-glow {
  position: absolute;
  bottom: 36%; left: 50%; transform: translateX(-50%);
  width: 60%;
  height: 120px;
  background: radial-gradient(ellipse at 50% 100%, rgba(196,132,138,.08) 0%, transparent 70%);
  z-index: 2;
  pointer-events: none;
}

/* Decorative vertical stripe (right panel) */
.hs-right-panel {
  position: absolute;
  top: 16%; right: 0;
  width: 28%;
  bottom: 36%;
  background: #1A1714;
  z-index: 2;
  border-left: 1px solid rgba(200,168,112,.12);
}
.hs-right-panel::before {
  content: '';
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    0deg,
    transparent 0px, transparent 40px,
    rgba(255,255,255,.02) 40px, rgba(255,255,255,.02) 41px
  );
}

/* Framed artwork on right panel */
.hs-artwork {
  position: absolute;
  top: calc(16% + 20%);
  right: 4%;
  width: 20%;
  height: 26%;
  background: #111;
  border: 2px solid rgba(200,168,112,.25);
  z-index: 4;
}
.hs-artwork::before {
  content: '';
  position: absolute;
  inset: 8px;
  background: linear-gradient(135deg,
    hsl(340,20%,15%) 0%,
    hsl(340,15%,12%) 100%);
}
/* Abstract face silhouette in artwork */
.hs-artwork::after {
  content: '';
  position: absolute;
  top: 20%; left: 50%; transform: translateX(-50%);
  width: 40%;
  height: 60%;
  background: rgba(200,168,112,.15);
  border-radius: 50% 50% 40% 40%;
  clip-path: ellipse(50% 60% at 50% 40%);
}

/* Hero overlay */
.hs-hero-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(100deg,
    rgba(14,13,12,.9) 0%,
    rgba(14,13,12,.65) 50%,
    transparent 100%);
  z-index: 12;
}

.hs-hero-content {
  position: relative;
  z-index: 15;
  max-width: 560px;
}
.hs-hero-eyebrow {
  display: inline-flex;
  align-items: center;
  gap: 12px;
  font-size: .65rem;
  font-weight: 100;
  letter-spacing: .36em;
  text-transform: uppercase;
  color: rgba(196,132,138,.8);
  margin-bottom: 28px;
}
.hs-hero-eyebrow::before {
  content: '';
  width: 32px; height: 1px;
  background: var(--hs-rose);
}
.hs-hero-title {
  font-family: var(--hs-serif);
  font-size: clamp(2.6rem, 5.5vw, 5rem);
  font-weight: 600;
  line-height: 1.1;
  color: var(--hs-blush);
  margin-bottom: 16px;
}
.hs-hero-title em {
  font-style: italic;
  font-weight: 300;
  color: var(--hs-rose-lt);
}
.hs-hero-subtitle {
  font-family: var(--hs-serif);
  font-size: clamp(1rem, 2vw, 1.3rem);
  font-weight: 300;
  font-style: italic;
  color: rgba(242,232,229,.6);
  margin-bottom: 32px;
  line-height: 1.6;
}
.hs-hero-btns { display: flex; gap: 14px; flex-wrap: wrap; }

/* Booking card */
.hs-booking-card {
  position: absolute;
  bottom: 40px; right: 40px;
  width: 220px;
  background: rgba(14,13,12,.85);
  border: 1px solid rgba(200,168,112,.25);
  border-radius: var(--hs-radius);
  padding: 22px 20px;
  z-index: 15;
  backdrop-filter: blur(6px);
}
.hs-bc-tag {
  font-size: .6rem;
  font-weight: 600;
  letter-spacing: .2em;
  text-transform: uppercase;
  color: var(--hs-rose);
  margin-bottom: 10px;
}
.hs-bc-title {
  font-family: var(--hs-serif);
  font-size: 1.1rem;
  font-style: italic;
  font-weight: 300;
  color: var(--hs-blush);
  margin-bottom: 4px;
}
.hs-bc-addr {
  font-size: .72rem;
  color: rgba(242,232,229,.4);
  margin-bottom: 14px;
  letter-spacing: .04em;
}
.hs-bc-hours {
  display: flex;
  flex-direction: column;
  gap: 4px;
  margin-bottom: 14px;
}
.hs-bc-hours span {
  font-size: .68rem;
  color: rgba(242,232,229,.5);
  display: flex;
  justify-content: space-between;
}
.hs-bc-hours span b { color: var(--hs-champagne); }

/* ============================================================
   STATS BAR
   ============================================================ */
.hs-stats-bar {
  background: var(--hs-dark);
  border-top: 1px solid rgba(200,168,112,.3);
  padding: 48px 0;
}
.hs-stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  text-align: center;
}
.hs-stat {
  padding: 12px 16px;
  border-right: 1px solid rgba(255,255,255,.06);
}
.hs-stat:last-child { border-right: none; }
.hs-stat-number {
  font-family: var(--hs-serif);
  font-size: 2.8rem;
  font-weight: 600;
  color: var(--hs-rose);
  line-height: 1;
  margin-bottom: 6px;
}
.hs-stat-label {
  font-size: .65rem;
  font-weight: 600;
  letter-spacing: .15em;
  text-transform: uppercase;
  color: rgba(242,232,229,.35);
}

/* ============================================================
   SERVICES / TREATMENTS
   ============================================================ */
.hs-treatments { background: var(--hs-cream); }
.hs-section-header { margin-bottom: 60px; }
.hs-treatments-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1px;
  background: rgba(14,13,12,.07);
}
.hs-treatment-card {
  background: var(--hs-cream);
  padding: 40px 32px;
  position: relative;
  transition: background .25s ease;
  overflow: hidden;
}
.hs-treatment-card:hover { background: var(--hs-ivory); }
.hs-treatment-card::before {
  content: '';
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 2px;
  background: linear-gradient(90deg, var(--hs-rose), var(--hs-champagne));
  transform: scaleX(0);
  transform-origin: left;
  transition: transform .3s ease;
}
.hs-treatment-card:hover::before { transform: scaleX(1); }
.hs-treatment-num {
  font-family: var(--hs-serif);
  font-size: 3rem;
  font-weight: 300;
  font-style: italic;
  color: rgba(196,132,138,.12);
  line-height: 1;
  margin-bottom: 12px;
}
.hs-treatment-card h3 {
  font-family: var(--hs-serif);
  font-size: 1.2rem;
  font-weight: 600;
  color: var(--hs-dark);
  margin-bottom: 6px;
}
.hs-treatment-duration {
  font-size: .65rem;
  font-weight: 600;
  letter-spacing: .18em;
  text-transform: uppercase;
  color: var(--hs-rose);
  margin-bottom: 12px;
}
.hs-treatment-card p {
  font-size: .86rem;
  color: var(--hs-taupe);
  line-height: 1.75;
  font-weight: 300;
}
.hs-treatment-price {
  display: inline-block;
  margin-top: 16px;
  font-family: var(--hs-serif);
  font-size: 1.1rem;
  font-weight: 600;
  color: var(--hs-dark);
}

/* ============================================================
   ABOUT
   ============================================================ */
.hs-about { background: var(--hs-ivory); }
.hs-about-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 80px;
  align-items: center;
}
/* Colour palette art scene */
.hs-colour-scene {
  height: 440px;
  background: var(--hs-dark);
  position: relative;
  overflow: hidden;
}
/* Colour swatches row — hair colour palette */
<?php
$swatches = [
  ['hue'=>30,  'sat'=>40, 'lit'=>65, 'name'=>'Golden Blonde'],
  ['hue'=>28,  'sat'=>55, 'lit'=>45, 'name'=>'Honey Caramel'],
  ['hue'=>20,  'sat'=>60, 'lit'=>30, 'name'=>'Rich Auburn'],
  ['hue'=>10,  'sat'=>40, 'lit'=>20, 'name'=>'Deep Chestnut'],
  ['hue'=>0,   'sat'=>0,  'lit'=>10, 'name'=>'Jet Black'],
  ['hue'=>40,  'sat'=>15, 'lit'=>80, 'name'=>'Platinum Ash'],
  ['hue'=>330, 'sat'=>30, 'lit'=>55, 'name'=>'Rose Blond'],
  ['hue'=>270, 'sat'=>20, 'lit'=>40, 'name'=>'Smokey Violet'],
];
foreach ($swatches as $si => $sw):?>
.hs-swatch-<?php echo $si; ?> {
  position: absolute;
  bottom: 28px;
  left: calc(8% + <?php echo $si; ?> * 11.5%);
  width: 10%;
  height: 44%;
  background: hsl(<?php echo $sw['hue']; ?>,<?php echo $sw['sat']; ?>%,<?php echo $sw['lit']; ?>%);
  border-radius: 2px 2px 0 0;
  z-index: 3;
}
.hs-swatch-<?php echo $si; ?>-label {
  position: absolute;
  bottom: 28px;
  left: calc(8% + <?php echo $si; ?> * 11.5%);
  width: 10%;
  padding-bottom: 4px;
  font-size: .42rem;
  font-weight: 600;
  letter-spacing: .06em;
  text-transform: uppercase;
  color: rgba(255,255,255,.35);
  text-align: center;
  z-index: 4;
  transform: translateY(-100%) translateY(-6px);
}
<?php endforeach; ?>
/* Colour scene light */
.hs-cs-light {
  position: absolute;
  top: 0; left: 50%; transform: translateX(-50%);
  width: 2px; height: 60px;
  background: rgba(200,168,112,.3);
}
.hs-cs-light::before {
  content: '';
  position: absolute;
  bottom: 0; left: 50%; transform: translateX(-50%);
  width: 0; height: 0;
  border-left: 12px solid transparent;
  border-right: 12px solid transparent;
  border-top: 16px solid rgba(30,25,18,.8);
}
.hs-cs-light::after {
  content: '';
  position: absolute;
  top: 60px; left: 50%; transform: translateX(-50%);
  width: 200px; height: 300px;
  background: radial-gradient(ellipse at 50% 0%, rgba(255,220,160,.12) 0%, transparent 70%);
}
/* Hair strand art */
.hs-cs-strands {
  position: absolute;
  top: 10%; left: 30%; right: 30%;
  bottom: 30%;
  z-index: 2;
}
<?php for ($str = 0; $str < 8; $str++):
  $sl = 2 + $str * 13;
  $sdur = 3 + rand(0,2);
  $sdel = rand(0,20)/10;
  $shue = [30,28,20,10,40,330,270,0][rand(0,7)];
?>
.hs-strand-<?php echo $str; ?> {
  position: absolute;
  top: 0;
  left: <?php echo $sl; ?>%;
  width: 2px;
  height: 100%;
  background: linear-gradient(180deg,
    transparent 0%,
    hsl(<?php echo $shue; ?>,30%,40%) 20%,
    hsl(<?php echo $shue; ?>,35%,55%) 50%,
    hsl(<?php echo $shue; ?>,25%,35%) 80%,
    transparent 100%);
  border-radius: 1px;
  opacity: .4;
  animation: hs-strand-sway <?php echo $sdur; ?>s ease-in-out infinite alternate;
  animation-delay: <?php echo $sdel; ?>s;
}
<?php endfor; ?>
@keyframes hs-strand-sway {
  0%   { transform: rotate(-3deg) translateX(-2px); }
  100% { transform: rotate(3deg) translateX(2px); }
}
/* Decorative title inside scene */
.hs-cs-label {
  position: absolute;
  bottom: 46%;
  left: 0; right: 0;
  text-align: center;
  font-family: var(--hs-serif);
  font-size: .75rem;
  font-style: italic;
  font-weight: 300;
  color: rgba(200,168,112,.4);
  letter-spacing: .12em;
  z-index: 5;
}

.hs-about-text {}
.hs-about-values {
  display: flex; flex-direction: column; gap: 28px; margin-top: 36px;
}
.hs-value {
  display: flex; gap: 0;
  padding: 24px;
  background: var(--hs-cream);
  border-left: 3px solid transparent;
  transition: border-color .25s ease;
}
.hs-value:hover { border-left-color: var(--hs-rose); }
.hs-value-body h4 {
  font-family: var(--hs-serif);
  font-size: 1.05rem;
  font-weight: 600;
  color: var(--hs-dark);
  margin-bottom: 6px;
}
.hs-value-body p {
  font-size: .85rem;
  color: var(--hs-taupe);
  line-height: 1.7;
  font-weight: 300;
}

/* ============================================================
   PRICING MENU
   ============================================================ */
.hs-pricing { background: var(--hs-dark); }
.hs-pricing .hs-tag    { color: var(--hs-rose-lt); }
.hs-pricing .hs-heading { color: var(--hs-blush); }
.hs-pricing .hs-heading em { color: var(--hs-rose-lt); }
.hs-pricing-cols {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 40px;
  margin-top: 56px;
}
.hs-price-col h3 {
  font-family: var(--hs-serif);
  font-size: 1.1rem;
  font-weight: 600;
  font-style: italic;
  color: var(--hs-rose-lt);
  margin-bottom: 24px;
  padding-bottom: 12px;
  border-bottom: 1px solid rgba(200,168,112,.2);
}
.hs-price-item {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  padding: 12px 0;
  border-bottom: 1px solid rgba(255,255,255,.04);
}
.hs-price-item:last-child { border-bottom: none; }
.hs-price-name {
  font-size: .84rem;
  color: rgba(242,232,229,.7);
  font-weight: 300;
  line-height: 1.4;
  max-width: 70%;
}
.hs-price-val {
  font-family: var(--hs-serif);
  font-size: .9rem;
  font-weight: 600;
  color: var(--hs-champagne);
  white-space: nowrap;
}
.hs-price-note {
  font-size: .72rem;
  color: rgba(242,232,229,.3);
  margin-top: 20px;
  font-style: italic;
  font-family: var(--hs-serif);
}

/* ============================================================
   PROCESS
   ============================================================ */
.hs-process { background: var(--hs-ivory); }
.hs-process-steps {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 32px;
  margin-top: 56px;
  position: relative;
}
.hs-process-steps::before {
  content: '';
  position: absolute;
  top: 24px; left: 12.5%; right: 12.5%;
  height: 1px;
  background: linear-gradient(90deg, var(--hs-rose) 0%, rgba(196,132,138,.1) 100%);
}
.hs-proc-step { text-align: center; }
.hs-proc-dot {
  width: 48px; height: 48px;
  border-radius: 50%;
  background: var(--hs-dark);
  border: 1px solid var(--hs-rose);
  display: flex; align-items: center; justify-content: center;
  font-family: var(--hs-serif);
  font-size: 1rem;
  font-style: italic;
  color: var(--hs-rose);
  margin: 0 auto 18px;
  position: relative; z-index: 2;
}
.hs-proc-title {
  font-family: var(--hs-serif);
  font-size: .98rem;
  font-weight: 600;
  color: var(--hs-dark);
  margin-bottom: 8px;
}
.hs-proc-desc {
  font-size: .82rem;
  color: var(--hs-taupe);
  line-height: 1.65;
  font-weight: 300;
}

/* ============================================================
   CSS STYLIST FIGURES
   ============================================================ */
.hs-team-section {
  background: var(--hs-dark);
  padding: 100px 0;
  overflow: hidden;
}
.hs-team-section .hs-tag   { color: var(--hs-rose-lt); }
.hs-team-section .hs-heading { color: var(--hs-blush); }
.hs-team-row {
  display: flex; justify-content: center; gap: 60px; margin-top: 60px;
}
.hs-stylist-figure {
  display: flex; flex-direction: column; align-items: center;
}
/* Hair (stylists have expressive hair) */
.hs-stylist-hair {
  width: 46px;
  height: 28px;
  background: linear-gradient(180deg, #2A1A10 0%, #4A2A18 100%);
  border-radius: 50% 50% 0 0;
  position: relative;
}
.hs-stylist-hair::before {
  content: '';
  position: absolute;
  top: -2px; left: -4px; right: -4px;
  height: 10px;
  background: linear-gradient(180deg, #1A0A04 0%, #3A1A0C 100%);
  border-radius: 50% 50% 0 0;
}
/* Head */
.hs-stylist-head {
  width: 38px; height: 42px;
  background: radial-gradient(ellipse at 40% 38%, #ECC8A0 0%, #C89060 100%);
  border-radius: 50% 50% 44% 44%;
  position: relative;
}
/* Earring */
.hs-stylist-head::after {
  content: '';
  position: absolute;
  bottom: 20%; right: 2px;
  width: 4px; height: 6px;
  background: var(--hs-champagne);
  border-radius: 0 0 2px 2px;
}
.hs-stylist-neck {
  width: 12px; height: 8px;
  background: #C89060;
  margin: 0 auto;
}
/* Stylist top — black turtleneck / apron */
.hs-stylist-body {
  width: 56px; height: 68px;
  background: linear-gradient(180deg, #1A1010 0%, #111 100%);
  border-radius: 4px 4px 2px 2px;
  position: relative;
}
/* Salon apron */
.hs-stylist-body::before {
  content: '';
  position: absolute;
  top: 0; left: 50%; transform: translateX(-50%);
  width: 34px; height: 100%;
  background: linear-gradient(180deg, #2A1A18 0%, #1A0E0C 100%);
  clip-path: polygon(5% 0%, 95% 0%, 90% 100%, 10% 100%);
}
/* Scissors in right hand */
.hs-stylist-body::after {
  content: '';
  position: absolute;
  bottom: -4px; right: -16px;
  width: 4px; height: 32px;
  background: linear-gradient(180deg, #A0A0A0 0%, #707070 100%);
  border-radius: 2px;
  transform: rotate(-25deg);
  transform-origin: top center;
}
/* Arms */
.hs-stylist-arm-l {
  position: absolute;
  top: 4px; left: -13px;
  width: 13px; height: 50px;
  background: linear-gradient(180deg, #1A1010 0%, #111 100%);
  border-radius: 6px 3px 3px 6px;
  transform: rotate(6deg);
  transform-origin: top center;
}
.hs-stylist-arm-r {
  position: absolute;
  top: 4px; right: -12px;
  width: 13px; height: 46px;
  background: linear-gradient(180deg, #1A1010 0%, #111 100%);
  border-radius: 3px 6px 6px 3px;
  transform: rotate(-22deg);
  transform-origin: top center;
}
.hs-stylist-legs {
  width: 56px; height: 60px; position: relative;
}
.hs-stylist-leg-l, .hs-stylist-leg-r {
  position: absolute; bottom: 0;
  width: 20px; height: 56px;
  background: linear-gradient(180deg, #111 0%, #080808 100%);
  border-radius: 2px 2px 0 0;
}
.hs-stylist-leg-l { left: 4px; }
.hs-stylist-leg-r { right: 4px; }
.hs-stylist-leg-l::after, .hs-stylist-leg-r::after {
  content: '';
  position: absolute; bottom: 0; left: 0; right: 0;
  height: 9px; background: #030303; border-radius: 0 0 2px 2px;
}
.hs-stylist-name {
  margin-top: 14px;
  font-family: var(--hs-serif);
  font-size: .92rem;
  font-style: italic;
  font-weight: 300;
  color: rgba(242,232,229,.7);
  text-align: center;
}
.hs-stylist-role {
  font-size: .62rem;
  font-weight: 600;
  letter-spacing: .15em;
  text-transform: uppercase;
  color: var(--hs-rose);
  margin-top: 2px;
  text-align: center;
}

/* ============================================================
   TESTIMONIALS
   ============================================================ */
.hs-testimonials { background: var(--hs-cream); }
.hs-testi-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
  margin-top: 52px;
}
.hs-testi-card {
  background: var(--hs-ivory);
  padding: 32px 26px;
  border-top: 2px solid var(--hs-rose);
}
.hs-testi-stars { color: var(--hs-rose); font-size: .82rem; margin-bottom: 14px; }
.hs-testi-text {
  font-family: var(--hs-serif);
  font-style: italic;
  font-weight: 300;
  font-size: .96rem;
  color: var(--hs-dark);
  line-height: 1.78;
  margin-bottom: 18px;
}
.hs-testi-author {
  font-size: .72rem;
  font-weight: 600;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: var(--hs-taupe);
}
.hs-testi-service {
  font-size: .7rem;
  color: var(--hs-rose);
  margin-top: 2px;
}

/* ============================================================
   FAQ
   ============================================================ */
.hs-faq { background: var(--hs-ivory); }
.hs-faq-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 52px;
  align-items: start;
  margin-top: 52px;
}
.hs-faq-list { display: flex; flex-direction: column; gap: 8px; }
.hs-faq-item {
  background: var(--hs-cream);
  border-bottom: 1px solid rgba(14,13,12,.07);
  overflow: hidden;
}
.hs-faq-q {
  display: flex; justify-content: space-between; align-items: center;
  padding: 18px 0;
  cursor: pointer;
  font-family: var(--hs-serif);
  font-size: .98rem;
  font-weight: 600;
  color: var(--hs-dark);
  user-select: none;
  transition: color .2s;
}
.hs-faq-q:hover { color: var(--hs-rose); }
.hs-faq-icon {
  width: 22px; height: 22px;
  border: 1px solid rgba(196,132,138,.4);
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .85rem; color: var(--hs-rose); flex-shrink: 0;
  transition: transform .3s ease;
}
.hs-faq-item.open .hs-faq-icon { transform: rotate(45deg); }
.hs-faq-a { max-height: 0; overflow: hidden; transition: max-height .35s ease; }
.hs-faq-a-inner {
  padding: 0 0 16px;
  font-size: .86rem; color: var(--hs-taupe); line-height: 1.78; font-weight: 300;
}
.hs-faq-item.open .hs-faq-a { max-height: 280px; }

.hs-faq-cta {
  background: var(--hs-dark);
  padding: 40px 32px;
  display: flex; flex-direction: column; gap: 18px;
}
.hs-faq-cta h3 {
  font-family: var(--hs-serif);
  font-size: 1.5rem;
  font-style: italic;
  font-weight: 300;
  color: var(--hs-blush);
  line-height: 1.3;
}
.hs-faq-cta p {
  font-size: .86rem;
  color: rgba(242,232,229,.45);
  line-height: 1.75;
  font-weight: 300;
}
.hs-faq-contact { display: flex; flex-direction: column; gap: 8px; }
.hs-faq-contact a {
  color: var(--hs-rose-lt);
  text-decoration: none;
  font-size: .86rem;
  display: flex; align-items: center; gap: 8px;
  transition: color .2s;
}
.hs-faq-contact a:hover { color: var(--hs-blush); }

/* ============================================================
   BOOKING FORM
   ============================================================ */
.hs-booking { background: var(--hs-dark); }
.hs-booking .hs-tag    { color: var(--hs-rose-lt); }
.hs-booking .hs-heading { color: var(--hs-blush); }
.hs-booking .hs-heading em { color: var(--hs-rose-lt); }
.hs-booking .hs-lead { color: rgba(242,232,229,.45); }
.hs-form-wrapper {
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(196,132,138,.18);
  padding: 48px 44px;
  margin-top: 48px;
  max-width: 860px;
  margin-left: auto;
  margin-right: auto;
}
.hs-form-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 22px;
  margin-bottom: 22px;
}
.hs-form-group { display: flex; flex-direction: column; gap: 8px; }
.hs-form-group.full { grid-column: 1/-1; }
.hs-form-group label {
  font-size: .65rem;
  font-weight: 600;
  letter-spacing: .2em;
  text-transform: uppercase;
  color: rgba(242,232,229,.35);
}
.hs-form-group input,
.hs-form-group select,
.hs-form-group textarea {
  background: rgba(255,255,255,.05);
  border: 1px solid rgba(255,255,255,.08);
  border-bottom: 1px solid rgba(196,132,138,.3);
  padding: 12px 0;
  font-family: var(--hs-sans);
  font-size: .86rem;
  font-weight: 300;
  color: var(--hs-blush);
  outline: none;
  width: 100%;
  background: transparent;
  border-top: none;
  border-left: none;
  border-right: none;
  border-radius: 0;
}
.hs-form-group input::placeholder,
.hs-form-group textarea::placeholder { color: rgba(242,232,229,.2); }
.hs-form-group input:focus,
.hs-form-group select:focus { border-bottom-color: var(--hs-rose); }
.hs-form-group select { cursor: pointer; }
.hs-form-group select option { background: var(--hs-dark); }
.hs-form-group textarea { resize: vertical; min-height: 90px; border: 1px solid rgba(255,255,255,.08); border-radius: 0; padding: 12px; }
.hs-form-group textarea:focus { border-color: var(--hs-rose); }
.hs-form-actions { display: flex; align-items: center; gap: 18px; margin-top: 8px; }
.hs-form-note { font-size: .7rem; color: rgba(242,232,229,.25); line-height: 1.5; font-weight: 300; }
.hs-form-success { display: none; text-align: center; padding: 32px; color: var(--hs-blush); }
.hs-form-success h3 {
  font-family: var(--hs-serif);
  font-size: 1.6rem;
  font-style: italic;
  font-weight: 300;
  color: var(--hs-rose-lt);
  margin-bottom: 8px;
}

/* ============================================================
   FOOTER
   ============================================================ */
.hs-footer {
  background: var(--hs-black);
  padding: 60px 0 32px;
  border-top: 1px solid rgba(196,132,138,.15);
}
.hs-footer-inner {
  display: grid;
  grid-template-columns: 2fr 1fr 1fr;
  gap: 56px;
  margin-bottom: 44px;
}
.hs-footer-brand h3 {
  font-family: var(--hs-serif);
  font-size: 1.5rem;
  font-style: italic;
  font-weight: 300;
  color: var(--hs-blush);
  margin-bottom: 4px;
}
.hs-footer-brand > span {
  font-size: .62rem;
  font-weight: 600;
  letter-spacing: .25em;
  text-transform: uppercase;
  color: var(--hs-rose);
  display: block;
  margin-bottom: 14px;
}
.hs-footer-brand p {
  font-size: .8rem;
  color: rgba(242,232,229,.3);
  line-height: 1.75;
  max-width: 280px;
  font-weight: 300;
}
.hs-footer-col h4 {
  font-size: .62rem;
  font-weight: 600;
  letter-spacing: .22em;
  text-transform: uppercase;
  color: var(--hs-rose);
  margin-bottom: 16px;
}
.hs-footer-col ul { list-style: none; }
.hs-footer-col ul li { margin-bottom: 8px; }
.hs-footer-col ul li a {
  font-size: .8rem;
  font-weight: 300;
  color: rgba(242,232,229,.3);
  text-decoration: none;
  transition: color .2s;
  letter-spacing: .04em;
}
.hs-footer-col ul li a:hover { color: var(--hs-blush); }
.hs-footer-bottom {
  border-top: 1px solid rgba(255,255,255,.05);
  padding-top: 22px;
  display: flex; justify-content: space-between; align-items: center;
}
.hs-footer-bottom p { font-size: .72rem; color: rgba(242,232,229,.18); font-weight: 300; }
.hs-footer-bottom a { font-size: .72rem; color: rgba(196,132,138,.3); text-decoration: none; }
.hs-footer-bottom a:hover { color: var(--hs-rose); }

/* ============================================================
   RESPONSIVE
   ============================================================ */
@media (max-width: 1024px) {
  .hs-about-grid     { grid-template-columns: 1fr; gap: 48px; }
  .hs-colour-scene   { height: 260px; }
  .hs-treatments-grid { grid-template-columns: repeat(2,1fr); }
  .hs-pricing-cols   { grid-template-columns: 1fr; }
  .hs-footer-inner   { grid-template-columns: 1fr 1fr; }
}
@media (max-width: 768px) {
  .hs-section { padding: 64px 0; }
  .hs-container { padding: 0 20px; }
  .hs-stats-grid     { grid-template-columns: repeat(2,1fr); }
  .hs-treatments-grid { grid-template-columns: 1fr; }
  .hs-process-steps  { grid-template-columns: repeat(2,1fr); }
  .hs-process-steps::before { display: none; }
  .hs-testi-grid     { grid-template-columns: 1fr; }
  .hs-faq-grid       { grid-template-columns: 1fr; }
  .hs-form-grid      { grid-template-columns: 1fr; }
  .hs-team-row       { flex-wrap: wrap; gap: 32px; }
  .hs-footer-inner   { grid-template-columns: 1fr; gap: 28px; }
  .hs-footer-bottom  { flex-direction: column; gap: 12px; text-align: center; }
  .hs-booking-card   { display: none; }
}
</style>
<?php get_header(); ?>
<div class="page-template-page-hairdresser">
>

<!-- HERO -->
<section class="hs-hero">
  <div class="hs-salon-bg"></div>
  <div class="hs-salon-ceiling"></div>
  <div class="hs-salon-wall"></div>
  <div class="hs-dado-rail"></div>
  <div class="hs-salon-floor"></div>
  <div class="hs-right-panel"></div>

  <!-- Mirror wall -->
  <div class="hs-mirror-wall">
    <?php for ($mi = 0; $mi < 3; $mi++): ?>
    <div class="hs-mirror-<?php echo $mi; ?>"></div>
    <?php endfor; ?>
  </div>

  <!-- Hollywood mirror -->
  <div class="hs-hm-wrap">
    <div class="hs-hm-glass"></div>
    <?php foreach ($bulb_positions as $bpi => $bp): ?>
    <div class="hs-hm-bulb-<?php echo $bpi; ?>"></div>
    <?php endforeach; ?>
  </div>

  <!-- Artwork -->
  <div class="hs-artwork"></div>

  <!-- Styling chairs -->
  <?php foreach ($chairs as $ci => $ch): ?>
  <div class="hs-chair-<?php echo $ci; ?>">
    <div class="hs-chair-<?php echo $ci; ?>-back"></div>
    <div class="hs-chair-<?php echo $ci; ?>-seat"></div>
    <div class="hs-chair-<?php echo $ci; ?>-base"></div>
    <div class="hs-chair-<?php echo $ci; ?>-star"></div>
  </div>
  <?php endforeach; ?>

  <!-- Styling counter -->
  <div class="hs-styling-counter"></div>

  <!-- Bottles -->
  <?php foreach ($bottles as $bi => $bt): ?>
  <div class="hs-bottle-<?php echo $bi; ?>"></div>
  <?php endforeach; ?>

  <!-- Hanging plants -->
  <?php for ($pl = 0; $pl < 3; $pl++): ?>
  <div class="hs-plant-<?php echo $pl; ?>" style="position:absolute;top:16%;left:<?php echo 70 + $pl * 10; ?>%;z-index:4;">
    <div class="hs-plant-<?php echo $pl; ?>-string"></div>
    <div class="hs-plant-<?php echo $pl; ?>-pot"></div>
    <?php for ($lf = 0; $lf < 6; $lf++): ?>
    <div class="hs-leaf-<?php echo $pl; ?>-<?php echo $lf; ?>" style="position:absolute;"></div>
    <?php endfor; ?>
  </div>
  <?php endfor; ?>

  <!-- Pendant lights -->
  <?php for ($sl = 0; $sl < 6; $sl++): ?>
  <div class="hs-sl-<?php echo $sl; ?>">
    <div class="hs-sl-<?php echo $sl; ?>-wire"></div>
    <div class="hs-sl-<?php echo $sl; ?>-shade"></div>
    <div class="hs-sl-<?php echo $sl; ?>-glow"></div>
  </div>
  <?php endfor; ?>

  <!-- Floating petals -->
  <?php foreach ($petals as $pi => $pt): ?>
  <div class="hs-petal-<?php echo $pi; ?>"></div>
  <?php endforeach; ?>

  <div class="hs-floor-glow"></div>

  <div class="hs-hero-overlay"></div>

  <div class="hs-container" style="position:relative;z-index:15;width:100%;">
    <div class="hs-hero-content">
      <div class="hs-hero-eyebrow">Knightsbridge · London · Est. 2001</div>
      <h1 class="hs-hero-title">
        Art.<br><em>Craft.</em><br>Colour.
      </h1>
      <p class="hs-hero-subtitle">Award-winning hairdressing & colour studio</p>
      <div class="hs-hero-btns" style="margin-top:36px;">
        <a href="#booking" class="hs-btn hs-btn-rose">Book Appointment</a>
        <a href="#treatments" class="hs-btn hs-btn-ghost">Our Services</a>
      </div>
    </div>
  </div>

  <!-- Booking info card -->
  <div class="hs-booking-card">
    <div class="hs-bc-tag">Opening Hours</div>
    <div class="hs-bc-title">Maison Cheveux</div>
    <div class="hs-bc-addr">12 Brompton Road · Knightsbridge SW3</div>
    <div class="hs-bc-hours">
      <span>Mon – Fri <b>9am – 8pm</b></span>
      <span>Saturday <b>9am – 7pm</b></span>
      <span>Sunday <b>10am – 5pm</b></span>
    </div>
    <a href="#booking" class="hs-btn hs-btn-rose" style="font-size:.65rem;padding:10px 20px;width:100%;text-align:center;">Book Now</a>
  </div>
</section>

<!-- STATS BAR -->
<section class="hs-stats-bar">
  <div class="hs-container">
    <div class="hs-stats-grid">
      <?php
      $stats = [
        ['val'=>'23yrs',   'lbl'=>'London Excellence'],
        ['val'=>'14,000+', 'lbl'=>'Happy Clients'],
        ['val'=>'4.9★',    'lbl'=>'Google Rating'],
        ['val'=>'22',      'lbl'=>'Awards Won'],
      ];
      foreach ($stats as $st):?>
      <div class="hs-stat">
        <div class="hs-stat-number" data-target="<?php echo esc_attr($st['val']); ?>"><?php echo esc_html($st['val']); ?></div>
        <div class="hs-stat-label"><?php echo esc_html($st['lbl']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- TREATMENTS -->
<section class="hs-treatments hs-section" id="treatments">
  <div class="hs-container">
    <div class="hs-section-header">
      <span class="hs-tag">Services</span>
      <h2 class="hs-heading">Our <em>Specialities</em></h2>
      <p class="hs-lead" style="margin-top:16px;">Every service begins with a personalised consultation to understand your vision, hair type, and lifestyle.</p>
    </div>
    <div class="hs-treatments-grid">
      <?php
      $treatments = [
        ['n'=>'01','name'=>'Cut & Finish',         'dur'=>'60 – 90 min','price'=>'From £95','desc'=>'Precision cutting tailored to your face shape and hair texture, finished with a bespoke blow-dry or set.'],
        ['n'=>'02','name'=>'Balayage & Ombré',     'dur'=>'2.5 – 3.5 hrs','price'=>'From £220','desc'=>'Hand-painted colour for sun-kissed, natural results with seamless grow-out and lasting vibrancy.'],
        ['n'=>'03','name'=>'Full Colour',           'dur'=>'2 – 3 hrs','price'=>'From £160','desc'=>'Root-to-tip colour or a complete shade transformation, using Olaplex-protected formulas for hair health.'],
        ['n'=>'04','name'=>'Highlights & Lowlights','dur'=>'2 – 3 hrs','price'=>'From £185','desc'=>'Multi-tonal placement for depth, dimension, and movement — foil, freehand, or a combination of both.'],
        ['n'=>'05','name'=>'Keratin Treatment',    'dur'=>'2.5 hrs','price'=>'From £240','desc'=>'Professional smoothing treatment that eliminates frizz, reduces styling time, and adds mirror-like shine for up to 16 weeks.'],
        ['n'=>'06','name'=>'Bridal & Occasion',    'dur'=>'1.5 – 2.5 hrs','price'=>'From £180','desc'=>'Trial included. Bespoke updos, waves, and blowouts for your wedding day, charity gala, or special event.'],
      ];
      foreach ($treatments as $tr):?>
      <div class="hs-treatment-card">
        <div class="hs-treatment-num"><?php echo esc_html($tr['n']); ?></div>
        <h3><?php echo esc_html($tr['name']); ?></h3>
        <div class="hs-treatment-duration"><?php echo esc_html($tr['dur']); ?></div>
        <p><?php echo esc_html($tr['desc']); ?></p>
        <div class="hs-treatment-price"><?php echo esc_html($tr['price']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ABOUT -->
<section class="hs-about hs-section" id="about">
  <div class="hs-container">
    <div class="hs-about-grid">
      <!-- Colour scene -->
      <div class="hs-colour-scene">
        <div class="hs-cs-light"></div>
        <div class="hs-cs-strands">
          <?php for ($str = 0; $str < 8; $str++): ?>
          <div class="hs-strand-<?php echo $str; ?>"></div>
          <?php endfor; ?>
        </div>
        <?php foreach ($swatches as $si => $sw): ?>
        <div class="hs-swatch-<?php echo $si; ?>"></div>
        <div class="hs-swatch-<?php echo $si; ?>-label"><?php echo esc_html($sw['name']); ?></div>
        <?php endforeach; ?>
        <div class="hs-cs-label">The Maison Cheveux Colour Palette</div>
      </div>

      <div class="hs-about-text">
        <span class="hs-tag">Our Story</span>
        <h2 class="hs-heading">Twenty-Three Years of <em>Hair Artistry</em></h2>
        <p class="hs-lead" style="margin-top:18px;">Founded in 2001 by creative director Isabelle Moreau, Maison Cheveux has been the destination for discerning Londoners seeking transformative hairdressing. Our philosophy is simple: listen deeply, cut precisely, colour beautifully.</p>
        <div class="hs-about-values">
          <?php
          $vals = [
            ['title'=>'Bespoke Consultation',  'desc'=>'Every visit begins with a detailed consultation — your lifestyle, hair history, and vision guide every decision we make.'],
            ['title'=>'Hair Health First',      'desc'=>'We use Olaplex, K18, and premium Schwarzkopf Professional colour exclusively to ensure the integrity of your hair is never compromised.'],
            ['title'=>'Ongoing Education',      'desc'=>'Our stylists attend international masterclasses and collections every year to bring the latest techniques from Paris, Milan, and New York.'],
          ];
          foreach ($vals as $v):?>
          <div class="hs-value">
            <div class="hs-value-body">
              <h4><?php echo esc_html($v['title']); ?></h4>
              <p><?php echo esc_html($v['desc']); ?></p>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- PRICING MENU -->
<section class="hs-pricing hs-section" id="pricing">
  <div class="hs-container">
    <div class="hs-section-header">
      <span class="hs-tag">Price List</span>
      <h2 class="hs-heading">Service <em>Menu</em></h2>
    </div>
    <div class="hs-pricing-cols">
      <?php
      $pricecols = [
        ['title'=>'Cutting',
         'items'=>[
           ['name'=>'Blow-dry & Finish',               'price'=>'£55+'],
           ['name'=>'Wash, Cut & Blow-dry',            'price'=>'£95+'],
           ['name'=>'Senior Stylist — Cut & Finish',    'price'=>'£130+'],
           ['name'=>'Creative Director — Cut & Finish', 'price'=>'£195+'],
           ['name'=>'Children Under 12',               'price'=>'£45+'],
           ['name'=>'Fringe Trim (client)',             'price'=>'£18'],
         ]],
        ['title'=>'Colour',
         'items'=>[
           ['name'=>'Root Touch-Up',                   'price'=>'£85+'],
           ['name'=>'Full Head Colour',                 'price'=>'£160+'],
           ['name'=>'Highlights / Lowlights (partial)', 'price'=>'£145+'],
           ['name'=>'Full Balayage',                    'price'=>'£220+'],
           ['name'=>'Colour Correction',               'price'=>'POA'],
           ['name'=>'Toning / Gloss Treatment',        'price'=>'£55+'],
         ]],
        ['title'=>'Treatments & Occasions',
         'items'=>[
           ['name'=>'Keratin Smoothing',               'price'=>'£240+'],
           ['name'=>'Olaplex Bond Treatment',          'price'=>'£45'],
           ['name'=>'K18 Repair Treatment',             'price'=>'£38'],
           ['name'=>'Bridal Trial',                     'price'=>'£95+'],
           ['name'=>'Bridal Day',                       'price'=>'£180+'],
           ['name'=>'Occasion Updo',                   'price'=>'£120+'],
         ]],
      ];
      foreach ($pricecols as $pc):?>
      <div class="hs-price-col">
        <h3><?php echo esc_html($pc['title']); ?></h3>
        <?php foreach ($pc['items'] as $pit):?>
        <div class="hs-price-item">
          <span class="hs-price-name"><?php echo esc_html($pit['name']); ?></span>
          <span class="hs-price-val"><?php echo esc_html($pit['price']); ?></span>
        </div>
        <?php endforeach; ?>
        <p class="hs-price-note">Prices may vary by hair length, thickness, and complexity.</p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- PROCESS -->
<section class="hs-process hs-section">
  <div class="hs-container">
    <div class="hs-section-header">
      <span class="hs-tag">Your Visit</span>
      <h2 class="hs-heading">The <em>Maison</em> Experience</h2>
      <p class="hs-lead" style="margin-top:16px;">From the moment you arrive, every detail is designed around your comfort and transformation.</p>
    </div>
    <div class="hs-process-steps">
      <?php
      $procs = [
        ['n'=>'01','title'=>'Arrival & Welcome',   'desc'=>'You are welcomed with refreshments and invited to our private consultation space before your appointment begins.'],
        ['n'=>'02','title'=>'Deep Consultation',   'desc'=>'We listen. We analyse your hair\'s condition, discuss your vision, and plan every step of your service together.'],
        ['n'=>'03','title'=>'The Service',          'desc'=>'Your treatment is performed by your chosen stylist with the care, time, and craft your hair deserves.'],
        ['n'=>'04','title'=>'Education & Care',     'desc'=>'Before you leave, we walk you through a personalised home care routine and show you exactly how to recreate the look.'],
      ];
      foreach ($procs as $pr):?>
      <div class="hs-proc-step">
        <div class="hs-proc-dot"><?php echo esc_html($pr['n']); ?></div>
        <h3 class="hs-proc-title"><?php echo esc_html($pr['title']); ?></h3>
        <p class="hs-proc-desc"><?php echo esc_html($pr['desc']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- TEAM -->
<section class="hs-team-section">
  <div class="hs-container">
    <div class="hs-section-header" style="margin-bottom:0;">
      <span class="hs-tag">Our Team</span>
      <h2 class="hs-heading">The <em>Artisans</em></h2>
    </div>
    <div class="hs-team-row">
      <?php
      $stylists = [
        ['name'=>'Isabelle Moreau',   'role'=>'Creative Director'],
        ['name'=>'Chloe Nakamura',    'role'=>'Senior Colourist'],
        ['name'=>'Oliver Walsh',       'role'=>'Senior Stylist'],
        ['name'=>'Amara Osei',         'role'=>'Colour Specialist'],
      ];
      foreach ($stylists as $sty):?>
      <div class="hs-stylist-figure">
        <div class="hs-stylist-hair"></div>
        <div class="hs-stylist-head"></div>
        <div class="hs-stylist-neck"></div>
        <div class="hs-stylist-body" style="position:relative;">
          <div class="hs-stylist-arm-l"></div>
          <div class="hs-stylist-arm-r"></div>
        </div>
        <div class="hs-stylist-legs">
          <div class="hs-stylist-leg-l"></div>
          <div class="hs-stylist-leg-r"></div>
        </div>
        <div class="hs-stylist-name"><?php echo esc_html($sty['name']); ?></div>
        <div class="hs-stylist-role"><?php echo esc_html($sty['role']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="hs-testimonials hs-section">
  <div class="hs-container">
    <div class="hs-section-header">
      <span class="hs-tag">Reviews</span>
      <h2 class="hs-heading">What Our Clients <em>Say</em></h2>
    </div>
    <div class="hs-testi-grid">
      <?php
      $testis = [
        ['text'=>'I\'ve been coming to Maison Cheveux for eight years and Isabelle is the only person I trust with my hair. The balayage she created for my wedding was absolutely perfect — I still get compliments now.','author'=>'Alexandra C.','service'=>'Balayage & Bridal Styling'],
        ['text'=>'Chloe completely transformed my colour — took my damaged, over-highlighted hair and gave me the most beautiful, healthy brunette I\'ve had in years. The consultation was so thorough and reassuring.','author'=>'Priya M.','service'=>'Colour Correction'],
        ['text'=>'As someone with very thick, coarse hair I\'ve always struggled to find a stylist who really understands it. Oliver knows my hair better than I do. The keratin treatment changed my life.','author'=>'Sarah T.','service'=>'Keratin Treatment & Cut'],
      ];
      foreach ($testis as $tt):?>
      <div class="hs-testi-card">
        <div class="hs-testi-stars">★★★★★</div>
        <p class="hs-testi-text"><?php echo esc_html($tt['text']); ?></p>
        <div class="hs-testi-author"><?php echo esc_html($tt['author']); ?></div>
        <div class="hs-testi-service"><?php echo esc_html($tt['service']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- FAQ -->
<section class="hs-faq hs-section">
  <div class="hs-container">
    <div class="hs-section-header">
      <span class="hs-tag">Questions</span>
      <h2 class="hs-heading">Your <em>Questions</em> Answered</h2>
    </div>
    <div class="hs-faq-grid">
      <div class="hs-faq-list">
        <?php
        $faqs = [
          ['q'=>'Do I need a consultation before my first colour appointment?','a'=>'For all first-time colour clients we strongly recommend a consultation appointment, particularly for balayage, colour correction, or any lightening service. Consultations are complimentary and can be booked in-salon or via a video call.'],
          ['q'=>'How do I maintain my balayage at home?','a'=>'We provide bespoke home care advice after every colour appointment. We typically recommend a purple toning shampoo once a week, a hydrating mask bi-weekly, and a heat protectant for blow-drying. We also retail the specific products we recommend.'],
          ['q'=>'Can you fix a bad colour from another salon?','a'=>'Yes — colour corrections are one of our specialisms. We ask all colour correction clients to book a free consultation first so we can properly assess your hair, advise on a realistic plan, and provide an accurate quotation. Please do not bleach or colour your hair before the consultation.'],
          ['q'=>'Do you offer a cancellation policy?','a'=>'We ask for 48 hours\' notice to cancel or reschedule an appointment. Cancellations made within 48 hours may be subject to a 50% late cancellation charge. No-shows will be charged in full.'],
          ['q'=>'What products do you use?','a'=>'We use Schwarzkopf Professional colour and lighteners exclusively. For treatments we work with Olaplex, K18, and Phyto. We retail all of these brands in-salon, and our team will recommend exactly what your hair needs.'],
        ];
        foreach ($faqs as $fi => $faq):?>
        <div class="hs-faq-item">
          <div class="hs-faq-q" aria-expanded="false" role="button" tabindex="0">
            <?php echo esc_html($faq['q']); ?>
            <span class="hs-faq-icon">+</span>
          </div>
          <div class="hs-faq-a">
            <div class="hs-faq-a-inner"><?php echo esc_html($faq['a']); ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <div class="hs-faq-cta">
        <h3>Have another question?</h3>
        <p>Our front-of-house team is available six days a week to help with any question — from product advice to booking for large bridal parties.</p>
        <div class="hs-faq-contact">
          <a href="tel:+442071234567">📞 +44 (0)20 7123 4567</a>
          <a href="mailto:hello@maisoncheveuxlondon.com">✉ hello@maisoncheveuxlondon.com</a>
          <a href="#">📍 12 Brompton Road, Knightsbridge SW3 1AA</a>
        </div>
        <a href="#booking" class="hs-btn hs-btn-rose">Book Your Appointment</a>
      </div>
    </div>
  </div>
</section>

<!-- BOOKING FORM -->
<section class="hs-booking hs-section" id="booking">
  <div class="hs-container">
    <div class="hs-section-header">
      <span class="hs-tag">Book Now</span>
      <h2 class="hs-heading">Reserve Your <em>Appointment</em></h2>
      <p class="hs-lead" style="margin-top:14px;">Complete the form below and our team will confirm your appointment within a few hours. Alternatively call us direct on +44 (0)20 7123 4567.</p>
    </div>
    <div class="hs-form-wrapper">
      <div class="hs-form-success" id="hs-success">
        <h3>Appointment Request Received</h3>
        <p>We will confirm your booking within a few hours. We look forward to seeing you.</p>
      </div>
      <form id="hs-booking-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <?php wp_nonce_field('tf_hs_booking','tf_hs_nonce'); ?>
        <input type="hidden" name="action" value="tf_hs_booking">
        <div class="hs-form-grid">
          <div class="hs-form-group">
            <label for="hs-name">Your Name *</label>
            <input type="text" id="hs-name" name="hs_name" placeholder="Isabelle Moreau" required>
          </div>
          <div class="hs-form-group">
            <label for="hs-email">Email Address *</label>
            <input type="email" id="hs-email" name="hs_email" placeholder="isabelle@email.com" required>
          </div>
          <div class="hs-form-group">
            <label for="hs-phone">Phone Number *</label>
            <input type="tel" id="hs-phone" name="hs_phone" placeholder="+44 (0)7700 000 000" required>
          </div>
          <div class="hs-form-group">
            <label for="hs-preferred-date">Preferred Date</label>
            <input type="date" id="hs-preferred-date" name="hs_date">
          </div>
          <div class="hs-form-group">
            <label for="hs-service">Service Required *</label>
            <select id="hs-service" name="hs_service" required>
              <option value="">Select service</option>
              <option value="cut">Cut & Blow-dry</option>
              <option value="colour">Colour (Root / Full / Toner)</option>
              <option value="highlights">Highlights / Lowlights</option>
              <option value="balayage">Balayage / Ombré</option>
              <option value="keratin">Keratin Smoothing</option>
              <option value="treatment">Bond / Repair Treatment</option>
              <option value="bridal">Bridal / Occasion</option>
              <option value="consultation">Consultation Only</option>
            </select>
          </div>
          <div class="hs-form-group">
            <label for="hs-stylist">Preferred Stylist</label>
            <select id="hs-stylist" name="hs_stylist">
              <option value="">No preference</option>
              <option value="isabelle">Isabelle Moreau — Creative Director</option>
              <option value="chloe">Chloe Nakamura — Senior Colourist</option>
              <option value="oliver">Oliver Walsh — Senior Stylist</option>
              <option value="amara">Amara Osei — Colour Specialist</option>
            </select>
          </div>
          <div class="hs-form-group full">
            <label for="hs-notes">Anything Else We Should Know?</label>
            <textarea id="hs-notes" name="hs_notes" placeholder="Hair history, current condition, allergies, reference images, anything that will help us prepare for your visit…"></textarea>
          </div>
        </div>
        <div class="hs-form-actions">
          <button type="submit" class="hs-btn hs-btn-rose">Request Appointment</button>
          <p class="hs-form-note">We'll confirm within a few hours. We have a 48-hour cancellation policy.</p>
        </div>
      </form>
    </div>
  </div>
</section>

<!-- FOOTER -->
<footer class="hs-footer">
  <div class="hs-container">
    <div class="hs-footer-inner">
      <div class="hs-footer-brand">
        <h3>Maison Cheveux</h3>
        <span>Luxury Hair Studio · Est. 2001</span>
        <p>Award-winning hairdressing and colour studio in the heart of Knightsbridge. Bespoke cuts, transformative colour, and immersive hair care experiences.</p>
      </div>
      <div class="hs-footer-col">
        <h4>Services</h4>
        <ul>
          <li><a href="#">Cut & Finish</a></li>
          <li><a href="#">Balayage & Ombré</a></li>
          <li><a href="#">Colour & Highlights</a></li>
          <li><a href="#">Keratin Treatments</a></li>
          <li><a href="#">Bridal & Occasion</a></li>
        </ul>
      </div>
      <div class="hs-footer-col">
        <h4>Visit Us</h4>
        <ul>
          <li><a href="tel:+442071234567">+44 (0)20 7123 4567</a></li>
          <li><a href="mailto:hello@maisoncheveuxlondon.com">hello@maisoncheveux.com</a></li>
          <li><a href="#">12 Brompton Road</a></li>
          <li><a href="#">Knightsbridge, SW3 1AA</a></li>
        </ul>
      </div>
    </div>
    <div class="hs-footer-bottom">
      <p>© <?php echo date('Y'); ?> Maison Cheveux Ltd. All rights reserved.</p>
      <a href="#">Privacy Policy</a>
    </div>
  </div>
</footer>

<script>
(function(){
  // ---- FAQ ----
  document.querySelectorAll('.hs-faq-q').forEach(function(btn){
    btn.addEventListener('click',function(){
      var item=this.closest('.hs-faq-item'),open=item.classList.contains('open');
      document.querySelectorAll('.hs-faq-item.open').forEach(function(o){
        o.classList.remove('open');
        o.querySelector('.hs-faq-q').setAttribute('aria-expanded','false');
      });
      if(!open){item.classList.add('open');this.setAttribute('aria-expanded','true');}
    });
    btn.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();this.click();}});
  });

  // ---- Animated counters ----
  var easeOut=function(t){return 1-Math.pow(1-t,3);};
  var obs=new IntersectionObserver(function(entries){
    entries.forEach(function(entry){
      if(!entry.isIntersecting)return;
      var el=entry.target;
      var raw=el.getAttribute('data-target')||'';
      var num=parseFloat(raw.replace(/[^0-9.]/g,''));
      if(isNaN(num)){obs.unobserve(el);return;}
      var isFloat=raw.indexOf('.')!==-1;
      var dur=1400,start=null;
      function tick(now){
        if(!start)start=now;
        var p=Math.min((now-start)/dur,1);
        var v=easeOut(p)*num;
        var suffix=raw.replace(/^[£$€]?[0-9.,]+/,'');
        var prefix=raw.match(/^[£$€]/)?raw[0]:'';
        el.textContent=prefix+(isFloat?v.toFixed(1):Math.floor(v).toLocaleString())+suffix;
        if(p<1)requestAnimationFrame(tick);
        else el.textContent=raw;
      }
      requestAnimationFrame(tick);
      obs.unobserve(el);
    });
  },{threshold:.4});
  document.querySelectorAll('.hs-stat-number').forEach(function(c){obs.observe(c);});

  // ---- Form ----
  var form=document.getElementById('hs-booking-form');
  var succ=document.getElementById('hs-success');
  if(form){form.addEventListener('submit',function(e){e.preventDefault();form.style.display='none';succ.style.display='block';});}
})();
</script>
</body>
</html>
</div><!-- .page-template-page-hairdresser -->
<?php get_footer(); ?>
