<?php
/**
 * Template Name: Boutique Hotel
 *
 * Premium homepage for a boutique / luxury independent hotel.
 * Namespace : --htl-*
 * Fonts     : Libre Baskerville + Jost
 * Palette   : midnight #0d1117, bronze #8c6a3a, warm #c8a870, ivory #f8f4ec, forest #1e3a2a
 *
 * @package ThemeFlex
 */

get_header();

/* ── Deterministic randomness ────────────────────────────── */
srand( crc32( get_the_permalink() ) );

/* ── Hotel data ──────────────────────────────────────────── */
$hotel_name  = 'The Ashford House';
$hotel_sub   = 'A Country House Hotel & Spa';
$phone       = '01608 643 200';
$email       = 'reservations@ashfordhouse.co.uk';
$address     = 'Ashford Lane, Chipping Campden, Gloucestershire GL55 6AN';
$founded     = 1892;

$stats = [
    [ 'value' => '32',   'label' => 'Rooms & Suites',      'suffix' => '' ],
    [ 'value' => '4.9',  'label' => 'TripAdvisor Rating',  'suffix' => '★' ],
    [ 'value' => '132',  'label' => 'Years of Hospitality','suffix' => '' ],
    [ 'value' => '18',   'label' => 'Acres of Grounds',    'suffix' => '' ],
];

$rooms = [
    [
        'name'    => 'Classic Room',
        'size'    => '28m²',
        'from'    => 195,
        'desc'    => 'Beautifully appointed with hand-stitched linens, original artwork and views over the walled kitchen garden.',
        'features'=> ['Super-king bed', 'Rainfall shower', 'Nespresso machine', 'Heated floors'],
        'col'     => '#1e3a2a',
    ],
    [
        'name'    => 'Deluxe Garden Room',
        'size'    => '36m²',
        'from'    => 265,
        'desc'    => 'Ground-floor rooms with private terraces opening directly onto the rose garden — perfect for long summer evenings.',
        'features'=> ['Private terrace', 'Freestanding bath', 'Garden views', 'Pillow menu'],
        'col'     => '#3a2a1a',
    ],
    [
        'name'    => 'Junior Suite',
        'size'    => '52m²',
        'from'    => 395,
        'desc'    => 'A separate sitting room, antique writing desk and a deep copper bath — understated luxury in the heart of the Cotswolds.',
        'features'=> ['Separate lounge', 'Copper bath & shower', 'Whisky decanter', 'Turndown service'],
        'col'     => '#2a1e3a',
    ],
    [
        'name'    => 'The Ashford Suite',
        'size'    => '88m²',
        'from'    => 695,
        'desc'    => 'Our grandest suite — two rooms, a private dining table, butler service and a rooftop terrace with panoramic views of the valley.',
        'features'=> ['Private rooftop terrace', 'Butler service', 'Bang & Olufsen system', 'In-suite dining'],
        'col'     => '#1a2a3a',
        'featured'=> true,
    ],
];

$amenities = [
    [ 'icon' => '♨', 'name' => 'Spa & Wellness', 'desc' => '18-treatment-room spa, indoor pool, hot tub and steam room — open daily 7am–9pm.' ],
    [ 'icon' => '🍽', 'name' => 'The Oak Room',   'desc' => 'AA Two Rosette restaurant serving modern British cuisine with produce from our kitchen garden.' ],
    [ 'icon' => '🍸', 'name' => 'Campden Bar',    'desc' => 'An intimate bar with 140 whiskies, local craft ales and cocktails crafted by our bar team.' ],
    [ 'icon' => '🎾', 'name' => 'Tennis & Croquet','desc' => 'All-weather tennis court and a manicured croquet lawn set within our 18 acres of grounds.' ],
    [ 'icon' => '🚴', 'name' => 'Cycling & Walks','desc' => 'Complimentary e-bikes, curated walking maps and a picnic hamper service for exploring the Cotswolds.' ],
    [ 'icon' => '🎪', 'name' => 'Events & Weddings','desc' => 'Licensed for civil ceremonies with spaces for up to 120 guests indoors and 200 in the grounds.' ],
];

$team = [
    [ 'name' => 'Jonathan Ashford',  'role' => 'General Manager',           'years' => 18, 'desc' => 'Third-generation custodian of the house, Jonathan brings warmth, deep knowledge and genuine passion to every guest\'s stay.' ],
    [ 'name' => 'Chef Léa Moreau',   'role' => 'Head Chef, The Oak Room',   'years' => 8,  'desc' => 'Trained under a two-Michelin-star kitchen in Lyon, Léa\'s menus celebrate the finest seasonal produce from the Ashford kitchen garden.' ],
    [ 'name' => 'Sophie Clarke',     'role' => 'Spa Director',              'years' => 11, 'desc' => 'Sophie has transformed the Ashford Spa into one of the Cotswolds\' most sought-after wellbeing destinations.' ],
];

$testimonials = [
    [
        'name'  => 'Mr & Mrs Pemberton',
        'source'=> 'Anniversary Stay',
        'quote' => 'Every detail was considered. From the champagne on arrival to the extraordinary breakfast, we felt genuinely cared for. The Junior Suite was exquisite. We will return every year.',
        'stars' => 5,
    ],
    [
        'name'  => 'Fiona H.',
        'source'=> 'Solo Weekend',
        'quote' => 'The spa is genuinely world-class and the grounds are breathtaking. I walked six miles each morning and returned to the most perfect dinner. Restorative is the only word for it.',
        'stars' => 5,
    ],
    [
        'name'  => 'The Whitfield Wedding Party',
        'source'=> 'Country House Wedding',
        'quote' => 'Jonathan and his team were brilliant from the very first site visit. Everything ran flawlessly. Our guests are still telling us it was the most beautiful wedding they\'ve attended.',
        'stars' => 5,
    ],
];

$faqs = [
    [ 'q' => 'What is the check-in and check-out time?',
      'a' => 'Check-in is from 3pm. Early check-in from 1pm can be arranged subject to availability — please call us in advance. Check-out is by 11am. Late check-out until 1pm is complimentary when available; please ask at reception on the morning of departure.' ],
    [ 'q' => 'Do you allow dogs?',
      'a' => 'We are delighted to welcome well-behaved dogs in our dog-friendly rooms and throughout the grounds. There is a £25 per night dog supplement. Bedding, bowls and treats are provided. Dogs are not permitted in the restaurant but may join you in the bar.' ],
    [ 'q' => 'Is the spa included in the room rate?',
      'a' => 'All guests have complimentary use of the indoor pool, hot tub, steam room and gym. Spa treatments are charged additionally and can be booked in advance through the spa team. We recommend booking treatments at least two weeks ahead during peak season.' ],
    [ 'q' => 'How far are you from the nearest railway station?',
      'a' => 'Moreton-in-Marsh station (London Paddington line) is 7 miles away. We offer a complimentary transfer service from the station with 24 hours\' notice — please call to arrange. Taxis are also readily available from the station rank.' ],
    [ 'q' => 'Can you arrange special occasions?',
      'a' => 'Absolutely. We specialise in anniversary surprises, proposals, birthday celebrations and private dining. Please contact our reservations team in advance and we will make every arrangement — from rose-petal turndown to in-room dining and bespoke gifts.' ],
];

/* ── PHP hero decoration counts ─────────────────────────── */
$n_stars  = 40;
$n_lights = 12;
?>
<!– page-hotel –>
<style>
/* ═══════════════════════════════════════════════════════════
   HOTEL — CSS CUSTOM PROPERTIES
═══════════════════════════════════════════════════════════ */
:root {
    --htl-midnight: #0d1117;
    --htl-dark:     #141c22;
    --htl-forest:   #1e3a2a;
    --htl-bronze:   #8c6a3a;
    --htl-warm:     #c8a870;
    --htl-gold:     #d4b860;
    --htl-gold-lt:  #e8cc80;
    --htl-ivory:    #f8f4ec;
    --htl-cream:    #fdfaf5;
    --htl-white:    #ffffff;
    --htl-text:     #2a2010;
    --htl-muted:    #7a6a50;
    --htl-border:   #e4d8c0;
    --htl-shadow:   0 4px 24px rgba(13,17,23,.14);
    --htl-shadow-lg:0 16px 56px rgba(13,17,23,.22);
    --htl-r:        4px;
    --htl-r-lg:     8px;
    --htl-trans:    all .35s ease;
    --htl-font-head:'Libre Baskerville', Georgia, 'Times New Roman', serif;
    --htl-font-body:'Jost', system-ui, sans-serif;
}

/* ── Reset / Base ──────────────────────────────────────── */
.htl-page *, .htl-page *::before, .htl-page *::after { box-sizing: border-box; margin: 0; padding: 0; }
.htl-page { font-family: var(--htl-font-body); color: var(--htl-text); background: var(--htl-cream); line-height: 1.65; }
.htl-wrap { max-width: 1200px; margin: 0 auto; padding: 0 24px; }
.htl-section { padding: 96px 0; }
.htl-section-alt { background: var(--htl-ivory); }
.htl-section-dark { background: var(--htl-midnight); color: var(--htl-white); }
.htl-section-forest { background: var(--htl-forest); color: var(--htl-white); }
.htl-kicker { display: inline-block; font-family: var(--htl-font-body); font-size: .7rem; font-weight: 500; letter-spacing: .3em; text-transform: uppercase; color: var(--htl-bronze); margin-bottom: 14px; }
.htl-section-dark .htl-kicker, .htl-section-forest .htl-kicker { color: var(--htl-gold-lt); }
.htl-h2 { font-family: var(--htl-font-head); font-size: clamp(1.8rem, 4vw, 2.8rem); font-weight: 700; line-height: 1.25; color: var(--htl-midnight); margin-bottom: 16px; }
.htl-section-dark .htl-h2, .htl-section-forest .htl-h2 { color: var(--htl-white); }
.htl-rule { display: flex; align-items: center; gap: 12px; margin-bottom: 28px; }
.htl-rule-line { height: 1px; background: var(--htl-warm); flex: 0 0 40px; }
.htl-rule-diamond { width: 8px; height: 8px; background: var(--htl-warm); transform: rotate(45deg); }
.htl-lead { font-size: 1.05rem; color: var(--htl-muted); max-width: 600px; line-height: 1.75; }
.htl-section-dark .htl-lead, .htl-section-forest .htl-lead { color: rgba(255,255,255,.7); }
.htl-center { text-align: center; }
.htl-center .htl-rule { justify-content: center; }
.htl-center .htl-lead { margin: 0 auto; }
.htl-btn { display: inline-flex; align-items: center; gap: 8px; padding: 14px 36px; border-radius: var(--htl-r); font-family: var(--htl-font-body); font-size: .88rem; font-weight: 500; letter-spacing: .08em; text-transform: uppercase; text-decoration: none; cursor: pointer; border: none; transition: var(--htl-trans); }
.htl-btn-gold { background: var(--htl-warm); color: var(--htl-midnight); }
.htl-btn-gold:hover { background: var(--htl-gold); transform: translateY(-2px); box-shadow: 0 6px 20px rgba(200,168,112,.35); }
.htl-btn-outline { background: transparent; border: 1px solid var(--htl-warm); color: var(--htl-warm); }
.htl-btn-outline:hover { background: var(--htl-warm); color: var(--htl-midnight); }
.htl-btn-dark { background: var(--htl-midnight); color: var(--htl-white); }
.htl-btn-dark:hover { background: var(--htl-dark); transform: translateY(-2px); }
.htl-btn-white { background: var(--htl-white); color: var(--htl-midnight); }
.htl-btn-white:hover { background: var(--htl-ivory); transform: translateY(-2px); }

@import url('https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&family=Jost:wght@300;400;500;600&display=swap');

/* ═══════════════════════════════════════════════════════════
   NAV
═══════════════════════════════════════════════════════════ */
.htl-nav { position: sticky; top: 0; z-index: 999; background: var(--htl-midnight); border-bottom: 1px solid rgba(200,168,112,.2); }
.htl-nav-inner { display: flex; align-items: center; justify-content: space-between; height: 72px; gap: 24px; }
.htl-nav-logo { display: flex; flex-direction: column; align-items: center; text-decoration: none; }
.htl-nav-logo-name { font-family: var(--htl-font-head); font-size: 1.1rem; font-weight: 700; color: var(--htl-white); letter-spacing: .06em; }
.htl-nav-logo-sub { font-size: .6rem; letter-spacing: .22em; text-transform: uppercase; color: var(--htl-warm); margin-top: 2px; }
.htl-nav-links { display: flex; gap: 32px; list-style: none; }
.htl-nav-links a { font-size: .78rem; font-weight: 500; letter-spacing: .12em; text-transform: uppercase; color: rgba(255,255,255,.7); text-decoration: none; transition: color .2s; }
.htl-nav-links a:hover { color: var(--htl-gold-lt); }
.htl-nav-cta { display: flex; gap: 12px; align-items: center; }
.htl-nav-phone { color: var(--htl-warm); font-size: .82rem; font-weight: 500; text-decoration: none; letter-spacing: .04em; }
.htl-nav-phone:hover { color: var(--htl-gold-lt); }

/* ═══════════════════════════════════════════════════════════
   HERO — CSS COUNTRY HOUSE FACADE AT DUSK
═══════════════════════════════════════════════════════════ */
.htl-hero { position: relative; min-height: 680px; background: linear-gradient(180deg, #06080e 0%, #0d1a28 30%, #0d2010 60%, #081408 100%); display: flex; align-items: center; overflow: hidden; }
.htl-hero-scene { position: absolute; inset: 0; overflow: hidden; }

/* Sky gradient */
.htl-sky { position: absolute; inset: 0; background: linear-gradient(180deg, #02050a 0%, #060e1e 25%, #0a1830 50%, #0e2018 70%, #0a1810 85%, #060e08 100%); }
/* Moon */
.htl-moon { position: absolute; top: 6%; right: 18%; width: 44px; height: 44px; border-radius: 50%; background: radial-gradient(circle at 40% 35%, #f8f4e0 0%, #d8c8a0 60%, #c0b080 100%); box-shadow: 0 0 20px rgba(248,244,224,.5), 0 0 60px rgba(248,244,224,.15); }
.htl-moon::before { content: ''; position: absolute; top: 6px; left: 12px; width: 16px; height: 16px; border-radius: 50%; background: rgba(180,160,120,.3); }
/* Stars */
.htl-star { position: absolute; border-radius: 50%; background: rgba(255,255,240,.9); animation: htl-star-twinkle ease-in-out infinite; }
@keyframes htl-star-twinkle { 0%,100%{opacity:.3;} 50%{opacity:1;} }

/* Ground / lawn */
.htl-lawn { position: absolute; bottom: 0; left: 0; right: 0; height: 28%; background: linear-gradient(180deg, #0a1808 0%, #060e06 100%); }
.htl-lawn::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 2px; background: rgba(90,120,60,.3); box-shadow: 0 0 8px rgba(90,120,60,.2); }
/* Gravel drive */
.htl-drive { position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); width: 160px; height: 28%; background: linear-gradient(180deg, #2a2218 0%, #1a1610 100%); clip-path: polygon(15% 0, 85% 0, 100% 100%, 0 100%); }

/* Hedgerow */
.htl-hedge { position: absolute; bottom: 28%; height: 30px; background: repeating-linear-gradient(90deg, #1a3010 0px, #2a4a1a 4px, #1a3010 8px); border-radius: 4px 4px 0 0; }
.htl-hedge-l { left: 0; right: 60%; }
.htl-hedge-r { left: 60%; right: 0; }

/* House facade */
.htl-house { position: absolute; bottom: 28%; left: 50%; transform: translateX(-50%); width: 500px; }
/* Roof */
.htl-roof { width: 500px; height: 80px; background: linear-gradient(180deg, #1a1410 0%, #0e0e0a 100%); clip-path: polygon(0 100%, 10% 0, 90% 0, 100% 100%); position: relative; }
.htl-chimney { position: absolute; background: linear-gradient(180deg, #1e1a14 0%, #140e08 100%); border-radius: 2px; }
.htl-chimney-1 { width: 22px; height: 50px; top: -50px; left: 22%; }
.htl-chimney-2 { width: 18px; height: 40px; top: -40px; left: 72%; }
.htl-chimney-top { position: absolute; top: 0; left: -4px; right: -4px; height: 6px; background: #2a2218; }
.htl-chimney-smoke { position: absolute; top: -20px; left: 50%; transform: translateX(-50%); width: 8px; height: 20px; background: linear-gradient(180deg, rgba(180,180,160,.0) 0%, rgba(180,180,160,.12) 50%, rgba(180,180,160,.0) 100%); border-radius: 50%; animation: htl-smoke 4s ease-in-out infinite; }
@keyframes htl-smoke { 0% { transform: translateX(-50%) scaleX(1); opacity: 0; } 30% { opacity: 1; } 100% { transform: translateX(calc(-50% + 12px)) scaleX(2) translateY(-30px); opacity: 0; } }
/* Main wall */
.htl-wall { width: 500px; height: 200px; background: linear-gradient(180deg, #2a2218 0%, #1e1810 100%); position: relative; }
.htl-wall-stone { position: absolute; inset: 0; background: repeating-linear-gradient(90deg, rgba(255,255,255,.015) 0, rgba(255,255,255,.015) 1px, transparent 1px, transparent 60px), repeating-linear-gradient(0deg, rgba(255,255,255,.02) 0, rgba(255,255,255,.02) 1px, transparent 1px, transparent 30px); }
/* Windows — lit amber */
.htl-window-lit { position: absolute; background: linear-gradient(160deg, #c8a040 0%, #f0c860 30%, #e8b840 70%, #a07830 100%); border: 3px solid #2a2010; box-shadow: 0 0 16px rgba(200,160,60,.6), 0 0 40px rgba(200,160,60,.2); }
.htl-window-lit::before { content: ''; position: absolute; top: 0; left: 50%; transform: translateX(-50%); width: 3px; height: 100%; background: rgba(0,0,0,.25); }
.htl-window-lit::after  { content: ''; position: absolute; top: 50%; left: 0; right: 0; height: 3px; background: rgba(0,0,0,.25); }
/* Small round window in roof */
.htl-window-round { width: 30px; height: 30px; border-radius: 50%; }
/* Ground floor windows */
.htl-window-tall { width: 44px; height: 70px; border-radius: 2px 2px 0 0; }
.htl-window-arch { border-radius: 50% 50% 0 0 / 30% 30% 0 0; }
/* Main entrance door */
.htl-door { position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); width: 60px; height: 110px; background: linear-gradient(180deg, #8c6a2a 0%, #5a4018 100%); border-radius: 4px 4px 0 0; border: 4px solid #2a1a08; }
.htl-door::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 50%; border-radius: 50% 50% 0 0 / 30% 30% 0 0; background: radial-gradient(ellipse at 50% 80%, rgba(200,160,60,.5) 0%, transparent 70%); border-bottom: 2px solid #5a3a10; }
.htl-door-handle { position: absolute; right: 8px; top: 60%; width: 6px; height: 6px; border-radius: 50%; background: #d4b060; box-shadow: 0 0 4px rgba(212,176,96,.8); }
.htl-door-light { position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); width: 100px; height: 50px; background: radial-gradient(ellipse at 50% 0%, rgba(200,160,60,.35) 0%, transparent 70%); }
/* Porch columns */
.htl-column { position: absolute; bottom: 0; width: 14px; background: linear-gradient(90deg, #2a2218 0%, #3a3228 40%, #2a2218 100%); border-radius: 2px 2px 0 0; }
.htl-column::before { content: ''; position: absolute; top: 0; left: -4px; right: -4px; height: 8px; background: linear-gradient(90deg, #3a3228 0%, #4a4238 50%, #3a3228 100%); border-radius: 2px; }
.htl-column::after  { content: ''; position: absolute; bottom: 0; left: -4px; right: -4px; height: 8px; background: #3a3228; }
/* Steps */
.htl-step { position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); height: 10px; background: linear-gradient(180deg, #3a3228 0%, #2a2218 100%); border-radius: 2px 2px 0 0; }
.htl-step-1 { width: 120px; bottom: 0; }
.htl-step-2 { width: 100px; bottom: 10px; }
.htl-step-3 { width: 80px; bottom: 20px; }
/* Lanterns flanking door */
.htl-lantern { position: absolute; bottom: 100px; width: 14px; height: 22px; background: transparent; border: 2px solid #8c6a2a; border-radius: 2px; }
.htl-lantern::before { content: ''; position: absolute; top: -6px; left: 50%; transform: translateX(-50%); width: 2px; height: 6px; background: #8c6a2a; }
.htl-lantern::after  { content: ''; position: absolute; inset: 2px; background: radial-gradient(ellipse, rgba(200,160,60,.8) 0%, rgba(200,120,20,.5) 100%); border-radius: 1px; box-shadow: 0 0 10px rgba(200,160,60,.7); }
.htl-lantern.left  { left: calc(50% - 60px); }
.htl-lantern.right { right: calc(50% - 60px); }
/* Trees flanking house */
.htl-tree { position: absolute; bottom: 28%; }
.htl-tree-trunk { width: 12px; margin: 0 auto; border-radius: 2px; background: linear-gradient(90deg, #2a1a0a 0%, #3a2a1a 50%, #2a1a0a 100%); }
.htl-tree-canopy { border-radius: 50% 50% 40% 40%; position: relative; margin: 0 auto; }
.htl-tree-canopy::before { content: ''; position: absolute; bottom: -14px; left: 50%; transform: translateX(-50%); border-radius: 50% 50% 40% 40%; background: inherit; filter: brightness(.85); }
/* Topiary balls */
.htl-topiary { position: absolute; bottom: 28%; }
.htl-topiary-ball { border-radius: 50%; background: radial-gradient(circle at 35% 30%, #3a5a2a 0%, #1a3a12 60%, #0e2808 100%); }
.htl-topiary-trunk { width: 6px; height: 20px; background: #2a1a0a; margin: 0 auto; }

/* Ivy on walls */
.htl-ivy-patch { position: absolute; opacity: .5; }

/* Hero content overlay */
.htl-hero-content { position: relative; z-index: 10; max-width: 580px; padding: 80px 0; }
.htl-hero-est { font-size: .7rem; letter-spacing: .28em; text-transform: uppercase; color: var(--htl-warm); margin-bottom: 16px; }
.htl-hero-h1 { font-family: var(--htl-font-head); font-size: clamp(2.2rem, 5vw, 3.8rem); font-weight: 700; color: var(--htl-white); line-height: 1.15; margin-bottom: 10px; }
.htl-hero-h1 em { font-style: italic; color: var(--htl-gold-lt); }
.htl-hero-sub { font-family: var(--htl-font-head); font-size: 1rem; color: var(--htl-warm); font-style: italic; margin-bottom: 22px; letter-spacing: .04em; }
.htl-hero-desc { font-size: 1rem; color: rgba(255,255,255,.72); line-height: 1.8; margin-bottom: 40px; }
.htl-hero-ctas { display: flex; gap: 16px; flex-wrap: wrap; margin-bottom: 48px; }
.htl-hero-awards { display: flex; gap: 16px; flex-wrap: wrap; }
.htl-hero-award { display: flex; align-items: center; gap: 8px; font-size: .76rem; color: rgba(255,255,255,.55); }
.htl-hero-award-badge { width: 28px; height: 28px; border-radius: 50%; border: 1px solid rgba(200,168,112,.4); background: rgba(200,168,112,.08); display: flex; align-items: center; justify-content: center; font-size: .65rem; color: var(--htl-warm); }

/* String lights */
.htl-string-light { position: absolute; }
.htl-bulb { position: absolute; border-radius: 50%; background: radial-gradient(circle, #f8f060 0%, #e8b830 60%, transparent 100%); animation: htl-bulb-glow 2s ease-in-out infinite; }
@keyframes htl-bulb-glow { 0%,100%{opacity:.6;} 50%{opacity:1;} }

/* ═══════════════════════════════════════════════════════════
   STATS BAR
═══════════════════════════════════════════════════════════ */
.htl-stats-bar { background: linear-gradient(90deg, var(--htl-forest) 0%, #162e1e 50%, var(--htl-forest) 100%); padding: 44px 0; border-top: 2px solid var(--htl-warm); }
.htl-stats-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 0; }
.htl-stat { text-align: center; padding: 8px 20px; border-right: 1px solid rgba(200,168,112,.2); }
.htl-stat:last-child { border-right: none; }
.htl-stat-value { font-family: var(--htl-font-head); font-size: 2.4rem; font-weight: 700; color: var(--htl-white); line-height: 1; }
.htl-stat-suffix { font-size: 1.4rem; color: var(--htl-gold-lt); }
.htl-stat-label { font-size: .72rem; letter-spacing: .14em; text-transform: uppercase; color: rgba(255,255,255,.5); margin-top: 6px; }

/* ═══════════════════════════════════════════════════════════
   ROOMS
═══════════════════════════════════════════════════════════ */
.htl-rooms-grid { display: grid; grid-template-columns: repeat(2,1fr); gap: 24px; margin-top: 48px; }
.htl-room-card { background: var(--htl-cream); border: 1px solid var(--htl-border); border-radius: var(--htl-r-lg); overflow: hidden; transition: var(--htl-trans); }
.htl-room-card:hover { transform: translateY(-4px); box-shadow: var(--htl-shadow-lg); }
.htl-room-card.featured { border-color: var(--htl-warm); }
.htl-room-card.featured .htl-room-header { border-top: 3px solid var(--htl-warm); }
.htl-room-visual { height: 160px; position: relative; overflow: hidden; display: flex; align-items: flex-end; justify-content: center; padding: 16px; }
.htl-room-badge { position: absolute; top: 12px; right: 12px; background: var(--htl-warm); color: var(--htl-midnight); font-size: .68rem; font-weight: 600; letter-spacing: .1em; text-transform: uppercase; padding: 4px 12px; border-radius: 2px; }
/* CSS room interior sketch */
.htl-room-sketch { width: 100%; height: 100%; position: relative; }
.htl-sketch-wall { position: absolute; inset: 0; border-radius: 2px; }
.htl-sketch-floor { position: absolute; bottom: 0; left: 0; right: 0; height: 35%; }
.htl-sketch-bed { position: absolute; bottom: 35%; left: 50%; transform: translateX(-50%); width: 80px; height: 44px; border-radius: 4px 4px 0 0; }
.htl-sketch-headboard { position: absolute; bottom: calc(35% + 44px); left: 50%; transform: translateX(-50%); width: 80px; height: 18px; border-radius: 4px 4px 0 0; }
.htl-sketch-pillow { position: absolute; top: 0; width: 32px; height: 14px; border-radius: 3px; background: rgba(255,255,255,.8); }
.htl-sketch-pillow.l { left: 4px; }
.htl-sketch-pillow.r { right: 4px; }
.htl-sketch-window { position: absolute; top: 12px; right: 16px; width: 32px; height: 40px; background: rgba(255,255,255,.15); border: 2px solid rgba(255,255,255,.3); border-radius: 2px 2px 0 0; }
.htl-sketch-lamp { position: absolute; bottom: 35%; left: 16px; width: 16px; height: 30px; }
.htl-sketch-lamp-shade { width: 24px; height: 14px; border-radius: 0 0 12px 12px; background: rgba(200,160,60,.5); margin-left: -4px; }
.htl-sketch-lamp-pole { width: 3px; height: 18px; background: rgba(160,120,60,.5); margin: 0 auto; }
.htl-room-header { padding: 20px 24px 0; }
.htl-room-name { font-family: var(--htl-font-head); font-size: 1.15rem; font-weight: 700; color: var(--htl-midnight); margin-bottom: 4px; }
.htl-room-size { font-size: .78rem; color: var(--htl-muted); letter-spacing: .08em; }
.htl-room-body { padding: 12px 24px 20px; }
.htl-room-desc { font-size: .88rem; color: var(--htl-muted); line-height: 1.65; margin-bottom: 14px; }
.htl-room-features { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 16px; }
.htl-room-feature { display: inline-flex; align-items: center; gap: 5px; font-size: .76rem; color: var(--htl-text); background: var(--htl-ivory); border: 1px solid var(--htl-border); padding: 3px 10px; border-radius: 2px; }
.htl-room-feature::before { content: '✓'; color: var(--htl-bronze); font-size: .65rem; }
.htl-room-price { display: flex; align-items: baseline; gap: 4px; }
.htl-room-from { font-size: .75rem; color: var(--htl-muted); }
.htl-room-amount { font-family: var(--htl-font-head); font-size: 1.5rem; font-weight: 700; color: var(--htl-midnight); }
.htl-room-per { font-size: .78rem; color: var(--htl-muted); }

/* ═══════════════════════════════════════════════════════════
   AMENITIES
═══════════════════════════════════════════════════════════ */
.htl-amenities-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; margin-top: 48px; }
.htl-amenity-card { display: flex; gap: 20px; align-items: flex-start; padding: 28px 24px; background: rgba(255,255,255,.06); border: 1px solid rgba(200,168,112,.15); border-radius: var(--htl-r-lg); transition: var(--htl-trans); }
.htl-amenity-card:hover { background: rgba(255,255,255,.09); border-color: rgba(200,168,112,.3); }
.htl-amenity-icon { flex-shrink: 0; width: 52px; height: 52px; border-radius: var(--htl-r); background: rgba(200,168,112,.12); border: 1px solid rgba(200,168,112,.2); display: flex; align-items: center; justify-content: center; font-size: 1.4rem; }
.htl-amenity-name { font-family: var(--htl-font-head); font-size: 1rem; font-weight: 700; color: var(--htl-white); margin-bottom: 6px; }
.htl-amenity-desc { font-size: .85rem; color: rgba(255,255,255,.6); line-height: 1.6; }

/* ═══════════════════════════════════════════════════════════
   DINING FEATURE
═══════════════════════════════════════════════════════════ */
.htl-dining-split { display: grid; grid-template-columns: 1fr 1fr; gap: 64px; align-items: center; }
.htl-dining-visual { height: 420px; position: relative; border-radius: var(--htl-r-lg); overflow: hidden; }
.htl-dining-bg { position: absolute; inset: 0; background: linear-gradient(160deg, #1a1208 0%, #2a1e10 100%); }
/* CSS table setting */
.htl-table { position: absolute; bottom: 15%; left: 50%; transform: translateX(-50%); }
.htl-table-top { width: 220px; height: 10px; background: linear-gradient(180deg, #5c3a1e 0%, #3d2510 100%); border-radius: 3px; box-shadow: 0 4px 16px rgba(0,0,0,.5); }
.htl-table-leg { position: absolute; top: 10px; width: 8px; background: #3d2510; border-radius: 0 0 2px 2px; }
.htl-table-leg.l { left: 20px; height: 80px; }
.htl-table-leg.r { right: 20px; height: 80px; }
/* Place settings */
.htl-place-setting { position: absolute; bottom: calc(15% + 10px); }
.htl-plate { border-radius: 50%; border: 2px solid rgba(255,255,255,.3); }
.htl-plate::before { content: ''; position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); border-radius: 50%; background: rgba(255,255,255,.06); }
.htl-glass { border-radius: 0 0 4px 4px; border: 1px solid rgba(200,220,255,.3); }
.htl-glass::before { content: ''; position: absolute; top: -14px; left: 50%; transform: translateX(-50%); width: 16px; height: 16px; border-radius: 50%; border: 1px solid rgba(200,220,255,.3); background: rgba(120,160,255,.08); }
.htl-cutlery { position: absolute; width: 2px; border-radius: 1px; background: rgba(200,180,140,.5); }
/* Candelabra centre */
.htl-candelabra { position: absolute; bottom: calc(15% + 10px); left: 50%; transform: translateX(-50%); }
.htl-cand-base { width: 30px; height: 6px; background: linear-gradient(90deg, #8a7040 0%, #b09a50 50%, #8a7040 100%); border-radius: 3px; margin: 0 auto; }
.htl-cand-stem { width: 4px; height: 50px; background: linear-gradient(90deg, #8a7040 0%, #b09a50 50%, #8a7040 100%); margin: 0 auto; }
.htl-cand-arm { position: absolute; height: 3px; background: linear-gradient(90deg, #8a7040, #b09a50); top: 20px; }
.htl-cand-arm.l { width: 28px; left: -28px; transform-origin: right; transform: rotate(-15deg); }
.htl-cand-arm.r { width: 28px; right: -28px; transform-origin: left; transform: rotate(15deg); }
.htl-cand-candle { position: absolute; width: 6px; height: 28px; background: #f8e8d0; border-radius: 2px; }
.htl-cand-flame { position: absolute; top: -10px; left: 50%; transform: translateX(-50%); width: 6px; height: 10px; background: radial-gradient(ellipse at 50% 60%, #f8d050 0%, #f07010 50%, transparent 100%); border-radius: 50%; animation: htl-flame .8s ease-in-out infinite alternate; }
@keyframes htl-flame { from{transform:translateX(-50%) scaleY(1);} to{transform:translateX(-50%) scaleY(1.2) scaleX(.85);} }
/* Oak Room sign */
.htl-oak-sign { position: absolute; top: 16px; left: 50%; transform: translateX(-50%); background: rgba(0,0,0,.6); border: 1px solid rgba(200,168,112,.3); padding: 8px 20px; border-radius: var(--htl-r); text-align: center; }
.htl-oak-sign-title { font-family: var(--htl-font-head); font-size: .85rem; font-style: italic; color: var(--htl-gold-lt); }
.htl-oak-sign-sub { font-size: .62rem; letter-spacing: .2em; text-transform: uppercase; color: rgba(255,255,255,.5); margin-top: 2px; }
/* Dining room window light */
.htl-dining-window-light { position: absolute; top: 0; right: 0; width: 120px; height: 300px; background: linear-gradient(135deg, rgba(200,168,112,.08) 0%, transparent 60%); }

/* ═══════════════════════════════════════════════════════════
   TEAM
═══════════════════════════════════════════════════════════ */
.htl-team-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 32px; margin-top: 48px; }
.htl-team-card { background: var(--htl-cream); border: 1px solid var(--htl-border); border-radius: var(--htl-r-lg); overflow: hidden; transition: var(--htl-trans); }
.htl-team-card:hover { transform: translateY(-4px); box-shadow: var(--htl-shadow-lg); }
.htl-team-avatar { height: 200px; display: flex; align-items: flex-end; justify-content: center; position: relative; overflow: hidden; }
/* CSS hotel staff figure */
.htl-staff-fig { position: relative; width: 80px; z-index: 1; }
.htl-staff-head { width: 44px; height: 44px; border-radius: 50%; margin: 0 auto; }
.htl-staff-jacket { width: 68px; height: 88px; border-radius: 8px 8px 0 0; margin: 0 auto; position: relative; }
.htl-staff-jacket::before { content: ''; position: absolute; top: 0; left: 50%; transform: translateX(-50%); width: 16px; height: 100%; background: rgba(255,255,255,.15); border-radius: 2px; }
.htl-staff-bow-tie { position: absolute; top: 8px; left: 50%; transform: translateX(-50%); width: 18px; height: 8px; }
.htl-staff-bow-tie::before { content: ''; position: absolute; left: 0; top: 0; width: 8px; height: 8px; background: var(--htl-midnight); clip-path: polygon(0 0, 100% 50%, 0 100%); }
.htl-staff-bow-tie::after  { content: ''; position: absolute; right: 0; top: 0; width: 8px; height: 8px; background: var(--htl-midnight); clip-path: polygon(100% 0, 0 50%, 100% 100%); }
.htl-staff-badge { position: absolute; right: 4px; top: 30px; width: 14px; height: 14px; background: var(--htl-warm); border-radius: 2px; }
.htl-team-info { padding: 20px 24px 28px; }
.htl-team-name { font-family: var(--htl-font-head); font-size: 1.05rem; font-weight: 700; color: var(--htl-midnight); margin-bottom: 4px; }
.htl-team-role { font-size: .75rem; font-weight: 500; color: var(--htl-bronze); letter-spacing: .12em; text-transform: uppercase; margin-bottom: 10px; }
.htl-team-years { display: inline-block; background: var(--htl-ivory); border: 1px solid var(--htl-border); color: var(--htl-muted); font-size: .72rem; padding: 2px 10px; border-radius: 2px; margin-bottom: 10px; }
.htl-team-desc { font-size: .84rem; color: var(--htl-muted); line-height: 1.6; }

/* ═══════════════════════════════════════════════════════════
   TESTIMONIALS
═══════════════════════════════════════════════════════════ */
.htl-testimonials-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; margin-top: 48px; }
.htl-testimonial { padding: 32px 28px; background: var(--htl-cream); border: 1px solid var(--htl-border); border-radius: var(--htl-r-lg); position: relative; }
.htl-testimonial::before { content: '\201C'; position: absolute; top: 12px; right: 20px; font-family: var(--htl-font-head); font-size: 5rem; color: rgba(140,106,58,.12); line-height: 1; }
.htl-testimonial-stars { display: flex; gap: 2px; margin-bottom: 14px; }
.htl-testimonial-stars span { color: var(--htl-warm); font-size: .88rem; }
.htl-testimonial-quote { font-size: .88rem; color: var(--htl-muted); line-height: 1.75; font-style: italic; margin-bottom: 20px; }
.htl-testimonial-name { font-family: var(--htl-font-head); font-size: .9rem; font-weight: 700; color: var(--htl-midnight); }
.htl-testimonial-source { font-size: .76rem; color: var(--htl-bronze); margin-top: 2px; }

/* ═══════════════════════════════════════════════════════════
   FAQ
═══════════════════════════════════════════════════════════ */
.htl-faq-list { margin-top: 48px; display: flex; flex-direction: column; gap: 2px; }
.htl-faq-item { background: var(--htl-cream); border: 1px solid var(--htl-border); border-radius: var(--htl-r); overflow: hidden; }
.htl-faq-q { display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 18px 24px; cursor: pointer; font-family: var(--htl-font-head); font-size: .95rem; font-style: italic; font-weight: 400; color: var(--htl-midnight); user-select: none; transition: background .2s; }
.htl-faq-q:hover { background: var(--htl-ivory); }
.htl-faq-q.open { background: var(--htl-forest); color: var(--htl-white); }
.htl-faq-icon { flex-shrink: 0; font-size: 1rem; transition: transform .25s; color: var(--htl-bronze); }
.htl-faq-q.open .htl-faq-icon { transform: rotate(45deg); color: var(--htl-gold-lt); }
.htl-faq-a { max-height: 0; overflow: hidden; transition: max-height .4s ease; }
.htl-faq-a.open { max-height: 300px; }
.htl-faq-a-inner { padding: 16px 24px 20px; font-size: .88rem; color: var(--htl-muted); line-height: 1.7; }

/* ═══════════════════════════════════════════════════════════
   BOOKING FORM
═══════════════════════════════════════════════════════════ */
.htl-booking-split { display: grid; grid-template-columns: 1fr 1.1fr; gap: 64px; align-items: start; }
.htl-booking-info { }
.htl-contact-line { display: flex; gap: 14px; align-items: flex-start; margin-bottom: 20px; }
.htl-contact-line-icon { flex-shrink: 0; width: 40px; height: 40px; border-radius: var(--htl-r); background: rgba(200,168,112,.1); border: 1px solid rgba(200,168,112,.2); display: flex; align-items: center; justify-content: center; }
.htl-contact-line-icon svg { width: 18px; height: 18px; fill: var(--htl-gold-lt); }
.htl-contact-line-label { font-size: .7rem; letter-spacing: .14em; text-transform: uppercase; color: var(--htl-warm); margin-bottom: 3px; }
.htl-contact-line-value { font-size: .9rem; color: var(--htl-white); }
.htl-contact-line-value a { color: var(--htl-white); text-decoration: none; }
.htl-contact-line-value a:hover { color: var(--htl-gold-lt); }
.htl-form-card { background: var(--htl-cream); border-radius: var(--htl-r-lg); padding: 40px; }
.htl-form-title { font-family: var(--htl-font-head); font-size: 1.5rem; font-weight: 700; color: var(--htl-midnight); margin-bottom: 6px; }
.htl-form-sub { font-size: .88rem; color: var(--htl-muted); margin-bottom: 28px; }
.htl-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.htl-form-group { margin-bottom: 16px; }
.htl-form-group label { display: block; font-size: .72rem; font-weight: 500; color: var(--htl-midnight); letter-spacing: .1em; text-transform: uppercase; margin-bottom: 6px; }
.htl-form-group input,
.htl-form-group select,
.htl-form-group textarea { width: 100%; padding: 12px 16px; background: var(--htl-white); border: 1px solid var(--htl-border); border-radius: var(--htl-r); font-family: var(--htl-font-body); font-size: .9rem; color: var(--htl-text); outline: none; transition: border-color .2s; }
.htl-form-group input:focus,
.htl-form-group select:focus,
.htl-form-group textarea:focus { border-color: var(--htl-bronze); }
.htl-form-group textarea { resize: vertical; min-height: 90px; }
.htl-form-note { font-size: .75rem; color: var(--htl-muted); margin-top: 14px; line-height: 1.5; text-align: center; }

/* ═══════════════════════════════════════════════════════════
   FOOTER
═══════════════════════════════════════════════════════════ */
.htl-footer { background: var(--htl-midnight); border-top: 1px solid rgba(200,168,112,.15); padding: 28px 0; }
.htl-footer-inner { display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap; }
.htl-footer-copy { font-size: .78rem; color: rgba(255,255,255,.35); }
.htl-footer-address { font-size: .76rem; color: rgba(255,255,255,.3); margin-top: 3px; }
.htl-footer-links { display: flex; gap: 20px; }
.htl-footer-links a { font-size: .76rem; color: rgba(255,255,255,.35); text-decoration: none; }
.htl-footer-links a:hover { color: var(--htl-gold-lt); }

/* ═══════════════════════════════════════════════════════════
   RESPONSIVE
═══════════════════════════════════════════════════════════ */
@media (max-width: 1024px) {
    .htl-rooms-grid     { grid-template-columns: 1fr; }
    .htl-amenities-grid { grid-template-columns: repeat(2,1fr); }
    .htl-team-grid      { grid-template-columns: repeat(2,1fr); }
    .htl-dining-split   { grid-template-columns: 1fr; }
    .htl-booking-split  { grid-template-columns: 1fr; }
    .htl-stats-grid     { grid-template-columns: repeat(2,1fr); }
    .htl-stat { border-right: none; border-bottom: 1px solid rgba(200,168,112,.15); }
    .htl-stat:nth-child(odd) { border-right: 1px solid rgba(200,168,112,.15); }
    .htl-stat:last-child { border-bottom: none; }
    .htl-nav-links { display: none; }
}
@media (max-width: 640px) {
    .htl-amenities-grid { grid-template-columns: 1fr; }
    .htl-team-grid      { grid-template-columns: 1fr; }
    .htl-testimonials-grid { grid-template-columns: 1fr; }
    .htl-form-row       { grid-template-columns: 1fr; }
    .htl-hero-ctas      { flex-direction: column; }
}
</style>

<div class="htl-page">

<!-- ══ NAV ══════════════════════════════════════════════════ -->
<nav class="htl-nav">
    <div class="htl-wrap">
        <div class="htl-nav-inner">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="htl-nav-logo" style="text-decoration:none;">
                <div class="htl-nav-logo-name"><?php echo esc_html($hotel_name); ?></div>
                <div class="htl-nav-logo-sub">Est. <?php echo esc_html($founded); ?> &middot; Cotswolds</div>
            </a>
            <ul class="htl-nav-links">
                <li><a href="#rooms">Rooms &amp; Suites</a></li>
                <li><a href="#amenities">Amenities</a></li>
                <li><a href="#dining">Dining</a></li>
                <li><a href="#team">The Team</a></li>
                <li><a href="#reservations">Reservations</a></li>
            </ul>
            <div class="htl-nav-cta">
                <a href="tel:<?php echo preg_replace('/\D/','',$phone); ?>" class="htl-nav-phone">&#128222; <?php echo esc_html($phone); ?></a>
                <a href="#reservations" class="htl-btn htl-btn-gold" style="padding:10px 22px;font-size:.78rem;">Book a Room</a>
            </div>
        </div>
    </div>
</nav>

<!-- ══ HERO ══════════════════════════════════════════════════ -->
<section class="htl-hero">
    <div class="htl-hero-scene">
        <div class="htl-sky"></div>
        <div class="htl-moon"></div>

        <!-- Stars -->
        <?php for ($i = 0; $i < $n_stars; $i++) :
            $lft = rand(0,100);
            $top = rand(0,55);
            $sz  = rand(1,3);
            $dur = rand(2,6);
            $del = rand(0,5);
        ?>
        <div class="htl-star" style="left:<?= $lft ?>%;top:<?= $top ?>%;width:<?= $sz ?>px;height:<?= $sz ?>px;animation-duration:<?= $dur ?>s;animation-delay:-<?= $del ?>s;"></div>
        <?php endfor; ?>

        <!-- Lawn & drive -->
        <div class="htl-lawn"></div>
        <div class="htl-drive"></div>
        <div class="htl-hedge htl-hedge-l"></div>
        <div class="htl-hedge htl-hedge-r"></div>

        <!-- Topiaries -->
        <div class="htl-topiary" style="left:calc(50% - 170px);bottom:28%;">
            <div class="htl-topiary-ball" style="width:40px;height:40px;"></div>
            <div class="htl-topiary-trunk" style="height:24px;"></div>
            <div class="htl-topiary-ball" style="width:30px;height:30px;"></div>
            <div class="htl-topiary-trunk" style="height:16px;"></div>
        </div>
        <div class="htl-topiary" style="left:calc(50% + 130px);bottom:28%;">
            <div class="htl-topiary-ball" style="width:40px;height:40px;"></div>
            <div class="htl-topiary-trunk" style="height:24px;"></div>
            <div class="htl-topiary-ball" style="width:30px;height:30px;"></div>
            <div class="htl-topiary-trunk" style="height:16px;"></div>
        </div>

        <!-- Trees -->
        <div class="htl-tree" style="left:8%;">
            <div class="htl-tree-canopy" style="width:80px;height:120px;background:radial-gradient(circle at 40% 30%,#2a4a1a 0%,#1a3010 60%,#0e2008 100%);"></div>
            <div class="htl-tree-trunk" style="height:50px;"></div>
        </div>
        <div class="htl-tree" style="right:6%;">
            <div class="htl-tree-canopy" style="width:70px;height:100px;background:radial-gradient(circle at 40% 30%,#2a4a1a 0%,#1a3010 60%,#0e2008 100%);"></div>
            <div class="htl-tree-trunk" style="height:40px;"></div>
        </div>

        <!-- House -->
        <div class="htl-house">
            <!-- Roof -->
            <div class="htl-roof">
                <div class="htl-chimney htl-chimney-1">
                    <div class="htl-chimney-top"></div>
                    <div class="htl-chimney-smoke"></div>
                </div>
                <div class="htl-chimney htl-chimney-2">
                    <div class="htl-chimney-top"></div>
                </div>
                <!-- Round window in gable -->
                <div class="htl-window-lit htl-window-round" style="position:absolute;top:12px;left:50%;transform:translateX(-50%);"></div>
            </div>
            <!-- Main wall -->
            <div class="htl-wall">
                <div class="htl-wall-stone"></div>
                <!-- Upper windows -->
                <?php $upper_w_positions = [6,24,44,64,82]; // percent from left
                foreach ($upper_w_positions as $wp) : ?>
                <div class="htl-window-lit" style="position:absolute;top:14px;left:<?= $wp ?>%;width:38px;height:52px;border-radius:4px 4px 0 0;"></div>
                <?php endforeach; ?>
                <!-- Lower windows / arch windows -->
                <div class="htl-window-lit htl-window-tall htl-window-arch" style="position:absolute;bottom:0;left:6%;width:40px;height:80px;"></div>
                <div class="htl-window-lit htl-window-tall htl-window-arch" style="position:absolute;bottom:0;left:24%;width:40px;height:80px;"></div>
                <div class="htl-window-lit htl-window-tall htl-window-arch" style="position:absolute;bottom:0;right:24%;width:40px;height:80px;"></div>
                <div class="htl-window-lit htl-window-tall htl-window-arch" style="position:absolute;bottom:0;right:6%;width:40px;height:80px;"></div>
                <!-- Door -->
                <div class="htl-door">
                    <div class="htl-door-handle"></div>
                </div>
                <div class="htl-door-light"></div>
                <!-- Lanterns -->
                <div class="htl-lantern left"></div>
                <div class="htl-lantern right"></div>
                <!-- Steps -->
                <div class="htl-step htl-step-1"></div>
                <div class="htl-step htl-step-2"></div>
                <div class="htl-step htl-step-3"></div>
                <!-- Porch columns -->
                <div class="htl-column" style="position:absolute;bottom:0;left:calc(50% - 44px);height:120px;"></div>
                <div class="htl-column" style="position:absolute;bottom:0;right:calc(50% - 44px);height:120px;"></div>
            </div>
        </div>

        <!-- String lights -->
        <?php for ($i = 0; $i < $n_lights; $i++) :
            $lft = $i * 9;
            $top = 4 + sin($i * 0.7) * 3;
            $sz  = rand(4, 7);
        ?>
        <div class="htl-bulb" style="left:<?= $lft ?>%;top:<?= $top ?>%;width:<?= $sz ?>px;height:<?= $sz ?>px;animation-duration:<?= 1.5 + ($i * .2) ?>s;animation-delay:-<?= rand(0,2) ?>s;"></div>
        <?php endfor; ?>
    </div>

    <div class="htl-wrap">
        <div class="htl-hero-content">
            <div class="htl-hero-est">Est. <?php echo esc_html($founded); ?> &middot; Chipping Campden, Cotswolds</div>
            <h1 class="htl-hero-h1">A Retreat as <em>Timeless</em><br>as the Cotswolds Itself</h1>
            <div class="htl-hero-sub"><?php echo esc_html($hotel_sub); ?></div>
            <p class="htl-hero-desc">
                Nestled within 18 acres of rolling Gloucestershire countryside,
                <?php echo esc_html($hotel_name); ?> offers 32 rooms and suites, an award-winning spa,
                an AA Two Rosette restaurant and the warmth of a family-run country house.
            </p>
            <div class="htl-hero-ctas">
                <a href="#reservations" class="htl-btn htl-btn-gold">Check Availability</a>
                <a href="#rooms" class="htl-btn htl-btn-outline">Explore Rooms</a>
            </div>
            <div class="htl-hero-awards">
                <?php $awards = ['AA ♦♦♦♦ Hotel','Condé Nast Johansens','2 Rosette Dining','Top 50 UK Spas'];
                foreach ($awards as $aw) : ?>
                <div class="htl-hero-award">
                    <div class="htl-hero-award-badge">★</div>
                    <span><?php echo esc_html($aw); ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>

<!-- ══ STATS ══════════════════════════════════════════════════ -->
<div class="htl-stats-bar">
    <div class="htl-wrap">
        <div class="htl-stats-grid">
            <?php foreach ($stats as $st) : ?>
            <div class="htl-stat">
                <div class="htl-stat-value">
                    <span class="htl-counter" data-target="<?php echo esc_attr(preg_replace('/,/','',$st['value'])); ?>"><?php echo esc_html($st['value']); ?></span><span class="htl-stat-suffix"><?php echo esc_html($st['suffix']); ?></span>
                </div>
                <div class="htl-stat-label"><?php echo esc_html($st['label']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ══ ROOMS ══════════════════════════════════════════════════ -->
<section class="htl-section" id="rooms">
    <div class="htl-wrap">
        <div class="htl-center">
            <span class="htl-kicker">Rooms &amp; Suites</span>
            <h2 class="htl-h2">Find Your Perfect Room</h2>
            <div class="htl-rule"><div class="htl-rule-line"></div><div class="htl-rule-diamond"></div><div class="htl-rule-line"></div></div>
            <p class="htl-lead">Every room at <?php echo esc_html($hotel_name); ?> has its own character — hand-selected furnishings, original artwork and beds designed for the deepest sleep.</p>
        </div>
        <div class="htl-rooms-grid">
            <?php foreach ($rooms as $room) :
                $wall_c  = $room['col'];
                $floor_c = '#2a1e10';
                $bed_c   = '#d8c8a0';
            ?>
            <div class="htl-room-card <?php echo !empty($room['featured']) ? 'featured' : ''; ?>">
                <div class="htl-room-visual" style="background:<?php echo esc_attr($wall_c); ?>;">
                    <div class="htl-room-sketch">
                        <div class="htl-sketch-floor" style="background:<?php echo esc_attr($floor_c); ?>;"></div>
                        <div class="htl-sketch-window"></div>
                        <div class="htl-sketch-headboard" style="background:<?php echo esc_attr($bed_c); ?>;opacity:.7;"></div>
                        <div class="htl-sketch-bed" style="background:<?php echo esc_attr($bed_c); ?>;opacity:.8;">
                            <div class="htl-sketch-pillow l"></div>
                            <div class="htl-sketch-pillow r"></div>
                        </div>
                        <div class="htl-sketch-lamp">
                            <div class="htl-sketch-lamp-shade"></div>
                            <div class="htl-sketch-lamp-pole"></div>
                        </div>
                    </div>
                    <?php if (!empty($room['featured'])) : ?>
                    <div class="htl-room-badge">Signature Suite</div>
                    <?php endif; ?>
                </div>
                <div class="htl-room-header">
                    <div class="htl-room-name"><?php echo esc_html($room['name']); ?></div>
                    <div class="htl-room-size"><?php echo esc_html($room['size']); ?></div>
                </div>
                <div class="htl-room-body">
                    <p class="htl-room-desc"><?php echo esc_html($room['desc']); ?></p>
                    <div class="htl-room-features">
                        <?php foreach ($room['features'] as $feat) : ?>
                        <span class="htl-room-feature"><?php echo esc_html($feat); ?></span>
                        <?php endforeach; ?>
                    </div>
                    <div class="htl-room-price">
                        <span class="htl-room-from">From</span>
                        <span class="htl-room-amount">£<?php echo esc_html($room['from']); ?></span>
                        <span class="htl-room-per">per night</span>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div style="text-align:center;margin-top:40px;">
            <a href="#reservations" class="htl-btn htl-btn-dark">Check Availability &rarr;</a>
        </div>
    </div>
</section>

<!-- ══ AMENITIES ══════════════════════════════════════════════ -->
<section class="htl-section htl-section-dark" id="amenities">
    <div class="htl-wrap">
        <div class="htl-center">
            <span class="htl-kicker">What Awaits You</span>
            <h2 class="htl-h2">Hotel Amenities</h2>
            <div class="htl-rule" style="justify-content:center;"><div class="htl-rule-line"></div><div class="htl-rule-diamond"></div><div class="htl-rule-line"></div></div>
            <p class="htl-lead">From morning swims to candlelit dinners — every detail of your stay is attended to.</p>
        </div>
        <div class="htl-amenities-grid">
            <?php foreach ($amenities as $am) : ?>
            <div class="htl-amenity-card">
                <div class="htl-amenity-icon"><?php echo $am['icon']; ?></div>
                <div>
                    <div class="htl-amenity-name"><?php echo esc_html($am['name']); ?></div>
                    <p class="htl-amenity-desc"><?php echo esc_html($am['desc']); ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══ DINING ════════════════════════════════════════════════ -->
<section class="htl-section htl-section-alt" id="dining">
    <div class="htl-wrap">
        <div class="htl-dining-split">
            <div class="htl-dining-visual">
                <div class="htl-dining-bg"></div>
                <div class="htl-dining-window-light"></div>
                <div class="htl-oak-sign">
                    <div class="htl-oak-sign-title">The Oak Room</div>
                    <div class="htl-oak-sign-sub">AA Two Rosette Restaurant</div>
                </div>
                <!-- Table setting -->
                <div class="htl-table">
                    <div class="htl-table-top"></div>
                    <div class="htl-table-leg l"></div>
                    <div class="htl-table-leg r"></div>
                </div>
                <!-- Place settings left -->
                <div class="htl-place-setting" style="left:calc(50% - 100px);">
                    <div class="htl-plate" style="width:44px;height:44px;position:relative;background:rgba(248,244,236,.9);">
                        <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:30px;height:30px;border-radius:50%;border:1px solid rgba(200,180,120,.3);"></div>
                    </div>
                </div>
                <!-- Cutlery left -->
                <div class="htl-cutlery" style="position:absolute;bottom:calc(15% + 20px);left:calc(50% - 122px);height:50px;"></div>
                <div class="htl-cutlery" style="position:absolute;bottom:calc(15% + 20px);left:calc(50% - 82px);height:50px;"></div>
                <!-- Place settings right -->
                <div class="htl-place-setting" style="right:calc(50% - 100px);">
                    <div class="htl-plate" style="width:44px;height:44px;position:relative;background:rgba(248,244,236,.9);">
                        <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:30px;height:30px;border-radius:50%;border:1px solid rgba(200,180,120,.3);"></div>
                    </div>
                </div>
                <!-- Cutlery right -->
                <div class="htl-cutlery" style="position:absolute;bottom:calc(15% + 20px);right:calc(50% - 122px);height:50px;"></div>
                <div class="htl-cutlery" style="position:absolute;bottom:calc(15% + 20px);right:calc(50% - 82px);height:50px;"></div>
                <!-- Wine glasses -->
                <div class="htl-glass" style="position:absolute;bottom:calc(15% + 55px);left:calc(50% - 90px);width:20px;height:28px;background:transparent;"></div>
                <div class="htl-glass" style="position:absolute;bottom:calc(15% + 55px);right:calc(50% - 90px);width:20px;height:28px;background:transparent;"></div>
                <!-- Candelabra -->
                <div class="htl-candelabra">
                    <div class="htl-cand-base"></div>
                    <div class="htl-cand-stem" style="position:relative;">
                        <div class="htl-cand-arm l"></div>
                        <div class="htl-cand-arm r"></div>
                    </div>
                    <div class="htl-cand-candle" style="position:absolute;bottom:50px;left:50%;transform:translateX(-50%);">
                        <div class="htl-cand-flame"></div>
                    </div>
                    <div class="htl-cand-candle" style="position:absolute;bottom:40px;left:calc(50% - 28px);transform:translateX(-50%) rotate(-15deg);">
                        <div class="htl-cand-flame"></div>
                    </div>
                    <div class="htl-cand-candle" style="position:absolute;bottom:40px;left:calc(50% + 28px);transform:translateX(-50%) rotate(15deg);">
                        <div class="htl-cand-flame"></div>
                    </div>
                </div>
            </div>
            <div>
                <span class="htl-kicker">Fine Dining</span>
                <h2 class="htl-h2">The Oak Room Restaurant</h2>
                <div class="htl-rule"><div class="htl-rule-line"></div><div class="htl-rule-diamond"></div><div class="htl-rule-line"></div></div>
                <p class="htl-lead" style="margin-bottom:24px;">Awarded two AA Rosettes for culinary excellence, The Oak Room celebrates the finest seasonal produce — much of it harvested that very morning from our walled kitchen garden.</p>
                <p style="font-size:.9rem;color:var(--htl-muted);line-height:1.75;margin-bottom:32px;">Head Chef Léa Moreau's menus change with the seasons, featuring produce from named farms within twenty miles of the house. Vegetarian and vegan menus are crafted with the same care and imagination.</p>
                <?php $dining_features = [
                    'Breakfast 7–10:30am',
                    'Lunch 12–2:30pm',
                    'Dinner 6:30–9:30pm',
                    'Afternoon Tea Daily',
                    'Residents\' Bar Open All Day',
                    'Private Dining Available',
                ];
                echo '<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:32px;">';
                foreach ($dining_features as $df) {
                    echo '<span style="background:var(--htl-ivory);border:1px solid var(--htl-border);color:var(--htl-muted);font-size:.76rem;padding:5px 14px;border-radius:2px;">' . esc_html($df) . '</span>';
                }
                echo '</div>';
                ?>
                <a href="#reservations" class="htl-btn htl-btn-gold">Reserve a Table</a>
            </div>
        </div>
    </div>
</section>

<!-- ══ TEAM ══════════════════════════════════════════════════ -->
<section class="htl-section" id="team">
    <div class="htl-wrap">
        <div class="htl-center">
            <span class="htl-kicker">The People</span>
            <h2 class="htl-h2">Dedicated to Your Stay</h2>
            <div class="htl-rule" style="justify-content:center;"><div class="htl-rule-line"></div><div class="htl-rule-diamond"></div><div class="htl-rule-line"></div></div>
            <p class="htl-lead">Our team has been welcoming guests to <?php echo esc_html($hotel_name); ?> for generations. Their care and knowledge make every stay exceptional.</p>
        </div>
        <div class="htl-team-grid">
            <?php $staff_bgs   = ['#1a2a3a','#1e3a2a','#2a1a2a'];
            $staff_jackets = ['#0d1117','#1e3a2a','#1a1a2e'];
            $staff_skin    = ['#c8966a','#d4a878','#a87848'];
            foreach ($team as $ti => $tm) :
                $sbg = $staff_bgs[$ti % count($staff_bgs)];
                $sjk = $staff_jackets[$ti % count($staff_jackets)];
                $ssk = $staff_skin[$ti % count($staff_skin)];
            ?>
            <div class="htl-team-card">
                <div class="htl-team-avatar" style="background:<?php echo esc_attr($sbg); ?>;">
                    <div class="htl-staff-fig">
                        <div class="htl-staff-head" style="background:radial-gradient(circle at 40% 35%,<?php echo esc_attr($ssk); ?> 0%,<?php echo esc_attr($ssk); ?>aa 100%);"></div>
                        <div class="htl-staff-jacket" style="background:linear-gradient(180deg,<?php echo esc_attr($sjk); ?> 0%,<?php echo esc_attr($sjk); ?> 100%);">
                            <div class="htl-staff-bow-tie"></div>
                            <div class="htl-staff-badge"></div>
                        </div>
                    </div>
                </div>
                <div class="htl-team-info">
                    <div class="htl-team-name"><?php echo esc_html($tm['name']); ?></div>
                    <div class="htl-team-role"><?php echo esc_html($tm['role']); ?></div>
                    <span class="htl-team-years"><?php echo esc_html($tm['years']); ?> years at <?php echo esc_html($hotel_name); ?></span>
                    <p class="htl-team-desc"><?php echo esc_html($tm['desc']); ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══ TESTIMONIALS ══════════════════════════════════════════ -->
<section class="htl-section htl-section-alt" id="testimonials">
    <div class="htl-wrap">
        <div class="htl-center">
            <span class="htl-kicker">Guest Reviews</span>
            <h2 class="htl-h2">What Our Guests Say</h2>
            <div class="htl-rule" style="justify-content:center;"><div class="htl-rule-line"></div><div class="htl-rule-diamond"></div><div class="htl-rule-line"></div></div>
        </div>
        <div class="htl-testimonials-grid">
            <?php foreach ($testimonials as $t) : ?>
            <div class="htl-testimonial">
                <div class="htl-testimonial-stars">
                    <?php for ($s = 0; $s < $t['stars']; $s++) echo '<span>&#9733;</span>'; ?>
                </div>
                <p class="htl-testimonial-quote"><?php echo esc_html($t['quote']); ?></p>
                <div class="htl-testimonial-name"><?php echo esc_html($t['name']); ?></div>
                <div class="htl-testimonial-source"><?php echo esc_html($t['source']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══ FAQ ═══════════════════════════════════════════════════ -->
<section class="htl-section" id="faq">
    <div class="htl-wrap" style="max-width:800px;">
        <div class="htl-center">
            <span class="htl-kicker">Guest Information</span>
            <h2 class="htl-h2">Frequently Asked Questions</h2>
            <div class="htl-rule" style="justify-content:center;"><div class="htl-rule-line"></div><div class="htl-rule-diamond"></div><div class="htl-rule-line"></div></div>
        </div>
        <div class="htl-faq-list">
            <?php foreach ($faqs as $fi => $faq) : ?>
            <div class="htl-faq-item">
                <div class="htl-faq-q" role="button" aria-expanded="false" aria-controls="htl-faq-a-<?php echo $fi; ?>" tabindex="0">
                    <?php echo esc_html($faq['q']); ?>
                    <span class="htl-faq-icon">+</span>
                </div>
                <div class="htl-faq-a" id="htl-faq-a-<?php echo $fi; ?>" role="region">
                    <div class="htl-faq-a-inner"><?php echo esc_html($faq['a']); ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══ RESERVATIONS ══════════════════════════════════════════ -->
<section class="htl-section htl-section-dark" id="reservations">
    <div class="htl-wrap">
        <div class="htl-booking-split">
            <div class="htl-booking-info">
                <span class="htl-kicker">Reservations</span>
                <h2 class="htl-h2">Plan Your Stay</h2>
                <div class="htl-rule"><div class="htl-rule-line"></div><div class="htl-rule-diamond"></div><div class="htl-rule-line"></div></div>
                <p class="htl-lead" style="margin-bottom:40px;">
                    Our reservations team are on hand seven days a week to help you plan the perfect stay — from romantic weekends to family celebrations.
                </p>
                <div class="htl-contact-line">
                    <div class="htl-contact-line-icon">
                        <svg viewBox="0 0 24 24"><path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1-9.4 0-17-7.6-17-17 0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1L6.6 10.8z"/></svg>
                    </div>
                    <div>
                        <div class="htl-contact-line-label">Reservations</div>
                        <div class="htl-contact-line-value"><a href="tel:<?php echo preg_replace('/\D/','',$phone); ?>"><?php echo esc_html($phone); ?></a></div>
                    </div>
                </div>
                <div class="htl-contact-line">
                    <div class="htl-contact-line-icon">
                        <svg viewBox="0 0 24 24"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
                    </div>
                    <div>
                        <div class="htl-contact-line-label">Email</div>
                        <div class="htl-contact-line-value"><a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a></div>
                    </div>
                </div>
                <div class="htl-contact-line">
                    <div class="htl-contact-line-icon">
                        <svg viewBox="0 0 24 24"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>
                    </div>
                    <div>
                        <div class="htl-contact-line-label">Address</div>
                        <div class="htl-contact-line-value"><?php echo esc_html($address); ?></div>
                    </div>
                </div>
                <div style="margin-top:8px;padding:20px;background:rgba(255,255,255,.05);border:1px solid rgba(200,168,112,.15);border-radius:var(--htl-r-lg);">
                    <div style="font-size:.7rem;letter-spacing:.18em;text-transform:uppercase;color:var(--htl-warm);margin-bottom:12px;font-weight:500;">Reservations Hours</div>
                    <?php $hours = [['Mon–Fri','8am – 8pm'],['Saturday','9am – 7pm'],['Sunday','10am – 6pm']];
                    foreach ($hours as $h) : ?>
                    <div style="display:flex;justify-content:space-between;font-size:.84rem;color:rgba(255,255,255,.6);padding:5px 0;border-bottom:1px solid rgba(255,255,255,.06);">
                        <span><?php echo esc_html($h[0]); ?></span><span><?php echo esc_html($h[1]); ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="htl-form-card">
                <div class="htl-form-title">Check Availability</div>
                <div class="htl-form-sub">Submit an enquiry and our team will confirm within 2 hours.</div>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" novalidate>
                    <?php wp_nonce_field('tf_htl_booking','tf_htl_nonce'); ?>
                    <input type="hidden" name="action" value="tf_hotel_booking">
                    <div class="htl-form-row">
                        <div class="htl-form-group">
                            <label for="htl-fname">First Name <span style="color:var(--htl-bronze)">*</span></label>
                            <input type="text" id="htl-fname" name="first_name" placeholder="Jonathan" required>
                        </div>
                        <div class="htl-form-group">
                            <label for="htl-lname">Last Name <span style="color:var(--htl-bronze)">*</span></label>
                            <input type="text" id="htl-lname" name="last_name" placeholder="Ashford" required>
                        </div>
                    </div>
                    <div class="htl-form-row">
                        <div class="htl-form-group">
                            <label for="htl-email">Email <span style="color:var(--htl-bronze)">*</span></label>
                            <input type="email" id="htl-email" name="email" placeholder="you@example.com" required>
                        </div>
                        <div class="htl-form-group">
                            <label for="htl-phone">Phone</label>
                            <input type="tel" id="htl-phone" name="phone" placeholder="07700 900000">
                        </div>
                    </div>
                    <div class="htl-form-row">
                        <div class="htl-form-group">
                            <label for="htl-checkin">Check-in Date <span style="color:var(--htl-bronze)">*</span></label>
                            <input type="date" id="htl-checkin" name="checkin" min="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                        <div class="htl-form-group">
                            <label for="htl-checkout">Check-out Date <span style="color:var(--htl-bronze)">*</span></label>
                            <input type="date" id="htl-checkout" name="checkout" min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>" required>
                        </div>
                    </div>
                    <div class="htl-form-row">
                        <div class="htl-form-group">
                            <label for="htl-room-type">Room Type</label>
                            <select id="htl-room-type" name="room_type">
                                <option value="">— No preference —</option>
                                <?php foreach ($rooms as $r) : ?>
                                <option value="<?php echo esc_attr(sanitize_title($r['name'])); ?>"><?php echo esc_html($r['name']); ?> (from £<?php echo esc_html($r['from']); ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="htl-form-group">
                            <label for="htl-guests">Number of Guests <span style="color:var(--htl-bronze)">*</span></label>
                            <select id="htl-guests" name="guests" required>
                                <option value="1">1 Guest</option>
                                <option value="2" selected>2 Guests</option>
                                <option value="3">3 Guests</option>
                                <option value="4">4 Guests</option>
                                <option value="more">More than 4</option>
                            </select>
                        </div>
                    </div>
                    <div class="htl-form-group">
                        <label for="htl-occasion">Special Occasion</label>
                        <select id="htl-occasion" name="occasion">
                            <option value="">— None / Not specified —</option>
                            <option value="anniversary">Anniversary</option>
                            <option value="birthday">Birthday</option>
                            <option value="honeymoon">Honeymoon</option>
                            <option value="proposal">Proposal</option>
                            <option value="corporate">Corporate / Business</option>
                        </select>
                    </div>
                    <div class="htl-form-group">
                        <label for="htl-notes">Special Requests</label>
                        <textarea id="htl-notes" name="notes" placeholder="Dietary requirements, accessibility needs, specific room preferences, arrival time..."></textarea>
                    </div>
                    <button type="submit" class="htl-btn htl-btn-gold" style="width:100%;justify-content:center;font-size:.9rem;">
                        Request Reservation &rarr;
                    </button>
                    <p class="htl-form-note">We will respond within 2 hours. All rates include VAT and full access to spa facilities.</p>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- ══ FOOTER ════════════════════════════════════════════════ -->
<footer class="htl-footer">
    <div class="htl-wrap">
        <div class="htl-footer-inner">
            <div>
                <div class="htl-footer-copy">&copy; <?php echo date('Y'); ?> <?php echo esc_html($hotel_name); ?>. All rights reserved.</div>
                <div class="htl-footer-address"><?php echo esc_html($address); ?></div>
            </div>
            <div class="htl-footer-links">
                <a href="#">Privacy Policy</a>
                <a href="#">Terms &amp; Conditions</a>
                <a href="#">Cookie Policy</a>
                <a href="#">Accessibility</a>
            </div>
        </div>
    </div>
</footer>

</div><!-- .htl-page -->

<script>
/* ── Animated counters ─────────────────────────────────── */
(function () {
    var counters = document.querySelectorAll('.htl-counter');
    if (!counters.length) return;
    var observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (!entry.isIntersecting) return;
            observer.unobserve(entry.target);
            var el      = entry.target;
            var raw     = el.dataset.target.replace(/,/g, '');
            var end     = parseFloat(raw);
            if (isNaN(end)) return;
            var isFloat = raw.indexOf('.') !== -1;
            var dur     = 1800;
            var start   = performance.now();
            var easeOut = function (t) { return 1 - Math.pow(1 - t, 3); };
            (function tick(now) {
                var prog = Math.min((now - start) / dur, 1);
                var val  = end * easeOut(prog);
                el.textContent = isFloat
                    ? val.toFixed(1)
                    : Math.round(val).toLocaleString();
                if (prog < 1) requestAnimationFrame(tick);
                else el.textContent = isFloat ? end.toFixed(1) : end.toLocaleString();
            })(start);
        });
    }, { threshold: 0.4 });
    counters.forEach(function (c) { observer.observe(c); });
})();

/* ── FAQ accordion ─────────────────────────────────────── */
(function () {
    var questions = document.querySelectorAll('.htl-faq-q');
    questions.forEach(function (q) {
        function toggle() {
            var isOpen = q.classList.contains('open');
            document.querySelectorAll('.htl-faq-q').forEach(function (qq) { qq.classList.remove('open'); qq.setAttribute('aria-expanded','false'); });
            document.querySelectorAll('.htl-faq-a').forEach(function (aa) { aa.classList.remove('open'); });
            if (!isOpen) {
                q.classList.add('open');
                q.setAttribute('aria-expanded','true');
                var aid = q.getAttribute('aria-controls');
                var ans = document.getElementById(aid);
                if (ans) ans.classList.add('open');
            }
        }
        q.addEventListener('click', toggle);
        q.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); } });
    });
})();

/* ── Check-out date min = check-in + 1 ────────────────── */
(function () {
    var ci = document.getElementById('htl-checkin');
    var co = document.getElementById('htl-checkout');
    if (!ci || !co) return;
    ci.addEventListener('change', function () {
        if (!ci.value) return;
        var next = new Date(ci.value);
        next.setDate(next.getDate() + 1);
        co.min = next.toISOString().split('T')[0];
        if (co.value && co.value <= ci.value) co.value = next.toISOString().split('T')[0];
    });
})();
</script>

<?php get_footer(); ?>
