<?php
/**
 * Template Name: Hypnotherapist
 *
 * Premium hypnotherapy practice homepage.
 * Fonts  : Cinzel Decorative + Raleway (Google Fonts)
 * Palette: midnight ink #0B0C1A / deep violet #3D1A78 / silver mist #C8D0E0 / luminous teal #00C2B2 / warm ivory #F5F2EC
 * Tokens : --hy-* (zero cross-template contamination)
 */
defined('ABSPATH') || exit;
/* ── Seeded randomness ──────────────────────────────────── */
srand(crc32(get_the_permalink()));

/* ── Hero floating orbs ────────────────────────────────── */
$orb_symbols = ['○','◎','◯','◦','⊙','⊕','◉','●','⬤','◐','◑','◒','◓','⊗','∘','·'];
$orbs = [];
for ($i = 0; $i < 22; $i++) {
    $orbs[] = [
        'sym'   => $orb_symbols[array_rand($orb_symbols)],
        'top'   => rand(5, 90),
        'left'  => rand(3, 97),
        'size'  => rand(11, 28),
        'dur'   => rand(6, 18),
        'delay' => rand(0, 10),
        'col'   => (rand(0,1) ? 'var(--hy-teal)' : 'var(--hy-violet-lt)'),
    ];
}

/* ── Brain wave pulses (concentric arcs) ──────────────── */
$waves = 5; // CSS-only, described in HTML

/* ── Crystal ball particles ────────────────────────────── */
$crystal_sparks = [];
$spark_chars = ['✦','✧','✩','✪','★','☆','✫','✬','✭','✮'];
for ($i = 0; $i < 8; $i++) {
    $crystal_sparks[] = [
        'sym'   => $spark_chars[array_rand($spark_chars)],
        'ang'   => rand(0,359),
        'dist'  => rand(52, 80),
        'size'  => rand(10, 18),
        'delay' => rand(0, 5),
    ];
}

/* ── Spiral hypnotic disc segments ────────────────────── */
$spiral_segs = 12;

/* ── Testimonials ──────────────────────────────────────── */
$testimonials = [
    ['name'=>'Sarah M.','role'=>'Anxiety & Phobia Client','rating'=>5,
     'text'=>'After just four sessions I boarded a plane for the first time in eight years. The transformation felt completely natural — like the fear had never existed.'],
    ['name'=>'James R.','role'=>'Smoking Cessation Client','rating'=>5,
     'text'=>'I smoked for 22 years. One session and the craving simply vanished. Six months on and I have never looked back. Absolutely life-changing.'],
    ['name'=>'Priya S.','role'=>'Sleep & Stress Client','rating'=>5,
     'text'=>'My insomnia had lasted three years. The deep relaxation techniques and personalised recording mean I now sleep soundly every single night.'],
];

/* ── Services ──────────────────────────────────────────── */
$services = [
    ['icon'=>'🧠','title'=>'Anxiety & Panic','desc'=>'Release the root cause of anxiety, rewire your nervous system and restore calm confidence.'],
    ['icon'=>'🚭','title'=>'Stop Smoking','desc'=>'Single-session quit programme combining hypnosis, NLP and motivational techniques.'],
    ['icon'=>'😴','title'=>'Sleep Therapy','desc'=>'Overcome insomnia, night anxiety and restless sleep with deep-trance conditioning.'],
    ['icon'=>'🎯','title'=>'Phobia Release','desc'=>'Fast and permanent resolution of specific phobias using regression and reframing.'],
    ['icon'=>'⚖️','title'=>'Weight & Habits','desc'=>'Address the subconscious drivers of emotional eating and unwanted habits.'],
    ['icon'=>'🏅','title'=>'Performance','desc'=>'Sports coaching, exam confidence, public speaking and boardroom presence.'],
    ['icon'=>'💔','title'=>'Trauma & PTSD','desc'=>'Gentle trauma-informed hypnotherapy with EMDR integration for deep healing.'],
    ['icon'=>'🌙','title'=>'Self-Hypnosis','desc'=>'Learn powerful self-hypnosis techniques to maintain and deepen your progress.'],
];

/* ── Conditions tag cloud ───────────────────────────────── */
$conditions = [
    'Anxiety','Panic Attacks','Phobias','Insomnia','PTSD','Stress',
    'Smoking','Weight Loss','OCD','Depression','Grief','Low Self-Esteem',
    'Tinnitus','IBS','Pain Management','Exam Nerves','Fear of Flying',
    'Public Speaking','Social Anxiety','Addiction','Anger Management',
    'Blushing','Nail Biting','Bruxism','Fertility Hypnosis',
];

/* ── Approach steps ─────────────────────────────────────── */
$steps = [
    ['num'=>'01','title'=>'Discovery Call','desc'=>'A complimentary 20-minute consultation to understand your goals and explain the process.'],
    ['num'=>'02','title'=>'Deep Assessment','desc'=>'Full history, timeline and subconscious mapping to design your bespoke programme.'],
    ['num'=>'03','title'=>'Trance Induction','desc'=>'Guided entry into a deeply relaxed hypnotic state tailored to your personal depth preference.'],
    ['num'=>'04','title'=>'Inner Transformation','desc'=>'Precision suggestion therapy, regression work and NLP reframing at the subconscious level.'],
    ['num'=>'05','title'=>'Integration','desc'=>'Personalised self-hypnosis recording plus between-session support for lasting change.'],
];

/* ── Gallery panels ─────────────────────────────────────── */
$gallery = [
    ['label'=>'Consultation Room','color'=>'linear-gradient(135deg,#1a0a3d,#3D1A78)','icon'=>'🛋️'],
    ['label'=>'Deep Trance','color'=>'linear-gradient(135deg,#0a1a2d,#00C2B2)','icon'=>'💫'],
    ['label'=>'NLP Reframing','color'=>'linear-gradient(135deg,#1a1a3d,#5B2FA0)','icon'=>'🔮'],
    ['label'=>'Client Results','color'=>'linear-gradient(135deg,#0d1a1a,#007a6e)','icon'=>'📈'],
    ['label'=>'Recording Studio','color'=>'linear-gradient(135deg,#1a0d2e,#2a0e5e)','icon'=>'🎧'],
    ['label'=>'Online Sessions','color'=>'linear-gradient(135deg,#0a1a2a,#00C2B2)','icon'=>'💻'],
];

/* ── Counters ───────────────────────────────────────────── */
$counters = [
    ['val'=>14,'suffix'=>' yrs','label'=>'In Practice','float'=>0],
    ['val'=>2600,'suffix'=>'+','label'=>'Sessions Delivered','float'=>0],
    ['val'=>4.9,'suffix'=>'★','label'=>'Average Rating','float'=>1],
    ['val'=>91,'suffix'=>'%','label'=>'Report Lasting Change','float'=>0],
];

/* ── Packages ───────────────────────────────────────────── */
$packages = [
    ['name'=>'Discovery','price'=>'£95','per'=>'single session','featured'=>false,
     'features'=>['60-minute session','Personalised induction','Follow-up notes','Email support']],
    ['name'=>'Transformation','price'=>'£350','per'=>'4-session programme','featured'=>true,
     'features'=>['4 × 75-minute sessions','Custom hypnosis recording','WhatsApp support','Free follow-up call','Progress tracking']],
    ['name'=>'Deep Change','price'=>'£595','per'=>'7-session programme','featured'=>false,
     'features'=>['7 × 75-minute sessions','2 custom recordings','Priority WhatsApp','Monthly check-ins for 3 months','Unlimited email support']],
];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cinzel+Decorative:wght@400;700&family=Raleway:ital,wght@0,300;0,400;0,600;0,700;1,300&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════════
   HYPNOTHERAPIST — CSS TOKENS  (--hy-*)
   ═══════════════════════════════════════════════════════════ */
:root {
  --hy-ink:        #0B0C1A;
  --hy-violet:     #3D1A78;
  --hy-violet-lt:  #7B4DC0;
  --hy-violet-d:   #260e52;
  --hy-teal:       #00C2B2;
  --hy-teal-d:     #008e82;
  --hy-mist:       #C8D0E0;
  --hy-ivory:      #F5F2EC;
  --hy-ivory-d:    #e8e4dc;
  --hy-font-head:  'Cinzel Decorative', serif;
  --hy-font-body:  'Raleway', sans-serif;
  --hy-radius:     12px;
  --hy-shadow:     0 8px 32px rgba(0,0,0,.35);
}

/* ── Reset & Base ────────────────────────────────────────── */
.hy-wrap *, .hy-wrap *::before, .hy-wrap *::after { box-sizing:border-box; margin:0; padding:0; }
.hy-wrap { font-family:var(--hy-font-body); color:var(--hy-ink); background:var(--hy-ivory); line-height:1.7; }
.hy-wrap img { max-width:100%; }
.hy-container { max-width:1200px; margin:0 auto; padding:0 24px; }
.hy-section { padding:96px 0; }
.hy-section--dark { background:var(--hy-ink); color:var(--hy-mist); }
.hy-section--violet { background:var(--hy-violet-d); color:var(--hy-mist); }
.hy-section--ivory { background:var(--hy-ivory-d); }
.hy-tag { display:inline-block; background:rgba(0,194,178,.12); color:var(--hy-teal-d); font-size:.7rem; font-weight:700; letter-spacing:.1em; text-transform:uppercase; padding:4px 14px; border-radius:20px; margin-bottom:16px; }
.hy-tag--light { background:rgba(200,208,224,.15); color:var(--hy-mist); }
.hy-h1 { font-family:var(--hy-font-head); font-size:clamp(2rem,5vw,3.6rem); line-height:1.15; letter-spacing:.02em; }
.hy-h2 { font-family:var(--hy-font-head); font-size:clamp(1.5rem,3.5vw,2.6rem); line-height:1.2; letter-spacing:.02em; margin-bottom:12px; }
.hy-lead { font-size:1.1rem; font-weight:300; opacity:.85; max-width:640px; }
.hy-btn { display:inline-block; padding:14px 36px; border-radius:var(--hy-radius); font-family:var(--hy-font-body); font-size:.95rem; font-weight:700; letter-spacing:.05em; text-decoration:none; cursor:pointer; border:none; transition:transform .2s,box-shadow .2s; }
.hy-btn--primary { background:linear-gradient(135deg,var(--hy-teal),var(--hy-teal-d)); color:#fff; box-shadow:0 4px 20px rgba(0,194,178,.4); }
.hy-btn--primary:hover { transform:translateY(-2px); box-shadow:0 8px 28px rgba(0,194,178,.5); }
.hy-btn--ghost { background:transparent; color:var(--hy-teal); border:2px solid var(--hy-teal); }
.hy-btn--ghost:hover { background:rgba(0,194,178,.1); transform:translateY(-2px); }

/* ═══════════════════════════════════════════════════════════
   HERO
   ═══════════════════════════════════════════════════════════ */
.hy-hero {
  position:relative; min-height:100vh;
  background:linear-gradient(145deg,#060610 0%,#0e0825 40%,#1a0a3d 70%,#0d1a2a 100%);
  overflow:hidden; display:flex; align-items:center;
}
/* Starfield backdrop */
.hy-hero::before {
  content:''; position:absolute; inset:0;
  background-image:
    radial-gradient(1px 1px at 15% 20%,rgba(255,255,255,.5) 0%,transparent 100%),
    radial-gradient(1px 1px at 30% 55%,rgba(255,255,255,.4) 0%,transparent 100%),
    radial-gradient(1px 1px at 55% 10%,rgba(255,255,255,.6) 0%,transparent 100%),
    radial-gradient(1px 1px at 70% 35%,rgba(255,255,255,.3) 0%,transparent 100%),
    radial-gradient(1px 1px at 85% 65%,rgba(255,255,255,.5) 0%,transparent 100%),
    radial-gradient(1px 1px at 42% 80%,rgba(255,255,255,.4) 0%,transparent 100%),
    radial-gradient(2px 2px at 90% 15%,rgba(0,194,178,.4) 0%,transparent 100%),
    radial-gradient(2px 2px at 5%  80%,rgba(123,77,192,.5) 0%,transparent 100%),
    radial-gradient(120px 120px at 80% 50%,rgba(61,26,120,.25) 0%,transparent 100%);
  pointer-events:none;
}

/* ── Floating orb particles ──────────────────────────────── */
.hy-orb { position:absolute; border-radius:50%; animation:hy-float var(--dur,8s) var(--del,0s) ease-in-out infinite alternate; pointer-events:none; opacity:.6; }
@keyframes hy-float {
  from { transform:translateY(0) scale(1);   opacity:.4; }
  to   { transform:translateY(-40px) scale(1.15); opacity:.8; }
}

/* ── Hero scene ────────────────────────────────────────────── */
.hy-hero__inner { position:relative; z-index:2; display:grid; grid-template-columns:1fr 1fr; gap:60px; align-items:center; padding:120px 0 80px; }
.hy-hero__content {}
.hy-hero__scene { display:flex; justify-content:center; align-items:center; }

/* ── Content side ────────────────────────────────────────── */
.hy-hero__badge { display:inline-flex; align-items:center; gap:8px; background:rgba(0,194,178,.12); border:1px solid rgba(0,194,178,.3); color:var(--hy-teal); padding:6px 18px; border-radius:20px; font-size:.75rem; font-weight:700; letter-spacing:.1em; text-transform:uppercase; margin-bottom:24px; }
.hy-hero__title { color:#fff; margin-bottom:20px; }
.hy-hero__sub { color:var(--hy-mist); font-size:1.1rem; font-weight:300; margin-bottom:36px; line-height:1.7; }
.hy-hero__ctas { display:flex; gap:16px; flex-wrap:wrap; margin-bottom:48px; }
.hy-hero__trust { display:flex; gap:32px; flex-wrap:wrap; }
.hy-hero__trust-item { display:flex; align-items:center; gap:8px; color:var(--hy-mist); font-size:.85rem; }
.hy-hero__trust-item span:first-child { font-size:1.2rem; }

/* ═══════════════════════════════════════════════════════════
   HYPNOTIC DISC SCENE
   ═══════════════════════════════════════════════════════════ */
.hy-disc-wrap {
  position:relative; width:420px; height:420px;
}

/* Outer ambient glow */
.hy-disc-wrap::before {
  content:''; position:absolute;
  inset:-40px; border-radius:50%;
  background:radial-gradient(circle,rgba(61,26,120,.5) 0%,rgba(0,194,178,.15) 50%,transparent 70%);
  animation:hy-aura-pulse 4s ease-in-out infinite alternate;
}
@keyframes hy-aura-pulse {
  from { opacity:.6; transform:scale(.9); }
  to   { opacity:1;  transform:scale(1.05); }
}

/* Crystal ball */
.hy-ball {
  position:absolute; top:50%; left:50%;
  transform:translate(-50%,-50%);
  width:220px; height:220px; border-radius:50%;
  background:radial-gradient(circle at 35% 35%,
    rgba(200,220,255,.3) 0%,
    rgba(61,26,120,.6) 30%,
    rgba(11,12,26,.95) 60%,
    rgba(0,194,178,.15) 100%);
  border:1px solid rgba(200,208,224,.2);
  box-shadow:
    0 0 40px rgba(61,26,120,.6),
    0 0 80px rgba(0,194,178,.2),
    inset 0 0 40px rgba(0,0,0,.5);
  z-index:10;
  overflow:hidden;
}

/* Inner hypnotic spiral inside ball */
.hy-ball__spiral {
  position:absolute; inset:0;
  display:flex; align-items:center; justify-content:center;
}
.hy-spiral-disc {
  width:160px; height:160px; border-radius:50%;
  background:conic-gradient(
    from 0deg,
    transparent 0deg, rgba(0,194,178,.4) 15deg,
    transparent 30deg, rgba(61,26,120,.4) 45deg,
    transparent 60deg, rgba(0,194,178,.3) 75deg,
    transparent 90deg, rgba(123,77,192,.35) 105deg,
    transparent 120deg, rgba(0,194,178,.4) 135deg,
    transparent 150deg, rgba(61,26,120,.4) 165deg,
    transparent 180deg, rgba(0,194,178,.3) 195deg,
    transparent 210deg, rgba(123,77,192,.35) 225deg,
    transparent 240deg, rgba(0,194,178,.4) 255deg,
    transparent 270deg, rgba(61,26,120,.4) 285deg,
    transparent 300deg, rgba(0,194,178,.3) 315deg,
    transparent 330deg, rgba(123,77,192,.35) 345deg,
    transparent 360deg
  );
  animation:hy-spin 8s linear infinite;
  filter:blur(1px);
}
@keyframes hy-spin { to { transform:rotate(360deg); } }

/* Ball highlight */
.hy-ball::after {
  content:''; position:absolute;
  top:12%; left:15%; width:35%; height:25%;
  background:radial-gradient(ellipse,rgba(255,255,255,.25) 0%,transparent 70%);
  border-radius:50%; transform:rotate(-30deg);
}

/* Crystal ball base */
.hy-ball-base {
  position:absolute; bottom:18%; left:50%; transform:translateX(-50%);
  width:80px; height:16px; border-radius:50%;
  background:linear-gradient(180deg,#2a1a50,#1a0d35);
  box-shadow:0 4px 16px rgba(0,0,0,.5);
  z-index:9;
}
.hy-ball-base::before {
  content:''; position:absolute;
  top:50%; left:50%; transform:translate(-50%,-50%);
  width:60px; height:6px; border-radius:50%;
  background:rgba(200,208,224,.1);
}

/* Crystal sparks orbiting ball */
.hy-spark {
  position:absolute; top:50%; left:50%;
  transform-origin:0 0;
  font-size:14px; color:var(--hy-teal);
  animation:hy-orbit var(--spark-dur,6s) var(--spark-del,0s) linear infinite;
  z-index:11;
}
@keyframes hy-orbit {
  from { transform:rotate(var(--spark-ang,0deg)) translateX(var(--spark-dist,60px)) rotate(calc(-1 * var(--spark-ang,0deg))); }
  to   { transform:rotate(calc(var(--spark-ang,0deg) + 360deg)) translateX(var(--spark-dist,60px)) rotate(calc(-1 * (var(--spark-ang,0deg) + 360deg))); }
}

/* Concentric brain-wave rings */
.hy-ring {
  position:absolute; top:50%; left:50%; transform:translate(-50%,-50%);
  border-radius:50%; border:1px solid;
  animation:hy-ring-expand var(--ring-dur,4s) var(--ring-del,0s) ease-out infinite;
  opacity:0; z-index:8;
}
@keyframes hy-ring-expand {
  0%   { opacity:.7; }
  100% { opacity:0; transform:translate(-50%,-50%) scale(1.6); }
}

/* Floating thought bubbles around the disc */
.hy-thought {
  position:absolute; font-size:.75rem; font-weight:600; font-family:var(--hy-font-body);
  color:var(--hy-teal); background:rgba(11,12,26,.7); border:1px solid rgba(0,194,178,.3);
  padding:4px 10px; border-radius:20px; white-space:nowrap;
  animation:hy-thought-bob var(--tb-dur,5s) var(--tb-del,0s) ease-in-out infinite alternate;
  z-index:12;
}
@keyframes hy-thought-bob {
  from { transform:translateY(0); }
  to   { transform:translateY(-10px); }
}

/* ═══════════════════════════════════════════════════════════
   TRUST BAR
   ═══════════════════════════════════════════════════════════ */
.hy-trust-bar { background:var(--hy-violet-d); padding:20px 0; border-top:1px solid rgba(200,208,224,.1); border-bottom:1px solid rgba(200,208,224,.1); }
.hy-trust-bar__inner { display:flex; justify-content:space-around; flex-wrap:wrap; gap:20px; }
.hy-trust-bar__item { display:flex; align-items:center; gap:10px; color:var(--hy-mist); font-size:.9rem; }
.hy-trust-bar__item span:first-child { font-size:1.3rem; }
.hy-trust-bar__item strong { color:#fff; }

/* ═══════════════════════════════════════════════════════════
   SERVICES GRID
   ═══════════════════════════════════════════════════════════ */
.hy-services { text-align:center; }
.hy-services__intro { max-width:640px; margin:0 auto 60px; }
.hy-services__grid { display:grid; grid-template-columns:repeat(4,1fr); gap:24px; }
.hy-svc {
  background:#fff; border-radius:var(--hy-radius); padding:32px 20px; text-align:center;
  box-shadow:0 4px 20px rgba(0,0,0,.06); border:1px solid rgba(0,0,0,.05);
  transition:transform .25s,box-shadow .25s,border-color .25s;
}
.hy-svc:hover { transform:translateY(-6px); box-shadow:0 12px 36px rgba(61,26,120,.15); border-color:rgba(61,26,120,.2); }
.hy-svc__icon { font-size:2.2rem; margin-bottom:16px; }
.hy-svc__title { font-family:var(--hy-font-head); font-size:.95rem; margin-bottom:10px; color:var(--hy-violet); letter-spacing:.04em; }
.hy-svc__desc  { font-size:.88rem; line-height:1.65; color:#555; }

/* ═══════════════════════════════════════════════════════════
   CONDITIONS CLOUD
   ═══════════════════════════════════════════════════════════ */
.hy-conditions { text-align:center; }
.hy-conditions__intro { max-width:600px; margin:0 auto 48px; }
.hy-conditions__cloud { display:flex; flex-wrap:wrap; justify-content:center; gap:10px; }
.hy-cond-tag {
  display:inline-block; padding:8px 18px; border-radius:24px;
  background:rgba(61,26,120,.08); color:var(--hy-violet); font-size:.85rem; font-weight:600;
  border:1px solid rgba(61,26,120,.15); cursor:default;
  transition:background .2s,color .2s,border-color .2s;
}
.hy-cond-tag:hover { background:var(--hy-violet); color:#fff; border-color:var(--hy-violet); }

/* ═══════════════════════════════════════════════════════════
   ABOUT
   ═══════════════════════════════════════════════════════════ */
.hy-about { }
.hy-about__grid { display:grid; grid-template-columns:1fr 1fr; gap:80px; align-items:center; }
.hy-about__visual { display:flex; justify-content:center; }

/* Therapist portrait card */
.hy-portrait-card {
  width:320px; background:var(--hy-violet-d); border-radius:20px; overflow:hidden;
  box-shadow:0 16px 48px rgba(61,26,120,.4); border:1px solid rgba(200,208,224,.1);
}
.hy-portrait-card__header {
  background:linear-gradient(135deg,var(--hy-violet),var(--hy-ink));
  padding:36px 24px 24px; text-align:center;
}
/* CSS therapist figure */
.hy-therapist-fig { display:flex; flex-direction:column; align-items:center; gap:0; margin-bottom:12px; }
.hy-therapist-fig__head {
  width:64px; height:64px; border-radius:50%;
  background:radial-gradient(circle at 40% 35%,#d4b896,#c19a6b);
  border:3px solid rgba(200,208,224,.3);
  position:relative; margin-bottom:0;
}
.hy-therapist-fig__head::before {
  content:''; position:absolute; top:-10px; left:4px; right:4px; height:16px;
  background:linear-gradient(180deg,#2c1a0a,#4a2f18);
  border-radius:50% 50% 0 0;
}
.hy-therapist-fig__neck {
  width:16px; height:14px;
  background:linear-gradient(180deg,#c19a6b,#a07850);
}
.hy-therapist-fig__body {
  width:80px; height:70px; border-radius:8px 8px 0 0;
  background:linear-gradient(180deg,var(--hy-teal-d),#005e57);
  position:relative;
}
.hy-therapist-fig__body::before {
  content:''; position:absolute; top:12px; left:50%; transform:translateX(-50%);
  width:2px; height:40px; background:rgba(255,255,255,.2); border-radius:1px;
}
.hy-therapist-fig__body::after {
  content:'✦'; position:absolute; bottom:8px; left:50%; transform:translateX(-50%);
  color:rgba(255,255,255,.4); font-size:12px;
}
.hy-therapist-fig__legs {
  width:80px; height:40px;
  background:linear-gradient(180deg,#1a1a2e,#0d0d1a);
  border-radius:0 0 6px 6px;
}

.hy-portrait-card__header p { color:var(--hy-mist); font-size:.8rem; opacity:.8; }
.hy-portrait-card__header h3 { color:#fff; font-family:var(--hy-font-head); font-size:1rem; margin-bottom:2px; letter-spacing:.05em; }

.hy-portrait-card__body { padding:20px 24px; }
.hy-portrait-card__row { display:flex; justify-content:space-between; align-items:center; padding:8px 0; border-bottom:1px solid rgba(200,208,224,.08); font-size:.82rem; }
.hy-portrait-card__row:last-child { border-bottom:none; }
.hy-portrait-card__row span:first-child { color:var(--hy-mist); opacity:.7; }
.hy-portrait-card__row span:last-child  { color:var(--hy-teal); font-weight:700; }

.hy-about__text .hy-h2 { color:var(--hy-violet-d); }
.hy-about__text p { color:#444; margin-bottom:16px; line-height:1.8; }
.hy-qualifications { list-style:none; margin:24px 0 32px; display:flex; flex-direction:column; gap:10px; }
.hy-qualifications li { display:flex; align-items:center; gap:10px; font-size:.9rem; color:#333; }
.hy-qualifications li::before { content:'✦'; color:var(--hy-teal); flex-shrink:0; }

/* ═══════════════════════════════════════════════════════════
   APPROACH / PROCESS
   ═══════════════════════════════════════════════════════════ */
.hy-approach { background:var(--hy-ink); }
.hy-approach__intro { text-align:center; max-width:640px; margin:0 auto 60px; }
.hy-approach__grid {
  display:grid; grid-template-columns:repeat(5,1fr); gap:0;
  position:relative;
}
.hy-approach__grid::before {
  content:''; position:absolute; top:44px; left:10%; right:10%; height:2px;
  background:linear-gradient(90deg,var(--hy-violet),var(--hy-teal),var(--hy-violet));
  z-index:0;
}
.hy-step { text-align:center; padding:0 12px; position:relative; z-index:1; }
.hy-step__num {
  width:48px; height:48px; border-radius:50%;
  background:linear-gradient(135deg,var(--hy-violet),var(--hy-teal-d));
  color:#fff; font-family:var(--hy-font-head); font-size:.75rem;
  display:inline-flex; align-items:center; justify-content:center;
  margin-bottom:20px; box-shadow:0 0 20px rgba(0,194,178,.3);
  letter-spacing:.05em;
}
.hy-step__title { font-family:var(--hy-font-head); font-size:.85rem; color:#fff; margin-bottom:10px; letter-spacing:.04em; }
.hy-step__desc  { font-size:.82rem; color:var(--hy-mist); opacity:.8; line-height:1.6; }

/* ═══════════════════════════════════════════════════════════
   GALLERY
   ═══════════════════════════════════════════════════════════ */
.hy-gallery__grid {
  display:grid;
  grid-template-columns:repeat(3,1fr);
  grid-template-rows:220px 220px;
  gap:12px;
}
.hy-gallery__item { border-radius:var(--hy-radius); overflow:hidden; position:relative; cursor:pointer; }
.hy-gallery__item:nth-child(1) { grid-column:span 2; }
.hy-gallery__item:nth-child(5) { grid-column:span 2; }
.hy-gallery__panel { width:100%; height:100%; display:flex; align-items:center; justify-content:center; font-size:3rem; transition:transform .4s; }
.hy-gallery__item:hover .hy-gallery__panel { transform:scale(1.04); }
.hy-gallery__overlay {
  position:absolute; inset:0; display:flex; align-items:flex-end;
  background:linear-gradient(to top,rgba(0,0,0,.7) 0%,transparent 50%);
  padding:20px; opacity:0; transition:opacity .3s;
}
.hy-gallery__item:hover .hy-gallery__overlay { opacity:1; }
.hy-gallery__overlay span { color:#fff; font-size:.9rem; font-weight:600; }

/* ═══════════════════════════════════════════════════════════
   COUNTERS
   ═══════════════════════════════════════════════════════════ */
.hy-counters { background:linear-gradient(135deg,var(--hy-violet-d),var(--hy-ink)); text-align:center; }
.hy-counters__grid { display:grid; grid-template-columns:repeat(4,1fr); gap:40px; }
.hy-counter__val { font-family:var(--hy-font-head); font-size:clamp(2rem,4vw,3.2rem); color:var(--hy-teal); display:block; line-height:1; letter-spacing:.02em; }
.hy-counter__label { font-size:.85rem; color:var(--hy-mist); margin-top:8px; opacity:.8; }

/* ═══════════════════════════════════════════════════════════
   PACKAGES
   ═══════════════════════════════════════════════════════════ */
.hy-packages { text-align:center; }
.hy-packages__intro { max-width:600px; margin:0 auto 60px; }
.hy-packages__grid { display:grid; grid-template-columns:repeat(3,1fr); gap:24px; align-items:start; }
.hy-pkg {
  border-radius:var(--hy-radius); padding:36px 28px; text-align:center;
  background:#fff; box-shadow:0 4px 24px rgba(0,0,0,.08); border:2px solid transparent;
  transition:transform .25s,box-shadow .25s;
}
.hy-pkg:hover { transform:translateY(-6px); box-shadow:0 16px 48px rgba(61,26,120,.15); }
.hy-pkg--featured { border-color:var(--hy-teal); box-shadow:0 8px 40px rgba(0,194,178,.25); background:var(--hy-violet-d); color:var(--hy-mist); transform:translateY(-8px); }
.hy-pkg--featured:hover { transform:translateY(-14px); }
.hy-pkg__badge { display:inline-block; background:var(--hy-teal); color:#fff; font-size:.7rem; font-weight:700; letter-spacing:.1em; text-transform:uppercase; padding:3px 12px; border-radius:12px; margin-bottom:12px; }
.hy-pkg__name { font-family:var(--hy-font-head); font-size:1.1rem; margin-bottom:4px; letter-spacing:.05em; }
.hy-pkg--featured .hy-pkg__name { color:#fff; }
.hy-pkg__price { font-size:2.4rem; font-weight:700; margin:16px 0 4px; }
.hy-pkg--featured .hy-pkg__price { color:var(--hy-teal); }
.hy-pkg__per { font-size:.8rem; opacity:.65; margin-bottom:24px; }
.hy-pkg__features { list-style:none; text-align:left; margin-bottom:28px; display:flex; flex-direction:column; gap:10px; }
.hy-pkg__features li { display:flex; align-items:center; gap:8px; font-size:.88rem; }
.hy-pkg__features li::before { content:'✦'; color:var(--hy-teal); flex-shrink:0; }
.hy-pkg--featured .hy-pkg__features li { color:var(--hy-mist); }
.hy-pkg .hy-btn { width:100%; text-align:center; }

/* ═══════════════════════════════════════════════════════════
   TESTIMONIALS
   ═══════════════════════════════════════════════════════════ */
.hy-testimonials { }
.hy-testimonials__intro { text-align:center; max-width:600px; margin:0 auto 60px; }
.hy-testimonials__grid { display:grid; grid-template-columns:repeat(3,1fr); gap:24px; }
.hy-testi {
  background:#fff; border-radius:var(--hy-radius); padding:32px 28px;
  box-shadow:0 4px 24px rgba(0,0,0,.07); border-top:4px solid var(--hy-teal);
  position:relative;
}
.hy-testi::before {
  content:'❝'; position:absolute; top:20px; right:24px;
  font-size:3rem; color:rgba(61,26,120,.1); line-height:1; font-family:serif;
}
.hy-testi__stars { color:#f5a623; font-size:1rem; margin-bottom:16px; }
.hy-testi__text { font-size:.92rem; line-height:1.75; color:#444; margin-bottom:20px; font-style:italic; }
.hy-testi__name { font-weight:700; color:var(--hy-violet); font-size:.9rem; }
.hy-testi__role { font-size:.8rem; color:#888; }

/* ═══════════════════════════════════════════════════════════
   BOOKING FORM
   ═══════════════════════════════════════════════════════════ */
.hy-booking { background:var(--hy-ink); }
.hy-booking__inner { display:grid; grid-template-columns:1fr 1fr; gap:80px; align-items:start; }
.hy-booking__info h2 { color:#fff; margin-bottom:16px; }
.hy-booking__info p  { color:var(--hy-mist); opacity:.8; margin-bottom:32px; line-height:1.8; }
.hy-booking__features { list-style:none; display:flex; flex-direction:column; gap:14px; }
.hy-booking__features li { display:flex; align-items:center; gap:12px; color:var(--hy-mist); font-size:.9rem; }
.hy-booking__features li span:first-child { width:32px; height:32px; background:rgba(0,194,178,.15); border:1px solid rgba(0,194,178,.3); border-radius:50%; display:inline-flex; align-items:center; justify-content:center; flex-shrink:0; font-size:1rem; }
.hy-form { background:rgba(255,255,255,.04); border:1px solid rgba(200,208,224,.1); border-radius:16px; padding:36px; }
.hy-form__row { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
.hy-form__group { margin-bottom:16px; }
.hy-form__group label { display:block; font-size:.82rem; font-weight:600; color:var(--hy-mist); margin-bottom:6px; letter-spacing:.04em; }
.hy-form__group input,
.hy-form__group select,
.hy-form__group textarea {
  width:100%; padding:12px 16px; border-radius:8px;
  border:1px solid rgba(200,208,224,.15); background:rgba(255,255,255,.05);
  color:#fff; font-family:var(--hy-font-body); font-size:.9rem;
  transition:border-color .2s;
}
.hy-form__group input::placeholder,
.hy-form__group textarea::placeholder { color:rgba(200,208,224,.4); }
.hy-form__group input:focus,
.hy-form__group select:focus,
.hy-form__group textarea:focus { outline:none; border-color:var(--hy-teal); }
.hy-form__group select option { background:#1a0a3d; color:#fff; }
.hy-form__group textarea { resize:vertical; min-height:100px; }
.hy-form__submit { width:100%; padding:16px; background:linear-gradient(135deg,var(--hy-teal),var(--hy-teal-d)); color:#fff; font-family:var(--hy-font-body); font-size:1rem; font-weight:700; letter-spacing:.05em; border:none; border-radius:10px; cursor:pointer; transition:transform .2s,box-shadow .2s; margin-top:8px; }
.hy-form__submit:hover { transform:translateY(-2px); box-shadow:0 8px 24px rgba(0,194,178,.4); }

/* ═══════════════════════════════════════════════════════════
   FOOTER
   ═══════════════════════════════════════════════════════════ */
.hy-footer { background:var(--hy-violet-d); padding:32px 0; text-align:center; border-top:1px solid rgba(200,208,224,.08); }
.hy-footer p { color:var(--hy-mist); font-size:.85rem; opacity:.7; }

/* ═══════════════════════════════════════════════════════════
   RESPONSIVE
   ═══════════════════════════════════════════════════════════ */
@media(max-width:1024px){
  .hy-hero__inner { grid-template-columns:1fr; gap:40px; padding:100px 0 60px; }
  .hy-disc-wrap { width:320px; height:320px; }
  .hy-ball { width:180px; height:180px; }
  .hy-services__grid { grid-template-columns:repeat(2,1fr); }
  .hy-about__grid { grid-template-columns:1fr; }
  .hy-approach__grid { grid-template-columns:repeat(3,1fr); }
  .hy-approach__grid::before { display:none; }
  .hy-counters__grid { grid-template-columns:repeat(2,1fr); }
  .hy-packages__grid { grid-template-columns:1fr; }
  .hy-testimonials__grid { grid-template-columns:1fr; }
  .hy-booking__inner { grid-template-columns:1fr; }
}
@media(max-width:640px){
  .hy-section { padding:64px 0; }
  .hy-services__grid { grid-template-columns:1fr; }
  .hy-approach__grid { grid-template-columns:1fr 1fr; }
  .hy-gallery__grid { grid-template-columns:1fr 1fr; grid-template-rows:auto; }
  .hy-gallery__item:nth-child(1),
  .hy-gallery__item:nth-child(5) { grid-column:span 1; }
  .hy-counters__grid { grid-template-columns:1fr 1fr; }
  .hy-form__row { grid-template-columns:1fr; }
  .hy-hero__ctas { flex-direction:column; }
  .hy-hero__trust { flex-direction:column; gap:12px; }
  .hy-disc-wrap { width:260px; height:260px; }
  .hy-ball { width:140px; height:140px; }
}
</style>
<?php get_header(); ?>
<div class="hy-page">
>
<?php wp_body_open(); ?>
<div class="hy-wrap">

<!-- ═══════════════ HERO ═══════════════ -->
<section class="hy-hero" aria-label="Hypnotherapy practice hero">

  <!-- Floating orb particles -->
  <?php foreach ($orbs as $i => $orb): ?>
  <div class="hy-orb" aria-hidden="true" style="
    top:<?= $orb['top'] ?>%;
    left:<?= $orb['left'] ?>%;
    width:<?= $orb['size'] ?>px;
    height:<?= $orb['size'] ?>px;
    background:radial-gradient(circle,<?= esc_attr($orb['col']) ?>,transparent);
    --dur:<?= $orb['dur'] ?>s;
    --del:<?= $orb['delay'] ?>s;
  "></div>
  <?php endforeach; ?>

  <div class="hy-container">
    <div class="hy-hero__inner">

      <!-- Content -->
      <div class="hy-hero__content">
        <div class="hy-hero__badge" aria-label="GHR Registered Hypnotherapist">
          <span>✦</span> GHR Registered Hypnotherapist
        </div>
        <h1 class="hy-h1 hy-hero__title">
          Transform Your Mind.<br>
          <span style="color:var(--hy-teal);">Reclaim Your Life.</span>
        </h1>
        <p class="hy-hero__sub">
          Evidence-based clinical hypnotherapy for anxiety, phobias, smoking cessation, sleep disorders and lasting behavioural change — in-person &amp; online.
        </p>
        <div class="hy-hero__ctas">
          <a href="#booking" class="hy-btn hy-btn--primary">Book a Free Consultation</a>
          <a href="#services" class="hy-btn hy-btn--ghost">Explore Treatments</a>
        </div>
        <div class="hy-hero__trust">
          <div class="hy-hero__trust-item"><span>🏅</span><span>GHR &amp; GHSC Registered</span></div>
          <div class="hy-hero__trust-item"><span>🔒</span><span>Fully Insured</span></div>
          <div class="hy-hero__trust-item"><span>📋</span><span>Free Discovery Call</span></div>
        </div>
      </div>

      <!-- Scene: Hypnotic Crystal Ball -->
      <div class="hy-hero__scene" aria-hidden="true">
        <div class="hy-disc-wrap">

          <!-- Concentric expanding rings -->
          <?php for ($r = 0; $r < 5; $r++):
            $rsize = 120 + $r * 50;
            $rcol  = ($r % 2 === 0) ? 'rgba(0,194,178,0.35)' : 'rgba(61,26,120,0.4)';
          ?>
          <div class="hy-ring" style="
            width:<?= $rsize ?>px; height:<?= $rsize ?>px;
            border-color:<?= $rcol ?>;
            --ring-dur:<?= (3 + $r * 0.8) ?>s;
            --ring-del:<?= ($r * 0.6) ?>s;
          "></div>
          <?php endfor; ?>

          <!-- Crystal ball -->
          <div class="hy-ball">
            <div class="hy-ball__spiral">
              <div class="hy-spiral-disc"></div>
            </div>
          </div>

          <!-- Ball base -->
          <div class="hy-ball-base"></div>

          <!-- Orbiting crystal sparks -->
          <?php foreach ($crystal_sparks as $s): ?>
          <div class="hy-spark" style="
            --spark-ang:<?= $s['ang'] ?>deg;
            --spark-dist:<?= $s['dist'] ?>px;
            --spark-dur:<?= (5 + $s['delay'] * 1.5) ?>s;
            --spark-del:<?= ($s['delay'] * -1) ?>s;
            font-size:<?= $s['size'] ?>px;
          "><?= esc_html($s['sym']) ?></div>
          <?php endforeach; ?>

          <!-- Floating thought labels -->
          <div class="hy-thought" style="top:8%;left:58%;--tb-dur:5s;--tb-del:0s;">Calm</div>
          <div class="hy-thought" style="top:20%;left:5%;--tb-dur:6s;--tb-del:1s;">Focus</div>
          <div class="hy-thought" style="bottom:22%;left:60%;--tb-dur:7s;--tb-del:2s;">Clarity</div>
          <div class="hy-thought" style="bottom:10%;left:5%;--tb-dur:5.5s;--tb-del:0.5s;">Peace</div>

        </div>
      </div>

    </div>
  </div>
</section>

<!-- ═══════════════ TRUST BAR ═══════════════ -->
<div class="hy-trust-bar" aria-label="Credentials and trust indicators">
  <div class="hy-container">
    <div class="hy-trust-bar__inner">
      <div class="hy-trust-bar__item"><span>🎓</span><span><strong>DSFH Qualified</strong> — Diploma in Solution-Focused Hypnotherapy</span></div>
      <div class="hy-trust-bar__item"><span>🏥</span><span><strong>NHS Referral</strong> Accepted</span></div>
      <div class="hy-trust-bar__item"><span>🌐</span><span>In-Person &amp; <strong>Secure Online</strong> Sessions</span></div>
      <div class="hy-trust-bar__item"><span>📞</span><span><strong>Free</strong> 20-Min Discovery Call</span></div>
    </div>
  </div>
</div>

<!-- ═══════════════ SERVICES ═══════════════ -->
<section class="hy-section hy-services" id="services" aria-labelledby="hy-svc-heading">
  <div class="hy-container">
    <div class="hy-services__intro">
      <span class="hy-tag">What We Treat</span>
      <h2 class="hy-h2" id="hy-svc-heading">Specialist Treatment Areas</h2>
      <p class="hy-lead">Clinical hypnotherapy combined with NLP, CBT and solution-focused techniques for profound, lasting transformation.</p>
    </div>
    <div class="hy-services__grid">
      <?php foreach ($services as $svc): ?>
      <article class="hy-svc" role="listitem">
        <div class="hy-svc__icon" aria-hidden="true"><?= $svc['icon'] ?></div>
        <h3 class="hy-svc__title"><?= esc_html($svc['title']) ?></h3>
        <p class="hy-svc__desc"><?= esc_html($svc['desc']) ?></p>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ CONDITIONS CLOUD ═══════════════ -->
<section class="hy-section hy-section--ivory hy-conditions" aria-labelledby="hy-cond-heading">
  <div class="hy-container">
    <div class="hy-conditions__intro">
      <span class="hy-tag">Presenting Issues</span>
      <h2 class="hy-h2" id="hy-cond-heading">Conditions I Work With</h2>
      <p class="hy-lead">From acute phobias to chronic stress, hypnotherapy provides safe and effective relief across a broad spectrum of presenting issues.</p>
    </div>
    <div class="hy-conditions__cloud" role="list" aria-label="Treatable conditions">
      <?php foreach ($conditions as $cond): ?>
      <span class="hy-cond-tag" role="listitem"><?= esc_html($cond) ?></span>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ ABOUT ═══════════════ -->
<section class="hy-section hy-about" id="about" aria-labelledby="hy-about-heading">
  <div class="hy-container">
    <div class="hy-about__grid">

      <div class="hy-about__visual">
        <div class="hy-portrait-card" role="img" aria-label="Therapist credential card for Dr. Eleanor Shaw">
          <div class="hy-portrait-card__header">
            <!-- CSS Therapist Figure -->
            <div class="hy-therapist-fig" aria-hidden="true">
              <div class="hy-therapist-fig__head"></div>
              <div class="hy-therapist-fig__neck"></div>
              <div class="hy-therapist-fig__body"></div>
              <div class="hy-therapist-fig__legs"></div>
            </div>
            <h3>Eleanor Shaw DSFH</h3>
            <p>Clinical Hypnotherapist &amp; NLP Practitioner</p>
          </div>
          <div class="hy-portrait-card__body">
            <div class="hy-portrait-card__row">
              <span>Qualification</span>
              <span>DSFH (Bath)</span>
            </div>
            <div class="hy-portrait-card__row">
              <span>Registration</span>
              <span>GHR &amp; GHSC</span>
            </div>
            <div class="hy-portrait-card__row">
              <span>Training</span>
              <span>CPHT Certified</span>
            </div>
            <div class="hy-portrait-card__row">
              <span>Specialism</span>
              <span>Anxiety &amp; Trauma</span>
            </div>
            <div class="hy-portrait-card__row">
              <span>Experience</span>
              <span>14 Years</span>
            </div>
          </div>
        </div>
      </div>

      <div class="hy-about__text">
        <span class="hy-tag">About Your Therapist</span>
        <h2 class="hy-h2" id="hy-about-heading">Trained to Create Real Change</h2>
        <p>I am Eleanor Shaw, a diploma-qualified and GHR-registered clinical hypnotherapist with 14 years of specialist practice. My approach combines solution-focused hypnotherapy with neuroscience-informed techniques that speak directly to the part of your brain responsible for anxiety, habit and automatic behaviour.</p>
        <p>I trained at the prestigious Centre of Excellence for Hypnotherapy Training (CPHT) and hold additional qualifications in NLP, Cognitive Behavioural Hypnotherapy and trauma-informed care. Every session is completely bespoke — there are no scripts, no generic recordings, no one-size-fits-all approaches.</p>
        <ul class="hy-qualifications" aria-label="Professional qualifications">
          <li>Diploma in Solution-Focused Hypnotherapy (DSFH)</li>
          <li>Registered with GHR &amp; GHSC (professional bodies)</li>
          <li>NLP Master Practitioner — Society of NLP</li>
          <li>Trauma-Informed Hypnotherapy Certificate</li>
          <li>Cognitive Behavioural Hypnotherapy (CBH)</li>
          <li>Fully insured — £5 million public liability</li>
        </ul>
        <a href="#booking" class="hy-btn hy-btn--primary">Book Your Free Call</a>
      </div>

    </div>
  </div>
</section>

<!-- ═══════════════ APPROACH ═══════════════ -->
<section class="hy-section hy-approach" aria-labelledby="hy-approach-heading">
  <div class="hy-container">
    <div class="hy-approach__intro">
      <span class="hy-tag hy-tag--light">The Process</span>
      <h2 class="hy-h2" id="hy-approach-heading" style="color:#fff;">How Your Transformation Unfolds</h2>
      <p class="hy-lead" style="color:var(--hy-mist);margin:0 auto;">A structured, evidence-based process designed to create deep, sustainable change at the subconscious level.</p>
    </div>
    <div class="hy-approach__grid" role="list">
      <?php foreach ($steps as $step): ?>
      <div class="hy-step" role="listitem">
        <div class="hy-step__num" aria-hidden="true"><?= esc_html($step['num']) ?></div>
        <h3 class="hy-step__title"><?= esc_html($step['title']) ?></h3>
        <p class="hy-step__desc"><?= esc_html($step['desc']) ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ GALLERY ═══════════════ -->
<section class="hy-section hy-section--ivory" aria-labelledby="hy-gallery-heading">
  <div class="hy-container">
    <div style="text-align:center;margin-bottom:48px;">
      <span class="hy-tag">Inside the Practice</span>
      <h2 class="hy-h2" id="hy-gallery-heading">The Healing Space</h2>
    </div>
    <div class="hy-gallery__grid" role="list">
      <?php foreach ($gallery as $panel): ?>
      <div class="hy-gallery__item" role="listitem">
        <div class="hy-gallery__panel" style="background:<?= esc_attr($panel['color']) ?>;"
             aria-label="<?= esc_attr($panel['label']) ?> image">
          <span aria-hidden="true" style="font-size:3.5rem;"><?= $panel['icon'] ?></span>
        </div>
        <div class="hy-gallery__overlay" aria-hidden="true">
          <span><?= esc_html($panel['label']) ?></span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ COUNTERS ═══════════════ -->
<section class="hy-section hy-counters" aria-labelledby="hy-counters-heading">
  <div class="hy-container">
    <h2 class="hy-h2 sr-only" id="hy-counters-heading">Practice statistics</h2>
    <div class="hy-counters__grid">
      <?php foreach ($counters as $c): ?>
      <div class="hy-counter-item">
        <span class="hy-counter__val"
              data-target="<?= esc_attr($c['val']) ?>"
              data-suffix="<?= esc_attr($c['suffix']) ?>"
              <?= $c['float'] ? 'data-float="1"' : '' ?>
              aria-label="<?= esc_attr($c['val'] . $c['suffix'] . ' ' . $c['label']) ?>">
          0
        </span>
        <p class="hy-counter__label"><?= esc_html($c['label']) ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ PACKAGES ═══════════════ -->
<section class="hy-section hy-packages" id="packages" aria-labelledby="hy-pkg-heading">
  <div class="hy-container">
    <div class="hy-packages__intro">
      <span class="hy-tag">Investment</span>
      <h2 class="hy-h2" id="hy-pkg-heading">Choose Your Programme</h2>
      <p class="hy-lead" style="margin:0 auto;">Transparent pricing with no hidden fees. Every package includes a personalised induction and follow-up support.</p>
    </div>
    <div class="hy-packages__grid">
      <?php foreach ($packages as $pkg): ?>
      <div class="hy-pkg <?= $pkg['featured'] ? 'hy-pkg--featured' : '' ?>">
        <?php if ($pkg['featured']): ?><div class="hy-pkg__badge">Most Popular</div><?php endif; ?>
        <h3 class="hy-pkg__name"><?= esc_html($pkg['name']) ?></h3>
        <div class="hy-pkg__price"><?= esc_html($pkg['price']) ?></div>
        <div class="hy-pkg__per"><?= esc_html($pkg['per']) ?></div>
        <ul class="hy-pkg__features" aria-label="<?= esc_attr($pkg['name']) ?> package features">
          <?php foreach ($pkg['features'] as $f): ?>
          <li><?= esc_html($f) ?></li>
          <?php endforeach; ?>
        </ul>
        <a href="#booking" class="hy-btn <?= $pkg['featured'] ? 'hy-btn--primary' : 'hy-btn--ghost' ?>"
           aria-label="Book the <?= esc_attr($pkg['name']) ?> package">
          Book <?= esc_html($pkg['name']) ?>
        </a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ TESTIMONIALS ═══════════════ -->
<section class="hy-section hy-section--ivory hy-testimonials" aria-labelledby="hy-testi-heading">
  <div class="hy-container">
    <div class="hy-testimonials__intro">
      <span class="hy-tag">Client Stories</span>
      <h2 class="hy-h2" id="hy-testi-heading">Lives Transformed</h2>
      <p class="hy-lead" style="margin:0 auto;">Real outcomes from real people. Names are used with permission and shared to inspire others.</p>
    </div>
    <div class="hy-testimonials__grid">
      <?php foreach ($testimonials as $t): ?>
      <blockquote class="hy-testi">
        <div class="hy-testi__stars" aria-label="<?= esc_attr($t['rating']) ?> out of 5 stars">
          <?= str_repeat('★', $t['rating']) ?>
        </div>
        <p class="hy-testi__text"><?= esc_html($t['text']) ?></p>
        <footer>
          <div class="hy-testi__name"><?= esc_html($t['name']) ?></div>
          <div class="hy-testi__role"><?= esc_html($t['role']) ?></div>
        </footer>
      </blockquote>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ BOOKING ═══════════════ -->
<section class="hy-section hy-booking" id="booking" aria-labelledby="hy-booking-heading">
  <div class="hy-container">
    <div class="hy-booking__inner">

      <div class="hy-booking__info">
        <span class="hy-tag hy-tag--light">Get Started</span>
        <h2 class="hy-h2" id="hy-booking-heading">Begin Your Transformation</h2>
        <p>Take the first step towards lasting change. Book your complimentary discovery call and we will talk through your goals, answer your questions and explore whether hypnotherapy is right for you — completely free and without obligation.</p>
        <ul class="hy-booking__features" aria-label="Booking benefits">
          <li><span aria-hidden="true">📞</span><span>Free 20-minute discovery call — no commitment</span></li>
          <li><span aria-hidden="true">🔒</span><span>Strictly confidential — bound by professional ethics</span></li>
          <li><span aria-hidden="true">📅</span><span>Flexible scheduling including evenings and weekends</span></li>
          <li><span aria-hidden="true">💻</span><span>In-person in the clinic or secure video call</span></li>
          <li><span aria-hidden="true">💳</span><span>Payment plans available for longer programmes</span></li>
        </ul>
      </div>

      <div class="hy-form" role="form" aria-label="Booking enquiry form">
        <?php
          if (!empty($_POST['tf_hy_nonce']) && wp_verify_nonce($_POST['tf_hy_nonce'], 'tf_hy_booking')) {
            echo '<p style="color:var(--hy-teal);font-weight:700;margin-bottom:16px;">✦ Thank you — we\'ll be in touch very shortly!</p>';
          }
        ?>
        <form method="post" action="<?php echo esc_url(get_permalink()); ?>#booking" novalidate>
          <?php wp_nonce_field('tf_hy_booking','tf_hy_nonce'); ?>
          <div class="hy-form__row">
            <div class="hy-form__group">
              <label for="hy_name">Full Name <span aria-hidden="true" style="color:var(--hy-teal)">*</span></label>
              <input type="text" id="hy_name" name="hy_name" placeholder="Your full name" required autocomplete="name">
            </div>
            <div class="hy-form__group">
              <label for="hy_email">Email Address <span aria-hidden="true" style="color:var(--hy-teal)">*</span></label>
              <input type="email" id="hy_email" name="hy_email" placeholder="you@example.com" required autocomplete="email">
            </div>
          </div>
          <div class="hy-form__row">
            <div class="hy-form__group">
              <label for="hy_phone">Phone Number</label>
              <input type="tel" id="hy_phone" name="hy_phone" placeholder="+44 7700 900000" autocomplete="tel">
            </div>
            <div class="hy-form__group">
              <label for="hy_format">Session Format</label>
              <select id="hy_format" name="hy_format">
                <option value="">Prefer not to say</option>
                <option value="in-person">In-Person (Clinic)</option>
                <option value="online">Online (Video Call)</option>
                <option value="either">Either / No Preference</option>
              </select>
            </div>
          </div>
          <div class="hy-form__group">
            <label for="hy_concern">Primary Concern <span aria-hidden="true" style="color:var(--hy-teal)">*</span></label>
            <select id="hy_concern" name="hy_concern" required>
              <option value="">Please select&hellip;</option>
              <option value="anxiety">Anxiety / Panic Attacks</option>
              <option value="smoking">Stop Smoking</option>
              <option value="sleep">Sleep Problems / Insomnia</option>
              <option value="phobia">Phobia / Fear</option>
              <option value="weight">Weight &amp; Habits</option>
              <option value="performance">Performance / Confidence</option>
              <option value="trauma">Trauma / PTSD</option>
              <option value="other">Other — I will explain below</option>
            </select>
          </div>
          <div class="hy-form__group">
            <label for="hy_experience">Previous Hypnotherapy Experience?</label>
            <select id="hy_experience" name="hy_experience">
              <option value="none">No — this is my first time</option>
              <option value="some">Yes — some experience</option>
              <option value="regular">Yes — I practise regularly</option>
            </select>
          </div>
          <div class="hy-form__group">
            <label for="hy_message">Tell me a little about what you would like to achieve</label>
            <textarea id="hy_message" name="hy_message" placeholder="Briefly describe your goals and any relevant background…"></textarea>
          </div>
          <button type="submit" class="hy-form__submit">✦ Book My Free Discovery Call</button>
        </form>
      </div>

    </div>
  </div>
</section>

<!-- ═══════════════ FOOTER ═══════════════ -->
<footer class="hy-footer" role="contentinfo">
  <div class="hy-container">
    <p>&copy; <?php echo esc_html(date('Y')); ?> <?php bloginfo('name'); ?> &mdash; Clinical Hypnotherapy &amp; NLP. GHR &amp; GHSC Registered. All rights reserved.</p>
  </div>
</footer>

</div><!-- /.hy-wrap -->

<script>
(function(){
  'use strict';

  /* ── Animated counters ───────────────────────────────── */
  var easeOut = function(t){ return 1 - Math.pow(1 - t, 3); };
  var counters = document.querySelectorAll('.hy-counter__val[data-target]');

  if ('IntersectionObserver' in window) {
    var obs = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if (!entry.isIntersecting) return;
        obs.unobserve(entry.target);
        var el     = entry.target;
        var target = parseFloat(el.dataset.target);
        var suffix = el.dataset.suffix || '';
        var isFloat= el.dataset.float === '1';
        if (isNaN(target)) return;
        var duration = 1800;
        var start    = null;
        function tick(ts){
          if (!start) start = ts;
          var progress = Math.min((ts - start) / duration, 1);
          var eased    = easeOut(progress);
          var val      = target * eased;
          el.textContent = (isFloat ? val.toFixed(1) : Math.floor(val)) + suffix;
          if (progress < 1) requestAnimationFrame(tick);
          else el.textContent = (isFloat ? target.toFixed(1) : target) + suffix;
        }
        requestAnimationFrame(tick);
      });
    }, { threshold: 0.4 });
    counters.forEach(function(el){ obs.observe(el); });
  } else {
    counters.forEach(function(el){
      el.textContent = el.dataset.target + (el.dataset.suffix || '');
    });
  }

  /* ── Mouse parallax on orbs ─────────────────────────── */
  var orbs = document.querySelectorAll('.hy-orb');
  var hero = document.querySelector('.hy-hero');
  if (hero) {
    hero.addEventListener('mousemove', function(e){
      var rect = hero.getBoundingClientRect();
      var dx = (e.clientX - rect.left - rect.width / 2) / rect.width;
      var dy = (e.clientY - rect.top - rect.height / 2) / rect.height;
      orbs.forEach(function(orb, idx){
        var depth = (idx % 4 + 1) * 6;
        orb.style.transform = 'translate(' + (dx * depth) + 'px, ' + (dy * depth) + 'px)';
      });
    });
  }

})();
</script>

</body>
</html>
</div><!-- .hy-page -->
<?php get_footer(); ?>
