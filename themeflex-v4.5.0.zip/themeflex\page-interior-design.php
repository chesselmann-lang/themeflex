<?php
/**
 * Template Name: Interior Design Studio Homepage
 * Template Post Type: page
 *
 * Premium Interior Design Studio template — Maison Collective
 * Namespace: --id-*  |  Fonts: Cormorant Garamond + Jost
 * Palette: Ivory #FAF8F5 / Charcoal #1E1E1E / Blush #D4A5A5 / Sage #8A9E85 / Gold #C9A96E
 */
defined('ABSPATH') || exit;
get_header();

/* ── Deterministic per-page randomness ──────────────────────────── */
srand(crc32('maison-collective-id'));
$id_swatches = ['#D4A5A5','#8A9E85','#C9A96E','#B8C4BE','#E8D5C4','#9BA7B0','#C4B5A5','#A8B89A'];
$id_palette  = ['Blush','Sage','Gold','Dusty Teal','Sand','Steel','Taupe','Fern'];

/* ── Hero scene color blocks ────────────────────────────────────── */
$id_shelf_books = [];
$id_book_cols   = ['#C9A96E','#8A9E85','#D4A5A5','#B8C4BE','#E8D5C4','#9BA7B0','#C4B5A5','#A8B89A','#D9C5B2','#7A9488'];
for ($i = 0; $i < 14; $i++) {
    $id_shelf_books[] = [
        'color'  => $id_book_cols[$i % count($id_book_cols)],
        'height' => rand(28, 48),
        'width'  => rand(12, 20),
    ];
}
?>
<!-- ══════════════════════════════════════════════════════════════
     GOOGLE FONTS
══════════════════════════════════════════════════════════════ -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=Jost:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>
/* ════════════════════════════════════════════════════════════════
   CSS CUSTOM PROPERTIES — --id-* namespace
════════════════════════════════════════════════════════════════ */
:root {
  --id-ivory:     #FAF8F5;
  --id-charcoal:  #1E1E1E;
  --id-blush:     #D4A5A5;
  --id-sage:      #8A9E85;
  --id-gold:      #C9A96E;
  --id-taupe:     #C4B5A5;
  --id-sand:      #E8D5C4;
  --id-stone:     #9B9589;
  --id-light:     #F3F0EB;
  --id-serif:     'Cormorant Garamond', Georgia, serif;
  --id-sans:      'Jost', system-ui, sans-serif;
  --id-r:         0.5rem;
  --id-r-lg:      1rem;
  --id-shadow:    0 4px 24px rgba(30,30,30,.08);
  --id-shadow-lg: 0 12px 48px rgba(30,30,30,.12);
  --id-trans:     all .35s cubic-bezier(.4,0,.2,1);
}

/* ════════════════════════════════════════════════════════════════
   BASE RESET
════════════════════════════════════════════════════════════════ */
.id-page *, .id-page *::before, .id-page *::after { box-sizing: border-box; margin: 0; padding: 0; }
.id-page { font-family: var(--id-sans); color: var(--id-charcoal); background: var(--id-ivory); overflow-x: hidden; }
.id-page img { max-width: 100%; height: auto; display: block; }
.id-page a { color: inherit; text-decoration: none; }
.id-page button { cursor: pointer; border: none; background: none; font-family: inherit; }

/* ════════════════════════════════════════════════════════════════
   LAYOUT HELPERS
════════════════════════════════════════════════════════════════ */
.id-wrap { max-width: 1200px; margin: 0 auto; padding: 0 2rem; }
.id-wrap--wide { max-width: 1400px; margin: 0 auto; padding: 0 2rem; }
.id-section { padding: 6rem 0; }
.id-section--alt { background: var(--id-light); }
.id-section--dark { background: var(--id-charcoal); color: var(--id-ivory); }
.id-section--sand { background: var(--id-sand); }

.id-eyebrow {
  font-family: var(--id-sans);
  font-size: .7rem;
  font-weight: 600;
  letter-spacing: .25em;
  text-transform: uppercase;
  color: var(--id-gold);
  margin-bottom: .75rem;
}
.id-h1 { font-family: var(--id-serif); font-size: clamp(3rem,6vw,5.5rem); font-weight: 300; line-height: 1.1; letter-spacing: -.01em; }
.id-h2 { font-family: var(--id-serif); font-size: clamp(2rem,4vw,3.5rem); font-weight: 300; line-height: 1.2; }
.id-h3 { font-family: var(--id-serif); font-size: 1.6rem; font-weight: 400; }
.id-lead { font-size: 1.1rem; font-weight: 300; line-height: 1.8; color: var(--id-stone); max-width: 56ch; }

.id-btn {
  display: inline-flex; align-items: center; gap: .5rem;
  padding: .85rem 2.2rem;
  font-family: var(--id-sans); font-size: .8rem; font-weight: 600;
  letter-spacing: .12em; text-transform: uppercase;
  border-radius: 0;
  transition: var(--id-trans);
}
.id-btn--primary { background: var(--id-charcoal); color: var(--id-ivory); }
.id-btn--primary:hover { background: var(--id-gold); color: var(--id-charcoal); }
.id-btn--outline { border: 1px solid var(--id-charcoal); color: var(--id-charcoal); }
.id-btn--outline:hover { background: var(--id-charcoal); color: var(--id-ivory); }
.id-btn--ghost { border: 1px solid rgba(250,248,245,.4); color: var(--id-ivory); }
.id-btn--ghost:hover { background: var(--id-ivory); color: var(--id-charcoal); }

/* reveal animation */
.id-reveal { opacity: 0; transform: translateY(24px); transition: opacity .7s ease, transform .7s ease; }
.id-reveal.id-visible { opacity: 1; transform: none; }

/* ════════════════════════════════════════════════════════════════
   NAV
════════════════════════════════════════════════════════════════ */
.id-nav {
  position: fixed; top: 0; left: 0; right: 0; z-index: 100;
  display: flex; align-items: center; justify-content: space-between;
  padding: 1.4rem 3rem;
  background: rgba(250,248,245,.92);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid rgba(30,30,30,.08);
  transition: var(--id-trans);
}
.id-nav__logo {
  font-family: var(--id-serif); font-size: 1.5rem; font-weight: 600;
  letter-spacing: .05em; color: var(--id-charcoal);
}
.id-nav__logo span { color: var(--id-gold); }
.id-nav__links { display: flex; gap: 2.5rem; list-style: none; }
.id-nav__links a {
  font-size: .78rem; font-weight: 500; letter-spacing: .1em; text-transform: uppercase;
  color: var(--id-stone); transition: color .25s;
}
.id-nav__links a:hover { color: var(--id-charcoal); }
.id-nav__cta {
  font-family: var(--id-sans); font-size: .75rem; font-weight: 600;
  letter-spacing: .1em; text-transform: uppercase;
  padding: .65rem 1.6rem;
  background: var(--id-charcoal); color: var(--id-ivory);
  transition: var(--id-trans);
}
.id-nav__cta:hover { background: var(--id-gold); color: var(--id-charcoal); }

/* ════════════════════════════════════════════════════════════════
   HERO
════════════════════════════════════════════════════════════════ */
.id-hero {
  min-height: 100vh;
  display: grid;
  grid-template-columns: 1fr 1fr;
  padding-top: 80px;
  background: var(--id-ivory);
  position: relative;
  overflow: hidden;
}

/* left content panel */
.id-hero__left {
  display: flex; flex-direction: column; justify-content: center;
  padding: 5rem 4rem 5rem 5rem;
  position: relative; z-index: 2;
}
.id-hero__left .id-eyebrow { margin-bottom: 1.5rem; }
.id-hero__left .id-h1 { margin-bottom: 1.5rem; }
.id-hero__left .id-lead { margin-bottom: 2.5rem; }
.id-hero__actions { display: flex; gap: 1rem; flex-wrap: wrap; }

/* award/press tags */
.id-hero__press {
  display: flex; gap: 1.5rem; align-items: center;
  margin-top: 3rem;
  padding-top: 2rem;
  border-top: 1px solid rgba(30,30,30,.1);
}
.id-hero__press-label { font-size: .7rem; letter-spacing: .15em; text-transform: uppercase; color: var(--id-stone); }
.id-hero__press-items { display: flex; gap: 1.5rem; }
.id-hero__press-item {
  font-family: var(--id-serif); font-size: .95rem; font-style: italic;
  color: var(--id-stone);
}

/* right: CSS studio scene */
.id-hero__right {
  position: relative;
  background: linear-gradient(160deg, #F0EBE3 0%, #E8E0D5 50%, #DDD5C8 100%);
  overflow: hidden;
}

/* room floor */
.id-room { position: absolute; inset: 0; }
.id-room__floor {
  position: absolute; bottom: 0; left: 0; right: 0; height: 38%;
  background: linear-gradient(180deg, #D8CFC4 0%, #C8BFB3 100%);
}
.id-room__floor::before {
  content: '';
  position: absolute; inset: 0;
  background: repeating-linear-gradient(
    90deg,
    transparent 0, transparent 59px,
    rgba(30,30,30,.06) 59px, rgba(30,30,30,.06) 60px
  ),
  repeating-linear-gradient(
    0deg,
    transparent 0, transparent 29px,
    rgba(30,30,30,.04) 29px, rgba(30,30,30,.04) 30px
  );
}
/* wall */
.id-room__wall {
  position: absolute; top: 0; left: 0; right: 0; height: 62%;
  background: linear-gradient(160deg, #F0EBE3 0%, #EAE3D9 100%);
}
.id-room__wall::after {
  content: '';
  position: absolute; bottom: 0; left: 0; right: 0; height: 3px;
  background: linear-gradient(90deg, transparent, rgba(30,30,30,.12), transparent);
}

/* large framed artwork on wall */
.id-room__art {
  position: absolute; top: 10%; right: 8%; width: 160px; height: 120px;
  background: linear-gradient(135deg, #B8C4BE 0%, #8A9E85 40%, #C9A96E 70%, #D4A5A5 100%);
  border: 8px solid #FAF8F5;
  box-shadow: 0 2px 16px rgba(30,30,30,.18), inset 0 0 0 1px rgba(30,30,30,.06);
}
.id-room__art::before {
  content: '';
  position: absolute; top: 20px; left: 20px; right: 20px; bottom: 20px;
  background: radial-gradient(ellipse at 40% 60%, #8A9E85 0%, transparent 60%),
              linear-gradient(45deg, #C9A96E20, transparent 50%);
  border-radius: 50% 30% 60% 40%;
}
.id-room__art-frame {
  position: absolute; top: -12px; left: -12px; right: -12px; bottom: -12px;
  border: 2px solid #C9A96E;
  pointer-events: none;
}

/* sofa */
.id-room__sofa {
  position: absolute; bottom: 36%; left: 6%;
  width: 200px;
}
.id-sofa__back {
  height: 55px;
  background: linear-gradient(180deg, #8A9E85 0%, #7A8E75 100%);
  border-radius: 6px 6px 0 0;
  position: relative;
}
.id-sofa__back::before {
  content: '';
  position: absolute; top: 8px; left: 8px; right: 8px; bottom: 0;
  background: linear-gradient(180deg, rgba(255,255,255,.12) 0%, transparent 100%);
  border-radius: 4px 4px 0 0;
}
/* cushions */
.id-sofa__cushions { display: flex; gap: 4px; }
.id-sofa__cushion {
  flex: 1; height: 38px;
  background: linear-gradient(180deg, #9AAE95 0%, #8A9E85 100%);
  border-radius: 2px;
  position: relative;
}
.id-sofa__cushion::after {
  content: '';
  position: absolute; top: 4px; left: 4px; right: 4px;
  height: 2px;
  background: rgba(255,255,255,.15);
  border-radius: 1px;
}
.id-sofa__base {
  height: 18px;
  background: linear-gradient(180deg, #7A8E75 0%, #6A7E65 100%);
  border-radius: 0 0 4px 4px;
}
.id-sofa__legs {
  display: flex; justify-content: space-between; padding: 0 16px;
}
.id-sofa__leg {
  width: 8px; height: 12px;
  background: #C9A96E;
  border-radius: 0 0 3px 3px;
}

/* throw pillow on sofa */
.id-room__pillow {
  position: absolute; bottom: calc(36% + 38px); left: calc(6% + 70px);
  width: 38px; height: 32px;
  background: linear-gradient(135deg, #D4A5A5 0%, #C49595 100%);
  border-radius: 4px;
  transform: rotate(-5deg);
  box-shadow: 1px 1px 4px rgba(30,30,30,.15);
}
.id-room__pillow::before {
  content: '';
  position: absolute; top: 8px; left: 8px; right: 8px; bottom: 8px;
  border: 1px solid rgba(255,255,255,.3);
  border-radius: 2px;
}

/* coffee table */
.id-room__table {
  position: absolute; bottom: 32%; left: 12%;
  width: 120px;
}
.id-table__top {
  height: 10px;
  background: linear-gradient(180deg, #E8D5C4 0%, #D8C5B4 100%);
  border-radius: 50%;
  box-shadow: 0 2px 8px rgba(30,30,30,.2);
}
.id-table__leg {
  width: 2px; height: 28px;
  background: #C9A96E;
  margin: 0 auto;
}
.id-table__base {
  width: 60px; height: 6px;
  background: #C9A96E;
  margin: 0 auto;
  border-radius: 3px;
}
/* vase on table */
.id-room__vase {
  position: absolute; bottom: calc(32% + 38px); left: calc(12% + 45px);
  display: flex; flex-direction: column; align-items: center;
}
.id-vase__body {
  width: 18px; height: 28px;
  background: linear-gradient(180deg, #D4A5A5 0%, #B89595 100%);
  border-radius: 50% 50% 30% 30% / 40% 40% 20% 20%;
  position: relative;
}
.id-vase__neck { width: 10px; height: 10px; background: #C49595; border-radius: 50% 50% 0 0; }
.id-vase__stem {
  width: 2px; height: 24px;
  background: #8A9E85;
}
.id-vase__bloom {
  width: 20px; height: 16px;
  background: radial-gradient(circle, #D4A5A5 30%, #8A9E85 100%);
  border-radius: 50% 50% 30% 30%;
  position: relative;
}
.id-vase__bloom::before, .id-vase__bloom::after {
  content: '';
  position: absolute; top: -4px;
  width: 12px; height: 12px;
  background: #C49595;
  border-radius: 50%;
}
.id-vase__bloom::before { left: -6px; }
.id-vase__bloom::after  { right: -6px; }

/* floor lamp */
.id-room__lamp {
  position: absolute; bottom: 30%; right: 12%;
  display: flex; flex-direction: column; align-items: center;
}
.id-lamp__shade {
  width: 36px; height: 28px;
  background: linear-gradient(180deg, #E8D5C4 0%, #D8C5B4 100%);
  clip-path: polygon(10% 0%, 90% 0%, 100% 100%, 0% 100%);
  position: relative;
  box-shadow: 0 0 20px rgba(201,169,110,.6);
}
.id-lamp__shade::before {
  content: '';
  position: absolute; inset: 0;
  background: linear-gradient(90deg, rgba(255,255,255,.2) 0%, transparent 50%, rgba(0,0,0,.05) 100%);
}
.id-lamp__pole {
  width: 3px; height: 110px;
  background: linear-gradient(180deg, #C9A96E 0%, #B89050 100%);
}
.id-lamp__base {
  width: 28px; height: 8px;
  background: linear-gradient(180deg, #C9A96E 0%, #A88040 100%);
  border-radius: 50%;
}
/* lamp glow on floor */
.id-lamp__glow {
  position: absolute;
  bottom: calc(30% - 20px); right: 7%;
  width: 80px; height: 30px;
  background: radial-gradient(ellipse, rgba(201,169,110,.25) 0%, transparent 70%);
  pointer-events: none;
}

/* bookshelf on left wall area */
.id-room__shelf {
  position: absolute; top: 14%; left: 5%;
  width: 160px;
  display: flex; flex-direction: column; gap: 2px;
}
.id-shelf__row {
  display: flex; gap: 2px; align-items: flex-end;
  background: #C8BFB3;
  padding: 2px 4px;
  border-top: 3px solid #B8AFA3;
}

/* indoor plant — tall fiddle-leaf type */
.id-room__plant {
  position: absolute; bottom: 35%; right: 26%;
}
.id-plant__pot {
  width: 24px; height: 18px;
  background: linear-gradient(180deg, #C4B5A5 0%, #B4A595 100%);
  clip-path: polygon(5% 0%, 95% 0%, 85% 100%, 15% 100%);
  margin: 0 auto;
}
.id-plant__stem {
  width: 3px; height: 50px;
  background: #8A9E85;
  margin: 0 auto;
}
.id-plant__leaf {
  position: absolute;
  background: #8A9E85;
  border-radius: 50% 0 50% 0;
  transform-origin: bottom center;
}
.id-plant__leaf--l1 { width: 24px; height: 32px; bottom: 42px; left: -20px; transform: rotate(-30deg); }
.id-plant__leaf--l2 { width: 20px; height: 28px; bottom: 54px; right: -16px; transform: rotate(25deg) scaleX(-1); }
.id-plant__leaf--l3 { width: 22px; height: 30px; bottom: 66px; left: -18px; transform: rotate(-20deg); }
.id-plant__leaf--l4 { width: 18px; height: 24px; bottom: 78px; right: -14px; transform: rotate(20deg) scaleX(-1); }

/* floating badge: awards */
.id-room__badge {
  position: absolute; top: 18%; left: 50%;
  background: rgba(250,248,245,.95);
  border: 1px solid rgba(201,169,110,.4);
  border-radius: 4px;
  padding: .5rem .8rem;
  font-family: var(--id-sans); font-size: .65rem;
  box-shadow: 0 4px 16px rgba(30,30,30,.12);
  white-space: nowrap;
  animation: id-badge-float 4s ease-in-out infinite;
}
.id-room__badge strong { display: block; font-size: .75rem; color: var(--id-gold); }
@keyframes id-badge-float {
  0%, 100% { transform: translateY(0); }
  50%       { transform: translateY(-6px); }
}

/* floating colour swatch strip */
.id-room__swatches {
  position: absolute; bottom: 20%; left: 5%;
  display: flex; flex-direction: column; gap: 3px;
  animation: id-badge-float 5s ease-in-out infinite;
  animation-delay: .8s;
}
.id-swatch {
  display: flex; align-items: center; gap: .4rem;
  background: rgba(250,248,245,.92);
  border-radius: 3px;
  padding: .25rem .5rem;
  font-size: .6rem; letter-spacing: .05em;
  box-shadow: 0 2px 6px rgba(30,30,30,.1);
}
.id-swatch__dot { width: 10px; height: 10px; border-radius: 2px; flex-shrink: 0; }

/* designer figure */
.id-designer {
  position: absolute; bottom: 31%; right: 38%;
}
.id-designer__head {
  width: 22px; height: 24px;
  background: #C4956A;
  border-radius: 50%;
  margin: 0 auto;
  position: relative;
}
.id-designer__head::before { /* hair */
  content: '';
  position: absolute; top: -6px; left: -2px; right: -2px; height: 14px;
  background: #2C1A0E;
  border-radius: 50% 50% 0 0;
}
/* earrings */
.id-designer__head::after {
  content: '◆';
  position: absolute; right: -4px; top: 8px;
  font-size: 5px; color: #C9A96E;
}
.id-designer__body {
  width: 30px; height: 44px;
  background: linear-gradient(180deg, #FAF8F5 0%, #F0EBE3 100%);
  border-radius: 4px 4px 0 0;
  margin: 0 auto;
  position: relative;
}
/* blouse accent */
.id-designer__body::before {
  content: '';
  position: absolute; top: 8px; left: 6px; right: 6px; bottom: 0;
  background: rgba(212,165,165,.3);
  border-radius: 2px;
}
.id-designer__arm-l {
  position: absolute; top: 46px; left: -8px;
  width: 10px; height: 32px;
  background: #FAF8F5;
  border-radius: 5px;
  transform: rotate(-15deg);
  transform-origin: top center;
}
.id-designer__arm-r {
  position: absolute; top: 46px; right: -8px;
  width: 10px; height: 30px;
  background: #C4956A; /* skin, holding swatch */
  border-radius: 5px;
  transform: rotate(20deg);
  transform-origin: top center;
}
/* clipboard in hand */
.id-designer__clipboard {
  position: absolute; bottom: 0; right: -16px;
  width: 20px; height: 26px;
  background: #E8D5C4;
  border-radius: 2px;
  border-top: 3px solid #C9A96E;
}
.id-designer__clipboard::before {
  content: '';
  position: absolute; top: 6px; left: 3px; right: 3px; height: 2px;
  background: rgba(30,30,30,.2);
  box-shadow: 0 4px 0 rgba(30,30,30,.2), 0 8px 0 rgba(30,30,30,.2);
}
.id-designer__legs {
  display: flex; gap: 4px; justify-content: center;
}
.id-designer__leg {
  width: 10px; height: 26px;
  background: linear-gradient(180deg, #2C1A0E 0%, #1C0E00 100%);
  border-radius: 0 0 3px 3px;
}
.id-designer__foot {
  width: 14px; height: 7px;
  background: #8B7355;
  border-radius: 0 3px 3px 0;
}

/* ════════════════════════════════════════════════════════════════
   MARQUEE — clients
════════════════════════════════════════════════════════════════ */
.id-marquee-wrap {
  overflow: hidden;
  background: var(--id-charcoal);
  padding: .85rem 0;
  border-top: 1px solid rgba(250,248,245,.08);
  border-bottom: 1px solid rgba(250,248,245,.08);
}
.id-marquee {
  display: flex; gap: 4rem;
  animation: id-scroll 28s linear infinite;
  white-space: nowrap;
}
.id-marquee-item {
  font-family: var(--id-serif); font-size: 1rem; font-style: italic;
  color: rgba(250,248,245,.45); letter-spacing: .08em; flex-shrink: 0;
}
.id-marquee-dot { color: var(--id-gold); }
@keyframes id-scroll {
  from { transform: translateX(0); }
  to   { transform: translateX(-50%); }
}

/* ════════════════════════════════════════════════════════════════
   STATS ROW
════════════════════════════════════════════════════════════════ */
.id-stats {
  display: grid; grid-template-columns: repeat(4,1fr);
  border-top: 1px solid rgba(30,30,30,.1);
  border-bottom: 1px solid rgba(30,30,30,.1);
}
.id-stat {
  padding: 3rem 2rem;
  text-align: center;
  border-right: 1px solid rgba(30,30,30,.1);
  position: relative;
}
.id-stat:last-child { border-right: none; }
.id-stat__num {
  font-family: var(--id-serif); font-size: 3.2rem; font-weight: 300;
  color: var(--id-charcoal); line-height: 1;
  display: block; margin-bottom: .35rem;
}
.id-stat__num span { color: var(--id-gold); }
.id-stat__label { font-size: .72rem; letter-spacing: .15em; text-transform: uppercase; color: var(--id-stone); }

/* ════════════════════════════════════════════════════════════════
   SERVICES GRID
════════════════════════════════════════════════════════════════ */
.id-services {
  display: grid;
  grid-template-columns: repeat(3,1fr);
  gap: 2px;
  background: rgba(30,30,30,.06);
}
.id-service {
  background: var(--id-ivory);
  padding: 2.8rem;
  transition: var(--id-trans);
  position: relative; overflow: hidden;
}
.id-service::before {
  content: '';
  position: absolute; bottom: 0; left: 0;
  height: 3px; width: 0;
  background: var(--id-gold);
  transition: width .4s ease;
}
.id-service:hover::before { width: 100%; }
.id-service:hover { background: var(--id-light); }
.id-service__icon {
  width: 48px; height: 48px;
  display: flex; align-items: center; justify-content: center;
  background: var(--id-sand);
  margin-bottom: 1.5rem;
  font-size: 1.4rem;
}
.id-service__title {
  font-family: var(--id-serif); font-size: 1.3rem; font-weight: 400;
  margin-bottom: .75rem;
}
.id-service__text { font-size: .9rem; line-height: 1.7; color: var(--id-stone); }

/* ════════════════════════════════════════════════════════════════
   PROCESS
════════════════════════════════════════════════════════════════ */
.id-process { display: grid; grid-template-columns: repeat(4,1fr); gap: 3rem; }
.id-step { text-align: center; position: relative; }
.id-step::after {
  content: '';
  position: absolute; top: 32px; left: calc(50% + 32px); right: -50%;
  height: 1px;
  background: linear-gradient(90deg, var(--id-gold), transparent);
}
.id-step:last-child::after { display: none; }
.id-step__num {
  width: 64px; height: 64px;
  border: 1px solid var(--id-gold);
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-family: var(--id-serif); font-size: 1.4rem; font-weight: 300;
  color: var(--id-gold);
  margin: 0 auto 1.5rem;
  position: relative; z-index: 1;
  background: var(--id-ivory);
}
.id-step__title { font-family: var(--id-serif); font-size: 1.15rem; margin-bottom: .6rem; }
.id-step__text { font-size: .85rem; line-height: 1.7; color: var(--id-stone); }

/* ════════════════════════════════════════════════════════════════
   COLOUR PALETTE SHOWCASE
════════════════════════════════════════════════════════════════ */
.id-palette { display: grid; grid-template-columns: repeat(4,1fr); gap: 1.5rem; }
.id-swatch-card {
  border-radius: 0;
  overflow: hidden;
  box-shadow: var(--id-shadow);
  transition: var(--id-trans);
}
.id-swatch-card:hover { transform: translateY(-4px); box-shadow: var(--id-shadow-lg); }
.id-swatch-card__color { height: 120px; }
.id-swatch-card__info { padding: 1rem 1.2rem; background: var(--id-ivory); }
.id-swatch-card__name { font-family: var(--id-serif); font-size: 1rem; margin-bottom: .25rem; }
.id-swatch-card__hex { font-size: .75rem; letter-spacing: .08em; color: var(--id-stone); }

/* ════════════════════════════════════════════════════════════════
   PORTFOLIO MOSAIC
════════════════════════════════════════════════════════════════ */
.id-portfolio {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-template-rows: auto;
  gap: 3px;
}
.id-project { position: relative; overflow: hidden; cursor: pointer; }
.id-project:nth-child(1) { grid-column: 1 / 3; grid-row: 1 / 3; }
.id-project:nth-child(4) { grid-column: 2 / 4; }
.id-project__visual {
  width: 100%; padding-bottom: 75%;
  position: relative;
}
.id-project:nth-child(1) .id-project__visual { padding-bottom: 66%; }
.id-project__bg {
  position: absolute; inset: 0;
  transition: transform .5s ease;
}
.id-project:hover .id-project__bg { transform: scale(1.04); }
.id-project__overlay {
  position: absolute; inset: 0;
  background: linear-gradient(to top, rgba(30,30,30,.8) 0%, transparent 60%);
  opacity: 0; transition: opacity .35s;
  display: flex; align-items: flex-end; padding: 2rem;
}
.id-project:hover .id-project__overlay { opacity: 1; }
.id-project__meta { color: var(--id-ivory); }
.id-project__cat { font-size: .65rem; letter-spacing: .2em; text-transform: uppercase; color: var(--id-gold); margin-bottom: .3rem; }
.id-project__title { font-family: var(--id-serif); font-size: 1.3rem; }

/* Project background palettes */
.id-project:nth-child(1) .id-project__bg { background: linear-gradient(135deg, #D4C4B0 0%, #B8A89A 35%, #8A9E85 65%, #C9A96E 100%); }
.id-project:nth-child(2) .id-project__bg { background: linear-gradient(135deg, #E8D5C4 0%, #D4A5A5 100%); }
.id-project:nth-child(3) .id-project__bg { background: linear-gradient(135deg, #8A9E85 0%, #6A7E65 100%); }
.id-project:nth-child(4) .id-project__bg { background: linear-gradient(135deg, #1E1E1E 0%, #2E2E2E 50%, #C9A96E 100%); }
.id-project:nth-child(5) .id-project__bg { background: linear-gradient(135deg, #C4B5A5 0%, #B0A090 100%); }

/* ════════════════════════════════════════════════════════════════
   ABOUT SECTION
════════════════════════════════════════════════════════════════ */
.id-about { display: grid; grid-template-columns: 1fr 1fr; gap: 6rem; align-items: center; }
.id-about__img {
  position: relative;
  background: linear-gradient(135deg, #D4C4B0 0%, #C4B5A5 100%);
  height: 520px;
}
.id-about__img::before {
  content: '';
  position: absolute; top: -16px; left: -16px;
  width: 100px; height: 100px;
  border: 2px solid var(--id-gold);
  pointer-events: none;
}
.id-about__img::after {
  content: '"Design is intelligence made visible."';
  position: absolute; bottom: 2rem; left: 1.5rem; right: 1.5rem;
  font-family: var(--id-serif); font-size: 1rem; font-style: italic;
  color: var(--id-ivory);
  background: rgba(30,30,30,.75);
  padding: 1rem 1.25rem;
  line-height: 1.5;
}
/* designer figure inside about */
.id-about__figure {
  position: absolute; top: 15%; left: 50%; transform: translateX(-50%);
  display: flex; flex-direction: column; align-items: center;
}
.id-about__head {
  width: 60px; height: 68px;
  background: #C4956A;
  border-radius: 50%;
  position: relative;
}
.id-about__head::before { /* hair */
  content: '';
  position: absolute; top: -12px; left: -4px; right: -4px; height: 30px;
  background: #2C1A0E;
  border-radius: 50% 50% 0 0;
}
.id-about__body {
  width: 80px; height: 120px;
  background: linear-gradient(180deg, #FAF8F5 0%, #F0EBE3 100%);
  border-radius: 6px 6px 0 0;
  position: relative; margin-top: 4px;
}
.id-about__body::before {
  content: '';
  position: absolute; top: 12px; left: 12px; right: 12px;
  height: 60px;
  background: linear-gradient(180deg, rgba(201,169,110,.3) 0%, transparent 100%);
  border-radius: 2px;
}
.id-about__skirt {
  width: 90px; height: 70px;
  background: linear-gradient(180deg, #8A9E85 0%, #7A8E75 100%);
  clip-path: polygon(5% 0%, 95% 0%, 100% 100%, 0% 100%);
}
.id-about__info { }
.id-about__info .id-h2 { margin-bottom: 1rem; }
.id-about__info .id-lead { margin-bottom: 2rem; }
.id-about__credentials {
  display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;
  margin-bottom: 2rem;
}
.id-cred {
  padding: 1rem 1.2rem;
  border: 1px solid rgba(30,30,30,.1);
  border-left: 3px solid var(--id-gold);
}
.id-cred__title { font-size: .8rem; font-weight: 600; margin-bottom: .25rem; }
.id-cred__detail { font-size: .8rem; color: var(--id-stone); }
.id-about__sig {
  font-family: var(--id-serif); font-size: 1.8rem; font-style: italic;
  color: var(--id-charcoal); margin-bottom: .25rem;
}
.id-about__role { font-size: .75rem; letter-spacing: .15em; text-transform: uppercase; color: var(--id-stone); }

/* ════════════════════════════════════════════════════════════════
   PACKAGES
════════════════════════════════════════════════════════════════ */
.id-packages { display: grid; grid-template-columns: repeat(3,1fr); gap: 2rem; }
.id-pkg {
  border: 1px solid rgba(30,30,30,.1);
  padding: 2.5rem;
  position: relative;
  transition: var(--id-trans);
}
.id-pkg:hover { box-shadow: var(--id-shadow-lg); }
.id-pkg--featured {
  border-color: var(--id-gold);
  background: var(--id-charcoal);
  color: var(--id-ivory);
  transform: scale(1.04);
  z-index: 1;
}
.id-pkg__badge {
  position: absolute; top: -1px; left: 50%; transform: translateX(-50%);
  background: var(--id-gold); color: var(--id-charcoal);
  font-size: .65rem; font-weight: 700; letter-spacing: .15em; text-transform: uppercase;
  padding: .3rem 1.2rem;
}
.id-pkg__name { font-family: var(--id-serif); font-size: 1.4rem; font-weight: 400; margin-bottom: .5rem; }
.id-pkg__desc { font-size: .85rem; color: var(--id-stone); margin-bottom: 1.5rem; }
.id-pkg--featured .id-pkg__desc { color: rgba(250,248,245,.6); }
.id-pkg__price { font-family: var(--id-serif); font-size: 2.8rem; font-weight: 300; line-height: 1; margin-bottom: .25rem; }
.id-pkg__price sup { font-size: 1.2rem; vertical-align: super; }
.id-pkg__price sub { font-size: .9rem; }
.id-pkg__price-note { font-size: .75rem; color: var(--id-stone); margin-bottom: 1.5rem; padding-bottom: 1.5rem; border-bottom: 1px solid rgba(30,30,30,.1); }
.id-pkg--featured .id-pkg__price-note { border-color: rgba(250,248,245,.15); }
.id-pkg__features { list-style: none; margin-bottom: 2rem; display: flex; flex-direction: column; gap: .6rem; }
.id-pkg__feature {
  font-size: .85rem; display: flex; align-items: flex-start; gap: .6rem;
}
.id-pkg__feature::before { content: '—'; color: var(--id-gold); flex-shrink: 0; }
.id-pkg--featured .id-pkg__feature { color: rgba(250,248,245,.85); }

/* ════════════════════════════════════════════════════════════════
   TESTIMONIALS
════════════════════════════════════════════════════════════════ */
.id-testimonials { display: grid; grid-template-columns: repeat(3,1fr); gap: 2rem; }
.id-testi {
  background: var(--id-ivory);
  border: 1px solid rgba(30,30,30,.08);
  padding: 2.5rem;
  position: relative;
}
.id-testi::before {
  content: '"';
  font-family: var(--id-serif); font-size: 5rem; font-weight: 300;
  color: var(--id-gold); opacity: .4;
  position: absolute; top: .5rem; left: 1.5rem;
  line-height: 1;
}
.id-testi__text { font-size: .9rem; line-height: 1.8; color: var(--id-stone); margin-bottom: 1.5rem; margin-top: 2rem; }
.id-testi__author { display: flex; align-items: center; gap: .75rem; }
.id-testi__avatar {
  width: 40px; height: 40px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-family: var(--id-serif); font-size: 1rem;
  color: var(--id-ivory); flex-shrink: 0;
}
.id-testi__name { font-family: var(--id-serif); font-size: .95rem; display: block; }
.id-testi__role { font-size: .72rem; letter-spacing: .08em; text-transform: uppercase; color: var(--id-stone); }
.id-stars { color: var(--id-gold); font-size: .75rem; margin-bottom: .5rem; letter-spacing: .1em; }

/* ════════════════════════════════════════════════════════════════
   FAQ ACCORDION
════════════════════════════════════════════════════════════════ */
.id-faq-list { max-width: 800px; margin: 0 auto; }
.id-faq {
  border-bottom: 1px solid rgba(30,30,30,.1);
}
.id-faq__q {
  width: 100%; display: flex; align-items: center; justify-content: space-between;
  padding: 1.4rem 0;
  font-family: var(--id-serif); font-size: 1.1rem; font-weight: 400;
  text-align: left; cursor: pointer;
  color: var(--id-charcoal);
  transition: color .25s;
  background: none; border: none;
}
.id-faq__q:hover { color: var(--id-gold); }
.id-faq__icon {
  width: 24px; height: 24px; flex-shrink: 0;
  border: 1px solid currentColor; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .8rem; transition: transform .35s;
}
.id-faq.id-open .id-faq__icon { transform: rotate(45deg); }
.id-faq__a {
  max-height: 0; overflow: hidden;
  transition: max-height .4s ease, padding .4s ease;
}
.id-faq__a-inner {
  padding-bottom: 1.2rem;
  font-size: .9rem; line-height: 1.8; color: var(--id-stone);
}

/* ════════════════════════════════════════════════════════════════
   CONTACT FORM
════════════════════════════════════════════════════════════════ */
.id-contact { display: grid; grid-template-columns: 1fr 1fr; gap: 6rem; align-items: start; }
.id-contact__info .id-h2 { margin-bottom: 1rem; }
.id-contact__info .id-lead { margin-bottom: 2rem; }
.id-contact__details { display: flex; flex-direction: column; gap: 1.5rem; margin-bottom: 2rem; }
.id-detail { display: flex; gap: 1rem; align-items: flex-start; }
.id-detail__icon {
  width: 40px; height: 40px; flex-shrink: 0;
  background: var(--id-sand);
  display: flex; align-items: center; justify-content: center;
  font-size: 1rem;
}
.id-detail__label { font-size: .7rem; letter-spacing: .12em; text-transform: uppercase; color: var(--id-stone); margin-bottom: .2rem; }
.id-detail__value { font-size: .9rem; line-height: 1.5; }

.id-form { display: flex; flex-direction: column; gap: 1.2rem; }
.id-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1.2rem; }
.id-field { display: flex; flex-direction: column; gap: .4rem; }
.id-label { font-size: .72rem; letter-spacing: .1em; text-transform: uppercase; color: var(--id-stone); }
.id-input, .id-select, .id-textarea {
  width: 100%; padding: .85rem 1rem;
  border: 1px solid rgba(30,30,30,.2);
  border-radius: 0;
  background: var(--id-ivory);
  font-family: var(--id-sans); font-size: .9rem;
  color: var(--id-charcoal);
  transition: border-color .25s;
  appearance: none;
}
.id-input:focus, .id-select:focus, .id-textarea:focus {
  outline: none; border-color: var(--id-gold);
}
.id-textarea { resize: vertical; min-height: 120px; }
.id-form__submit { align-self: flex-start; }

/* ════════════════════════════════════════════════════════════════
   CTA BANNER
════════════════════════════════════════════════════════════════ */
.id-cta-banner {
  background: var(--id-charcoal);
  padding: 6rem 0;
  text-align: center;
  position: relative; overflow: hidden;
}
.id-cta-banner::before {
  content: '';
  position: absolute; top: -40%; left: 50%; transform: translateX(-50%);
  width: 600px; height: 600px;
  background: radial-gradient(circle, rgba(201,169,110,.12) 0%, transparent 70%);
  pointer-events: none;
}
.id-cta-banner .id-h2 { color: var(--id-ivory); margin-bottom: 1.2rem; }
.id-cta-banner .id-lead { color: rgba(250,248,245,.65); margin: 0 auto 2.5rem; }
.id-cta-banner__actions { display: flex; gap: 1rem; justify-content: center; }

/* ════════════════════════════════════════════════════════════════
   FOOTER
════════════════════════════════════════════════════════════════ */
.id-footer {
  background: var(--id-charcoal);
  border-top: 1px solid rgba(250,248,245,.08);
  padding: 4rem 0 2rem;
}
.id-footer__top { display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 3rem; margin-bottom: 3rem; }
.id-footer__brand .id-nav__logo { display: inline-block; margin-bottom: 1rem; color: var(--id-ivory); }
.id-footer__brand p { font-size: .85rem; line-height: 1.7; color: rgba(250,248,245,.5); max-width: 28ch; }
.id-footer__col-title { font-size: .7rem; letter-spacing: .15em; text-transform: uppercase; color: var(--id-gold); margin-bottom: 1rem; }
.id-footer__links { list-style: none; display: flex; flex-direction: column; gap: .5rem; }
.id-footer__links a { font-size: .85rem; color: rgba(250,248,245,.5); transition: color .25s; }
.id-footer__links a:hover { color: var(--id-ivory); }
.id-footer__bottom {
  padding-top: 2rem;
  border-top: 1px solid rgba(250,248,245,.08);
  display: flex; justify-content: space-between; align-items: center;
  font-size: .78rem; color: rgba(250,248,245,.35);
}

/* ════════════════════════════════════════════════════════════════
   RESPONSIVE
════════════════════════════════════════════════════════════════ */
@media (max-width: 1024px) {
  .id-hero { grid-template-columns: 1fr; min-height: auto; }
  .id-hero__right { height: 60vw; min-height: 360px; }
  .id-hero__left { padding: 3rem 2rem; }
  .id-services { grid-template-columns: repeat(2,1fr); }
  .id-portfolio { grid-template-columns: repeat(2,1fr); }
  .id-project:nth-child(1) { grid-column: 1/3; grid-row: 1/2; }
  .id-project:nth-child(4) { grid-column: 1/3; }
  .id-about { grid-template-columns: 1fr; gap: 3rem; }
  .id-about__img { height: 320px; }
  .id-contact { grid-template-columns: 1fr; gap: 3rem; }
  .id-footer__top { grid-template-columns: 1fr 1fr; }
}
@media (max-width: 768px) {
  .id-nav__links, .id-nav__cta { display: none; }
  .id-stats { grid-template-columns: repeat(2,1fr); }
  .id-services { grid-template-columns: 1fr; }
  .id-process { grid-template-columns: repeat(2,1fr); gap: 2rem; }
  .id-step::after { display: none; }
  .id-palette { grid-template-columns: repeat(2,1fr); }
  .id-portfolio { grid-template-columns: 1fr; }
  .id-project:nth-child(1), .id-project:nth-child(4) { grid-column: 1; grid-row: auto; }
  .id-packages { grid-template-columns: 1fr; }
  .id-pkg--featured { transform: none; }
  .id-testimonials { grid-template-columns: 1fr; }
  .id-form-row { grid-template-columns: 1fr; }
  .id-footer__top { grid-template-columns: 1fr; }
  .id-footer__bottom { flex-direction: column; gap: .75rem; text-align: center; }
}
</style>

<div class="id-page">

<!-- ══════════════════════════════════════════════════════════════
     NAV
══════════════════════════════════════════════════════════════ -->
<nav class="id-nav" role="navigation" aria-label="<?php esc_attr_e('Main navigation','themeflex'); ?>">
  <a href="<?php echo esc_url(home_url('/')); ?>" class="id-nav__logo">Maison <span>Collective</span></a>
  <ul class="id-nav__links">
    <li><a href="#services">Services</a></li>
    <li><a href="#portfolio">Portfolio</a></li>
    <li><a href="#about">Studio</a></li>
    <li><a href="#packages">Packages</a></li>
    <li><a href="#contact">Contact</a></li>
  </ul>
  <a href="#contact" class="id-nav__cta"><?php esc_html_e('Book Consultation','themeflex'); ?></a>
</nav>

<!-- ══════════════════════════════════════════════════════════════
     HERO
══════════════════════════════════════════════════════════════ -->
<section class="id-hero" aria-label="<?php esc_attr_e('Hero','themeflex'); ?>">

  <div class="id-hero__left">
    <p class="id-eyebrow"><?php esc_html_e('Award-Winning Interior Design Studio','themeflex'); ?></p>
    <h1 class="id-h1">
      <?php esc_html_e('Spaces That','themeflex'); ?><br>
      <em><?php esc_html_e('Tell Your Story','themeflex'); ?></em>
    </h1>
    <p class="id-lead"><?php esc_html_e('Maison Collective transforms residential and commercial interiors into bespoke environments that balance beauty, function, and feeling. From concept to completion, every detail is intentional.','themeflex'); ?></p>
    <div class="id-hero__actions">
      <a href="#portfolio" class="id-btn id-btn--primary"><?php esc_html_e('View Portfolio','themeflex'); ?></a>
      <a href="#contact" class="id-btn id-btn--outline"><?php esc_html_e('Start a Project','themeflex'); ?></a>
    </div>

    <div class="id-hero__press" aria-label="<?php esc_attr_e('Press mentions','themeflex'); ?>">
      <span class="id-hero__press-label"><?php esc_html_e('As seen in','themeflex'); ?></span>
      <div class="id-hero__press-items" aria-hidden="true">
        <span class="id-hero__press-item">Architectural Digest</span>
        <span class="id-hero__press-item">Elle Décor</span>
        <span class="id-hero__press-item">House &amp; Garden</span>
      </div>
    </div>
  </div>

  <!-- CSS Design Studio Scene -->
  <div class="id-hero__right" aria-hidden="true">
    <div class="id-room">
      <div class="id-room__wall"></div>
      <div class="id-room__floor"></div>

      <!-- Framed artwork -->
      <div class="id-room__art" role="img" aria-label="Artwork">
        <div class="id-room__art-frame"></div>
      </div>

      <!-- Bookshelf with coloured spines -->
      <div class="id-room__shelf">
        <div class="id-shelf__row">
          <?php foreach (array_slice($id_shelf_books, 0, 7) as $bk): ?>
          <div style="width:<?php echo esc_attr($bk['width']); ?>px;height:<?php echo esc_attr($bk['height']); ?>px;background:<?php echo esc_attr($bk['color']); ?>;border-radius:1px 1px 0 0;"></div>
          <?php endforeach; ?>
        </div>
        <div class="id-shelf__row">
          <?php foreach (array_slice($id_shelf_books, 7) as $bk): ?>
          <div style="width:<?php echo esc_attr($bk['width']); ?>px;height:<?php echo esc_attr($bk['height']); ?>px;background:<?php echo esc_attr($bk['color']); ?>;border-radius:1px 1px 0 0;"></div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Sofa -->
      <div class="id-room__sofa">
        <div class="id-sofa__back"></div>
        <div class="id-sofa__cushions">
          <div class="id-sofa__cushion"></div>
          <div class="id-sofa__cushion"></div>
          <div class="id-sofa__cushion"></div>
        </div>
        <div class="id-sofa__base"></div>
        <div class="id-sofa__legs">
          <div class="id-sofa__leg"></div>
          <div class="id-sofa__leg"></div>
        </div>
      </div>
      <div class="id-room__pillow"></div>

      <!-- Coffee table + vase -->
      <div class="id-room__table">
        <div class="id-table__top"></div>
        <div class="id-table__leg"></div>
        <div class="id-table__base"></div>
      </div>
      <div class="id-room__vase">
        <div class="id-vase__bloom"></div>
        <div class="id-vase__stem"></div>
        <div class="id-vase__neck"></div>
        <div class="id-vase__body"></div>
      </div>

      <!-- Floor lamp + glow -->
      <div class="id-room__lamp">
        <div class="id-lamp__shade"></div>
        <div class="id-lamp__pole"></div>
        <div class="id-lamp__base"></div>
      </div>
      <div class="id-lamp__glow"></div>

      <!-- Indoor plant -->
      <div class="id-room__plant">
        <div class="id-plant__leaf id-plant__leaf--l4"></div>
        <div class="id-plant__leaf id-plant__leaf--l3"></div>
        <div class="id-plant__leaf id-plant__leaf--l2"></div>
        <div class="id-plant__leaf id-plant__leaf--l1"></div>
        <div class="id-plant__stem"></div>
        <div class="id-plant__pot"></div>
      </div>

      <!-- Designer figure -->
      <div class="id-designer">
        <div class="id-designer__head"></div>
        <div class="id-designer__body">
          <div class="id-designer__arm-l"></div>
          <div class="id-designer__arm-r">
            <div class="id-designer__clipboard"></div>
          </div>
        </div>
        <div class="id-designer__legs">
          <div class="id-designer__leg"></div>
          <div class="id-designer__leg"></div>
        </div>
        <div class="id-designer__foot"></div>
      </div>

      <!-- Floating award badge -->
      <div class="id-room__badge">
        <strong><?php esc_html_e('BIID Award 2025','themeflex'); ?></strong>
        <?php esc_html_e('Best Residential Studio','themeflex'); ?>
      </div>

      <!-- Colour swatch strip -->
      <div class="id-room__swatches" aria-hidden="true">
        <?php for ($i = 0; $i < 4; $i++): ?>
        <div class="id-swatch">
          <div class="id-swatch__dot" style="background:<?php echo esc_attr($id_swatches[$i]); ?>;"></div>
          <?php echo esc_html($id_palette[$i]); ?>
        </div>
        <?php endfor; ?>
      </div>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════════════════════════
     MARQUEE
══════════════════════════════════════════════════════════════ -->
<div class="id-marquee-wrap" aria-hidden="true">
  <div class="id-marquee">
    <?php
    $id_press = ['Architectural Digest','Elle Décor','House &amp; Garden','RIBA Journal','Dezeen','Grand Designs','Blueprint Magazine','The World of Interiors'];
    $id_marquee_items = array_merge($id_press, $id_press); // double for seamless
    foreach ($id_marquee_items as $item):
    ?>
    <span class="id-marquee-item"><?php echo wp_kses_post($item); ?> <span class="id-marquee-dot">✦</span></span>
    <?php endforeach; ?>
  </div>
</div>

<!-- ══════════════════════════════════════════════════════════════
     STATS
══════════════════════════════════════════════════════════════ -->
<section class="id-section" aria-label="<?php esc_attr_e('Key statistics','themeflex'); ?>">
  <div class="id-wrap">
    <div class="id-stats">
      <div class="id-stat id-reveal">
        <span class="id-stat__num" data-target="280">0<span>+</span></span>
        <span class="id-stat__label"><?php esc_html_e('Projects Completed','themeflex'); ?></span>
      </div>
      <div class="id-stat id-reveal" style="transition-delay:.1s">
        <span class="id-stat__num" data-target="18">0<span></span></span>
        <span class="id-stat__label"><?php esc_html_e('Years of Practice','themeflex'); ?></span>
      </div>
      <div class="id-stat id-reveal" style="transition-delay:.2s">
        <span class="id-stat__num" data-target="96">0<span>%</span></span>
        <span class="id-stat__label"><?php esc_html_e('Client Satisfaction','themeflex'); ?></span>
      </div>
      <div class="id-stat id-reveal" style="transition-delay:.3s">
        <span class="id-stat__num" data-target="14">0<span></span></span>
        <span class="id-stat__label"><?php esc_html_e('Industry Awards','themeflex'); ?></span>
      </div>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════════════════════════
     SERVICES
══════════════════════════════════════════════════════════════ -->
<section id="services" class="id-section id-section--alt" aria-labelledby="id-svc-title">
  <div class="id-wrap">
    <header style="text-align:center;margin-bottom:3.5rem;" class="id-reveal">
      <p class="id-eyebrow"><?php esc_html_e('What We Do','themeflex'); ?></p>
      <h2 class="id-h2" id="id-svc-title"><?php esc_html_e('Full-Spectrum Design Services','themeflex'); ?></h2>
      <p class="id-lead" style="margin:1rem auto 0;"><?php esc_html_e('From the first sketch to the final cushion, we handle every element of your interior transformation.','themeflex'); ?></p>
    </header>
    <div class="id-services">
      <?php
      $id_services = [
        ['🏡','Residential Design','Bespoke interiors for private homes, apartments, and holiday properties — tailored to how you live, not trends.'],
        ['🏢','Commercial Spaces','Offices, hotels, restaurants, and retail environments that reinforce your brand and delight your customers.'],
        ['🎨','Concept &amp; Styling','Mood boards, material palettes, and full concept decks to align creative vision before a penny is spent.'],
        ['🖼','Art Curation','Sourcing and placing original artworks, prints, and sculptural pieces that give rooms soul and narrative.'],
        ['🌿','FF&amp;E Procurement','Furniture, fixtures, and equipment specification and procurement from global and local suppliers.'],
        ['🔦','Lighting Design','Layered lighting schemes — ambient, task, and accent — that set mood and define space at every hour.'],
      ];
      foreach ($id_services as $i => [$icon, $title, $text]):
      ?>
      <div class="id-service id-reveal" style="transition-delay:<?php echo $i * 0.08; ?>s">
        <div class="id-service__icon" aria-hidden="true"><?php echo $icon; ?></div>
        <h3 class="id-service__title"><?php echo wp_kses_post($title); ?></h3>
        <p class="id-service__text"><?php echo wp_kses_post($text); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════════════════════════
     PROCESS
══════════════════════════════════════════════════════════════ -->
<section class="id-section" aria-labelledby="id-proc-title">
  <div class="id-wrap">
    <header style="text-align:center;margin-bottom:3.5rem;" class="id-reveal">
      <p class="id-eyebrow"><?php esc_html_e('Our Approach','themeflex'); ?></p>
      <h2 class="id-h2" id="id-proc-title"><?php esc_html_e('How We Work','themeflex'); ?></h2>
    </header>
    <div class="id-process">
      <?php
      $id_steps = [
        ['01','Discovery','We meet you, listen deeply, and explore the space — absorbing how you live, work, and what brings you joy.'],
        ['02','Concept','We develop a full concept deck: mood boards, palette, furniture direction, and spatial flow — your vision, elevated.'],
        ['03','Design &amp; Specify','Detailed drawings, material schedules, and FF&amp;E specifications are produced and signed off before procurement begins.'],
        ['04','Deliver &amp; Style','We manage contractors, deliveries, and installation. The final reveal is our favourite moment — and yours.'],
      ];
      foreach ($id_steps as $i => [$num, $title, $text]):
      ?>
      <div class="id-step id-reveal" style="transition-delay:<?php echo $i * 0.12; ?>s">
        <div class="id-step__num" aria-hidden="true"><?php echo esc_html($num); ?></div>
        <h3 class="id-step__title"><?php echo wp_kses_post($title); ?></h3>
        <p class="id-step__text"><?php echo wp_kses_post($text); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════════════════════════
     COLOUR PALETTE SHOWCASE
══════════════════════════════════════════════════════════════ -->
<section class="id-section id-section--sand" aria-labelledby="id-pal-title">
  <div class="id-wrap">
    <header style="text-align:center;margin-bottom:3rem;" class="id-reveal">
      <p class="id-eyebrow"><?php esc_html_e('Our Signature Palette','themeflex'); ?></p>
      <h2 class="id-h2" id="id-pal-title"><?php esc_html_e('Colour as Language','themeflex'); ?></h2>
      <p class="id-lead" style="margin:1rem auto 0;"><?php esc_html_e('Every project begins with a bespoke colour story. Here are eight tonalities we return to most often — timeless, warm, and infinitely adaptable.','themeflex'); ?></p>
    </header>
    <div class="id-palette">
      <?php for ($i = 0; $i < 8; $i++): ?>
      <div class="id-swatch-card id-reveal" style="transition-delay:<?php echo $i * 0.06; ?>s">
        <div class="id-swatch-card__color" style="background:<?php echo esc_attr($id_swatches[$i]); ?>;"></div>
        <div class="id-swatch-card__info">
          <p class="id-swatch-card__name"><?php echo esc_html($id_palette[$i]); ?></p>
          <p class="id-swatch-card__hex"><?php echo esc_html($id_swatches[$i]); ?></p>
        </div>
      </div>
      <?php endfor; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════════════════════════
     PORTFOLIO MOSAIC
══════════════════════════════════════════════════════════════ -->
<section id="portfolio" class="id-section id-section--dark" aria-labelledby="id-port-title">
  <div class="id-wrap--wide">
    <header style="text-align:center;margin-bottom:3rem;" class="id-reveal">
      <p class="id-eyebrow"><?php esc_html_e('Selected Work','themeflex'); ?></p>
      <h2 class="id-h2" id="id-port-title"><?php esc_html_e('Recent Projects','themeflex'); ?></h2>
    </header>
    <div class="id-portfolio" role="list">
      <?php
      $id_projects = [
        ['Residential','The Chelsea Townhouse','A five-storey Georgian home reimagined for a young family — warm neutrals, hand-crafted joinery, and layered textiles.'],
        ['Commercial','Aro Hotel Lobby','Earthy tones and biophilic elements for a new boutique hotel arrival experience in Edinburgh.'],
        ['Residential','Notting Hill Garden Flat','A compact garden apartment that feels expansive through mirroring, light, and a disciplined palette.'],
        ['Commercial','Luma Restaurant &amp; Bar','Dramatic, candle-lit dining: velvet booths, arched plaster ceilings, and a bespoke bar in aged brass.'],
        ['Residential','The Lake District Retreat','A rural second home with stone, linen, and a palette borrowed directly from the surrounding fells.'],
      ];
      foreach ($id_projects as [$cat, $title, $desc]):
      ?>
      <div class="id-project id-reveal" role="listitem">
        <div class="id-project__visual">
          <div class="id-project__bg" aria-hidden="true"></div>
          <div class="id-project__overlay">
            <div class="id-project__meta">
              <p class="id-project__cat"><?php echo esc_html($cat); ?></p>
              <h3 class="id-project__title"><?php echo wp_kses_post($title); ?></h3>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center;margin-top:2.5rem;">
      <a href="#contact" class="id-btn id-btn--ghost"><?php esc_html_e('Discuss Your Project','themeflex'); ?></a>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════════════════════════
     ABOUT
══════════════════════════════════════════════════════════════ -->
<section id="about" class="id-section" aria-labelledby="id-about-title">
  <div class="id-wrap">
    <div class="id-about">
      <div class="id-about__img id-reveal" role="img" aria-label="<?php esc_attr_e('Studio founder Isabelle Renard','themeflex'); ?>">
        <div class="id-about__figure">
          <div class="id-about__head"></div>
          <div class="id-about__body"></div>
          <div class="id-about__skirt"></div>
        </div>
      </div>
      <div class="id-about__info id-reveal" style="transition-delay:.15s">
        <p class="id-eyebrow"><?php esc_html_e('The Studio','themeflex'); ?></p>
        <h2 class="id-h2" id="id-about-title"><?php esc_html_e('Founded on Craft, Driven by Curiosity','themeflex'); ?></h2>
        <p class="id-lead"><?php esc_html_e('Maison Collective was founded in London in 2007 by Isabelle Renard, who trained at the École Camondo in Paris before building her practice across the UK and Europe. The studio now numbers twelve designers, an art consultant, and two project directors — small enough to care deeply, large enough to deliver beautifully.','themeflex'); ?></p>
        <div class="id-about__credentials">
          <?php
          $id_creds = [
            ['BIID Member','British Institute of Interior Design'],
            ['RIBA Affiliate','Royal Institute of British Architects'],
            ['Dezeen Award','Residential Project 2023'],
            ['AD100 Listed','Architectural Digest UK 2024'],
          ];
          foreach ($id_creds as [$t, $d]):
          ?>
          <div class="id-cred">
            <p class="id-cred__title"><?php echo esc_html($t); ?></p>
            <p class="id-cred__detail"><?php echo esc_html($d); ?></p>
          </div>
          <?php endforeach; ?>
        </div>
        <p class="id-about__sig">Isabelle Renard</p>
        <p class="id-about__role"><?php esc_html_e('Founder &amp; Creative Director','themeflex'); ?></p>
      </div>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════════════════════════
     PACKAGES
══════════════════════════════════════════════════════════════ -->
<section id="packages" class="id-section id-section--alt" aria-labelledby="id-pkg-title">
  <div class="id-wrap">
    <header style="text-align:center;margin-bottom:4rem;" class="id-reveal">
      <p class="id-eyebrow"><?php esc_html_e('Investment','themeflex'); ?></p>
      <h2 class="id-h2" id="id-pkg-title"><?php esc_html_e('Choose Your Service Level','themeflex'); ?></h2>
      <p class="id-lead" style="margin:1rem auto 0;"><?php esc_html_e('Transparent pricing structured around how much support you want. All packages include our initial discovery consultation.','themeflex'); ?></p>
    </header>
    <div class="id-packages">
      <?php
      $id_packages = [
        [
          'Consultation &amp; Concept', 'From','£1,200','one-time fee',
          'Ideal for single rooms or directional guidance before self-managing the project.',
          false, null,
          ['3-hour studio meeting','Full concept presentation','Palette &amp; material board','Furniture direction doc','Source list (not procured)'],
        ],
        [
          'Full Design Service', 'From','£6,500','per project',
          'Our most popular offering — full concept through to installation management.',
          true, 'Most Popular',
          ['Everything in Consultation','Space planning &amp; drawings','FF&amp;E specification','Contractor coordination','Site visits (up to 8)','Final styling &amp; reveal'],
        ],
        [
          'Retainer Partnership', 'From','£2,800','per month',
          'For developers, property investors, or businesses requiring ongoing design support.',
          false, null,
          ['Dedicated designer','Unlimited brief revisions','Priority scheduling','Monthly project reports','Access to trade pricing','Annual palette review'],
        ],
      ];
      foreach ($id_packages as [$name, $from, $price, $unit, $desc, $featured, $badge, $features]):
      ?>
      <div class="id-pkg id-reveal<?php echo $featured ? ' id-pkg--featured' : ''; ?>">
        <?php if ($badge): ?>
        <div class="id-pkg__badge"><?php echo esc_html($badge); ?></div>
        <?php endif; ?>
        <h3 class="id-pkg__name"><?php echo wp_kses_post($name); ?></h3>
        <p class="id-pkg__desc"><?php echo esc_html($desc); ?></p>
        <div class="id-pkg__price"><sup><?php esc_html_e('£','themeflex'); ?></sup><?php echo esc_html(ltrim($price,'£')); ?></div>
        <p class="id-pkg__price-note"><?php echo esc_html($unit); ?></p>
        <ul class="id-pkg__features">
          <?php foreach ($features as $f): ?>
          <li class="id-pkg__feature"><?php echo wp_kses_post($f); ?></li>
          <?php endforeach; ?>
        </ul>
        <a href="#contact" class="id-btn <?php echo $featured ? 'id-btn--ghost' : 'id-btn--outline'; ?>" style="width:100%;justify-content:center;"><?php esc_html_e('Book a Consultation','themeflex'); ?></a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════════════════════════
     TESTIMONIALS
══════════════════════════════════════════════════════════════ -->
<section class="id-section" aria-labelledby="id-testi-title">
  <div class="id-wrap">
    <header style="text-align:center;margin-bottom:3rem;" class="id-reveal">
      <p class="id-eyebrow"><?php esc_html_e('Client Stories','themeflex'); ?></p>
      <h2 class="id-h2" id="id-testi-title"><?php esc_html_e('What Our Clients Say','themeflex'); ?></h2>
    </header>
    <div class="id-testimonials">
      <?php
      $id_testis = [
        ['#8A9E85','S','Sophia &amp; James T.','Chelsea Townhouse Clients','Working with Maison Collective was the best decision we made. Isabelle understood instinctively what we wanted before we could even articulate it. The house now feels like us — warm, considered, and genuinely beautiful.'],
        ['#D4A5A5','M','Marcus P.','Aro Hotel, Operations Director','The hotel lobby project came in on time and has transformed guest first impressions. Dwell times in reception have increased. Our PR team have used the space in three shoots. It pays for itself.'],
        ['#C9A96E','R','Rachel O.','Notting Hill Flat Owner','I was nervous about spending on design — I thought I could manage it myself. I was wrong. The studio added ideas I would never have considered and the result is extraordinary for the square footage.'],
      ];
      foreach ($id_testis as $i => [$bg, $init, $name, $role, $text]):
      ?>
      <div class="id-testi id-reveal" style="transition-delay:<?php echo $i * 0.1; ?>s">
        <div class="id-stars" aria-label="<?php esc_attr_e('5 stars','themeflex'); ?>">★★★★★</div>
        <p class="id-testi__text"><?php echo wp_kses_post($text); ?></p>
        <div class="id-testi__author">
          <div class="id-testi__avatar" style="background:<?php echo esc_attr($bg); ?>" aria-hidden="true"><?php echo esc_html($init); ?></div>
          <div>
            <span class="id-testi__name"><?php echo wp_kses_post($name); ?></span>
            <span class="id-testi__role"><?php echo esc_html($role); ?></span>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════════════════════════
     FAQ
══════════════════════════════════════════════════════════════ -->
<section class="id-section id-section--alt" aria-labelledby="id-faq-title">
  <div class="id-wrap">
    <header style="text-align:center;margin-bottom:3rem;" class="id-reveal">
      <p class="id-eyebrow"><?php esc_html_e('Questions','themeflex'); ?></p>
      <h2 class="id-h2" id="id-faq-title"><?php esc_html_e('Frequently Asked','themeflex'); ?></h2>
    </header>
    <div class="id-faq-list">
      <?php
      $id_faqs = [
        ['How long does a full design project take?','Typically six to sixteen weeks from concept sign-off to final install, depending on project scale, contractor availability, and lead times on bespoke items. We'll give you a project-specific timeline at the concept stage.'],
        ['Do you work outside London?','Yes. While our studio is in West London, we regularly take on projects across the UK and Europe. For international projects, we charge travel and accommodation on top of the design fee.'],
        ['Can I buy furniture through you at trade prices?','Yes. As part of the Full Design Service and Retainer packages, clients benefit from our trade accounts with a broad range of suppliers — typically 15–30% below retail. We pass the full saving to you.'],
        ['I have an architect already — can you work with them?','Absolutely. We collaborate closely with architects, structural engineers, and contractors. Many clients come to us during the fit-out phase once the architecture is resolved. We're experienced at stepping into live projects.'],
        ['Do you offer virtual or remote consultations?','We offer our Consultation &amp; Concept package with a virtual option for clients outside the South East. Video calls and shared digital boards allow us to do excellent work remotely, though site visits add significant value where budgets allow.'],
        ['What if I only need help with one room?','Our Consultation &amp; Concept package is designed exactly for this. Many clients start with a single room and return to us for more — which we take as the best possible compliment.'],
      ];
      foreach ($id_faqs as $k => [$q, $a]):
        $faq_id = 'id-faq-'.$k;
      ?>
      <div class="id-faq" id="<?php echo esc_attr($faq_id); ?>">
        <button class="id-faq__q" aria-expanded="false" aria-controls="<?php echo esc_attr($faq_id.'-a'); ?>">
          <?php echo wp_kses_post($q); ?>
          <span class="id-faq__icon" aria-hidden="true">+</span>
        </button>
        <div class="id-faq__a" id="<?php echo esc_attr($faq_id.'-a'); ?>" role="region">
          <p class="id-faq__a-inner"><?php echo wp_kses_post($a); ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════════════════════════
     CTA BANNER
══════════════════════════════════════════════════════════════ -->
<section class="id-cta-banner id-reveal" aria-labelledby="id-cta-title">
  <div class="id-wrap" style="text-align:center;">
    <p class="id-eyebrow"><?php esc_html_e('Ready to Begin?','themeflex'); ?></p>
    <h2 class="id-h2" id="id-cta-title"><?php esc_html_e('Let\'s Create Something Beautiful','themeflex'); ?></h2>
    <p class="id-lead"><?php esc_html_e('Book a complimentary 30-minute discovery call. Tell us about your space, your vision, and your timeline — and we\'ll tell you how we can help.','themeflex'); ?></p>
    <div class="id-cta-banner__actions">
      <a href="#contact" class="id-btn id-btn--primary"><?php esc_html_e('Book Discovery Call','themeflex'); ?></a>
      <a href="<?php echo esc_url(home_url('/portfolio')); ?>" class="id-btn id-btn--ghost"><?php esc_html_e('View Full Portfolio','themeflex'); ?></a>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════════════════════════
     CONTACT
══════════════════════════════════════════════════════════════ -->
<section id="contact" class="id-section" aria-labelledby="id-contact-title">
  <div class="id-wrap">
    <div class="id-contact">
      <div class="id-contact__info id-reveal">
        <p class="id-eyebrow"><?php esc_html_e('Get In Touch','themeflex'); ?></p>
        <h2 class="id-h2" id="id-contact-title"><?php esc_html_e('Start Your Project','themeflex'); ?></h2>
        <p class="id-lead"><?php esc_html_e('Whether you have a clear brief or only a feeling, we'd love to hear from you. Initial consultations are complimentary and carry no obligation.','themeflex'); ?></p>
        <div class="id-contact__details">
          <?php
          $id_details = [
            ['📍','Studio Address','18 Elgin Crescent<br>Notting Hill, London W11 2JJ'],
            ['📞','Studio Phone','020 7946 0531'],
            ['✉️','Email','hello@maisoncollective.co.uk'],
            ['🕐','Studio Hours','Mon–Fri 9:00–18:00 | By appointment'],
          ];
          foreach ($id_details as [$icon, $label, $value]):
          ?>
          <div class="id-detail">
            <div class="id-detail__icon" aria-hidden="true"><?php echo $icon; ?></div>
            <div>
              <p class="id-detail__label"><?php echo esc_html($label); ?></p>
              <p class="id-detail__value"><?php echo wp_kses_post($value); ?></p>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="id-reveal" style="transition-delay:.15s">
        <form class="id-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" novalidate>
          <?php wp_nonce_field('tf_id_booking','tf_id_nonce'); ?>
          <input type="hidden" name="action" value="tf_id_enquiry">

          <div class="id-form-row">
            <div class="id-field">
              <label class="id-label" for="id-fname"><?php esc_html_e('First Name *','themeflex'); ?></label>
              <input class="id-input" id="id-fname" name="first_name" type="text" required autocomplete="given-name" placeholder="<?php esc_attr_e('Isabelle','themeflex'); ?>">
            </div>
            <div class="id-field">
              <label class="id-label" for="id-lname"><?php esc_html_e('Last Name *','themeflex'); ?></label>
              <input class="id-input" id="id-lname" name="last_name" type="text" required autocomplete="family-name" placeholder="<?php esc_attr_e('Renard','themeflex'); ?>">
            </div>
          </div>

          <div class="id-form-row">
            <div class="id-field">
              <label class="id-label" for="id-email"><?php esc_html_e('Email Address *','themeflex'); ?></label>
              <input class="id-input" id="id-email" name="email" type="email" required autocomplete="email" placeholder="<?php esc_attr_e('you@example.com','themeflex'); ?>">
            </div>
            <div class="id-field">
              <label class="id-label" for="id-phone"><?php esc_html_e('Phone Number','themeflex'); ?></label>
              <input class="id-input" id="id-phone" name="phone" type="tel" autocomplete="tel" placeholder="<?php esc_attr_e('+44 7700 000000','themeflex'); ?>">
            </div>
          </div>

          <div class="id-form-row">
            <div class="id-field">
              <label class="id-label" for="id-project-type"><?php esc_html_e('Project Type *','themeflex'); ?></label>
              <select class="id-select" id="id-project-type" name="project_type" required>
                <option value=""><?php esc_html_e('Select type…','themeflex'); ?></option>
                <option><?php esc_html_e('Residential — Full Home','themeflex'); ?></option>
                <option><?php esc_html_e('Residential — Single Room','themeflex'); ?></option>
                <option><?php esc_html_e('Commercial — Office','themeflex'); ?></option>
                <option><?php esc_html_e('Commercial — Hospitality','themeflex'); ?></option>
                <option><?php esc_html_e('Development / Investment','themeflex'); ?></option>
                <option><?php esc_html_e('Other','themeflex'); ?></option>
              </select>
            </div>
            <div class="id-field">
              <label class="id-label" for="id-budget"><?php esc_html_e('Approximate Budget','themeflex'); ?></label>
              <select class="id-select" id="id-budget" name="budget">
                <option value=""><?php esc_html_e('Select range…','themeflex'); ?></option>
                <option><?php esc_html_e('Under £5,000','themeflex'); ?></option>
                <option><?php esc_html_e('£5,000 – £15,000','themeflex'); ?></option>
                <option><?php esc_html_e('£15,000 – £50,000','themeflex'); ?></option>
                <option><?php esc_html_e('£50,000 – £150,000','themeflex'); ?></option>
                <option><?php esc_html_e('£150,000+','themeflex'); ?></option>
              </select>
            </div>
          </div>

          <div class="id-field">
            <label class="id-label" for="id-location"><?php esc_html_e('Project Location','themeflex'); ?></label>
            <input class="id-input" id="id-location" name="location" type="text" placeholder="<?php esc_attr_e('e.g. Chelsea, London','themeflex'); ?>">
          </div>

          <div class="id-field">
            <label class="id-label" for="id-message"><?php esc_html_e('Tell Us About Your Project *','themeflex'); ?></label>
            <textarea class="id-textarea" id="id-message" name="message" required rows="5" placeholder="<?php esc_attr_e('Describe your space, your vision, and your timeline…','themeflex'); ?>"></textarea>
          </div>

          <div class="id-form__submit">
            <button type="submit" class="id-btn id-btn--primary"><?php esc_html_e('Send Enquiry','themeflex'); ?></button>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════════════════════════
     FOOTER
══════════════════════════════════════════════════════════════ -->
<footer class="id-footer" role="contentinfo">
  <div class="id-wrap">
    <div class="id-footer__top">
      <div class="id-footer__brand">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="id-nav__logo">Maison <span>Collective</span></a>
        <p><?php esc_html_e('Award-winning interior design studio based in London. Residential and commercial projects across the UK and Europe.','themeflex'); ?></p>
      </div>
      <div>
        <p class="id-footer__col-title"><?php esc_html_e('Services','themeflex'); ?></p>
        <ul class="id-footer__links">
          <li><a href="#services"><?php esc_html_e('Residential Design','themeflex'); ?></a></li>
          <li><a href="#services"><?php esc_html_e('Commercial Interiors','themeflex'); ?></a></li>
          <li><a href="#services"><?php esc_html_e('Concept &amp; Styling','themeflex'); ?></a></li>
          <li><a href="#services"><?php esc_html_e('Art Curation','themeflex'); ?></a></li>
          <li><a href="#services"><?php esc_html_e('Lighting Design','themeflex'); ?></a></li>
        </ul>
      </div>
      <div>
        <p class="id-footer__col-title"><?php esc_html_e('Studio','themeflex'); ?></p>
        <ul class="id-footer__links">
          <li><a href="#about"><?php esc_html_e('About Us','themeflex'); ?></a></li>
          <li><a href="#portfolio"><?php esc_html_e('Portfolio','themeflex'); ?></a></li>
          <li><a href="#packages"><?php esc_html_e('Packages','themeflex'); ?></a></li>
          <li><a href="<?php echo esc_url(home_url('/journal')); ?>"><?php esc_html_e('Journal','themeflex'); ?></a></li>
          <li><a href="#contact"><?php esc_html_e('Press Enquiries','themeflex'); ?></a></li>
        </ul>
      </div>
      <div>
        <p class="id-footer__col-title"><?php esc_html_e('Follow','themeflex'); ?></p>
        <ul class="id-footer__links">
          <li><a href="#" rel="noopener noreferrer">Instagram</a></li>
          <li><a href="#" rel="noopener noreferrer">Pinterest</a></li>
          <li><a href="#" rel="noopener noreferrer">LinkedIn</a></li>
          <li><a href="#" rel="noopener noreferrer">Houzz</a></li>
        </ul>
      </div>
    </div>
    <div class="id-footer__bottom">
      <span>&copy; <?php echo esc_html(date('Y')); ?> <?php esc_html_e('Maison Collective Ltd. All rights reserved.','themeflex'); ?></span>
      <span><?php esc_html_e('BIID Member · AD100 · Dezeen Award Winner','themeflex'); ?></span>
    </div>
  </div>
</footer>

</div><!-- /.id-page -->

<script>
(function(){
  'use strict';

  /* ── Scroll reveal ─────────────────────────────────────── */
  var idRevealObs = new IntersectionObserver(function(entries){
    entries.forEach(function(e){
      if(e.isIntersecting){ e.target.classList.add('id-visible'); idRevealObs.unobserve(e.target); }
    });
  }, { threshold: 0.12 });
  document.querySelectorAll('.id-reveal').forEach(function(el){ idRevealObs.observe(el); });

  /* ── Animated counters ─────────────────────────────────── */
  var idEase = function(t){ return 1 - Math.pow(1 - t, 3); };
  var idCounterObs = new IntersectionObserver(function(entries){
    entries.forEach(function(e){
      if(!e.isIntersecting) return;
      var el   = e.target;
      var tgt  = parseFloat(el.dataset.target);
      if(isNaN(tgt)) return;
      var sfx  = el.querySelector('span') ? el.querySelector('span').textContent : '';
      var dur  = 1600;
      var start;
      (function tick(ts){
        if(!start) start = ts;
        var prog = Math.min((ts - start) / dur, 1);
        var val  = Math.round(idEase(prog) * tgt);
        el.textContent = val;
        var sp = document.createElement('span');
        sp.textContent = sfx;
        el.appendChild(sp);
        if(prog < 1) requestAnimationFrame(tick);
      })(performance.now());
      idCounterObs.unobserve(el);
    });
  }, { threshold: 0.5 });
  document.querySelectorAll('.id-stat__num[data-target]').forEach(function(el){ idCounterObs.observe(el); });

  /* ── FAQ accordion ─────────────────────────────────────── */
  document.querySelectorAll('.id-faq__q').forEach(function(btn){
    btn.addEventListener('click', function(){
      var faq   = btn.closest('.id-faq');
      var ans   = faq.querySelector('.id-faq__a');
      var inner = faq.querySelector('.id-faq__a-inner');
      var open  = faq.classList.contains('id-open');
      // close siblings
      document.querySelectorAll('.id-faq.id-open').forEach(function(f){
        var a = f.querySelector('.id-faq__a');
        a.style.maxHeight = '0';
        f.classList.remove('id-open');
        f.querySelector('.id-faq__q').setAttribute('aria-expanded','false');
      });
      if(!open){
        ans.style.maxHeight = inner.scrollHeight + 'px';
        faq.classList.add('id-open');
        btn.setAttribute('aria-expanded','true');
      }
    });
  });

  /* ── Sticky nav shadow ──────────────────────────────────── */
  var idNav = document.querySelector('.id-nav');
  window.addEventListener('scroll', function(){
    idNav.style.boxShadow = window.scrollY > 10 ? '0 4px 24px rgba(30,30,30,.1)' : '';
  }, { passive: true });

})();
</script>

<?php get_footer(); ?>
