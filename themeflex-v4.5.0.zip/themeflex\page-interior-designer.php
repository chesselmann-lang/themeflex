<?php
/**
 * Template Name: Interior Designer – Luxury Interior Design Studio
 * Description:   Premium ThemeFlex template for a luxury interior design studio.
 *                CSS art hero: a refined Chelsea drawing room at golden hour —
 *                arched sash windows with flooding afternoon light, a marble
 *                fireplace, herringbone floor, floating material swatches,
 *                CSS furniture silhouettes, and a moodboard montage.
 *                Namespace: --int-* | Fonts: Fraunces + DM Sans
 */
srand(crc32(get_the_permalink()));

/* ── Floating material swatch particles ──────────────────────────── */
$swatches = [];
for ($i = 0; $i < 16; $i++) {
    $swatches[] = [
        'left'  => rand(3, 95),
        'top'   => rand(8, 82),
        'w'     => rand(24, 56),
        'h'     => rand(18, 42),
        'delay' => rand(0, 80) / 10,
        'dur'   => rand(70, 140) / 10,
        'hue'   => [28, 195, 45, 0, 270, 180, 35][rand(0, 6)],
        'sat'   => rand(18, 55),
        'lit'   => rand(60, 82),
    ];
}

/* ── Services ─────────────────────────────────────────────────────── */
$services = [
    ['icon'=>'◈','title'=>'Full Interior Design','desc'=>'End-to-end interior design — from initial brief and concept development through specification, procurement, and on-site project management to final installation and styling.','from'=>'POA'],
    ['icon'=>'✦','title'=>'Design Consultation','desc'=>'A focused 90-minute session in your home. We assess the space, discuss your vision, and provide immediate recommendations for colour, layout, lighting, and furnishing direction.','from'=>'£350'],
    ['icon'=>'◇','title'=>'Space Planning','desc'=>'Detailed floor plans and furniture layout proposals, optimising traffic flow, natural light, and the relationship between functional zones within your home.','from'=>'From £650'],
    ['icon'=>'❋','title'=>'Kitchen & Bath Design','desc'=>'Bespoke kitchen and bathroom design with detailed drawings, specification of units, worktops, tiles, fixtures, and full contractor coordination.','from'=>'From £1,800'],
    ['icon'=>'✧','title'=>'Furniture & Procurement','desc'=>'Access to our trade-exclusive suppliers, careful selection of furniture and soft furnishings, and white-glove delivery and installation.','from'=>'From £900'],
    ['icon'=>'◉','title'=>'Styling & Staging','desc'=>'Transform your existing space or prepare a property for sale or photography — art curation, accessory layering, lighting adjustment, and finishing touches.','from'=>'From £650'],
];

/* ── Portfolio projects ───────────────────────────────────────────── */
$projects = [
    ['name'=>'The Chelsea Townhouse','type'=>'Residential · Full Design','rooms'=>6,'duration'=>'9 months','palette'=>'Sage & Aged Brass'],
    ['name'=>'Holland Park Apartment','type'=>'Residential · Refresh','rooms'=>4,'duration'=>'4 months','palette'=>'Plaster Pink & Walnut'],
    ['name'=>'Marylebone Pied-à-Terre','type'=>'Residential · Full Design','rooms'=>3,'duration'=>'5 months','palette'=>'Navy & Aged Gold'],
    ['name'=>'Cotswolds Farmhouse','type'=>'Residential · Full Design','rooms'=>10,'duration'=>'14 months','palette'=>'Stone & Natural Linen'],
    ['name'=>'Soho Members Club','type'=>'Commercial · Full Design','rooms'=>12,'duration'=>'18 months','palette'=>'Midnight & Emerald'],
    ['name'=>'Richmond Boutique Hotel','type'=>'Hospitality · Full Design','rooms'=>28,'duration'=>'24 months','palette'=>'Terracotta & Ochre'],
];

/* ── Process ─────────────────────────────────────────────────────── */
$process = [
    ['num'=>'01','title'=>'Discovery','desc'=>'We meet in your home or our studio to understand how you live, your aesthetic references, budget, and timeline.'],
    ['num'=>'02','title'=>'Concept','desc'=>'Mood boards, material palettes, and initial spatial proposals — refined until you\'re completely confident in the direction.'],
    ['num'=>'03','title'=>'Design Development','desc'=>'Detailed drawings, specifications, and procurement schedules. Every item sourced, every finish confirmed before a single contractor is engaged.'],
    ['num'=>'04','title'=>'Realisation','desc'=>'We manage the entire project — contractors, deliveries, and installations — bringing your vision to life with precision and care.'],
];

/* ── Stats ────────────────────────────────────────────────────────── */
$stats = [
    ['val'=>'140','label'=>'Projects Completed','suffix'=>'+'],
    ['val'=>'15','label'=>'Years of Design','suffix'=>'yrs'],
    ['val'=>'4.9','label'=>'Client Rating','suffix'=>'★'],
    ['val'=>'8','label'=>'Design Awards','suffix'=>''],
];

/* ── Testimonials ─────────────────────────────────────────────────── */
$testimonials = [
    ['quote'=>'Working with Henrietta transformed our home beyond what we imagined possible. The attention to detail, the material knowledge, and the calm management of a complex project were extraordinary.','name'=>'William & Anna F.','role'=>'Chelsea Townhouse, London'],
    ['quote'=>'Our boutique hotel is exactly what we dreamed of — intimate, atmospheric, and completely original. Guests comment on the design constantly. Worth every penny.','name'=>'James H.','role'=>'General Manager, The Richmond'],
    ['quote'=>'The consultation alone was worth it. Henrietta immediately identified solutions we\'d been circling for months. Her knowledge of material, proportion, and light is remarkable.','name'=>'Sophie L.','role'=>'Holland Park, London'],
];

/* ── FAQs ─────────────────────────────────────────────────────────── */
$faqs = [
    ['q'=>'What does a full interior design service involve?','a'=>'Full design covers concept development, detailed drawings, material and furniture specification, procurement, contractor coordination, and on-site project management through to final installation and styling. We act as the single point of contact for your entire project.'],
    ['q'=>'Do you work with clients\' existing contractors?','a'=>'Yes — we can work with your existing building contractor or connect you with trusted trades from our established network, depending on your preference and project scale.'],
    ['q'=>'How do you charge for your services?','a'=>'Design fees are charged as a percentage of total project value or as a fixed design fee agreed at the outset. Procurement carries a trade margin. All fees are discussed transparently during your initial consultation.'],
    ['q'=>'Do you take on projects outside London?','a'=>'Yes — we work across the UK and internationally. Our studio is based in Chelsea but we manage projects in the Cotswolds, Edinburgh, the Channel Islands, and in Europe. Travel costs are discussed during briefing.'],
    ['q'=>'Can you work within a tight budget?','a'=>'Yes. We work with clients at a range of budgets, always prioritising the elements that deliver the greatest impact. We\'re transparent about where investment pays off and where budget can be redirected.'],
];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,700;1,9..144,400&family=DM+Sans:wght@300;400;500;700&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════════════════
   THEMEFLEX – INTERIOR DESIGN STUDIO  (--int-* namespace)
═══════════════════════════════════════════════════════════════════ */
:root{
  --int-clay:    #E8DDD0;
  --int-warm:    #F5EFE8;
  --int-ivory:   #FAF7F3;
  --int-stone:   #C8BCA8;
  --int-sage:    #7A9078;
  --int-sage-dk: #5A6E58;
  --int-rust:    #B06848;
  --int-terr:    #C88060;
  --int-dark:    #221C16;
  --int-charcoal:#3A3028;
  --int-gold:    #C49840;
  --int-navy:    #1A2840;
  --int-border:  rgba(58,48,40,.12);
  --int-border-lt:rgba(196,152,64,.15);
  --int-r:       0px;
  --int-shadow:  0 8px 40px rgba(34,28,22,.10);
  --int-font-h:  'Fraunces', Georgia, serif;
  --int-font-b:  'DM Sans', system-ui, sans-serif;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body.page-template-page-interior-designer{
  background:var(--int-ivory);
  color:var(--int-charcoal);
  font-family:var(--int-font-b);
  font-size:16px;
  line-height:1.7;
}

/* ── Utility ─────────────────────────────────────────────────────── */
.int-wrap{max-width:1200px;margin:0 auto;padding:0 clamp(16px,4vw,48px)}
.int-badge{display:inline-block;font-family:var(--int-font-b);font-size:.72rem;font-weight:500;letter-spacing:.2em;text-transform:uppercase;color:var(--int-rust);margin-bottom:1.1rem}
.int-h1{font-family:var(--int-font-h);font-size:clamp(2.8rem,5.5vw,4.8rem);font-weight:400;line-height:1.15;color:var(--int-dark);letter-spacing:-.01em}
.int-h2{font-family:var(--int-font-h);font-size:clamp(2rem,4vw,3.4rem);font-weight:400;line-height:1.2;color:var(--int-dark)}
.int-h3{font-family:var(--int-font-h);font-size:1.35rem;font-weight:400;color:var(--int-dark)}
.int-lead{font-size:clamp(.96rem,1.5vw,1.08rem);color:var(--int-charcoal);opacity:.8;line-height:1.82;max-width:620px}
.int-btn{display:inline-block;padding:.85em 2.2em;font-family:var(--int-font-b);font-size:.84rem;font-weight:500;letter-spacing:.1em;text-transform:uppercase;text-decoration:none;cursor:pointer;border:none;transition:all .3s ease}
.int-btn-dark{background:var(--int-dark);color:var(--int-ivory)}
.int-btn-dark:hover{background:var(--int-charcoal);transform:translateY(-2px);box-shadow:0 8px 24px rgba(34,28,22,.25)}
.int-btn-outline{background:transparent;color:var(--int-dark);border:1px solid var(--int-border)}
.int-btn-outline:hover{background:var(--int-clay)}
.int-btn-rust{background:var(--int-rust);color:#fff}
.int-btn-rust:hover{background:var(--int-terr);transform:translateY(-2px)}
.int-section{padding:clamp(64px,9vw,120px) 0}
.int-section-clay{background:var(--int-clay)}
.int-section-warm{background:var(--int-warm)}
.int-section-dark{background:var(--int-dark);color:var(--int-ivory)}
.int-divider{width:1px;height:48px;background:var(--int-stone);margin:1.4rem 0 2rem}
.int-center{text-align:center}
.int-center .int-divider{margin-left:auto;margin-right:auto;width:48px;height:1px;background:var(--int-stone);display:block}
.int-rule{width:100%;height:1px;background:var(--int-border);margin:2rem 0}

/* ── NAV ─────────────────────────────────────────────────────────── */
.int-nav{
  position:fixed;top:0;left:0;right:0;z-index:999;
  background:rgba(250,247,243,.96);
  backdrop-filter:blur(16px);
  border-bottom:1px solid var(--int-border);
  padding:0 clamp(16px,4vw,48px);
}
.int-nav-inner{
  display:flex;align-items:center;justify-content:space-between;
  max-width:1200px;margin:0 auto;height:72px;
}
.int-logo{font-family:var(--int-font-h);font-size:1.2rem;font-weight:400;color:var(--int-dark);text-decoration:none;letter-spacing:.04em}
.int-logo span{color:var(--int-rust)}
.int-nav-links{display:flex;gap:2.4rem;list-style:none}
.int-nav-links a{font-size:.78rem;font-weight:500;letter-spacing:.15em;text-transform:uppercase;color:var(--int-charcoal);text-decoration:none;transition:color .22s}
.int-nav-links a:hover{color:var(--int-rust)}
.int-nav-cta{display:flex;gap:.8rem;align-items:center}

/* ── HERO ────────────────────────────────────────────────────────── */
.int-hero{
  position:relative;min-height:100vh;display:flex;align-items:center;
  overflow:hidden;padding-top:72px;
  background:linear-gradient(145deg,#F2E8DA 0%,#EDE0CE 40%,#F5EDE0 100%);
}

/* CSS room scene */
.int-hero-scene{position:absolute;inset:0;overflow:hidden;pointer-events:none;z-index:1}

/* Parquet herringbone floor */
.int-floor{
  position:absolute;bottom:0;left:0;right:0;height:35%;
  background:linear-gradient(180deg,#C8A870 0%,#B89060 60%,#A88050 100%);
}
.int-floor::before{
  content:'';position:absolute;inset:0;
  background:
    repeating-linear-gradient(45deg,transparent,transparent 16px,rgba(255,255,255,.05) 16px,rgba(255,255,255,.05) 17px),
    repeating-linear-gradient(-45deg,transparent,transparent 16px,rgba(0,0,0,.05) 16px,rgba(0,0,0,.05) 17px);
}

/* Plaster walls */
.int-wall{
  position:absolute;top:0;left:0;right:0;bottom:35%;
  background:linear-gradient(180deg,#F2EDE5 0%,#E8E0D4 100%);
}
/* Wall dado rail */
.int-wall::before{
  content:'';position:absolute;bottom:25%;left:0;right:0;height:8px;
  background:linear-gradient(90deg,rgba(200,180,148,.6),rgba(220,200,168,.8),rgba(200,180,148,.6));
  border-top:1px solid rgba(200,180,148,.4);
  border-bottom:1px solid rgba(200,180,148,.4);
}
/* Cornicing */
.int-wall::after{
  content:'';position:absolute;top:0;left:0;right:0;height:20px;
  background:linear-gradient(180deg,rgba(255,255,255,.5),transparent);
  border-bottom:1px solid rgba(200,180,148,.3);
}

/* Arched sash windows */
.int-window{
  position:absolute;top:8%;
  width:110px;height:68%;
  background:linear-gradient(145deg,rgba(255,240,200,.75) 0%,rgba(255,230,160,.45) 50%,rgba(255,240,200,.7) 100%);
  border:4px solid rgba(200,180,148,.5);
  border-bottom:none;
}
.int-window::before{/* arch top */
  content:'';position:absolute;top:-30px;left:-4px;right:-4px;height:56px;
  background:rgba(255,240,200,.6);
  border-radius:50%;
  border:4px solid rgba(200,180,148,.5);
}
.int-window::after{/* glazing bar */
  content:'';position:absolute;inset:0;
  background:
    linear-gradient(90deg,transparent 48%,rgba(200,180,148,.4) 48%,rgba(200,180,148,.4) 52%,transparent 52%),
    linear-gradient(180deg,transparent 48%,rgba(200,180,148,.4) 48%,rgba(200,180,148,.4) 52%,transparent 52%);
}
/* Light shaft from window */
.int-light-shaft{
  position:absolute;
  background:linear-gradient(180deg,rgba(255,240,180,.18) 0%,rgba(255,240,180,.06) 60%,transparent 100%);
  pointer-events:none;
}
.int-win-1{left:4%}
.int-win-2{left:22%;opacity:.7}
.int-win-3{right:4%}

/* Marble fireplace */
.int-fireplace{
  position:absolute;bottom:35%;left:50%;transform:translateX(-50%);
  width:180px;
  z-index:3;
}
.int-fp-mantel{
  position:absolute;bottom:0;left:-16px;right:-16px;height:16px;
  background:linear-gradient(180deg,#F8F4F0,#E8E4E0);
  border-top:2px solid rgba(200,190,180,.6);
}
.int-fp-surround{
  position:absolute;bottom:16px;left:0;right:0;height:90px;
  background:linear-gradient(145deg,#F2EEE8,#E8E4DC);
  border:3px solid rgba(200,190,180,.5);
}
.int-fp-surround::before{/* pilasters */
  content:'';position:absolute;inset:0;
  background:
    linear-gradient(90deg,rgba(200,190,180,.3) 0%,transparent 10%,transparent 90%,rgba(200,190,180,.3) 100%);
}
.int-fp-opening{
  position:absolute;bottom:16px;left:20px;right:20px;height:70px;
  background:linear-gradient(145deg,#2A1E12,#1A1008);
  border-radius:0;
}
/* Fire glow */
.int-fp-opening::before{
  content:'';position:absolute;bottom:0;left:10%;right:10%;height:40%;
  background:radial-gradient(ellipse at 50% 100%,rgba(255,120,40,.5),rgba(255,80,20,.3),transparent);
  animation:int-flicker 1.8s ease-in-out infinite alternate;
}
.int-fp-hearth{
  position:absolute;bottom:10px;left:-8px;right:-8px;height:10px;
  background:linear-gradient(90deg,#E8E0D0,#F0E8D8,#E8E0D0);
}

/* Armchair (CSS silhouette) */
.int-armchair{
  position:absolute;bottom:35%;
  width:90px;height:68px;
  z-index:4;
}
.int-chair-seat{
  position:absolute;bottom:0;left:0;right:0;height:28px;
  background:linear-gradient(145deg,#8A6848,#6A4828);
  border-radius:4px 4px 0 0;
}
.int-chair-back{
  position:absolute;bottom:28px;left:4px;right:4px;height:46px;
  background:linear-gradient(145deg,#7A5838,#5A3818);
  border-radius:6px 6px 0 0;
}
.int-chair-arm-l,.int-chair-arm-r{
  position:absolute;bottom:0;width:12px;height:44px;
  background:linear-gradient(180deg,#8A6848,#6A4828);
  border-radius:6px 6px 0 0;
}
.int-chair-arm-l{left:0}
.int-chair-arm-r{right:0}
.int-chair-leg{
  position:absolute;bottom:-12px;width:8px;height:12px;
  background:linear-gradient(180deg,#5A4030,#3A2818);
  border-radius:0 0 2px 2px;
}
.int-chair-leg-1{left:8px}
.int-chair-leg-2{right:8px}
.int-chair-1{left:8%}
.int-chair-2{right:8%;transform:scaleX(-1)}

/* Side table */
.int-table{
  position:absolute;bottom:35%;
  width:50px;height:44px;
  z-index:3;
}
.int-table-top{
  position:absolute;top:0;left:0;right:0;height:8px;
  background:linear-gradient(90deg,#C8A870,#D8B880,#C8A870);
  border-radius:2px;
}
.int-table-leg-l,.int-table-leg-r{
  position:absolute;top:8px;width:4px;height:36px;
  background:#A88050;
  border-radius:0 0 2px 2px;
}
.int-table-leg-l{left:6px}
.int-table-leg-r{right:6px}
/* Vase on table */
.int-vase{
  position:absolute;top:-28px;left:50%;transform:translateX(-50%);
  width:16px;height:28px;
  background:linear-gradient(145deg,#6A8888,#4A6868);
  border-radius:50% 50% 40% 40%/60% 60% 40% 40%;
}
.int-table-1{left:20%}
.int-table-2{right:22%}

/* Decorative wall panel lines */
.int-panel{
  position:absolute;top:30%;
  border:1px solid rgba(200,180,148,.3);
}

/* Floating swatches */
.int-swatch{position:absolute;pointer-events:none;border-radius:2px}

/* Keyframes */
@keyframes int-flicker{0%{opacity:.5}100%{opacity:.9}}
@keyframes int-swatch-float{0%,100%{transform:translateY(0) rotate(var(--r))}50%{transform:translateY(-14px) rotate(calc(var(--r) + 5deg))}}
@keyframes int-float{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
@keyframes int-fade-up{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:none}}
@keyframes int-shine{0%{left:-40%}100%{left:140%}}
@keyframes int-counter-up{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}

/* ── Hero content ─────────────────────────────────────────────────── */
.int-hero-content{
  position:relative;z-index:2;
  display:grid;grid-template-columns:1fr 1fr;gap:clamp(40px,6vw,80px);align-items:center;
  max-width:1200px;margin:0 auto;
  padding:clamp(48px,8vw,100px) clamp(16px,4vw,48px);
  width:100%;
}
.int-hero-text .int-h1{margin-bottom:1.4rem}
.int-hero-text .int-h1 em{color:var(--int-rust);font-style:italic}
.int-hero-text .int-lead{margin-bottom:2.2rem}
.int-hero-actions{display:flex;gap:1rem;flex-wrap:wrap;margin-bottom:2.4rem}
.int-hero-meta{display:flex;gap:1.8rem;flex-wrap:wrap}
.int-meta-item{font-size:.75rem;font-weight:500;letter-spacing:.12em;text-transform:uppercase;color:rgba(58,48,40,.55)}

/* Hero visual card */
.int-hero-visual{
  position:relative;height:520px;
  display:flex;align-items:flex-end;justify-content:center;
}
.int-room-card{
  position:relative;width:100%;height:480px;
  background:linear-gradient(145deg,#F2E8DA,#E8DDD0);
  overflow:hidden;
  border:1px solid rgba(200,180,148,.3);
  box-shadow:0 24px 80px rgba(34,28,22,.12);
}
/* Card floor */
.int-rc-floor{
  position:absolute;bottom:0;left:0;right:0;height:32%;
  background:linear-gradient(180deg,#C8A870,#B08858);
}
.int-rc-floor::before{
  content:'';position:absolute;inset:0;
  background:repeating-linear-gradient(45deg,transparent,transparent 10px,rgba(255,255,255,.04) 10px,rgba(255,255,255,.04) 11px),
             repeating-linear-gradient(-45deg,transparent,transparent 10px,rgba(0,0,0,.04) 10px,rgba(0,0,0,.04) 11px);
}
/* Card wall */
.int-rc-wall{
  position:absolute;top:0;left:0;right:0;bottom:32%;
  background:linear-gradient(180deg,#F0EAE0,#E8E0D4);
}
/* Card window */
.int-rc-win{
  position:absolute;top:6%;right:8%;width:80px;height:64%;
  background:rgba(255,240,200,.7);
  border:3px solid rgba(200,180,148,.4);
  border-bottom:none;
}
.int-rc-win::before{
  content:'';position:absolute;top:-24px;left:-3px;right:-3px;height:42px;
  background:rgba(255,240,200,.6);
  border-radius:50%;
  border:3px solid rgba(200,180,148,.4);
}
/* Card light shaft */
.int-rc-shaft{
  position:absolute;top:6%;right:10%;
  width:60px;height:90%;
  background:linear-gradient(180deg,rgba(255,240,180,.2) 0%,transparent 100%);
  clip-path:polygon(20% 0%,80% 0%,100% 100%,0% 100%);
}
/* Card fireplace */
.int-rc-fp{
  position:absolute;bottom:32%;left:50%;transform:translateX(-50%);
  width:100px;
}
.int-rc-mantel{position:absolute;bottom:0;left:-8px;right:-8px;height:10px;background:#F0EAE0;border-top:2px solid rgba(200,190,180,.5)}
.int-rc-surround{position:absolute;bottom:10px;left:0;right:0;height:60px;background:#EAEAE2;border:2px solid rgba(200,190,180,.4)}
.int-rc-opening{position:absolute;bottom:10px;left:12px;right:12px;height:46px;background:linear-gradient(145deg,#2A1E12,#1A1008)}
.int-rc-opening::before{content:'';position:absolute;bottom:0;left:10%;right:10%;height:40%;background:radial-gradient(ellipse at 50% 100%,rgba(255,120,40,.5),transparent);animation:int-flicker 2s ease-in-out infinite alternate}
/* Card chair */
.int-rc-chair{
  position:absolute;bottom:32%;left:8%;
  width:60px;height:48px;
}
.int-rcc-seat{position:absolute;bottom:0;left:0;right:0;height:18px;background:linear-gradient(145deg,#8A6848,#6A4828);border-radius:3px 3px 0 0}
.int-rcc-back{position:absolute;bottom:18px;left:3px;right:3px;height:32px;background:linear-gradient(145deg,#7A5838,#5A3818);border-radius:4px 4px 0 0}
.int-rcc-arm-l{position:absolute;bottom:0;left:0;width:8px;height:28px;background:#8A6848;border-radius:4px 4px 0 0}
.int-rcc-arm-r{position:absolute;bottom:0;right:0;width:8px;height:28px;background:#8A6848;border-radius:4px 4px 0 0}
/* Floating badge */
.int-float-badge{
  position:absolute;top:8%;left:3%;
  background:var(--int-ivory);border:1px solid var(--int-border);padding:.7rem 1.1rem;
  box-shadow:0 8px 32px rgba(34,28,22,.10);
  animation:int-float 5s ease-in-out infinite;
  font-family:var(--int-font-b);font-size:.78rem;
  display:flex;align-items:center;gap:.6rem;
}
.int-float-badge-text strong{display:block;font-size:.9rem;color:var(--int-dark);font-family:var(--int-font-h);font-weight:400}
.int-float-badge-text span{color:rgba(58,48,40,.55)}

/* ── STATS BAR ─────────────────────────────────────────────────────── */
.int-stats-bar{
  background:var(--int-dark);
  padding:clamp(36px,5vw,60px) 0;
}
.int-stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:2rem;text-align:center}
.int-stat-num{font-family:var(--int-font-h);font-size:clamp(2rem,4vw,3.2rem);font-weight:400;color:var(--int-terr);line-height:1;margin-bottom:.3rem}
.int-stat-label{font-size:.72rem;font-weight:500;letter-spacing:.15em;text-transform:uppercase;color:rgba(245,240,232,.45)}

/* ── SERVICES ─────────────────────────────────────────────────────── */
.int-services-grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:1px;
  background:var(--int-border);border:1px solid var(--int-border);
  margin-top:clamp(36px,5vw,56px);
}
.int-service-card{
  background:var(--int-ivory);padding:clamp(24px,3vw,40px);
  transition:background .28s;
  position:relative;overflow:hidden;
}
.int-service-card::after{
  content:'';position:absolute;top:0;bottom:0;width:30%;
  background:linear-gradient(90deg,transparent,rgba(196,152,64,.05),transparent);
  left:-30%;animation:int-shine 7s ease-in-out infinite;
  animation-delay:calc(var(--i)*1.4s);
}
.int-service-card:hover{background:#fff}
.int-svc-icon{font-size:1.6rem;color:var(--int-rust);margin-bottom:1.2rem}
.int-svc-title{font-family:var(--int-font-h);font-size:1.2rem;font-weight:400;color:var(--int-dark);margin-bottom:.7rem}
.int-svc-desc{font-size:.88rem;line-height:1.78;color:var(--int-charcoal);opacity:.8;margin-bottom:1rem}
.int-svc-from{font-size:.78rem;font-weight:500;letter-spacing:.12em;text-transform:uppercase;color:var(--int-sage)}

/* ── PORTFOLIO GRID ────────────────────────────────────────────────── */
.int-portfolio-grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:2px;
  margin-top:clamp(36px,5vw,56px);
}
.int-portfolio-card{
  position:relative;height:260px;overflow:hidden;
  cursor:pointer;
  transition:transform .3s ease;
}
.int-portfolio-card:hover{transform:scale(.98)}
.int-portfolio-card:first-child,.int-portfolio-card:nth-child(4){grid-row:span 2;height:auto}
/* CSS room scene for portfolio cards */
.int-pc-scene{
  position:absolute;inset:0;
  display:flex;align-items:flex-end;
  overflow:hidden;
}
.int-pc-floor{
  position:absolute;bottom:0;left:0;right:0;height:38%;
}
.int-pc-wall{position:absolute;top:0;left:0;right:0;bottom:38%}
.int-pc-overlay{
  position:absolute;inset:0;
  background:linear-gradient(180deg,transparent 40%,rgba(34,28,22,.7) 100%);
  transition:opacity .3s ease;
}
.int-portfolio-card:hover .int-pc-overlay{opacity:.85}
.int-pc-label{
  position:absolute;bottom:0;left:0;right:0;padding:1.2rem 1.4rem;
  transform:translateY(8px);transition:transform .3s ease;
}
.int-portfolio-card:hover .int-pc-label{transform:translateY(0)}
.int-pc-name{font-family:var(--int-font-h);font-size:1.05rem;font-weight:400;color:#fff;margin-bottom:.2rem}
.int-pc-type{font-size:.72rem;font-weight:500;letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.65)}
.int-pc-palette{font-size:.76rem;color:rgba(255,255,255,.5);margin-top:.3rem;font-style:italic;font-family:var(--int-font-h)}

/* ── PROCESS ──────────────────────────────────────────────────────── */
.int-process-grid{
  display:grid;grid-template-columns:repeat(4,1fr);gap:2.4rem;
  margin-top:clamp(36px,5vw,56px);
}
.int-process-step{
  position:relative;
  padding-top:1.2rem;
  border-top:1px solid var(--int-border);
}
.int-step-num{
  font-family:var(--int-font-h);font-size:2.8rem;font-weight:400;color:rgba(196,152,64,.3);
  line-height:1;margin-bottom:1rem;
}
.int-step-title{font-family:var(--int-font-h);font-size:1.1rem;font-weight:400;color:var(--int-dark);margin-bottom:.6rem}
.int-step-desc{font-size:.86rem;color:var(--int-charcoal);opacity:.78;line-height:1.72}

/* ── TESTIMONIALS ─────────────────────────────────────────────────── */
.int-testi-grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:1px;
  background:var(--int-border);border:1px solid var(--int-border);
  margin-top:clamp(36px,5vw,56px);
}
.int-testi-card{
  background:var(--int-ivory);padding:clamp(24px,3vw,40px);
  position:relative;
}
.int-testi-stars{color:var(--int-gold);font-size:.9rem;letter-spacing:.1em;margin-bottom:1rem}
.int-testi-quote{font-family:var(--int-font-h);font-size:1.02rem;font-style:italic;color:var(--int-charcoal);line-height:1.8;margin-bottom:1.2rem}
.int-testi-author{font-weight:500;font-size:.84rem;color:var(--int-dark)}
.int-testi-role{font-size:.76rem;color:var(--int-rust);font-weight:500;text-transform:uppercase;letter-spacing:.08em}

/* ── FAQ ──────────────────────────────────────────────────────────── */
.int-faq-list{max-width:740px;margin:clamp(32px,5vw,56px) auto 0;display:flex;flex-direction:column;gap:1px;border:1px solid var(--int-border)}
.int-faq-item{background:#fff}
.int-faq-q{
  width:100%;background:none;border:none;cursor:pointer;
  display:flex;justify-content:space-between;align-items:center;
  padding:1.1rem 1.5rem;text-align:left;
  font-family:var(--int-font-h);font-size:1rem;font-weight:400;color:var(--int-dark);
  border-bottom:1px solid transparent;
}
.int-faq-q::after{content:'+';font-size:1.3rem;font-weight:300;color:var(--int-rust);flex-shrink:0;margin-left:1rem;transition:transform .28s ease}
.int-faq-item.open .int-faq-q::after{transform:rotate(45deg)}
.int-faq-item.open .int-faq-q{border-bottom-color:var(--int-border)}
.int-faq-a{max-height:0;overflow:hidden;transition:max-height .4s ease}
.int-faq-a-inner{padding:.3rem 1.5rem 1.3rem;font-size:.88rem;color:var(--int-charcoal);line-height:1.8}
.int-faq-item.open .int-faq-a{max-height:260px}

/* ── ENQUIRY ──────────────────────────────────────────────────────── */
.int-enquiry-wrap{
  display:grid;grid-template-columns:1fr 1fr;gap:clamp(48px,6vw,80px);align-items:start;
}
.int-form-card{
  background:var(--int-ivory);border:1px solid var(--int-border);padding:clamp(28px,4vw,48px);
}
.int-form-group{display:flex;flex-direction:column;gap:.4rem;margin-bottom:.9rem}
.int-form-group label{font-size:.72rem;font-weight:500;letter-spacing:.15em;text-transform:uppercase;color:var(--int-charcoal)}
.int-form-group input,.int-form-group select,.int-form-group textarea{
  border:1px solid var(--int-border);border-radius:0;
  padding:.75em 1em;font-family:var(--int-font-b);font-size:.9rem;
  color:var(--int-charcoal);background:#fff;
  transition:border-color .22s;outline:none;
}
.int-form-group input:focus,.int-form-group select:focus,.int-form-group textarea:focus{border-color:var(--int-rust)}
.int-form-group textarea{resize:vertical;min-height:110px}
.int-form-row{display:grid;grid-template-columns:1fr 1fr;gap:1rem}

/* ── FOOTER ───────────────────────────────────────────────────────── */
.int-footer{
  background:var(--int-dark);color:rgba(245,240,232,.55);
  padding:clamp(48px,7vw,80px) 0 clamp(24px,3vw,40px);
}
.int-footer-grid{display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:clamp(24px,4vw,56px);margin-bottom:3rem}
.int-footer-desc{font-size:.84rem;line-height:1.8;margin-top:1rem;max-width:280px}
.int-footer-col h4{font-family:var(--int-font-h);font-size:.95rem;font-weight:400;color:rgba(245,240,232,.85);margin-bottom:1rem;letter-spacing:.06em}
.int-footer-col ul{list-style:none;display:flex;flex-direction:column;gap:.65rem}
.int-footer-col ul li a{font-size:.82rem;color:rgba(245,240,232,.45);text-decoration:none;transition:color .2s}
.int-footer-col ul li a:hover{color:var(--int-terr)}
.int-footer-bottom{border-top:1px solid rgba(245,240,232,.08);padding-top:1.5rem;display:flex;justify-content:space-between;font-size:.76rem;color:rgba(245,240,232,.28);flex-wrap:wrap;gap:.8rem}
.int-footer-bottom a{color:rgba(245,240,232,.28);text-decoration:none}
.int-footer-bottom a:hover{color:var(--int-terr)}

/* ── RESPONSIVE ───────────────────────────────────────────────────── */
@media(max-width:1024px){
  .int-services-grid{grid-template-columns:repeat(2,1fr)}
  .int-portfolio-grid{grid-template-columns:repeat(2,1fr)}
  .int-portfolio-card:first-child,.int-portfolio-card:nth-child(4){grid-row:span 1;height:260px}
  .int-process-grid{grid-template-columns:repeat(2,1fr)}
  .int-testi-grid{grid-template-columns:1fr}
  .int-stats-grid{grid-template-columns:repeat(2,1fr)}
  .int-footer-grid{grid-template-columns:1fr 1fr}
  .int-hero-content{grid-template-columns:1fr}
  .int-hero-visual{display:none}
  .int-enquiry-wrap{grid-template-columns:1fr}
}
@media(max-width:640px){
  .int-services-grid{grid-template-columns:1fr}
  .int-portfolio-grid{grid-template-columns:1fr}
  .int-process-grid{grid-template-columns:1fr}
  .int-form-row{grid-template-columns:1fr}
  .int-footer-grid{grid-template-columns:1fr}
  .int-nav-links,.int-nav-cta{display:none}
}
</style>
<?php get_header(); ?>
<div class="page-template-page-interior-designer">
>

<!-- ══ NAVIGATION ══════════════════════════════════════════════════ -->
<nav class="int-nav" role="navigation" aria-label="Main navigation">
  <div class="int-nav-inner">
    <a href="<?php echo esc_url(home_url('/')); ?>" class="int-logo">
      Henrietta<span>&nbsp;Bell</span>
    </a>
    <ul class="int-nav-links">
      <li><a href="#services">Services</a></li>
      <li><a href="#portfolio">Portfolio</a></li>
      <li><a href="#process">Process</a></li>
      <li><a href="#testimonials">Testimonials</a></li>
      <li><a href="#enquiry">Enquire</a></li>
    </ul>
    <div class="int-nav-cta">
      <a href="tel:02073007890" class="int-btn int-btn-outline" style="padding:.55em 1.2em;font-size:.76rem">020 7300 7890</a>
      <a href="#enquiry" class="int-btn int-btn-dark" style="padding:.55em 1.4em;font-size:.76rem">Book a Consultation</a>
    </div>
  </div>
</nav>

<!-- ══ HERO ════════════════════════════════════════════════════════ -->
<section class="int-hero" aria-label="Interior design studio hero">

  <!-- Full CSS room scene -->
  <div class="int-hero-scene" aria-hidden="true">
    <!-- Floor & wall -->
    <div class="int-floor"></div>
    <div class="int-wall"></div>

    <!-- Windows -->
    <div class="int-window int-win-1"></div>
    <div class="int-window int-win-2"></div>
    <div class="int-window int-win-3"></div>

    <!-- Light shafts -->
    <div class="int-light-shaft" style="left:5%;top:8%;width:90px;height:88%;background:linear-gradient(170deg,rgba(255,240,180,.12) 0%,transparent 100%);clip-path:polygon(15% 0%,85% 0%,100% 100%,0% 100%)"></div>
    <div class="int-light-shaft" style="right:5%;top:8%;width:90px;height:88%;background:linear-gradient(190deg,rgba(255,240,180,.10) 0%,transparent 100%);clip-path:polygon(0% 0%,100% 0%,85% 100%,15% 100%)"></div>

    <!-- Fireplace -->
    <div class="int-fireplace">
      <div class="int-fp-hearth"></div>
      <div class="int-fp-surround"></div>
      <div class="int-fp-opening"></div>
      <div class="int-fp-mantel"></div>
    </div>

    <!-- Armchairs -->
    <div class="int-armchair int-chair-1">
      <div class="int-chair-back"></div>
      <div class="int-chair-seat"></div>
      <div class="int-chair-arm-l"></div>
      <div class="int-chair-arm-r"></div>
      <div class="int-chair-leg int-chair-leg-1"></div>
      <div class="int-chair-leg int-chair-leg-2"></div>
    </div>
    <div class="int-armchair int-chair-2">
      <div class="int-chair-back"></div>
      <div class="int-chair-seat"></div>
      <div class="int-chair-arm-l"></div>
      <div class="int-chair-arm-r"></div>
      <div class="int-chair-leg int-chair-leg-1"></div>
      <div class="int-chair-leg int-chair-leg-2"></div>
    </div>

    <!-- Side tables -->
    <div class="int-table int-table-1">
      <div class="int-table-top"></div>
      <div class="int-table-leg-l"></div>
      <div class="int-table-leg-r"></div>
      <div class="int-vase"></div>
    </div>
    <div class="int-table int-table-2">
      <div class="int-table-top"></div>
      <div class="int-table-leg-l"></div>
      <div class="int-table-leg-r"></div>
      <div class="int-vase" style="background:linear-gradient(145deg,#8A2820,#6A1810)"></div>
    </div>

    <!-- Wall panels -->
    <div class="int-panel" style="left:35%;right:35%;top:28%;height:38%"></div>

    <!-- Floating material swatches -->
    <?php foreach ($swatches as $sw):
      $r = rand(-15, 15);
    ?>
    <div class="int-swatch" style="left:<?php echo $sw['left']; ?>%;top:<?php echo $sw['top']; ?>%;width:<?php echo $sw['w']; ?>px;height:<?php echo $sw['h']; ?>px;background:hsl(<?php echo $sw['hue']; ?>,<?php echo $sw['sat']; ?>%,<?php echo $sw['lit']; ?>%);--r:<?php echo $r; ?>deg;transform:rotate(<?php echo $r; ?>deg);opacity:.6;animation:int-swatch-float <?php echo $sw['dur']; ?>s ease-in-out <?php echo $sw['delay']; ?>s infinite;box-shadow:0 2px 8px rgba(34,28,22,.12)"></div>
    <?php endforeach; ?>
  </div>

  <!-- Content -->
  <div class="int-hero-content">
    <div class="int-hero-text">
      <div class="int-badge">Interior Design Studio · Chelsea, London</div>
      <h1 class="int-h1">Spaces that<br>speak to the<br><em>soul</em></h1>
      <p class="int-lead">Henrietta Bell Interior Design creates homes and spaces of quiet luxury — thoughtfully designed, beautifully crafted, and utterly personal. Based in Chelsea, working across the UK and Europe.</p>
      <div class="int-hero-actions">
        <a href="#enquiry" class="int-btn int-btn-dark">Book a Consultation</a>
        <a href="#portfolio" class="int-btn int-btn-outline">View Our Work</a>
      </div>
      <div class="int-hero-meta">
        <div class="int-meta-item">BIID Member</div>
        <div class="int-meta-item">·</div>
        <div class="int-meta-item">8 Design Awards</div>
        <div class="int-meta-item">·</div>
        <div class="int-meta-item">140+ Projects</div>
      </div>
    </div>

    <!-- Room card -->
    <div class="int-hero-visual" aria-hidden="true">
      <div class="int-room-card">
        <div class="int-rc-wall"></div>
        <div class="int-rc-floor"></div>
        <div class="int-rc-win"></div>
        <div class="int-rc-shaft"></div>
        <div class="int-rc-fp">
          <div class="int-rc-surround"></div>
          <div class="int-rc-opening"></div>
          <div class="int-rc-mantel"></div>
        </div>
        <div class="int-rc-chair">
          <div class="int-rcc-back"></div>
          <div class="int-rcc-seat"></div>
          <div class="int-rcc-arm-l"></div>
          <div class="int-rcc-arm-r"></div>
        </div>
      </div>
      <div class="int-float-badge">
        <div style="font-size:1.2rem">🏆</div>
        <div class="int-float-badge-text">
          <strong>House &amp; Garden Featured</strong>
          <span>Henrietta Bell Studio · 2024</span>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ══ STATS BAR ════════════════════════════════════════════════════ -->
<section class="int-stats-bar" aria-label="Studio statistics">
  <div class="int-wrap">
    <div class="int-stats-grid">
      <?php foreach ($stats as $s): ?>
      <div style="text-align:center">
        <div class="int-stat-num int-counter" data-target="<?php echo esc_attr($s['val']); ?>" data-suffix="<?php echo esc_attr($s['suffix']); ?>">0</div>
        <div class="int-stat-label"><?php echo esc_html($s['label']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══ SERVICES ═════════════════════════════════════════════════════ -->
<section class="int-section" id="services" aria-label="Interior design services">
  <div class="int-wrap">
    <div class="int-center">
      <div class="int-badge">Services</div>
      <h2 class="int-h2">Every element,<br>thoughtfully considered</h2>
      <div class="int-center int-divider"></div>
      <p class="int-lead" style="margin:0 auto">Whether you need a full redesign, a single room transformation, or simply a guiding eye — we offer a range of services to suit every stage of your project.</p>
    </div>
    <div class="int-services-grid">
      <?php foreach ($services as $si => $svc): ?>
      <div class="int-service-card" style="--i:<?php echo $si; ?>">
        <div class="int-svc-icon"><?php echo $svc['icon']; ?></div>
        <h3 class="int-svc-title"><?php echo esc_html($svc['title']); ?></h3>
        <p class="int-svc-desc"><?php echo esc_html($svc['desc']); ?></p>
        <div class="int-svc-from"><?php echo esc_html($svc['from']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══ PORTFOLIO ════════════════════════════════════════════════════ -->
<section class="int-section int-section-clay" id="portfolio" aria-label="Design portfolio">
  <div class="int-wrap">
    <div class="int-center">
      <div class="int-badge">Portfolio</div>
      <h2 class="int-h2">Selected projects</h2>
      <div class="int-center int-divider"></div>
    </div>
    <div class="int-portfolio-grid">
      <?php
      $pc_palettes = [
        ['floor'=>'linear-gradient(180deg,#C0A080,#A08060)','wall'=>'linear-gradient(180deg,#C8D0B8,#B8C0A8)'],
        ['floor'=>'linear-gradient(180deg,#D0B890,#C0A880)','wall'=>'linear-gradient(180deg,#F2E8DC,#E8DED0)'],
        ['floor'=>'linear-gradient(180deg,#A09080,#908070)','wall'=>'linear-gradient(180deg,#1A2840,#2A3850)'],
        ['floor'=>'linear-gradient(180deg,#C8B8A0,#B8A890)','wall'=>'linear-gradient(180deg,#E8E0D0,#D8D0C0)'],
        ['floor'=>'linear-gradient(180deg,#2A2018,#1A1410)','wall'=>'linear-gradient(180deg,#1A4A2A,#0A3A1A)'],
        ['floor'=>'linear-gradient(180deg,#D0A880,#C09870)','wall'=>'linear-gradient(180deg,#E8C8A8,#D8B898)'],
      ];
      foreach ($projects as $pi => $proj):
        $pp = $pc_palettes[$pi % count($pc_palettes)];
      ?>
      <div class="int-portfolio-card">
        <div class="int-pc-scene">
          <div class="int-pc-wall" style="background:<?php echo $pp['wall']; ?>"></div>
          <div class="int-pc-floor" style="background:<?php echo $pp['floor']; ?>"></div>
          <!-- Mini CSS window -->
          <div style="position:absolute;top:6%;right:12%;width:30px;height:50%;background:rgba(255,240,200,.5);border:2px solid rgba(200,180,148,.3);border-bottom:none;border-radius:15px 15px 0 0"></div>
          <!-- Mini CSS furniture silhouette -->
          <div style="position:absolute;bottom:38%;left:15%;width:50px;height:28px">
            <div style="position:absolute;bottom:0;width:100%;height:14px;background:rgba(0,0,0,.25);border-radius:2px 2px 0 0"></div>
            <div style="position:absolute;bottom:14px;left:4px;right:4px;height:20px;background:rgba(0,0,0,.2);border-radius:3px 3px 0 0"></div>
          </div>
        </div>
        <div class="int-pc-overlay"></div>
        <div class="int-pc-label">
          <div class="int-pc-name"><?php echo esc_html($proj['name']); ?></div>
          <div class="int-pc-type"><?php echo esc_html($proj['type']); ?></div>
          <div class="int-pc-palette"><?php echo esc_html($proj['palette']); ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══ PROCESS ══════════════════════════════════════════════════════ -->
<section class="int-section" id="process" aria-label="Design process">
  <div class="int-wrap">
    <div class="int-center">
      <div class="int-badge">Our Process</div>
      <h2 class="int-h2">From first conversation<br>to finished room</h2>
      <div class="int-center int-divider"></div>
    </div>
    <div class="int-process-grid">
      <?php foreach ($process as $ps): ?>
      <div class="int-process-step">
        <div class="int-step-num"><?php echo esc_html($ps['num']); ?></div>
        <h3 class="int-step-title"><?php echo esc_html($ps['title']); ?></h3>
        <p class="int-step-desc"><?php echo esc_html($ps['desc']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══ TESTIMONIALS ══════════════════════════════════════════════════ -->
<section class="int-section int-section-warm" id="testimonials" aria-label="Client testimonials">
  <div class="int-wrap">
    <div class="int-center">
      <div class="int-badge">Client Testimonials</div>
      <h2 class="int-h2">What our clients say</h2>
      <div class="int-center int-divider"></div>
    </div>
    <div class="int-testi-grid">
      <?php foreach ($testimonials as $t): ?>
      <div class="int-testi-card">
        <div class="int-testi-stars">★★★★★</div>
        <p class="int-testi-quote">"<?php echo esc_html($t['quote']); ?>"</p>
        <div class="int-testi-author"><?php echo esc_html($t['name']); ?></div>
        <div class="int-testi-role"><?php echo esc_html($t['role']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══ FAQ ══════════════════════════════════════════════════════════ -->
<section class="int-section" aria-label="Frequently asked questions">
  <div class="int-wrap">
    <div class="int-center">
      <div class="int-badge">FAQ</div>
      <h2 class="int-h2">Common questions</h2>
      <div class="int-center int-divider"></div>
    </div>
    <div class="int-faq-list" role="list">
      <?php foreach ($faqs as $fi => $faq): ?>
      <div class="int-faq-item" role="listitem">
        <button class="int-faq-q" aria-expanded="false" aria-controls="int-faq-a-<?php echo $fi; ?>">
          <?php echo esc_html($faq['q']); ?>
        </button>
        <div class="int-faq-a" id="int-faq-a-<?php echo $fi; ?>" role="region">
          <div class="int-faq-a-inner"><?php echo esc_html($faq['a']); ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══ ENQUIRY ══════════════════════════════════════════════════════ -->
<section class="int-section int-section-dark" id="enquiry" aria-label="Studio enquiry">
  <div class="int-wrap">
    <div class="int-enquiry-wrap">
      <!-- Info -->
      <div>
        <div class="int-badge" style="color:var(--int-terr)">Get in Touch</div>
        <h2 class="int-h2" style="color:var(--int-ivory)">Let's design<br>something beautiful</h2>
        <div style="width:48px;height:1px;background:var(--int-stone);margin:1.4rem 0 2rem"></div>
        <p class="int-lead" style="color:rgba(245,240,232,.65)">We begin every project with a conversation. Tell us about your space, your vision, and your timeline — and we'll arrange an initial consultation, complimentary and without obligation.</p>
        <br>
        <div style="display:flex;flex-direction:column;gap:1.2rem;margin-top:.5rem">
          <div style="display:flex;gap:1rem;align-items:flex-start">
            <div style="width:32px;height:32px;border:1px solid rgba(196,152,64,.3);border-radius:50%;display:flex;align-items:center;justify-content:center;color:var(--int-terr);flex-shrink:0;font-size:.85rem">📍</div>
            <div><strong style="font-size:.82rem;display:block;color:rgba(245,240,232,.85);letter-spacing:.1em;text-transform:uppercase;margin-bottom:.2rem">Studio</strong><span style="font-size:.85rem;color:rgba(245,240,232,.55)">42 Oakley Street, Chelsea, London SW3 5NP</span></div>
          </div>
          <div style="display:flex;gap:1rem;align-items:flex-start">
            <div style="width:32px;height:32px;border:1px solid rgba(196,152,64,.3);border-radius:50%;display:flex;align-items:center;justify-content:center;color:var(--int-terr);flex-shrink:0;font-size:.85rem">📞</div>
            <div><strong style="font-size:.82rem;display:block;color:rgba(245,240,232,.85);letter-spacing:.1em;text-transform:uppercase;margin-bottom:.2rem">020 7300 7890</strong><span style="font-size:.85rem;color:rgba(245,240,232,.55)">studio@henriettabell.co.uk</span></div>
          </div>
          <div style="display:flex;gap:1rem;align-items:flex-start">
            <div style="width:32px;height:32px;border:1px solid rgba(196,152,64,.3);border-radius:50%;display:flex;align-items:center;justify-content:center;color:var(--int-terr);flex-shrink:0;font-size:.85rem">🏆</div>
            <div><strong style="font-size:.82rem;display:block;color:rgba(245,240,232,.85);letter-spacing:.1em;text-transform:uppercase;margin-bottom:.2rem">BIID Registered</strong><span style="font-size:.85rem;color:rgba(245,240,232,.55)">British Institute of Interior Design · Member No. 12345</span></div>
          </div>
        </div>
      </div>

      <!-- Form -->
      <div class="int-form-card">
        <h3 style="font-family:var(--int-font-h);font-size:1.5rem;font-weight:400;color:var(--int-dark);margin-bottom:1.4rem">Studio Enquiry</h3>
        <?php if (isset($_GET['int_sent']) && $_GET['int_sent'] === '1'): ?>
        <div style="border-left:2px solid var(--int-rust);padding:.8rem 1rem;margin-bottom:1.2rem;font-size:.88rem;color:var(--int-dark);background:var(--int-warm)">
          Thank you — Henrietta will be in touch within 24 hours.
        </div>
        <?php endif; ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
          <?php wp_nonce_field('tf_int_enquiry', 'tf_int_nonce'); ?>
          <input type="hidden" name="action" value="tf_int_enquiry">
          <div class="int-form-row">
            <div class="int-form-group">
              <label for="int-fname">First Name *</label>
              <input type="text" id="int-fname" name="first_name" required placeholder="First name">
            </div>
            <div class="int-form-group">
              <label for="int-lname">Last Name *</label>
              <input type="text" id="int-lname" name="last_name" required placeholder="Last name">
            </div>
          </div>
          <div class="int-form-group">
            <label for="int-email">Email *</label>
            <input type="email" id="int-email" name="email" required placeholder="your@email.com">
          </div>
          <div class="int-form-group">
            <label for="int-phone">Phone</label>
            <input type="tel" id="int-phone" name="phone" placeholder="020 7000 0000">
          </div>
          <div class="int-form-group">
            <label for="int-service">Service of Interest *</label>
            <select id="int-service" name="service" required>
              <option value="">Please select…</option>
              <option>Full Interior Design</option>
              <option>Design Consultation</option>
              <option>Space Planning</option>
              <option>Kitchen &amp; Bath Design</option>
              <option>Furniture &amp; Procurement</option>
              <option>Styling &amp; Staging</option>
            </select>
          </div>
          <div class="int-form-row">
            <div class="int-form-group">
              <label for="int-location">Property Location</label>
              <input type="text" id="int-location" name="location" placeholder="e.g. Chelsea, London">
            </div>
            <div class="int-form-group">
              <label for="int-budget">Approximate Budget</label>
              <select id="int-budget" name="budget">
                <option value="">Please select…</option>
                <option>Under £20k</option>
                <option>£20k–£60k</option>
                <option>£60k–£150k</option>
                <option>£150k–£400k</option>
                <option>Over £400k</option>
              </select>
            </div>
          </div>
          <div class="int-form-group">
            <label for="int-msg">Tell Us About Your Project</label>
            <textarea id="int-msg" name="message" placeholder="Property type, number of rooms, style references, timeline, and anything else that would help us understand your vision…"></textarea>
          </div>
          <button type="submit" class="int-btn int-btn-rust" style="width:100%;text-align:center">
            Send Enquiry
          </button>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- ══ FOOTER ════════════════════════════════════════════════════════ -->
<footer class="int-footer" role="contentinfo">
  <div class="int-wrap">
    <div class="int-footer-grid">
      <div>
        <a href="<?php echo esc_url(home_url('/')); ?>" class="int-logo" style="color:rgba(245,240,232,.85)">Henrietta<span style="color:var(--int-terr)">&nbsp;Bell</span></a>
        <p class="int-footer-desc">Luxury interior design studio based in Chelsea, London. Crafting thoughtful, beautiful spaces for residential and commercial clients across the UK and Europe since 2009.</p>
      </div>
      <div class="int-footer-col">
        <h4>Services</h4>
        <ul>
          <li><a href="#services">Full Interior Design</a></li>
          <li><a href="#services">Consultation</a></li>
          <li><a href="#services">Space Planning</a></li>
          <li><a href="#services">Kitchen &amp; Bath</a></li>
          <li><a href="#services">Styling &amp; Staging</a></li>
        </ul>
      </div>
      <div class="int-footer-col">
        <h4>Studio</h4>
        <ul>
          <li><a href="#portfolio">Portfolio</a></li>
          <li><a href="#process">Our Process</a></li>
          <li><a href="#">Journal</a></li>
          <li><a href="#">Press</a></li>
          <li><a href="#">Gift Vouchers</a></li>
        </ul>
      </div>
      <div class="int-footer-col">
        <h4>Contact</h4>
        <ul>
          <li><a href="tel:02073007890">020 7300 7890</a></li>
          <li><a href="mailto:studio@henriettabell.co.uk">studio@henriettabell.co.uk</a></li>
          <li><a href="#">42 Oakley Street, SW3</a></li>
          <li><a href="#enquiry">Book a Consultation</a></li>
        </ul>
      </div>
    </div>
    <div class="int-footer-bottom">
      <span>&copy; <?php echo date('Y'); ?> Henrietta Bell Interior Design Ltd. All rights reserved. BIID Registered Member.</span>
      <div style="display:flex;gap:1.2rem">
        <a href="#">Privacy</a>
        <a href="#">Cookies</a>
        <a href="#">Terms</a>
      </div>
    </div>
  </div>
</footer>


<script>
(function(){
  'use strict';

  /* ── FAQ ───────────────────────────────────────────────────────── */
  document.querySelectorAll('.int-faq-q').forEach(function(btn){
    btn.addEventListener('click',function(){
      var item = this.closest('.int-faq-item');
      var isOpen = item.classList.contains('open');
      document.querySelectorAll('.int-faq-item.open').forEach(function(o){
        o.classList.remove('open');
        o.querySelector('.int-faq-q').setAttribute('aria-expanded','false');
      });
      if(!isOpen){item.classList.add('open');this.setAttribute('aria-expanded','true');}
    });
  });

  /* ── Counters ──────────────────────────────────────────────────── */
  var counters = document.querySelectorAll('.int-counter');
  var started  = false;
  function easeOut(t){return 1-Math.pow(1-t,3)}
  function runCounters(){
    if(started) return; started = true;
    counters.forEach(function(el){
      var target  = parseFloat(el.dataset.target);
      var suffix  = el.dataset.suffix || '';
      var isFloat = el.dataset.target.indexOf('.') !== -1;
      if(isNaN(target)) return;
      var start = performance.now();
      function tick(now){
        var p = Math.min((now-start)/1800,1);
        var v = target*easeOut(p);
        el.textContent = (isFloat?v.toFixed(1):Math.floor(v).toLocaleString())+suffix;
        if(p<1) requestAnimationFrame(tick);
        else el.textContent = (isFloat?target.toFixed(1):target.toLocaleString())+suffix;
      }
      requestAnimationFrame(tick);
    });
  }
  if('IntersectionObserver' in window){
    var obs = new IntersectionObserver(function(e){e.forEach(function(e){if(e.isIntersecting) runCounters();});},{threshold:.3});
    var sb = document.querySelector('.int-stats-bar');
    if(sb) obs.observe(sb);
  } else runCounters();

  /* ── Smooth scroll ─────────────────────────────────────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(function(a){
    a.addEventListener('click',function(e){
      var t = document.querySelector(this.getAttribute('href'));
      if(t){e.preventDefault();window.scrollTo({top:t.getBoundingClientRect().top+window.pageYOffset-80,behavior:'smooth'});}
    });
  });

  /* ── Nav shadow ────────────────────────────────────────────────── */
  var nav = document.querySelector('.int-nav');
  window.addEventListener('scroll',function(){
    if(nav) nav.style.boxShadow = window.scrollY>10 ? '0 4px 20px rgba(34,28,22,.08)' : '';
  },{passive:true});
})();
</script>
</body>
</html>
</div><!-- .page-template-page-interior-designer -->
<?php get_footer(); ?>
