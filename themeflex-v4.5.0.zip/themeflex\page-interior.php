<?php
/**
 * Template Name: Premium – Interior Design Studio
 *
 * Namespace : --int-*
 * Fonts     : Cormorant Garamond + DM Sans
 * Palette   : sand #e8dcc8 · charcoal #2c2c2c · terracotta #c87050 · sage #7a8a6a · ivory #faf8f4
 */
?>

<?php
/* ── deterministic seed ── */
srand(crc32(get_the_permalink()));

/* ── PHP data: dust mote particles ── */
$motes = [];
for($i=0;$i<22;$i++) $motes[] = [rand(5,95),rand(10,90),rand(10,22)/10,rand(0,40)/10,rand(20,60)/100];

/* light beams angles */
$beams = [[-15,20],[-5,35],[8,18],[20,28]];

/* Portfolio projects */
$projects = [
  ['The Belvedere Residence','residential','living','A Mayfair pied-à-terre transformed through layered textures, antique brass, and hand-plastered walls.','#c87050'],
  ['Studio Nomad','commercial','workspace','A Shoreditch creative agency reimagined as a biophilic workspace — terracotta, rattan, and living walls.','#7a8a6a'],
  ['Villa Otranto','residential','bedroom','Sicilian holiday villa: whitewashed stone, linen drapes, and handcrafted ceramic tableware.','#a07858'],
  ['The Penthouse Edit','residential','living','Full floor Canary Wharf penthouse. Onyx kitchen island, curved millwork, floor-to-ceiling steel windows.','#4a5a6a'],
  ['Café Lumière','commercial','hospitality','A Parisian-inspired café: polished plaster, rattan pendants, hand-painted tile floors, marble counters.','#c87050'],
  ['The Writer\'s House','residential','workspace','A converted Victorian schoolhouse library. Bespoke joinery, laddering bookcase, reading pit.','#5a4a3a'],
];

/* Services */
$services = [
  ['Full Interior Design','full','Complete design from concept to completion. Space planning, bespoke joinery, material procurement, contractor coordination.'],
  ['Interior Styling','styling','Transform your existing space with expert curation of furniture, soft furnishings, art, and accessories.'],
  ['Architectural Colour','colour','Whole-home colour consultancy. Paint selection, finish specification, and on-site guidance from our colour director.'],
  ['Kitchen & Bath Design','kitchen','Detailed design for kitchens and bathrooms — layout, cabinetry, hardware, stone selection, appliance specification.'],
  ['FF&E Procurement','ffe','Full furniture, fixtures and equipment procurement. Exclusive trade access to global suppliers and custom makers.'],
  ['Online Design','online','Digital design service for clients anywhere. Mood boards, floorplans, shopping lists, and video consultations.'],
];

/* Team */
$team = [
  ['Margot Vidal','Creative Director','École Boulle Paris. 18 years designing for private clients across Europe, the Middle East, and the Americas.','#c87050'],
  ['Theo Albrecht','Senior Designer','Formerly at Ilse Crawford\'s Studioilse. Specialist in biophilic and sustainable interiors.','#7a8a6a'],
  ['Priya Mehta','FF&E Director','Sourcing director with access to 400+ exclusive trade suppliers. Bespoke fabric and furniture expert.','#a07858'],
  ['Kaspar Holm','Architectural Designer','ARB registered. Spatial planning, listed buildings consent, and custom cabinetry design.','#4a5a6a'],
];

$testimonials = [
  ['Margot\'s vision transformed our Victorian terrace into something magazine-worthy. She listened perfectly and delivered beyond our imagination.','The Hartley Family','Notting Hill, London','★★★★★'],
  ['Working with the studio on our restaurant was transformative. The biophilic elements create a warmth our customers can\'t stop talking about.','Restaurant Owner','Paris','★★★★★'],
  ['The online design service was exceptional value. Three rooms completely reinvented without us leaving the house.','Private Client','Edinburgh','★★★★★'],
];

/* Swatch palette */
$swatches = ['#e8dcc8','#c87050','#7a8a6a','#4a5a6a','#2c2c2c','#d8c8a8','#a07858','#8a9a8a'];
?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
/* ════════════════════════════════════════════════
   INT TOKEN SYSTEM
════════════════════════════════════════════════ */
:root{
  --int-sand:#e8dcc8;
  --int-charcoal:#2c2c2c;
  --int-terracotta:#c87050;
  --int-sage:#7a8a6a;
  --int-ivory:#faf8f4;
  --int-warm:#f4f0e8;
  --int-linen:#ede8dc;
  --int-serif:'Cormorant Garamond',Georgia,serif;
  --int-sans:'DM Sans',system-ui,sans-serif;
  --int-transition:0.4s ease;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
html{scroll-behavior:smooth;}
body.page-template-page-interior{
  font-family:var(--int-sans);
  background:var(--int-ivory);
  color:var(--int-charcoal);
  overflow-x:hidden;
}

/* ════ HERO ════ */
.int-hero{
  position:relative;
  width:100%;
  height:100vh;
  min-height:700px;
  overflow:hidden;
  display:flex;
  align-items:center;
}
/* Room background */
.int-room-bg{
  position:absolute;
  inset:0;
  background:linear-gradient(180deg,#d8cdb8 0%,#c8bda8 60%,#b8a890 100%);
}
/* Floor */
.int-floor{
  position:absolute;
  bottom:0;left:0;right:0;
  height:260px;
  background:repeating-linear-gradient(
    90deg,
    rgba(180,150,110,.6) 0,rgba(180,150,110,.6) 1px,
    transparent 1px,transparent 80px
  ),
  repeating-linear-gradient(
    0deg,
    rgba(180,150,110,.2) 0,rgba(180,150,110,.2) 1px,
    transparent 1px,transparent 40px
  ),
  linear-gradient(180deg,#c0aa88,#a88a60);
  perspective:400px;
}
/* Wall texture */
.int-wall{
  position:absolute;
  top:0;left:0;right:0;
  bottom:260px;
  background:
    repeating-linear-gradient(
      90deg,transparent,transparent 119px,rgba(200,180,150,.12) 120px
    ),
    linear-gradient(180deg,#d8cdb8,#c8bda8);
}
/* Skirting board */
.int-skirting{
  position:absolute;
  bottom:258px;left:0;right:0;
  height:12px;
  background:linear-gradient(180deg,#d8cdb8,#b8a890);
  box-shadow:0 4px 12px rgba(0,0,0,.15);
}
/* Cornice */
.int-cornice{
  position:absolute;
  top:0;left:0;right:0;
  height:28px;
  background:linear-gradient(180deg,#ece0cc,#d8cdb8);
  box-shadow:0 4px 12px rgba(0,0,0,.1);
}
.int-cornice::after{
  content:'';
  position:absolute;
  bottom:0;left:0;right:0;
  height:4px;
  background:linear-gradient(90deg,rgba(200,180,150,.5) 0,rgba(200,180,150,.2) 50%,rgba(200,180,150,.5) 100%);
}

/* Light beams */
.int-beam{
  position:absolute;
  top:0;
  width:80px;
  height:600px;
  background:linear-gradient(180deg,rgba(255,240,200,.15),transparent);
  transform-origin:top center;
  pointer-events:none;
}

/* Dust motes */
.int-mote{
  position:absolute;
  width:3px;height:3px;
  border-radius:50%;
  background:rgba(255,240,200,.6);
  animation:int-drift var(--int-md,4s) ease-in-out infinite alternate;
}
@keyframes int-drift{
  from{transform:translateY(0) translateX(0);opacity:var(--int-mo,.3);}
  to{transform:translateY(-20px) translateX(8px);opacity:.7;}
}

/* ── Room furniture scene ── */
.int-scene{
  position:absolute;
  bottom:0;left:0;right:0;
  height:360px;
}

/* Sofa */
.int-sofa{
  position:absolute;
  bottom:200px;
  left:50%;
  transform:translateX(-50%);
}
.int-sofa-back{
  width:340px;height:80px;
  background:linear-gradient(180deg,#8a6a4a,#6a4a2a);
  border-radius:8px 8px 0 0;
  position:relative;
}
.int-sofa-back::before{
  content:'';
  position:absolute;
  top:10px;left:10px;right:10px;bottom:0;
  background:repeating-linear-gradient(
    90deg,rgba(255,255,255,.04) 0,rgba(255,255,255,.04) 1px,transparent 1px,transparent 20px
  );
}
.int-sofa-seat{
  width:360px;height:36px;
  background:linear-gradient(180deg,#9a7a5a,#7a5a3a);
  border-radius:4px;
  margin-left:-10px;
  margin-top:0;
  box-shadow:0 6px 16px rgba(0,0,0,.25);
}
.int-sofa-arm-l,.int-sofa-arm-r{
  position:absolute;
  bottom:0;
  width:24px;height:60px;
  background:linear-gradient(90deg,#6a4a2a,#8a6a4a);
  border-radius:8px 8px 4px 4px;
}
.int-sofa-arm-l{left:-10px;}
.int-sofa-arm-r{right:-10px;}
.int-sofa-leg{
  position:absolute;
  bottom:-18px;
  width:10px;height:18px;
  background:linear-gradient(90deg,#4a3010,#6a4a1a);
  border-radius:0 0 3px 3px;
}
.int-sofa-leg-1{left:20px;}
.int-sofa-leg-2{right:20px;}
.int-sofa-leg-3{left:50%;transform:translateX(-50%);}

/* Cushions */
.int-cushion{
  position:absolute;
  bottom:36px;
  width:70px;height:52px;
  border-radius:8px;
  box-shadow:2px 2px 8px rgba(0,0,0,.2);
}
.int-cushion-1{left:18px;background:linear-gradient(135deg,#c87050,#a05030);transform:rotate(-3deg);}
.int-cushion-2{left:130px;background:linear-gradient(135deg,#7a8a6a,#5a6a4a);transform:rotate(2deg);}
.int-cushion-3{right:18px;background:linear-gradient(135deg,#e8dcc8,#c8bca8);transform:rotate(-2deg);}

/* Coffee table */
.int-table{
  position:absolute;
  bottom:155px;
  left:50%;
  transform:translateX(-50%);
}
.int-table-top{
  width:200px;height:14px;
  background:linear-gradient(180deg,#c8b088,#a09060);
  border-radius:4px;
  box-shadow:0 4px 12px rgba(0,0,0,.2);
}
.int-table-leg{
  position:absolute;
  bottom:-40px;
  width:6px;height:40px;
  background:linear-gradient(90deg,#4a3010,#6a4a1a);
  border-radius:0 0 3px 3px;
}
.int-tl-1{left:20px;}
.int-tl-2{right:20px;}

/* Vase on table */
.int-vase{
  position:absolute;
  bottom:14px;left:50%;
  transform:translateX(-60%);
}
.int-vase-body{
  width:22px;height:36px;
  background:linear-gradient(90deg,#c87050,#e0905a);
  clip-path:polygon(20% 0,80% 0,95% 100%,5% 100%);
  border-radius:2px;
}
.int-vase-neck{
  width:14px;height:8px;
  background:linear-gradient(90deg,#b06040,#d07850);
  border-radius:2px 2px 0 0;
  margin:0 auto;
  margin-top:-2px;
}
.int-vase-flower{
  width:18px;height:18px;
  background:radial-gradient(circle,#f0d0b0,#c87050);
  border-radius:50%;
  margin:-10px auto 0;
  box-shadow:0 0 8px rgba(200,112,80,.4);
}
.int-stem{
  width:2px;height:24px;
  background:#7a8a6a;
  margin:0 auto;
}

/* Floor lamp */
.int-lamp-floor{
  position:absolute;
  bottom:200px;
  right:calc(50% - 220px);
}
.int-lamp-foot{
  width:30px;height:6px;
  background:linear-gradient(90deg,#3a2a1a,#5a3a1a);
  border-radius:3px;
  margin:0 auto;
}
.int-lamp-pole{
  width:4px;height:150px;
  background:linear-gradient(90deg,#4a3a2a,#7a5a3a);
  margin:0 auto;
  border-radius:2px;
}
.int-lamp-arc{
  width:50px;height:4px;
  background:#5a3a2a;
  border-radius:2px;
  margin-top:-4px;
  margin-left:4px;
}
.int-lamp-shade-floor{
  width:55px;height:38px;
  background:linear-gradient(90deg,#e0c898,#f0dca8);
  clip-path:polygon(8% 0,92% 0,100% 100%,0% 100%);
  margin-left:4px;
  position:relative;
}
.int-lamp-shade-floor::after{
  content:'';
  position:absolute;
  bottom:0;left:5%;right:5%;
  height:3px;
  background:rgba(200,160,80,.5);
}
.int-lamp-glow-floor{
  position:absolute;
  bottom:-4px;left:50%;
  transform:translateX(-50%);
  width:100px;height:60px;
  background:radial-gradient(ellipse at top,rgba(255,230,150,.2),transparent 70%);
}

/* Painting on wall */
.int-painting{
  position:absolute;
  top:60px;
  left:50%;
  transform:translateX(-50%);
}
.int-frame{
  width:160px;height:110px;
  border:8px solid #7a5a3a;
  background:linear-gradient(135deg,#f0e8d8,#e0d0b8);
  box-shadow:4px 6px 20px rgba(0,0,0,.25);
  position:relative;
  overflow:hidden;
}
.int-canvas-art{
  position:absolute;
  inset:0;
  background:
    radial-gradient(ellipse at 30% 40%,rgba(200,112,80,.5),transparent 50%),
    radial-gradient(ellipse at 70% 60%,rgba(122,138,106,.4),transparent 50%),
    linear-gradient(135deg,#f0e0c0,#d8c8a0);
}
.int-canvas-art::before{
  content:'';
  position:absolute;
  top:20%;left:10%;right:30%;bottom:20%;
  border-radius:50%;
  background:rgba(200,112,80,.3);
}
/* Shelf */
.int-wall-shelf{
  position:absolute;
  top:160px;
  right:calc(50% - 250px);
  width:80px;height:8px;
  background:linear-gradient(180deg,#a07858,#7a5a38);
  border-radius:2px;
  box-shadow:2px 4px 8px rgba(0,0,0,.2);
}
.int-shelf-obj-1{
  position:absolute;
  bottom:8px;left:10px;
  width:12px;height:28px;
  background:linear-gradient(90deg,#c87050,#a05030);
  border-radius:2px 2px 0 0;
}
.int-shelf-obj-2{
  position:absolute;
  bottom:8px;left:28px;
  width:8px;height:20px;
  background:#7a8a6a;
  border-radius:50% 50% 0 0;
}
.int-shelf-obj-3{
  position:absolute;
  bottom:8px;right:10px;
  width:16px;height:22px;
  background:linear-gradient(90deg,#e8dcc8,#c8b8a0);
  border-radius:2px;
}
/* Plant */
.int-plant{
  position:absolute;
  bottom:200px;
  left:calc(50% - 240px);
}
.int-plant-pot{
  width:36px;height:30px;
  background:linear-gradient(90deg,#c87050,#e09060);
  clip-path:polygon(10% 0,90% 0,80% 100%,20% 100%);
}
.int-plant-stem{
  width:3px;height:50px;
  background:#7a8a6a;
  margin:0 auto;
}
.int-plant-leaf{
  width:30px;height:16px;
  border-radius:50%;
  background:radial-gradient(ellipse,#8a9a7a,#5a7a4a);
  position:absolute;
  bottom:var(--int-ply,20px);
  left:var(--int-plx,-10px);
  transform:rotate(var(--int-plr,-20deg));
}

/* Rug */
.int-rug{
  position:absolute;
  bottom:200px;
  left:50%;
  transform:translateX(-50%);
  width:320px;height:16px;
  background:
    repeating-linear-gradient(
      90deg,rgba(200,112,80,.3) 0,rgba(200,112,80,.3) 2px,transparent 2px,transparent 20px
    ),
    linear-gradient(90deg,#8a7a6a,#a09080);
  border-radius:4px;
  box-shadow:0 4px 12px rgba(0,0,0,.15);
}

/* Hero copy */
.int-hero-copy{
  position:relative;
  z-index:10;
  max-width:540px;
  padding:2rem 2rem 2rem 6%;
  color:var(--int-charcoal);
}
.int-hero-eyebrow{
  font-family:var(--int-sans);
  font-size:0.7rem;
  font-weight:500;
  letter-spacing:0.38em;
  text-transform:uppercase;
  color:var(--int-terracotta);
  margin-bottom:1.5rem;
}
.int-hero-title{
  font-family:var(--int-serif);
  font-size:clamp(3rem,7vw,5.5rem);
  font-weight:300;
  line-height:1.06;
  margin-bottom:1.25rem;
  color:var(--int-charcoal);
}
.int-hero-title em{
  font-style:italic;
  font-weight:300;
  color:var(--int-terracotta);
}
.int-hero-sub{
  font-family:var(--int-sans);
  font-size:1rem;
  font-weight:300;
  line-height:1.75;
  color:rgba(44,44,44,.65);
  margin-bottom:2.5rem;
  max-width:420px;
}
.int-hero-ctas{display:flex;gap:1rem;flex-wrap:wrap;}
.int-cta{
  display:inline-block;
  padding:0.9rem 2rem;
  font-family:var(--int-sans);
  font-size:0.78rem;
  font-weight:500;
  letter-spacing:0.18em;
  text-transform:uppercase;
  text-decoration:none;
  transition:var(--int-transition);
}
.int-cta.primary{background:var(--int-terracotta);color:#fff;}
.int-cta.primary:hover{background:#b06040;}
.int-cta.outline{border:1px solid rgba(44,44,44,.3);color:var(--int-charcoal);}
.int-cta.outline:hover{background:rgba(44,44,44,.06);}

/* Colour swatches row */
.int-swatches{
  display:flex;
  gap:0.4rem;
  margin-top:2rem;
  align-items:center;
}
.int-swatch{
  width:22px;height:22px;
  border-radius:50%;
  box-shadow:0 1px 4px rgba(0,0,0,.15);
  transition:transform .2s ease;
  cursor:default;
}
.int-swatch:hover{transform:scale(1.2);}
.int-swatches-label{
  font-size:0.68rem;
  letter-spacing:0.2em;
  text-transform:uppercase;
  color:rgba(44,44,44,.45);
  margin-left:0.5rem;
}

/* ════ MARQUEE ════ */
.int-marquee-wrap{
  background:var(--int-charcoal);
  overflow:hidden;
  padding:0.85rem 0;
}
.int-marquee-track{
  display:flex;
  width:max-content;
  animation:int-marquee 32s linear infinite;
}
.int-marquee-track:hover{animation-play-state:paused;}
@keyframes int-marquee{from{transform:translateX(0);}to{transform:translateX(-50%);}}
.int-marquee-item{
  white-space:nowrap;
  font-family:var(--int-sans);
  font-size:0.7rem;
  font-weight:400;
  letter-spacing:0.25em;
  text-transform:uppercase;
  color:rgba(232,220,200,.45);
  padding:0 2.5rem;
}
.int-marquee-sep{color:var(--int-terracotta);opacity:.6;}

/* ════ SECTION BASE ════ */
.int-section{padding:6rem 1.5rem;}
.int-container{max-width:1100px;margin:0 auto;}
.int-label{
  font-family:var(--int-sans);
  font-size:0.68rem;
  font-weight:500;
  letter-spacing:0.35em;
  text-transform:uppercase;
  color:var(--int-terracotta);
  margin-bottom:1rem;
}
.int-section-title{
  font-family:var(--int-serif);
  font-size:clamp(2rem,4vw,3.2rem);
  font-weight:300;
  line-height:1.15;
  color:var(--int-charcoal);
  margin-bottom:1rem;
}
.int-section-title.light{color:var(--int-ivory);}
.int-section-title em{font-style:italic;}
.int-divider{
  width:55px;height:1px;
  background:var(--int-terracotta);
  margin:1.5rem 0 2.5rem;
  opacity:.6;
}

/* Reveal */
.int-reveal{opacity:0;transform:translateY(24px);transition:opacity .7s ease,transform .7s ease;}
.int-reveal.visible{opacity:1;transform:none;}

/* ════ PORTFOLIO ════ */
.int-portfolio-section{background:var(--int-warm);}
.int-port-head{display:flex;justify-content:space-between;align-items:flex-end;flex-wrap:wrap;gap:1.5rem;margin-bottom:3rem;}
.int-filter-bar{display:flex;gap:0.5rem;flex-wrap:wrap;}
.int-filter-btn{
  padding:0.45rem 1.2rem;
  border:1px solid rgba(44,44,44,.18);
  background:transparent;
  font-family:var(--int-sans);
  font-size:0.72rem;
  letter-spacing:0.12em;
  text-transform:uppercase;
  cursor:pointer;
  transition:var(--int-transition);
  color:rgba(44,44,44,.6);
}
.int-filter-btn.active,.int-filter-btn:hover{
  background:var(--int-charcoal);
  color:var(--int-sand);
  border-color:var(--int-charcoal);
}
.int-portfolio-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:1.5px;
  background:rgba(44,44,44,.08);
}
@media(max-width:768px){.int-portfolio-grid{grid-template-columns:1fr 1fr;}}
@media(max-width:480px){.int-portfolio-grid{grid-template-columns:1fr;}}
.int-port-card{
  position:relative;
  overflow:hidden;
  background:var(--int-warm);
  transition:var(--int-transition);
}
.int-port-card.hidden{display:none;}
/* CSS room thumbnail */
.int-port-visual{
  height:220px;
  position:relative;
  overflow:hidden;
}
.int-port-card:hover .int-port-overlay{opacity:1;}
.int-port-overlay{
  position:absolute;
  inset:0;
  background:rgba(44,44,44,.65);
  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content:center;
  opacity:0;
  transition:var(--int-transition);
  padding:1.5rem;
  text-align:center;
}
.int-port-overlay-title{
  font-family:var(--int-serif);
  font-size:1.2rem;
  font-weight:300;
  color:var(--int-sand);
  margin-bottom:0.4rem;
}
.int-port-overlay-cat{
  font-size:0.65rem;
  letter-spacing:0.2em;
  text-transform:uppercase;
  color:var(--int-terracotta);
}
.int-port-body{padding:1.25rem 1rem;}
.int-port-name{
  font-family:var(--int-serif);
  font-size:1.05rem;
  font-weight:400;
  color:var(--int-charcoal);
  margin-bottom:0.3rem;
}
.int-port-desc{font-size:.82rem;line-height:1.6;color:rgba(44,44,44,.55);}

/* ════ SERVICES ════ */
.int-services-section{background:var(--int-charcoal);}
.int-services-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(280px,1fr));
  gap:1px;
  background:rgba(232,220,200,.06);
  margin-top:3rem;
}
.int-svc-card{
  background:var(--int-charcoal);
  padding:2.5rem 2rem;
  transition:var(--int-transition);
  position:relative;
}
.int-svc-card::before{
  content:'';
  position:absolute;
  top:0;left:0;right:0;
  height:1px;
  background:var(--int-terracotta);
  transform:scaleX(0);
  transform-origin:left;
  transition:var(--int-transition);
}
.int-svc-card:hover{background:#383838;}
.int-svc-card:hover::before{transform:scaleX(1);}
.int-svc-num{
  font-family:var(--int-serif);
  font-size:2.5rem;
  font-weight:300;
  color:rgba(232,220,200,.12);
  display:block;
  line-height:1;
  margin-bottom:0.75rem;
}
.int-svc-name{
  font-family:var(--int-serif);
  font-size:1.15rem;
  font-weight:300;
  color:var(--int-ivory);
  margin-bottom:0.75rem;
}
.int-svc-desc{
  font-size:.85rem;
  line-height:1.7;
  color:rgba(232,220,200,.45);
}

/* ════ ABOUT ════ */
.int-about-section{background:var(--int-ivory);}
.int-about-grid{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:5rem;
  align-items:center;
}
@media(max-width:768px){.int-about-grid{grid-template-columns:1fr;gap:3rem;}}
.int-about-text p{
  font-size:1rem;
  line-height:1.85;
  color:rgba(44,44,44,.7);
  margin-bottom:1.25rem;
}
/* Materials moodboard art */
.int-moodboard{
  display:grid;
  grid-template-columns:1fr 1fr;
  grid-template-rows:1fr 1fr;
  gap:8px;
  height:380px;
}
.int-mood-tile{
  border-radius:4px;
  position:relative;
  overflow:hidden;
}
.int-mood-tile-1{background:linear-gradient(135deg,#e8dcc8,#c8b8a0);}
.int-mood-tile-2{background:linear-gradient(135deg,#c87050,#a05030);}
.int-mood-tile-3{background:linear-gradient(135deg,#7a8a6a,#5a6a4a);}
.int-mood-tile-4{
  background:linear-gradient(135deg,#2c2c2c,#4a4a4a);
  grid-column:span 2;
  display:flex;align-items:center;justify-content:center;
}
.int-mood-tile-1::before{
  content:'';
  position:absolute;
  inset:0;
  background:repeating-linear-gradient(
    45deg,rgba(255,255,255,.08) 0,rgba(255,255,255,.08) 2px,transparent 2px,transparent 10px
  );
}
.int-mood-label{
  position:absolute;
  bottom:8px;left:12px;
  font-family:var(--int-serif);
  font-size:.75rem;
  font-style:italic;
  color:rgba(255,255,255,.6);
}

/* ════ STATS ════ */
.int-stats-section{background:var(--int-terracotta);}
.int-stats-grid{
  display:grid;
  grid-template-columns:repeat(4,1fr);
  gap:1px;
  background:rgba(255,255,255,.15);
}
@media(max-width:600px){.int-stats-grid{grid-template-columns:repeat(2,1fr);}}
.int-stat{
  background:var(--int-terracotta);
  padding:3rem 1.5rem;
  text-align:center;
}
.int-stat-num{
  font-family:var(--int-serif);
  font-size:clamp(2.5rem,5vw,3.5rem);
  font-weight:300;
  color:#fff;
  display:block;
  line-height:1;
  margin-bottom:0.5rem;
}
.int-stat-label{
  font-family:var(--int-sans);
  font-size:0.7rem;
  letter-spacing:0.2em;
  text-transform:uppercase;
  color:rgba(255,255,255,.65);
}

/* ════ TEAM ════ */
.int-team-section{background:var(--int-linen);}
.int-team-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(230px,1fr));
  gap:1.5rem;
  margin-top:3rem;
}
.int-team-card{
  background:var(--int-ivory);
  overflow:hidden;
  transition:var(--int-transition);
}
.int-team-card:hover{box-shadow:0 8px 32px rgba(44,44,44,.1);transform:translateY(-2px);}
.int-team-avatar{
  height:200px;
  background:var(--int-charcoal);
  display:flex;align-items:center;justify-content:center;
  position:relative;
  overflow:hidden;
}
.int-team-body{padding:1.5rem;}
.int-team-name{
  font-family:var(--int-serif);
  font-size:1.2rem;
  font-weight:400;
  color:var(--int-charcoal);
  margin-bottom:0.2rem;
}
.int-team-role{
  font-size:0.68rem;
  font-weight:500;
  letter-spacing:0.2em;
  text-transform:uppercase;
  color:var(--int-terracotta);
  margin-bottom:0.75rem;
}
.int-team-bio{font-size:.83rem;line-height:1.65;color:rgba(44,44,44,.6);}

/* ════ TESTIMONIALS ════ */
.int-testi-section{background:var(--int-ivory);}
.int-testi-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(300px,1fr));
  gap:2rem;
  margin-top:3rem;
}
.int-testi-card{
  padding:2.5rem;
  border-left:2px solid var(--int-terracotta);
  background:var(--int-warm);
  transition:var(--int-transition);
}
.int-testi-card:hover{background:var(--int-linen);}
.int-testi-stars{color:var(--int-terracotta);font-size:.9rem;margin-bottom:1rem;letter-spacing:.08em;}
.int-testi-quote{
  font-family:var(--int-serif);
  font-style:italic;
  font-size:1.05rem;
  line-height:1.7;
  color:var(--int-charcoal);
  margin-bottom:1.5rem;
}
.int-testi-author{font-family:var(--int-sans);font-size:.78rem;font-weight:500;color:var(--int-charcoal);}
.int-testi-loc{font-size:.72rem;color:rgba(44,44,44,.45);margin-top:.2rem;}

/* ════ CONTACT ════ */
.int-contact-section{background:var(--int-warm);}
.int-contact-wrap{
  display:grid;
  grid-template-columns:1fr 1.4fr;
  gap:5rem;
  align-items:start;
}
@media(max-width:768px){.int-contact-wrap{grid-template-columns:1fr;gap:2.5rem;}}
.int-contact-info p{
  font-size:.95rem;line-height:1.75;
  color:rgba(44,44,44,.65);margin-bottom:1.5rem;
}
.int-ci{display:flex;gap:.9rem;align-items:flex-start;margin-bottom:1.25rem;font-size:.88rem;color:rgba(44,44,44,.65);}
.int-ci-icon{
  width:34px;height:34px;
  border:1px solid rgba(200,112,80,.3);
  display:flex;align-items:center;justify-content:center;
  flex-shrink:0;color:var(--int-terracotta);
}
.int-form .int-field{
  width:100%;
  padding:.85rem 1rem;
  background:transparent;
  border:1px solid rgba(44,44,44,.18);
  font-family:var(--int-sans);
  font-size:.9rem;
  color:var(--int-charcoal);
  transition:border-color var(--int-transition);
  border-radius:0;
}
.int-form .int-field:focus{outline:none;border-color:var(--int-terracotta);}
.int-form-row{display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin-bottom:1rem;}
@media(max-width:500px){.int-form-row{grid-template-columns:1fr;}}
.int-form-group{margin-bottom:1rem;}
.int-form-label{
  display:block;font-size:.68rem;
  letter-spacing:.2em;text-transform:uppercase;
  color:rgba(44,44,44,.45);margin-bottom:.4rem;
}
.int-form-check{
  display:flex;gap:.75rem;align-items:flex-start;
  font-size:.83rem;color:rgba(44,44,44,.5);
  margin-bottom:1.5rem;
}
.int-submit{
  width:100%;padding:1rem;
  background:var(--int-charcoal);
  color:var(--int-sand);
  border:none;
  font-family:var(--int-sans);
  font-size:.75rem;font-weight:500;
  letter-spacing:.2em;text-transform:uppercase;
  cursor:pointer;transition:var(--int-transition);
}
.int-submit:hover{background:var(--int-terracotta);}

@media(max-width:900px){.int-scene{height:280px;}}
</style>
<?php get_header(); ?>
<div class="page-template-page-interior">
>

<!-- ═══════════════════════════════
     HERO
═══════════════════════════════ -->
<section class="int-hero" aria-label="<?php esc_attr_e('Hero','themeflex'); ?>">
  <div class="int-room-bg"></div>
  <div class="int-cornice" aria-hidden="true"></div>
  <div class="int-wall" aria-hidden="true"></div>

  <!-- Light beams -->
  <?php foreach($beams as $i => $beam): ?>
  <div class="int-beam" aria-hidden="true" style="left:<?= 15+$i*18 ?>%;transform:rotate(<?= $beam[0] ?>deg);opacity:<?= $beam[1]/100 ?>;"></div>
  <?php endforeach; ?>

  <!-- Dust motes -->
  <?php foreach($motes as $m): ?>
  <div class="int-mote" aria-hidden="true" style="left:<?= $m[0] ?>%;top:<?= $m[1] ?>%;--int-md:<?= $m[2] ?>s;animation-delay:<?= $m[3] ?>s;--int-mo:<?= $m[4] ?>;"></div>
  <?php endforeach; ?>

  <!-- Furniture scene -->
  <div class="int-scene" aria-hidden="true">
    <div class="int-skirting"></div>
    <div class="int-floor"></div>
    <!-- Rug -->
    <div class="int-rug"></div>
    <!-- Plant -->
    <div class="int-plant" style="position:absolute;">
      <div class="int-plant-leaf" style="--int-ply:40px;--int-plx:-14px;--int-plr:-25deg;"></div>
      <div class="int-plant-leaf" style="--int-ply:50px;--int-plx:4px;--int-plr:15deg;"></div>
      <div class="int-plant-leaf" style="--int-ply:30px;--int-plx:-8px;--int-plr:-40deg;"></div>
      <div class="int-plant-stem"></div>
      <div class="int-plant-pot"></div>
    </div>
    <!-- Floor lamp -->
    <div class="int-lamp-floor" style="position:absolute;">
      <div class="int-lamp-arc"></div>
      <div class="int-lamp-shade-floor"></div>
      <div class="int-lamp-pole"></div>
      <div class="int-lamp-foot"></div>
      <div class="int-lamp-glow-floor"></div>
    </div>
    <!-- Painting -->
    <div class="int-painting">
      <div class="int-frame"><div class="int-canvas-art"></div></div>
    </div>
    <!-- Wall shelf -->
    <div class="int-wall-shelf" style="position:absolute;">
      <div class="int-shelf-obj-1"></div>
      <div class="int-shelf-obj-2"></div>
      <div class="int-shelf-obj-3"></div>
    </div>
    <!-- Sofa -->
    <div class="int-sofa" style="position:absolute;">
      <div class="int-cushion int-cushion-1"></div>
      <div class="int-cushion int-cushion-2"></div>
      <div class="int-cushion int-cushion-3"></div>
      <div class="int-sofa-back">
        <div class="int-sofa-arm-l"></div>
        <div class="int-sofa-arm-r"></div>
      </div>
      <div class="int-sofa-seat"></div>
      <div class="int-sofa-leg int-sofa-leg-1"></div>
      <div class="int-sofa-leg int-sofa-leg-2"></div>
      <div class="int-sofa-leg int-sofa-leg-3"></div>
    </div>
    <!-- Coffee table -->
    <div class="int-table" style="position:absolute;">
      <div class="int-table-top">
        <div class="int-table-leg int-tl-1"></div>
        <div class="int-table-leg int-tl-2"></div>
      </div>
    </div>
    <!-- Vase -->
    <div class="int-vase" style="position:absolute;bottom:185px;left:calc(50% - 20px);">
      <div class="int-vase-flower"></div>
      <div class="int-stem"></div>
      <div class="int-vase-neck"></div>
      <div class="int-vase-body"></div>
    </div>
  </div>

  <!-- Hero copy -->
  <div class="int-hero-copy">
    <p class="int-hero-eyebrow"><?php esc_html_e('Interior Design Studio · London','themeflex'); ?></p>
    <h1 class="int-hero-title">
      <?php esc_html_e('Spaces That','themeflex'); ?><br>
      <em><?php esc_html_e('Tell Your Story','themeflex'); ?></em>
    </h1>
    <p class="int-hero-sub"><?php esc_html_e('Bespoke interior design for homes, offices, and hospitality spaces that move, inspire, and endure.','themeflex'); ?></p>
    <div class="int-hero-ctas">
      <a href="#contact" class="int-cta primary"><?php esc_html_e('Start a Project','themeflex'); ?></a>
      <a href="#portfolio" class="int-cta outline"><?php esc_html_e('View Portfolio','themeflex'); ?></a>
    </div>
    <div class="int-swatches">
      <?php foreach($swatches as $sw): ?>
      <div class="int-swatch" style="background:<?= esc_attr($sw) ?>;" aria-hidden="true"></div>
      <?php endforeach; ?>
      <span class="int-swatches-label"><?php esc_html_e('Signature Palette','themeflex'); ?></span>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     MARQUEE
═══════════════════════════════ -->
<div class="int-marquee-wrap" aria-hidden="true">
  <div class="int-marquee-track">
    <?php
    $pubs = ['House & Garden','The World of Interiors','AD Architectural Digest','Elle Décor','Wallpaper*','Dezeen','Condé Nast Traveller','The Sunday Times Magazine'];
    $dup = array_merge($pubs,$pubs);
    foreach($dup as $p): ?>
    <span class="int-marquee-item"><?= esc_html($p) ?> <span class="int-marquee-sep">◆</span></span>
    <?php endforeach; ?>
  </div>
</div>

<!-- ═══════════════════════════════
     PORTFOLIO
═══════════════════════════════ -->
<section class="int-section int-portfolio-section" id="portfolio">
  <div class="int-container">
    <div class="int-port-head int-reveal">
      <div>
        <p class="int-label"><?php esc_html_e('Selected Works','themeflex'); ?></p>
        <h2 class="int-section-title"><?php esc_html_e('Our Portfolio','themeflex'); ?></h2>
        <div class="int-divider"></div>
      </div>
      <div class="int-filter-bar" role="group" aria-label="<?php esc_attr_e('Filter portfolio','themeflex'); ?>">
        <button class="int-filter-btn active" data-filter="all" aria-pressed="true"><?php esc_html_e('All','themeflex'); ?></button>
        <button class="int-filter-btn" data-filter="residential" aria-pressed="false"><?php esc_html_e('Residential','themeflex'); ?></button>
        <button class="int-filter-btn" data-filter="commercial" aria-pressed="false"><?php esc_html_e('Commercial','themeflex'); ?></button>
        <button class="int-filter-btn" data-filter="living" aria-pressed="false"><?php esc_html_e('Living','themeflex'); ?></button>
        <button class="int-filter-btn" data-filter="workspace" aria-pressed="false"><?php esc_html_e('Workspace','themeflex'); ?></button>
      </div>
    </div>
    <div class="int-portfolio-grid" role="list">
      <?php foreach($projects as $idx => $p): ?>
      <article class="int-port-card int-reveal" data-cat="<?= esc_attr($p[1]) ?>" data-type="<?= esc_attr($p[2]) ?>" role="listitem">
        <div class="int-port-visual">
          <!-- CSS room thumbnail -->
          <svg width="100%" height="220" viewBox="0 0 400 220" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
            <!-- Room wall -->
            <rect width="400" height="220" fill="<?= $idx%2===0?'#d8cdb8':($idx%3===1?'#e8dcc8':'#c8bda8') ?>"/>
            <!-- Floor -->
            <rect x="0" y="160" width="400" height="60" fill="<?= $idx%2===0?'#b8a880':'#c8b890' ?>"/>
            <!-- Perspective floor lines -->
            <line x1="0" y1="160" x2="200" y2="140" stroke="rgba(100,80,40,.12)" stroke-width="1"/>
            <line x1="400" y1="160" x2="200" y2="140" stroke="rgba(100,80,40,.12)" stroke-width="1"/>
            <!-- Accent wall panel -->
            <rect x="100" y="20" width="200" height="120" fill="rgba(<?= $p[5]==='#c87050'?'200,112,80':($p[5]==='#7a8a6a'?'122,138,106':'74,90,106') ?>,.15)" stroke="rgba(100,80,40,.15)" stroke-width="1"/>
            <!-- Furniture silhouette -->
            <rect x="80" y="130" width="240" height="30" rx="4" fill="rgba(<?= $p[5]==='#c87050'?'100,70,40':'50,70,50' ?>,.55)"/>
            <rect x="60" y="110" width="280" height="22" rx="3" fill="rgba(60,40,20,.3)"/>
            <!-- Accent item -->
            <circle cx="200" cy="<?= 110+rand(-5,5) ?>" r="8" fill="<?= esc_attr($p[5]) ?>"/>
            <!-- Light source -->
            <ellipse cx="200" cy="0" rx="80" ry="40" fill="rgba(255,240,200,.2)"/>
          </svg>
          <div class="int-port-overlay">
            <p class="int-port-overlay-title"><?= esc_html($p[0]) ?></p>
            <p class="int-port-overlay-cat"><?= esc_html(ucfirst($p[1]).' · '.ucfirst($p[2])) ?></p>
          </div>
        </div>
        <div class="int-port-body">
          <h3 class="int-port-name"><?= esc_html($p[0]) ?></h3>
          <p class="int-port-desc"><?= esc_html($p[3]) ?></p>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     SERVICES
═══════════════════════════════ -->
<section class="int-section int-services-section">
  <div class="int-container">
    <div class="int-reveal" style="text-align:center;">
      <p class="int-label"><?php esc_html_e('What We Offer','themeflex'); ?></p>
      <h2 class="int-section-title light"><?php esc_html_e('Our <em>Services</em>','themeflex'); ?></h2>
      <div class="int-divider" style="margin-left:auto;margin-right:auto;"></div>
    </div>
    <div class="int-services-grid">
      <?php foreach($services as $i => $s): ?>
      <div class="int-svc-card int-reveal">
        <span class="int-svc-num" aria-hidden="true"><?= str_pad($i+1,2,'0',STR_PAD_LEFT) ?></span>
        <h3 class="int-svc-name"><?= esc_html($s[0]) ?></h3>
        <p class="int-svc-desc"><?= esc_html($s[2]) ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     ABOUT
═══════════════════════════════ -->
<section class="int-section int-about-section">
  <div class="int-container">
    <div class="int-about-grid">
      <div class="int-about-text int-reveal">
        <p class="int-label"><?php esc_html_e('About the Studio','themeflex'); ?></p>
        <h2 class="int-section-title"><?php esc_html_e('Beauty With <em>Purpose</em>','themeflex'); ?></h2>
        <div class="int-divider"></div>
        <p><?php esc_html_e('Founded in 2006 by Margot Vidal, our London studio has earned a reputation for interiors that are simultaneously beautiful and deeply liveable. We believe that great design should serve the people who inhabit it — not the other way around.','themeflex'); ?></p>
        <p><?php esc_html_e('Our process begins with listening. We want to understand how you move through a space, what you love and what frustrates you, which colours lift your spirit and which drain it. From this foundation, we build a design that is entirely, unmistakably yours.','themeflex'); ?></p>
        <p><?php esc_html_e('Our projects have been published in House & Garden, The World of Interiors, and Architectural Digest. We have completed over 140 residential and commercial commissions across Europe, the Middle East, and North America.','themeflex'); ?></p>
      </div>
      <div class="int-moodboard int-reveal" aria-hidden="true">
        <div class="int-mood-tile int-mood-tile-1"><span class="int-mood-label"><?php esc_html_e('Natural Linen','themeflex'); ?></span></div>
        <div class="int-mood-tile int-mood-tile-2"><span class="int-mood-label"><?php esc_html_e('Terracotta','themeflex'); ?></span></div>
        <div class="int-mood-tile int-mood-tile-3"><span class="int-mood-label"><?php esc_html_e('Sage','themeflex'); ?></span></div>
        <div class="int-mood-tile int-mood-tile-4">
          <span style="font-family:var(--int-serif);font-size:1.5rem;font-style:italic;color:rgba(232,220,200,.4);"><?php esc_html_e('Materials tell stories.','themeflex'); ?></span>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     STATS
═══════════════════════════════ -->
<section class="int-section int-stats-section">
  <div class="int-container">
    <div class="int-stats-grid">
      <div class="int-stat int-reveal"><span class="int-stat-num" data-target="140" data-suffix="+">140+</span><span class="int-stat-label"><?php esc_html_e('Projects Completed','themeflex'); ?></span></div>
      <div class="int-stat int-reveal"><span class="int-stat-num" data-target="18" data-suffix="">18</span><span class="int-stat-label"><?php esc_html_e('Years Established','themeflex'); ?></span></div>
      <div class="int-stat int-reveal"><span class="int-stat-num" data-target="12" data-suffix="">12</span><span class="int-stat-label"><?php esc_html_e('Countries','themeflex'); ?></span></div>
      <div class="int-stat int-reveal"><span class="int-stat-num" data-target="96" data-suffix="%">96%</span><span class="int-stat-label"><?php esc_html_e('Repeat Clients','themeflex'); ?></span></div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     TEAM
═══════════════════════════════ -->
<section class="int-section int-team-section" aria-labelledby="int-team-title">
  <div class="int-container">
    <div class="int-reveal" style="text-align:center;">
      <p class="int-label"><?php esc_html_e('The Studio','themeflex'); ?></p>
      <h2 class="int-section-title" id="int-team-title"><?php esc_html_e('Our <em>Designers</em>','themeflex'); ?></h2>
      <div class="int-divider" style="margin-left:auto;margin-right:auto;"></div>
    </div>
    <div class="int-team-grid">
      <?php foreach($team as $i => $m): ?>
      <div class="int-team-card int-reveal">
        <div class="int-team-avatar">
          <svg width="120" height="175" viewBox="0 0 120 175" aria-hidden="true">
            <!-- Body -->
            <path d="M28 84 Q18 98 16 165 L104 165 Q102 98 92 84 Z" fill="<?= esc_attr($m[3]) ?>"/>
            <!-- Turtleneck -->
            <rect x="46" y="82" width="28" height="20" rx="8" fill="rgba(44,44,44,.6)"/>
            <rect x="50" y="70" width="20" height="16" rx="8" fill="#e8c8a0"/>
            <!-- Head -->
            <ellipse cx="60" cy="54" rx="26" ry="27" fill="#e8c8a0"/>
            <!-- Eyes -->
            <ellipse cx="51" cy="50" rx="3" ry="3.4" fill="#3a2a1a"/>
            <ellipse cx="69" cy="50" rx="3" ry="3.4" fill="#3a2a1a"/>
            <circle cx="52" cy="48.5" r="1.1" fill="#fff"/>
            <circle cx="70" cy="48.5" r="1.1" fill="#fff"/>
            <!-- Smile / neutral -->
            <path d="M54 63 Q60 68 66 63" stroke="#8a5a3a" stroke-width="1.5" fill="none" stroke-linecap="round"/>
            <!-- Arms -->
            <rect x="6" y="87" width="20" height="46" rx="9" fill="<?= esc_attr($m[3]) ?>"/>
            <rect x="94" y="87" width="20" height="46" rx="9" fill="<?= esc_attr($m[3]) ?>"/>
            <ellipse cx="16" cy="135" rx="9" ry="7" fill="#e8c8a0"/>
            <ellipse cx="104" cy="135" rx="9" ry="7" fill="#e8c8a0"/>
            <!-- Hair -->
            <?php if($i===0): ?>
            <!-- Chignon -->
            <ellipse cx="60" cy="28" rx="26" ry="14" fill="#8a5a2a"/>
            <rect x="34" y="24" width="9" height="32" rx="4.5" fill="#8a5a2a"/>
            <rect x="77" y="24" width="9" height="32" rx="4.5" fill="#8a5a2a"/>
            <circle cx="60" cy="28" r="7" fill="#7a4a1a"/>
            <?php elseif($i===1): ?>
            <!-- Wavy medium -->
            <ellipse cx="60" cy="28" rx="27" ry="15" fill="#3a2a1a"/>
            <rect x="33" y="24" width="9" height="38" rx="4.5" fill="#3a2a1a"/>
            <rect x="78" y="24" width="9" height="38" rx="4.5" fill="#3a2a1a"/>
            <?php elseif($i===2): ?>
            <!-- Long braid -->
            <ellipse cx="60" cy="28" rx="26" ry="14" fill="#6a3a1a"/>
            <rect x="34" y="24" width="10" height="55" rx="5" fill="#6a3a1a"/>
            <rect x="76" y="24" width="10" height="55" rx="5" fill="#6a3a1a"/>
            <?php else: ?>
            <!-- Short grey -->
            <ellipse cx="60" cy="30" rx="26" ry="12" fill="#7a8090"/>
            <rect x="34" y="27" width="7" height="20" rx="3.5" fill="#7a8090"/>
            <rect x="79" y="27" width="7" height="20" rx="3.5" fill="#7a8090"/>
            <?php endif; ?>
            <!-- Accessory: notepad/pencil -->
            <?php if($i===0||$i===2): ?>
            <rect x="92" y="115" width="16" height="20" rx="2" fill="#e8d8b0" transform="rotate(10 100 125)"/>
            <line x1="95" y1="119" x2="105" y2="118" stroke="rgba(100,80,40,.4)" stroke-width="1" transform="rotate(10 100 125)"/>
            <line x1="95" y1="122" x2="105" y2="121" stroke="rgba(100,80,40,.3)" stroke-width="1" transform="rotate(10 100 125)"/>
            <?php endif; ?>
            <?php if($i===3): ?>
            <!-- Glasses -->
            <circle cx="51" cy="50" r="8" fill="none" stroke="#3a2a1a" stroke-width="1.5"/>
            <circle cx="69" cy="50" r="8" fill="none" stroke="#3a2a1a" stroke-width="1.5"/>
            <line x1="59" y1="50" x2="61" y2="50" stroke="#3a2a1a" stroke-width="1.5"/>
            <line x1="43" y1="50" x2="37" y2="52" stroke="#3a2a1a" stroke-width="1.5"/>
            <line x1="77" y1="50" x2="83" y2="52" stroke="#3a2a1a" stroke-width="1.5"/>
            <?php endif; ?>
          </svg>
        </div>
        <div class="int-team-body">
          <h3 class="int-team-name"><?= esc_html($m[0]) ?></h3>
          <p class="int-team-role"><?= esc_html($m[1]) ?></p>
          <p class="int-team-bio"><?= esc_html($m[2]) ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     TESTIMONIALS
═══════════════════════════════ -->
<section class="int-section int-testi-section" aria-labelledby="int-testi-title">
  <div class="int-container">
    <div class="int-reveal" style="text-align:center;">
      <p class="int-label"><?php esc_html_e('Client Words','themeflex'); ?></p>
      <h2 class="int-section-title" id="int-testi-title"><?php esc_html_e('What Our Clients Say','themeflex'); ?></h2>
      <div class="int-divider" style="margin-left:auto;margin-right:auto;"></div>
    </div>
    <div class="int-testi-grid">
      <?php foreach($testimonials as $t): ?>
      <blockquote class="int-testi-card int-reveal">
        <p class="int-testi-stars"><?= esc_html($t[3]) ?></p>
        <p class="int-testi-quote"><?= esc_html($t[0]) ?></p>
        <footer>
          <p class="int-testi-author"><?= esc_html($t[1]) ?></p>
          <p class="int-testi-loc"><?= esc_html($t[2]) ?></p>
        </footer>
      </blockquote>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     CONTACT
═══════════════════════════════ -->
<section class="int-section int-contact-section" id="contact" aria-labelledby="int-contact-title">
  <div class="int-container">
    <div class="int-contact-wrap">
      <div class="int-contact-info int-reveal">
        <p class="int-label"><?php esc_html_e('Start a Project','themeflex'); ?></p>
        <h2 class="int-section-title" id="int-contact-title"><?php esc_html_e('Let\'s Talk About Your Space','themeflex'); ?></h2>
        <div class="int-divider"></div>
        <p><?php esc_html_e('We\'d love to hear about your project. All enquiries receive a personal response from a senior designer within 24 hours.','themeflex'); ?></p>
        <div class="int-ci">
          <div class="int-ci-icon">✆</div>
          <span>+44 20 7000 0000</span>
        </div>
        <div class="int-ci">
          <div class="int-ci-icon">✉</div>
          <span><?php esc_html_e('studio@vidal-interiors.co.uk','themeflex'); ?></span>
        </div>
        <div class="int-ci">
          <div class="int-ci-icon">⌖</div>
          <span>12 Charlotte Street, London W1T 2LY</span>
        </div>
        <div class="int-ci">
          <div class="int-ci-icon">🕐</div>
          <span><?php esc_html_e('Mon–Fri: 09:00 – 18:00','themeflex'); ?></span>
        </div>
      </div>
      <div class="int-reveal">
        <form class="int-form" method="post" action="#contact" novalidate>
          <?php wp_nonce_field('tf_int_enquiry','tf_int_nonce'); ?>
          <div class="int-form-row">
            <div class="int-form-group">
              <label class="int-form-label" for="int_fname"><?php esc_html_e('First Name','themeflex'); ?> *</label>
              <input class="int-field" id="int_fname" name="int_fname" type="text" required autocomplete="given-name">
            </div>
            <div class="int-form-group">
              <label class="int-form-label" for="int_lname"><?php esc_html_e('Last Name','themeflex'); ?> *</label>
              <input class="int-field" id="int_lname" name="int_lname" type="text" required autocomplete="family-name">
            </div>
          </div>
          <div class="int-form-row">
            <div class="int-form-group">
              <label class="int-form-label" for="int_email"><?php esc_html_e('Email','themeflex'); ?> *</label>
              <input class="int-field" id="int_email" name="int_email" type="email" required autocomplete="email">
            </div>
            <div class="int-form-group">
              <label class="int-form-label" for="int_phone"><?php esc_html_e('Phone','themeflex'); ?></label>
              <input class="int-field" id="int_phone" name="int_phone" type="tel" autocomplete="tel">
            </div>
          </div>
          <div class="int-form-row">
            <div class="int-form-group">
              <label class="int-form-label" for="int_project"><?php esc_html_e('Project Type','themeflex'); ?></label>
              <select class="int-field" id="int_project" name="int_project">
                <option value=""><?php esc_html_e('Select type','themeflex'); ?></option>
                <option value="full"><?php esc_html_e('Full Interior Design','themeflex'); ?></option>
                <option value="styling"><?php esc_html_e('Interior Styling','themeflex'); ?></option>
                <option value="colour"><?php esc_html_e('Colour Consultancy','themeflex'); ?></option>
                <option value="kitchen"><?php esc_html_e('Kitchen & Bath','themeflex'); ?></option>
                <option value="ffe"><?php esc_html_e('FF&E Procurement','themeflex'); ?></option>
                <option value="online"><?php esc_html_e('Online Design Service','themeflex'); ?></option>
              </select>
            </div>
            <div class="int-form-group">
              <label class="int-form-label" for="int_budget"><?php esc_html_e('Approximate Budget','themeflex'); ?></label>
              <select class="int-field" id="int_budget" name="int_budget">
                <option value=""><?php esc_html_e('Select budget range','themeflex'); ?></option>
                <option value="under-30k"><?php esc_html_e('Under £30,000','themeflex'); ?></option>
                <option value="30-75k"><?php esc_html_e('£30,000 – £75,000','themeflex'); ?></option>
                <option value="75-200k"><?php esc_html_e('£75,000 – £200,000','themeflex'); ?></option>
                <option value="over-200k"><?php esc_html_e('Over £200,000','themeflex'); ?></option>
              </select>
            </div>
          </div>
          <div class="int-form-group">
            <label class="int-form-label" for="int_message"><?php esc_html_e('Tell Us About Your Project','themeflex'); ?> *</label>
            <textarea class="int-field" id="int_message" name="int_message" rows="5" required style="resize:vertical;" placeholder="<?php esc_attr_e('Location, size, style preferences, timeline…','themeflex'); ?>"></textarea>
          </div>
          <div class="int-form-check">
            <input type="checkbox" id="int_consent" name="int_consent" required style="margin-top:2px;">
            <label for="int_consent"><?php esc_html_e('I consent to Vidal Interiors processing my enquiry data in accordance with their privacy policy.','themeflex'); ?></label>
          </div>
          <button type="submit" class="int-submit" name="int_submit"><?php esc_html_e('Send Project Enquiry','themeflex'); ?></button>
        </form>
      </div>
    </div>
  </div>
</section>

<script>
(function(){
  'use strict';
  /* ── Scroll reveal ── */
  const obs = new IntersectionObserver(entries=>{
    entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');obs.unobserve(e.target);}});
  },{threshold:.1});
  document.querySelectorAll('.int-reveal').forEach(el=>obs.observe(el));

  /* ── Portfolio filter ── */
  const btns  = document.querySelectorAll('.int-filter-btn');
  const cards = document.querySelectorAll('.int-port-card');
  btns.forEach(btn=>{
    btn.addEventListener('click',()=>{
      btns.forEach(b=>{b.classList.remove('active');b.setAttribute('aria-pressed','false');});
      btn.classList.add('active');
      btn.setAttribute('aria-pressed','true');
      const f = btn.dataset.filter;
      cards.forEach(c=>c.classList.toggle('hidden',f!=='all'&&c.dataset.cat!==f&&c.dataset.type!==f));
    });
  });

  /* ── Animated counters ── */
  const easeOut = t=>1-Math.pow(1-t,3);
  const cobs = new IntersectionObserver(entries=>{
    entries.forEach(e=>{
      if(!e.isIntersecting) return;
      const el = e.target;
      const target = parseFloat(el.dataset.target);
      const suffix = el.dataset.suffix||'';
      const dur = 1800;
      const t0 = performance.now();
      const tick = now=>{
        const p = Math.min((now-t0)/dur,1);
        el.textContent = Math.round(easeOut(p)*target)+suffix;
        if(p<1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      cobs.unobserve(el);
    });
  },{threshold:.5});
  document.querySelectorAll('.int-stat-num[data-target]').forEach(el=>cobs.observe(el));
})();
</script>

</body>
</html>
</div><!-- .page-template-page-interior -->
<?php get_footer(); ?>
