<?php
/**
 * Template Name: Jeweller – Fine Jewellery & Goldsmith Atelier
 *
 * Premium jewellery boutique page template for ThemeFlex.
 * Hadley & Stone — Fine Jewellers, Bond Street London Est. 1962
 *
 * @package ThemeFlex
 */

defined('ABSPATH') || exit;

srand(crc32(get_the_permalink()));

// PHP-generated gem stone array for hero display case
$jw_gems = [
  ['shape'=>'oval',     'color'=>'#1A3A6A', 'name'=>'Royal Sapphire',    'hue'=>215, 's'=>65, 'l'=>28, 'glow'=>'rgba(80,130,220,.5)'],
  ['shape'=>'round',    'color'=>'#8A1520', 'name'=>'Burmese Ruby',      'hue'=>355, 's'=>72, 'l'=>32, 'glow'=>'rgba(220,60,80,.5)'],
  ['shape'=>'emerald',  'color'=>'#1A5A2A', 'name'=>'Colombian Emerald', 'hue'=>145, 's'=>60, 'l'=>25, 'glow'=>'rgba(50,180,80,.4)'],
  ['shape'=>'round',    'color'=>'#C0C8D8', 'name'=>'Brilliant Diamond', 'hue'=>220, 's'=>15, 'l'=>82, 'glow'=>'rgba(200,215,240,.7)'],
  ['shape'=>'pear',     'color'=>'#5A2080', 'name'=>'Purple Amethyst',   'hue'=>280, 's'=>55, 'l'=>35, 'glow'=>'rgba(160,80,220,.4)'],
  ['shape'=>'oval',     'color'=>'#1A4A60', 'name'=>'Paraiba Tourmaline','hue'=>195, 's'=>68, 'l'=>26, 'glow'=>'rgba(40,180,200,.5)'],
];

// PHP-generated collection items
$jw_collection = [
  ['name'=>'The Heiress Ring',        'type'=>'Engagement Ring',   'metal'=>'Platinum', 'gem'=>'Sapphire & Diamonds', 'price'=>'£18,500'],
  ['name'=>'Victoria Pendant',        'type'=>'Necklace',          'metal'=>'18ct Gold', 'gem'=>'Emerald Cut Diamond','price'=>'£6,800'],
  ['name'=>'The Constance Bangle',    'type'=>'Bangle',            'metal'=>'18ct Gold', 'gem'=>'Pavé Diamonds',       'price'=>'£4,200'],
  ['name'=>'Dorchester Earrings',     'type'=>'Drop Earrings',     'metal'=>'Platinum', 'gem'=>'Ruby & Diamond',      'price'=>'£9,400'],
  ['name'=>'The Mayfair Band',        'type'=>'Wedding Band',      'metal'=>'Platinum', 'gem'=>'Channel-set Diamonds','price'=>'£3,600'],
  ['name'=>'Rosamund Brooch',         'type'=>'Brooch',            'metal'=>'18ct Gold', 'gem'=>'Amethyst & Pearls',  'price'=>'£5,100'],
];

// Workshop tools
$jw_tools = [
  ['type'=>'loupe',   'label'=>'10× Loupe'],
  ['type'=>'pliers',  'label'=>'Flat Pliers'],
  ['type'=>'file',    'label'=>'Needle File'],
  ['type'=>'hammer',  'label'=>'Planishing Hammer'],
  ['type'=>'tweeze',  'label'=>'Gem Tweezers'],
];

// Sparkle positions
$jw_sparkles = [];
for ($i = 0; $i < 20; $i++) {
    $jw_sparkles[] = [
        'top'   => rand(5, 88),
        'left'  => rand(5, 92),
        'size'  => rand(3, 9),
        'delay' => rand(0, 3000),
        'dur'   => 1500 + rand(0, 2000),
    ];
}

?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400;1,600&family=Jost:wght@300;400;500&display=swap" rel="stylesheet">
<style>
/* ============================================================
   HADLEY & STONE — FINE JEWELLERS CSS DESIGN SYSTEM
   Namespace: --jw-*  |  No external image dependencies
   ============================================================ */

:root {
  --jw-obsidian:   #0C0A08;
  --jw-charcoal:   #1A1614;
  --jw-velvet:     #2A2220;
  --jw-steel:      #5A5450;
  --jw-silver:     #A8A4A0;
  --jw-cream:      #F5F0E8;
  --jw-paper:      #FAF7F2;
  --jw-ivory:      #FDFBF7;
  --jw-gold:       #C8A055;
  --jw-gold-deep:  #A07A30;
  --jw-gold-pale:  #E8D4A8;
  --jw-platinum:   #D8D4CE;

  --jw-serif:  'Cormorant Garamond', Georgia, serif;
  --jw-sans:   'Jost', system-ui, sans-serif;

  --jw-ease:   cubic-bezier(.22,.68,0,1.2);
  --jw-dur:    .4s;
  --jw-r:      0px;
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; }

body.jw-body {
  font-family: var(--jw-sans);
  background: var(--jw-ivory);
  color: var(--jw-charcoal);
  overflow-x: hidden;
  -webkit-font-smoothing: antialiased;
}

/* ── NAV ──────────────────────────────────────────────────── */
.jw-nav {
  position: fixed; top: 0; left: 0; right: 0; z-index: 200;
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 60px;
  height: 76px;
  background: rgba(12,10,8,.9);
  backdrop-filter: blur(14px);
  border-bottom: 1px solid rgba(200,160,85,.12);
}
.jw-nav__logo {
  display: flex; flex-direction: column; gap: 2px;
}
.jw-nav__name {
  font-family: var(--jw-serif);
  font-size: 1.3rem;
  font-weight: 300;
  letter-spacing: .2em;
  color: var(--jw-cream);
  text-transform: uppercase;
}
.jw-nav__est {
  font-size: .58rem;
  letter-spacing: .4em;
  color: var(--jw-gold);
  text-transform: uppercase;
}
.jw-nav__links {
  display: flex; gap: 36px; list-style: none;
}
.jw-nav__links a {
  font-size: .75rem; letter-spacing: .14em;
  color: var(--jw-silver); text-decoration: none;
  text-transform: uppercase; transition: color var(--jw-dur);
}
.jw-nav__links a:hover { color: var(--jw-gold); }
.jw-nav__cta {
  padding: 10px 28px;
  border: 1px solid var(--jw-gold);
  color: var(--jw-gold);
  font-family: var(--jw-sans);
  font-size: .75rem; letter-spacing: .14em;
  text-transform: uppercase;
  text-decoration: none;
  transition: all var(--jw-dur);
}
.jw-nav__cta:hover { background: var(--jw-gold); color: var(--jw-obsidian); }

/* ── HERO ─────────────────────────────────────────────────── */
.jw-hero {
  position: relative; width: 100%; height: 100vh; min-height: 700px;
  overflow: hidden;
  background: var(--jw-obsidian);
  display: flex; align-items: flex-end;
}

/* Atelier ceiling */
.jw-atelier-ceiling {
  position: absolute; top: 0; left: 0; right: 0; height: 22%;
  background: linear-gradient(180deg, #080604 0%, #0E0C0A 100%);
  border-bottom: 1px solid rgba(200,160,85,.08);
}
.jw-atelier-ceiling::before {
  content: '';
  position: absolute; inset: 0;
  background: repeating-linear-gradient(
    90deg,
    transparent 0, transparent 79px,
    rgba(255,255,255,.015) 79px, rgba(255,255,255,.015) 80px
  );
}

/* Atelier walls */
.jw-atelier-wall {
  position: absolute; top: 0; bottom: 20%; left: 0; right: 0;
  background: linear-gradient(180deg, #0E0C0A 0%, #141210 60%, #181614 100%);
}
.jw-atelier-wall::before {
  content: '';
  position: absolute; inset: 0;
  background: repeating-linear-gradient(
    180deg,
    transparent 0, transparent 39px,
    rgba(255,255,255,.012) 39px, rgba(255,255,255,.012) 40px
  );
}

/* Dark green baize workbench */
.jw-bench {
  position: absolute;
  bottom: 20%; left: 0; right: 0;
  height: 42%;
  background: linear-gradient(180deg, #0A1408 0%, #0E1A0C 40%, #0A1208 100%);
  border-top: 2px solid #1C2818;
  border-bottom: 2px solid #060A04;
}
.jw-bench::before {
  content: '';
  position: absolute; inset: 0;
  background:
    radial-gradient(ellipse 40% 60% at 50% 40%, rgba(200,160,85,.06) 0%, transparent 70%),
    radial-gradient(ellipse 20% 30% at 30% 50%, rgba(200,160,85,.04) 0%, transparent 60%);
}
.jw-bench::after {
  content: '';
  position: absolute; top: 0; left: 0; right: 0; height: 3px;
  background: linear-gradient(90deg, transparent, rgba(200,160,85,.25), transparent);
}

/* Bench underside shadow */
.jw-bench-front {
  position: absolute; bottom: 20%; left: 0; right: 0;
  height: 18px;
  background: linear-gradient(180deg, #060A04 0%, #0A0E08 100%);
  border-bottom: 1px solid rgba(200,160,85,.1);
}

/* Workshop floor */
.jw-floor {
  position: absolute; bottom: 0; left: 0; right: 0; height: 20%;
  background: linear-gradient(180deg, #0E0C0A 0%, #080604 100%);
}
.jw-floor::before {
  content: '';
  position: absolute; inset: 0;
  background: repeating-linear-gradient(
    90deg,
    transparent 0, transparent 119px,
    rgba(255,255,255,.014) 119px, rgba(255,255,255,.014) 120px
  );
}

/* Spotlight from above */
.jw-spotlight {
  position: absolute;
  top: 0; left: 50%; transform: translateX(-50%);
  width: 0; height: 0;
  border-left: 180px solid transparent;
  border-right: 180px solid transparent;
  border-top: 320px solid rgba(200,160,85,.05);
  filter: blur(20px);
  pointer-events: none;
}

/* ── DISPLAY CASE ─────────────────────────────────────────── */
.jw-display-case {
  position: absolute;
  bottom: calc(20% + 40px);
  left: 50%; transform: translateX(-50%);
  width: 480px; height: 140px;
  z-index: 5;
}
.jw-case-body {
  position: absolute; inset: 0;
  background: linear-gradient(180deg, #1A1410 0%, #120E0C 100%);
  border: 1px solid rgba(200,160,85,.3);
  border-radius: 2px;
}
.jw-case-body::before { /* glass lid glare */
  content: '';
  position: absolute; top: 0; left: 0; right: 0; height: 30%;
  background: linear-gradient(180deg, rgba(200,160,85,.08) 0%, transparent 100%);
}
.jw-case-body::after { /* gold trim strip */
  content: '';
  position: absolute; top: 0; left: 0; right: 0; height: 3px;
  background: linear-gradient(90deg, var(--jw-gold-deep), var(--jw-gold), var(--jw-gold-deep));
}
.jw-case-velvet {
  position: absolute;
  top: 16px; bottom: 16px; left: 16px; right: 16px;
  background: linear-gradient(135deg, #1A1008 0%, #221608 100%);
  border-radius: 1px;
}
.jw-case-gems {
  position: absolute; inset: 20px;
  display: flex; align-items: center; justify-content: space-around;
}

/* Individual gem styles */
.jw-gem {
  position: relative;
  display: flex; flex-direction: column; align-items: center; gap: 8px;
  cursor: default;
}
.jw-gem__stone {
  position: relative;
}
.jw-gem--round .jw-gem__stone {
  border-radius: 50%;
}
.jw-gem--oval .jw-gem__stone {
  border-radius: 50% / 40%;
}
.jw-gem--emerald .jw-gem__stone {
  border-radius: 2px;
}
.jw-gem--pear .jw-gem__stone {
  border-radius: 50% 50% 30% 30% / 60% 60% 40% 40%;
}

.jw-gem__stone::before { /* facet highlight */
  content: '';
  position: absolute; top: 15%; left: 15%;
  width: 30%; height: 30%;
  background: rgba(255,255,255,.45);
  border-radius: 50%;
  filter: blur(2px);
}
.jw-gem__stone::after { /* inner facet lines */
  content: '';
  position: absolute; inset: 0;
  background: linear-gradient(135deg, rgba(255,255,255,.12) 0%, transparent 50%, rgba(0,0,0,.2) 100%);
  border-radius: inherit;
}
.jw-gem__mount {
  width: 12px; height: 6px;
  background: linear-gradient(180deg, var(--jw-gold) 0%, var(--jw-gold-deep) 100%);
  border-radius: 0 0 1px 1px;
}
.jw-gem__label {
  font-size: .44rem;
  letter-spacing: .1em;
  color: var(--jw-gold-pale);
  text-transform: uppercase;
  text-align: center;
  white-space: nowrap;
}

/* ── JEWELLER FIGURE (workshop left) ──────────────────────── */
.jw-jeweller {
  position: absolute;
  bottom: calc(20% + 2px);
  left: 12%;
  display: flex; flex-direction: column; align-items: center;
}
.jw-jeweller__head {
  width: 44px; height: 44px;
  border-radius: 50%;
  background: radial-gradient(circle at 38% 35%, #D4B090 0%, #A88060 50%, #6A5040 100%);
  position: relative;
  margin-bottom: -2px;
}
.jw-jeweller__head::before { /* loupe headband */
  content: '';
  position: absolute; top: 5px; left: -8px; right: -8px;
  height: 10px;
  background: linear-gradient(180deg, #3A3835 0%, #2A2826 100%);
  border-radius: 20px;
}
.jw-jeweller__head::after { /* loupe lens over right eye */
  content: '';
  position: absolute; top: 10px; right: 2px;
  width: 14px; height: 14px;
  border-radius: 50%;
  background: radial-gradient(circle at 35% 35%, rgba(150,200,240,.4) 0%, rgba(100,160,200,.2) 100%);
  border: 1.5px solid #5A5450;
}
.jw-jeweller__neck {
  width: 16px; height: 14px;
  background: #A88060;
}
.jw-jeweller__body {
  width: 80px; height: 90px;
  background: linear-gradient(180deg, #2A2420 0%, #1A1410 100%);
  border-radius: 4px 4px 0 0;
  position: relative;
}
.jw-jeweller__body::before { /* white lab coat */
  content: '';
  position: absolute; top: 0; left: 5px; right: 5px; bottom: 0;
  background: linear-gradient(180deg, #FAFAF8 0%, #E8E6E0 100%);
  border-radius: 3px 3px 0 0;
  clip-path: polygon(0 0, 45% 0, 45% 35%, 50% 38%, 55% 35%, 55% 0, 100% 0, 100% 100%, 0 100%);
}
.jw-jeweller__arm-r {
  position: absolute; bottom: 20px; right: -22px;
  width: 22px; height: 10px;
  background: #FAFAF8;
  border-radius: 5px;
  transform: rotate(-20deg);
}
.jw-jeweller__arm-r::after { /* tool in hand */
  content: '';
  position: absolute; right: -16px; top: 50%; transform: translateY(-50%);
  width: 18px; height: 3px;
  background: linear-gradient(90deg, #8A8480 0%, #C8C4BE 50%, #8A8480 100%);
  border-radius: 1px;
}
.jw-jeweller__arm-l {
  position: absolute; bottom: 20px; left: -20px;
  width: 20px; height: 10px;
  background: #FAFAF8;
  border-radius: 5px;
  transform: rotate(15deg);
}

/* ── RING DISPLAY STAND ───────────────────────────────────── */
.jw-ring-stands {
  position: absolute;
  bottom: calc(20% + 12px);
  right: 10%;
  display: flex; gap: 14px; align-items: flex-end;
}
.jw-ring-stand {
  display: flex; flex-direction: column; align-items: center;
}
.jw-ring-stand__cone {
  width: 18px; height: 60px;
  background: linear-gradient(180deg, #E8E4DC 0%, #C8C4BC 50%, #A8A4A0 100%);
  clip-path: polygon(10% 0%, 90% 0%, 100% 100%, 0% 100%);
}
.jw-ring-stand__base {
  width: 28px; height: 4px;
  background: linear-gradient(180deg, #C8C4BC 0%, #A8A4A0 100%);
  border-radius: 1px;
}
.jw-ring-stand__ring {
  position: absolute;
  width: 22px; height: 10px;
  border-radius: 50%;
  border: 2px solid;
  top: 6px; left: 50%; transform: translateX(-50%);
}

/* ── SPARKLE ELEMENTS ─────────────────────────────────────── */
.jw-sparkle {
  position: absolute;
  pointer-events: none;
}
.jw-sparkle::before,
.jw-sparkle::after {
  content: '';
  position: absolute;
  top: 50%; left: 50%;
  background: var(--jw-gold-pale);
  transform-origin: center;
}
.jw-sparkle::before {
  width: 100%; height: 1.5px;
  transform: translate(-50%, -50%);
}
.jw-sparkle::after {
  width: 1.5px; height: 100%;
  transform: translate(-50%, -50%);
}

/* ── HERO TEXT ────────────────────────────────────────────── */
.jw-hero__content {
  position: relative; z-index: 10;
  padding: 0 7% 80px;
  max-width: 600px;
}
.jw-hero__eyebrow {
  display: flex; align-items: center; gap: 16px; margin-bottom: 22px;
}
.jw-hero__eyebrow-line { width: 36px; height: 1px; background: var(--jw-gold); }
.jw-hero__eyebrow-text {
  font-size: .65rem; letter-spacing: .38em;
  color: var(--jw-gold); text-transform: uppercase;
}
.jw-hero__title {
  font-family: var(--jw-serif);
  font-size: clamp(2.8rem, 5.5vw, 5rem);
  font-weight: 300; line-height: 1.1;
  color: var(--jw-cream); margin-bottom: 22px;
}
.jw-hero__title em { font-style: italic; color: var(--jw-gold-pale); }
.jw-hero__tagline {
  font-size: 1rem; font-weight: 300; line-height: 1.75;
  color: var(--jw-silver); margin-bottom: 38px; max-width: 420px;
}
.jw-hero__actions { display: flex; gap: 16px; align-items: center; }

.jw-btn {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 13px 34px;
  font-family: var(--jw-sans);
  font-size: .78rem; letter-spacing: .14em;
  text-transform: uppercase; text-decoration: none;
  cursor: pointer; border: none;
  transition: all var(--jw-dur);
}
.jw-btn--gold { background: var(--jw-gold); color: var(--jw-obsidian); }
.jw-btn--gold:hover { background: var(--jw-gold-pale); }
.jw-btn--outline {
  background: transparent;
  border: 1px solid rgba(200,160,85,.4);
  color: var(--jw-gold-pale);
}
.jw-btn--outline:hover { border-color: var(--jw-gold); color: var(--jw-gold); }

/* Provenance card */
.jw-prov-card {
  position: absolute; bottom: 48px; right: 5%; z-index: 10;
  width: 210px;
  background: rgba(14,12,10,.92);
  border: 1px solid rgba(200,160,85,.2);
  padding: 20px 22px;
  backdrop-filter: blur(10px);
}
.jw-prov-card__title {
  font-size: .6rem; letter-spacing: .28em;
  color: var(--jw-gold); text-transform: uppercase; margin-bottom: 14px;
}
.jw-prov-card__row {
  display: flex; justify-content: space-between;
  margin-bottom: 7px; font-size: .78rem;
}
.jw-prov-card__key { color: var(--jw-silver); font-weight: 300; }
.jw-prov-card__val { color: var(--jw-cream); font-weight: 400; }
.jw-prov-card__sep { height: 1px; background: rgba(200,160,85,.12); margin: 12px 0; }
.jw-prov-card__cert {
  font-size: .65rem; color: var(--jw-gold);
  letter-spacing: .12em; text-transform: uppercase;
}

/* ── STATS ────────────────────────────────────────────────── */
.jw-stats {
  background: var(--jw-obsidian);
  border-bottom: 1px solid rgba(200,160,85,.1);
  display: grid; grid-template-columns: repeat(4,1fr);
}
.jw-stat {
  padding: 36px 20px; text-align: center;
  border-right: 1px solid rgba(200,160,85,.08);
}
.jw-stat:last-child { border-right: none; }
.jw-stat__val {
  font-family: var(--jw-serif); font-size: 2.6rem; font-weight: 300;
  color: var(--jw-gold); line-height: 1; margin-bottom: 6px;
}
.jw-stat__lbl {
  font-size: .64rem; letter-spacing: .2em;
  color: var(--jw-silver); text-transform: uppercase;
}

/* ── SECTION UTILS ────────────────────────────────────────── */
.jw-section { padding: 100px 7%; }
.jw-section--dark { background: var(--jw-charcoal); color: var(--jw-cream); }
.jw-section--ink  { background: var(--jw-obsidian); color: var(--jw-cream); }
.jw-section--ivory { background: var(--jw-ivory); }
.jw-section--cream { background: var(--jw-cream); }

.jw-section-label { display: flex; align-items: center; gap: 16px; margin-bottom: 16px; }
.jw-section-label__line { width: 30px; height: 1px; background: var(--jw-gold); }
.jw-section-label__text {
  font-size: .64rem; letter-spacing: .3em;
  color: var(--jw-gold); text-transform: uppercase;
}
.jw-h2 {
  font-family: var(--jw-serif); font-size: clamp(2rem, 3.5vw, 3.2rem);
  font-weight: 300; line-height: 1.2; margin-bottom: 18px;
}
.jw-h2 em { font-style: italic; }
.jw-lead {
  font-size: 1rem; font-weight: 300; line-height: 1.75;
  color: var(--jw-steel); max-width: 540px;
}
.jw-section--dark .jw-lead,
.jw-section--ink .jw-lead { color: var(--jw-silver); }

/* ── COLLECTION GRID ──────────────────────────────────────── */
.jw-collection__grid {
  display: grid; grid-template-columns: repeat(3,1fr);
  gap: 2px; margin-top: 56px;
}
.jw-collection-item {
  background: var(--jw-charcoal);
  position: relative; overflow: hidden;
  transition: background .35s;
}
.jw-collection-item:hover { background: #221E1A; }

/* CSS jewellery illustrations per item */
.jw-item-visual {
  position: relative; height: 220px;
  display: flex; align-items: center; justify-content: center;
  overflow: hidden;
}
.jw-item-glow {
  position: absolute; inset: 0;
  background: radial-gradient(ellipse 60% 60% at 50% 50%, rgba(200,160,85,.07) 0%, transparent 70%);
  pointer-events: none;
}

/* Generic ring CSS */
.jw-css-ring {
  position: relative; width: 80px; height: 80px;
}
.jw-css-ring__band {
  position: absolute; inset: 10px;
  border-radius: 50%;
  border: 8px solid;
}
.jw-css-ring__band::before { /* inner shine */
  content: '';
  position: absolute; top: 15%; left: 15%;
  width: 25%; height: 25%;
  border-radius: 50%;
  background: rgba(255,255,255,.25);
  filter: blur(2px);
}
.jw-css-ring__stone {
  position: absolute; top: 0; left: 50%; transform: translateX(-50%);
  width: 22px; height: 16px;
  border-radius: 50%;
  border: 2px solid rgba(200,160,85,.6);
}
.jw-css-ring__stone::before {
  content: '';
  position: absolute; top: 20%; left: 20%;
  width: 30%; height: 30%;
  border-radius: 50%;
  background: rgba(255,255,255,.5);
}

/* Generic pendant CSS */
.jw-css-pendant {
  display: flex; flex-direction: column; align-items: center; gap: 0;
}
.jw-css-pendant__chain {
  width: 1px; height: 60px;
  background: linear-gradient(180deg, transparent 0%, var(--jw-gold) 30%, var(--jw-gold) 70%, transparent 100%);
}
.jw-css-pendant__gem {
  width: 28px; height: 28px;
  border-radius: 50%;
  border: 2px solid rgba(200,160,85,.5);
  position: relative;
}
.jw-css-pendant__gem::before {
  content: '';
  position: absolute; top: 20%; left: 20%;
  width: 30%; height: 30%;
  border-radius: 50%;
  background: rgba(255,255,255,.5);
}
.jw-css-pendant__bail {
  width: 8px; height: 8px;
  border: 1.5px solid var(--jw-gold);
  border-radius: 50%;
  margin-top: -5px;
}

/* Bangle CSS */
.jw-css-bangle {
  width: 90px; height: 50px;
  border-radius: 50%;
  border: 10px solid;
  position: relative;
  transform: rotate(-20deg);
}
.jw-css-bangle::before {
  content: '';
  position: absolute; top: 3px; left: 3px;
  width: 30%; height: 40%;
  border-radius: 50%;
  background: rgba(255,255,255,.2);
  filter: blur(2px);
}

/* Earring pair CSS */
.jw-css-earrings {
  display: flex; gap: 24px; align-items: flex-start;
}
.jw-css-earring {
  display: flex; flex-direction: column; align-items: center;
}
.jw-css-earring__hook {
  width: 12px; height: 20px;
  border: 2px solid var(--jw-gold);
  border-radius: 50% 50% 0 0;
  border-bottom: none;
}
.jw-css-earring__drop {
  width: 10px; height: 10px;
  margin-top: -1px;
  border-radius: 50% 50% 40% 40%;
  border: 1.5px solid rgba(200,160,85,.5);
  position: relative;
}
.jw-css-earring__drop::before {
  content: '';
  position: absolute; top: 20%; left: 15%;
  width: 35%; height: 35%;
  border-radius: 50%;
  background: rgba(255,255,255,.5);
}

/* Wedding band CSS */
.jw-css-band {
  width: 90px; height: 38px;
  border-radius: 50%;
  border: 7px solid;
  position: relative;
  overflow: hidden;
}
.jw-css-band::before { /* diamond channel */
  content: '';
  position: absolute; top: 50%; left: 0; right: 0;
  height: 3px; margin-top: -1.5px;
  background: repeating-linear-gradient(
    90deg,
    rgba(255,255,255,.6) 0, rgba(255,255,255,.6) 4px,
    rgba(255,255,255,.2) 4px, rgba(255,255,255,.2) 8px
  );
}

/* Brooch CSS */
.jw-css-brooch {
  width: 60px; height: 60px;
  position: relative;
}
.jw-css-brooch__body {
  position: absolute; inset: 8px;
  border-radius: 50%;
  border: 4px solid var(--jw-gold);
  background: radial-gradient(circle at 35% 35%, rgba(200,160,85,.3) 0%, transparent 70%);
}
.jw-css-brooch__petal {
  position: absolute; width: 16px; height: 24px;
  border-radius: 50% 50% 50% 50% / 60% 60% 40% 40%;
  background: linear-gradient(180deg, var(--jw-gold) 0%, var(--jw-gold-deep) 100%);
  transform-origin: 50% 100%;
  bottom: 50%; left: calc(50% - 8px);
}

.jw-item-info { padding: 24px 28px 32px; }
.jw-item-info__type {
  font-size: .62rem; letter-spacing: .22em;
  color: var(--jw-gold); text-transform: uppercase; margin-bottom: 8px;
}
.jw-item-info__name {
  font-family: var(--jw-serif); font-size: 1.3rem;
  font-style: italic; color: var(--jw-cream); margin-bottom: 6px;
}
.jw-item-info__details {
  font-size: .8rem; color: var(--jw-silver); margin-bottom: 14px;
  line-height: 1.5;
}
.jw-item-info__price {
  font-family: var(--jw-serif); font-size: 1.4rem;
  font-weight: 300; color: var(--jw-gold-pale);
}

/* ── BESPOKE SPLIT ────────────────────────────────────────── */
.jw-bespoke {
  display: grid; grid-template-columns: 1fr 1fr; min-height: 600px;
}
.jw-bespoke__visual {
  background: var(--jw-obsidian);
  position: relative; overflow: hidden; min-height: 540px;
}
.jw-bespoke__text {
  padding: 80px 60px;
  background: var(--jw-ivory);
  display: flex; flex-direction: column; justify-content: center;
}

/* CSS workshop tools scene */
.jw-workshop-scene {
  position: absolute; inset: 0;
  display: flex; align-items: flex-end; justify-content: center;
  padding-bottom: 60px;
}
.jw-tool-bench {
  position: absolute;
  bottom: 0; left: 0; right: 0; height: 55%;
  background: linear-gradient(180deg, #0A1408 0%, #0C1A0A 100%);
  border-top: 2px solid #1C2818;
}
.jw-tool-bench::before {
  content: '';
  position: absolute; inset: 0;
  background: radial-gradient(ellipse 80% 60% at 50% 0%, rgba(200,160,85,.08) 0%, transparent 60%);
}

/* CSS loupe */
.jw-css-loupe {
  position: absolute; bottom: 55%; right: 28%;
  width: 48px; height: 60px;
}
.jw-css-loupe__lens {
  width: 36px; height: 36px; border-radius: 50%;
  border: 4px solid #8A8480;
  background: radial-gradient(circle at 35% 35%, rgba(150,200,240,.35) 0%, rgba(60,80,120,.2) 100%);
  position: relative;
}
.jw-css-loupe__lens::before {
  content: '';
  position: absolute; top: 15%; left: 15%;
  width: 28%; height: 28%; border-radius: 50%;
  background: rgba(255,255,255,.45);
}
.jw-css-loupe__handle {
  width: 4px; height: 28px;
  background: linear-gradient(180deg, #8A8480 0%, #5A5450 100%);
  margin-left: 30px; margin-top: -4px;
  transform: rotate(35deg); transform-origin: top center;
  border-radius: 2px;
}

/* CSS gem on bench */
.jw-bench-gem {
  position: absolute; bottom: calc(55% + 8px); left: 30%;
  width: 20px; height: 16px;
  border-radius: 50%;
  background: radial-gradient(circle at 35% 35%, #90C0F0 0%, #4070C0 50%, #1030A0 100%);
  border: 1px solid rgba(200,160,85,.4);
  box-shadow: 0 0 12px rgba(80,130,220,.5), 0 0 3px rgba(255,255,255,.3);
}
.jw-bench-gem::before {
  content: '';
  position: absolute; top: 15%; left: 15%;
  width: 30%; height: 30%; border-radius: 50%;
  background: rgba(255,255,255,.6);
}

/* CSS tweezers */
.jw-css-tweezers {
  position: absolute; bottom: 55%; left: 38%;
  width: 4px; height: 50px;
  background: linear-gradient(180deg, #C8C4BE 0%, #8A8480 100%);
  border-radius: 2px;
  transform: rotate(15deg); transform-origin: bottom center;
}
.jw-css-tweezers::before {
  content: '';
  position: absolute; bottom: 0; left: 1px;
  width: 4px; height: 16px;
  background: linear-gradient(180deg, #8A8480 0%, #C8C4BE 100%);
  border-radius: 2px;
  transform: rotate(8deg); transform-origin: top center;
}

/* ── HERITAGE TIMELINE ────────────────────────────────────── */
.jw-timeline {
  position: relative;
  margin-top: 56px;
  padding-left: 32px;
}
.jw-timeline::before {
  content: '';
  position: absolute; top: 8px; bottom: 8px; left: 8px;
  width: 1px;
  background: linear-gradient(180deg, transparent, var(--jw-gold), var(--jw-gold), transparent);
  opacity: .3;
}
.jw-timeline-item {
  position: relative; margin-bottom: 36px; padding-left: 28px;
}
.jw-timeline-item::before {
  content: '';
  position: absolute; left: -28px; top: 8px;
  width: 8px; height: 8px; border-radius: 50%;
  background: var(--jw-gold);
  border: 2px solid var(--jw-obsidian);
  box-shadow: 0 0 0 2px var(--jw-gold);
}
.jw-timeline-item__year {
  font-size: .68rem; letter-spacing: .2em;
  color: var(--jw-gold); text-transform: uppercase; margin-bottom: 4px;
}
.jw-timeline-item__text { font-size: .88rem; line-height: 1.65; color: var(--jw-silver); }

/* ── CRAFTSMANSHIP PROCESS ────────────────────────────────── */
.jw-craft__grid {
  display: grid; grid-template-columns: repeat(4,1fr);
  gap: 0; margin-top: 56px; position: relative;
}
.jw-craft__grid::before {
  content: '';
  position: absolute; top: 32px; left: 12.5%; right: 12.5%;
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(200,160,85,.25), rgba(200,160,85,.25), transparent);
}
.jw-craft-step { padding: 0 24px; text-align: center; }
.jw-craft-step__icon {
  width: 64px; height: 64px; border-radius: 50%;
  border: 1px solid rgba(200,160,85,.3);
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto 24px;
  background: var(--jw-obsidian);
  font-size: 1.5rem; position: relative; z-index: 1;
}
.jw-craft-step__title {
  font-family: var(--jw-serif); font-size: 1.1rem;
  font-style: italic; color: var(--jw-cream); margin-bottom: 10px;
}
.jw-craft-step__text { font-size: .84rem; line-height: 1.65; color: var(--jw-silver); }

/* ── BESPOKE COMMISSION PACKAGES ──────────────────────────── */
.jw-packages__grid {
  display: grid; grid-template-columns: repeat(3,1fr);
  gap: 2px; margin-top: 56px;
}
.jw-package {
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(200,160,85,.1);
  padding: 44px 36px;
  position: relative;
  transition: border-color .35s;
}
.jw-package:hover { border-color: rgba(200,160,85,.28); }
.jw-package--featured {
  background: rgba(200,160,85,.05);
  border-color: rgba(200,160,85,.32);
}
.jw-package__badge {
  position: absolute; top: -1px; left: 50%; transform: translateX(-50%);
  background: var(--jw-gold); color: var(--jw-obsidian);
  font-size: .58rem; letter-spacing: .2em; text-transform: uppercase;
  padding: 4px 16px;
}
.jw-package__tier {
  font-size: .64rem; letter-spacing: .25em;
  color: var(--jw-gold); text-transform: uppercase; margin-bottom: 14px;
}
.jw-package__name {
  font-family: var(--jw-serif); font-size: 1.7rem;
  font-weight: 300; color: var(--jw-cream); margin-bottom: 6px;
}
.jw-package__from {
  font-family: var(--jw-serif); font-size: 1.4rem;
  font-weight: 300; color: var(--jw-gold-pale); margin-bottom: 24px;
}
.jw-package__sep { height: 1px; background: rgba(200,160,85,.12); margin-bottom: 24px; }
.jw-package__features {
  list-style: none; display: flex; flex-direction: column;
  gap: 10px; margin-bottom: 32px;
}
.jw-package__feature {
  display: flex; gap: 12px; align-items: flex-start;
  font-size: .85rem; color: var(--jw-silver); line-height: 1.5;
}
.jw-package__feature::before { content: '✦'; color: var(--jw-gold); font-size: .7rem; margin-top: 2px; flex-shrink: 0; }

/* ── MATERIALS SHOWCASE ───────────────────────────────────── */
.jw-materials {
  display: grid; grid-template-columns: repeat(6,1fr);
  gap: 2px; margin-top: 56px;
}
.jw-material {
  padding: 32px 16px;
  text-align: center;
  background: var(--jw-charcoal);
  transition: background .3s;
}
.jw-material:hover { background: var(--jw-velvet); }
.jw-material__swatch {
  width: 48px; height: 48px; border-radius: 50%;
  margin: 0 auto 16px;
  position: relative;
  border: 1px solid rgba(255,255,255,.08);
}
.jw-material__swatch::before {
  content: '';
  position: absolute; top: 15%; left: 15%;
  width: 30%; height: 30%; border-radius: 50%;
  background: rgba(255,255,255,.2);
}
.jw-material__name {
  font-size: .68rem; letter-spacing: .15em;
  color: var(--jw-cream); text-transform: uppercase; margin-bottom: 4px;
}
.jw-material__desc { font-size: .72rem; color: var(--jw-silver); line-height: 1.5; }

/* ── BOOKING FORM ─────────────────────────────────────────── */
.jw-enquiry {
  display: grid; grid-template-columns: 1fr 1fr; min-height: 580px;
}
.jw-enquiry__info {
  background: var(--jw-obsidian); padding: 80px 7%;
  display: flex; flex-direction: column; justify-content: center;
}
.jw-enquiry__form-wrap {
  background: var(--jw-ivory); padding: 80px 7%;
  display: flex; flex-direction: column; justify-content: center;
}
.jw-enquiry__manifesto {
  font-family: var(--jw-serif); font-size: 1.45rem;
  font-style: italic; line-height: 1.6;
  color: var(--jw-cream); margin-top: 24px;
  padding-left: 20px;
  border-left: 1px solid var(--jw-gold);
}
.jw-form { display: flex; flex-direction: column; gap: 18px; }
.jw-field-group { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; }
.jw-field { display: flex; flex-direction: column; gap: 6px; }
.jw-field label {
  font-size: .65rem; letter-spacing: .15em;
  color: var(--jw-steel); text-transform: uppercase;
}
.jw-field input,
.jw-field select,
.jw-field textarea {
  background: transparent; border: none;
  border-bottom: 1px solid var(--jw-mist, #C8C4BF);
  padding: 10px 0;
  font-family: var(--jw-sans); font-size: .9rem;
  color: var(--jw-charcoal); outline: none;
  transition: border-color .3s; width: 100%;
}
.jw-field input:focus,
.jw-field select:focus,
.jw-field textarea:focus { border-bottom-color: var(--jw-gold); }
.jw-field textarea { resize: vertical; min-height: 80px; }
.jw-field select { cursor: pointer; appearance: none; }
.jw-form .jw-btn { align-self: flex-start; margin-top: 8px; }

/* ── TESTIMONIALS ─────────────────────────────────────────── */
.jw-testimonials__grid {
  display: grid; grid-template-columns: repeat(3,1fr);
  gap: 24px; margin-top: 56px;
}
.jw-testimonial {
  padding: 36px 30px;
  border-top: 1px solid var(--jw-gold);
  position: relative;
}
.jw-testimonial__stars { color: var(--jw-gold); font-size: .9rem; letter-spacing: 2px; margin-bottom: 16px; }
.jw-testimonial__text {
  font-family: var(--jw-serif); font-style: italic;
  font-size: 1rem; line-height: 1.75;
  color: var(--jw-cream); margin-bottom: 20px;
}
.jw-testimonial__author { font-size: .78rem; color: var(--jw-silver); }
.jw-testimonial__author strong {
  display: block; font-style: normal;
  font-family: var(--jw-sans); font-weight: 500;
  color: var(--jw-cream); margin-bottom: 2px;
}

/* ── FOOTER ───────────────────────────────────────────────── */
.jw-footer {
  background: var(--jw-obsidian); padding: 64px 7% 32px;
  border-top: 1px solid rgba(200,160,85,.12);
}
.jw-footer__top {
  display: grid; grid-template-columns: 1.5fr 1fr 1fr 1fr;
  gap: 48px; padding-bottom: 48px;
  border-bottom: 1px solid rgba(200,160,85,.08);
}
.jw-footer__name {
  font-family: var(--jw-serif); font-size: 1.4rem;
  font-weight: 300; color: var(--jw-cream); margin-bottom: 4px; letter-spacing: .1em;
}
.jw-footer__tagline {
  font-size: .6rem; letter-spacing: .35em;
  color: var(--jw-gold); text-transform: uppercase; margin-bottom: 18px;
}
.jw-footer__text { font-size: .84rem; line-height: 1.65; color: var(--jw-silver); }
.jw-footer__col-title {
  font-size: .62rem; letter-spacing: .25em;
  color: var(--jw-gold); text-transform: uppercase; margin-bottom: 18px;
}
.jw-footer__links { list-style: none; display: flex; flex-direction: column; gap: 9px; }
.jw-footer__links a {
  font-size: .84rem; color: var(--jw-silver); text-decoration: none; transition: color .3s;
}
.jw-footer__links a:hover { color: var(--jw-cream); }
.jw-footer__bottom {
  display: flex; justify-content: space-between; align-items: center;
  padding-top: 28px; font-size: .74rem; color: var(--jw-silver);
  flex-wrap: wrap; gap: 12px;
}
.jw-footer__bottom-links { display: flex; gap: 24px; }
.jw-footer__bottom-links a { color: var(--jw-silver); text-decoration: none; transition: color .3s; }
.jw-footer__bottom-links a:hover { color: var(--jw-gold); }

/* ── ANIMATIONS ───────────────────────────────────────────── */
@keyframes jw-sparkle-pulse {
  0%, 100% { opacity: 0; transform: scale(.5); }
  50%       { opacity: 1; transform: scale(1); }
}
@keyframes jw-gem-glow {
  0%, 100% { filter: brightness(1); }
  50%       { filter: brightness(1.3); }
}
.jw-gem { animation: jw-gem-glow 3s ease-in-out infinite; }
.jw-gem:nth-child(2) { animation-delay: .5s; }
.jw-gem:nth-child(3) { animation-delay: 1s; }
.jw-gem:nth-child(4) { animation-delay: 1.5s; }
.jw-gem:nth-child(5) { animation-delay: 2s; }
.jw-gem:nth-child(6) { animation-delay: 2.5s; }

/* ── RESPONSIVE ───────────────────────────────────────────── */
@media (max-width: 1100px) {
  .jw-collection__grid { grid-template-columns: repeat(2,1fr); }
  .jw-craft__grid { grid-template-columns: repeat(2,1fr); gap: 40px; }
  .jw-packages__grid { grid-template-columns: 1fr; }
  .jw-materials { grid-template-columns: repeat(3,1fr); }
  .jw-footer__top { grid-template-columns: 1fr 1fr; }
}
@media (max-width: 768px) {
  .jw-nav { padding: 0 24px; }
  .jw-nav__links { display: none; }
  .jw-hero__content { padding: 0 24px 80px; }
  .jw-prov-card { display: none; }
  .jw-bespoke { grid-template-columns: 1fr; }
  .jw-enquiry { grid-template-columns: 1fr; }
  .jw-testimonials__grid { grid-template-columns: 1fr; }
  .jw-collection__grid { grid-template-columns: 1fr; }
  .jw-materials { grid-template-columns: repeat(2,1fr); }
  .jw-field-group { grid-template-columns: 1fr; }
  .jw-section { padding: 64px 24px; }
  .jw-footer__top { grid-template-columns: 1fr; }
}
</style>
<?php get_header(); ?>
<div class="jw-body">
">

<!-- NAV -->
<nav class="jw-nav" role="navigation" aria-label="Main navigation">
  <div class="jw-nav__logo">
    <span class="jw-nav__name">Hadley &amp; Stone</span>
    <span class="jw-nav__est">Fine Jewellers · Bond Street, London · Est. 1962</span>
  </div>
  <ul class="jw-nav__links">
    <li><a href="#collection">Collection</a></li>
    <li><a href="#bespoke">Bespoke</a></li>
    <li><a href="#craftsmanship">Craftsmanship</a></li>
    <li><a href="#packages">Commissions</a></li>
    <li><a href="#enquiry">Enquire</a></li>
  </ul>
  <a href="#enquiry" class="jw-nav__cta">Private Appointment</a>
</nav>

<!-- HERO -->
<section class="jw-hero" aria-label="Hero — Fine Jewellery Atelier">
  <div class="jw-atelier-ceiling" aria-hidden="true"></div>
  <div class="jw-atelier-wall" aria-hidden="true"></div>
  <div class="jw-bench" aria-hidden="true"></div>
  <div class="jw-bench-front" aria-hidden="true"></div>
  <div class="jw-floor" aria-hidden="true"></div>
  <div class="jw-spotlight" aria-hidden="true"></div>

  <!-- PHP sparkle elements -->
  <?php foreach ($jw_sparkles as $sp) : ?>
  <div class="jw-sparkle" aria-hidden="true" style="
    top: <?php echo $sp['top']; ?>%;
    left: <?php echo $sp['left']; ?>%;
    width: <?php echo $sp['size']; ?>px;
    height: <?php echo $sp['size']; ?>px;
    animation: jw-sparkle-pulse <?php echo $sp['dur']; ?>ms ease-in-out <?php echo $sp['delay']; ?>ms infinite;
  "></div>
  <?php endforeach; ?>

  <!-- Jeweller figure at bench -->
  <div class="jw-jeweller" aria-hidden="true" role="img" aria-label="Jeweller at work">
    <div class="jw-jeweller__head"></div>
    <div class="jw-jeweller__neck"></div>
    <div class="jw-jeweller__body">
      <div class="jw-jeweller__arm-r"></div>
      <div class="jw-jeweller__arm-l"></div>
    </div>
  </div>

  <!-- Display case with gems -->
  <div class="jw-display-case" aria-hidden="true" role="img" aria-label="Gem display case">
    <div class="jw-case-body">
      <div class="jw-case-velvet">
        <div class="jw-case-gems">
          <?php foreach ($jw_gems as $gem) : ?>
          <div class="jw-gem jw-gem--<?php echo esc_attr($gem['shape']); ?>" title="<?php echo esc_attr($gem['name']); ?>">
            <div class="jw-gem__stone" style="
              width: <?php echo ($gem['shape'] === 'oval') ? '24px' : (($gem['shape'] === 'emerald') ? '20px' : (($gem['shape'] === 'pear') ? '18px' : '20px')); ?>;
              height: <?php echo ($gem['shape'] === 'oval') ? '18px' : (($gem['shape'] === 'emerald') ? '28px' : (($gem['shape'] === 'pear') ? '24px' : '20px')); ?>;
              background: radial-gradient(circle at 30% 30%,
                hsl(<?php echo $gem['hue']; ?>,<?php echo min(100,$gem['s']+30); ?>%,<?php echo min(90,$gem['l']+30); ?>%) 0%,
                hsl(<?php echo $gem['hue']; ?>,<?php echo $gem['s']; ?>%,<?php echo $gem['l']; ?>%) 50%,
                hsl(<?php echo $gem['hue']; ?>,<?php echo max(0,$gem['s']-10); ?>%,<?php echo max(5,$gem['l']-15); ?>%) 100%
              );
              box-shadow: 0 0 10px <?php echo esc_attr($gem['glow']); ?>, inset 0 0 4px rgba(255,255,255,.15);
            "></div>
            <div class="jw-gem__mount"></div>
            <div class="jw-gem__label"><?php echo esc_html($gem['name']); ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Ring display stands (right) -->
  <div class="jw-ring-stands" aria-hidden="true">
    <?php
    $stand_rings = [
      ['color'=>'#C8C4BE', 'gem_bg'=>'radial-gradient(circle at 35% 35%, #A0B8E0 0%, #4060C0 100%)'],
      ['color'=>'#C8A840', 'gem_bg'=>'radial-gradient(circle at 35% 35%, #E8A090 0%, #C04040 100%)'],
      ['color'=>'#C8C4BE', 'gem_bg'=>'radial-gradient(circle at 35% 35%, #80D090 0%, #208040 100%)'],
    ];
    foreach ($stand_rings as $sr) :
    ?>
    <div class="jw-ring-stand" style="position:relative;">
      <div class="jw-ring-stand__cone" style="background: linear-gradient(180deg, <?php echo esc_attr($sr['color']); ?> 0%, rgba(100,98,95,.8) 100%);"></div>
      <div class="jw-ring-stand__base" style="background: <?php echo esc_attr($sr['color']); ?>;"></div>
      <div class="jw-ring-stand__ring" style="
        background: <?php echo $sr['gem_bg']; ?>;
        border-color: <?php echo esc_attr($sr['color']); ?>;
        width: 22px; height: 10px;
        border-radius: 50%;
        position: absolute; top: 6px; left: 50%; transform: translateX(-50%);
      "></div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Key light glow -->
  <div style="position:absolute; inset:0; background: radial-gradient(ellipse 55% 65% at 50% 25%, rgba(200,160,85,.06) 0%, transparent 70%); pointer-events:none;" aria-hidden="true"></div>

  <!-- Hero text -->
  <div class="jw-hero__content">
    <div class="jw-hero__eyebrow">
      <div class="jw-hero__eyebrow-line"></div>
      <span class="jw-hero__eyebrow-text">Hadley &amp; Stone · Est. 1962</span>
    </div>
    <h1 class="jw-hero__title">
      Jewels made<br>to outlast<br><em>generations</em>
    </h1>
    <p class="jw-hero__tagline">
      Six decades of master goldsmithing on Bond Street.
      Every piece is designed, hand-set and finished in our Mayfair atelier
      by craftspeople who have trained for decades.
    </p>
    <div class="jw-hero__actions">
      <a href="#collection" class="jw-btn jw-btn--gold">Explore Collection</a>
      <a href="#enquiry" class="jw-btn jw-btn--outline">Private Appointment</a>
    </div>
  </div>

  <!-- Provenance card -->
  <div class="jw-prov-card" aria-label="Gem provenance details">
    <div class="jw-prov-card__title">Featured Stone</div>
    <div class="jw-prov-card__row">
      <span class="jw-prov-card__key">Origin</span>
      <span class="jw-prov-card__val">Kashmir</span>
    </div>
    <div class="jw-prov-card__row">
      <span class="jw-prov-card__key">Cut</span>
      <span class="jw-prov-card__val">Oval Brilliant</span>
    </div>
    <div class="jw-prov-card__row">
      <span class="jw-prov-card__key">Weight</span>
      <span class="jw-prov-card__val">4.82 ct</span>
    </div>
    <div class="jw-prov-card__row">
      <span class="jw-prov-card__key">Colour</span>
      <span class="jw-prov-card__val">Royal Blue</span>
    </div>
    <div class="jw-prov-card__sep"></div>
    <div class="jw-prov-card__cert">GIA Certified · No Heat</div>
  </div>
</section>

<!-- STATS -->
<div class="jw-stats" aria-label="Hadley and Stone achievements">
  <div class="jw-stat">
    <div class="jw-stat__val" data-target="62">62</div>
    <div class="jw-stat__lbl">Years on Bond Street</div>
  </div>
  <div class="jw-stat">
    <div class="jw-stat__val" data-target="12000">12,000+</div>
    <div class="jw-stat__lbl">Pieces Created</div>
  </div>
  <div class="jw-stat">
    <div class="jw-stat__val" data-target="4.9">4.9★</div>
    <div class="jw-stat__lbl">Client Rating</div>
  </div>
  <div class="jw-stat">
    <div class="jw-stat__val" data-target="180">180+</div>
    <div class="jw-stat__lbl">Gem Origins Sourced</div>
  </div>
</div>

<!-- COLLECTION -->
<section id="collection" class="jw-section jw-section--ink" aria-labelledby="jw-collection-heading">
  <div class="jw-section-label">
    <div class="jw-section-label__line"></div>
    <span class="jw-section-label__text">The Collection</span>
  </div>
  <h2 id="jw-collection-heading" class="jw-h2">
    Selected <em>Pieces</em>
  </h2>
  <p class="jw-lead">
    Each piece in our collection represents years of accumulated craft knowledge —
    from the cutting of the stone to the final polish of the metal.
  </p>

  <div class="jw-collection__grid" role="list">
    <?php
    $jw_visuals = [
      /* ring */
      '<div style="position:relative; width:90px; height:90px;">
        <div style="position:absolute; inset:12px; border-radius:50%; border:9px solid; border-color:linear-gradient(180deg,#D4C4A0,#8A7030); background:linear-gradient(180deg,#C8A840,#8A6820); box-shadow:0 0 0 1px rgba(200,160,85,.3);"></div>
        <div style="position:absolute; top:0; left:50%; transform:translateX(-50%); width:24px; height:16px; border-radius:50%; background:radial-gradient(circle at 30% 30%, #90B0E0 0%, #3060C0 50%, #1030A0 100%); border:2px solid rgba(200,160,85,.5); box-shadow:0 0 8px rgba(80,120,220,.6);"></div>
      </div>',
      /* pendant */
      '<div style="display:flex; flex-direction:column; align-items:center;">
        <div style="width:1px; height:55px; background:linear-gradient(180deg, transparent, #C8A840, #C8A840, transparent);"></div>
        <div style="width:30px; height:30px; border-radius:50%; background:radial-gradient(circle at 30% 30%, #90D090 0%, #208040 60%, #104020 100%); border:2px solid rgba(200,160,85,.5); box-shadow:0 0 10px rgba(50,180,80,.5); position:relative;">
          <div style="position:absolute; top:18%; left:18%; width:28%; height:28%; border-radius:50%; background:rgba(255,255,255,.55);"></div>
        </div>
      </div>',
      /* bangle */
      '<div style="width:88px; height:48px; border-radius:50%; border:10px solid; border-color:#C8A840; transform:rotate(-15deg); position:relative; box-shadow:0 0 0 1px rgba(200,160,85,.2); background:radial-gradient(circle at 30% 30%, rgba(200,160,85,.25) 0%, transparent 70%);">
        <div style="position:absolute; top:4px; left:4px; width:26%; height:36%; border-radius:50%; background:rgba(255,255,255,.22);"></div>
      </div>',
      /* earrings */
      '<div style="display:flex; gap:20px; align-items:flex-start;">
        <div style="display:flex; flex-direction:column; align-items:center;">
          <div style="width:11px; height:20px; border:2px solid #C8A840; border-radius:50% 50% 0 0; border-bottom:none;"></div>
          <div style="width:16px; height:22px; background:radial-gradient(circle at 30% 30%, #E09080 0%, #C04040 50%, #801020 100%); border-radius:50% 50% 40% 40%; border:1.5px solid rgba(200,160,85,.4); margin-top:-1px; box-shadow:0 0 8px rgba(200,60,60,.4); position:relative;"><div style="position:absolute; top:18%; left:16%; width:30%; height:30%; border-radius:50%; background:rgba(255,255,255,.5);"></div></div>
        </div>
        <div style="display:flex; flex-direction:column; align-items:center;">
          <div style="width:11px; height:20px; border:2px solid #C8A840; border-radius:50% 50% 0 0; border-bottom:none;"></div>
          <div style="width:16px; height:22px; background:radial-gradient(circle at 30% 30%, #E09080 0%, #C04040 50%, #801020 100%); border-radius:50% 50% 40% 40%; border:1.5px solid rgba(200,160,85,.4); margin-top:-1px; box-shadow:0 0 8px rgba(200,60,60,.4); position:relative;"><div style="position:absolute; top:18%; left:16%; width:30%; height:30%; border-radius:50%; background:rgba(255,255,255,.5);"></div></div>
        </div>
      </div>',
      /* band */
      '<div style="width:88px; height:36px; border-radius:50%; border:8px solid #C0C8D8; position:relative; overflow:hidden; box-shadow:0 0 0 1px rgba(200,210,230,.15);">
        <div style="position:absolute; top:50%; left:0; right:0; height:3px; margin-top:-1.5px; background:repeating-linear-gradient(90deg, rgba(255,255,255,.65) 0, rgba(255,255,255,.65) 4px, rgba(200,210,230,.3) 4px, rgba(200,210,230,.3) 8px);"></div>
        <div style="position:absolute; top:4px; left:5px; width:24%; height:36%; border-radius:50%; background:rgba(255,255,255,.25);"></div>
      </div>',
      /* brooch */
      '<div style="position:relative; width:64px; height:64px;">
        ' . implode('', array_map(function($i) {
            $angle = $i * 45;
            return '<div style="position:absolute; width:14px; height:22px; border-radius:50% 50% 50% 50%/60% 60% 40% 40%; background:linear-gradient(180deg,#C8A840 0%,#8A6820 100%); transform-origin:50% 100%; transform:rotate('.$angle.'deg) translateX(-50%); bottom:50%; left:50%;"></div>';
          }, range(0,7))) . '
        <div style="position:absolute; inset:14px; border-radius:50%; background:radial-gradient(circle at 35% 35%, #E0D090 0%, #A08030 60%, #604010 100%); border:2px solid rgba(200,160,85,.5); box-shadow:0 0 12px rgba(200,160,85,.4);"></div>
      </div>',
    ];
    foreach ($jw_collection as $i => $item) : ?>
    <div class="jw-collection-item" role="listitem">
      <div class="jw-item-visual" aria-hidden="true">
        <div class="jw-item-glow"></div>
        <?php echo $jw_visuals[$i % count($jw_visuals)]; ?>
      </div>
      <div class="jw-item-info">
        <div class="jw-item-info__type"><?php echo esc_html($item['type']); ?></div>
        <div class="jw-item-info__name"><?php echo esc_html($item['name']); ?></div>
        <div class="jw-item-info__details"><?php echo esc_html($item['metal']); ?> · <?php echo esc_html($item['gem']); ?></div>
        <div class="jw-item-info__price"><?php echo esc_html($item['price']); ?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- BESPOKE -->
<section id="bespoke" class="jw-bespoke" aria-labelledby="jw-bespoke-heading">
  <div class="jw-bespoke__visual" aria-hidden="true">
    <div class="jw-workshop-scene">
      <div class="jw-tool-bench"></div>
      <div class="jw-bench-gem"></div>
      <div class="jw-css-loupe">
        <div class="jw-css-loupe__lens"></div>
        <div class="jw-css-loupe__handle"></div>
      </div>
      <div class="jw-css-tweezers"></div>
    </div>
    <div style="position:absolute; bottom:24px; left:0; right:0; text-align:center; font-size:.62rem; letter-spacing:.2em; color:var(--jw-silver); text-transform:uppercase;">The Hadley &amp; Stone Atelier</div>
  </div>
  <div class="jw-bespoke__text">
    <div class="jw-section-label">
      <div class="jw-section-label__line"></div>
      <span class="jw-section-label__text">Bespoke Commissions</span>
    </div>
    <h2 id="jw-bespoke-heading" class="jw-h2">
      A jewel made<br>entirely <em>for you</em>
    </h2>
    <p class="jw-lead">
      Our bespoke service begins with a private consultation in our Bond Street atelier.
      We listen, sketch, source, and create — guiding you through every stage of the
      commission, from choosing the stone to the final setting.
    </p>

    <div class="jw-timeline" aria-label="Our heritage timeline">
      <div class="jw-timeline-item">
        <div class="jw-timeline-item__year">1962</div>
        <div class="jw-timeline-item__text">Founded by Edward Hadley and George Stone in a small workshop off Bond Street. The first commission: a sapphire engagement ring for a Cabinet minister.</div>
      </div>
      <div class="jw-timeline-item">
        <div class="jw-timeline-item__year">1978</div>
        <div class="jw-timeline-item__text">Appointed jewellers to HRH following the creation of a bespoke tiara. The royal warrant has been renewed at every five-year review since.</div>
      </div>
      <div class="jw-timeline-item">
        <div class="jw-timeline-item__year">2008</div>
        <div class="jw-timeline-item__text">Second generation family ownership. The atelier expands to include an on-site gem laboratory and in-house GIA-trained gemmologist.</div>
      </div>
      <div class="jw-timeline-item">
        <div class="jw-timeline-item__year">Today</div>
        <div class="jw-timeline-item__text">Six decades of craft, still entirely hand-finished in Mayfair. Every commission carries a lifetime guarantee and is fully documented for insurance and heritage purposes.</div>
      </div>
    </div>
  </div>
</section>

<!-- CRAFTSMANSHIP -->
<section id="craftsmanship" class="jw-section jw-section--dark" aria-labelledby="jw-craft-heading">
  <div class="jw-section-label">
    <div class="jw-section-label__line"></div>
    <span class="jw-section-label__text">The Process</span>
  </div>
  <h2 id="jw-craft-heading" class="jw-h2">
    Six decades of <em>craft</em>
  </h2>

  <div class="jw-craft__grid" role="list">
    <div class="jw-craft-step" role="listitem">
      <div class="jw-craft-step__icon" aria-hidden="true">◈</div>
      <h3 class="jw-craft-step__title">Consultation</h3>
      <p class="jw-craft-step__text">A private appointment in our Bond Street atelier to understand your vision, timeline and budget. We begin every commission by listening.</p>
    </div>
    <div class="jw-craft-step" role="listitem">
      <div class="jw-craft-step__icon" aria-hidden="true">◉</div>
      <h3 class="jw-craft-step__title">Stone Selection</h3>
      <p class="jw-craft-step__text">We source ethically certificated stones from our network of trusted suppliers across Kashmir, Colombia and Botswana — stones that will inspire the design.</p>
    </div>
    <div class="jw-craft-step" role="listitem">
      <div class="jw-craft-step__icon" aria-hidden="true">◎</div>
      <h3 class="jw-craft-step__title">Design &amp; Approval</h3>
      <p class="jw-craft-step__text">Our master goldsmiths produce hand-drawn sketches and wax models for your approval. Nothing proceeds until you are entirely satisfied.</p>
    </div>
    <div class="jw-craft-step" role="listitem">
      <div class="jw-craft-step__icon" aria-hidden="true">◇</div>
      <h3 class="jw-craft-step__title">Master Crafting</h3>
      <p class="jw-craft-step__text">Every piece is hand-fabricated, set and polished in our Mayfair atelier. A process that takes weeks, not hours — and shows in every finished jewel.</p>
    </div>
  </div>
</section>

<!-- MATERIALS -->
<section class="jw-section jw-section--ink" aria-labelledby="jw-materials-heading">
  <div class="jw-section-label">
    <div class="jw-section-label__line"></div>
    <span class="jw-section-label__text">Our Materials</span>
  </div>
  <h2 id="jw-materials-heading" class="jw-h2">
    Only the <em>finest</em>
  </h2>
  <div class="jw-materials" role="list">
    <?php
    $jw_mats = [
      ['name'=>'18ct Gold',     'bg'=>'radial-gradient(circle at 35% 35%, #F0D870 0%, #C8A840 50%, #8A6820 100%)', 'desc'=>'Yellow, white & rose'],
      ['name'=>'Platinum',      'bg'=>'radial-gradient(circle at 35% 35%, #F0F0F0 0%, #D0D0D0 50%, #9A9A9A 100%)', 'desc'=>'950 & 999 grades'],
      ['name'=>'Sapphire',      'bg'=>'radial-gradient(circle at 30% 30%, #8AAAE8 0%, #3060C0 50%, #102080 100%)', 'desc'=>'Kashmir & Ceylon'],
      ['name'=>'Ruby',          'bg'=>'radial-gradient(circle at 30% 30%, #F09090 0%, #C03040 50%, #800820 100%)', 'desc'=>'Burma & Mozambique'],
      ['name'=>'Emerald',       'bg'=>'radial-gradient(circle at 30% 30%, #70D080 0%, #208040 50%, #0A4020 100%)', 'desc'=>'Colombian origin'],
      ['name'=>'Diamond',       'bg'=>'radial-gradient(circle at 30% 30%, #F8F8F8 0%, #D8D8E8 50%, #A0A0B8 100%)', 'desc'=>'D–F colour, VS+'],
    ];
    foreach ($jw_mats as $mat) : ?>
    <div class="jw-material" role="listitem">
      <div class="jw-material__swatch" aria-hidden="true" style="background: <?php echo esc_attr($mat['bg']); ?>;"></div>
      <div class="jw-material__name"><?php echo esc_html($mat['name']); ?></div>
      <div class="jw-material__desc"><?php echo esc_html($mat['desc']); ?></div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- COMMISSION PACKAGES -->
<section id="packages" class="jw-section jw-section--dark" aria-labelledby="jw-packages-heading">
  <div class="jw-section-label">
    <div class="jw-section-label__line"></div>
    <span class="jw-section-label__text">Commission Guide</span>
  </div>
  <h2 id="jw-packages-heading" class="jw-h2">
    Bespoke <em>Commissions</em>
  </h2>
  <p class="jw-lead">
    Three pathways to owning a piece of Hadley &amp; Stone — from our curated
    ready-to-wear range to a fully bespoke commission built around a stone we
    source exclusively for you.
  </p>

  <div class="jw-packages__grid" role="list">
    <article class="jw-package" role="listitem">
      <div class="jw-package__tier">Ready to Wear</div>
      <div class="jw-package__name">From the Collection</div>
      <div class="jw-package__from">From £1,800</div>
      <div class="jw-package__sep"></div>
      <ul class="jw-package__features">
        <li class="jw-package__feature">Selection from current collection</li>
        <li class="jw-package__feature">Minor sizing adjustments included</li>
        <li class="jw-package__feature">Full documentation &amp; certificate</li>
        <li class="jw-package__feature">Hallmarked &amp; gift-boxed</li>
        <li class="jw-package__feature">Lifetime cleaning service</li>
      </ul>
      <a href="#enquiry" class="jw-btn jw-btn--outline">Book Viewing</a>
    </article>
    <article class="jw-package jw-package--featured" role="listitem">
      <div class="jw-package__badge">Most Popular</div>
      <div class="jw-package__tier">Semi-Bespoke</div>
      <div class="jw-package__name">Adapted Design</div>
      <div class="jw-package__from">From £4,500</div>
      <div class="jw-package__sep"></div>
      <ul class="jw-package__features">
        <li class="jw-package__feature">Adapt an existing Hadley &amp; Stone design</li>
        <li class="jw-package__feature">Stone selection consultation</li>
        <li class="jw-package__feature">Wax model for approval</li>
        <li class="jw-package__feature">Metal choice &amp; finish selection</li>
        <li class="jw-package__feature">Full provenance documentation</li>
        <li class="jw-package__feature">Lifetime guarantee</li>
      </ul>
      <a href="#enquiry" class="jw-btn jw-btn--gold">Begin Commission</a>
    </article>
    <article class="jw-package" role="listitem">
      <div class="jw-package__tier">Fully Bespoke</div>
      <div class="jw-package__name">Pure Commission</div>
      <div class="jw-package__from">From £12,000</div>
      <div class="jw-package__sep"></div>
      <ul class="jw-package__features">
        <li class="jw-package__feature">Entirely original design from brief</li>
        <li class="jw-package__feature">Exclusive stone sourcing worldwide</li>
        <li class="jw-package__feature">Multiple design iterations &amp; sketches</li>
        <li class="jw-package__feature">3D wax &amp; casting approval</li>
        <li class="jw-package__feature">GIA certification on all stones</li>
        <li class="jw-package__feature">Insurance valuation included</li>
        <li class="jw-package__feature">Heritage documentation &amp; box</li>
      </ul>
      <a href="#enquiry" class="jw-btn jw-btn--outline">Request Consultation</a>
    </article>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="jw-section jw-section--ink" aria-labelledby="jw-testimonials-heading">
  <div class="jw-section-label">
    <div class="jw-section-label__line"></div>
    <span class="jw-section-label__text">Client Voices</span>
  </div>
  <h2 id="jw-testimonials-heading" class="jw-h2">
    Pieces that <em>endure</em>
  </h2>
  <div class="jw-testimonials__grid" role="list">
    <blockquote class="jw-testimonial" role="listitem">
      <div class="jw-testimonial__stars" aria-label="5 stars">★★★★★</div>
      <p class="jw-testimonial__text">
        "The engagement ring Hadley &amp; Stone created for Cecilia is beyond anything I could
        have imagined. Three years later, strangers still stop to ask about it."
      </p>
      <footer class="jw-testimonial__author">
        <strong>Henry Ashworth-Clarke</strong>Bespoke Commission Client
      </footer>
    </blockquote>
    <blockquote class="jw-testimonial" role="listitem">
      <div class="jw-testimonial__stars" aria-label="5 stars">★★★★★</div>
      <p class="jw-testimonial__text">
        "I have been collecting from Hadley &amp; Stone for twenty years. Their eye for
        exceptional stones is unmatched — and the craftsmanship simply gets better."
      </p>
      <footer class="jw-testimonial__author">
        <strong>Lady G. Pemberton</strong>Long-standing Collector
      </footer>
    </blockquote>
    <blockquote class="jw-testimonial" role="listitem">
      <div class="jw-testimonial__stars" aria-label="5 stars">★★★★★</div>
      <p class="jw-testimonial__text">
        "The team worked tirelessly to source a Colombian emerald to match my grandmother's ring.
        The result is the most meaningful piece of jewellery I have ever owned."
      </p>
      <footer class="jw-testimonial__author">
        <strong>Sophia Middleton-Haigh</strong>Bespoke Commission Client
      </footer>
    </blockquote>
  </div>
</section>

<!-- ENQUIRY FORM -->
<section id="enquiry" class="jw-enquiry" aria-labelledby="jw-enquiry-heading">
  <div class="jw-enquiry__info">
    <div class="jw-section-label">
      <div class="jw-section-label__line"></div>
      <span class="jw-section-label__text">Private Appointments</span>
    </div>
    <h2 id="jw-enquiry-heading" class="jw-h2">
      Begin your <em>commission</em>
    </h2>
    <blockquote class="jw-enquiry__manifesto">
      "A great jewel is not bought — it is commissioned, considered,
      and crafted with patience. We have no other way of working."
      <cite style="display:block; margin-top:14px; font-size:.72rem; letter-spacing:.15em; font-style:normal; color:var(--jw-gold);">— JAMES HADLEY, MASTER GOLDSMITH</cite>
    </blockquote>
    <div style="margin-top:36px; display:flex; flex-direction:column; gap:14px;">
      <div>
        <div style="font-size:.62rem; letter-spacing:.22em; color:var(--jw-gold); text-transform:uppercase; margin-bottom:4px;">Atelier Address</div>
        <div style="font-size:.88rem; color:var(--jw-mist,#C8C5BF); line-height:1.6;">44 Bond Street, Mayfair, London W1S 1RB</div>
      </div>
      <div>
        <div style="font-size:.62rem; letter-spacing:.22em; color:var(--jw-gold); text-transform:uppercase; margin-bottom:4px;">By Appointment</div>
        <div style="font-size:.88rem; color:var(--jw-mist,#C8C5BF);">020 7946 0814</div>
      </div>
      <div>
        <div style="font-size:.62rem; letter-spacing:.22em; color:var(--jw-gold); text-transform:uppercase; margin-bottom:4px;">Email</div>
        <div style="font-size:.88rem; color:var(--jw-mist,#C8C5BF);">commissions@hadleystone.co.uk</div>
      </div>
    </div>
  </div>
  <div class="jw-enquiry__form-wrap">
    <div class="jw-section-label">
      <div class="jw-section-label__line"></div>
      <span class="jw-section-label__text">Enquiry</span>
    </div>
    <h3 style="font-family:var(--jw-serif); font-size:1.6rem; font-weight:300; margin-bottom:28px; color:var(--jw-charcoal);">
      Tell us about your <em>vision</em>
    </h3>
    <form class="jw-form" method="post" action="" novalidate aria-label="Commission enquiry form">
      <?php wp_nonce_field('tf_jw_enquiry', 'tf_jw_nonce'); ?>
      <div class="jw-field-group">
        <div class="jw-field">
          <label for="jw-first-name">First Name <span aria-hidden="true">*</span></label>
          <input type="text" id="jw-first-name" name="jw_first_name" required autocomplete="given-name">
        </div>
        <div class="jw-field">
          <label for="jw-last-name">Last Name <span aria-hidden="true">*</span></label>
          <input type="text" id="jw-last-name" name="jw_last_name" required autocomplete="family-name">
        </div>
      </div>
      <div class="jw-field-group">
        <div class="jw-field">
          <label for="jw-email">Email Address <span aria-hidden="true">*</span></label>
          <input type="email" id="jw-email" name="jw_email" required autocomplete="email">
        </div>
        <div class="jw-field">
          <label for="jw-phone">Telephone</label>
          <input type="tel" id="jw-phone" name="jw_phone" autocomplete="tel">
        </div>
      </div>
      <div class="jw-field">
        <label for="jw-interest">Area of Interest <span aria-hidden="true">*</span></label>
        <select id="jw-interest" name="jw_interest" required>
          <option value="">Please select…</option>
          <option value="engagement">Engagement Ring</option>
          <option value="wedding">Wedding Jewellery</option>
          <option value="bespoke">Bespoke Commission</option>
          <option value="collection">From the Collection</option>
          <option value="remodel">Remodelling &amp; Restoration</option>
          <option value="valuation">Valuation &amp; Insurance</option>
        </select>
      </div>
      <div class="jw-field-group">
        <div class="jw-field">
          <label for="jw-budget">Approximate Investment</label>
          <select id="jw-budget" name="jw_budget">
            <option value="">Please select…</option>
            <option value="under5k">Under £5,000</option>
            <option value="5k-15k">£5,000 – £15,000</option>
            <option value="15k-40k">£15,000 – £40,000</option>
            <option value="40k-plus">£40,000+</option>
            <option value="discuss">Prefer to discuss</option>
          </select>
        </div>
        <div class="jw-field">
          <label for="jw-timeline">Desired Timeline</label>
          <select id="jw-timeline" name="jw_timeline">
            <option value="">Please select…</option>
            <option value="urgent">Within 6 weeks</option>
            <option value="3months">3 months</option>
            <option value="6months">6 months</option>
            <option value="flexible">Flexible</option>
          </select>
        </div>
      </div>
      <div class="jw-field">
        <label for="jw-message">Tell Us About Your Vision</label>
        <textarea id="jw-message" name="jw_message" rows="4"
                  placeholder="Describe the piece, the occasion, any stones or metals you have in mind…"></textarea>
      </div>
      <button type="submit" class="jw-btn jw-btn--gold" aria-label="Submit commission enquiry">
        Send Enquiry
      </button>
    </form>
  </div>
</section>

<!-- FOOTER -->
<footer class="jw-footer" role="contentinfo" aria-label="Site footer">
  <div class="jw-footer__top">
    <div>
      <div class="jw-footer__name">Hadley &amp; Stone</div>
      <div class="jw-footer__tagline">Fine Jewellers · Bond Street · Est. 1962</div>
      <p class="jw-footer__text">
        Six decades of master goldsmithing in the heart of Mayfair.
        Bespoke commissions, rare stones and a lifetime guarantee on every piece.
      </p>
    </div>
    <div>
      <div class="jw-footer__col-title">Services</div>
      <ul class="jw-footer__links">
        <li><a href="#collection">The Collection</a></li>
        <li><a href="#bespoke">Bespoke Commissions</a></li>
        <li><a href="#craftsmanship">Craftsmanship</a></li>
        <li><a href="#packages">Commission Guide</a></li>
        <li><a href="#enquiry">Private Appointment</a></li>
      </ul>
    </div>
    <div>
      <div class="jw-footer__col-title">Expertise</div>
      <ul class="jw-footer__links">
        <li><a href="#">Engagement Rings</a></li>
        <li><a href="#">Wedding Jewellery</a></li>
        <li><a href="#">Gem Sourcing</a></li>
        <li><a href="#">Restoration</a></li>
        <li><a href="#">Valuations</a></li>
      </ul>
    </div>
    <div>
      <div class="jw-footer__col-title">Visit Us</div>
      <p style="font-size:.84rem; color:var(--jw-silver); line-height:1.7;">
        44 Bond Street<br>
        Mayfair<br>
        London W1S 1RB<br><br>
        020 7946 0814<br>
        commissions@hadleystone.co.uk
      </p>
    </div>
  </div>
  <div class="jw-footer__bottom">
    <span>© <?php echo date('Y'); ?> Hadley &amp; Stone Ltd. All rights reserved.</span>
    <div class="jw-footer__bottom-links">
      <a href="#">Privacy Policy</a>
      <a href="#">Terms &amp; Conditions</a>
      <a href="#">Cookie Policy</a>
    </div>
  </div>
</footer>

<script>
(function () {
  'use strict';

  /* ── Counter animation ─────────────────────────────────── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  const isFloat = v => !isNaN(v) && v % 1 !== 0;

  document.querySelectorAll('.jw-stat__val[data-target]').forEach(el => {
    const raw    = el.dataset.target;
    const target = parseFloat(raw);
    if (isNaN(target)) return;
    const duration = 1800;
    const start    = performance.now();
    const suffix   = el.textContent.replace(String(raw), '').trim();
    const tick = now => {
      const t   = Math.min((now - start) / duration, 1);
      const val = target * easeOut(t);
      el.textContent = (isFloat(target) ? val.toFixed(1) : Math.round(val).toLocaleString())
                       + (suffix ? suffix : '');
      if (t < 1) requestAnimationFrame(tick);
    };
    const obs = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) { requestAnimationFrame(tick); obs.disconnect(); }
    }, { threshold: 0.5 });
    obs.observe(el);
  });

  /* ── Nav scroll ─────────────────────────────────────────── */
  const nav = document.querySelector('.jw-nav');
  if (nav) {
    window.addEventListener('scroll', () => {
      nav.style.background = window.scrollY > 60
        ? 'rgba(12,10,8,.98)'
        : 'rgba(12,10,8,.9)';
    }, { passive: true });
  }

  /* ── Form ───────────────────────────────────────────────── */
  const form = document.querySelector('.jw-form');
  if (form) {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const btn = form.querySelector('button[type="submit"]');
      btn.textContent = 'Sending…';
      btn.disabled = true;
      setTimeout(() => {
        btn.textContent = 'Enquiry Received — We\'ll be in touch shortly';
        btn.style.background = '#4CAF50';
      }, 1200);
    });
  }

})();
</script>

</body>
</html>
</div><!-- .jw-body -->
<?php get_footer(); ?>
