<?php
/**
 * Template Name: TF — Law Firm
 * Description:   Premium law firm / solicitors landing page template.
 * Namespace:     --lf-*
 * Google Fonts:  Playfair Display + Source Sans 3
 * Palette:       Navy #0B1F3A / Gold #C9A84C / Ivory #F8F6F0 / Slate #4A5568 / White #FFFFFF
 * Hero scene:    CSS courthouse columns, scales of justice, legal books, barrister figure
 */

defined('ABSPATH') || exit;
get_header();
?>

<!-- ============================================================
     LAW FIRM — PREMIUM TEMPLATE
     ============================================================ -->
<div class="lf-wrap">

<!-- ── GOOGLE FONTS ─────────────────────────────────────────── -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;0,800;1,400;1,600&family=Source+Sans+3:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>
/* ── DESIGN TOKENS ──────────────────────────────────────────── */
:root{
  --lf-navy:#0B1F3A;
  --lf-navy-lt:#132848;
  --lf-navy-mid:#1C3A5E;
  --lf-gold:#C9A84C;
  --lf-gold-lt:#E2C17A;
  --lf-gold-dk:#A8862E;
  --lf-ivory:#F8F6F0;
  --lf-ivory-dk:#EDE9DF;
  --lf-slate:#4A5568;
  --lf-slate-lt:#718096;
  --lf-white:#FFFFFF;
  --lf-f-serif:'Playfair Display',Georgia,serif;
  --lf-f-sans:'Source Sans 3',sans-serif;
  --lf-r:4px;
  --lf-r-lg:10px;
  --lf-sh:0 4px 24px rgba(11,31,58,.18);
  --lf-sh-gold:0 4px 20px rgba(201,168,76,.25)
}

/* ── BASE ───────────────────────────────────────────────────── */
.lf-wrap{font-family:var(--lf-f-sans);color:var(--lf-navy);overflow-x:hidden}
.lf-wrap *,
.lf-wrap *::before,
.lf-wrap *::after{box-sizing:border-box;margin:0;padding:0}
.lf-wrap a{color:inherit;text-decoration:none}

/* ── LAYOUT ─────────────────────────────────────────────────── */
.lf-container{max-width:1180px;margin:0 auto;padding:0 24px}
.lf-section{padding:96px 0}
.lf-section--navy{background:var(--lf-navy)}
.lf-section--navy-lt{background:var(--lf-navy-lt)}
.lf-section--ivory{background:var(--lf-ivory)}
.lf-section--ivory-dk{background:var(--lf-ivory-dk)}
.lf-section--white{background:var(--lf-white)}

/* ── TYPOGRAPHY ─────────────────────────────────────────────── */
.lf-eyebrow{
  font-family:var(--lf-f-sans);font-size:.72rem;
  letter-spacing:.2em;text-transform:uppercase;
  color:var(--lf-gold);font-weight:700;
  display:flex;align-items:center;gap:12px;margin-bottom:16px
}
.lf-eyebrow::before{
  content:'';display:inline-block;width:36px;height:1px;background:var(--lf-gold)
}
.lf-eyebrow--dark{color:var(--lf-navy)}
.lf-eyebrow--dark::before{background:var(--lf-navy)}
.lf-h1{
  font-family:var(--lf-f-serif);
  font-size:clamp(2.6rem,6vw,5rem);
  font-weight:800;line-height:1.1;color:var(--lf-white)
}
.lf-h1 em{color:var(--lf-gold);font-style:italic}
.lf-h2{
  font-family:var(--lf-f-serif);
  font-size:clamp(2rem,4vw,3.2rem);
  font-weight:700;line-height:1.15
}
.lf-h3{
  font-family:var(--lf-f-serif);
  font-size:1.4rem;font-weight:700
}
.lf-lead{font-size:1.1rem;line-height:1.75}
.lf-sub{font-size:.95rem;line-height:1.7}

/* gold rule divider */
.lf-rule{
  display:block;width:56px;height:2px;background:var(--lf-gold);
  margin:20px 0
}
.lf-rule--center{margin:20px auto}

/* ── BUTTONS ────────────────────────────────────────────────── */
.lf-btn{
  display:inline-flex;align-items:center;gap:8px;
  font-family:var(--lf-f-sans);font-size:.9rem;font-weight:600;
  letter-spacing:.06em;text-transform:uppercase;
  padding:14px 32px;border-radius:var(--lf-r);
  border:2px solid transparent;cursor:pointer;
  transition:all .25s;white-space:nowrap
}
.lf-btn--gold{
  background:var(--lf-gold);color:var(--lf-navy);border-color:var(--lf-gold);
  box-shadow:var(--lf-sh-gold)
}
.lf-btn--gold:hover{background:var(--lf-gold-dk);border-color:var(--lf-gold-dk);transform:translateY(-2px)}
.lf-btn--outline-white{
  background:transparent;color:var(--lf-white);border-color:rgba(255,255,255,.4)
}
.lf-btn--outline-white:hover{background:rgba(255,255,255,.1);border-color:var(--lf-white)}
.lf-btn--navy{
  background:var(--lf-navy);color:var(--lf-white);border-color:var(--lf-navy)
}
.lf-btn--navy:hover{background:var(--lf-navy-lt);transform:translateY(-2px)}

/* ── HERO ───────────────────────────────────────────────────── */
.lf-hero{
  min-height:100vh;position:relative;overflow:hidden;
  background:linear-gradient(150deg,var(--lf-navy) 0%,var(--lf-navy-lt) 40%,var(--lf-navy-mid) 70%,#0F2A4A 100%);
  display:flex;align-items:center;padding:120px 0 80px
}

/* subtle dot grid */
.lf-hero::before{
  content:'';position:absolute;inset:0;
  background-image:radial-gradient(circle,rgba(201,168,76,.08) 1px,transparent 1px);
  background-size:40px 40px;pointer-events:none
}

/* gold accent lines */
.lf-hero-line{
  position:absolute;background:linear-gradient(to right,transparent,rgba(201,168,76,.25),transparent);
  height:1px;left:0;right:0;pointer-events:none
}

/* CSS COURTHOUSE SCENE */
.lf-hero-scene{
  position:absolute;right:0;top:0;bottom:0;
  width:500px;overflow:hidden
}

/* dark overlay left of scene */
.lf-hero-scene::before{
  content:'';position:absolute;inset:0;left:-60px;
  background:linear-gradient(to right,var(--lf-navy),transparent);
  z-index:2;pointer-events:none
}

/* building facade */
.lf-building{
  position:absolute;bottom:0;right:40px;
  width:380px;height:75vh;
  background:linear-gradient(to bottom,#1a3055,#0d2040);
  border-top:3px solid var(--lf-gold)
}

/* pediment (triangle top) */
.lf-pediment{
  position:absolute;bottom:100%;left:-20px;right:-20px;
  height:80px;overflow:hidden
}
.lf-pediment::before{
  content:'';position:absolute;bottom:0;left:0;right:0;
  height:80px;
  background:linear-gradient(to bottom,#1a3055,#0d2040);
  clip-path:polygon(50% 0%,100% 100%,0% 100%)
}
.lf-pediment-line{
  position:absolute;bottom:0;left:0;right:0;height:2px;background:var(--lf-gold)
}

/* columns */
.lf-columns{
  position:absolute;bottom:100%;left:0;right:0;height:220px;
  margin-bottom:78px;
  display:flex;justify-content:space-around;align-items:flex-end
}
.lf-col{
  flex:0 0 36px;background:linear-gradient(to right,#1a3055,#2a4570,#1a3055);
  border-radius:2px 2px 0 0;position:relative
}
.lf-col::before{
  content:'';position:absolute;top:-18px;left:-8px;right:-8px;height:18px;
  background:linear-gradient(to bottom,#2a4570,#1a3055);border-radius:2px
}
.lf-col::after{
  content:'';position:absolute;bottom:-12px;left:-8px;right:-8px;height:12px;
  background:#2a4570;border-radius:0 0 2px 2px
}

/* steps */
.lf-steps{
  position:absolute;bottom:0;left:-40px;right:-40px
}
.lf-step{
  height:16px;
  background:linear-gradient(to bottom,#1e3d65,#142e52)
}
.lf-step:nth-child(1){margin:0 0px}
.lf-step:nth-child(2){margin:0 20px}
.lf-step:nth-child(3){margin:0 40px}

/* windows on building */
.lf-window-row{
  display:flex;justify-content:space-evenly;padding:0 20px;margin-bottom:20px
}
.lf-window{
  width:36px;height:50px;
  background:rgba(201,168,76,.08);
  border:1px solid rgba(201,168,76,.15);
  border-radius:2px 2px 0 0;
  position:relative
}
.lf-window::before{
  content:'';position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);
  width:1px;height:100%;background:rgba(201,168,76,.15)
}
.lf-window::after{
  content:'';position:absolute;top:50%;left:0;right:0;height:1px;
  background:rgba(201,168,76,.15)
}
/* lit window */
.lf-window.lf-lit{
  background:rgba(201,168,76,.2);border-color:rgba(201,168,76,.4)
}

/* scales of justice */
@keyframes lf-scale-swing{
  0%,100%{transform:rotate(-4deg)}
  50%{transform:rotate(4deg)}
}
.lf-scales{
  position:absolute;top:60px;left:50%;transform:translateX(-60%);
  animation:lf-scale-swing 4s ease-in-out infinite;z-index:3
}
.lf-scales-beam{
  width:120px;height:3px;background:var(--lf-gold);
  position:relative;border-radius:2px
}
.lf-scales-beam::before{
  content:'';position:absolute;top:-24px;left:50%;transform:translateX(-50%);
  width:2px;height:24px;background:var(--lf-gold)
}
.lf-scales-beam::after{
  content:'';position:absolute;top:-48px;left:50%;transform:translateX(-50%);
  width:16px;height:16px;
  border-left:8px solid transparent;border-right:8px solid transparent;
  border-top:14px solid var(--lf-gold)
}
.lf-scale-pan{
  position:absolute;top:4px;width:44px;height:14px;
  border-radius:0 0 20px 20px;border:2px solid var(--lf-gold);
  border-top:none
}
.lf-scale-pan::before{
  content:'';position:absolute;top:-20px;left:50%;transform:translateX(-50%);
  width:1px;height:20px;background:var(--lf-gold)
}
.lf-scale-pan:nth-child(2){left:-42px}
.lf-scale-pan:nth-child(3){right:-42px}

/* book stack */
.lf-books{
  position:absolute;bottom:68px;left:25px;z-index:3
}
.lf-book{
  height:22px;border-radius:2px 4px 4px 2px;
  margin-bottom:2px;position:relative
}
.lf-book::before{
  content:'';position:absolute;left:0;top:0;bottom:0;width:6px;
  background:rgba(0,0,0,.25);border-radius:2px 0 0 2px
}
.lf-book:nth-child(1){width:72px;background:linear-gradient(to right,#8B2222,#B22222)}
.lf-book:nth-child(2){width:80px;background:linear-gradient(to right,#1a3d1a,#2d6a2d)}
.lf-book:nth-child(3){width:68px;background:linear-gradient(to right,#2a2a5a,#3d3d8a)}
.lf-book:nth-child(4){width:76px;background:linear-gradient(to right,#4a3a00,#7a6200)}
.lf-book:nth-child(5){width:70px;background:linear-gradient(to right,#5a1a1a,#8a2a2a)}

/* barrister figure */
.lf-barrister{
  position:absolute;bottom:68px;right:60px;z-index:3
}
.lf-bar-robe{
  width:52px;height:80px;
  background:linear-gradient(to bottom,#0a0a0a,#1a1a1a);
  border-radius:6px 6px 0 0;position:relative
}
/* white shirt front */
.lf-bar-robe::before{
  content:'';position:absolute;top:8px;left:50%;transform:translateX(-50%);
  width:16px;height:60px;
  background:linear-gradient(to bottom,#f0f0f0,#e0e0e0);
  border-radius:2px
}
/* bands collar */
.lf-bar-robe::after{
  content:'';position:absolute;top:-2px;left:50%;transform:translateX(-50%);
  width:22px;height:14px;
  background:var(--lf-white);border-radius:2px;
  box-shadow:0 1px 0 0 #ccc inset
}
.lf-bar-arms{position:relative}
.lf-bar-arm-l,
.lf-bar-arm-r{
  position:absolute;top:-70px;width:14px;height:50px;border-radius:7px;
  background:linear-gradient(to bottom,#0a0a0a,#1a1a1a)
}
.lf-bar-arm-l{left:-12px;transform:rotate(15deg);transform-origin:top center}
.lf-bar-arm-r{right:-12px;transform:rotate(-15deg);transform-origin:top center}
/* hand holding paper */
.lf-bar-arm-r::after{
  content:'📄';position:absolute;bottom:-8px;right:-8px;font-size:1rem
}
.lf-bar-legs{
  width:52px;height:56px;
  background:linear-gradient(to bottom,#0a0a0a,#151515);
  position:relative
}
.lf-bar-legs::before,
.lf-bar-legs::after{
  content:'';position:absolute;bottom:-10px;
  width:22px;height:12px;border-radius:0 0 4px 4px;
  background:#111
}
.lf-bar-legs::before{left:2px}
.lf-bar-legs::after{right:2px}
.lf-bar-head{
  width:36px;height:42px;border-radius:50% 50% 45% 45%;
  background:linear-gradient(to bottom,#f5d5b0,#e0b890);
  position:absolute;bottom:75px;left:50%;transform:translateX(-50%)
}
/* wig */
.lf-bar-wig{
  position:absolute;bottom:76px;left:50%;transform:translateX(-50%);
  width:48px;height:38px;z-index:4
}
.lf-bar-wig::before{
  content:'';position:absolute;top:0;left:0;right:0;height:24px;
  background:linear-gradient(to bottom,#f5f0e0,#e8e0c8);
  border-radius:10px 10px 0 0
}
/* wig curls */
.lf-bar-wig::after{
  content:'';position:absolute;top:16px;left:-4px;right:-4px;height:22px;
  background:radial-gradient(circle at 20% 50%, #f5f0e0 30%, transparent 31%),
             radial-gradient(circle at 50% 50%, #f5f0e0 30%, transparent 31%),
             radial-gradient(circle at 80% 50%, #f5f0e0 30%, transparent 31%);
  background-size:33% 100%;background-repeat:no-repeat
}

/* floating credential tags */
@keyframes lf-tag-float{
  0%,100%{transform:translateY(0)}
  50%{transform:translateY(-10px)}
}
.lf-hero-tag-float{
  position:absolute;
  background:rgba(11,31,58,.85);border:1px solid rgba(201,168,76,.45);
  border-radius:var(--lf-r);padding:10px 16px;
  font-family:var(--lf-f-sans);font-size:.8rem;font-weight:600;color:var(--lf-white);
  animation:lf-tag-float 3.5s ease-in-out infinite;z-index:5
}
.lf-hero-tag-float::before{
  content:'';display:inline-block;width:8px;height:8px;border-radius:50%;
  background:var(--lf-gold);margin-right:8px;vertical-align:middle
}

/* hero content */
.lf-hero-content{position:relative;z-index:3;max-width:580px}
.lf-hero-alert{
  display:inline-flex;align-items:center;gap:10px;
  border:1px solid rgba(201,168,76,.35);
  border-radius:var(--lf-r);padding:8px 18px;margin-bottom:32px;
  font-size:.82rem;font-weight:600;letter-spacing:.06em;
  color:var(--lf-gold-lt);text-transform:uppercase
}
.lf-hero-alert::before{content:'⚖️';font-size:1rem}
.lf-hero-desc{
  font-size:1.1rem;line-height:1.8;color:rgba(255,255,255,.78);
  margin:24px 0 38px
}
.lf-hero-btns{display:flex;gap:16px;flex-wrap:wrap}
.lf-hero-assurances{
  display:flex;gap:32px;margin-top:48px;padding-top:40px;
  border-top:1px solid rgba(255,255,255,.1);flex-wrap:wrap
}
.lf-hero-assurance{
  display:flex;align-items:center;gap:8px;
  font-size:.82rem;color:rgba(255,255,255,.6);font-weight:600;
  text-transform:uppercase;letter-spacing:.06em
}
.lf-hero-assurance::before{content:'✓';color:var(--lf-gold);font-weight:700}

/* ── STATS ──────────────────────────────────────────────────── */
.lf-stats-band{
  background:var(--lf-gold);padding:56px 0
}
.lf-stats-grid{
  display:grid;grid-template-columns:repeat(4,1fr);gap:1px;
  background:var(--lf-gold-dk)
}
.lf-stat-cell{
  background:var(--lf-gold);padding:32px;text-align:center
}
.lf-stat-num{
  font-family:var(--lf-f-serif);font-size:clamp(2.2rem,5vw,3.5rem);font-weight:800;
  color:var(--lf-navy);line-height:1;display:block
}
.lf-stat-label{
  font-size:.82rem;color:var(--lf-navy);opacity:.75;text-transform:uppercase;
  letter-spacing:.1em;margin-top:8px;display:block;font-weight:600
}

/* ── PRACTICE AREAS ─────────────────────────────────────────── */
.lf-areas-grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:2px;
  background:var(--lf-ivory-dk);margin-top:64px
}
.lf-area-card{
  background:var(--lf-white);padding:40px 32px;
  border-bottom:3px solid transparent;
  transition:all .3s;cursor:default
}
.lf-area-card:hover{border-bottom-color:var(--lf-gold);background:var(--lf-ivory)}
.lf-area-icon{
  font-size:2.2rem;margin-bottom:20px;display:block
}
.lf-area-name{
  font-family:var(--lf-f-serif);font-size:1.25rem;font-weight:700;
  color:var(--lf-navy);margin-bottom:12px
}
.lf-area-desc{font-size:.9rem;color:var(--lf-slate);line-height:1.7}
.lf-area-link{
  display:inline-flex;align-items:center;gap:6px;margin-top:16px;
  font-size:.82rem;font-weight:700;text-transform:uppercase;
  letter-spacing:.08em;color:var(--lf-gold)
}

/* ── SOLICITORS ─────────────────────────────────────────────── */
.lf-team-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:32px}
.lf-team-card{
  background:var(--lf-navy-lt);border-radius:var(--lf-r-lg);
  overflow:hidden;transition:transform .3s,box-shadow .3s
}
.lf-team-card:hover{transform:translateY(-6px);box-shadow:var(--lf-sh)}
.lf-team-avatar{
  height:200px;display:flex;align-items:flex-end;justify-content:center;
  padding-bottom:12px;overflow:hidden;position:relative
}
.lf-team-body{padding:28px;border-top:2px solid var(--lf-gold)}
.lf-team-name{
  font-family:var(--lf-f-serif);font-size:1.4rem;font-weight:700;
  color:var(--lf-white);margin-bottom:4px
}
.lf-team-role{
  font-size:.82rem;color:var(--lf-gold);text-transform:uppercase;
  letter-spacing:.1em;font-weight:600;margin-bottom:12px
}
.lf-team-bio{font-size:.9rem;color:rgba(255,255,255,.65);line-height:1.65;margin-bottom:16px}
.lf-team-qual{
  display:flex;flex-wrap:wrap;gap:6px
}
.lf-team-qual-badge{
  font-size:.72rem;font-weight:700;padding:3px 10px;border-radius:99px;
  background:rgba(201,168,76,.12);color:var(--lf-gold);
  border:1px solid rgba(201,168,76,.25)
}

/* CSS solicitor figures */
.lf-sfig{position:relative;width:70px;height:150px}
.lf-sfig-head{position:absolute;top:0;left:50%;transform:translateX(-50%);width:32px;height:38px;border-radius:50% 50% 45% 45%}
.lf-sfig-wig{position:absolute;top:-4px;left:50%;transform:translateX(-50%);width:44px;height:30px;z-index:1}
.lf-sfig-wig::before{content:'';position:absolute;top:0;left:0;right:0;height:18px;border-radius:8px 8px 0 0;background:#f5f0e0}
.lf-sfig-wig::after{content:'';position:absolute;top:12px;left:-4px;right:-4px;height:18px;background:radial-gradient(circle at 25% 50%,#f5f0e0 30%,transparent 31%),radial-gradient(circle at 50% 50%,#f5f0e0 30%,transparent 31%),radial-gradient(circle at 75% 50%,#f5f0e0 30%,transparent 31%);background-size:33% 100%;background-repeat:no-repeat}
.lf-sfig-robe{position:absolute;top:40px;left:50%;transform:translateX(-50%);width:46px;height:70px;background:linear-gradient(to bottom,#0a0a0a,#1a1a1a);border-radius:5px 5px 2px 2px}
.lf-sfig-robe::before{content:'';position:absolute;top:6px;left:50%;transform:translateX(-50%);width:14px;height:56px;background:#f0f0f0;border-radius:2px}
.lf-sfig-robe::after{content:'';position:absolute;top:-2px;left:50%;transform:translateX(-50%);width:20px;height:12px;background:#fff;border-radius:2px}
.lf-sfig-legs{position:absolute;bottom:0;left:50%;transform:translateX(-50%);width:44px;height:42px;background:#111;border-radius:0 0 4px 4px}
.lf-sfig-arm-l,.lf-sfig-arm-r{position:absolute;top:46px;width:12px;height:42px;border-radius:6px;background:#0a0a0a}
.lf-sfig-arm-l{left:1px;transform:rotate(5deg);transform-origin:top center}
.lf-sfig-arm-r{right:1px;transform:rotate(-5deg);transform-origin:top center}

/* figure skin tones */
.lf-sf1 .lf-sfig-head{background:linear-gradient(to bottom,#f5d5b0,#e0b890)}
.lf-sf2 .lf-sfig-head{background:linear-gradient(to bottom,#5C3317,#8B5C30)}
.lf-sf3 .lf-sfig-head{background:linear-gradient(to bottom,#FDDBB4,#F0C896)}

/* ── PROCESS ────────────────────────────────────────────────── */
.lf-process-grid{
  display:grid;grid-template-columns:repeat(4,1fr);gap:40px;
  position:relative
}
.lf-process-grid::before{
  content:'';position:absolute;top:36px;left:calc(12.5% + 18px);right:calc(12.5% + 18px);
  height:1px;background:linear-gradient(to right,var(--lf-gold),rgba(201,168,76,.2));
  z-index:0
}
.lf-process-step{text-align:center;position:relative;z-index:1}
.lf-process-icon{
  width:72px;height:72px;border-radius:50%;
  background:var(--lf-navy-lt);border:2px solid var(--lf-gold);
  display:flex;align-items:center;justify-content:center;
  font-size:1.8rem;margin:0 auto 20px;position:relative
}
.lf-process-num{
  position:absolute;top:-4px;right:-4px;width:24px;height:24px;border-radius:50%;
  background:var(--lf-gold);color:var(--lf-navy);
  font-family:var(--lf-f-sans);font-size:.75rem;font-weight:700;
  display:flex;align-items:center;justify-content:center
}
.lf-process-title{
  font-family:var(--lf-f-serif);font-size:1.1rem;font-weight:700;
  color:var(--lf-white);margin-bottom:10px
}
.lf-process-desc{font-size:.88rem;color:rgba(255,255,255,.6);line-height:1.65}

/* ── TESTIMONIALS ───────────────────────────────────────────── */
.lf-testi-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:28px}
.lf-testi-card{
  background:var(--lf-white);border-radius:var(--lf-r-lg);
  padding:36px;border-top:3px solid var(--lf-gold);
  box-shadow:var(--lf-sh);transition:transform .3s
}
.lf-testi-card:hover{transform:translateY(-4px)}
.lf-testi-stars{color:var(--lf-gold);font-size:1rem;letter-spacing:2px;margin-bottom:16px}
.lf-testi-text{
  font-family:var(--lf-f-serif);font-size:1rem;line-height:1.8;
  color:var(--lf-slate);margin-bottom:24px;font-style:italic
}
.lf-testi-author{
  display:flex;align-items:center;gap:14px;
  padding-top:18px;border-top:1px solid var(--lf-ivory-dk)
}
.lf-testi-avatar{
  width:44px;height:44px;border-radius:50%;
  background:var(--lf-navy-lt);
  display:flex;align-items:center;justify-content:center;
  font-size:1.2rem;flex-shrink:0;border:2px solid var(--lf-gold)
}
.lf-testi-name{
  font-family:var(--lf-f-serif);font-size:1rem;font-weight:700;color:var(--lf-navy)
}
.lf-testi-case{font-size:.8rem;color:var(--lf-gold);font-weight:600;text-transform:uppercase;letter-spacing:.06em}

/* ── FAQ ────────────────────────────────────────────────────── */
.lf-faq-grid{
  display:grid;grid-template-columns:1fr 1fr;gap:16px;max-width:960px;margin:0 auto
}
.lf-faq-item{
  background:var(--lf-white);border-radius:var(--lf-r);
  border:1px solid var(--lf-ivory-dk);overflow:hidden;
  box-shadow:0 2px 8px rgba(11,31,58,.06)
}
.lf-faq-q{
  width:100%;background:none;border:none;cursor:pointer;
  display:flex;align-items:center;justify-content:space-between;gap:16px;
  padding:22px 24px;text-align:left;
  font-family:var(--lf-f-serif);font-size:1rem;font-weight:600;
  color:var(--lf-navy);transition:color .25s
}
.lf-faq-q:hover{color:var(--lf-gold-dk)}
.lf-faq-icon{
  flex-shrink:0;width:28px;height:28px;border-radius:50%;
  border:2px solid var(--lf-ivory-dk);
  display:flex;align-items:center;justify-content:center;
  font-size:1.2rem;transition:all .3s;color:var(--lf-gold)
}
.lf-faq-item.lf-open .lf-faq-icon{
  transform:rotate(45deg);background:var(--lf-gold);color:var(--lf-white);
  border-color:var(--lf-gold)
}
.lf-faq-a{max-height:0;overflow:hidden;transition:max-height .4s ease}
.lf-faq-a-inner{
  padding:0 24px 22px;
  font-size:.9rem;color:var(--lf-slate);line-height:1.75;
  border-top:1px solid var(--lf-ivory-dk)
}

/* ── CONTACT ────────────────────────────────────────────────── */
.lf-contact-wrap{
  display:grid;grid-template-columns:1fr 1.2fr;gap:80px;align-items:start
}
.lf-contact-info h2{margin-bottom:16px}
.lf-contact-info p{color:var(--lf-slate);line-height:1.75;margin-bottom:32px}
.lf-contact-detail{
  display:flex;align-items:flex-start;gap:16px;
  padding:16px 0;border-bottom:1px solid var(--lf-ivory-dk)
}
.lf-contact-detail:last-of-type{border-bottom:none}
.lf-contact-icon{
  width:42px;height:42px;border-radius:var(--lf-r);
  background:var(--lf-navy);
  display:flex;align-items:center;justify-content:center;
  font-size:1.1rem;flex-shrink:0
}
.lf-contact-label{
  font-size:.75rem;font-weight:700;text-transform:uppercase;
  letter-spacing:.1em;color:var(--lf-gold);margin-bottom:4px
}
.lf-contact-value{font-size:.95rem;color:var(--lf-navy);font-weight:600;line-height:1.5}

/* form */
.lf-form{
  background:var(--lf-navy);border-radius:var(--lf-r-lg);padding:44px;
  border-top:4px solid var(--lf-gold)
}
.lf-form-title{
  font-family:var(--lf-f-serif);font-size:1.8rem;font-weight:700;
  color:var(--lf-white);margin-bottom:6px
}
.lf-form-subtitle{font-size:.9rem;color:rgba(255,255,255,.5);margin-bottom:32px}
.lf-form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.lf-field{margin-bottom:20px}
.lf-field label{
  display:block;margin-bottom:8px;
  font-size:.75rem;font-weight:700;text-transform:uppercase;
  letter-spacing:.1em;color:rgba(255,255,255,.6)
}
.lf-field input,
.lf-field select,
.lf-field textarea{
  width:100%;padding:13px 16px;border-radius:var(--lf-r);
  border:1px solid rgba(255,255,255,.15);
  background:rgba(255,255,255,.06);color:var(--lf-white);
  font-family:var(--lf-f-sans);font-size:.95rem;
  transition:border-color .25s;outline:none
}
.lf-field input:focus,
.lf-field select:focus,
.lf-field textarea:focus{border-color:var(--lf-gold)}
.lf-field select option{background:var(--lf-navy);color:var(--lf-white)}
.lf-field textarea{min-height:120px;resize:vertical}

/* ── FOOTER CTA ─────────────────────────────────────────────── */
.lf-footer-cta{
  padding:80px 0;text-align:center;
  background:var(--lf-navy);
  border-top:1px solid rgba(201,168,76,.2)
}
.lf-footer-cta h2{color:var(--lf-white);margin-bottom:16px}
.lf-footer-cta p{
  font-size:1.05rem;color:rgba(255,255,255,.65);
  max-width:520px;margin:0 auto 36px;line-height:1.75
}

/* ── SCROLL REVEAL ──────────────────────────────────────────── */
.lf-reveal{opacity:0;transform:translateY(28px);transition:opacity .65s ease,transform .65s ease}
.lf-reveal.lf-visible{opacity:1;transform:translateY(0)}

/* ── RESPONSIVE ─────────────────────────────────────────────── */
@media(max-width:1050px){
  .lf-hero-scene{width:380px}
}
@media(max-width:880px){
  .lf-hero-scene{display:none}
  .lf-stats-grid{grid-template-columns:repeat(2,1fr)}
  .lf-areas-grid{grid-template-columns:repeat(2,1fr)}
  .lf-team-grid{grid-template-columns:repeat(2,1fr)}
  .lf-process-grid{grid-template-columns:repeat(2,1fr);gap:32px}
  .lf-process-grid::before{display:none}
  .lf-testi-grid{grid-template-columns:1fr}
  .lf-faq-grid{grid-template-columns:1fr}
  .lf-contact-wrap{grid-template-columns:1fr}
}
@media(max-width:600px){
  .lf-section{padding:64px 0}
  .lf-areas-grid{grid-template-columns:1fr}
  .lf-team-grid{grid-template-columns:1fr}
  .lf-stats-grid{grid-template-columns:1fr 1fr}
  .lf-form-row{grid-template-columns:1fr}
  .lf-hero-assurances{flex-direction:column;gap:14px}
  .lf-hero-btns{flex-direction:column}
}
</style>

<!-- ── HERO ──────────────────────────────────────────────────── -->
<section class="lf-hero">

  <!-- gold accent lines -->
  <div class="lf-hero-line" style="top:35%"></div>
  <div class="lf-hero-line" style="top:70%"></div>

  <!-- CSS COURTHOUSE SCENE -->
  <div class="lf-hero-scene" aria-hidden="true">

    <!-- building -->
    <div class="lf-building">
      <!-- columns -->
      <div class="lf-columns">
        <?php for($c=0;$c<5;$c++):
          $h = 130 + $c*10;
        ?><div class="lf-col" style="height:<?=$h?>px"></div><?php endfor;?>
      </div>
      <!-- pediment -->
      <div class="lf-pediment"><div class="lf-pediment-line"></div></div>
      <!-- windows -->
      <?php
      srand(crc32('lf-windows'));
      for($row=0;$row<4;$row++):?>
      <div class="lf-window-row" style="margin-top:<?=24+$row*28?>px">
        <?php for($w=0;$w<4;$w++):
          $lit = rand(0,1) ? 'lf-lit' : '';
        ?><div class="lf-window <?=$lit?>"></div><?php endfor;?>
      </div>
      <?php endfor;?>
      <!-- steps -->
      <div class="lf-steps">
        <div class="lf-step"></div>
        <div class="lf-step"></div>
        <div class="lf-step"></div>
      </div>
    </div>

    <!-- scales of justice -->
    <div class="lf-scales">
      <div class="lf-scales-beam">
        <div class="lf-scale-pan"></div>
        <div class="lf-scale-pan"></div>
      </div>
    </div>

    <!-- book stack -->
    <div class="lf-books">
      <div class="lf-book"></div>
      <div class="lf-book"></div>
      <div class="lf-book"></div>
      <div class="lf-book"></div>
      <div class="lf-book"></div>
    </div>

    <!-- barrister figure -->
    <div class="lf-barrister">
      <div class="lf-bar-head"></div>
      <div class="lf-bar-wig"></div>
      <div class="lf-bar-robe"></div>
      <div class="lf-bar-arms">
        <div class="lf-bar-arm-l"></div>
        <div class="lf-bar-arm-r"></div>
      </div>
      <div class="lf-bar-legs"></div>
    </div>

    <!-- floating credential tags -->
    <div class="lf-hero-tag-float" style="top:12%;right:20px;animation-delay:0s">SRA Regulated</div>
    <div class="lf-hero-tag-float" style="top:28%;right:15px;animation-delay:1.2s">Legal 500 Ranked</div>
    <div class="lf-hero-tag-float" style="top:44%;right:25px;animation-delay:2.4s">No Win No Fee</div>

  </div><!-- /scene -->

  <div class="lf-container" style="position:relative;z-index:3">
    <div class="lf-hero-content">

      <div class="lf-hero-alert">Specialist Solicitors — Founded 1987</div>

      <h1 class="lf-h1">
        <em>Expert</em> Legal<br>
        Advice When<br>
        It Matters Most
      </h1>

      <span class="lf-rule"></span>

      <p class="lf-hero-desc">
        Fletcher & Drummond LLP is a leading full-service law firm with offices in London, Birmingham and Leeds.
        Our specialist solicitors deliver clear, strategic advice across commercial law, family law, personal injury and property.
      </p>

      <div class="lf-hero-btns">
        <a href="#contact" class="lf-btn lf-btn--gold">Free Consultation</a>
        <a href="#areas" class="lf-btn lf-btn--outline-white">Our Expertise</a>
      </div>

      <div class="lf-hero-assurances">
        <div class="lf-hero-assurance">SRA Regulated</div>
        <div class="lf-hero-assurance">Legal 500 Ranked</div>
        <div class="lf-hero-assurance">No Win, No Fee</div>
        <div class="lf-hero-assurance">Free Initial Advice</div>
      </div>

    </div>
  </div>

</section><!-- /hero -->

<!-- ── STATS ─────────────────────────────────────────────────── -->
<div class="lf-stats-band">
  <div class="lf-container">
    <div class="lf-stats-grid">
      <?php
      $stats = [
        ['num'=>97,'suf'=>'%','label'=>'Client Satisfaction'],
        ['num'=>38,'suf'=>'','label'=>'Years Established'],
        ['num'=>4800,'suf'=>'+','label'=>'Cases Won'],
        ['num'=>3,'suf'=>'','label'=>'UK Office Locations'],
      ];
      foreach($stats as $s):?>
      <div class="lf-stat-cell">
        <span class="lf-stat-num" data-target="<?=esc_attr($s['num'])?>" data-suffix="<?=esc_attr($s['suf'])?>">0</span>
        <span class="lf-stat-label"><?=esc_html($s['label'])?></span>
      </div>
      <?php endforeach;?>
    </div>
  </div>
</div>

<!-- ── PRACTICE AREAS ────────────────────────────────────────── -->
<section class="lf-section lf-section--ivory" id="areas">
  <div class="lf-container">

    <div style="max-width:600px;margin-bottom:16px">
      <div class="lf-eyebrow lf-eyebrow--dark">Legal Expertise</div>
      <h2 class="lf-h2">Areas of Practice</h2>
    </div>
    <p class="lf-lead" style="color:var(--lf-slate);max-width:680px;margin-bottom:0">
      From complex commercial transactions to sensitive family disputes, our solicitors bring decades of specialist
      experience to every case we take on.
    </p>

    <div class="lf-areas-grid">
      <?php
      $areas = [
        ['icon'=>'🏢','name'=>'Commercial Law','desc'=>'Business contracts, mergers, acquisitions, shareholder disputes, intellectual property and commercial litigation.'],
        ['icon'=>'👨‍👩‍👧','name'=>'Family Law','desc'=>'Divorce, financial settlements, child arrangements, cohabitation agreements and domestic injunctions.'],
        ['icon'=>'🏠','name'=>'Property Law','desc'=>'Residential conveyancing, commercial leases, lease extensions, boundary disputes and property litigation.'],
        ['icon'=>'⚕️','name'=>'Personal Injury','desc'=>'Road traffic accidents, medical negligence, workplace injuries and serious injury claims on a no win, no fee basis.'],
        ['icon'=>'📜','name'=>'Wills & Probate','desc'=>'Will drafting, lasting power of attorney, estate administration, contested probate and inheritance disputes.'],
        ['icon'=>'👔','name'=>'Employment Law','desc'=>'Unfair dismissal, discrimination, redundancy, settlement agreements and employment tribunal representation.'],
      ];
      foreach($areas as $a):?>
      <div class="lf-area-card lf-reveal">
        <span class="lf-area-icon"><?=esc_html($a['icon'])?></span>
        <div class="lf-area-name"><?=esc_html($a['name'])?></div>
        <p class="lf-area-desc"><?=esc_html($a['desc'])?></p>
        <span class="lf-area-link">Learn More →</span>
      </div>
      <?php endforeach;?>
    </div>

  </div>
</section>

<!-- ── TEAM ──────────────────────────────────────────────────── -->
<section class="lf-section lf-section--navy">
  <div class="lf-container">

    <div style="text-align:center;max-width:560px;margin:0 auto 64px">
      <div class="lf-eyebrow" style="justify-content:center">Our Solicitors</div>
      <h2 class="lf-h2" style="color:var(--lf-white)">Meet the Team</h2>
    </div>

    <div class="lf-team-grid">

      <!-- Solicitor 1 -->
      <div class="lf-team-card lf-sf1 lf-reveal">
        <div class="lf-team-avatar" style="background:linear-gradient(to bottom,var(--lf-navy-mid),var(--lf-navy-lt))">
          <div class="lf-sfig" aria-hidden="true">
            <div class="lf-sfig-head"></div>
            <div class="lf-sfig-wig"></div>
            <div class="lf-sfig-arm-l"></div>
            <div class="lf-sfig-arm-r"></div>
            <div class="lf-sfig-robe"></div>
            <div class="lf-sfig-legs"></div>
          </div>
        </div>
        <div class="lf-team-body">
          <div class="lf-team-name">Helena Fletcher</div>
          <div class="lf-team-role">Senior Partner — Commercial Law</div>
          <p class="lf-team-bio">Former City lawyer with 24 years acting for FTSE 100 companies and high-growth start-ups on complex M&A transactions and shareholder disputes.</p>
          <div class="lf-team-qual">
            <span class="lf-team-qual-badge">LLB (Hons)</span>
            <span class="lf-team-qual-badge">Legal 500 Ranked</span>
            <span class="lf-team-qual-badge">SRA Regulated</span>
          </div>
        </div>
      </div>

      <!-- Solicitor 2 -->
      <div class="lf-team-card lf-sf2 lf-reveal">
        <div class="lf-team-avatar" style="background:linear-gradient(to bottom,var(--lf-navy-mid),var(--lf-navy-lt))">
          <div class="lf-sfig" aria-hidden="true">
            <div class="lf-sfig-head"></div>
            <div class="lf-sfig-wig"></div>
            <div class="lf-sfig-arm-l"></div>
            <div class="lf-sfig-arm-r"></div>
            <div class="lf-sfig-robe"></div>
            <div class="lf-sfig-legs"></div>
          </div>
        </div>
        <div class="lf-team-body">
          <div class="lf-team-name">James Drummond</div>
          <div class="lf-team-role">Partner — Personal Injury</div>
          <p class="lf-team-bio">Specialist in serious injury claims, medical negligence and road traffic accident litigation. Has recovered over £85 million in compensation for clients over his career.</p>
          <div class="lf-team-qual">
            <span class="lf-team-qual-badge">LLB (Hons) Sheffield</span>
            <span class="lf-team-qual-badge">APIL Member</span>
            <span class="lf-team-qual-badge">No Win No Fee</span>
          </div>
        </div>
      </div>

      <!-- Solicitor 3 -->
      <div class="lf-team-card lf-sf3 lf-reveal">
        <div class="lf-team-avatar" style="background:linear-gradient(to bottom,var(--lf-navy-mid),var(--lf-navy-lt))">
          <div class="lf-sfig" aria-hidden="true">
            <div class="lf-sfig-head"></div>
            <div class="lf-sfig-wig"></div>
            <div class="lf-sfig-arm-l"></div>
            <div class="lf-sfig-arm-r"></div>
            <div class="lf-sfig-robe"></div>
            <div class="lf-sfig-legs"></div>
          </div>
        </div>
        <div class="lf-team-body">
          <div class="lf-team-name">Sophie Adeyemi</div>
          <div class="lf-team-role">Associate — Family Law</div>
          <p class="lf-team-bio">Empathetic and tenacious family law specialist covering divorce proceedings, child arrangements and complex financial remedy cases for high-net-worth individuals.</p>
          <div class="lf-team-qual">
            <span class="lf-team-qual-badge">LPC Distinction</span>
            <span class="lf-team-qual-badge">Resolution Member</span>
            <span class="lf-team-qual-badge">Mediator Accredited</span>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- ── PROCESS ───────────────────────────────────────────────── -->
<section class="lf-section lf-section--navy-lt">
  <div class="lf-container">

    <div style="text-align:center;max-width:560px;margin:0 auto 72px">
      <div class="lf-eyebrow" style="justify-content:center">How We Work</div>
      <h2 class="lf-h2" style="color:var(--lf-white)">Our Client Process</h2>
    </div>

    <div class="lf-process-grid">
      <?php
      $steps = [
        ['icon'=>'📞','title'=>'Free Consultation','desc'=>'Call or book online for a no-obligation 30-minute consultation with one of our specialist solicitors.'],
        ['icon'=>'📋','title'=>'Case Assessment','desc'=>'We review your matter, advise on merits and costs, and explain your legal options in plain English.'],
        ['icon'=>'⚖️','title'=>'Legal Strategy','desc'=>'Your solicitor develops a clear strategy and timeline, keeping you informed at every milestone.'],
        ['icon'=>'🏆','title'=>'Resolution','desc'=>'We pursue the best outcome — through negotiation, mediation or litigation — and see the matter through to conclusion.'],
      ];
      foreach($steps as $i=>$s):?>
      <div class="lf-process-step lf-reveal">
        <div class="lf-process-icon">
          <?=esc_html($s['icon'])?>
          <div class="lf-process-num"><?=$i+1?></div>
        </div>
        <h3 class="lf-process-title"><?=esc_html($s['title'])?></h3>
        <p class="lf-process-desc"><?=esc_html($s['desc'])?></p>
      </div>
      <?php endforeach;?>
    </div>

  </div>
</section>

<!-- ── TESTIMONIALS ──────────────────────────────────────────── -->
<section class="lf-section lf-section--ivory">
  <div class="lf-container">

    <div style="text-align:center;max-width:560px;margin:0 auto 64px">
      <div class="lf-eyebrow lf-eyebrow--dark" style="justify-content:center">Client Reviews</div>
      <h2 class="lf-h2">What Our Clients Say</h2>
    </div>

    <div class="lf-testi-grid">
      <?php
      $testis = [
        [
          'text'=>'Helena guided us through a hostile takeover bid with absolute precision. Her commercial instincts and calm under pressure were invaluable. Exceptional firm.',
          'name'=>'Richard Pemberton','case'=>'M&A Defence — FTSE 250 Company','avatar'=>'🏢'
        ],
        [
          'text'=>'After my accident, James and his team recovered significantly more than we anticipated. He kept me informed throughout and I never felt like just another case.',
          'name'=>'Cynthia Marsh','case'=>'Road Traffic Accident — £340,000 Settlement','avatar'=>'⚕️'
        ],
        [
          'text'=>'Sophie dealt with my divorce with real sensitivity and professionalism. The financial outcome was far better than I expected given how complicated our assets were.',
          'name'=>'Anonymous Client','case'=>'High-Net-Worth Divorce — London','avatar'=>'👨‍👩‍👧'
        ],
      ];
      foreach($testis as $t):?>
      <div class="lf-testi-card lf-reveal">
        <div class="lf-testi-stars">★★★★★</div>
        <p class="lf-testi-text">"<?=esc_html($t['text'])?>"</p>
        <div class="lf-testi-author">
          <div class="lf-testi-avatar"><?=esc_html($t['avatar'])?></div>
          <div>
            <div class="lf-testi-name"><?=esc_html($t['name'])?></div>
            <div class="lf-testi-case"><?=esc_html($t['case'])?></div>
          </div>
        </div>
      </div>
      <?php endforeach;?>
    </div>

  </div>
</section>

<!-- ── FAQ ───────────────────────────────────────────────────── -->
<section class="lf-section lf-section--ivory-dk">
  <div class="lf-container">

    <div style="text-align:center;max-width:560px;margin:0 auto 56px">
      <div class="lf-eyebrow lf-eyebrow--dark" style="justify-content:center">Common Questions</div>
      <h2 class="lf-h2">Frequently Asked</h2>
    </div>

    <div class="lf-faq-grid">
      <?php
      $faqs = [
        ['q'=>'Is the initial consultation really free?','a'=>'Yes — your first 30-minute consultation with one of our solicitors is completely free of charge, with no obligation to proceed. We want to understand your situation before you commit to anything.'],
        ['q'=>'How much will my legal matter cost?','a'=>'Costs depend on the complexity of your matter. We provide clear, written fee estimates upfront and offer fixed-fee arrangements for many services, including conveyancing and will drafting.'],
        ['q'=>'Do you offer no win, no fee?','a'=>'We offer conditional fee agreements (no win, no fee) for personal injury, medical negligence and some employment claims. Your solicitor will advise you on eligibility during your free consultation.'],
        ['q'=>'How long will my case take?','a'=>'Timescales vary widely. A straightforward conveyance might take 8–12 weeks; complex litigation can take 18–24 months. Your solicitor will give you a realistic timeline after reviewing your case.'],
        ['q'=>'Which offices can I visit?','a'=>'We have offices in London (City), Birmingham (Colmore Row) and Leeds (Park Row). We also offer video and telephone consultations for clients who prefer remote advice.'],
        ['q'=>'Is my information kept confidential?','a'=>'Absolutely. All information you share is protected by strict legal professional privilege and our Privacy Policy. We will never share your information with any third party without your explicit consent.'],
      ];
      foreach($faqs as $i=>$f):?>
      <div class="lf-faq-item">
        <button class="lf-faq-q" aria-expanded="false" aria-controls="lf-faq-a-<?=$i?>">
          <?=esc_html($f['q'])?>
          <span class="lf-faq-icon" aria-hidden="true">+</span>
        </button>
        <div class="lf-faq-a" id="lf-faq-a-<?=$i?>" role="region">
          <div class="lf-faq-a-inner"><?=esc_html($f['a'])?></div>
        </div>
      </div>
      <?php endforeach;?>
    </div>

  </div>
</section>

<!-- ── CONTACT ───────────────────────────────────────────────── -->
<section class="lf-section lf-section--white" id="contact">
  <div class="lf-container">
    <div class="lf-contact-wrap">

      <div class="lf-contact-info lf-reveal">
        <div class="lf-eyebrow lf-eyebrow--dark">Get Legal Advice</div>
        <h2 class="lf-h2">Contact Our Solicitors</h2>
        <span class="lf-rule"></span>
        <p>
          Whether you need urgent legal advice or want to discuss a matter at your own pace, our team is here to help.
          Book your free consultation online or call us now.
        </p>

        <?php
        $details = [
          ['icon'=>'📞','label'=>'Telephone','value'=>"0207 000 1234\nFree: 0800 000 1234"],
          ['icon'=>'📧','label'=>'Email','value'=>'hello@fletcherdrummond.co.uk'],
          ['icon'=>'📍','label'=>'London Office','value'=>"1 Temple Row, London EC4A 1AA"],
          ['icon'=>'🕒','label'=>'Office Hours','value'=>"Mon–Fri 9am–6pm\nEmergency line 24/7"],
        ];
        foreach($details as $d):?>
        <div class="lf-contact-detail">
          <div class="lf-contact-icon"><?=esc_html($d['icon'])?></div>
          <div>
            <div class="lf-contact-label"><?=esc_html($d['label'])?></div>
            <div class="lf-contact-value" style="white-space:pre-line"><?=esc_html($d['value'])?></div>
          </div>
        </div>
        <?php endforeach;?>

        <div style="margin-top:32px;padding:20px;background:var(--lf-ivory);border-radius:var(--lf-r);border-left:3px solid var(--lf-gold)">
          <p style="font-size:.88rem;color:var(--lf-slate);line-height:1.7">
            <strong style="color:var(--lf-navy)">SRA Regulated:</strong>
            Fletcher &amp; Drummond LLP is authorised and regulated by the Solicitors Regulation Authority (SRA No. 123456789).
          </p>
        </div>

      </div>

      <div class="lf-form lf-reveal">
        <div class="lf-form-title">Book Free Consultation</div>
        <div class="lf-form-subtitle">We'll respond within 2 hours during office hours</div>

        <form method="post" action="<?=esc_url(admin_url('admin-post.php'))?>">
          <?php wp_nonce_field('tf_lf_booking','tf_lf_nonce'); ?>
          <input type="hidden" name="action" value="tf_lf_booking">

          <div class="lf-form-row">
            <div class="lf-field">
              <label for="lf-fname">First Name</label>
              <input type="text" id="lf-fname" name="first_name" placeholder="Richard" required autocomplete="given-name">
            </div>
            <div class="lf-field">
              <label for="lf-lname">Last Name</label>
              <input type="text" id="lf-lname" name="last_name" placeholder="Pemberton" required autocomplete="family-name">
            </div>
          </div>

          <div class="lf-form-row">
            <div class="lf-field">
              <label for="lf-email">Email Address</label>
              <input type="email" id="lf-email" name="email" placeholder="you@example.com" required autocomplete="email">
            </div>
            <div class="lf-field">
              <label for="lf-phone">Phone Number</label>
              <input type="tel" id="lf-phone" name="phone" placeholder="+44 7700 900000" autocomplete="tel">
            </div>
          </div>

          <div class="lf-field">
            <label for="lf-area">Area of Law</label>
            <select id="lf-area" name="legal_area">
              <option value="">— Select area of law —</option>
              <option value="commercial">Commercial Law</option>
              <option value="family">Family Law</option>
              <option value="property">Property Law</option>
              <option value="personal-injury">Personal Injury</option>
              <option value="wills">Wills &amp; Probate</option>
              <option value="employment">Employment Law</option>
              <option value="other">Other / Not Sure</option>
            </select>
          </div>

          <div class="lf-field">
            <label for="lf-urgency">Urgency</label>
            <select id="lf-urgency" name="urgency">
              <option value="">— How urgent is your matter? —</option>
              <option value="urgent">Urgent — within 24 hours</option>
              <option value="this-week">This week</option>
              <option value="flexible">I'm flexible</option>
            </select>
          </div>

          <div class="lf-field">
            <label for="lf-message">Brief Description of Your Matter</label>
            <textarea id="lf-message" name="message" placeholder="Please describe your legal matter in a few sentences..."></textarea>
          </div>

          <button type="submit" class="lf-btn lf-btn--gold" style="width:100%;justify-content:center;font-size:1rem;padding:16px">
            ⚖️ Book Free Consultation
          </button>
          <p style="text-align:center;margin-top:12px;font-size:.8rem;color:rgba(255,255,255,.4)">
            Confidential · No obligation · SRA regulated
          </p>

        </form>
      </div>

    </div>
  </div>
</section>

<!-- ── FOOTER CTA ─────────────────────────────────────────────── -->
<section class="lf-footer-cta">
  <div class="lf-container" style="position:relative;z-index:1">
    <div class="lf-eyebrow" style="justify-content:center">Fletcher & Drummond LLP</div>
    <h2 class="lf-h2">London · Birmingham · Leeds</h2>
    <p>Trusted by businesses and individuals across England and Wales since 1987.<br>SRA Regulated · Legal 500 Ranked</p>
    <div style="display:flex;gap:16px;justify-content:center;flex-wrap:wrap">
      <a href="tel:02070001234" class="lf-btn lf-btn--gold">📞 0207 000 1234</a>
      <a href="#contact" class="lf-btn lf-btn--outline-white">Book Consultation</a>
    </div>
  </div>
</section>

</div><!-- /lf-wrap -->

<!-- ── JAVASCRIPT ─────────────────────────────────────────────── -->
<script>
(function(){

  /* animated counters */
  const easeOut = t => 1 - Math.pow(1-t,3);
  document.querySelectorAll('.lf-stat-num[data-target]').forEach(el=>{
    const target = parseFloat(el.dataset.target);
    const suffix = el.dataset.suffix||'';
    if(isNaN(target)) return;
    const obs = new IntersectionObserver(entries=>{
      entries.forEach(e=>{
        if(!e.isIntersecting) return;
        obs.unobserve(e.target);
        const dur=1800, start=performance.now();
        (function tick(now){
          const t = Math.min((now-start)/dur,1);
          el.textContent = Math.round(easeOut(t)*target).toLocaleString() + suffix;
          if(t<1) requestAnimationFrame(tick);
          else el.textContent = target.toLocaleString() + suffix;
        })(start);
      });
    },{threshold:.4});
    obs.observe(el);
  });

  /* FAQ accordion */
  document.querySelectorAll('.lf-faq-q').forEach(btn=>{
    btn.addEventListener('click',function(){
      const item = this.closest('.lf-faq-item');
      const ans  = item.querySelector('.lf-faq-a');
      const open = item.classList.contains('lf-open');
      document.querySelectorAll('.lf-faq-item.lf-open').forEach(o=>{
        o.classList.remove('lf-open');
        o.querySelector('.lf-faq-a').style.maxHeight='0';
        o.querySelector('.lf-faq-q').setAttribute('aria-expanded','false');
      });
      if(!open){
        item.classList.add('lf-open');
        ans.style.maxHeight = ans.scrollHeight+'px';
        this.setAttribute('aria-expanded','true');
      }
    });
  });

  /* scroll reveal */
  const ro = new IntersectionObserver(entries=>{
    entries.forEach((e,i)=>{
      if(!e.isIntersecting) return;
      setTimeout(()=>e.target.classList.add('lf-visible'),i*90);
      ro.unobserve(e.target);
    });
  },{threshold:.1});
  document.querySelectorAll('.lf-reveal').forEach(el=>ro.observe(el));

})();
</script>

<?php get_footer(); ?>
