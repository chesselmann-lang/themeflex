<?php
/**
 * Template Name: TF — Law Firm (Solicitor Practice)
 *
 * Premium solicitor / individual law practice template for ThemeFlex.
 * Distinct from page-law-firm.php (large commercial firm) — this targets
 * a single-solicitor or small boutique practice: criminal, family, immigration.
 *
 * Namespace : --la-*
 * Fonts     : Cinzel (display) + Lato (body)
 * Palette   : Forest #1A3A2A / Parchment #F5F0E4 / Copper #B87333 / Moss #4A6741 / Stone #7D8570
 */
defined('ABSPATH') || exit;
get_header();
?>

<style>
@import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@400;600;700&family=Lato:ital,wght@0,300;0,400;0,700;1,400&display=swap');

/* ── Tokens ── */
:root{
  --la-forest:#1A3A2A;
  --la-forest-deep:#0E2418;
  --la-parchment:#F5F0E4;
  --la-parchment-warm:#EDE5CE;
  --la-copper:#B87333;
  --la-copper-light:#D4956A;
  --la-moss:#4A6741;
  --la-stone:#7D8570;
  --la-stone-light:#B4B9AE;
  --la-white:#FFFFFF;
  --la-display:'Cinzel',Georgia,serif;
  --la-body:'Lato',system-ui,sans-serif;
  --la-radius:4px;
  --la-shadow:0 4px 24px rgba(26,58,42,.12);
  --la-shadow-lg:0 12px 40px rgba(26,58,42,.18);
}

/* ── Reset ── */
.la-page *,
.la-page *::before,
.la-page *::after{box-sizing:border-box;margin:0;padding:0}
.la-page{font-family:var(--la-body);color:var(--la-forest);background:var(--la-parchment);line-height:1.65;overflow-x:hidden}
.la-page a{color:inherit;text-decoration:none}

/* ── Layout ── */
.la-wrap{max-width:1100px;margin:0 auto;padding:0 24px}
.la-section{padding:88px 0}
.la-section--dark{background:var(--la-forest);color:var(--la-parchment)}
.la-section--warm{background:var(--la-parchment-warm)}
.la-section--forest{background:var(--la-forest-deep);color:var(--la-parchment)}

/* ── Typography ── */
.la-eyebrow{font-family:var(--la-body);font-size:.7rem;font-weight:700;letter-spacing:.22em;text-transform:uppercase;color:var(--la-copper);margin-bottom:12px;display:block}
.la-section--dark .la-eyebrow,.la-section--forest .la-eyebrow{color:var(--la-copper-light)}
.la-h1{font-family:var(--la-display);font-size:clamp(2.2rem,4.5vw,3.6rem);line-height:1.15;color:var(--la-white)}
.la-h2{font-family:var(--la-display);font-size:clamp(1.7rem,3.2vw,2.6rem);line-height:1.2;color:var(--la-forest)}
.la-section--dark .la-h2,.la-section--forest .la-h2{color:var(--la-parchment)}
.la-lead{font-size:1.05rem;color:var(--la-stone);max-width:660px;margin:0 auto;line-height:1.8}
.la-section--dark .la-lead,.la-section--forest .la-lead{color:rgba(245,240,228,.65)}
.la-center{text-align:center}
.la-hgroup{margin-bottom:52px}

/* ── Divider rule ── */
.la-rule{
  display:flex;align-items:center;gap:14px;
  margin:16px 0 28px;
}
.la-rule::before,.la-rule::after{
  content:'';flex:1;height:1px;
  background:linear-gradient(90deg,transparent,var(--la-copper),transparent);
  opacity:.4;
}
.la-rule-glyph{color:var(--la-copper);font-size:1rem;flex-shrink:0}

/* ── Buttons ── */
.la-btn{display:inline-flex;align-items:center;gap:8px;padding:14px 32px;border-radius:var(--la-radius);font-family:var(--la-display);font-size:.85rem;font-weight:600;letter-spacing:.06em;cursor:pointer;border:none;transition:all .25s;text-decoration:none}
.la-btn--primary{background:var(--la-copper);color:var(--la-white)}
.la-btn--primary:hover{background:#9E6228;transform:translateY(-2px);box-shadow:0 6px 20px rgba(184,115,51,.35)}
.la-btn--outline{background:transparent;color:var(--la-forest);border:2px solid var(--la-forest)}
.la-btn--outline:hover{background:var(--la-forest);color:var(--la-parchment)}
.la-btn--ghost{background:transparent;color:var(--la-parchment);border:1px solid rgba(245,240,228,.35)}
.la-btn--ghost:hover{border-color:var(--la-copper-light);color:var(--la-copper-light)}

/* ═══════════════════════════════════════════
   HERO
═══════════════════════════════════════════ */
.la-hero{
  position:relative;
  min-height:100vh;
  background:linear-gradient(160deg,var(--la-forest-deep) 0%,var(--la-forest) 55%,#22543D 100%);
  display:flex;align-items:center;overflow:hidden;
  padding:80px 0 60px;
}

/* Grain texture overlay */
.la-hero__texture{
  position:absolute;inset:0;
  background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.75' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.04'/%3E%3C/svg%3E");
  background-repeat:repeat;background-size:200px;
  pointer-events:none;opacity:.5;
}

/* Gold filigree accents */
.la-hero__filigree{
  position:absolute;
  top:0;right:0;bottom:0;width:40%;
  background:linear-gradient(270deg,rgba(184,115,51,.07) 0%,transparent 80%);
  pointer-events:none;
}
.la-hero__filigree::before{
  content:'';position:absolute;
  top:60px;right:60px;
  width:200px;height:200px;
  border:1px solid rgba(184,115,51,.15);
  border-radius:50%;
}
.la-hero__filigree::after{
  content:'';position:absolute;
  top:100px;right:100px;
  width:120px;height:120px;
  border:1px solid rgba(184,115,51,.1);
  border-radius:50%;
}

.la-hero__inner{
  position:relative;z-index:2;
  display:grid;grid-template-columns:1fr 440px;
  gap:60px;align-items:center;
  max-width:1100px;margin:0 auto;padding:0 24px;
}

/* ── Hero Copy ── */
.la-hero__sup{
  font-family:var(--la-display);font-size:.7rem;letter-spacing:.25em;text-transform:uppercase;
  color:var(--la-copper-light);margin-bottom:18px;display:block;
}
.la-hero__desc{
  font-size:1rem;color:rgba(245,240,228,.72);line-height:1.8;
  margin:22px 0 34px;max-width:500px;
}
.la-hero__ctas{display:flex;gap:14px;flex-wrap:wrap}
.la-hero__disclaimer{
  margin-top:18px;font-size:.75rem;font-style:italic;
  color:rgba(245,240,228,.4);
}

/* ── Hero Scene: Courtroom / Chambers ── */
.la-hero__scene{
  position:relative;
  width:440px;height:440px;flex-shrink:0;
}

/* Chamber room */
.la-chamber{
  position:absolute;
  bottom:0;left:0;right:0;height:200px;
  background:linear-gradient(180deg,#2D1B07 0%,#1A0F04 100%);
  border-radius:4px 4px 0 0;
}
/* Wood panelling */
.la-chamber::before{
  content:'';position:absolute;
  top:0;left:0;right:0;height:40px;
  background:linear-gradient(180deg,#3D2510,#2D1B07);
  border-bottom:2px solid rgba(184,115,51,.3);
}
/* Chamber floor */
.la-chamber::after{
  content:'';position:absolute;
  bottom:0;left:0;right:0;height:20px;
  background:linear-gradient(90deg,#1A0F04,#2D1B07,#1A0F04);
}

/* Bookcase */
.la-bookcase{
  position:absolute;
  bottom:20px;left:20px;
  width:90px;height:160px;
  background:#1A0F04;
  border:2px solid rgba(184,115,51,.2);
  border-radius:2px;
  overflow:hidden;
}
<?php
// PHP-generated book rows
$la_book_colors = [
  '#8B1A1A','#1A3A8B','#2A6E2A','#6E4A1A','#4A1A6E',
  '#8B4A1A','#1A5A5A','#6E1A4A','#3A6E1A','#1A1A6E',
  '#8B6E1A','#1A6E3A','#5A1A1A','#1A4A6E','#6E2A1A',
];
?>
.la-bookcase__shelves{position:absolute;inset:0;display:flex;flex-direction:column;justify-content:space-around;padding:8px 4px}
.la-shelf{display:flex;gap:2px;align-items:flex-end}
.la-book{border-radius:1px 2px 2px 1px}

/* Desk */
.la-desk-chamber{
  position:absolute;
  bottom:20px;left:120px;right:30px;
  height:14px;
  background:linear-gradient(180deg,#5A3A1A,#3D2510);
  border-radius:2px;
  box-shadow:0 4px 12px rgba(0,0,0,.4);
}
.la-desk-chamber::before{
  content:'';position:absolute;
  bottom:-60px;left:10px;right:10px;height:60px;
  background:linear-gradient(180deg,#3D2510,#2D1B07);
  clip-path:polygon(0 0,100% 0,85% 100%,15% 100%);
}

/* Desk lamp */
.la-lamp{
  position:absolute;
  bottom:34px;right:50px;
}
.la-lamp__base{width:24px;height:6px;background:#8B7355;border-radius:2px}
.la-lamp__stem{
  width:4px;height:40px;background:#8B7355;
  margin:0 auto;border-radius:2px;
  transform-origin:bottom center;transform:rotate(10deg);
}
.la-lamp__arm{
  width:30px;height:4px;background:#8B7355;
  transform:rotate(-30deg);
  position:relative;top:-4px;left:-6px;
}
.la-lamp__head{
  width:28px;height:14px;
  background:radial-gradient(ellipse,#C8A878 0%,#8B7355 100%);
  border-radius:4px 4px 8px 8px;
  position:relative;top:-2px;left:-12px;
  box-shadow:0 8px 20px rgba(200,168,120,.25);
}
.la-lamp__glow{
  position:absolute;
  width:60px;height:30px;
  background:radial-gradient(ellipse,rgba(255,215,100,.15) 0%,transparent 70%);
  top:8px;left:-18px;
  border-radius:50%;
}

/* Scales of Justice (CSS) */
.la-scales{
  position:absolute;
  bottom:34px;left:170px;
}
.la-scales__pole{
  width:4px;height:80px;
  background:linear-gradient(180deg,#C8A878,#8B7355);
  margin:0 auto;border-radius:2px;
}
.la-scales__top{
  width:4px;height:4px;border-radius:50%;
  background:var(--la-copper);margin:0 auto;position:relative;
}
.la-scales__beam{
  position:absolute;
  top:2px;left:50%;transform:translateX(-50%);
  width:60px;height:3px;
  background:linear-gradient(90deg,#8B7355,#C8A878,#8B7355);
  border-radius:2px;
  animation:la-beam-tip 4s ease-in-out infinite;
  transform-origin:50% 50%;
}
@keyframes la-beam-tip{
  0%,100%{transform:translateX(-50%) rotate(-4deg)}
  50%{transform:translateX(-50%) rotate(4deg)}
}
.la-scales__chain-l,.la-scales__chain-r{
  position:absolute;
  top:3px;
  width:1px;height:22px;
  background:rgba(184,115,51,.5);
  animation:la-beam-tip 4s ease-in-out infinite;
  transform-origin:top center;
}
.la-scales__chain-l{left:0}
.la-scales__chain-r{right:0}
.la-pan{
  width:24px;height:6px;
  background:linear-gradient(180deg,#C8A878,#8B7355);
  border-radius:3px;
  position:absolute;
  bottom:-22px;
}
.la-scales__chain-l .la-pan{left:-12px}
.la-scales__chain-r .la-pan{right:-12px}
.la-scales__base{
  width:40px;height:8px;
  background:linear-gradient(180deg,#8B7355,#5A3A1A);
  border-radius:4px;
  margin:-2px auto 0;
}

/* Gavel */
.la-gavel{
  position:absolute;
  bottom:48px;left:130px;
  transform:rotate(-25deg);
}
.la-gavel__head{
  width:40px;height:18px;
  background:linear-gradient(180deg,#5A3A1A,#3D2510);
  border-radius:3px;
}
.la-gavel__handle{
  width:8px;height:55px;
  background:linear-gradient(180deg,#8B5A2A,#5A3A1A);
  border-radius:4px;
  margin:0 auto;
  transform-origin:top center;
}

/* CSS Solicitor Figure */
.la-sfig{
  position:absolute;
  bottom:34px;right:28px;
  display:flex;flex-direction:column;align-items:center;
}
/* Wig */
.la-sfig__wig{
  width:44px;height:18px;
  background:#F5F0E4;
  border-radius:8px 8px 0 0;
  position:relative;
  margin-bottom:-4px;
  z-index:2;
}
.la-sfig__wig::before{/* wig curls left */
  content:'';position:absolute;
  bottom:-6px;left:-4px;
  width:12px;height:12px;border-radius:50%;
  background:#F5F0E4;box-shadow:0 -12px 0 #F5F0E4,12px -6px 0 #F5F0E4;
}
.la-sfig__wig::after{/* wig curls right */
  content:'';position:absolute;
  bottom:-6px;right:-4px;
  width:12px;height:12px;border-radius:50%;
  background:#F5F0E4;box-shadow:0 -12px 0 #F5F0E4,-12px -6px 0 #F5F0E4;
}
.la-sfig__head{
  width:36px;height:40px;
  background:#C8956B;
  border-radius:50% 50% 45% 45%;
  position:relative;z-index:1;
}
.la-sfig__head::after{/* eyes */
  content:'';position:absolute;
  top:18px;left:8px;right:8px;height:4px;
  background:rgba(26,58,42,.7);border-radius:2px;
  box-shadow:14px 0 0 rgba(26,58,42,.7);
}
.la-sfig__neck{width:10px;height:8px;background:#B87B5A;margin:0 auto}
/* Robe */
.la-sfig__robe{
  width:56px;height:72px;
  background:linear-gradient(180deg,#1A1A1A,#2A2A2A);
  border-radius:6px 6px 2px 2px;
  position:relative;
}
.la-sfig__robe::before{/* white neck bands */
  content:'';position:absolute;
  top:4px;left:50%;transform:translateX(-50%);
  width:18px;height:28px;
  background:linear-gradient(180deg,#F5F0E4 0%,#F5F0E4 40%,rgba(245,240,228,.6) 100%);
  border-radius:2px;
}
.la-sfig__robe::after{/* robe lapels */
  content:'';position:absolute;
  top:0;left:4px;right:4px;height:30px;
  background:linear-gradient(135deg,#1A1A1A 45%,transparent 45%,transparent 55%,#1A1A1A 55%);
}
.la-sfig__arm-l{
  position:absolute;top:8px;left:-10px;
  width:10px;height:48px;
  background:#2A2A2A;border-radius:5px;
  transform:rotate(-12deg);transform-origin:top center;
}
.la-sfig__arm-r{
  position:absolute;top:8px;right:-10px;
  width:10px;height:48px;
  background:#2A2A2A;border-radius:5px;
  transform:rotate(12deg);transform-origin:top center;
}
/* Document the figure holds */
.la-sfig__doc{
  position:absolute;bottom:-4px;right:-18px;
  width:28px;height:36px;
  background:#F5F0E4;border-radius:2px;
  transform:rotate(5deg);
}
.la-sfig__doc::before{
  content:'';position:absolute;
  top:6px;left:4px;right:4px;height:2px;
  background:#B4B9AE;box-shadow:0 6px 0 #B4B9AE,0 12px 0 #B4B9AE,0 18px 0 #CDC8BC;
}
.la-sfig__legs{display:flex;gap:8px;justify-content:center}
.la-sfig__leg{
  width:16px;height:50px;
  background:#1A1A1A;border-radius:2px 2px 4px 4px;
  position:relative;
}
.la-sfig__leg::after{
  content:'';position:absolute;bottom:-6px;left:-3px;
  width:22px;height:8px;
  background:#0A0A0A;border-radius:2px 4px 4px 2px;
}

/* Floating credential tags */
.la-cred-tag{
  position:absolute;
  background:rgba(26,58,42,.7);
  border:1px solid rgba(184,115,51,.3);
  backdrop-filter:blur(6px);
  border-radius:4px;padding:8px 12px;
  font-family:var(--la-display);font-size:.62rem;letter-spacing:.08em;
  color:var(--la-copper-light);
  animation:la-cred-float 5s ease-in-out infinite;
}
@keyframes la-cred-float{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}
.la-cred-tag:nth-child(1){top:30px;left:10px;animation-delay:.8s}
.la-cred-tag:nth-child(2){top:100px;right:4px;animation-delay:2s}
.la-cred-tag:nth-child(3){top:190px;left:16px;animation-delay:1.3s}

/* ── Hero Stats ── */
.la-hero__stats{
  position:relative;z-index:2;
  max-width:1100px;margin:40px auto 0;padding:0 24px;
  display:flex;gap:0;
  border-top:1px solid rgba(184,115,51,.2);
  padding-top:32px;
}
.la-hero__stat{flex:1;text-align:center;border-right:1px solid rgba(184,115,51,.15)}
.la-hero__stat:last-child{border-right:none}
.la-stat-val{font-family:var(--la-display);font-size:1.8rem;font-weight:700;color:var(--la-copper-light)}
.la-stat-lbl{font-size:.75rem;color:rgba(245,240,228,.5);margin-top:4px}

/* ═══════════════════════════════════════════
   TRUST BAND
═══════════════════════════════════════════ */
.la-trust{
  background:var(--la-copper);padding:18px 0;
}
.la-trust__inner{
  max-width:1100px;margin:0 auto;padding:0 24px;
  display:flex;align-items:center;gap:24px;flex-wrap:wrap;justify-content:center;
}
.la-trust__item{
  font-family:var(--la-display);font-size:.72rem;letter-spacing:.1em;
  color:rgba(255,255,255,.9);display:flex;align-items:center;gap:8px;
}
.la-trust__item::before{content:'✦';font-size:.6rem;opacity:.7}

/* ═══════════════════════════════════════════
   PRACTICE AREAS
═══════════════════════════════════════════ */
.la-areas__grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:52px;
}
.la-area-card{
  background:var(--la-white);
  border:1px solid rgba(26,58,42,.1);
  border-radius:6px;
  padding:32px 28px;
  transition:all .3s;
  position:relative;overflow:hidden;
}
.la-area-card::before{
  content:'';position:absolute;
  top:0;left:0;bottom:0;width:4px;
  background:linear-gradient(180deg,var(--la-copper),var(--la-moss));
  transform:scaleY(0);transform-origin:bottom;transition:transform .3s;
}
.la-area-card:hover{box-shadow:var(--la-shadow-lg);transform:translateY(-4px);border-color:rgba(184,115,51,.2)}
.la-area-card:hover::before{transform:scaleY(1)}
.la-area-icon{font-size:1.8rem;margin-bottom:16px}
.la-area-card h3{font-family:var(--la-display);font-size:1.05rem;margin-bottom:10px;color:var(--la-forest)}
.la-area-card p{font-size:.875rem;color:var(--la-stone);line-height:1.7}
.la-area-card ul{list-style:none;margin-top:14px}
.la-area-card ul li{
  font-size:.825rem;color:var(--la-stone);padding:4px 0;
  display:flex;align-items:center;gap:8px;
  border-bottom:1px solid rgba(26,58,42,.06);
}
.la-area-card ul li:last-child{border-bottom:none}
.la-area-card ul li::before{content:'›';color:var(--la-copper);font-weight:700;font-size:1rem;flex-shrink:0}

/* ═══════════════════════════════════════════
   ABOUT SOLICITOR
═══════════════════════════════════════════ */
.la-about{background:var(--la-parchment-warm)}
.la-about__inner{
  display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:center;
}
/* CSS barrister portrait */
.la-portrait-scene{
  position:relative;height:360px;
  background:linear-gradient(160deg,var(--la-forest) 0%,var(--la-forest-deep) 100%);
  border-radius:8px;
  overflow:hidden;
}
.la-portrait__bg-lines{
  position:absolute;inset:0;
  background-image:repeating-linear-gradient(90deg,rgba(184,115,51,.04) 0px,rgba(184,115,51,.04) 1px,transparent 1px,transparent 40px);
}
/* Large centred solicitor figure */
.la-portrait-fig{
  position:absolute;
  bottom:0;left:50%;transform:translateX(-50%);
  display:flex;flex-direction:column;align-items:center;
}
.la-portrait-fig .la-sfig__wig{width:60px;height:24px}
.la-portrait-fig .la-sfig__head{width:48px;height:52px}
.la-portrait-fig .la-sfig__robe{width:74px;height:90px}
.la-portrait-fig .la-sfig__leg{width:20px;height:60px}
/* Certificates on wall */
.la-cert{
  position:absolute;
  background:rgba(245,240,228,.06);border:1px solid rgba(184,115,51,.2);
  border-radius:2px;padding:6px 10px;
  font-family:var(--la-display);font-size:.5rem;letter-spacing:.08em;
  color:rgba(245,240,228,.5);text-align:center;
}
.la-cert:nth-child(1){top:24px;right:24px;width:70px}
.la-cert:nth-child(2){top:24px;left:24px;width:70px}
/* Gold nameplate */
.la-nameplate{
  position:absolute;bottom:20px;left:50%;transform:translateX(-50%);
  background:linear-gradient(180deg,var(--la-copper),#9E6228);
  padding:8px 24px;border-radius:2px;white-space:nowrap;
  font-family:var(--la-display);font-size:.65rem;letter-spacing:.15em;color:var(--la-parchment);
}

.la-about__content{}
.la-about__content h2{margin-bottom:8px}
.la-about__content .la-eyebrow{margin-bottom:6px}
.la-about__quals{
  display:flex;flex-wrap:wrap;gap:8px;margin:20px 0 28px;
}
.la-qual{
  background:var(--la-forest);color:var(--la-copper-light);
  font-family:var(--la-display);font-size:.65rem;letter-spacing:.1em;
  padding:5px 14px;border-radius:2px;
}
.la-about__stats{
  display:grid;grid-template-columns:1fr 1fr;gap:16px;margin:24px 0;
}
.la-about__stat{
  text-align:center;padding:16px;
  background:var(--la-white);border:1px solid rgba(26,58,42,.1);border-radius:4px;
}
.la-about__stat-val{font-family:var(--la-display);font-size:1.6rem;color:var(--la-copper)}
.la-about__stat-lbl{font-size:.75rem;color:var(--la-stone);margin-top:4px}
.la-about__bio{font-size:.925rem;color:var(--la-stone);line-height:1.8}

/* ═══════════════════════════════════════════
   PROCESS
═══════════════════════════════════════════ */
.la-process{background:var(--la-forest)}
.la-process__steps{
  display:grid;grid-template-columns:repeat(4,1fr);gap:24px;margin-top:52px;
  position:relative;
}
.la-process__steps::before{
  content:'';position:absolute;
  top:28px;left:12.5%;right:12.5%;height:1px;
  background:linear-gradient(90deg,transparent,rgba(184,115,51,.4),rgba(184,115,51,.4),transparent);
}
.la-proc-step{text-align:center;position:relative}
.la-proc-step__num{
  width:56px;height:56px;border-radius:50%;
  background:rgba(184,115,51,.15);border:2px solid rgba(184,115,51,.4);
  display:flex;align-items:center;justify-content:center;
  font-family:var(--la-display);font-size:1rem;font-weight:700;color:var(--la-copper-light);
  margin:0 auto 20px;position:relative;z-index:1;
  transition:all .3s;
}
.la-proc-step:hover .la-proc-step__num{
  background:var(--la-copper);color:var(--la-white);border-color:var(--la-copper);
}
.la-proc-step h3{font-family:var(--la-display);font-size:.95rem;margin-bottom:8px;color:var(--la-parchment)}
.la-proc-step p{font-size:.825rem;color:rgba(245,240,228,.55);line-height:1.65}

/* ═══════════════════════════════════════════
   PACKAGES / FEES
═══════════════════════════════════════════ */
.la-fees{background:var(--la-parchment-warm)}
.la-fees__grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:52px;align-items:start;
}
.la-fee-card{
  background:var(--la-white);
  border:1px solid rgba(26,58,42,.1);
  border-radius:6px;padding:32px 24px;
  transition:all .3s;position:relative;
}
.la-fee-card:hover{box-shadow:var(--la-shadow)}
.la-fee-card--featured{
  border-color:var(--la-copper);
  transform:scale(1.03);
  box-shadow:var(--la-shadow-lg);
}
.la-fee-card__badge{
  position:absolute;top:-12px;left:50%;transform:translateX(-50%);
  background:var(--la-copper);color:var(--la-white);
  font-family:var(--la-display);font-size:.65rem;letter-spacing:.12em;
  padding:4px 16px;border-radius:2px;white-space:nowrap;
}
.la-fee-card__name{font-family:var(--la-display);font-size:1rem;margin-bottom:6px;color:var(--la-forest)}
.la-fee-card__price{
  font-family:var(--la-display);font-size:1.8rem;font-weight:700;
  color:var(--la-copper);margin:14px 0 4px;
}
.la-fee-card__price span{font-size:.875rem;color:var(--la-stone);font-family:var(--la-body);font-weight:400}
.la-fee-card__desc{font-size:.825rem;color:var(--la-stone);margin-bottom:18px;line-height:1.65}
.la-fee-card__divider{height:1px;background:rgba(26,58,42,.08);margin:16px 0}
.la-fee-card__items{list-style:none}
.la-fee-card__items li{
  font-size:.825rem;color:var(--la-stone);padding:6px 0;
  display:flex;align-items:flex-start;gap:8px;
}
.la-fee-card__items li::before{content:'✓';color:var(--la-moss);font-weight:700;flex-shrink:0}
.la-fee-card .la-btn{margin-top:22px;width:100%;justify-content:center}
.la-fees__note{
  text-align:center;margin-top:28px;
  font-size:.8rem;font-style:italic;color:var(--la-stone);
}

/* ═══════════════════════════════════════════
   TESTIMONIALS
═══════════════════════════════════════════ */
.la-testis{background:var(--la-forest-deep)}
.la-testi-grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-top:52px;
}
.la-testi{
  background:rgba(245,240,228,.04);border:1px solid rgba(184,115,51,.12);
  border-radius:6px;padding:28px;
}
.la-testi::before{
  content:'\201C';
  font-family:var(--la-display);font-size:3.5rem;color:var(--la-copper);
  opacity:.35;line-height:1;display:block;margin-bottom:8px;
}
.la-testi__text{font-size:.9rem;color:rgba(245,240,228,.7);line-height:1.75;margin-bottom:20px}
.la-testi__stars{color:var(--la-copper-light);margin-bottom:10px}
.la-testi__name{font-weight:700;color:var(--la-parchment);font-size:.875rem}
.la-testi__matter{font-size:.75rem;color:rgba(245,240,228,.45);margin-top:3px;font-style:italic}

/* ═══════════════════════════════════════════
   FAQ
═══════════════════════════════════════════ */
.la-faq{background:var(--la-parchment)}
.la-faq__list{max-width:720px;margin:44px auto 0}
.la-faq-item{border-bottom:1px solid rgba(26,58,42,.1)}
.la-faq-q{
  width:100%;background:none;border:none;
  display:flex;justify-content:space-between;align-items:center;
  padding:20px 0;cursor:pointer;text-align:left;
  font-family:var(--la-display);font-size:.925rem;font-weight:600;color:var(--la-forest);
  gap:16px;transition:color .2s;
}
.la-faq-q:hover{color:var(--la-copper)}
.la-faq-icon{
  width:26px;height:26px;border-radius:2px;
  background:var(--la-forest);color:var(--la-copper-light);
  display:flex;align-items:center;justify-content:center;
  font-size:1rem;flex-shrink:0;transition:transform .3s,background .2s;
}
.la-faq-item.la-open .la-faq-icon{transform:rotate(45deg);background:var(--la-copper);color:var(--la-white)}
.la-faq-a{max-height:0;overflow:hidden;transition:max-height .4s ease}
.la-faq-a p{padding:0 0 20px;font-size:.875rem;color:var(--la-stone);line-height:1.75}

/* ═══════════════════════════════════════════
   CONTACT
═══════════════════════════════════════════ */
.la-contact{background:var(--la-forest)}
.la-contact__inner{
  display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:start;
}
.la-contact__info .la-eyebrow{color:var(--la-copper-light)}
.la-contact__info h2{color:var(--la-parchment);margin-bottom:16px}
.la-contact__info p{color:rgba(245,240,228,.6);font-size:.95rem;line-height:1.8;margin-bottom:28px}
.la-contact__detail{display:flex;align-items:flex-start;gap:12px;margin-bottom:18px}
.la-contact__detail-icon{
  width:36px;height:36px;border-radius:4px;flex-shrink:0;
  background:rgba(184,115,51,.15);border:1px solid rgba(184,115,51,.25);
  display:flex;align-items:center;justify-content:center;font-size:.95rem;
}
.la-contact__detail-text strong{display:block;color:var(--la-parchment);font-size:.875rem;margin-bottom:2px}
.la-contact__detail-text span{color:rgba(245,240,228,.5);font-size:.82rem}
.la-contact__urgent{
  background:rgba(184,115,51,.12);border:1px solid rgba(184,115,51,.25);
  border-radius:4px;padding:14px 18px;margin-top:24px;
  font-size:.825rem;color:var(--la-copper-light);line-height:1.6;
}
.la-contact__urgent strong{display:block;margin-bottom:4px;font-family:var(--la-display);letter-spacing:.06em}

.la-cform{
  background:rgba(245,240,228,.04);border:1px solid rgba(184,115,51,.15);
  border-radius:6px;padding:36px;
}
.la-cf-row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.la-cf{margin-bottom:18px}
.la-cf label{display:block;font-family:var(--la-display);font-size:.65rem;letter-spacing:.12em;color:rgba(245,240,228,.5);margin-bottom:7px}
.la-cf input,
.la-cf select,
.la-cf textarea{
  width:100%;background:rgba(245,240,228,.05);border:1px solid rgba(184,115,51,.2);
  border-radius:var(--la-radius);padding:11px 14px;
  font-family:var(--la-body);font-size:.875rem;color:var(--la-parchment);outline:none;
  transition:border-color .2s;
}
.la-cf input::placeholder,.la-cf textarea::placeholder{color:rgba(245,240,228,.25)}
.la-cf input:focus,.la-cf select:focus,.la-cf textarea:focus{border-color:var(--la-copper)}
.la-cf select option{background:var(--la-forest)}
.la-cf textarea{resize:vertical;min-height:110px}
.la-cform .la-btn{width:100%;justify-content:center;margin-top:6px}
.la-cform__disclaimer{
  text-align:center;font-size:.72rem;font-style:italic;
  color:rgba(245,240,228,.3);margin-top:12px;line-height:1.6;
}

/* ═══════════════════════════════════════════
   FOOTER CTA
═══════════════════════════════════════════ */
.la-footer-cta{
  background:linear-gradient(135deg,var(--la-copper) 0%,#9E6228 100%);
  padding:64px 0;text-align:center;
}
.la-footer-cta h2{font-family:var(--la-display);font-size:clamp(1.6rem,3vw,2.4rem);color:var(--la-white);margin-bottom:14px}
.la-footer-cta p{color:rgba(255,255,255,.75);margin-bottom:32px;font-size:1rem}
.la-footer-cta .la-btn{background:var(--la-white);color:var(--la-copper);font-size:1rem;padding:14px 40px}
.la-footer-cta .la-btn:hover{background:var(--la-parchment);transform:translateY(-2px)}

/* ── Scroll reveal ── */
.la-reveal{opacity:0;transform:translateY(24px);transition:opacity .6s ease,transform .6s ease}
.la-reveal.la-visible{opacity:1;transform:none}

/* ── Responsive ── */
@media(max-width:960px){
  .la-hero__inner{grid-template-columns:1fr;text-align:center}
  .la-hero__scene{display:none}
  .la-hero__ctas{justify-content:center}
  .la-hero__desc{margin:0 auto 28px}
  .la-hero__stats{flex-wrap:wrap}
  .la-hero__stat{flex:0 0 50%}
  .la-areas__grid{grid-template-columns:1fr 1fr}
  .la-about__inner{grid-template-columns:1fr}
  .la-process__steps{grid-template-columns:1fr 1fr}
  .la-process__steps::before{display:none}
  .la-fees__grid{grid-template-columns:1fr}
  .la-fee-card--featured{transform:none}
  .la-testi-grid{grid-template-columns:1fr}
  .la-contact__inner{grid-template-columns:1fr}
}
@media(max-width:600px){
  .la-section{padding:60px 0}
  .la-areas__grid{grid-template-columns:1fr}
  .la-cf-row{grid-template-columns:1fr}
}
</style>

<div class="la-page">

<!-- ════════════════════════════════════════
     HERO
════════════════════════════════════════ -->
<section class="la-hero">
  <div class="la-hero__texture" aria-hidden="true"></div>
  <div class="la-hero__filigree" aria-hidden="true"></div>

  <div class="la-hero__inner">
    <!-- Copy -->
    <div class="la-hero__copy">
      <span class="la-hero__sup">Solicitors &amp; Barristers · Established 2001</span>
      <h1 class="la-h1">Expert Legal Counsel.<br>Steadfast Representation.</h1>
      <div class="la-rule"><span class="la-rule-glyph">⚖</span></div>
      <p class="la-hero__desc">Hadley &amp; Associates brings over two decades of specialist experience in criminal defence, family law, and immigration — fighting for every client with the dedication their case demands.</p>
      <div class="la-hero__ctas">
        <a href="#contact" class="la-btn la-btn--primary">Request a Consultation</a>
        <a href="#areas" class="la-btn la-btn--ghost">Our Practice Areas</a>
      </div>
      <p class="la-hero__disclaimer">All consultations are strictly confidential. Regulated by the Solicitors Regulation Authority.</p>
    </div>

    <!-- Scene: Chambers -->
    <div class="la-hero__scene" aria-hidden="true">
      <!-- Credentials floating -->
      <div class="la-cred-tag">SRA Authorised</div>
      <div class="la-cred-tag">Law Society Member</div>
      <div class="la-cred-tag">Legal Aid Franchise</div>

      <!-- Chamber background -->
      <div class="la-chamber"></div>

      <!-- Bookcase -->
      <div class="la-bookcase">
        <div class="la-bookcase__shelves">
          <?php
          srand(crc32('la-books'));
          $la_bc = ['#8B1A1A','#1A3A8B','#2A6E2A','#6E4A1A','#4A1A6E','#8B4A1A','#1A5A5A','#6E1A4A','#3A6E1A','#1A1A6E','#8B6E1A','#1A6E3A','#5A1A1A','#1A4A6E','#6E2A1A'];
          for($row=0;$row<4;$row++){
            echo '<div class="la-shelf">';
            $books_in_row = rand(5,9);
            for($b=0;$b<$books_in_row;$b++){
              $col = $la_bc[array_rand($la_bc)];
              $h = rand(22,32);$w = rand(8,12);
              echo "<div class='la-book' style='width:{$w}px;height:{$h}px;background:{$col}'></div>";
            }
            echo '</div>';
          }
          ?>
        </div>
      </div>

      <!-- Desk -->
      <div class="la-desk-chamber"></div>

      <!-- Lamp -->
      <div class="la-lamp">
        <div class="la-lamp__base"></div>
        <div class="la-lamp__stem"></div>
        <div class="la-lamp__arm"></div>
        <div class="la-lamp__head">
          <div class="la-lamp__glow"></div>
        </div>
      </div>

      <!-- Scales -->
      <div class="la-scales" style="position:absolute;bottom:34px;left:200px">
        <div style="position:relative;width:70px">
          <div class="la-scales__top" style="margin:0 auto">
            <div class="la-scales__beam">
              <div class="la-scales__chain-l"><div class="la-pan"></div></div>
              <div class="la-scales__chain-r"><div class="la-pan"></div></div>
            </div>
          </div>
          <div class="la-scales__pole"></div>
          <div class="la-scales__base"></div>
        </div>
      </div>

      <!-- Gavel -->
      <div class="la-gavel">
        <div class="la-gavel__head"></div>
        <div class="la-gavel__handle"></div>
      </div>

      <!-- Solicitor figure -->
      <div class="la-sfig">
        <div class="la-sfig__wig"></div>
        <div class="la-sfig__head"></div>
        <div class="la-sfig__neck"></div>
        <div class="la-sfig__robe" style="position:relative">
          <div class="la-sfig__arm-l"></div>
          <div class="la-sfig__arm-r">
            <div class="la-sfig__doc"></div>
          </div>
        </div>
        <div class="la-sfig__legs">
          <div class="la-sfig__leg"></div>
          <div class="la-sfig__leg"></div>
        </div>
      </div>
    </div>
  </div>

  <!-- Stats -->
  <div class="la-hero__stats">
    <div class="la-hero__stat">
      <div class="la-stat-val la-counter" data-target="23" data-suffix=" yrs">0</div>
      <div class="la-stat-lbl">In Practice</div>
    </div>
    <div class="la-hero__stat">
      <div class="la-stat-val la-counter" data-target="4200" data-suffix="+">0</div>
      <div class="la-stat-lbl">Cases Handled</div>
    </div>
    <div class="la-hero__stat">
      <div class="la-stat-val la-counter" data-target="96" data-suffix="%">0</div>
      <div class="la-stat-lbl">Client Satisfaction</div>
    </div>
    <div class="la-hero__stat">
      <div class="la-stat-val la-counter" data-target="8" data-suffix=" solicitors">0</div>
      <div class="la-stat-lbl">Specialist Team</div>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     TRUST BAND
════════════════════════════════════════ -->
<div class="la-trust">
  <div class="la-trust__inner">
    <span class="la-trust__item">SRA Regulated</span>
    <span class="la-trust__item">Law Society Accredited</span>
    <span class="la-trust__item">Legal Aid Approved</span>
    <span class="la-trust__item">Lexcel Quality Mark</span>
    <span class="la-trust__item">Resolution Member</span>
  </div>
</div>

<!-- ════════════════════════════════════════
     PRACTICE AREAS
════════════════════════════════════════ -->
<section class="la-section" id="areas">
  <div class="la-wrap">
    <div class="la-hgroup la-center">
      <span class="la-eyebrow">Practice Areas</span>
      <h2 class="la-h2">Specialist Legal Services</h2>
      <p class="la-lead">We focus on the areas of law where the stakes are highest and specialist expertise makes the greatest difference to the outcome.</p>
    </div>
    <div class="la-areas__grid">
      <?php
      $la_areas = [
        ['icon'=>'⚖️','title'=>'Criminal Defence','desc'=>'Fearless representation at every stage of criminal proceedings — from police station attendance through to Crown Court trials and appeals.','items'=>['Police station attendance (24/7)','Magistrates &amp; Crown Court','Drug offences','Fraud &amp; financial crime','Motoring offences']],
        ['icon'=>'👨‍👩‍👧','title'=>'Family Law','desc'=>'Sensitive, resolute advice through life\'s most difficult transitions — always placing the welfare of your children at the centre of every decision.','items'=>['Divorce &amp; separation','Child arrangements','Financial settlements','Domestic abuse orders','Cohabitation disputes']],
        ['icon'=>'✈️','title'=>'Immigration &amp; Asylum','desc'=>'Expert guidance through an increasingly complex immigration system — from visa applications to asylum claims and deportation appeals.','items'=>['Visa applications &amp; renewals','Asylum &amp; refugee claims','Deportation appeals','Indefinite leave to remain','Nationality &amp; citizenship']],
        ['icon'=>'📋','title'=>'Employment Law','desc'=>'Protecting employees\' rights and guiding employers through the complexities of workplace law with clear, practical advice.','items'=>['Unfair dismissal','Discrimination claims','Settlement agreements','Redundancy &amp; TUPE','Employment tribunal advocacy']],
        ['icon'=>'🏠','title'=>'Housing &amp; Property','desc'=>'Practical help for tenants and homeowners facing housing insecurity, disputes, or complex property transactions.','items'=>['Eviction defence','Disrepair claims','Boundary disputes','Lease renewals','Possession proceedings']],
        ['icon'=>'📝','title'=>'Wills &amp; Probate','desc'=>'Ensuring your estate and your wishes are protected — and supporting families through the process of administering an estate with care.','items'=>['Will drafting &amp; review','Lasting Power of Attorney','Probate administration','Contested wills','Trusts &amp; estate planning']],
      ];
      foreach($la_areas as $a): ?>
      <div class="la-area-card la-reveal">
        <div class="la-area-icon"><?php echo $a['icon']; ?></div>
        <h3><?php echo $a['title']; ?></h3>
        <p><?php echo $a['desc']; ?></p>
        <ul>
          <?php foreach($a['items'] as $item): ?>
          <li><?php echo $item; ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     ABOUT
════════════════════════════════════════ -->
<section class="la-section la-about" id="about">
  <div class="la-wrap">
    <div class="la-about__inner">
      <div class="la-portrait-scene la-reveal" aria-hidden="true">
        <div class="la-portrait__bg-lines"></div>
        <div class="la-cert">Barrister<br>Middle Temple<br>2001</div>
        <div class="la-cert">Resolution<br>Accredited<br>Specialist</div>
        <div class="la-portrait-fig">
          <div class="la-sfig__wig" style="width:60px;height:24px;border-radius:10px 10px 0 0"></div>
          <div class="la-sfig__head" style="width:48px;height:52px;background:#C8956B;border-radius:50% 50% 45% 45%;position:relative">
            <div style="position:absolute;top:22px;left:10px;right:10px;height:4px;background:rgba(26,58,42,.7);border-radius:2px;box-shadow:18px 0 0 rgba(26,58,42,.7)"></div>
          </div>
          <div style="width:12px;height:10px;background:#B87B5A;margin:0 auto"></div>
          <div style="position:relative;width:74px;height:90px;background:linear-gradient(180deg,#1A1A1A,#2A2A2A);border-radius:6px 6px 2px 2px">
            <div style="position:absolute;top:4px;left:50%;transform:translateX(-50%);width:20px;height:32px;background:linear-gradient(180deg,#F5F0E4 0%,#F5F0E4 45%,rgba(245,240,228,.6) 100%);border-radius:2px"></div>
          </div>
          <div style="display:flex;gap:8px">
            <div style="width:20px;height:60px;background:#1A1A1A;border-radius:2px 2px 4px 4px;position:relative">
              <div style="position:absolute;bottom:-6px;left:-3px;width:26px;height:8px;background:#0A0A0A;border-radius:2px 4px 4px 2px"></div>
            </div>
            <div style="width:20px;height:60px;background:#1A1A1A;border-radius:2px 2px 4px 4px;position:relative">
              <div style="position:absolute;bottom:-6px;left:-3px;width:26px;height:8px;background:#0A0A0A;border-radius:2px 4px 4px 2px"></div>
            </div>
          </div>
        </div>
        <div class="la-nameplate">DIANA HADLEY LLB (Hons)</div>
      </div>

      <div class="la-about__content la-reveal">
        <span class="la-eyebrow">Lead Solicitor</span>
        <h2 class="la-h2">Diana Hadley LLB (Hons)</h2>
        <div class="la-rule"><span class="la-rule-glyph">⚖</span></div>
        <div class="la-about__quals">
          <span class="la-qual">LLB Hons (Bristol)</span>
          <span class="la-qual">Resolution Accredited</span>
          <span class="la-qual">IAAS Accredited</span>
          <span class="la-qual">Duty Solicitor</span>
        </div>
        <p class="la-about__bio">Diana Hadley has practised as a solicitor for over 23 years, building a reputation for meticulous preparation, fearless advocacy, and the ability to find solutions in the most complex of cases. She founded Hadley &amp; Associates in 2001 with a single conviction: that every client deserves the same level of commitment and strategic thinking, regardless of the size of their matter or their financial means.</p>
        <p class="la-about__bio" style="margin-top:14px">Diana is a Duty Solicitor and holds the Immigration &amp; Asylum Accreditation. She is listed in the Legal 500 as a recommended practitioner in family law and criminal defence for the North West.</p>
        <div class="la-about__stats">
          <div class="la-about__stat">
            <div class="la-about__stat-val la-counter" data-target="23" data-suffix=" yrs">0</div>
            <div class="la-about__stat-lbl">In Practice</div>
          </div>
          <div class="la-about__stat">
            <div class="la-about__stat-val">Legal<br>500</div>
            <div class="la-about__stat-lbl">Listed Practitioner</div>
          </div>
        </div>
        <a href="#contact" class="la-btn la-btn--primary" style="margin-top:8px">Book a Consultation</a>
      </div>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     PROCESS
════════════════════════════════════════ -->
<section class="la-section la-process la-section--dark">
  <div class="la-wrap">
    <div class="la-hgroup la-center">
      <span class="la-eyebrow">How We Work</span>
      <h2 class="la-h2">Your Case, Our Priority</h2>
      <p class="la-lead">We take a structured, transparent approach to every matter — so you always know what's happening, what comes next, and what it will cost.</p>
    </div>
    <div class="la-process__steps">
      <?php
      $la_steps = [
        ['num'=>'I','title'=>'Initial Consultation','desc'=>'We listen first. A confidential consultation to understand your situation, assess your options, and advise on the best path forward.'],
        ['num'=>'II','title'=>'Case Strategy','desc'=>'We build a clear, realistic strategy — identifying the strongest arguments, the evidence required, and the likely timeline.'],
        ['num'=>'III','title'=>'Active Representation','desc'=>'We handle everything: correspondence, court filings, negotiations, and hearings. You are kept informed at every step.'],
        ['num'=>'IV','title'=>'Resolution &amp; Beyond','desc'=>'We don\'t disappear after the result. We ensure outcomes are implemented, and we\'re here if circumstances change.'],
      ];
      foreach($la_steps as $s): ?>
      <div class="la-proc-step la-reveal">
        <div class="la-proc-step__num"><?php echo $s['num']; ?></div>
        <h3><?php echo $s['title']; ?></h3>
        <p><?php echo $s['desc']; ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     FEES
════════════════════════════════════════ -->
<section class="la-section la-fees" id="fees">
  <div class="la-wrap">
    <div class="la-hgroup la-center">
      <span class="la-eyebrow">Transparent Fees</span>
      <h2 class="la-h2">Clear Costs, No Surprises</h2>
      <p class="la-lead">We believe in transparent pricing. You will always know what our services cost before we begin — and we offer payment plans to ensure quality legal advice is accessible.</p>
    </div>
    <div class="la-fees__grid">
      <div class="la-fee-card la-reveal">
        <div class="la-fee-card__name">Initial Consultation</div>
        <p class="la-fee-card__desc">A focused one-hour meeting to understand your situation and assess your options — with no commitment to proceed.</p>
        <div class="la-fee-card__price">£150 <span>+ VAT / 1 hour</span></div>
        <hr class="la-fee-card__divider">
        <ul class="la-fee-card__items">
          <li>In-person or video call</li>
          <li>Confidential assessment</li>
          <li>Clear explanation of your options</li>
          <li>Indicative costs provided</li>
          <li>No obligation to instruct</li>
        </ul>
        <a href="#contact" class="la-btn la-btn--outline">Book Consultation</a>
      </div>

      <div class="la-fee-card la-fee-card--featured la-reveal">
        <div class="la-fee-card__badge">Most Common</div>
        <div class="la-fee-card__name">Fixed-Fee Matter</div>
        <p class="la-fee-card__desc">For straightforward matters where scope is clear, we offer fixed-fee arrangements so you know exactly what you will pay.</p>
        <div class="la-fee-card__price">From £850 <span>+ VAT</span></div>
        <hr class="la-fee-card__divider">
        <ul class="la-fee-card__items">
          <li>Fixed price agreed upfront</li>
          <li>All correspondence included</li>
          <li>Court filing fees included</li>
          <li>Regular progress updates</li>
          <li>Instalment payment plans available</li>
          <li>Legal Aid assessed if eligible</li>
        </ul>
        <a href="#contact" class="la-btn la-btn--primary">Get a Fixed-Fee Quote</a>
      </div>

      <div class="la-fee-card la-reveal">
        <div class="la-fee-card__name">Hourly Rate</div>
        <p class="la-fee-card__desc">For complex or unpredictable matters, we charge by the hour with full time recording and monthly billing so you maintain oversight.</p>
        <div class="la-fee-card__price">£185–£285 <span>+ VAT / hr</span></div>
        <hr class="la-fee-card__divider">
        <ul class="la-fee-card__items">
          <li>Detailed time records provided</li>
          <li>Monthly billing cycle</li>
          <li>Costs estimate reviewed regularly</li>
          <li>Senior solicitor: £285/hr</li>
          <li>Associate: £185/hr</li>
          <li>Legal Aid accepted where applicable</li>
        </ul>
        <a href="#contact" class="la-btn la-btn--outline">Discuss Your Matter</a>
      </div>
    </div>
    <p class="la-fees__note">Legal Aid: We hold a Legal Aid franchise in criminal defence and immigration. Please contact us to establish your eligibility before your consultation.</p>
  </div>
</section>

<!-- ════════════════════════════════════════
     TESTIMONIALS
════════════════════════════════════════ -->
<section class="la-section la-testis la-section--forest">
  <div class="la-wrap">
    <div class="la-hgroup la-center">
      <span class="la-eyebrow">Client Testimonials</span>
      <h2 class="la-h2">What Our Clients Say</h2>
    </div>
    <div class="la-testi-grid">
      <?php
      $la_testis = [
        ['text'=>'Diana took my case when nobody else would. She fought every step of the way, prepared meticulously, and secured a result that I genuinely didn\'t believe was possible. I owe her everything.','name'=>'D.W.','matter'=>'Criminal Defence — Crown Court acquittal'],
        ['text'=>'The family law team handled our divorce with a combination of legal precision and genuine compassion. They helped us reach a fair settlement without dragging the children through years of conflict.','name'=>'A.M.','matter'=>'Family Law — Contested divorce'],
        ['text'=>'After two previous solicitors failed to progress my immigration case, Hadley &amp; Associates resolved it in four months. Their knowledge of the immigration rules is in a different class.','name'=>'P.O.','matter'=>'Immigration — Indefinite Leave to Remain'],
      ];
      foreach($la_testis as $t): ?>
      <div class="la-testi la-reveal">
        <div class="la-testi__stars">★★★★★</div>
        <p class="la-testi__text"><?php echo $t['text']; ?></p>
        <div class="la-testi__name"><?php echo $t['name']; ?></div>
        <div class="la-testi__matter"><?php echo $t['matter']; ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     FAQ
════════════════════════════════════════ -->
<section class="la-section la-faq">
  <div class="la-wrap">
    <div class="la-hgroup la-center">
      <span class="la-eyebrow">Frequently Asked</span>
      <h2 class="la-h2">Common Questions</h2>
    </div>
    <div class="la-faq__list">
      <?php
      $la_faqs = [
        ['q'=>'Do you offer emergency appointments?','a'=>'Yes. For criminal matters — particularly police station attendances — we have a 24-hour duty line. In urgent family law matters (such as emergency injunctions), we can typically arrange an appointment within 24 hours. Please call the emergency line on the number above.'],
        ['q'=>'How do I know if I qualify for Legal Aid?','a'=>'Legal Aid eligibility depends on the type of case and your financial circumstances. We hold franchises in criminal defence and immigration law. In criminal matters, Legal Aid is often available regardless of means if you face a custodial sentence. Call us for a free eligibility assessment — it takes about 10 minutes.'],
        ['q'=>'What should I bring to my first consultation?','a'=>'Any documents relating to your case — letters, court orders, correspondence from the police, immigration notices, or your original documents (passport, visa). The more context we have, the more useful we can be. If you don\'t have anything yet, come anyway — we can begin with your account of events.'],
        ['q'=>'Can I change solicitors if I\'m unhappy with my current one?','a'=>'Yes, you have the right to change solicitors at any time. We can assist with the transfer of your file. In Legal Aid matters, a change of solicitor may require justification, but this is often straightforward to establish where there has been a breakdown in communication or lack of progress.'],
        ['q'=>'How long will my case take?','a'=>'This depends entirely on the type and complexity of your matter. A straightforward divorce may conclude in 4–6 months; a contested Crown Court trial may take 12–18 months from charge to verdict. We will give you a realistic timeline at your initial consultation, and update you whenever circumstances change.'],
        ['q'=>'What is your complaints procedure?','a'=>'We take complaints very seriously. In the first instance, please raise concerns with your supervising solicitor. If unresolved, you can escalate to our internal Complaints Partner. If still dissatisfied, you may refer the matter to the Legal Ombudsman. Full details are in our client care letter and available on request.'],
      ];
      foreach($la_faqs as $faq): ?>
      <div class="la-faq-item">
        <button class="la-faq-q" aria-expanded="false">
          <?php echo $faq['q']; ?>
          <span class="la-faq-icon" aria-hidden="true">+</span>
        </button>
        <div class="la-faq-a">
          <p><?php echo $faq['a']; ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     CONTACT
════════════════════════════════════════ -->
<section class="la-section la-contact la-section--dark" id="contact">
  <div class="la-wrap">
    <div class="la-contact__inner">
      <div class="la-contact__info">
        <span class="la-eyebrow">Contact Us</span>
        <h2 class="la-h2">Get in Touch</h2>
        <p>We respond to all enquiries within one working day. For urgent criminal matters, call our 24-hour duty line — listed below.</p>
        <div class="la-contact__detail">
          <div class="la-contact__detail-icon">📍</div>
          <div class="la-contact__detail-text">
            <strong>Office</strong>
            <span>12 Temple Chambers, Manchester M2 4WN</span>
          </div>
        </div>
        <div class="la-contact__detail">
          <div class="la-contact__detail-icon">📞</div>
          <div class="la-contact__detail-text">
            <strong>Main Line</strong>
            <span>0161 832 4100</span>
          </div>
        </div>
        <div class="la-contact__detail">
          <div class="la-contact__detail-icon">✉️</div>
          <div class="la-contact__detail-text">
            <strong>Email</strong>
            <span>enquiries@hadleysolicitors.co.uk</span>
          </div>
        </div>
        <div class="la-contact__detail">
          <div class="la-contact__detail-icon">🕐</div>
          <div class="la-contact__detail-text">
            <strong>Office Hours</strong>
            <span>Mon–Fri 9:00am – 5:30pm</span>
          </div>
        </div>
        <div class="la-contact__urgent">
          <strong>⚡ 24-Hour Criminal Defence Line</strong>
          0800 123 4567 — For police station attendances and urgent criminal matters, day or night.
        </div>
      </div>

      <div class="la-cform">
        <form method="post" action="">
          <?php wp_nonce_field('tf_la_booking','tf_la_nonce'); ?>
          <div class="la-cf-row">
            <div class="la-cf">
              <label for="la-fname">First Name *</label>
              <input type="text" id="la-fname" name="la_fname" placeholder="Diana" required>
            </div>
            <div class="la-cf">
              <label for="la-lname">Last Name *</label>
              <input type="text" id="la-lname" name="la_lname" placeholder="Hadley" required>
            </div>
          </div>
          <div class="la-cf">
            <label for="la-email">Email Address *</label>
            <input type="email" id="la-email" name="la_email" placeholder="you@example.com" required>
          </div>
          <div class="la-cf">
            <label for="la-phone">Phone Number</label>
            <input type="tel" id="la-phone" name="la_phone" placeholder="07xxx xxxxxx">
          </div>
          <div class="la-cf">
            <label for="la-matter">Area of Law *</label>
            <select id="la-matter" name="la_matter" required>
              <option value="">Select area…</option>
              <option>Criminal Defence</option>
              <option>Family Law</option>
              <option>Immigration &amp; Asylum</option>
              <option>Employment Law</option>
              <option>Housing &amp; Property</option>
              <option>Wills &amp; Probate</option>
              <option>Other</option>
            </select>
          </div>
          <div class="la-cf">
            <label for="la-urgent">Is your matter urgent?</label>
            <select id="la-urgent" name="la_urgent">
              <option>No — standard enquiry</option>
              <option>Yes — within the next 48 hours</option>
              <option>Yes — I need help today</option>
            </select>
          </div>
          <div class="la-cf">
            <label for="la-message">Brief description of your matter *</label>
            <textarea id="la-message" name="la_message" placeholder="Please describe your situation briefly. All enquiries are treated in strict confidence." required></textarea>
          </div>
          <button type="submit" class="la-btn la-btn--primary">Send Enquiry →</button>
          <p class="la-cform__disclaimer">All enquiries are treated in strictest confidence and are protected by legal professional privilege. We will never share your details with third parties.</p>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     FOOTER CTA
════════════════════════════════════════ -->
<div class="la-footer-cta">
  <div class="la-wrap">
    <h2>Need Legal Advice?</h2>
    <p>Call us today for a confidential consultation. We're here to help — whatever your situation.</p>
    <a href="#contact" class="la-btn">Request a Consultation →</a>
  </div>
</div>

</div><!-- .la-page -->

<script>
(function(){
  'use strict';
  /* ── Counters ── */
  function laEase(t){return 1-Math.pow(1-t,3)}
  document.querySelectorAll('.la-counter').forEach(function(el){
    var target=parseFloat(el.dataset.target);
    if(isNaN(target))return;
    var prefix=el.dataset.prefix||'';var suffix=el.dataset.suffix||'';
    var isFloat=target%1!==0;var started=false;
    var obs=new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(entry.isIntersecting&&!started){
          started=true;var start=performance.now();var dur=1800;
          function tick(now){
            var t=Math.min((now-start)/dur,1);
            var val=laEase(t)*target;
            el.textContent=prefix+(isFloat?val.toFixed(1):Math.round(val))+suffix;
            if(t<1)requestAnimationFrame(tick);
          }
          requestAnimationFrame(tick);obs.disconnect();
        }
      });
    },{threshold:.3});
    obs.observe(el);
  });
  /* ── Reveal ── */
  var reveals=document.querySelectorAll('.la-reveal');
  if(reveals.length){
    var ro=new IntersectionObserver(function(entries){
      entries.forEach(function(entry,i){
        if(entry.isIntersecting){
          setTimeout(function(){entry.target.classList.add('la-visible');},i*80);
          ro.unobserve(entry.target);
        }
      });
    },{threshold:.12});
    reveals.forEach(function(el){ro.observe(el);});
  }
  /* ── FAQ ── */
  document.querySelectorAll('.la-faq-q').forEach(function(btn){
    btn.addEventListener('click',function(){
      var item=btn.closest('.la-faq-item');
      var ans=item.querySelector('.la-faq-a');
      var isOpen=item.classList.contains('la-open');
      document.querySelectorAll('.la-faq-item.la-open').forEach(function(oi){
        oi.classList.remove('la-open');
        oi.querySelector('.la-faq-a').style.maxHeight='0';
        oi.querySelector('.la-faq-q').setAttribute('aria-expanded','false');
      });
      if(!isOpen){
        item.classList.add('la-open');
        ans.style.maxHeight=ans.scrollHeight+'px';
        btn.setAttribute('aria-expanded','true');
      }
    });
  });
  /* ── Smooth scroll ── */
  document.querySelectorAll('a[href^="#"]').forEach(function(a){
    a.addEventListener('click',function(e){
      var t=document.querySelector(a.getAttribute('href'));
      if(t){e.preventDefault();t.scrollIntoView({behavior:'smooth',block:'start'});}
    });
  });
})();
</script>

<?php get_footer(); ?>
