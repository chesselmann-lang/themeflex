<?php
/**
 * Template Name: Premium – Law Firm & Legal Services
 *
 * @package ThemeFlex
 */

defined('ABSPATH') || exit;

srand(crc32(get_the_permalink()));

/* ── Practice Areas ─────────────────────────────────────────── */
$lfw_practices = [
    ['icon'=>'⚖️','title'=>'Litigation & Dispute Resolution','desc'=>'Robust courtroom advocacy and strategic dispute management for complex commercial and civil matters.','sub'=>['Commercial Disputes','Contract Litigation','Class Actions','Arbitration & Mediation']],
    ['icon'=>'🏢','title'=>'Corporate & M&A','desc'=>'End-to-end transactional counsel for mergers, acquisitions, restructurings and joint ventures.','sub'=>['Due Diligence','Deal Structuring','Regulatory Approvals','Post-Merger Integration']],
    ['icon'=>'🏠','title'=>'Real Estate & Property','desc'=>'Full-spectrum property law advice for developers, investors, landlords and occupiers.','sub'=>['Acquisitions & Disposals','Development Finance','Leasing','Planning & Zoning']],
    ['icon'=>'👤','title'=>'Employment & HR','desc'=>'Strategic employment law support protecting businesses and individuals in the modern workplace.','sub'=>['Wrongful Dismissal','Discrimination Claims','Settlement Agreements','HR Policy Drafting']],
    ['icon'=>'📋','title'=>'Wills, Trusts & Estates','desc'=>'Compassionate succession planning and estate administration with precision and discretion.','sub'=>['Wills & Codicils','Lasting Power of Attorney','Probate','Trust Formation']],
    ['icon'=>'💻','title'=>'Technology & IP','desc'=>'Cutting-edge advice on intellectual property, data privacy and technology transactions.','sub'=>['Patent & Trade Mark','Data Protection / GDPR','Software Licensing','Cyber Incident Response']],
];

/* ── Attorneys ──────────────────────────────────────────────── */
$lfw_attorneys = [
    ['name'=>'Margaret Ashworth QC','role'=>'Senior Partner — Litigation','years'=>28,'called'=>'Silk, Inner Temple','cases'=>340,'color'=>'#2c3e50'],
    ['name'=>'James Caldwell','role'=>'Partner — Corporate & M&A','years'=>19,'called'=>'Gray\'s Inn, 2007','cases'=>210,'color'=>'#1a3a5c'],
    ['name'=>'Priya Mehta','role'=>'Partner — Technology & IP','years'=>14,'called'=>'Lincoln\'s Inn, 2012','cases'=>175,'color'=>'#2d4a3e'],
    ['name'=>'Thomas Brennan','role'=>'Associate — Employment','years'=>8,'called'=>'Middle Temple, 2018','cases'=>120,'color'=>'#4a2d2d'],
];

/* ── Process Steps ──────────────────────────────────────────── */
$lfw_steps = [
    ['num'=>'01','title'=>'Initial Consultation','desc'=>'A confidential, no-obligation discussion to understand your situation and assess the merit of your matter.'],
    ['num'=>'02','title'=>'Engagement & Strategy','desc'=>'We agree scope, fees and a bespoke legal strategy tailored to your objectives and risk appetite.'],
    ['num'=>'03','title'=>'Active Representation','desc'=>'Our team works with precision and urgency — drafting, negotiating, litigating — on your behalf.'],
    ['num'=>'04','title'=>'Resolution & Review','desc'=>'We secure the best possible outcome, then debrief to ensure lasting protection and peace of mind.'],
];

/* ── Stats ──────────────────────────────────────────────────── */
$lfw_stats = [
    ['val'=>'94','suffix'=>'%','label'=>'Success Rate'],
    ['val'=>'1200','suffix'=>'+','label'=>'Cases Resolved'],
    ['val'=>'38','suffix'=>'','label'=>'Years Established'],
    ['val'=>'6','suffix'=>'','label'=>'Practice Areas'],
];

/* ── Testimonials ───────────────────────────────────────────── */
$lfw_testimonials = [
    ['quote'=>'Ashworth & Partners navigated our £40m acquisition with exceptional skill. Their M&A team identified risks our own due diligence had missed and negotiated terms that saved us considerably.','author'=>'CEO, Manufacturing Group','sector'=>'Corporate'],
    ['quote'=>'Margaret Ashworth\'s representation in our commercial dispute was outstanding. Her courtroom presence and legal acumen secured a result we genuinely did not think was achievable.','author'=>'Managing Director, Retail Chain','sector'=>'Litigation'],
    ['quote'=>'Priya Mehta guided us through a complex GDPR investigation with calm authority. Her advice was practical, clear and ultimately resolved the matter without enforcement action.','author'=>'Chief Operating Officer, FinTech','sector'=>'Technology & IP'],
];

/* ── Awards ─────────────────────────────────────────────────── */
$lfw_awards = [
    ['year'=>'2024','award'=>'Chambers UK Band 1 — Commercial Litigation'],
    ['year'=>'2024','award'=>'Legal 500 — Tier 1 Corporate & M&A'],
    ['year'=>'2023','award'=>'Law Society Excellence Award — Client Service'],
    ['year'=>'2023','award'=>'The Lawyer — Top 100 Regional Firm'],
    ['year'=>'2022','award'=>'Lexology Index — Outstanding M&A Advisory'],
    ['year'=>'2022','award'=>'Litigation Times — Best Regional Practice'],
];

/* ── FAQ ────────────────────────────────────────────────────── */
$lfw_faqs = [
    ['q'=>'Do you offer a free initial consultation?','a'=>'Yes. We offer a 30-minute confidential consultation at no charge. This allows us to understand your matter and advise whether we can assist before any fees are incurred.'],
    ['q'=>'What are your fee arrangements?','a'=>'We offer a range of fee arrangements including fixed fee, hourly rate, conditional fee (no-win no-fee) and blended rates for litigation matters, depending on the nature and complexity of your case.'],
    ['q'=>'How quickly can you take on my case?','a'=>'For urgent matters — injunctions, tribunal deadlines, time-sensitive transactions — we can mobilise within 24 hours. Routine instructions are typically onboarded within 3–5 working days.'],
    ['q'=>'Are all matters kept strictly confidential?','a'=>'Absolutely. All client communications are protected by legal professional privilege and our strict confidentiality policy. We take data protection seriously and are fully GDPR compliant.'],
    ['q'=>'Do you act for individuals as well as businesses?','a'=>'Yes. While much of our work involves corporate clients, we also represent high-net-worth individuals, executives, entrepreneurs and private clients across all our practice areas.'],
];

get_header();
?>

<!– Law Firm & Legal Services — ThemeFlex Premium Template –>
<style>
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400;1,600&family=Raleway:wght@300;400;500;600;700&display=swap');

:root {
  --lfw-midnight: #0d1117;
  --lfw-charcoal: #1c2128;
  --lfw-gold:     #c9a84c;
  --lfw-gold-lt:  #e2c97e;
  --lfw-cream:    #f5f0e8;
  --lfw-ivory:    #fdfaf4;
  --lfw-slate:    #4a5568;
  --lfw-silver:   #8a95a3;
  --lfw-border:   rgba(201,168,76,0.25);
  --lfw-serif:    'Cormorant Garamond', Georgia, serif;
  --lfw-sans:     'Raleway', system-ui, sans-serif;
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

.lfw-wrap { font-family: var(--lfw-sans); color: var(--lfw-charcoal); background: var(--lfw-ivory); overflow-x: hidden; }

/* ── HERO ──────────────────────────────────────────────────── */
.lfw-hero {
  position: relative;
  min-height: 100vh;
  background: var(--lfw-midnight);
  display: flex;
  align-items: center;
  overflow: hidden;
}

/* Background architectural grid */
.lfw-hero-grid {
  position: absolute; inset: 0;
  background-image:
    linear-gradient(rgba(201,168,76,0.04) 1px, transparent 1px),
    linear-gradient(90deg, rgba(201,168,76,0.04) 1px, transparent 1px);
  background-size: 80px 80px;
}

/* CSS courthouse / law building illustration */
.lfw-courthouse {
  position: absolute;
  right: 0; bottom: 0;
  width: 55%;
  height: 100%;
  pointer-events: none;
}

/* Courthouse base */
.lfw-ch-base {
  position: absolute;
  bottom: 0; left: 50%;
  transform: translateX(-50%);
  width: 520px;
  height: 360px;
  background: linear-gradient(180deg, #1e2a38 0%, #161f2b 100%);
  border-top: 3px solid var(--lfw-gold);
}

/* Pediment / triangular roof */
.lfw-ch-pediment {
  position: absolute;
  bottom: 360px; left: 50%;
  transform: translateX(-50%);
  width: 0;
  height: 0;
  border-left: 290px solid transparent;
  border-right: 290px solid transparent;
  border-bottom: 120px solid #1a2535;
  filter: drop-shadow(0 -2px 0 rgba(201,168,76,0.4));
}

/* Cornice / entablature under pediment */
.lfw-ch-entablature {
  position: absolute;
  bottom: 360px; left: 50%;
  transform: translateX(-50%);
  width: 560px;
  height: 32px;
  background: linear-gradient(180deg, #243040 0%, #1a2535 100%);
  border-top: 2px solid var(--lfw-gold);
  border-bottom: 2px solid rgba(201,168,76,0.3);
}

/* Columns */
.lfw-ch-columns {
  position: absolute;
  bottom: 392px; left: 50%;
  transform: translateX(-50%);
  width: 500px;
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
}
.lfw-ch-col {
  width: 42px;
  height: 220px;
  background: linear-gradient(90deg, #1a2535 0%, #243040 30%, #2a3848 50%, #243040 70%, #1a2535 100%);
  border-top: 8px solid #2d3f52;
  border-bottom: 12px solid #2d3f52;
  position: relative;
}
.lfw-ch-col::before {
  content: '';
  position: absolute;
  top: -14px; left: 50%;
  transform: translateX(-50%);
  width: 52px; height: 12px;
  background: #2d3f52;
}
.lfw-ch-col::after {
  content: '';
  position: absolute;
  bottom: -18px; left: 50%;
  transform: translateX(-50%);
  width: 52px; height: 14px;
  background: #2d3f52;
}

/* Column fluting lines */
.lfw-ch-col span {
  position: absolute;
  top: 0; bottom: 0;
  width: 1px;
  background: rgba(255,255,255,0.06);
}

/* Courthouse steps */
.lfw-ch-steps {
  position: absolute;
  bottom: 0; left: 50%;
  transform: translateX(-50%);
}
.lfw-ch-step {
  height: 18px;
  background: #1a2535;
  border-top: 1px solid rgba(201,168,76,0.15);
  margin: 0 auto;
}

/* Windows on courthouse */
.lfw-ch-window {
  position: absolute;
  background: linear-gradient(180deg, rgba(201,168,76,0.15) 0%, rgba(201,168,76,0.06) 100%);
  border: 1px solid rgba(201,168,76,0.3);
  border-radius: 50% 50% 0 0 / 100% 100% 0 0;
}
.lfw-ch-window::before {
  content: '';
  position: absolute;
  inset: 4px;
  border: 1px solid rgba(201,168,76,0.15);
  border-radius: 50% 50% 0 0 / 100% 100% 0 0;
}

/* Grand door */
.lfw-ch-door {
  position: absolute;
  bottom: 54px; left: 50%;
  transform: translateX(-50%);
  width: 80px; height: 140px;
  background: linear-gradient(180deg, #0d1117 0%, #141c26 100%);
  border: 2px solid rgba(201,168,76,0.4);
  border-radius: 50% 50% 0 0 / 40% 40% 0 0;
}
.lfw-ch-door::before {
  content: '';
  position: absolute;
  inset: 6px;
  border: 1px solid rgba(201,168,76,0.2);
  border-radius: 50% 50% 0 0 / 40% 40% 0 0;
}
/* Door handle */
.lfw-ch-door::after {
  content: '';
  position: absolute;
  bottom: 30px; left: 50%;
  transform: translateX(-50%);
  width: 8px; height: 8px;
  background: var(--lfw-gold);
  border-radius: 50%;
  box-shadow: 0 0 8px rgba(201,168,76,0.6);
}

/* Scales of justice on pediment */
.lfw-ch-scales {
  position: absolute;
  bottom: 420px; left: 50%;
  transform: translateX(-50%);
  width: 60px; height: 80px;
}
.lfw-ch-scales-arm {
  position: absolute;
  top: 30px; left: 50%;
  transform: translateX(-50%);
  width: 56px; height: 2px;
  background: var(--lfw-gold);
}
.lfw-ch-scales-arm::before {
  content: '';
  position: absolute;
  top: 50%; left: 50%;
  transform: translate(-50%,-50%);
  width: 2px; height: 30px;
  background: var(--lfw-gold);
}
.lfw-ch-scales-pan {
  position: absolute;
  bottom: 0;
  width: 18px; height: 6px;
  background: var(--lfw-gold);
  border-radius: 0 0 8px 8px;
}
.lfw-ch-scales-pan.left { left: 0; }
.lfw-ch-scales-pan.right { right: 0; }
.lfw-ch-scales-cord {
  position: absolute;
  bottom: 6px;
  width: 1px; height: 14px;
  background: var(--lfw-gold);
}
.lfw-ch-scales-cord.left { left: 9px; }
.lfw-ch-scales-cord.right { right: 9px; }

/* Ambient glow behind building */
.lfw-ch-glow {
  position: absolute;
  bottom: 0; left: 50%;
  transform: translateX(-50%);
  width: 600px; height: 300px;
  background: radial-gradient(ellipse at 50% 100%, rgba(201,168,76,0.1) 0%, transparent 70%);
  pointer-events: none;
}

/* Gold vertical accent line */
.lfw-hero-accent {
  position: absolute;
  left: 8%;
  top: 15%; bottom: 15%;
  width: 2px;
  background: linear-gradient(180deg, transparent, var(--lfw-gold), transparent);
  opacity: 0.6;
}

/* Floating quote marks */
.lfw-hero-quote-mark {
  position: absolute;
  font-family: var(--lfw-serif);
  font-size: 320px;
  color: rgba(201,168,76,0.04);
  line-height: 1;
  font-style: italic;
  user-select: none;
  pointer-events: none;
}

.lfw-hero-content {
  position: relative;
  z-index: 2;
  max-width: 580px;
  padding: 80px 60px;
}

.lfw-hero-eyebrow {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-bottom: 28px;
}
.lfw-hero-eyebrow-line {
  width: 48px; height: 1px;
  background: var(--lfw-gold);
}
.lfw-hero-eyebrow-text {
  font-family: var(--lfw-sans);
  font-size: 0.7rem;
  font-weight: 600;
  letter-spacing: 0.25em;
  text-transform: uppercase;
  color: var(--lfw-gold);
}

.lfw-hero h1 {
  font-family: var(--lfw-serif);
  font-size: clamp(3rem, 5.5vw, 5.5rem);
  font-weight: 600;
  line-height: 1.08;
  color: var(--lfw-cream);
  margin-bottom: 8px;
}
.lfw-hero h1 em {
  font-style: italic;
  color: var(--lfw-gold);
}

.lfw-hero-sub {
  font-family: var(--lfw-serif);
  font-size: clamp(1.4rem, 2.5vw, 2rem);
  font-weight: 400;
  font-style: italic;
  color: var(--lfw-silver);
  margin-bottom: 32px;
}

.lfw-hero-desc {
  font-size: 1rem;
  line-height: 1.75;
  color: rgba(245,240,232,0.7);
  max-width: 440px;
  margin-bottom: 48px;
}

.lfw-hero-ctas {
  display: flex;
  gap: 16px;
  flex-wrap: wrap;
}
.lfw-btn-primary {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  padding: 16px 36px;
  background: var(--lfw-gold);
  color: var(--lfw-midnight);
  font-family: var(--lfw-sans);
  font-size: 0.8rem;
  font-weight: 700;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  text-decoration: none;
  transition: background 0.25s, transform 0.2s;
  border: none; cursor: pointer;
}
.lfw-btn-primary:hover { background: var(--lfw-gold-lt); transform: translateY(-2px); }

.lfw-btn-outline {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  padding: 15px 36px;
  background: transparent;
  color: var(--lfw-cream);
  font-family: var(--lfw-sans);
  font-size: 0.8rem;
  font-weight: 600;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  text-decoration: none;
  border: 1px solid rgba(245,240,232,0.3);
  transition: border-color 0.25s, color 0.25s, transform 0.2s;
}
.lfw-btn-outline:hover { border-color: var(--lfw-gold); color: var(--lfw-gold); transform: translateY(-2px); }

/* Credential bar at bottom of hero */
.lfw-hero-credentials {
  position: absolute;
  bottom: 0; left: 0; right: 0;
  background: rgba(13,17,23,0.9);
  border-top: 1px solid var(--lfw-border);
  backdrop-filter: blur(8px);
  display: flex;
  justify-content: center;
  gap: 0;
  z-index: 3;
}
.lfw-cred-item {
  padding: 18px 40px;
  border-right: 1px solid var(--lfw-border);
  display: flex;
  align-items: center;
  gap: 12px;
}
.lfw-cred-item:last-child { border-right: none; }
.lfw-cred-icon {
  font-size: 1.4rem;
  opacity: 0.85;
}
.lfw-cred-text {
  font-size: 0.72rem;
  font-weight: 600;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--lfw-silver);
}
.lfw-cred-text strong {
  display: block;
  color: var(--lfw-gold);
  font-size: 0.68rem;
}

/* ── GENERAL LAYOUT ────────────────────────────────────────── */
.lfw-section {
  padding: 100px 40px;
  max-width: 1280px;
  margin: 0 auto;
}
.lfw-section-full {
  padding: 100px 40px;
}
.lfw-section-label {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-bottom: 16px;
}
.lfw-section-label-line {
  width: 40px; height: 1px;
  background: var(--lfw-gold);
}
.lfw-section-label-text {
  font-size: 0.68rem;
  font-weight: 700;
  letter-spacing: 0.22em;
  text-transform: uppercase;
  color: var(--lfw-gold);
}
.lfw-section-title {
  font-family: var(--lfw-serif);
  font-size: clamp(2rem, 3.5vw, 3rem);
  font-weight: 600;
  line-height: 1.15;
  color: var(--lfw-charcoal);
  margin-bottom: 16px;
}
.lfw-section-title em { font-style: italic; color: var(--lfw-gold); }
.lfw-section-intro {
  font-size: 1.05rem;
  line-height: 1.75;
  color: var(--lfw-slate);
  max-width: 600px;
  margin-bottom: 64px;
}

/* ── REVEAL ANIMATION ──────────────────────────────────────── */
.lfw-reveal {
  opacity: 0;
  transform: translateY(28px);
  transition: opacity 0.65s ease, transform 0.65s ease;
}
.lfw-reveal.visible { opacity: 1; transform: translateY(0); }

/* ── PRACTICE AREAS ────────────────────────────────────────── */
.lfw-practices-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 2px;
  background: rgba(201,168,76,0.1);
}
.lfw-practice-card {
  background: var(--lfw-ivory);
  padding: 44px 40px;
  position: relative;
  transition: background 0.3s;
  overflow: hidden;
}
.lfw-practice-card::before {
  content: '';
  position: absolute;
  bottom: 0; left: 0;
  width: 0; height: 3px;
  background: var(--lfw-gold);
  transition: width 0.4s ease;
}
.lfw-practice-card:hover { background: #fffdf7; }
.lfw-practice-card:hover::before { width: 100%; }

.lfw-practice-icon {
  font-size: 2.2rem;
  margin-bottom: 20px;
  display: block;
}
.lfw-practice-title {
  font-family: var(--lfw-serif);
  font-size: 1.3rem;
  font-weight: 600;
  color: var(--lfw-charcoal);
  margin-bottom: 14px;
  line-height: 1.3;
}
.lfw-practice-desc {
  font-size: 0.9rem;
  line-height: 1.7;
  color: var(--lfw-slate);
  margin-bottom: 20px;
}
.lfw-practice-sub {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.lfw-practice-sub li {
  font-size: 0.78rem;
  color: var(--lfw-silver);
  padding-left: 16px;
  position: relative;
}
.lfw-practice-sub li::before {
  content: '—';
  position: absolute;
  left: 0;
  color: var(--lfw-gold);
  font-size: 0.7rem;
}

/* ── ATTORNEYS ─────────────────────────────────────────────── */
.lfw-attorneys-section {
  background: var(--lfw-charcoal);
  color: var(--lfw-cream);
}
.lfw-attorneys-inner {
  max-width: 1280px;
  margin: 0 auto;
}
.lfw-attorneys-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 2px;
  background: rgba(201,168,76,0.1);
  margin-top: 60px;
}
.lfw-attorney-card {
  background: var(--lfw-charcoal);
  padding: 40px 32px;
  position: relative;
  overflow: hidden;
  transition: background 0.3s;
}
.lfw-attorney-card:hover { background: #222b36; }

/* CSS attorney portrait */
.lfw-atty-portrait {
  width: 88px; height: 88px;
  border-radius: 50%;
  margin: 0 auto 24px;
  position: relative;
  overflow: hidden;
}
.lfw-atty-portrait-bg {
  position: absolute; inset: 0;
  border-radius: 50%;
}
/* Head */
.lfw-atty-head {
  position: absolute;
  top: 14px; left: 50%;
  transform: translateX(-50%);
  width: 36px; height: 36px;
  background: #d4a574;
  border-radius: 50%;
}
/* Suit/jacket */
.lfw-atty-suit {
  position: absolute;
  bottom: 0; left: 50%;
  transform: translateX(-50%);
  width: 76px; height: 42px;
  border-radius: 50% 50% 0 0 / 30% 30% 0 0;
}
/* Lapels */
.lfw-atty-lapel-l, .lfw-atty-lapel-r {
  position: absolute;
  bottom: 10px;
  width: 14px; height: 30px;
  background: var(--lfw-cream);
}
.lfw-atty-lapel-l { left: 50%; transform: translateX(-18px) rotate(8deg); clip-path: polygon(0 0, 100% 20%, 100% 100%, 0 80%); }
.lfw-atty-lapel-r { left: 50%; transform: translateX(4px) rotate(-8deg); clip-path: polygon(0 20%, 100% 0, 100% 80%, 0 100%); }
/* Tie */
.lfw-atty-tie {
  position: absolute;
  bottom: 8px; left: 50%;
  transform: translateX(-50%);
  width: 10px; height: 28px;
  clip-path: polygon(20% 0%, 80% 0%, 100% 80%, 50% 100%, 0% 80%);
}
/* Gold ring border */
.lfw-atty-portrait::after {
  content: '';
  position: absolute; inset: 2px;
  border-radius: 50%;
  border: 2px solid var(--lfw-gold);
  pointer-events: none;
}

.lfw-atty-name {
  font-family: var(--lfw-serif);
  font-size: 1.1rem;
  font-weight: 600;
  color: var(--lfw-cream);
  text-align: center;
  margin-bottom: 6px;
}
.lfw-atty-role {
  font-size: 0.72rem;
  font-weight: 500;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--lfw-gold);
  text-align: center;
  margin-bottom: 20px;
}
.lfw-atty-detail {
  font-size: 0.78rem;
  color: var(--lfw-silver);
  text-align: center;
  line-height: 1.6;
}
.lfw-atty-cases {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  margin-top: 16px;
  padding-top: 16px;
  border-top: 1px solid rgba(201,168,76,0.15);
}
.lfw-atty-cases-num {
  font-family: var(--lfw-serif);
  font-size: 1.6rem;
  font-weight: 600;
  color: var(--lfw-gold);
}
.lfw-atty-cases-label {
  font-size: 0.7rem;
  color: var(--lfw-silver);
  letter-spacing: 0.05em;
  line-height: 1.3;
}

/* ── PROCESS ───────────────────────────────────────────────── */
.lfw-process-section { background: var(--lfw-ivory); }
.lfw-process-steps {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 0;
  margin-top: 60px;
  position: relative;
}
/* Connecting line */
.lfw-process-steps::before {
  content: '';
  position: absolute;
  top: 36px; left: 10%; right: 10%;
  height: 1px;
  background: linear-gradient(90deg, transparent, var(--lfw-gold), transparent);
}
.lfw-process-step {
  padding: 0 32px;
  text-align: center;
  position: relative;
}
.lfw-process-num {
  font-family: var(--lfw-serif);
  font-size: 3.5rem;
  font-weight: 700;
  color: rgba(201,168,76,0.15);
  line-height: 1;
  margin-bottom: 12px;
}
.lfw-process-circle {
  width: 72px; height: 72px;
  border-radius: 50%;
  border: 1px solid var(--lfw-gold);
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 24px;
  background: var(--lfw-ivory);
  font-family: var(--lfw-serif);
  font-size: 1.1rem;
  font-weight: 600;
  color: var(--lfw-gold);
  position: relative;
  z-index: 1;
}
.lfw-process-title {
  font-family: var(--lfw-serif);
  font-size: 1.1rem;
  font-weight: 600;
  color: var(--lfw-charcoal);
  margin-bottom: 12px;
}
.lfw-process-desc {
  font-size: 0.85rem;
  line-height: 1.7;
  color: var(--lfw-slate);
}

/* ── STATS ─────────────────────────────────────────────────── */
.lfw-stats-section {
  background: var(--lfw-midnight);
  padding: 80px 40px;
  position: relative;
  overflow: hidden;
}
.lfw-stats-section::before {
  content: '"Justice"';
  position: absolute;
  right: 5%;
  top: 50%;
  transform: translateY(-50%);
  font-family: var(--lfw-serif);
  font-size: 180px;
  font-style: italic;
  font-weight: 600;
  color: rgba(201,168,76,0.04);
  pointer-events: none;
  white-space: nowrap;
}
.lfw-stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 0;
  max-width: 1000px;
  margin: 0 auto;
  border: 1px solid var(--lfw-border);
}
.lfw-stat-item {
  padding: 52px 40px;
  text-align: center;
  border-right: 1px solid var(--lfw-border);
  position: relative;
}
.lfw-stat-item:last-child { border-right: none; }
.lfw-stat-val {
  font-family: var(--lfw-serif);
  font-size: 3.8rem;
  font-weight: 600;
  color: var(--lfw-gold);
  line-height: 1;
  display: block;
}
.lfw-stat-label {
  font-size: 0.72rem;
  font-weight: 600;
  letter-spacing: 0.15em;
  text-transform: uppercase;
  color: var(--lfw-silver);
  margin-top: 10px;
  display: block;
}

/* ── TESTIMONIALS ──────────────────────────────────────────── */
.lfw-testimonials-section { background: var(--lfw-cream); }
.lfw-testimonials-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 32px;
  margin-top: 60px;
}
.lfw-testimonial-card {
  background: var(--lfw-ivory);
  padding: 44px 40px;
  position: relative;
  border-top: 3px solid var(--lfw-gold);
}
.lfw-testimonial-quote-mark {
  font-family: var(--lfw-serif);
  font-size: 5rem;
  line-height: 0.5;
  color: var(--lfw-gold);
  opacity: 0.3;
  margin-bottom: 20px;
  display: block;
}
.lfw-testimonial-text {
  font-family: var(--lfw-serif);
  font-size: 1.05rem;
  font-style: italic;
  line-height: 1.75;
  color: var(--lfw-slate);
  margin-bottom: 28px;
}
.lfw-testimonial-author {
  font-size: 0.8rem;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--lfw-charcoal);
}
.lfw-testimonial-sector {
  font-size: 0.72rem;
  color: var(--lfw-gold);
  margin-top: 4px;
  font-weight: 500;
}

/* ── AWARDS ────────────────────────────────────────────────── */
.lfw-awards-section { background: var(--lfw-ivory); }
.lfw-awards-table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 60px;
}
.lfw-awards-table tr {
  border-bottom: 1px solid rgba(201,168,76,0.15);
  transition: background 0.2s;
}
.lfw-awards-table tr:hover { background: rgba(201,168,76,0.04); }
.lfw-awards-table td {
  padding: 22px 0;
  font-size: 0.9rem;
}
.lfw-award-year {
  font-family: var(--lfw-serif);
  font-size: 1.4rem;
  font-weight: 600;
  color: var(--lfw-gold);
  width: 90px;
  padding-right: 32px !important;
}
.lfw-award-name {
  color: var(--lfw-charcoal);
  font-weight: 500;
}
.lfw-award-icon {
  text-align: right;
  color: var(--lfw-gold);
  font-size: 1.1rem;
}

/* ── FAQ ───────────────────────────────────────────────────── */
.lfw-faq-section { background: var(--lfw-cream); }
.lfw-faq-layout {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 80px;
  margin-top: 60px;
  align-items: start;
}
.lfw-faq-list {
  display: flex;
  flex-direction: column;
  gap: 0;
}
.lfw-faq-item {
  border-bottom: 1px solid rgba(201,168,76,0.2);
}
.lfw-faq-trigger {
  width: 100%;
  background: none;
  border: none;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  padding: 24px 0;
  cursor: pointer;
  text-align: left;
}
.lfw-faq-q {
  font-family: var(--lfw-serif);
  font-size: 1.05rem;
  font-weight: 600;
  color: var(--lfw-charcoal);
  line-height: 1.35;
}
.lfw-faq-icon {
  flex-shrink: 0;
  width: 28px; height: 28px;
  border-radius: 50%;
  border: 1px solid var(--lfw-gold);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.1rem;
  color: var(--lfw-gold);
  transition: transform 0.3s, background 0.3s;
}
.lfw-faq-item.open .lfw-faq-icon {
  transform: rotate(45deg);
  background: var(--lfw-gold);
  color: var(--lfw-midnight);
}
.lfw-faq-body {
  overflow: hidden;
  max-height: 0;
  transition: max-height 0.4s ease;
}
.lfw-faq-body-inner {
  padding: 0 0 24px;
  font-size: 0.9rem;
  line-height: 1.75;
  color: var(--lfw-slate);
}

/* CSS bookcase / law library illustration */
.lfw-faq-library {
  position: relative;
  width: 100%;
  height: 480px;
  background: linear-gradient(180deg, #f0e8d8 0%, #e8dcc8 100%);
  border: 1px solid rgba(201,168,76,0.2);
  overflow: hidden;
}
.lfw-lib-floor {
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 24px;
  background: #c8a878;
}
.lfw-lib-wall {
  position: absolute;
  inset: 0;
  background: linear-gradient(180deg, #e8d8c0 0%, #d8c8a8 100%);
}
/* Wainscoting */
.lfw-lib-wainscot {
  position: absolute;
  bottom: 24px; left: 0; right: 0;
  height: 80px;
  background: #c8a878;
  border-top: 3px solid #b89868;
}
/* Large bookcase */
.lfw-lib-bookcase {
  position: absolute;
  bottom: 104px; left: 50%;
  transform: translateX(-50%);
  width: 300px; height: 300px;
  background: #5c3d1e;
  border: 3px solid #3e2810;
}
/* Shelves */
.lfw-lib-shelf {
  position: absolute;
  left: 8px; right: 8px;
  height: 6px;
  background: #3e2810;
  border-radius: 1px;
}
/* Books on shelves — generated via PHP */
<?php
$lfw_book_colors = ['#8b0000','#1a3a5c','#2d4a1e','#6b2030','#3d2b6b','#c8580a','#1e4040','#7a5c00','#4a1a3a','#2a4a2a'];
$lfw_book_widths = [16,14,18,13,20,15,17,12,19,16];
$lfw_shelf_y    = [12, 96, 180, 264]; // top position of each shelf row

foreach ($lfw_shelf_y as $si => $sy) {
    $x = 12;
    $books_on_shelf = rand(6, 9);
    for ($bi = 0; $bi < $books_on_shelf; $bi++) {
        $bw = $lfw_book_widths[$bi % count($lfw_book_widths)];
        $bc = $lfw_book_colors[$bi % count($lfw_book_colors)];
        $bh = rand(56, 80);
        $tilt = ($bi % 5 === 4) ? 'transform:rotate(-8deg);transform-origin:bottom center;' : '';
        echo ".lfw-lib-book-{$si}-{$bi}{position:absolute;bottom:6px;left:{$x}px;width:{$bw}px;height:{$bh}px;background:{$bc};border-right:2px solid rgba(0,0,0,0.15);{$tilt}}\n";
        $x += $bw + 2;
    }
}
?>

/* Desk */
.lfw-lib-desk {
  position: absolute;
  bottom: 104px; right: 20px;
  width: 110px; height: 12px;
  background: #8b6914;
  border-radius: 2px;
}
.lfw-lib-desk-leg {
  position: absolute;
  bottom: 116px; right: 20px;
  width: 8px; height: 60px;
  background: #6b5010;
}
.lfw-lib-desk-leg.r { right: 112px; }

/* Desk lamp */
.lfw-lib-lamp {
  position: absolute;
  bottom: 116px; right: 64px;
  width: 4px; height: 50px;
  background: #888;
}
.lfw-lib-lamp-shade {
  position: absolute;
  bottom: 164px; right: 44px;
  width: 44px; height: 20px;
  background: #c8a050;
  border-radius: 50% 50% 0 0 / 100% 100% 0 0;
  box-shadow: 0 8px 20px rgba(201,168,76,0.5);
}
/* Lamp glow */
.lfw-lib-lamp-glow {
  position: absolute;
  bottom: 88px; right: 14px;
  width: 100px; height: 60px;
  background: radial-gradient(ellipse at 60% 0%, rgba(201,168,76,0.3) 0%, transparent 70%);
}

/* Legal tome on desk */
.lfw-lib-tome {
  position: absolute;
  bottom: 116px; right: 24px;
  width: 32px; height: 22px;
  background: #8b0000;
  border-right: 3px solid #6b0000;
  transform: rotate(-3deg);
}

/* Scales of justice on desk */
.lfw-lib-scales {
  position: absolute;
  bottom: 116px; right: 70px;
  width: 30px; height: 40px;
}
.lfw-lib-scales-arm {
  position: absolute;
  top: 18px; left: 0; right: 0;
  height: 1px;
  background: var(--lfw-gold);
}
.lfw-lib-scales-arm::before {
  content: '';
  position: absolute;
  top: 0; left: 50%;
  transform: translateX(-50%);
  width: 1px; height: 18px;
  background: var(--lfw-gold);
}
.lfw-lib-scales-pan {
  position: absolute;
  bottom: 0;
  width: 10px; height: 3px;
  background: var(--lfw-gold);
  border-radius: 0 0 4px 4px;
}
.lfw-lib-scales-pan.l { left: 0; }
.lfw-lib-scales-pan.r { right: 0; }

/* Window */
.lfw-lib-window {
  position: absolute;
  top: 24px; right: 24px;
  width: 90px; height: 140px;
  background: linear-gradient(180deg, rgba(135,185,235,0.5) 0%, rgba(100,160,220,0.3) 100%);
  border: 4px solid #8b6914;
  border-radius: 50% 50% 0 0 / 30% 30% 0 0;
}
/* Cross bar */
.lfw-lib-window::before {
  content: '';
  position: absolute;
  top: 50%; left: 0; right: 0;
  height: 3px;
  background: #8b6914;
}
.lfw-lib-window::after {
  content: '';
  position: absolute;
  top: 0; bottom: 0; left: 50%;
  width: 3px;
  background: #8b6914;
}
/* Light rays from window */
.lfw-lib-ray {
  position: absolute;
  top: 24px; right: 24px;
  width: 1px;
  background: linear-gradient(180deg, rgba(201,168,76,0.2), transparent);
  transform-origin: top center;
}

/* Portrait painting */
.lfw-lib-portrait {
  position: absolute;
  top: 20px; left: 24px;
  width: 70px; height: 90px;
  background: linear-gradient(180deg, #2a3a2a 0%, #1a2a1a 100%);
  border: 6px solid #8b6914;
}
.lfw-lib-portrait::before {
  content: '';
  position: absolute;
  inset: 8px;
  background: #c8a878;
  border-radius: 50% 50% 0 0 / 30% 30% 0 0;
}
.lfw-lib-portrait::after {
  content: '';
  position: absolute;
  inset: -10px;
  border: 2px solid rgba(139,105,20,0.4);
  pointer-events: none;
}

/* Caption under library */
.lfw-lib-caption {
  position: absolute;
  bottom: 132px; left: 50%;
  transform: translateX(-50%);
  font-family: var(--lfw-serif);
  font-size: 0.75rem;
  font-style: italic;
  color: rgba(92,61,30,0.5);
  white-space: nowrap;
}

/* ── CONTACT / ENQUIRY ─────────────────────────────────────── */
.lfw-contact-section {
  background: var(--lfw-midnight);
  padding: 100px 40px;
}
.lfw-contact-inner {
  max-width: 1280px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: 1fr 1.4fr;
  gap: 80px;
  align-items: start;
}
.lfw-contact-label { margin-bottom: 20px; }
.lfw-contact-title {
  font-family: var(--lfw-serif);
  font-size: clamp(2rem, 3vw, 2.8rem);
  font-weight: 600;
  color: var(--lfw-cream);
  line-height: 1.2;
  margin-bottom: 24px;
}
.lfw-contact-title em { font-style: italic; color: var(--lfw-gold); }
.lfw-contact-intro {
  font-size: 0.95rem;
  line-height: 1.75;
  color: var(--lfw-silver);
  margin-bottom: 48px;
}
.lfw-contact-detail {
  display: flex;
  flex-direction: column;
  gap: 24px;
}
.lfw-contact-detail-item {
  display: flex;
  gap: 16px;
  align-items: flex-start;
}
.lfw-contact-detail-icon {
  width: 40px; height: 40px;
  border: 1px solid var(--lfw-border);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1rem;
  flex-shrink: 0;
}
.lfw-contact-detail-text {
  font-size: 0.85rem;
  color: var(--lfw-silver);
  line-height: 1.6;
}
.lfw-contact-detail-text strong {
  display: block;
  color: var(--lfw-cream);
  font-size: 0.78rem;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  margin-bottom: 4px;
}

/* Form */
.lfw-form {
  background: rgba(255,255,255,0.04);
  border: 1px solid var(--lfw-border);
  padding: 52px 48px;
}
.lfw-form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  margin-bottom: 20px;
}
.lfw-form-group { margin-bottom: 20px; }
.lfw-form-label {
  display: block;
  font-size: 0.68rem;
  font-weight: 700;
  letter-spacing: 0.15em;
  text-transform: uppercase;
  color: var(--lfw-silver);
  margin-bottom: 8px;
}
.lfw-form-control {
  width: 100%;
  background: rgba(255,255,255,0.06);
  border: 1px solid rgba(201,168,76,0.2);
  color: var(--lfw-cream);
  padding: 14px 18px;
  font-family: var(--lfw-sans);
  font-size: 0.9rem;
  outline: none;
  transition: border-color 0.25s;
}
.lfw-form-control:focus { border-color: var(--lfw-gold); }
.lfw-form-control::placeholder { color: rgba(138,149,163,0.5); }
select.lfw-form-control option { background: var(--lfw-charcoal); }
textarea.lfw-form-control { min-height: 120px; resize: vertical; }

.lfw-form-privacy {
  font-size: 0.72rem;
  color: var(--lfw-silver);
  line-height: 1.6;
  margin-bottom: 28px;
}
.lfw-form-submit {
  width: 100%;
  padding: 18px;
  background: var(--lfw-gold);
  color: var(--lfw-midnight);
  border: none;
  font-family: var(--lfw-sans);
  font-size: 0.82rem;
  font-weight: 700;
  letter-spacing: 0.18em;
  text-transform: uppercase;
  cursor: pointer;
  transition: background 0.25s, transform 0.2s;
}
.lfw-form-submit:hover { background: var(--lfw-gold-lt); transform: translateY(-2px); }

.lfw-form-success {
  display: none;
  text-align: center;
  padding: 40px;
}
.lfw-form-success .lfw-success-icon {
  font-size: 3rem;
  display: block;
  margin-bottom: 16px;
}
.lfw-form-success p {
  font-family: var(--lfw-serif);
  font-size: 1.2rem;
  font-style: italic;
  color: var(--lfw-cream);
}

@media (max-width: 1100px) {
  .lfw-practices-grid { grid-template-columns: repeat(2, 1fr); }
  .lfw-attorneys-grid { grid-template-columns: repeat(2, 1fr); }
  .lfw-process-steps { grid-template-columns: repeat(2, 1fr); gap: 40px; }
  .lfw-process-steps::before { display: none; }
  .lfw-faq-layout { grid-template-columns: 1fr; }
  .lfw-contact-inner { grid-template-columns: 1fr; }
}
@media (max-width: 768px) {
  .lfw-hero-content { padding: 60px 24px 120px; }
  .lfw-courthouse { opacity: 0.15; }
  .lfw-practices-grid { grid-template-columns: 1fr; }
  .lfw-attorneys-grid { grid-template-columns: 1fr; }
  .lfw-stats-grid { grid-template-columns: repeat(2, 1fr); }
  .lfw-testimonials-grid { grid-template-columns: 1fr; }
  .lfw-form-row { grid-template-columns: 1fr; }
  .lfw-form { padding: 32px 24px; }
  .lfw-hero-credentials { flex-wrap: wrap; }
  .lfw-cred-item { padding: 14px 20px; border-right: none; border-bottom: 1px solid var(--lfw-border); }
}
</style>

<div class="lfw-wrap">

  <!-- ═══ HERO ══════════════════════════════════════════════════ -->
  <section class="lfw-hero">

    <div class="lfw-hero-grid"></div>

    <div class="lfw-hero-quote-mark" style="top:-80px;left:-60px;">"</div>

    <div class="lfw-hero-accent"></div>

    <!-- Courthouse CSS art -->
    <div class="lfw-courthouse" aria-hidden="true">
      <div class="lfw-ch-glow"></div>

      <!-- Steps -->
      <div class="lfw-ch-steps">
        <?php foreach ([560,530,500,470] as $si => $sw): ?>
        <div class="lfw-ch-step" style="width:<?= $sw ?>px;"></div>
        <?php endforeach; ?>
      </div>

      <!-- Main building body -->
      <div class="lfw-ch-base">
        <!-- Windows row top -->
        <?php
        $lfw_win_x = [30, 110, 190, 270, 350, 430];
        foreach ($lfw_win_x as $wi => $wx):
        ?>
        <div class="lfw-ch-window" style="top:40px;left:<?= $wx ?>px;width:44px;height:64px;"></div>
        <?php endforeach; ?>

        <!-- Windows row bottom -->
        <?php foreach ($lfw_win_x as $wi => $wx): ?>
        <div class="lfw-ch-window" style="top:140px;left:<?= $wx ?>px;width:44px;height:64px;"></div>
        <?php endforeach; ?>

        <!-- Grand Door -->
        <div class="lfw-ch-door"></div>
      </div>

      <!-- Entablature -->
      <div class="lfw-ch-entablature"></div>

      <!-- Columns -->
      <div class="lfw-ch-columns">
        <?php for ($ci = 0; $ci < 7; $ci++): ?>
        <div class="lfw-ch-col">
          <span style="left:25%"></span>
          <span style="left:50%"></span>
          <span style="left:75%"></span>
        </div>
        <?php endfor; ?>
      </div>

      <!-- Pediment -->
      <div class="lfw-ch-pediment"></div>

      <!-- Scales of Justice on pediment -->
      <div class="lfw-ch-scales">
        <div class="lfw-ch-scales-arm"></div>
        <div class="lfw-ch-scales-cord left"></div>
        <div class="lfw-ch-scales-cord right"></div>
        <div class="lfw-ch-scales-pan left"></div>
        <div class="lfw-ch-scales-pan right"></div>
      </div>

      <!-- Ambient light rays -->
      <?php for ($ri = 0; $ri < 5; $ri++): ?>
      <div class="lfw-lib-ray" style="height:<?= 200 + $ri * 40 ?>px;right:<?= 150 + $ri * 30 ?>px;opacity:0.<?= 3 - $ri ?>"></div>
      <?php endfor; ?>
    </div>

    <!-- Hero content -->
    <div class="lfw-hero-content">
      <div class="lfw-hero-eyebrow">
        <div class="lfw-hero-eyebrow-line"></div>
        <span class="lfw-hero-eyebrow-text">Ashworth &amp; Partners</span>
      </div>
      <h1>The Right<br><em>Counsel.</em><br>Every Case.</h1>
      <p class="lfw-hero-sub">London's premier litigation &amp; advisory practice</p>
      <p class="lfw-hero-desc">For 38 years, Ashworth &amp; Partners has delivered authoritative legal counsel across the full spectrum of commercial, property and private client law. Our reputation is built on outcomes — and the relationships that endure beyond them.</p>
      <div class="lfw-hero-ctas">
        <a href="#contact" class="lfw-btn-primary">Free Consultation ⚖️</a>
        <a href="#practices" class="lfw-btn-outline">Our Practice Areas</a>
      </div>
    </div>

    <!-- Credential bar -->
    <div class="lfw-hero-credentials">
      <div class="lfw-cred-item">
        <span class="lfw-cred-icon">🏛️</span>
        <span class="lfw-cred-text"><strong>Chambers UK 2024</strong>Band 1 — Litigation</span>
      </div>
      <div class="lfw-cred-item">
        <span class="lfw-cred-icon">📋</span>
        <span class="lfw-cred-text"><strong>Legal 500 2024</strong>Tier 1 — Corporate M&amp;A</span>
      </div>
      <div class="lfw-cred-item">
        <span class="lfw-cred-icon">⚖️</span>
        <span class="lfw-cred-text"><strong>No-Win No-Fee</strong>Selected Litigation Matters</span>
      </div>
      <div class="lfw-cred-item">
        <span class="lfw-cred-icon">🔒</span>
        <span class="lfw-cred-text"><strong>Strict Confidentiality</strong>All Matters Protected</span>
      </div>
    </div>

  </section>

  <!-- ═══ PRACTICE AREAS ════════════════════════════════════════ -->
  <section id="practices" style="background:var(--lfw-cream);">
    <div class="lfw-section">
      <div class="lfw-section-label lfw-reveal">
        <div class="lfw-section-label-line"></div>
        <span class="lfw-section-label-text">What We Do</span>
      </div>
      <h2 class="lfw-section-title lfw-reveal">Practice <em>Areas</em></h2>
      <p class="lfw-section-intro lfw-reveal">Our practice covers the full breadth of commercial and private legal needs. Whatever the matter, you will be represented by experts who know your sector and your stakes.</p>
    </div>
    <div class="lfw-practices-grid">
      <?php foreach ($lfw_practices as $pi => $pr): ?>
      <div class="lfw-practice-card lfw-reveal" style="transition-delay:<?= $pi * 0.08 ?>s">
        <span class="lfw-practice-icon"><?= $pr['icon'] ?></span>
        <div class="lfw-practice-title"><?= esc_html($pr['title']) ?></div>
        <p class="lfw-practice-desc"><?= esc_html($pr['desc']) ?></p>
        <ul class="lfw-practice-sub">
          <?php foreach ($pr['sub'] as $sub): ?>
          <li><?= esc_html($sub) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- ═══ ATTORNEYS ═════════════════════════════════════════════ -->
  <section class="lfw-attorneys-section lfw-section-full">
    <div class="lfw-attorneys-inner">
      <div class="lfw-section-label lfw-reveal">
        <div class="lfw-section-label-line"></div>
        <span class="lfw-section-label-text" style="color:var(--lfw-gold)">Our Team</span>
      </div>
      <h2 class="lfw-section-title lfw-reveal" style="color:var(--lfw-cream)">Exceptional <em>Attorneys</em></h2>
      <p class="lfw-section-intro lfw-reveal" style="color:var(--lfw-silver)">Each member of our team is a specialist in their field — called to the Bar or admitted as a solicitor from the UK's finest institutions, with track records that speak for themselves.</p>
      <div class="lfw-attorneys-grid">
        <?php foreach ($lfw_attorneys as $ai => $att): ?>
        <div class="lfw-attorney-card lfw-reveal" style="transition-delay:<?= $ai * 0.1 ?>s">
          <!-- CSS Portrait -->
          <div class="lfw-atty-portrait">
            <div class="lfw-atty-portrait-bg" style="background:<?= esc_attr($att['color']) ?>;"></div>
            <div class="lfw-atty-head"></div>
            <div class="lfw-atty-suit" style="background:<?= esc_attr($att['color']) ?>;"></div>
            <div class="lfw-atty-lapel-l"></div>
            <div class="lfw-atty-lapel-r"></div>
            <div class="lfw-atty-tie" style="background:<?= $ai % 2 === 0 ? 'var(--lfw-gold)' : '#8b0000' ?>;"></div>
          </div>
          <div class="lfw-atty-name"><?= esc_html($att['name']) ?></div>
          <div class="lfw-atty-role"><?= esc_html($att['role']) ?></div>
          <div class="lfw-atty-detail">
            <?= $att['years'] ?> years at the Bar<br>
            <?= esc_html($att['called']) ?>
          </div>
          <div class="lfw-atty-cases">
            <span class="lfw-atty-cases-num" data-target="<?= $att['cases'] ?>" data-suffix="+"><?= $att['cases'] ?>+</span>
            <span class="lfw-atty-cases-label">cases<br>resolved</span>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ═══ PROCESS ═══════════════════════════════════════════════ -->
  <section class="lfw-process-section lfw-section-full">
    <div class="lfw-section" style="padding-bottom:0">
      <div class="lfw-section-label lfw-reveal">
        <div class="lfw-section-label-line"></div>
        <span class="lfw-section-label-text">How We Work</span>
      </div>
      <h2 class="lfw-section-title lfw-reveal">From First Call to <em>Resolution</em></h2>
      <p class="lfw-section-intro lfw-reveal">Our structured approach ensures clarity, accountability and a relentless focus on your outcome at every stage of the matter.</p>
    </div>
    <div class="lfw-section">
      <div class="lfw-process-steps">
        <?php foreach ($lfw_steps as $pi => $step): ?>
        <div class="lfw-process-step lfw-reveal" style="transition-delay:<?= $pi * 0.12 ?>s">
          <div class="lfw-process-circle"><?= esc_html($step['num']) ?></div>
          <div class="lfw-process-title"><?= esc_html($step['title']) ?></div>
          <p class="lfw-process-desc"><?= esc_html($step['desc']) ?></p>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ═══ STATS ═════════════════════════════════════════════════ -->
  <section class="lfw-stats-section">
    <div class="lfw-stats-grid">
      <?php foreach ($lfw_stats as $si => $stat): ?>
      <div class="lfw-stat-item lfw-reveal" style="transition-delay:<?= $si * 0.1 ?>s">
        <span class="lfw-stat-val" data-target="<?= $stat['val'] ?>" data-suffix="<?= esc_attr($stat['suffix']) ?>">
          <?= esc_html($stat['val'] . $stat['suffix']) ?>
        </span>
        <span class="lfw-stat-label"><?= esc_html($stat['label']) ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- ═══ TESTIMONIALS ══════════════════════════════════════════ -->
  <section class="lfw-testimonials-section lfw-section-full">
    <div class="lfw-section" style="padding-bottom:0">
      <div class="lfw-section-label lfw-reveal">
        <div class="lfw-section-label-line"></div>
        <span class="lfw-section-label-text">Client Voices</span>
      </div>
      <h2 class="lfw-section-title lfw-reveal">What Our <em>Clients</em> Say</h2>
    </div>
    <div class="lfw-section">
      <div class="lfw-testimonials-grid">
        <?php foreach ($lfw_testimonials as $ti => $tm): ?>
        <div class="lfw-testimonial-card lfw-reveal" style="transition-delay:<?= $ti * 0.12 ?>s">
          <span class="lfw-testimonial-quote-mark">"</span>
          <p class="lfw-testimonial-text"><?= esc_html($tm['quote']) ?></p>
          <div class="lfw-testimonial-author"><?= esc_html($tm['author']) ?></div>
          <div class="lfw-testimonial-sector"><?= esc_html($tm['sector']) ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ═══ AWARDS ════════════════════════════════════════════════ -->
  <section class="lfw-awards-section lfw-section-full">
    <div class="lfw-section">
      <div class="lfw-section-label lfw-reveal">
        <div class="lfw-section-label-line"></div>
        <span class="lfw-section-label-text">Recognition</span>
      </div>
      <h2 class="lfw-section-title lfw-reveal">Awards &amp; <em>Rankings</em></h2>
      <p class="lfw-section-intro lfw-reveal">Independent recognition from the leading legal directories and industry bodies confirms what our clients already know.</p>
      <table class="lfw-awards-table">
        <tbody>
          <?php foreach ($lfw_awards as $ai => $aw): ?>
          <tr class="lfw-reveal" style="transition-delay:<?= $ai * 0.08 ?>s">
            <td class="lfw-award-year"><?= esc_html($aw['year']) ?></td>
            <td class="lfw-award-name"><?= esc_html($aw['award']) ?></td>
            <td class="lfw-award-icon">🏆</td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </section>

  <!-- ═══ FAQ ═══════════════════════════════════════════════════ -->
  <section class="lfw-faq-section lfw-section-full">
    <div class="lfw-section" style="padding-bottom:0">
      <div class="lfw-section-label lfw-reveal">
        <div class="lfw-section-label-line"></div>
        <span class="lfw-section-label-text">Common Questions</span>
      </div>
      <h2 class="lfw-section-title lfw-reveal">Frequently Asked <em>Questions</em></h2>
    </div>
    <div class="lfw-section">
      <div class="lfw-faq-layout">

        <!-- FAQ accordion -->
        <div class="lfw-faq-list">
          <?php foreach ($lfw_faqs as $fi => $faq): ?>
          <div class="lfw-faq-item lfw-reveal" style="transition-delay:<?= $fi * 0.08 ?>s">
            <button class="lfw-faq-trigger" aria-expanded="false">
              <span class="lfw-faq-q"><?= esc_html($faq['q']) ?></span>
              <span class="lfw-faq-icon" aria-hidden="true">+</span>
            </button>
            <div class="lfw-faq-body" role="region">
              <div class="lfw-faq-body-inner"><?= esc_html($faq['a']) ?></div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>

        <!-- CSS Law Library illustration -->
        <div class="lfw-faq-library lfw-reveal" aria-hidden="true">
          <div class="lfw-lib-wall"></div>

          <!-- Light rays from window -->
          <?php for ($ri = 0; $ri < 4; $ri++): ?>
          <div class="lfw-lib-ray" style="
            position:absolute;
            top:<?= 24 + $ri * 10 ?>px;
            right:<?= 60 + $ri * 15 ?>px;
            width:1px;
            height:<?= 180 - $ri * 20 ?>px;
            background:linear-gradient(180deg, rgba(201,168,76,0.25), transparent);
            transform:rotate(<?= 10 + $ri * 5 ?>deg);
            transform-origin:top center;
          "></div>
          <?php endfor; ?>

          <div class="lfw-lib-window"></div>
          <div class="lfw-lib-portrait"></div>

          <!-- Bookcase -->
          <div class="lfw-lib-bookcase">
            <?php
            foreach ($lfw_shelf_y as $si => $sy):
              // shelf plank
              echo '<div class="lfw-lib-shelf" style="top:'.($sy + 72).'px;"></div>';
              // books
              $x2 = 12;
              $cnt2 = rand(7,10);
              for ($bi2 = 0; $bi2 < $cnt2; $bi2++):
                $bw2 = $lfw_book_widths[$bi2 % count($lfw_book_widths)];
                $bc2 = $lfw_book_colors[$bi2 % count($lfw_book_colors)];
                $bh2 = rand(52, 70);
                $tilt2 = ($bi2 % 6 === 5) ? 'transform:rotate(-10deg);transform-origin:bottom center;' : '';
                if ($x2 + $bw2 > 280) break;
                echo "<div style='position:absolute;bottom:".($sy == end($lfw_shelf_y) ? 6 : 0)."px;top:".($sy + 6)."px;left:{$x2}px;width:{$bw2}px;height:{$bh2}px;background:{$bc2};border-right:2px solid rgba(0,0,0,0.2);{$tilt2}'></div>";
                $x2 += $bw2 + 2;
              endfor;
            endforeach;
            ?>
          </div>

          <!-- Desk -->
          <div class="lfw-lib-desk"></div>
          <div class="lfw-lib-desk-leg"></div>
          <div class="lfw-lib-desk-leg r"></div>
          <div class="lfw-lib-lamp"></div>
          <div class="lfw-lib-lamp-shade"></div>
          <div class="lfw-lib-lamp-glow"></div>
          <div class="lfw-lib-tome"></div>

          <!-- Desk scales -->
          <div class="lfw-lib-scales">
            <div class="lfw-lib-scales-arm"></div>
            <div class="lfw-lib-scales-pan l"></div>
            <div class="lfw-lib-scales-pan r"></div>
          </div>

          <div class="lfw-lib-wainscot"></div>
          <div class="lfw-lib-floor"></div>

          <p class="lfw-lib-caption"><em>Ashworth &amp; Partners — Est. 1988</em></p>
        </div>

      </div>
    </div>
  </section>

  <!-- ═══ CONTACT ═══════════════════════════════════════════════ -->
  <section id="contact" class="lfw-contact-section">
    <div class="lfw-contact-inner">

      <!-- Left: contact info -->
      <div>
        <div class="lfw-contact-label">
          <div class="lfw-section-label lfw-reveal">
            <div class="lfw-section-label-line"></div>
            <span class="lfw-section-label-text">Get In Touch</span>
          </div>
        </div>
        <h2 class="lfw-contact-title lfw-reveal">Book Your Free <em>Consultation</em></h2>
        <p class="lfw-contact-intro lfw-reveal">Every legal matter begins with a conversation. Tell us your situation — confidentially, without obligation — and we will advise you honestly on your options and the strength of your position.</p>
        <div class="lfw-contact-detail lfw-reveal">
          <div class="lfw-contact-detail-item">
            <div class="lfw-contact-detail-icon">📍</div>
            <div class="lfw-contact-detail-text">
              <strong>Address</strong>
              1 Temple Square, London EC4Y 8BT
            </div>
          </div>
          <div class="lfw-contact-detail-item">
            <div class="lfw-contact-detail-icon">📞</div>
            <div class="lfw-contact-detail-text">
              <strong>Telephone</strong>
              +44 (0)20 7123 4567
            </div>
          </div>
          <div class="lfw-contact-detail-item">
            <div class="lfw-contact-detail-icon">✉️</div>
            <div class="lfw-contact-detail-text">
              <strong>Email</strong>
              enquiries@ashworthpartners.co.uk
            </div>
          </div>
          <div class="lfw-contact-detail-item">
            <div class="lfw-contact-detail-icon">🕐</div>
            <div class="lfw-contact-detail-text">
              <strong>Office Hours</strong>
              Monday – Friday: 8:30am – 6:30pm<br>
              Urgent matters: 24/7 on-call service
            </div>
          </div>
        </div>
      </div>

      <!-- Right: enquiry form -->
      <div class="lfw-reveal">
        <div class="lfw-form" id="lfw-contact-form-wrap">
          <form id="lfw-contact-form" novalidate>
            <?php wp_nonce_field('tf_lfw_enquiry', 'tf_lfw_nonce'); ?>

            <div class="lfw-form-row">
              <div class="lfw-form-group">
                <label class="lfw-form-label" for="lfw-first-name">First Name <span style="color:var(--lfw-gold)">*</span></label>
                <input type="text" id="lfw-first-name" name="first_name" class="lfw-form-control" placeholder="Margaret" required>
              </div>
              <div class="lfw-form-group">
                <label class="lfw-form-label" for="lfw-last-name">Last Name <span style="color:var(--lfw-gold)">*</span></label>
                <input type="text" id="lfw-last-name" name="last_name" class="lfw-form-control" placeholder="Ashworth" required>
              </div>
            </div>

            <div class="lfw-form-row">
              <div class="lfw-form-group">
                <label class="lfw-form-label" for="lfw-email">Email Address <span style="color:var(--lfw-gold)">*</span></label>
                <input type="email" id="lfw-email" name="email" class="lfw-form-control" placeholder="you@company.com" required>
              </div>
              <div class="lfw-form-group">
                <label class="lfw-form-label" for="lfw-phone">Telephone</label>
                <input type="tel" id="lfw-phone" name="phone" class="lfw-form-control" placeholder="+44 7000 000000">
              </div>
            </div>

            <div class="lfw-form-group">
              <label class="lfw-form-label" for="lfw-practice">Area of Law <span style="color:var(--lfw-gold)">*</span></label>
              <select id="lfw-practice" name="practice" class="lfw-form-control" required>
                <option value="">Select practice area…</option>
                <?php foreach ($lfw_practices as $pr): ?>
                <option value="<?= esc_attr($pr['title']) ?>"><?= esc_html($pr['title']) ?></option>
                <?php endforeach; ?>
                <option value="Other">Other / Not Sure</option>
              </select>
            </div>

            <div class="lfw-form-row">
              <div class="lfw-form-group">
                <label class="lfw-form-label" for="lfw-urgency">Urgency</label>
                <select id="lfw-urgency" name="urgency" class="lfw-form-control">
                  <option value="">Select urgency…</option>
                  <option>Immediate — within 24 hours</option>
                  <option>Urgent — within 1 week</option>
                  <option>Standard — within 1 month</option>
                  <option>Planning ahead</option>
                </select>
              </div>
              <div class="lfw-form-group">
                <label class="lfw-form-label" for="lfw-client-type">Client Type</label>
                <select id="lfw-client-type" name="client_type" class="lfw-form-control">
                  <option value="">Select…</option>
                  <option>Business / Corporate</option>
                  <option>Individual / Personal</option>
                  <option>Public Sector</option>
                  <option>Non-Profit / Charity</option>
                </select>
              </div>
            </div>

            <div class="lfw-form-group">
              <label class="lfw-form-label" for="lfw-matter">Brief Description of Your Matter <span style="color:var(--lfw-gold)">*</span></label>
              <textarea id="lfw-matter" name="matter" class="lfw-form-control" placeholder="Please describe your situation briefly. All information is treated in the strictest confidence." required></textarea>
            </div>

            <p class="lfw-form-privacy">Your enquiry is protected by legal professional privilege. We will never share your information with third parties. By submitting this form you agree to our <a href="#" style="color:var(--lfw-gold)">Privacy Policy</a>.</p>

            <button type="submit" class="lfw-form-submit">Request Free Consultation ⚖️</button>
          </form>

          <div class="lfw-form-success" id="lfw-form-success">
            <span class="lfw-success-icon">⚖️</span>
            <p>Thank you. A member of our team will be in contact within one business day to arrange your consultation.</p>
          </div>
        </div>
      </div>

    </div>
  </section>

</div><!-- .lfw-wrap -->

<script>
(function () {
  'use strict';

  /* ── Scroll Reveal ───────────────────────────────────────── */
  const revealObs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('visible'); revealObs.unobserve(e.target); }
    });
  }, { threshold: 0.12 });
  document.querySelectorAll('.lfw-reveal').forEach(el => revealObs.observe(el));

  /* ── Animated Counters ───────────────────────────────────── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  const counterObs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      counterObs.unobserve(e.target);
      const el = e.target;
      const target = parseInt(el.dataset.target, 10);
      const suffix = el.dataset.suffix || '';
      const dur = 1800;
      const start = performance.now();
      (function tick(now) {
        const p = Math.min((now - start) / dur, 1);
        const v = Math.round(easeOut(p) * target);
        el.textContent = v + suffix;
        if (p < 1) requestAnimationFrame(tick);
      })(start);
    });
  }, { threshold: 0.5 });
  document.querySelectorAll('[data-target]').forEach(el => counterObs.observe(el));

  /* ── FAQ Accordion ───────────────────────────────────────── */
  document.querySelectorAll('.lfw-faq-trigger').forEach(btn => {
    btn.addEventListener('click', function () {
      const item = this.closest('.lfw-faq-item');
      const body = item.querySelector('.lfw-faq-body');
      const isOpen = item.classList.contains('open');

      // close all
      document.querySelectorAll('.lfw-faq-item').forEach(i => {
        i.classList.remove('open');
        i.querySelector('.lfw-faq-trigger').setAttribute('aria-expanded', 'false');
        i.querySelector('.lfw-faq-body').style.maxHeight = '0';
      });

      if (!isOpen) {
        item.classList.add('open');
        this.setAttribute('aria-expanded', 'true');
        body.style.maxHeight = body.scrollHeight + 'px';
      }
    });
  });

  /* ── Enquiry Form ────────────────────────────────────────── */
  const form = document.getElementById('lfw-contact-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      const btn = this.querySelector('.lfw-form-submit');
      btn.textContent = 'Sending…';
      btn.disabled = true;
      setTimeout(() => {
        document.getElementById('lfw-contact-form').style.display = 'none';
        document.getElementById('lfw-form-success').style.display = 'block';
      }, 900);
    });
  }
})();
</script>

<?php get_footer(); ?>
