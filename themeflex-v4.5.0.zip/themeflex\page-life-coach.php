<?php
/**
 * Template Name: Life Coach — Luminary
 *
 * Premium life & executive coaching page template.
 * Palette  : deep plum #3A1F4A / warm gold #C9963A / ivory #FAF8F3 / blush #F2E8E0 / slate #4A5568
 * Fonts    : Cormorant Garamond (headings) + DM Sans (body)
 * Namespace: --lc-*
 *
 * @package ThemeFlex
 */

if ( ! defined( 'ABSPATH' ) ) exit;

srand( crc32( get_the_permalink() ) );

/* ── helpers ── */
$site   = get_bloginfo( 'name' ) ?: 'Luminary Coaching';
$phone  = get_theme_mod( 'tf_phone', '+44 20 7946 0822' );
$email  = get_theme_mod( 'tf_email', 'hello@luminarycoaching.co.uk' );
$addr   = get_theme_mod( 'tf_address', 'Mayfair, London W1K' );

/* ── floating orbs data ── */
$orbs = [
  ['🌟','top:8%','left:5%'],['✨','top:15%','left:88%'],['🌿','top:70%','left:3%'],
  ['💎','top:80%','left:90%'],['🕊️','top:30%','left:92%'],['🌙','top:55%','left:7%'],
  ['⭐','top:42%','left:85%'],['🌺','top:90%','left:15%'],['🦋','top:20%','left:50%'],
  ['🌸','top:65%','left:60%'],['✦','top:10%','left:72%'],['❋','top:85%','left:45%'],
];

/* ── transformation pillars ── */
$pillars = [
  [ 'icon' => '🧭', 'title' => 'Clarity & Direction',   'desc' => 'Cut through the noise. Define what success truly means to you and chart an unwavering path toward it.' ],
  [ 'icon' => '🔥', 'title' => 'Confidence & Presence', 'desc' => 'Step into rooms with magnetic authority. Own your story, your voice, and your seat at the table.' ],
  [ 'icon' => '⚡', 'title' => 'Peak Performance',       'desc' => 'Architect habits and routines that sustain excellence — without burning out or compromising who you are.' ],
  [ 'icon' => '🌱', 'title' => 'Career Transition',      'desc' => 'Pivot with purpose. Whether climbing, pivoting, or launching — move strategically, not out of fear.' ],
  [ 'icon' => '🤝', 'title' => 'Executive Leadership',   'desc' => 'Lead teams with empathy and edge. Build cultures that perform and people who choose to stay.' ],
  [ 'icon' => '⚖️', 'title' => 'Life–Work Integration',  'desc' => 'Redefine balance. Create a life where ambition and fulfilment are not opposites but partners.' ],
];

/* ── process steps ── */
$steps = [
  [ 'num' => '01', 'title' => 'Discovery Call',       'desc' => 'A complimentary 45-minute conversation to explore your vision, challenges, and whether we\'re the right fit.' ],
  [ 'num' => '02', 'title' => 'Coaching Blueprint',   'desc' => 'Together we design a bespoke programme — goals, cadence, tools — built around your life, not a template.' ],
  [ 'num' => '03', 'title' => 'Deep-Dive Sessions',   'desc' => 'Weekly or bi-weekly 60-minute sessions via video or in-person, with voice notes between for continuity.' ],
  [ 'num' => '04', 'title' => 'Integration & Action', 'desc' => 'Structured assignments embed insights into daily decisions. Real change happens between sessions.' ],
  [ 'num' => '05', 'title' => 'Evolution & Review',   'desc' => 'Monthly progress reviews refine focus. Growth is measured, celebrated, and built upon.' ],
];

/* ── packages ── */
$packages = [
  [
    'name'     => 'Clarity Sprint',
    'price'    => '£1,200',
    'period'   => 'one-time',
    'featured' => false,
    'features' => [ '4 × 60-min sessions', 'Goal clarity framework', 'Email support (2 weeks)', 'Session recordings', 'Action blueprint' ],
  ],
  [
    'name'     => 'Transformation',
    'price'    => '£2,800',
    'period'   => 'per 3 months',
    'featured' => true,
    'features' => [ '12 × 60-min sessions', 'Full coaching blueprint', 'WhatsApp voice access', 'Personality profiling', 'Monthly reviews', 'Resource library' ],
  ],
  [
    'name'     => 'Executive Mastery',
    'price'    => 'POA',
    'period'   => 'bespoke',
    'featured' => false,
    'features' => [ 'Unlimited sessions', 'Board & stakeholder prep', 'Crisis coaching (24hr)', '360° leadership review', 'Retreat days', 'Lifetime alumni access' ],
  ],
];

/* ── testimonials ── */
$testimonials = [
  [
    'quote'  => 'Within three months I had the clarity, the confidence, and the strategy to walk away from a career that was crushing me — and launch the business I\'d dreamed about for years. Luminary didn\'t just coach me; they changed my life.',
    'name'   => 'Marcus W.',
    'role'   => 'Ex-Investment Director → Founder, MW Ventures',
    'stars'  => 5,
  ],
  [
    'quote'  => 'I\'d read every leadership book. I\'d done the MBA. What I hadn\'t done was look inward. These sessions cracked open a version of me my team actually wants to follow. My 360 reviews went from average to exceptional in one cycle.',
    'name'   => 'Priya S.',
    'role'   => 'Chief People Officer, FinTech Scale-up',
    'stars'  => 5,
  ],
  [
    'quote'  => 'The ROI is impossible to calculate. A promotion I\'d been overlooked for twice, a salary increase of 40%, and for the first time in years — actual peace. I recommend Luminary to every high-achiever I know who\'s quietly struggling.',
    'name'   => 'James H.',
    'role'   => 'VP Operations, FTSE 100 Company',
    'stars'  => 5,
  ],
];

/* ── credentials ── */
$creds = [
  [ 'abbr' => 'ACC',     'body' => 'ICF Associate Certified Coach' ],
  [ 'abbr' => 'PCC',     'body' => 'ICF Professional Certified Coach' ],
  [ 'abbr' => 'MBA',     'body' => 'London Business School' ],
  [ 'abbr' => 'EMCC',    'body' => 'European Mentoring & Coaching Council' ],
];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;0,700;1,400;1,600&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════
   LUMINARY COACHING — CSS CUSTOM PROPERTIES
   ═══════════════════════════════════════════ */
:root {
  --lc-plum:    #3A1F4A;
  --lc-plum2:   #2A1235;
  --lc-gold:    #C9963A;
  --lc-gold2:   #E8B84B;
  --lc-ivory:   #FAF8F3;
  --lc-blush:   #F2E8E0;
  --lc-slate:   #4A5568;
  --lc-text:    #2D2D2D;
  --lc-muted:   #6B7280;
  --lc-white:   #FFFFFF;
  --lc-rad:     12px;
  --lc-rad-lg:  20px;
  --lc-shadow:  0 4px 24px rgba(58,31,74,.10);
  --lc-shadow2: 0 12px 48px rgba(58,31,74,.18);
  --lc-font-h:  'Cormorant Garamond', Georgia, serif;
  --lc-font-b:  'DM Sans', system-ui, sans-serif;
  --lc-ease:    cubic-bezier(.4,0,.2,1);
}

/* ── reset ── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: var(--lc-font-b); color: var(--lc-text); background: var(--lc-ivory); overflow-x: hidden; }
img  { max-width: 100%; display: block; }
a    { color: inherit; text-decoration: none; }

/* ── layout ── */
.lc-wrap  { max-width: 1200px; margin: 0 auto; padding: 0 24px; }
.lc-sec   { padding: 100px 0; }
.lc-sec--alt { background: var(--lc-blush); }
.lc-sec--dark { background: var(--lc-plum); color: var(--lc-ivory); }
.lc-sec--plum2 { background: var(--lc-plum2); color: var(--lc-ivory); }
.lc-sec--gold { background: linear-gradient(135deg,var(--lc-gold) 0%,var(--lc-gold2) 100%); color: var(--lc-plum); }

/* ── section headings ── */
.lc-eyebrow {
  display: inline-block;
  font-family: var(--lc-font-b);
  font-size: .75rem;
  font-weight: 600;
  letter-spacing: .15em;
  text-transform: uppercase;
  color: var(--lc-gold);
  margin-bottom: 14px;
}
.lc-sec--dark .lc-eyebrow,
.lc-sec--plum2 .lc-eyebrow { color: var(--lc-gold2); }
.lc-sec--gold .lc-eyebrow  { color: var(--lc-plum); opacity: .7; }

.lc-h2 {
  font-family: var(--lc-font-h);
  font-size: clamp(2rem, 4vw, 3.2rem);
  font-weight: 600;
  line-height: 1.15;
  margin-bottom: 20px;
}
.lc-lead {
  font-size: 1.1rem;
  line-height: 1.75;
  color: var(--lc-muted);
  max-width: 640px;
}
.lc-sec--dark .lc-lead,
.lc-sec--plum2 .lc-lead { color: rgba(250,248,243,.7); }
.lc-sec--gold .lc-lead   { color: var(--lc-plum); opacity: .75; }
.lc-center { text-align: center; }
.lc-center .lc-lead { margin: 0 auto; }

/* ════════════════════════════════
   NAVBAR
   ════════════════════════════════ */
.lc-nav {
  position: fixed; top: 0; left: 0; width: 100%; z-index: 1000;
  background: rgba(58,31,74,.96);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  border-bottom: 1px solid rgba(201,150,58,.25);
}
.lc-nav__inner {
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 24px; height: 72px; max-width: 1200px; margin: 0 auto;
}
.lc-nav__logo {
  font-family: var(--lc-font-h);
  font-size: 1.5rem;
  font-weight: 700;
  color: var(--lc-ivory);
  letter-spacing: .02em;
}
.lc-nav__logo span { color: var(--lc-gold); }
.lc-nav__links { display: flex; gap: 32px; }
.lc-nav__links a {
  font-size: .85rem; font-weight: 500; letter-spacing: .04em;
  color: rgba(250,248,243,.8);
  transition: color .25s;
}
.lc-nav__links a:hover { color: var(--lc-gold2); }
.lc-nav__cta {
  background: var(--lc-gold);
  color: var(--lc-plum) !important;
  padding: 10px 22px;
  border-radius: 6px;
  font-weight: 600 !important;
  transition: background .25s !important;
}
.lc-nav__cta:hover { background: var(--lc-gold2) !important; }

/* ════════════════════════════════
   HERO
   ════════════════════════════════ */
.lc-hero {
  position: relative;
  height: 100vh; min-height: 700px;
  background: linear-gradient(145deg, var(--lc-plum) 0%, #5A2F72 40%, #3A1F4A 70%, #1A0A28 100%);
  overflow: hidden;
  display: flex; align-items: center;
}

/* ── starfield ── */
.lc-hero__stars {
  position: absolute; inset: 0;
  background-image:
    radial-gradient(1px 1px at 10% 15%, rgba(255,255,255,.6) 0%, transparent 100%),
    radial-gradient(1px 1px at 20% 40%, rgba(255,255,255,.4) 0%, transparent 100%),
    radial-gradient(1.5px 1.5px at 35% 10%, rgba(255,255,255,.7) 0%, transparent 100%),
    radial-gradient(1px 1px at 50% 25%, rgba(255,255,255,.5) 0%, transparent 100%),
    radial-gradient(1px 1px at 65% 8%, rgba(255,255,255,.6) 0%, transparent 100%),
    radial-gradient(1.5px 1.5px at 75% 35%, rgba(255,255,255,.4) 0%, transparent 100%),
    radial-gradient(1px 1px at 85% 18%, rgba(255,255,255,.7) 0%, transparent 100%),
    radial-gradient(1px 1px at 90% 55%, rgba(255,255,255,.5) 0%, transparent 100%),
    radial-gradient(1.5px 1.5px at 15% 70%, rgba(255,255,255,.6) 0%, transparent 100%),
    radial-gradient(1px 1px at 30% 85%, rgba(255,255,255,.4) 0%, transparent 100%),
    radial-gradient(1px 1px at 45% 75%, rgba(255,255,255,.5) 0%, transparent 100%),
    radial-gradient(1.5px 1.5px at 60% 65%, rgba(255,255,255,.6) 0%, transparent 100%),
    radial-gradient(1px 1px at 70% 80%, rgba(255,255,255,.7) 0%, transparent 100%),
    radial-gradient(1px 1px at 80% 72%, rgba(255,255,255,.4) 0%, transparent 100%),
    radial-gradient(1.5px 1.5px at 92% 88%, rgba(255,255,255,.5) 0%, transparent 100%),
    radial-gradient(2px 2px at 5% 50%, rgba(201,150,58,.4) 0%, transparent 100%),
    radial-gradient(2px 2px at 95% 30%, rgba(201,150,58,.3) 0%, transparent 100%),
    radial-gradient(2px 2px at 55% 92%, rgba(201,150,58,.4) 0%, transparent 100%);
}

/* ── radial glow behind scene ── */
.lc-hero__glow {
  position: absolute;
  width: 700px; height: 700px;
  top: 50%; left: 55%;
  transform: translate(-50%,-50%);
  background: radial-gradient(circle, rgba(201,150,58,.18) 0%, rgba(90,47,114,.12) 40%, transparent 70%);
  border-radius: 50%;
  pointer-events: none;
}

/* ── CSS coaching room scene ── */
.lc-hero__scene {
  position: absolute;
  right: 0; top: 0; bottom: 0;
  width: 55%;
  overflow: hidden;
}

/* floor */
.lc-scene__floor {
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 38%;
  background: linear-gradient(180deg, #2A1840 0%, #1E1030 100%);
  border-top: 2px solid rgba(201,150,58,.2);
}
/* floor rug */
.lc-scene__rug {
  position: absolute;
  bottom: 8%;
  left: 50%; transform: translateX(-50%);
  width: 70%; height: 22%;
  background: radial-gradient(ellipse at center, rgba(90,47,114,.6) 0%, rgba(58,31,74,.4) 60%, transparent 100%);
  border-radius: 50%;
}

/* wall */
.lc-scene__wall {
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 62%;
  background: linear-gradient(180deg, #2D1545 0%, #3A1F4A 100%);
}

/* large arched window */
.lc-scene__window {
  position: absolute;
  top: 4%;
  left: 8%;
  width: 35%; height: 54%;
  background: linear-gradient(180deg, #0A0418 0%, #1A0A28 60%, #120820 100%);
  border: 3px solid rgba(201,150,58,.35);
  border-radius: 50% 50% 0 0 / 30% 30% 0 0;
  overflow: hidden;
}
/* moon through window */
.lc-scene__window::before {
  content: '';
  position: absolute;
  top: 10%; left: 50%; transform: translateX(-50%);
  width: 40%; height: 40%;
  background: radial-gradient(circle, rgba(232,184,75,.9) 0%, rgba(201,150,58,.4) 50%, transparent 100%);
  border-radius: 50%;
}
/* city lights */
.lc-scene__window::after {
  content: '';
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 40%;
  background-image:
    radial-gradient(2px 6px at 15% 80%, rgba(255,220,100,.7) 0%, transparent 100%),
    radial-gradient(2px 8px at 25% 70%, rgba(201,150,58,.5) 0%, transparent 100%),
    radial-gradient(2px 4px at 40% 85%, rgba(255,220,100,.6) 0%, transparent 100%),
    radial-gradient(2px 10px at 55% 65%, rgba(201,150,58,.4) 0%, transparent 100%),
    radial-gradient(2px 6px at 70% 75%, rgba(255,220,100,.7) 0%, transparent 100%),
    radial-gradient(2px 5px at 82% 80%, rgba(201,150,58,.5) 0%, transparent 100%),
    radial-gradient(2px 7px at 90% 68%, rgba(255,220,100,.6) 0%, transparent 100%);
}
/* window curtain left */
.lc-scene__curtain-l {
  position: absolute;
  top: 0; left: 3%;
  width: 12%; height: 58%;
  background: linear-gradient(180deg, #4A2060 0%, #3A1F4A 100%);
  transform-origin: top center;
  transform: perspective(200px) rotateY(8deg);
}
.lc-scene__curtain-r {
  position: absolute;
  top: 0; right: 3%;
  width: 12%; height: 58%;
  background: linear-gradient(180deg, #4A2060 0%, #3A1F4A 100%);
  transform-origin: top center;
  transform: perspective(200px) rotateY(-8deg);
}
/* curtain tieback */
.lc-scene__curtain-l::after,
.lc-scene__curtain-r::after {
  content: '';
  position: absolute;
  top: 55%; left: 50%; transform: translate(-50%,-50%);
  width: 14px; height: 14px;
  background: var(--lc-gold);
  border-radius: 50%;
}

/* bookshelf right side */
.lc-scene__shelf {
  position: absolute;
  top: 6%; right: 5%;
  width: 22%; height: 55%;
  background: #1E0F2E;
  border: 2px solid rgba(201,150,58,.2);
  border-radius: 4px 4px 0 0;
}
/* shelf boards */
.lc-scene__shelf::before {
  content: '';
  position: absolute;
  left: 0; right: 0;
  top: 32%; height: 3px;
  background: rgba(201,150,58,.3);
  box-shadow: 0 calc(35%) 0 rgba(201,150,58,.3);
}

/* coach figure */
.lc-scene__coach {
  position: absolute;
  bottom: 36%; left: 42%;
  width: 80px; height: 130px;
}
/* body */
.lc-scene__coach-body {
  position: absolute;
  bottom: 0; left: 50%; transform: translateX(-50%);
  width: 46px; height: 80px;
  background: var(--lc-gold);
  border-radius: 4px 4px 0 0;
}
/* head */
.lc-scene__coach-body::before {
  content: '';
  position: absolute;
  top: -42px; left: 50%; transform: translateX(-50%);
  width: 34px; height: 34px;
  background: #C8956A;
  border-radius: 50%;
}
/* hair */
.lc-scene__coach-body::after {
  content: '';
  position: absolute;
  top: -48px; left: 50%; transform: translateX(-50%);
  width: 36px; height: 20px;
  background: #2A1A0A;
  border-radius: 50% 50% 0 0;
}
/* coach arm with notebook */
.lc-scene__coach-arm {
  position: absolute;
  bottom: 28px; right: -26px;
  width: 26px; height: 12px;
  background: var(--lc-gold);
  border-radius: 6px;
  transform: rotate(-20deg);
}
.lc-scene__coach-arm::after {
  content: '';
  position: absolute;
  right: -18px; top: -14px;
  width: 20px; height: 26px;
  background: var(--lc-ivory);
  border-radius: 2px;
  transform: rotate(20deg);
}

/* client figure */
.lc-scene__client {
  position: absolute;
  bottom: 36%; left: 20%;
}
/* client body */
.lc-scene__client-body {
  position: absolute;
  bottom: 0; left: 0;
  width: 44px; height: 75px;
  background: rgba(90,47,114,.9);
  border-radius: 4px 4px 0 0;
}
.lc-scene__client-body::before {
  content: '';
  position: absolute;
  top: -40px; left: 50%; transform: translateX(-50%);
  width: 32px; height: 32px;
  background: #B07850;
  border-radius: 50%;
}
.lc-scene__client-body::after {
  content: '';
  position: absolute;
  top: -46px; left: 50%; transform: translateX(-50%);
  width: 34px; height: 18px;
  background: #1A0A08;
  border-radius: 50% 50% 0 0;
}

/* couch / seating */
.lc-scene__sofa {
  position: absolute;
  bottom: 34%; left: 5%;
  width: 42%; height: 14%;
  background: #4A2060;
  border-radius: 6px 6px 0 0;
  border: 2px solid rgba(201,150,58,.2);
}
/* sofa cushions */
.lc-scene__sofa::before {
  content: '';
  position: absolute;
  top: -18%; left: 2%; right: 2%; height: 18%;
  background: #5A3070;
  border-radius: 4px 4px 0 0;
}
/* sofa back */
.lc-scene__sofa::after {
  content: '';
  position: absolute;
  top: -55%; left: 0; right: 0; height: 50%;
  background: #5A3070;
  border-radius: 6px 6px 0 0;
  border: 1px solid rgba(201,150,58,.15);
}

/* coach chair */
.lc-scene__chair {
  position: absolute;
  bottom: 34%; left: 55%;
  width: 16%; height: 14%;
  background: #3A2050;
  border-radius: 4px 4px 0 0;
}
.lc-scene__chair::before {
  content: '';
  position: absolute;
  top: -50%; left: 0; right: 0; height: 50%;
  background: #4A2F60;
  border-radius: 4px 4px 0 0;
}

/* coffee table */
.lc-scene__table {
  position: absolute;
  bottom: 34%; left: 34%;
  width: 14%; height: 4%;
  background: linear-gradient(180deg, #8B6E3A 0%, #6B4E2A 100%);
  border-radius: 4px;
}
.lc-scene__table::after {
  content: '';
  position: absolute;
  top: -30%; left: 50%; transform: translateX(-50%);
  width: 60%; height: 50%;
  background: rgba(255,255,255,.08);
  border-radius: 50% 50% 0 0 / 100% 100% 0 0;
}

/* floor lamp */
.lc-scene__lamp {
  position: absolute;
  bottom: 36%; right: 32%;
  width: 8px; height: 50%;
  background: linear-gradient(180deg, rgba(201,150,58,.6) 0%, rgba(201,150,58,.3) 100%);
  border-radius: 4px;
}
.lc-scene__lamp::before {
  content: '';
  position: absolute;
  top: -20px; left: 50%; transform: translateX(-50%);
  width: 40px; height: 26px;
  background: linear-gradient(180deg, rgba(201,150,58,.9) 0%, rgba(201,150,58,.5) 100%);
  clip-path: polygon(20% 0%, 80% 0%, 100% 100%, 0% 100%);
  border-radius: 0 0 4px 4px;
}
/* lamp glow */
.lc-scene__lamp::after {
  content: '';
  position: absolute;
  top: -30px; left: 50%; transform: translateX(-50%);
  width: 80px; height: 60px;
  background: radial-gradient(ellipse at center top, rgba(232,184,75,.25) 0%, transparent 70%);
  border-radius: 50%;
  pointer-events: none;
}

/* framed artwork on wall */
.lc-scene__art {
  position: absolute;
  top: 8%; left: 50%;
  width: 18%; height: 28%;
  background: linear-gradient(135deg, #1A0A28 0%, #2A1040 100%);
  border: 3px solid rgba(201,150,58,.4);
  border-radius: 2px;
}
.lc-scene__art::before {
  content: '';
  position: absolute;
  inset: 8px;
  background:
    radial-gradient(ellipse at 30% 30%, rgba(201,150,58,.3) 0%, transparent 50%),
    radial-gradient(ellipse at 70% 70%, rgba(90,47,114,.4) 0%, transparent 50%);
  border-radius: 2px;
}

/* floating orbs */
.lc-hero__orbs { position: absolute; inset: 0; pointer-events: none; }
.lc-orb {
  position: absolute;
  font-size: 1.4rem;
  animation: lc-orb-float 6s ease-in-out infinite;
  opacity: .7;
}
@keyframes lc-orb-float {
  0%, 100% { transform: translateY(0) rotate(0deg); }
  33%       { transform: translateY(-14px) rotate(5deg); }
  66%       { transform: translateY(8px) rotate(-3deg); }
}

/* ── hero text ── */
.lc-hero__content {
  position: relative; z-index: 2;
  max-width: 580px;
  padding: 0 24px 0 60px;
  color: var(--lc-ivory);
}
.lc-hero__eyebrow {
  display: inline-flex; align-items: center; gap: 10px;
  font-family: var(--lc-font-b);
  font-size: .75rem; font-weight: 600;
  letter-spacing: .16em; text-transform: uppercase;
  color: var(--lc-gold2);
  margin-bottom: 20px;
}
.lc-hero__eyebrow::before,
.lc-hero__eyebrow::after {
  content: ''; display: block;
  width: 28px; height: 1px;
  background: var(--lc-gold);
}
.lc-hero__h1 {
  font-family: var(--lc-font-h);
  font-size: clamp(2.6rem, 5vw, 4.2rem);
  font-weight: 600;
  line-height: 1.1;
  margin-bottom: 24px;
}
.lc-hero__h1 em {
  font-style: italic;
  color: var(--lc-gold2);
}
.lc-hero__tagline {
  font-size: 1.1rem;
  line-height: 1.75;
  color: rgba(250,248,243,.75);
  margin-bottom: 36px;
  max-width: 460px;
}
.lc-hero__actions { display: flex; gap: 16px; flex-wrap: wrap; }
.lc-btn {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 14px 28px;
  border-radius: var(--lc-rad);
  font-family: var(--lc-font-b);
  font-size: .9rem; font-weight: 600;
  cursor: pointer;
  transition: all .3s var(--lc-ease);
  border: none;
}
.lc-btn--gold {
  background: var(--lc-gold);
  color: var(--lc-plum);
}
.lc-btn--gold:hover {
  background: var(--lc-gold2);
  transform: translateY(-2px);
  box-shadow: 0 8px 28px rgba(201,150,58,.4);
}
.lc-btn--ghost {
  background: transparent;
  color: var(--lc-ivory);
  border: 2px solid rgba(250,248,243,.3);
}
.lc-btn--ghost:hover {
  border-color: var(--lc-gold);
  color: var(--lc-gold2);
  transform: translateY(-2px);
}
.lc-hero__scroll {
  position: absolute; bottom: 36px; left: 60px;
  display: flex; align-items: center; gap: 10px;
  font-size: .75rem; letter-spacing: .1em; text-transform: uppercase;
  color: rgba(250,248,243,.5);
  animation: lc-fade-up 2s ease 1s both;
}
.lc-hero__scroll::before {
  content: '';
  display: block; width: 1px; height: 40px;
  background: linear-gradient(180deg, transparent, rgba(201,150,58,.6));
  animation: lc-scroll-line 2s ease-in-out infinite;
}
@keyframes lc-scroll-line {
  0%, 100% { transform: scaleY(1); }
  50%       { transform: scaleY(.5); }
}
@keyframes lc-fade-up {
  from { opacity: 0; transform: translateY(20px); }
  to   { opacity: 1; transform: translateY(0); }
}

/* ════════════════════════════════
   TRUST BAR
   ════════════════════════════════ */
.lc-trust {
  background: var(--lc-plum2);
  border-top: 1px solid rgba(201,150,58,.15);
  border-bottom: 1px solid rgba(201,150,58,.15);
  padding: 22px 0;
}
.lc-trust__inner {
  display: flex; align-items: center;
  justify-content: center; flex-wrap: wrap;
  gap: 12px 40px;
  max-width: 1200px; margin: 0 auto; padding: 0 24px;
}
.lc-trust__item {
  display: flex; align-items: center; gap: 10px;
  font-size: .85rem; font-weight: 500;
  color: rgba(250,248,243,.75);
}
.lc-trust__item::before {
  content: attr(data-icon);
  font-size: 1.1rem;
}

/* ════════════════════════════════
   PILLARS GRID
   ════════════════════════════════ */
.lc-pillars__grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px,1fr));
  gap: 28px;
  margin-top: 56px;
}
.lc-pillar {
  background: var(--lc-white);
  border-radius: var(--lc-rad-lg);
  padding: 36px 32px;
  box-shadow: var(--lc-shadow);
  transition: transform .3s var(--lc-ease), box-shadow .3s var(--lc-ease);
  position: relative;
  overflow: hidden;
}
.lc-pillar::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 3px;
  background: linear-gradient(90deg, var(--lc-plum), var(--lc-gold));
  opacity: 0;
  transition: opacity .3s;
}
.lc-pillar:hover {
  transform: translateY(-6px);
  box-shadow: var(--lc-shadow2);
}
.lc-pillar:hover::before { opacity: 1; }
.lc-pillar__icon {
  font-size: 2.4rem; margin-bottom: 18px;
  display: block;
}
.lc-pillar__title {
  font-family: var(--lc-font-h);
  font-size: 1.4rem; font-weight: 600;
  margin-bottom: 12px;
  color: var(--lc-plum);
}
.lc-pillar__desc {
  font-size: .95rem; line-height: 1.7;
  color: var(--lc-muted);
}

/* ════════════════════════════════
   COUNTERS
   ════════════════════════════════ */
.lc-counters__grid {
  display: grid;
  grid-template-columns: repeat(4,1fr);
  gap: 2px;
  margin-top: 0;
}
.lc-counter {
  text-align: center;
  padding: 60px 24px;
  background: rgba(255,255,255,.05);
  border: 1px solid rgba(201,150,58,.15);
}
.lc-counter__num {
  font-family: var(--lc-font-h);
  font-size: clamp(2.6rem, 5vw, 4rem);
  font-weight: 700;
  color: var(--lc-gold2);
  display: block;
  line-height: 1;
  margin-bottom: 8px;
}
.lc-counter__label {
  font-size: .85rem;
  font-weight: 500;
  letter-spacing: .08em;
  color: rgba(250,248,243,.6);
  text-transform: uppercase;
}

/* ════════════════════════════════
   ABOUT / COACH PROFILE
   ════════════════════════════════ */
.lc-about__grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 72px;
  align-items: center;
}
.lc-about__visual {
  position: relative;
  height: 500px;
}
/* CSS portrait frame */
.lc-about__frame {
  position: absolute;
  top: 0; left: 0; right: 0; bottom: 0;
  background: linear-gradient(145deg, var(--lc-plum) 0%, #5A2F72 100%);
  border-radius: var(--lc-rad-lg);
  overflow: hidden;
}
/* abstract art inside frame */
.lc-about__frame::before {
  content: '';
  position: absolute;
  top: 10%; left: 50%; transform: translateX(-50%);
  width: 200px; height: 200px;
  background: radial-gradient(circle, rgba(201,150,58,.4) 0%, rgba(90,47,114,.3) 50%, transparent 100%);
  border-radius: 50%;
}
.lc-about__frame::after {
  content: '';
  position: absolute;
  bottom: -10%; right: -10%;
  width: 300px; height: 300px;
  background: radial-gradient(circle, rgba(201,150,58,.15) 0%, transparent 60%);
  border-radius: 50%;
}
/* CSS coach silhouette */
.lc-about__silhouette {
  position: absolute;
  bottom: 0; left: 50%; transform: translateX(-50%);
  width: 160px; height: 320px;
}
.lc-about__sil-body {
  position: absolute;
  bottom: 0; left: 50%; transform: translateX(-50%);
  width: 80px; height: 180px;
  background: linear-gradient(180deg, rgba(201,150,58,.5) 0%, rgba(201,150,58,.3) 100%);
  border-radius: 8px 8px 0 0;
}
.lc-about__sil-body::before {
  content: '';
  position: absolute;
  top: -60px; left: 50%; transform: translateX(-50%);
  width: 56px; height: 56px;
  background: rgba(201,150,58,.6);
  border-radius: 50%;
}
.lc-about__sil-body::after {
  content: '';
  position: absolute;
  top: -80px; left: 50%; transform: translateX(-50%);
  width: 58px; height: 32px;
  background: rgba(50,30,10,.8);
  border-radius: 50% 50% 0 0;
}
/* gold accent bar */
.lc-about__accent {
  position: absolute;
  bottom: -8px; left: -8px;
  width: 60%; height: 60%;
  border: 3px solid rgba(201,150,58,.4);
  border-radius: var(--lc-rad-lg);
  pointer-events: none;
}
/* floating credential badges */
.lc-about__badge {
  position: absolute;
  background: var(--lc-white);
  border-radius: 10px;
  padding: 12px 16px;
  box-shadow: 0 8px 28px rgba(58,31,74,.2);
  font-size: .78rem;
  font-weight: 600;
}
.lc-about__badge--1 { top: 15%; right: -20px; }
.lc-about__badge--2 { bottom: 28%; right: -16px; }
.lc-about__badge--3 { bottom: 10%; left: -16px; }
.lc-about__badge-abbr {
  display: block;
  font-family: var(--lc-font-h);
  font-size: 1.1rem;
  color: var(--lc-plum);
  font-weight: 700;
}
.lc-about__badge-label {
  color: var(--lc-muted);
  font-weight: 400;
  font-size: .72rem;
  margin-top: 2px;
}

/* credentials grid */
.lc-creds {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 14px;
  margin-top: 32px;
}
.lc-cred {
  display: flex; align-items: center; gap: 14px;
  padding: 14px 18px;
  background: var(--lc-blush);
  border-radius: 10px;
  border-left: 3px solid var(--lc-gold);
}
.lc-cred__abbr {
  font-family: var(--lc-font-h);
  font-size: 1.15rem; font-weight: 700;
  color: var(--lc-plum);
  flex-shrink: 0;
  min-width: 44px;
}
.lc-cred__label { font-size: .82rem; color: var(--lc-muted); line-height: 1.4; }

/* ════════════════════════════════
   PROCESS STEPS
   ════════════════════════════════ */
.lc-process { counter-reset: step; }
.lc-process__steps {
  display: flex; flex-direction: column;
  gap: 0;
  margin-top: 56px;
  position: relative;
}
.lc-process__steps::before {
  content: '';
  position: absolute;
  left: 42px; top: 0; bottom: 0;
  width: 2px;
  background: linear-gradient(180deg, var(--lc-gold) 0%, rgba(201,150,58,.1) 100%);
}
.lc-step {
  display: flex; gap: 32px;
  padding: 32px 0;
  position: relative;
  align-items: flex-start;
}
.lc-step__num {
  flex-shrink: 0;
  width: 84px; height: 84px;
  background: var(--lc-white);
  border: 3px solid var(--lc-gold);
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-family: var(--lc-font-h);
  font-size: 1.6rem; font-weight: 700;
  color: var(--lc-plum);
  box-shadow: 0 4px 20px rgba(201,150,58,.2);
  position: relative; z-index: 1;
}
.lc-step__body {
  padding-top: 16px;
  flex: 1;
}
.lc-step__title {
  font-family: var(--lc-font-h);
  font-size: 1.4rem; font-weight: 600;
  color: var(--lc-plum);
  margin-bottom: 10px;
}
.lc-step__desc {
  font-size: .95rem; line-height: 1.75;
  color: var(--lc-muted);
}

/* ════════════════════════════════
   PACKAGES
   ════════════════════════════════ */
.lc-packages__grid {
  display: grid;
  grid-template-columns: repeat(3,1fr);
  gap: 28px;
  margin-top: 56px;
  align-items: start;
}
.lc-package {
  background: var(--lc-white);
  border-radius: var(--lc-rad-lg);
  padding: 40px 32px;
  box-shadow: var(--lc-shadow);
  border: 2px solid transparent;
  transition: all .3s var(--lc-ease);
  position: relative;
}
.lc-package:hover {
  transform: translateY(-4px);
  box-shadow: var(--lc-shadow2);
}
.lc-package--featured {
  background: linear-gradient(145deg, var(--lc-plum) 0%, #5A2F72 100%);
  color: var(--lc-ivory);
  border-color: var(--lc-gold);
  box-shadow: 0 16px 56px rgba(58,31,74,.35);
  transform: scale(1.04);
}
.lc-package--featured:hover { transform: scale(1.04) translateY(-4px); }
.lc-package__badge {
  position: absolute;
  top: -14px; left: 50%; transform: translateX(-50%);
  background: var(--lc-gold);
  color: var(--lc-plum);
  font-size: .7rem; font-weight: 700;
  letter-spacing: .12em; text-transform: uppercase;
  padding: 6px 18px;
  border-radius: 20px;
  white-space: nowrap;
}
.lc-package__name {
  font-family: var(--lc-font-h);
  font-size: 1.5rem; font-weight: 600;
  margin-bottom: 8px;
}
.lc-package--featured .lc-package__name { color: var(--lc-ivory); }
.lc-package__price {
  font-family: var(--lc-font-h);
  font-size: 2.4rem; font-weight: 700;
  color: var(--lc-plum);
  line-height: 1;
  margin-bottom: 4px;
}
.lc-package--featured .lc-package__price { color: var(--lc-gold2); }
.lc-package__period {
  font-size: .8rem; color: var(--lc-muted);
  margin-bottom: 28px;
}
.lc-package--featured .lc-package__period { color: rgba(250,248,243,.6); }
.lc-package__divider {
  height: 1px;
  background: rgba(58,31,74,.1);
  margin-bottom: 24px;
}
.lc-package--featured .lc-package__divider { background: rgba(201,150,58,.3); }
.lc-package__features { list-style: none; margin-bottom: 32px; }
.lc-package__features li {
  padding: 8px 0;
  font-size: .9rem;
  display: flex; align-items: center; gap: 10px;
  color: var(--lc-muted);
}
.lc-package--featured .lc-package__features li { color: rgba(250,248,243,.8); }
.lc-package__features li::before {
  content: '✦';
  color: var(--lc-gold);
  font-size: .75rem;
  flex-shrink: 0;
}
.lc-package__cta {
  display: block; width: 100%;
  padding: 14px;
  border-radius: 10px;
  text-align: center;
  font-weight: 600; font-size: .9rem;
  cursor: pointer;
  transition: all .3s var(--lc-ease);
  border: none;
}
.lc-package__cta--outline {
  background: transparent;
  border: 2px solid rgba(58,31,74,.2);
  color: var(--lc-plum);
}
.lc-package__cta--outline:hover {
  border-color: var(--lc-plum);
  background: var(--lc-plum);
  color: var(--lc-ivory);
}
.lc-package__cta--gold {
  background: var(--lc-gold);
  color: var(--lc-plum);
}
.lc-package__cta--gold:hover {
  background: var(--lc-gold2);
  transform: translateY(-1px);
  box-shadow: 0 6px 20px rgba(201,150,58,.4);
}

/* ════════════════════════════════
   TESTIMONIALS
   ════════════════════════════════ */
.lc-testimonials__grid {
  display: grid;
  grid-template-columns: repeat(3,1fr);
  gap: 28px;
  margin-top: 56px;
}
.lc-testimonial {
  background: rgba(255,255,255,.06);
  border: 1px solid rgba(201,150,58,.15);
  border-radius: var(--lc-rad-lg);
  padding: 40px 32px;
  position: relative;
  transition: transform .3s var(--lc-ease);
}
.lc-testimonial:hover { transform: translateY(-4px); }
.lc-testimonial::before {
  content: '"';
  position: absolute;
  top: 16px; left: 24px;
  font-family: var(--lc-font-h);
  font-size: 6rem; line-height: 1;
  color: rgba(201,150,58,.2);
  font-weight: 700;
}
.lc-testimonial__stars {
  display: flex; gap: 4px;
  margin-bottom: 20px;
}
.lc-testimonial__stars span { color: var(--lc-gold2); font-size: 1rem; }
.lc-testimonial__quote {
  font-family: var(--lc-font-h);
  font-size: 1.05rem;
  font-style: italic;
  line-height: 1.7;
  color: rgba(250,248,243,.85);
  margin-bottom: 24px;
  position: relative; z-index: 1;
}
.lc-testimonial__author { display: flex; align-items: center; gap: 14px; }
.lc-testimonial__avatar {
  width: 46px; height: 46px;
  border-radius: 50%;
  background: linear-gradient(135deg, var(--lc-gold), var(--lc-plum));
  display: flex; align-items: center; justify-content: center;
  font-family: var(--lc-font-h);
  font-size: 1.2rem; font-weight: 700;
  color: var(--lc-ivory);
  flex-shrink: 0;
}
.lc-testimonial__name {
  font-weight: 600;
  font-size: .9rem;
  color: var(--lc-gold2);
}
.lc-testimonial__role {
  font-size: .78rem;
  color: rgba(250,248,243,.5);
  margin-top: 2px;
}

/* ════════════════════════════════
   BOOKING FORM
   ════════════════════════════════ */
.lc-booking {
  background: linear-gradient(145deg, #2A1235 0%, #3A1F4A 100%);
  border-top: 1px solid rgba(201,150,58,.15);
}
.lc-booking__grid {
  display: grid;
  grid-template-columns: 1fr 1.4fr;
  gap: 72px;
  align-items: start;
}
.lc-booking__info h3 {
  font-family: var(--lc-font-h);
  font-size: 1.8rem; font-weight: 600;
  color: var(--lc-ivory);
  margin-bottom: 20px;
}
.lc-booking__promise {
  list-style: none;
  margin-top: 28px;
}
.lc-booking__promise li {
  padding: 10px 0;
  font-size: .9rem;
  color: rgba(250,248,243,.75);
  display: flex; align-items: flex-start; gap: 12px;
  border-bottom: 1px solid rgba(201,150,58,.08);
}
.lc-booking__promise li:last-child { border-bottom: none; }
.lc-booking__promise li::before {
  content: '✦';
  color: var(--lc-gold);
  flex-shrink: 0;
  margin-top: 2px;
}
.lc-form {
  background: rgba(255,255,255,.05);
  border: 1px solid rgba(201,150,58,.2);
  border-radius: var(--lc-rad-lg);
  padding: 40px;
  backdrop-filter: blur(8px);
}
.lc-form__row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}
.lc-form__group { margin-bottom: 20px; }
.lc-form__group label {
  display: block;
  font-size: .8rem;
  font-weight: 600;
  letter-spacing: .06em;
  text-transform: uppercase;
  color: rgba(250,248,243,.6);
  margin-bottom: 8px;
}
.lc-form__group input,
.lc-form__group select,
.lc-form__group textarea {
  width: 100%;
  background: rgba(255,255,255,.07);
  border: 1px solid rgba(201,150,58,.2);
  border-radius: 8px;
  padding: 12px 16px;
  font-family: var(--lc-font-b);
  font-size: .9rem;
  color: var(--lc-ivory);
  outline: none;
  transition: border-color .25s, background .25s;
}
.lc-form__group input::placeholder,
.lc-form__group textarea::placeholder { color: rgba(250,248,243,.3); }
.lc-form__group input:focus,
.lc-form__group select:focus,
.lc-form__group textarea:focus {
  border-color: var(--lc-gold);
  background: rgba(255,255,255,.1);
}
.lc-form__group select option { background: var(--lc-plum); color: var(--lc-ivory); }
.lc-form__group textarea { resize: vertical; min-height: 100px; }
.lc-form__submit {
  width: 100%;
  padding: 16px;
  background: linear-gradient(135deg, var(--lc-gold) 0%, var(--lc-gold2) 100%);
  color: var(--lc-plum);
  border: none;
  border-radius: 10px;
  font-family: var(--lc-font-b);
  font-size: 1rem; font-weight: 700;
  cursor: pointer;
  letter-spacing: .04em;
  transition: all .3s var(--lc-ease);
  box-shadow: 0 4px 20px rgba(201,150,58,.3);
}
.lc-form__submit:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 32px rgba(201,150,58,.5);
}

/* ════════════════════════════════
   FOOTER
   ════════════════════════════════ */
.lc-footer {
  background: var(--lc-plum2);
  border-top: 1px solid rgba(201,150,58,.12);
  padding: 32px 0;
}
.lc-footer__inner {
  display: flex; align-items: center;
  justify-content: space-between; flex-wrap: wrap;
  gap: 16px;
  max-width: 1200px; margin: 0 auto; padding: 0 24px;
}
.lc-footer__logo {
  font-family: var(--lc-font-h);
  font-size: 1.2rem; font-weight: 700;
  color: var(--lc-ivory);
}
.lc-footer__logo span { color: var(--lc-gold); }
.lc-footer__copy {
  font-size: .8rem;
  color: rgba(250,248,243,.4);
}
.lc-footer__links {
  display: flex; gap: 24px;
}
.lc-footer__links a {
  font-size: .8rem;
  color: rgba(250,248,243,.5);
  transition: color .2s;
}
.lc-footer__links a:hover { color: var(--lc-gold2); }

/* ════════════════════════════════
   ANIMATIONS
   ════════════════════════════════ */
.lc-reveal {
  opacity: 0;
  transform: translateY(30px);
  transition: opacity .7s var(--lc-ease), transform .7s var(--lc-ease);
}
.lc-reveal.is-visible {
  opacity: 1;
  transform: translateY(0);
}

/* ════════════════════════════════
   RESPONSIVE
   ════════════════════════════════ */
@media (max-width: 1024px) {
  .lc-about__grid   { grid-template-columns: 1fr; gap: 48px; }
  .lc-about__visual { height: 380px; }
  .lc-booking__grid { grid-template-columns: 1fr; gap: 40px; }
}
@media (max-width: 768px) {
  .lc-sec { padding: 72px 0; }
  .lc-hero__scene { display: none; }
  .lc-hero__content { padding: 0 24px; max-width: 100%; }
  .lc-nav__links { display: none; }
  .lc-counters__grid { grid-template-columns: repeat(2,1fr); }
  .lc-packages__grid { grid-template-columns: 1fr; }
  .lc-package--featured { transform: none; }
  .lc-testimonials__grid { grid-template-columns: 1fr; }
  .lc-form__row { grid-template-columns: 1fr; }
  .lc-process__steps::before { left: 38px; }
  .lc-step__num { width: 76px; height: 76px; font-size: 1.4rem; }
  .lc-creds { grid-template-columns: 1fr; }
}
@media (max-width: 480px) {
  .lc-counters__grid { grid-template-columns: 1fr 1fr; }
  .lc-pillars__grid  { grid-template-columns: 1fr; }
}
</style>
<?php get_header(); ?>
<div class="lc-page">
>

<!-- ══════════════════════════════════════════
     NAVBAR
     ══════════════════════════════════════════ -->
<nav class="lc-nav" aria-label="Main navigation">
  <div class="lc-nav__inner">
    <a href="<?php echo esc_url( home_url('/') ); ?>" class="lc-nav__logo">
      Luminary<span>.</span>
    </a>
    <div class="lc-nav__links">
      <a href="#pillars">What We Do</a>
      <a href="#process">How It Works</a>
      <a href="#about">About</a>
      <a href="#packages">Investment</a>
      <a href="#booking" class="lc-nav__cta">Book Discovery Call</a>
    </div>
  </div>
</nav>

<!-- ══════════════════════════════════════════
     HERO
     ══════════════════════════════════════════ -->
<section class="lc-hero" aria-label="Hero">

  <div class="lc-hero__stars" aria-hidden="true"></div>
  <div class="lc-hero__glow"  aria-hidden="true"></div>

  <!-- floating orbs -->
  <div class="lc-hero__orbs" aria-hidden="true">
    <?php foreach ( $orbs as $i => $orb ) :
      $delay = ( $i * 0.55 ) % 4.0;
      $dur   = 5.0 + ( $i * 0.4 ) % 3.0;
    ?>
    <span class="lc-orb"
          style="top:<?php echo esc_attr( $orb[1] ); ?>;<?php echo esc_attr( $orb[2] ); ?>;animation-delay:<?php echo esc_attr( number_format($delay,2) ); ?>s;animation-duration:<?php echo esc_attr( number_format($dur,1) ); ?>s;">
      <?php echo $orb[0]; ?>
    </span>
    <?php endforeach; ?>
  </div>

  <!-- CSS coaching room scene -->
  <div class="lc-hero__scene" aria-hidden="true">
    <div class="lc-scene__wall"></div>
    <div class="lc-scene__window">
    </div>
    <div class="lc-scene__curtain-l"></div>
    <div class="lc-scene__curtain-r"></div>
    <div class="lc-scene__shelf">
      <?php
      $book_colors = ['#4A2060','#C9963A','#2A5A6A','#7A2A2A','#3A5A2A','#5A4A20','#2A2A6A','#6A2A5A'];
      for ( $b = 0; $b < 8; $b++ ) :
        $bh    = 55 + rand(0,25);
        $bw    = 14 + rand(0,8);
        $btop  = 58 - $bh;
        $bleft = 4 + $b * 14;
        $bcol  = $book_colors[ $b % count($book_colors) ];
        $btilt = rand(-3,3);
      ?>
      <div style="position:absolute;bottom:0;left:<?php echo esc_attr($bleft); ?>px;width:<?php echo esc_attr($bw); ?>px;height:<?php echo esc_attr($bh); ?>%;background:<?php echo esc_attr($bcol); ?>;border-right:1px solid rgba(255,255,255,.1);transform:rotate(<?php echo esc_attr($btilt); ?>deg);transform-origin:bottom center;"></div>
      <?php endfor; ?>
    </div>
    <div class="lc-scene__art"></div>
    <div class="lc-scene__floor">
      <div class="lc-scene__rug"></div>
    </div>
    <div class="lc-scene__sofa"></div>
    <div class="lc-scene__chair"></div>
    <div class="lc-scene__table"></div>
    <div class="lc-scene__lamp"></div>
    <div class="lc-scene__coach">
      <div class="lc-scene__coach-body">
        <div class="lc-scene__coach-arm"></div>
      </div>
    </div>
    <div class="lc-scene__client">
      <div class="lc-scene__client-body"></div>
    </div>
  </div>

  <!-- hero text -->
  <div class="lc-hero__content">
    <div class="lc-hero__eyebrow">ICF Certified · Executive Coaching · London</div>
    <h1 class="lc-hero__h1">
      Become the Leader<br>
      <em>You Were Built to Be</em>
    </h1>
    <p class="lc-hero__tagline">
      Luminary Coaching partners with ambitious professionals to unlock clarity,
      command presence, and create careers and lives that are truly extraordinary.
    </p>
    <div class="lc-hero__actions">
      <a href="#booking" class="lc-btn lc-btn--gold">Book a Discovery Call</a>
      <a href="#process" class="lc-btn lc-btn--ghost">How It Works</a>
    </div>
  </div>

  <div class="lc-hero__scroll" aria-hidden="true">Explore</div>
</section>

<!-- ══════════════════════════════════════════
     TRUST BAR
     ══════════════════════════════════════════ -->
<div class="lc-trust" aria-label="Trust indicators">
  <div class="lc-trust__inner">
    <span class="lc-trust__item" data-icon="✦">ICF Certified PCC Coach</span>
    <span class="lc-trust__item" data-icon="✦">500+ Transformations</span>
    <span class="lc-trust__item" data-icon="✦">FTSE 100 Clients</span>
    <span class="lc-trust__item" data-icon="✦">4.9★ Average Rating</span>
    <span class="lc-trust__item" data-icon="✦">Complimentary Discovery Call</span>
  </div>
</div>

<!-- ══════════════════════════════════════════
     PILLARS / WHAT WE DO
     ══════════════════════════════════════════ -->
<section id="pillars" class="lc-sec lc-sec--alt">
  <div class="lc-wrap">
    <div class="lc-center">
      <span class="lc-eyebrow">Areas of Transformation</span>
      <h2 class="lc-h2">Coaching That Goes<br>Beyond the Surface</h2>
      <p class="lc-lead">
        Real change happens when you address the whole person — not just the problem in front of you.
        Our coaching spans six interconnected dimensions of professional and personal excellence.
      </p>
    </div>
    <div class="lc-pillars__grid">
      <?php foreach ( $pillars as $i => $p ) : ?>
      <div class="lc-pillar lc-reveal" style="transition-delay:<?php echo esc_attr( $i * 80 ); ?>ms;">
        <span class="lc-pillar__icon" aria-hidden="true"><?php echo $p['icon']; ?></span>
        <h3 class="lc-pillar__title"><?php echo esc_html( $p['title'] ); ?></h3>
        <p class="lc-pillar__desc"><?php echo esc_html( $p['desc'] ); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════
     COUNTERS
     ══════════════════════════════════════════ -->
<section class="lc-sec--dark" id="impact" aria-label="Impact statistics" style="padding:0;">
  <div class="lc-counters__grid">
    <div class="lc-counter lc-reveal">
      <span class="lc-counter__num" data-target="18" data-suffix="yrs">0</span>
      <span class="lc-counter__label">Years Coaching</span>
    </div>
    <div class="lc-counter lc-reveal" style="transition-delay:100ms;">
      <span class="lc-counter__num" data-target="500" data-suffix="+">0</span>
      <span class="lc-counter__label">Lives Transformed</span>
    </div>
    <div class="lc-counter lc-reveal" style="transition-delay:200ms;">
      <span class="lc-counter__num" data-target="4.9" data-suffix="★" data-float="1">0</span>
      <span class="lc-counter__label">Average Rating</span>
    </div>
    <div class="lc-counter lc-reveal" style="transition-delay:300ms;">
      <span class="lc-counter__num" data-target="94" data-suffix="%">0</span>
      <span class="lc-counter__label">Clients Reach Their Goal</span>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════
     ABOUT / COACH PROFILE
     ══════════════════════════════════════════ -->
<section id="about" class="lc-sec">
  <div class="lc-wrap">
    <div class="lc-about__grid">
      <div class="lc-about__visual lc-reveal">
        <div class="lc-about__frame">
          <div class="lc-about__silhouette">
            <div class="lc-about__sil-body"></div>
          </div>
        </div>
        <div class="lc-about__accent"></div>
        <?php
        $badges = [
          [ 'abbr' => 'PCC', 'label' => 'ICF Certified', 'cls' => '1' ],
          [ 'abbr' => 'MBA', 'label' => 'London Business School', 'cls' => '2' ],
          [ 'abbr' => '18+', 'label' => 'Years Experience', 'cls' => '3' ],
        ];
        foreach ( $badges as $b ) : ?>
        <div class="lc-about__badge lc-about__badge--<?php echo esc_attr($b['cls']); ?>">
          <span class="lc-about__badge-abbr"><?php echo esc_html($b['abbr']); ?></span>
          <span class="lc-about__badge-label"><?php echo esc_html($b['label']); ?></span>
        </div>
        <?php endforeach; ?>
      </div>

      <div class="lc-about__text lc-reveal" style="transition-delay:150ms;">
        <span class="lc-eyebrow">Your Coach</span>
        <h2 class="lc-h2">Alexandra Pemberton</h2>
        <p class="lc-lead" style="margin-bottom:20px;">
          I spent fifteen years in the boardrooms of Fortune 500 companies before I discovered
          that the highest-performing leaders weren't necessarily the hardest workers — they were
          the ones who truly knew themselves.
        </p>
        <p style="font-size:.95rem; line-height:1.75; color:var(--lc-muted); margin-bottom:32px;">
          That insight led me to train with the International Coaching Federation and establish
          Luminary Coaching in London. Since then I've worked with C-suite executives,
          entrepreneurs, and aspiring leaders across six continents — helping them break through
          the invisible ceilings they've placed on themselves and step into the fullness of who
          they are capable of being.
        </p>
        <div class="lc-creds">
          <?php foreach ( $creds as $c ) : ?>
          <div class="lc-cred">
            <span class="lc-cred__abbr"><?php echo esc_html( $c['abbr'] ); ?></span>
            <span class="lc-cred__label"><?php echo esc_html( $c['body'] ); ?></span>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════
     PROCESS — HOW IT WORKS
     ══════════════════════════════════════════ -->
<section id="process" class="lc-sec lc-sec--alt">
  <div class="lc-wrap" style="max-width:800px;">
    <div class="lc-center">
      <span class="lc-eyebrow">The Journey</span>
      <h2 class="lc-h2">A Process Designed<br>Around You</h2>
      <p class="lc-lead">
        Every coaching engagement is different, but the framework that gets results is proven.
        Here's how we turn ambition into action.
      </p>
    </div>
    <div class="lc-process__steps lc-process">
      <?php foreach ( $steps as $i => $s ) : ?>
      <div class="lc-step lc-reveal" style="transition-delay:<?php echo esc_attr( $i * 80 ); ?>ms;">
        <div class="lc-step__num"><?php echo esc_html( $s['num'] ); ?></div>
        <div class="lc-step__body">
          <h3 class="lc-step__title"><?php echo esc_html( $s['title'] ); ?></h3>
          <p class="lc-step__desc"><?php echo esc_html( $s['desc'] ); ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════
     PACKAGES
     ══════════════════════════════════════════ -->
<section id="packages" class="lc-sec">
  <div class="lc-wrap">
    <div class="lc-center">
      <span class="lc-eyebrow">Investment</span>
      <h2 class="lc-h2">Choose Your Path to<br><em style="font-family:var(--lc-font-h);">Extraordinary</em></h2>
      <p class="lc-lead">
        Three engagement models, each designed for a different stage of your journey.
        All include a complimentary 45-minute discovery call.
      </p>
    </div>
    <div class="lc-packages__grid">
      <?php foreach ( $packages as $pkg ) : ?>
      <div class="lc-package <?php echo $pkg['featured'] ? 'lc-package--featured' : ''; ?> lc-reveal">
        <?php if ( $pkg['featured'] ) : ?>
          <div class="lc-package__badge">Most Popular</div>
        <?php endif; ?>
        <div class="lc-package__name"><?php echo esc_html( $pkg['name'] ); ?></div>
        <div class="lc-package__price"><?php echo esc_html( $pkg['price'] ); ?></div>
        <div class="lc-package__period"><?php echo esc_html( $pkg['period'] ); ?></div>
        <div class="lc-package__divider"></div>
        <ul class="lc-package__features">
          <?php foreach ( $pkg['features'] as $feat ) : ?>
          <li><?php echo esc_html( $feat ); ?></li>
          <?php endforeach; ?>
        </ul>
        <?php if ( $pkg['featured'] ) : ?>
          <a href="#booking" class="lc-package__cta lc-package__cta--gold">Begin Your Transformation</a>
        <?php else : ?>
          <a href="#booking" class="lc-package__cta lc-package__cta--outline">Get Started</a>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════
     TESTIMONIALS
     ══════════════════════════════════════════ -->
<section class="lc-sec lc-sec--dark" id="testimonials">
  <div class="lc-wrap">
    <div class="lc-center">
      <span class="lc-eyebrow">Client Stories</span>
      <h2 class="lc-h2" style="color:var(--lc-ivory);">Results That Speak<br>for Themselves</h2>
      <p class="lc-lead">
        Don't take our word for it. Here's what happens when high-achievers commit to becoming extraordinary.
      </p>
    </div>
    <div class="lc-testimonials__grid">
      <?php foreach ( $testimonials as $t ) : ?>
      <div class="lc-testimonial lc-reveal">
        <div class="lc-testimonial__stars">
          <?php for ( $s = 0; $s < $t['stars']; $s++ ) echo '<span>★</span>'; ?>
        </div>
        <blockquote class="lc-testimonial__quote">
          <?php echo esc_html( $t['quote'] ); ?>
        </blockquote>
        <div class="lc-testimonial__author">
          <div class="lc-testimonial__avatar" aria-hidden="true">
            <?php echo esc_html( mb_substr( $t['name'], 0, 1 ) ); ?>
          </div>
          <div>
            <div class="lc-testimonial__name"><?php echo esc_html( $t['name'] ); ?></div>
            <div class="lc-testimonial__role"><?php echo esc_html( $t['role'] ); ?></div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════
     BOOKING FORM
     ══════════════════════════════════════════ -->
<section id="booking" class="lc-sec lc-booking">
  <div class="lc-wrap">
    <div class="lc-booking__grid">
      <div class="lc-booking__info">
        <span class="lc-eyebrow">Book Your Call</span>
        <h3>Start With a Complimentary Discovery Session</h3>
        <p style="font-size:.95rem; line-height:1.75; color:rgba(250,248,243,.7); margin-bottom:8px;">
          45 minutes. No scripts. No sales pitch. Just an honest conversation about
          where you are, where you want to be, and whether we're the right fit to
          help you get there.
        </p>
        <ul class="lc-booking__promise">
          <li>Completely free — no obligation</li>
          <li>Video call or in-person at our Mayfair studio</li>
          <li>Leave with at least one actionable insight</li>
          <li>Confidentiality guaranteed</li>
          <li>We reply within one business day</li>
        </ul>

        <div style="margin-top:36px; padding:24px; background:rgba(201,150,58,.08); border:1px solid rgba(201,150,58,.2); border-radius:12px;">
          <div style="font-family:var(--lc-font-h); font-size:1rem; color:var(--lc-ivory); margin-bottom:12px;">Get in touch directly</div>
          <div style="font-size:.85rem; color:rgba(250,248,243,.65); line-height:2;">
            📞 <?php echo esc_html( $phone ); ?><br>
            ✉️ <?php echo esc_html( $email ); ?><br>
            📍 <?php echo esc_html( $addr ); ?>
          </div>
        </div>
      </div>

      <div class="lc-form">
        <form method="post" action="" novalidate>
          <?php wp_nonce_field( 'tf_lc_booking', 'tf_lc_nonce' ); ?>

          <div class="lc-form__row">
            <div class="lc-form__group">
              <label for="lc_fname">First Name</label>
              <input type="text" id="lc_fname" name="lc_fname" placeholder="Alexandra" required>
            </div>
            <div class="lc-form__group">
              <label for="lc_lname">Last Name</label>
              <input type="text" id="lc_lname" name="lc_lname" placeholder="Pemberton" required>
            </div>
          </div>

          <div class="lc-form__group">
            <label for="lc_email">Email Address</label>
            <input type="email" id="lc_email" name="lc_email" placeholder="you@company.com" required>
          </div>

          <div class="lc-form__row">
            <div class="lc-form__group">
              <label for="lc_role">Your Current Role</label>
              <input type="text" id="lc_role" name="lc_role" placeholder="CEO, VP, Founder…">
            </div>
            <div class="lc-form__group">
              <label for="lc_interest">I'm Interested In</label>
              <select id="lc_interest" name="lc_interest">
                <option value="">Select focus area…</option>
                <option value="clarity">Clarity &amp; Direction</option>
                <option value="confidence">Confidence &amp; Presence</option>
                <option value="performance">Peak Performance</option>
                <option value="transition">Career Transition</option>
                <option value="leadership">Executive Leadership</option>
                <option value="life-work">Life–Work Integration</option>
              </select>
            </div>
          </div>

          <div class="lc-form__group">
            <label for="lc_goal">What would a successful coaching relationship look like for you?</label>
            <textarea id="lc_goal" name="lc_goal" placeholder="Share your biggest challenge or aspiration…"></textarea>
          </div>

          <div class="lc-form__group">
            <label for="lc_hear">How did you hear about us?</label>
            <select id="lc_hear" name="lc_hear">
              <option value="">Select…</option>
              <option value="referral">Personal Referral</option>
              <option value="linkedin">LinkedIn</option>
              <option value="google">Google Search</option>
              <option value="podcast">Podcast</option>
              <option value="press">Press / Article</option>
              <option value="other">Other</option>
            </select>
          </div>

          <button type="submit" name="tf_lc_submit" class="lc-form__submit">
            Request My Discovery Call →
          </button>

          <p style="text-align:center; margin-top:14px; font-size:.75rem; color:rgba(250,248,243,.35);">
            We respect your privacy. Your information is never shared.
          </p>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════════════
     FOOTER
     ══════════════════════════════════════════ -->
<footer class="lc-footer" role="contentinfo">
  <div class="lc-footer__inner">
    <div class="lc-footer__logo">Luminary<span>.</span></div>
    <p class="lc-footer__copy">
      &copy; <?php echo esc_html( date('Y') ); ?> <?php bloginfo('name'); ?>. ICF Certified Coaching. All rights reserved.
    </p>
    <nav class="lc-footer__links" aria-label="Footer navigation">
      <a href="#">Privacy</a>
      <a href="#">Terms</a>
      <a href="#booking">Contact</a>
    </nav>
  </div>
</footer>

<!-- ══════════════════════════════════════════
     JAVASCRIPT
     ══════════════════════════════════════════ -->
<script>
(function () {
  'use strict';

  /* ── IntersectionObserver: reveal + counters ── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);

  function animateCounter(el) {
    const target   = parseFloat(el.dataset.target);
    const suffix   = el.dataset.suffix  || '';
    const isFloat  = el.dataset.float   === '1';
    if (isNaN(target)) return;
    const dur = 1800;
    let start = null;
    function tick(ts) {
      if (!start) start = ts;
      const progress = Math.min((ts - start) / dur, 1);
      const val = easeOut(progress) * target;
      el.textContent = isFloat
        ? val.toFixed(1) + suffix
        : Math.round(val) + suffix;
      if (progress < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }

  const io = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      el.classList.add('is-visible');
      const counters = el.querySelectorAll
        ? el.querySelectorAll('[data-target]')
        : [];
      counters.forEach(animateCounter);
      if (el.dataset && el.dataset.target) animateCounter(el);
      io.unobserve(el);
    });
  }, { threshold: 0.15 });

  document.querySelectorAll('.lc-reveal, .lc-counter__num[data-target]')
    .forEach(function (el) { io.observe(el); });

  /* ── Smooth scroll ── */
  document.querySelectorAll('a[href^="#"]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (!target) return;
      e.preventDefault();
      const offset = 80;
      window.scrollTo({
        top: target.getBoundingClientRect().top + window.pageYOffset - offset,
        behavior: 'smooth'
      });
    });
  });

  /* ── Navbar scroll effect ── */
  const nav = document.querySelector('.lc-nav');
  window.addEventListener('scroll', function () {
    nav.style.boxShadow = window.scrollY > 50
      ? '0 4px 32px rgba(58,31,74,.35)'
      : 'none';
  }, { passive: true });

  /* ── Orb parallax tilt ── */
  document.addEventListener('mousemove', function (e) {
    const cx = window.innerWidth  / 2;
    const cy = window.innerHeight / 2;
    const dx = (e.clientX - cx) / cx;
    const dy = (e.clientY - cy) / cy;
    document.querySelectorAll('.lc-orb').forEach(function (orb, i) {
      const depth = 0.5 + (i % 4) * 0.25;
      orb.style.transform =
        'translate(' + (dx * 12 * depth) + 'px,' + (dy * 8 * depth) + 'px)';
    });
  });

  /* ── Form submission ── */
  const form = document.querySelector('form[method="post"]');
  if (form) {
    form.addEventListener('submit', function (e) {
      const email = form.querySelector('#lc_email');
      if (email && !email.value.includes('@')) {
        e.preventDefault();
        email.focus();
        email.style.borderColor = '#e74c3c';
        setTimeout(function () {
          email.style.borderColor = '';
        }, 2000);
      }
    });
  }

})();
</script>

</body>
</html>
</div><!-- .lc-page -->
<?php get_footer(); ?>
