<?php
/**
 * Template Name: Locksmith
 *
 * Premium locksmith services homepage.
 * Fonts  : Barlow + Roboto (Google Fonts)
 * Palette: steel night #0F1923 / chrome silver #8CA0B3 / safety gold #F5A623 / signal red #E63946 / ice white #EDF2F7
 * Tokens : --ls-* (zero cross-template contamination)
 */
defined('ABSPATH') || exit;
srand(crc32(get_the_permalink()));

/* ── Hero floating particles ────────────────────────────── */
$key_chars = ['🔑','⚙','⬡','◈','✦','◇','·','∘','▪','◦'];
$particles = [];
for ($i = 0; $i < 16; $i++) {
    $particles[] = [
        'sym'  => $key_chars[array_rand($key_chars)],
        'top'  => rand(5,90),
        'left' => rand(3,95),
        'size' => rand(11,24),
        'dur'  => rand(6,15),
        'del'  => rand(0,9),
        'col'  => (rand(0,1) ? 'rgba(245,166,35,.55)' : 'rgba(140,160,179,.45)'),
    ];
}

/* ── Lock tumblers in scene ─────────────────────────────── */
$tumblers = 5;

/* ── Services ───────────────────────────────────────────── */
$services = [
    ['icon'=>'🏠','title'=>'Residential Lockout','desc'=>'24/7 emergency response — locked out of your home? Our engineers arrive within 30 minutes, guaranteed.'],
    ['icon'=>'🏢','title'=>'Commercial Locks','desc'=>'Master key systems, high-security cylinders, access control and perimeter security for businesses.'],
    ['icon'=>'🚗','title'=>'Auto Locksmith','desc'=>'Vehicle entry, ignition repair, key coding, transponder programming and spare key cutting for all makes.'],
    ['icon'=>'🔐','title'=>'Lock Installation','desc'=>'BS3621 deadlocks, multi-point locks, smart locks and insurance-approved cylinders fitted to standard.'],
    ['icon'=>'🛡️','title'=>'Security Survey','desc'=>'Free 30-point vulnerability assessment with a written report and tailored upgrade recommendations.'],
    ['icon'=>'⚙️','title'=>'Lock Repair','desc'=>'Stiff, broken or worn locks repaired efficiently — we always try to repair before replacing.'],
    ['icon'=>'📋','title'=>'Key Cutting','desc'=>'Precision key cutting for domestic, commercial and specialist keys. Laser cutting on request.'],
    ['icon'=>'🔒','title'=>'Safe Services','desc'=>'Safe opening, combination changes, relocation and repair for home and commercial safes.'],
];

/* ── Conditions / scenarios ─────────────────────────────── */
$scenarios = [
    'Home Lockout','Office Lockout','Lost Keys','Broken Key in Lock',
    'Eviction Lock Change','Post-Burglary Security','uPVC Door Lock',
    'Composite Door','Garage Door Lock','French Doors','Patio Doors',
    'High-Security Upgrade','Car Lockout','Van Lockout','Motorcycle Lock',
    'Safe Opening','Keypad Entry','CCTV Installation','Door Frame Repair',
    'Insurance Upgrade','Yale Lock','Mortice Deadlock',
];

/* ── Steps ──────────────────────────────────────────────── */
$steps = [
    ['num'=>'01','title'=>'Call Us','desc'=>'Reach our 24/7 control room. Describe your situation and we will give you a no-obligation quote on the spot.'],
    ['num'=>'02','title'=>'Engineer Dispatched','desc'=>'Your nearest DBS-checked engineer is dispatched immediately. Average arrival: 28 minutes.'],
    ['num'=>'03','title'=>'Assessment','desc'=>'Our engineer assesses the lock, explains the options and confirms the final price before starting work.'],
    ['num'=>'04','title'=>'Work Completed','desc'=>'Non-destructive entry wherever possible. Locks repaired or replaced to BS3621 / insurance standard.'],
    ['num'=>'05','title'=>'Certificate Issued','desc'=>'A written job certificate and receipt issued on completion — accepted by all major insurers.'],
];

/* ── Gallery ────────────────────────────────────────────── */
$gallery = [
    ['label'=>'High-Security Cylinder','color'=>'linear-gradient(135deg,#0a1a28,#1a3a5a)','icon'=>'🔐'],
    ['label'=>'Smart Lock Range','color'=>'linear-gradient(135deg,#1a1a0a,#3a3a1a)','icon'=>'📱'],
    ['label'=>'Commercial Access','color'=>'linear-gradient(135deg,#0f1923,#1a3028)','icon'=>'🏢'],
    ['label'=>'Safe Selection','color'=>'linear-gradient(135deg,#1a0f0f,#3a1a1a)','icon'=>'🔒'],
    ['label'=>'Auto Key Cutting','color'=>'linear-gradient(135deg,#0f1423,#1a2840)','icon'=>'🚗'],
    ['label'=>'Door Hardware','color'=>'linear-gradient(135deg,#0a1a1a,#0a2a2a)','icon'=>'🚪'],
];

/* ── Counters ───────────────────────────────────────────── */
$counters = [
    ['val'=>28,'suffix',' label'=>'Avg Response (mins)','float'=>0,'suffix'=>' min'],
    ['val'=>18000,'suffix'=>'+','label'=>'Jobs Completed','float'=>0],
    ['val'=>4.9,'suffix'=>'★','label'=>'Customer Rating','float'=>1],
    ['val'=>100,'suffix'=>'%','label'=>'Non-Destructive Rate','float'=>0],
];

/* ── Packages ───────────────────────────────────────────── */
$packages = [
    ['name'=>'Emergency Call-Out','price'=>'£75','per'=>'from (24/7)','featured'=>false,
     'features'=>['30-min guaranteed arrival','Non-destructive entry attempt','BS3621 replacement if needed','Written job certificate','All makes & models']],
    ['name'=>'Home Security Plan','price'=>'£249','per'=>'complete package','featured'=>true,
     'features'=>['Full security survey','2 × BS3621 deadlocks','High-security cylinder upgrade','Anti-snap cylinder on all external doors','12-month call-back guarantee','Insurance certificate']],
    ['name'=>'Business Protection','price'=>'POA','per'=>'bespoke quote','featured'=>false,
     'features'=>['Master key system design','Multi-site management','Access control integration','Key control records','Annual security audit','Priority 24/7 response']],
];

/* ── Testimonials ───────────────────────────────────────── */
$testimonials = [
    ['name'=>'Rachel T.','role'=>'Homeowner, Oxford','rating'=>5,
     'text'=>'Locked out at 11pm on a Sunday. The engineer arrived in 22 minutes, opened my door without any damage and fitted a new anti-snap cylinder on the spot. Absolutely professional from start to finish.'],
    ['name'=>'Marcus H.','role'=>'Office Manager, Reading','rating'=>5,
     'text'=>'Our front door lock failed at 7am before staff arrived. Within 40 minutes the engineer had repaired the mechanism, re-keyed the system and we were fully operational. Invaluable service.'],
    ['name'=>'Sophie L.','role'=>'Landlord, London','rating'=>5,
     'text'=>'I use this company for all 12 of my properties. The security survey identified vulnerabilities I\'d never considered and the master key system they installed has saved me considerable time and money.'],
];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Barlow:ital,wght@0,400;0,600;0,700;0,800;1,400&family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════════
   LOCKSMITH — CSS TOKENS  (--ls-*)
   ═══════════════════════════════════════════════════════════ */
:root {
  --ls-night:     #0F1923;
  --ls-night-lt:  #1a2d3d;
  --ls-chrome:    #8CA0B3;
  --ls-chrome-lt: #b0c4d8;
  --ls-gold:      #F5A623;
  --ls-gold-d:    #c47f0d;
  --ls-red:       #E63946;
  --ls-red-d:     #b82532;
  --ls-ice:       #EDF2F7;
  --ls-font-head: 'Barlow', sans-serif;
  --ls-font-body: 'Roboto', sans-serif;
  --ls-radius:    10px;
  --ls-shadow:    0 6px 28px rgba(0,0,0,.18);
}

/* ── Reset & Base ───────────────────────────────────────── */
.ls-wrap *, .ls-wrap *::before, .ls-wrap *::after { box-sizing:border-box; margin:0; padding:0; }
.ls-wrap { font-family:var(--ls-font-body); color:var(--ls-night); background:var(--ls-ice); line-height:1.7; }
.ls-container { max-width:1200px; margin:0 auto; padding:0 24px; }
.ls-section { padding:90px 0; }
.ls-section--dark { background:var(--ls-night); color:var(--ls-chrome-lt); }
.ls-section--night-lt { background:var(--ls-night-lt); color:var(--ls-chrome-lt); }
.ls-section--ice { background:var(--ls-ice); }
.ls-tag { display:inline-block; background:rgba(245,166,35,.15); color:var(--ls-gold-d); font-size:.7rem; font-weight:800; letter-spacing:.12em; text-transform:uppercase; padding:4px 14px; border-radius:4px; margin-bottom:16px; font-family:var(--ls-font-head); }
.ls-tag--light { background:rgba(245,166,35,.2); color:var(--ls-gold); }
.ls-h2 { font-family:var(--ls-font-head); font-size:clamp(1.6rem,3.5vw,2.6rem); line-height:1.15; font-weight:800; text-transform:uppercase; letter-spacing:.02em; margin-bottom:12px; }
.ls-lead { font-size:1.05rem; opacity:.8; max-width:640px; }
.ls-btn { display:inline-block; padding:14px 36px; border-radius:4px; font-family:var(--ls-font-head); font-size:1rem; font-weight:800; letter-spacing:.08em; text-transform:uppercase; text-decoration:none; cursor:pointer; border:none; transition:transform .2s,box-shadow .2s; }
.ls-btn--gold { background:var(--ls-gold); color:#fff; box-shadow:0 4px 20px rgba(245,166,35,.4); }
.ls-btn--gold:hover { transform:translateY(-2px); box-shadow:0 8px 28px rgba(245,166,35,.55); }
.ls-btn--red  { background:var(--ls-red); color:#fff; box-shadow:0 4px 20px rgba(230,57,70,.4); }
.ls-btn--red:hover { transform:translateY(-2px); box-shadow:0 8px 28px rgba(230,57,70,.55); }
.ls-btn--ghost { background:transparent; color:var(--ls-gold); border:2px solid var(--ls-gold); }
.ls-btn--ghost:hover { background:rgba(245,166,35,.1); transform:translateY(-2px); }

/* ═══════════════════════════════════════════════════════════
   HERO
   ═══════════════════════════════════════════════════════════ */
.ls-hero {
  position:relative; min-height:100vh;
  background:linear-gradient(145deg,#060d15 0%,#0f1923 50%,#0a1628 100%);
  overflow:hidden; display:flex; align-items:center;
}
/* Grid overlay */
.ls-hero::before {
  content:''; position:absolute; inset:0;
  background-image:
    linear-gradient(rgba(140,160,179,.04) 1px,transparent 1px),
    linear-gradient(90deg,rgba(140,160,179,.04) 1px,transparent 1px);
  background-size:60px 60px;
  pointer-events:none;
}
/* Radial gold glow */
.ls-hero::after {
  content:''; position:absolute; top:50%; right:10%;
  width:500px; height:500px; transform:translateY(-50%);
  background:radial-gradient(circle,rgba(245,166,35,.08) 0%,transparent 65%);
  pointer-events:none;
}

/* ── Particles ───────────────────────────────────────────── */
.ls-particle { position:absolute; pointer-events:none; animation:ls-drift var(--dur,10s) var(--del,0s) ease-in-out infinite alternate; }
@keyframes ls-drift {
  from { transform:translateY(0) rotate(0deg); opacity:.35; }
  to   { transform:translateY(-28px) rotate(15deg); opacity:.75; }
}

.ls-hero__inner { position:relative; z-index:2; display:grid; grid-template-columns:1fr 1fr; gap:60px; align-items:center; padding:120px 0 80px; }

/* ── Scene: Lock mechanism ────────────────────────────────── */
.ls-scene { display:flex; justify-content:center; align-items:center; }
.ls-lock-wrap { position:relative; width:380px; height:420px; }

/* Outer ambient glow */
.ls-lock-wrap::before {
  content:''; position:absolute;
  top:50%; left:50%; transform:translate(-50%,-50%);
  width:300px; height:300px; border-radius:50%;
  background:radial-gradient(circle,rgba(245,166,35,.1) 0%,transparent 65%);
  animation:ls-glow-pulse 3s ease-in-out infinite alternate;
}
@keyframes ls-glow-pulse {
  from { opacity:.5; transform:translate(-50%,-50%) scale(.9); }
  to   { opacity:1;  transform:translate(-50%,-50%) scale(1.05); }
}

/* Padlock body */
.ls-padlock {
  position:absolute; bottom:30px; left:50%; transform:translateX(-50%);
  width:160px; height:140px;
  background:linear-gradient(180deg,#2a3a4a,#1a2535);
  border-radius:14px; border:3px solid #3a5068;
  box-shadow:0 8px 40px rgba(0,0,0,.5), inset 0 1px 0 rgba(255,255,255,.08);
}
/* Padlock shackle */
.ls-padlock__shackle {
  position:absolute; top:-70px; left:50%; transform:translateX(-50%);
  width:80px; height:80px; border-radius:40px 40px 0 0;
  border:14px solid #4a6880; border-bottom:none;
  background:transparent;
}
/* Keyhole */
.ls-padlock__keyhole {
  position:absolute; top:50%; left:50%; transform:translate(-50%,-50%);
}
.ls-padlock__keyhole-circle {
  width:28px; height:28px; border-radius:50%;
  background:var(--ls-night); border:2px solid var(--ls-gold);
  margin:0 auto;
  box-shadow:0 0 12px rgba(245,166,35,.4);
  animation:ls-keyhole-glow 2s ease-in-out infinite alternate;
}
@keyframes ls-keyhole-glow {
  from { box-shadow:0 0 8px rgba(245,166,35,.3); border-color:var(--ls-gold-d); }
  to   { box-shadow:0 0 20px rgba(245,166,35,.7); border-color:var(--ls-gold); }
}
.ls-padlock__keyhole-slot {
  width:10px; height:18px; background:var(--ls-night); border:2px solid var(--ls-gold);
  border-top:none; border-radius:0 0 4px 4px; margin:0 auto;
}

/* Tumblers above padlock */
.ls-tumblers {
  position:absolute; top:20px; left:50%; transform:translateX(-50%);
  display:flex; gap:12px;
}
.ls-tumbler {
  width:38px; height:54px; background:linear-gradient(180deg,#3a5068,#263040);
  border-radius:6px; border:2px solid #4a6880;
  display:flex; align-items:center; justify-content:center;
  font-family:var(--ls-font-head); font-size:.9rem; font-weight:800;
  color:var(--ls-gold); box-shadow:var(--ls-shadow);
  animation:ls-tumbler-cycle var(--tc-dur,2s) var(--tc-del,0s) ease-in-out infinite;
}
@keyframes ls-tumbler-cycle {
  0%, 40%  { transform:translateY(0); }
  50%      { transform:translateY(-8px); }
  60%, 100%{ transform:translateY(0); }
}

/* Keys flanking the lock */
.ls-key {
  position:absolute; bottom:70px;
  display:flex; align-items:center;
}
.ls-key--left  { left:10px; }
.ls-key--right { right:10px; transform:scaleX(-1); }
.ls-key__bow {
  width:36px; height:36px; border-radius:50%;
  border:6px solid var(--ls-gold);
  background:transparent;
  box-shadow:0 0 14px rgba(245,166,35,.4);
}
.ls-key__bow::before {
  content:''; display:block; width:10px; height:10px;
  border-radius:50%; background:var(--ls-night);
  border:3px solid var(--ls-gold);
  position:relative; top:50%; left:50%; transform:translate(-50%,-50%);
}
.ls-key__blade {
  width:60px; height:8px; background:linear-gradient(90deg,var(--ls-gold),var(--ls-gold-d));
  margin-left:-2px; position:relative;
  box-shadow:0 2px 8px rgba(245,166,35,.3);
}
.ls-key__blade::after {
  content:''; position:absolute; right:0; top:-4px;
  border-left:16px solid var(--ls-gold-d); border-top:8px solid transparent; border-bottom:8px solid transparent;
}
.ls-key__teeth {
  position:absolute; bottom:-4px; left:10px;
  display:flex; gap:4px;
}
.ls-key__tooth { width:4px; background:var(--ls-gold-d); border-radius:0 0 2px 2px; }

/* Floating shield */
.ls-shield {
  position:absolute; top:30px; right:20px; font-size:2rem;
  animation:ls-shield-bob 4s ease-in-out infinite alternate;
}
@keyframes ls-shield-bob {
  from { transform:translateY(0) rotate(-5deg); }
  to   { transform:translateY(-12px) rotate(5deg); }
}

/* ── Hero content ─────────────────────────────────────────── */
.ls-hero__badge { display:inline-flex; align-items:center; gap:8px; background:rgba(230,57,70,.15); border:1px solid rgba(230,57,70,.4); color:var(--ls-red); padding:6px 18px; border-radius:4px; font-family:var(--ls-font-head); font-size:.8rem; font-weight:800; letter-spacing:.1em; text-transform:uppercase; margin-bottom:24px; animation:ls-badge-blink 3s ease-in-out infinite; }
@keyframes ls-badge-blink { 0%,100%{opacity:1;} 50%{opacity:.7;} }
.ls-hero__badge::before { content:'●'; color:var(--ls-red); animation:ls-blink 1s step-start infinite; }
@keyframes ls-blink { 50%{opacity:0;} }
.ls-hero__title { font-family:var(--ls-font-head); font-size:clamp(2rem,5vw,3.4rem); font-weight:800; text-transform:uppercase; letter-spacing:.02em; color:#fff; margin-bottom:16px; line-height:1.1; }
.ls-hero__title span { color:var(--ls-gold); }
.ls-hero__sub { font-size:1.05rem; color:var(--ls-chrome-lt); margin-bottom:32px; line-height:1.7; }
.ls-hero__timer { background:rgba(245,166,35,.1); border:1px solid rgba(245,166,35,.3); border-radius:6px; padding:12px 20px; margin-bottom:32px; display:flex; align-items:center; gap:12px; color:var(--ls-gold); font-family:var(--ls-font-head); font-weight:700; font-size:1rem; }
.ls-hero__timer span:first-child { font-size:1.4rem; }
.ls-hero__ctas { display:flex; gap:14px; flex-wrap:wrap; margin-bottom:36px; }
.ls-hero__trust { display:flex; gap:24px; flex-wrap:wrap; }
.ls-hero__trust-item { display:flex; align-items:center; gap:8px; color:var(--ls-chrome-lt); font-size:.85rem; }

/* ═══════════════════════════════════════════════════════════
   TRUST BAR
   ═══════════════════════════════════════════════════════════ */
.ls-trust-bar { background:var(--ls-red); padding:18px 0; }
.ls-trust-bar__inner { display:flex; justify-content:space-around; flex-wrap:wrap; gap:16px; }
.ls-trust-bar__item { display:flex; align-items:center; gap:10px; color:rgba(255,255,255,.9); font-family:var(--ls-font-head); font-size:.9rem; font-weight:600; }
.ls-trust-bar__item span:first-child { font-size:1.2rem; }
.ls-trust-bar__item strong { color:#fff; font-size:1rem; }

/* ═══════════════════════════════════════════════════════════
   SERVICES
   ═══════════════════════════════════════════════════════════ */
.ls-services { background:var(--ls-ice); }
.ls-services__intro { text-align:center; max-width:640px; margin:0 auto 56px; }
.ls-services__grid { display:grid; grid-template-columns:repeat(4,1fr); gap:20px; }
.ls-svc {
  background:#fff; border-radius:var(--ls-radius); padding:28px 18px; text-align:center;
  box-shadow:0 2px 16px rgba(0,0,0,.07); border:1px solid rgba(0,0,0,.06);
  border-top:3px solid var(--ls-gold);
  transition:transform .25s,box-shadow .25s;
}
.ls-svc:hover { transform:translateY(-6px); box-shadow:0 12px 36px rgba(0,0,0,.12); }
.ls-svc__icon { font-size:2rem; margin-bottom:14px; display:block; }
.ls-svc__title { font-family:var(--ls-font-head); font-size:.95rem; font-weight:800; text-transform:uppercase; letter-spacing:.04em; margin-bottom:8px; color:var(--ls-night); }
.ls-svc__desc  { font-size:.85rem; line-height:1.65; color:#555; }

/* ═══════════════════════════════════════════════════════════
   SCENARIOS CLOUD
   ═══════════════════════════════════════════════════════════ */
.ls-scenarios { text-align:center; }
.ls-scenarios__intro { max-width:600px; margin:0 auto 48px; }
.ls-scenarios__cloud { display:flex; flex-wrap:wrap; justify-content:center; gap:10px; }
.ls-scen-tag {
  display:inline-block; padding:7px 16px; border-radius:4px;
  background:rgba(245,166,35,.1); color:var(--ls-gold-d); font-size:.85rem; font-weight:600;
  border:1px solid rgba(245,166,35,.25); font-family:var(--ls-font-head); letter-spacing:.04em;
  cursor:default; transition:background .2s,color .2s;
}
.ls-scen-tag:hover { background:var(--ls-gold); color:#fff; }

/* ═══════════════════════════════════════════════════════════
   ABOUT
   ═══════════════════════════════════════════════════════════ */
.ls-about { }
.ls-about__grid { display:grid; grid-template-columns:1fr 1fr; gap:80px; align-items:center; }
.ls-about__visual { display:flex; flex-direction:column; gap:20px; align-items:center; }

/* Engineer ID card */
.ls-id-card {
  width:300px; background:var(--ls-night); border-radius:12px; overflow:hidden;
  box-shadow:0 12px 48px rgba(0,0,0,.3); border:1px solid rgba(140,160,179,.15);
}
.ls-id-card__header {
  background:linear-gradient(135deg,var(--ls-night-lt),var(--ls-night));
  padding:24px 20px 20px; text-align:center;
  border-bottom:2px solid var(--ls-gold);
}
/* CSS engineer figure */
.ls-eng-fig { display:flex; flex-direction:column; align-items:center; margin-bottom:12px; }
.ls-eng-fig__head { width:52px; height:52px; border-radius:50%; background:radial-gradient(circle at 40% 35%,#c8a878,#a07850); border:3px solid rgba(245,166,35,.4); position:relative; }
.ls-eng-fig__head::before { content:''; position:absolute; top:-8px; left:4px; right:4px; height:12px; background:linear-gradient(180deg,#1a1a1a,#333); border-radius:50% 50% 0 0; }
.ls-eng-fig__body { width:68px; height:58px; background:linear-gradient(180deg,#1a2a3a,#0f1923); border-radius:4px 4px 0 0; margin-top:0; position:relative; }
.ls-eng-fig__body::before { content:'🔑'; position:absolute; top:12px; left:50%; transform:translateX(-50%); font-size:.75rem; }
.ls-eng-fig__body::after { content:'ENGINEER'; position:absolute; bottom:6px; left:0; right:0; text-align:center; font-size:.45rem; color:var(--ls-gold); font-family:var(--ls-font-head); font-weight:800; letter-spacing:.08em; }
.ls-id-card__header h3 { color:#fff; font-family:var(--ls-font-head); font-weight:800; font-size:1rem; text-transform:uppercase; margin-bottom:2px; }
.ls-id-card__header p  { color:var(--ls-chrome); font-size:.75rem; }
.ls-id-card__body { padding:16px 20px; }
.ls-id-card__row { display:flex; justify-content:space-between; padding:7px 0; border-bottom:1px solid rgba(255,255,255,.06); font-size:.82rem; }
.ls-id-card__row:last-child { border-bottom:none; }
.ls-id-card__row span:first-child { color:var(--ls-chrome); opacity:.75; }
.ls-id-card__row span:last-child  { color:var(--ls-gold); font-weight:700; font-family:var(--ls-font-head); }

.ls-cert-badges { display:flex; flex-wrap:wrap; gap:10px; justify-content:center; }
.ls-cert-badge { background:rgba(245,166,35,.1); border:1px solid rgba(245,166,35,.3); color:var(--ls-gold-d); border-radius:4px; padding:6px 12px; font-size:.72rem; font-weight:700; font-family:var(--ls-font-head); letter-spacing:.05em; }

.ls-about__text .ls-h2 { color:var(--ls-night); }
.ls-about__text p { color:#444; margin-bottom:16px; line-height:1.8; }
.ls-about__feats { list-style:none; margin:20px 0 32px; display:flex; flex-direction:column; gap:10px; }
.ls-about__feats li { display:flex; align-items:center; gap:10px; font-size:.9rem; color:#333; }
.ls-about__feats li::before { content:'🔐'; flex-shrink:0; font-size:.8rem; }

/* ═══════════════════════════════════════════════════════════
   APPROACH
   ═══════════════════════════════════════════════════════════ */
.ls-approach { background:var(--ls-night); }
.ls-approach__intro { text-align:center; max-width:640px; margin:0 auto 56px; }
.ls-approach__grid {
  display:grid; grid-template-columns:repeat(5,1fr); gap:0; position:relative;
}
.ls-approach__grid::before {
  content:''; position:absolute; top:38px; left:10%; right:10%; height:2px;
  background:linear-gradient(90deg,var(--ls-gold),var(--ls-red),var(--ls-gold));
  z-index:0;
}
.ls-step { text-align:center; padding:0 10px; position:relative; z-index:1; }
.ls-step__num { width:44px; height:44px; border-radius:4px; background:var(--ls-gold); color:var(--ls-night); font-family:var(--ls-font-head); font-size:.8rem; font-weight:800; display:inline-flex; align-items:center; justify-content:center; margin-bottom:18px; box-shadow:0 4px 14px rgba(245,166,35,.4); }
.ls-step__title { font-family:var(--ls-font-head); font-size:.88rem; font-weight:800; text-transform:uppercase; color:#fff; margin-bottom:8px; letter-spacing:.04em; }
.ls-step__desc  { font-size:.82rem; color:var(--ls-chrome); opacity:.8; line-height:1.6; }

/* ═══════════════════════════════════════════════════════════
   GALLERY
   ═══════════════════════════════════════════════════════════ */
.ls-gallery__grid { display:grid; grid-template-columns:repeat(3,1fr); grid-template-rows:220px 220px; gap:10px; }
.ls-gallery__item { border-radius:var(--ls-radius); overflow:hidden; position:relative; cursor:pointer; }
.ls-gallery__item:nth-child(1) { grid-column:span 2; }
.ls-gallery__item:nth-child(5) { grid-column:span 2; }
.ls-gallery__panel { width:100%; height:100%; display:flex; align-items:center; justify-content:center; font-size:3rem; transition:transform .4s; }
.ls-gallery__item:hover .ls-gallery__panel { transform:scale(1.04); }
.ls-gallery__overlay { position:absolute; inset:0; display:flex; align-items:flex-end; background:linear-gradient(to top,rgba(0,0,0,.7) 0%,transparent 50%); padding:20px; opacity:0; transition:opacity .3s; }
.ls-gallery__item:hover .ls-gallery__overlay { opacity:1; }
.ls-gallery__overlay span { color:#fff; font-size:.9rem; font-weight:700; font-family:var(--ls-font-head); letter-spacing:.04em; }

/* ═══════════════════════════════════════════════════════════
   COUNTERS
   ═══════════════════════════════════════════════════════════ */
.ls-counters { background:linear-gradient(135deg,var(--ls-night-lt),var(--ls-night)); text-align:center; }
.ls-counters__grid { display:grid; grid-template-columns:repeat(4,1fr); gap:40px; }
.ls-counter__val { font-family:var(--ls-font-head); font-size:clamp(2rem,4vw,3.2rem); font-weight:800; color:var(--ls-gold); display:block; line-height:1; letter-spacing:.02em; }
.ls-counter__label { font-size:.85rem; color:var(--ls-chrome-lt); margin-top:8px; opacity:.8; }

/* ═══════════════════════════════════════════════════════════
   PACKAGES
   ═══════════════════════════════════════════════════════════ */
.ls-packages { text-align:center; background:var(--ls-ice); }
.ls-packages__intro { max-width:600px; margin:0 auto 56px; }
.ls-packages__grid { display:grid; grid-template-columns:repeat(3,1fr); gap:24px; align-items:start; }
.ls-pkg { border-radius:var(--ls-radius); padding:36px 28px; text-align:center; background:#fff; box-shadow:0 4px 24px rgba(0,0,0,.08); border:2px solid transparent; transition:transform .25s,box-shadow .25s; }
.ls-pkg:hover { transform:translateY(-6px); box-shadow:0 16px 48px rgba(0,0,0,.14); }
.ls-pkg--featured { border-color:var(--ls-gold); box-shadow:0 8px 40px rgba(245,166,35,.2); background:var(--ls-night); color:var(--ls-chrome-lt); transform:translateY(-8px); }
.ls-pkg--featured:hover { transform:translateY(-14px); }
.ls-pkg__badge { display:inline-block; background:var(--ls-gold); color:var(--ls-night); font-size:.7rem; font-weight:800; letter-spacing:.1em; text-transform:uppercase; padding:3px 12px; border-radius:3px; margin-bottom:12px; font-family:var(--ls-font-head); }
.ls-pkg__name { font-family:var(--ls-font-head); font-size:1rem; font-weight:800; text-transform:uppercase; letter-spacing:.05em; margin-bottom:4px; }
.ls-pkg--featured .ls-pkg__name { color:#fff; }
.ls-pkg__price { font-size:2.4rem; font-weight:800; margin:14px 0 4px; font-family:var(--ls-font-head); }
.ls-pkg--featured .ls-pkg__price { color:var(--ls-gold); }
.ls-pkg__per { font-size:.8rem; opacity:.65; margin-bottom:24px; }
.ls-pkg__features { list-style:none; text-align:left; margin-bottom:28px; display:flex; flex-direction:column; gap:10px; }
.ls-pkg__features li { display:flex; align-items:center; gap:8px; font-size:.88rem; }
.ls-pkg__features li::before { content:'🔒'; flex-shrink:0; font-size:.7rem; }
.ls-pkg--featured .ls-pkg__features li { color:var(--ls-chrome-lt); }
.ls-pkg .ls-btn { width:100%; text-align:center; }

/* ═══════════════════════════════════════════════════════════
   TESTIMONIALS
   ═══════════════════════════════════════════════════════════ */
.ls-testimonials { text-align:center; }
.ls-testimonials__intro { max-width:600px; margin:0 auto 56px; }
.ls-testimonials__grid { display:grid; grid-template-columns:repeat(3,1fr); gap:24px; }
.ls-testi { background:#fff; border-radius:var(--ls-radius); padding:28px 24px; box-shadow:0 4px 20px rgba(0,0,0,.07); border-left:4px solid var(--ls-gold); text-align:left; }
.ls-testi__stars { color:#f5a623; margin-bottom:14px; }
.ls-testi__text { font-size:.9rem; line-height:1.75; color:#444; margin-bottom:18px; font-style:italic; }
.ls-testi__name { font-weight:700; color:var(--ls-night); font-family:var(--ls-font-head); font-size:.9rem; text-transform:uppercase; letter-spacing:.04em; }
.ls-testi__role { font-size:.8rem; color:#888; }

/* ═══════════════════════════════════════════════════════════
   BOOKING FORM
   ═══════════════════════════════════════════════════════════ */
.ls-booking { background:var(--ls-night); }
.ls-booking__inner { display:grid; grid-template-columns:1fr 1fr; gap:80px; align-items:start; }
.ls-booking__info h2 { color:#fff; margin-bottom:16px; }
.ls-booking__info p  { color:var(--ls-chrome-lt); opacity:.8; margin-bottom:28px; line-height:1.8; }
.ls-booking__list { list-style:none; display:flex; flex-direction:column; gap:12px; }
.ls-booking__list li { display:flex; align-items:center; gap:10px; color:var(--ls-chrome-lt); font-size:.9rem; }
.ls-booking__list li span:first-child { width:30px; height:30px; background:rgba(245,166,35,.15); border:1px solid rgba(245,166,35,.3); border-radius:4px; display:inline-flex; align-items:center; justify-content:center; flex-shrink:0; }
.ls-form { background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08); border-radius:10px; padding:36px; }
.ls-form__row { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
.ls-form__group { margin-bottom:14px; }
.ls-form__group label { display:block; font-size:.78rem; font-weight:700; color:var(--ls-chrome); margin-bottom:6px; letter-spacing:.08em; text-transform:uppercase; font-family:var(--ls-font-head); }
.ls-form__group input,
.ls-form__group select,
.ls-form__group textarea {
  width:100%; padding:11px 14px; border-radius:6px;
  border:1px solid rgba(255,255,255,.1); background:rgba(255,255,255,.05);
  color:#fff; font-family:var(--ls-font-body); font-size:.9rem;
  transition:border-color .2s;
}
.ls-form__group input::placeholder,
.ls-form__group textarea::placeholder { color:rgba(255,255,255,.3); }
.ls-form__group input:focus,
.ls-form__group select:focus,
.ls-form__group textarea:focus { outline:none; border-color:var(--ls-gold); }
.ls-form__group select option { background:#0f1923; }
.ls-form__group textarea { resize:vertical; min-height:90px; }
.ls-form__submit { width:100%; padding:15px; background:linear-gradient(135deg,var(--ls-gold),var(--ls-gold-d)); color:var(--ls-night); font-family:var(--ls-font-head); font-size:1.05rem; font-weight:800; letter-spacing:.08em; text-transform:uppercase; border:none; border-radius:6px; cursor:pointer; transition:transform .2s,box-shadow .2s; margin-top:8px; }
.ls-form__submit:hover { transform:translateY(-2px); box-shadow:0 8px 24px rgba(245,166,35,.45); }

/* ═══════════════════════════════════════════════════════════
   FOOTER
   ═══════════════════════════════════════════════════════════ */
.ls-footer { background:var(--ls-night-lt); padding:28px 0; text-align:center; border-top:1px solid rgba(255,255,255,.05); }
.ls-footer p { color:var(--ls-chrome); font-size:.85rem; opacity:.7; }

/* ═══════════════════════════════════════════════════════════
   RESPONSIVE
   ═══════════════════════════════════════════════════════════ */
@media(max-width:1024px){
  .ls-hero__inner { grid-template-columns:1fr; gap:40px; padding:100px 0 60px; }
  .ls-lock-wrap { width:300px; height:340px; }
  .ls-services__grid { grid-template-columns:repeat(2,1fr); }
  .ls-about__grid { grid-template-columns:1fr; }
  .ls-approach__grid { grid-template-columns:repeat(3,1fr); }
  .ls-approach__grid::before { display:none; }
  .ls-counters__grid { grid-template-columns:repeat(2,1fr); }
  .ls-packages__grid { grid-template-columns:1fr; }
  .ls-testimonials__grid { grid-template-columns:1fr; }
  .ls-booking__inner { grid-template-columns:1fr; }
}
@media(max-width:640px){
  .ls-section { padding:64px 0; }
  .ls-services__grid { grid-template-columns:1fr; }
  .ls-approach__grid { grid-template-columns:1fr 1fr; }
  .ls-gallery__grid { grid-template-columns:1fr 1fr; grid-template-rows:auto; }
  .ls-gallery__item:nth-child(1),
  .ls-gallery__item:nth-child(5) { grid-column:span 1; }
  .ls-counters__grid { grid-template-columns:1fr 1fr; }
  .ls-form__row { grid-template-columns:1fr; }
  .ls-hero__ctas { flex-direction:column; }
}
</style>
<?php get_header(); ?>
<div class="ls-page">
>
<?php wp_body_open(); ?>
<div class="ls-wrap">

<!-- ═══════════════ HERO ═══════════════ -->
<section class="ls-hero" aria-label="Locksmith services hero">

  <!-- Floating particles -->
  <?php foreach ($particles as $p): ?>
  <div class="ls-particle" aria-hidden="true" style="
    top:<?= $p['top'] ?>%; left:<?= $p['left'] ?>%;
    font-size:<?= $p['size'] ?>px; color:<?= esc_attr($p['col']) ?>;
    --dur:<?= $p['dur'] ?>s; --del:<?= $p['del'] ?>s;
  "><?= esc_html($p['sym']) ?></div>
  <?php endforeach; ?>

  <div class="ls-container">
    <div class="ls-hero__inner">

      <!-- Content -->
      <div class="ls-hero__content">
        <div class="ls-hero__badge">🔴 24 / 7 Emergency Response</div>
        <h1 class="ls-hero__title">
          Locked Out?<br>
          <span>We're On Our Way.</span>
        </h1>
        <p class="ls-hero__sub">
          DBS-checked, fully insured locksmiths serving the region around the clock. Average arrival time 28 minutes. No call-out fee. Fixed prices agreed before we start.
        </p>
        <div class="ls-hero__timer" aria-label="Average response time guarantee">
          <span>⏱️</span>
          <span>Guaranteed arrival within <strong>30 minutes</strong> or we discount your bill</span>
        </div>
        <div class="ls-hero__ctas">
          <a href="tel:01234567890" class="ls-btn ls-btn--red">📞 Call Now — 24/7</a>
          <a href="#booking" class="ls-btn ls-btn--ghost">Request a Quote</a>
        </div>
        <div class="ls-hero__trust">
          <div class="ls-hero__trust-item"><span>🛡️</span><span>DBS Checked</span></div>
          <div class="ls-hero__trust-item"><span>💷</span><span>Fixed Prices</span></div>
          <div class="ls-hero__trust-item"><span>🏅</span><span>Which? Trusted</span></div>
        </div>
      </div>

      <!-- Scene: Lock mechanism -->
      <div class="ls-scene" aria-hidden="true">
        <div class="ls-lock-wrap">

          <!-- Tumblers -->
          <div class="ls-tumblers">
            <?php $digits = ['7','3','8','4','2'];
            foreach ($digits as $idx => $d): ?>
            <div class="ls-tumbler" style="--tc-dur:<?= (1.5 + $idx * 0.4) ?>s;--tc-del:<?= ($idx * 0.3) ?>s;"><?= $d ?></div>
            <?php endforeach; ?>
          </div>

          <!-- Padlock -->
          <div class="ls-padlock">
            <div class="ls-padlock__shackle"></div>
            <div class="ls-padlock__keyhole">
              <div class="ls-padlock__keyhole-circle"></div>
              <div class="ls-padlock__keyhole-slot"></div>
            </div>
          </div>

          <!-- Left key -->
          <div class="ls-key ls-key--left">
            <div class="ls-key__bow"></div>
            <div class="ls-key__blade">
              <div class="ls-key__teeth">
                <?php foreach ([10,7,12,8,11] as $th): ?>
                <div class="ls-key__tooth" style="height:<?= $th ?>px;"></div>
                <?php endforeach; ?>
              </div>
            </div>
          </div>

          <!-- Right key -->
          <div class="ls-key ls-key--right">
            <div class="ls-key__bow"></div>
            <div class="ls-key__blade">
              <div class="ls-key__teeth">
                <?php foreach ([8,12,6,10,9] as $th): ?>
                <div class="ls-key__tooth" style="height:<?= $th ?>px;"></div>
                <?php endforeach; ?>
              </div>
            </div>
          </div>

          <!-- Shield -->
          <div class="ls-shield">🛡️</div>

        </div>
      </div>

    </div>
  </div>
</section>

<!-- ═══════════════ TRUST BAR ═══════════════ -->
<div class="ls-trust-bar" aria-label="Trust and credential indicators">
  <div class="ls-container">
    <div class="ls-trust-bar__inner">
      <div class="ls-trust-bar__item"><span>🏅</span><span><strong>Which? Trusted Trader</strong></span></div>
      <div class="ls-trust-bar__item"><span>🔒</span><span><strong>Master Locksmith</strong> Association Member</span></div>
      <div class="ls-trust-bar__item"><span>🛡️</span><span><strong>£5M</strong> Public Liability Insurance</span></div>
      <div class="ls-trust-bar__item"><span>✅</span><span><strong>BS3621</strong> &amp; Insurance-Approved</span></div>
    </div>
  </div>
</div>

<!-- ═══════════════ SERVICES ═══════════════ -->
<section class="ls-section ls-services" id="services" aria-labelledby="ls-svc-heading">
  <div class="ls-container">
    <div class="ls-services__intro">
      <span class="ls-tag">What We Do</span>
      <h2 class="ls-h2" id="ls-svc-heading">Complete Locksmith Services</h2>
      <p class="ls-lead" style="margin:0 auto;">Emergency lockouts, security upgrades, key cutting, safe opening and more — available 24/7, 365 days a year.</p>
    </div>
    <div class="ls-services__grid">
      <?php foreach ($services as $svc): ?>
      <article class="ls-svc" role="listitem">
        <span class="ls-svc__icon" aria-hidden="true"><?= $svc['icon'] ?></span>
        <h3 class="ls-svc__title"><?= esc_html($svc['title']) ?></h3>
        <p class="ls-svc__desc"><?= esc_html($svc['desc']) ?></p>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ SCENARIOS ═══════════════ -->
<section class="ls-section ls-section--dark ls-scenarios" aria-labelledby="ls-scen-heading">
  <div class="ls-container">
    <div class="ls-scenarios__intro">
      <span class="ls-tag ls-tag--light">We Handle Every Situation</span>
      <h2 class="ls-h2" id="ls-scen-heading" style="color:#fff;">Common Situations We Solve</h2>
      <p class="ls-lead" style="color:var(--ls-chrome-lt);margin:0 auto;">Whatever your situation — lockout, upgrade, repair or emergency — we have the training and tools to resolve it fast.</p>
    </div>
    <div class="ls-scenarios__cloud" role="list">
      <?php foreach ($scenarios as $scen): ?>
      <span class="ls-scen-tag" role="listitem"><?= esc_html($scen) ?></span>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ ABOUT ═══════════════ -->
<section class="ls-section ls-about ls-section--ice" id="about" aria-labelledby="ls-about-heading">
  <div class="ls-container">
    <div class="ls-about__grid">
      <div class="ls-about__visual">
        <div class="ls-id-card" role="img" aria-label="Engineer credential card for James Lockwood MLA">
          <div class="ls-id-card__header">
            <div class="ls-eng-fig" aria-hidden="true">
              <div class="ls-eng-fig__head"></div>
              <div class="ls-eng-fig__body"></div>
            </div>
            <h3>James Lockwood MLA</h3>
            <p>Master Locksmith — 20 Years' Experience</p>
          </div>
          <div class="ls-id-card__body">
            <div class="ls-id-card__row"><span>Membership</span><span>MLA Full Member</span></div>
            <div class="ls-id-card__row"><span>DBS Check</span><span>Enhanced (2025)</span></div>
            <div class="ls-id-card__row"><span>Insurance</span><span>£5M Public Liability</span></div>
            <div class="ls-id-card__row"><span>Specialism</span><span>High-Security Systems</span></div>
            <div class="ls-id-card__row"><span>Experience</span><span>20 Years</span></div>
          </div>
        </div>
        <div class="ls-cert-badges">
          <div class="ls-cert-badge">MLA Member</div>
          <div class="ls-cert-badge">Which? Trusted</div>
          <div class="ls-cert-badge">BS3621 Approved</div>
          <div class="ls-cert-badge">DBS Checked</div>
        </div>
      </div>

      <div class="ls-about__text">
        <span class="ls-tag">About Us</span>
        <h2 class="ls-h2" id="ls-about-heading">Trusted Locksmiths for 20 Years</h2>
        <p>Lockwood Locksmiths was established in 2005 with a commitment to honest pricing, fast response and genuine expertise. Every engineer is a fully qualified member of the Master Locksmith Association (MLA), DBS-checked, and carries £5 million public liability insurance as standard.</p>
        <p>We believe in transparency: you receive a fixed price over the phone before we arrive, with no hidden extras, call-out fees or weekend surcharges. If we cannot gain entry without damage, we will tell you — and only proceed with your explicit agreement.</p>
        <ul class="ls-about__feats" aria-label="Company highlights">
          <li>All engineers are MLA-qualified and DBS-checked</li>
          <li>Fixed prices quoted over the phone — no surprises</li>
          <li>Zero call-out fee, day or night, 365 days a year</li>
          <li>Non-destructive entry attempted in every case</li>
          <li>Written job certificate accepted by all insurers</li>
          <li>Which? Trusted Trader — independently verified</li>
        </ul>
        <a href="#booking" class="ls-btn ls-btn--gold">Get a Free Quote</a>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════ APPROACH ═══════════════ -->
<section class="ls-section ls-approach" aria-labelledby="ls-approach-heading">
  <div class="ls-container">
    <div class="ls-approach__intro">
      <span class="ls-tag ls-tag--light">How It Works</span>
      <h2 class="ls-h2" id="ls-approach-heading" style="color:#fff;">From Call to Completion</h2>
      <p class="ls-lead" style="color:var(--ls-chrome-lt);margin:0 auto;">A fast, stress-free process designed to get you back inside as quickly and affordably as possible.</p>
    </div>
    <div class="ls-approach__grid" role="list">
      <?php foreach ($steps as $step): ?>
      <div class="ls-step" role="listitem">
        <div class="ls-step__num" aria-hidden="true"><?= esc_html($step['num']) ?></div>
        <h3 class="ls-step__title"><?= esc_html($step['title']) ?></h3>
        <p class="ls-step__desc"><?= esc_html($step['desc']) ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ GALLERY ═══════════════ -->
<section class="ls-section ls-section--ice" aria-labelledby="ls-gallery-heading">
  <div class="ls-container">
    <div style="text-align:center;margin-bottom:48px;">
      <span class="ls-tag">Our Range</span>
      <h2 class="ls-h2" id="ls-gallery-heading">Products &amp; Services</h2>
    </div>
    <div class="ls-gallery__grid" role="list">
      <?php foreach ($gallery as $panel): ?>
      <div class="ls-gallery__item" role="listitem">
        <div class="ls-gallery__panel" style="background:<?= esc_attr($panel['color']) ?>;" aria-label="<?= esc_attr($panel['label']) ?>">
          <span aria-hidden="true" style="font-size:3.5rem;"><?= $panel['icon'] ?></span>
        </div>
        <div class="ls-gallery__overlay" aria-hidden="true">
          <span><?= esc_html($panel['label']) ?></span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ COUNTERS ═══════════════ -->
<section class="ls-section ls-counters" aria-labelledby="ls-counters-heading">
  <div class="ls-container">
    <h2 class="sr-only" id="ls-counters-heading">Business statistics</h2>
    <div class="ls-counters__grid">
      <?php foreach ($counters as $c): ?>
      <div>
        <span class="ls-counter__val"
              data-target="<?= esc_attr($c['val']) ?>"
              data-suffix="<?= esc_attr($c['suffix']) ?>"
              <?= $c['float'] ? 'data-float="1"' : '' ?>
              aria-label="<?= esc_attr($c['val'] . $c['suffix'] . ' — ' . $c['label']) ?>">0</span>
        <p class="ls-counter__label"><?= esc_html($c['label']) ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ PACKAGES ═══════════════ -->
<section class="ls-section ls-packages" id="packages" aria-labelledby="ls-pkg-heading">
  <div class="ls-container">
    <div class="ls-packages__intro">
      <span class="ls-tag">Pricing</span>
      <h2 class="ls-h2" id="ls-pkg-heading">Clear, Fixed Prices</h2>
      <p class="ls-lead" style="margin:0 auto;">No call-out charges. No hidden fees. Prices agreed before work begins. VAT-registered — invoices issued on completion.</p>
    </div>
    <div class="ls-packages__grid">
      <?php foreach ($packages as $pkg): ?>
      <div class="ls-pkg <?= $pkg['featured'] ? 'ls-pkg--featured' : '' ?>">
        <?php if ($pkg['featured']): ?><div class="ls-pkg__badge">Best Value</div><?php endif; ?>
        <h3 class="ls-pkg__name"><?= esc_html($pkg['name']) ?></h3>
        <div class="ls-pkg__price"><?= esc_html($pkg['price']) ?></div>
        <div class="ls-pkg__per"><?= esc_html($pkg['per']) ?></div>
        <ul class="ls-pkg__features" aria-label="<?= esc_attr($pkg['name']) ?> package features">
          <?php foreach ($pkg['features'] as $f): ?>
          <li><?= esc_html($f) ?></li>
          <?php endforeach; ?>
        </ul>
        <a href="#booking" class="ls-btn <?= $pkg['featured'] ? 'ls-btn--gold' : 'ls-btn--ghost' ?>">
          Book Now
        </a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ TESTIMONIALS ═══════════════ -->
<section class="ls-section ls-testimonials" aria-labelledby="ls-testi-heading">
  <div class="ls-container">
    <div class="ls-testimonials__intro">
      <span class="ls-tag">Reviews</span>
      <h2 class="ls-h2" id="ls-testi-heading">Trusted by Thousands</h2>
      <p class="ls-lead" style="margin:0 auto;">Over 2,000 five-star reviews on Google and Which? — see why our customers keep recommending us.</p>
    </div>
    <div class="ls-testimonials__grid">
      <?php foreach ($testimonials as $t): ?>
      <blockquote class="ls-testi">
        <div class="ls-testi__stars" aria-label="<?= esc_attr($t['rating']) ?> stars"><?= str_repeat('★',$t['rating']) ?></div>
        <p class="ls-testi__text"><?= esc_html($t['text']) ?></p>
        <footer>
          <div class="ls-testi__name"><?= esc_html($t['name']) ?></div>
          <div class="ls-testi__role"><?= esc_html($t['role']) ?></div>
        </footer>
      </blockquote>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ BOOKING ═══════════════ -->
<section class="ls-section ls-booking" id="booking" aria-labelledby="ls-booking-heading">
  <div class="ls-container">
    <div class="ls-booking__inner">
      <div class="ls-booking__info">
        <span class="ls-tag ls-tag--light">Get Help Now</span>
        <h2 class="ls-h2" id="ls-booking-heading">Call or Request a Quote</h2>
        <p>For emergencies, always call our 24-hour line — we'll dispatch the nearest engineer immediately. For non-urgent enquiries, complete the form and we'll respond within the hour during business hours.</p>
        <ul class="ls-booking__list" aria-label="Service promises">
          <li><span>📞</span><span>24/7 emergency phone line — always answered</span></li>
          <li><span>⏱️</span><span>30-minute guaranteed arrival for lockouts</span></li>
          <li><span>💷</span><span>Fixed prices given over the phone — no surprises</span></li>
          <li><span>🔓</span><span>Non-destructive entry — no unnecessary damage</span></li>
          <li><span>📋</span><span>Insurance certificate issued on completion</span></li>
        </ul>
      </div>
      <div class="ls-form">
        <?php
          if (!empty($_POST['tf_ls_nonce']) && wp_verify_nonce($_POST['tf_ls_nonce'],'tf_ls_booking')) {
            echo '<p style="color:var(--ls-gold);font-weight:700;margin-bottom:16px;">🔑 Request received — we\'ll be in touch within the hour!</p>';
          }
        ?>
        <form method="post" action="<?php echo esc_url(get_permalink()); ?>#booking" novalidate>
          <?php wp_nonce_field('tf_ls_booking','tf_ls_nonce'); ?>
          <div class="ls-form__row">
            <div class="ls-form__group">
              <label for="ls_name">Name <span style="color:var(--ls-gold)">*</span></label>
              <input type="text" id="ls_name" name="ls_name" placeholder="Your full name" required autocomplete="name">
            </div>
            <div class="ls-form__group">
              <label for="ls_phone">Phone <span style="color:var(--ls-gold)">*</span></label>
              <input type="tel" id="ls_phone" name="ls_phone" placeholder="+44 7700 900000" required autocomplete="tel">
            </div>
          </div>
          <div class="ls-form__group">
            <label for="ls_service">Service Required <span style="color:var(--ls-gold)">*</span></label>
            <select id="ls_service" name="ls_service" required>
              <option value="">Select service…</option>
              <option value="lockout-home">Home Lockout — Emergency</option>
              <option value="lockout-car">Car Lockout — Emergency</option>
              <option value="lockout-office">Office / Commercial Lockout</option>
              <option value="lock-install">Lock Installation / Upgrade</option>
              <option value="lock-repair">Lock Repair</option>
              <option value="key-cutting">Key Cutting</option>
              <option value="safe">Safe Opening / Service</option>
              <option value="security-survey">Free Security Survey</option>
            </select>
          </div>
          <div class="ls-form__row">
            <div class="ls-form__group">
              <label for="ls_postcode">Postcode <span style="color:var(--ls-gold)">*</span></label>
              <input type="text" id="ls_postcode" name="ls_postcode" placeholder="e.g. OX1 1AA" required autocomplete="postal-code">
            </div>
            <div class="ls-form__group">
              <label for="ls_timing">When Do You Need Us?</label>
              <select id="ls_timing" name="ls_timing">
                <option value="now">Right Now — Emergency</option>
                <option value="today">Today</option>
                <option value="tomorrow">Tomorrow</option>
                <option value="this-week">This Week</option>
                <option value="quote-only">Quote Only — No Rush</option>
              </select>
            </div>
          </div>
          <div class="ls-form__group">
            <label for="ls_notes">Details</label>
            <textarea id="ls_notes" name="ls_notes" placeholder="Describe your lock type, door type, or any other relevant details…"></textarea>
          </div>
          <button type="submit" class="ls-form__submit">🔑 Submit Enquiry</button>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════ FOOTER ═══════════════ -->
<footer class="ls-footer">
  <div class="ls-container">
    <p>&copy; <?php echo esc_html(date('Y')); ?> <?php bloginfo('name'); ?> &mdash; Lockwood Locksmiths. MLA Member. DBS Checked. All rights reserved.</p>
  </div>
</footer>

</div><!-- /.ls-wrap -->

<script>
(function(){
  'use strict';

  /* ── Animated counters ─────────────────────────────── */
  var easeOut = function(t){ return 1 - Math.pow(1 - t, 3); };
  var counters = document.querySelectorAll('.ls-counter__val[data-target]');

  if ('IntersectionObserver' in window) {
    var obs = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if (!entry.isIntersecting) return;
        obs.unobserve(entry.target);
        var el     = entry.target;
        var target = parseFloat(el.dataset.target);
        var suffix = el.dataset.suffix || '';
        var isFloat= el.dataset.float === '1';
        if (isNaN(target)) return;
        var duration = 1800, start = null;
        function tick(ts){
          if (!start) start = ts;
          var p = Math.min((ts - start) / duration, 1);
          var v = target * easeOut(p);
          el.textContent = (isFloat ? v.toFixed(1) : Math.floor(v)) + suffix;
          if (p < 1) requestAnimationFrame(tick);
          else el.textContent = (isFloat ? target.toFixed(1) : target) + suffix;
        }
        requestAnimationFrame(tick);
      });
    }, { threshold: 0.4 });
    counters.forEach(function(el){ obs.observe(el); });
  } else {
    counters.forEach(function(el){
      el.textContent = el.dataset.target + (el.dataset.suffix || '');
    });
  }

  /* ── Tumbler random spin on page load ─────────────── */
  var tumblers = document.querySelectorAll('.ls-tumbler');
  tumblers.forEach(function(t){
    var digits = '0123456789';
    var finalChar = t.textContent;
    var count = 0, max = 8;
    var interval = setInterval(function(){
      t.textContent = digits[Math.floor(Math.random() * 10)];
      count++;
      if (count >= max) { clearInterval(interval); t.textContent = finalChar; }
    }, 80);
  });

  /* ── Mouse parallax on particles ──────────────────── */
  var particles = document.querySelectorAll('.ls-particle');
  var hero = document.querySelector('.ls-hero');
  if (hero) {
    hero.addEventListener('mousemove', function(e){
      var rect = hero.getBoundingClientRect();
      var dx = (e.clientX - rect.left - rect.width / 2) / rect.width;
      var dy = (e.clientY - rect.top - rect.height / 2) / rect.height;
      particles.forEach(function(p, i){
        var depth = (i % 4 + 1) * 6;
        p.style.transform = 'translate(' + (dx * depth) + 'px, ' + (dy * depth) + 'px)';
      });
    });
  }

})();
</script>

</body>
</html>
</div><!-- .ls-page -->
<?php get_footer(); ?>
