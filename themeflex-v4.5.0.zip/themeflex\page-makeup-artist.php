<?php
/**
 * Template Name: Makeup Artist
 * Description: Premium makeup artist / beauty professional homepage template
 *
 * @package ThemeFlex
 */

// ── Deterministic randomness ────────────────────────────────────────────────
srand( crc32( get_the_permalink() ) );

// ── Artist data ─────────────────────────────────────────────────────────────
$artist = [
    'name'     => 'Celeste Moreau',
    'title'    => 'Celebrity & Bridal Makeup Artist · London & Destination',
    'tagline'  => 'Beauty That Moves You',
    'bio'      => 'With 13 years of experience across editorial, film, television and bridal work, Celeste Moreau transforms faces and elevates confidence. Trained at the London College of Fashion and mentored by top industry names, she blends technical precision with artistic intuition to create looks that are uniquely and unmistakably you.',
    'bio2'     => 'From intimate elopements to 300-guest grand weddings, glossy magazine shoots to screen work for BBC and Channel 4 — Celeste brings the same dedication and artistry to every face she touches.',
    'years'    => 13,
    'clients'  => 2800,
    'rating'   => 5.0,
    'weddings' => 420,
];

// ── Services ─────────────────────────────────────────────────────────────────
$services = [
    [ 'icon' => '💍', 'title' => 'Bridal Makeup',        'desc' => 'Long-wear, photograph-perfect looks tailored to your dress, venue and vision — from natural to full glam.' ],
    [ 'icon' => '👰', 'title' => 'Bridal Party',          'desc' => 'Cohesive, complementary looks for bridesmaids, mothers and flower girls on your special day.' ],
    [ 'icon' => '📷', 'title' => 'Editorial / Shoot',     'desc' => 'Magazine-ready artistry for fashion shoots, campaigns, lookbooks and brand photography.' ],
    [ 'icon' => '🎬', 'title' => 'Film & TV',             'desc' => 'Screen-tested HD makeup for broadcast, streaming, commercials and documentary production.' ],
    [ 'icon' => '🎭', 'title' => 'Special Events',        'desc' => 'Red carpet, charity galas, award ceremonies — unforgettable looks for your most important nights.' ],
    [ 'icon' => '✨', 'title' => 'Glam Occasion',         'desc' => 'Birthday, hen-do, anniversary, prom — professional makeup for life\'s celebratory moments.' ],
    [ 'icon' => '🎓', 'title' => 'Masterclass',           'desc' => 'Private or group masterclasses: learn techniques tailored to your face, skin and lifestyle.' ],
    [ 'icon' => '🧴', 'title' => 'Skin Prep Consultation','desc' => 'Pre-event skin analysis and preparation routine to ensure your makeup sits perfectly all day.' ],
];

// ── Packages ─────────────────────────────────────────────────────────────────
$packages = [
    [
        'name'     => 'Bridal Glow',
        'price'    => '£380',
        'period'   => 'bride only',
        'colour'   => 'blush',
        'features' => [
            'Bridal makeup trial (2hrs)',
            'Wedding day application',
            'Full HD-ready product kit',
            'Touch-up kit to take away',
            'Up to 2.5 hrs on the day',
        ],
        'featured' => false,
    ],
    [
        'name'     => 'Wedding Party',
        'price'    => '£680',
        'period'   => 'bride + 3 guests',
        'colour'   => 'rose',
        'features' => [
            'Bridal trial + wedding day',
            'Makeup for 3 additional guests',
            'Full product kit throughout',
            'Cohesive colour story',
            'Early-morning start available',
            'Lash application included',
            'Touch-up consultation',
        ],
        'featured' => true,
    ],
    [
        'name'     => 'Full Bridal Suite',
        'price'    => '£1,100',
        'period'   => 'bride + full party',
        'colour'   => 'mauve',
        'features' => [
            'Trial + up to 6 guests',
            'Dedicated assistant artist',
            'Pre-wedding skin consult',
            'Premium luxury product kit',
            'Hairstyling coordination',
            'On-site touch-ups (4hrs)',
            'Wedding-day timeline plan',
        ],
        'featured' => false,
    ],
];

// ── Process ───────────────────────────────────────────────────────────────────
$steps = [
    [ 'num' => '01', 'title' => 'Enquiry & Consultation', 'desc' => 'Tell Celeste your vision, event type and date. She\'ll check availability and get to know your style.' ],
    [ 'num' => '02', 'title' => 'Colour & Skin Consult',  'desc' => 'A detailed skin tone, undertone and lifestyle assessment to plan your perfect look.' ],
    [ 'num' => '03', 'title' => 'Bridal Trial',            'desc' => 'A full dress rehearsal of your chosen look — refine and perfect before the big day.' ],
    [ 'num' => '04', 'title' => 'Day of Glam',             'desc' => 'Celeste arrives calm, fully prepared and focused on making you feel utterly beautiful.' ],
    [ 'num' => '05', 'title' => 'Touch-Up & Beyond',       'desc' => 'A touch-up kit and aftercare guide ensure your look stays flawless all day and night.' ],
];

// ── FAQs ─────────────────────────────────────────────────────────────────────
$faqs = [
    [ 'q' => 'How far in advance should I book?', 'a' => 'Bridal dates book 12–18 months ahead for peak season (May–September). Editorial and event work typically 4–8 weeks. Contact Celeste early to avoid disappointment.' ],
    [ 'q' => 'Do you travel to destination weddings?', 'a' => 'Yes! Celeste travels internationally. Destination packages include travel and accommodation in the fee. Popular locations include Italy, France, Greece and Dubai.' ],
    [ 'q' => 'What products do you use?', 'a' => 'Celeste works with a curated kit of professional-grade brands including Charlotte Tilbury, NARS, MAC, Armani Beauty and Dior. All products are cruelty-free. Vegan-only options available on request.' ],
    [ 'q' => 'Can you accommodate sensitive skin or allergies?', 'a' => 'Absolutely. Celeste is trained in working with sensitive skin, rosacea, eczema and known allergies. Please disclose any sensitivities at booking so the kit can be adapted.' ],
    [ 'q' => 'Is an airbrush finish available?', 'a' => 'Yes — HD airbrush is available as an upgrade on all packages and is particularly popular for film work and outdoor summer weddings.' ],
    [ 'q' => 'What\'s included in the masterclass?', 'a' => 'Masterclasses run 2–3 hours and are fully tailored to you. You\'ll learn techniques for your specific face shape, skin type and daily routine. All products and brushes provided.' ],
];

// ── Floating glitter positions ────────────────────────────────────────────────
$glitters = [];
for ( $i = 0; $i < 22; $i++ ) {
    $glitters[] = [
        'top'    => rand( 3, 92 ),
        'left'   => rand( 2, 96 ),
        'size'   => rand( 3, 10 ),
        'delay'  => round( $i * 0.3, 2 ),
        'dur'    => round( rand( 20, 50 ) / 10, 1 ),
        'colour' => [ '#FFD6E0', '#FFC0CB', '#E8B4C8', '#C9A0DC', '#FFE4E1', '#F7CAC9', '#FADADD' ][ $i % 7 ],
    ];
}

// ── Brush sizes ───────────────────────────────────────────────────────────────
$brushes = [
    [ 'w' => 8, 'h' => 130, 'col' => '#C9A0DC', 'rot' => -15 ],
    [ 'w' => 6, 'h' => 110, 'col' => '#E8B4C8', 'rot' => -5  ],
    [ 'w' => 10,'h' => 145, 'col' => '#F7CAC9', 'rot' => 8   ],
    [ 'w' => 7, 'h' => 120, 'col' => '#C9A0DC', 'rot' => 20  ],
    [ 'w' => 5, 'h' => 100, 'col' => '#E8B4C8', 'rot' => -28 ],
];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════════════════════════
   MAKEUP ARTIST TEMPLATE  —  namespace: --ma-*
   ═══════════════════════════════════════════════════════════════════════════ */
:root {
  --ma-blush:  #F7CAC9;
  --ma-rose:   #E8B4C8;
  --ma-mauve:  #C9A0DC;
  --ma-nude:   #EDD5C0;
  --ma-deep:   #2C1A2E;
  --ma-plum:   #5E3565;
  --ma-cream:  #FDF8F5;
  --ma-warm:   #F9F0EA;
  --ma-mid:    #7A6575;
  --ma-light:  #FEF5F8;
  --ma-shadow: rgba(92,53,101,.12);
  --ma-r:      16px;
  --ma-ff:     'Playfair Display', Georgia, serif;
  --ma-ff2:    'Lato', sans-serif;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body.ma-page{font-family:var(--ma-ff2);color:var(--ma-deep);background:var(--ma-cream);line-height:1.75}
img{max-width:100%;display:block}
a{color:inherit;text-decoration:none}
.ma-page h1,.ma-page h2,.ma-page h3,.ma-page h4{font-family:var(--ma-ff);font-weight:700;line-height:1.2}

/* ── LAYOUT ── */
.ma-wrap{max-width:1160px;margin:0 auto;padding:0 24px}
.ma-section{padding:96px 0}
.ma-section--alt{background:#fff}
.ma-section--light{background:var(--ma-light)}
.ma-tag{display:inline-block;font-family:var(--ma-ff2);font-size:.72rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--ma-plum);background:rgba(94,53,101,.1);padding:6px 18px;border-radius:99px;margin-bottom:18px}

/* ── HERO ── */
.ma-hero{position:relative;min-height:100vh;display:flex;align-items:center;overflow:hidden;background:linear-gradient(135deg,#1A0A1E 0%,#2C1A2E 35%,#3D1F45 65%,#2C1A2E 100%)}
.ma-hero::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse 70% 60% at 60% 40%,rgba(201,160,220,.15) 0%,transparent 65%)}

/* bokeh orbs */
.ma-bokeh{position:absolute;border-radius:50%;filter:blur(40px);animation:ma-bokeh-float var(--bk-dur,8s) ease-in-out var(--bk-d,0s) infinite alternate}
@keyframes ma-bokeh-float{0%{transform:translate(0,0) scale(1)}100%{transform:translate(var(--bk-tx,20px),var(--bk-ty,-20px)) scale(1.1)}}

/* glitter particles */
.ma-glitter{position:absolute;border-radius:50%;animation:ma-glitter-twinkle var(--gl-dur,3s) ease-in-out var(--gl-d,0s) infinite alternate}
@keyframes ma-glitter-twinkle{0%{opacity:.15;transform:scale(1) rotate(0deg)}50%{opacity:.9;transform:scale(1.4) rotate(180deg)}100%{opacity:.2;transform:scale(.8) rotate(360deg)}}

/* vanity mirror */
.ma-mirror{position:absolute;right:8%;top:50%;transform:translateY(-50%);z-index:4}
.ma-mirror-frame{width:220px;height:310px;border-radius:110px 110px 60px 60px;background:linear-gradient(145deg,#3D2A4A 0%,#2C1A2E 100%);padding:12px;box-shadow:0 0 60px rgba(201,160,220,.3),inset 0 0 20px rgba(0,0,0,.4)}
.ma-mirror-glass{width:100%;height:100%;border-radius:100px 100px 50px 50px;background:radial-gradient(ellipse at 35% 30%,rgba(255,255,255,.08) 0%,rgba(201,160,220,.05) 50%,rgba(44,26,46,.9) 100%);position:relative;overflow:hidden}
/* face reflection */
.ma-face{position:absolute;top:22%;left:50%;transform:translateX(-50%);width:80px;height:90px}
.ma-face-oval{width:80px;height:90px;background:linear-gradient(160deg,#F5D5B0 0%,#EEC298 100%);border-radius:50%;border:2px solid rgba(255,255,255,.1)}
.ma-face-eye{position:absolute;top:32px;width:14px;height:8px;background:#2C1A2E;border-radius:50%;border-bottom:3px solid #E8B4C8}
.ma-face-eye--l{left:16px}
.ma-face-eye--r{right:16px}
.ma-face-lash{position:absolute;top:28px;width:18px;height:3px;background:#2C1A2E;border-radius:99px;transform-origin:right center}
.ma-face-lash--l{left:12px;transform:rotate(-5deg)}
.ma-face-lash--r{right:12px;transform:rotate(5deg) scaleX(-1)}
.ma-face-brow{position:absolute;top:22px;width:16px;height:3px;background:#5E3565;border-radius:99px;transform:rotate(-5deg)}
.ma-face-brow--l{left:15px}
.ma-face-brow--r{right:15px;transform:rotate(5deg)}
.ma-face-nose{position:absolute;top:50px;left:50%;transform:translateX(-50%);width:12px;height:10px;border-radius:0 0 50% 50%;border:2px solid rgba(180,120,80,.4);border-top:none}
.ma-face-lips{position:absolute;bottom:18px;left:50%;transform:translateX(-50%);width:28px;height:14px}
.ma-face-lips-top{width:28px;height:8px;background:var(--ma-rose);border-radius:50% 50% 0 0;clip-path:polygon(0 100%,20% 0,50% 40%,80% 0,100% 100%)}
.ma-face-lips-bot{width:28px;height:10px;background:var(--ma-blush);border-radius:0 0 50% 50%;margin-top:-2px}
/* blush on cheeks */
.ma-face-blush{position:absolute;top:46px;width:22px;height:12px;background:rgba(247,202,201,.6);border-radius:50%;filter:blur(4px)}
.ma-face-blush--l{left:2px}
.ma-face-blush--r{right:2px}
/* highlight dot */
.ma-face-highlight{position:absolute;top:28px;left:18px;width:5px;height:5px;background:rgba(255,255,255,.8);border-radius:50%}
/* mirror bulbs */
.ma-bulb-row{display:flex;justify-content:space-between;padding:0 8px;margin-top:8px}
.ma-bulb{width:16px;height:16px;border-radius:50%;background:radial-gradient(circle at 35% 35%,#FFF8DC,#FFC107);box-shadow:0 0 10px 3px rgba(255,193,7,.5);animation:ma-bulb-pulse 2s ease-in-out var(--bl-d,0s) infinite alternate}
@keyframes ma-bulb-pulse{0%{box-shadow:0 0 8px 2px rgba(255,193,7,.4)}100%{box-shadow:0 0 18px 6px rgba(255,193,7,.7)}}

/* makeup products */
.ma-products{position:absolute;bottom:32%;left:6%;z-index:4;display:flex;gap:12px;align-items:flex-end}
.ma-lipstick{width:14px;height:60px;position:relative}
.ma-lipstick__tube{width:14px;height:42px;background:linear-gradient(180deg,#C0392B,#922B21);border-radius:2px 2px 0 0;position:absolute;bottom:0}
.ma-lipstick__bullet{position:absolute;top:-16px;left:0;width:14px;height:22px;background:var(--ma-rose);border-radius:50% 50% 0 0;animation:ma-bullet-glow 2s ease-in-out infinite alternate}
@keyframes ma-bullet-glow{0%{box-shadow:0 0 6px rgba(232,180,200,.4)}100%{box-shadow:0 0 14px rgba(232,180,200,.9)}}
.ma-palette{width:70px;height:50px;background:linear-gradient(145deg,#F5F0F5,#EEE8EE);border-radius:8px;border:2px solid rgba(201,160,220,.4);display:grid;grid-template-columns:repeat(4,1fr);gap:3px;padding:5px;box-shadow:0 4px 16px rgba(0,0,0,.3)}
.ma-swatch{border-radius:50%;border:1px solid rgba(255,255,255,.3)}
.ma-brush-fan{position:absolute;bottom:32%;right:6%;z-index:4;display:flex;gap:8px;align-items:flex-end}
.ma-brush{position:relative;display:flex;flex-direction:column;align-items:center}
.ma-brush__handle{border-radius:2px;background:linear-gradient(180deg,#F7CAC9,#C9A0DC)}
.ma-brush__ferrule{width:calc(var(--bw) + 2px);height:16px;background:#C0C0C0;border-radius:1px}
.ma-brush__head{border-radius:50% 50% 0 0;background:linear-gradient(180deg,rgba(255,255,255,.9),rgba(240,230,235,.5))}

/* hero content */
.ma-hero__content{position:relative;z-index:10;max-width:580px;padding:40px 0 180px}
.ma-hero__eyebrow{font-family:var(--ma-ff2);font-size:.78rem;font-weight:700;letter-spacing:.18em;text-transform:uppercase;color:var(--ma-blush);margin-bottom:20px}
.ma-hero__title{font-family:var(--ma-ff);font-size:clamp(2.4rem,5.5vw,4.2rem);font-weight:700;color:#fff;line-height:1.08;margin-bottom:24px}
.ma-hero__title em{color:var(--ma-blush);font-style:italic}
.ma-hero__sub{font-size:1.1rem;color:rgba(255,255,255,.75);max-width:440px;margin-bottom:40px;line-height:1.75}
.ma-hero__ctas{display:flex;gap:16px;flex-wrap:wrap}
.ma-btn{display:inline-flex;align-items:center;gap:8px;font-family:var(--ma-ff2);font-weight:700;font-size:.92rem;padding:14px 32px;border-radius:99px;cursor:pointer;border:none;transition:transform .2s,box-shadow .2s;letter-spacing:.04em}
.ma-btn--primary{background:linear-gradient(135deg,var(--ma-blush),var(--ma-rose));color:var(--ma-deep)}
.ma-btn--primary:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(232,180,200,.5)}
.ma-btn--ghost{background:transparent;color:#fff;border:1.5px solid rgba(255,255,255,.4)}
.ma-btn--ghost:hover{background:rgba(255,255,255,.08)}

/* ── COUNTERS ── */
.ma-counters{display:grid;grid-template-columns:repeat(4,1fr);gap:28px}
.ma-counter{text-align:center;padding:36px 18px;background:#fff;border-radius:var(--ma-r);box-shadow:0 4px 20px var(--ma-shadow);border-bottom:3px solid var(--ma-rose)}
.ma-counter__num{font-family:var(--ma-ff);font-size:2.6rem;font-weight:700;color:var(--ma-plum);line-height:1}
.ma-counter__label{font-size:.86rem;color:var(--ma-mid);margin-top:10px;font-family:var(--ma-ff2)}

/* ── SERVICES ── */
.ma-services-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:24px;margin-top:52px}
.ma-service-card{background:#fff;border-radius:var(--ma-r);padding:32px 26px;box-shadow:0 4px 20px var(--ma-shadow);position:relative;overflow:hidden;transition:transform .25s,box-shadow .25s}
.ma-service-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--ma-blush),var(--ma-mauve))}
.ma-service-card:hover{transform:translateY(-4px);box-shadow:0 12px 32px var(--ma-shadow)}
.ma-service-card__icon{font-size:2rem;margin-bottom:16px}
.ma-service-card__title{font-family:var(--ma-ff);font-size:1.05rem;color:var(--ma-deep);margin-bottom:10px}
.ma-service-card__desc{font-size:.9rem;color:var(--ma-mid);line-height:1.65}

/* ── ABOUT ── */
.ma-about{display:grid;grid-template-columns:1fr 1fr;gap:72px;align-items:center}
.ma-about__figure{display:flex;justify-content:center;position:relative}
.ma-about__scene{width:300px;height:360px;border-radius:var(--ma-r);background:linear-gradient(145deg,var(--ma-light),#fff);box-shadow:0 8px 32px var(--ma-shadow);display:flex;flex-direction:column;align-items:center;justify-content:flex-end;overflow:hidden;position:relative;border:2px solid rgba(201,160,220,.2)}
.ma-ab-mirror-bg{position:absolute;top:0;left:0;right:0;height:55%;background:linear-gradient(180deg,#2C1A2E 0%,#3D1F45 100%)}
.ma-ab-mirror-lights{position:absolute;top:8px;left:0;right:0;display:flex;justify-content:space-around;padding:0 12px}
.ma-ab-bulb-sm{width:10px;height:10px;border-radius:50%;background:var(--ma-blush);opacity:.7;box-shadow:0 0 6px rgba(247,202,201,.8)}
.ma-ab-face{position:absolute;top:14%;left:50%;transform:translateX(-50%);width:70px;height:78px}
.ma-ab-face-oval{width:70px;height:78px;background:linear-gradient(160deg,#F5D5B0,#EEC298);border-radius:50%;border:2px solid rgba(255,255,255,.2)}
.ma-ab-eyes{position:absolute;top:28px;left:50%;transform:translateX(-50%);width:44px;display:flex;justify-content:space-between}
.ma-ab-eye{width:10px;height:7px;background:#2C1A2E;border-radius:50%;border-bottom:2px solid var(--ma-rose)}
.ma-ab-lips{position:absolute;bottom:16px;left:50%;transform:translateX(-50%);width:24px;height:12px;background:var(--ma-rose);border-radius:50%}
.ma-about__name{position:absolute;bottom:24px;text-align:center;z-index:2}
.ma-about__creds{margin-top:28px;display:flex;flex-direction:column;gap:12px}
.ma-cred{display:flex;align-items:center;gap:12px;padding:12px 18px;border-radius:10px;background:var(--ma-light);border-left:3px solid var(--ma-rose)}
.ma-cred__icon{font-size:1.2rem}
.ma-cred__text{font-size:.88rem;font-weight:700;color:var(--ma-deep)}

/* ── PROCESS ── */
.ma-process{display:flex;flex-direction:column;gap:0}
.ma-step{display:flex;gap:24px;padding:24px 0;border-bottom:1px solid rgba(201,160,220,.2)}
.ma-step:last-child{border-bottom:none}
.ma-step__num{flex-shrink:0;width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,var(--ma-blush),var(--ma-mauve));display:flex;align-items:center;justify-content:center;font-family:var(--ma-ff2);font-weight:700;font-size:.9rem;color:var(--ma-deep)}
.ma-step__title{font-family:var(--ma-ff);font-size:1rem;color:var(--ma-deep);margin-bottom:5px}
.ma-step__desc{font-size:.9rem;color:var(--ma-mid)}

/* ── PACKAGES ── */
.ma-packages{display:grid;grid-template-columns:repeat(3,1fr);gap:28px;margin-top:52px;align-items:start}
.ma-pkg{border-radius:var(--ma-r);padding:40px 30px;background:#fff;box-shadow:0 4px 20px var(--ma-shadow);position:relative;transition:transform .25s}
.ma-pkg:hover{transform:translateY(-4px)}
.ma-pkg--rose{border-top:4px solid var(--ma-rose)}
.ma-pkg--blush{border-top:4px solid var(--ma-blush)}
.ma-pkg--mauve{border-top:4px solid var(--ma-mauve)}
.ma-pkg--featured{background:linear-gradient(145deg,var(--ma-deep) 0%,var(--ma-plum) 100%);color:#fff;box-shadow:0 12px 40px rgba(94,53,101,.4);transform:scale(1.04)}
.ma-pkg--featured:hover{transform:scale(1.04) translateY(-4px)}
.ma-pkg--featured .ma-pkg__name{color:#fff}
.ma-pkg--featured .ma-pkg__price{color:var(--ma-blush)}
.ma-pkg--featured .ma-pkg__period,.ma-pkg--featured .ma-pkg__feature{color:rgba(255,255,255,.8)}
.ma-pkg--featured .ma-pkg__feature::before{color:var(--ma-blush)}
.ma-pkg__ribbon{position:absolute;top:-1px;right:22px;background:linear-gradient(135deg,var(--ma-blush),var(--ma-rose));color:var(--ma-deep);font-size:.7rem;font-weight:700;padding:5px 14px;border-radius:0 0 8px 8px;letter-spacing:.05em;font-family:var(--ma-ff2)}
.ma-pkg__name{font-family:var(--ma-ff);font-size:1.2rem;color:var(--ma-deep);margin-bottom:8px}
.ma-pkg__price{font-family:var(--ma-ff);font-size:2.6rem;font-weight:700;color:var(--ma-plum);line-height:1}
.ma-pkg__period{font-size:.83rem;color:var(--ma-mid);margin-bottom:26px;font-family:var(--ma-ff2)}
.ma-pkg__features{list-style:none;display:flex;flex-direction:column;gap:10px;margin-bottom:30px}
.ma-pkg__feature{font-size:.88rem;padding-left:20px;position:relative;font-family:var(--ma-ff2)}
.ma-pkg__feature::before{content:'✦';position:absolute;left:0;color:var(--ma-rose);font-size:.7rem;top:2px}
.ma-pkg__btn{display:block;text-align:center;padding:13px;border-radius:99px;font-family:var(--ma-ff2);font-weight:700;font-size:.88rem;transition:opacity .2s;cursor:pointer;border:none}
.ma-pkg--blush .ma-pkg__btn{background:linear-gradient(135deg,var(--ma-blush),var(--ma-rose));color:var(--ma-deep)}
.ma-pkg--rose .ma-pkg__btn{background:linear-gradient(135deg,var(--ma-blush),var(--ma-mauve));color:#fff}
.ma-pkg--mauve .ma-pkg__btn{background:var(--ma-plum);color:#fff}
.ma-pkg__btn:hover{opacity:.85}

/* ── TESTIMONIALS ── */
.ma-testimonials{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:52px}
.ma-testimonial{background:#fff;border-radius:var(--ma-r);padding:28px;box-shadow:0 4px 16px var(--ma-shadow)}
.ma-testimonial__quote{font-family:var(--ma-ff);font-size:2rem;color:var(--ma-rose);opacity:.5;line-height:1}
.ma-testimonial__text{font-size:.9rem;line-height:1.75;color:var(--ma-mid);margin:8px 0 18px}
.ma-testimonial__name{font-weight:700;font-size:.9rem;color:var(--ma-deep)}
.ma-testimonial__event{font-size:.8rem;color:var(--ma-mid)}
.ma-stars{color:var(--ma-rose);letter-spacing:2px;font-size:.85rem}

/* ── FAQs ── */
.ma-faq-list{display:flex;flex-direction:column;gap:10px;margin-top:44px}
.ma-faq{border:1px solid rgba(201,160,220,.25);border-radius:10px;overflow:hidden;background:#fff}
.ma-faq__q{padding:18px 24px;font-family:var(--ma-ff);font-size:.98rem;color:var(--ma-deep);cursor:pointer;display:flex;justify-content:space-between;align-items:center;gap:16px}
.ma-faq__q::after{content:'＋';font-size:1.2rem;color:var(--ma-plum);flex-shrink:0;transition:transform .25s;font-family:var(--ma-ff2)}
.ma-faq.open .ma-faq__q::after{transform:rotate(45deg)}
.ma-faq__a{max-height:0;overflow:hidden;transition:max-height .35s ease}
.ma-faq.open .ma-faq__a{max-height:280px}
.ma-faq__a-inner{padding:0 24px 18px;font-size:.9rem;color:var(--ma-mid);line-height:1.72;font-family:var(--ma-ff2)}

/* ── BOOKING FORM ── */
.ma-form-wrap{background:linear-gradient(135deg,var(--ma-deep) 0%,var(--ma-plum) 100%);border-radius:var(--ma-r);padding:56px 52px;box-shadow:0 16px 56px rgba(44,26,46,.4)}
.ma-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}
.ma-form-grid .ma-fg--full{grid-column:1/-1}
.ma-field label{display:block;font-size:.78rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.6);margin-bottom:8px;font-family:var(--ma-ff2)}
.ma-field input,.ma-field select,.ma-field textarea{width:100%;padding:12px 16px;background:rgba(255,255,255,.08);border:1.5px solid rgba(255,255,255,.18);border-radius:8px;color:#fff;font-size:.93rem;font-family:var(--ma-ff2);transition:border-color .2s}
.ma-field input::placeholder,.ma-field textarea::placeholder{color:rgba(255,255,255,.35)}
.ma-field input:focus,.ma-field select:focus,.ma-field textarea:focus{outline:none;border-color:var(--ma-blush)}
.ma-field select option{background:var(--ma-deep);color:#fff}
.ma-field textarea{resize:vertical;min-height:90px}
.ma-form-note{font-size:.78rem;color:rgba(255,255,255,.4);margin-top:10px;font-family:var(--ma-ff2)}

/* ── CTA STRIP ── */
.ma-cta-strip{background:linear-gradient(135deg,var(--ma-blush) 0%,var(--ma-rose) 50%,var(--ma-mauve) 100%);padding:72px 0;text-align:center}
.ma-cta-strip h2{font-family:var(--ma-ff);font-size:2.4rem;color:var(--ma-deep);margin-bottom:14px}
.ma-cta-strip p{color:var(--ma-plum);font-size:1.05rem;margin-bottom:32px}

/* ── FOOTER ── */
.ma-footer-strip{background:var(--ma-deep);padding:26px 0;text-align:center}
.ma-footer-strip p{color:rgba(255,255,255,.4);font-size:.83rem;font-family:var(--ma-ff2)}

/* ── SECTION TITLES ── */
.ma-section-title{font-family:var(--ma-ff);font-size:clamp(1.8rem,3.5vw,2.6rem);color:var(--ma-deep);margin-bottom:16px}
.ma-section-sub{font-size:1.03rem;color:var(--ma-mid);max-width:560px;font-family:var(--ma-ff2)}

/* ── SCROLL REVEAL ── */
.ma-reveal{opacity:0;transform:translateY(28px);transition:opacity .65s,transform .65s}
.ma-reveal.visible{opacity:1;transform:none}

/* ── RESPONSIVE ── */
@media(max-width:900px){
  .ma-counters{grid-template-columns:repeat(2,1fr)}
  .ma-packages{grid-template-columns:1fr}
  .ma-pkg--featured{transform:none}
  .ma-about{grid-template-columns:1fr}
  .ma-testimonials{grid-template-columns:1fr}
  .ma-form-grid{grid-template-columns:1fr}
  .ma-mirror{display:none}
  .ma-brush-fan{display:none}
}
@media(max-width:600px){
  .ma-section{padding:64px 0}
  .ma-form-wrap{padding:32px 20px}
}
</style>
<?php get_header(); ?>
<div class="ma-page">
>
<?php wp_body_open(); ?>

<!-- ═══════════ HERO ═══════════ -->
<section class="ma-hero" id="home">

  <!-- Bokeh orbs -->
  <div class="ma-bokeh" style="top:15%;left:10%;width:200px;height:200px;background:rgba(201,160,220,.08);--bk-dur:9s;--bk-tx:30px;--bk-ty:-40px"></div>
  <div class="ma-bokeh" style="top:50%;left:40%;width:300px;height:300px;background:rgba(247,202,201,.06);--bk-dur:12s;--bk-d:2s;--bk-tx:-20px;--bk-ty:30px"></div>
  <div class="ma-bokeh" style="top:5%;right:15%;width:150px;height:150px;background:rgba(232,180,200,.1);--bk-dur:7s;--bk-d:1s;--bk-tx:15px;--bk-ty:25px"></div>

  <!-- Glitter particles -->
  <?php foreach ( $glitters as $gl ) : ?>
    <div class="ma-glitter" style="top:<?php echo $gl['top']; ?>%;left:<?php echo $gl['left']; ?>%;width:<?php echo $gl['size']; ?>px;height:<?php echo $gl['size']; ?>px;background:<?php echo $gl['colour']; ?>;--gl-dur:<?php echo $gl['dur']; ?>s;--gl-d:<?php echo $gl['delay']; ?>s"></div>
  <?php endforeach; ?>

  <!-- Vanity mirror -->
  <div class="ma-mirror">
    <div class="ma-bulb-row" style="margin-bottom:8px">
      <?php for($b=0;$b<5;$b++): ?>
      <div class="ma-bulb" style="--bl-d:<?php echo $b*.3; ?>s"></div>
      <?php endfor; ?>
    </div>
    <div class="ma-mirror-frame">
      <div class="ma-mirror-glass">
        <div class="ma-face">
          <div class="ma-face-oval"></div>
          <div class="ma-face-brow ma-face-brow--l"></div>
          <div class="ma-face-brow ma-face-brow--r"></div>
          <div class="ma-face-lash ma-face-lash--l"></div>
          <div class="ma-face-lash ma-face-lash--r"></div>
          <div class="ma-face-eye ma-face-eye--l"></div>
          <div class="ma-face-eye ma-face-eye--r"></div>
          <div class="ma-face-blush ma-face-blush--l"></div>
          <div class="ma-face-blush ma-face-blush--r"></div>
          <div class="ma-face-nose"></div>
          <div class="ma-face-lips">
            <div class="ma-face-lips-top"></div>
            <div class="ma-face-lips-bot"></div>
          </div>
          <div class="ma-face-highlight"></div>
        </div>
      </div>
    </div>
    <div class="ma-bulb-row" style="margin-top:8px">
      <?php for($b=0;$b<5;$b++): ?>
      <div class="ma-bulb" style="--bl-d:<?php echo .5 + $b*.3; ?>s"></div>
      <?php endfor; ?>
    </div>
  </div>

  <!-- Makeup products -->
  <div class="ma-products">
    <div class="ma-lipstick">
      <div class="ma-lipstick__tube"></div>
      <div class="ma-lipstick__bullet"></div>
    </div>
    <div class="ma-palette">
      <?php
      $swatches = ['#F7CAC9','#E8B4C8','#C9A0DC','#5E3565','#EDD5C0','#D4A574','#F5A623','#C0392B'];
      foreach($swatches as $sw): ?>
      <div class="ma-swatch" style="background:<?php echo $sw; ?>"></div>
      <?php endforeach; ?>
    </div>
    <div class="ma-lipstick" style="margin-left:4px">
      <div class="ma-lipstick__tube" style="background:linear-gradient(180deg,#6C3483,#4A235A)"></div>
      <div class="ma-lipstick__bullet" style="background:var(--ma-mauve)"></div>
    </div>
  </div>

  <!-- Brush fan -->
  <div class="ma-brush-fan">
    <?php foreach ( $brushes as $br ) : ?>
    <div class="ma-brush" style="transform:rotate(<?php echo $br['rot']; ?>deg);transform-origin:bottom center">
      <div class="ma-brush__head" style="width:<?php echo $br['w']+6; ?>px;height:<?php echo round($br['h']*.35); ?>px;background:<?php echo $br['col']; ?>;opacity:.7"></div>
      <div class="ma-brush__ferrule" style="--bw:<?php echo $br['w']; ?>px;width:<?php echo $br['w']+2; ?>px"></div>
      <div class="ma-brush__handle" style="width:<?php echo $br['w']; ?>px;height:<?php echo round($br['h']*.65); ?>px;background:linear-gradient(180deg,<?php echo $br['col']; ?>,var(--ma-deep))"></div>
    </div>
    <?php endforeach; ?>
  </div>

  <div class="ma-wrap">
    <div class="ma-hero__content">
      <p class="ma-hero__eyebrow">✦ Celebrity & Bridal Makeup Artist · London & Destination</p>
      <h1 class="ma-hero__title">
        <?php echo esc_html( $artist['tagline'] ); ?><br>
        <em>Every Face, Every Story</em>
      </h1>
      <p class="ma-hero__sub">
        Award-winning artistry for weddings, editorials, film & television. Making you feel <em>beautifully, unapologetically yourself</em>.
      </p>
      <div class="ma-hero__ctas">
        <a href="#booking" class="ma-btn ma-btn--primary">✦ Book Your Consultation</a>
        <a href="#services" class="ma-btn ma-btn--ghost">Explore Services</a>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ COUNTERS ═══════════ -->
<section class="ma-section ma-section--alt">
  <div class="ma-wrap">
    <div class="ma-counters">
      <div class="ma-counter ma-reveal">
        <div class="ma-counter__num" data-target="<?php echo $artist['years']; ?>">0</div>
        <div class="ma-counter__label">Years of Artistry</div>
      </div>
      <div class="ma-counter ma-reveal">
        <div class="ma-counter__num" data-target="<?php echo $artist['clients']; ?>" data-suffix="+">0</div>
        <div class="ma-counter__label">Faces Transformed</div>
      </div>
      <div class="ma-counter ma-reveal">
        <div class="ma-counter__num" data-target="<?php echo $artist['rating']; ?>" data-float="1" data-suffix="★">0</div>
        <div class="ma-counter__label">Average Rating</div>
      </div>
      <div class="ma-counter ma-reveal">
        <div class="ma-counter__num" data-target="<?php echo $artist['weddings']; ?>" data-suffix="+">0</div>
        <div class="ma-counter__label">Weddings &amp; Events</div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ SERVICES ═══════════ -->
<section class="ma-section ma-section--light" id="services">
  <div class="ma-wrap">
    <div class="ma-tag">What I Offer</div>
    <h2 class="ma-section-title">Services &amp; Occasions</h2>
    <p class="ma-section-sub">From your wedding day to your television screen — every service is crafted with the same level of artistry.</p>
    <div class="ma-services-grid">
      <?php foreach ( $services as $svc ) : ?>
      <div class="ma-service-card ma-reveal">
        <div class="ma-service-card__icon"><?php echo $svc['icon']; ?></div>
        <h3 class="ma-service-card__title"><?php echo esc_html( $svc['title'] ); ?></h3>
        <p class="ma-service-card__desc"><?php echo esc_html( $svc['desc'] ); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════ ABOUT ═══════════ -->
<section class="ma-section ma-section--alt" id="about">
  <div class="ma-wrap">
    <div class="ma-about">
      <div class="ma-about__figure">
        <div class="ma-about__scene">
          <div class="ma-ab-mirror-bg"></div>
          <div class="ma-ab-mirror-lights">
            <?php for($b=0;$b<6;$b++): ?>
            <div class="ma-ab-bulb-sm"></div>
            <?php endfor; ?>
          </div>
          <div class="ma-ab-face">
            <div class="ma-ab-face-oval"></div>
            <div class="ma-ab-eyes">
              <div class="ma-ab-eye"></div>
              <div class="ma-ab-eye"></div>
            </div>
            <div class="ma-ab-lips"></div>
          </div>
          <div class="ma-about__name">
            <p style="font-family:var(--ma-ff);font-size:.85rem;font-weight:700;color:var(--ma-deep)"><?php echo esc_html( $artist['name'] ); ?></p>
            <p style="font-size:.72rem;color:var(--ma-mid);font-family:var(--ma-ff2)">Celebrity & Bridal MUA</p>
          </div>
        </div>
      </div>
      <div>
        <div class="ma-tag">About Celeste</div>
        <h2 class="ma-section-title"><?php echo esc_html( $artist['name'] ); ?></h2>
        <p style="font-size:.88rem;font-weight:700;color:var(--ma-plum);margin-bottom:20px;font-family:var(--ma-ff2)"><?php echo esc_html( $artist['title'] ); ?></p>
        <p style="color:var(--ma-mid);line-height:1.8;margin-bottom:18px"><?php echo esc_html( $artist['bio'] ); ?></p>
        <p style="color:var(--ma-mid);line-height:1.8;margin-bottom:28px"><?php echo esc_html( $artist['bio2'] ); ?></p>
        <div class="ma-about__creds">
          <div class="ma-cred"><span class="ma-cred__icon">🎓</span><span class="ma-cred__text">London College of Fashion — Makeup Artistry Diploma</span></div>
          <div class="ma-cred"><span class="ma-cred__icon">🎬</span><span class="ma-cred__text">BBC, Channel 4 & Netflix Screen Credits</span></div>
          <div class="ma-cred"><span class="ma-cred__icon">💍</span><span class="ma-cred__text">420+ Bridal Clients · Vogue Featured Artist</span></div>
          <div class="ma-cred"><span class="ma-cred__icon">✈️</span><span class="ma-cred__text">International Destination Weddings: Italy, France, Greece, UAE</span></div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ PROCESS ═══════════ -->
<section class="ma-section ma-section--light" id="process">
  <div class="ma-wrap">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:72px;align-items:start">
      <div>
        <div class="ma-tag">The Experience</div>
        <h2 class="ma-section-title">How We Create Your Perfect Look</h2>
        <p class="ma-section-sub" style="margin-bottom:36px">From first message to final touch-up, every step is thoughtful, personal and beautifully executed.</p>
        <div class="ma-process">
          <?php foreach ( $steps as $st ) : ?>
          <div class="ma-step ma-reveal">
            <div class="ma-step__num"><?php echo $st['num']; ?></div>
            <div>
              <div class="ma-step__title"><?php echo esc_html( $st['title'] ); ?></div>
              <div class="ma-step__desc"><?php echo esc_html( $st['desc'] ); ?></div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <div>
        <div class="ma-tag">Brands in Kit</div>
        <h2 class="ma-section-title" style="font-size:1.7rem">Only the Best Products</h2>
        <p style="color:var(--ma-mid);margin-bottom:28px;font-family:var(--ma-ff2)">Celeste's kit features a curated selection of professional luxury brands, chosen for performance, longevity and skin compatibility.</p>
        <?php
        $brands = ['Charlotte Tilbury','NARS','MAC Cosmetics','Armani Beauty','Dior Beauty','Hourglass','Pat McGrath Labs','Laura Mercier','Bobbi Brown','Urban Decay','Too Faced','Huda Beauty','Benefit','YSL Beauty','Fenty Beauty'];
        foreach ( $brands as $brand ) : ?>
        <span style="display:inline-block;margin:4px;padding:7px 14px;background:#fff;border-radius:99px;font-size:.82rem;font-weight:700;color:var(--ma-plum);box-shadow:0 2px 8px var(--ma-shadow);border:1px solid rgba(201,160,220,.2);font-family:var(--ma-ff2)"><?php echo esc_html( $brand ); ?></span>
        <?php endforeach; ?>
        <p style="margin-top:20px;font-size:.82rem;color:var(--ma-mid);font-family:var(--ma-ff2)">✦ All cruelty-free · Vegan-only kit available on request</p>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ PACKAGES ═══════════ -->
<section class="ma-section ma-section--alt" id="packages">
  <div class="ma-wrap">
    <div style="text-align:center;max-width:620px;margin:0 auto 8px">
      <div class="ma-tag">Bridal Packages</div>
      <h2 class="ma-section-title">Invest in Your Most Important Day</h2>
      <p class="ma-section-sub" style="margin:0 auto">Transparent, all-inclusive pricing. Every package includes a trial session.</p>
    </div>
    <div class="ma-packages">
      <?php foreach ( $packages as $pkg ) : ?>
      <div class="ma-pkg ma-pkg--<?php echo $pkg['colour']; ?><?php echo $pkg['featured'] ? ' ma-pkg--featured' : ''; ?> ma-reveal">
        <?php if ( $pkg['featured'] ) : ?><div class="ma-pkg__ribbon">✦ Most Loved</div><?php endif; ?>
        <div class="ma-pkg__name"><?php echo esc_html( $pkg['name'] ); ?></div>
        <div class="ma-pkg__price"><?php echo esc_html( $pkg['price'] ); ?></div>
        <div class="ma-pkg__period"><?php echo esc_html( $pkg['period'] ); ?></div>
        <ul class="ma-pkg__features">
          <?php foreach ( $pkg['features'] as $feat ) : ?>
          <li class="ma-pkg__feature"><?php echo esc_html( $feat ); ?></li>
          <?php endforeach; ?>
        </ul>
        <a href="#booking" class="ma-pkg__btn">Enquire About <?php echo esc_html( $pkg['name'] ); ?></a>
      </div>
      <?php endforeach; ?>
    </div>
    <p style="text-align:center;margin-top:24px;font-size:.86rem;color:var(--ma-mid);font-family:var(--ma-ff2)">Travel & accommodation included for Sussex & Surrey. Destination surcharges apply for other regions. Packages are bespoke — contact for a custom quote.</p>
  </div>
</section>

<!-- ═══════════ TESTIMONIALS ═══════════ -->
<section class="ma-section ma-section--light">
  <div class="ma-wrap">
    <div class="ma-tag">Kind Words</div>
    <h2 class="ma-section-title">Brides & Clients</h2>
    <div class="ma-testimonials">
      <?php
      $testimonials = [
        [ 'text' => 'I cannot put into words how incredible Celeste made me feel on my wedding day. She listened to every word during the trial, and on the day herself she produced a look that lasted 14 hours and moved me to actual tears. Every wedding deserves a Celeste.', 'name' => 'Imogen W.', 'event' => 'Bride · Tuscany Wedding' ],
        [ 'text' => 'Working with Celeste on the BBC documentary was an absolute pleasure. She\'s calm under pressure, incredibly skilled and makes every subject feel completely at ease in front of the camera. A genuine pro.', 'name' => 'D. Okafor', 'event' => 'Director · BBC Production' ],
        [ 'text' => 'My bridal party of six all looked cohesive, polished and genuinely themselves — which is no easy feat! The whole morning was relaxed, professional and fun. Celeste is an absolute joy to have on your wedding day.', 'name' => 'Priya N.', 'event' => 'Bride · London Wedding' ],
      ];
      foreach ( $testimonials as $t ) : ?>
      <div class="ma-testimonial ma-reveal">
        <div class="ma-testimonial__quote">"</div>
        <p class="ma-testimonial__text"><?php echo esc_html( $t['text'] ); ?></p>
        <div class="ma-testimonial__name"><?php echo esc_html( $t['name'] ); ?></div>
        <div class="ma-testimonial__event"><?php echo esc_html( $t['event'] ); ?></div>
        <div class="ma-stars" style="margin-top:6px">★★★★★</div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════ FAQs ═══════════ -->
<section class="ma-section ma-section--alt" id="faq">
  <div class="ma-wrap">
    <div style="max-width:740px;margin:0 auto">
      <div class="ma-tag">FAQs</div>
      <h2 class="ma-section-title">Frequently Asked Questions</h2>
      <div class="ma-faq-list">
        <?php foreach ( $faqs as $faq ) : ?>
        <div class="ma-faq">
          <div class="ma-faq__q"><?php echo esc_html( $faq['q'] ); ?></div>
          <div class="ma-faq__a"><div class="ma-faq__a-inner"><?php echo esc_html( $faq['a'] ); ?></div></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ CTA STRIP ═══════════ -->
<div class="ma-cta-strip">
  <div class="ma-wrap">
    <h2>Ready to Book Your Look?</h2>
    <p>Dates fill fast — especially for summer weddings. Enquire today to check availability.</p>
    <a href="#booking" class="ma-btn ma-btn--primary">✦ Start Your Enquiry</a>
  </div>
</div>

<!-- ═══════════ BOOKING ═══════════ -->
<section class="ma-section ma-section--light" id="booking">
  <div class="ma-wrap">
    <div style="max-width:800px;margin:0 auto">
      <div class="ma-tag">Enquire Now</div>
      <h2 class="ma-section-title">Book Your Consultation</h2>
      <p style="color:var(--ma-mid);margin-bottom:40px;font-family:var(--ma-ff2)">Fill in the form and Celeste will be in touch within 48 hours to discuss your event and check her availability.</p>
      <div class="ma-form-wrap">
        <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
          <?php wp_nonce_field( 'tf_ma_booking', 'tf_ma_nonce' ); ?>
          <input type="hidden" name="action" value="tf_ma_booking">
          <div class="ma-form-grid">
            <div class="ma-field">
              <label for="ma-name">Your Name *</label>
              <input type="text" id="ma-name" name="name" placeholder="Your full name" required>
            </div>
            <div class="ma-field">
              <label for="ma-email">Email Address *</label>
              <input type="email" id="ma-email" name="email" placeholder="you@example.com" required>
            </div>
            <div class="ma-field">
              <label for="ma-phone">Phone Number</label>
              <input type="tel" id="ma-phone" name="phone" placeholder="+44 7700 000000">
            </div>
            <div class="ma-field">
              <label for="ma-event-date">Event Date *</label>
              <input type="date" id="ma-event-date" name="event_date" required>
            </div>
            <div class="ma-field">
              <label for="ma-event-type">Event Type *</label>
              <select id="ma-event-type" name="event_type" required>
                <option value="" disabled selected>Select occasion</option>
                <option>Wedding — Bride Only</option>
                <option>Wedding — Bride + Bridal Party</option>
                <option>Editorial / Fashion Shoot</option>
                <option>Film / TV / Commercial</option>
                <option>Red Carpet / Gala Event</option>
                <option>Birthday / Hen-Do</option>
                <option>Masterclass</option>
                <option>Other Special Occasion</option>
              </select>
            </div>
            <div class="ma-field">
              <label for="ma-location">Event Location *</label>
              <input type="text" id="ma-location" name="location" placeholder="Venue / City" required>
            </div>
            <div class="ma-field">
              <label for="ma-package">Package Interest</label>
              <select id="ma-package" name="package">
                <option value="" disabled selected>Which package?</option>
                <option>Bridal Glow (bride only)</option>
                <option>Wedding Party (bride + 3)</option>
                <option>Full Bridal Suite (bride + party)</option>
                <option>Editorial / Screen Rate</option>
                <option>Not sure yet</option>
              </select>
            </div>
            <div class="ma-field">
              <label for="ma-guests">Number of People</label>
              <select id="ma-guests" name="guests">
                <option value="" disabled selected>How many faces?</option>
                <option>Just me</option>
                <option>2–3 people</option>
                <option>4–6 people</option>
                <option>7–10 people</option>
                <option>10+ people</option>
              </select>
            </div>
            <div class="ma-field ma-fg--full">
              <label for="ma-vision">Your Vision &amp; Inspiration</label>
              <textarea id="ma-vision" name="vision" placeholder="Describe your dream look, skin type, any allergies, references or inspiration images you have in mind..."></textarea>
            </div>
          </div>
          <div style="margin-top:24px">
            <button type="submit" class="ma-btn ma-btn--primary" style="width:100%;justify-content:center;font-size:1rem;padding:16px">✦ Send Enquiry to Celeste</button>
          </div>
          <p class="ma-form-note">Celeste responds within 48 hours. No deposit required to enquire. Bridal dates are confirmed upon booking fee receipt.</p>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ FOOTER ═══════════ -->
<div class="ma-footer-strip">
  <div class="ma-wrap">
    <p>✦ <?php echo esc_html( $artist['name'] ); ?> · <?php echo esc_html( $artist['title'] ); ?> · <?php echo date('Y'); ?></p>
  </div>
</div>

<script>
(function () {
  'use strict';

  /* ── Counters ──────────────────────────────────────────────────── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  const DURATION = 1800;

  function animateCounter(el) {
    const raw    = parseFloat(el.dataset.target);
    if (isNaN(raw)) return;
    const isFloat = el.dataset.float === '1';
    const suffix  = el.dataset.suffix || '';
    const start   = performance.now();
    (function tick(now) {
      const p   = Math.min((now - start) / DURATION, 1);
      const val = raw * easeOut(p);
      el.textContent = (isFloat ? val.toFixed(1) : Math.floor(val)) + suffix;
      if (p < 1) requestAnimationFrame(tick);
    })(start);
  }

  const cObs = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) { animateCounter(e.target); cObs.unobserve(e.target); } });
  }, { threshold: 0.5 });
  document.querySelectorAll('.ma-counter__num[data-target]').forEach(el => cObs.observe(el));

  /* ── FAQ ─────────────────────────────────────────────────────── */
  document.querySelectorAll('.ma-faq__q').forEach(q => {
    q.addEventListener('click', () => {
      const faq = q.closest('.ma-faq');
      const open = faq.classList.contains('open');
      document.querySelectorAll('.ma-faq.open').forEach(f => f.classList.remove('open'));
      if (!open) faq.classList.add('open');
    });
  });

  /* ── Reveal ───────────────────────────────────────────────────── */
  const rObs = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); rObs.unobserve(e.target); } });
  }, { threshold: 0.12 });
  document.querySelectorAll('.ma-reveal').forEach(el => rObs.observe(el));

  /* ── Smooth scroll ─────────────────────────────────────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const t = document.querySelector(a.getAttribute('href'));
      if (t) { e.preventDefault(); t.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    });
  });
})();
</script>

</body>
</html>
</div><!-- .ma-page -->
<?php get_footer(); ?>
