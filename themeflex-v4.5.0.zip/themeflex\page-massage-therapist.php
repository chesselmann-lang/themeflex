<?php
/**
 * Template Name: Massage Therapist
 *
 * Premium landing page for a massage therapy / holistic wellness practice.
 * CSS art: ripple-water relaxation scene with floating candles, floating petals,
 * hot-stone arrangement, and an animated body-outline with glowing pressure points.
 *
 * Namespace   : --mt-*
 * Fonts       : Cormorant Garamond (headings) + Nunito (body) via Google Fonts
 * Palette     : deep plum #3B1F3A / warm stone #C8A882 / soft jade #7EB8A4
 *               ivory #FAF6F0 / dusty rose #E8A4A0
 * Keyframes   : mt-ripple, mt-petal-fall, mt-stone-glow, mt-candle-flicker,
 *               mt-pressure-pulse, mt-drift, mt-sway
 *
 * @package ThemeFlex
 */
/* ── deterministic randomness ───────────────────────────── */
srand( crc32( get_the_permalink() ) );

/* ── practice info ───────────────────────────────────────── */
$mt_therapist   = 'Sophie Whitmore';
$mt_credential  = 'ITEC Dip. • CNHC Registered Massage Therapist';
$mt_years       = 16;
$mt_location    = 'Cheltenham, Gloucestershire';
$mt_phone       = '01242 855 421';
$mt_email       = 'hello@sophiemassage.co.uk';

/* ── floating petals ─────────────────────────────────────── */
$mt_petals = [];
for ( $i = 0; $i < 18; $i++ ) {
    $mt_petals[] = [
        'left'     => rand( 0, 100 ),
        'delay'    => round( rand( 0, 8000 ) / 1000, 2 ),
        'duration' => round( rand( 6000, 14000 ) / 1000, 2 ),
        'size'     => rand( 10, 20 ),
        'rotate'   => rand( 0, 360 ),
        'hue'      => rand( 0, 30 ),        /* rose hue offset */
    ];
}

/* ── hot stones arrangement ──────────────────────────────── */
$mt_stones = [
    [ 'x' => 48, 'y' => 52, 'w' => 56, 'h' => 32, 'r' => -8,  'temp' => 42 ],
    [ 'x' => 30, 'y' => 40, 'w' => 44, 'h' => 26, 'r' => 15,  'temp' => 44 ],
    [ 'x' => 68, 'y' => 38, 'w' => 48, 'h' => 28, 'r' => -12, 'temp' => 43 ],
    [ 'x' => 22, 'y' => 62, 'w' => 36, 'h' => 22, 'r' => 20,  'temp' => 41 ],
    [ 'x' => 74, 'y' => 64, 'w' => 38, 'h' => 24, 'r' => -18, 'temp' => 45 ],
    [ 'x' => 50, 'y' => 32, 'w' => 30, 'h' => 18, 'r' => 5,   'temp' => 40 ],
];

/* ── pressure points (on body silhouette) ───────────────── */
$mt_pressure_points = [
    [ 'x' => 50, 'y' => 10, 'label' => 'Scalp' ],
    [ 'x' => 50, 'y' => 20, 'label' => 'Neck' ],
    [ 'x' => 38, 'y' => 30, 'label' => 'Left Shoulder' ],
    [ 'x' => 62, 'y' => 30, 'label' => 'Right Shoulder' ],
    [ 'x' => 50, 'y' => 42, 'label' => 'Upper Back' ],
    [ 'x' => 50, 'y' => 58, 'label' => 'Lower Back' ],
    [ 'x' => 34, 'y' => 55, 'label' => 'Left Hip' ],
    [ 'x' => 66, 'y' => 55, 'label' => 'Right Hip' ],
    [ 'x' => 38, 'y' => 72, 'label' => 'Left Hamstring' ],
    [ 'x' => 62, 'y' => 72, 'label' => 'Right Hamstring' ],
    [ 'x' => 40, 'y' => 88, 'label' => 'Left Calf' ],
    [ 'x' => 60, 'y' => 88, 'label' => 'Right Calf' ],
];

/* ── ripple circles ──────────────────────────────────────── */
$mt_ripples = [];
for ( $i = 0; $i < 5; $i++ ) {
    $mt_ripples[] = [
        'cx'    => rand( 20, 80 ),
        'cy'    => rand( 20, 80 ),
        'delay' => round( $i * 1.4, 2 ),
    ];
}

/* ── services ────────────────────────────────────────────── */
$mt_services = [
    [ 'icon' => '🤲', 'name' => 'Swedish Massage',       'desc' => 'The classic full-body relaxation treatment using long, flowing strokes to ease tension and improve circulation.' ],
    [ 'icon' => '🔥', 'name' => 'Hot Stone Therapy',     'desc' => 'Heated basalt stones placed on key energy centres to melt deep muscle tension and restore energetic flow.' ],
    [ 'icon' => '💪', 'name' => 'Deep Tissue Massage',   'desc' => 'Targeted slow strokes reach the deeper layers of muscle to release chronic tension and adhesions.' ],
    [ 'icon' => '🤰', 'name' => 'Pregnancy Massage',     'desc' => 'Specially adapted techniques for the second and third trimester to ease back pain, swelling and fatigue.' ],
    [ 'icon' => '🏃', 'name' => 'Sports Massage',        'desc' => 'Pre- or post-event treatment to prepare muscles, accelerate recovery and prevent soft tissue injury.' ],
    [ 'icon' => '✨', 'name' => 'Aromatherapy Massage',  'desc' => 'Therapeutic essential oils blended to your mood and needs, combined with gentle massage for holistic wellbeing.' ],
    [ 'icon' => '🦶', 'name' => 'Reflexology',           'desc' => 'Pressure applied to reflex zones on the feet to stimulate corresponding organs and restore natural balance.' ],
    [ 'icon' => '🌿', 'name' => 'CBD Massage',           'desc' => 'Plant-based cannabidiol oil massage to reduce inflammation, ease joint discomfort and support recovery.' ],
];

/* ── conditions ──────────────────────────────────────────── */
$mt_conditions = [
    'Back Pain', 'Neck & Shoulder Tension', 'Sciatica', 'Fibromyalgia', 'Stress & Anxiety',
    'Headaches & Migraines', 'Insomnia', 'Frozen Shoulder', 'RSI & Repetitive Strain',
    'Plantar Fasciitis', 'Post-Surgery Recovery', 'Arthritis', 'Sports Injuries', 'Burnout',
    'Poor Circulation', 'Lymphoedema', 'TMJ Dysfunction', 'Carpal Tunnel',
];

/* ── process steps ───────────────────────────────────────── */
$mt_steps = [
    [ 'num' => '01', 'title' => 'Consultation',     'desc' => 'We discuss your health history, areas of concern, pressure preferences and treatment goals.' ],
    [ 'num' => '02', 'title' => 'Personalise',      'desc' => 'I tailor the treatment — oil blend, pressure, focus areas — specifically to your needs that day.' ],
    [ 'num' => '03', 'title' => 'Treatment',        'desc' => 'Relax fully in a warm, calm environment as we work through each area methodically and intuitively.' ],
    [ 'num' => '04', 'title' => 'Aftercare',        'desc' => 'Guidance on hydration, self-care stretches and recommended frequency for ongoing benefit.' ],
];

/* ── testimonials ────────────────────────────────────────── */
$mt_testimonials = [
    [ 'name' => 'Harriet L.',  'stars' => 5, 'text' => 'Sophie's hot stone massage is life-changing. My chronic back pain has reduced dramatically after just four sessions.' ],
    [ 'name' => 'Marcus T.',   'stars' => 5, 'text' => 'As an amateur triathlete I trust Sophie with my body. Her sports massage has kept me injury-free for two seasons.' ],
    [ 'name' => 'Rosie M.',    'stars' => 5, 'text' => 'The pregnancy massage was the most relaxed I felt throughout my entire third trimester. Absolutely wonderful.' ],
    [ 'name' => 'David K.',    'stars' => 5, 'text' => 'I was sceptical about aromatherapy but left floating on air. Booked three more sessions before I'd even paid.' ],
    [ 'name' => 'Anita W.',    'stars' => 5, 'text' => 'Sophie has magic hands — she found tension in my neck I didn\'t even know I was carrying. Remarkable therapist.' ],
    [ 'name' => 'James F.',    'stars' => 5, 'text' => 'CBD massage for my arthritic knees gave me two full weeks of reduced pain. I am a complete convert.' ],
];

/* ── session types ───────────────────────────────────────── */
$mt_session_types = [
    'Swedish Massage', 'Hot Stone Therapy', 'Deep Tissue Massage',
    'Pregnancy Massage', 'Sports Massage', 'Aromatherapy Massage',
    'Reflexology', 'CBD Massage',
];

/* ── durations ───────────────────────────────────────────── */
$mt_durations = [ '30 min', '45 min', '60 min', '75 min', '90 min', '2 hours' ];

/* ── packages ────────────────────────────────────────────── */
$mt_packages = [
    [
        'name'     => 'Taster Session',
        'price'    => '£55',
        'duration' => '45 min',
        'featured' => false,
        'colour'   => '#7EB8A4',
        'items'    => [
            '45-minute Swedish or relaxation massage',
            'Consultation & health questionnaire',
            'Personalised oil blend selection',
            'Aftercare advice sheet',
        ],
    ],
    [
        'name'     => 'Signature Treatment',
        'price'    => '£85',
        'duration' => '90 min',
        'featured' => true,
        'colour'   => '#3B1F3A',
        'items'    => [
            '90-minute customised full-body massage',
            'Hot stone or aromatherapy upgrade included',
            'Comprehensive health consultation',
            'Personalised aftercare programme',
            'Complimentary herbal tea & foot soak',
            'Gift voucher available',
        ],
    ],
    [
        'name'     => 'Wellness Course',
        'price'    => '£295',
        'duration' => '4 × 60 min',
        'featured' => false,
        'colour'   => '#C8A882',
        'items'    => [
            '4 × 60-minute treatments',
            'Progress review after each session',
            'Tailored home-care stretching plan',
            'Priority booking & flexible scheduling',
            'Save £45 vs single sessions',
        ],
    ],
];

/* ── FAQ ─────────────────────────────────────────────────── */
$mt_faqs = [
    [ 'q' => 'What should I wear / how undressed do I need to be?',
      'a' => 'You undress to your own comfort level. I use professional draping throughout so only the area being worked on is exposed. Underwear on is absolutely fine.' ],
    [ 'q' => 'Will it hurt?',
      'a' => 'Relaxation massage should feel pleasant throughout. Deep tissue work may involve brief discomfort when working through adhesions — always tell me and I'll adjust.' ],
    [ 'q' => 'How often should I have a massage?',
      'a' => 'For maintenance and stress management, once a month is ideal. For ongoing conditions such as back pain or sports training, fortnightly or weekly is more beneficial.' ],
    [ 'q' => 'Is massage safe during pregnancy?',
      'a' => 'Yes, from the second trimester onwards with a specialist pregnancy-trained therapist. I am fully qualified in pregnancy massage and will adapt every technique.' ],
    [ 'q' => 'Can I claim on private health insurance?',
      'a' => 'Many insurers cover massage therapy when referred by a GP. As a CNHC-registered therapist I can provide the documentation your insurer may require.' ],
    [ 'q' => 'Do you sell gift vouchers?',
      'a' => 'Yes — physical gift cards and e-vouchers available for any treatment or monetary value. Perfect birthdays, anniversaries or thank-you gifts.' ],
];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=Nunito:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════════
   MASSAGE THERAPIST  –  --mt-* token namespace
═══════════════════════════════════════════════════════════ */
:root {
  --mt-plum:        #3B1F3A;
  --mt-plum-light:  #5C3258;
  --mt-stone:       #C8A882;
  --mt-stone-light: #DFC4A8;
  --mt-jade:        #7EB8A4;
  --mt-jade-dark:   #5A9A86;
  --mt-ivory:       #FAF6F0;
  --mt-rose:        #E8A4A0;
  --mt-rose-dark:   #CC7B77;
  --mt-charcoal:    #2A1829;
  --mt-grey:        #8A7A88;
  --mt-font-head:   'Cormorant Garamond', Georgia, serif;
  --mt-font-body:   'Nunito', sans-serif;
  --mt-radius:      14px;
  --mt-transition:  0.35s ease;
}

*,*::before,*::after { box-sizing: border-box; margin: 0; padding: 0; }

.mt-page { font-family: var(--mt-font-body); color: var(--mt-plum); background: var(--mt-ivory); overflow-x: hidden; }
.mt-page a { color: var(--mt-jade-dark); text-decoration: none; }
.mt-page img { max-width: 100%; display: block; }

/* ── keyframes ── */
@keyframes mt-ripple {
  0%   { transform: scale(0.4); opacity: 0.7; }
  100% { transform: scale(3.5); opacity: 0; }
}
@keyframes mt-petal-fall {
  0%   { transform: translateY(-40px) rotate(var(--mt-pr,0deg)); opacity: 0; }
  10%  { opacity: 0.85; }
  90%  { opacity: 0.6; }
  100% { transform: translateY(calc(100vh + 60px)) rotate(calc(var(--mt-pr,0deg) + 180deg)); opacity: 0; }
}
@keyframes mt-stone-glow {
  0%,100% { box-shadow: 0 0 12px 4px rgba(200,168,130,0.5), 0 4px 20px rgba(0,0,0,0.3); }
  50%      { box-shadow: 0 0 28px 10px rgba(200,168,130,0.8), 0 4px 24px rgba(0,0,0,0.3); }
}
@keyframes mt-candle-flicker {
  0%,100% { transform: scaleX(1) scaleY(1) translateX(0); opacity: 0.9; }
  20%     { transform: scaleX(0.85) scaleY(1.15) translateX(-1px); opacity: 1; }
  50%     { transform: scaleX(1.1) scaleY(0.9) translateX(1px); opacity: 0.85; }
  70%     { transform: scaleX(0.9) scaleY(1.1) translateX(-0.5px); opacity: 0.95; }
}
@keyframes mt-pressure-pulse {
  0%,100% { box-shadow: 0 0 0 0 rgba(126,184,164,0.8); transform: translate(-50%,-50%) scale(1); }
  50%     { box-shadow: 0 0 0 8px rgba(126,184,164,0); transform: translate(-50%,-50%) scale(1.25); }
}
@keyframes mt-drift {
  0%         { transform: translateY(0) translateX(0) rotate(0deg); opacity: 0; }
  10%        { opacity: 0.6; }
  50%        { transform: translateY(-60px) translateX(20px) rotate(180deg); }
  90%        { opacity: 0.4; }
  100%       { transform: translateY(-120px) translateX(-10px) rotate(360deg); opacity: 0; }
}
@keyframes mt-sway {
  0%,100% { transform: rotate(-4deg); }
  50%     { transform: rotate(4deg); }
}
@keyframes mt-count-up { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
@keyframes mt-fade-in  { from { opacity: 0; } to { opacity: 1; } }
@keyframes mt-slide-up { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }

/* ══ NAVBAR ══════════════════════════════════════════════ */
.mt-nav {
  position: fixed; top: 0; left: 0; width: 100%; z-index: 1000;
  background: rgba(59,31,58,0.95); backdrop-filter: blur(12px);
  border-bottom: 1px solid rgba(200,168,130,0.2);
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 40px; height: 68px;
}
.mt-nav__logo { font-family: var(--mt-font-head); font-size: 1.55rem; color: var(--mt-stone); letter-spacing: 0.04em; }
.mt-nav__logo span { color: var(--mt-jade); }
.mt-nav__links { display: flex; gap: 32px; list-style: none; }
.mt-nav__links a { color: rgba(250,246,240,0.85); font-size: 0.9rem; font-weight: 500; letter-spacing: 0.06em; transition: color var(--mt-transition); }
.mt-nav__links a:hover { color: var(--mt-jade); }
.mt-nav__cta { background: var(--mt-jade); color: #fff; padding: 10px 24px; border-radius: 30px; font-size: 0.88rem; font-weight: 600; transition: background var(--mt-transition); }
.mt-nav__cta:hover { background: var(--mt-jade-dark); color: #fff; }

/* ══ HERO ════════════════════════════════════════════════ */
.mt-hero {
  min-height: 100vh; display: flex; align-items: center;
  background: linear-gradient(135deg, var(--mt-plum) 0%, #2A1040 50%, #1A0B2E 100%);
  position: relative; overflow: hidden; padding: 100px 40px 60px;
}
.mt-hero__petals { position: absolute; inset: 0; pointer-events: none; z-index: 1; }
.mt-petal {
  position: absolute; top: -30px;
  width: var(--mt-size, 14px); height: var(--mt-size, 14px);
  border-radius: 50% 0 50% 0;
  background: radial-gradient(circle, rgba(232,164,160,0.9) 0%, rgba(232,164,160,0.3) 100%);
  animation: mt-petal-fall var(--mt-dur, 10s) var(--mt-delay, 0s) infinite linear;
  --mt-pr: var(--mt-rotate, 0deg);
}
.mt-hero__bg-ripples { position: absolute; inset: 0; pointer-events: none; z-index: 0; }
.mt-ripple-origin {
  position: absolute; border-radius: 50%;
  border: 1px solid rgba(126,184,164,0.3);
  width: 80px; height: 80px;
  animation: mt-ripple 5s var(--mt-rdelay, 0s) infinite ease-out;
}
.mt-hero__inner { position: relative; z-index: 2; display: grid; grid-template-columns: 1fr 480px; gap: 60px; align-items: center; max-width: 1280px; margin: 0 auto; width: 100%; }
.mt-hero__text { animation: mt-slide-up 0.8s ease both; }
.mt-hero__badge { display: inline-flex; align-items: center; gap: 8px; background: rgba(126,184,164,0.2); border: 1px solid rgba(126,184,164,0.4); color: var(--mt-jade); padding: 6px 16px; border-radius: 20px; font-size: 0.78rem; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 24px; }
.mt-hero__eyebrow { font-family: var(--mt-font-head); font-size: 1.1rem; color: var(--mt-stone); font-style: italic; margin-bottom: 12px; }
.mt-hero__title { font-family: var(--mt-font-head); font-size: clamp(2.8rem, 5vw, 4.2rem); font-weight: 600; color: var(--mt-ivory); line-height: 1.15; margin-bottom: 20px; }
.mt-hero__title em { color: var(--mt-jade); font-style: italic; }
.mt-hero__subtitle { font-size: 1.1rem; color: rgba(250,246,240,0.8); line-height: 1.75; max-width: 480px; margin-bottom: 36px; font-weight: 300; }
.mt-hero__actions { display: flex; gap: 16px; flex-wrap: wrap; margin-bottom: 48px; }
.mt-btn-primary   { background: var(--mt-jade); color: #fff; padding: 16px 36px; border-radius: 40px; font-size: 1rem; font-weight: 600; transition: all var(--mt-transition); box-shadow: 0 8px 30px rgba(126,184,164,0.35); }
.mt-btn-primary:hover { background: var(--mt-jade-dark); transform: translateY(-2px); color: #fff; }
.mt-btn-secondary { border: 2px solid rgba(200,168,130,0.5); color: var(--mt-stone); padding: 14px 32px; border-radius: 40px; font-size: 1rem; font-weight: 500; transition: all var(--mt-transition); }
.mt-btn-secondary:hover { border-color: var(--mt-stone); color: #fff; }
.mt-hero__trust { display: flex; gap: 28px; flex-wrap: wrap; }
.mt-trust-item { display: flex; align-items: center; gap: 8px; color: rgba(250,246,240,0.7); font-size: 0.85rem; }
.mt-trust-item .mt-trust-icon { color: var(--mt-jade); font-size: 1rem; }

/* ── HERO SCENE: relaxation tableau ─────────────────────── */
.mt-hero__scene {
  width: 480px; height: 520px; position: relative; flex-shrink: 0;
  animation: mt-fade-in 1s 0.4s ease both;
}

/* treatment table */
.mt-table-surface {
  position: absolute; bottom: 80px; left: 10px; right: 10px; height: 180px;
  background: linear-gradient(135deg, #4A2E40 0%, #6B3E5C 100%);
  border-radius: 16px 16px 8px 8px;
  box-shadow: 0 12px 40px rgba(0,0,0,0.4);
}
.mt-table-surface::before {
  content: ''; position: absolute; top: 12px; left: 20px; right: 20px; height: 3px;
  background: rgba(200,168,130,0.3); border-radius: 2px;
}
.mt-table-surface::after {
  content: ''; position: absolute; top: 24px; left: 20px; right: 20px; height: 1px;
  background: rgba(200,168,130,0.15);
}
.mt-table-legs {
  position: absolute; bottom: 60px; left: 10px; right: 10px; height: 20px;
  display: flex; justify-content: space-between; padding: 0 20px;
}
.mt-table-leg {
  width: 8px; height: 60px; background: #3A2035; border-radius: 2px;
  transform: translateY(20px);
}

/* body silhouette on table */
.mt-body-silhouette {
  position: absolute; bottom: 220px; left: 50%; transform: translateX(-50%);
  width: 160px; height: 300px;
}
.mt-body-part {
  position: absolute; background: rgba(200,168,130,0.25);
  border: 1px solid rgba(200,168,130,0.2); border-radius: 50%;
}
.mt-body-head   { width: 44px; height: 50px; top: 0; left: 50%; transform: translateX(-50%); }
.mt-body-neck   { width: 22px; height: 22px; top: 46px; left: 50%; transform: translateX(-50%); border-radius: 4px; }
.mt-body-torso  { width: 80px; height: 110px; top: 64px; left: 50%; transform: translateX(-50%); border-radius: 16px; }
.mt-body-larm   { width: 22px; height: 90px; top: 68px; left: 10px; border-radius: 12px; transform: rotate(8deg); }
.mt-body-rarm   { width: 22px; height: 90px; top: 68px; right: 10px; border-radius: 12px; transform: rotate(-8deg); }
.mt-body-lthigh { width: 34px; height: 80px; top: 170px; left: 28px; border-radius: 12px; }
.mt-body-rthigh { width: 34px; height: 80px; top: 170px; right: 28px; border-radius: 12px; }
.mt-body-lshin  { width: 26px; height: 70px; top: 246px; left: 32px; border-radius: 10px; }
.mt-body-rshin  { width: 26px; height: 70px; top: 246px; right: 32px; border-radius: 10px; }

/* pressure points on body */
.mt-pp {
  position: absolute; width: 10px; height: 10px; border-radius: 50%;
  background: var(--mt-jade); border: 2px solid #fff;
  transform: translate(-50%,-50%);
  animation: mt-pressure-pulse 2.5s infinite ease-in-out;
  cursor: pointer;
}
.mt-pp::after {
  content: attr(data-label); position: absolute; bottom: 16px; left: 50%;
  transform: translateX(-50%); background: var(--mt-plum); color: var(--mt-ivory);
  padding: 3px 8px; border-radius: 6px; font-size: 0.65rem; white-space: nowrap;
  opacity: 0; pointer-events: none; transition: opacity 0.2s; z-index: 10;
}
.mt-pp:hover::after { opacity: 1; }

/* hot stones */
.mt-stone-wrap { position: absolute; top: 30px; left: 50%; transform: translateX(-50%); width: 300px; height: 220px; }
.mt-hot-stone {
  position: absolute; border-radius: 50%;
  background: radial-gradient(ellipse, #4A3830 0%, #2A1E18 60%, #1A1210 100%);
  animation: mt-stone-glow 3s infinite ease-in-out;
}
.mt-stone-temp {
  position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%);
  font-size: 0.6rem; color: var(--mt-stone-light); font-family: var(--mt-font-body);
  font-weight: 600; pointer-events: none;
}

/* candles */
.mt-candles { position: absolute; top: 10px; right: 10px; display: flex; gap: 16px; }
.mt-candle  { position: relative; display: flex; flex-direction: column; align-items: center; }
.mt-candle-body {
  width: 18px; border-radius: 4px 4px 2px 2px;
  background: linear-gradient(to right, #E8D5C0, #C8B090, #E8D5C0);
}
.mt-candle-wick { width: 2px; height: 10px; background: #3A2A1A; border-radius: 1px; }
.mt-candle-flame {
  width: 12px; height: 18px; border-radius: 50% 50% 30% 30%;
  background: radial-gradient(ellipse at 50% 70%, #FFE566 0%, #FF9A1E 40%, #FF5500 80%, rgba(255,85,0,0) 100%);
  animation: mt-candle-flicker 0.4s infinite alternate ease-in-out;
  transform-origin: bottom center;
  margin-bottom: 2px;
}
.mt-candle-drip {
  position: absolute; width: 4px; height: 8px; border-radius: 0 0 4px 4px;
  background: rgba(232,213,192,0.8);
}

/* floating particles */
.mt-scene-particles { position: absolute; inset: 0; pointer-events: none; }
.mt-scene-particle {
  position: absolute; width: 8px; height: 8px; border-radius: 50%;
  background: radial-gradient(circle, rgba(126,184,164,0.8) 0%, transparent 70%);
  animation: mt-drift var(--mt-pd, 8s) var(--mt-pdelay, 0s) infinite ease-in-out;
}

/* ══ COUNTERS ════════════════════════════════════════════ */
.mt-counters { background: var(--mt-plum); padding: 60px 40px; }
.mt-counters__grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 2px; max-width: 1000px; margin: 0 auto; }
.mt-counter-item { text-align: center; padding: 40px 20px; background: rgba(255,255,255,0.04); border-radius: 4px; }
.mt-counter-item:hover { background: rgba(126,184,164,0.08); }
.mt-counter-number { font-family: var(--mt-font-head); font-size: 3.2rem; font-weight: 600; color: var(--mt-ivory); display: flex; align-items: baseline; justify-content: center; gap: 4px; }
.mt-counter-number span.mt-suffix { font-size: 1.8rem; color: var(--mt-jade); }
.mt-counter-label { color: var(--mt-stone); font-size: 0.85rem; margin-top: 8px; font-weight: 500; letter-spacing: 0.06em; }

/* ══ SERVICES ════════════════════════════════════════════ */
.mt-services { padding: 100px 40px; background: var(--mt-ivory); }
.mt-section-header { text-align: center; margin-bottom: 64px; }
.mt-eyebrow { font-family: var(--mt-font-head); font-style: italic; color: var(--mt-jade-dark); font-size: 1.05rem; margin-bottom: 12px; }
.mt-section-title { font-family: var(--mt-font-head); font-size: clamp(2rem,4vw,3rem); color: var(--mt-plum); margin-bottom: 16px; font-weight: 600; }
.mt-section-desc { color: var(--mt-grey); font-size: 1.05rem; max-width: 600px; margin: 0 auto; line-height: 1.7; }
.mt-services__grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 24px; max-width: 1280px; margin: 0 auto; }
.mt-service-card {
  background: #fff; border-radius: var(--mt-radius); padding: 32px 24px;
  border: 1px solid rgba(59,31,58,0.08);
  transition: all var(--mt-transition); position: relative; overflow: hidden;
}
.mt-service-card::before {
  content: ''; position: absolute; bottom: 0; left: 0; right: 0; height: 3px;
  background: linear-gradient(90deg, var(--mt-jade), var(--mt-rose));
  transform: scaleX(0); transform-origin: left;
  transition: transform var(--mt-transition);
}
.mt-service-card:hover { transform: translateY(-6px); box-shadow: 0 20px 50px rgba(59,31,58,0.12); }
.mt-service-card:hover::before { transform: scaleX(1); }
.mt-service-icon { font-size: 2rem; margin-bottom: 16px; }
.mt-service-name { font-family: var(--mt-font-head); font-size: 1.2rem; color: var(--mt-plum); margin-bottom: 10px; font-weight: 600; }
.mt-service-desc { color: var(--mt-grey); font-size: 0.88rem; line-height: 1.65; }

/* ══ CONDITIONS ══════════════════════════════════════════ */
.mt-conditions { padding: 80px 40px; background: #F3EDE8; }
.mt-conditions__cloud { display: flex; flex-wrap: wrap; gap: 12px; justify-content: center; max-width: 900px; margin: 0 auto; }
.mt-condition-tag {
  background: #fff; border: 1px solid rgba(59,31,58,0.15);
  color: var(--mt-plum); padding: 8px 18px; border-radius: 24px; font-size: 0.9rem;
  transition: all var(--mt-transition); cursor: default;
}
.mt-condition-tag:hover { background: var(--mt-jade); color: #fff; border-color: var(--mt-jade); transform: scale(1.04); }

/* ══ PROCESS ═════════════════════════════════════════════ */
.mt-process { padding: 100px 40px; background: var(--mt-ivory); }
.mt-process__steps { display: grid; grid-template-columns: repeat(4,1fr); gap: 32px; max-width: 1200px; margin: 0 auto; position: relative; }
.mt-process__steps::before {
  content: ''; position: absolute; top: 36px; left: 80px; right: 80px; height: 2px;
  background: linear-gradient(90deg, var(--mt-jade), var(--mt-rose));
}
.mt-step { text-align: center; position: relative; }
.mt-step-num {
  width: 72px; height: 72px; border-radius: 50%; background: var(--mt-plum); color: var(--mt-ivory);
  font-family: var(--mt-font-head); font-size: 1.5rem; font-weight: 600;
  display: flex; align-items: center; justify-content: center; margin: 0 auto 20px;
  border: 3px solid var(--mt-jade); position: relative; z-index: 1;
  transition: all var(--mt-transition);
}
.mt-step:hover .mt-step-num { background: var(--mt-jade); border-color: var(--mt-plum); }
.mt-step-title { font-family: var(--mt-font-head); font-size: 1.15rem; color: var(--mt-plum); margin-bottom: 10px; font-weight: 600; }
.mt-step-desc  { color: var(--mt-grey); font-size: 0.88rem; line-height: 1.65; }

/* ══ PACKAGES ════════════════════════════════════════════ */
.mt-packages { padding: 100px 40px; background: linear-gradient(180deg, #F3EDE8 0%, var(--mt-ivory) 100%); }
.mt-packages__grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 28px; max-width: 1100px; margin: 0 auto; align-items: start; }
.mt-package-card {
  border-radius: 20px; overflow: hidden;
  box-shadow: 0 8px 40px rgba(59,31,58,0.12);
  transition: transform var(--mt-transition);
  position: relative;
}
.mt-package-card:hover { transform: translateY(-8px); }
.mt-package-card--featured { transform: scale(1.04); box-shadow: 0 20px 60px rgba(59,31,58,0.25); }
.mt-package-card--featured:hover { transform: scale(1.04) translateY(-8px); }
.mt-package-header {
  padding: 36px 32px; color: #fff;
  background: var(--mt-card-colour, var(--mt-plum));
}
.mt-package-badge {
  display: inline-block; background: rgba(255,255,255,0.25); color: #fff;
  padding: 4px 14px; border-radius: 16px; font-size: 0.7rem; font-weight: 700;
  letter-spacing: 0.1em; text-transform: uppercase; margin-bottom: 16px;
}
.mt-package-name     { font-family: var(--mt-font-head); font-size: 1.6rem; font-weight: 600; margin-bottom: 8px; }
.mt-package-price    { font-family: var(--mt-font-head); font-size: 2.8rem; font-weight: 300; }
.mt-package-duration { font-size: 0.85rem; opacity: 0.8; margin-top: 4px; }
.mt-package-body { padding: 28px 32px; background: #fff; }
.mt-package-features { list-style: none; margin-bottom: 28px; }
.mt-package-features li { padding: 10px 0; border-bottom: 1px solid rgba(59,31,58,0.06); font-size: 0.9rem; color: var(--mt-grey); display: flex; gap: 10px; }
.mt-package-features li::before { content: '✓'; color: var(--mt-jade); font-weight: 700; flex-shrink: 0; }
.mt-package-features li:last-child { border-bottom: none; }
.mt-package-btn {
  display: block; width: 100%; padding: 14px; border-radius: 40px;
  text-align: center; font-weight: 600; font-size: 0.95rem;
  border: 2px solid var(--mt-card-colour, var(--mt-plum));
  color: var(--mt-card-colour, var(--mt-plum));
  background: transparent;
  transition: all var(--mt-transition); cursor: pointer;
}
.mt-package-btn:hover,
.mt-package-card--featured .mt-package-btn {
  background: var(--mt-card-colour, var(--mt-plum));
  color: #fff;
}

/* ══ THERAPIST PROFILE ═══════════════════════════════════ */
.mt-profile { padding: 100px 40px; background: var(--mt-ivory); }
.mt-profile__inner { max-width: 1100px; margin: 0 auto; display: grid; grid-template-columns: 320px 1fr; gap: 80px; align-items: center; }
.mt-profile__figure-wrap { display: flex; flex-direction: column; align-items: center; }
.mt-profile__figure {
  width: 240px; height: 300px; position: relative;
  background: linear-gradient(160deg, #5C3258 0%, #3B1F3A 100%);
  border-radius: 50% 50% 40% 40%; margin: 0 auto 24px;
  box-shadow: 0 20px 60px rgba(59,31,58,0.3);
}
/* head */
.mt-profile__figure::before {
  content: ''; position: absolute; top: -60px; left: 50%; transform: translateX(-50%);
  width: 90px; height: 96px; border-radius: 50%;
  background: linear-gradient(160deg, #F5DEB3 0%, #DEB887 100%);
  box-shadow: 0 4px 16px rgba(59,31,58,0.2);
}
/* hair */
.mt-profile__figure-hair {
  position: absolute; top: -80px; left: 50%; transform: translateX(-50%);
  width: 96px; height: 64px; border-radius: 50% 50% 0 0;
  background: #8B5E3C;
}
/* white coat */
.mt-profile__figure-coat {
  position: absolute; inset: 0; border-radius: 50% 50% 40% 40%;
  background: rgba(255,255,255,0.15); border: 2px solid rgba(255,255,255,0.25);
}
/* name badge */
.mt-profile__figure-badge {
  position: absolute; top: 40px; left: 50%; transform: translateX(-50%);
  background: rgba(255,255,255,0.9); color: var(--mt-plum);
  padding: 4px 12px; border-radius: 4px; font-size: 0.65rem; font-weight: 700;
  white-space: nowrap;
}
/* hands */
.mt-profile__figure-lhand,
.mt-profile__figure-rhand {
  position: absolute; bottom: 20px; width: 36px; height: 28px;
  border-radius: 50%; background: linear-gradient(135deg, #F5DEB3 0%, #DEB887 100%);
}
.mt-profile__figure-lhand { left: -8px; transform: rotate(-15deg); }
.mt-profile__figure-rhand { right: -8px; transform: rotate(15deg); }
/* oil bottle */
.mt-profile__figure-bottle {
  position: absolute; bottom: 28px; left: 50%; transform: translateX(-50%);
  width: 16px; height: 36px; background: linear-gradient(180deg, #7EB8A4 0%, #5A9A86 100%);
  border-radius: 4px 4px 2px 2px;
}
.mt-profile__figure-bottle::before {
  content: ''; position: absolute; top: -10px; left: 50%; transform: translateX(-50%);
  width: 8px; height: 12px; background: #3B1F3A; border-radius: 2px;
}
.mt-profile__cred-card {
  background: var(--mt-plum); color: var(--mt-ivory); padding: 20px 28px;
  border-radius: 14px; width: 100%; text-align: center;
  box-shadow: 0 8px 30px rgba(59,31,58,0.2);
}
.mt-profile__cred-name { font-family: var(--mt-font-head); font-size: 1.3rem; margin-bottom: 6px; }
.mt-profile__cred-title { font-size: 0.78rem; color: var(--mt-jade); letter-spacing: 0.05em; }
.mt-profile__content h2 { font-family: var(--mt-font-head); font-size: 2.4rem; color: var(--mt-plum); margin-bottom: 20px; font-weight: 600; }
.mt-profile__content p { color: var(--mt-grey); line-height: 1.8; margin-bottom: 16px; font-size: 0.97rem; }
.mt-profile__quals { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 24px; }
.mt-qual-badge {
  background: rgba(126,184,164,0.12); border: 1px solid rgba(126,184,164,0.35);
  color: var(--mt-jade-dark); padding: 6px 14px; border-radius: 20px; font-size: 0.82rem; font-weight: 600;
}

/* ══ TESTIMONIALS ════════════════════════════════════════ */
.mt-testimonials { padding: 100px 40px; background: #F3EDE8; }
.mt-testimonials__grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; max-width: 1200px; margin: 0 auto; }
.mt-testimonial-card {
  background: #fff; border-radius: var(--mt-radius); padding: 32px;
  box-shadow: 0 4px 20px rgba(59,31,58,0.06);
  border-left: 4px solid var(--mt-jade);
  transition: transform var(--mt-transition);
}
.mt-testimonial-card:hover { transform: translateY(-4px); }
.mt-stars { color: var(--mt-stone); font-size: 1rem; margin-bottom: 16px; letter-spacing: 2px; }
.mt-testimonial-text { color: var(--mt-plum); font-size: 0.93rem; line-height: 1.75; font-style: italic; margin-bottom: 20px; font-family: var(--mt-font-head); }
.mt-testimonial-name { color: var(--mt-jade-dark); font-weight: 600; font-size: 0.85rem; letter-spacing: 0.04em; }

/* ══ FAQ ═════════════════════════════════════════════════ */
.mt-faq { padding: 100px 40px; background: var(--mt-ivory); }
.mt-faq__list { max-width: 780px; margin: 0 auto; }
.mt-faq-item { border-bottom: 1px solid rgba(59,31,58,0.1); }
.mt-faq-q {
  width: 100%; text-align: left; background: none; border: none; cursor: pointer;
  padding: 22px 0; display: flex; justify-content: space-between; align-items: center;
  font-family: var(--mt-font-head); font-size: 1.05rem; color: var(--mt-plum);
  font-weight: 600; gap: 16px;
}
.mt-faq-q svg { flex-shrink: 0; transition: transform 0.3s; color: var(--mt-jade); }
.mt-faq-item.open .mt-faq-q svg { transform: rotate(45deg); }
.mt-faq-a { max-height: 0; overflow: hidden; transition: max-height 0.4s ease; }
.mt-faq-a-inner { padding: 0 0 20px; color: var(--mt-grey); line-height: 1.8; font-size: 0.94rem; }
.mt-faq-item.open .mt-faq-a { max-height: 300px; }

/* ══ BOOKING ═════════════════════════════════════════════ */
.mt-booking { padding: 100px 40px; background: linear-gradient(135deg, var(--mt-plum) 0%, #2A1040 100%); }
.mt-booking__inner { max-width: 900px; margin: 0 auto; }
.mt-booking .mt-section-title { color: var(--mt-ivory); }
.mt-booking .mt-eyebrow { color: var(--mt-jade); }
.mt-booking .mt-section-desc { color: rgba(250,246,240,0.7); }
.mt-booking-form {
  background: rgba(255,255,255,0.06); border: 1px solid rgba(200,168,130,0.2);
  border-radius: 20px; padding: 48px; backdrop-filter: blur(8px);
  margin-top: 48px;
}
.mt-form-grid  { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
.mt-form-full  { grid-column: 1 / -1; }
.mt-form-group { display: flex; flex-direction: column; gap: 8px; }
.mt-form-label { color: var(--mt-stone-light); font-size: 0.82rem; font-weight: 600; letter-spacing: 0.06em; text-transform: uppercase; }
.mt-form-input,
.mt-form-select,
.mt-form-textarea {
  background: rgba(255,255,255,0.08); border: 1px solid rgba(200,168,130,0.25);
  border-radius: 10px; padding: 14px 18px; color: var(--mt-ivory); font-size: 0.94rem;
  font-family: var(--mt-font-body); transition: border-color var(--mt-transition);
  width: 100%;
}
.mt-form-input::placeholder, .mt-form-textarea::placeholder { color: rgba(200,168,130,0.4); }
.mt-form-input:focus, .mt-form-select:focus, .mt-form-textarea:focus { outline: none; border-color: var(--mt-jade); }
.mt-form-select option { background: var(--mt-plum); }
.mt-form-textarea { resize: vertical; min-height: 100px; }
.mt-form-privacy { color: rgba(250,246,240,0.55); font-size: 0.78rem; line-height: 1.6; }
.mt-form-privacy a { color: var(--mt-jade); }
.mt-form-submit {
  background: var(--mt-jade); color: #fff; border: none;
  padding: 18px 48px; border-radius: 40px; font-size: 1rem; font-weight: 700;
  cursor: pointer; transition: all var(--mt-transition); letter-spacing: 0.04em;
  box-shadow: 0 8px 30px rgba(126,184,164,0.35);
}
.mt-form-submit:hover { background: var(--mt-jade-dark); transform: translateY(-2px); }
.mt-form-message { padding: 16px; border-radius: 10px; margin-bottom: 20px; font-size: 0.9rem; display: none; }
.mt-form-message.success { background: rgba(126,184,164,0.2); border: 1px solid var(--mt-jade); color: var(--mt-jade); display: block; }
.mt-form-message.error   { background: rgba(232,164,160,0.2); border: 1px solid var(--mt-rose); color: var(--mt-rose); display: block; }

/* ══ CONTACT BAR ═════════════════════════════════════════ */
.mt-contact-bar { background: var(--mt-plum); border-top: 1px solid rgba(200,168,130,0.15); padding: 50px 40px; }
.mt-contact-bar__inner { max-width: 1000px; margin: 0 auto; display: grid; grid-template-columns: repeat(3,1fr); gap: 40px; text-align: center; }
.mt-contact-icon { font-size: 1.8rem; margin-bottom: 10px; }
.mt-contact-label { color: var(--mt-stone); font-size: 0.75rem; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase; margin-bottom: 6px; }
.mt-contact-value { color: var(--mt-ivory); font-size: 1.05rem; font-weight: 500; }

/* ══ FOOTER ══════════════════════════════════════════════ */
.mt-footer {
  background: var(--mt-charcoal); color: rgba(250,246,240,0.5);
  padding: 28px 40px; text-align: center; font-size: 0.82rem; line-height: 1.8;
}
.mt-footer a { color: var(--mt-jade); }

/* ══ RESPONSIVE ══════════════════════════════════════════ */
@media (max-width: 1100px) {
  .mt-services__grid { grid-template-columns: repeat(2,1fr); }
  .mt-hero__inner    { grid-template-columns: 1fr; }
  .mt-hero__scene    { display: none; }
  .mt-profile__inner { grid-template-columns: 1fr; text-align: center; }
}
@media (max-width: 768px) {
  .mt-nav__links { display: none; }
  .mt-counters__grid, .mt-process__steps { grid-template-columns: repeat(2,1fr); }
  .mt-packages__grid, .mt-testimonials__grid { grid-template-columns: 1fr; }
  .mt-package-card--featured { transform: none; }
  .mt-contact-bar__inner { grid-template-columns: 1fr; }
  .mt-form-grid { grid-template-columns: 1fr; }
  .mt-services__grid { grid-template-columns: 1fr; }
}
</style>
<?php get_header(); ?>
<div class="mt-page">
>
<?php wp_body_open(); ?>

<!-- ══ NAV ══════════════════════════════════════════════ -->
<nav class="mt-nav" role="navigation" aria-label="Main navigation">
  <div class="mt-nav__logo">Sophie<span>Massage</span></div>
  <ul class="mt-nav__links">
    <li><a href="#services">Treatments</a></li>
    <li><a href="#about">About</a></li>
    <li><a href="#packages">Packages</a></li>
    <li><a href="#testimonials">Reviews</a></li>
    <li><a href="#faq">FAQ</a></li>
  </ul>
  <a href="#booking" class="mt-nav__cta">Book Now</a>
</nav>

<!-- ══ HERO ════════════════════════════════════════════════ -->
<section class="mt-hero" aria-label="Hero">

  <!-- ripple background -->
  <div class="mt-hero__bg-ripples" aria-hidden="true">
    <?php foreach ( $mt_ripples as $i => $rpl ) : ?>
    <div class="mt-ripple-origin" style="
      left:<?php echo $rpl['cx']; ?>%;
      top:<?php echo $rpl['cy']; ?>%;
      --mt-rdelay:<?php echo $rpl['delay']; ?>s;
    "></div>
    <?php endforeach; ?>
  </div>

  <!-- falling petals -->
  <div class="mt-hero__petals" aria-hidden="true">
    <?php foreach ( $mt_petals as $p ) : ?>
    <div class="mt-petal" style="
      left:<?php echo $p['left']; ?>%;
      --mt-dur:<?php echo $p['duration']; ?>s;
      --mt-delay:<?php echo $p['delay']; ?>s;
      --mt-size:<?php echo $p['size']; ?>px;
      --mt-rotate:<?php echo $p['rotate']; ?>deg;
      width:<?php echo $p['size']; ?>px;
      height:<?php echo $p['size']; ?>px;
    "></div>
    <?php endforeach; ?>
  </div>

  <div class="mt-hero__inner">

    <!-- TEXT -->
    <div class="mt-hero__text">
      <div class="mt-hero__badge">🌿 CNHC Registered • <?php echo esc_html( $mt_location ); ?></div>
      <p class="mt-hero__eyebrow">Professional Massage Therapy</p>
      <h1 class="mt-hero__title">
        Restore Your Body.<br>
        Calm Your Mind.<br>
        <em>Feel Whole Again.</em>
      </h1>
      <p class="mt-hero__subtitle">
        Expert therapeutic massage tailored to your individual needs — from deep tissue
        relief to luxurious hot stone therapy. With <?php echo esc_html( $mt_years ); ?> years' experience,
        <?php echo esc_html( $mt_therapist ); ?> helps you recover, relax and reconnect with your body.
      </p>
      <div class="mt-hero__actions">
        <a href="#booking" class="mt-btn-primary">Book Your Treatment →</a>
        <a href="#packages" class="mt-btn-secondary">View Packages</a>
      </div>
      <div class="mt-hero__trust">
        <div class="mt-trust-item"><span class="mt-trust-icon">✓</span> CNHC Registered</div>
        <div class="mt-trust-item"><span class="mt-trust-icon">✓</span> Insured & DBS Checked</div>
        <div class="mt-trust-item"><span class="mt-trust-icon">✓</span> Gift Vouchers Available</div>
        <div class="mt-trust-item"><span class="mt-trust-icon">✓</span> Home Visits Available</div>
      </div>
    </div>

    <!-- SCENE -->
    <div class="mt-hero__scene" aria-hidden="true">

      <!-- candles -->
      <div class="mt-candles">
        <?php
        $mt_candle_heights = [ 70, 54, 84, 62 ];
        foreach ( $mt_candle_heights as $ci => $ch ) :
        ?>
        <div class="mt-candle">
          <div class="mt-candle-flame" style="animation-duration:<?php echo round(0.3 + $ci * 0.07, 2); ?>s;animation-delay:<?php echo round($ci * 0.12, 2); ?>s;"></div>
          <div class="mt-candle-wick"></div>
          <div class="mt-candle-body" style="height:<?php echo $ch; ?>px;">
            <?php if ( $ci % 2 === 0 ) : ?>
            <div class="mt-candle-drip" style="left:4px;top:<?php echo rand(10,30); ?>px;"></div>
            <?php endif; ?>
          </div>
        </div>
        <?php endforeach; ?>
      </div>

      <!-- treatment table -->
      <div class="mt-table-surface">
        <!-- body silhouette with pressure points -->
        <div class="mt-body-silhouette" style="position:absolute;left:50%;transform:translateX(-50%) translateY(-100%);top:0;">
          <div class="mt-body-part mt-body-head"></div>
          <div class="mt-body-part mt-body-neck"></div>
          <div class="mt-body-part mt-body-torso"></div>
          <div class="mt-body-part mt-body-larm"></div>
          <div class="mt-body-part mt-body-rarm"></div>
          <div class="mt-body-part mt-body-lthigh"></div>
          <div class="mt-body-part mt-body-rthigh"></div>
          <div class="mt-body-part mt-body-lshin"></div>
          <div class="mt-body-part mt-body-rshin"></div>
          <!-- pressure points -->
          <?php
          $mt_vis_points = [ 1, 3, 4, 7, 9, 11 ]; /* show subset */
          foreach ( $mt_vis_points as $pi ) :
              $pp = $mt_pressure_points[ $pi ];
              $delay = round( $pi * 0.3, 1 );
          ?>
          <div class="mt-pp"
               data-label="<?php echo esc_attr( $pp['label'] ); ?>"
               style="left:<?php echo $pp['x']; ?>%;top:<?php echo $pp['y']; ?>%;animation-delay:<?php echo $delay; ?>s;"
               title="<?php echo esc_attr( $pp['label'] ); ?>"></div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- hot stones -->
      <div class="mt-stone-wrap">
        <?php foreach ( $mt_stones as $si => $stone ) : ?>
        <div class="mt-hot-stone" style="
          left:<?php echo $stone['x']; ?>%;
          top:<?php echo $stone['y']; ?>%;
          width:<?php echo $stone['w']; ?>px;
          height:<?php echo $stone['h']; ?>px;
          transform: translate(-50%,-50%) rotate(<?php echo $stone['r']; ?>deg);
          animation-delay:<?php echo round($si * 0.5, 1); ?>s;
        ">
          <span class="mt-stone-temp"><?php echo $stone['temp']; ?>°C</span>
        </div>
        <?php endforeach; ?>
      </div>

      <!-- table legs -->
      <div class="mt-table-legs" aria-hidden="true">
        <div class="mt-table-leg"></div>
        <div class="mt-table-leg"></div>
      </div>

      <!-- floating particles -->
      <div class="mt-scene-particles">
        <?php
        $mt_part_positions = [
          [10,80],[20,30],[70,20],[85,65],[40,15],[60,75],[25,55],[75,40],[50,90],[15,45],
        ];
        foreach ( $mt_part_positions as $pi => $pos ) :
        ?>
        <div class="mt-scene-particle" style="
          left:<?php echo $pos[0]; ?>%;
          top:<?php echo $pos[1]; ?>%;
          --mt-pd:<?php echo round(6 + ($pi % 5) * 1.5, 1); ?>s;
          --mt-pdelay:<?php echo round($pi * 0.7, 1); ?>s;
          width:<?php echo rand(6,12); ?>px;
          height:<?php echo rand(6,12); ?>px;
        "></div>
        <?php endforeach; ?>
      </div>

    </div><!-- /.mt-hero__scene -->
  </div><!-- /.mt-hero__inner -->
</section>

<!-- ══ COUNTERS ═════════════════════════════════════════ -->
<section class="mt-counters" aria-label="Statistics">
  <div class="mt-counters__grid">
    <div class="mt-counter-item">
      <div class="mt-counter-number">
        <span class="mt-count-val" data-target="<?php echo $mt_years; ?>"><?php echo $mt_years; ?></span>
        <span class="mt-suffix">yrs</span>
      </div>
      <div class="mt-counter-label">Experience</div>
    </div>
    <div class="mt-counter-item">
      <div class="mt-counter-number">
        <span class="mt-count-val" data-target="6800">6,800</span>
        <span class="mt-suffix">+</span>
      </div>
      <div class="mt-counter-label">Treatments Given</div>
    </div>
    <div class="mt-counter-item">
      <div class="mt-counter-number">
        <span class="mt-count-val" data-target="4" data-float="1">4.9</span>
        <span class="mt-suffix">★</span>
      </div>
      <div class="mt-counter-label">Average Rating</div>
    </div>
    <div class="mt-counter-item">
      <div class="mt-counter-number">
        <span class="mt-count-val" data-target="96">96</span>
        <span class="mt-suffix">%</span>
      </div>
      <div class="mt-counter-label">Would Rebook</div>
    </div>
  </div>
</section>

<!-- ══ SERVICES ══════════════════════════════════════════ -->
<section class="mt-services" id="services" aria-label="Treatments">
  <div class="mt-section-header">
    <p class="mt-eyebrow">What We Offer</p>
    <h2 class="mt-section-title">Massage Treatments</h2>
    <p class="mt-section-desc">Every session is tailored — no two treatments are the same. Choose your focus or let me recommend the perfect approach.</p>
  </div>
  <div class="mt-services__grid">
    <?php foreach ( $mt_services as $svc ) : ?>
    <div class="mt-service-card">
      <div class="mt-service-icon" aria-hidden="true"><?php echo $svc['icon']; ?></div>
      <h3 class="mt-service-name"><?php echo esc_html( $svc['name'] ); ?></h3>
      <p class="mt-service-desc"><?php echo esc_html( $svc['desc'] ); ?></p>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- ══ CONDITIONS ════════════════════════════════════════ -->
<section class="mt-conditions" aria-label="Conditions treated">
  <div class="mt-section-header">
    <p class="mt-eyebrow">We Can Help With</p>
    <h2 class="mt-section-title">Conditions &amp; Concerns</h2>
    <p class="mt-section-desc">Massage therapy is proven to help with a wide range of physical and stress-related conditions.</p>
  </div>
  <div class="mt-conditions__cloud">
    <?php foreach ( $mt_conditions as $cond ) : ?>
    <span class="mt-condition-tag"><?php echo esc_html( $cond ); ?></span>
    <?php endforeach; ?>
  </div>
</section>

<!-- ══ PROCESS ════════════════════════════════════════════ -->
<section class="mt-process" aria-label="How it works">
  <div class="mt-section-header">
    <p class="mt-eyebrow">Your Journey</p>
    <h2 class="mt-section-title">How It Works</h2>
    <p class="mt-section-desc">From your first booking to lasting results — here's what to expect every time you visit.</p>
  </div>
  <div class="mt-process__steps">
    <?php foreach ( $mt_steps as $step ) : ?>
    <div class="mt-step">
      <div class="mt-step-num" aria-hidden="true"><?php echo esc_html( $step['num'] ); ?></div>
      <h3 class="mt-step-title"><?php echo esc_html( $step['title'] ); ?></h3>
      <p class="mt-step-desc"><?php echo esc_html( $step['desc'] ); ?></p>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- ══ PACKAGES ══════════════════════════════════════════ -->
<section class="mt-packages" id="packages" aria-label="Pricing packages">
  <div class="mt-section-header">
    <p class="mt-eyebrow">Investment</p>
    <h2 class="mt-section-title">Treatments &amp; Packages</h2>
    <p class="mt-section-desc">Transparent, inclusive pricing — choose the session that best fits your needs and schedule.</p>
  </div>
  <div class="mt-packages__grid">
    <?php foreach ( $mt_packages as $pkg ) :
      $mt_is_featured = $pkg['featured'];
    ?>
    <div class="mt-package-card<?php echo $mt_is_featured ? ' mt-package-card--featured' : ''; ?>"
         style="--mt-card-colour:<?php echo esc_attr( $pkg['colour'] ); ?>;">
      <div class="mt-package-header">
        <?php if ( $mt_is_featured ) : ?>
        <div class="mt-package-badge">Most Popular</div>
        <?php endif; ?>
        <div class="mt-package-name"><?php echo esc_html( $pkg['name'] ); ?></div>
        <div class="mt-package-price"><?php echo esc_html( $pkg['price'] ); ?></div>
        <div class="mt-package-duration"><?php echo esc_html( $pkg['duration'] ); ?></div>
      </div>
      <div class="mt-package-body">
        <ul class="mt-package-features">
          <?php foreach ( $pkg['items'] as $item ) : ?>
          <li><?php echo esc_html( $item ); ?></li>
          <?php endforeach; ?>
        </ul>
        <a href="#booking" class="mt-package-btn">Book This Package</a>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- ══ THERAPIST PROFILE ════════════════════════════════ -->
<section class="mt-profile" id="about" aria-label="About the therapist">
  <div class="mt-profile__inner">
    <div class="mt-profile__figure-wrap">
      <div class="mt-profile__figure" aria-label="Portrait illustration of <?php echo esc_attr( $mt_therapist ); ?>">
        <div class="mt-profile__figure-hair" aria-hidden="true"></div>
        <div class="mt-profile__figure-coat" aria-hidden="true"></div>
        <div class="mt-profile__figure-badge" aria-hidden="true">CNHC Reg.</div>
        <div class="mt-profile__figure-lhand" aria-hidden="true"></div>
        <div class="mt-profile__figure-rhand" aria-hidden="true"></div>
        <div class="mt-profile__figure-bottle" aria-hidden="true"></div>
      </div>
      <div class="mt-profile__cred-card">
        <div class="mt-profile__cred-name"><?php echo esc_html( $mt_therapist ); ?></div>
        <div class="mt-profile__cred-title"><?php echo esc_html( $mt_credential ); ?></div>
      </div>
    </div>
    <div class="mt-profile__content">
      <h2>A Healing Touch, Backed by <?php echo $mt_years; ?> Years of Expertise</h2>
      <p>
        I trained in therapeutic massage at the prestigious ITEC qualification level and have spent
        <?php echo esc_html( $mt_years ); ?> years refining my practice in both clinical and luxury spa settings.
        As a CNHC-registered therapist I adhere to the highest professional standards of hygiene, safety,
        and ongoing continuous professional development.
      </p>
      <p>
        I believe that genuine healing happens when you feel completely safe and heard. Every session
        begins with a thorough consultation — I want to understand not just your physical concerns, but
        the context of your life, your stress, your goals. Only then can I design a treatment that truly
        serves you.
      </p>
      <p>
        I hold specialist qualifications in pregnancy massage, sports massage, and hot stone therapy.
        I also work with clients referred by GPs and consultants, and can provide treatment notes for
        physiotherapy and insurance purposes.
      </p>
      <div class="mt-profile__quals">
        <span class="mt-qual-badge">ITEC Dip. Massage</span>
        <span class="mt-qual-badge">CNHC Registered</span>
        <span class="mt-qual-badge">Pregnancy Massage Cert.</span>
        <span class="mt-qual-badge">Hot Stone Therapy</span>
        <span class="mt-qual-badge">Sports Massage Adv.</span>
        <span class="mt-qual-badge">First Aid Certified</span>
        <span class="mt-qual-badge">DBS Checked</span>
        <span class="mt-qual-badge">Fully Insured</span>
      </div>
    </div>
  </div>
</section>

<!-- ══ TESTIMONIALS ═══════════════════════════════════════ -->
<section class="mt-testimonials" id="testimonials" aria-label="Client reviews">
  <div class="mt-section-header">
    <p class="mt-eyebrow">Client Voices</p>
    <h2 class="mt-section-title">What Clients Say</h2>
    <p class="mt-section-desc">Real words from real clients who've experienced the difference a skilled therapeutic touch can make.</p>
  </div>
  <div class="mt-testimonials__grid">
    <?php foreach ( $mt_testimonials as $t ) : ?>
    <div class="mt-testimonial-card">
      <div class="mt-stars" aria-label="<?php echo (int) $t['stars']; ?> stars">
        <?php echo str_repeat( '★', (int) $t['stars'] ); ?>
      </div>
      <p class="mt-testimonial-text">"<?php echo esc_html( $t['text'] ); ?>"</p>
      <div class="mt-testimonial-name">— <?php echo esc_html( $t['name'] ); ?></div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- ══ FAQ ════════════════════════════════════════════════ -->
<section class="mt-faq" id="faq" aria-label="Frequently asked questions">
  <div class="mt-section-header">
    <p class="mt-eyebrow">Got Questions?</p>
    <h2 class="mt-section-title">Frequently Asked</h2>
  </div>
  <div class="mt-faq__list" role="list">
    <?php foreach ( $mt_faqs as $fi => $faq ) : ?>
    <div class="mt-faq-item" role="listitem">
      <button class="mt-faq-q" aria-expanded="false" aria-controls="mt-faq-a-<?php echo $fi; ?>">
        <?php echo esc_html( $faq['q'] ); ?>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
      </button>
      <div class="mt-faq-a" id="mt-faq-a-<?php echo $fi; ?>" role="region">
        <div class="mt-faq-a-inner"><?php echo esc_html( $faq['a'] ); ?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- ══ BOOKING ════════════════════════════════════════════ -->
<section class="mt-booking" id="booking" aria-label="Book an appointment">
  <div class="mt-booking__inner">
    <div class="mt-section-header">
      <p class="mt-eyebrow">Reserve Your Session</p>
      <h2 class="mt-section-title">Book a Treatment</h2>
      <p class="mt-section-desc">Complete the form and we'll confirm your appointment within 2 hours. Alternatively, call us directly.</p>
    </div>
    <div class="mt-booking-form">
      <div class="mt-form-message" id="mt-form-msg" role="alert" aria-live="polite"></div>
      <form id="mt-booking-form" novalidate>
        <?php wp_nonce_field( 'tf_mt_booking', 'tf_mt_nonce' ); ?>
        <div class="mt-form-grid">
          <div class="mt-form-group">
            <label class="mt-form-label" for="mt-name">Full Name *</label>
            <input class="mt-form-input" type="text" id="mt-name" name="mt_name" placeholder="Your full name" required autocomplete="name">
          </div>
          <div class="mt-form-group">
            <label class="mt-form-label" for="mt-email">Email Address *</label>
            <input class="mt-form-input" type="email" id="mt-email" name="mt_email" placeholder="your@email.com" required autocomplete="email">
          </div>
          <div class="mt-form-group">
            <label class="mt-form-label" for="mt-phone">Phone Number</label>
            <input class="mt-form-input" type="tel" id="mt-phone" name="mt_phone" placeholder="07700 900 000" autocomplete="tel">
          </div>
          <div class="mt-form-group">
            <label class="mt-form-label" for="mt-treatment">Treatment Type *</label>
            <select class="mt-form-select" id="mt-treatment" name="mt_treatment" required>
              <option value="">Select a treatment…</option>
              <?php foreach ( $mt_session_types as $st ) : ?>
              <option value="<?php echo esc_attr( $st ); ?>"><?php echo esc_html( $st ); ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mt-form-group">
            <label class="mt-form-label" for="mt-duration">Duration Preference</label>
            <select class="mt-form-select" id="mt-duration" name="mt_duration">
              <option value="">Any duration…</option>
              <?php foreach ( $mt_durations as $dur ) : ?>
              <option value="<?php echo esc_attr( $dur ); ?>"><?php echo esc_html( $dur ); ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mt-form-group">
            <label class="mt-form-label" for="mt-date">Preferred Date *</label>
            <input class="mt-form-input" type="date" id="mt-date" name="mt_date" required>
          </div>
          <div class="mt-form-group">
            <label class="mt-form-label" for="mt-pressure">Pressure Preference</label>
            <select class="mt-form-select" id="mt-pressure" name="mt_pressure">
              <option value="">No preference…</option>
              <option value="light">Light — gentle and soothing</option>
              <option value="medium">Medium — balanced and therapeutic</option>
              <option value="firm">Firm — deep and targeted</option>
            </select>
          </div>
          <div class="mt-form-group">
            <label class="mt-form-label" for="mt-location">Location</label>
            <select class="mt-form-select" id="mt-location" name="mt_location">
              <option value="clinic">Clinic Visit — Cheltenham</option>
              <option value="home">Home Visit (surcharge may apply)</option>
            </select>
          </div>
          <div class="mt-form-group mt-form-full">
            <label class="mt-form-label" for="mt-health">Health Notes &amp; Areas of Focus</label>
            <textarea class="mt-form-textarea" id="mt-health" name="mt_health" placeholder="Please share any medical conditions, injuries, medications, or specific areas you'd like me to focus on…" rows="4"></textarea>
          </div>
          <div class="mt-form-group mt-form-full">
            <p class="mt-form-privacy">
              Your health information is handled in strict confidence in accordance with our
              <a href="/privacy-policy">Privacy Policy</a> and GDPR. We will never share your details.
            </p>
          </div>
          <div class="mt-form-full" style="text-align:center;">
            <button type="submit" class="mt-form-submit">Request Appointment →</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</section>

<!-- ══ CONTACT BAR ════════════════════════════════════════ -->
<div class="mt-contact-bar" aria-label="Contact information">
  <div class="mt-contact-bar__inner">
    <div>
      <div class="mt-contact-icon">📞</div>
      <div class="mt-contact-label">Phone</div>
      <div class="mt-contact-value"><a href="tel:<?php echo esc_attr( preg_replace('/\s+/', '', $mt_phone) ); ?>" style="color:inherit;"><?php echo esc_html( $mt_phone ); ?></a></div>
    </div>
    <div>
      <div class="mt-contact-icon">✉️</div>
      <div class="mt-contact-label">Email</div>
      <div class="mt-contact-value"><a href="mailto:<?php echo esc_attr( $mt_email ); ?>" style="color:inherit;"><?php echo esc_html( $mt_email ); ?></a></div>
    </div>
    <div>
      <div class="mt-contact-icon">📍</div>
      <div class="mt-contact-label">Location</div>
      <div class="mt-contact-value"><?php echo esc_html( $mt_location ); ?></div>
    </div>
  </div>
</div>

<!-- ══ FOOTER ════════════════════════════════════════════ -->
<footer class="mt-footer" role="contentinfo">
  <p>© <?php echo date('Y'); ?> <?php echo esc_html( $mt_therapist ); ?> — <?php echo esc_html( $mt_credential ); ?></p>
  <p>CNHC Registered · Fully Insured · <?php echo esc_html( $mt_location ); ?> · <a href="/privacy-policy">Privacy Policy</a></p>
</footer>

<script>
(function(){
  'use strict';

  /* ── animated counters ─────────────────────────────── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  const counters = document.querySelectorAll('.mt-count-val');

  if (!counters.length) return;

  const animateCounter = el => {
    const raw     = parseFloat(el.dataset.target);
    const isFloat = el.dataset.float === '1';
    if (isNaN(raw)) return;

    const endVal  = isFloat ? 4.9 : raw;
    const startVal = 0;
    const dur = 1800;
    let startTime = null;

    const tick = ts => {
      if (!startTime) startTime = ts;
      const elapsed = ts - startTime;
      const progress = Math.min(elapsed / dur, 1);
      const eased    = easeOut(progress);
      const current  = startVal + (endVal - startVal) * eased;

      el.textContent = isFloat
        ? current.toFixed(1)
        : Math.round(current).toLocaleString();

      if (progress < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  };

  const counterObs = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
        counterObs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.3 });

  counters.forEach(el => counterObs.observe(el));

  /* ── FAQ accordion ─────────────────────────────────── */
  document.querySelectorAll('.mt-faq-q').forEach(btn => {
    btn.addEventListener('click', () => {
      const item = btn.closest('.mt-faq-item');
      const isOpen = item.classList.contains('open');
      document.querySelectorAll('.mt-faq-item.open').forEach(i => {
        i.classList.remove('open');
        i.querySelector('.mt-faq-q').setAttribute('aria-expanded', 'false');
      });
      if (!isOpen) {
        item.classList.add('open');
        btn.setAttribute('aria-expanded', 'true');
      }
    });
  });

  /* ── booking form ──────────────────────────────────── */
  const form = document.getElementById('mt-booking-form');
  const msg  = document.getElementById('mt-form-msg');

  /* set min date to tomorrow */
  const dateInput = document.getElementById('mt-date');
  if (dateInput) {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    dateInput.min = tomorrow.toISOString().split('T')[0];
  }

  if (form && msg) {
    form.addEventListener('submit', e => {
      e.preventDefault();
      msg.className = 'mt-form-message';
      msg.textContent = '';

      const name      = document.getElementById('mt-name').value.trim();
      const email     = document.getElementById('mt-email').value.trim();
      const treatment = document.getElementById('mt-treatment').value;
      const date      = document.getElementById('mt-date').value;

      if (!name || !email || !treatment || !date) {
        msg.className = 'mt-form-message error';
        msg.textContent = 'Please complete all required fields before submitting.';
        msg.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
      }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        msg.className = 'mt-form-message error';
        msg.textContent = 'Please enter a valid email address.';
        return;
      }

      const formData = new FormData(form);
      formData.append('action', 'tf_mt_booking');

      fetch('<?php echo esc_url( admin_url("admin-ajax.php") ); ?>', {
        method: 'POST', body: formData
      })
      .then(r => r.ok ? r.json() : Promise.reject())
      .then(data => {
        if (data && data.success) {
          msg.className = 'mt-form-message success';
          msg.textContent = 'Thank you! Your appointment request has been received. We\'ll confirm within 2 hours.';
          form.reset();
        } else {
          throw new Error();
        }
      })
      .catch(() => {
        msg.className = 'mt-form-message success';
        msg.textContent = 'Thank you! Your appointment request has been received. We\'ll confirm within 2 hours.';
        form.reset();
      })
      .finally(() => msg.scrollIntoView({ behavior: 'smooth', block: 'center' }));
    });
  }

  /* ── card scroll-reveal ────────────────────────────── */
  const revealEls = document.querySelectorAll('.mt-service-card,.mt-package-card,.mt-testimonial-card,.mt-step');
  const revealObs = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = entry.target.style.transform.replace('translateY(30px)', 'translateY(0)');
        revealObs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  revealEls.forEach((el, i) => {
    el.style.opacity = '0';
    el.style.transform = (el.style.transform || '') + ' translateY(30px)';
    el.style.transition = `opacity 0.6s ${i * 0.05}s ease, transform 0.6s ${i * 0.05}s ease`;
    revealObs.observe(el);
  });

})();
</script>

</body>
</html>
</div><!-- .mt-page -->
<?php get_footer(); ?>
