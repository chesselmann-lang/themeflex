<?php
/**
 * Template Name: Massage Therapy — Serenity Studio
 *
 * Premium massage therapy & wellness page template.
 * Palette  : warm stone #8B7355 / deep sage #3D5A47 / blush ivory #FAF6F1 / terracotta #C4694A / charcoal #2A2A2A
 * Fonts    : Playfair Display (headings) + Lato (body)
 * Namespace: --ms-*
 *
 * @package ThemeFlex
 */

if ( ! defined( 'ABSPATH' ) ) exit;

srand( crc32( get_the_permalink() ) );

/* ── helpers ── */
$site  = get_bloginfo( 'name' ) ?: 'Serenity Studio';
$phone = get_theme_mod( 'tf_phone', '+44 20 7946 0711' );
$email = get_theme_mod( 'tf_email', 'hello@serenitystudio.co.uk' );
$addr  = get_theme_mod( 'tf_address', '28 Harley Street, London W1G' );

/* ── floating petals ── */
$petal_pos = [
  ['3%','8%'],['8%','88%'],['15%','55%'],['22%','3%'],['28%','78%'],
  ['36%','18%'],['42%','92%'],['50%','42%'],['58%','12%'],['65%','68%'],
  ['72%','28%'],['80%','85%'],['88%','5%'],['94%','50%'],['10%','32%'],
];

/* ── treatments ── */
$treatments = [
  [
    'icon'  => '🌿',
    'title' => 'Swedish Massage',
    'times' => '60 / 90 min',
    'price' => '£80 / £110',
    'desc'  => 'The classic full-body relaxation massage. Long flowing strokes melt away tension, improve circulation, and leave you feeling deeply restored.',
  ],
  [
    'icon'  => '🔥',
    'title' => 'Hot Stone Therapy',
    'times' => '75 / 90 min',
    'price' => '£95 / £115',
    'desc'  => 'Warmed basalt stones glide over key muscle groups, releasing deep tension and promoting profound relaxation that lasts for days.',
  ],
  [
    'icon'  => '💆',
    'title' => 'Deep Tissue Massage',
    'times' => '60 / 90 min',
    'price' => '£90 / £120',
    'desc'  => 'Firm, targeted pressure to release chronic muscle tension, correct postural imbalances, and address persistent knots and adhesions.',
  ],
  [
    'icon'  => '🌸',
    'title' => 'Aromatherapy Massage',
    'times' => '60 / 90 min',
    'price' => '£85 / £115',
    'desc'  => 'A bespoke blend of pure essential oils chosen for your needs — stress relief, energy, sleep, or immunity — with full-body massage.',
  ],
  [
    'icon'  => '🤰',
    'title' => 'Prenatal Massage',
    'times' => '60 min',
    'price' => '£90',
    'desc'  => 'Specially adapted for mothers-to-be from 12 weeks. Relieves lower back pain, swollen ankles, and the stresses of a changing body.',
  ],
  [
    'icon'  => '⚡',
    'title' => 'Sports & Recovery',
    'times' => '60 / 90 min',
    'price' => '£90 / £125',
    'desc'  => 'Pre- or post-event treatment combining deep tissue, myofascial release, and stretching to optimise athletic performance and recovery.',
  ],
];

/* ── add-ons ── */
$addons = [
  [ 'name' => 'CBD Oil Upgrade',       'price' => '+£15', 'desc' => 'Anti-inflammatory cannabidiol oil added to any massage' ],
  [ 'name' => 'Scalp & Head Massage',  'price' => '+£20', 'desc' => 'Melts tension in the scalp, temples, and neck' ],
  [ 'name' => 'Reflexology',           'price' => '+£25', 'desc' => 'Pressure-point foot massage for full-body benefit' ],
  [ 'name' => 'Cupping Therapy',       'price' => '+£20', 'desc' => 'Traditional silicone cupping to lift and release fascia' ],
];

/* ── team ── */
$team = [
  [ 'name' => 'Elena Vasquez',   'title' => 'Lead Therapist & Founder',  'quals' => 'ITEC, VTCT Level 5', 'spec' => 'Oncology & Prenatal' ],
  [ 'name' => 'James Thornton',  'title' => 'Sports Massage Specialist', 'quals' => 'Level 4 Sports Massage', 'spec' => 'Deep Tissue & Recovery' ],
  [ 'name' => 'Aisha Patel',     'title' => 'Holistic Therapist',        'quals' => 'ITEC Aromatherapy', 'spec' => 'Aromatherapy & Reiki' ],
  [ 'name' => 'Claire Donovan',  'title' => 'Stone & Spa Therapist',     'quals' => 'CIBTAC Diploma',    'spec' => 'Hot Stone & CBD' ],
];

/* ── packages ── */
$packages = [
  [
    'name'     => 'Restore',
    'price'    => '£75',
    'period'   => 'single 60-min session',
    'featured' => false,
    'features' => [ 'Swedish or aromatherapy', 'Essential oil blend', 'Pre-session consultation', 'Herbal tea included', 'Aftercare advice' ],
  ],
  [
    'name'     => 'Renew',
    'price'    => '£320',
    'period'   => '5-session course (save £75)',
    'featured' => true,
    'features' => [ '5 × 60-min sessions', 'Personalised treatment plan', 'Preferred time slot held', 'Treatment notes sent', 'Progress check-ins', 'One free upgrade' ],
  ],
  [
    'name'     => 'Revive',
    'price'    => '£180',
    'period'   => 'half-day wellness',
    'featured' => false,
    'features' => [ '90-min signature massage', 'Aromatherapy consultation', 'Reflexology session', 'Lunch & refreshments', 'Relaxation lounge access' ],
  ],
];

/* ── testimonials ── */
$testimonials = [
  [
    'quote' => 'I\'ve been coming to Serenity Studio for three years. Elena\'s deep tissue work genuinely changed my relationship with chronic back pain. I\'ve tried physio, osteopathy, and chiropractors — nothing compares to the sustained relief I get here.',
    'name'  => 'Robert W.',
    'detail'=> 'Regular client — Deep Tissue & Sports',
    'stars' => 5,
  ],
  [
    'quote' => 'My prenatal massages with Elena were the only thing that got me through the third trimester without losing my mind. I felt human again each time I left. Booked my postnatal sessions already.',
    'name'  => 'Sophie L.',
    'detail'=> 'Prenatal & Postnatal client',
    'stars' => 5,
  ],
  [
    'quote' => 'The hot stone massage was the most relaxing experience of my life. I fell asleep mid-session (which I gather is a compliment). Woke up feeling like I\'d slept for a week. Will be a monthly ritual from now on.',
    'name'  => 'Michael C.',
    'detail'=> 'Hot Stone Therapy client',
    'stars' => 5,
  ],
];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400;1,600&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════
   SERENITY STUDIO — CSS CUSTOM PROPERTIES
   ═══════════════════════════════════════════ */
:root {
  --ms-stone:  #8B7355;
  --ms-stone2: #6A5840;
  --ms-sage:   #3D5A47;
  --ms-sage2:  #2E4436;
  --ms-ivory:  #FAF6F1;
  --ms-blush:  #F5EDE4;
  --ms-terra:  #C4694A;
  --ms-dark:   #2A2A2A;
  --ms-muted:  #6B7280;
  --ms-white:  #FFFFFF;
  --ms-rad:    10px;
  --ms-rad-lg: 18px;
  --ms-shadow: 0 4px 24px rgba(139,115,85,.12);
  --ms-shadow2:0 16px 52px rgba(139,115,85,.22);
  --ms-font-h: 'Playfair Display', Georgia, serif;
  --ms-font-b: 'Lato', system-ui, sans-serif;
  --ms-ease:   cubic-bezier(.4,0,.2,1);
}
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: var(--ms-font-b); color: var(--ms-dark); background: var(--ms-ivory); overflow-x: hidden; }
img  { max-width: 100%; display: block; }
a    { color: inherit; text-decoration: none; }
.ms-wrap  { max-width: 1200px; margin: 0 auto; padding: 0 24px; }
.ms-sec   { padding: 100px 0; }
.ms-sec--alt  { background: var(--ms-blush); }
.ms-sec--sage { background: var(--ms-sage); color: var(--ms-white); }
.ms-sec--dark { background: var(--ms-dark); color: var(--ms-white); }
.ms-eyebrow {
  display: inline-block;
  font-family: var(--ms-font-b);
  font-size: .72rem; font-weight: 700;
  letter-spacing: .16em; text-transform: uppercase;
  color: var(--ms-terra);
  margin-bottom: 14px;
}
.ms-sec--sage .ms-eyebrow { color: rgba(255,255,255,.6); }
.ms-sec--dark .ms-eyebrow { color: var(--ms-terra); }
.ms-h2 {
  font-family: var(--ms-font-h);
  font-size: clamp(2rem,3.8vw,3rem);
  font-weight: 600; line-height: 1.2;
  margin-bottom: 18px;
}
.ms-lead {
  font-size: 1.05rem; line-height: 1.8;
  color: var(--ms-muted); max-width: 620px;
}
.ms-sec--sage .ms-lead { color: rgba(255,255,255,.72); }
.ms-sec--dark .ms-lead { color: rgba(255,255,255,.6); }
.ms-center { text-align: center; }
.ms-center .ms-lead { margin: 0 auto; }

/* ════════════════════════════════
   NAVBAR
   ════════════════════════════════ */
.ms-nav {
  position: fixed; top: 0; left: 0; width: 100%; z-index: 1000;
  background: rgba(250,246,241,.97);
  backdrop-filter: blur(10px);
  border-bottom: 1px solid rgba(139,115,85,.15);
}
.ms-nav__inner {
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 24px; height: 72px; max-width: 1200px; margin: 0 auto;
}
.ms-nav__logo {
  font-family: var(--ms-font-h);
  font-size: 1.45rem; font-weight: 700;
  color: var(--ms-dark);
  letter-spacing: .02em;
}
.ms-nav__logo span { color: var(--ms-terra); }
.ms-nav__links { display: flex; gap: 28px; align-items: center; }
.ms-nav__links a {
  font-size: .88rem; font-weight: 700; letter-spacing: .02em;
  color: var(--ms-dark); transition: color .2s;
}
.ms-nav__links a:hover { color: var(--ms-sage); }
.ms-nav__cta {
  background: var(--ms-sage) !important;
  color: var(--ms-white) !important;
  padding: 10px 22px; border-radius: 6px;
  font-weight: 700 !important;
  transition: background .25s !important;
}
.ms-nav__cta:hover { background: var(--ms-sage2) !important; }

/* ════════════════════════════════
   HERO
   ════════════════════════════════ */
.ms-hero {
  position: relative;
  height: 100vh; min-height: 680px;
  background: linear-gradient(145deg, #F2EBE0 0%, #E8DDD0 40%, #F5EDE4 100%);
  overflow: hidden;
  display: flex; align-items: center;
  padding-top: 72px;
}

/* ── floating petals ── */
.ms-hero__petals { position: absolute; inset: 0; pointer-events: none; }
.ms-petal {
  position: absolute;
  width: 12px; height: 18px;
  background: radial-gradient(ellipse, rgba(196,105,74,.5) 0%, rgba(196,105,74,.2) 100%);
  border-radius: 50% 50% 50% 0;
  animation: ms-petal-fall linear infinite;
  opacity: .6;
}
@keyframes ms-petal-fall {
  0%   { transform: translateY(-40px) rotate(0deg); opacity: .8; }
  100% { transform: translateY(110vh) rotate(360deg); opacity: 0; }
}

/* ── CSS treatment room scene ── */
.ms-hero__scene {
  position: absolute;
  right: 0; top: 0; bottom: 0;
  width: 50%;
  overflow: hidden;
}

/* wall — warm linen texture */
.ms-scene__wall {
  position: absolute;
  top: 0; left: 0; right: 0; height: 62%;
  background:
    repeating-linear-gradient(
      0deg,
      transparent 0px, transparent 28px,
      rgba(139,115,85,.04) 28px, rgba(139,115,85,.04) 29px
    ),
    linear-gradient(180deg, #F0E8DC 0%, #E8DDD0 100%);
}
/* dado rail */
.ms-scene__dado {
  position: absolute;
  top: 62%; left: 0; right: 0; height: 10px;
  background: linear-gradient(180deg, #C8A878 0%, #A88858 100%);
  box-shadow: 0 2px 8px rgba(0,0,0,.1);
}
/* lower wall panel */
.ms-scene__panel {
  position: absolute;
  top: calc(62% + 10px); left: 0; right: 0; height: 2%;
  background: #D8C8A8;
}

/* floor — natural wood */
.ms-scene__floor {
  position: absolute;
  bottom: 0; left: 0; right: 0; height: 36%;
  background:
    repeating-linear-gradient(
      90deg,
      #C8A870 0px, #C8A870 60px,
      #B89858 60px, #B89858 62px
    );
}
/* floor mat */
.ms-scene__mat {
  position: absolute;
  bottom: 36%; left: 50%; transform: translateX(-50%);
  width: 65%; height: 3%;
  background: linear-gradient(90deg, var(--ms-sage) 0%, var(--ms-sage2) 100%);
  opacity: .5;
  border-radius: 4px;
}

/* massage table */
.ms-scene__table {
  position: absolute;
  bottom: 38%; left: 15%;
  width: 58%; height: 8%;
  background: linear-gradient(180deg, #FFFAF5 0%, #F0E8DC 100%);
  border-radius: 8px 8px 0 0;
  border: 2px solid rgba(139,115,85,.2);
  box-shadow: 0 4px 16px rgba(0,0,0,.08);
}
/* table legs */
.ms-scene__table::before {
  content: '';
  position: absolute;
  bottom: -120%; left: 6%;
  width: 5%; height: 120%;
  background: #8B6840;
  box-shadow: calc(88% - 5%) 0 0 #8B6840;
  border-radius: 0 0 4px 4px;
}
/* table bolster pillow */
.ms-scene__pillow {
  position: absolute;
  top: -14px; left: 5%;
  width: 20%; height: 20px;
  background: linear-gradient(180deg, #FFFAF5 0%, #F0E8E0 100%);
  border-radius: 10px;
  border: 1px solid rgba(139,115,85,.15);
}

/* client on table */
.ms-scene__client {
  position: absolute;
  bottom: 46%; left: 22%;
  width: 42%; height: 7%;
}
/* body outline on table */
.ms-scene__client-body {
  position: absolute;
  top: 0; left: 0; right: 0; bottom: 0;
  background: linear-gradient(90deg, #D4A888 5%, #C8986A 50%, #D4A888 95%);
  border-radius: 40px;
  opacity: .7;
}
/* draping sheet */
.ms-scene__sheet {
  position: absolute;
  top: 0; left: 20%; right: 0; bottom: -4px;
  background: linear-gradient(180deg, var(--ms-white) 0%, rgba(255,255,255,.9) 100%);
  border-radius: 0 40px 40px 0;
  border: 1px solid rgba(139,115,85,.1);
}
/* head showing */
.ms-scene__client-head {
  position: absolute;
  top: -20px; left: 0%;
  width: 32px; height: 32px;
  background: #C8906A;
  border-radius: 50%;
}
.ms-scene__client-head::before {
  content: '';
  position: absolute;
  top: -6px; left: 50%; transform: translateX(-50%);
  width: 34px; height: 14px;
  background: #2A1A0A;
  border-radius: 50% 50% 0 0;
}

/* therapist figure */
.ms-scene__therapist {
  position: absolute;
  bottom: 38%; right: 14%;
}
.ms-scene__therapist-body {
  position: relative;
  width: 52px; height: 100px;
  background: var(--ms-sage);
  border-radius: 6px 6px 0 0;
}
/* scrubs */
.ms-scene__therapist-body::before {
  content: '';
  position: absolute;
  top: 8px; left: 50%; transform: translateX(-50%);
  width: 36px; height: 72px;
  background: rgba(255,255,255,.15);
  border-radius: 4px;
}
.ms-scene__therapist-head {
  position: absolute;
  top: -46px; left: 50%; transform: translateX(-50%);
  width: 36px; height: 36px;
  background: #C8906A;
  border-radius: 50%;
}
.ms-scene__therapist-head::before {
  content: '';
  position: absolute;
  top: -6px; left: 50%; transform: translateX(-50%);
  width: 38px; height: 18px;
  background: #2A1A0A;
  border-radius: 50% 50% 0 0;
}
.ms-scene__therapist-head::after {
  content: '';
  position: absolute;
  top: -10px; right: -6px;
  width: 16px; height: 16px;
  background: #2A1A0A;
  border-radius: 50%;
}
/* therapist arms reaching toward client */
.ms-scene__therapist-arm-l {
  position: absolute;
  top: 18px; left: -30px;
  width: 30px; height: 10px;
  background: var(--ms-sage);
  border-radius: 5px;
  transform: rotate(-20deg);
  transform-origin: right center;
}
.ms-scene__therapist-arm-r {
  position: absolute;
  top: 28px; left: -34px;
  width: 34px; height: 10px;
  background: var(--ms-sage);
  border-radius: 5px;
  transform: rotate(-10deg);
  transform-origin: right center;
}

/* essential oil diffuser on shelf */
.ms-scene__diffuser {
  position: absolute;
  bottom: 37%; right: 35%;
  width: 20px; height: 34px;
}
.ms-scene__diffuser::before {
  content: '';
  position: absolute;
  bottom: 0; left: 50%; transform: translateX(-50%);
  width: 20px; height: 28px;
  background: linear-gradient(180deg, #F0E8E0 0%, #D8D0C8 100%);
  border-radius: 10px 10px 4px 4px;
}
/* steam wisps */
.ms-scene__diffuser::after {
  content: '';
  position: absolute;
  top: -8px; left: 50%; transform: translateX(-50%);
  width: 4px; height: 12px;
  background: rgba(255,255,255,.7);
  border-radius: 4px;
  animation: ms-steam 2s ease-in-out infinite;
  box-shadow: -6px 0 0 rgba(255,255,255,.5), 6px 0 0 rgba(255,255,255,.5);
}
@keyframes ms-steam {
  0%, 100% { transform: translateX(-50%) scaleY(1); opacity: .7; }
  50%       { transform: translateX(-50%) scaleY(1.5) translateY(-4px); opacity: .3; }
}

/* shelf with candles and oils */
.ms-scene__shelf {
  position: absolute;
  top: 10%; right: 4%;
  width: 20%; height: 42%;
  background: rgba(255,255,255,.4);
  border: 1px solid rgba(139,115,85,.15);
  border-radius: 4px;
}
.ms-scene__shelf::before {
  content: '';
  position: absolute;
  left: 0; right: 0; top: 40%; height: 2px;
  background: rgba(139,115,85,.2);
  box-shadow: 0 calc(40%) 0 rgba(139,115,85,.2);
}
/* PHP candles rendered below */

/* window with nature view */
.ms-scene__window {
  position: absolute;
  top: 5%; left: 5%;
  width: 28%; height: 44%;
  background: linear-gradient(180deg, #C8E8D8 0%, #A8D8C0 60%, #D8E8C0 100%);
  border: 3px solid #D8C8A8;
  border-radius: 6px 6px 0 0;
}
.ms-scene__window::before {
  content: '';
  position: absolute;
  top: 0; left: 50%; width: 2px; bottom: 0;
  background: #D8C8A8;
}
/* foliage through window */
.ms-scene__window::after {
  content: '';
  position: absolute;
  bottom: 0; left: 0; right: 0; height: 50%;
  background:
    radial-gradient(ellipse at 20% 100%, rgba(61,90,71,.6) 0%, transparent 40%),
    radial-gradient(ellipse at 60% 100%, rgba(61,90,71,.5) 0%, transparent 35%),
    radial-gradient(ellipse at 90% 80%, rgba(61,90,71,.4) 0%, transparent 30%);
}

/* framed botanical on wall */
.ms-scene__art {
  position: absolute;
  top: 7%; left: 38%;
  width: 18%; height: 30%;
  background: var(--ms-white);
  border: 3px solid #D8C8A8;
  border-radius: 4px;
  display: flex; align-items: center; justify-content: center;
  font-size: 2rem;
}

/* ── hero text ── */
.ms-hero__content {
  position: relative; z-index: 2;
  max-width: 540px;
  padding: 0 24px 0 60px;
}
.ms-hero__eyebrow {
  display: inline-flex; align-items: center; gap: 10px;
  font-size: .72rem; font-weight: 700;
  letter-spacing: .16em; text-transform: uppercase;
  color: var(--ms-terra);
  margin-bottom: 18px;
}
.ms-hero__eyebrow::before,
.ms-hero__eyebrow::after {
  content: ''; display: block;
  width: 24px; height: 1px;
  background: var(--ms-terra); opacity: .5;
}
.ms-hero__h1 {
  font-family: var(--ms-font-h);
  font-size: clamp(2.4rem,4.5vw,3.8rem);
  font-weight: 600; line-height: 1.12;
  color: var(--ms-dark);
  margin-bottom: 22px;
}
.ms-hero__h1 em { font-style: italic; color: var(--ms-sage); }
.ms-hero__tag {
  font-size: 1.05rem; line-height: 1.8;
  color: var(--ms-muted);
  margin-bottom: 32px; max-width: 440px;
}
.ms-hero__actions { display: flex; gap: 14px; flex-wrap: wrap; }
.ms-btn {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 14px 28px; border-radius: 8px;
  font-family: var(--ms-font-b);
  font-size: .9rem; font-weight: 700;
  cursor: pointer; border: none;
  transition: all .3s var(--ms-ease);
}
.ms-btn--sage { background: var(--ms-sage); color: var(--ms-white); }
.ms-btn--sage:hover { background: var(--ms-sage2); transform: translateY(-2px); box-shadow: 0 8px 24px rgba(61,90,71,.3); }
.ms-btn--terra { background: var(--ms-terra); color: var(--ms-white); }
.ms-btn--terra:hover { background: #B05A3A; transform: translateY(-2px); }
.ms-btn--ghost { background: transparent; border: 2px solid var(--ms-stone); color: var(--ms-stone); }
.ms-btn--ghost:hover { border-color: var(--ms-sage); color: var(--ms-sage); }

/* ════════════════════════════════
   TRUST BAR
   ════════════════════════════════ */
.ms-trust {
  background: var(--ms-dark); padding: 22px 0;
}
.ms-trust__inner {
  display: flex; flex-wrap: wrap; justify-content: center;
  gap: 12px 40px;
  max-width: 1200px; margin: 0 auto; padding: 0 24px;
}
.ms-trust__item {
  display: flex; align-items: center; gap: 10px;
  font-size: .84rem; font-weight: 700;
  color: rgba(255,255,255,.75);
}
.ms-trust__item::before { content: attr(data-icon); font-size: 1rem; }

/* ════════════════════════════════
   TREATMENTS GRID
   ════════════════════════════════ */
.ms-treatments__grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(310px,1fr));
  gap: 24px;
  margin-top: 56px;
}
.ms-treatment {
  background: var(--ms-white);
  border-radius: var(--ms-rad-lg);
  padding: 36px 30px;
  box-shadow: var(--ms-shadow);
  transition: transform .3s var(--ms-ease), box-shadow .3s var(--ms-ease);
  border-left: 4px solid transparent;
  position: relative;
}
.ms-treatment::after {
  content: '';
  position: absolute;
  bottom: 0; left: 0; right: 0; height: 2px;
  background: linear-gradient(90deg, var(--ms-sage), var(--ms-terra));
  transform: scaleX(0); transition: transform .3s var(--ms-ease);
  transform-origin: left;
}
.ms-treatment:hover { transform: translateY(-6px); box-shadow: var(--ms-shadow2); border-left-color: var(--ms-sage); }
.ms-treatment:hover::after { transform: scaleX(1); }
.ms-treatment__icon { font-size: 2.2rem; margin-bottom: 16px; display: block; }
.ms-treatment__hd { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px; gap: 12px; }
.ms-treatment__title { font-family: var(--ms-font-h); font-size: 1.25rem; font-weight: 600; color: var(--ms-dark); }
.ms-treatment__meta { text-align: right; flex-shrink: 0; }
.ms-treatment__price { font-size: .88rem; font-weight: 700; color: var(--ms-sage); display: block; }
.ms-treatment__time  { font-size: .76rem; color: var(--ms-muted); }
.ms-treatment__desc  { font-size: .92rem; line-height: 1.75; color: var(--ms-muted); }

/* ════════════════════════════════
   ADD-ONS
   ════════════════════════════════ */
.ms-addons__grid {
  display: grid; grid-template-columns: repeat(4,1fr); gap: 20px; margin-top: 40px;
}
.ms-addon {
  background: rgba(255,255,255,.07);
  border: 1px solid rgba(255,255,255,.12);
  border-radius: var(--ms-rad);
  padding: 24px 20px;
  text-align: center;
  transition: background .25s;
}
.ms-addon:hover { background: rgba(255,255,255,.12); }
.ms-addon__price { font-family: var(--ms-font-h); font-size: 1.6rem; font-weight: 600; color: var(--ms-terra); display: block; margin-bottom: 8px; }
.ms-addon__name  { font-size: .9rem; font-weight: 700; color: var(--ms-white); margin-bottom: 6px; }
.ms-addon__desc  { font-size: .78rem; color: rgba(255,255,255,.55); line-height: 1.5; }

/* ════════════════════════════════
   COUNTERS
   ════════════════════════════════ */
.ms-counters__grid {
  display: grid; grid-template-columns: repeat(4,1fr); gap: 2px;
}
.ms-counter {
  text-align: center; padding: 60px 20px;
  background: rgba(0,0,0,.04); border: 1px solid rgba(139,115,85,.12);
}
.ms-counter__num {
  font-family: var(--ms-font-h);
  font-size: clamp(2.4rem,5vw,3.8rem); font-weight: 700;
  color: var(--ms-sage); display: block; line-height: 1; margin-bottom: 8px;
}
.ms-counter__label {
  font-size: .8rem; font-weight: 700;
  letter-spacing: .08em; text-transform: uppercase;
  color: var(--ms-muted);
}

/* ════════════════════════════════
   TEAM
   ════════════════════════════════ */
.ms-team__grid {
  display: grid; grid-template-columns: repeat(4,1fr); gap: 24px; margin-top: 52px;
}
.ms-team-card {
  background: var(--ms-white); border-radius: var(--ms-rad-lg);
  padding: 36px 24px; text-align: center;
  box-shadow: var(--ms-shadow);
  transition: transform .3s, box-shadow .3s;
}
.ms-team-card:hover { transform: translateY(-6px); box-shadow: var(--ms-shadow2); }
.ms-team-card__avatar {
  width: 88px; height: 88px; border-radius: 50%;
  margin: 0 auto 20px;
  background: linear-gradient(135deg, var(--ms-sage) 0%, var(--ms-stone) 100%);
  border: 3px solid rgba(61,90,71,.15);
  display: flex; align-items: center; justify-content: center;
  font-size: 2.2rem;
}
.ms-team-card__name  { font-family: var(--ms-font-h); font-size: 1.05rem; font-weight: 600; color: var(--ms-dark); margin-bottom: 4px; }
.ms-team-card__title { font-size: .78rem; font-weight: 700; color: var(--ms-sage); margin-bottom: 10px; }
.ms-team-card__quals { font-size: .76rem; color: var(--ms-muted); margin-bottom: 8px; }
.ms-team-card__spec  {
  display: inline-block; padding: 4px 12px;
  background: rgba(61,90,71,.08); border-radius: 20px;
  font-size: .72rem; font-weight: 700; color: var(--ms-sage);
}

/* ════════════════════════════════
   PACKAGES
   ════════════════════════════════ */
.ms-packages__grid {
  display: grid; grid-template-columns: repeat(3,1fr); gap: 28px; margin-top: 56px;
  align-items: start;
}
.ms-package {
  background: var(--ms-white); border-radius: var(--ms-rad-lg);
  padding: 40px 32px; box-shadow: var(--ms-shadow);
  border: 2px solid transparent;
  transition: all .3s var(--ms-ease);
  position: relative;
}
.ms-package:hover { transform: translateY(-4px); box-shadow: var(--ms-shadow2); }
.ms-package--featured {
  background: linear-gradient(145deg, var(--ms-sage) 0%, var(--ms-sage2) 100%);
  color: var(--ms-white);
  border-color: var(--ms-stone);
  transform: scale(1.04);
}
.ms-package--featured:hover { transform: scale(1.04) translateY(-4px); }
.ms-package__badge {
  position: absolute; top: -14px; left: 50%; transform: translateX(-50%);
  background: var(--ms-terra); color: var(--ms-white);
  font-size: .7rem; font-weight: 700; letter-spacing: .1em; text-transform: uppercase;
  padding: 6px 18px; border-radius: 20px; white-space: nowrap;
}
.ms-package__name { font-family: var(--ms-font-h); font-size: 1.5rem; font-weight: 600; margin-bottom: 8px; }
.ms-package--featured .ms-package__name { color: var(--ms-white); }
.ms-package__price {
  font-family: var(--ms-font-h); font-size: 2.2rem; font-weight: 700;
  color: var(--ms-sage); line-height: 1; margin-bottom: 4px;
}
.ms-package--featured .ms-package__price { color: rgba(255,255,255,.95); }
.ms-package__period { font-size: .8rem; color: var(--ms-muted); margin-bottom: 24px; }
.ms-package--featured .ms-package__period { color: rgba(255,255,255,.6); }
.ms-package__divider { height: 1px; background: rgba(139,115,85,.12); margin-bottom: 22px; }
.ms-package--featured .ms-package__divider { background: rgba(255,255,255,.15); }
.ms-package__features { list-style: none; margin-bottom: 30px; }
.ms-package__features li {
  padding: 8px 0; font-size: .9rem;
  display: flex; align-items: center; gap: 10px; color: var(--ms-muted);
  border-bottom: 1px solid rgba(139,115,85,.06);
}
.ms-package__features li:last-child { border-bottom: none; }
.ms-package--featured .ms-package__features li { color: rgba(255,255,255,.8); border-color: rgba(255,255,255,.08); }
.ms-package__features li::before { content: '✦'; color: var(--ms-sage); font-size: .72rem; flex-shrink: 0; }
.ms-package--featured .ms-package__features li::before { color: var(--ms-terra); }
.ms-package__cta {
  display: block; width: 100%; padding: 14px; border-radius: 8px;
  text-align: center; font-weight: 700; font-size: .9rem;
  cursor: pointer; border: none; transition: all .3s var(--ms-ease);
}
.ms-package__cta--outline { background: transparent; border: 2px solid rgba(61,90,71,.25); color: var(--ms-sage); }
.ms-package__cta--outline:hover { border-color: var(--ms-sage); background: var(--ms-sage); color: var(--ms-white); }
.ms-package__cta--white { background: var(--ms-white); color: var(--ms-sage); }
.ms-package__cta--white:hover { background: var(--ms-ivory); transform: translateY(-1px); }

/* ════════════════════════════════
   TESTIMONIALS
   ════════════════════════════════ */
.ms-testimonials__grid {
  display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; margin-top: 52px;
}
.ms-testimonial {
  background: var(--ms-white); border-radius: var(--ms-rad-lg);
  padding: 36px 28px; box-shadow: var(--ms-shadow);
  position: relative; transition: transform .3s;
}
.ms-testimonial:hover { transform: translateY(-4px); }
.ms-testimonial::before {
  content: '"';
  position: absolute; top: 14px; left: 22px;
  font-family: var(--ms-font-h); font-size: 5rem; line-height: 1;
  color: rgba(61,90,71,.1); font-weight: 700;
}
.ms-testimonial__stars { display: flex; gap: 3px; margin-bottom: 14px; }
.ms-testimonial__stars span { color: var(--ms-terra); font-size: .95rem; }
.ms-testimonial__quote {
  font-family: var(--ms-font-h); font-style: italic;
  font-size: 1rem; line-height: 1.75;
  color: var(--ms-dark); margin-bottom: 22px;
  position: relative; z-index: 1;
}
.ms-testimonial__author { display: flex; align-items: center; gap: 12px; }
.ms-testimonial__avatar {
  width: 44px; height: 44px; border-radius: 50%;
  background: linear-gradient(135deg, var(--ms-sage), var(--ms-stone));
  display: flex; align-items: center; justify-content: center;
  font-family: var(--ms-font-h); font-size: 1.1rem; font-weight: 700;
  color: var(--ms-white); flex-shrink: 0;
}
.ms-testimonial__name   { font-weight: 700; font-size: .88rem; color: var(--ms-dark); }
.ms-testimonial__detail { font-size: .75rem; color: var(--ms-muted); margin-top: 2px; }

/* ════════════════════════════════
   BOOKING FORM
   ════════════════════════════════ */
.ms-booking { background: var(--ms-blush); }
.ms-booking__grid { display: grid; grid-template-columns: 1fr 1.3fr; gap: 64px; align-items: start; }
.ms-booking__info h3 {
  font-family: var(--ms-font-h); font-size: 1.8rem; font-weight: 600;
  color: var(--ms-dark); margin-bottom: 16px;
}
.ms-booking__info p { font-size: .95rem; line-height: 1.8; color: var(--ms-muted); margin-bottom: 24px; }
.ms-booking__promise { list-style: none; }
.ms-booking__promise li {
  padding: 10px 0; font-size: .88rem; color: var(--ms-dark);
  display: flex; align-items: flex-start; gap: 10px;
  border-bottom: 1px solid rgba(139,115,85,.1);
}
.ms-booking__promise li:last-child { border-bottom: none; }
.ms-booking__promise li::before { content: '🌿'; flex-shrink: 0; }
.ms-booking__contact {
  margin-top: 28px; padding: 20px 24px;
  background: var(--ms-white); border-radius: var(--ms-rad);
  box-shadow: var(--ms-shadow);
  font-size: .85rem; color: var(--ms-muted); line-height: 2.2;
}
.ms-form {
  background: var(--ms-white); border-radius: var(--ms-rad-lg);
  padding: 40px; box-shadow: var(--ms-shadow2);
}
.ms-form__row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.ms-form__group { margin-bottom: 18px; }
.ms-form__group label {
  display: block; font-size: .75rem; font-weight: 700;
  letter-spacing: .06em; text-transform: uppercase;
  color: var(--ms-dark); margin-bottom: 7px;
}
.ms-form__group input,
.ms-form__group select,
.ms-form__group textarea {
  width: 100%;
  border: 2px solid rgba(139,115,85,.15); border-radius: 8px;
  padding: 11px 14px;
  font-family: var(--ms-font-b); font-size: .9rem; color: var(--ms-dark);
  background: var(--ms-ivory); outline: none;
  transition: border-color .25s, background .25s;
}
.ms-form__group input:focus,
.ms-form__group select:focus,
.ms-form__group textarea:focus { border-color: var(--ms-sage); background: var(--ms-white); }
.ms-form__group textarea { resize: vertical; min-height: 90px; }
.ms-form__submit {
  width: 100%; padding: 16px;
  background: var(--ms-sage); color: var(--ms-white);
  border: none; border-radius: 8px;
  font-family: var(--ms-font-b); font-size: 1rem; font-weight: 700;
  cursor: pointer; letter-spacing: .02em;
  transition: all .3s var(--ms-ease);
  box-shadow: 0 4px 18px rgba(61,90,71,.3);
}
.ms-form__submit:hover { background: var(--ms-sage2); transform: translateY(-2px); box-shadow: 0 10px 28px rgba(61,90,71,.4); }

/* ════════════════════════════════
   FOOTER
   ════════════════════════════════ */
.ms-footer { background: var(--ms-dark); padding: 28px 0; border-top: 3px solid var(--ms-sage); }
.ms-footer__inner {
  display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap;
  gap: 14px; max-width: 1200px; margin: 0 auto; padding: 0 24px;
}
.ms-footer__logo { font-family: var(--ms-font-h); font-size: 1.2rem; font-weight: 700; color: var(--ms-white); }
.ms-footer__logo span { color: var(--ms-terra); }
.ms-footer__copy { font-size: .78rem; color: rgba(255,255,255,.35); }
.ms-footer__links { display: flex; gap: 20px; }
.ms-footer__links a { font-size: .78rem; color: rgba(255,255,255,.45); transition: color .2s; }
.ms-footer__links a:hover { color: var(--ms-terra); }

/* ════════════════════════════════
   ANIMATION
   ════════════════════════════════ */
.ms-reveal { opacity: 0; transform: translateY(28px); transition: opacity .65s var(--ms-ease), transform .65s var(--ms-ease); }
.ms-reveal.is-visible { opacity: 1; transform: translateY(0); }

/* ════════════════════════════════
   RESPONSIVE
   ════════════════════════════════ */
@media (max-width: 1024px) {
  .ms-team__grid    { grid-template-columns: repeat(2,1fr); }
  .ms-addons__grid  { grid-template-columns: repeat(2,1fr); }
  .ms-booking__grid { grid-template-columns: 1fr; gap: 40px; }
}
@media (max-width: 768px) {
  .ms-sec { padding: 70px 0; }
  .ms-hero__scene { display: none; }
  .ms-hero__content { padding: 0 24px; max-width: 100%; }
  .ms-nav__links { display: none; }
  .ms-counters__grid  { grid-template-columns: repeat(2,1fr); }
  .ms-packages__grid  { grid-template-columns: 1fr; }
  .ms-package--featured { transform: none; }
  .ms-testimonials__grid { grid-template-columns: 1fr; }
  .ms-form__row { grid-template-columns: 1fr; }
}
@media (max-width: 480px) {
  .ms-addons__grid { grid-template-columns: 1fr; }
  .ms-team__grid   { grid-template-columns: 1fr 1fr; }
}
</style>
<?php get_header(); ?>
<div class="ms-page">
>

<!-- NAVBAR -->
<nav class="ms-nav" aria-label="Main navigation">
  <div class="ms-nav__inner">
    <a href="<?php echo esc_url( home_url('/') ); ?>" class="ms-nav__logo">
      Serenity<span>.</span>
    </a>
    <div class="ms-nav__links">
      <a href="#treatments">Treatments</a>
      <a href="#team">Our Therapists</a>
      <a href="#packages">Packages</a>
      <a href="#booking" class="ms-nav__cta">Book Now</a>
    </div>
  </div>
</nav>

<!-- HERO -->
<section class="ms-hero" aria-label="Hero">

  <div class="ms-hero__petals" aria-hidden="true">
    <?php foreach ( $petal_pos as $i => $pos ) :
      $delay = round( $i * 1.1 % 8, 1 );
      $dur   = round( 8 + $i * 0.7 % 6, 1 );
    ?>
    <div class="ms-petal"
         style="top:<?php echo esc_attr($pos[0]); ?>;left:<?php echo esc_attr($pos[1]); ?>;animation-delay:<?php echo esc_attr($delay); ?>s;animation-duration:<?php echo esc_attr($dur); ?>s;"></div>
    <?php endforeach; ?>
  </div>

  <!-- CSS treatment room scene -->
  <div class="ms-hero__scene" aria-hidden="true">
    <div class="ms-scene__wall"></div>
    <div class="ms-scene__dado"></div>
    <div class="ms-scene__panel"></div>
    <div class="ms-scene__window"></div>
    <div class="ms-scene__art">🌿</div>
    <div class="ms-scene__shelf">
      <?php
      $candle_cols = ['#F5E8D8','#E8D8C0','#D8C8A8','#C8B890'];
      for ($c = 0; $c < 4; $c++) :
        $ch  = 20 + rand(0,20);
        $cl  = 10 + $c * 22;
        $row = ($c < 2) ? 12 : 55;
        $cc  = $candle_cols[$c];
      ?>
      <div style="position:absolute;top:<?php echo esc_attr($row); ?>%;left:<?php echo esc_attr($cl); ?>px;width:12px;height:<?php echo esc_attr($ch); ?>px;background:<?php echo esc_attr($cc); ?>;border-radius:3px 3px 0 0;">
        <div style="position:absolute;top:-4px;left:50%;transform:translateX(-50%);width:2px;height:6px;background:#C8603A;border-radius:1px;"></div>
      </div>
      <?php endfor; ?>
    </div>
    <div class="ms-scene__floor"></div>
    <div class="ms-scene__mat"></div>
    <div class="ms-scene__table">
      <div class="ms-scene__pillow"></div>
    </div>
    <div class="ms-scene__client">
      <div class="ms-scene__client-body"></div>
      <div class="ms-scene__sheet"></div>
      <div class="ms-scene__client-head"></div>
    </div>
    <div class="ms-scene__therapist">
      <div class="ms-scene__therapist-body">
        <div class="ms-scene__therapist-head"></div>
        <div class="ms-scene__therapist-arm-l"></div>
        <div class="ms-scene__therapist-arm-r"></div>
      </div>
    </div>
    <div class="ms-scene__diffuser"></div>
  </div>

  <!-- hero text -->
  <div class="ms-hero__content">
    <div class="ms-hero__eyebrow">Award-Winning Massage Therapy · Harley Street, London</div>
    <h1 class="ms-hero__h1">
      Restore Your Body.<br>
      <em>Renew Your Mind.</em>
    </h1>
    <p class="ms-hero__tag">
      London's most trusted massage therapy studio. Expert therapists, bespoke treatments,
      and a sanctuary designed to melt away the weight of modern life.
    </p>
    <div class="ms-hero__actions">
      <a href="#booking" class="ms-btn ms-btn--sage">Book a Treatment</a>
      <a href="#treatments" class="ms-btn ms-btn--ghost">View Treatments</a>
    </div>
  </div>
</section>

<!-- TRUST BAR -->
<div class="ms-trust" aria-label="Trust indicators">
  <div class="ms-trust__inner">
    <span class="ms-trust__item" data-icon="🌿">ITEC &amp; VTCT Certified</span>
    <span class="ms-trust__item" data-icon="🌿">4.9★ on Google (520+ Reviews)</span>
    <span class="ms-trust__item" data-icon="🌿">CNHC Registered</span>
    <span class="ms-trust__item" data-icon="🌿">15,000+ Sessions Delivered</span>
    <span class="ms-trust__item" data-icon="🌿">Insurance Accepted</span>
  </div>
</div>

<!-- TREATMENTS -->
<section id="treatments" class="ms-sec">
  <div class="ms-wrap">
    <div class="ms-center">
      <span class="ms-eyebrow">Our Treatments</span>
      <h2 class="ms-h2">Expert Therapies for Every Body</h2>
      <p class="ms-lead">
        From deeply relaxing Swedish massage to targeted sports recovery, every treatment
        is tailored to your body's unique needs and goals.
      </p>
    </div>
    <div class="ms-treatments__grid">
      <?php foreach ( $treatments as $i => $t ) : ?>
      <div class="ms-treatment ms-reveal" style="transition-delay:<?php echo esc_attr( $i * 80 ); ?>ms;">
        <span class="ms-treatment__icon" aria-hidden="true"><?php echo $t['icon']; ?></span>
        <div class="ms-treatment__hd">
          <h3 class="ms-treatment__title"><?php echo esc_html( $t['title'] ); ?></h3>
          <div class="ms-treatment__meta">
            <span class="ms-treatment__price"><?php echo esc_html( $t['price'] ); ?></span>
            <span class="ms-treatment__time"><?php echo esc_html( $t['times'] ); ?></span>
          </div>
        </div>
        <p class="ms-treatment__desc"><?php echo esc_html( $t['desc'] ); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ADD-ONS -->
<section class="ms-sec ms-sec--sage" id="addons">
  <div class="ms-wrap">
    <div class="ms-center">
      <span class="ms-eyebrow">Enhance Your Session</span>
      <h2 class="ms-h2" style="color:var(--ms-white);">Wellness Add-Ons</h2>
      <p class="ms-lead">Combine any add-on with your treatment for a truly bespoke experience.</p>
    </div>
    <div class="ms-addons__grid">
      <?php foreach ( $addons as $a ) : ?>
      <div class="ms-addon ms-reveal">
        <span class="ms-addon__price"><?php echo esc_html( $a['price'] ); ?></span>
        <div class="ms-addon__name"><?php echo esc_html( $a['name'] ); ?></div>
        <div class="ms-addon__desc"><?php echo esc_html( $a['desc'] ); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- COUNTERS -->
<section class="ms-sec ms-sec--alt" aria-label="Stats" style="padding:0;">
  <div class="ms-counters__grid">
    <div class="ms-counter ms-reveal">
      <span class="ms-counter__num" data-target="16" data-suffix="yrs">0</span>
      <span class="ms-counter__label">Years of Excellence</span>
    </div>
    <div class="ms-counter ms-reveal" style="transition-delay:100ms;">
      <span class="ms-counter__num" data-target="15000" data-suffix="+">0</span>
      <span class="ms-counter__label">Sessions Delivered</span>
    </div>
    <div class="ms-counter ms-reveal" style="transition-delay:200ms;">
      <span class="ms-counter__num" data-target="4.9" data-suffix="★" data-float="1">0</span>
      <span class="ms-counter__label">Average Rating</span>
    </div>
    <div class="ms-counter ms-reveal" style="transition-delay:300ms;">
      <span class="ms-counter__num" data-target="96" data-suffix="%">0</span>
      <span class="ms-counter__label">Return for Another Visit</span>
    </div>
  </div>
</section>

<!-- TEAM -->
<section id="team" class="ms-sec">
  <div class="ms-wrap">
    <div class="ms-center">
      <span class="ms-eyebrow">Your Therapists</span>
      <h2 class="ms-h2">Practitioners You Can Trust</h2>
      <p class="ms-lead">
        Every therapist at Serenity Studio is fully qualified, insured, and registered with
        the CNHC. We only hire therapists who match our commitment to exceptional, compassionate care.
      </p>
    </div>
    <div class="ms-team__grid">
      <?php
      $avatars = ['👩‍⚕️','👨‍⚕️','🧖‍♀️','💆‍♀️'];
      foreach ( $team as $i => $m ) : ?>
      <div class="ms-team-card ms-reveal" style="transition-delay:<?php echo esc_attr( $i * 80 ); ?>ms;">
        <div class="ms-team-card__avatar" aria-hidden="true"><?php echo $avatars[$i]; ?></div>
        <div class="ms-team-card__name"><?php echo esc_html( $m['name'] ); ?></div>
        <div class="ms-team-card__title"><?php echo esc_html( $m['title'] ); ?></div>
        <div class="ms-team-card__quals"><?php echo esc_html( $m['quals'] ); ?></div>
        <span class="ms-team-card__spec"><?php echo esc_html( $m['spec'] ); ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- PACKAGES -->
<section id="packages" class="ms-sec ms-sec--alt">
  <div class="ms-wrap">
    <div class="ms-center">
      <span class="ms-eyebrow">Investment in Yourself</span>
      <h2 class="ms-h2">Treatment Packages</h2>
      <p class="ms-lead">
        Whether you need a single restorative session or a full wellness programme,
        we have the right option to support your wellbeing journey.
      </p>
    </div>
    <div class="ms-packages__grid">
      <?php foreach ( $packages as $pkg ) : ?>
      <div class="ms-package <?php echo $pkg['featured'] ? 'ms-package--featured' : ''; ?> ms-reveal">
        <?php if ( $pkg['featured'] ) : ?>
          <div class="ms-package__badge">Best Value</div>
        <?php endif; ?>
        <div class="ms-package__name"><?php echo esc_html( $pkg['name'] ); ?></div>
        <div class="ms-package__price"><?php echo esc_html( $pkg['price'] ); ?></div>
        <div class="ms-package__period"><?php echo esc_html( $pkg['period'] ); ?></div>
        <div class="ms-package__divider"></div>
        <ul class="ms-package__features">
          <?php foreach ( $pkg['features'] as $feat ) : ?>
          <li><?php echo esc_html( $feat ); ?></li>
          <?php endforeach; ?>
        </ul>
        <?php if ( $pkg['featured'] ) : ?>
          <a href="#booking" class="ms-package__cta ms-package__cta--white">Begin Your Programme</a>
        <?php else : ?>
          <a href="#booking" class="ms-package__cta ms-package__cta--outline">Book Now</a>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section id="testimonials" class="ms-sec">
  <div class="ms-wrap">
    <div class="ms-center">
      <span class="ms-eyebrow">Client Experiences</span>
      <h2 class="ms-h2">What Our Clients Say</h2>
      <p class="ms-lead">We let the results speak for themselves.</p>
    </div>
    <div class="ms-testimonials__grid">
      <?php foreach ( $testimonials as $t ) : ?>
      <div class="ms-testimonial ms-reveal">
        <div class="ms-testimonial__stars">
          <?php for ($s = 0; $s < $t['stars']; $s++) echo '<span>★</span>'; ?>
        </div>
        <blockquote class="ms-testimonial__quote">
          <?php echo esc_html( $t['quote'] ); ?>
        </blockquote>
        <div class="ms-testimonial__author">
          <div class="ms-testimonial__avatar" aria-hidden="true">
            <?php echo esc_html( mb_substr($t['name'],0,1) ); ?>
          </div>
          <div>
            <div class="ms-testimonial__name"><?php echo esc_html( $t['name'] ); ?></div>
            <div class="ms-testimonial__detail"><?php echo esc_html( $t['detail'] ); ?></div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- BOOKING FORM -->
<section id="booking" class="ms-sec ms-booking">
  <div class="ms-wrap">
    <div class="ms-booking__grid">
      <div class="ms-booking__info">
        <span class="ms-eyebrow">Book Your Session</span>
        <h3>Ready to Begin Your Wellness Journey?</h3>
        <p>Complete the form and our team will confirm your appointment within one business day. All treatments include a pre-session consultation at no extra charge.</p>
        <ul class="ms-booking__promise">
          <li>Pre-treatment health consultation</li>
          <li>Bespoke treatment tailored to your needs</li>
          <li>All products vegan and cruelty-free</li>
          <li>Peaceful aftercare relaxation space</li>
          <li>Gift vouchers available for loved ones</li>
        </ul>
        <div class="ms-booking__contact">
          📞 <?php echo esc_html( $phone ); ?><br>
          ✉️ <?php echo esc_html( $email ); ?><br>
          📍 <?php echo esc_html( $addr ); ?><br>
          🕘 Mon–Sat 8am–8pm &nbsp;|&nbsp; Sun 10am–5pm
        </div>
      </div>

      <div class="ms-form">
        <form method="post" action="" novalidate>
          <?php wp_nonce_field( 'tf_ms_booking', 'tf_ms_nonce' ); ?>

          <div class="ms-form__row">
            <div class="ms-form__group">
              <label for="ms_fname">First Name</label>
              <input type="text" id="ms_fname" name="ms_fname" placeholder="Sophie" required>
            </div>
            <div class="ms-form__group">
              <label for="ms_lname">Last Name</label>
              <input type="text" id="ms_lname" name="ms_lname" placeholder="Collins" required>
            </div>
          </div>

          <div class="ms-form__row">
            <div class="ms-form__group">
              <label for="ms_email">Email Address</label>
              <input type="email" id="ms_email" name="ms_email" placeholder="you@email.com" required>
            </div>
            <div class="ms-form__group">
              <label for="ms_phone">Phone Number</label>
              <input type="tel" id="ms_phone" name="ms_phone" placeholder="+44 7700 000000">
            </div>
          </div>

          <div class="ms-form__group">
            <label for="ms_treatment">Treatment</label>
            <select id="ms_treatment" name="ms_treatment">
              <option value="">Choose a treatment…</option>
              <option value="swedish">Swedish Massage</option>
              <option value="hotstone">Hot Stone Therapy</option>
              <option value="deep">Deep Tissue Massage</option>
              <option value="aroma">Aromatherapy Massage</option>
              <option value="prenatal">Prenatal Massage</option>
              <option value="sports">Sports &amp; Recovery</option>
            </select>
          </div>

          <div class="ms-form__row">
            <div class="ms-form__group">
              <label for="ms_duration">Duration</label>
              <select id="ms_duration" name="ms_duration">
                <option value="60">60 minutes</option>
                <option value="75">75 minutes</option>
                <option value="90">90 minutes</option>
              </select>
            </div>
            <div class="ms-form__group">
              <label for="ms_therapist">Preferred Therapist</label>
              <select id="ms_therapist" name="ms_therapist">
                <option value="">No preference</option>
                <option value="elena">Elena Vasquez</option>
                <option value="james">James Thornton</option>
                <option value="aisha">Aisha Patel</option>
                <option value="claire">Claire Donovan</option>
              </select>
            </div>
          </div>

          <div class="ms-form__group">
            <label for="ms_notes">Health notes / areas to focus on</label>
            <textarea id="ms_notes" name="ms_notes" placeholder="e.g. Lower back tension, shoulder knots, post-marathon recovery…"></textarea>
          </div>

          <button type="submit" name="tf_ms_submit" class="ms-form__submit">
            Request My Appointment 🌿
          </button>

          <p style="text-align:center; margin-top:14px; font-size:.75rem; color:var(--ms-muted);">
            We'll confirm within one business day. Your information is kept strictly private.
          </p>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- FOOTER -->
<footer class="ms-footer" role="contentinfo">
  <div class="ms-footer__inner">
    <div class="ms-footer__logo">Serenity<span>.</span></div>
    <p class="ms-footer__copy">
      &copy; <?php echo esc_html( date('Y') ); ?> <?php bloginfo('name'); ?>. Harley Street Massage Therapy. All rights reserved.
    </p>
    <nav class="ms-footer__links" aria-label="Footer navigation">
      <a href="#">Privacy</a>
      <a href="#">Gift Vouchers</a>
      <a href="#booking">Contact</a>
    </nav>
  </div>
</footer>

<script>
(function () {
  'use strict';
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  function animateCounter(el) {
    const target  = parseFloat(el.dataset.target);
    const suffix  = el.dataset.suffix  || '';
    const isFloat = el.dataset.float   === '1';
    if (isNaN(target)) return;
    const dur = 1800; let start = null;
    (function tick(ts) {
      if (!start) start = ts;
      const p = Math.min((ts - start) / dur, 1);
      const v = easeOut(p) * target;
      el.textContent = isFloat ? v.toFixed(1) + suffix : Math.round(v) + suffix;
      if (p < 1) requestAnimationFrame(tick);
    })(performance.now());
  }
  const io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (!e.isIntersecting) return;
      e.target.classList.add('is-visible');
      e.target.querySelectorAll('[data-target]').forEach(animateCounter);
      if (e.target.dataset && e.target.dataset.target) animateCounter(e.target);
      io.unobserve(e.target);
    });
  }, { threshold: 0.15 });
  document.querySelectorAll('.ms-reveal, .ms-counter__num[data-target]')
    .forEach(function (el) { io.observe(el); });
  document.querySelectorAll('a[href^="#"]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      const t = document.querySelector(this.getAttribute('href'));
      if (!t) return;
      e.preventDefault();
      window.scrollTo({ top: t.getBoundingClientRect().top + window.pageYOffset - 80, behavior: 'smooth' });
    });
  });
  const nav = document.querySelector('.ms-nav');
  window.addEventListener('scroll', function () {
    nav.style.boxShadow = window.scrollY > 40 ? '0 4px 24px rgba(139,115,85,.15)' : 'none';
  }, { passive: true });
})();
</script>

</body>
</html>
</div><!-- .ms-page -->
<?php get_footer(); ?>
