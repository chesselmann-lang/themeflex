<?php
/**
 * Template Name: Medical — Private Clinic & Medical Practice
 *
 * Premium private clinic / medical practice page template.
 * Namespace : --med-*
 * Fonts     : Lora + Source Sans 3
 * Palette   : sapphire #1a4a7a · glacier #e8f3fa · teal #1a7a6e · pearl #f8fbfc · slate #4a5a6a
 *
 * @package ThemeFlex
 */

/* ── PHP seed data ─────────────────────────────────── */
srand( 89 );

// DNA helix dots for hero background
$helix_dots = [];
for ( $i = 0; $i < 24; $i++ ) {
    $t = $i / 24;
    // Two interleaved sine waves
    $helix_dots[] = [
        'side'  => 'a',
        'x'     => 72 + sin( $t * M_PI * 4 ) * 8,
        'y'     => $t * 100,
        'op'    => rand( 40, 90 ) / 100,
        'r'     => rand( 3, 6 ),
    ];
    $helix_dots[] = [
        'side'  => 'b',
        'x'     => 72 - sin( $t * M_PI * 4 ) * 8,
        'y'     => $t * 100,
        'op'    => rand( 30, 80 ) / 100,
        'r'     => rand( 2, 5 ),
    ];
}

// Specialties
$specialties = [
    [ 'icon' => '◈', 'name' => 'Internal Medicine',      'desc' => 'Comprehensive diagnostic workup and management of complex multi-system conditions in adults.' ],
    [ 'icon' => '◉', 'name' => 'Cardiology',              'desc' => 'Non-invasive cardiac diagnostics, ECG, echocardiography, Holter monitoring and risk prevention.' ],
    [ 'icon' => '▣', 'name' => 'Sports Medicine',         'desc' => 'Performance optimisation, injury rehabilitation and targeted return-to-sport protocols.' ],
    [ 'icon' => '◆', 'name' => 'Preventive Health',       'desc' => 'Executive health screenings, longevity medicine and tailored prevention programmes.' ],
    [ 'icon' => '◐', 'name' => 'Dermatology',             'desc' => 'Skin cancer screening, mole mapping, medical and aesthetic dermatology.' ],
    [ 'icon' => '◑', 'name' => 'Mental Health',           'desc' => 'Confidential psychiatric assessment, burnout support and evidence-based therapy pathways.' ],
];

// Physicians
$doctors = [
    [ 'name' => 'Prof. Dr. med. Elena Richter', 'spec' => 'Chief Physician — Internal Medicine', 'qual' => 'Charité Berlin · Mayo Clinic', 'col' => '#1a4060', 'acc' => '#4a90c0' ],
    [ 'name' => 'Dr. med. Jonas Kaufmann',      'spec' => 'Cardiologist',                        'qual' => 'TU München · Cleveland Clinic', 'col' => '#102e28', 'acc' => '#2a8a70' ],
    [ 'name' => 'Dr. med. Mia Schäfer',         'spec' => 'Sports & Preventive Medicine',        'qual' => 'Heidelberg · ETH Zürich',       'col' => '#2a1a40', 'acc' => '#7060b0' ],
    [ 'name' => 'Dr. med. Felix Brandt',        'spec' => 'Dermatologist',                       'qual' => 'Hamburg UKE · Johns Hopkins',   'col' => '#3a2a10', 'acc' => '#c09040' ],
];

// Patient journey steps
$journey = [
    [ 'n' => '01', 'title' => 'First Consultation',   'desc' => 'A 60-minute intake with your dedicated physician — full history, examination and goal-setting.' ],
    [ 'n' => '02', 'title' => 'Diagnostics',           'desc' => 'State-of-the-art in-house laboratory, imaging and functional testing — results within 24 hours.' ],
    [ 'n' => '03', 'title' => 'Treatment Plan',        'desc' => 'A personalised, evidence-based plan presented in plain language — no jargon, no uncertainty.' ],
    [ 'n' => '04', 'title' => 'Ongoing Care',          'desc' => 'Regular follow-ups, secure messaging with your care team and 24/7 emergency access.' ],
];

// Services highlights
$highlights = [
    '✓ Same-day appointments available',
    '✓ Multilingual team (DE · EN · FR)',
    '✓ Private & statutory insurance',
    '✓ House call service on request',
    '✓ Secure patient portal',
    '✓ Direct specialist referrals',
];

// Testimonials
$testimonials = [
    [
        'name'   => 'Dr. Christine M.',
        'role'   => 'Executive Health Screen Patient',
        'stars'  => 5,
        'quote'  => 'For the first time in my life, a full health check that felt genuinely thorough. The team found an early cardiovascular marker my previous doctor had missed for years.',
        'avatar' => 'CM',
        'col'    => '#1a7a6e',
    ],
    [
        'name'   => 'Tobias H.',
        'role'   => 'Sports Medicine Patient',
        'stars'  => 5,
        'quote'  => 'I was back running within 8 weeks of a quad tear — a time frame my physiotherapist said was impossible. The structured protocol here made all the difference.',
        'avatar' => 'TH',
        'col'    => '#1a4a7a',
    ],
    [
        'name'   => 'Annette W.',
        'role'   => 'Family Patient',
        'stars'  => 5,
        'quote'  => 'We moved our entire family here from our old practice. The discretion, the speed, and the quality of explanation are completely different. I trust this team completely.',
        'avatar' => 'AW',
        'col'    => '#7060b0',
    ],
];

// Stats
$stats = [
    [ 'val' => 14000, 'suffix' => '+',  'label' => 'Patients Treated' ],
    [ 'val' => 96,    'suffix' => '%',  'label' => 'Patient Satisfaction' ],
    [ 'val' => 22,    'suffix' => '',   'label' => 'Years of Practice' ],
    [ 'val' => 24,    'suffix' => 'h',  'label' => 'Emergency Access' ],
];

// Certifications marquee
$certs = [
    'ISO 9001:2015 Certified',
    'KBV Quality Seal',
    'TÜV Medical Device Safety',
    'DGIM Member',
    'DGK Cardiology Society',
    'European Health Award',
    'Focus Doctors List 2024',
    'Stern Recommended Specialist',
    'AWMF Guideline Adherent',
    'Digital Health Pioneer',
];
$certs_double = array_merge( $certs, $certs );
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,600;0,700;1,400;1,600&family=Source+Sans+3:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════════
   MEDICAL — CSS CUSTOM PROPERTIES
═══════════════════════════════════════════════════════════ */
:root {
    --med-sapphire : #1a4a7a;
    --med-sapphire-d:#0f2f50;
    --med-sapphire-m:#2a6aaa;
    --med-teal     : #1a7a6e;
    --med-teal-l   : #2aaa98;
    --med-glacier  : #e8f3fa;
    --med-pearl    : #f8fbfc;
    --med-white    : #ffffff;
    --med-slate    : #4a5a6a;
    --med-light-sl : #8a9aaa;
    --med-ff-head  : 'Lora', Georgia, serif;
    --med-ff-body  : 'Source Sans 3', system-ui, sans-serif;
    --med-radius   : 6px;
    --med-trans    : .35s cubic-bezier(.4,0,.2,1);
}

/* ── Reset ── */
.med-page *, .med-page *::before, .med-page *::after { box-sizing: border-box; margin: 0; padding: 0; }
.med-page { font-family: var(--med-ff-body); color: var(--med-sapphire-d); background: var(--med-pearl); line-height: 1.6; }
.med-page a { color: inherit; text-decoration: none; }
.med-page ul { list-style: none; }

/* ── Layout ── */
.med-wrap      { max-width: 1240px; margin: 0 auto; padding: 0 28px; }
.med-wrap--wide{ max-width: 1420px; margin: 0 auto; padding: 0 24px; }

/* ── Headings ── */
.med-eyebrow {
    font-family: var(--med-ff-body);
    font-size: .7rem;
    font-weight: 700;
    letter-spacing: .22em;
    text-transform: uppercase;
    color: var(--med-teal);
    display: block;
    margin-bottom: .8rem;
}
.med-h2 {
    font-family: var(--med-ff-head);
    font-size: clamp(2rem, 4vw, 3.1rem);
    font-weight: 700;
    color: var(--med-sapphire-d);
    line-height: 1.18;
}
.med-h2.light { color: var(--med-white); }
.med-h2 em { color: var(--med-teal); font-style: italic; }
.med-lead {
    font-size: 1.05rem;
    color: var(--med-slate);
    line-height: 1.8;
    margin-top: 1rem;
    max-width: 54ch;
}
.med-lead.light { color: rgba(232,243,250,.75); }

/* ── Buttons ── */
.med-btn {
    display: inline-flex;
    align-items: center;
    gap: .5rem;
    padding: .9rem 2rem;
    font-family: var(--med-ff-body);
    font-size: .82rem;
    font-weight: 700;
    letter-spacing: .1em;
    text-transform: uppercase;
    border: none;
    cursor: pointer;
    transition: var(--med-trans);
    border-radius: 50px;
}
.med-btn--teal { background: var(--med-teal); color: var(--med-white); }
.med-btn--teal:hover { background: var(--med-teal-l); transform: translateY(-2px); box-shadow: 0 8px 24px rgba(26,122,110,.35); }
.med-btn--outline {
    background: transparent;
    border: 1.5px solid rgba(26,74,122,.3);
    color: var(--med-sapphire);
    border-radius: 50px;
}
.med-btn--outline:hover { background: var(--med-sapphire); color: var(--med-white); }
.med-btn--outline-light {
    background: transparent;
    border: 1.5px solid rgba(232,243,250,.4);
    color: var(--med-glacier);
    border-radius: 50px;
}
.med-btn--outline-light:hover { border-color: var(--med-teal-l); color: var(--med-teal-l); }

/* ═══════════════════════════════════════════════════════════
   HERO — CLINICAL INTERIOR ART SCENE
═══════════════════════════════════════════════════════════ */
.med-hero {
    position: relative;
    min-height: 100vh;
    background: linear-gradient(135deg, var(--med-sapphire-d) 0%, #0d2840 40%, #0d3030 100%);
    display: flex;
    align-items: center;
    overflow: hidden;
}

/* Background subtle grid */
.med-hero-grid {
    position: absolute;
    inset: 0;
    background-image:
        linear-gradient(rgba(232,243,250,.04) 1px, transparent 1px),
        linear-gradient(90deg, rgba(232,243,250,.04) 1px, transparent 1px);
    background-size: 50px 50px;
    pointer-events: none;
}

/* Ambient glow circles */
.med-glow-1 {
    position: absolute;
    top: -15%;
    right: 15%;
    width: 500px;
    height: 500px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(26,122,110,.2) 0%, transparent 70%);
    pointer-events: none;
}
.med-glow-2 {
    position: absolute;
    bottom: -10%;
    left: 25%;
    width: 400px;
    height: 400px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(42,106,170,.15) 0%, transparent 70%);
    pointer-events: none;
}

/* ── CSS Clinic room art ── */
.med-clinic-art {
    position: absolute;
    right: 4%;
    top: 50%;
    transform: translateY(-50%);
    width: 460px;
    height: 480px;
}
@media (max-width: 1100px) { .med-clinic-art { display: none; } }

/* Room walls */
.med-room-wall {
    position: absolute;
    inset: 0;
    background: linear-gradient(160deg, #1a2a3a 0%, #0f1a28 100%);
    border-radius: 8px;
    overflow: hidden;
}

/* Wall panel lines */
.med-wall-panel-h {
    position: absolute;
    left: 0; right: 0;
    height: 1px;
    background: rgba(232,243,250,.06);
}
.med-wall-panel-h:nth-of-type(1) { top: 20%; }
.med-wall-panel-h:nth-of-type(2) { top: 55%; }

/* Floor */
.med-room-floor {
    position: absolute;
    bottom: 0; left: 0; right: 0;
    height: 28%;
    background: linear-gradient(180deg, #1a2830 0%, #121e28 100%);
    border-top: 1px solid rgba(232,243,250,.08);
}

/* Examination table */
.med-exam-table {
    position: absolute;
    bottom: 28%;
    left: 50%;
    transform: translateX(-50%);
    width: 55%;
}
.med-table-top {
    height: 12px;
    background: linear-gradient(180deg, #e0eeee, #c8dcdc);
    border-radius: 6px 6px 0 0;
    border: 1px solid rgba(255,255,255,.15);
}
.med-table-padding {
    height: 28px;
    background: linear-gradient(180deg, #a0c4c4, #80aaaa);
    border-radius: 0;
    margin: 0 4px;
}
.med-table-base {
    height: 8px;
    background: #607080;
    border-radius: 0 0 4px 4px;
}
.med-table-legs {
    display: flex;
    justify-content: space-between;
    padding: 0 10%;
}
.med-table-leg {
    width: 4px;
    height: 24px;
    background: linear-gradient(180deg, #607080, #405060);
    border-radius: 2px;
}

/* Patient figure on table */
.med-patient {
    position: absolute;
    top: -46px;
    left: 50%;
    transform: translateX(-50%);
    width: 100%;
    display: flex;
    justify-content: center;
}

/* Monitor / vital signs screen */
.med-monitor {
    position: absolute;
    top: 12%;
    right: 8%;
    width: 100px;
    background: #0a1a2a;
    border: 1px solid rgba(42,106,170,.4);
    border-radius: 6px;
    padding: 8px;
    box-shadow: 0 4px 20px rgba(0,0,0,.5);
}
.med-monitor-screen {
    background: #051015;
    border-radius: 3px;
    height: 60px;
    position: relative;
    overflow: hidden;
}
.med-monitor-line {
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    height: 1px;
    background: rgba(42,200,170,.15);
}
/* ECG waveform line */
.med-ecg-path {
    position: absolute;
    top: 50%;
    left: 0;
    width: 200%;
    height: 30px;
    transform: translateY(-50%);
    animation: med-ecg-scroll 3s linear infinite;
}
@keyframes med-ecg-scroll { from{transform:translateY(-50%) translateX(0)} to{transform:translateY(-50%) translateX(-50%)} }
.med-monitor-label {
    font-family: monospace;
    font-size: .5rem;
    color: rgba(42,200,170,.7);
    margin-top: 4px;
    text-align: center;
    line-height: 1.4;
}

/* IV drip stand */
.med-iv-stand {
    position: absolute;
    top: 8%;
    left: 8%;
    width: 30px;
}
.med-iv-pole {
    width: 3px;
    height: 180px;
    background: linear-gradient(180deg, #a0b0c0, #607080);
    margin: 0 auto;
    border-radius: 2px;
}
.med-iv-hook {
    position: relative;
    height: 16px;
}
.med-iv-hook::before, .med-iv-hook::after {
    content: '';
    position: absolute;
    top: 0;
    width: 14px;
    height: 10px;
    border-top: 2px solid #909aaa;
    border-radius: 50% 50% 0 0;
}
.med-iv-hook::before { left: 0; }
.med-iv-hook::after  { right: 0; }
.med-iv-bag {
    width: 28px;
    height: 42px;
    background: linear-gradient(180deg, rgba(42,170,200,.3), rgba(26,100,150,.4));
    border: 1px solid rgba(42,170,200,.5);
    border-radius: 6px 6px 4px 4px;
    margin: 2px auto 0;
}
.med-iv-tube {
    width: 1px;
    height: 60px;
    background: rgba(42,170,200,.5);
    margin: 0 auto;
}
.med-iv-base {
    display: flex;
    justify-content: center;
    gap: 14px;
}
.med-iv-foot { width: 20px; height: 3px; background: #607080; border-radius: 2px; }

/* Clipboard / chart on wall */
.med-clipboard {
    position: absolute;
    top: 20%;
    left: 12%;
    width: 50px;
    background: #f8f4ec;
    border-radius: 3px;
    padding: 6px;
    box-shadow: 2px 4px 12px rgba(0,0,0,.4);
}
.med-clipboard::before {
    content: '';
    display: block;
    width: 18px;
    height: 6px;
    background: #808890;
    border-radius: 2px;
    margin: 0 auto 6px;
}
.med-chart-line {
    height: 2px;
    background: rgba(26,74,122,.3);
    border-radius: 1px;
    margin-bottom: 3px;
}
.med-chart-line:last-child { width: 65%; }

/* Heartbeat cross symbol */
.med-cross {
    position: absolute;
    top: 10%;
    left: 50%;
    transform: translateX(-50%);
    width: 32px;
    height: 32px;
}
.med-cross::before, .med-cross::after {
    content: '';
    position: absolute;
    background: rgba(26,122,110,.4);
    border-radius: 2px;
}
.med-cross::before { left: 50%; top: 0; bottom: 0; width: 6px; transform: translateX(-50%); }
.med-cross::after  { top: 50%; left: 0; right: 0; height: 6px; transform: translateY(-50%); }

/* ── Hero content ── */
.med-hero-content {
    position: relative;
    z-index: 2;
    padding: 120px 0 80px;
    max-width: 600px;
}
.med-hero-trust {
    display: flex;
    align-items: center;
    gap: .6rem;
    padding: .45rem 1rem;
    background: rgba(26,122,110,.15);
    border: 1px solid rgba(26,122,110,.3);
    border-radius: 50px;
    display: inline-flex;
    margin-bottom: 2rem;
    font-size: .72rem;
    font-weight: 700;
    letter-spacing: .14em;
    text-transform: uppercase;
    color: var(--med-teal-l);
}
.med-hero-trust::before { content: '◆'; font-size: .5rem; }
.med-hero-h1 {
    font-family: var(--med-ff-head);
    font-size: clamp(2.8rem, 6vw, 5rem);
    font-weight: 700;
    color: var(--med-white);
    line-height: 1.1;
    margin-bottom: 1.6rem;
}
.med-hero-h1 em { color: var(--med-teal-l); font-style: italic; }
.med-hero-sub {
    font-size: 1.08rem;
    color: rgba(232,243,250,.75);
    line-height: 1.8;
    margin-bottom: 2.4rem;
    font-weight: 400;
    max-width: 46ch;
}
.med-hero-ctas { display: flex; gap: 1rem; flex-wrap: wrap; }

/* Quick info bar */
.med-hero-info {
    display: flex;
    gap: 2rem;
    margin-top: 2.5rem;
    flex-wrap: wrap;
}
.med-hero-info-item {
    display: flex;
    align-items: center;
    gap: .5rem;
    font-size: .82rem;
    color: rgba(232,243,250,.55);
}
.med-hero-info-item strong { color: var(--med-glacier); font-weight: 600; }

/* Scroll line */
.med-scroll {
    position: absolute;
    bottom: 28px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 2;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: .4rem;
}
.med-scroll-line {
    width: 1px;
    height: 44px;
    background: linear-gradient(180deg, rgba(26,122,110,.7), transparent);
    animation: med-scroll-grow 2.2s ease-in-out infinite;
}
@keyframes med-scroll-grow { 0%,100%{transform:scaleY(0);transform-origin:top;opacity:0} 50%{transform:scaleY(1);transform-origin:top;opacity:1} 51%{transform:scaleY(1);transform-origin:bottom} }
.med-scroll span { font-size: .65rem; letter-spacing: .18em; text-transform: uppercase; color: rgba(232,243,250,.35); }

/* ═══════════════════════════════════════════════════════════
   CERTIFICATIONS MARQUEE
═══════════════════════════════════════════════════════════ */
.med-marquee-bar {
    background: var(--med-sapphire);
    padding: .9rem 0;
    overflow: hidden;
}
.med-marquee-track {
    display: flex;
    width: max-content;
    animation: med-scroll-left 44s linear infinite;
}
.med-marquee-track:hover { animation-play-state: paused; }
@keyframes med-scroll-left { from{transform:translateX(0)} to{transform:translateX(-50%)} }
.med-marquee-item {
    padding: 0 2.5rem;
    font-size: .72rem;
    font-weight: 700;
    letter-spacing: .15em;
    text-transform: uppercase;
    color: rgba(232,243,250,.55);
    white-space: nowrap;
    display: flex;
    align-items: center;
    gap: 2.5rem;
}
.med-marquee-item::after { content: '◆'; font-size: .45rem; color: var(--med-teal-l); }

/* ═══════════════════════════════════════════════════════════
   SPECIALTIES
═══════════════════════════════════════════════════════════ */
.med-specialties { padding: 110px 0; background: var(--med-pearl); }
.med-spec-header { text-align: center; margin-bottom: 4rem; }
.med-spec-header .med-lead { margin: 1rem auto 0; }
.med-spec-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1.5rem;
}
@media (max-width: 900px) { .med-spec-grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 560px) { .med-spec-grid { grid-template-columns: 1fr; } }

.med-spec-card {
    background: var(--med-white);
    border: 1px solid rgba(26,74,122,.07);
    border-radius: var(--med-radius);
    padding: 2.5rem;
    transition: var(--med-trans);
    position: relative;
    overflow: hidden;
}
.med-spec-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 3px;
    background: var(--med-teal);
    transform: scaleX(0);
    transform-origin: left;
    transition: transform .4s ease;
}
.med-spec-card:hover::before { transform: scaleX(1); }
.med-spec-card:hover { transform: translateY(-4px); box-shadow: 0 16px 40px rgba(26,74,122,.1); border-color: rgba(26,122,110,.15); }
.med-spec-icon {
    width: 52px;
    height: 52px;
    border-radius: 50%;
    background: var(--med-glacier);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.2rem;
    color: var(--med-sapphire);
    margin-bottom: 1.2rem;
}
.med-spec-name {
    font-family: var(--med-ff-head);
    font-size: 1.1rem;
    font-weight: 700;
    color: var(--med-sapphire-d);
    margin-bottom: .7rem;
}
.med-spec-desc { font-size: .92rem; color: var(--med-slate); line-height: 1.7; }

/* ═══════════════════════════════════════════════════════════
   ABOUT / CLINIC PHILOSOPHY
═══════════════════════════════════════════════════════════ */
.med-about { padding: 110px 0; background: var(--med-glacier); }
.med-about-inner {
    display: grid;
    grid-template-columns: 1.1fr 1fr;
    gap: 5rem;
    align-items: center;
}
@media (max-width: 860px) { .med-about-inner { grid-template-columns: 1fr; gap: 3rem; } }

/* CSS DNA helix illustration */
.med-dna-art {
    position: relative;
    width: 100%;
    max-width: 400px;
    margin: 0 auto;
    aspect-ratio: .7;
    background: var(--med-sapphire-d);
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 20px 60px rgba(26,74,122,.25);
}
.med-dna-bg {
    position: absolute;
    inset: 0;
    background-image:
        linear-gradient(rgba(232,243,250,.04) 1px, transparent 1px),
        linear-gradient(90deg, rgba(232,243,250,.04) 1px, transparent 1px);
    background-size: 30px 30px;
}
/* DNA helix SVG drawn in PHP */
.med-dna-svg { position: absolute; inset: 0; width: 100%; height: 100%; }

.med-dna-label {
    position: absolute;
    bottom: 16px;
    left: 0; right: 0;
    text-align: center;
    font-family: monospace;
    font-size: .6rem;
    letter-spacing: .12em;
    text-transform: uppercase;
    color: rgba(42,170,200,.5);
}

/* Highlights list */
.med-about-highlights {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: .6rem;
    margin-top: 2rem;
}
.med-highlight {
    display: flex;
    align-items: center;
    gap: .5rem;
    font-size: .92rem;
    color: var(--med-sapphire);
    font-weight: 500;
}

/* ═══════════════════════════════════════════════════════════
   PATIENT JOURNEY
═══════════════════════════════════════════════════════════ */
.med-journey { padding: 110px 0; background: var(--med-sapphire); }
.med-journey-header { text-align: center; margin-bottom: 4rem; }
.med-journey-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 0;
    position: relative;
}
@media (max-width: 900px) { .med-journey-grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 480px) { .med-journey-grid { grid-template-columns: 1fr; } }

/* Connector line between steps */
.med-journey-grid::before {
    content: '';
    position: absolute;
    top: 44px;
    left: 12.5%;
    right: 12.5%;
    height: 1px;
    background: rgba(232,243,250,.15);
    pointer-events: none;
}
@media (max-width: 900px) { .med-journey-grid::before { display: none; } }

.med-journey-step {
    padding: 2.5rem 2rem;
    text-align: center;
    position: relative;
}
.med-journey-num {
    width: 52px;
    height: 52px;
    border-radius: 50%;
    background: rgba(42,170,200,.15);
    border: 2px solid rgba(42,170,200,.35);
    color: var(--med-teal-l);
    font-family: var(--med-ff-head);
    font-size: 1rem;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 1.4rem;
}
.med-journey-title {
    font-family: var(--med-ff-head);
    font-size: 1.1rem;
    font-weight: 700;
    color: var(--med-white);
    margin-bottom: .7rem;
}
.med-journey-desc { font-size: .9rem; color: rgba(232,243,250,.6); line-height: 1.7; }

/* ═══════════════════════════════════════════════════════════
   STATS
═══════════════════════════════════════════════════════════ */
.med-stats {
    padding: 70px 0;
    background: var(--med-teal);
}
.med-stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 2rem;
    text-align: center;
}
@media (max-width: 700px) { .med-stats-grid { grid-template-columns: repeat(2, 1fr); } }

.med-stat-val {
    font-family: var(--med-ff-head);
    font-size: clamp(2.5rem, 5vw, 3.8rem);
    font-weight: 700;
    color: var(--med-white);
    line-height: 1;
    display: block;
}
.med-stat-label {
    font-size: .75rem;
    letter-spacing: .16em;
    text-transform: uppercase;
    color: rgba(255,255,255,.55);
    margin-top: .6rem;
    display: block;
}

/* ═══════════════════════════════════════════════════════════
   TEAM — PHYSICIANS
═══════════════════════════════════════════════════════════ */
.med-team { padding: 110px 0; background: var(--med-pearl); }
.med-team-header { text-align: center; margin-bottom: 4rem; }
.med-team-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1.5rem;
}
@media (max-width: 900px) { .med-team-grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 480px) { .med-team-grid { grid-template-columns: 1fr; } }

.med-doctor-card {
    background: var(--med-white);
    border-radius: var(--med-radius);
    overflow: hidden;
    border: 1px solid rgba(26,74,122,.07);
    transition: var(--med-trans);
}
.med-doctor-card:hover { transform: translateY(-5px); box-shadow: 0 16px 40px rgba(26,74,122,.12); }

.med-doctor-portrait {
    aspect-ratio: 1;
    position: relative;
    overflow: hidden;
}

.med-doctor-body {
    padding: 1.4rem;
    border-top: 3px solid var(--med-teal);
}
.med-doctor-name {
    font-family: var(--med-ff-head);
    font-size: .95rem;
    font-weight: 700;
    color: var(--med-sapphire-d);
    margin-bottom: .25rem;
    line-height: 1.3;
}
.med-doctor-spec {
    font-size: .78rem;
    color: var(--med-teal);
    font-weight: 600;
    letter-spacing: .06em;
    margin-bottom: .4rem;
}
.med-doctor-qual {
    font-size: .78rem;
    color: var(--med-light-sl);
    line-height: 1.5;
}

/* ═══════════════════════════════════════════════════════════
   TESTIMONIALS
═══════════════════════════════════════════════════════════ */
.med-testimonials { padding: 110px 0; background: var(--med-glacier); }
.med-test-header { text-align: center; margin-bottom: 4rem; }
.med-test-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1.5rem;
}
@media (max-width: 900px) { .med-test-grid { grid-template-columns: 1fr; max-width: 580px; margin: 0 auto; } }

.med-test-card {
    background: var(--med-white);
    border-radius: var(--med-radius);
    padding: 2.5rem;
    border: 1px solid rgba(26,74,122,.06);
    transition: var(--med-trans);
    position: relative;
}
.med-test-card:hover { transform: translateY(-4px); box-shadow: 0 16px 40px rgba(26,74,122,.1); }
.med-test-card::before {
    content: '"';
    font-family: var(--med-ff-head);
    font-size: 5rem;
    color: rgba(26,74,122,.06);
    position: absolute;
    top: .5rem;
    left: 1.5rem;
    line-height: 1;
}
.med-test-stars { color: #f0a830; margin-bottom: 1rem; letter-spacing: .1em; font-size: .9rem; }
.med-test-quote {
    font-family: var(--med-ff-head);
    font-style: italic;
    font-size: 1rem;
    color: var(--med-sapphire-d);
    line-height: 1.75;
    margin-bottom: 1.8rem;
}
.med-test-author { display: flex; align-items: center; gap: .8rem; }
.med-test-avatar {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: .78rem;
    font-weight: 700;
    color: var(--med-white);
    flex-shrink: 0;
}
.med-test-name { font-size: .9rem; font-weight: 700; color: var(--med-sapphire-d); }
.med-test-role { font-size: .78rem; color: var(--med-light-sl); margin-top: .15rem; }

/* ═══════════════════════════════════════════════════════════
   APPOINTMENT / BOOKING FORM
═══════════════════════════════════════════════════════════ */
.med-booking { padding: 110px 0; background: var(--med-sapphire-d); }
.med-booking-inner {
    display: grid;
    grid-template-columns: 1fr 1.3fr;
    gap: 5rem;
    align-items: start;
}
@media (max-width: 860px) { .med-booking-inner { grid-template-columns: 1fr; gap: 3rem; } }

.med-booking-info { }
.med-booking-info-items { margin-top: 2.5rem; }
.med-info-item {
    display: flex;
    gap: 1rem;
    align-items: flex-start;
    padding: 1.2rem 0;
    border-bottom: 1px solid rgba(232,243,250,.06);
}
.med-info-item:first-child { border-top: 1px solid rgba(232,243,250,.06); }
.med-info-icon {
    width: 38px;
    height: 38px;
    border-radius: 50%;
    background: rgba(26,122,110,.15);
    border: 1px solid rgba(26,122,110,.3);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: .9rem;
    color: var(--med-teal-l);
    flex-shrink: 0;
}
.med-info-text strong { display: block; font-size: .88rem; font-weight: 700; color: var(--med-white); margin-bottom: .2rem; }
.med-info-text span { font-size: .85rem; color: rgba(232,243,250,.5); }

/* Form */
.med-form-card {
    background: rgba(255,255,255,.04);
    border: 1px solid rgba(232,243,250,.08);
    border-radius: 8px;
    padding: 3rem;
    backdrop-filter: blur(8px);
}
.med-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
@media (max-width: 560px) { .med-form-row { grid-template-columns: 1fr; } }
.med-field {
    display: flex;
    flex-direction: column;
    gap: .4rem;
    margin-bottom: 1.2rem;
}
.med-field label {
    font-size: .72rem;
    font-weight: 700;
    letter-spacing: .12em;
    text-transform: uppercase;
    color: rgba(232,243,250,.4);
}
.med-field input,
.med-field select,
.med-field textarea {
    background: rgba(255,255,255,.05);
    border: 1px solid rgba(232,243,250,.1);
    border-radius: 4px;
    padding: .85rem 1rem;
    color: var(--med-glacier);
    font-family: var(--med-ff-body);
    font-size: .95rem;
    transition: border-color .25s;
    width: 100%;
}
.med-field input:focus,
.med-field select:focus,
.med-field textarea:focus {
    outline: none;
    border-color: var(--med-teal-l);
    background: rgba(26,122,110,.06);
}
.med-field input::placeholder { color: rgba(232,243,250,.2); }
.med-field select option { background: var(--med-sapphire-d); color: var(--med-glacier); }
.med-field textarea { resize: vertical; min-height: 100px; }
.med-form-submit { width: 100%; justify-content: center; margin-top: .5rem; }
.med-form-note {
    font-size: .77rem;
    color: rgba(232,243,250,.3);
    text-align: center;
    margin-top: 1rem;
    line-height: 1.5;
}

/* ═══════════════════════════════════════════════════════════
   SCROLL REVEAL
═══════════════════════════════════════════════════════════ */
.med-reveal {
    opacity: 0;
    transform: translateY(24px);
    transition: opacity .65s ease, transform .65s ease;
}
.med-reveal.visible { opacity: 1; transform: none; }

@media (max-width: 640px) {
    .med-hero-ctas { flex-direction: column; }
    .med-hero-info { flex-direction: column; gap: .8rem; }
}
</style>
<?php get_header(); ?>
<div class="med-page">
>
<div class="med-page">

<!-- ═══════════════════════════════════════════════════
     HERO
═══════════════════════════════════════════════════ -->
<section class="med-hero" aria-label="Hero">
    <div class="med-hero-grid" aria-hidden="true"></div>
    <div class="med-glow-1" aria-hidden="true"></div>
    <div class="med-glow-2" aria-hidden="true"></div>

    <!-- CSS clinic room art -->
    <div class="med-clinic-art" aria-hidden="true">
        <div class="med-room-wall">
            <div class="med-wall-panel-h"></div>
            <div class="med-wall-panel-h"></div>
            <!-- Cross symbol -->
            <div class="med-cross"></div>
        </div>

        <!-- IV stand -->
        <div class="med-iv-stand">
            <div class="med-iv-hook"></div>
            <div class="med-iv-bag"></div>
            <div class="med-iv-pole"></div>
            <div class="med-iv-tube"></div>
            <div class="med-iv-base">
                <div class="med-iv-foot"></div>
                <div class="med-iv-foot"></div>
                <div class="med-iv-foot"></div>
            </div>
        </div>

        <!-- Vitals monitor -->
        <div class="med-monitor">
            <div class="med-monitor-screen">
                <div class="med-monitor-line"></div>
                <svg class="med-ecg-path" viewBox="0 0 200 30" xmlns="http://www.w3.org/2000/svg">
                    <path d="M0,15 L20,15 L28,15 L32,5 L36,25 L40,10 L44,15 L60,15 L80,15 L88,15 L92,5 L96,25 L100,10 L104,15 L120,15 L140,15 L148,15 L152,5 L156,25 L160,10 L164,15 L180,15 L200,15"
                          fill="none" stroke="rgba(42,200,170,.7)" stroke-width="1.5"/>
                </svg>
            </div>
            <div class="med-monitor-label">HR 68 bpm<br>SpO2 99%<br>BP 118/74</div>
        </div>

        <!-- Clipboard -->
        <div class="med-clipboard">
            <div class="med-chart-line"></div>
            <div class="med-chart-line"></div>
            <div class="med-chart-line"></div>
            <div class="med-chart-line"></div>
        </div>

        <!-- Exam table -->
        <div class="med-exam-table">
            <!-- Patient CSS figure (lying) -->
            <div class="med-patient">
                <svg viewBox="0 0 200 40" xmlns="http://www.w3.org/2000/svg" width="160">
                    <!-- Head -->
                    <ellipse cx="22" cy="20" rx="14" ry="16" fill="#3a5a7a" opacity="0.8"/>
                    <!-- Body -->
                    <rect x="34" y="10" width="80" height="22" rx="10" fill="#2a4a6a" opacity="0.7"/>
                    <!-- Blanket -->
                    <rect x="50" y="14" width="120" height="16" rx="6" fill="rgba(232,243,250,.15)" stroke="rgba(232,243,250,.2)" stroke-width="0.5"/>
                    <!-- Legs -->
                    <rect x="110" y="12" width="60" height="20" rx="8" fill="#2a4a6a" opacity="0.5"/>
                </svg>
            </div>
            <div class="med-table-top"></div>
            <div class="med-table-padding"></div>
            <div class="med-table-base"></div>
            <div class="med-table-legs">
                <div class="med-table-leg"></div>
                <div class="med-table-leg"></div>
            </div>
        </div>

        <!-- Floor -->
        <div class="med-room-floor"></div>
    </div>

    <div class="med-wrap">
        <div class="med-hero-content">
            <div class="med-hero-trust">Private Medical Excellence · Hamburg</div>
            <h1 class="med-hero-h1">
                Your health,<br>
                <em>expertly</em> cared for
            </h1>
            <p class="med-hero-sub">A multidisciplinary private clinic where diagnostic precision meets genuine compassion. Same-week appointments, no waiting lists.</p>
            <div class="med-hero-ctas">
                <a href="#booking" class="med-btn med-btn--teal">Book Appointment</a>
                <a href="#specialties" class="med-btn med-btn--outline-light">Our Specialties</a>
            </div>
            <div class="med-hero-info">
                <div class="med-hero-info-item">◆ <strong>Open Mon–Fri</strong> 08:00–20:00</div>
                <div class="med-hero-info-item">◈ <strong>Same-day</strong> appointments</div>
                <div class="med-hero-info-item">◉ <strong>24/7</strong> emergency line</div>
            </div>
        </div>
    </div>

    <div class="med-scroll" aria-hidden="true">
        <div class="med-scroll-line"></div>
        <span>scroll</span>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════
     CERTIFICATIONS MARQUEE
═══════════════════════════════════════════════════ -->
<div class="med-marquee-bar" aria-label="Certifications and recognition">
    <div class="med-marquee-track" role="marquee">
        <?php foreach ( $certs_double as $c ) : ?>
            <span class="med-marquee-item"><?php echo esc_html($c); ?></span>
        <?php endforeach; ?>
    </div>
</div>

<!-- ═══════════════════════════════════════════════════
     SPECIALTIES
═══════════════════════════════════════════════════ -->
<section id="specialties" class="med-specialties" aria-labelledby="med-spec-title">
<div class="med-wrap">

    <div class="med-spec-header med-reveal">
        <span class="med-eyebrow">Our areas</span>
        <h2 class="med-h2" id="med-spec-title">Medical <em>specialties</em></h2>
        <p class="med-lead">Six specialist disciplines under one roof — fully integrated and communicating for your complete care.</p>
    </div>

    <div class="med-spec-grid">
        <?php foreach ( $specialties as $i => $spec ) : ?>
        <div class="med-spec-card med-reveal" style="transition-delay:<?php echo $i*.09;?>s">
            <div class="med-spec-icon" aria-hidden="true"><?php echo $spec['icon']; ?></div>
            <h3 class="med-spec-name"><?php echo esc_html($spec['name']); ?></h3>
            <p class="med-spec-desc"><?php echo esc_html($spec['desc']); ?></p>
        </div>
        <?php endforeach; ?>
    </div>

</div>
</section>

<!-- ═══════════════════════════════════════════════════
     ABOUT / PHILOSOPHY
═══════════════════════════════════════════════════ -->
<section class="med-about" aria-labelledby="med-about-title">
<div class="med-wrap">
<div class="med-about-inner">

    <!-- Text -->
    <div class="med-reveal">
        <span class="med-eyebrow">Our philosophy</span>
        <h2 class="med-h2" id="med-about-title">Medicine as a <em>partnership</em></h2>
        <p class="med-lead" style="margin-top:1rem">Founded in 2002, the Richter Clinic operates from a simple conviction: every patient deserves time, clarity and continuity of care. We limit our patient list so that each person receives unhurried attention from a physician who knows their complete history.</p>
        <p class="med-lead" style="margin-top:.8rem">Our diagnostic philosophy is to find answers, not just manage symptoms. We combine the latest evidence-based protocols with the kind of thoughtful clinical reasoning that only comes from genuine expertise.</p>
        <div class="med-about-highlights">
            <?php foreach ( $highlights as $h ) : ?>
            <div class="med-highlight"><?php echo esc_html($h); ?></div>
            <?php endforeach; ?>
        </div>
        <div style="margin-top:2.5rem">
            <a href="#booking" class="med-btn med-btn--teal">Make an Appointment</a>
        </div>
    </div>

    <!-- DNA helix art -->
    <div class="med-dna-art med-reveal">
        <div class="med-dna-bg"></div>
        <svg class="med-dna-svg" viewBox="0 0 300 430" xmlns="http://www.w3.org/2000/svg">
            <!-- DNA double helix -->
            <?php
            $helix_n = 40;
            for ( $hi = 0; $hi < $helix_n; $hi++ ) :
                $t   = $hi / ($helix_n - 1);
                $y   = 30 + $t * 370;
                $x1  = 150 + sin( $t * M_PI * 5 ) * 60;
                $x2  = 150 - sin( $t * M_PI * 5 ) * 60;
                $r   = 4 + abs( sin( $t * M_PI * 5 ) ) * 2;
                $col1 = ( $hi % 3 === 0 ) ? 'rgba(42,170,200,.8)' : ( $hi % 3 === 1 ? 'rgba(26,122,110,.8)' : 'rgba(100,160,220,.8)' );
                $col2 = ( $hi % 3 === 0 ) ? 'rgba(26,122,110,.8)' : ( $hi % 3 === 1 ? 'rgba(42,170,200,.8)' : 'rgba(180,120,220,.8)' );
            ?>
            <!-- Rung connecting the two strands -->
            <?php if ( abs( sin( $t * M_PI * 5 ) ) < 0.4 && $hi % 3 === 0 ) : ?>
            <line x1="<?php echo $x1;?>" y1="<?php echo $y;?>" x2="<?php echo $x2;?>" y2="<?php echo $y;?>" stroke="rgba(232,243,250,.18)" stroke-width="1.5"/>
            <rect x="<?php echo min($x1,$x2) + abs($x1-$x2)*.25;?>" y="<?php echo $y-3;?>" width="<?php echo abs($x1-$x2)*.5;?>" height="6" rx="3" fill="rgba(232,243,250,.12)"/>
            <?php endif; ?>
            <!-- Strand A dot -->
            <circle cx="<?php echo $x1;?>" cy="<?php echo $y;?>" r="<?php echo $r;?>" fill="<?php echo $col1;?>"/>
            <!-- Strand B dot -->
            <circle cx="<?php echo $x2;?>" cy="<?php echo $y;?>" r="<?php echo $r;?>" fill="<?php echo $col2;?>"/>
            <?php endfor; ?>

            <!-- Base labels -->
            <text x="150" y="420" text-anchor="middle" font-family="monospace" font-size="8" fill="rgba(42,170,200,.4)" letter-spacing="2">A T G C A T G C</text>
        </svg>
        <div class="med-dna-label">Personalised Medicine · Genomic Profiling</div>
    </div>

</div>
</div>
</section>

<!-- ═══════════════════════════════════════════════════
     PATIENT JOURNEY
═══════════════════════════════════════════════════ -->
<section class="med-journey" aria-labelledby="med-journey-title">
<div class="med-wrap">

    <div class="med-journey-header med-reveal">
        <span class="med-eyebrow" style="color:var(--med-teal-l)">Your care pathway</span>
        <h2 class="med-h2 light" id="med-journey-title">How we <em>care</em> for you</h2>
    </div>

    <div class="med-journey-grid">
        <?php foreach ( $journey as $i => $step ) : ?>
        <div class="med-journey-step med-reveal" style="transition-delay:<?php echo $i*.1;?>s">
            <div class="med-journey-num"><?php echo esc_html($step['n']); ?></div>
            <h3 class="med-journey-title"><?php echo esc_html($step['title']); ?></h3>
            <p class="med-journey-desc"><?php echo esc_html($step['desc']); ?></p>
        </div>
        <?php endforeach; ?>
    </div>

</div>
</section>

<!-- ═══════════════════════════════════════════════════
     STATS
═══════════════════════════════════════════════════ -->
<section class="med-stats" aria-label="Clinic statistics">
<div class="med-wrap">
    <div class="med-stats-grid">
        <?php foreach ( $stats as $i => $st ) : ?>
        <div class="med-reveal" style="transition-delay:<?php echo $i*.1;?>s;text-align:center">
            <span class="med-stat-val" data-target="<?php echo esc_attr($st['val']); ?>" data-suffix="<?php echo esc_attr($st['suffix']); ?>">0</span>
            <span class="med-stat-label"><?php echo esc_html($st['label']); ?></span>
        </div>
        <?php endforeach; ?>
    </div>
</div>
</section>

<!-- ═══════════════════════════════════════════════════
     TEAM
═══════════════════════════════════════════════════ -->
<section class="med-team" aria-labelledby="med-team-title">
<div class="med-wrap">

    <div class="med-team-header med-reveal">
        <span class="med-eyebrow">The physicians</span>
        <h2 class="med-h2" id="med-team-title">Meet our <em>doctors</em></h2>
    </div>

    <div class="med-team-grid">
        <?php foreach ( $doctors as $di => $doc ) : ?>
        <div class="med-doctor-card med-reveal" style="transition-delay:<?php echo $di*.1;?>s">
            <!-- CSS portrait -->
            <div class="med-doctor-portrait" style="background:<?php echo esc_attr($doc['col']);?>">
                <svg viewBox="0 0 240 240" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%">
                    <!-- Background pattern -->
                    <defs>
                        <pattern id="med-dgrid-<?php echo $di;?>" width="10" height="10" patternUnits="userSpaceOnUse">
                            <path d="M10 0L0 0 0 10" fill="none" stroke="<?php echo $doc['acc'];?>" stroke-width="0.15" opacity="0.3"/>
                        </pattern>
                    </defs>
                    <rect width="240" height="240" fill="url(#med-dgrid-<?php echo $di;?>)"/>

                    <!-- White coat background -->
                    <path d="M20 240 L60 180 L120 170 L180 180 L220 240" fill="rgba(248,251,252,0.15)"/>

                    <!-- Doctor figure — head -->
                    <ellipse cx="120" cy="80" rx="36" ry="42" fill="<?php echo $doc['acc'];?>" opacity="0.85"/>
                    <!-- Hair -->
                    <ellipse cx="120" cy="44" rx="37" ry="20" fill="<?php echo $doc['acc'];?>" opacity="0.55"/>
                    <!-- Neck -->
                    <rect x="112" y="118" width="16" height="22" fill="<?php echo $doc['acc'];?>" opacity="0.8"/>

                    <!-- White coat torso -->
                    <path d="M55 142 L120 132 L185 142 L195 240 L45 240 Z" fill="rgba(248,251,252,0.85)"/>
                    <!-- Lapels -->
                    <path d="M120 132 L100 180 L120 172" fill="rgba(232,243,250,0.9)"/>
                    <path d="M120 132 L140 180 L120 172" fill="rgba(232,243,250,0.9)"/>
                    <!-- Shirt & tie -->
                    <rect x="113" y="132" width="14" height="48" fill="rgba(26,74,122,0.6)"/>
                    <path d="M117 145 L120 160 L123 145 L121 140 Z" fill="rgba(26,122,110,0.8)"/>

                    <!-- Stethoscope around neck -->
                    <path d="M95 148 Q 80 165 85 185 Q 88 195 100 195" fill="none" stroke="rgba(100,120,140,0.8)" stroke-width="3" stroke-linecap="round"/>
                    <path d="M145 148 Q 160 165 155 185 Q 152 195 140 195" fill="none" stroke="rgba(100,120,140,0.8)" stroke-width="3" stroke-linecap="round"/>
                    <circle cx="120" cy="195" r="8" fill="rgba(80,100,120,0.7)" stroke="rgba(120,140,160,0.5)" stroke-width="1.5"/>

                    <!-- Face -->
                    <ellipse cx="110" cy="82" rx="4.5" ry="4" fill="rgba(17,17,17,0.55)"/>
                    <ellipse cx="130" cy="82" rx="4.5" ry="4" fill="rgba(17,17,17,0.55)"/>
                    <path d="M 108 100 Q 120 109 132 100" fill="none" stroke="rgba(17,17,17,0.4)" stroke-width="2"/>

                    <!-- Glasses for alternate -->
                    <?php if ( $di % 2 === 1 ) : ?>
                    <rect x="102" y="78" width="16" height="12" rx="4" fill="none" stroke="rgba(17,17,17,.5)" stroke-width="1.5"/>
                    <rect x="122" y="78" width="16" height="12" rx="4" fill="none" stroke="rgba(17,17,17,.5)" stroke-width="1.5"/>
                    <line x1="118" y1="84" x2="122" y2="84" stroke="rgba(17,17,17,.5)" stroke-width="1.5"/>
                    <?php endif; ?>

                    <!-- Pocket pen -->
                    <rect x="162" y="152" width="4" height="22" rx="2" fill="rgba(26,122,110,0.7)"/>
                    <rect x="160" y="150" width="8" height="4" rx="1" fill="rgba(26,74,122,0.5)"/>
                </svg>
            </div>
            <div class="med-doctor-body">
                <div class="med-doctor-name"><?php echo esc_html($doc['name']); ?></div>
                <div class="med-doctor-spec"><?php echo esc_html($doc['spec']); ?></div>
                <div class="med-doctor-qual"><?php echo esc_html($doc['qual']); ?></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

</div>
</section>

<!-- ═══════════════════════════════════════════════════
     TESTIMONIALS
═══════════════════════════════════════════════════ -->
<section class="med-testimonials" aria-labelledby="med-test-title">
<div class="med-wrap">

    <div class="med-test-header med-reveal">
        <span class="med-eyebrow">Patient voices</span>
        <h2 class="med-h2" id="med-test-title">What patients <em>say</em></h2>
    </div>

    <div class="med-test-grid">
        <?php foreach ( $testimonials as $i => $t ) : ?>
        <blockquote class="med-test-card med-reveal" style="transition-delay:<?php echo $i*.12;?>s">
            <div class="med-test-stars" aria-label="<?php echo $t['stars']; ?> stars"><?php echo str_repeat('★', $t['stars']); ?></div>
            <p class="med-test-quote">"<?php echo esc_html($t['quote']); ?>"</p>
            <footer class="med-test-author">
                <div class="med-test-avatar" style="background:<?php echo esc_attr($t['col']); ?>"><?php echo esc_html($t['avatar']); ?></div>
                <div>
                    <div class="med-test-name"><?php echo esc_html($t['name']); ?></div>
                    <div class="med-test-role"><?php echo esc_html($t['role']); ?></div>
                </div>
            </footer>
        </blockquote>
        <?php endforeach; ?>
    </div>

</div>
</section>

<!-- ═══════════════════════════════════════════════════
     APPOINTMENT FORM
═══════════════════════════════════════════════════ -->
<section id="booking" class="med-booking" aria-labelledby="med-booking-title">
<div class="med-wrap">
<div class="med-booking-inner">

    <!-- Info panel -->
    <div class="med-reveal">
        <span class="med-eyebrow" style="color:var(--med-teal-l)">Schedule a visit</span>
        <h2 class="med-h2 light" id="med-booking-title">Book your <em>appointment</em></h2>
        <p class="med-lead light">Same-week availability in most cases. First appointments include a 60-minute comprehensive intake with your assigned physician.</p>
        <div class="med-booking-info-items">
            <div class="med-info-item">
                <div class="med-info-icon" aria-hidden="true">◆</div>
                <div class="med-info-text">
                    <strong>Location</strong>
                    <span>Eppendorf 18, 20249 Hamburg — ground floor, accessible</span>
                </div>
            </div>
            <div class="med-info-item">
                <div class="med-info-icon" aria-hidden="true">◈</div>
                <div class="med-info-text">
                    <strong>Hours</strong>
                    <span>Mon–Fri 08:00–20:00 · Sat 09:00–14:00</span>
                </div>
            </div>
            <div class="med-info-item">
                <div class="med-info-icon" aria-hidden="true">◉</div>
                <div class="med-info-text">
                    <strong>Emergency</strong>
                    <span>24/7 dedicated patient emergency line</span>
                </div>
            </div>
            <div class="med-info-item">
                <div class="med-info-icon" aria-hidden="true">▣</div>
                <div class="med-info-text">
                    <strong>Insurance</strong>
                    <span>Private, Beihilfe &amp; statutory (Kassenarzt on request)</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Appointment form -->
    <div class="med-form-card med-reveal">
        <form method="post" action="" novalidate>
            <?php wp_nonce_field( 'tf_med_appointment', 'tf_med_nonce' ); ?>

            <div class="med-form-row">
                <div class="med-field">
                    <label for="med-name">Full Name *</label>
                    <input type="text" id="med-name" name="med_name" required placeholder="Dr. Christine Müller" autocomplete="name">
                </div>
                <div class="med-field">
                    <label for="med-dob">Date of Birth</label>
                    <input type="date" id="med-dob" name="med_dob" autocomplete="bday">
                </div>
            </div>

            <div class="med-form-row">
                <div class="med-field">
                    <label for="med-email">Email *</label>
                    <input type="email" id="med-email" name="med_email" required placeholder="christine@example.de" autocomplete="email">
                </div>
                <div class="med-field">
                    <label for="med-phone">Phone *</label>
                    <input type="tel" id="med-phone" name="med_phone" required placeholder="+49 40 123 456" autocomplete="tel">
                </div>
            </div>

            <div class="med-form-row">
                <div class="med-field">
                    <label for="med-specialty">Specialty / Reason *</label>
                    <select id="med-specialty" name="med_specialty" required>
                        <option value="">Please select…</option>
                        <option value="internal">Internal Medicine</option>
                        <option value="cardio">Cardiology</option>
                        <option value="sports">Sports Medicine</option>
                        <option value="preventive">Preventive Health Screen</option>
                        <option value="derm">Dermatology</option>
                        <option value="mental">Mental Health</option>
                        <option value="unsure">Not sure — first consultation</option>
                    </select>
                </div>
                <div class="med-field">
                    <label for="med-urgency">Urgency</label>
                    <select id="med-urgency" name="med_urgency">
                        <option value="routine">Routine — next available</option>
                        <option value="soon">This week if possible</option>
                        <option value="urgent">Urgent — within 24h</option>
                    </select>
                </div>
            </div>

            <div class="med-form-row">
                <div class="med-field">
                    <label for="med-date">Preferred Date</label>
                    <input type="date" id="med-date" name="med_date">
                </div>
                <div class="med-field">
                    <label for="med-insurance">Insurance Type</label>
                    <select id="med-insurance" name="med_insurance">
                        <option value="">Please select…</option>
                        <option value="private">Private (PKV)</option>
                        <option value="beihilfe">Beihilfe</option>
                        <option value="statutory">Statutory (GKV)</option>
                        <option value="selfpay">Self-pay</option>
                    </select>
                </div>
            </div>

            <div class="med-field">
                <label for="med-notes">Symptoms / Background (optional)</label>
                <textarea id="med-notes" name="med_notes" rows="3" placeholder="Brief description of your concern or any relevant medical history…"></textarea>
            </div>

            <div class="med-field" style="flex-direction:row;align-items:flex-start;gap:.6rem">
                <input type="checkbox" id="med-consent" name="med_consent" required style="width:auto;margin-top:3px;accent-color:#1a7a6e">
                <label for="med-consent" style="text-transform:none;letter-spacing:0;font-size:.85rem;color:rgba(232,243,250,.5)">I consent to my data being processed to schedule this appointment, in accordance with GDPR and medical data protection regulations.</label>
            </div>

            <button type="submit" class="med-btn med-btn--teal med-form-submit">Request Appointment ◆</button>
            <p class="med-form-note">Our team will confirm within 4 business hours. For emergencies: +49 40 8800 9911</p>
        </form>
    </div>

</div>
</div>
</section>

</div><!-- /.med-page -->

<script>
(function(){
'use strict';

/* ── Scroll reveal ─── */
const reveals = document.querySelectorAll('.med-reveal');
const revealObs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
        if (!e.isIntersecting) return;
        const delay = (parseFloat(e.target.style.transitionDelay) || 0) * 1000;
        setTimeout(() => e.target.classList.add('visible'), delay);
        revealObs.unobserve(e.target);
    });
}, { threshold: 0.08 });
reveals.forEach(el => revealObs.observe(el));

/* ── Animated counters ─── */
const counters = document.querySelectorAll('.med-stat-val[data-target]');
const easeOut  = t => 1 - Math.pow(1 - t, 3);
const cObs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
        if (!e.isIntersecting) return;
        cObs.unobserve(e.target);
        const el     = e.target;
        const target = parseInt(el.dataset.target, 10);
        const suffix = el.dataset.suffix || '';
        const dur    = 1800;
        let start    = null;
        const tick = (ts) => {
            if (!start) start = ts;
            const prog = Math.min((ts - start) / dur, 1);
            el.textContent = Math.round(easeOut(prog) * target) + suffix;
            if (prog < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
    });
}, { threshold: 0.4 });
counters.forEach(el => cObs.observe(el));

})();
</script>
</div><!-- .med-page -->
<?php get_footer(); ?>
</div>
</html>
