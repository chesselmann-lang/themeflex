<?php
/**
 * Template Name: Mobile App Landing Page
 * Template Post Type: page
 *
 * Premium mobile app landing page — dark-first, zero Elementor dependency.
 * Features: CSS phone mockup hero, bento feature grid, how-it-works,
 * alternating feature detail panels, 3-tier pricing with annual toggle,
 * testimonials, final CTA with avatar stack.
 *
 * @package ThemeFlex
 * @since   2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
get_header(); ?>

<main id="tf-app-main" class="tf-app-page" aria-label="<?php esc_attr_e( 'Mobile App Landing Page', 'themeflex' ); ?>">
<style>
/* ══════════════════════════════════════════════════════════════════════════
   ThemeFlex — Mobile App Landing Page
   Dark-first premium template. Scoped under .tf-app-page.
   ══════════════════════════════════════════════════════════════════════════ */

.tf-app-page {
  --tf-bg:       #06021d;
  --tf-bg-2:     #0d1526;
  --tf-bg-3:     #111827;
  --tf-accent:   #ff5e2e;
  --tf-accent2:  #00d4ff;
  --tf-accent3:  #a855f7;
  --tf-accent4:  #10b981;
  --tf-border:   rgba(255,255,255,.07);
  --tf-heading:  #f8fafc;
  --tf-muted:    #94a3b8;
  --tf-meta:     #64748b;
  --tf-r:        16px;
  --tf-r-sm:     10px;
  font-family: 'Inter Tight', system-ui, -apple-system, sans-serif;
  background: var(--tf-bg);
  color: var(--tf-muted);
  overflow-x: hidden;
  line-height: 1.6;
}
.tf-app-page *, .tf-app-page *::before, .tf-app-page *::after {
  box-sizing: border-box; margin: 0; padding: 0;
}
.tf-app-page a { text-decoration: none; color: inherit; }

/* ── Layout helpers ────────────────────────────────────────────────────── */
.tf-app-wrap   { max-width: 1180px; margin: 0 auto; padding: 0 24px; }
.tf-app-section { padding: 100px 0; }

.tf-app-label {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.22);
  color: var(--tf-accent); font-size: .68rem; font-weight: 800;
  letter-spacing: .16em; text-transform: uppercase;
  padding: 6px 18px; border-radius: 100px; margin-bottom: 18px;
}
.tf-app-label svg { width: 13px; height: 13px; }

.tf-app-head { text-align: center; margin-bottom: 60px; }
.tf-app-head h2 {
  font-size: clamp(1.9rem, 3.8vw, 3rem); font-weight: 900;
  color: var(--tf-heading); line-height: 1.1; letter-spacing: -.4px;
  margin: 0 0 16px;
}
.tf-app-head p {
  font-size: 1.08rem; color: var(--tf-muted); max-width: 560px;
  margin: 0 auto; line-height: 1.75;
}
.tf-app-gradient {
  background: linear-gradient(135deg, #ff5e2e 0%, #ff8c5a 40%, #a855f7 100%);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  background-clip: text;
}

/* ══════════════════════════════════════════════════════════════════════════
   §1 — HERO
   ══════════════════════════════════════════════════════════════════════════ */
.tf-app-hero {
  position: relative; overflow: hidden;
  min-height: 100vh; display: flex; align-items: center;
  background: radial-gradient(ellipse 80% 60% at 50% -10%, rgba(255,94,46,.16) 0%, transparent 70%), var(--tf-bg);
  padding: 120px 24px 80px;
}
.tf-app-hero::before {
  content: ''; position: absolute; inset: 0; pointer-events: none;
  background-image:
    linear-gradient(rgba(255,255,255,.035) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255,255,255,.035) 1px, transparent 1px);
  background-size: 56px 56px;
  mask-image: radial-gradient(ellipse 90% 80% at 50% 50%, #000 30%, transparent 100%);
}
.tf-app-hero-inner {
  position: relative; z-index: 2;
  display: grid; grid-template-columns: 1fr 1fr;
  gap: 64px; align-items: center;
  max-width: 1180px; margin: 0 auto; width: 100%;
}
.tf-app-hero-content { display: flex; flex-direction: column; }

/* Hero badge */
.tf-app-hero-badge {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.25);
  color: var(--tf-accent); font-size: .72rem; font-weight: 700;
  letter-spacing: .1em; text-transform: uppercase;
  padding: 7px 18px; border-radius: 100px; margin-bottom: 28px;
  align-self: flex-start;
}
.tf-app-hero-badge-dot {
  width: 6px; height: 6px; border-radius: 50%;
  background: var(--tf-accent);
  box-shadow: 0 0 8px var(--tf-accent);
  animation: tf-app-pulse 2s ease-in-out infinite;
}
@keyframes tf-app-pulse {
  0%, 100% { opacity: 1; transform: scale(1); }
  50%       { opacity: .55; transform: scale(.75); }
}

/* Hero heading */
.tf-app-hero-h1 {
  font-size: clamp(2.4rem, 5vw, 4.2rem); font-weight: 900;
  color: var(--tf-heading); line-height: 1.06; letter-spacing: -.7px;
  margin-bottom: 24px;
}
.tf-app-hero-sub {
  font-size: 1.12rem; color: var(--tf-muted);
  line-height: 1.8; margin-bottom: 36px; max-width: 480px;
}

/* CTA buttons */
.tf-app-hero-ctas {
  display: flex; gap: 14px; flex-wrap: wrap; margin-bottom: 32px;
}
.tf-app-btn-primary {
  display: inline-flex; align-items: center; gap: 10px;
  padding: 16px 32px; background: var(--tf-accent); color: #fff;
  border-radius: 14px; font-size: .95rem; font-weight: 700;
  letter-spacing: .02em;
  box-shadow: 0 10px 32px rgba(255,94,46,.4);
  transition: transform .2s, box-shadow .2s;
}
.tf-app-btn-primary:hover { transform: translateY(-2px); box-shadow: 0 16px 40px rgba(255,94,46,.5); }
.tf-app-btn-primary svg  { width: 18px; height: 18px; flex-shrink: 0; }
.tf-app-btn-ghost {
  display: inline-flex; align-items: center; gap: 10px;
  padding: 15px 28px; background: rgba(255,255,255,.06);
  color: var(--tf-heading); border-radius: 14px;
  font-size: .95rem; font-weight: 600;
  border: 1px solid rgba(255,255,255,.12);
  transition: background .2s, border-color .2s;
}
.tf-app-btn-ghost:hover { background: rgba(255,255,255,.1); border-color: rgba(255,255,255,.2); }
.tf-app-btn-ghost svg { width: 18px; height: 18px; flex-shrink: 0; }

/* App store badges */
.tf-app-store-row {
  display: flex; gap: 12px; flex-wrap: wrap;
}
.tf-app-store-pill {
  display: inline-flex; align-items: center; gap: 9px;
  padding: 11px 22px;
  background: var(--tf-bg-2); color: var(--tf-heading);
  border: 1px solid var(--tf-border); border-radius: 100px;
  font-size: .82rem; font-weight: 600;
  transition: background .2s, border-color .2s;
  cursor: pointer;
}
.tf-app-store-pill:hover { background: rgba(255,255,255,.08); border-color: rgba(255,255,255,.18); }
.tf-app-store-pill svg { width: 16px; height: 16px; flex-shrink: 0; }

/* ── CSS Phone Mockup ───────────────────────────────────────────────────── */
.tf-app-phone-wrap {
  position: relative; display: flex; justify-content: center; align-items: center;
}
.tf-app-phone {
  width: 260px; border-radius: 36px;
  border: 2px solid rgba(255,255,255,.12);
  background: #0a0a1a;
  overflow: hidden;
  box-shadow:
    0 40px 100px rgba(0,0,0,.8),
    0 0 0 1px rgba(255,255,255,.05),
    inset 0 1px 0 rgba(255,255,255,.08);
  position: relative; z-index: 2;
}
/* Status bar */
.tf-app-phone-status {
  display: flex; align-items: center; justify-content: space-between;
  padding: 12px 18px 6px;
  background: #0a0a1a;
}
.tf-app-phone-time {
  font-size: .65rem; font-weight: 700; color: var(--tf-heading);
}
.tf-app-phone-icons {
  display: flex; gap: 4px; align-items: center;
}
.tf-app-phone-signal {
  display: flex; gap: 2px; align-items: flex-end; height: 10px;
}
.tf-app-phone-signal span {
  width: 3px; background: var(--tf-heading); border-radius: 1px;
}
.tf-app-phone-signal span:nth-child(1) { height: 4px; }
.tf-app-phone-signal span:nth-child(2) { height: 6px; }
.tf-app-phone-signal span:nth-child(3) { height: 8px; }
.tf-app-phone-signal span:nth-child(4) { height: 10px; }
.tf-app-phone-batt {
  width: 18px; height: 10px; border: 1.5px solid var(--tf-heading);
  border-radius: 2px; position: relative;
}
.tf-app-phone-batt::after {
  content: ''; position: absolute; right: -5px; top: 50%;
  transform: translateY(-50%);
  width: 3px; height: 6px; background: var(--tf-heading);
  border-radius: 0 1px 1px 0;
}
.tf-app-phone-batt-fill {
  position: absolute; left: 1px; top: 1px; bottom: 1px;
  width: 75%; background: var(--tf-accent4); border-radius: 1px;
}
/* App header bar */
.tf-app-phone-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 10px 16px 8px;
  background: rgba(255,255,255,.04);
  border-bottom: 1px solid rgba(255,255,255,.06);
}
.tf-app-phone-app-title {
  font-size: .72rem; font-weight: 700; color: var(--tf-heading);
}
.tf-app-phone-header svg { width: 16px; height: 16px; color: var(--tf-muted); }
/* Metric cards grid */
.tf-app-phone-screen { padding: 12px; background: #0a0a1a; }
.tf-app-phone-metrics {
  display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 12px;
}
.tf-app-phone-metric {
  background: var(--tf-bg-2); border-radius: 10px;
  padding: 10px; border: 1px solid rgba(255,255,255,.06);
}
.tf-app-phone-metric-icon {
  width: 20px; height: 20px; border-radius: 6px;
  display: flex; align-items: center; justify-content: center;
  margin-bottom: 6px;
}
.tf-app-phone-metric-icon svg { width: 12px; height: 12px; }
.tf-app-phone-metric-num {
  font-size: .8rem; font-weight: 800; color: var(--tf-heading);
  line-height: 1;
}
.tf-app-phone-metric-label {
  font-size: .56rem; color: var(--tf-meta); margin-top: 2px;
  text-transform: uppercase; letter-spacing: .06em;
}
.tf-app-phone-metric-trend {
  font-size: .6rem; color: var(--tf-accent4); margin-top: 3px;
}
/* Chart bars */
.tf-app-phone-chart {
  padding: 10px; background: var(--tf-bg-2); border-radius: 10px;
  border: 1px solid rgba(255,255,255,.06);
}
.tf-app-phone-chart-label {
  font-size: .56rem; color: var(--tf-meta); margin-bottom: 8px;
  text-transform: uppercase; letter-spacing: .06em;
}
.tf-app-phone-bars {
  display: flex; align-items: flex-end; gap: 5px; height: 40px;
}
.tf-app-phone-bar {
  flex: 1; border-radius: 3px 3px 0 0;
  background: linear-gradient(180deg, var(--tf-accent), rgba(255,94,46,.4));
  transition: opacity .2s;
}

/* Floating pills around phone */
.tf-app-float-pill {
  position: absolute; z-index: 3;
  display: inline-flex; align-items: center; gap: 7px;
  background: var(--tf-bg-3); border: 1px solid var(--tf-border);
  border-radius: 100px; padding: 8px 14px;
  font-size: .72rem; font-weight: 600; color: var(--tf-heading);
  box-shadow: 0 8px 24px rgba(0,0,0,.5);
  white-space: nowrap;
}
.tf-app-float-pill-dot {
  width: 7px; height: 7px; border-radius: 50%;
}
.tf-app-float-pill:nth-child(1) { top: 8%;  left:  -5%;  }
.tf-app-float-pill:nth-child(2) { top: 45%; right: -12%; }
.tf-app-float-pill:nth-child(3) { bottom: 10%; left:  0%; }

/* ══════════════════════════════════════════════════════════════════════════
   §2 — SOCIAL PROOF BAR
   ══════════════════════════════════════════════════════════════════════════ */
.tf-app-proof {
  background: var(--tf-bg-2);
  border-top: 1px solid var(--tf-border);
  border-bottom: 1px solid var(--tf-border);
  padding: 40px 0;
}
.tf-app-proof-inner {
  max-width: 1180px; margin: 0 auto; padding: 0 24px;
}
.tf-app-proof-trusted {
  text-align: center;
  font-size: .72rem; font-weight: 700; letter-spacing: .14em;
  text-transform: uppercase; color: var(--tf-meta); margin-bottom: 24px;
}
.tf-app-proof-logos {
  display: flex; flex-wrap: wrap; gap: 10px;
  justify-content: center; margin-bottom: 36px;
}
.tf-app-proof-chip {
  padding: 6px 18px;
  background: rgba(255,255,255,.04);
  border: 1px solid var(--tf-border);
  border-radius: 100px;
  font-size: .78rem; font-weight: 600; color: var(--tf-muted);
}
.tf-app-proof-stats {
  display: flex; justify-content: center; gap: 60px; flex-wrap: wrap;
}
.tf-app-proof-stat { text-align: center; }
.tf-app-proof-stat-num {
  font-size: 2rem; font-weight: 900; color: var(--tf-heading);
  letter-spacing: -.04em; line-height: 1;
}
.tf-app-proof-stat-num span { color: var(--tf-accent); }
.tf-app-proof-stat-label {
  font-size: .78rem; color: var(--tf-meta); margin-top: 4px;
}

/* ══════════════════════════════════════════════════════════════════════════
   §3 — BENTO FEATURE GRID
   ══════════════════════════════════════════════════════════════════════════ */
.tf-app-bento-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
}
.tf-app-bento-card {
  background: var(--tf-bg-2);
  border: 1px solid var(--tf-border);
  border-radius: 20px; padding: 28px;
  position: relative; overflow: hidden;
  transition: border-color .25s, transform .25s;
}
.tf-app-bento-card:hover {
  border-color: rgba(255,94,46,.3);
  transform: translateY(-2px);
}
.tf-app-bento-card.large  { grid-column: span 2; }
.tf-app-bento-card-icon {
  width: 44px; height: 44px; border-radius: 12px;
  display: flex; align-items: center; justify-content: center;
  margin-bottom: 16px; flex-shrink: 0;
}
.tf-app-bento-card-icon svg { width: 22px; height: 22px; }
.tf-app-bento-card h3 {
  font-size: 1.1rem; font-weight: 800; color: var(--tf-heading);
  margin-bottom: 8px;
}
.tf-app-bento-card p {
  font-size: .9rem; color: var(--tf-muted); line-height: 1.7;
}

/* Terminal / online users widget inside large bento card */
.tf-app-bento-terminal {
  background: #0a0f1c; border-radius: 12px;
  border: 1px solid rgba(255,255,255,.08);
  padding: 14px 16px; margin-top: 20px;
  font-family: 'JetBrains Mono', 'Fira Code', monospace;
  font-size: .72rem;
}
.tf-app-bento-terminal-bar {
  display: flex; gap: 6px; margin-bottom: 12px;
}
.tf-app-bento-terminal-bar span {
  width: 10px; height: 10px; border-radius: 50%;
}
.tf-app-bento-terminal-bar span:nth-child(1) { background: #ff5f57; }
.tf-app-bento-terminal-bar span:nth-child(2) { background: #ffbd2e; }
.tf-app-bento-terminal-bar span:nth-child(3) { background: #28c840; }
.tf-app-bento-user-row {
  display: flex; align-items: center; gap: 10px;
  padding: 7px 0; border-bottom: 1px solid rgba(255,255,255,.05);
  color: var(--tf-muted);
}
.tf-app-bento-user-row:last-child { border-bottom: none; }
.tf-app-bento-cursor {
  width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0;
}
.tf-app-bento-user-name { color: var(--tf-heading); font-weight: 600; }
.tf-app-bento-user-action { color: var(--tf-meta); font-size: .68rem; }
.tf-app-bento-user-file { color: var(--tf-accent2); }
.tf-app-bento-online-badge {
  display: inline-flex; align-items: center; gap: 6px;
  background: rgba(16,185,129,.1); border: 1px solid rgba(16,185,129,.2);
  color: #10b981; font-size: .64rem; font-weight: 700;
  padding: 3px 10px; border-radius: 100px; margin-top: 10px;
}
.tf-app-bento-online-dot {
  width: 6px; height: 6px; border-radius: 50%; background: #10b981;
  animation: tf-app-pulse 2s infinite;
}

/* Notification list widget */
.tf-app-notif-list { margin-top: 18px; display: flex; flex-direction: column; gap: 8px; }
.tf-app-notif-row {
  display: flex; align-items: center; gap: 10px;
  background: rgba(255,255,255,.04); border-radius: 10px;
  padding: 9px 12px;
  border: 1px solid rgba(255,255,255,.05);
  font-size: .78rem; color: var(--tf-muted);
}
.tf-app-notif-dot {
  width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0;
}
.tf-app-notif-text { flex: 1; }
.tf-app-notif-time { font-size: .65rem; color: var(--tf-meta); white-space: nowrap; }

/* Bento mini chart */
.tf-app-bento-chart { margin-top: 18px; }
.tf-app-bento-bars {
  display: flex; align-items: flex-end; gap: 5px; height: 60px;
  padding: 0 0 8px;
}
.tf-app-bento-bar {
  flex: 1; border-radius: 4px 4px 0 0;
  background: linear-gradient(180deg, var(--tf-accent), rgba(255,94,46,.25));
  min-height: 8px;
}

/* Small bento status chip */
.tf-app-bento-status {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(16,185,129,.1); border: 1px solid rgba(16,185,129,.22);
  color: #10b981; font-size: .78rem; font-weight: 700;
  padding: 8px 16px; border-radius: 100px; margin-top: 16px;
}
.tf-app-bento-status-dot {
  width: 7px; height: 7px; border-radius: 50%;
  background: #10b981;
  animation: tf-app-pulse 2s infinite;
}
.tf-app-bento-chip {
  display: inline-flex; align-items: center; gap: 6px;
  background: rgba(168,85,247,.12); border: 1px solid rgba(168,85,247,.25);
  color: #c084fc; font-size: .75rem; font-weight: 700;
  padding: 5px 12px; border-radius: 8px; margin-top: 14px;
  font-family: 'JetBrains Mono', monospace;
}

/* ══════════════════════════════════════════════════════════════════════════
   §4 — HOW IT WORKS
   ══════════════════════════════════════════════════════════════════════════ */
.tf-app-hiw { background: var(--tf-bg-2); }
.tf-app-hiw-flow {
  display: grid; grid-template-columns: repeat(3, 1fr);
  gap: 0; position: relative;
}
/* Dashed connecting line */
.tf-app-hiw-flow::before {
  content: ''; position: absolute;
  top: 52px; left: calc(16.5% + 24px); right: calc(16.5% + 24px);
  height: 2px;
  background: repeating-linear-gradient(
    90deg, var(--tf-accent) 0, var(--tf-accent) 8px,
    transparent 8px, transparent 18px
  );
  opacity: .35; z-index: 0;
}
.tf-app-hiw-step {
  display: flex; flex-direction: column; align-items: center;
  text-align: center; padding: 0 24px; position: relative; z-index: 1;
}
.tf-app-hiw-num {
  width: 28px; height: 28px; border-radius: 50%;
  background: var(--tf-accent); color: #fff;
  font-size: .72rem; font-weight: 900;
  display: flex; align-items: center; justify-content: center;
  position: absolute; top: -4px; right: calc(50% - 14px);
  z-index: 2;
}
.tf-app-hiw-ring {
  width: 80px; height: 80px; border-radius: 50%;
  border: 2px solid var(--tf-border);
  background: var(--tf-bg-3);
  display: flex; align-items: center; justify-content: center;
  margin-bottom: 24px; position: relative;
  transition: border-color .25s;
}
.tf-app-hiw-step:hover .tf-app-hiw-ring { border-color: rgba(255,94,46,.5); }
.tf-app-hiw-ring svg { width: 28px; height: 28px; color: var(--tf-accent); }
.tf-app-hiw-title {
  font-size: 1.05rem; font-weight: 800; color: var(--tf-heading); margin-bottom: 10px;
}
.tf-app-hiw-desc { font-size: .88rem; color: var(--tf-muted); line-height: 1.7; }

/* ══════════════════════════════════════════════════════════════════════════
   §5 — FEATURE DETAIL PANELS
   ══════════════════════════════════════════════════════════════════════════ */
.tf-app-panels { background: var(--tf-bg); }
.tf-app-panel {
  display: grid; grid-template-columns: 1fr 1fr;
  gap: 72px; align-items: center; padding: 80px 0;
  border-bottom: 1px solid var(--tf-border);
}
.tf-app-panel:last-child { border-bottom: none; }
.tf-app-panel.reverse .tf-app-panel-visual { order: 2; }
.tf-app-panel.reverse .tf-app-panel-text  { order: 1; }

.tf-app-panel-label {
  display: inline-flex; align-items: center; gap: 7px;
  color: var(--tf-accent); font-size: .7rem; font-weight: 800;
  letter-spacing: .14em; text-transform: uppercase; margin-bottom: 16px;
}
.tf-app-panel-label svg { width: 14px; height: 14px; }
.tf-app-panel-text h2 {
  font-size: clamp(1.7rem, 3vw, 2.5rem); font-weight: 900;
  color: var(--tf-heading); line-height: 1.12; letter-spacing: -.4px;
  margin-bottom: 20px;
}
.tf-app-panel-text p {
  font-size: 1rem; color: var(--tf-muted); line-height: 1.8; margin-bottom: 28px;
}
.tf-app-panel-bullets { list-style: none; display: flex; flex-direction: column; gap: 12px; }
.tf-app-panel-bullet {
  display: flex; align-items: flex-start; gap: 12px;
  font-size: .9rem; color: var(--tf-muted); line-height: 1.6;
}
.tf-app-panel-bullet svg { width: 18px; height: 18px; color: var(--tf-accent4); flex-shrink: 0; margin-top: 2px; }

/* CSS Dashboard mockup */
.tf-app-dash-mock {
  background: var(--tf-bg-2);
  border: 1px solid var(--tf-border);
  border-radius: 16px; overflow: hidden;
  box-shadow: 0 24px 64px rgba(0,0,0,.5);
}
.tf-app-dash-titlebar {
  display: flex; align-items: center; gap: 10px; padding: 12px 16px;
  background: rgba(255,255,255,.03); border-bottom: 1px solid var(--tf-border);
}
.tf-app-dash-dots { display: flex; gap: 6px; }
.tf-app-dash-dots span { width: 10px; height: 10px; border-radius: 50%; }
.tf-app-dash-dots span:nth-child(1) { background: #ff5f57; }
.tf-app-dash-dots span:nth-child(2) { background: #ffbd2e; }
.tf-app-dash-dots span:nth-child(3) { background: #28c840; }
.tf-app-dash-body { display: grid; grid-template-columns: 140px 1fr; min-height: 260px; }
.tf-app-dash-sidebar {
  padding: 14px 10px; background: rgba(255,255,255,.02);
  border-right: 1px solid var(--tf-border);
}
.tf-app-dash-nav-item {
  display: flex; align-items: center; gap: 8px;
  padding: 7px 10px; border-radius: 8px;
  font-size: .68rem; color: var(--tf-muted); margin-bottom: 2px;
}
.tf-app-dash-nav-item.active { background: rgba(255,94,46,.12); color: var(--tf-accent); }
.tf-app-dash-nav-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
.tf-app-dash-content { padding: 16px; }
.tf-app-dash-stat-row {
  display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin-bottom: 12px;
}
.tf-app-dash-stat-card {
  background: var(--tf-bg-3); border-radius: 10px; padding: 10px;
  border: 1px solid rgba(255,255,255,.05);
}
.tf-app-dash-stat-num {
  font-size: .9rem; font-weight: 800; color: var(--tf-heading);
}
.tf-app-dash-stat-lbl { font-size: .6rem; color: var(--tf-meta); margin-top: 2px; }
.tf-app-dash-chart-area {
  background: var(--tf-bg-3); border-radius: 10px;
  padding: 10px; border: 1px solid rgba(255,255,255,.05);
  height: 80px; display: flex; align-items: flex-end; gap: 4px;
}
.tf-app-dash-bar {
  flex: 1; border-radius: 3px 3px 0 0;
  background: linear-gradient(180deg, rgba(255,94,46,.8), rgba(255,94,46,.2));
}

/* CSS Activity feed mockup */
.tf-app-feed-mock {
  background: var(--tf-bg-2);
  border: 1px solid var(--tf-border);
  border-radius: 16px; overflow: hidden;
  box-shadow: 0 24px 64px rgba(0,0,0,.5); padding: 20px;
}
.tf-app-feed-header {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 16px; padding-bottom: 12px;
  border-bottom: 1px solid var(--tf-border);
}
.tf-app-feed-title {
  font-size: .85rem; font-weight: 700; color: var(--tf-heading);
}
.tf-app-feed-badge {
  background: var(--tf-accent); color: #fff;
  font-size: .6rem; font-weight: 800; padding: 2px 8px;
  border-radius: 100px;
}
.tf-app-feed-list { display: flex; flex-direction: column; gap: 10px; }
.tf-app-feed-row {
  display: flex; align-items: flex-start; gap: 12px;
  padding: 10px 12px; background: rgba(255,255,255,.03);
  border-radius: 10px; border: 1px solid rgba(255,255,255,.05);
}
.tf-app-feed-avatar {
  width: 32px; height: 32px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .65rem; font-weight: 800; color: #fff; flex-shrink: 0;
}
.tf-app-feed-msg {
  flex: 1;
  font-size: .78rem; color: var(--tf-muted); line-height: 1.5;
}
.tf-app-feed-msg strong { color: var(--tf-heading); font-weight: 700; }
.tf-app-feed-time { font-size: .65rem; color: var(--tf-meta); white-space: nowrap; }

/* ══════════════════════════════════════════════════════════════════════════
   §6 — PRICING
   ══════════════════════════════════════════════════════════════════════════ */
.tf-app-pricing-bg { background: var(--tf-bg-2); }
.tf-app-pricing-toggle-row {
  display: flex; align-items: center; justify-content: center;
  gap: 16px; margin-bottom: 48px;
}
.tf-app-toggle-label {
  font-size: .88rem; font-weight: 600; color: var(--tf-muted);
  transition: color .2s;
}
.tf-app-toggle-label.active { color: var(--tf-heading); }
.tf-app-pricing-toggle {
  width: 48px; height: 26px; border-radius: 100px;
  background: var(--tf-bg-3); border: 1px solid var(--tf-border);
  position: relative; cursor: pointer; flex-shrink: 0;
  transition: background .2s;
}
.tf-app-pricing-toggle::after {
  content: ''; position: absolute;
  top: 3px; left: 3px;
  width: 18px; height: 18px; border-radius: 50%;
  background: var(--tf-muted);
  transition: transform .25s, background .2s;
}
.tf-app-pricing-toggle.annual { background: var(--tf-accent); }
.tf-app-pricing-toggle.annual::after {
  transform: translateX(22px); background: #fff;
}
.tf-app-save-badge {
  background: rgba(16,185,129,.12); border: 1px solid rgba(16,185,129,.22);
  color: #10b981; font-size: .68rem; font-weight: 700;
  padding: 3px 10px; border-radius: 100px;
}
.tf-app-pricing-grid {
  display: grid; grid-template-columns: repeat(3, 1fr);
  gap: 20px; align-items: start;
}
.tf-app-pricing-card {
  background: var(--tf-bg); border: 1px solid var(--tf-border);
  border-radius: 20px; padding: 32px;
  position: relative; transition: border-color .25s, transform .25s;
}
.tf-app-pricing-card:hover { border-color: rgba(255,94,46,.3); transform: translateY(-2px); }
.tf-app-pricing-card.popular {
  background: linear-gradient(180deg, rgba(255,94,46,.06) 0%, var(--tf-bg) 100%);
  border-color: rgba(255,94,46,.35);
  transform: scale(1.03);
}
.tf-app-pricing-card.popular:hover { transform: scale(1.03) translateY(-2px); }
.tf-app-popular-badge {
  position: absolute; top: -12px; left: 50%; transform: translateX(-50%);
  background: var(--tf-accent); color: #fff;
  font-size: .64rem; font-weight: 800; letter-spacing: .08em;
  text-transform: uppercase; padding: 4px 16px; border-radius: 100px;
  white-space: nowrap;
}
.tf-app-pricing-tier {
  font-size: .7rem; font-weight: 800; letter-spacing: .14em;
  text-transform: uppercase; color: var(--tf-accent); margin-bottom: 8px;
}
.tf-app-pricing-price {
  display: flex; align-items: flex-end; gap: 4px; margin-bottom: 4px;
}
.tf-app-pricing-price-num {
  font-size: 2.8rem; font-weight: 900; color: var(--tf-heading); line-height: 1;
}
.tf-app-pricing-price-mo {
  font-size: .85rem; color: var(--tf-muted); margin-bottom: 6px;
}
.tf-app-pricing-desc {
  font-size: .85rem; color: var(--tf-muted); margin-bottom: 24px; line-height: 1.6;
}
.tf-app-pricing-divider { border: none; border-top: 1px solid var(--tf-border); margin: 0 0 24px; }
.tf-app-pricing-features { list-style: none; display: flex; flex-direction: column; gap: 11px; margin-bottom: 28px; }
.tf-app-pricing-feature {
  display: flex; align-items: center; gap: 10px;
  font-size: .87rem; color: var(--tf-muted); line-height: 1.5;
}
.tf-app-pricing-feature svg { width: 16px; height: 16px; color: var(--tf-accent4); flex-shrink: 0; }
.tf-app-pricing-feature.muted svg { color: var(--tf-meta); opacity: .45; }
.tf-app-pricing-cta {
  display: flex; align-items: center; justify-content: center; gap: 8px;
  padding: 14px 24px; border-radius: 12px;
  font-size: .9rem; font-weight: 700; width: 100%;
  cursor: pointer; transition: transform .2s, box-shadow .2s;
}
.tf-app-pricing-cta:hover { transform: translateY(-1px); }
.tf-app-pricing-cta.primary {
  background: var(--tf-accent); color: #fff;
  box-shadow: 0 8px 24px rgba(255,94,46,.35);
}
.tf-app-pricing-cta.primary:hover { box-shadow: 0 12px 32px rgba(255,94,46,.45); }
.tf-app-pricing-cta.ghost {
  background: rgba(255,255,255,.06); color: var(--tf-heading);
  border: 1px solid var(--tf-border);
}
.tf-app-pricing-cta.ghost:hover { background: rgba(255,255,255,.1); }
.tf-app-pricing-cta svg { width: 16px; height: 16px; }

/* ══════════════════════════════════════════════════════════════════════════
   §7 — TESTIMONIALS
   ══════════════════════════════════════════════════════════════════════════ */
.tf-app-testi-grid {
  display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px;
}
.tf-app-testi-card {
  background: var(--tf-bg-2); border: 1px solid var(--tf-border);
  border-radius: 20px; padding: 28px;
  transition: border-color .25s, transform .25s;
}
.tf-app-testi-card:hover { border-color: rgba(255,94,46,.3); transform: translateY(-2px); }
.tf-app-testi-stars {
  display: flex; gap: 3px; margin-bottom: 16px;
}
.tf-app-testi-star {
  width: 15px; height: 15px; color: #fbbf24;
}
.tf-app-testi-quote {
  font-size: .9rem; color: var(--tf-muted); line-height: 1.75;
  margin-bottom: 20px; font-style: normal;
}
.tf-app-testi-author {
  display: flex; align-items: center; gap: 12px;
}
.tf-app-testi-avatar {
  width: 40px; height: 40px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .72rem; font-weight: 800; color: #fff; flex-shrink: 0;
}
.tf-app-testi-name { font-size: .88rem; font-weight: 700; color: var(--tf-heading); }
.tf-app-testi-role { font-size: .75rem; color: var(--tf-meta); margin-top: 1px; }

/* ══════════════════════════════════════════════════════════════════════════
   §8 — FINAL CTA
   ══════════════════════════════════════════════════════════════════════════ */
.tf-app-final-cta {
  position: relative; overflow: hidden;
  background: radial-gradient(ellipse 70% 80% at 50% 50%, rgba(255,94,46,.14) 0%, transparent 70%),
              var(--tf-bg);
  text-align: center; padding: 120px 24px;
}
.tf-app-final-cta::before {
  content: ''; position: absolute; inset: 0; pointer-events: none;
  background-image:
    linear-gradient(rgba(255,255,255,.03) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255,255,255,.03) 1px, transparent 1px);
  background-size: 48px 48px;
  mask-image: radial-gradient(ellipse 60% 70% at 50% 50%, #000 20%, transparent 100%);
}
.tf-app-final-inner { position: relative; z-index: 1; max-width: 680px; margin: 0 auto; }
.tf-app-final-h2 {
  font-size: clamp(2rem, 4vw, 3.2rem); font-weight: 900;
  color: var(--tf-heading); line-height: 1.08; letter-spacing: -.5px;
  margin-bottom: 16px;
}
.tf-app-final-sub {
  font-size: 1.05rem; color: var(--tf-muted); margin-bottom: 40px; line-height: 1.7;
}
.tf-app-final-stores {
  display: flex; justify-content: center; gap: 12px;
  flex-wrap: wrap; margin-bottom: 20px;
}
.tf-app-final-link {
  font-size: .85rem; color: var(--tf-meta); text-decoration: underline;
  text-underline-offset: 3px; margin-bottom: 44px; display: block;
  transition: color .2s;
}
.tf-app-final-link:hover { color: var(--tf-heading); }

/* Avatar stack */
.tf-app-avatar-stack { display: flex; flex-direction: column; align-items: center; gap: 12px; }
.tf-app-avatars {
  display: flex;
}
.tf-app-avatar-circle {
  width: 36px; height: 36px; border-radius: 50%;
  border: 2px solid var(--tf-bg); margin-left: -10px;
  display: flex; align-items: center; justify-content: center;
  font-size: .65rem; font-weight: 800; color: #fff;
  flex-shrink: 0;
}
.tf-app-avatars .tf-app-avatar-circle:first-child { margin-left: 0; }
.tf-app-avatar-text {
  font-size: .82rem; color: var(--tf-muted);
}
.tf-app-avatar-text strong { color: var(--tf-heading); }

/* ══════════════════════════════════════════════════════════════════════════
   SCROLL REVEAL
   ══════════════════════════════════════════════════════════════════════════ */
.tf-app-reveal {
  opacity: 0; transform: translateY(28px);
  transition: opacity .55s ease, transform .55s ease;
}
.tf-app-reveal.revealed {
  opacity: 1; transform: none;
}

/* ══════════════════════════════════════════════════════════════════════════
   RESPONSIVE
   ══════════════════════════════════════════════════════════════════════════ */
@media (max-width: 1024px) {
  .tf-app-hero-inner      { grid-template-columns: 1fr; gap: 48px; }
  .tf-app-phone-wrap      { justify-content: center; }
  .tf-app-float-pill:nth-child(1) { display: none; }
  .tf-app-float-pill:nth-child(3) { display: none; }
  .tf-app-bento-grid      { grid-template-columns: repeat(2, 1fr); }
  .tf-app-bento-card.large { grid-column: span 2; }
  .tf-app-panel           { grid-template-columns: 1fr; gap: 40px; }
  .tf-app-panel.reverse .tf-app-panel-visual { order: 1; }
  .tf-app-panel.reverse .tf-app-panel-text  { order: 2; }
  .tf-app-pricing-grid    { grid-template-columns: repeat(2, 1fr); }
  .tf-app-pricing-card.popular { transform: none; grid-column: span 2; max-width: 480px; margin: 0 auto; width: 100%; }
  .tf-app-testi-grid      { grid-template-columns: repeat(2, 1fr); }
  .tf-app-hiw-flow        { grid-template-columns: 1fr; gap: 40px; }
  .tf-app-hiw-flow::before { display: none; }
  .tf-app-proof-stats     { gap: 36px; }
}
@media (max-width: 640px) {
  .tf-app-section         { padding: 60px 0; }
  .tf-app-bento-grid      { grid-template-columns: 1fr; }
  .tf-app-bento-card.large { grid-column: span 1; }
  .tf-app-pricing-grid    { grid-template-columns: 1fr; }
  .tf-app-pricing-card.popular { grid-column: span 1; max-width: none; }
  .tf-app-testi-grid      { grid-template-columns: 1fr; }
  .tf-app-hero-ctas       { flex-direction: column; }
  .tf-app-store-row       { justify-content: center; }
  .tf-app-proof-stats     { flex-direction: column; gap: 24px; }
}
</style>

<?php
/* ══════════════════════════════════════════════════════════════════════════
   §1 — HERO
   ══════════════════════════════════════════════════════════════════════════ */
?>
<section class="tf-app-hero" aria-labelledby="tf-app-hero-h1">
  <div class="tf-app-hero-inner">

    <!-- Left: copy -->
    <div class="tf-app-hero-content">
      <div class="tf-app-hero-badge" aria-hidden="true">
        <span class="tf-app-hero-badge-dot"></span>
        <?php echo tf_icon_get( 'smartphone', 13 ); ?>
        <?php esc_html_e( 'Now available on iOS & Android', 'themeflex' ); ?>
      </div>

      <h1 id="tf-app-hero-h1" class="tf-app-hero-h1">
        <?php esc_html_e( 'The App That Changes How You Work', 'themeflex' ); ?>
      </h1>

      <p class="tf-app-hero-sub">
        <?php esc_html_e( 'Supercharge your team\'s productivity with real-time collaboration, smart analytics, and AI-powered automation — all in your pocket.', 'themeflex' ); ?>
      </p>

      <div class="tf-app-hero-ctas">
        <a href="<?php echo esc_url( home_url( '/download/' ) ); ?>" class="tf-app-btn-primary">
          <?php echo tf_icon_get( 'download', 18 ); ?>
          <?php esc_html_e( 'Download Free', 'themeflex' ); ?>
        </a>
        <a href="<?php echo esc_url( home_url( '/demo/' ) ); ?>" class="tf-app-btn-ghost">
          <?php echo tf_icon_get( 'play-circle', 18 ); ?>
          <?php esc_html_e( 'Watch Demo', 'themeflex' ); ?>
        </a>
      </div>

      <div class="tf-app-store-row">
        <a href="<?php echo esc_url( home_url( '/app-store/' ) ); ?>" class="tf-app-store-pill" aria-label="<?php esc_attr_e( 'Download on the App Store', 'themeflex' ); ?>">
          <?php echo tf_icon_get( 'apple', 16 ); ?>
          <?php esc_html_e( 'App Store', 'themeflex' ); ?>
        </a>
        <a href="<?php echo esc_url( home_url( '/google-play/' ) ); ?>" class="tf-app-store-pill" aria-label="<?php esc_attr_e( 'Get it on Google Play', 'themeflex' ); ?>">
          <?php echo tf_icon_get( 'play', 16 ); ?>
          <?php esc_html_e( 'Google Play', 'themeflex' ); ?>
        </a>
      </div>
    </div><!-- /.tf-app-hero-content -->

    <!-- Right: CSS phone mockup -->
    <div class="tf-app-phone-wrap" aria-hidden="true">
      <!-- Floating pills -->
      <div class="tf-app-float-pill">
        <span class="tf-app-float-pill-dot" style="background:#10b981;box-shadow:0 0 6px #10b981;"></span>
        <?php esc_html_e( '99.9% Uptime', 'themeflex' ); ?>
      </div>
      <div class="tf-app-float-pill">
        <?php echo tf_icon_get( 'shield', 13 ); ?>
        <?php esc_html_e( '256-bit Encryption', 'themeflex' ); ?>
      </div>
      <div class="tf-app-float-pill">
        <?php echo tf_icon_get( 'cpu', 13 ); ?>
        <?php esc_html_e( 'AI-Powered', 'themeflex' ); ?>
      </div>

      <!-- Phone frame -->
      <div class="tf-app-phone">
        <!-- Status bar -->
        <div class="tf-app-phone-status">
          <span class="tf-app-phone-time">9:41</span>
          <div class="tf-app-phone-icons">
            <div class="tf-app-phone-signal" aria-hidden="true">
              <span></span><span></span><span></span><span></span>
            </div>
            <div class="tf-app-phone-batt" aria-hidden="true">
              <div class="tf-app-phone-batt-fill"></div>
            </div>
          </div>
        </div>
        <!-- App header -->
        <div class="tf-app-phone-header">
          <span class="tf-app-phone-app-title"><?php esc_html_e( 'Dashboard', 'themeflex' ); ?></span>
          <?php echo tf_icon_get( 'bell', 16 ); ?>
        </div>
        <!-- Screen content -->
        <div class="tf-app-phone-screen">
          <!-- 2x2 metric cards -->
          <div class="tf-app-phone-metrics">
            <?php
            $phone_metrics = [
              [ 'label' => __( 'Revenue', 'themeflex' ), 'num' => '$24k', 'trend' => '+8.2%', 'bg' => 'rgba(255,94,46,.18)', 'color' => '#ff5e2e', 'icon' => 'trending-up' ],
              [ 'label' => __( 'Users',   'themeflex' ), 'num' => '4.1k', 'trend' => '+12%',  'bg' => 'rgba(0,212,255,.15)', 'color' => '#00d4ff', 'icon' => 'users' ],
              [ 'label' => __( 'Tasks',   'themeflex' ), 'num' => '182',  'trend' => '+5.1%', 'bg' => 'rgba(168,85,247,.18)', 'color' => '#a855f7', 'icon' => 'layers' ],
              [ 'label' => __( 'Growth',  'themeflex' ), 'num' => '37%',  'trend' => '+3.4%', 'bg' => 'rgba(16,185,129,.15)', 'color' => '#10b981', 'icon' => 'bar-chart-2' ],
            ];
            foreach ( $phone_metrics as $m ) : ?>
              <div class="tf-app-phone-metric">
                <div class="tf-app-phone-metric-icon" style="background:<?php echo esc_attr( $m['bg'] ); ?>; color:<?php echo esc_attr( $m['color'] ); ?>;">
                  <?php echo tf_icon_get( $m['icon'], 12 ); ?>
                </div>
                <div class="tf-app-phone-metric-num"><?php echo esc_html( $m['num'] ); ?></div>
                <div class="tf-app-phone-metric-label"><?php echo esc_html( $m['label'] ); ?></div>
                <div class="tf-app-phone-metric-trend"><?php echo esc_html( $m['trend'] ); ?></div>
              </div>
            <?php endforeach; ?>
          </div>
          <!-- Mini chart bars -->
          <div class="tf-app-phone-chart">
            <div class="tf-app-phone-chart-label"><?php esc_html_e( 'Weekly Activity', 'themeflex' ); ?></div>
            <div class="tf-app-phone-bars" aria-hidden="true">
              <?php foreach ( [ 45, 70, 55, 90, 65, 80 ] as $h ) : ?>
                <div class="tf-app-phone-bar" style="height:<?php echo esc_attr( $h ); ?>%"></div>
              <?php endforeach; ?>
            </div>
          </div>
        </div><!-- /.tf-app-phone-screen -->
      </div><!-- /.tf-app-phone -->
    </div><!-- /.tf-app-phone-wrap -->

  </div><!-- /.tf-app-hero-inner -->
</section>

<?php
/* ══════════════════════════════════════════════════════════════════════════
   §2 — SOCIAL PROOF BAR
   ══════════════════════════════════════════════════════════════════════════ */
?>
<div class="tf-app-proof tf-app-reveal">
  <div class="tf-app-proof-inner">
    <p class="tf-app-proof-trusted"><?php esc_html_e( 'Trusted by teams at', 'themeflex' ); ?></p>
    <div class="tf-app-proof-logos">
      <?php
      $companies = [ 'Vercel', 'Linear', 'Loom', 'Notion', 'Stripe', 'Figma' ];
      foreach ( $companies as $c ) : ?>
        <span class="tf-app-proof-chip"><?php echo esc_html( $c ); ?></span>
      <?php endforeach; ?>
    </div>
    <div class="tf-app-proof-stats">
      <div class="tf-app-proof-stat">
        <div class="tf-app-proof-stat-num" data-counter="500000" data-suffix="k+">
          <span>500</span><span>k+</span>
        </div>
        <div class="tf-app-proof-stat-label"><?php esc_html_e( 'Active Users', 'themeflex' ); ?></div>
      </div>
      <div class="tf-app-proof-stat">
        <div class="tf-app-proof-stat-num">4.9<span style="color:var(--tf-accent);"><?php esc_html_e( 'stars', 'themeflex' ); ?></span></div>
        <div class="tf-app-proof-stat-label"><?php esc_html_e( 'App Store Rating', 'themeflex' ); ?></div>
      </div>
      <div class="tf-app-proof-stat">
        <div class="tf-app-proof-stat-num" data-counter="98" data-suffix="%">98<span>%</span></div>
        <div class="tf-app-proof-stat-label"><?php esc_html_e( 'Retention Rate', 'themeflex' ); ?></div>
      </div>
    </div>
  </div>
</div>

<?php
/* ══════════════════════════════════════════════════════════════════════════
   §3 — BENTO FEATURE GRID
   ══════════════════════════════════════════════════════════════════════════ */
?>
<section class="tf-app-section" aria-labelledby="tf-app-bento-h2">
  <div class="tf-app-wrap">
    <div class="tf-app-head tf-app-reveal">
      <div class="tf-app-label" aria-hidden="true">
        <?php echo tf_icon_get( 'zap', 13 ); ?>
        <?php esc_html_e( 'Features', 'themeflex' ); ?>
      </div>
      <h2 id="tf-app-bento-h2">
        <?php esc_html_e( 'Everything your team needs,', 'themeflex' ); ?>
        <span class="tf-app-gradient"><?php esc_html_e( 'nothing you don\'t', 'themeflex' ); ?></span>
      </h2>
      <p><?php esc_html_e( 'A complete toolkit built for fast-moving teams. Ship faster, collaborate smarter, stay secure.', 'themeflex' ); ?></p>
    </div>

    <div class="tf-app-bento-grid">

      <!-- Large card: Real-time Collaboration -->
      <div class="tf-app-bento-card large tf-app-reveal" style="transition-delay:.05s">
        <div class="tf-app-bento-card-icon" style="background:rgba(255,94,46,.15);color:var(--tf-accent);">
          <?php echo tf_icon_get( 'users', 22 ); ?>
        </div>
        <h3><?php esc_html_e( 'Real-time Collaboration', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'See every change as it happens. Work alongside your team with live cursors, presence indicators, and instant sync across all devices.', 'themeflex' ); ?></p>
        <!-- Terminal / users online widget -->
        <div class="tf-app-bento-terminal" aria-hidden="true">
          <div class="tf-app-bento-terminal-bar"><span></span><span></span><span></span></div>
          <?php
          $online_users = [
            [ 'name' => 'sarah.chen',   'action' => __( 'editing', 'themeflex' ), 'file' => 'dashboard.tsx', 'color' => '#ff5e2e' ],
            [ 'name' => 'marcus.reid',  'action' => __( 'viewing', 'themeflex' ), 'file' => 'analytics.ts',  'color' => '#a855f7' ],
            [ 'name' => 'priya.nair',   'action' => __( 'editing', 'themeflex' ), 'file' => 'api/users.ts',  'color' => '#00d4ff' ],
          ];
          foreach ( $online_users as $u ) : ?>
            <div class="tf-app-bento-user-row">
              <div class="tf-app-bento-cursor" style="background:<?php echo esc_attr( $u['color'] ); ?>;box-shadow:0 0 6px <?php echo esc_attr( $u['color'] ); ?>;"></div>
              <span class="tf-app-bento-user-name"><?php echo esc_html( $u['name'] ); ?></span>
              <span class="tf-app-bento-user-action"><?php echo esc_html( $u['action'] ); ?></span>
              <span class="tf-app-bento-user-file"><?php echo esc_html( $u['file'] ); ?></span>
            </div>
          <?php endforeach; ?>
          <div class="tf-app-bento-online-badge">
            <span class="tf-app-bento-online-dot"></span>
            <?php esc_html_e( '3 teammates online', 'themeflex' ); ?>
          </div>
        </div>
      </div><!-- /.large -->

      <!-- Medium card: Smart Notifications -->
      <div class="tf-app-bento-card tf-app-reveal" style="transition-delay:.1s">
        <div class="tf-app-bento-card-icon" style="background:rgba(168,85,247,.15);color:#a855f7;">
          <?php echo tf_icon_get( 'bell', 22 ); ?>
        </div>
        <h3><?php esc_html_e( 'Smart Notifications', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'AI filters the noise so you only see what matters. Customise priority rules per project.', 'themeflex' ); ?></p>
        <div class="tf-app-notif-list" aria-hidden="true">
          <?php
          $notifs = [
            [ 'color' => '#ff5e2e', 'text' => __( 'Deploy succeeded on main', 'themeflex' ),      'time' => '2m' ],
            [ 'color' => '#a855f7', 'text' => __( 'Sarah mentioned you in a comment', 'themeflex' ), 'time' => '9m' ],
            [ 'color' => '#10b981', 'text' => __( 'Weekly report is ready', 'themeflex' ),          'time' => '1h' ],
          ];
          foreach ( $notifs as $n ) : ?>
            <div class="tf-app-notif-row">
              <span class="tf-app-notif-dot" style="background:<?php echo esc_attr( $n['color'] ); ?>"></span>
              <span class="tf-app-notif-text"><?php echo esc_html( $n['text'] ); ?></span>
              <span class="tf-app-notif-time"><?php echo esc_html( $n['time'] ); ?></span>
            </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Medium card: Advanced Analytics -->
      <div class="tf-app-bento-card tf-app-reveal" style="transition-delay:.15s">
        <div class="tf-app-bento-card-icon" style="background:rgba(0,212,255,.12);color:#00d4ff;">
          <?php echo tf_icon_get( 'bar-chart-2', 22 ); ?>
        </div>
        <h3><?php esc_html_e( 'Advanced Analytics', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'Drill into the metrics that drive your business. Cohort analysis, funnels, retention — all in one view.', 'themeflex' ); ?></p>
        <div class="tf-app-bento-chart" aria-hidden="true">
          <div class="tf-app-bento-bars">
            <?php foreach ( [ 55, 40, 75, 50, 90, 65, 82, 70 ] as $h ) : ?>
              <div class="tf-app-bento-bar" style="height:<?php echo esc_attr( $h ); ?>%"></div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <!-- Small card: Offline Mode -->
      <div class="tf-app-bento-card tf-app-reveal" style="transition-delay:.2s">
        <div class="tf-app-bento-card-icon" style="background:rgba(16,185,129,.12);color:#10b981;">
          <?php echo tf_icon_get( 'wifi-off', 22 ); ?>
        </div>
        <h3><?php esc_html_e( '100% Offline Mode', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'Keep working even without a connection. Changes sync automatically when you\'re back online.', 'themeflex' ); ?></p>
        <div class="tf-app-bento-status" aria-label="<?php esc_attr_e( 'Offline mode active', 'themeflex' ); ?>">
          <span class="tf-app-bento-status-dot"></span>
          <?php esc_html_e( 'Offline mode ready', 'themeflex' ); ?>
        </div>
      </div>

      <!-- Small card: Security -->
      <div class="tf-app-bento-card tf-app-reveal" style="transition-delay:.25s">
        <div class="tf-app-bento-card-icon" style="background:rgba(168,85,247,.15);color:#a855f7;">
          <?php echo tf_icon_get( 'lock', 22 ); ?>
        </div>
        <h3><?php esc_html_e( 'Bank-level Security', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'Your data is encrypted at rest and in transit. SOC 2 Type II certified, GDPR ready.', 'themeflex' ); ?></p>
        <div class="tf-app-bento-chip" aria-label="<?php esc_attr_e( 'AES-256 Encryption', 'themeflex' ); ?>">
          <?php echo tf_icon_get( 'shield', 13 ); ?>
          AES-256
        </div>
      </div>

    </div><!-- /.tf-app-bento-grid -->
  </div>
</section>

<?php
/* ══════════════════════════════════════════════════════════════════════════
   §4 — HOW IT WORKS
   ══════════════════════════════════════════════════════════════════════════ */
?>
<section class="tf-app-section tf-app-hiw" aria-labelledby="tf-app-hiw-h2">
  <div class="tf-app-wrap">
    <div class="tf-app-head tf-app-reveal">
      <div class="tf-app-label" aria-hidden="true">
        <?php echo tf_icon_get( 'layers', 13 ); ?>
        <?php esc_html_e( 'How It Works', 'themeflex' ); ?>
      </div>
      <h2 id="tf-app-hiw-h2">
        <?php esc_html_e( 'Up and running in', 'themeflex' ); ?>
        <span class="tf-app-gradient"><?php esc_html_e( '3 simple steps', 'themeflex' ); ?></span>
      </h2>
      <p><?php esc_html_e( 'Getting started takes minutes, not hours. No IT ticket required.', 'themeflex' ); ?></p>
    </div>

    <div class="tf-app-hiw-flow">
      <?php
      $steps = [
        [
          'num'   => '1',
          'icon'  => 'user-plus',
          'title' => __( 'Create Account', 'themeflex' ),
          'desc'  => __( 'Sign up in seconds with your email or Google account. No credit card required to get started.', 'themeflex' ),
        ],
        [
          'num'   => '2',
          'icon'  => 'settings',
          'title' => __( 'Set Up Your Workspace', 'themeflex' ),
          'desc'  => __( 'Customise your workspace with the projects, boards, and integrations your team needs.', 'themeflex' ),
        ],
        [
          'num'   => '3',
          'icon'  => 'users',
          'title' => __( 'Invite Your Team', 'themeflex' ),
          'desc'  => __( 'Send invites in one click. Your team gets instant access and you\'re collaborating in real time.', 'themeflex' ),
        ],
      ];
      foreach ( $steps as $i => $step ) : ?>
        <div class="tf-app-hiw-step tf-app-reveal" style="transition-delay:<?php echo esc_attr( $i * 0.12 ); ?>s">
          <div class="tf-app-hiw-ring" aria-hidden="true">
            <?php echo tf_icon_get( $step['icon'], 28 ); ?>
            <div class="tf-app-hiw-num" aria-label="<?php echo esc_attr( sprintf( __( 'Step %s', 'themeflex' ), $step['num'] ) ); ?>"><?php echo esc_html( $step['num'] ); ?></div>
          </div>
          <h3 class="tf-app-hiw-title"><?php echo esc_html( $step['title'] ); ?></h3>
          <p class="tf-app-hiw-desc"><?php echo esc_html( $step['desc'] ); ?></p>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php
/* ══════════════════════════════════════════════════════════════════════════
   §5 — FEATURE DETAIL PANELS
   ══════════════════════════════════════════════════════════════════════════ */
?>
<section class="tf-app-section tf-app-panels" aria-labelledby="tf-app-panels-heading">
  <h2 id="tf-app-panels-heading" class="screen-reader-text"><?php esc_html_e( 'Feature Details', 'themeflex' ); ?></h2>
  <div class="tf-app-wrap">

    <!-- Panel A: visual left -->
    <div class="tf-app-panel tf-app-reveal">
      <!-- CSS Dashboard visual -->
      <div class="tf-app-panel-visual" aria-hidden="true">
        <div class="tf-app-dash-mock">
          <div class="tf-app-dash-titlebar">
            <div class="tf-app-dash-dots"><span></span><span></span><span></span></div>
          </div>
          <div class="tf-app-dash-body">
            <div class="tf-app-dash-sidebar">
              <?php
              $nav_items = [
                [ 'label' => __( 'Overview', 'themeflex' ), 'active' => true,  'color' => '#ff5e2e' ],
                [ 'label' => __( 'Analytics', 'themeflex'), 'active' => false, 'color' => '#94a3b8' ],
                [ 'label' => __( 'Projects', 'themeflex' ), 'active' => false, 'color' => '#94a3b8' ],
                [ 'label' => __( 'Team', 'themeflex' ),     'active' => false, 'color' => '#94a3b8' ],
                [ 'label' => __( 'Settings', 'themeflex' ), 'active' => false, 'color' => '#94a3b8' ],
              ];
              foreach ( $nav_items as $nav ) : ?>
                <div class="tf-app-dash-nav-item<?php echo $nav['active'] ? ' active' : ''; ?>">
                  <span class="tf-app-dash-nav-dot" style="background:<?php echo esc_attr( $nav['color'] ); ?>"></span>
                  <?php echo esc_html( $nav['label'] ); ?>
                </div>
              <?php endforeach; ?>
            </div>
            <div class="tf-app-dash-content">
              <div class="tf-app-dash-stat-row">
                <?php foreach ( [ [ '$24k', __( 'Revenue', 'themeflex' ) ], [ '4.1k', __( 'Users', 'themeflex' ) ], [ '98%', __( 'Uptime', 'themeflex' ) ] ] as $s ) : ?>
                  <div class="tf-app-dash-stat-card">
                    <div class="tf-app-dash-stat-num"><?php echo esc_html( $s[0] ); ?></div>
                    <div class="tf-app-dash-stat-lbl"><?php echo esc_html( $s[1] ); ?></div>
                  </div>
                <?php endforeach; ?>
              </div>
              <div class="tf-app-dash-chart-area" aria-hidden="true">
                <?php foreach ( [ 45, 60, 35, 80, 55, 90, 65, 75, 50, 85 ] as $h ) : ?>
                  <div class="tf-app-dash-bar" style="height:<?php echo esc_attr( $h ); ?>%"></div>
                <?php endforeach; ?>
              </div>
            </div>
          </div>
        </div>
      </div><!-- /.tf-app-panel-visual -->

      <!-- Text -->
      <div class="tf-app-panel-text">
        <div class="tf-app-panel-label" aria-hidden="true">
          <?php echo tf_icon_get( 'bar-chart-2', 14 ); ?>
          <?php esc_html_e( 'Dashboard', 'themeflex' ); ?>
        </div>
        <h2><?php esc_html_e( 'Powerful Dashboard', 'themeflex' ); ?></h2>
        <p><?php esc_html_e( 'Get a bird\'s-eye view of your entire operation with a fully customisable command centre that surfaces what matters most.', 'themeflex' ); ?></p>
        <ul class="tf-app-panel-bullets">
          <?php
          $panel_a_bullets = [
            __( 'Drag-and-drop widgets — build the view you need', 'themeflex' ),
            __( 'Live data with sub-second refresh rates', 'themeflex' ),
            __( 'Custom date ranges, filters, and drill-downs', 'themeflex' ),
            __( 'Export to CSV, PDF, or share via shareable link', 'themeflex' ),
          ];
          foreach ( $panel_a_bullets as $b ) : ?>
            <li class="tf-app-panel-bullet">
              <?php echo tf_icon_get( 'check-circle', 18 ); ?>
              <?php echo esc_html( $b ); ?>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>
    </div><!-- /.tf-app-panel -->

    <!-- Panel B: visual right -->
    <div class="tf-app-panel reverse tf-app-reveal">
      <!-- Text -->
      <div class="tf-app-panel-text">
        <div class="tf-app-panel-label" aria-hidden="true">
          <?php echo tf_icon_get( 'bell', 14 ); ?>
          <?php esc_html_e( 'Activity Feed', 'themeflex' ); ?>
        </div>
        <h2><?php esc_html_e( 'Stay in Sync', 'themeflex' ); ?></h2>
        <p><?php esc_html_e( 'Never miss an important update. The unified activity feed surfaces every action across your workspace in real time.', 'themeflex' ); ?></p>
        <ul class="tf-app-panel-bullets">
          <?php
          $panel_b_bullets = [
            __( 'Thread-based discussions tied to any object', 'themeflex' ),
            __( 'Smart @mentions with instant push notifications', 'themeflex' ),
            __( 'Full audit log for compliance and transparency', 'themeflex' ),
            __( 'Digest emails — daily or weekly, your choice', 'themeflex' ),
          ];
          foreach ( $panel_b_bullets as $b ) : ?>
            <li class="tf-app-panel-bullet">
              <?php echo tf_icon_get( 'check-circle', 18 ); ?>
              <?php echo esc_html( $b ); ?>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>

      <!-- CSS Activity feed visual -->
      <div class="tf-app-panel-visual" aria-hidden="true">
        <div class="tf-app-feed-mock">
          <div class="tf-app-feed-header">
            <span class="tf-app-feed-title"><?php esc_html_e( 'Activity Feed', 'themeflex' ); ?></span>
            <span class="tf-app-feed-badge">Live</span>
          </div>
          <div class="tf-app-feed-list">
            <?php
            $feed_items = [
              [ 'initials' => 'SC', 'color' => '#ff5e2e', 'msg' => sprintf( __( '<strong>Sarah</strong> deployed v2.4.1 to production', 'themeflex' ) ), 'time' => '2m' ],
              [ 'initials' => 'MR', 'color' => '#a855f7', 'msg' => sprintf( __( '<strong>Marcus</strong> closed 5 tasks in Sprint 14', 'themeflex' ) ), 'time' => '8m' ],
              [ 'initials' => 'PN', 'color' => '#00d4ff', 'msg' => sprintf( __( '<strong>Priya</strong> left a comment on API Docs', 'themeflex' ) ), 'time' => '14m' ],
              [ 'initials' => 'TL', 'color' => '#10b981', 'msg' => sprintf( __( '<strong>Tom</strong> merged branch feature/onboarding', 'themeflex' ) ), 'time' => '31m' ],
            ];
            foreach ( $feed_items as $f ) : ?>
              <div class="tf-app-feed-row">
                <div class="tf-app-feed-avatar" style="background:<?php echo esc_attr( $f['color'] ); ?>" aria-hidden="true"><?php echo esc_html( $f['initials'] ); ?></div>
                <div class="tf-app-feed-msg"><?php echo wp_kses( $f['msg'], [ 'strong' => [] ] ); ?></div>
                <div class="tf-app-feed-time"><?php echo esc_html( $f['time'] ); ?></div>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div><!-- /.tf-app-panel-visual -->
    </div><!-- /.tf-app-panel.reverse -->

  </div>
</section>

<?php
/* ══════════════════════════════════════════════════════════════════════════
   §6 — PRICING
   ══════════════════════════════════════════════════════════════════════════ */
?>
<section class="tf-app-section tf-app-pricing-bg" aria-labelledby="tf-app-pricing-h2">
  <div class="tf-app-wrap">
    <div class="tf-app-head tf-app-reveal">
      <div class="tf-app-label" aria-hidden="true">
        <?php echo tf_icon_get( 'zap', 13 ); ?>
        <?php esc_html_e( 'Pricing', 'themeflex' ); ?>
      </div>
      <h2 id="tf-app-pricing-h2">
        <?php esc_html_e( 'Simple, transparent', 'themeflex' ); ?>
        <span class="tf-app-gradient"><?php esc_html_e( 'pricing', 'themeflex' ); ?></span>
      </h2>
      <p><?php esc_html_e( 'Start free. Scale as you grow. Cancel anytime.', 'themeflex' ); ?></p>
    </div>

    <!-- Annual/Monthly toggle -->
    <div class="tf-app-pricing-toggle-row tf-app-reveal">
      <span class="tf-app-toggle-label active" id="tf-app-month-label"><?php esc_html_e( 'Monthly', 'themeflex' ); ?></span>
      <button
        id="tf-app-pricing-toggle"
        class="tf-app-pricing-toggle"
        role="switch"
        aria-checked="false"
        aria-label="<?php esc_attr_e( 'Toggle annual billing', 'themeflex' ); ?>"
      ></button>
      <span class="tf-app-toggle-label" id="tf-app-annual-label"><?php esc_html_e( 'Annual', 'themeflex' ); ?></span>
      <span class="tf-app-save-badge"><?php esc_html_e( 'Save 20%', 'themeflex' ); ?></span>
    </div>

    <div class="tf-app-pricing-grid">
      <?php
      $plans = [
        [
          'tier'       => __( 'Starter', 'themeflex' ),
          'popular'    => false,
          'price_mo'   => '0',
          'price_yr'   => '0',
          'desc'       => __( 'Perfect for individuals and small side projects just getting started.', 'themeflex' ),
          'cta_text'   => __( 'Get Started Free', 'themeflex' ),
          'cta_style'  => 'ghost',
          'cta_url'    => home_url( '/signup/' ),
          'features'   => [
            [ 'text' => __( '1 workspace', 'themeflex' ),           'included' => true ],
            [ 'text' => __( 'Up to 3 team members', 'themeflex' ),  'included' => true ],
            [ 'text' => __( '5 GB storage', 'themeflex' ),          'included' => true ],
            [ 'text' => __( 'Core analytics', 'themeflex' ),        'included' => true ],
            [ 'text' => __( 'Priority support', 'themeflex' ),      'included' => false ],
            [ 'text' => __( 'Advanced automation', 'themeflex' ),   'included' => false ],
          ],
        ],
        [
          'tier'       => __( 'Pro', 'themeflex' ),
          'popular'    => true,
          'price_mo'   => '12',
          'price_yr'   => '10',
          'desc'       => __( 'For growing teams who need more power and advanced collaboration.', 'themeflex' ),
          'cta_text'   => __( 'Start Free Trial', 'themeflex' ),
          'cta_style'  => 'primary',
          'cta_url'    => home_url( '/signup/pro/' ),
          'features'   => [
            [ 'text' => __( 'Unlimited workspaces', 'themeflex' ),  'included' => true ],
            [ 'text' => __( 'Up to 20 team members', 'themeflex' ), 'included' => true ],
            [ 'text' => __( '100 GB storage', 'themeflex' ),        'included' => true ],
            [ 'text' => __( 'Advanced analytics', 'themeflex' ),    'included' => true ],
            [ 'text' => __( 'Priority support', 'themeflex' ),      'included' => true ],
            [ 'text' => __( 'Advanced automation', 'themeflex' ),   'included' => false ],
          ],
        ],
        [
          'tier'       => __( 'Team', 'themeflex' ),
          'popular'    => false,
          'price_mo'   => '29',
          'price_yr'   => '23',
          'desc'       => __( 'For larger organisations requiring enterprise-grade controls and unlimited scale.', 'themeflex' ),
          'cta_text'   => __( 'Start Free Trial', 'themeflex' ),
          'cta_style'  => 'ghost',
          'cta_url'    => home_url( '/signup/team/' ),
          'features'   => [
            [ 'text' => __( 'Unlimited workspaces', 'themeflex' ),  'included' => true ],
            [ 'text' => __( 'Unlimited team members', 'themeflex' ),'included' => true ],
            [ 'text' => __( '1 TB storage', 'themeflex' ),          'included' => true ],
            [ 'text' => __( 'Advanced analytics', 'themeflex' ),    'included' => true ],
            [ 'text' => __( 'Priority support', 'themeflex' ),      'included' => true ],
            [ 'text' => __( 'Advanced automation', 'themeflex' ),   'included' => true ],
          ],
        ],
      ];

      foreach ( $plans as $plan ) : ?>
        <div class="tf-app-pricing-card<?php echo $plan['popular'] ? ' popular' : ''; ?> tf-app-reveal">
          <?php if ( $plan['popular'] ) : ?>
            <div class="tf-app-popular-badge" aria-label="<?php esc_attr_e( 'Most popular plan', 'themeflex' ); ?>"><?php esc_html_e( 'Most Popular', 'themeflex' ); ?></div>
          <?php endif; ?>
          <div class="tf-app-pricing-tier"><?php echo esc_html( $plan['tier'] ); ?></div>
          <div class="tf-app-pricing-price">
            <span class="tf-app-pricing-price-num">
              $<span class="tf-app-price-value" data-monthly="<?php echo esc_attr( $plan['price_mo'] ); ?>" data-annual="<?php echo esc_attr( $plan['price_yr'] ); ?>"><?php echo esc_html( $plan['price_mo'] ); ?></span>
            </span>
            <span class="tf-app-pricing-price-mo"><?php esc_html_e( '/mo', 'themeflex' ); ?></span>
          </div>
          <p class="tf-app-pricing-desc"><?php echo esc_html( $plan['desc'] ); ?></p>
          <hr class="tf-app-pricing-divider">
          <ul class="tf-app-pricing-features">
            <?php foreach ( $plan['features'] as $feat ) : ?>
              <li class="tf-app-pricing-feature<?php echo ! $feat['included'] ? ' muted' : ''; ?>">
                <?php echo tf_icon_get( 'check-circle', 16 ); ?>
                <?php echo esc_html( $feat['text'] ); ?>
              </li>
            <?php endforeach; ?>
          </ul>
          <a href="<?php echo esc_url( $plan['cta_url'] ); ?>" class="tf-app-pricing-cta <?php echo esc_attr( $plan['cta_style'] ); ?>">
            <?php echo esc_html( $plan['cta_text'] ); ?>
            <?php echo tf_icon_get( 'arrow-right', 16 ); ?>
          </a>
        </div>
      <?php endforeach; ?>
    </div><!-- /.tf-app-pricing-grid -->
  </div>
</section>

<?php
/* ══════════════════════════════════════════════════════════════════════════
   §7 — TESTIMONIALS
   ══════════════════════════════════════════════════════════════════════════ */
?>
<section class="tf-app-section" aria-labelledby="tf-app-testi-h2">
  <div class="tf-app-wrap">
    <div class="tf-app-head tf-app-reveal">
      <div class="tf-app-label" aria-hidden="true">
        <?php echo tf_icon_get( 'star', 13 ); ?>
        <?php esc_html_e( 'Testimonials', 'themeflex' ); ?>
      </div>
      <h2 id="tf-app-testi-h2">
        <?php esc_html_e( 'Loved by teams', 'themeflex' ); ?>
        <span class="tf-app-gradient"><?php esc_html_e( 'worldwide', 'themeflex' ); ?></span>
      </h2>
      <p><?php esc_html_e( 'Don\'t take our word for it. Here\'s what our users say about us.', 'themeflex' ); ?></p>
    </div>

    <div class="tf-app-testi-grid">
      <?php
      $testimonials = [
        [
          'quote'    => __( 'This app completely transformed how our remote team collaborates. We shipped 40% faster within the first month alone.', 'themeflex' ),
          'name'     => 'Sarah Chen',
          'role'     => __( 'CTO at LoopStack', 'themeflex' ),
          'initials' => 'SC',
          'color'    => '#ff5e2e',
        ],
        [
          'quote'    => __( 'The offline mode is a game-changer for our field teams. Zero downtime, everything syncs perfectly when they\'re back online.', 'themeflex' ),
          'name'     => 'Marcus Reid',
          'role'     => __( 'Engineering Lead, Orbit.io', 'themeflex' ),
          'initials' => 'MR',
          'color'    => '#a855f7',
        ],
        [
          'quote'    => __( 'Pricing is shockingly fair. We replaced three different apps with this one platform and saved over $600 a month.', 'themeflex' ),
          'name'     => 'Priya Nair',
          'role'     => __( 'Founder, Quill SaaS', 'themeflex' ),
          'initials' => 'PN',
          'color'    => '#00d4ff',
        ],
      ];

      foreach ( $testimonials as $i => $t ) : ?>
        <article class="tf-app-testi-card tf-app-reveal" style="transition-delay:<?php echo esc_attr( $i * 0.1 ); ?>s">
          <div class="tf-app-testi-stars" aria-label="<?php esc_attr_e( '5 out of 5 stars', 'themeflex' ); ?>">
            <?php for ( $s = 0; $s < 5; $s++ ) : ?>
              <svg class="tf-app-testi-star" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.958a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.37 2.448a1 1 0 00-.364 1.118l1.286 3.958c.3.921-.755 1.688-1.54 1.118L10 15.347l-3.37 2.448c-.784.57-1.838-.197-1.539-1.118l1.286-3.958a1 1 0 00-.364-1.118L2.643 9.385c-.783-.57-.38-1.81.588-1.81h4.162a1 1 0 00.95-.69L9.049 2.927z"/>
              </svg>
            <?php endfor; ?>
          </div>
          <blockquote class="tf-app-testi-quote"><?php echo esc_html( $t['quote'] ); ?></blockquote>
          <div class="tf-app-testi-author">
            <div class="tf-app-testi-avatar" style="background:<?php echo esc_attr( $t['color'] ); ?>" aria-hidden="true"><?php echo esc_html( $t['initials'] ); ?></div>
            <div>
              <div class="tf-app-testi-name"><?php echo esc_html( $t['name'] ); ?></div>
              <div class="tf-app-testi-role"><?php echo esc_html( $t['role'] ); ?></div>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div><!-- /.tf-app-testi-grid -->
  </div>
</section>

<?php
/* ══════════════════════════════════════════════════════════════════════════
   §8 — FINAL CTA
   ══════════════════════════════════════════════════════════════════════════ */
?>
<section class="tf-app-final-cta tf-app-reveal" aria-labelledby="tf-app-final-h2">
  <div class="tf-app-final-inner">
    <div class="tf-app-label" style="margin:0 auto 24px;" aria-hidden="true">
      <?php echo tf_icon_get( 'smartphone', 13 ); ?>
      <?php esc_html_e( 'Get Started', 'themeflex' ); ?>
    </div>
    <h2 id="tf-app-final-h2" class="tf-app-final-h2">
      <?php esc_html_e( 'Start for Free Today', 'themeflex' ); ?>
    </h2>
    <p class="tf-app-final-sub">
      <?php esc_html_e( 'No credit card required. 14-day free trial on all paid plans.', 'themeflex' ); ?>
    </p>

    <div class="tf-app-final-stores">
      <a href="<?php echo esc_url( home_url( '/app-store/' ) ); ?>" class="tf-app-store-pill" aria-label="<?php esc_attr_e( 'Download on the App Store', 'themeflex' ); ?>">
        <?php echo tf_icon_get( 'apple', 16 ); ?>
        <?php esc_html_e( 'App Store', 'themeflex' ); ?>
      </a>
      <a href="<?php echo esc_url( home_url( '/google-play/' ) ); ?>" class="tf-app-store-pill" aria-label="<?php esc_attr_e( 'Get it on Google Play', 'themeflex' ); ?>">
        <?php echo tf_icon_get( 'play', 16 ); ?>
        <?php esc_html_e( 'Google Play', 'themeflex' ); ?>
      </a>
    </div>

    <a href="<?php echo esc_url( home_url( '/signup/' ) ); ?>" class="tf-app-final-link">
      <?php esc_html_e( 'or start in browser', 'themeflex' ); ?>
    </a>

    <!-- Avatar stack -->
    <div class="tf-app-avatar-stack">
      <div class="tf-app-avatars" aria-hidden="true">
        <?php
        $avatars = [
          [ 'i' => 'JK', 'c' => '#ff5e2e' ],
          [ 'i' => 'AL', 'c' => '#a855f7' ],
          [ 'i' => 'MB', 'c' => '#00d4ff' ],
          [ 'i' => 'SR', 'c' => '#10b981' ],
          [ 'i' => 'TW', 'c' => '#fbbf24' ],
        ];
        foreach ( $avatars as $av ) : ?>
          <div class="tf-app-avatar-circle" style="background:<?php echo esc_attr( $av['c'] ); ?>">
            <?php echo esc_html( $av['i'] ); ?>
          </div>
        <?php endforeach; ?>
      </div>
      <p class="tf-app-avatar-text">
        <?php esc_html_e( 'Join', 'themeflex' ); ?> <strong><?php esc_html_e( '500k+ users', 'themeflex' ); ?></strong> <?php esc_html_e( 'already using the app', 'themeflex' ); ?>
      </p>
    </div>
  </div>
</section>

</main><!-- /#tf-app-main -->

<script>
/* ══════════════════════════════════════════════════════════════════════════
   ThemeFlex Mobile App Landing Page — Vanilla JS
   No dependencies. Runs after DOM is ready.
   ══════════════════════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  /* ── Scroll reveal (IntersectionObserver) ─────────────────────────────── */
  var revealEls = document.querySelectorAll('.tf-app-reveal');

  if ('IntersectionObserver' in window) {
    var revealObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
          revealObs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });

    revealEls.forEach(function (el) { revealObs.observe(el); });
  } else {
    /* Fallback: show all immediately */
    revealEls.forEach(function (el) { el.classList.add('revealed'); });
  }

  /* ── Animated counters ────────────────────────────────────────────────── */
  function animateCounter(el) {
    var target = parseInt(el.getAttribute('data-counter'), 10);
    if (isNaN(target)) return;
    var start     = 0;
    var duration  = 1800;
    var startTime = null;

    function step(timestamp) {
      if (!startTime) startTime = timestamp;
      var progress = Math.min((timestamp - startTime) / duration, 1);
      var eased    = 1 - Math.pow(1 - progress, 3);
      var current  = Math.floor(eased * target);
      /* Rebuild inner while preserving coloured spans */
      var suffix = el.getAttribute('data-suffix') || '';
      el.innerHTML = current + '<span>' + suffix + '</span>';
      if (progress < 1) requestAnimationFrame(step);
    }

    requestAnimationFrame(step);
  }

  if ('IntersectionObserver' in window) {
    var counterObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          animateCounter(entry.target);
          counterObs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.5 });

    document.querySelectorAll('[data-counter]').forEach(function (el) {
      counterObs.observe(el);
    });
  }

  /* ── Pricing toggle (annual / monthly) ───────────────────────────────── */
  var toggleBtn   = document.getElementById('tf-app-pricing-toggle');
  var monthLabel  = document.getElementById('tf-app-month-label');
  var annualLabel = document.getElementById('tf-app-annual-label');
  var isAnnual    = false;

  function updatePricing() {
    var prices = document.querySelectorAll('.tf-app-price-value');

    prices.forEach(function (el) {
      var val = isAnnual
        ? el.getAttribute('data-annual')
        : el.getAttribute('data-monthly');
      el.textContent = val;
    });

    if (isAnnual) {
      toggleBtn.classList.add('annual');
      toggleBtn.setAttribute('aria-checked', 'true');
      annualLabel.classList.add('active');
      monthLabel.classList.remove('active');
    } else {
      toggleBtn.classList.remove('annual');
      toggleBtn.setAttribute('aria-checked', 'false');
      monthLabel.classList.add('active');
      annualLabel.classList.remove('active');
    }
  }

  if (toggleBtn) {
    toggleBtn.addEventListener('click', function () {
      isAnnual = !isAnnual;
      updatePricing();
    });
    toggleBtn.addEventListener('keydown', function (e) {
      if (e.key === ' ' || e.key === 'Enter') {
        e.preventDefault();
        isAnnual = !isAnnual;
        updatePricing();
      }
    });
  }

})();
</script>

<?php get_footer(); ?>
