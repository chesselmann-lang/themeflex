<?php
/**
 * Template Name: Mortgage Broker
 *
 * Premium mortgage broker / financial adviser homepage.
 * Fonts  : Merriweather + Source Sans 3 (Google Fonts)
 * Palette: navy trust #0A2342 / corporate blue #1B4F8A / warm gold #C8962A / sage green #3D8B6E / pearl #F7F8FA
 * Tokens : --mb-* (zero cross-template contamination)
 */
defined('ABSPATH') || exit;
srand(crc32(get_the_permalink()));

/* ── Hero floating particles ────────────────────────────── */
$fin_chars = ['£','%','◈','⬡','◇','✦','·','∘','◦','▫'];
$particles = [];
for ($i = 0; $i < 14; $i++) {
    $particles[] = [
        'sym'  => $fin_chars[array_rand($fin_chars)],
        'top'  => rand(5,90),
        'left' => rand(3,95),
        'size' => rand(12,22),
        'dur'  => rand(7,16),
        'del'  => rand(0,9),
        'col'  => (rand(0,1) ? 'rgba(200,150,42,.4)' : 'rgba(27,79,138,.4)'),
    ];
}

/* ── City skyline buildings ─────────────────────────────── */
$buildings = [];
$b_widths  = [50,35,60,45,55,40,65,38];
$b_heights = [180,220,160,240,200,170,260,190];
for ($i = 0; $i < 8; $i++) {
    $windows = [];
    for ($r = 0; $r < rand(3,6); $r++) {
        for ($c = 0; $c < rand(2,4); $c++) {
            $windows[] = ['r'=>$r,'c'=>$c,'lit'=>rand(0,1)];
        }
    }
    $buildings[] = [
        'w' => $b_widths[$i],
        'h' => $b_heights[$i],
        'col' => sprintf('#%02x%02x%02x', rand(10,35), rand(25,55), rand(55,90)),
        'windows' => $windows,
    ];
}

/* ── Rate chart bars ────────────────────────────────────── */
$chart_bars = [
    ['label'=>'2yr Fix','rate'=>4.2,'col'=>'var(--mb-blue)'],
    ['label'=>'5yr Fix','rate'=>4.5,'col'=>'var(--mb-blue-lt)'],
    ['label'=>'Tracker','rate'=>4.8,'col'=>'var(--mb-gold)'],
    ['label'=>'Variable','rate'=>5.1,'col'=>'var(--mb-sage)'],
];
$chart_max = 6.0;

/* ── Services ───────────────────────────────────────────── */
$services = [
    ['icon'=>'🏠','title'=>'First-Time Buyers','desc'=>'Expert guidance through the entire purchase process — from Agreement in Principle to completion — with access to 90+ lenders.'],
    ['icon'=>'🔄','title'=>'Remortgage','desc'=>'Avoid your lender\'s Standard Variable Rate. We search the whole market to secure you the best available deal before your fix expires.'],
    ['icon'=>'🏗️','title'=>'Buy-to-Let','desc'=>'Portfolio landlord or first investment property — we source the most competitive BTL rates and structure your portfolio tax-efficiently.'],
    ['icon'=>'🏢','title'=>'Commercial Finance','desc'=>'Business mortgages, bridging finance, development loans and commercial investment mortgages from specialist lenders.'],
    ['icon'=>'💼','title'=>'Self-Employed','desc'=>'Complex income structures, multiple trading entities and newly self-employed — we know which lenders consider SA302s favourably.'],
    ['icon'=>'⚡','title'=>'Adverse Credit','desc'=>'CCJs, defaults or missed payments? We access specialist lenders who consider applications others can\'t place.'],
    ['icon'=>'🌿','title'=>'Green Mortgages','desc'=>'Energy-efficient properties can unlock preferential rates. We identify every green mortgage incentive you may qualify for.'],
    ['icon'=>'🛡️','title'=>'Protection','desc'=>'Life insurance, critical illness cover, income protection and buildings & contents insurance — comprehensive, independent advice.'],
];

/* ── Mortgage types cloud ───────────────────────────────── */
$mortgage_types = [
    'Fixed Rate','Tracker','Offset','Interest Only','Help to Buy',
    'Shared Ownership','Right to Buy','Guarantor','Joint Borrower Sole Proprietor',
    'New Build','Green Mortgage','Self-Build','Holiday Let','HMO','Limited Company BTL',
    'Expat Mortgage','Foreign National','Later Life Lending','Equity Release','Bridging Loan',
];

/* ── Steps ──────────────────────────────────────────────── */
$steps = [
    ['num'=>'01','title'=>'Discovery Call','desc'=>'A free 30-minute consultation to understand your goals, assess affordability and outline the most suitable mortgage strategy.'],
    ['num'=>'02','title'=>'Market Search','desc'=>'We search over 90 lenders — including exclusive deals unavailable on the high street — to find your optimal rate.'],
    ['num'=>'03','title'=>'AIP Secured','desc'=>'Your Agreement in Principle is obtained quickly and cleanly, protecting your credit file with a soft search.'],
    ['num'=>'04','title'=>'Application Submitted','desc'=>'We prepare a compelling application, manage the paperwork and liaise directly with the lender on your behalf.'],
    ['num'=>'05','title'=>'Offer & Completion','desc'=>'We manage the process through to mortgage offer and coordinate with solicitors to ensure a smooth completion.'],
];

/* ── Gallery ────────────────────────────────────────────── */
$gallery = [
    ['label'=>'Consultation Suite','color'=>'linear-gradient(135deg,#0a2342,#1B4F8A)','icon'=>'🤝'],
    ['label'=>'Market Analysis','color'=>'linear-gradient(135deg,#0a2a1a,#3D8B6E)','icon'=>'📊'],
    ['label'=>'Document Processing','color'=>'linear-gradient(135deg,#1a1a0a,#c8962a)','icon'=>'📋'],
    ['label'=>'Rate Dashboard','color'=>'linear-gradient(135deg,#0a1a2a,#1B4F8A)','icon'=>'📈'],
    ['label'=>'Legal Completion','color'=>'linear-gradient(135deg,#0a2a1a,#3D8B6E)','icon'=>'⚖️'],
    ['label'=>'Client Onboarding','color'=>'linear-gradient(135deg,#1a0a2a,#3a1a6a)','icon'=>'🏡'],
];

/* ── Counters ───────────────────────────────────────────── */
$counters = [
    ['val'=>90,'suffix'=>'+','label'=>'Lenders on Panel','float'=>0],
    ['val'=>450,'suffix'=>'M+','label'=>'Mortgages Arranged','float'=>0],
    ['val'=>4.9,'suffix'=>'★','label'=>'Client Rating','float'=>1],
    ['val'=>98,'suffix'=>'%','label'=>'Offer Success Rate','float'=>0],
];

/* ── Packages ───────────────────────────────────────────── */
$packages = [
    ['name'=>'Residential','price'=>'£0','per'=>'broker fee (most cases)','featured'=>false,
     'features'=>['Whole-of-market search','First-time buyer expertise','Remortgage specialist','AIP in 24 hours','Full application management','Ongoing rate review alerts']],
    ['name'=>'Complex Cases','price'=>'£495','per'=>'broker fee (complex)','featured'=>true,
     'features'=>['Self-employed / contractor','Adverse credit history','Multiple income streams','Specialist lender access','Enhanced application support','Dedicated case manager','Priority processing']],
    ['name'=>'Buy-to-Let','price'=>'£295','per'=>'broker fee','featured'=>false,
     'features'=>['Portfolio landlord review','Stress-test calculations','Limited company BTL','HMO & MUB finance','Tax-efficient structuring','Annual portfolio health check']],
];

/* ── Testimonials ───────────────────────────────────────── */
$testimonials = [
    ['name'=>'Hannah & Tom W.','role'=>'First-Time Buyers, Bristol','rating'=>5,
     'text'=>'We were overwhelmed by the whole process but our adviser walked us through every step with patience and clarity. We secured a rate 0.6% lower than what our bank quoted. Couldn\'t be happier with the service.'],
    ['name'=>'David O.','role'=>'Portfolio Landlord, 9 Properties','rating'=>5,
     'text'=>'I\'ve been using this brokerage for six years across multiple purchases and remortgages. The commercial insight and lender relationships they bring to complex BTL structures are second to none.'],
    ['name'=>'Priya K.','role'=>'Self-Employed — 2 Years Trading','rating'=>5,
     'text'=>'My bank turned me down immediately because my income structure is non-standard. Within a week my broker had secured a competitive offer from a lender I\'d never heard of. Professional beyond expectation.'],
];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,400;0,700;1,300&family=Source+Sans+3:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════════
   MORTGAGE BROKER — CSS TOKENS  (--mb-*)
   ═══════════════════════════════════════════════════════════ */
:root {
  --mb-navy:     #0A2342;
  --mb-navy-lt:  #12335a;
  --mb-blue:     #1B4F8A;
  --mb-blue-lt:  #2d6ab5;
  --mb-gold:     #C8962A;
  --mb-gold-lt:  #e2ab38;
  --mb-gold-d:   #a07518;
  --mb-sage:     #3D8B6E;
  --mb-sage-d:   #2d6a53;
  --mb-pearl:    #F7F8FA;
  --mb-pearl-d:  #ECEEF2;
  --mb-text:     #1a2a3a;
  --mb-font-head:'Merriweather', serif;
  --mb-font-body:'Source Sans 3', sans-serif;
  --mb-radius:   10px;
  --mb-shadow:   0 6px 28px rgba(0,0,0,.09);
}

/* ── Reset & Base ───────────────────────────────────────── */
.mb-wrap *, .mb-wrap *::before, .mb-wrap *::after { box-sizing:border-box; margin:0; padding:0; }
.mb-wrap { font-family:var(--mb-font-body); color:var(--mb-text); background:var(--mb-pearl); line-height:1.7; }
.mb-container { max-width:1200px; margin:0 auto; padding:0 24px; }
.mb-section { padding:96px 0; }
.mb-section--navy  { background:var(--mb-navy); color:rgba(255,255,255,.9); }
.mb-section--pearl { background:var(--mb-pearl-d); }
.mb-section--sage  { background:linear-gradient(135deg,var(--mb-sage-d),var(--mb-sage)); color:#fff; }
.mb-tag { display:inline-block; background:rgba(200,150,42,.12); color:var(--mb-gold-d); font-size:.7rem; font-weight:700; letter-spacing:.12em; text-transform:uppercase; padding:4px 14px; border-radius:3px; margin-bottom:16px; }
.mb-tag--light { background:rgba(200,150,42,.2); color:var(--mb-gold-lt); }
.mb-h2 { font-family:var(--mb-font-head); font-size:clamp(1.5rem,3.2vw,2.4rem); line-height:1.25; font-weight:700; margin-bottom:12px; }
.mb-lead { font-size:1.05rem; opacity:.8; max-width:640px; }
.mb-btn { display:inline-block; padding:14px 36px; border-radius:var(--mb-radius); font-family:var(--mb-font-body); font-size:.95rem; font-weight:700; letter-spacing:.04em; text-decoration:none; cursor:pointer; border:none; transition:transform .2s,box-shadow .2s; }
.mb-btn--gold  { background:var(--mb-gold); color:#fff; box-shadow:0 4px 18px rgba(200,150,42,.4); }
.mb-btn--gold:hover  { transform:translateY(-2px); box-shadow:0 8px 28px rgba(200,150,42,.55); }
.mb-btn--navy  { background:var(--mb-navy); color:#fff; box-shadow:0 4px 18px rgba(10,35,66,.3); }
.mb-btn--navy:hover  { transform:translateY(-2px); box-shadow:0 8px 28px rgba(10,35,66,.45); }
.mb-btn--ghost { background:transparent; color:var(--mb-gold); border:2px solid var(--mb-gold); }
.mb-btn--ghost:hover { background:rgba(200,150,42,.08); transform:translateY(-2px); }

/* ═══════════════════════════════════════════════════════════
   HERO
   ═══════════════════════════════════════════════════════════ */
.mb-hero {
  position:relative; min-height:100vh;
  background:linear-gradient(155deg,#050f1e 0%,#0A2342 45%,#0d2a50 70%,#0e1f38 100%);
  overflow:hidden; display:flex; align-items:center;
}
/* Subtle grid */
.mb-hero::before {
  content:''; position:absolute; inset:0;
  background-image:
    linear-gradient(rgba(200,150,42,.03) 1px,transparent 1px),
    linear-gradient(90deg,rgba(200,150,42,.03) 1px,transparent 1px);
  background-size:80px 80px;
  pointer-events:none;
}

/* ── Floating particles ──────────────────────────────────── */
.mb-particle { position:absolute; pointer-events:none; animation:mb-drift var(--dur,10s) var(--del,0s) ease-in-out infinite alternate; }
@keyframes mb-drift {
  from { transform:translateY(0); opacity:.35; }
  to   { transform:translateY(-24px); opacity:.7; }
}

.mb-hero__inner { position:relative; z-index:2; display:grid; grid-template-columns:1fr 1fr; gap:60px; align-items:center; padding:120px 0 80px; }

/* ── City skyline scene ───────────────────────────────────── */
.mb-scene { display:flex; align-items:flex-end; justify-content:center; height:380px; position:relative; }

/* Ground / horizon glow */
.mb-scene::before {
  content:''; position:absolute; bottom:0; left:-20px; right:-20px; height:4px;
  background:linear-gradient(90deg,transparent,var(--mb-gold),transparent);
  box-shadow:0 0 30px rgba(200,150,42,.4);
}
.mb-scene::after {
  content:''; position:absolute; bottom:4px; left:-20px; right:-20px; height:40px;
  background:linear-gradient(180deg,rgba(200,150,42,.08),transparent);
}

/* Buildings */
.mb-bldg { position:relative; margin:0 2px; flex-shrink:0; border-radius:2px 2px 0 0; }
.mb-bldg__win { position:absolute; width:6px; height:8px; border-radius:1px; background:rgba(200,150,42,.6); }
.mb-bldg__win--dark { background:rgba(10,35,66,.8); border:1px solid rgba(255,255,255,.05); }

/* Rate chart overlay */
.mb-rate-card {
  position:absolute; bottom:20px; right:-10px;
  background:rgba(10,35,66,.9); border:1px solid rgba(200,150,42,.3);
  border-radius:10px; padding:16px; width:180px;
  box-shadow:0 8px 32px rgba(0,0,0,.4);
}
.mb-rate-card__title { color:var(--mb-gold); font-size:.65rem; font-weight:700; letter-spacing:.1em; text-transform:uppercase; margin-bottom:10px; font-family:var(--mb-font-body); }
.mb-rate-bar { display:flex; align-items:center; gap:6px; margin-bottom:6px; }
.mb-rate-bar__label { color:rgba(255,255,255,.7); font-size:.62rem; width:46px; flex-shrink:0; }
.mb-rate-bar__track { flex:1; height:6px; background:rgba(255,255,255,.08); border-radius:3px; overflow:hidden; }
.mb-rate-bar__fill  { height:100%; border-radius:3px; transition:width .3s; }
.mb-rate-bar__val   { color:#fff; font-size:.62rem; font-weight:700; width:28px; text-align:right; flex-shrink:0; }

/* House icon (property) */
.mb-house {
  position:absolute; bottom:20px; left:0;
  width:80px;
}
.mb-house__roof {
  width:0; height:0;
  border-left:40px solid transparent;
  border-right:40px solid transparent;
  border-bottom:30px solid var(--mb-gold);
}
.mb-house__walls {
  height:42px; background:linear-gradient(180deg,#fff,#edf0f4);
  border:2px solid rgba(200,150,42,.3);
  position:relative; display:flex; align-items:center; justify-content:center;
}
.mb-house__door {
  width:16px; height:26px; background:var(--mb-navy-lt);
  border-radius:2px 2px 0 0; position:absolute; bottom:0; left:50%; transform:translateX(-50%);
}
.mb-house__win {
  position:absolute; top:8px;
  width:14px; height:12px; background:rgba(200,150,42,.3);
  border:1px solid rgba(200,150,42,.4); border-radius:1px;
}
.mb-house__win--l { left:8px; }
.mb-house__win--r { right:8px; }

/* ── Hero content ─────────────────────────────────────────── */
.mb-hero__badge { display:inline-flex; align-items:center; gap:8px; background:rgba(200,150,42,.12); border:1px solid rgba(200,150,42,.3); color:var(--mb-gold-lt); padding:6px 18px; border-radius:6px; font-size:.75rem; font-weight:700; letter-spacing:.08em; text-transform:uppercase; margin-bottom:24px; }
.mb-hero__title { font-family:var(--mb-font-head); font-size:clamp(1.8rem,4.5vw,3.2rem); line-height:1.2; color:#fff; margin-bottom:16px; }
.mb-hero__title span { color:var(--mb-gold-lt); }
.mb-hero__sub { font-size:1.05rem; color:rgba(255,255,255,.75); margin-bottom:32px; line-height:1.8; }
.mb-hero__rate { background:rgba(200,150,42,.1); border:1px solid rgba(200,150,42,.25); border-radius:8px; padding:14px 20px; margin-bottom:32px; display:flex; align-items:center; gap:14px; }
.mb-hero__rate-val { font-family:var(--mb-font-head); font-size:1.8rem; color:var(--mb-gold-lt); font-weight:700; }
.mb-hero__rate-desc { font-size:.82rem; color:rgba(255,255,255,.7); line-height:1.4; }
.mb-hero__ctas { display:flex; gap:14px; flex-wrap:wrap; margin-bottom:36px; }
.mb-hero__trust { display:flex; gap:24px; flex-wrap:wrap; }
.mb-hero__trust-item { display:flex; align-items:center; gap:8px; color:rgba(255,255,255,.7); font-size:.85rem; }

/* ═══════════════════════════════════════════════════════════
   TRUST BAR
   ═══════════════════════════════════════════════════════════ */
.mb-trust-bar { background:var(--mb-gold); padding:18px 0; }
.mb-trust-bar__inner { display:flex; justify-content:space-around; flex-wrap:wrap; gap:16px; }
.mb-trust-bar__item { display:flex; align-items:center; gap:10px; color:rgba(255,255,255,.95); font-size:.9rem; font-weight:600; }
.mb-trust-bar__item span:first-child { font-size:1.2rem; }
.mb-trust-bar__item strong { color:#fff; }

/* ═══════════════════════════════════════════════════════════
   SERVICES
   ═══════════════════════════════════════════════════════════ */
.mb-services { text-align:center; }
.mb-services__intro { max-width:640px; margin:0 auto 56px; }
.mb-services__grid { display:grid; grid-template-columns:repeat(4,1fr); gap:20px; }
.mb-svc {
  background:#fff; border-radius:var(--mb-radius); padding:28px 18px; text-align:left;
  box-shadow:var(--mb-shadow); border:1px solid rgba(0,0,0,.05);
  border-bottom:3px solid var(--mb-gold);
  transition:transform .25s,box-shadow .25s;
}
.mb-svc:hover { transform:translateY(-6px); box-shadow:0 12px 36px rgba(10,35,66,.14); }
.mb-svc__icon { font-size:2rem; margin-bottom:14px; display:block; }
.mb-svc__title { font-family:var(--mb-font-head); font-size:.9rem; margin-bottom:8px; color:var(--mb-navy); }
.mb-svc__desc  { font-size:.85rem; line-height:1.65; color:#555; }

/* ═══════════════════════════════════════════════════════════
   MORTGAGE TYPES CLOUD
   ═══════════════════════════════════════════════════════════ */
.mb-types { text-align:center; }
.mb-types__intro { max-width:600px; margin:0 auto 48px; }
.mb-types__cloud { display:flex; flex-wrap:wrap; justify-content:center; gap:10px; }
.mb-type-tag {
  display:inline-block; padding:8px 18px; border-radius:6px;
  background:rgba(27,79,138,.08); color:var(--mb-blue); font-size:.85rem; font-weight:600;
  border:1px solid rgba(27,79,138,.15); cursor:default;
  transition:background .2s,color .2s;
}
.mb-type-tag:hover { background:var(--mb-blue); color:#fff; }

/* ═══════════════════════════════════════════════════════════
   ABOUT
   ═══════════════════════════════════════════════════════════ */
.mb-about { }
.mb-about__grid { display:grid; grid-template-columns:1fr 1fr; gap:80px; align-items:center; }
.mb-about__visual { display:flex; flex-direction:column; gap:20px; align-items:center; }

/* Adviser credential card */
.mb-adviser-card {
  width:300px; background:var(--mb-navy); border-radius:14px; overflow:hidden;
  box-shadow:0 12px 48px rgba(0,0,0,.2); border:1px solid rgba(200,150,42,.2);
}
.mb-adviser-card__header {
  background:linear-gradient(135deg,var(--mb-navy-lt),var(--mb-navy));
  padding:28px 20px 20px; text-align:center;
  border-bottom:2px solid var(--mb-gold);
}
/* CSS adviser figure */
.mb-adv-fig { display:flex; flex-direction:column; align-items:center; margin-bottom:10px; }
.mb-adv-fig__head { width:52px; height:52px; border-radius:50%; background:radial-gradient(circle at 40% 35%,#d4b896,#c19a6b); border:3px solid rgba(200,150,42,.4); position:relative; }
.mb-adv-fig__head::before { content:''; position:absolute; top:-8px; left:5px; right:5px; height:12px; background:linear-gradient(180deg,#2c1a0a,#4a3020); border-radius:50% 50% 0 0; }
.mb-adv-fig__body { width:66px; height:56px; background:linear-gradient(180deg,#1a2d4a,#0a2342); border-radius:4px 4px 0 0; position:relative; }
.mb-adv-fig__body::before { content:''; position:absolute; top:6px; left:50%; transform:translateX(-50%); width:2px; height:36px; background:rgba(200,150,42,.4); }
.mb-adv-fig__body::after  { content:'£'; position:absolute; top:10px; right:10px; font-size:.85rem; color:rgba(200,150,42,.6); }
.mb-adviser-card__header h3 { color:#fff; font-family:var(--mb-font-head); font-size:1rem; margin-bottom:2px; }
.mb-adviser-card__header p  { color:rgba(255,255,255,.65); font-size:.78rem; }
.mb-adviser-card__body { padding:16px 20px; }
.mb-adviser-card__row { display:flex; justify-content:space-between; padding:7px 0; border-bottom:1px solid rgba(255,255,255,.06); font-size:.82rem; }
.mb-adviser-card__row:last-child { border-bottom:none; }
.mb-adviser-card__row span:first-child { color:rgba(255,255,255,.55); }
.mb-adviser-card__row span:last-child  { color:var(--mb-gold-lt); font-weight:700; }

.mb-accreditations { display:flex; flex-wrap:wrap; gap:10px; justify-content:center; }
.mb-accred { background:rgba(27,79,138,.08); border:1px solid rgba(27,79,138,.2); color:var(--mb-blue); border-radius:6px; padding:6px 12px; font-size:.72rem; font-weight:700; letter-spacing:.04em; }

.mb-about__text .mb-h2 { color:var(--mb-navy); }
.mb-about__text p { color:#444; margin-bottom:16px; line-height:1.8; }
.mb-about__feats { list-style:none; margin:20px 0 32px; display:flex; flex-direction:column; gap:10px; }
.mb-about__feats li { display:flex; align-items:center; gap:10px; font-size:.9rem; color:#333; }
.mb-about__feats li::before { content:'✦'; color:var(--mb-gold); flex-shrink:0; }

/* ═══════════════════════════════════════════════════════════
   APPROACH / PROCESS
   ═══════════════════════════════════════════════════════════ */
.mb-approach { background:var(--mb-navy); }
.mb-approach__intro { text-align:center; max-width:640px; margin:0 auto 56px; }
.mb-approach__grid {
  display:grid; grid-template-columns:repeat(5,1fr); gap:0; position:relative;
}
.mb-approach__grid::before {
  content:''; position:absolute; top:38px; left:10%; right:10%; height:2px;
  background:linear-gradient(90deg,var(--mb-gold),var(--mb-sage),var(--mb-gold));
  z-index:0;
}
.mb-step { text-align:center; padding:0 10px; position:relative; z-index:1; }
.mb-step__num { width:44px; height:44px; border-radius:50%; background:var(--mb-gold); color:var(--mb-navy); font-family:var(--mb-font-head); font-size:.8rem; font-weight:700; display:inline-flex; align-items:center; justify-content:center; margin-bottom:18px; box-shadow:0 4px 14px rgba(200,150,42,.4); }
.mb-step__title { font-family:var(--mb-font-head); font-size:.85rem; color:#fff; margin-bottom:8px; }
.mb-step__desc  { font-size:.82rem; color:rgba(255,255,255,.65); line-height:1.6; }

/* ═══════════════════════════════════════════════════════════
   GALLERY
   ═══════════════════════════════════════════════════════════ */
.mb-gallery__grid { display:grid; grid-template-columns:repeat(3,1fr); grid-template-rows:220px 220px; gap:12px; }
.mb-gallery__item { border-radius:var(--mb-radius); overflow:hidden; position:relative; cursor:pointer; }
.mb-gallery__item:nth-child(1) { grid-column:span 2; }
.mb-gallery__item:nth-child(4) { grid-column:span 2; }
.mb-gallery__panel { width:100%; height:100%; display:flex; align-items:center; justify-content:center; font-size:3rem; transition:transform .4s; }
.mb-gallery__item:hover .mb-gallery__panel { transform:scale(1.04); }
.mb-gallery__overlay { position:absolute; inset:0; display:flex; align-items:flex-end; background:linear-gradient(to top,rgba(0,0,0,.65) 0%,transparent 50%); padding:20px; opacity:0; transition:opacity .3s; }
.mb-gallery__item:hover .mb-gallery__overlay { opacity:1; }
.mb-gallery__overlay span { color:#fff; font-size:.9rem; font-weight:600; }

/* ═══════════════════════════════════════════════════════════
   COUNTERS
   ═══════════════════════════════════════════════════════════ */
.mb-counters { background:linear-gradient(135deg,var(--mb-navy-lt),var(--mb-navy)); text-align:center; }
.mb-counters__grid { display:grid; grid-template-columns:repeat(4,1fr); gap:40px; }
.mb-counter__val { font-family:var(--mb-font-head); font-size:clamp(2rem,4vw,3.2rem); color:var(--mb-gold-lt); display:block; line-height:1; }
.mb-counter__label { font-size:.85rem; color:rgba(255,255,255,.7); margin-top:8px; }

/* ═══════════════════════════════════════════════════════════
   PACKAGES
   ═══════════════════════════════════════════════════════════ */
.mb-packages { text-align:center; background:var(--mb-pearl-d); }
.mb-packages__intro { max-width:600px; margin:0 auto 56px; }
.mb-packages__grid { display:grid; grid-template-columns:repeat(3,1fr); gap:24px; align-items:start; }
.mb-pkg { border-radius:var(--mb-radius); padding:36px 28px; text-align:left; background:#fff; box-shadow:var(--mb-shadow); border:2px solid transparent; transition:transform .25s,box-shadow .25s; }
.mb-pkg:hover { transform:translateY(-6px); box-shadow:0 14px 48px rgba(10,35,66,.14); }
.mb-pkg--featured { border-color:var(--mb-gold); box-shadow:0 8px 40px rgba(200,150,42,.2); background:var(--mb-navy); color:rgba(255,255,255,.9); transform:translateY(-8px); }
.mb-pkg--featured:hover { transform:translateY(-14px); }
.mb-pkg__badge { display:inline-block; background:var(--mb-gold); color:#fff; font-size:.7rem; font-weight:700; letter-spacing:.1em; text-transform:uppercase; padding:3px 12px; border-radius:4px; margin-bottom:12px; }
.mb-pkg__name { font-family:var(--mb-font-head); font-size:1rem; margin-bottom:4px; }
.mb-pkg--featured .mb-pkg__name { color:#fff; }
.mb-pkg__price { font-size:2.2rem; font-weight:700; font-family:var(--mb-font-head); margin:14px 0 4px; }
.mb-pkg--featured .mb-pkg__price { color:var(--mb-gold-lt); }
.mb-pkg__per { font-size:.8rem; opacity:.65; margin-bottom:24px; }
.mb-pkg__features { list-style:none; margin-bottom:28px; display:flex; flex-direction:column; gap:10px; }
.mb-pkg__features li { display:flex; align-items:center; gap:8px; font-size:.88rem; }
.mb-pkg__features li::before { content:'✦'; color:var(--mb-gold); flex-shrink:0; }
.mb-pkg--featured .mb-pkg__features li { color:rgba(255,255,255,.85); }
.mb-pkg .mb-btn { width:100%; text-align:center; }

/* ═══════════════════════════════════════════════════════════
   TESTIMONIALS
   ═══════════════════════════════════════════════════════════ */
.mb-testimonials { }
.mb-testimonials__intro { text-align:center; max-width:600px; margin:0 auto 56px; }
.mb-testimonials__grid { display:grid; grid-template-columns:repeat(3,1fr); gap:24px; }
.mb-testi { background:#fff; border-radius:var(--mb-radius); padding:28px 24px; box-shadow:var(--mb-shadow); border-top:4px solid var(--mb-gold); position:relative; }
.mb-testi::before { content:'❝'; position:absolute; top:16px; right:20px; font-size:3rem; color:rgba(10,35,66,.08); font-family:serif; line-height:1; }
.mb-testi__stars { color:#f5a623; margin-bottom:14px; }
.mb-testi__text { font-size:.9rem; line-height:1.75; color:#444; margin-bottom:18px; font-style:italic; }
.mb-testi__name { font-weight:700; color:var(--mb-navy); font-size:.9rem; font-family:var(--mb-font-head); }
.mb-testi__role { font-size:.8rem; color:#888; }

/* ═══════════════════════════════════════════════════════════
   DISCLAIMER
   ═══════════════════════════════════════════════════════════ */
.mb-disclaimer { background:var(--mb-pearl-d); padding:24px 0; border-top:1px solid rgba(0,0,0,.06); }
.mb-disclaimer p { font-size:.78rem; color:#777; line-height:1.6; max-width:900px; margin:0 auto; text-align:center; }

/* ═══════════════════════════════════════════════════════════
   BOOKING FORM
   ═══════════════════════════════════════════════════════════ */
.mb-booking { background:var(--mb-navy); }
.mb-booking__inner { display:grid; grid-template-columns:1fr 1fr; gap:80px; align-items:start; }
.mb-booking__info h2 { color:#fff; margin-bottom:16px; }
.mb-booking__info p  { color:rgba(255,255,255,.7); margin-bottom:28px; line-height:1.8; }
.mb-booking__list { list-style:none; display:flex; flex-direction:column; gap:12px; }
.mb-booking__list li { display:flex; align-items:center; gap:10px; color:rgba(255,255,255,.8); font-size:.9rem; }
.mb-booking__list li span:first-child { width:30px; height:30px; background:rgba(200,150,42,.15); border:1px solid rgba(200,150,42,.3); border-radius:50%; display:inline-flex; align-items:center; justify-content:center; flex-shrink:0; }
.mb-form { background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08); border-radius:12px; padding:36px; }
.mb-form__row { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
.mb-form__group { margin-bottom:14px; }
.mb-form__group label { display:block; font-size:.8rem; font-weight:700; color:rgba(255,255,255,.65); margin-bottom:6px; letter-spacing:.06em; text-transform:uppercase; }
.mb-form__group input,
.mb-form__group select,
.mb-form__group textarea {
  width:100%; padding:11px 14px; border-radius:8px;
  border:1px solid rgba(255,255,255,.1); background:rgba(255,255,255,.05);
  color:#fff; font-family:var(--mb-font-body); font-size:.9rem;
  transition:border-color .2s;
}
.mb-form__group input::placeholder,
.mb-form__group textarea::placeholder { color:rgba(255,255,255,.3); }
.mb-form__group input:focus,
.mb-form__group select:focus,
.mb-form__group textarea:focus { outline:none; border-color:var(--mb-gold); }
.mb-form__group select option { background:#0a2342; }
.mb-form__group textarea { resize:vertical; min-height:90px; }
.mb-form__submit { width:100%; padding:15px; background:linear-gradient(135deg,var(--mb-gold),var(--mb-gold-d)); color:#fff; font-family:var(--mb-font-body); font-size:1rem; font-weight:700; border:none; border-radius:10px; cursor:pointer; transition:transform .2s,box-shadow .2s; margin-top:8px; }
.mb-form__submit:hover { transform:translateY(-2px); box-shadow:0 8px 24px rgba(200,150,42,.45); }

/* ═══════════════════════════════════════════════════════════
   FOOTER
   ═══════════════════════════════════════════════════════════ */
.mb-footer { background:var(--mb-navy-lt); padding:28px 0; text-align:center; border-top:1px solid rgba(255,255,255,.05); }
.mb-footer p { color:rgba(255,255,255,.5); font-size:.85rem; }

/* ═══════════════════════════════════════════════════════════
   RESPONSIVE
   ═══════════════════════════════════════════════════════════ */
@media(max-width:1024px){
  .mb-hero__inner { grid-template-columns:1fr; gap:40px; padding:100px 0 60px; }
  .mb-scene { height:280px; }
  .mb-services__grid { grid-template-columns:repeat(2,1fr); }
  .mb-about__grid { grid-template-columns:1fr; }
  .mb-approach__grid { grid-template-columns:repeat(3,1fr); }
  .mb-approach__grid::before { display:none; }
  .mb-counters__grid { grid-template-columns:repeat(2,1fr); }
  .mb-packages__grid { grid-template-columns:1fr; }
  .mb-testimonials__grid { grid-template-columns:1fr; }
  .mb-booking__inner { grid-template-columns:1fr; }
}
@media(max-width:640px){
  .mb-section { padding:64px 0; }
  .mb-services__grid { grid-template-columns:1fr; }
  .mb-approach__grid { grid-template-columns:1fr 1fr; }
  .mb-gallery__grid { grid-template-columns:1fr 1fr; grid-template-rows:auto; }
  .mb-gallery__item:nth-child(1),
  .mb-gallery__item:nth-child(4) { grid-column:span 1; }
  .mb-counters__grid { grid-template-columns:1fr 1fr; }
  .mb-form__row { grid-template-columns:1fr; }
  .mb-hero__ctas { flex-direction:column; }
}
</style>
<?php get_header(); ?>
<div class="mb-page">
>
<?php wp_body_open(); ?>
<div class="mb-wrap">

<!-- ═══════════════ HERO ═══════════════ -->
<section class="mb-hero" aria-label="Mortgage broker hero">

  <!-- Floating particles -->
  <?php foreach ($particles as $p): ?>
  <div class="mb-particle" aria-hidden="true" style="
    top:<?= $p['top'] ?>%; left:<?= $p['left'] ?>%;
    font-size:<?= $p['size'] ?>px; color:<?= esc_attr($p['col']) ?>;
    --dur:<?= $p['dur'] ?>s; --del:<?= $p['del'] ?>s;
  "><?= esc_html($p['sym']) ?></div>
  <?php endforeach; ?>

  <div class="mb-container">
    <div class="mb-hero__inner">

      <!-- Content -->
      <div class="mb-hero__content">
        <div class="mb-hero__badge"><span>🏅</span> FCA Authorised Mortgage Broker</div>
        <h1 class="mb-hero__title">
          Your Mortgage.<br>
          <span>Our Expertise.</span><br>
          The Best Deal.
        </h1>
        <p class="mb-hero__sub">
          Whole-of-market mortgage advice from FCA-authorised specialists. First-time buyers, remortgages, buy-to-let, self-employed and complex cases welcome. No broker fee on most residential mortgages.
        </p>
        <div class="mb-hero__rate" aria-label="Current indicative mortgage rate">
          <div class="mb-hero__rate-val">4.2%</div>
          <div class="mb-hero__rate-desc">Indicative 2-year fixed rate<br><small style="opacity:.7">Best available rate as at <?php echo esc_html(date('F Y')); ?> — subject to criteria</small></div>
        </div>
        <div class="mb-hero__ctas">
          <a href="#booking" class="mb-btn mb-btn--gold">Get Free Advice</a>
          <a href="#services" class="mb-btn mb-btn--ghost">Explore Services</a>
        </div>
        <div class="mb-hero__trust">
          <div class="mb-hero__trust-item"><span>🛡️</span><span>FCA Authorised</span></div>
          <div class="mb-hero__trust-item"><span>🏦</span><span>90+ Lenders</span></div>
          <div class="mb-hero__trust-item"><span>£0</span><span>Broker Fee*</span></div>
        </div>
      </div>

      <!-- Scene: City skyline with rate chart -->
      <div class="mb-scene" aria-hidden="true">

        <!-- Property / house -->
        <div class="mb-house">
          <div class="mb-house__roof"></div>
          <div class="mb-house__walls">
            <div class="mb-house__win mb-house__win--l"></div>
            <div class="mb-house__win mb-house__win--r"></div>
            <div class="mb-house__door"></div>
          </div>
        </div>

        <!-- City buildings -->
        <?php foreach ($buildings as $b): ?>
        <div class="mb-bldg" style="width:<?= $b['w'] ?>px;height:<?= $b['h'] ?>px;background:<?= esc_attr($b['col']) ?>;" aria-hidden="true">
          <?php
          $win_cols = max(2, floor($b['w'] / 16));
          $win_rows = max(2, floor($b['h'] / 24));
          for ($wr = 0; $wr < min($win_rows, 8); $wr++) {
            for ($wc = 0; $wc < min($win_cols, 4); $wc++) {
              $lit = rand(0,1);
              $wx = 6 + $wc * 13;
              $wy = 8 + $wr * 22;
              echo '<div class="mb-bldg__win' . ($lit ? '' : ' mb-bldg__win--dark') . '" style="left:' . $wx . 'px;top:' . $wy . 'px;"></div>';
            }
          }
          ?>
        </div>
        <?php endforeach; ?>

        <!-- Rate card overlay -->
        <div class="mb-rate-card" role="img" aria-label="Live mortgage rate comparison chart">
          <div class="mb-rate-card__title">Current Rates</div>
          <?php foreach ($chart_bars as $bar): ?>
          <div class="mb-rate-bar">
            <span class="mb-rate-bar__label"><?= esc_html($bar['label']) ?></span>
            <div class="mb-rate-bar__track">
              <div class="mb-rate-bar__fill" style="width:<?= round(($bar['rate'] / $chart_max) * 100) ?>%;background:<?= esc_attr($bar['col']) ?>;"></div>
            </div>
            <span class="mb-rate-bar__val"><?= $bar['rate'] ?>%</span>
          </div>
          <?php endforeach; ?>
        </div>

      </div>

    </div>
  </div>
</section>

<!-- ═══════════════ TRUST BAR ═══════════════ -->
<div class="mb-trust-bar" aria-label="Credentials and trust indicators">
  <div class="mb-container">
    <div class="mb-trust-bar__inner">
      <div class="mb-trust-bar__item"><span>🏅</span><span>FCA Reference <strong>#123456</strong></span></div>
      <div class="mb-trust-bar__item"><span>🏦</span><span><strong>90+</strong> Lenders on Panel</span></div>
      <div class="mb-trust-bar__item"><span>⭐</span><span><strong>4.9/5</strong> — Trustpilot &amp; Google</span></div>
      <div class="mb-trust-bar__item"><span>📋</span><span><strong>Free</strong> Initial Consultation</span></div>
    </div>
  </div>
</div>

<!-- ═══════════════ SERVICES ═══════════════ -->
<section class="mb-section mb-services" id="services" aria-labelledby="mb-svc-heading">
  <div class="mb-container">
    <div class="mb-services__intro">
      <span class="mb-tag">Our Expertise</span>
      <h2 class="mb-h2" id="mb-svc-heading">Mortgage &amp; Protection Services</h2>
      <p class="mb-lead" style="margin:0 auto;">From straightforward first purchase to complex multi-property portfolios — whole-of-market advice tailored to your exact circumstances.</p>
    </div>
    <div class="mb-services__grid">
      <?php foreach ($services as $svc): ?>
      <article class="mb-svc" role="listitem">
        <span class="mb-svc__icon" aria-hidden="true"><?= $svc['icon'] ?></span>
        <h3 class="mb-svc__title"><?= esc_html($svc['title']) ?></h3>
        <p class="mb-svc__desc"><?= esc_html($svc['desc']) ?></p>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ MORTGAGE TYPES ═══════════════ -->
<section class="mb-section mb-section--pearl mb-types" aria-labelledby="mb-types-heading">
  <div class="mb-container">
    <div class="mb-types__intro">
      <span class="mb-tag">Product Range</span>
      <h2 class="mb-h2" id="mb-types-heading">Every Type of Mortgage</h2>
      <p class="mb-lead" style="margin:0 auto;">Our advisers are qualified across the full spectrum of mortgage products — standard residential to highly specialist finance.</p>
    </div>
    <div class="mb-types__cloud" role="list">
      <?php foreach ($mortgage_types as $mt): ?>
      <span class="mb-type-tag" role="listitem"><?= esc_html($mt) ?></span>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ ABOUT ═══════════════ -->
<section class="mb-section mb-about" id="about" aria-labelledby="mb-about-heading">
  <div class="mb-container">
    <div class="mb-about__grid">
      <div class="mb-about__visual">
        <div class="mb-adviser-card" role="img" aria-label="Adviser credential card for Sarah J. Hamilton CeMAP">
          <div class="mb-adviser-card__header">
            <div class="mb-adv-fig" aria-hidden="true">
              <div class="mb-adv-fig__head"></div>
              <div class="mb-adv-fig__body"></div>
            </div>
            <h3>Sarah J. Hamilton CeMAP</h3>
            <p>Senior Mortgage Adviser &amp; Director</p>
          </div>
          <div class="mb-adviser-card__body">
            <div class="mb-adviser-card__row"><span>Qualification</span><span>CeMAP (LIBF)</span></div>
            <div class="mb-adviser-card__row"><span>FCA Reference</span><span>#123456</span></div>
            <div class="mb-adviser-card__row"><span>Specialism</span><span>Complex &amp; BTL</span></div>
            <div class="mb-adviser-card__row"><span>Lender Panel</span><span>90+ Lenders</span></div>
            <div class="mb-adviser-card__row"><span>Experience</span><span>16 Years</span></div>
          </div>
        </div>
        <div class="mb-accreditations">
          <div class="mb-accred">CeMAP Qualified</div>
          <div class="mb-accred">FCA Authorised</div>
          <div class="mb-accred">Trustpilot 4.9★</div>
          <div class="mb-accred">Which? Endorsed</div>
        </div>
      </div>

      <div class="mb-about__text">
        <span class="mb-tag">About Us</span>
        <h2 class="mb-h2" id="mb-about-heading">Independent Advice You Can Trust</h2>
        <p>Hamilton Mortgages was founded in 2008 with a clear mandate: provide genuinely independent, whole-of-market mortgage advice that puts clients first. Our team of CeMAP-qualified advisers collectively hold over 50 years of experience and have arranged more than £450 million of mortgage lending.</p>
        <p>We are directly authorised by the FCA and work with over 90 lenders — including exclusive products unavailable on comparison sites or high streets. Our advice is truly independent: we are not tied to any lender and our recommendations are driven solely by your best interests.</p>
        <ul class="mb-about__feats" aria-label="Company credentials">
          <li>Directly FCA-authorised (not appointed representative)</li>
          <li>Whole-of-market — 90+ lenders including exclusive deals</li>
          <li>£450M+ arranged since 2008</li>
          <li>98% mortgage offer success rate</li>
          <li>No broker fee on most residential mortgages</li>
          <li>Fully advised service — not just an execution-only platform</li>
        </ul>
        <a href="#booking" class="mb-btn mb-btn--gold">Book Free Consultation</a>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════ APPROACH ═══════════════ -->
<section class="mb-section mb-approach" aria-labelledby="mb-approach-heading">
  <div class="mb-container">
    <div class="mb-approach__intro">
      <span class="mb-tag mb-tag--light">The Process</span>
      <h2 class="mb-h2" id="mb-approach-heading" style="color:#fff;">How We Secure Your Mortgage</h2>
      <p class="mb-lead" style="color:rgba(255,255,255,.7);margin:0 auto;">A clear, managed process from first contact to key collection — with a dedicated adviser beside you at every step.</p>
    </div>
    <div class="mb-approach__grid" role="list">
      <?php foreach ($steps as $step): ?>
      <div class="mb-step" role="listitem">
        <div class="mb-step__num" aria-hidden="true"><?= esc_html($step['num']) ?></div>
        <h3 class="mb-step__title"><?= esc_html($step['title']) ?></h3>
        <p class="mb-step__desc"><?= esc_html($step['desc']) ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ GALLERY ═══════════════ -->
<section class="mb-section mb-section--pearl" aria-labelledby="mb-gallery-heading">
  <div class="mb-container">
    <div style="text-align:center;margin-bottom:48px;">
      <span class="mb-tag">Our Process</span>
      <h2 class="mb-h2" id="mb-gallery-heading">Inside Our Practice</h2>
    </div>
    <div class="mb-gallery__grid" role="list">
      <?php foreach ($gallery as $panel): ?>
      <div class="mb-gallery__item" role="listitem">
        <div class="mb-gallery__panel" style="background:<?= esc_attr($panel['color']) ?>;" aria-label="<?= esc_attr($panel['label']) ?>">
          <span aria-hidden="true" style="font-size:3.5rem;"><?= $panel['icon'] ?></span>
        </div>
        <div class="mb-gallery__overlay" aria-hidden="true">
          <span><?= esc_html($panel['label']) ?></span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ COUNTERS ═══════════════ -->
<section class="mb-section mb-counters" aria-labelledby="mb-counters-heading">
  <div class="mb-container">
    <h2 class="sr-only" id="mb-counters-heading">Business statistics</h2>
    <div class="mb-counters__grid">
      <?php foreach ($counters as $c): ?>
      <div>
        <span class="mb-counter__val"
              data-target="<?= esc_attr($c['val']) ?>"
              data-suffix="<?= esc_attr($c['suffix']) ?>"
              <?= $c['float'] ? 'data-float="1"' : '' ?>
              aria-label="<?= esc_attr($c['val'] . $c['suffix'] . ' — ' . $c['label']) ?>">0</span>
        <p class="mb-counter__label"><?= esc_html($c['label']) ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ PACKAGES ═══════════════ -->
<section class="mb-section mb-packages" id="packages" aria-labelledby="mb-pkg-heading">
  <div class="mb-container">
    <div class="mb-packages__intro">
      <span class="mb-tag">Fee Structure</span>
      <h2 class="mb-h2" id="mb-pkg-heading">Transparent, Fair Pricing</h2>
      <p class="mb-lead" style="margin:0 auto;">We charge zero broker fee on most standard residential mortgages. A fee applies only for complex cases requiring significant additional work.</p>
    </div>
    <div class="mb-packages__grid">
      <?php foreach ($packages as $pkg): ?>
      <div class="mb-pkg <?= $pkg['featured'] ? 'mb-pkg--featured' : '' ?>">
        <?php if ($pkg['featured']): ?><div class="mb-pkg__badge">Most Requested</div><?php endif; ?>
        <h3 class="mb-pkg__name"><?= esc_html($pkg['name']) ?></h3>
        <div class="mb-pkg__price"><?= esc_html($pkg['price']) ?></div>
        <div class="mb-pkg__per"><?= esc_html($pkg['per']) ?></div>
        <ul class="mb-pkg__features" aria-label="<?= esc_attr($pkg['name']) ?> features">
          <?php foreach ($pkg['features'] as $f): ?>
          <li><?= esc_html($f) ?></li>
          <?php endforeach; ?>
        </ul>
        <a href="#booking" class="mb-btn <?= $pkg['featured'] ? 'mb-btn--gold' : 'mb-btn--navy' ?>">
          Book Consultation
        </a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ TESTIMONIALS ═══════════════ -->
<section class="mb-section mb-testimonials" aria-labelledby="mb-testi-heading">
  <div class="mb-container">
    <div class="mb-testimonials__intro">
      <span class="mb-tag">Client Reviews</span>
      <h2 class="mb-h2" id="mb-testi-heading">What Our Clients Say</h2>
      <p class="mb-lead" style="margin:0 auto;">Rated 4.9/5 on Trustpilot from over 800 verified reviews. Here are three recent stories from clients whose mortgages we were proud to arrange.</p>
    </div>
    <div class="mb-testimonials__grid">
      <?php foreach ($testimonials as $t): ?>
      <blockquote class="mb-testi">
        <div class="mb-testi__stars" aria-label="<?= esc_attr($t['rating']) ?> stars"><?= str_repeat('★',$t['rating']) ?></div>
        <p class="mb-testi__text"><?= esc_html($t['text']) ?></p>
        <footer>
          <div class="mb-testi__name"><?= esc_html($t['name']) ?></div>
          <div class="mb-testi__role"><?= esc_html($t['role']) ?></div>
        </footer>
      </blockquote>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ BOOKING ═══════════════ -->
<section class="mb-section mb-booking" id="booking" aria-labelledby="mb-booking-heading">
  <div class="mb-container">
    <div class="mb-booking__inner">
      <div class="mb-booking__info">
        <span class="mb-tag mb-tag--light">Get Started</span>
        <h2 class="mb-h2" id="mb-booking-heading">Book Your Free Consultation</h2>
        <p>A no-obligation 30-minute consultation by phone, video or in our office. We'll assess your situation, outline the most suitable strategy and give you a clear picture of what you can borrow — completely free and without commitment.</p>
        <ul class="mb-booking__list" aria-label="Consultation benefits">
          <li><span>📞</span><span>Phone, video or in-office — your choice</span></li>
          <li><span>🆓</span><span>Free with no obligation to proceed</span></li>
          <li><span>⚡</span><span>Agreement in Principle often same day</span></li>
          <li><span>🔒</span><span>Soft credit search — no impact on your score</span></li>
          <li><span>🌐</span><span>Evening and weekend appointments available</span></li>
        </ul>
      </div>
      <div class="mb-form">
        <?php
          if (!empty($_POST['tf_mb_nonce']) && wp_verify_nonce($_POST['tf_mb_nonce'],'tf_mb_booking')) {
            echo '<p style="color:var(--mb-gold-lt);font-weight:700;margin-bottom:16px;">✦ Thank you — your adviser will be in touch within two hours!</p>';
          }
        ?>
        <form method="post" action="<?php echo esc_url(get_permalink()); ?>#booking" novalidate>
          <?php wp_nonce_field('tf_mb_booking','tf_mb_nonce'); ?>
          <div class="mb-form__row">
            <div class="mb-form__group">
              <label for="mb_name">Full Name <span style="color:var(--mb-gold)">*</span></label>
              <input type="text" id="mb_name" name="mb_name" placeholder="Your full name" required autocomplete="name">
            </div>
            <div class="mb-form__group">
              <label for="mb_email">Email <span style="color:var(--mb-gold)">*</span></label>
              <input type="email" id="mb_email" name="mb_email" placeholder="you@example.com" required autocomplete="email">
            </div>
          </div>
          <div class="mb-form__row">
            <div class="mb-form__group">
              <label for="mb_phone">Phone</label>
              <input type="tel" id="mb_phone" name="mb_phone" placeholder="+44 7700 900000" autocomplete="tel">
            </div>
            <div class="mb-form__group">
              <label for="mb_type">Mortgage Type <span style="color:var(--mb-gold)">*</span></label>
              <select id="mb_type" name="mb_type" required>
                <option value="">Select type…</option>
                <option value="ftb">First-Time Buyer</option>
                <option value="remortgage">Remortgage</option>
                <option value="btl">Buy-to-Let</option>
                <option value="moving">Moving Home</option>
                <option value="self-employed">Self-Employed</option>
                <option value="adverse">Adverse Credit</option>
                <option value="commercial">Commercial</option>
                <option value="other">Other / Not Sure</option>
              </select>
            </div>
          </div>
          <div class="mb-form__row">
            <div class="mb-form__group">
              <label for="mb_amount">Mortgage Amount</label>
              <select id="mb_amount" name="mb_amount">
                <option value="">Prefer not to say</option>
                <option value="under-150k">Under £150,000</option>
                <option value="150-250k">£150,000 – £250,000</option>
                <option value="250-400k">£250,000 – £400,000</option>
                <option value="400-600k">£400,000 – £600,000</option>
                <option value="over-600k">Over £600,000</option>
              </select>
            </div>
            <div class="mb-form__group">
              <label for="mb_timeframe">Timeframe</label>
              <select id="mb_timeframe" name="mb_timeframe">
                <option value="">Select timeframe…</option>
                <option value="asap">As Soon as Possible</option>
                <option value="1-3months">1–3 Months</option>
                <option value="3-6months">3–6 Months</option>
                <option value="6-12months">6–12 Months</option>
                <option value="exploring">Just Exploring</option>
              </select>
            </div>
          </div>
          <div class="mb-form__group">
            <label for="mb_notes">Additional Information</label>
            <textarea id="mb_notes" name="mb_notes" placeholder="Tell us anything relevant — employment type, credit history, number of properties…"></textarea>
          </div>
          <button type="submit" class="mb-form__submit">✦ Book Free Consultation</button>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════ DISCLAIMER ═══════════════ -->
<div class="mb-disclaimer">
  <div class="mb-container">
    <p>Your home may be repossessed if you do not keep up repayments on your mortgage. Hamilton Mortgages Ltd is authorised and regulated by the Financial Conduct Authority (FCA Reference: 123456). Registered in England &amp; Wales. *No broker fee payable on standard residential mortgages where we receive a procuration fee from the lender. A fee is disclosed and agreed in advance for complex cases.</p>
  </div>
</div>

<!-- ═══════════════ FOOTER ═══════════════ -->
<footer class="mb-footer">
  <div class="mb-container">
    <p>&copy; <?php echo esc_html(date('Y')); ?> <?php bloginfo('name'); ?> &mdash; Hamilton Mortgages Ltd. FCA Authorised. All rights reserved.</p>
  </div>
</footer>

</div><!-- /.mb-wrap -->

<script>
(function(){
  'use strict';

  /* ── Animated counters ─────────────────────────────── */
  var easeOut = function(t){ return 1 - Math.pow(1 - t, 3); };
  var counters = document.querySelectorAll('.mb-counter__val[data-target]');

  if ('IntersectionObserver' in window) {
    var obs = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if (!entry.isIntersecting) return;
        obs.unobserve(entry.target);
        var el     = entry.target;
        var target = parseFloat(el.dataset.target);
        var suffix = el.dataset.suffix || '';
        var isFloat= el.dataset.float === '1';
        if (isNaN(target)) return;
        var duration = 1800, start = null;
        function tick(ts){
          if (!start) start = ts;
          var p = Math.min((ts - start) / duration, 1);
          var v = target * easeOut(p);
          el.textContent = (isFloat ? v.toFixed(1) : Math.floor(v)) + suffix;
          if (p < 1) requestAnimationFrame(tick);
          else el.textContent = (isFloat ? target.toFixed(1) : target) + suffix;
        }
        requestAnimationFrame(tick);
      });
    }, { threshold: 0.4 });
    counters.forEach(function(el){ obs.observe(el); });
  } else {
    counters.forEach(function(el){
      el.textContent = el.dataset.target + (el.dataset.suffix || '');
    });
  }

  /* ── Mouse parallax on particles ──────────────────── */
  var particles = document.querySelectorAll('.mb-particle');
  var hero = document.querySelector('.mb-hero');
  if (hero) {
    hero.addEventListener('mousemove', function(e){
      var rect = hero.getBoundingClientRect();
      var dx = (e.clientX - rect.left - rect.width / 2) / rect.width;
      var dy = (e.clientY - rect.top - rect.height / 2) / rect.height;
      particles.forEach(function(p, i){
        var depth = (i % 4 + 1) * 5;
        p.style.transform = 'translate(' + (dx * depth) + 'px, ' + (dy * depth) + 'px)';
      });
    });
  }

  /* ── Animate rate bars on load ─────────────────────── */
  var fills = document.querySelectorAll('.mb-rate-bar__fill');
  fills.forEach(function(f){
    var target = f.style.width;
    f.style.width = '0';
    setTimeout(function(){ f.style.width = target; }, 600);
  });

})();
</script>

</body>
</html>
</div><!-- .mb-page -->
<?php get_footer(); ?>
