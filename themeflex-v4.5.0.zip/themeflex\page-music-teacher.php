<?php
/**
 * Template Name: Music Teacher
 * Description: Premium Music Teacher / Tutor page template — full CSS art-directed hero
 */
get_header(); ?>

<!-- GOOGLE FONTS: DM Serif Display + Inter -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
/* ============================================================
   MUSIC TEACHER TEMPLATE — --mt-* namespace
   Palette: burgundy #7B1FA2 / gold #F59E0B / ivory #FEFCE8 / charcoal #1F2937
   ============================================================ */
:root {
  --mt-purple:    #7B1FA2;
  --mt-purple-dk: #4A148C;
  --mt-purple-lt: #CE93D8;
  --mt-gold:      #F59E0B;
  --mt-gold-lt:   #FDE68A;
  --mt-teal:      #0D9488;
  --mt-ivory:     #FEFCE8;
  --mt-ivory-dk:  #FEF9C3;
  --mt-charcoal:  #1F2937;
  --mt-grey:      #6B7280;
  --mt-white:     #FFFFFF;
  --mt-radius:    14px;
  --mt-shadow:    0 8px 32px rgba(123,31,162,0.14);
  --mt-font-head: 'DM Serif Display', Georgia, serif;
  --mt-font-body: 'Inter', system-ui, sans-serif;
}

.mt-wrap * { box-sizing: border-box; margin: 0; padding: 0; }
.mt-wrap { font-family: var(--mt-font-body); color: var(--mt-charcoal); background: var(--mt-white); }

/* ── HERO ── */
.mt-hero {
  position: relative;
  min-height: 100vh;
  background: linear-gradient(150deg, var(--mt-purple-dk) 0%, var(--mt-purple) 50%, #9C27B0 80%, #CE93D8 100%);
  overflow: hidden;
  display: flex;
  align-items: center;
}

/* Floating music notes */
.mt-note {
  position: absolute;
  color: rgba(255,255,255,0.12);
  font-size: 2rem;
  animation: mt-note-rise 8s ease-in-out infinite;
  user-select: none;
}
@keyframes mt-note-rise {
  0%   { transform: translateY(0) rotate(0deg);   opacity: 0; }
  10%  { opacity: 0.12; }
  90%  { opacity: 0.12; }
  100% { transform: translateY(-80vh) rotate(20deg); opacity: 0; }
}

/* Sound wave backdrop */
.mt-waves {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 160px;
  overflow: hidden;
}
.mt-wave {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 160px;
  border-radius: 50% 50% 0 0 / 40% 40% 0 0;
  animation: mt-wave-sway 6s ease-in-out infinite alternate;
}
.mt-wave-1 { background: rgba(255,255,255,0.04); animation-delay: 0s; }
.mt-wave-2 { background: rgba(255,255,255,0.04); height: 120px; animation-delay: 2s; }
.mt-wave-3 { background: rgba(255,255,255,0.04); height: 80px;  animation-delay: 4s; }
@keyframes mt-wave-sway {
  from { transform: scaleX(1); }
  to   { transform: scaleX(1.1); }
}

/* CSS MUSIC STUDIO SCENE */
.mt-scene {
  position: absolute;
  right: 5%;
  bottom: 0;
  width: 440px;
  height: 580px;
}

/* Piano */
.mt-piano {
  position: absolute;
  bottom: 40px;
  left: 20px;
  width: 300px;
}
.mt-piano-body {
  width: 300px;
  height: 100px;
  background: linear-gradient(180deg, #1A1A1A 0%, #0D0D0D 100%);
  border-radius: 8px 8px 4px 4px;
  position: relative;
  box-shadow: 0 8px 0 #080808, 0 10px 24px rgba(0,0,0,0.5);
}
/* White keys */
.mt-keys-white {
  display: flex;
  gap: 3px;
  position: absolute;
  bottom: 6px;
  left: 8px;
  right: 8px;
}
.mt-key-w {
  flex: 1;
  height: 60px;
  background: linear-gradient(180deg, #FEFEFE 0%, #F0F0F0 100%);
  border-radius: 0 0 4px 4px;
  border: 1px solid #E0E0E0;
  box-shadow: 0 4px 0 #D0D0D0;
}
.mt-key-w.mt-pressed { transform: translateY(2px); box-shadow: 0 2px 0 #D0D0D0; background: var(--mt-ivory-dk); }
/* Black keys overlay */
.mt-keys-black {
  position: absolute;
  top: 6px;
  left: 8px;
  right: 8px;
  height: 38px;
  display: flex;
  gap: 0;
}
.mt-key-b {
  width: 18px;
  height: 38px;
  background: linear-gradient(180deg, #333 0%, #111 100%);
  border-radius: 0 0 3px 3px;
  flex-shrink: 0;
  position: relative;
  z-index: 2;
}
.mt-key-b.mt-gap { width: 14px; background: transparent; }
/* Piano lid */
.mt-piano-lid {
  width: 300px;
  height: 24px;
  background: linear-gradient(180deg, #2A2A2A 0%, #111 100%);
  border-radius: 8px 8px 0 0;
  margin-bottom: 2px;
}

/* Sheet music stand */
.mt-stand {
  position: absolute;
  bottom: 138px;
  left: 90px;
  width: 120px;
  text-align: center;
}
.mt-stand-top {
  width: 120px;
  height: 80px;
  background: linear-gradient(180deg, #FAFAFA 0%, #F0F0F0 100%);
  border-radius: 6px;
  border: 2px solid #E0E0E0;
  position: relative;
  overflow: hidden;
}
/* Staff lines on sheet music */
.mt-stand-top::before {
  content: '';
  position: absolute;
  top: 16px;
  left: 8px;
  right: 8px;
  height: 2px;
  background: #999;
  box-shadow: 0 8px 0 #999, 0 16px 0 #999, 0 24px 0 #999, 0 32px 0 #999;
}
/* Note symbol on sheet */
.mt-stand-top::after {
  content: '♩♪♫';
  position: absolute;
  top: 12px;
  left: 8px;
  font-size: 1.1rem;
  color: var(--mt-purple);
  letter-spacing: 4px;
}
.mt-stand-pole {
  width: 4px;
  height: 30px;
  background: #B0BEC5;
  margin: 0 auto;
}
.mt-stand-base {
  width: 60px;
  height: 8px;
  background: #B0BEC5;
  border-radius: 4px;
  margin: 0 auto;
}

/* Teacher figure at piano */
.mt-figure {
  position: absolute;
  bottom: 138px;
  right: 24px;
}
.mt-fig-head {
  width: 52px;
  height: 52px;
  background: linear-gradient(180deg, #FFCCBC 0%, #FFAB91 100%);
  border-radius: 50%;
  margin: 0 auto 2px;
  position: relative;
}
.mt-fig-hair {
  position: absolute;
  top: -5px;
  left: 4px;
  right: 4px;
  height: 22px;
  background: #3E2723;
  border-radius: 50% 50% 10% 10%;
}
.mt-fig-hair::after {
  content: '';
  position: absolute;
  bottom: -8px;
  right: -2px;
  width: 10px;
  height: 18px;
  background: #3E2723;
  border-radius: 0 0 8px 6px;
}
.mt-fig-head::after {
  content: '🎵';
  position: absolute;
  bottom: 6px;
  left: 50%;
  transform: translateX(-50%);
  font-size: 0.9rem;
}
.mt-fig-body {
  width: 60px;
  height: 100px;
  background: linear-gradient(180deg, #1565C0 0%, #0D47A1 100%);
  border-radius: 12px 12px 6px 6px;
  margin: 0 auto;
  position: relative;
}
/* Shirt collar */
.mt-fig-body::before {
  content: '';
  position: absolute;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 16px;
  height: 24px;
  background: var(--mt-white);
  border-radius: 0 0 6px 6px;
}
/* Piano playing arms */
.mt-fig-arm-l {
  position: absolute;
  bottom: 16px;
  left: -22px;
  width: 32px;
  height: 12px;
  background: #1565C0;
  border-radius: 6px;
  transform: rotate(20deg);
  transform-origin: right center;
  animation: mt-arm-play 0.8s ease-in-out infinite alternate;
}
.mt-fig-arm-r {
  position: absolute;
  bottom: 16px;
  right: -22px;
  width: 32px;
  height: 12px;
  background: #1565C0;
  border-radius: 6px;
  transform: rotate(-20deg);
  transform-origin: left center;
  animation: mt-arm-play 0.8s ease-in-out infinite alternate-reverse;
}
@keyframes mt-arm-play {
  from { transform: rotate(20deg) translateY(0); }
  to   { transform: rotate(12deg) translateY(-4px); }
}
.mt-fig-arm-r { animation-name: mt-arm-play-r; }
@keyframes mt-arm-play-r {
  from { transform: rotate(-20deg) translateY(0); }
  to   { transform: rotate(-12deg) translateY(-4px); }
}

/* Floating music badges */
.mt-badge {
  position: absolute;
  background: rgba(255,255,255,0.15);
  backdrop-filter: blur(8px);
  border: 1px solid rgba(255,255,255,0.3);
  border-radius: 50px;
  padding: 8px 16px;
  color: var(--mt-white);
  font-family: var(--mt-font-body);
  font-size: 0.8rem;
  font-weight: 600;
  animation: mt-badge-float 5s ease-in-out infinite alternate;
}
.mt-badge-1 { top: 80px;  left: 10px; animation-delay: 0s; }
.mt-badge-2 { top: 160px; left: 24px; animation-delay: 1.8s; }
.mt-badge-3 { top: 250px; left: 8px;  animation-delay: 3.5s; }
@keyframes mt-badge-float {
  from { transform: translateY(0); }
  to   { transform: translateY(-14px); }
}

/* Animated equaliser bars */
.mt-equaliser {
  position: absolute;
  top: 40px;
  right: 20px;
  display: flex;
  gap: 5px;
  align-items: flex-end;
  height: 50px;
}
.mt-eq-bar {
  width: 8px;
  background: rgba(245,158,11,0.5);
  border-radius: 4px 4px 0 0;
  animation: mt-eq-bounce 0.8s ease-in-out infinite alternate;
}
.mt-eq-bar:nth-child(1) { animation-delay: 0s;    animation-duration: 0.6s; }
.mt-eq-bar:nth-child(2) { animation-delay: 0.1s;  animation-duration: 0.9s; }
.mt-eq-bar:nth-child(3) { animation-delay: 0.2s;  animation-duration: 0.5s; }
.mt-eq-bar:nth-child(4) { animation-delay: 0.3s;  animation-duration: 0.7s; }
.mt-eq-bar:nth-child(5) { animation-delay: 0.05s; animation-duration: 1.0s; }
.mt-eq-bar:nth-child(6) { animation-delay: 0.15s; animation-duration: 0.65s; }
@keyframes mt-eq-bounce {
  from { height: 8px; }
  to   { height: 40px; background: rgba(245,158,11,0.9); }
}

/* Hero content */
.mt-hero-inner {
  position: relative;
  z-index: 2;
  max-width: 1280px;
  margin: 0 auto;
  padding: 120px 5% 80px;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 60px;
  align-items: center;
  width: 100%;
}
.mt-hero-text { color: var(--mt-white); }
.mt-hero-tag {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: rgba(255,255,255,0.15);
  border: 1px solid rgba(255,255,255,0.3);
  border-radius: 50px;
  padding: 6px 16px;
  font-size: 0.78rem;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  margin-bottom: 22px;
}
.mt-hero h1 {
  font-family: var(--mt-font-head);
  font-size: clamp(2.4rem, 5vw, 4rem);
  font-weight: 400;
  line-height: 1.1;
  margin-bottom: 20px;
}
.mt-hero h1 em { font-style: italic; color: var(--mt-gold-lt); }
.mt-hero-sub {
  font-size: 1.05rem;
  opacity: 0.88;
  line-height: 1.75;
  margin-bottom: 32px;
  max-width: 500px;
}
.mt-hero-ctas { display: flex; gap: 14px; flex-wrap: wrap; }
.mt-btn-primary {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: var(--mt-gold);
  color: var(--mt-charcoal);
  padding: 16px 30px;
  border-radius: 50px;
  font-weight: 700;
  font-size: 0.95rem;
  text-decoration: none;
  transition: all 0.3s;
  box-shadow: 0 4px 20px rgba(245,158,11,0.4);
}
.mt-btn-primary:hover { background: var(--mt-gold-lt); transform: translateY(-2px); box-shadow: 0 8px 28px rgba(245,158,11,0.5); }
.mt-btn-secondary {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: rgba(255,255,255,0.12);
  border: 2px solid rgba(255,255,255,0.45);
  color: var(--mt-white);
  padding: 14px 26px;
  border-radius: 50px;
  font-weight: 600;
  font-size: 0.95rem;
  text-decoration: none;
  transition: all 0.3s;
}
.mt-btn-secondary:hover { background: rgba(255,255,255,0.22); }

.mt-hero-stats {
  display: flex;
  gap: 36px;
  margin-top: 44px;
  padding-top: 28px;
  border-top: 1px solid rgba(255,255,255,0.2);
}
.mt-hero-stat { color: var(--mt-white); }
.mt-hero-stat-num {
  font-family: var(--mt-font-head);
  font-size: 2rem;
  font-weight: 400;
  display: block;
}
.mt-hero-stat-lbl { font-size: 0.78rem; opacity: 0.72; text-transform: uppercase; letter-spacing: 0.06em; }

/* ── TRUST BAR ── */
.mt-trust { background: var(--mt-charcoal); padding: 18px 5%; }
.mt-trust-inner {
  max-width: 1280px;
  margin: 0 auto;
  display: flex;
  align-items: center;
  gap: 36px;
  flex-wrap: wrap;
  justify-content: center;
}
.mt-trust-item { color: rgba(255,255,255,0.7); font-size: 0.82rem; font-weight: 500; display: flex; align-items: center; gap: 8px; }
.mt-trust-item span { color: var(--mt-gold); }

/* ── SECTIONS ── */
.mt-section { padding: 90px 5%; }
.mt-section-inner { max-width: 1280px; margin: 0 auto; }
.mt-section-tag {
  display: inline-block;
  background: rgba(123,31,162,0.1);
  color: var(--mt-purple);
  font-size: 0.72rem;
  font-weight: 700;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  padding: 5px 14px;
  border-radius: 50px;
  margin-bottom: 10px;
}
.mt-section-title {
  font-family: var(--mt-font-head);
  font-size: clamp(1.8rem, 3.5vw, 2.8rem);
  color: var(--mt-charcoal);
  margin-bottom: 14px;
  line-height: 1.15;
}
.mt-section-sub { color: var(--mt-grey); font-size: 1rem; line-height: 1.7; max-width: 580px; }

/* ── INSTRUMENTS ── */
.mt-instruments { background: var(--mt-ivory); }
.mt-instr-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 20px;
  margin-top: 48px;
}
.mt-instr-card {
  background: var(--mt-white);
  border-radius: var(--mt-radius);
  padding: 28px 20px;
  text-align: center;
  box-shadow: 0 4px 16px rgba(0,0,0,0.06);
  transition: all 0.3s;
  border: 2px solid transparent;
}
.mt-instr-card:hover { transform: translateY(-6px); border-color: var(--mt-purple-lt); box-shadow: var(--mt-shadow); }
.mt-instr-icon { font-size: 2.6rem; display: block; margin-bottom: 12px; }
.mt-instr-card h3 { font-weight: 700; font-size: 0.95rem; color: var(--mt-charcoal); margin-bottom: 6px; }
.mt-instr-card p { font-size: 0.82rem; color: var(--mt-grey); }
.mt-instr-card .mt-level {
  display: inline-block;
  margin-top: 10px;
  background: rgba(123,31,162,0.1);
  color: var(--mt-purple);
  font-size: 0.72rem;
  font-weight: 700;
  padding: 3px 10px;
  border-radius: 50px;
  text-transform: uppercase;
  letter-spacing: 0.06em;
}

/* ── ABOUT ── */
.mt-about-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center; }
.mt-about-visual { position: relative; height: 420px; }
.mt-about-bg {
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, #F3E8FF 0%, var(--mt-ivory-dk) 100%);
  border-radius: 20px;
}
/* Large note display */
.mt-big-note {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -55%);
  font-size: 8rem;
  opacity: 0.15;
  animation: mt-note-pulse 3s ease-in-out infinite;
}
@keyframes mt-note-pulse {
  0%, 100% { transform: translate(-50%,-55%) scale(1); }
  50%       { transform: translate(-50%,-55%) scale(1.05); }
}
/* Credential badges */
.mt-cred {
  position: absolute;
  background: var(--mt-white);
  border-radius: 10px;
  padding: 10px 14px;
  font-size: 0.75rem;
  font-weight: 700;
  box-shadow: 0 4px 16px rgba(0,0,0,0.1);
  animation: mt-cred-bob 5s ease-in-out infinite alternate;
}
.mt-cred-1 { top: 24px;  left: 20px;  animation-delay: 0s;   color: var(--mt-purple); border-left: 3px solid var(--mt-purple); }
.mt-cred-2 { top: 100px; right: 20px; animation-delay: 1.5s; color: var(--mt-gold);   border-left: 3px solid var(--mt-gold); }
.mt-cred-3 { bottom: 80px; left: 20px; animation-delay: 3s;  color: var(--mt-teal);   border-left: 3px solid var(--mt-teal); }
@keyframes mt-cred-bob { from { transform: translateY(0); } to { transform: translateY(-10px); } }
/* Mini piano graphic */
.mt-mini-piano {
  position: absolute;
  bottom: 20px;
  right: 20px;
  width: 110px;
  height: 40px;
  background: #1A1A1A;
  border-radius: 6px;
}
.mt-mini-piano::before {
  content: '';
  position: absolute;
  bottom: 5px;
  left: 6px;
  right: 6px;
  height: 26px;
  background: repeating-linear-gradient(90deg, #FEFEFE 0px, #FEFEFE 7px, #111 7px, #111 9px);
  border-radius: 0 0 3px 3px;
}
.mt-about-text .mt-section-sub { max-width: 100%; }
.mt-about-quals {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin: 22px 0;
}
.mt-qual-row {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 0.88rem;
}
.mt-qual-row::before { content: '🎵'; font-size: 0.85rem; flex-shrink: 0; }
.mt-about-quote {
  background: linear-gradient(135deg, var(--mt-purple-dk) 0%, var(--mt-purple) 100%);
  color: var(--mt-white);
  padding: 22px 26px;
  border-radius: var(--mt-radius);
  font-family: var(--mt-font-head);
  font-size: 1rem;
  font-style: italic;
  line-height: 1.65;
  margin-top: 16px;
}

/* ── LESSON TYPES ── */
.mt-lessons { background: var(--mt-ivory); }
.mt-lessons-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 24px;
  margin-top: 48px;
}
.mt-lesson-card {
  background: var(--mt-white);
  border-radius: var(--mt-radius);
  overflow: hidden;
  box-shadow: 0 4px 20px rgba(0,0,0,0.07);
  transition: all 0.3s;
}
.mt-lesson-card:hover { transform: translateY(-6px); box-shadow: var(--mt-shadow); }
.mt-lesson-stripe {
  height: 6px;
  background: linear-gradient(90deg, var(--mt-purple) 0%, var(--mt-purple-lt) 100%);
}
.mt-lesson-card:nth-child(2n) .mt-lesson-stripe {
  background: linear-gradient(90deg, var(--mt-gold) 0%, var(--mt-gold-lt) 100%);
}
.mt-lesson-card:nth-child(3n) .mt-lesson-stripe {
  background: linear-gradient(90deg, var(--mt-teal) 0%, #5EEAD4 100%);
}
.mt-lesson-body { padding: 24px; }
.mt-lesson-icon { font-size: 1.8rem; display: block; margin-bottom: 12px; }
.mt-lesson-card h3 { font-weight: 700; font-size: 1rem; margin-bottom: 8px; }
.mt-lesson-card p { font-size: 0.86rem; color: var(--mt-grey); line-height: 1.6; margin-bottom: 14px; }
.mt-lesson-meta {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}
.mt-lesson-tag {
  background: rgba(123,31,162,0.08);
  color: var(--mt-purple);
  font-size: 0.72rem;
  font-weight: 700;
  padding: 3px 10px;
  border-radius: 50px;
}

/* ── PROCESS ── */
.mt-process-section {
  background: linear-gradient(135deg, var(--mt-purple-dk) 0%, var(--mt-purple) 100%);
}
.mt-process-section .mt-section-tag { background: rgba(245,158,11,0.2); color: var(--mt-gold-lt); }
.mt-process-section .mt-section-title { color: var(--mt-white); }
.mt-process-section .mt-section-sub { color: rgba(255,255,255,0.72); }
.mt-process-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 32px;
  margin-top: 52px;
}
.mt-process-step { text-align: center; }
.mt-process-num {
  width: 56px; height: 56px;
  border-radius: 50%;
  background: rgba(245,158,11,0.25);
  border: 2px solid var(--mt-gold);
  color: var(--mt-gold);
  font-family: var(--mt-font-head);
  font-size: 1.4rem;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 16px;
}
.mt-process-step h3 { font-weight: 700; color: var(--mt-white); margin-bottom: 8px; font-size: 1rem; }
.mt-process-step p { font-size: 0.84rem; color: rgba(255,255,255,0.65); line-height: 1.6; }

/* ── PACKAGES ── */
.mt-packages-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
  margin-top: 52px;
}
.mt-package {
  border-radius: var(--mt-radius);
  padding: 32px 24px;
  border: 2px solid #EEF0F3;
  background: var(--mt-white);
  transition: all 0.3s;
  position: relative;
}
.mt-package:hover { box-shadow: var(--mt-shadow); }
.mt-package-featured {
  background: linear-gradient(135deg, var(--mt-purple-dk) 0%, var(--mt-purple) 100%);
  border-color: var(--mt-purple);
  transform: scale(1.03);
}
.mt-package-featured:hover { transform: scale(1.06); }
.mt-pkg-badge {
  position: absolute;
  top: -13px;
  left: 50%;
  transform: translateX(-50%);
  background: var(--mt-gold);
  color: var(--mt-charcoal);
  font-size: 0.68rem;
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  padding: 4px 14px;
  border-radius: 50px;
  white-space: nowrap;
}
.mt-package h3 { font-family: var(--mt-font-head); font-size: 1.2rem; margin-bottom: 6px; color: var(--mt-charcoal); }
.mt-package-featured h3 { color: var(--mt-white); }
.mt-pkg-price {
  font-family: var(--mt-font-head);
  font-size: 2.2rem;
  color: var(--mt-purple);
  margin: 14px 0 4px;
  line-height: 1;
}
.mt-package-featured .mt-pkg-price { color: var(--mt-gold-lt); }
.mt-pkg-per { font-size: 0.82rem; color: var(--mt-grey); margin-bottom: 16px; }
.mt-package-featured .mt-pkg-per { color: rgba(255,255,255,0.65); }
.mt-pkg-features { list-style: none; margin-bottom: 24px; }
.mt-pkg-features li {
  padding: 7px 0;
  border-bottom: 1px solid #EEF0F3;
  font-size: 0.86rem;
  display: flex;
  align-items: center;
  gap: 8px;
}
.mt-package-featured .mt-pkg-features li { border-bottom-color: rgba(255,255,255,0.15); color: rgba(255,255,255,0.9); }
.mt-pkg-features li::before { content: '♩'; color: var(--mt-purple); font-weight: 700; }
.mt-package-featured .mt-pkg-features li::before { color: var(--mt-gold-lt); }
.mt-pkg-btn {
  display: block;
  text-align: center;
  padding: 13px;
  border-radius: 50px;
  font-weight: 700;
  font-size: 0.9rem;
  text-decoration: none;
  transition: all 0.3s;
  background: var(--mt-ivory);
  color: var(--mt-purple);
  border: 2px solid var(--mt-purple);
}
.mt-pkg-btn:hover { background: var(--mt-purple); color: var(--mt-white); }
.mt-package-featured .mt-pkg-btn { background: var(--mt-white); color: var(--mt-purple-dk); border-color: var(--mt-white); }
.mt-package-featured .mt-pkg-btn:hover { background: var(--mt-gold); color: var(--mt-charcoal); border-color: var(--mt-gold); }

/* ── TESTIMONIALS ── */
.mt-testimonials { background: var(--mt-ivory); }
.mt-testimonials-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
  margin-top: 48px;
}
.mt-testimonial {
  background: var(--mt-white);
  border-radius: var(--mt-radius);
  padding: 28px 24px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.06);
  position: relative;
}
.mt-testimonial::before {
  content: '♪';
  font-size: 4rem;
  color: var(--mt-purple-lt);
  position: absolute;
  top: -8px;
  left: 16px;
  opacity: 0.3;
}
.mt-stars { color: #F59E0B; font-size: 1rem; margin-bottom: 10px; }
.mt-testimonial p { font-size: 0.88rem; color: var(--mt-charcoal); line-height: 1.7; margin-bottom: 18px; font-style: italic; }
.mt-testi-author { display: flex; align-items: center; gap: 10px; }
.mt-testi-avatar {
  width: 40px; height: 40px;
  border-radius: 50%;
  background: linear-gradient(135deg, var(--mt-purple-lt) 0%, var(--mt-purple) 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--mt-white);
  font-weight: 700;
  font-size: 0.9rem;
}
.mt-testi-name { font-weight: 700; font-size: 0.88rem; }
.mt-testi-role { font-size: 0.76rem; color: var(--mt-grey); }

/* ── FAQ ── */
.mt-faqs { max-width: 760px; margin: 48px auto 0; }
.mt-faq-item { border-bottom: 1px solid #EEF0F3; }
.mt-faq-q {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 18px 0;
  cursor: pointer;
  font-weight: 600;
  font-size: 0.93rem;
  user-select: none;
}
.mt-faq-q::after { content: '+'; font-size: 1.4rem; color: var(--mt-purple); transition: transform 0.3s; flex-shrink: 0; }
.mt-faq-item.mt-open .mt-faq-q::after { transform: rotate(45deg); }
.mt-faq-a { max-height: 0; overflow: hidden; transition: max-height 0.4s ease; }
.mt-faq-a-inner { padding: 0 0 18px; color: var(--mt-grey); font-size: 0.88rem; line-height: 1.7; }

/* ── BOOKING ── */
.mt-booking-section {
  background: linear-gradient(135deg, var(--mt-purple-dk) 0%, var(--mt-purple) 100%);
}
.mt-booking-section .mt-section-tag { background: rgba(245,158,11,0.2); color: var(--mt-gold-lt); }
.mt-booking-section .mt-section-title { color: var(--mt-white); }
.mt-booking-section .mt-section-sub { color: rgba(255,255,255,0.75); }
.mt-booking-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 60px;
  margin-top: 48px;
  align-items: start;
}
.mt-booking-info { color: var(--mt-white); }
.mt-booking-info h3 { font-family: var(--mt-font-head); font-size: 1.4rem; margin-bottom: 18px; }
.mt-booking-info ul { list-style: none; display: flex; flex-direction: column; gap: 10px; }
.mt-booking-info li { display: flex; align-items: flex-start; gap: 10px; font-size: 0.88rem; opacity: 0.9; }
.mt-booking-info li::before { content: '♫'; color: var(--mt-gold-lt); font-size: 0.85rem; flex-shrink: 0; }
.mt-contact-box {
  background: rgba(255,255,255,0.1);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: var(--mt-radius);
  padding: 18px 22px;
  margin-top: 24px;
}
.mt-contact-box h4 { font-size: 0.8rem; font-weight: 700; color: rgba(255,255,255,0.65); text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 12px; }
.mt-contact-item { display: flex; align-items: center; gap: 10px; font-size: 0.88rem; color: rgba(255,255,255,0.9); margin-bottom: 8px; }
.mt-form {
  background: var(--mt-white);
  border-radius: 16px;
  padding: 32px 28px;
  box-shadow: 0 20px 60px rgba(0,0,0,0.2);
}
.mt-form h3 { font-family: var(--mt-font-head); font-size: 1.3rem; color: var(--mt-charcoal); margin-bottom: 20px; }
.mt-form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
.mt-form-group { display: flex; flex-direction: column; gap: 5px; }
.mt-form-group.mt-full { grid-column: 1/-1; }
.mt-form-group label { font-size: 0.78rem; font-weight: 600; color: var(--mt-charcoal); }
.mt-form-group input,
.mt-form-group select,
.mt-form-group textarea {
  padding: 11px 14px;
  border: 2px solid #EEF0F3;
  border-radius: 8px;
  font-family: var(--mt-font-body);
  font-size: 0.88rem;
  color: var(--mt-charcoal);
  transition: border-color 0.3s;
  background: var(--mt-white);
}
.mt-form-group input:focus,
.mt-form-group select:focus,
.mt-form-group textarea:focus { outline: none; border-color: var(--mt-purple); }
.mt-form-group textarea { resize: vertical; min-height: 80px; }
.mt-form-submit {
  width: 100%;
  padding: 15px;
  background: linear-gradient(135deg, var(--mt-purple) 0%, var(--mt-purple-dk) 100%);
  color: var(--mt-white);
  border: none;
  border-radius: 50px;
  font-family: var(--mt-font-body);
  font-size: 1rem;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.3s;
  margin-top: 8px;
  box-shadow: 0 4px 16px rgba(123,31,162,0.4);
}
.mt-form-submit:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(123,31,162,0.5); }
.mt-form-note { font-size: 0.76rem; color: var(--mt-grey); text-align: center; margin-top: 10px; }

/* ── RESPONSIVE ── */
@media (max-width: 1024px) {
  .mt-hero-inner { grid-template-columns: 1fr; }
  .mt-scene { display: none; }
  .mt-about-grid { grid-template-columns: 1fr; }
  .mt-about-visual { height: 240px; }
  .mt-packages-grid { grid-template-columns: 1fr; }
  .mt-package-featured { transform: none; }
  .mt-testimonials-grid { grid-template-columns: 1fr; }
  .mt-booking-grid { grid-template-columns: 1fr; }
}
@media (max-width: 640px) {
  .mt-section { padding: 60px 5%; }
  .mt-hero h1 { font-size: 2.2rem; }
  .mt-instr-grid { grid-template-columns: repeat(2, 1fr); }
  .mt-lessons-grid { grid-template-columns: 1fr; }
  .mt-process-grid { grid-template-columns: 1fr 1fr; }
  .mt-form-grid { grid-template-columns: 1fr; }
  .mt-hero-stats { gap: 18px; }
}
</style>

<div class="mt-wrap">

<!-- ═══════════════════════════════
     HERO
════════════════════════════════ -->
<section class="mt-hero">

  <!-- Floating music notes -->
  <?php
  srand(crc32('mt-notes'));
  $note_chars = ['♩','♪','♫','♬','𝄞','𝄢'];
  for ($i = 0; $i < 16; $i++) {
    $left  = rand(3, 97);
    $top   = rand(5, 95);
    $delay = rand(0, 8000) / 1000;
    $dur   = rand(6, 12);
    $sym   = $note_chars[array_rand($note_chars)];
    echo "<div class='mt-note' style='left:{$left}%;top:{$top}%;animation-delay:{$delay}s;animation-duration:{$dur}s;'>{$sym}</div>";
  }
  ?>

  <!-- Sound waves -->
  <div class="mt-waves">
    <div class="mt-wave mt-wave-1"></div>
    <div class="mt-wave mt-wave-2"></div>
    <div class="mt-wave mt-wave-3"></div>
  </div>

  <div class="mt-hero-inner">
    <div class="mt-hero-text">
      <div class="mt-hero-tag">🎓 ABRSM Examiner · 20 Years Teaching</div>
      <h1>Unlock Your<br><em>Musical Potential</em></h1>
      <p class="mt-hero-sub">Expert piano, violin, and music theory tuition for all ages and abilities — from first note to diploma level. Based in Bristol with online lessons available worldwide.</p>
      <div class="mt-hero-ctas">
        <a href="#booking" class="mt-btn-primary">🎵 Book a Trial Lesson</a>
        <a href="#lessons" class="mt-btn-secondary">View Lessons →</a>
      </div>
      <div class="mt-hero-stats">
        <div class="mt-hero-stat">
          <span class="mt-hero-stat-num" data-target="20" data-suffix="yrs">0yrs</span>
          <span class="mt-hero-stat-lbl">Teaching</span>
        </div>
        <div class="mt-hero-stat">
          <span class="mt-hero-stat-num" data-target="320" data-suffix="+">0+</span>
          <span class="mt-hero-stat-lbl">Students Taught</span>
        </div>
        <div class="mt-hero-stat">
          <span class="mt-hero-stat-num" data-target="4.9" data-float="1" data-suffix="★">0★</span>
          <span class="mt-hero-stat-lbl">Rating</span>
        </div>
        <div class="mt-hero-stat">
          <span class="mt-hero-stat-num" data-target="98" data-suffix="%">0%</span>
          <span class="mt-hero-stat-lbl">Pass Rate</span>
        </div>
      </div>
    </div>
  </div>

  <!-- CSS Music Studio Scene -->
  <div class="mt-scene">
    <div class="mt-equaliser">
      <div class="mt-eq-bar" style="height:20px;"></div>
      <div class="mt-eq-bar" style="height:36px;"></div>
      <div class="mt-eq-bar" style="height:14px;"></div>
      <div class="mt-eq-bar" style="height:42px;"></div>
      <div class="mt-eq-bar" style="height:24px;"></div>
      <div class="mt-eq-bar" style="height:18px;"></div>
    </div>
    <!-- Sheet music stand -->
    <div class="mt-stand">
      <div class="mt-stand-top"></div>
      <div class="mt-stand-pole"></div>
      <div class="mt-stand-base"></div>
    </div>
    <!-- Teacher figure -->
    <div class="mt-figure">
      <div class="mt-fig-head"><div class="mt-fig-hair"></div></div>
      <div class="mt-fig-body">
        <div class="mt-fig-arm-l"></div>
        <div class="mt-fig-arm-r"></div>
      </div>
    </div>
    <!-- Piano -->
    <div class="mt-piano">
      <div class="mt-piano-lid"></div>
      <div class="mt-piano-body">
        <div class="mt-keys-black">
          <div class="mt-key-b"></div><div class="mt-key-b"></div>
          <div class="mt-key-b mt-gap"></div>
          <div class="mt-key-b"></div><div class="mt-key-b"></div><div class="mt-key-b"></div>
          <div class="mt-key-b mt-gap"></div>
          <div class="mt-key-b"></div><div class="mt-key-b"></div>
          <div class="mt-key-b mt-gap"></div>
          <div class="mt-key-b"></div><div class="mt-key-b"></div><div class="mt-key-b"></div>
        </div>
        <div class="mt-keys-white">
          <?php for ($k=0; $k<14; $k++) { $pressed = in_array($k,[0,3,7,10]) ? ' mt-pressed' : ''; echo "<div class='mt-key-w{$pressed}'></div>"; } ?>
        </div>
      </div>
    </div>
    <!-- Floating badges -->
    <div class="mt-badge mt-badge-1">🎓 ABRSM Grade 8 Piano</div>
    <div class="mt-badge mt-badge-2">🎻 LRSM Violin</div>
    <div class="mt-badge mt-badge-3">📜 Music Theory Dip.</div>
  </div>

</section>

<!-- TRUST BAR -->
<div class="mt-trust">
  <div class="mt-trust-inner">
    <div class="mt-trust-item"><span>🎓</span> ABRSM Examiner & Adjudicator</div>
    <div class="mt-trust-item"><span>🏫</span> MMus Royal College of Music</div>
    <div class="mt-trust-item"><span>🛡️</span> Enhanced DBS Checked</div>
    <div class="mt-trust-item"><span>💻</span> Online Lessons Available</div>
    <div class="mt-trust-item"><span>🏆</span> 98% Exam Pass Rate</div>
  </div>
</div>

<!-- ═══════════════════════════════
     INSTRUMENTS TAUGHT
════════════════════════════════ -->
<section class="mt-section mt-instruments">
  <div class="mt-section-inner">
    <div class="mt-section-tag">Instruments &amp; Subjects</div>
    <h2 class="mt-section-title">What You Can Learn</h2>
    <p class="mt-section-sub">From beginner to diploma level — tailored lessons across multiple disciplines.</p>

    <div class="mt-instr-grid">
      <div class="mt-instr-card">
        <span class="mt-instr-icon">🎹</span>
        <h3>Piano</h3>
        <p>Classical &amp; contemporary, beginner to ABRSM Grade 8 and beyond</p>
        <div class="mt-level">All Levels</div>
      </div>
      <div class="mt-instr-card">
        <span class="mt-instr-icon">🎻</span>
        <h3>Violin</h3>
        <p>Classical technique, folk styles, and graded exam preparation</p>
        <div class="mt-level">All Levels</div>
      </div>
      <div class="mt-instr-card">
        <span class="mt-instr-icon">📖</span>
        <h3>Music Theory</h3>
        <p>ABRSM &amp; Trinity theory grades 1–8, A-Level, and composition</p>
        <div class="mt-level">All Grades</div>
      </div>
      <div class="mt-instr-card">
        <span class="mt-instr-icon">🎼</span>
        <h3>Composition</h3>
        <p>Songwriting, arrangement, and original composition for any style</p>
        <div class="mt-level">Intermediate+</div>
      </div>
      <div class="mt-instr-card">
        <span class="mt-instr-icon">🎵</span>
        <h3>Sight-Reading</h3>
        <p>Intensive sight-reading workshops for quick-fire exam improvement</p>
        <div class="mt-level">Grade 3+</div>
      </div>
      <div class="mt-instr-card">
        <span class="mt-instr-icon">🎤</span>
        <h3>Ear Training</h3>
        <p>Interval recognition, melodic dictation, harmony, and aural skills</p>
        <div class="mt-level">All Levels</div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     ABOUT
════════════════════════════════ -->
<section class="mt-section">
  <div class="mt-section-inner">
    <div class="mt-about-grid">
      <div class="mt-about-visual">
        <div class="mt-about-bg"></div>
        <div class="mt-big-note">🎼</div>
        <div class="mt-cred mt-cred-1">MMus Royal College of Music</div>
        <div class="mt-cred mt-cred-2">ABRSM Chief Examiner</div>
        <div class="mt-cred mt-cred-3">LRSM Violin Performer</div>
        <div class="mt-mini-piano"></div>
      </div>
      <div class="mt-about-text">
        <div class="mt-section-tag">Your Teacher</div>
        <h2 class="mt-section-title">Victoria Chen</h2>
        <p class="mt-section-sub">With a Master's degree from the Royal College of Music and 20 years of teaching experience, Victoria brings world-class musicianship to students of every age. A practising ABRSM examiner, her students consistently achieve distinctions and go on to music college, professional performance, and lifelong enjoyment of music.</p>

        <div class="mt-about-quals">
          <div class="mt-qual-row">MMus Piano Performance — Royal College of Music, London</div>
          <div class="mt-qual-row">BA (Hons) Music — University of Bristol (First Class)</div>
          <div class="mt-qual-row">ABRSM Chief Examiner &amp; Diploma Assessor</div>
          <div class="mt-qual-row">LRSM Violin Performer's Diploma</div>
          <div class="mt-qual-row">Enhanced DBS Checked — ISA registered</div>
        </div>
        <div class="mt-about-quote">
          "Music is not about perfection — it's about expression, confidence, and joy. Every student I teach finds their own musical voice, and there's no greater reward as a teacher than witnessing that discovery."
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     LESSON TYPES
════════════════════════════════ -->
<section class="mt-section mt-lessons" id="lessons">
  <div class="mt-section-inner">
    <div class="mt-section-tag">Lesson Options</div>
    <h2 class="mt-section-title">Tailored to Every Student</h2>
    <p class="mt-section-sub">Whether you're taking your first steps or preparing for a professional audition, there's a lesson format that's right for you.</p>

    <div class="mt-lessons-grid">
      <div class="mt-lesson-card">
        <div class="mt-lesson-stripe"></div>
        <div class="mt-lesson-body">
          <span class="mt-lesson-icon">👶</span>
          <h3>Young Beginners (Ages 4–7)</h3>
          <p>Fun, game-based piano and violin lessons designed to build coordination, listening, and a lifelong love of music.</p>
          <div class="mt-lesson-meta">
            <div class="mt-lesson-tag">30 min sessions</div>
            <div class="mt-lesson-tag">In-person or online</div>
          </div>
        </div>
      </div>
      <div class="mt-lesson-card">
        <div class="mt-lesson-stripe"></div>
        <div class="mt-lesson-body">
          <span class="mt-lesson-icon">🧒</span>
          <h3>Children &amp; Teens (Ages 8–18)</h3>
          <p>Structured lessons aligned to ABRSM or Trinity syllabi — building technique, repertoire, and exam confidence.</p>
          <div class="mt-lesson-meta">
            <div class="mt-lesson-tag">45 or 60 min</div>
            <div class="mt-lesson-tag">Exam preparation</div>
          </div>
        </div>
      </div>
      <div class="mt-lesson-card">
        <div class="mt-lesson-stripe"></div>
        <div class="mt-lesson-body">
          <span class="mt-lesson-icon">🧑</span>
          <h3>Adults (All Levels)</h3>
          <p>Whether picking up where you left off or starting from scratch — adult lessons are tailored to your goals and schedule.</p>
          <div class="mt-lesson-meta">
            <div class="mt-lesson-tag">45 or 60 min</div>
            <div class="mt-lesson-tag">Flexible timing</div>
          </div>
        </div>
      </div>
      <div class="mt-lesson-card">
        <div class="mt-lesson-stripe"></div>
        <div class="mt-lesson-body">
          <span class="mt-lesson-icon">🎓</span>
          <h3>Diploma &amp; Advanced</h3>
          <p>Intensive preparation for ABRSM DipABRSM, LRSM, FRSM — and music college and conservatoire auditions.</p>
          <div class="mt-lesson-meta">
            <div class="mt-lesson-tag">60–90 min</div>
            <div class="mt-lesson-tag">Advanced level</div>
          </div>
        </div>
      </div>
      <div class="mt-lesson-card">
        <div class="mt-lesson-stripe"></div>
        <div class="mt-lesson-body">
          <span class="mt-lesson-icon">💻</span>
          <h3>Online Lessons</h3>
          <p>High-quality Zoom lessons with digital score sharing. Students worldwide join from the comfort of their own home.</p>
          <div class="mt-lesson-meta">
            <div class="mt-lesson-tag">Worldwide</div>
            <div class="mt-lesson-tag">All instruments</div>
          </div>
        </div>
      </div>
      <div class="mt-lesson-card">
        <div class="mt-lesson-stripe"></div>
        <div class="mt-lesson-body">
          <span class="mt-lesson-icon">📋</span>
          <h3>Theory Crash Courses</h3>
          <p>Intensive holiday block courses for students needing to rapidly improve their theory grade or A-Level coursework.</p>
          <div class="mt-lesson-meta">
            <div class="mt-lesson-tag">Block bookings</div>
            <div class="mt-lesson-tag">Grade 1–8</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     PROCESS
════════════════════════════════ -->
<section class="mt-section mt-process-section">
  <div class="mt-section-inner">
    <div class="mt-section-tag">Getting Started</div>
    <h2 class="mt-section-title">From Enquiry to First Note</h2>
    <p class="mt-section-sub">A simple, welcoming process to get you or your child started quickly.</p>

    <div class="mt-process-grid">
      <div class="mt-process-step">
        <div class="mt-process-num">1</div>
        <h3>Free Consultation</h3>
        <p>A 15-minute chat to discuss your goals, current level, and find the right lesson format.</p>
      </div>
      <div class="mt-process-step">
        <div class="mt-process-num">2</div>
        <h3>Trial Lesson</h3>
        <p>A relaxed, 30-minute introductory lesson to assess level and for you to see if we're a good fit.</p>
      </div>
      <div class="mt-process-step">
        <div class="mt-process-num">3</div>
        <h3>Lesson Plan</h3>
        <p>A personalised programme with clear milestones, repertoire, and exam targets tailored to you.</p>
      </div>
      <div class="mt-process-step">
        <div class="mt-process-num">4</div>
        <h3>Regular Lessons</h3>
        <p>Weekly sessions with structured practice guidance, progress reviews, and parental updates.</p>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     PACKAGES
════════════════════════════════ -->
<section class="mt-section">
  <div class="mt-section-inner">
    <div class="mt-section-tag">Lesson Rates</div>
    <h2 class="mt-section-title">Investment in Your Music</h2>
    <p class="mt-section-sub">Clear, transparent pricing. Block bookings offer the best value and secure your weekly slot.</p>

    <div class="mt-packages-grid">
      <div class="mt-package">
        <h3>Individual Lessons</h3>
        <div class="mt-pkg-price">£55</div>
        <div class="mt-pkg-per">per 45-min lesson · pay as you go</div>
        <ul class="mt-pkg-features">
          <li>45-minute lesson (60 min: +£12)</li>
          <li>All instruments &amp; theory</li>
          <li>Practice guidance notes</li>
          <li>Flexible booking</li>
          <li>No long-term commitment</li>
        </ul>
        <a href="#booking" class="mt-pkg-btn">Book Now</a>
      </div>
      <div class="mt-package mt-package-featured">
        <div class="mt-pkg-badge">Best Value</div>
        <h3>Monthly Block</h3>
        <div class="mt-pkg-price">£195</div>
        <div class="mt-pkg-per">4 x 45-min lessons per month</div>
        <ul class="mt-pkg-features">
          <li>Save £25 vs individual rate</li>
          <li>Guaranteed weekly slot</li>
          <li>Full practice notes &amp; resources</li>
          <li>Monthly progress report</li>
          <li>Priority exam entry support</li>
          <li>WhatsApp teacher access</li>
        </ul>
        <a href="#booking" class="mt-pkg-btn">Start Block</a>
      </div>
      <div class="mt-package">
        <h3>Exam Intensive</h3>
        <div class="mt-pkg-price">£285</div>
        <div class="mt-pkg-per">6-lesson exam prep block</div>
        <ul class="mt-pkg-features">
          <li>6 x 60-min focused sessions</li>
          <li>Mock examination included</li>
          <li>Accompanist coordinated</li>
          <li>Exam board registration help</li>
          <li>Detailed feedback report</li>
        </ul>
        <a href="#booking" class="mt-pkg-btn">Book Intensive</a>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     TESTIMONIALS
════════════════════════════════ -->
<section class="mt-section mt-testimonials">
  <div class="mt-section-inner">
    <div class="mt-section-tag">Student Stories</div>
    <h2 class="mt-section-title">Music That Transforms Lives</h2>

    <div class="mt-testimonials-grid">
      <div class="mt-testimonial">
        <div class="mt-stars">★★★★★</div>
        <p>Victoria has taken our daughter from a nervous beginner to achieving a Distinction in Grade 6 Piano in three years. Her patience, creativity, and genuine passion for teaching are unlike anything I've encountered. Worth every penny.</p>
        <div class="mt-testi-author">
          <div class="mt-testi-avatar">HP</div>
          <div>
            <div class="mt-testi-name">Helen &amp; Patrick O.</div>
            <div class="mt-testi-role">Parents of Sophie, Grade 6 Piano</div>
          </div>
        </div>
      </div>
      <div class="mt-testimonial">
        <div class="mt-stars">★★★★★</div>
        <p>I'm 52 and always dreamed of learning piano but assumed it was too late. Victoria proved me completely wrong. Within 18 months I was playing pieces I never imagined I could manage — it's been one of the most joyful experiences of my adult life.</p>
        <div class="mt-testi-author">
          <div class="mt-testi-avatar">RS</div>
          <div>
            <div class="mt-testi-name">Richard S.</div>
            <div class="mt-testi-role">Adult Beginner Piano</div>
          </div>
        </div>
      </div>
      <div class="mt-testimonial">
        <div class="mt-stars">★★★★★</div>
        <p>Victoria prepared me for my DipABRSM over 8 months. Her knowledge of the repertoire is extraordinary, and her mock exams were harder than the real thing — which is exactly what I needed. I passed with distinction.</p>
        <div class="mt-testi-author">
          <div class="mt-testi-avatar">AL</div>
          <div>
            <div class="mt-testi-name">Amy L.</div>
            <div class="mt-testi-role">DipABRSM Distinction</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     FAQ
════════════════════════════════ -->
<section class="mt-section">
  <div class="mt-section-inner">
    <div style="text-align:center;">
      <div class="mt-section-tag">FAQ</div>
      <h2 class="mt-section-title">Common Questions</h2>
    </div>
    <div class="mt-faqs">
      <div class="mt-faq-item">
        <div class="mt-faq-q">Do I need my own instrument to start lessons?</div>
        <div class="mt-faq-a"><div class="mt-faq-a-inner">Not for your first few lessons — you're welcome to practise on my instrument during in-person sessions. However, regular practice at home is essential for progress, and I provide detailed guidance on selecting and purchasing an appropriate instrument within your budget.</div></div>
      </div>
      <div class="mt-faq-item">
        <div class="mt-faq-q">What age can children start piano lessons?</div>
        <div class="mt-faq-a"><div class="mt-faq-a-inner">Most children are ready to begin from age 4–5, though this varies. At this age, lessons are 20–30 minutes long and highly game-based. I offer a free 15-minute assessment to determine if your child is ready to start formal lessons.</div></div>
      </div>
      <div class="mt-faq-item">
        <div class="mt-faq-q">What happens if I miss a lesson?</div>
        <div class="mt-faq-a"><div class="mt-faq-a-inner">Lessons cancelled with more than 48 hours' notice can be rescheduled within the same month. Late cancellations and no-shows are charged at the full lesson rate. I'll always do my best to find an alternative slot that suits you.</div></div>
      </div>
      <div class="mt-faq-item">
        <div class="mt-faq-q">Are online lessons as effective as in-person?</div>
        <div class="mt-faq-a"><div class="mt-faq-a-inner">For piano and theory, online lessons work extremely well with the right setup. I use score-sharing software and two-camera viewing for technique correction. Violin lessons are also very successful online for established students. I recommend a good quality device and stable internet connection.</div></div>
      </div>
      <div class="mt-faq-item">
        <div class="mt-faq-q">Do you prepare students for music college auditions?</div>
        <div class="mt-faq-a"><div class="mt-faq-a-inner">Yes — I have successfully prepared students for the Royal College, Royal Academy, Trinity Laban, and RNCM. This requires a minimum of 12 months dedicated preparation and a current standard of approximately Grade 8 Distinction or above. Please enquire to discuss your specific goals.</div></div>
      </div>
      <div class="mt-faq-item">
        <div class="mt-faq-q">Do you teach music theory separately from instrument lessons?</div>
        <div class="mt-faq-a"><div class="mt-faq-a-inner">Yes — theory lessons are available as standalone sessions or integrated with instrument tuition. They're particularly recommended for students taking Grade 5+ exams, as ABRSM requires a Grade 5 Theory pass before Grade 6 practical examinations.</div></div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     BOOKING FORM
════════════════════════════════ -->
<section class="mt-section mt-booking-section" id="booking">
  <div class="mt-section-inner">
    <div class="mt-section-tag">Book a Lesson</div>
    <h2 class="mt-section-title">Begin Your Musical Journey</h2>
    <p class="mt-section-sub">First lesson is a discounted trial — 30 minutes for £25. No commitment required.</p>

    <div class="mt-booking-grid">
      <div class="mt-booking-info">
        <h3>Studio Information</h3>
        <ul>
          <li>Yamaha grand piano &amp; Steinway upright on-site</li>
          <li>Professional violin and bow available for beginners</li>
          <li>Sheet music library of 3,000+ works available</li>
          <li>Digital recording available for self-assessment</li>
          <li>Online lessons via Zoom with digital score sharing</li>
          <li>Free parking directly outside the studio</li>
          <li>30-min trial lesson — £25 for new students</li>
        </ul>
        <div class="mt-contact-box">
          <h4>Contact &amp; Location</h4>
          <div class="mt-contact-item">📍 14 Clifton Park Road, Bristol BS8 3HN</div>
          <div class="mt-contact-item">📞 0117 924 5870</div>
          <div class="mt-contact-item">📧 victoria@chenmusicstudio.co.uk</div>
          <div class="mt-contact-item">🕐 Mon–Fri: 9am–8pm | Sat: 9am–5pm</div>
        </div>
      </div>

      <div class="mt-form">
        <h3>🎵 Book Your Trial Lesson</h3>
        <?php if ( function_exists( 'get_the_permalink' ) ) : ?>
        <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
          <?php wp_nonce_field( 'tf_mt_booking', 'tf_mt_nonce' ); ?>
          <input type="hidden" name="action" value="tf_mt_booking">
          <div class="mt-form-grid">
            <div class="mt-form-group">
              <label for="mt_name">Your Name *</label>
              <input type="text" id="mt_name" name="name" required placeholder="Victoria Smith">
            </div>
            <div class="mt-form-group">
              <label for="mt_phone">Phone Number *</label>
              <input type="tel" id="mt_phone" name="phone" required placeholder="0117 000 0000">
            </div>
            <div class="mt-form-group mt-full">
              <label for="mt_email">Email Address *</label>
              <input type="email" id="mt_email" name="email" required placeholder="victoria@email.com">
            </div>
            <div class="mt-form-group">
              <label for="mt_instrument">Instrument / Subject *</label>
              <select id="mt_instrument" name="instrument" required>
                <option value="">— Select —</option>
                <option>Piano</option>
                <option>Violin</option>
                <option>Music Theory</option>
                <option>Composition</option>
                <option>Ear Training</option>
                <option>Multiple / Unsure</option>
              </select>
            </div>
            <div class="mt-form-group">
              <label for="mt_level">Current Level *</label>
              <select id="mt_level" name="level" required>
                <option value="">— Select —</option>
                <option>Complete Beginner</option>
                <option>Early Beginner (Grade 1–2)</option>
                <option>Intermediate (Grade 3–5)</option>
                <option>Upper Intermediate (Grade 6–7)</option>
                <option>Advanced (Grade 8+)</option>
                <option>Diploma Level</option>
              </select>
            </div>
            <div class="mt-form-group mt-full">
              <label for="mt_goals">Your Musical Goals</label>
              <textarea id="mt_goals" name="goals" placeholder="Tell me what you'd like to achieve — exam targets, favourite repertoire, whether lessons are for you or your child..."></textarea>
            </div>
          </div>
          <button type="submit" class="mt-form-submit">🎹 Book My Trial Lesson (£25)</button>
          <p class="mt-form-note">🔒 Your details are kept private and never shared. I'll be in touch within 24 hours to arrange your trial.</p>
        </form>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

</div><!-- .mt-wrap -->

<script>
(function(){
  /* ── ANIMATED COUNTERS ── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  const counters = document.querySelectorAll('[data-target]');
  if (!counters.length) return;
  const obs = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const target = parseFloat(el.dataset.target);
      if (isNaN(target)) return;
      const suffix  = el.dataset.suffix || '';
      const isFloat = el.dataset.float === '1';
      const dur = 1800; let start = null;
      function tick(ts) {
        if (!start) start = ts;
        const prog = Math.min((ts - start) / dur, 1);
        const val  = easeOut(prog) * target;
        el.textContent = (isFloat ? val.toFixed(1) : Math.floor(val).toLocaleString()) + suffix;
        if (prog < 1) requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
      obs.unobserve(el);
    });
  }, { threshold: 0.5 });
  counters.forEach(c => obs.observe(c));

  /* ── FAQ ACCORDION ── */
  document.querySelectorAll('.mt-faq-q').forEach(q => {
    q.addEventListener('click', () => {
      const item = q.parentElement;
      const ans  = item.querySelector('.mt-faq-a');
      const open = item.classList.contains('mt-open');
      document.querySelectorAll('.mt-faq-item.mt-open').forEach(o => {
        o.classList.remove('mt-open');
        o.querySelector('.mt-faq-a').style.maxHeight = '0';
      });
      if (!open) { item.classList.add('mt-open'); ans.style.maxHeight = ans.scrollHeight + 'px'; }
    });
  });

  /* ── SCROLL REVEAL ── */
  const reveals = document.querySelectorAll('.mt-instr-card,.mt-lesson-card,.mt-process-step,.mt-testimonial,.mt-package');
  const revObs  = new IntersectionObserver(entries => {
    entries.forEach((e, i) => {
      if (e.isIntersecting) {
        setTimeout(() => {
          e.target.style.opacity   = '1';
          e.target.style.transform = e.target.classList.contains('mt-package-featured') ? 'scale(1.03)' : 'translateY(0)';
        }, (i % 4) * 80);
        revObs.unobserve(e.target);
      }
    });
  }, { threshold: 0.1 });
  reveals.forEach(r => {
    r.style.opacity   = '0';
    r.style.transform = r.classList.contains('mt-package-featured') ? 'scale(0.98)' : 'translateY(22px)';
    r.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    revObs.observe(r);
  });

  /* ── SMOOTH SCROLL ── */
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const target = document.querySelector(a.getAttribute('href'));
      if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    });
  });
})();
</script>

<?php get_footer(); ?>
