<?php
/**
 * Template Name: Nonprofit & Charity Homepage
 * Template Post Type: page
 *
 * Premium Nonprofit & Charity homepage: CSS globe/network hero with floating
 * impact cards, animated stats bar (lives/countries/volunteers/years),
 * 4 cause cards (Education/Water/Food/Health) with unique CSS art, 3-step
 * donation flow, 3-tier giving tiers, programs with funding progress bars,
 * volunteer CTA section, upcoming events strip, beneficiary testimonials,
 * partner logo marquee, newsletter CTA.
 *
 * @package ThemeFlex
 * @since 3.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

/* ── Color tokens (warm amber + teal on near-black) ────────────────────── */
$np_amber  = '#f59e0b';
$np_teal   = '#0d9488';
$np_rose   = '#fb7185';
$np_green  = '#4ade80';

/* ── PHP-generated bar-chart heights for programs section ──────────────── */
$program_funds = [
	[ 'name' => 'Clean Water Wells', 'pct' => 74, 'raised' => '148,000', 'goal' => '200,000', 'color' => $np_teal ],
	[ 'name' => 'School Meals 2025', 'pct' => 89, 'raised' => '267,000', 'goal' => '300,000', 'color' => $np_amber ],
	[ 'name' => 'Mobile Health Clinics', 'pct' => 52, 'raised' => '104,000', 'goal' => '200,000', 'color' => $np_rose ],
];

/* ── Upcoming events ────────────────────────────────────────────────────── */
$np_events = [
	[ 'day' => '12', 'mon' => 'Jun', 'title' => 'Annual Gala Dinner',         'loc' => 'Vienna, Austria',   'type' => 'Fundraiser' ],
	[ 'day' => '21', 'mon' => 'Jun', 'title' => 'Community Run for Water',    'loc' => 'Berlin, Germany',   'type' => 'Event' ],
	[ 'day' => '04', 'mon' => 'Jul', 'title' => 'Volunteer Training Weekend', 'loc' => 'Online / Zoom',     'type' => 'Training' ],
	[ 'day' => '19', 'mon' => 'Jul', 'title' => 'Children's Art Auction',     'loc' => 'Munich, Germany',   'type' => 'Fundraiser' ],
];

/* ── Partner logos (text-based) ─────────────────────────────────────────── */
$np_partners = [ 'UNICEF Partner', 'WHO Alliance', 'GIZ', 'Welthungerhilfe', 'Médecins Sans Frontières', 'Save the Children', 'Oxfam', 'CARE International', 'Plan International', 'ActionAid' ];
?>

<!– ══════════════════════════════════════════════════════════════════════════
     NONPROFIT & CHARITY — INLINE STYLES
══════════════════════════════════════════════════════════════════════════ –>
<style>
/* ── Tokens ─────────────────────────────────────────────────────────────── */
:root {
	--np-amber:   #f59e0b;
	--np-amber-d: #d97706;
	--np-teal:    #0d9488;
	--np-teal-d:  #0f766e;
	--np-rose:    #fb7185;
	--np-green:   #4ade80;
	--np-bg:      #0c0a09;
	--np-surface: #1c1917;
	--np-card:    #292524;
	--np-border:  rgba(245,158,11,.12);
	--np-text:    #f5f5f4;
	--np-muted:   #a8a29e;
	--np-r:       12px;
}

/* ── Base ───────────────────────────────────────────────────────────────── */
.np-page { background: var(--np-bg); color: var(--np-text); font-family: 'Inter Tight', sans-serif; line-height: 1.6; overflow-x: hidden; }
.np-wrap { max-width: 1160px; margin: 0 auto; padding: 0 24px; }
.np-section { padding: 96px 0; }
.np-label { display: inline-block; font-size: .72rem; font-weight: 700; letter-spacing: .14em; text-transform: uppercase; color: var(--np-amber); background: rgba(245,158,11,.1); border: 1px solid rgba(245,158,11,.25); border-radius: 40px; padding: 5px 14px; margin-bottom: 20px; }
.np-h2 { font-size: clamp(1.8rem, 4vw, 2.6rem); font-weight: 800; line-height: 1.15; margin: 0 0 16px; }
.np-lead { font-size: 1.05rem; color: var(--np-muted); max-width: 560px; }
.np-btn { display: inline-flex; align-items: center; gap: 8px; padding: 14px 28px; border-radius: 8px; font-size: .95rem; font-weight: 700; text-decoration: none; transition: all .2s; cursor: pointer; border: none; }
.np-btn-primary { background: var(--np-amber); color: #000; }
.np-btn-primary:hover { background: var(--np-amber-d); transform: translateY(-1px); }
.np-btn-outline { background: transparent; color: var(--np-text); border: 2px solid rgba(255,255,255,.2); }
.np-btn-outline:hover { border-color: var(--np-amber); color: var(--np-amber); }
.np-btn-teal { background: var(--np-teal); color: #fff; }
.np-btn-teal:hover { background: var(--np-teal-d); transform: translateY(-1px); }

/* ── Hero ───────────────────────────────────────────────────────────────── */
.np-hero { min-height: 100vh; display: grid; grid-template-columns: 1fr 1fr; align-items: center; gap: 60px; padding: 120px 0 80px; position: relative; overflow: hidden; }
.np-hero::before { content: ''; position: absolute; inset: 0; background: radial-gradient(ellipse 60% 80% at 70% 50%, rgba(13,148,136,.06) 0%, transparent 70%); pointer-events: none; }

.np-hero-content { position: relative; z-index: 2; }
.np-hero-badge { display: inline-flex; align-items: center; gap: 8px; background: rgba(13,148,136,.12); border: 1px solid rgba(13,148,136,.3); border-radius: 40px; padding: 6px 14px; font-size: .78rem; font-weight: 600; color: #5eead4; margin-bottom: 28px; }
.np-hero-badge-dot { width: 6px; height: 6px; background: #4ade80; border-radius: 50%; animation: np-pulse 2s ease-in-out infinite; }
.np-hero h1 { font-size: clamp(2.4rem, 5vw, 3.6rem); font-weight: 900; line-height: 1.1; margin: 0 0 20px; letter-spacing: -.02em; }
.np-hero h1 span { color: var(--np-amber); }
.np-hero-sub { font-size: 1.1rem; color: var(--np-muted); max-width: 480px; margin-bottom: 36px; }
.np-hero-ctas { display: flex; gap: 14px; flex-wrap: wrap; margin-bottom: 48px; }
.np-hero-stats { display: flex; gap: 32px; padding-top: 32px; border-top: 1px solid var(--np-border); }
.np-hero-stat-val { font-size: 1.6rem; font-weight: 800; color: var(--np-amber); }
.np-hero-stat-lbl { font-size: .75rem; color: var(--np-muted); }

/* ── Hero Visual (CSS globe/network) ────────────────────────────────────── */
.np-hero-visual { position: relative; display: flex; align-items: center; justify-content: center; height: 520px; }
.np-globe { position: relative; width: 320px; height: 320px; }
.np-globe-ring { position: absolute; border-radius: 50%; border: 1px solid rgba(13,148,136,.25); top: 50%; left: 50%; transform: translate(-50%, -50%); animation: np-ring-expand 4s ease-in-out infinite; }
.np-globe-ring:nth-child(1) { width: 100%; height: 100%; animation-delay: 0s; }
.np-globe-ring:nth-child(2) { width: 78%; height: 78%; animation-delay: .6s; border-color: rgba(245,158,11,.2); }
.np-globe-ring:nth-child(3) { width: 56%; height: 56%; animation-delay: 1.2s; border-color: rgba(251,113,133,.2); }

.np-globe-core { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 120px; height: 120px; border-radius: 50%; background: radial-gradient(circle, rgba(13,148,136,.4) 0%, rgba(13,148,136,.05) 70%); border: 2px solid rgba(13,148,136,.5); display: flex; align-items: center; justify-content: center; font-size: .7rem; font-weight: 700; color: #5eead4; letter-spacing: .06em; text-transform: uppercase; text-align: center; line-height: 1.3; }

/* Network dots on the rings */
.np-node { position: absolute; width: 10px; height: 10px; background: var(--np-amber); border-radius: 50%; box-shadow: 0 0 10px rgba(245,158,11,.6); }
<?php
$node_positions = [
	['top'=>'5%','left'=>'50%'],['top'=>'18%','left'=>'92%'],['top'=>'50%','left'=>'100%'],
	['top'=>'82%','left'=>'90%'],['top'=>'95%','left'=>'50%'],['top'=>'82%','left'=>'10%'],
	['top'=>'50%','left'=>'0%'],['top'=>'18%','left'=>'8%'],
];
foreach($node_positions as $i=>$pos):?>
.np-node:nth-child(<?php echo $i+5; ?>) { top: <?php echo $pos['top']; ?>; left: <?php echo $pos['left']; ?>; animation: np-node-pulse 3s ease-in-out infinite; animation-delay: <?php echo $i*.35; ?>s; }
<?php endforeach;?>

/* Floating stat cards around globe */
.np-float-card { position: absolute; background: var(--np-card); border: 1px solid var(--np-border); border-radius: 10px; padding: 12px 16px; display: flex; align-items: center; gap: 10px; animation: np-card-float 4s ease-in-out infinite; }
.np-float-card:nth-child(1) { top: 4%; left: -30px; animation-delay: 0s; }
.np-float-card:nth-child(2) { bottom: 16%; right: -30px; animation-delay: 1.5s; }
.np-float-card:nth-child(3) { bottom: 4%; left: 10%; animation-delay: .8s; }
.np-float-icon { width: 36px; height: 36px; border-radius: 8px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.np-float-card-val { font-size: 1.1rem; font-weight: 800; color: var(--np-text); }
.np-float-card-lbl { font-size: .7rem; color: var(--np-muted); }

@keyframes np-pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:.5;transform:scale(.8)} }
@keyframes np-ring-expand { 0%,100%{opacity:.4;transform:translate(-50%,-50%) scale(1)} 50%{opacity:.8;transform:translate(-50%,-50%) scale(1.04)} }
@keyframes np-node-pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:.4;transform:scale(.6)} }
@keyframes np-card-float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }

/* ── Impact Stats Bar ───────────────────────────────────────────────────── */
.np-stats-bar { background: var(--np-surface); border-top: 1px solid var(--np-border); border-bottom: 1px solid var(--np-border); padding: 52px 0; }
.np-stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 0; }
.np-stat-item { text-align: center; padding: 0 32px; position: relative; }
.np-stat-item + .np-stat-item::before { content: ''; position: absolute; left: 0; top: 20%; height: 60%; width: 1px; background: var(--np-border); }
.np-stat-num { font-size: 3rem; font-weight: 900; line-height: 1; letter-spacing: -.03em; }
.np-stat-num.amber { color: var(--np-amber); }
.np-stat-num.teal { color: var(--np-teal); }
.np-stat-num.rose { color: var(--np-rose); }
.np-stat-num.green { color: var(--np-green); }
.np-stat-suffix { font-size: 2rem; font-weight: 900; color: inherit; }
.np-stat-lbl { font-size: .8rem; color: var(--np-muted); margin-top: 6px; font-weight: 500; }

/* ── Causes Section ─────────────────────────────────────────────────────── */
.np-causes-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-top: 52px; }
.np-cause-card { background: var(--np-card); border: 1px solid var(--np-border); border-radius: var(--np-r); overflow: hidden; transition: border-color .25s, transform .25s; }
.np-cause-card:hover { border-color: var(--np-amber); transform: translateY(-4px); }
.np-cause-art { height: 160px; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden; }
.np-cause-body { padding: 20px; }
.np-cause-name { font-size: 1rem; font-weight: 700; margin: 0 0 6px; }
.np-cause-desc { font-size: .82rem; color: var(--np-muted); margin: 0 0 14px; line-height: 1.5; }
.np-cause-link { font-size: .8rem; font-weight: 700; color: var(--np-amber); text-decoration: none; display: inline-flex; align-items: center; gap: 5px; }

/* Cause CSS Art */
/* Education — Open book */
.np-art-edu { background: linear-gradient(135deg, #1e1b4b, #312e81); width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; }
.np-book { width: 80px; height: 64px; position: relative; }
.np-book-left { position: absolute; left: 0; top: 0; width: 38px; height: 64px; background: #6366f1; border-radius: 4px 0 0 4px; border-right: 3px solid #818cf8; }
.np-book-right { position: absolute; right: 0; top: 0; width: 38px; height: 64px; background: #818cf8; border-radius: 0 4px 4px 0; }
.np-book-line { position: absolute; left: 50%; transform: translateX(-50%); background: rgba(255,255,255,.25); height: 2px; width: 28px; }
.np-book-line:nth-child(1){ top: 20px; } .np-book-line:nth-child(2){ top: 30px; } .np-book-line:nth-child(3){ top: 40px; }
.np-book-star { position: absolute; top: -18px; left: 50%; transform: translateX(-50%); width: 12px; height: 12px; background: #fbbf24; clip-path: polygon(50% 0%,61% 35%,98% 35%,68% 57%,79% 91%,50% 70%,21% 91%,32% 57%,2% 35%,39% 35%); animation: np-star-spin 4s linear infinite; }
@keyframes np-star-spin { to{transform:translateX(-50%) rotate(360deg)} }

/* Water — Wave + drops */
.np-art-water { background: linear-gradient(135deg, #0c4a6e, #075985); width: 100%; height: 100%; display: flex; align-items: flex-end; justify-content: center; overflow: hidden; position: relative; }
.np-wave { position: absolute; bottom: 0; width: 200%; height: 60px; background: #0ea5e9; border-radius: 50% 50% 0 0; animation: np-wave-move 3s ease-in-out infinite; }
.np-wave2 { animation: np-wave-move 3s ease-in-out infinite reverse; opacity: .6; bottom: 8px; background: #38bdf8; }
@keyframes np-wave-move { 0%,100%{transform:translateX(-10%)} 50%{transform:translateX(-30%)} }
.np-drop { position: absolute; top: 30px; width: 18px; height: 24px; background: #7dd3fc; border-radius: 50% 50% 50% 50% / 60% 60% 40% 40%; animation: np-drop-fall 2s ease-in infinite; }
.np-drop:nth-child(2){left:38%;animation-delay:.5s;} .np-drop:nth-child(3){left:52%;animation-delay:1s;top:18px;}
@keyframes np-drop-fall { 0%{opacity:1;transform:translateY(0)} 80%{opacity:.3;transform:translateY(60px)} 100%{opacity:0;transform:translateY(60px)} }

/* Food — Bowl with steam */
.np-art-food { background: linear-gradient(135deg, #431407, #7c2d12); width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; position: relative; }
.np-bowl { width: 72px; height: 36px; background: #f97316; border-radius: 0 0 40px 40px; position: relative; }
.np-bowl::before { content: ''; position: absolute; top: -6px; left: -8px; right: -8px; height: 12px; background: #fb923c; border-radius: 50%; }
.np-bowl-rice { position: absolute; top: 4px; left: 50%; transform: translateX(-50%); width: 50px; height: 14px; background: #fef3c7; border-radius: 50%; }
.np-steam { position: absolute; width: 3px; background: transparent; top: -28px; animation: np-steam-rise 2.5s ease-in-out infinite; border-radius: 3px; }
.np-steam::before { content:''; position:absolute; width:12px; height:20px; border: 3px solid rgba(251,191,36,.4); border-radius: 0 12px 0 12px; top:0; left:-4px; }
.np-steam:nth-child(1){left:30%;animation-delay:0s;} .np-steam:nth-child(2){left:50%;animation-delay:.8s;} .np-steam:nth-child(3){left:70%;animation-delay:1.6s;}
@keyframes np-steam-rise { 0%{opacity:0;transform:translateY(0) scaleX(1)} 50%{opacity:1} 100%{opacity:0;transform:translateY(-30px) scaleX(1.5)} }

/* Health — Heartbeat cross */
.np-art-health { background: linear-gradient(135deg, #4c0519, #881337); width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; position: relative; }
.np-cross { width: 60px; height: 60px; position: relative; }
.np-cross-h { position: absolute; top: 50%; left: 0; width: 100%; height: 20px; background: #fb7185; border-radius: 4px; transform: translateY(-50%); }
.np-cross-v { position: absolute; left: 50%; top: 0; width: 20px; height: 100%; background: #fb7185; border-radius: 4px; transform: translateX(-50%); }
.np-heartbeat { position: absolute; bottom: 20px; left: 50%; transform: translateX(-50%); width: 90px; height: 24px; }
.np-heartbeat svg { width: 100%; height: 100%; }
.np-ecg-path { stroke: #f43f5e; stroke-width: 2; fill: none; stroke-dasharray: 120; stroke-dashoffset: 120; animation: np-ecg-draw 2s linear infinite; }
@keyframes np-ecg-draw { to{stroke-dashoffset:-120} }

/* ── How It Works ───────────────────────────────────────────────────────── */
.np-how-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 40px; margin-top: 52px; position: relative; }
.np-how-grid::before { content: ''; position: absolute; top: 36px; left: 18%; right: 18%; height: 1px; background: repeating-linear-gradient(90deg, var(--np-amber) 0, var(--np-amber) 8px, transparent 8px, transparent 20px); }
.np-how-step { text-align: center; padding: 32px 24px; background: var(--np-card); border: 1px solid var(--np-border); border-radius: var(--np-r); position: relative; }
.np-how-num { width: 56px; height: 56px; border-radius: 50%; background: var(--np-amber); color: #000; font-size: 1.2rem; font-weight: 900; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; position: relative; z-index: 1; }
.np-how-title { font-size: 1rem; font-weight: 700; margin: 0 0 8px; }
.np-how-desc { font-size: .83rem; color: var(--np-muted); line-height: 1.55; }

/* ── Donation Tiers ─────────────────────────────────────────────────────── */
.np-tiers-wrap { background: var(--np-surface); }
.np-tiers-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; margin-top: 52px; }
.np-tier { background: var(--np-card); border: 1px solid var(--np-border); border-radius: var(--np-r); padding: 36px 28px; transition: border-color .25s; position: relative; overflow: hidden; }
.np-tier.featured { border-color: var(--np-amber); background: linear-gradient(160deg, rgba(245,158,11,.06) 0%, var(--np-card) 60%); }
.np-tier-badge { position: absolute; top: 16px; right: 16px; background: var(--np-amber); color: #000; font-size: .68rem; font-weight: 800; letter-spacing: .06em; text-transform: uppercase; padding: 3px 10px; border-radius: 20px; }
.np-tier-icon { width: 52px; height: 52px; border-radius: 12px; display: flex; align-items: center; justify-content: center; margin-bottom: 20px; }
.np-tier-name { font-size: .8rem; font-weight: 700; text-transform: uppercase; letter-spacing: .1em; color: var(--np-muted); margin-bottom: 8px; }
.np-tier-price { font-size: 2.6rem; font-weight: 900; color: var(--np-text); line-height: 1; margin-bottom: 4px; }
.np-tier-price span { font-size: 1rem; font-weight: 500; color: var(--np-muted); }
.np-tier-impact { font-size: .82rem; color: var(--np-amber); font-weight: 600; margin: 12px 0 24px; }
.np-tier-perks { list-style: none; padding: 0; margin: 0 0 28px; display: flex; flex-direction: column; gap: 10px; }
.np-tier-perks li { font-size: .85rem; color: var(--np-muted); display: flex; align-items: flex-start; gap: 10px; }
.np-tier-perks li::before { content: '✓'; color: var(--np-green); font-weight: 700; flex-shrink: 0; margin-top: 1px; }
.np-tier-btn { display: block; text-align: center; padding: 13px; border-radius: 8px; font-size: .9rem; font-weight: 700; text-decoration: none; transition: all .2s; }
.np-tier-btn-outline { border: 2px solid rgba(255,255,255,.2); color: var(--np-text); }
.np-tier-btn-outline:hover { border-color: var(--np-amber); color: var(--np-amber); }
.np-tier-btn-amber { background: var(--np-amber); color: #000; }
.np-tier-btn-amber:hover { background: var(--np-amber-d); }

/* ── Programs ───────────────────────────────────────────────────────────── */
.np-programs-grid { display: flex; flex-direction: column; gap: 20px; margin-top: 52px; }
.np-program { background: var(--np-card); border: 1px solid var(--np-border); border-radius: var(--np-r); padding: 28px 32px; display: grid; grid-template-columns: 1fr auto; align-items: center; gap: 40px; }
.np-program-name { font-size: 1rem; font-weight: 700; margin-bottom: 6px; }
.np-program-meta { font-size: .8rem; color: var(--np-muted); margin-bottom: 14px; }
.np-progress-track { height: 8px; background: rgba(255,255,255,.08); border-radius: 99px; overflow: hidden; }
.np-progress-fill { height: 100%; border-radius: 99px; transition: width 1.2s cubic-bezier(.16,1,.3,1); width: 0; }
.np-program-amounts { text-align: right; }
.np-program-raised { font-size: 1.4rem; font-weight: 800; color: var(--np-amber); }
.np-program-goal { font-size: .8rem; color: var(--np-muted); }

/* ── Volunteer ──────────────────────────────────────────────────────────── */
.np-volunteer { background: var(--np-surface); }
.np-volunteer-inner { display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center; }
.np-vol-stats { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 32px 0; }
.np-vol-stat { background: var(--np-card); border: 1px solid var(--np-border); border-radius: var(--np-r); padding: 20px; text-align: center; }
.np-vol-stat-val { font-size: 1.8rem; font-weight: 800; color: var(--np-teal); }
.np-vol-stat-lbl { font-size: .75rem; color: var(--np-muted); }
.np-vol-form { background: var(--np-card); border: 1px solid var(--np-border); border-radius: var(--np-r); padding: 36px; }
.np-vol-form h3 { font-size: 1.2rem; font-weight: 700; margin: 0 0 24px; }
.np-field { margin-bottom: 16px; }
.np-field label { display: block; font-size: .78rem; font-weight: 600; color: var(--np-muted); margin-bottom: 6px; text-transform: uppercase; letter-spacing: .06em; }
.np-field input, .np-field select, .np-field textarea { width: 100%; background: var(--np-surface); border: 1px solid rgba(255,255,255,.1); border-radius: 8px; padding: 11px 14px; color: var(--np-text); font-size: .9rem; font-family: inherit; transition: border-color .2s; box-sizing: border-box; }
.np-field input:focus, .np-field select:focus, .np-field textarea:focus { outline: none; border-color: var(--np-amber); }
.np-field select option { background: #1c1917; }
.np-field-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.np-privacy { font-size: .75rem; color: var(--np-muted); margin-bottom: 16px; line-height: 1.4; }

/* ── Events ─────────────────────────────────────────────────────────────── */
.np-events-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; margin-top: 52px; }
.np-event { background: var(--np-card); border: 1px solid var(--np-border); border-radius: var(--np-r); padding: 20px 24px; display: flex; gap: 20px; align-items: flex-start; transition: border-color .2s; }
.np-event:hover { border-color: var(--np-amber); }
.np-event-date { background: var(--np-amber); color: #000; border-radius: 8px; width: 52px; height: 56px; display: flex; flex-direction: column; align-items: center; justify-content: center; flex-shrink: 0; }
.np-event-day { font-size: 1.4rem; font-weight: 900; line-height: 1; }
.np-event-mon { font-size: .65rem; font-weight: 700; text-transform: uppercase; }
.np-event-type { display: inline-block; font-size: .68rem; font-weight: 700; text-transform: uppercase; letter-spacing: .06em; background: rgba(245,158,11,.1); color: var(--np-amber); border-radius: 4px; padding: 2px 8px; margin-bottom: 6px; }
.np-event-title { font-size: .95rem; font-weight: 700; margin: 0 0 4px; }
.np-event-loc { font-size: .78rem; color: var(--np-muted); display: flex; align-items: center; gap: 4px; }

/* ── Testimonials ───────────────────────────────────────────────────────── */
.np-testi-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; margin-top: 52px; }
.np-testi { background: var(--np-card); border: 1px solid var(--np-border); border-radius: var(--np-r); padding: 32px; position: relative; }
.np-testi::before { content: '"'; position: absolute; top: 16px; right: 20px; font-size: 5rem; line-height: 1; color: rgba(245,158,11,.12); font-family: Georgia, serif; }
.np-testi-text { font-size: .88rem; color: var(--np-muted); line-height: 1.65; margin: 0 0 24px; font-style: italic; position: relative; z-index: 1; }
.np-testi-author { display: flex; align-items: center; gap: 12px; }
.np-testi-avatar { width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg, var(--np-teal), var(--np-amber)); display: flex; align-items: center; justify-content: center; font-size: .8rem; font-weight: 800; color: #fff; flex-shrink: 0; }
.np-testi-name { font-size: .88rem; font-weight: 700; }
.np-testi-loc { font-size: .75rem; color: var(--np-muted); }
.np-testi-badge { display: inline-block; font-size: .7rem; font-weight: 700; padding: 3px 10px; border-radius: 20px; margin-top: 12px; }

/* ── Partners Marquee ───────────────────────────────────────────────────── */
.np-partners-wrap { background: var(--np-surface); border-top: 1px solid var(--np-border); border-bottom: 1px solid var(--np-border); padding: 36px 0; overflow: hidden; position: relative; }
.np-partners-wrap::before, .np-partners-wrap::after { content: ''; position: absolute; top: 0; bottom: 0; width: 120px; z-index: 2; pointer-events: none; }
.np-partners-wrap::before { left: 0; background: linear-gradient(90deg, var(--np-surface), transparent); }
.np-partners-wrap::after { right: 0; background: linear-gradient(270deg, var(--np-surface), transparent); }
.np-partners-track { display: flex; gap: 60px; width: max-content; animation: np-logos-scroll 28s linear infinite; }
.np-partners-track:hover { animation-play-state: paused; }
@keyframes np-logos-scroll { from{transform:translateX(0)} to{transform:translateX(-50%)} }
.np-partner-item { font-size: .85rem; font-weight: 700; color: var(--np-muted); white-space: nowrap; letter-spacing: .04em; transition: color .2s; }
.np-partner-item:hover { color: var(--np-text); }

/* ── Newsletter CTA ─────────────────────────────────────────────────────── */
.np-cta { position: relative; overflow: hidden; text-align: center; padding: 100px 0; }
.np-cta::before { content: ''; position: absolute; inset: 0; background: radial-gradient(ellipse 60% 100% at 50% 0%, rgba(245,158,11,.12) 0%, transparent 70%); pointer-events: none; }
.np-cta-inner { position: relative; z-index: 1; max-width: 640px; margin: 0 auto; }
.np-cta h2 { font-size: clamp(2rem,4vw,2.8rem); font-weight: 900; margin: 0 0 16px; }
.np-cta h2 span { color: var(--np-amber); }
.np-cta p { font-size: 1rem; color: var(--np-muted); margin-bottom: 36px; }
.np-newsletter-form { display: flex; gap: 12px; max-width: 440px; margin: 0 auto; }
.np-newsletter-form input { flex: 1; background: var(--np-card); border: 1px solid var(--np-border); border-radius: 8px; padding: 13px 18px; color: var(--np-text); font-size: .9rem; font-family: inherit; }
.np-newsletter-form input:focus { outline: none; border-color: var(--np-amber); }
.np-cta-note { font-size: .75rem; color: var(--np-muted); margin-top: 14px; }

/* ── Responsive ─────────────────────────────────────────────────────────── */
@media(max-width:900px){
	.np-hero { grid-template-columns: 1fr; padding: 100px 0 60px; }
	.np-hero-visual { display: none; }
	.np-causes-grid { grid-template-columns: repeat(2,1fr); }
	.np-tiers-grid { grid-template-columns: 1fr; }
	.np-volunteer-inner { grid-template-columns: 1fr; gap: 40px; }
	.np-testi-grid { grid-template-columns: 1fr; }
	.np-stats-grid { grid-template-columns: repeat(2,1fr); gap: 24px; }
	.np-how-grid { grid-template-columns: 1fr; }
	.np-how-grid::before { display: none; }
	.np-events-grid { grid-template-columns: 1fr; }
	.np-program { grid-template-columns: 1fr; gap: 16px; }
	.np-program-amounts { text-align: left; }
}
@media(max-width:600px){
	.np-causes-grid { grid-template-columns: 1fr; }
	.np-hero h1 { font-size: 2.2rem; }
	.np-newsletter-form { flex-direction: column; }
}
</style>

<div class="np-page">

<?php /* ── HERO ──────────────────────────────────────────────────────────────── */ ?>
<section class="np-section" style="padding-top:0;padding-bottom:0;">
<div class="np-wrap">
<div class="np-hero">

	<div class="np-hero-content">
		<div class="np-hero-badge">
			<span class="np-hero-badge-dot"></span>
			<?php esc_html_e( 'Non-Profit Organisation · Est. 2005', 'themeflex' ); ?>
		</div>
		<h1><?php esc_html_e( 'Every Life', 'themeflex' ); ?><br><span><?php esc_html_e( 'Deserves Dignity', 'themeflex' ); ?></span></h1>
		<p class="np-hero-sub"><?php esc_html_e( 'We bring clean water, education, food, and healthcare to underserved communities across 42 countries. Join us in making real, measurable change.', 'themeflex' ); ?></p>
		<div class="np-hero-ctas">
			<a href="#donate" class="np-btn np-btn-primary">
				<?php echo tf_icon_get( 'heart', 18 ); ?>
				<?php esc_html_e( 'Donate Now', 'themeflex' ); ?>
			</a>
			<a href="#volunteer" class="np-btn np-btn-outline">
				<?php echo tf_icon_get( 'users', 18 ); ?>
				<?php esc_html_e( 'Volunteer', 'themeflex' ); ?>
			</a>
		</div>
		<div class="np-hero-stats">
			<div>
				<div class="np-hero-stat-val">2.4M+</div>
				<div class="np-hero-stat-lbl"><?php esc_html_e( 'Lives Changed', 'themeflex' ); ?></div>
			</div>
			<div>
				<div class="np-hero-stat-val">42</div>
				<div class="np-hero-stat-lbl"><?php esc_html_e( 'Countries', 'themeflex' ); ?></div>
			</div>
			<div>
				<div class="np-hero-stat-val">€18M</div>
				<div class="np-hero-stat-lbl"><?php esc_html_e( 'Raised in 2024', 'themeflex' ); ?></div>
			</div>
		</div>
	</div>

	<div class="np-hero-visual" aria-hidden="true">
		<?php /* Floating cards */ ?>
		<div class="np-float-card">
			<div class="np-float-icon" style="background:rgba(245,158,11,.12);">
				<?php echo tf_icon_get( 'droplets', 20, 'style="color:#f59e0b"' ); ?>
			</div>
			<div>
				<div class="np-float-card-val">14,200</div>
				<div class="np-float-card-lbl"><?php esc_html_e( 'Wells Built', 'themeflex' ); ?></div>
			</div>
		</div>
		<div class="np-float-card">
			<div class="np-float-icon" style="background:rgba(13,148,136,.12);">
				<?php echo tf_icon_get( 'graduation-cap', 20, 'style="color:#0d9488"' ); ?>
			</div>
			<div>
				<div class="np-float-card-val">320K</div>
				<div class="np-float-card-lbl"><?php esc_html_e( 'Children in School', 'themeflex' ); ?></div>
			</div>
		</div>
		<div class="np-float-card">
			<div class="np-float-icon" style="background:rgba(74,222,128,.12);">
				<?php echo tf_icon_get( 'trending-up', 20, 'style="color:#4ade80"' ); ?>
			</div>
			<div>
				<div class="np-float-card-val">94%</div>
				<div class="np-float-card-lbl"><?php esc_html_e( 'Funds to Programs', 'themeflex' ); ?></div>
			</div>
		</div>

		<?php /* Globe visualization */ ?>
		<div class="np-globe">
			<div class="np-globe-ring"></div>
			<div class="np-globe-ring"></div>
			<div class="np-globe-ring"></div>
			<?php for($n=0;$n<8;$n++): ?>
			<div class="np-node"></div>
			<?php endfor; ?>
			<div class="np-globe-core">Global<br>Network</div>
		</div>
	</div>

</div>
</div>
</section>

<?php /* ── IMPACT STATS BAR ─────────────────────────────────────────────────── */ ?>
<section class="np-stats-bar">
<div class="np-wrap">
	<div class="np-stats-grid">
		<div class="np-stat-item">
			<div class="np-stat-num amber" data-counter="2400000" data-suffix="+">0</div>
			<div class="np-stat-lbl"><?php esc_html_e( 'Lives Changed', 'themeflex' ); ?></div>
		</div>
		<div class="np-stat-item">
			<div class="np-stat-num teal" data-counter="42" data-suffix="">0</div>
			<div class="np-stat-lbl"><?php esc_html_e( 'Countries Reached', 'themeflex' ); ?></div>
		</div>
		<div class="np-stat-item">
			<div class="np-stat-num rose" data-counter="18500" data-suffix="+">0</div>
			<div class="np-stat-lbl"><?php esc_html_e( 'Volunteers Worldwide', 'themeflex' ); ?></div>
		</div>
		<div class="np-stat-item">
			<div class="np-stat-num green" data-counter="19" data-suffix=" Yrs">0</div>
			<div class="np-stat-lbl"><?php esc_html_e( 'Years of Impact', 'themeflex' ); ?></div>
		</div>
	</div>
</div>
</section>

<?php /* ── OUR CAUSES ───────────────────────────────────────────────────────── */ ?>
<section class="np-section">
<div class="np-wrap">
	<div class="np-label"><?php esc_html_e( 'Our Causes', 'themeflex' ); ?></div>
	<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;align-items:end;margin-bottom:0;">
		<h2 class="np-h2"><?php esc_html_e( 'Four Pillars of Change', 'themeflex' ); ?></h2>
		<p class="np-lead" style="justify-self:end;"><?php esc_html_e( 'We focus where the need is greatest — from literacy to lifesaving healthcare. Each program is evidence-based and locally led.', 'themeflex' ); ?></p>
	</div>
	<div class="np-causes-grid">

		<div class="np-cause-card">
			<div class="np-cause-art">
				<div class="np-art-edu">
					<div class="np-book">
						<div class="np-book-left"></div>
						<div class="np-book-right">
							<div class="np-book-line"></div>
							<div class="np-book-line"></div>
							<div class="np-book-line"></div>
						</div>
						<div class="np-book-star"></div>
					</div>
				</div>
			</div>
			<div class="np-cause-body">
				<div class="np-cause-name"><?php esc_html_e( 'Education', 'themeflex' ); ?></div>
				<p class="np-cause-desc"><?php esc_html_e( '320,000 children enrolled in school. We build classrooms, train teachers, and provide learning materials.', 'themeflex' ); ?></p>
				<a href="#" class="np-cause-link"><?php esc_html_e( 'Learn More', 'themeflex' ); ?> →</a>
			</div>
		</div>

		<div class="np-cause-card">
			<div class="np-cause-art">
				<div class="np-art-water">
					<div class="np-drop"></div>
					<div class="np-drop"></div>
					<div class="np-drop"></div>
					<div class="np-wave"></div>
					<div class="np-wave np-wave2"></div>
				</div>
			</div>
			<div class="np-cause-body">
				<div class="np-cause-name"><?php esc_html_e( 'Clean Water', 'themeflex' ); ?></div>
				<p class="np-cause-desc"><?php esc_html_e( '14,200 wells drilled in remote communities. Safe water access transforms health outcomes overnight.', 'themeflex' ); ?></p>
				<a href="#" class="np-cause-link"><?php esc_html_e( 'Learn More', 'themeflex' ); ?> →</a>
			</div>
		</div>

		<div class="np-cause-card">
			<div class="np-cause-art">
				<div class="np-art-food">
					<div class="np-steam"></div>
					<div class="np-steam"></div>
					<div class="np-steam"></div>
					<div class="np-bowl">
						<div class="np-bowl-rice"></div>
					</div>
				</div>
			</div>
			<div class="np-cause-body">
				<div class="np-cause-name"><?php esc_html_e( 'Food Security', 'themeflex' ); ?></div>
				<p class="np-cause-desc"><?php esc_html_e( '1.8 million meals served monthly through our school feeding programs and emergency food distribution.', 'themeflex' ); ?></p>
				<a href="#" class="np-cause-link"><?php esc_html_e( 'Learn More', 'themeflex' ); ?> →</a>
			</div>
		</div>

		<div class="np-cause-card">
			<div class="np-cause-art">
				<div class="np-art-health">
					<div class="np-cross">
						<div class="np-cross-h"></div>
						<div class="np-cross-v"></div>
					</div>
					<div class="np-heartbeat">
						<svg viewBox="0 0 90 24" xmlns="http://www.w3.org/2000/svg">
							<path class="np-ecg-path" d="M0,12 L15,12 L20,4 L25,20 L32,4 L38,20 L43,12 L90,12"/>
						</svg>
					</div>
				</div>
			</div>
			<div class="np-cause-body">
				<div class="np-cause-name"><?php esc_html_e( 'Healthcare', 'themeflex' ); ?></div>
				<p class="np-cause-desc"><?php esc_html_e( '48 mobile health clinics and 220,000 patient consultations annually in underserved rural areas.', 'themeflex' ); ?></p>
				<a href="#" class="np-cause-link"><?php esc_html_e( 'Learn More', 'themeflex' ); ?> →</a>
			</div>
		</div>

	</div>
</div>
</section>

<?php /* ── HOW IT WORKS ─────────────────────────────────────────────────────── */ ?>
<section class="np-section" style="background:var(--np-surface);border-top:1px solid var(--np-border);border-bottom:1px solid var(--np-border);">
<div class="np-wrap">
	<div style="text-align:center;margin-bottom:0;">
		<div class="np-label"><?php esc_html_e( 'Transparency', 'themeflex' ); ?></div>
		<h2 class="np-h2"><?php esc_html_e( 'Your Donation in Three Steps', 'themeflex' ); ?></h2>
		<p class="np-lead" style="margin:0 auto;"><?php esc_html_e( '94 cents of every euro you donate goes directly to programs. We publish full financials annually.', 'themeflex' ); ?></p>
	</div>
	<div class="np-how-grid">
		<div class="np-how-step">
			<div class="np-how-num">1</div>
			<div class="np-how-title"><?php esc_html_e( 'Choose a Cause', 'themeflex' ); ?></div>
			<p class="np-how-desc"><?php esc_html_e( 'Select the program that resonates with you — water, education, food, or health. Or give to where the need is greatest.', 'themeflex' ); ?></p>
		</div>
		<div class="np-how-step">
			<div class="np-how-num">2</div>
			<div class="np-how-title"><?php esc_html_e( 'Make a Secure Gift', 'themeflex' ); ?></div>
			<p class="np-how-desc"><?php esc_html_e( 'One-time or monthly giving options. All donations are secured by 256-bit encryption. Tax-deductible in the EU.', 'themeflex' ); ?></p>
		</div>
		<div class="np-how-step">
			<div class="np-how-num">3</div>
			<div class="np-how-title"><?php esc_html_e( 'See the Impact', 'themeflex' ); ?></div>
			<p class="np-how-desc"><?php esc_html_e( 'Receive quarterly impact reports showing exactly how your gift was used — with photos and stories from the field.', 'themeflex' ); ?></p>
		</div>
	</div>
</div>
</section>

<?php /* ── DONATION TIERS ───────────────────────────────────────────────────── */ ?>
<section class="np-section np-tiers-wrap" id="donate">
<div class="np-wrap">
	<div class="np-label"><?php esc_html_e( 'Give Monthly', 'themeflex' ); ?></div>
	<h2 class="np-h2"><?php esc_html_e( 'Choose Your Impact Level', 'themeflex' ); ?></h2>
	<p class="np-lead"><?php esc_html_e( 'Monthly giving is the most effective way to create lasting change. Cancel or adjust anytime.', 'themeflex' ); ?></p>

	<div class="np-tiers-grid">

		<div class="np-tier">
			<div class="np-tier-icon" style="background:rgba(13,148,136,.1);">
				<?php echo tf_icon_get( 'leaf', 22, 'style="color:#0d9488"' ); ?>
			</div>
			<div class="np-tier-name"><?php esc_html_e( 'Supporter', 'themeflex' ); ?></div>
			<div class="np-tier-price">€25<span>/<?php esc_html_e( 'month', 'themeflex' ); ?></span></div>
			<div class="np-tier-impact"><?php esc_html_e( 'Feeds 15 children for a month', 'themeflex' ); ?></div>
			<ul class="np-tier-perks">
				<li><?php esc_html_e( 'Quarterly impact newsletter', 'themeflex' ); ?></li>
				<li><?php esc_html_e( 'Tax deductible receipt', 'themeflex' ); ?></li>
				<li><?php esc_html_e( 'Access to donor portal', 'themeflex' ); ?></li>
			</ul>
			<a href="#" class="np-tier-btn np-tier-btn-outline"><?php esc_html_e( 'Start Giving', 'themeflex' ); ?></a>
		</div>

		<div class="np-tier featured">
			<div class="np-tier-badge"><?php esc_html_e( 'Most Popular', 'themeflex' ); ?></div>
			<div class="np-tier-icon" style="background:rgba(245,158,11,.1);">
				<?php echo tf_icon_get( 'star', 22, 'style="color:#f59e0b"' ); ?>
			</div>
			<div class="np-tier-name"><?php esc_html_e( 'Champion', 'themeflex' ); ?></div>
			<div class="np-tier-price">€75<span>/<?php esc_html_e( 'month', 'themeflex' ); ?></span></div>
			<div class="np-tier-impact"><?php esc_html_e( 'Sponsors a child's education for a term', 'themeflex' ); ?></div>
			<ul class="np-tier-perks">
				<li><?php esc_html_e( 'All Supporter benefits', 'themeflex' ); ?></li>
				<li><?php esc_html_e( 'Personal impact story updates', 'themeflex' ); ?></li>
				<li><?php esc_html_e( 'Annual field visit invitation', 'themeflex' ); ?></li>
				<li><?php esc_html_e( 'Named in our annual report', 'themeflex' ); ?></li>
			</ul>
			<a href="#" class="np-tier-btn np-tier-btn-amber"><?php esc_html_e( 'Become a Champion', 'themeflex' ); ?></a>
		</div>

		<div class="np-tier">
			<div class="np-tier-icon" style="background:rgba(251,113,133,.1);">
				<?php echo tf_icon_get( 'award', 22, 'style="color:#fb7185"' ); ?>
			</div>
			<div class="np-tier-name"><?php esc_html_e( 'Patron', 'themeflex' ); ?></div>
			<div class="np-tier-price">€250<span>/<?php esc_html_e( 'month', 'themeflex' ); ?></span></div>
			<div class="np-tier-impact"><?php esc_html_e( 'Funds a water well serving 200 people', 'themeflex' ); ?></div>
			<ul class="np-tier-perks">
				<li><?php esc_html_e( 'All Champion benefits', 'themeflex' ); ?></li>
				<li><?php esc_html_e( 'Dedicated impact manager', 'themeflex' ); ?></li>
				<li><?php esc_html_e( 'Naming rights on funded projects', 'themeflex' ); ?></li>
				<li><?php esc_html_e( 'Private field trip annually', 'themeflex' ); ?></li>
				<li><?php esc_html_e( 'Advisory Council membership', 'themeflex' ); ?></li>
			</ul>
			<a href="#" class="np-tier-btn np-tier-btn-outline"><?php esc_html_e( 'Become a Patron', 'themeflex' ); ?></a>
		</div>

	</div>
</div>
</section>

<?php /* ── PROGRAMS & FUNDING ───────────────────────────────────────────────── */ ?>
<section class="np-section">
<div class="np-wrap">
	<div class="np-label"><?php esc_html_e( 'Live Campaigns', 'themeflex' ); ?></div>
	<div style="display:flex;justify-content:space-between;align-items:flex-end;gap:24px;flex-wrap:wrap;">
		<h2 class="np-h2" style="margin:0;"><?php esc_html_e( 'Active Programs', 'themeflex' ); ?></h2>
		<a href="#" class="np-btn np-btn-outline" style="padding:10px 20px;font-size:.85rem;"><?php esc_html_e( 'All Programs', 'themeflex' ); ?> →</a>
	</div>
	<div class="np-programs-grid">
		<?php foreach ( $program_funds as $prog ) : ?>
		<div class="np-program">
			<div>
				<div class="np-program-name"><?php echo esc_html( $prog['name'] ); ?></div>
				<div class="np-program-meta">
					<?php
					printf(
						esc_html__( '%1$s%% funded · €%2$s raised of €%3$s goal', 'themeflex' ),
						esc_html( $prog['pct'] ),
						esc_html( $prog['raised'] ),
						esc_html( $prog['goal'] )
					);
					?>
				</div>
				<div class="np-progress-track">
					<div class="np-progress-fill" style="background:<?php echo esc_attr( $prog['color'] ); ?>;" data-width="<?php echo esc_attr( $prog['pct'] ); ?>"></div>
				</div>
			</div>
			<div class="np-program-amounts">
				<div class="np-program-raised">€<?php echo esc_html( $prog['raised'] ); ?></div>
				<div class="np-program-goal"><?php esc_html_e( 'of', 'themeflex' ); ?> €<?php echo esc_html( $prog['goal'] ); ?></div>
				<a href="#donate" class="np-btn np-btn-primary" style="margin-top:12px;padding:10px 18px;font-size:.82rem;"><?php esc_html_e( 'Donate', 'themeflex' ); ?></a>
			</div>
		</div>
		<?php endforeach; ?>
	</div>
</div>
</section>

<?php /* ── VOLUNTEER ────────────────────────────────────────────────────────── */ ?>
<section class="np-section np-volunteer" id="volunteer">
<div class="np-wrap">
<div class="np-volunteer-inner">

	<div class="np-vol-left">
		<div class="np-label"><?php esc_html_e( 'Get Involved', 'themeflex' ); ?></div>
		<h2 class="np-h2"><?php esc_html_e( 'Volunteer Your Skills', 'themeflex' ); ?></h2>
		<p class="np-lead"><?php esc_html_e( 'Our 18,500+ volunteers work in the field and remotely — engineers, doctors, teachers, creatives, and organizers all make a difference.', 'themeflex' ); ?></p>
		<div class="np-vol-stats">
			<div class="np-vol-stat">
				<div class="np-vol-stat-val">18,500+</div>
				<div class="np-vol-stat-lbl"><?php esc_html_e( 'Active Volunteers', 'themeflex' ); ?></div>
			</div>
			<div class="np-vol-stat">
				<div class="np-vol-stat-val">42</div>
				<div class="np-vol-stat-lbl"><?php esc_html_e( 'Countries', 'themeflex' ); ?></div>
			</div>
			<div class="np-vol-stat">
				<div class="np-vol-stat-val">340K</div>
				<div class="np-vol-stat-lbl"><?php esc_html_e( 'Volunteer Hours / Year', 'themeflex' ); ?></div>
			</div>
			<div class="np-vol-stat">
				<div class="np-vol-stat-val">4.9★</div>
				<div class="np-vol-stat-lbl"><?php esc_html_e( 'Volunteer Satisfaction', 'themeflex' ); ?></div>
			</div>
		</div>
		<div style="display:flex;gap:12px;flex-wrap:wrap;">
			<a href="#" class="np-btn np-btn-teal">
				<?php echo tf_icon_get( 'calendar', 18 ); ?>
				<?php esc_html_e( 'See Open Roles', 'themeflex' ); ?>
			</a>
			<a href="#" class="np-btn np-btn-outline"><?php esc_html_e( 'Learn More', 'themeflex' ); ?></a>
		</div>
	</div>

	<div class="np-vol-form">
		<h3><?php esc_html_e( 'Apply to Volunteer', 'themeflex' ); ?></h3>
		<form method="post" action="">
			<?php wp_nonce_field( 'tf_np_volunteer', 'tf_np_vol_nonce' ); ?>
			<div class="np-field-row">
				<div class="np-field">
					<label><?php esc_html_e( 'First Name', 'themeflex' ); ?></label>
					<input type="text" name="vol_first" placeholder="<?php esc_attr_e( 'Maria', 'themeflex' ); ?>" required>
				</div>
				<div class="np-field">
					<label><?php esc_html_e( 'Last Name', 'themeflex' ); ?></label>
					<input type="text" name="vol_last" placeholder="<?php esc_attr_e( 'Schmidt', 'themeflex' ); ?>" required>
				</div>
			</div>
			<div class="np-field">
				<label><?php esc_html_e( 'Email', 'themeflex' ); ?></label>
				<input type="email" name="vol_email" placeholder="<?php esc_attr_e( 'you@example.com', 'themeflex' ); ?>" required>
			</div>
			<div class="np-field">
				<label><?php esc_html_e( 'Area of Expertise', 'themeflex' ); ?></label>
				<select name="vol_skill">
					<option value=""><?php esc_html_e( 'Select your skill set', 'themeflex' ); ?></option>
					<option><?php esc_html_e( 'Healthcare / Medicine', 'themeflex' ); ?></option>
					<option><?php esc_html_e( 'Education / Teaching', 'themeflex' ); ?></option>
					<option><?php esc_html_e( 'Engineering / Construction', 'themeflex' ); ?></option>
					<option><?php esc_html_e( 'Communications / Marketing', 'themeflex' ); ?></option>
					<option><?php esc_html_e( 'Finance / Fundraising', 'themeflex' ); ?></option>
					<option><?php esc_html_e( 'Logistics / Operations', 'themeflex' ); ?></option>
					<option><?php esc_html_e( 'Other', 'themeflex' ); ?></option>
				</select>
			</div>
			<div class="np-field">
				<label><?php esc_html_e( 'Preferred Mode', 'themeflex' ); ?></label>
				<select name="vol_mode">
					<option><?php esc_html_e( 'Remote / Online', 'themeflex' ); ?></option>
					<option><?php esc_html_e( 'Field (On-Site)', 'themeflex' ); ?></option>
					<option><?php esc_html_e( 'Either / Flexible', 'themeflex' ); ?></option>
				</select>
			</div>
			<p class="np-privacy"><?php esc_html_e( 'Your data is used only for volunteer matching and kept strictly confidential. See our privacy policy.', 'themeflex' ); ?></p>
			<button type="submit" class="np-btn np-btn-teal" style="width:100%;justify-content:center;">
				<?php echo tf_icon_get( 'send', 16 ); ?>
				<?php esc_html_e( 'Submit Application', 'themeflex' ); ?>
			</button>
		</form>
	</div>

</div>
</div>
</section>

<?php /* ── EVENTS ───────────────────────────────────────────────────────────── */ ?>
<section class="np-section" style="border-top:1px solid var(--np-border);">
<div class="np-wrap">
	<div style="display:flex;justify-content:space-between;align-items:flex-end;flex-wrap:wrap;gap:16px;margin-bottom:52px;">
		<div>
			<div class="np-label"><?php esc_html_e( 'Upcoming', 'themeflex' ); ?></div>
			<h2 class="np-h2" style="margin:0;"><?php esc_html_e( 'Events & Fundraisers', 'themeflex' ); ?></h2>
		</div>
		<a href="#" class="np-btn np-btn-outline" style="padding:10px 20px;font-size:.85rem;"><?php esc_html_e( 'All Events', 'themeflex' ); ?> →</a>
	</div>
	<div class="np-events-grid">
		<?php foreach ( $np_events as $ev ) : ?>
		<div class="np-event">
			<div class="np-event-date">
				<span class="np-event-day"><?php echo esc_html( $ev['day'] ); ?></span>
				<span class="np-event-mon"><?php echo esc_html( $ev['mon'] ); ?></span>
			</div>
			<div>
				<span class="np-event-type"><?php echo esc_html( $ev['type'] ); ?></span>
				<div class="np-event-title"><?php echo esc_html( $ev['title'] ); ?></div>
				<div class="np-event-loc">
					<?php echo tf_icon_get( 'map-pin', 13, 'style="color:var(--np-amber)"' ); ?>
					<?php echo esc_html( $ev['loc'] ); ?>
				</div>
			</div>
		</div>
		<?php endforeach; ?>
	</div>
</div>
</section>

<?php /* ── TESTIMONIALS ─────────────────────────────────────────────────────── */ ?>
<section class="np-section" style="background:var(--np-surface);border-top:1px solid var(--np-border);border-bottom:1px solid var(--np-border);">
<div class="np-wrap">
	<div style="text-align:center;">
		<div class="np-label"><?php esc_html_e( 'Real Stories', 'themeflex' ); ?></div>
		<h2 class="np-h2"><?php esc_html_e( 'Voices from the Field', 'themeflex' ); ?></h2>
	</div>
	<div class="np-testi-grid">

		<div class="np-testi">
			<p class="np-testi-text"><?php esc_html_e( '"Before the well came to our village, my daughters walked three hours each day for water. Now they go to school. My youngest wants to be a doctor. That is your gift to us."', 'themeflex' ); ?></p>
			<div class="np-testi-author">
				<div class="np-testi-avatar">AK</div>
				<div>
					<div class="np-testi-name">Amara Kofi</div>
					<div class="np-testi-loc">Tamale, Ghana</div>
				</div>
			</div>
			<span class="np-testi-badge" style="background:rgba(13,148,136,.1);color:#0d9488;"><?php esc_html_e( 'Clean Water Program', 'themeflex' ); ?></span>
		</div>

		<div class="np-testi">
			<p class="np-testi-text"><?php esc_html_e( '"I was seven years old when the mobile clinic came. The doctor found my heart condition. Without the surgery they arranged, I would not be here. I am now studying medicine — to give others what I received."', 'themeflex' ); ?></p>
			<div class="np-testi-author">
				<div class="np-testi-avatar">LM</div>
				<div>
					<div class="np-testi-name">Luis Mendoza</div>
					<div class="np-testi-loc">Cochabamba, Bolivia</div>
				</div>
			</div>
			<span class="np-testi-badge" style="background:rgba(251,113,133,.1);color:#fb7185;"><?php esc_html_e( 'Healthcare Program', 'themeflex' ); ?></span>
		</div>

		<div class="np-testi">
			<p class="np-testi-text"><?php esc_html_e( '"The school meals meant I could concentrate. Before, I would fall asleep in class from hunger. Now I finished secondary school with top marks. I received a university scholarship last month."', 'themeflex' ); ?></p>
			<div class="np-testi-author">
				<div class="np-testi-avatar">FN</div>
				<div>
					<div class="np-testi-name">Fatuma Ndegwa</div>
					<div class="np-testi-loc">Kisumu, Kenya</div>
				</div>
			</div>
			<span class="np-testi-badge" style="background:rgba(245,158,11,.1);color:#f59e0b;"><?php esc_html_e( 'School Meals + Education', 'themeflex' ); ?></span>
		</div>

	</div>
</div>
</section>

<?php /* ── PARTNERS MARQUEE ─────────────────────────────────────────────────── */ ?>
<div class="np-partners-wrap">
	<div class="np-partners-track">
		<?php foreach ( array_merge( $np_partners, $np_partners ) as $partner ) : ?>
		<div class="np-partner-item"><?php echo esc_html( $partner ); ?></div>
		<?php endforeach; ?>
	</div>
</div>

<?php /* ── NEWSLETTER CTA ───────────────────────────────────────────────────── */ ?>
<section class="np-section np-cta">
<div class="np-wrap">
<div class="np-cta-inner">
	<div class="np-label"><?php esc_html_e( 'Stay Connected', 'themeflex' ); ?></div>
	<h2><?php esc_html_e( 'Join Our', 'themeflex' ); ?> <span><?php esc_html_e( 'Community of Change', 'themeflex' ); ?></span></h2>
	<p><?php esc_html_e( 'Get monthly impact updates, field stories, and event invitations. Join 140,000+ subscribers who care about the world.', 'themeflex' ); ?></p>
	<form class="np-newsletter-form" method="post" action="">
		<?php wp_nonce_field( 'tf_np_newsletter', 'tf_np_nl_nonce' ); ?>
		<input type="email" name="nl_email" placeholder="<?php esc_attr_e( 'Your email address', 'themeflex' ); ?>" required>
		<button type="submit" class="np-btn np-btn-primary"><?php esc_html_e( 'Subscribe', 'themeflex' ); ?></button>
	</form>
	<p class="np-cta-note"><?php esc_html_e( 'No spam. Unsubscribe anytime. Your data stays with us, always.', 'themeflex' ); ?></p>
	<div style="display:flex;gap:16px;justify-content:center;margin-top:32px;flex-wrap:wrap;">
		<a href="#" class="np-btn np-btn-primary" style="font-size:1rem;padding:16px 36px;">
			<?php echo tf_icon_get( 'heart', 18 ); ?>
			<?php esc_html_e( 'Donate Now', 'themeflex' ); ?>
		</a>
		<a href="#volunteer" class="np-btn np-btn-outline" style="font-size:1rem;padding:16px 36px;"><?php esc_html_e( 'Volunteer', 'themeflex' ); ?></a>
	</div>
</div>
</div>
</section>

</div><!-- .np-page -->

<script>
(function(){
'use strict';

/* ── Animated Counters ─────────────────────────────────────────────────── */
const easeOut = t => 1 - Math.pow(1 - t, 3);

const formatNum = (val) => {
	if (val >= 1000000) return (val / 1000000).toFixed(1).replace('.0','') + 'M';
	if (val >= 1000)    return (val / 1000).toFixed(0) + 'K';
	return val.toString();
};

const counters = document.querySelectorAll('[data-counter]');
if (counters.length && 'IntersectionObserver' in window) {
	const io = new IntersectionObserver((entries) => {
		entries.forEach(entry => {
			if (!entry.isIntersecting) return;
			io.unobserve(entry.target);
			const el  = entry.target;
			const end = parseInt(el.dataset.counter, 10);
			const sfx = el.dataset.suffix || '';
			const dur = 2000;
			let start = null;
			const step = ts => {
				if (!start) start = ts;
				const prog = Math.min((ts - start) / dur, 1);
				const val  = Math.round(easeOut(prog) * end);
				el.textContent = formatNum(val) + sfx;
				if (prog < 1) requestAnimationFrame(step);
			};
			requestAnimationFrame(step);
		});
	}, { threshold: 0.3 });
	counters.forEach(c => io.observe(c));
}

/* ── Funding Progress Bars ─────────────────────────────────────────────── */
const bars = document.querySelectorAll('.np-progress-fill');
if (bars.length && 'IntersectionObserver' in window) {
	const bio = new IntersectionObserver((entries) => {
		entries.forEach(entry => {
			if (!entry.isIntersecting) return;
			bio.unobserve(entry.target);
			const bar = entry.target;
			bar.style.width = bar.dataset.width + '%';
		});
	}, { threshold: 0.4 });
	bars.forEach(b => bio.observe(b));
}

})();
</script>

<?php get_footer(); ?>
