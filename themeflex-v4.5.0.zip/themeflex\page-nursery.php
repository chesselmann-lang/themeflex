<?php
/**
 * Template Name: Nursery – Garden Centre & Plant Nursery
 *
 * Premium page template for a Garden Centre & Plant Nursery business.
 * CSS art hero: glasshouse at golden hour – botanical greenhouse scene.
 * Namespace: --nur-*
 * Fonts: Cormorant Garamond (headings) + Nunito (body)
 *
 * @package ThemeFlex
 */
/* ── Seeded randomness ───────────────────────────────────────────── */
srand( crc32( get_the_permalink() ) );

/* ── Nonce ───────────────────────────────────────────────────────── */
$nur_nonce = wp_create_nonce( 'tf_nur_enquiry' );

/* ── Business data ───────────────────────────────────────────────── */
$business = [
    'name'     => 'Greenleaf Garden Centre',
    'tagline'  => 'Growing Beautiful Spaces Since 1987',
    'location' => 'Burford Road, Chipping Norton, Oxfordshire',
    'phone'    => '01608 645 200',
    'email'    => 'hello@greenleafgardencentre.co.uk',
    'hours'    => 'Mon–Sat 8:30–18:00 · Sun 10:00–17:00',
];

/* ── Stats ───────────────────────────────────────────────────────── */
$stats = [
    [ 'value' => 4500,  'suffix' => '+',  'label' => 'Plant Varieties' ],
    [ 'value' => 37,    'suffix' => '',   'label' => 'Years Est.' ],
    [ 'value' => 4.8,   'suffix' => '★',  'label' => 'Google Rating' ],
    [ 'value' => 28000, 'suffix' => '+',  'label' => 'Happy Customers' ],
];

/* ── Departments ─────────────────────────────────────────────────── */
$departments = [
    [
        'icon'  => '🌿',
        'title' => 'Hardy Plants',
        'desc'  => 'Perennials, grasses, ferns and ground-cover plants suited to British gardens, chosen for multi-season interest.',
        'badge' => '1,200+ varieties',
    ],
    [
        'icon'  => '🌸',
        'title' => 'Seasonal Bedding',
        'desc'  => 'Brilliant colour from spring through autumn — from tulip bulbs and pansies to summer fuchsias and winter cyclamen.',
        'badge' => 'Year-round colour',
    ],
    [
        'icon'  => '🌳',
        'title' => 'Trees & Shrubs',
        'desc'  => 'Specimen trees, hedging, ornamental shrubs and fruit trees, all container-grown for instant planting impact.',
        'badge' => 'Instant structure',
    ],
    [
        'icon'  => '🥦',
        'title' => 'Kitchen Garden',
        'desc'  => 'Vegetables, herbs, soft fruit, raised bed kits and seeds — everything you need to grow your own.',
        'badge' => 'Grow your own',
    ],
    [
        'icon'  => '🪴',
        'title' => 'Houseplants',
        'desc'  => 'Tropical foliage, cacti, succulents, orchids and statement floor plants for every interior style.',
        'badge' => 'Indoor living walls',
    ],
    [
        'icon'  => '🛖',
        'title' => 'Garden Living',
        'desc'  => 'Furniture, barbecues, outdoor lighting, pots, tools and garden décor from leading brands.',
        'badge' => 'Design & lifestyle',
    ],
];

/* ── Featured plants (CSS art rendered) ─────────────────────────── */
$featured = [
    [ 'css' => 'nur-plant-rose',       'name' => 'Rosa \'Boscobel\'',         'type' => 'Climbing Rose',       'price' => '£18.99', 'pot' => '3L',  'tag' => 'Bestseller' ],
    [ 'css' => 'nur-plant-hosta',      'name' => 'Hosta \'Halcyon\'',         'type' => 'Perennial',           'price' => '£12.50', 'pot' => '2L',  'tag' => '' ],
    [ 'css' => 'nur-plant-lavender',   'name' => 'Lavandula angustifolia',    'type' => 'Aromatic Shrub',      'price' => '£9.99',  'pot' => '9cm', 'tag' => 'RHS Award' ],
    [ 'css' => 'nur-plant-fern',       'name' => 'Dryopteris filix-mas',      'type' => 'Hardy Fern',          'price' => '£11.50', 'pot' => '2L',  'tag' => '' ],
    [ 'css' => 'nur-plant-agapanthus', 'name' => 'Agapanthus \'Midnight\'',   'type' => 'Summer Bulb',         'price' => '£16.99', 'pot' => '2L',  'tag' => 'Staff Pick' ],
    [ 'css' => 'nur-plant-bamboo',     'name' => 'Fargesia robusta \'Campbell\'','type' => 'Clumping Bamboo',  'price' => '£29.99', 'pot' => '5L',  'tag' => '' ],
];

/* ── CSS greenhouse panes (PHP-generated grid) ───────────────────── */
$gh_panes = [];
for ( $r = 0; $r < 4; $r++ ) {
    for ( $c = 0; $c < 6; $c++ ) {
        $gh_panes[] = [
            'r'    => $r,
            'c'    => $c,
            'lit'  => ( rand(0,10) > 2 ),
            'leaf' => ( rand(0,10) > 6 ),
        ];
    }
}

/* ── Floating botanical particles ────────────────────────────────── */
$particles = [];
$particle_shapes = ['leaf','petal','seed','spore'];
for ( $i = 0; $i < 28; $i++ ) {
    $particles[] = [
        'shape' => $particle_shapes[ array_rand($particle_shapes) ],
        'left'  => rand(2,98),
        'top'   => rand(5,90),
        'size'  => rand(8,22),
        'delay' => rand(0,60) / 10,
        'dur'   => rand(60,140) / 10,
        'rot'   => rand(0,360),
        'op'    => rand(15,55),
    ];
}

/* ── PHP flower/plant clumps in foreground ───────────────────────── */
$clumps = [];
$clump_types = ['tulip','daisy','grass','shrub'];
for ( $i = 0; $i < 12; $i++ ) {
    $clumps[] = [
        'type'  => $clump_types[ array_rand($clump_types) ],
        'left'  => rand(0,95),
        'color' => ['#e8a0b8','#f4c97a','#9fc87d','#c084c8','#f9a87d','#7ec8c8'][ rand(0,5) ],
    ];
}

/* ── Services ────────────────────────────────────────────────────── */
$services = [
    [
        'title' => 'Garden Design Consultations',
        'price' => 'From £95',
        'dur'   => '90 min',
        'desc'  => 'One-to-one sessions with our RHS-qualified designers, on-site or in our design studio.',
    ],
    [
        'title' => 'Planting & Installation',
        'price' => 'POA',
        'dur'   => 'Half or full day',
        'desc'  => 'Our horticultural team will plant borders, beds and containers to a professional standard.',
    ],
    [
        'title' => 'Plant Healthcare Clinic',
        'price' => 'Free',
        'dur'   => 'Drop-in daily',
        'desc'  => 'Bring in an ailing plant or photos of a problem — our experts will diagnose and prescribe.',
    ],
    [
        'title' => 'Workshops & Events',
        'price' => '£20–£65',
        'dur'   => 'Various',
        'desc'  => 'Wreath-making, pruning masterclasses, propagation days and children\'s planting sessions.',
    ],
];

/* ── Seasonal events ─────────────────────────────────────────────── */
$events = [
    [ 'date' => '10 May',  'name' => 'Chelsea Flower Show Inspiration Day', 'tag' => 'Talk' ],
    [ 'date' => '17 May',  'name' => 'Propagation from Cuttings Workshop',  'tag' => 'Workshop' ],
    [ 'date' => '24 May',  'name' => 'Children\'s Sunflower Planting Day',  'tag' => 'Family' ],
    [ 'date' => '07 Jun',  'name' => 'Roses — Pruning & Deadheading Clinic','tag' => 'Clinic' ],
    [ 'date' => '21 Jun',  'name' => 'Midsummer Twilight Garden Party',     'tag' => 'Event' ],
];

/* ── Testimonials ────────────────────────────────────────────────── */
$testimonials = [
    [
        'name'    => 'Patricia Winslow',
        'loc'     => 'Hook Norton',
        'stars'   => 5,
        'quote'   => 'Greenleaf transformed our overgrown plot into a garden we actually use. The planting advice was spot-on and every plant has thrived.',
        'subject' => 'Border planting consultation',
    ],
    [
        'name'    => 'Tom & Deborah Ashby',
        'loc'     => 'Chipping Norton',
        'stars'   => 5,
        'quote'   => 'The most knowledgeable staff of any garden centre we\'ve visited. They found us a rare Meconopsis that we\'d searched for years.',
        'subject' => 'Specialist plant sourcing',
    ],
    [
        'name'    => 'Helena Cross',
        'loc'     => 'Bourton-on-the-Water',
        'stars'   => 5,
        'quote'   => 'The Christmas wreaths workshop was magical. We left with beautiful handmade decorations and so many new skills.',
        'subject' => 'Seasonal workshop',
    ],
];

/* ── FAQ ─────────────────────────────────────────────────────────── */
$faqs = [
    [
        'q' => 'Do you offer a plant guarantee?',
        'a' => 'Yes — all plants purchased in-store carry a 12-month guarantee (with proof of purchase and evidence of proper care). We\'ll replace any plant that fails to establish under normal garden conditions.',
    ],
    [
        'q' => 'Can you source rare or unusual plants not in stock?',
        'a' => 'Absolutely. Our buying team has established relationships with specialist nurseries across the UK and Europe. Leave us your details via our Plant Search form and we\'ll do our best to track it down.',
    ],
    [
        'q' => 'Do you deliver large plants and trees?',
        'a' => 'Yes — we offer a local delivery and planting service for large specimen plants, trees and bulk orders. Delivery charges are calculated by distance; free delivery applies to orders over £250 within 10 miles.',
    ],
    [
        'q' => 'Are your plants peat-free?',
        'a' => 'Over 90% of our compost and growing media is now peat-free, ahead of the 2030 ban. All our own-grown stock is raised in peat-free media, and we label the remainder clearly on our shelves.',
    ],
    [
        'q' => 'What are the café opening hours?',
        'a' => 'The Potting Shed Café is open Mon–Sat 9:00–17:00 and Sun 10:30–16:30. We serve hot food until 14:30 daily, with homemade cakes, sandwiches and hot drinks available all day.',
    ],
];

/* ── Enquiry form ────────────────────────────────────────────────── */
$enquiry_types = [
    'Plant advice & sourcing',
    'Garden design consultation',
    'Planting & installation service',
    'Workshops & events',
    'School / community project',
    'Wholesale / trade',
    'General enquiry',
];
?>
?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,300;1,400&family=Nunito:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
/* ══════════════════════════════════════════════════════════════════
   NURSERY TEMPLATE — CSS CUSTOM PROPERTIES
   ══════════════════════════════════════════════════════════════════ */
:root {
    /* Brand palette — garden greens & earth tones */
    --nur-green-deep:   #2d5a27;
    --nur-green-mid:    #4a7c40;
    --nur-green-light:  #7cb873;
    --nur-green-pale:   #c8e6c2;
    --nur-earth:        #7a5c3a;
    --nur-earth-light:  #a8825a;
    --nur-cream:        #f9f6ef;
    --nur-warm-white:   #fefcf8;
    --nur-gold:         #d4a84b;
    --nur-gold-light:   #f0d080;
    --nur-blush:        #e8a0b0;
    --nur-sky:          #b8d8e8;
    --nur-sky-deep:     #6898b8;
    --nur-glass:        rgba(200,230,195,0.18);

    /* Typography */
    --nur-font-head: 'Cormorant Garamond', 'Georgia', serif;
    --nur-font-body: 'Nunito', 'Helvetica Neue', sans-serif;

    /* Spacing */
    --nur-section: clamp(64px,8vw,120px);
    --nur-radius:  12px;
    --nur-shadow:  0 8px 40px rgba(45,90,39,0.12);
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body.nur-page {
    font-family: var(--nur-font-body);
    font-size: 17px;
    line-height: 1.7;
    color: #2a2a1e;
    background: var(--nur-warm-white);
    overflow-x: hidden;
}

/* ── HERO ──────────────────────────────────────────────────────── */
.nur-hero {
    position: relative;
    width: 100%;
    min-height: 100vh;
    overflow: hidden;
    display: flex;
    align-items: center;
}

/* Sky gradient — golden hour */
.nur-sky {
    position: absolute;
    inset: 0;
    background: linear-gradient(
        175deg,
        #e8c87a 0%,
        #f0d890 12%,
        #d4e8c0 35%,
        #a8cca0 55%,
        #7aaa8a 75%,
        #5a8a6a 100%
    );
}

/* Sun disc */
.nur-sun {
    position: absolute;
    top: 8%;
    right: 18%;
    width: 80px;
    height: 80px;
    border-radius: 50%;
    background: radial-gradient(circle, #fff8d0 0%, #f8d060 35%, #e8a830 70%, rgba(232,168,48,0) 100%);
    box-shadow: 0 0 60px 30px rgba(248,200,80,0.5), 0 0 120px 60px rgba(248,200,80,0.25);
    animation: nur-sun-pulse 6s ease-in-out infinite;
}

@keyframes nur-sun-pulse {
    0%,100% { transform: scale(1); box-shadow: 0 0 60px 30px rgba(248,200,80,0.5), 0 0 120px 60px rgba(248,200,80,0.25); }
    50%      { transform: scale(1.04); box-shadow: 0 0 80px 40px rgba(248,200,80,0.6), 0 0 150px 75px rgba(248,200,80,0.3); }
}

/* Sun rays */
.nur-ray {
    position: absolute;
    top: 8%;
    right: 18%;
    width: 80px;
    height: 80px;
    animation: nur-ray-spin 30s linear infinite;
    transform-origin: center;
}
.nur-ray::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 160px;
    height: 2px;
    background: linear-gradient(90deg, rgba(255,240,160,0.7) 0%, rgba(255,240,160,0) 100%);
    transform-origin: 0 50%;
    transform: translateY(-50%);
    box-shadow: 0 120px 0 rgba(255,240,160,0.5), 0 -120px 0 rgba(255,240,160,0.5), 90px 90px 0 rgba(255,240,160,0.4), -90px 90px 0 rgba(255,240,160,0.4), 90px -90px 0 rgba(255,240,160,0.4);
}

@keyframes nur-ray-spin {
    from { transform: rotate(0deg); }
    to   { transform: rotate(360deg); }
}

/* Clouds */
.nur-cloud {
    position: absolute;
    border-radius: 50px;
    background: rgba(255,255,240,0.6);
    filter: blur(4px);
    animation: nur-cloud-drift linear infinite;
}
.nur-cloud::before, .nur-cloud::after {
    content: '';
    position: absolute;
    background: inherit;
    border-radius: 50%;
}
.nur-cloud-1 { width:120px;height:35px;top:10%;left:-140px;animation-duration:80s;animation-delay:-20s; }
.nur-cloud-1::before { width:70px;height:55px;top:-25px;left:20px; }
.nur-cloud-1::after  { width:50px;height:40px;top:-15px;left:60px; }
.nur-cloud-2 { width:90px;height:28px;top:17%;left:-110px;animation-duration:110s;animation-delay:-55s;opacity:0.7; }
.nur-cloud-2::before { width:55px;height:45px;top:-20px;left:15px; }
.nur-cloud-2::after  { width:40px;height:32px;top:-12px;left:45px; }
.nur-cloud-3 { width:140px;height:40px;top:6%;left:-165px;animation-duration:95s;animation-delay:-70s;opacity:0.5; }
.nur-cloud-3::before { width:80px;height:60px;top:-28px;left:25px; }
.nur-cloud-3::after  { width:60px;height:48px;top:-18px;left:70px; }
@keyframes nur-cloud-drift { from{left:-200px} to{left:110%} }

/* Greenhouse structure */
.nur-greenhouse {
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    width: min(780px,90vw);
    height: 380px;
}

/* Greenhouse base wall */
.nur-gh-base {
    position: absolute;
    bottom: 0;
    left: 5%;
    right: 5%;
    height: 90px;
    background: #c8b098;
    border-top: 6px solid #a89078;
}
.nur-gh-base::before {
    content: '';
    position: absolute;
    inset: 0;
    background: repeating-linear-gradient(
        90deg,
        transparent 0px, transparent 58px,
        rgba(0,0,0,0.12) 58px, rgba(0,0,0,0.12) 62px
    );
}

/* Greenhouse frame sides */
.nur-gh-frame {
    position: absolute;
    bottom: 90px;
    left: 5%;
    right: 5%;
    height: 230px;
    border-left: 5px solid #6a8a60;
    border-right: 5px solid #6a8a60;
    border-top: 5px solid #6a8a60;
}

/* Ridge beam */
.nur-gh-ridge {
    position: absolute;
    bottom: 318px;
    left: 50%;
    transform: translateX(-50%);
    width: 72%;
    height: 6px;
    background: #5a7a50;
    border-radius: 3px;
}

/* Pitched roof panels */
.nur-gh-roof-l {
    position: absolute;
    bottom: 318px;
    left: 5%;
    width: calc(45% - 2.5px);
    height: 0;
    border-bottom: 80px solid rgba(160,210,150,0.4);
    border-right: 20px solid transparent;
    border-left: 0;
}
.nur-gh-roof-r {
    position: absolute;
    bottom: 318px;
    right: 5%;
    width: calc(45% - 2.5px);
    height: 0;
    border-bottom: 80px solid rgba(160,210,150,0.4);
    border-left: 20px solid transparent;
    border-right: 0;
}

/* Greenhouse glass pane grid */
.nur-gh-panes {
    position: absolute;
    bottom: 90px;
    left: calc(5% + 5px);
    right: calc(5% + 5px);
    height: 230px;
    display: grid;
    grid-template-columns: repeat(6,1fr);
    grid-template-rows: repeat(4,1fr);
    gap: 4px;
    padding: 4px;
}
.nur-gh-pane {
    background: rgba(160,215,150,0.22);
    border: 1px solid rgba(100,150,90,0.4);
    border-radius: 1px;
    position: relative;
    overflow: hidden;
}
.nur-gh-pane.lit {
    background: rgba(240,250,200,0.35);
    box-shadow: inset 0 0 8px rgba(200,240,160,0.4);
}
.nur-gh-pane.leaf::after {
    content: '';
    position: absolute;
    bottom: 2px;
    left: 50%;
    transform: translateX(-50%);
    width: 18px;
    height: 22px;
    background: var(--nur-green-mid);
    border-radius: 0 50% 0 50%;
    opacity: 0.7;
}
/* Glass glare diagonal */
.nur-gh-pane::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 40%;
    height: 100%;
    background: linear-gradient(135deg, rgba(255,255,255,0.25) 0%, transparent 60%);
}

/* Greenhouse door */
.nur-gh-door {
    position: absolute;
    bottom: 90px;
    left: 50%;
    transform: translateX(-50%);
    width: 60px;
    height: 100px;
    background: rgba(120,180,100,0.3);
    border: 3px solid #6a8a60;
    border-bottom: none;
    border-radius: 30px 30px 0 0;
}
.nur-gh-door::after {
    content: '';
    position: absolute;
    top: 50%;
    right: 8px;
    width: 6px;
    height: 6px;
    background: var(--nur-gold);
    border-radius: 50%;
    transform: translateY(-50%);
}

/* Foreground ground */
.nur-ground {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 90px;
    background: linear-gradient(180deg, #5a8040 0%, #3d6030 100%);
}
.nur-ground::before {
    content: '';
    position: absolute;
    inset: 0;
    background: repeating-linear-gradient(
        90deg,
        transparent 0px, transparent 3px,
        rgba(0,0,0,0.07) 3px, rgba(0,0,0,0.08) 4px
    );
}

/* Path through greenhouse */
.nur-path {
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 80px;
    height: 90px;
    background: #c8b098;
    clip-path: polygon(10% 0%, 90% 0%, 100% 100%, 0% 100%);
}
.nur-path::before {
    content: '';
    position: absolute;
    inset: 0;
    background: repeating-linear-gradient(
        0deg,
        transparent 0px, transparent 14px,
        rgba(0,0,0,0.1) 14px, rgba(0,0,0,0.12) 16px
    );
}

/* Plant pots on ground */
.nur-pot {
    position: absolute;
    bottom: 90px;
}
.nur-pot-body {
    width: 28px;
    height: 24px;
    background: linear-gradient(135deg, #c87848 0%, #a05830 100%);
    border-radius: 2px 2px 6px 6px;
    clip-path: polygon(5% 0%, 95% 0%, 100% 100%, 0% 100%);
    position: relative;
}
.nur-pot-rim {
    width: 32px;
    height: 6px;
    background: #d88858;
    border-radius: 3px;
    margin: 0 -2px;
    position: relative;
    top: -26px;
}
.nur-pot-plant {
    position: absolute;
    top: -40px;
    left: 50%;
    transform: translateX(-50%);
    width: 24px;
    height: 36px;
}
.nur-pot-stem {
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 3px;
    height: 28px;
    background: var(--nur-green-mid);
    border-radius: 2px;
}
.nur-pot-bloom {
    position: absolute;
    top: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 22px;
    height: 22px;
    border-radius: 50%;
    background: radial-gradient(circle at 40% 35%, #f4a0c0 0%, #e06090 60%, #c04070 100%);
}
.nur-pot-leaf-l, .nur-pot-leaf-r {
    position: absolute;
    width: 16px;
    height: 10px;
    background: var(--nur-green-light);
    border-radius: 0 50% 50% 0;
    top: 14px;
}
.nur-pot-leaf-l { left: -10px; transform: rotate(-20deg); }
.nur-pot-leaf-r { right: -10px; transform: rotate(20deg) scaleX(-1); }

/* Botanical floating particles */
.nur-particle {
    position: absolute;
    pointer-events: none;
    animation: nur-particle-drift linear infinite;
}
.nur-particle.leaf {
    width: 12px;
    height: 18px;
    background: var(--nur-green-light);
    border-radius: 0 50% 0 50%;
}
.nur-particle.petal {
    width: 10px;
    height: 14px;
    background: var(--nur-blush);
    border-radius: 50% 0 50% 0;
}
.nur-particle.seed {
    width: 6px;
    height: 14px;
    background: var(--nur-gold);
    border-radius: 50%;
}
.nur-particle.spore {
    width: 5px;
    height: 5px;
    background: rgba(200,240,180,0.8);
    border-radius: 50%;
}
@keyframes nur-particle-drift {
    0%   { transform: translateY(20px) rotate(0deg); opacity: 0; }
    10%  { opacity: 1; }
    90%  { opacity: 1; }
    100% { transform: translateY(-80px) rotate(360deg); opacity: 0; }
}

/* Hero content */
.nur-hero-content {
    position: relative;
    z-index: 10;
    max-width: 1200px;
    margin: 0 auto;
    padding: 120px 48px 200px;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 48px;
    align-items: center;
}
.nur-hero-text { }
.nur-eyebrow {
    display: inline-block;
    font-family: var(--nur-font-body);
    font-size: 0.75rem;
    font-weight: 700;
    letter-spacing: 0.18em;
    text-transform: uppercase;
    color: var(--nur-green-deep);
    background: rgba(200,230,180,0.85);
    border: 1px solid rgba(100,160,80,0.4);
    padding: 6px 16px;
    border-radius: 20px;
    margin-bottom: 20px;
    backdrop-filter: blur(4px);
}
.nur-hero-h1 {
    font-family: var(--nur-font-head);
    font-size: clamp(2.8rem,5vw,4.4rem);
    font-weight: 300;
    line-height: 1.1;
    color: var(--nur-green-deep);
    margin-bottom: 12px;
    letter-spacing: -0.01em;
}
.nur-hero-h1 em {
    font-style: italic;
    color: var(--nur-earth);
}
.nur-hero-sub {
    font-family: var(--nur-font-head);
    font-size: clamp(1rem,1.6vw,1.25rem);
    font-style: italic;
    font-weight: 300;
    color: var(--nur-green-deep);
    opacity: 0.8;
    margin-bottom: 28px;
}
.nur-hero-desc {
    font-size: 1.05rem;
    color: #3a3a28;
    margin-bottom: 36px;
    max-width: 440px;
    background: rgba(255,255,250,0.7);
    padding: 16px 20px;
    border-radius: 8px;
    border-left: 3px solid var(--nur-green-mid);
    backdrop-filter: blur(4px);
}
.nur-hero-btns {
    display: flex;
    gap: 16px;
    flex-wrap: wrap;
}
.nur-btn-primary {
    display: inline-block;
    padding: 14px 32px;
    background: var(--nur-green-deep);
    color: #fff;
    font-family: var(--nur-font-body);
    font-size: 0.95rem;
    font-weight: 700;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    text-decoration: none;
    border-radius: var(--nur-radius);
    border: none;
    cursor: pointer;
    transition: background 0.25s, transform 0.2s, box-shadow 0.25s;
    box-shadow: 0 4px 18px rgba(45,90,39,0.3);
}
.nur-btn-primary:hover {
    background: var(--nur-green-mid);
    transform: translateY(-2px);
    box-shadow: 0 8px 28px rgba(45,90,39,0.35);
}
.nur-btn-outline {
    display: inline-block;
    padding: 13px 28px;
    background: rgba(255,255,250,0.85);
    color: var(--nur-green-deep);
    font-family: var(--nur-font-body);
    font-size: 0.95rem;
    font-weight: 600;
    text-decoration: none;
    border-radius: var(--nur-radius);
    border: 2px solid var(--nur-green-deep);
    cursor: pointer;
    transition: all 0.25s;
    backdrop-filter: blur(4px);
}
.nur-btn-outline:hover {
    background: var(--nur-green-deep);
    color: #fff;
}

/* Hero info panel */
.nur-hero-panel {
    background: rgba(255,255,250,0.88);
    border-radius: 16px;
    padding: 32px;
    backdrop-filter: blur(8px);
    border: 1px solid rgba(120,180,100,0.3);
    box-shadow: 0 16px 50px rgba(45,90,39,0.15);
}
.nur-panel-title {
    font-family: var(--nur-font-head);
    font-size: 1.5rem;
    font-weight: 500;
    color: var(--nur-green-deep);
    margin-bottom: 20px;
    padding-bottom: 12px;
    border-bottom: 2px solid var(--nur-green-pale);
}
.nur-opening-row {
    display: flex;
    gap: 12px;
    align-items: flex-start;
    margin-bottom: 14px;
}
.nur-opening-icon { font-size: 1.2rem; }
.nur-opening-text { font-size: 0.9rem; color: #444; }
.nur-opening-text strong { color: var(--nur-green-deep); font-weight: 700; }
.nur-status-open {
    display: inline-block;
    background: #d4f0c8;
    color: var(--nur-green-deep);
    font-size: 0.75rem;
    font-weight: 700;
    padding: 4px 12px;
    border-radius: 12px;
    margin-top: 16px;
    letter-spacing: 0.05em;
}
.nur-quick-links {
    margin-top: 20px;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
}
.nur-quick-link {
    display: block;
    padding: 10px 14px;
    background: var(--nur-cream);
    border: 1px solid var(--nur-green-pale);
    border-radius: 8px;
    text-decoration: none;
    font-size: 0.85rem;
    font-weight: 600;
    color: var(--nur-green-deep);
    text-align: center;
    transition: all 0.2s;
}
.nur-quick-link:hover {
    background: var(--nur-green-pale);
    border-color: var(--nur-green-mid);
}

/* ── STATS BAR ─────────────────────────────────────────────────── */
.nur-stats {
    background: var(--nur-green-deep);
    padding: 48px 48px;
}
.nur-stats-inner {
    max-width: 1200px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: repeat(4,1fr);
    gap: 32px;
    text-align: center;
}
.nur-stat-num {
    font-family: var(--nur-font-head);
    font-size: clamp(2.2rem,3.5vw,3rem);
    font-weight: 300;
    color: var(--nur-gold-light);
    line-height: 1;
    letter-spacing: -0.02em;
}
.nur-stat-label {
    font-size: 0.82rem;
    font-weight: 600;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    color: rgba(255,255,255,0.7);
    margin-top: 6px;
}

/* ── SECTION SHELL ─────────────────────────────────────────────── */
.nur-section {
    padding: var(--nur-section) 48px;
    max-width: 1200px;
    margin: 0 auto;
}
.nur-section-full {
    padding: var(--nur-section) 0;
    background: var(--nur-cream);
}
.nur-section-full .nur-section {
    padding-top: 0;
    padding-bottom: 0;
}
.nur-label {
    display: inline-block;
    font-size: 0.72rem;
    font-weight: 700;
    letter-spacing: 0.18em;
    text-transform: uppercase;
    color: var(--nur-green-mid);
    margin-bottom: 14px;
}
.nur-h2 {
    font-family: var(--nur-font-head);
    font-size: clamp(2rem,3.5vw,3rem);
    font-weight: 300;
    color: var(--nur-green-deep);
    line-height: 1.15;
    margin-bottom: 18px;
}
.nur-h2 em { font-style: italic; color: var(--nur-earth); }
.nur-lead {
    font-size: 1.05rem;
    color: #555;
    max-width: 600px;
    margin-bottom: 48px;
}

/* ── DEPARTMENTS ───────────────────────────────────────────────── */
.nur-dept-grid {
    display: grid;
    grid-template-columns: repeat(3,1fr);
    gap: 28px;
    margin-top: 48px;
}
.nur-dept-card {
    background: #fff;
    border: 1px solid #e0edd8;
    border-radius: var(--nur-radius);
    padding: 32px 28px;
    position: relative;
    transition: transform 0.25s, box-shadow 0.25s, border-color 0.25s;
}
.nur-dept-card:hover {
    transform: translateY(-4px);
    box-shadow: var(--nur-shadow);
    border-color: var(--nur-green-light);
}
.nur-dept-icon {
    font-size: 2.2rem;
    margin-bottom: 16px;
    display: block;
}
.nur-dept-badge {
    position: absolute;
    top: 16px;
    right: 16px;
    background: var(--nur-green-pale);
    color: var(--nur-green-deep);
    font-size: 0.7rem;
    font-weight: 700;
    padding: 4px 10px;
    border-radius: 10px;
    letter-spacing: 0.03em;
}
.nur-dept-title {
    font-family: var(--nur-font-head);
    font-size: 1.35rem;
    font-weight: 500;
    color: var(--nur-green-deep);
    margin-bottom: 10px;
}
.nur-dept-desc {
    font-size: 0.9rem;
    color: #555;
    line-height: 1.6;
}

/* ── FEATURED PLANTS ───────────────────────────────────────────── */
.nur-plants-grid {
    display: grid;
    grid-template-columns: repeat(3,1fr);
    gap: 24px;
    margin-top: 48px;
}
.nur-plant-card {
    background: #fff;
    border: 1px solid #e0edd8;
    border-radius: var(--nur-radius);
    overflow: hidden;
    transition: transform 0.25s, box-shadow 0.25s;
    position: relative;
}
.nur-plant-card:hover {
    transform: translateY(-4px);
    box-shadow: var(--nur-shadow);
}
.nur-plant-art {
    height: 200px;
    background: linear-gradient(160deg, #e8f5e0 0%, #c8e8b8 100%);
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
}
.nur-plant-tag {
    position: absolute;
    top: 12px;
    left: 12px;
    background: var(--nur-gold);
    color: #fff;
    font-size: 0.7rem;
    font-weight: 700;
    padding: 4px 10px;
    border-radius: 8px;
    letter-spacing: 0.04em;
    box-shadow: 0 2px 8px rgba(0,0,0,0.15);
}
.nur-plant-info {
    padding: 20px 22px;
}
.nur-plant-name {
    font-family: var(--nur-font-head);
    font-size: 1.15rem;
    font-weight: 500;
    font-style: italic;
    color: var(--nur-green-deep);
    margin-bottom: 4px;
}
.nur-plant-type {
    font-size: 0.8rem;
    color: #888;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    margin-bottom: 12px;
}
.nur-plant-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.nur-plant-price {
    font-size: 1.15rem;
    font-weight: 700;
    color: var(--nur-green-deep);
}
.nur-plant-pot {
    font-size: 0.78rem;
    color: #aaa;
    background: var(--nur-cream);
    padding: 4px 10px;
    border-radius: 8px;
}

/* CSS Plant art — Rose */
.nur-plant-rose .nur-stem {
    position: absolute;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    width: 4px;
    height: 90px;
    background: linear-gradient(180deg, #5a8a40 0%, #4a7a30 100%);
    border-radius: 2px;
}
.nur-plant-rose .nur-leaf-l {
    position: absolute;
    bottom: 80px;
    left: calc(50% - 28px);
    width: 28px;
    height: 16px;
    background: #7ab860;
    border-radius: 0 50% 50% 0;
    transform: rotate(-25deg);
}
.nur-plant-rose .nur-leaf-r {
    position: absolute;
    bottom: 60px;
    left: calc(50% + 2px);
    width: 28px;
    height: 16px;
    background: #7ab860;
    border-radius: 50% 0 0 50%;
    transform: rotate(25deg);
}
.nur-plant-rose .nur-flower {
    position: absolute;
    bottom: 110px;
    left: 50%;
    transform: translateX(-50%);
    width: 52px;
    height: 48px;
}
.nur-rose-petal {
    position: absolute;
    width: 20px;
    height: 26px;
    background: radial-gradient(ellipse at 40% 30%, #f8b0c0 0%, #e8607a 70%, #c84060 100%);
    border-radius: 50% 50% 50% 0;
    top: 50%;
    left: 50%;
    transform-origin: 0 0;
}

/* CSS Plant art — Hosta */
.nur-plant-hosta .nur-hosta-leaf {
    position: absolute;
    width: 60px;
    height: 80px;
    background: linear-gradient(160deg, #8ac870 0%, #5a9040 100%);
    border-radius: 50% 50% 50% 50% / 60% 60% 40% 40%;
    transform-origin: bottom center;
}

/* CSS Plant art — Lavender */
.nur-plant-lavender .nur-lav-stem {
    position: absolute;
    width: 3px;
    background: #7a9a50;
    border-radius: 2px;
    bottom: 20px;
    transform-origin: bottom center;
}
.nur-plant-lavender .nur-lav-spike {
    position: absolute;
    top: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 10px;
    height: 30px;
    background: linear-gradient(180deg, #8060a0 0%, #9878c0 100%);
    border-radius: 5px 5px 2px 2px;
}

/* CSS Plant art — Fern */
.nur-plant-fern .nur-fern-frond {
    position: absolute;
    width: 6px;
    background: linear-gradient(180deg, #6aaa50 0%, #4a8a30 100%);
    border-radius: 3px;
    transform-origin: bottom center;
    bottom: 20px;
}
.nur-plant-fern .nur-fern-frond::before,
.nur-plant-fern .nur-fern-frond::after {
    content: '';
    position: absolute;
    width: 22px;
    height: 10px;
    background: #6aaa50;
    border-radius: 0 50% 50% 0;
    top: 30%;
}
.nur-plant-fern .nur-fern-frond::before { right: 4px; transform: rotate(-35deg); }
.nur-plant-fern .nur-fern-frond::after  { left: 4px; transform: rotate(35deg) scaleX(-1); }

/* CSS Plant art — Agapanthus */
.nur-plant-agapanthus .nur-aga-stem {
    position: absolute;
    width: 4px;
    height: 100px;
    background: #6a9a50;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    border-radius: 2px;
}
.nur-plant-agapanthus .nur-aga-head {
    position: absolute;
    bottom: 118px;
    left: 50%;
    transform: translateX(-50%);
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: radial-gradient(circle at center, #7070d0 0%, #5050b0 60%, #3030a0 100%);
}

/* CSS Plant art — Bamboo */
.nur-plant-bamboo .nur-bam-cane {
    position: absolute;
    width: 8px;
    background: linear-gradient(90deg, #8ab870 0%, #6a9850 50%, #8ab870 100%);
    bottom: 10px;
    border-radius: 4px;
}
.nur-plant-bamboo .nur-bam-node {
    position: absolute;
    left: -2px;
    right: -2px;
    height: 3px;
    background: #5a8840;
    border-radius: 2px;
}
.nur-plant-bamboo .nur-bam-leaf {
    position: absolute;
    width: 28px;
    height: 8px;
    background: #7ab860;
    border-radius: 0 50% 50% 0;
    transform-origin: left center;
}

/* ── SERVICES ──────────────────────────────────────────────────── */
.nur-services-grid {
    display: grid;
    grid-template-columns: repeat(2,1fr);
    gap: 24px;
    margin-top: 48px;
}
.nur-svc-card {
    background: #fff;
    border-radius: var(--nur-radius);
    border: 1px solid #e0edd8;
    padding: 32px;
    display: grid;
    grid-template-columns: 1fr auto;
    gap: 16px;
    position: relative;
    transition: transform 0.25s, box-shadow 0.25s;
}
.nur-svc-card:hover {
    transform: translateY(-3px);
    box-shadow: var(--nur-shadow);
}
.nur-svc-title {
    font-family: var(--nur-font-head);
    font-size: 1.25rem;
    font-weight: 500;
    color: var(--nur-green-deep);
    margin-bottom: 8px;
    grid-column: 1;
}
.nur-svc-desc {
    font-size: 0.9rem;
    color: #666;
    grid-column: 1;
    line-height: 1.6;
}
.nur-svc-meta {
    grid-column: 2;
    grid-row: 1 / 3;
    text-align: right;
}
.nur-svc-price {
    font-family: var(--nur-font-head);
    font-size: 1.3rem;
    font-weight: 600;
    color: var(--nur-earth);
    display: block;
}
.nur-svc-dur {
    font-size: 0.78rem;
    color: #aaa;
    display: block;
    margin-top: 4px;
}

/* ── EVENTS ────────────────────────────────────────────────────── */
.nur-events-list {
    margin-top: 40px;
    display: flex;
    flex-direction: column;
    gap: 16px;
}
.nur-event-row {
    display: grid;
    grid-template-columns: 80px 1fr auto;
    gap: 20px;
    align-items: center;
    background: #fff;
    border: 1px solid #e0edd8;
    border-radius: var(--nur-radius);
    padding: 20px 24px;
    transition: border-color 0.2s, transform 0.2s;
}
.nur-event-row:hover {
    border-color: var(--nur-green-light);
    transform: translateX(4px);
}
.nur-event-date {
    font-family: var(--nur-font-head);
    font-size: 1.05rem;
    font-weight: 600;
    color: var(--nur-green-deep);
    text-align: center;
    line-height: 1.2;
}
.nur-event-name {
    font-size: 0.97rem;
    font-weight: 600;
    color: #333;
}
.nur-event-badge {
    background: var(--nur-cream);
    color: var(--nur-earth);
    font-size: 0.72rem;
    font-weight: 700;
    padding: 5px 12px;
    border-radius: 10px;
    border: 1px solid #e0d0b8;
    white-space: nowrap;
    letter-spacing: 0.04em;
}

/* ── TESTIMONIALS ──────────────────────────────────────────────── */
.nur-testi-grid {
    display: grid;
    grid-template-columns: repeat(3,1fr);
    gap: 24px;
    margin-top: 48px;
}
.nur-testi-card {
    background: #fff;
    border: 1px solid #e0edd8;
    border-radius: var(--nur-radius);
    padding: 32px 28px;
    position: relative;
}
.nur-testi-stars {
    font-size: 1rem;
    color: var(--nur-gold);
    margin-bottom: 14px;
    letter-spacing: 2px;
}
.nur-testi-quote {
    font-family: var(--nur-font-head);
    font-size: 1.05rem;
    font-style: italic;
    font-weight: 300;
    color: #333;
    line-height: 1.65;
    margin-bottom: 20px;
}
.nur-testi-quote::before { content: '\201C'; }
.nur-testi-quote::after  { content: '\201D'; }
.nur-testi-author {
    font-size: 0.88rem;
    font-weight: 700;
    color: var(--nur-green-deep);
}
.nur-testi-detail {
    font-size: 0.78rem;
    color: #aaa;
    margin-top: 2px;
}
.nur-testi-subject {
    display: inline-block;
    margin-top: 12px;
    background: var(--nur-green-pale);
    color: var(--nur-green-deep);
    font-size: 0.72rem;
    font-weight: 600;
    padding: 4px 12px;
    border-radius: 10px;
}

/* ── FAQ ───────────────────────────────────────────────────────── */
.nur-faq-list {
    margin-top: 40px;
    display: flex;
    flex-direction: column;
    gap: 12px;
}
.nur-faq-item {
    background: #fff;
    border: 1px solid #e0edd8;
    border-radius: var(--nur-radius);
    overflow: hidden;
}
.nur-faq-q {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 24px;
    cursor: pointer;
    font-size: 1rem;
    font-weight: 600;
    color: var(--nur-green-deep);
    gap: 16px;
    user-select: none;
}
.nur-faq-q:hover { background: var(--nur-cream); }
.nur-faq-icon {
    width: 26px;
    height: 26px;
    border-radius: 50%;
    background: var(--nur-green-pale);
    color: var(--nur-green-deep);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.1rem;
    flex-shrink: 0;
    transition: transform 0.3s, background 0.2s;
    font-style: normal;
}
.nur-faq-item.open .nur-faq-icon {
    transform: rotate(45deg);
    background: var(--nur-green-deep);
    color: #fff;
}
.nur-faq-a {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.4s ease;
}
.nur-faq-a-inner {
    padding: 0 24px 20px;
    font-size: 0.95rem;
    color: #555;
    line-height: 1.7;
    border-top: 1px solid #e0edd8;
    padding-top: 16px;
}

/* ── FORM ──────────────────────────────────────────────────────── */
.nur-form-section {
    background: var(--nur-green-deep);
    padding: var(--nur-section) 48px;
}
.nur-form-inner {
    max-width: 1200px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: 1fr 1.6fr;
    gap: 64px;
    align-items: start;
}
.nur-form-intro .nur-h2 { color: var(--nur-gold-light); }
.nur-form-intro .nur-label { color: rgba(255,255,255,0.7); }
.nur-form-intro .nur-lead { color: rgba(255,255,255,0.75); margin-bottom: 32px; }
.nur-form-detail {
    display: flex;
    gap: 12px;
    align-items: flex-start;
    margin-bottom: 16px;
    color: rgba(255,255,255,0.8);
    font-size: 0.9rem;
}
.nur-form-detail-icon { font-size: 1.1rem; flex-shrink: 0; }

.nur-form {
    background: rgba(255,255,255,0.06);
    border: 1px solid rgba(255,255,255,0.15);
    border-radius: 16px;
    padding: 40px;
    backdrop-filter: blur(10px);
}
.nur-form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 18px;
    margin-bottom: 18px;
}
.nur-form-group {
    display: flex;
    flex-direction: column;
    gap: 6px;
}
.nur-form-group.full { grid-column: 1 / -1; }
.nur-form-label {
    font-size: 0.78rem;
    font-weight: 700;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: rgba(255,255,255,0.8);
}
.nur-form-input,
.nur-form-select,
.nur-form-textarea {
    padding: 12px 16px;
    background: rgba(255,255,255,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    border-radius: 8px;
    color: #fff;
    font-family: var(--nur-font-body);
    font-size: 0.95rem;
    outline: none;
    transition: border-color 0.2s, background 0.2s;
}
.nur-form-input::placeholder,
.nur-form-textarea::placeholder { color: rgba(255,255,255,0.4); }
.nur-form-input:focus,
.nur-form-select:focus,
.nur-form-textarea:focus {
    border-color: var(--nur-gold);
    background: rgba(255,255,255,0.15);
}
.nur-form-select { cursor: pointer; }
.nur-form-select option { background: var(--nur-green-deep); color: #fff; }
.nur-form-textarea { resize: vertical; min-height: 110px; }
.nur-form-submit {
    width: 100%;
    padding: 16px;
    background: var(--nur-gold);
    color: var(--nur-green-deep);
    font-family: var(--nur-font-body);
    font-size: 1rem;
    font-weight: 800;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    border: none;
    border-radius: var(--nur-radius);
    cursor: pointer;
    margin-top: 8px;
    transition: background 0.25s, transform 0.2s;
    box-shadow: 0 4px 18px rgba(0,0,0,0.2);
}
.nur-form-submit:hover {
    background: var(--nur-gold-light);
    transform: translateY(-2px);
}
.nur-form-note {
    text-align: center;
    font-size: 0.8rem;
    color: rgba(255,255,255,0.5);
    margin-top: 14px;
}

/* ── CAFÉ STRIP ────────────────────────────────────────────────── */
.nur-cafe {
    background: var(--nur-earth);
    padding: 64px 48px;
    text-align: center;
    position: relative;
    overflow: hidden;
}
.nur-cafe::before {
    content: '';
    position: absolute;
    inset: 0;
    background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='60' height='60'%3E%3Ccircle cx='30' cy='30' r='1' fill='rgba(255,255,255,0.06)'/%3E%3C/svg%3E");
}
.nur-cafe-inner {
    position: relative;
    max-width: 700px;
    margin: 0 auto;
}
.nur-cafe h2 {
    font-family: var(--nur-font-head);
    font-size: clamp(1.8rem,3vw,2.6rem);
    font-weight: 300;
    color: #fff;
    margin-bottom: 14px;
}
.nur-cafe h2 em { font-style: italic; color: var(--nur-gold-light); }
.nur-cafe p {
    color: rgba(255,255,255,0.75);
    margin-bottom: 28px;
    font-size: 1.05rem;
}
.nur-cafe-hours {
    display: inline-flex;
    gap: 32px;
    background: rgba(255,255,255,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    border-radius: 12px;
    padding: 16px 28px;
    color: rgba(255,255,255,0.9);
    font-size: 0.88rem;
    font-weight: 600;
}

/* ── ANIMATIONS ────────────────────────────────────────────────── */
.nur-fade-up {
    opacity: 0;
    transform: translateY(30px);
    transition: opacity 0.65s ease, transform 0.65s ease;
}
.nur-fade-up.visible {
    opacity: 1;
    transform: none;
}

/* ── RESPONSIVE ────────────────────────────────────────────────── */
@media (max-width:1024px) {
    .nur-hero-content   { grid-template-columns: 1fr; padding: 100px 32px 220px; }
    .nur-stats-inner    { grid-template-columns: repeat(2,1fr); }
    .nur-dept-grid      { grid-template-columns: repeat(2,1fr); }
    .nur-plants-grid    { grid-template-columns: repeat(2,1fr); }
    .nur-testi-grid     { grid-template-columns: repeat(2,1fr); }
    .nur-form-inner     { grid-template-columns: 1fr; }
    .nur-greenhouse     { width: min(680px,95vw); height: 340px; }
}
@media (max-width:680px) {
    .nur-section        { padding: 60px 20px; }
    .nur-stats-inner    { grid-template-columns: repeat(2,1fr); gap: 20px; }
    .nur-dept-grid      { grid-template-columns: 1fr; }
    .nur-plants-grid    { grid-template-columns: 1fr; }
    .nur-services-grid  { grid-template-columns: 1fr; }
    .nur-testi-grid     { grid-template-columns: 1fr; }
    .nur-form-grid      { grid-template-columns: 1fr; }
    .nur-event-row      { grid-template-columns: 70px 1fr; }
    .nur-event-row > :last-child { grid-column: 2; }
    .nur-greenhouse     { width: 100%; height: 280px; }
    .nur-form-section   { padding: 60px 20px; }
    .nur-cafe           { padding: 48px 20px; }
    .nur-cafe-hours     { flex-direction: column; gap: 12px; }
}
</style>
<?php get_header(); ?>

<div class="">

>
<?php wp_body_open(); ?>

<!-- ═══════════════════════════════════════════════════════════════
     HERO — GREENHOUSE AT GOLDEN HOUR
     ═══════════════════════════════════════════════════════════════ -->
<section class="nur-hero" aria-label="Hero">

    <!-- Sky backdrop -->
    <div class="nur-sky" aria-hidden="true"></div>

    <!-- Sun -->
    <div class="nur-sun" aria-hidden="true"></div>
    <div class="nur-ray" aria-hidden="true"></div>

    <!-- Clouds -->
    <div class="nur-cloud nur-cloud-1" aria-hidden="true"></div>
    <div class="nur-cloud nur-cloud-2" aria-hidden="true"></div>
    <div class="nur-cloud nur-cloud-3" aria-hidden="true"></div>

    <!-- Botanical particles -->
    <?php foreach ( $particles as $i => $p ) : ?>
    <div class="nur-particle <?php echo esc_attr($p['shape']); ?>"
         aria-hidden="true"
         style="
             left:<?php echo $p['left']; ?>%;
             top:<?php echo $p['top']; ?>%;
             width:<?php echo $p['size']; ?>px;
             height:<?php echo ($p['size'] * 1.4); ?>px;
             opacity:<?php echo $p['op'] / 100; ?>;
             animation-duration:<?php echo $p['dur']; ?>s;
             animation-delay:-<?php echo $p['delay']; ?>s;
             transform:rotate(<?php echo $p['rot']; ?>deg);
         "></div>
    <?php endforeach; ?>

    <!-- Greenhouse structure -->
    <div class="nur-greenhouse" aria-hidden="true">

        <!-- Roof panels -->
        <div class="nur-gh-roof-l"></div>
        <div class="nur-gh-roof-r"></div>
        <div class="nur-gh-ridge"></div>

        <!-- Frame -->
        <div class="nur-gh-frame"></div>

        <!-- Glass panes -->
        <div class="nur-gh-panes">
            <?php foreach ( $gh_panes as $pane ) : ?>
            <div class="nur-gh-pane<?php echo $pane['lit'] ? ' lit' : ''; ?><?php echo $pane['leaf'] ? ' leaf' : ''; ?>"></div>
            <?php endforeach; ?>
        </div>

        <!-- Door -->
        <div class="nur-gh-door"></div>

        <!-- Base wall -->
        <div class="nur-gh-base"></div>
    </div>

    <!-- Ground -->
    <div class="nur-ground" aria-hidden="true">
        <div class="nur-path"></div>
        <!-- Plant pots either side -->
        <div class="nur-pot" style="left:5%;bottom:90px;" aria-hidden="true">
            <div class="nur-pot-plant">
                <div class="nur-pot-stem"></div>
                <div class="nur-pot-bloom" style="background:radial-gradient(circle at 40% 35%,#f8e060 0%,#e8b030 60%,#c88020 100%);"></div>
                <div class="nur-pot-leaf-l"></div>
                <div class="nur-pot-leaf-r"></div>
            </div>
            <div class="nur-pot-rim"></div>
            <div class="nur-pot-body"></div>
        </div>
        <div class="nur-pot" style="left:12%;bottom:90px;" aria-hidden="true">
            <div class="nur-pot-plant">
                <div class="nur-pot-stem"></div>
                <div class="nur-pot-bloom"></div>
                <div class="nur-pot-leaf-l"></div>
                <div class="nur-pot-leaf-r"></div>
            </div>
            <div class="nur-pot-rim"></div>
            <div class="nur-pot-body" style="background:linear-gradient(135deg,#b06040 0%,#884828 100%);"></div>
        </div>
        <div class="nur-pot" style="right:14%;bottom:90px;" aria-hidden="true">
            <div class="nur-pot-plant">
                <div class="nur-pot-stem"></div>
                <div class="nur-pot-bloom" style="background:radial-gradient(circle at 40% 35%,#c090e0 0%,#9060c0 60%,#7040a0 100%);"></div>
                <div class="nur-pot-leaf-l"></div>
                <div class="nur-pot-leaf-r"></div>
            </div>
            <div class="nur-pot-rim"></div>
            <div class="nur-pot-body"></div>
        </div>
        <div class="nur-pot" style="right:6%;bottom:90px;" aria-hidden="true">
            <div class="nur-pot-plant">
                <div class="nur-pot-stem"></div>
                <div class="nur-pot-bloom" style="background:radial-gradient(circle at 40% 35%,#80e080 0%,#50b050 60%,#308030 100%);"></div>
                <div class="nur-pot-leaf-l"></div>
                <div class="nur-pot-leaf-r"></div>
            </div>
            <div class="nur-pot-rim"></div>
            <div class="nur-pot-body" style="background:linear-gradient(135deg,#d09870 0%,#a87050 100%);"></div>
        </div>
    </div>

    <!-- Hero content -->
    <div class="nur-hero-content">
        <div class="nur-hero-text">
            <span class="nur-eyebrow">🌱 Chipping Norton, Oxfordshire</span>
            <h1 class="nur-hero-h1">
                Where gardens<br>
                <em>come to life</em>
            </h1>
            <p class="nur-hero-sub"><?php echo esc_html( $business['tagline'] ); ?></p>
            <p class="nur-hero-desc">
                <?php echo esc_html( $business['name'] ); ?> is one of the Cotswolds' most-loved independent garden centres —
                bursting with plants, expert advice and everything you need to create the garden you've always imagined.
            </p>
            <div class="nur-hero-btns">
                <a href="#departments" class="nur-btn-primary">Explore the Centre</a>
                <a href="#contact"     class="nur-btn-outline">Contact Us</a>
            </div>
        </div>

        <div class="nur-hero-panel">
            <div class="nur-panel-title">🏡 Visitor Information</div>

            <div class="nur-opening-row">
                <div class="nur-opening-icon">🕐</div>
                <div class="nur-opening-text">
                    <strong>Opening Hours</strong><br>
                    Mon–Sat: 8:30am – 6:00pm<br>
                    Sunday: 10:00am – 5:00pm
                </div>
            </div>
            <div class="nur-opening-row">
                <div class="nur-opening-icon">📍</div>
                <div class="nur-opening-text">
                    <strong>Location</strong><br>
                    <?php echo esc_html( $business['location'] ); ?>
                </div>
            </div>
            <div class="nur-opening-row">
                <div class="nur-opening-icon">☎️</div>
                <div class="nur-opening-text">
                    <strong>Call us</strong><br>
                    <a href="tel:<?php echo esc_attr( preg_replace('/\s+/','',$business['phone']) ); ?>"
                       style="color:var(--nur-green-deep);font-weight:700;">
                        <?php echo esc_html( $business['phone'] ); ?>
                    </a>
                </div>
            </div>

            <span class="nur-status-open">✓ Open Today</span>

            <div class="nur-quick-links">
                <a href="#plants"    class="nur-quick-link">🌸 Plants</a>
                <a href="#services"  class="nur-quick-link">✂️ Services</a>
                <a href="#events"    class="nur-quick-link">📅 Events</a>
                <a href="#contact"   class="nur-quick-link">📬 Enquire</a>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     STATS BAR
     ═══════════════════════════════════════════════════════════════ -->
<section class="nur-stats" aria-label="Key facts">
    <div class="nur-stats-inner">
        <?php foreach ( $stats as $st ) : ?>
        <div>
            <div class="nur-stat-num"
                 data-target="<?php echo esc_attr( $st['value'] ); ?>"
                 data-suffix="<?php echo esc_attr( $st['suffix'] ); ?>">
                <?php echo esc_html( $st['value'] . $st['suffix'] ); ?>
            </div>
            <div class="nur-stat-label"><?php echo esc_html( $st['label'] ); ?></div>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     DEPARTMENTS
     ═══════════════════════════════════════════════════════════════ -->
<div id="departments">
<section class="nur-section" aria-label="Our departments">
    <div class="nur-fade-up">
        <span class="nur-label">What we offer</span>
        <h2 class="nur-h2">Every corner of the <em>garden</em></h2>
        <p class="nur-lead">
            From hardy perennials to exotic houseplants, vegetable seeds to designer patio furniture —
            our six departments cover everything the passionate gardener needs.
        </p>
    </div>
    <div class="nur-dept-grid">
        <?php foreach ( $departments as $d ) : ?>
        <article class="nur-dept-card nur-fade-up">
            <span class="nur-dept-icon" aria-hidden="true"><?php echo $d['icon']; ?></span>
            <span class="nur-dept-badge"><?php echo esc_html( $d['badge'] ); ?></span>
            <h3 class="nur-dept-title"><?php echo esc_html( $d['title'] ); ?></h3>
            <p class="nur-dept-desc"><?php echo esc_html( $d['desc'] ); ?></p>
        </article>
        <?php endforeach; ?>
    </div>
</section>
</div>

<!-- ═══════════════════════════════════════════════════════════════
     FEATURED PLANTS
     ═══════════════════════════════════════════════════════════════ -->
<div class="nur-section-full" id="plants">
<section class="nur-section" style="padding-top:var(--nur-section);padding-bottom:var(--nur-section);" aria-label="Featured plants">
    <div class="nur-fade-up">
        <span class="nur-label">Hand-picked selection</span>
        <h2 class="nur-h2">Plants we're <em>loving right now</em></h2>
        <p class="nur-lead">
            Our buyers travel the length of the country sourcing the best garden-ready stock.
            Here are a few of our current favourites.
        </p>
    </div>
    <div class="nur-plants-grid">

        <!-- Rose -->
        <article class="nur-plant-card nur-fade-up">
            <div class="nur-plant-art nur-plant-rose" aria-label="Rosa Boscobel illustration">
                <?php if ( !empty($featured[0]['tag']) ) : ?>
                <span class="nur-plant-tag"><?php echo esc_html($featured[0]['tag']); ?></span>
                <?php endif; ?>
                <!-- Stem + leaves -->
                <div class="nur-stem" aria-hidden="true"></div>
                <div class="nur-leaf-l" aria-hidden="true"></div>
                <div class="nur-leaf-r" aria-hidden="true"></div>
                <!-- Rose head — 6 petals -->
                <div class="nur-flower" aria-hidden="true">
                    <?php for ($p=0;$p<6;$p++): ?>
                    <div class="nur-rose-petal"
                         style="transform:translate(-50%,-50%) rotate(<?php echo $p*60;?>deg) translateY(-16px);
                                background:radial-gradient(ellipse at 40% 30%,
                                <?php $pc=['#f8b0c8','#e8607a','#c84060'];
                                     $pi=($p+rand(0,1))%3;
                                     echo "$pc[$pi] 0%,$pc[($pi+1)%3] 70%,$pc[($pi+2)%3] 100%"; ?>);"></div>
                    <?php endfor; ?>
                </div>
            </div>
            <div class="nur-plant-info">
                <div class="nur-plant-name"><?php echo esc_html($featured[0]['name']); ?></div>
                <div class="nur-plant-type"><?php echo esc_html($featured[0]['type']); ?></div>
                <div class="nur-plant-footer">
                    <div class="nur-plant-price"><?php echo esc_html($featured[0]['price']); ?></div>
                    <div class="nur-plant-pot"><?php echo esc_html($featured[0]['pot']); ?> pot</div>
                </div>
            </div>
        </article>

        <!-- Hosta -->
        <article class="nur-plant-card nur-fade-up">
            <div class="nur-plant-art nur-plant-hosta" aria-label="Hosta Halcyon illustration">
                <?php if ( !empty($featured[1]['tag']) ) : ?>
                <span class="nur-plant-tag"><?php echo esc_html($featured[1]['tag']); ?></span>
                <?php endif; ?>
                <?php
                $hosta_leaves = [
                    ['left'=>'28%','top'=>'30%','rot'=>'-40','w'=>55,'h'=>70,'g1'=>'#8ac870','g2'=>'#5a9040'],
                    ['left'=>'42%','top'=>'20%','rot'=>'-10','w'=>65,'h'=>85,'g1'=>'#9ad880','g2'=>'#6aaa50'],
                    ['left'=>'54%','top'=>'30%','rot'=>'20','w'=>55,'h'=>72,'g1'=>'#8ac870','g2'=>'#5a9040'],
                    ['left'=>'36%','top'=>'50%','rot'=>'-25','w'=>48,'h'=>62,'g1'=>'#a0e090','g2'=>'#70b060'],
                    ['left'=>'50%','top'=>'55%','rot'=>'15','w'=>50,'h'=>65,'g1'=>'#9ad880','g2'=>'#6aaa50'],
                ];
                foreach($hosta_leaves as $hl): ?>
                <div class="nur-hosta-leaf" aria-hidden="true"
                     style="left:<?php echo $hl['left']; ?>;top:<?php echo $hl['top']; ?>;
                            transform:rotate(<?php echo $hl['rot']; ?>deg);
                            width:<?php echo $hl['w']; ?>px;height:<?php echo $hl['h']; ?>px;
                            background:linear-gradient(160deg,<?php echo $hl['g1']; ?> 0%,<?php echo $hl['g2']; ?> 100%);"></div>
                <?php endforeach; ?>
            </div>
            <div class="nur-plant-info">
                <div class="nur-plant-name"><?php echo esc_html($featured[1]['name']); ?></div>
                <div class="nur-plant-type"><?php echo esc_html($featured[1]['type']); ?></div>
                <div class="nur-plant-footer">
                    <div class="nur-plant-price"><?php echo esc_html($featured[1]['price']); ?></div>
                    <div class="nur-plant-pot"><?php echo esc_html($featured[1]['pot']); ?> pot</div>
                </div>
            </div>
        </article>

        <!-- Lavender -->
        <article class="nur-plant-card nur-fade-up">
            <div class="nur-plant-art nur-plant-lavender" aria-label="Lavender illustration">
                <?php if ( !empty($featured[2]['tag']) ) : ?>
                <span class="nur-plant-tag" style="background:var(--nur-green-deep);"><?php echo esc_html($featured[2]['tag']); ?></span>
                <?php endif; ?>
                <?php
                $lav_stems = [
                    ['left'=>'28%','h'=>95,'rot'=>'-18'],
                    ['left'=>'38%','h'=>108,'rot'=>'-8'],
                    ['left'=>'48%','h'=>115,'rot'=>'0'],
                    ['left'=>'58%','h'=>105,'rot'=>'10'],
                    ['left'=>'68%','h'=>92,'rot'=>'20'],
                ];
                foreach($lav_stems as $ls): ?>
                <div class="nur-lav-stem" aria-hidden="true"
                     style="left:<?php echo $ls['left']; ?>;height:<?php echo $ls['h']; ?>px;
                            transform:rotate(<?php echo $ls['rot']; ?>deg);">
                    <div class="nur-lav-spike"
                         style="background:linear-gradient(180deg,
                             <?php $lc=['#8060a0','#9878c0','#7050b0'][$ls===$lav_stems[2]?0:rand(0,2)]; echo $lc; ?> 0%,
                             <?php echo ['#a088d8','#b090e0','#9070c8'][$ls===$lav_stems[2]?0:rand(0,2)]; ?> 100%);"></div>
                </div>
                <?php endforeach; ?>
                <!-- Low foliage mound -->
                <div aria-hidden="true"
                     style="position:absolute;bottom:20px;left:50%;transform:translateX(-50%);
                            width:120px;height:30px;
                            background:linear-gradient(180deg,#7aaa60 0%,#5a8a40 100%);
                            border-radius:50% 50% 0 0;"></div>
            </div>
            <div class="nur-plant-info">
                <div class="nur-plant-name"><?php echo esc_html($featured[2]['name']); ?></div>
                <div class="nur-plant-type"><?php echo esc_html($featured[2]['type']); ?></div>
                <div class="nur-plant-footer">
                    <div class="nur-plant-price"><?php echo esc_html($featured[2]['price']); ?></div>
                    <div class="nur-plant-pot"><?php echo esc_html($featured[2]['pot']); ?> pot</div>
                </div>
            </div>
        </article>

        <!-- Fern -->
        <article class="nur-plant-card nur-fade-up">
            <div class="nur-plant-art nur-plant-fern" aria-label="Dryopteris fern illustration">
                <?php if ( !empty($featured[3]['tag']) ) : ?>
                <span class="nur-plant-tag"><?php echo esc_html($featured[3]['tag']); ?></span>
                <?php endif; ?>
                <?php
                $fern_fronds = [
                    ['left'=>'44%','h'=>110,'rot'=>'-50'],
                    ['left'=>'46%','h'=>95,'rot'=>'-25'],
                    ['left'=>'48%','h'=>105,'rot'=>'0'],
                    ['left'=>'50%','h'=>98,'rot'=>'25'],
                    ['left'=>'52%','h'=>108,'rot'=>'52'],
                ];
                foreach($fern_fronds as $ff): ?>
                <div class="nur-fern-frond" aria-hidden="true"
                     style="left:<?php echo $ff['left']; ?>;height:<?php echo $ff['h']; ?>px;
                            transform:rotate(<?php echo $ff['rot']; ?>deg);
                            background:linear-gradient(180deg,#6aaa50 0%,#4a8a30 100%);"></div>
                <?php endforeach; ?>
                <!-- Soil mound -->
                <div aria-hidden="true"
                     style="position:absolute;bottom:20px;left:50%;transform:translateX(-50%);
                            width:80px;height:20px;
                            background:#8a7060;border-radius:50% 50% 0 0;"></div>
            </div>
            <div class="nur-plant-info">
                <div class="nur-plant-name"><?php echo esc_html($featured[3]['name']); ?></div>
                <div class="nur-plant-type"><?php echo esc_html($featured[3]['type']); ?></div>
                <div class="nur-plant-footer">
                    <div class="nur-plant-price"><?php echo esc_html($featured[3]['price']); ?></div>
                    <div class="nur-plant-pot"><?php echo esc_html($featured[3]['pot']); ?> pot</div>
                </div>
            </div>
        </article>

        <!-- Agapanthus -->
        <article class="nur-plant-card nur-fade-up">
            <div class="nur-plant-art nur-plant-agapanthus" aria-label="Agapanthus Midnight illustration">
                <?php if ( !empty($featured[4]['tag']) ) : ?>
                <span class="nur-plant-tag" style="background:var(--nur-earth);"><?php echo esc_html($featured[4]['tag']); ?></span>
                <?php endif; ?>
                <div class="nur-aga-stem" aria-hidden="true"></div>
                <div class="nur-aga-head" aria-hidden="true">
                    <!-- Florets radiating from head -->
                    <?php for($af=0;$af<14;$af++): ?>
                    <div aria-hidden="true"
                         style="position:absolute;top:50%;left:50%;
                                width:3px;height:28px;
                                background:#8080e0;
                                border-radius:2px;
                                transform-origin:top center;
                                transform:rotate(<?php echo $af*25.7;?>deg) translateY(-2px);"></div>
                    <?php endfor; ?>
                </div>
                <!-- Strap-like foliage -->
                <?php for($afl=0;$afl<5;$afl++): ?>
                <div aria-hidden="true"
                     style="position:absolute;bottom:20px;left:<?php echo 35+$afl*8;?>%;
                            width:8px;height:<?php echo 55+($afl%2)*15;?>px;
                            background:linear-gradient(180deg,#7ab060 0%,#5a8040 100%);
                            border-radius:4px;
                            transform:rotate(<?php echo -15+$afl*8;?>deg);
                            transform-origin:bottom center;"></div>
                <?php endfor; ?>
            </div>
            <div class="nur-plant-info">
                <div class="nur-plant-name"><?php echo esc_html($featured[4]['name']); ?></div>
                <div class="nur-plant-type"><?php echo esc_html($featured[4]['type']); ?></div>
                <div class="nur-plant-footer">
                    <div class="nur-plant-price"><?php echo esc_html($featured[4]['price']); ?></div>
                    <div class="nur-plant-pot"><?php echo esc_html($featured[4]['pot']); ?> pot</div>
                </div>
            </div>
        </article>

        <!-- Bamboo -->
        <article class="nur-plant-card nur-fade-up">
            <div class="nur-plant-art nur-plant-bamboo" aria-label="Fargesia bamboo illustration">
                <?php if ( !empty($featured[5]['tag']) ) : ?>
                <span class="nur-plant-tag"><?php echo esc_html($featured[5]['tag']); ?></span>
                <?php endif; ?>
                <?php
                $bam_canes = [
                    ['left'=>'25%','h'=>165,'col1'=>'#8ab870','col2'=>'#6a9850'],
                    ['left'=>'35%','h'=>145,'col1'=>'#9ac880','col2'=>'#7aaa60'],
                    ['left'=>'46%','h'=>170,'col1'=>'#8ab870','col2'=>'#6a9850'],
                    ['left'=>'57%','h'=>155,'col1'=>'#9ac880','col2'=>'#7aaa60'],
                    ['left'=>'68%','h'=>140,'col1'=>'#8ab870','col2'=>'#6a9850'],
                ];
                foreach($bam_canes as $bc): ?>
                <div class="nur-bam-cane" aria-hidden="true"
                     style="left:<?php echo $bc['left']; ?>;height:<?php echo $bc['h']; ?>px;
                            background:linear-gradient(90deg,<?php echo $bc['col1']; ?> 0%,<?php echo $bc['col2']; ?> 50%,<?php echo $bc['col1']; ?> 100%);">
                    <!-- Nodes -->
                    <?php for($bn=1;$bn<5;$bn++): ?>
                    <div class="nur-bam-node"
                         style="top:<?php echo $bn * 20; ?>%;"></div>
                    <?php endfor; ?>
                    <!-- Leaves from top -->
                    <div class="nur-bam-leaf"
                         style="top:5%;left:6px;transform:rotate(-30deg);
                                background:linear-gradient(90deg,#8ac870 0%,#5a9040 100%);"></div>
                    <div class="nur-bam-leaf"
                         style="top:12%;left:-22px;transform:rotate(210deg) scaleX(-1);
                                background:linear-gradient(90deg,#8ac870 0%,#5a9040 100%);width:22px;"></div>
                </div>
                <?php endforeach; ?>
                <!-- Ground mound -->
                <div aria-hidden="true"
                     style="position:absolute;bottom:10px;left:50%;transform:translateX(-50%);
                            width:140px;height:18px;background:#7a6050;border-radius:50%;"></div>
            </div>
            <div class="nur-plant-info">
                <div class="nur-plant-name"><?php echo esc_html($featured[5]['name']); ?></div>
                <div class="nur-plant-type"><?php echo esc_html($featured[5]['type']); ?></div>
                <div class="nur-plant-footer">
                    <div class="nur-plant-price"><?php echo esc_html($featured[5]['price']); ?></div>
                    <div class="nur-plant-pot"><?php echo esc_html($featured[5]['pot']); ?> pot</div>
                </div>
            </div>
        </article>

    </div><!-- .nur-plants-grid -->
</section>
</div>

<!-- ═══════════════════════════════════════════════════════════════
     SERVICES
     ═══════════════════════════════════════════════════════════════ -->
<div id="services">
<section class="nur-section" aria-label="Our services">
    <div class="nur-fade-up">
        <span class="nur-label">Expert support</span>
        <h2 class="nur-h2">More than a <em>garden centre</em></h2>
        <p class="nur-lead">
            Our team of RHS-qualified horticulturalists and garden designers offer a range of
            services to help you achieve the garden of your dreams.
        </p>
    </div>
    <div class="nur-services-grid">
        <?php foreach ( $services as $svc ) : ?>
        <article class="nur-svc-card nur-fade-up">
            <h3 class="nur-svc-title"><?php echo esc_html( $svc['title'] ); ?></h3>
            <div class="nur-svc-meta">
                <span class="nur-svc-price"><?php echo esc_html( $svc['price'] ); ?></span>
                <span class="nur-svc-dur"><?php echo esc_html( $svc['dur'] ); ?></span>
            </div>
            <p class="nur-svc-desc"><?php echo esc_html( $svc['desc'] ); ?></p>
        </article>
        <?php endforeach; ?>
    </div>
</section>
</div>

<!-- ═══════════════════════════════════════════════════════════════
     EVENTS
     ═══════════════════════════════════════════════════════════════ -->
<div class="nur-section-full" id="events">
<section class="nur-section" style="padding-top:var(--nur-section);padding-bottom:var(--nur-section);" aria-label="Upcoming events">
    <div class="nur-fade-up">
        <span class="nur-label">What's on</span>
        <h2 class="nur-h2">Workshops &amp; <em>events</em></h2>
        <p class="nur-lead">
            Join us for talks, hands-on workshops, family activities and special seasonal events
            throughout the year. Booking essential.
        </p>
    </div>
    <div class="nur-events-list">
        <?php foreach ( $events as $ev ) : ?>
        <div class="nur-event-row nur-fade-up">
            <div class="nur-event-date"><?php echo esc_html( $ev['date'] ); ?></div>
            <div class="nur-event-name"><?php echo esc_html( $ev['name'] ); ?></div>
            <span class="nur-event-badge"><?php echo esc_html( $ev['tag'] ); ?></span>
        </div>
        <?php endforeach; ?>
    </div>
</section>
</div>

<!-- ═══════════════════════════════════════════════════════════════
     TESTIMONIALS
     ═══════════════════════════════════════════════════════════════ -->
<section class="nur-section" aria-label="Customer reviews">
    <div class="nur-fade-up">
        <span class="nur-label">What our customers say</span>
        <h2 class="nur-h2">Grown by <em>generations</em></h2>
        <p class="nur-lead">
            We're proud to have served gardeners across the Cotswolds for nearly four decades.
            Here's what some of them say.
        </p>
    </div>
    <div class="nur-testi-grid">
        <?php foreach ( $testimonials as $t ) : ?>
        <article class="nur-testi-card nur-fade-up">
            <div class="nur-testi-stars" aria-label="<?php echo esc_attr( $t['stars'] ); ?> stars">
                <?php echo str_repeat('★', intval($t['stars'])); ?>
            </div>
            <blockquote class="nur-testi-quote"><?php echo esc_html( $t['quote'] ); ?></blockquote>
            <div class="nur-testi-author"><?php echo esc_html( $t['name'] ); ?></div>
            <div class="nur-testi-detail"><?php echo esc_html( $t['loc'] ); ?></div>
            <span class="nur-testi-subject"><?php echo esc_html( $t['subject'] ); ?></span>
        </article>
        <?php endforeach; ?>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     CAFÉ STRIP
     ═══════════════════════════════════════════════════════════════ -->
<div class="nur-cafe" aria-label="Café information">
    <div class="nur-cafe-inner">
        <h2>Visit <em>The Potting Shed Café</em></h2>
        <p>
            After browsing, unwind with homemade soup, seasonal salads, loose-leaf teas and
            freshly baked cakes in our garden-view café. Dogs welcome on the terrace.
        </p>
        <div class="nur-cafe-hours">
            <span>☕ Hot food until 14:30</span>
            <span>🍰 Cakes all day</span>
            <span>🐾 Dog friendly terrace</span>
        </div>
    </div>
</div>

<!-- ═══════════════════════════════════════════════════════════════
     FAQ
     ═══════════════════════════════════════════════════════════════ -->
<section class="nur-section" aria-label="Frequently asked questions">
    <div class="nur-fade-up">
        <span class="nur-label">Common questions</span>
        <h2 class="nur-h2">We're here to <em>help</em></h2>
    </div>
    <div class="nur-faq-list" role="list">
        <?php foreach ( $faqs as $i => $faq ) : ?>
        <div class="nur-faq-item" role="listitem">
            <button class="nur-faq-q"
                    aria-expanded="false"
                    aria-controls="nur-faq-a-<?php echo $i; ?>">
                <span><?php echo esc_html( $faq['q'] ); ?></span>
                <span class="nur-faq-icon" aria-hidden="true">+</span>
            </button>
            <div class="nur-faq-a"
                 id="nur-faq-a-<?php echo $i; ?>"
                 role="region">
                <div class="nur-faq-a-inner">
                    <?php echo esc_html( $faq['a'] ); ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     ENQUIRY FORM
     ═══════════════════════════════════════════════════════════════ -->
<div class="nur-form-section" id="contact" aria-label="Enquiry form">
    <div class="nur-form-inner">

        <div class="nur-form-intro nur-fade-up">
            <span class="nur-label">Get in touch</span>
            <h2 class="nur-h2">Let's talk <em>gardens</em></h2>
            <p class="nur-lead">
                Whether you need expert planting advice, want to book a workshop,
                or are dreaming of a complete garden redesign — we'd love to hear from you.
            </p>

            <div class="nur-form-detail">
                <span class="nur-form-detail-icon">📍</span>
                <span><?php echo esc_html( $business['location'] ); ?></span>
            </div>
            <div class="nur-form-detail">
                <span class="nur-form-detail-icon">☎️</span>
                <span>
                    <a href="tel:<?php echo esc_attr( preg_replace('/\s+/','',$business['phone']) ); ?>"
                       style="color:var(--nur-gold-light);">
                        <?php echo esc_html( $business['phone'] ); ?>
                    </a>
                </span>
            </div>
            <div class="nur-form-detail">
                <span class="nur-form-detail-icon">✉️</span>
                <span>
                    <a href="mailto:<?php echo esc_attr( $business['email'] ); ?>"
                       style="color:var(--nur-gold-light);">
                        <?php echo esc_html( $business['email'] ); ?>
                    </a>
                </span>
            </div>
            <div class="nur-form-detail">
                <span class="nur-form-detail-icon">🕐</span>
                <span><?php echo esc_html( $business['hours'] ); ?></span>
            </div>
        </div>

        <div class="nur-form nur-fade-up">
            <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" novalidate>
                <?php wp_nonce_field( 'tf_nur_enquiry', 'tf_nur_nonce' ); ?>
                <input type="hidden" name="action" value="tf_nur_enquiry">

                <div class="nur-form-grid">
                    <div class="nur-form-group">
                        <label class="nur-form-label" for="nur-first">First Name *</label>
                        <input class="nur-form-input" type="text" id="nur-first"
                               name="first_name" placeholder="Patricia" required
                               autocomplete="given-name">
                    </div>
                    <div class="nur-form-group">
                        <label class="nur-form-label" for="nur-last">Last Name *</label>
                        <input class="nur-form-input" type="text" id="nur-last"
                               name="last_name" placeholder="Winslow" required
                               autocomplete="family-name">
                    </div>
                    <div class="nur-form-group">
                        <label class="nur-form-label" for="nur-email">Email Address *</label>
                        <input class="nur-form-input" type="email" id="nur-email"
                               name="email" placeholder="you@example.co.uk" required
                               autocomplete="email">
                    </div>
                    <div class="nur-form-group">
                        <label class="nur-form-label" for="nur-phone">Phone Number</label>
                        <input class="nur-form-input" type="tel" id="nur-phone"
                               name="phone" placeholder="01608 000 000"
                               autocomplete="tel">
                    </div>
                    <div class="nur-form-group full">
                        <label class="nur-form-label" for="nur-type">Enquiry Type *</label>
                        <select class="nur-form-select" id="nur-type" name="enquiry_type" required>
                            <option value="">— Please select —</option>
                            <?php foreach ( $enquiry_types as $et ) : ?>
                            <option value="<?php echo esc_attr( sanitize_title($et) ); ?>">
                                <?php echo esc_html( $et ); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="nur-form-group full">
                        <label class="nur-form-label" for="nur-garden">Tell us about your garden</label>
                        <textarea class="nur-form-textarea" id="nur-garden" name="garden_details"
                                  placeholder="Size, aspect, soil type, any existing plants you love…"></textarea>
                    </div>
                    <div class="nur-form-group full">
                        <label class="nur-form-label" for="nur-message">Your Message *</label>
                        <textarea class="nur-form-textarea" id="nur-message" name="message"
                                  placeholder="How can we help?" required></textarea>
                    </div>
                </div>

                <button type="submit" class="nur-form-submit">
                    Send Enquiry 🌿
                </button>
                <p class="nur-form-note">
                    We aim to respond within one working day. Your details are used only to respond
                    to your enquiry and are never shared with third parties.
                </p>
            </form>
        </div>

    </div>
</div>

<!-- ═══════════════════════════════════════════════════════════════
     JAVASCRIPT
     ═══════════════════════════════════════════════════════════════ -->
<script>
(function () {
    'use strict';

    /* ── Intersection observer — fade-up ──────────────────────────── */
    const fadeEls = document.querySelectorAll('.nur-fade-up');
    if ('IntersectionObserver' in window) {
        const io = new IntersectionObserver(function (entries) {
            entries.forEach(function (e) {
                if (e.isIntersecting) {
                    e.target.classList.add('visible');
                    io.unobserve(e.target);
                }
            });
        }, { threshold: 0.12 });
        fadeEls.forEach(function (el) { io.observe(el); });
    } else {
        fadeEls.forEach(function (el) { el.classList.add('visible'); });
    }

    /* ── Animated counters ────────────────────────────────────────── */
    const counters = document.querySelectorAll('[data-target]');
    const easeOut = function (t) { return 1 - Math.pow(1 - t, 3); };

    function animateCounter(el) {
        var raw    = parseFloat(el.dataset.target);
        var suffix = el.dataset.suffix || '';
        if (isNaN(raw)) return;
        var isFloat = el.dataset.target.indexOf('.') !== -1;
        var start   = null;
        var dur     = 1800;

        function tick(ts) {
            if (!start) start = ts;
            var prog = Math.min((ts - start) / dur, 1);
            var val  = raw * easeOut(prog);
            el.textContent = (isFloat ? val.toFixed(1) : Math.round(val).toLocaleString()) + suffix;
            if (prog < 1) requestAnimationFrame(tick);
            else el.textContent = (isFloat ? raw.toFixed(1) : raw.toLocaleString()) + suffix;
        }
        requestAnimationFrame(tick);
    }

    if ('IntersectionObserver' in window) {
        var cio = new IntersectionObserver(function (entries) {
            entries.forEach(function (e) {
                if (e.isIntersecting) {
                    animateCounter(e.target);
                    cio.unobserve(e.target);
                }
            });
        }, { threshold: 0.5 });
        counters.forEach(function (c) { cio.observe(c); });
    } else {
        counters.forEach(animateCounter);
    }

    /* ── FAQ accordion ────────────────────────────────────────────── */
    document.querySelectorAll('.nur-faq-q').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var item   = btn.closest('.nur-faq-item');
            var answer = item.querySelector('.nur-faq-a');
            var open   = item.classList.toggle('open');
            btn.setAttribute('aria-expanded', open ? 'true' : 'false');
            answer.style.maxHeight = open ? answer.scrollHeight + 'px' : '0';
        });
    });

    /* ── Smooth scroll ────────────────────────────────────────────── */
    document.querySelectorAll('a[href^="#"]').forEach(function (a) {
        a.addEventListener('click', function (e) {
            var id = a.getAttribute('href').slice(1);
            var target = document.getElementById(id);
            if (target) {
                e.preventDefault();
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });

})();
</script>

</div><!-- . -->

<?php get_footer(); ?>
