<?php
/**
 * Template Name: Nutritional Therapist
 *
 * Premium landing page for a nutritional therapist / registered dietitian.
 * Hero: CSS bowl scene — colourful CSS food items, nutrient particles, dietitian figure.
 * Namespace: --nt-* | Fonts: Plus Jakarta Sans + Lora | Palette: fresh greens, warm oranges, cream
 *
 * @package ThemeFlex
 */

get_header(); ?>

<style>
/* ── Fonts ─────────────────────────────────────────────────── */
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Lora:ital,wght@0,400;0,600;0,700;1,400&display=swap');

/* ── Token System ───────────────────────────────────────────── */
:root {
  --nt-green:     #2E8B57;
  --nt-green-lt:  #4CAF50;
  --nt-green-dk:  #1B5E3B;
  --nt-orange:    #FF7043;
  --nt-orange-lt: #FF8A65;
  --nt-orange-lx: #FFF3E0;
  --nt-yellow:    #FFD600;
  --nt-red:       #E53935;
  --nt-purple:    #7B1FA2;
  --nt-berry:     #C2185B;
  --nt-cream:     #FFFBF5;
  --nt-white:     #FFFFFF;
  --nt-text:      #1C1C1E;
  --nt-text-lt:   #5A5A6A;
  --nt-shadow:    rgba(28,28,30,0.12);

  --nt-r:    8px;
  --nt-r-lg: 16px;
  --nt-r-xl: 24px;

  --ff-body:  'Plus Jakarta Sans', system-ui, sans-serif;
  --ff-serif: 'Lora', Georgia, serif;
}

/* ── Reset ─────────────────────────────────────────────────── */
.nt-page *, .nt-page *::before, .nt-page *::after { box-sizing: border-box; margin: 0; padding: 0; }
.nt-page { font-family: var(--ff-body); color: var(--nt-text); background: var(--nt-cream); overflow-x: hidden; }
.nt-page a { color: inherit; text-decoration: none; }

/* ── Layout ─────────────────────────────────────────────────── */
.nt-wrap    { max-width: 1160px; margin: 0 auto; padding: 0 24px; }
.nt-section { padding: 80px 0; }
.nt-section--alt { background: var(--nt-white); }

/* ── Typography ─────────────────────────────────────────────── */
.nt-eyebrow {
  font-size: .75rem; font-weight: 700; letter-spacing: .12em;
  text-transform: uppercase; color: var(--nt-green); margin-bottom: 10px;
}
.nt-h1 { font-family: var(--ff-serif); font-size: clamp(2.4rem,5vw,3.8rem); font-weight: 700; line-height: 1.15; }
.nt-h2 { font-family: var(--ff-serif); font-size: clamp(1.8rem,3.5vw,2.8rem); font-weight: 600; line-height: 1.2; margin-bottom: 16px; }
.nt-h3 { font-family: var(--ff-serif); font-size: 1.3rem; font-weight: 600; margin-bottom: 8px; }
.nt-lead { font-size: 1.1rem; line-height: 1.75; color: var(--nt-text-lt); }

/* ── Buttons ─────────────────────────────────────────────────── */
.nt-btn {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 14px 32px; border-radius: 50px; font-family: var(--ff-body);
  font-size: .95rem; font-weight: 600; cursor: pointer;
  transition: transform .2s, box-shadow .2s; border: none;
}
.nt-btn--primary {
  background: var(--nt-green); color: var(--nt-white);
  box-shadow: 0 4px 18px rgba(46,139,87,.35);
}
.nt-btn--primary:hover { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(46,139,87,.5); }
.nt-btn--outline {
  background: transparent; color: var(--nt-white);
  border: 2px solid rgba(255,255,255,.7);
}
.nt-btn--outline:hover { background: rgba(255,255,255,.12); transform: translateY(-2px); }

/* ============================================================
   HERO — BOWL & FOOD SCENE
   ============================================================ */
.nt-hero {
  position: relative; overflow: hidden;
  min-height: 100vh; display: flex; align-items: center;
  background: linear-gradient(135deg, #1B5E3B 0%, #2E8B57 40%, #43A047 70%, #1B5E3B 100%);
}

/* ── Organic background blobs ── */
.nt-blob {
  position: absolute; border-radius: 50%; filter: blur(60px);
  opacity: .25;
}
.nt-blob--1 { width: 400px; height: 400px; top: -80px; right: 5%; background: var(--nt-orange); }
.nt-blob--2 { width: 300px; height: 300px; bottom: 10%; left: 5%; background: var(--nt-yellow); }
.nt-blob--3 { width: 200px; height: 200px; top: 50%; right: 25%; background: var(--nt-berry); }

/* ── Floating nutrient particles ── */
.nt-particle {
  position: absolute; border-radius: 50%;
  animation: nt-particle-rise 6s ease-in-out infinite;
}
.nt-particle::after {
  content: attr(data-label);
  position: absolute; top: 50%; left: 50%;
  transform: translate(-50%,-50%);
  font-size: .6rem; font-weight: 700; color: var(--nt-white);
  white-space: nowrap;
}
.nt-p--vit-c   { width: 46px; height: 46px; background: rgba(255,112,67,.85); top: 12%; left: 68%; animation-delay: 0s; }
.nt-p--omega   { width: 38px; height: 38px; background: rgba(123,31,162,.8);  top: 22%; left: 80%; animation-delay: -2s; }
.nt-p--folate  { width: 42px; height: 42px; background: rgba(76,175,80,.85);  top: 58%; left: 72%; animation-delay: -4s; }
.nt-p--iron    { width: 34px; height: 34px; background: rgba(229,57,53,.8);   top: 40%; left: 85%; animation-delay: -1s; }
.nt-p--b12     { width: 40px; height: 40px; background: rgba(255,214,0,.85);  top: 70%; left: 78%; animation-delay: -3s; }
.nt-p--zinc    { width: 32px; height: 32px; background: rgba(0,188,212,.8);   top: 30%; left: 75%; animation-delay: -5s; }
@keyframes nt-particle-rise {
  0%,100% { transform: translateY(0) rotate(0deg); }
  33%      { transform: translateY(-18px) rotate(8deg); }
  66%      { transform: translateY(-8px) rotate(-4deg); }
}

/* ── Large bowl ── */
.nt-bowl {
  position: absolute; right: 8%; top: 50%; transform: translateY(-50%);
  width: 260px; height: 260px;
}
.nt-bowl__shell {
  position: absolute; inset: 0; border-radius: 50%;
  background: radial-gradient(circle at 35% 30%, #FFF9F4, #F5E6D3);
  box-shadow: 0 20px 60px rgba(0,0,0,.3), inset 0 -8px 24px rgba(0,0,0,.1);
  overflow: hidden;
}
/* Bowl rim */
.nt-bowl__shell::before {
  content:''; position: absolute;
  top: 0; left: 0; right: 0; height: 40px;
  border-radius: 50% 50% 0 0 / 80% 80% 0 0;
  background: linear-gradient(180deg,#E8D5C4,transparent);
}

/* Food items inside bowl — CSS art */
/* Leafy greens */
.nt-food-leaf {
  position: absolute; border-radius: 50% 0 50% 0;
  background: var(--nt-green-lt);
}
.nt-food-leaf--1 { width: 60px; height: 40px; top: 35%; left: 15%; transform: rotate(-20deg); }
.nt-food-leaf--2 { width: 50px; height: 34px; top: 30%; left: 30%; transform: rotate(15deg); background: var(--nt-green); }
.nt-food-leaf--3 { width: 44px; height: 30px; top: 25%; left: 20%; transform: rotate(-10deg); background: #81C784; }

/* Tomato */
.nt-food-tomato {
  position: absolute; border-radius: 50%;
  background: radial-gradient(circle at 35% 30%, #EF9A9A, var(--nt-red));
  top: 48%; left: 55%;
  width: 38px; height: 38px;
}
.nt-food-tomato::before {
  content:''; position: absolute; width: 14px; height: 8px;
  background: var(--nt-green-lt); top: -5px; left: 50%;
  transform: translateX(-50%); border-radius: 50% 50% 0 0;
}

/* Avocado */
.nt-food-avocado {
  position: absolute; top: 50%; left: 20%;
  width: 36px; height: 52px; border-radius: 50% 50% 60% 60%;
  background: linear-gradient(180deg, #388E3C, #1B5E20);
}
.nt-food-avocado::before {
  content:''; position: absolute; top: 10px; left: 50%; transform: translateX(-50%);
  width: 22px; height: 32px; border-radius: 50%;
  background: linear-gradient(180deg, #C8E6C9, #A5D6A7);
}
.nt-food-avocado::after {
  content:''; position: absolute; top: 18px; left: 50%; transform: translateX(-50%);
  width: 12px; height: 18px; border-radius: 50%;
  background: radial-gradient(circle at 40% 35%, #8D6E63, #3E2723);
}

/* Blueberries */
.nt-berry-group {
  position: absolute; top: 60%; left: 50%;
  display: flex; gap: 4px;
}
.nt-berry {
  width: 16px; height: 16px; border-radius: 50%;
  background: radial-gradient(circle at 35% 30%, #9575CD, #4527A0);
}

/* Quinoa / grain base */
.nt-food-grain {
  position: absolute; bottom: 15%; left: 0; right: 0; height: 28px;
  background: radial-gradient(ellipse, #FDD835 40%, #F9A825);
  border-radius: 50%;
  opacity: .75;
}

/* Nuts */
.nt-food-nut {
  position: absolute; border-radius: 50% 50% 60% 60%;
  background: linear-gradient(180deg, #D7A86E, #A0522D);
}
.nt-food-nut--1 { width: 18px; height: 14px; top: 62%; left: 35%; transform: rotate(-20deg); }
.nt-food-nut--2 { width: 16px; height: 12px; top: 58%; left: 42%; transform: rotate(10deg); }

/* ── Dietitian figure ── */
.nt-dietitian {
  position: absolute; bottom: 18%; left: 35%;
  width: 60px; display: flex; flex-direction: column; align-items: center;
}
/* Lab coat / white tunic */
.nt-dietitian__head {
  width: 34px; height: 38px; border-radius: 50% 50% 45% 45%;
  background: #FFE0B2; position: relative;
}
.nt-dietitian__head::before {
  content:''; position: absolute;
  width: 8px; height: 8px; border-radius: 50%;
  background: #4E342E; top: 42%; left: 18%;
  box-shadow: 12px 0 0 #4E342E;
}
.nt-dietitian__head::after {
  content:''; position: absolute;
  width: 14px; height: 7px;
  border: 2px solid #4E342E; border-top: none; border-radius: 0 0 50% 50%;
  bottom: 22%; left: 50%; transform: translateX(-50%);
}
/* Hair */
.nt-dietitian__hair {
  position: absolute; width: 38px; height: 20px;
  border-radius: 50% 50% 0 0;
  background: #4E342E; top: -8px; left: -2px;
}
.nt-dietitian__body {
  width: 44px; height: 50px; border-radius: 6px 6px 0 0;
  background: var(--nt-white); margin-top: -2px; position: relative;
}
/* Green lapel / lanyard */
.nt-dietitian__body::before {
  content:''; position: absolute;
  width: 16px; height: 28px;
  background: var(--nt-green-lt);
  top: 4px; left: 50%; transform: translateX(-50%);
  clip-path: polygon(50% 0%, 100% 30%, 50% 100%, 0% 30%);
}
/* Clipboard prop */
.nt-dietitian__body::after {
  content:''; position: absolute;
  width: 24px; height: 30px; border-radius: 3px;
  background: #FFF9E3; border: 2px solid #BDBDBD;
  right: -20px; top: 8px;
  box-shadow:
    2px 6px 0 -1px #E0E0E0,
    2px 10px 0 -1px #E0E0E0,
    2px 14px 0 -1px #E0E0E0;
}
.nt-dietitian__legs { display: flex; gap: 6px; }
.nt-dietitian__leg  { width: 18px; height: 28px; border-radius: 0 0 5px 5px; background: #90A4AE; }
.nt-dietitian__feet { display: flex; gap: 6px; }
.nt-dietitian__foot { width: 20px; height: 10px; border-radius: 0 8px 8px 0; background: #546E7A; margin-top:-2px; }
.nt-dietitian__foot:first-child { border-radius: 8px 0 0 8px; }

/* ── Hero content ── */
.nt-hero__inner {
  position: relative; z-index: 10;
  max-width: 580px; padding: 40px 24px 40px 60px;
}
.nt-hero__title { color: var(--nt-white); text-shadow: 0 2px 12px rgba(0,0,0,.3); margin-bottom: 18px; }
.nt-hero__sub   { font-size: 1.12rem; color: rgba(255,255,255,.88); line-height: 1.75; margin-bottom: 30px; }
.nt-hero__ctas  { display: flex; gap: 14px; flex-wrap: wrap; }

/* ── Floating info cards ── */
.nt-info-card {
  position: absolute; border-radius: var(--nt-r-lg);
  background: rgba(255,255,255,.92); backdrop-filter: blur(10px);
  padding: 10px 16px; box-shadow: 0 6px 20px rgba(0,0,0,.18);
  font-size: .82rem; font-weight: 600; color: var(--nt-text);
  animation: nt-card-float 5s ease-in-out infinite;
}
.nt-info-card__icon { font-size: 1rem; margin-right: 6px; }
.nt-info-card--1 { top: 15%; left: 50%; animation-delay: 0s; }
.nt-info-card--2 { top: 32%; left: 48%; animation-delay: -2.2s; }
.nt-info-card--3 { bottom: 22%; left: 52%; animation-delay: -4s; }
@keyframes nt-card-float {
  0%,100% { transform: translateY(0); }
  50%      { transform: translateY(-8px); }
}

/* ============================================================
   STATS
   ============================================================ */
.nt-stats { background: var(--nt-green-dk); padding: 40px 0; }
.nt-stats__grid { display: grid; grid-template-columns: repeat(4,1fr); }
.nt-stat {
  text-align: center; padding: 16px;
  border-right: 1px solid rgba(255,255,255,.15);
}
.nt-stat:last-child { border-right: none; }
.nt-stat__number {
  font-family: var(--ff-serif); font-size: 2.6rem; font-weight: 700;
  color: var(--nt-yellow); line-height: 1;
}
.nt-stat__label { font-size: .82rem; color: rgba(255,255,255,.72); margin-top: 6px; }

/* ============================================================
   APPROACH / PHILOSOPHY
   ============================================================ */
.nt-pillars { margin-top: 48px; display: grid; grid-template-columns: repeat(3,1fr); gap: 28px; }
.nt-pillar {
  background: var(--nt-white); border-radius: var(--nt-r-xl); padding: 32px 28px;
  box-shadow: 0 4px 20px var(--nt-shadow); text-align: center;
  border-top: 4px solid var(--nt-green);
  transition: transform .25s;
}
.nt-pillar:hover { transform: translateY(-4px); }
.nt-pillar:nth-child(2) { border-top-color: var(--nt-orange); }
.nt-pillar:nth-child(3) { border-top-color: var(--nt-purple); }
.nt-pillar__icon { font-size: 2.4rem; margin-bottom: 14px; display: block; }
.nt-pillar__title { font-family: var(--ff-serif); font-size: 1.25rem; font-weight: 600; margin-bottom: 10px; }
.nt-pillar__desc  { font-size: .93rem; line-height: 1.65; color: var(--nt-text-lt); }

/* ============================================================
   ABOUT
   ============================================================ */
.nt-about__grid { display: grid; grid-template-columns: 1fr 1fr; gap: 64px; align-items: center; }

.nt-about__visual {
  position: relative; height: 440px; border-radius: var(--nt-r-xl);
  overflow: hidden;
  background: linear-gradient(135deg, #E8F5E9, #C8E6C9);
  box-shadow: 0 12px 40px var(--nt-shadow);
}
/* CSS food icons decoration */
.nt-about__food-grid {
  position: absolute; inset: 20px;
  display: grid; grid-template-columns: repeat(4,1fr); gap: 16px;
  align-content: center;
}
.nt-food-icon {
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  background: rgba(255,255,255,.85); border-radius: var(--nt-r-lg);
  padding: 14px 8px; aspect-ratio: 1;
  font-size: 1.8rem; box-shadow: 0 2px 8px var(--nt-shadow);
}
.nt-food-icon span { font-size: .65rem; font-weight: 600; margin-top: 4px; color: var(--nt-text-lt); }

.nt-about__badge {
  position: absolute; bottom: 16px; right: 16px;
  background: var(--nt-green); color: var(--nt-white);
  border-radius: var(--nt-r); padding: 10px 16px;
  font-size: .82rem; font-weight: 600;
}
.nt-about__cert {
  position: absolute; top: 12px; left: 12px;
  background: var(--nt-white); border-radius: var(--nt-r);
  padding: 8px 12px; font-size: .78rem; font-weight: 600;
  color: var(--nt-green-dk); box-shadow: 0 2px 10px var(--nt-shadow);
}

.nt-about__name {
  font-family: var(--ff-serif); font-size: 2rem;
  font-weight: 700; margin: 12px 0 6px;
}
.nt-about__credential {
  display: inline-block; background: var(--nt-orange-lx);
  color: var(--nt-orange); border-radius: 50px;
  font-size: .78rem; font-weight: 600; padding: 4px 14px; margin-bottom: 18px;
}
.nt-about__body { font-size: 1.02rem; line-height: 1.8; color: var(--nt-text-lt); margin-bottom: 16px; }
.nt-about__quals { list-style: none; margin-bottom: 28px; }
.nt-about__quals li {
  padding: 8px 0 8px 28px; border-bottom: 1px solid #EEE;
  font-size: .93rem; color: var(--nt-text-lt); position: relative;
}
.nt-about__quals li::before { content: '🥦'; position: absolute; left: 0; top: 8px; font-size: .8rem; }

/* ============================================================
   SERVICES
   ============================================================ */
.nt-services__grid {
  display: grid; grid-template-columns: repeat(auto-fit,minmax(260px,1fr)); gap: 24px; margin-top: 40px;
}
.nt-service {
  background: var(--nt-white); border-radius: var(--nt-r-lg);
  padding: 28px; box-shadow: 0 4px 20px var(--nt-shadow);
  border-left: 4px solid var(--nt-green);
  transition: transform .25s;
}
.nt-service:nth-child(2n) { border-left-color: var(--nt-orange); }
.nt-service:nth-child(3n) { border-left-color: var(--nt-purple); }
.nt-service:hover { transform: translateY(-4px); }
.nt-service__icon  { font-size: 2rem; margin-bottom: 12px; display: block; }
.nt-service__title { font-family: var(--ff-serif); font-size: 1.2rem; font-weight: 600; margin-bottom: 8px; }
.nt-service__desc  { font-size: .92rem; line-height: 1.65; color: var(--nt-text-lt); }

/* ============================================================
   CONDITIONS TREATED (tag cloud)
   ============================================================ */
.nt-conditions { background: var(--nt-green-dk); padding: 60px 0; }
.nt-conditions .nt-eyebrow { color: var(--nt-yellow); }
.nt-conditions .nt-h2 { color: var(--nt-white); }
.nt-tags { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 32px; }
.nt-tag {
  background: rgba(255,255,255,.12); color: rgba(255,255,255,.9);
  border: 1px solid rgba(255,255,255,.2); border-radius: 50px;
  padding: 8px 18px; font-size: .88rem; font-weight: 500;
  transition: background .2s;
}
.nt-tag:hover { background: rgba(255,255,255,.22); }

/* ============================================================
   PROCESS
   ============================================================ */
.nt-process__steps { display: grid; grid-template-columns: repeat(4,1fr); gap: 0; margin-top: 48px; position: relative; }
.nt-process__steps::before {
  content:''; position: absolute;
  top: 32px; left: 12%; right: 12%; height: 3px;
  background: linear-gradient(90deg, var(--nt-green), var(--nt-orange));
  z-index: 0;
}
.nt-step { text-align: center; position: relative; z-index: 1; padding: 0 16px; }
.nt-step__num {
  width: 64px; height: 64px; border-radius: 50%;
  background: var(--nt-green); color: var(--nt-white);
  font-family: var(--ff-serif); font-size: 1.5rem; font-weight: 700;
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto 16px; box-shadow: 0 4px 16px rgba(46,139,87,.35);
}
.nt-step__title { font-family: var(--ff-serif); font-size: 1rem; font-weight: 600; margin-bottom: 6px; }
.nt-step__desc  { font-size: .83rem; line-height: 1.55; color: var(--nt-text-lt); }

/* ============================================================
   PACKAGES
   ============================================================ */
.nt-packages__grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 28px; margin-top: 48px; align-items: start; }
.nt-pkg {
  border-radius: var(--nt-r-xl); overflow: hidden;
  box-shadow: 0 6px 28px var(--nt-shadow); background: var(--nt-white);
  transition: transform .25s;
}
.nt-pkg:hover { transform: translateY(-4px); }
.nt-pkg--featured { transform: scale(1.04); box-shadow: 0 12px 48px rgba(46,139,87,.3); }
.nt-pkg--featured:hover { transform: scale(1.04) translateY(-4px); }

.nt-pkg__header { padding: 28px 28px 20px; text-align: center; }
.nt-pkg--starter  .nt-pkg__header { background: linear-gradient(135deg,#29B6F6,#0288D1); }
.nt-pkg--featured .nt-pkg__header { background: linear-gradient(135deg,var(--nt-green-lt),var(--nt-green-dk)); }
.nt-pkg--deep     .nt-pkg__header { background: linear-gradient(135deg,var(--nt-orange),#BF360C); }

.nt-pkg__badge { display: inline-block; background: var(--nt-yellow); color: #333; border-radius: 50px; font-size: .72rem; font-weight: 700; padding: 3px 12px; margin-bottom: 10px; letter-spacing: .08em; text-transform: uppercase; }
.nt-pkg__name  { font-family: var(--ff-serif); font-size: 1.5rem; font-weight: 700; color: var(--nt-white); }
.nt-pkg__price { font-family: var(--ff-serif); font-size: 2.4rem; font-weight: 700; color: var(--nt-white); margin: 12px 0 4px; }
.nt-pkg__unit  { font-size: .82rem; color: rgba(255,255,255,.75); }

.nt-pkg__body { padding: 24px 28px 28px; }
.nt-pkg__desc { font-size: .92rem; color: var(--nt-text-lt); margin-bottom: 18px; line-height: 1.6; }
.nt-pkg__features { list-style: none; margin-bottom: 24px; }
.nt-pkg__features li { padding: 6px 0 6px 26px; position: relative; font-size: .9rem; color: var(--nt-text-lt); border-bottom: 1px solid #F5F5F5; }
.nt-pkg__features li::before { content:'✓'; position: absolute; left: 0; color: var(--nt-green); font-weight: 700; }
.nt-pkg__cta { display: block; text-align: center; padding: 13px; border-radius: 50px; font-family: var(--ff-body); font-size: .95rem; font-weight: 600; cursor: pointer; border: none; transition: opacity .2s; }
.nt-pkg--starter  .nt-pkg__cta { background: #29B6F6; color: var(--nt-white); }
.nt-pkg--featured .nt-pkg__cta { background: var(--nt-green); color: var(--nt-white); }
.nt-pkg--deep     .nt-pkg__cta { background: var(--nt-orange); color: var(--nt-white); }
.nt-pkg__cta:hover { opacity: .88; }

/* ============================================================
   TESTIMONIALS
   ============================================================ */
.nt-testimonials__grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; margin-top: 40px; }
.nt-testi {
  background: var(--nt-white); border-radius: var(--nt-r-lg);
  padding: 28px; box-shadow: 0 4px 20px var(--nt-shadow);
}
.nt-testi__stars { color: #FFD600; font-size: 1rem; margin-bottom: 12px; letter-spacing: 2px; }
.nt-testi__quote {
  font-family: var(--ff-serif); font-size: 1rem; font-style: italic;
  line-height: 1.75; color: var(--nt-text-lt); margin-bottom: 16px;
}
.nt-testi__author { font-weight: 600; font-size: .9rem; }
.nt-testi__meta   { font-size: .82rem; color: var(--nt-text-lt); }

/* ============================================================
   FAQs
   ============================================================ */
.nt-faqs__list { max-width: 780px; margin: 40px auto 0; }
.nt-faq { border-bottom: 1px solid #E0E0E0; }
.nt-faq__q {
  width: 100%; background: none; border: none; cursor: pointer;
  display: flex; justify-content: space-between; align-items: center;
  padding: 20px 0; font-family: var(--ff-serif); font-size: 1.1rem;
  font-weight: 600; color: var(--nt-text); text-align: left; gap: 16px;
}
.nt-faq__icon { font-size: 1.4rem; color: var(--nt-green); transition: transform .3s; flex-shrink: 0; }
.nt-faq__q[aria-expanded="true"] .nt-faq__icon { transform: rotate(45deg); }
.nt-faq__a { display: none; padding: 0 0 20px; font-size: .97rem; line-height: 1.75; color: var(--nt-text-lt); }
.nt-faq__a.is-open { display: block; }

/* ============================================================
   BOOKING FORM
   ============================================================ */
.nt-booking { background: linear-gradient(135deg, var(--nt-green-dk), var(--nt-green)); padding: 80px 0; }
.nt-booking .nt-eyebrow { color: var(--nt-yellow); }
.nt-booking .nt-h2 { color: var(--nt-white); }
.nt-booking .nt-lead { color: rgba(255,255,255,.78); }

.nt-form { background: var(--nt-white); border-radius: var(--nt-r-xl); padding: 48px; margin-top: 40px; box-shadow: 0 12px 48px rgba(0,0,0,.2); }
.nt-form__grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
.nt-form__full { grid-column: 1/-1; }

.nt-label { display: block; font-size: .85rem; font-weight: 600; margin-bottom: 6px; color: var(--nt-text-lt); }
.nt-input, .nt-select, .nt-textarea {
  width: 100%; padding: 12px 16px;
  border: 1.5px solid #DDD; border-radius: var(--nt-r);
  font-family: var(--ff-body); font-size: .97rem; color: var(--nt-text);
  background: #FAFAFA; transition: border-color .2s;
}
.nt-input:focus, .nt-select:focus, .nt-textarea:focus { outline: none; border-color: var(--nt-green); background: var(--nt-white); }
.nt-textarea { min-height: 120px; resize: vertical; }
.nt-form__submit { text-align: center; margin-top: 32px; }
.nt-form__note { text-align: center; font-size: .82rem; color: var(--nt-text-lt); margin-top: 10px; }

/* ============================================================
   FOOTER CTA
   ============================================================ */
.nt-footer-cta {
  background: linear-gradient(135deg, var(--nt-orange) 0%, #BF360C 100%);
  padding: 60px 0; text-align: center;
}
.nt-footer-cta .nt-h2  { color: var(--nt-white); margin-bottom: 10px; }
.nt-footer-cta .nt-lead { color: rgba(255,255,255,.88); margin-bottom: 28px; }

/* ============================================================
   SCROLL REVEAL
   ============================================================ */
.nt-reveal { opacity: 0; transform: translateY(28px); transition: opacity .65s, transform .65s; }
.nt-reveal.is-visible { opacity: 1; transform: none; }

/* ============================================================
   RESPONSIVE
   ============================================================ */
@media (max-width: 900px) {
  .nt-about__grid    { grid-template-columns: 1fr; }
  .nt-packages__grid { grid-template-columns: 1fr; }
  .nt-pkg--featured  { transform: none; }
  .nt-process__steps { grid-template-columns: 1fr 1fr; }
  .nt-process__steps::before { display: none; }
  .nt-stats__grid    { grid-template-columns: 1fr 1fr; }
  .nt-pillars        { grid-template-columns: 1fr; }
  .nt-testimonials__grid { grid-template-columns: 1fr; }
}
@media (max-width: 600px) {
  .nt-hero__inner { padding: 40px 24px; }
  .nt-form__grid  { grid-template-columns: 1fr; }
  .nt-info-card--2, .nt-info-card--3 { display: none; }
}
</style>

<div class="nt-page">

  <!-- ── HERO ─────────────────────────────────────────────── -->
  <section class="nt-hero" aria-label="Nutritional therapist hero">

    <!-- Blobs -->
    <div class="nt-blob nt-blob--1" aria-hidden="true"></div>
    <div class="nt-blob nt-blob--2" aria-hidden="true"></div>
    <div class="nt-blob nt-blob--3" aria-hidden="true"></div>

    <!-- Nutrient particles -->
    <div class="nt-particle nt-p--vit-c" data-label="Vit C" aria-hidden="true"></div>
    <div class="nt-particle nt-p--omega"  data-label="Ω-3"   aria-hidden="true"></div>
    <div class="nt-particle nt-p--folate" data-label="Folate" aria-hidden="true"></div>
    <div class="nt-particle nt-p--iron"   data-label="Iron"   aria-hidden="true"></div>
    <div class="nt-particle nt-p--b12"    data-label="B12"    aria-hidden="true"></div>
    <div class="nt-particle nt-p--zinc"   data-label="Zinc"   aria-hidden="true"></div>

    <!-- CSS Bowl -->
    <div class="nt-bowl" aria-hidden="true">
      <div class="nt-bowl__shell">
        <div class="nt-food-grain"></div>
        <div class="nt-food-leaf nt-food-leaf--1"></div>
        <div class="nt-food-leaf nt-food-leaf--2"></div>
        <div class="nt-food-leaf nt-food-leaf--3"></div>
        <div class="nt-food-tomato"></div>
        <div class="nt-food-avocado"></div>
        <div class="nt-berry-group">
          <div class="nt-berry"></div>
          <div class="nt-berry"></div>
          <div class="nt-berry"></div>
        </div>
        <div class="nt-food-nut nt-food-nut--1"></div>
        <div class="nt-food-nut nt-food-nut--2"></div>
      </div>
    </div>

    <!-- Dietitian figure -->
    <div class="nt-dietitian" aria-hidden="true">
      <div class="nt-dietitian__hair"></div>
      <div class="nt-dietitian__head"></div>
      <div class="nt-dietitian__body"></div>
      <div class="nt-dietitian__legs">
        <div class="nt-dietitian__leg"></div>
        <div class="nt-dietitian__leg"></div>
      </div>
      <div class="nt-dietitian__feet">
        <div class="nt-dietitian__foot"></div>
        <div class="nt-dietitian__foot"></div>
      </div>
    </div>

    <!-- Floating info cards -->
    <div class="nt-info-card nt-info-card--1" aria-hidden="true">
      <span class="nt-info-card__icon">🏅</span> BANT Registered
    </div>
    <div class="nt-info-card nt-info-card--2" aria-hidden="true">
      <span class="nt-info-card__icon">⭐</span> 4.9 Stars · 600+ Clients
    </div>
    <div class="nt-info-card nt-info-card--3" aria-hidden="true">
      <span class="nt-info-card__icon">🌿</span> Evidence-Based Approach
    </div>

    <!-- Hero copy -->
    <div class="nt-hero__inner">
      <p class="nt-eyebrow">Registered Nutritional Therapist · BANT · CNHC</p>
      <h1 class="nt-h1 nt-hero__title">
        Nourish Your Body.<br><em>Transform Your Life.</em>
      </h1>
      <p class="nt-hero__sub">Personalised nutrition programmes rooted in functional medicine. Address the root cause — not just the symptoms — and reclaim the energy, clarity, and health you deserve.</p>
      <div class="nt-hero__ctas">
        <a href="#booking" class="nt-btn nt-btn--primary">🥗 Book a Free Discovery Call</a>
        <a href="#packages" class="nt-btn nt-btn--outline">View Programmes</a>
      </div>
    </div>
  </section>

  <!-- ── STATS ─────────────────────────────────────────────── -->
  <section class="nt-stats" aria-label="Key figures">
    <div class="nt-wrap">
      <div class="nt-stats__grid">
        <div class="nt-stat">
          <div class="nt-stat__number" data-target="14" aria-label="14 years experience">0</div>
          <div class="nt-stat__label">Years in Practice</div>
        </div>
        <div class="nt-stat">
          <div class="nt-stat__number" data-target="620" aria-label="620+ clients">0</div>
          <div class="nt-stat__label">Clients Supported</div>
        </div>
        <div class="nt-stat">
          <div class="nt-stat__number" data-target="4" data-float="1" aria-label="4.9 star rating">0</div>
          <div class="nt-stat__label">★ Average Rating</div>
        </div>
        <div class="nt-stat">
          <div class="nt-stat__number" data-target="94" aria-label="94% report improved energy">0</div>
          <div class="nt-stat__label">% Report Improved Energy</div>
        </div>
      </div>
    </div>
  </section>

  <!-- ── PHILOSOPHY / PILLARS ───────────────────────────────── -->
  <section class="nt-section nt-section--alt" aria-labelledby="nt-pillars-heading">
    <div class="nt-wrap">
      <p class="nt-eyebrow" style="text-align:center">My Approach</p>
      <h2 class="nt-h2" id="nt-pillars-heading" style="text-align:center">Functional Nutrition Philosophy</h2>
      <p class="nt-lead" style="text-align:center;max-width:620px;margin:0 auto;">I don't believe in one-size-fits-all diets. Every body is different, and your nutrition plan should be too.</p>

      <div class="nt-pillars">
        <div class="nt-pillar nt-reveal">
          <span class="nt-pillar__icon">🔬</span>
          <h3 class="nt-pillar__title">Root-Cause Focus</h3>
          <p class="nt-pillar__desc">We investigate the underlying biochemical and lifestyle drivers of your symptoms, not just mask them with supplements or restriction.</p>
        </div>
        <div class="nt-pillar nt-reveal">
          <span class="nt-pillar__icon">🧬</span>
          <h3 class="nt-pillar__title">Bio-Individual Plans</h3>
          <p class="nt-pillar__desc">Your genetics, microbiome, stress levels, and food preferences shape your plan. There is no generic prescription here — ever.</p>
        </div>
        <div class="nt-pillar nt-reveal">
          <span class="nt-pillar__icon">📊</span>
          <h3 class="nt-pillar__title">Evidence-Based</h3>
          <p class="nt-pillar__desc">Every recommendation is grounded in current peer-reviewed research and tailored to your unique test results and health history.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- ── ABOUT ─────────────────────────────────────────────── -->
  <section class="nt-section" id="about" aria-labelledby="nt-about-heading">
    <div class="nt-wrap">
      <div class="nt-about__grid">

        <div class="nt-about__visual nt-reveal" aria-hidden="true">
          <div class="nt-about__cert">🎓 BSc Nutritional Medicine</div>
          <div class="nt-about__food-grid">
            <div class="nt-food-icon">🥑<span>Avocado</span></div>
            <div class="nt-food-icon">🫐<span>Blueberry</span></div>
            <div class="nt-food-icon">🥦<span>Broccoli</span></div>
            <div class="nt-food-icon">🐟<span>Salmon</span></div>
            <div class="nt-food-icon">🌰<span>Walnuts</span></div>
            <div class="nt-food-icon">🍋<span>Lemon</span></div>
            <div class="nt-food-icon">🫛<span>Legumes</span></div>
            <div class="nt-food-icon">🌿<span>Herbs</span></div>
          </div>
          <div class="nt-about__badge">✓ BANT · CNHC · mBANT Registered</div>
        </div>

        <div class="nt-about__content nt-reveal">
          <p class="nt-eyebrow">Your Nutritional Therapist</p>
          <h2 class="nt-about__name" id="nt-about-heading">Dr. Priya Mehta mBANT</h2>
          <span class="nt-about__credential">BSc Nutritional Medicine · CNHC Registered</span>
          <p class="nt-about__body">
            After a decade spent as a hospital dietitian, I founded this practice to offer something the NHS rarely has time for: deep, unhurried, personalised nutritional care. I work with clients across the UK via video consultation, combining functional laboratory testing with real-food, sustainable strategies.
          </p>
          <p class="nt-about__body">
            My specialisms include gut health, hormonal balance, fatigue, thyroid conditions, and auto-immune nutrition. I believe food is the most powerful medicine available — when it's the right food for your unique biology.
          </p>
          <ul class="nt-about__quals">
            <li>BSc (Hons) Nutritional Medicine, University of Westminster</li>
            <li>mBANT — British Association for Nutrition & Lifestyle Medicine</li>
            <li>CNHC — Complementary & Natural Healthcare Council</li>
            <li>Institute for Functional Medicine (IFM) trained</li>
            <li>SIBO, Gut Microbiome, Dutch Hormone Testing certified</li>
          </ul>
          <a href="#booking" class="nt-btn nt-btn--primary">Book Your Free Discovery Call</a>
        </div>
      </div>
    </div>
  </section>

  <!-- ── SERVICES ───────────────────────────────────────────── -->
  <section class="nt-section nt-section--alt" id="services" aria-labelledby="nt-services-heading">
    <div class="nt-wrap">
      <p class="nt-eyebrow">How I Can Help</p>
      <h2 class="nt-h2" id="nt-services-heading">Specialisms &amp; Services</h2>
      <p class="nt-lead">From gut health to hormone balance — evidence-based nutrition for your specific needs.</p>

      <div class="nt-services__grid">

        <article class="nt-service nt-reveal">
          <span class="nt-service__icon">🫀</span>
          <h3 class="nt-service__title">Gut Health &amp; Digestion</h3>
          <p class="nt-service__desc">IBS, SIBO, leaky gut, inflammatory bowel conditions — comprehensive gut microbiome support with functional testing and a precision nutrition protocol.</p>
        </article>

        <article class="nt-service nt-reveal">
          <span class="nt-service__icon">⚡</span>
          <h3 class="nt-service__title">Fatigue &amp; Energy</h3>
          <p class="nt-service__desc">Chronic fatigue, burnout, and post-viral exhaustion — identifying mitochondrial dysfunction, nutrient deficiencies, adrenal dysregulation, and sleep disruption.</p>
        </article>

        <article class="nt-service nt-reveal">
          <span class="nt-service__icon">🌙</span>
          <h3 class="nt-service__title">Hormonal Balance</h3>
          <p class="nt-service__desc">PMS, PCOS, perimenopause, menopause, and thyroid conditions — using Dutch hormone testing and targeted nutrition to restore balance naturally.</p>
        </article>

        <article class="nt-service nt-reveal">
          <span class="nt-service__icon">🧠</span>
          <h3 class="nt-service__title">Brain Health &amp; Mood</h3>
          <p class="nt-service__desc">Anxiety, depression, brain fog, and cognitive decline — the gut-brain axis, neurotransmitter nutrition, and lifestyle interventions that support mental clarity.</p>
        </article>

        <article class="nt-service nt-reveal">
          <span class="nt-service__icon">⚖️</span>
          <h3 class="nt-service__title">Weight &amp; Metabolism</h3>
          <p class="nt-service__desc">Sustainable, non-restrictive weight management addressing insulin resistance, inflammation, and metabolic health — no calorie counting, no deprivation.</p>
        </article>

        <article class="nt-service nt-reveal">
          <span class="nt-service__icon">🛡️</span>
          <h3 class="nt-service__title">Immune &amp; Autoimmune</h3>
          <p class="nt-service__desc">Recurring infections, inflammatory conditions, and autoimmune nutrition — building resilience through gut repair, anti-inflammatory eating, and targeted supplementation.</p>
        </article>

        <article class="nt-service nt-reveal">
          <span class="nt-service__icon">🤰</span>
          <h3 class="nt-service__title">Fertility &amp; Pregnancy</h3>
          <p class="nt-service__desc">Preconception nutrition, IVF support, gestational nutrition, and postnatal recovery — supporting you through one of life's most important transitions.</p>
        </article>

        <article class="nt-service nt-reveal">
          <span class="nt-service__icon">🏃</span>
          <h3 class="nt-service__title">Sports &amp; Performance</h3>
          <p class="nt-service__desc">Fuelling athletic performance, recovery optimisation, body composition, and supplement strategy for amateur and competitive athletes.</p>
        </article>

      </div>
    </div>
  </section>

  <!-- ── CONDITIONS TAG CLOUD ───────────────────────────────── -->
  <section class="nt-conditions" aria-labelledby="nt-conditions-heading">
    <div class="nt-wrap">
      <p class="nt-eyebrow">Areas of Support</p>
      <h2 class="nt-h2" id="nt-conditions-heading">Conditions Commonly Addressed</h2>
      <div class="nt-tags">
        <?php
        $conditions = [
          'IBS','SIBO','Crohn\'s Disease','Ulcerative Colitis','GERD / Acid Reflux',
          'Hashimoto\'s Thyroiditis','Hypothyroidism','PCOS','Endometriosis','Fibroids',
          'Perimenopause','Menopause','PMS / PMDD','Chronic Fatigue Syndrome','Fibromyalgia',
          'Long COVID','Type 2 Diabetes','Insulin Resistance','Non-Alcoholic Fatty Liver',
          'High Cholesterol','Cardiovascular Risk','Rheumatoid Arthritis','Psoriasis','Eczema',
          'Anxiety','Depression','ADHD','Brain Fog','Migraines','Insomnia',
          'Osteoporosis','Iron-Deficiency Anaemia','Vitamin D Deficiency',
        ];
        foreach ($conditions as $cond) {
          echo '<span class="nt-tag">' . esc_html($cond) . '</span>';
        }
        ?>
      </div>
    </div>
  </section>

  <!-- ── PROCESS ────────────────────────────────────────────── -->
  <section class="nt-section nt-section--alt" aria-labelledby="nt-process-heading">
    <div class="nt-wrap">
      <p class="nt-eyebrow" style="text-align:center">Getting Started</p>
      <h2 class="nt-h2" id="nt-process-heading" style="text-align:center">The Journey to Better Health</h2>

      <div class="nt-process__steps">
        <div class="nt-step nt-reveal">
          <div class="nt-step__num">1</div>
          <h3 class="nt-step__title">Free Discovery Call</h3>
          <p class="nt-step__desc">A 20-minute video call to understand your health goals and confirm we're the right fit.</p>
        </div>
        <div class="nt-step nt-reveal">
          <div class="nt-step__num">2</div>
          <h3 class="nt-step__title">Initial Consultation</h3>
          <p class="nt-step__desc">A 90-minute in-depth assessment covering your health history, diet, lifestyle, and symptoms.</p>
        </div>
        <div class="nt-step nt-reveal">
          <div class="nt-step__num">3</div>
          <h3 class="nt-step__title">Lab Testing</h3>
          <p class="nt-step__desc">Where appropriate, we run functional tests — gut microbiome, DUTCH hormones, blood panels — for precision.</p>
        </div>
        <div class="nt-step nt-reveal">
          <div class="nt-step__num">4</div>
          <h3 class="nt-step__title">Your Bespoke Plan</h3>
          <p class="nt-step__desc">A personalised nutrition and lifestyle protocol, reviewed and refined every four to six weeks throughout your programme.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- ── PACKAGES ───────────────────────────────────────────── -->
  <section class="nt-section" id="packages" aria-labelledby="nt-packages-heading">
    <div class="nt-wrap">
      <p class="nt-eyebrow" style="text-align:center">Invest in Your Health</p>
      <h2 class="nt-h2" id="nt-packages-heading" style="text-align:center">Nutrition Programmes</h2>
      <p class="nt-lead" style="text-align:center">All programmes include a free 20-minute discovery call before you commit.</p>

      <div class="nt-packages__grid">

        <div class="nt-pkg nt-pkg--starter nt-reveal">
          <div class="nt-pkg__header">
            <div class="nt-pkg__name">Foundations</div>
            <div class="nt-pkg__price">£320</div>
            <div class="nt-pkg__unit">single session + action plan</div>
          </div>
          <div class="nt-pkg__body">
            <p class="nt-pkg__desc">An ideal starting point for those who need clarity and direction — a comprehensive assessment with a targeted nutrition action plan.</p>
            <ul class="nt-pkg__features">
              <li>90-minute initial consultation</li>
              <li>Detailed health & diet assessment</li>
              <li>Personalised nutrition plan</li>
              <li>Supplement recommendations</li>
              <li>Recipe guide (2 weeks)</li>
              <li>Email support for 2 weeks</li>
            </ul>
            <button class="nt-pkg__cta" onclick="document.getElementById('booking').scrollIntoView({behavior:'smooth'})">Get Started</button>
          </div>
        </div>

        <div class="nt-pkg nt-pkg--featured nt-reveal">
          <div class="nt-pkg__header">
            <div class="nt-pkg__badge">Most Popular</div>
            <div class="nt-pkg__name">Transformation</div>
            <div class="nt-pkg__price">£795</div>
            <div class="nt-pkg__unit">3-month programme</div>
          </div>
          <div class="nt-pkg__body">
            <p class="nt-pkg__desc">My signature 12-week programme for lasting change — the time needed to see real, measurable shifts in your health.</p>
            <ul class="nt-pkg__features">
              <li>90-min initial consultation</li>
              <li>5 × 50-min follow-up sessions</li>
              <li>Functional lab test review</li>
              <li>Bespoke meal planning</li>
              <li>Supplement protocol</li>
              <li>WhatsApp support between sessions</li>
              <li>Recipe library access</li>
              <li>Final review & maintenance plan</li>
            </ul>
            <button class="nt-pkg__cta" onclick="document.getElementById('booking').scrollIntoView({behavior:'smooth'})">Start Transformation</button>
          </div>
        </div>

        <div class="nt-pkg nt-pkg--deep nt-reveal">
          <div class="nt-pkg__header">
            <div class="nt-pkg__name">Precision Health</div>
            <div class="nt-pkg__price">£1,290</div>
            <div class="nt-pkg__unit">6-month deep-dive</div>
          </div>
          <div class="nt-pkg__body">
            <p class="nt-pkg__desc">For complex chronic conditions requiring in-depth functional testing and a minimum six months of dedicated, personalised support.</p>
            <ul class="nt-pkg__features">
              <li>90-min initial consultation</li>
              <li>10 × 50-min sessions</li>
              <li>Comprehensive lab panel included</li>
              <li>Dutch hormone test included</li>
              <li>Gut microbiome analysis</li>
              <li>Full supplement management</li>
              <li>Priority WhatsApp access</li>
              <li>Quarterly blood review calls</li>
            </ul>
            <button class="nt-pkg__cta" onclick="document.getElementById('booking').scrollIntoView({behavior:'smooth'})">Enquire Now</button>
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- ── TESTIMONIALS ───────────────────────────────────────── -->
  <section class="nt-section nt-section--alt" aria-labelledby="nt-testi-heading">
    <div class="nt-wrap">
      <p class="nt-eyebrow" style="text-align:center">Success Stories</p>
      <h2 class="nt-h2" id="nt-testi-heading" style="text-align:center">Client Transformations</h2>
      <div class="nt-testimonials__grid">

        <blockquote class="nt-testi nt-reveal">
          <div class="nt-testi__stars" aria-label="5 stars">★★★★★</div>
          <p class="nt-testi__quote">"After seven years of IBS and being told to 'just manage stress', Dr. Mehta found the root cause within six weeks — a SIBO overgrowth — and my symptoms resolved within three months. I'm a completely different person."</p>
          <footer>
            <div class="nt-testi__author">Clare R.</div>
            <div class="nt-testi__meta">Transformation Programme · IBS / SIBO</div>
          </footer>
        </blockquote>

        <blockquote class="nt-testi nt-reveal">
          <div class="nt-testi__stars" aria-label="5 stars">★★★★★</div>
          <p class="nt-testi__quote">"My perimenopause symptoms — hot flushes, insomnia, anxiety — were making life unbearable. The Precision Health programme changed everything. My hormone panel told a completely different story to what my GP suspected."</p>
          <footer>
            <div class="nt-testi__author">Janet M.</div>
            <div class="nt-testi__meta">Precision Health · Perimenopause</div>
          </footer>
        </blockquote>

        <blockquote class="nt-testi nt-reveal">
          <div class="nt-testi__stars" aria-label="5 stars">★★★★★</div>
          <p class="nt-testi__quote">"I came in with chronic fatigue and brain fog post-COVID. Within three months on the programme I was back at the gym and working full days. The nutritional approach Dr. Mehta takes is unlike anything I'd encountered before."</p>
          <footer>
            <div class="nt-testi__author">Daniel T.</div>
            <div class="nt-testi__meta">Transformation Programme · Long COVID</div>
          </footer>
        </blockquote>

      </div>
    </div>
  </section>

  <!-- ── FAQs ───────────────────────────────────────────────── -->
  <section class="nt-section" aria-labelledby="nt-faq-heading">
    <div class="nt-wrap">
      <p class="nt-eyebrow" style="text-align:center">Questions</p>
      <h2 class="nt-h2" id="nt-faq-heading" style="text-align:center">Frequently Asked Questions</h2>
      <div class="nt-faqs__list">

        <div class="nt-faq">
          <button class="nt-faq__q" aria-expanded="false" aria-controls="nt-faq-1">
            What is nutritional therapy and how does it differ from dietetics?
            <span class="nt-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="nt-faq__a" id="nt-faq-1" role="region">
            Nutritional therapy takes a functional medicine approach — looking at the whole person and the root causes of dysfunction using personalised nutrition, lifestyle interventions, and advanced laboratory testing. Dietetics is a regulated clinical profession primarily focused on managing diagnosed medical conditions to NHS guidelines. Both are evidence-based; they simply have different scopes and approaches.
          </div>
        </div>

        <div class="nt-faq">
          <button class="nt-faq__q" aria-expanded="false" aria-controls="nt-faq-2">
            Do I need to do laboratory testing?
            <span class="nt-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="nt-faq__a" id="nt-faq-2" role="region">
            Testing is recommended but not mandatory. For many clients — particularly those with complex or chronic conditions — functional lab testing provides invaluable precision that makes the programme significantly more effective. We discuss testing options after the initial consultation, and costs are always transparent in advance.
          </div>
        </div>

        <div class="nt-faq">
          <button class="nt-faq__q" aria-expanded="false" aria-controls="nt-faq-3">
            Are consultations available online?
            <span class="nt-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="nt-faq__a" id="nt-faq-3" role="region">
            Yes — all consultations are conducted via secure video call, which means I work with clients anywhere in the UK and internationally. Home test kits can be delivered to your door, so geography is no barrier to getting the support you need.
          </div>
        </div>

        <div class="nt-faq">
          <button class="nt-faq__q" aria-expanded="false" aria-controls="nt-faq-4">
            Will I be put on a restrictive diet?
            <span class="nt-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="nt-faq__a" id="nt-faq-4" role="region">
            Absolutely not — restrictive dieting is not my approach. We may identify specific food triggers to investigate temporarily, but the goal is always to expand what you eat, not restrict it further. Sustainable, enjoyable, abundant eating is central to everything I recommend.
          </div>
        </div>

        <div class="nt-faq">
          <button class="nt-faq__q" aria-expanded="false" aria-controls="nt-faq-5">
            Can nutritional therapy work alongside medication?
            <span class="nt-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="nt-faq__a" id="nt-faq-5" role="region">
            Yes — nutritional therapy is complementary and works alongside conventional medical treatment, not instead of it. I work closely with GPs and specialists where needed, and always consider any medications you are taking when making recommendations to avoid interactions.
          </div>
        </div>

        <div class="nt-faq">
          <button class="nt-faq__q" aria-expanded="false" aria-controls="nt-faq-6">
            How quickly will I see results?
            <span class="nt-faq__icon" aria-hidden="true">+</span>
          </button>
          <div class="nt-faq__a" id="nt-faq-6" role="region">
            Many clients notice improvements in energy and digestion within the first four to six weeks. More complex conditions — autoimmune, hormonal, deep gut issues — typically require three to six months to see significant, lasting change. I am always transparent about realistic timescales from the outset.
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- ── BOOKING ────────────────────────────────────────────── -->
  <section class="nt-booking" id="booking" aria-labelledby="nt-booking-heading">
    <div class="nt-wrap">
      <p class="nt-eyebrow" style="text-align:center">Start Your Journey</p>
      <h2 class="nt-h2" id="nt-booking-heading" style="text-align:center">Book Your Free Discovery Call</h2>
      <p class="nt-lead" style="text-align:center">Tell me about your health goals — I'll be in touch within one working day.</p>

      <div class="nt-form">
        <?php if ( function_exists( 'wp_nonce_field' ) ) : ?>
        <form method="post" action="" novalidate>
          <?php wp_nonce_field( 'tf_nt_booking', 'tf_nt_nonce' ); ?>

          <div class="nt-form__grid">

            <div>
              <label class="nt-label" for="nt-name">Full Name *</label>
              <input class="nt-input" type="text" id="nt-name" name="nt_name" required placeholder="Your full name" autocomplete="name">
            </div>

            <div>
              <label class="nt-label" for="nt-email">Email Address *</label>
              <input class="nt-input" type="email" id="nt-email" name="nt_email" required placeholder="you@example.com" autocomplete="email">
            </div>

            <div>
              <label class="nt-label" for="nt-phone">Phone Number</label>
              <input class="nt-input" type="tel" id="nt-phone" name="nt_phone" placeholder="07xxx xxxxxx" autocomplete="tel">
            </div>

            <div>
              <label class="nt-label" for="nt-age">Age Range</label>
              <select class="nt-select" id="nt-age" name="nt_age">
                <option value="">Prefer not to say</option>
                <option>Under 25</option>
                <option>25–34</option>
                <option>35–44</option>
                <option>45–54</option>
                <option>55–64</option>
                <option>65+</option>
              </select>
            </div>

            <div>
              <label class="nt-label" for="nt-concern">Primary Health Concern *</label>
              <select class="nt-select" id="nt-concern" name="nt_concern" required>
                <option value="">Please select…</option>
                <option>Gut Health / Digestion</option>
                <option>Fatigue / Low Energy</option>
                <option>Hormonal Balance</option>
                <option>Weight Management</option>
                <option>Brain Health / Mood</option>
                <option>Autoimmune Condition</option>
                <option>Fertility / Pregnancy</option>
                <option>Sports Performance</option>
                <option>General Health Optimisation</option>
                <option>Other</option>
              </select>
            </div>

            <div>
              <label class="nt-label" for="nt-programme">Programme Interest</label>
              <select class="nt-select" id="nt-programme" name="nt_programme">
                <option value="">Not sure yet</option>
                <option>Foundations (£320)</option>
                <option>Transformation — 3 months (£795)</option>
                <option>Precision Health — 6 months (£1,290)</option>
              </select>
            </div>

            <div>
              <label class="nt-label" for="nt-duration">How long have you had this concern?</label>
              <select class="nt-select" id="nt-duration" name="nt_duration">
                <option value="">Please select…</option>
                <option>Less than 3 months</option>
                <option>3–12 months</option>
                <option>1–3 years</option>
                <option>3–10 years</option>
                <option>More than 10 years</option>
              </select>
            </div>

            <div>
              <label class="nt-label" for="nt-format">Preferred Meeting Format</label>
              <select class="nt-select" id="nt-format" name="nt_format">
                <option>Video Call (Zoom / Teams)</option>
                <option>Phone Call</option>
              </select>
            </div>

            <div class="nt-form__full">
              <label class="nt-label" for="nt-goals">Tell me a little about your health goals and current challenges *</label>
              <textarea class="nt-textarea" id="nt-goals" name="nt_goals" required placeholder="The more you share, the better I can prepare for our discovery call…"></textarea>
            </div>

          </div>

          <div class="nt-form__submit">
            <button type="submit" class="nt-btn nt-btn--primary">🥗 Request Discovery Call</button>
          </div>
          <p class="nt-form__note">Free 20-min call · No obligation · Reply within 1 working day</p>

        </form>
        <?php endif; ?>
      </div>
    </div>
  </section>

  <!-- ── FOOTER CTA ─────────────────────────────────────────── -->
  <section class="nt-footer-cta" aria-label="Call to action">
    <div class="nt-wrap">
      <h2 class="nt-h2">Your Best Health Starts with One Conversation</h2>
      <p class="nt-lead">Book your free 20-minute discovery call today — no obligation, just clarity.</p>
      <a href="#booking" class="nt-btn nt-btn--outline">Book Your Free Call ↗</a>
    </div>
  </section>

</div><!-- .nt-page -->

<script>
(function () {
  'use strict';

  /* ── Animated counters ──────────────────────────────────── */
  var easeOut  = function (t) { return 1 - Math.pow(1 - t, 3); };
  var duration = 1800;

  function animateCounter(el) {
    var target  = parseFloat(el.getAttribute('data-target'));
    var isFloat = el.getAttribute('data-float') === '1';
    if (isNaN(target)) return;
    var start = null;
    function tick(ts) {
      if (!start) start = ts;
      var p = Math.min((ts - start) / duration, 1);
      var v = target * easeOut(p);
      el.textContent = isFloat ? v.toFixed(1) : Math.floor(v).toLocaleString();
      if (p < 1) requestAnimationFrame(tick);
      else el.textContent = isFloat ? target.toFixed(1) : target.toLocaleString();
    }
    requestAnimationFrame(tick);
  }

  new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (e.isIntersecting) { animateCounter(e.target); this.unobserve(e.target); }
    }.bind(this));
  }, { threshold: 0.5 }).observe
    ? (function () {
        var obs = new IntersectionObserver(function (entries, obs) {
          entries.forEach(function (e) {
            if (e.isIntersecting) { animateCounter(e.target); obs.unobserve(e.target); }
          });
        }, { threshold: 0.5 });
        document.querySelectorAll('[data-target]').forEach(function (el) { obs.observe(el); });
      })()
    : null;

  /* ── FAQ accordion ──────────────────────────────────────── */
  document.querySelectorAll('.nt-faq__q').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var expanded = this.getAttribute('aria-expanded') === 'true';
      var answerId = this.getAttribute('aria-controls');
      document.querySelectorAll('.nt-faq__q').forEach(function (b) { b.setAttribute('aria-expanded', 'false'); });
      document.querySelectorAll('.nt-faq__a').forEach(function (a) { a.classList.remove('is-open'); });
      if (!expanded) {
        this.setAttribute('aria-expanded', 'true');
        var ans = document.getElementById(answerId);
        if (ans) ans.classList.add('is-open');
      }
    });
  });

  /* ── Scroll reveal ──────────────────────────────────────── */
  var revObs = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (e.isIntersecting) { e.target.classList.add('is-visible'); revObs.unobserve(e.target); }
    });
  }, { threshold: 0.12 });
  document.querySelectorAll('.nt-reveal').forEach(function (el) { revObs.observe(el); });

  /* ── Smooth scroll ──────────────────────────────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      var t = document.querySelector(this.getAttribute('href'));
      if (t) { e.preventDefault(); t.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    });
  });

})();
</script>

<?php get_footer(); ?>
