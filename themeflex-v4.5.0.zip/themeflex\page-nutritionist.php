<?php
/**
 * Template Name: Nutritionist – Health & Nutrition Coaching
 *
 * Premium nutritionist & wellness coach homepage template.
 * DM Sans + Fraunces · --nt-* namespace · sage/cream/terracotta palette
 * CSS art-directed consulting studio hero · WCAG 2.1 AA · vanilla JS
 *
 * @package ThemeFlex
 */

defined( 'ABSPATH' ) || exit;

srand( crc32( get_the_permalink() ) );

/* ── palette ────────────────────────────────────────────────────────── */
$nt_sage      = '#6B8F71';
$nt_sage_dark = '#4A6E50';
$nt_sage_lt   = '#EEF4EF';
$nt_terra     = '#C0714A';
$nt_cream     = '#FAF7F2';
$nt_stone     = '#E8E0D4';
$nt_charcoal  = '#2C3428';
$nt_text      = '#3C4838';

/* ── food & ingredient items on desk ────────────────────────────────── */
$food_items = [
    [ 'type' => 'bowl',   'x' => 14, 'color' => '#D4A070', 'fill' => '#8BC34A', 'label' => 'Salad'     ],
    [ 'type' => 'jar',    'x' => 28, 'color' => '#8BC34A', 'fill' => '#558B2F', 'label' => 'Greens'    ],
    [ 'type' => 'avocado','x' => 44, 'color' => '#558B2F', 'fill' => '#8BC34A', 'label' => 'Avocado'   ],
    [ 'type' => 'jar',    'x' => 60, 'color' => '#C0714A', 'fill' => '#E8A060', 'label' => 'Honey'     ],
    [ 'type' => 'bowl',   'x' => 74, 'color' => '#B07840', 'fill' => '#8BC34A', 'label' => 'Grains'    ],
    [ 'type' => 'lemon',  'x' => 88, 'color' => '#F5E030', 'fill' => '#E8C820', 'label' => 'Lemon'     ],
];

/* ── floating nutrients/food icons ──────────────────────────────────── */
$floaters = [];
for ( $i = 0; $i < 18; $i++ ) {
    $icons = [ '🥑', '🫐', '🥦', '🍋', '🌿', '🫚', '🥕', '🥗', '🍎', '🫚' ];
    $floaters[] = [
        'icon'  => $icons[ $i % count($icons) ],
        'x'     => rand( 3, 97 ),
        'y'     => rand( 5, 85 ),
        'sz'    => rand( 14, 26 ),
        'op'    => rand( 8, 22 ),
        'delay' => rand( 0, 80 ) / 10,
        'dur'   => rand( 35, 70 ) / 10,
    ];
}

/* ── bookshelf items ─────────────────────────────────────────────────── */
$books = [];
$book_colors = [ '#C0714A','#6B8F71','#4A6E50','#8B6340','#C8A850','#5A7A68' ];
for ( $i = 0; $i < 10; $i++ ) {
    $books[] = [
        'w'     => rand( 14, 22 ),
        'h'     => rand( 80, 110 ),
        'color' => $book_colors[ $i % count($book_colors) ],
        'tilt'  => rand( -5, 5 ),
    ];
}

/* ── programs ────────────────────────────────────────────────────────── */
$programs = [
    [ 'icon' => '🌱', 'title' => 'Gut Health Reset',         'desc' => 'A 6-week evidence-based protocol to restore gut microbiome balance, reduce inflammation, and improve digestion.' ],
    [ 'icon' => '⚡', 'title' => 'Energy & Performance',      'desc' => 'Optimise your nutrition for sustained energy, mental clarity, and physical performance throughout the day.' ],
    [ 'icon' => '⚖️', 'title' => 'Weight Management',         'desc' => 'A sustainable, science-led approach to reaching and maintaining a healthy weight without restrictive dieting.' ],
    [ 'icon' => '🧠', 'title' => 'Hormonal Balance',          'desc' => 'Targeted nutrition strategies to support hormonal health, mood, and sleep across all life stages.' ],
    [ 'icon' => '🏃', 'title' => 'Sports Nutrition',          'desc' => 'Bespoke fuelling strategies for endurance, strength, and recovery, tailored to your training load.' ],
    [ 'icon' => '❤️', 'title' => 'Heart Health',              'desc' => 'Cardioprotective dietary patterns with personalised targets for lipids, blood pressure, and metabolic health.' ],
];

/* ── how it works ────────────────────────────────────────────────────── */
$process = [
    [ 'step' => '01', 'title' => 'Discovery Call',        'desc' => 'A complimentary 20-minute call to understand your health goals and confirm we are the right fit.' ],
    [ 'step' => '02', 'title' => 'In-Depth Assessment',   'desc' => 'A 90-minute initial consultation covering diet history, health markers, lifestyle, and lab data.' ],
    [ 'step' => '03', 'title' => 'Personalised Plan',     'desc' => 'A fully customised nutrition protocol, meal framework, and supplement strategy within 48 hours.' ],
    [ 'step' => '04', 'title' => 'Ongoing Support',       'desc' => 'Regular check-ins, plan adjustments, and accountability coaching to keep you on track.' ],
];

/* ── packages ────────────────────────────────────────────────────────── */
$packages = [
    [
        'name'     => 'Single Session',
        'price'    => '£150',
        'period'   => '/ 60 min',
        'featured' => false,
        'items'    => [ 'Full dietary assessment', 'Personalised recommendations', 'Supplement guidance', 'Written summary report', 'Resources & recipe guide', 'Email follow-up within 48h' ],
    ],
    [
        'name'     => '12-Week Programme',
        'price'    => '£780',
        'period'   => '/ full programme',
        'featured' => true,
        'items'    => [ 'Initial 90-min assessment', '5 follow-up consultations', 'Bespoke meal framework', 'Weekly check-in messages', 'Lab result interpretation', 'Recipe vault access', 'Priority email support' ],
    ],
    [
        'name'     => 'VIP Intensive',
        'price'    => 'POA',
        'period'   => '/ bespoke',
        'featured' => false,
        'items'    => [ 'Unlimited consultations', 'Full lab panel co-ordination', 'Functional testing support', 'Meal plan & shopping lists', 'Corporate & team packages', 'Speaker & media enquiries' ],
    ],
];

/* ── counters ────────────────────────────────────────────────────────── */
$counters = [
    [ 'value' => 14,   'suffix' => 'yrs',   'label' => 'In Practice',     'float' => false ],
    [ 'value' => 3200, 'suffix' => '+',      'label' => 'Clients Coached', 'float' => false ],
    [ 'value' => 4.9,  'suffix' => '★',     'label' => 'Client Rating',   'float' => true  ],
    [ 'value' => 93,   'suffix' => '%',      'label' => 'Achieve Goals',   'float' => false ],
];

/* ── credentials ─────────────────────────────────────────────────────── */
$creds = [
    [ 'badge' => 'ANutr',  'name' => 'Registered Associate Nutritionist',   'body' => 'AfN' ],
    [ 'badge' => 'mBANT',  'name' => 'British Association for Nutrition',   'body' => 'BANT' ],
    [ 'badge' => 'CNHC',   'name' => 'Complementary & Natural Healthcare',  'body' => 'CNHC' ],
    [ 'badge' => 'MSc',    'name' => 'MSc Nutritional Medicine',            'body' => 'University of Surrey' ],
];

/* ── testimonials ────────────────────────────────────────────────────── */
$testimonials = [
    [ 'text' => 'Working with Olivia completely changed my relationship with food. After years of failed diets, her approach felt refreshingly non-restrictive and the results have been life-changing.', 'name' => 'Catherine M.', 'goal' => 'Weight Management' ],
    [ 'text' => 'My energy levels have been transformed. I used to crash every afternoon — now I sail through the day without needing caffeine. The science behind the plan made me trust the process completely.', 'name' => 'Jonathan R.', 'goal' => 'Energy Optimisation' ],
    [ 'text' => 'Three months of gut health coaching resolved digestive issues I had struggled with for a decade. Olivia is thorough, empathetic, and genuinely invested in long-term results.', 'name' => 'Sophia K.', 'goal' => 'Gut Health Reset' ],
];

get_header();
?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&family=Fraunces:ital,wght@0,300;0,400;0,600;0,700;1,300;1,400&display=swap" rel="stylesheet">

<style>
/* ═══════════════════════════════════════════════════════════════════════
   NUTRITIONIST — CSS CUSTOM PROPERTIES
═══════════════════════════════════════════════════════════════════════ */
:root {
    --nt-sage:      <?= $nt_sage ?>;
    --nt-sage-dark: <?= $nt_sage_dark ?>;
    --nt-sage-lt:   <?= $nt_sage_lt ?>;
    --nt-terra:     <?= $nt_terra ?>;
    --nt-cream:     <?= $nt_cream ?>;
    --nt-stone:     <?= $nt_stone ?>;
    --nt-charcoal:  <?= $nt_charcoal ?>;
    --nt-text:      <?= $nt_text ?>;

    --nt-ff-head: 'DM Sans', sans-serif;
    --nt-ff-body: 'Fraunces', serif;

    --nt-radius:  8px;
    --nt-shadow:  0 4px 24px rgba(44,52,40,.10);
    --nt-trans:   .3s cubic-bezier(.4,0,.2,1);
}

/* ── reset ──────────────────────────────────────────────────────────── */
.nt-wrap *, .nt-wrap *::before, .nt-wrap *::after { box-sizing: border-box; margin: 0; padding: 0; }
.nt-wrap { font-family: var(--nt-ff-body); color: var(--nt-text); background: var(--nt-cream); overflow-x: hidden; }
.nt-container { max-width: 1160px; margin: 0 auto; padding: 0 24px; }

/* ── typography ─────────────────────────────────────────────────────── */
.nt-section-label { font-family: var(--nt-ff-head); font-size: .72rem; font-weight: 600; letter-spacing: .18em; text-transform: uppercase; color: var(--nt-sage); display: block; margin-bottom: 12px; }
.nt-section-title { font-family: var(--nt-ff-body); font-size: clamp(1.8rem, 3.5vw, 2.8rem); font-weight: 600; line-height: 1.2; color: var(--nt-charcoal); }
.nt-section-title em { font-style: italic; color: var(--nt-sage); }
.nt-section-body  { font-size: 1rem; line-height: 1.85; color: #5A6858; margin-top: 18px; font-weight: 300; }

/* ── buttons ────────────────────────────────────────────────────────── */
.nt-btn { display: inline-flex; align-items: center; gap: 8px; font-family: var(--nt-ff-head); font-size: .88rem; font-weight: 600; padding: 13px 28px; border-radius: 50px; cursor: pointer; border: 2px solid transparent; text-decoration: none; transition: var(--nt-trans); }
.nt-btn--primary { background: var(--nt-sage); color: #fff; }
.nt-btn--primary:hover { background: var(--nt-sage-dark); transform: translateY(-2px); box-shadow: 0 8px 24px rgba(107,143,113,.35); }
.nt-btn--ghost { background: transparent; color: #fff; border-color: rgba(255,255,255,.6); border-radius: 50px; }
.nt-btn--ghost:hover { background: rgba(255,255,255,.12); }
.nt-btn--outline { background: transparent; color: var(--nt-sage); border-color: var(--nt-sage); border-radius: 50px; }
.nt-btn--outline:hover { background: var(--nt-sage); color: #fff; }

/* ════════════════════════════════════════════════════════════════════
   HERO
════════════════════════════════════════════════════════════════════ */
.nt-hero { position: relative; min-height: 94vh; display: flex; align-items: center; overflow: hidden;
    background: linear-gradient(150deg, #2C3C28 0%, #3A5035 40%, #2A3C28 100%); }

/* ── studio scene ─────────────────────────────────────────────────── */
.nt-scene { position: absolute; inset: 0; overflow: hidden; }

/* walls & floor */
.nt-scene__ceiling { position: absolute; top: 0; left: 0; right: 0; height: 10%; background: linear-gradient(180deg, #E8E0D0 0%, #DDD5C4 100%); }
.nt-scene__wall { position: absolute; top: 10%; left: 0; right: 0; bottom: 26%; background: linear-gradient(180deg, #E0D8C8 0%, #D4CABC 100%); }
/* linen texture */
.nt-scene__wall::after { content: ''; position: absolute; inset: 0; background: repeating-linear-gradient(0deg, rgba(107,143,113,.04) 0px, rgba(107,143,113,.04) 1px, transparent 1px, transparent 18px), repeating-linear-gradient(90deg, rgba(107,143,113,.03) 0px, rgba(107,143,113,.03) 1px, transparent 1px, transparent 40px); }
.nt-scene__floor { position: absolute; bottom: 0; left: 0; right: 0; height: 26%; background: linear-gradient(180deg, #B8A88A 0%, #A09070 100%); }
.nt-scene__floor-line { position: absolute; top: 0; left: 0; right: 0; height: 3px; background: #908060; }
/* floor boards */
.nt-scene__floor::before { content: ''; position: absolute; inset: 0; background: repeating-linear-gradient(90deg, rgba(0,0,0,.06) 0px, rgba(0,0,0,.06) 1px, transparent 1px, transparent 80px); }

/* large arch window */
.nt-scene__window { position: absolute; top: 10%; left: 62%; width: 28%; bottom: 26%; background: linear-gradient(180deg, #A8D4B8 0%, #88C0A0 60%, #70A888 100%); border-radius: 50% 50% 0 0 / 30% 30% 0 0; overflow: hidden; border: 8px solid #C8C0B0; border-bottom: none; }
.nt-scene__window::before { content: ''; position: absolute; inset: 0; background: radial-gradient(ellipse at 35% 30%, rgba(255,255,255,.4) 0%, transparent 60%); }
/* foliage silhouette in window */
.nt-scene__window::after { content: ''; position: absolute; bottom: 0; left: -10%; right: -10%; height: 70%; background: radial-gradient(ellipse at 50% 100%, #3A6040 0%, #2A4830 40%, transparent 70%), radial-gradient(ellipse at 20% 90%, #4A7050 0%, transparent 50%), radial-gradient(ellipse at 80% 95%, #3A6040 0%, transparent 50%); }
/* window pane cross */
.nt-scene__window-bar-h { position: absolute; top: 50%; left: 0; right: 0; height: 6px; background: #C8C0B0; transform: translateY(-50%); }
.nt-scene__window-bar-v { position: absolute; top: 0; bottom: 0; left: 50%; width: 6px; background: #C8C0B0; transform: translateX(-50%); }

/* consulting table */
.nt-scene__table { position: absolute; bottom: 26%; left: 8%; width: 50%; }
.nt-scene__table-top { height: 14px; background: linear-gradient(180deg, #E0D0B8 0%, #C8B898 100%); border-radius: 3px 3px 0 0; box-shadow: 0 -2px 6px rgba(0,0,0,.15); }
.nt-scene__table-body { height: 44px; background: linear-gradient(180deg, #C8B898 0%, #B0A080 100%); position: relative; }
.nt-scene__table-leg-l { position: absolute; bottom: -32px; left: 8%; width: 8px; height: 32px; background: #A09070; border-radius: 0 0 2px 2px; }
.nt-scene__table-leg-r { position: absolute; bottom: -32px; right: 8%; width: 8px; height: 32px; background: #A09070; border-radius: 0 0 2px 2px; }

/* bookshelf on right wall */
.nt-scene__shelf { position: absolute; top: 15%; right: 3%; width: 18%; }
.nt-scene__shelf-board { height: 8px; background: #C8B898; border-radius: 1px; margin-bottom: 4px; box-shadow: 0 2px 4px rgba(0,0,0,.2); }
.nt-scene__shelf-bracket { position: absolute; right: 4px; bottom: 0; width: 4px; height: 24px; background: #B0A080; }
.nt-scene__shelf-bracket--l { left: 4px; right: auto; }
.nt-scene__books { display: flex; align-items: flex-end; padding: 0 2px; gap: 2px; height: 80px; }

/* plant */
.nt-scene__plant-corner { position: absolute; bottom: 26%; left: 2%; }
.nt-scene__pot-corner { width: 32px; height: 26px; background: linear-gradient(180deg, <?= $nt_terra ?> 0%, #A05030 100%); clip-path: polygon(8% 0%, 92% 0%, 100% 100%, 0% 100%); margin: 0 auto; }
.nt-scene__stem-corner { width: 4px; background: linear-gradient(180deg, #4A7040 0%, #3A5828 100%); margin: 0 auto; border-radius: 2px; }
.nt-scene__leaf-group { position: relative; width: 60px; margin: 0 auto; }
.nt-scene__leaf-big { position: absolute; border-radius: 0 80% 0 80%; background: radial-gradient(ellipse at 30% 40%, #6B9060 0%, #3A6030 100%); }

/* floating food icons */
.nt-floater { position: absolute; animation: nt-float linear infinite; pointer-events: none; }
@keyframes nt-float { 0%,100%{ transform:translateY(0); } 50%{ transform:translateY(-10px); } }

/* nutritionist figure at desk */
.nt-scene__nutritionist { position: absolute; bottom: 26%; left: 22%; }
.nt-nutritionist-fig { position: relative; }
.nt-nutritionist-fig__head { width: 28px; height: 32px; background: #DEB887; border-radius: 50% 50% 40% 40%; margin: 0 auto; position: relative; }
.nt-nutritionist-fig__hair { position: absolute; top: 0; left: 0; right: 0; height: 18px; background: #3D1C02; clip-path: ellipse(50% 55% at 50% 0%); }
.nt-nutritionist-fig__hair::before { content: ''; position: absolute; top: 4px; right: -4px; width: 8px; height: 14px; background: #3D1C02; border-radius: 0 4px 4px 0; } /* side bun */
.nt-nutritionist-fig__neck { width: 12px; height: 8px; background: #DEB887; margin: 0 auto; }
.nt-nutritionist-fig__body { width: 36px; height: 52px; background: var(--nt-sage); border-radius: 2px 2px 0 0; margin: 0 auto; position: relative; }
.nt-nutritionist-fig__body::before { content: ''; position: absolute; top: 6px; left: 50%; transform: translateX(-50%); width: 1px; height: 28px; background: rgba(255,255,255,.3); box-shadow: -4px 0 0 rgba(255,255,255,.2), 4px 0 0 rgba(255,255,255,.2); } /* button line */
.nt-nutritionist-fig__arm-l { position: absolute; left: -10px; top: 10px; width: 10px; height: 28px; background: var(--nt-sage); border-radius: 4px 0 0 4px; }
.nt-nutritionist-fig__arm-r { position: absolute; right: -10px; top: 10px; width: 10px; height: 28px; background: var(--nt-sage); border-radius: 0 4px 4px 0; }
/* clipboard in hand */
.nt-nutritionist-fig__clipboard { position: absolute; right: -18px; top: 4px; width: 16px; height: 22px; background: #F5F0E8; border: 1px solid #C8B898; border-radius: 1px; }
.nt-nutritionist-fig__clipboard::before { content: ''; position: absolute; top: 3px; left: 2px; right: 2px; height: 1px; background: #8A9880; box-shadow: 0 4px 0 #8A9880, 0 8px 0 #8A9880, 0 12px 0 #8A9880; }

/* hero content */
.nt-hero__content { position: relative; z-index: 10; max-width: 580px; padding: 60px 0; }
.nt-hero__eyebrow { font-family: var(--nt-ff-head); font-size: .72rem; font-weight: 600; letter-spacing: .2em; text-transform: uppercase; color: rgba(238,244,239,.8); margin-bottom: 14px; }
.nt-hero__title { font-family: var(--nt-ff-body); font-size: clamp(2.4rem, 5vw, 4rem); font-weight: 600; line-height: 1.12; color: #fff; }
.nt-hero__title em { font-style: italic; color: #A8D4A0; }
.nt-hero__sub { font-size: .98rem; line-height: 1.85; color: rgba(255,255,255,.76); margin: 20px 0 32px; font-weight: 300; }
.nt-hero__ctas { display: flex; gap: 14px; flex-wrap: wrap; }
.nt-hero__trust { display: flex; gap: 20px; margin-top: 28px; flex-wrap: wrap; }
.nt-hero__trust-item { display: flex; align-items: center; gap: 6px; font-family: var(--nt-ff-head); font-size: .78rem; font-weight: 500; color: rgba(255,255,255,.8); }
.nt-hero__trust-item span { display: flex; align-items: center; justify-content: center; width: 18px; height: 18px; background: var(--nt-sage); border-radius: 50%; font-size: .6rem; color: #fff; }

/* ════════════════════════════════════════════════════════════════════
   TRUST BAR
════════════════════════════════════════════════════════════════════ */
.nt-trust { background: #fff; border-bottom: 1px solid var(--nt-stone); }
.nt-trust__inner { display: flex; align-items: center; justify-content: center; flex-wrap: wrap; }
.nt-trust__item { display: flex; align-items: center; gap: 12px; padding: 20px 32px; border-right: 1px solid var(--nt-stone); }
.nt-trust__item:last-child { border-right: none; }
.nt-trust__icon { font-size: 1.4rem; }
.nt-trust__label { font-family: var(--nt-ff-head); font-size: .78rem; font-weight: 600; color: var(--nt-charcoal); }
.nt-trust__sub { font-size: .7rem; color: #8A9A88; }

/* ════════════════════════════════════════════════════════════════════
   PROGRAMS
════════════════════════════════════════════════════════════════════ */
.nt-programs { padding: 100px 0; background: var(--nt-cream); }
.nt-programs__header { text-align: center; max-width: 580px; margin: 0 auto 60px; }
.nt-programs__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 24px; }
.nt-program-card { background: #fff; border-radius: var(--nt-radius); padding: 36px 32px; border: 1px solid var(--nt-stone); transition: var(--nt-trans); position: relative; overflow: hidden; }
.nt-program-card::after { content: ''; position: absolute; bottom: 0; left: 0; right: 0; height: 4px; background: linear-gradient(90deg, var(--nt-sage), var(--nt-sage-dark)); transform: scaleX(0); transform-origin: left; transition: var(--nt-trans); }
.nt-program-card:hover { transform: translateY(-4px); box-shadow: var(--nt-shadow); }
.nt-program-card:hover::after { transform: scaleX(1); }
.nt-program-card__icon { font-size: 2.4rem; margin-bottom: 18px; display: block; }
.nt-program-card__title { font-family: var(--nt-ff-head); font-size: 1.08rem; font-weight: 700; color: var(--nt-charcoal); margin-bottom: 10px; }
.nt-program-card__desc { font-size: .9rem; line-height: 1.75; color: #5A6858; font-weight: 300; }

/* ════════════════════════════════════════════════════════════════════
   COUNTERS
════════════════════════════════════════════════════════════════════ */
.nt-counters { background: linear-gradient(135deg, var(--nt-sage-dark) 0%, var(--nt-charcoal) 100%); padding: 80px 0; }
.nt-counters__grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 40px; text-align: center; }
.nt-counter__value { font-family: var(--nt-ff-head); font-size: clamp(2.2rem, 4vw, 3.2rem); font-weight: 700; color: #fff; line-height: 1; }
.nt-counter__value span { color: #A8D4A0; }
.nt-counter__label { font-family: var(--nt-ff-head); font-size: .78rem; font-weight: 500; color: rgba(255,255,255,.58); text-transform: uppercase; letter-spacing: .12em; margin-top: 10px; }

/* ════════════════════════════════════════════════════════════════════
   PROCESS
════════════════════════════════════════════════════════════════════ */
.nt-process { padding: 100px 0; background: var(--nt-sage-lt); }
.nt-process__header { text-align: center; max-width: 560px; margin: 0 auto 60px; }
.nt-process__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 32px; }
.nt-process-card { background: #fff; border-radius: var(--nt-radius); padding: 36px 28px; text-align: center; border: 1px solid rgba(107,143,113,.15); transition: var(--nt-trans); }
.nt-process-card:hover { transform: translateY(-4px); box-shadow: var(--nt-shadow); }
.nt-process-card__step { font-family: var(--nt-ff-head); font-size: 2.8rem; font-weight: 800; color: var(--nt-sage-lt); line-height: 1; margin-bottom: 16px; position: relative; display: inline-block; }
.nt-process-card__step::after { content: attr(data-step); position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; font-size: 1rem; color: var(--nt-sage); font-weight: 700; }
.nt-process-card__title { font-family: var(--nt-ff-head); font-size: 1rem; font-weight: 700; color: var(--nt-charcoal); margin-bottom: 10px; }
.nt-process-card__desc { font-size: .88rem; line-height: 1.75; color: #5A6858; font-weight: 300; }

/* ════════════════════════════════════════════════════════════════════
   ABOUT
════════════════════════════════════════════════════════════════════ */
.nt-about { padding: 100px 0; background: #fff; }
.nt-about__inner { display: grid; grid-template-columns: 1fr 1fr; gap: 72px; align-items: center; }

/* CSS nutrition desk scene */
.nt-desk-scene { height: 360px; background: linear-gradient(180deg, var(--nt-sage-lt) 0%, #D8E8D8 100%); border-radius: var(--nt-radius); position: relative; overflow: hidden; }
/* floor */
.nt-desk-scene::before { content: ''; position: absolute; bottom: 0; left: 0; right: 0; height: 30%; background: linear-gradient(180deg, #B8A880 0%, #A09070 100%); }
/* wall texture */
.nt-desk-scene::after { content: ''; position: absolute; inset: 0 0 30% 0; background: repeating-linear-gradient(0deg, rgba(107,143,113,.05) 0px, rgba(107,143,113,.05) 1px, transparent 1px, transparent 20px); }
/* small window */
.nt-desk-scene__window { position: absolute; top: 12%; right: 10%; width: 30%; height: 35%; background: linear-gradient(180deg, #A8D4B8 0%, #88C0A0 100%); border-radius: 50% 50% 0 0 / 40% 40% 0 0; border: 5px solid #C8C0B0; border-bottom: none; overflow: hidden; }
.nt-desk-scene__window::before { content: ''; position: absolute; bottom: 0; left: 0; right: 0; height: 60%; background: radial-gradient(ellipse at 50% 100%, #4A7050 0%, transparent 60%); }
/* writing desk */
.nt-desk-scene__desk { position: absolute; bottom: 30%; left: 5%; width: 55%; }
.nt-desk-scene__desk-top { height: 10px; background: linear-gradient(180deg, #E0D0B0 0%, #C8B890 100%); border-radius: 2px 2px 0 0; }
.nt-desk-scene__desk-body { height: 36px; background: linear-gradient(180deg, #C8B890 0%, #B0A070 100%); }
.nt-desk-scene__desk-leg { position: absolute; bottom: -24px; width: 6px; height: 24px; background: #A09060; }
/* laptop on desk */
.nt-desk-scene__laptop { position: absolute; top: -40px; left: 10%; width: 52px; }
.nt-desk-scene__screen { height: 32px; background: linear-gradient(135deg, #2C3A28 0%, #1A2818 100%); border: 2px solid #6A8060; border-radius: 2px 2px 0 0; position: relative; overflow: hidden; }
.nt-desk-scene__screen::before { content: ''; position: absolute; inset: 4px; background: repeating-linear-gradient(0deg, rgba(107,143,113,.2) 0px, rgba(107,143,113,.2) 1px, transparent 1px, transparent 5px); }
.nt-desk-scene__hinge { height: 3px; background: #4A5A48; }
.nt-desk-scene__keyboard { height: 6px; background: linear-gradient(180deg, #D8CEB8 0%, #C8BEA8 100%); border-radius: 0 0 2px 2px; }
/* food bowl on desk */
.nt-desk-scene__bowl { position: absolute; top: -34px; right: 12%; width: 32px; height: 18px; background: radial-gradient(ellipse at 50% 30%, #6B9060 0%, #3A6030 100%); border-radius: 50% 50% 45% 45%; }
.nt-desk-scene__bowl::after { content: ''; position: absolute; bottom: 0; left: 10%; right: 10%; height: 6px; background: #C8B898; border-radius: 0 0 50% 50%; }
/* credentials on wall */
.nt-desk-scene__frame { position: absolute; top: 14%; left: 4%; width: 28px; height: 36px; background: #F5F0E8; border: 2px solid #C8B898; border-radius: 1px; }
.nt-desk-scene__frame::before { content: ''; position: absolute; inset: 3px; border: 1px solid rgba(107,143,113,.3); }
.nt-desk-scene__frame-2 { left: 10%; top: 18%; width: 24px; height: 30px; }

.nt-about__text { }
.nt-about__cred { display: flex; gap: 14px; align-items: flex-start; margin-top: 20px; }
.nt-about__cred-badge { flex-shrink: 0; width: 48px; height: 48px; background: var(--nt-sage-lt); border: 2px solid rgba(107,143,113,.3); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-family: var(--nt-ff-head); font-size: .62rem; font-weight: 800; color: var(--nt-sage); text-align: center; line-height: 1.1; }
.nt-about__cred-text strong { font-family: var(--nt-ff-head); font-size: .88rem; font-weight: 700; color: var(--nt-charcoal); display: block; margin-bottom: 2px; }
.nt-about__cred-text span { font-size: .78rem; color: #6A7A68; }

/* ════════════════════════════════════════════════════════════════════
   PACKAGES
════════════════════════════════════════════════════════════════════ */
.nt-packages { padding: 100px 0; background: var(--nt-cream); }
.nt-packages__header { text-align: center; max-width: 580px; margin: 0 auto 60px; }
.nt-packages__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 24px; align-items: start; }
.nt-package-card { background: #fff; border-radius: var(--nt-radius); padding: 40px 36px; border: 1px solid var(--nt-stone); position: relative; transition: var(--nt-trans); }
.nt-package-card:hover { transform: translateY(-4px); box-shadow: var(--nt-shadow); }
.nt-package-card--featured { background: linear-gradient(160deg, var(--nt-sage) 0%, var(--nt-sage-dark) 100%); border-color: transparent; }
.nt-package-card--featured .nt-package-card__name,
.nt-package-card--featured .nt-package-card__price,
.nt-package-card--featured .nt-package-card__period,
.nt-package-card--featured .nt-package-card__item { color: rgba(255,255,255,.95); }
.nt-package-card--featured .nt-package-card__item::before { background: rgba(255,255,255,.7); }
.nt-package-card__badge { position: absolute; top: -1px; right: 24px; background: var(--nt-terra); color: #fff; font-family: var(--nt-ff-head); font-size: .68rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; padding: 4px 14px 5px; border-radius: 0 0 6px 6px; }
.nt-package-card__name { font-family: var(--nt-ff-head); font-size: 1.1rem; font-weight: 700; color: var(--nt-charcoal); margin-bottom: 20px; }
.nt-package-card__price-row { display: flex; align-items: baseline; gap: 4px; margin-bottom: 28px; }
.nt-package-card__price { font-family: var(--nt-ff-head); font-size: 2.4rem; font-weight: 800; color: var(--nt-charcoal); }
.nt-package-card__period { font-size: .85rem; color: #7A8A78; }
.nt-package-card__list { list-style: none; display: flex; flex-direction: column; gap: 10px; margin-bottom: 30px; }
.nt-package-card__item { font-size: .88rem; color: #4A5A48; padding-left: 20px; position: relative; font-weight: 300; }
.nt-package-card__item::before { content: ''; position: absolute; left: 0; top: 50%; transform: translateY(-50%); width: 8px; height: 8px; border-radius: 50%; background: var(--nt-sage); }

/* ════════════════════════════════════════════════════════════════════
   TESTIMONIALS
════════════════════════════════════════════════════════════════════ */
.nt-testimonials { padding: 100px 0; background: var(--nt-sage-lt); }
.nt-testimonials__header { text-align: center; max-width: 560px; margin: 0 auto 56px; }
.nt-testimonials__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 24px; }
.nt-testimonial { background: #fff; border-radius: var(--nt-radius); padding: 36px; border: 1px solid rgba(107,143,113,.15); }
.nt-testimonial__stars { color: var(--nt-terra); font-size: .95rem; letter-spacing: 2px; margin-bottom: 18px; }
.nt-testimonial__text { font-size: .95rem; line-height: 1.85; color: #4A5A48; font-style: italic; font-weight: 300; }
.nt-testimonial__author { margin-top: 22px; display: flex; gap: 12px; align-items: center; }
.nt-testimonial__avatar { width: 40px; height: 40px; background: linear-gradient(135deg, var(--nt-sage), var(--nt-sage-dark)); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-family: var(--nt-ff-head); font-size: .88rem; font-weight: 700; color: #fff; }
.nt-testimonial__name { font-family: var(--nt-ff-head); font-size: .88rem; font-weight: 700; color: var(--nt-charcoal); }
.nt-testimonial__goal { font-size: .78rem; color: var(--nt-sage); }

/* ════════════════════════════════════════════════════════════════════
   BOOKING
════════════════════════════════════════════════════════════════════ */
.nt-booking { padding: 100px 0; background: #fff; }
.nt-booking__inner { display: grid; grid-template-columns: 1fr 1fr; gap: 72px; align-items: start; }
.nt-form { background: var(--nt-cream); border-radius: var(--nt-radius); padding: 40px; border: 1px solid var(--nt-stone); }
.nt-form__title { font-family: var(--nt-ff-head); font-size: 1.3rem; font-weight: 700; color: var(--nt-charcoal); margin-bottom: 28px; }
.nt-form__row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.nt-form__group { display: flex; flex-direction: column; gap: 6px; margin-bottom: 18px; }
.nt-form__group--full { grid-column: 1 / -1; }
.nt-form__label { font-family: var(--nt-ff-head); font-size: .78rem; font-weight: 600; color: var(--nt-charcoal); letter-spacing: .03em; }
.nt-form__input, .nt-form__select, .nt-form__textarea { width: 100%; padding: 11px 15px; border: 1px solid var(--nt-stone); border-radius: var(--nt-radius); font-family: var(--nt-ff-body); font-size: .88rem; color: var(--nt-text); background: #fff; transition: var(--nt-trans); outline: none; font-weight: 300; }
.nt-form__input:focus, .nt-form__select:focus, .nt-form__textarea:focus { border-color: var(--nt-sage); box-shadow: 0 0 0 3px rgba(107,143,113,.12); }
.nt-form__textarea { resize: vertical; min-height: 100px; }
.nt-form__submit { width: 100%; padding: 14px; font-family: var(--nt-ff-head); font-size: .92rem; font-weight: 700; color: #fff; background: linear-gradient(135deg, var(--nt-sage) 0%, var(--nt-sage-dark) 100%); border: none; border-radius: 50px; cursor: pointer; transition: var(--nt-trans); }
.nt-form__submit:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(107,143,113,.35); }
.nt-form__note { font-size: .75rem; color: #8A9A88; text-align: center; margin-top: 12px; font-weight: 300; }

.nt-booking__info { }
.nt-booking__faq { margin-top: 32px; display: flex; flex-direction: column; gap: 16px; }
.nt-booking__faq-item { padding: 18px 20px; background: var(--nt-cream); border-radius: var(--nt-radius); border: 1px solid var(--nt-stone); }
.nt-booking__faq-q { font-family: var(--nt-ff-head); font-size: .9rem; font-weight: 700; color: var(--nt-charcoal); margin-bottom: 6px; }
.nt-booking__faq-a { font-size: .85rem; color: #5A6858; line-height: 1.65; font-weight: 300; }

/* ════════════════════════════════════════════════════════════════════
   FOOTER CTA
════════════════════════════════════════════════════════════════════ */
.nt-footer-cta { background: linear-gradient(135deg, var(--nt-sage-dark) 0%, var(--nt-charcoal) 100%); padding: 80px 0; text-align: center; }
.nt-footer-cta__title { font-family: var(--nt-ff-body); font-size: clamp(1.8rem, 3.5vw, 2.8rem); font-weight: 600; color: #fff; margin-bottom: 14px; }
.nt-footer-cta__sub { font-size: 1rem; color: rgba(255,255,255,.7); margin-bottom: 36px; font-weight: 300; }
.nt-footer-cta__actions { display: flex; gap: 14px; justify-content: center; flex-wrap: wrap; }

/* ════════════════════════════════════════════════════════════════════
   RESPONSIVE
════════════════════════════════════════════════════════════════════ */
@media (max-width: 900px) {
    .nt-about__inner, .nt-booking__inner { grid-template-columns: 1fr; gap: 48px; }
    .nt-counters__grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 600px) {
    .nt-hero { min-height: 80vh; }
    .nt-counters__grid { grid-template-columns: repeat(2, 1fr); }
    .nt-form__row { grid-template-columns: 1fr; }
    .nt-trust__item { border-right: none; border-bottom: 1px solid var(--nt-stone); width: 100%; }
}
</style>

<div class="nt-wrap">

    <!-- ═══════════════════════════════════ HERO ═══════════════════════════════════ -->
    <section class="nt-hero">
        <div class="nt-scene" aria-hidden="true">

            <!-- studio architecture -->
            <div class="nt-scene__ceiling"></div>
            <div class="nt-scene__wall"></div>
            <div class="nt-scene__floor">
                <div class="nt-scene__floor-line"></div>
            </div>

            <!-- arch window -->
            <div class="nt-scene__window">
                <div class="nt-scene__window-bar-h"></div>
                <div class="nt-scene__window-bar-v"></div>
            </div>

            <!-- corner plant -->
            <div class="nt-scene__plant-corner">
                <?php
                $corner_leaves = [
                    ['w'=>36,'h'=>22,'left'=>-20,'bot'=>55,'rot'=>-40],
                    ['w'=>40,'h'=>24,'left'=>6,'bot'=>48,'rot'=>10],
                    ['w'=>32,'h'=>20,'left'=>-14,'bot'=>38,'rot'=>-55],
                    ['w'=>28,'h'=>18,'left'=>8,'bot'=>30,'rot'=>25],
                    ['w'=>34,'h'=>22,'left'=>-18,'bot'=>20,'rot'=>-35],
                ];
                ?>
                <div class="nt-scene__leaf-group" style="height:80px;position:relative;">
                    <?php foreach ($corner_leaves as $cl) : ?>
                    <div class="nt-scene__leaf-big" style="width:<?=$cl['w']?>px;height:<?=$cl['h']?>px;left:<?=$cl['left']?>px;bottom:<?=$cl['bot']?>px;transform:rotate(<?=$cl['rot']?>deg);"></div>
                    <?php endforeach; ?>
                </div>
                <div class="nt-scene__stem-corner" style="height:60px;"></div>
                <div class="nt-scene__pot-corner"></div>
            </div>

            <!-- consulting table -->
            <div class="nt-scene__table">
                <div class="nt-scene__table-top"></div>
                <div class="nt-scene__table-body">
                    <div class="nt-scene__table-leg-l"></div>
                    <div class="nt-scene__table-leg-r"></div>
                </div>
                <!-- food items on table -->
                <?php foreach ( $food_items as $fi ) :
                    $offset = $fi['x'] - 8; // relative to table left
                    if ( $offset < 0 || $offset > 90 ) continue;
                ?>
                <div style="position:absolute;top:-28px;left:<?= $offset ?>%;">
                    <?php if ( $fi['type'] === 'bowl' ) : ?>
                    <div style="width:24px;height:14px;background:radial-gradient(ellipse at 50% 30%,<?=$fi['fill']?> 0%,<?=$fi['color']?> 100%);border-radius:50% 50% 45% 45%;"></div>
                    <div style="width:26px;height:6px;background:<?=$fi['color']?>;border-radius:0 0 50% 50%;margin-top:-2px;"></div>
                    <?php elseif ( $fi['type'] === 'jar' ) : ?>
                    <div style="width:18px;height:22px;background:linear-gradient(180deg,<?=$fi['color']?> 0%,<?=$fi['fill']?> 100%);border-radius:2px;border:2px solid rgba(255,255,255,.3);">
                        <div style="width:22px;height:5px;background:<?=$fi['color']?>;border-radius:2px 2px 0 0;margin:-2px -2px 0;"></div>
                    </div>
                    <?php elseif ( $fi['type'] === 'avocado' ) : ?>
                    <div style="width:18px;height:26px;background:radial-gradient(ellipse at 50% 40%,#3A6030 0%,<?=$fi['color']?> 100%);border-radius:50% 50% 40% 40%;position:relative;">
                        <div style="position:absolute;top:30%;left:25%;width:50%;height:40%;background:#C89840;border-radius:50%;"></div>
                    </div>
                    <?php else : ?>
                    <div style="width:20px;height:20px;background:radial-gradient(ellipse at 40% 35%,#FFFF80 0%,<?=$fi['color']?> 60%,<?=$fi['fill']?> 100%);border-radius:50%;"></div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- nutritionist figure -->
            <div class="nt-scene__nutritionist">
                <div class="nt-nutritionist-fig">
                    <div class="nt-nutritionist-fig__head">
                        <div class="nt-nutritionist-fig__hair"></div>
                    </div>
                    <div class="nt-nutritionist-fig__neck"></div>
                    <div style="position:relative;">
                        <div class="nt-nutritionist-fig__body">
                            <div class="nt-nutritionist-fig__arm-l"></div>
                            <div class="nt-nutritionist-fig__arm-r">
                                <div class="nt-nutritionist-fig__clipboard"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- bookshelf -->
            <div class="nt-scene__shelf">
                <div class="nt-scene__shelf-board" style="position:relative;">
                    <div class="nt-scene__shelf-bracket"></div>
                    <div class="nt-scene__shelf-bracket nt-scene__shelf-bracket--l"></div>
                    <div class="nt-scene__books">
                        <?php foreach ( $books as $b ) : ?>
                        <div style="width:<?=$b['w']?>px;height:<?=$b['h']?>px;background:<?=$b['color']?>;border-radius:0 1px 1px 0;flex-shrink:0;transform:rotate(<?=$b['tilt']?>deg);position:relative;transform-origin:bottom center;">
                            <div style="position:absolute;top:4px;left:2px;right:2px;height:1px;background:rgba(255,255,255,.2);box-shadow:0 6px 0 rgba(255,255,255,.15),0 12px 0 rgba(255,255,255,.1);"></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- floating food icons -->
            <?php foreach ( $floaters as $fl ) : ?>
            <div class="nt-floater" style="left:<?=$fl['x']?>%;top:<?=$fl['y']?>%;font-size:<?=$fl['sz']?>px;opacity:<?=$fl['op']/100?>;animation-delay:<?=$fl['delay']?>s;animation-duration:<?=$fl['dur']?>s;">
                <?= $fl['icon'] ?>
            </div>
            <?php endforeach; ?>

        </div><!-- /.nt-scene -->

        <div class="nt-container">
            <div class="nt-hero__content">
                <p class="nt-hero__eyebrow">🌿 Personalised Nutrition Science</p>
                <h1 class="nt-hero__title">
                    Nourish Your Body,<br>
                    <em>Transform Your Health</em>
                </h1>
                <p class="nt-hero__sub">Evidence-based nutrition coaching tailored to your biology, lifestyle, and goals. No fads, no one-size-fits-all plans — just science-led, compassionate guidance that creates lasting change.</p>
                <div class="nt-hero__ctas">
                    <a href="#booking" class="nt-btn nt-btn--primary">Book a Discovery Call</a>
                    <a href="#programs" class="nt-btn nt-btn--ghost">Explore Programmes</a>
                </div>
                <div class="nt-hero__trust">
                    <span class="nt-hero__trust-item"><span>✓</span>Registered Nutritionist (ANutr)</span>
                    <span class="nt-hero__trust-item"><span>✓</span>BANT Member</span>
                    <span class="nt-hero__trust-item"><span>✓</span>CNHC Registered</span>
                </div>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ TRUST BAR ═════════════════════════════ -->
    <div class="nt-trust">
        <div class="nt-container">
            <div class="nt-trust__inner">
                <?php
                $trust_items = [
                    [ 'icon' => '🎓', 'label' => 'MSc Nutritional Medicine',   'sub' => 'University of Surrey' ],
                    [ 'icon' => '🏅', 'label' => 'BANT & CNHC Registered',     'sub' => 'Professional standards upheld' ],
                    [ 'icon' => '📋', 'label' => 'Personalised Plans',          'sub' => 'No generic protocols' ],
                    [ 'icon' => '🔬', 'label' => 'Functional Testing',          'sub' => 'Lab-informed nutrition' ],
                    [ 'icon' => '💬', 'label' => 'Ongoing Support',             'sub' => 'Between sessions access' ],
                ];
                foreach ( $trust_items as $ti ) : ?>
                <div class="nt-trust__item">
                    <span class="nt-trust__icon"><?= $ti['icon'] ?></span>
                    <div>
                        <div class="nt-trust__label"><?= esc_html( $ti['label'] ) ?></div>
                        <div class="nt-trust__sub"><?= esc_html( $ti['sub'] ) ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- ═══════════════════════════════════ PROGRAMS ══════════════════════════════ -->
    <section class="nt-programs" id="programs">
        <div class="nt-container">
            <div class="nt-programs__header">
                <span class="nt-section-label">Specialist Programmes</span>
                <h2 class="nt-section-title">Nutrition for <em>Every Health Goal</em></h2>
                <p class="nt-section-body">Each programme is built around peer-reviewed science and adapted to your individual health markers, preferences, and lifestyle — never copied from a template.</p>
            </div>
            <div class="nt-programs__grid">
                <?php foreach ( $programs as $p ) : ?>
                <div class="nt-program-card">
                    <span class="nt-program-card__icon"><?= $p['icon'] ?></span>
                    <h3 class="nt-program-card__title"><?= esc_html( $p['title'] ) ?></h3>
                    <p class="nt-program-card__desc"><?= esc_html( $p['desc'] ) ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ COUNTERS ═════════════════════════════ -->
    <section class="nt-counters" aria-label="Practice statistics">
        <div class="nt-container">
            <div class="nt-counters__grid">
                <?php foreach ( $counters as $c ) : ?>
                <div>
                    <div class="nt-counter__value"
                         data-target="<?= $c['value'] ?>"
                         <?= $c['float'] ? 'data-float="1"' : '' ?>>
                        <span>0</span><?= esc_html( $c['suffix'] ) ?>
                    </div>
                    <div class="nt-counter__label"><?= esc_html( $c['label'] ) ?></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ PROCESS ══════════════════════════════ -->
    <section class="nt-process">
        <div class="nt-container">
            <div class="nt-process__header">
                <span class="nt-section-label">How It Works</span>
                <h2 class="nt-section-title">Your Journey to <em>Better Health</em></h2>
            </div>
            <div class="nt-process__grid">
                <?php foreach ( $process as $step ) : ?>
                <div class="nt-process-card">
                    <div class="nt-process-card__step" data-step="<?= esc_attr( $step['step'] ) ?>"><?= esc_html( $step['step'] ) ?></div>
                    <h3 class="nt-process-card__title"><?= esc_html( $step['title'] ) ?></h3>
                    <p class="nt-process-card__desc"><?= esc_html( $step['desc'] ) ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ ABOUT ════════════════════════════════ -->
    <section class="nt-about" id="about">
        <div class="nt-container">
            <div class="nt-about__inner">
                <div aria-hidden="true">
                    <!-- CSS nutrition consulting desk scene -->
                    <div class="nt-desk-scene">
                        <div class="nt-desk-scene__window"></div>
                        <div class="nt-desk-scene__frame"></div>
                        <div class="nt-desk-scene__frame nt-desk-scene__frame-2"></div>
                        <div class="nt-desk-scene__desk" style="left:8%;width:55%;">
                            <div class="nt-desk-scene__laptop">
                                <div class="nt-desk-scene__screen"></div>
                                <div class="nt-desk-scene__hinge"></div>
                                <div class="nt-desk-scene__keyboard"></div>
                            </div>
                            <div class="nt-desk-scene__bowl"></div>
                            <div class="nt-desk-scene__desk-top"></div>
                            <div class="nt-desk-scene__desk-body">
                                <div class="nt-desk-scene__desk-leg" style="left:8%;"></div>
                                <div class="nt-desk-scene__desk-leg" style="right:8%;"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="nt-about__text">
                    <span class="nt-section-label">Meet Olivia</span>
                    <h2 class="nt-section-title">Registered Nutritionist &amp; <em>Health Coach</em></h2>
                    <p class="nt-section-body">With an MSc in Nutritional Medicine and 14 years of clinical practice, Olivia Hart combines the precision of functional medicine with genuine warmth and accountability. She believes food is powerful medicine — and that sustainable change comes from understanding, not willpower.</p>
                    <div style="margin-top:28px;display:flex;flex-direction:column;gap:0;">
                        <?php foreach ( $creds as $cr ) : ?>
                        <div class="nt-about__cred">
                            <div class="nt-about__cred-badge"><?= esc_html( $cr['badge'] ) ?></div>
                            <div class="nt-about__cred-text">
                                <strong><?= esc_html( $cr['name'] ) ?></strong>
                                <span><?= esc_html( $cr['body'] ) ?></span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div style="margin-top:32px;">
                        <a href="#booking" class="nt-btn nt-btn--primary">Book a Discovery Call</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ PACKAGES ═════════════════════════════ -->
    <section class="nt-packages" id="packages">
        <div class="nt-container">
            <div class="nt-packages__header">
                <span class="nt-section-label">Investment</span>
                <h2 class="nt-section-title">Choose Your <em>Level of Support</em></h2>
                <p class="nt-section-body">Whether you need a focused single session or immersive programme support, there is an option to match your needs and budget.</p>
            </div>
            <div class="nt-packages__grid">
                <?php foreach ( $packages as $pkg ) : ?>
                <div class="nt-package-card <?= $pkg['featured'] ? 'nt-package-card--featured' : '' ?>">
                    <?php if ( $pkg['featured'] ) : ?>
                    <div class="nt-package-card__badge">Most Popular</div>
                    <?php endif; ?>
                    <div class="nt-package-card__name"><?= esc_html( $pkg['name'] ) ?></div>
                    <div class="nt-package-card__price-row">
                        <div class="nt-package-card__price"><?= esc_html( $pkg['price'] ) ?></div>
                        <div class="nt-package-card__period"><?= esc_html( $pkg['period'] ) ?></div>
                    </div>
                    <ul class="nt-package-card__list">
                        <?php foreach ( $pkg['items'] as $item ) : ?>
                        <li class="nt-package-card__item"><?= esc_html( $item ) ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <a href="#booking" class="nt-btn <?= $pkg['featured'] ? 'nt-btn--ghost' : 'nt-btn--outline' ?>" style="width:100%;justify-content:center;">
                        Get Started
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ TESTIMONIALS ═════════════════════════ -->
    <section class="nt-testimonials">
        <div class="nt-container">
            <div class="nt-testimonials__header">
                <span class="nt-section-label">Client Stories</span>
                <h2 class="nt-section-title">Real People, <em>Real Results</em></h2>
            </div>
            <div class="nt-testimonials__grid">
                <?php foreach ( $testimonials as $t ) :
                    $init = strtoupper( $t['name'][0] );
                ?>
                <div class="nt-testimonial">
                    <div class="nt-testimonial__stars">★★★★★</div>
                    <p class="nt-testimonial__text">"<?= esc_html( $t['text'] ) ?>"</p>
                    <div class="nt-testimonial__author">
                        <div class="nt-testimonial__avatar"><?= $init ?></div>
                        <div>
                            <div class="nt-testimonial__name"><?= esc_html( $t['name'] ) ?></div>
                            <div class="nt-testimonial__goal"><?= esc_html( $t['goal'] ) ?></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ BOOKING ══════════════════════════════ -->
    <section class="nt-booking" id="booking">
        <div class="nt-container">
            <div class="nt-booking__inner">
                <div class="nt-booking__info">
                    <span class="nt-section-label">Get in Touch</span>
                    <h2 class="nt-section-title">Start Your <em>Health Journey</em></h2>
                    <p class="nt-section-body">Begin with a complimentary 20-minute discovery call. There is no obligation — just an honest conversation about where you are now and where you want to be.</p>
                    <div class="nt-booking__faq">
                        <?php
                        $faqs = [
                            [ 'q' => 'Do consultations take place in person or online?', 'a' => 'Both options are available. In-person sessions are held at our central London clinic; online sessions via secure video call.' ],
                            [ 'q' => 'Do I need a GP referral?',                         'a' => 'No referral is needed. You can book directly. If you have complex medical needs, we may coordinate with your GP.' ],
                            [ 'q' => 'How quickly will I see results?',                  'a' => 'Many clients notice improved energy and digestion within 2–3 weeks. Body composition goals typically show measurable changes at 8–12 weeks.' ],
                        ];
                        foreach ( $faqs as $faq ) : ?>
                        <div class="nt-booking__faq-item">
                            <div class="nt-booking__faq-q"><?= esc_html( $faq['q'] ) ?></div>
                            <div class="nt-booking__faq-a"><?= esc_html( $faq['a'] ) ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div>
                    <form class="nt-form" method="post" action="">
                        <?php wp_nonce_field( 'tf_nt_booking', 'tf_nt_nonce' ); ?>
                        <h3 class="nt-form__title">Book a Discovery Call</h3>
                        <div class="nt-form__row">
                            <div class="nt-form__group">
                                <label class="nt-form__label" for="nt-name">Your Name *</label>
                                <input class="nt-form__input" type="text" id="nt-name" name="name" placeholder="Jane Smith" required>
                            </div>
                            <div class="nt-form__group">
                                <label class="nt-form__label" for="nt-email">Email Address *</label>
                                <input class="nt-form__input" type="email" id="nt-email" name="email" placeholder="jane@example.com" required>
                            </div>
                        </div>
                        <div class="nt-form__row">
                            <div class="nt-form__group">
                                <label class="nt-form__label" for="nt-phone">Phone Number</label>
                                <input class="nt-form__input" type="tel" id="nt-phone" name="phone" placeholder="020 7946 0000">
                            </div>
                            <div class="nt-form__group">
                                <label class="nt-form__label" for="nt-goal">Primary Health Goal *</label>
                                <select class="nt-form__select" id="nt-goal" name="goal">
                                    <option value="">Select goal…</option>
                                    <option value="gut">Gut Health</option>
                                    <option value="energy">Energy & Performance</option>
                                    <option value="weight">Weight Management</option>
                                    <option value="hormonal">Hormonal Balance</option>
                                    <option value="sports">Sports Nutrition</option>
                                    <option value="heart">Heart Health</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                        </div>
                        <div class="nt-form__group nt-form__group--full">
                            <label class="nt-form__label" for="nt-message">Tell Me About Your Health Goals</label>
                            <textarea class="nt-form__textarea" id="nt-message" name="message" placeholder="What health challenges are you currently facing? What do you hope to achieve?"></textarea>
                        </div>
                        <div class="nt-form__group nt-form__group--full">
                            <label class="nt-form__label" for="nt-format">Preferred Format</label>
                            <select class="nt-form__select" id="nt-format" name="format">
                                <option value="online">Online (Video Call)</option>
                                <option value="in-person">In-Person (Central London)</option>
                            </select>
                        </div>
                        <button type="submit" class="nt-form__submit">Book Free Discovery Call →</button>
                        <p class="nt-form__note">Complimentary 20-minute call · No obligation · Responds within 24 hours</p>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ FOOTER CTA ═══════════════════════════ -->
    <section class="nt-footer-cta">
        <div class="nt-container">
            <h2 class="nt-footer-cta__title">Ready to Transform Your Health?</h2>
            <p class="nt-footer-cta__sub">Olivia Hart Nutrition · Harley Street, London · hello@oliviahartnutrition.co.uk</p>
            <div class="nt-footer-cta__actions">
                <a href="#booking" class="nt-btn nt-btn--primary">Book Discovery Call</a>
                <a href="#programs" class="nt-btn nt-btn--ghost">View Programmes</a>
            </div>
        </div>
    </section>

</div><!-- /.nt-wrap -->

<script>
/* ── IntersectionObserver animated counters ───────────────────────── */
(function () {
    'use strict';
    var easeOut = function (t) { return 1 - Math.pow(1 - t, 3); };
    var els = document.querySelectorAll('.nt-counter__value[data-target]');
    if (!els.length) return;
    var obs = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (!entry.isIntersecting) return;
            obs.unobserve(entry.target);
            var el      = entry.target;
            var target  = parseFloat(el.dataset.target);
            var isFloat = !!el.dataset.float;
            var span    = el.querySelector('span');
            if (!span || isNaN(target)) return;
            var dur = 1800, start = null;
            function tick(ts) {
                if (!start) start = ts;
                var p = Math.min((ts - start) / dur, 1);
                var v = easeOut(p) * target;
                span.textContent = isFloat ? v.toFixed(1) : Math.round(v).toLocaleString();
                if (p < 1) requestAnimationFrame(tick);
                else span.textContent = isFloat ? target.toFixed(1) : target.toLocaleString();
            }
            requestAnimationFrame(tick);
        });
    }, { threshold: 0.4 });
    els.forEach(function (el) { obs.observe(el); });
})();
</script>

<?php get_footer(); ?>
