<?php
/**
 * Template Name: Optician & Eyecare Clinic
 *
 * Premium homepage for an independent optician / eyecare practice.
 * Namespace : --opt-*
 * Fonts     : DM Sans + Merriweather
 * Palette   : deep #0c1a2e, cobalt #1a3a6e, teal #0e8c8c, sky #e0f4f4, white #ffffff
 *
 * @package ThemeFlex
 */

get_header();

/* ── Deterministic randomness ────────────────────────────── */
srand( crc32( get_the_permalink() ) );

/* ── Practice data ───────────────────────────────────────── */
$practice_name  = 'Vista Eyecare';
$tagline        = 'Clearer Vision. Better Life.';
$phone          = '0161 834 7720';
$email          = 'hello@vistaeyecare.co.uk';
$address        = '42 Deansgate, Manchester M3 2EG';

$stats = [
    [ 'value' => '18000', 'label' => 'Patients Seen',       'suffix' => '+' ],
    [ 'value' => '24',    'label' => 'Years in Practice',   'suffix' => '' ],
    [ 'value' => '4.9',   'label' => 'Google Rating',       'suffix' => '★' ],
    [ 'value' => '98',    'label' => 'Would Recommend',     'suffix' => '%' ],
];

$services = [
    [
        'title' => 'Comprehensive Eye Tests',
        'desc'  => 'A thorough 30-minute examination using the latest digital diagnostic equipment to assess vision, eye health and detect early signs of conditions such as glaucoma, cataracts and macular degeneration.',
        'price' => '£35',
        'icon'  => 'eye',
    ],
    [
        'title' => 'Contact Lens Fitting',
        'desc'  => 'Expert assessment and fitting for daily, monthly, toric and multifocal lenses. Includes a free trial pair and follow-up appointment.',
        'price' => '£45',
        'icon'  => 'lens',
    ],
    [
        'title' => 'Children\'s Eye Tests',
        'desc'  => 'Specialist paediatric examinations for children of all ages. Early detection of squint, lazy eye and colour vision deficiencies. NHS funded for under-16s.',
        'price' => 'Free (NHS)',
        'icon'  => 'child',
    ],
    [
        'title' => 'Diabetic Eye Screening',
        'desc'  => 'Retinal photography and OCT scanning to monitor diabetic retinopathy and other systemic conditions that manifest in the eye.',
        'price' => '£55',
        'icon'  => 'retina',
    ],
    [
        'title' => 'Dry Eye Clinic',
        'desc'  => 'Advanced meibomian gland assessment and treatment including iLux thermal pulsation therapy for chronic dry eye syndrome.',
        'price' => '£60',
        'icon'  => 'drop',
    ],
    [
        'title' => 'Myopia Management',
        'desc'  => 'Specialist programme for children showing progression of short-sightedness. MiSight contact lenses and orthokeratology available.',
        'price' => 'From £65/mo',
        'icon'  => 'chart',
    ],
];

$frames = [
    [ 'brand' => 'Ray-Ban',         'style' => 'Classic Aviators',    'from' => 149, 'color' => '#1a1a2e' ],
    [ 'brand' => 'Tom Ford',        'style' => 'Luxury Acetate',      'from' => 295, 'color' => '#2e1a0c' ],
    [ 'brand' => 'Silhouette',      'style' => 'Rimless Titanium',    'from' => 380, 'color' => '#1a2e2e' ],
    [ 'brand' => 'Oakley',          'style' => 'Sport & Wrap',        'from' => 165, 'color' => '#0c2e1a' ],
    [ 'brand' => 'Lindberg',        'style' => 'Danish Minimalist',   'from' => 420, 'color' => '#1a1a2e' ],
    [ 'brand' => 'Own Collection',  'style' => 'Exclusive Frames',    'from' => 89,  'color' => '#2e0c1a' ],
];

$team = [
    [ 'name' => 'Dr. Aisha Patel',   'role' => 'Lead Optometrist',         'qual' => 'MCOptom, DipTp(CL)',     'spec' => 'Contact Lenses & Myopia' ],
    [ 'name' => 'James Thornton',    'role' => 'Dispensing Optician',      'qual' => 'FBDO, SMC(Tech)',        'spec' => 'Frames & Dispensing' ],
    [ 'name' => 'Mei-Ling Chen',     'role' => 'Specialist Optometrist',   'qual' => 'MCOptom, PGCertOphth',  'spec' => 'Dry Eye & Glaucoma' ],
    [ 'name' => 'Ryan O\'Sullivan',  'role' => 'Pre-reg Optometrist',      'qual' => 'MOptom, HCPC Reg.',     'spec' => 'Paediatric Vision' ],
];

$process = [
    [ 'step' => '01', 'title' => 'Book Online',           'desc' => 'Choose your appointment type and preferred time slot. Same-week appointments usually available.' ],
    [ 'step' => '02', 'title' => 'Pre-test Checks',       'desc' => 'Digital retinal photography and automated measurements before you see the optometrist.' ],
    [ 'step' => '03', 'title' => 'Eye Examination',       'desc' => 'A thorough clinical examination by your optometrist discussing your vision and eye health.' ],
    [ 'step' => '04', 'title' => 'Frame & Lens Selection','desc' => 'Browse our collections with expert dispensing guidance to find the perfect eyewear.' ],
    [ 'step' => '05', 'title' => 'Collection & Aftercare','desc' => 'Collect your glasses perfectly adjusted. All prescriptions include free aftercare visits.' ],
];

$testimonials = [
    [
        'name'  => 'Sarah J.',
        'quote' => 'I\'ve been coming to Vista for eight years. Dr. Patel is exceptional — thorough, knowledgeable and genuinely caring. The new OCT scanner found an early sign of macular change that no one else had spotted.',
        'stars' => 5,
    ],
    [
        'name'  => 'David M.',
        'quote' => 'After years of struggling with dry eyes, the iLux treatment here changed my life. Mei-Ling explained everything so clearly and the results after just one session were remarkable.',
        'stars' => 5,
    ],
    [
        'name'  => 'Priya K.',
        'quote' => 'James helped me choose frames that I absolutely love and that work perfectly with my strong prescription. The whole team are wonderful — professional and so friendly.',
        'stars' => 5,
    ],
];

$faqs = [
    [ 'q' => 'How often should I have an eye test?',
      'a' => 'Adults under 60 should have an eye test every two years. Over 60 or if you have risk factors (family history of glaucoma, diabetes, high myopia), we recommend annually. Children should be tested at least every year.' ],
    [ 'q' => 'Are eye tests free on the NHS?',
      'a' => 'NHS funded eye tests are available for children under 16, those in full-time education under 19, adults over 60, those with certain medical conditions, and those at risk of glaucoma. Our team can advise whether you qualify.' ],
    [ 'q' => 'What is OCT scanning and do I need it?',
      'a' => 'Optical Coherence Tomography (OCT) is a non-invasive scan that produces detailed cross-sectional images of the retina. It can detect conditions up to four years earlier than traditional methods. We recommend it for all patients, particularly those over 40.' ],
    [ 'q' => 'Can you match my current prescription?',
      'a' => 'Absolutely. Bring your current glasses or a copy of your prescription and our dispensing opticians can check and match it. We recommend a full eye test if your prescription is over two years old.' ],
    [ 'q' => 'How long does it take to get glasses?',
      'a' => 'Standard prescriptions are usually ready in 7–10 days. Complex high-prescription lenses or specialist coatings may take up to three weeks. We offer an express service for most single-vision lenses.' ],
];

/* ── PHP-generated hero decorations ─────────────────────── */
$n_lens_rings = 7;
$n_sparkles   = 20;
$n_bubbles    = 15;
?>
<!– page-optician –>
<style>
/* ═══════════════════════════════════════════════════════════
   OPTICIAN — CSS CUSTOM PROPERTIES
═══════════════════════════════════════════════════════════ */
:root {
    --opt-deep:      #0c1a2e;
    --opt-cobalt:    #1a3a6e;
    --opt-cobalt-lt: #2a5aaa;
    --opt-teal:      #0e8c8c;
    --opt-teal-lt:   #12b8b8;
    --opt-sky:       #e0f4f4;
    --opt-cream:     #f8fcfc;
    --opt-white:     #ffffff;
    --opt-text:      #1e3a5a;
    --opt-muted:     #5a7a9a;
    --opt-border:    #c8e4e8;
    --opt-shadow:    0 4px 24px rgba(12,26,46,.12);
    --opt-shadow-lg: 0 12px 48px rgba(12,26,46,.2);
    --opt-r:         8px;
    --opt-r-lg:      16px;
    --opt-r-xl:      24px;
    --opt-trans:     all .3s ease;
    --opt-font-head: 'Merriweather', Georgia, serif;
    --opt-font-body: 'DM Sans', system-ui, sans-serif;
}

/* ── Reset / Base ──────────────────────────────────────── */
.opt-page *, .opt-page *::before, .opt-page *::after { box-sizing: border-box; margin: 0; padding: 0; }
.opt-page { font-family: var(--opt-font-body); color: var(--opt-text); background: var(--opt-cream); line-height: 1.65; }
.opt-wrap { max-width: 1160px; margin: 0 auto; padding: 0 24px; }
.opt-section { padding: 88px 0; }
.opt-section-alt { background: var(--opt-white); }
.opt-section-dark { background: var(--opt-deep); color: var(--opt-white); }
.opt-section-teal { background: var(--opt-teal); color: var(--opt-white); }
.opt-kicker { display: inline-block; font-size: .75rem; font-weight: 700; letter-spacing: .18em; text-transform: uppercase; color: var(--opt-teal); margin-bottom: 12px; }
.opt-section-dark .opt-kicker, .opt-section-teal .opt-kicker { color: rgba(255,255,255,.75); }
.opt-h2 { font-family: var(--opt-font-head); font-size: clamp(1.7rem, 3.8vw, 2.6rem); font-weight: 700; line-height: 1.25; color: var(--opt-deep); margin-bottom: 16px; }
.opt-section-dark .opt-h2, .opt-section-teal .opt-h2 { color: var(--opt-white); }
.opt-h2-line { width: 48px; height: 3px; background: var(--opt-teal); margin: 0 0 28px; }
.opt-lead { font-size: 1.05rem; color: var(--opt-muted); max-width: 600px; line-height: 1.7; }
.opt-section-dark .opt-lead, .opt-section-teal .opt-lead { color: rgba(255,255,255,.75); }
.opt-center { text-align: center; }
.opt-center .opt-h2-line { margin: 0 auto 28px; }
.opt-center .opt-lead { margin: 0 auto; }
.opt-btn { display: inline-flex; align-items: center; gap: 8px; padding: 14px 32px; border-radius: var(--opt-r); font-family: var(--opt-font-body); font-size: .95rem; font-weight: 700; text-decoration: none; cursor: pointer; border: none; transition: var(--opt-trans); }
.opt-btn-teal { background: var(--opt-teal); color: var(--opt-white); }
.opt-btn-teal:hover { background: var(--opt-teal-lt); transform: translateY(-2px); box-shadow: 0 6px 20px rgba(14,140,140,.35); }
.opt-btn-outline { background: transparent; border: 2px solid var(--opt-teal); color: var(--opt-teal); }
.opt-btn-outline:hover { background: var(--opt-teal); color: var(--opt-white); }
.opt-btn-white { background: var(--opt-white); color: var(--opt-teal); }
.opt-btn-white:hover { background: var(--opt-sky); transform: translateY(-2px); }
.opt-btn-cobalt { background: var(--opt-cobalt); color: var(--opt-white); }
.opt-btn-cobalt:hover { background: var(--opt-cobalt-lt); transform: translateY(-2px); }

@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;700&family=Merriweather:ital,wght@0,400;0,700;1,400&display=swap');

/* ═══════════════════════════════════════════════════════════
   NAV
═══════════════════════════════════════════════════════════ */
.opt-nav { position: sticky; top: 0; z-index: 999; background: var(--opt-white); border-bottom: 2px solid var(--opt-teal); box-shadow: 0 2px 16px rgba(12,26,46,.08); }
.opt-nav-inner { display: flex; align-items: center; justify-content: space-between; height: 68px; gap: 24px; }
.opt-nav-logo { display: flex; align-items: center; gap: 12px; text-decoration: none; }
.opt-nav-logo-icon { width: 38px; height: 38px; }
.opt-nav-logo-name { font-family: var(--opt-font-head); font-size: 1.2rem; font-weight: 700; color: var(--opt-deep); }
.opt-nav-logo-sub { font-size: .65rem; letter-spacing: .14em; text-transform: uppercase; color: var(--opt-teal); display: block; }
.opt-nav-links { display: flex; gap: 28px; list-style: none; }
.opt-nav-links a { font-size: .88rem; font-weight: 500; color: var(--opt-text); text-decoration: none; transition: color .2s; }
.opt-nav-links a:hover { color: var(--opt-teal); }
.opt-nav-cta { display: flex; gap: 12px; align-items: center; }
.opt-nav-phone { color: var(--opt-cobalt); font-size: .88rem; font-weight: 700; text-decoration: none; }
.opt-nav-phone:hover { color: var(--opt-teal); }
.opt-nav-nhs { display: inline-flex; align-items: center; gap: 6px; background: #003087; color: #fff; font-size: .72rem; font-weight: 700; padding: 4px 10px; border-radius: 4px; letter-spacing: .04em; }

/* ═══════════════════════════════════════════════════════════
   HERO — CSS OPTICS / TESTING ROOM SCENE
═══════════════════════════════════════════════════════════ */
.opt-hero { position: relative; min-height: 640px; background: linear-gradient(135deg, var(--opt-deep) 0%, #0a2040 50%, #0c2e4a 100%); display: flex; align-items: center; overflow: hidden; }
.opt-hero-scene { position: absolute; inset: 0; overflow: hidden; }

/* Eye chart on wall */
.opt-eye-chart { position: absolute; right: 10%; top: 8%; width: 160px; }
.opt-chart-mount { width: 100%; padding: 12px; background: #f8f4ec; border: 3px solid #e0d8c8; border-radius: 2px; box-shadow: 4px 4px 16px rgba(0,0,0,.5); }
.opt-chart-row { display: flex; justify-content: center; gap: 4px; margin-bottom: 6px; font-family: 'Courier New', monospace; font-weight: 700; color: #1a1a1a; }

/* Slit lamp / phoropter */
.opt-phoropter { position: absolute; right: 34%; top: 22%; }
.opt-phor-arm { width: 8px; height: 90px; background: linear-gradient(90deg, #5a6a7a 0%, #8a9aaa 50%, #5a6a7a 100%); border-radius: 4px; margin: 0 auto; }
.opt-phor-head { width: 80px; height: 60px; background: linear-gradient(160deg, #2a3a4a 0%, #1a2a3a 100%); border-radius: 8px; position: relative; margin-top: -4px; }
.opt-phor-lens-l { position: absolute; left: 8px; top: 8px; width: 28px; height: 28px; border-radius: 50%; background: radial-gradient(circle at 35% 30%, rgba(100,180,220,.4) 0%, rgba(40,100,160,.6) 40%, rgba(20,60,100,.9) 100%); border: 2px solid #4a6a8a; box-shadow: 0 0 8px rgba(100,200,255,.3); }
.opt-phor-lens-r { position: absolute; right: 8px; top: 8px; width: 28px; height: 28px; border-radius: 50%; background: radial-gradient(circle at 35% 30%, rgba(100,180,220,.4) 0%, rgba(40,100,160,.6) 40%, rgba(20,60,100,.9) 100%); border: 2px solid #4a6a8a; box-shadow: 0 0 8px rgba(100,200,255,.3); }
.opt-phor-knob { position: absolute; bottom: 4px; left: 50%; transform: translateX(-50%); width: 16px; height: 16px; background: #4a6a8a; border-radius: 50%; }
.opt-phor-base { width: 120px; height: 10px; background: linear-gradient(90deg, #2a3a4a, #3a4a5a, #2a3a4a); border-radius: 5px; margin: 0 auto; }

/* Spectacle frames display */
.opt-frames-display { position: absolute; right: 12%; bottom: 18%; display: flex; gap: 8px; }
.opt-frame-stand { text-align: center; }
.opt-frame-css { width: 56px; height: 24px; position: relative; margin: 0 auto 4px; }
.opt-frame-css-left { position: absolute; left: 0; top: 0; width: 22px; height: 22px; border-radius: 50%; border: 3px solid var(--opt-frame-col, #c8902a); }
.opt-frame-css-right { position: absolute; right: 0; top: 0; width: 22px; height: 22px; border-radius: 50%; border: 3px solid var(--opt-frame-col, #c8902a); }
.opt-frame-css-bridge { position: absolute; top: 8px; left: 21px; right: 21px; height: 3px; background: var(--opt-frame-col, #c8902a); border-radius: 2px; }
.opt-frame-css-ltem { position: absolute; top: 8px; left: -14px; width: 14px; height: 3px; background: var(--opt-frame-col, #c8902a); border-radius: 2px; }
.opt-frame-css-rtem { position: absolute; top: 8px; right: -14px; width: 14px; height: 3px; background: var(--opt-frame-col, #c8902a); border-radius: 2px; }
.opt-frame-price { font-size: .55rem; color: rgba(255,255,255,.55); }

/* Teal beam of light from testing equipment */
.opt-beam { position: absolute; top: 40%; left: 20%; width: 400px; height: 2px; background: linear-gradient(90deg, transparent 0%, rgba(14,140,140,.5) 30%, rgba(14,200,200,.8) 60%, transparent 100%); box-shadow: 0 0 12px rgba(14,200,200,.4); animation: opt-beam-pulse 3s ease-in-out infinite; }
@keyframes opt-beam-pulse { 0%,100% { opacity: .5; } 50% { opacity: 1; } }

/* Large CSS eye (iris) centrepiece */
.opt-eye-orb { position: absolute; left: 52%; top: 10%; width: 200px; height: 130px; }
.opt-eye-white { width: 200px; height: 130px; background: rgba(248,252,252,.08); border-radius: 50% 50% 50% 50% / 60% 60% 40% 40%; border: 1px solid rgba(255,255,255,.1); }
.opt-iris { position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); width: 90px; height: 90px; border-radius: 50%; background: radial-gradient(circle at 38% 35%, rgba(30,140,160,.9) 0%, rgba(14,80,120,.95) 35%, rgba(10,40,80,1) 65%, rgba(5,15,30,1) 100%); box-shadow: 0 0 20px rgba(14,140,180,.5), inset 0 0 30px rgba(0,0,0,.5); animation: opt-iris-pulse 4s ease-in-out infinite; }
@keyframes opt-iris-pulse { 0%,100%{transform:translate(-50%,-50%) scale(1);} 50%{transform:translate(-50%,-50%) scale(1.04);} }
.opt-pupil { position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); width: 32px; height: 32px; border-radius: 50%; background: radial-gradient(circle at 35% 30%, rgba(40,40,60,.5) 0%, rgba(5,5,10,1) 100%); }
.opt-iris-ring { position: absolute; top: 50%; left: 50%; border-radius: 50%; border: 1px solid rgba(14,140,160,.35); }
.opt-iris-ring-1 { width: 108px; height: 108px; transform: translate(-50%,-50%); }
.opt-iris-ring-2 { width: 128px; height: 128px; transform: translate(-50%,-50%); }
.opt-iris-ring-3 { width: 150px; height: 150px; transform: translate(-50%,-50%); }
.opt-eye-glint { position: absolute; top: 26px; left: 36px; width: 16px; height: 10px; border-radius: 50%; background: rgba(255,255,255,.55); filter: blur(2px); }
.opt-eye-lash { position: absolute; background: rgba(14,140,160,.3); border-radius: 50%; }

/* Sparkle particles */
.opt-sparkle { position: absolute; width: 3px; height: 3px; border-radius: 50%; background: rgba(14,200,200,.8); animation: opt-sparkle-twinkle ease-in-out infinite; }
@keyframes opt-sparkle-twinkle { 0%,100%{opacity:0;transform:scale(.5);} 50%{opacity:1;transform:scale(1.5);} }

/* Vision chart projection beam */
.opt-projection { position: absolute; top: 8%; left: 10%; width: 80px; height: 60px; background: linear-gradient(135deg, rgba(14,140,140,.15) 0%, transparent 80%); border-radius: 4px; border: 1px solid rgba(14,140,140,.2); }
.opt-projection::after { content: 'E'; font-family: 'Courier New', monospace; font-size: 2rem; font-weight: 700; color: rgba(14,200,200,.6); position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); }

/* Room elements */
.opt-room-floor { position: absolute; bottom: 0; left: 0; right: 0; height: 25%; background: linear-gradient(180deg, #0e1e30 0%, #0a1624 100%); }
.opt-room-floor::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 1px; background: rgba(14,140,140,.3); box-shadow: 0 0 8px rgba(14,140,140,.2); }

/* Hero content */
.opt-hero-content { position: relative; z-index: 10; max-width: 520px; padding: 80px 0; }
.opt-hero-nhs { display: inline-flex; align-items: center; gap: 8px; background: rgba(0,48,135,.5); border: 1px solid rgba(0,100,200,.3); border-radius: var(--opt-r); padding: 8px 16px; margin-bottom: 24px; font-size: .8rem; color: #90c0ff; font-weight: 600; }
.opt-hero-h1 { font-family: var(--opt-font-head); font-size: clamp(2rem, 4.5vw, 3.2rem); font-weight: 700; color: var(--opt-white); line-height: 1.2; margin-bottom: 20px; }
.opt-hero-h1 em { font-style: italic; color: var(--opt-teal-lt); }
.opt-hero-desc { font-size: 1.05rem; color: rgba(255,255,255,.75); line-height: 1.75; margin-bottom: 32px; }
.opt-hero-ctas { display: flex; gap: 16px; flex-wrap: wrap; margin-bottom: 40px; }
.opt-hero-trust { display: grid; grid-template-columns: repeat(2,1fr); gap: 12px; }
.opt-trust-pill { display: flex; align-items: center; gap: 8px; background: rgba(255,255,255,.06); border: 1px solid rgba(255,255,255,.1); border-radius: var(--opt-r); padding: 10px 14px; }
.opt-trust-icon { width: 20px; height: 20px; flex-shrink: 0; }
.opt-trust-text { font-size: .8rem; color: rgba(255,255,255,.7); }

/* ═══════════════════════════════════════════════════════════
   STATS BAR
═══════════════════════════════════════════════════════════ */
.opt-stats-bar { background: var(--opt-cobalt); padding: 44px 0; }
.opt-stats-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 0; }
.opt-stat { text-align: center; padding: 8px 16px; border-right: 1px solid rgba(255,255,255,.12); }
.opt-stat:last-child { border-right: none; }
.opt-stat-value { font-family: var(--opt-font-head); font-size: 2.4rem; font-weight: 700; color: var(--opt-white); line-height: 1; }
.opt-stat-suffix { color: var(--opt-teal-lt); font-size: 1.6rem; }
.opt-stat-label { font-size: .78rem; letter-spacing: .1em; text-transform: uppercase; color: rgba(255,255,255,.55); margin-top: 6px; }

/* ═══════════════════════════════════════════════════════════
   SERVICES
═══════════════════════════════════════════════════════════ */
.opt-services-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; margin-top: 48px; }
.opt-service-card { background: var(--opt-white); border: 1px solid var(--opt-border); border-radius: var(--opt-r-lg); padding: 32px 28px; transition: var(--opt-trans); position: relative; overflow: hidden; }
.opt-service-card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px; background: linear-gradient(90deg, var(--opt-teal) 0%, var(--opt-cobalt-lt) 100%); transform: scaleX(0); transform-origin: left; transition: transform .3s ease; }
.opt-service-card:hover::before { transform: scaleX(1); }
.opt-service-card:hover { transform: translateY(-4px); box-shadow: var(--opt-shadow-lg); }
.opt-service-icon { width: 56px; height: 56px; border-radius: 50%; background: var(--opt-sky); display: flex; align-items: center; justify-content: center; margin-bottom: 20px; }
.opt-service-icon svg { width: 28px; height: 28px; fill: var(--opt-teal); }
.opt-service-title { font-family: var(--opt-font-head); font-size: 1.05rem; font-weight: 700; color: var(--opt-deep); margin-bottom: 10px; }
.opt-service-desc { font-size: .88rem; color: var(--opt-muted); line-height: 1.65; margin-bottom: 16px; }
.opt-service-price { display: inline-block; background: var(--opt-sky); color: var(--opt-teal); font-size: .85rem; font-weight: 700; padding: 5px 14px; border-radius: 20px; }

/* ═══════════════════════════════════════════════════════════
   FRAMES GALLERY
═══════════════════════════════════════════════════════════ */
.opt-frames-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; margin-top: 48px; }
.opt-frame-card { background: var(--opt-white); border: 1px solid var(--opt-border); border-radius: var(--opt-r-lg); padding: 32px 24px; text-align: center; transition: var(--opt-trans); }
.opt-frame-card:hover { transform: translateY(-4px); box-shadow: var(--opt-shadow-lg); }
.opt-frame-visual { height: 80px; display: flex; align-items: center; justify-content: center; margin-bottom: 20px; }
/* CSS glasses shapes */
.opt-glasses { position: relative; width: 100px; height: 44px; }
.opt-glass-l, .opt-glass-r { position: absolute; top: 0; width: 40px; height: 40px; border-radius: 50%; border: 4px solid var(--opt-gc, #1a3a6e); }
.opt-glass-l { left: 0; }
.opt-glass-r { right: 0; }
.opt-glass-bridge { position: absolute; top: 16px; left: 39px; width: 22px; height: 4px; background: var(--opt-gc, #1a3a6e); border-radius: 2px; }
.opt-glass-arm-l { position: absolute; top: 16px; left: -18px; width: 18px; height: 4px; background: var(--opt-gc, #1a3a6e); border-radius: 2px; transform-origin: right; transform: rotate(-8deg); }
.opt-glass-arm-r { position: absolute; top: 16px; right: -18px; width: 18px; height: 4px; background: var(--opt-gc, #1a3a6e); border-radius: 2px; transform-origin: left; transform: rotate(8deg); }
/* Rectangle frames */
.opt-glasses-rect .opt-glass-l, .opt-glasses-rect .opt-glass-r { border-radius: 6px; width: 38px; height: 28px; top: 8px; }
/* Cat-eye frames */
.opt-glasses-cat .opt-glass-l { border-radius: 50% 20% 50% 50%; }
.opt-glasses-cat .opt-glass-r { border-radius: 20% 50% 50% 50%; }
/* Round small */
.opt-glasses-round .opt-glass-l, .opt-glasses-round .opt-glass-r { width: 32px; height: 32px; top: 4px; }
.opt-frame-brand { font-family: var(--opt-font-head); font-size: 1.1rem; font-weight: 700; color: var(--opt-deep); margin-bottom: 4px; }
.opt-frame-style { font-size: .85rem; color: var(--opt-muted); margin-bottom: 12px; }
.opt-frame-from { font-size: .8rem; color: var(--opt-cobalt); font-weight: 700; }
.opt-frame-from span { font-size: 1.1rem; }

/* ═══════════════════════════════════════════════════════════
   TEAM
═══════════════════════════════════════════════════════════ */
.opt-team-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 24px; margin-top: 48px; }
.opt-team-card { background: var(--opt-white); border: 1px solid var(--opt-border); border-radius: var(--opt-r-lg); overflow: hidden; transition: var(--opt-trans); text-align: center; }
.opt-team-card:hover { transform: translateY(-4px); box-shadow: var(--opt-shadow-lg); }
.opt-team-avatar { height: 180px; position: relative; display: flex; align-items: flex-end; justify-content: center; padding-bottom: 0; overflow: hidden; }
.opt-optom-fig { position: relative; width: 80px; z-index: 1; }
.opt-optom-head { width: 42px; height: 42px; border-radius: 50%; margin: 0 auto; position: relative; }
.opt-optom-glasses-fig { position: absolute; top: 14px; left: 50%; transform: translateX(-50%); width: 48px; height: 22px; }
.opt-optom-gframe-l { position: absolute; left: 0; top: 0; width: 18px; height: 18px; border-radius: 50%; border: 2.5px solid rgba(14,140,140,.9); }
.opt-optom-gframe-r { position: absolute; right: 0; top: 0; width: 18px; height: 18px; border-radius: 50%; border: 2.5px solid rgba(14,140,140,.9); }
.opt-optom-gbridge { position: absolute; top: 7px; left: 17px; width: 14px; height: 2.5px; background: rgba(14,140,140,.9); }
.opt-optom-body { width: 64px; height: 80px; margin: 0 auto; border-radius: 8px 8px 0 0; }
.opt-optom-coat { background: linear-gradient(180deg, #f8f8f8 0%, #e8e8e8 100%); }
.opt-optom-uniform { background: linear-gradient(180deg, var(--opt-teal) 0%, #0a6a6a 100%); }
.opt-optom-collar { position: absolute; top: 0; left: 50%; transform: translateX(-50%); width: 20px; height: 10px; background: rgba(0,0,0,.08); border-radius: 0 0 8px 8px; }
.opt-team-info { padding: 16px 16px 20px; }
.opt-team-name { font-family: var(--opt-font-head); font-size: .95rem; font-weight: 700; color: var(--opt-deep); margin-bottom: 4px; }
.opt-team-role { font-size: .78rem; font-weight: 700; color: var(--opt-teal); letter-spacing: .06em; text-transform: uppercase; margin-bottom: 6px; }
.opt-team-qual { font-size: .75rem; color: var(--opt-muted); margin-bottom: 6px; }
.opt-team-spec { display: inline-block; background: var(--opt-sky); color: var(--opt-cobalt); font-size: .72rem; font-weight: 600; padding: 2px 10px; border-radius: 12px; }

/* ═══════════════════════════════════════════════════════════
   PROCESS
═══════════════════════════════════════════════════════════ */
.opt-process-grid { display: grid; grid-template-columns: repeat(5,1fr); gap: 0; margin-top: 56px; position: relative; }
.opt-process-grid::before { content: ''; position: absolute; top: 32px; left: 10%; right: 10%; height: 2px; background: linear-gradient(90deg, var(--opt-teal) 0%, var(--opt-cobalt-lt) 100%); }
.opt-process-item { text-align: center; padding: 0 12px; position: relative; }
.opt-process-num { width: 64px; height: 64px; border-radius: 50%; background: var(--opt-teal); border: 3px solid var(--opt-white); box-shadow: 0 0 0 4px var(--opt-teal); display: flex; align-items: center; justify-content: center; font-family: var(--opt-font-head); font-size: 1.1rem; font-weight: 700; color: var(--opt-white); margin: 0 auto 20px; position: relative; z-index: 1; }
.opt-process-title { font-weight: 700; font-size: .9rem; color: var(--opt-deep); margin-bottom: 8px; }
.opt-process-desc { font-size: .8rem; color: var(--opt-muted); line-height: 1.55; }

/* ═══════════════════════════════════════════════════════════
   TESTIMONIALS
═══════════════════════════════════════════════════════════ */
.opt-testimonials-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; margin-top: 48px; }
.opt-testimonial { background: rgba(255,255,255,.06); border: 1px solid rgba(255,255,255,.1); border-radius: var(--opt-r-lg); padding: 32px 28px; }
.opt-testimonial-stars { display: flex; gap: 3px; margin-bottom: 14px; }
.opt-testimonial-stars span { color: var(--opt-teal-lt); font-size: .9rem; }
.opt-testimonial-quote { font-size: .9rem; color: rgba(255,255,255,.82); line-height: 1.7; font-style: italic; margin-bottom: 20px; }
.opt-testimonial-author { display: flex; align-items: center; gap: 12px; }
.opt-testimonial-avatar { width: 40px; height: 40px; border-radius: 50%; background: var(--opt-teal); display: flex; align-items: center; justify-content: center; font-weight: 700; color: var(--opt-white); font-size: .9rem; }
.opt-testimonial-name { font-weight: 700; font-size: .88rem; color: var(--opt-white); }

/* ═══════════════════════════════════════════════════════════
   FAQ
═══════════════════════════════════════════════════════════ */
.opt-faq-list { margin-top: 48px; display: flex; flex-direction: column; gap: 2px; }
.opt-faq-item { background: var(--opt-white); border: 1px solid var(--opt-border); border-radius: var(--opt-r); overflow: hidden; }
.opt-faq-q { display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 18px 24px; cursor: pointer; font-weight: 600; color: var(--opt-deep); user-select: none; transition: background .2s; }
.opt-faq-q:hover { background: var(--opt-sky); }
.opt-faq-q.open { background: var(--opt-teal); color: var(--opt-white); }
.opt-faq-icon { flex-shrink: 0; font-size: 1.1rem; transition: transform .25s; }
.opt-faq-q.open .opt-faq-icon { transform: rotate(45deg); }
.opt-faq-a { max-height: 0; overflow: hidden; transition: max-height .4s ease; }
.opt-faq-a.open { max-height: 300px; }
.opt-faq-a-inner { padding: 16px 24px 20px; font-size: .88rem; color: var(--opt-muted); line-height: 1.7; }

/* ═══════════════════════════════════════════════════════════
   APPOINTMENT FORM
═══════════════════════════════════════════════════════════ */
.opt-appt-split { display: grid; grid-template-columns: 1fr 1.2fr; gap: 64px; align-items: start; }
.opt-appt-info { }
.opt-appt-feature { display: flex; gap: 16px; align-items: flex-start; margin-bottom: 24px; }
.opt-appt-feat-icon { flex-shrink: 0; width: 48px; height: 48px; border-radius: var(--opt-r); background: rgba(14,140,140,.15); border: 1px solid rgba(14,140,140,.25); display: flex; align-items: center; justify-content: center; }
.opt-appt-feat-icon svg { width: 22px; height: 22px; fill: var(--opt-teal-lt); }
.opt-appt-feat-title { font-weight: 700; font-size: .9rem; color: var(--opt-white); margin-bottom: 4px; }
.opt-appt-feat-desc { font-size: .82rem; color: rgba(255,255,255,.6); line-height: 1.5; }
.opt-form-card { background: var(--opt-white); border-radius: var(--opt-r-lg); padding: 36px; }
.opt-form-title { font-family: var(--opt-font-head); font-size: 1.4rem; font-weight: 700; color: var(--opt-deep); margin-bottom: 6px; }
.opt-form-sub { font-size: .88rem; color: var(--opt-muted); margin-bottom: 24px; }
.opt-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.opt-form-group { margin-bottom: 16px; }
.opt-form-group label { display: block; font-size: .78rem; font-weight: 700; color: var(--opt-deep); letter-spacing: .04em; text-transform: uppercase; margin-bottom: 6px; }
.opt-form-group input,
.opt-form-group select,
.opt-form-group textarea { width: 100%; padding: 11px 14px; background: var(--opt-cream); border: 1.5px solid var(--opt-border); border-radius: var(--opt-r); font-family: var(--opt-font-body); font-size: .9rem; color: var(--opt-text); outline: none; transition: border-color .2s; }
.opt-form-group input:focus,
.opt-form-group select:focus,
.opt-form-group textarea:focus { border-color: var(--opt-teal); background: var(--opt-white); }
.opt-form-group textarea { resize: vertical; min-height: 90px; }
.opt-form-note { font-size: .75rem; color: var(--opt-muted); margin-top: 12px; line-height: 1.5; }

/* ═══════════════════════════════════════════════════════════
   FOOTER STRIP
═══════════════════════════════════════════════════════════ */
.opt-footer { background: var(--opt-deep); border-top: 1px solid rgba(14,140,140,.2); padding: 24px 0; }
.opt-footer-inner { display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap; }
.opt-footer-copy { font-size: .8rem; color: rgba(255,255,255,.4); }
.opt-footer-links { display: flex; gap: 20px; }
.opt-footer-links a { font-size: .8rem; color: rgba(255,255,255,.4); text-decoration: none; }
.opt-footer-links a:hover { color: var(--opt-teal-lt); }
.opt-footer-goc { font-size: .75rem; color: rgba(255,255,255,.35); margin-top: 4px; }

/* ═══════════════════════════════════════════════════════════
   RESPONSIVE
═══════════════════════════════════════════════════════════ */
@media (max-width: 1024px) {
    .opt-services-grid { grid-template-columns: repeat(2,1fr); }
    .opt-frames-grid   { grid-template-columns: repeat(2,1fr); }
    .opt-team-grid     { grid-template-columns: repeat(2,1fr); }
    .opt-process-grid  { grid-template-columns: repeat(3,1fr); gap: 24px; }
    .opt-process-grid::before { display: none; }
    .opt-stats-grid    { grid-template-columns: repeat(2,1fr); }
    .opt-stat { border-right: none; border-bottom: 1px solid rgba(255,255,255,.1); }
    .opt-stat:nth-child(odd) { border-right: 1px solid rgba(255,255,255,.1); }
    .opt-stat:last-child { border-bottom: none; }
    .opt-appt-split    { grid-template-columns: 1fr; }
    .opt-nav-links     { display: none; }
}
@media (max-width: 640px) {
    .opt-services-grid { grid-template-columns: 1fr; }
    .opt-frames-grid   { grid-template-columns: 1fr; }
    .opt-team-grid     { grid-template-columns: 1fr; }
    .opt-process-grid  { grid-template-columns: 1fr; }
    .opt-testimonials-grid { grid-template-columns: 1fr; }
    .opt-form-row      { grid-template-columns: 1fr; }
    .opt-hero-ctas     { flex-direction: column; }
    .opt-hero-trust    { grid-template-columns: 1fr; }
}
</style>

<div class="opt-page">

<!-- ══ NAV ══════════════════════════════════════════════════ -->
<nav class="opt-nav">
    <div class="opt-wrap">
        <div class="opt-nav-inner">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="opt-nav-logo">
                <!-- CSS eye SVG logo -->
                <svg class="opt-nav-logo-icon" viewBox="0 0 38 38" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect width="38" height="38" rx="8" fill="#e0f4f4"/>
                    <path d="M5 19c4-8 24-8 28 0-4 8-24 8-28 0z" fill="#0e8c8c" opacity=".3"/>
                    <path d="M5 19c4-8 24-8 28 0-4 8-24 8-28 0z" stroke="#0e8c8c" stroke-width="1.5" fill="none"/>
                    <circle cx="19" cy="19" r="6" fill="#0e8c8c" opacity=".7"/>
                    <circle cx="19" cy="19" r="3.5" fill="#0c1a2e"/>
                    <circle cx="17" cy="17" r="1.2" fill="rgba(255,255,255,.6)"/>
                </svg>
                <div>
                    <div class="opt-nav-logo-name"><?php echo esc_html($practice_name); ?></div>
                    <span class="opt-nav-logo-sub">Independent Opticians</span>
                </div>
            </a>
            <ul class="opt-nav-links">
                <li><a href="#services">Eye Tests</a></li>
                <li><a href="#frames">Eyewear</a></li>
                <li><a href="#team">Our Team</a></li>
                <li><a href="#faq">FAQ</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
            <div class="opt-nav-cta">
                <span class="opt-nav-nhs">NHS <strong>Eye Tests</strong> Available</span>
                <a href="tel:<?php echo preg_replace('/\D/','',$phone); ?>" class="opt-nav-phone">&#128222; <?php echo esc_html($phone); ?></a>
                <a href="#contact" class="opt-btn opt-btn-teal" style="padding:10px 20px;font-size:.85rem;">Book Eye Test</a>
            </div>
        </div>
    </div>
</nav>

<!-- ══ HERO ══════════════════════════════════════════════════ -->
<section class="opt-hero">
    <div class="opt-hero-scene">
        <!-- Room -->
        <div class="opt-room-floor"></div>

        <!-- Eye chart on wall -->
        <div class="opt-eye-chart">
            <div class="opt-chart-mount">
                <?php
                $chart_rows = [
                    ['E','',     '',    '',    '',    '',    '',  '',  72],
                    ['F','P','',    '',    '',    '',    '',  '',  50],
                    ['T','O','Z',  '',    '',    '',    '',  '',  36],
                    ['L','P','E','D','',    '',    '',  '',  29],
                    ['P','E','C','F','D',  '',    '',  '',  20],
                    ['E','D','F','C','Z','P','',  '',  14],
                    ['F','E','L','O','P','Z','D','',  11],
                    ['D','E','F','P','O','T','E','C', 8],
                ];
                foreach ($chart_rows as $cr) :
                    $sz = end($cr);
                    echo '<div class="opt-chart-row" style="font-size:' . $sz . 'px;line-height:1.1;letter-spacing:4px;">';
                    for ($ci = 0; $ci < count($cr) - 1; $ci++) {
                        if ($cr[$ci] !== '') echo esc_html($cr[$ci]);
                    }
                    echo '</div>';
                endforeach;
                ?>
            </div>
        </div>

        <!-- Testing beam -->
        <div class="opt-beam"></div>

        <!-- Large CSS Eye -->
        <div class="opt-eye-orb">
            <div class="opt-eye-white">
                <div class="opt-iris">
                    <div class="opt-pupil"></div>
                    <div class="opt-eye-glint"></div>
                </div>
                <div class="opt-iris-ring opt-iris-ring-1"></div>
                <div class="opt-iris-ring opt-iris-ring-2"></div>
                <div class="opt-iris-ring opt-iris-ring-3"></div>
            </div>
        </div>

        <!-- Phoropter -->
        <div class="opt-phoropter">
            <div class="opt-phor-base"></div>
            <div class="opt-phor-arm"></div>
            <div class="opt-phor-head">
                <div class="opt-phor-lens-l"></div>
                <div class="opt-phor-lens-r"></div>
                <div class="opt-phor-knob"></div>
            </div>
        </div>

        <!-- Frames display -->
        <div class="opt-frames-display">
            <?php $fd_colors = ['#c8902a','#1a3a6e','#8b1a1a','#1a3a1a','#4a1a6e'];
            foreach ($fd_colors as $fdc) : ?>
            <div class="opt-frame-stand">
                <div class="opt-frame-css" style="--opt-frame-col:<?php echo esc_attr($fdc); ?>;">
                    <div class="opt-frame-css-left"></div>
                    <div class="opt-frame-css-right"></div>
                    <div class="opt-frame-css-bridge"></div>
                    <div class="opt-frame-css-ltem"></div>
                    <div class="opt-frame-css-rtem"></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Projection -->
        <div class="opt-projection"></div>

        <!-- Sparkle particles -->
        <?php for ($i = 0; $i < $n_sparkles; $i++) :
            $lft = rand(5, 95);
            $top = rand(5, 90);
            $dur = rand(2, 6);
            $del = rand(0, 5);
            $sz  = rand(2, 5);
        ?>
        <div class="opt-sparkle" style="
            left:<?= $lft ?>%;
            top:<?= $top ?>%;
            width:<?= $sz ?>px;
            height:<?= $sz ?>px;
            animation-duration:<?= $dur ?>s;
            animation-delay:-<?= $del ?>s;
        "></div>
        <?php endfor; ?>
    </div>

    <div class="opt-wrap">
        <div class="opt-hero-content">
            <div class="opt-hero-nhs">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="#90c0ff"><path d="M7 1a6 6 0 1 0 0 12A6 6 0 0 0 7 1zm.5 9h-1V6h1v4zm0-5h-1V4h1v1z"/></svg>
                NHS Eye Tests Available · Children Free
            </div>
            <h1 class="opt-hero-h1">See the World<br>in <em>Perfect Clarity</em></h1>
            <p class="opt-hero-desc">
                Manchester's trusted independent opticians since <?php echo date('Y') - 24; ?>.
                Cutting-edge diagnostic technology, expert clinical care and an exceptional
                collection of designer frames — all under one roof.
            </p>
            <div class="opt-hero-ctas">
                <a href="#contact" class="opt-btn opt-btn-teal">Book Eye Test Online</a>
                <a href="#services" class="opt-btn opt-btn-white">Our Services</a>
            </div>
            <div class="opt-hero-trust">
                <?php $trust = [
                    ['GOC Registered Optometrists', 'verified'],
                    ['Latest OCT & Retinal Imaging', 'scanner'],
                    ['Fully Independent Practice', 'independent'],
                    ['Same-Week Appointments', 'calendar'],
                ];
                foreach ($trust as $tr) : ?>
                <div class="opt-trust-pill">
                    <svg class="opt-trust-icon" viewBox="0 0 20 20" fill="#0eb8b8"><path d="M10 1l2.4 6.3H19l-5.2 3.8 2 6.3L10 14l-5.8 3.4 2-6.3L1 7.3h6.6z"/></svg>
                    <span class="opt-trust-text"><?php echo esc_html($tr[0]); ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>

<!-- ══ STATS ══════════════════════════════════════════════════ -->
<div class="opt-stats-bar">
    <div class="opt-wrap">
        <div class="opt-stats-grid">
            <?php foreach ($stats as $st) : ?>
            <div class="opt-stat">
                <div class="opt-stat-value">
                    <span class="opt-counter" data-target="<?php echo esc_attr(preg_replace('/,/','',$st['value'])); ?>"><?php echo esc_html($st['value']); ?></span><span class="opt-stat-suffix"><?php echo esc_html($st['suffix']); ?></span>
                </div>
                <div class="opt-stat-label"><?php echo esc_html($st['label']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ══ SERVICES ══════════════════════════════════════════════ -->
<section class="opt-section" id="services">
    <div class="opt-wrap">
        <div class="opt-center">
            <span class="opt-kicker">What We Offer</span>
            <h2 class="opt-h2">Expert Eyecare Services</h2>
            <div class="opt-h2-line"></div>
            <p class="opt-lead">From comprehensive eye examinations to specialist clinics, our clinical team provides the highest standard of eyecare at every visit.</p>
        </div>
        <div class="opt-services-grid">
            <?php $svc_icons = [
                'eye'    => '<path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zm0 12.5c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3z"/>',
                'lens'   => '<circle cx="12" cy="12" r="8" stroke-width="2" stroke="currentColor" fill="none"/><circle cx="12" cy="12" r="4" fill="currentColor" opacity=".4"/><circle cx="10" cy="10" r="1.5" fill="currentColor" opacity=".6"/>',
                'child'  => '<path d="M12 2a2 2 0 1 1 0 4 2 2 0 0 1 0-4zm-1 5h2c.6 0 1 .4 1 1v6h-1v4h-2v-4H9V8c0-.6.4-1 1-1zm-3 1.5L6 14h2l-1-3.5zM17 8.5L15 14h2l-1-3.5z"/>',
                'retina' => '<circle cx="12" cy="12" r="9" stroke-width="1.5" stroke="currentColor" fill="none"/><path d="M8 12c0-2.2 1.8-4 4-4s4 1.8 4 4" stroke-width="1.5" stroke="currentColor" fill="none"/><circle cx="12" cy="14" r="1.5"/>',
                'drop'   => '<path d="M12 2L6 12a6 6 0 1 0 12 0L12 2zm0 16a4 4 0 0 1-4-4c0-1.4.7-2.7 2-3.5l2-4 2 4a4 4 0 0 1 2 3.5 4 4 0 0 1-4 4z"/>',
                'chart'  => '<path d="M5 19h14v2H5zm0-4h3v3H5zm5-3h3v6h-3zm5-4h3v10h-3zM5 8h3v6H5z"/>',
            ];
            foreach ($services as $svc) : ?>
            <div class="opt-service-card">
                <div class="opt-service-icon">
                    <svg viewBox="0 0 24 24"><?php echo $svc_icons[$svc['icon']] ?? '<circle cx="12" cy="12" r="8"/>'; ?></svg>
                </div>
                <h3 class="opt-service-title"><?php echo esc_html($svc['title']); ?></h3>
                <p class="opt-service-desc"><?php echo esc_html($svc['desc']); ?></p>
                <span class="opt-service-price"><?php echo esc_html($svc['price']); ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══ FRAMES ════════════════════════════════════════════════ -->
<section class="opt-section opt-section-alt" id="frames">
    <div class="opt-wrap">
        <div class="opt-center">
            <span class="opt-kicker">Eyewear Collection</span>
            <h2 class="opt-h2">Designer Frames &amp; Lenses</h2>
            <div class="opt-h2-line"></div>
            <p class="opt-lead">Hundreds of frames from the world's leading brands, expertly dispensed to suit your prescription, face shape and lifestyle.</p>
        </div>
        <div class="opt-frames-grid">
            <?php
            $frame_gc = ['#1a3a6e','#c8902a','#8b1a1a','#1a3a1a','#4a1a6e','#2a2a2a'];
            $frame_shape_classes = ['','opt-glasses-rect','opt-glasses-cat','opt-glasses-round','opt-glasses-rect','opt-glasses-cat'];
            foreach ($frames as $fi => $fr) :
                $gc = $frame_gc[$fi % count($frame_gc)];
                $sc = $frame_shape_classes[$fi % count($frame_shape_classes)];
            ?>
            <div class="opt-frame-card">
                <div class="opt-frame-visual">
                    <div class="opt-glasses <?php echo esc_attr($sc); ?>" style="--opt-gc:<?php echo esc_attr($gc); ?>;">
                        <div class="opt-glass-l"></div>
                        <div class="opt-glass-r"></div>
                        <div class="opt-glass-bridge"></div>
                        <div class="opt-glass-arm-l"></div>
                        <div class="opt-glass-arm-r"></div>
                    </div>
                </div>
                <div class="opt-frame-brand"><?php echo esc_html($fr['brand']); ?></div>
                <div class="opt-frame-style"><?php echo esc_html($fr['style']); ?></div>
                <div class="opt-frame-from">From <span>£<?php echo esc_html($fr['from']); ?></span></div>
            </div>
            <?php endforeach; ?>
        </div>
        <div style="text-align:center;margin-top:40px;">
            <a href="#contact" class="opt-btn opt-btn-cobalt">Try Frames In-Store →</a>
        </div>
    </div>
</section>

<!-- ══ TEAM ══════════════════════════════════════════════════ -->
<section class="opt-section" id="team">
    <div class="opt-wrap">
        <div class="opt-center">
            <span class="opt-kicker">Our Clinicians</span>
            <h2 class="opt-h2">Meet the Team</h2>
            <div class="opt-h2-line"></div>
            <p class="opt-lead">Qualified, experienced and passionate about eyecare — our team is here to look after you and your family's vision for life.</p>
        </div>
        <div class="opt-team-grid">
            <?php $team_bgs = ['#1a3a6e','#0e6a6a','#1e2a4a','#0a5050'];
            $team_head_colors = ['#c8966a','#a87848','#d4a878','#b8885a'];
            foreach ($team as $ti => $tm) :
                $bg = $team_bgs[$ti % count($team_bgs)];
                $hc = $team_head_colors[$ti % count($team_head_colors)];
                $use_coat = ($ti % 2 === 0);
            ?>
            <div class="opt-team-card">
                <div class="opt-team-avatar" style="background:<?php echo esc_attr($bg); ?>;">
                    <div class="opt-optom-fig">
                        <div class="opt-optom-head" style="background:radial-gradient(circle at 40% 35%, <?php echo esc_attr($hc); ?> 0%, <?php echo esc_attr(substr($hc,0,7)); ?>88 100%);">
                            <!-- Glasses on face -->
                            <div class="opt-optom-glasses-fig">
                                <div class="opt-optom-gframe-l"></div>
                                <div class="opt-optom-gframe-r"></div>
                                <div class="opt-optom-gbridge"></div>
                            </div>
                        </div>
                        <div class="opt-optom-body <?php echo $use_coat ? 'opt-optom-coat' : 'opt-optom-uniform'; ?>" style="position:relative;">
                            <div class="opt-optom-collar"></div>
                        </div>
                    </div>
                </div>
                <div class="opt-team-info">
                    <div class="opt-team-name"><?php echo esc_html($tm['name']); ?></div>
                    <div class="opt-team-role"><?php echo esc_html($tm['role']); ?></div>
                    <div class="opt-team-qual"><?php echo esc_html($tm['qual']); ?></div>
                    <span class="opt-team-spec"><?php echo esc_html($tm['spec']); ?></span>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══ PROCESS ═══════════════════════════════════════════════ -->
<section class="opt-section opt-section-alt" id="process">
    <div class="opt-wrap">
        <div class="opt-center">
            <span class="opt-kicker">Your Visit</span>
            <h2 class="opt-h2">What to Expect</h2>
            <div class="opt-h2-line"></div>
            <p class="opt-lead">From booking to collection, we make every step of your eyecare journey simple, comfortable and completely personal.</p>
        </div>
        <div class="opt-process-grid">
            <?php foreach ($process as $ps) : ?>
            <div class="opt-process-item">
                <div class="opt-process-num"><?php echo esc_html($ps['step']); ?></div>
                <div class="opt-process-title"><?php echo esc_html($ps['title']); ?></div>
                <p class="opt-process-desc"><?php echo esc_html($ps['desc']); ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══ TESTIMONIALS ══════════════════════════════════════════ -->
<section class="opt-section opt-section-dark" id="testimonials">
    <div class="opt-wrap">
        <div class="opt-center">
            <span class="opt-kicker">Patient Reviews</span>
            <h2 class="opt-h2">Trusted by Thousands</h2>
            <div class="opt-h2-line"></div>
            <p class="opt-lead">Hear from patients who've experienced the Vista difference.</p>
        </div>
        <div class="opt-testimonials-grid">
            <?php foreach ($testimonials as $t) : ?>
            <div class="opt-testimonial">
                <div class="opt-testimonial-stars">
                    <?php for ($s = 0; $s < $t['stars']; $s++) echo '<span>&#9733;</span>'; ?>
                </div>
                <p class="opt-testimonial-quote"><?php echo esc_html($t['quote']); ?></p>
                <div class="opt-testimonial-author">
                    <div class="opt-testimonial-avatar"><?php echo esc_html(substr($t['name'],0,1)); ?></div>
                    <div class="opt-testimonial-name"><?php echo esc_html($t['name']); ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══ FAQ ═══════════════════════════════════════════════════ -->
<section class="opt-section" id="faq">
    <div class="opt-wrap" style="max-width:800px;">
        <div class="opt-center">
            <span class="opt-kicker">Common Questions</span>
            <h2 class="opt-h2">Frequently Asked Questions</h2>
            <div class="opt-h2-line"></div>
        </div>
        <div class="opt-faq-list">
            <?php foreach ($faqs as $fi => $faq) : ?>
            <div class="opt-faq-item">
                <div class="opt-faq-q" role="button" aria-expanded="false" aria-controls="opt-faq-a-<?php echo $fi; ?>" tabindex="0">
                    <?php echo esc_html($faq['q']); ?>
                    <span class="opt-faq-icon">+</span>
                </div>
                <div class="opt-faq-a" id="opt-faq-a-<?php echo $fi; ?>" role="region">
                    <div class="opt-faq-a-inner"><?php echo esc_html($faq['a']); ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══ APPOINTMENT / CONTACT ═════════════════════════════════ -->
<section class="opt-section opt-section-dark" id="contact">
    <div class="opt-wrap">
        <div class="opt-appt-split">
            <div class="opt-appt-info">
                <span class="opt-kicker">Book an Appointment</span>
                <h2 class="opt-h2">Ready for Clearer Vision?</h2>
                <div class="opt-h2-line" style="background:var(--opt-teal);"></div>
                <p class="opt-lead" style="margin-bottom:40px;">Same-week appointments available. Book online or call us — our team will find a time that suits you perfectly.</p>
                <?php $feats = [
                    ['Free Parking Nearby', 'Deansgate car parks 2 minutes away'],
                    ['Wheelchair Accessible', 'Full ground-floor access and facilities'],
                    ['Evening Appointments', 'Available Tuesdays and Thursdays until 7pm'],
                    ['NHS & Private', 'We accept NHS vouchers and all major insurers'],
                ];
                $feat_icons = [
                    '<path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/>',
                    '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>',
                    '<path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67V7z"/>',
                    '<path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM7 10h5v5H7z"/>',
                ];
                foreach ($feats as $fi => $feat) : ?>
                <div class="opt-appt-feature">
                    <div class="opt-appt-feat-icon">
                        <svg viewBox="0 0 24 24"><?php echo $feat_icons[$fi]; ?></svg>
                    </div>
                    <div>
                        <div class="opt-appt-feat-title"><?php echo esc_html($feat[0]); ?></div>
                        <div class="opt-appt-feat-desc"><?php echo esc_html($feat[1]); ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
                <div style="margin-top:8px;">
                    <a href="tel:<?php echo preg_replace('/\D/','',$phone); ?>" class="opt-btn opt-btn-teal">&#128222; Call <?php echo esc_html($phone); ?></a>
                </div>
            </div>

            <div class="opt-form-card">
                <div class="opt-form-title">Book Your Eye Test</div>
                <div class="opt-form-sub">Complete the form and we'll confirm your appointment within 2 hours.</div>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" novalidate>
                    <?php wp_nonce_field('tf_opt_appointment','tf_opt_nonce'); ?>
                    <input type="hidden" name="action" value="tf_optician_appointment">
                    <div class="opt-form-row">
                        <div class="opt-form-group">
                            <label for="opt-fname">First Name <span style="color:var(--opt-teal)">*</span></label>
                            <input type="text" id="opt-fname" name="first_name" placeholder="Sarah" required>
                        </div>
                        <div class="opt-form-group">
                            <label for="opt-lname">Last Name <span style="color:var(--opt-teal)">*</span></label>
                            <input type="text" id="opt-lname" name="last_name" placeholder="Johnson" required>
                        </div>
                    </div>
                    <div class="opt-form-row">
                        <div class="opt-form-group">
                            <label for="opt-email">Email <span style="color:var(--opt-teal)">*</span></label>
                            <input type="email" id="opt-email" name="email" placeholder="sarah@example.com" required>
                        </div>
                        <div class="opt-form-group">
                            <label for="opt-phone">Phone <span style="color:var(--opt-teal)">*</span></label>
                            <input type="tel" id="opt-phone" name="phone" placeholder="07700 900000" required>
                        </div>
                    </div>
                    <div class="opt-form-group">
                        <label for="opt-appt-type">Appointment Type <span style="color:var(--opt-teal)">*</span></label>
                        <select id="opt-appt-type" name="appointment_type" required>
                            <option value="">— Select Appointment Type —</option>
                            <option value="eye-test">Full Eye Test (Adult)</option>
                            <option value="child-eye-test">Children's Eye Test (NHS Free)</option>
                            <option value="contact-lens">Contact Lens Fitting</option>
                            <option value="dry-eye">Dry Eye Clinic</option>
                            <option value="myopia">Myopia Management Consultation</option>
                            <option value="other">Other / Not Sure</option>
                        </select>
                    </div>
                    <div class="opt-form-row">
                        <div class="opt-form-group">
                            <label for="opt-date">Preferred Date</label>
                            <input type="date" id="opt-date" name="preferred_date" min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>">
                        </div>
                        <div class="opt-form-group">
                            <label for="opt-time">Preferred Time</label>
                            <select id="opt-time" name="preferred_time">
                                <option value="">— No preference —</option>
                                <option value="morning">Morning (9am–12pm)</option>
                                <option value="afternoon">Afternoon (12pm–5pm)</option>
                                <option value="evening">Evening (5pm–7pm Tue/Thu)</option>
                            </select>
                        </div>
                    </div>
                    <div class="opt-form-group">
                        <label for="opt-nhs">Are you eligible for an NHS eye test?</label>
                        <select id="opt-nhs" name="nhs_eligible">
                            <option value="not-sure">Not sure</option>
                            <option value="yes">Yes</option>
                            <option value="no">No / Private Patient</option>
                        </select>
                    </div>
                    <div class="opt-form-group">
                        <label for="opt-notes">Additional Notes</label>
                        <textarea id="opt-notes" name="notes" placeholder="Any specific concerns, existing conditions or questions for your optometrist..."></textarea>
                    </div>
                    <button type="submit" class="opt-btn opt-btn-teal" style="width:100%;justify-content:center;">
                        Book Appointment &rarr;
                    </button>
                    <p class="opt-form-note">By booking you agree to our Privacy Policy. We will confirm your appointment by email within 2 hours. <?php echo esc_html($practice_name); ?> is registered with the General Optical Council.</p>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- ══ FOOTER ════════════════════════════════════════════════ -->
<footer class="opt-footer">
    <div class="opt-wrap">
        <div class="opt-footer-inner">
            <div>
                <div class="opt-footer-copy">&copy; <?php echo date('Y'); ?> <?php echo esc_html($practice_name); ?>. All rights reserved.</div>
                <div class="opt-footer-goc">Registered with the General Optical Council. GOC Registration: 01-23456.</div>
            </div>
            <div class="opt-footer-links">
                <a href="#">Privacy Policy</a>
                <a href="#">Accessibility</a>
                <a href="#">NHS Information</a>
                <a href="#">Cookie Policy</a>
            </div>
        </div>
    </div>
</footer>

</div><!-- .opt-page -->

<script>
/* ── Animated counters ─────────────────────────────────── */
(function () {
    var counters = document.querySelectorAll('.opt-counter');
    if (!counters.length) return;
    var observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (!entry.isIntersecting) return;
            observer.unobserve(entry.target);
            var el      = entry.target;
            var raw     = el.dataset.target.replace(/,/g, '');
            var end     = parseFloat(raw);
            if (isNaN(end)) return;
            var isFloat = raw.indexOf('.') !== -1;
            var dur     = 1800;
            var start   = performance.now();
            var easeOut = function (t) { return 1 - Math.pow(1 - t, 3); };
            (function tick(now) {
                var prog = Math.min((now - start) / dur, 1);
                var val  = end * easeOut(prog);
                el.textContent = isFloat
                    ? val.toFixed(1)
                    : Math.round(val).toLocaleString();
                if (prog < 1) requestAnimationFrame(tick);
                else el.textContent = isFloat ? end.toFixed(1) : end.toLocaleString();
            })(start);
        });
    }, { threshold: 0.4 });
    counters.forEach(function (c) { observer.observe(c); });
})();

/* ── FAQ accordion ─────────────────────────────────────── */
(function () {
    var questions = document.querySelectorAll('.opt-faq-q');
    questions.forEach(function (q) {
        function toggle() {
            var isOpen = q.classList.contains('open');
            document.querySelectorAll('.opt-faq-q').forEach(function (qq) { qq.classList.remove('open'); qq.setAttribute('aria-expanded','false'); });
            document.querySelectorAll('.opt-faq-a').forEach(function (aa) { aa.classList.remove('open'); });
            if (!isOpen) {
                q.classList.add('open');
                q.setAttribute('aria-expanded','true');
                var aid = q.getAttribute('aria-controls');
                var ans = document.getElementById(aid);
                if (ans) ans.classList.add('open');
            }
        }
        q.addEventListener('click', toggle);
        q.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); } });
    });
})();
</script>

<?php get_footer(); ?>
