<?php
/**
 * Template Name: Osteopath Clinic
 *
 * Premium landing page for osteopaths and osteopathic clinics.
 * Palette: warm stone #F5F0EB / deep slate #2C3E50 / healing teal #2E8B7A / soft amber #D4925A
 * Fonts: Cormorant Garamond + Lato
 * Namespace: --ot-*
 *
 * @package ThemeFlex
 */

if ( ! defined( 'ABSPATH' ) ) exit;

srand( crc32( get_the_permalink() ) );

$ot_services = [
    [ 'icon' => '🦴', 'title' => 'Spinal Treatment',      'desc' => 'Precise spinal manipulation and mobilisation to relieve back and neck pain, restore alignment and improve posture.' ],
    [ 'icon' => '💪', 'title' => 'Sports Injuries',        'desc' => 'Targeted treatment for sports-related strains, sprains and overuse injuries to get you back in the game faster.' ],
    [ 'icon' => '🤰', 'title' => 'Pregnancy Care',         'desc' => 'Gentle, safe osteopathic care throughout pregnancy to ease discomfort, support posture changes and prepare for birth.' ],
    [ 'icon' => '👶', 'title' => 'Paediatric Osteopathy',  'desc' => 'Specialist gentle treatment for babies, toddlers and children addressing colic, sleep issues and developmental concerns.' ],
    [ 'icon' => '🧠', 'title' => 'Cranial Osteopathy',     'desc' => 'Subtle, non-invasive technique working with rhythmic patterns in the body to release tension and restore balance.' ],
    [ 'icon' => '🦷', 'title' => 'TMJ & Jaw Pain',         'desc' => 'Effective treatment for temporomandibular joint dysfunction, headaches and facial pain caused by jaw tension.' ],
    [ 'icon' => '🦵', 'title' => 'Joint Mobilisation',     'desc' => 'Skilled mobilisation of hip, knee, shoulder and elbow joints to restore full range of motion and reduce pain.' ],
    [ 'icon' => '🫁', 'title' => 'Respiratory Support',    'desc' => 'Osteopathic techniques to improve rib cage mobility, diaphragm function and breathing efficiency.' ],
];

$ot_conditions = [
    'Back Pain','Neck Pain','Sciatica','Disc Problems','Frozen Shoulder','Tennis Elbow',
    'Hip Pain','Knee Pain','Plantar Fasciitis','Headaches & Migraines','Postural Problems',
    'Whiplash','Arthritis','Fibromyalgia','Carpal Tunnel','Growing Pains','Colic & Reflux','Pregnancy Discomfort',
];

$ot_steps = [
    [ 'num' => '01', 'title' => 'Initial Consultation',   'desc' => 'A thorough 60-minute first appointment covering your full case history, lifestyle and health goals.' ],
    [ 'num' => '02', 'title' => 'Physical Assessment',    'desc' => 'Detailed postural and movement assessment to identify structural imbalances and areas of restriction.' ],
    [ 'num' => '03', 'title' => 'Personalised Treatment', 'desc' => 'Hands-on osteopathic treatment tailored specifically to your body, condition and recovery goals.' ],
    [ 'num' => '04', 'title' => 'Exercise & Advice',      'desc' => 'Tailored home exercise programme and lifestyle advice to support your recovery between sessions.' ],
    [ 'num' => '05', 'title' => 'Ongoing Review',         'desc' => 'Regular progress reviews to adjust your treatment plan and ensure you\'re achieving lasting results.' ],
];

$ot_gallery = [
    [ 'label' => 'Treatment Room', 'c1' => '#2E8B7A', 'c2' => '#1a6b5a' ],
    [ 'label' => 'Reception Area', 'c1' => '#2C3E50', 'c2' => '#1a2a3a' ],
    [ 'label' => 'Spinal Assessment', 'c1' => '#D4925A', 'c2' => '#b87040' ],
    [ 'label' => 'Exercise Studio', 'c1' => '#4a8fba', 'c2' => '#2e6fa0' ],
    [ 'label' => 'Cranial Suite', 'c1' => '#8B6BA0', 'c2' => '#6a4a80' ],
    [ 'label' => 'Consultation Room', 'c1' => '#5a9a6a', 'c2' => '#3a7a4a' ],
];

$ot_packages = [
    [
        'name'     => 'Initial + Follow-Up',
        'price'    => '£130',
        'sub'      => 'First visit bundle',
        'featured' => false,
        'items'    => [ '60-min initial consultation', 'Full postural assessment', 'Hands-on treatment', '45-min follow-up session', 'Home exercise programme' ],
    ],
    [
        'name'     => 'Treatment Course',
        'price'    => '£320',
        'sub'      => 'Most popular · 5 sessions',
        'featured' => true,
        'items'    => [ '5 × 45-min sessions', 'Personalised treatment plan', 'Exercise & lifestyle coaching', 'Email support between visits', 'Progress tracking & review' ],
    ],
    [
        'name'     => 'Maintenance Plan',
        'price'    => '£55',
        'sub'      => 'Per session · rolling',
        'featured' => false,
        'items'    => [ '45-min treatment session', 'Flexible scheduling', 'No long-term commitment', 'Discounted block bookings', 'Priority appointment access' ],
    ],
];

$ot_testimonials = [
    [ 'name' => 'Rachel T.', 'loc' => 'London', 'stars' => 5, 'text' => 'After years of chronic back pain I was sceptical, but after just four sessions I was pain-free for the first time in a decade. Absolutely outstanding care.' ],
    [ 'name' => 'James H.', 'loc' => 'Surrey', 'stars' => 5, 'text' => 'Brought my baby daughter for colic treatment and the results were remarkable. Gentle, professional and genuinely caring. Highly recommend.' ],
    [ 'name' => 'Priya K.', 'loc' => 'London', 'stars' => 5, 'text' => 'The cranial osteopathy sessions transformed my chronic migraines. I\'ve gone from weekly headaches to almost none. Life-changing treatment.' ],
];

// Floating body anatomy particles
$ot_particles = [];
$chars = ['○','◎','◯','◦','⊙','⊕','⊗','▫','▪','·','⋅','∘'];
for ( $i = 0; $i < 14; $i++ ) {
    $ot_particles[] = [
        'char'  => $chars[ array_rand( $chars ) ],
        'x'     => rand( 3, 97 ),
        'y'     => rand( 5, 92 ),
        'size'  => rand( 8, 22 ),
        'op'    => rand( 15, 45 ) / 100,
        'dur'   => rand( 60, 120 ) / 10,
        'delay' => rand( 0, 80 ) / 10,
        'depth' => rand( 15, 55 ) / 10,
    ];
}
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=Lato:wght@300;400;700;900&display=swap" rel="stylesheet">
<style>
/* =========================================================
   OSTEOPATH — CSS Custom Properties  (--ot-* namespace)
   ========================================================= */
:root {
    --ot-stone:   #F5F0EB;
    --ot-slate:   #2C3E50;
    --ot-teal:    #2E8B7A;
    --ot-teal-d:  #1a6b5a;
    --ot-amber:   #D4925A;
    --ot-amber-d: #b87040;
    --ot-cream:   #FAF8F4;
    --ot-text:    #3a3a3a;
    --ot-muted:   #6b7280;
    --ot-ff-head: 'Cormorant Garamond', Georgia, serif;
    --ot-ff-body: 'Lato', system-ui, sans-serif;
    --ot-radius:  10px;
    --ot-shadow:  0 8px 32px rgba(44,62,80,.10);
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{font-family:var(--ot-ff-body);color:var(--ot-text);background:var(--ot-stone);-webkit-font-smoothing:antialiased}
img{max-width:100%;height:auto;display:block}
a{color:inherit;text-decoration:none}
ul{list-style:none}

/* ── Utility ── */
.ot-container{max-width:1160px;margin:0 auto;padding:0 24px}
.ot-section{padding:90px 0}
.ot-eyebrow{font-family:var(--ot-ff-body);font-size:.75rem;font-weight:700;letter-spacing:.18em;text-transform:uppercase;color:var(--ot-teal);margin-bottom:12px;display:block}
.ot-heading{font-family:var(--ot-ff-head);font-size:clamp(2rem,4vw,3rem);font-weight:600;line-height:1.15;color:var(--ot-slate);margin-bottom:20px}
.ot-heading--light{color:#fff}
.ot-lead{font-size:1.05rem;line-height:1.75;color:var(--ot-muted);max-width:640px}
.ot-btn{display:inline-flex;align-items:center;gap:8px;padding:14px 32px;border-radius:4px;font-family:var(--ot-ff-body);font-size:.9rem;font-weight:700;letter-spacing:.06em;cursor:pointer;transition:all .25s;border:2px solid transparent}
.ot-btn--primary{background:var(--ot-teal);color:#fff;border-color:var(--ot-teal)}
.ot-btn--primary:hover{background:var(--ot-teal-d);border-color:var(--ot-teal-d);transform:translateY(-2px)}
.ot-btn--outline{background:transparent;color:#fff;border-color:rgba(255,255,255,.6)}
.ot-btn--outline:hover{background:rgba(255,255,255,.12);border-color:#fff}
.ot-btn--dark{background:var(--ot-slate);color:#fff;border-color:var(--ot-slate)}
.ot-btn--dark:hover{background:#1a2b3a;transform:translateY(-2px)}
.ot-center{text-align:center}
.ot-center .ot-lead{margin-inline:auto}

/* =========================================================
   HERO
   ========================================================= */
.ot-hero{position:relative;min-height:100vh;overflow:hidden;background:#1E2D3D;display:flex;align-items:center}

/* Treatment room background */
.ot-room{position:absolute;inset:0;overflow:hidden}

/* Walls */
.ot-room__wall{position:absolute;inset:0;background:linear-gradient(180deg,#e8e0d8 0%,#ddd5cb 100%)}
.ot-room__wall::before{content:'';position:absolute;inset:0;background-image:repeating-linear-gradient(0deg,rgba(0,0,0,.03) 0,rgba(0,0,0,.03) 1px,transparent 1px,transparent 48px),repeating-linear-gradient(90deg,rgba(0,0,0,.03) 0,rgba(0,0,0,.03) 1px,transparent 1px,transparent 48px)}

/* Dado rail */
.ot-room__dado{position:absolute;top:42%;left:0;right:0;height:10px;background:linear-gradient(180deg,#c8bfb4,#b8afa4,#c8bfb4);box-shadow:0 2px 8px rgba(0,0,0,.12)}
.ot-room__dado::before{content:'';position:absolute;top:-6px;left:0;right:0;height:6px;background:linear-gradient(180deg,#d8cfc4,#c8bfb4)}

/* Lower wall panel */
.ot-room__panel{position:absolute;top:42%;bottom:18%;left:0;right:0;background:linear-gradient(180deg,#d4cbbf,#c8bfb4)}

/* Floor */
.ot-room__floor{position:absolute;bottom:0;left:0;right:0;height:18%;background:linear-gradient(180deg,#9e8e7e,#8a7c6e);perspective:800px}
.ot-room__floor::before{content:'';position:absolute;inset:0;background-image:repeating-linear-gradient(90deg,rgba(255,255,255,.06) 0,rgba(255,255,255,.06) 1px,transparent 1px,transparent 60px);background-size:60px 100%}
.ot-room__floor::after{content:'';position:absolute;top:0;left:0;right:0;height:4px;background:linear-gradient(90deg,transparent,rgba(255,255,255,.3),transparent)}

/* Skirting */
.ot-room__skirting{position:absolute;bottom:18%;left:0;right:0;height:8px;background:linear-gradient(180deg,#e0d8d0,#c8c0b8,#b8b0a8);box-shadow:0 2px 6px rgba(0,0,0,.15)}

/* Treatment table */
.ot-table{position:absolute;bottom:18%;left:50%;transform:translateX(-50%);width:340px}
.ot-table__legs{display:flex;justify-content:space-between;height:70px;padding:0 20px}
.ot-table__leg{width:12px;background:linear-gradient(90deg,#8a7a6a,#7a6a5a);border-radius:2px}
.ot-table__frame{height:14px;background:linear-gradient(90deg,#9a8a7a,#8a7a6a,#9a8a7a);border-radius:3px 3px 0 0}
.ot-table__surface{height:18px;background:linear-gradient(180deg,#e8e0d8,#ddd5cb);border-radius:4px;position:relative;box-shadow:0 4px 12px rgba(0,0,0,.2)}
.ot-table__surface::before{content:'';position:absolute;top:4px;left:16px;right:16px;height:2px;background:rgba(255,255,255,.4);border-radius:1px}
/* Patient on table */
.ot-patient{position:absolute;bottom:18%;left:50%;transform:translateX(-50%);width:340px;pointer-events:none}
.ot-patient__body{position:absolute;bottom:100px;left:50%;transform:translateX(-50%);display:flex;align-items:center;gap:0}
.ot-patient__head{width:26px;height:26px;background:radial-gradient(circle at 38% 35%,#f0c890,#d4a060);border-radius:50%;position:relative;flex-shrink:0}
.ot-patient__torso{width:68px;height:22px;background:linear-gradient(180deg,#c8d8e8,#b0c8dc);border-radius:6px 2px 2px 6px;margin-left:-2px}
.ot-patient__legs{width:90px;height:16px;background:linear-gradient(180deg,#6080a0,#4a6888);border-radius:0 4px 4px 0;margin-left:-1px}

/* Osteopath figure */
.ot-therapist{position:absolute;bottom:18%;right:22%;display:flex;flex-direction:column;align-items:center;pointer-events:none}
.ot-therapist__head{width:30px;height:30px;background:radial-gradient(circle at 38% 35%,#ffe0b2,#ffb870);border-radius:50%;margin-bottom:2px;position:relative}
.ot-therapist__head::after{content:'';position:absolute;top:-8px;left:0;right:0;height:12px;background:linear-gradient(180deg,#2E8B7A,#1a6b5a);border-radius:50% 50% 0 0}
.ot-therapist__body{width:42px;height:56px;background:linear-gradient(180deg,#fff,#f0ece8);border-radius:6px 6px 2px 2px;position:relative}
.ot-therapist__body::before{content:'';position:absolute;top:6px;left:50%;transform:translateX(-50%);width:28px;height:40px;background:var(--ot-teal);border-radius:4px;opacity:.9}
.ot-therapist__body::after{content:'';position:absolute;top:14px;left:50%;transform:translateX(-55%) rotate(-20deg);width:30px;height:6px;background:linear-gradient(90deg,#ffe0b2,#ffb870);border-radius:3px}
.ot-therapist__arm{position:absolute;left:-14px;top:20px;width:14px;height:28px;background:linear-gradient(90deg,#ffe0b2,#ffb870);border-radius:3px;transform:rotate(25deg)}

/* Anatomy skeleton overlay - art piece */
.ot-skeleton{position:absolute;left:12%;top:8%;width:90px;height:220px;opacity:.12;pointer-events:none}
.ot-skeleton__spine{position:absolute;left:50%;transform:translateX(-50%);top:0;width:6px;height:100%;background:repeating-linear-gradient(180deg,#2C3E50 0,#2C3E50 10px,transparent 10px,transparent 14px);border-radius:3px}
.ot-skeleton__rib{position:absolute;left:50%;height:2px;background:rgba(44,62,80,.8);border-radius:1px}

/* Window - frosted/privacy glass */
.ot-window{position:absolute;top:8%;right:10%;width:100px;height:140px;background:linear-gradient(135deg,rgba(200,220,240,.7),rgba(180,200,220,.5));border:3px solid #b0a898;border-radius:2px;overflow:hidden;box-shadow:inset 0 0 20px rgba(255,255,255,.3),4px 4px 16px rgba(0,0,0,.15)}
.ot-window::before{content:'';position:absolute;top:0;bottom:0;left:50%;transform:translateX(-50%);width:3px;background:#b0a898}
.ot-window::after{content:'';position:absolute;left:0;right:0;top:50%;transform:translateY(-50%);height:3px;background:#b0a898}
.ot-window__light{position:absolute;top:0;left:0;right:0;height:50%;background:linear-gradient(180deg,rgba(255,255,255,.4),transparent)}

/* Shelf with reference books */
.ot-shelf{position:absolute;top:20%;left:5%;width:130px}
.ot-shelf__board{height:8px;background:linear-gradient(180deg,#c8b8a8,#b0a090);border-radius:1px;box-shadow:2px 2px 8px rgba(0,0,0,.2)}
.ot-shelf__books{display:flex;align-items:flex-end;gap:2px;height:70px;padding:0 4px}
.ot-shelf__book{border-radius:1px 1px 0 0;flex:1}

/* Certificate on wall */
.ot-cert{position:absolute;top:12%;left:12%;width:80px;height:60px;background:rgba(255,255,255,.85);border:2px solid #c8b8a8;border-radius:2px;box-shadow:2px 2px 8px rgba(0,0,0,.12);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;padding:6px}
.ot-cert__line{height:2px;width:60%;background:rgba(44,62,80,.25);border-radius:1px}
.ot-cert__line--short{width:40%}
.ot-cert__seal{width:14px;height:14px;background:radial-gradient(circle,var(--ot-amber),var(--ot-amber-d));border-radius:50%;margin-top:2px}

/* Particles */
.ot-particle{position:absolute;font-size:var(--sz);opacity:var(--op);color:var(--ot-teal);animation:ot-drift var(--dur)s ease-in-out var(--delay)s infinite alternate;pointer-events:none;will-change:transform}
@keyframes ot-drift{0%{transform:translateY(0) rotate(0deg)}100%{transform:translateY(-18px) rotate(12deg)}}

/* Dark overlay for text readability */
.ot-hero__overlay{position:absolute;inset:0;background:linear-gradient(90deg,rgba(30,45,60,.92) 0%,rgba(30,45,60,.75) 45%,rgba(30,45,60,.2) 70%,transparent 100%)}

/* Hero content */
.ot-hero__content{position:relative;z-index:10;padding:0 5%;max-width:560px}
.ot-hero__eyebrow{display:inline-block;background:rgba(46,139,122,.2);border:1px solid rgba(46,139,122,.5);color:var(--ot-teal);font-size:.7rem;font-weight:700;letter-spacing:.18em;text-transform:uppercase;padding:6px 16px;border-radius:2px;margin-bottom:24px;backdrop-filter:blur(4px)}
.ot-hero__title{font-family:var(--ot-ff-head);font-size:clamp(2.6rem,5.5vw,4.2rem);font-weight:300;line-height:1.1;color:#fff;margin-bottom:12px}
.ot-hero__title em{font-style:italic;color:var(--ot-teal)}
.ot-hero__subtitle{font-family:var(--ot-ff-head);font-size:clamp(1.1rem,2vw,1.4rem);font-weight:300;font-style:italic;color:rgba(255,255,255,.75);margin-bottom:24px}
.ot-hero__body{font-size:1rem;line-height:1.75;color:rgba(255,255,255,.82);margin-bottom:36px;max-width:480px}
.ot-hero__ctas{display:flex;flex-wrap:wrap;gap:12px}
.ot-hero__badges{display:flex;flex-wrap:wrap;gap:12px;margin-top:32px}
.ot-hero__badge{display:flex;align-items:center;gap:8px;font-size:.8rem;color:rgba(255,255,255,.75);background:rgba(255,255,255,.08);padding:8px 14px;border-radius:30px;border:1px solid rgba(255,255,255,.12);backdrop-filter:blur(4px)}
.ot-hero__badge-icon{font-size:1rem}

/* Trust bar */
.ot-trust{background:var(--ot-slate);padding:22px 0}
.ot-trust__inner{display:flex;flex-wrap:wrap;justify-content:center;gap:8px 28px}
.ot-trust__item{display:flex;align-items:center;gap:8px;font-size:.82rem;color:rgba(255,255,255,.75);white-space:nowrap}
.ot-trust__item::before{content:'✓';color:var(--ot-teal);font-weight:700;font-size:.9rem}

/* =========================================================
   SERVICES
   ========================================================= */
.ot-services{background:var(--ot-cream)}
.ot-services__grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:28px;margin-top:52px}
.ot-service-card{background:#fff;border-radius:var(--ot-radius);padding:32px 26px;border:1px solid rgba(44,62,80,.07);transition:all .3s;position:relative;overflow:hidden}
.ot-service-card::before{content:'';position:absolute;top:0;left:0;width:3px;height:100%;background:var(--ot-teal);transform:scaleY(0);transition:transform .3s}
.ot-service-card:hover{box-shadow:var(--ot-shadow);transform:translateY(-4px)}
.ot-service-card:hover::before{transform:scaleY(1)}
.ot-service-card__icon{font-size:2rem;margin-bottom:14px;display:block}
.ot-service-card__title{font-family:var(--ot-ff-head);font-size:1.25rem;font-weight:600;color:var(--ot-slate);margin-bottom:10px}
.ot-service-card__desc{font-size:.9rem;line-height:1.7;color:var(--ot-muted)}

/* =========================================================
   CONDITIONS
   ========================================================= */
.ot-conditions{background:#fff}
.ot-conditions__grid{display:grid;grid-template-columns:1fr 1fr;gap:48px;align-items:center;margin-top:52px}
.ot-conditions__visual{position:relative;height:380px;border-radius:var(--ot-radius);overflow:hidden;background:linear-gradient(135deg,var(--ot-stone),#ede5dc)}
.ot-body-map{position:relative;width:100%;height:100%;display:flex;align-items:center;justify-content:center}
.ot-body-figure{position:relative;display:flex;flex-direction:column;align-items:center;gap:4px}
.ot-body-figure__head{width:44px;height:50px;background:radial-gradient(circle at 40% 35%,#f0c890,#d4a060);border-radius:50% 50% 40% 40%}
.ot-body-figure__neck{width:16px;height:14px;background:linear-gradient(180deg,#d4a060,#c89050)}
.ot-body-figure__torso{width:68px;height:80px;background:linear-gradient(180deg,#d8e8f8,#c0d8f0);border-radius:8px}
.ot-body-figure__arms{position:absolute;top:60px;display:flex;gap:76px}
.ot-body-figure__arm{width:12px;height:64px;background:linear-gradient(180deg,#d4a060,#c89050);border-radius:6px}
.ot-body-figure__hips{width:72px;height:28px;background:linear-gradient(180deg,#6080a0,#4a6888);border-radius:4px}
.ot-body-figure__legs{display:flex;gap:10px}
.ot-body-figure__leg{width:24px;height:80px;background:linear-gradient(180deg,#4a6888,#3a5878);border-radius:4px 4px 6px 6px}
/* Hotspot dots */
.ot-hotspot{position:absolute;width:16px;height:16px;background:rgba(46,139,122,.6);border-radius:50%;border:2px solid var(--ot-teal);animation:ot-pulse 2.5s ease-in-out infinite}
@keyframes ot-pulse{0%,100%{transform:scale(1);opacity:1}50%{transform:scale(1.5);opacity:.5}}
.ot-conditions__tags{margin-top:20px}
.ot-conditions__tag{display:inline-block;background:var(--ot-stone);color:var(--ot-slate);font-size:.8rem;padding:5px 14px;border-radius:20px;margin:4px;transition:all .22s;cursor:default;border:1px solid rgba(44,62,80,.1)}
.ot-conditions__tag:hover{background:var(--ot-teal);color:#fff;border-color:var(--ot-teal)}

/* =========================================================
   APPROACH
   ========================================================= */
.ot-approach{background:var(--ot-slate);padding:90px 0}
.ot-approach .ot-eyebrow{color:var(--ot-amber)}
.ot-approach__grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:0;margin-top:52px;position:relative}
.ot-approach__grid::before{content:'';position:absolute;top:28px;left:10%;right:10%;height:2px;background:linear-gradient(90deg,transparent,rgba(255,255,255,.15),transparent)}
.ot-step{text-align:center;padding:32px 20px;position:relative}
.ot-step__num{width:56px;height:56px;border-radius:50%;background:rgba(46,139,122,.2);border:2px solid var(--ot-teal);color:var(--ot-teal);font-family:var(--ot-ff-head);font-size:1.2rem;font-weight:600;display:flex;align-items:center;justify-content:center;margin:0 auto 18px}
.ot-step__title{font-family:var(--ot-ff-head);font-size:1.1rem;font-weight:600;color:#fff;margin-bottom:10px}
.ot-step__desc{font-size:.85rem;line-height:1.65;color:rgba(255,255,255,.65)}

/* =========================================================
   GALLERY
   ========================================================= */
.ot-gallery{background:var(--ot-stone)}
.ot-gallery__grid{display:grid;grid-template-columns:repeat(3,1fr);grid-template-rows:220px 220px;gap:12px;margin-top:52px}
.ot-gallery__item{border-radius:var(--ot-radius);overflow:hidden;position:relative;cursor:pointer}
.ot-gallery__item:first-child{grid-column:span 2}
.ot-gallery__item:nth-child(5){grid-column:span 2}
.ot-gallery__art{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:1rem;color:rgba(255,255,255,.6);letter-spacing:.1em;text-transform:uppercase;font-family:var(--ot-ff-head);font-style:italic;position:relative;overflow:hidden}
.ot-gallery__art::before{content:'';position:absolute;inset:0;background:inherit;filter:brightness(.7);transition:filter .4s}
.ot-gallery__item:hover .ot-gallery__art::before{filter:brightness(.5)}
.ot-gallery__label{position:relative;z-index:1;background:rgba(0,0,0,.35);padding:8px 18px;border-radius:3px;font-size:.8rem;letter-spacing:.08em}

/* =========================================================
   COUNTERS
   ========================================================= */
.ot-counters{background:linear-gradient(135deg,var(--ot-teal),var(--ot-teal-d));padding:80px 0}
.ot-counters__grid{display:grid;grid-template-columns:repeat(4,1fr);gap:40px;text-align:center}
.ot-counter__val{font-family:var(--ot-ff-head);font-size:clamp(2.4rem,4vw,3.5rem);font-weight:600;color:#fff;line-height:1}
.ot-counter__label{font-size:.8rem;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.75);margin-top:8px}

/* =========================================================
   ABOUT
   ========================================================= */
.ot-about{background:#fff}
.ot-about__grid{display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:center}
.ot-about__visual{position:relative}
.ot-portrait{width:100%;aspect-ratio:3/4;max-width:380px;background:linear-gradient(160deg,var(--ot-stone),#ede5dc);border-radius:var(--ot-radius);position:relative;overflow:hidden;box-shadow:var(--ot-shadow)}
.ot-portrait__figure{position:absolute;bottom:0;left:50%;transform:translateX(-50%);width:70%;height:85%}
.ot-portrait__fig-head{width:54px;height:60px;background:radial-gradient(circle at 40% 35%,#f0c890,#d4a060);border-radius:50% 50% 40% 40%;margin:0 auto 4px}
.ot-portrait__fig-body{width:100%;height:calc(100% - 70px);background:linear-gradient(180deg,#fff,#f4efe9);border-radius:8px 8px 0 0;position:relative}
.ot-portrait__fig-body::before{content:'';position:absolute;top:10px;left:50%;transform:translateX(-50%);width:60%;height:50%;background:var(--ot-teal);border-radius:4px;opacity:.9}
.ot-portrait__badge{position:absolute;bottom:20px;right:-16px;background:#fff;border-radius:var(--ot-radius);padding:14px 18px;box-shadow:var(--ot-shadow);text-align:center;min-width:120px}
.ot-portrait__badge-val{font-family:var(--ot-ff-head);font-size:1.8rem;font-weight:600;color:var(--ot-teal);line-height:1}
.ot-portrait__badge-label{font-size:.72rem;letter-spacing:.06em;color:var(--ot-muted);text-transform:uppercase;margin-top:4px}
.ot-about__content{}
.ot-about__creds{display:flex;flex-wrap:wrap;gap:10px;margin:24px 0}
.ot-cred{display:flex;align-items:center;gap:6px;font-size:.8rem;font-weight:700;letter-spacing:.04em;color:var(--ot-teal);background:rgba(46,139,122,.08);padding:6px 14px;border-radius:20px;border:1px solid rgba(46,139,122,.2)}
.ot-about__bio{font-size:.95rem;line-height:1.8;color:var(--ot-muted);margin-bottom:24px}
.ot-about__quote{font-family:var(--ot-ff-head);font-size:1.2rem;font-style:italic;color:var(--ot-slate);border-left:3px solid var(--ot-teal);padding-left:20px;margin:28px 0}

/* =========================================================
   PACKAGES
   ========================================================= */
.ot-packages{background:var(--ot-cream)}
.ot-packages__grid{display:grid;grid-template-columns:repeat(3,1fr);gap:28px;margin-top:52px}
.ot-pkg{background:#fff;border-radius:var(--ot-radius);padding:36px 28px;border:2px solid rgba(44,62,80,.08);transition:all .3s;position:relative}
.ot-pkg--featured{border-color:var(--ot-teal);background:linear-gradient(180deg,rgba(46,139,122,.04),#fff)}
.ot-pkg--featured::before{content:'Most Popular';position:absolute;top:-14px;left:50%;transform:translateX(-50%);background:var(--ot-teal);color:#fff;font-size:.7rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;padding:4px 16px;border-radius:20px;white-space:nowrap}
.ot-pkg__name{font-family:var(--ot-ff-head);font-size:1.3rem;font-weight:600;color:var(--ot-slate);margin-bottom:4px}
.ot-pkg__sub{font-size:.8rem;color:var(--ot-muted);margin-bottom:20px}
.ot-pkg__price{font-family:var(--ot-ff-head);font-size:2.4rem;font-weight:600;color:var(--ot-teal);margin-bottom:24px;line-height:1}
.ot-pkg__list{display:flex;flex-direction:column;gap:10px;margin-bottom:28px}
.ot-pkg__list li{display:flex;align-items:flex-start;gap:8px;font-size:.88rem;color:var(--ot-text);line-height:1.5}
.ot-pkg__list li::before{content:'✓';color:var(--ot-teal);font-weight:700;flex-shrink:0;margin-top:1px}

/* =========================================================
   TESTIMONIALS
   ========================================================= */
.ot-testimonials{background:#fff}
.ot-testi-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:28px;margin-top:52px}
.ot-testi{background:var(--ot-stone);border-radius:var(--ot-radius);padding:32px 28px;border-top:3px solid var(--ot-amber);position:relative}
.ot-testi__stars{color:var(--ot-amber);font-size:1rem;letter-spacing:2px;margin-bottom:14px}
.ot-testi__text{font-family:var(--ot-ff-head);font-size:1.05rem;font-style:italic;line-height:1.7;color:var(--ot-slate);margin-bottom:20px}
.ot-testi__author{font-size:.8rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--ot-muted)}
.ot-testi__loc{font-size:.78rem;color:var(--ot-muted);margin-top:2px}

/* =========================================================
   BOOKING FORM
   ========================================================= */
.ot-booking{background:linear-gradient(135deg,var(--ot-slate),#1a2b3a);padding:90px 0}
.ot-booking .ot-eyebrow{color:var(--ot-amber)}
.ot-booking .ot-heading--light{color:#fff}
.ot-booking__grid{display:grid;grid-template-columns:1fr 1.6fr;gap:64px;align-items:start;margin-top:52px}
.ot-booking__info{}
.ot-booking__info-item{display:flex;align-items:flex-start;gap:14px;margin-bottom:24px}
.ot-booking__info-icon{font-size:1.4rem;flex-shrink:0;margin-top:2px}
.ot-booking__info-title{font-size:.88rem;font-weight:700;color:#fff;margin-bottom:4px;letter-spacing:.04em}
.ot-booking__info-text{font-size:.85rem;line-height:1.6;color:rgba(255,255,255,.65)}
.ot-form{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:var(--ot-radius);padding:40px 36px;backdrop-filter:blur(8px)}
.ot-form__row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.ot-form__group{margin-bottom:18px;display:flex;flex-direction:column;gap:6px}
.ot-form__group label{font-size:.78rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:rgba(255,255,255,.75)}
.ot-form__group input,
.ot-form__group select,
.ot-form__group textarea{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.18);border-radius:4px;padding:11px 14px;font-family:var(--ot-ff-body);font-size:.9rem;color:#fff;outline:none;transition:border-color .25s;width:100%}
.ot-form__group input::placeholder,
.ot-form__group textarea::placeholder{color:rgba(255,255,255,.4)}
.ot-form__group input:focus,
.ot-form__group select:focus,
.ot-form__group textarea:focus{border-color:var(--ot-teal);background:rgba(255,255,255,.12)}
.ot-form__group select option{background:#1a2b3a;color:#fff}
.ot-form__group textarea{resize:vertical;min-height:100px}
.ot-form__submit{width:100%;padding:15px;background:var(--ot-teal);border:none;border-radius:4px;font-family:var(--ot-ff-body);font-size:1rem;font-weight:700;letter-spacing:.06em;color:#fff;cursor:pointer;transition:all .25s;margin-top:8px}
.ot-form__submit:hover{background:var(--ot-teal-d);transform:translateY(-2px)}
.ot-form__consent{font-size:.75rem;color:rgba(255,255,255,.5);margin-top:12px;line-height:1.6;text-align:center}

/* =========================================================
   FOOTER
   ========================================================= */
.ot-footer{background:#0e1a26;padding:28px 0}
.ot-footer__inner{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:16px}
.ot-footer__copy{font-size:.8rem;color:rgba(255,255,255,.45)}
.ot-footer__links{display:flex;gap:20px}
.ot-footer__links a{font-size:.8rem;color:rgba(255,255,255,.45);transition:color .2s}
.ot-footer__links a:hover{color:var(--ot-teal)}

/* =========================================================
   RESPONSIVE
   ========================================================= */
@media(max-width:900px){
    .ot-conditions__grid,.ot-about__grid,.ot-booking__grid{grid-template-columns:1fr}
    .ot-packages__grid,.ot-testi-grid{grid-template-columns:1fr}
    .ot-counters__grid{grid-template-columns:repeat(2,1fr)}
    .ot-gallery__grid{grid-template-columns:1fr 1fr}
    .ot-gallery__item:first-child,.ot-gallery__item:nth-child(5){grid-column:span 1}
    .ot-approach__grid::before{display:none}
}
@media(max-width:600px){
    .ot-section{padding:60px 0}
    .ot-form__row{grid-template-columns:1fr}
    .ot-counters__grid{grid-template-columns:repeat(2,1fr)}
    .ot-hero__content{padding:0 6%}
}
</style>
<?php get_header(); ?>
<div class="ot-page">
>

<!-- ═══════════════════════════════════════════════
     HERO
═══════════════════════════════════════════════ -->
<section class="ot-hero" id="ot-hero">

    <!-- Treatment room scene -->
    <div class="ot-room" aria-hidden="true">
        <div class="ot-room__wall"></div>
        <div class="ot-room__dado"></div>
        <div class="ot-room__panel"></div>

        <!-- Window -->
        <div class="ot-window"><div class="ot-window__light"></div></div>

        <!-- Certificate -->
        <div class="ot-cert">
            <div class="ot-cert__line"></div>
            <div class="ot-cert__line ot-cert__line--short"></div>
            <div class="ot-cert__line"></div>
            <div class="ot-cert__seal"></div>
        </div>

        <!-- Shelf with books -->
        <div class="ot-shelf">
            <div class="ot-shelf__books">
                <?php
                $book_colors = ['#2E8B7A','#2C3E50','#D4925A','#8B6BA0','#4a8fba','#5a9a6a','#c85a40'];
                for ( $i = 0; $i < 7; $i++ ) :
                    $bc = $book_colors[$i % count($book_colors)];
                    $bw = rand(12,18);
                ?>
                <div class="ot-shelf__book" style="background:<?php echo esc_attr($bc); ?>;width:<?php echo $bw; ?>px"></div>
                <?php endfor; ?>
            </div>
            <div class="ot-shelf__board"></div>
        </div>

        <!-- Anatomy skeleton sketch -->
        <div class="ot-skeleton">
            <div class="ot-skeleton__spine"></div>
            <?php
            $rib_tops = [10,18,26,34,42,50,58];
            $rib_widths = [28,32,34,34,30,26,20];
            foreach ($rib_tops as $idx => $top):
                $w = $rib_widths[$idx];
            ?>
            <div class="ot-skeleton__rib" style="top:<?php echo $top; ?>%;width:<?php echo $w; ?>px;left:calc(50% - <?php echo $w/2; ?>px)"></div>
            <div class="ot-skeleton__rib" style="top:<?php echo $top; ?>%;width:<?php echo $w; ?>px;right:calc(50% - <?php echo $w/2; ?>px);left:auto"></div>
            <?php endforeach; ?>
        </div>

        <!-- Floor -->
        <div class="ot-room__skirting"></div>
        <div class="ot-room__floor"></div>

        <!-- Treatment table -->
        <div class="ot-table" aria-hidden="true">
            <div class="ot-table__legs">
                <div class="ot-table__leg"></div>
                <div class="ot-table__leg"></div>
            </div>
            <div class="ot-table__frame"></div>
            <div class="ot-table__surface"></div>
        </div>

        <!-- Patient on table -->
        <div class="ot-patient" aria-hidden="true">
            <div class="ot-patient__body">
                <div class="ot-patient__head"></div>
                <div class="ot-patient__torso"></div>
                <div class="ot-patient__legs"></div>
            </div>
        </div>

        <!-- Therapist figure -->
        <div class="ot-therapist" aria-hidden="true">
            <div class="ot-therapist__head"></div>
            <div class="ot-therapist__body">
                <div class="ot-therapist__arm"></div>
            </div>
        </div>

        <!-- Floating anatomy particles -->
        <?php foreach ( $ot_particles as $p ) : ?>
        <div class="ot-particle"
             style="left:<?php echo $p['x']; ?>%;top:<?php echo $p['y']; ?>%;--sz:<?php echo $p['size']; ?>px;--op:<?php echo $p['op']; ?>;--dur:<?php echo $p['dur']; ?>;--delay:<?php echo $p['delay']; ?>"
             data-depth="<?php echo $p['depth']; ?>"><?php echo $p['char']; ?></div>
        <?php endforeach; ?>
    </div>

    <!-- Dark overlay -->
    <div class="ot-hero__overlay" aria-hidden="true"></div>

    <!-- Hero content -->
    <div class="ot-container">
        <div class="ot-hero__content">
            <span class="ot-hero__eyebrow">Registered Osteopath · GOsC Registered</span>
            <h1 class="ot-hero__title">
                Restore Balance.<br>
                <em>Relieve Pain.</em><br>
                Move Freely.
            </h1>
            <p class="ot-hero__subtitle">Evidence-based osteopathic care for the whole body</p>
            <p class="ot-hero__body">
                Struggling with back pain, joint problems or sports injuries? Our experienced osteopaths use gentle, hands-on techniques to identify the root cause of your pain and restore natural movement — so you can get back to living life fully.
            </p>
            <div class="ot-hero__ctas">
                <a href="#ot-booking" class="ot-btn ot-btn--primary">Book a Consultation</a>
                <a href="#ot-services" class="ot-btn ot-btn--outline">Our Treatments</a>
            </div>
            <div class="ot-hero__badges">
                <span class="ot-hero__badge"><span class="ot-hero__badge-icon">🏅</span> GOsC Registered</span>
                <span class="ot-hero__badge"><span class="ot-hero__badge-icon">⭐</span> 5.0 · 300+ Reviews</span>
                <span class="ot-hero__badge"><span class="ot-hero__badge-icon">📋</span> NHS Referred</span>
            </div>
        </div>
    </div>
</section>

<!-- Trust bar -->
<div class="ot-trust">
    <div class="ot-container">
        <div class="ot-trust__inner">
            <?php
            $ot_trust = ['GOsC Registered Practitioner','Insurance & NHS Accepted','Same-Week Appointments Available','Full Patient Confidentiality','Child & Pregnancy Specialists','Evening & Weekend Clinics'];
            foreach ($ot_trust as $ti): ?>
            <span class="ot-trust__item"><?php echo esc_html($ti); ?></span>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ═══════════════════════════════════════════════
     SERVICES
═══════════════════════════════════════════════ -->
<section class="ot-section ot-services" id="ot-services">
    <div class="ot-container">
        <div class="ot-center">
            <span class="ot-eyebrow">What We Treat</span>
            <h2 class="ot-heading">Osteopathic Treatments</h2>
            <p class="ot-lead">From spinal pain to sports injuries and specialist paediatric care — our registered osteopaths provide safe, effective treatment for patients of all ages.</p>
        </div>
        <div class="ot-services__grid">
            <?php foreach ( $ot_services as $svc ) : ?>
            <article class="ot-service-card">
                <span class="ot-service-card__icon"><?php echo esc_html( $svc['icon'] ); ?></span>
                <h3 class="ot-service-card__title"><?php echo esc_html( $svc['title'] ); ?></h3>
                <p class="ot-service-card__desc"><?php echo esc_html( $svc['desc'] ); ?></p>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     CONDITIONS
═══════════════════════════════════════════════ -->
<section class="ot-section ot-conditions" id="ot-conditions">
    <div class="ot-container">
        <div class="ot-conditions__grid">
            <div>
                <span class="ot-eyebrow">Conditions Treated</span>
                <h2 class="ot-heading">We Help With</h2>
                <p class="ot-lead" style="margin-bottom:28px">Osteopathy addresses a wide range of musculoskeletal conditions and general health complaints. If you're not sure whether osteopathy can help, please get in touch — we're happy to advise.</p>
                <div class="ot-conditions__tags">
                    <?php foreach ( $ot_conditions as $cond ) : ?>
                    <span class="ot-conditions__tag"><?php echo esc_html( $cond ); ?></span>
                    <?php endforeach; ?>
                </div>
                <div style="margin-top:32px">
                    <a href="#ot-booking" class="ot-btn ot-btn--primary">Book a Consultation →</a>
                </div>
            </div>
            <div>
                <div class="ot-conditions__visual">
                    <div class="ot-body-map">
                        <div class="ot-body-figure">
                            <div class="ot-body-figure__head"></div>
                            <div class="ot-body-figure__neck"></div>
                            <div class="ot-body-figure__torso" style="position:relative">
                                <div class="ot-body-figure__arms">
                                    <div class="ot-body-figure__arm"></div>
                                    <div class="ot-body-figure__arm"></div>
                                </div>
                            </div>
                            <div class="ot-body-figure__hips"></div>
                            <div class="ot-body-figure__legs">
                                <div class="ot-body-figure__leg"></div>
                                <div class="ot-body-figure__leg"></div>
                            </div>
                        </div>
                        <!-- Hotspot pain indicators -->
                        <div class="ot-hotspot" style="top:28%;left:48%" title="Neck"></div>
                        <div class="ot-hotspot" style="top:38%;left:45%" title="Shoulder"></div>
                        <div class="ot-hotspot" style="top:48%;left:50%" title="Lower Back" ></div>
                        <div class="ot-hotspot" style="top:60%;left:46%" title="Hip"></div>
                        <div class="ot-hotspot" style="top:72%;left:52%" title="Knee"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     APPROACH
═══════════════════════════════════════════════ -->
<section class="ot-approach" id="ot-approach">
    <div class="ot-container">
        <div class="ot-center">
            <span class="ot-eyebrow">Our Method</span>
            <h2 class="ot-heading ot-heading--light">Your Treatment Journey</h2>
            <p class="ot-lead" style="color:rgba(255,255,255,.7);margin-inline:auto">A structured, patient-centred approach to diagnosing, treating and preventing pain — designed to deliver lasting results, not just temporary relief.</p>
        </div>
        <div class="ot-approach__grid">
            <?php foreach ( $ot_steps as $step ) : ?>
            <div class="ot-step">
                <div class="ot-step__num"><?php echo esc_html( $step['num'] ); ?></div>
                <h3 class="ot-step__title"><?php echo esc_html( $step['title'] ); ?></h3>
                <p class="ot-step__desc"><?php echo esc_html( $step['desc'] ); ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     GALLERY
═══════════════════════════════════════════════ -->
<section class="ot-section ot-gallery" id="ot-gallery">
    <div class="ot-container">
        <div class="ot-center">
            <span class="ot-eyebrow">Our Clinic</span>
            <h2 class="ot-heading">A Space to Heal</h2>
        </div>
        <div class="ot-gallery__grid">
            <?php foreach ( $ot_gallery as $gitem ) : ?>
            <div class="ot-gallery__item">
                <div class="ot-gallery__art" style="background:linear-gradient(135deg,<?php echo esc_attr($gitem['c1']); ?>,<?php echo esc_attr($gitem['c2']); ?>)">
                    <span class="ot-gallery__label"><?php echo esc_html($gitem['label']); ?></span>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     COUNTERS
═══════════════════════════════════════════════ -->
<section class="ot-counters" aria-label="Practice statistics">
    <div class="ot-container">
        <div class="ot-counters__grid">
            <div class="ot-counter">
                <div class="ot-counter__val" data-target="18" data-suffix="yrs">0</div>
                <div class="ot-counter__label">Clinical Experience</div>
            </div>
            <div class="ot-counter">
                <div class="ot-counter__val" data-target="4500" data-suffix="+">0</div>
                <div class="ot-counter__label">Patients Treated</div>
            </div>
            <div class="ot-counter">
                <div class="ot-counter__val" data-target="4.9" data-suffix="★" data-float="1">0</div>
                <div class="ot-counter__label">Average Rating</div>
            </div>
            <div class="ot-counter">
                <div class="ot-counter__val" data-target="94" data-suffix="%">0</div>
                <div class="ot-counter__label">Patients Pain-Free</div>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     ABOUT
═══════════════════════════════════════════════ -->
<section class="ot-section ot-about" id="ot-about">
    <div class="ot-container">
        <div class="ot-about__grid">
            <div class="ot-about__visual">
                <div class="ot-portrait">
                    <div class="ot-portrait__figure">
                        <div class="ot-portrait__fig-head"></div>
                        <div class="ot-portrait__fig-body"></div>
                    </div>
                </div>
                <div class="ot-portrait__badge">
                    <div class="ot-portrait__badge-val">18</div>
                    <div class="ot-portrait__badge-label">Years' Experience</div>
                </div>
            </div>
            <div class="ot-about__content">
                <span class="ot-eyebrow">Meet Your Practitioner</span>
                <h2 class="ot-heading">Dr. Sarah Mitchell<br><small style="font-size:.6em;color:var(--ot-muted)">BSc (Hons) Osteopathy · GOsC Registered</small></h2>
                <div class="ot-about__creds">
                    <span class="ot-cred">🏅 GOsC Registered</span>
                    <span class="ot-cred">🎓 BSc Osteopathy</span>
                    <span class="ot-cred">👶 Paediatric Specialist</span>
                    <span class="ot-cred">🤰 Pregnancy Care</span>
                </div>
                <p class="ot-about__bio">
                    With over 18 years of clinical experience, Dr. Sarah Mitchell has helped thousands of patients find lasting relief from pain and injury. Trained at the British School of Osteopathy and holding a postgraduate diploma in paediatric osteopathy, Sarah brings exceptional depth of knowledge to every consultation.
                </p>
                <p class="ot-about__bio">
                    Her approach combines classical osteopathic techniques with the latest evidence-based practices, ensuring each patient receives the most effective and appropriate care for their individual needs.
                </p>
                <blockquote class="ot-about__quote">
                    "I believe in treating the whole person, not just the symptom. When we address the underlying cause, the body has a remarkable ability to heal itself."
                </blockquote>
                <a href="#ot-booking" class="ot-btn ot-btn--dark">Book with Dr. Mitchell →</a>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     PACKAGES
═══════════════════════════════════════════════ -->
<section class="ot-section ot-packages" id="ot-packages">
    <div class="ot-container">
        <div class="ot-center">
            <span class="ot-eyebrow">Treatment Plans</span>
            <h2 class="ot-heading">Choose Your Package</h2>
            <p class="ot-lead">Flexible options to suit your schedule and budget. All packages include a personalised treatment plan and home exercise programme.</p>
        </div>
        <div class="ot-packages__grid">
            <?php foreach ( $ot_packages as $pkg ) : ?>
            <div class="ot-pkg<?php echo $pkg['featured'] ? ' ot-pkg--featured' : ''; ?>">
                <div class="ot-pkg__name"><?php echo esc_html($pkg['name']); ?></div>
                <div class="ot-pkg__sub"><?php echo esc_html($pkg['sub']); ?></div>
                <div class="ot-pkg__price"><?php echo esc_html($pkg['price']); ?></div>
                <ul class="ot-pkg__list">
                    <?php foreach ($pkg['items'] as $item): ?>
                    <li><?php echo esc_html($item); ?></li>
                    <?php endforeach; ?>
                </ul>
                <a href="#ot-booking" class="ot-btn ot-btn--<?php echo $pkg['featured'] ? 'primary' : 'dark'; ?>" style="width:100%;justify-content:center">Book Now</a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     TESTIMONIALS
═══════════════════════════════════════════════ -->
<section class="ot-section ot-testimonials" id="ot-testimonials">
    <div class="ot-container">
        <div class="ot-center">
            <span class="ot-eyebrow">Patient Stories</span>
            <h2 class="ot-heading">Real Results, Real Lives</h2>
        </div>
        <div class="ot-testi-grid">
            <?php foreach ( $ot_testimonials as $testi ) : ?>
            <div class="ot-testi">
                <div class="ot-testi__stars"><?php echo str_repeat('★', $testi['stars']); ?></div>
                <p class="ot-testi__text">"<?php echo esc_html($testi['text']); ?>"</p>
                <div class="ot-testi__author"><?php echo esc_html($testi['name']); ?></div>
                <div class="ot-testi__loc"><?php echo esc_html($testi['loc']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     BOOKING
═══════════════════════════════════════════════ -->
<section class="ot-booking" id="ot-booking">
    <div class="ot-container">
        <div class="ot-center">
            <span class="ot-eyebrow">Book an Appointment</span>
            <h2 class="ot-heading ot-heading--light">Start Your Recovery Today</h2>
            <p class="ot-lead" style="color:rgba(255,255,255,.7);margin-inline:auto">Take the first step towards a pain-free life. Same-week appointments available, with evening and weekend slots to suit your schedule.</p>
        </div>
        <div class="ot-booking__grid">
            <div class="ot-booking__info">
                <div class="ot-booking__info-item">
                    <span class="ot-booking__info-icon">📍</span>
                    <div>
                        <div class="ot-booking__info-title">Clinic Location</div>
                        <div class="ot-booking__info-text">123 Harley Street, London W1G 9QD<br>Easy access by tube & bus</div>
                    </div>
                </div>
                <div class="ot-booking__info-item">
                    <span class="ot-booking__info-icon">🕐</span>
                    <div>
                        <div class="ot-booking__info-title">Clinic Hours</div>
                        <div class="ot-booking__info-text">Mon–Fri: 8am – 8pm<br>Sat: 9am – 4pm · Sun: 10am – 2pm</div>
                    </div>
                </div>
                <div class="ot-booking__info-item">
                    <span class="ot-booking__info-icon">💳</span>
                    <div>
                        <div class="ot-booking__info-title">Insurance & Payment</div>
                        <div class="ot-booking__info-text">All major insurers accepted including BUPA, AXA & Cigna. Interest-free payment plans available.</div>
                    </div>
                </div>
                <div class="ot-booking__info-item">
                    <span class="ot-booking__info-icon">📞</span>
                    <div>
                        <div class="ot-booking__info-title">Call the Clinic</div>
                        <div class="ot-booking__info-text">020 7946 0000<br>Mon–Fri 9am–6pm</div>
                    </div>
                </div>
            </div>
            <div>
                <form class="ot-form" method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
                    <?php wp_nonce_field('tf_ot_booking','tf_ot_nonce'); ?>
                    <input type="hidden" name="action" value="tf_ot_booking">
                    <div class="ot-form__row">
                        <div class="ot-form__group">
                            <label for="ot-name">Full Name *</label>
                            <input type="text" id="ot-name" name="ot_name" required placeholder="Your full name">
                        </div>
                        <div class="ot-form__group">
                            <label for="ot-email">Email Address *</label>
                            <input type="email" id="ot-email" name="ot_email" required placeholder="your@email.com">
                        </div>
                    </div>
                    <div class="ot-form__row">
                        <div class="ot-form__group">
                            <label for="ot-phone">Phone Number *</label>
                            <input type="tel" id="ot-phone" name="ot_phone" required placeholder="07700 900000">
                        </div>
                        <div class="ot-form__group">
                            <label for="ot-dob">Date of Birth</label>
                            <input type="date" id="ot-dob" name="ot_dob">
                        </div>
                    </div>
                    <div class="ot-form__group">
                        <label for="ot-treatment">Treatment Type *</label>
                        <select id="ot-treatment" name="ot_treatment" required>
                            <option value="">Select treatment…</option>
                            <option>Spinal Treatment</option>
                            <option>Sports Injury</option>
                            <option>Pregnancy Care</option>
                            <option>Paediatric Osteopathy</option>
                            <option>Cranial Osteopathy</option>
                            <option>TMJ / Jaw Pain</option>
                            <option>Joint Mobilisation</option>
                            <option>General Assessment</option>
                        </select>
                    </div>
                    <div class="ot-form__row">
                        <div class="ot-form__group">
                            <label for="ot-referral">Referral Source</label>
                            <select id="ot-referral" name="ot_referral">
                                <option value="">How did you find us?</option>
                                <option>GP Referral</option>
                                <option>NHS Direct</option>
                                <option>Word of Mouth</option>
                                <option>Google Search</option>
                                <option>Insurance Provider</option>
                                <option>Other</option>
                            </select>
                        </div>
                        <div class="ot-form__group">
                            <label for="ot-date">Preferred Date</label>
                            <input type="date" id="ot-date" name="ot_date">
                        </div>
                    </div>
                    <div class="ot-form__group">
                        <label for="ot-concern">Main Concern / Symptoms *</label>
                        <textarea id="ot-concern" name="ot_concern" required placeholder="Please describe your main symptoms, how long you've had them, and any previous treatment…"></textarea>
                    </div>
                    <button type="submit" class="ot-form__submit">Request Appointment →</button>
                    <p class="ot-form__consent">By submitting this form you agree to our privacy policy. Your information will only be used to contact you about your appointment.</p>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     FOOTER
═══════════════════════════════════════════════ -->
<footer class="ot-footer">
    <div class="ot-container">
        <div class="ot-footer__inner">
            <p class="ot-footer__copy">&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All rights reserved. GOsC Registered.</p>
            <nav class="ot-footer__links" aria-label="Footer navigation">
                <a href="<?php echo esc_url(home_url('/privacy-policy')); ?>">Privacy Policy</a>
                <a href="<?php echo esc_url(home_url('/terms')); ?>">Terms</a>
                <a href="<?php echo esc_url(home_url('/accessibility')); ?>">Accessibility</a>
            </nav>
        </div>
    </div>
</footer>


<script>
(function(){
    /* ── Animated Counters ── */
    const counters = document.querySelectorAll('.ot-counter__val[data-target]');
    const easeOut = t => 1 - Math.pow(1 - t, 3);
    const io = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (!entry.isIntersecting) return;
            const el = entry.target;
            const target = parseFloat(el.dataset.target);
            const suffix = el.dataset.suffix || '';
            const isFloat = el.dataset.float === '1';
            if (isNaN(target)) return;
            const dur = 1800;
            let start = null;
            function tick(ts) {
                if (!start) start = ts;
                const prog = Math.min((ts - start) / dur, 1);
                const val = target * easeOut(prog);
                el.textContent = (isFloat ? val.toFixed(1) : Math.round(val)) + suffix;
                if (prog < 1) requestAnimationFrame(tick);
            }
            requestAnimationFrame(tick);
            io.unobserve(el);
        });
    }, { threshold: 0.4 });
    counters.forEach(c => io.observe(c));

    /* ── Mouse parallax on floating particles ── */
    const particles = document.querySelectorAll('.ot-particle');
    document.getElementById('ot-hero')?.addEventListener('mousemove', e => {
        const rect = e.currentTarget.getBoundingClientRect();
        const dx = (e.clientX - rect.width / 2) / rect.width;
        const dy = (e.clientY - rect.height / 2) / rect.height;
        particles.forEach(p => {
            const d = parseFloat(p.dataset.depth) || 20;
            p.style.transform = `translate(${dx * d}px, ${dy * d}px)`;
        });
    });
})();
</script>
</body>
</html>
</div><!-- .ot-page -->
<?php get_footer(); ?>
