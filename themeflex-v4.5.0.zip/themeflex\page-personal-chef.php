<?php
/**
 * Template Name: TF — Personal Chef
 * Description:   Premium personal chef / private dining landing page template.
 * Namespace:     --pc-*
 * Google Fonts:  Italiana + DM Sans
 * Palette:       Truffle #2C1A0E / Gold #C8922A / Cream #FBF8F2 / Sage #7B9E87 / Smoke #F5F2EE
 * Hero scene:    CSS kitchen with chef figure, copper pots, flames, steaming dishes, herb garden
 */

defined('ABSPATH') || exit;
get_header();
?>

<!-- ============================================================
     PERSONAL CHEF — PREMIUM TEMPLATE
     ============================================================ -->
<div class="pc-wrap">

<!-- ── GOOGLE FONTS ─────────────────────────────────────────── -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Italiana&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400&display=swap" rel="stylesheet">

<style>
/* ── DESIGN TOKENS ──────────────────────────────────────────── */
:root{
  --pc-truffle:#2C1A0E;
  --pc-truffle-lt:#3D2415;
  --pc-truffle-mid:#4E3020;
  --pc-gold:#C8922A;
  --pc-gold-lt:#E0B060;
  --pc-gold-dk:#A67220;
  --pc-cream:#FBF8F2;
  --pc-smoke:#F5F2EE;
  --pc-smoke-dk:#EAE5DE;
  --pc-sage:#7B9E87;
  --pc-sage-dk:#5A7A66;
  --pc-white:#FFFFFF;
  --pc-slate:#5A5045;
  --pc-f-display:'Italiana',Georgia,serif;
  --pc-f-body:'DM Sans',sans-serif;
  --pc-r:4px;
  --pc-r-lg:12px;
  --pc-sh:0 8px 32px rgba(44,26,14,.2);
  --pc-sh-gold:0 4px 20px rgba(200,146,42,.3)
}

/* ── BASE ───────────────────────────────────────────────────── */
.pc-wrap{font-family:var(--pc-f-body);color:var(--pc-truffle);overflow-x:hidden}
.pc-wrap *,
.pc-wrap *::before,
.pc-wrap *::after{box-sizing:border-box;margin:0;padding:0}
.pc-wrap a{color:inherit;text-decoration:none}

/* ── LAYOUT ─────────────────────────────────────────────────── */
.pc-container{max-width:1180px;margin:0 auto;padding:0 24px}
.pc-section{padding:96px 0}
.pc-section--truffle{background:var(--pc-truffle)}
.pc-section--truffle-lt{background:var(--pc-truffle-lt)}
.pc-section--cream{background:var(--pc-cream)}
.pc-section--smoke{background:var(--pc-smoke)}
.pc-section--smoke-dk{background:var(--pc-smoke-dk)}
.pc-section--white{background:var(--pc-white)}

/* ── TYPOGRAPHY ─────────────────────────────────────────────── */
.pc-eyebrow{
  font-family:var(--pc-f-body);font-size:.7rem;
  letter-spacing:.25em;text-transform:uppercase;font-weight:500;
  color:var(--pc-gold);margin-bottom:14px
}
.pc-eyebrow--sage{color:var(--pc-sage)}
.pc-eyebrow--dark{color:var(--pc-slate)}
.pc-h1{
  font-family:var(--pc-f-display);
  font-size:clamp(3rem,7vw,6rem);
  line-height:1.05;color:var(--pc-white)
}
.pc-h1 em{color:var(--pc-gold-lt)}
.pc-h2{
  font-family:var(--pc-f-display);
  font-size:clamp(2.2rem,5vw,4rem);
  line-height:1.1
}
.pc-h3{
  font-family:var(--pc-f-display);font-size:1.6rem
}
.pc-lead{font-size:1.05rem;line-height:1.8;font-weight:300}
.pc-sub{font-size:.92rem;line-height:1.75}

/* gold leaf rule */
.pc-rule{
  display:flex;align-items:center;gap:14px;margin:20px 0
}
.pc-rule::before,
.pc-rule::after{
  content:'';flex:1;height:1px;background:linear-gradient(to right,transparent,var(--pc-gold))
}
.pc-rule::after{background:linear-gradient(to left,transparent,var(--pc-gold))}
.pc-rule-icon{color:var(--pc-gold);font-size:.85rem;flex-shrink:0}

/* ── BUTTONS ────────────────────────────────────────────────── */
.pc-btn{
  display:inline-flex;align-items:center;gap:8px;
  font-family:var(--pc-f-body);font-size:.82rem;font-weight:500;
  letter-spacing:.12em;text-transform:uppercase;
  padding:14px 34px;
  border:1px solid transparent;cursor:pointer;
  transition:all .3s;white-space:nowrap;border-radius:0
}
.pc-btn--gold{
  background:var(--pc-gold);color:var(--pc-truffle);border-color:var(--pc-gold);
  box-shadow:var(--pc-sh-gold)
}
.pc-btn--gold:hover{background:var(--pc-gold-dk);border-color:var(--pc-gold-dk);transform:translateY(-2px)}
.pc-btn--outline-white{
  background:transparent;color:var(--pc-white);border-color:rgba(255,255,255,.4)
}
.pc-btn--outline-white:hover{background:rgba(255,255,255,.08);border-color:var(--pc-white)}
.pc-btn--truffle{
  background:var(--pc-truffle);color:var(--pc-white);border-color:var(--pc-truffle)
}
.pc-btn--truffle:hover{background:var(--pc-truffle-lt);transform:translateY(-2px)}

/* ── HERO ───────────────────────────────────────────────────── */
.pc-hero{
  min-height:100vh;position:relative;overflow:hidden;
  background:linear-gradient(160deg,var(--pc-truffle) 0%,var(--pc-truffle-lt) 45%,var(--pc-truffle-mid) 75%,#1a0e06 100%);
  display:flex;align-items:center;padding:120px 0 80px
}

/* subtle texture */
.pc-hero::before{
  content:'';position:absolute;inset:0;
  background-image:radial-gradient(circle,rgba(200,146,42,.05) 1px,transparent 1px);
  background-size:36px 36px;pointer-events:none
}

/* CSS KITCHEN SCENE */
.pc-hero-scene{
  position:absolute;right:0;top:0;bottom:0;width:520px;z-index:2
}
.pc-hero-scene::before{
  content:'';position:absolute;inset:0;left:-80px;
  background:linear-gradient(to right,var(--pc-truffle),transparent 60%);
  z-index:10;pointer-events:none
}

/* kitchen counter */
.pc-counter{
  position:absolute;bottom:0;left:0;right:0;height:110px;
  background:linear-gradient(to bottom,#3d2a18,#2a1a0a);
  border-top:4px solid #6b4e2a
}
/* counter surface shine */
.pc-counter::before{
  content:'';position:absolute;top:4px;left:0;right:0;height:2px;
  background:linear-gradient(to right,transparent,rgba(200,146,42,.4),transparent)
}

/* range/stove */
.pc-range{
  position:absolute;bottom:110px;left:60px;width:220px;height:160px;
  background:linear-gradient(to bottom,#1a1a1a,#111);
  border:2px solid #333;border-radius:4px
}
/* range knobs row */
.pc-range::before{
  content:'';position:absolute;top:12px;left:16px;right:16px;height:12px;
  background:repeating-linear-gradient(to right,#555 0,#555 8px,transparent 8px,transparent 22px);
  border-radius:6px
}
/* burner rings */
.pc-burner{
  position:absolute;border-radius:50%;
  background:radial-gradient(circle,#2a2a2a 30%,#1a1a1a 50%,#444 100%);
  border:2px solid #555
}
.pc-burner:nth-child(3){width:52px;height:52px;top:36px;left:24px}
.pc-burner:nth-child(4){width:44px;height:44px;top:36px;right:24px}
.pc-burner:nth-child(5){width:48px;height:48px;bottom:28px;left:24px}
.pc-burner:nth-child(6){width:38px;height:38px;bottom:28px;right:28px}

/* flames */
@keyframes pc-flame{
  0%,100%{transform:scaleY(1) rotate(-3deg);opacity:.9}
  50%{transform:scaleY(1.3) rotate(3deg);opacity:1}
}
.pc-flame{
  position:absolute;border-radius:50% 50% 20% 20%;
  animation:pc-flame .6s ease-in-out infinite alternate
}
.pc-flame-outer{
  width:28px;height:36px;
  background:linear-gradient(to top,#FF6B00,#FF9500,#FFD700);
  filter:blur(1px)
}
.pc-flame-inner{
  width:14px;height:20px;top:10px;left:50%;transform:translateX(-50%);
  background:linear-gradient(to top,#FFF,#FFE066);
  filter:blur(1px);animation-delay:.1s
}

/* copper pots */
@keyframes pc-steam{
  0%{transform:translateY(0) scaleX(1);opacity:.8}
  100%{transform:translateY(-40px) scaleX(1.5);opacity:0}
}
.pc-pot{
  position:absolute;z-index:5
}
.pc-pot-body{
  border-radius:0 0 50% 50%;border-top:none;
  background:linear-gradient(135deg,#b5651d,#cd853f,#8B4513)
}
.pc-pot-lid{
  border-radius:50% 50% 0 0;
  background:linear-gradient(to bottom,#cd853f,#a0522d)
}
.pc-pot-lid::before{
  content:'';position:absolute;top:-8px;left:50%;transform:translateX(-50%);
  width:10px;height:8px;background:#8B4513;border-radius:4px
}
.pc-pot-handle-l,
.pc-pot-handle-r{
  position:absolute;top:50%;width:16px;height:8px;border-radius:4px;
  background:#8B4513;transform:translateY(-50%)
}
.pc-pot-handle-l{left:-14px}
.pc-pot-handle-r{right:-14px}
.pc-steam-puff{
  position:absolute;border-radius:50%;
  background:rgba(255,255,255,.7);
  animation:pc-steam 1.8s ease-out infinite
}

/* chef figure */
@keyframes pc-chef-stir{
  0%,100%{transform:rotate(-8deg)}
  50%{transform:rotate(8deg)}
}
.pc-chef{
  position:absolute;bottom:110px;right:50px;z-index:6;width:70px
}
.pc-chef-toque{
  width:52px;height:36px;margin:0 auto;position:relative
}
.pc-chef-toque::before{
  content:'';position:absolute;bottom:0;left:0;right:0;height:14px;
  background:linear-gradient(to bottom,#e0e0e0,#ccc);border-radius:2px
}
.pc-chef-toque::after{
  content:'';position:absolute;bottom:12px;left:4px;right:4px;height:26px;
  background:var(--pc-white);border-radius:50% 50% 20% 20%;
  box-shadow:0 -4px 8px rgba(0,0,0,.1)
}
.pc-chef-head{
  width:36px;height:42px;border-radius:50% 50% 45% 45%;
  background:linear-gradient(to bottom,#f5d5b0,#e0b880);
  position:relative;left:50%;transform:translateX(-50%);margin-top:-2px
}
.pc-chef-head::after{
  content:'';position:absolute;bottom:10px;left:50%;transform:translateX(-50%);
  width:16px;height:2px;background:rgba(60,30,0,.3);border-radius:2px
}
.pc-chef-coat{
  width:52px;height:72px;margin:0 auto;
  background:linear-gradient(to bottom,var(--pc-white),#eee);
  border-radius:4px 4px 2px 2px;position:relative
}
/* double-breasted buttons */
.pc-chef-coat::before{
  content:'';position:absolute;top:10px;left:14px;
  width:4px;height:44px;background:#e0e0e0;border-radius:2px;
  box-shadow:8px 0 0 #e0e0e0
}
.pc-chef-coat::after{
  content:'';position:absolute;top:10px;left:18px;
  width:4px;height:4px;border-radius:50%;background:#ccc;
  box-shadow:0 10px 0 #ccc,0 20px 0 #ccc,0 30px 0 #ccc
}
/* neckerchief */
.pc-neckerchief{
  position:absolute;top:-4px;left:50%;transform:translateX(-50%);
  width:28px;height:14px;background:var(--pc-gold);
  clip-path:polygon(0 0,100% 0,70% 100%,50% 60%,30% 100%);z-index:2
}
/* stirring arm */
@keyframes pc-stir{
  0%,100%{transform:rotate(-20deg)}
  50%{transform:rotate(20deg)}
}
.pc-chef-arm-r{
  position:absolute;top:52px;right:-12px;
  width:12px;height:52px;border-radius:6px;
  background:var(--pc-white);
  animation:pc-stir 1.4s ease-in-out infinite;transform-origin:top center
}
.pc-chef-arm-r::after{
  content:'';position:absolute;bottom:-20px;left:50%;transform:translateX(-50%);
  width:2px;height:22px;background:#8B4513;border-radius:1px
}
.pc-chef-arm-l{
  position:absolute;top:52px;left:-12px;
  width:12px;height:48px;border-radius:6px;
  background:var(--pc-white);transform:rotate(10deg);transform-origin:top center
}
.pc-chef-trousers{
  width:52px;height:60px;margin:0 auto;
  background:repeating-linear-gradient(45deg,#222 0,#222 4px,#333 4px,#333 8px);
  border-radius:0 0 4px 4px
}

/* floating food emoji tags */
@keyframes pc-float{
  0%,100%{transform:translateY(0)}
  50%{transform:translateY(-10px)}
}
.pc-food-tag{
  position:absolute;z-index:8;
  background:rgba(44,26,14,.88);border:1px solid rgba(200,146,42,.4);
  border-radius:var(--pc-r);padding:8px 14px;
  font-family:var(--pc-f-body);font-size:.8rem;font-weight:500;
  color:rgba(255,255,255,.85);animation:pc-float 3.5s ease-in-out infinite
}
.pc-food-tag strong{color:var(--pc-gold-lt);display:block;font-size:.9rem}

/* herb garden shelf */
.pc-herbs{
  position:absolute;bottom:110px;right:10px;z-index:5;
  display:flex;gap:8px;align-items:flex-end
}
.pc-herb-pot{
  width:28px;height:28px;
  background:linear-gradient(to bottom,#8B4513,#6b3410);
  border-radius:0 0 50% 50%;border-top:2px solid #a0522d;
  position:relative
}
.pc-herb-plant{
  position:absolute;bottom:100%;left:50%;transform:translateX(-50%);
  font-size:1.2rem;line-height:1
}

/* hero content */
.pc-hero-content{position:relative;z-index:3;max-width:560px}
.pc-hero-pre{
  display:inline-flex;align-items:center;gap:10px;
  margin-bottom:28px;font-size:.78rem;font-weight:500;
  letter-spacing:.2em;text-transform:uppercase;color:var(--pc-gold-lt)
}
.pc-hero-pre::before{content:'';display:inline-block;width:24px;height:1px;background:var(--pc-gold-lt)}
.pc-hero-desc{
  font-size:1.08rem;line-height:1.85;color:rgba(255,255,255,.75);
  margin:28px 0 40px;font-weight:300
}
.pc-hero-btns{display:flex;gap:16px;flex-wrap:wrap}
.pc-hero-credentials{
  display:flex;gap:32px;margin-top:52px;padding-top:44px;
  border-top:1px solid rgba(200,146,42,.2);flex-wrap:wrap
}
.pc-hero-cred{
  text-align:center
}
.pc-hero-cred-num{
  font-family:var(--pc-f-display);font-size:1.8rem;color:var(--pc-gold-lt);line-height:1
}
.pc-hero-cred-label{
  font-size:.7rem;color:rgba(255,255,255,.5);text-transform:uppercase;
  letter-spacing:.12em;margin-top:4px
}

/* ── ABOUT BAND ─────────────────────────────────────────────── */
.pc-about-band{
  background:var(--pc-gold);padding:20px 0
}
.pc-about-band-inner{
  display:flex;align-items:center;justify-content:center;
  gap:48px;flex-wrap:wrap
}
.pc-about-badge{
  display:flex;align-items:center;gap:10px;
  font-family:var(--pc-f-body);font-size:.82rem;font-weight:600;
  letter-spacing:.08em;text-transform:uppercase;color:var(--pc-truffle)
}
.pc-about-badge::before{content:'✦';font-size:.7rem}

/* ── STATS ──────────────────────────────────────────────────── */
.pc-stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:1px;background:rgba(200,146,42,.15)}
.pc-stat-cell{
  background:var(--pc-truffle-lt);padding:44px 24px;text-align:center;
  border-bottom:2px solid transparent;transition:border-color .3s
}
.pc-stat-cell:hover{border-bottom-color:var(--pc-gold)}
.pc-stat-num{
  font-family:var(--pc-f-display);font-size:clamp(2rem,5vw,3.2rem);
  color:var(--pc-gold-lt);line-height:1;display:block
}
.pc-stat-label{
  font-size:.72rem;color:rgba(255,255,255,.5);text-transform:uppercase;
  letter-spacing:.14em;margin-top:10px;display:block;font-weight:500
}

/* ── CUISINE ────────────────────────────────────────────────── */
.pc-cuisine-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:2px;background:var(--pc-smoke-dk);margin-top:60px}
.pc-cuisine-card{
  background:var(--pc-smoke);padding:40px 32px;
  border-bottom:2px solid transparent;transition:all .3s;cursor:default
}
.pc-cuisine-card:hover{background:var(--pc-white);border-bottom-color:var(--pc-gold)}
.pc-cuisine-icon{font-size:2.2rem;margin-bottom:18px;display:block}
.pc-cuisine-name{
  font-family:var(--pc-f-display);font-size:1.3rem;color:var(--pc-truffle);margin-bottom:10px
}
.pc-cuisine-desc{font-size:.9rem;color:var(--pc-slate);line-height:1.7}

/* ── MENUS ──────────────────────────────────────────────────── */
.pc-menus-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:28px;align-items:start}
.pc-menu-card{border-radius:var(--pc-r-lg);overflow:hidden;transition:transform .3s,box-shadow .3s}
.pc-menu-card:hover{transform:translateY(-6px);box-shadow:var(--pc-sh)}
.pc-menu-standard{background:var(--pc-truffle-lt);border:1px solid rgba(200,146,42,.12)}
.pc-menu-featured{
  background:var(--pc-truffle-mid);border:1px solid var(--pc-gold);
  transform:scale(1.04);box-shadow:var(--pc-sh-gold)
}
.pc-menu-featured:hover{transform:scale(1.04) translateY(-6px)}
.pc-menu-grand{background:var(--pc-truffle-lt);border:1px solid rgba(200,146,42,.12)}
.pc-menu-top{padding:32px 28px 24px;border-bottom:1px solid rgba(255,255,255,.07)}
.pc-menu-badge{
  display:inline-block;margin-bottom:14px;
  font-size:.68rem;font-weight:600;letter-spacing:.16em;text-transform:uppercase;
  padding:4px 12px;border-radius:99px;
  background:rgba(200,146,42,.12);color:var(--pc-gold-lt)
}
.pc-menu-featured .pc-menu-badge{background:var(--pc-gold);color:var(--pc-truffle)}
.pc-menu-name{
  font-family:var(--pc-f-display);font-size:1.7rem;color:var(--pc-white);margin-bottom:8px
}
.pc-menu-price{
  font-family:var(--pc-f-display);font-size:3rem;color:var(--pc-gold-lt);line-height:1
}
.pc-menu-price sup{font-size:1.2rem;vertical-align:top;margin-top:.5rem}
.pc-menu-period{font-size:.8rem;color:rgba(255,255,255,.45);margin-top:4px}
.pc-menu-body{padding:24px 28px}
.pc-menu-course{
  display:flex;align-items:flex-start;gap:10px;
  padding:9px 0;border-bottom:1px solid rgba(255,255,255,.06);
  font-size:.9rem;color:rgba(255,255,255,.75)
}
.pc-menu-course:last-child{border-bottom:none}
.pc-menu-dot{color:var(--pc-gold);flex-shrink:0;margin-top:2px;font-size:.7rem}
.pc-menu-featured .pc-menu-dot{color:var(--pc-gold-lt)}
.pc-menu-btn{display:block;text-align:center;margin-top:20px}

/* ── PROCESS ────────────────────────────────────────────────── */
.pc-process-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:40px;position:relative}
.pc-process-grid::before{
  content:'';position:absolute;top:32px;left:calc(12.5% + 16px);right:calc(12.5% + 16px);
  height:1px;background:linear-gradient(to right,var(--pc-gold),rgba(200,146,42,.15));z-index:0
}
.pc-process-step{text-align:center;position:relative;z-index:1}
.pc-process-icon{
  width:64px;height:64px;border-radius:50%;
  background:var(--pc-truffle-mid);border:1px solid var(--pc-gold);
  display:flex;align-items:center;justify-content:center;
  font-size:1.6rem;margin:0 auto 20px;position:relative
}
.pc-process-num{
  position:absolute;top:-4px;right:-4px;width:22px;height:22px;border-radius:50%;
  background:var(--pc-gold);color:var(--pc-truffle);
  font-family:var(--pc-f-body);font-size:.7rem;font-weight:700;
  display:flex;align-items:center;justify-content:center
}
.pc-process-title{
  font-family:var(--pc-f-display);font-size:1.1rem;color:var(--pc-white);margin-bottom:8px
}
.pc-process-desc{font-size:.88rem;color:rgba(255,255,255,.55);line-height:1.65}

/* ── TESTIMONIALS ───────────────────────────────────────────── */
.pc-testi-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}
.pc-testi-card{
  background:var(--pc-white);padding:36px;
  border-top:2px solid var(--pc-gold);
  box-shadow:var(--pc-sh);transition:transform .3s
}
.pc-testi-card:hover{transform:translateY(-4px)}
.pc-testi-stars{color:var(--pc-gold);font-size:1rem;letter-spacing:3px;margin-bottom:16px}
.pc-testi-text{
  font-family:var(--pc-f-display);font-size:1rem;line-height:1.8;
  color:var(--pc-slate);margin-bottom:24px
}
.pc-testi-author{
  display:flex;align-items:center;gap:14px;
  padding-top:16px;border-top:1px solid var(--pc-smoke-dk)
}
.pc-testi-avatar{
  width:44px;height:44px;border-radius:50%;
  background:var(--pc-truffle);
  display:flex;align-items:center;justify-content:center;
  font-size:1.2rem;flex-shrink:0;border:2px solid var(--pc-gold)
}
.pc-testi-name{
  font-family:var(--pc-f-display);font-size:1rem;color:var(--pc-truffle)
}
.pc-testi-occasion{font-size:.78rem;color:var(--pc-gold-dk);font-weight:500}

/* ── FAQ ────────────────────────────────────────────────────── */
.pc-faq-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;max-width:960px;margin:0 auto}
.pc-faq-item{
  background:var(--pc-white);border:1px solid var(--pc-smoke-dk);overflow:hidden;
  box-shadow:0 2px 8px rgba(44,26,14,.06)
}
.pc-faq-q{
  width:100%;background:none;border:none;cursor:pointer;
  display:flex;align-items:center;justify-content:space-between;gap:16px;
  padding:22px 24px;text-align:left;
  font-family:var(--pc-f-display);font-size:1rem;
  color:var(--pc-truffle);transition:color .25s
}
.pc-faq-q:hover{color:var(--pc-gold-dk)}
.pc-faq-icon{
  flex-shrink:0;width:26px;height:26px;border-radius:50%;
  border:1px solid var(--pc-smoke-dk);
  display:flex;align-items:center;justify-content:center;
  font-size:1.1rem;transition:all .3s;color:var(--pc-gold)
}
.pc-faq-item.pc-open .pc-faq-icon{
  transform:rotate(45deg);background:var(--pc-gold);color:var(--pc-truffle);border-color:var(--pc-gold)
}
.pc-faq-a{max-height:0;overflow:hidden;transition:max-height .4s ease}
.pc-faq-a-inner{
  padding:0 24px 20px;
  font-size:.9rem;color:var(--pc-slate);line-height:1.75;
  border-top:1px solid var(--pc-smoke-dk)
}

/* ── BOOKING ────────────────────────────────────────────────── */
.pc-booking-wrap{display:grid;grid-template-columns:1fr 1.15fr;gap:80px;align-items:start}
.pc-booking-info h2{margin-bottom:20px}
.pc-booking-info p{color:rgba(255,255,255,.7);line-height:1.8;margin-bottom:28px}
.pc-booking-detail{
  display:flex;align-items:flex-start;gap:14px;
  padding:14px 0;border-bottom:1px solid rgba(200,146,42,.15)
}
.pc-booking-detail:last-child{border-bottom:none}
.pc-booking-icon{
  width:40px;height:40px;
  background:rgba(200,146,42,.1);border:1px solid rgba(200,146,42,.2);
  display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0
}
.pc-booking-label{font-size:.7rem;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:var(--pc-gold);margin-bottom:3px}
.pc-booking-value{font-size:.92rem;color:rgba(255,255,255,.7)}
.pc-form{background:var(--pc-truffle-mid);padding:44px;border:1px solid rgba(200,146,42,.18);border-radius:var(--pc-r-lg)}
.pc-form-title{font-family:var(--pc-f-display);font-size:2rem;color:var(--pc-white);margin-bottom:6px}
.pc-form-subtitle{font-size:.88rem;color:rgba(255,255,255,.45);margin-bottom:32px;font-weight:300}
.pc-form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.pc-field{margin-bottom:18px}
.pc-field label{display:block;margin-bottom:7px;font-size:.7rem;font-weight:600;text-transform:uppercase;letter-spacing:.14em;color:rgba(255,255,255,.5)}
.pc-field input,.pc-field select,.pc-field textarea{
  width:100%;padding:12px 16px;
  border:1px solid rgba(200,146,42,.18);
  background:rgba(255,255,255,.04);color:var(--pc-white);
  font-family:var(--pc-f-body);font-size:.9rem;
  transition:border-color .25s;outline:none;border-radius:0
}
.pc-field input:focus,.pc-field select:focus,.pc-field textarea:focus{border-color:var(--pc-gold)}
.pc-field select option{background:var(--pc-truffle);color:var(--pc-white)}
.pc-field textarea{min-height:110px;resize:vertical}

/* ── FOOTER CTA ─────────────────────────────────────────────── */
.pc-footer-cta{
  padding:76px 0;text-align:center;background:var(--pc-cream);
  border-top:1px solid rgba(200,146,42,.2)
}
.pc-footer-cta h2{color:var(--pc-truffle);margin-bottom:14px}
.pc-footer-cta p{font-size:1rem;color:var(--pc-slate);max-width:500px;margin:0 auto 32px;line-height:1.8}

/* ── SCROLL REVEAL ──────────────────────────────────────────── */
.pc-reveal{opacity:0;transform:translateY(26px);transition:opacity .65s ease,transform .65s ease}
.pc-reveal.pc-visible{opacity:1;transform:translateY(0)}

/* ── RESPONSIVE ─────────────────────────────────────────────── */
@media(max-width:1050px){.pc-hero-scene{width:380px}}
@media(max-width:880px){
  .pc-hero-scene{display:none}
  .pc-stats-grid{grid-template-columns:repeat(2,1fr)}
  .pc-cuisine-grid{grid-template-columns:repeat(2,1fr)}
  .pc-menus-grid{grid-template-columns:1fr}
  .pc-menu-featured{transform:none}
  .pc-process-grid{grid-template-columns:repeat(2,1fr);gap:32px}
  .pc-process-grid::before{display:none}
  .pc-testi-grid{grid-template-columns:1fr}
  .pc-faq-grid{grid-template-columns:1fr}
  .pc-booking-wrap{grid-template-columns:1fr}
}
@media(max-width:600px){
  .pc-section{padding:68px 0}
  .pc-cuisine-grid{grid-template-columns:1fr}
  .pc-stats-grid{grid-template-columns:1fr 1fr}
  .pc-form-row{grid-template-columns:1fr}
  .pc-hero-credentials{flex-direction:column;gap:24px}
  .pc-hero-btns{flex-direction:column}
}
</style>

<!-- ── HERO ──────────────────────────────────────────────────── -->
<section class="pc-hero">

  <!-- CSS KITCHEN SCENE -->
  <div class="pc-hero-scene" aria-hidden="true">

    <!-- kitchen counter & range -->
    <div class="pc-range">
      <div class="pc-burner"></div>
      <div class="pc-burner"></div>
      <div class="pc-burner"></div>
      <div class="pc-burner"></div>
    </div>
    <div class="pc-counter"></div>

    <!-- flames on front left burner -->
    <div style="position:absolute;bottom:248px;left:140px;z-index:5">
      <div class="pc-flame pc-flame-outer"></div>
      <div class="pc-flame pc-flame-inner"></div>
    </div>
    <div style="position:absolute;bottom:242px;left:128px;z-index:5;animation-delay:.2s">
      <div class="pc-flame" style="width:20px;height:26px;background:linear-gradient(to top,#FF6B00,#FFD700);border-radius:50% 50% 20% 20%;filter:blur(1px)"></div>
    </div>

    <!-- copper pot 1 (large, left burner) -->
    <div class="pc-pot" style="bottom:258px;left:120px;z-index:6">
      <div class="pc-steam-puff" style="width:20px;height:20px;top:-28px;left:10px;animation-delay:0s"></div>
      <div class="pc-steam-puff" style="width:14px;height:14px;top:-22px;left:26px;animation-delay:.7s"></div>
      <div class="pc-pot-lid" style="width:70px;height:18px;position:relative">
        <div class="pc-pot-handle-l"></div>
        <div class="pc-pot-handle-r"></div>
      </div>
      <div class="pc-pot-body" style="width:70px;height:48px"></div>
    </div>

    <!-- copper pot 2 (small, right burner) -->
    <div class="pc-pot" style="bottom:266px;left:214px;z-index:6">
      <div class="pc-steam-puff" style="width:12px;height:12px;top:-20px;left:8px;animation-delay:.4s"></div>
      <div class="pc-pot-lid" style="width:52px;height:14px;position:relative">
        <div class="pc-pot-handle-l"></div>
        <div class="pc-pot-handle-r"></div>
      </div>
      <div class="pc-pot-body" style="width:52px;height:36px"></div>
    </div>

    <!-- chef figure -->
    <div class="pc-chef">
      <div class="pc-chef-toque"></div>
      <div class="pc-chef-head"></div>
      <div class="pc-chef-coat" style="position:relative">
        <div class="pc-neckerchief"></div>
        <div class="pc-chef-arm-l"></div>
        <div class="pc-chef-arm-r"></div>
      </div>
      <div class="pc-chef-trousers"></div>
    </div>

    <!-- herb pots shelf -->
    <div class="pc-herbs">
      <?php
      $herbs=[['🌿','Basil'],['🌱','Thyme'],['🪴','Rosemary'],['🌿','Parsley']];
      foreach($herbs as $h):?>
      <div class="pc-herb-pot" title="<?=esc_attr($h[1])?>">
        <div class="pc-herb-plant"><?=esc_html($h[0])?></div>
      </div>
      <?php endforeach;?>
    </div>

    <!-- floating food info tags -->
    <div class="pc-food-tag" style="top:10%;left:10%;animation-delay:0s">
      <strong>Michelin-Trained</strong>Former Le Gavroche
    </div>
    <div class="pc-food-tag" style="top:28%;right:5%;animation-delay:1.5s">
      <strong>Seasonal Menus</strong>Farm-to-table sourcing
    </div>
    <div class="pc-food-tag" style="top:50%;left:5%;animation-delay:3s">
      <strong>Dietary Inclusive</strong>All requirements catered
    </div>

  </div><!-- /scene -->

  <div class="pc-container" style="position:relative;z-index:3">
    <div class="pc-hero-content">

      <div class="pc-hero-pre">Private Dining · In-Home Chef</div>

      <h1 class="pc-h1">
        Restaurant<br>
        Quality in<br>
        <em>Your Own Home</em>
      </h1>

      <div class="pc-rule"><span class="pc-rule-icon">✦</span></div>

      <p class="pc-hero-desc">
        Award-winning chef Laurent Moreau brings the full fine-dining experience
        directly to your home. From intimate dinners to milestone celebrations —
        everything prepared fresh, everything immaculate.
      </p>

      <div class="pc-hero-btns">
        <a href="#booking" class="pc-btn pc-btn--gold">Book a Dinner</a>
        <a href="#menus" class="pc-btn pc-btn--outline-white">View Menus</a>
      </div>

      <div class="pc-hero-credentials">
        <?php
        $creds=[['500+','Private Dinners'],['15','Years Experience'],['4.9★','Client Rating']];
        foreach($creds as $c):?>
        <div class="pc-hero-cred">
          <div class="pc-hero-cred-num"><?=esc_html($c[0])?></div>
          <div class="pc-hero-cred-label"><?=esc_html($c[1])?></div>
        </div>
        <?php endforeach;?>
      </div>

    </div>
  </div>

</section><!-- /hero -->

<!-- ── TRUST BAND ─────────────────────────────────────────────── -->
<div class="pc-about-band">
  <div class="pc-container">
    <div class="pc-about-band-inner">
      <?php
      $badges=['Michelin-Trained Chef','Fully Insured & DBS Checked','All Dietary Requirements Catered','Farm-to-Table Seasonal Sourcing','UK-Wide Service Available'];
      foreach($badges as $b):?>
      <div class="pc-about-badge"><?=esc_html($b)?></div>
      <?php endforeach;?>
    </div>
  </div>
</div>

<!-- ── STATS ─────────────────────────────────────────────────── -->
<section class="pc-section--truffle" style="padding:0">
  <div class="pc-stats-grid">
    <?php
    $stats=[
      ['num'=>500,'suf'=>'+','label'=>'Private Dinners'],
      ['num'=>15,'suf'=>'','label'=>'Years Experience'],
      ['num'=>98,'suf'=>'%','label'=>'Client Satisfaction'],
      ['num'=>12,'suf'=>'','label'=>'Cuisine Styles Offered'],
    ];
    foreach($stats as $s):?>
    <div class="pc-stat-cell">
      <span class="pc-stat-num" data-target="<?=esc_attr($s['num'])?>" data-suffix="<?=esc_attr($s['suf'])?>">0</span>
      <span class="pc-stat-label"><?=esc_html($s['label'])?></span>
    </div>
    <?php endforeach;?>
  </div>
</section>

<!-- ── CUISINE STYLES ────────────────────────────────────────── -->
<section class="pc-section pc-section--smoke">
  <div class="pc-container">

    <div style="max-width:600px;margin-bottom:20px">
      <div class="pc-eyebrow pc-eyebrow--dark">Culinary Range</div>
      <h2 class="pc-h2">Cuisine Styles</h2>
    </div>
    <p class="pc-lead" style="color:var(--pc-slate);max-width:620px;margin-bottom:0">
      Trained at Le Gavroche under Michel Roux Jr and with stints across Paris, Tokyo and New York,
      Laurent brings an extraordinary breadth of technique and flavour to every menu.
    </p>

    <div class="pc-cuisine-grid">
      <?php
      $cuisines=[
        ['icon'=>'🇫🇷','name'=>'Classic French','desc'=>'The foundation of Laurent\'s training. Elegant sauces, refined techniques and exceptional produce — from a simple sole meunière to a full tasting menu.'],
        ['icon'=>'🫒','name'=>'Modern Mediterranean','desc'=>'Sun-drenched produce, good olive oil and the freshest seafood. Perfect for summer dining and informal entertaining.'],
        ['icon'=>'🍣','name'=>'Japanese Fusion','desc'=>'Drawing on a year spent in Kyoto, Laurent weaves Japanese precision and umami depth into contemporary European dishes.'],
        ['icon'=>'🥩','name'=>'British & Seasonal','desc'=>'Celebrating the best of British produce — Herefordshire beef, Cornish fish, Cumbrian lamb — with honest preparation and minimal intervention.'],
        ['icon'=>'🌿','name'=>'Plant-Based Fine Dining','desc'=>'Complex, satisfying and genuinely beautiful vegetable cookery that requires no compromise. A full tasting menu available.'],
        ['icon'=>'🎂','name'=>'Private Celebrations','desc'=>'Birthday menus, anniversary dinners, proposal evenings and bespoke milestone celebrations — each one designed around the guest of honour.'],
      ];
      foreach($cuisines as $c):?>
      <div class="pc-cuisine-card pc-reveal">
        <span class="pc-cuisine-icon"><?=esc_html($c['icon'])?></span>
        <div class="pc-cuisine-name"><?=esc_html($c['name'])?></div>
        <p class="pc-cuisine-desc"><?=esc_html($c['desc'])?></p>
      </div>
      <?php endforeach;?>
    </div>

  </div>
</section>

<!-- ── MENUS ─────────────────────────────────────────────────── -->
<section class="pc-section pc-section--truffle-lt" id="menus">
  <div class="pc-container">

    <div style="text-align:center;max-width:560px;margin:0 auto 60px">
      <div class="pc-eyebrow">Dining Packages</div>
      <h2 class="pc-h2" style="color:var(--pc-white)">Choose Your Experience</h2>
      <div class="pc-rule" style="max-width:200px;margin:20px auto"><span class="pc-rule-icon">✦</span></div>
      <p style="color:rgba(255,255,255,.6);line-height:1.7">All packages include full service from arrival prep to kitchen clean-down.</p>
    </div>

    <div class="pc-menus-grid">

      <!-- Intimate -->
      <div class="pc-menu-card pc-menu-standard pc-reveal">
        <div class="pc-menu-top">
          <div class="pc-menu-badge">2–4 Guests</div>
          <div class="pc-menu-name">Intimate Dinner</div>
          <div class="pc-menu-price"><sup>£</sup>180</div>
          <div class="pc-menu-period">per person · 3 courses</div>
        </div>
        <div class="pc-menu-body">
          <?php foreach(['Bespoke 3-course menu','Wine pairing suggestions','All mise en place on arrival','Kitchen cleaned on departure','Service for 2–4 guests'] as $c):?>
          <div class="pc-menu-course"><span class="pc-menu-dot">✦</span><span><?=esc_html($c)?></span></div>
          <?php endforeach;?>
          <div class="pc-menu-btn"><a href="#booking" class="pc-btn pc-btn--outline-white" style="width:100%;justify-content:center">Enquire Now</a></div>
        </div>
      </div>

      <!-- Signature (featured) -->
      <div class="pc-menu-card pc-menu-featured pc-reveal">
        <div class="pc-menu-top">
          <div class="pc-menu-badge">✦ Most Popular</div>
          <div class="pc-menu-name">Signature Tasting</div>
          <div class="pc-menu-price"><sup>£</sup>280</div>
          <div class="pc-menu-period">per person · 7 courses</div>
        </div>
        <div class="pc-menu-body">
          <?php foreach(['7-course tasting menu','Matched wine flight (somm-selected)','Amuse-bouche & pre-dessert','Personalised menu card keepsake','Service for 2–8 guests','Canape reception on arrival','Post-dinner cheese & digestif'] as $c):?>
          <div class="pc-menu-course"><span class="pc-menu-dot">✦</span><span><?=esc_html($c)?></span></div>
          <?php endforeach;?>
          <div class="pc-menu-btn"><a href="#booking" class="pc-btn pc-btn--gold" style="width:100%;justify-content:center">Book Experience</a></div>
        </div>
      </div>

      <!-- Grand Occasion -->
      <div class="pc-menu-card pc-menu-grand pc-reveal">
        <div class="pc-menu-top">
          <div class="pc-menu-badge">Celebration</div>
          <div class="pc-menu-name">Grand Occasion</div>
          <div class="pc-menu-price"><sup>£</sup>380</div>
          <div class="pc-menu-period">per person · 10 courses</div>
        </div>
        <div class="pc-menu-body">
          <?php foreach(['10-course grand tasting menu','Champagne & luxury wine flight','Live kitchen theatre / open kitchen','Custom printed menus & table styling','Up to 16 guests','Pre-dinner consultation visit','Laurent attends in person throughout'] as $c):?>
          <div class="pc-menu-course"><span class="pc-menu-dot">✦</span><span><?=esc_html($c)?></span></div>
          <?php endforeach;?>
          <div class="pc-menu-btn"><a href="#booking" class="pc-btn pc-btn--gold" style="width:100%;justify-content:center">Reserve Now</a></div>
        </div>
      </div>

    </div>

    <p style="text-align:center;margin-top:28px;color:rgba(255,255,255,.4);font-size:.88rem">
      Custom menus and weekly meal preparation services also available — enquire for details.
    </p>

  </div>
</section>

<!-- ── PROCESS ───────────────────────────────────────────────── -->
<section class="pc-section pc-section--truffle">
  <div class="pc-container">

    <div style="text-align:center;max-width:560px;margin:0 auto 68px">
      <div class="pc-eyebrow">The Experience</div>
      <h2 class="pc-h2" style="color:var(--pc-white)">From First Contact to Last Course</h2>
    </div>

    <div class="pc-process-grid">
      <?php
      $steps=[
        ['icon'=>'📞','title'=>'Consultation','desc'=>'We discuss your occasion, guest count, dietary requirements, flavour preferences and preferred cuisine style.'],
        ['icon'=>'📋','title'=>'Bespoke Menu','desc'=>'Laurent designs a personalised menu using the finest seasonal produce, sent to you for approval and refinement.'],
        ['icon'=>'🍳','title'=>'Arrival & Prep','desc'=>'Laurent arrives 2–3 hours before dining, prepares your kitchen workspace and ensures everything is perfectly timed.'],
        ['icon'=>'🥂','title'=>'The Dinner','desc'=>'From first canapé to final petit four, every detail is orchestrated — you relax and enjoy the entire evening.'],
      ];
      foreach($steps as $i=>$s):?>
      <div class="pc-process-step pc-reveal">
        <div class="pc-process-icon">
          <?=esc_html($s['icon'])?>
          <div class="pc-process-num"><?=$i+1?></div>
        </div>
        <h3 class="pc-process-title"><?=esc_html($s['title'])?></h3>
        <p class="pc-process-desc"><?=esc_html($s['desc'])?></p>
      </div>
      <?php endforeach;?>
    </div>

  </div>
</section>

<!-- ── TESTIMONIALS ──────────────────────────────────────────── -->
<section class="pc-section pc-section--cream">
  <div class="pc-container">

    <div style="text-align:center;max-width:560px;margin:0 auto 60px">
      <div class="pc-eyebrow pc-eyebrow--dark">Guest Reviews</div>
      <h2 class="pc-h2">What Our Guests Say</h2>
    </div>

    <div class="pc-testi-grid">
      <?php
      $testis=[
        ['text'=>'"Laurent cooked our wedding anniversary dinner and it was genuinely the most memorable meal of our lives. The langoustine bisque alone was worth every penny."','name'=>'William & Sarah Ashworth','occasion'=>'20th Wedding Anniversary · Bath','avatar'=>'🥂'],
        ['text'=>'"We booked Laurent for a proposal dinner for 2 and the entire experience was flawless. My partner still talks about the foie gras and the chocolate soufflé. Perfect in every way."','name'=>'James Hartley','occasion'=>'Proposal Dinner · Kensington','avatar'=>'💍'],
        ['text'=>'"We have Laurent cook for our board dinners four times a year. The consistency is extraordinary — every menu different, every dish exceptional. Our clients are always astonished."','name'=>'Catherine Blaine','occasion'=>'Corporate Entertaining · Mayfair','avatar'=>'🏢'],
      ];
      foreach($testis as $t):?>
      <div class="pc-testi-card pc-reveal">
        <div class="pc-testi-stars">★★★★★</div>
        <p class="pc-testi-text"><?=esc_html($t['text'])?></p>
        <div class="pc-testi-author">
          <div class="pc-testi-avatar"><?=esc_html($t['avatar'])?></div>
          <div>
            <div class="pc-testi-name"><?=esc_html($t['name'])?></div>
            <div class="pc-testi-occasion"><?=esc_html($t['occasion'])?></div>
          </div>
        </div>
      </div>
      <?php endforeach;?>
    </div>

  </div>
</section>

<!-- ── FAQ ───────────────────────────────────────────────────── -->
<section class="pc-section pc-section--smoke-dk">
  <div class="pc-container">

    <div style="text-align:center;max-width:560px;margin:0 auto 52px">
      <div class="pc-eyebrow pc-eyebrow--dark">Questions</div>
      <h2 class="pc-h2">Frequently Asked</h2>
    </div>

    <div class="pc-faq-grid">
      <?php
      $faqs=[
        ['q'=>'How far in advance should I book?','a'=>'Laurent is typically booked 4–8 weeks in advance, particularly for weekend dates and the holiday season. We recommend enquiring as early as possible for significant occasions. Last-minute bookings are sometimes possible — please call to check.'],
        ['q'=>'What does Laurent need from my kitchen?','a'=>'A standard domestic kitchen is all that\'s required. Laurent brings all his own specialist equipment, knives and plating tools. A brief kitchen call or visit can be arranged beforehand for more complex events.'],
        ['q'=>'Can you accommodate dietary requirements?','a'=>'Yes — Laurent is exceptionally skilled at creating menus for any combination of dietary requirements including vegan, gluten-free, dairy-free, nut allergies and any other medical or religious dietary needs. These are incorporated seamlessly into the menu design.'],
        ['q'=>'What area do you cover?','a'=>'Laurent is based in London and covers all of Greater London within the base package price. Travel surcharges apply for locations outside London; however, Laurent regularly travels to country houses, estates and city residences throughout England and Scotland.'],
        ['q'=>'Is the kitchen left clean?','a'=>'Completely. Full kitchen clean-down is included in every package — the kitchen is typically returned to its original state within 45 minutes of the final course. This is a non-negotiable standard for Laurent.'],
        ['q'=>'Do you bring the ingredients or do we?','a'=>'Laurent handles all sourcing, shopping and ingredient procurement as part of the service. You will be invoiced for ingredient costs separately at cost price — no mark-up. A detailed ingredient list and receipts are provided on request.'],
      ];
      foreach($faqs as $i=>$f):?>
      <div class="pc-faq-item">
        <button class="pc-faq-q" aria-expanded="false" aria-controls="pc-faq-a-<?=$i?>">
          <?=esc_html($f['q'])?>
          <span class="pc-faq-icon" aria-hidden="true">+</span>
        </button>
        <div class="pc-faq-a" id="pc-faq-a-<?=$i?>" role="region">
          <div class="pc-faq-a-inner"><?=esc_html($f['a'])?></div>
        </div>
      </div>
      <?php endforeach;?>
    </div>

  </div>
</section>

<!-- ── BOOKING ───────────────────────────────────────────────── -->
<section class="pc-section pc-section--truffle-lt" id="booking">
  <div class="pc-container">
    <div class="pc-booking-wrap">

      <div class="pc-booking-info pc-reveal">
        <div class="pc-eyebrow">Reserve Your Evening</div>
        <h2 class="pc-h2" style="color:var(--pc-white)">Book Your Private Dinner</h2>
        <p>Tell us a little about your occasion and Laurent will be in touch within 24 hours to discuss a personalised menu and confirm availability.</p>

        <?php
        $bds=[
          ['icon'=>'📞','label'=>'Telephone','value'=>'+44 207 000 5678'],
          ['icon'=>'📧','label'=>'Email','value'=>'hello@laurentmoreau.co.uk'],
          ['icon'=>'📍','label'=>'Service Area','value'=>'London & UK-wide · Country houses & estates welcome'],
          ['icon'=>'🕒','label'=>'Booking Hours','value'=>"Mon–Fri 9am–7pm\nWeekends by appointment"],
        ];
        foreach($bds as $d):?>
        <div class="pc-booking-detail">
          <div class="pc-booking-icon"><?=esc_html($d['icon'])?></div>
          <div>
            <div class="pc-booking-label"><?=esc_html($d['label'])?></div>
            <div class="pc-booking-value"><?=esc_html($d['value'])?></div>
          </div>
        </div>
        <?php endforeach;?>

        <div style="margin-top:28px;padding:18px;background:rgba(200,146,42,.08);border-left:2px solid var(--pc-gold)">
          <p style="font-size:.88rem;color:rgba(255,255,255,.6);line-height:1.7">
            A 25% non-refundable deposit is required to confirm your booking. Full balance is due 7 days before your event date.
          </p>
        </div>

      </div>

      <div class="pc-form pc-reveal">
        <div class="pc-form-title">Enquire Now</div>
        <div class="pc-form-subtitle">Replied to within one working day</div>

        <form method="post" action="<?=esc_url(admin_url('admin-post.php'))?>">
          <?php wp_nonce_field('tf_pc_booking','tf_pc_nonce'); ?>
          <input type="hidden" name="action" value="tf_pc_booking">

          <div class="pc-form-row">
            <div class="pc-field">
              <label for="pc-fname">First Name</label>
              <input type="text" id="pc-fname" name="first_name" placeholder="William" required autocomplete="given-name">
            </div>
            <div class="pc-field">
              <label for="pc-lname">Last Name</label>
              <input type="text" id="pc-lname" name="last_name" placeholder="Ashworth" required autocomplete="family-name">
            </div>
          </div>

          <div class="pc-form-row">
            <div class="pc-field">
              <label for="pc-email">Email</label>
              <input type="email" id="pc-email" name="email" placeholder="you@example.com" required autocomplete="email">
            </div>
            <div class="pc-field">
              <label for="pc-phone">Phone</label>
              <input type="tel" id="pc-phone" name="phone" placeholder="+44 7700 900000" autocomplete="tel">
            </div>
          </div>

          <div class="pc-form-row">
            <div class="pc-field">
              <label for="pc-date">Dining Date</label>
              <input type="date" id="pc-date" name="event_date" required>
            </div>
            <div class="pc-field">
              <label for="pc-guests">Number of Guests</label>
              <select id="pc-guests" name="guest_count">
                <option value="">— Select —</option>
                <option value="2">2 guests</option>
                <option value="3-4">3–4 guests</option>
                <option value="5-8">5–8 guests</option>
                <option value="9-12">9–12 guests</option>
                <option value="13-16">13–16 guests</option>
              </select>
            </div>
          </div>

          <div class="pc-field">
            <label for="pc-package">Preferred Package</label>
            <select id="pc-package" name="package">
              <option value="">— Select a package —</option>
              <option value="intimate">Intimate Dinner (3 courses · £180pp)</option>
              <option value="signature">Signature Tasting (7 courses · £280pp)</option>
              <option value="grand">Grand Occasion (10 courses · £380pp)</option>
              <option value="custom">Custom / Meal Prep — discuss with Laurent</option>
            </select>
          </div>

          <div class="pc-field">
            <label for="pc-occasion">Occasion</label>
            <select id="pc-occasion" name="occasion">
              <option value="">— What's the occasion? —</option>
              <option value="anniversary">Wedding Anniversary</option>
              <option value="birthday">Birthday Celebration</option>
              <option value="proposal">Proposal Dinner</option>
              <option value="corporate">Corporate Entertaining</option>
              <option value="dinner-party">Dinner Party</option>
              <option value="other">Other Special Occasion</option>
            </select>
          </div>

          <div class="pc-field">
            <label for="pc-dietary">Dietary Requirements</label>
            <input type="text" id="pc-dietary" name="dietary" placeholder="e.g. nut allergy, vegetarian, gluten-free...">
          </div>

          <div class="pc-field">
            <label for="pc-message">Tell Laurent About Your Evening</label>
            <textarea id="pc-message" name="message" placeholder="Cuisine preferences, occasion details, special requests, venue type..."></textarea>
          </div>

          <button type="submit" class="pc-btn pc-btn--gold" style="width:100%;justify-content:center;font-size:.85rem;padding:16px">
            ✦ Send Enquiry
          </button>
          <p style="text-align:center;margin-top:12px;font-size:.78rem;color:rgba(255,255,255,.35)">
            Fully insured · DBS checked · UK-wide service
          </p>

        </form>
      </div>

    </div>
  </div>
</section>

<!-- ── FOOTER CTA ─────────────────────────────────────────────── -->
<section class="pc-footer-cta">
  <div class="pc-container">
    <div class="pc-eyebrow pc-eyebrow--dark" style="display:flex;justify-content:center">Laurent Moreau · Private Chef</div>
    <h2 class="pc-h2">London · UK-Wide · International</h2>
    <p>Michelin-trained fine dining in your home. Available for private dinners, celebrations and weekly meal preparation.</p>
    <div style="display:flex;gap:16px;justify-content:center;flex-wrap:wrap">
      <a href="tel:02070005678" class="pc-btn pc-btn--gold">📞 0207 000 5678</a>
      <a href="#booking" class="pc-btn pc-btn--truffle">Book a Dinner</a>
    </div>
  </div>
</section>

</div><!-- /pc-wrap -->

<!-- ── JAVASCRIPT ─────────────────────────────────────────────── -->
<script>
(function(){

  /* animated counters */
  const easeOut = t => 1 - Math.pow(1-t,3);
  document.querySelectorAll('.pc-stat-num[data-target]').forEach(el=>{
    const target = parseFloat(el.dataset.target);
    const suffix = el.dataset.suffix||'';
    if(isNaN(target)) return;
    const obs = new IntersectionObserver(entries=>{
      entries.forEach(e=>{
        if(!e.isIntersecting) return;
        obs.unobserve(e.target);
        const dur=1800,start=performance.now();
        (function tick(now){
          const t=Math.min((now-start)/dur,1);
          el.textContent=Math.round(easeOut(t)*target).toLocaleString()+suffix;
          if(t<1) requestAnimationFrame(tick);
          else el.textContent=target.toLocaleString()+suffix;
        })(start);
      });
    },{threshold:.4});
    obs.observe(el);
  });

  /* FAQ accordion */
  document.querySelectorAll('.pc-faq-q').forEach(btn=>{
    btn.addEventListener('click',function(){
      const item=this.closest('.pc-faq-item');
      const ans=item.querySelector('.pc-faq-a');
      const open=item.classList.contains('pc-open');
      document.querySelectorAll('.pc-faq-item.pc-open').forEach(o=>{
        o.classList.remove('pc-open');
        o.querySelector('.pc-faq-a').style.maxHeight='0';
        o.querySelector('.pc-faq-q').setAttribute('aria-expanded','false');
      });
      if(!open){
        item.classList.add('pc-open');
        ans.style.maxHeight=ans.scrollHeight+'px';
        this.setAttribute('aria-expanded','true');
      }
    });
  });

  /* scroll reveal */
  const ro=new IntersectionObserver(entries=>{
    entries.forEach((e,i)=>{
      if(!e.isIntersecting) return;
      setTimeout(()=>e.target.classList.add('pc-visible'),i*85);
      ro.unobserve(e.target);
    });
  },{threshold:.1});
  document.querySelectorAll('.pc-reveal').forEach(el=>ro.observe(el));

})();
</script>

<?php get_footer(); ?>
