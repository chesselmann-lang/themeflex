<?php
/**
 * Template Name: Personal Stylist
 *
 * Premium landing page for personal stylists, image consultants and fashion advisors.
 * Palette: champagne #F5E6D0 / deep rose #B5446E / warm charcoal #2C2C2C / blush #FAD7E0 / gold #C9A84C
 * Fonts: Playfair Display + Montserrat
 * Namespace: --ps-*
 *
 * @package ThemeFlex
 */

if ( ! defined( 'ABSPATH' ) ) exit;

srand( crc32( get_the_permalink() ) );

$ps_services = [
    [ 'icon' => '🧥', 'title' => 'Wardrobe Edit',          'desc' => 'A thorough review of your existing wardrobe — keeping what works, identifying gaps and releasing what no longer serves you.' ],
    [ 'icon' => '🛍️', 'title' => 'Personal Shopping',      'desc' => 'Curated shopping trips or virtual sessions where every piece is selected specifically for your body, lifestyle and budget.' ],
    [ 'icon' => '🎨', 'title' => 'Colour Analysis',         'desc' => 'Discover your seasonal colour palette and learn which tones make your complexion glow and your eyes shine.' ],
    [ 'icon' => '✂️', 'title' => 'Body Shape Styling',      'desc' => 'Understand your unique proportions and dress confidently to accentuate your best features in every outfit.' ],
    [ 'icon' => '💼', 'title' => 'Corporate Image',         'desc' => 'Develop a professional wardrobe that commands authority, builds trust and reflects your personal brand at work.' ],
    [ 'icon' => '👗', 'title' => 'Occasion Styling',        'desc' => 'Perfect looks for weddings, galas, job interviews, photoshoots or any event where your appearance truly matters.' ],
];

$ps_packages = [
    [
        'name'     => 'Style Starter',
        'price'    => '£195',
        'sub'      => 'Perfect introduction',
        'featured' => false,
        'items'    => [ '90-min style consultation', 'Colour & body shape analysis', 'Personalised style guide', 'Shopping list & brands', 'Follow-up email support' ],
    ],
    [
        'name'     => 'Full Transformation',
        'price'    => '£550',
        'sub'      => 'Most popular · 2 sessions',
        'featured' => true,
        'items'    => [ 'Wardrobe edit (3hrs)', 'Full-day personal shopping', 'Colour & body analysis', 'Outfit formula blueprint', '30-day WhatsApp support', 'Digital lookbook' ],
    ],
    [
        'name'     => 'VIP Style Day',
        'price'    => '£980',
        'sub'      => 'Ultimate experience',
        'featured' => false,
        'items'    => [ 'Full wardrobe detox', 'Luxury personal shopping', 'Hair & beauty referrals', 'Photoshoot styling', 'Ongoing monthly check-ins', 'Lifetime digital lookbook' ],
    ],
];

$ps_process = [
    [ 'num' => '01', 'title' => 'Discovery Call',      'desc' => 'A free 20-minute call to understand your lifestyle, goals, budget and current style challenges.' ],
    [ 'num' => '02', 'title' => 'Style Analysis',      'desc' => 'Deep dive into your body shape, colouring, personality and the image you want to project to the world.' ],
    [ 'num' => '03', 'title' => 'Wardrobe Review',     'desc' => 'We go through everything you own together — identifying what stays, what goes and what\'s missing.' ],
    [ 'num' => '04', 'title' => 'Curated Shopping',    'desc' => 'I shop on your behalf or accompany you in person, selecting pieces that form a cohesive, versatile wardrobe.' ],
    [ 'num' => '05', 'title' => 'Your Lookbook',       'desc' => 'You receive a personalised digital lookbook with outfit formulas, brand guides and styling tips to keep forever.' ],
];

$ps_gallery = [
    [ 'label' => 'Casual Chic',     'c1' => '#B5446E', 'c2' => '#8a2a50' ],
    [ 'label' => 'Power Dressing',  'c1' => '#2C2C2C', 'c2' => '#1a1a1a' ],
    [ 'label' => 'Weekend Edit',    'c1' => '#C9A84C', 'c2' => '#9a7830' ],
    [ 'label' => 'Evening Glamour', 'c1' => '#6B52B0', 'c2' => '#4a3888' ],
    [ 'label' => 'Colour Palette',  'c1' => '#F5E6D0', 'c2' => '#e8d0b0' ],
    [ 'label' => 'Boardroom Ready', 'c1' => '#4A7B6F', 'c2' => '#2a5b50' ],
];

$ps_testimonials = [
    [ 'name' => 'Sophie L.',     'loc' => 'London',     'stars' => 5, 'text' => 'My confidence has completely transformed. I used to dread getting dressed — now I actually look forward to it. The wardrobe edit alone was worth every penny.' ],
    [ 'name' => 'Priya D.',      'loc' => 'Birmingham', 'stars' => 5, 'text' => 'The colour analysis was revelatory. I\'d been wearing completely the wrong tones for years. Now I get compliments everywhere I go and I feel genuinely myself.' ],
    [ 'name' => 'Catherine W.',  'loc' => 'London',     'stars' => 5, 'text' => 'Hired for a job interview styling session and got the offer! The investment paid for itself immediately. Professional, warm and genuinely transformational.' ],
];

// Floating fashion elements
$ps_floaters = [];
$fashion_items = ['✦','◇','◈','✧','♦','◊','✺','⬡','∗','⊹'];
for ($i = 0; $i < 14; $i++) {
    $ps_floaters[] = [
        'char'  => $fashion_items[array_rand($fashion_items)],
        'x'     => rand(3,97),
        'y'     => rand(3,95),
        'size'  => rand(8,20),
        'op'    => rand(8,25)/100,
        'dur'   => rand(60,120)/10,
        'delay' => rand(0,80)/10,
        'depth' => rand(10,45)/10,
    ];
}

// Clothes rack items
$rack_colors = ['#B5446E','#2C2C2C','#C9A84C','#FAD7E0','#6B52B0','#4A7B6F','#E63946','#fff','#1a1a2e','#8B6BA0'];
$rack_items = [];
for ($r = 0; $r < 10; $r++) {
    $rack_items[] = [
        'color' => $rack_colors[$r % count($rack_colors)],
        'width' => rand(24,36),
        'style' => (rand(0,1)) ? 'dress' : 'jacket',
    ];
}
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500&family=Montserrat:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
/* =========================================================
   PERSONAL STYLIST — CSS Custom Properties  (--ps-* namespace)
   ========================================================= */
:root {
    --ps-champ:  #F5E6D0;
    --ps-rose:   #B5446E;
    --ps-rose-d: #8a2a50;
    --ps-char:   #2C2C2C;
    --ps-blush:  #FAD7E0;
    --ps-gold:   #C9A84C;
    --ps-gold-d: #9a7830;
    --ps-cream:  #FDF8F3;
    --ps-text:   #2C2C2C;
    --ps-muted:  #7a6a6a;
    --ps-ff-head:'Playfair Display', Georgia, serif;
    --ps-ff-body:'Montserrat', system-ui, sans-serif;
    --ps-radius: 8px;
    --ps-shadow: 0 8px 32px rgba(44,44,44,.10);
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{font-family:var(--ps-ff-body);color:var(--ps-text);background:var(--ps-cream);-webkit-font-smoothing:antialiased}
img{max-width:100%;height:auto;display:block}
a{color:inherit;text-decoration:none}
ul{list-style:none}

/* ── Utility ── */
.ps-container{max-width:1160px;margin:0 auto;padding:0 24px}
.ps-section{padding:90px 0}
.ps-eyebrow{font-family:var(--ps-ff-body);font-size:.7rem;font-weight:600;letter-spacing:.2em;text-transform:uppercase;color:var(--ps-rose);margin-bottom:14px;display:block}
.ps-heading{font-family:var(--ps-ff-head);font-size:clamp(2.2rem,4.5vw,3.5rem);font-weight:500;line-height:1.1;color:var(--ps-char);margin-bottom:20px}
.ps-heading em{font-style:italic;color:var(--ps-rose)}
.ps-heading--light{color:#fff}
.ps-lead{font-size:.98rem;line-height:1.8;color:var(--ps-muted);max-width:640px;font-weight:300}
.ps-btn{display:inline-flex;align-items:center;gap:8px;padding:14px 34px;border-radius:2px;font-family:var(--ps-ff-body);font-size:.8rem;font-weight:600;letter-spacing:.12em;cursor:pointer;transition:all .25s;border:1.5px solid transparent;text-transform:uppercase}
.ps-btn--primary{background:var(--ps-rose);color:#fff;border-color:var(--ps-rose)}
.ps-btn--primary:hover{background:var(--ps-rose-d);transform:translateY(-2px)}
.ps-btn--outline-dark{background:transparent;color:var(--ps-char);border-color:var(--ps-char)}
.ps-btn--outline-dark:hover{background:var(--ps-char);color:#fff}
.ps-btn--gold{background:var(--ps-gold);color:#fff;border-color:var(--ps-gold)}
.ps-btn--gold:hover{background:var(--ps-gold-d);transform:translateY(-2px)}
.ps-btn--outline-light{background:transparent;color:#fff;border-color:rgba(255,255,255,.5)}
.ps-btn--outline-light:hover{background:rgba(255,255,255,.1);border-color:#fff}
.ps-center{text-align:center}
.ps-center .ps-lead{margin-inline:auto}

/* =========================================================
   HERO — boutique dressing room scene
   ========================================================= */
.ps-hero{position:relative;min-height:100vh;overflow:hidden;background:var(--ps-champ);display:flex;align-items:center}

/* Dressing room */
.ps-room{position:absolute;inset:0;overflow:hidden}

/* Wallpaper */
.ps-room__wall{position:absolute;inset:0;background:linear-gradient(180deg,#f0dfc8,#e8d4b8)}
.ps-room__wall::before{content:'';position:absolute;inset:0;background-image:repeating-linear-gradient(45deg,rgba(181,68,110,.04) 0,rgba(181,68,110,.04) 1px,transparent 1px,transparent 20px),repeating-linear-gradient(-45deg,rgba(181,68,110,.04) 0,rgba(181,68,110,.04) 1px,transparent 1px,transparent 20px)}

/* Wainscoting */
.ps-room__dado{position:absolute;top:45%;left:0;right:0;height:8px;background:linear-gradient(180deg,#c8b49a,#b8a48a,#c8b49a)}
.ps-room__lower{position:absolute;top:45%;bottom:16%;left:0;right:0;background:linear-gradient(180deg,#e0cdb0,#d0b898)}

/* Floor */
.ps-room__floor{position:absolute;bottom:0;left:0;right:0;height:16%;background:linear-gradient(180deg,#8a6a4a,#6a4a2a)}
.ps-room__floor::before{content:'';position:absolute;inset:0;background-image:repeating-linear-gradient(90deg,rgba(255,255,255,.07) 0,rgba(255,255,255,.07) 1px,transparent 1px,transparent 80px)}
.ps-room__skirting{position:absolute;bottom:16%;left:0;right:0;height:6px;background:linear-gradient(180deg,#e8d8c8,#d8c8b8);box-shadow:0 2px 4px rgba(0,0,0,.1)}

/* Large mirror */
.ps-mirror{position:absolute;top:5%;right:14%;width:110px;height:200px;background:linear-gradient(135deg,rgba(245,230,210,.6),rgba(200,180,160,.4));border:5px solid #c8a880;border-radius:50% 50% 8px 8px;box-shadow:inset 0 0 20px rgba(255,255,255,.4),4px 4px 20px rgba(0,0,0,.15)}
.ps-mirror::before{content:'';position:absolute;top:10px;left:10px;right:10px;bottom:10px;background:linear-gradient(135deg,rgba(255,255,255,.5) 0%,rgba(255,255,255,.1) 50%,transparent 100%);border-radius:40% 40% 4px 4px}
.ps-mirror::after{content:'';position:absolute;bottom:-30px;left:50%;transform:translateX(-50%);width:30px;height:30px;background:#c8a880;border-radius:50% 50% 0 0}

/* Clothes rack */
.ps-rack{position:absolute;bottom:16%;right:8%;pointer-events:none}
.ps-rack__rod{width:160px;height:6px;background:linear-gradient(180deg,#c8b090,#a89070);border-radius:3px;position:relative}
.ps-rack__rod::before{content:'';position:absolute;left:-4px;top:-16px;width:4px;height:22px;background:#b0906a;border-radius:2px}
.ps-rack__rod::after{content:'';position:absolute;right:-4px;top:-16px;width:4px;height:22px;background:#b0906a;border-radius:2px}
.ps-rack__items{display:flex;gap:6px;padding:0 8px;justify-content:center;padding-top:2px}
.ps-garment{display:flex;flex-direction:column;align-items:center}
.ps-garment__hanger{width:0;height:0;border-left:8px solid transparent;border-right:8px solid transparent;border-bottom:10px solid #8a6a4a;position:relative}
.ps-garment__hanger::after{content:'';position:absolute;top:10px;left:50%;transform:translateX(-50%);width:2px;height:6px;background:#8a6a4a}
.ps-garment__body{border-radius:2px 2px 4px 4px;margin-top:0}
.ps-garment--dress{clip-path:polygon(20% 0%,80% 0%,100% 100%,0% 100%)}
.ps-garment--jacket{clip-path:polygon(0% 0%,100% 0%,90% 100%,10% 100%)}

/* Stylist figure */
.ps-stylist{position:absolute;bottom:16%;right:36%;display:flex;flex-direction:column;align-items:center;pointer-events:none}
.ps-stylist__head{width:30px;height:32px;background:radial-gradient(circle at 40% 35%,#ffe0c0,#d4a070);border-radius:50%;position:relative}
.ps-stylist__head::before{content:'';position:absolute;top:-8px;left:-2px;right:-2px;height:14px;background:linear-gradient(180deg,var(--ps-rose),var(--ps-rose-d));border-radius:50% 50% 0 0}
.ps-stylist__neck{width:12px;height:10px;background:linear-gradient(180deg,#d4a070,#c09060)}
.ps-stylist__body{width:48px;height:64px;background:linear-gradient(180deg,#fff,#f0ece8);border-radius:4px 4px 0 0;position:relative}
.ps-stylist__body::before{content:'';position:absolute;top:0;left:50%;transform:translateX(-50%);width:32px;height:64px;background:linear-gradient(180deg,var(--ps-rose),var(--ps-rose-d));border-radius:4px 4px 0 0;opacity:.9}
.ps-stylist__clipboard{position:absolute;right:-28px;top:10px;width:20px;height:26px;background:linear-gradient(180deg,#fff,#f5f0eb);border-radius:2px;border:1px solid rgba(0,0,0,.15)}
.ps-stylist__clipboard::before{content:'';position:absolute;top:4px;left:4px;right:4px;height:2px;background:rgba(0,0,0,.2);box-shadow:0 4px 0 rgba(0,0,0,.1),0 8px 0 rgba(0,0,0,.1)}

/* Mannequin */
.ps-mannequin{position:absolute;bottom:16%;left:16%;display:flex;flex-direction:column;align-items:center;pointer-events:none}
.ps-mannequin__head{width:24px;height:28px;background:linear-gradient(180deg,#e0d0c0,#c8b8a8);border-radius:50%;margin-bottom:2px}
.ps-mannequin__neck{width:10px;height:12px;background:linear-gradient(180deg,#c8b8a8,#b8a898)}
.ps-mannequin__torso{width:50px;height:70px;background:linear-gradient(180deg,#B5446E,#8a2a50);border-radius:4px 4px 8px 8px;position:relative}
.ps-mannequin__torso::before{content:'👗';position:absolute;top:6px;left:50%;transform:translateX(-50%);font-size:1.6rem;opacity:.3}
.ps-mannequin__stand{width:8px;height:40px;background:linear-gradient(90deg,#b0a090,#a09080)}
.ps-mannequin__base{width:50px;height:8px;background:linear-gradient(180deg,#a09080,#908070);border-radius:3px}

/* Vanity table */
.ps-vanity{position:absolute;bottom:16%;left:5%;pointer-events:none}
.ps-vanity__top{width:90px;height:10px;background:linear-gradient(180deg,#e8d8c8,#d8c8b8);border-radius:2px;box-shadow:0 2px 6px rgba(0,0,0,.12)}
.ps-vanity__body{width:90px;height:50px;background:linear-gradient(180deg,#d8c8b8,#c8b8a8);border-radius:0 0 4px 4px;display:flex;align-items:center;justify-content:center;gap:8px;padding:0 10px}
.ps-vanity__item{width:12px;border-radius:50% 50% 2px 2px;opacity:.9}
.ps-vanity__legs{display:flex;justify-content:space-between;padding:0 8px;height:20px}
.ps-vanity__leg{width:6px;background:linear-gradient(90deg,#b0a090,#a09080)}

/* Floating particles */
.ps-particle{position:absolute;font-size:var(--sz);opacity:var(--op);color:var(--ps-rose);animation:ps-drift var(--dur)s ease-in-out var(--delay)s infinite alternate;pointer-events:none;will-change:transform}
@keyframes ps-drift{0%{transform:translateY(0) rotate(0deg)}100%{transform:translateY(-14px) rotate(15deg)}}

/* Overlay */
.ps-hero__overlay{position:absolute;inset:0;background:linear-gradient(90deg,rgba(245,230,208,.96) 0%,rgba(245,230,208,.8) 45%,rgba(245,230,208,.15) 72%,transparent 100%)}

/* Hero content */
.ps-hero__content{position:relative;z-index:10;padding:0 5%;max-width:560px}
.ps-hero__tag{display:inline-block;background:rgba(181,68,110,.1);border:1px solid rgba(181,68,110,.3);color:var(--ps-rose);font-size:.68rem;font-weight:600;letter-spacing:.2em;text-transform:uppercase;padding:6px 16px;border-radius:2px;margin-bottom:24px}
.ps-hero__title{font-family:var(--ps-ff-head);font-size:clamp(2.8rem,6vw,5rem);font-weight:400;line-height:1;color:var(--ps-char);margin-bottom:8px}
.ps-hero__title em{font-style:italic;color:var(--ps-rose)}
.ps-hero__sub{font-family:var(--ps-ff-head);font-size:clamp(1rem,2vw,1.3rem);font-style:italic;font-weight:400;color:var(--ps-rose);margin-bottom:24px}
.ps-hero__body{font-size:.93rem;line-height:1.8;color:var(--ps-muted);font-weight:300;margin-bottom:36px;max-width:480px}
.ps-hero__ctas{display:flex;flex-wrap:wrap;gap:12px}
.ps-hero__trust{display:flex;flex-wrap:wrap;gap:10px;margin-top:28px}
.ps-hero__trust-item{font-size:.75rem;color:var(--ps-muted);font-weight:500;display:flex;align-items:center;gap:6px}
.ps-hero__trust-item::before{content:'✓';color:var(--ps-rose);font-weight:700}

/* Trust bar */
.ps-trust{background:var(--ps-rose);padding:18px 0}
.ps-trust__inner{display:flex;flex-wrap:wrap;justify-content:center;gap:6px 32px}
.ps-trust__item{font-size:.78rem;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.88);display:flex;align-items:center;gap:8px}
.ps-trust__item::before{content:'✦';color:rgba(255,255,255,.6);font-size:.6rem}

/* =========================================================
   SERVICES
   ========================================================= */
.ps-services{background:var(--ps-cream)}
.ps-services__grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:24px;margin-top:52px}
.ps-service-card{background:#fff;border-radius:var(--ps-radius);padding:32px 26px;border:1px solid rgba(181,68,110,.08);transition:all .3s;position:relative;overflow:hidden}
.ps-service-card::after{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,var(--ps-rose),var(--ps-gold));transform:scaleX(0);transition:transform .3s}
.ps-service-card:hover{box-shadow:var(--ps-shadow);transform:translateY(-4px)}
.ps-service-card:hover::after{transform:scaleX(1)}
.ps-service-card__icon{font-size:1.8rem;margin-bottom:14px;display:block}
.ps-service-card__title{font-family:var(--ps-ff-head);font-size:1.2rem;font-weight:500;color:var(--ps-char);margin-bottom:8px}
.ps-service-card__desc{font-size:.87rem;line-height:1.72;color:var(--ps-muted);font-weight:300}

/* =========================================================
   PROCESS
   ========================================================= */
.ps-process{background:linear-gradient(135deg,var(--ps-blush),#f5e0ea);padding:90px 0}
.ps-process .ps-eyebrow{color:var(--ps-rose-d)}
.ps-process__grid{display:grid;grid-template-columns:repeat(5,1fr);gap:20px;margin-top:52px}
.ps-pstep{text-align:center;padding:28px 14px}
.ps-pstep__num{font-family:var(--ps-ff-head);font-size:3rem;font-style:italic;font-weight:400;color:rgba(181,68,110,.18);line-height:1;margin-bottom:-12px}
.ps-pstep__title{font-family:var(--ps-ff-head);font-size:1rem;font-weight:500;color:var(--ps-char);margin-bottom:8px;position:relative;z-index:1}
.ps-pstep__desc{font-size:.82rem;line-height:1.65;color:var(--ps-muted);font-weight:300}

/* =========================================================
   GALLERY
   ========================================================= */
.ps-gallery{background:#fff}
.ps-gallery__grid{display:grid;grid-template-columns:repeat(3,1fr);grid-template-rows:220px 220px;gap:10px;margin-top:52px}
.ps-gallery__item{border-radius:var(--ps-radius);overflow:hidden;position:relative;cursor:pointer}
.ps-gallery__item:first-child{grid-column:span 2}
.ps-gallery__item:nth-child(4){grid-column:span 2}
.ps-gallery__art{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-family:var(--ps-ff-head);font-size:.9rem;font-style:italic;color:rgba(255,255,255,.7);position:relative;overflow:hidden}
.ps-gallery__art::before{content:'';position:absolute;inset:0;background:inherit;filter:brightness(.7);transition:filter .4s}
.ps-gallery__item:hover .ps-gallery__art::before{filter:brightness(.5)}
.ps-gallery__label{position:relative;z-index:1;background:rgba(0,0,0,.3);padding:7px 18px;border-radius:2px}

/* =========================================================
   COUNTERS
   ========================================================= */
.ps-counters{background:var(--ps-char);padding:80px 0}
.ps-counters__grid{display:grid;grid-template-columns:repeat(4,1fr);gap:40px;text-align:center}
.ps-counter__val{font-family:var(--ps-ff-head);font-size:clamp(2.5rem,4.5vw,4rem);font-weight:400;color:#fff;line-height:1}
.ps-counter__label{font-family:var(--ps-ff-body);font-size:.72rem;letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.55);margin-top:8px}

/* =========================================================
   ABOUT
   ========================================================= */
.ps-about{background:var(--ps-cream)}
.ps-about__grid{display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:center}
.ps-about__visual{position:relative}
.ps-polaroid-stack{position:relative;width:100%;max-width:380px}
.ps-polaroid{background:#fff;padding:14px 14px 50px;box-shadow:var(--ps-shadow);border-radius:2px}
.ps-polaroid--back{position:absolute;top:-12px;left:-10px;transform:rotate(-4deg);background:#fff;width:90%;height:90%;padding:14px 14px 50px;box-shadow:0 4px 16px rgba(0,0,0,.08)}
.ps-polaroid__img{width:100%;aspect-ratio:3/4;background:linear-gradient(160deg,var(--ps-champ),#ead8c0);border-radius:1px;display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden}
.ps-polaroid__fig{position:absolute;bottom:0;left:50%;transform:translateX(-50%);display:flex;flex-direction:column;align-items:center;width:60%}
.ps-polaroid__fig-head{width:44px;height:48px;background:radial-gradient(circle at 40% 35%,#ffe0c0,#d4a070);border-radius:50%;margin-bottom:4px}
.ps-polaroid__fig-body{width:70%;height:100px;background:linear-gradient(180deg,var(--ps-rose),var(--ps-rose-d));border-radius:6px 6px 0 0}
.ps-polaroid__caption{font-family:var(--ps-ff-head);font-size:.9rem;font-style:italic;color:var(--ps-muted);text-align:center;margin-top:10px}
.ps-award{position:absolute;bottom:-20px;right:-16px;background:var(--ps-gold);border-radius:var(--ps-radius);padding:14px 18px;box-shadow:var(--ps-shadow);text-align:center;min-width:130px}
.ps-award__val{font-family:var(--ps-ff-head);font-size:1.6rem;font-weight:600;color:#fff;line-height:1}
.ps-award__label{font-size:.68rem;letter-spacing:.06em;text-transform:uppercase;color:rgba(255,255,255,.85);margin-top:4px;font-weight:600}
.ps-about__quote{font-family:var(--ps-ff-head);font-size:1.3rem;font-style:italic;color:var(--ps-char);border-left:2px solid var(--ps-rose);padding-left:18px;margin:24px 0;line-height:1.5}
.ps-about__bio{font-size:.93rem;line-height:1.8;color:var(--ps-muted);font-weight:300;margin-bottom:16px}
.ps-about__creds{display:flex;flex-wrap:wrap;gap:8px;margin:20px 0}
.ps-about__cred{font-size:.72rem;font-weight:600;letter-spacing:.06em;color:var(--ps-rose);background:rgba(181,68,110,.08);border:1px solid rgba(181,68,110,.2);padding:5px 12px;border-radius:2px;text-transform:uppercase}

/* =========================================================
   PACKAGES
   ========================================================= */
.ps-packages{background:#fff}
.ps-packages__grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:52px}
.ps-pkg{background:var(--ps-cream);border-radius:var(--ps-radius);padding:36px 28px;border:1.5px solid rgba(181,68,110,.1);transition:all .3s;position:relative}
.ps-pkg:hover{box-shadow:var(--ps-shadow)}
.ps-pkg--featured{border-color:var(--ps-rose);background:linear-gradient(180deg,rgba(181,68,110,.04),var(--ps-cream))}
.ps-pkg--featured::before{content:'Most Popular';position:absolute;top:-14px;left:50%;transform:translateX(-50%);background:var(--ps-rose);color:#fff;font-size:.64rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;padding:4px 16px;border-radius:20px;white-space:nowrap;font-family:var(--ps-ff-body)}
.ps-pkg__name{font-family:var(--ps-ff-head);font-size:1.3rem;font-style:italic;font-weight:500;color:var(--ps-char);margin-bottom:4px}
.ps-pkg__sub{font-size:.78rem;color:var(--ps-muted);margin-bottom:20px;font-weight:300}
.ps-pkg__price{font-family:var(--ps-ff-head);font-size:2.2rem;color:var(--ps-rose);margin-bottom:24px;line-height:1}
.ps-pkg__list{display:flex;flex-direction:column;gap:10px;margin-bottom:28px}
.ps-pkg__list li{display:flex;align-items:flex-start;gap:8px;font-size:.86rem;color:var(--ps-text);line-height:1.5;font-weight:300}
.ps-pkg__list li::before{content:'✦';color:var(--ps-gold);flex-shrink:0;font-size:.7rem;margin-top:3px}

/* =========================================================
   TESTIMONIALS
   ========================================================= */
.ps-testimonials{background:var(--ps-champ)}
.ps-testi-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:52px}
.ps-testi{background:#fff;border-radius:var(--ps-radius);padding:30px 26px;position:relative;box-shadow:0 4px 16px rgba(181,68,110,.06)}
.ps-testi::before{content:'❝';position:absolute;top:-12px;left:24px;font-size:3rem;color:var(--ps-rose);opacity:.15;font-family:Georgia,serif;line-height:1}
.ps-testi__stars{color:var(--ps-gold);font-size:.9rem;letter-spacing:2px;margin-bottom:14px}
.ps-testi__text{font-family:var(--ps-ff-head);font-size:1rem;font-style:italic;line-height:1.7;color:var(--ps-char);margin-bottom:18px}
.ps-testi__author{font-size:.78rem;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:var(--ps-rose)}
.ps-testi__loc{font-size:.74rem;color:var(--ps-muted);font-weight:300}

/* =========================================================
   BOOKING
   ========================================================= */
.ps-booking{background:linear-gradient(135deg,var(--ps-char),#1a1a1a);padding:90px 0}
.ps-booking .ps-eyebrow{color:var(--ps-gold)}
.ps-booking__grid{display:grid;grid-template-columns:1fr 1.6fr;gap:60px;align-items:start;margin-top:52px}
.ps-booking__info-title{font-family:var(--ps-ff-head);font-size:1.6rem;font-style:italic;color:#fff;margin-bottom:20px}
.ps-booking__info-item{display:flex;align-items:flex-start;gap:14px;margin-bottom:22px}
.ps-booking__info-icon{font-size:1.3rem;flex-shrink:0;margin-top:2px}
.ps-booking__info-label{font-size:.72rem;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.55);margin-bottom:4px}
.ps-booking__info-text{font-size:.85rem;line-height:1.6;color:rgba(255,255,255,.65);font-weight:300}
.ps-form{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--ps-radius);padding:38px 34px;backdrop-filter:blur(8px)}
.ps-form__row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.ps-form__group{margin-bottom:16px;display:flex;flex-direction:column;gap:6px}
.ps-form__group label{font-size:.7rem;font-weight:600;letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.6)}
.ps-form__group input,
.ps-form__group select,
.ps-form__group textarea{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.14);border-radius:2px;padding:11px 14px;font-family:var(--ps-ff-body);font-size:.88rem;color:#fff;outline:none;transition:border-color .25s;width:100%;font-weight:300}
.ps-form__group input::placeholder,
.ps-form__group textarea::placeholder{color:rgba(255,255,255,.3)}
.ps-form__group input:focus,
.ps-form__group select:focus,
.ps-form__group textarea:focus{border-color:var(--ps-rose);background:rgba(255,255,255,.1)}
.ps-form__group select option{background:#1a1a1a;color:#fff}
.ps-form__group textarea{resize:vertical;min-height:100px}
.ps-form__submit{width:100%;padding:15px;background:var(--ps-rose);border:none;border-radius:2px;font-family:var(--ps-ff-body);font-size:.9rem;font-weight:600;letter-spacing:.12em;text-transform:uppercase;color:#fff;cursor:pointer;transition:all .25s;margin-top:6px}
.ps-form__submit:hover{background:var(--ps-rose-d);transform:translateY(-2px)}
.ps-form__consent{font-size:.7rem;color:rgba(255,255,255,.4);margin-top:10px;line-height:1.6;text-align:center;font-weight:300}

/* =========================================================
   FOOTER
   ========================================================= */
.ps-footer{background:#111;padding:26px 0}
.ps-footer__inner{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:16px}
.ps-footer__copy{font-size:.76rem;color:rgba(255,255,255,.35);font-weight:300}
.ps-footer__links{display:flex;gap:20px}
.ps-footer__links a{font-size:.76rem;color:rgba(255,255,255,.35);transition:color .2s;font-weight:300}
.ps-footer__links a:hover{color:var(--ps-rose)}

/* =========================================================
   RESPONSIVE
   ========================================================= */
@media(max-width:960px){
    .ps-about__grid,.ps-booking__grid{grid-template-columns:1fr}
    .ps-packages__grid,.ps-testi-grid{grid-template-columns:1fr}
    .ps-counters__grid{grid-template-columns:repeat(2,1fr)}
    .ps-process__grid{grid-template-columns:repeat(3,1fr)}
    .ps-gallery__grid{grid-template-columns:1fr 1fr}
    .ps-gallery__item:first-child,.ps-gallery__item:nth-child(4){grid-column:span 1}
}
@media(max-width:600px){
    .ps-section{padding:60px 0}
    .ps-form__row{grid-template-columns:1fr}
    .ps-process__grid{grid-template-columns:repeat(2,1fr)}
}
</style>
<?php get_header(); ?>
<div class="ps-page">
>

<!-- ═══════════════════════════════════════════════
     HERO
═══════════════════════════════════════════════ -->
<section class="ps-hero" id="ps-hero">
    <div class="ps-room" aria-hidden="true">
        <div class="ps-room__wall"></div>
        <div class="ps-room__dado"></div>
        <div class="ps-room__lower"></div>

        <!-- Vanity table -->
        <div class="ps-vanity">
            <div class="ps-vanity__top"></div>
            <div class="ps-vanity__body">
                <?php
                $vanity_colors = ['#B5446E','#C9A84C','#E63946','#6B52B0','#2C2C2C'];
                $vanity_heights = [28,36,24,32,28];
                for ($v=0; $v<5; $v++): ?>
                <div class="ps-vanity__item" style="background:<?php echo $vanity_colors[$v]; ?>;height:<?php echo $vanity_heights[$v]; ?>px"></div>
                <?php endfor; ?>
            </div>
            <div class="ps-vanity__legs">
                <div class="ps-vanity__leg"></div>
                <div class="ps-vanity__leg"></div>
            </div>
        </div>

        <!-- Mannequin -->
        <div class="ps-mannequin">
            <div class="ps-mannequin__head"></div>
            <div class="ps-mannequin__neck"></div>
            <div class="ps-mannequin__torso"></div>
            <div class="ps-mannequin__stand"></div>
            <div class="ps-mannequin__base"></div>
        </div>

        <!-- Mirror -->
        <div class="ps-mirror"></div>

        <!-- Clothes rack -->
        <div class="ps-rack">
            <div class="ps-rack__rod">
                <div class="ps-rack__items">
                    <?php foreach ($rack_items as $ri): ?>
                    <div class="ps-garment">
                        <div class="ps-garment__hanger"></div>
                        <div class="ps-garment__body ps-garment--<?php echo $ri['style']; ?>" style="background:<?php echo esc_attr($ri['color']); ?>;width:<?php echo $ri['width']; ?>px;height:<?php echo ($ri['style']==='dress') ? '52px' : '42px'; ?>"></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Stylist figure -->
        <div class="ps-stylist">
            <div class="ps-stylist__head"></div>
            <div class="ps-stylist__neck"></div>
            <div class="ps-stylist__body">
                <div class="ps-stylist__clipboard"></div>
            </div>
        </div>

        <!-- Skirting + floor -->
        <div class="ps-room__skirting"></div>
        <div class="ps-room__floor"></div>

        <!-- Floating particles -->
        <?php foreach ($ps_floaters as $fl): ?>
        <div class="ps-particle"
             style="left:<?php echo $fl['x']; ?>%;top:<?php echo $fl['y']; ?>%;--sz:<?php echo $fl['size']; ?>px;--op:<?php echo $fl['op']; ?>;--dur:<?php echo $fl['dur']; ?>;--delay:<?php echo $fl['delay']; ?>s"
             data-depth="<?php echo $fl['depth']; ?>"><?php echo $fl['char']; ?></div>
        <?php endforeach; ?>
    </div>

    <!-- Overlay -->
    <div class="ps-hero__overlay" aria-hidden="true"></div>

    <!-- Hero content -->
    <div class="ps-container">
        <div class="ps-hero__content">
            <span class="ps-hero__tag">Personal Stylist · Image Consultant · London</span>
            <h1 class="ps-hero__title">Look like<br>the best version<br>of <em>yourself.</em></h1>
            <p class="ps-hero__sub">Style that tells your story — without saying a word</p>
            <p class="ps-hero__body">
                Whether you're reinventing your wardrobe from scratch, preparing for a career transition or simply tired of having nothing to wear, I help women and men dress with intention, confidence and effortless style.
            </p>
            <div class="ps-hero__ctas">
                <a href="#ps-booking" class="ps-btn ps-btn--primary">Book a Discovery Call</a>
                <a href="#ps-services" class="ps-btn ps-btn--outline-dark">Explore Services</a>
            </div>
            <div class="ps-hero__trust">
                <span class="ps-hero__trust-item">Free discovery call</span>
                <span class="ps-hero__trust-item">Colour &amp; body analysis</span>
                <span class="ps-hero__trust-item">500+ clients transformed</span>
                <span class="ps-hero__trust-item">Virtual sessions available</span>
            </div>
        </div>
    </div>
</section>

<!-- Trust bar -->
<div class="ps-trust">
    <div class="ps-container">
        <div class="ps-trust__inner">
            <?php
            $ps_trust = ['Free 20-Min Discovery Call','In-Person & Virtual Sessions','All Budgets Welcome','100% Personalised Service','Exclusive Shopping Access','Ongoing Style Support'];
            foreach ($ps_trust as $ti): ?>
            <span class="ps-trust__item"><?php echo esc_html($ti); ?></span>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ═══════════════════════════════════════════════
     SERVICES
═══════════════════════════════════════════════ -->
<section class="ps-section ps-services" id="ps-services">
    <div class="ps-container">
        <div class="ps-center">
            <span class="ps-eyebrow">What I Offer</span>
            <h2 class="ps-heading">Styling <em>Services</em></h2>
            <p class="ps-lead">From a single session to a full wardrobe overhaul — every service is designed around you, your life and the image you want to project.</p>
        </div>
        <div class="ps-services__grid">
            <?php foreach ($ps_services as $svc): ?>
            <article class="ps-service-card">
                <span class="ps-service-card__icon"><?php echo esc_html($svc['icon']); ?></span>
                <h3 class="ps-service-card__title"><?php echo esc_html($svc['title']); ?></h3>
                <p class="ps-service-card__desc"><?php echo esc_html($svc['desc']); ?></p>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     PROCESS
═══════════════════════════════════════════════ -->
<section class="ps-section ps-process" id="ps-process">
    <div class="ps-container">
        <div class="ps-center">
            <span class="ps-eyebrow">How It Works</span>
            <h2 class="ps-heading">Your <em>Style Journey</em></h2>
            <p class="ps-lead">A structured five-step process that goes far beyond shopping — building a wardrobe that reflects who you truly are, with pieces that work hard and feel effortless.</p>
        </div>
        <div class="ps-process__grid">
            <?php foreach ($ps_process as $step): ?>
            <div class="ps-pstep">
                <div class="ps-pstep__num"><?php echo esc_html($step['num']); ?></div>
                <h3 class="ps-pstep__title"><?php echo esc_html($step['title']); ?></h3>
                <p class="ps-pstep__desc"><?php echo esc_html($step['desc']); ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     GALLERY
═══════════════════════════════════════════════ -->
<section class="ps-section ps-gallery" id="ps-gallery">
    <div class="ps-container">
        <div class="ps-center">
            <span class="ps-eyebrow">The Work</span>
            <h2 class="ps-heading">Style <em>Portfolio</em></h2>
        </div>
        <div class="ps-gallery__grid">
            <?php foreach ($ps_gallery as $gitem): ?>
            <div class="ps-gallery__item">
                <div class="ps-gallery__art" style="background:linear-gradient(135deg,<?php echo esc_attr($gitem['c1']); ?>,<?php echo esc_attr($gitem['c2']); ?>)">
                    <span class="ps-gallery__label"><?php echo esc_html($gitem['label']); ?></span>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     COUNTERS
═══════════════════════════════════════════════ -->
<section class="ps-counters" aria-label="Stylist statistics">
    <div class="ps-container">
        <div class="ps-counters__grid">
            <div class="ps-counter">
                <div class="ps-counter__val" data-target="12" data-suffix="yrs">0</div>
                <div class="ps-counter__label">Years' Experience</div>
            </div>
            <div class="ps-counter">
                <div class="ps-counter__val" data-target="500" data-suffix="+">0</div>
                <div class="ps-counter__label">Clients Transformed</div>
            </div>
            <div class="ps-counter">
                <div class="ps-counter__val" data-target="4.9" data-suffix="★" data-float="1">0</div>
                <div class="ps-counter__label">Average Rating</div>
            </div>
            <div class="ps-counter">
                <div class="ps-counter__val" data-target="98" data-suffix="%">0</div>
                <div class="ps-counter__label">Would Recommend</div>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     ABOUT
═══════════════════════════════════════════════ -->
<section class="ps-section ps-about" id="ps-about">
    <div class="ps-container">
        <div class="ps-about__grid">
            <div class="ps-about__visual">
                <div class="ps-polaroid-stack">
                    <div class="ps-polaroid ps-polaroid--back"></div>
                    <div class="ps-polaroid">
                        <div class="ps-polaroid__img">
                            <div class="ps-polaroid__fig">
                                <div class="ps-polaroid__fig-head"></div>
                                <div class="ps-polaroid__fig-body"></div>
                            </div>
                        </div>
                        <div class="ps-polaroid__caption">Your stylist · Ready to help</div>
                    </div>
                </div>
                <div class="ps-award">
                    <div class="ps-award__val">500+</div>
                    <div class="ps-award__label">Clients Styled</div>
                </div>
            </div>
            <div class="ps-about__content">
                <span class="ps-eyebrow">About Me</span>
                <h2 class="ps-heading">Sophie Beaumont<br><small style="font-size:.5em;color:var(--ps-muted);font-style:normal;font-weight:300">Personal Stylist · Image Consultant · London</small></h2>
                <blockquote class="ps-about__quote">
                    "Style isn't about following trends — it's about knowing yourself well enough to wear only what makes you feel extraordinary."
                </blockquote>
                <p class="ps-about__bio">
                    With twelve years styling everyone from executives to new mothers, I've learned that confidence isn't something you find — it's something you build, piece by piece, in your wardrobe. My approach blends technical expertise with genuine curiosity about who you are and who you want to become.
                </p>
                <div class="ps-about__creds">
                    <span class="ps-about__cred">London College of Fashion</span>
                    <span class="ps-about__cred">CIBT Certified</span>
                    <span class="ps-about__cred">Colour Me Beautiful</span>
                    <span class="ps-about__cred">Press Featured</span>
                </div>
                <a href="#ps-booking" class="ps-btn ps-btn--primary">Work with Sophie →</a>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     PACKAGES
═══════════════════════════════════════════════ -->
<section class="ps-section ps-packages" id="ps-packages">
    <div class="ps-container">
        <div class="ps-center">
            <span class="ps-eyebrow">Investment</span>
            <h2 class="ps-heading">Choose Your <em>Package</em></h2>
            <p class="ps-lead">Every package includes a personalised approach — because your style is as unique as you are. Payment plans available on all packages.</p>
        </div>
        <div class="ps-packages__grid">
            <?php foreach ($ps_packages as $pkg): ?>
            <div class="ps-pkg<?php echo $pkg['featured'] ? ' ps-pkg--featured' : ''; ?>">
                <div class="ps-pkg__name"><?php echo esc_html($pkg['name']); ?></div>
                <div class="ps-pkg__sub"><?php echo esc_html($pkg['sub']); ?></div>
                <div class="ps-pkg__price"><?php echo esc_html($pkg['price']); ?></div>
                <ul class="ps-pkg__list">
                    <?php foreach ($pkg['items'] as $item): ?>
                    <li><?php echo esc_html($item); ?></li>
                    <?php endforeach; ?>
                </ul>
                <a href="#ps-booking" class="ps-btn ps-btn--<?php echo $pkg['featured'] ? 'primary' : 'outline-dark'; ?>" style="width:100%;justify-content:center">Book Now</a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     TESTIMONIALS
═══════════════════════════════════════════════ -->
<section class="ps-section ps-testimonials" id="ps-testimonials">
    <div class="ps-container">
        <div class="ps-center">
            <span class="ps-eyebrow">Client Stories</span>
            <h2 class="ps-heading">Real <em>Transformations</em></h2>
        </div>
        <div class="ps-testi-grid">
            <?php foreach ($ps_testimonials as $testi): ?>
            <div class="ps-testi">
                <div class="ps-testi__stars"><?php echo str_repeat('★',$testi['stars']); ?></div>
                <p class="ps-testi__text">"<?php echo esc_html($testi['text']); ?>"</p>
                <div class="ps-testi__author"><?php echo esc_html($testi['name']); ?></div>
                <div class="ps-testi__loc"><?php echo esc_html($testi['loc']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     BOOKING
═══════════════════════════════════════════════ -->
<section class="ps-booking" id="ps-booking">
    <div class="ps-container">
        <div class="ps-center">
            <span class="ps-eyebrow">Book Your Session</span>
            <h2 class="ps-heading ps-heading--light">Ready to <em style="color:var(--ps-gold)">Transform</em>?</h2>
            <p class="ps-lead" style="color:rgba(255,255,255,.65);margin-inline:auto">Every journey starts with a free 20-minute discovery call. Tell me about you, your lifestyle and what you'd like to change.</p>
        </div>
        <div class="ps-booking__grid">
            <div>
                <div class="ps-booking__info-title">Let's create your signature style together.</div>
                <div class="ps-booking__info-item">
                    <span class="ps-booking__info-icon">📍</span>
                    <div>
                        <div class="ps-booking__info-label">Location</div>
                        <div class="ps-booking__info-text">Based in London. In-person sessions across London &amp; SE England. Virtual sessions worldwide.</div>
                    </div>
                </div>
                <div class="ps-booking__info-item">
                    <span class="ps-booking__info-icon">🕐</span>
                    <div>
                        <div class="ps-booking__info-label">Availability</div>
                        <div class="ps-booking__info-text">Mon–Sat, flexible hours. Evening &amp; weekend sessions by arrangement.</div>
                    </div>
                </div>
                <div class="ps-booking__info-item">
                    <span class="ps-booking__info-icon">📧</span>
                    <div>
                        <div class="ps-booking__info-label">Quick Enquiry</div>
                        <div class="ps-booking__info-text">hello@sophiebeaumont.com<br>Usually replies within 12 hours</div>
                    </div>
                </div>
                <div class="ps-booking__info-item">
                    <span class="ps-booking__info-icon">💳</span>
                    <div>
                        <div class="ps-booking__info-label">Payment</div>
                        <div class="ps-booking__info-text">All major cards, bank transfer. Interest-free payment plans available on packages over £300.</div>
                    </div>
                </div>
            </div>
            <div>
                <form class="ps-form" method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
                    <?php wp_nonce_field('tf_ps_booking','tf_ps_nonce'); ?>
                    <input type="hidden" name="action" value="tf_ps_booking">
                    <div class="ps-form__row">
                        <div class="ps-form__group">
                            <label for="ps-name">Full Name *</label>
                            <input type="text" id="ps-name" name="ps_name" required placeholder="Your full name">
                        </div>
                        <div class="ps-form__group">
                            <label for="ps-email">Email Address *</label>
                            <input type="email" id="ps-email" name="ps_email" required placeholder="your@email.com">
                        </div>
                    </div>
                    <div class="ps-form__row">
                        <div class="ps-form__group">
                            <label for="ps-phone">Phone Number</label>
                            <input type="tel" id="ps-phone" name="ps_phone" placeholder="07700 900000">
                        </div>
                        <div class="ps-form__group">
                            <label for="ps-service">Interested In *</label>
                            <select id="ps-service" name="ps_service" required>
                                <option value="">Select service…</option>
                                <option>Style Starter Session</option>
                                <option>Full Transformation Package</option>
                                <option>VIP Style Day</option>
                                <option>Wardrobe Edit Only</option>
                                <option>Personal Shopping</option>
                                <option>Corporate Image</option>
                                <option>Occasion Styling</option>
                            </select>
                        </div>
                    </div>
                    <div class="ps-form__row">
                        <div class="ps-form__group">
                            <label for="ps-format">Session Format *</label>
                            <select id="ps-format" name="ps_format" required>
                                <option value="">Select…</option>
                                <option>In-Person (London)</option>
                                <option>Virtual (video call)</option>
                                <option>Either — I'm flexible</option>
                            </select>
                        </div>
                        <div class="ps-form__group">
                            <label for="ps-budget">Approx. Budget</label>
                            <select id="ps-budget" name="ps_budget">
                                <option value="">Select range…</option>
                                <option>£100–£250</option>
                                <option>£250–£500</option>
                                <option>£500–£1,000</option>
                                <option>£1,000+</option>
                                <option>Not Sure Yet</option>
                            </select>
                        </div>
                    </div>
                    <div class="ps-form__group">
                        <label for="ps-goals">Your Style Goals *</label>
                        <textarea id="ps-goals" name="ps_goals" required placeholder="Tell me about your current style challenges and what you'd like to achieve — e.g. wardrobe overhaul, dressing for a new job, finding my personal style…"></textarea>
                    </div>
                    <button type="submit" class="ps-form__submit">Book Your Free Discovery Call →</button>
                    <p class="ps-form__consent">By submitting this form you agree to our privacy policy. Your details will never be shared with third parties.</p>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     FOOTER
═══════════════════════════════════════════════ -->
<footer class="ps-footer">
    <div class="ps-container">
        <div class="ps-footer__inner">
            <p class="ps-footer__copy">&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All rights reserved.</p>
            <nav class="ps-footer__links" aria-label="Footer navigation">
                <a href="<?php echo esc_url(home_url('/privacy-policy')); ?>">Privacy Policy</a>
                <a href="<?php echo esc_url(home_url('/terms')); ?>">Terms</a>
                <a href="<?php echo esc_url(home_url('/accessibility')); ?>">Accessibility</a>
            </nav>
        </div>
    </div>
</footer>


<script>
(function(){
    /* ── Animated Counters ── */
    const counters = document.querySelectorAll('.ps-counter__val[data-target]');
    const easeOut = t => 1 - Math.pow(1 - t, 3);
    const io = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (!entry.isIntersecting) return;
            const el = entry.target;
            const target = parseFloat(el.dataset.target);
            const suffix = el.dataset.suffix || '';
            const isFloat = el.dataset.float === '1';
            if (isNaN(target)) return;
            const dur = 1800;
            let start = null;
            function tick(ts) {
                if (!start) start = ts;
                const prog = Math.min((ts - start) / dur, 1);
                const val = target * easeOut(prog);
                el.textContent = (isFloat ? val.toFixed(1) : Math.round(val)) + suffix;
                if (prog < 1) requestAnimationFrame(tick);
            }
            requestAnimationFrame(tick);
            io.unobserve(el);
        });
    }, { threshold: 0.4 });
    counters.forEach(c => io.observe(c));

    /* ── Mouse parallax on particles ── */
    const particles = document.querySelectorAll('.ps-particle');
    document.getElementById('ps-hero')?.addEventListener('mousemove', e => {
        const rect = e.currentTarget.getBoundingClientRect();
        const dx = (e.clientX - rect.width / 2) / rect.width;
        const dy = (e.clientY - rect.height / 2) / rect.height;
        particles.forEach(p => {
            const d = parseFloat(p.dataset.depth) || 20;
            p.style.transform = `translate(${dx * d}px, ${dy * d}px)`;
        });
    });
})();
</script>
</body>
</html>
</div><!-- .ps-page -->
<?php get_footer(); ?>
