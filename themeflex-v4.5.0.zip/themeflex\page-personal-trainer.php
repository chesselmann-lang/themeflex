<?php
/**
 * Template Name: Personal Trainer – Fitness & Performance Studio
 *
 * Premium personal training studio page for ThemeFlex.
 * Concept : Industrial-chic gym floor at dawn — rubber flooring, rig wall,
 *           kettlebells, barbell rack, motivational neon sign.
 * Palette : Near-black / electric-orange / chalk-white.
 * Fonts   : Bebas Neue (headings) + Outfit (body).
 * Namespace: --pt-*
 *
 * @package ThemeFlex
 */

if ( ! defined( 'ABSPATH' ) ) exit;

srand( crc32( get_the_permalink() ) );

/* ── hero particles ─────────────────────────────── */
$pt_particles = [];
for ( $i = 0; $i < 22; $i++ ) {
    $pt_particles[] = [
        'left'  => rand( 2, 98 ),
        'top'   => rand( 5, 90 ),
        'size'  => rand( 2, 7 ),
        'delay' => rand( 0, 6000 ),
        'dur'   => rand( 3000, 7000 ),
        'type'  => rand( 0, 2 ), // 0=circle 1=diamond 2=star
    ];
}

/* ── kettlebell rack weights ─────────────────────── */
$pt_bells = [ 8, 12, 16, 20, 24, 32 ];

/* ── stats ─────────────────────────────────────── */
$pt_stats = [
    [ 'val' => 850,  'suffix' => '+', 'label' => 'Members Transformed' ],
    [ 'val' => 12,   'suffix' => '',  'label' => 'Years Experience'     ],
    [ 'val' => 4.9,  'suffix' => '★', 'label' => 'Average Rating'      ],
    [ 'val' => 97,   'suffix' => '%', 'label' => 'Goal Achievement Rate'],
];

/* ── programmes ─────────────────────────────────── */
$pt_programmes = [
    [ 'icon' => '💪', 'name' => 'Strength & Power',    'desc' => 'Progressive overload programming to build raw strength, muscle mass and athletic power from the ground up.' ],
    [ 'icon' => '🔥', 'name' => 'Fat Loss & Conditioning', 'desc' => 'High-intensity metabolic training fused with smart nutrition coaching for sustainable, rapid body recomposition.' ],
    [ 'icon' => '🏃', 'name' => 'Athletic Performance', 'desc' => 'Speed, agility and endurance training tailored to your sport — used by amateur and semi-professional athletes.' ],
    [ 'icon' => '🧘', 'name' => 'Mobility & Recovery',  'desc' => 'Targeted stretching, corrective exercise and recovery protocols to keep you pain-free and moving fluidly.' ],
    [ 'icon' => '🥗', 'name' => 'Nutrition Coaching',   'desc' => 'Practical, evidence-based nutrition plans — no fad diets, just food strategies that fit your life and goals.' ],
    [ 'icon' => '📱', 'name' => 'Online Coaching',      'desc' => 'Full remote programme with weekly check-ins, custom plans, video analysis and direct WhatsApp support.' ],
];

/* ── packages ────────────────────────────────────── */
$pt_packages = [
    [
        'name'     => 'Ignite',
        'sessions' => '4 sessions / month',
        'price'    => '£199',
        'period'   => '/mo',
        'features' => [ 'Weekly 1-to-1 session', 'Custom training plan', 'App access', 'Goal tracking' ],
        'highlight'=> false,
    ],
    [
        'name'     => 'Forge',
        'sessions' => '8 sessions / month',
        'price'    => '£349',
        'period'   => '/mo',
        'features' => [ 'Bi-weekly 1-to-1 sessions', 'Advanced training plan', 'Nutrition guide', 'App access', 'WhatsApp support', 'Monthly body analysis' ],
        'highlight'=> true,
    ],
    [
        'name'     => 'Elite',
        'sessions' => '12 sessions / month',
        'price'    => '£479',
        'period'   => '/mo',
        'features' => [ '3× weekly 1-to-1 sessions', 'Periodised programme', 'Full nutrition coaching', 'Supplement advice', 'Priority booking', 'Quarterly photo reviews' ],
        'highlight'=> false,
    ],
];

/* ── team ────────────────────────────────────────── */
$pt_team = [
    [ 'name' => 'Marcus Reid',    'role' => 'Head Coach & Founder',  'spec' => 'Strength & Athletic Performance', 'colour' => '#E8500A' ],
    [ 'name' => 'Sophia Grant',   'role' => 'Fat Loss Specialist',   'spec' => 'Nutrition & Metabolic Conditioning','colour' => '#1E90FF' ],
    [ 'name' => 'Daniel Okafor',  'role' => 'Mobility & Recovery',   'spec' => 'Corrective Exercise & Yoga', 'colour' => '#28A745' ],
    [ 'name' => 'Priya Sharma',   'role' => 'Online Coaching Lead',  'spec' => 'Remote Programming & Endurance', 'colour' => '#9B59B6' ],
];

/* ── process ─────────────────────────────────────── */
$pt_process = [
    [ 'num' => '01', 'title' => 'Free Consultation',   'desc' => 'We sit down to understand your goals, history, lifestyle and any injuries or limitations.' ],
    [ 'num' => '02', 'title' => 'Fitness Assessment',  'desc' => 'Full movement screen, body composition analysis and fitness baseline tests.' ],
    [ 'num' => '03', 'title' => 'Custom Programming',  'desc' => 'Your bespoke plan is built — training, nutrition and recovery all aligned to your specific goal.' ],
    [ 'num' => '04', 'title' => 'Train & Evolve',      'desc' => 'Regular reviews every four weeks ensure your programme stays challenging and results keep coming.' ],
];

/* ── testimonials ────────────────────────────────── */
$pt_testimonials = [
    [ 'name' => 'James O\'Brien',  'role' => 'Lost 18kg in 5 months', 'text' => 'Marcus completely changed my relationship with the gym. I\'ve tried every diet going — this is the first time results have actually stuck. The accountability is everything.' ],
    [ 'name' => 'Chloe Hastings',  'role' => 'Competitive runner',    'text' => 'My 10K time dropped by four minutes after just eight weeks of the Athletic Performance programme. The programming is genuinely world-class.' ],
    [ 'name' => 'Tom Whitfield',   'role' => 'Busy professional',     'text' => 'I travel constantly and thought online coaching wouldn\'t work for me. Sophia proved me completely wrong. Flexible, motivating and it fits around my insane schedule.' ],
];

/* ── FAQs ────────────────────────────────────────── */
$pt_faqs = [
    [ 'q' => 'I haven\'t trained in years — is this suitable for beginners?',
      'a' => 'Absolutely. We start every client with a full assessment and build from your current level. Many of our most successful transformations started from zero fitness.' ],
    [ 'q' => 'How quickly will I see results?',
      'a' => 'Most clients notice tangible changes in energy and strength within two to three weeks. Visible body composition changes typically appear from weeks four to eight depending on your goal and consistency.' ],
    [ 'q' => 'Do I need to follow a strict diet?',
      'a' => 'No fad diets here. We work with your food preferences to build sustainable habits. Our nutrition coaching is practical and flexible — 80% structure, 20% freedom.' ],
    [ 'q' => 'Can I combine in-person and online sessions?',
      'a' => 'Yes. Many clients train with us in-studio and supplement with additional online programming for days they can\'t get in. We build hybrid packages on request.' ],
    [ 'q' => 'Is the studio fully equipped?',
      'a' => 'Our 2,400 sq ft private studio contains full rig, barbells and plates to 300kg, dumbbells, kettlebells, cables, sleds, assault bike and turf track. No queuing, no distractions.' ],
];

get_header();
?>

<style>
/* ══════════════════════════════════════════
   PERSONAL TRAINER — CSS DESIGN SYSTEM
   Namespace: --pt-*
══════════════════════════════════════════ */
@import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@300;400;500;600;700&display=swap');

:root{
    --pt-black   : #0A0A0A;
    --pt-dark    : #141414;
    --pt-panel   : #1C1C1C;
    --pt-border  : #2E2E2E;
    --pt-orange  : #E8500A;
    --pt-amber   : #F59E0B;
    --pt-chalk   : #F0EDE8;
    --pt-mid     : #9A9A9A;
    --pt-white   : #FFFFFF;
    --pt-neon    : #FF6B1A;
    --pt-r       : 0px;
    --pt-font-h  : 'Bebas Neue', sans-serif;
    --pt-font-b  : 'Outfit', sans-serif;
    --pt-shadow  : 0 20px 60px rgba(0,0,0,.6);
    --pt-glow    : 0 0 40px rgba(232,80,10,.35);
}

.pt-wrap *{ box-sizing:border-box; margin:0; padding:0; }
.pt-wrap{ font-family:var(--pt-font-b); color:var(--pt-chalk); background:var(--pt-black); line-height:1.6; }
.pt-container{ max-width:1200px; margin:0 auto; padding:0 32px; }

/* ── Typography ─────────────────────────── */
.pt-h1{ font-family:var(--pt-font-h); font-size:clamp(3.5rem,8vw,7rem); line-height:.95; letter-spacing:.02em; color:var(--pt-white); text-transform:uppercase; }
.pt-h2{ font-family:var(--pt-font-h); font-size:clamp(2.2rem,5vw,3.6rem); letter-spacing:.04em; color:var(--pt-white); text-transform:uppercase; }
.pt-h3{ font-family:var(--pt-font-h); font-size:1.6rem; letter-spacing:.06em; color:var(--pt-white); text-transform:uppercase; }
.pt-lead{ font-size:1.15rem; color:var(--pt-mid); font-weight:300; max-width:600px; }
.pt-overline{ font-family:var(--pt-font-h); font-size:1rem; letter-spacing:.2em; color:var(--pt-orange); text-transform:uppercase; display:block; margin-bottom:.75rem; }
.pt-accent{ color:var(--pt-orange); }

/* ── Buttons ────────────────────────────── */
.pt-btn{
    display:inline-flex; align-items:center; gap:.5rem;
    font-family:var(--pt-font-h); font-size:1.1rem; letter-spacing:.08em;
    padding:.8rem 2.2rem; background:var(--pt-orange); color:var(--pt-white);
    border:none; cursor:pointer; text-decoration:none; text-transform:uppercase;
    transition:background .25s, transform .2s;
}
.pt-btn:hover{ background:var(--pt-neon); transform:translateY(-2px); }
.pt-btn-outline{
    background:transparent; border:2px solid var(--pt-orange); color:var(--pt-orange);
}
.pt-btn-outline:hover{ background:var(--pt-orange); color:var(--pt-white); }
.pt-btn-chalk{
    background:var(--pt-chalk); color:var(--pt-black);
}
.pt-btn-chalk:hover{ background:var(--pt-white); }

/* ── Section spacing ────────────────────── */
.pt-section{ padding:100px 0; }
.pt-section-dark{ background:var(--pt-dark); }
.pt-section-panel{ background:var(--pt-panel); }
.pt-section-header{ text-align:center; margin-bottom:64px; }

/* ══════════════════════════════════════════
   HERO — Industrial gym floor at dawn
══════════════════════════════════════════ */
.pt-hero{
    position:relative; min-height:100vh;
    background:var(--pt-black);
    overflow:hidden; display:flex; align-items:center;
}

/* rubber floor */
.pt-floor{
    position:absolute; bottom:0; left:0; right:0; height:38%;
    background:
        repeating-linear-gradient(90deg, rgba(255,255,255,.04) 0, rgba(255,255,255,.04) 1px, transparent 1px, transparent 50px),
        repeating-linear-gradient(0deg,  rgba(255,255,255,.04) 0, rgba(255,255,255,.04) 1px, transparent 1px, transparent 50px),
        #1A1612;
    border-top:3px solid #2A2520;
}
/* floor lane stripe */
.pt-floor::before{
    content:''; position:absolute; left:50%; top:0; width:3px; height:100%;
    background:var(--pt-orange); transform:translateX(-50%); opacity:.4;
}
/* floor reflection */
.pt-floor::after{
    content:''; position:absolute; top:0; left:0; right:0; height:40%;
    background:linear-gradient(to bottom, rgba(232,80,10,.08) 0%, transparent 100%);
}

/* back wall */
.pt-gym-wall{
    position:absolute; top:0; left:0; right:0; bottom:38%;
    background:
        repeating-linear-gradient(90deg, rgba(255,255,255,.015) 0, rgba(255,255,255,.015) 1px, transparent 1px, transparent 80px),
        linear-gradient(180deg, #0E0E0E 0%, #181410 100%);
}

/* rig wall */
.pt-rig{
    position:absolute; left:5%; top:10%; width:40%; height:72%;
    border:4px solid #333;
}
/* rig top bar */
.pt-rig::before{
    content:''; position:absolute; top:-10px; left:-10px; right:-10px; height:14px;
    background:#3A3A3A; border-radius:4px;
}
/* rig cross bars */
.pt-rig::after{
    content:''; position:absolute; top:25%; left:0; right:0; height:6px;
    background:#2E2E2E;
    box-shadow: 0 100px 0 #2E2E2E, 0 200px 0 #2E2E2E;
}
/* rig vertical dividers */
.pt-rig-v1,.pt-rig-v2{
    position:absolute; top:0; bottom:0; width:5px; background:#2E2E2E;
}
.pt-rig-v1{ left:33%; }
.pt-rig-v2{ left:66%; }

/* pull-up bars on rig */
.pt-bar-row{
    position:absolute; top:8%; left:4%; right:4%;
    display:flex; gap:14px;
}
.pt-bar{
    flex:1; height:10px; background:#4A4A4A; border-radius:5px;
    box-shadow:0 4px 12px rgba(0,0,0,.5);
}

/* neon sign */
.pt-neon-sign{
    position:absolute; top:15%; left:50%; transform:translateX(-50%);
    font-family:var(--pt-font-h); font-size:2.2rem; letter-spacing:.15em;
    color:var(--pt-neon); text-transform:uppercase; white-space:nowrap;
    text-shadow:
        0 0 8px var(--pt-neon),
        0 0 20px var(--pt-neon),
        0 0 40px rgba(232,80,10,.6),
        0 0 80px rgba(232,80,10,.3);
    animation:pt-neon-flicker 6s ease-in-out infinite;
}
.pt-neon-sign::before{
    content:''; position:absolute; bottom:-8px; left:0; right:0; height:2px;
    background:var(--pt-neon); box-shadow:0 0 12px var(--pt-neon);
}

/* barbell on floor */
.pt-barbell{
    position:absolute; bottom:40%; left:50%; transform:translateX(-50%);
    width:600px; height:14px;
}
.pt-bb-bar{
    position:absolute; top:3px; left:80px; right:80px; height:8px;
    background:linear-gradient(90deg,#555,#888,#555);
    border-radius:4px;
    box-shadow:0 2px 8px rgba(0,0,0,.6);
}
.pt-bb-collar{
    position:absolute; top:0; width:24px; height:14px;
    background:#C0C0C0; border-radius:3px;
}
.pt-bb-collar.left { left:78px; }
.pt-bb-collar.right{ right:78px; }
.pt-bb-plate{
    position:absolute; top:0; display:flex; gap:4px; align-items:center;
}
.pt-bb-plate.left { left:0; }
.pt-bb-plate.right{ right:0; flex-direction:row-reverse; }
.pt-plate{
    height:var(--ph); width:22px;
    background:linear-gradient(90deg,var(--pc),color-mix(in srgb,var(--pc) 60%,#000));
    border-radius:3px;
    box-shadow:inset 0 2px 4px rgba(255,255,255,.15);
    margin-top:calc((var(--ph) - 14px) / -2);
}

/* kettlebell rack */
.pt-kb-rack{
    position:absolute; right:4%; bottom:38%; height:54%;
    width:260px;
    background:#1A1A1A;
    border:3px solid #2E2E2E;
    border-bottom:none;
    display:flex; flex-direction:column; justify-content:space-around;
    padding:16px 12px;
}
.pt-kb-row{ display:flex; gap:8px; justify-content:center; }
.pt-kb{
    display:flex; flex-direction:column; align-items:center; gap:0;
}
.pt-kb-body{
    width:var(--kw); height:var(--kh);
    background:radial-gradient(ellipse at 35% 30%, #4A4A4A, #1A1A1A);
    border-radius:50%;
    position:relative;
    box-shadow:0 4px 12px rgba(0,0,0,.7), inset 0 -3px 6px rgba(0,0,0,.4);
}
.pt-kb-body::before{
    content:attr(data-kg); position:absolute; bottom:28%; left:50%; transform:translateX(-50%);
    font-family:var(--pt-font-h); font-size:.65rem; color:rgba(255,255,255,.5); letter-spacing:.05em;
}
.pt-kb-handle{
    width:calc(var(--kw) * .55); height:calc(var(--kh) * .45);
    border:4px solid #3A3A3A;
    border-bottom:none;
    border-radius:50% 50% 0 0;
    margin-bottom:-2px;
    background:transparent;
}

/* hero particles (chalk dust / sparks) */
.pt-particle{
    position:absolute; border-radius:50%;
    background:rgba(232,80,10,.6);
    animation:pt-particle-drift var(--pd) ease-in-out var(--pde) infinite alternate;
    pointer-events:none;
}
.pt-particle.diamond{
    border-radius:0; transform:rotate(45deg);
    background:rgba(240,237,232,.4);
}

/* ── Gym scene card (hero visual col) ───── */
.pt-scene-card{
    position:relative; background:#141414;
    border:2px solid var(--pt-border);
    overflow:hidden; aspect-ratio:4/3;
    box-shadow:var(--pt-shadow);
}
.sc-wall{
    position:absolute; top:0; left:0; right:0; bottom:32%;
    background:linear-gradient(180deg,#0E0E0E,#1A1615);
}
.sc-floor{
    position:absolute; bottom:0; left:0; right:0; height:34%;
    background:
        repeating-linear-gradient(90deg,rgba(255,255,255,.05) 0, rgba(255,255,255,.05) 1px, transparent 1px, transparent 30px),
        #1A1612;
    border-top:2px solid var(--pt-orange);
}
.sc-rig{
    position:absolute; left:5%; top:8%; width:36%; height:58%;
    border:3px solid #333;
}
.sc-rig::before{
    content:''; position:absolute; top:-7px; left:-7px; right:-7px; height:9px;
    background:#3A3A3A;
}
.sc-neon{
    position:absolute; top:12%; left:50%; transform:translateX(-50%);
    font-family:var(--pt-font-h); font-size:.9rem; letter-spacing:.12em;
    color:var(--pt-neon); white-space:nowrap;
    text-shadow:0 0 8px var(--pt-neon), 0 0 20px rgba(232,80,10,.5);
    animation:pt-neon-flicker 6s ease-in-out 1s infinite;
}
.sc-barbell{
    position:absolute; bottom:36%; left:50%; transform:translateX(-50%);
    width:70%; height:8px;
}
.sc-bb-bar{
    position:absolute; top:1px; left:18%; right:18%; height:6px;
    background:linear-gradient(90deg,#555,#888,#555); border-radius:3px;
}
.sc-bb-plate{
    position:absolute; top:-3px; width:12%; height:14px;
    background:#B22222; border-radius:2px;
}
.sc-bb-plate.l{ left:6%; }
.sc-bb-plate.r{ right:6%; }
.sc-kb-row{
    position:absolute; right:4%; bottom:36%;
    display:flex; gap:5px;
}
.sc-kb{
    width:22px; height:22px;
    background:radial-gradient(ellipse at 35% 30%,#4A4A4A,#1A1A1A);
    border-radius:50%;
}
.pt-float-badge{
    position:absolute; bottom:16px; left:16px;
    background:var(--pt-orange); color:var(--pt-white);
    font-family:var(--pt-font-h); font-size:.85rem; letter-spacing:.08em;
    padding:8px 16px; text-transform:uppercase;
    animation:pt-float .5s ease-in-out infinite alternate; /* very subtle */
}

/* ── Hero layout ─────────────────────────── */
.pt-hero-inner{
    position:relative; z-index:10;
    display:grid; grid-template-columns:1fr 1fr; gap:80px;
    align-items:center; padding:120px 0 80px;
    width:100%; max-width:1200px; margin:0 auto; padding-left:32px; padding-right:32px;
}
.pt-hero-badges{ display:flex; gap:12px; flex-wrap:wrap; margin-top:32px; }
.pt-badge{
    background:rgba(232,80,10,.15); border:1px solid rgba(232,80,10,.4);
    color:var(--pt-orange); font-family:var(--pt-font-h); font-size:.85rem;
    letter-spacing:.1em; padding:6px 14px; text-transform:uppercase;
}

/* ══════════════════════════════════════════
   STATS BAR
══════════════════════════════════════════ */
.pt-stats-bar{
    background:var(--pt-orange); padding:48px 0;
}
.pt-stats-grid{
    display:grid; grid-template-columns:repeat(4,1fr); gap:32px; text-align:center;
}
.pt-stat-val{
    font-family:var(--pt-font-h); font-size:3rem; letter-spacing:.04em;
    color:var(--pt-white); display:block;
}
.pt-stat-label{
    font-size:.85rem; text-transform:uppercase; letter-spacing:.12em;
    color:rgba(255,255,255,.7); font-weight:500;
}

/* ══════════════════════════════════════════
   PROGRAMMES
══════════════════════════════════════════ */
.pt-prog-grid{
    display:grid; grid-template-columns:repeat(3,1fr); gap:2px;
    background:var(--pt-border);
}
.pt-prog-card{
    background:var(--pt-dark); padding:36px 28px;
    border-bottom:3px solid transparent;
    transition:border-color .25s, background .25s;
    cursor:default;
}
.pt-prog-card:hover{
    background:var(--pt-panel); border-bottom-color:var(--pt-orange);
}
.pt-prog-icon{ font-size:2rem; display:block; margin-bottom:16px; }
.pt-prog-name{ font-family:var(--pt-font-h); font-size:1.3rem; letter-spacing:.06em; color:var(--pt-white); text-transform:uppercase; margin-bottom:12px; }
.pt-prog-desc{ font-size:.9rem; color:var(--pt-mid); line-height:1.7; }

/* ══════════════════════════════════════════
   PROCESS
══════════════════════════════════════════ */
.pt-process-grid{
    display:grid; grid-template-columns:repeat(4,1fr); gap:0;
    position:relative;
}
.pt-process-grid::before{
    content:''; position:absolute; top:42px; left:12.5%; right:12.5%; height:2px;
    background:var(--pt-border);
}
.pt-process-step{ text-align:center; padding:0 24px; }
.pt-process-num{
    width:80px; height:80px; border-radius:50%;
    border:2px solid var(--pt-orange);
    display:flex; align-items:center; justify-content:center;
    font-family:var(--pt-font-h); font-size:1.6rem; color:var(--pt-orange);
    margin:0 auto 24px; background:var(--pt-dark); position:relative; z-index:1;
    transition:background .25s;
}
.pt-process-step:hover .pt-process-num{ background:var(--pt-orange); color:var(--pt-white); }
.pt-process-title{ font-family:var(--pt-font-h); font-size:1.1rem; letter-spacing:.06em; color:var(--pt-white); text-transform:uppercase; margin-bottom:12px; }
.pt-process-desc{ font-size:.88rem; color:var(--pt-mid); }

/* ══════════════════════════════════════════
   PACKAGES
══════════════════════════════════════════ */
.pt-pkg-grid{
    display:grid; grid-template-columns:repeat(3,1fr); gap:24px;
}
.pt-pkg-card{
    background:var(--pt-panel); border:2px solid var(--pt-border);
    padding:40px 32px; position:relative; transition:border-color .25s;
}
.pt-pkg-card:hover{ border-color:var(--pt-orange); }
.pt-pkg-card.highlight{
    background:var(--pt-orange); border-color:var(--pt-orange);
}
.pt-pkg-badge{
    position:absolute; top:-14px; left:50%; transform:translateX(-50%);
    background:var(--pt-amber); color:var(--pt-black);
    font-family:var(--pt-font-h); font-size:.8rem; letter-spacing:.12em;
    padding:4px 16px; white-space:nowrap; text-transform:uppercase;
}
.pt-pkg-name{
    font-family:var(--pt-font-h); font-size:2rem; letter-spacing:.1em;
    color:var(--pt-white); text-transform:uppercase; margin-bottom:6px;
}
.pt-pkg-sessions{ font-size:.85rem; color:rgba(255,255,255,.7); margin-bottom:28px; }
.pt-pkg-price{
    display:flex; align-items:baseline; gap:4px; margin-bottom:28px;
}
.pt-pkg-amount{
    font-family:var(--pt-font-h); font-size:3.2rem; color:var(--pt-white);
}
.pt-pkg-period{ font-size:.9rem; color:rgba(255,255,255,.7); }
.pt-pkg-features{ list-style:none; margin-bottom:32px; display:flex; flex-direction:column; gap:10px; }
.pt-pkg-features li{
    font-size:.9rem; color:rgba(255,255,255,.85);
    padding-left:20px; position:relative;
}
.pt-pkg-features li::before{
    content:'✓'; position:absolute; left:0; color:var(--pt-white); font-weight:700;
}
.pt-pkg-card.highlight .pt-pkg-sessions,
.pt-pkg-card.highlight .pt-pkg-period{ color:rgba(255,255,255,.8); }
.pt-pkg-card.highlight .pt-pkg-features li{ color:var(--pt-white); }
.pt-pkg-card.highlight .pt-btn-outline{
    border-color:var(--pt-white); color:var(--pt-white);
}
.pt-pkg-card.highlight .pt-btn-outline:hover{ background:var(--pt-white); color:var(--pt-orange); }

/* ══════════════════════════════════════════
   TEAM
══════════════════════════════════════════ */
.pt-team-grid{ display:grid; grid-template-columns:repeat(4,1fr); gap:24px; }
.pt-team-card{
    background:var(--pt-panel); border:2px solid var(--pt-border); overflow:hidden;
    transition:border-color .25s;
}
.pt-team-card:hover{ border-color:var(--pt-orange); }
.pt-team-avatar{
    height:200px; position:relative;
    background:var(--pt-dark);
    display:flex; align-items:flex-end; justify-content:center;
    overflow:hidden;
}
.pt-avatar-accent{
    position:absolute; top:0; left:0; right:0; height:4px;
    background:var(--accent);
}
/* CSS trainer figure */
.pt-figure{
    position:relative; width:80px; height:160px; margin-bottom:0;
}
.pt-fig-head{
    width:36px; height:36px; border-radius:50%;
    background:var(--accent); margin:0 auto 0;
    position:absolute; top:12px; left:50%; transform:translateX(-50%);
}
.pt-fig-body{
    position:absolute; top:52px; left:50%; transform:translateX(-50%);
    width:44px; height:52px;
    background:var(--accent);
    clip-path:polygon(10% 0%,90% 0%,100% 100%,0% 100%);
}
/* vest stripe */
.pt-fig-body::before{
    content:''; position:absolute; left:40%; top:0; width:20%; height:100%;
    background:rgba(255,255,255,.15);
}
.pt-fig-arm-l,.pt-fig-arm-r{
    position:absolute; width:12px; height:44px;
    background:var(--accent); border-radius:6px;
}
.pt-fig-arm-l{ top:52px; left:calc(50% - 32px); transform:rotate(18deg); transform-origin:top center; }
.pt-fig-arm-r{ top:52px; right:calc(50% - 32px); transform:rotate(-18deg); transform-origin:top center; }
.pt-fig-leg-l,.pt-fig-leg-r{
    position:absolute; width:16px; height:48px;
    background:#222; border-radius:4px 4px 8px 8px;
}
.pt-fig-leg-l{ top:100px; left:calc(50% - 18px); }
.pt-fig-leg-r{ top:100px; right:calc(50% - 18px); }
/* dumbbell in hand */
.pt-fig-db{
    position:absolute; top:86px; left:calc(50% - 42px);
    width:30px; height:6px;
    background:#555; border-radius:3px;
}
.pt-fig-db::before,.pt-fig-db::after{
    content:''; position:absolute; top:-3px; width:6px; height:12px;
    background:#444; border-radius:2px;
}
.pt-fig-db::before{ left:0; }
.pt-fig-db::after{ right:0; }
.pt-team-info{ padding:20px 20px 24px; }
.pt-team-name{ font-family:var(--pt-font-h); font-size:1.2rem; letter-spacing:.06em; color:var(--pt-white); text-transform:uppercase; margin-bottom:4px; }
.pt-team-role{ font-size:.8rem; color:var(--pt-orange); font-weight:600; text-transform:uppercase; letter-spacing:.1em; margin-bottom:6px; }
.pt-team-spec{ font-size:.85rem; color:var(--pt-mid); }

/* ══════════════════════════════════════════
   TESTIMONIALS
══════════════════════════════════════════ */
.pt-testi-grid{ display:grid; grid-template-columns:repeat(3,1fr); gap:24px; }
.pt-testi-card{
    background:var(--pt-panel); border:2px solid var(--pt-border);
    padding:32px; border-left:4px solid var(--pt-orange);
}
.pt-testi-text{ font-size:1rem; color:var(--pt-chalk); line-height:1.75; margin-bottom:24px; font-style:italic; }
.pt-testi-name{ font-family:var(--pt-font-h); font-size:1rem; letter-spacing:.06em; color:var(--pt-white); text-transform:uppercase; }
.pt-testi-role{ font-size:.8rem; color:var(--pt-orange); font-weight:600; text-transform:uppercase; letter-spacing:.1em; }

/* ══════════════════════════════════════════
   FAQ
══════════════════════════════════════════ */
.pt-faq-list{ max-width:800px; margin:0 auto; display:flex; flex-direction:column; gap:2px; }
.pt-faq-item{ background:var(--pt-panel); border-left:3px solid transparent; transition:border-color .25s; }
.pt-faq-item.open{ border-left-color:var(--pt-orange); }
.pt-faq-btn{
    width:100%; text-align:left; padding:22px 28px;
    font-family:var(--pt-font-h); font-size:1.05rem; letter-spacing:.04em;
    color:var(--pt-white); text-transform:uppercase;
    background:none; border:none; cursor:pointer;
    display:flex; justify-content:space-between; align-items:center; gap:16px;
}
.pt-faq-icon{ font-size:1.4rem; color:var(--pt-orange); flex-shrink:0; transition:transform .3s; }
.pt-faq-item.open .pt-faq-icon{ transform:rotate(45deg); }
.pt-faq-body{ max-height:0; overflow:hidden; transition:max-height .4s ease; }
.pt-faq-body-inner{ padding:0 28px 24px; font-size:.95rem; color:var(--pt-mid); line-height:1.75; }

/* ══════════════════════════════════════════
   BOOKING FORM
══════════════════════════════════════════ */
.pt-contact-wrap{
    display:grid; grid-template-columns:1fr 1fr; gap:64px; align-items:start;
}
.pt-contact-info-items{ display:flex; flex-direction:column; gap:32px; margin-top:32px; }
.pt-contact-info-item{ display:flex; gap:16px; align-items:flex-start; }
.pt-contact-icon{
    width:48px; height:48px; background:rgba(232,80,10,.15);
    border:1px solid rgba(232,80,10,.4);
    display:flex; align-items:center; justify-content:center;
    font-size:1.2rem; flex-shrink:0;
}
.pt-contact-detail-title{ font-family:var(--pt-font-h); font-size:.95rem; letter-spacing:.08em; color:var(--pt-white); text-transform:uppercase; margin-bottom:4px; }
.pt-contact-detail-val{ font-size:.9rem; color:var(--pt-mid); }

.pt-form{ display:flex; flex-direction:column; gap:20px; }
.pt-form-row{ display:grid; grid-template-columns:1fr 1fr; gap:20px; }
.pt-field label{
    display:block; font-family:var(--pt-font-h); font-size:.85rem; letter-spacing:.1em;
    color:var(--pt-mid); text-transform:uppercase; margin-bottom:8px;
}
.pt-field input, .pt-field select, .pt-field textarea{
    width:100%; padding:14px 16px;
    background:var(--pt-panel); border:2px solid var(--pt-border);
    color:var(--pt-chalk); font-family:var(--pt-font-b); font-size:.95rem;
    transition:border-color .25s;
}
.pt-field input:focus, .pt-field select:focus, .pt-field textarea:focus{
    outline:none; border-color:var(--pt-orange);
}
.pt-field select{ appearance:none; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%23E8500A' fill='none' stroke-width='2'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:calc(100% - 16px) 50%; padding-right:40px; }
.pt-field select option{ background:var(--pt-dark); }
.pt-field textarea{ resize:vertical; min-height:120px; }
.pt-form-privacy{ font-size:.8rem; color:var(--pt-mid); }
.pt-form-privacy a{ color:var(--pt-orange); }

/* ══════════════════════════════════════════
   FOOTER CTA
══════════════════════════════════════════ */
.pt-cta{
    background:var(--pt-orange); padding:80px 0; text-align:center;
    position:relative; overflow:hidden;
}
.pt-cta::before{
    content:''; position:absolute; top:-60px; left:-60px;
    width:300px; height:300px; border-radius:50%;
    background:rgba(255,255,255,.05);
}
.pt-cta::after{
    content:''; position:absolute; bottom:-80px; right:-40px;
    width:400px; height:400px; border-radius:50%;
    background:rgba(0,0,0,.08);
}
.pt-cta-inner{ position:relative; z-index:1; }
.pt-cta-title{ font-family:var(--pt-font-h); font-size:clamp(2rem,5vw,4rem); color:var(--pt-white); letter-spacing:.06em; text-transform:uppercase; margin-bottom:16px; }
.pt-cta-sub{ font-size:1.1rem; color:rgba(255,255,255,.8); margin-bottom:40px; }

/* ══════════════════════════════════════════
   KEYFRAMES
══════════════════════════════════════════ */
@keyframes pt-neon-flicker{
    0%,100%{ opacity:1; }
    92%{ opacity:1; }
    93%{ opacity:.6; }
    94%{ opacity:1; }
    96%{ opacity:.4; }
    97%{ opacity:1; }
}
@keyframes pt-particle-drift{
    0%  { transform:translateY(0) scale(1); opacity:.6; }
    100%{ transform:translateY(-30px) scale(1.4); opacity:0; }
}
@keyframes pt-float{
    0%  { transform:translateY(0); }
    100%{ transform:translateY(-6px); }
}
@keyframes pt-count-up{ from{ opacity:0; transform:translateY(10px); } to{ opacity:1; transform:none; } }

/* ══════════════════════════════════════════
   RESPONSIVE
══════════════════════════════════════════ */
@media(max-width:1024px){
    .pt-hero-inner{ grid-template-columns:1fr; gap:40px; }
    .pt-stats-grid{ grid-template-columns:repeat(2,1fr); }
    .pt-prog-grid{ grid-template-columns:repeat(2,1fr); }
    .pt-process-grid{ grid-template-columns:repeat(2,1fr); gap:40px; }
    .pt-process-grid::before{ display:none; }
    .pt-pkg-grid{ grid-template-columns:1fr; max-width:420px; margin:0 auto; }
    .pt-team-grid{ grid-template-columns:repeat(2,1fr); }
    .pt-testi-grid{ grid-template-columns:1fr; }
    .pt-contact-wrap{ grid-template-columns:1fr; }
}
@media(max-width:640px){
    .pt-prog-grid,.pt-team-grid{ grid-template-columns:1fr; }
    .pt-form-row{ grid-template-columns:1fr; }
    .pt-stats-grid{ grid-template-columns:1fr; }
    .pt-process-grid{ grid-template-columns:1fr; }
}
</style>

<div class="pt-wrap">

<!-- ══════════════════════════════════════
     HERO
══════════════════════════════════════ -->
<section class="pt-hero">

    <!-- gym environment -->
    <div class="pt-floor"></div>
    <div class="pt-gym-wall"></div>

    <!-- rig wall -->
    <div class="pt-rig">
        <div class="pt-rig-v1"></div>
        <div class="pt-rig-v2"></div>
        <div class="pt-bar-row">
            <?php for($b=0;$b<4;$b++): ?>
            <div class="pt-bar"></div>
            <?php endfor; ?>
        </div>
    </div>

    <!-- neon sign -->
    <div class="pt-neon-sign">No Excuses</div>

    <!-- barbell on floor -->
    <div class="pt-barbell">
        <div class="pt-bb-bar"></div>
        <div class="pt-bb-collar left"></div>
        <div class="pt-bb-collar right"></div>
        <!-- left plates: 20kg red, 10kg blue, 5kg green -->
        <div class="pt-bb-plate left">
            <div class="pt-plate" style="--ph:50px;--pc:#B22222;"></div>
            <div class="pt-plate" style="--ph:40px;--pc:#1E5FA8;"></div>
            <div class="pt-plate" style="--ph:30px;--pc:#28773E;"></div>
        </div>
        <!-- right plates mirrored -->
        <div class="pt-bb-plate right">
            <div class="pt-plate" style="--ph:50px;--pc:#B22222;"></div>
            <div class="pt-plate" style="--ph:40px;--pc:#1E5FA8;"></div>
            <div class="pt-plate" style="--ph:30px;--pc:#28773E;"></div>
        </div>
    </div>

    <!-- kettlebell rack -->
    <div class="pt-kb-rack">
        <?php
        $kb_rows = [ [8,12,16], [20,24,32] ];
        foreach($kb_rows as $row): ?>
        <div class="pt-kb-row">
            <?php foreach($row as $kg):
                $s = 26 + ($kg/32)*12;
                $kw = $s; $kh = $s;
            ?>
            <div class="pt-kb" style="--kw:<?php echo $kw; ?>px;--kh:<?php echo $kh; ?>px;">
                <div class="pt-kb-handle"></div>
                <div class="pt-kb-body" data-kg="<?php echo $kg; ?>KG"></div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- floating particles (chalk dust) -->
    <?php foreach($pt_particles as $p): ?>
    <div class="pt-particle <?php echo ['','diamond',''][min($p['type'],2)]; ?>"
         style="
            left:<?php echo $p['left']; ?>%;
            top:<?php echo $p['top']; ?>%;
            width:<?php echo $p['size']; ?>px;
            height:<?php echo $p['size']; ?>px;
            --pd:<?php echo $p['dur']; ?>ms;
            --pde:<?php echo $p['delay']; ?>ms;
         ">
    </div>
    <?php endforeach; ?>

    <!-- hero content -->
    <div class="pt-hero-inner">
        <div class="pt-hero-text">
            <span class="pt-overline">Private Personal Training · London</span>
            <h1 class="pt-h1">
                Build Your<br>
                <span class="pt-accent">Best</span><br>
                Body.
            </h1>
            <p class="pt-lead" style="margin-top:24px;">
                Expert 1-to-1 coaching in our private Shoreditch studio. No crowds,
                no distractions — just evidence-based training and real, lasting results.
            </p>
            <div class="pt-hero-badges">
                <span class="pt-badge">★ 4.9 Google</span>
                <span class="pt-badge">850+ Transformations</span>
                <span class="pt-badge">Free Consultation</span>
            </div>
            <div style="margin-top:36px; display:flex; gap:16px; flex-wrap:wrap;">
                <a href="#book" class="pt-btn">Book Free Consultation</a>
                <a href="#programmes" class="pt-btn pt-btn-outline">Our Programmes</a>
            </div>
        </div>

        <!-- gym scene card -->
        <div class="pt-hero-visual">
            <div class="pt-scene-card">
                <div class="sc-wall"></div>
                <div class="sc-floor"></div>
                <div class="sc-rig"></div>
                <div class="sc-neon">No Excuses</div>
                <div class="sc-barbell">
                    <div class="sc-bb-bar"></div>
                    <div class="sc-bb-plate l"></div>
                    <div class="sc-bb-plate r"></div>
                </div>
                <div class="sc-kb-row">
                    <div class="sc-kb"></div>
                    <div class="sc-kb" style="width:26px;height:26px;"></div>
                    <div class="sc-kb" style="width:30px;height:30px;"></div>
                </div>
                <div class="pt-float-badge">🏋️ Private Studio · Shoreditch</div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     STATS BAR
══════════════════════════════════════ -->
<div class="pt-stats-bar">
    <div class="pt-container">
        <div class="pt-stats-grid">
            <?php foreach($pt_stats as $st):
                $is_float = (floor($st['val']) !== (float)$st['val']); ?>
            <div class="pt-stat">
                <span class="pt-stat-val"
                      data-target="<?php echo $st['val']; ?>"
                      data-suffix="<?php echo esc_attr($st['suffix']); ?>"
                      data-float="<?php echo $is_float ? '1' : '0'; ?>">
                    0<?php echo esc_html($st['suffix']); ?>
                </span>
                <span class="pt-stat-label"><?php echo esc_html($st['label']); ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ══════════════════════════════════════
     PROGRAMMES
══════════════════════════════════════ -->
<section class="pt-section" id="programmes">
    <div class="pt-container">
        <div class="pt-section-header">
            <span class="pt-overline">What We Offer</span>
            <h2 class="pt-h2">Programmes Built for <span class="pt-accent">Results</span></h2>
            <p class="pt-lead" style="margin:16px auto 0; text-align:center;">
                Every programme is personalised to your goals, schedule and starting point.
            </p>
        </div>
        <div class="pt-prog-grid">
            <?php foreach($pt_programmes as $prog): ?>
            <div class="pt-prog-card">
                <span class="pt-prog-icon"><?php echo $prog['icon']; ?></span>
                <div class="pt-prog-name"><?php echo esc_html($prog['name']); ?></div>
                <p class="pt-prog-desc"><?php echo esc_html($prog['desc']); ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     PROCESS
══════════════════════════════════════ -->
<section class="pt-section pt-section-dark">
    <div class="pt-container">
        <div class="pt-section-header">
            <span class="pt-overline">How It Works</span>
            <h2 class="pt-h2">Your Journey to <span class="pt-accent">Transformation</span></h2>
        </div>
        <div class="pt-process-grid">
            <?php foreach($pt_process as $step): ?>
            <div class="pt-process-step">
                <div class="pt-process-num"><?php echo esc_html($step['num']); ?></div>
                <div class="pt-process-title"><?php echo esc_html($step['title']); ?></div>
                <p class="pt-process-desc"><?php echo esc_html($step['desc']); ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     PACKAGES
══════════════════════════════════════ -->
<section class="pt-section" id="packages">
    <div class="pt-container">
        <div class="pt-section-header">
            <span class="pt-overline">Investment</span>
            <h2 class="pt-h2">Choose Your <span class="pt-accent">Plan</span></h2>
            <p class="pt-lead" style="margin:16px auto 0; text-align:center;">
                All packages include a free initial consultation and 30-day satisfaction guarantee.
            </p>
        </div>
        <div class="pt-pkg-grid">
            <?php foreach($pt_packages as $pkg): ?>
            <div class="pt-pkg-card <?php echo $pkg['highlight'] ? 'highlight' : ''; ?>">
                <?php if($pkg['highlight']): ?>
                <div class="pt-pkg-badge">Most Popular</div>
                <?php endif; ?>
                <div class="pt-pkg-name"><?php echo esc_html($pkg['name']); ?></div>
                <div class="pt-pkg-sessions"><?php echo esc_html($pkg['sessions']); ?></div>
                <div class="pt-pkg-price">
                    <span class="pt-pkg-amount"><?php echo esc_html($pkg['price']); ?></span>
                    <span class="pt-pkg-period"><?php echo esc_html($pkg['period']); ?></span>
                </div>
                <ul class="pt-pkg-features">
                    <?php foreach($pkg['features'] as $f): ?>
                    <li><?php echo esc_html($f); ?></li>
                    <?php endforeach; ?>
                </ul>
                <a href="#book" class="pt-btn pt-btn-outline" style="width:100%; justify-content:center;">
                    Get Started
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     TEAM
══════════════════════════════════════ -->
<section class="pt-section pt-section-panel">
    <div class="pt-container">
        <div class="pt-section-header">
            <span class="pt-overline">The Coaches</span>
            <h2 class="pt-h2">Expert Trainers, <span class="pt-accent">Real People</span></h2>
        </div>
        <div class="pt-team-grid">
            <?php foreach($pt_team as $coach): ?>
            <div class="pt-team-card" style="--accent:<?php echo esc_attr($coach['colour']); ?>;">
                <div class="pt-team-avatar">
                    <div class="pt-avatar-accent"></div>
                    <div class="pt-figure">
                        <div class="pt-fig-head"></div>
                        <div class="pt-fig-body"></div>
                        <div class="pt-fig-arm-l"></div>
                        <div class="pt-fig-arm-r"></div>
                        <div class="pt-fig-db"></div>
                        <div class="pt-fig-leg-l"></div>
                        <div class="pt-fig-leg-r"></div>
                    </div>
                </div>
                <div class="pt-team-info">
                    <div class="pt-team-name"><?php echo esc_html($coach['name']); ?></div>
                    <div class="pt-team-role"><?php echo esc_html($coach['role']); ?></div>
                    <div class="pt-team-spec"><?php echo esc_html($coach['spec']); ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     TESTIMONIALS
══════════════════════════════════════ -->
<section class="pt-section pt-section-dark">
    <div class="pt-container">
        <div class="pt-section-header">
            <span class="pt-overline">Success Stories</span>
            <h2 class="pt-h2">Real People, <span class="pt-accent">Real Results</span></h2>
        </div>
        <div class="pt-testi-grid">
            <?php foreach($pt_testimonials as $t): ?>
            <div class="pt-testi-card">
                <p class="pt-testi-text">"<?php echo esc_html($t['text']); ?>"</p>
                <div class="pt-testi-name"><?php echo esc_html($t['name']); ?></div>
                <div class="pt-testi-role"><?php echo esc_html($t['role']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     FAQ
══════════════════════════════════════ -->
<section class="pt-section">
    <div class="pt-container">
        <div class="pt-section-header">
            <span class="pt-overline">FAQ</span>
            <h2 class="pt-h2">Common <span class="pt-accent">Questions</span></h2>
        </div>
        <div class="pt-faq-list">
            <?php foreach($pt_faqs as $i=>$faq): ?>
            <div class="pt-faq-item" id="pt-faq-<?php echo $i; ?>">
                <button class="pt-faq-btn"
                        aria-expanded="false"
                        aria-controls="pt-faq-body-<?php echo $i; ?>">
                    <?php echo esc_html($faq['q']); ?>
                    <span class="pt-faq-icon">+</span>
                </button>
                <div class="pt-faq-body" id="pt-faq-body-<?php echo $i; ?>" role="region">
                    <div class="pt-faq-body-inner"><?php echo esc_html($faq['a']); ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     BOOKING FORM
══════════════════════════════════════ -->
<section class="pt-section pt-section-dark" id="book">
    <div class="pt-container">
        <div class="pt-contact-wrap">

            <!-- Info column -->
            <div>
                <span class="pt-overline">Get Started</span>
                <h2 class="pt-h2" style="margin-bottom:16px;">Book Your Free <span class="pt-accent">Consultation</span></h2>
                <p class="pt-lead">
                    A no-obligation 45-minute session where we assess your goals and show you exactly
                    what's possible. Zero sales pressure.
                </p>
                <div class="pt-contact-info-items">
                    <div class="pt-contact-info-item">
                        <div class="pt-contact-icon">📍</div>
                        <div>
                            <div class="pt-contact-detail-title">Studio Location</div>
                            <div class="pt-contact-detail-val">14 Curtain Road, Shoreditch, London EC2A 3AT</div>
                        </div>
                    </div>
                    <div class="pt-contact-info-item">
                        <div class="pt-contact-icon">📞</div>
                        <div>
                            <div class="pt-contact-detail-title">Call or WhatsApp</div>
                            <div class="pt-contact-detail-val">+44 (0)20 7123 4567</div>
                        </div>
                    </div>
                    <div class="pt-contact-info-item">
                        <div class="pt-contact-icon">⏰</div>
                        <div>
                            <div class="pt-contact-detail-title">Studio Hours</div>
                            <div class="pt-contact-detail-val">Mon–Fri: 06:00–21:00 · Sat–Sun: 07:00–17:00</div>
                        </div>
                    </div>
                    <div class="pt-contact-info-item">
                        <div class="pt-contact-icon">🎯</div>
                        <div>
                            <div class="pt-contact-detail-title">Free Consultation Includes</div>
                            <div class="pt-contact-detail-val">Goal review · Movement screen · Personalised plan overview</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Form column -->
            <div>
                <form class="pt-form"
                      method="post"
                      action="<?php echo esc_url(admin_url('admin-post.php')); ?>">

                    <?php wp_nonce_field('tf_pt_enquiry','tf_pt_nonce'); ?>
                    <input type="hidden" name="action" value="tf_pt_enquiry">

                    <div class="pt-form-row">
                        <div class="pt-field">
                            <label for="pt-fname">First Name <span style="color:var(--pt-orange)">*</span></label>
                            <input type="text" id="pt-fname" name="pt_fname" required placeholder="Marcus">
                        </div>
                        <div class="pt-field">
                            <label for="pt-lname">Last Name <span style="color:var(--pt-orange)">*</span></label>
                            <input type="text" id="pt-lname" name="pt_lname" required placeholder="Reid">
                        </div>
                    </div>

                    <div class="pt-form-row">
                        <div class="pt-field">
                            <label for="pt-email">Email Address <span style="color:var(--pt-orange)">*</span></label>
                            <input type="email" id="pt-email" name="pt_email" required placeholder="marcus@email.com">
                        </div>
                        <div class="pt-field">
                            <label for="pt-phone">Phone / WhatsApp</label>
                            <input type="tel" id="pt-phone" name="pt_phone" placeholder="+44 7700 900 000">
                        </div>
                    </div>

                    <div class="pt-field">
                        <label for="pt-goal">Primary Goal <span style="color:var(--pt-orange)">*</span></label>
                        <select id="pt-goal" name="pt_goal" required>
                            <option value="" disabled selected>Select your main goal…</option>
                            <option>Lose body fat</option>
                            <option>Build muscle & strength</option>
                            <option>Improve athletic performance</option>
                            <option>Improve general fitness</option>
                            <option>Mobility & injury rehabilitation</option>
                            <option>Nutrition coaching</option>
                        </select>
                    </div>

                    <div class="pt-form-row">
                        <div class="pt-field">
                            <label for="pt-pkg">Package Interest</label>
                            <select id="pt-pkg" name="pt_pkg">
                                <option value="" disabled selected>Choose a package…</option>
                                <option>Ignite — 4 sessions/month</option>
                                <option>Forge — 8 sessions/month</option>
                                <option>Elite — 12 sessions/month</option>
                                <option>Online Coaching</option>
                                <option>Not sure yet</option>
                            </select>
                        </div>
                        <div class="pt-field">
                            <label for="pt-date">Preferred Consultation Date</label>
                            <input type="date" id="pt-date" name="pt_date"
                                   min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>">
                        </div>
                    </div>

                    <div class="pt-field">
                        <label for="pt-message">Anything else we should know?</label>
                        <textarea id="pt-message" name="pt_message"
                                  placeholder="Tell us about any injuries, your current activity level, or anything else relevant…"></textarea>
                    </div>

                    <p class="pt-form-privacy">
                        Your information is kept strictly confidential and never shared with third parties.
                        By submitting you agree to our <a href="#">Privacy Policy</a>.
                    </p>

                    <button type="submit" class="pt-btn" style="width:100%; justify-content:center;">
                        Book Free Consultation →
                    </button>
                </form>
            </div>

        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     FOOTER CTA
══════════════════════════════════════ -->
<div class="pt-cta">
    <div class="pt-container pt-cta-inner">
        <div class="pt-cta-title">Stop Waiting. Start Training.</div>
        <p class="pt-cta-sub">
            Join over 850 people who have already transformed their bodies and lives with us.
        </p>
        <div style="display:flex; gap:16px; justify-content:center; flex-wrap:wrap;">
            <a href="#book" class="pt-btn pt-btn-chalk">Book Free Consultation</a>
            <a href="tel:+442071234567" class="pt-btn pt-btn-outline" style="border-color:white;color:white;">
                Call +44 20 7123 4567
            </a>
        </div>
    </div>
</div>

</div><!-- /.pt-wrap -->

<script>
(function(){
    /* ── Animated counters ─────────────────────── */
    const easeOut = t => 1 - Math.pow(1 - t, 3);
    const counterEls = document.querySelectorAll('.pt-stat-val[data-target]');
    const seenCounters = new Set();
    const counterObs = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if(!entry.isIntersecting || seenCounters.has(entry.target)) return;
            seenCounters.add(entry.target);
            const el     = entry.target;
            const target = parseFloat(el.dataset.target);
            const suffix = el.dataset.suffix || '';
            const isFloat= el.dataset.float === '1';
            if(isNaN(target)) return;
            const dur = 1600, start = performance.now();
            const tick = now => {
                const t = Math.min((now - start) / dur, 1);
                const v = easeOut(t) * target;
                el.textContent = (isFloat ? v.toFixed(1) : Math.round(v)) + suffix;
                if(t < 1) requestAnimationFrame(tick);
            };
            requestAnimationFrame(tick);
        });
    }, { threshold: 0.4 });
    counterEls.forEach(el => counterObs.observe(el));

    /* ── FAQ accordion ─────────────────────────── */
    document.querySelectorAll('.pt-faq-btn').forEach(btn => {
        btn.addEventListener('click', function(){
            const item = this.closest('.pt-faq-item');
            const body = item.querySelector('.pt-faq-body');
            const open = item.classList.contains('open');
            /* close all */
            document.querySelectorAll('.pt-faq-item.open').forEach(i => {
                i.classList.remove('open');
                i.querySelector('.pt-faq-body').style.maxHeight = '0';
                i.querySelector('.pt-faq-btn').setAttribute('aria-expanded','false');
            });
            if(!open){
                item.classList.add('open');
                body.style.maxHeight = body.scrollHeight + 'px';
                this.setAttribute('aria-expanded','true');
            }
        });
    });
})();
</script>

<?php get_footer(); ?>
