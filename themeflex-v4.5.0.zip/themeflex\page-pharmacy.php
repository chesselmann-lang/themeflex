<?php
/**
 * Template Name: TF — Pharmacy & Apothecary
 *
 * Namespace : --phm-*
 * Fonts     : DM Serif Display (headings) + DM Sans (body)
 * Palette   : teal #1a7a8a · white #f8fdfd · navy #0f2535 · slate #4a6070 · mint #e0f4f6
 */

/* ── deterministic randomness ── */
srand( crc32( get_the_permalink() ) );

/* ── lab bubbles (hero) ── */
$bubbles = [];
for ( $i = 0; $i < 24; $i++ ) {
    $bubbles[] = [
        'x'    => rand( 3, 97 ),
        'y'    => rand( 5, 88 ),
        'size' => rand( 6, 20 ),
        'del'  => round( lcg_value() * 5, 2 ),
        'dur'  => round( 4 + lcg_value() * 5, 2 ),
        'alpha'=> round( 0.15 + lcg_value() * 0.2, 2 ),
        'color'=> [ '#1a7a8a','#0f9ab0','#2ab8d0','#50c8d8','#00a0b0' ][ rand(0,4) ],
    ];
}

/* ── molecule nodes (hero decoration) ── */
$mol_nodes = [];
for ( $i = 0; $i < 8; $i++ ) {
    $angle = $i * (360/8);
    $mol_nodes[] = [
        'angle' => $angle,
        'r'     => rand( 60, 100 ),
        'size'  => rand( 6, 14 ),
        'color' => [ '#1a7a8a','#0f9ab0','#c9a84c','#4a6070' ][ rand(0,3) ],
    ];
}

/* ── services / health categories ── */
$services = [
    [ 'icon'=>'💊', 'cat'=>'prescriptions', 'title'=>'Prescription Dispensing',   'desc'=>'Fast, accurate dispensing with full medication review and safety checking. NHS and private prescriptions accepted.' ],
    [ 'icon'=>'🧴', 'cat'=>'skincare',       'title'=>'Compounding & Bespoke',     'desc'=>'Custom-formulated topical preparations, capsules, and creams tailored to your exact prescription requirements.' ],
    [ 'icon'=>'🩸', 'cat'=>'testing',        'title'=>'Health Testing',            'desc'=>'In-pharmacy blood tests including cholesterol, HbA1c, vitamin D, iron, and thyroid panels with same-day results.' ],
    [ 'icon'=>'💉', 'cat'=>'vaccinations',   'title'=>'Travel & Flu Vaccinations', 'desc'=>'NHS flu jab, COVID boosters, and full travel vaccination service including yellow fever, typhoid, and hepatitis.' ],
    [ 'icon'=>'🌿', 'cat'=>'skincare',       'title'=>'Natural & Wellness',        'desc'=>'Curated selection of evidence-based supplements, herbal medicines, and natural health products from trusted brands.' ],
    [ 'icon'=>'💙', 'cat'=>'prescriptions',  'title'=>'Medicines Use Review',      'desc'=>'Free confidential consultation with our pharmacist to review your current medicines and optimise your regimen.' ],
    [ 'icon'=>'🏃', 'cat'=>'testing',        'title'=>'Sports & Performance',      'desc'=>'Nutrition, protein, and recovery supplements plus bespoke vitamin stacks reviewed by our clinical pharmacists.' ],
    [ 'icon'=>'👶', 'cat'=>'vaccinations',   'title'=>'Baby & Child Health',       'desc'=>'Infant medicines, teething gels, vitamin supplements, and expert advice from our paediatric-trained team.' ],
];

/* ── product shelf categories ── */
$products = [
    [ 'name'=>'Vitamins & Supplements', 'count'=>'240+', 'color'=>'#1a7a8a', 'icon'=>'✦' ],
    [ 'name'=>'Skincare & Beauty',      'count'=>'180+', 'color'=>'#c47a8a', 'icon'=>'✦' ],
    [ 'name'=>'Baby & Family',          'count'=>'130+', 'color'=>'#8aab80', 'icon'=>'✦' ],
    [ 'name'=>'Natural Health',         'count'=>'200+', 'color'=>'#c9a84c', 'icon'=>'✦' ],
];

/* ── pharmacists / team ── */
$team = [
    [ 'name'=>'Dr. Priya Mehta',      'role'=>'Chief Pharmacist',       'qual'=>'MPharm, PhD, FRPharmS', 'female'=>true,  'glasses'=>false, 'hair'=>'#0a0804', 'scrub'=>'#1a7a8a' ],
    [ 'name'=>'James Calloway',        'role'=>'Clinical Pharmacist',    'qual'=>'MPharm, PGDip',         'female'=>false, 'glasses'=>true,  'hair'=>'#2a1808', 'scrub'=>'#0f2535' ],
    [ 'name'=>'Fatima Al-Rashid',      'role'=>'Compounding Specialist', 'qual'=>'MPharm, BCPS',          'female'=>true,  'glasses'=>false, 'hair'=>'#1a0a04', 'scrub'=>'#1a7a8a' ],
    [ 'name'=>'Tom Nguyen',            'role'=>'Dispensary Manager',     'qual'=>'BPharm, RPh',           'female'=>false, 'glasses'=>false, 'hair'=>'#0a0806', 'scrub'=>'#0f2535' ],
];

/* ── FAQs ── */
$faqs = [
    [ 'q'=>'Can I get my prescription dispensed without visiting a GP first?', 'a'=>'For many conditions, yes. Our pharmacists can prescribe and dispense treatments under a Pharmacy First scheme for conditions including sinusitis, sore throat, earache, infected insect bites, impetigo, shingles, and urinary tract infections.' ],
    [ 'q'=>'How long does it take to have a bespoke compound prepared?', 'a'=>'Standard compounding takes 2–4 working days. Urgent preparations can often be ready within 24 hours. We\'ll give you an accurate time estimate when you place your order.' ],
    [ 'q'=>'Do you offer NHS prescriptions?', 'a'=>'Yes. We dispense all NHS prescriptions. For patients with a prepayment certificate or qualifying for free prescriptions, simply bring your prescription along and we\'ll process it in the normal NHS way.' ],
    [ 'q'=>'What health tests do you offer and how quickly are results available?', 'a'=>'We offer over 20 blood tests including full blood count, cholesterol, HbA1c, thyroid, vitamin D, iron studies, and PSA. Most results are available the same day or within 24 hours.' ],
];

/* ── testimonials ── */
$testimonials = [
    [ 'text'=>'The compounding team made a cream that no off-the-shelf product could match. The pharmacist spent 20 minutes going through my skin history before formulating it. Extraordinary service.', 'author'=>'Rebecca T.' ],
    [ 'text'=>'Priya\'s medicines review identified an interaction between two of my long-term medications that my GP hadn\'t spotted. It\'s genuinely the most clinically impressive pharmacy experience I\'ve had.', 'author'=>'Michael S.' ],
    [ 'text'=>'Travel vaccinations for our family of four, all booked and administered in one visit. Efficient, kind, and far less hassle than the GP surgery. We won\'t go anywhere else.', 'author'=>'Clare & David P.' ],
];

/* ── marquee ── */
$mq_raw  = [ 'Prescriptions', '·', 'Compounding', '·', 'Health Tests', '·', 'Vaccinations', '·', 'Supplements', '·', 'Skincare', '·', 'Baby Health', '·', 'Pharmacy First', '·' ];
$marquee = array_merge( $mq_raw, $mq_raw );
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════
   PHARMACY — CSS CUSTOM PROPERTIES
═══════════════════════════════════════════ */
:root{
  --phm-teal:#1a7a8a;
  --phm-white:#f8fdfd;
  --phm-navy:#0f2535;
  --phm-slate:#4a6070;
  --phm-mint:#e0f4f6;
  --phm-cream:#f5f9fa;
  --phm-light-teal:#c8e8ec;
  --phm-radius:6px;
  --phm-serif:'DM Serif Display',serif;
  --phm-sans:'DM Sans',sans-serif;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body.phm-page{
  font-family:var(--phm-sans);
  font-weight:300;color:var(--phm-navy);
  background:var(--phm-white);
  line-height:1.7;overflow-x:hidden;
}
.phm-wrap{max-width:1180px;margin:0 auto;padding:0 24px}
.phm-eyebrow{
  font-family:var(--phm-sans);font-size:.7rem;font-weight:600;
  letter-spacing:.24em;text-transform:uppercase;
  color:var(--phm-teal);display:block;margin-bottom:14px;
}
.phm-section-title{
  font-family:var(--phm-serif);
  font-size:clamp(1.9rem,4vw,3rem);
  font-weight:400;color:var(--phm-navy);
  margin-bottom:18px;line-height:1.2;
}
.phm-btn{
  display:inline-block;padding:12px 32px;
  border-radius:40px;font-family:var(--phm-sans);
  font-size:.78rem;font-weight:600;letter-spacing:.08em;
  text-transform:uppercase;text-decoration:none;
  cursor:pointer;border:none;
  transition:transform .22s,box-shadow .22s,background .22s;
}
.phm-btn:hover{transform:translateY(-2px)}
.phm-btn-teal{background:var(--phm-teal);color:#fff}
.phm-btn-teal:hover{background:#147080;box-shadow:0 8px 24px rgba(26,122,138,.35)}
.phm-btn-navy{background:var(--phm-navy);color:#fff}
.phm-btn-navy:hover{background:#081520;box-shadow:0 8px 24px rgba(15,37,53,.35)}
.phm-btn-outline{background:transparent;border:1.5px solid var(--phm-teal);color:var(--phm-teal)}
.phm-btn-outline:hover{background:var(--phm-teal);color:#fff}
.phm-btn-ghost{background:transparent;border:1px solid rgba(248,253,253,.3);color:#fff}
.phm-btn-ghost:hover{background:rgba(248,253,253,.1)}

.phm-reveal{opacity:0;transform:translateY(24px);transition:opacity .65s,transform .65s}
.phm-reveal.visible{opacity:1;transform:none}

/* ══════════════════════════════
   HERO — APOTHECARY LAB SCENE
══════════════════════════════ */
.phm-hero{
  position:relative;min-height:100vh;
  display:flex;align-items:center;
  overflow:hidden;
  background:linear-gradient(145deg,#081520 0%,#0f2535 40%,#1a4050 70%,#0f2535 100%);
}
.phm-hero::before{
  content:'';position:absolute;inset:0;
  background:radial-gradient(ellipse 80% 60% at 70% 50%,rgba(26,122,138,.18) 0%,transparent 65%),
              radial-gradient(ellipse 40% 40% at 10% 20%,rgba(42,184,208,.06) 0%,transparent 50%);
  pointer-events:none;
}

/* lab bubbles */
.phm-bubble{
  position:absolute;border-radius:50%;
  filter:blur(2px);
  animation:phm-bubble-float var(--phm-bdur,5s) ease-in-out var(--phm-bdel,0s) infinite alternate;
  pointer-events:none;
}
@keyframes phm-bubble-float{
  0%{transform:translate(0,0) scale(1)}
  100%{transform:translate(var(--phm-bx,8px),var(--phm-by,-16px)) scale(1.1)}
}

/* cross / plus medical symbols */
.phm-cross{
  position:absolute;
  animation:phm-cross-spin var(--phm-cdur,20s) linear var(--phm-cdel,0s) infinite;
  opacity:.1;
  pointer-events:none;
}
.phm-cross::before,.phm-cross::after{
  content:'';position:absolute;
  background:var(--phm-teal);
  border-radius:2px;
}
.phm-cross::before{top:0;left:50%;transform:translateX(-50%);width:30%;height:100%}
.phm-cross::after{top:50%;left:0;transform:translateY(-50%);width:100%;height:30%}
@keyframes phm-cross-spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}

/* ── CSS LAB SCENE ── */
.phm-lab-scene{
  position:absolute;
  right:0;bottom:0;width:52%;height:100%;
  pointer-events:none;
}
/* lab bench */
.phm-bench{
  position:absolute;bottom:0;left:0;right:0;height:28%;
  background:linear-gradient(to top,#1e3040,#2a4050);
}
.phm-bench::before{
  content:'';position:absolute;top:0;left:0;right:0;height:4px;
  background:#3a5060;
}
/* lab wall / cabinet */
.phm-lab-wall{
  position:absolute;top:0;left:0;right:0;bottom:28%;
  background:linear-gradient(180deg,#0a1820 0%,#122030 100%);
}
/* cabinets on wall */
.phm-cabinet{
  position:absolute;
  border:1px solid rgba(26,122,138,.2);
  border-radius:2px;
  background:rgba(26,122,138,.04);
}
/* shelf with bottles */
.phm-shelf{
  position:absolute;
  height:5px;
  background:#3a5060;
  border-radius:2px;
}
/* CSS flask */
.phm-flask{
  position:absolute;
  display:flex;flex-direction:column;align-items:center;
}
.phm-flask-neck{
  width:14px;height:22px;
  border-radius:7px 7px 0 0;
  position:relative;
}
.phm-flask-neck::before{
  content:'';position:absolute;
  top:-8px;left:50%;transform:translateX(-50%);
  width:10px;height:10px;
  background:inherit;border-radius:5px;
}
.phm-flask-body{
  width:42px;height:38px;
  border-radius:0 0 20px 20px;
  position:relative;overflow:hidden;
}
.phm-flask-shine{
  position:absolute;
  top:4px;left:6px;width:8px;height:50%;
  background:rgba(255,255,255,.15);
  border-radius:4px;
}
.phm-flask-liquid{
  position:absolute;
  bottom:0;left:0;right:0;
  border-radius:0 0 20px 20px;
  animation:phm-liquid-wave 3s ease-in-out infinite alternate;
}
@keyframes phm-liquid-wave{
  0%{height:50%}100%{height:58%}
}
/* CSS medicine bottles / pill bottles */
.phm-pill-bottle{
  position:absolute;
  display:flex;flex-direction:column;align-items:center;
}
.phm-pill-cap{
  border-radius:3px 3px 0 0;
}
.phm-pill-body{
  border-radius:0 0 4px 4px;
  position:relative;overflow:hidden;
}
.phm-pill-label{
  position:absolute;top:25%;left:5%;right:5%;bottom:10%;
  background:rgba(255,255,255,.12);border-radius:2px;
}
/* mortar & pestle */
.phm-mortar{
  position:absolute;
}
.phm-mortar-bowl{
  width:50px;height:28px;
  background:linear-gradient(to bottom,rgba(200,220,224,.2),rgba(200,220,224,.1));
  border:2px solid rgba(26,122,138,.4);
  border-radius:0 0 24px 24px;
  border-top:none;
  position:relative;
}
.phm-mortar-bowl::after{
  content:'';position:absolute;
  bottom:6px;left:10%;right:10%;height:8px;
  background:rgba(26,122,138,.15);
  border-radius:50%;
}
.phm-pestle{
  position:absolute;
  top:-22px;left:50%;
  width:6px;height:30px;
  background:linear-gradient(to bottom,rgba(200,220,224,.4),rgba(200,220,224,.2));
  border-radius:3px 3px 2px 2px;
  transform:rotate(30deg);
  transform-origin:50% 100%;
}
/* steriliser / UV lamp glow */
.phm-uv-glow{
  position:absolute;
  top:12%;right:20%;
  width:80px;height:30px;
  background:linear-gradient(180deg,rgba(100,80,240,.2),transparent);
  filter:blur(8px);
  animation:phm-uv-pulse 3s ease-in-out infinite alternate;
}
@keyframes phm-uv-pulse{0%{opacity:.4}100%{opacity:1}}

/* molecules animation */
.phm-molecule{
  position:absolute;
  top:40%;right:10%;
  width:120px;height:120px;
}
.phm-mol-center{
  position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);
  width:16px;height:16px;border-radius:50%;
  background:var(--phm-teal);
  box-shadow:0 0 16px rgba(26,122,138,.6);
}
.phm-mol-node{
  position:absolute;
  top:50%;left:50%;
  width:10px;height:10px;
  border-radius:50%;
  transform-origin:-50% -50%;
}
.phm-mol-bond{
  position:absolute;
  top:50%;left:50%;
  height:1px;
  background:rgba(26,122,138,.4);
  transform-origin:0 50%;
}

/* hero copy */
.phm-hero-content{
  position:relative;z-index:20;
  width:52%;padding:160px 0 120px 60px;
}
.phm-hero h1{
  font-family:var(--phm-serif);
  font-size:clamp(2.8rem,6vw,5rem);
  color:var(--phm-white);font-weight:400;
  line-height:1.1;margin-bottom:22px;
  text-shadow:0 2px 30px rgba(0,0,0,.4);
}
.phm-hero h1 em{font-style:italic;color:rgba(42,184,208,.9)}
.phm-hero-sub{
  font-size:.95rem;font-weight:300;
  color:rgba(224,244,246,.7);
  max-width:440px;margin-bottom:36px;line-height:1.8;
}
.phm-hero-trust{
  display:flex;gap:24px;flex-wrap:wrap;margin-bottom:44px;
}
.phm-trust-item{
  font-size:.72rem;font-weight:600;letter-spacing:.1em;text-transform:uppercase;
  color:rgba(224,244,246,.55);
  display:flex;align-items:center;gap:8px;
}
.phm-trust-item::before{content:'✓';color:var(--phm-teal);font-size:.8rem;font-weight:700}
.phm-hero-scroll{
  position:absolute;bottom:36px;left:60px;
  display:flex;flex-direction:column;align-items:flex-start;gap:8px;
  color:rgba(224,244,246,.35);
  font-size:.65rem;letter-spacing:.16em;text-transform:uppercase;
}
.phm-scroll-line{
  width:40px;height:1px;
  background:linear-gradient(to right,rgba(224,244,246,.5),transparent);
  animation:phm-scroll-ext 2s ease-in-out infinite alternate;
}
@keyframes phm-scroll-ext{0%{width:28px;opacity:.35}100%{width:56px;opacity:.8}}

/* ══════════════════════════════
   MARQUEE
══════════════════════════════ */
.phm-marquee-wrap{background:var(--phm-teal);padding:14px 0;overflow:hidden}
.phm-marquee-track{
  display:flex;width:max-content;
  animation:phm-marquee 28s linear infinite;
}
.phm-marquee-track:hover{animation-play-state:paused}
.phm-marquee-item{
  padding:0 20px;font-size:.72rem;font-weight:600;
  letter-spacing:.18em;text-transform:uppercase;
  color:rgba(255,255,255,.85);white-space:nowrap;
}
@keyframes phm-marquee{from{transform:translateX(0)}to{transform:translateX(-50%)}}

/* ══════════════════════════════
   SERVICES
══════════════════════════════ */
.phm-services{padding:100px 0;background:var(--phm-cream)}
.phm-section-header{text-align:center;margin-bottom:52px}
.phm-filter-bar{
  display:flex;flex-wrap:wrap;justify-content:center;gap:10px;margin-bottom:40px;
}
.phm-filter-btn{
  padding:8px 22px;border-radius:40px;
  border:1.5px solid var(--phm-slate);
  background:transparent;color:var(--phm-slate);
  font-family:var(--phm-sans);font-size:.72rem;font-weight:600;
  letter-spacing:.1em;text-transform:uppercase;cursor:pointer;transition:all .2s;
}
.phm-filter-btn.active,
.phm-filter-btn:hover{background:var(--phm-teal);border-color:var(--phm-teal);color:#fff}
.phm-svc-grid{
  display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:20px;
}
.phm-svc-card{
  background:#fff;border-radius:10px;padding:28px 24px;
  border-top:3px solid var(--phm-teal);
  transition:transform .25s,box-shadow .25s;
}
.phm-svc-card:hover{transform:translateY(-4px);box-shadow:0 14px 36px rgba(26,122,138,.12)}
.phm-svc-card.hidden{display:none}
.phm-svc-icon{font-size:1.8rem;margin-bottom:14px;display:block}
.phm-svc-title{
  font-family:var(--phm-serif);font-size:1.1rem;
  color:var(--phm-navy);margin-bottom:8px;
}
.phm-svc-desc{font-size:.82rem;color:var(--phm-slate);line-height:1.75}

/* ══════════════════════════════
   PRODUCTS / CATEGORIES
══════════════════════════════ */
.phm-products{padding:100px 0;background:var(--phm-navy)}
.phm-products .phm-eyebrow{color:rgba(26,122,138,.8)}
.phm-products .phm-section-title{color:var(--phm-white)}
.phm-product-grid{
  display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:20px;
}
.phm-product-card{
  background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);
  border-radius:10px;padding:32px 24px;
  transition:background .25s,border-color .25s;
  text-align:center;
}
.phm-product-card:hover{background:rgba(255,255,255,.07);border-color:rgba(26,122,138,.3)}
.phm-product-icon{font-size:.8rem;color:var(--phm-teal);letter-spacing:.2em;margin-bottom:14px}
.phm-product-name{
  font-family:var(--phm-serif);font-size:1.1rem;
  color:var(--phm-mint);margin-bottom:8px;
}
.phm-product-count{
  font-size:.72rem;font-weight:600;letter-spacing:.1em;text-transform:uppercase;
  color:rgba(224,244,246,.45);
}

/* ══════════════════════════════
   ABOUT / LAB ILLUSTRATION
══════════════════════════════ */
.phm-about{padding:110px 0;background:var(--phm-mint)}
.phm-about-inner{display:grid;grid-template-columns:1fr 1fr;gap:80px;align-items:center}
.phm-about-text p{color:var(--phm-slate);font-size:.9rem;line-height:1.85;margin-bottom:16px}
.phm-lab-art{
  position:relative;height:460px;border-radius:14px;overflow:hidden;
  background:linear-gradient(160deg,#081520,#0f2535);
}
/* compounding lab CSS scene */
.phm-lab-bench2{
  position:absolute;bottom:0;left:0;right:0;height:30%;
  background:linear-gradient(to top,#1e3040,#2a4050);
}
.phm-lab-bench2::before{
  content:'';position:absolute;top:0;left:0;right:0;height:4px;
  background:#3a5060;
}
.phm-lab-wall2{
  position:absolute;top:0;left:0;right:0;bottom:30%;
  background:linear-gradient(180deg,#0a1820,#0f2030);
}
.phm-lab-wall2::after{
  content:'';position:absolute;inset:0;
  background:repeating-linear-gradient(90deg,rgba(26,122,138,.03) 0,rgba(26,122,138,.03) 1px,transparent 1px,transparent 60px),
              repeating-linear-gradient(0deg,rgba(26,122,138,.03) 0,rgba(26,122,138,.03) 1px,transparent 1px,transparent 60px);
}
/* scales */
.phm-scales{
  position:absolute;bottom:28%;left:15%;
}
.phm-scales-arm{
  width:70px;height:3px;
  background:rgba(26,122,138,.6);
  border-radius:2px;
  position:relative;
}
.phm-scales-arm::before{
  content:'';position:absolute;
  top:50%;left:50%;transform:translate(-50%,-50%);
  width:3px;height:30px;
  background:rgba(26,122,138,.5);
}
.phm-scales-pan{
  position:absolute;bottom:-20px;
  width:22px;height:6px;
  background:rgba(26,122,138,.4);
  border-radius:2px;
}
.phm-scales-pan::before{
  content:'';position:absolute;
  bottom:100%;left:50%;transform:translateX(-50%);
  width:1px;height:20px;
  background:rgba(26,122,138,.3);
}
/* microscope */
.phm-microscope{
  position:absolute;bottom:28%;right:15%;
  width:40px;
}
.phm-scope-base{
  width:40px;height:8px;
  background:rgba(200,220,224,.2);
  border-radius:4px;
}
.phm-scope-arm{
  width:5px;height:55px;
  background:rgba(200,220,224,.2);
  margin:0 auto;
  border-radius:2px;
}
.phm-scope-head{
  width:22px;height:10px;
  background:rgba(200,220,224,.25);
  border-radius:2px;
  margin:0 auto;
  transform:rotate(-15deg);
}
.phm-scope-eye{
  width:10px;height:10px;
  border-radius:50%;
  background:rgba(26,122,138,.4);
  margin:-2px auto 0;
  box-shadow:0 0 8px rgba(26,122,138,.3);
}
/* pill counter tray */
.phm-pill-tray{
  position:absolute;bottom:29%;left:50%;transform:translateX(-50%);
  width:100px;height:16px;
  background:rgba(200,220,224,.1);
  border:1px solid rgba(26,122,138,.2);
  border-radius:4px;
  display:flex;align-items:center;justify-content:center;gap:4px;
  padding:0 6px;
}
.phm-pill{
  width:10px;height:6px;
  border-radius:3px;
  display:inline-block;
}
/* computer screen */
.phm-lab-screen{
  position:absolute;top:12%;left:50%;transform:translateX(-50%);
  width:90px;height:64px;
  background:#0a1628;
  border:2px solid rgba(26,122,138,.3);
  border-radius:4px;
  display:flex;flex-direction:column;
  padding:6px;gap:4px;
}
.phm-screen-row{
  height:5px;border-radius:2px;
  background:rgba(26,122,138,.4);
}
.phm-screen-row:nth-child(2){width:70%;opacity:.6}
.phm-screen-row:nth-child(3){width:85%;opacity:.4}
.phm-screen-row:nth-child(4){width:60%;opacity:.5}
.phm-screen-stand{
  position:absolute;
  top:calc(12% + 64px);left:50%;transform:translateX(-50%);
  width:4px;height:18px;
  background:rgba(26,122,138,.2);
}
/* lab glow from screen */
.phm-screen-glow{
  position:absolute;
  top:calc(12% + 10px);left:50%;transform:translateX(-50%);
  width:150px;height:60px;
  background:radial-gradient(ellipse,rgba(26,122,138,.1),transparent 70%);
  pointer-events:none;
}
/* wall-mounted medicine cabinets */
.phm-med-cabinet{
  position:absolute;top:18%;
  width:70px;height:80px;
  border:1px solid rgba(26,122,138,.2);
  border-radius:3px;
  background:rgba(26,122,138,.04);
  display:flex;flex-direction:column;justify-content:space-evenly;
  padding:8px 6px;
}
.phm-cabinet-shelf-item{
  height:5px;border-radius:2px;
  background:rgba(26,122,138,.3);
}

/* ══════════════════════════════
   STATS
══════════════════════════════ */
.phm-stats{padding:80px 0;background:var(--phm-teal)}
.phm-stats-grid{
  display:grid;grid-template-columns:repeat(4,1fr);gap:40px;text-align:center;
}
.phm-stat-num{
  font-family:var(--phm-serif);font-size:clamp(2.4rem,5vw,3.8rem);
  color:#fff;font-weight:400;line-height:1;margin-bottom:8px;
}
.phm-stat-label{
  font-size:.72rem;font-weight:600;letter-spacing:.15em;text-transform:uppercase;
  color:rgba(255,255,255,.65);
}

/* ══════════════════════════════
   TEAM
══════════════════════════════ */
.phm-team{padding:100px 0;background:var(--phm-cream)}
.phm-team-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:24px}
.phm-team-card{
  background:#fff;border-radius:12px;text-align:center;
  padding:34px 22px 28px;
  transition:transform .25s,box-shadow .25s;
}
.phm-team-card:hover{transform:translateY(-4px);box-shadow:0 14px 36px rgba(0,0,0,.08)}
.phm-team-avatar{
  position:relative;width:100px;height:120px;margin:0 auto 18px;
}
.phm-team-head{
  position:absolute;top:0;left:50%;transform:translateX(-50%);
  width:44px;height:44px;border-radius:50%;background:#d4b090;
}
.phm-team-torso{
  position:absolute;top:48px;left:50%;transform:translateX(-50%);
  width:56px;height:52px;border-radius:28px 28px 0 0;
}
.phm-team-name{
  font-family:var(--phm-serif);font-size:1.15rem;color:var(--phm-navy);margin-bottom:4px;
}
.phm-team-role{
  font-size:.72rem;font-weight:600;letter-spacing:.1em;text-transform:uppercase;
  color:var(--phm-teal);margin-bottom:6px;
}
.phm-team-qual{
  display:inline-block;font-size:.68rem;padding:4px 12px;
  background:var(--phm-mint);color:var(--phm-teal);border-radius:20px;
  font-weight:500;
}

/* ══════════════════════════════
   FAQ ACCORDION
══════════════════════════════ */
.phm-faq{padding:100px 0;background:var(--phm-white)}
.phm-faq-list{max-width:780px;margin:0 auto}
.phm-faq-item{border-bottom:1px solid var(--phm-light-teal)}
.phm-faq-question{
  width:100%;text-align:left;
  padding:20px 0;background:transparent;border:none;cursor:pointer;
  display:flex;justify-content:space-between;align-items:center;gap:16px;
  font-family:var(--phm-serif);font-size:1rem;color:var(--phm-navy);
  font-weight:400;
}
.phm-faq-icon{
  width:24px;height:24px;flex-shrink:0;
  border-radius:50%;background:var(--phm-mint);
  display:flex;align-items:center;justify-content:center;
  font-size:.9rem;color:var(--phm-teal);
  transition:transform .3s,background .2s;
  font-style:normal;
}
.phm-faq-item.open .phm-faq-icon{transform:rotate(45deg);background:var(--phm-teal);color:#fff}
.phm-faq-answer{
  max-height:0;overflow:hidden;
  transition:max-height .35s ease,padding .3s;
  font-size:.88rem;color:var(--phm-slate);line-height:1.8;
}
.phm-faq-item.open .phm-faq-answer{max-height:200px;padding-bottom:18px}

/* ══════════════════════════════
   TESTIMONIALS
══════════════════════════════ */
.phm-testimonials{padding:100px 0;background:var(--phm-mint)}
.phm-testi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:22px}
.phm-testi-card{
  background:#fff;border-radius:12px;padding:30px 26px;
  border-left:3px solid var(--phm-teal);
}
.phm-testi-text{
  font-style:italic;font-size:.88rem;color:var(--phm-slate);
  line-height:1.8;margin-bottom:16px;
}
.phm-testi-author{font-size:.75rem;font-weight:600;letter-spacing:.06em;color:var(--phm-navy)}

/* ══════════════════════════════
   CONTACT / BOOKING
══════════════════════════════ */
.phm-contact{padding:110px 0;background:var(--phm-navy);position:relative;overflow:hidden}
.phm-contact::before{
  content:'';position:absolute;top:-200px;right:-100px;
  width:500px;height:500px;border-radius:50%;
  background:radial-gradient(circle,rgba(26,122,138,.15),transparent 70%);
  pointer-events:none;
}
.phm-contact-inner{
  position:relative;z-index:2;
  display:grid;grid-template-columns:1fr 1fr;gap:80px;align-items:start;
}
.phm-contact-info h2{
  font-family:var(--phm-serif);font-size:clamp(1.8rem,3.5vw,2.6rem);
  color:var(--phm-white);margin-bottom:16px;
}
.phm-contact-info p{color:rgba(224,244,246,.6);font-size:.88rem;line-height:1.85;margin-bottom:28px}
.phm-contact-details{list-style:none;display:flex;flex-direction:column;gap:14px}
.phm-contact-details li{
  font-size:.82rem;color:rgba(224,244,246,.65);
  display:flex;align-items:center;gap:12px;
}
.phm-contact-icon{
  width:34px;height:34px;border-radius:50%;
  background:rgba(26,122,138,.3);
  display:flex;align-items:center;justify-content:center;
  font-size:.8rem;flex-shrink:0;
}
.phm-form{
  background:rgba(255,255,255,.05);
  border:1px solid rgba(255,255,255,.1);
  border-radius:14px;padding:36px 34px;
}
.phm-form h3{
  font-family:var(--phm-serif);font-size:1.5rem;
  color:var(--phm-white);margin-bottom:24px;
}
.phm-field{margin-bottom:18px}
.phm-field label{
  display:block;font-size:.68rem;font-weight:600;
  letter-spacing:.14em;text-transform:uppercase;
  color:rgba(224,244,246,.5);margin-bottom:7px;
}
.phm-field input,
.phm-field select,
.phm-field textarea{
  width:100%;padding:12px 16px;
  background:rgba(255,255,255,.06);
  border:1px solid rgba(255,255,255,.14);
  border-radius:var(--phm-radius);
  color:var(--phm-white);font-family:var(--phm-sans);font-size:.86rem;
  transition:border-color .2s;
}
.phm-field select option{background:var(--phm-navy);color:var(--phm-white)}
.phm-field input:focus,
.phm-field select:focus,
.phm-field textarea:focus{outline:none;border-color:var(--phm-teal)}
.phm-field textarea{height:90px;resize:vertical}
.phm-field-row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.phm-form-note{font-size:.72rem;color:rgba(224,244,246,.35);margin-bottom:20px;line-height:1.6}
.phm-form .phm-btn{width:100%;text-align:center}
.phm-form-success{
  display:none;text-align:center;padding:24px;
  font-family:var(--phm-serif);font-size:1rem;color:var(--phm-mint);
}

/* responsive */
@media(max-width:860px){
  .phm-hero{flex-direction:column}
  .phm-hero-content{width:100%;padding:120px 24px 60px}
  .phm-lab-scene{position:relative;width:100%;height:300px}
  .phm-about-inner,.phm-contact-inner{grid-template-columns:1fr;gap:48px}
  .phm-lab-art{height:320px}
  .phm-stats-grid{grid-template-columns:repeat(2,1fr)}
}
@media(max-width:600px){
  .phm-stats-grid{grid-template-columns:1fr 1fr}
  .phm-field-row{grid-template-columns:1fr}
  .phm-hero h1{font-size:2.6rem}
}
</style>
<?php get_header(); ?>
<div class="phm-page">
">
<?php wp_body_open(); ?>

<!-- ══════════════════════════════
     HERO
══════════════════════════════ -->
<section class="phm-hero">

  <!-- bubbles -->
  <?php foreach($bubbles as $b): ?>
  <div class="phm-bubble" style="
    left:<?php echo $b['x']; ?>%;top:<?php echo $b['y']; ?>%;
    width:<?php echo $b['size']; ?>px;height:<?php echo $b['size']; ?>px;
    background:<?php echo $b['color']; ?>;opacity:<?php echo $b['alpha']; ?>;
    border:1px solid rgba(255,255,255,.15);
    --phm-bdur:<?php echo $b['dur']; ?>s;
    --phm-bdel:<?php echo $b['del']; ?>s;
    --phm-bx:<?php echo (rand(0,1)?'':'-').rand(4,12); ?>px;
    --phm-by:<?php echo (rand(0,1)?'':'-').rand(8,20); ?>px;
  "></div>
  <?php endforeach; ?>

  <!-- medical crosses -->
  <?php for($ci=0;$ci<6;$ci++): ?>
  <div class="phm-cross" style="
    left:<?php echo rand(5,90); ?>%;top:<?php echo rand(10,80); ?>%;
    width:<?php echo rand(20,40); ?>px;height:<?php echo rand(20,40); ?>px;
    --phm-cdur:<?php echo round(15+lcg_value()*20,1); ?>s;
    --phm-cdel:<?php echo round(lcg_value()*5,2); ?>s;
  "></div>
  <?php endfor; ?>

  <!-- lab scene right -->
  <div class="phm-lab-scene">
    <div class="phm-lab-wall"></div>
    <div class="phm-bench"></div>
    <!-- UV steriliser glow -->
    <div class="phm-uv-glow"></div>
    <!-- cabinets on wall -->
    <?php
    $cab_positions=[[5,15],[5,60],[70,15],[70,60]];
    foreach($cab_positions as $cp):
    ?>
    <div class="phm-cabinet" style="left:<?php echo $cp[0]; ?>%;top:<?php echo $cp[1]; ?>%;width:20%;height:20%">
      <?php for($si=0;$si<3;$si++): ?>
      <div style="position:absolute;left:5%;right:5%;height:3px;background:rgba(26,122,138,.2);top:<?php echo 25+$si*28; ?>%"></div>
      <?php endfor; ?>
    </div>
    <?php endforeach; ?>

    <!-- flasks on bench -->
    <?php
    $flasks=[
      ['x'=>10,'color'=>'#1a7a8a','liquid'=>'#0f9ab0','ht'=>38],
      ['x'=>22,'color'=>'#1a7a8a','liquid'=>'rgba(26,122,138,.6)','ht'=>28],
      ['x'=>55,'color'=>'#0f2535','liquid'=>'rgba(201,168,76,.5)','ht'=>45],
    ];
    foreach($flasks as $fl):
    ?>
    <div class="phm-flask" style="left:<?php echo $fl['x']; ?>%;bottom:28%">
      <div class="phm-flask-neck" style="background:<?php echo $fl['color']; ?>"></div>
      <div class="phm-flask-body" style="background:rgba(26,122,138,.1);border:1.5px solid rgba(26,122,138,.3)">
        <div class="phm-flask-liquid" style="background:<?php echo $fl['liquid']; ?>;height:<?php echo $fl['ht']; ?>%"></div>
        <div class="phm-flask-shine"></div>
      </div>
    </div>
    <?php endforeach; ?>

    <!-- pill bottles -->
    <?php
    $pill_bottles=[
      ['x'=>35,'color'=>'#c47a8a','cap'=>'#a06068','w'=>14,'h'=>40],
      ['x'=>44,'color'=>'#1a7a8a','cap'=>'#0f6070','w'=>12,'h'=>34],
      ['x'=>67,'color'=>'#8aab80','cap'=>'#6a8a60','w'=>14,'h'=>38],
    ];
    foreach($pill_bottles as $pb):
    ?>
    <div class="phm-pill-bottle" style="left:<?php echo $pb['x']; ?>%;bottom:28%">
      <div class="phm-pill-cap" style="width:<?php echo $pb['w']+4; ?>px;height:10px;background:<?php echo $pb['cap']; ?>"></div>
      <div class="phm-pill-body" style="width:<?php echo $pb['w']; ?>px;height:<?php echo $pb['h']; ?>px;background:<?php echo $pb['color']; ?>">
        <div class="phm-pill-label"></div>
      </div>
    </div>
    <?php endforeach; ?>

    <!-- mortar & pestle -->
    <div class="phm-mortar" style="left:78%;bottom:28%">
      <div class="phm-mortar-bowl">
        <div class="phm-pestle"></div>
      </div>
    </div>

    <!-- molecule decoration -->
    <div class="phm-molecule">
      <div class="phm-mol-center"></div>
      <?php foreach($mol_nodes as $mn):
        $rad_x = cos(deg2rad($mn['angle'])) * $mn['r'] / 2;
        $rad_y = sin(deg2rad($mn['angle'])) * $mn['r'] / 2;
      ?>
      <div class="phm-mol-bond" style="
        width:<?php echo $mn['r']/2; ?>px;
        transform:rotate(<?php echo $mn['angle']; ?>deg);
        margin-left:-1px;margin-top:-0.5px;
      "></div>
      <div class="phm-mol-node" style="
        width:<?php echo $mn['size']; ?>px;height:<?php echo $mn['size']; ?>px;
        background:<?php echo $mn['color']; ?>;
        border-radius:50%;
        position:absolute;
        top:calc(50% + <?php echo $rad_y; ?>px - <?php echo $mn['size']/2; ?>px);
        left:calc(50% + <?php echo $rad_x; ?>px - <?php echo $mn['size']/2; ?>px);
        box-shadow:0 0 8px <?php echo $mn['color']; ?>80;
      "></div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- hero copy -->
  <div class="phm-hero-content">
    <span class="phm-eyebrow">Est. 1987 — Independent Pharmacy</span>
    <h1>Your Health.<br><em>Our Expertise.</em></h1>
    <p class="phm-hero-sub">A modern, independent pharmacy offering expert dispensing, bespoke compounding, and personalised health consultations.</p>
    <div class="phm-hero-trust">
      <span class="phm-trust-item">GPhC Registered</span>
      <span class="phm-trust-item">NHS Pharmacy First</span>
      <span class="phm-trust-item">Free Medication Review</span>
    </div>
    <div style="display:flex;gap:14px;flex-wrap:wrap">
      <a href="#services" class="phm-btn phm-btn-teal">Our Services</a>
      <a href="#contact" class="phm-btn phm-btn-ghost">Book Consultation</a>
    </div>
  </div>

  <div class="phm-hero-scroll">
    <div class="phm-scroll-line"></div>
    <span>Scroll</span>
  </div>

</section>

<!-- MARQUEE -->
<div class="phm-marquee-wrap">
  <div class="phm-marquee-track">
    <?php foreach($marquee as $item): ?>
    <span class="phm-marquee-item"><?php echo esc_html($item); ?></span>
    <?php endforeach; ?>
  </div>
</div>

<!-- ══════════════════════════════
     SERVICES
══════════════════════════════ -->
<section class="phm-services" id="services">
  <div class="phm-wrap">
    <div class="phm-section-header phm-reveal">
      <span class="phm-eyebrow">What We Offer</span>
      <h2 class="phm-section-title">Pharmacy Services</h2>
    </div>
    <div class="phm-filter-bar phm-reveal">
      <button class="phm-filter-btn active" data-filter="all">All Services</button>
      <button class="phm-filter-btn" data-filter="prescriptions">Prescriptions</button>
      <button class="phm-filter-btn" data-filter="testing">Health Testing</button>
      <button class="phm-filter-btn" data-filter="skincare">Compounding</button>
      <button class="phm-filter-btn" data-filter="vaccinations">Vaccinations</button>
    </div>
    <div class="phm-svc-grid" id="phm-svc-grid">
      <?php
      $svc_border_colors=['prescriptions'=>'#1a7a8a','testing'=>'#c9a84c','skincare'=>'#c47a8a','vaccinations'=>'#8aab80'];
      foreach($services as $svc):
        $bc=$svc_border_colors[$svc['cat']]??'#1a7a8a';
      ?>
      <div class="phm-svc-card phm-reveal" data-cat="<?php echo esc_attr($svc['cat']); ?>" style="border-top-color:<?php echo esc_attr($bc); ?>">
        <span class="phm-svc-icon"><?php echo $svc['icon']; ?></span>
        <div class="phm-svc-title"><?php echo esc_html($svc['title']); ?></div>
        <p class="phm-svc-desc"><?php echo esc_html($svc['desc']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════
     PRODUCTS / CATEGORIES
══════════════════════════════ -->
<section class="phm-products">
  <div class="phm-wrap">
    <div class="phm-section-header phm-reveal">
      <span class="phm-eyebrow">In-Store & Online</span>
      <h2 class="phm-section-title">Product Categories</h2>
    </div>
    <div class="phm-product-grid">
      <?php foreach($products as $p): ?>
      <div class="phm-product-card phm-reveal">
        <div class="phm-product-icon">✦ ✦ ✦</div>
        <div class="phm-product-name"><?php echo esc_html($p['name']); ?></div>
        <div class="phm-product-count"><?php echo esc_html($p['count']); ?> products</div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════
     ABOUT / LAB ART
══════════════════════════════ -->
<section class="phm-about">
  <div class="phm-wrap">
    <div class="phm-about-inner">
      <div class="phm-lab-art phm-reveal">
        <div class="phm-lab-wall2"></div>
        <div class="phm-lab-bench2"></div>
        <!-- computer screen -->
        <div class="phm-lab-screen">
          <div class="phm-screen-row"></div>
          <div class="phm-screen-row"></div>
          <div class="phm-screen-row"></div>
          <div class="phm-screen-row"></div>
        </div>
        <div class="phm-screen-stand"></div>
        <div class="phm-screen-glow"></div>
        <!-- medicine cabinet -->
        <div class="phm-med-cabinet" style="left:6%">
          <?php for($mi=0;$mi<4;$mi++): ?>
          <div class="phm-cabinet-shelf-item" style="background:rgba(<?php echo rand(0,1)?'26,122,138':'201,168,76'; ?>,.5)"></div>
          <?php endfor; ?>
        </div>
        <div class="phm-med-cabinet" style="right:6%">
          <?php for($mi=0;$mi<4;$mi++): ?>
          <div class="phm-cabinet-shelf-item" style="background:rgba(<?php echo rand(0,1)?'138,171,128':'196,122,138'; ?>,.5)"></div>
          <?php endfor; ?>
        </div>
        <!-- scales on bench -->
        <div class="phm-scales">
          <div class="phm-scales-arm">
            <div class="phm-scales-pan" style="left:-2px"></div>
            <div class="phm-scales-pan" style="right:-2px"></div>
          </div>
          <div style="position:absolute;top:100%;left:50%;transform:translateX(-50%);width:3px;height:25px;background:rgba(26,122,138,.4)"></div>
          <div style="position:absolute;top:calc(100% + 25px);left:50%;transform:translateX(-50%);width:30px;height:4px;background:rgba(26,122,138,.4);border-radius:2px"></div>
        </div>
        <!-- microscope -->
        <div class="phm-microscope">
          <div class="phm-scope-eye"></div>
          <div class="phm-scope-head"></div>
          <div class="phm-scope-arm"></div>
          <div class="phm-scope-base"></div>
        </div>
        <!-- pill counting tray -->
        <div class="phm-pill-tray">
          <?php $pill_colors=['#1a7a8a','#c47a8a','#8aab80','#c9a84c','#1a7a8a','#c47a8a','#8aab80']; ?>
          <?php for($pi=0;$pi<7;$pi++): ?>
          <div class="phm-pill" style="background:<?php echo $pill_colors[$pi]; ?>"></div>
          <?php endfor; ?>
        </div>
      </div>
      <div class="phm-reveal">
        <span class="phm-eyebrow">Our Story</span>
        <h2 class="phm-section-title">Independent Pharmacy Since 1987</h2>
        <p>Founded by Dr. Anjali Mehta in 1987, our pharmacy has been a trusted fixture in the community for nearly four decades. We've grown from a small dispensary into a full-service clinical pharmacy — but our values haven't changed.</p>
        <p>We believe that a pharmacist should be more than a dispenser. We are clinicians, advisors, and advocates for the health of every patient who walks through our door. We take the time that the NHS system often can't afford.</p>
        <p>Our compounding lab, opened in 2015, allows us to prepare bespoke formulations for patients with allergies, sensitivities, or requirements that no commercial product can meet.</p>
        <a href="#contact" class="phm-btn phm-btn-teal" style="margin-top:20px">Book a Consultation</a>
      </div>
    </div>
  </div>
</section>

<!-- ══════════════════════════════
     STATS
══════════════════════════════ -->
<section class="phm-stats">
  <div class="phm-wrap">
    <div class="phm-stats-grid">
      <?php
      $stats=[
        ['num'=>37,'suffix'=>' yrs','label'=>'Years of Service'],
        ['num'=>4800,'suffix'=>'+','label'=>'Registered Patients'],
        ['num'=>220,'suffix'=>'+','label'=>'Compounds Monthly'],
        ['num'=>98,'suffix'=>'%','label'=>'Patient Satisfaction'],
      ];
      foreach($stats as $st):
      ?>
      <div class="phm-reveal" style="text-align:center">
        <div class="phm-stat-num" data-target="<?php echo $st['num']; ?>" data-suffix="<?php echo esc_attr($st['suffix']); ?>">0</div>
        <div class="phm-stat-label"><?php echo esc_html($st['label']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════
     TEAM
══════════════════════════════ -->
<section class="phm-team">
  <div class="phm-wrap">
    <div class="phm-section-header phm-reveal">
      <span class="phm-eyebrow">Our Pharmacists</span>
      <h2 class="phm-section-title">The Clinical Team</h2>
    </div>
    <div class="phm-team-grid">
      <?php foreach($team as $ti=>$t):
        $scrub_color=$t['scrub'];
        $skin_colors=['#d4a87a','#c8a870','#d4b090','#c09060'];
        $skin=$skin_colors[$ti%count($skin_colors)];
      ?>
      <div class="phm-team-card phm-reveal">
        <div class="phm-team-avatar">
          <div class="phm-team-head" style="background:<?php echo $skin; ?>">
            <div style="position:absolute;top:-5px;left:1px;right:1px;height:<?php echo $t['female']?'20px':'12px'; ?>;background:<?php echo $t['hair']; ?>;border-radius:10px 10px 0 0"></div>
            <?php if($t['female']&&$ti===0): // priya bun ?>
            <div style="position:absolute;top:-8px;right:-3px;width:12px;height:12px;border-radius:50%;background:<?php echo $t['hair']; ?>"></div>
            <?php elseif($t['female']&&$ti===2): // fatima hijab suggestion — show neat hair ?>
            <?php endif; ?>
            <?php if($t['glasses']): ?>
            <div style="position:absolute;bottom:7px;left:3px;right:3px;height:4px;background:rgba(0,0,0,.3);border-radius:2px;display:flex;gap:2px">
              <div style="flex:1;border:1px solid rgba(0,0,0,.35);border-radius:2px"></div>
              <div style="flex:1;border:1px solid rgba(0,0,0,.35);border-radius:2px"></div>
            </div>
            <?php endif; ?>
          </div>
          <!-- scrubs torso -->
          <div class="phm-team-torso" style="background:<?php echo $scrub_color; ?>">
            <!-- stethoscope loop -->
            <div style="position:absolute;top:8px;left:50%;transform:translateX(-50%);width:26px;height:14px;border:2px solid rgba(255,255,255,.2);border-bottom:none;border-radius:13px 13px 0 0"></div>
            <!-- ID badge -->
            <div style="position:absolute;top:26px;left:50%;transform:translateX(-50%);width:18px;height:12px;background:rgba(255,255,255,.15);border-radius:2px"></div>
          </div>
        </div>
        <div class="phm-team-name"><?php echo esc_html($t['name']); ?></div>
        <div class="phm-team-role"><?php echo esc_html($t['role']); ?></div>
        <span class="phm-team-qual"><?php echo esc_html($t['qual']); ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════
     FAQ ACCORDION
══════════════════════════════ -->
<section class="phm-faq" id="faq">
  <div class="phm-wrap">
    <div class="phm-section-header phm-reveal">
      <span class="phm-eyebrow">Common Questions</span>
      <h2 class="phm-section-title">Frequently Asked</h2>
    </div>
    <div class="phm-faq-list">
      <?php foreach($faqs as $fi=>$faq): ?>
      <div class="phm-faq-item phm-reveal">
        <button class="phm-faq-question" aria-expanded="false">
          <?php echo esc_html($faq['q']); ?>
          <span class="phm-faq-icon">+</span>
        </button>
        <div class="phm-faq-answer">
          <?php echo esc_html($faq['a']); ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════
     TESTIMONIALS
══════════════════════════════ -->
<section class="phm-testimonials">
  <div class="phm-wrap">
    <div class="phm-section-header phm-reveal">
      <span class="phm-eyebrow">Patient Stories</span>
      <h2 class="phm-section-title">What Our Patients Say</h2>
    </div>
    <div class="phm-testi-grid">
      <?php foreach($testimonials as $t): ?>
      <div class="phm-testi-card phm-reveal">
        <p class="phm-testi-text">"<?php echo esc_html($t['text']); ?>"</p>
        <div class="phm-testi-author"><?php echo esc_html($t['author']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════
     CONTACT / BOOK
══════════════════════════════ -->
<section class="phm-contact" id="contact">
  <div class="phm-wrap">
    <div class="phm-contact-inner">
      <div class="phm-contact-info phm-reveal">
        <span class="phm-eyebrow">Book & Visit</span>
        <h2>Book a Consultation or Order a Test</h2>
        <p>Our pharmacists are available for appointments Monday to Saturday. Walk-ins are welcome for all standard services. Use the form to book a specific appointment or place a compounding order.</p>
        <ul class="phm-contact-details">
          <li><span class="phm-contact-icon">📍</span>42 Wellbeing Road, Kensington, London W8 4PZ</li>
          <li><span class="phm-contact-icon">📞</span>+44 20 7946 0201</li>
          <li><span class="phm-contact-icon">✉</span>hello@mehtapharmacy.co.uk</li>
          <li><span class="phm-contact-icon">🕐</span>Mon–Fri: 08:30–19:00 · Sat: 09:00–17:00</li>
        </ul>
      </div>
      <div class="phm-form phm-reveal">
        <h3>Make an Appointment</h3>
        <?php wp_nonce_field('tf_phm_booking','tf_phm_nonce'); ?>
        <div class="phm-field-row">
          <div class="phm-field">
            <label>First Name</label>
            <input type="text" name="phm_fname" placeholder="Rebecca" required>
          </div>
          <div class="phm-field">
            <label>Last Name</label>
            <input type="text" name="phm_lname" placeholder="Thomas" required>
          </div>
        </div>
        <div class="phm-field">
          <label>Email Address</label>
          <input type="email" name="phm_email" placeholder="rebecca@example.com" required>
        </div>
        <div class="phm-field">
          <label>Phone Number</label>
          <input type="tel" name="phm_phone" placeholder="+44 7700 900000">
        </div>
        <div class="phm-field">
          <label>Service Required</label>
          <select name="phm_service">
            <option value="">— Select service —</option>
            <option>Prescription Dispensing</option>
            <option>Bespoke Compounding</option>
            <option>Health Blood Test</option>
            <option>Travel Vaccination</option>
            <option>Flu Jab</option>
            <option>Medicines Use Review</option>
            <option>General Consultation</option>
          </select>
        </div>
        <div class="phm-field-row">
          <div class="phm-field">
            <label>Preferred Date</label>
            <input type="date" name="phm_date">
          </div>
          <div class="phm-field">
            <label>Preferred Time</label>
            <select name="phm_time">
              <option value="">— Time —</option>
              <option>Morning (08:30–12:00)</option>
              <option>Afternoon (12:00–17:00)</option>
              <option>Evening (17:00–19:00)</option>
            </select>
          </div>
        </div>
        <div class="phm-field">
          <label>Additional Notes</label>
          <textarea name="phm_notes" placeholder="Any relevant medical information or requests…"></textarea>
        </div>
        <p class="phm-form-note">Your information is held in strict confidence in accordance with NHS data protection standards and our privacy policy.</p>
        <button type="submit" class="phm-btn phm-btn-teal" id="phm-submit-btn">Book Appointment</button>
        <div class="phm-form-success" id="phm-success">
          ✓ Thank you. Your appointment request has been received. We'll confirm by email within 2 hours.
        </div>
      </div>
    </div>
  </div>
</section>
<script>
(function(){
  /* scroll reveal */
  const ro=new IntersectionObserver(e=>{
    e.forEach(en=>{if(en.isIntersecting){en.target.classList.add('visible');ro.unobserve(en.target);}});
  },{threshold:.1,rootMargin:'0px 0px -40px 0px'});
  document.querySelectorAll('.phm-reveal').forEach(el=>ro.observe(el));

  /* animated counters */
  const easeOut=t=>1-Math.pow(1-t,3);
  const co=new IntersectionObserver(e=>{
    e.forEach(en=>{
      if(!en.isIntersecting)return;
      const el=en.target,target=+el.dataset.target,suffix=el.dataset.suffix||'',dur=1800;
      let start=null;
      (function tick(ts){
        if(!start)start=ts;
        const p=Math.min((ts-start)/dur,1);
        el.textContent=Math.round(easeOut(p)*target)+suffix;
        if(p<1)requestAnimationFrame(tick);
      })(performance.now());
      co.unobserve(el);
    });
  },{threshold:.4});
  document.querySelectorAll('.phm-stat-num[data-target]').forEach(el=>co.observe(el));

  /* services filter */
  const filterBtns=document.querySelectorAll('.phm-filter-btn');
  const svcCards=document.querySelectorAll('#phm-svc-grid .phm-svc-card');
  filterBtns.forEach(btn=>{
    btn.addEventListener('click',()=>{
      filterBtns.forEach(b=>{b.classList.remove('active');b.setAttribute('aria-pressed','false');});
      btn.classList.add('active');btn.setAttribute('aria-pressed','true');
      const f=btn.dataset.filter;
      svcCards.forEach(c=>c.classList.toggle('hidden',f!=='all'&&c.dataset.cat!==f));
    });
    btn.setAttribute('aria-pressed',btn.classList.contains('active')?'true':'false');
  });

  /* FAQ accordion */
  document.querySelectorAll('.phm-faq-item').forEach(item=>{
    const btn=item.querySelector('.phm-faq-question');
    btn.addEventListener('click',()=>{
      const open=item.classList.toggle('open');
      btn.setAttribute('aria-expanded',open?'true':'false');
    });
    btn.setAttribute('aria-expanded','false');
  });

  /* form */
  const form=document.querySelector('.phm-form');
  if(form){
    form.addEventListener('submit',function(e){
      e.preventDefault();
      document.getElementById('phm-submit-btn').style.display='none';
      document.getElementById('phm-success').style.display='block';
    });
  }
})();
</script>
</div><!-- .phm-page -->
<?php get_footer(); ?>
