<?php
/**
 * Template Name: Photographer – Photography Studio & Portfolio
 *
 * Premium photography studio page template for ThemeFlex.
 * Maison Lumière Photography, Fitzrovia London Est. 2003
 *
 * @package ThemeFlex
 */

defined('ABSPATH') || exit;

srand(crc32(get_the_permalink()));

$ph_portraits  = ['Editorial', 'Portrait', 'Fashion', 'Commercial', 'Wedding', 'Architecture'];
$ph_gear_count = 8;
$ph_bulb_count = 6;

// PHP-generated portfolio items
$ph_portfolio = [
  ['cat'=>'Editorial',    'title'=>'Vogue Italia — Spring Issue',      'ratio'=>'3/4'],
  ['cat'=>'Commercial',   'title'=>'Burberry Campaign 2025',           'ratio'=>'4/3'],
  ['cat'=>'Portrait',     'title'=>'The Artist Series — Vol. III',     'ratio'=>'1/1'],
  ['cat'=>'Wedding',      'title'=>'Rosalind & Edward, Blenheim',     'ratio'=>'3/4'],
  ['cat'=>'Fashion',      'title'=>'Selfridges — Resort Collection',   'ratio'=>'4/3'],
  ['cat'=>'Architecture', 'title'=>'The Barbican — Light Study',       'ratio'=>'1/1'],
];

// PHP-generated studio lighting rigs
$ph_lights = [];
for ($i = 0; $i < $ph_bulb_count; $i++) {
    $ph_lights[] = [
        'left'   => 8 + ($i * 15) + rand(-3, 3),
        'height' => 120 + rand(0, 60),
        'size'   => 18 + rand(-4, 4),
        'warm'   => ($i % 2 === 0),
    ];
}

// Softbox positions
$ph_softboxes = [
    ['left'=>12,  'top'=>22, 'w'=>110, 'h'=>80,  'angle'=>-15],
    ['left'=>68,  'top'=>18, 'w'=>90,  'h'=>70,  'angle'=>12],
    ['left'=>38,  'top'=>8,  'w'=>130, 'h'=>55,  'angle'=>0],
];

// Backdrop roll colours
$ph_backdrops = [
    ['hue'=>0,   'sat'=>0,   'lit'=>8,  'label'=>'Obsidian'],
    ['hue'=>220, 'sat'=>15,  'lit'=>22, 'label'=>'Slate'],
    ['hue'=>200, 'sat'=>20,  'lit'=>55, 'label'=>'Mist'],
    ['hue'=>30,  'sat'=>25,  'lit'=>72, 'label'=>'Parchment'],
    ['hue'=>340, 'sat'=>18,  'lit'=>68, 'label'=>'Blush'],
    ['hue'=>0,   'sat'=>0,   'lit'=>95, 'label'=>'Ivory'],
];

// Gear shelf items
$ph_gear = [
    ['w'=>28, 'h'=>42, 'type'=>'lens',   'label'=>'85mm f/1.2'],
    ['w'=>22, 'h'=>38, 'type'=>'lens',   'label'=>'50mm f/1.4'],
    ['w'=>32, 'h'=>48, 'type'=>'body',   'label'=>'Phase One'],
    ['w'=>18, 'h'=>32, 'type'=>'flash',  'label'=>'Profoto B10'],
    ['w'=>26, 'h'=>44, 'type'=>'lens',   'label'=>'135mm f/2'],
    ['w'=>20, 'h'=>36, 'type'=>'filter', 'label'=>'ND System'],
    ['w'=>30, 'h'=>46, 'type'=>'body',   'label'=>'Canon R5'],
    ['w'=>16, 'h'=>28, 'type'=>'remote', 'label'=>'Air Remote'],
];

?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400;1,700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
/* ============================================================
   MAISON LUMIÈRE PHOTOGRAPHY — CSS DESIGN SYSTEM
   Namespace: --ph-*   |   No external image dependencies
   ============================================================ */

:root {
  --ph-ink:        #0A0908;
  --ph-charcoal:   #1C1A18;
  --ph-steel:      #3A3835;
  --ph-silver:     #8C8A87;
  --ph-mist:       #C8C5BF;
  --ph-cream:      #F4F0EB;
  --ph-paper:      #FAF8F5;
  --ph-gold:       #C4A055;
  --ph-gold-pale:  #E8D5A0;
  --ph-amber:      #D4862A;

  --ph-serif:  'Playfair Display', Georgia, serif;
  --ph-sans:   'DM Sans', system-ui, sans-serif;

  --ph-ease:   cubic-bezier(.22,.68,0,1.2);
  --ph-dur:    .45s;
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

html { scroll-behavior: smooth; }

body.ph-body {
  font-family: var(--ph-sans);
  background: var(--ph-paper);
  color: var(--ph-charcoal);
  overflow-x: hidden;
  -webkit-font-smoothing: antialiased;
}

/* ── NAV ──────────────────────────────────────────────────── */
.ph-nav {
  position: fixed; top: 0; left: 0; right: 0; z-index: 200;
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 56px;
  height: 72px;
  background: rgba(10,9,8,.85);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid rgba(196,160,85,.15);
}
.ph-nav__logo {
  display: flex; flex-direction: column; gap: 1px;
}
.ph-nav__logo-main {
  font-family: var(--ph-serif);
  font-size: 1.15rem;
  letter-spacing: .18em;
  color: var(--ph-cream);
  text-transform: uppercase;
}
.ph-nav__logo-sub {
  font-size: .62rem;
  letter-spacing: .35em;
  color: var(--ph-gold);
  text-transform: uppercase;
}
.ph-nav__links {
  display: flex; gap: 36px; list-style: none;
}
.ph-nav__links a {
  font-size: .8rem;
  letter-spacing: .12em;
  color: var(--ph-mist);
  text-decoration: none;
  text-transform: uppercase;
  transition: color var(--ph-dur);
}
.ph-nav__links a:hover { color: var(--ph-gold); }
.ph-nav__cta {
  padding: 10px 28px;
  background: transparent;
  border: 1px solid var(--ph-gold);
  color: var(--ph-gold);
  font-family: var(--ph-sans);
  font-size: .8rem;
  letter-spacing: .12em;
  text-transform: uppercase;
  cursor: pointer;
  transition: background var(--ph-dur), color var(--ph-dur);
  text-decoration: none;
}
.ph-nav__cta:hover {
  background: var(--ph-gold);
  color: var(--ph-ink);
}

/* ── HERO ─────────────────────────────────────────────────── */
.ph-hero {
  position: relative;
  width: 100%;
  height: 100vh;
  min-height: 700px;
  overflow: hidden;
  background: var(--ph-ink);
  display: flex;
  align-items: flex-end;
}

/* Studio ceiling */
.ph-studio-ceiling {
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 28%;
  background: #0C0B0A;
  border-bottom: 1px solid #1E1C1A;
}
.ph-studio-ceiling::before {
  content: '';
  position: absolute; inset: 0;
  background: repeating-linear-gradient(
    90deg,
    transparent 0, transparent 79px,
    rgba(255,255,255,.025) 79px, rgba(255,255,255,.025) 80px
  );
}
.ph-studio-ceiling::after {
  content: '';
  position: absolute; bottom: 0; left: 0; right: 0;
  height: 2px;
  background: linear-gradient(90deg, transparent, rgba(196,160,85,.3), transparent);
}

/* Track rail on ceiling */
.ph-track-rail {
  position: absolute;
  top: 26%;
  left: 5%;
  width: 90%;
  height: 6px;
  background: #2A2826;
  border-radius: 3px;
  border-top: 1px solid #3C3A38;
}
.ph-track-rail::before {
  content: '';
  position: absolute; top: 50%; left: 0; right: 0;
  height: 1px; margin-top: -0.5px;
  background: repeating-linear-gradient(
    90deg,
    rgba(196,160,85,.4) 0, rgba(196,160,85,.4) 4px,
    transparent 4px, transparent 18px
  );
}

/* Studio backdrop wall */
.ph-backdrop-wall {
  position: absolute;
  top: 0; bottom: 25%; left: 0; right: 0;
  background: linear-gradient(180deg, #0C0B0A 0%, #111009 60%, #181614 100%);
}

/* Seamless paper backdrop (active — rolled down) */
.ph-backdrop-paper {
  position: absolute;
  top: 15%; bottom: 25%;
  left: 22%; right: 22%;
  background: linear-gradient(180deg,
    hsl(220,12%,18%) 0%,
    hsl(220,10%,22%) 60%,
    hsl(220,8%,20%) 100%
  );
  border-radius: 0 0 4px 4px;
  overflow: hidden;
}
.ph-backdrop-paper::before {
  content: '';
  position: absolute; top: 0; left: 0; right: 0;
  height: 8px;
  background: linear-gradient(90deg,
    hsl(220,12%,14%) 0%,
    hsl(220,10%,20%) 50%,
    hsl(220,12%,14%) 100%
  );
  border-radius: 0;
}
.ph-backdrop-paper::after {
  content: '';
  position: absolute; inset: 0;
  background: radial-gradient(
    ellipse 70% 90% at 50% 40%,
    rgba(196,160,85,.06) 0%,
    transparent 70%
  );
}

/* Backdrop rolls on wall left side */
.ph-backdrop-rolls {
  position: absolute;
  top: 2%; right: 2%;
  width: 52px;
  display: flex; flex-direction: column; gap: 6px;
  padding: 12px 8px;
  background: rgba(0,0,0,.4);
  border: 1px solid rgba(255,255,255,.06);
}

.ph-roll {
  width: 36px; height: 24px;
  border-radius: 2px;
  position: relative;
  cursor: pointer;
}
.ph-roll::before {
  content: '';
  position: absolute; top: 3px; bottom: 3px; left: 3px; right: 3px;
  border-radius: 1px;
  background: rgba(255,255,255,.1);
}
.ph-roll__label {
  position: absolute; bottom: -14px; left: 0; right: 0;
  font-size: .42rem;
  letter-spacing: .06em;
  color: var(--ph-silver);
  text-align: center;
  text-transform: uppercase;
  white-space: nowrap;
}

/* Studio floor */
.ph-studio-floor {
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 26%;
  background: linear-gradient(180deg, #1A1815 0%, #141210 100%);
  border-top: 1px solid #2A2826;
}
.ph-studio-floor::before {
  content: '';
  position: absolute; inset: 0;
  background: repeating-linear-gradient(
    90deg,
    transparent 0, transparent 119px,
    rgba(255,255,255,.018) 119px, rgba(255,255,255,.018) 120px
  ),
  repeating-linear-gradient(
    180deg,
    transparent 0, transparent 59px,
    rgba(255,255,255,.018) 59px, rgba(255,255,255,.018) 60px
  );
}
.ph-studio-floor::after {
  content: '';
  position: absolute; top: 0; left: 0; right: 0;
  height: 80px;
  background: linear-gradient(180deg, rgba(0,0,0,.6) 0%, transparent 100%);
}

/* Backdrop sweep onto floor */
.ph-floor-sweep {
  position: absolute;
  bottom: 26%; left: 22%; right: 22%;
  height: 60px;
  background: linear-gradient(180deg,
    hsl(220,8%,20%) 0%,
    hsl(220,6%,16%) 60%,
    hsl(220,4%,12%) 100%
  );
  clip-path: ellipse(55% 100% at 50% 0%);
}

/* ── LIGHTING RIGS ────────────────────────────────────────── */
.ph-light-rig {
  position: absolute;
  top: 26%;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.ph-light-rig__stand {
  width: 3px;
  background: linear-gradient(180deg, #3A3835 0%, #2A2826 100%);
  border-radius: 1.5px;
}
.ph-light-rig__head {
  position: relative;
  border-radius: 50%;
  background: radial-gradient(circle at 40% 35%,
    #FFF8E0 0%, #F0C850 30%, #C48A10 65%, #8A5A08 100%
  );
  box-shadow: 0 0 20px rgba(240,200,80,.5), 0 0 60px rgba(240,200,80,.2);
}
.ph-light-rig__cone {
  position: absolute;
  top: 100%;
  left: 50%;
  transform: translateX(-50%);
  width: 0; height: 0;
  border-left: solid transparent;
  border-right: solid transparent;
  border-top: solid;
  opacity: .06;
  pointer-events: none;
}

/* ── SOFTBOXES ────────────────────────────────────────────── */
.ph-softbox {
  position: absolute;
  background: linear-gradient(180deg,
    rgba(240,220,160,.15) 0%,
    rgba(240,220,160,.05) 100%
  );
  border: 1px solid rgba(240,220,160,.2);
  border-radius: 2px;
  transform-origin: top center;
}
.ph-softbox::before {
  content: '';
  position: absolute; inset: 4px;
  background: rgba(255,248,220,.08);
  border-radius: 1px;
}
.ph-softbox__arm {
  position: absolute; top: -30px; left: 50%;
  transform: translateX(-50%);
  width: 2px; height: 30px;
  background: #3A3835;
}

/* ── CAMERA ON TRIPOD ─────────────────────────────────────── */
.ph-tripod {
  position: absolute;
  bottom: 26%;
  left: 14%;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.ph-camera {
  position: relative;
  width: 72px; height: 50px;
  background: linear-gradient(180deg, #2A2826 0%, #1C1A18 100%);
  border: 1px solid #3A3835;
  border-radius: 3px;
}
.ph-camera::before { /* lens barrel */
  content: '';
  position: absolute;
  top: 50%; left: -18px;
  transform: translateY(-50%);
  width: 18px; height: 28px;
  background: linear-gradient(90deg, #111 0%, #2A2826 50%, #1A1816 100%);
  border-radius: 2px 0 0 2px;
  border: 1px solid #3A3835;
}
.ph-camera::after { /* viewfinder hump */
  content: '';
  position: absolute;
  top: -10px; left: 14px;
  width: 28px; height: 12px;
  background: linear-gradient(180deg, #2A2826 0%, #222020 100%);
  border-radius: 2px 2px 0 0;
  border: 1px solid #3A3835;
  border-bottom: none;
}
.ph-camera__screen {
  position: absolute;
  top: 6px; right: 6px; bottom: 6px;
  width: 32px;
  background: linear-gradient(135deg, #0A0F14 0%, #0E1520 100%);
  border: 1px solid #4A4846;
  border-radius: 1px;
  overflow: hidden;
}
.ph-camera__screen::before {
  content: '';
  position: absolute; inset: 0;
  background: radial-gradient(
    ellipse 60% 60% at 40% 40%,
    rgba(100,130,160,.15) 0%,
    transparent 100%
  );
}
.ph-tripod__neck {
  width: 4px; height: 50px;
  background: linear-gradient(180deg, #3A3835 0%, #2A2826 100%);
}
.ph-tripod__spread {
  position: relative;
  width: 80px; height: 20px;
}
.ph-tripod__leg {
  position: absolute;
  bottom: 0;
  height: 2px;
  background: #3A3835;
  transform-origin: right center;
  border-radius: 1px;
}

/* ── HERO LIGHT SPILL ─────────────────────────────────────── */
.ph-key-spill {
  position: absolute;
  top: 10%; left: 10%; right: 10%;
  height: 70%;
  background: radial-gradient(
    ellipse 60% 80% at 50% 30%,
    rgba(196,160,85,.08) 0%,
    transparent 70%
  );
  pointer-events: none;
}

/* ── HERO TEXT ────────────────────────────────────────────── */
.ph-hero__content {
  position: relative; z-index: 10;
  padding: 0 7% 80px;
  max-width: 620px;
}
.ph-hero__eyebrow {
  display: flex; align-items: center; gap: 16px;
  margin-bottom: 20px;
}
.ph-hero__eyebrow-line {
  width: 40px; height: 1px;
  background: var(--ph-gold);
}
.ph-hero__eyebrow-text {
  font-size: .7rem;
  letter-spacing: .35em;
  color: var(--ph-gold);
  text-transform: uppercase;
}
.ph-hero__title {
  font-family: var(--ph-serif);
  font-size: clamp(2.6rem, 5vw, 4.5rem);
  font-weight: 400;
  line-height: 1.1;
  color: var(--ph-cream);
  margin-bottom: 22px;
}
.ph-hero__title em {
  font-style: italic;
  color: var(--ph-gold-pale);
}
.ph-hero__tagline {
  font-size: 1.05rem;
  font-weight: 300;
  color: var(--ph-mist);
  line-height: 1.65;
  margin-bottom: 38px;
  max-width: 440px;
}
.ph-hero__actions {
  display: flex; gap: 16px; align-items: center;
}
.ph-btn {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 14px 36px;
  font-family: var(--ph-sans);
  font-size: .82rem;
  letter-spacing: .12em;
  text-transform: uppercase;
  text-decoration: none;
  cursor: pointer;
  border: none;
  transition: all var(--ph-dur);
}
.ph-btn--gold {
  background: var(--ph-gold);
  color: var(--ph-ink);
}
.ph-btn--gold:hover { background: var(--ph-gold-pale); }
.ph-btn--outline {
  background: transparent;
  border: 1px solid rgba(196,160,85,.5);
  color: var(--ph-gold-pale);
}
.ph-btn--outline:hover {
  border-color: var(--ph-gold);
  color: var(--ph-gold);
}

/* Booking card */
.ph-booking-card {
  position: absolute;
  bottom: 48px; right: 5%;
  z-index: 10;
  width: 220px;
  background: rgba(16,14,12,.9);
  border: 1px solid rgba(196,160,85,.2);
  padding: 20px 22px;
  backdrop-filter: blur(8px);
}
.ph-booking-card__title {
  font-size: .65rem;
  letter-spacing: .25em;
  color: var(--ph-gold);
  text-transform: uppercase;
  margin-bottom: 14px;
}
.ph-booking-card__row {
  display: flex; justify-content: space-between; align-items: baseline;
  margin-bottom: 6px;
  font-size: .78rem;
}
.ph-booking-card__day { color: var(--ph-mist); font-weight: 300; }
.ph-booking-card__time { color: var(--ph-cream); font-weight: 400; }
.ph-booking-card__sep {
  height: 1px;
  background: rgba(196,160,85,.15);
  margin: 12px 0;
}
.ph-booking-card__avail {
  display: flex; align-items: center; gap: 8px;
  font-size: .72rem; color: var(--ph-silver);
}
.ph-booking-card__dot {
  width: 6px; height: 6px; border-radius: 50%;
  background: #4CAF50; flex-shrink: 0;
}

/* ── STATS STRIP ──────────────────────────────────────────── */
.ph-stats {
  background: var(--ph-ink);
  border-top: 1px solid rgba(196,160,85,.15);
  border-bottom: 1px solid rgba(196,160,85,.15);
  padding: 0;
  display: grid;
  grid-template-columns: repeat(4,1fr);
}
.ph-stat {
  padding: 32px 20px;
  text-align: center;
  border-right: 1px solid rgba(196,160,85,.1);
}
.ph-stat:last-child { border-right: none; }
.ph-stat__val {
  font-family: var(--ph-serif);
  font-size: 2.4rem;
  font-weight: 400;
  color: var(--ph-gold);
  line-height: 1;
  margin-bottom: 6px;
}
.ph-stat__lbl {
  font-size: .68rem;
  letter-spacing: .18em;
  color: var(--ph-silver);
  text-transform: uppercase;
}

/* ── SECTION UTILS ────────────────────────────────────────── */
.ph-section {
  padding: 100px 7%;
}
.ph-section--dark {
  background: var(--ph-charcoal);
  color: var(--ph-cream);
}
.ph-section--ink {
  background: var(--ph-ink);
  color: var(--ph-cream);
}
.ph-section--paper {
  background: var(--ph-paper);
}
.ph-section-label {
  display: flex; align-items: center; gap: 16px;
  margin-bottom: 18px;
}
.ph-section-label__line {
  width: 32px; height: 1px;
  background: var(--ph-gold);
}
.ph-section-label__text {
  font-size: .68rem;
  letter-spacing: .3em;
  color: var(--ph-gold);
  text-transform: uppercase;
}
.ph-h2 {
  font-family: var(--ph-serif);
  font-size: clamp(2rem, 3.5vw, 3rem);
  font-weight: 400;
  line-height: 1.2;
  margin-bottom: 18px;
}
.ph-h2 em { font-style: italic; }
.ph-lead {
  font-size: 1.05rem;
  font-weight: 300;
  line-height: 1.7;
  color: var(--ph-steel);
  max-width: 560px;
}
.ph-section--dark .ph-lead,
.ph-section--ink .ph-lead { color: var(--ph-mist); }

/* ── PORTFOLIO GRID ───────────────────────────────────────── */
.ph-portfolio {
  padding: 100px 7%;
  background: var(--ph-ink);
}
.ph-portfolio__head {
  display: flex; align-items: flex-end; justify-content: space-between;
  margin-bottom: 48px;
  flex-wrap: wrap; gap: 24px;
}
.ph-portfolio__filters {
  display: flex; gap: 0; flex-wrap: wrap;
}
.ph-filter-btn {
  padding: 8px 20px;
  font-family: var(--ph-sans);
  font-size: .72rem;
  letter-spacing: .12em;
  text-transform: uppercase;
  background: transparent;
  border: 1px solid rgba(196,160,85,.2);
  border-left: none;
  color: var(--ph-silver);
  cursor: pointer;
  transition: all .3s;
}
.ph-filter-btn:first-child { border-left: 1px solid rgba(196,160,85,.2); }
.ph-filter-btn.active,
.ph-filter-btn:hover {
  background: var(--ph-gold);
  border-color: var(--ph-gold);
  color: var(--ph-ink);
}
.ph-portfolio__grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 3px;
}
.ph-portfolio__item {
  position: relative;
  overflow: hidden;
  cursor: pointer;
}
.ph-portfolio__thumb {
  width: 100%;
  display: block;
  background: var(--ph-charcoal);
  position: relative;
  overflow: hidden;
}
.ph-portfolio__thumb::before {
  content: '';
  display: block;
}
/* ratio classes */
.ph-ratio-3-4::before  { padding-top: 133.33%; }
.ph-ratio-4-3::before  { padding-top: 75%; }
.ph-ratio-1-1::before  { padding-top: 100%; }

/* Simulated photo content with CSS gradient scenes */
.ph-photo-scene {
  position: absolute; inset: 0;
}
.ph-photo-scene--editorial {
  background: linear-gradient(135deg,
    #0A0908 0%, #1A1614 30%, #2A1E16 60%, #3A2820 100%
  );
}
.ph-photo-scene--editorial::before {
  content: '';
  position: absolute; inset: 0;
  background: radial-gradient(ellipse 50% 80% at 50% 30%,
    rgba(196,160,85,.15) 0%, transparent 70%
  );
}
.ph-photo-scene--commercial {
  background: linear-gradient(160deg,
    #F0EBE3 0%, #D8D0C4 40%, #C0B8AC 100%
  );
}
.ph-photo-scene--commercial::before {
  content: '';
  position: absolute;
  bottom: 0; left: 0; right: 0; height: 40%;
  background: linear-gradient(180deg, transparent, rgba(0,0,0,.4));
}
.ph-photo-scene--portrait {
  background: radial-gradient(ellipse 70% 70% at 50% 35%,
    #C8B49A 0%, #8C7A6A 40%, #3A2A20 100%
  );
}
.ph-photo-scene--wedding {
  background: linear-gradient(180deg,
    #E8E0D8 0%, #D0C8C0 50%, #B8B0A8 100%
  );
}
.ph-photo-scene--wedding::before {
  content: '';
  position: absolute; inset: 0;
  background: radial-gradient(ellipse 60% 40% at 50% 70%,
    rgba(255,248,240,.3) 0%, transparent 70%
  );
}
.ph-photo-scene--fashion {
  background: linear-gradient(160deg,
    #1A0A0A 0%, #2A1212 50%, #0A0808 100%
  );
}
.ph-photo-scene--fashion::before {
  content: '';
  position: absolute; inset: 0;
  background: radial-gradient(ellipse 40% 70% at 60% 30%,
    rgba(200,160,85,.12) 0%, transparent 60%
  );
}
.ph-photo-scene--architecture {
  background: linear-gradient(180deg,
    #E8EDEE 0%, #C8D0D4 30%, #8890A0 70%, #4A5060 100%
  );
}

/* Figure silhouettes in photos */
.ph-fig-silhouette {
  position: absolute;
  bottom: 15%;
  left: 50%;
  transform: translateX(-50%);
  width: 18%;
  background: rgba(0,0,0,.7);
}

.ph-portfolio__overlay {
  position: absolute; inset: 0;
  background: rgba(10,9,8,.75);
  display: flex; flex-direction: column;
  align-items: center; justify-content: center;
  opacity: 0;
  transition: opacity .35s;
  padding: 24px;
  text-align: center;
}
.ph-portfolio__item:hover .ph-portfolio__overlay { opacity: 1; }
.ph-portfolio__cat {
  font-size: .62rem;
  letter-spacing: .25em;
  color: var(--ph-gold);
  text-transform: uppercase;
  margin-bottom: 10px;
}
.ph-portfolio__title {
  font-family: var(--ph-serif);
  font-size: 1.1rem;
  font-style: italic;
  color: var(--ph-cream);
  line-height: 1.3;
}

/* ── ABOUT SPLIT ──────────────────────────────────────────── */
.ph-about {
  display: grid;
  grid-template-columns: 1fr 1fr;
  min-height: 580px;
}
.ph-about__visual {
  background: var(--ph-charcoal);
  position: relative;
  overflow: hidden;
  min-height: 520px;
}
.ph-about__text {
  padding: 80px 60px;
  background: var(--ph-paper);
  display: flex; flex-direction: column; justify-content: center;
}

/* CSS camera gear shelf in about visual */
.ph-gear-scene {
  position: absolute; inset: 0;
  display: flex; flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 0;
}
.ph-gear-shelf {
  width: 90%;
  height: 8px;
  background: linear-gradient(180deg, #3A3835 0%, #2A2826 100%);
  border-radius: 1px;
  position: relative;
}
.ph-gear-shelf::before {
  content: '';
  position: absolute; top: 0; left: 0; right: 0; height: 2px;
  background: rgba(255,255,255,.06);
}
.ph-gear-shelf__back {
  position: absolute; top: 8px; left: 0; right: 0; bottom: -200px;
  background: linear-gradient(180deg, #1C1A18 0%, #141210 100%);
}
.ph-gear-items {
  position: relative;
  width: 90%;
  height: 180px;
  display: flex; align-items: flex-end; gap: 8px;
}
.ph-gear-item {
  position: relative;
  background: linear-gradient(180deg, #2A2826 0%, #1C1A18 100%);
  border: 1px solid #3A3835;
  border-radius: 2px;
  flex-shrink: 0;
}
.ph-gear-item--lens::before {
  content: '';
  position: absolute; top: 8px; left: 50%; transform: translateX(-50%);
  width: 60%; height: 60%;
  background: radial-gradient(circle at 35% 35%,
    #4A4846 0%, #2A2826 50%, #111 100%
  );
  border-radius: 50%;
  border: 1px solid #4A4846;
}
.ph-gear-item--body::before {
  content: '';
  position: absolute; top: 6px; right: 6px; bottom: 10px; left: 6px;
  background: linear-gradient(135deg, #1A1816 0%, #0E0D0C 100%);
  border: 1px solid #3A3835;
  border-radius: 1px;
}
.ph-gear-item__label {
  position: absolute; bottom: -18px; left: 0; right: 0;
  font-size: .46rem;
  letter-spacing: .06em;
  color: var(--ph-silver);
  text-align: center;
  text-transform: uppercase;
  white-space: nowrap;
}

.ph-about__scene-caption {
  position: absolute; bottom: 24px; left: 0; right: 0;
  text-align: center;
  font-size: .65rem;
  letter-spacing: .2em;
  color: var(--ph-silver);
  text-transform: uppercase;
}

.ph-about__points {
  list-style: none;
  margin-top: 28px;
  display: flex; flex-direction: column; gap: 14px;
}
.ph-about__point {
  display: flex; gap: 14px; align-items: flex-start;
}
.ph-about__point-icon {
  width: 18px; height: 18px; flex-shrink: 0;
  margin-top: 2px;
  background: var(--ph-gold);
  display: flex; align-items: center; justify-content: center;
  font-size: .65rem; color: var(--ph-ink);
}
.ph-about__point-text {
  font-size: .9rem;
  line-height: 1.6;
  color: var(--ph-steel);
}

/* ── SERVICES GRID ────────────────────────────────────────── */
.ph-services__grid {
  display: grid;
  grid-template-columns: repeat(3,1fr);
  gap: 2px;
  margin-top: 56px;
}
.ph-service-card {
  background: #1C1A18;
  padding: 44px 36px;
  position: relative;
  overflow: hidden;
  transition: background .35s;
}
.ph-service-card:hover { background: #221E1C; }
.ph-service-card::before {
  content: '';
  position: absolute; top: 0; left: 0; right: 0;
  height: 2px;
  background: var(--ph-gold);
  transform: scaleX(0);
  transform-origin: left;
  transition: transform .45s var(--ph-ease);
}
.ph-service-card:hover::before { transform: scaleX(1); }
.ph-service-card__icon {
  width: 48px; height: 48px;
  border: 1px solid rgba(196,160,85,.3);
  display: flex; align-items: center; justify-content: center;
  margin-bottom: 24px;
  font-size: 1.3rem;
}
.ph-service-card__title {
  font-family: var(--ph-serif);
  font-size: 1.3rem;
  font-weight: 400;
  color: var(--ph-cream);
  margin-bottom: 12px;
}
.ph-service-card__text {
  font-size: .88rem;
  line-height: 1.7;
  color: var(--ph-silver);
  margin-bottom: 20px;
}
.ph-service-card__from {
  font-size: .75rem;
  letter-spacing: .1em;
  color: var(--ph-gold);
  text-transform: uppercase;
}

/* ── PHOTOGRAPHERS (TEAM) ─────────────────────────────────── */
.ph-team__grid {
  display: grid;
  grid-template-columns: repeat(4,1fr);
  gap: 32px;
  margin-top: 56px;
}
.ph-team-card {
  position: relative;
}
.ph-team-card__avatar {
  width: 100%;
  aspect-ratio: 3/4;
  position: relative;
  overflow: hidden;
  margin-bottom: 18px;
  background: var(--ph-charcoal);
}

/* CSS photographer figure portraits */
.ph-portrait-scene {
  position: absolute; inset: 0;
}
.ph-portrait--1 {
  background: linear-gradient(180deg, #1A1614 0%, #2A2018 100%);
}
.ph-portrait--2 {
  background: linear-gradient(180deg, #1A1A1A 0%, #2A2626 100%);
}
.ph-portrait--3 {
  background: linear-gradient(180deg, #141820 0%, #1E2430 100%);
}
.ph-portrait--4 {
  background: linear-gradient(180deg, #1A1614 0%, #261E18 100%);
}

/* Shared figure in portrait cards */
.ph-fig {
  position: absolute;
  bottom: 0; left: 50%; transform: translateX(-50%);
  width: 60%;
}
.ph-fig__head {
  width: 52px; height: 52px;
  border-radius: 50%;
  margin: 0 auto 0;
  position: relative;
}
.ph-fig__neck {
  width: 18px; height: 16px;
  margin: 0 auto;
  position: relative;
}
.ph-fig__body {
  width: 90px; height: 110px;
  border-radius: 6px 6px 0 0;
  margin: 0 auto;
  position: relative;
}
.ph-fig__camera {
  position: absolute;
  top: 20px; left: 50%; transform: translateX(-50%);
  width: 44px; height: 30px;
  background: linear-gradient(180deg, #2A2826 0%, #1C1A18 100%);
  border: 1px solid #3A3835;
  border-radius: 2px;
}
.ph-fig__camera::before { /* lens */
  content: '';
  position: absolute;
  top: 50%; left: -12px;
  transform: translateY(-50%);
  width: 12px; height: 18px;
  background: linear-gradient(90deg, #111 0%, #2A2826 100%);
  border-radius: 1px 0 0 1px;
  border: 1px solid #3A3835;
}
/* Per-photographer colour variants */
.ph-fig--1 .ph-fig__head { background: radial-gradient(circle at 40% 35%, #C8A080 0%, #9A7060 50%, #6A4A38 100%); }
.ph-fig--1 .ph-fig__neck { background: #9A7060; }
.ph-fig--1 .ph-fig__body { background: linear-gradient(180deg, #1A1814 0%, #0E0C0A 100%); }
.ph-fig--1 .ph-fig__head::before { /* hair */
  content: '';
  position: absolute; top: -4px; left: 0; right: 0;
  height: 28px;
  background: #1A1008;
  border-radius: 26px 26px 0 0;
  clip-path: polygon(0 60%, 10% 20%, 50% 0%, 90% 20%, 100% 60%, 100% 100%, 0 100%);
}
.ph-fig--2 .ph-fig__head { background: radial-gradient(circle at 40% 35%, #D4B090 0%, #B09070 50%, #806050 100%); }
.ph-fig--2 .ph-fig__neck { background: #B09070; }
.ph-fig--2 .ph-fig__body { background: linear-gradient(180deg, #2A1818 0%, #1A0E0E 100%); }
.ph-fig--2 .ph-fig__head::before {
  content: '';
  position: absolute; top: -6px; left: -4px; right: 4px;
  height: 26px;
  background: #3A2010;
  border-radius: 20px 20px 0 0;
  clip-path: polygon(0 50%, 5% 10%, 60% 0%, 100% 30%, 100% 100%, 0 100%);
}
.ph-fig--3 .ph-fig__head { background: radial-gradient(circle at 40% 35%, #E8C8A8 0%, #C8A888 50%, #9A7860 100%); }
.ph-fig--3 .ph-fig__neck { background: #C8A888; }
.ph-fig--3 .ph-fig__body { background: linear-gradient(180deg, #1E2030 0%, #141824 100%); }
.ph-fig--3 .ph-fig__head::before {
  content: '';
  position: absolute; top: -8px; left: -2px; right: -2px;
  height: 32px;
  background: #F0D890;
  border-radius: 26px 26px 0 0;
  clip-path: polygon(5% 80%, 5% 30%, 50% 0%, 95% 30%, 95% 80%, 85% 100%, 15% 100%);
}
.ph-fig--4 .ph-fig__head { background: radial-gradient(circle at 40% 35%, #B89070 0%, #8A6850 50%, #5A4030 100%); }
.ph-fig--4 .ph-fig__neck { background: #8A6850; }
.ph-fig--4 .ph-fig__body { background: linear-gradient(180deg, #1A1412 0%, #100C0A 100%); }
.ph-fig--4 .ph-fig__head::before {
  content: '';
  position: absolute; top: -5px; left: 2px; right: -6px;
  height: 28px;
  background: #0A0806;
  border-radius: 20px 20px 0 0;
  clip-path: polygon(0 40%, 0% 0%, 90% 0%, 100% 40%, 100% 100%, 0 100%);
}

.ph-team-card__name {
  font-family: var(--ph-serif);
  font-size: 1.15rem;
  font-style: italic;
  color: var(--ph-charcoal);
  margin-bottom: 4px;
}
.ph-team-card__role {
  font-size: .7rem;
  letter-spacing: .18em;
  color: var(--ph-gold);
  text-transform: uppercase;
  margin-bottom: 8px;
}
.ph-team-card__spec {
  font-size: .82rem;
  color: var(--ph-silver);
  line-height: 1.55;
}

/* ── PACKAGES ─────────────────────────────────────────────── */
.ph-packages__grid {
  display: grid;
  grid-template-columns: repeat(3,1fr);
  gap: 2px;
  margin-top: 56px;
}
.ph-package {
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(196,160,85,.1);
  padding: 48px 40px;
  position: relative;
  transition: border-color .35s;
}
.ph-package:hover { border-color: rgba(196,160,85,.3); }
.ph-package--featured {
  background: rgba(196,160,85,.06);
  border-color: rgba(196,160,85,.35);
}
.ph-package__badge {
  position: absolute; top: -1px; left: 50%; transform: translateX(-50%);
  background: var(--ph-gold);
  color: var(--ph-ink);
  font-size: .6rem;
  letter-spacing: .2em;
  text-transform: uppercase;
  padding: 4px 16px;
}
.ph-package__tier {
  font-size: .68rem;
  letter-spacing: .25em;
  color: var(--ph-gold);
  text-transform: uppercase;
  margin-bottom: 16px;
}
.ph-package__name {
  font-family: var(--ph-serif);
  font-size: 1.8rem;
  font-weight: 400;
  color: var(--ph-cream);
  margin-bottom: 8px;
}
.ph-package__price {
  font-size: 2.6rem;
  font-weight: 300;
  color: var(--ph-cream);
  line-height: 1;
  margin-bottom: 6px;
}
.ph-package__price sup {
  font-size: 1.2rem;
  vertical-align: super;
  color: var(--ph-gold);
}
.ph-package__per {
  font-size: .75rem;
  color: var(--ph-silver);
  margin-bottom: 28px;
}
.ph-package__sep {
  height: 1px;
  background: rgba(196,160,85,.15);
  margin-bottom: 28px;
}
.ph-package__features {
  list-style: none;
  display: flex; flex-direction: column; gap: 11px;
  margin-bottom: 36px;
}
.ph-package__feature {
  display: flex; gap: 12px; align-items: flex-start;
  font-size: .88rem; color: var(--ph-mist); line-height: 1.5;
}
.ph-package__feature::before {
  content: '✓';
  color: var(--ph-gold);
  font-size: .75rem;
  margin-top: 2px;
  flex-shrink: 0;
}

/* ── PROCESS ──────────────────────────────────────────────── */
.ph-process__steps {
  display: grid;
  grid-template-columns: repeat(4,1fr);
  gap: 0;
  margin-top: 56px;
  position: relative;
}
.ph-process__steps::before {
  content: '';
  position: absolute; top: 30px; left: 12.5%; right: 12.5%;
  height: 1px;
  background: linear-gradient(90deg, transparent, var(--ph-gold), var(--ph-gold), transparent);
  opacity: .25;
}
.ph-process-step {
  padding: 0 32px 0;
  text-align: center;
}
.ph-process-step__num {
  width: 60px; height: 60px;
  border: 1px solid rgba(196,160,85,.35);
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto 24px;
  font-family: var(--ph-serif);
  font-size: 1.2rem;
  color: var(--ph-gold);
  background: var(--ph-ink);
  position: relative; z-index: 1;
}
.ph-process-step__title {
  font-family: var(--ph-serif);
  font-size: 1.15rem;
  font-style: italic;
  color: var(--ph-cream);
  margin-bottom: 10px;
}
.ph-process-step__text {
  font-size: .85rem;
  line-height: 1.65;
  color: var(--ph-silver);
}

/* ── BOOKING FORM ─────────────────────────────────────────── */
.ph-booking {
  display: grid;
  grid-template-columns: 1fr 1fr;
  min-height: 600px;
}
.ph-booking__info {
  background: var(--ph-ink);
  padding: 80px 7%;
  display: flex; flex-direction: column; justify-content: center;
}
.ph-booking__form-wrap {
  background: var(--ph-paper);
  padding: 80px 7%;
  display: flex; flex-direction: column; justify-content: center;
}
.ph-booking__manifesto {
  font-family: var(--ph-serif);
  font-size: 1.5rem;
  font-style: italic;
  line-height: 1.5;
  color: var(--ph-cream);
  margin-top: 24px;
  padding-left: 20px;
  border-left: 2px solid var(--ph-gold);
}
.ph-booking__contact-row {
  display: flex; align-items: center; gap: 12px;
  margin-top: 18px;
  font-size: .88rem;
  color: var(--ph-mist);
}
.ph-booking__contact-label {
  font-size: .65rem;
  letter-spacing: .2em;
  color: var(--ph-gold);
  text-transform: uppercase;
  display: block;
  margin-bottom: 4px;
}
.ph-form { display: flex; flex-direction: column; gap: 18px; }
.ph-field-group {
  display: grid; grid-template-columns: 1fr 1fr; gap: 18px;
}
.ph-field {
  display: flex; flex-direction: column; gap: 6px;
}
.ph-field label {
  font-size: .68rem;
  letter-spacing: .15em;
  color: var(--ph-steel);
  text-transform: uppercase;
}
.ph-field input,
.ph-field select,
.ph-field textarea {
  background: transparent;
  border: none;
  border-bottom: 1px solid var(--ph-mist);
  padding: 10px 0;
  font-family: var(--ph-sans);
  font-size: .9rem;
  color: var(--ph-charcoal);
  outline: none;
  transition: border-color .3s;
  width: 100%;
}
.ph-field input:focus,
.ph-field select:focus,
.ph-field textarea:focus { border-bottom-color: var(--ph-gold); }
.ph-field textarea { resize: vertical; min-height: 80px; }
.ph-field select { cursor: pointer; appearance: none; }
.ph-form .ph-btn { align-self: flex-start; margin-top: 8px; }

/* ── TESTIMONIALS ─────────────────────────────────────────── */
.ph-testimonials__grid {
  display: grid;
  grid-template-columns: repeat(3,1fr);
  gap: 24px;
  margin-top: 56px;
}
.ph-testimonial {
  padding: 36px 32px;
  background: var(--ph-paper);
  border-top: 2px solid var(--ph-gold);
  position: relative;
}
.ph-testimonial__stars {
  color: var(--ph-gold);
  font-size: .9rem;
  letter-spacing: 2px;
  margin-bottom: 16px;
}
.ph-testimonial__text {
  font-family: var(--ph-serif);
  font-style: italic;
  font-size: 1rem;
  line-height: 1.7;
  color: var(--ph-charcoal);
  margin-bottom: 20px;
}
.ph-testimonial__author { font-size: .78rem; color: var(--ph-steel); }
.ph-testimonial__author strong {
  display: block;
  font-style: normal;
  font-family: var(--ph-sans);
  font-weight: 500;
  color: var(--ph-charcoal);
  margin-bottom: 2px;
}

/* ── FOOTER ───────────────────────────────────────────────── */
.ph-footer {
  background: var(--ph-ink);
  padding: 64px 7% 32px;
  border-top: 1px solid rgba(196,160,85,.15);
}
.ph-footer__top {
  display: grid;
  grid-template-columns: 1.5fr 1fr 1fr 1fr;
  gap: 48px;
  padding-bottom: 48px;
  border-bottom: 1px solid rgba(196,160,85,.1);
}
.ph-footer__brand { }
.ph-footer__brand-name {
  font-family: var(--ph-serif);
  font-size: 1.3rem;
  color: var(--ph-cream);
  margin-bottom: 4px;
  letter-spacing: .08em;
}
.ph-footer__brand-tagline {
  font-size: .65rem;
  letter-spacing: .3em;
  color: var(--ph-gold);
  text-transform: uppercase;
  margin-bottom: 18px;
}
.ph-footer__brand-text {
  font-size: .84rem;
  line-height: 1.65;
  color: var(--ph-silver);
}
.ph-footer__col-title {
  font-size: .65rem;
  letter-spacing: .25em;
  color: var(--ph-gold);
  text-transform: uppercase;
  margin-bottom: 18px;
}
.ph-footer__links {
  list-style: none;
  display: flex; flex-direction: column; gap: 9px;
}
.ph-footer__links a {
  font-size: .84rem;
  color: var(--ph-silver);
  text-decoration: none;
  transition: color .3s;
}
.ph-footer__links a:hover { color: var(--ph-cream); }
.ph-footer__bottom {
  display: flex; justify-content: space-between; align-items: center;
  padding-top: 28px;
  font-size: .75rem;
  color: var(--ph-silver);
  flex-wrap: wrap; gap: 12px;
}
.ph-footer__bottom-links {
  display: flex; gap: 24px;
}
.ph-footer__bottom-links a {
  color: var(--ph-silver); text-decoration: none;
  transition: color .3s;
}
.ph-footer__bottom-links a:hover { color: var(--ph-gold); }

/* ── ANIMATIONS ───────────────────────────────────────────── */
@keyframes ph-shutter {
  0%, 100% { opacity: 1; }
  50%       { opacity: .3; }
}
@keyframes ph-focus-pulse {
  0%, 100% { box-shadow: 0 0 8px rgba(196,160,85,.2); }
  50%       { box-shadow: 0 0 20px rgba(196,160,85,.5); }
}
@keyframes ph-float {
  0%, 100% { transform: translateY(0); }
  50%       { transform: translateY(-6px); }
}

.ph-camera { animation: ph-float 4s ease-in-out infinite; }

/* ── COUNTER ANIMATION ────────────────────────────────────── */
.ph-stat__val[data-target] { }

/* ── RESPONSIVE ───────────────────────────────────────────── */
@media (max-width: 1100px) {
  .ph-portfolio__grid { grid-template-columns: repeat(2,1fr); }
  .ph-services__grid { grid-template-columns: repeat(2,1fr); }
  .ph-team__grid { grid-template-columns: repeat(2,1fr); }
  .ph-packages__grid { grid-template-columns: 1fr; }
  .ph-process__steps { grid-template-columns: repeat(2,1fr); gap: 40px; }
  .ph-footer__top { grid-template-columns: 1fr 1fr; }
}
@media (max-width: 768px) {
  .ph-nav { padding: 0 24px; }
  .ph-nav__links { display: none; }
  .ph-hero__content { padding: 0 24px 80px; }
  .ph-booking-card { display: none; }
  .ph-about { grid-template-columns: 1fr; }
  .ph-booking { grid-template-columns: 1fr; }
  .ph-testimonials__grid { grid-template-columns: 1fr; }
  .ph-portfolio__grid { grid-template-columns: 1fr; }
  .ph-team__grid { grid-template-columns: 1fr 1fr; }
  .ph-process__steps { grid-template-columns: 1fr; }
  .ph-field-group { grid-template-columns: 1fr; }
  .ph-section { padding: 64px 24px; }
  .ph-footer__top { grid-template-columns: 1fr; }
}
</style>
<?php get_header(); ?>
<div class="ph-body">
">

<!-- NAV -->
<nav class="ph-nav" role="navigation" aria-label="Main navigation">
  <div class="ph-nav__logo">
    <span class="ph-nav__logo-main">Maison Lumière</span>
    <span class="ph-nav__logo-sub">Photography — Fitzrovia, London</span>
  </div>
  <ul class="ph-nav__links">
    <li><a href="#portfolio">Portfolio</a></li>
    <li><a href="#about">Studio</a></li>
    <li><a href="#services">Services</a></li>
    <li><a href="#team">Photographers</a></li>
    <li><a href="#packages">Packages</a></li>
    <li><a href="#booking">Contact</a></li>
  </ul>
  <a href="#booking" class="ph-nav__cta">Book a Session</a>
</nav>

<!-- HERO -->
<section class="ph-hero" aria-label="Hero — Luxury Photography Studio">

  <!-- Studio structure -->
  <div class="ph-studio-ceiling" aria-hidden="true"></div>
  <div class="ph-track-rail" aria-hidden="true"></div>
  <div class="ph-backdrop-wall" aria-hidden="true"></div>

  <!-- Active seamless paper backdrop -->
  <div class="ph-backdrop-paper" aria-hidden="true"></div>
  <div class="ph-floor-sweep" aria-hidden="true"></div>

  <!-- Backdrop rolls panel -->
  <div class="ph-backdrop-rolls" aria-hidden="true" role="img" aria-label="Backdrop roll colours available">
    <?php foreach ($ph_backdrops as $roll) : ?>
    <div class="ph-roll"
         style="background: hsl(<?php echo $roll['hue']; ?>,<?php echo $roll['sat']; ?>%,<?php echo $roll['lit']; ?>%);"
         title="<?php echo esc_attr($roll['label']); ?>">
      <span class="ph-roll__label"><?php echo esc_html($roll['label']); ?></span>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Softboxes -->
  <?php foreach ($ph_softboxes as $sb) : ?>
  <div class="ph-softbox" aria-hidden="true" style="
    top: <?php echo $sb['top']; ?>%;
    left: <?php echo $sb['left']; ?>%;
    width: <?php echo $sb['w']; ?>px;
    height: <?php echo $sb['h']; ?>px;
    transform: rotate(<?php echo $sb['angle']; ?>deg);
  ">
    <div class="ph-softbox__arm"></div>
  </div>
  <?php endforeach; ?>

  <!-- Lighting rigs -->
  <?php foreach ($ph_lights as $light) : ?>
  <div class="ph-light-rig" aria-hidden="true" style="left: <?php echo $light['left']; ?>%;">
    <div class="ph-light-rig__head" style="
      width: <?php echo $light['size']; ?>px;
      height: <?php echo $light['size']; ?>px;
      background: radial-gradient(circle at 35% 35%,
        <?php echo $light['warm'] ? '#FFF8E0' : '#E8F0FF'; ?> 0%,
        <?php echo $light['warm'] ? '#F0C850' : '#C0D0F0'; ?> 30%,
        <?php echo $light['warm'] ? '#C48A10' : '#8090C0'; ?> 65%,
        <?php echo $light['warm'] ? '#8A5A08' : '#5060A0'; ?> 100%
      );
      box-shadow: 0 0 <?php echo $light['size']; ?>px <?php echo $light['warm'] ? 'rgba(240,200,80,.6)' : 'rgba(192,208,255,.5)'; ?>,
                  0 0 <?php echo $light['size'] * 3; ?>px <?php echo $light['warm'] ? 'rgba(240,200,80,.2)' : 'rgba(192,208,255,.15)'; ?>;
    "></div>
    <div class="ph-light-rig__stand" style="height: <?php echo $light['height']; ?>px;"></div>
    <div class="ph-light-rig__cone" style="
      border-left-width: <?php echo $light['size'] * 2; ?>px;
      border-right-width: <?php echo $light['size'] * 2; ?>px;
      border-top-width: <?php echo $light['height'] * 0.8; ?>px;
      border-top-color: <?php echo $light['warm'] ? 'rgba(240,200,80,1)' : 'rgba(192,208,255,1)'; ?>;
    "></div>
  </div>
  <?php endforeach; ?>

  <!-- Camera on tripod -->
  <div class="ph-tripod" aria-hidden="true" role="img" aria-label="Camera on tripod">
    <div class="ph-camera">
      <div class="ph-camera__screen"></div>
    </div>
    <div class="ph-tripod__neck"></div>
    <div class="ph-tripod__spread">
      <div class="ph-tripod__leg" style="left:50%; width:44%; transform:rotate(-40deg);"></div>
      <div class="ph-tripod__leg" style="right:50%; width:44%; transform:rotate(40deg);"></div>
      <div class="ph-tripod__leg" style="left:50%; width:38%; transform:rotate(0deg) translateY(-1px);"></div>
    </div>
  </div>

  <!-- Key light spill -->
  <div class="ph-key-spill" aria-hidden="true"></div>

  <!-- Studio floor -->
  <div class="ph-studio-floor" aria-hidden="true"></div>

  <!-- Hero text -->
  <div class="ph-hero__content">
    <div class="ph-hero__eyebrow">
      <div class="ph-hero__eyebrow-line"></div>
      <span class="ph-hero__eyebrow-text">Maison Lumière — Est. 2003</span>
    </div>
    <h1 class="ph-hero__title">
      Where <em>light</em><br>becomes<br><em>legacy</em>
    </h1>
    <p class="ph-hero__tagline">
      Award-winning photography studio in the heart of Fitzrovia.
      Editorial, portrait, commercial and wedding photography for those
      who demand the extraordinary.
    </p>
    <div class="ph-hero__actions">
      <a href="#portfolio" class="ph-btn ph-btn--gold">View Portfolio</a>
      <a href="#booking" class="ph-btn ph-btn--outline">Book a Session</a>
    </div>
  </div>

  <!-- Booking card -->
  <div class="ph-booking-card" aria-label="Studio availability">
    <div class="ph-booking-card__title">Studio Hours</div>
    <div class="ph-booking-card__row">
      <span class="ph-booking-card__day">Monday – Friday</span>
      <span class="ph-booking-card__time">8am – 8pm</span>
    </div>
    <div class="ph-booking-card__row">
      <span class="ph-booking-card__day">Saturday</span>
      <span class="ph-booking-card__time">9am – 6pm</span>
    </div>
    <div class="ph-booking-card__row">
      <span class="ph-booking-card__day">Sunday</span>
      <span class="ph-booking-card__time">By appointment</span>
    </div>
    <div class="ph-booking-card__sep"></div>
    <div class="ph-booking-card__avail">
      <div class="ph-booking-card__dot"></div>
      <span>Availability this week</span>
    </div>
  </div>

</section>

<!-- STATS -->
<div class="ph-stats" aria-label="Studio achievements">
  <div class="ph-stat">
    <div class="ph-stat__val" data-target="22" aria-label="22 years">22</div>
    <div class="ph-stat__lbl">Years in Fitzrovia</div>
  </div>
  <div class="ph-stat">
    <div class="ph-stat__val" data-target="4800" aria-label="4,800+ shoots">4,800+</div>
    <div class="ph-stat__lbl">Shoots Completed</div>
  </div>
  <div class="ph-stat">
    <div class="ph-stat__val" data-target="4.9" aria-label="4.9 stars">4.9★</div>
    <div class="ph-stat__lbl">Client Rating</div>
  </div>
  <div class="ph-stat">
    <div class="ph-stat__val" data-target="38" aria-label="38 awards">38</div>
    <div class="ph-stat__lbl">Industry Awards</div>
  </div>
</div>

<!-- PORTFOLIO -->
<section id="portfolio" class="ph-portfolio" aria-labelledby="ph-portfolio-heading">
  <div class="ph-portfolio__head">
    <div>
      <div class="ph-section-label">
        <div class="ph-section-label__line"></div>
        <span class="ph-section-label__text">Our Work</span>
      </div>
      <h2 id="ph-portfolio-heading" class="ph-h2" style="color:var(--ph-cream);">
        Selected <em>Portfolio</em>
      </h2>
    </div>
    <nav class="ph-portfolio__filters" aria-label="Portfolio filters">
      <button class="ph-filter-btn active" data-filter="all">All</button>
      <?php foreach ($ph_portraits as $cat) : ?>
      <button class="ph-filter-btn" data-filter="<?php echo esc_attr(strtolower($cat)); ?>"><?php echo esc_html($cat); ?></button>
      <?php endforeach; ?>
    </nav>
  </div>

  <div class="ph-portfolio__grid" role="list" aria-label="Portfolio gallery">
    <?php foreach ($ph_portfolio as $item) : ?>
    <?php
      $scene_class = 'ph-photo-scene--' . strtolower($item['cat']);
      $ratio_class = 'ph-ratio-' . str_replace('/', '-', $item['ratio']);
    ?>
    <div class="ph-portfolio__item"
         role="listitem"
         data-cat="<?php echo esc_attr(strtolower($item['cat'])); ?>">
      <div class="ph-portfolio__thumb <?php echo esc_attr($ratio_class); ?>">
        <div class="ph-photo-scene <?php echo esc_attr($scene_class); ?>" aria-hidden="true"></div>
      </div>
      <div class="ph-portfolio__overlay">
        <div class="ph-portfolio__cat"><?php echo esc_html($item['cat']); ?></div>
        <div class="ph-portfolio__title"><?php echo esc_html($item['title']); ?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- ABOUT -->
<section id="about" class="ph-about" aria-labelledby="ph-about-heading">
  <div class="ph-about__visual" aria-hidden="true">
    <div class="ph-gear-scene">
      <div class="ph-gear-items">
        <?php foreach ($ph_gear as $item) : ?>
        <div class="ph-gear-item ph-gear-item--<?php echo esc_attr($item['type']); ?>"
             style="width:<?php echo $item['w']; ?>px; height:<?php echo $item['h']; ?>px;"
             title="<?php echo esc_attr($item['label']); ?>">
          <span class="ph-gear-item__label"><?php echo esc_html($item['label']); ?></span>
        </div>
        <?php endforeach; ?>
      </div>
      <div class="ph-gear-shelf"></div>
    </div>
    <div class="ph-about__scene-caption">The Maison Lumière Arsenal</div>
  </div>
  <div class="ph-about__text">
    <div class="ph-section-label">
      <div class="ph-section-label__line"></div>
      <span class="ph-section-label__text">The Studio</span>
    </div>
    <h2 id="ph-about-heading" class="ph-h2">
      Crafting images<br>that <em>endure</em>
    </h2>
    <p class="ph-lead">
      Founded in 2003 on the quiet streets of Fitzrovia, Maison Lumière has spent
      two decades photographing the world's most discerning clients. From Vogue editorials
      to private family portraits, we bring the same obsessive attention to light, composition,
      and emotion to every frame.
    </p>
    <ul class="ph-about__points">
      <li class="ph-about__point">
        <div class="ph-about__point-icon" aria-hidden="true">✦</div>
        <span class="ph-about__point-text">3,000 sq ft purpose-built studio with 5.5m ceiling heights and infinity cove</span>
      </li>
      <li class="ph-about__point">
        <div class="ph-about__point-icon" aria-hidden="true">✦</div>
        <span class="ph-about__point-text">Phase One 150MP medium format, Canon R5, Profoto lighting — Phase One tethered shooting standard</span>
      </li>
      <li class="ph-about__point">
        <div class="ph-about__point-icon" aria-hidden="true">✦</div>
        <span class="ph-about__point-text">On-site retouching suite with colour-calibrated displays for same-day proofing</span>
      </li>
      <li class="ph-about__point">
        <div class="ph-about__point-icon" aria-hidden="true">✦</div>
        <span class="ph-about__point-text">Full hair & make-up preparation suite with natural and studio lighting</span>
      </li>
    </ul>
  </div>
</section>

<!-- SERVICES -->
<section id="services" class="ph-section ph-section--dark" aria-labelledby="ph-services-heading">
  <div class="ph-section-label">
    <div class="ph-section-label__line"></div>
    <span class="ph-section-label__text">Specialisms</span>
  </div>
  <h2 id="ph-services-heading" class="ph-h2">
    Our <em>Services</em>
  </h2>

  <div class="ph-services__grid" role="list">

    <article class="ph-service-card" role="listitem">
      <div class="ph-service-card__icon" aria-hidden="true">◈</div>
      <h3 class="ph-service-card__title">Editorial & Fashion</h3>
      <p class="ph-service-card__text">
        Magazine-ready editorial photography for luxury brands and publications.
        We work with art directors, stylists and creative teams to realise
        ambitious visual narratives.
      </p>
      <div class="ph-service-card__from">From £1,800 per day</div>
    </article>

    <article class="ph-service-card" role="listitem">
      <div class="ph-service-card__icon" aria-hidden="true">◉</div>
      <h3 class="ph-service-card__title">Portrait Sessions</h3>
      <p class="ph-service-card__text">
        Executive, personal brand and fine art portraiture. Each session is
        a considered collaboration — we spend time understanding who you are
        before a single frame is made.
      </p>
      <div class="ph-service-card__from">From £650 per session</div>
    </article>

    <article class="ph-service-card" role="listitem">
      <div class="ph-service-card__icon" aria-hidden="true">◎</div>
      <h3 class="ph-service-card__title">Commercial & Product</h3>
      <p class="ph-service-card__text">
        Campaign, e-commerce and product photography built for conversion.
        Our commercial work has appeared in Harrods, Liberty London and
        across global luxury brand platforms.
      </p>
      <div class="ph-service-card__from">From £1,200 per day</div>
    </article>

    <article class="ph-service-card" role="listitem">
      <div class="ph-service-card__icon" aria-hidden="true">◇</div>
      <h3 class="ph-service-card__title">Wedding & Events</h3>
      <p class="ph-service-card__text">
        Documentary and fine-art wedding photography for those who want
        something beyond the conventional. We're trusted by discerning
        couples from Blenheim to Claridge's.
      </p>
      <div class="ph-service-card__from">From £3,800 per day</div>
    </article>

    <article class="ph-service-card" role="listitem">
      <div class="ph-service-card__icon" aria-hidden="true">◈</div>
      <h3 class="ph-service-card__title">Architecture & Interiors</h3>
      <p class="ph-service-card__text">
        Architectural and interiors photography for architects, developers
        and hospitality brands. We understand natural light and how to
        show space at its most compelling.
      </p>
      <div class="ph-service-card__from">From £1,500 per half-day</div>
    </article>

    <article class="ph-service-card" role="listitem">
      <div class="ph-service-card__icon" aria-hidden="true">◑</div>
      <h3 class="ph-service-card__title">Retouching & Post</h3>
      <p class="ph-service-card__text">
        Colour grading, beauty retouching and compositing to our exacting
        standards. Available as a standalone service for images shot
        elsewhere or as part of any package.
      </p>
      <div class="ph-service-card__from">From £95 per image</div>
    </article>

  </div>
</section>

<!-- TEAM -->
<section id="team" class="ph-section ph-section--paper" aria-labelledby="ph-team-heading">
  <div class="ph-section-label">
    <div class="ph-section-label__line"></div>
    <span class="ph-section-label__text">Our Photographers</span>
  </div>
  <h2 id="ph-team-heading" class="ph-h2">
    The <em>Artists</em> Behind the Lens
  </h2>
  <p class="ph-lead">
    Four lead photographers, each with a distinct visual language — united by
    an uncompromising commitment to the image.
  </p>

  <div class="ph-team__grid" role="list">

    <article class="ph-team-card" role="listitem">
      <div class="ph-team-card__avatar" aria-label="Portrait of Isabelle Morel">
        <div class="ph-portrait-scene ph-portrait--1" aria-hidden="true">
          <div class="ph-fig ph-fig--1">
            <div class="ph-fig__head"></div>
            <div class="ph-fig__neck"></div>
            <div class="ph-fig__body">
              <div class="ph-fig__camera"></div>
            </div>
          </div>
        </div>
      </div>
      <h3 class="ph-team-card__name">Isabelle Morel</h3>
      <div class="ph-team-card__role">Founder &amp; Creative Director</div>
      <p class="ph-team-card__spec">Editorial &amp; Fashion — 22 years. Previously Art Director at Condé Nast Paris.</p>
    </article>

    <article class="ph-team-card" role="listitem">
      <div class="ph-team-card__avatar" aria-label="Portrait of Marcus Webb">
        <div class="ph-portrait-scene ph-portrait--2" aria-hidden="true">
          <div class="ph-fig ph-fig--2">
            <div class="ph-fig__head"></div>
            <div class="ph-fig__neck"></div>
            <div class="ph-fig__body">
              <div class="ph-fig__camera"></div>
            </div>
          </div>
        </div>
      </div>
      <h3 class="ph-team-card__name">Marcus Webb</h3>
      <div class="ph-team-card__role">Lead Commercial Photographer</div>
      <p class="ph-team-card__spec">Commercial &amp; Product — 16 years. Canon Europe Ambassador since 2019.</p>
    </article>

    <article class="ph-team-card" role="listitem">
      <div class="ph-team-card__avatar" aria-label="Portrait of Anya Lindqvist">
        <div class="ph-portrait-scene ph-portrait--3" aria-hidden="true">
          <div class="ph-fig ph-fig--3">
            <div class="ph-fig__head"></div>
            <div class="ph-fig__neck"></div>
            <div class="ph-fig__body">
              <div class="ph-fig__camera"></div>
            </div>
          </div>
        </div>
      </div>
      <h3 class="ph-team-card__name">Anya Lindqvist</h3>
      <div class="ph-team-card__role">Wedding & Portrait Specialist</div>
      <p class="ph-team-card__spec">Wedding &amp; Portraiture — 14 years. Junebug Weddings Best of the World 2023, 2024.</p>
    </article>

    <article class="ph-team-card" role="listitem">
      <div class="ph-team-card__avatar" aria-label="Portrait of Dayo Okafor">
        <div class="ph-portrait-scene ph-portrait--4" aria-hidden="true">
          <div class="ph-fig ph-fig--4">
            <div class="ph-fig__head"></div>
            <div class="ph-fig__neck"></div>
            <div class="ph-fig__body">
              <div class="ph-fig__camera"></div>
            </div>
          </div>
        </div>
      </div>
      <h3 class="ph-team-card__name">Dayo Okafor</h3>
      <div class="ph-team-card__role">Architecture & Interiors</div>
      <p class="ph-team-card__spec">Architecture &amp; Interiors — 11 years. RIBA Journal &amp; Wallpaper* contributor.</p>
    </article>

  </div>
</section>

<!-- PACKAGES -->
<section id="packages" class="ph-section ph-section--ink" aria-labelledby="ph-packages-heading">
  <div class="ph-section-label">
    <div class="ph-section-label__line"></div>
    <span class="ph-section-label__text">Investment</span>
  </div>
  <h2 id="ph-packages-heading" class="ph-h2">
    Portrait <em>Packages</em>
  </h2>
  <p class="ph-lead">
    Curated portrait experiences designed to suit every vision and budget.
    All packages include full consultation, studio time, and retouched high-resolution files.
  </p>

  <div class="ph-packages__grid" role="list">

    <article class="ph-package" role="listitem">
      <div class="ph-package__tier">The Essential</div>
      <div class="ph-package__name">Portrait Session</div>
      <div class="ph-package__price"><sup>£</sup>650</div>
      <div class="ph-package__per">Two-hour session · one subject</div>
      <div class="ph-package__sep"></div>
      <ul class="ph-package__features">
        <li class="ph-package__feature">2-hour studio session</li>
        <li class="ph-package__feature">Pre-session consultation call</li>
        <li class="ph-package__feature">2 backdrop options from our library</li>
        <li class="ph-package__feature">30 fully retouched digital images</li>
        <li class="ph-package__feature">Online private gallery (60 days)</li>
        <li class="ph-package__feature">Print-ready high-resolution files</li>
      </ul>
      <a href="#booking" class="ph-btn ph-btn--outline">Enquire</a>
    </article>

    <article class="ph-package ph-package--featured" role="listitem">
      <div class="ph-package__badge">Most Requested</div>
      <div class="ph-package__tier">The Signature</div>
      <div class="ph-package__name">Full Day Session</div>
      <div class="ph-package__price"><sup>£</sup>1,800</div>
      <div class="ph-package__per">Full studio day · up to 3 subjects</div>
      <div class="ph-package__sep"></div>
      <ul class="ph-package__features">
        <li class="ph-package__feature">Full day (8 hours) studio access</li>
        <li class="ph-package__feature">In-depth pre-production meeting</li>
        <li class="ph-package__feature">Unlimited backdrop changes</li>
        <li class="ph-package__feature">Hair &amp; make-up artist included</li>
        <li class="ph-package__feature">100 fully retouched digital images</li>
        <li class="ph-package__feature">Private online gallery (1 year)</li>
        <li class="ph-package__feature">Same-day proof sheet</li>
        <li class="ph-package__feature">Fine art print (20×16") included</li>
      </ul>
      <a href="#booking" class="ph-btn ph-btn--gold">Book This Package</a>
    </article>

    <article class="ph-package" role="listitem">
      <div class="ph-package__tier">The Prestige</div>
      <div class="ph-package__name">Bespoke Campaign</div>
      <div class="ph-package__price">POA</div>
      <div class="ph-package__per">Multi-day · production team included</div>
      <div class="ph-package__sep"></div>
      <ul class="ph-package__features">
        <li class="ph-package__feature">Dedicated creative director</li>
        <li class="ph-package__feature">Full production coordination</li>
        <li class="ph-package__feature">Location scouting &amp; permits</li>
        <li class="ph-package__feature">Wardrobe styling service</li>
        <li class="ph-package__feature">Unlimited retouched deliverables</li>
        <li class="ph-package__feature">Video behind-the-scenes included</li>
        <li class="ph-package__feature">Usage rights consultation</li>
        <li class="ph-package__feature">Dedicated account manager</li>
      </ul>
      <a href="#booking" class="ph-btn ph-btn--outline">Request a Proposal</a>
    </article>

  </div>
</section>

<!-- PROCESS -->
<section class="ph-section ph-section--dark" aria-labelledby="ph-process-heading">
  <div class="ph-section-label">
    <div class="ph-section-label__line"></div>
    <span class="ph-section-label__text">How It Works</span>
  </div>
  <h2 id="ph-process-heading" class="ph-h2">
    Our <em>Process</em>
  </h2>

  <div class="ph-process__steps" role="list">
    <div class="ph-process-step" role="listitem">
      <div class="ph-process-step__num" aria-hidden="true">I</div>
      <h3 class="ph-process-step__title">Consultation</h3>
      <p class="ph-process-step__text">
        We begin every project with a detailed conversation — your vision, your audience,
        your brief. In-person at the studio or over video call.
      </p>
    </div>
    <div class="ph-process-step" role="listitem">
      <div class="ph-process-step__num" aria-hidden="true">II</div>
      <h3 class="ph-process-step__title">Pre-Production</h3>
      <p class="ph-process-step__text">
        Mood boards, shot lists, styling direction and logistics are confirmed.
        You'll know exactly what to expect on shoot day.
      </p>
    </div>
    <div class="ph-process-step" role="listitem">
      <div class="ph-process-step__num" aria-hidden="true">III</div>
      <h3 class="ph-process-step__title">The Shoot</h3>
      <p class="ph-process-step__text">
        A focused, collaborative day in our Fitzrovia studio or on location.
        Tethered shooting means you see the images as we make them.
      </p>
    </div>
    <div class="ph-process-step" role="listitem">
      <div class="ph-process-step__num" aria-hidden="true">IV</div>
      <h3 class="ph-process-step__title">Delivery</h3>
      <p class="ph-process-step__text">
        Expert retouching, colour grading and delivery to your private gallery
        within five working days. Print files and usage rights included.
      </p>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="ph-section ph-section--paper" aria-labelledby="ph-testimonials-heading">
  <div class="ph-section-label">
    <div class="ph-section-label__line"></div>
    <span class="ph-section-label__text">Client Words</span>
  </div>
  <h2 id="ph-testimonials-heading" class="ph-h2">
    What Clients <em>Say</em>
  </h2>
  <div class="ph-testimonials__grid" role="list">
    <blockquote class="ph-testimonial" role="listitem">
      <div class="ph-testimonial__stars" aria-label="5 stars">★★★★★</div>
      <p class="ph-testimonial__text">
        "Working with Isabelle is unlike any photography experience I've had.
        She has an extraordinary ability to capture something deeply true about her subjects."
      </p>
      <footer class="ph-testimonial__author">
        <strong>Countess A. Pemberton</strong>Private Portrait Client
      </footer>
    </blockquote>
    <blockquote class="ph-testimonial" role="listitem">
      <div class="ph-testimonial__stars" aria-label="5 stars">★★★★★</div>
      <p class="ph-testimonial__text">
        "Maison Lumière shot our resort campaign for three consecutive seasons.
        The images have consistently outperformed every other asset in our marketing mix."
      </p>
      <footer class="ph-testimonial__author">
        <strong>James Northcott</strong>Marketing Director, Elysian Hotels Group
      </footer>
    </blockquote>
    <blockquote class="ph-testimonial" role="listitem">
      <div class="ph-testimonial__stars" aria-label="5 stars">★★★★★</div>
      <p class="ph-testimonial__text">
        "Anya photographed our wedding at Blenheim. We have been trying to find the words
        since — suffice to say these photographs are our most treasured possessions."
      </p>
      <footer class="ph-testimonial__author">
        <strong>Rosalind &amp; Edward Ashworth</strong>Wedding Clients, 2024
      </footer>
    </blockquote>
  </div>
</section>

<!-- BOOKING -->
<section id="booking" class="ph-booking" aria-labelledby="ph-booking-heading">
  <div class="ph-booking__info">
    <div class="ph-section-label">
      <div class="ph-section-label__line"></div>
      <span class="ph-section-label__text">Get in Touch</span>
    </div>
    <h2 id="ph-booking-heading" class="ph-h2">
      Begin your <em>story</em>
    </h2>
    <blockquote class="ph-booking__manifesto">
      "The best photographs are not taken — they are earned through trust,
      preparation, and an obsessive love of light."
      <cite style="display:block; margin-top:12px; font-size:.75rem; letter-spacing:.15em; font-style:normal; color:var(--ph-gold);">— ISABELLE MOREL, FOUNDER</cite>
    </blockquote>
    <div style="margin-top:32px; display:flex; flex-direction:column; gap:14px;">
      <div class="ph-booking__contact-row">
        <span>
          <span class="ph-booking__contact-label">Studio</span>
          12 Goodge Place, Fitzrovia, London W1T 4RB
        </span>
      </div>
      <div class="ph-booking__contact-row">
        <span>
          <span class="ph-booking__contact-label">Email</span>
          hello@maisonlumiere.co.uk
        </span>
      </div>
      <div class="ph-booking__contact-row">
        <span>
          <span class="ph-booking__contact-label">Phone</span>
          020 7946 0382
        </span>
      </div>
    </div>
  </div>
  <div class="ph-booking__form-wrap">
    <div class="ph-section-label">
      <div class="ph-section-label__line"></div>
      <span class="ph-section-label__text">Enquiry Form</span>
    </div>
    <h3 style="font-family:var(--ph-serif); font-size:1.6rem; font-weight:400; margin-bottom:28px; color:var(--ph-charcoal);">
      Tell us about your <em>project</em>
    </h3>
    <form class="ph-form" method="post" action="" novalidate aria-label="Booking enquiry form">
      <?php wp_nonce_field('tf_ph_booking', 'tf_ph_nonce'); ?>
      <div class="ph-field-group">
        <div class="ph-field">
          <label for="ph-first-name">First Name <span aria-hidden="true">*</span></label>
          <input type="text" id="ph-first-name" name="ph_first_name" required autocomplete="given-name">
        </div>
        <div class="ph-field">
          <label for="ph-last-name">Last Name <span aria-hidden="true">*</span></label>
          <input type="text" id="ph-last-name" name="ph_last_name" required autocomplete="family-name">
        </div>
      </div>
      <div class="ph-field-group">
        <div class="ph-field">
          <label for="ph-email">Email Address <span aria-hidden="true">*</span></label>
          <input type="email" id="ph-email" name="ph_email" required autocomplete="email">
        </div>
        <div class="ph-field">
          <label for="ph-phone">Phone Number</label>
          <input type="tel" id="ph-phone" name="ph_phone" autocomplete="tel">
        </div>
      </div>
      <div class="ph-field">
        <label for="ph-service">Type of Photography <span aria-hidden="true">*</span></label>
        <select id="ph-service" name="ph_service" required>
          <option value="">Please select…</option>
          <option value="editorial">Editorial &amp; Fashion</option>
          <option value="portrait">Portrait Session</option>
          <option value="commercial">Commercial &amp; Product</option>
          <option value="wedding">Wedding &amp; Events</option>
          <option value="architecture">Architecture &amp; Interiors</option>
          <option value="retouching">Retouching &amp; Post</option>
        </select>
      </div>
      <div class="ph-field-group">
        <div class="ph-field">
          <label for="ph-date">Preferred Date</label>
          <input type="date" id="ph-date" name="ph_date">
        </div>
        <div class="ph-field">
          <label for="ph-budget">Approximate Budget</label>
          <select id="ph-budget" name="ph_budget">
            <option value="">Please select…</option>
            <option value="under1k">Under £1,000</option>
            <option value="1k-3k">£1,000 – £3,000</option>
            <option value="3k-8k">£3,000 – £8,000</option>
            <option value="8k-plus">£8,000+</option>
            <option value="discuss">Prefer to discuss</option>
          </select>
        </div>
      </div>
      <div class="ph-field">
        <label for="ph-message">Project Brief</label>
        <textarea id="ph-message" name="ph_message" rows="4"
                  placeholder="Tell us about your vision, deadline, and any specific requirements…"></textarea>
      </div>
      <button type="submit" class="ph-btn ph-btn--gold" aria-label="Submit booking enquiry">
        Send Enquiry
      </button>
    </form>
  </div>
</section>

<!-- FOOTER -->
<footer class="ph-footer" role="contentinfo" aria-label="Site footer">
  <div class="ph-footer__top">
    <div class="ph-footer__brand">
      <div class="ph-footer__brand-name">Maison Lumière</div>
      <div class="ph-footer__brand-tagline">Photography — Est. 2003 · Fitzrovia, London</div>
      <p class="ph-footer__brand-text">
        Award-winning photography studio serving editorial, commercial and private
        clients from our Fitzrovia studio. Light is everything.
      </p>
    </div>
    <div>
      <div class="ph-footer__col-title">Services</div>
      <ul class="ph-footer__links">
        <li><a href="#services">Editorial &amp; Fashion</a></li>
        <li><a href="#services">Portrait Sessions</a></li>
        <li><a href="#services">Commercial &amp; Product</a></li>
        <li><a href="#services">Wedding &amp; Events</a></li>
        <li><a href="#services">Architecture</a></li>
        <li><a href="#services">Retouching</a></li>
      </ul>
    </div>
    <div>
      <div class="ph-footer__col-title">Studio</div>
      <ul class="ph-footer__links">
        <li><a href="#portfolio">Portfolio</a></li>
        <li><a href="#team">Photographers</a></li>
        <li><a href="#packages">Packages</a></li>
        <li><a href="#about">About Us</a></li>
        <li><a href="#booking">Contact</a></li>
      </ul>
    </div>
    <div>
      <div class="ph-footer__col-title">Location</div>
      <p style="font-size:.84rem; color:var(--ph-silver); line-height:1.7;">
        12 Goodge Place<br>
        Fitzrovia<br>
        London W1T 4RB<br><br>
        020 7946 0382<br>
        hello@maisonlumiere.co.uk
      </p>
    </div>
  </div>
  <div class="ph-footer__bottom">
    <span>© <?php echo date('Y'); ?> Maison Lumière Photography Ltd. All rights reserved.</span>
    <div class="ph-footer__bottom-links">
      <a href="#">Privacy Policy</a>
      <a href="#">Terms of Service</a>
      <a href="#">Cookie Preferences</a>
    </div>
  </div>
</footer>

<script>
(function () {
  'use strict';

  /* ── Counter animation ─────────────────────────────────── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  const isFloat = v => !isNaN(v) && v % 1 !== 0;

  document.querySelectorAll('.ph-stat__val[data-target]').forEach(el => {
    const raw    = el.dataset.target;
    const target = parseFloat(raw);
    if (isNaN(target)) return;

    const duration = 1800;
    const start    = performance.now();
    const suffix   = el.textContent.replace(String(raw), '').trim();

    const tick = now => {
      const t   = Math.min((now - start) / duration, 1);
      const val = target * easeOut(t);
      el.textContent = (isFloat(target) ? val.toFixed(1) : Math.round(val).toLocaleString())
                       + (suffix ? suffix : '');
      if (t < 1) requestAnimationFrame(tick);
    };

    const obs = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) {
        requestAnimationFrame(tick);
        obs.disconnect();
      }
    }, { threshold: 0.5 });
    obs.observe(el);
  });

  /* ── Portfolio filter ──────────────────────────────────── */
  document.querySelectorAll('.ph-filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.ph-filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const filter = btn.dataset.filter;
      document.querySelectorAll('.ph-portfolio__item').forEach(item => {
        const show = filter === 'all' || item.dataset.cat === filter;
        item.style.display = show ? '' : 'none';
      });
    });
  });

  /* ── Nav scroll shrink ─────────────────────────────────── */
  const nav = document.querySelector('.ph-nav');
  if (nav) {
    window.addEventListener('scroll', () => {
      nav.style.background = window.scrollY > 60
        ? 'rgba(10,9,8,.97)'
        : 'rgba(10,9,8,.85)';
    }, { passive: true });
  }

  /* ── Form submission ───────────────────────────────────── */
  const form = document.querySelector('.ph-form');
  if (form) {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const btn = form.querySelector('button[type="submit"]');
      btn.textContent = 'Sending…';
      btn.disabled = true;
      setTimeout(() => {
        btn.textContent = 'Enquiry Sent — We\'ll be in touch shortly';
        btn.style.background = '#4CAF50';
        btn.style.borderColor = '#4CAF50';
      }, 1200);
    });
  }

})();
</script>

</body>
</html>
</div><!-- .ph-body -->
<?php get_footer(); ?>
