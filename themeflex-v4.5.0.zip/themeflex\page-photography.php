<?php
/**
 * Template Name: TF — Photography Studio
 * Description:   Premium commercial & portrait photography studio landing page.
 * Namespace:     --ph-*
 * Google Fonts:  Josefin Sans + Libre Baskerville
 * Palette:       Jet #0D0D0D / Silver #C0C0C8 / Cream #F5F0E8 / Amber #E8A020 / White #FFFFFF
 * Hero scene:    CSS studio with softbox lights, camera on tripod, backdrop roll, photographer figure
 */

defined('ABSPATH') || exit;
get_header();
?>

<!-- ============================================================
     PHOTOGRAPHY STUDIO — PREMIUM TEMPLATE
     ============================================================ -->
<div class="ph-wrap">

<!-- ── GOOGLE FONTS ─────────────────────────────────────────── -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,300;0,400;0,600;0,700;1,300&family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">

<style>
/* ── DESIGN TOKENS ──────────────────────────────────────────── */
:root{
  --ph-jet:#0D0D0D;
  --ph-jet-lt:#1A1A1A;
  --ph-jet-mid:#252525;
  --ph-silver:#C0C0C8;
  --ph-silver-dk:#9898A4;
  --ph-cream:#F5F0E8;
  --ph-cream-dk:#E8E2D6;
  --ph-amber:#E8A020;
  --ph-amber-lt:#F0BB55;
  --ph-amber-dk:#C07A10;
  --ph-white:#FFFFFF;
  --ph-f-sans:'Josefin Sans',sans-serif;
  --ph-f-serif:'Libre Baskerville',Georgia,serif;
  --ph-r:3px;
  --ph-r-lg:8px;
  --ph-sh:0 8px 32px rgba(0,0,0,.5);
  --ph-sh-amber:0 4px 20px rgba(232,160,32,.3)
}

/* ── BASE ───────────────────────────────────────────────────── */
.ph-wrap{font-family:var(--ph-f-sans);color:var(--ph-jet);overflow-x:hidden}
.ph-wrap *,
.ph-wrap *::before,
.ph-wrap *::after{box-sizing:border-box;margin:0;padding:0}
.ph-wrap a{color:inherit;text-decoration:none}

/* ── LAYOUT ─────────────────────────────────────────────────── */
.ph-container{max-width:1200px;margin:0 auto;padding:0 24px}
.ph-section{padding:100px 0}
.ph-section--dark{background:var(--ph-jet)}
.ph-section--jet-lt{background:var(--ph-jet-lt)}
.ph-section--jet-mid{background:var(--ph-jet-mid)}
.ph-section--cream{background:var(--ph-cream)}
.ph-section--cream-dk{background:var(--ph-cream-dk)}
.ph-section--white{background:var(--ph-white)}

/* ── TYPOGRAPHY ─────────────────────────────────────────────── */
.ph-eyebrow{
  font-family:var(--ph-f-sans);font-size:.68rem;
  letter-spacing:.3em;text-transform:uppercase;
  color:var(--ph-amber);font-weight:400;
  margin-bottom:18px
}
.ph-eyebrow--silver{color:var(--ph-silver)}
.ph-eyebrow--dark{color:var(--ph-silver-dk)}
.ph-h1{
  font-family:var(--ph-f-serif);
  font-size:clamp(2.8rem,7vw,5.5rem);
  font-weight:400;line-height:1.1;color:var(--ph-white);
  font-style:italic
}
.ph-h1 strong{font-style:normal;font-weight:700}
.ph-h2{
  font-family:var(--ph-f-serif);
  font-size:clamp(2rem,4vw,3rem);
  font-weight:700;line-height:1.2
}
.ph-h3{
  font-family:var(--ph-f-serif);
  font-size:1.3rem;font-weight:700
}
.ph-lead{font-size:1.05rem;line-height:1.8}
.ph-sub{font-size:.9rem;line-height:1.75}

/* thin decorative line */
.ph-line{
  display:block;width:40px;height:1px;background:var(--ph-amber);margin:18px 0
}
.ph-line--center{margin:18px auto}

/* ── BUTTONS ────────────────────────────────────────────────── */
.ph-btn{
  display:inline-flex;align-items:center;gap:8px;
  font-family:var(--ph-f-sans);font-size:.8rem;font-weight:600;
  letter-spacing:.15em;text-transform:uppercase;
  padding:14px 32px;border-radius:0;
  border:1px solid transparent;cursor:pointer;
  transition:all .3s;white-space:nowrap
}
.ph-btn--amber{
  background:var(--ph-amber);color:var(--ph-jet);border-color:var(--ph-amber);
  box-shadow:var(--ph-sh-amber)
}
.ph-btn--amber:hover{background:var(--ph-amber-dk);border-color:var(--ph-amber-dk);transform:translateY(-2px)}
.ph-btn--outline-white{
  background:transparent;color:var(--ph-white);border-color:rgba(255,255,255,.35)
}
.ph-btn--outline-white:hover{background:rgba(255,255,255,.08);border-color:var(--ph-white)}
.ph-btn--outline-dark{
  background:transparent;color:var(--ph-jet);border-color:var(--ph-jet)
}
.ph-btn--outline-dark:hover{background:var(--ph-jet);color:var(--ph-white)}

/* ── HERO ───────────────────────────────────────────────────── */
.ph-hero{
  min-height:100vh;position:relative;overflow:hidden;
  background:var(--ph-jet);
  display:flex;align-items:center
}

/* noise/grain texture overlay */
.ph-hero::before{
  content:'';position:absolute;inset:0;
  background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='.03'/%3E%3C/svg%3E");
  opacity:.4;pointer-events:none;z-index:1
}

/* CSS PHOTOGRAPHY STUDIO SCENE */
.ph-hero-scene{
  position:absolute;right:0;top:0;bottom:0;width:520px;z-index:2
}

/* gradient fade left */
.ph-hero-scene::before{
  content:'';position:absolute;inset:0;left:-80px;
  background:linear-gradient(to right,var(--ph-jet),transparent 60%);
  z-index:10;pointer-events:none
}

/* studio floor */
.ph-studio-floor{
  position:absolute;bottom:0;left:0;right:0;height:100px;
  background:linear-gradient(to bottom,#1a1a1a,#111);
  border-top:1px solid #2a2a2a
}

/* back wall */
.ph-studio-wall{
  position:absolute;inset:0;bottom:100px;
  background:linear-gradient(to bottom,#0f0f0f,#1c1c1c)
}

/* seamless paper backdrop roll */
.ph-backdrop{
  position:absolute;bottom:100px;left:80px;right:80px;top:30px;
  background:linear-gradient(to bottom,#f0ede6 0%,#e8e4dc 60%,#d0ccc4 100%);
  border-radius:0 0 40px 40px
}
/* backdrop roll tube at top */
.ph-backdrop::before{
  content:'';position:absolute;top:-12px;left:-20px;right:-20px;height:24px;
  background:linear-gradient(to bottom,#ccc,#eee,#ccc);border-radius:12px
}

/* softbox light left */
.ph-softbox-l{
  position:absolute;top:60px;left:20px;width:80px;z-index:5
}
.ph-softbox-l-stand{
  width:4px;height:200px;background:linear-gradient(to bottom,#555,#333);
  margin:0 auto;position:relative
}
.ph-softbox-l-stand::before{
  content:'';position:absolute;bottom:0;left:-20px;right:-20px;height:6px;
  background:#444;border-radius:3px
}
/* boom arm */
.ph-softbox-l-arm{
  position:absolute;top:40px;right:-4px;width:60px;height:3px;
  background:#555;transform-origin:right center;transform:rotate(-30deg)
}
.ph-softbox-l-head{
  position:absolute;top:20px;left:-5px;width:90px;height:70px;
  background:linear-gradient(135deg,#222,#333);border-radius:4px;
  border:2px solid #444
}
/* light glow */
.ph-softbox-l-head::before{
  content:'';position:absolute;inset:8px;
  background:radial-gradient(ellipse,rgba(255,240,200,.35) 0%,transparent 70%);
  border-radius:3px
}
/* light beam on backdrop */
.ph-softbox-l-head::after{
  content:'';position:absolute;top:100%;left:50%;transform:translateX(-50%);
  width:0;height:0;
  border-left:40px solid transparent;
  border-right:40px solid transparent;
  border-top:120px solid rgba(255,240,200,.04)
}

/* softbox light right */
.ph-softbox-r{
  position:absolute;top:40px;right:20px;width:80px;z-index:5
}
.ph-softbox-r-stand{
  width:4px;height:220px;background:linear-gradient(to bottom,#555,#333);
  margin:0 auto
}
.ph-softbox-r-head{
  position:absolute;top:30px;right:-5px;width:80px;height:60px;
  background:linear-gradient(135deg,#222,#333);border-radius:4px;border:2px solid #444
}
.ph-softbox-r-head::before{
  content:'';position:absolute;inset:8px;
  background:radial-gradient(ellipse,rgba(255,240,200,.3) 0%,transparent 70%);
  border-radius:3px
}

/* camera on tripod */
.ph-tripod{
  position:absolute;bottom:96px;left:50%;transform:translateX(-50%);
  width:120px;z-index:6
}
/* tripod legs */
.ph-tripod::before{
  content:'';position:absolute;bottom:0;left:50%;transform:translateX(-50%);
  width:100px;height:120px;
  background:
    linear-gradient(to bottom right,transparent calc(50% - 1.5px),#555 calc(50% - 1.5px),#555 calc(50% + 1.5px),transparent calc(50% + 1.5px)),
    linear-gradient(to bottom,transparent calc(50% - 1.5px),#555 calc(50% - 1.5px),#555 calc(50% + 1.5px),transparent calc(50% + 1.5px)),
    linear-gradient(to bottom left,transparent calc(50% - 1.5px),#555 calc(50% - 1.5px),#555 calc(50% + 1.5px),transparent calc(50% + 1.5px))
}
/* camera body */
.ph-camera-body{
  position:relative;z-index:7;margin:0 auto 0;
  width:70px;height:50px;
  background:linear-gradient(to bottom,#222,#1a1a1a);
  border-radius:4px;border:1px solid #444
}
/* viewfinder bump */
.ph-camera-body::before{
  content:'';position:absolute;top:-12px;left:10px;
  width:22px;height:12px;background:#1a1a1a;border-radius:2px;border:1px solid #444
}
/* shutter button */
.ph-camera-body::after{
  content:'';position:absolute;top:-16px;right:14px;
  width:10px;height:10px;border-radius:50%;
  background:radial-gradient(circle,#aaa,#666)
}
/* lens */
.ph-lens{
  position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);
  width:30px;height:30px;border-radius:50%;
  background:radial-gradient(circle at 35% 35%,#3a5a7a,#0a1a2a);
  border:3px solid #555;
  box-shadow:0 0 0 2px #333
}
.ph-lens::before{
  content:'';position:absolute;top:5px;left:6px;
  width:7px;height:7px;border-radius:50%;
  background:rgba(255,255,255,.35)
}

/* photographer figure */
.ph-photographer{
  position:absolute;bottom:96px;left:calc(50% + 50px);z-index:7
}
.ph-phfig-head{
  width:32px;height:38px;border-radius:50% 50% 45% 45%;
  background:linear-gradient(to bottom,#5C3317,#8B5C30);
  position:relative;left:50%;transform:translateX(-50%)
}
/* hair */
.ph-phfig-head::before{
  content:'';position:absolute;top:-4px;left:-2px;right:-2px;height:18px;
  background:#1a1a1a;border-radius:50% 50% 0 0
}
.ph-phfig-body{
  width:40px;height:58px;margin:0 auto;
  background:linear-gradient(to bottom,#2a3a55,#1e2c42);
  border-radius:4px 4px 0 0
}
/* camera strap */
.ph-phfig-body::before{
  content:'';position:absolute;
  width:2px;height:30px;background:var(--ph-amber);
  top:42px;left:calc(50% + 6px)
}
/* eye to viewfinder arm */
.ph-phfig-arm-l{
  position:absolute;top:44px;left:-8px;
  width:12px;height:36px;border-radius:6px;
  background:#2a3a55;transform:rotate(-60deg);transform-origin:top center
}
.ph-phfig-arm-r{
  position:absolute;top:44px;right:-8px;
  width:12px;height:36px;border-radius:6px;
  background:#2a3a55;transform:rotate(20deg);transform-origin:top center
}
.ph-phfig-legs{
  width:40px;height:60px;margin:0 auto;
  background:linear-gradient(to bottom,#1a1a2a,#111);
  position:relative
}
.ph-phfig-legs::before,
.ph-phfig-legs::after{
  content:'';position:absolute;bottom:0;
  width:17px;height:10px;background:#222;border-radius:0 0 3px 3px
}
.ph-phfig-legs::before{left:2px}
.ph-phfig-legs::after{right:2px}

/* ambient light pulse */
@keyframes ph-ambient{
  0%,100%{opacity:.12}
  50%{opacity:.2}
}
.ph-ambient-glow{
  position:absolute;border-radius:50%;
  background:radial-gradient(circle,rgba(232,160,32,.3) 0%,transparent 70%);
  animation:ph-ambient 4s ease-in-out infinite;pointer-events:none
}

/* floating spec tags */
@keyframes ph-tag-drift{
  0%,100%{transform:translateY(0)}
  50%{transform:translateY(-8px)}
}
.ph-spec-tag{
  position:absolute;z-index:8;
  background:rgba(13,13,13,.88);border:1px solid rgba(232,160,32,.4);
  padding:8px 14px;
  font-family:var(--ph-f-sans);font-size:.72rem;letter-spacing:.1em;
  text-transform:uppercase;color:rgba(255,255,255,.8);
  animation:ph-tag-drift 3.5s ease-in-out infinite
}
.ph-spec-tag strong{color:var(--ph-amber);display:block;font-size:.85rem;letter-spacing:.05em}

/* hero content */
.ph-hero-content{position:relative;z-index:5;max-width:560px}
.ph-hero-sig{
  display:inline-block;margin-bottom:28px;
  font-family:var(--ph-f-serif);font-size:.85rem;font-style:italic;
  color:var(--ph-amber-lt);letter-spacing:.05em
}
.ph-hero-desc{
  font-size:1.05rem;line-height:1.85;color:rgba(255,255,255,.7);
  margin:24px 0 40px;font-weight:300
}
.ph-hero-btns{display:flex;gap:16px;flex-wrap:wrap}
.ph-hero-stats{
  display:flex;gap:40px;margin-top:52px;padding-top:44px;
  border-top:1px solid rgba(255,255,255,.08);flex-wrap:wrap
}
.ph-hero-stat-num{
  font-family:var(--ph-f-serif);font-size:2rem;font-weight:700;
  color:var(--ph-amber-lt);line-height:1
}
.ph-hero-stat-label{
  font-size:.7rem;color:rgba(255,255,255,.5);text-transform:uppercase;
  letter-spacing:.15em;margin-top:5px
}

/* ── STATS ──────────────────────────────────────────────────── */
.ph-stats-grid{
  display:grid;grid-template-columns:repeat(4,1fr);gap:1px;
  background:rgba(255,255,255,.06)
}
.ph-stat-cell{
  background:var(--ph-jet-lt);padding:48px 24px;text-align:center;
  border-bottom:2px solid transparent;transition:border-color .3s
}
.ph-stat-cell:hover{border-bottom-color:var(--ph-amber)}
.ph-stat-num{
  font-family:var(--ph-f-serif);font-size:clamp(2.2rem,5vw,3.5rem);font-weight:700;
  color:var(--ph-amber-lt);line-height:1;display:block
}
.ph-stat-label{
  font-size:.72rem;color:var(--ph-silver-dk);text-transform:uppercase;
  letter-spacing:.15em;margin-top:10px;display:block
}

/* ── PORTFOLIO GRID ─────────────────────────────────────────── */
.ph-portfolio-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  grid-auto-rows:240px;gap:4px;margin-top:56px
}
.ph-portfolio-tile{
  position:relative;overflow:hidden;cursor:pointer
}
.ph-portfolio-tile:nth-child(1){grid-column:span 2;grid-row:span 2}
.ph-portfolio-tile:nth-child(5){grid-column:span 2}
.ph-portfolio-bg{
  position:absolute;inset:0;transition:transform .6s ease
}
.ph-portfolio-tile:hover .ph-portfolio-bg{transform:scale(1.06)}
.ph-portfolio-overlay{
  position:absolute;inset:0;
  background:linear-gradient(to top,rgba(0,0,0,.75) 0%,transparent 60%);
  opacity:0;transition:opacity .35s
}
.ph-portfolio-tile:hover .ph-portfolio-overlay{opacity:1}
.ph-portfolio-info{
  position:absolute;bottom:0;left:0;right:0;padding:24px;
  transform:translateY(8px);opacity:0;
  transition:all .35s;
  font-family:var(--ph-f-sans)
}
.ph-portfolio-tile:hover .ph-portfolio-info{transform:translateY(0);opacity:1}
.ph-portfolio-cat{
  font-size:.7rem;letter-spacing:.2em;text-transform:uppercase;
  color:var(--ph-amber-lt);margin-bottom:6px
}
.ph-portfolio-title{
  font-family:var(--ph-f-serif);font-size:1.1rem;color:var(--ph-white);font-weight:700
}

/* ── SERVICES ───────────────────────────────────────────────── */
.ph-services-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:2px;background:var(--ph-cream-dk)}
.ph-service-card{
  background:var(--ph-cream);padding:44px 36px;
  border-bottom:2px solid transparent;transition:all .3s
}
.ph-service-card:hover{background:var(--ph-white);border-bottom-color:var(--ph-amber)}
.ph-service-icon{font-size:2rem;margin-bottom:20px;display:block}
.ph-service-name{
  font-family:var(--ph-f-serif);font-size:1.2rem;font-weight:700;
  color:var(--ph-jet);margin-bottom:12px
}
.ph-service-desc{font-size:.9rem;color:#555;line-height:1.7;margin-bottom:18px}
.ph-service-price{
  font-family:var(--ph-f-sans);font-size:.8rem;font-weight:600;
  letter-spacing:.1em;text-transform:uppercase;
  color:var(--ph-amber-dk)
}

/* ── PACKAGES ───────────────────────────────────────────────── */
.ph-packages-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;align-items:start}
.ph-pkg-card{border-radius:var(--ph-r-lg);overflow:hidden;transition:transform .3s,box-shadow .3s}
.ph-pkg-card:hover{transform:translateY(-6px);box-shadow:var(--ph-sh)}
.ph-pkg-card--standard{background:var(--ph-jet-lt);border:1px solid rgba(255,255,255,.08)}
.ph-pkg-card--featured{
  background:var(--ph-jet-mid);border:1px solid var(--ph-amber);
  transform:scale(1.03);box-shadow:var(--ph-sh-amber)
}
.ph-pkg-card--featured:hover{transform:scale(1.03) translateY(-6px)}
.ph-pkg-card--premium{background:var(--ph-jet-lt);border:1px solid rgba(255,255,255,.08)}
.ph-pkg-top{
  padding:32px 28px 24px;
  border-bottom:1px solid rgba(255,255,255,.07)
}
.ph-pkg-badge{
  display:inline-block;margin-bottom:14px;
  font-size:.68rem;letter-spacing:.15em;text-transform:uppercase;font-weight:600;
  padding:4px 12px;border-radius:99px;
  background:rgba(232,160,32,.12);color:var(--ph-amber)
}
.ph-pkg-card--featured .ph-pkg-badge{background:var(--ph-amber);color:var(--ph-jet)}
.ph-pkg-name{
  font-family:var(--ph-f-serif);font-size:1.6rem;font-weight:700;
  color:var(--ph-white);margin-bottom:8px
}
.ph-pkg-price{
  font-family:var(--ph-f-serif);font-size:2.8rem;font-weight:700;
  color:var(--ph-amber-lt);line-height:1
}
.ph-pkg-price sup{font-size:1.2rem;vertical-align:top;margin-top:.5rem}
.ph-pkg-period{font-size:.8rem;color:var(--ph-silver-dk);margin-top:4px}
.ph-pkg-body{padding:24px 28px}
.ph-pkg-feature{
  display:flex;align-items:flex-start;gap:10px;
  padding:8px 0;border-bottom:1px solid rgba(255,255,255,.05);
  font-size:.9rem;color:rgba(255,255,255,.75)
}
.ph-pkg-feature:last-child{border-bottom:none}
.ph-pkg-check{
  color:var(--ph-amber);flex-shrink:0;margin-top:1px
}
.ph-pkg-btn{display:block;text-align:center;margin-top:20px}

/* ── PROCESS ────────────────────────────────────────────────── */
.ph-process-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:40px;position:relative}
.ph-process-grid::before{
  content:'';position:absolute;top:36px;left:calc(12.5% + 18px);right:calc(12.5% + 18px);
  height:1px;background:linear-gradient(to right,var(--ph-amber),rgba(232,160,32,.1));
  z-index:0
}
.ph-process-step{text-align:center;position:relative;z-index:1}
.ph-process-icon{
  width:72px;height:72px;border-radius:50%;
  background:var(--ph-jet-mid);border:1px solid var(--ph-amber);
  display:flex;align-items:center;justify-content:center;
  font-size:1.8rem;margin:0 auto 22px;position:relative
}
.ph-process-num{
  position:absolute;top:-4px;right:-4px;width:22px;height:22px;border-radius:50%;
  background:var(--ph-amber);color:var(--ph-jet);
  font-family:var(--ph-f-sans);font-size:.72rem;font-weight:700;
  display:flex;align-items:center;justify-content:center
}
.ph-process-title{
  font-family:var(--ph-f-serif);font-size:1rem;font-weight:700;
  color:var(--ph-white);margin-bottom:10px
}
.ph-process-desc{font-size:.88rem;color:rgba(255,255,255,.55);line-height:1.65}

/* ── TESTIMONIALS ───────────────────────────────────────────── */
.ph-testi-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}
.ph-testi-card{
  background:var(--ph-white);padding:36px;
  border-left:2px solid var(--ph-amber);
  box-shadow:0 2px 16px rgba(0,0,0,.08);
  transition:transform .3s
}
.ph-testi-card:hover{transform:translateY(-4px)}
.ph-testi-stars{color:var(--ph-amber);font-size:1rem;letter-spacing:3px;margin-bottom:16px}
.ph-testi-text{
  font-family:var(--ph-f-serif);font-size:.97rem;
  line-height:1.8;color:#444;margin-bottom:24px;font-style:italic
}
.ph-testi-author{
  display:flex;align-items:center;gap:14px;
  padding-top:16px;border-top:1px solid var(--ph-cream-dk)
}
.ph-testi-avatar{
  width:44px;height:44px;border-radius:50%;
  background:var(--ph-jet);
  display:flex;align-items:center;justify-content:center;
  font-size:1.2rem;flex-shrink:0
}
.ph-testi-name{
  font-family:var(--ph-f-sans);font-size:.9rem;font-weight:700;
  text-transform:uppercase;letter-spacing:.06em;color:var(--ph-jet)
}
.ph-testi-occasion{font-size:.78rem;color:var(--ph-amber-dk);margin-top:2px}

/* ── FAQ ────────────────────────────────────────────────────── */
.ph-faq-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;max-width:960px;margin:0 auto}
.ph-faq-item{
  background:var(--ph-jet-lt);border:1px solid rgba(255,255,255,.07);overflow:hidden
}
.ph-faq-q{
  width:100%;background:none;border:none;cursor:pointer;
  display:flex;align-items:center;justify-content:space-between;gap:16px;
  padding:22px 24px;text-align:left;
  font-family:var(--ph-f-sans);font-size:.88rem;font-weight:600;
  letter-spacing:.04em;text-transform:uppercase;
  color:var(--ph-white);transition:color .25s
}
.ph-faq-q:hover{color:var(--ph-amber-lt)}
.ph-faq-icon{
  flex-shrink:0;width:26px;height:26px;border-radius:50%;
  border:1px solid rgba(255,255,255,.2);
  display:flex;align-items:center;justify-content:center;
  font-size:1.1rem;transition:all .3s;color:var(--ph-amber)
}
.ph-faq-item.ph-open .ph-faq-icon{
  transform:rotate(45deg);background:var(--ph-amber);color:var(--ph-jet);border-color:var(--ph-amber)
}
.ph-faq-a{max-height:0;overflow:hidden;transition:max-height .4s ease}
.ph-faq-a-inner{
  padding:0 24px 22px;
  font-size:.9rem;color:rgba(255,255,255,.6);line-height:1.75;
  border-top:1px solid rgba(255,255,255,.07)
}

/* ── BOOKING ────────────────────────────────────────────────── */
.ph-booking-wrap{display:grid;grid-template-columns:1fr 1.15fr;gap:80px;align-items:start}
.ph-booking-info h2{color:var(--ph-white);margin-bottom:16px}
.ph-booking-info p{color:rgba(255,255,255,.65);line-height:1.8;margin-bottom:28px}
.ph-booking-detail{
  display:flex;align-items:center;gap:14px;
  padding:14px 0;border-bottom:1px solid rgba(255,255,255,.07)
}
.ph-booking-detail:last-child{border-bottom:none}
.ph-booking-icon{
  width:40px;height:40px;
  background:rgba(232,160,32,.1);border:1px solid rgba(232,160,32,.2);
  display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0
}
.ph-booking-label{
  font-size:.72rem;font-weight:600;letter-spacing:.12em;text-transform:uppercase;
  color:var(--ph-amber);margin-bottom:2px
}
.ph-booking-value{font-size:.9rem;color:rgba(255,255,255,.75)}

/* form */
.ph-form{background:var(--ph-jet-mid);padding:44px;border:1px solid rgba(232,160,32,.15)}
.ph-form-title{
  font-family:var(--ph-f-serif);font-size:1.7rem;font-weight:700;
  color:var(--ph-white);margin-bottom:6px
}
.ph-form-subtitle{font-size:.85rem;color:rgba(255,255,255,.45);margin-bottom:32px;letter-spacing:.05em}
.ph-form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.ph-field{margin-bottom:18px}
.ph-field label{
  display:block;margin-bottom:7px;
  font-size:.7rem;font-weight:600;text-transform:uppercase;
  letter-spacing:.14em;color:rgba(255,255,255,.55)
}
.ph-field input,
.ph-field select,
.ph-field textarea{
  width:100%;padding:12px 16px;
  border:1px solid rgba(255,255,255,.12);
  background:rgba(255,255,255,.04);color:var(--ph-white);
  font-family:var(--ph-f-sans);font-size:.9rem;
  transition:border-color .25s;outline:none;border-radius:0
}
.ph-field input:focus,
.ph-field select:focus,
.ph-field textarea:focus{border-color:var(--ph-amber)}
.ph-field select option{background:var(--ph-jet);color:var(--ph-white)}
.ph-field textarea{min-height:110px;resize:vertical}

/* ── FOOTER CTA ─────────────────────────────────────────────── */
.ph-footer-cta{
  padding:80px 0;text-align:center;
  background:var(--ph-jet);border-top:1px solid rgba(232,160,32,.15)
}
.ph-footer-cta h2{color:var(--ph-white);margin-bottom:16px}
.ph-footer-cta p{
  font-size:1rem;color:rgba(255,255,255,.6);
  max-width:480px;margin:0 auto 36px;line-height:1.8
}

/* ── SCROLL REVEAL ──────────────────────────────────────────── */
.ph-reveal{opacity:0;transform:translateY(28px);transition:opacity .65s ease,transform .65s ease}
.ph-reveal.ph-visible{opacity:1;transform:translateY(0)}

/* ── RESPONSIVE ─────────────────────────────────────────────── */
@media(max-width:1050px){.ph-hero-scene{width:400px}}
@media(max-width:880px){
  .ph-hero-scene{display:none}
  .ph-stats-grid{grid-template-columns:repeat(2,1fr)}
  .ph-portfolio-grid{grid-template-columns:1fr 1fr;grid-auto-rows:200px}
  .ph-portfolio-tile:nth-child(1){grid-column:span 2;grid-row:span 1}
  .ph-portfolio-tile:nth-child(5){grid-column:span 1}
  .ph-services-grid{grid-template-columns:repeat(2,1fr)}
  .ph-packages-grid{grid-template-columns:1fr}
  .ph-pkg-card--featured{transform:none}
  .ph-process-grid{grid-template-columns:repeat(2,1fr);gap:32px}
  .ph-process-grid::before{display:none}
  .ph-testi-grid{grid-template-columns:1fr}
  .ph-faq-grid{grid-template-columns:1fr}
  .ph-booking-wrap{grid-template-columns:1fr}
}
@media(max-width:600px){
  .ph-section{padding:68px 0}
  .ph-services-grid{grid-template-columns:1fr}
  .ph-form-row{grid-template-columns:1fr}
  .ph-hero-stats{flex-direction:column;gap:24px}
  .ph-hero-btns{flex-direction:column}
  .ph-portfolio-grid{grid-template-columns:1fr;grid-auto-rows:180px}
  .ph-portfolio-tile:nth-child(1){grid-column:span 1}
  .ph-portfolio-tile:nth-child(5){grid-column:span 1}
}
</style>

<!-- ── HERO ──────────────────────────────────────────────────── -->
<section class="ph-hero">

  <!-- ambient glow orbs -->
  <div class="ph-ambient-glow" style="width:400px;height:400px;top:10%;left:5%;animation-delay:0s" aria-hidden="true"></div>
  <div class="ph-ambient-glow" style="width:300px;height:300px;top:50%;left:20%;animation-delay:2s;background:radial-gradient(circle,rgba(255,255,255,.04) 0%,transparent 70%)" aria-hidden="true"></div>

  <!-- CSS STUDIO SCENE -->
  <div class="ph-hero-scene" aria-hidden="true">
    <div class="ph-studio-wall"></div>
    <div class="ph-backdrop"></div>
    <div class="ph-studio-floor"></div>

    <!-- soft box left -->
    <div class="ph-softbox-l">
      <div class="ph-softbox-l-head"></div>
      <div class="ph-softbox-l-arm"></div>
      <div class="ph-softbox-l-stand"></div>
    </div>

    <!-- soft box right -->
    <div class="ph-softbox-r">
      <div class="ph-softbox-r-head"></div>
      <div class="ph-softbox-r-stand"></div>
    </div>

    <!-- camera on tripod -->
    <div class="ph-tripod">
      <div class="ph-camera-body">
        <div class="ph-lens"></div>
      </div>
    </div>

    <!-- photographer -->
    <div class="ph-photographer">
      <div class="ph-phfig-head"></div>
      <div class="ph-phfig-body" style="position:relative">
        <div class="ph-phfig-arm-l"></div>
        <div class="ph-phfig-arm-r"></div>
      </div>
      <div class="ph-phfig-legs"></div>
    </div>

    <!-- floating spec tags -->
    <div class="ph-spec-tag" style="top:15%;left:10%;animation-delay:0s">
      <strong>Sony A1</strong>Full Frame 50MP
    </div>
    <div class="ph-spec-tag" style="top:30%;right:5%;animation-delay:1.5s">
      <strong>RAW Delivery</strong>48-hr Turnaround
    </div>
    <div class="ph-spec-tag" style="top:50%;left:5%;animation-delay:3s">
      <strong>4K Video</strong>Cinema Grade
    </div>

  </div><!-- /scene -->

  <div class="ph-container" style="position:relative;z-index:5">
    <div class="ph-hero-content">

      <div class="ph-hero-sig">Isabel Rowe Photography</div>

      <h1 class="ph-h1">
        <strong>Images that</strong><br>
        <em>move people.</em>
      </h1>

      <span class="ph-line"></span>

      <p class="ph-hero-desc">
        Award-winning commercial, portrait and editorial photography based in Edinburgh.
        Trusted by global brands and independent businesses alike to create visuals that stop the scroll and tell the story.
      </p>

      <div class="ph-hero-btns">
        <a href="#booking" class="ph-btn ph-btn--amber">Book a Session</a>
        <a href="#portfolio" class="ph-btn ph-btn--outline-white">View Portfolio</a>
      </div>

      <div class="ph-hero-stats">
        <?php
        $hstats = [
          ['num'=>'850+','label'=>'Projects Delivered'],
          ['num'=>'12','label'=>'Industry Awards'],
          ['num'=>'4.9★','label'=>'Client Rating'],
        ];
        foreach($hstats as $s):?>
        <div>
          <div class="ph-hero-stat-num"><?=esc_html($s['num'])?></div>
          <div class="ph-hero-stat-label"><?=esc_html($s['label'])?></div>
        </div>
        <?php endforeach;?>
      </div>

    </div>
  </div>

</section><!-- /hero -->

<!-- ── STATS ─────────────────────────────────────────────────── -->
<section class="ph-section--dark" style="padding:0">
  <div class="ph-stats-grid">
    <?php
    $stats = [
      ['num'=>850,'suf'=>'+','label'=>'Projects Delivered'],
      ['num'=>12,'suf'=>'','label'=>'Industry Awards'],
      ['num'=>96,'suf'=>'%','label'=>'Repeat Clients'],
      ['num'=>9,'suf'=>'','label'=>'Years in the Business'],
    ];
    foreach($stats as $s):?>
    <div class="ph-stat-cell">
      <span class="ph-stat-num" data-target="<?=esc_attr($s['num'])?>" data-suffix="<?=esc_attr($s['suf'])?>">0</span>
      <span class="ph-stat-label"><?=esc_html($s['label'])?></span>
    </div>
    <?php endforeach;?>
  </div>
</section>

<!-- ── PORTFOLIO ─────────────────────────────────────────────── -->
<section class="ph-section ph-section--jet-lt" id="portfolio">
  <div class="ph-container">

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:end;margin-bottom:0">
      <div>
        <div class="ph-eyebrow">Selected Work</div>
        <h2 class="ph-h2" style="color:var(--ph-white)">Portfolio</h2>
      </div>
      <p class="ph-lead" style="color:rgba(255,255,255,.6)">
        A selection of recent commercial, portrait and editorial projects spanning fashion, hospitality, architecture and brand identity.
      </p>
    </div>

    <div class="ph-portfolio-grid ph-reveal">
      <?php
      srand(crc32('ph-portfolio'));
      $tiles = [
        ['cat'=>'Commercial','title'=>'Brand Campaign — Edinburgh Gin','bg'=>'linear-gradient(135deg,#1a0d05 0%,#3d1a08 100%)'],
        ['cat'=>'Portrait','title'=>'Executive Portraits — Blackwood Capital','bg'=>'linear-gradient(135deg,#050a1a 0%,#0d1e3d 100%)'],
        ['cat'=>'Editorial','title'=>'Vogue Scotland — Autumn Collection','bg'=>'linear-gradient(135deg,#1a1a0d 0%,#3d3d08 100%)'],
        ['cat'=>'Architecture','title'=>'Waldorf Astoria Hotel — Interior','bg'=>'linear-gradient(135deg,#0d1a1a 0%,#083d3d 100%)'],
        ['cat'=>'Product','title'=>'Luxury Skincare — Still Life Series','bg'=>'linear-gradient(135deg,#1a0d1a 0%,#3d0d3d 100%)'],
        ['cat'=>'Event','title'=>'The Caledonian Ball — Reportage','bg'=>'linear-gradient(135deg,#1a1005 0%,#3d2808 100%)'],
      ];
      foreach($tiles as $t):?>
      <div class="ph-portfolio-tile">
        <div class="ph-portfolio-bg" style="background:<?=esc_attr($t['bg'])?>"></div>
        <div class="ph-portfolio-overlay"></div>
        <div class="ph-portfolio-info">
          <div class="ph-portfolio-cat"><?=esc_html($t['cat'])?></div>
          <div class="ph-portfolio-title"><?=esc_html($t['title'])?></div>
        </div>
      </div>
      <?php endforeach;?>
    </div>

  </div>
</section>

<!-- ── SERVICES ──────────────────────────────────────────────── -->
<section class="ph-section ph-section--cream" id="services">
  <div class="ph-container">

    <div style="max-width:600px;margin:0 auto 64px;text-align:center">
      <div class="ph-eyebrow ph-eyebrow--dark">What I Offer</div>
      <h2 class="ph-h2">Photography Services</h2>
      <span class="ph-line ph-line--center"></span>
    </div>

    <div class="ph-services-grid">
      <?php
      $services = [
        ['icon'=>'📸','name'=>'Commercial & Brand','desc'=>'Campaign imagery, product photography, team headshots and brand identity visuals for agencies and in-house marketing teams.','price'=>'From £450/half day'],
        ['icon'=>'👤','name'=>'Portrait & Headshots','desc'=>'Executive headshots, LinkedIn portraits, actor headshots and personal branding shoots in studio or on location.','price'=>'From £195/session'],
        ['icon'=>'📖','name'=>'Editorial & Magazine','desc'=>'Fashion, lifestyle and feature editorial for print and digital publications. Full creative direction available.','price'=>'POA'],
        ['icon'=>'🏛️','name'=>'Architecture & Interiors','desc'=>'Hotels, restaurants, residential properties and commercial spaces shot for developers, architects and hospitality brands.','price'=>'From £650/day'],
        ['icon'=>'🎥','name'=>'Video & Motion','desc'=>'4K brand films, social media reels, talking-head interviews and cinematic short-form content.','price'=>'From £850/day'],
        ['icon'=>'🎉','name'=>'Events & Reportage','desc'=>'Corporate events, awards dinners, private parties and documentary-style social media content capture.','price'=>'From £500/event'],
      ];
      foreach($services as $s):?>
      <div class="ph-service-card ph-reveal">
        <span class="ph-service-icon"><?=esc_html($s['icon'])?></span>
        <div class="ph-service-name"><?=esc_html($s['name'])?></div>
        <p class="ph-service-desc"><?=esc_html($s['desc'])?></p>
        <div class="ph-service-price"><?=esc_html($s['price'])?></div>
      </div>
      <?php endforeach;?>
    </div>

  </div>
</section>

<!-- ── PACKAGES ──────────────────────────────────────────────── -->
<section class="ph-section ph-section--jet-lt">
  <div class="ph-container">

    <div style="text-align:center;max-width:560px;margin:0 auto 64px">
      <div class="ph-eyebrow">Packages</div>
      <h2 class="ph-h2" style="color:var(--ph-white)">Portrait Session Packages</h2>
    </div>

    <div class="ph-packages-grid">

      <!-- Essential -->
      <div class="ph-pkg-card ph-pkg-card--standard ph-reveal">
        <div class="ph-pkg-top">
          <div class="ph-pkg-badge">Essential</div>
          <div class="ph-pkg-name">Mini Session</div>
          <div class="ph-pkg-price"><sup>£</sup>195</div>
          <div class="ph-pkg-period">1 hour · studio · 15 edited images</div>
        </div>
        <div class="ph-pkg-body">
          <?php
          foreach(['1-hour studio session','Up to 2 outfit changes','15 high-resolution edited images','Online gallery for 30 days','Personal use licence'] as $f):?>
          <div class="ph-pkg-feature"><span class="ph-pkg-check">✓</span><span><?=esc_html($f)?></span></div>
          <?php endforeach;?>
          <div class="ph-pkg-btn"><a href="#booking" class="ph-btn ph-btn--outline-white" style="width:100%;justify-content:center">Book Now</a></div>
        </div>
      </div>

      <!-- Signature (featured) -->
      <div class="ph-pkg-card ph-pkg-card--featured ph-reveal">
        <div class="ph-pkg-top">
          <div class="ph-pkg-badge">★ Most Popular</div>
          <div class="ph-pkg-name">Signature Session</div>
          <div class="ph-pkg-price"><sup>£</sup>395</div>
          <div class="ph-pkg-period">2 hours · studio + location · 35 edited images</div>
        </div>
        <div class="ph-pkg-body">
          <?php
          foreach(['2-hour studio + location session','Unlimited outfit changes','35 high-resolution edited images','Online gallery for 60 days','Commercial + personal licence','Complimentary 16×12 print','Pre-shoot consultation call'] as $f):?>
          <div class="ph-pkg-feature"><span class="ph-pkg-check">✓</span><span><?=esc_html($f)?></span></div>
          <?php endforeach;?>
          <div class="ph-pkg-btn"><a href="#booking" class="ph-btn ph-btn--amber" style="width:100%;justify-content:center">Book Now</a></div>
        </div>
      </div>

      <!-- Brand Day -->
      <div class="ph-pkg-card ph-pkg-card--premium ph-reveal">
        <div class="ph-pkg-top">
          <div class="ph-pkg-badge">Business</div>
          <div class="ph-pkg-name">Brand Day</div>
          <div class="ph-pkg-price"><sup>£</sup>850</div>
          <div class="ph-pkg-period">Full day · studio + on-site · 75 edited images</div>
        </div>
        <div class="ph-pkg-body">
          <?php
          foreach(['Full-day studio + location','Up to 4 team members','75 high-resolution edited images','Lifestyle + product photography','Commercial licence · all platforms','Dedicated art direction','48-hour fast-track delivery'] as $f):?>
          <div class="ph-pkg-feature"><span class="ph-pkg-check">✓</span><span><?=esc_html($f)?></span></div>
          <?php endforeach;?>
          <div class="ph-pkg-btn"><a href="#booking" class="ph-btn ph-btn--outline-white" style="width:100%;justify-content:center">Enquire Now</a></div>
        </div>
      </div>

    </div>

  </div>
</section>

<!-- ── PROCESS ───────────────────────────────────────────────── -->
<section class="ph-section ph-section--jet-mid">
  <div class="ph-container">

    <div style="text-align:center;max-width:560px;margin:0 auto 72px">
      <div class="ph-eyebrow">My Approach</div>
      <h2 class="ph-h2" style="color:var(--ph-white)">How Every Session Works</h2>
    </div>

    <div class="ph-process-grid">
      <?php
      $steps = [
        ['icon'=>'💬','title'=>'Discovery Call','desc'=>'We talk through your goals, vision, aesthetic and how you\'ll use the images — this shapes the whole shoot.'],
        ['icon'=>'📋','title'=>'Pre-Shoot Brief','desc'=>'I send a detailed brief with location, mood board, shot list and styling notes so we both arrive fully prepared.'],
        ['icon'=>'📷','title'=>'The Shoot','desc'=>'A relaxed, collaborative session where I direct, but follow your creative instincts wherever they lead.'],
        ['icon'=>'🖼️','title'=>'Edited Gallery','desc'=>'Your finished images are delivered to a private online gallery within 48 hours, print-ready and retouched.'],
      ];
      foreach($steps as $i=>$s):?>
      <div class="ph-process-step ph-reveal">
        <div class="ph-process-icon">
          <?=esc_html($s['icon'])?>
          <div class="ph-process-num"><?=$i+1?></div>
        </div>
        <h3 class="ph-process-title"><?=esc_html($s['title'])?></h3>
        <p class="ph-process-desc"><?=esc_html($s['desc'])?></p>
      </div>
      <?php endforeach;?>
    </div>

  </div>
</section>

<!-- ── TESTIMONIALS ──────────────────────────────────────────── -->
<section class="ph-section ph-section--cream">
  <div class="ph-container">

    <div style="text-align:center;max-width:560px;margin:0 auto 64px">
      <div class="ph-eyebrow ph-eyebrow--dark">Client Stories</div>
      <h2 class="ph-h2">What Clients Say</h2>
    </div>

    <div class="ph-testi-grid">
      <?php
      $testis = [
        ['text'=>'Isabel transformed our entire brand identity shoot in a single day. The images ran across our website, Forbes article and all print materials. Absolutely world-class.','name'=>'Andrew MacPherson','occasion'=>'CEO — Cairngorm Capital Partners','avatar'=>'🏢'],
        ['text'=>'I\'ve had headshots done before but nothing like this. Isabel made me feel completely at ease and the results genuinely stopped me scrolling when I saw them on my own feed.','name'=>'Rebecca Lowe','occasion'=>'Barrister — Parliament Square Chambers','avatar'=>'👤'],
        ['text'=>'We hired Isabel for our annual Edinburgh Gin campaign and the images exceeded every brief we\'d set. Her eye for light is something really special.','name'=>'Fraser Dunlop','occasion'=>'Brand Director — Edinburgh Gin Co.','avatar'=>'🥃'],
      ];
      foreach($testis as $t):?>
      <div class="ph-testi-card ph-reveal">
        <div class="ph-testi-stars">★★★★★</div>
        <p class="ph-testi-text">"<?=esc_html($t['text'])?>"</p>
        <div class="ph-testi-author">
          <div class="ph-testi-avatar"><?=esc_html($t['avatar'])?></div>
          <div>
            <div class="ph-testi-name"><?=esc_html($t['name'])?></div>
            <div class="ph-testi-occasion"><?=esc_html($t['occasion'])?></div>
          </div>
        </div>
      </div>
      <?php endforeach;?>
    </div>

  </div>
</section>

<!-- ── FAQ ───────────────────────────────────────────────────── -->
<section class="ph-section ph-section--dark">
  <div class="ph-container">

    <div style="text-align:center;max-width:560px;margin:0 auto 56px">
      <div class="ph-eyebrow">Common Questions</div>
      <h2 class="ph-h2" style="color:var(--ph-white)">FAQ</h2>
    </div>

    <div class="ph-faq-grid">
      <?php
      $faqs = [
        ['q'=>'How far in advance do I need to book?','a'=>'For portraits and headshots, 1–2 weeks is usually sufficient. For brand days and commercial shoots, I recommend 3–4 weeks to allow for full briefing, mood boards and any location scouting.'],
        ['q'=>'What happens if the weather ruins an outdoor shoot?','a'=>'I always have a studio backup for any location work. If you prefer to reschedule rather than move indoors, I\'ll hold a priority re-booking date within 4 weeks at no extra charge.'],
        ['q'=>'How quickly will I receive my images?','a'=>'Standard delivery is 5–7 working days. Fast-track 48-hour delivery is available on all packages for an additional £95. All images are delivered via a secure private online gallery.'],
        ['q'=>'Do I own the copyright to my photos?','a'=>'I retain copyright as the creator, but each package includes a clearly defined licence for your use. Commercial licences cover all digital and print use for your business. Full copyright buyout is available on request.'],
        ['q'=>'Can I bring hair & make-up artists?','a'=>'Absolutely — I work with an excellent local team and can arrange professional hair and make-up for your session. Just mention this when booking and I\'ll include a quote.'],
        ['q'=>'What should I wear to my portrait session?','a'=>'I send a detailed pre-shoot guide covering styling, colours, patterns and what to avoid. During our pre-shoot call we\'ll go through your wardrobe together to make sure every outfit works on camera.'],
      ];
      foreach($faqs as $i=>$f):?>
      <div class="ph-faq-item">
        <button class="ph-faq-q" aria-expanded="false" aria-controls="ph-faq-a-<?=$i?>">
          <?=esc_html($f['q'])?>
          <span class="ph-faq-icon" aria-hidden="true">+</span>
        </button>
        <div class="ph-faq-a" id="ph-faq-a-<?=$i?>" role="region">
          <div class="ph-faq-a-inner"><?=esc_html($f['a'])?></div>
        </div>
      </div>
      <?php endforeach;?>
    </div>

  </div>
</section>

<!-- ── BOOKING ───────────────────────────────────────────────── -->
<section class="ph-section ph-section--jet-lt" id="booking">
  <div class="ph-container">
    <div class="ph-booking-wrap">

      <div class="ph-booking-info ph-reveal">
        <div class="ph-eyebrow">Book a Session</div>
        <h2 class="ph-h2">Let's Create Something Beautiful</h2>
        <span class="ph-line"></span>
        <p>Tell me about your project and I'll get back to you within 24 hours with availability, pricing and a free 20-minute discovery call.</p>

        <?php
        $bdetails = [
          ['icon'=>'📍','label'=>'Studio Location','value'=>'22 Canongate, Edinburgh EH8 8AD'],
          ['icon'=>'📞','label'=>'Direct Line','value'=>'+44 131 000 1234'],
          ['icon'=>'📧','label'=>'Email','value'=>'hello@isabelrowephoto.co.uk'],
          ['icon'=>'🕒','label'=>'Availability','value'=>"Mon–Sat · By appointment\nSunday shoots available on request"],
        ];
        foreach($bdetails as $d):?>
        <div class="ph-booking-detail">
          <div class="ph-booking-icon"><?=esc_html($d['icon'])?></div>
          <div>
            <div class="ph-booking-label"><?=esc_html($d['label'])?></div>
            <div class="ph-booking-value" style="white-space:pre-line"><?=esc_html($d['value'])?></div>
          </div>
        </div>
        <?php endforeach;?>

      </div>

      <div class="ph-form ph-reveal">
        <div class="ph-form-title">Project Enquiry</div>
        <div class="ph-form-subtitle">I'll respond within one business day</div>

        <form method="post" action="<?=esc_url(admin_url('admin-post.php'))?>">
          <?php wp_nonce_field('tf_ph_booking','tf_ph_nonce'); ?>
          <input type="hidden" name="action" value="tf_ph_booking">

          <div class="ph-form-row">
            <div class="ph-field">
              <label for="ph-fname">First Name</label>
              <input type="text" id="ph-fname" name="first_name" placeholder="Isabel" required autocomplete="given-name">
            </div>
            <div class="ph-field">
              <label for="ph-lname">Last Name</label>
              <input type="text" id="ph-lname" name="last_name" placeholder="Rowe" required autocomplete="family-name">
            </div>
          </div>

          <div class="ph-form-row">
            <div class="ph-field">
              <label for="ph-email">Email</label>
              <input type="email" id="ph-email" name="email" placeholder="you@example.com" required autocomplete="email">
            </div>
            <div class="ph-field">
              <label for="ph-phone">Phone</label>
              <input type="tel" id="ph-phone" name="phone" placeholder="+44 7700 900000" autocomplete="tel">
            </div>
          </div>

          <div class="ph-field">
            <label for="ph-type">Session Type</label>
            <select id="ph-type" name="session_type">
              <option value="">— Select session type —</option>
              <option value="portrait">Portrait / Headshots</option>
              <option value="commercial">Commercial & Brand</option>
              <option value="editorial">Editorial / Magazine</option>
              <option value="architecture">Architecture / Interiors</option>
              <option value="video">Video / Motion</option>
              <option value="event">Event / Reportage</option>
              <option value="other">Other / Not Sure</option>
            </select>
          </div>

          <div class="ph-form-row">
            <div class="ph-field">
              <label for="ph-date">Preferred Date</label>
              <input type="date" id="ph-date" name="preferred_date">
            </div>
            <div class="ph-field">
              <label for="ph-budget">Approximate Budget</label>
              <select id="ph-budget" name="budget">
                <option value="">— Budget range —</option>
                <option value="under-500">Under £500</option>
                <option value="500-1000">£500 – £1,000</option>
                <option value="1000-2500">£1,000 – £2,500</option>
                <option value="2500-plus">£2,500+</option>
              </select>
            </div>
          </div>

          <div class="ph-field">
            <label for="ph-message">Tell Me About Your Project</label>
            <textarea id="ph-message" name="message" placeholder="What are you shooting? Who is it for? Any reference images or mood boards?"></textarea>
          </div>

          <button type="submit" class="ph-btn ph-btn--amber" style="width:100%;justify-content:center;font-size:.85rem;padding:16px;letter-spacing:.15em">
            📷 Send Enquiry
          </button>
          <p style="text-align:center;margin-top:12px;font-size:.78rem;color:rgba(255,255,255,.35);letter-spacing:.08em">
            RESPONSE WITHIN 24 HOURS · CONFIDENTIAL
          </p>

        </form>
      </div>

    </div>
  </div>
</section>

<!-- ── FOOTER CTA ─────────────────────────────────────────────── -->
<section class="ph-footer-cta">
  <div class="ph-container" style="position:relative;z-index:1">
    <div class="ph-eyebrow ph-eyebrow--silver" style="justify-content:center;display:flex">Isabel Rowe Photography</div>
    <h2 class="ph-h2">Edinburgh · Nationwide · International</h2>
    <p>Commercial, portrait and editorial photography for brands and individuals who care about how they look.</p>
    <div style="display:flex;gap:16px;justify-content:center;flex-wrap:wrap">
      <a href="tel:01310001234" class="ph-btn ph-btn--amber">📞 0131 000 1234</a>
      <a href="#booking" class="ph-btn ph-btn--outline-white">Book a Session</a>
    </div>
  </div>
</section>

</div><!-- /ph-wrap -->

<!-- ── JAVASCRIPT ─────────────────────────────────────────────── -->
<script>
(function(){

  /* animated counters */
  const easeOut = t => 1 - Math.pow(1-t,3);
  document.querySelectorAll('.ph-stat-num[data-target]').forEach(el=>{
    const target = parseFloat(el.dataset.target);
    const suffix = el.dataset.suffix||'';
    if(isNaN(target)) return;
    const obs = new IntersectionObserver(entries=>{
      entries.forEach(e=>{
        if(!e.isIntersecting) return;
        obs.unobserve(e.target);
        const dur=1800, start=performance.now();
        (function tick(now){
          const t = Math.min((now-start)/dur,1);
          el.textContent = Math.round(easeOut(t)*target).toLocaleString() + suffix;
          if(t<1) requestAnimationFrame(tick);
          else el.textContent = target.toLocaleString() + suffix;
        })(start);
      });
    },{threshold:.4});
    obs.observe(el);
  });

  /* FAQ accordion */
  document.querySelectorAll('.ph-faq-q').forEach(btn=>{
    btn.addEventListener('click',function(){
      const item = this.closest('.ph-faq-item');
      const ans  = item.querySelector('.ph-faq-a');
      const open = item.classList.contains('ph-open');
      document.querySelectorAll('.ph-faq-item.ph-open').forEach(o=>{
        o.classList.remove('ph-open');
        o.querySelector('.ph-faq-a').style.maxHeight='0';
        o.querySelector('.ph-faq-q').setAttribute('aria-expanded','false');
      });
      if(!open){
        item.classList.add('ph-open');
        ans.style.maxHeight = ans.scrollHeight+'px';
        this.setAttribute('aria-expanded','true');
      }
    });
  });

  /* scroll reveal */
  const ro = new IntersectionObserver(entries=>{
    entries.forEach((e,i)=>{
      if(!e.isIntersecting) return;
      setTimeout(()=>e.target.classList.add('ph-visible'),i*85);
      ro.unobserve(e.target);
    });
  },{threshold:.1});
  document.querySelectorAll('.ph-reveal').forEach(el=>ro.observe(el));

})();
</script>

<?php get_footer(); ?>
