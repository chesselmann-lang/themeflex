<?php
/**
 * Template Name: Physio – Physiotherapy & Sports Rehabilitation
 *
 * Premium physiotherapy practice homepage template.
 * Nunito + Source Serif 4 · --py-* namespace · cobalt/white/warm-grey palette
 * CSS art-directed treatment room hero · WCAG 2.1 AA · vanilla JS
 *
 * @package ThemeFlex
 */

defined( 'ABSPATH' ) || exit;

srand( crc32( get_the_permalink() ) );

/* ── palette ────────────────────────────────────────────────────────── */
$py_cobalt    = '#1A5FA8';
$py_cobalt_dk = '#124480';
$py_cobalt_lt = '#E8F1FB';
$py_orange    = '#E07830';
$py_white     = '#FAFCFF';
$py_grey      = '#F0F4F8';
$py_navy      = '#0E2040';
$py_text      = '#2C3A4A';

/* ── treatment table & equipment ─────────────────────────────────────*/
$equipment = [
    [ 'type' => 'resistance_band', 'color' => '#E07830', 'x' => 4,  'y' => 60 ],
    [ 'type' => 'foam_roller',     'color' => '#1A5FA8', 'x' => 9,  'y' => 64 ],
    [ 'type' => 'resistance_band', 'color' => '#3A9A50', 'x' => 14, 'y' => 62 ],
];

/* ── floating anatomy icons ──────────────────────────────────────────*/
$floaters = [];
for ( $i = 0; $i < 14; $i++ ) {
    $floaters[] = [
        'x'     => rand( 2, 97 ),
        'y'     => rand( 5, 88 ),
        'sz'    => rand( 10, 20 ),
        'op'    => rand( 4, 14 ),
        'delay' => rand( 0, 80 ) / 10,
        'dur'   => rand( 40, 70 ) / 10,
    ];
}

/* ── services ────────────────────────────────────────────────────────*/
$services = [
    [ 'icon' => '🦴', 'title' => 'Musculoskeletal Physio',      'desc' => 'Assessment and hands-on treatment of joint, muscle, and soft tissue injuries at any stage of recovery.' ],
    [ 'icon' => '⚽', 'title' => 'Sports Rehabilitation',        'desc' => 'Return-to-sport protocols designed around your sport, position, and performance timeline.' ],
    [ 'icon' => '🏃', 'title' => 'Running & Gait Analysis',     'desc' => 'Video-based gait assessment with corrective loading, strength, and footwear recommendations.' ],
    [ 'icon' => '🧠', 'title' => 'Neurological Rehab',          'desc' => 'Specialist rehabilitation following stroke, MS, Parkinson\'s, and acquired brain injury.' ],
    [ 'icon' => '🤰', 'title' => 'Women\'s Health',             'desc' => 'Ante and postnatal care, pelvic floor rehabilitation, and diastasis recti treatment.' ],
    [ 'icon' => '💆', 'title' => 'Manual Therapy & Sports Massage', 'desc' => 'Deep tissue massage, joint mobilisation, and myofascial release to restore movement and reduce pain.' ],
];

/* ── team ────────────────────────────────────────────────────────────*/
$team = [
    [ 'name' => 'Emma Fielding',   'role' => 'Principal Physiotherapist',     'qual' => 'MSc Physiotherapy · HCPC Registered · CSP Member',      'spec' => 'MSK & Sports Rehab' ],
    [ 'name' => 'Raj Patel',       'role' => 'Sports Rehabilitation Lead',    'qual' => 'BSc Physio · SEM Certificate · BASES Accredited',         'spec' => 'Running & Gait' ],
    [ 'name' => 'Claire Murray',   'role' => 'Women\'s Health Specialist',    'qual' => 'MSc Physiotherapy · POGP Member',                         'spec' => 'Pelvic Health' ],
    [ 'name' => 'Oliver Chen',     'role' => 'Neurological Physiotherapist',  'qual' => 'BPhysio · ACPIN Member · Clinical Neuroscience PGCert',   'spec' => 'Neurology & Stroke' ],
];

/* ── packages ────────────────────────────────────────────────────────*/
$packages = [
    [
        'name'     => 'Initial Assessment',
        'price'    => '£90',
        'period'   => '/ 60 min',
        'featured' => false,
        'items'    => [ 'Full movement & posture screen', 'Injury history & lifestyle review', 'Manual examination', 'Diagnosis & report', 'Initial treatment', 'Home exercise programme' ],
    ],
    [
        'name'     => 'Rehabilitation Block',
        'price'    => '£380',
        'period'   => '/ 5 sessions',
        'featured' => true,
        'items'    => [ 'Assessment + 4 follow-up sessions', 'Personalised rehab programme', 'Digital exercise app access', 'Unlimited messaging support', 'Return-to-sport clearance letter', 'Priority booking', 'Free reassessment at 3 months' ],
    ],
    [
        'name'     => 'Corporate & Team',
        'price'    => 'POA',
        'period'   => '/ bespoke',
        'featured' => false,
        'items'    => [ 'On-site clinic provision', 'Sports team cover & pitch-side', 'Ergonomic workstation audit', 'Staff wellness workshops', 'Monthly retainer packages', 'Insurance & self-referral accepted' ],
    ],
];

/* ── counters ────────────────────────────────────────────────────────*/
$counters = [
    [ 'value' => 19,    'suffix' => 'yrs',  'label' => 'In Practice',       'float' => false ],
    [ 'value' => 12400, 'suffix' => '+',    'label' => 'Patients Treated',  'float' => false ],
    [ 'value' => 4.9,   'suffix' => '★',   'label' => 'Patient Rating',    'float' => true  ],
    [ 'value' => 98,    'suffix' => '%',    'label' => 'Return to Activity', 'float' => false ],
];

/* ── conditions treated ──────────────────────────────────────────────*/
$conditions = [
    'Back & Neck Pain', 'Shoulder Impingement', 'Knee Ligament Injuries', 'Plantar Fasciitis',
    'Rotator Cuff Tears', 'Hip Replacement Rehab', 'Tennis & Golfer\'s Elbow', 'Sciatica',
    'Achilles Tendinopathy', 'ACL Reconstruction', 'Frozen Shoulder', 'Pelvic Floor Dysfunction',
    'Post-Stroke Rehab', 'Spinal Stenosis', 'IT Band Syndrome', 'Concussion Management',
];

/* ── testimonials ────────────────────────────────────────────────────*/
$testimonials = [
    [ 'text' => 'Emma diagnosed my shoulder impingement in the first session after two other physios had missed it. Six weeks of targeted rehab and I was back in the water training for my triathlon. Outstanding.', 'name' => 'Paul T.', 'condition' => 'Shoulder Impingement' ],
    [ 'text' => "Raj's gait analysis was a revelation — he identified a hip drop that was causing my recurring hamstring injuries. The running programme he designed has been injury-free for eight months now.", 'name' => 'Sarah L.', 'condition' => 'Running Injury' ],
    [ 'text' => 'Claire was wonderful throughout my postnatal recovery. Sensitive, knowledgeable, and incredibly thorough. My pelvic floor strength is better now at 40 than it was before having children.', 'name' => 'Nicola M.', 'condition' => 'Postnatal Rehabilitation' ],
];

get_header();
?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;500;600;700;800&family=Source+Serif+4:ital,wght@0,300;0,400;0,600;1,300;1,400&display=swap" rel="stylesheet">

<style>
/* ═══════════════════════════════════════════════════════════════════════
   PHYSIO — CSS CUSTOM PROPERTIES
═══════════════════════════════════════════════════════════════════════ */
:root {
    --py-cobalt:    <?= $py_cobalt ?>;
    --py-cobalt-dk: <?= $py_cobalt_dk ?>;
    --py-cobalt-lt: <?= $py_cobalt_lt ?>;
    --py-orange:    <?= $py_orange ?>;
    --py-white:     <?= $py_white ?>;
    --py-grey:      <?= $py_grey ?>;
    --py-navy:      <?= $py_navy ?>;
    --py-text:      <?= $py_text ?>;

    --py-ff-head: 'Nunito', sans-serif;
    --py-ff-body: 'Source Serif 4', serif;

    --py-radius: 8px;
    --py-shadow: 0 4px 24px rgba(14,32,64,.10);
    --py-trans:  .3s cubic-bezier(.4,0,.2,1);
}

/* ── reset ──────────────────────────────────────────────────────────── */
.py-wrap *, .py-wrap *::before, .py-wrap *::after { box-sizing: border-box; margin: 0; padding: 0; }
.py-wrap { font-family: var(--py-ff-body); color: var(--py-text); background: var(--py-white); overflow-x: hidden; }
.py-container { max-width: 1160px; margin: 0 auto; padding: 0 24px; }

/* ── typography ─────────────────────────────────────────────────────── */
.py-section-label { font-family: var(--py-ff-head); font-size: .72rem; font-weight: 700; letter-spacing: .18em; text-transform: uppercase; color: var(--py-cobalt); display: block; margin-bottom: 12px; }
.py-section-title { font-family: var(--py-ff-head); font-size: clamp(1.8rem, 3.5vw, 2.8rem); font-weight: 800; line-height: 1.15; color: var(--py-navy); }
.py-section-title span { color: var(--py-cobalt); }
.py-section-body  { font-size: .98rem; line-height: 1.85; color: #5A6A7A; margin-top: 18px; font-weight: 300; }

/* ── buttons ────────────────────────────────────────────────────────── */
.py-btn { display: inline-flex; align-items: center; gap: 8px; font-family: var(--py-ff-head); font-size: .88rem; font-weight: 700; padding: 13px 28px; border-radius: var(--py-radius); cursor: pointer; border: 2px solid transparent; text-decoration: none; transition: var(--py-trans); }
.py-btn--primary { background: var(--py-cobalt); color: #fff; }
.py-btn--primary:hover { background: var(--py-cobalt-dk); transform: translateY(-2px); box-shadow: 0 8px 24px rgba(26,95,168,.35); }
.py-btn--ghost { background: transparent; color: #fff; border-color: rgba(255,255,255,.6); }
.py-btn--ghost:hover { background: rgba(255,255,255,.12); }
.py-btn--outline { background: transparent; color: var(--py-cobalt); border-color: var(--py-cobalt); }
.py-btn--outline:hover { background: var(--py-cobalt); color: #fff; }

/* ════════════════════════════════════════════════════════════════════
   HERO
════════════════════════════════════════════════════════════════════ */
.py-hero { position: relative; min-height: 93vh; display: flex; align-items: center; overflow: hidden;
    background: linear-gradient(155deg, #0E2040 0%, #1A4070 45%, #124480 100%); }

/* ── treatment room scene ─────────────────────────────────────────── */
.py-scene { position: absolute; inset: 0; overflow: hidden; }

/* ceiling & walls */
.py-scene__ceiling { position: absolute; top: 0; left: 0; right: 0; height: 12%; background: linear-gradient(180deg, #E8F0F8 0%, #DCE8F4 100%); }
.py-scene__wall { position: absolute; top: 12%; left: 0; right: 0; bottom: 26%; background: linear-gradient(180deg, #ECF3FA 0%, #E0EDF8 100%); }
/* wall dado */
.py-scene__dado { position: absolute; top: 44%; left: 0; right: 0; height: 5px; background: #C0D0E0; }
.py-scene__dado-wall { position: absolute; top: calc(44% + 5px); left: 0; right: 0; bottom: 26%; background: linear-gradient(180deg, #D8E8F4 0%, #C8D8E8 100%); }
/* floor */
.py-scene__floor { position: absolute; bottom: 0; left: 0; right: 0; height: 26%; background: linear-gradient(180deg, #C0CED8 0%, #A8B8C4 100%); }
.py-scene__floor-line { position: absolute; top: 0; left: 0; right: 0; height: 3px; background: #9AAAB4; }
.py-scene__floor::before { content: ''; position: absolute; inset: 0; background: repeating-linear-gradient(90deg, rgba(255,255,255,.06) 0px, rgba(255,255,255,.06) 1px, transparent 1px, transparent 60px); }

/* treatment plinth / table */
.py-scene__plinth { position: absolute; bottom: 26%; left: 18%; width: 48%; }
.py-scene__plinth-top { height: 10px; background: linear-gradient(180deg, #F0F8FF 0%, #D8EAF8 100%); border-radius: 3px 3px 0 0; box-shadow: 0 -2px 6px rgba(0,0,0,.12); }
.py-scene__plinth-body { height: 36px; background: linear-gradient(180deg, #E0F0FF 0%, #C8DCEE 100%); position: relative; }
.py-scene__plinth-leg { position: absolute; bottom: -24px; width: 8px; height: 24px; background: #8A9EB0; border-radius: 0 0 2px 2px; }
/* patient on plinth */
.py-scene__patient { position: absolute; top: -28px; left: 8%; width: 84%; height: 28px; }
.py-scene__patient-body { height: 20px; background: linear-gradient(180deg, #F5DEB3 0%, #E8C89A 100%); border-radius: 8px; position: relative; }
.py-scene__patient-body::before { content: ''; position: absolute; right: -10px; top: 2px; width: 16px; height: 16px; background: radial-gradient(ellipse at 50% 50%, #F5DEB3 0%, #E0C080 100%); border-radius: 50%; } /* head */
/* pillow */
.py-scene__pillow { position: absolute; top: -24px; right: -2px; width: 20px; height: 14px; background: linear-gradient(180deg, #E8EEF8 0%, #D0DAEC 100%); border-radius: 2px; }
/* rolled towel at foot */
.py-scene__towel { position: absolute; top: -16px; left: -4px; width: 14px; height: 20px; background: linear-gradient(90deg, #3A5FA8 0%, #5070B8 100%); border-radius: 8px; }
/* resistance band on wall */
.py-scene__band { position: absolute; top: 20%; right: 8%; width: 24px; height: 60px; background: linear-gradient(180deg, <?= $py_orange ?> 0%, #C06020 100%); border-radius: 4px; }
.py-scene__band::before { content: ''; position: absolute; top: 0; left: 50%; transform: translateX(-50%); width: 4px; height: 4px; background: #8A9EB0; border-radius: 50%; }
/* anatomy chart on wall */
.py-scene__chart { position: absolute; top: 15%; left: 8%; width: 42px; height: 58px; background: #F5F0E8; border: 2px solid #C0D0E0; border-radius: 2px; }
.py-scene__chart::before { content: ''; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 14px; height: 36px; background: #C89070; border-radius: 6px 6px 3px 3px; }
.py-scene__chart::after { content: ''; position: absolute; bottom: 2px; left: 2px; right: 2px; height: 1px; background: #A0B0C0; box-shadow: 0 -5px 0 #A0B0C0, 0 -10px 0 rgba(160,176,192,.5); }
/* overhead ceiling light */
.py-scene__overhead { position: absolute; top: 12%; left: 42%; width: 16%; height: 8px; background: linear-gradient(90deg, transparent, #FFFFFF, transparent); border-radius: 2px; box-shadow: 0 0 20px 8px rgba(255,255,255,.5), 0 0 60px 20px rgba(200,220,240,.2); }
/* physio figure */
.py-scene__physio { position: absolute; bottom: 26%; right: 26%; }
.py-physio-fig { }
.py-physio-fig__head { width: 26px; height: 30px; background: #D4A878; border-radius: 50% 50% 40% 40%; margin: 0 auto; position: relative; }
.py-physio-fig__hair { position: absolute; top: 0; left: 0; right: 0; height: 16px; background: #3D1C02; clip-path: ellipse(50% 55% at 50% 0%); }
.py-physio-fig__hair::after { content: ''; position: absolute; top: 4px; right: -2px; width: 6px; height: 10px; background: #3D1C02; border-radius: 0 4px 4px 0; } /* side bun */
.py-physio-fig__neck { width: 10px; height: 6px; background: #D4A878; margin: 0 auto; }
.py-physio-fig__body { width: 32px; height: 48px; background: var(--py-cobalt); border-radius: 2px 2px 0 0; margin: 0 auto; position: relative; }
.py-physio-fig__body::before { content: ''; position: absolute; top: 5px; left: 3px; width: 10px; height: 14px; background: rgba(255,255,255,.15); border-radius: 1px; } /* badge */
.py-physio-fig__arm-l { position: absolute; left: -10px; top: 8px; width: 10px; height: 26px; background: var(--py-cobalt); border-radius: 4px 0 0 4px; }
.py-physio-fig__arm-r { position: absolute; right: -10px; top: 8px; width: 10px; height: 26px; background: var(--py-cobalt); border-radius: 0 4px 4px 0; }
/* clipboard in hand */
.py-physio-fig__clip { position: absolute; right: -20px; top: 2px; width: 16px; height: 22px; background: #F5F0E8; border: 1px solid #C0D0E0; border-radius: 1px; }
.py-physio-fig__clip::before { content: ''; position: absolute; top: 2px; left: 2px; right: 2px; height: 1px; background: #8AAABA; box-shadow: 0 4px 0 #8AAABA, 0 8px 0 #8AAABA, 0 12px 0 rgba(138,170,186,.4); }

/* floating icons */
.py-floater { position: absolute; pointer-events: none; animation: py-float linear infinite; font-size: 1rem; opacity: .06; }
@keyframes py-float { 0%,100%{ transform:translateY(0); } 50%{ transform:translateY(-10px); } }

/* hero content */
.py-hero__content { position: relative; z-index: 10; max-width: 580px; padding: 60px 0; }
.py-hero__eyebrow { font-family: var(--py-ff-head); font-size: .72rem; font-weight: 700; letter-spacing: .2em; text-transform: uppercase; color: rgba(232,240,251,.8); margin-bottom: 14px; }
.py-hero__title { font-family: var(--py-ff-head); font-size: clamp(2.4rem, 5vw, 4rem); font-weight: 800; line-height: 1.08; color: #fff; }
.py-hero__title span { color: #7EC0F8; }
.py-hero__sub { font-size: .98rem; line-height: 1.85; color: rgba(255,255,255,.74); margin: 20px 0 32px; font-weight: 300; }
.py-hero__ctas { display: flex; gap: 14px; flex-wrap: wrap; }
.py-hero__accreds { display: flex; gap: 18px; margin-top: 28px; flex-wrap: wrap; }
.py-hero__accred { font-family: var(--py-ff-head); font-size: .72rem; font-weight: 700; color: rgba(255,255,255,.6); text-transform: uppercase; letter-spacing: .1em; display: flex; align-items: center; gap: 6px; }
.py-hero__accred::before { content: '✓'; display: flex; align-items: center; justify-content: center; width: 16px; height: 16px; background: var(--py-cobalt); border-radius: 50%; font-size: .6rem; color: #fff; }

/* ════════════════════════════════════════════════════════════════════
   TRUST BAR
════════════════════════════════════════════════════════════════════ */
.py-trust { background: #fff; border-bottom: 1px solid #D8E8F4; }
.py-trust__inner { display: flex; align-items: center; justify-content: center; flex-wrap: wrap; }
.py-trust__item { display: flex; align-items: center; gap: 12px; padding: 20px 28px; border-right: 1px solid #D8E8F4; }
.py-trust__item:last-child { border-right: none; }
.py-trust__icon { font-size: 1.4rem; }
.py-trust__label { font-family: var(--py-ff-head); font-size: .78rem; font-weight: 700; color: var(--py-navy); }
.py-trust__sub { font-size: .7rem; color: #7A8A9A; }

/* ════════════════════════════════════════════════════════════════════
   SERVICES
════════════════════════════════════════════════════════════════════ */
.py-services { padding: 100px 0; background: var(--py-white); }
.py-services__header { text-align: center; max-width: 560px; margin: 0 auto 60px; }
.py-services__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 24px; }
.py-service-card { background: #fff; border-radius: var(--py-radius); padding: 36px 32px; border: 1px solid #D8E8F4; transition: var(--py-trans); position: relative; overflow: hidden; }
.py-service-card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px; background: linear-gradient(90deg, var(--py-cobalt), var(--py-cobalt-dk)); transform: scaleX(0); transform-origin: left; transition: var(--py-trans); }
.py-service-card:hover { transform: translateY(-4px); box-shadow: var(--py-shadow); }
.py-service-card:hover::before { transform: scaleX(1); }
.py-service-card__icon { font-size: 2.2rem; margin-bottom: 16px; display: block; }
.py-service-card__title { font-family: var(--py-ff-head); font-size: 1.05rem; font-weight: 700; color: var(--py-navy); margin-bottom: 10px; }
.py-service-card__desc { font-size: .9rem; line-height: 1.75; color: #5A6A7A; font-weight: 300; }

/* ════════════════════════════════════════════════════════════════════
   CONDITIONS
════════════════════════════════════════════════════════════════════ */
.py-conditions { padding: 80px 0; background: var(--py-cobalt-lt); }
.py-conditions__header { text-align: center; max-width: 560px; margin: 0 auto 48px; }
.py-conditions__cloud { display: flex; flex-wrap: wrap; gap: 10px; justify-content: center; }
.py-condition-tag { font-family: var(--py-ff-head); font-size: .82rem; font-weight: 600; padding: 8px 16px; background: #fff; border: 1px solid #C0D4EC; border-radius: 50px; color: var(--py-cobalt); transition: var(--py-trans); }
.py-condition-tag:hover { background: var(--py-cobalt); color: #fff; border-color: var(--py-cobalt); }

/* ════════════════════════════════════════════════════════════════════
   COUNTERS
════════════════════════════════════════════════════════════════════ */
.py-counters { background: linear-gradient(135deg, var(--py-cobalt-dk) 0%, var(--py-navy) 100%); padding: 80px 0; }
.py-counters__grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 40px; text-align: center; }
.py-counter__value { font-family: var(--py-ff-head); font-size: clamp(2.2rem, 4vw, 3.2rem); font-weight: 800; color: #fff; line-height: 1; }
.py-counter__value span { color: #7EC0F8; }
.py-counter__label { font-family: var(--py-ff-head); font-size: .78rem; font-weight: 600; color: rgba(255,255,255,.55); text-transform: uppercase; letter-spacing: .12em; margin-top: 10px; }

/* ════════════════════════════════════════════════════════════════════
   TEAM
════════════════════════════════════════════════════════════════════ */
.py-team { padding: 100px 0; background: var(--py-grey); }
.py-team__header { text-align: center; max-width: 560px; margin: 0 auto 60px; }
.py-team__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 24px; }
.py-team-card { background: #fff; border-radius: var(--py-radius); overflow: hidden; border: 1px solid #D0E0EC; transition: var(--py-trans); }
.py-team-card:hover { transform: translateY(-4px); box-shadow: var(--py-shadow); }
.py-team-card__figure { height: 200px; background: linear-gradient(180deg, var(--py-cobalt-lt) 0%, #C8D8EC 100%); display: flex; align-items: flex-end; justify-content: center; position: relative; }
/* CSS physio figure */
.py-fig { position: relative; width: 68px; }
.py-fig__head { width: 32px; height: 36px; margin: 0 auto; border-radius: 50% 50% 40% 40%; position: relative; }
.py-fig__hair { position: absolute; top: 0; left: 0; right: 0; height: 18px; clip-path: var(--py-hclip, ellipse(50% 55% at 50% 0%)); }
.py-fig__neck { width: 12px; height: 7px; margin: 0 auto; }
.py-fig__body { width: 44px; height: 58px; border-radius: 2px 2px 0 0; margin: 2px auto 0; position: relative; }
.py-fig__badge { position: absolute; top: 6px; left: 4px; width: 12px; height: 16px; background: rgba(255,255,255,.2); border-radius: 1px; }
.py-fig__arm-l { position: absolute; left: -11px; top: 8px; width: 11px; height: 28px; border-radius: 4px 0 0 4px; }
.py-fig__arm-r { position: absolute; right: -11px; top: 8px; width: 11px; height: 28px; border-radius: 0 4px 4px 0; }
.py-fig__steth { position: absolute; top: 10px; left: 50%; transform: translateX(-50%); width: 18px; height: 12px; border: 2px solid rgba(255,255,255,.3); border-radius: 50% 50% 0 0; border-bottom: none; }
.py-fig__steth::after { content: ''; position: absolute; bottom: -7px; left: 50%; transform: translateX(-50%); width: 5px; height: 5px; background: rgba(255,255,255,.3); border-radius: 50%; }

.py-team-card__info { padding: 20px 22px 24px; }
.py-team-card__name { font-family: var(--py-ff-head); font-size: 1rem; font-weight: 800; color: var(--py-navy); }
.py-team-card__role { font-family: var(--py-ff-head); font-size: .78rem; font-weight: 600; color: var(--py-cobalt); margin: 4px 0 8px; }
.py-team-card__qual { font-size: .78rem; color: #6A7A8A; line-height: 1.45; font-weight: 300; }
.py-team-card__spec { display: inline-flex; align-items: center; gap: 4px; margin-top: 10px; font-family: var(--py-ff-head); font-size: .7rem; font-weight: 700; color: var(--py-cobalt); background: var(--py-cobalt-lt); padding: 3px 10px; border-radius: 50px; }

/* ════════════════════════════════════════════════════════════════════
   PACKAGES
════════════════════════════════════════════════════════════════════ */
.py-packages { padding: 100px 0; background: var(--py-white); }
.py-packages__header { text-align: center; max-width: 580px; margin: 0 auto 60px; }
.py-packages__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 24px; align-items: start; }
.py-package-card { background: #fff; border-radius: var(--py-radius); padding: 40px 36px; border: 1px solid #D0E0EC; position: relative; transition: var(--py-trans); }
.py-package-card:hover { transform: translateY(-4px); box-shadow: var(--py-shadow); }
.py-package-card--featured { background: linear-gradient(160deg, var(--py-cobalt) 0%, var(--py-cobalt-dk) 100%); border-color: transparent; }
.py-package-card--featured .py-package-card__name,
.py-package-card--featured .py-package-card__price,
.py-package-card--featured .py-package-card__period,
.py-package-card--featured .py-package-card__item { color: rgba(255,255,255,.95); }
.py-package-card--featured .py-package-card__item::before { background: rgba(255,255,255,.7); }
.py-package-card__badge { position: absolute; top: -1px; right: 24px; background: var(--py-orange); color: #fff; font-family: var(--py-ff-head); font-size: .68rem; font-weight: 800; letter-spacing: .1em; text-transform: uppercase; padding: 4px 14px 5px; border-radius: 0 0 6px 6px; }
.py-package-card__name { font-family: var(--py-ff-head); font-size: 1.12rem; font-weight: 800; color: var(--py-navy); margin-bottom: 20px; }
.py-package-card__price-row { display: flex; align-items: baseline; gap: 4px; margin-bottom: 28px; }
.py-package-card__price { font-family: var(--py-ff-head); font-size: 2.4rem; font-weight: 800; color: var(--py-navy); }
.py-package-card__period { font-size: .85rem; color: #7A8A9A; font-weight: 300; }
.py-package-card__list { list-style: none; display: flex; flex-direction: column; gap: 10px; margin-bottom: 30px; }
.py-package-card__item { font-size: .88rem; color: #4A5A6A; padding-left: 20px; position: relative; font-weight: 300; }
.py-package-card__item::before { content: ''; position: absolute; left: 0; top: 50%; transform: translateY(-50%); width: 8px; height: 8px; border-radius: 50%; background: var(--py-cobalt); }

/* ════════════════════════════════════════════════════════════════════
   TESTIMONIALS
════════════════════════════════════════════════════════════════════ */
.py-testimonials { padding: 100px 0; background: var(--py-cobalt-lt); }
.py-testimonials__header { text-align: center; max-width: 560px; margin: 0 auto 56px; }
.py-testimonials__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 24px; }
.py-testimonial { background: #fff; border-radius: var(--py-radius); padding: 36px; border: 1px solid #C8D8EC; }
.py-testimonial__stars { color: var(--py-orange); font-size: .95rem; letter-spacing: 2px; margin-bottom: 16px; }
.py-testimonial__text { font-size: .92rem; line-height: 1.85; color: #4A5A6A; font-style: italic; font-weight: 300; }
.py-testimonial__author { margin-top: 22px; display: flex; gap: 12px; align-items: center; }
.py-testimonial__avatar { width: 40px; height: 40px; background: linear-gradient(135deg, var(--py-cobalt), var(--py-cobalt-dk)); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-family: var(--py-ff-head); font-size: .88rem; font-weight: 800; color: #fff; }
.py-testimonial__name { font-family: var(--py-ff-head); font-size: .88rem; font-weight: 800; color: var(--py-navy); }
.py-testimonial__condition { font-size: .78rem; color: var(--py-cobalt); }

/* ════════════════════════════════════════════════════════════════════
   BOOKING
════════════════════════════════════════════════════════════════════ */
.py-booking { padding: 100px 0; background: #fff; }
.py-booking__inner { display: grid; grid-template-columns: 1fr 1fr; gap: 72px; align-items: start; }
.py-form { background: var(--py-grey); border-radius: var(--py-radius); padding: 40px; border: 1px solid #D0E0EC; }
.py-form__title { font-family: var(--py-ff-head); font-size: 1.3rem; font-weight: 800; color: var(--py-navy); margin-bottom: 28px; }
.py-form__row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.py-form__group { display: flex; flex-direction: column; gap: 6px; margin-bottom: 18px; }
.py-form__group--full { grid-column: 1 / -1; }
.py-form__label { font-family: var(--py-ff-head); font-size: .76rem; font-weight: 700; color: var(--py-navy); letter-spacing: .04em; }
.py-form__input, .py-form__select, .py-form__textarea { width: 100%; padding: 11px 15px; border: 1px solid #C0D0E0; border-radius: var(--py-radius); font-family: var(--py-ff-body); font-size: .88rem; color: var(--py-text); background: #fff; transition: var(--py-trans); outline: none; font-weight: 300; }
.py-form__input:focus, .py-form__select:focus, .py-form__textarea:focus { border-color: var(--py-cobalt); box-shadow: 0 0 0 3px rgba(26,95,168,.12); }
.py-form__textarea { resize: vertical; min-height: 100px; }
.py-form__submit { width: 100%; padding: 14px; font-family: var(--py-ff-head); font-size: .92rem; font-weight: 800; color: #fff; background: linear-gradient(135deg, var(--py-cobalt) 0%, var(--py-cobalt-dk) 100%); border: none; border-radius: var(--py-radius); cursor: pointer; transition: var(--py-trans); }
.py-form__submit:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(26,95,168,.35); }
.py-form__note { font-size: .75rem; color: #7A8A9A; text-align: center; margin-top: 12px; font-weight: 300; }
.py-booking__insurance { margin-top: 32px; display: flex; flex-direction: column; gap: 14px; }
.py-booking__ins-row { display: flex; align-items: center; gap: 12px; padding: 12px 16px; background: var(--py-cobalt-lt); border-radius: var(--py-radius); border: 1px solid #C0D4EC; }
.py-booking__ins-name { font-family: var(--py-ff-head); font-size: .82rem; font-weight: 700; color: var(--py-navy); }
.py-booking__ins-note { font-size: .75rem; color: #5A6A7A; font-weight: 300; }

/* ════════════════════════════════════════════════════════════════════
   FOOTER CTA
════════════════════════════════════════════════════════════════════ */
.py-footer-cta { background: linear-gradient(135deg, var(--py-cobalt-dk) 0%, var(--py-navy) 100%); padding: 80px 0; text-align: center; }
.py-footer-cta__title { font-family: var(--py-ff-head); font-size: clamp(1.8rem, 3.5vw, 2.8rem); font-weight: 800; color: #fff; margin-bottom: 14px; }
.py-footer-cta__sub { font-size: .98rem; color: rgba(255,255,255,.68); margin-bottom: 36px; font-weight: 300; }
.py-footer-cta__actions { display: flex; gap: 14px; justify-content: center; flex-wrap: wrap; }

/* ════════════════════════════════════════════════════════════════════
   RESPONSIVE
════════════════════════════════════════════════════════════════════ */
@media (max-width: 900px) {
    .py-booking__inner { grid-template-columns: 1fr; gap: 48px; }
    .py-counters__grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 600px) {
    .py-hero { min-height: 80vh; }
    .py-counters__grid { grid-template-columns: repeat(2, 1fr); }
    .py-form__row { grid-template-columns: 1fr; }
    .py-trust__item { border-right: none; border-bottom: 1px solid #D8E8F4; width: 100%; }
}
</style>

<div class="py-wrap">

    <!-- ═══════════════════════════════════ HERO ═══════════════════════════════════ -->
    <section class="py-hero">
        <div class="py-scene" aria-hidden="true">

            <!-- room structure -->
            <div class="py-scene__ceiling"></div>
            <div class="py-scene__wall"></div>
            <div class="py-scene__dado"></div>
            <div class="py-scene__dado-wall"></div>
            <div class="py-scene__floor">
                <div class="py-scene__floor-line"></div>
            </div>
            <div class="py-scene__overhead"></div>

            <!-- anatomy chart -->
            <div class="py-scene__chart"></div>

            <!-- treatment plinth -->
            <div class="py-scene__plinth">
                <div class="py-scene__patient">
                    <div class="py-scene__patient-body"></div>
                    <div class="py-scene__pillow"></div>
                    <div class="py-scene__towel"></div>
                </div>
                <div class="py-scene__plinth-top"></div>
                <div class="py-scene__plinth-body">
                    <div class="py-scene__plinth-leg" style="left:8%;"></div>
                    <div class="py-scene__plinth-leg" style="right:8%;"></div>
                </div>
            </div>

            <!-- physio figure -->
            <div class="py-scene__physio">
                <div class="py-physio-fig">
                    <div class="py-physio-fig__head">
                        <div class="py-physio-fig__hair"></div>
                    </div>
                    <div class="py-physio-fig__neck"></div>
                    <div style="position:relative;display:inline-block;">
                        <div class="py-physio-fig__body">
                            <div class="py-physio-fig__arm-l"></div>
                            <div class="py-physio-fig__arm-r">
                                <div class="py-physio-fig__clip"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- resistance band -->
            <div class="py-scene__band"></div>

            <!-- floating icons -->
            <?php
            $float_icons = ['🦴','⚕️','🏃','💪','🧘','⚽','🎽','❤️'];
            foreach ( $floaters as $i => $fl ) : ?>
            <div class="py-floater" style="left:<?=$fl['x']?>%;top:<?=$fl['y']?>%;font-size:<?=$fl['sz']?>px;opacity:<?=$fl['op']/100?>;animation-delay:<?=$fl['delay']?>s;animation-duration:<?=$fl['dur']?>s;">
                <?= $float_icons[ $i % count($float_icons) ] ?>
            </div>
            <?php endforeach; ?>

        </div><!-- /.py-scene -->

        <div class="py-container">
            <div class="py-hero__content">
                <p class="py-hero__eyebrow">🩺 HCPC Registered · Evidence-Based Care</p>
                <h1 class="py-hero__title">
                    Move Better,<br>
                    Live <span>Without Pain</span>
                </h1>
                <p class="py-hero__sub">Expert physiotherapy and sports rehabilitation for faster, longer-lasting recovery. Serving patients across London with evidence-based treatment and genuine clinical expertise.</p>
                <div class="py-hero__ctas">
                    <a href="#booking" class="py-btn py-btn--primary">Book an Appointment</a>
                    <a href="#services" class="py-btn py-btn--ghost">Our Services</a>
                </div>
                <div class="py-hero__accreds">
                    <span class="py-hero__accred">HCPC Registered</span>
                    <span class="py-hero__accred">CSP Members</span>
                    <span class="py-hero__accred">Insurance Accepted</span>
                </div>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ TRUST BAR ═════════════════════════════ -->
    <div class="py-trust">
        <div class="py-container">
            <div class="py-trust__inner">
                <?php
                $trust_items = [
                    [ 'icon' => '🏅', 'label' => 'HCPC & CSP Registered',        'sub' => 'All clinicians' ],
                    [ 'icon' => '⚡', 'label' => 'Same-Day Appointments',          'sub' => 'Often available' ],
                    [ 'icon' => '🏥', 'label' => 'Insurance Accepted',             'sub' => 'AXA, Bupa, Aviva, Vitality' ],
                    [ 'icon' => '🔬', 'label' => 'Evidence-Based Treatment',       'sub' => 'Clinically proven protocols' ],
                    [ 'icon' => '📲', 'label' => 'Digital Exercise App',           'sub' => 'Video rehab programme' ],
                ];
                foreach ( $trust_items as $ti ) : ?>
                <div class="py-trust__item">
                    <span class="py-trust__icon"><?= $ti['icon'] ?></span>
                    <div>
                        <div class="py-trust__label"><?= esc_html( $ti['label'] ) ?></div>
                        <div class="py-trust__sub"><?= esc_html( $ti['sub'] ) ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- ═══════════════════════════════════ SERVICES ══════════════════════════════ -->
    <section class="py-services" id="services">
        <div class="py-container">
            <div class="py-services__header">
                <span class="py-section-label">What We Treat</span>
                <h2 class="py-section-title">Specialist <span>Physiotherapy Services</span></h2>
                <p class="py-section-body">From acute injuries to complex chronic conditions, our physiotherapists provide expert assessment and hands-on treatment across a wide range of specialisms.</p>
            </div>
            <div class="py-services__grid">
                <?php foreach ( $services as $s ) : ?>
                <div class="py-service-card">
                    <span class="py-service-card__icon"><?= $s['icon'] ?></span>
                    <h3 class="py-service-card__title"><?= esc_html( $s['title'] ) ?></h3>
                    <p class="py-service-card__desc"><?= esc_html( $s['desc'] ) ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ CONDITIONS ════════════════════════════ -->
    <section class="py-conditions">
        <div class="py-container">
            <div class="py-conditions__header">
                <span class="py-section-label">Conditions Treated</span>
                <h2 class="py-section-title">We Can <span>Help With</span></h2>
            </div>
            <div class="py-conditions__cloud">
                <?php foreach ( $conditions as $cond ) : ?>
                <span class="py-condition-tag"><?= esc_html( $cond ) ?></span>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ COUNTERS ═════════════════════════════ -->
    <section class="py-counters" aria-label="Practice statistics">
        <div class="py-container">
            <div class="py-counters__grid">
                <?php foreach ( $counters as $c ) : ?>
                <div>
                    <div class="py-counter__value"
                         data-target="<?= $c['value'] ?>"
                         <?= $c['float'] ? 'data-float="1"' : '' ?>>
                        <span>0</span><?= esc_html( $c['suffix'] ) ?>
                    </div>
                    <div class="py-counter__label"><?= esc_html( $c['label'] ) ?></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ TEAM ═════════════════════════════════ -->
    <section class="py-team" id="team">
        <div class="py-container">
            <div class="py-team__header">
                <span class="py-section-label">Our Clinicians</span>
                <h2 class="py-section-title">Expert <span>Physiotherapists</span></h2>
                <p class="py-section-body">Our team holds postgraduate qualifications, specialist certifications, and years of hands-on clinical experience across MSK, sports, neurology, and women's health.</p>
            </div>
            <div class="py-team__grid">
                <?php
                $skin_tones = [ '#D4A878', '#C08A58', '#A06838', '#E0C09A' ];
                $hair_cols  = [ '#3D1C02', '#0A0A0A', '#2C1810', '#6B3A1A' ];
                $hair_clips = [ 'ellipse(50% 55% at 50% 0%)', 'ellipse(55% 60% at 50% 0%)', 'ellipse(50% 58% at 50% 0%)', 'ellipse(52% 55% at 50% 0%)' ];
                foreach ( $team as $i => $member ) :
                    $skin = $skin_tones[ $i % count($skin_tones) ];
                    $hair = $hair_cols[ $i % count($hair_cols) ];
                    $clip = $hair_clips[ $i % count($hair_clips) ];
                ?>
                <div class="py-team-card">
                    <div class="py-team-card__figure">
                        <div class="py-fig" style="--py-hclip:<?= $clip ?>;">
                            <div class="py-fig__head" style="background:<?= $skin ?>;">
                                <div class="py-fig__hair" style="background:<?= $hair ?>;height:18px;"></div>
                            </div>
                            <div class="py-fig__neck" style="background:<?= $skin ?>;"></div>
                            <div class="py-fig__body" style="background:var(--py-cobalt);">
                                <div class="py-fig__badge"></div>
                                <div class="py-fig__steth"></div>
                                <div class="py-fig__arm-l" style="background:var(--py-cobalt);"></div>
                                <div class="py-fig__arm-r" style="background:var(--py-cobalt);"></div>
                            </div>
                        </div>
                    </div>
                    <div class="py-team-card__info">
                        <div class="py-team-card__name"><?= esc_html( $member['name'] ) ?></div>
                        <div class="py-team-card__role"><?= esc_html( $member['role'] ) ?></div>
                        <div class="py-team-card__qual"><?= esc_html( $member['qual'] ) ?></div>
                        <div class="py-team-card__spec">🎯 <?= esc_html( $member['spec'] ) ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ PACKAGES ═════════════════════════════ -->
    <section class="py-packages" id="packages">
        <div class="py-container">
            <div class="py-packages__header">
                <span class="py-section-label">Pricing</span>
                <h2 class="py-section-title">Clear <span>Transparent Fees</span></h2>
                <p class="py-section-body">We are recognised by all major health insurers and also welcome self-paying patients. No GP referral required.</p>
            </div>
            <div class="py-packages__grid">
                <?php foreach ( $packages as $pkg ) : ?>
                <div class="py-package-card <?= $pkg['featured'] ? 'py-package-card--featured' : '' ?>">
                    <?php if ( $pkg['featured'] ) : ?>
                    <div class="py-package-card__badge">Best Value</div>
                    <?php endif; ?>
                    <div class="py-package-card__name"><?= esc_html( $pkg['name'] ) ?></div>
                    <div class="py-package-card__price-row">
                        <div class="py-package-card__price"><?= esc_html( $pkg['price'] ) ?></div>
                        <div class="py-package-card__period"><?= esc_html( $pkg['period'] ) ?></div>
                    </div>
                    <ul class="py-package-card__list">
                        <?php foreach ( $pkg['items'] as $item ) : ?>
                        <li class="py-package-card__item"><?= esc_html( $item ) ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <a href="#booking" class="py-btn <?= $pkg['featured'] ? 'py-btn--ghost' : 'py-btn--outline' ?>" style="width:100%;justify-content:center;">
                        Book Now
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ TESTIMONIALS ═════════════════════════ -->
    <section class="py-testimonials">
        <div class="py-container">
            <div class="py-testimonials__header">
                <span class="py-section-label">Patient Reviews</span>
                <h2 class="py-section-title">Patients Who Got <span>Their Life Back</span></h2>
            </div>
            <div class="py-testimonials__grid">
                <?php foreach ( $testimonials as $t ) :
                    $init = strtoupper( $t['name'][0] );
                ?>
                <div class="py-testimonial">
                    <div class="py-testimonial__stars">★★★★★</div>
                    <p class="py-testimonial__text">"<?= esc_html( $t['text'] ) ?>"</p>
                    <div class="py-testimonial__author">
                        <div class="py-testimonial__avatar"><?= $init ?></div>
                        <div>
                            <div class="py-testimonial__name"><?= esc_html( $t['name'] ) ?></div>
                            <div class="py-testimonial__condition"><?= esc_html( $t['condition'] ) ?></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ BOOKING ══════════════════════════════ -->
    <section class="py-booking" id="booking">
        <div class="py-container">
            <div class="py-booking__inner">
                <div class="py-booking__info">
                    <span class="py-section-label">Book an Appointment</span>
                    <h2 class="py-section-title">Start Your <span>Recovery Today</span></h2>
                    <p class="py-section-body">Same-day and next-day appointments are often available. No GP referral needed — book directly with our specialist physiotherapists.</p>
                    <div style="margin-top:28px;">
                        <h3 style="font-family:var(--py-ff-head);font-size:1rem;font-weight:800;color:var(--py-navy);margin-bottom:16px;">Insurance Recognised</h3>
                    </div>
                    <div class="py-booking__insurance">
                        <?php
                        $insurers = [
                            [ 'name' => 'AXA Health',   'note' => 'Direct settlement available' ],
                            [ 'name' => 'Bupa',          'note' => 'All recognised specialists' ],
                            [ 'name' => 'Aviva',         'note' => 'Approved physiotherapy provider' ],
                            [ 'name' => 'Vitality',      'note' => 'Silver & Gold members' ],
                            [ 'name' => 'WPA',           'note' => 'Full cover available' ],
                        ];
                        foreach ( $insurers as $ins ) : ?>
                        <div class="py-booking__ins-row">
                            <span style="font-size:1.2rem;">🏥</span>
                            <div>
                                <div class="py-booking__ins-name"><?= esc_html( $ins['name'] ) ?></div>
                                <div class="py-booking__ins-note"><?= esc_html( $ins['note'] ) ?></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div>
                    <form class="py-form" method="post" action="">
                        <?php wp_nonce_field( 'tf_py_booking', 'tf_py_nonce' ); ?>
                        <h3 class="py-form__title">Book an Appointment</h3>
                        <div class="py-form__row">
                            <div class="py-form__group">
                                <label class="py-form__label" for="py-name">Full Name *</label>
                                <input class="py-form__input" type="text" id="py-name" name="name" placeholder="Jane Smith" required>
                            </div>
                            <div class="py-form__group">
                                <label class="py-form__label" for="py-phone">Phone *</label>
                                <input class="py-form__input" type="tel" id="py-phone" name="phone" placeholder="020 7946 0000" required>
                            </div>
                        </div>
                        <div class="py-form__row">
                            <div class="py-form__group">
                                <label class="py-form__label" for="py-email">Email *</label>
                                <input class="py-form__input" type="email" id="py-email" name="email" placeholder="jane@example.com" required>
                            </div>
                            <div class="py-form__group">
                                <label class="py-form__label" for="py-service">Service Required *</label>
                                <select class="py-form__select" id="py-service" name="service">
                                    <option value="">Select service…</option>
                                    <option>MSK / Back & Neck</option>
                                    <option>Sports Injury</option>
                                    <option>Running & Gait Analysis</option>
                                    <option>Post-Surgery Rehab</option>
                                    <option>Women's Health</option>
                                    <option>Neurological</option>
                                    <option>Sports Massage</option>
                                    <option>Not sure — need assessment</option>
                                </select>
                            </div>
                        </div>
                        <div class="py-form__row">
                            <div class="py-form__group">
                                <label class="py-form__label" for="py-paying">Paying As *</label>
                                <select class="py-form__select" id="py-paying" name="paying">
                                    <option value="self">Self-Paying</option>
                                    <option value="insurance">Health Insurance</option>
                                </select>
                            </div>
                            <div class="py-form__group">
                                <label class="py-form__label" for="py-urgency">Urgency</label>
                                <select class="py-form__select" id="py-urgency" name="urgency">
                                    <option>Same / Next Day</option>
                                    <option>Within the Week</option>
                                    <option>Within 2 Weeks</option>
                                    <option>Flexible</option>
                                </select>
                            </div>
                        </div>
                        <div class="py-form__group py-form__group--full">
                            <label class="py-form__label" for="py-complaint">Chief Complaint *</label>
                            <textarea class="py-form__textarea" id="py-complaint" name="complaint" placeholder="Briefly describe your main symptoms, area of pain, and how long you have had this problem…" required></textarea>
                        </div>
                        <button type="submit" class="py-form__submit">Request Appointment →</button>
                        <p class="py-form__note">We will confirm your appointment within 2 hours during clinic hours.</p>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ FOOTER CTA ═══════════════════════════ -->
    <section class="py-footer-cta">
        <div class="py-container">
            <h2 class="py-footer-cta__title">Pain-Free Starts Here</h2>
            <p class="py-footer-cta__sub">Clarity Physio · Marylebone, London · HCPC Registered · Insurance Accepted</p>
            <div class="py-footer-cta__actions">
                <a href="#booking" class="py-btn py-btn--primary">Book Appointment</a>
                <a href="tel:02079460200" class="py-btn py-btn--ghost">020 7946 0200</a>
            </div>
        </div>
    </section>

</div><!-- /.py-wrap -->

<script>
/* ── IntersectionObserver animated counters ───────────────────────── */
(function () {
    'use strict';
    var easeOut = function (t) { return 1 - Math.pow(1 - t, 3); };
    var els = document.querySelectorAll('.py-counter__value[data-target]');
    if (!els.length) return;
    var obs = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (!entry.isIntersecting) return;
            obs.unobserve(entry.target);
            var el      = entry.target;
            var target  = parseFloat(el.dataset.target);
            var isFloat = !!el.dataset.float;
            var span    = el.querySelector('span');
            if (!span || isNaN(target)) return;
            var dur = 1800, start = null;
            function tick(ts) {
                if (!start) start = ts;
                var p = Math.min((ts - start) / dur, 1);
                var v = easeOut(p) * target;
                span.textContent = isFloat ? v.toFixed(1) : Math.round(v).toLocaleString();
                if (p < 1) requestAnimationFrame(tick);
                else span.textContent = isFloat ? target.toFixed(1) : target.toLocaleString();
            }
            requestAnimationFrame(tick);
        });
    }, { threshold: 0.4 });
    els.forEach(function (el) { obs.observe(el); });
})();
</script>

<?php get_footer(); ?>
