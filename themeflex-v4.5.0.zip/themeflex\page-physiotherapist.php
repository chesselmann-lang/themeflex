<?php
/**
 * Template Name: Physiotherapist
 * Description: Premium page template for Physiotherapy / Physical Therapy clinics
 *
 * @package ThemeFlex
 */

// Fonts: Raleway + Inter
// Namespace: --pt-*
// Hero: CSS human body silhouette with glowing joint/muscle highlights + treatment table scene
// Palette: clinical white #FAFBFC / healing teal #1DB8A6 / warm coral #FF6B6B / deep navy #1E3A5F / soft grey #6B7C93

if ( ! defined( 'ABSPATH' ) ) exit;
srand( crc32( get_the_permalink() ) );

$pt_services = [
    [ 'icon' => '🦴', 'title' => 'Musculoskeletal Physio',    'desc' => 'Back pain, neck pain, joint problems and sports injuries treated with evidence-based manual therapy and exercise rehabilitation.' ],
    [ 'icon' => '🏃', 'title' => 'Sports Injury Rehab',       'desc' => 'From ACL tears to ankle sprains — structured return-to-sport programmes with strength and conditioning guidance.' ],
    [ 'icon' => '🤸', 'title' => 'Post-Surgical Rehab',       'desc' => 'Hip replacement, knee replacement, rotator cuff repair and spinal surgery recovery programmes.' ],
    [ 'icon' => '💆', 'title' => 'Neurological Physio',       'desc' => 'Physiotherapy for stroke, MS, Parkinson\'s disease and acquired brain injuries — helping patients regain independence.' ],
    [ 'icon' => '🧘', 'title' => 'Pilates & Core Stability',  'desc' => 'Clinical Pilates classes led by qualified physiotherapists — ideal for back pain, pelvic floor and posture.' ],
    [ 'icon' => '⚡', 'title' => 'Electrotherapy & Ultrasound','desc' => 'TENS, ultrasound, interferential and shockwave therapy to reduce inflammation and accelerate tissue healing.' ],
    [ 'icon' => '🏥', 'title' => 'Workplace Ergonomics',      'desc' => 'DSE assessments, posture analysis and ergonomic recommendations to prevent work-related injuries.' ],
    [ 'icon' => '👴', 'title' => 'Elderly & Falls Prevention', 'desc' => 'Balance training, falls risk assessment and mobility programmes for older adults and those with complex needs.' ],
];

$pt_conditions = [
    'Lower Back Pain', 'Sciatica', 'Neck Pain', 'Whiplash', 'Frozen Shoulder',
    'Rotator Cuff Tear', 'Tennis Elbow', 'Golfer\'s Elbow', 'Carpal Tunnel',
    'Hip Replacement Rehab', 'Knee Replacement Rehab', 'ACL Reconstruction',
    'Patellofemoral Pain', 'Plantar Fasciitis', 'Achilles Tendinopathy',
    'Scoliosis', 'Disc Herniation', 'Post-Stroke Rehab', 'Fibromyalgia',
    'Osteoarthritis', 'Rheumatoid Arthritis', 'Spondylosis',
];

$pt_process = [
    [ 'step' => '01', 'title' => 'Initial Assessment',    'desc' => 'A thorough 60-minute assessment of your history, posture, movement and pain patterns to establish the root cause.' ],
    [ 'step' => '02', 'title' => 'Diagnosis & Plan',      'desc' => 'Clear explanation of findings and a personalised treatment plan with measurable goals and a realistic recovery timeline.' ],
    [ 'step' => '03', 'title' => 'Hands-On Treatment',    'desc' => 'Manual therapy, joint mobilisation, soft tissue release and dry needling as indicated by your assessment findings.' ],
    [ 'step' => '04', 'title' => 'Exercise Programme',    'desc' => 'A progressive home exercise programme tailored to your stage of recovery, delivered via our patient app.' ],
    [ 'step' => '05', 'title' => 'Discharge & Prevention','desc' => 'Full discharge summary, self-management strategies and an optional maintenance programme to prevent recurrence.' ],
];

$pt_testimonials = [
    [ 'name' => 'Sarah Connelly',  'role' => 'Runner · Glasgow',        'text' => 'After months of Achilles pain stopping my marathon training, I was back running within 8 weeks. The exercise plan was perfectly progressive and the therapist clearly knew their stuff.' ],
    [ 'name' => 'Tom Warburton',   'role' => 'Post-op Patient · Leeds', 'text' => 'Had a knee replacement and was worried about recovery. The post-surgical rehab programme was brilliant — I was walking unaided ahead of schedule. Exceptional care.' ],
    [ 'name' => 'Anjali Sharma',   'role' => 'Office Worker · Bristol', 'text' => 'Chronic neck pain from years at a desk. After the ergonomic assessment and six sessions, I\'m virtually pain free. Wish I\'d come sooner — truly life-changing.' ],
];

$pt_packages = [
    [
        'name'     => 'Initial Assessment',
        'price'    => '£85',
        'period'   => '60-minute session',
        'featured' => false,
        'items'    => [ 'Full MSK assessment', 'Postural analysis', 'Movement screening', 'Diagnosis & plan', 'Written report included' ],
    ],
    [
        'name'     => 'Recovery Package',
        'price'    => '£340',
        'period'   => '5 sessions',
        'featured' => true,
        'items'    => [ 'Assessment + 4 treatment sessions', 'Home exercise programme', 'Patient app access', 'Email support between sessions', 'Discharge summary report', 'Reassessment at session 3' ],
    ],
    [
        'name'     => 'Sports Performance',
        'price'    => '£550',
        'period'   => '8 sessions',
        'featured' => false,
        'items'    => [ 'Biomechanical screening', '7 treatment/rehab sessions', 'Return-to-sport protocol', 'Strength & conditioning plan', 'Video movement analysis', 'Coach liaison report' ],
    ],
];

$pt_counters = [
    [ 'value' => 18,     'suffix' => 'yrs',  'label' => 'Established',       'float' => false ],
    [ 'value' => 9200,   'suffix' => '+',    'label' => 'Patients Treated',  'float' => false ],
    [ 'value' => 4.9,    'suffix' => '★',   'label' => 'Google Rating',     'float' => true  ],
    [ 'value' => 92,     'suffix' => '%',    'label' => 'Return to Activity','float' => false ],
];

// Body joint hotspot positions (% x,y)
$pt_joints = [
    [ 'x' => 50, 'y' =>  8, 'label' => 'Cervical Spine', 'delay' => 0    ],
    [ 'x' => 35, 'y' => 22, 'label' => 'Shoulder',       'delay' => 400  ],
    [ 'x' => 65, 'y' => 22, 'label' => 'Shoulder',       'delay' => 200  ],
    [ 'x' => 50, 'y' => 30, 'label' => 'Lumbar Spine',   'delay' => 600  ],
    [ 'x' => 28, 'y' => 38, 'label' => 'Elbow',          'delay' => 300  ],
    [ 'x' => 72, 'y' => 38, 'label' => 'Elbow',          'delay' => 500  ],
    [ 'x' => 38, 'y' => 52, 'label' => 'Hip',            'delay' => 700  ],
    [ 'x' => 62, 'y' => 52, 'label' => 'Hip',            'delay' => 100  ],
    [ 'x' => 36, 'y' => 70, 'label' => 'Knee',           'delay' => 800  ],
    [ 'x' => 64, 'y' => 70, 'label' => 'Knee',           'delay' => 250  ],
    [ 'x' => 36, 'y' => 88, 'label' => 'Ankle',          'delay' => 900  ],
    [ 'x' => 64, 'y' => 88, 'label' => 'Ankle',          'delay' => 450  ],
];

// Floating health particles
$pt_particles = [];
for ( $i = 0; $i < 16; $i++ ) {
    $pt_particles[] = [
        'x'     => rand( 0, 100 ),
        'y'     => rand( 0, 100 ),
        'size'  => rand( 3, 8 ),
        'dur'   => rand( 3000, 6000 ),
        'delay' => rand( 0, 4000 ),
    ];
}
?>
?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300;400;500;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
/* ============================================================
   PHYSIOTHERAPIST TEMPLATE — --pt-* namespace
   Raleway + Inter
   Palette: clinical white #FAFBFC / teal #1DB8A6 / coral #FF6B6B / navy #1E3A5F / grey #6B7C93
   ============================================================ */

:root {
    --pt-white  : #FAFBFC;
    --pt-teal   : #1DB8A6;
    --pt-coral  : #FF6B6B;
    --pt-navy   : #1E3A5F;
    --pt-grey   : #6B7C93;
    --pt-light  : #EAF6F5;
    --pt-dark   : #0F2037;
    --pt-mid    : #163050;
    --pt-border : rgba(29,184,166,.2);
    --pt-font-h : 'Raleway', sans-serif;
    --pt-font-b : 'Inter', sans-serif;
    --pt-radius : 10px;
    --pt-shadow : 0 4px 24px rgba(0,0,0,.1);
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
.pt-page { font-family: var(--pt-font-b); color: var(--pt-navy); background: var(--pt-white); line-height: 1.6; }
.pt-page h1, .pt-page h2, .pt-page h3, .pt-page h4 { font-family: var(--pt-font-h); font-weight: 700; }
.pt-container { max-width: 1200px; margin: 0 auto; padding: 0 24px; }
.pt-section    { padding: 88px 0; }
.pt-section--dark { background: var(--pt-dark); color: var(--pt-white); }
.pt-section--mid  { background: var(--pt-mid);  color: var(--pt-white); }
.pt-section--light{ background: var(--pt-light); }
.pt-btn {
    display: inline-block; padding: 14px 32px; border-radius: 50px;
    font-family: var(--pt-font-h); font-size: .95rem; font-weight: 700; letter-spacing: .05em;
    text-decoration: none; cursor: pointer; border: none; transition: transform .2s, box-shadow .2s;
}
.pt-btn:hover { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(0,0,0,.18); }
.pt-btn--teal    { background: var(--pt-teal);   color: #fff; }
.pt-btn--outline { background: transparent; border: 2px solid rgba(255,255,255,.6); color: #fff; }
.pt-section-label {
    font-family: var(--pt-font-h); font-size: .78rem; font-weight: 700;
    letter-spacing: .14em; color: var(--pt-teal); text-transform: uppercase; margin-bottom: 10px;
}
.pt-section-title { font-size: clamp(1.9rem, 3.5vw, 2.6rem); margin-bottom: 16px; }
.pt-section-sub   { font-size: 1.02rem; opacity: .7; max-width: 560px; line-height: 1.75; }

/* ---- HERO ---- */
.pt-hero {
    position: relative; min-height: 100vh; overflow: hidden;
    background: linear-gradient(135deg, var(--pt-dark) 0%, var(--pt-navy) 60%, #1A4A6E 100%);
    display: flex; align-items: center;
}
/* floating particles */
.pt-particle {
    position: absolute; border-radius: 50%;
    background: var(--pt-teal); pointer-events: none; opacity: .35;
}
@keyframes pt-drift {
    0%  { transform: translateY(0) scale(1); opacity: .35; }
    50% { transform: translateY(-30px) scale(1.2); opacity: .6; }
    100%{ transform: translateY(0) scale(1); opacity: .35; }
}
.pt-particle { animation: pt-drift var(--pt-pdur,4s) var(--pt-pdelay,0ms) infinite ease-in-out; }

.pt-hero__inner {
    position: relative; z-index: 2;
    display: grid; grid-template-columns: 1fr 440px; gap: 60px; align-items: center;
    max-width: 1200px; margin: 0 auto; padding: 120px 24px 80px; width: 100%;
}
.pt-hero__eyebrow {
    display: inline-flex; align-items: center; gap: 8px;
    background: rgba(29,184,166,.15); border: 1px solid rgba(29,184,166,.35);
    border-radius: 20px; padding: 6px 16px; margin-bottom: 20px;
    font-size: .8rem; font-weight: 600; letter-spacing: .06em; color: var(--pt-teal);
    font-family: var(--pt-font-h);
}
.pt-hero__eyebrow::before {
    content: ''; width: 8px; height: 8px; border-radius: 50%;
    background: var(--pt-teal); box-shadow: 0 0 8px var(--pt-teal);
}
.pt-hero__heading { font-size: clamp(2.4rem,5vw,3.6rem); line-height: 1.1; color: #fff; margin-bottom: 20px; }
.pt-hero__heading em { color: var(--pt-teal); font-style: normal; }
.pt-hero__sub { font-size: 1.08rem; color: rgba(255,255,255,.72); margin-bottom: 32px; line-height: 1.75; }
.pt-hero__cta { display: flex; gap: 16px; flex-wrap: wrap; }

/* ---- BODY DIAGRAM SCENE ---- */
.pt-body-scene {
    position: relative; width: 440px; height: 520px; flex-shrink: 0;
}
/* Glow backdrop */
.pt-body-glow {
    position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%);
    width: 300px; height: 460px; border-radius: 50%;
    background: radial-gradient(ellipse, rgba(29,184,166,.18) 0%, transparent 70%);
    pointer-events: none;
}

/* CSS Human silhouette — head, torso, arms, legs */
.pt-figure { position: absolute; left: 50%; top: 20px; transform: translateX(-50%); }

/* Head */
.pt-fig__head {
    width: 60px; height: 70px; border-radius: 50% 50% 45% 45%;
    background: rgba(255,255,255,.12); border: 2px solid rgba(255,255,255,.25);
    margin: 0 auto;
}
/* Neck */
.pt-fig__neck {
    width: 22px; height: 18px; background: rgba(255,255,255,.1);
    border-left: 2px solid rgba(255,255,255,.2); border-right: 2px solid rgba(255,255,255,.2);
    margin: 0 auto;
}
/* Torso */
.pt-fig__torso {
    width: 100px; height: 140px;
    background: rgba(29,184,166,.12); border: 2px solid rgba(29,184,166,.35);
    border-radius: 10px 10px 14px 14px; margin: 0 auto; position: relative;
}
/* Spine line */
.pt-fig__torso::after {
    content: ''; position: absolute; left: 50%; top: 10px; bottom: 10px; width: 2px;
    background: rgba(29,184,166,.4); transform: translateX(-50%);
}
/* Upper arms */
.pt-fig__upper-arms { display: flex; justify-content: space-between; width: 180px; margin: 0 auto; margin-top: -130px; }
.pt-fig__upper-arm {
    width: 22px; height: 110px;
    background: rgba(255,255,255,.1); border: 2px solid rgba(255,255,255,.2);
    border-radius: 10px;
}
/* Forearms */
.pt-fig__forearms { display: flex; justify-content: space-between; width: 200px; margin: 0 auto; margin-top: 4px; }
.pt-fig__forearm {
    width: 18px; height: 90px;
    background: rgba(255,255,255,.08); border: 2px solid rgba(255,255,255,.15);
    border-radius: 8px;
}
/* Pelvis */
.pt-fig__pelvis {
    width: 110px; height: 40px;
    background: rgba(29,184,166,.1); border: 2px solid rgba(29,184,166,.3);
    border-radius: 0 0 30px 30px; margin: 0 auto; margin-top: 10px;
}
/* Thighs */
.pt-fig__thighs { display: flex; justify-content: center; gap: 12px; margin-top: 2px; }
.pt-fig__thigh {
    width: 34px; height: 120px;
    background: rgba(255,255,255,.1); border: 2px solid rgba(255,255,255,.2);
    border-radius: 10px;
}
/* Shins */
.pt-fig__shins { display: flex; justify-content: center; gap: 20px; margin-top: 4px; }
.pt-fig__shin {
    width: 26px; height: 110px;
    background: rgba(255,255,255,.08); border: 2px solid rgba(255,255,255,.15);
    border-radius: 8px 8px 4px 4px;
}

/* Joint hotspot dots */
.pt-joint {
    position: absolute; transform: translate(-50%, -50%);
    width: 16px; height: 16px; border-radius: 50%;
    background: var(--pt-teal); border: 2px solid rgba(255,255,255,.6);
    cursor: default;
}
.pt-joint::before {
    content: ''; position: absolute; inset: -6px; border-radius: 50%;
    border: 2px solid rgba(29,184,166,.4);
}
@keyframes pt-joint-pulse {
    0%,100%{ box-shadow: 0 0 0 0 rgba(29,184,166,.6); }
    50%     { box-shadow: 0 0 0 8px rgba(29,184,166,0); }
}
.pt-joint { animation: pt-joint-pulse var(--pt-jdur,2s) var(--pt-jdelay,0ms) infinite; }

/* Joint tooltip */
.pt-joint__tip {
    position: absolute; bottom: 120%; left: 50%; transform: translateX(-50%);
    background: var(--pt-teal); color: #fff; border-radius: 4px;
    padding: 3px 8px; font-size: .6rem; font-weight: 600; letter-spacing: .06em;
    white-space: nowrap; pointer-events: none; opacity: 0;
    transition: opacity .2s;
}
.pt-joint:hover .pt-joint__tip { opacity: 1; }
.pt-joint__tip::after {
    content: ''; position: absolute; top: 100%; left: 50%; transform: translateX(-50%);
    border: 5px solid transparent; border-top-color: var(--pt-teal);
}

/* Coral pain indicator (hip area highlight) */
.pt-pain-zone {
    position: absolute;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(255,107,107,.35) 0%, transparent 70%);
    pointer-events: none;
    animation: pt-pain-pulse 2.5s infinite;
}
@keyframes pt-pain-pulse {
    0%,100%{ opacity: .6; transform: translate(-50%,-50%) scale(1); }
    50%     { opacity: 1;  transform: translate(-50%,-50%) scale(1.15); }
}

/* Treatment table at bottom of scene */
.pt-table-wrap {
    position: absolute; bottom: 0; left: 50%; transform: translateX(-50%);
    width: 360px; height: 70px;
}
.pt-table {
    position: absolute; bottom: 0; left: 0; right: 0;
    height: 18px; background: var(--pt-teal);
    border-radius: 6px 6px 0 0; opacity: .8;
}
.pt-table__leg {
    position: absolute; bottom: 18px; width: 10px; height: 30px;
    background: rgba(29,184,166,.5); border-radius: 2px;
}
.pt-table__leg--l { left: 30px; }
.pt-table__leg--r { right: 30px; }
.pt-table__pillow {
    position: absolute; top: -16px; right: 30px;
    width: 60px; height: 18px; background: rgba(255,255,255,.5);
    border-radius: 8px 8px 0 0;
}

/* ---- TRUST BAR ---- */
.pt-trust-bar { background: var(--pt-teal); padding: 14px 0; }
.pt-trust-bar__inner {
    display: flex; align-items: center; justify-content: center;
    gap: 48px; flex-wrap: wrap;
}
.pt-trust-item {
    display: flex; align-items: center; gap: 9px;
    font-family: var(--pt-font-h); font-size: .85rem; font-weight: 700;
    letter-spacing: .04em; color: #fff;
}
.pt-trust-item span { font-size: 1.1rem; }

/* ---- COUNTERS ---- */
.pt-counters { background: var(--pt-navy); padding: 56px 0; }
.pt-counters__grid {
    display: grid; grid-template-columns: repeat(4,1fr); gap: 24px;
    max-width: 1000px; margin: 0 auto; padding: 0 24px;
}
.pt-counter-card {
    text-align: center; padding: 32px 16px;
    background: rgba(255,255,255,.05); border: 1px solid var(--pt-border);
    border-radius: var(--pt-radius);
}
.pt-counter-card__val {
    font-family: var(--pt-font-h); font-size: 2.8rem; font-weight: 800;
    color: var(--pt-teal); line-height: 1.1;
    display: flex; align-items: baseline; justify-content: center; gap: 2px;
}
.pt-counter-card__suffix { font-size: 1.4rem; }
.pt-counter-card__label  { font-size: .85rem; color: rgba(255,255,255,.6); margin-top: 6px; letter-spacing: .03em; }

/* ---- SERVICES ---- */
.pt-services-grid {
    display: grid; grid-template-columns: repeat(auto-fill,minmax(260px,1fr)); gap: 24px;
    margin-top: 48px;
}
.pt-service-card {
    background: #fff; border: 1px solid rgba(0,0,0,.07);
    border-radius: var(--pt-radius); padding: 28px; position: relative;
    transition: transform .25s, box-shadow .25s; overflow: hidden;
}
.pt-service-card::before {
    content: ''; position: absolute; inset: 0 0 auto 0;
    height: 4px; background: linear-gradient(90deg, var(--pt-teal), #0DCABA);
}
.pt-service-card:hover { transform: translateY(-4px); box-shadow: 0 12px 32px rgba(0,0,0,.1); }
.pt-service-card__icon  { font-size: 2.2rem; margin-bottom: 14px; }
.pt-service-card__title { font-size: 1rem; margin-bottom: 10px; }
.pt-service-card__desc  { font-size: .87rem; color: #666; line-height: 1.65; }

/* ---- CONDITIONS CLOUD ---- */
.pt-conditions { background: var(--pt-dark); }
.pt-tags-cloud  { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 32px; }
.pt-tag {
    background: rgba(29,184,166,.1); border: 1px solid rgba(29,184,166,.25);
    color: rgba(255,255,255,.8); border-radius: 20px;
    padding: 6px 14px; font-size: .82rem; transition: background .2s, color .2s;
}
.pt-tag:hover { background: rgba(29,184,166,.25); color: var(--pt-teal); }

/* ---- PROCESS ---- */
.pt-process { background: var(--pt-mid); }
.pt-process__steps {
    position: relative; margin-top: 56px;
    display: grid; grid-template-columns: repeat(5,1fr); gap: 0;
}
.pt-process__steps::before {
    content: ''; position: absolute; top: 28px; left: 10%; right: 10%; height: 3px;
    background: linear-gradient(90deg, var(--pt-teal), var(--pt-coral), var(--pt-teal));
    z-index: 0;
}
.pt-step { text-align: center; position: relative; z-index: 1; padding: 0 12px; }
.pt-step__num {
    width: 56px; height: 56px; border-radius: 50%; margin: 0 auto 20px;
    display: flex; align-items: center; justify-content: center;
    font-family: var(--pt-font-h); font-size: 1.1rem; font-weight: 800;
    background: var(--pt-mid); border: 3px solid var(--pt-teal); color: var(--pt-teal);
    box-shadow: 0 0 16px rgba(29,184,166,.3);
}
.pt-step__title { font-family: var(--pt-font-h); font-size: .88rem; font-weight: 700; color: var(--pt-white); margin-bottom: 8px; }
.pt-step__desc  { font-size: .78rem; color: rgba(255,255,255,.55); line-height: 1.6; }

/* ---- THERAPIST CREDENTIAL ---- */
.pt-therapist-section { background: var(--pt-dark); }
.pt-therapist-wrap { display: grid; grid-template-columns: 300px 1fr; gap: 56px; align-items: center; }
/* CSS therapist figure */
.pt-therapist-figure { position: relative; height: 260px; }
.pt-th__body {
    position: absolute; bottom: 0; left: 50%; transform: translateX(-50%);
    width: 72px; height: 120px;
    background: var(--pt-teal); border-radius: 8px 8px 4px 4px;
}
/* White coat */
.pt-th__body::before {
    content: ''; position: absolute; top: 0; left: -8px; right: -8px; height: 80px;
    background: rgba(255,255,255,.9); border-radius: 6px 6px 0 0;
    border-bottom: 3px solid var(--pt-teal);
}
/* Stethoscope icon on coat */
.pt-th__body::after {
    content: '🩺'; position: absolute; top: 20px; left: 50%; transform: translateX(-50%);
    font-size: .9rem; z-index: 1;
}
.pt-th__legs {
    position: absolute; bottom: 0; left: 50%; transform: translateX(-50%);
    display: flex; gap: 8px;
}
.pt-th__leg {
    width: 26px; height: 55px;
    background: var(--pt-navy); border-radius: 0 0 4px 4px;
}
.pt-th__head {
    position: absolute; bottom: 118px; left: 50%; transform: translateX(-50%);
    width: 44px; height: 44px;
    background: #C9956A; border-radius: 50%;
}
/* Hair */
.pt-th__head::before {
    content: ''; position: absolute; top: -6px; left: -4px; right: -4px; height: 20px;
    background: #5B3A29; border-radius: 50% 50% 0 0;
}
.pt-th__arms { }
.pt-th__arm {
    position: absolute; bottom: 68px;
    width: 16px; height: 65px;
    background: rgba(255,255,255,.85); border-radius: 6px;
}
.pt-th__arm--l { left: calc(50% - 52px); transform: rotate(10deg); transform-origin: top; }
.pt-th__arm--r { right: calc(50% - 52px); transform: rotate(-20deg); transform-origin: top; }

.pt-therapist-info h3 { font-size: 1.8rem; color: var(--pt-white); margin-bottom: 4px; }
.pt-therapist-info h4 { font-size: .9rem; color: var(--pt-teal); font-family: var(--pt-font-h); letter-spacing: .06em; margin-bottom: 20px; font-weight: 600; }
.pt-therapist-info p  { color: rgba(255,255,255,.72); line-height: 1.75; margin-bottom: 20px; }
.pt-therapist-badges  { display: flex; flex-wrap: wrap; gap: 10px; }
.pt-badge {
    display: inline-flex; align-items: center; gap: 6px;
    background: rgba(29,184,166,.12); border: 1px solid rgba(29,184,166,.3);
    border-radius: 20px; padding: 6px 14px;
    font-size: .78rem; font-weight: 700; font-family: var(--pt-font-h);
    letter-spacing: .04em; color: var(--pt-teal);
}

/* ---- PACKAGES ---- */
.pt-packages-grid {
    display: grid; grid-template-columns: repeat(3,1fr); gap: 24px;
    margin-top: 48px; align-items: start;
}
.pt-package {
    background: #fff; border: 2px solid rgba(0,0,0,.07);
    border-radius: var(--pt-radius); padding: 32px; position: relative;
}
.pt-package--featured {
    background: var(--pt-navy); border-color: var(--pt-teal);
    box-shadow: 0 0 32px rgba(29,184,166,.2); transform: scale(1.03);
}
.pt-package__badge {
    position: absolute; top: -14px; left: 50%; transform: translateX(-50%);
    background: var(--pt-teal); color: #fff;
    font-family: var(--pt-font-h); font-size: .72rem; font-weight: 700;
    letter-spacing: .1em; padding: 4px 16px; border-radius: 20px; white-space: nowrap;
}
.pt-package__name  { font-size: 1.1rem; margin-bottom: 6px; }
.pt-package--featured .pt-package__name { color: var(--pt-white); }
.pt-package__price {
    font-family: var(--pt-font-h); font-size: 2.2rem; font-weight: 800;
    color: var(--pt-teal); margin: 12px 0 4px;
}
.pt-package__period { font-size: .78rem; color: var(--pt-grey); margin-bottom: 20px; }
.pt-package--featured .pt-package__period { color: rgba(255,255,255,.5); }
.pt-package__items { list-style: none; margin-bottom: 28px; }
.pt-package__items li {
    padding: 7px 0; font-size: .88rem; border-bottom: 1px solid rgba(0,0,0,.06);
    display: flex; gap: 8px; align-items: flex-start;
}
.pt-package--featured .pt-package__items li { border-color: rgba(255,255,255,.08); color: rgba(255,255,255,.82); }
.pt-package__items li::before { content: '✓'; color: var(--pt-teal); font-weight: 700; flex-shrink: 0; }
.pt-package__cta { display: block; text-align: center; }

/* ---- TESTIMONIALS ---- */
.pt-testi-grid {
    display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; margin-top: 48px;
}
.pt-testi {
    background: #fff; border: 1px solid rgba(0,0,0,.07);
    border-radius: var(--pt-radius); padding: 28px;
}
.pt-testi__quote { font-size: 2.8rem; line-height: 1; color: var(--pt-teal); opacity: .4; margin-bottom: 6px; }
.pt-testi__stars { color: #F5A623; margin-bottom: 10px; }
.pt-testi__text  { font-size: .88rem; color: #555; line-height: 1.7; margin-bottom: 18px; }
.pt-testi__name  { font-weight: 700; font-size: .88rem; color: var(--pt-navy); }
.pt-testi__role  { font-size: .78rem; color: var(--pt-grey); }

/* ---- BOOKING ---- */
.pt-booking { background: var(--pt-dark); }
.pt-booking__wrap {
    display: grid; grid-template-columns: 1fr 1fr; gap: 56px; align-items: start;
}
.pt-booking__info h2 { color: var(--pt-white); margin-bottom: 16px; }
.pt-booking__info p  { color: rgba(255,255,255,.68); line-height: 1.75; margin-bottom: 24px; }
.pt-booking__bullets { list-style: none; }
.pt-booking__bullets li {
    padding: 10px 0; border-bottom: 1px solid rgba(255,255,255,.08);
    color: rgba(255,255,255,.78); font-size: .9rem;
    display: flex; gap: 10px; align-items: flex-start;
}
.pt-booking__bullets li::before { content: '🩺'; flex-shrink: 0; }

.pt-form {
    background: var(--pt-mid); border: 1px solid rgba(29,184,166,.2);
    border-radius: var(--pt-radius); padding: 36px;
}
.pt-form h3 { color: var(--pt-white); font-size: 1.35rem; margin-bottom: 24px; }
.pt-field    { margin-bottom: 18px; }
.pt-field label {
    display: block; font-size: .8rem; font-weight: 600; letter-spacing: .05em;
    color: rgba(255,255,255,.65); margin-bottom: 6px; text-transform: uppercase;
    font-family: var(--pt-font-h);
}
.pt-field input,
.pt-field select,
.pt-field textarea {
    width: 100%; padding: 11px 14px; border-radius: var(--pt-radius);
    background: var(--pt-dark); border: 1px solid rgba(29,184,166,.2);
    color: var(--pt-white); font-family: var(--pt-font-b); font-size: .92rem;
    outline: none; transition: border-color .2s;
}
.pt-field input:focus,
.pt-field select:focus,
.pt-field textarea:focus { border-color: var(--pt-teal); }
.pt-field textarea { resize: vertical; min-height: 100px; }
.pt-field select option { background: var(--pt-dark); }
.pt-field-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.pt-form__submit {
    width: 100%; padding: 15px; background: var(--pt-teal); color: #fff;
    border: none; border-radius: 50px; font-family: var(--pt-font-h);
    font-size: 1rem; font-weight: 700; letter-spacing: .06em; cursor: pointer;
    transition: filter .2s, transform .2s;
}
.pt-form__submit:hover { filter: brightness(1.1); transform: translateY(-1px); }

/* ---- FOOTER ---- */
.pt-footer {
    background: var(--pt-dark); padding: 40px 0; text-align: center;
    border-top: 1px solid rgba(255,255,255,.06);
}
.pt-footer p { font-size: .82rem; color: rgba(255,255,255,.4); margin-bottom: 4px; }
.pt-footer__phone {
    font-family: var(--pt-font-h); font-size: 1.6rem; color: var(--pt-teal);
    margin-bottom: 8px; letter-spacing: .03em;
}

/* ---- RESPONSIVE ---- */
@media (max-width: 900px) {
    .pt-hero__inner       { grid-template-columns: 1fr; padding-top: 100px; }
    .pt-body-scene        { width: 100%; height: 340px; }
    .pt-counters__grid    { grid-template-columns: repeat(2,1fr); }
    .pt-process__steps    { grid-template-columns: 1fr; gap: 32px; }
    .pt-process__steps::before { display: none; }
    .pt-therapist-wrap    { grid-template-columns: 1fr; }
    .pt-therapist-figure  { height: 200px; margin: 0 auto 32px; }
    .pt-packages-grid     { grid-template-columns: 1fr; }
    .pt-package--featured { transform: none; }
    .pt-testi-grid        { grid-template-columns: 1fr; }
    .pt-booking__wrap     { grid-template-columns: 1fr; }
}
</style>
<?php get_header(); ?>

<div class="">

>

<!-- ═══════════════════════════════════════════════════════
     HERO — Human Body Diagram with Joint Hotspots
     ═══════════════════════════════════════════════════════ -->
<section class="pt-hero" aria-label="Hero">

    <!-- Floating particles -->
    <?php foreach ( $pt_particles as $pp ) : ?>
        <div class="pt-particle" aria-hidden="true" style="
            left:<?php echo esc_attr($pp['x']); ?>%;
            top:<?php echo esc_attr($pp['y']); ?>%;
            width:<?php echo esc_attr($pp['size']); ?>px;
            height:<?php echo esc_attr($pp['size']); ?>px;
            --pt-pdur:<?php echo esc_attr($pp['dur']); ?>ms;
            --pt-pdelay:<?php echo esc_attr($pp['delay']); ?>ms;
        "></div>
    <?php endforeach; ?>

    <div class="pt-hero__inner">
        <!-- Text -->
        <div>
            <div class="pt-hero__eyebrow">CSP Registered Physiotherapists</div>
            <h1 class="pt-hero__heading">
                Expert Care<br>For Your<br><em>Recovery</em>
            </h1>
            <p class="pt-hero__sub">Evidence-based physiotherapy for musculoskeletal pain, sports injuries and post-surgical rehabilitation. Back to living the life you love — faster.</p>
            <div class="pt-hero__cta">
                <a href="#booking" class="pt-btn pt-btn--teal">Book Assessment</a>
                <a href="tel:+441234567890" class="pt-btn pt-btn--outline">📞 Call the Clinic</a>
            </div>
        </div>

        <!-- Body diagram scene -->
        <div class="pt-body-scene" aria-hidden="true">
            <div class="pt-body-glow"></div>

            <!-- CSS figure -->
            <div class="pt-figure">
                <div class="pt-fig__head"></div>
                <div class="pt-fig__neck"></div>
                <div class="pt-fig__upper-arms">
                    <div class="pt-fig__upper-arm"></div>
                    <div class="pt-fig__upper-arm"></div>
                </div>
                <div class="pt-fig__torso"></div>
                <div class="pt-fig__forearms">
                    <div class="pt-fig__forearm"></div>
                    <div class="pt-fig__forearm"></div>
                </div>
                <div class="pt-fig__pelvis"></div>
                <div class="pt-fig__thighs">
                    <div class="pt-fig__thigh"></div>
                    <div class="pt-fig__thigh"></div>
                </div>
                <div class="pt-fig__shins">
                    <div class="pt-fig__shin"></div>
                    <div class="pt-fig__shin"></div>
                </div>
            </div>

            <!-- Joint hotspot markers -->
            <?php foreach ( $pt_joints as $jt ) : ?>
                <div class="pt-joint" style="
                    left:<?php echo esc_attr($jt['x']); ?>%;
                    top:<?php echo esc_attr($jt['y']); ?>%;
                    --pt-jdur:<?php echo rand(1600,2800); ?>ms;
                    --pt-jdelay:<?php echo esc_attr($jt['delay']); ?>ms;
                ">
                    <span class="pt-joint__tip"><?php echo esc_html($jt['label']); ?></span>
                </div>
            <?php endforeach; ?>

            <!-- Pain zone highlight (lower back) -->
            <div class="pt-pain-zone" style="left:50%;top:32%;width:80px;height:80px;"></div>

            <!-- Treatment table -->
            <div class="pt-table-wrap">
                <div class="pt-table__leg pt-table__leg--l"></div>
                <div class="pt-table__leg pt-table__leg--r"></div>
                <div class="pt-table">
                    <div class="pt-table__pillow"></div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     TRUST BAR
     ═══════════════════════════════════════════════════════ -->
<div class="pt-trust-bar" role="complementary">
    <div class="pt-trust-bar__inner pt-container">
        <div class="pt-trust-item"><span>🏅</span> CSP Registered</div>
        <div class="pt-trust-item"><span>🩺</span> HCPC Regulated</div>
        <div class="pt-trust-item"><span>📋</span> MSK Specialists</div>
        <div class="pt-trust-item"><span>⚡</span> Same-Week Appointments</div>
        <div class="pt-trust-item"><span>🛡️</span> Fully Insured</div>
    </div>
</div>

<!-- ═══════════════════════════════════════════════════════
     COUNTERS
     ═══════════════════════════════════════════════════════ -->
<section class="pt-counters" aria-label="Key figures">
    <div class="pt-counters__grid">
        <?php foreach ( $pt_counters as $ctr ) : ?>
            <div class="pt-counter-card">
                <div class="pt-counter-card__val">
                    <span class="pt-counter-num"
                          data-target="<?php echo esc_attr($ctr['value']); ?>"
                          data-suffix="<?php echo esc_attr($ctr['suffix']); ?>"
                          <?php if($ctr['float']) echo 'data-float="1"'; ?>>0</span>
                    <span class="pt-counter-card__suffix"><?php echo esc_html($ctr['suffix']); ?></span>
                </div>
                <div class="pt-counter-card__label"><?php echo esc_html($ctr['label']); ?></div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     SERVICES
     ═══════════════════════════════════════════════════════ -->
<section class="pt-section" aria-labelledby="pt-services-title">
    <div class="pt-container">
        <div class="pt-section-label">What We Treat</div>
        <h2 class="pt-section-title" id="pt-services-title">Our Physiotherapy Services</h2>
        <p class="pt-section-sub">Specialist assessment and treatment across the full spectrum of physiotherapy — from acute sports injuries to complex neurological conditions.</p>
        <div class="pt-services-grid">
            <?php foreach ( $pt_services as $svc ) : ?>
                <div class="pt-service-card">
                    <div class="pt-service-card__icon"><?php echo esc_html($svc['icon']); ?></div>
                    <h3 class="pt-service-card__title"><?php echo esc_html($svc['title']); ?></h3>
                    <p class="pt-service-card__desc"><?php echo esc_html($svc['desc']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     CONDITIONS CLOUD
     ═══════════════════════════════════════════════════════ -->
<section class="pt-section pt-conditions" aria-labelledby="pt-conditions-title">
    <div class="pt-container">
        <div class="pt-section-label" style="color:var(--pt-teal);">We Treat</div>
        <h2 class="pt-section-title" id="pt-conditions-title" style="color:var(--pt-white);">Conditions We Specialise In</h2>
        <p class="pt-section-sub" style="color:rgba(255,255,255,.6);">Our physiotherapists have experience treating a wide range of musculoskeletal, neurological and sports-related conditions.</p>
        <div class="pt-tags-cloud" role="list">
            <?php foreach ( $pt_conditions as $cond ) : ?>
                <span class="pt-tag" role="listitem"><?php echo esc_html($cond); ?></span>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     PROCESS
     ═══════════════════════════════════════════════════════ -->
<section class="pt-section pt-process" aria-labelledby="pt-process-title">
    <div class="pt-container">
        <div class="pt-section-label" style="color:var(--pt-teal);">Your Journey</div>
        <h2 class="pt-section-title" id="pt-process-title" style="color:var(--pt-white);">From Assessment to Recovery</h2>
        <p class="pt-section-sub" style="color:rgba(255,255,255,.6);">A clear, patient-centred pathway from your very first appointment to confident self-management.</p>
        <div class="pt-process__steps">
            <?php foreach ( $pt_process as $ps ) : ?>
                <div class="pt-step">
                    <div class="pt-step__num"><?php echo esc_html($ps['step']); ?></div>
                    <div class="pt-step__title"><?php echo esc_html($ps['title']); ?></div>
                    <p class="pt-step__desc"><?php echo esc_html($ps['desc']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     LEAD THERAPIST CREDENTIAL
     ═══════════════════════════════════════════════════════ -->
<section class="pt-section pt-therapist-section" aria-labelledby="pt-therapist-title">
    <div class="pt-container">
        <div class="pt-therapist-wrap">
            <!-- CSS therapist figure -->
            <div class="pt-therapist-figure" aria-hidden="true">
                <div class="pt-th__arm pt-th__arm--l"></div>
                <div class="pt-th__arm pt-th__arm--r"></div>
                <div class="pt-th__body"></div>
                <div class="pt-th__legs">
                    <div class="pt-th__leg"></div>
                    <div class="pt-th__leg"></div>
                </div>
                <div class="pt-th__head"></div>
            </div>
            <!-- Info -->
            <div class="pt-therapist-info">
                <div class="pt-section-label">Clinical Lead</div>
                <h3 id="pt-therapist-title">Dr. Rachel Sutton</h3>
                <h4>BSc (Hons) Physiotherapy · MSc Sports Medicine · HCPC Registered · MCSP</h4>
                <p>
                    Rachel leads our clinical team with <?php echo date('Y') - 2006; ?> years of experience spanning professional sport, orthopaedic surgery rehabilitation and NHS musculoskeletal services. She completed her MSc at UCL and regularly presents at national physiotherapy conferences.
                </p>
                <p>
                    Our team of six physiotherapists all hold CSP membership, HCPC registration and carry full professional indemnity insurance. We operate an open referral policy — no GP letter required.
                </p>
                <div class="pt-therapist-badges">
                    <span class="pt-badge">🏅 HCPC Registered</span>
                    <span class="pt-badge">🩺 MCSP</span>
                    <span class="pt-badge">📋 MSc Sports Medicine</span>
                    <span class="pt-badge">🧠 Dry Needling Certified</span>
                    <span class="pt-badge">⚡ Shockwave Therapy</span>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     PACKAGES
     ═══════════════════════════════════════════════════════ -->
<section class="pt-section pt-section--light" aria-labelledby="pt-packages-title">
    <div class="pt-container">
        <div class="pt-section-label">Pricing</div>
        <h2 class="pt-section-title" id="pt-packages-title">Treatment Packages</h2>
        <p class="pt-section-sub">Transparent pricing with no hidden extras. All sessions conducted by a qualified, HCPC-registered physiotherapist.</p>
        <div class="pt-packages-grid">
            <?php foreach ( $pt_packages as $pkg ) : ?>
                <div class="pt-package <?php echo $pkg['featured'] ? 'pt-package--featured' : ''; ?>">
                    <?php if ( $pkg['featured'] ) : ?>
                        <div class="pt-package__badge">MOST POPULAR</div>
                    <?php endif; ?>
                    <h3 class="pt-package__name"><?php echo esc_html($pkg['name']); ?></h3>
                    <div class="pt-package__price"><?php echo esc_html($pkg['price']); ?></div>
                    <div class="pt-package__period"><?php echo esc_html($pkg['period']); ?></div>
                    <ul class="pt-package__items">
                        <?php foreach ( $pkg['items'] as $item ) : ?>
                            <li><?php echo esc_html($item); ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <a href="#booking" class="pt-btn pt-btn--teal pt-package__cta">Book This Package</a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     TESTIMONIALS
     ═══════════════════════════════════════════════════════ -->
<section class="pt-section" aria-labelledby="pt-testi-title">
    <div class="pt-container">
        <div class="pt-section-label">Patient Reviews</div>
        <h2 class="pt-section-title" id="pt-testi-title">Real Results, Real People</h2>
        <p class="pt-section-sub">Thousands of patients have trusted us to help them recover, rehabilitate and return to the activities they love.</p>
        <div class="pt-testi-grid">
            <?php foreach ( $pt_testimonials as $t ) : ?>
                <blockquote class="pt-testi">
                    <div class="pt-testi__quote" aria-hidden="true">❝</div>
                    <div class="pt-testi__stars" aria-label="5 stars">★★★★★</div>
                    <p class="pt-testi__text"><?php echo esc_html($t['text']); ?></p>
                    <footer>
                        <div class="pt-testi__name"><?php echo esc_html($t['name']); ?></div>
                        <div class="pt-testi__role"><?php echo esc_html($t['role']); ?></div>
                    </footer>
                </blockquote>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     BOOKING FORM
     ═══════════════════════════════════════════════════════ -->
<section class="pt-section pt-booking" id="booking" aria-labelledby="pt-booking-title">
    <div class="pt-container">
        <div class="pt-booking__wrap">
            <div class="pt-booking__info">
                <div class="pt-section-label" style="color:var(--pt-teal);">Book an Appointment</div>
                <h2 id="pt-booking-title" style="color:var(--pt-white);">Start Your Recovery Today</h2>
                <p>Fill in your details and we'll contact you within 24 hours to confirm your appointment. No GP referral needed — just call or complete the form.</p>
                <ul class="pt-booking__bullets">
                    <li>No GP referral required — direct access</li>
                    <li>Appointments available within 48–72 hours</li>
                    <li>Evening and weekend slots available</li>
                    <li>Home visits available on request</li>
                    <li>Online video physiotherapy also available</li>
                    <li>Most private health insurers accepted</li>
                </ul>
            </div>
            <div class="pt-form">
                <h3>Request an Appointment</h3>
                <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" novalidate>
                    <?php wp_nonce_field( 'tf_pt_booking', 'tf_pt_nonce' ); ?>
                    <input type="hidden" name="action" value="tf_pt_booking">

                    <div class="pt-field-row">
                        <div class="pt-field">
                            <label for="pt-name">Full Name *</label>
                            <input type="text" id="pt-name" name="pt_name" required placeholder="Jane Smith">
                        </div>
                        <div class="pt-field">
                            <label for="pt-dob">Date of Birth</label>
                            <input type="date" id="pt-dob" name="pt_dob">
                        </div>
                    </div>

                    <div class="pt-field-row">
                        <div class="pt-field">
                            <label for="pt-phone">Phone *</label>
                            <input type="tel" id="pt-phone" name="pt_phone" required placeholder="07700 900123">
                        </div>
                        <div class="pt-field">
                            <label for="pt-email">Email *</label>
                            <input type="email" id="pt-email" name="pt_email" required placeholder="jane@example.com">
                        </div>
                    </div>

                    <div class="pt-field">
                        <label for="pt-condition">Area of Concern *</label>
                        <select id="pt-condition" name="pt_condition" required>
                            <option value="">— Select body area / condition —</option>
                            <option value="back">Back / Spine</option>
                            <option value="neck">Neck / Shoulder</option>
                            <option value="knee">Knee</option>
                            <option value="hip">Hip</option>
                            <option value="ankle-foot">Ankle / Foot</option>
                            <option value="elbow-wrist">Elbow / Wrist / Hand</option>
                            <option value="sports">Sports Injury</option>
                            <option value="post-op">Post-Surgical Rehab</option>
                            <option value="neuro">Neurological</option>
                            <option value="other">Other / Not Sure</option>
                        </select>
                    </div>

                    <div class="pt-field-row">
                        <div class="pt-field">
                            <label for="pt-duration">How Long?</label>
                            <select id="pt-duration" name="pt_duration">
                                <option value="acute">Less than 2 weeks</option>
                                <option value="subacute">2–6 weeks</option>
                                <option value="chronic" selected>More than 6 weeks</option>
                                <option value="recurring">Recurring problem</option>
                            </select>
                        </div>
                        <div class="pt-field">
                            <label for="pt-insurance">Private Insurance?</label>
                            <select id="pt-insurance" name="pt_insurance">
                                <option value="self-pay">Self-pay</option>
                                <option value="axa">AXA Health</option>
                                <option value="bupa">BUPA</option>
                                <option value="aviva">Aviva</option>
                                <option value="vhi">VHI</option>
                                <option value="other">Other Insurer</option>
                            </select>
                        </div>
                    </div>

                    <div class="pt-field">
                        <label for="pt-notes">Brief Description of Symptoms</label>
                        <textarea id="pt-notes" name="pt_notes" placeholder="Please describe your pain, when it started, what makes it better or worse..."></textarea>
                    </div>

                    <button type="submit" class="pt-form__submit">🩺 Book My Assessment</button>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     FOOTER
     ═══════════════════════════════════════════════════════ -->
<footer class="pt-footer" role="contentinfo">
    <div class="pt-container">
        <p>Sutton Physiotherapy Clinic &nbsp;·&nbsp; HCPC Registered &nbsp;·&nbsp; CSP Members</p>
        <div class="pt-footer__phone">📞 01234 567 890</div>
        <p><?php echo esc_html( get_bloginfo('name') ); ?> &copy; <?php echo date('Y'); ?> &nbsp;·&nbsp; All physiotherapists are HCPC registered and hold full professional indemnity insurance</p>
    </div>
</footer>

<script>
(function(){
    'use strict';
    var easeOut = function(t){ return 1 - Math.pow(1-t,3); };
    var counters = document.querySelectorAll('.pt-counter-num');
    if(!counters.length) return;
    var observer = new IntersectionObserver(function(entries){
        entries.forEach(function(entry){
            if(!entry.isIntersecting) return;
            observer.unobserve(entry.target);
            var el = entry.target;
            var target = parseFloat(el.dataset.target);
            var isFloat = el.dataset.float === '1';
            if(isNaN(target)) return;
            var start = null, dur = 1800;
            function tick(ts){
                if(!start) start = ts;
                var prog = Math.min((ts-start)/dur,1);
                var val = easeOut(prog)*target;
                el.textContent = isFloat ? val.toFixed(1) : Math.floor(val).toLocaleString();
                if(prog<1) requestAnimationFrame(tick);
                else el.textContent = isFloat ? target.toFixed(1) : target.toLocaleString();
            }
            requestAnimationFrame(tick);
        });
    }, {threshold:0.3});
    counters.forEach(function(c){ observer.observe(c); });
})();
</script>

</div><!-- . -->

<?php get_footer(); ?>
