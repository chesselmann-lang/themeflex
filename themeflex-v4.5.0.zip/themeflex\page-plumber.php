<?php
/**
 * Template Name: Plumber
 * Description: Premium page template for Plumber / Plumbing & Heating Services
 *
 * @package ThemeFlex
 */

// Fonts: Exo 2 + Source Sans 3
// Namespace: --pl-*
// Hero: CSS isometric pipe network scene — pipes, valves, water droplets, boiler unit, pressure gauge
// Palette: deep slate #1C2B3A / aqua blue #00A8CC / pipe copper #B87333 / arctic white #F0F8FF / warm red #C0392B

if ( ! defined( 'ABSPATH' ) ) exit;
srand( crc32( get_the_permalink() ) );

$pl_services = [
    [ 'icon' => '🔧', 'title' => 'Boiler Installation',         'desc' => 'Supply and fit of Worcester Bosch, Vaillant and Baxi combi, system and regular boilers — Gas Safe registered engineers.' ],
    [ 'icon' => '🚿', 'title' => 'Bathroom Installation',       'desc' => 'Full suite installations, wet rooms, showers and en-suites. Supply-only or supply-and-fit — your choice.' ],
    [ 'icon' => '💧', 'title' => 'Leak Detection & Repair',     'desc' => 'Pinpoint leak detection using acoustic sensors and thermal imaging. No unnecessary excavation.' ],
    [ 'icon' => '🏠', 'title' => 'Central Heating',             'desc' => 'Full system installs, power flushes, radiator replacements and thermostatic radiator valve upgrades.' ],
    [ 'icon' => '🚰', 'title' => 'Emergency Call-Out',          'desc' => '24/7 emergency plumbing. Burst pipes, no hot water, blocked drains, overflowing toilets — we respond fast.' ],
    [ 'icon' => '🔥', 'title' => 'Gas Appliances',              'desc' => 'Gas cooker connections, gas fires, hob installations and annual gas safety inspections (CP12 certificates).' ],
    [ 'icon' => '♻️', 'title' => 'Underfloor Heating',          'desc' => 'Wet and dry underfloor heating systems for new builds, extensions and retrofit applications.' ],
    [ 'icon' => '🛁', 'title' => 'Unvented Hot Water',          'desc' => 'Megaflo and unvented cylinder installation, commissioning and annual servicing — G3-qualified engineers.' ],
];

$pl_scenarios = [
    'Burst pipe', 'No heating', 'No hot water', 'Leaking tap', 'Blocked drain',
    'Overflowing toilet', 'Dripping radiator', 'Boiler breakdown', 'Cold spots on radiator',
    'Low water pressure', 'Noisy pipes', 'Cylinder replacement', 'Annual boiler service',
    'Landlord gas safety check', 'Outside tap installation', 'Dishwasher connection',
    'Washing machine plumbing', 'Bathroom refit', 'Power flush', 'Thermostatic valve',
    'Underfloor heating fault', 'Water softener install',
];

$pl_process = [
    [ 'step' => '01', 'title' => 'Free Estimate',     'desc' => 'Call or book online for a free no-obligation estimate. We visit, assess and provide a written fixed-price quote.' ],
    [ 'step' => '02', 'title' => 'Schedule Job',      'desc' => 'Choose a slot that suits you — including same-day for emergencies. We text you when we\'re 30 minutes away.' ],
    [ 'step' => '03', 'title' => 'Diagnosis',         'desc' => 'Our engineer diagnoses the root cause of the problem, not just the symptom — preventing repeat call-outs.' ],
    [ 'step' => '04', 'title' => 'Clean Work',        'desc' => 'We use dust sheets, shoe covers and tidy as we go. Your home is left cleaner than we found it.' ],
    [ 'step' => '05', 'title' => 'Signed Off',        'desc' => 'All gas work issued with Gas Safe documentation. All plumbing checked for leaks before we leave. 12-month guarantee.' ],
];

$pl_testimonials = [
    [ 'name' => 'Karen Blythe',   'role' => 'Homeowner · Nottingham',   'text' => 'Boiler packed in on the coldest night of the year. Called at 9pm and they had a new combi fitted the next morning. Brilliant service — tidy workers and very fairly priced.' ],
    [ 'name' => 'Raj Patel',      'role' => 'Landlord · Birmingham',    'text' => 'Manage 14 properties so reliable plumbers are gold dust. These are the best I\'ve used in 15 years. Always Gas Safe certified, great with tenants and the reports arrive same day.' ],
    [ 'name' => 'Chloe Thornton', 'role' => 'New Build Owner · Leeds',  'text' => 'Had a completely new bathroom installed including wet room shower. The tiling is immaculate, everything drains perfectly and they were at least 20% cheaper than two other quotes.' ],
];

$pl_packages = [
    [
        'name'     => 'Boiler Service',
        'price'    => '£85',
        'period'   => 'annual service',
        'featured' => false,
        'items'    => [ 'Full safety inspection', 'Flue gas analysis', 'Burner & heat exchanger check', 'Controls test', 'Gas Safe certificate issued', 'Service sticker & report' ],
    ],
    [
        'name'     => 'Boiler Replacement',
        'price'    => '£1,850',
        'period'   => 'avg. combi swap',
        'featured' => true,
        'items'    => [ 'Worcester Bosch / Vaillant combi', 'Full installation & commissioning', 'Removal of old boiler', 'New controls & programmer', 'Gas Safe registration', '10-yr manufacturer warranty', '2-yr labour guarantee' ],
    ],
    [
        'name'     => 'HomeCare Plan',
        'price'    => '£19/mo',
        'period'   => 'annual contract',
        'featured' => false,
        'items'    => [ 'Annual boiler service', 'Priority emergency callout', 'Parts & labour covered', 'Plumbing emergencies included', 'No excess on claims', '24/7 helpline access' ],
    ],
];

$pl_counters = [
    [ 'value' => 19,    'suffix' => 'yrs',  'label' => 'Trading',           'float' => false ],
    [ 'value' => 11000, 'suffix' => '+',    'label' => 'Jobs Completed',    'float' => false ],
    [ 'value' => 4.9,   'suffix' => '★',   'label' => 'Google Rating',     'float' => true  ],
    [ 'value' => 100,   'suffix' => '%',    'label' => 'Gas Safe Certified','float' => false ],
];

// Pipe segments for hero scene
$pl_pipes = [];
// Horizontal pipes
for ( $i = 0; $i < 8; $i++ ) {
    $pl_pipes[] = [
        'x'   => rand( 2, 55 ),
        'y'   => rand( 8, 88 ),
        'w'   => rand( 60, 180 ),
        'dir' => 'h',
        'col' => [ 'copper', 'blue', 'grey' ][ rand(0,2) ],
    ];
}
// Vertical pipes
for ( $i = 0; $i < 6; $i++ ) {
    $pl_pipes[] = [
        'x'   => rand( 5, 90 ),
        'y'   => rand( 5, 55 ),
        'h'   => rand( 60, 160 ),
        'dir' => 'v',
        'col' => [ 'copper', 'blue', 'grey' ][ rand(0,2) ],
    ];
}

// Water droplets
$pl_drops = [];
for ( $i = 0; $i < 18; $i++ ) {
    $pl_drops[] = [
        'x'     => rand( 0, 100 ),
        'y'     => rand( 0, 100 ),
        'size'  => rand( 4, 10 ),
        'dur'   => rand( 2500, 5500 ),
        'delay' => rand( 0, 4000 ),
    ];
}
?>
?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;500;600;700;800&family=Source+Sans+3:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
/* ============================================================
   PLUMBER TEMPLATE — --pl-* namespace
   Exo 2 + Source Sans 3
   Palette: slate #1C2B3A / aqua #00A8CC / copper #B87333 / white #F0F8FF / red #C0392B
   ============================================================ */

:root {
    --pl-slate  : #1C2B3A;
    --pl-aqua   : #00A8CC;
    --pl-copper : #B87333;
    --pl-white  : #F0F8FF;
    --pl-red    : #C0392B;
    --pl-dark   : #0F1B26;
    --pl-mid    : #162332;
    --pl-muted  : #7A99B0;
    --pl-border : rgba(0,168,204,.2);
    --pl-font-h : 'Exo 2', sans-serif;
    --pl-font-b : 'Source Sans 3', sans-serif;
    --pl-radius : 6px;
    --pl-shadow : 0 4px 24px rgba(0,0,0,.25);
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
.pl-page { font-family: var(--pl-font-b); color: var(--pl-slate); background: var(--pl-white); line-height: 1.65; }
.pl-page h1, .pl-page h2, .pl-page h3, .pl-page h4 { font-family: var(--pl-font-h); font-weight: 700; }
.pl-container { max-width: 1200px; margin: 0 auto; padding: 0 24px; }
.pl-section { padding: 88px 0; }
.pl-section--dark { background: var(--pl-dark);  color: var(--pl-white); }
.pl-section--mid  { background: var(--pl-mid);   color: var(--pl-white); }
.pl-section--light{ background: #EBF5FB; }
.pl-btn {
    display: inline-block; padding: 14px 32px; border-radius: var(--pl-radius);
    font-family: var(--pl-font-h); font-size: .95rem; font-weight: 700; letter-spacing: .05em;
    text-decoration: none; cursor: pointer; border: none; transition: transform .2s, box-shadow .2s;
}
.pl-btn:hover { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(0,0,0,.25); }
.pl-btn--aqua    { background: var(--pl-aqua);   color: #fff; }
.pl-btn--outline { background: transparent; border: 2px solid rgba(0,168,204,.6); color: var(--pl-aqua); }
.pl-btn--red     { background: var(--pl-red);    color: #fff; }
.pl-section-label {
    font-family: var(--pl-font-h); font-size: .78rem; font-weight: 700;
    letter-spacing: .14em; color: var(--pl-aqua); text-transform: uppercase; margin-bottom: 10px;
}
.pl-section-title { font-size: clamp(1.9rem, 3.5vw, 2.6rem); margin-bottom: 16px; }
.pl-section-sub   { font-size: 1.02rem; opacity: .7; max-width: 560px; line-height: 1.75; }

/* ---- HERO ---- */
.pl-hero {
    position: relative; min-height: 100vh; overflow: hidden;
    background: var(--pl-dark);
    display: flex; align-items: center;
}
/* Blue water-wash gradient overlay */
.pl-hero::after {
    content: ''; position: absolute; inset: 0; pointer-events: none;
    background: radial-gradient(ellipse at 70% 50%, rgba(0,168,204,.12) 0%, transparent 60%);
}

/* Floating water drops */
.pl-drop {
    position: absolute; border-radius: 50% 50% 50% 50% / 60% 60% 40% 40%;
    background: rgba(0,168,204,.55);
    pointer-events: none;
}
@keyframes pl-drop-fall {
    0%  { transform: translateY(-20px) scaleY(.8); opacity: .7; }
    80% { transform: translateY(60px) scaleY(1); opacity: .4; }
    100%{ transform: translateY(80px) scaleY(.6); opacity: 0; }
}
.pl-drop { animation: pl-drop-fall var(--pl-ddur,3.5s) var(--pl-ddelay,0ms) infinite ease-in; }

.pl-hero__inner {
    position: relative; z-index: 2;
    display: grid; grid-template-columns: 1fr 500px; gap: 60px; align-items: center;
    max-width: 1200px; margin: 0 auto; padding: 120px 24px 80px; width: 100%;
}
.pl-hero__badge {
    display: inline-flex; align-items: center; gap: 8px;
    background: rgba(0,168,204,.12); border: 1px solid rgba(0,168,204,.3);
    border-radius: 4px; padding: 6px 16px; margin-bottom: 20px;
    font-size: .8rem; font-weight: 700; letter-spacing: .1em; color: var(--pl-aqua);
    font-family: var(--pl-font-h);
}
.pl-hero__emergency {
    display: inline-flex; align-items: center; gap: 8px;
    background: var(--pl-red); border-radius: 4px; padding: 6px 16px; margin-left: 10px;
    font-size: .8rem; font-weight: 700; letter-spacing: .1em; color: #fff;
    font-family: var(--pl-font-h); animation: pl-emergency-pulse 2s infinite;
}
@keyframes pl-emergency-pulse {
    0%,100%{ box-shadow: 0 0 0 0 rgba(192,57,43,.5); }
    50%     { box-shadow: 0 0 0 8px rgba(192,57,43,0); }
}
.pl-hero__heading { font-size: clamp(2.4rem,5vw,3.6rem); line-height: 1.1; color: var(--pl-white); margin-bottom: 20px; }
.pl-hero__heading em { color: var(--pl-aqua); font-style: normal; }
.pl-hero__sub { font-size: 1.08rem; color: rgba(240,248,255,.72); margin-bottom: 32px; line-height: 1.75; }
.pl-hero__cta { display: flex; gap: 16px; flex-wrap: wrap; }

/* ---- PIPE NETWORK SCENE ---- */
.pl-pipe-scene { position: relative; width: 500px; height: 460px; flex-shrink: 0; }

/* Pipe colour classes */
.pl-pipe {
    position: absolute; border-radius: 4px;
}
.pl-pipe--copper { background: var(--pl-copper); box-shadow: 0 2px 8px rgba(184,115,51,.4); }
.pl-pipe--blue   { background: var(--pl-aqua);   box-shadow: 0 2px 8px rgba(0,168,204,.35); }
.pl-pipe--grey   { background: #4A6070;           box-shadow: 0 2px 6px rgba(0,0,0,.3); }
.pl-pipe--h { height: 14px; }
.pl-pipe--v { width: 14px; }

/* Pipe joint/elbow dot */
.pl-joint {
    position: absolute; width: 20px; height: 20px; border-radius: 50%;
    transform: translate(-50%,-50%);
}
.pl-joint--copper { background: #8B5E2A; border: 2px solid var(--pl-copper); }
.pl-joint--blue   { background: #006E88; border: 2px solid var(--pl-aqua); }

/* Valve */
.pl-valve {
    position: absolute; width: 28px; height: 28px;
    background: #2A3F52; border: 3px solid var(--pl-aqua);
    border-radius: 4px; transform: translate(-50%,-50%);
    display: flex; align-items: center; justify-content: center;
}
.pl-valve::before {
    content: ''; width: 20px; height: 6px;
    background: var(--pl-aqua); border-radius: 2px;
    transform: rotate(45deg);
}

/* Pressure gauge */
.pl-gauge {
    position: absolute; width: 70px; height: 70px; border-radius: 50%;
    background: #162332; border: 4px solid var(--pl-aqua);
    box-shadow: 0 0 20px rgba(0,168,204,.3); bottom: 30px; right: 40px;
    display: flex; align-items: center; justify-content: center; flex-direction: column;
}
.pl-gauge__val  { font-family: 'Courier New',monospace; font-size: .85rem; color: var(--pl-aqua); font-weight: 700; line-height: 1; }
.pl-gauge__unit { font-size: .5rem; color: var(--pl-muted); letter-spacing: .08em; }
/* Needle */
.pl-gauge__needle {
    position: absolute; top: 50%; left: 50%;
    width: 26px; height: 3px;
    background: var(--pl-red); border-radius: 2px;
    transform-origin: left center;
    transform: rotate(-30deg) translateY(-50%);
    animation: pl-needle-wobble 4s infinite ease-in-out;
}
@keyframes pl-needle-wobble {
    0%,100%{ transform: rotate(-30deg) translateY(-50%); }
    50%    { transform: rotate(20deg) translateY(-50%); }
}

/* Boiler unit box */
.pl-boiler {
    position: absolute; top: 20px; right: 30px;
    width: 90px; height: 120px;
    background: #2A3F52; border: 2px solid #3A5065; border-radius: 8px;
    box-shadow: 0 0 24px rgba(0,168,204,.15);
}
.pl-boiler__brand {
    position: absolute; top: 8px; left: 0; right: 0;
    text-align: center; font-family: var(--pl-font-h); font-size: .45rem;
    font-weight: 800; letter-spacing: .1em; color: var(--pl-aqua);
}
.pl-boiler__display {
    position: absolute; top: 22px; left: 8px; right: 8px; height: 28px;
    background: #0F1B26; border-radius: 4px; border: 1px solid var(--pl-aqua);
    display: flex; align-items: center; justify-content: center;
    font-family: 'Courier New',monospace; font-size: .75rem; color: var(--pl-aqua);
}
.pl-boiler__button {
    position: absolute; border-radius: 50%;
    background: #1C2B3A; border: 2px solid #3A5065;
}
@keyframes pl-flame {
    0%,100%{ color: #FF6B35; text-shadow: 0 0 8px #FF6B35; }
    50%     { color: #FFD700; text-shadow: 0 0 14px #FFD700; }
}
.pl-boiler__flame {
    position: absolute; bottom: 12px; left: 50%; transform: translateX(-50%);
    font-size: .9rem; animation: pl-flame 1.5s infinite;
}

/* Water flow animation on blue pipes */
@keyframes pl-flow {
    0%   { background-position: 0 0; }
    100% { background-position: 40px 0; }
}
.pl-pipe--blue {
    background: repeating-linear-gradient(90deg, var(--pl-aqua) 0, var(--pl-aqua) 14px, rgba(0,168,204,.5) 14px, rgba(0,168,204,.5) 20px);
    animation: pl-flow 1.2s linear infinite;
}

/* ---- TRUST BAR ---- */
.pl-trust-bar { background: var(--pl-aqua); padding: 14px 0; }
.pl-trust-bar__inner {
    display: flex; justify-content: center; align-items: center;
    gap: 48px; flex-wrap: wrap;
}
.pl-trust-item {
    display: flex; align-items: center; gap: 9px;
    font-family: var(--pl-font-h); font-size: .85rem; font-weight: 700;
    letter-spacing: .04em; color: #fff;
}
.pl-trust-item span { font-size: 1.1rem; }

/* ---- COUNTERS ---- */
.pl-counters { background: var(--pl-mid); padding: 56px 0; }
.pl-counters__grid {
    display: grid; grid-template-columns: repeat(4,1fr); gap: 24px;
    max-width: 1000px; margin: 0 auto; padding: 0 24px;
}
.pl-counter-card {
    text-align: center; padding: 32px 16px;
    background: rgba(255,255,255,.04); border: 1px solid var(--pl-border);
    border-radius: var(--pl-radius);
}
.pl-counter-card__val {
    font-family: var(--pl-font-h); font-size: 2.8rem; font-weight: 800;
    color: var(--pl-aqua); line-height: 1.1;
    display: flex; align-items: baseline; justify-content: center; gap: 2px;
}
.pl-counter-card__suffix { font-size: 1.4rem; }
.pl-counter-card__label  { font-size: .84rem; color: rgba(240,248,255,.55); margin-top: 6px; }

/* ---- SERVICES ---- */
.pl-services-grid {
    display: grid; grid-template-columns: repeat(auto-fill,minmax(260px,1fr)); gap: 24px;
    margin-top: 48px;
}
.pl-service-card {
    background: #fff; border: 1px solid rgba(0,0,0,.08);
    border-radius: var(--pl-radius); padding: 28px; position: relative; overflow: hidden;
    transition: transform .25s, box-shadow .25s;
}
.pl-service-card::before {
    content: ''; position: absolute; inset: 0 0 auto 0;
    height: 4px; background: linear-gradient(90deg, var(--pl-aqua), var(--pl-copper));
}
.pl-service-card:hover { transform: translateY(-4px); box-shadow: 0 12px 32px rgba(0,0,0,.1); }
.pl-service-card__icon  { font-size: 2rem; margin-bottom: 14px; }
.pl-service-card__title { font-size: 1.02rem; margin-bottom: 10px; }
.pl-service-card__desc  { font-size: .87rem; color: #666; line-height: 1.65; }

/* ---- SCENARIOS ---- */
.pl-scenarios { background: var(--pl-dark); }
.pl-tags-cloud { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 32px; }
.pl-tag {
    background: rgba(0,168,204,.1); border: 1px solid rgba(0,168,204,.25);
    color: rgba(240,248,255,.8); border-radius: 4px;
    padding: 6px 14px; font-size: .82rem; transition: background .2s;
}
.pl-tag:hover { background: rgba(0,168,204,.22); color: var(--pl-aqua); }

/* ---- PROCESS ---- */
.pl-process { background: var(--pl-mid); }
.pl-process__steps {
    display: grid; grid-template-columns: repeat(5,1fr); gap: 0;
    position: relative; margin-top: 56px;
}
.pl-process__steps::before {
    content: ''; position: absolute; top: 28px; left: 10%; right: 10%; height: 3px;
    background: linear-gradient(90deg, var(--pl-aqua), var(--pl-copper), var(--pl-aqua));
    z-index: 0;
}
.pl-step { text-align: center; position: relative; z-index: 1; padding: 0 12px; }
.pl-step__num {
    width: 56px; height: 56px; border-radius: 50%; margin: 0 auto 20px;
    display: flex; align-items: center; justify-content: center;
    font-family: var(--pl-font-h); font-size: 1.1rem; font-weight: 800;
    background: var(--pl-mid); border: 3px solid var(--pl-aqua); color: var(--pl-aqua);
    box-shadow: 0 0 16px rgba(0,168,204,.3);
}
.pl-step__title { font-family: var(--pl-font-h); font-size: .88rem; font-weight: 700; color: var(--pl-white); margin-bottom: 8px; }
.pl-step__desc  { font-size: .78rem; color: rgba(240,248,255,.55); line-height: 1.6; }

/* ---- ENGINEER CREDENTIAL ---- */
.pl-engineer-section { background: var(--pl-dark); }
.pl-engineer-wrap { display: grid; grid-template-columns: 300px 1fr; gap: 56px; align-items: center; }
/* CSS plumber figure */
.pl-eng-figure { position: relative; height: 280px; }
.pl-eng__body {
    position: absolute; bottom: 0; left: 50%; transform: translateX(-50%);
    width: 74px; height: 128px;
    background: #1C2B3A; border-radius: 8px 8px 4px 4px;
    border: 2px solid #2E4560;
}
/* Hi-vis stripe */
.pl-eng__body::before {
    content: ''; position: absolute; top: 32px; left: 0; right: 0; height: 10px;
    background: var(--pl-aqua); opacity: .7;
}
.pl-eng__body::after {
    content: '🔧'; position: absolute; top: 10px; left: 50%; transform: translateX(-50%);
    font-size: .75rem;
}
.pl-eng__legs {
    position: absolute; bottom: 0; left: 50%; transform: translateX(-50%);
    display: flex; gap: 8px;
}
.pl-eng__leg {
    width: 26px; height: 55px;
    background: #0F1B26; border-radius: 0 0 4px 4px;
}
.pl-eng__head {
    position: absolute; bottom: 126px; left: 50%; transform: translateX(-50%);
    width: 46px; height: 46px;
    background: #C08060; border-radius: 50%;
}
/* Hard hat */
.pl-eng__hat {
    position: absolute; top: -20px; left: 50%; transform: translateX(-50%);
    width: 58px; height: 22px;
    background: var(--pl-aqua); border-radius: 50% 50% 0 0;
    box-shadow: 0 0 10px rgba(0,168,204,.4);
}
.pl-eng__hat::after {
    content: ''; position: absolute; bottom: 0; left: -6px; right: -6px;
    height: 6px; background: var(--pl-aqua); border-radius: 0 0 3px 3px;
}
.pl-eng__arm {
    position: absolute; bottom: 76px;
    width: 17px; height: 68px;
    background: #1C2B3A; border-radius: 6px;
    border: 1px solid #2E4560;
}
.pl-eng__arm--l { left: calc(50% - 52px); transform: rotate(15deg); transform-origin: top; }
.pl-eng__arm--r { right: calc(50% - 52px); transform: rotate(-30deg); transform-origin: top; }
/* Wrench tool */
.pl-eng__tool {
    position: absolute; bottom: 8px; right: calc(50% - 70px);
    font-size: .9rem;
}

.pl-engineer-info h3 { font-size: 1.8rem; color: var(--pl-white); margin-bottom: 4px; }
.pl-engineer-info h4 { font-size: .88rem; color: var(--pl-aqua); font-family: var(--pl-font-h); letter-spacing: .06em; margin-bottom: 20px; font-weight: 600; }
.pl-engineer-info p  { color: rgba(240,248,255,.72); line-height: 1.75; margin-bottom: 20px; }
.pl-engineer-badges  { display: flex; flex-wrap: wrap; gap: 10px; }
.pl-badge {
    display: inline-flex; align-items: center; gap: 6px;
    background: rgba(0,168,204,.1); border: 1px solid rgba(0,168,204,.25);
    border-radius: 4px; padding: 6px 14px;
    font-size: .78rem; font-weight: 700; font-family: var(--pl-font-h);
    letter-spacing: .04em; color: var(--pl-aqua);
}

/* ---- PACKAGES ---- */
.pl-packages-grid {
    display: grid; grid-template-columns: repeat(3,1fr); gap: 24px;
    margin-top: 48px; align-items: start;
}
.pl-package {
    background: #fff; border: 2px solid rgba(0,0,0,.07);
    border-radius: var(--pl-radius); padding: 32px; position: relative;
}
.pl-package--featured {
    background: var(--pl-slate); border-color: var(--pl-aqua);
    box-shadow: 0 0 32px rgba(0,168,204,.2); transform: scale(1.03);
}
.pl-package__badge {
    position: absolute; top: -14px; left: 50%; transform: translateX(-50%);
    background: var(--pl-aqua); color: #fff;
    font-family: var(--pl-font-h); font-size: .72rem; font-weight: 700;
    letter-spacing: .1em; padding: 4px 16px; border-radius: 4px; white-space: nowrap;
}
.pl-package__name { font-size: 1.1rem; margin-bottom: 6px; }
.pl-package--featured .pl-package__name { color: var(--pl-white); }
.pl-package__price { font-family: var(--pl-font-h); font-size: 2.2rem; font-weight: 800; color: var(--pl-aqua); margin: 12px 0 4px; }
.pl-package__period { font-size: .78rem; color: var(--pl-muted); margin-bottom: 20px; }
.pl-package--featured .pl-package__period { color: rgba(240,248,255,.5); }
.pl-package__items { list-style: none; margin-bottom: 28px; }
.pl-package__items li {
    padding: 7px 0; font-size: .87rem; border-bottom: 1px solid rgba(0,0,0,.06);
    display: flex; gap: 8px;
}
.pl-package--featured .pl-package__items li { border-color: rgba(255,255,255,.08); color: rgba(240,248,255,.82); }
.pl-package__items li::before { content: '✓'; color: var(--pl-aqua); font-weight: 700; flex-shrink: 0; }
.pl-package__cta { display: block; text-align: center; }

/* ---- TESTIMONIALS ---- */
.pl-testi-grid {
    display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; margin-top: 48px;
}
.pl-testi {
    background: #fff; border: 1px solid rgba(0,0,0,.07);
    border-radius: var(--pl-radius); padding: 28px;
}
.pl-testi__quote { font-size: 2.8rem; line-height: 1; color: var(--pl-aqua); opacity: .35; margin-bottom: 6px; }
.pl-testi__stars { color: #F5A623; margin-bottom: 10px; }
.pl-testi__text  { font-size: .88rem; color: #555; line-height: 1.7; margin-bottom: 18px; }
.pl-testi__name  { font-weight: 700; font-size: .88rem; color: var(--pl-slate); }
.pl-testi__role  { font-size: .78rem; color: var(--pl-muted); }

/* ---- BOOKING ---- */
.pl-booking { background: var(--pl-dark); }
.pl-booking__wrap { display: grid; grid-template-columns: 1fr 1fr; gap: 56px; align-items: start; }
.pl-booking__info h2 { color: var(--pl-white); margin-bottom: 16px; }
.pl-booking__info p  { color: rgba(240,248,255,.68); line-height: 1.75; margin-bottom: 24px; }
.pl-booking__bullets { list-style: none; }
.pl-booking__bullets li {
    padding: 10px 0; border-bottom: 1px solid rgba(255,255,255,.07);
    color: rgba(240,248,255,.75); font-size: .9rem;
    display: flex; gap: 10px;
}
.pl-booking__bullets li::before { content: '💧'; flex-shrink: 0; }

.pl-form {
    background: var(--pl-mid); border: 1px solid var(--pl-border);
    border-radius: var(--pl-radius); padding: 36px;
}
.pl-form h3 { color: var(--pl-white); font-size: 1.35rem; margin-bottom: 24px; }
.pl-field    { margin-bottom: 18px; }
.pl-field label {
    display: block; font-size: .78rem; font-weight: 700; letter-spacing: .06em;
    color: rgba(240,248,255,.6); margin-bottom: 6px; text-transform: uppercase;
    font-family: var(--pl-font-h);
}
.pl-field input, .pl-field select, .pl-field textarea {
    width: 100%; padding: 11px 14px; border-radius: var(--pl-radius);
    background: var(--pl-dark); border: 1px solid var(--pl-border);
    color: var(--pl-white); font-family: var(--pl-font-b); font-size: .92rem;
    outline: none; transition: border-color .2s;
}
.pl-field input:focus, .pl-field select:focus, .pl-field textarea:focus { border-color: var(--pl-aqua); }
.pl-field textarea { resize: vertical; min-height: 100px; }
.pl-field select option { background: var(--pl-dark); }
.pl-field-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.pl-form__submit {
    width: 100%; padding: 15px; background: var(--pl-aqua); color: #fff;
    border: none; border-radius: var(--pl-radius); font-family: var(--pl-font-h);
    font-size: 1rem; font-weight: 700; letter-spacing: .06em; cursor: pointer;
    transition: filter .2s, transform .2s;
}
.pl-form__submit:hover { filter: brightness(1.1); transform: translateY(-1px); }

/* ---- FOOTER ---- */
.pl-footer {
    background: var(--pl-dark); padding: 40px 0; text-align: center;
    border-top: 1px solid rgba(255,255,255,.05);
}
.pl-footer p { font-size: .82rem; color: rgba(240,248,255,.35); margin-bottom: 4px; }
.pl-footer__phone { font-family: var(--pl-font-h); font-size: 1.7rem; color: var(--pl-aqua); margin-bottom: 8px; }

/* ---- RESPONSIVE ---- */
@media (max-width: 900px) {
    .pl-hero__inner     { grid-template-columns: 1fr; padding-top: 100px; }
    .pl-pipe-scene      { width: 100%; height: 320px; }
    .pl-counters__grid  { grid-template-columns: repeat(2,1fr); }
    .pl-process__steps  { grid-template-columns: 1fr; gap: 32px; }
    .pl-process__steps::before { display: none; }
    .pl-engineer-wrap   { grid-template-columns: 1fr; }
    .pl-eng-figure      { height: 200px; margin: 0 auto 32px; }
    .pl-packages-grid   { grid-template-columns: 1fr; }
    .pl-package--featured { transform: none; }
    .pl-testi-grid      { grid-template-columns: 1fr; }
    .pl-booking__wrap   { grid-template-columns: 1fr; }
}
</style>
<?php get_header(); ?>

<div class="">

>

<!-- ═══════════════════════════════════════════════════════
     HERO — Pipe Network + Boiler Scene
     ═══════════════════════════════════════════════════════ -->
<section class="pl-hero" aria-label="Hero">

    <!-- Water drops -->
    <?php foreach ( $pl_drops as $dr ) : ?>
        <div class="pl-drop" aria-hidden="true" style="
            left:<?php echo esc_attr($dr['x']); ?>%;
            top:<?php echo esc_attr($dr['y']); ?>%;
            width:<?php echo esc_attr($dr['size']); ?>px;
            height:<?php echo esc_attr( round($dr['size']*1.3) ); ?>px;
            --pl-ddur:<?php echo esc_attr($dr['dur']); ?>ms;
            --pl-ddelay:<?php echo esc_attr($dr['delay']); ?>ms;
        "></div>
    <?php endforeach; ?>

    <div class="pl-hero__inner">
        <!-- Text -->
        <div>
            <div class="pl-hero__badge">🏅 Gas Safe Registered</div>
            <div class="pl-hero__emergency">● 24/7 Emergency</div>
            <h1 class="pl-hero__heading" style="margin-top:16px;">
                Your Local<br><em>Trusted</em><br>Plumber
            </h1>
            <p class="pl-hero__sub">Gas Safe registered engineers for boiler installation, bathroom fitting, leak repairs and 24/7 emergency plumbing. Fixed prices — no call-out fee.</p>
            <div class="pl-hero__cta">
                <a href="#booking" class="pl-btn pl-btn--aqua">Get a Free Quote</a>
                <a href="tel:+441234567890" class="pl-btn pl-btn--red">🚨 Emergency Line</a>
            </div>
        </div>

        <!-- Pipe network scene -->
        <div class="pl-pipe-scene" aria-hidden="true">

            <!-- Boiler unit -->
            <div class="pl-boiler">
                <div class="pl-boiler__brand">COMBI PRO</div>
                <div class="pl-boiler__display">60°C</div>
                <div class="pl-boiler__button" style="width:14px;height:14px;bottom:40px;left:12px;border-color:var(--pl-aqua);"></div>
                <div class="pl-boiler__button" style="width:14px;height:14px;bottom:40px;left:32px;border-color:var(--pl-aqua);"></div>
                <div class="pl-boiler__button" style="width:14px;height:14px;bottom:40px;left:52px;border-color:var(--pl-red);"></div>
                <div class="pl-boiler__flame">🔥</div>
            </div>

            <!-- Pipe runs from boiler -->
            <!-- Copper flow pipe horizontal -->
            <div class="pl-pipe pl-pipe--copper pl-pipe--h" style="left:120px;top:45px;width:140px;"></div>
            <!-- Vertical down left -->
            <div class="pl-pipe pl-pipe--copper pl-pipe--v" style="left:120px;top:45px;height:200px;"></div>
            <!-- Bottom horizontal -->
            <div class="pl-pipe pl-pipe--copper pl-pipe--h" style="left:50px;top:243px;width:200px;"></div>
            <!-- Return vertical -->
            <div class="pl-pipe pl-pipe--blue pl-pipe--v" style="left:50px;top:60px;height:183px;"></div>
            <!-- Boiler connection -->
            <div class="pl-pipe pl-pipe--blue pl-pipe--h" style="left:50px;top:60px;width:70px;"></div>
            <!-- Branch pipe going right -->
            <div class="pl-pipe pl-pipe--grey pl-pipe--h" style="left:260px;top:100px;width:140px;"></div>
            <div class="pl-pipe pl-pipe--grey pl-pipe--v" style="left:393px;top:100px;height:130px;"></div>

            <!-- Joints -->
            <div class="pl-joint pl-joint--copper" style="left:120px;top:45px;"></div>
            <div class="pl-joint pl-joint--copper" style="left:120px;top:245px;"></div>
            <div class="pl-joint pl-joint--blue" style="left:50px;top:60px;"></div>
            <div class="pl-joint pl-joint--blue" style="left:50px;top:245px;"></div>

            <!-- Valves -->
            <div class="pl-valve" style="left:200px;top:55px;"></div>
            <div class="pl-valve" style="left:80px;top:155px;"></div>

            <!-- Pressure gauge -->
            <div class="pl-gauge">
                <div class="pl-gauge__val">1.5</div>
                <div class="pl-gauge__unit">BAR</div>
                <div class="pl-gauge__needle"></div>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     TRUST BAR
     ═══════════════════════════════════════════════════════ -->
<div class="pl-trust-bar" role="complementary">
    <div class="pl-trust-bar__inner pl-container">
        <div class="pl-trust-item"><span>🏅</span> Gas Safe Registered</div>
        <div class="pl-trust-item"><span>💧</span> CIPHE Member</div>
        <div class="pl-trust-item"><span>🚨</span> 24/7 Emergency</div>
        <div class="pl-trust-item"><span>🛡️</span> £2M Public Liability</div>
        <div class="pl-trust-item"><span>✅</span> 12-Month Guarantee</div>
    </div>
</div>

<!-- ═══════════════════════════════════════════════════════
     COUNTERS
     ═══════════════════════════════════════════════════════ -->
<section class="pl-counters" aria-label="Key statistics">
    <div class="pl-counters__grid">
        <?php foreach ( $pl_counters as $ctr ) : ?>
            <div class="pl-counter-card">
                <div class="pl-counter-card__val">
                    <span class="pl-counter-num"
                          data-target="<?php echo esc_attr($ctr['value']); ?>"
                          data-suffix="<?php echo esc_attr($ctr['suffix']); ?>"
                          <?php if($ctr['float']) echo 'data-float="1"'; ?>>0</span>
                    <span class="pl-counter-card__suffix"><?php echo esc_html($ctr['suffix']); ?></span>
                </div>
                <div class="pl-counter-card__label"><?php echo esc_html($ctr['label']); ?></div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     SERVICES
     ═══════════════════════════════════════════════════════ -->
<section class="pl-section" aria-labelledby="pl-services-title">
    <div class="pl-container">
        <div class="pl-section-label">What We Do</div>
        <h2 class="pl-section-title" id="pl-services-title">Plumbing & Heating Services</h2>
        <p class="pl-section-sub">From boiler breakdowns to complete bathroom installations — Gas Safe registered engineers for every plumbing and heating need.</p>
        <div class="pl-services-grid">
            <?php foreach ( $pl_services as $svc ) : ?>
                <div class="pl-service-card">
                    <div class="pl-service-card__icon"><?php echo esc_html($svc['icon']); ?></div>
                    <h3 class="pl-service-card__title"><?php echo esc_html($svc['title']); ?></h3>
                    <p class="pl-service-card__desc"><?php echo esc_html($svc['desc']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     SCENARIOS CLOUD
     ═══════════════════════════════════════════════════════ -->
<section class="pl-section pl-scenarios" aria-labelledby="pl-scenarios-title">
    <div class="pl-container">
        <div class="pl-section-label" style="color:var(--pl-aqua);">We Fix</div>
        <h2 class="pl-section-title" id="pl-scenarios-title" style="color:var(--pl-white);">Every Plumbing Problem</h2>
        <p class="pl-section-sub" style="color:rgba(240,248,255,.6);">Whether it's a dripping tap or a full system failure — our engineers are equipped to handle any plumbing or heating scenario.</p>
        <div class="pl-tags-cloud" role="list">
            <?php foreach ( $pl_scenarios as $sc ) : ?>
                <span class="pl-tag" role="listitem"><?php echo esc_html($sc); ?></span>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     PROCESS
     ═══════════════════════════════════════════════════════ -->
<section class="pl-section pl-process" aria-labelledby="pl-process-title">
    <div class="pl-container">
        <div class="pl-section-label" style="color:var(--pl-aqua);">How It Works</div>
        <h2 class="pl-section-title" id="pl-process-title" style="color:var(--pl-white);">Our 5-Step Process</h2>
        <p class="pl-section-sub" style="color:rgba(240,248,255,.58);">Clean, professional and transparent — from first call to final sign-off.</p>
        <div class="pl-process__steps">
            <?php foreach ( $pl_process as $ps ) : ?>
                <div class="pl-step">
                    <div class="pl-step__num"><?php echo esc_html($ps['step']); ?></div>
                    <div class="pl-step__title"><?php echo esc_html($ps['title']); ?></div>
                    <p class="pl-step__desc"><?php echo esc_html($ps['desc']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     LEAD ENGINEER CREDENTIAL
     ═══════════════════════════════════════════════════════ -->
<section class="pl-section pl-engineer-section" aria-labelledby="pl-engineer-title">
    <div class="pl-container">
        <div class="pl-engineer-wrap">
            <div class="pl-eng-figure" aria-hidden="true">
                <div class="pl-eng__arm pl-eng__arm--l"></div>
                <div class="pl-eng__arm pl-eng__arm--r"></div>
                <div class="pl-eng__body"></div>
                <div class="pl-eng__legs">
                    <div class="pl-eng__leg"></div>
                    <div class="pl-eng__leg"></div>
                </div>
                <div class="pl-eng__head">
                    <div class="pl-eng__hat"></div>
                </div>
                <div class="pl-eng__tool">🔧</div>
            </div>
            <div class="pl-engineer-info">
                <div class="pl-section-label">Principal Engineer</div>
                <h3 id="pl-engineer-title">Gary Thornton</h3>
                <h4>Gas Safe Registered · CIPHE Member · G3 Unvented · City & Guilds Qualified</h4>
                <p>
                    Gary has been a Gas Safe registered engineer since <?php echo date('Y') - 19; ?> and leads a team of six qualified plumbers and heating engineers. He specialises in boiler installation, underfloor heating and complex heating system design.
                </p>
                <p>
                    All our engineers carry Gas Safe ID cards, are DBS checked and hold £2 million public liability insurance. Every gas job is registered with Gas Safe Register — our customers receive their documentation within 24 hours of completion.
                </p>
                <div class="pl-engineer-badges">
                    <span class="pl-badge">🏅 Gas Safe Reg.</span>
                    <span class="pl-badge">💧 CIPHE Member</span>
                    <span class="pl-badge">⚡ G3 Unvented</span>
                    <span class="pl-badge">🔥 City & Guilds</span>
                    <span class="pl-badge">✅ DBS Checked</span>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     PACKAGES
     ═══════════════════════════════════════════════════════ -->
<section class="pl-section pl-section--light" aria-labelledby="pl-packages-title">
    <div class="pl-container">
        <div class="pl-section-label">Pricing</div>
        <h2 class="pl-section-title" id="pl-packages-title">Fixed-Price Packages</h2>
        <p class="pl-section-sub">No call-out charges. No hourly guesswork. Every job priced upfront before we start work.</p>
        <div class="pl-packages-grid">
            <?php foreach ( $pl_packages as $pkg ) : ?>
                <div class="pl-package <?php echo $pkg['featured'] ? 'pl-package--featured' : ''; ?>">
                    <?php if ( $pkg['featured'] ) : ?>
                        <div class="pl-package__badge">MOST POPULAR</div>
                    <?php endif; ?>
                    <h3 class="pl-package__name"><?php echo esc_html($pkg['name']); ?></h3>
                    <div class="pl-package__price"><?php echo esc_html($pkg['price']); ?></div>
                    <div class="pl-package__period"><?php echo esc_html($pkg['period']); ?></div>
                    <ul class="pl-package__items">
                        <?php foreach ( $pkg['items'] as $item ) : ?>
                            <li><?php echo esc_html($item); ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <a href="#booking" class="pl-btn pl-btn--aqua pl-package__cta">Book This Package</a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     TESTIMONIALS
     ═══════════════════════════════════════════════════════ -->
<section class="pl-section" aria-labelledby="pl-testi-title">
    <div class="pl-container">
        <div class="pl-section-label">Reviews</div>
        <h2 class="pl-section-title" id="pl-testi-title">What Our Customers Say</h2>
        <p class="pl-section-sub">Thousands of homeowners and landlords trust us year after year — here's why.</p>
        <div class="pl-testi-grid">
            <?php foreach ( $pl_testimonials as $t ) : ?>
                <blockquote class="pl-testi">
                    <div class="pl-testi__quote" aria-hidden="true">❝</div>
                    <div class="pl-testi__stars" aria-label="5 stars">★★★★★</div>
                    <p class="pl-testi__text"><?php echo esc_html($t['text']); ?></p>
                    <footer>
                        <div class="pl-testi__name"><?php echo esc_html($t['name']); ?></div>
                        <div class="pl-testi__role"><?php echo esc_html($t['role']); ?></div>
                    </footer>
                </blockquote>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     BOOKING FORM
     ═══════════════════════════════════════════════════════ -->
<section class="pl-section pl-booking" id="booking" aria-labelledby="pl-booking-title">
    <div class="pl-container">
        <div class="pl-booking__wrap">
            <div class="pl-booking__info">
                <div class="pl-section-label" style="color:var(--pl-aqua);">Get in Touch</div>
                <h2 id="pl-booking-title" style="color:var(--pl-white);">Book a Free Estimate</h2>
                <p>Tell us your plumbing or heating problem and we'll come out to assess it for free. Same-day response to enquiries — emergencies answered immediately.</p>
                <ul class="pl-booking__bullets">
                    <li>Free, no-obligation estimate</li>
                    <li>Same-day emergency callouts available</li>
                    <li>Fixed prices agreed before work starts</li>
                    <li>Gas Safe paperwork issued same day</li>
                    <li>12-month labour guarantee on all work</li>
                    <li>Evening &amp; weekend appointments available</li>
                </ul>
            </div>
            <div class="pl-form">
                <h3>Request a Quote</h3>
                <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" novalidate>
                    <?php wp_nonce_field( 'tf_pl_booking', 'tf_pl_nonce' ); ?>
                    <input type="hidden" name="action" value="tf_pl_booking">

                    <div class="pl-field-row">
                        <div class="pl-field">
                            <label for="pl-name">Full Name *</label>
                            <input type="text" id="pl-name" name="pl_name" required placeholder="Jane Smith">
                        </div>
                        <div class="pl-field">
                            <label for="pl-phone">Phone *</label>
                            <input type="tel" id="pl-phone" name="pl_phone" required placeholder="07700 900123">
                        </div>
                    </div>

                    <div class="pl-field">
                        <label for="pl-email">Email Address *</label>
                        <input type="email" id="pl-email" name="pl_email" required placeholder="jane@example.com">
                    </div>

                    <div class="pl-field">
                        <label for="pl-service">Service Required *</label>
                        <select id="pl-service" name="pl_service" required>
                            <option value="">— Select a service —</option>
                            <option value="boiler-install">Boiler Installation</option>
                            <option value="boiler-service">Boiler Service</option>
                            <option value="boiler-repair">Boiler Repair</option>
                            <option value="bathroom">Bathroom Installation</option>
                            <option value="leak">Leak Detection / Repair</option>
                            <option value="heating">Central Heating</option>
                            <option value="emergency">Emergency Call-Out</option>
                            <option value="gas-safety">Gas Safety Certificate</option>
                            <option value="ufh">Underfloor Heating</option>
                            <option value="other">Other</option>
                        </select>
                    </div>

                    <div class="pl-field-row">
                        <div class="pl-field">
                            <label for="pl-property">Property Type</label>
                            <select id="pl-property" name="pl_property">
                                <option value="terraced">Terraced House</option>
                                <option value="semi">Semi-Detached</option>
                                <option value="detached">Detached House</option>
                                <option value="flat">Flat / Apartment</option>
                                <option value="commercial">Commercial</option>
                            </select>
                        </div>
                        <div class="pl-field">
                            <label for="pl-urgency">Urgency</label>
                            <select id="pl-urgency" name="pl_urgency">
                                <option value="emergency">Emergency — Today</option>
                                <option value="asap">ASAP — This Week</option>
                                <option value="week" selected>Within a Week</option>
                                <option value="flexible">Flexible</option>
                            </select>
                        </div>
                    </div>

                    <div class="pl-field">
                        <label for="pl-notes">Describe the Problem</label>
                        <textarea id="pl-notes" name="pl_notes" placeholder="What's the issue? The more detail you provide, the more accurate our quote will be..."></textarea>
                    </div>

                    <button type="submit" class="pl-form__submit">💧 Request My Free Estimate</button>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════
     FOOTER
     ═══════════════════════════════════════════════════════ -->
<footer class="pl-footer" role="contentinfo">
    <div class="pl-container">
        <p>Thornton Plumbing & Heating Ltd &nbsp;·&nbsp; Gas Safe Registered · CIPHE Member</p>
        <div class="pl-footer__phone">📞 0800 123 4567</div>
        <p><?php echo esc_html( get_bloginfo('name') ); ?> &copy; <?php echo date('Y'); ?> &nbsp;·&nbsp; Gas Safe Registration No. 123456 &nbsp;·&nbsp; All gas work registered with Gas Safe Register</p>
    </div>
</footer>

<script>
(function(){
    'use strict';
    var easeOut = function(t){ return 1 - Math.pow(1-t,3); };
    var counters = document.querySelectorAll('.pl-counter-num');
    if(!counters.length) return;
    var observer = new IntersectionObserver(function(entries){
        entries.forEach(function(entry){
            if(!entry.isIntersecting) return;
            observer.unobserve(entry.target);
            var el = entry.target;
            var target = parseFloat(el.dataset.target);
            var isFloat = el.dataset.float === '1';
            if(isNaN(target)) return;
            var start = null, dur = 1800;
            function tick(ts){
                if(!start) start = ts;
                var prog = Math.min((ts-start)/dur,1);
                var val = easeOut(prog)*target;
                el.textContent = isFloat ? val.toFixed(1) : Math.floor(val).toLocaleString();
                if(prog<1) requestAnimationFrame(tick);
                else el.textContent = isFloat ? target.toFixed(1) : target.toLocaleString();
            }
            requestAnimationFrame(tick);
        });
    }, {threshold:0.3});
    counters.forEach(function(c){ observer.observe(c); });
})();
</script>

</div><!-- . -->

<?php get_footer(); ?>
