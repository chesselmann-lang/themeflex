<?php
/**
 * Template Name: Premium Podcast & Media Brand Homepage
 * Template Post Type: page
 *
 * ThemeFlex – ThemeFlex: Audio / Talk Show
 * Namespace : --po-*
 * Fonts     : Clash Display (headings) + Satoshi (body) → via CDN aliases: Space Grotesk + DM Sans
 * Palette   : Ink #0D0D0D / Flame #FF4D00 / Butter #FFE566 / Fog #F0F0EE / Slate #5A5A6A
 */
defined('ABSPATH') || exit;
get_header();

/* ── Palette ─────────────────────────────────────────────── */
$po_ink    = '#0D0D0D';
$po_flame  = '#FF4D00';
$po_butter = '#FFE566';
$po_fog    = '#F0F0EE';
$po_slate  = '#5A5A6A';
$po_warm   = '#1A1410';
$po_mid    = '#2C2C2C';

/* ── Deterministic randomness ─────────────────────────────── */
srand(crc32('po-podcast-hero'));

/* ── Episode Data ────────────────────────────────────────── */
$po_episodes = [
  ['ep'=>147,'title'=>'The Future of Work Is Already Here','guest'=>'Priya Narayan','guestRole'=>'Future of Work Researcher, MIT','duration'=>'1h 22m','date'=>'28 Apr 2026','tags'=>['Work','AI','Society'],'color'=>'#1A1410','popular'=>true],
  ['ep'=>146,'title'=>'How Tiny Countries Win at Everything','guest'=>'Erik Halvorsen','guestRole'=>'Author, "The Small-Country Advantage"','duration'=>'58m','date'=>'21 Apr 2026','tags'=>['Policy','Economics'],'color'=>'#101418','popular'=>false],
  ['ep'=>145,'title'=>'Inside the Climate Money Machine','guest'=>'Dr. Amara Osei','guestRole'=>'Climate Finance Director, UN','duration'=>'1h 08m','date'=>'14 Apr 2026','tags'=>['Climate','Finance'],'color'=>'#141018','popular'=>false],
  ['ep'=>144,'title'=>'Rewiring Attention in an Age of Everything','guest'=>'James Kilburn','guestRole'=>'Neuroscientist & bestselling author','duration'=>'1h 35m','date'=>'7 Apr 2026','tags'=>['Neuroscience','Tech','Psychology'],'color'=>'#181410','popular'=>false],
  ['ep'=>143,'title'=>'The Architecture of Power','guest'=>'Laila Mansour','guestRole'=>'Political Philosopher, Oxford','duration'=>'1h 12m','date'=>'31 Mar 2026','tags'=>['Politics','Philosophy'],'color'=>'#101214','popular'=>false],
  ['ep'=>142,'title'=>'Radical Honesty in Business','guest'=>'Tom Cassidy','guestRole'=>'CEO, Cassidy Group','duration'=>'48m','date'=>'24 Mar 2026','tags'=>['Business','Leadership'],'color'=>'#14120E','popular'=>false],
];

/* ── Guests (featured) ─────────────────────────────────── */
$po_guests = [
  ['name'=>'Priya Narayan','role'=>'Future of Work Researcher','org'=>'MIT Media Lab','ep'=>147,'skin'=>'#C8906A','hair'=>'#1A0808'],
  ['name'=>'Erik Halvorsen','role'=>'Author & Policy Advisor','org'=>'Copenhagen Economics','ep'=>146,'skin'=>'#C4A882','hair'=>'#2A1818'],
  ['name'=>'Dr. Amara Osei','role'=>'Climate Finance Director','org'=>'United Nations','ep'=>145,'skin'=>'#8B6040','hair'=>'#0A0404'],
  ['name'=>'James Kilburn','role'=>'Neuroscientist','org'=>'UCL Brain Sciences','ep'=>144,'skin'=>'#D4AA82','hair'=>'#382010'],
];

/* ── Platform links ──────────────────────────────────────── */
$po_platforms = [
  ['n'=>'Spotify','color'=>'#1DB954','ic'=>'&#9835;'],
  ['n'=>'Apple Podcasts','color'=>'#B150E2','ic'=>'&#9836;'],
  ['n'=>'YouTube','color'=>'#FF0000','ic'=>'&#9654;'],
  ['n'=>'Amazon Music','color'=>'#00A8E1','ic'=>'&#9834;'],
  ['n'=>'Pocket Casts','color'=>'#F43E37','ic'=>'&#128246;'],
  ['n'=>'Overcast','color'=>'#FC7E0F','ic'=>'&#128248;'],
];

/* ── Stats ───────────────────────────────────────────────── */
$po_stats = [
  ['n'=>'147','l'=>'Episodes'],
  ['n'=>'4.2M','l'=>'Downloads / mo'],
  ['n'=>'#3','l'=>'UK Charts'],
  ['n'=>'94%','l'=>'5-star reviews'],
];
?>
<!-- GLOBAL CSS ──────────────────────────────────────────── -->
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=DM+Sans:wght@300;400;500;600&display=swap');
:root{
  --po-ink:<?php echo $po_ink; ?>;
  --po-flame:<?php echo $po_flame; ?>;
  --po-butter:<?php echo $po_butter; ?>;
  --po-fog:<?php echo $po_fog; ?>;
  --po-slate:<?php echo $po_slate; ?>;
}
.po-page{font-family:'DM Sans',system-ui,sans-serif;background:var(--po-ink);color:var(--po-fog);line-height:1.6;margin:0;}
.po-container{max-width:1200px;margin:0 auto;padding:0 2rem;}
.po-section{padding:6rem 0;}
.po-reveal{opacity:0;transform:translateY(24px);transition:opacity .65s ease,transform .65s ease;}
.po-reveal.po-visible{opacity:1;transform:none;}
.po-eyebrow{font-family:'Space Grotesk',sans-serif;font-size:.68rem;letter-spacing:.28em;text-transform:uppercase;color:var(--po-flame);margin-bottom:.75rem;}
/* Episode row */
.po-episode{border-bottom:1px solid rgba(255,255,255,.07);padding:1.75rem 0;display:grid;grid-template-columns:60px 1fr auto;gap:1.5rem;align-items:center;transition:background .25s;}
.po-episode:hover{background:rgba(255,255,255,.02);}
/* FAQ */
.po-faq__a{max-height:0;overflow:hidden;transition:max-height .4s ease;}
.po-faq.po-open .po-faq__a{max-height:300px;}
/* Waveform bars animation */
@keyframes po-wave{0%,100%{height:20%;}50%{height:90%;}}
</style>

<div class="po-page">

  <!-- HERO ─────────────────────────────────────────────────── -->
  <section style="min-height:100vh;position:relative;display:flex;flex-direction:column;justify-content:flex-end;overflow:hidden;background:var(--po-warm);" aria-labelledby="po-hero-title">

    <!-- Dark gradient bg -->
    <div aria-hidden="true" style="position:absolute;inset:0;background:radial-gradient(ellipse at 70% 0%,rgba(255,77,0,.08) 0%,transparent 55%),radial-gradient(ellipse at 10% 100%,rgba(255,229,102,.06) 0%,transparent 50%);"></div>

    <!-- Grid overlay -->
    <div aria-hidden="true" style="position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,.015) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.015) 1px,transparent 1px);background-size:80px 80px;"></div>

    <!-- CSS Recording Studio Scene ──────────────────────── -->
    <div aria-hidden="true" style="position:absolute;top:0;right:0;width:55%;height:100%;overflow:hidden;display:flex;align-items:center;justify-content:center;">

      <!-- Studio room background wall -->
      <div style="position:absolute;inset:0;background:linear-gradient(180deg,#0F0B08 0%,#1A1410 100%);"></div>

      <!-- Acoustic foam panels (texture) -->
      <?php for($fp=0;$fp<4;$fp++){
        $fpleft = 5 + $fp*24;
        $fptop  = 10 + ($fp%2)*30;
      ?>
      <div style="position:absolute;top:<?php echo $fptop; ?>%;left:<?php echo $fpleft; ?>%;width:18%;height:35%;background:repeating-linear-gradient(45deg,#1C1510,#1C1510 6px,#201812 6px,#201812 12px);border-radius:2px;opacity:.6;"></div>
      <?php } ?>

      <!-- Large monitor speakers -->
      <?php foreach([-35,25] as $spx): ?>
      <div style="position:absolute;bottom:20%;left:calc(50% + <?php echo $spx; ?>%);transform:translateX(-50%);width:14%;aspect-ratio:.75;background:linear-gradient(180deg,#1E1E1E 0%,#141414 100%);border-radius:6px;border:2px solid #2A2A2A;display:flex;flex-direction:column;align-items:center;justify-content:space-around;padding:12% 10%;">
        <div style="width:80%;aspect-ratio:1;border-radius:50%;background:radial-gradient(circle,#333 0%,#1A1A1A 60%,#222 100%);border:3px solid #2E2E2E;"></div>
        <div style="width:80%;height:20%;border-radius:30%;background:radial-gradient(ellipse,#2A2A2A 0%,#1A1A1A 100%);border:2px solid #2E2E2E;"></div>
        <div style="width:40%;height:4px;border-radius:2px;background:#FF4D00;box-shadow:0 0 8px rgba(255,77,0,.6);"></div>
      </div>
      <?php endforeach; ?>

      <!-- Mixing desk / console -->
      <div style="position:absolute;bottom:10%;left:50%;transform:translateX(-50%);width:70%;height:25%;background:linear-gradient(180deg,#2A2218 0%,#1A1510 100%);border-radius:8px 8px 4px 4px;border:2px solid #3A3020;">
        <!-- Fader rows -->
        <?php for($row=0;$row<3;$row++){
          $rowTop = 20 + $row*25;
        ?>
        <div style="position:absolute;top:<?php echo $rowTop; ?>%;left:5%;right:5%;height:6%;display:flex;gap:2%;align-items:center;">
          <?php for($fd=0;$fd<12;$fd++){
            $fh = rand(20,80);
            $fc = ($fd===4||$fd===7)?'rgba(255,77,0,.9)':($fd===2?'rgba(255,229,102,.9)':'rgba(255,255,255,.2)');
          ?>
          <div style="flex:1;height:100%;position:relative;background:#111;border-radius:1px;">
            <div style="position:absolute;bottom:0;left:0;right:0;height:<?php echo $fh; ?>%;background:<?php echo $fc; ?>;border-radius:1px;"></div>
          </div>
          <?php } ?>
        </div>
        <?php } ?>
        <!-- Knobs row -->
        <div style="position:absolute;bottom:10%;left:5%;right:5%;display:flex;gap:2%;align-items:center;">
          <?php for($kn=0;$kn<14;$kn++): $kc = $kn%4===0?$po_flame:($kn%3===0?$po_butter:'#3A3A3A'); ?>
          <div style="flex:1;aspect-ratio:1;border-radius:50%;background:radial-gradient(circle at 35% 35%,<?php echo $kc; ?>,<?php echo $po_ink; ?>);border:1px solid rgba(255,255,255,.08);"></div>
          <?php endfor; ?>
        </div>
        <!-- Screen -->
        <div style="position:absolute;top:5%;right:2%;width:22%;height:45%;background:#0A1A0A;border-radius:3px;border:2px solid #2A3020;display:flex;align-items:center;justify-content:center;overflow:hidden;">
          <div style="display:flex;align-items:flex-end;gap:1px;height:60%;padding:0 4px;">
            <?php for($lb=0;$lb<8;$lb++): $lbh = rand(15,100); ?>
            <div style="flex:1;height:<?php echo $lbh; ?>%;background:<?php echo $lbh>70?'#FF4D00':($lbh>40?'#FFE566':'#00C040'); ?>;border-radius:1px 1px 0 0;"></div>
            <?php endfor; ?>
          </div>
        </div>
      </div>

      <!-- Microphone boom arm + mic -->
      <div style="position:absolute;bottom:35%;left:50%;transform:translateX(-20%);width:4px;height:80px;background:#333;transform-origin:bottom center;transform:translateX(-20%) rotate(-30deg);"></div>
      <div style="position:absolute;bottom:calc(35% + 60px);left:calc(50% - 22px);width:22px;height:40px;border-radius:10px;background:linear-gradient(180deg,#444 0%,#222 100%);border:2px solid #555;box-shadow:0 0 10px rgba(255,77,0,.2);"></div>
      <!-- Mic grille -->
      <?php for($mg=0;$mg<4;$mg++) echo '<div style="position:absolute;bottom:calc(35% + '.($68+$mg*6).'px);left:calc(50% - 20px);width:18px;height:1px;background:rgba(255,255,255,.15);"></div>'; ?>

      <!-- ON AIR light -->
      <div style="position:absolute;top:15%;right:8%;padding:.4rem 1.2rem;background:#FF4D00;border-radius:3px;font-family:\'Space Grotesk\',sans-serif;font-size:.65rem;font-weight:700;letter-spacing:.2em;text-transform:uppercase;color:#ffffff;box-shadow:0 0 20px rgba(255,77,0,.7);">ON AIR</div>

      <!-- Pop filter -->
      <div style="position:absolute;bottom:calc(35% + 65px);left:calc(50% - 35px);width:30px;height:30px;border-radius:50%;border:3px solid rgba(255,255,255,.12);background:transparent;"></div>

      <!-- Headphones on hook -->
      <div style="position:absolute;top:25%;left:10%;width:40px;height:30px;border-radius:50% 50% 0 0;border:5px solid #3A3A3A;border-bottom:none;background:transparent;"></div>
      <div style="position:absolute;top:calc(25% + 28px);left:8px;width:10px;height:12px;border-radius:50%;background:#2A2A2A;border:3px solid #3A3A3A;"></div>

    </div><!-- /studio scene -->

    <!-- Hero Content -->
    <div class="po-container" style="position:relative;z-index:2;padding-bottom:5rem;max-width:50%;">
      <div style="display:inline-flex;align-items:center;gap:.6rem;background:rgba(255,77,0,.12);border:1px solid rgba(255,77,0,.3);border-radius:2px;padding:.3rem .85rem;margin-bottom:1.5rem;">
        <span style="width:7px;height:7px;border-radius:50%;background:var(--po-flame);box-shadow:0 0 8px var(--po-flame);animation:po-blink 1.5s step-end infinite;" aria-hidden="true"></span>
        <span style="font-family:'Space Grotesk',sans-serif;font-size:.65rem;letter-spacing:.18em;text-transform:uppercase;color:var(--po-flame);">Live every Tuesday</span>
      </div>
      <style>@keyframes po-blink{0%,100%{opacity:1;}50%{opacity:0;}}</style>
      <h1 id="po-hero-title" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(3rem,6vw,5.5rem);font-weight:700;color:#ffffff;line-height:.95;letter-spacing:-.04em;margin:0 0 1.25rem;">The Long<br>View<br><span style="color:var(--po-butter);">Podcast.</span></h1>
      <p style="font-size:1rem;color:rgba(240,240,238,.6);max-width:400px;line-height:1.75;margin:0 0 2.5rem;">Deep conversations with the people reshaping ideas, institutions, and industries. No hot takes. No filler. Just thinking.</p>
      <div style="display:flex;gap:1rem;flex-wrap:wrap;align-items:center;">
        <a href="<?php echo esc_url(home_url('/listen/latest')); ?>" style="display:inline-flex;align-items:center;gap:.6rem;padding:.9rem 2rem;background:var(--po-flame);color:#ffffff;font-family:'Space Grotesk',sans-serif;font-size:.78rem;font-weight:600;letter-spacing:.12em;text-transform:uppercase;text-decoration:none;border-radius:2px;"><span aria-hidden="true">&#9654;</span> Latest Episode</a>
        <a href="<?php echo esc_url(home_url('/episodes')); ?>" style="display:inline-block;padding:.9rem 2rem;border:1px solid rgba(255,255,255,.15);color:rgba(240,240,238,.7);font-family:'Space Grotesk',sans-serif;font-size:.78rem;letter-spacing:.12em;text-transform:uppercase;text-decoration:none;border-radius:2px;">All Episodes</a>
      </div>
    </div>

    <!-- Bottom gradient -->
    <div aria-hidden="true" style="position:absolute;bottom:0;left:0;right:0;height:200px;background:linear-gradient(0deg,var(--po-ink) 0%,transparent 100%);pointer-events:none;"></div>
  </section>

  <!-- STATS BAR ───────────────────────────────────────────── -->
  <div style="background:var(--po-ink);border-bottom:1px solid rgba(255,255,255,.06);">
    <div class="po-container">
      <div style="display:grid;grid-template-columns:repeat(4,1fr);">
        <?php foreach($po_stats as $si=>$st): ?>
        <div class="po-reveal" style="transition-delay:<?php echo $si*60; ?>ms;text-align:center;padding:2.5rem 1rem;border-left:<?php echo $si===0?'none':'1px solid rgba(255,255,255,.06)'; ?>;">
          <p style="font-family:'Space Grotesk',sans-serif;font-size:2rem;font-weight:700;color:var(--po-butter);margin:0 0 .25rem;line-height:1;"><?php echo esc_html($st['n']); ?></p>
          <p style="font-family:'DM Sans',sans-serif;font-size:.72rem;letter-spacing:.16em;text-transform:uppercase;color:var(--po-slate);margin:0;"><?php echo esc_html($st['l']); ?></p>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- LATEST EPISODE FEATURE ─────────────────────────────── -->
  <section class="po-section" style="background:var(--po-mid);" aria-labelledby="po-latest-title">
    <?php $ep0 = $po_episodes[0]; ?>
    <div class="po-container">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:5rem;align-items:center;">
        <!-- Episode art -->
        <div class="po-reveal" style="aspect-ratio:1;background:<?php echo esc_attr($ep0['color']); ?>;border-radius:6px;position:relative;overflow:hidden;">
          <!-- Waveform visual -->
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;gap:3px;padding:2rem 3rem;">
            <?php for($wb=0;$wb<40;$wb++){
              $wbh = rand(10,100);
              $wbc = $wb>18&&$wb<24?'var(--po-flame)':'rgba(255,229,102,'.rand(10,35)/100.')';
            ?>
            <div style="flex:1;min-width:0;height:<?php echo $wbh; ?>%;background:<?php echo $wbc; ?>;border-radius:2px;"></div>
            <?php } ?>
          </div>
          <!-- Episode number -->
          <div style="position:absolute;bottom:2rem;left:2rem;font-family:'Space Grotesk',sans-serif;font-size:5rem;font-weight:700;color:rgba(255,255,255,.04);line-height:1;">EP<?php echo esc_html($ep0['ep']); ?></div>
          <!-- Popular badge -->
          <?php if($ep0['popular']): ?>
          <div style="position:absolute;top:1.5rem;right:1.5rem;background:var(--po-flame);color:#ffffff;font-family:'Space Grotesk',sans-serif;font-size:.6rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;padding:.3rem .7rem;border-radius:2px;">&#9733; Popular</div>
          <?php endif; ?>
          <!-- Play overlay -->
          <a href="<?php echo esc_url(home_url('/episodes/'.sanitize_title($ep0['title']))); ?>" style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.0);text-decoration:none;" aria-label="Play episode <?php echo esc_attr($ep0['ep']); ?>">
            <div style="width:72px;height:72px;border-radius:50%;background:rgba(255,77,0,.15);border:2px solid rgba(255,77,0,.4);display:flex;align-items:center;justify-content:center;color:var(--po-flame);font-size:1.5rem;transition:background .3s;">&#9654;</div>
          </a>
        </div>
        <!-- Episode info -->
        <div class="po-reveal" style="transition-delay:100ms;">
          <p class="po-eyebrow">Latest Episode</p>
          <p style="font-family:'Space Grotesk',sans-serif;font-size:.7rem;letter-spacing:.1em;color:rgba(255,255,255,.3);margin:0 0 .75rem;">#<?php echo esc_html($ep0['ep']); ?> · <?php echo esc_html($ep0['date']); ?> · <?php echo esc_html($ep0['duration']); ?></p>
          <h2 id="po-latest-title" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(1.5rem,2.5vw,2.25rem);font-weight:700;color:#ffffff;letter-spacing:-.03em;margin:0 0 .75rem;line-height:1.15;"><?php echo esc_html($ep0['title']); ?></h2>
          <p style="font-size:.9rem;color:var(--po-slate);margin:0 0 .25rem;">With <strong style="color:rgba(255,255,255,.65);"><?php echo esc_html($ep0['guest']); ?></strong></p>
          <p style="font-size:.82rem;color:var(--po-slate);margin:0 0 2rem;"><?php echo esc_html($ep0['guestRole']); ?></p>
          <!-- Tags -->
          <div style="display:flex;flex-wrap:wrap;gap:.5rem;margin-bottom:2rem;">
            <?php foreach($ep0['tags'] as $tag): ?>
            <span style="padding:.25rem .7rem;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:2px;font-family:'Space Grotesk',sans-serif;font-size:.65rem;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.5);"><?php echo esc_html($tag); ?></span>
            <?php endforeach; ?>
          </div>
          <div style="display:flex;gap:1rem;">
            <a href="<?php echo esc_url(home_url('/episodes/'.sanitize_title($ep0['title']))); ?>" style="padding:.85rem 2rem;background:var(--po-flame);color:#ffffff;font-family:'Space Grotesk',sans-serif;font-size:.78rem;font-weight:600;letter-spacing:.12em;text-transform:uppercase;text-decoration:none;border-radius:2px;">Listen Now</a>
            <a href="<?php echo esc_url(home_url('/episodes/'.sanitize_title($ep0['title']).'/notes')); ?>" style="padding:.85rem 2rem;border:1px solid rgba(255,255,255,.12);color:rgba(240,240,238,.65);font-family:'Space Grotesk',sans-serif;font-size:.78rem;letter-spacing:.12em;text-transform:uppercase;text-decoration:none;border-radius:2px;">Show Notes</a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- EPISODE LIST ────────────────────────────────────────── -->
  <section class="po-section" style="background:var(--po-ink);" aria-labelledby="po-episodes-title">
    <div class="po-container">
      <div style="display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:3rem;flex-wrap:wrap;gap:1.5rem;">
        <div class="po-reveal">
          <p class="po-eyebrow">Archive</p>
          <h2 id="po-episodes-title" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(2rem,3vw,2.75rem);font-weight:700;color:#ffffff;letter-spacing:-.03em;margin:0;">Recent Episodes</h2>
        </div>
        <a href="<?php echo esc_url(home_url('/episodes')); ?>" class="po-reveal" style="padding:.75rem 1.75rem;border:1px solid rgba(255,255,255,.12);color:rgba(240,240,238,.65);font-family:'Space Grotesk',sans-serif;font-size:.75rem;letter-spacing:.12em;text-transform:uppercase;text-decoration:none;border-radius:2px;">View All</a>
      </div>
      <div style="border-top:1px solid rgba(255,255,255,.07);">
        <?php foreach($po_episodes as $ei=>$ep): ?>
        <div class="po-episode po-reveal" style="transition-delay:<?php echo $ei*60; ?>ms;" role="article">
          <!-- Episode number -->
          <div style="font-family:'Space Grotesk',sans-serif;font-size:.75rem;font-weight:600;color:var(--po-slate);text-align:right;">#<?php echo esc_html($ep['ep']); ?></div>
          <!-- Episode info -->
          <div>
            <div style="display:flex;align-items:center;gap:.75rem;margin-bottom:.3rem;flex-wrap:wrap;">
              <a href="<?php echo esc_url(home_url('/episodes/'.sanitize_title($ep['title']))); ?>" style="font-family:'Space Grotesk',sans-serif;font-size:1rem;font-weight:600;color:#ffffff;text-decoration:none;line-height:1.3;"><?php echo esc_html($ep['title']); ?></a>
              <?php if($ep['popular']): ?>
              <span style="font-family:'Space Grotesk',sans-serif;font-size:.55rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--po-flame);border:1px solid rgba(255,77,0,.3);border-radius:2px;padding:.1rem .4rem;">Hot</span>
              <?php endif; ?>
            </div>
            <p style="font-size:.82rem;color:var(--po-slate);margin:0 0 .5rem;"><?php echo esc_html($ep['guest']); ?> · <?php echo esc_html($ep['guestRole']); ?></p>
            <div style="display:flex;gap:.5rem;flex-wrap:wrap;">
              <?php foreach($ep['tags'] as $tag): ?>
              <span style="font-size:.62rem;color:rgba(255,255,255,.3);border:1px solid rgba(255,255,255,.08);border-radius:2px;padding:.1rem .4rem;font-family:'Space Grotesk',sans-serif;letter-spacing:.08em;"><?php echo esc_html($tag); ?></span>
              <?php endforeach; ?>
            </div>
          </div>
          <!-- Duration / date / play -->
          <div style="display:flex;flex-direction:column;align-items:flex-end;gap:.5rem;flex-shrink:0;">
            <span style="font-family:'Space Grotesk',sans-serif;font-size:.75rem;color:var(--po-slate);"><?php echo esc_html($ep['duration']); ?></span>
            <span style="font-size:.7rem;color:rgba(255,255,255,.25);"><?php echo esc_html($ep['date']); ?></span>
            <a href="<?php echo esc_url(home_url('/episodes/'.sanitize_title($ep['title']))); ?>" style="width:36px;height:36px;border-radius:50%;background:rgba(255,77,0,.1);border:1px solid rgba(255,77,0,.2);display:flex;align-items:center;justify-content:center;color:var(--po-flame);font-size:.8rem;text-decoration:none;" aria-label="Play <?php echo esc_attr($ep['title']); ?>">&#9654;</a>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- FEATURED GUESTS ─────────────────────────────────────── -->
  <section class="po-section" style="background:var(--po-mid);" aria-labelledby="po-guests-title">
    <div class="po-container">
      <div class="po-reveal" style="text-align:center;margin-bottom:4rem;">
        <p class="po-eyebrow">Conversations</p>
        <h2 id="po-guests-title" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(2rem,3vw,2.75rem);font-weight:700;color:#ffffff;letter-spacing:-.03em;margin:0;">Notable Guests</h2>
      </div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:1.5rem;">
        <?php foreach($po_guests as $gi=>$g): ?>
        <article class="po-reveal" style="transition-delay:<?php echo $gi*80; ?>ms;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:4px;padding:2rem;text-align:center;cursor:pointer;transition:border-color .3s,background .3s;" onmouseenter="this.style.borderColor='rgba(255,77,0,.25)';this.style.background='rgba(255,77,0,.04)'" onmouseleave="this.style.borderColor='rgba(255,255,255,.07)';this.style.background='rgba(255,255,255,.03)'">
          <!-- CSS portrait -->
          <div style="width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,<?php echo esc_attr($g['skin']); ?>,<?php echo esc_attr($g['skin']); ?>);margin:0 auto 1.25rem;position:relative;overflow:hidden;border:3px solid rgba(255,255,255,.07);">
            <div style="position:absolute;top:-3px;left:0;right:0;height:40%;background:<?php echo esc_attr($g['hair']); ?>;border-radius:50% 50% 0 0;"></div>
            <div style="position:absolute;bottom:-3px;left:50%;transform:translateX(-50%);width:50px;height:20px;background:rgba(255,255,255,.15);border-radius:50% 50% 0 0;"></div>
          </div>
          <h3 style="font-family:'Space Grotesk',sans-serif;font-size:.95rem;font-weight:600;color:#ffffff;margin:0 0 .25rem;"><?php echo esc_html($g['name']); ?></h3>
          <p style="font-size:.78rem;color:var(--po-slate);margin:0 0 .2rem;"><?php echo esc_html($g['role']); ?></p>
          <p style="font-size:.72rem;color:rgba(255,255,255,.25);margin:0 0 1.25rem;"><?php echo esc_html($g['org']); ?></p>
          <a href="<?php echo esc_url(home_url('/episodes/?ep='.$g['ep'])); ?>" style="font-family:'Space Grotesk',sans-serif;font-size:.65rem;letter-spacing:.12em;text-transform:uppercase;color:var(--po-flame);text-decoration:none;border-bottom:1px solid rgba(255,77,0,.3);padding-bottom:1px;">Ep #<?php echo esc_html($g['ep']); ?> &#8594;</a>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- LISTEN ON PLATFORMS ─────────────────────────────────── -->
  <section style="background:var(--po-ink);padding:5rem 0;border-top:1px solid rgba(255,255,255,.05);" aria-labelledby="po-platforms-title">
    <div class="po-container">
      <div class="po-reveal" style="text-align:center;margin-bottom:3rem;">
        <p class="po-eyebrow">Available On</p>
        <h2 id="po-platforms-title" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(1.75rem,2.5vw,2.5rem);font-weight:700;color:#ffffff;letter-spacing:-.03em;margin:0;">Listen Everywhere</h2>
      </div>
      <div style="display:grid;grid-template-columns:repeat(6,1fr);gap:1rem;">
        <?php foreach($po_platforms as $pli=>$pl): ?>
        <a href="<?php echo esc_url(home_url('/listen/'.sanitize_title($pl['n']))); ?>" class="po-reveal" style="transition-delay:<?php echo $pli*50; ?>ms;display:flex;flex-direction:column;align-items:center;gap:.75rem;padding:1.75rem 1rem;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:4px;text-decoration:none;transition:border-color .3s,background .3s;" aria-label="Listen on <?php echo esc_attr($pl['n']); ?>" onmouseenter="this.style.borderColor='rgba(255,255,255,.18)';this.style.background='rgba(255,255,255,.05)'" onmouseleave="this.style.borderColor='rgba(255,255,255,.07)';this.style.background='rgba(255,255,255,.03)'">
          <span aria-hidden="true" style="font-size:1.5rem;color:<?php echo esc_attr($pl['color']); ?>;"><?php echo $pl['ic']; ?></span>
          <span style="font-family:'Space Grotesk',sans-serif;font-size:.7rem;font-weight:500;color:rgba(255,255,255,.5);text-align:center;"><?php echo esc_html($pl['n']); ?></span>
        </a>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- SUBSCRIBE / NEWSLETTER ──────────────────────────────── -->
  <section style="background:var(--po-flame);padding:6rem 0;position:relative;overflow:hidden;" aria-labelledby="po-subscribe-title">
    <div aria-hidden="true" style="position:absolute;top:-50%;right:-10%;width:700px;height:700px;border-radius:50%;background:rgba(0,0,0,.08);pointer-events:none;"></div>
    <div class="po-container" style="position:relative;z-index:1;">
      <div style="max-width:640px;margin:0 auto;text-align:center;">
        <p style="font-family:'Space Grotesk',sans-serif;font-size:.7rem;letter-spacing:.28em;text-transform:uppercase;color:rgba(255,255,255,.7);margin-bottom:.75rem;">Newsletter</p>
        <h2 id="po-subscribe-title" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(2rem,4vw,3.5rem);font-weight:700;color:#ffffff;letter-spacing:-.04em;margin:0 0 1rem;line-height:1.05;">Ideas worth subscribing to.</h2>
        <p style="font-family:'DM Sans',sans-serif;font-size:1rem;color:rgba(255,255,255,.75);line-height:1.7;margin:0 0 2.5rem;">Get the show notes, guest links, and a hand-curated reading list delivered to your inbox every week.</p>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:flex;gap:.75rem;max-width:480px;margin:0 auto 1.25rem;" novalidate>
          <input type="hidden" name="action" value="tf_po_subscribe">
          <?php wp_nonce_field('tf_po_subscribe','tf_po_nonce'); ?>
          <label for="po-sub-email" class="screen-reader-text"><?php esc_html_e('Email address','themeflex'); ?></label>
          <input type="email" id="po-sub-email" name="email" placeholder="your@email.com" required style="flex:1;padding:.9rem 1rem;background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.3);border-radius:2px;color:#ffffff;font-family:'DM Sans',sans-serif;font-size:.875rem;outline:none;" aria-required="true">
          <button type="submit" style="padding:.9rem 1.5rem;background:#ffffff;color:var(--po-flame);font-family:'Space Grotesk',sans-serif;font-size:.75rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;border:none;border-radius:2px;cursor:pointer;white-space:nowrap;">Subscribe</button>
        </form>
        <p style="font-family:'DM Sans',sans-serif;font-size:.75rem;color:rgba(255,255,255,.55);">11,400+ subscribers. No spam. Unsubscribe anytime.</p>
      </div>
    </div>
  </section>

  <!-- REVIEWS ─────────────────────────────────────────────── -->
  <section class="po-section" style="background:var(--po-mid);" aria-labelledby="po-reviews-title">
    <div class="po-container">
      <div class="po-reveal" style="text-align:center;margin-bottom:4rem;">
        <p class="po-eyebrow">Listener Reviews</p>
        <h2 id="po-reviews-title" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(2rem,3vw,2.75rem);font-weight:700;color:#ffffff;letter-spacing:-.03em;margin:0 0 .5rem;">What Listeners Say</h2>
        <p style="font-size:.85rem;color:var(--po-slate);">&#9733;&#9733;&#9733;&#9733;&#9733; &nbsp; 4.9 average from 6,200 ratings</p>
      </div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:1.5rem;">
        <?php
        $po_reviews=[
          ['name'=>'Francesca B.','text'=>"The Long View is the only podcast I listen to on 1x speed. Every episode feels like it opens a window I didn't know was there.",'src'=>'Apple Podcasts'],
          ['name'=>'Nathan K.','text'=>"Finally a show for people who've grown tired of 3-minute takes. Priya Narayan's episode genuinely changed how I think about remote work.",'src'=>'Spotify'],
          ['name'=>'Dr M. Obi','text'=>"The host asks better questions than most journalists. The Amara Osei climate episode should be mandatory listening.",'src'=>'Apple Podcasts'],
        ];
        foreach($po_reviews as $pri=>$pr):?>
        <blockquote class="po-reveal" style="transition-delay:<?php echo $pri*90; ?>ms;margin:0;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:4px;padding:2rem;position:relative;">
          <div style="display:flex;gap:.25rem;margin-bottom:1rem;" aria-label="5 stars">
            <?php for($s=0;$s<5;$s++) echo '<span aria-hidden="true" style="color:var(--po-butter);font-size:.85rem;">&#9733;</span>'; ?>
          </div>
          <p style="font-family:'DM Sans',sans-serif;font-size:.9rem;color:rgba(240,240,238,.7);line-height:1.7;margin:0 0 1.25rem;"><?php echo esc_html($pr['text']); ?></p>
          <footer style="display:flex;align-items:center;justify-content:space-between;">
            <p style="font-family:'Space Grotesk',sans-serif;font-size:.8rem;font-weight:600;color:#ffffff;margin:0;"><?php echo esc_html($pr['name']); ?></p>
            <p style="font-size:.7rem;color:var(--po-slate);margin:0;"><?php echo esc_html($pr['src']); ?></p>
          </footer>
        </blockquote>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

</div><!-- /.po-page -->

<script>
(function(){
  'use strict';
  var obs=new IntersectionObserver(function(e){e.forEach(function(el){if(el.isIntersecting){el.target.classList.add('po-visible');obs.unobserve(el.target);}});},{threshold:.08});
  document.querySelectorAll('.po-reveal').forEach(function(el){obs.observe(el);});
})();
</script>


<?php
/* ─────────────────────────────────────────────────────────────
   ABOUT THE HOST
   ───────────────────────────────────────────────────────────── */
$po_host_credits = [
  'Former investigative journalist, The Guardian (2010–2018)',
  'Host, "Policy & Practice" podcast (2018–2022) — 22M downloads',
  'Visiting Fellow, Reuters Institute for the Study of Journalism',
  'Author, "The Attention Economy and the Collapse of Context" (2021)',
  'Two-time Webby Award winner for audio journalism',
];
?>
<!-- HOST BIO ─────────────────────────────────────────────── -->
<section class="po-section" style="background:var(--po-ink);border-top:1px solid rgba(255,255,255,.06);" aria-labelledby="po-host-title">
  <div class="po-container">
    <div style="display:grid;grid-template-columns:1fr 1.6fr;gap:5rem;align-items:start;">
      <!-- Host portrait (CSS) -->
      <div class="po-reveal">
        <div style="position:relative;width:100%;max-width:380px;">
          <!-- Main portrait block -->
          <div style="aspect-ratio:.85;background:linear-gradient(180deg,#1A1208 0%,#0D0D0D 100%);border-radius:6px;overflow:hidden;position:relative;">
            <!-- Person figure -->
            <div style="position:absolute;bottom:0;left:50%;transform:translateX(-50%);width:70%;height:85%;">
              <!-- Head -->
              <div style="position:absolute;top:0;left:50%;transform:translateX(-50%);width:56px;height:56px;border-radius:50%;background:#B87A5A;"></div>
              <!-- Hair -->
              <div style="position:absolute;top:-4px;left:calc(50% - 28px);width:56px;height:26px;background:#180E06;border-radius:50% 50% 0 0;"></div>
              <!-- Body / jacket -->
              <div style="position:absolute;top:52px;left:calc(50% - 40px);width:80px;height:100px;background:var(--po-ink);border-radius:4px 4px 0 0;"></div>
              <!-- Collar / shirt -->
              <div style="position:absolute;top:52px;left:calc(50% - 12px);width:24px;height:36px;background:rgba(255,255,255,.15);border-radius:0 0 4px 4px;"></div>
              <!-- Headphones -->
              <div style="position:absolute;top:-2px;left:calc(50% - 36px);width:72px;height:24px;border-radius:50% 50% 0 0;border:5px solid #333;background:transparent;border-bottom:none;"></div>
              <div style="position:absolute;top:20px;left:calc(50% - 38px);width:12px;height:16px;border-radius:50%;background:#222;border:3px solid #333;"></div>
              <div style="position:absolute;top:20px;right:calc(50% - 38px);width:12px;height:16px;border-radius:50%;background:#222;border:3px solid #333;"></div>
              <!-- Mic in front -->
              <div style="position:absolute;top:30px;left:calc(50% + 14px);width:3px;height:50px;background:rgba(255,255,255,.25);"></div>
              <div style="position:absolute;top:18px;left:calc(50% + 8px);width:18px;height:24px;border-radius:10px;background:#3A3A3A;border:2px solid #555;"></div>
            </div>
            <!-- Waveform at feet -->
            <div style="position:absolute;bottom:0;left:0;right:0;height:25%;display:flex;align-items:flex-end;gap:2px;padding:0 1rem;opacity:.3;">
              <?php for($hb=0;$hb<30;$hb++) echo '<div style="flex:1;height:'.rand(10,100).'%;background:var(--po-flame);border-radius:1px 1px 0 0;min-width:0;"></div>'; ?>
            </div>
            <!-- Flame glow -->
            <div aria-hidden="true" style="position:absolute;inset:0;background:radial-gradient(ellipse at 50% 80%,rgba(255,77,0,.08) 0%,transparent 60%);pointer-events:none;"></div>
          </div>
          <!-- Stats overlay card -->
          <div style="position:absolute;bottom:-1.5rem;right:-1.5rem;background:var(--po-flame);border-radius:4px;padding:1.25rem 1.5rem;min-width:140px;">
            <p style="font-family:'Space Grotesk',sans-serif;font-size:2rem;font-weight:700;color:#ffffff;margin:0 0 .15rem;line-height:1;">8</p>
            <p style="font-family:'DM Sans',sans-serif;font-size:.72rem;color:rgba(255,255,255,.75);margin:0;letter-spacing:.06em;">years in audio journalism</p>
          </div>
        </div>
      </div>
      <!-- Bio text -->
      <div class="po-reveal" style="transition-delay:120ms;">
        <p class="po-eyebrow">Your Host</p>
        <h2 id="po-host-title" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(2rem,3vw,3rem);font-weight:700;color:#ffffff;letter-spacing:-.03em;margin:0 0 1.5rem;line-height:1.05;">Maya Okonkwo</h2>
        <div style="display:flex;flex-direction:column;gap:1rem;margin-bottom:2.5rem;">
          <p style="font-family:'DM Sans',sans-serif;font-size:.975rem;color:rgba(240,240,238,.65);line-height:1.8;margin:0;">Maya spent eight years as an investigative journalist before leaving print to explore what long-form audio could do that print couldn't. The answer, she discovered, was nuance at scale.</p>
          <p style="font-family:'DM Sans',sans-serif;font-size:.975rem;color:rgba(240,240,238,.45);line-height:1.8;margin:0;">She created The Long View after becoming frustrated with the speed of news. Every episode is the result of weeks of research, pre-interviews, and genuine curiosity — no prep sheets, no talking points, no publicists on the line.</p>
        </div>
        <!-- Credits list -->
        <div style="border-top:1px solid rgba(255,255,255,.07);padding-top:1.75rem;">
          <p style="font-family:'Space Grotesk',sans-serif;font-size:.65rem;letter-spacing:.2em;text-transform:uppercase;color:var(--po-slate);margin-bottom:1.25rem;">Background</p>
          <ul style="list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:.85rem;">
            <?php foreach($po_host_credits as $credit): ?>
            <li style="display:flex;align-items:flex-start;gap:.85rem;font-family:'DM Sans',sans-serif;font-size:.875rem;color:rgba(240,240,238,.55);line-height:1.5;">
              <span style="color:var(--po-flame);font-size:.7rem;margin-top:3px;flex-shrink:0;">&#9679;</span>
              <?php echo esc_html($credit); ?>
            </li>
            <?php endforeach; ?>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

<?php
/* ─────────────────────────────────────────────────────────────
   SPONSORSHIP / ADVERTISING
   ───────────────────────────────────────────────────────────── */
$po_sponsor_tiers = [
  ['name'=>'Spot Ad','price'=>'£1,200','unit'=>'per episode','desc'=>'30-second host-read ad, placed mid-roll. Full script review and approval. Works best for direct-response campaigns.','inc'=>['Host-read script','Mid-roll placement','Episode show notes mention','Performance report'],'featured'=>false],
  ['name'=>'Presenting Partner','price'=>'£3,800','unit'=>'per episode','desc'=>'Full presenting sponsorship with pre-roll, mid-roll, and post-roll. Brand mentioned in intro and show notes. Priority for episode tie-in.','inc'=>['Pre-, mid- & post-roll','"Presented by" credit in intro','Social media post','Show notes feature','Monthly analytics'],'featured'=>true],
  ['name'=>'Series Partner','price'=>'Custom','unit'=>'per series','desc'=>'Exclusive partnership across a themed run of 4–8 episodes. Deep brand integration, co-created content, live event access.','inc'=>['All Presenting benefits','Content co-creation','Dedicated landing page','Live event access','Custom analytics dashboard'],'featured'=>false],
];
?>
<!-- SPONSOR ──────────────────────────────────────────────── -->
<section class="po-section" style="background:var(--po-mid);" aria-labelledby="po-sponsor-title">
  <div class="po-container">
    <div class="po-reveal" style="text-align:center;margin-bottom:4rem;">
      <p class="po-eyebrow">Partnerships</p>
      <h2 id="po-sponsor-title" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(2rem,3vw,2.75rem);font-weight:700;color:#ffffff;letter-spacing:-.03em;margin:0 0 1rem;">Reach a Thinking Audience</h2>
      <p style="font-family:'DM Sans',sans-serif;font-size:.95rem;color:var(--po-slate);max-width:540px;margin:0 auto;line-height:1.7;">Our listeners are educated, curious, and loyal — 78% of whom listen to every episode. Partner with The Long View to reach decision-makers who act on good ideas.</p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:1.5rem;margin-bottom:4rem;align-items:start;">
      <?php foreach($po_sponsor_tiers as $sti=>$tier): ?>
      <div class="po-reveal" style="transition-delay:<?php echo $sti*90; ?>ms;background:<?php echo $tier['featured']?'var(--po-flame)':'rgba(255,255,255,.03)'; ?>;border:1px solid <?php echo $tier['featured']?'var(--po-flame)':'rgba(255,255,255,.07)'; ?>;border-radius:4px;padding:2.25rem 2rem;position:relative;<?php echo $tier['featured']?'transform:scale(1.03);':''; ?>">
        <?php if($tier['featured']): ?>
        <div style="position:absolute;top:-12px;left:50%;transform:translateX(-50%);background:var(--po-butter);color:var(--po-ink);font-family:'Space Grotesk',sans-serif;font-size:.6rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;padding:.25rem .85rem;border-radius:2px;">Most Popular</div>
        <?php endif; ?>
        <p style="font-family:'Space Grotesk',sans-serif;font-size:.7rem;letter-spacing:.18em;text-transform:uppercase;color:<?php echo $tier['featured']?'rgba(255,255,255,.7)':'var(--po-slate)'; ?>;margin:0 0 .75rem;"><?php echo esc_html($tier['name']); ?></p>
        <div style="margin-bottom:1.5rem;">
          <span style="font-family:'Space Grotesk',sans-serif;font-size:2.25rem;font-weight:700;color:#ffffff;line-height:1;"><?php echo esc_html($tier['price']); ?></span>
          <span style="font-size:.78rem;color:<?php echo $tier['featured']?'rgba(255,255,255,.6)':'var(--po-slate)'; ?>;margin-left:.3rem;"><?php echo esc_html($tier['unit']); ?></span>
        </div>
        <p style="font-family:'DM Sans',sans-serif;font-size:.85rem;color:<?php echo $tier['featured']?'rgba(255,255,255,.75)':'rgba(240,240,238,.5)'; ?>;line-height:1.65;margin:0 0 1.75rem;"><?php echo esc_html($tier['desc']); ?></p>
        <ul style="list-style:none;padding:0;margin:0 0 2rem;display:flex;flex-direction:column;gap:.65rem;">
          <?php foreach($tier['inc'] as $inc): ?>
          <li style="display:flex;align-items:flex-start;gap:.6rem;font-family:'DM Sans',sans-serif;font-size:.82rem;color:<?php echo $tier['featured']?'rgba(255,255,255,.85)':'rgba(240,240,238,.55)'; ?>;line-height:1.4;">
            <span aria-hidden="true" style="margin-top:2px;flex-shrink:0;">&#10003;</span>
            <?php echo esc_html($inc); ?>
          </li>
          <?php endforeach; ?>
        </ul>
        <a href="<?php echo esc_url(home_url('/advertise')); ?>" style="display:block;text-align:center;padding:.85rem 1.5rem;background:<?php echo $tier['featured']?'#ffffff':'rgba(255,255,255,.08)'; ?>;color:<?php echo $tier['featured']?'var(--po-flame)':'#ffffff'; ?>;font-family:'Space Grotesk',sans-serif;font-size:.75rem;font-weight:600;letter-spacing:.12em;text-transform:uppercase;text-decoration:none;border-radius:2px;">Enquire</a>
      </div>
      <?php endforeach; ?>
    </div>
    <!-- Audience data strip -->
    <div class="po-reveal" style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:4px;padding:2.5rem;display:grid;grid-template-columns:repeat(5,1fr);gap:2rem;">
      <?php
      $po_aud=[['n'=>'72%','l'=>'Age 28–45'],['n'=>'68%','l'=>'University educated'],['n'=>'4.2M','l'=>'Monthly downloads'],['n'=>'11.4K','l'=>'Newsletter subs'],['n'=>'78%','l'=>'Listen every ep']];
      foreach($po_aud as $ai=>$ad):?>
      <div style="text-align:center;<?php echo $ai>0?'border-left:1px solid rgba(255,255,255,.07);':''; ?>">
        <p style="font-family:'Space Grotesk',sans-serif;font-size:1.5rem;font-weight:700;color:var(--po-butter);margin:0 0 .25rem;line-height:1;"><?php echo esc_html($ad['n']); ?></p>
        <p style="font-family:'DM Sans',sans-serif;font-size:.7rem;letter-spacing:.12em;text-transform:uppercase;color:var(--po-slate);margin:0;"><?php echo esc_html($ad['l']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php
/* ─────────────────────────────────────────────────────────────
   FAQ
   ───────────────────────────────────────────────────────────── */
$po_faqs = [
  ['q'=>'How often do new episodes come out?','a'=>'New episodes drop every Tuesday morning. We occasionally release bonus episodes — short solo conversations or excerpts from live events — on Fridays.'],
  ['q'=>'How do I suggest a guest or topic?','a'=>'We genuinely read every suggestion sent via the contact form. We can\'t respond to every one, but good ideas do surface. The best suggestions come with a brief explanation of why this guest or topic deserves a long conversation.'],
  ['q'=>'Is there a transcript I can read?','a'=>'Yes — full transcripts are published on the episode page within 24 hours of release. Transcripts are lightly edited for clarity but preserve the original conversation faithfully.'],
  ['q'=>'How can my organisation advertise on The Long View?','a'=>'Please use the sponsorship enquiry form above. We respond to all advertising enquiries within 2–3 business days. Note that we only work with brands whose products we can genuinely endorse.'],
  ['q'=>'Can I use clips from the show?','a'=>'Short clips (under 60 seconds) for non-commercial sharing are permitted with attribution. For any commercial use, licensing, or broadcast, please contact us directly.'],
];
?>
<!-- FAQ ─────────────────────────────────────────────────── -->
<section class="po-section" style="background:var(--po-ink);" aria-labelledby="po-faq-title">
  <div class="po-container">
    <div style="display:grid;grid-template-columns:1fr 1.5fr;gap:5rem;align-items:start;">
      <div class="po-reveal">
        <p class="po-eyebrow">Help</p>
        <h2 id="po-faq-title" style="font-family:'Space Grotesk',sans-serif;font-size:clamp(2rem,3vw,3rem);font-weight:700;color:#ffffff;letter-spacing:-.03em;margin:0 0 1.25rem;line-height:1.05;">Frequently<br>Asked</h2>
        <p style="font-family:'DM Sans',sans-serif;font-size:.9rem;color:var(--po-slate);line-height:1.75;margin:0 0 2rem;">Still have questions? Reach out through the contact form or send us a note on Instagram.</p>
        <div style="display:flex;gap:1rem;flex-wrap:wrap;">
          <a href="<?php echo esc_url(home_url('/contact')); ?>" style="padding:.85rem 1.75rem;background:var(--po-flame);color:#ffffff;font-family:'Space Grotesk',sans-serif;font-size:.75rem;font-weight:600;letter-spacing:.12em;text-transform:uppercase;text-decoration:none;border-radius:2px;">Contact Us</a>
        </div>
      </div>
      <div class="po-reveal" style="transition-delay:100ms;border-top:1px solid rgba(255,255,255,.07);">
        <?php foreach($po_faqs as $fi=>$fq): ?>
        <div class="po-faq" style="border-bottom:1px solid rgba(255,255,255,.07);">
          <button class="po-faq__q" aria-expanded="false" style="width:100%;display:flex;align-items:flex-start;justify-content:space-between;padding:1.4rem 0;background:none;border:none;cursor:pointer;text-align:left;gap:1.5rem;">
            <span style="font-family:'Space Grotesk',sans-serif;font-size:.95rem;font-weight:500;color:#ffffff;line-height:1.4;"><?php echo esc_html($fq['q']); ?></span>
            <span class="po-faq__icon" aria-hidden="true" style="font-size:1.2rem;color:var(--po-flame);flex-shrink:0;margin-top:2px;transition:transform .3s ease;">+</span>
          </button>
          <div class="po-faq__a" role="region">
            <div class="po-faq__a-inner" style="padding:0 0 1.4rem;">
              <p style="font-family:'DM Sans',sans-serif;font-size:.88rem;color:var(--po-slate);line-height:1.75;margin:0;"><?php echo esc_html($fq['a']); ?></p>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<script>
(function(){
  document.querySelectorAll('.po-faq .po-faq__q').forEach(function(btn){
    btn.addEventListener('click',function(){
      var faq=btn.closest('.po-faq'),
          ans=faq.querySelector('.po-faq__a'),
          inn=faq.querySelector('.po-faq__a-inner'),
          ico=faq.querySelector('.po-faq__icon'),
          open=faq.classList.contains('po-open');
      document.querySelectorAll('.po-faq.po-open').forEach(function(f){
        f.querySelector('.po-faq__a').style.maxHeight='0';
        f.classList.remove('po-open');
        f.querySelector('.po-faq__q').setAttribute('aria-expanded','false');
        var i=f.querySelector('.po-faq__icon');if(i){i.textContent='+';i.style.transform='none';}
      });
      if(!open){
        ans.style.maxHeight=inn.scrollHeight+'px';
        faq.classList.add('po-open');
        btn.setAttribute('aria-expanded','true');
        if(ico){ico.textContent='×';ico.style.transform='rotate(45deg)';}
      }
    });
  });
})();
</script>

<?php get_footer(); ?>
