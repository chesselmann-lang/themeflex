<?php
/**
 * Template Name: Podiatrist
 * Description: Premium Podiatry Clinic page template — full CSS art-directed hero
 */
get_header(); ?>

<!-- GOOGLE FONTS: Space Grotesk + Fraunces -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Fraunces:ital,wght@0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">

<style>
/* ============================================================
   PODIATRIST TEMPLATE — --po-* namespace
   Palette: teal #00897B / coral #FF5252 / sand #F5F0E8 / charcoal #2C3E50
   ============================================================ */
:root {
  --po-teal:       #00897B;
  --po-teal-dk:    #005F56;
  --po-teal-lt:    #4DB6AC;
  --po-coral:      #FF5252;
  --po-coral-lt:   #FF8A80;
  --po-sand:       #F5F0E8;
  --po-sand-dk:    #EDE7D9;
  --po-charcoal:   #2C3E50;
  --po-charcoal-lt:#3D5166;
  --po-white:      #FFFFFF;
  --po-grey:       #7F8C8D;
  --po-radius:     12px;
  --po-shadow:     0 8px 32px rgba(0,137,123,0.15);
  --po-font-head:  'Fraunces', Georgia, serif;
  --po-font-body:  'Space Grotesk', system-ui, sans-serif;
}

.po-wrap * { box-sizing: border-box; margin: 0; padding: 0; }
.po-wrap { font-family: var(--po-font-body); color: var(--po-charcoal); background: var(--po-white); }

/* ── HERO ── */
.po-hero {
  position: relative;
  min-height: 100vh;
  background: linear-gradient(155deg, var(--po-teal-dk) 0%, var(--po-teal) 45%, #26A69A 75%, #80CBC4 100%);
  overflow: hidden;
  display: flex;
  align-items: center;
}

/* Floating hex grid background */
.po-hex-grid {
  position: absolute;
  inset: 0;
  overflow: hidden;
  opacity: 0.06;
}
.po-hex {
  position: absolute;
  width: 60px;
  height: 69px;
  background: var(--po-white);
  clip-path: polygon(50% 0%,100% 25%,100% 75%,50% 100%,0% 75%,0% 25%);
}

/* Cross symbols */
.po-cross {
  position: absolute;
  color: rgba(255,255,255,0.08);
  font-size: 2rem;
  font-weight: 300;
  user-select: none;
}

/* Floating orbs */
.po-orb {
  position: absolute;
  border-radius: 50%;
  filter: blur(60px);
  opacity: 0.2;
}
.po-orb-1 { width: 400px; height: 400px; background: var(--po-coral); top: -100px; right: -100px; animation: po-orb-drift 8s ease-in-out infinite alternate; }
.po-orb-2 { width: 250px; height: 250px; background: #B2DFDB; bottom: -50px; left: 5%; animation: po-orb-drift 6s ease-in-out infinite alternate-reverse; }

@keyframes po-orb-drift {
  from { transform: translate(0,0); }
  to   { transform: translate(30px,-30px); }
}

/* CSS CLINIC SCENE */
.po-scene {
  position: absolute;
  right: 6%;
  bottom: 0;
  width: 420px;
  height: 520px;
}

/* Treatment table */
.po-table {
  position: absolute;
  bottom: 60px;
  left: 50%;
  transform: translateX(-50%);
  width: 280px;
  height: 70px;
  background: linear-gradient(180deg, #ECEFF1 0%, #CFD8DC 100%);
  border-radius: 8px 8px 4px 4px;
  box-shadow: 0 6px 0 #B0BEC5, 0 8px 20px rgba(0,0,0,0.3);
}
.po-table::before {
  content: '';
  position: absolute;
  bottom: -38px;
  left: 30px;
  width: 18px;
  height: 40px;
  background: #B0BEC5;
  border-radius: 0 0 4px 4px;
  box-shadow: 202px 0 0 #B0BEC5;
}
/* Paper roll on table */
.po-table-paper {
  position: absolute;
  top: 8px;
  left: 20px;
  right: 20px;
  height: 54px;
  background: var(--po-white);
  border-radius: 6px;
  border: 2px solid #E0E0E0;
}

/* Patient foot on table */
.po-foot {
  position: absolute;
  bottom: 128px;
  left: 50%;
  transform: translateX(-60px);
}
.po-foot-body {
  width: 90px;
  height: 45px;
  background: linear-gradient(180deg, #FFCCBC 0%, #FFAB91 100%);
  border-radius: 0 30px 20px 10px;
  position: relative;
  box-shadow: 2px 4px 8px rgba(0,0,0,0.2);
}
/* Toes */
.po-toes {
  position: absolute;
  right: -2px;
  top: -10px;
  display: flex;
  gap: 3px;
}
.po-toe {
  width: 12px;
  background: linear-gradient(180deg, #FFCCBC 0%, #FFAB91 100%);
  border-radius: 50% 50% 30% 30%;
  border: 1px solid #FFAB91;
}
.po-toe:nth-child(1) { height: 20px; }
.po-toe:nth-child(2) { height: 18px; }
.po-toe:nth-child(3) { height: 16px; }
.po-toe:nth-child(4) { height: 14px; }
.po-toe:nth-child(5) { height: 11px; width: 10px; }
/* Ankle/leg */
.po-ankle {
  position: absolute;
  left: -10px;
  top: 5px;
  width: 36px;
  height: 60px;
  background: linear-gradient(180deg, #FFCCBC 0%, #FFAB91 100%);
  border-radius: 6px 6px 0 0;
  box-shadow: -2px 0 6px rgba(0,0,0,0.1);
}

/* Podiatrist figure */
.po-figure {
  position: absolute;
  bottom: 118px;
  right: 20px;
}
/* Lab coat */
.po-coat {
  width: 80px;
  height: 110px;
  background: linear-gradient(180deg, #FAFAFA 0%, #F5F5F5 100%);
  border-radius: 12px 12px 6px 6px;
  position: relative;
  border: 2px solid #E0E0E0;
  box-shadow: inset -4px 0 8px rgba(0,0,0,0.05);
}
/* Coat lapels */
.po-coat::before {
  content: '';
  position: absolute;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 20px;
  height: 40px;
  background: var(--po-teal-lt);
  border-radius: 0 0 8px 8px;
}
/* Stethoscope */
.po-coat::after {
  content: '⊕';
  position: absolute;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
  font-size: 14px;
  color: #9E9E9E;
}
.po-head {
  width: 48px;
  height: 48px;
  background: linear-gradient(180deg, #FFCCBC 0%, #FFAB91 100%);
  border-radius: 50%;
  margin: 0 auto 2px;
  position: relative;
}
.po-hair {
  position: absolute;
  top: -4px;
  left: 4px;
  right: 4px;
  height: 22px;
  background: #4E342E;
  border-radius: 50% 50% 10% 10%;
}
.po-head::after {
  content: '';
  position: absolute;
  bottom: 12px;
  left: 50%;
  transform: translateX(-50%);
  width: 16px;
  height: 6px;
  background: transparent;
  border: 2px solid rgba(0,0,0,0.2);
  border-top: none;
  border-radius: 0 0 8px 8px;
}
/* Working arm angled down */
.po-arm {
  position: absolute;
  bottom: -8px;
  left: -16px;
  width: 36px;
  height: 14px;
  background: linear-gradient(90deg, #FAFAFA 0%, #F0F0F0 100%);
  border-radius: 8px;
  transform-origin: right center;
  transform: rotate(35deg);
  border: 1px solid #E0E0E0;
  animation: po-arm-work 2s ease-in-out infinite;
}
.po-arm::after {
  content: '';
  position: absolute;
  right: -8px;
  top: 50%;
  transform: translateY(-50%);
  width: 14px;
  height: 8px;
  background: #B0BEC5;
  border-radius: 3px;
}
@keyframes po-arm-work {
  0%, 100% { transform: rotate(35deg); }
  50%       { transform: rotate(25deg); }
}

/* Tool tray */
.po-tray {
  position: absolute;
  bottom: 100px;
  left: 30px;
  width: 70px;
  height: 50px;
  background: linear-gradient(180deg, #ECEFF1 0%, #CFD8DC 100%);
  border-radius: 6px;
  border: 1px solid #B0BEC5;
}
.po-tray::before {
  content: '';
  position: absolute;
  top: 8px;
  left: 8px;
  right: 8px;
  height: 2px;
  background: #78909C;
  border-radius: 1px;
  box-shadow: 0 10px 0 #78909C, 0 20px 0 #78909C;
}

/* Pulse rings around foot area */
.po-pulse {
  position: absolute;
  bottom: 140px;
  left: 140px;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  border: 2px solid var(--po-coral-lt);
  animation: po-pulse-ring 2s ease-out infinite;
  opacity: 0;
}
.po-pulse:nth-child(2) { animation-delay: 0.7s; }
.po-pulse:nth-child(3) { animation-delay: 1.4s; }
@keyframes po-pulse-ring {
  0%   { transform: scale(0.5); opacity: 0.8; }
  100% { transform: scale(2.5); opacity: 0; }
}

/* Floating badges */
.po-badge {
  position: absolute;
  background: rgba(255,255,255,0.15);
  backdrop-filter: blur(8px);
  border: 1px solid rgba(255,255,255,0.3);
  border-radius: 50px;
  padding: 8px 16px;
  color: var(--po-white);
  font-family: var(--po-font-body);
  font-size: 0.8rem;
  font-weight: 600;
  animation: po-badge-float 4s ease-in-out infinite alternate;
}
.po-badge-1 { top: 60px; left: 20px; animation-delay: 0s; }
.po-badge-2 { top: 130px; left: 40px; animation-delay: 1.5s; }
.po-badge-3 { top: 200px; left: 15px; animation-delay: 0.8s; }
@keyframes po-badge-float {
  from { transform: translateY(0); }
  to   { transform: translateY(-12px); }
}

/* Hero content */
.po-hero-inner {
  position: relative;
  z-index: 2;
  max-width: 1280px;
  margin: 0 auto;
  padding: 120px 5% 80px;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 60px;
  align-items: center;
  width: 100%;
}
.po-hero-text { color: var(--po-white); }
.po-hero-tag {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: rgba(255,255,255,0.15);
  border: 1px solid rgba(255,255,255,0.3);
  border-radius: 50px;
  padding: 6px 16px;
  font-size: 0.8rem;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--po-white);
  margin-bottom: 24px;
}
.po-hero-tag::before {
  content: '';
  width: 8px; height: 8px;
  background: var(--po-coral-lt);
  border-radius: 50%;
  animation: po-pulse-dot 1.5s ease-in-out infinite;
}
@keyframes po-pulse-dot {
  0%, 100% { opacity: 1; transform: scale(1); }
  50%       { opacity: 0.4; transform: scale(0.6); }
}
.po-hero h1 {
  font-family: var(--po-font-head);
  font-size: clamp(2.4rem, 5vw, 4rem);
  font-weight: 700;
  line-height: 1.1;
  margin-bottom: 20px;
}
.po-hero h1 em {
  font-style: italic;
  color: #B2DFDB;
}
.po-hero-sub {
  font-size: 1.1rem;
  opacity: 0.9;
  line-height: 1.7;
  margin-bottom: 32px;
  max-width: 500px;
}
.po-hero-ctas { display: flex; gap: 16px; flex-wrap: wrap; }
.po-btn-primary {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: var(--po-coral);
  color: var(--po-white);
  padding: 16px 32px;
  border-radius: 50px;
  font-weight: 700;
  font-size: 1rem;
  text-decoration: none;
  transition: all 0.3s;
  box-shadow: 0 4px 20px rgba(255,82,82,0.4);
}
.po-btn-primary:hover { background: var(--po-coral-lt); transform: translateY(-2px); box-shadow: 0 8px 30px rgba(255,82,82,0.5); }
.po-btn-secondary {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: rgba(255,255,255,0.15);
  border: 2px solid rgba(255,255,255,0.5);
  color: var(--po-white);
  padding: 14px 28px;
  border-radius: 50px;
  font-weight: 600;
  font-size: 1rem;
  text-decoration: none;
  transition: all 0.3s;
}
.po-btn-secondary:hover { background: rgba(255,255,255,0.25); border-color: var(--po-white); }

.po-hero-stats {
  display: flex;
  gap: 40px;
  margin-top: 48px;
  padding-top: 32px;
  border-top: 1px solid rgba(255,255,255,0.2);
}
.po-hero-stat { color: var(--po-white); }
.po-hero-stat-num {
  font-family: var(--po-font-head);
  font-size: 2rem;
  font-weight: 700;
  display: block;
}
.po-hero-stat-lbl {
  font-size: 0.8rem;
  opacity: 0.75;
  text-transform: uppercase;
  letter-spacing: 0.06em;
}

/* ── TRUST BAR ── */
.po-trust {
  background: var(--po-charcoal);
  padding: 20px 5%;
}
.po-trust-inner {
  max-width: 1280px;
  margin: 0 auto;
  display: flex;
  align-items: center;
  gap: 40px;
  flex-wrap: wrap;
  justify-content: center;
}
.po-trust-item {
  color: rgba(255,255,255,0.7);
  font-size: 0.85rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 8px;
}
.po-trust-item span { color: var(--po-teal-lt); font-size: 1.1rem; }

/* ── SECTION BASE ── */
.po-section {
  padding: 90px 5%;
}
.po-section-inner { max-width: 1280px; margin: 0 auto; }
.po-section-tag {
  display: inline-block;
  background: rgba(0,137,123,0.1);
  color: var(--po-teal);
  font-size: 0.75rem;
  font-weight: 700;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  padding: 6px 16px;
  border-radius: 50px;
  margin-bottom: 12px;
}
.po-section-title {
  font-family: var(--po-font-head);
  font-size: clamp(1.8rem, 3.5vw, 2.8rem);
  font-weight: 700;
  color: var(--po-charcoal);
  margin-bottom: 16px;
  line-height: 1.2;
}
.po-section-sub {
  color: var(--po-grey);
  font-size: 1.05rem;
  line-height: 1.7;
  max-width: 580px;
}

/* ── CONDITIONS TREATED ── */
.po-conditions {
  background: var(--po-sand);
}
.po-conditions-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 24px;
  margin-top: 48px;
}
.po-condition-card {
  background: var(--po-white);
  border-radius: var(--po-radius);
  padding: 28px 24px;
  border-left: 4px solid var(--po-teal);
  box-shadow: 0 4px 20px rgba(0,0,0,0.06);
  transition: all 0.3s;
  display: flex;
  gap: 16px;
  align-items: flex-start;
}
.po-condition-card:hover { transform: translateY(-4px); box-shadow: var(--po-shadow); border-left-color: var(--po-coral); }
.po-condition-icon {
  width: 48px;
  height: 48px;
  background: linear-gradient(135deg, var(--po-teal) 0%, var(--po-teal-lt) 100%);
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.4rem;
  flex-shrink: 0;
}
.po-condition-card:hover .po-condition-icon { background: linear-gradient(135deg, var(--po-coral) 0%, var(--po-coral-lt) 100%); }
.po-condition-card h3 { font-weight: 700; font-size: 1rem; margin-bottom: 6px; color: var(--po-charcoal); }
.po-condition-card p { font-size: 0.88rem; color: var(--po-grey); line-height: 1.6; }

/* ── ABOUT ── */
.po-about-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 80px;
  align-items: center;
}
/* CSS Podiatrist Portrait */
.po-portrait {
  position: relative;
  display: flex;
  justify-content: center;
  align-items: flex-end;
  height: 420px;
}
.po-portrait-bg {
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, var(--po-sand) 0%, #E0F2F1 100%);
  border-radius: 20px;
}
.po-portrait-fig {
  position: relative;
  z-index: 2;
  display: flex;
  flex-direction: column;
  align-items: center;
}
/* Figure body */
.po-fig-coat {
  width: 100px;
  height: 140px;
  background: linear-gradient(180deg, #FAFAFA 0%, #F5F5F5 100%);
  border-radius: 16px 16px 8px 8px;
  border: 2px solid #E0E0E0;
  position: relative;
  margin-top: 4px;
}
.po-fig-coat::before {
  content: '';
  position: absolute;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 24px;
  height: 50px;
  background: var(--po-teal-lt);
  border-radius: 0 0 12px 12px;
}
.po-fig-coat::after {
  content: 'HCPC';
  position: absolute;
  top: 16px;
  right: 12px;
  font-size: 0.45rem;
  font-weight: 700;
  color: var(--po-teal);
  background: #E0F2F1;
  padding: 2px 5px;
  border-radius: 4px;
}
.po-fig-head {
  width: 60px;
  height: 60px;
  background: linear-gradient(180deg, #FFCCBC 0%, #FFAB91 100%);
  border-radius: 50%;
  position: relative;
}
.po-fig-hair {
  position: absolute;
  top: -6px;
  left: 6px;
  right: 6px;
  height: 28px;
  background: #6D4C41;
  border-radius: 50% 50% 20% 20%;
}
.po-fig-head::after {
  content: '😊';
  position: absolute;
  bottom: 8px;
  left: 50%;
  transform: translateX(-50%);
  font-size: 1.1rem;
}
/* Credential cards floating around portrait */
.po-cred {
  position: absolute;
  background: var(--po-white);
  border-radius: 10px;
  padding: 10px 14px;
  font-size: 0.75rem;
  font-weight: 700;
  color: var(--po-charcoal);
  box-shadow: 0 4px 16px rgba(0,0,0,0.12);
  animation: po-cred-bob 4s ease-in-out infinite alternate;
}
.po-cred-1 { top: 30px; left: -20px; animation-delay: 0s; color: var(--po-teal); border-left: 3px solid var(--po-teal); }
.po-cred-2 { top: 100px; right: -24px; animation-delay: 1s; color: var(--po-coral); border-left: 3px solid var(--po-coral); }
.po-cred-3 { bottom: 80px; right: -20px; animation-delay: 2s; color: var(--po-teal); border-left: 3px solid var(--po-teal); }
@keyframes po-cred-bob {
  from { transform: translateY(0); }
  to   { transform: translateY(-10px); }
}

.po-about-text .po-section-sub { max-width: 100%; }
.po-about-quals {
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin: 28px 0;
}
.po-qual-item {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 0.9rem;
}
.po-qual-icon { color: var(--po-teal); font-size: 1rem; width: 20px; flex-shrink: 0; }
.po-about-quote {
  background: linear-gradient(135deg, var(--po-teal) 0%, var(--po-teal-dk) 100%);
  color: var(--po-white);
  padding: 24px 28px;
  border-radius: var(--po-radius);
  font-family: var(--po-font-head);
  font-size: 1rem;
  font-style: italic;
  line-height: 1.6;
  margin-top: 20px;
}

/* ── SERVICES / TREATMENTS ── */
.po-treatments-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 28px;
  margin-top: 52px;
}
.po-treatment-card {
  background: var(--po-white);
  border-radius: var(--po-radius);
  overflow: hidden;
  box-shadow: 0 4px 20px rgba(0,0,0,0.07);
  transition: all 0.3s;
  border: 1px solid var(--po-sand-dk);
}
.po-treatment-card:hover { transform: translateY(-6px); box-shadow: var(--po-shadow); }
.po-treatment-top {
  height: 8px;
  background: linear-gradient(90deg, var(--po-teal) 0%, var(--po-teal-lt) 100%);
}
.po-treatment-card:nth-child(even) .po-treatment-top {
  background: linear-gradient(90deg, var(--po-coral) 0%, var(--po-coral-lt) 100%);
}
.po-treatment-body { padding: 28px; }
.po-treatment-icon { font-size: 2rem; margin-bottom: 14px; display: block; }
.po-treatment-card h3 {
  font-family: var(--po-font-head);
  font-weight: 700;
  font-size: 1.15rem;
  color: var(--po-charcoal);
  margin-bottom: 10px;
}
.po-treatment-card p { font-size: 0.88rem; color: var(--po-grey); line-height: 1.65; margin-bottom: 16px; }
.po-treatment-price {
  font-weight: 700;
  color: var(--po-teal);
  font-size: 1.05rem;
}
.po-treatment-card:nth-child(even) .po-treatment-price { color: var(--po-coral); }

/* ── PROCESS ── */
.po-process-section {
  background: linear-gradient(135deg, var(--po-charcoal) 0%, var(--po-charcoal-lt) 100%);
}
.po-process-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 32px;
  margin-top: 52px;
}
.po-process-step { text-align: center; position: relative; }
.po-process-step:not(:last-child)::after {
  content: '→';
  position: absolute;
  right: -16px;
  top: 28px;
  color: rgba(255,255,255,0.3);
  font-size: 1.4rem;
}
.po-process-num {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  background: linear-gradient(135deg, var(--po-teal) 0%, var(--po-teal-lt) 100%);
  color: var(--po-white);
  font-family: var(--po-font-head);
  font-size: 1.4rem;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 16px;
  box-shadow: 0 4px 16px rgba(0,137,123,0.4);
}
.po-process-step h3 {
  font-weight: 700;
  color: var(--po-white);
  margin-bottom: 8px;
  font-size: 1rem;
}
.po-process-step p { color: rgba(255,255,255,0.65); font-size: 0.85rem; line-height: 1.6; }
.po-process-section .po-section-tag { background: rgba(77,182,172,0.2); color: var(--po-teal-lt); }
.po-process-section .po-section-title { color: var(--po-white); }
.po-process-section .po-section-sub { color: rgba(255,255,255,0.7); }

/* ── PACKAGES ── */
.po-packages-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 28px;
  margin-top: 52px;
}
.po-package {
  border-radius: var(--po-radius);
  padding: 36px 28px;
  border: 2px solid var(--po-sand-dk);
  background: var(--po-white);
  position: relative;
  transition: all 0.3s;
}
.po-package:hover { box-shadow: var(--po-shadow); }
.po-package-featured {
  background: linear-gradient(135deg, var(--po-teal-dk) 0%, var(--po-teal) 100%);
  border-color: var(--po-teal);
  color: var(--po-white);
  transform: scale(1.03);
}
.po-package-featured:hover { transform: scale(1.06); }
.po-package-badge {
  position: absolute;
  top: -14px;
  left: 50%;
  transform: translateX(-50%);
  background: var(--po-coral);
  color: var(--po-white);
  font-size: 0.7rem;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  padding: 4px 14px;
  border-radius: 50px;
}
.po-package h3 {
  font-family: var(--po-font-head);
  font-size: 1.2rem;
  font-weight: 700;
  margin-bottom: 8px;
}
.po-package-featured h3 { color: var(--po-white); }
.po-pkg-price {
  font-family: var(--po-font-head);
  font-size: 2.4rem;
  font-weight: 700;
  color: var(--po-teal);
  margin: 16px 0 4px;
  line-height: 1;
}
.po-package-featured .po-pkg-price { color: #B2DFDB; }
.po-pkg-desc { font-size: 0.85rem; color: var(--po-grey); margin-bottom: 20px; }
.po-package-featured .po-pkg-desc { color: rgba(255,255,255,0.7); }
.po-pkg-features { list-style: none; margin-bottom: 28px; }
.po-pkg-features li {
  padding: 8px 0;
  border-bottom: 1px solid var(--po-sand-dk);
  font-size: 0.88rem;
  display: flex;
  align-items: center;
  gap: 8px;
}
.po-package-featured .po-pkg-features li { border-bottom-color: rgba(255,255,255,0.15); color: rgba(255,255,255,0.9); }
.po-pkg-features li::before { content: '✓'; color: var(--po-teal); font-weight: 700; }
.po-package-featured .po-pkg-features li::before { color: #B2DFDB; }
.po-pkg-btn {
  display: block;
  text-align: center;
  padding: 14px;
  border-radius: 50px;
  font-weight: 700;
  font-size: 0.9rem;
  text-decoration: none;
  transition: all 0.3s;
  background: var(--po-sand);
  color: var(--po-teal);
  border: 2px solid var(--po-teal);
}
.po-pkg-btn:hover { background: var(--po-teal); color: var(--po-white); }
.po-package-featured .po-pkg-btn {
  background: var(--po-white);
  color: var(--po-teal-dk);
  border-color: var(--po-white);
}
.po-package-featured .po-pkg-btn:hover { background: var(--po-coral); color: var(--po-white); border-color: var(--po-coral); }

/* ── TESTIMONIALS ── */
.po-testimonials { background: var(--po-sand); }
.po-testimonials-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 28px;
  margin-top: 52px;
}
.po-testimonial {
  background: var(--po-white);
  border-radius: var(--po-radius);
  padding: 32px 28px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.06);
  position: relative;
}
.po-testimonial::before {
  content: '"';
  font-family: var(--po-font-head);
  font-size: 5rem;
  color: var(--po-teal-lt);
  position: absolute;
  top: -10px;
  left: 20px;
  line-height: 1;
  opacity: 0.3;
}
.po-stars { color: #FFC107; font-size: 1rem; margin-bottom: 12px; }
.po-testimonial p { font-size: 0.92rem; color: var(--po-charcoal); line-height: 1.7; margin-bottom: 20px; font-style: italic; }
.po-testi-author { display: flex; align-items: center; gap: 12px; }
.po-testi-avatar {
  width: 44px;
  height: 44px;
  border-radius: 50%;
  background: linear-gradient(135deg, var(--po-teal-lt) 0%, var(--po-teal) 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--po-white);
  font-weight: 700;
  font-size: 1rem;
}
.po-testi-name { font-weight: 700; font-size: 0.9rem; }
.po-testi-cond { font-size: 0.78rem; color: var(--po-grey); }

/* ── FAQ ── */
.po-faqs { max-width: 800px; margin: 52px auto 0; }
.po-faq-item {
  border-bottom: 1px solid var(--po-sand-dk);
  margin-bottom: 4px;
}
.po-faq-q {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 0;
  cursor: pointer;
  font-weight: 600;
  font-size: 0.95rem;
  color: var(--po-charcoal);
  user-select: none;
}
.po-faq-q::after {
  content: '+';
  font-size: 1.4rem;
  color: var(--po-teal);
  transition: transform 0.3s;
  flex-shrink: 0;
}
.po-faq-item.po-open .po-faq-q::after { transform: rotate(45deg); }
.po-faq-a {
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.4s ease;
}
.po-faq-a-inner {
  padding: 0 0 20px;
  color: var(--po-grey);
  font-size: 0.9rem;
  line-height: 1.7;
}

/* ── BOOKING FORM ── */
.po-booking-section {
  background: linear-gradient(135deg, var(--po-teal-dk) 0%, var(--po-teal) 100%);
}
.po-booking-section .po-section-tag { background: rgba(178,223,219,0.2); color: #B2DFDB; }
.po-booking-section .po-section-title { color: var(--po-white); }
.po-booking-section .po-section-sub { color: rgba(255,255,255,0.75); }
.po-booking-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 60px;
  margin-top: 48px;
  align-items: start;
}
.po-booking-info { color: var(--po-white); }
.po-booking-info h3 {
  font-family: var(--po-font-head);
  font-size: 1.4rem;
  font-weight: 700;
  margin-bottom: 20px;
}
.po-booking-info ul { list-style: none; display: flex; flex-direction: column; gap: 12px; }
.po-booking-info li {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  font-size: 0.9rem;
  opacity: 0.9;
}
.po-booking-info li::before { content: '✓'; color: #B2DFDB; font-weight: 700; flex-shrink: 0; }
.po-contact-box {
  background: rgba(255,255,255,0.1);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: var(--po-radius);
  padding: 20px 24px;
  margin-top: 28px;
}
.po-contact-box h4 { font-size: 0.85rem; font-weight: 700; color: rgba(255,255,255,0.7); text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 12px; }
.po-contact-item { display: flex; align-items: center; gap: 10px; font-size: 0.9rem; color: rgba(255,255,255,0.9); margin-bottom: 8px; }

.po-form {
  background: var(--po-white);
  border-radius: 16px;
  padding: 36px;
  box-shadow: 0 20px 60px rgba(0,0,0,0.2);
}
.po-form h3 {
  font-family: var(--po-font-head);
  font-size: 1.3rem;
  font-weight: 700;
  color: var(--po-charcoal);
  margin-bottom: 24px;
}
.po-form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.po-form-group { display: flex; flex-direction: column; gap: 6px; }
.po-form-group.po-full { grid-column: 1/-1; }
.po-form-group label { font-size: 0.82rem; font-weight: 600; color: var(--po-charcoal); }
.po-form-group input,
.po-form-group select,
.po-form-group textarea {
  padding: 12px 16px;
  border: 2px solid var(--po-sand-dk);
  border-radius: 8px;
  font-family: var(--po-font-body);
  font-size: 0.9rem;
  color: var(--po-charcoal);
  transition: border-color 0.3s;
  background: var(--po-white);
}
.po-form-group input:focus,
.po-form-group select:focus,
.po-form-group textarea:focus { outline: none; border-color: var(--po-teal); }
.po-form-group textarea { resize: vertical; min-height: 90px; }
.po-form-submit {
  width: 100%;
  padding: 16px;
  background: linear-gradient(135deg, var(--po-teal) 0%, var(--po-teal-dk) 100%);
  color: var(--po-white);
  border: none;
  border-radius: 50px;
  font-family: var(--po-font-body);
  font-size: 1rem;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.3s;
  margin-top: 8px;
  box-shadow: 0 4px 16px rgba(0,137,123,0.4);
}
.po-form-submit:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(0,137,123,0.5); }
.po-form-note {
  font-size: 0.78rem;
  color: var(--po-grey);
  text-align: center;
  margin-top: 12px;
}

/* ── RESPONSIVE ── */
@media (max-width: 1024px) {
  .po-hero-inner { grid-template-columns: 1fr; }
  .po-scene { display: none; }
  .po-about-grid { grid-template-columns: 1fr; }
  .po-portrait { height: 280px; }
  .po-packages-grid { grid-template-columns: 1fr; }
  .po-package-featured { transform: none; }
  .po-testimonials-grid { grid-template-columns: 1fr; }
  .po-booking-grid { grid-template-columns: 1fr; }
}
@media (max-width: 640px) {
  .po-section { padding: 60px 5%; }
  .po-hero h1 { font-size: 2.2rem; }
  .po-conditions-grid { grid-template-columns: 1fr; }
  .po-treatments-grid { grid-template-columns: 1fr; }
  .po-process-grid { grid-template-columns: 1fr 1fr; }
  .po-form-grid { grid-template-columns: 1fr; }
  .po-hero-stats { gap: 20px; }
}
</style>

<div class="po-wrap">

<!-- ═══════════════════════════════
     HERO
════════════════════════════════ -->
<section class="po-hero">

  <!-- Hex grid background -->
  <div class="po-hex-grid">
    <?php
    srand(crc32('po-hex'));
    for ($i = 0; $i < 24; $i++) {
      $left = rand(0, 100);
      $top  = rand(0, 100);
      echo "<div class='po-hex' style='left:{$left}%;top:{$top}%;'></div>";
    }
    ?>
  </div>

  <!-- Floating cross symbols -->
  <?php
  srand(crc32('po-cross'));
  $crosses = ['+', '✚', '✛'];
  for ($i = 0; $i < 8; $i++) {
    $left = rand(5, 90);
    $top  = rand(5, 90);
    $sym  = $crosses[array_rand($crosses)];
    echo "<div class='po-cross' style='left:{$left}%;top:{$top}%;'>{$sym}</div>";
  }
  ?>

  <div class="po-orb po-orb-1"></div>
  <div class="po-orb po-orb-2"></div>

  <!-- Hero Inner -->
  <div class="po-hero-inner">
    <div class="po-hero-text">
      <div class="po-hero-tag">HCPC Registered Podiatrist</div>
      <h1>Expert Foot &amp; Ankle<br><em>Care in Edinburgh</em></h1>
      <p class="po-hero-sub">Specialist podiatry for pain relief, biomechanical assessment, sports injuries, and long-term foot health — delivered with clinical precision and genuine care.</p>
      <div class="po-hero-ctas">
        <a href="#booking" class="po-btn-primary">📅 Book Appointment</a>
        <a href="#treatments" class="po-btn-secondary">View Treatments →</a>
      </div>
      <div class="po-hero-stats">
        <div class="po-hero-stat">
          <span class="po-hero-stat-num" data-target="16" data-suffix="yrs">0yrs</span>
          <span class="po-hero-stat-lbl">Experience</span>
        </div>
        <div class="po-hero-stat">
          <span class="po-hero-stat-num" data-target="4800" data-suffix="+">0+</span>
          <span class="po-hero-stat-lbl">Patients Treated</span>
        </div>
        <div class="po-hero-stat">
          <span class="po-hero-stat-num" data-target="4.9" data-float="1" data-suffix="★">0★</span>
          <span class="po-hero-stat-lbl">Rating</span>
        </div>
        <div class="po-hero-stat">
          <span class="po-hero-stat-num" data-target="96" data-suffix="%">0%</span>
          <span class="po-hero-stat-lbl">Recommend Us</span>
        </div>
      </div>
    </div>
  </div>

  <!-- CSS Clinic Scene -->
  <div class="po-scene">
    <!-- Pulse rings -->
    <div class="po-pulse"></div>
    <div class="po-pulse"></div>
    <div class="po-pulse"></div>

    <!-- Treatment Table -->
    <div class="po-table">
      <div class="po-table-paper"></div>
    </div>

    <!-- Patient Foot -->
    <div class="po-foot">
      <div class="po-ankle"></div>
      <div class="po-foot-body">
        <div class="po-toes">
          <div class="po-toe"></div>
          <div class="po-toe"></div>
          <div class="po-toe"></div>
          <div class="po-toe"></div>
          <div class="po-toe"></div>
        </div>
      </div>
    </div>

    <!-- Tool Tray -->
    <div class="po-tray"></div>

    <!-- Podiatrist Figure -->
    <div class="po-figure">
      <div class="po-head">
        <div class="po-hair"></div>
      </div>
      <div class="po-coat">
        <div class="po-arm"></div>
      </div>
    </div>

    <!-- Floating Badges -->
    <div class="po-badge po-badge-1">🏥 HCPC Registered</div>
    <div class="po-badge po-badge-2">🦶 Biomechanics Expert</div>
    <div class="po-badge po-badge-3">⭐ 4.9 Star Rating</div>
  </div>

</section>

<!-- TRUST BAR -->
<div class="po-trust">
  <div class="po-trust-inner">
    <div class="po-trust-item"><span>🏥</span> HCPC Registered</div>
    <div class="po-trust-item"><span>🎓</span> BSc (Hons) Podiatry</div>
    <div class="po-trust-item"><span>🏆</span> College of Podiatry Member</div>
    <div class="po-trust-item"><span>🛡️</span> Fully Insured</div>
    <div class="po-trust-item"><span>📍</span> Edinburgh City Centre</div>
    <div class="po-trust-item"><span>📱</span> Same-Week Appointments</div>
  </div>
</div>

<!-- ═══════════════════════════════
     CONDITIONS TREATED
════════════════════════════════ -->
<section class="po-section po-conditions">
  <div class="po-section-inner">
    <div class="po-section-tag">Conditions Treated</div>
    <h2 class="po-section-title">Helping You Walk, Run &amp; Live Pain-Free</h2>
    <p class="po-section-sub">From everyday discomfort to complex biomechanical issues — evidence-based podiatry for patients of all ages.</p>

    <div class="po-conditions-grid">
      <div class="po-condition-card">
        <div class="po-condition-icon">🦶</div>
        <div>
          <h3>Plantar Fasciitis</h3>
          <p>Heel pain and arch inflammation treated with targeted orthotic therapy, stretching programmes, and shockwave therapy.</p>
        </div>
      </div>
      <div class="po-condition-card">
        <div class="po-condition-icon">💅</div>
        <div>
          <h3>Ingrown Toenails</h3>
          <p>Gentle, precise nail surgery — including PNA/TNA procedures performed under local anaesthetic for lasting relief.</p>
        </div>
      </div>
      <div class="po-condition-card">
        <div class="po-condition-icon">🔵</div>
        <div>
          <h3>Verrucae &amp; Warts</h3>
          <p>Cryotherapy, needling, and SWIFT microwave therapy for even the most stubborn plantar verrucae.</p>
        </div>
      </div>
      <div class="po-condition-card">
        <div class="po-condition-icon">🧬</div>
        <div>
          <h3>Diabetic Foot Care</h3>
          <p>Specialist annual reviews, neurovascular assessment, offloading, and wound care to prevent serious complications.</p>
        </div>
      </div>
      <div class="po-condition-card">
        <div class="po-condition-icon">🏃</div>
        <div>
          <h3>Sports Injuries</h3>
          <p>Shin splints, Achilles tendinopathy, metatarsal stress fractures — biomechanical analysis and return-to-sport planning.</p>
        </div>
      </div>
      <div class="po-condition-card">
        <div class="po-condition-icon">🧓</div>
        <div>
          <h3>Elderly Foot Care</h3>
          <p>Routine nail care, corns, callus removal, and falls-prevention assessments — home visits available.</p>
        </div>
      </div>
      <div class="po-condition-card">
        <div class="po-condition-icon">🔧</div>
        <div>
          <h3>Biomechanical Assessment</h3>
          <p>Full gait analysis, video treadmill assessment, and custom orthotic prescription for structural problems.</p>
        </div>
      </div>
      <div class="po-condition-card">
        <div class="po-condition-icon">👶</div>
        <div>
          <h3>Children's Podiatry</h3>
          <p>Flat feet, in-toeing, growing pains, and Sever's disease — gentle paediatric assessment and treatment.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     ABOUT
════════════════════════════════ -->
<section class="po-section">
  <div class="po-section-inner">
    <div class="po-about-grid">
      <div class="po-portrait">
        <div class="po-portrait-bg"></div>
        <div class="po-portrait-fig">
          <div class="po-fig-head">
            <div class="po-fig-hair"></div>
          </div>
          <div class="po-fig-coat"></div>
        </div>
        <div class="po-cred po-cred-1">BSc (Hons) Podiatry</div>
        <div class="po-cred po-cred-2">MSc Sports Medicine</div>
        <div class="po-cred po-cred-3">HCPC Reg. No. PO12847</div>
      </div>
      <div class="po-about-text">
        <div class="po-section-tag">Your Podiatrist</div>
        <h2 class="po-section-title">Dr. Rachel Drummond</h2>
        <p class="po-section-sub">A specialist podiatrist with 16 years of NHS and private practice experience, Rachel's approach combines rigorous clinical assessment with patient-centred care. She holds specialist qualifications in sports podiatry and diabetic foot management, and has helped thousands of Edinburgh residents rediscover pain-free movement.</p>

        <div class="po-about-quals">
          <div class="po-qual-item"><span class="po-qual-icon">🎓</span> BSc (Hons) Podiatric Medicine — Queen Margaret University</div>
          <div class="po-qual-item"><span class="po-qual-icon">🎓</span> MSc Sports &amp; Exercise Medicine — Edinburgh Napier</div>
          <div class="po-qual-item"><span class="po-qual-icon">🏥</span> Former NHS Lothian Senior Podiatrist (8 years)</div>
          <div class="po-qual-item"><span class="po-qual-icon">🏆</span> SWIFT Certified Practitioner</div>
          <div class="po-qual-item"><span class="po-qual-icon">📋</span> HCPC Registered (PO12847) &amp; College of Podiatry Member</div>
        </div>
        <div class="po-about-quote">
          "I believe everyone deserves to move without pain. Whether you're a competitive athlete or struggling with everyday steps, I'll find the root cause and fix it properly — not just manage the symptoms."
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     TREATMENTS
════════════════════════════════ -->
<section class="po-section" id="treatments" style="background: var(--po-sand);">
  <div class="po-section-inner">
    <div class="po-section-tag">Our Treatments</div>
    <h2 class="po-section-title">Comprehensive Podiatry Services</h2>
    <p class="po-section-sub">From routine care to advanced clinical procedures — all under one roof.</p>

    <div class="po-treatments-grid">
      <div class="po-treatment-card">
        <div class="po-treatment-top"></div>
        <div class="po-treatment-body">
          <span class="po-treatment-icon">🦶</span>
          <h3>General Podiatry</h3>
          <p>Nail care, corns, calluses, verrucae, and skin conditions. Includes full lower-limb assessment and personalised advice.</p>
          <div class="po-treatment-price">from £55</div>
        </div>
      </div>
      <div class="po-treatment-card">
        <div class="po-treatment-top"></div>
        <div class="po-treatment-body">
          <span class="po-treatment-icon">🔧</span>
          <h3>Biomechanical Assessment</h3>
          <p>Comprehensive gait analysis, muscle strength testing, and joint range of motion — 90-minute in-depth session.</p>
          <div class="po-treatment-price">£120</div>
        </div>
      </div>
      <div class="po-treatment-card">
        <div class="po-treatment-top"></div>
        <div class="po-treatment-body">
          <span class="po-treatment-icon">👟</span>
          <h3>Custom Orthotics</h3>
          <p>Precision-cast or 3D-printed insoles designed from your biomechanical assessment. Includes fitting and review.</p>
          <div class="po-treatment-price">from £280</div>
        </div>
      </div>
      <div class="po-treatment-card">
        <div class="po-treatment-top"></div>
        <div class="po-treatment-body">
          <span class="po-treatment-icon">💉</span>
          <h3>Nail Surgery (PNA/TNA)</h3>
          <p>Permanent correction of recurring ingrown toenails under local anaesthetic. High success rate, minimal downtime.</p>
          <div class="po-treatment-price">from £350</div>
        </div>
      </div>
      <div class="po-treatment-card">
        <div class="po-treatment-top"></div>
        <div class="po-treatment-body">
          <span class="po-treatment-icon">⚡</span>
          <h3>SWIFT Microwave Therapy</h3>
          <p>The gold-standard verruca treatment — FDA-cleared microwave energy activates immune response for lasting clearance.</p>
          <div class="po-treatment-price">from £95/session</div>
        </div>
      </div>
      <div class="po-treatment-card">
        <div class="po-treatment-top"></div>
        <div class="po-treatment-body">
          <span class="po-treatment-icon">🧬</span>
          <h3>Diabetic Foot Screen</h3>
          <p>Annual neurological and vascular assessment, risk categorisation, preventative advice, and GP correspondence.</p>
          <div class="po-treatment-price">£75</div>
        </div>
      </div>
      <div class="po-treatment-card">
        <div class="po-treatment-top"></div>
        <div class="po-treatment-body">
          <span class="po-treatment-icon">🏃</span>
          <h3>Sports Podiatry</h3>
          <p>Video gait analysis for runners, cyclists, and team sport athletes. Injury rehab, load management, and performance optimisation.</p>
          <div class="po-treatment-price">£95</div>
        </div>
      </div>
      <div class="po-treatment-card">
        <div class="po-treatment-top"></div>
        <div class="po-treatment-body">
          <span class="po-treatment-icon">🏠</span>
          <h3>Home Visits</h3>
          <p>Full podiatry service in the comfort of your own home. Ideal for elderly patients or those with mobility challenges.</p>
          <div class="po-treatment-price">from £80</div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     PROCESS
════════════════════════════════ -->
<section class="po-section po-process-section">
  <div class="po-section-inner">
    <div class="po-section-tag">How It Works</div>
    <h2 class="po-section-title">Your Path to Healthy Feet</h2>
    <p class="po-section-sub">A clear, structured journey from first contact to lasting relief.</p>

    <div class="po-process-grid">
      <div class="po-process-step">
        <div class="po-process-num">1</div>
        <h3>Book Online</h3>
        <p>Choose your appointment type, preferred time, and complete a short medical history form.</p>
      </div>
      <div class="po-process-step">
        <div class="po-process-num">2</div>
        <h3>Assessment</h3>
        <p>Thorough clinical examination — we identify the root cause, not just the symptom.</p>
      </div>
      <div class="po-process-step">
        <div class="po-process-num">3</div>
        <h3>Treatment Plan</h3>
        <p>Clear explanation of findings and a personalised treatment plan with realistic timelines.</p>
      </div>
      <div class="po-process-step">
        <div class="po-process-num">4</div>
        <h3>Treatment &amp; Review</h3>
        <p>Evidence-based treatment with follow-up appointments to monitor progress and adjust as needed.</p>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     PACKAGES
════════════════════════════════ -->
<section class="po-section">
  <div class="po-section-inner">
    <div class="po-section-tag">Pricing</div>
    <h2 class="po-section-title">Transparent, Affordable Podiatry</h2>
    <p class="po-section-sub">No hidden fees, no unnecessary referrals. Clear pricing for exceptional care.</p>

    <div class="po-packages-grid">
      <div class="po-package">
        <h3>Essential Care</h3>
        <div class="po-pkg-price">£55</div>
        <div class="po-pkg-desc">General podiatry appointment</div>
        <ul class="po-pkg-features">
          <li>45-minute appointment</li>
          <li>Nails, corns &amp; callus</li>
          <li>Skin assessment</li>
          <li>Footwear advice</li>
          <li>Self-care programme</li>
        </ul>
        <a href="#booking" class="po-pkg-btn">Book Now</a>
      </div>
      <div class="po-package po-package-featured">
        <div class="po-package-badge">Most Popular</div>
        <h3>Biomechanics Package</h3>
        <div class="po-pkg-price">£360</div>
        <div class="po-pkg-desc">Full assessment + custom orthotics</div>
        <ul class="po-pkg-features">
          <li>90-min biomechanical assessment</li>
          <li>Video gait analysis</li>
          <li>Pair of custom-cast orthotics</li>
          <li>Fitting appointment included</li>
          <li>6-week review appointment</li>
          <li>Rehab exercise programme</li>
        </ul>
        <a href="#booking" class="po-pkg-btn">Book Now</a>
      </div>
      <div class="po-package">
        <h3>Sports Performance</h3>
        <div class="po-pkg-price">£220</div>
        <div class="po-pkg-desc">For runners &amp; active athletes</div>
        <ul class="po-pkg-features">
          <li>Sports assessment (75 min)</li>
          <li>Treadmill video analysis</li>
          <li>Injury diagnosis &amp; rehab plan</li>
          <li>Off-the-shelf orthotic fitting</li>
          <li>Return-to-sport timeline</li>
        </ul>
        <a href="#booking" class="po-pkg-btn">Book Now</a>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     TESTIMONIALS
════════════════════════════════ -->
<section class="po-section po-testimonials">
  <div class="po-section-inner">
    <div class="po-section-tag">Patient Reviews</div>
    <h2 class="po-section-title">Patients Walking Taller</h2>

    <div class="po-testimonials-grid">
      <div class="po-testimonial">
        <div class="po-stars">★★★★★</div>
        <p>I'd suffered plantar fasciitis for 18 months and seen two other podiatrists without improvement. Rachel found the true biomechanical cause in the first appointment. Custom orthotics and a targeted exercise programme had me pain-free in 8 weeks.</p>
        <div class="po-testi-author">
          <div class="po-testi-avatar">AK</div>
          <div>
            <div class="po-testi-name">Andrew K., Edinburgh</div>
            <div class="po-testi-cond">Plantar Fasciitis</div>
          </div>
        </div>
      </div>
      <div class="po-testimonial">
        <div class="po-stars">★★★★★</div>
        <p>The SWIFT verruca treatment was remarkable — I'd been trying to shift a stubborn verruca for three years. Three sessions with Rachel and it was completely gone. The treatment itself was over in seconds each time.</p>
        <div class="po-testi-author">
          <div class="po-testi-avatar">SL</div>
          <div>
            <div class="po-testi-name">Sophie L., Leith</div>
            <div class="po-testi-cond">Verruca Treatment</div>
          </div>
        </div>
      </div>
      <div class="po-testimonial">
        <div class="po-stars">★★★★★</div>
        <p>As a Type 2 diabetic I was nervous about foot care, but Rachel's annual diabetes foot screen was thorough, reassuring, and completely painless. She also wrote to my GP with the results, which was incredibly helpful.</p>
        <div class="po-testi-author">
          <div class="po-testi-avatar">MB</div>
          <div>
            <div class="po-testi-name">Margaret B., Morningside</div>
            <div class="po-testi-cond">Diabetic Foot Care</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     FAQ
════════════════════════════════ -->
<section class="po-section">
  <div class="po-section-inner">
    <div style="text-align:center;">
      <div class="po-section-tag">FAQ</div>
      <h2 class="po-section-title">Frequently Asked Questions</h2>
    </div>

    <div class="po-faqs">
      <div class="po-faq-item">
        <div class="po-faq-q">Do I need a GP referral to see a podiatrist?</div>
        <div class="po-faq-a"><div class="po-faq-a-inner">No — you can refer yourself directly. Simply book online or call the clinic. If your treatment requires onward referral for imaging or specialist care, we'll arrange that for you.</div></div>
      </div>
      <div class="po-faq-item">
        <div class="po-faq-q">Is podiatry covered by health insurance?</div>
        <div class="po-faq-a"><div class="po-faq-a-inner">Many private health insurers cover podiatry, particularly for chronic conditions and surgical procedures. We recommend confirming with your insurer before your appointment. We're recognised by BUPA, AXA Health, Vitality, and Aviva.</div></div>
      </div>
      <div class="po-faq-item">
        <div class="po-faq-q">How long will my appointment take?</div>
        <div class="po-faq-a"><div class="po-faq-a-inner">General appointments are 45 minutes. Biomechanical assessments are 90 minutes. Nail surgery is typically 60–75 minutes including anaesthetic time. We never rush appointments — we'd rather take the time to get it right.</div></div>
      </div>
      <div class="po-faq-item">
        <div class="po-faq-q">Will treatments hurt?</div>
        <div class="po-faq-a"><div class="po-faq-a-inner">We go to considerable lengths to ensure patient comfort. Nail surgery is performed under local anaesthetic so you'll feel pressure but no pain. SWIFT therapy causes a brief 2–3 second sting during treatment. Most other treatments are entirely painless.</div></div>
      </div>
      <div class="po-faq-item">
        <div class="po-faq-q">How soon can I get an appointment?</div>
        <div class="po-faq-a"><div class="po-faq-a-inner">We typically have appointments available within 3–5 working days. Urgent appointments for acute pain or infected ingrown toenails are prioritised — call us and we'll do our best to see you the same week.</div></div>
      </div>
      <div class="po-faq-item">
        <div class="po-faq-q">Do you treat children?</div>
        <div class="po-faq-a"><div class="po-faq-a-inner">Yes — we see patients from age 4 upwards. Paediatric conditions we treat include flat feet, in-toeing, Sever's disease (heel pain in growing children), verrucae, and ingrown toenails. Parents are always welcome to be present throughout.</div></div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     BOOKING FORM
════════════════════════════════ -->
<section class="po-section po-booking-section" id="booking">
  <div class="po-section-inner">
    <div class="po-section-tag">Book Your Appointment</div>
    <h2 class="po-section-title">Take the First Step</h2>
    <p class="po-section-sub">Expert podiatry, available this week. No GP referral needed.</p>

    <div class="po-booking-grid">
      <div class="po-booking-info">
        <h3>Why Choose Drummond Podiatry?</h3>
        <ul>
          <li>HCPC registered with 16 years' clinical experience</li>
          <li>Same-week appointments typically available</li>
          <li>Advanced diagnostic equipment on-site</li>
          <li>Recognised by BUPA, AXA Health &amp; Vitality</li>
          <li>Custom orthotics delivered within 2 weeks</li>
          <li>Digital patient records for continuity of care</li>
          <li>Home visits available for mobility-limited patients</li>
        </ul>
        <div class="po-contact-box">
          <h4>Contact &amp; Location</h4>
          <div class="po-contact-item">📍 12 Stafford Street, Edinburgh EH3 7BG</div>
          <div class="po-contact-item">📞 0131 225 4870</div>
          <div class="po-contact-item">📧 hello@drummondpodiatry.co.uk</div>
          <div class="po-contact-item">🕐 Mon–Fri: 8:30am–6:30pm | Sat: 9am–1pm</div>
        </div>
      </div>

      <div class="po-form">
        <h3>Request an Appointment</h3>
        <?php if ( function_exists( 'get_the_permalink' ) ) : ?>
        <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
          <?php wp_nonce_field( 'tf_po_booking', 'tf_po_nonce' ); ?>
          <input type="hidden" name="action" value="tf_po_booking">
          <div class="po-form-grid">
            <div class="po-form-group">
              <label for="po_first">First Name *</label>
              <input type="text" id="po_first" name="first_name" required placeholder="Rachel">
            </div>
            <div class="po-form-group">
              <label for="po_last">Last Name *</label>
              <input type="text" id="po_last" name="last_name" required placeholder="Smith">
            </div>
            <div class="po-form-group">
              <label for="po_email">Email Address *</label>
              <input type="email" id="po_email" name="email" required placeholder="rachel@email.com">
            </div>
            <div class="po-form-group">
              <label for="po_phone">Phone Number *</label>
              <input type="tel" id="po_phone" name="phone" required placeholder="0131 000 0000">
            </div>
            <div class="po-form-group po-full">
              <label for="po_treatment">Treatment Required *</label>
              <select id="po_treatment" name="treatment" required>
                <option value="">— Select treatment —</option>
                <option>General Podiatry (£55)</option>
                <option>Biomechanical Assessment (£120)</option>
                <option>Custom Orthotics Package (£360)</option>
                <option>Nail Surgery PNA/TNA (from £350)</option>
                <option>SWIFT Verruca Treatment (£95)</option>
                <option>Diabetic Foot Screen (£75)</option>
                <option>Sports Podiatry (£95)</option>
                <option>Home Visit (from £80)</option>
                <option>Not sure — please advise</option>
              </select>
            </div>
            <div class="po-form-group">
              <label for="po_dob">Date of Birth</label>
              <input type="date" id="po_dob" name="dob">
            </div>
            <div class="po-form-group">
              <label for="po_prefer">Preferred Day</label>
              <select id="po_prefer" name="preferred_day">
                <option value="">— Any day —</option>
                <option>Monday</option>
                <option>Tuesday</option>
                <option>Wednesday</option>
                <option>Thursday</option>
                <option>Friday</option>
                <option>Saturday</option>
              </select>
            </div>
            <div class="po-form-group po-full">
              <label for="po_msg">Brief Description of Your Concern *</label>
              <textarea id="po_msg" name="message" required placeholder="Please describe your foot or ankle concern, how long you've had it, and any previous treatments you've tried..."></textarea>
            </div>
          </div>
          <button type="submit" class="po-form-submit">📅 Request My Appointment</button>
          <p class="po-form-note">🔒 Your information is confidential and handled in accordance with GDPR. We aim to respond within 4 working hours.</p>
        </form>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

</div><!-- .po-wrap -->

<script>
(function(){
  /* ── ANIMATED COUNTERS ── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  const counters = document.querySelectorAll('[data-target]');
  if (!counters.length) return;
  const obs = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const target = parseFloat(el.dataset.target);
      if (isNaN(target)) return;
      const suffix  = el.dataset.suffix || '';
      const isFloat = el.dataset.float === '1';
      const dur     = 1800;
      let start     = null;
      function tick(ts) {
        if (!start) start = ts;
        const prog = Math.min((ts - start) / dur, 1);
        const val  = easeOut(prog) * target;
        el.textContent = (isFloat ? val.toFixed(1) : Math.floor(val).toLocaleString()) + suffix;
        if (prog < 1) requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
      obs.unobserve(el);
    });
  }, { threshold: 0.5 });
  counters.forEach(c => obs.observe(c));

  /* ── FAQ ACCORDION ── */
  document.querySelectorAll('.po-faq-q').forEach(q => {
    q.addEventListener('click', () => {
      const item = q.parentElement;
      const ans  = item.querySelector('.po-faq-a');
      const open = item.classList.contains('po-open');
      document.querySelectorAll('.po-faq-item.po-open').forEach(o => {
        o.classList.remove('po-open');
        o.querySelector('.po-faq-a').style.maxHeight = '0';
      });
      if (!open) {
        item.classList.add('po-open');
        ans.style.maxHeight = ans.scrollHeight + 'px';
      }
    });
  });

  /* ── SCROLL REVEAL ── */
  const reveals = document.querySelectorAll('.po-condition-card,.po-treatment-card,.po-process-step,.po-testimonial,.po-package');
  const revObs  = new IntersectionObserver(entries => {
    entries.forEach((e, i) => {
      if (e.isIntersecting) {
        setTimeout(() => {
          e.target.style.opacity    = '1';
          e.target.style.transform  = e.target.classList.contains('po-package-featured') ? 'scale(1.03)' : 'translateY(0)';
        }, (i % 4) * 80);
        revObs.unobserve(e.target);
      }
    });
  }, { threshold: 0.1 });
  reveals.forEach(r => {
    r.style.opacity   = '0';
    r.style.transform = r.classList.contains('po-package-featured') ? 'scale(0.98)' : 'translateY(24px)';
    r.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    revObs.observe(r);
  });

  /* ── SMOOTH SCROLL ── */
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const target = document.querySelector(a.getAttribute('href'));
      if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    });
  });
})();
</script>

<?php get_footer(); ?>
