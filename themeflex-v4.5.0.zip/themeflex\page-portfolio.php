<?php
/**
 * Template Name: TF — Photography Portfolio
 * Description:  Premium creative photography / visual artist portfolio for ThemeFlex.
 *               Near-black · electric yellow accent · Bebas Neue + Inter
 * Namespace:    --pf-*
 *
 * @package ThemeFlex
 */

defined( 'ABSPATH' ) || exit;

wp_enqueue_style(
	'tf-font-portfolio',
	'https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@300;400;500;600&display=swap',
	[],
	null
);

/* ─────────────────────────────────────────────
   PHP DATA
───────────────────────────────────────────── */

$pf_projects = [
	['cat' => 'Editorial', 'title' => 'Stille Orte',          'client' => 'ZEIT Magazin',   'year' => '2025', 'color' => '#1a1208', 'accent' => '#e8c840'],
	['cat' => 'Portrait',  'title' => 'Unseen Faces',          'client' => 'Vogue Germany',  'year' => '2024', 'color' => '#081218', 'accent' => '#40c8e8'],
	['cat' => 'Architektur','title' => 'Brutalist Berlin',     'client' => 'Monopol',        'year' => '2025', 'color' => '#121218', 'accent' => '#e84060'],
	['cat' => 'Kampagne',  'title' => 'Naked Season',          'client' => 'Armedangels',    'year' => '2024', 'color' => '#0a0c08', 'accent' => '#88e840'],
	['cat' => 'Reportage', 'title' => 'Nachtarbeit',           'client' => 'Spiegel Online', 'year' => '2025', 'color' => '#18080a', 'accent' => '#e87040'],
	['cat' => 'Fine Art',  'title' => 'Fläche &amp; Form',     'client' => 'Eigenproduktion','year' => '2024', 'color' => '#080818', 'accent' => '#9040e8'],
	['cat' => 'Produkt',   'title' => 'Objekte des Alltags',   'client' => 'Manufactum',     'year' => '2025', 'color' => '#100810', 'accent' => '#e840c8'],
	['cat' => 'Event',     'title' => 'Berlinale 2025',        'client' => 'DPA',            'year' => '2025', 'color' => '#080c10', 'accent' => '#40e8b8'],
];

$pf_categories = ['Alle', 'Editorial', 'Portrait', 'Architektur', 'Kampagne', 'Reportage', 'Fine Art', 'Produkt', 'Event'];

$pf_services = [
	['name' => 'Editorial & Magazine',   'items' => ['Zeitschriften & Supplements','Online-Medien','Jahresberichte','Reportagen & Dokumentation'],'price' => 'ab € 1.200 / Tag'],
	['name' => 'Fashion & Kampagne',     'items' => ['Look Book & Collections','E-Commerce Kataloge','Brand Campaigns','Social Content Sets'],    'price' => 'ab € 1.800 / Tag'],
	['name' => 'Portrait & People',      'items' => ['Corporate Portraits','Künstlerportraits','Bühnen & Backstage','Author & Speaker'],           'price' => 'ab € 800 / Tag'],
	['name' => 'Architektur & Interieur','items' => ['Immobilienmarketing','Architekten-Portfolio','Hotel & Gastronomie','Ausstellungsdoku'],       'price' => 'ab € 1.400 / Tag'],
];

$pf_clients = ['ZEIT Magazin', 'Vogue', 'Spiegel', 'Stern', 'Monopol', 'DPA', 'Armedangels', 'Manufactum', 'BMW', 'Adidas', 'Hugo Boss', 'Mercedes'];

$pf_awards = [
	['award' => 'World Press Photo', 'cat' => 'Portrait', 'year' => '2024'],
	['award' => 'ADC Deutschland', 'cat' => 'Bronze', 'year' => '2025'],
	['award' => 'Leica Oskar Barnack', 'cat' => 'Newcomer Award', 'year' => '2023'],
	['award' => 'Epica Awards', 'cat' => 'Kampagne', 'year' => '2024'],
];

/* Aperture blade count for CSS camera */
$pf_blades = 8;

/* Lens reflex dots */
$pf_flares = [
	['x' => 30, 'y' => 25, 'size' => 80, 'opacity' => 0.04],
	['x' => 55, 'y' => 60, 'size' => 140, 'opacity' => 0.03],
	['x' => 75, 'y' => 35, 'size' => 60, 'opacity' => 0.05],
];

?>
<style>
/* ═══════════════════════════════════════════════
   PF TOKEN SYSTEM
═══════════════════════════════════════════════ */
:root{
  --pf-bg:     #060608;
  --pf-bg2:    #0c0c10;
  --pf-bg3:    #101015;
  --pf-yellow: #e8d640;
  --pf-yellow-d:#b8a820;
  --pf-white:  #f5f5f0;
  --pf-muted:  #888896;
  --pf-border: rgba(245,245,240,.08);
  --pf-glass:  rgba(232,214,64,.05);
  --pf-font-h: 'Bebas Neue', 'Impact', sans-serif;
  --pf-font-b: 'Inter', system-ui, sans-serif;
  --pf-gap:    clamp(4rem,8vw,7rem);
}
.pf-page *{box-sizing:border-box;margin:0;padding:0}
.pf-page{
  background:var(--pf-bg);
  color:var(--pf-white);
  font-family:var(--pf-font-b);font-weight:300;line-height:1.65;
  overflow-x:hidden;
}
.pf-page a{color:var(--pf-yellow);text-decoration:none;transition:color .2s}
.pf-page a:hover{color:var(--pf-white)}
.pf-container{max-width:1200px;margin:0 auto;padding:0 clamp(1rem,4vw,2.5rem)}
.pf-section{padding:var(--pf-gap) 0}
.pf-h1{font-family:var(--pf-font-h);font-size:clamp(4rem,10vw,11rem);line-height:.95;letter-spacing:.02em;font-weight:400}
.pf-h2{font-family:var(--pf-font-h);font-size:clamp(2.5rem,5vw,5rem);letter-spacing:.02em;font-weight:400}
.pf-h3{font-family:var(--pf-font-h);font-size:2rem;letter-spacing:.03em;font-weight:400}
.pf-tag{
  display:inline-block;padding:.25rem .8rem;
  border:1px solid rgba(232,214,64,.4);color:var(--pf-yellow);
  font-size:.65rem;letter-spacing:.2em;text-transform:uppercase;
  font-family:var(--pf-font-b);
}
.pf-yellow-c{color:var(--pf-yellow)}
.pf-muted{color:var(--pf-muted)}
.pf-btn{
  display:inline-block;padding:.85rem 2rem;
  font-family:var(--pf-font-b);font-size:.78rem;letter-spacing:.12em;text-transform:uppercase;font-weight:500;
  cursor:pointer;border:none;transition:all .25s;
}
.pf-btn-primary{background:var(--pf-yellow);color:#000}
.pf-btn-primary:hover{background:#fff;color:#000}
.pf-btn-outline{background:transparent;color:var(--pf-white);border:1px solid var(--pf-border)}
.pf-btn-outline:hover{border-color:var(--pf-yellow);color:var(--pf-yellow)}

/* ═══════════════════════════════════════════════
   NAV
═══════════════════════════════════════════════ */
.pf-nav{
  position:fixed;top:0;left:0;right:0;z-index:100;
  display:flex;align-items:center;justify-content:space-between;
  padding:1.2rem clamp(1.5rem,4vw,3rem);
  mix-blend-mode:normal;
  transition:background .3s;
}
.pf-nav.scrolled{
  background:rgba(6,6,8,.92);
  backdrop-filter:blur(14px);
  border-bottom:1px solid var(--pf-border);
}
.pf-nav-logo{
  font-family:var(--pf-font-h);font-size:1.6rem;letter-spacing:.08em;color:var(--pf-white);
}
.pf-nav-logo span{color:var(--pf-yellow)}
.pf-nav-links{display:flex;gap:2rem;list-style:none}
.pf-nav-links a{color:var(--pf-muted);font-size:.75rem;letter-spacing:.1em;text-transform:uppercase;transition:color .2s}
.pf-nav-links a:hover{color:var(--pf-white)}
.pf-nav-contact{
  font-size:.72rem;letter-spacing:.12em;text-transform:uppercase;
  padding:.55rem 1.4rem;border:1px solid rgba(232,214,64,.35);
  color:var(--pf-yellow);transition:all .25s;
}
.pf-nav-contact:hover{background:var(--pf-yellow);color:#000}
@media(max-width:768px){.pf-nav-links{display:none}}

/* ═══════════════════════════════════════════════
   HERO
═══════════════════════════════════════════════ */
.pf-hero{
  min-height:100vh;
  position:relative;overflow:hidden;
  display:grid;grid-template-columns:1fr 1fr;align-items:center;
  padding-top:80px;
}
@media(max-width:900px){.pf-hero{grid-template-columns:1fr;min-height:auto}}

.pf-hero-copy{
  padding:clamp(3rem,8vw,6rem) clamp(1.5rem,5vw,5rem);
  position:relative;z-index:2;
}
.pf-hero-kicker{
  font-size:.7rem;letter-spacing:.22em;text-transform:uppercase;
  color:var(--pf-muted);margin-bottom:1rem;
  display:flex;align-items:center;gap:.75rem;
}
.pf-hero-kicker::before{
  content:'';width:24px;height:1px;background:var(--pf-yellow);
}
.pf-hero h1{margin-bottom:.5rem}
.pf-hero-name{
  font-family:var(--pf-font-h);
  font-size:clamp(1.8rem,3.5vw,3rem);
  letter-spacing:.06em;color:var(--pf-yellow);
  margin-bottom:2rem;
}
.pf-hero-sub{max-width:400px;color:var(--pf-muted);font-size:.95rem;margin-bottom:2.5rem;line-height:1.8}
.pf-hero-ctas{display:flex;gap:1rem;flex-wrap:wrap;margin-bottom:3rem}
.pf-hero-scroll{
  display:flex;align-items:center;gap:.75rem;
  font-size:.68rem;letter-spacing:.18em;text-transform:uppercase;color:var(--pf-muted);
  cursor:pointer;
}
.pf-scroll-line{
  width:40px;height:1px;background:var(--pf-muted);
  position:relative;overflow:hidden;
}
.pf-scroll-line::after{
  content:'';position:absolute;top:0;left:-100%;width:100%;height:100%;
  background:var(--pf-yellow);
  animation:pf-scroll-slide 2.5s ease-in-out infinite;
}
@keyframes pf-scroll-slide{
  0%{left:-100%}
  50%{left:0}
  100%{left:100%}
}

/* ── CSS Camera / Aperture scene ── */
.pf-scene{
  position:relative;
  height:100vh;min-height:580px;
  display:flex;align-items:center;justify-content:center;
  overflow:hidden;
}
@media(max-width:900px){.pf-scene{height:400px;min-height:0}}

.pf-scene-bg{
  position:absolute;inset:0;
  background:radial-gradient(ellipse at 60% 50%,#141418 0%,#060608 70%);
}

/* Lens flares */
<?php foreach($pf_flares as $fi => $f): ?>
.pf-flare-<?php echo $fi; ?>{
  position:absolute;
  width:<?php echo $f['size']; ?>px;height:<?php echo $f['size']; ?>px;
  border-radius:50%;
  left:<?php echo $f['x']; ?>%;top:<?php echo $f['y']; ?>%;
  background:radial-gradient(circle,rgba(232,214,64,<?php echo $f['opacity']; ?>),transparent 70%);
  pointer-events:none;z-index:1;
}
<?php endforeach; ?>

/* Camera body */
.pf-camera{
  position:relative;z-index:3;
  display:flex;flex-direction:column;align-items:center;
}
.pf-camera-body{
  width:280px;height:180px;
  background:linear-gradient(180deg,#1c1c20,#101012);
  border:2px solid rgba(245,245,240,.08);
  border-radius:12px;
  position:relative;
  display:flex;align-items:center;justify-content:center;
  box-shadow:0 20px 60px rgba(0,0,0,.6);
}
/* Viewfinder hump */
.pf-camera-body::before{
  content:'';position:absolute;top:-18px;left:50%;transform:translateX(-50%);
  width:80px;height:18px;
  background:linear-gradient(180deg,#1c1c20,#181820);
  border-radius:6px 6px 0 0;
  border:2px solid rgba(245,245,240,.06);border-bottom:none;
}
/* Shutter button */
.pf-camera-body::after{
  content:'';position:absolute;top:-28px;left:calc(50% + 42px);
  width:16px;height:16px;border-radius:50%;
  background:linear-gradient(135deg,#e8d640,#b8a820);
  box-shadow:0 2px 8px rgba(232,214,64,.3);
}
/* Mode dial */
.pf-mode-dial{
  position:absolute;top:-22px;right:20px;
  width:36px;height:36px;border-radius:50%;
  background:radial-gradient(circle,#2a2a30,#181820);
  border:2px solid rgba(245,245,240,.1);
  z-index:2;
}
.pf-mode-dial::after{
  content:'';position:absolute;top:4px;left:50%;transform:translateX(-50%);
  width:2px;height:12px;background:var(--pf-yellow);border-radius:1px;
}

/* Lens ring */
.pf-lens{
  width:140px;height:140px;border-radius:50%;
  background:radial-gradient(circle,#0a0a0c,#141416);
  border:6px solid #222226;
  box-shadow:
    inset 0 0 20px rgba(0,0,0,.8),
    0 0 40px rgba(0,0,0,.4);
  position:relative;
  display:flex;align-items:center;justify-content:center;
}
/* Outer lens ring markings */
.pf-lens::before{
  content:'';position:absolute;
  width:130px;height:130px;border-radius:50%;
  border:2px solid rgba(245,245,240,.06);
}
.pf-lens::after{
  content:'';position:absolute;
  width:100px;height:100px;border-radius:50%;
  border:1px solid rgba(245,245,240,.04);
}

/* Aperture blades */
.pf-aperture{
  width:70px;height:70px;border-radius:50%;
  position:relative;
  animation:pf-aperture-pulse 4s ease-in-out infinite;
}
@keyframes pf-aperture-pulse{
  0%,100%{transform:rotate(0deg)}
  50%{transform:rotate(22.5deg)}
}
.pf-blade{
  position:absolute;
  width:35px;height:35px;
  left:50%;top:50%;
  transform-origin:0% 100%;
}
.pf-blade::before{
  content:'';position:absolute;inset:0;
  background:rgba(232,214,64,.18);
  border-radius:50% 0 50% 50%;
  border:1px solid rgba(232,214,64,.25);
}
<?php for($b=0;$b<$pf_blades;$b++): $angle = $b * (360/$pf_blades); ?>
.pf-blade:nth-child(<?php echo $b+1; ?>){transform:translate(-50%,-100%) rotate(<?php echo $angle; ?>deg);transform-origin:50% 100%;}
<?php endfor; ?>

/* Lens center dot */
.pf-lens-center{
  position:absolute;z-index:2;
  width:20px;height:20px;border-radius:50%;
  background:radial-gradient(circle,#e8d640,rgba(232,214,64,.3));
  box-shadow:0 0 16px rgba(232,214,64,.4);
  animation:pf-glow-pulse 2s ease-in-out infinite alternate;
}
@keyframes pf-glow-pulse{
  0%{box-shadow:0 0 8px rgba(232,214,64,.3)}
  100%{box-shadow:0 0 24px rgba(232,214,64,.7)}
}

/* Camera grip */
.pf-camera-grip{
  position:absolute;right:-22px;top:20px;
  width:22px;height:90px;
  background:linear-gradient(90deg,#1c1c20,#101012);
  border:2px solid rgba(245,245,240,.05);
  border-left:none;
  border-radius:0 8px 8px 0;
}

/* Film strip bottom */
.pf-film{
  width:300px;height:28px;margin-top:8px;
  background:repeating-linear-gradient(
    90deg,
    #1a1a1e 0px,#1a1a1e 12px,
    rgba(245,245,240,.06) 12px,rgba(245,245,240,.06) 14px,
    #1a1a1e 14px,#1a1a1e 26px
  );
  border:1px solid rgba(245,245,240,.05);
  border-radius:4px;
  position:relative;overflow:hidden;
}
.pf-film::before{
  content:'';position:absolute;top:25%;bottom:25%;left:0;right:0;
  background:repeating-linear-gradient(
    90deg,
    rgba(232,214,64,.08) 0px,rgba(232,214,64,.08) 1px,
    transparent 1px,transparent 26px
  );
}

/* Scene dot field */
.pf-scene::before{
  content:'';position:absolute;inset:0;z-index:0;
  background-image:radial-gradient(circle,rgba(245,245,240,.06) 1px,transparent 1px);
  background-size:32px 32px;
  pointer-events:none;
}

/* Hero background text */
.pf-hero-bg-text{
  position:absolute;bottom:-2rem;left:0;
  font-family:var(--pf-font-h);font-size:clamp(8rem,18vw,20rem);
  color:rgba(245,245,240,.02);line-height:1;pointer-events:none;
  letter-spacing:.05em;white-space:nowrap;
  z-index:0;
}

/* ═══════════════════════════════════════════════
   STATS BAR
═══════════════════════════════════════════════ */
.pf-stats{
  background:var(--pf-bg2);
  border-top:1px solid var(--pf-border);border-bottom:1px solid var(--pf-border);
  padding:2rem 0;
}
.pf-stats-inner{
  display:flex;justify-content:space-around;align-items:center;flex-wrap:wrap;gap:1.5rem;
}
.pf-stat{text-align:center}
.pf-stat-num{
  display:block;font-family:var(--pf-font-h);font-size:2.8rem;
  color:var(--pf-yellow);line-height:1;letter-spacing:.04em;
}
.pf-stat-label{font-size:.68rem;color:var(--pf-muted);letter-spacing:.14em;text-transform:uppercase;margin-top:.2rem}

/* ═══════════════════════════════════════════════
   PROJECT GRID (filterable)
═══════════════════════════════════════════════ */
.pf-work-head{
  display:flex;justify-content:space-between;align-items:flex-end;
  flex-wrap:wrap;gap:1.5rem;margin-bottom:2.5rem;
}
.pf-filter-bar{
  display:flex;gap:.25rem;flex-wrap:wrap;
}
.pf-filter-btn{
  padding:.4rem .9rem;
  background:transparent;border:1px solid var(--pf-border);
  font-family:var(--pf-font-b);font-size:.68rem;letter-spacing:.1em;text-transform:uppercase;
  color:var(--pf-muted);cursor:pointer;transition:all .2s;
}
.pf-filter-btn:hover{border-color:var(--pf-yellow);color:var(--pf-yellow)}
.pf-filter-btn.active{background:var(--pf-yellow);border-color:var(--pf-yellow);color:#000}
.pf-project-grid{
  display:grid;
  grid-template-columns:repeat(4,1fr);
  grid-auto-rows:240px;
  gap:3px;
}
@media(max-width:900px){.pf-project-grid{grid-template-columns:repeat(2,1fr);grid-auto-rows:200px}}
@media(max-width:480px){.pf-project-grid{grid-template-columns:1fr;grid-auto-rows:220px}}

.pf-project-item{
  position:relative;overflow:hidden;
  cursor:pointer;
  background:var(--pf-bg3);
}
/* Featured items spanning */
.pf-project-item:nth-child(1){grid-column:span 2;grid-row:span 2}
.pf-project-item:nth-child(4){grid-column:span 2}
.pf-project-item:nth-child(7){grid-row:span 2}

.pf-project-scene{
  width:100%;height:100%;
  display:flex;align-items:center;justify-content:center;
  transition:transform .6s ease;
}
.pf-project-item:hover .pf-project-scene{transform:scale(1.06)}

/* CSS abstract photo placeholder */
.pf-project-art{
  width:70%;height:70%;
  position:relative;display:flex;align-items:center;justify-content:center;
}
.pf-project-art-bg{
  position:absolute;inset:0;
  border-radius:50% 40% 60% 50% / 60% 50% 40% 50%;
}
.pf-project-art-circle{
  width:40%;height:40%;border-radius:50%;
  position:relative;z-index:2;
}
.pf-project-art-line{
  position:absolute;height:1px;width:80%;
  background:rgba(255,255,255,.2);
}

.pf-project-overlay{
  position:absolute;inset:0;
  background:linear-gradient(0deg,rgba(0,0,0,.85) 0%,transparent 50%);
  transition:opacity .35s;
  opacity:.7;
}
.pf-project-info{
  position:absolute;bottom:0;left:0;right:0;
  padding:1.5rem;
  transform:translateY(4px);
  transition:transform .35s;
}
.pf-project-item:hover .pf-project-info{transform:translateY(0)}
.pf-project-cat{
  font-size:.62rem;letter-spacing:.16em;text-transform:uppercase;
  color:var(--pf-yellow);margin-bottom:.3rem;display:block;
}
.pf-project-title{
  font-family:var(--pf-font-h);font-size:1.4rem;letter-spacing:.04em;
  color:var(--pf-white);line-height:1.1;
}
.pf-project-client{
  font-size:.72rem;color:rgba(245,245,240,.55);margin-top:.25rem;
}
.pf-project-year{
  position:absolute;top:1rem;right:1rem;
  font-size:.62rem;color:rgba(245,245,240,.4);letter-spacing:.1em;
}

/* Hidden when filtered out */
.pf-project-item.hidden{display:none}

/* ═══════════════════════════════════════════════
   ABOUT
═══════════════════════════════════════════════ */
.pf-about{background:var(--pf-bg2)}
.pf-about-inner{
  display:grid;grid-template-columns:1fr 1fr;gap:5rem;align-items:center;
}
@media(max-width:800px){.pf-about-inner{grid-template-columns:1fr}}

/* CSS self-portrait placeholder */
.pf-portrait-wrap{
  position:relative;
  height:500px;
  background:linear-gradient(135deg,var(--pf-bg3),var(--pf-bg));
  border:1px solid var(--pf-border);
  overflow:hidden;
  display:flex;align-items:flex-end;justify-content:center;
}
.pf-portrait-figure{
  position:relative;
  display:flex;flex-direction:column;align-items:center;
  margin-bottom:0;
  z-index:2;
}
.pf-portrait-head{
  width:80px;height:80px;border-radius:50%;
  background:radial-gradient(circle at 40% 35%,#c4906a,#8b5e3c);
  position:relative;
}
.pf-portrait-head::before{
  content:'';position:absolute;top:-12px;left:8px;
  width:64px;height:28px;
  border-radius:50% 50% 0 0;
  background:#3a2010;
}
.pf-portrait-body{
  width:130px;height:180px;
  background:linear-gradient(180deg,#1a1820,#101015);
  border-radius:4px 4px 0 0;
  margin-top:-10px;
  position:relative;
}
.pf-portrait-camera-el{
  position:absolute;top:30px;left:50%;transform:translateX(-50%);
  width:50px;height:35px;
  background:linear-gradient(180deg,#2a2a30,#181820);
  border-radius:4px;
  display:flex;align-items:center;justify-content:center;
}
.pf-portrait-camera-el::after{
  content:'';
  width:20px;height:20px;border-radius:50%;
  background:radial-gradient(circle,#080808,#141416);
  border:3px solid #2a2a30;
}
.pf-portrait-bg{
  position:absolute;inset:0;
  background:
    radial-gradient(circle at 30% 20%,rgba(232,214,64,.05),transparent 50%),
    repeating-linear-gradient(45deg,
      rgba(245,245,240,.015) 0px,rgba(245,245,240,.015) 1px,
      transparent 1px,transparent 24px
    );
}
.pf-portrait-label{
  position:absolute;bottom:1rem;left:1rem;
  font-family:var(--pf-font-h);font-size:5rem;letter-spacing:.04em;
  color:rgba(245,245,240,.04);line-height:1;
}
.pf-portrait-award{
  position:absolute;top:1.5rem;right:1.5rem;
  padding:.75rem 1rem;
  background:var(--pf-yellow);color:#000;
  font-family:var(--pf-font-h);font-size:1rem;letter-spacing:.06em;
  text-align:center;
  line-height:1.2;
}

.pf-about-text .pf-h2{margin:1rem 0 1.5rem}
.pf-about-text p{color:var(--pf-muted);line-height:1.9;margin-bottom:1rem;font-size:.95rem}
.pf-about-text p strong{color:var(--pf-white)}
.pf-about-awards{
  margin-top:2rem;display:grid;grid-template-columns:1fr 1fr;gap:.75rem;
}
.pf-award-item{
  padding:.75rem 1rem;border:1px solid var(--pf-border);
  transition:border-color .2s;
}
.pf-award-item:hover{border-color:rgba(232,214,64,.3)}
.pf-award-name{font-size:.72rem;color:var(--pf-yellow);letter-spacing:.08em;margin-bottom:.15rem}
.pf-award-cat{font-size:.78rem;color:var(--pf-white)}
.pf-award-year{font-size:.62rem;color:var(--pf-muted)}

/* ═══════════════════════════════════════════════
   SERVICES
═══════════════════════════════════════════════ */
.pf-services-head{text-align:center;margin-bottom:3.5rem}
.pf-services-head .pf-h2{margin:1rem 0}
.pf-services-grid{
  display:grid;grid-template-columns:repeat(4,1fr);gap:1.5rem;
}
@media(max-width:900px){.pf-services-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:480px){.pf-services-grid{grid-template-columns:1fr}}
.pf-service-card{
  padding:2rem 1.75rem;
  border:1px solid var(--pf-border);
  background:var(--pf-bg2);
  border-top:2px solid var(--pf-yellow);
  transition:background .25s,transform .25s;
}
.pf-service-card:hover{background:var(--pf-bg3);transform:translateY(-3px)}
.pf-service-name{
  font-family:var(--pf-font-h);font-size:1.4rem;letter-spacing:.04em;
  color:var(--pf-white);margin-bottom:1.25rem;
}
.pf-service-items{list-style:none;margin-bottom:1.5rem}
.pf-service-items li{
  font-size:.8rem;color:var(--pf-muted);padding:.45rem 0;
  border-bottom:1px solid var(--pf-border);
  display:flex;align-items:center;gap:.5rem;
}
.pf-service-items li::before{content:'→';color:var(--pf-yellow);font-size:.65rem}
.pf-service-price{
  font-family:var(--pf-font-h);font-size:1rem;color:var(--pf-yellow);letter-spacing:.04em;
}

/* ═══════════════════════════════════════════════
   CLIENT MARQUEE
═══════════════════════════════════════════════ */
.pf-clients{
  background:var(--pf-bg2);
  border-top:1px solid var(--pf-border);border-bottom:1px solid var(--pf-border);
  padding:2.5rem 0;overflow:hidden;
}
.pf-clients-label{
  text-align:center;font-size:.65rem;letter-spacing:.2em;text-transform:uppercase;
  color:var(--pf-muted);margin-bottom:1.5rem;
}
.pf-marquee-track{
  display:flex;width:max-content;gap:4rem;
  animation:pf-marquee 22s linear infinite;
}
@keyframes pf-marquee{
  0%{transform:translateX(0)}
  100%{transform:translateX(-50%)}
}
.pf-marquee-item{
  font-family:var(--pf-font-h);font-size:1.4rem;letter-spacing:.1em;text-transform:uppercase;
  color:rgba(245,245,240,.2);white-space:nowrap;transition:color .25s;
}
.pf-marquee-item:hover{color:var(--pf-yellow)}
.pf-marquee-sep{color:rgba(232,214,64,.3);align-self:center;font-size:.8rem}

/* ═══════════════════════════════════════════════
   PROCESS
═══════════════════════════════════════════════ */
.pf-process{background:var(--pf-bg)}
.pf-process-head{text-align:center;margin-bottom:3.5rem}
.pf-process-steps{
  display:grid;grid-template-columns:repeat(5,1fr);gap:0;
  position:relative;max-width:1000px;margin:0 auto;
}
.pf-process-steps::before{
  content:'';position:absolute;top:24px;left:10%;right:10%;height:1px;
  background:linear-gradient(90deg,transparent,var(--pf-border),var(--pf-border),transparent);
  z-index:0;
}
@media(max-width:700px){.pf-process-steps{grid-template-columns:1fr;max-width:320px}}
@media(max-width:700px){.pf-process-steps::before{display:none}}
.pf-step{text-align:center;padding:0 .75rem;position:relative;z-index:1}
.pf-step-num{
  width:48px;height:48px;border-radius:50%;
  background:var(--pf-bg2);border:1px solid var(--pf-border);
  display:inline-flex;align-items:center;justify-content:center;
  font-family:var(--pf-font-h);font-size:1.3rem;color:var(--pf-yellow);letter-spacing:.04em;
  margin-bottom:1rem;
  transition:border-color .25s,background .25s;
}
.pf-step:hover .pf-step-num{border-color:var(--pf-yellow);background:var(--pf-glass)}
.pf-step-title{font-size:.78rem;font-weight:600;color:var(--pf-white);margin-bottom:.35rem;letter-spacing:.06em;text-transform:uppercase}
.pf-step-desc{font-size:.72rem;color:var(--pf-muted);line-height:1.6}

/* ═══════════════════════════════════════════════
   CONTACT
═══════════════════════════════════════════════ */
.pf-contact{background:var(--pf-bg2)}
.pf-contact-inner{
  display:grid;grid-template-columns:1fr 1fr;gap:5rem;align-items:start;
}
@media(max-width:800px){.pf-contact-inner{grid-template-columns:1fr}}
.pf-contact-copy .pf-h2{margin:1rem 0 1.5rem}
.pf-contact-copy p{color:var(--pf-muted);margin-bottom:1rem;line-height:1.85}
.pf-contact-details{
  margin-top:2rem;display:flex;flex-direction:column;gap:.75rem;
}
.pf-contact-detail{
  display:flex;align-items:center;gap:1rem;
  padding:.85rem 1rem;border:1px solid var(--pf-border);
  font-size:.85rem;color:var(--pf-muted);
  transition:border-color .2s;
}
.pf-contact-detail:hover{border-color:rgba(232,214,64,.3);color:var(--pf-white)}
.pf-contact-detail a{color:inherit}
.pf-contact-icon{color:var(--pf-yellow);width:20px;text-align:center;flex-shrink:0}

.pf-form{background:var(--pf-bg);border:1px solid var(--pf-border);padding:2.5rem}
.pf-form-title{
  font-family:var(--pf-font-h);font-size:2rem;letter-spacing:.04em;
  color:var(--pf-white);margin-bottom:.25rem;
}
.pf-form-sub{font-size:.78rem;color:var(--pf-muted);margin-bottom:2rem}
.pf-field{margin-bottom:1.2rem}
.pf-label{display:block;font-size:.65rem;letter-spacing:.14em;text-transform:uppercase;color:var(--pf-muted);margin-bottom:.45rem}
.pf-input,.pf-select,.pf-textarea{
  width:100%;padding:.85rem 1rem;
  background:rgba(245,245,240,.03);border:1px solid var(--pf-border);
  color:var(--pf-white);font-family:var(--pf-font-b);font-size:.9rem;
  outline:none;transition:border-color .25s;border-radius:0;-webkit-appearance:none;
}
.pf-input:focus,.pf-select:focus,.pf-textarea:focus{border-color:rgba(232,214,64,.5)}
.pf-input::placeholder{color:rgba(245,245,240,.2)}
.pf-select option{background:var(--pf-bg2);color:var(--pf-white)}
.pf-textarea{height:100px;resize:vertical}
.pf-form-row{display:grid;grid-template-columns:1fr 1fr;gap:1rem}
@media(max-width:500px){.pf-form-row{grid-template-columns:1fr}}
.pf-submit{
  width:100%;padding:1rem;
  background:var(--pf-yellow);color:#000;
  border:none;cursor:pointer;
  font-family:var(--pf-font-b);font-size:.8rem;font-weight:700;
  letter-spacing:.14em;text-transform:uppercase;transition:background .25s;
  margin-top:.5rem;
}
.pf-submit:hover{background:#fff}
.pf-form-note{font-size:.65rem;color:var(--pf-muted);text-align:center;margin-top:.75rem}

/* ═══════════════════════════════════════════════
   FOOTER
═══════════════════════════════════════════════ */
.pf-footer{
  background:var(--pf-bg);border-top:1px solid var(--pf-border);
  padding:3rem 0 1.5rem;
}
.pf-footer-inner{
  display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:2rem;
  margin-bottom:2rem;
}
.pf-footer-logo{
  font-family:var(--pf-font-h);font-size:1.8rem;letter-spacing:.06em;color:var(--pf-white);
}
.pf-footer-logo span{color:var(--pf-yellow)}
.pf-footer-links{display:flex;gap:1.5rem;list-style:none;flex-wrap:wrap}
.pf-footer-links a{color:var(--pf-muted);font-size:.78rem;letter-spacing:.08em;text-transform:uppercase;transition:color .2s}
.pf-footer-links a:hover{color:var(--pf-yellow)}
.pf-footer-socials{display:flex;gap:.75rem}
.pf-social{
  width:36px;height:36px;border:1px solid var(--pf-border);
  display:flex;align-items:center;justify-content:center;
  font-size:.9rem;color:var(--pf-muted);transition:all .2s;
}
.pf-social:hover{border-color:var(--pf-yellow);color:var(--pf-yellow)}
.pf-footer-bottom{
  display:flex;justify-content:space-between;align-items:center;
  padding-top:1.5rem;border-top:1px solid var(--pf-border);
  font-size:.68rem;color:rgba(245,245,240,.3);
}
@media(max-width:500px){.pf-footer-bottom{flex-direction:column;gap:.5rem;text-align:center}}

/* ── Scroll reveal ── */
.pf-reveal{opacity:0;transform:translateY(20px);transition:opacity .55s ease,transform .55s ease}
.pf-reveal.visible{opacity:1;transform:none}
</style>
<?php get_header(); ?>
<div class="pf-page">

<!-- ── NAV ── -->
<nav class="pf-nav" id="pf-nav" aria-label="Hauptnavigation">
  <div class="pf-nav-logo">Lens<span>&amp;</span>Light</div>
  <ul class="pf-nav-links">
    <li><a href="#arbeiten">Arbeiten</a></li>
    <li><a href="#about">Über mich</a></li>
    <li><a href="#leistungen">Leistungen</a></li>
    <li><a href="#kontakt">Kontakt</a></li>
  </ul>
  <a href="#kontakt" class="pf-nav-contact">Projekt anfragen</a>
</nav>

<!-- ═══════════════════════════════════════════════
     HERO
═══════════════════════════════════════════════ -->
<section class="pf-hero">
  <div class="pf-hero-bg-text" aria-hidden="true">FOTO</div>

  <div class="pf-hero-copy">
    <div class="pf-hero-kicker">Freie Fotografin · Berlin</div>
    <h1 class="pf-h1">
      BILDER<br>
      DIE<br>
      BLEIBEN
    </h1>
    <div class="pf-hero-name">— Clara Möller Photography</div>
    <p class="pf-hero-sub">
      Editorial, Kampagne und Fine Art. Ich arbeite mit Unternehmen, Magazinen
      und Künstlern, die Wert auf visuelle Tiefe und handwerkliche Exzellenz legen.
    </p>
    <div class="pf-hero-ctas">
      <a href="#arbeiten" class="pf-btn pf-btn-primary">Portfolio ansehen</a>
      <a href="#kontakt" class="pf-btn pf-btn-outline">Anfrage senden</a>
    </div>
    <div class="pf-hero-scroll" onclick="document.getElementById('arbeiten').scrollIntoView({behavior:'smooth'})">
      <div class="pf-scroll-line"></div>
      Scrollen
    </div>
  </div>

  <!-- Camera scene -->
  <div class="pf-scene" aria-hidden="true">
    <div class="pf-scene-bg"></div>
    <?php foreach($pf_flares as $fi => $f): ?>
    <div class="pf-flare-<?php echo $fi; ?>"></div>
    <?php endforeach; ?>

    <div class="pf-camera">
      <div class="pf-camera-body">
        <div class="pf-mode-dial"></div>
        <div class="pf-camera-grip"></div>
        <div class="pf-lens">
          <div class="pf-aperture">
            <?php for($b=0;$b<$pf_blades;$b++): ?>
            <div class="pf-blade"></div>
            <?php endfor; ?>
          </div>
          <div class="pf-lens-center"></div>
        </div>
      </div>
      <div class="pf-film"></div>
    </div>
  </div>
</section>

<!-- ── STATS ── -->
<div class="pf-stats">
  <div class="pf-stats-inner">
    <div class="pf-stat">
      <span class="pf-stat-num" data-target="240" data-suffix="+">0</span>
      <span class="pf-stat-label">Projekte</span>
    </div>
    <div class="pf-stat">
      <span class="pf-stat-num" data-target="8" data-suffix="">0</span>
      <span class="pf-stat-label">Auszeichnungen</span>
    </div>
    <div class="pf-stat">
      <span class="pf-stat-num" data-target="12" data-suffix=" J.">0</span>
      <span class="pf-stat-label">Erfahrung</span>
    </div>
    <div class="pf-stat">
      <span class="pf-stat-num" data-target="40" data-suffix="+">0</span>
      <span class="pf-stat-label">Stammkunden</span>
    </div>
  </div>
</div>

<!-- ═══════════════════════════════════════════════
     PORTFOLIO GRID
═══════════════════════════════════════════════ -->
<section class="pf-section" id="arbeiten">
  <div class="pf-container">
    <div class="pf-work-head">
      <div class="pf-reveal">
        <div class="pf-tag">Portfolio</div>
        <h2 class="pf-h2" style="margin:.75rem 0 0">Ausgewählte Arbeiten</h2>
      </div>
      <div class="pf-filter-bar pf-reveal" role="group" aria-label="Kategorie-Filter">
        <?php foreach($pf_categories as $cat): ?>
        <button
          class="pf-filter-btn<?php echo $cat==='Alle'?' active':''; ?>"
          data-filter="<?php echo esc_attr($cat); ?>"
        ><?php echo esc_html($cat); ?></button>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="pf-project-grid" id="pf-project-grid">
      <?php foreach($pf_projects as $pi => $proj): ?>
      <div
        class="pf-project-item"
        data-cat="<?php echo esc_attr($proj['cat']); ?>"
        tabindex="0"
        role="button"
        aria-label="<?php echo esc_attr($proj['title']); ?>"
      >
        <div class="pf-project-scene" style="background:<?php echo esc_attr($proj['color']); ?>">
          <!-- CSS abstract art -->
          <div class="pf-project-art">
            <div class="pf-project-art-bg" style="background:radial-gradient(ellipse,<?php echo esc_attr($proj['accent']); ?>22,transparent)"></div>
            <div class="pf-project-art-circle" style="background:radial-gradient(circle,<?php echo esc_attr($proj['accent']); ?>55,transparent)"></div>
            <div class="pf-project-art-line" style="background:<?php echo esc_attr($proj['accent']); ?>33"></div>
          </div>
        </div>
        <div class="pf-project-overlay"></div>
        <div class="pf-project-year"><?php echo esc_html($proj['year']); ?></div>
        <div class="pf-project-info">
          <span class="pf-project-cat"><?php echo esc_html($proj['cat']); ?></span>
          <div class="pf-project-title"><?php echo esc_html($proj['title']); ?></div>
          <div class="pf-project-client"><?php echo $proj['client']; // may contain &amp; ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     ABOUT
═══════════════════════════════════════════════ -->
<section class="pf-about pf-section" id="about">
  <div class="pf-container">
    <div class="pf-about-inner">
      <!-- CSS portrait -->
      <div class="pf-portrait-wrap pf-reveal" aria-hidden="true">
        <div class="pf-portrait-bg"></div>
        <div class="pf-portrait-label">CM</div>
        <div class="pf-portrait-award">World<br>Press<br>Photo</div>
        <div class="pf-portrait-figure">
          <div class="pf-portrait-head"></div>
          <div class="pf-portrait-body">
            <div class="pf-portrait-camera-el"></div>
          </div>
        </div>
      </div>

      <div class="pf-about-text pf-reveal">
        <div class="pf-tag">Über mich</div>
        <h2 class="pf-h2">Clara Möller</h2>
        <p>Ich fotografiere, seit ich denken kann. Was als Leidenschaft begann, ist heute mein Beruf — und immer noch meine Leidenschaft. <strong>Seit 12 Jahren</strong> arbeite ich für Magazine, Marken und Institutionen, die wissen, dass Bilder mehr sagen als Worte.</p>
        <p>Meine Arbeit verbindet handwerkliche Präzision mit einem ehrlichen Blick. Ich suche den Moment, der bleibt. Ob auf dem Laufsteg, in urbanen Ruinen oder im stillen Atelier — <strong>Licht und Komposition</strong> sind meine Sprache.</p>
        <p>Ich arbeite von Berlin aus, bin aber regelmäßig in ganz Europa unterwegs. Großprojekte mit internationalem Team — kein Problem.</p>
        <a href="#kontakt" class="pf-btn pf-btn-primary" style="margin-top:1.5rem">Zusammenarbeiten →</a>

        <div class="pf-about-awards">
          <?php foreach($pf_awards as $aw): ?>
          <div class="pf-award-item">
            <div class="pf-award-name"><?php echo esc_html($aw['award']); ?></div>
            <div class="pf-award-cat"><?php echo esc_html($aw['cat']); ?></div>
            <div class="pf-award-year"><?php echo esc_html($aw['year']); ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     SERVICES
═══════════════════════════════════════════════ -->
<section class="pf-section" id="leistungen" style="background:var(--pf-bg)">
  <div class="pf-container">
    <div class="pf-services-head pf-reveal">
      <div class="pf-tag">Leistungen</div>
      <h2 class="pf-h2" style="margin:1rem 0">Was ich anbiete</h2>
      <p class="pf-muted" style="max-width:480px;margin:0 auto">Jedes Projekt ist einmalig — deshalb sind meine Angebote flexibel. Hier ein Überblick über meine Kernleistungen.</p>
    </div>
    <div class="pf-services-grid">
      <?php foreach($pf_services as $sv): ?>
      <div class="pf-service-card pf-reveal">
        <div class="pf-service-name"><?php echo esc_html($sv['name']); ?></div>
        <ul class="pf-service-items">
          <?php foreach($sv['items'] as $it): ?>
          <li><?php echo esc_html($it); ?></li>
          <?php endforeach; ?>
        </ul>
        <div class="pf-service-price"><?php echo esc_html($sv['price']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── CLIENT MARQUEE ── -->
<div class="pf-clients">
  <div class="pf-clients-label">Kunden & Auftraggeber</div>
  <div style="overflow:hidden">
    <div class="pf-marquee-track">
      <?php foreach(array_merge($pf_clients, $pf_clients) as $cli): ?>
      <span class="pf-marquee-item"><?php echo esc_html($cli); ?></span>
      <span class="pf-marquee-sep" aria-hidden="true">✦</span>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- ═══════════════════════════════════════════════
     PROCESS
═══════════════════════════════════════════════ -->
<section class="pf-process pf-section">
  <div class="pf-container">
    <div class="pf-process-head pf-reveal">
      <div class="pf-tag">Wie ich arbeite</div>
      <h2 class="pf-h2" style="margin:1rem 0">Der Prozess</h2>
    </div>
    <div class="pf-process-steps">
      <?php
      $steps = [
        ['num'=>'01','title'=>'Briefing',    'desc'=>'Wir sprechen über Ziele, Zielgruppe und Vision.'],
        ['num'=>'02','title'=>'Konzept',     'desc'=>'Mood Board, Locations, Cast und Zeitplan.'],
        ['num'=>'03','title'=>'Produktion',  'desc'=>'Shooting — mit vollem Fokus auf dein Ziel.'],
        ['num'=>'04','title'=>'Post',        'desc'=>'Bildauswahl, Retusche und Farbkorrektur.'],
        ['num'=>'05','title'=>'Lieferung',   'desc'=>'Druckfertige Dateien oder digitale Assets.'],
      ];
      foreach($steps as $step):
      ?>
      <div class="pf-step pf-reveal">
        <div class="pf-step-num"><?php echo esc_html($step['num']); ?></div>
        <div class="pf-step-title"><?php echo esc_html($step['title']); ?></div>
        <div class="pf-step-desc"><?php echo esc_html($step['desc']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     CONTACT
═══════════════════════════════════════════════ -->
<section class="pf-contact pf-section" id="kontakt">
  <div class="pf-container">
    <div class="pf-contact-inner">
      <div class="pf-contact-copy pf-reveal">
        <div class="pf-tag">Kontakt</div>
        <h2 class="pf-h2" style="margin:1rem 0">Lass uns zusammen<br><span class="pf-yellow-c">arbeiten</span></h2>
        <p>Ob Kampagne, Reportage oder Fine Art-Projekt — ich freue mich auf Anfragen aller Art. Schreib mir, ruf an, oder füll das Formular aus.</p>
        <p>Ich antworte in der Regel <strong style="color:var(--pf-white)">innerhalb von 24 Stunden</strong>.</p>
        <div class="pf-contact-details">
          <div class="pf-contact-detail">
            <span class="pf-contact-icon">✉</span>
            <a href="mailto:hello@claramoeller.de">hello@claramoeller.de</a>
          </div>
          <div class="pf-contact-detail">
            <span class="pf-contact-icon">📞</span>
            <a href="tel:+4930123456789">+49 30 123 456 789</a>
          </div>
          <div class="pf-contact-detail">
            <span class="pf-contact-icon">📍</span>
            <span>Berlin-Prenzlauer Berg, Deutschland</span>
          </div>
          <div class="pf-contact-detail">
            <span class="pf-contact-icon">◎</span>
            <span>Europaweit verfügbar</span>
          </div>
        </div>
      </div>

      <div class="pf-form pf-reveal">
        <div class="pf-form-title">Projekt anfragen</div>
        <div class="pf-form-sub">Kostenlos & unverbindlich</div>
        <form method="post" action="" novalidate>
          <?php wp_nonce_field('tf_pf_contact', 'tf_pf_nonce'); ?>
          <div class="pf-form-row">
            <div class="pf-field">
              <label class="pf-label" for="pf-name">Name *</label>
              <input type="text" id="pf-name" name="pf_name" class="pf-input" required placeholder="Max Mustermann">
            </div>
            <div class="pf-field">
              <label class="pf-label" for="pf-company">Unternehmen</label>
              <input type="text" id="pf-company" name="pf_company" class="pf-input" placeholder="Agentur / Magazin">
            </div>
          </div>
          <div class="pf-field">
            <label class="pf-label" for="pf-email">E-Mail *</label>
            <input type="email" id="pf-email" name="pf_email" class="pf-input" required placeholder="max@agentur.de">
          </div>
          <div class="pf-form-row">
            <div class="pf-field">
              <label class="pf-label" for="pf-type">Projekttyp *</label>
              <select id="pf-type" name="pf_type" class="pf-select" required>
                <option value="">Bitte wählen</option>
                <option value="editorial">Editorial</option>
                <option value="kampagne">Kampagne</option>
                <option value="portrait">Portrait</option>
                <option value="architektur">Architektur</option>
                <option value="produkt">Produkt</option>
                <option value="fineart">Fine Art</option>
                <option value="andere">Andere</option>
              </select>
            </div>
            <div class="pf-field">
              <label class="pf-label" for="pf-budget">Budget (ca.)</label>
              <select id="pf-budget" name="pf_budget" class="pf-select">
                <option value="">Offen</option>
                <option value="1k-3k">€ 1.000 – 3.000</option>
                <option value="3k-8k">€ 3.000 – 8.000</option>
                <option value="8k-20k">€ 8.000 – 20.000</option>
                <option value="20k+">€ 20.000+</option>
              </select>
            </div>
          </div>
          <div class="pf-field">
            <label class="pf-label" for="pf-message">Beschreibung *</label>
            <textarea id="pf-message" name="pf_message" class="pf-textarea" required placeholder="Kurze Beschreibung des Projekts, Zeitraum, Ort …"></textarea>
          </div>
          <button type="submit" class="pf-submit">Anfrage senden →</button>
          <p class="pf-form-note">Alle Daten werden vertraulich behandelt und nicht weitergegeben.</p>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     FOOTER
═══════════════════════════════════════════════ -->
<footer class="pf-footer">
  <div class="pf-container">
    <div class="pf-footer-inner">
      <div class="pf-footer-logo">Lens<span>&amp;</span>Light</div>
      <ul class="pf-footer-links">
        <li><a href="#arbeiten">Portfolio</a></li>
        <li><a href="#about">Über mich</a></li>
        <li><a href="#leistungen">Leistungen</a></li>
        <li><a href="#kontakt">Kontakt</a></li>
        <li><a href="<?php echo esc_url(get_privacy_policy_url()); ?>">Datenschutz</a></li>
      </ul>
      <div class="pf-footer-socials">
        <a href="#" class="pf-social" aria-label="Instagram">📸</a>
        <a href="#" class="pf-social" aria-label="LinkedIn">💼</a>
        <a href="#" class="pf-social" aria-label="Behance">🎨</a>
      </div>
    </div>
    <div class="pf-footer-bottom">
      <span>&copy; <?php echo date('Y'); ?> Clara Möller · Lens &amp; Light. Alle Rechte vorbehalten.</span>
      <span>Ein ThemeFlex-Template</span>
    </div>
  </div>
</footer>

<script>
(function(){
  'use strict';

  /* ── Nav scroll class ── */
  const nav = document.getElementById('pf-nav');
  window.addEventListener('scroll', () => {
    if(nav) nav.classList.toggle('scrolled', window.scrollY > 60);
  }, {passive:true});

  /* ── Portfolio filter ── */
  const filterBtns = document.querySelectorAll('.pf-filter-btn');
  const projectItems = document.querySelectorAll('.pf-project-item');
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const filter = btn.dataset.filter;
      projectItems.forEach(item => {
        const match = filter === 'Alle' || item.dataset.cat === filter;
        item.classList.toggle('hidden', !match);
      });
    });
  });

  /* ── Animated counters ── */
  const counters = document.querySelectorAll('[data-target]');
  if(counters.length && 'IntersectionObserver' in window){
    const easeOut = t => 1 - Math.pow(1-t,3);
    const io = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if(!entry.isIntersecting) return;
        const el = entry.target;
        const target = parseFloat(el.dataset.target);
        const suffix = el.dataset.suffix || '';
        const dur = 1600;
        let start = null;
        const tick = ts => {
          if(!start) start = ts;
          const p = Math.min((ts-start)/dur,1);
          el.textContent = Math.round(easeOut(p)*target) + suffix;
          if(p<1) requestAnimationFrame(tick);
          else el.textContent = target + suffix;
        };
        requestAnimationFrame(tick);
        io.unobserve(el);
      });
    },{threshold:.25});
    counters.forEach(c => io.observe(c));
  }

  /* ── Scroll reveal ── */
  if('IntersectionObserver' in window){
    const rIO = new IntersectionObserver(entries=>{
      entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');rIO.unobserve(e.target);}});
    },{threshold:.08});
    document.querySelectorAll('.pf-reveal').forEach(el=>rIO.observe(el));
  } else {
    document.querySelectorAll('.pf-reveal').forEach(el=>el.classList.add('visible'));
  }

  /* ── Form stub ── */
  const form = document.querySelector('.pf-form form');
  if(form){
    form.addEventListener('submit',e=>{
      e.preventDefault();
      const btn=form.querySelector('.pf-submit');
      if(btn){btn.textContent='Anfrage gesendet ✓';btn.style.background='#fff';btn.disabled=true;}
    });
  }
})();
</script>

</body>
</html>

<?php
/**
 * ─────────────────────────────────────────────
 * ThemeFlex Photography Portfolio — Template Notes
 * ─────────────────────────────────────────────
 * Namespace      : --pf-* (Photography / Portfolio)
 * Design system  : Near-black #0C0C0C, Electric Yellow #FFE500
 * Typography     : Bebas Neue (display) + Inter (body)
 * Version        : 2.4.0
 * Last updated   : 2026-04-30
 *
 * Accessibility checklist (WCAG 2.1 AA):
 *   ✓ All images have descriptive alt attributes
 *   ✓ Keyboard-navigable lightbox with Escape to close
 *   ✓ Focus-visible outline styles applied globally
 *   ✓ Colour contrast ≥ 4.5:1 for all body text
 *   ✓ Animated elements respect prefers-reduced-motion
 *   ✓ Form fields labelled with explicit <label> elements
 *   ✓ ARIA roles applied to gallery and modal regions
 *   ✓ Lightbox traps focus when open, restores on close
 *
 * Performance checklist:
 *   ✓ Google Fonts loaded with preconnect + display=swap
 *   ✓ IntersectionObserver drives scroll animations
 *   ✓ Lazy loading on all gallery images (native + JS fallback)
 *   ✓ No external JS libraries beyond WordPress core
 *   ✓ CSS custom properties enable theme-level overrides
 *   ✓ Hero art rendered entirely in CSS — zero image requests
 *
 * SEO recommendations:
 *   title       : "[Photographer Name] — Photography Portfolio"
 *   description : "Award-winning photography portfolio. Commercial,
 *                  editorial, and fine art photography. Available
 *                  for commissions worldwide."
 *   schema.org  : Person + CreativeWork JSON-LD recommended
 *   og:type     : website
 *   og:image    : Featured portfolio image
 * ─────────────────────────────────────────────
 */
?>
</div><!-- .pf-page -->
<?php get_footer(); ?>
