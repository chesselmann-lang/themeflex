<?php
/**
 * Template Name: Pricing & Plans
 * Template Post Type: page
 *
 * ThemeFlex — Premium SaaS Pricing Page
 * Namespace  : --pr-*
 * Fonts      : Plus Jakarta Sans (headings) + Outfit (body)
 * Palette    : Void #0B0F1A | Iris #6B5BF5 | Aqua #00D4C8 | Slate #3A4566 | Cloud #EFF2FF
 */

if ( ! defined( 'ABSPATH' ) ) exit;
/* ─── DATA ──────────────────────────────────────────────── */

$pr_plans = [
  [
    'name'    => 'Starter',
    'price'   => '0',
    'period'  => 'forever',
    'colour'  => '#3A4566',
    'accent'  => '#00D4C8',
    'tagline' => 'Perfect for individuals and side projects getting started.',
    'featured'=> false,
    'cta'     => 'Get Started Free',
    'perks'   => [
      '3 active projects',
      '1 team member',
      '5 GB storage',
      'Core analytics dashboard',
      'Email support (48 h SLA)',
      'Public API access',
    ],
  ],
  [
    'name'    => 'Pro',
    'price'   => '49',
    'period'  => 'per month',
    'colour'  => '#6B5BF5',
    'accent'  => '#6B5BF5',
    'tagline' => 'The complete toolkit for growing teams and serious makers.',
    'featured'=> true,
    'cta'     => 'Start Pro Trial',
    'perks'   => [
      'Unlimited projects',
      'Up to 15 team members',
      '100 GB storage',
      'Advanced analytics & reports',
      'Priority support (4 h SLA)',
      'Full API + webhooks',
      'Custom domain',
      'White-label exports',
    ],
  ],
  [
    'name'    => 'Enterprise',
    'price'   => '199',
    'period'  => 'per month',
    'colour'  => '#3A4566',
    'accent'  => '#00D4C8',
    'tagline' => 'Tailored security, compliance, and unlimited scale for large orgs.',
    'featured'=> false,
    'cta'     => 'Contact Sales',
    'perks'   => [
      'Unlimited projects & members',
      'Unlimited storage',
      'Enterprise analytics + BI export',
      'Dedicated account manager',
      '1 h SLA + 24/7 phone support',
      'SSO / SAML 2.0',
      'SOC 2 Type II compliance',
      'On-prem deployment option',
      'Custom SLA contract',
    ],
  ],
];

$pr_features = [
  ['feature' => 'Active projects',            'starter' => '3',        'pro' => 'Unlimited',  'ent' => 'Unlimited'],
  ['feature' => 'Team members',               'starter' => '1',        'pro' => 'Up to 15',   'ent' => 'Unlimited'],
  ['feature' => 'Storage',                    'starter' => '5 GB',     'pro' => '100 GB',     'ent' => 'Unlimited'],
  ['feature' => 'API access',                 'starter' => '✓',        'pro' => '✓',          'ent' => '✓'],
  ['feature' => 'Webhooks',                   'starter' => '—',        'pro' => '✓',          'ent' => '✓'],
  ['feature' => 'Custom domain',              'starter' => '—',        'pro' => '✓',          'ent' => '✓'],
  ['feature' => 'White-label exports',        'starter' => '—',        'pro' => '✓',          'ent' => '✓'],
  ['feature' => 'Priority support',           'starter' => '—',        'pro' => '4 h SLA',    'ent' => '1 h SLA'],
  ['feature' => 'Dedicated account manager',  'starter' => '—',        'pro' => '—',          'ent' => '✓'],
  ['feature' => 'SSO / SAML 2.0',            'starter' => '—',        'pro' => '—',          'ent' => '✓'],
  ['feature' => 'SOC 2 Type II',             'starter' => '—',        'pro' => '—',          'ent' => '✓'],
  ['feature' => 'On-prem deployment',         'starter' => '—',        'pro' => '—',          'ent' => '✓'],
  ['feature' => 'Advanced analytics',         'starter' => 'Basic',    'pro' => 'Advanced',   'ent' => 'Enterprise BI'],
  ['feature' => 'Audit logs',                 'starter' => '—',        'pro' => '30 days',    'ent' => 'Unlimited'],
  ['feature' => 'Custom contracts & SLA',     'starter' => '—',        'pro' => '—',          'ent' => '✓'],
];

$pr_faqs = [
  ['q' => 'Can I change my plan at any time?',
   'a' => 'Absolutely. You can upgrade, downgrade, or cancel your plan at any point from your account settings. Upgrades take effect immediately; downgrades apply at the end of the current billing cycle. Unused time on paid plans is credited to your account.'],
  ['q' => 'Is there a free trial for Pro and Enterprise?',
   'a' => 'Yes — Pro comes with a 14-day free trial, no credit card required. Enterprise plans include a personalised onboarding session and a 30-day proof-of-concept period. Contact our sales team to arrange yours.'],
  ['q' => 'How does storage work across the team?',
   'a' => 'Storage is pooled across all team members on your workspace. On the Starter plan each account gets 5 GB. Pro workspaces share a 100 GB pool. Enterprise workspaces have no storage cap and can add on-prem object storage nodes.'],
  ['q' => 'What payment methods do you accept?',
   'a' => 'We accept all major credit and debit cards (Visa, Mastercard, Amex, Discover) as well as SEPA direct debit for EU customers and BACS for UK customers. Enterprise invoicing with NET-30 payment terms is available on request.'],
  ['q' => 'Do you offer discounts for annual billing?',
   'a' => 'Yes — pay annually and save 20% on all paid plans. Annual billing is available at checkout or via your account settings. We also offer 50% discounts for registered non-profits and verified educational institutions.'],
  ['q' => 'Where is my data stored and is it secure?',
   'a' => 'All data is stored encrypted at rest (AES-256) and in transit (TLS 1.3). Our infrastructure runs on ISO-27001-certified EU data centres (Frankfurt primary, Dublin failover). Enterprise customers can request a dedicated single-tenant environment or on-prem deployment.'],
  ['q' => 'What happens to my data if I cancel?',
   'a' => 'Your data remains accessible for 30 days after cancellation, giving you time to export everything. After 30 days, your workspace and all associated data are permanently deleted. We provide one-click CSV/JSON exports from your account settings at any time.'],
];

$pr_testimonials = [
  [
    'quote'  => 'Switching to the Pro plan was an instant game-changer. We shipped three times as many features in the month after upgrading — the advanced analytics alone justified the cost.',
    'name'   => 'Amara Osei',
    'role'   => 'CTO, Loopline Labs',
    'initials'=> 'AO',
    'colour' => '#6B5BF5',
  ],
  [
    'quote'  => 'The Enterprise tier gives our legal and security teams exactly what they need — SOC 2 compliance out of the box, SAML SSO, and a dedicated account manager who actually picks up the phone.',
    'name'   => 'Rajiv Mehta',
    'role'   => 'Head of Engineering, Vantara Group',
    'initials'=> 'RM',
    'colour' => '#00D4C8',
  ],
  [
    'quote'  => 'We started on Starter as a side project, scaled to Pro, and now run the full business on it. The migration between plans is genuinely seamless — no re-configuration, no downtime.',
    'name'   => 'Sofia Brennan',
    'role'   => 'Founder, Pulsar Studio',
    'initials'=> 'SB',
    'colour' => '#F59E0B',
  ],
  [
    'quote'  => 'Having a 4-hour SLA on support completely changed how we manage production incidents. The team is responsive, knowledgeable, and always follows up to make sure the fix held.',
    'name'   => 'James Okwu',
    'role'   => 'DevOps Lead, Brightfield Systems',
    'initials'=> 'JO',
    'colour' => '#EC4899',
  ],
];

$pr_trust = [
  ['ico'=>'🔒','t'=>'SOC 2 Type II','d'=>'Independently audited security controls'],
  ['ico'=>'🇪🇺','t'=>'GDPR Compliant','d'=>'EU data residency with DPA available'],
  ['ico'=>'⚡','t'=>'99.99% Uptime SLA','d'=>'Enterprise-grade infrastructure'],
  ['ico'=>'🛡️','t'=>'AES-256 Encryption','d'=>'At rest and in transit, always'],
];

$pr_stats = [
  ['v'=>'40,000+', 'l'=>'Teams Worldwide'],
  ['v'=>'99.99%',  'l'=>'Uptime (12 month avg)'],
  ['v'=>'4 h',     'l'=>'Median Support Response'],
  ['v'=>'4.9/5',   'l'=>'Average Review Score'],
];

?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
/* ── CSS CUSTOM PROPERTIES ─────────────────────────── */
:root {
  --pr-void  : #0B0F1A;
  --pr-iris  : #6B5BF5;
  --pr-aqua  : #00D4C8;
  --pr-slate : #3A4566;
  --pr-cloud : #EFF2FF;
  --pr-surface: #121828;
  --pr-card  : #171E30;
  --pr-border: rgba(107,91,245,.18);
  --pr-head  : 'Plus Jakarta Sans', sans-serif;
  --pr-body  : 'Outfit', sans-serif;
  --pr-r     : 12px;
}

/* ── RESET & BASE ──────────────────────────────────── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; }
body { background: var(--pr-void); color: #c9d1e8; font-family: var(--pr-body); line-height: 1.7; overflow-x: hidden; }
img { max-width: 100%; display: block; }
a { text-decoration: none; color: inherit; }

/* ── LAYOUT ────────────────────────────────────────── */
.pr-wrap { max-width: 1200px; margin: 0 auto; padding: 0 24px; }
.pr-wrap--narrow { max-width: 840px; margin: 0 auto; padding: 0 24px; }

/* ── TYPOGRAPHY HELPERS ────────────────────────────── */
.pr-eyebrow {
  font-family: var(--pr-body);
  font-size: .72rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: .2em;
  color: var(--pr-aqua);
  margin: 0 0 10px;
}
.pr-h2 {
  font-family: var(--pr-head);
  font-size: clamp(2rem, 4.5vw, 3rem);
  font-weight: 800;
  color: #ffffff;
  line-height: 1.15;
  letter-spacing: -.02em;
  margin: 0 0 16px;
}
.pr-lead {
  font-size: 1.05rem;
  color: #8896b5;
  max-width: 560px;
  margin: 0 auto 56px;
}

/* ── PILL / BADGE ──────────────────────────────────── */
.pr-badge {
  display: inline-block;
  background: linear-gradient(135deg, var(--pr-iris), var(--pr-aqua));
  color: #ffffff;
  font-family: var(--pr-body);
  font-size: .65rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: .14em;
  padding: 4px 12px;
  border-radius: 40px;
}

/* ── BUTTONS ───────────────────────────────────────── */
.pr-btn {
  display: inline-block;
  font-family: var(--pr-body);
  font-weight: 600;
  font-size: .88rem;
  letter-spacing: .03em;
  padding: 14px 28px;
  border-radius: 8px;
  cursor: pointer;
  transition: transform .2s, box-shadow .2s, opacity .2s;
  border: none;
}
.pr-btn:hover { transform: translateY(-2px); opacity: .92; }
.pr-btn--iris {
  background: var(--pr-iris);
  color: #ffffff;
  box-shadow: 0 8px 24px rgba(107,91,245,.35);
}
.pr-btn--iris:hover { box-shadow: 0 14px 36px rgba(107,91,245,.45); }
.pr-btn--ghost {
  background: transparent;
  color: #c9d1e8;
  border: 2px solid rgba(255,255,255,.14);
}
.pr-btn--ghost:hover { border-color: rgba(255,255,255,.3); color: #fff; }
.pr-btn--aqua {
  background: var(--pr-aqua);
  color: #0B0F1A;
  box-shadow: 0 8px 24px rgba(0,212,200,.3);
}

/* ── TOGGLE (monthly / annual) ─────────────────────── */
.pr-toggle-wrap { display: flex; align-items: center; justify-content: center; gap: 14px; margin-bottom: 56px; }
.pr-toggle-label { font-family: var(--pr-body); font-size: .9rem; color: #8896b5; }
.pr-toggle-label--active { color: #ffffff; font-weight: 600; }
.pr-toggle {
  position: relative; width: 52px; height: 28px;
  background: var(--pr-slate); border-radius: 14px; cursor: pointer;
  transition: background .3s;
}
.pr-toggle input { position: absolute; opacity: 0; width: 0; height: 0; }
.pr-toggle-knob {
  position: absolute; top: 4px; left: 4px;
  width: 20px; height: 20px; border-radius: 50%;
  background: #ffffff; transition: left .3s;
}
.pr-toggle input:checked ~ .pr-toggle-knob { left: 28px; }
.pr-toggle input:checked + .pr-toggle + .pr-toggle-wrap { background: var(--pr-iris); }
.pr-save-badge {
  background: rgba(0,212,200,.15);
  color: var(--pr-aqua);
  border: 1px solid rgba(0,212,200,.25);
  font-size: .7rem;
  font-weight: 700;
  letter-spacing: .1em;
  text-transform: uppercase;
  padding: 3px 10px;
  border-radius: 20px;
}

/* ── PLAN CARDS ────────────────────────────────────── */
.pr-plans { display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; margin-bottom: 96px; }
.pr-plan-card {
  background: var(--pr-card);
  border: 1px solid rgba(255,255,255,.07);
  border-radius: var(--pr-r);
  padding: 36px 30px;
  display: flex;
  flex-direction: column;
  position: relative;
  overflow: hidden;
  transition: transform .25s, box-shadow .25s;
}
.pr-plan-card:hover { transform: translateY(-4px); box-shadow: 0 24px 56px rgba(0,0,0,.5); }
.pr-plan-card--featured {
  transform: scale(1.03);
  border-color: var(--pr-iris);
  box-shadow: 0 0 0 2px var(--pr-iris), 0 32px 64px rgba(107,91,245,.25);
  background: linear-gradient(160deg, #1a1532 0%, #171E30 60%);
}
.pr-plan-card--featured:hover { transform: scale(1.03) translateY(-4px); }
.pr-plan-card::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0; height: 3px;
  background: linear-gradient(90deg, var(--accent-start, var(--pr-slate)), var(--accent-end, var(--pr-slate)));
}
.pr-plan-name { font-family: var(--pr-head); font-size: 1rem; font-weight: 700; color: #ffffff; letter-spacing: .04em; text-transform: uppercase; margin-bottom: 8px; }
.pr-plan-tagline { font-size: .83rem; color: #6d7fa8; line-height: 1.6; margin-bottom: 24px; }
.pr-plan-price-row { display: flex; align-items: baseline; gap: 6px; margin-bottom: 6px; }
.pr-plan-currency { font-family: var(--pr-head); font-size: 1.3rem; font-weight: 700; color: #8896b5; }
.pr-plan-price { font-family: var(--pr-head); font-size: 3.2rem; font-weight: 900; color: #ffffff; line-height: 1; letter-spacing: -.04em; }
.pr-plan-period { font-size: .78rem; color: #6d7fa8; align-self: flex-end; padding-bottom: 6px; }
.pr-plan-divider { height: 1px; background: rgba(255,255,255,.08); margin: 24px 0; }
.pr-perk-list { list-style: none; padding: 0; margin: 0 0 32px; display: flex; flex-direction: column; gap: 10px; flex: 1; }
.pr-perk-item { display: flex; gap: 10px; align-items: flex-start; font-size: .87rem; color: #a0adcc; }
.pr-perk-item::before { content: '✓'; color: var(--pr-aqua); font-weight: 700; flex-shrink: 0; margin-top: 1px; }
.pr-perk-item--off { color: #44506a; }
.pr-perk-item--off::before { content: '—'; color: #44506a; }

/* ── FEATURE TABLE ─────────────────────────────────── */
.pr-table-wrap { overflow-x: auto; margin-bottom: 96px; }
.pr-table { width: 100%; border-collapse: collapse; }
.pr-table th, .pr-table td {
  padding: 14px 20px;
  text-align: left;
  font-family: var(--pr-body);
  font-size: .88rem;
  border-bottom: 1px solid rgba(255,255,255,.06);
}
.pr-table thead th {
  font-family: var(--pr-head);
  font-size: .8rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: .1em;
  color: #ffffff;
  background: var(--pr-card);
  padding-top: 20px;
  padding-bottom: 20px;
}
.pr-table thead th:first-child { border-radius: var(--pr-r) 0 0 0; }
.pr-table thead th:last-child { border-radius: 0 var(--pr-r) 0 0; }
.pr-table thead th.pr-table-iris { color: var(--pr-iris); background: rgba(107,91,245,.08); border-top: 2px solid var(--pr-iris); }
.pr-table tbody tr:hover td { background: rgba(255,255,255,.02); }
.pr-table tbody td { color: #8896b5; }
.pr-table tbody td:first-child { color: #c9d1e8; font-weight: 500; }
.pr-table tbody td.pr-table-iris { background: rgba(107,91,245,.04); color: #c9d1e8; }
.pr-check { color: var(--pr-aqua); font-weight: 700; }
.pr-dash { color: #44506a; }

/* ── TESTIMONIALS ──────────────────────────────────── */
.pr-testimonials { display: grid; grid-template-columns: repeat(2, 1fr); gap: 24px; margin-bottom: 96px; }
.pr-tcard {
  background: var(--pr-card);
  border: 1px solid rgba(255,255,255,.07);
  border-radius: var(--pr-r);
  padding: 32px;
  position: relative;
}
.pr-tcard::before { content: '"'; position: absolute; top: 16px; right: 24px; font-size: 5rem; line-height: 1; color: rgba(255,255,255,.04); font-family: var(--pr-head); }
.pr-tcard-quote { font-size: .93rem; line-height: 1.75; color: #a0adcc; margin-bottom: 24px; font-style: italic; }
.pr-tcard-author { display: flex; align-items: center; gap: 14px; }
.pr-tcard-avatar { width: 44px; height: 44px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-family: var(--pr-head); font-weight: 800; font-size: .9rem; color: #ffffff; flex-shrink: 0; }
.pr-tcard-name { font-family: var(--pr-head); font-size: .92rem; font-weight: 700; color: #ffffff; }
.pr-tcard-role { font-size: .78rem; color: #6d7fa8; }

/* ── FAQ ───────────────────────────────────────────── */
.pr-faq-list { list-style: none; padding: 0; margin: 0; }
.pr-faq-item { border-bottom: 1px solid rgba(255,255,255,.07); }
.pr-faq-btn {
  display: flex; align-items: center; justify-content: space-between; gap: 16px;
  width: 100%; background: none; border: none; cursor: pointer;
  padding: 22px 0; text-align: left;
  font-family: var(--pr-head); font-size: 1rem; font-weight: 600; color: #ffffff;
  transition: color .2s;
}
.pr-faq-btn:hover { color: var(--pr-aqua); }
.pr-faq-icon { width: 24px; height: 24px; border-radius: 50%; background: rgba(107,91,245,.2); flex-shrink: 0; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; color: var(--pr-iris); transition: transform .3s, background .3s; }
.pr-faq-item.pr-open .pr-faq-icon { transform: rotate(45deg); background: rgba(107,91,245,.4); }
.pr-faq-body { max-height: 0; overflow: hidden; transition: max-height .4s ease; }
.pr-faq-body-inner { padding: 0 0 22px; font-size: .93rem; color: #8896b5; line-height: 1.8; }

/* ── TRUST BADGES ──────────────────────────────────── */
.pr-trust-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 96px; }
.pr-trust-card {
  background: var(--pr-card);
  border: 1px solid rgba(255,255,255,.06);
  border-radius: var(--pr-r);
  padding: 24px;
  text-align: center;
  transition: border-color .25s;
}
.pr-trust-card:hover { border-color: var(--pr-iris); }
.pr-trust-icon { font-size: 2rem; margin-bottom: 10px; }
.pr-trust-title { font-family: var(--pr-head); font-size: .88rem; font-weight: 700; color: #ffffff; margin-bottom: 4px; }
.pr-trust-desc { font-size: .78rem; color: #6d7fa8; line-height: 1.5; }

/* ── STATS BAND ────────────────────────────────────── */
.pr-stats-band { background: var(--pr-card); border-top: 1px solid rgba(255,255,255,.06); border-bottom: 1px solid rgba(255,255,255,.06); padding: 56px 0; margin-bottom: 96px; }
.pr-stats-inner { display: grid; grid-template-columns: repeat(4, 1fr); gap: 0; }
.pr-stat-cell { text-align: center; padding: 0 24px; border-right: 1px solid rgba(255,255,255,.07); }
.pr-stat-cell:last-child { border-right: none; }
.pr-stat-val { font-family: var(--pr-head); font-size: 2.8rem; font-weight: 900; color: #ffffff; line-height: 1; letter-spacing: -.03em; background: linear-gradient(135deg, #ffffff 30%, var(--pr-aqua)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
.pr-stat-label { font-size: .78rem; color: #6d7fa8; text-transform: uppercase; letter-spacing: .1em; margin-top: 6px; }

/* ── HERO CSS ART ──────────────────────────────────── */
.pr-hero-art { position: relative; height: 420px; pointer-events: none; overflow: hidden; }
.pr-hero-grid { position: absolute; inset: 0; background-image: linear-gradient(rgba(107,91,245,.08) 1px, transparent 1px), linear-gradient(90deg, rgba(107,91,245,.08) 1px, transparent 1px); background-size: 48px 48px; }
.pr-hero-glow { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -60%); width: 600px; height: 600px; background: radial-gradient(ellipse, rgba(107,91,245,.2) 0%, rgba(0,212,200,.08) 40%, transparent 70%); border-radius: 50%; }
.pr-hero-card { position: absolute; background: var(--pr-card); border: 1px solid rgba(255,255,255,.1); border-radius: 16px; }
.pr-hero-card--a { width: 200px; height: 120px; top: 60px; left: calc(50% - 280px); transform: rotate(-6deg); padding: 16px; }
.pr-hero-card--b { width: 220px; height: 140px; top: 40px; left: calc(50% - 110px); padding: 16px; border-color: var(--pr-iris); box-shadow: 0 0 0 2px rgba(107,91,245,.3), 0 24px 48px rgba(107,91,245,.2); }
.pr-hero-card--c { width: 200px; height: 120px; top: 60px; left: calc(50% + 80px); transform: rotate(6deg); padding: 16px; }
.pr-hero-card--d { width: 260px; height: 80px; top: 220px; left: calc(50% - 130px); padding: 14px 18px; display: flex; align-items: center; gap: 14px; }
.pr-hero-card--e { width: 160px; height: 70px; top: 260px; left: calc(50% - 330px); transform: rotate(-3deg); padding: 12px 16px; }
.pr-hero-card--f { width: 160px; height: 70px; top: 260px; left: calc(50% + 170px); transform: rotate(3deg); padding: 12px 16px; }
.pr-sparkline { display: flex; align-items: flex-end; gap: 3px; height: 36px; }
.pr-sparkline-bar { width: 8px; border-radius: 2px 2px 0 0; background: var(--pr-iris); opacity: .5; }
.pr-sparkline-bar--active { opacity: 1; background: linear-gradient(to top, var(--pr-iris), var(--pr-aqua)); }
.pr-hero-orb { position: absolute; border-radius: 50%; opacity: .6; animation: pr-float 6s ease-in-out infinite; }
@keyframes pr-float { 0%,100%{ transform: translateY(0); } 50%{ transform: translateY(-14px); } }
@keyframes pr-pulse { 0%,100%{ opacity:.3; } 50%{ opacity:.7; } }

/* ── CTA SECTION ───────────────────────────────────── */
.pr-cta { background: linear-gradient(135deg, #13113a 0%, #0f1e38 100%); border: 1px solid rgba(107,91,245,.25); border-radius: 20px; padding: 72px 48px; text-align: center; margin-bottom: 48px; position: relative; overflow: hidden; }
.pr-cta::before { content: ''; position: absolute; top: -80px; right: -80px; width: 320px; height: 320px; border-radius: 50%; background: radial-gradient(circle, rgba(107,91,245,.15) 0%, transparent 70%); }
.pr-cta::after { content: ''; position: absolute; bottom: -60px; left: -60px; width: 240px; height: 240px; border-radius: 50%; background: radial-gradient(circle, rgba(0,212,200,.1) 0%, transparent 70%); }

/* ── SCROLL REVEAL ─────────────────────────────────── */
.pr-reveal { opacity: 0; transform: translateY(24px); transition: opacity .6s ease, transform .6s ease; }
.pr-reveal.pr-visible { opacity: 1; transform: none; }

/* ── RESPONSIVE ────────────────────────────────────── */
@media (max-width: 960px) {
  .pr-plans { grid-template-columns: 1fr; }
  .pr-plan-card--featured { transform: none; }
  .pr-testimonials { grid-template-columns: 1fr; }
  .pr-trust-grid { grid-template-columns: repeat(2, 1fr); }
  .pr-stats-inner { grid-template-columns: repeat(2, 1fr); }
  .pr-stat-cell { border-right: none; border-bottom: 1px solid rgba(255,255,255,.07); padding: 24px 0; }
  .pr-stat-cell:last-child { border-bottom: none; }
}
@media (max-width: 640px) {
  .pr-trust-grid { grid-template-columns: 1fr; }
  .pr-stats-inner { grid-template-columns: 1fr; }
  .pr-cta { padding: 48px 24px; }
}
</style>
<?php get_header(); ?>
<div class="pr-page">
>
<?php wp_body_open(); ?>

<!-- ═══════════════════════════════════════════════
     HERO
     ═══════════════════════════════════════════════ -->
<section class="pr-hero" style="background:var(--pr-void);padding:80px 0 0;text-align:center;overflow:hidden;border-bottom:1px solid rgba(255,255,255,.06);">
  <div class="pr-wrap">
    <p class="pr-eyebrow pr-reveal">Simple, Transparent Pricing</p>
    <h1 class="pr-h2 pr-reveal" style="font-size:clamp(2.6rem,6vw,4rem);max-width:680px;margin:0 auto 20px;">Plans that grow <span style="background:linear-gradient(135deg,var(--pr-iris),var(--pr-aqua));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;">with you</span></h1>
    <p class="pr-reveal" style="font-size:1.05rem;color:#8896b5;max-width:520px;margin:0 auto 40px;line-height:1.7;">Start free. Scale as you grow. No surprise fees, no vendor lock-in — just software that earns its place on your stack every single month.</p>
  </div>

  <!-- CSS art: floating plan cards -->
  <div class="pr-hero-art">
    <div class="pr-hero-grid"></div>
    <div class="pr-hero-glow"></div>

    <!-- floating orbs -->
    <div class="pr-hero-orb" style="width:80px;height:80px;background:radial-gradient(circle,rgba(107,91,245,.4),transparent 70%);top:30px;left:calc(50% - 400px);animation-delay:-2s;"></div>
    <div class="pr-hero-orb" style="width:50px;height:50px;background:radial-gradient(circle,rgba(0,212,200,.4),transparent 70%);top:80px;right:calc(50% - 360px);animation-delay:-4s;"></div>

    <!-- card A — Starter -->
    <div class="pr-hero-card pr-hero-card--a">
      <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.12em;color:#6d7fa8;margin-bottom:6px;">Starter</div>
      <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:1.6rem;font-weight:900;color:#ffffff;line-height:1;">Free</div>
      <div style="display:flex;align-items:flex-end;gap:3px;height:28px;margin-top:12px;">
        <?php $heights=[6,10,8,14,9,12,16,11,7,13]; foreach($heights as $h): ?><div style="width:7px;height:<?php echo $h; ?>px;background:rgba(0,212,200,.3);border-radius:1px;"></div><?php endforeach; ?>
      </div>
    </div>

    <!-- card B — Pro (featured) -->
    <div class="pr-hero-card pr-hero-card--b">
      <div style="position:absolute;top:-1px;left:50%;transform:translateX(-50%);"><span class="pr-badge" style="font-size:.58rem;padding:3px 10px;">Most Popular</span></div>
      <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.12em;color:#9b8df8;margin-bottom:6px;">Pro</div>
      <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:1.6rem;font-weight:900;color:#ffffff;line-height:1;">$49<span style="font-size:.9rem;font-weight:500;color:#6d7fa8;"> /mo</span></div>
      <div class="pr-sparkline" style="margin-top:12px;">
        <?php $sh=[8,12,10,18,14,22,16,28,20,32,24,36]; foreach($sh as $idx=>$h): ?><div class="pr-sparkline-bar <?php echo ($idx>=9)?'pr-sparkline-bar--active':''; ?>" style="height:<?php echo $h; ?>px;"></div><?php endforeach; ?>
      </div>
    </div>

    <!-- card C — Enterprise -->
    <div class="pr-hero-card pr-hero-card--c">
      <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.12em;color:#6d7fa8;margin-bottom:6px;">Enterprise</div>
      <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:1.6rem;font-weight:900;color:#ffffff;line-height:1;">$199<span style="font-size:.9rem;font-weight:500;color:#6d7fa8;"> /mo</span></div>
      <div style="display:flex;gap:4px;margin-top:12px;">
        <?php for($d=0;$d<5;$d++): ?><div style="width:16px;height:4px;background:rgba(0,212,200,.<?php echo 3+$d; ?>);border-radius:2px;"></div><?php endfor; ?>
      </div>
    </div>

    <!-- card D — social proof -->
    <div class="pr-hero-card pr-hero-card--d">
      <div style="display:flex;">
        <?php $av_colours=['#6B5BF5','#00D4C8','#F59E0B','#EC4899']; foreach($av_colours as $i=>$c): ?><div style="width:28px;height:28px;border-radius:50%;background:<?php echo $c; ?>;border:2px solid var(--pr-card);margin-left:<?php echo $i?'-8px':'0'; ?>;display:flex;align-items:center;justify-content:center;font-size:.65rem;font-weight:700;color:#fff;"></div><?php endforeach; ?>
      </div>
      <div>
        <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:.78rem;font-weight:700;color:#ffffff;">40,000+ teams</div>
        <div style="font-size:.68rem;color:#6d7fa8;">already onboard</div>
      </div>
    </div>

    <!-- card E -->
    <div class="pr-hero-card pr-hero-card--e">
      <div style="font-size:.65rem;color:#6d7fa8;margin-bottom:4px;">Monthly savings</div>
      <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:1.1rem;font-weight:800;color:var(--pr-aqua);">Save 20%</div>
    </div>

    <!-- card F -->
    <div class="pr-hero-card pr-hero-card--f">
      <div style="font-size:.65rem;color:#6d7fa8;margin-bottom:4px;">Uptime SLA</div>
      <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:1.1rem;font-weight:800;color:#ffffff;">99.99%</div>
    </div>

    <!-- bottom fade -->
    <div style="position:absolute;bottom:0;left:0;right:0;height:120px;background:linear-gradient(to top,var(--pr-void) 0%,transparent 100%);"></div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     BILLING TOGGLE + PLAN CARDS
     ═══════════════════════════════════════════════ -->
<section style="padding:80px 0 0;background:var(--pr-void);">
  <div class="pr-wrap">
    <!-- toggle -->
    <div class="pr-toggle-wrap pr-reveal">
      <span class="pr-toggle-label pr-toggle-label--active" id="pr-lbl-monthly">Monthly</span>
      <label class="pr-toggle" aria-label="Toggle annual billing">
        <input type="checkbox" id="pr-billing-toggle">
        <div class="pr-toggle-knob"></div>
      </label>
      <span class="pr-toggle-label" id="pr-lbl-annual">Annual</span>
      <span class="pr-save-badge">Save 20%</span>
    </div>

    <!-- plan cards -->
    <div class="pr-plans pr-reveal">
      <?php foreach($pr_plans as $plan): ?>
      <?php
        $gradient_start = $plan['featured'] ? 'var(--pr-iris)' : 'rgba(58,69,102,.6)';
        $gradient_end   = $plan['featured'] ? 'var(--pr-aqua)' : 'rgba(58,69,102,.3)';
      ?>
      <div class="pr-plan-card <?php echo $plan['featured']?'pr-plan-card--featured':''; ?>" style="--accent-start:<?php echo esc_attr($gradient_start); ?>;--accent-end:<?php echo esc_attr($gradient_end); ?>;">
        <?php if($plan['featured']): ?>
        <div style="text-align:center;margin-bottom:16px;"><span class="pr-badge">Most Popular</span></div>
        <?php endif; ?>
        <div class="pr-plan-name"><?php echo esc_html($plan['name']); ?></div>
        <p class="pr-plan-tagline"><?php echo esc_html($plan['tagline']); ?></p>
        <div class="pr-plan-price-row">
          <?php if($plan['price'] !== '0'): ?>
          <span class="pr-plan-currency">$</span>
          <span class="pr-plan-price" data-monthly="<?php echo esc_attr($plan['price']); ?>" data-annual="<?php echo esc_attr(floor((int)$plan['price']*.8)); ?>"><?php echo esc_html($plan['price']); ?></span>
          <span class="pr-plan-period"><?php echo esc_html($plan['period']); ?></span>
          <?php else: ?>
          <span class="pr-plan-price">Free</span>
          <span class="pr-plan-period"><?php echo esc_html($plan['period']); ?></span>
          <?php endif; ?>
        </div>
        <div class="pr-plan-divider"></div>
        <ul class="pr-perk-list">
          <?php foreach($plan['perks'] as $perk): ?>
          <li class="pr-perk-item"><?php echo esc_html($perk); ?></li>
          <?php endforeach; ?>
        </ul>
        <a href="#" class="pr-btn <?php echo $plan['featured']?'pr-btn--iris':'pr-btn--ghost'; ?>" style="text-align:center;width:100%;">
          <?php echo esc_html($plan['cta']); ?>
        </a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     STATS BAND
     ═══════════════════════════════════════════════ -->
<section class="pr-stats-band">
  <div class="pr-wrap">
    <div class="pr-stats-inner">
      <?php foreach($pr_stats as $s): ?>
      <div class="pr-stat-cell pr-reveal">
        <div class="pr-stat-val"><?php echo esc_html($s['v']); ?></div>
        <div class="pr-stat-label"><?php echo esc_html($s['l']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     FEATURE COMPARISON TABLE
     ═══════════════════════════════════════════════ -->
<section style="padding:0 0 96px;background:var(--pr-void);">
  <div class="pr-wrap">
    <div style="text-align:center;margin-bottom:48px;" class="pr-reveal">
      <p class="pr-eyebrow">Compare</p>
      <h2 class="pr-h2">Everything in one view</h2>
    </div>
    <div class="pr-table-wrap pr-reveal">
      <table class="pr-table" role="table" aria-label="Feature comparison">
        <thead>
          <tr>
            <th scope="col">Feature</th>
            <th scope="col">Starter</th>
            <th scope="col" class="pr-table-iris">Pro</th>
            <th scope="col">Enterprise</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($pr_features as $row): ?>
          <tr>
            <td><?php echo esc_html($row['feature']); ?></td>
            <td class="<?php echo in_array($row['starter'],['✓','—'])?($row['starter']==='✓'?'pr-check':'pr-dash'):''; ?>"><?php echo esc_html($row['starter']); ?></td>
            <td class="pr-table-iris <?php echo in_array($row['pro'],['✓','—'])?($row['pro']==='✓'?'pr-check':'pr-dash'):''; ?>"><?php echo esc_html($row['pro']); ?></td>
            <td class="<?php echo in_array($row['ent'],['✓','—'])?($row['ent']==='✓'?'pr-check':'pr-dash'):''; ?>"><?php echo esc_html($row['ent']); ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     TRUST BADGES
     ═══════════════════════════════════════════════ -->
<section style="padding:0 0 96px;background:var(--pr-void);">
  <div class="pr-wrap">
    <div style="text-align:center;margin-bottom:48px;" class="pr-reveal">
      <p class="pr-eyebrow">Security & Compliance</p>
      <h2 class="pr-h2">Built for the most demanding teams</h2>
    </div>
    <div class="pr-trust-grid">
      <?php foreach($pr_trust as $t): ?>
      <div class="pr-trust-card pr-reveal">
        <div class="pr-trust-icon"><?php echo $t['ico']; ?></div>
        <div class="pr-trust-title"><?php echo esc_html($t['t']); ?></div>
        <div class="pr-trust-desc"><?php echo esc_html($t['d']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     TESTIMONIALS
     ═══════════════════════════════════════════════ -->
<section style="padding:0 0 96px;background:var(--pr-void);">
  <div class="pr-wrap">
    <div style="text-align:center;margin-bottom:48px;" class="pr-reveal">
      <p class="pr-eyebrow">Customer Stories</p>
      <h2 class="pr-h2">Trusted by teams who ship</h2>
    </div>
    <div class="pr-testimonials">
      <?php foreach($pr_testimonials as $t): ?>
      <div class="pr-tcard pr-reveal">
        <p class="pr-tcard-quote">"<?php echo esc_html($t['quote']); ?>"</p>
        <div class="pr-tcard-author">
          <div class="pr-tcard-avatar" style="background:<?php echo esc_attr($t['colour']); ?>;"><?php echo esc_html($t['initials']); ?></div>
          <div>
            <div class="pr-tcard-name"><?php echo esc_html($t['name']); ?></div>
            <div class="pr-tcard-role"><?php echo esc_html($t['role']); ?></div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     FAQ
     ═══════════════════════════════════════════════ -->
<section style="padding:0 0 96px;background:var(--pr-void);">
  <div class="pr-wrap--narrow">
    <div style="text-align:center;margin-bottom:48px;" class="pr-reveal">
      <p class="pr-eyebrow">Got Questions?</p>
      <h2 class="pr-h2">Frequently Asked Questions</h2>
    </div>
    <ul class="pr-faq-list" role="list">
      <?php foreach($pr_faqs as $idx=>$f): ?>
      <li class="pr-faq-item pr-reveal" role="listitem">
        <button class="pr-faq-btn" aria-expanded="false" aria-controls="pr-faq-body-<?php echo $idx; ?>">
          <?php echo esc_html($f['q']); ?>
          <span class="pr-faq-icon" aria-hidden="true">+</span>
        </button>
        <div class="pr-faq-body" id="pr-faq-body-<?php echo $idx; ?>" role="region">
          <div class="pr-faq-body-inner"><?php echo esc_html($f['a']); ?></div>
        </div>
      </li>
      <?php endforeach; ?>
    </ul>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     CTA — ENTERPRISE CONTACT
     ═══════════════════════════════════════════════ -->
<section style="padding:0 0 48px;background:var(--pr-void);">
  <div class="pr-wrap">
    <div class="pr-cta pr-reveal">
      <p class="pr-eyebrow" style="position:relative;z-index:1;">Enterprise Sales</p>
      <h2 class="pr-h2" style="position:relative;z-index:1;max-width:600px;margin:0 auto 16px;">Need a custom plan or a live demo?</h2>
      <p style="color:#8896b5;max-width:480px;margin:0 auto 36px;line-height:1.7;position:relative;z-index:1;">Our enterprise team will walk you through the platform, answer every compliance question, and put together a proposal scoped to your exact needs — no fluff, no pressure.</p>
      <div style="display:flex;gap:16px;justify-content:center;flex-wrap:wrap;position:relative;z-index:1;">
        <a href="#" class="pr-btn pr-btn--iris">Talk to Sales</a>
        <a href="#" class="pr-btn pr-btn--ghost">Book a Demo</a>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     NEWSLETTER OPTIN
     ═══════════════════════════════════════════════ -->
<section style="padding:48px 0 96px;background:var(--pr-void);border-top:1px solid rgba(255,255,255,.06);">
  <div class="pr-wrap--narrow" style="text-align:center;">
    <p class="pr-eyebrow pr-reveal">Stay in the Loop</p>
    <h2 class="pr-h2 pr-reveal" style="font-size:clamp(1.8rem,4vw,2.4rem);">Get product updates &amp; pricing alerts</h2>
    <p class="pr-reveal" style="color:#8896b5;margin:0 auto 32px;max-width:480px;line-height:1.7;">Be first to hear about new features, plan changes, and exclusive early-bird pricing. Sent no more than twice a month.</p>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:flex;gap:12px;max-width:480px;margin:0 auto 12px;flex-wrap:wrap;" class="pr-reveal" novalidate>
      <input type="hidden" name="action" value="tf_pr_subscribe">
      <?php wp_nonce_field('tf_pr_subscribe','tf_pr_nonce'); ?>
      <label for="pr-sub-email" class="screen-reader-text"><?php esc_html_e('Your email','themeflex'); ?></label>
      <input type="email" id="pr-sub-email" name="email" placeholder="you@company.com" required aria-required="true" style="flex:1;min-width:220px;padding:14px 16px;background:var(--pr-card);border:1px solid rgba(255,255,255,.1);border-radius:8px;color:#ffffff;font-family:'Outfit',sans-serif;font-size:.9rem;outline:none;transition:border-color .2s;" onfocus="this.style.borderColor='var(--pr-iris)'" onblur="this.style.borderColor='rgba(255,255,255,.1)'">
      <button type="submit" class="pr-btn pr-btn--iris">Subscribe</button>
    </form>
    <p class="pr-reveal" style="font-size:.75rem;color:#44506a;">No spam. Unsubscribe any time. We respect your privacy.</p>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     LOGO WALL — TRUSTED COMPANIES
     ═══════════════════════════════════════════════ -->
<section style="padding:72px 0;background:var(--pr-surface);border-top:1px solid rgba(255,255,255,.05);border-bottom:1px solid rgba(255,255,255,.05);">
  <div class="pr-wrap" style="text-align:center;">
    <p style="font-family:'Outfit',sans-serif;font-size:.78rem;color:#44506a;text-transform:uppercase;letter-spacing:.18em;margin-bottom:36px;">Trusted by teams at</p>
    <div style="display:flex;flex-wrap:wrap;justify-content:center;align-items:center;gap:40px 56px;">
      <?php
      $pr_logos=['Veritas Dynamics','Nordlight AG','Stackbridge','Pulsar Studio','Meridian Cloud','Alchemy Tech','Loopline Labs','Vantara Group'];
      foreach($pr_logos as $logo):
      ?>
      <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:1rem;font-weight:800;color:#44506a;letter-spacing:-.01em;transition:color .2s;" onmouseenter="this.style.color='#8896b5'" onmouseleave="this.style.color='#44506a'"><?php echo esc_html($logo); ?></div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     ONBOARDING STEPS
     ═══════════════════════════════════════════════ -->
<section style="padding:96px 0;background:var(--pr-void);">
  <div class="pr-wrap">
    <div style="text-align:center;margin-bottom:64px;" class="pr-reveal">
      <p class="pr-eyebrow">Get Started in Minutes</p>
      <h2 class="pr-h2">Three steps to your first project</h2>
      <p style="color:#8896b5;max-width:480px;margin:16px auto 0;line-height:1.7;font-family:'Outfit',sans-serif;">No lengthy setup. No IT ticket required. Pick a plan, create your workspace, and start building today.</p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:32px;position:relative;">
      <!-- connector line -->
      <div style="position:absolute;top:36px;left:calc(16.67% + 16px);right:calc(16.67% + 16px);height:2px;background:linear-gradient(90deg,var(--pr-iris),var(--pr-aqua));opacity:.3;"></div>
      <?php
      $pr_steps=[
        ['n'=>'01','t'=>'Choose your plan','d'=>'Select Starter, Pro, or Enterprise. Every plan starts with a 14-day trial — no card needed for Starter.','ico'=>'🎯'],
        ['n'=>'02','t'=>'Create your workspace','d'=>'Name your workspace, invite your first teammate, and connect your tools in under 5 minutes.','ico'=>'🏗️'],
        ['n'=>'03','t'=>'Ship your first project','d'=>'Use our project templates or start from scratch. Your first project can go live on the same day you sign up.','ico'=>'🚀'],
      ];
      foreach($pr_steps as $i=>$s):
      ?>
      <div class="pr-reveal" style="text-align:center;padding:0 16px;">
        <div style="width:72px;height:72px;border-radius:50%;background:var(--pr-card);border:2px solid var(--pr-iris);display:flex;align-items:center;justify-content:center;margin:0 auto 20px;position:relative;z-index:1;">
          <span style="font-size:1.6rem;"><?php echo $s['ico']; ?></span>
        </div>
        <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.18em;color:var(--pr-aqua);margin-bottom:8px;"><?php echo $s['n']; ?></div>
        <h3 style="font-family:'Plus Jakarta Sans',sans-serif;font-size:1.15rem;font-weight:700;color:#ffffff;margin-bottom:10px;"><?php echo esc_html($s['t']); ?></h3>
        <p style="font-size:.87rem;color:#6d7fa8;line-height:1.7;font-family:'Outfit',sans-serif;"><?php echo esc_html($s['d']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     INTEGRATION STRIP
     ═══════════════════════════════════════════════ -->
<section style="padding:80px 0;background:var(--pr-surface);border-top:1px solid rgba(255,255,255,.05);">
  <div class="pr-wrap" style="display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:center;">
    <div class="pr-reveal">
      <p class="pr-eyebrow">Works with your stack</p>
      <h2 class="pr-h2" style="font-size:clamp(1.8rem,3.5vw,2.4rem);">Connect the tools your team already loves</h2>
      <p style="color:#8896b5;line-height:1.8;margin-bottom:32px;font-family:'Outfit',sans-serif;">Native integrations with Slack, GitHub, Jira, Notion, Figma, HubSpot, Salesforce, and 120+ more. Set up via OAuth in seconds — no API keys, no engineering tickets.</p>
      <div style="display:flex;gap:12px;flex-wrap:wrap;">
        <a href="#" class="pr-btn pr-btn--ghost" style="font-size:.82rem;">View all integrations →</a>
      </div>
    </div>
    <!-- CSS integration icons grid -->
    <div class="pr-reveal" style="display:grid;grid-template-columns:repeat(4,1fr);gap:14px;">
      <?php
      $pr_integrations=[
        ['Slack','#4A154B'],['GitHub','#24292E'],['Jira','#0052CC'],['Figma','#F24E1E'],
        ['Notion','#ffffff'],['HubSpot','#FF7A59'],['Salesforce','#00A1E0'],['Stripe','#635BFF'],
        ['Zapier','#FF4A00'],['Linear','#5E6AD2'],['Intercom','#286EFA'],['Datadog','#632CA6'],
      ];
      foreach($pr_integrations as $int):
      ?>
      <div style="aspect-ratio:1;background:var(--pr-card);border:1px solid rgba(255,255,255,.07);border-radius:10px;display:flex;align-items:center;justify-content:center;transition:border-color .2s,transform .2s;" onmouseenter="this.style.borderColor='var(--pr-iris)';this.style.transform='scale(1.06)'" onmouseleave="this.style.borderColor='rgba(255,255,255,.07)';this.style.transform='scale(1)'">
        <div style="width:28px;height:28px;border-radius:6px;background:<?php echo esc_attr($int[1]); ?>;opacity:.85;"></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     MONEY-BACK GUARANTEE
     ═══════════════════════════════════════════════ -->
<section style="padding:80px 0;background:var(--pr-void);border-top:1px solid rgba(255,255,255,.05);">
  <div class="pr-wrap--narrow" style="text-align:center;">
    <div class="pr-reveal" style="background:var(--pr-card);border:1px solid rgba(0,212,200,.2);border-radius:20px;padding:56px 48px;position:relative;overflow:hidden;">
      <div style="position:absolute;top:-40px;left:-40px;width:200px;height:200px;border-radius:50%;background:radial-gradient(circle,rgba(0,212,200,.08),transparent 70%);"></div>
      <div style="position:absolute;bottom:-40px;right:-40px;width:160px;height:160px;border-radius:50%;background:radial-gradient(circle,rgba(107,91,245,.08),transparent 70%);"></div>
      <div style="width:72px;height:72px;border-radius:50%;background:linear-gradient(135deg,var(--pr-iris),var(--pr-aqua));display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-size:2rem;position:relative;z-index:1;">🛡️</div>
      <h2 style="font-family:'Plus Jakarta Sans',sans-serif;font-size:1.8rem;font-weight:800;color:#ffffff;margin-bottom:12px;position:relative;z-index:1;">30-Day Money-Back Guarantee</h2>
      <p style="color:#8896b5;max-width:480px;margin:0 auto 28px;line-height:1.8;font-family:'Outfit',sans-serif;position:relative;z-index:1;">Not happy in the first 30 days? We'll refund every penny — no questions asked, no hoops to jump through. We're confident you'll love it, but if not, the refund is yours.</p>
      <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap;position:relative;z-index:1;">
        <?php $pr_guarants=['No questions asked','Instant refund','Cancel anytime','No contracts']; ?>
        <?php foreach($pr_guarants as $g): ?>
        <span style="background:rgba(0,212,200,.1);border:1px solid rgba(0,212,200,.2);color:var(--pr-aqua);font-family:'Outfit',sans-serif;font-size:.75rem;font-weight:600;padding:5px 14px;border-radius:20px;"><?php echo esc_html($g); ?></span>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     COMPARISON VS COMPETITORS
     ═══════════════════════════════════════════════ -->
<section style="padding:80px 0 96px;background:var(--pr-void);">
  <div class="pr-wrap">
    <div style="text-align:center;margin-bottom:48px;" class="pr-reveal">
      <p class="pr-eyebrow">How We Compare</p>
      <h2 class="pr-h2">Better value than the alternatives</h2>
      <p style="color:#8896b5;max-width:480px;margin:16px auto 0;line-height:1.7;font-family:'Outfit',sans-serif;">Same features, half the price. See how our Pro plan stacks up against the market leaders.</p>
    </div>
    <div class="pr-reveal" style="overflow-x:auto;">
      <table class="pr-table" role="table" aria-label="Competitor comparison">
        <thead>
          <tr>
            <th scope="col">Feature</th>
            <th scope="col" class="pr-table-iris">ThemeFlex Pro ($49)</th>
            <th scope="col">Competitor A ($79)</th>
            <th scope="col">Competitor B ($89)</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $pr_comp=[
            ['Unlimited projects','✓','✓','✓'],
            ['Team members (pro tier)','15','10','Unlimited'],
            ['Storage','100 GB','50 GB','75 GB'],
            ['Custom domain','✓','✓','—'],
            ['White-label exports','✓','—','—'],
            ['Priority support (SLA)','4 h','8 h','6 h'],
            ['API + webhooks','✓','✓','✓'],
            ['Advanced analytics','✓','Limited','✓'],
            ['14-day free trial','✓','✓','—'],
            ['Annual discount','20%','15%','10%'],
          ];
          foreach($pr_comp as $row):
          ?>
          <tr>
            <td><?php echo esc_html($row[0]); ?></td>
            <td class="pr-table-iris <?php echo $row[1]==='✓'?'pr-check':($row[1]==='—'?'pr-dash':''); ?>"><?php echo esc_html($row[1]); ?></td>
            <td class="<?php echo $row[2]==='✓'?'pr-check':($row[2]==='—'?'pr-dash':''); ?>"><?php echo esc_html($row[2]); ?></td>
            <td class="<?php echo $row[3]==='✓'?'pr-check':($row[3]==='—'?'pr-dash':''); ?>"><?php echo esc_html($row[3]); ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <p style="text-align:center;color:#44506a;font-size:.75rem;margin-top:16px;font-family:'Outfit',sans-serif;">Competitor pricing accurate as of Q2 2026. Data sourced from publicly listed pricing pages.</p>
  </div>
</section>
<script>
(function(){
  /* ── Scroll reveal ── */
  const reveals = document.querySelectorAll('.pr-reveal');
  if('IntersectionObserver' in window){
    const io = new IntersectionObserver(entries=>{
      entries.forEach((e,i)=>{
        if(e.isIntersecting){
          setTimeout(()=>e.target.classList.add('pr-visible'), i*80);
          io.unobserve(e.target);
        }
      });
    },{threshold:.12});
    reveals.forEach(el=>io.observe(el));
  } else {
    reveals.forEach(el=>el.classList.add('pr-visible'));
  }

  /* ── Billing toggle ── */
  const toggle = document.getElementById('pr-billing-toggle');
  const lblM   = document.getElementById('pr-lbl-monthly');
  const lblA   = document.getElementById('pr-lbl-annual');
  const prices = document.querySelectorAll('.pr-plan-price[data-monthly]');
  if(toggle){
    toggle.addEventListener('change',function(){
      const annual = this.checked;
      lblM.classList.toggle('pr-toggle-label--active',!annual);
      lblA.classList.toggle('pr-toggle-label--active', annual);
      prices.forEach(el=>{
        el.textContent = annual ? el.dataset.annual : el.dataset.monthly;
      });
    });
  }

  /* ── FAQ accordion ── */
  document.querySelectorAll('.pr-faq-btn').forEach(btn=>{
    btn.addEventListener('click',function(){
      const item   = this.closest('.pr-faq-item');
      const body   = item.querySelector('.pr-faq-body');
      const isOpen = item.classList.contains('pr-open');
      /* close all */
      document.querySelectorAll('.pr-faq-item.pr-open').forEach(open=>{
        open.classList.remove('pr-open');
        open.querySelector('.pr-faq-body').style.maxHeight = '0';
        open.querySelector('.pr-faq-btn').setAttribute('aria-expanded','false');
      });
      if(!isOpen){
        item.classList.add('pr-open');
        body.style.maxHeight = body.scrollHeight + 'px';
        this.setAttribute('aria-expanded','true');
      }
    });
  });
})();
</script>
</div><!-- .pr-page -->
<?php get_footer(); ?>
