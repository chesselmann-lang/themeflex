<?php
/**
 * Template Name: Private Tutor — Education & Academic Coaching
 *
 * Premium private tuition page for ThemeFlex.
 * Concept : Scholar's study at dusk — warm desk lamp, book-lined shelves,
 *           globe, chalkboard with equations, stacked notebooks, floating
 *           formula symbols.
 * Palette : Oxford navy / warm ivory / amber gold / sage green accent.
 * Fonts   : Spectral (headings, editorial serif) + Nunito Sans (body).
 * Namespace: --ed-*
 *
 * @package ThemeFlex
 */

if ( ! defined( 'ABSPATH' ) ) exit;

srand( crc32( get_the_permalink() ) );

/* ── floating formula symbols ───────────────── */
$ed_symbols = [];
$raw = ['∑','∫','π','√','∞','∂','Δ','∇','α','β','∈','∀','∃','⊕','≈','×','÷','±'];
for($i=0;$i<24;$i++){
    $ed_symbols[]=[
        'sym'   => $raw[rand(0,count($raw)-1)],
        'left'  => rand(4,96),
        'top'   => rand(6,88),
        'size'  => rand(14,32),
        'delay' => rand(0,7000),
        'dur'   => rand(5000,12000),
        'op'    => rand(10,28),
    ];
}

/* ── bookshelf books ─────────────────────────── */
$ed_books = [];
$book_hues = [210,180,32,0,120,280,340,55,200,16,300,8];
for($i=0;$i<36;$i++){
    $ed_books[]=[
        'hue' => $book_hues[$i % count($book_hues)],
        'w'   => rand(10,22),
        'h'   => rand(80,130),
        'sat' => rand(40,80),
        'lit' => rand(25,55),
    ];
}

/* ── stats ───────────────────────────────────── */
$ed_stats=[
    ['val'=>98,  'suffix'=>'%','label'=>'Grade Improvement Rate'],
    ['val'=>1240,'suffix'=>'+','label'=>'Students Tutored'],
    ['val'=>4.9, 'suffix'=>'★','label'=>'Average Rating'],
    ['val'=>16,  'suffix'=>'', 'label'=>'Years Teaching'],
];

/* ── subjects ────────────────────────────────── */
$ed_subjects=[
    ['icon'=>'📐','name'=>'Mathematics',        'levels'=>'GCSE · A-Level · Oxbridge · University','desc'=>'From GCSE foundations to university-level analysis and Oxbridge entrance — structured, confidence-building maths coaching.'],
    ['icon'=>'⚗','name'=>'Sciences',            'levels'=>'GCSE · A-Level · IB · University',      'desc'=>'Physics, Chemistry and Biology taught with clarity and depth — exam technique, practicals and conceptual mastery.'],
    ['icon'=>'📖','name'=>'English & Literature','levels'=>'GCSE · A-Level · 11+ · University',     'desc'=>'Essay writing, close reading, creative writing and language analysis — tailored to every examining board.'],
    ['icon'=>'🌍','name'=>'Modern Languages',   'levels'=>'GCSE · A-Level · Conversational',       'desc'=>'French, Spanish, German and Mandarin — grammar, oral practice and cultural context for confident communication.'],
    ['icon'=>'🏛','name'=>'Humanities',          'levels'=>'GCSE · A-Level · University',           'desc'=>'History, Geography, Economics and Philosophy taught with the analytical rigour that top universities expect.'],
    ['icon'=>'💻','name'=>'Computer Science',   'levels'=>'GCSE · A-Level · University',           'desc'=>'Python, algorithms, data structures, SQL and systems thinking — from first concepts to full A-Level and beyond.'],
];

/* ── exam preparation ────────────────────────── */
$ed_exams=[
    ['name'=>'11+ & Common Entrance', 'icon'=>'🎓','desc'=>'Selective school and grammar school preparation — verbal reasoning, non-verbal reasoning, maths and English.'],
    ['name'=>'GCSE & IGCSE',          'icon'=>'📝','desc'=>'All major exam boards: AQA, Edexcel, OCR and Cambridge IGCSE — targeted revision and mock exams.'],
    ['name'=>'A-Level & Pre-U',       'icon'=>'🏆','desc'=>'Deep-subject coaching for A-Level and Cambridge Pre-U — preparing students for top university offers.'],
    ['name'=>'Oxbridge Preparation',  'icon'=>'🦉','desc'=>'Personal statement, written assessments (TSA, BMAT, MAT), interview preparation and subject-specific coaching.'],
];

/* ── methodology ──────────────────────────────── */
$ed_method=[
    ['n'=>'01','t'=>'Diagnostic Assessment','d'=>'We begin with a comprehensive assessment to pinpoint gaps, strengths and the most efficient route to improvement.'],
    ['n'=>'02','t'=>'Bespoke Learning Plan', 'd'=>'A personalised programme aligned to your syllabus, exam dates and learning style — built around you, not a template.'],
    ['n'=>'03','t'=>'Active Sessions',       'd'=>'Socratic dialogue, worked examples and targeted practice — sessions that challenge thinking, not just fill time.'],
    ['n'=>'04','t'=>'Progress & Refinement', 'd'=>'Regular mock papers, marking and feedback loops ensure steady, measurable improvement every four weeks.'],
];

/* ── tutors ──────────────────────────────────── */
$ed_tutors=[
    ['name'=>'Dr Oliver Marsh',   'role'=>'Founder & Lead Tutor',   'qual'=>'DPhil Mathematics · Oxford · Former Lecturer', 'colour'=>'#1E3A6E'],
    ['name'=>'Emily Ashton',      'role'=>'Sciences Lead',          'qual'=>'BSc Physics (1st) · Imperial · PGCE',          'colour'=>'#2E7050'],
    ['name'=>'Clara Beaumont',    'role'=>'English & Languages',    'qual'=>'MA English Lit · Cambridge · CELTA',           'colour'=>'#8C3028'],
    ['name'=>'Rohan Mehta',       'role'=>'Maths & Computer Science','qual'=>'MEng Computer Science · UCL · PGCE',          'colour'=>'#5C3A8C'],
];

/* ── packages ─────────────────────────────────── */
$ed_packages=[
    [
        'name'     => 'Foundation',
        'sessions' => '4 sessions / month',
        'price'    => '£240',
        'period'   => '/mo',
        'features' => ['One subject · 60-min sessions','Diagnostic report','Progress tracking','PDF resources'],
        'highlight'=> false,
    ],
    [
        'name'     => 'Scholar',
        'sessions' => '8 sessions / month',
        'price'    => '£440',
        'period'   => '/mo',
        'features' => ['Up to 2 subjects · 60-min sessions','Monthly progress report','Mock exam marking','Email support between sessions','Resource library'],
        'highlight'=> true,
    ],
    [
        'name'     => 'Intensive',
        'sessions' => '12+ sessions / month',
        'price'    => '£620',
        'period'   => '/mo',
        'features' => ['Multiple subjects','Weekly progress reviews','Full mock exam suite','Priority scheduling','University / school application support','Parent update calls'],
        'highlight'=> false,
    ],
];

/* ── testimonials ────────────────────────────── */
$ed_testimonials=[
    ['name'=>'Sarah & James Whitfield','role'=>'Parents of A-Level student',
     'text'=>'Oliver took our daughter from a predicted C to an A* in Mathematics. His ability to identify exactly where she was losing marks was extraordinary — and his calm patience gave her real confidence.'],
    ['name'=>'Tom Alderton',           'role'=>'Oxford Medicine offer',
     'text'=>'Dr Marsh\'s BMAT preparation was worth every session. He didn\'t just teach the material — he taught me how to think under exam conditions. I\'ll be forever grateful.'],
    ['name'=>'Mrs Patricia Osei',      'role'=>'Parent of 11+ pupil',
     'text'=>'Clara worked with our son for four months ahead of his 11+ exams. He passed his first-choice school. Her ability to make learning feel exciting rather than stressful was remarkable.'],
];

/* ── FAQs ─────────────────────────────────────── */
$ed_faqs=[
    ['q'=>'Do you offer online tutoring as well as in-person?',
     'a'=>'Yes — all subjects are available both in-person across London and online via a digital whiteboard platform. Many of our students combine both formats.'],
    ['q'=>'How quickly will my child see results?',
     'a'=>'Most students show measurable improvement within four to six weeks. For students with a strong work ethic, one term is typically sufficient to move a full grade band.'],
    ['q'=>'Which exam boards do you cover?',
     'a'=>'We cover all major UK exam boards: AQA, Edexcel, OCR, WJEC, Cambridge IGCSE and Pre-U, as well as IB Standard Level and Higher Level for most subjects.'],
    ['q'=>'Can I request a specific tutor?',
     'a'=>'Yes. We take great care in matching tutor to student — you are welcome to specify requirements or request a trial session with a preferred tutor before committing.'],
    ['q'=>'What is your cancellation policy?',
     'a'=>'We ask for 24 hours\' notice for individual session cancellations. Regular monthly packages are rolling with 30 days\' written notice to cancel.'],
];

get_header();
?>

<style>
/* ══════════════════════════════════════════
   PRIVATE TUTOR — CSS DESIGN SYSTEM
   Namespace: --ed-*
══════════════════════════════════════════ */
@import url('https://fonts.googleapis.com/css2?family=Spectral:ital,wght@0,300;0,400;0,600;1,300;1,400&family=Nunito+Sans:wght@300;400;600;700&display=swap');

:root{
    --ed-navy    : #1A2844;
    --ed-navy-d  : #0E1828;
    --ed-navy-l  : #2A3C60;
    --ed-ivory   : #FBF7F0;
    --ed-sand    : #EEE8DC;
    --ed-amber   : #C08030;
    --ed-amber-l : #D8943C;
    --ed-sage    : #4A7060;
    --ed-mid     : #7A7060;
    --ed-dark    : #1A1410;
    --ed-white   : #FFFFFF;
    --ed-font-h  : 'Spectral', serif;
    --ed-font-b  : 'Nunito Sans', sans-serif;
    --ed-shadow  : 0 20px 60px rgba(0,0,0,.15);
    --ed-border  : #DDD4C0;
}

.ed-wrap *{ box-sizing:border-box; margin:0; padding:0; }
.ed-wrap{ font-family:var(--ed-font-b); color:var(--ed-dark); background:var(--ed-ivory); line-height:1.7; }
.ed-container{ max-width:1200px; margin:0 auto; padding:0 40px; }

/* ── Typography ─────────────────────────── */
.ed-h1{ font-family:var(--ed-font-h); font-size:clamp(2.8rem,6.5vw,5.5rem); font-weight:300; font-style:italic; line-height:1.1; color:var(--ed-white); }
.ed-h2{ font-family:var(--ed-font-h); font-size:clamp(1.8rem,4vw,2.8rem); font-weight:400; color:var(--ed-navy-d); }
.ed-h3{ font-family:var(--ed-font-h); font-size:1.3rem; color:var(--ed-navy-d); }
.ed-lead{ font-size:.97rem; color:var(--ed-mid); font-weight:300; max-width:580px; line-height:1.85; }
.ed-overline{ font-family:var(--ed-font-b); font-size:.68rem; font-weight:700; letter-spacing:.24em; color:var(--ed-amber); text-transform:uppercase; display:block; margin-bottom:1rem; }
.ed-accent{ color:var(--ed-amber); font-style:italic; }
.ed-divider{ display:inline-block; width:40px; height:1.5px; background:var(--ed-amber); margin:20px 0; }

/* ── Buttons ─────────────────────────────── */
.ed-btn{
    display:inline-flex; align-items:center; gap:.5rem;
    font-family:var(--ed-font-b); font-size:.78rem; font-weight:700; letter-spacing:.16em;
    padding:.85rem 2.2rem; background:var(--ed-navy); color:var(--ed-white);
    border:none; cursor:pointer; text-decoration:none; text-transform:uppercase;
    transition:background .25s, transform .2s; border-radius:3px;
}
.ed-btn:hover{ background:var(--ed-navy-l); transform:translateY(-2px); }
.ed-btn-amber{ background:var(--ed-amber); }
.ed-btn-amber:hover{ background:var(--ed-amber-l); }
.ed-btn-outline{
    background:transparent; border:1.5px solid rgba(255,255,255,.5); color:var(--ed-white);
    border-radius:3px;
}
.ed-btn-outline:hover{ background:rgba(255,255,255,.1); }
.ed-btn-dark-outline{
    background:transparent; border:1.5px solid var(--ed-navy); color:var(--ed-navy);
    border-radius:3px;
}
.ed-btn-dark-outline:hover{ background:var(--ed-navy); color:var(--ed-white); }

/* ── Sections ────────────────────────────── */
.ed-section{ padding:100px 0; }
.ed-section-alt{ background:var(--ed-sand); }
.ed-section-dark{ background:var(--ed-navy-d); }
.ed-section-header{ text-align:center; margin-bottom:64px; }

/* ══════════════════════════════════════════
   HERO — Scholar's study at dusk
══════════════════════════════════════════ */
.ed-hero{
    position:relative; min-height:100vh;
    background:linear-gradient(160deg,#0E1828 0%,#141E34 50%,#1A2440 100%);
    overflow:hidden; display:flex; align-items:center;
}

/* room ceiling */
.ed-room-ceiling{
    position:absolute; top:0; left:0; right:0; height:18%;
    background:linear-gradient(180deg,#0A1018,#121C2C);
}
/* cornice */
.ed-room-ceiling::after{
    content:''; position:absolute; bottom:0; left:0; right:0; height:8px;
    background:linear-gradient(90deg,#1C2C40,#243244,#1C2C40);
}

/* room floor */
.ed-room-floor{
    position:absolute; bottom:0; left:0; right:0; height:20%;
    background:
        repeating-linear-gradient(90deg,rgba(255,255,255,.03) 0,rgba(255,255,255,.03) 1px,transparent 1px,transparent 48px),
        linear-gradient(180deg,#1A1410,#0E0C0A);
    border-top:3px solid #2A2018;
}

/* back wall */
.ed-wall{
    position:absolute; top:18%; bottom:20%; left:0; right:0;
    background:linear-gradient(180deg,#1A2840,#162234);
    /* subtle wallpaper lines */
    background-image:
        repeating-linear-gradient(0deg,transparent 0,transparent 39px,rgba(255,255,255,.012) 39px,rgba(255,255,255,.012) 40px),
        linear-gradient(180deg,#1A2840,#162234);
}

/* bookshelf unit — left side */
.ed-shelf-unit{
    position:absolute; top:16%; bottom:20%; left:2%; width:28%;
    background:#2A1C10;
    border:3px solid #3A2818;
    padding:8px;
    display:flex; flex-direction:column; gap:4px;
    overflow:hidden;
}
/* shelf boards */
.ed-shelf-board{
    flex:1; display:flex; gap:3px; align-items:flex-end;
    border-top:4px solid #4A3020; padding:2px 2px 0;
}
.ed-book{
    height:var(--bh); width:var(--bw); flex-shrink:0;
    background:linear-gradient(90deg,hsl(var(--bhu),var(--bsa)%,calc(var(--bli)% - 10%)),hsl(var(--bhu),var(--bsa)%,var(--bli)%),hsl(var(--bhu),var(--bsa)%,calc(var(--bli)% - 5%)));
    border-radius:1px;
}

/* chalkboard */
.ed-chalkboard{
    position:absolute; top:22%; right:4%; width:38%; height:50%;
    background:#2A3A28;
    border:8px solid #4A3010;
    border-radius:4px;
    position:absolute;
    overflow:hidden;
}
/* chalk texture */
.ed-chalkboard::before{
    content:''; position:absolute; inset:0;
    background:
        repeating-linear-gradient(0deg,transparent 0,transparent 3px,rgba(255,255,255,.01) 3px,rgba(255,255,255,.01) 4px);
}
/* chalk equations on board */
.ed-chalk-line{
    position:absolute; left:8%; right:8%;
    font-family:var(--ed-font-b); color:rgba(255,255,255,.55);
    font-size:var(--cfs); white-space:nowrap; overflow:hidden;
}
/* chalk erased marks */
.ed-chalkboard::after{
    content:''; position:absolute; top:25%; left:20%; right:40%; bottom:50%;
    background:rgba(200,210,200,.06); border-radius:50%;
}
/* chalk tray */
.ed-chalk-tray{
    position:absolute; bottom:-18px; left:-8px; right:-8px; height:14px;
    background:#3A2010; border:2px solid #4A3010;
    display:flex; align-items:center; gap:4px; padding:0 8px;
}
.ed-chalk-stick{
    height:6px; background:rgba(240,240,240,.65); border-radius:3px;
}

/* desk with lamp */
.ed-desk{
    position:absolute; bottom:20%; left:30%; right:42%;
    height:16px;
    background:linear-gradient(180deg,#8C6030,#6A4820);
    border-radius:2px 2px 0 0;
}
.ed-desk::before{
    content:''; position:absolute; top:-4px; left:-8px; right:-8px; height:8px;
    background:linear-gradient(180deg,#A07040,#7A5028);
    border-radius:2px;
}
/* desk leg */
.ed-desk::after{
    content:''; position:absolute; top:16px; left:50%; transform:translateX(-50%);
    width:8px; height:40px;
    background:linear-gradient(180deg,#6A4820,#4A2E12);
}

/* lamp on desk */
.ed-lamp{
    position:absolute; bottom:calc(20% + 16px); left:calc(30% + 16px);
}
.ed-lamp-base{
    width:30px; height:6px;
    background:linear-gradient(90deg,#8C6030,#C0943A,#8C6030);
    border-radius:2px;
}
.ed-lamp-pole{
    width:3px; height:48px; background:#A07040;
    margin:0 auto; position:relative;
}
/* lamp pole bend */
.ed-lamp-pole::before{
    content:''; position:absolute; top:0; right:0;
    width:36px; height:3px; background:#A07040;
    transform-origin:left center; transform:rotate(-20deg);
}
.ed-lamp-shade{
    position:absolute; top:-14px; right:-30px;
    width:0; height:0;
    border-left:22px solid transparent;
    border-right:22px solid transparent;
    border-top:20px solid #C09030;
}
/* lamp light cone */
.ed-lamp-beam{
    position:absolute; top:16px; right:-18px;
    width:0; height:0;
    border-left:50px solid transparent;
    border-right:50px solid transparent;
    border-top:120px solid rgba(240,200,80,.07);
    pointer-events:none;
}

/* globe */
.ed-globe{
    position:absolute; bottom:calc(20% + 16px); right:calc(42% + 20px);
}
.ed-globe-sphere{
    width:42px; height:42px; border-radius:50%;
    background:radial-gradient(ellipse at 30% 25%,#3080C0,#1040A0 50%,#082060);
    position:relative; overflow:hidden;
    border:1px solid rgba(255,255,255,.15);
}
/* globe latitude lines */
.ed-globe-sphere::before{
    content:''; position:absolute; inset:0;
    background:
        repeating-linear-gradient(0deg,transparent 0,transparent 12px,rgba(255,255,255,.15) 12px,rgba(255,255,255,.15) 13px),
        repeating-linear-gradient(90deg,transparent 0,transparent 12px,rgba(255,255,255,.08) 12px,rgba(255,255,255,.08) 13px);
}
/* continent blob */
.ed-globe-sphere::after{
    content:''; position:absolute; top:20%; left:30%;
    width:24px; height:16px;
    background:rgba(60,140,60,.7);
    border-radius:30% 60% 40% 50%;
}
.ed-globe-axis{
    width:3px; height:56px; margin:0 auto;
    background:linear-gradient(180deg,#8C6030,#4A2E12);
    position:relative;
}
.ed-globe-base{
    width:54px; height:8px; margin:0 auto;
    background:linear-gradient(90deg,#6A4020,#A06030,#6A4020);
    border-radius:4px 4px 0 0;
}

/* stacked notebooks on desk */
.ed-notebooks{
    position:absolute; bottom:calc(20% + 16px); left:calc(30% + 80px);
    display:flex; gap:2px; align-items:flex-end;
}
.ed-nb{
    height:var(--nbh); width:18px;
    background:hsl(var(--nbc),60%,45%);
    border-radius:1px;
    box-shadow:2px 0 4px rgba(0,0,0,.4);
}

/* floating formula symbols */
.ed-symbol{
    position:absolute; color:rgba(255,255,255,var(--sop));
    font-size:var(--sfs); font-family:var(--ed-font-h); font-style:italic;
    pointer-events:none;
    animation:ed-symbol-drift var(--sd) ease-in-out var(--sde) infinite alternate;
}

/* scene card */
.ed-scene-card{
    position:relative; aspect-ratio:3/4; overflow:hidden;
    background:var(--ed-navy-d); border:1px solid rgba(192,128,48,.25);
    box-shadow:var(--ed-shadow);
    border-radius:3px;
}
.ed-sc-wall{ position:absolute; inset:0; background:linear-gradient(180deg,#141E34,#1A2840); }
.ed-sc-shelf{
    position:absolute; top:4%; left:0; right:0; bottom:28%;
    border-right:none;
    display:flex; flex-direction:column; gap:3px; padding:4px;
}
.ed-sc-shelf-row{ flex:1; display:flex; gap:2px; align-items:flex-end; border-top:3px solid #4A3020; padding-top:2px; }
.ed-sc-book{ height:var(--sbh); width:var(--sbw); background:hsl(var(--sbh2),60%,35%); border-radius:1px; }
.ed-sc-floor{
    position:absolute; bottom:0; left:0; right:0; height:28%;
    background:#1A1410; border-top:2px solid #2A2018;
}
.ed-sc-desk{
    position:absolute; bottom:28%; left:20%; right:10%; height:8px;
    background:#8C6030; border-radius:1px 1px 0 0;
}
.ed-sc-globe{
    position:absolute; bottom:calc(28% + 8px); right:12%;
    width:22px; height:22px; border-radius:50%;
    background:radial-gradient(ellipse at 30% 25%,#3080C0,#1040A0 50%,#082060);
}
.ed-sc-lamp-beam{
    position:absolute; bottom:calc(28% + 8px); left:20%;
    width:0; height:0;
    border-left:28px solid transparent; border-right:28px solid transparent;
    border-top:70px solid rgba(240,200,80,.08);
}
.ed-float-badge{
    position:absolute; bottom:14px; left:14px; right:14px;
    background:rgba(14,24,40,.92); border:1px solid rgba(192,128,48,.35);
    color:var(--ed-white); font-family:var(--ed-font-h); font-size:.78rem;
    letter-spacing:.06em; padding:10px 14px; text-align:center;
    border-radius:3px; font-style:italic;
    animation:ed-float 3s ease-in-out infinite;
}

/* ── Hero layout ─────────────────────────── */
.ed-hero-inner{
    position:relative; z-index:10;
    display:grid; grid-template-columns:1fr 1fr; gap:80px; align-items:center;
    max-width:1200px; margin:0 auto; padding:120px 40px 80px; width:100%;
}
.ed-hero-meta{
    display:flex; gap:32px; margin-top:36px; flex-wrap:wrap;
}
.ed-hero-meta-val{
    font-family:var(--ed-font-h); font-size:2rem; font-weight:300; color:var(--ed-white);
}
.ed-hero-meta-label{ font-size:.7rem; letter-spacing:.16em; text-transform:uppercase; color:rgba(255,255,255,.45); }
.ed-hero-actions{ display:flex; gap:16px; flex-wrap:wrap; margin-top:32px; }

/* ══════════════════════════════════════════
   STATS BAR
══════════════════════════════════════════ */
.ed-stats-bar{ background:var(--ed-amber); padding:48px 0; }
.ed-stats-grid{ display:grid; grid-template-columns:repeat(4,1fr); }
.ed-stat-cell{ text-align:center; padding:0 24px; border-right:1px solid rgba(255,255,255,.25); }
.ed-stat-cell:last-child{ border-right:none; }
.ed-stat-val{ font-family:var(--ed-font-h); font-size:2.8rem; color:var(--ed-white); display:block; font-weight:600; }
.ed-stat-label{ font-size:.68rem; letter-spacing:.2em; text-transform:uppercase; color:rgba(255,255,255,.7); margin-top:4px; }

/* ══════════════════════════════════════════
   SUBJECTS
══════════════════════════════════════════ */
.ed-subj-grid{ display:grid; grid-template-columns:repeat(3,1fr); gap:1px; background:var(--ed-border); }
.ed-subj-card{
    background:var(--ed-ivory); padding:40px 32px;
    border-bottom:3px solid transparent; transition:border-color .3s, background .3s;
}
.ed-subj-card:hover{ background:var(--ed-white); border-bottom-color:var(--ed-amber); }
.ed-subj-icon{ font-size:1.8rem; display:block; margin-bottom:16px; }
.ed-subj-name{ font-family:var(--ed-font-h); font-size:1.2rem; color:var(--ed-navy-d); margin-bottom:4px; }
.ed-subj-levels{ font-size:.7rem; letter-spacing:.14em; text-transform:uppercase; color:var(--ed-amber); font-weight:700; margin-bottom:12px; }
.ed-subj-desc{ font-size:.88rem; color:var(--ed-mid); line-height:1.75; }

/* ══════════════════════════════════════════
   EXAM PREPARATION
══════════════════════════════════════════ */
.ed-exam-grid{ display:grid; grid-template-columns:repeat(2,1fr); gap:24px; }
.ed-exam-card{
    background:var(--ed-white); border:1px solid var(--ed-border);
    padding:32px; display:flex; gap:20px; align-items:flex-start;
    border-left:4px solid var(--ed-navy);
    transition:border-left-color .25s;
}
.ed-exam-card:hover{ border-left-color:var(--ed-amber); }
.ed-exam-icon{ font-size:2rem; flex-shrink:0; }
.ed-exam-name{ font-family:var(--ed-font-h); font-size:1.1rem; color:var(--ed-navy-d); margin-bottom:8px; }
.ed-exam-desc{ font-size:.88rem; color:var(--ed-mid); line-height:1.7; }

/* ══════════════════════════════════════════
   METHODOLOGY PROCESS
══════════════════════════════════════════ */
.ed-method-grid{ display:grid; grid-template-columns:repeat(4,1fr); gap:0; border-top:1px solid var(--ed-border); }
.ed-method-step{
    padding:48px 28px; border-right:1px solid var(--ed-border); position:relative;
}
.ed-method-step:last-child{ border-right:none; }
.ed-method-num{
    font-family:var(--ed-font-h); font-size:4.5rem; font-weight:300;
    color:var(--ed-sand); line-height:1; margin-bottom:16px;
}
.ed-method-title{ font-family:var(--ed-font-h); font-size:1.1rem; color:var(--ed-navy-d); margin-bottom:10px; }
.ed-method-desc{ font-size:.85rem; color:var(--ed-mid); line-height:1.75; }
.ed-method-step::before{
    content:''; position:absolute; top:0; left:28px; width:2px; height:3px;
    background:var(--ed-amber); transition:height .4s;
}
.ed-method-step:hover::before{ height:40px; }

/* ══════════════════════════════════════════
   PACKAGES
══════════════════════════════════════════ */
.ed-pkg-grid{ display:grid; grid-template-columns:repeat(3,1fr); gap:24px; }
.ed-pkg-card{
    background:var(--ed-white); border:1.5px solid var(--ed-border); padding:40px 32px;
    position:relative; border-radius:3px; transition:box-shadow .25s;
}
.ed-pkg-card:hover{ box-shadow:0 12px 40px rgba(0,0,0,.1); }
.ed-pkg-card.highlight{ background:var(--ed-navy-d); border-color:var(--ed-navy-d); }
.ed-pkg-badge{
    position:absolute; top:-13px; left:50%; transform:translateX(-50%);
    background:var(--ed-amber); color:var(--ed-white);
    font-family:var(--ed-font-b); font-size:.68rem; font-weight:700; letter-spacing:.14em;
    padding:4px 14px; border-radius:100px; white-space:nowrap; text-transform:uppercase;
}
.ed-pkg-name{ font-family:var(--ed-font-h); font-size:1.8rem; margin-bottom:4px; }
.ed-pkg-name.l{ color:var(--ed-navy-d); }
.ed-pkg-name.d{ color:var(--ed-white); }
.ed-pkg-sessions{ font-size:.75rem; letter-spacing:.1em; text-transform:uppercase; color:var(--ed-mid); margin-bottom:20px; }
.ed-pkg-sessions.d{ color:rgba(255,255,255,.5); }
.ed-pkg-price{ font-family:var(--ed-font-h); font-size:3rem; margin-bottom:6px; }
.ed-pkg-price.l{ color:var(--ed-navy-d); }
.ed-pkg-price.d{ color:var(--ed-white); }
.ed-pkg-period.l{ font-size:.85rem; color:var(--ed-mid); }
.ed-pkg-period.d{ font-size:.85rem; color:rgba(255,255,255,.5); }
.ed-pkg-features{ list-style:none; margin:24px 0 32px; display:flex; flex-direction:column; gap:8px; }
.ed-pkg-features li{ font-size:.88rem; padding-left:20px; position:relative; }
.ed-pkg-features li.l{ color:var(--ed-dark); }
.ed-pkg-features li.d{ color:rgba(255,255,255,.8); }
.ed-pkg-features li::before{ content:'✓'; position:absolute; left:0; font-weight:700; color:var(--ed-amber); }

/* ══════════════════════════════════════════
   TEAM / TUTORS
══════════════════════════════════════════ */
.ed-team-grid{ display:grid; grid-template-columns:repeat(4,1fr); gap:24px; }
.ed-team-card{
    background:var(--ed-white); border:1px solid var(--ed-border); overflow:hidden;
    border-radius:3px; transition:box-shadow .25s;
}
.ed-team-card:hover{ box-shadow:0 12px 40px rgba(0,0,0,.1); }
.ed-team-fig{
    height:200px; background:var(--ed-sand);
    display:flex; align-items:flex-end; justify-content:center;
    overflow:hidden; position:relative;
}
.ed-team-top{ position:absolute; top:0; left:0; right:0; height:3px; background:var(--accent); }
/* CSS academic figure */
.ed-figure-a{ position:relative; width:80px; height:180px; }
.ed-fa-head{
    position:absolute; top:10px; left:50%; transform:translateX(-50%);
    width:30px; height:30px; border-radius:50%;
    background:linear-gradient(180deg,#D4A878,#C09060);
}
/* glasses */
.ed-fa-head::after{
    content:''; position:absolute; top:14px; left:4px; right:4px; height:6px;
    border:1.5px solid #3A2A1A; border-radius:3px;
    background:rgba(180,220,255,.2);
}
.ed-fa-body{
    position:absolute; top:44px; left:50%; transform:translateX(-50%);
    width:40px; height:54px;
    background:var(--accent);
}
/* academic gown flap */
.ed-fa-body::before{
    content:''; position:absolute; top:0; left:0; right:0; height:100%;
    background:rgba(0,0,0,.25);
    clip-path:polygon(10% 0,50% 0,40% 100%,0 100%);
}
/* white shirt showing through */
.ed-fa-body::after{
    content:''; position:absolute; top:2px; left:50%; transform:translateX(-50%);
    width:12px; height:40%;
    background:#F0ECD8;
}
.ed-fa-arm-l,.ed-fa-arm-r{
    position:absolute; width:10px; height:44px;
    background:var(--accent); border-radius:4px;
}
.ed-fa-arm-l{ top:44px; left:calc(50% - 28px); transform:rotate(6deg); transform-origin:top; }
.ed-fa-arm-r{ top:44px; right:calc(50% - 28px); transform:rotate(-14deg); transform-origin:top; }
/* book held under left arm */
.ed-fa-book{
    position:absolute; top:68px; left:calc(50% - 38px);
    width:20px; height:14px; background:#C8503A;
    border-radius:1px; transform:rotate(-10deg);
}
.ed-fa-leg-l,.ed-fa-leg-r{
    position:absolute; width:13px; height:50px;
    background:#1A1818; border-radius:3px 3px 6px 6px;
}
.ed-fa-leg-l{ top:96px; left:calc(50% - 15px); }
.ed-fa-leg-r{ top:96px; right:calc(50% - 15px); }
.ed-team-info{ padding:20px; border-top:1px solid var(--ed-border); }
.ed-team-name{ font-family:var(--ed-font-h); font-size:1.05rem; color:var(--ed-navy-d); margin-bottom:4px; }
.ed-team-role{ font-size:.7rem; letter-spacing:.14em; text-transform:uppercase; color:var(--ed-amber); font-weight:700; margin-bottom:6px; }
.ed-team-qual{ font-size:.8rem; color:var(--ed-mid); }

/* ══════════════════════════════════════════
   TESTIMONIALS
══════════════════════════════════════════ */
.ed-testi-grid{ display:grid; grid-template-columns:repeat(3,1fr); gap:24px; }
.ed-testi-card{ background:var(--ed-white); border:1px solid var(--ed-border); padding:32px; border-top:3px solid var(--ed-amber); border-radius:3px; }
.ed-testi-text{ font-family:var(--ed-font-h); font-size:.97rem; font-style:italic; color:var(--ed-dark); line-height:1.8; margin-bottom:20px; }
.ed-testi-name{ font-family:var(--ed-font-h); font-size:.95rem; color:var(--ed-navy-d); margin-bottom:3px; }
.ed-testi-role{ font-size:.72rem; letter-spacing:.14em; text-transform:uppercase; color:var(--ed-mid); }

/* ══════════════════════════════════════════
   FAQ
══════════════════════════════════════════ */
.ed-faq-list{ max-width:760px; margin:0 auto; display:flex; flex-direction:column; }
.ed-faq-item{ border-bottom:1px solid var(--ed-border); }
.ed-faq-item:first-child{ border-top:1px solid var(--ed-border); }
.ed-faq-btn{
    width:100%; text-align:left; padding:22px 0;
    font-family:var(--ed-font-h); font-size:1rem; color:var(--ed-navy-d);
    background:none; border:none; cursor:pointer;
    display:flex; justify-content:space-between; align-items:center; gap:16px;
}
.ed-faq-icon{ font-size:1.2rem; color:var(--ed-amber); flex-shrink:0; transition:transform .3s; }
.ed-faq-item.open .ed-faq-icon{ transform:rotate(45deg); }
.ed-faq-body{ max-height:0; overflow:hidden; transition:max-height .4s ease; }
.ed-faq-body-inner{ padding:0 0 24px; font-size:.92rem; color:var(--ed-mid); line-height:1.8; }

/* ══════════════════════════════════════════
   BOOKING FORM
══════════════════════════════════════════ */
.ed-contact-grid{ display:grid; grid-template-columns:1fr 1fr; gap:80px; align-items:start; }
.ed-contact-items{ display:flex; flex-direction:column; gap:24px; margin-top:32px; }
.ed-contact-item{ display:flex; gap:16px; }
.ed-contact-icon{ width:42px; height:42px; border:1px solid var(--ed-border); display:flex; align-items:center; justify-content:center; font-size:1.1rem; flex-shrink:0; border-radius:3px; }
.ed-contact-label{ font-size:.68rem; letter-spacing:.18em; text-transform:uppercase; color:var(--ed-mid); margin-bottom:3px; }
.ed-contact-val{ font-size:.9rem; color:var(--ed-dark); }

.ed-form{ display:flex; flex-direction:column; gap:20px; }
.ed-form-row{ display:grid; grid-template-columns:1fr 1fr; gap:20px; }
.ed-field label{ display:block; font-size:.7rem; font-weight:700; letter-spacing:.18em; color:var(--ed-mid); text-transform:uppercase; margin-bottom:8px; }
.ed-field input,.ed-field select,.ed-field textarea{
    width:100%; padding:13px 16px;
    background:var(--ed-white); border:1px solid var(--ed-border);
    color:var(--ed-dark); font-family:var(--ed-font-b); font-size:.92rem;
    border-radius:3px; transition:border-color .25s;
}
.ed-field input:focus,.ed-field select:focus,.ed-field textarea:focus{ outline:none; border-color:var(--ed-amber); }
.ed-field select{
    appearance:none;
    background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath d='M1 1l4 4 4-4' stroke='%23C08030' fill='none' stroke-width='1.5'/%3E%3C/svg%3E");
    background-repeat:no-repeat; background-position:calc(100% - 14px) 50%; padding-right:36px;
}
.ed-field textarea{ resize:vertical; min-height:110px; }
.ed-form-note{ font-size:.78rem; color:var(--ed-mid); }
.ed-form-note a{ color:var(--ed-amber); }

/* ══════════════════════════════════════════
   FOOTER CTA
══════════════════════════════════════════ */
.ed-cta{ background:var(--ed-navy-d); padding:80px 0; text-align:center; border-top:3px solid var(--ed-amber); }
.ed-cta-title{ font-family:var(--ed-font-h); font-size:clamp(1.8rem,4vw,3rem); font-weight:300; font-style:italic; color:var(--ed-white); margin-bottom:16px; }
.ed-cta-sub{ font-size:.9rem; color:rgba(255,255,255,.45); margin-bottom:40px; }

/* ══════════════════════════════════════════
   KEYFRAMES
══════════════════════════════════════════ */
@keyframes ed-symbol-drift{
    0%  { transform:translateY(0) rotate(0deg); }
    100%{ transform:translateY(-20px) rotate(8deg); }
}
@keyframes ed-float{
    0%,100%{ transform:translateY(0); }
    50%    { transform:translateY(-5px); }
}

/* ══════════════════════════════════════════
   RESPONSIVE
══════════════════════════════════════════ */
@media(max-width:1024px){
    .ed-hero-inner,.ed-contact-grid{ grid-template-columns:1fr; gap:48px; }
    .ed-stats-grid{ grid-template-columns:repeat(2,1fr); }
    .ed-stat-cell:nth-child(2){ border-right:none; }
    .ed-stat-cell:nth-child(3){ border-right:1px solid rgba(255,255,255,.25); }
    .ed-subj-grid{ grid-template-columns:repeat(2,1fr); }
    .ed-exam-grid{ grid-template-columns:1fr; }
    .ed-method-grid{ grid-template-columns:repeat(2,1fr); }
    .ed-method-step:nth-child(2){ border-right:none; }
    .ed-pkg-grid{ grid-template-columns:1fr; max-width:420px; margin:0 auto; }
    .ed-team-grid{ grid-template-columns:repeat(2,1fr); }
    .ed-testi-grid{ grid-template-columns:1fr; }
}
@media(max-width:640px){
    .ed-subj-grid,.ed-team-grid{ grid-template-columns:1fr; }
    .ed-form-row{ grid-template-columns:1fr; }
    .ed-stats-grid{ grid-template-columns:1fr; }
    .ed-stat-cell{ border-right:none; border-bottom:1px solid rgba(255,255,255,.25); }
    .ed-method-grid{ grid-template-columns:1fr; }
}
</style>

<div class="ed-wrap">

<!-- ══════════════════════════════════════
     HERO
══════════════════════════════════════ -->
<section class="ed-hero">

    <div class="ed-room-ceiling"></div>
    <div class="ed-wall"></div>
    <div class="ed-room-floor"></div>

    <!-- bookshelf left -->
    <div class="ed-shelf-unit">
        <?php for($r=0;$r<6;$r++): ?>
        <div class="ed-shelf-board">
            <?php for($b=0;$b<floor(count($ed_books)/6);$b++):
                $bk = $ed_books[$r * 6 + $b];
            ?>
            <div class="ed-book"
                 style="--bh:<?php echo $bk['h']*.6; ?>px;--bw:<?php echo $bk['w']*.7; ?>px;--bhu:<?php echo $bk['hue']; ?>;--bsa:<?php echo $bk['sat']; ?>;--bli:<?php echo $bk['lit']; ?>;">
            </div>
            <?php endfor; ?>
        </div>
        <?php endfor; ?>
    </div>

    <!-- chalkboard right -->
    <div class="ed-chalkboard">
        <div class="ed-chalk-line" style="top:12%;--cfs:.65rem;">E = mc²&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;F = ma</div>
        <div class="ed-chalk-line" style="top:26%;--cfs:.55rem;">∫₀^∞ e^(-x²) dx = √π/2</div>
        <div class="ed-chalk-line" style="top:40%;--cfs:.7rem;">y = mx + c</div>
        <div class="ed-chalk-line" style="top:54%;--cfs:.5rem;">∑ₙ₌₁^∞ 1/n² = π²/6</div>
        <div class="ed-chalk-line" style="top:68%;--cfs:.6rem;">PV = nRT</div>
        <div class="ed-chalk-tray">
            <div class="ed-chalk-stick" style="width:28px;"></div>
            <div class="ed-chalk-stick" style="width:20px;background:rgba(255,200,200,.6);"></div>
            <div class="ed-chalk-stick" style="width:16px;background:rgba(200,230,200,.6);"></div>
        </div>
    </div>

    <!-- desk -->
    <div class="ed-desk"></div>

    <!-- lamp -->
    <div class="ed-lamp">
        <div class="ed-lamp-pole">
            <div class="ed-lamp-shade"></div>
            <div class="ed-lamp-beam"></div>
        </div>
        <div class="ed-lamp-base"></div>
    </div>

    <!-- globe -->
    <div class="ed-globe">
        <div class="ed-globe-sphere"></div>
        <div class="ed-globe-axis"></div>
        <div class="ed-globe-base"></div>
    </div>

    <!-- stacked notebooks -->
    <div class="ed-notebooks">
        <?php
        $nbs = [[45,210],[36,32],[42,0],[38,280],[44,120]];
        foreach($nbs as $nb): ?>
        <div class="ed-nb" style="--nbh:<?php echo $nb[0]; ?>px;--nbc:<?php echo $nb[1]; ?>;"></div>
        <?php endforeach; ?>
    </div>

    <!-- floating formula symbols -->
    <?php foreach($ed_symbols as $sym): ?>
    <div class="ed-symbol"
         style="left:<?php echo $sym['left']; ?>%;top:<?php echo $sym['top']; ?>%;
                font-size:<?php echo $sym['size']; ?>px;
                --sop:<?php echo $sym['op']/100; ?>;
                --sfs:<?php echo $sym['size']; ?>px;
                --sd:<?php echo $sym['dur']; ?>ms;
                --sde:<?php echo $sym['delay']; ?>ms;">
        <?php echo esc_html($sym['sym']); ?>
    </div>
    <?php endforeach; ?>

    <!-- hero content -->
    <div class="ed-hero-inner">
        <div>
            <span class="ed-overline">Private Academic Tuition · London</span>
            <h1 class="ed-h1">
                Unlock your<br>
                <em>academic</em><br>
                <span class="ed-accent">potential.</span>
            </h1>
            <p class="ed-lead" style="margin-top:24px; color:rgba(255,255,255,.6);">
                Expert 1-to-1 tuition from primary through to university level.
                Exam-board specialists, Oxbridge coaches and subject-matter
                experts committed to lasting results, not quick fixes.
            </p>
            <div class="ed-hero-meta">
                <div class="ed-hero-meta-item">
                    <div class="ed-hero-meta-val">98%</div>
                    <div class="ed-hero-meta-label">Grade Improvement</div>
                </div>
                <div class="ed-hero-meta-item">
                    <div class="ed-hero-meta-val">1,240+</div>
                    <div class="ed-hero-meta-label">Students Taught</div>
                </div>
            </div>
            <div class="ed-hero-actions">
                <a href="#book" class="ed-btn ed-btn-amber">Book a Free Assessment</a>
                <a href="#subjects" class="ed-btn ed-btn-outline">Our Subjects</a>
            </div>
        </div>

        <!-- study scene card -->
        <div>
            <div class="ed-scene-card">
                <div class="ed-sc-wall"></div>
                <div class="ed-sc-shelf">
                    <?php for($r=0;$r<4;$r++): ?>
                    <div class="ed-sc-shelf-row">
                        <?php for($b=0;$b<6;$b++):
                            $sh = rand(40,65); $sw = rand(8,15);
                            $sh2= $book_hues[($r*6+$b)%count($book_hues)];
                        ?>
                        <div class="ed-sc-book" style="--sbh:<?php echo $sh; ?>px;--sbw:<?php echo $sw; ?>px;--sbh2:<?php echo $sh2; ?>;"></div>
                        <?php endfor; ?>
                    </div>
                    <?php endfor; ?>
                </div>
                <div class="ed-sc-floor"></div>
                <div class="ed-sc-desk"></div>
                <div class="ed-sc-lamp-beam"></div>
                <div class="ed-sc-globe"></div>
                <div class="ed-float-badge">Dr Marsh &amp; Associates · Est. 2008</div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     STATS BAR
══════════════════════════════════════ -->
<div class="ed-stats-bar">
    <div class="ed-container">
        <div class="ed-stats-grid">
            <?php foreach($ed_stats as $st):
                $isf = floor($st['val'])!==(float)$st['val']; ?>
            <div class="ed-stat-cell">
                <span class="ed-stat-val"
                      data-target="<?php echo $st['val']; ?>"
                      data-suffix="<?php echo esc_attr($st['suffix']); ?>"
                      data-float="<?php echo $isf?'1':'0'; ?>">
                    0<?php echo esc_html($st['suffix']); ?>
                </span>
                <div class="ed-stat-label"><?php echo esc_html($st['label']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ══════════════════════════════════════
     SUBJECTS
══════════════════════════════════════ -->
<section class="ed-section" id="subjects">
    <div class="ed-container">
        <div class="ed-section-header">
            <span class="ed-overline">What We Teach</span>
            <h2 class="ed-h2">Subjects &amp; <span class="ed-accent">Specialisms</span></h2>
            <div class="ed-divider"></div>
            <p class="ed-lead" style="margin:0 auto; text-align:center;">
                Every subject taught by specialists with first-class degrees, teaching qualifications and proven exam results.
            </p>
        </div>
        <div class="ed-subj-grid">
            <?php foreach($ed_subjects as $s): ?>
            <div class="ed-subj-card">
                <span class="ed-subj-icon"><?php echo $s['icon']; ?></span>
                <div class="ed-subj-name"><?php echo esc_html($s['name']); ?></div>
                <div class="ed-subj-levels"><?php echo esc_html($s['levels']); ?></div>
                <p class="ed-subj-desc"><?php echo esc_html($s['desc']); ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     EXAM PREPARATION
══════════════════════════════════════ -->
<section class="ed-section ed-section-alt">
    <div class="ed-container">
        <div class="ed-section-header">
            <span class="ed-overline">Exam Preparation</span>
            <h2 class="ed-h2">Every Stage, Every <span class="ed-accent">Board</span></h2>
            <div class="ed-divider"></div>
        </div>
        <div class="ed-exam-grid">
            <?php foreach($ed_exams as $ex): ?>
            <div class="ed-exam-card">
                <div class="ed-exam-icon"><?php echo $ex['icon']; ?></div>
                <div>
                    <div class="ed-exam-name"><?php echo esc_html($ex['name']); ?></div>
                    <p class="ed-exam-desc"><?php echo esc_html($ex['desc']); ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     METHODOLOGY
══════════════════════════════════════ -->
<section class="ed-section">
    <div class="ed-container">
        <div class="ed-section-header">
            <span class="ed-overline">How We Work</span>
            <h2 class="ed-h2">The <span class="ed-accent">Approach</span></h2>
            <div class="ed-divider"></div>
        </div>
        <div class="ed-method-grid">
            <?php foreach($ed_method as $m): ?>
            <div class="ed-method-step">
                <div class="ed-method-num"><?php echo esc_html($m['n']); ?></div>
                <div class="ed-method-title"><?php echo esc_html($m['t']); ?></div>
                <p class="ed-method-desc"><?php echo esc_html($m['d']); ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     PACKAGES
══════════════════════════════════════ -->
<section class="ed-section ed-section-alt">
    <div class="ed-container">
        <div class="ed-section-header">
            <span class="ed-overline">Investment</span>
            <h2 class="ed-h2">Tuition <span class="ed-accent">Packages</span></h2>
            <div class="ed-divider"></div>
            <p class="ed-lead" style="margin:0 auto; text-align:center;">
                All packages begin with a free 30-minute diagnostic assessment. No minimum term.
            </p>
        </div>
        <div class="ed-pkg-grid">
            <?php foreach($ed_packages as $pkg): ?>
            <div class="ed-pkg-card <?php echo $pkg['highlight']?'highlight':''; ?>">
                <?php if($pkg['highlight']): ?>
                <div class="ed-pkg-badge">Most Popular</div>
                <?php endif; ?>
                <?php $c = $pkg['highlight']?'d':'l'; ?>
                <div class="ed-pkg-name <?php echo $c; ?>"><?php echo esc_html($pkg['name']); ?></div>
                <div class="ed-pkg-sessions <?php echo $c; ?>"><?php echo esc_html($pkg['sessions']); ?></div>
                <div class="ed-pkg-price <?php echo $c; ?>"><?php echo esc_html($pkg['price']); ?></div>
                <div class="ed-pkg-period <?php echo $c; ?>"><?php echo esc_html($pkg['period']); ?></div>
                <ul class="ed-pkg-features">
                    <?php foreach($pkg['features'] as $f): ?>
                    <li class="<?php echo $c; ?>"><?php echo esc_html($f); ?></li>
                    <?php endforeach; ?>
                </ul>
                <a href="#book" class="ed-btn <?php echo $pkg['highlight']?'ed-btn-amber':'ed-btn-dark-outline'; ?>" style="width:100%;justify-content:center;">
                    Get Started
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     TEAM
══════════════════════════════════════ -->
<section class="ed-section">
    <div class="ed-container">
        <div class="ed-section-header">
            <span class="ed-overline">Our Tutors</span>
            <h2 class="ed-h2">Learn from the <span class="ed-accent">Best</span></h2>
            <div class="ed-divider"></div>
        </div>
        <div class="ed-team-grid">
            <?php foreach($ed_tutors as $t): ?>
            <div class="ed-team-card" style="--accent:<?php echo esc_attr($t['colour']); ?>;">
                <div class="ed-team-fig">
                    <div class="ed-team-top"></div>
                    <div class="ed-figure-a">
                        <div class="ed-fa-head"></div>
                        <div class="ed-fa-body"></div>
                        <div class="ed-fa-arm-l"></div>
                        <div class="ed-fa-arm-r"></div>
                        <div class="ed-fa-book"></div>
                        <div class="ed-fa-leg-l"></div>
                        <div class="ed-fa-leg-r"></div>
                    </div>
                </div>
                <div class="ed-team-info">
                    <div class="ed-team-name"><?php echo esc_html($t['name']); ?></div>
                    <div class="ed-team-role"><?php echo esc_html($t['role']); ?></div>
                    <div class="ed-team-qual"><?php echo esc_html($t['qual']); ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     TESTIMONIALS
══════════════════════════════════════ -->
<section class="ed-section ed-section-alt">
    <div class="ed-container">
        <div class="ed-section-header">
            <span class="ed-overline">Success Stories</span>
            <h2 class="ed-h2">What <span class="ed-accent">Parents &amp; Students</span> Say</h2>
            <div class="ed-divider"></div>
        </div>
        <div class="ed-testi-grid">
            <?php foreach($ed_testimonials as $t): ?>
            <div class="ed-testi-card">
                <p class="ed-testi-text">"<?php echo esc_html($t['text']); ?>"</p>
                <div class="ed-testi-name"><?php echo esc_html($t['name']); ?></div>
                <div class="ed-testi-role"><?php echo esc_html($t['role']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     FAQ
══════════════════════════════════════ -->
<section class="ed-section">
    <div class="ed-container">
        <div class="ed-section-header">
            <span class="ed-overline">FAQ</span>
            <h2 class="ed-h2">Your <span class="ed-accent">Questions</span> Answered</h2>
            <div class="ed-divider"></div>
        </div>
        <div class="ed-faq-list">
            <?php foreach($ed_faqs as $i=>$faq): ?>
            <div class="ed-faq-item" id="ed-faq-<?php echo $i; ?>">
                <button class="ed-faq-btn"
                        aria-expanded="false"
                        aria-controls="ed-faq-body-<?php echo $i; ?>">
                    <?php echo esc_html($faq['q']); ?>
                    <span class="ed-faq-icon">+</span>
                </button>
                <div class="ed-faq-body" id="ed-faq-body-<?php echo $i; ?>" role="region">
                    <div class="ed-faq-body-inner"><?php echo esc_html($faq['a']); ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     BOOKING FORM
══════════════════════════════════════ -->
<section class="ed-section ed-section-alt" id="book">
    <div class="ed-container">
        <div class="ed-contact-grid">

            <div>
                <span class="ed-overline">Get Started</span>
                <h2 class="ed-h2" style="margin-bottom:16px;">
                    Book a Free <span class="ed-accent">Assessment</span>
                </h2>
                <div class="ed-divider"></div>
                <p class="ed-lead">
                    A 30-minute diagnostic session to identify exactly what your child needs —
                    zero obligation, completely free. We respond within one working day.
                </p>
                <div class="ed-contact-items">
                    <div class="ed-contact-item">
                        <div class="ed-contact-icon">📍</div>
                        <div>
                            <div class="ed-contact-label">Offices</div>
                            <div class="ed-contact-val">22 Bedford Square, Bloomsbury, London WC1B 3HH</div>
                        </div>
                    </div>
                    <div class="ed-contact-item">
                        <div class="ed-contact-icon">📞</div>
                        <div>
                            <div class="ed-contact-label">Phone</div>
                            <div class="ed-contact-val">+44 (0)20 7637 4400</div>
                        </div>
                    </div>
                    <div class="ed-contact-item">
                        <div class="ed-contact-icon">⏰</div>
                        <div>
                            <div class="ed-contact-label">Office Hours</div>
                            <div class="ed-contact-val">Mon–Fri 08:00–20:00 · Sat 09:00–17:00</div>
                        </div>
                    </div>
                    <div class="ed-contact-item">
                        <div class="ed-contact-icon">🌐</div>
                        <div>
                            <div class="ed-contact-label">Tuition Available</div>
                            <div class="ed-contact-val">In-Person (London) · Online (Worldwide)</div>
                        </div>
                    </div>
                </div>
            </div>

            <form class="ed-form"
                  method="post"
                  action="<?php echo esc_url(admin_url('admin-post.php')); ?>">

                <?php wp_nonce_field('tf_ed_enquiry','tf_ed_nonce'); ?>
                <input type="hidden" name="action" value="tf_ed_enquiry">

                <div class="ed-form-row">
                    <div class="ed-field">
                        <label for="ed-parent">Parent / Guardian Name <span style="color:var(--ed-amber)">*</span></label>
                        <input type="text" id="ed-parent" name="ed_parent" required placeholder="Sarah Whitfield">
                    </div>
                    <div class="ed-field">
                        <label for="ed-student">Student Name <span style="color:var(--ed-amber)">*</span></label>
                        <input type="text" id="ed-student" name="ed_student" required placeholder="Emma Whitfield">
                    </div>
                </div>

                <div class="ed-form-row">
                    <div class="ed-field">
                        <label for="ed-email">Email Address <span style="color:var(--ed-amber)">*</span></label>
                        <input type="email" id="ed-email" name="ed_email" required placeholder="sarah@email.com">
                    </div>
                    <div class="ed-field">
                        <label for="ed-phone">Phone Number</label>
                        <input type="tel" id="ed-phone" name="ed_phone" placeholder="+44 7700 900 000">
                    </div>
                </div>

                <div class="ed-form-row">
                    <div class="ed-field">
                        <label for="ed-subject">Primary Subject <span style="color:var(--ed-amber)">*</span></label>
                        <select id="ed-subject" name="ed_subject" required>
                            <option value="" disabled selected>Select subject…</option>
                            <option>Mathematics</option>
                            <option>Physics</option>
                            <option>Chemistry</option>
                            <option>Biology</option>
                            <option>English Literature</option>
                            <option>English Language</option>
                            <option>French</option>
                            <option>Spanish</option>
                            <option>German</option>
                            <option>Mandarin</option>
                            <option>History</option>
                            <option>Geography</option>
                            <option>Economics</option>
                            <option>Computer Science</option>
                            <option>Other</option>
                        </select>
                    </div>
                    <div class="ed-field">
                        <label for="ed-level">Current Level <span style="color:var(--ed-amber)">*</span></label>
                        <select id="ed-level" name="ed_level" required>
                            <option value="" disabled selected>Select level…</option>
                            <option>Primary (7–11)</option>
                            <option>11+ Preparation</option>
                            <option>KS3 (11–14)</option>
                            <option>GCSE / IGCSE</option>
                            <option>A-Level / Pre-U / IB</option>
                            <option>Oxbridge / Entrance Exam</option>
                            <option>University Level</option>
                        </select>
                    </div>
                </div>

                <div class="ed-field">
                    <label for="ed-goals">Learning Goals &amp; Exam Dates</label>
                    <textarea id="ed-goals" name="ed_goals"
                              placeholder="Tell us about the student's goals, current challenges and any upcoming exam dates we should be aware of…"></textarea>
                </div>

                <p class="ed-form-note">
                    All information is held securely and in confidence. By submitting you agree to our <a href="#">Privacy Policy</a>.
                </p>

                <button type="submit" class="ed-btn ed-btn-amber" style="width:100%;justify-content:center;">
                    Book Free Assessment →
                </button>
            </form>

        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     FOOTER CTA
══════════════════════════════════════ -->
<div class="ed-cta">
    <div class="ed-container">
        <span class="ed-overline" style="text-align:center;display:block;color:var(--ed-amber);">
            1,240+ Students · 16 Years · 98% Grade Improvement
        </span>
        <div class="ed-cta-title">Every grade has a <em>ceiling</em> — let's raise yours.</div>
        <p class="ed-cta-sub">Free 30-minute assessment · No minimum commitment · Results guaranteed</p>
        <div style="display:flex;gap:16px;justify-content:center;flex-wrap:wrap;">
            <a href="#book" class="ed-btn ed-btn-amber">Book Free Assessment</a>
            <a href="#subjects" class="ed-btn ed-btn-outline" style="border-color:rgba(255,255,255,.3);">Explore Subjects</a>
        </div>
    </div>
</div>

</div><!-- /.ed-wrap -->

<script>
(function(){
    /* ── Animated counters ─────────────────────── */
    const easeOut = t => 1 - Math.pow(1 - t, 3);
    const counterEls = document.querySelectorAll('.ed-stat-val[data-target]');
    const seen = new Set();
    const obs = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if(!entry.isIntersecting || seen.has(entry.target)) return;
            seen.add(entry.target);
            const el     = entry.target;
            const target = parseFloat(el.dataset.target);
            const suffix = el.dataset.suffix || '';
            const isFloat= el.dataset.float === '1';
            if(isNaN(target)) return;
            const dur = 1800, start = performance.now();
            const tick = now => {
                const t = Math.min((now - start) / dur, 1);
                const v = easeOut(t) * target;
                el.textContent = (isFloat ? v.toFixed(1) : Math.round(v)) + suffix;
                if(t < 1) requestAnimationFrame(tick);
            };
            requestAnimationFrame(tick);
        });
    }, { threshold: 0.4 });
    counterEls.forEach(el => obs.observe(el));

    /* ── FAQ accordion ─────────────────────────── */
    document.querySelectorAll('.ed-faq-btn').forEach(btn => {
        btn.addEventListener('click', function(){
            const item = this.closest('.ed-faq-item');
            const body = item.querySelector('.ed-faq-body');
            const open = item.classList.contains('open');
            document.querySelectorAll('.ed-faq-item.open').forEach(i => {
                i.classList.remove('open');
                i.querySelector('.ed-faq-body').style.maxHeight = '0';
                i.querySelector('.ed-faq-btn').setAttribute('aria-expanded','false');
            });
            if(!open){
                item.classList.add('open');
                body.style.maxHeight = body.scrollHeight + 'px';
                this.setAttribute('aria-expanded','true');
            }
        });
    });
})();
</script>

<?php get_footer(); ?>
