<?php
/**
 * Template Name: Premium – Real Estate Agency
 *
 * @package ThemeFlex
 */

defined('ABSPATH') || exit;

srand(crc32(get_the_permalink()));

/* ── Featured Listings ──────────────────────────────────────── */
$rle_listings = [
    ['address'=>'14 Kensington Gardens Square','area'=>'Notting Hill, W2','price'=>'£4,850,000','beds'=>5,'baths'=>4,'sqft'=>3200,'type'=>'Townhouse','tag'=>'Featured','color'=>'#2c3e50'],
    ['address'=>'Penthouse 3, The Strand Residences','area'=>'City of London, WC2','price'=>'£6,200,000','beds'=>3,'baths'=>3,'sqft'=>2800,'type'=>'Penthouse','tag'=>'New','color'=>'#8b6914'],
    ['address'=>'Ashwood Manor, Hampstead Heath','area'=>'Hampstead, NW3','price'=>'£9,750,000','beds'=>7,'baths'=>6,'sqft'=>6400,'type'=>'Detached House','tag'=>'Exclusive','color'=>'#2d4a3e'],
    ['address'=>'Apt 12C, Belgravia Court','area'=>'Belgravia, SW1','price'=>'£3,400,000','beds'=>2,'baths'=>2,'sqft'=>1650,'type'=>'Apartment','tag'=>'Reduced','color'=>'#4a2030'],
    ['address'=>'The Old Rectory, Richmond Hill','area'=>'Richmond, TW10','price'=>'£5,600,000','beds'=>6,'baths'=>5,'sqft'=>4800,'type'=>'Period Property','tag'=>'Featured','color'=>'#1a3a5c'],
    ['address'=>'Loft 8, The Biscuit Factory','area'=>'Bermondsey, SE1','price'=>'£1,950,000','beds'=>2,'baths'=>2,'sqft'=>1900,'type'=>'Loft','tag'=>'New','color'=>'#3d2b1a'],
];

/* ── Services ───────────────────────────────────────────────── */
$rle_services = [
    ['icon'=>'🏡','title'=>'Residential Sales','desc'=>'Expert guidance for buyers and sellers across London\'s prime residential markets, from first-time purchases to £10m+ estates.'],
    ['icon'=>'🏢','title'=>'Lettings & Management','desc'=>'Full-service lettings for landlords and tenants — from tenant-find to comprehensive property management.'],
    ['icon'=>'📊','title'=>'Investment Advisory','desc'=>'Strategic portfolio advice, yield analysis and acquisition sourcing for private investors and family offices.'],
    ['icon'=>'🌍','title'=>'International Desk','desc'=>'Dedicated service for overseas buyers acquiring London property, including tax, legal and finance referrals.'],
    ['icon'=>'✏️','title'=>'New Developments','desc'=>'Exclusive off-plan and new-build sales across prime and super-prime new developments.'],
    ['icon'=>'📋','title'=>'Valuation & Survey','desc'=>'RICS-compliant valuations for sale, mortgage, probate, divorce and portfolio assessment purposes.'],
];

/* ── Agents ─────────────────────────────────────────────────── */
$rle_agents = [
    ['name'=>'Victoria Langham','title'=>'Director — Prime Sales','sales'=>'£180m+','listings'=>42,'color'=>'#2c3e50','hair'=>'#3d2b1a'],
    ['name'=>'Oliver Stanwick','title'=>'Senior Negotiator','sales'=>'£95m+','listings'=>28,'color'=>'#1a3a5c','hair'=>'#8b6914'],
    ['name'=>'Chiara Benedetti','title'=>'International Desk Lead','sales'=>'£120m+','listings'=>35,'color'=>'#2d4a3e','hair'=>'#1a1a1a'],
    ['name'=>'Marcus Reid','title'=>'Investment Specialist','sales'=>'£75m+','listings'=>22,'color'=>'#4a2030','hair'=>'#3a2a1a'],
];

/* ── Process ────────────────────────────────────────────────── */
$rle_process = [
    ['num'=>'01','icon'=>'🤝','title'=>'Initial Valuation','desc'=>'A comprehensive, no-obligation market appraisal with comparable analysis and a bespoke marketing strategy.'],
    ['num'=>'02','icon'=>'📸','title'=>'Premium Marketing','desc'=>'Professional photography, architectural videography, floor plans and targeted digital & print campaigns.'],
    ['num'=>'03','icon'=>'🔑','title'=>'Qualified Viewings','desc'=>'All applicants are financially pre-qualified before viewings, ensuring only serious buyers see your property.'],
    ['num'=>'04','icon'=>'✅','title'=>'Sale to Completion','desc'=>'Expert negotiation, sale progression and dedicated support through exchange and legal completion.'],
];

/* ── Stats ──────────────────────────────────────────────────── */
$rle_stats = [
    ['val'=>'1200','suffix'=>'+','label'=>'Properties Sold'],
    ['val'=>'98','suffix'=>'%','label'=>'Asking Price Achieved'],
    ['val'=>'28','suffix'=>'','label'=>'Average Days to Sale'],
    ['val'=>'£2.4','suffix'=>'bn','label'=>'Total Sales Volume'],
];

/* ── Testimonials ───────────────────────────────────────────── */
$rle_testimonials = [
    ['quote'=>'Victoria and her team achieved £200,000 over our guide price. Their marketing was exceptional — the video tour alone generated 14 viewings in the first week. Outstanding service.','author'=>'Mr & Mrs Harrington','property'=>'Notting Hill Townhouse'],
    ['quote'=>'As overseas buyers we were nervous about the process. The international desk guided us through every step — legal, mortgage, survey — and we completed without a single stressful moment.','author'=>'The Marchetti Family','property'=>'Belgravia Apartment'],
    ['quote'=>'Marcus\' investment advice has added two excellent properties to our portfolio at yields well above market average. His knowledge of off-market opportunities is genuinely unmatched.','author'=>'Private Family Office','property'=>'Portfolio of 6 Units'],
];

/* ── Awards ─────────────────────────────────────────────────── */
$rle_awards = [
    ['icon'=>'🏆','award'=>'Estates Gazette — Best London Agency 2024'],
    ['icon'=>'⭐','award'=>'The Sunday Times — Top 10 Estate Agent UK 2024'],
    ['icon'=>'🥇','award'=>'ARLA Propertymark Gold Award 2023'],
    ['icon'=>'🏅','award'=>'London Property Awards — Prime Sales 2023'],
];

/* ── FAQ ────────────────────────────────────────────────────── */
$rle_faqs = [
    ['q'=>'How do you determine the asking price?','a'=>'We carry out a detailed comparable market analysis using recently sold properties in your area, current competition, and our live buyer demand data. We then recommend a price strategy designed to maximise both speed and value.'],
    ['q'=>'Do you charge upfront fees?','a'=>'No. Our fee is a percentage of the sale price, payable only on successful completion. There are no upfront or marketing fees on our standard agency agreement.'],
    ['q'=>'How do you qualify buyers?','a'=>'Every applicant is financially pre-qualified before a viewing is arranged. We confirm proof of funds, mortgage in principle (if applicable) and chain position. This means only serious, proceedable buyers visit your property.'],
    ['q'=>'Can you sell discreetly without public marketing?','a'=>'Yes. We operate an extensive off-market network. For clients who require complete discretion — no portals, no boards, no public marketing — we can match your property directly with our database of pre-vetted buyers.'],
    ['q'=>'What is your average time to sell?','a'=>'Our average time from instruction to accepted offer is 28 days across all property types. For prime and super-prime property the timeframe varies, but our sale-through rate of 98% of asking price demonstrates consistent demand.'],
];

get_header();
?>

<!– Real Estate Agency — ThemeFlex Premium Template –>
<style>
@import url('https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&family=Inter:wght@300;400;500;600;700&display=swap');

:root {
  --rle-navy:     #0e1f33;
  --rle-deep:     #152840;
  --rle-gold:     #c19a3a;
  --rle-gold-lt:  #d9b85a;
  --rle-cream:    #f8f4ef;
  --rle-white:    #ffffff;
  --rle-slate:    #4a5568;
  --rle-silver:   #8a95a3;
  --rle-border:   rgba(193,154,58,0.2);
  --rle-serif:    'Libre Baskerville', Georgia, serif;
  --rle-sans:     'Inter', system-ui, sans-serif;
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

.rle-wrap { font-family: var(--rle-sans); color: var(--rle-navy); background: var(--rle-white); overflow-x: hidden; }

/* ── HERO ──────────────────────────────────────────────────── */
.rle-hero {
  position: relative;
  min-height: 100vh;
  background: var(--rle-navy);
  overflow: hidden;
  display: flex;
  align-items: flex-end;
}

/* Sky gradient */
.rle-hero-sky {
  position: absolute; inset: 0;
  background: linear-gradient(180deg,
    #060e1a 0%,
    #0a1828 20%,
    #0e2040 50%,
    #1a3a6a 80%,
    #2a4a7a 100%
  );
}

/* Stars */
.rle-star {
  position: absolute;
  background: #fff;
  border-radius: 50%;
  animation: rle-twinkle var(--tw-dur, 3s) ease-in-out infinite;
  animation-delay: var(--tw-delay, 0s);
}
@keyframes rle-twinkle {
  0%, 100% { opacity: var(--tw-max, 0.8); }
  50% { opacity: 0.2; }
}

/* Moon */
.rle-moon {
  position: absolute;
  top: 60px; right: 12%;
  width: 70px; height: 70px;
  background: #f5e8b0;
  border-radius: 50%;
  box-shadow: 0 0 40px rgba(245,232,176,0.4), 0 0 80px rgba(245,232,176,0.15);
}
.rle-moon::before {
  content: '';
  position: absolute;
  top: 8px; right: 8px;
  width: 18px; height: 18px;
  background: rgba(180,160,80,0.2);
  border-radius: 50%;
}

/* CSS City Skyline */
.rle-skyline {
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 70%;
  pointer-events: none;
}

/* Individual buildings via PHP */
<?php
$rle_buildings = [
  /* x%, width, height, color, windows_cols, windows_rows */
  [0,   80,  180, '#0d1928', 3, 5],
  [5,   60,  260, '#111f30', 2, 8],
  [9,  100,  220, '#0e1f33', 4, 6],
  [16,  70,  300, '#0a1828', 2, 9],
  [21,  90,  240, '#132030', 3, 7],
  [27,  50,  180, '#0d1928', 2, 5],
  [30, 120,  380, '#0a1525', 4,11], /* tallest */
  [39,  80,  280, '#111f30', 3, 8],
  [44,  60,  200, '#0e1f33', 2, 6],
  [47, 110,  320, '#0d1928', 4, 9],
  [55,  75,  260, '#132030', 3, 7],
  [59,  65,  200, '#0a1828', 2, 6],
  [62,  90,  340, '#0e1f33', 3,10],
  [69,  55,  180, '#0d1928', 2, 5],
  [72,  85,  300, '#111f30', 3, 9],
  [78,  70,  220, '#132030', 2, 6],
  [82,  95,  260, '#0a1828', 4, 7],
  [87,  60,  190, '#0e1f33', 2, 5],
  [90,  75,  280, '#0d1928', 3, 8],
  [95, 100,  200, '#111f30', 4, 5],
];

foreach ($rle_buildings as $bi => $b):
  [$bx, $bw, $bh, $bc, $wcols, $wrows] = $b;
  echo ".rle-bld-{$bi}{position:absolute;bottom:0;left:{$bx}%;width:{$bw}px;height:{$bh}px;background:{$bc};}\n";
  // windows
  for ($wr = 0; $wr < $wrows; $wr++):
    for ($wc = 0; $wc < $wcols; $wc++):
      $lit = (rand(0,3) > 0) ? 'rgba(255,220,100,0.7)' : 'rgba(100,150,220,0.3)';
      $wx = 8 + $wc * (($bw - 16) / $wcols);
      $wy = $bh - 20 - $wr * 28;
      echo ".rle-bld-{$bi} .rle-win-{$wr}-{$wc}{position:absolute;left:{$wx}px;top:{$wy}px;width:8px;height:12px;background:{$lit};}\n";
    endfor;
  endfor;
endforeach;
?>

/* Reflection in water */
.rle-water {
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 120px;
  background: linear-gradient(180deg, rgba(14,31,51,0.6) 0%, rgba(10,20,40,0.9) 100%);
  backdrop-filter: blur(2px);
}
.rle-water::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(193,154,58,0.4), transparent);
}
/* Ripples */
.rle-ripple {
  position: absolute;
  border-radius: 50%;
  border: 1px solid rgba(193,154,58,0.15);
  animation: rle-ripple-anim 4s ease-out infinite;
}
@keyframes rle-ripple-anim {
  0% { transform: scaleX(1); opacity: 0.5; }
  100% { transform: scaleX(3); opacity: 0; }
}

/* Atmospheric glow */
.rle-city-glow {
  position: absolute;
  bottom: 60px; left: 50%;
  transform: translateX(-50%);
  width: 80%; height: 200px;
  background: radial-gradient(ellipse at 50% 100%, rgba(193,154,58,0.08) 0%, transparent 70%);
  pointer-events: none;
}

/* Hero content over skyline */
.rle-hero-content {
  position: relative;
  z-index: 10;
  width: 100%;
  padding: 0 60px 180px;
  max-width: 760px;
}

.rle-hero-eyebrow {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-bottom: 24px;
}
.rle-eyebrow-line { width: 48px; height: 1px; background: var(--rle-gold); }
.rle-eyebrow-text {
  font-size: 0.68rem;
  font-weight: 600;
  letter-spacing: 0.22em;
  text-transform: uppercase;
  color: var(--rle-gold);
}

.rle-hero h1 {
  font-family: var(--rle-serif);
  font-size: clamp(3rem, 6vw, 6rem);
  font-weight: 700;
  line-height: 1.06;
  color: var(--rle-white);
  margin-bottom: 28px;
}
.rle-hero h1 em { font-style: italic; color: var(--rle-gold); }
.rle-hero-sub {
  font-size: 1.1rem;
  line-height: 1.7;
  color: rgba(248,244,239,0.7);
  max-width: 520px;
  margin-bottom: 48px;
}

.rle-hero-ctas {
  display: flex;
  gap: 16px;
  flex-wrap: wrap;
  margin-bottom: 56px;
}

/* Search bar */
.rle-search-bar {
  display: flex;
  gap: 0;
  background: rgba(255,255,255,0.08);
  border: 1px solid var(--rle-border);
  backdrop-filter: blur(8px);
  max-width: 620px;
}
.rle-search-field {
  flex: 1;
  background: none;
  border: none;
  padding: 16px 20px;
  color: var(--rle-white);
  font-family: var(--rle-sans);
  font-size: 0.9rem;
  outline: none;
}
.rle-search-field::placeholder { color: rgba(138,149,163,0.6); }
.rle-search-select {
  background: none;
  border: none;
  border-left: 1px solid var(--rle-border);
  color: var(--rle-silver);
  padding: 16px 16px;
  font-family: var(--rle-sans);
  font-size: 0.85rem;
  outline: none;
  cursor: pointer;
}
.rle-search-select option { background: var(--rle-deep); }
.rle-search-btn {
  background: var(--rle-gold);
  border: none;
  color: var(--rle-navy);
  padding: 16px 28px;
  font-family: var(--rle-sans);
  font-size: 0.82rem;
  font-weight: 700;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  cursor: pointer;
  transition: background 0.25s;
}
.rle-search-btn:hover { background: var(--rle-gold-lt); }

/* Scroll indicator */
.rle-hero-scroll {
  position: absolute;
  bottom: 140px; right: 60px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  z-index: 10;
}
.rle-hero-scroll-text {
  font-size: 0.65rem;
  letter-spacing: 0.2em;
  text-transform: uppercase;
  color: var(--rle-gold);
  writing-mode: vertical-rl;
}
.rle-hero-scroll-line {
  width: 1px; height: 60px;
  background: linear-gradient(180deg, var(--rle-gold), transparent);
  animation: rle-scroll-pulse 2s ease-in-out infinite;
}
@keyframes rle-scroll-pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.3; }
}

/* Stats strip */
.rle-hero-strip {
  position: absolute;
  bottom: 0; left: 0; right: 0;
  background: rgba(10,20,40,0.95);
  border-top: 1px solid var(--rle-border);
  backdrop-filter: blur(12px);
  display: flex;
  justify-content: center;
  z-index: 10;
}
.rle-strip-item {
  padding: 20px 48px;
  border-right: 1px solid var(--rle-border);
  text-align: center;
}
.rle-strip-item:last-child { border-right: none; }
.rle-strip-val {
  font-family: var(--rle-serif);
  font-size: 1.8rem;
  font-weight: 700;
  color: var(--rle-gold);
  display: block;
}
.rle-strip-label {
  font-size: 0.68rem;
  font-weight: 600;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--rle-silver);
  margin-top: 4px;
  display: block;
}

/* ── SHARED LAYOUT ─────────────────────────────────────────── */
.rle-section {
  padding: 100px 60px;
  max-width: 1320px;
  margin: 0 auto;
}
.rle-section-full { padding: 100px 60px; }
.rle-section-label {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 14px;
}
.rle-label-line { width: 36px; height: 1px; background: var(--rle-gold); }
.rle-label-text {
  font-size: 0.68rem;
  font-weight: 700;
  letter-spacing: 0.22em;
  text-transform: uppercase;
  color: var(--rle-gold);
}
.rle-section-title {
  font-family: var(--rle-serif);
  font-size: clamp(1.8rem, 3vw, 2.8rem);
  font-weight: 700;
  line-height: 1.2;
  color: var(--rle-navy);
  margin-bottom: 14px;
}
.rle-section-title em { font-style: italic; color: var(--rle-gold); }
.rle-section-intro {
  font-size: 1rem;
  line-height: 1.75;
  color: var(--rle-slate);
  max-width: 580px;
  margin-bottom: 60px;
}

/* ── REVEAL ──────────────────────────────────────────────────  */
.rle-reveal {
  opacity: 0;
  transform: translateY(24px);
  transition: opacity 0.6s ease, transform 0.6s ease;
}
.rle-reveal.visible { opacity: 1; transform: translateY(0); }

/* ── BUTTONS ─────────────────────────────────────────────────  */
.rle-btn-primary {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 15px 32px;
  background: var(--rle-gold);
  color: var(--rle-navy);
  font-family: var(--rle-sans);
  font-size: 0.78rem;
  font-weight: 700;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  text-decoration: none;
  border: none; cursor: pointer;
  transition: background 0.25s, transform 0.2s;
}
.rle-btn-primary:hover { background: var(--rle-gold-lt); transform: translateY(-2px); }
.rle-btn-outline {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 14px 32px;
  background: transparent;
  color: var(--rle-white);
  font-family: var(--rle-sans);
  font-size: 0.78rem;
  font-weight: 600;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  text-decoration: none;
  border: 1px solid rgba(255,255,255,0.3);
  transition: border-color 0.25s, color 0.25s, transform 0.2s;
}
.rle-btn-outline:hover { border-color: var(--rle-gold); color: var(--rle-gold); transform: translateY(-2px); }

/* ── LISTINGS ────────────────────────────────────────────────  */
.rle-listings-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 28px;
}
.rle-listing-card {
  background: var(--rle-white);
  border: 1px solid rgba(14,31,51,0.08);
  overflow: hidden;
  transition: box-shadow 0.3s, transform 0.3s;
  cursor: pointer;
}
.rle-listing-card:hover { box-shadow: 0 20px 60px rgba(14,31,51,0.12); transform: translateY(-4px); }

/* CSS property illustration */
.rle-listing-art {
  height: 200px;
  position: relative;
  overflow: hidden;
}
.rle-listing-sky {
  position: absolute; inset: 0;
  background: linear-gradient(180deg, #b8d4f0 0%, #dcedf8 100%);
}
.rle-listing-sun {
  position: absolute;
  top: 20px; right: 24px;
  width: 36px; height: 36px;
  background: #f5d060;
  border-radius: 50%;
  box-shadow: 0 0 20px rgba(245,208,96,0.5);
}
/* Property building CSS */
.rle-prop-body {
  position: absolute;
  bottom: 0; left: 50%;
  transform: translateX(-50%);
}
.rle-prop-roof {
  position: absolute;
  bottom: 100%; left: 50%;
  transform: translateX(-50%);
  width: 0; height: 0;
}
.rle-prop-win {
  position: absolute;
  background: rgba(245,232,176,0.8);
  border: 1px solid rgba(193,154,58,0.3);
  border-radius: 50% 50% 0 0 / 30% 30% 0 0;
}
.rle-prop-door {
  position: absolute;
  bottom: 0; left: 50%;
  transform: translateX(-50%);
  background: #3d2b1a;
  border-radius: 50% 50% 0 0 / 20% 20% 0 0;
}
/* Ground / lawn */
.rle-prop-ground {
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 32px;
  background: linear-gradient(180deg, #6ab04c 0%, #4a8a34 100%);
}
/* Path */
.rle-prop-path {
  position: absolute;
  bottom: 0; left: 50%;
  transform: translateX(-50%);
  width: 20px;
  height: 32px;
  background: #c8a878;
}
/* Trees */
.rle-prop-tree-trunk {
  position: absolute;
  bottom: 32px;
  width: 6px;
  height: 24px;
  background: #5c3d1e;
}
.rle-prop-tree-top {
  position: absolute;
  width: 0; height: 0;
  border-style: solid;
}

/* Listing tag */
.rle-listing-tag {
  position: absolute;
  top: 14px; left: 14px;
  padding: 5px 12px;
  font-size: 0.68rem;
  font-weight: 700;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  border-radius: 2px;
  z-index: 2;
}

.rle-listing-body { padding: 24px 26px 28px; }
.rle-listing-price {
  font-family: var(--rle-serif);
  font-size: 1.5rem;
  font-weight: 700;
  color: var(--rle-navy);
  margin-bottom: 6px;
}
.rle-listing-address {
  font-size: 0.9rem;
  font-weight: 600;
  color: var(--rle-navy);
  margin-bottom: 4px;
}
.rle-listing-area {
  font-size: 0.78rem;
  color: var(--rle-gold);
  margin-bottom: 18px;
  font-weight: 500;
}
.rle-listing-specs {
  display: flex;
  gap: 20px;
  padding-top: 16px;
  border-top: 1px solid rgba(14,31,51,0.08);
}
.rle-listing-spec {
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: 0.78rem;
  color: var(--rle-slate);
}
.rle-listing-spec-icon { font-size: 0.9rem; }
.rle-listing-type-tag {
  margin-left: auto;
  font-size: 0.68rem;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--rle-silver);
  padding: 3px 8px;
  border: 1px solid rgba(138,149,163,0.3);
  border-radius: 2px;
}

/* ── SERVICES ────────────────────────────────────────────────  */
.rle-services-section { background: var(--rle-cream); }
.rle-services-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 2px;
  background: rgba(193,154,58,0.1);
}
.rle-service-card {
  background: var(--rle-cream);
  padding: 44px 36px;
  position: relative;
  overflow: hidden;
  transition: background 0.3s;
}
.rle-service-card::after {
  content: '';
  position: absolute;
  bottom: 0; left: 0;
  height: 3px; width: 0;
  background: var(--rle-gold);
  transition: width 0.4s ease;
}
.rle-service-card:hover { background: #fdfaf5; }
.rle-service-card:hover::after { width: 100%; }
.rle-service-icon { font-size: 2rem; margin-bottom: 18px; display: block; }
.rle-service-title {
  font-family: var(--rle-serif);
  font-size: 1.15rem;
  font-weight: 700;
  color: var(--rle-navy);
  margin-bottom: 12px;
}
.rle-service-desc {
  font-size: 0.88rem;
  line-height: 1.7;
  color: var(--rle-slate);
}

/* ── AGENTS ──────────────────────────────────────────────────  */
.rle-agents-section { background: var(--rle-navy); }
.rle-agents-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 28px;
}
.rle-agent-card {
  background: rgba(255,255,255,0.04);
  border: 1px solid var(--rle-border);
  padding: 36px 28px;
  text-align: center;
  transition: background 0.3s, border-color 0.3s;
}
.rle-agent-card:hover { background: rgba(255,255,255,0.08); border-color: rgba(193,154,58,0.5); }

/* CSS agent portrait */
.rle-agent-portrait {
  width: 90px; height: 90px;
  border-radius: 50%;
  margin: 0 auto 20px;
  position: relative;
  overflow: hidden;
  border: 2px solid var(--rle-gold);
}
.rle-agt-bg { position: absolute; inset: 0; border-radius: 50%; }
.rle-agt-head {
  position: absolute;
  top: 16px; left: 50%;
  transform: translateX(-50%);
  width: 34px; height: 34px;
  background: #d4a574;
  border-radius: 50%;
}
.rle-agt-hair {
  position: absolute;
  top: 12px; left: 50%;
  transform: translateX(-50%);
  width: 38px; height: 20px;
  border-radius: 50% 50% 0 0;
}
.rle-agt-body {
  position: absolute;
  bottom: 0; left: 50%;
  transform: translateX(-50%);
  width: 80px; height: 44px;
  border-radius: 50% 50% 0 0 / 30% 30% 0 0;
}
.rle-agt-collar {
  position: absolute;
  bottom: 12px; left: 50%;
  transform: translateX(-50%);
  width: 12px; height: 20px;
  background: var(--rle-white);
  clip-path: polygon(0 0, 100% 0, 50% 100%);
}
.rle-agent-name {
  font-family: var(--rle-serif);
  font-size: 1rem;
  font-weight: 700;
  color: var(--rle-white);
  margin-bottom: 6px;
}
.rle-agent-title {
  font-size: 0.72rem;
  font-weight: 600;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--rle-gold);
  margin-bottom: 18px;
}
.rle-agent-stat {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding-top: 16px;
  border-top: 1px solid var(--rle-border);
}
.rle-agent-stat-val {
  font-family: var(--rle-serif);
  font-size: 1.4rem;
  font-weight: 700;
  color: var(--rle-gold);
}
.rle-agent-stat-label {
  font-size: 0.68rem;
  color: var(--rle-silver);
  letter-spacing: 0.05em;
}

/* ── PROCESS ─────────────────────────────────────────────────  */
.rle-process-section { background: var(--rle-white); }
.rle-process-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 48px;
  position: relative;
}
.rle-process-grid::before {
  content: '';
  position: absolute;
  top: 28px; left: 12%; right: 12%;
  height: 1px;
  background: linear-gradient(90deg, transparent, var(--rle-gold), transparent);
  opacity: 0.4;
}
.rle-process-card {
  text-align: center;
  padding: 0 16px;
}
.rle-process-num-wrap {
  width: 56px; height: 56px;
  border-radius: 50%;
  border: 1px solid var(--rle-gold);
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 20px;
  background: var(--rle-white);
  position: relative;
  z-index: 1;
}
.rle-process-icon { font-size: 1.4rem; }
.rle-process-title {
  font-family: var(--rle-serif);
  font-size: 1rem;
  font-weight: 700;
  color: var(--rle-navy);
  margin-bottom: 10px;
}
.rle-process-desc {
  font-size: 0.82rem;
  line-height: 1.7;
  color: var(--rle-slate);
}

/* ── STATS ───────────────────────────────────────────────────  */
.rle-stats-section {
  background: var(--rle-deep);
  padding: 80px 60px;
}
.rle-stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 0;
  border: 1px solid var(--rle-border);
  max-width: 1000px;
  margin: 0 auto;
}
.rle-stat-item {
  padding: 52px 36px;
  text-align: center;
  border-right: 1px solid var(--rle-border);
}
.rle-stat-item:last-child { border-right: none; }
.rle-stat-val {
  font-family: var(--rle-serif);
  font-size: 3.2rem;
  font-weight: 700;
  color: var(--rle-gold);
  display: block;
  line-height: 1;
}
.rle-stat-label {
  font-size: 0.7rem;
  font-weight: 600;
  letter-spacing: 0.15em;
  text-transform: uppercase;
  color: var(--rle-silver);
  margin-top: 10px;
  display: block;
}

/* ── TESTIMONIALS ────────────────────────────────────────────  */
.rle-testi-section { background: var(--rle-cream); }
.rle-testi-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 28px;
}
.rle-testi-card {
  background: var(--rle-white);
  padding: 40px 36px;
  border-left: 3px solid var(--rle-gold);
}
.rle-testi-quote {
  font-size: 2.5rem;
  color: var(--rle-gold);
  opacity: 0.4;
  line-height: 0.6;
  margin-bottom: 16px;
  font-family: var(--rle-serif);
}
.rle-testi-text {
  font-family: var(--rle-serif);
  font-size: 0.95rem;
  font-style: italic;
  line-height: 1.75;
  color: var(--rle-slate);
  margin-bottom: 24px;
}
.rle-testi-author {
  font-size: 0.8rem;
  font-weight: 700;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  color: var(--rle-navy);
}
.rle-testi-prop {
  font-size: 0.72rem;
  color: var(--rle-gold);
  margin-top: 4px;
  font-weight: 500;
}

/* ── AWARDS ──────────────────────────────────────────────────  */
.rle-awards-section { background: var(--rle-white); }
.rle-awards-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 2px;
  background: rgba(193,154,58,0.1);
}
.rle-award-card {
  background: var(--rle-white);
  padding: 32px 36px;
  display: flex;
  align-items: center;
  gap: 20px;
}
.rle-award-icon-wrap {
  width: 52px; height: 52px;
  border-radius: 50%;
  border: 1px solid var(--rle-gold);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.4rem;
  flex-shrink: 0;
}
.rle-award-text {
  font-size: 0.9rem;
  font-weight: 600;
  color: var(--rle-navy);
  line-height: 1.4;
}

/* ── FAQ ─────────────────────────────────────────────────────  */
.rle-faq-section { background: var(--rle-cream); }
.rle-faq-list { display: flex; flex-direction: column; gap: 0; max-width: 780px; }
.rle-faq-item { border-bottom: 1px solid rgba(193,154,58,0.2); }
.rle-faq-trigger {
  width: 100%; background: none; border: none;
  display: flex; align-items: center; justify-content: space-between;
  gap: 16px; padding: 22px 0; cursor: pointer; text-align: left;
}
.rle-faq-q {
  font-family: var(--rle-serif);
  font-size: 1rem;
  font-weight: 700;
  color: var(--rle-navy);
  line-height: 1.35;
}
.rle-faq-icon {
  flex-shrink: 0;
  width: 26px; height: 26px;
  border-radius: 50%;
  border: 1px solid var(--rle-gold);
  display: flex; align-items: center; justify-content: center;
  font-size: 1rem; color: var(--rle-gold);
  transition: transform 0.3s, background 0.3s;
}
.rle-faq-item.open .rle-faq-icon { transform: rotate(45deg); background: var(--rle-gold); color: var(--rle-navy); }
.rle-faq-body { overflow: hidden; max-height: 0; transition: max-height 0.4s ease; }
.rle-faq-body-inner { padding: 0 0 22px; font-size: 0.88rem; line-height: 1.75; color: var(--rle-slate); }

/* ── CONTACT ─────────────────────────────────────────────────  */
.rle-contact-section { background: var(--rle-navy); padding: 100px 60px; }
.rle-contact-inner {
  max-width: 1320px; margin: 0 auto;
  display: grid; grid-template-columns: 1fr 1.5fr; gap: 80px; align-items: start;
}
.rle-contact-title {
  font-family: var(--rle-serif);
  font-size: clamp(1.8rem, 2.8vw, 2.6rem);
  font-weight: 700; color: var(--rle-white); line-height: 1.2; margin-bottom: 20px;
}
.rle-contact-title em { font-style: italic; color: var(--rle-gold); }
.rle-contact-intro { font-size: 0.95rem; line-height: 1.75; color: var(--rle-silver); margin-bottom: 40px; }
.rle-contact-info { display: flex; flex-direction: column; gap: 20px; }
.rle-contact-info-item { display: flex; gap: 14px; align-items: flex-start; }
.rle-contact-info-icon {
  width: 38px; height: 38px; border: 1px solid var(--rle-border);
  display: flex; align-items: center; justify-content: center; font-size: 0.95rem; flex-shrink: 0;
}
.rle-contact-info-text { font-size: 0.84rem; color: var(--rle-silver); line-height: 1.6; }
.rle-contact-info-text strong { display: block; color: var(--rle-white); font-size: 0.72rem; letter-spacing: 0.1em; text-transform: uppercase; margin-bottom: 3px; }

.rle-form { background: rgba(255,255,255,0.05); border: 1px solid var(--rle-border); padding: 48px 44px; }
.rle-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; margin-bottom: 18px; }
.rle-form-group { margin-bottom: 18px; }
.rle-form-label { display: block; font-size: 0.66rem; font-weight: 700; letter-spacing: 0.15em; text-transform: uppercase; color: var(--rle-silver); margin-bottom: 7px; }
.rle-form-control {
  width: 100%; background: rgba(255,255,255,0.06); border: 1px solid rgba(193,154,58,0.2);
  color: var(--rle-white); padding: 13px 16px; font-family: var(--rle-sans); font-size: 0.88rem; outline: none; transition: border-color 0.25s;
}
.rle-form-control:focus { border-color: var(--rle-gold); }
.rle-form-control::placeholder { color: rgba(138,149,163,0.45); }
select.rle-form-control option { background: var(--rle-deep); }
textarea.rle-form-control { min-height: 100px; resize: vertical; }
.rle-form-submit {
  width: 100%; padding: 17px; background: var(--rle-gold); color: var(--rle-navy);
  border: none; font-family: var(--rle-sans); font-size: 0.8rem; font-weight: 700;
  letter-spacing: 0.15em; text-transform: uppercase; cursor: pointer; transition: background 0.25s, transform 0.2s;
  margin-top: 8px;
}
.rle-form-submit:hover { background: var(--rle-gold-lt); transform: translateY(-2px); }
.rle-form-success { display: none; text-align: center; padding: 40px; }
.rle-form-success-icon { font-size: 3rem; display: block; margin-bottom: 16px; }
.rle-form-success p { font-family: var(--rle-serif); font-size: 1.1rem; font-style: italic; color: var(--rle-white); }

@media (max-width: 1100px) {
  .rle-listings-grid { grid-template-columns: repeat(2, 1fr); }
  .rle-services-grid { grid-template-columns: repeat(2, 1fr); }
  .rle-agents-grid { grid-template-columns: repeat(2, 1fr); }
  .rle-process-grid { grid-template-columns: repeat(2, 1fr); }
  .rle-process-grid::before { display: none; }
  .rle-contact-inner { grid-template-columns: 1fr; }
}
@media (max-width: 768px) {
  .rle-hero-content { padding: 0 24px 160px; }
  .rle-listings-grid, .rle-services-grid, .rle-agents-grid, .rle-awards-grid { grid-template-columns: 1fr; }
  .rle-stats-grid { grid-template-columns: repeat(2, 1fr); }
  .rle-testi-grid { grid-template-columns: 1fr; }
  .rle-form-row { grid-template-columns: 1fr; }
  .rle-form { padding: 28px 20px; }
  .rle-hero-strip { flex-wrap: wrap; }
  .rle-strip-item { border-right: none; border-bottom: 1px solid var(--rle-border); flex: 1 1 50%; }
}
</style>

<div class="rle-wrap">

  <!-- ═══ HERO ══════════════════════════════════════════════════ -->
  <section class="rle-hero">
    <div class="rle-hero-sky"></div>

    <!-- Stars -->
    <?php for ($si = 0; $si < 80; $si++):
      $sx = rand(0,100); $sy = rand(0,60);
      $ss = rand(1,3); $so = round(rand(4,9) / 10, 1);
      $dur = rand(2,5); $del = round(rand(0,30)/10,1);
    ?>
    <div class="rle-star" style="left:<?= $sx ?>%;top:<?= $sy ?>%;width:<?= $ss ?>px;height:<?= $ss ?>px;opacity:<?= $so ?>;--tw-dur:<?= $dur ?>s;--tw-delay:<?= $del ?>s;--tw-max:<?= $so ?>;"></div>
    <?php endfor; ?>

    <div class="rle-moon"></div>

    <!-- CSS Skyline -->
    <div class="rle-skyline" aria-hidden="true">
      <?php foreach ($rle_buildings as $bi => $b):
        [$bx, $bw, $bh, $bc, $wcols, $wrows] = $b;
      ?>
      <div class="rle-bld-<?= $bi ?>" style="left:<?= $bx ?>%;width:<?= $bw ?>px;height:<?= $bh ?>px;background:<?= $bc ?>;">
        <?php for ($wr = 0; $wr < $wrows; $wr++): for ($wc = 0; $wc < $wcols; $wc++): ?>
        <div class="rle-win-<?= $wr ?>-<?= $wc ?>" style="
          position:absolute;
          left:<?= 8 + $wc * (($bw - 16) / $wcols) ?>px;
          top:<?= $bh - 20 - $wr * 28 ?>px;
          width:8px;height:12px;
          background:<?= (rand(0,3) > 0) ? 'rgba(255,220,100,0.7)' : 'rgba(100,150,220,0.3)' ?>;
        "></div>
        <?php endfor; endfor; ?>
      </div>
      <?php endforeach; ?>

      <div class="rle-city-glow"></div>

      <!-- Water reflection -->
      <div class="rle-water">
        <?php for ($ri = 0; $ri < 4; $ri++): ?>
        <div class="rle-ripple" style="
          left:<?= rand(10,80) ?>%;
          top:<?= rand(20,60) ?>%;
          width:<?= 40 + $ri*30 ?>px;
          height:<?= 6 + $ri*3 ?>px;
          animation-delay:<?= $ri * 1.1 ?>s;
        "></div>
        <?php endfor; ?>
      </div>
    </div>

    <!-- Hero content -->
    <div class="rle-hero-content">
      <div class="rle-hero-eyebrow">
        <div class="rle-eyebrow-line"></div>
        <span class="rle-eyebrow-text">Langham &amp; Partners Estate Agents</span>
      </div>
      <h1>London's Finest<br><em>Properties,</em><br>Expertly Sold.</h1>
      <p class="rle-hero-sub">Specialists in prime and super-prime London residential sales, lettings and investment for over two decades.</p>
      <div class="rle-hero-ctas">
        <a href="#listings" class="rle-btn-primary">View Listings 🏡</a>
        <a href="#contact" class="rle-btn-outline">Free Valuation</a>
      </div>
      <!-- Search bar -->
      <div class="rle-search-bar">
        <input type="text" class="rle-search-field" placeholder="Area, postcode or property type…">
        <select class="rle-search-select">
          <option>For Sale</option>
          <option>To Let</option>
        </select>
        <button class="rle-search-btn">Search</button>
      </div>
    </div>

    <div class="rle-hero-scroll" aria-hidden="true">
      <div class="rle-hero-scroll-line"></div>
      <span class="rle-hero-scroll-text">Scroll</span>
    </div>

    <!-- Stats strip -->
    <div class="rle-hero-strip">
      <?php foreach ($rle_stats as $st): ?>
      <div class="rle-strip-item">
        <span class="rle-strip-val" data-target="<?= preg_replace('/[^0-9]/', '', $st['val']) ?>" data-suffix="<?= esc_attr(preg_replace('/[0-9]/', '', $st['val']) . $st['suffix']) ?>">
          <?= esc_html($st['val'] . $st['suffix']) ?>
        </span>
        <span class="rle-strip-label"><?= esc_html($st['label']) ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- ═══ FEATURED LISTINGS ═════════════════════════════════════ -->
  <section id="listings" style="background:var(--rle-white);">
    <div class="rle-section">
      <div class="rle-section-label rle-reveal">
        <div class="rle-label-line"></div>
        <span class="rle-label-text">Portfolio</span>
      </div>
      <h2 class="rle-section-title rle-reveal">Featured <em>Properties</em></h2>
      <p class="rle-section-intro rle-reveal">A curated selection from our current portfolio of exceptional homes across London's most sought-after addresses.</p>
      <div class="rle-listings-grid">
        <?php foreach ($rle_listings as $li => $lst):
          $tag_colors = ['Featured'=>'background:#0e1f33;color:#c19a3a','New'=>'background:#2d4a3e;color:#f5f0e8','Exclusive'=>'background:#8b6914;color:#fff','Reduced'=>'background:#8b0000;color:#fff'];
          $tc = $tag_colors[$lst['tag']] ?? 'background:#444;color:#fff';
        ?>
        <div class="rle-listing-card rle-reveal" style="transition-delay:<?= $li * 0.08 ?>s">
          <!-- CSS property art -->
          <div class="rle-listing-art">
            <div class="rle-listing-sky"></div>
            <div class="rle-listing-sun"></div>
            <!-- Ground -->
            <div class="rle-prop-ground"></div>
            <div class="rle-prop-path"></div>
            <!-- Building body -->
            <?php
            $bw2 = 140; $bh2 = 110;
            ?>
            <div class="rle-prop-body" style="width:<?= $bw2 ?>px;height:<?= $bh2 ?>px;background:<?= esc_attr($lst['color']) ?>;">
              <!-- Roof -->
              <div class="rle-prop-roof" style="
                border-left:<?= $bw2/2 ?>px solid transparent;
                border-right:<?= $bw2/2 ?>px solid transparent;
                border-bottom:50px solid <?= esc_attr($lst['color']) ?>;
                filter:brightness(0.7);
              "></div>
              <!-- Windows -->
              <?php for ($wi = 0; $wi < 3; $wi++): ?>
              <div class="rle-prop-win" style="top:20px;left:<?= 16 + $wi * 40 ?>px;width:24px;height:32px;"></div>
              <?php endfor; ?>
              <!-- Door -->
              <div class="rle-prop-door" style="width:28px;height:44px;bottom:0;left:50%;transform:translateX(-50%);"></div>
            </div>
            <!-- Trees -->
            <?php for ($ti = 0; $ti < 2; $ti++): $tx = ($ti === 0) ? 24 : 200; ?>
            <div class="rle-prop-tree-trunk" style="left:<?= $tx ?>px;"></div>
            <div class="rle-prop-tree-top" style="
              bottom:56px;left:<?= $tx - 16 ?>px;
              border-left:20px solid transparent;border-right:20px solid transparent;
              border-bottom:50px solid #3a7a28;
            "></div>
            <div class="rle-prop-tree-top" style="
              bottom:90px;left:<?= $tx - 12 ?>px;
              border-left:16px solid transparent;border-right:16px solid transparent;
              border-bottom:40px solid #4a9a34;
            "></div>
            <?php endfor; ?>
            <!-- Tag -->
            <div class="rle-listing-tag" style="<?= $tc ?>"><?= esc_html($lst['tag']) ?></div>
          </div>
          <div class="rle-listing-body">
            <div class="rle-listing-price"><?= esc_html($lst['price']) ?></div>
            <div class="rle-listing-address"><?= esc_html($lst['address']) ?></div>
            <div class="rle-listing-area"><?= esc_html($lst['area']) ?></div>
            <div class="rle-listing-specs">
              <span class="rle-listing-spec"><span class="rle-listing-spec-icon">🛏</span> <?= $lst['beds'] ?> Beds</span>
              <span class="rle-listing-spec"><span class="rle-listing-spec-icon">🛁</span> <?= $lst['baths'] ?> Baths</span>
              <span class="rle-listing-spec"><span class="rle-listing-spec-icon">📐</span> <?= number_format($lst['sqft']) ?> sq ft</span>
              <span class="rle-listing-type-tag"><?= esc_html($lst['type']) ?></span>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <div style="text-align:center;margin-top:48px;">
        <a href="#" class="rle-btn-primary" style="background:var(--rle-navy);color:var(--rle-gold);">View All Properties →</a>
      </div>
    </div>
  </section>

  <!-- ═══ SERVICES ══════════════════════════════════════════════ -->
  <section class="rle-services-section rle-section-full">
    <div class="rle-section" style="padding-bottom:0">
      <div class="rle-section-label rle-reveal">
        <div class="rle-label-line"></div>
        <span class="rle-label-text">Our Services</span>
      </div>
      <h2 class="rle-section-title rle-reveal">Full-Spectrum <em>Property Services</em></h2>
      <p class="rle-section-intro rle-reveal">From first valuation to final completion, we provide an unmatched level of service across every aspect of the property journey.</p>
    </div>
    <div class="rle-services-grid">
      <?php foreach ($rle_services as $si => $svc): ?>
      <div class="rle-service-card rle-reveal" style="transition-delay:<?= $si * 0.08 ?>s">
        <span class="rle-service-icon"><?= $svc['icon'] ?></span>
        <div class="rle-service-title"><?= esc_html($svc['title']) ?></div>
        <p class="rle-service-desc"><?= esc_html($svc['desc']) ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- ═══ AGENTS ════════════════════════════════════════════════ -->
  <section class="rle-agents-section rle-section-full">
    <div class="rle-section" style="padding-bottom:0">
      <div class="rle-section-label rle-reveal">
        <div class="rle-label-line"></div>
        <span class="rle-label-text" style="color:var(--rle-gold)">Our People</span>
      </div>
      <h2 class="rle-section-title rle-reveal" style="color:var(--rle-white)">Meet Our <em>Expert Agents</em></h2>
      <p class="rle-section-intro rle-reveal" style="color:var(--rle-silver)">Our negotiators combine deep market knowledge with genuine dedication to achieving the best possible result for every client.</p>
    </div>
    <div class="rle-section">
      <div class="rle-agents-grid">
        <?php foreach ($rle_agents as $ai => $agt): ?>
        <div class="rle-agent-card rle-reveal" style="transition-delay:<?= $ai * 0.1 ?>s">
          <div class="rle-agent-portrait">
            <div class="rle-agt-bg" style="background:<?= esc_attr($agt['color']) ?>;"></div>
            <div class="rle-agt-hair" style="background:<?= esc_attr($agt['hair']) ?>;"></div>
            <div class="rle-agt-head"></div>
            <div class="rle-agt-body" style="background:<?= esc_attr($agt['color']) ?>;"></div>
            <div class="rle-agt-collar"></div>
          </div>
          <div class="rle-agent-name"><?= esc_html($agt['name']) ?></div>
          <div class="rle-agent-title"><?= esc_html($agt['title']) ?></div>
          <div class="rle-agent-stat">
            <span class="rle-agent-stat-val"><?= esc_html($agt['sales']) ?></span>
            <span class="rle-agent-stat-label">Sales volume · <?= $agt['listings'] ?> listings</span>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ═══ PROCESS ═══════════════════════════════════════════════ -->
  <section class="rle-process-section rle-section-full">
    <div class="rle-section" style="padding-bottom:0">
      <div class="rle-section-label rle-reveal">
        <div class="rle-label-line"></div>
        <span class="rle-label-text">How We Sell</span>
      </div>
      <h2 class="rle-section-title rle-reveal">The Langham <em>Process</em></h2>
      <p class="rle-section-intro rle-reveal">Our proven four-step process delivers consistently outstanding results, from first instruction through to successful completion.</p>
    </div>
    <div class="rle-section">
      <div class="rle-process-grid">
        <?php foreach ($rle_process as $pi => $proc): ?>
        <div class="rle-process-card rle-reveal" style="transition-delay:<?= $pi * 0.1 ?>s">
          <div class="rle-process-num-wrap">
            <span class="rle-process-icon"><?= $proc['icon'] ?></span>
          </div>
          <div class="rle-process-title"><?= esc_html($proc['title']) ?></div>
          <p class="rle-process-desc"><?= esc_html($proc['desc']) ?></p>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ═══ TESTIMONIALS ══════════════════════════════════════════ -->
  <section class="rle-testi-section rle-section-full">
    <div class="rle-section" style="padding-bottom:0">
      <div class="rle-section-label rle-reveal">
        <div class="rle-label-line"></div>
        <span class="rle-label-text">Client Stories</span>
      </div>
      <h2 class="rle-section-title rle-reveal">Exceptional <em>Results</em></h2>
    </div>
    <div class="rle-section">
      <div class="rle-testi-grid">
        <?php foreach ($rle_testimonials as $ti => $tm): ?>
        <div class="rle-testi-card rle-reveal" style="transition-delay:<?= $ti * 0.1 ?>s">
          <div class="rle-testi-quote">"</div>
          <p class="rle-testi-text"><?= esc_html($tm['quote']) ?></p>
          <div class="rle-testi-author"><?= esc_html($tm['author']) ?></div>
          <div class="rle-testi-prop"><?= esc_html($tm['property']) ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ═══ AWARDS ════════════════════════════════════════════════ -->
  <section class="rle-awards-section rle-section-full">
    <div class="rle-section" style="padding-bottom:0">
      <div class="rle-section-label rle-reveal">
        <div class="rle-label-line"></div>
        <span class="rle-label-text">Recognition</span>
      </div>
      <h2 class="rle-section-title rle-reveal">Industry <em>Recognition</em></h2>
    </div>
    <div class="rle-section">
      <div class="rle-awards-grid">
        <?php foreach ($rle_awards as $ai => $aw): ?>
        <div class="rle-award-card rle-reveal" style="transition-delay:<?= $ai * 0.08 ?>s">
          <div class="rle-award-icon-wrap"><?= $aw['icon'] ?></div>
          <div class="rle-award-text"><?= esc_html($aw['award']) ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ═══ FAQ ═══════════════════════════════════════════════════ -->
  <section class="rle-faq-section rle-section-full">
    <div class="rle-section">
      <div class="rle-section-label rle-reveal">
        <div class="rle-label-line"></div>
        <span class="rle-label-text">Questions</span>
      </div>
      <h2 class="rle-section-title rle-reveal">Frequently Asked <em>Questions</em></h2>
      <div class="rle-faq-list" style="margin-top:40px">
        <?php foreach ($rle_faqs as $fi => $faq): ?>
        <div class="rle-faq-item rle-reveal" style="transition-delay:<?= $fi * 0.07 ?>s">
          <button class="rle-faq-trigger" aria-expanded="false">
            <span class="rle-faq-q"><?= esc_html($faq['q']) ?></span>
            <span class="rle-faq-icon" aria-hidden="true">+</span>
          </button>
          <div class="rle-faq-body">
            <div class="rle-faq-body-inner"><?= esc_html($faq['a']) ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ═══ CONTACT ═══════════════════════════════════════════════ -->
  <section id="contact" class="rle-contact-section">
    <div class="rle-contact-inner">
      <div>
        <div class="rle-section-label rle-reveal" style="margin-bottom:16px">
          <div class="rle-label-line"></div>
          <span class="rle-label-text">Contact Us</span>
        </div>
        <h2 class="rle-contact-title rle-reveal">Book a Free <em>Valuation</em></h2>
        <p class="rle-contact-intro rle-reveal">Our expert valuers will provide an accurate, no-obligation market appraisal with a bespoke marketing strategy tailored to your property and your goals.</p>
        <div class="rle-contact-info rle-reveal">
          <div class="rle-contact-info-item">
            <div class="rle-contact-info-icon">📍</div>
            <div class="rle-contact-info-text">
              <strong>Office</strong>42 Bruton Street, Mayfair, London W1J 6PZ
            </div>
          </div>
          <div class="rle-contact-info-item">
            <div class="rle-contact-info-icon">📞</div>
            <div class="rle-contact-info-text">
              <strong>Telephone</strong>+44 (0)20 7890 1234
            </div>
          </div>
          <div class="rle-contact-info-item">
            <div class="rle-contact-info-icon">✉️</div>
            <div class="rle-contact-info-text">
              <strong>Email</strong>sales@langhampartners.co.uk
            </div>
          </div>
          <div class="rle-contact-info-item">
            <div class="rle-contact-info-icon">🕐</div>
            <div class="rle-contact-info-text">
              <strong>Hours</strong>Mon–Fri: 8am–7pm · Sat: 9am–5pm · Sun: 10am–2pm
            </div>
          </div>
        </div>
      </div>

      <div class="rle-reveal">
        <div class="rle-form" id="rle-form-wrap">
          <form id="rle-form" novalidate>
            <?php wp_nonce_field('tf_rle_valuation', 'tf_rle_nonce'); ?>
            <div class="rle-form-row">
              <div class="rle-form-group">
                <label class="rle-form-label" for="rle-fname">First Name <span style="color:var(--rle-gold)">*</span></label>
                <input type="text" id="rle-fname" name="first_name" class="rle-form-control" placeholder="Victoria" required>
              </div>
              <div class="rle-form-group">
                <label class="rle-form-label" for="rle-lname">Last Name <span style="color:var(--rle-gold)">*</span></label>
                <input type="text" id="rle-lname" name="last_name" class="rle-form-control" placeholder="Langham" required>
              </div>
            </div>
            <div class="rle-form-row">
              <div class="rle-form-group">
                <label class="rle-form-label" for="rle-email">Email <span style="color:var(--rle-gold)">*</span></label>
                <input type="email" id="rle-email" name="email" class="rle-form-control" placeholder="you@email.com" required>
              </div>
              <div class="rle-form-group">
                <label class="rle-form-label" for="rle-phone">Phone</label>
                <input type="tel" id="rle-phone" name="phone" class="rle-form-control" placeholder="+44 7000 000000">
              </div>
            </div>
            <div class="rle-form-group">
              <label class="rle-form-label" for="rle-property-address">Property Address <span style="color:var(--rle-gold)">*</span></label>
              <input type="text" id="rle-property-address" name="address" class="rle-form-control" placeholder="Full property address or postcode" required>
            </div>
            <div class="rle-form-row">
              <div class="rle-form-group">
                <label class="rle-form-label" for="rle-prop-type">Property Type</label>
                <select id="rle-prop-type" name="property_type" class="rle-form-control">
                  <option value="">Select…</option>
                  <option>Apartment / Flat</option>
                  <option>Terraced House</option>
                  <option>Semi-Detached House</option>
                  <option>Detached House</option>
                  <option>Townhouse</option>
                  <option>Penthouse</option>
                  <option>Mews House</option>
                  <option>Other</option>
                </select>
              </div>
              <div class="rle-form-group">
                <label class="rle-form-label" for="rle-service">Service Required</label>
                <select id="rle-service" name="service" class="rle-form-control">
                  <option value="">Select…</option>
                  <option>Sell my property</option>
                  <option>Let my property</option>
                  <option>Buy a property</option>
                  <option>Investment advice</option>
                  <option>Valuation only</option>
                </select>
              </div>
            </div>
            <div class="rle-form-group">
              <label class="rle-form-label" for="rle-notes">Additional Notes</label>
              <textarea id="rle-notes" name="notes" class="rle-form-control" placeholder="Any additional information about your property or requirements…"></textarea>
            </div>
            <button type="submit" class="rle-form-submit">Book Free Valuation 🏡</button>
          </form>
          <div class="rle-form-success" id="rle-form-success">
            <span class="rle-form-success-icon">🏡</span>
            <p>Thank you. One of our expert valuers will be in touch within 24 hours to arrange your appraisal.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

</div><!-- .rle-wrap -->

<script>
(function () {
  'use strict';

  /* ── Scroll Reveal ───────────────────────────────────────── */
  const rObs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('visible'); rObs.unobserve(e.target); }
    });
  }, { threshold: 0.1 });
  document.querySelectorAll('.rle-reveal').forEach(el => rObs.observe(el));

  /* ── Counters ────────────────────────────────────────────── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  const cObs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      cObs.unobserve(e.target);
      const el = e.target;
      const target = parseInt(el.dataset.target, 10);
      const suffix = el.dataset.suffix || '';
      const dur = 1800;
      const t0 = performance.now();
      (function tick(now) {
        const p = Math.min((now - t0) / dur, 1);
        el.textContent = Math.round(easeOut(p) * target) + suffix;
        if (p < 1) requestAnimationFrame(tick);
      })(t0);
    });
  }, { threshold: 0.5 });
  document.querySelectorAll('[data-target]').forEach(el => cObs.observe(el));

  /* ── FAQ Accordion ───────────────────────────────────────── */
  document.querySelectorAll('.rle-faq-trigger').forEach(btn => {
    btn.addEventListener('click', function () {
      const item = this.closest('.rle-faq-item');
      const body = item.querySelector('.rle-faq-body');
      const isOpen = item.classList.contains('open');
      document.querySelectorAll('.rle-faq-item').forEach(i => {
        i.classList.remove('open');
        i.querySelector('.rle-faq-trigger').setAttribute('aria-expanded','false');
        i.querySelector('.rle-faq-body').style.maxHeight = '0';
      });
      if (!isOpen) {
        item.classList.add('open');
        this.setAttribute('aria-expanded','true');
        body.style.maxHeight = body.scrollHeight + 'px';
      }
    });
  });

  /* ── Valuation Form ──────────────────────────────────────── */
  const form = document.getElementById('rle-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      const btn = this.querySelector('.rle-form-submit');
      btn.textContent = 'Sending…'; btn.disabled = true;
      setTimeout(() => {
        form.style.display = 'none';
        document.getElementById('rle-form-success').style.display = 'block';
      }, 900);
    });
  }
})();
</script>

<?php get_footer(); ?>
