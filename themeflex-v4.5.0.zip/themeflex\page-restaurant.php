<?php
/**
 * Template Name: TF — Fine Dining Restaurant
 * Description:   Premium fine dining restaurant homepage template.
 * Namespace:     --rst-*
 * Fonts:         Bodoni Moda + Jost
 * Palette:       obsidian #0c0c0c · parchment #f5f0e8 · gold #c8a050 · burgundy #6b2030 · ivory #fffdf7
 */
defined('ABSPATH') || exit;
/* ── PHP data ──────────────────────────────────────────────────────────── */
srand(crc32(get_the_permalink()));

$candle_flames = [];
for($i=0;$i<30;$i++) $candle_flames[] = ['x'=>rand(2,96),'y'=>rand(5,88),'s'=>lcg_value()*1.5+.5,'op'=>lcg_value()*.3+.06,'dur'=>lcg_value()*3+1.5,'del'=>lcg_value()*5];

$menu_sections = [
  [
    'name'=>'Amuse-Bouche',
    'sub'=>'Complimentary · Two pieces',
    'items'=>[
      ['dish'=>'Oyster, Verjuice Gel, Dill','note'=>'Maldon, East England'],
      ['dish'=>'Wagyu Tartare Cone','note'=>'Truffle, chive, crème fraîche'],
    ]
  ],
  [
    'name'=>'First',
    'sub'=>'Choose one',
    'items'=>[
      ['dish'=>'Hand-Dived Scallop','note'=>'Cauliflower velouté, hazelnut, golden raisin','price'=>''],
      ['dish'=>'Heritage Beetroot','note'=>'Whipped goat\'s curd, walnut crumble, micro herbs','price'=>''],
      ['dish'=>'Foie Gras Royale','note'=>'Brioche, Sauternes jelly, black pepper','price'=>''],
    ]
  ],
  [
    'name'=>'Second',
    'sub'=>'Choose one',
    'items'=>[
      ['dish'=>'Turbot, Beurre Blanc','note'=>'Jersey Royals, samphire, caviar butter','price'=>''],
      ['dish'=>'Breast of Pigeon','note'=>'Confit leg, bitter chocolate, cherry vinegar','price'=>''],
      ['dish'=>'Garden Risotto','note'=>'Spring peas, broad beans, aged Comté, truffle oil','price'=>''],
    ]
  ],
  [
    'name'=>'Main',
    'sub'=>'Choose one',
    'items'=>[
      ['dish'=>'Aged Hereford Fillet','note'=>'72hr short rib, bone marrow, pomme purée','price'=>''],
      ['dish'=>'Halibut en Papillote','note'=>'Crab beurre blanc, asparagus, sea vegetables','price'=>''],
      ['dish'=>'Duck Breast, Two Ways','note'=>'Confit, cherry gastrique, celeriac fondant','price'=>''],
      ['dish'=>'Wild Mushroom Wellington','note'=>'Lentil dahl, parsley oil, shaved truffle','price'=>''],
    ]
  ],
  [
    'name'=>'Dessert',
    'sub'=>'Choose one',
    'items'=>[
      ['dish'=>'Valrhona Chocolate Sphere','note'=>'Warm sauce, salted caramel, hazelnut praline','price'=>''],
      ['dish'=>'Lemon Tart','note'=>'Italian meringue, raspberry gel, limoncello sorbet','price'=>''],
      ['dish'=>'British Cheese Selection','note'=>'Quince, fig bread, candied walnuts (supplement £12)','price'=>''],
    ]
  ],
];

$tasting_menus = [
  ['name'=>'The Seasonal Menu','courses'=>'7 Courses','price'=>'£145','wine'=>'+ £85 wine pairing','desc'=>'A journey through the season — vegetables pulled this week, fish landed yesterday, and protein sourced within forty miles.'],
  ['name'=>'The Chef\'s Table','courses'=>'12 Courses','price'=>'£210','wine'=>'+ £120 wine pairing','desc'=>'Served at the kitchen counter, this extended format invites you into the creative process. Dishes change nightly.'],
  ['name'=>'The Heritage Menu','courses'=>'5 Courses','price'=>'£95','wine'=>'+ £60 wine pairing','desc'=>'A more accessible introduction to our kitchen, built around British classics reinterpreted with modern technique.'],
];

$team = [
  ['name'=>'Theo Harrington','role'=>'Head Chef & Patron','bio'=>'Two Michelin stars. Trained under Pierre Gagnaire. Returns to roots in British produce.','hair'=>'#1a1a1a','skin'=>'#c8956c'],
  ['name'=>'Isabelle Marchand','role'=>'Pastry Chef','bio'=>'Former Ladurée Paris. Winner of UK Pastry Chef of the Year 2023.','hair'=>'#2a1a10','skin'=>'#d4a574'],
  ['name'=>'Kwame Asante','role'=>'Head Sommelier','bio'=>'WSET Diploma. Over 3,000 labels in our cellar. A storyteller with a corkscrew.','hair'=>'#1a0808','skin'=>'#7a4020'],
  ['name'=>'Claire Whitfield','role'=>'Restaurant Director','bio'=>'18 years front of house. Obsessed with the invisible details that make a meal unforgettable.','hair'=>'#3a2010','skin'=>'#d4a574'],
];

$testimonials = [
  ['text'=>'The pigeon course stopped the table. Nobody spoke for a full minute. That has never happened before in thirty years of fine dining.','author'=>'Marcus H.','detail'=>'Chef\'s Table, anniversary dinner'],
  ['text'=>'Kwame\'s wine pairings were as precise and expressive as the food. I\'ve dined at thirty Michelin-starred restaurants. This is in the top three.','author'=>'Amara O.','detail'=>'Seasonal Menu, summer 2025'],
  ['text'=>'We brought clients here for a private dining evening. They cancelled the other two restaurants they\'d planned for the same trip.','author'=>'James A.','detail'=>'Private Dining Room, corporate event'],
];

$private_options = [
  ['name'=>'The Library','capacity'=>'Up to 14','desc'=>'Wood-panelled, book-lined, with an open fireplace. A room that invites long conversation.','icon'=>'📚'],
  ['name'=>'The Wine Cellar','capacity'=>'Up to 22','desc'=>'Vaulted ceilings, candlelight, 3,400 bottles. Extraordinary for launches, proposals, and celebrations.','icon'=>'🍾'],
  ['name'=>'Exclusive Buyout','capacity'=>'Up to 70','desc'=>'The entire restaurant, yours alone. Full kitchen, full team, full cellar — a bespoke evening.','icon'=>'✨'],
];

$awards = [
  ['year'=>'2025','name'=>'Two Michelin Stars','body'=>'Michelin Guide Great Britain & Ireland'],
  ['year'=>'2025','name'=>'Number 12 — UK\'s Best Restaurants','body'=>'National Restaurant Awards'],
  ['year'=>'2024','name'=>'Wine List of the Year','body'=>'AA Hospitality Awards'],
  ['year'=>'2024','name'=>'Chef of the Year — Theo Harrington','body'=>'Caterer & Hotelkeeper'],
  ['year'=>'2023','name'=>'Best Fine Dining, South East','body'=>'Tatler Restaurant Guide'],
  ['year'=>'2023','name'=>'Sustainability Award','body'=>'Sustainable Restaurant Association'],
];

$marquee_items = ['✦ Two Michelin Stars','✦ Open Wednesday–Sunday','✦ Tasting Menus From £95','✦ Private Dining Available','✦ 3,400-Bottle Wine Cellar','✦ Seasonal British Produce','✦ Chef\'s Table 12 Courses','✦ Sunday Lunch From 12:30pm'];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Bodoni+Moda:ital,opsz,wght@0,6..96,400;0,6..96,500;0,6..96,600;1,6..96,400;1,6..96,500&family=Jost:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
/* ── TOKENS ─────────────────────────────────────────────────────────── */
:root{
  --rst-obs:#0c0c0c;
  --rst-dark:#161410;
  --rst-parch:#f5f0e8;
  --rst-gold:#c8a050;
  --rst-gold2:#e0bc70;
  --rst-burg:#6b2030;
  --rst-ivory:#fffdf7;
  --rst-slate:#6a6058;
  --rst-ff-head:'Bodoni Moda',Georgia,serif;
  --rst-ff-body:'Jost',sans-serif;
  --rst-r:2px;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body.rst-page{font-family:var(--rst-ff-body);color:var(--rst-obs);background:var(--rst-ivory);font-size:16px;line-height:1.75;font-weight:300}
.rst-container{max-width:1180px;margin:0 auto;padding:0 24px}
.rst-section{padding:96px 0}
.rst-label{font-family:var(--rst-ff-body);font-size:.68rem;font-weight:600;letter-spacing:.25em;text-transform:uppercase;color:var(--rst-gold);margin-bottom:14px}
.rst-h1{font-family:var(--rst-ff-head);font-size:clamp(3rem,7vw,6rem);line-height:1;font-weight:400}
.rst-h2{font-family:var(--rst-ff-head);font-size:clamp(2rem,4.5vw,3.5rem);line-height:1.1;font-weight:400}
.rst-h3{font-family:var(--rst-ff-head);font-size:1.5rem;font-weight:400}
.rst-lead{font-size:1rem;font-weight:300;line-height:1.85;color:var(--rst-slate)}
.rst-gold-rule{display:flex;align-items:center;gap:16px;margin:20px 0 32px}
.rst-gold-rule-line{flex:1;height:1px;background:linear-gradient(90deg,var(--rst-gold),transparent);max-width:60px}
.rst-gold-rule-ornament{color:var(--rst-gold);font-size:.8rem;letter-spacing:.3em}
.rst-btn{display:inline-block;padding:14px 36px;font-family:var(--rst-ff-body);font-size:.78rem;font-weight:600;letter-spacing:.18em;text-transform:uppercase;text-decoration:none;border:none;cursor:pointer;transition:all .35s}
.rst-btn-gold{background:var(--rst-gold);color:var(--rst-obs)}.rst-btn-gold:hover{background:var(--rst-gold2);transform:translateY(-2px)}
.rst-btn-outline-dark{background:transparent;color:var(--rst-obs);border:1px solid var(--rst-obs)}.rst-btn-outline-dark:hover{background:var(--rst-obs);color:var(--rst-ivory)}
.rst-btn-outline-light{background:transparent;color:var(--rst-parch);border:1px solid rgba(245,240,232,.35)}.rst-btn-outline-light:hover{background:rgba(245,240,232,.1);border-color:var(--rst-gold)}
.rst-reveal{opacity:0;transform:translateY(20px);transition:opacity .75s,transform .75s}
.rst-reveal.visible{opacity:1;transform:none}

/* ── HERO ────────────────────────────────────────────────────────────── */
.rst-hero{position:relative;width:100%;height:100vh;min-height:700px;overflow:hidden;display:flex;align-items:center;background:var(--rst-obs)}
/* Bokeh glow particles (candle bokeh) */
.rst-bokeh{position:absolute;border-radius:50%;filter:blur(var(--rst-blur,6px))}
@keyframes rst-bokeh-pulse{0%,100%{opacity:var(--rst-bop);transform:scale(1)}50%{opacity:calc(var(--rst-bop)*1.8);transform:scale(1.15)}}
/* CSS dining table scene */
.rst-table-scene{position:absolute;right:0;bottom:0;width:58%;height:100%;overflow:hidden}
/* Background wall */
.rst-wall{position:absolute;inset:0;background:linear-gradient(180deg,#0a0806 0%,#14100c 60%,#1a1510 100%)}
/* Wainscoting panel */
.rst-wainscot2{position:absolute;bottom:0;left:0;right:0;height:35%;background:linear-gradient(0deg,#1a1408,#221a0e);border-top:2px solid rgba(200,160,80,.2)}
/* Floor */
.rst-floor2{position:absolute;bottom:0;left:0;right:0;height:20%;background:linear-gradient(0deg,#080604,#120e08)}
/* Wall candle sconces */
.rst-sconce{position:absolute}
.rst-sconce-back{width:24px;height:32px;background:linear-gradient(180deg,rgba(200,160,80,.15),transparent);border-radius:2px}
.rst-sconce-arm{position:absolute;bottom:0;left:50%;transform:translateX(-50%);width:28px;height:3px;background:rgba(180,140,60,.5);border-radius:1px}
.rst-sconce-flame-wrap{position:absolute;bottom:3px;left:50%;transform:translateX(-50%)}
/* Dining table */
.rst-dining-table{position:absolute;bottom:20%;left:50%;transform:translateX(-50%);perspective:400px}
.rst-table-top{width:320px;height:140px;background:linear-gradient(160deg,#2a2018,#1a1408);border-radius:4px;transform:rotateX(20deg);position:relative;border:1px solid rgba(200,160,80,.15)}
.rst-table-cloth{position:absolute;inset:0;background:linear-gradient(160deg,#f8f4ea,#f0ead8);border-radius:3px;opacity:.08}
/* Table settings */
.rst-place-setting{position:absolute;display:flex;flex-direction:column;align-items:center;gap:4px}
/* Plate */
.rst-plate{border-radius:50%;background:radial-gradient(circle at 35% 35%,#f8f6f0,#ede8e0);box-shadow:0 0 0 2px rgba(200,160,80,.3)}
.rst-plate-inner{border-radius:50%;background:transparent;border:1px solid rgba(200,160,80,.25);position:absolute}
/* Wine glass */
.rst-wine-glass{display:flex;flex-direction:column;align-items:center}
.rst-wg-bowl{width:12px;height:14px;border-radius:50% 50% 30% 30%;border:1px solid rgba(200,160,80,.4);background:rgba(180,60,80,.08)}
.rst-wg-stem2{width:1.5px;height:14px;background:rgba(200,160,80,.3)}
.rst-wg-base2{width:10px;height:1.5px;background:rgba(200,160,80,.35);border-radius:1px}
/* Cutlery */
.rst-knife{width:2px;height:22px;background:rgba(200,180,140,.4);border-radius:1px}
.rst-fork{width:3px;height:20px;background:rgba(200,180,140,.35);border-radius:1px;position:relative}
/* Table candle centrepiece */
.rst-centre-candle{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);display:flex;flex-direction:column;align-items:center}
.rst-tc-holder{width:20px;height:20px;background:linear-gradient(180deg,#c8a050,#8a6030);border-radius:50%;box-shadow:0 0 8px rgba(200,160,80,.3)}
.rst-tc-candle{width:8px;height:30px;background:linear-gradient(180deg,#f8f6f2,#e0d8c8);border-radius:1px;margin-top:2px;position:relative}
.rst-tc-wick{width:1.5px;height:4px;background:#1a1208;position:absolute;top:-4px;left:50%;transform:translateX(-50%)}
.rst-tc-flame{width:6px;height:10px;background:linear-gradient(0deg,#ff6600,#ffa000,#ffdd00);border-radius:50% 50% 40% 40%;position:absolute;top:-14px;left:50%;transform:translateX(-50%);animation:rst-flame 1.3s ease-in-out infinite alternate}
@keyframes rst-flame{0%{transform:translateX(-50%) scaleX(1) skewX(-2deg)}100%{transform:translateX(-50%) scaleX(.85) skewX(3deg)}}
.rst-tc-glow{position:absolute;top:-10px;left:50%;transform:translateX(-50%);width:40px;height:30px;background:radial-gradient(ellipse,rgba(255,160,0,.2),transparent 70%);border-radius:50%;pointer-events:none;animation:rst-glow-pulse 2s ease-in-out infinite alternate}
@keyframes rst-glow-pulse{0%{opacity:.6}100%{opacity:1}}
/* Table legs */
.rst-table-leg2{position:absolute;bottom:-40px;width:10px;height:40px;background:linear-gradient(180deg,#2a1e0e,#1a1208);border-radius:2px}
/* Large wall mirror frame */
.rst-mirror{position:absolute;top:5%;left:50%;transform:translateX(-50%);width:160px;height:120px;border:8px solid rgba(200,160,80,.2);border-radius:2px;background:linear-gradient(135deg,rgba(255,255,255,.03),rgba(255,255,255,.01))}
.rst-mirror::before{content:'';position:absolute;inset:6px;border:1px solid rgba(200,160,80,.08)}
/* Candle wall sconces */
.rst-wall-sconce-l,.rst-wall-sconce-r{position:absolute;display:flex;flex-direction:column;align-items:center}
/* Art deco dividers on wall */
.rst-wall-line{position:absolute;background:rgba(200,160,80,.07)}
/* Hero content */
.rst-hero-inner{position:relative;z-index:10;padding:0 80px;max-width:620px;color:var(--rst-parch)}
.rst-hero-stars{font-size:1rem;letter-spacing:.2em;color:var(--rst-gold);margin-bottom:20px}
.rst-hero-h1{font-family:var(--rst-ff-head);font-size:clamp(3rem,6vw,5.5rem);line-height:1;font-weight:400;color:var(--rst-parch);margin-bottom:16px}
.rst-hero-h1 em{font-style:italic;color:var(--rst-gold)}
.rst-hero-sub{font-size:.95rem;font-weight:300;color:rgba(245,240,232,.65);line-height:1.8;margin-bottom:32px;max-width:440px}
.rst-hero-btns{display:flex;gap:14px;flex-wrap:wrap;margin-bottom:48px}
.rst-hero-detail{display:flex;gap:24px;flex-wrap:wrap}
.rst-hero-detail-item{display:flex;flex-direction:column;gap:2px}
.rst-hero-detail-label{font-size:.65rem;font-weight:600;letter-spacing:.2em;text-transform:uppercase;color:var(--rst-gold);opacity:.7}
.rst-hero-detail-value{font-family:var(--rst-ff-head);font-size:.9rem;color:rgba(245,240,232,.8)}
/* Vertical dividers */
.rst-hero-detail-item+.rst-hero-detail-item{padding-left:24px;border-left:1px solid rgba(200,160,80,.2)}

/* ── MARQUEE ─────────────────────────────────────────────────────────── */
.rst-marquee-wrap{background:var(--rst-burg);padding:13px 0;overflow:hidden}
.rst-marquee-track{display:flex;width:max-content;animation:rst-marquee 38s linear infinite}
.rst-marquee-track:hover{animation-play-state:paused}
.rst-marquee-item{white-space:nowrap;padding:0 30px;font-size:.72rem;font-weight:600;letter-spacing:.18em;text-transform:uppercase;color:rgba(245,240,232,.85)}
@keyframes rst-marquee{from{transform:translateX(0)}to{transform:translateX(-50%)}}

/* ── INTRO ───────────────────────────────────────────────────────────── */
.rst-intro{background:var(--rst-ivory)}
.rst-intro-grid{display:grid;grid-template-columns:1fr 1fr;gap:100px;align-items:center}
/* Plating CSS art */
.rst-plate-art{width:100%;aspect-ratio:1;position:relative;border-radius:50%;background:radial-gradient(circle at 35% 35%,#faf8f4,#f0ece4);border:1px solid rgba(200,160,80,.2);box-shadow:0 20px 60px rgba(0,0,0,.08);max-width:380px;margin:0 auto}
.rst-plate-rim{position:absolute;inset:12px;border-radius:50%;border:1.5px solid rgba(200,160,80,.15)}
/* Plated elements */
.rst-plate-sauce{position:absolute;border-radius:50%;background:linear-gradient(135deg,#8a3020,#6b2030);opacity:.7}
.rst-plate-element{position:absolute;border-radius:50%}
.rst-plate-herb{position:absolute;width:4px;height:10px;background:#4a7a3a;border-radius:50% 0 50% 0;opacity:.8}
.rst-plate-reduction{position:absolute;height:2px;background:linear-gradient(90deg,transparent,rgba(100,30,20,.4),transparent);border-radius:2px;transform-origin:center}
/* Cutlery flanking the art plate */
.rst-plate-fork-art{position:absolute;top:50%;right:-60px;transform:translateY(-50%);display:flex;flex-direction:column;align-items:center;gap:0}
.rst-plate-knife-art{position:absolute;top:50%;left:-60px;transform:translateY(-50%)}

/* ── MENU ────────────────────────────────────────────────────────────── */
.rst-menu{background:var(--rst-obs)}
.rst-menu .rst-label,.rst-menu .rst-gold-rule-ornament{color:var(--rst-gold)}
.rst-menu .rst-h2{color:var(--rst-parch)}
.rst-menu-grid{display:grid;grid-template-columns:1fr 1fr;gap:64px;margin-top:52px}
.rst-menu-section{border-top:1px solid rgba(200,160,80,.2);padding-top:24px}
.rst-menu-section-name{font-family:var(--rst-ff-head);font-size:1.3rem;color:var(--rst-gold);margin-bottom:4px;font-style:italic}
.rst-menu-section-sub{font-size:.72rem;font-weight:600;letter-spacing:.15em;text-transform:uppercase;color:rgba(245,240,232,.3);margin-bottom:20px}
.rst-menu-item{padding:12px 0;border-bottom:1px solid rgba(255,255,255,.04);display:flex;justify-content:space-between;align-items:flex-start;gap:20px}
.rst-menu-item-dish{font-family:var(--rst-ff-head);font-size:1rem;color:var(--rst-parch);font-weight:400;margin-bottom:4px}
.rst-menu-item-note{font-size:.8rem;color:rgba(245,240,232,.4);font-weight:300;font-style:italic;line-height:1.5}

/* ── TASTING MENUS ───────────────────────────────────────────────────── */
.rst-tasting{background:var(--rst-parch)}
.rst-tasting-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:2px;margin-top:52px}
.rst-tasting-card{background:var(--rst-ivory);padding:44px 32px;border-top:2px solid var(--rst-gold);position:relative;transition:transform .3s,box-shadow .3s}
.rst-tasting-card:hover{transform:translateY(-4px);box-shadow:0 16px 48px rgba(0,0,0,.1)}
.rst-tasting-name{font-family:var(--rst-ff-head);font-size:1.4rem;color:var(--rst-obs);margin-bottom:6px;font-weight:400}
.rst-tasting-courses{font-size:.72rem;font-weight:600;letter-spacing:.15em;text-transform:uppercase;color:var(--rst-gold);margin-bottom:16px}
.rst-tasting-price{font-family:var(--rst-ff-head);font-size:2.5rem;color:var(--rst-obs);line-height:1;margin-bottom:6px}
.rst-tasting-wine{font-size:.8rem;color:var(--rst-slate);margin-bottom:20px}
.rst-tasting-desc{font-size:.88rem;line-height:1.75;color:var(--rst-slate);font-style:italic;margin-bottom:28px}

/* ── AWARDS ──────────────────────────────────────────────────────────── */
.rst-awards{background:var(--rst-obs)}
.rst-awards .rst-label,.rst-awards .rst-gold-rule-ornament{color:var(--rst-gold)}
.rst-awards .rst-h2{color:var(--rst-parch)}
.rst-awards-list{margin-top:40px}
.rst-award-row2{display:grid;grid-template-columns:72px 1fr auto;gap:16px;align-items:center;padding:18px 0;border-bottom:1px solid rgba(200,160,80,.1);transition:padding-left .3s}
.rst-award-row2:hover{padding-left:10px}
.rst-award-year2{font-family:var(--rst-ff-head);font-size:1rem;color:var(--rst-gold);font-style:italic}
.rst-award-name2{font-size:.92rem;color:var(--rst-parch);font-weight:300}
.rst-award-body2{font-size:.75rem;color:rgba(245,240,232,.35);text-align:right;white-space:nowrap}

/* ── TEAM ────────────────────────────────────────────────────────────── */
.rst-team{background:var(--rst-ivory)}
.rst-team-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:24px;margin-top:52px}
.rst-team-card{text-align:center}
.rst-team-portrait2{aspect-ratio:4/5;position:relative;overflow:hidden;border-radius:var(--rst-r);background:var(--rst-parch);margin-bottom:20px}
/* CSS portrait */
.rst-portrait-scene2{width:100%;height:100%;position:relative}
.rst-portrait-bg2{position:absolute;inset:0;background:linear-gradient(160deg,#f8f4ec 0%,#ede8dc 100%)}
.rst-portrait-table2{position:absolute;bottom:0;left:0;right:0;height:20%;background:linear-gradient(0deg,#c8a070,#d8b080)}
.rst-portrait-jacket2{position:absolute;bottom:18%;left:50%;transform:translateX(-50%);width:68%;height:38%;border-radius:40% 40% 0 0}
.rst-portrait-whites{position:absolute;bottom:18%;left:50%;transform:translateX(-50%);width:64%;height:36%;border-radius:40% 40% 0 0;border:2px solid #e8e4de}
.rst-portrait-neck2{position:absolute;border-radius:50%}
.rst-portrait-head2{position:absolute;border-radius:50% 50% 40% 40%;overflow:hidden}
.rst-portrait-hair2{position:absolute;border-radius:50% 50% 0 0}
/* Team info */
.rst-team-name2{font-family:var(--rst-ff-head);font-size:1.05rem;font-weight:400;color:var(--rst-obs);margin-bottom:4px}
.rst-team-role2{font-size:.72rem;font-weight:600;letter-spacing:.12em;text-transform:uppercase;color:var(--rst-gold);margin-bottom:6px}
.rst-team-bio{font-size:.8rem;color:var(--rst-slate);font-weight:300;line-height:1.6;font-style:italic}

/* ── TESTIMONIALS ────────────────────────────────────────────────────── */
.rst-testimonials{background:var(--rst-dark);padding:80px 0}
.rst-testimonials .rst-label{color:var(--rst-gold)}
.rst-testimonials .rst-h2{color:var(--rst-parch)}
.rst-test-grid2{display:grid;grid-template-columns:repeat(3,1fr);gap:2px;margin-top:48px}
.rst-test-card2{background:rgba(255,255,255,.03);border:1px solid rgba(200,160,80,.08);padding:36px 28px}
.rst-test-star{color:var(--rst-gold);font-size:.7rem;letter-spacing:.1em;margin-bottom:12px}
.rst-test-text2{font-family:var(--rst-ff-head);font-size:.95rem;font-style:italic;color:rgba(245,240,232,.8);line-height:1.8;margin-bottom:24px;font-weight:400}
.rst-test-author2{font-size:.8rem;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:var(--rst-gold)}
.rst-test-detail2{font-size:.75rem;color:rgba(245,240,232,.3);font-weight:300;margin-top:2px}

/* ── PRIVATE DINING ──────────────────────────────────────────────────── */
.rst-private{background:var(--rst-ivory)}
.rst-private-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:52px}
.rst-private-card{background:var(--rst-parch);padding:40px 28px;border-radius:var(--rst-r);text-align:center;border-bottom:2px solid var(--rst-gold);transition:transform .3s,box-shadow .3s}
.rst-private-card:hover{transform:translateY(-4px);box-shadow:0 12px 36px rgba(0,0,0,.06)}
.rst-private-icon{font-size:2rem;margin-bottom:16px;display:block}
.rst-private-name{font-family:var(--rst-ff-head);font-size:1.3rem;margin-bottom:8px;color:var(--rst-obs)}
.rst-private-cap{font-size:.72rem;font-weight:600;letter-spacing:.15em;text-transform:uppercase;color:var(--rst-gold);margin-bottom:14px}
.rst-private-desc{font-size:.88rem;line-height:1.75;color:var(--rst-slate);font-style:italic;margin-bottom:24px}

/* ── RESERVATIONS ────────────────────────────────────────────────────── */
.rst-reservations{background:var(--rst-obs);padding:96px 0}
.rst-reservations .rst-label{color:var(--rst-gold)}
.rst-reservations .rst-h2{color:var(--rst-parch)}
.rst-reservations .rst-lead{color:rgba(245,240,232,.55)}
.rst-res-grid{display:grid;grid-template-columns:1fr 1fr;gap:80px;align-items:start;margin-top:52px}
.rst-res-info{color:rgba(245,240,232,.6)}
.rst-res-info p{font-size:.9rem;line-height:1.8;font-weight:300;margin-bottom:16px}
.rst-res-contact{display:flex;flex-direction:column;gap:14px;margin-top:28px}
.rst-res-row{display:flex;align-items:center;gap:14px;font-size:.9rem;color:rgba(245,240,232,.6);font-weight:300}
.rst-res-icon{width:38px;height:38px;border:1px solid rgba(200,160,80,.25);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.9rem;flex-shrink:0}
.rst-res-form{background:rgba(255,255,255,.04);border:1px solid rgba(200,160,80,.1);padding:40px;border-radius:var(--rst-r)}
.rst-res-form label{display:block;font-size:.68rem;font-weight:600;letter-spacing:.18em;text-transform:uppercase;color:rgba(200,160,80,.6);margin-bottom:6px}
.rst-res-form input,.rst-res-form select{width:100%;padding:12px 14px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);color:rgba(245,240,232,.8);font-family:var(--rst-ff-body);font-size:.88rem;margin-bottom:14px;font-weight:300}
.rst-res-form input::placeholder{color:rgba(255,255,255,.2)}
.rst-res-form select option{background:#1a1410;color:#f5f0e8}
.rst-res-form input:focus,.rst-res-form select:focus{outline:none;border-color:rgba(200,160,80,.4)}
.rst-res-row2{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.rst-res-submit{width:100%;padding:15px;background:var(--rst-gold);color:var(--rst-obs);border:none;font-family:var(--rst-ff-body);font-size:.78rem;font-weight:600;letter-spacing:.18em;text-transform:uppercase;cursor:pointer;transition:background .3s,transform .2s;margin-top:6px}
.rst-res-submit:hover{background:var(--rst-gold2);transform:translateY(-2px)}

/* ── RESPONSIVE ──────────────────────────────────────────────────────── */
@media(max-width:1024px){
  .rst-intro-grid{grid-template-columns:1fr}
  .rst-menu-grid{grid-template-columns:1fr}
  .rst-tasting-grid{grid-template-columns:1fr}
  .rst-team-grid{grid-template-columns:repeat(2,1fr)}
  .rst-test-grid2{grid-template-columns:1fr}
  .rst-private-grid{grid-template-columns:1fr}
  .rst-res-grid{grid-template-columns:1fr}
  .rst-hero-inner{padding:0 32px}
}
@media(max-width:768px){
  .rst-section{padding:64px 0}
  .rst-team-grid{grid-template-columns:repeat(2,1fr)}
  .rst-res-row2{grid-template-columns:1fr}
}
</style>
<?php get_header(); ?>
<div class="rst-page">
>

<?php /* ── HERO ─────────────────────────────────────────────────────── */ ?>
<section class="rst-hero" aria-label="Hero">

  <?php /* Bokeh candle particles */ ?>
  <?php foreach($candle_flames as $i=>$c): $blur=rand(4,12); ?>
  <div class="rst-bokeh" style="left:<?=$c['x']?>%;top:<?=$c['y']?>%;width:<?=round($c['s']*8,1)?>px;height:<?=round($c['s']*8,1)?>px;background:radial-gradient(circle,rgba(255,160,60,<?=round($c['op'],2)?>),transparent 70%);--rst-blur:<?=$blur?>px;--rst-bop:<?=round($c['op'],2)?>;animation:rst-bokeh-pulse <?=round($c['dur'],1)?>s <?=round($c['del'],1)?>s ease-in-out infinite" aria-hidden="true"></div>
  <?php endforeach; ?>

  <?php /* Dining room scene */ ?>
  <div class="rst-table-scene" aria-hidden="true">
    <div class="rst-wall"></div>
    <div class="rst-wainscot2"></div>
    <div class="rst-floor2"></div>

    <?php /* Art deco wall lines */ ?>
    <?php for($wl=0;$wl<3;$wl++): ?>
    <div class="rst-wall-line" style="top:<?=20+$wl*25?>%;left:10%;width:80%;height:1px;opacity:<?=.05+$wl*.02?>"></div>
    <?php endfor; ?>

    <?php /* Large mirror */ ?>
    <div class="rst-mirror"></div>

    <?php /* Wall sconces (left + right of mirror) */ ?>
    <?php $sconce_positions=[['left:15%','top:15%'],['right:15%','top:15%'],['left:8%','top:45%'],['right:8%','top:45%']]; ?>
    <?php foreach($sconce_positions as $sp): ?>
    <div style="position:absolute;<?=$sp[0]?>;<?=$sp[1]?>;display:flex;flex-direction:column;align-items:center">
      <div style="width:16px;height:6px;background:rgba(200,160,80,.25);border-radius:0 0 50% 50%"></div>
      <div style="width:4px;height:20px;background:rgba(200,160,80,.2)"></div>
      <div style="width:8px;height:12px;background:linear-gradient(0deg,rgba(255,120,0,.5),rgba(255,200,0,.3),transparent);border-radius:50% 50% 40% 40%;filter:blur(1px);animation:rst-flame 1.5s ease-in-out infinite alternate"></div>
      <div style="width:24px;height:30px;background:radial-gradient(ellipse at 50% 0%,rgba(255,150,50,.12),transparent 70%);position:absolute;top:28px;left:50%;transform:translateX(-50%);pointer-events:none"></div>
    </div>
    <?php endforeach; ?>

    <?php /* Dining table */ ?>
    <div class="rst-dining-table">
      <div class="rst-table-top">
        <div class="rst-table-cloth"></div>

        <?php /* Centre candle */ ?>
        <div class="rst-centre-candle">
          <div class="rst-tc-glow"></div>
          <div class="rst-tc-flame"></div>
          <div class="rst-tc-wick"></div>
          <div class="rst-tc-candle"></div>
          <div class="rst-tc-holder"></div>
        </div>

        <?php /* Two place settings */ ?>
        <?php $settings=[['left:22%','top:15%'],['right:22%','top:15%']]; ?>
        <?php foreach($settings as $ps): ?>
        <div style="position:absolute;<?=$ps[0]?>;<?=$ps[1]?>;display:flex;align-items:center;gap:5px">
          <div style="width:1.5px;height:22px;background:rgba(200,180,140,.3);border-radius:1px"></div>
          <div style="position:relative">
            <div style="width:22px;height:22px;border-radius:50%;background:radial-gradient(circle at 35% 35%,rgba(255,255,255,.12),rgba(255,255,255,.04));border:1px solid rgba(200,160,80,.2)"></div>
          </div>
          <div style="display:flex;flex-direction:column;align-items:center;gap:3px">
            <div style="width:8px;height:10px;border-radius:40% 40% 20% 20%;border:1px solid rgba(200,160,80,.2);background:rgba(100,30,40,.06)"></div>
            <div style="width:1.5px;height:10px;background:rgba(200,160,80,.2)"></div>
            <div style="width:8px;height:1.5px;background:rgba(200,160,80,.2);border-radius:1px"></div>
          </div>
          <div style="width:1.5px;height:20px;background:rgba(200,180,140,.25);border-radius:1px"></div>
        </div>
        <?php endforeach; ?>

        <?php /* Table legs */ ?>
        <div class="rst-table-leg2" style="bottom:-40px;left:15px"></div>
        <div class="rst-table-leg2" style="bottom:-40px;right:15px"></div>
      </div>
    </div>

    <?php /* Chair silhouettes */ ?>
    <div style="position:absolute;bottom:20%;left:calc(50% - 200px);transform:translateX(-50%);width:60px;height:80px">
      <div style="width:60px;height:50px;background:linear-gradient(160deg,#2a2018,#1a1408);border-radius:3px 3px 0 0"></div>
      <div style="width:68px;height:22px;background:linear-gradient(180deg,#221c0c,#141008);margin-left:-4px;border-radius:0 0 2px 2px"></div>
    </div>
    <div style="position:absolute;bottom:20%;right:calc(50% - 200px);transform:translateX(50%);width:60px;height:80px">
      <div style="width:60px;height:50px;background:linear-gradient(160deg,#2a2018,#1a1408);border-radius:3px 3px 0 0"></div>
      <div style="width:68px;height:22px;background:linear-gradient(180deg,#221c0c,#141008);margin-left:-4px;border-radius:0 0 2px 2px"></div>
    </div>
  </div>

  <?php /* Hero content */ ?>
  <div class="rst-hero-inner">
    <div class="rst-hero-stars">⭐⭐</div>
    <h1 class="rst-hero-h1"><em>Where</em><br>the meal<br>becomes<br><em>memory</em></h1>
    <p class="rst-hero-sub">Two Michelin stars. A wine cellar of 3,400 labels. A kitchen garden. And a team whose singular obsession is your evening.</p>
    <div class="rst-hero-btns">
      <a href="#reservations" class="rst-btn rst-btn-gold">Reserve a Table</a>
      <a href="#menu" class="rst-btn rst-btn-outline-light">View the Menu</a>
    </div>
    <div class="rst-hero-detail">
      <div class="rst-hero-detail-item">
        <span class="rst-hero-detail-label">Open</span>
        <span class="rst-hero-detail-value">Wed – Sun</span>
      </div>
      <div class="rst-hero-detail-item">
        <span class="rst-hero-detail-label">Lunch</span>
        <span class="rst-hero-detail-value">12:30 – 14:00</span>
      </div>
      <div class="rst-hero-detail-item">
        <span class="rst-hero-detail-label">Dinner</span>
        <span class="rst-hero-detail-value">18:30 – 21:00</span>
      </div>
    </div>
  </div>
</section>

<?php /* ── MARQUEE ───────────────────────────────────────────────────── */ ?>
<div class="rst-marquee-wrap" aria-hidden="true">
  <div class="rst-marquee-track">
    <?php $mi=array_merge($marquee_items,$marquee_items); foreach($mi as $m): ?>
    <span class="rst-marquee-item"><?=esc_html($m)?></span>
    <?php endforeach; ?>
  </div>
</div>

<?php /* ── INTRO ────────────────────────────────────────────────────── */ ?>
<section class="rst-section rst-intro" id="about">
  <div class="rst-container">
    <div class="rst-intro-grid">
      <?php /* CSS plate art */ ?>
      <div class="rst-reveal" style="display:flex;justify-content:center">
        <div style="position:relative;max-width:360px;width:100%">
          <div class="rst-plate-art">
            <div class="rst-plate-rim"></div>
            <?php /* Sauce pools */ ?>
            <div class="rst-plate-sauce" style="width:60px;height:40px;top:40%;left:30%;transform:rotate(-15deg)"></div>
            <div class="rst-plate-sauce" style="width:20px;height:14px;top:55%;right:32%;transform:rotate(20deg);background:linear-gradient(135deg,#c4a050,#8a6030)"></div>
            <?php /* Main element */ ?>
            <div class="rst-plate-element" style="width:50px;height:40px;top:35%;left:35%;background:linear-gradient(135deg,#5a3a20,#3a2010)"></div>
            <?php /* Micro herbs */ ?>
            <?php $herb_positions=[['38%','32%','35deg'],['42%','28%','-20deg'],['55%','30%','50deg'],['60%','38%','-10deg'],['35%','52%','60deg']]; ?>
            <?php foreach($herb_positions as $hp): ?>
            <div class="rst-plate-herb" style="left:<?=$hp[0]?>;top:<?=$hp[1]?>;transform:rotate(<?=$hp[2]?>)"></div>
            <?php endforeach; ?>
            <?php /* Reduction lines */ ?>
            <div class="rst-plate-reduction" style="width:80px;top:65%;left:25%;transform:rotate(-5deg)"></div>
            <div class="rst-plate-reduction" style="width:50px;top:70%;left:45%;transform:rotate(8deg)"></div>
            <?php /* Dots */ ?>
            <?php $dot_pos=[['25%','45%',6,'#6b2030'],['72%','42%',5,'#6b2030'],['30%','60%',4,'#c8a050'],['68%','58%',4,'#c8a050'],['50%','68%',5,'#6b2030']]; ?>
            <?php foreach($dot_pos as $d): ?>
            <div style="position:absolute;left:<?=$d[0]?>;top:<?=$d[1]?>;width:<?=$d[2]?>px;height:<?=$d[2]?>px;border-radius:50%;background:<?=$d[3]?>"></div>
            <?php endforeach; ?>
          </div>
          <?php /* Flanking cutlery */ ?>
          <div style="position:absolute;top:50%;right:-48px;transform:translateY(-50%);display:flex;flex-direction:column;align-items:center;gap:2px">
            <?php /* Knife */ ?>
            <div style="width:3px;height:80px;background:linear-gradient(180deg,#b0a888,#8a8060);border-radius:1px"></div>
            <div style="width:5px;height:20px;background:linear-gradient(180deg,#8a8060,#5a5040);border-radius:0 0 2px 2px"></div>
          </div>
          <div style="position:absolute;top:50%;left:-48px;transform:translateY(-50%);display:flex;flex-direction:column;align-items:center;gap:2px">
            <?php /* Fork */ ?>
            <div style="display:flex;gap:2px;margin-bottom:2px">
              <?php for($ft=0;$ft<4;$ft++): ?>
              <div style="width:1.5px;height:20px;background:rgba(160,140,100,.5);border-radius:1px 1px 0 0"></div>
              <?php endfor; ?>
            </div>
            <div style="width:3px;height:70px;background:linear-gradient(180deg,rgba(160,140,100,.5),rgba(100,90,60,.5));border-radius:0 0 2px 2px"></div>
          </div>
          <?php /* Gold shadow beneath plate */ ?>
          <div style="position:absolute;bottom:-20px;left:50%;transform:translateX(-50%);width:80%;height:20px;background:radial-gradient(ellipse,rgba(200,160,80,.1),transparent 70%);border-radius:50%"></div>
        </div>
      </div>
      <div class="rst-reveal">
        <div class="rst-label">Our Philosophy</div>
        <h2 class="rst-h2">The honest pursuit of flavour</h2>
        <div class="rst-gold-rule"><div class="rst-gold-rule-line"></div><span class="rst-gold-rule-ornament">✦</span></div>
        <p class="rst-lead" style="margin-bottom:20px">We built this kitchen on a simple proposition: that exceptional ingredients, treated with precision and respect, need little else. Our menu changes with the harvest, the tides, and the conversation we have with our farmers each week.</p>
        <p class="rst-lead" style="margin-bottom:32px">Chef Harrington sources within forty miles for over 80% of our menu. We keep our own kitchen garden, forage seasonally with a dedicated forager, and work with fewer than a dozen suppliers — all known by name.</p>
        <div style="display:flex;gap:48px">
          <div>
            <div style="font-family:var(--rst-ff-head);font-size:2.8rem;color:var(--rst-gold);font-style:italic" data-target="80" data-suffix="%">80%</div>
            <div style="font-size:.72rem;font-weight:600;letter-spacing:.15em;text-transform:uppercase;color:var(--rst-slate)">Local Sourcing</div>
          </div>
          <div>
            <div style="font-family:var(--rst-ff-head);font-size:2.8rem;color:var(--rst-gold);font-style:italic" data-target="3400" data-suffix="">3,400</div>
            <div style="font-size:.72rem;font-weight:600;letter-spacing:.15em;text-transform:uppercase;color:var(--rst-slate)">Wine Labels</div>
          </div>
          <div>
            <div style="font-family:var(--rst-ff-head);font-size:2.8rem;color:var(--rst-gold);font-style:italic" data-target="12" data-suffix="">12</div>
            <div style="font-size:.72rem;font-weight:600;letter-spacing:.15em;text-transform:uppercase;color:var(--rst-slate)">Suppliers</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php /* ── MENU ─────────────────────────────────────────────────────── */ ?>
<section class="rst-section rst-menu" id="menu">
  <div class="rst-container">
    <div class="rst-reveal" style="text-align:center">
      <div class="rst-label">À La Carte</div>
      <h2 class="rst-h2">This Season's Menu</h2>
      <div class="rst-gold-rule" style="justify-content:center"><div class="rst-gold-rule-line" style="max-width:80px"></div><span class="rst-gold-rule-ornament">✦</span><div class="rst-gold-rule-line" style="max-width:80px;transform:scaleX(-1)"></div></div>
      <p style="font-size:.8rem;color:rgba(245,240,232,.3);font-weight:300;font-style:italic;margin-top:-16px">Menu changes daily. Dishes subject to availability.</p>
    </div>
    <div class="rst-menu-grid">
      <?php foreach($menu_sections as $section): ?>
      <div class="rst-menu-section rst-reveal">
        <div class="rst-menu-section-name"><?=esc_html($section['name'])?></div>
        <div class="rst-menu-section-sub"><?=esc_html($section['sub'])?></div>
        <?php foreach($section['items'] as $item): ?>
        <div class="rst-menu-item">
          <div>
            <div class="rst-menu-item-dish"><?=esc_html($item['dish'])?></div>
            <div class="rst-menu-item-note"><?=esc_html($item['note'])?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center;margin-top:48px" class="rst-reveal">
      <p style="font-size:.82rem;color:rgba(245,240,232,.3);margin-bottom:24px">For dietary requirements and allergen information, please speak with your server or contact us ahead of your visit.</p>
      <a href="#tasting" class="rst-btn rst-btn-gold">View Tasting Menus</a>
    </div>
  </div>
</section>

<?php /* ── TASTING MENUS ─────────────────────────────────────────────── */ ?>
<section class="rst-section rst-tasting" id="tasting">
  <div class="rst-container">
    <div class="rst-reveal" style="text-align:center">
      <div class="rst-label">Tasting Menus</div>
      <h2 class="rst-h2">The Full Experience</h2>
      <div class="rst-gold-rule" style="justify-content:center"><div class="rst-gold-rule-line"></div><span class="rst-gold-rule-ornament">✦</span><div class="rst-gold-rule-line" style="transform:scaleX(-1)"></div></div>
    </div>
    <div class="rst-tasting-grid">
      <?php foreach($tasting_menus as $t): ?>
      <article class="rst-tasting-card rst-reveal">
        <div class="rst-tasting-name"><?=esc_html($t['name'])?></div>
        <div class="rst-tasting-courses"><?=esc_html($t['courses'])?></div>
        <div class="rst-tasting-price"><?=esc_html($t['price'])?></div>
        <div class="rst-tasting-wine"><?=esc_html($t['wine'])?></div>
        <p class="rst-tasting-desc"><?=esc_html($t['desc'])?></p>
        <a href="#reservations" class="rst-btn rst-btn-outline-dark">Reserve</a>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php /* ── AWARDS ───────────────────────────────────────────────────── */ ?>
<section class="rst-section rst-awards" id="awards">
  <div class="rst-container">
    <div class="rst-reveal">
      <div class="rst-label">Recognition</div>
      <h2 class="rst-h2">Honoured for our craft</h2>
      <div class="rst-gold-rule"><div class="rst-gold-rule-line"></div><span class="rst-gold-rule-ornament">✦</span></div>
    </div>
    <div class="rst-awards-list rst-reveal">
      <?php foreach($awards as $aw): ?>
      <div class="rst-award-row2">
        <div class="rst-award-year2"><?=esc_html($aw['year'])?></div>
        <div class="rst-award-name2"><?=esc_html($aw['name'])?></div>
        <div class="rst-award-body2"><?=esc_html($aw['body'])?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php /* ── TEAM ─────────────────────────────────────────────────────── */ ?>
<section class="rst-section rst-team" id="team">
  <div class="rst-container">
    <div class="rst-reveal" style="text-align:center">
      <div class="rst-label">The People</div>
      <h2 class="rst-h2">The makers of the meal</h2>
      <div class="rst-gold-rule" style="justify-content:center"><div class="rst-gold-rule-line"></div><span class="rst-gold-rule-ornament">✦</span><div class="rst-gold-rule-line" style="transform:scaleX(-1)"></div></div>
    </div>
    <div class="rst-team-grid">
      <?php foreach($team as $ti=>$t): ?>
      <article class="rst-team-card rst-reveal">
        <div class="rst-team-portrait2">
          <div class="rst-portrait-scene2">
            <div class="rst-portrait-bg2"></div>
            <div class="rst-portrait-table2"></div>
            <?php /* Chef whites or dark jacket */ ?>
            <?php if($ti===0||$ti===1): /* whites */ ?>
            <div class="rst-portrait-whites" style="background:linear-gradient(160deg,#fff,#f0ece4)"></div>
            <?php if($ti===0): /* chef hat */ ?>
            <div style="position:absolute;bottom:calc(18% + 72%);left:50%;transform:translateX(-50%);width:40px;height:28px;background:#fff;border-radius:40% 40% 0 0;border:1px solid #e0ddd8"></div>
            <?php endif; ?>
            <?php else: ?>
            <div class="rst-portrait-jacket2" style="background:linear-gradient(160deg,<?=$ti===2?'#1a1a2a':'#2a2018'?>,<?=$ti===2?'#0a0a18':'#1a1408'?>)"></div>
            <?php if($ti===2): /* sommelier bowtie */ ?>
            <div style="position:absolute;bottom:calc(18% + 38%);left:50%;transform:translateX(-50%);width:12px;height:6px;background:var(--rst-burg);clip-path:polygon(0 0,50% 50%,0 100%,100% 0,50% 50%,100% 100%)"></div>
            <?php endif; ?>
            <?php endif; ?>
            <?php /* Neck */ ?>
            <div class="rst-portrait-neck2" style="position:absolute;bottom:calc(18% + 35%);left:50%;transform:translateX(-50%);width:24px;height:22px;background:<?=$t['skin']?>;border-radius:50%"></div>
            <?php /* Head */ ?>
            <div class="rst-portrait-head2" style="position:absolute;bottom:calc(18% + 47%);left:50%;transform:translateX(-50%);width:52px;height:58px;background:<?=$t['skin']?>">
              <div class="rst-portrait-hair2" style="position:absolute;top:0;left:0;right:0;height:<?=$ti===1?48:40?>%;background:<?=$t['hair']?>;border-radius:50% 50% 0 0"></div>
              <?php if($ti===1): /* bun */ ?>
              <div style="position:absolute;top:-8px;right:4px;width:14px;height:14px;border-radius:50%;background:<?=$t['hair']?>"></div>
              <?php endif; ?>
              <div style="position:absolute;top:50%;left:50%;transform:translateX(-50%);display:flex;gap:8px">
                <div style="width:5px;height:5px;border-radius:50%;background:#2a1a0a"></div>
                <div style="width:5px;height:5px;border-radius:50%;background:#2a1a0a"></div>
              </div>
              <div style="position:absolute;top:68%;left:50%;transform:translateX(-50%);width:12px;height:6px;border-bottom:1.5px solid rgba(140,90,50,.45);border-radius:0 0 50% 50%"></div>
              <?php if($ti===2): /* glasses */ ?>
              <div style="position:absolute;top:46%;left:50%;transform:translateX(-50%);display:flex;gap:2px">
                <div style="width:14px;height:10px;border:1.5px solid rgba(80,60,30,.4);border-radius:2px"></div>
                <div style="width:3px;height:1px;background:rgba(80,60,30,.3);margin:auto"></div>
                <div style="width:14px;height:10px;border:1.5px solid rgba(80,60,30,.4);border-radius:2px"></div>
              </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <div class="rst-team-name2"><?=esc_html($t['name'])?></div>
        <div class="rst-team-role2"><?=esc_html($t['role'])?></div>
        <p class="rst-team-bio"><?=esc_html($t['bio'])?></p>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php /* ── TESTIMONIALS ──────────────────────────────────────────────── */ ?>
<section class="rst-testimonials">
  <div class="rst-container">
    <div class="rst-reveal" style="text-align:center">
      <div class="rst-label">Guest Memories</div>
      <h2 class="rst-h2">Their words</h2>
      <div class="rst-gold-rule" style="justify-content:center"><div class="rst-gold-rule-line"></div><span class="rst-gold-rule-ornament">✦</span><div class="rst-gold-rule-line" style="transform:scaleX(-1)"></div></div>
    </div>
    <div class="rst-test-grid2">
      <?php foreach($testimonials as $t): ?>
      <blockquote class="rst-test-card2 rst-reveal">
        <div class="rst-test-star">★ ★ ★ ★ ★</div>
        <p class="rst-test-text2"><?=esc_html($t['text'])?></p>
        <footer>
          <div class="rst-test-author2"><?=esc_html($t['author'])?></div>
          <div class="rst-test-detail2"><?=esc_html($t['detail'])?></div>
        </footer>
      </blockquote>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php /* ── PRIVATE DINING ────────────────────────────────────────────── */ ?>
<section class="rst-section rst-private" id="private">
  <div class="rst-container">
    <div class="rst-reveal" style="text-align:center">
      <div class="rst-label">Private Dining</div>
      <h2 class="rst-h2">An evening entirely your own</h2>
      <div class="rst-gold-rule" style="justify-content:center"><div class="rst-gold-rule-line"></div><span class="rst-gold-rule-ornament">✦</span><div class="rst-gold-rule-line" style="transform:scaleX(-1)"></div></div>
    </div>
    <div class="rst-private-grid">
      <?php foreach($private_options as $p): ?>
      <div class="rst-private-card rst-reveal">
        <span class="rst-private-icon"><?=esc_html($p['icon'])?></span>
        <h3 class="rst-private-name rst-h3"><?=esc_html($p['name'])?></h3>
        <div class="rst-private-cap"><?=esc_html($p['capacity'])?></div>
        <p class="rst-private-desc"><?=esc_html($p['desc'])?></p>
        <a href="#reservations" class="rst-btn rst-btn-outline-dark" style="font-size:.72rem;padding:12px 28px">Enquire</a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php /* ── RESERVATIONS ──────────────────────────────────────────────── */ ?>
<section class="rst-reservations" id="reservations">
  <div class="rst-container">
    <div class="rst-reveal" style="text-align:center">
      <div class="rst-label">Reservations</div>
      <h2 class="rst-h2">Reserve your table</h2>
      <div class="rst-gold-rule" style="justify-content:center"><div class="rst-gold-rule-line"></div><span class="rst-gold-rule-ornament">✦</span><div class="rst-gold-rule-line" style="transform:scaleX(-1)"></div></div>
    </div>
    <div class="rst-res-grid">
      <div class="rst-res-info rst-reveal">
        <p>We recommend booking at least three weeks in advance for dinner service, and six weeks for the Chef's Table. Same-week availability may be checked by telephone.</p>
        <p>Deposits of £50 per person are taken at the time of booking and deducted from the final bill. Cancellations within 48 hours forfeit the deposit.</p>
        <div class="rst-res-contact">
          <div class="rst-res-row"><div class="rst-res-icon">📞</div><span>+44 20 7890 1234</span></div>
          <div class="rst-res-row"><div class="rst-res-icon">✉️</div><span>reservations@restaurant.co.uk</span></div>
          <div class="rst-res-row"><div class="rst-res-icon">🕐</div><span>Wed–Fri 12–9pm · Sat–Sun 10am–9pm</span></div>
          <div class="rst-res-row"><div class="rst-res-icon">📍</div><span>14 Blenheim Road, London SW1A 2AB</span></div>
        </div>
      </div>
      <div class="rst-res-form rst-reveal">
        <form id="rst-res-form" novalidate>
          <?php wp_nonce_field('tf_rst_reservation','tf_rst_nonce'); ?>
          <div class="rst-res-row2">
            <div><label for="rst-fname">First Name</label><input type="text" id="rst-fname" name="first_name" placeholder="Theo" required></div>
            <div><label for="rst-lname">Last Name</label><input type="text" id="rst-lname" name="last_name" placeholder="Harrington" required></div>
          </div>
          <div><label for="rst-email">Email</label><input type="email" id="rst-email" name="email" placeholder="theo@example.com" required></div>
          <div><label for="rst-phone">Telephone</label><input type="tel" id="rst-phone" name="phone" placeholder="+44 …"></div>
          <div class="rst-res-row2">
            <div><label for="rst-date">Date</label><input type="date" id="rst-date" name="date" required></div>
            <div>
              <label for="rst-time">Service</label>
              <select id="rst-time" name="time">
                <option value="lunch">Lunch — 12:30pm</option>
                <option value="dinner" selected>Dinner — 6:30pm or 8:30pm</option>
              </select>
            </div>
          </div>
          <div class="rst-res-row2">
            <div>
              <label for="rst-covers">Covers</label>
              <select id="rst-covers" name="covers">
                <?php for($n=1;$n<=10;$n++): ?>
                <option value="<?=$n?>"<?=$n===2?' selected':''?>><?=$n?> <?=$n===1?'guest':'guests'?></option>
                <?php endfor; ?>
              </select>
            </div>
            <div>
              <label for="rst-menu">Menu</label>
              <select id="rst-menu" name="menu">
                <option value="ala">À La Carte</option>
                <option value="seasonal">The Seasonal (7 courses)</option>
                <option value="chefs">Chef's Table (12 courses)</option>
                <option value="heritage">The Heritage (5 courses)</option>
              </select>
            </div>
          </div>
          <div><label for="rst-occasion">Occasion</label>
          <select id="rst-occasion" name="occasion">
            <option value="">No special occasion</option>
            <option value="birthday">Birthday</option>
            <option value="anniversary">Anniversary</option>
            <option value="proposal">Proposal</option>
            <option value="business">Business Dinner</option>
            <option value="private">Private Dining Enquiry</option>
          </select></div>
          <button type="submit" class="rst-res-submit">Request Reservation</button>
        </form>
        <p id="rst-form-msg" style="display:none;text-align:center;margin-top:14px;font-size:.85rem;color:var(--rst-gold)"></p>
      </div>
    </div>
  </div>
</section>

<script>
(function(){
  /* ── Scroll reveal ─────────────────────────────────────────────── */
  const reveals=document.querySelectorAll('.rst-reveal');
  if('IntersectionObserver' in window){
    const obs=new IntersectionObserver(entries=>{
      entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');obs.unobserve(e.target)}});
    },{threshold:.1});
    reveals.forEach(el=>obs.observe(el));
  } else {reveals.forEach(el=>el.classList.add('visible'));}

  /* ── Counters ──────────────────────────────────────────────────── */
  const easeOut=t=>1-Math.pow(1-t,3);
  document.querySelectorAll('[data-target]').forEach(el=>{
    const o=new IntersectionObserver(entries=>{
      if(!entries[0].isIntersecting) return;
      const target=parseInt(el.dataset.target,10);
      const suffix=el.dataset.suffix||'';
      const dur=1600;const start=performance.now();
      function tick(now){
        const t=Math.min((now-start)/dur,1);
        const v=Math.round(easeOut(t)*target);
        el.textContent=(target>=1000?v.toLocaleString():v)+suffix;
        if(t<1) requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
      o.unobserve(el);
    },{threshold:.4});
    o.observe(el);
  });

  /* ── Date min ──────────────────────────────────────────────────── */
  const di=document.getElementById('rst-date');
  if(di) di.min=new Date().toISOString().split('T')[0];

  /* ── Form ──────────────────────────────────────────────────────── */
  const form=document.getElementById('rst-res-form');
  if(form){
    form.addEventListener('submit',e=>{
      e.preventDefault();
      const btn=form.querySelector('.rst-res-submit');
      const msg=document.getElementById('rst-form-msg');
      btn.textContent='Sending…';btn.disabled=true;
      setTimeout(()=>{
        btn.textContent='Reservation Requested ✓';
        btn.style.background='#4a7a4a';
        msg.textContent='Thank you. We\'ll confirm your reservation within 24 hours via email.';
        msg.style.display='block';
      },900);
    });
  }
})();
</script>
</div><!-- .rst-page -->
<?php get_footer(); ?>
