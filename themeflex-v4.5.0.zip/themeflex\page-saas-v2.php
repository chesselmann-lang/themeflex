<?php
/**
 * Template Name: SaaS Landing Page v2
 * Template Post Type: page
 *
 * World-class SaaS product landing page — Linear / Vercel / Stripe quality.
 * Full-screen hero with animated orbs + CSS device mockup, bento feature grid,
 * 3-step how-it-works, 3-tier pricing with toggle, testimonial masonry,
 * integration logos, FAQ accordion, final CTA. Zero Elementor dependency.
 * Vanilla CSS + minimal inline JS. Dark-first, fully responsive.
 *
 * @package ThemeFlex
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
get_header(); ?>

<main id="tf-saas-main" class="tf-sv2" aria-label="<?php esc_attr_e( 'SaaS Product Landing Page', 'themeflex' ); ?>">
<style>
/* ══════════════════════════════════════════════════════════════════════════
   ThemeFlex — SaaS Landing Page v2
   Dark-first premium template. Variables shadow global theme vars.
   ══════════════════════════════════════════════════════════════════════════ */

.tf-sv2 {
  --tc:       #ff5e2e;
  --tc2:      #00d4ff;
  --tc3:      #a855f7;
  --tc4:      #22d3ee;
  --tc5:      #10b981;
  --bg:       #06021d;
  --bg2:      #0d1526;
  --bg3:      #111827;
  --border:   rgba(255,255,255,.07);
  --title:    #f1f5f9;
  --txt:      #94a3b8;
  --meta:     #64748b;
  --r:        16px;
  --r-sm:     10px;
  font-family: 'Inter Tight', system-ui, -apple-system, sans-serif;
  background: var(--bg);
  color: var(--txt);
  overflow-x: hidden;
  line-height: 1.6;
}
.tf-sv2 *, .tf-sv2 *::before, .tf-sv2 *::after { box-sizing: border-box; margin: 0; padding: 0; }
.tf-sv2 a { text-decoration: none; color: inherit; }

/* ── Layout helpers ───────────────────────────────────────────────────── */
.tf-sv2-wrap { max-width: 1180px; margin: 0 auto; padding: 0 24px; }
.tf-sv2-section { padding: 100px 0; }

.tf-sv2-label {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.22);
  color: var(--tc); font-size: .68rem; font-weight: 800;
  letter-spacing: .16em; text-transform: uppercase;
  padding: 6px 18px; border-radius: 100px; margin-bottom: 18px;
}
.tf-sv2-head { text-align: center; margin-bottom: 60px; }
.tf-sv2-head h2 {
  font-size: clamp(1.9rem, 3.8vw, 3rem); font-weight: 900;
  color: var(--title); line-height: 1.1; letter-spacing: -.4px; margin: 0 0 16px;
}
.tf-sv2-head p {
  font-size: 1.08rem; color: var(--txt); max-width: 560px;
  margin: 0 auto; line-height: 1.75;
}
.tf-sv2-gradient {
  background: linear-gradient(135deg, #ff5e2e 0%, #ff8c5a 40%, #a855f7 100%);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  background-clip: text;
}
.tf-sv2-gradient-cyan {
  background: linear-gradient(135deg, #00d4ff 0%, #a855f7 100%);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  background-clip: text;
}

/* ══════════════════════════════════════════════════════════════════════════
   §1 — HERO
   ══════════════════════════════════════════════════════════════════════════ */
.tf-sv2-hero {
  position: relative; overflow: hidden;
  min-height: 100vh; display: flex; flex-direction: column;
  align-items: center; justify-content: center;
  background: #050010;
  padding: 120px 24px 80px;
}

/* Animated gradient grid background */
.tf-sv2-hero::before {
  content: '';
  position: absolute; inset: 0; pointer-events: none;
  background-image:
    linear-gradient(rgba(255,255,255,.04) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255,255,255,.04) 1px, transparent 1px);
  background-size: 56px 56px;
  mask-image: radial-gradient(ellipse 80% 80% at 50% 50%, #000 40%, transparent 100%);
}

/* Animated radial orbs */
.tf-sv2-orb {
  position: absolute; border-radius: 50%;
  filter: blur(80px); pointer-events: none;
  animation: tf-sv2-orb-drift 8s ease-in-out infinite alternate;
}
.tf-sv2-orb-1 {
  width: 600px; height: 600px;
  background: radial-gradient(circle, rgba(168,85,247,.28) 0%, transparent 70%);
  top: -150px; left: -100px;
  animation-delay: 0s; animation-duration: 10s;
}
.tf-sv2-orb-2 {
  width: 500px; height: 500px;
  background: radial-gradient(circle, rgba(0,212,255,.2) 0%, transparent 70%);
  top: 10%; right: -80px;
  animation-delay: -3s; animation-duration: 12s;
}
.tf-sv2-orb-3 {
  width: 400px; height: 400px;
  background: radial-gradient(circle, rgba(255,94,46,.2) 0%, transparent 70%);
  bottom: 5%; left: 30%;
  animation-delay: -6s; animation-duration: 9s;
}
@keyframes tf-sv2-orb-drift {
  0%   { transform: translate(0, 0) scale(1); }
  33%  { transform: translate(30px, -25px) scale(1.05); }
  66%  { transform: translate(-20px, 20px) scale(.97); }
  100% { transform: translate(15px, -10px) scale(1.03); }
}

/* Hero content */
.tf-sv2-hero-inner {
  position: relative; z-index: 2;
  display: flex; flex-direction: column;
  align-items: center; text-align: center;
  max-width: 820px; width: 100%;
}

.tf-sv2-hero-badge {
  display: inline-flex; align-items: center; gap: 10px;
  background: rgba(168,85,247,.12); border: 1px solid rgba(168,85,247,.3);
  color: #c084fc; font-size: .8rem; font-weight: 600;
  padding: 7px 18px; border-radius: 100px; margin-bottom: 36px;
  cursor: pointer; transition: background .2s, border-color .2s;
}
.tf-sv2-hero-badge:hover { background: rgba(168,85,247,.22); border-color: rgba(168,85,247,.5); }
.tf-sv2-hero-badge-dot {
  width: 6px; height: 6px; border-radius: 50%;
  background: #a855f7;
  box-shadow: 0 0 8px #a855f7;
  animation: tf-sv2-pulse 2s ease-in-out infinite;
}
@keyframes tf-sv2-pulse {
  0%, 100% { opacity: 1; transform: scale(1); }
  50%       { opacity: .6; transform: scale(.8); }
}
.tf-sv2-badge-arrow { font-size: .75rem; opacity: .7; }

.tf-sv2-hero-h1 {
  font-size: clamp(2.6rem, 6vw, 4.8rem); font-weight: 900;
  color: var(--title); line-height: 1.05; letter-spacing: -.8px;
  margin-bottom: 24px;
}
.tf-sv2-hero-sub {
  font-size: 1.15rem; color: var(--txt); line-height: 1.8;
  max-width: 580px; margin: 0 auto 40px;
}
.tf-sv2-hero-ctas {
  display: flex; gap: 14px; flex-wrap: wrap;
  justify-content: center; margin-bottom: 18px;
}
.tf-sv2-btn-primary {
  display: inline-flex; align-items: center; gap: 10px;
  padding: 16px 36px; background: var(--tc); color: #fff;
  border-radius: 14px; font-size: 1rem; font-weight: 700;
  letter-spacing: .02em;
  box-shadow: 0 10px 32px rgba(255,94,46,.4), 0 2px 8px rgba(255,94,46,.2);
  transition: transform .2s, box-shadow .2s;
}
.tf-sv2-btn-primary:hover { transform: translateY(-2px); box-shadow: 0 16px 40px rgba(255,94,46,.5); }
.tf-sv2-btn-primary svg { width: 18px; height: 18px; }
.tf-sv2-btn-ghost {
  display: inline-flex; align-items: center; gap: 10px;
  padding: 15px 30px;
  background: rgba(255,255,255,.06); color: var(--title);
  border-radius: 14px; font-size: 1rem; font-weight: 600;
  border: 1px solid rgba(255,255,255,.12);
  transition: background .2s, border-color .2s;
}
.tf-sv2-btn-ghost:hover { background: rgba(255,255,255,.1); border-color: rgba(255,255,255,.2); }
.tf-sv2-btn-ghost svg { width: 18px; height: 18px; }

.tf-sv2-hero-disclaimer {
  font-size: .78rem; color: var(--meta); letter-spacing: .02em;
  margin-bottom: 64px;
}
.tf-sv2-hero-disclaimer span { margin: 0 8px; opacity: .4; }

/* CSS device mockup */
.tf-sv2-mockup-wrap {
  position: relative; z-index: 2;
  width: 100%; max-width: 860px;
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(255,255,255,.1);
  border-radius: 14px;
  box-shadow:
    0 40px 120px rgba(0,0,0,.7),
    0 0 0 1px rgba(255,255,255,.06),
    inset 0 1px 0 rgba(255,255,255,.08);
  overflow: hidden;
}

/* Title bar */
.tf-sv2-mock-titlebar {
  display: flex; align-items: center; gap: 12px;
  padding: 12px 18px;
  background: rgba(255,255,255,.04);
  border-bottom: 1px solid rgba(255,255,255,.07);
}
.tf-sv2-mock-dots { display: flex; gap: 6px; }
.tf-sv2-mock-dots span {
  width: 12px; height: 12px; border-radius: 50%;
}
.tf-sv2-mock-dots span:nth-child(1) { background: #ff5f57; }
.tf-sv2-mock-dots span:nth-child(2) { background: #ffbd2e; }
.tf-sv2-mock-dots span:nth-child(3) { background: #28c840; }
.tf-sv2-mock-title-text {
  flex: 1; text-align: center;
  font-size: .72rem; color: var(--meta); font-weight: 500;
  background: rgba(255,255,255,.05);
  border: 1px solid rgba(255,255,255,.07);
  border-radius: 6px; padding: 4px 12px;
  max-width: 240px; margin: 0 auto;
}

/* App body */
.tf-sv2-mock-body {
  display: grid; grid-template-columns: 200px 1fr;
  min-height: 360px;
}

/* Sidebar */
.tf-sv2-mock-sidebar {
  background: rgba(255,255,255,.03);
  border-right: 1px solid rgba(255,255,255,.06);
  padding: 18px 14px;
}
.tf-sv2-mock-sb-logo {
  display: flex; align-items: center; gap: 8px;
  margin-bottom: 24px; padding-bottom: 14px;
  border-bottom: 1px solid rgba(255,255,255,.06);
}
.tf-sv2-mock-sb-logo-icon {
  width: 26px; height: 26px; border-radius: 6px;
  background: linear-gradient(135deg, #ff5e2e, #a855f7);
}
.tf-sv2-mock-sb-logo-text {
  font-size: .75rem; font-weight: 700; color: var(--title);
}
.tf-sv2-mock-nav-item {
  display: flex; align-items: center; gap: 9px;
  padding: 8px 10px; border-radius: 8px;
  font-size: .72rem; color: var(--txt); margin-bottom: 2px;
  cursor: default;
}
.tf-sv2-mock-nav-item.active {
  background: rgba(255,94,46,.12); color: var(--tc);
}
.tf-sv2-mock-nav-dot {
  width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0;
}

/* Main content area */
.tf-sv2-mock-main { padding: 20px; overflow: hidden; }
.tf-sv2-mock-main-header {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 18px;
}
.tf-sv2-mock-main-title {
  font-size: .85rem; font-weight: 700; color: var(--title);
}
.tf-sv2-mock-main-actions { display: flex; gap: 8px; }
.tf-sv2-mock-chip {
  padding: 4px 12px; border-radius: 6px; font-size: .65rem; font-weight: 600;
  background: rgba(255,94,46,.15); color: var(--tc);
  border: 1px solid rgba(255,94,46,.25);
}
.tf-sv2-mock-chip.alt {
  background: rgba(255,255,255,.06); color: var(--txt);
  border-color: rgba(255,255,255,.08);
}

/* Metric cards row */
.tf-sv2-mock-metrics {
  display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px;
  margin-bottom: 18px;
}
.tf-sv2-mock-metric {
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(255,255,255,.07);
  border-radius: 10px; padding: 12px 14px;
}
.tf-sv2-mock-metric-label {
  font-size: .6rem; color: var(--meta); margin-bottom: 6px; text-transform: uppercase; letter-spacing: .08em;
}
.tf-sv2-mock-metric-val {
  font-size: .95rem; font-weight: 800; color: var(--title);
  display: flex; align-items: baseline; gap: 6px;
}
.tf-sv2-mock-metric-val span {
  font-size: .6rem; font-weight: 600; padding: 2px 6px;
  border-radius: 4px;
}
.tf-sv2-mock-metric-val span.up { background: rgba(16,185,129,.15); color: #10b981; }
.tf-sv2-mock-metric-val span.dn { background: rgba(239,68,68,.12); color: #f87171; }

/* Chart area */
.tf-sv2-mock-charts { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
.tf-sv2-mock-chart-box {
  background: rgba(255,255,255,.03);
  border: 1px solid rgba(255,255,255,.06);
  border-radius: 10px; padding: 12px;
}
.tf-sv2-mock-chart-title { font-size: .65rem; color: var(--meta); margin-bottom: 10px; text-transform: uppercase; letter-spacing: .07em; }
.tf-sv2-mock-bars {
  display: flex; align-items: flex-end; gap: 5px; height: 60px;
}
.tf-sv2-mock-bar {
  flex: 1; border-radius: 3px 3px 0 0;
  background: linear-gradient(180deg, rgba(255,94,46,.8) 0%, rgba(255,94,46,.3) 100%);
  min-height: 8px;
}
.tf-sv2-mock-bar.alt {
  background: linear-gradient(180deg, rgba(168,85,247,.8) 0%, rgba(168,85,247,.3) 100%);
}
.tf-sv2-mock-activity { }
.tf-sv2-mock-activity-item {
  display: flex; align-items: center; gap: 8px;
  padding: 6px 0; border-bottom: 1px solid rgba(255,255,255,.04);
  font-size: .62rem; color: var(--txt);
}
.tf-sv2-mock-activity-item:last-child { border-bottom: none; }
.tf-sv2-mock-avatar-xs {
  width: 18px; height: 18px; border-radius: 50%; flex-shrink: 0;
  display: flex; align-items: center; justify-content: center;
  font-size: .45rem; font-weight: 700; color: #fff;
}

/* ══════════════════════════════════════════════════════════════════════════
   §2 — SOCIAL PROOF BAR
   ══════════════════════════════════════════════════════════════════════════ */
.tf-sv2-proof {
  border-top: 1px solid var(--border);
  border-bottom: 1px solid var(--border);
  padding: 36px 0;
  background: var(--bg2);
}
.tf-sv2-proof-inner {
  display: flex; align-items: center; justify-content: center;
  gap: 40px; flex-wrap: wrap;
}
.tf-sv2-proof-label {
  font-size: .75rem; color: var(--meta); font-weight: 600;
  letter-spacing: .06em; text-transform: uppercase;
  white-space: nowrap;
}
.tf-sv2-proof-divider {
  width: 1px; height: 28px;
  background: var(--border);
}
.tf-sv2-proof-logos { display: flex; gap: 16px; flex-wrap: wrap; align-items: center; }
.tf-sv2-proof-chip {
  padding: 8px 20px;
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(255,255,255,.08);
  border-radius: 8px;
  font-size: .82rem; font-weight: 700; color: var(--title);
  letter-spacing: .03em;
  transition: background .2s, border-color .2s;
}
.tf-sv2-proof-chip:hover { background: rgba(255,255,255,.08); border-color: rgba(255,255,255,.14); }

/* ══════════════════════════════════════════════════════════════════════════
   §3 — BENTO FEATURE GRID
   ══════════════════════════════════════════════════════════════════════════ */
.tf-sv2-bento-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-template-rows: auto auto;
  gap: 16px;
}
.tf-sv2-bento-card {
  background: var(--bg2);
  border: 1px solid var(--border);
  border-radius: 20px; padding: 32px;
  position: relative; overflow: hidden;
  transition: border-color .3s, box-shadow .3s;
}
.tf-sv2-bento-card::before {
  content: ''; position: absolute;
  inset: 0; border-radius: 20px; opacity: 0;
  transition: opacity .3s;
  pointer-events: none;
}
.tf-sv2-bento-card:hover::before { opacity: 1; }
.tf-sv2-bento-card:hover { box-shadow: 0 8px 40px rgba(0,0,0,.4); }

/* Individual card glow colors */
.tf-sv2-bc-collab::before  { background: radial-gradient(circle at 0% 100%, rgba(168,85,247,.12) 0%, transparent 60%); }
.tf-sv2-bc-collab:hover  { border-color: rgba(168,85,247,.4); box-shadow: 0 8px 40px rgba(168,85,247,.12); }
.tf-sv2-bc-deploy::before  { background: radial-gradient(circle at 100% 0%, rgba(16,185,129,.1) 0%, transparent 60%); }
.tf-sv2-bc-deploy:hover  { border-color: rgba(16,185,129,.4); box-shadow: 0 8px 40px rgba(16,185,129,.1); }
.tf-sv2-bc-analytics::before { background: radial-gradient(circle at 0% 0%, rgba(0,212,255,.1) 0%, transparent 60%); }
.tf-sv2-bc-analytics:hover { border-color: rgba(0,212,255,.4); box-shadow: 0 8px 40px rgba(0,212,255,.1); }
.tf-sv2-bc-uptime::before  { background: radial-gradient(circle at 100% 100%, rgba(255,94,46,.12) 0%, transparent 60%); }
.tf-sv2-bc-uptime:hover  { border-color: rgba(255,94,46,.4); box-shadow: 0 8px 40px rgba(255,94,46,.12); }
.tf-sv2-bc-cdn::before    { background: radial-gradient(circle at 50% 50%, rgba(34,211,238,.1) 0%, transparent 60%); }
.tf-sv2-bc-cdn:hover    { border-color: rgba(34,211,238,.4); box-shadow: 0 8px 40px rgba(34,211,238,.1); }
.tf-sv2-bc-api::before    { background: radial-gradient(circle at 0% 50%, rgba(251,191,36,.1) 0%, transparent 60%); }
.tf-sv2-bc-api:hover    { border-color: rgba(251,191,36,.35); box-shadow: 0 8px 40px rgba(251,191,36,.1); }

/* Featured card spans 2 columns */
.tf-sv2-bc-collab { grid-column: span 2; }

.tf-sv2-bento-card-tag {
  display: inline-flex; align-items: center; gap: 6px;
  font-size: .65rem; font-weight: 700; letter-spacing: .14em;
  text-transform: uppercase; margin-bottom: 14px;
  color: var(--meta);
}
.tf-sv2-bento-card-tag-dot {
  width: 6px; height: 6px; border-radius: 50%; flex-shrink: 0;
}
.tf-sv2-bento-card h3 {
  font-size: 1.15rem; font-weight: 800; color: var(--title); margin-bottom: 10px; line-height: 1.25;
}
.tf-sv2-bento-card p {
  font-size: .875rem; color: var(--txt); line-height: 1.7;
  margin-bottom: 24px;
}

/* Collab mini UI */
.tf-sv2-collab-ui {
  background: rgba(255,255,255,.03);
  border: 1px solid rgba(255,255,255,.07);
  border-radius: 12px; padding: 20px;
  position: relative;
}
.tf-sv2-collab-text {
  font-size: .78rem; color: var(--txt); line-height: 1.8;
  position: relative;
}
.tf-sv2-collab-highlight {
  background: rgba(168,85,247,.25);
  border-bottom: 2px solid rgba(168,85,247,.7);
  padding: 0 2px; border-radius: 2px;
  position: relative;
}
.tf-sv2-cursor {
  display: inline-block; width: 2px; height: 14px;
  vertical-align: middle; border-radius: 1px; margin-left: 1px;
  animation: tf-sv2-blink .8s ease-in-out infinite alternate;
}
.tf-sv2-cursor-1 { background: #a855f7; }
.tf-sv2-cursor-2 { background: #00d4ff; animation-delay: .4s; }
@keyframes tf-sv2-blink { 0% { opacity: 1; } 100% { opacity: 0; } }
.tf-sv2-cursor-label {
  display: inline-block; font-size: .55rem; font-weight: 700;
  padding: 2px 6px; border-radius: 4px; white-space: nowrap;
  margin-left: 4px; vertical-align: middle; line-height: 1.4;
}
.tf-sv2-cursor-label-1 { background: #a855f7; color: #fff; }
.tf-sv2-cursor-label-2 { background: #00d4ff; color: #000; }

/* Terminal UI */
.tf-sv2-terminal {
  background: #0a0a12;
  border: 1px solid rgba(255,255,255,.1);
  border-radius: 10px; padding: 16px 18px;
  font-family: 'JetBrains Mono', 'Fira Code', monospace; font-size: .75rem;
}
.tf-sv2-term-bar {
  display: flex; gap: 6px; margin-bottom: 14px;
}
.tf-sv2-term-bar span {
  width: 10px; height: 10px; border-radius: 50%;
}
.tf-sv2-term-bar span:nth-child(1) { background: rgba(255,95,87,.7); }
.tf-sv2-term-bar span:nth-child(2) { background: rgba(255,189,46,.7); }
.tf-sv2-term-bar span:nth-child(3) { background: rgba(40,200,64,.7); }
.tf-sv2-term-line { margin-bottom: 4px; }
.tf-sv2-term-prompt { color: #64748b; }
.tf-sv2-term-cmd { color: #e2e8f0; }
.tf-sv2-term-success { color: #10b981; }
.tf-sv2-term-info { color: #94a3b8; }
.tf-sv2-term-done { color: #a855f7; font-weight: 700; }

/* Mini bar chart */
.tf-sv2-mini-chart {
  display: flex; align-items: flex-end; gap: 4px;
  height: 64px; padding-top: 8px;
}
.tf-sv2-mini-bar {
  flex: 1; border-radius: 3px 3px 0 0; min-width: 10px;
  background: linear-gradient(180deg, rgba(0,212,255,.9) 0%, rgba(0,212,255,.2) 100%);
  transition: transform .3s;
}
.tf-sv2-mini-bar:hover { transform: scaleY(1.05); transform-origin: bottom; }
.tf-sv2-mini-bar.alt {
  background: linear-gradient(180deg, rgba(168,85,247,.9) 0%, rgba(168,85,247,.2) 100%);
}

/* Uptime card */
.tf-sv2-uptime-num {
  font-size: 3.5rem; font-weight: 900; color: var(--title);
  line-height: 1; letter-spacing: -2px; margin-bottom: 8px;
}
.tf-sv2-uptime-badge {
  display: inline-flex; align-items: center; gap: 6px;
  background: rgba(16,185,129,.12); border: 1px solid rgba(16,185,129,.3);
  color: #10b981; font-size: .7rem; font-weight: 700;
  padding: 5px 14px; border-radius: 100px;
}
.tf-sv2-uptime-badge-dot {
  width: 6px; height: 6px; border-radius: 50%; background: #10b981;
  animation: tf-sv2-pulse 2s ease-in-out infinite;
}

/* CDN world dots */
.tf-sv2-world-dots {
  display: flex; flex-direction: column; gap: 4px; margin-top: 8px;
}
.tf-sv2-world-row { display: flex; gap: 3px; justify-content: center; }
.tf-sv2-world-dot {
  width: 5px; height: 5px; border-radius: 50%;
  background: rgba(34,211,238,.2);
}
.tf-sv2-world-dot.active { background: #22d3ee; box-shadow: 0 0 6px #22d3ee; }
.tf-sv2-world-dot.semi { background: rgba(34,211,238,.5); }

/* API code snippet */
.tf-sv2-code-snippet {
  background: #0a0a12;
  border: 1px solid rgba(255,255,255,.08);
  border-radius: 10px; padding: 16px;
  font-family: 'JetBrains Mono', 'Fira Code', monospace; font-size: .7rem;
  line-height: 1.7;
}
.tf-sv2-code-key { color: #7dd3fc; }
.tf-sv2-code-val { color: #86efac; }
.tf-sv2-code-str { color: #fca5a5; }
.tf-sv2-code-punc { color: #94a3b8; }
.tf-sv2-code-num { color: #fbbf24; }

/* ══════════════════════════════════════════════════════════════════════════
   §4 — HOW IT WORKS
   ══════════════════════════════════════════════════════════════════════════ */
.tf-sv2-how { background: var(--bg2); }
.tf-sv2-steps {
  display: grid; grid-template-columns: repeat(3, 1fr);
  gap: 0; position: relative;
}
.tf-sv2-steps::before {
  content: '';
  position: absolute; top: 38px; left: calc(16.67% + 20px); right: calc(16.67% + 20px);
  height: 1px;
  background: linear-gradient(90deg,
    transparent 0%, rgba(255,94,46,.4) 20%, rgba(168,85,247,.4) 50%, rgba(0,212,255,.4) 80%, transparent 100%);
}
.tf-sv2-step {
  display: flex; flex-direction: column; align-items: center;
  text-align: center; padding: 0 32px;
  position: relative;
}
.tf-sv2-step-num-wrap {
  position: relative; margin-bottom: 24px;
  display: flex; align-items: center; justify-content: center;
  width: 76px; height: 76px;
}
.tf-sv2-step-ring {
  position: absolute; inset: 0; border-radius: 50%;
  border: 1px solid rgba(255,94,46,.3);
  animation: tf-sv2-ring-pulse 3s ease-in-out infinite;
}
.tf-sv2-step:nth-child(2) .tf-sv2-step-ring { border-color: rgba(168,85,247,.3); animation-delay: 1s; }
.tf-sv2-step:nth-child(3) .tf-sv2-step-ring { border-color: rgba(0,212,255,.3); animation-delay: 2s; }
@keyframes tf-sv2-ring-pulse {
  0%, 100% { transform: scale(1); opacity: .6; }
  50%       { transform: scale(1.15); opacity: 1; }
}
.tf-sv2-step-circle {
  width: 60px; height: 60px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  background: linear-gradient(135deg, rgba(255,94,46,.2), rgba(255,94,46,.05));
  border: 1px solid rgba(255,94,46,.4);
  color: var(--tc);
  font-size: 1.1rem; font-weight: 900;
  position: relative; z-index: 1;
}
.tf-sv2-step:nth-child(2) .tf-sv2-step-circle {
  background: linear-gradient(135deg, rgba(168,85,247,.2), rgba(168,85,247,.05));
  border-color: rgba(168,85,247,.4); color: #a855f7;
}
.tf-sv2-step:nth-child(3) .tf-sv2-step-circle {
  background: linear-gradient(135deg, rgba(0,212,255,.2), rgba(0,212,255,.05));
  border-color: rgba(0,212,255,.4); color: #00d4ff;
}
.tf-sv2-step-circle svg { width: 22px; height: 22px; }
.tf-sv2-step-num {
  position: absolute; top: -4px; right: -4px;
  width: 22px; height: 22px; border-radius: 50%;
  background: var(--tc); color: #fff;
  font-size: .6rem; font-weight: 800;
  display: flex; align-items: center; justify-content: center;
  z-index: 2;
}
.tf-sv2-step:nth-child(2) .tf-sv2-step-num { background: #a855f7; }
.tf-sv2-step:nth-child(3) .tf-sv2-step-num { background: #00d4ff; color: #000; }
.tf-sv2-step h3 {
  font-size: 1.05rem; font-weight: 800; color: var(--title);
  margin-bottom: 10px;
}
.tf-sv2-step p { font-size: .875rem; color: var(--txt); line-height: 1.7; max-width: 240px; }

/* ══════════════════════════════════════════════════════════════════════════
   §5 — PRICING
   ══════════════════════════════════════════════════════════════════════════ */
.tf-sv2-pricing-toggle-wrap {
  display: flex; align-items: center; justify-content: center;
  gap: 14px; margin-bottom: 52px;
}
.tf-sv2-pricing-toggle-label {
  font-size: .875rem; font-weight: 600; color: var(--txt);
}
.tf-sv2-pricing-toggle-label.active { color: var(--title); }
.tf-sv2-toggle-switch {
  width: 48px; height: 26px; border-radius: 13px;
  background: rgba(255,255,255,.1); border: 1px solid rgba(255,255,255,.15);
  position: relative; cursor: pointer;
  transition: background .25s;
}
.tf-sv2-toggle-switch.annual { background: var(--tc); border-color: var(--tc); }
.tf-sv2-toggle-knob {
  position: absolute; top: 3px; left: 3px;
  width: 18px; height: 18px; border-radius: 50%;
  background: #fff;
  transition: transform .25s cubic-bezier(.4,0,.2,1);
  box-shadow: 0 2px 6px rgba(0,0,0,.3);
}
.tf-sv2-toggle-switch.annual .tf-sv2-toggle-knob { transform: translateX(22px); }
.tf-sv2-annual-badge {
  display: inline-block; font-size: .65rem; font-weight: 700;
  background: rgba(16,185,129,.15); color: #10b981;
  border: 1px solid rgba(16,185,129,.3);
  padding: 3px 10px; border-radius: 100px;
}

.tf-sv2-pricing-grid {
  display: grid; grid-template-columns: repeat(3, 1fr);
  gap: 20px; align-items: start;
}
.tf-sv2-pricing-card {
  background: var(--bg2); border: 1px solid var(--border);
  border-radius: 22px; padding: 36px 32px;
  position: relative; overflow: hidden;
  transition: border-color .3s, box-shadow .3s;
}
.tf-sv2-pricing-card:hover { box-shadow: 0 20px 60px rgba(0,0,0,.4); }
.tf-sv2-pricing-card.popular {
  border-color: rgba(255,94,46,.5);
  background: linear-gradient(180deg, rgba(255,94,46,.06) 0%, var(--bg2) 60%);
  box-shadow: 0 0 0 1px rgba(255,94,46,.15), 0 20px 60px rgba(255,94,46,.1);
  transform: scale(1.02);
}
.tf-sv2-popular-badge {
  position: absolute; top: 20px; right: 20px;
  background: var(--tc); color: #fff;
  font-size: .62rem; font-weight: 800; letter-spacing: .1em;
  text-transform: uppercase; padding: 4px 12px; border-radius: 100px;
}
.tf-sv2-pricing-tier {
  font-size: .7rem; font-weight: 800; text-transform: uppercase;
  letter-spacing: .14em; color: var(--meta); margin-bottom: 16px;
}
.tf-sv2-pricing-price {
  margin-bottom: 6px; display: flex; align-items: baseline; gap: 4px;
}
.tf-sv2-price-currency { font-size: 1.5rem; font-weight: 700; color: var(--title); }
.tf-sv2-price-num {
  font-size: 3.2rem; font-weight: 900; color: var(--title);
  line-height: 1; letter-spacing: -2px;
}
.tf-sv2-price-period { font-size: .85rem; color: var(--meta); align-self: flex-end; padding-bottom: 6px; }
.tf-sv2-price-free { font-size: 3.2rem; font-weight: 900; color: var(--title); line-height: 1; letter-spacing: -2px; }
.tf-sv2-pricing-desc {
  font-size: .82rem; color: var(--txt); margin-bottom: 24px; line-height: 1.6;
}
.tf-sv2-pricing-divider {
  height: 1px; background: var(--border); margin-bottom: 24px;
}
.tf-sv2-pricing-features { margin-bottom: 32px; }
.tf-sv2-pricing-feature {
  display: flex; align-items: flex-start; gap: 10px;
  font-size: .84rem; color: var(--txt); margin-bottom: 12px; line-height: 1.5;
}
.tf-sv2-pricing-feature svg { width: 16px; height: 16px; color: #10b981; flex-shrink: 0; margin-top: 2px; }
.tf-sv2-pricing-cta {
  display: block; text-align: center;
  padding: 14px 24px; border-radius: 12px;
  font-size: .9rem; font-weight: 700; letter-spacing: .02em;
  transition: all .2s;
}
.tf-sv2-pricing-cta-outline {
  background: transparent; color: var(--title);
  border: 1px solid rgba(255,255,255,.15);
}
.tf-sv2-pricing-cta-outline:hover { background: rgba(255,255,255,.07); border-color: rgba(255,255,255,.25); }
.tf-sv2-pricing-cta-filled {
  background: var(--tc); color: #fff;
  box-shadow: 0 8px 24px rgba(255,94,46,.35);
}
.tf-sv2-pricing-cta-filled:hover { box-shadow: 0 12px 32px rgba(255,94,46,.5); transform: translateY(-1px); }
.tf-sv2-pricing-footnote {
  text-align: center; margin-top: 36px;
  font-size: .8rem; color: var(--meta);
}

/* Price data stored as data attributes — JS toggles class on container */
.tf-sv2-price-val { transition: opacity .25s; }

/* ══════════════════════════════════════════════════════════════════════════
   §6 — TESTIMONIALS
   ══════════════════════════════════════════════════════════════════════════ */
.tf-sv2-testi { background: var(--bg2); }
.tf-sv2-testi-grid {
  columns: 3; column-gap: 20px;
}
.tf-sv2-testi-card {
  background: var(--bg3);
  border: 1px solid var(--border);
  border-radius: 18px; padding: 28px;
  break-inside: avoid; margin-bottom: 20px;
  transition: border-color .3s, box-shadow .3s;
}
.tf-sv2-testi-card:hover {
  border-color: rgba(255,255,255,.14);
  box-shadow: 0 8px 30px rgba(0,0,0,.35);
}
.tf-sv2-stars { display: flex; gap: 3px; margin-bottom: 14px; }
.tf-sv2-star { width: 14px; height: 14px; color: #fbbf24; }
.tf-sv2-testi-quote {
  font-size: .9rem; color: var(--title); line-height: 1.75;
  margin-bottom: 20px; font-style: italic;
}
.tf-sv2-testi-quote::before { content: '\201C'; color: var(--tc); font-size: 1.4rem; font-style: normal; line-height: 0; vertical-align: -0.4em; margin-right: 3px; }
.tf-sv2-testi-author {
  display: flex; align-items: center; gap: 12px;
}
.tf-sv2-testi-avatar {
  width: 38px; height: 38px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .7rem; font-weight: 800; color: #fff; flex-shrink: 0;
}
.tf-sv2-testi-name { font-size: .83rem; font-weight: 700; color: var(--title); }
.tf-sv2-testi-role { font-size: .73rem; color: var(--meta); }

/* ══════════════════════════════════════════════════════════════════════════
   §7 — INTEGRATIONS
   ══════════════════════════════════════════════════════════════════════════ */
.tf-sv2-integrations-grid {
  display: flex; flex-wrap: wrap; gap: 12px;
  justify-content: center; margin-bottom: 28px;
}
.tf-sv2-integration-chip {
  display: inline-flex; align-items: center; gap: 10px;
  background: var(--bg2);
  border: 1px solid var(--border);
  border-radius: 12px; padding: 12px 20px;
  font-size: .84rem; font-weight: 700; color: var(--title);
  transition: border-color .2s, background .2s, transform .2s;
  cursor: default;
}
.tf-sv2-integration-chip:hover { background: rgba(255,255,255,.06); border-color: rgba(255,255,255,.14); transform: translateY(-2px); }
.tf-sv2-int-icon {
  width: 22px; height: 22px; border-radius: 6px;
  display: flex; align-items: center; justify-content: center;
  font-size: .55rem; font-weight: 800; color: #fff; flex-shrink: 0;
}
.tf-sv2-int-more {
  text-align: center; font-size: .84rem; color: var(--meta);
}
.tf-sv2-int-more a { color: var(--tc); text-decoration: underline; text-underline-offset: 3px; }

/* ══════════════════════════════════════════════════════════════════════════
   §8 — FAQ
   ══════════════════════════════════════════════════════════════════════════ */
.tf-sv2-faq { background: var(--bg2); }
.tf-sv2-faq-list { max-width: 780px; margin: 0 auto; }
.tf-sv2-faq-item {
  border: 1px solid var(--border);
  border-radius: 14px; margin-bottom: 12px;
  overflow: hidden; transition: border-color .2s;
}
.tf-sv2-faq-item.open { border-color: rgba(255,94,46,.35); }
.tf-sv2-faq-q {
  display: flex; align-items: center; justify-content: space-between;
  padding: 22px 26px;
  cursor: pointer; background: var(--bg3);
  font-size: .95rem; font-weight: 700; color: var(--title);
  gap: 16px; transition: background .2s;
  border: none; width: 100%; text-align: left;
}
.tf-sv2-faq-q:hover { background: rgba(255,255,255,.04); }
.tf-sv2-faq-icon {
  width: 24px; height: 24px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0;
  background: rgba(255,255,255,.07);
  color: var(--title); font-size: .9rem;
  transition: transform .3s, background .3s;
}
.tf-sv2-faq-item.open .tf-sv2-faq-icon {
  transform: rotate(45deg); background: rgba(255,94,46,.2); color: var(--tc);
}
.tf-sv2-faq-a {
  max-height: 0; overflow: hidden;
  transition: max-height .35s cubic-bezier(.4,0,.2,1), padding .35s;
}
.tf-sv2-faq-a-inner {
  padding: 0 26px 22px;
  font-size: .9rem; color: var(--txt); line-height: 1.8;
  background: var(--bg3);
}
.tf-sv2-faq-item.open .tf-sv2-faq-a { max-height: 400px; }

/* ══════════════════════════════════════════════════════════════════════════
   §9 — FINAL CTA
   ══════════════════════════════════════════════════════════════════════════ */
.tf-sv2-final-cta {
  position: relative; overflow: hidden;
  padding: 120px 24px;
  background: #050010;
  text-align: center;
}
.tf-sv2-final-cta::before {
  content: '';
  position: absolute; inset: 0; pointer-events: none;
  background:
    radial-gradient(ellipse 70% 60% at 50% 60%, rgba(168,85,247,.2) 0%, transparent 65%),
    radial-gradient(ellipse 40% 50% at 20% 20%, rgba(255,94,46,.12) 0%, transparent 60%),
    radial-gradient(ellipse 40% 50% at 80% 80%, rgba(0,212,255,.1) 0%, transparent 60%);
}
.tf-sv2-cta-inner { position: relative; z-index: 1; }
.tf-sv2-final-cta h2 {
  font-size: clamp(2.4rem, 5vw, 4rem); font-weight: 900;
  color: var(--title); line-height: 1.05; letter-spacing: -.6px; margin-bottom: 18px;
}
.tf-sv2-final-cta p {
  font-size: 1.1rem; color: var(--txt); margin-bottom: 44px; line-height: 1.7;
}
.tf-sv2-social-proof-avatars {
  display: flex; align-items: center; justify-content: center;
  gap: 0; margin-bottom: 14px;
}
.tf-sv2-sp-avatar {
  width: 38px; height: 38px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .65rem; font-weight: 800; color: #fff;
  border: 2px solid #050010;
  margin-left: -10px; flex-shrink: 0;
}
.tf-sv2-sp-avatar:first-child { margin-left: 0; }
.tf-sv2-sp-text {
  margin-left: 14px; font-size: .84rem; color: var(--txt); font-weight: 600;
}
.tf-sv2-sp-text strong { color: var(--title); }

/* ══════════════════════════════════════════════════════════════════════════
   RESPONSIVE — 3 → 2 → 1 col
   ══════════════════════════════════════════════════════════════════════════ */
@media (max-width: 1024px) {
  .tf-sv2-bento-grid { grid-template-columns: repeat(2, 1fr); }
  .tf-sv2-bc-collab { grid-column: span 2; }
  .tf-sv2-pricing-grid { grid-template-columns: repeat(2, 1fr); }
  .tf-sv2-pricing-card.popular { transform: none; }
  .tf-sv2-testi-grid { columns: 2; }
  .tf-sv2-mock-body { grid-template-columns: 160px 1fr; }
  .tf-sv2-mock-metrics { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 768px) {
  .tf-sv2-section { padding: 72px 0; }
  .tf-sv2-bento-grid { grid-template-columns: 1fr; }
  .tf-sv2-bc-collab { grid-column: span 1; }
  .tf-sv2-steps { grid-template-columns: 1fr; gap: 40px; }
  .tf-sv2-steps::before { display: none; }
  .tf-sv2-pricing-grid { grid-template-columns: 1fr; max-width: 420px; margin: 0 auto; }
  .tf-sv2-testi-grid { columns: 1; }
  .tf-sv2-proof-divider { display: none; }
  .tf-sv2-proof-inner { flex-direction: column; gap: 20px; text-align: center; }
  .tf-sv2-mock-body { grid-template-columns: 1fr; }
  .tf-sv2-mock-sidebar { display: none; }
  .tf-sv2-mock-metrics { grid-template-columns: repeat(2, 1fr); }
  .tf-sv2-mock-charts { grid-template-columns: 1fr; }
}
@media (max-width: 640px) {
  .tf-sv2-hero-h1 { letter-spacing: -.5px; }
  .tf-sv2-hero-ctas { flex-direction: column; align-items: center; }
  .tf-sv2-btn-primary, .tf-sv2-btn-ghost { width: 100%; justify-content: center; }
  .tf-sv2-mock-wrap { display: none; }
  .tf-sv2-hero-disclaimer { margin-bottom: 0; }
  .tf-sv2-integrations-grid { gap: 8px; }
  .tf-sv2-integration-chip { padding: 10px 14px; font-size: .78rem; }
}
</style>

<?php
/* ══════════════════════════════════════════════════════════════════════════
   §1 — HERO
   ══════════════════════════════════════════════════════════════════════════ */
?>
<section class="tf-sv2-hero" aria-labelledby="tf-sv2-h1">
  <div class="tf-sv2-orb tf-sv2-orb-1" aria-hidden="true"></div>
  <div class="tf-sv2-orb tf-sv2-orb-2" aria-hidden="true"></div>
  <div class="tf-sv2-orb tf-sv2-orb-3" aria-hidden="true"></div>

  <div class="tf-sv2-hero-inner">

    <a href="<?php echo esc_url( '#changelog' ); ?>" class="tf-sv2-hero-badge" aria-label="<?php esc_attr_e( 'View changelog for version 2.0', 'themeflex' ); ?>">
      <span class="tf-sv2-hero-badge-dot" aria-hidden="true"></span>
      <?php esc_html_e( 'Now in v2.0 — See what\'s new', 'themeflex' ); ?>
      <span class="tf-sv2-badge-arrow" aria-hidden="true">→</span>
    </a>

    <h1 id="tf-sv2-h1" class="tf-sv2-hero-h1">
      <?php esc_html_e( 'The platform that turns', 'themeflex' ); ?>
      <br>
      <span class="tf-sv2-gradient"><?php esc_html_e( 'ideas into products', 'themeflex' ); ?></span>
      <?php esc_html_e( '— fast', 'themeflex' ); ?>
    </h1>

    <p class="tf-sv2-hero-sub">
      <?php esc_html_e( 'Collaborate in real-time, deploy with one click, and ship to millions — all from a single platform built for modern teams who move at speed.', 'themeflex' ); ?>
    </p>

    <div class="tf-sv2-hero-ctas">
      <a href="<?php echo esc_url( '#pricing' ); ?>" class="tf-sv2-btn-primary">
        <?php echo tf_icon_get( 'rocket', 18 ); ?>
        <?php esc_html_e( 'Start free trial', 'themeflex' ); ?>
      </a>
      <a href="<?php echo esc_url( '#demo' ); ?>" class="tf-sv2-btn-ghost">
        <?php echo tf_icon_get( 'play-circle', 18 ); ?>
        <?php esc_html_e( 'Watch demo', 'themeflex' ); ?>
      </a>
    </div>

    <p class="tf-sv2-hero-disclaimer">
      <?php esc_html_e( 'No credit card required', 'themeflex' ); ?>
      <span aria-hidden="true">·</span>
      <?php esc_html_e( 'Cancel anytime', 'themeflex' ); ?>
      <span aria-hidden="true">·</span>
      <?php esc_html_e( 'Free forever plan', 'themeflex' ); ?>
    </p>

    <!-- CSS Device Mockup -->
    <div class="tf-sv2-mockup-wrap" aria-label="<?php esc_attr_e( 'App dashboard preview', 'themeflex' ); ?>" role="img">
      <div class="tf-sv2-mock-titlebar">
        <div class="tf-sv2-mock-dots" aria-hidden="true">
          <span></span><span></span><span></span>
        </div>
        <div class="tf-sv2-mock-title-text" aria-hidden="true">app.product.io — Dashboard</div>
      </div>

      <div class="tf-sv2-mock-body">
        <!-- Sidebar -->
        <nav class="tf-sv2-mock-sidebar" aria-hidden="true">
          <div class="tf-sv2-mock-sb-logo">
            <div class="tf-sv2-mock-sb-logo-icon"></div>
            <div class="tf-sv2-mock-sb-logo-text">Product</div>
          </div>
          <?php
          $nav_items = [
            [ 'label' => 'Dashboard',  'color' => '#ff5e2e', 'active' => true  ],
            [ 'label' => 'Projects',   'color' => '#a855f7', 'active' => false ],
            [ 'label' => 'Analytics',  'color' => '#00d4ff', 'active' => false ],
            [ 'label' => 'Deploy',     'color' => '#10b981', 'active' => false ],
            [ 'label' => 'Team',       'color' => '#fbbf24', 'active' => false ],
            [ 'label' => 'Settings',   'color' => '#64748b', 'active' => false ],
          ];
          foreach ( $nav_items as $item ) : ?>
            <div class="tf-sv2-mock-nav-item<?php echo $item['active'] ? ' active' : ''; ?>">
              <span class="tf-sv2-mock-nav-dot" style="background:<?php echo esc_attr( $item['color'] ); ?>"></span>
              <?php echo esc_html( $item['label'] ); ?>
            </div>
          <?php endforeach; ?>
        </nav>

        <!-- Main content -->
        <div class="tf-sv2-mock-main" aria-hidden="true">
          <div class="tf-sv2-mock-main-header">
            <div class="tf-sv2-mock-main-title">Overview</div>
            <div class="tf-sv2-mock-main-actions">
              <div class="tf-sv2-mock-chip">+ New project</div>
              <div class="tf-sv2-mock-chip alt">This month ▾</div>
            </div>
          </div>

          <div class="tf-sv2-mock-metrics">
            <?php
            $metrics = [
              [ 'label' => 'Monthly Users',   'val' => '24.8k', 'change' => '+12%', 'up' => true  ],
              [ 'label' => 'Deployments',      'val' => '1,342',  'change' => '+8%',  'up' => true  ],
              [ 'label' => 'Uptime',           'val' => '99.9%',  'change' => '→ SLA', 'up' => true  ],
              [ 'label' => 'Avg. Load Time',  'val' => '142ms',  'change' => '-18%', 'up' => false ],
            ];
            foreach ( $metrics as $m ) : ?>
              <div class="tf-sv2-mock-metric">
                <div class="tf-sv2-mock-metric-label"><?php echo esc_html( $m['label'] ); ?></div>
                <div class="tf-sv2-mock-metric-val">
                  <?php echo esc_html( $m['val'] ); ?>
                  <span class="<?php echo $m['up'] ? 'up' : 'dn'; ?>"><?php echo esc_html( $m['change'] ); ?></span>
                </div>
              </div>
            <?php endforeach; ?>
          </div>

          <div class="tf-sv2-mock-charts">
            <div class="tf-sv2-mock-chart-box">
              <div class="tf-sv2-mock-chart-title">Traffic</div>
              <div class="tf-sv2-mock-bars" aria-hidden="true">
                <?php
                $bar_heights = [28, 42, 36, 55, 40, 62, 48, 70, 52, 65, 58, 75];
                foreach ( $bar_heights as $i => $h ) : ?>
                  <div class="tf-sv2-mock-bar<?php echo $i % 3 === 2 ? ' alt' : ''; ?>" style="height:<?php echo esc_attr( $h ); ?>px"></div>
                <?php endforeach; ?>
              </div>
            </div>
            <div class="tf-sv2-mock-chart-box">
              <div class="tf-sv2-mock-chart-title">Recent Activity</div>
              <?php
              $activities = [
                [ 'initials' => 'AK', 'color' => '#a855f7', 'text' => 'Deployed v2.3.1 to prod' ],
                [ 'initials' => 'JS', 'color' => '#00d4ff',  'text' => 'Merged PR #214 — Auth fix' ],
                [ 'initials' => 'MR', 'color' => '#ff5e2e',  'text' => 'Created new workspace' ],
                [ 'initials' => 'TL', 'color' => '#10b981',  'text' => 'Invited 3 team members' ],
              ];
              foreach ( $activities as $act ) : ?>
                <div class="tf-sv2-mock-activity-item">
                  <div class="tf-sv2-mock-avatar-xs" style="background:<?php echo esc_attr( $act['color'] ); ?>"><?php echo esc_html( $act['initials'] ); ?></div>
                  <?php echo esc_html( $act['text'] ); ?>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
        </div><!-- /.tf-sv2-mock-main -->
      </div><!-- /.tf-sv2-mock-body -->
    </div><!-- /.tf-sv2-mockup-wrap -->

  </div><!-- /.tf-sv2-hero-inner -->
</section>

<?php
/* ══════════════════════════════════════════════════════════════════════════
   §2 — SOCIAL PROOF BAR
   ══════════════════════════════════════════════════════════════════════════ */
?>
<section class="tf-sv2-proof" aria-label="<?php esc_attr_e( 'Trusted by leading companies', 'themeflex' ); ?>">
  <div class="tf-sv2-wrap">
    <div class="tf-sv2-proof-inner">
      <p class="tf-sv2-proof-label"><?php esc_html_e( 'Trusted by 10,000+ teams at:', 'themeflex' ); ?></p>
      <div class="tf-sv2-proof-divider" aria-hidden="true"></div>
      <div class="tf-sv2-proof-logos">
        <?php
        $companies = [ 'Startup Hub', 'TechCorp', 'DevLab', 'CloudCo', 'AppStack', 'BuildFast' ];
        foreach ( $companies as $co ) : ?>
          <div class="tf-sv2-proof-chip"><?php echo esc_html( $co ); ?></div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<?php
/* ══════════════════════════════════════════════════════════════════════════
   §3 — BENTO FEATURE GRID
   ══════════════════════════════════════════════════════════════════════════ */
?>
<section class="tf-sv2-section" aria-labelledby="tf-sv2-features-h2">
  <div class="tf-sv2-wrap">
    <div class="tf-sv2-head">
      <div class="tf-sv2-label" aria-hidden="true"><?php echo tf_icon_get( 'sparkles', 13 ); ?> <?php esc_html_e( 'Features', 'themeflex' ); ?></div>
      <h2 id="tf-sv2-features-h2"><?php esc_html_e( 'Everything you need to', 'themeflex' ); ?> <span class="tf-sv2-gradient"><?php esc_html_e( 'ship faster', 'themeflex' ); ?></span></h2>
      <p><?php esc_html_e( 'Built for speed without sacrificing quality. Every tool your team needs from first commit to production deploy.', 'themeflex' ); ?></p>
    </div>

    <div class="tf-sv2-bento-grid">

      <!-- Large: Real-time collaboration -->
      <article class="tf-sv2-bento-card tf-sv2-bc-collab">
        <div class="tf-sv2-bento-card-tag">
          <span class="tf-sv2-bento-card-tag-dot" style="background:#a855f7"></span>
          <?php esc_html_e( 'Collaboration', 'themeflex' ); ?>
        </div>
        <h3><?php esc_html_e( 'Real-time collaboration', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'Work together with your team in perfect sync. See cursor positions, live edits, and presence — all without page refreshes.', 'themeflex' ); ?></p>
        <div class="tf-sv2-collab-ui" aria-hidden="true">
          <div class="tf-sv2-collab-text">
            <span class="tf-sv2-cursor-label tf-sv2-cursor-label-1">Alex</span>
            <?php esc_html_e( 'The new landing page copy for the Q2 campaign should focus on ', 'themeflex' ); ?>
            <span class="tf-sv2-collab-highlight"><?php esc_html_e( 'conversion-first messaging', 'themeflex' ); ?><span class="tf-sv2-cursor tf-sv2-cursor-1"></span></span>
            <?php esc_html_e( ' while maintaining our brand voice.', 'themeflex' ); ?>
            <span class="tf-sv2-cursor tf-sv2-cursor-2"></span>
            <span class="tf-sv2-cursor-label tf-sv2-cursor-label-2">Sam</span>
          </div>
        </div>
      </article>

      <!-- Deploy card -->
      <article class="tf-sv2-bento-card tf-sv2-bc-deploy">
        <div class="tf-sv2-bento-card-tag">
          <span class="tf-sv2-bento-card-tag-dot" style="background:#10b981"></span>
          <?php esc_html_e( 'Deployment', 'themeflex' ); ?>
        </div>
        <h3><?php esc_html_e( 'Deploy in one click', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'Push to production from any branch. Zero-downtime deploys with instant rollback.', 'themeflex' ); ?></p>
        <div class="tf-sv2-terminal" aria-hidden="true">
          <div class="tf-sv2-term-bar"><span></span><span></span><span></span></div>
          <div class="tf-sv2-term-line"><span class="tf-sv2-term-prompt">~/project</span> <span class="tf-sv2-term-prompt">$</span> <span class="tf-sv2-term-cmd">deploy --prod</span></div>
          <div class="tf-sv2-term-line"><span class="tf-sv2-term-info">▸ Building... (12s)</span></div>
          <div class="tf-sv2-term-line"><span class="tf-sv2-term-success">✓ Tests passed (247)</span></div>
          <div class="tf-sv2-term-line"><span class="tf-sv2-term-success">✓ Build complete</span></div>
          <div class="tf-sv2-term-line"><span class="tf-sv2-term-done">⚡ Live at app.io/prod</span></div>
        </div>
      </article>

      <!-- Analytics card -->
      <article class="tf-sv2-bento-card tf-sv2-bc-analytics">
        <div class="tf-sv2-bento-card-tag">
          <span class="tf-sv2-bento-card-tag-dot" style="background:#00d4ff"></span>
          <?php esc_html_e( 'Analytics', 'themeflex' ); ?>
        </div>
        <h3><?php esc_html_e( 'Analytics dashboard', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'Track everything that matters. From page views to revenue — all in real time.', 'themeflex' ); ?></p>
        <div class="tf-sv2-mini-chart" aria-hidden="true">
          <?php
          $chart_bars = [30, 45, 38, 60, 44, 72, 50, 80, 58, 76, 64, 88, 70, 95];
          foreach ( $chart_bars as $i => $h ) : ?>
            <div class="tf-sv2-mini-bar<?php echo $i % 5 === 4 ? ' alt' : ''; ?>" style="height:<?php echo esc_attr( $h ); ?>%"></div>
          <?php endforeach; ?>
        </div>
      </article>

      <!-- Uptime card -->
      <article class="tf-sv2-bento-card tf-sv2-bc-uptime">
        <div class="tf-sv2-bento-card-tag">
          <span class="tf-sv2-bento-card-tag-dot" style="background:#ff5e2e"></span>
          <?php esc_html_e( 'Infrastructure', 'themeflex' ); ?>
        </div>
        <h3><?php esc_html_e( '99.9% Uptime', 'themeflex' ); ?></h3>
        <div class="tf-sv2-uptime-num" aria-hidden="true">99.9<small style="font-size:1.8rem">%</small></div>
        <div class="tf-sv2-uptime-badge">
          <span class="tf-sv2-uptime-badge-dot"></span>
          <?php esc_html_e( 'All systems operational', 'themeflex' ); ?>
        </div>
      </article>

      <!-- Global CDN card -->
      <article class="tf-sv2-bento-card tf-sv2-bc-cdn">
        <div class="tf-sv2-bento-card-tag">
          <span class="tf-sv2-bento-card-tag-dot" style="background:#22d3ee"></span>
          <?php esc_html_e( 'Performance', 'themeflex' ); ?>
        </div>
        <h3><?php esc_html_e( 'Global CDN', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( '200+ edge nodes. Sub-50ms response times worldwide.', 'themeflex' ); ?></p>
        <div class="tf-sv2-world-dots" aria-hidden="true">
          <?php
          $dot_rows = [
            [0,0,1,0,1,1,0,1,0,0,1,0],
            [0,1,1,1,1,1,1,1,1,1,1,0],
            [1,1,2,1,2,1,1,2,1,2,1,1],
            [0,1,1,1,1,1,1,1,1,1,1,0],
            [0,0,1,0,1,0,1,0,1,0,0,0],
          ];
          foreach ( $dot_rows as $row ) : ?>
            <div class="tf-sv2-world-row">
              <?php foreach ( $row as $dot ) : ?>
                <div class="tf-sv2-world-dot<?php echo $dot === 2 ? ' active' : ( $dot === 1 ? ' semi' : '' ); ?>"></div>
              <?php endforeach; ?>
            </div>
          <?php endforeach; ?>
        </div>
      </article>

      <!-- API Architecture card -->
      <article class="tf-sv2-bento-card tf-sv2-bc-api">
        <div class="tf-sv2-bento-card-tag">
          <span class="tf-sv2-bento-card-tag-dot" style="background:#fbbf24"></span>
          <?php esc_html_e( 'Developer', 'themeflex' ); ?>
        </div>
        <h3><?php esc_html_e( 'API-first architecture', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'Every feature accessible via REST & GraphQL. Build integrations in minutes.', 'themeflex' ); ?></p>
        <div class="tf-sv2-code-snippet" aria-hidden="true">
          <span class="tf-sv2-code-punc">{</span><br>
          &nbsp;&nbsp;<span class="tf-sv2-code-key">"status"</span><span class="tf-sv2-code-punc">:</span> <span class="tf-sv2-code-str">"deployed"</span><span class="tf-sv2-code-punc">,</span><br>
          &nbsp;&nbsp;<span class="tf-sv2-code-key">"version"</span><span class="tf-sv2-code-punc">:</span> <span class="tf-sv2-code-str">"v2.3.1"</span><span class="tf-sv2-code-punc">,</span><br>
          &nbsp;&nbsp;<span class="tf-sv2-code-key">"latency_ms"</span><span class="tf-sv2-code-punc">:</span> <span class="tf-sv2-code-num">42</span><span class="tf-sv2-code-punc">,</span><br>
          &nbsp;&nbsp;<span class="tf-sv2-code-key">"region"</span><span class="tf-sv2-code-punc">:</span> <span class="tf-sv2-code-str">"eu-west-1"</span><br>
          <span class="tf-sv2-code-punc">}</span>
        </div>
      </article>

    </div><!-- /.tf-sv2-bento-grid -->
  </div>
</section>

<?php
/* ══════════════════════════════════════════════════════════════════════════
   §4 — HOW IT WORKS
   ══════════════════════════════════════════════════════════════════════════ */
?>
<section class="tf-sv2-how tf-sv2-section" aria-labelledby="tf-sv2-how-h2">
  <div class="tf-sv2-wrap">
    <div class="tf-sv2-head">
      <div class="tf-sv2-label" aria-hidden="true"><?php echo tf_icon_get( 'layers', 13 ); ?> <?php esc_html_e( 'Process', 'themeflex' ); ?></div>
      <h2 id="tf-sv2-how-h2"><?php esc_html_e( 'From zero to shipped in', 'themeflex' ); ?> <span class="tf-sv2-gradient-cyan"><?php esc_html_e( '3 steps', 'themeflex' ); ?></span></h2>
      <p><?php esc_html_e( 'We stripped away the complexity. Getting your product live should be exciting, not exhausting.', 'themeflex' ); ?></p>
    </div>

    <div class="tf-sv2-steps">
      <?php
      $steps = [
        [
          'icon'  => 'rocket',
          'num'   => '1',
          'title' => __( 'Create your project', 'themeflex' ),
          'desc'  => __( 'Start from a template or scratch. Set up your workspace with a custom domain, environment variables, and team settings in under 2 minutes.', 'themeflex' ),
        ],
        [
          'icon'  => 'users',
          'num'   => '2',
          'title' => __( 'Invite your team', 'themeflex' ),
          'desc'  => __( 'Bring your whole team on board. Assign roles, set permissions, and start collaborating instantly — no IT department required.', 'themeflex' ),
        ],
        [
          'icon'  => 'zap',
          'num'   => '3',
          'title' => __( 'Ship to production', 'themeflex' ),
          'desc'  => __( 'Push your code and deploy globally in seconds. Automatic SSL, CDN distribution, and zero-downtime rollouts come built in.', 'themeflex' ),
        ],
      ];
      foreach ( $steps as $step ) : ?>
        <div class="tf-sv2-step">
          <div class="tf-sv2-step-num-wrap">
            <div class="tf-sv2-step-ring" aria-hidden="true"></div>
            <div class="tf-sv2-step-circle" aria-hidden="true">
              <?php echo tf_icon_get( $step['icon'], 22 ); ?>
            </div>
            <div class="tf-sv2-step-num" aria-hidden="true"><?php echo esc_html( $step['num'] ); ?></div>
          </div>
          <h3><?php echo esc_html( $step['title'] ); ?></h3>
          <p><?php echo esc_html( $step['desc'] ); ?></p>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php
/* ══════════════════════════════════════════════════════════════════════════
   §5 — PRICING
   ══════════════════════════════════════════════════════════════════════════ */
?>
<section class="tf-sv2-section" id="pricing" aria-labelledby="tf-sv2-pricing-h2">
  <div class="tf-sv2-wrap">
    <div class="tf-sv2-head">
      <div class="tf-sv2-label" aria-hidden="true"><?php echo tf_icon_get( 'percent', 13 ); ?> <?php esc_html_e( 'Pricing', 'themeflex' ); ?></div>
      <h2 id="tf-sv2-pricing-h2"><?php esc_html_e( 'Simple, transparent', 'themeflex' ); ?> <span class="tf-sv2-gradient"><?php esc_html_e( 'pricing', 'themeflex' ); ?></span></h2>
      <p><?php esc_html_e( 'No hidden fees, no surprise invoices. Pick the plan that fits your team — upgrade or downgrade anytime.', 'themeflex' ); ?></p>
    </div>

    <!-- Billing toggle -->
    <div class="tf-sv2-pricing-toggle-wrap" role="group" aria-label="<?php esc_attr_e( 'Billing period', 'themeflex' ); ?>">
      <span class="tf-sv2-pricing-toggle-label active" id="tf-sv2-monthly-label"><?php esc_html_e( 'Monthly', 'themeflex' ); ?></span>
      <div class="tf-sv2-toggle-switch" id="tf-sv2-billing-toggle" role="switch" aria-checked="false" aria-labelledby="tf-sv2-monthly-label tf-sv2-annual-label" tabindex="0">
        <div class="tf-sv2-toggle-knob"></div>
      </div>
      <span class="tf-sv2-pricing-toggle-label" id="tf-sv2-annual-label"><?php esc_html_e( 'Annual', 'themeflex' ); ?></span>
      <span class="tf-sv2-annual-badge"><?php esc_html_e( 'Save 20%', 'themeflex' ); ?></span>
    </div>

    <div class="tf-sv2-pricing-grid" id="tf-sv2-pricing-grid">
      <?php
      $pricing_tiers = [
        [
          'name'       => __( 'Free', 'themeflex' ),
          'popular'    => false,
          'price_mo'   => '0',
          'price_yr'   => '0',
          'is_free'    => true,
          'desc'       => __( 'Perfect for solo projects and experimenting with what\'s possible.', 'themeflex' ),
          'features'   => [
            __( '3 projects', 'themeflex' ),
            __( '1 team member', 'themeflex' ),
            __( '5 GB storage', 'themeflex' ),
            __( 'Community support', 'themeflex' ),
            __( 'Basic analytics', 'themeflex' ),
          ],
          'cta_label'  => __( 'Get started free', 'themeflex' ),
          'cta_style'  => 'outline',
          'cta_url'    => '#signup',
        ],
        [
          'name'       => __( 'Pro', 'themeflex' ),
          'popular'    => true,
          'price_mo'   => '29',
          'price_yr'   => '23',
          'is_free'    => false,
          'desc'       => __( 'For growing teams who need powerful tools and more resources.', 'themeflex' ),
          'features'   => [
            __( 'Unlimited projects', 'themeflex' ),
            __( '10 team members', 'themeflex' ),
            __( '100 GB storage', 'themeflex' ),
            __( 'Priority support', 'themeflex' ),
            __( 'Advanced analytics + exports', 'themeflex' ),
          ],
          'cta_label'  => __( 'Start free trial', 'themeflex' ),
          'cta_style'  => 'filled',
          'cta_url'    => '#signup-pro',
        ],
        [
          'name'       => __( 'Business', 'themeflex' ),
          'popular'    => false,
          'price_mo'   => '99',
          'price_yr'   => '79',
          'is_free'    => false,
          'desc'       => __( 'Enterprise-grade features with custom SLAs for serious teams.', 'themeflex' ),
          'features'   => [
            __( 'Unlimited everything', 'themeflex' ),
            __( 'Unlimited team members', 'themeflex' ),
            __( '2 TB storage + CDN', 'themeflex' ),
            __( 'Dedicated support + SLA', 'themeflex' ),
            __( 'SSO, audit logs, RBAC', 'themeflex' ),
          ],
          'cta_label'  => __( 'Contact sales', 'themeflex' ),
          'cta_style'  => 'outline',
          'cta_url'    => '#contact',
        ],
      ];
      foreach ( $pricing_tiers as $tier ) : ?>
        <div class="tf-sv2-pricing-card<?php echo $tier['popular'] ? ' popular' : ''; ?>">
          <?php if ( $tier['popular'] ) : ?>
            <div class="tf-sv2-popular-badge"><?php esc_html_e( 'Most Popular', 'themeflex' ); ?></div>
          <?php endif; ?>

          <div class="tf-sv2-pricing-tier"><?php echo esc_html( $tier['name'] ); ?></div>

          <div class="tf-sv2-pricing-price">
            <?php if ( $tier['is_free'] ) : ?>
              <div class="tf-sv2-price-free"><?php esc_html_e( 'Free', 'themeflex' ); ?></div>
            <?php else : ?>
              <div class="tf-sv2-price-currency">$</div>
              <div class="tf-sv2-price-num tf-sv2-price-val" data-monthly="<?php echo esc_attr( $tier['price_mo'] ); ?>" data-annual="<?php echo esc_attr( $tier['price_yr'] ); ?>"><?php echo esc_html( $tier['price_mo'] ); ?></div>
              <div class="tf-sv2-price-period"><?php esc_html_e( '/mo', 'themeflex' ); ?></div>
            <?php endif; ?>
          </div>

          <p class="tf-sv2-pricing-desc"><?php echo esc_html( $tier['desc'] ); ?></p>
          <div class="tf-sv2-pricing-divider" aria-hidden="true"></div>

          <ul class="tf-sv2-pricing-features" aria-label="<?php echo esc_attr( sprintf( __( '%s features', 'themeflex' ), $tier['name'] ) ); ?>">
            <?php foreach ( $tier['features'] as $feat ) : ?>
              <li class="tf-sv2-pricing-feature">
                <?php echo tf_icon_get( 'check-circle', 16 ); ?>
                <?php echo esc_html( $feat ); ?>
              </li>
            <?php endforeach; ?>
          </ul>

          <a href="<?php echo esc_url( '#' . ltrim( $tier['cta_url'], '#' ) ); ?>"
             class="tf-sv2-pricing-cta tf-sv2-pricing-cta-<?php echo $tier['cta_style'] === 'filled' ? 'filled' : 'outline'; ?>">
            <?php echo esc_html( $tier['cta_label'] ); ?>
          </a>
        </div>
      <?php endforeach; ?>
    </div><!-- /.tf-sv2-pricing-grid -->

    <p class="tf-sv2-pricing-footnote">
      <?php echo tf_icon_get( 'shield-check', 14 ); ?>
      <?php esc_html_e( '14-day free trial on all paid plans. No credit card required.', 'themeflex' ); ?>
    </p>
  </div>
</section>

<?php
/* ══════════════════════════════════════════════════════════════════════════
   §6 — TESTIMONIALS
   ══════════════════════════════════════════════════════════════════════════ */
?>
<section class="tf-sv2-testi tf-sv2-section" aria-labelledby="tf-sv2-testi-h2">
  <div class="tf-sv2-wrap">
    <div class="tf-sv2-head">
      <div class="tf-sv2-label" aria-hidden="true"><?php echo tf_icon_get( 'star', 13 ); ?> <?php esc_html_e( 'Testimonials', 'themeflex' ); ?></div>
      <h2 id="tf-sv2-testi-h2"><?php esc_html_e( 'Loved by developers', 'themeflex' ); ?> <span class="tf-sv2-gradient"><?php esc_html_e( 'and founders', 'themeflex' ); ?></span></h2>
      <p><?php esc_html_e( 'Don\'t take our word for it. Here\'s what teams building with our platform have to say.', 'themeflex' ); ?></p>
    </div>

    <div class="tf-sv2-testi-grid">
      <?php
      $testimonials = [
        [
          'quote'   => __( 'Switching to this platform cut our deployment time from 45 minutes to under 60 seconds. The team couldn\'t be happier — we ship twice as much now.', 'themeflex' ),
          'name'    => 'Sarah Chen',
          'role'    => __( 'CTO at LoopStack', 'themeflex' ),
          'initials'=> 'SC',
          'color'   => '#a855f7',
        ],
        [
          'quote'   => __( 'The real-time collaboration features are genuinely magical. We stopped using Notion, Figma comments, and Slack threads for dev discussions — it\'s all here.', 'themeflex' ),
          'name'    => 'Marcus Reid',
          'role'    => __( 'Lead Engineer at Orbit.io', 'themeflex' ),
          'initials'=> 'MR',
          'color'   => '#ff5e2e',
        ],
        [
          'quote'   => __( 'I was skeptical about yet another platform, but the API-first design sold me instantly. Integrated our Stripe billing in 20 minutes flat.', 'themeflex' ),
          'name'    => 'Priya Nair',
          'role'    => __( 'Founder, Quill SaaS', 'themeflex' ),
          'initials'=> 'PN',
          'color'   => '#00d4ff',
        ],
        [
          'quote'   => __( 'The pricing is shockingly fair for what you get. We replaced four tools with this one platform and saved $800/month on our stack.', 'themeflex' ),
          'name'    => 'Tom Lindqvist',
          'role'    => __( 'Engineering Manager, Beacon', 'themeflex' ),
          'initials'=> 'TL',
          'color'   => '#10b981',
        ],
        [
          'quote'   => __( 'The analytics dashboard alone is worth it. I can finally see the full picture from first deploy to user engagement in one view.', 'themeflex' ),
          'name'    => 'Ana Kovač',
          'role'    => __( 'Product Lead at Syncwise', 'themeflex' ),
          'initials'=> 'AK',
          'color'   => '#fbbf24',
        ],
        [
          'quote'   => __( 'Support is incredible. Opened a ticket at 11pm on a Friday. By midnight they\'d diagnosed a CDN edge issue I didn\'t even know I had. Night and day vs. the old provider.', 'themeflex' ),
          'name'    => 'Jordan Wells',
          'role'    => __( 'Co-founder, Driftly', 'themeflex' ),
          'initials'=> 'JW',
          'color'   => '#22d3ee',
        ],
      ];
      foreach ( $testimonials as $t ) : ?>
        <article class="tf-sv2-testi-card">
          <div class="tf-sv2-stars" aria-label="<?php esc_attr_e( '5 out of 5 stars', 'themeflex' ); ?>">
            <?php for ( $i = 0; $i < 5; $i++ ) : ?>
              <svg class="tf-sv2-star" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.958a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.37 2.448a1 1 0 00-.364 1.118l1.286 3.958c.3.921-.755 1.688-1.54 1.118L10 15.347l-3.37 2.448c-.784.57-1.838-.197-1.539-1.118l1.286-3.958a1 1 0 00-.364-1.118L2.643 9.385c-.783-.57-.38-1.81.588-1.81h4.162a1 1 0 00.95-.69L9.049 2.927z"/></svg>
            <?php endfor; ?>
          </div>
          <blockquote class="tf-sv2-testi-quote"><?php echo esc_html( $t['quote'] ); ?></blockquote>
          <div class="tf-sv2-testi-author">
            <div class="tf-sv2-testi-avatar" style="background:<?php echo esc_attr( $t['color'] ); ?>" aria-hidden="true"><?php echo esc_html( $t['initials'] ); ?></div>
            <div>
              <div class="tf-sv2-testi-name"><?php echo esc_html( $t['name'] ); ?></div>
              <div class="tf-sv2-testi-role"><?php echo esc_html( $t['role'] ); ?></div>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div><!-- /.tf-sv2-testi-grid -->
  </div>
</section>

<?php
/* ══════════════════════════════════════════════════════════════════════════
   §7 — INTEGRATIONS
   ══════════════════════════════════════════════════════════════════════════ */
?>
<section class="tf-sv2-section" aria-labelledby="tf-sv2-int-h2">
  <div class="tf-sv2-wrap">
    <div class="tf-sv2-head">
      <div class="tf-sv2-label" aria-hidden="true"><?php echo tf_icon_get( 'globe', 13 ); ?> <?php esc_html_e( 'Integrations', 'themeflex' ); ?></div>
      <h2 id="tf-sv2-int-h2"><?php esc_html_e( 'Connects with your', 'themeflex' ); ?> <span class="tf-sv2-gradient-cyan"><?php esc_html_e( 'favorite tools', 'themeflex' ); ?></span></h2>
      <p><?php esc_html_e( 'Your workflow, your stack. Plug in the tools you already love — or build your own integrations via our open API.', 'themeflex' ); ?></p>
    </div>

    <div class="tf-sv2-integrations-grid">
      <?php
      $integrations = [
        [ 'name' => 'Slack',     'initial' => 'S', 'color' => '#4a154b' ],
        [ 'name' => 'GitHub',    'initial' => 'G', 'color' => '#24292e' ],
        [ 'name' => 'Figma',     'initial' => 'F', 'color' => '#a259ff' ],
        [ 'name' => 'Vercel',    'initial' => 'V', 'color' => '#000000' ],
        [ 'name' => 'Stripe',    'initial' => 'S', 'color' => '#635bff' ],
        [ 'name' => 'SendGrid',  'initial' => 'S', 'color' => '#1a82e2' ],
        [ 'name' => 'AWS',       'initial' => 'A', 'color' => '#ff9900' ],
        [ 'name' => 'Notion',    'initial' => 'N', 'color' => '#191919' ],
        [ 'name' => 'Linear',    'initial' => 'L', 'color' => '#5e6ad2' ],
        [ 'name' => 'Jira',      'initial' => 'J', 'color' => '#0052cc' ],
        [ 'name' => 'Zapier',    'initial' => 'Z', 'color' => '#ff4a00' ],
        [ 'name' => 'Make',      'initial' => 'M', 'color' => '#7b4fff' ],
      ];
      foreach ( $integrations as $int ) : ?>
        <div class="tf-sv2-integration-chip">
          <div class="tf-sv2-int-icon" style="background:<?php echo esc_attr( $int['color'] ); ?>" aria-hidden="true"><?php echo esc_html( $int['initial'] ); ?></div>
          <?php echo esc_html( $int['name'] ); ?>
        </div>
      <?php endforeach; ?>
    </div>

    <p class="tf-sv2-int-more">
      <?php esc_html_e( 'And', 'themeflex' ); ?>
      <a href="<?php echo esc_url( '#integrations' ); ?>"><?php esc_html_e( '200+ more integrations', 'themeflex' ); ?></a>
      <?php esc_html_e( 'in our marketplace.', 'themeflex' ); ?>
    </p>
  </div>
</section>

<?php
/* ══════════════════════════════════════════════════════════════════════════
   §8 — FAQ
   ══════════════════════════════════════════════════════════════════════════ */
?>
<section class="tf-sv2-faq tf-sv2-section" aria-labelledby="tf-sv2-faq-h2">
  <div class="tf-sv2-wrap">
    <div class="tf-sv2-head">
      <div class="tf-sv2-label" aria-hidden="true"><?php echo tf_icon_get( 'infinity', 13 ); ?> <?php esc_html_e( 'FAQ', 'themeflex' ); ?></div>
      <h2 id="tf-sv2-faq-h2"><?php esc_html_e( 'Questions we', 'themeflex' ); ?> <span class="tf-sv2-gradient"><?php esc_html_e( 'always get asked', 'themeflex' ); ?></span></h2>
      <p><?php esc_html_e( 'Still not sure? Here are the most common questions from teams evaluating our platform.', 'themeflex' ); ?></p>
    </div>

    <div class="tf-sv2-faq-list" id="tf-sv2-faq-list">
      <?php
      $faqs = [
        [
          'q' => __( 'How does the free plan differ from paid plans?', 'themeflex' ),
          'a' => __( 'The Free plan gives you 3 projects, 1 team member, and 5 GB of storage with community support. Paid plans unlock unlimited projects, multiple team members, more storage, priority support, and advanced analytics. There are no hidden feature gates — everything a tier promises is available from day one.', 'themeflex' ),
        ],
        [
          'q' => __( 'How do you handle data security and compliance?', 'themeflex' ),
          'a' => __( 'We are SOC 2 Type II certified and fully GDPR compliant. All data is encrypted at rest (AES-256) and in transit (TLS 1.3). We offer EU data residency on Business plans, regular third-party penetration testing, and a dedicated security team. Full audit logs are available on Business tier.', 'themeflex' ),
        ],
        [
          'q' => __( 'Can I migrate from my existing platform?', 'themeflex' ),
          'a' => __( 'Yes — we have one-click importers for the most popular platforms, a full REST API for custom migrations, and a dedicated migration guide in our docs. For Business customers, our team will handle the migration for you at no additional cost. Most teams are fully migrated within a day.', 'themeflex' ),
        ],
        [
          'q' => __( 'Are there API rate limits or bandwidth caps?', 'themeflex' ),
          'a' => __( 'Free plans include 10,000 API calls/month and 50 GB bandwidth. Pro plans come with 500,000 API calls/month and 500 GB bandwidth. Business plans have custom limits negotiated to match your traffic. We never hard-throttle in production — instead we notify you before you approach limits.', 'themeflex' ),
        ],
        [
          'q' => __( 'What kind of support is available?', 'themeflex' ),
          'a' => __( 'Free users get access to our documentation, community forum, and a shared support queue with 48-hour response times. Pro users receive priority email support with 8-hour response SLAs during business hours. Business customers get a dedicated Slack channel, 24/7 on-call support, and a named customer success manager.', 'themeflex' ),
        ],
      ];
      foreach ( $faqs as $i => $faq ) :
        $faq_id = 'tf-sv2-faq-' . $i;
        $answer_id = 'tf-sv2-faq-answer-' . $i;
      ?>
        <div class="tf-sv2-faq-item" id="<?php echo esc_attr( $faq_id ); ?>">
          <button class="tf-sv2-faq-q"
                  aria-expanded="false"
                  aria-controls="<?php echo esc_attr( $answer_id ); ?>">
            <?php echo esc_html( $faq['q'] ); ?>
            <span class="tf-sv2-faq-icon" aria-hidden="true">+</span>
          </button>
          <div class="tf-sv2-faq-a" id="<?php echo esc_attr( $answer_id ); ?>" role="region" aria-hidden="true">
            <div class="tf-sv2-faq-a-inner">
              <?php echo esc_html( $faq['a'] ); ?>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php
/* ══════════════════════════════════════════════════════════════════════════
   §9 — FINAL CTA
   ══════════════════════════════════════════════════════════════════════════ */
?>
<section class="tf-sv2-final-cta" aria-labelledby="tf-sv2-final-h2">
  <div class="tf-sv2-cta-inner">
    <div class="tf-sv2-label" aria-hidden="true" style="margin-bottom:24px"><?php echo tf_icon_get( 'gift', 13 ); ?> <?php esc_html_e( 'Get started today', 'themeflex' ); ?></div>
    <h2 id="tf-sv2-final-h2">
      <?php esc_html_e( 'Start shipping', 'themeflex' ); ?>
      <br>
      <span class="tf-sv2-gradient"><?php esc_html_e( 'today', 'themeflex' ); ?></span>
    </h2>
    <p><?php esc_html_e( 'Join 10,000+ teams who build faster, collaborate better, and ship more — without the headaches.', 'themeflex' ); ?></p>

    <a href="<?php echo esc_url( '#signup' ); ?>" class="tf-sv2-btn-primary" style="font-size:1.1rem;padding:18px 48px;margin-bottom:40px;display:inline-flex;">
      <?php echo tf_icon_get( 'rocket', 20 ); ?>
      <?php esc_html_e( 'Start free trial', 'themeflex' ); ?>
    </a>

    <div class="tf-sv2-social-proof-avatars" aria-label="<?php esc_attr_e( 'Joined by thousands of teams', 'themeflex' ); ?>">
      <?php
      $sp_avatars = [
        [ 'i' => 'AK', 'c' => '#a855f7' ],
        [ 'i' => 'JS', 'c' => '#00d4ff' ],
        [ 'i' => 'MR', 'c' => '#ff5e2e' ],
        [ 'i' => 'TL', 'c' => '#10b981' ],
        [ 'i' => 'SC', 'c' => '#fbbf24' ],
        [ 'i' => 'PN', 'c' => '#22d3ee' ],
      ];
      foreach ( $sp_avatars as $av ) : ?>
        <div class="tf-sv2-sp-avatar" style="background:<?php echo esc_attr( $av['c'] ); ?>" aria-hidden="true"><?php echo esc_html( $av['i'] ); ?></div>
      <?php endforeach; ?>
      <span class="tf-sv2-sp-text">
        <?php esc_html_e( 'Join', 'themeflex' ); ?> <strong><?php esc_html_e( '10k+ teams', 'themeflex' ); ?></strong> <?php esc_html_e( 'already building', 'themeflex' ); ?>
      </span>
    </div>
  </div>
</section>

</main><!-- /#tf-saas-main -->

<script>
/* ══════════════════════════════════════════════════════════════════════════
   ThemeFlex SaaS v2 — Vanilla JS interactions
   Pricing toggle + FAQ accordion. Zero dependencies.
   ══════════════════════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  /* ── Pricing toggle ──────────────────────────────────────────────────── */
  var toggleEl   = document.getElementById('tf-sv2-billing-toggle');
  var monthLabel = document.getElementById('tf-sv2-monthly-label');
  var annualLabel = document.getElementById('tf-sv2-annual-label');
  var priceVals  = document.querySelectorAll('.tf-sv2-price-val');
  var isAnnual   = false;

  function updatePricing () {
    priceVals.forEach(function (el) {
      var next = isAnnual ? el.getAttribute('data-annual') : el.getAttribute('data-monthly');
      el.style.opacity = '0';
      setTimeout(function () {
        el.textContent = next;
        el.style.opacity = '1';
      }, 140);
    });
    if (isAnnual) {
      toggleEl.classList.add('annual');
      toggleEl.setAttribute('aria-checked', 'true');
      monthLabel.classList.remove('active');
      annualLabel.classList.add('active');
    } else {
      toggleEl.classList.remove('annual');
      toggleEl.setAttribute('aria-checked', 'false');
      annualLabel.classList.remove('active');
      monthLabel.classList.add('active');
    }
  }

  if (toggleEl) {
    toggleEl.addEventListener('click', function () {
      isAnnual = !isAnnual;
      updatePricing();
    });
    toggleEl.addEventListener('keydown', function (e) {
      if (e.key === ' ' || e.key === 'Enter') {
        e.preventDefault();
        isAnnual = !isAnnual;
        updatePricing();
      }
    });
  }

  /* ── FAQ accordion ───────────────────────────────────────────────────── */
  var faqItems = document.querySelectorAll('.tf-sv2-faq-item');

  faqItems.forEach(function (item) {
    var btn    = item.querySelector('.tf-sv2-faq-q');
    var answer = item.querySelector('.tf-sv2-faq-a');

    if (!btn || !answer) return;

    btn.addEventListener('click', function () {
      var isOpen = item.classList.contains('open');

      /* Close all open items */
      faqItems.forEach(function (other) {
        if (other !== item && other.classList.contains('open')) {
          other.classList.remove('open');
          var ob = other.querySelector('.tf-sv2-faq-q');
          var oa = other.querySelector('.tf-sv2-faq-a');
          if (ob) ob.setAttribute('aria-expanded', 'false');
          if (oa) oa.setAttribute('aria-hidden', 'true');
        }
      });

      /* Toggle current */
      if (isOpen) {
        item.classList.remove('open');
        btn.setAttribute('aria-expanded', 'false');
        answer.setAttribute('aria-hidden', 'true');
      } else {
        item.classList.add('open');
        btn.setAttribute('aria-expanded', 'true');
        answer.setAttribute('aria-hidden', 'false');
      }
    });
  });

})();
</script>

<?php get_footer(); ?>
