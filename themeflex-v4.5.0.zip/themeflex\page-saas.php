<?php
/**
 * Template Name: SaaS Landing Page
 * Template Post Type: page
 *
 * ThemeFlex — Premium SaaS Homepage Template
 * Namespace  : --sa-*
 * Fonts      : Syne (headings) + Inter (body)
 * Palette    : Deep #080D1A | Electric #3B82F6 | Cyan #06B6D4 | Graphite #1E2A3B | Mist #E8F4FD
 */

if ( ! defined( 'ABSPATH' ) ) exit;
/* ─── DATA ──────────────────────────────────────────────── */

$sa_features = [
  [
    'icon'   => '⚡',
    'title'  => 'Lightning Fast Deployment',
    'desc'   => 'Deploy your entire stack in under 60 seconds. Our CLI handles build, test, and infrastructure provisioning — zero downtime, every time.',
    'colour' => '#3B82F6',
    'tags'   => ['CI/CD', 'Kubernetes', 'Docker'],
  ],
  [
    'icon'   => '🔒',
    'title'  => 'Enterprise-Grade Security',
    'desc'   => 'SOC 2 Type II certified. End-to-end encryption, granular RBAC, SAML SSO, and automated vulnerability scanning baked in from day one.',
    'colour' => '#06B6D4',
    'tags'   => ['SOC 2', 'RBAC', 'SAML'],
  ],
  [
    'icon'   => '📊',
    'title'  => 'Real-Time Analytics',
    'desc'   => 'Understand exactly what your users are doing with sub-second event streaming. Build custom dashboards without leaving the platform.',
    'colour' => '#8B5CF6',
    'tags'   => ['Streaming', 'Dashboards', 'SQL'],
  ],
  [
    'icon'   => '🔗',
    'title'  => 'Native Integrations',
    'desc'   => 'Connect Slack, GitHub, Jira, Salesforce, and 180+ tools via our OAuth connector library. If we don\'t have it, our public API does.',
    'colour' => '#10B981',
    'tags'   => ['REST API', 'OAuth', 'Webhooks'],
  ],
  [
    'icon'   => '🌍',
    'title'  => 'Global Edge Network',
    'desc'   => '24 PoPs across 5 continents. Traffic is routed to the nearest edge node automatically, cutting P95 latency by up to 70% worldwide.',
    'colour' => '#F59E0B',
    'tags'   => ['CDN', 'Edge', 'Multi-region'],
  ],
  [
    'icon'   => '🤖',
    'title'  => 'AI-Powered Automation',
    'desc'   => 'Automate repetitive workflows with our built-in AI engine. Smart triggers, conditional branching, and natural-language rule building.',
    'colour' => '#EC4899',
    'tags'   => ['AI/ML', 'Automation', 'NLP'],
  ],
];

$sa_testimonials = [
  [
    'quote'    => 'We cut our deployment cycle from 4 hours to 6 minutes. Not a typo — 6 minutes. The ROI was visible within the first sprint.',
    'name'     => 'Elisa Fontaine',
    'role'     => 'VP Engineering, Cascade Systems',
    'initials' => 'EF',
    'colour'   => '#3B82F6',
    'stars'    => 5,
  ],
  [
    'quote'    => 'The analytics dashboard alone saved us two full-time analysts. We shipped the entire migration in a weekend and haven\'t looked back.',
    'name'     => 'Daisuke Yamamoto',
    'role'     => 'CTO, Helion Finance',
    'initials' => 'DY',
    'colour'   => '#06B6D4',
    'stars'    => 5,
  ],
  [
    'quote'    => 'Security team signed off in a week. That never happens. SOC 2 compliance out-of-the-box and SAML SSO ready in minutes — genuinely impressive.',
    'name'     => 'Ngozi Adeyemi',
    'role'     => 'CISO, Vantara Financial',
    'initials' => 'NA',
    'colour'   => '#8B5CF6',
    'stars'    => 5,
  ],
  [
    'quote'    => 'We evaluated six platforms. This was the only one where the onboarding actually worked. Live in prod within 48 hours of signing the contract.',
    'name'     => 'Lucas Svensson',
    'role'     => 'Head of Platform, Nordlight AG',
    'initials' => 'LS',
    'colour'   => '#10B981',
    'stars'    => 5,
  ],
];

$sa_faqs = [
  ['q'=>'How long does onboarding take?',
   'a'=>'Most teams are live in production within 48 hours. Our onboarding team provides a dedicated Slack channel, a structured checklist, and a live kickoff call. Enterprise customers receive a dedicated solutions engineer for the first 90 days.'],
  ['q'=>'Does it work with our existing infrastructure?',
   'a'=>'Yes. We support AWS, GCP, Azure, and on-prem environments. Our agent-based architecture means no firewall rules, no VPC peering, and no infrastructure changes required. If you run Kubernetes, Docker, or bare metal — we connect to it.'],
  ['q'=>'What level of support do Pro and Enterprise plans include?',
   'a'=>'Pro plans include 4-hour response SLA via email and chat, 24/5. Enterprise plans add 24/7 phone escalation, a 1-hour SLA for P1 incidents, and a named customer success manager. All plans have access to our community forum and knowledge base.'],
  ['q'=>'Can I migrate from a competitor without downtime?',
   'a'=>'Our migration tool imports data from 12 major platforms. We run a parallel shadow period where both systems receive traffic, validate consistency, then cut over at the point of your choosing — typically zero-downtime, often under 2 hours end to end.'],
  ['q'=>'Is there a self-hosted or on-prem option?',
   'a'=>'Enterprise plans include an on-prem deployment option running in your own VPC or private data centre. We provide the Helm chart, the operator, and a dedicated infra engineer for the initial deployment. Air-gapped environments are supported.'],
  ['q'=>'How is pricing calculated for large teams?',
   'a'=>'Pro scales to 15 seats. Enterprise is per-seat with volume discounts kicking in at 50, 100, and 500 seats. Annual commitments receive an additional 15% discount on top of the volume pricing. Contact sales for a custom quote.'],
];

$sa_metrics = [
  ['v'=>'2.4B+',  'l'=>'Events processed daily'],
  ['v'=>'70%',    'l'=>'Avg. latency reduction'],
  ['v'=>'99.99%', 'l'=>'Platform uptime SLA'],
  ['v'=>'6 min',  'l'=>'Median deploy time'],
];

$sa_logos = ['Cascade Systems','Helion Finance','Nordlight AG','Vantara Group','Pulsar Media','Brightfield','Alchemy Tech','Meridian Cloud'];

/* ─── HTML ──────────────────────────────────────────────── */
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
/* ── CUSTOM PROPERTIES ─────────────────────────────── */
:root{
  --sa-deep    : #080D1A;
  --sa-electric: #3B82F6;
  --sa-cyan    : #06B6D4;
  --sa-graphite: #1E2A3B;
  --sa-mist    : #E8F4FD;
  --sa-surface : #0F1825;
  --sa-card    : #131F30;
  --sa-border  : rgba(59,130,246,.15);
  --sa-head    : 'Syne', sans-serif;
  --sa-body    : 'Inter', sans-serif;
  --sa-r       : 12px;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
html{scroll-behavior:smooth;}
body{background:var(--sa-deep);color:#94a3b8;font-family:var(--sa-body);line-height:1.7;overflow-x:hidden;}
a{text-decoration:none;color:inherit;}

/* ── LAYOUT ─────────────────────────────────────── */
.sa-wrap{max-width:1200px;margin:0 auto;padding:0 24px;}
.sa-wrap--narrow{max-width:800px;margin:0 auto;padding:0 24px;}

/* ── UTILITIES ──────────────────────────────────── */
.sa-eyebrow{font-family:var(--sa-body);font-size:.7rem;font-weight:600;text-transform:uppercase;letter-spacing:.2em;color:var(--sa-cyan);margin:0 0 10px;}
.sa-h2{font-family:var(--sa-head);font-size:clamp(1.9rem,4vw,2.8rem);font-weight:800;color:#ffffff;line-height:1.15;letter-spacing:-.025em;margin:0 0 14px;}
.sa-lead{font-size:.97rem;color:#64748b;line-height:1.75;max-width:520px;margin:0 auto 48px;}
.sa-gradient-text{background:linear-gradient(135deg,var(--sa-electric) 0%,var(--sa-cyan) 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;}

/* ── BUTTONS ────────────────────────────────────── */
.sa-btn{display:inline-flex;align-items:center;gap:8px;font-family:var(--sa-body);font-size:.88rem;font-weight:600;padding:13px 24px;border-radius:8px;border:none;cursor:pointer;transition:transform .2s,box-shadow .2s,opacity .2s;}
.sa-btn:hover{transform:translateY(-2px);opacity:.92;}
.sa-btn--primary{background:linear-gradient(135deg,var(--sa-electric),var(--sa-cyan));color:#ffffff;box-shadow:0 8px 24px rgba(59,130,246,.3);}
.sa-btn--primary:hover{box-shadow:0 14px 36px rgba(59,130,246,.4);}
.sa-btn--ghost{background:transparent;color:#c8d8ee;border:1.5px solid rgba(255,255,255,.15);}
.sa-btn--ghost:hover{border-color:rgba(255,255,255,.35);color:#fff;}
.sa-btn--electric{background:var(--sa-electric);color:#ffffff;}

/* ── HERO ───────────────────────────────────────── */
.sa-hero{padding:100px 0 0;background:var(--sa-deep);text-align:center;position:relative;overflow:hidden;}
.sa-hero-bg{position:absolute;inset:0;background:radial-gradient(ellipse 80% 60% at 50% -10%,rgba(59,130,246,.12) 0%,transparent 70%);}
.sa-hero-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(59,130,246,.06) 1px,transparent 1px),linear-gradient(90deg,rgba(59,130,246,.06) 1px,transparent 1px);background-size:40px 40px;}

/* ── BADGE ──────────────────────────────────────── */
.sa-badge{display:inline-flex;align-items:center;gap:8px;background:rgba(59,130,246,.1);border:1px solid rgba(59,130,246,.25);border-radius:40px;padding:5px 14px 5px 8px;font-size:.75rem;color:#93c5fd;font-weight:500;margin-bottom:24px;}
.sa-badge-dot{width:8px;height:8px;border-radius:50%;background:var(--sa-electric);animation:sa-blink 2s ease-in-out infinite;}
@keyframes sa-blink{0%,100%{opacity:1;}50%{opacity:.3;}}

/* ── DASHBOARD CSS ART ──────────────────────────── */
.sa-dashboard{position:relative;max-width:900px;margin:56px auto 0;height:400px;}
.sa-dash-window{background:var(--sa-card);border:1px solid rgba(255,255,255,.08);border-radius:12px;overflow:hidden;box-shadow:0 40px 80px rgba(0,0,0,.6),0 0 0 1px rgba(59,130,246,.12);position:absolute;inset:0;}
.sa-dash-titlebar{height:36px;background:#0b1420;border-bottom:1px solid rgba(255,255,255,.06);display:flex;align-items:center;padding:0 16px;gap:8px;}
.sa-dash-dot{width:10px;height:10px;border-radius:50%;}
.sa-dash-body{display:grid;grid-template-columns:200px 1fr;height:calc(100% - 36px);}
.sa-dash-sidebar{background:#0b1420;border-right:1px solid rgba(255,255,255,.05);padding:16px 12px;display:flex;flex-direction:column;gap:6px;}
.sa-dash-nav-item{height:28px;border-radius:6px;display:flex;align-items:center;padding:0 10px;gap:8px;font-size:.7rem;color:#475569;}
.sa-dash-nav-item--active{background:rgba(59,130,246,.15);color:#93c5fd;}
.sa-dash-nav-icon{width:12px;height:12px;border-radius:3px;background:currentColor;opacity:.5;flex-shrink:0;}
.sa-dash-main{padding:20px;display:grid;grid-template-columns:repeat(3,1fr);grid-template-rows:auto auto 1fr;gap:12px;}
.sa-kpi-card{background:#0b1420;border:1px solid rgba(255,255,255,.06);border-radius:8px;padding:14px;}
.sa-kpi-val{font-family:var(--sa-head);font-size:1.4rem;font-weight:800;color:#ffffff;line-height:1;}
.sa-kpi-label{font-size:.62rem;color:#475569;text-transform:uppercase;letter-spacing:.1em;margin-top:4px;}
.sa-kpi-trend{font-size:.65rem;margin-top:8px;}
.sa-chart-area{grid-column:1/-1;background:#0b1420;border:1px solid rgba(255,255,255,.06);border-radius:8px;padding:14px;display:flex;align-items:flex-end;gap:4px;height:100px;}
.sa-chart-bar{flex:1;border-radius:3px 3px 0 0;transition:opacity .2s;}
.sa-chart-bar:hover{opacity:.8;}
.sa-table-area{grid-column:1/-1;background:#0b1420;border:1px solid rgba(255,255,255,.06);border-radius:8px;padding:14px;}

/* ── FEATURE CARDS ──────────────────────────────── */
.sa-feature-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;}
.sa-feat-card{background:var(--sa-card);border:1px solid rgba(255,255,255,.06);border-radius:var(--sa-r);padding:28px;transition:border-color .25s,transform .25s,box-shadow .25s;}
.sa-feat-card:hover{border-color:var(--sa-electric);transform:translateY(-4px);box-shadow:0 20px 48px rgba(0,0,0,.4);}
.sa-feat-icon{font-size:1.6rem;margin-bottom:14px;}
.sa-feat-title{font-family:var(--sa-head);font-size:1.05rem;font-weight:700;color:#ffffff;margin-bottom:8px;}
.sa-feat-desc{font-size:.85rem;color:#64748b;line-height:1.7;}
.sa-feat-tags{display:flex;gap:6px;flex-wrap:wrap;margin-top:16px;}
.sa-feat-tag{font-size:.65rem;font-weight:600;text-transform:uppercase;letter-spacing:.1em;padding:3px 8px;border-radius:4px;background:rgba(59,130,246,.1);color:#60a5fa;border:1px solid rgba(59,130,246,.15);}

/* ── METRICS BAND ───────────────────────────────── */
.sa-metrics-band{background:linear-gradient(135deg,#0e1d32 0%,#0a1522 100%);border-top:1px solid rgba(59,130,246,.12);border-bottom:1px solid rgba(59,130,246,.12);padding:64px 0;}
.sa-metrics-inner{display:grid;grid-template-columns:repeat(4,1fr);gap:0;}
.sa-metric{text-align:center;padding:0 24px;border-right:1px solid rgba(255,255,255,.06);}
.sa-metric:last-child{border-right:none;}
.sa-metric-val{font-family:var(--sa-head);font-size:2.8rem;font-weight:800;color:#ffffff;line-height:1;letter-spacing:-.04em;background:linear-gradient(135deg,#ffffff 20%,var(--sa-cyan));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;}
.sa-metric-label{font-size:.75rem;color:#475569;text-transform:uppercase;letter-spacing:.1em;margin-top:6px;}

/* ── TESTIMONIALS ───────────────────────────────── */
.sa-tgrid{display:grid;grid-template-columns:repeat(2,1fr);gap:20px;}
.sa-tcard{background:var(--sa-card);border:1px solid rgba(255,255,255,.06);border-radius:var(--sa-r);padding:28px;position:relative;}
.sa-tcard::before{content:'"';position:absolute;top:12px;right:20px;font-size:5rem;color:rgba(255,255,255,.03);font-family:var(--sa-head);line-height:1;}
.sa-stars{color:#F59E0B;font-size:.85rem;margin-bottom:14px;letter-spacing:2px;}
.sa-tquote{font-size:.9rem;color:#94a3b8;line-height:1.75;margin-bottom:20px;font-style:italic;}
.sa-tauthor{display:flex;align-items:center;gap:12px;}
.sa-tavatar{width:42px;height:42px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:var(--sa-head);font-weight:700;font-size:.85rem;color:#fff;flex-shrink:0;}
.sa-tname{font-family:var(--sa-head);font-size:.88rem;font-weight:700;color:#ffffff;}
.sa-trole{font-size:.75rem;color:#475569;}

/* ── FAQ ────────────────────────────────────────── */
.sa-faq-list{list-style:none;padding:0;margin:0;}
.sa-faq-item{border-bottom:1px solid rgba(255,255,255,.06);}
.sa-faq-btn{display:flex;align-items:center;justify-content:space-between;gap:16px;width:100%;background:none;border:none;cursor:pointer;padding:20px 0;font-family:var(--sa-head);font-size:.97rem;font-weight:600;color:#ffffff;text-align:left;transition:color .2s;}
.sa-faq-btn:hover{color:var(--sa-cyan);}
.sa-faq-icon{width:22px;height:22px;border-radius:50%;background:rgba(59,130,246,.15);flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:1rem;color:var(--sa-electric);transition:transform .3s,background .3s;}
.sa-faq-item.sa-open .sa-faq-icon{transform:rotate(45deg);background:rgba(59,130,246,.3);}
.sa-faq-body{max-height:0;overflow:hidden;transition:max-height .4s ease;}
.sa-faq-body-inner{padding:0 0 20px;font-size:.88rem;color:#64748b;line-height:1.8;}

/* ── SCROLL REVEAL ──────────────────────────────── */
.sa-reveal{opacity:0;transform:translateY(20px);transition:opacity .55s ease,transform .55s ease;}
.sa-reveal.sa-visible{opacity:1;transform:none;}

/* ── RESPONSIVE ─────────────────────────────────── */
@media(max-width:900px){
  .sa-feature-grid{grid-template-columns:repeat(2,1fr);}
  .sa-metrics-inner{grid-template-columns:repeat(2,1fr);}
  .sa-metric{border-right:none;border-bottom:1px solid rgba(255,255,255,.06);padding:24px 0;}
  .sa-metric:last-child{border-bottom:none;}
  .sa-tgrid{grid-template-columns:1fr;}
  .sa-dash-body{grid-template-columns:1fr;}
  .sa-dash-sidebar{display:none;}
}
@media(max-width:640px){
  .sa-feature-grid{grid-template-columns:1fr;}
}
</style>
<?php get_header(); ?>
<div class="sa-page">
>
<?php wp_body_open(); ?>

<!-- ═══════════════════════════════════════════════
     HERO
     ═══════════════════════════════════════════════ -->
<section class="sa-hero">
  <div class="sa-hero-bg"></div>
  <div class="sa-hero-grid"></div>
  <div class="sa-wrap" style="position:relative;z-index:1;">
    <div class="sa-badge sa-reveal"><span class="sa-badge-dot"></span>Now with AI-powered automation — <span style="color:#ffffff;font-weight:600;">What's new →</span></div>
    <h1 class="sa-reveal" style="font-family:'Syne',sans-serif;font-size:clamp(2.8rem,7vw,5rem);font-weight:800;color:#ffffff;line-height:1.08;letter-spacing:-.035em;max-width:760px;margin:0 auto 20px;">
      The platform your<br>engineering team <span class="sa-gradient-text">deserves</span>
    </h1>
    <p class="sa-reveal" style="font-size:1.1rem;color:#64748b;max-width:520px;margin:0 auto 36px;line-height:1.75;">Deploy faster. Scale smarter. Sleep better. Everything your team needs to ship great software — unified in a single, opinionated platform.</p>
    <div class="sa-reveal" style="display:flex;gap:14px;justify-content:center;flex-wrap:wrap;margin-bottom:16px;">
      <a href="#" class="sa-btn sa-btn--primary">Start for free &rarr;</a>
      <a href="#" class="sa-btn sa-btn--ghost">Watch demo (3 min)</a>
    </div>
    <p class="sa-reveal" style="font-size:.75rem;color:#334155;margin-bottom:56px;">No credit card required · Free 14-day Pro trial · SOC 2 Type II certified</p>
  </div>

  <!-- CSS dashboard illustration -->
  <div class="sa-wrap" style="position:relative;z-index:1;">
    <div class="sa-dashboard sa-reveal">
      <div class="sa-dash-window">
        <!-- titlebar -->
        <div class="sa-dash-titlebar">
          <div class="sa-dash-dot" style="background:#FF5F57;"></div>
          <div class="sa-dash-dot" style="background:#FEBC2E;"></div>
          <div class="sa-dash-dot" style="background:#28C840;"></div>
          <div style="flex:1;height:14px;background:rgba(255,255,255,.04);border-radius:7px;margin-left:12px;max-width:200px;"></div>
        </div>
        <!-- body -->
        <div class="sa-dash-body">
          <!-- sidebar -->
          <div class="sa-dash-sidebar">
            <?php
            $sa_navitems=[['Dashboard',true],['Deployments',false],['Analytics',false],['Integrations',false],['Team',false],['Settings',false]];
            foreach($sa_navitems as $n):
            ?>
            <div class="sa-dash-nav-item <?php echo $n[1]?'sa-dash-nav-item--active':''; ?>">
              <div class="sa-dash-nav-icon"></div>
              <span style="font-size:.68rem;"><?php echo esc_html($n[0]); ?></span>
            </div>
            <?php endforeach; ?>
            <div style="flex:1;"></div>
            <div style="height:28px;background:rgba(59,130,246,.1);border-radius:6px;display:flex;align-items:center;padding:0 10px;gap:6px;">
              <div style="width:18px;height:18px;border-radius:50%;background:linear-gradient(135deg,#3B82F6,#06B6D4);"></div>
              <div style="height:6px;flex:1;background:rgba(255,255,255,.06);border-radius:3px;"></div>
            </div>
          </div>
          <!-- main content -->
          <div class="sa-dash-main">
            <?php
            $sa_kpis=[
              ['2,847','Deployments','↑ 12%','#22c55e'],
              ['99.99%','Uptime','→ Stable','#60a5fa'],
              ['6 min','Avg. Deploy','↓ 41%','#22c55e'],
            ];
            foreach($sa_kpis as $k):
            ?>
            <div class="sa-kpi-card">
              <div class="sa-kpi-val"><?php echo esc_html($k[0]); ?></div>
              <div class="sa-kpi-label"><?php echo esc_html($k[1]); ?></div>
              <div class="sa-kpi-trend" style="color:<?php echo esc_attr($k[3]); ?>;"><?php echo esc_html($k[2]); ?> vs last month</div>
            </div>
            <?php endforeach; ?>
            <!-- bar chart -->
            <div class="sa-chart-area">
              <?php
              srand(crc32('sa-chart'));
              $sa_chart_heights=[28,35,24,42,38,55,48,62,58,72,64,80,68,76,84,88,76,92,80,96,88,100,92,96];
              foreach($sa_chart_heights as $ci=>$h):
                $is_highlight=($ci>=20);
                $col=$is_highlight?'linear-gradient(to top,#3B82F6,#06B6D4)':'rgba(59,130,246,.2)';
              ?>
              <div class="sa-chart-bar" style="height:<?php echo $h; ?>%;background:<?php echo $col; ?>;"></div>
              <?php endforeach; ?>
            </div>
            <!-- table preview -->
            <div class="sa-table-area">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
                <span style="font-size:.65rem;color:#475569;text-transform:uppercase;letter-spacing:.1em;">Recent Deployments</span>
                <div style="height:16px;width:40px;background:rgba(59,130,246,.15);border-radius:4px;"></div>
              </div>
              <?php for($tr=0;$tr<3;$tr++): ?>
              <div style="display:flex;align-items:center;gap:10px;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.04);">
                <div style="width:6px;height:6px;border-radius:50%;background:<?php echo ['#22c55e','#22c55e','#F59E0B'][$tr]; ?>;flex-shrink:0;"></div>
                <div style="height:8px;flex:1;background:rgba(255,255,255,.05);border-radius:4px;"></div>
                <div style="height:8px;width:40px;background:rgba(255,255,255,.04);border-radius:4px;"></div>
              </div>
              <?php endfor; ?>
            </div>
          </div>
        </div>
      </div>
      <!-- bottom fade -->
      <div style="position:absolute;bottom:0;left:0;right:0;height:120px;background:linear-gradient(to top,var(--sa-deep) 0%,transparent 100%);border-radius:0 0 12px 12px;"></div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     LOGO WALL
     ═══════════════════════════════════════════════ -->
<section style="padding:64px 0;background:var(--sa-surface);border-bottom:1px solid rgba(255,255,255,.05);">
  <div class="sa-wrap" style="text-align:center;">
    <p style="font-size:.72rem;color:#334155;text-transform:uppercase;letter-spacing:.2em;margin-bottom:32px;">Powering engineering teams at</p>
    <div style="display:flex;flex-wrap:wrap;justify-content:center;gap:32px 48px;">
      <?php foreach($sa_logos as $logo): ?>
      <div style="font-family:'Syne',sans-serif;font-size:.93rem;font-weight:700;color:#334155;letter-spacing:-.01em;transition:color .2s;" onmouseenter="this.style.color='#64748b'" onmouseleave="this.style.color='#334155'"><?php echo esc_html($logo); ?></div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     FEATURES
     ═══════════════════════════════════════════════ -->
<section style="padding:96px 0;background:var(--sa-deep);">
  <div class="sa-wrap">
    <div style="text-align:center;margin-bottom:56px;" class="sa-reveal">
      <p class="sa-eyebrow">Platform Capabilities</p>
      <h2 class="sa-h2">Everything you need.<br>Nothing you don't.</h2>
      <p class="sa-lead">Six core modules. One coherent platform. Built by engineers, for engineering teams that ship at scale.</p>
    </div>
    <div class="sa-feature-grid">
      <?php foreach($sa_features as $f): ?>
      <div class="sa-feat-card sa-reveal">
        <div class="sa-feat-icon"><?php echo $f['icon']; ?></div>
        <h3 class="sa-feat-title"><?php echo esc_html($f['title']); ?></h3>
        <p class="sa-feat-desc"><?php echo esc_html($f['desc']); ?></p>
        <div class="sa-feat-tags">
          <?php foreach($f['tags'] as $tag): ?>
          <span class="sa-feat-tag" style="color:<?php echo esc_attr($f['colour']); ?>;background:<?php echo esc_attr($f['colour']); ?>18;border-color:<?php echo esc_attr($f['colour']); ?>30;"><?php echo esc_html($tag); ?></span>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     METRICS BAND
     ═══════════════════════════════════════════════ -->
<section class="sa-metrics-band">
  <div class="sa-wrap">
    <div class="sa-metrics-inner">
      <?php foreach($sa_metrics as $m): ?>
      <div class="sa-metric sa-reveal">
        <div class="sa-metric-val"><?php echo esc_html($m['v']); ?></div>
        <div class="sa-metric-label"><?php echo esc_html($m['l']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     TESTIMONIALS
     ═══════════════════════════════════════════════ -->
<section style="padding:96px 0;background:var(--sa-deep);">
  <div class="sa-wrap">
    <div style="text-align:center;margin-bottom:56px;" class="sa-reveal">
      <p class="sa-eyebrow">Social Proof</p>
      <h2 class="sa-h2">Loved by the teams<br>building the future</h2>
    </div>
    <div class="sa-tgrid">
      <?php foreach($sa_testimonials as $t): ?>
      <div class="sa-tcard sa-reveal">
        <div class="sa-stars"><?php echo str_repeat('★', $t['stars']); ?></div>
        <p class="sa-tquote">"<?php echo esc_html($t['quote']); ?>"</p>
        <div class="sa-tauthor">
          <div class="sa-tavatar" style="background:<?php echo esc_attr($t['colour']); ?>;"><?php echo esc_html($t['initials']); ?></div>
          <div>
            <div class="sa-tname"><?php echo esc_html($t['name']); ?></div>
            <div class="sa-trole"><?php echo esc_html($t['role']); ?></div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     FAQ
     ═══════════════════════════════════════════════ -->
<section style="padding:96px 0;background:var(--sa-surface);border-top:1px solid rgba(255,255,255,.05);">
  <div class="sa-wrap--narrow">
    <div style="text-align:center;margin-bottom:48px;" class="sa-reveal">
      <p class="sa-eyebrow">Have Questions?</p>
      <h2 class="sa-h2">Frequently Asked Questions</h2>
    </div>
    <ul class="sa-faq-list" role="list">
      <?php foreach($sa_faqs as $idx=>$f): ?>
      <li class="sa-faq-item sa-reveal" role="listitem">
        <button class="sa-faq-btn" aria-expanded="false" aria-controls="sa-faq-<?php echo $idx; ?>">
          <?php echo esc_html($f['q']); ?>
          <span class="sa-faq-icon" aria-hidden="true">+</span>
        </button>
        <div class="sa-faq-body" id="sa-faq-<?php echo $idx; ?>" role="region">
          <div class="sa-faq-body-inner"><?php echo esc_html($f['a']); ?></div>
        </div>
      </li>
      <?php endforeach; ?>
    </ul>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     PRICING TEASER
     ═══════════════════════════════════════════════ -->
<section style="padding:96px 0;background:var(--sa-deep);">
  <div class="sa-wrap">
    <div style="text-align:center;margin-bottom:56px;" class="sa-reveal">
      <p class="sa-eyebrow">Pricing</p>
      <h2 class="sa-h2">Simple plans. No surprises.</h2>
      <p style="color:#64748b;max-width:440px;margin:14px auto 0;line-height:1.75;font-family:'Inter',sans-serif;">Start free, scale as you grow. All paid plans include a 14-day free trial.</p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px;" class="sa-reveal">
      <?php
      $sa_price_teaser=[
        ['Free','$0/mo','3 projects · 1 seat · Core features','Get Started','#1E2A3B',false],
        ['Pro','$49/mo','Unlimited projects · 15 seats · All features','Start Free Trial','#3B82F6',true],
        ['Enterprise','Custom','Unlimited · SSO · On-prem · Dedicated CSM','Contact Sales','#1E2A3B',false],
      ];
      foreach($sa_price_teaser as $pt):
      ?>
      <div style="background:<?php echo esc_attr($pt[4]); ?>;border:<?php echo $pt[5]?'2px solid #3B82F6':'1px solid rgba(255,255,255,.07)'; ?>;border-radius:var(--sa-r);padding:32px;text-align:center;<?php echo $pt[5]?'transform:scale(1.04);box-shadow:0 24px 56px rgba(59,130,246,.25);':''; ?>">
        <div style="font-family:'Syne',sans-serif;font-size:.8rem;font-weight:700;text-transform:uppercase;letter-spacing:.14em;color:<?php echo $pt[5]?'#93c5fd':'#475569'; ?>;margin-bottom:8px;"><?php echo esc_html($pt[0]); ?></div>
        <div style="font-family:'Syne',sans-serif;font-size:2rem;font-weight:800;color:#ffffff;margin-bottom:8px;"><?php echo esc_html($pt[1]); ?></div>
        <p style="font-size:.82rem;color:#475569;line-height:1.6;margin-bottom:24px;"><?php echo esc_html($pt[2]); ?></p>
        <a href="#" style="display:block;text-align:center;padding:12px;border-radius:8px;font-size:.85rem;font-weight:600;text-decoration:none;<?php echo $pt[5]?'background:#3B82F6;color:#fff;':'background:rgba(255,255,255,.06);color:#94a3b8;border:1px solid rgba(255,255,255,.1);'; ?>"><?php echo esc_html($pt[3]); ?></a>
      </div>
      <?php endforeach; ?>
    </div>
    <p style="text-align:center;color:#334155;font-size:.78rem;margin-top:24px;">Annual billing saves 20% · No credit card for free plan · Cancel anytime</p>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     CTA BAND
     ═══════════════════════════════════════════════ -->
<section style="padding:96px 0;background:linear-gradient(135deg,#0e1d32 0%,#070d1a 100%);border-top:1px solid rgba(59,130,246,.15);">
  <div class="sa-wrap--narrow" style="text-align:center;">
    <p class="sa-eyebrow sa-reveal">Ready to Ship Faster?</p>
    <h2 class="sa-h2 sa-reveal" style="font-size:clamp(2rem,5vw,3.2rem);margin-bottom:20px;">Start your free trial today</h2>
    <p class="sa-reveal" style="color:#64748b;margin:0 auto 36px;max-width:440px;line-height:1.75;font-family:'Inter',sans-serif;">No credit card. No commitment. Full Pro features for 14 days. Then pick the plan that fits — or stay on the free tier forever.</p>
    <div class="sa-reveal" style="display:flex;gap:14px;justify-content:center;flex-wrap:wrap;margin-bottom:40px;">
      <a href="#" class="sa-btn sa-btn--primary" style="font-size:.92rem;padding:15px 32px;">Get started free →</a>
      <a href="#" class="sa-btn sa-btn--ghost">Schedule a demo</a>
    </div>
    <!-- Newsletter signup -->
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="sa-reveal" style="display:flex;gap:10px;max-width:440px;margin:0 auto;flex-wrap:wrap;" novalidate>
      <input type="hidden" name="action" value="tf_sa_subscribe">
      <?php wp_nonce_field('tf_sa_subscribe','tf_sa_nonce'); ?>
      <label for="sa-email" class="screen-reader-text"><?php esc_html_e('Email address','themeflex'); ?></label>
      <input type="email" id="sa-email" name="email" placeholder="you@company.com" required aria-required="true" style="flex:1;min-width:200px;padding:13px 16px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:8px;color:#ffffff;font-family:'Inter',sans-serif;font-size:.87rem;outline:none;transition:border-color .2s;" onfocus="this.style.borderColor='#3B82F6'" onblur="this.style.borderColor='rgba(255,255,255,.1)'">
      <button type="submit" class="sa-btn sa-btn--electric">Subscribe</button>
    </form>
    <p class="sa-reveal" style="font-size:.72rem;color:#1e2a3b;margin-top:12px;">No spam · Product updates only · Unsubscribe any time</p>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     FEATURE DEEP-DIVE: DEPLOYMENT ENGINE
     ═══════════════════════════════════════════════ -->
<section style="padding:96px 0;background:var(--sa-surface);border-top:1px solid rgba(255,255,255,.05);">
  <div class="sa-wrap" style="display:grid;grid-template-columns:1fr 1fr;gap:72px;align-items:center;">
    <!-- text -->
    <div class="sa-reveal">
      <p class="sa-eyebrow">Deep Dive: Deployment</p>
      <h2 class="sa-h2" style="font-size:clamp(1.8rem,3.5vw,2.4rem);">From commit to production<br>in under 6 minutes</h2>
      <p style="color:#64748b;line-height:1.8;margin-bottom:28px;font-family:'Inter',sans-serif;">Our deployment engine runs parallel build stages, caches intelligently across branches, and rolls out using a blue-green strategy by default — with automated rollback if your health checks fail.</p>
      <ul style="list-style:none;padding:0;margin:0 0 32px;display:flex;flex-direction:column;gap:14px;">
        <?php $sa_deploy_feats=['Parallel build stages with intelligent layer caching','Automatic blue-green switchover with zero downtime','Built-in health checks and auto-rollback on failure','Preview environments on every pull request automatically','Artifact signing and provenance with SLSA Level 3']; ?>
        <?php foreach($sa_deploy_feats as $feat): ?>
        <li style="display:flex;gap:12px;align-items:flex-start;font-size:.88rem;color:#94a3b8;font-family:'Inter',sans-serif;">
          <span style="color:var(--sa-cyan);font-weight:700;flex-shrink:0;margin-top:1px;">✓</span>
          <?php echo esc_html($feat); ?>
        </li>
        <?php endforeach; ?>
      </ul>
      <a href="#" class="sa-btn sa-btn--ghost" style="font-size:.82rem;">Read the deployment docs →</a>
    </div>
    <!-- CSS pipeline art -->
    <div class="sa-reveal" style="position:relative;height:340px;">
      <div style="background:var(--sa-card);border:1px solid rgba(255,255,255,.07);border-radius:12px;padding:24px;height:100%;display:flex;flex-direction:column;gap:12px;overflow:hidden;">
        <div style="font-size:.65rem;color:#475569;text-transform:uppercase;letter-spacing:.15em;margin-bottom:4px;">Pipeline: main → production</div>
        <?php
        $sa_pipeline_stages=[
          ['Clone & Cache','completed','#22c55e','1.2s'],
          ['Install Dependencies','completed','#22c55e','18.4s'],
          ['Lint & Type Check','completed','#22c55e','8.1s'],
          ['Unit Tests (parallel)','completed','#22c55e','24.7s'],
          ['Build Production Bundle','completed','#22c55e','31.2s'],
          ['Integration Tests','running','#3B82F6','ongoing'],
          ['Deploy to Staging','pending','#334155','—'],
          ['Smoke Tests','pending','#334155','—'],
          ['Production Switch','pending','#334155','—'],
        ];
        foreach($sa_pipeline_stages as $stage):
        ?>
        <div style="display:flex;align-items:center;gap:12px;padding:8px 12px;background:rgba(255,255,255,.025);border-radius:6px;border-left:2px solid <?php echo esc_attr($stage[2]); ?>;">
          <div style="width:10px;height:10px;border-radius:50%;background:<?php echo esc_attr($stage[2]); ?>;flex-shrink:0;<?php echo $stage[1]==='running'?'animation:sa-blink 1s ease-in-out infinite;':''; ?>"></div>
          <span style="font-family:'Inter',sans-serif;font-size:.75rem;color:<?php echo $stage[1]==='pending'?'#334155':'#94a3b8'; ?>;flex:1;"><?php echo esc_html($stage[0]); ?></span>
          <span style="font-family:'Inter',sans-serif;font-size:.68rem;color:<?php echo esc_attr($stage[2]); ?>;"><?php echo esc_html($stage[3]); ?></span>
        </div>
        <?php endforeach; ?>
        <div style="margin-top:auto;display:flex;justify-content:space-between;align-items:center;">
          <span style="font-size:.68rem;color:#334155;font-family:'Inter',sans-serif;">6 of 9 stages complete · Est. 4 min remaining</span>
          <span style="background:rgba(59,130,246,.15);color:#60a5fa;font-size:.65rem;font-weight:600;padding:3px 10px;border-radius:4px;">Running</span>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     FEATURE DEEP-DIVE: ANALYTICS
     ═══════════════════════════════════════════════ -->
<section style="padding:96px 0;background:var(--sa-deep);">
  <div class="sa-wrap" style="display:grid;grid-template-columns:1fr 1fr;gap:72px;align-items:center;">
    <!-- CSS analytics art -->
    <div class="sa-reveal" style="position:relative;height:320px;order:1;">
      <div style="background:var(--sa-card);border:1px solid rgba(255,255,255,.07);border-radius:12px;padding:24px;height:100%;display:flex;flex-direction:column;gap:16px;overflow:hidden;">
        <div style="display:flex;align-items:center;justify-content:space-between;">
          <span style="font-family:'Syne',sans-serif;font-size:.82rem;font-weight:700;color:#ffffff;">Real-Time Events</span>
          <span style="background:rgba(34,197,94,.15);color:#22c55e;font-size:.65rem;font-weight:700;padding:3px 10px;border-radius:4px;">● Live</span>
        </div>
        <!-- multi-line chart simulation -->
        <div style="flex:1;position:relative;border-bottom:1px solid rgba(255,255,255,.06);">
          <svg viewBox="0 0 320 120" style="width:100%;height:100%;overflow:visible;">
            <!-- grid lines -->
            <?php for($gl=0;$gl<=3;$gl++): ?>
            <line x1="0" y1="<?php echo $gl*40; ?>" x2="320" y2="<?php echo $gl*40; ?>" stroke="rgba(255,255,255,.04)" stroke-width="1"/>
            <?php endfor; ?>
            <!-- line 1 — requests -->
            <polyline fill="none" stroke="#3B82F6" stroke-width="2" points="0,80 40,65 80,70 120,50 160,55 200,30 240,35 280,20 320,15"/>
            <polygon fill="url(#sa-grad1)" points="0,80 40,65 80,70 120,50 160,55 200,30 240,35 280,20 320,15 320,120 0,120"/>
            <defs><linearGradient id="sa-grad1" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#3B82F6" stop-opacity=".25"/><stop offset="100%" stop-color="#3B82F6" stop-opacity="0"/></linearGradient></defs>
            <!-- line 2 — errors -->
            <polyline fill="none" stroke="#EF4444" stroke-width="1.5" stroke-dasharray="4,3" points="0,110 40,108 80,109 120,107 160,108 200,106 240,107 280,105 320,104"/>
          </svg>
        </div>
        <!-- legend + latest value -->
        <div style="display:flex;gap:20px;align-items:center;">
          <div style="display:flex;align-items:center;gap:6px;"><div style="width:12px;height:2px;background:#3B82F6;"></div><span style="font-size:.68rem;color:#475569;">Requests/sec</span></div>
          <div style="display:flex;align-items:center;gap:6px;"><div style="width:12px;height:2px;background:#EF4444;border-top:1px dashed #EF4444;"></div><span style="font-size:.68rem;color:#475569;">Error rate</span></div>
          <div style="margin-left:auto;font-family:'Syne',sans-serif;font-size:1.2rem;font-weight:800;color:#3B82F6;">2,847 <span style="font-size:.65rem;color:#334155;font-family:'Inter',sans-serif;">req/s</span></div>
        </div>
        <!-- stat pills -->
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;">
          <?php $sa_apills=[['P50','12ms','#22c55e'],['P95','48ms','#F59E0B'],['P99','124ms','#EF4444']]; ?>
          <?php foreach($sa_apills as $p): ?>
          <div style="background:rgba(255,255,255,.03);border-radius:6px;padding:10px;text-align:center;">
            <div style="font-size:.6rem;color:#334155;text-transform:uppercase;letter-spacing:.1em;"><?php echo esc_html($p[0]); ?></div>
            <div style="font-family:'Syne',sans-serif;font-size:1rem;font-weight:700;color:<?php echo esc_attr($p[2]); ?>;"><?php echo esc_html($p[1]); ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
    <!-- text -->
    <div class="sa-reveal" style="order:2;">
      <p class="sa-eyebrow">Deep Dive: Analytics</p>
      <h2 class="sa-h2" style="font-size:clamp(1.8rem,3.5vw,2.4rem);">Know exactly what's happening<br>as it happens</h2>
      <p style="color:#64748b;line-height:1.8;margin-bottom:28px;font-family:'Inter',sans-serif;">Our event streaming engine processes over 2 billion events per day with sub-10ms ingestion latency. Build custom dashboards using SQL, or use our pre-built templates for common engineering metrics.</p>
      <ul style="list-style:none;padding:0;margin:0 0 32px;display:flex;flex-direction:column;gap:14px;">
        <?php $sa_analytics_feats=['Sub-second event ingestion with replay support','Custom dashboards with drag-and-drop SQL builder','P50/P95/P99 latency tracking per endpoint','Anomaly detection with automatic alerting','Export to Datadog, Grafana, or BigQuery natively']; ?>
        <?php foreach($sa_analytics_feats as $feat): ?>
        <li style="display:flex;gap:12px;align-items:flex-start;font-size:.88rem;color:#94a3b8;font-family:'Inter',sans-serif;">
          <span style="color:var(--sa-cyan);font-weight:700;flex-shrink:0;margin-top:1px;">✓</span>
          <?php echo esc_html($feat); ?>
        </li>
        <?php endforeach; ?>
      </ul>
      <a href="#" class="sa-btn sa-btn--ghost" style="font-size:.82rem;">Explore analytics docs →</a>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     SECURITY & COMPLIANCE DEEP-DIVE
     ═══════════════════════════════════════════════ -->
<section style="padding:96px 0;background:var(--sa-surface);border-top:1px solid rgba(255,255,255,.05);">
  <div class="sa-wrap">
    <div style="text-align:center;margin-bottom:56px;" class="sa-reveal">
      <p class="sa-eyebrow">Security & Compliance</p>
      <h2 class="sa-h2">Built to pass your security review<br><span class="sa-gradient-text">on the first attempt</span></h2>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:24px;" class="sa-reveal">
      <?php
      $sa_security=[
        ['🔒','SOC 2 Type II','Independently audited annually. Report available under NDA within 24 hours of request.','#3B82F6'],
        ['🇪🇺','GDPR & CCPA','Full data residency control. DPA available. EU/UK SCCs in place for all sub-processors.','#06B6D4'],
        ['🛡️','Pen Testing','Annual third-party penetration testing with Synack. CVE disclosure policy and bug bounty programme.','#8B5CF6'],
        ['🔑','RBAC & ABAC','Fine-grained role-based and attribute-based access controls down to the individual resource level.','#10B981'],
        ['📋','Audit Logs','Immutable, tamper-evident audit trail for every user action. Exportable to your SIEM in real time.','#F59E0B'],
        ['🏗️','Infra as Code','All infrastructure defined in Terraform and Pulumi. No click-ops, full auditability, GitOps-friendly.','#EC4899'],
      ];
      foreach($sa_security as $s):
      ?>
      <div style="background:var(--sa-card);border:1px solid rgba(255,255,255,.06);border-radius:var(--sa-r);padding:24px;border-top:2px solid <?php echo esc_attr($s[3]); ?>20;transition:border-color .25s;" onmouseenter="this.style.borderTopColor='<?php echo esc_attr($s[3]); ?>'" onmouseleave="this.style.borderTopColor='<?php echo esc_attr($s[3]); ?>20'">
        <div style="font-size:1.5rem;margin-bottom:10px;"><?php echo $s[0]; ?></div>
        <h3 style="font-family:'Syne',sans-serif;font-size:.95rem;font-weight:700;color:#ffffff;margin-bottom:8px;"><?php echo esc_html($s[1]); ?></h3>
        <p style="font-size:.82rem;color:#475569;line-height:1.65;font-family:'Inter',sans-serif;"><?php echo esc_html($s[2]); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
    <div class="sa-reveal" style="text-align:center;margin-top:40px;">
      <a href="#" class="sa-btn sa-btn--ghost" style="font-size:.82rem;">Download security whitepaper →</a>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     MIGRATION GUARANTEE
     ═══════════════════════════════════════════════ -->
<section style="padding:80px 0;background:var(--sa-deep);border-top:1px solid rgba(255,255,255,.05);">
  <div class="sa-wrap--narrow" style="text-align:center;">
    <div class="sa-reveal" style="background:var(--sa-card);border:1px solid rgba(6,182,212,.2);border-radius:20px;padding:56px 48px;position:relative;overflow:hidden;">
      <div style="position:absolute;top:-60px;right:-60px;width:240px;height:240px;border-radius:50%;background:radial-gradient(circle,rgba(59,130,246,.08),transparent 70%);"></div>
      <div style="position:absolute;bottom:-40px;left:-40px;width:180px;height:180px;border-radius:50%;background:radial-gradient(circle,rgba(6,182,212,.07),transparent 70%);"></div>
      <div style="width:64px;height:64px;border-radius:50%;background:linear-gradient(135deg,var(--sa-electric),var(--sa-cyan));display:flex;align-items:center;justify-content:center;margin:0 auto 18px;font-size:1.8rem;position:relative;z-index:1;">🚀</div>
      <h2 style="font-family:'Syne',sans-serif;font-size:1.8rem;font-weight:800;color:#ffffff;margin-bottom:12px;position:relative;z-index:1;">White-glove migration. Zero downtime. Guaranteed.</h2>
      <p style="color:#64748b;max-width:500px;margin:0 auto 28px;line-height:1.8;font-family:'Inter',sans-serif;position:relative;z-index:1;">Every plan includes free migration support from our Platform Engineering team. We've migrated teams from Heroku, AWS Elastic Beanstalk, Render, Railway, and 8 other platforms — median migration time: 4 hours.</p>
      <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-bottom:28px;position:relative;z-index:1;">
        <?php $sa_migration_from=['Heroku','AWS EB','Render','Railway','Fly.io','Netlify','Vercel','DigitalOcean']; ?>
        <?php foreach($sa_migration_from as $from): ?>
        <span style="background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);color:#64748b;font-family:'Inter',sans-serif;font-size:.72rem;padding:5px 12px;border-radius:20px;"><?php echo esc_html($from); ?></span>
        <?php endforeach; ?>
      </div>
      <a href="#" class="sa-btn sa-btn--primary" style="position:relative;z-index:1;">Book a free migration call →</a>
    </div>
  </div>
</section>
<script>
(function(){
  /* ── Scroll reveal ── */
  const reveals=document.querySelectorAll('.sa-reveal');
  if('IntersectionObserver' in window){
    const io=new IntersectionObserver(entries=>{entries.forEach((e,i)=>{if(e.isIntersecting){setTimeout(()=>e.target.classList.add('sa-visible'),i*70);io.unobserve(e.target);}});},{threshold:.1});
    reveals.forEach(el=>io.observe(el));
  } else {
    reveals.forEach(el=>el.classList.add('sa-visible'));
  }

  /* ── FAQ accordion ── */
  document.querySelectorAll('.sa-faq-btn').forEach(btn=>{
    btn.addEventListener('click',function(){
      const item=this.closest('.sa-faq-item');
      const body=item.querySelector('.sa-faq-body');
      const isOpen=item.classList.contains('sa-open');
      document.querySelectorAll('.sa-faq-item.sa-open').forEach(o=>{
        o.classList.remove('sa-open');
        o.querySelector('.sa-faq-body').style.maxHeight='0';
        o.querySelector('.sa-faq-btn').setAttribute('aria-expanded','false');
      });
      if(!isOpen){
        item.classList.add('sa-open');
        body.style.maxHeight=body.scrollHeight+'px';
        this.setAttribute('aria-expanded','true');
      }
    });
  });
})();
</script>
</div><!-- .sa-page -->
<?php get_footer(); ?>
