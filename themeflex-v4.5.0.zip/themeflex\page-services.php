<?php
/**
 * Template Name: Services
 * Template Post Type: page
 *
 * Best-in-class dark-first Services page for ThemeFlex.
 * Sections: Hero · Cards Grid · Why Us · Process · Deep-Dives ·
 *           Stack · Pricing Teaser · Testimonials · FAQ · CTA Banner
 *
 * @package ThemeFlex
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
?>

<main id="primary" class="tfs-main">
<style>
/* ============================================================
   BASE / TOKENS
   ============================================================ */
.tfs-main{
  --tc :#ff5e2e;
  --tc2:#00d4ff;
  --tc3:#a855f7;
  --bg :#06021d;
  --bg2:#0d1526;
  --bg3:#111827;
  --bdr:rgba(255,255,255,.07);
  --ttl:#f1f5f9;
  --txt:#94a3b8;
  --muted:#64748b;
  background:var(--bg);
  color:var(--txt);
  font-family:inherit;
  overflow-x:hidden;
}
.tfs-wrap{max-width:1200px;margin:0 auto;padding:0 24px}
.tfs-wrap--narrow{max-width:760px;margin:0 auto;padding:0 24px}
.tfs-eyebrow{
  display:inline-flex;align-items:center;gap:8px;
  background:rgba(255,94,46,.10);border:1px solid rgba(255,94,46,.28);
  color:var(--tc);font-size:.7rem;font-weight:700;letter-spacing:.12em;
  text-transform:uppercase;padding:6px 18px;border-radius:100px;
  margin-bottom:22px;position:relative;z-index:1;
}
.tfs-grad-text{
  background:linear-gradient(95deg,var(--tc) 0%,#ff8c5a 50%,var(--tc2) 100%);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
  background-clip:text;
}

/* ============================================================
   1. HERO
   ============================================================ */
.tfs-hero{
  position:relative;text-align:center;
  padding:140px 24px 110px;overflow:hidden;
  background:var(--bg);
}
/* Dot grid */
.tfs-hero::before{
  content:'';position:absolute;inset:0;
  background-image:radial-gradient(rgba(255,255,255,.045) 1px,transparent 1px);
  background-size:32px 32px;pointer-events:none;
}
/* Gradient orbs */
.tfs-orb{
  position:absolute;border-radius:50%;
  filter:blur(90px);pointer-events:none;opacity:.55;
  animation:tfs-orb-drift 14s ease-in-out infinite alternate;
}
.tfs-orb--1{
  width:560px;height:560px;top:-160px;left:-100px;
  background:radial-gradient(circle,rgba(255,94,46,.45),transparent 70%);
  animation-duration:16s;
}
.tfs-orb--2{
  width:480px;height:480px;top:-80px;right:-80px;
  background:radial-gradient(circle,rgba(0,212,255,.35),transparent 70%);
  animation-duration:20s;animation-delay:-6s;
}
.tfs-orb--3{
  width:400px;height:400px;bottom:-120px;left:50%;transform:translateX(-50%);
  background:radial-gradient(circle,rgba(168,85,247,.30),transparent 70%);
  animation-duration:18s;animation-delay:-3s;
}
@keyframes tfs-orb-drift{
  from{transform:translate(0,0) scale(1);}
  to  {transform:translate(40px,30px) scale(1.08);}
}
.tfs-orb--3{animation-name:tfs-orb-drift-3}
@keyframes tfs-orb-drift-3{
  from{transform:translateX(-50%) translate(0,0);}
  to  {transform:translateX(-50%) translate(-30px,20px);}
}
.tfs-hero__inner{position:relative;z-index:1;}
.tfs-hero h1{
  font-size:clamp(2.5rem,5.5vw,4.2rem);font-weight:900;
  color:var(--ttl);margin:0 0 20px;line-height:1.06;
  letter-spacing:-.02em;
}
.tfs-hero__sub{
  font-size:1.125rem;color:var(--txt);
  max-width:600px;margin:0 auto 40px;line-height:1.8;
}
/* Mini stats bar */
.tfs-hero__stats{
  display:inline-flex;flex-wrap:wrap;justify-content:center;
  gap:0;background:rgba(255,255,255,.04);
  border:1px solid var(--bdr);border-radius:16px;
  overflow:hidden;margin-bottom:0;
}
.tfs-hero__stat{
  padding:14px 28px;font-size:.85rem;font-weight:700;color:var(--ttl);
  border-right:1px solid var(--bdr);white-space:nowrap;
}
.tfs-hero__stat:last-child{border-right:none;}
.tfs-hero__stat span{color:var(--tc);display:block;font-size:1.3rem;line-height:1.2;margin-bottom:2px;}
/* Bottom wave */
.tfs-hero__wave{
  position:absolute;bottom:-1px;left:0;right:0;
  overflow:hidden;line-height:0;
}
.tfs-hero__wave svg{display:block;width:100%;}

/* ============================================================
   2. SERVICE CARDS
   ============================================================ */
.tfs-services{padding:90px 0 80px;background:var(--bg);}
.tfs-section-head{text-align:center;margin-bottom:60px;}
.tfs-section-head h2{
  font-size:clamp(1.9rem,3.5vw,2.8rem);font-weight:800;
  color:var(--ttl);margin:0 0 14px;line-height:1.15;
}
.tfs-section-head p{font-size:1rem;color:var(--txt);max-width:540px;margin:0 auto;line-height:1.75;}
.tfs-cards{
  display:grid;grid-template-columns:repeat(3,1fr);gap:28px;
}
.tfs-card{
  background:var(--bg3);border:1px solid var(--bdr);
  border-radius:22px;padding:38px 32px 32px;
  position:relative;overflow:hidden;
  transition:transform .35s cubic-bezier(.22,1,.36,1),
              border-color .35s,box-shadow .35s;
  opacity:0;transform:translateY(32px);
}
.tfs-card.tfs-visible{opacity:1;transform:translateY(0);}
.tfs-card::before{
  content:'';position:absolute;inset:0;
  background:linear-gradient(135deg,rgba(255,94,46,.06) 0%,transparent 55%);
  opacity:0;transition:opacity .35s;
}
.tfs-card:hover{
  transform:translateY(-8px);
  border-color:rgba(255,94,46,.35);
  box-shadow:0 0 0 1px rgba(255,94,46,.18),
             0 24px 64px rgba(255,94,46,.12),
             0 8px 24px rgba(0,0,0,.4);
}
.tfs-card:hover::before{opacity:1;}
.tfs-card__icon{
  width:64px;height:64px;border-radius:18px;
  display:flex;align-items:center;justify-content:center;
  margin-bottom:24px;flex-shrink:0;position:relative;z-index:1;
}
.tfs-card__icon svg{color:#fff;}
.tfs-card__icon--design {background:linear-gradient(135deg,#ff5e2e,#ff8c5a);}
.tfs-card__icon--code   {background:linear-gradient(135deg,#00d4ff,#0ea5e9);}
.tfs-card__icon--perf   {background:linear-gradient(135deg,#f59e0b,#fb923c);}
.tfs-card__icon--ecom   {background:linear-gradient(135deg,#10b981,#34d399);}
.tfs-card__icon--sec    {background:linear-gradient(135deg,#a855f7,#c084fc);}
.tfs-card__icon--seo    {background:linear-gradient(135deg,#3b82f6,#6366f1);}
.tfs-card h3{
  font-size:1.22rem;font-weight:800;color:var(--ttl);
  margin:0 0 12px;position:relative;z-index:1;
}
.tfs-card__desc{
  font-size:.92rem;color:var(--txt);line-height:1.75;
  margin-bottom:20px;position:relative;z-index:1;
}
.tfs-card__bullets{list-style:none;margin:0 0 20px;padding:0;position:relative;z-index:1;}
.tfs-card__bullets li{
  display:flex;align-items:flex-start;gap:8px;
  font-size:.85rem;color:var(--txt);margin-bottom:7px;
}
.tfs-card__bullets li svg{color:var(--tc);flex-shrink:0;margin-top:2px;}
.tfs-card__tags{
  display:flex;flex-wrap:wrap;gap:6px;
  margin-bottom:24px;position:relative;z-index:1;
}
.tfs-tag{
  font-size:.72rem;font-weight:600;letter-spacing:.04em;
  padding:4px 10px;border-radius:100px;
  background:rgba(255,255,255,.06);border:1px solid var(--bdr);
  color:var(--muted);
}
.tfs-card__cta{
  display:inline-flex;align-items:center;gap:6px;
  font-size:.85rem;font-weight:700;color:var(--tc);
  text-decoration:none;position:relative;z-index:1;
  transition:gap .25s;
}
.tfs-card__cta:hover{gap:10px;}
.tfs-card__cta svg{transition:transform .25s;}
.tfs-card__cta:hover svg{transform:translateX(3px);}

/* ============================================================
   3. WHY CHOOSE US
   ============================================================ */
.tfs-why{
  padding:90px 0;
  background:linear-gradient(180deg,var(--bg) 0%,var(--bg2) 100%);
  border-top:1px solid var(--bdr);border-bottom:1px solid var(--bdr);
}
.tfs-why__grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:36px;
  margin-top:56px;
}
.tfs-why__item{
  text-align:center;padding:40px 28px;
  background:rgba(255,255,255,.025);
  border:1px solid var(--bdr);border-radius:20px;
  transition:transform .3s,border-color .3s;
}
.tfs-why__item:hover{transform:translateY(-5px);border-color:rgba(255,94,46,.22);}
.tfs-why__icon{
  width:58px;height:58px;border-radius:16px;
  background:linear-gradient(135deg,rgba(255,94,46,.18),rgba(255,94,46,.04));
  border:1px solid rgba(255,94,46,.2);
  display:flex;align-items:center;justify-content:center;
  margin:0 auto 20px;
}
.tfs-why__icon svg{color:var(--tc);}
.tfs-why__item h3{font-size:1.1rem;font-weight:800;color:var(--ttl);margin:0 0 10px;}
.tfs-why__item p{font-size:.9rem;color:var(--txt);line-height:1.7;margin:0;}

/* ============================================================
   4. PROCESS
   ============================================================ */
.tfs-process{padding:100px 0;background:var(--bg2);}
.tfs-process__steps{
  display:grid;grid-template-columns:repeat(4,1fr);gap:0;
  margin-top:64px;position:relative;
}
/* Dashed connector line */
.tfs-process__steps::before{
  content:'';position:absolute;
  top:36px;left:calc(12.5% + 36px);
  right:calc(12.5% + 36px);height:2px;
  background:repeating-linear-gradient(
    90deg,
    rgba(255,94,46,.35) 0px,rgba(255,94,46,.35) 8px,
    transparent 8px,transparent 16px
  );
  z-index:0;
}
.tfs-step{
  text-align:center;padding:0 16px;
  position:relative;z-index:1;
}
.tfs-step__num{
  width:72px;height:72px;border-radius:50%;
  background:linear-gradient(135deg,var(--tc),#ff8c5a);
  display:flex;align-items:center;justify-content:center;
  font-size:1.3rem;font-weight:900;color:#fff;
  margin:0 auto 22px;
  box-shadow:0 0 0 6px rgba(255,94,46,.12),0 0 0 12px rgba(255,94,46,.06);
}
.tfs-step h3{font-size:1.05rem;font-weight:800;color:var(--ttl);margin:0 0 10px;}
.tfs-step p{font-size:.875rem;color:var(--txt);line-height:1.7;margin:0;}

/* ============================================================
   5. DEEP-DIVE SECTIONS
   ============================================================ */
.tfs-dive{padding:100px 0;background:var(--bg);}
.tfs-dive__row{
  display:grid;grid-template-columns:1fr 1fr;
  gap:64px;align-items:center;margin-bottom:100px;
}
.tfs-dive__row:last-child{margin-bottom:0;}
.tfs-dive__row--flip .tfs-dive__art{order:2;}
.tfs-dive__row--flip .tfs-dive__text{order:1;}
/* CSS gradient art panel */
.tfs-dive__art{
  position:relative;height:400px;border-radius:24px;overflow:hidden;
  border:1px solid var(--bdr);
}
.tfs-dive__art-bg{
  position:absolute;inset:0;
  background:linear-gradient(135deg,var(--bg3) 0%,var(--bg2) 100%);
}
.tfs-dive__art--design .tfs-dive__art-bg{
  background:linear-gradient(135deg,#1a0a00 0%,#2d0e00 50%,#1a0015 100%);
}
.tfs-dive__art--ecom .tfs-dive__art-bg{
  background:linear-gradient(135deg,#001a0e 0%,#001a2d 50%,#0d001a 100%);
}
.tfs-dive__art-blob{
  position:absolute;border-radius:50%;
  filter:blur(50px);pointer-events:none;
}
.tfs-dive__art--design .tfs-dive__art-blob:nth-child(1){
  width:220px;height:220px;top:-40px;left:-40px;
  background:rgba(255,94,46,.3);
}
.tfs-dive__art--design .tfs-dive__art-blob:nth-child(2){
  width:180px;height:180px;bottom:-30px;right:-20px;
  background:rgba(168,85,247,.25);
}
.tfs-dive__art--ecom .tfs-dive__art-blob:nth-child(1){
  width:220px;height:220px;top:-40px;right:-40px;
  background:rgba(16,185,129,.28);
}
.tfs-dive__art--ecom .tfs-dive__art-blob:nth-child(2){
  width:180px;height:180px;bottom:-30px;left:-20px;
  background:rgba(0,212,255,.22);
}
/* Floating stat cards inside art panel */
.tfs-stat-card{
  position:absolute;background:rgba(255,255,255,.07);
  backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);
  border:1px solid rgba(255,255,255,.12);border-radius:14px;
  padding:14px 18px;min-width:140px;
}
.tfs-stat-card__val{
  font-size:1.6rem;font-weight:900;color:var(--ttl);line-height:1;
  margin-bottom:4px;
}
.tfs-stat-card__label{font-size:.72rem;color:var(--muted);font-weight:500;}
.tfs-stat-card--a{top:28px;left:28px;}
.tfs-stat-card--b{bottom:28px;right:28px;}
.tfs-stat-card--c{top:50%;left:50%;transform:translate(-50%,-50%);}
/* Central icon area */
.tfs-dive__art-icon{
  position:absolute;top:50%;left:50%;
  transform:translate(-50%,-50%);
  width:90px;height:90px;border-radius:26px;
  display:flex;align-items:center;justify-content:center;
  background:rgba(255,255,255,.07);
  border:1px solid rgba(255,255,255,.12);
  backdrop-filter:blur(8px);
}
.tfs-dive__art-icon svg{color:#fff;width:44px;height:44px;}
/* Text side */
.tfs-dive__text h2{
  font-size:clamp(1.7rem,3vw,2.4rem);font-weight:800;
  color:var(--ttl);margin:0 0 16px;line-height:1.15;
}
.tfs-dive__text p{
  font-size:.97rem;color:var(--txt);line-height:1.8;margin:0 0 24px;
}
.tfs-dive__bullets{list-style:none;margin:0 0 32px;padding:0;}
.tfs-dive__bullets li{
  display:flex;align-items:flex-start;gap:10px;
  font-size:.92rem;color:var(--txt);margin-bottom:10px;line-height:1.6;
}
.tfs-dive__bullets li svg{color:var(--tc);flex-shrink:0;margin-top:3px;}
.tfs-btn{
  display:inline-flex;align-items:center;gap:8px;
  padding:14px 28px;border-radius:12px;font-size:.9rem;font-weight:700;
  text-decoration:none;cursor:pointer;border:none;
  transition:transform .25s,box-shadow .25s,opacity .25s;
}
.tfs-btn--primary{
  background:linear-gradient(135deg,var(--tc),#ff8c5a);
  color:#fff;
  box-shadow:0 8px 24px rgba(255,94,46,.28);
}
.tfs-btn--primary:hover{
  transform:translateY(-2px);
  box-shadow:0 12px 32px rgba(255,94,46,.38);
}
.tfs-btn--outline{
  background:transparent;
  border:1px solid var(--bdr);color:var(--ttl);
}
.tfs-btn--outline:hover{border-color:rgba(255,94,46,.4);color:var(--tc);}

/* ============================================================
   6. STACK / TOOLS
   ============================================================ */
.tfs-stack{
  padding:90px 0;background:var(--bg2);
  border-top:1px solid var(--bdr);
}
.tfs-stack__grid{
  display:grid;grid-template-columns:repeat(6,1fr);gap:16px;
  margin-top:52px;
}
.tfs-tool{
  background:var(--bg3);border:1px solid var(--bdr);border-radius:16px;
  padding:20px 16px;text-align:center;
  transition:transform .25s,border-color .25s;
}
.tfs-tool:hover{transform:translateY(-4px);border-color:rgba(255,255,255,.15);}
.tfs-tool__chip{
  width:40px;height:40px;border-radius:10px;
  display:flex;align-items:center;justify-content:center;
  font-size:.85rem;font-weight:900;color:#fff;margin:0 auto 10px;
}
.tfs-tool__name{font-size:.78rem;font-weight:600;color:var(--muted);}

/* ============================================================
   7. PRICING TEASER
   ============================================================ */
.tfs-pricing{padding:90px 0;background:var(--bg);}
.tfs-pricing__cards{
  display:grid;grid-template-columns:repeat(3,1fr);gap:24px;
  margin-top:52px;
}
.tfs-pricing-card{
  background:var(--bg3);border:1px solid var(--bdr);border-radius:20px;
  padding:36px 30px;text-align:center;position:relative;
  transition:transform .3s,border-color .3s,box-shadow .3s;
}
.tfs-pricing-card:hover{
  transform:translateY(-6px);border-color:rgba(255,94,46,.3);
  box-shadow:0 20px 56px rgba(0,0,0,.35);
}
.tfs-pricing-card--featured{
  border-color:rgba(255,94,46,.4);
  background:linear-gradient(160deg,rgba(255,94,46,.07) 0%,var(--bg3) 60%);
}
.tfs-pricing-card--featured::before{
  content:'Most Popular';position:absolute;top:-12px;left:50%;
  transform:translateX(-50%);
  background:linear-gradient(90deg,var(--tc),#ff8c5a);
  color:#fff;font-size:.68rem;font-weight:700;letter-spacing:.08em;
  text-transform:uppercase;padding:4px 14px;border-radius:100px;
  white-space:nowrap;
}
.tfs-pricing-card__tier{
  font-size:.7rem;font-weight:700;letter-spacing:.12em;
  text-transform:uppercase;color:var(--tc);margin-bottom:10px;
}
.tfs-pricing-card__price{
  font-size:2.4rem;font-weight:900;color:var(--ttl);
  line-height:1;margin-bottom:6px;
}
.tfs-pricing-card__from{
  font-size:.78rem;color:var(--muted);margin-bottom:16px;
}
.tfs-pricing-card__desc{
  font-size:.875rem;color:var(--txt);line-height:1.65;margin-bottom:0;
}
.tfs-pricing__footer{
  text-align:center;margin-top:36px;
}
.tfs-pricing__footer a{
  display:inline-flex;align-items:center;gap:6px;
  font-size:.9rem;font-weight:700;color:var(--tc);text-decoration:none;
  transition:gap .2s;
}
.tfs-pricing__footer a:hover{gap:10px;}

/* ============================================================
   8. TESTIMONIALS
   ============================================================ */
.tfs-testimonials{
  padding:90px 0;
  background:linear-gradient(180deg,var(--bg2) 0%,var(--bg) 100%);
  border-top:1px solid var(--bdr);
}
.tfs-testi-grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:24px;
  margin-top:52px;
}
.tfs-testi{
  background:var(--bg3);border:1px solid var(--bdr);border-radius:20px;
  padding:32px 28px;position:relative;overflow:hidden;
  transition:transform .3s,border-color .3s;
}
.tfs-testi:hover{transform:translateY(-4px);border-color:rgba(255,94,46,.22);}
.tfs-testi::before{
  content:'\201C';position:absolute;top:16px;right:22px;
  font-size:5rem;line-height:1;color:rgba(255,94,46,.1);font-weight:900;
}
.tfs-testi__stars{
  display:flex;gap:3px;margin-bottom:14px;
}
.tfs-testi__stars span{color:var(--tc);font-size:.9rem;}
.tfs-testi__quote{
  font-size:.92rem;color:var(--txt);line-height:1.75;
  margin-bottom:22px;position:relative;z-index:1;
}
.tfs-testi__author{display:flex;align-items:center;gap:12px;}
.tfs-testi__avatar{
  width:44px;height:44px;border-radius:50%;flex-shrink:0;
  display:flex;align-items:center;justify-content:center;
  font-size:.85rem;font-weight:900;color:#fff;
}
.tfs-testi__avatar--a{background:linear-gradient(135deg,#ff5e2e,#ff8c5a);}
.tfs-testi__avatar--b{background:linear-gradient(135deg,#00d4ff,#0ea5e9);}
.tfs-testi__avatar--c{background:linear-gradient(135deg,#a855f7,#c084fc);}
.tfs-testi__name{font-size:.88rem;font-weight:700;color:var(--ttl);}
.tfs-testi__role{font-size:.78rem;color:var(--muted);}

/* ============================================================
   9. FAQ
   ============================================================ */
.tfs-faq{padding:90px 0;background:var(--bg);}
.tfs-faq__list{margin-top:52px;}
.tfs-faq__item{
  border:1px solid var(--bdr);border-radius:14px;
  margin-bottom:12px;overflow:hidden;
  transition:border-color .25s;
}
.tfs-faq__item.tfs-faq--open{border-color:rgba(255,94,46,.3);}
.tfs-faq__trigger{
  width:100%;display:flex;justify-content:space-between;align-items:center;
  padding:20px 24px;background:var(--bg3);cursor:pointer;
  border:none;color:var(--ttl);font-size:.97rem;font-weight:700;
  text-align:left;gap:16px;transition:background .2s;
}
.tfs-faq__trigger:hover{background:rgba(255,94,46,.05);}
.tfs-faq__chevron{
  width:22px;height:22px;border-radius:50%;
  border:1px solid var(--bdr);display:flex;
  align-items:center;justify-content:center;flex-shrink:0;
  transition:transform .3s,background .3s,border-color .3s;
  color:var(--muted);
}
.tfs-faq--open .tfs-faq__chevron{
  transform:rotate(180deg);
  background:rgba(255,94,46,.1);border-color:rgba(255,94,46,.3);
  color:var(--tc);
}
.tfs-faq__body{
  max-height:0;overflow:hidden;
  transition:max-height .4s cubic-bezier(.4,0,.2,1),padding .4s;
  background:rgba(255,255,255,.015);
  padding:0 24px;
}
.tfs-faq--open .tfs-faq__body{
  max-height:240px;padding:18px 24px 22px;
}
.tfs-faq__body p{
  font-size:.9rem;color:var(--txt);line-height:1.75;margin:0;
}

/* ============================================================
   10. CTA BANNER
   ============================================================ */
.tfs-cta{
  padding:100px 24px;text-align:center;
  background:linear-gradient(135deg,rgba(255,94,46,.12) 0%,var(--bg2) 40%,rgba(0,212,255,.07) 100%);
  border-top:1px solid var(--bdr);position:relative;overflow:hidden;
}
.tfs-cta::before{
  content:'';position:absolute;inset:0;
  background-image:radial-gradient(rgba(255,255,255,.025) 1px,transparent 1px);
  background-size:28px 28px;pointer-events:none;
}
.tfs-cta__inner{position:relative;z-index:1;}
.tfs-cta h2{
  font-size:clamp(2rem,4vw,3.2rem);font-weight:900;
  color:var(--ttl);margin:0 0 16px;line-height:1.1;
}
.tfs-cta p{
  font-size:1.05rem;color:var(--txt);max-width:500px;
  margin:0 auto 36px;line-height:1.75;
}
.tfs-cta__btns{display:flex;gap:16px;justify-content:center;flex-wrap:wrap;}

/* ============================================================
   STAGGER ANIMATION (IntersectionObserver driven)
   ============================================================ */
.tfs-anim{opacity:0;transform:translateY(28px);transition:opacity .55s ease,transform .55s ease;}
.tfs-anim.tfs-visible{opacity:1;transform:translateY(0);}
.tfs-anim-delay-1{transition-delay:.08s;}
.tfs-anim-delay-2{transition-delay:.16s;}
.tfs-anim-delay-3{transition-delay:.24s;}
.tfs-anim-delay-4{transition-delay:.32s;}

/* ============================================================
   RESPONSIVE
   ============================================================ */
@media(max-width:1024px){
  .tfs-cards{grid-template-columns:repeat(2,1fr);}
  .tfs-why__grid{grid-template-columns:repeat(2,1fr);}
  .tfs-process__steps{grid-template-columns:repeat(2,1fr);gap:36px;}
  .tfs-process__steps::before{display:none;}
  .tfs-dive__row{grid-template-columns:1fr;gap:40px;}
  .tfs-dive__row--flip .tfs-dive__art,.tfs-dive__row--flip .tfs-dive__text{order:unset;}
  .tfs-stack__grid{grid-template-columns:repeat(4,1fr);}
  .tfs-pricing__cards{grid-template-columns:repeat(2,1fr);}
  .tfs-testi-grid{grid-template-columns:repeat(2,1fr);}
}
@media(max-width:640px){
  .tfs-cards{grid-template-columns:1fr;}
  .tfs-why__grid{grid-template-columns:1fr;}
  .tfs-process__steps{grid-template-columns:1fr;}
  .tfs-stack__grid{grid-template-columns:repeat(3,1fr);}
  .tfs-pricing__cards{grid-template-columns:1fr;}
  .tfs-testi-grid{grid-template-columns:1fr;}
  .tfs-hero__stats{flex-direction:column;border-radius:12px;}
  .tfs-hero__stat{border-right:none;border-bottom:1px solid var(--bdr);}
  .tfs-hero__stat:last-child{border-bottom:none;}
  .tfs-dive__art{height:280px;}
}
</style>

<!-- ============================================================
     1. HERO
     ============================================================ -->
<section class="tfs-hero">
  <div class="tfs-orb tfs-orb--1"></div>
  <div class="tfs-orb tfs-orb--2"></div>
  <div class="tfs-orb tfs-orb--3"></div>

  <div class="tfs-hero__inner">
    <div class="tfs-eyebrow">
      <?php echo tf_icon_get( 'sparkles', 14 ); ?>
      <?php esc_html_e( 'Professional Services', 'themeflex' ); ?>
    </div>

    <h1>
      <?php esc_html_e( 'Services built for', 'themeflex' ); ?><br>
      <span class="tfs-grad-text"><?php esc_html_e( 'ambitious businesses', 'themeflex' ); ?></span>
    </h1>

    <p class="tfs-hero__sub">
      <?php esc_html_e( 'From first pixel to global launch — we craft digital experiences that perform, convert, and scale without compromise.', 'themeflex' ); ?>
    </p>

    <div class="tfs-hero__stats">
      <div class="tfs-hero__stat">
        <span>250+</span><?php esc_html_e( 'Projects', 'themeflex' ); ?>
      </div>
      <div class="tfs-hero__stat">
        <span>8</span><?php esc_html_e( 'Years', 'themeflex' ); ?>
      </div>
      <div class="tfs-hero__stat">
        <span>97</span><?php esc_html_e( 'PageSpeed', 'themeflex' ); ?>
      </div>
      <div class="tfs-hero__stat">
        <span>4.9&#9733;</span><?php esc_html_e( 'Rating', 'themeflex' ); ?>
      </div>
    </div>
  </div>

  <div class="tfs-hero__wave">
    <svg viewBox="0 0 1440 64" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M0,32 C240,64 480,0 720,32 C960,64 1200,0 1440,32 L1440,64 L0,64 Z" fill="#06021d"/>
    </svg>
  </div>
</section>

<!-- ============================================================
     2. SERVICE CARDS
     ============================================================ -->
<section class="tfs-services">
  <div class="tfs-wrap">
    <div class="tfs-section-head tfs-anim">
      <h2><?php esc_html_e( 'Everything your project needs', 'themeflex' ); ?></h2>
      <p><?php esc_html_e( 'Six specialist disciplines, one seamlessly integrated team — delivered with obsessive attention to detail.', 'themeflex' ); ?></p>
    </div>

    <div class="tfs-cards">

      <!-- UI/UX Design -->
      <div class="tfs-card">
        <div class="tfs-card__icon tfs-card__icon--design">
          <?php echo tf_icon_get( 'palette', 28 ); ?>
        </div>
        <h3><?php esc_html_e( 'UI/UX Design', 'themeflex' ); ?></h3>
        <p class="tfs-card__desc"><?php esc_html_e( 'Pixel-perfect interfaces that guide users from curiosity to conversion. We combine data-driven UX research with award-worthy visual craft to build products people love to use.', 'themeflex' ); ?></p>
        <ul class="tfs-card__bullets">
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'User research &amp; persona mapping', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'Wireframes, prototypes &amp; interactive demos', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'Design system &amp; component library', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'WCAG 2.1 AA accessibility compliance', 'themeflex' ); ?></li>
        </ul>
        <div class="tfs-card__tags">
          <span class="tfs-tag">Figma</span>
          <span class="tfs-tag">Framer</span>
          <span class="tfs-tag">Design Systems</span>
          <span class="tfs-tag">A/B Testing</span>
        </div>
        <a href="#contact" class="tfs-card__cta">
          <?php esc_html_e( 'Learn more', 'themeflex' ); ?>
          <?php echo tf_icon_get( 'arrow-right', 16 ); ?>
        </a>
      </div>

      <!-- WordPress Development -->
      <div class="tfs-card">
        <div class="tfs-card__icon tfs-card__icon--code">
          <?php echo tf_icon_get( 'code', 28 ); ?>
        </div>
        <h3><?php esc_html_e( 'WordPress Development', 'themeflex' ); ?></h3>
        <p class="tfs-card__desc"><?php esc_html_e( 'Bespoke themes and plugins engineered for speed, security, and longevity. We write clean, well-documented code you will never have to throw away.', 'themeflex' ); ?></p>
        <ul class="tfs-card__bullets">
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'Custom theme development from scratch', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'Gutenberg &amp; Elementor block development', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'Headless WordPress + REST API', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'Automated testing &amp; CI/CD pipelines', 'themeflex' ); ?></li>
        </ul>
        <div class="tfs-card__tags">
          <span class="tfs-tag">WordPress</span>
          <span class="tfs-tag">PHP 8</span>
          <span class="tfs-tag">Gutenberg</span>
          <span class="tfs-tag">Headless</span>
        </div>
        <a href="#contact" class="tfs-card__cta">
          <?php esc_html_e( 'Learn more', 'themeflex' ); ?>
          <?php echo tf_icon_get( 'arrow-right', 16 ); ?>
        </a>
      </div>

      <!-- Performance -->
      <div class="tfs-card">
        <div class="tfs-card__icon tfs-card__icon--perf">
          <?php echo tf_icon_get( 'zap', 28 ); ?>
        </div>
        <h3><?php esc_html_e( 'Performance Optimisation', 'themeflex' ); ?></h3>
        <p class="tfs-card__desc"><?php esc_html_e( 'A 1-second delay in page load costs 7% in conversions. We surgically audit and optimise every asset, server configuration, and render-critical path on your site.', 'themeflex' ); ?></p>
        <ul class="tfs-card__bullets">
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'Core Web Vitals audit &amp; remediation', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'Image pipeline: AVIF, lazy loading, CDN', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'Server-side caching &amp; edge delivery', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'Sub-800ms LCP guarantee on delivery', 'themeflex' ); ?></li>
        </ul>
        <div class="tfs-card__tags">
          <span class="tfs-tag">WP Rocket</span>
          <span class="tfs-tag">Cloudflare</span>
          <span class="tfs-tag">Cloudinary</span>
          <span class="tfs-tag">Core Web Vitals</span>
        </div>
        <a href="#contact" class="tfs-card__cta">
          <?php esc_html_e( 'Learn more', 'themeflex' ); ?>
          <?php echo tf_icon_get( 'arrow-right', 16 ); ?>
        </a>
      </div>

      <!-- E-Commerce -->
      <div class="tfs-card">
        <div class="tfs-card__icon tfs-card__icon--ecom">
          <?php echo tf_icon_get( 'shopping-cart', 28 ); ?>
        </div>
        <h3><?php esc_html_e( 'E-Commerce', 'themeflex' ); ?></h3>
        <p class="tfs-card__desc"><?php esc_html_e( 'High-converting WooCommerce stores built to sell. From product architecture to checkout optimisation, we tune every touchpoint for maximum revenue.', 'themeflex' ); ?></p>
        <ul class="tfs-card__bullets">
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'WooCommerce build &amp; custom extensions', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'Multi-currency &amp; multi-language setup', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'Payment gateway integration', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'Abandoned cart &amp; upsell flows', 'themeflex' ); ?></li>
        </ul>
        <div class="tfs-card__tags">
          <span class="tfs-tag">WooCommerce</span>
          <span class="tfs-tag">Stripe</span>
          <span class="tfs-tag">Mailchimp</span>
          <span class="tfs-tag">Analytics</span>
        </div>
        <a href="#contact" class="tfs-card__cta">
          <?php esc_html_e( 'Learn more', 'themeflex' ); ?>
          <?php echo tf_icon_get( 'arrow-right', 16 ); ?>
        </a>
      </div>

      <!-- Security -->
      <div class="tfs-card">
        <div class="tfs-card__icon tfs-card__icon--sec">
          <?php echo tf_icon_get( 'shield-check', 28 ); ?>
        </div>
        <h3><?php esc_html_e( 'Security &amp; Maintenance', 'themeflex' ); ?></h3>
        <p class="tfs-card__desc"><?php esc_html_e( 'Sleep soundly knowing your site is monitored, hardened, and backed up around the clock. We proactively eliminate vulnerabilities before they become incidents.', 'themeflex' ); ?></p>
        <ul class="tfs-card__bullets">
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( '24/7 uptime monitoring &amp; alerting', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'Weekly core, plugin &amp; theme updates', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'Malware scanning &amp; firewall hardening', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'Off-site encrypted backups (30-day retention)', 'themeflex' ); ?></li>
        </ul>
        <div class="tfs-card__tags">
          <span class="tfs-tag">Wordfence</span>
          <span class="tfs-tag">Cloudflare WAF</span>
          <span class="tfs-tag">SSL/TLS</span>
          <span class="tfs-tag">2FA</span>
        </div>
        <a href="#contact" class="tfs-card__cta">
          <?php esc_html_e( 'Learn more', 'themeflex' ); ?>
          <?php echo tf_icon_get( 'arrow-right', 16 ); ?>
        </a>
      </div>

      <!-- SEO & Analytics -->
      <div class="tfs-card">
        <div class="tfs-card__icon tfs-card__icon--seo">
          <?php echo tf_icon_get( 'bar-chart-3', 28 ); ?>
        </div>
        <h3><?php esc_html_e( 'SEO &amp; Analytics', 'themeflex' ); ?></h3>
        <p class="tfs-card__desc"><?php esc_html_e( 'Data-led growth strategies that compound over time. We connect technical SEO, content architecture, and conversion analytics into a single measurable system.', 'themeflex' ); ?></p>
        <ul class="tfs-card__bullets">
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'Technical SEO audit &amp; structured data', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'GA4 &amp; Search Console configuration', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'Monthly ranking &amp; traffic reports', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check', 14 ); ?><?php esc_html_e( 'Conversion rate optimisation (CRO)', 'themeflex' ); ?></li>
        </ul>
        <div class="tfs-card__tags">
          <span class="tfs-tag">GA4</span>
          <span class="tfs-tag">Search Console</span>
          <span class="tfs-tag">Ahrefs</span>
          <span class="tfs-tag">Schema</span>
        </div>
        <a href="#contact" class="tfs-card__cta">
          <?php esc_html_e( 'Learn more', 'themeflex' ); ?>
          <?php echo tf_icon_get( 'arrow-right', 16 ); ?>
        </a>
      </div>

    </div><!-- .tfs-cards -->
  </div><!-- .tfs-wrap -->
</section>

<!-- ============================================================
     3. WHY CHOOSE US
     ============================================================ -->
<section class="tfs-why">
  <div class="tfs-wrap">
    <div class="tfs-section-head tfs-anim">
      <h2><?php esc_html_e( 'Why teams choose ThemeFlex', 'themeflex' ); ?></h2>
      <p><?php esc_html_e( 'Results you can measure, relationships that last.', 'themeflex' ); ?></p>
    </div>

    <div class="tfs-why__grid">
      <div class="tfs-why__item tfs-anim tfs-anim-delay-1">
        <div class="tfs-why__icon"><?php echo tf_icon_get( 'zap', 26 ); ?></div>
        <h3><?php esc_html_e( 'Lightning Fast', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'Sub-800ms LCP on every project we ship. Performance is not a feature we add at the end — it is baked into every line of code from day one.', 'themeflex' ); ?></p>
      </div>
      <div class="tfs-why__item tfs-anim tfs-anim-delay-2">
        <div class="tfs-why__icon"><?php echo tf_icon_get( 'award', 26 ); ?></div>
        <h3><?php esc_html_e( 'Award Winning', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'ThemeForest Choice Award 2024. Our work has been recognised by the industry\'s most demanding audiences and continues to set the standard for premium WordPress.', 'themeflex' ); ?></p>
      </div>
      <div class="tfs-why__item tfs-anim tfs-anim-delay-3">
        <div class="tfs-why__icon"><?php echo tf_icon_get( 'users', 26 ); ?></div>
        <h3><?php esc_html_e( 'Long-term Partner', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'Our average client relationship spans 3+ years. We invest in understanding your business so every recommendation serves your long-term growth, not a short-term invoice.', 'themeflex' ); ?></p>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     4. OUR PROCESS
     ============================================================ -->
<section class="tfs-process">
  <div class="tfs-wrap">
    <div class="tfs-section-head tfs-anim">
      <h2><?php esc_html_e( 'How we work', 'themeflex' ); ?></h2>
      <p><?php esc_html_e( 'A proven four-stage framework that removes uncertainty and keeps every project on time and on budget.', 'themeflex' ); ?></p>
    </div>

    <div class="tfs-process__steps">
      <div class="tfs-step tfs-anim tfs-anim-delay-1">
        <div class="tfs-step__num">01</div>
        <h3><?php esc_html_e( 'Discovery', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'Deep-dive workshops to map your goals, audience, competitors, and constraints. No assumptions, only evidence.', 'themeflex' ); ?></p>
      </div>
      <div class="tfs-step tfs-anim tfs-anim-delay-2">
        <div class="tfs-step__num">02</div>
        <h3><?php esc_html_e( 'Strategy', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'A documented roadmap with milestones, tech stack decisions, and measurable success criteria agreed before a line of code is written.', 'themeflex' ); ?></p>
      </div>
      <div class="tfs-step tfs-anim tfs-anim-delay-3">
        <div class="tfs-step__num">03</div>
        <h3><?php esc_html_e( 'Build', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'Two-week sprints with weekly review calls. You see real progress, give feedback in context, and retain full creative control throughout.', 'themeflex' ); ?></p>
      </div>
      <div class="tfs-step tfs-anim tfs-anim-delay-4">
        <div class="tfs-step__num">04</div>
        <h3><?php esc_html_e( 'Launch', 'themeflex' ); ?></h3>
        <p><?php esc_html_e( 'Zero-downtime deployment, post-launch monitoring, and a 60-day support window so your team can hit the ground running.', 'themeflex' ); ?></p>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     5. DEEP-DIVE SECTIONS
     ============================================================ -->
<section class="tfs-dive">
  <div class="tfs-wrap">

    <!-- Agency Web Design deep-dive -->
    <div class="tfs-dive__row tfs-anim">
      <div class="tfs-dive__art tfs-dive__art--design">
        <div class="tfs-dive__art-bg"></div>
        <div class="tfs-dive__art-blob"></div>
        <div class="tfs-dive__art-blob"></div>
        <div class="tfs-dive__art-icon">
          <?php echo tf_icon_get( 'palette', 44 ); ?>
        </div>
        <div class="tfs-stat-card tfs-stat-card--a">
          <div class="tfs-stat-card__val">+143%</div>
          <div class="tfs-stat-card__label"><?php esc_html_e( 'avg. conversion lift', 'themeflex' ); ?></div>
        </div>
        <div class="tfs-stat-card tfs-stat-card--b">
          <div class="tfs-stat-card__val">97</div>
          <div class="tfs-stat-card__label"><?php esc_html_e( 'avg. PageSpeed score', 'themeflex' ); ?></div>
        </div>
      </div>

      <div class="tfs-dive__text">
        <div class="tfs-eyebrow"><?php echo tf_icon_get( 'layers', 14 ); ?> <?php esc_html_e( 'Agency Web Design', 'themeflex' ); ?></div>
        <h2><?php esc_html_e( 'Websites that win business before you say a word', 'themeflex' ); ?></h2>
        <p><?php esc_html_e( 'We design websites for agencies, SaaS companies, and professional services firms that need to project authority instantly. Every layout decision is grounded in conversion psychology, every animation serves a purpose, and every page load is sub-second.', 'themeflex' ); ?></p>
        <ul class="tfs-dive__bullets">
          <li><?php echo tf_icon_get( 'check-circle', 16 ); ?><?php esc_html_e( 'Brand-aligned visual identity translated to web with precision', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check-circle', 16 ); ?><?php esc_html_e( 'Conversion-optimised landing pages with heatmap-validated layouts', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check-circle', 16 ); ?><?php esc_html_e( 'Motion design and micro-interactions that delight without distraction', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check-circle', 16 ); ?><?php esc_html_e( 'Mobile-first responsive build tested across 20+ device profiles', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check-circle', 16 ); ?><?php esc_html_e( 'Handoff documentation and editor training for your content team', 'themeflex' ); ?></li>
        </ul>
        <a href="#contact" class="tfs-btn tfs-btn--primary">
          <?php echo tf_icon_get( 'rocket', 18 ); ?>
          <?php esc_html_e( 'Start Your Design Project', 'themeflex' ); ?>
        </a>
      </div>
    </div>

    <!-- E-Commerce deep-dive (flipped) -->
    <div class="tfs-dive__row tfs-dive__row--flip tfs-anim">
      <div class="tfs-dive__text">
        <div class="tfs-eyebrow"><?php echo tf_icon_get( 'shopping-cart', 14 ); ?> <?php esc_html_e( 'E-Commerce', 'themeflex' ); ?></div>
        <h2><?php esc_html_e( 'Stores engineered to convert at every price point', 'themeflex' ); ?></h2>
        <p><?php esc_html_e( 'Whether you are launching a boutique DTC brand or migrating a 50,000-SKU catalogue, we build WooCommerce stores that scale gracefully and sell relentlessly. Revenue optimisation is not an afterthought — it drives every architecture decision.', 'themeflex' ); ?></p>
        <ul class="tfs-dive__bullets">
          <li><?php echo tf_icon_get( 'check-circle', 16 ); ?><?php esc_html_e( 'Custom WooCommerce theme with optimised checkout flow', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check-circle', 16 ); ?><?php esc_html_e( 'Product filtering, faceted search, and smart recommendations', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check-circle', 16 ); ?><?php esc_html_e( 'Subscription, bundle, and upsell mechanics built in from day one', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check-circle', 16 ); ?><?php esc_html_e( 'ERP / 3PL integrations and inventory sync pipelines', 'themeflex' ); ?></li>
          <li><?php echo tf_icon_get( 'check-circle', 16 ); ?><?php esc_html_e( 'Headless commerce option with Next.js storefront for maximum speed', 'themeflex' ); ?></li>
        </ul>
        <a href="#contact" class="tfs-btn tfs-btn--primary">
          <?php echo tf_icon_get( 'trending-up', 18 ); ?>
          <?php esc_html_e( 'Grow Your Store Revenue', 'themeflex' ); ?>
        </a>
      </div>

      <div class="tfs-dive__art tfs-dive__art--ecom">
        <div class="tfs-dive__art-bg"></div>
        <div class="tfs-dive__art-blob"></div>
        <div class="tfs-dive__art-blob"></div>
        <div class="tfs-dive__art-icon">
          <?php echo tf_icon_get( 'shopping-cart', 44 ); ?>
        </div>
        <div class="tfs-stat-card tfs-stat-card--a">
          <div class="tfs-stat-card__val">+38%</div>
          <div class="tfs-stat-card__label"><?php esc_html_e( 'avg. AOV increase', 'themeflex' ); ?></div>
        </div>
        <div class="tfs-stat-card tfs-stat-card--b">
          <div class="tfs-stat-card__val">2.1s</div>
          <div class="tfs-stat-card__label"><?php esc_html_e( 'avg. checkout time', 'themeflex' ); ?></div>
        </div>
      </div>
    </div>

  </div><!-- .tfs-wrap -->
</section>

<!-- ============================================================
     6. STACK / TOOLS
     ============================================================ -->
<section class="tfs-stack">
  <div class="tfs-wrap">
    <div class="tfs-section-head tfs-anim">
      <h2><?php esc_html_e( 'Our technology stack', 'themeflex' ); ?></h2>
      <p><?php esc_html_e( 'Best-in-class tools, expertly combined — so you inherit a proven, modern, and maintainable platform.', 'themeflex' ); ?></p>
    </div>

    <div class="tfs-stack__grid">
      <?php
      $tools = [
        [ 'name' => 'WordPress',   'init' => 'WP', 'bg' => '#21759b' ],
        [ 'name' => 'Elementor',   'init' => 'El', 'bg' => '#92003b' ],
        [ 'name' => 'WooCommerce', 'init' => 'Woo','bg' => '#7f54b3' ],
        [ 'name' => 'Figma',       'init' => 'Fi', 'bg' => '#f24e1e' ],
        [ 'name' => 'Cloudflare',  'init' => 'CF', 'bg' => '#f38020' ],
        [ 'name' => 'Google',      'init' => 'G',  'bg' => '#4285f4' ],
        [ 'name' => 'GA4',         'init' => 'GA', 'bg' => '#e8710a' ],
        [ 'name' => 'Wordfence',   'init' => 'Wf', 'bg' => '#2271b1' ],
        [ 'name' => 'WP Rocket',   'init' => 'WR', 'bg' => '#ff6243' ],
        [ 'name' => 'Cloudinary',  'init' => 'Cl', 'bg' => '#3448c5' ],
        [ 'name' => 'Mailchimp',   'init' => 'Mc', 'bg' => '#ffe01b', 'color' => '#000' ],
        [ 'name' => 'Vercel',      'init' => 'V',  'bg' => '#fff', 'color' => '#000' ],
      ];
      foreach ( $tools as $tool ) :
        $color = isset( $tool['color'] ) ? esc_attr( $tool['color'] ) : '#fff';
      ?>
        <div class="tfs-tool tfs-anim">
          <div class="tfs-tool__chip" style="background:<?php echo esc_attr( $tool['bg'] ); ?>;color:<?php echo $color; ?>">
            <?php echo esc_html( $tool['init'] ); ?>
          </div>
          <div class="tfs-tool__name"><?php echo esc_html( $tool['name'] ); ?></div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ============================================================
     7. PRICING TEASER
     ============================================================ -->
<section class="tfs-pricing">
  <div class="tfs-wrap">
    <div class="tfs-section-head tfs-anim">
      <h2><?php esc_html_e( 'Transparent project investment', 'themeflex' ); ?></h2>
      <p><?php esc_html_e( 'Every engagement is scoped to your exact needs. These tiers give you a starting point for planning.', 'themeflex' ); ?></p>
    </div>

    <div class="tfs-pricing__cards">
      <div class="tfs-pricing-card tfs-anim tfs-anim-delay-1">
        <div class="tfs-pricing-card__tier"><?php esc_html_e( 'Starter', 'themeflex' ); ?></div>
        <div class="tfs-pricing-card__price"><?php esc_html_e( '$2,500', 'themeflex' ); ?></div>
        <div class="tfs-pricing-card__from"><?php esc_html_e( 'starting from', 'themeflex' ); ?></div>
        <p class="tfs-pricing-card__desc"><?php esc_html_e( 'For small businesses launching online. A polished 5-page WordPress site with performance and SEO foundations.', 'themeflex' ); ?></p>
      </div>
      <div class="tfs-pricing-card tfs-pricing-card--featured tfs-anim tfs-anim-delay-2">
        <div class="tfs-pricing-card__tier"><?php esc_html_e( 'Growth', 'themeflex' ); ?></div>
        <div class="tfs-pricing-card__price"><?php esc_html_e( '$7,500', 'themeflex' ); ?></div>
        <div class="tfs-pricing-card__from"><?php esc_html_e( 'starting from', 'themeflex' ); ?></div>
        <p class="tfs-pricing-card__desc"><?php esc_html_e( 'For growing agencies and e-commerce brands. Custom theme, advanced integrations, and ongoing retainer support.', 'themeflex' ); ?></p>
      </div>
      <div class="tfs-pricing-card tfs-anim tfs-anim-delay-3">
        <div class="tfs-pricing-card__tier"><?php esc_html_e( 'Enterprise', 'themeflex' ); ?></div>
        <div class="tfs-pricing-card__price"><?php esc_html_e( '$20,000', 'themeflex' ); ?></div>
        <div class="tfs-pricing-card__from"><?php esc_html_e( 'starting from', 'themeflex' ); ?></div>
        <p class="tfs-pricing-card__desc"><?php esc_html_e( 'Full digital rebuild plus dedicated retainer. Headless option, global CDN, SLA-backed maintenance, and quarterly strategy reviews.', 'themeflex' ); ?></p>
      </div>
    </div>

    <div class="tfs-pricing__footer tfs-anim">
      <a href="<?php echo esc_url( home_url( '/pricing/' ) ); ?>">
        <?php esc_html_e( 'View full pricing details', 'themeflex' ); ?>
        <?php echo tf_icon_get( 'arrow-right', 16 ); ?>
      </a>
    </div>
  </div>
</section>

<!-- ============================================================
     8. TESTIMONIALS
     ============================================================ -->
<section class="tfs-testimonials">
  <div class="tfs-wrap">
    <div class="tfs-section-head tfs-anim">
      <h2><?php esc_html_e( 'What our clients say', 'themeflex' ); ?></h2>
      <p><?php esc_html_e( 'Feedback from teams who trusted us with their most important digital asset.', 'themeflex' ); ?></p>
    </div>

    <div class="tfs-testi-grid">

      <div class="tfs-testi tfs-anim tfs-anim-delay-1">
        <div class="tfs-testi__stars">
          <span>&#9733;</span><span>&#9733;</span><span>&#9733;</span><span>&#9733;</span><span>&#9733;</span>
        </div>
        <p class="tfs-testi__quote"><?php esc_html_e( '"ThemeFlex rebuilt our entire agency site in six weeks. PageSpeed went from 54 to 98, enquiries doubled in the first month, and our team can update every section without touching code. The attention to detail is extraordinary."', 'themeflex' ); ?></p>
        <div class="tfs-testi__author">
          <div class="tfs-testi__avatar tfs-testi__avatar--a">SM</div>
          <div>
            <div class="tfs-testi__name"><?php esc_html_e( 'Sarah M.', 'themeflex' ); ?></div>
            <div class="tfs-testi__role"><?php esc_html_e( 'Creative Director, Volta Studio', 'themeflex' ); ?></div>
          </div>
        </div>
      </div>

      <div class="tfs-testi tfs-anim tfs-anim-delay-2">
        <div class="tfs-testi__stars">
          <span>&#9733;</span><span>&#9733;</span><span>&#9733;</span><span>&#9733;</span><span>&#9733;</span>
        </div>
        <p class="tfs-testi__quote"><?php esc_html_e( '"Our WooCommerce store migration was seamless — zero downtime, 40% faster checkout, and AOV up by a third within 90 days. The team understands both the technical and commercial side of e-commerce at a level I have never experienced before."', 'themeflex' ); ?></p>
        <div class="tfs-testi__author">
          <div class="tfs-testi__avatar tfs-testi__avatar--b">JR</div>
          <div>
            <div class="tfs-testi__name"><?php esc_html_e( 'James R.', 'themeflex' ); ?></div>
            <div class="tfs-testi__role"><?php esc_html_e( 'Head of Digital, Nordvik Goods', 'themeflex' ); ?></div>
          </div>
        </div>
      </div>

      <div class="tfs-testi tfs-anim tfs-anim-delay-3">
        <div class="tfs-testi__stars">
          <span>&#9733;</span><span>&#9733;</span><span>&#9733;</span><span>&#9733;</span><span>&#9733;</span>
        </div>
        <p class="tfs-testi__quote"><?php esc_html_e( '"Three years on retainer and they still treat every request with the same urgency as day one. The maintenance plan has kept us at 100% uptime through two major plugin conflicts that could have been devastating. Genuinely indispensable partners."', 'themeflex' ); ?></p>
        <div class="tfs-testi__author">
          <div class="tfs-testi__avatar tfs-testi__avatar--c">LP</div>
          <div>
            <div class="tfs-testi__name"><?php esc_html_e( 'Laura P.', 'themeflex' ); ?></div>
            <div class="tfs-testi__role"><?php esc_html_e( 'CTO, Meridian SaaS', 'themeflex' ); ?></div>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- ============================================================
     9. FAQ
     ============================================================ -->
<section class="tfs-faq">
  <div class="tfs-wrap--narrow">
    <div class="tfs-section-head tfs-anim">
      <h2><?php esc_html_e( 'Frequently asked questions', 'themeflex' ); ?></h2>
      <p><?php esc_html_e( 'Straight answers to the questions we hear most often.', 'themeflex' ); ?></p>
    </div>

    <div class="tfs-faq__list tfs-anim">

      <?php
      $faqs = [
        [
          'q' => esc_html__( 'How long does a typical project take?', 'themeflex' ),
          'a' => esc_html__( 'A standard 5-page site takes 4–6 weeks from kickoff to launch. WooCommerce stores typically run 8–12 weeks depending on catalogue complexity. Enterprise rebuilds are scoped individually. All timelines include a 2-week buffer for feedback rounds — so the date we give you is the date you get your site.', 'themeflex' ),
        ],
        [
          'q' => esc_html__( 'Do you work with clients outside Germany?', 'themeflex' ),
          'a' => esc_html__( 'Yes. We work with clients across Europe, North America, and Australia entirely remotely. Our project management tooling is async-first, and we schedule review calls to suit your timezone. English and German are both fully supported.', 'themeflex' ),
        ],
        [
          'q' => esc_html__( 'Will I be able to edit the site myself after launch?', 'themeflex' ),
          'a' => esc_html__( 'Absolutely. Every project includes a structured content editor training session and written documentation. We build with the WordPress block editor or Elementor so your team can update text, images, and layouts without touching code. If you hit a wall, our maintenance clients get priority support responses within 4 business hours.', 'themeflex' ),
        ],
        [
          'q' => esc_html__( 'What does the maintenance retainer include?', 'themeflex' ),
          'a' => esc_html__( 'Retainer plans cover weekly core, plugin, and theme updates tested in a staging environment before deployment; 24/7 uptime monitoring with SMS/email alerting; daily off-site encrypted backups with 30-day retention; malware scanning and firewall rule management; and up to 2 hours of content or minor development changes per month.', 'themeflex' ),
        ],
        [
          'q' => esc_html__( 'How is the project price calculated?', 'themeflex' ),
          'a' => esc_html__( 'We provide fixed-price quotes based on a detailed scope document agreed before work begins. Pricing reflects design complexity, number of templates, third-party integrations, and post-launch support requirements. Change requests outside the agreed scope are quoted separately and require your written approval before we proceed — so there are never any surprise invoices.', 'themeflex' ),
        ],
      ];
      foreach ( $faqs as $i => $faq ) : ?>
        <div class="tfs-faq__item" id="tfs-faq-<?php echo esc_attr( $i ); ?>">
          <button
            class="tfs-faq__trigger"
            aria-expanded="false"
            aria-controls="tfs-faq-body-<?php echo esc_attr( $i ); ?>"
          >
            <?php echo esc_html( $faq['q'] ); ?>
            <span class="tfs-faq__chevron" aria-hidden="true">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
            </span>
          </button>
          <div
            class="tfs-faq__body"
            id="tfs-faq-body-<?php echo esc_attr( $i ); ?>"
            role="region"
            aria-labelledby="tfs-faq-<?php echo esc_attr( $i ); ?>"
          >
            <p><?php echo esc_html( $faq['a'] ); ?></p>
          </div>
        </div>
      <?php endforeach; ?>

    </div>
  </div>
</section>

<!-- ============================================================
     10. CTA BANNER
     ============================================================ -->
<section class="tfs-cta" id="contact">
  <div class="tfs-cta__inner">
    <div class="tfs-eyebrow tfs-anim">
      <?php echo tf_icon_get( 'rocket', 14 ); ?>
      <?php esc_html_e( 'Let\'s build something remarkable', 'themeflex' ); ?>
    </div>
    <h2 class="tfs-anim"><?php esc_html_e( 'Ready to start your project?', 'themeflex' ); ?></h2>
    <p class="tfs-anim"><?php esc_html_e( 'Book a free 30-minute strategy call and leave with a clear picture of what is possible, how long it takes, and what it costs.', 'themeflex' ); ?></p>
    <div class="tfs-cta__btns tfs-anim">
      <a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="tfs-btn tfs-btn--primary">
        <?php echo tf_icon_get( 'mail', 18 ); ?>
        <?php esc_html_e( 'Get a Free Quote', 'themeflex' ); ?>
      </a>
      <a href="<?php echo esc_url( home_url( '/portfolio/' ) ); ?>" class="tfs-btn tfs-btn--outline">
        <?php echo tf_icon_get( 'layers', 18 ); ?>
        <?php esc_html_e( 'View Our Work', 'themeflex' ); ?>
      </a>
    </div>
  </div>
</section>

<script>
(function(){
  'use strict';

  /* ── IntersectionObserver: stagger animate cards + generic .tfs-anim ── */
  var observer = new IntersectionObserver(function(entries){
    entries.forEach(function(entry){
      if(entry.isIntersecting){
        entry.target.classList.add('tfs-visible');
        observer.unobserve(entry.target);
      }
    });
  },{threshold:0.12});

  document.querySelectorAll('.tfs-card, .tfs-anim').forEach(function(el,i){
    /* Stagger cards within same parent */
    if(el.classList.contains('tfs-card')){
      el.style.transitionDelay = (i % 3) * 80 + 'ms';
    }
    observer.observe(el);
  });

  /* ── FAQ accordion ── */
  document.querySelectorAll('.tfs-faq__trigger').forEach(function(btn){
    btn.addEventListener('click', function(){
      var item   = btn.closest('.tfs-faq__item');
      var isOpen = item.classList.contains('tfs-faq--open');

      /* Close all */
      document.querySelectorAll('.tfs-faq__item').forEach(function(i){
        i.classList.remove('tfs-faq--open');
        i.querySelector('.tfs-faq__trigger').setAttribute('aria-expanded','false');
      });

      /* Open clicked (unless it was already open) */
      if(!isOpen){
        item.classList.add('tfs-faq--open');
        btn.setAttribute('aria-expanded','true');
      }
    });
  });
})();
</script>

</main><!-- #primary -->

<?php get_footer(); ?>
