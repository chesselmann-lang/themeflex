<?php
/**
 * Template Name: Solicitor – Prestige Law Firm
 * Description:   Premium ThemeFlex template for a prestigious London law firm.
 *                CSS art hero: a Georgian Inns of Court courtyard at dusk —
 *                stone archways, leaded windows with warm candlelight, the
 *                scales of justice, an open law book, a barrister's wig,
 *                floating legal particles, and evening sky gradient.
 *                Namespace: --sol-* | Fonts: Libre Baskerville + Source Sans 3
 */
srand(crc32(get_the_permalink()));

/* ── Floating legal particles ────────────────────────────────────── */
$legal_particles = [];
for ($i = 0; $i < 20; $i++) {
    $legal_particles[] = [
        'left'  => rand(2, 98),
        'top'   => rand(5, 85),
        'size'  => rand(6, 16),
        'delay' => rand(0, 80) / 10,
        'dur'   => rand(80, 160) / 10,
        'type'  => rand(0, 2), // 0=star, 1=dot, 2=gavel
    ];
}

/* ── Window lights data ──────────────────────────────────────────── */
$windows = [];
for ($i = 0; $i < 10; $i++) {
    $windows[] = [
        'lit'   => rand(0, 1),
        'flicker'=> rand(0, 1),
    ];
}

/* ── Practice areas ──────────────────────────────────────────────── */
$practice_areas = [
    ['icon'=>'⚖','title'=>'Commercial Law','desc'=>'From company formation and shareholder agreements to M&A transactions and commercial contracts — we protect and advance your business interests.'],
    ['icon'=>'🏛','title'=>'Property & Conveyancing','desc'=>'Residential and commercial property transactions, lease negotiations, development agreements, and landlord & tenant disputes handled with precision.'],
    ['icon'=>'👨‍👩‍👧','title'=>'Family Law','desc'=>'Sensitive, pragmatic advice on divorce, financial settlements, child arrangements, and cohabitation disputes — always focused on the best outcome for your family.'],
    ['icon'=>'📋','title'=>'Wills & Probate','desc'=>'Comprehensive estate planning, will drafting, lasting powers of attorney, and estate administration — ensuring your wishes are honoured and your loved ones protected.'],
    ['icon'=>'🤝','title'=>'Employment Law','desc'=>'Expert advice for employers and employees on contracts, tribunal claims, TUPE, redundancy, discrimination, and senior executive exits.'],
    ['icon'=>'⚡','title'=>'Dispute Resolution','desc'=>'Strategic litigation and alternative dispute resolution — from pre-action negotiations to High Court proceedings and commercial arbitration.'],
];

/* ── Notable achievements ────────────────────────────────────────── */
$achievements = [
    'Legal 500 — Tier 1 ranking in Commercial Property 2024',
    'Chambers UK — Band 1 for Employment Law (London) 2024',
    'The Lawyer — Top 100 UK Law Firms 2023',
    'Law Society Excellence Award — Client Care 2023',
    'Financial Times — Innovative Lawyers UK 2022',
];

/* ── Team ────────────────────────────────────────────────────────── */
$team = [
    ['name'=>'Catherine Ashworth QC','title'=>'Senior Partner','spec'=>'Commercial Litigation, Arbitration','exp'=>'28 years','ql'=>'LLB Cambridge · Barrister (Inner Temple)'],
    ['name'=>'Thomas Everton','title'=>'Partner','spec'=>'Commercial Property & Development','exp'=>'21 years','ql'=>'LLB Durham · Solicitor'],
    ['name'=>'Dr Priya Sharma','title'=>'Partner','spec'=>'Employment & Data Protection','exp'=>'17 years','ql'=>'LLB LLM · GDPR Specialist'],
    ['name'=>'James Whitfield','title'=>'Senior Associate','spec'=>'Corporate M&A, Private Equity','exp'=>'11 years','ql'=>'LLB Bristol · Solicitor'],
];

/* ── Stats ────────────────────────────────────────────────────────── */
$stats = [
    ['val'=>'1888','label'=>'Year Established','suffix'=>''],
    ['val'=>'4.8','label'=>'Client Rating','suffix'=>'★'],
    ['val'=>'98','label'=>'Cases Won','suffix'=>'%'],
    ['val'=>'2400','label'=>'Clients Served','suffix'=>'+'],
];

/* ── Testimonials ─────────────────────────────────────────────────── */
$testimonials = [
    ['quote'=>'Ashworth & Everton handled our £40m acquisition with remarkable skill and efficiency. Their commercial property team is simply outstanding — we wouldn\'t trust anyone else.','name'=>'Richard B.','role'=>'CEO, Property Development Group'],
    ['quote'=>'Catherine Ashworth\'s advocacy at the Court of Appeal was extraordinary. She understood every nuance of our position and delivered a result that exceeded all expectations.','name'=>'Sarah T.','role'=>'Managing Director, Financial Services'],
    ['quote'=>'In the most difficult time of my life, the family team showed genuine care and brilliant legal acumen. My case resolved quickly and favourably. I cannot recommend them highly enough.','name'=>'Anonymous','role'=>'Family Law Client'],
];

/* ── FAQs ─────────────────────────────────────────────────────────── */
$faqs = [
    ['q'=>'Do you offer a free initial consultation?','a'=>'Yes. We offer a complimentary 30-minute consultation for new clients — in person at our Lincoln\'s Inn chambers, by video conference, or by telephone. This allows us to understand your situation and advise on the best course of action.'],
    ['q'=>'How are your fees structured?','a'=>'We offer hourly rates, fixed fees for defined matters (particularly conveyancing, wills, and probate), and where appropriate, conditional fee arrangements (no win, no fee) for litigation. All fees are agreed transparently before we begin any work.'],
    ['q'=>'Are you regulated by the Solicitors Regulation Authority?','a'=>'Yes. Ashworth & Everton LLP is authorised and regulated by the Solicitors Regulation Authority (SRA number 12345678). Our professional indemnity insurance is maintained at the required level.'],
    ['q'=>'Can you assist with international matters?','a'=>'Yes. We have extensive experience in cross-border transactions and international arbitration, and maintain relationships with leading law firms in over 40 jurisdictions through our global network.'],
    ['q'=>'How quickly can you respond to urgent matters?','a'=>'We understand that legal matters are often time-sensitive. We aim to respond to all urgent enquiries within two hours during business hours, and have a duty solicitor on call for genuinely critical matters outside office hours.'],
];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&family=Source+Sans+3:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════════════════
   THEMEFLEX – LAW FIRM / SOLICITORS  (--sol-* namespace)
═══════════════════════════════════════════════════════════════════ */
:root{
  --sol-navy:    #0C1428;
  --sol-navy-md: #162040;
  --sol-navy-lt: #1E2E58;
  --sol-gold:    #B8943A;
  --sol-gold-lt: #D4B060;
  --sol-cream:   #F8F4EC;
  --sol-ivory:   #FBF9F5;
  --sol-stone:   #E8E0D0;
  --sol-charcoal:#3A3028;
  --sol-border:  rgba(184,148,58,.2);
  --sol-border-lt:rgba(184,148,58,.1);
  --sol-r:       4px;
  --sol-shadow:  0 8px 40px rgba(12,20,40,.12);
  --sol-font-h:  'Libre Baskerville', Georgia, serif;
  --sol-font-b:  'Source Sans 3', system-ui, sans-serif;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body.page-template-page-solicitor{
  background:var(--sol-ivory);
  color:var(--sol-charcoal);
  font-family:var(--sol-font-b);
  font-size:16px;
  line-height:1.7;
}

/* ── Utility ─────────────────────────────────────────────────────── */
.sol-wrap{max-width:1200px;margin:0 auto;padding:0 clamp(16px,4vw,48px)}
.sol-badge{display:inline-block;font-family:var(--sol-font-b);font-size:.73rem;font-weight:600;letter-spacing:.18em;text-transform:uppercase;color:var(--sol-gold);border-bottom:1px solid var(--sol-border);padding-bottom:.3em;margin-bottom:1.2rem}
.sol-h1{font-family:var(--sol-font-h);font-size:clamp(2.4rem,5vw,4rem);font-weight:700;line-height:1.2;color:var(--sol-ivory)}
.sol-h2{font-family:var(--sol-font-h);font-size:clamp(1.9rem,3.8vw,3rem);font-weight:700;line-height:1.22;color:var(--sol-navy)}
.sol-h2-light{color:var(--sol-ivory)}
.sol-lead{font-size:clamp(1rem,1.5vw,1.1rem);line-height:1.8;max-width:640px}
.sol-btn{display:inline-block;padding:.85em 2em;font-family:var(--sol-font-b);font-size:.88rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;text-decoration:none;cursor:pointer;border:none;transition:all .28s ease}
.sol-btn-gold{background:var(--sol-gold);color:#fff}
.sol-btn-gold:hover{background:var(--sol-gold-lt);transform:translateY(-2px);box-shadow:0 6px 24px rgba(184,148,58,.4)}
.sol-btn-outline{background:transparent;color:var(--sol-gold);border:1px solid var(--sol-border)}
.sol-btn-outline:hover{background:rgba(184,148,58,.08);border-color:var(--sol-gold)}
.sol-btn-outline-light{background:transparent;color:var(--sol-cream);border:1px solid rgba(248,244,236,.3)}
.sol-btn-outline-light:hover{background:rgba(248,244,236,.1)}
.sol-section{padding:clamp(64px,9vw,120px) 0}
.sol-section-cream{background:var(--sol-cream)}
.sol-section-dark{background:var(--sol-navy);color:var(--sol-cream)}
.sol-divider{width:48px;height:2px;background:var(--sol-gold);margin:1.2rem 0 2rem}
.sol-center{text-align:center}
.sol-center .sol-divider{margin-left:auto;margin-right:auto}
.sol-rule{width:100%;height:1px;background:var(--sol-border);margin:2rem 0}

/* ── NAV ─────────────────────────────────────────────────────────── */
.sol-nav{
  position:fixed;top:0;left:0;right:0;z-index:999;
  background:rgba(12,20,40,.97);
  backdrop-filter:blur(12px);
  border-bottom:1px solid var(--sol-border-lt);
  padding:0 clamp(16px,4vw,48px);
}
.sol-nav-inner{
  display:flex;align-items:center;justify-content:space-between;
  max-width:1200px;margin:0 auto;height:72px;
}
.sol-logo{
  font-family:var(--sol-font-h);font-size:1.15rem;font-weight:700;
  color:var(--sol-cream);text-decoration:none;letter-spacing:.04em;
}
.sol-logo span{color:var(--sol-gold)}
.sol-nav-links{display:flex;gap:2rem;list-style:none}
.sol-nav-links a{font-size:.78rem;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:rgba(248,244,236,.7);text-decoration:none;transition:color .22s}
.sol-nav-links a:hover{color:var(--sol-gold)}
.sol-nav-cta{display:flex;gap:.8rem;align-items:center}

/* ── HERO ────────────────────────────────────────────────────────── */
.sol-hero{
  position:relative;min-height:100vh;display:flex;align-items:center;
  overflow:hidden;padding-top:72px;
  background:linear-gradient(180deg,#060C1A 0%,#0C1428 40%,#162040 70%,#1E2848 100%);
}

/* Evening sky particles */
.sol-hero-scene{position:absolute;inset:0;overflow:hidden;pointer-events:none;z-index:1}

/* Stars */
.sol-star{position:absolute;background:#fff;border-radius:50%}

/* Georgian building facade */
.sol-building{
  position:absolute;bottom:0;left:50%;transform:translateX(-50%);
  width:720px;height:65%;
  background:linear-gradient(180deg,#2A2418 0%,#1E1C14 100%);
  border-top:3px solid rgba(184,148,58,.3);
}
/* Pediment (triangular top) */
.sol-building::before{
  content:'';position:absolute;top:-60px;left:50%;transform:translateX(-50%);
  width:0;height:0;
  border-left:80px solid transparent;
  border-right:80px solid transparent;
  border-bottom:60px solid #1E1C14;
}
/* Cornice line */
.sol-building::after{
  content:'';position:absolute;top:-8px;left:0;right:0;height:8px;
  background:linear-gradient(90deg,#3A3020,#4A4030,#3A3020);
}

/* Columns */
.sol-column{
  position:absolute;bottom:0;
  width:28px;
  background:linear-gradient(90deg,#3A3428,#4A4438,#3A3428);
  border-radius:2px 2px 0 0;
}
.sol-column::before{/* capital */
  content:'';position:absolute;top:0;left:-6px;right:-6px;height:14px;
  background:#4A4438;
  border-radius:2px;
}
.sol-column::after{/* base */
  content:'';position:absolute;bottom:0;left:-4px;right:-4px;height:12px;
  background:#4A4438;
  border-radius:0 0 2px 2px;
}

/* Arched doorway */
.sol-door{
  position:absolute;bottom:0;left:50%;transform:translateX(-50%);
  width:80px;height:140px;
  background:linear-gradient(180deg,#0A1828,#06101E);
  border-radius:40px 40px 0 0;
  border:3px solid rgba(184,148,58,.3);
  border-bottom:none;
}
.sol-door::before{/* door knocker */
  content:'';position:absolute;top:40%;left:50%;transform:translateX(-50%);
  width:8px;height:12px;
  border:2px solid var(--sol-gold);
  border-radius:50%;
}
/* Fanlight */
.sol-fanlight{
  position:absolute;top:0;left:50%;transform:translateX(-50%);
  width:80px;height:40px;
  border-radius:40px 40px 0 0;
  border:2px solid rgba(184,148,58,.4);
  border-bottom:none;
  overflow:hidden;
}
.sol-fanlight::before{
  content:'';position:absolute;inset:0;
  background:radial-gradient(ellipse at 50% 100%,rgba(255,200,80,.2),transparent);
}

/* Building windows (PHP-generated rows × columns) */
.sol-win{
  position:absolute;
  background:rgba(255,210,100,.0); /* default dark */
  border:1px solid rgba(184,148,58,.2);
  border-radius:2px 2px 0 0;
}
.sol-win.lit{
  background:radial-gradient(ellipse at 50% 120%,rgba(255,200,80,.35),rgba(255,180,60,.15));
  box-shadow:0 0 8px rgba(255,200,80,.2);
}

/* Courtyard cobblestones */
.sol-courtyard{
  position:absolute;bottom:0;left:0;right:0;height:12%;
  background:linear-gradient(180deg,#3A3428 0%,#2A2418 100%);
}
.sol-courtyard::before{
  content:'';position:absolute;inset:0;
  background:repeating-linear-gradient(90deg,transparent,transparent 28px,rgba(255,255,255,.04) 28px,rgba(255,255,255,.04) 30px),
             repeating-linear-gradient(2deg,transparent,transparent 14px,rgba(255,255,255,.04) 14px,rgba(255,255,255,.04) 16px);
}

/* CSS Scales of Justice */
.sol-scales{
  position:absolute;bottom:65%;left:15%;
  width:90px;height:100px;
  z-index:3;
}
.sol-scales-beam{
  position:absolute;top:20px;left:0;right:0;height:4px;
  background:linear-gradient(90deg,var(--sol-gold-lt),var(--sol-gold),var(--sol-gold-lt));
  border-radius:2px;
}
.sol-scales-pole{
  position:absolute;top:0;left:50%;transform:translateX(-50%);
  width:3px;height:100px;
  background:linear-gradient(180deg,var(--sol-gold-lt),var(--sol-gold-dk,#8A6820));
}
.sol-scales-pole::before{/* crown top */
  content:'';position:absolute;top:-6px;left:50%;transform:translateX(-50%);
  width:10px;height:10px;
  background:var(--sol-gold-lt);
  clip-path:polygon(50% 0%,100% 100%,0% 100%);
}
.sol-scales-chain{
  position:absolute;top:22px;width:2px;
  background:var(--sol-gold);
  transform-origin:top center;
}
.sol-scales-chain-l{left:8px;height:30px;transform:rotate(-12deg)}
.sol-scales-chain-r{right:8px;height:20px;transform:rotate(8deg)}
.sol-scales-pan{
  position:absolute;
  width:28px;height:6px;
  background:linear-gradient(90deg,#9A7820,var(--sol-gold-lt),#9A7820);
  border-radius:0 0 14px 14px;
}
.sol-scales-pan-l{bottom:40px;left:0;transform:rotate(-12deg)}
.sol-scales-pan-r{bottom:50px;right:0;transform:rotate(8deg)}

/* CSS Law book */
.sol-book{
  position:absolute;bottom:65%;right:14%;
  width:70px;height:90px;
}
.sol-book-body{
  position:absolute;bottom:0;left:10px;right:0;top:0;
  background:linear-gradient(145deg,#8A2820,#6A1810);
  border-radius:2px 4px 4px 2px;
  border:1px solid rgba(184,148,58,.3);
}
.sol-book-body::before{/* gold title bar */
  content:'';position:absolute;top:14px;left:8px;right:8px;height:2px;background:var(--sol-gold);
}
.sol-book-body::after{/* pages */
  content:'';position:absolute;top:4px;left:-4px;bottom:4px;width:6px;
  background:linear-gradient(180deg,#F8F4EC,#E8E0D0);
  border-radius:1px 0 0 1px;
}
.sol-book-spine{
  position:absolute;bottom:0;left:0;top:0;width:10px;
  background:linear-gradient(90deg,#6A1810,#8A2820);
  border-radius:2px 0 0 2px;
}
/* Lines on book interior */
.sol-book-lines{
  position:absolute;top:22px;left:14px;right:8px;bottom:8px;
  display:flex;flex-direction:column;gap:5px;
  overflow:hidden;
}
.sol-book-line{height:2px;background:rgba(184,148,58,.2);border-radius:1px}

/* CSS Wig */
.sol-wig{
  position:absolute;bottom:calc(65% + 90px);left:15%;
  width:80px;height:60px;
}
.sol-wig-top{
  position:absolute;top:0;left:50%;transform:translateX(-50%);
  width:50px;height:20px;
  background:linear-gradient(145deg,#E8E4DC,#D8D4CC);
  border-radius:50% 50% 30% 30%;
}
.sol-wig-curl{
  position:absolute;bottom:0;
  width:22px;height:36px;
  background:linear-gradient(180deg,#D8D4CC,#C8C4BC);
  border-radius:50%;
}
.sol-wig-curl-l{left:0}
.sol-wig-curl-r{right:4px}
.sol-wig-curl::before{
  content:'';position:absolute;top:10px;
  width:18px;height:18px;
  background:linear-gradient(145deg,#C8C4BC,#B8B4AC);
  border-radius:50%;
}

/* Floating legal particles */
.sol-legal-particle{position:absolute;pointer-events:none;color:rgba(184,148,58,.3);font-size:14px}

/* Keyframes */
@keyframes sol-float{0%,100%{transform:translateY(0)}50%{transform:translateY(-12px)}}
@keyframes sol-twinkle{0%,100%{opacity:.3}50%{opacity:1}}
@keyframes sol-particle-drift{0%{transform:translateY(0) rotate(0deg);opacity:0}20%{opacity:.6}80%{opacity:.4}100%{transform:translateY(-100px) rotate(360deg);opacity:0}}
@keyframes sol-fade-up{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:none}}
@keyframes sol-glow{0%,100%{box-shadow:0 0 8px rgba(255,200,80,.2)}50%{box-shadow:0 0 20px rgba(255,200,80,.4)}}

/* ── Hero content ─────────────────────────────────────────────────── */
.sol-hero-content{
  position:relative;z-index:2;
  display:grid;grid-template-columns:1fr 1fr;gap:clamp(40px,6vw,80px);align-items:center;
  max-width:1200px;margin:0 auto;
  padding:clamp(48px,7vw,96px) clamp(16px,4vw,48px);
  width:100%;
}
.sol-hero-text .sol-h1{margin-bottom:1.4rem}
.sol-hero-text .sol-h1 em{color:var(--sol-gold);font-style:italic}
.sol-hero-text .sol-lead{color:rgba(248,244,236,.75);margin-bottom:2.2rem}
.sol-hero-actions{display:flex;gap:1rem;flex-wrap:wrap;margin-bottom:2.6rem}
.sol-hero-credentials{display:flex;gap:1.8rem;flex-wrap:wrap}
.sol-cred-item{display:flex;align-items:center;gap:.5rem;font-size:.76rem;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:rgba(248,244,236,.5)}
.sol-cred-dot{width:3px;height:3px;background:var(--sol-gold);border-radius:50%;flex-shrink:0}

/* Hero right — CSS scene card */
.sol-hero-visual{
  position:relative;height:520px;
  display:flex;align-items:flex-end;justify-content:center;
}
.sol-scene-card{
  position:relative;width:100%;height:480px;
  background:linear-gradient(145deg,#0A1220,#0C1828,#162038);
  border-radius:2px;overflow:hidden;
  border:1px solid var(--sol-border-lt);
  box-shadow:0 24px 80px rgba(12,20,40,.5);
}
/* Scene stars */
.sol-sc-star{position:absolute;background:#fff;border-radius:50%}
/* Scene building front */
.sol-sc-building{
  position:absolute;bottom:0;left:10%;right:10%;height:70%;
  background:linear-gradient(180deg,#2A2418,#1E1C14);
  border-top:2px solid rgba(184,148,58,.25);
}
/* Scene windows 3×4 grid */
.sol-sc-win{
  position:absolute;width:20px;height:26px;
  border:1px solid rgba(184,148,58,.2);border-radius:1px 1px 0 0;
}
/* Scene door */
.sol-sc-door{
  position:absolute;bottom:0;left:50%;transform:translateX(-50%);
  width:28px;height:50px;
  background:#06101E;border-radius:14px 14px 0 0;
  border:1px solid rgba(184,148,58,.25);border-bottom:none;
}
/* Floating badge */
.sol-float-badge{
  position:absolute;top:8%;right:3%;
  background:rgba(12,20,40,.9);border:1px solid var(--sol-border);border-radius:2px;
  padding:.7rem 1.1rem;
  box-shadow:0 8px 32px rgba(12,20,40,.4);
  animation:sol-float 5s ease-in-out infinite;
  font-family:var(--sol-font-b);font-size:.75rem;
  display:flex;align-items:center;gap:.7rem;
}
.sol-float-badge-text strong{display:block;font-size:.85rem;color:var(--sol-gold);font-family:var(--sol-font-h)}
.sol-float-badge-text span{color:rgba(248,244,236,.55);font-size:.72rem}

/* ── STATS BAR ─────────────────────────────────────────────────────── */
.sol-stats-bar{
  background:var(--sol-gold);
  padding:clamp(28px,4vw,48px) 0;
}
.sol-stats-grid{
  display:grid;grid-template-columns:repeat(4,1fr);
  gap:2rem;text-align:center;
}
.sol-stat-num{
  font-family:var(--sol-font-h);font-size:clamp(1.8rem,3.5vw,2.8rem);
  font-weight:700;color:var(--sol-navy);line-height:1;margin-bottom:.3rem;
}
.sol-stat-label{font-size:.74rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:rgba(12,20,40,.65)}

/* ── PRACTICE AREAS ────────────────────────────────────────────────── */
.sol-areas-grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:1px;
  background:var(--sol-border-lt);border:1px solid var(--sol-border-lt);
  margin-top:clamp(36px,5vw,56px);
}
.sol-area-card{
  background:var(--sol-ivory);padding:clamp(24px,3vw,36px);
  transition:background .28s,border-left .28s;
  border-left:3px solid transparent;
}
.sol-area-card:hover{background:#fff;border-left-color:var(--sol-gold)}
.sol-area-icon{font-size:1.8rem;margin-bottom:1rem}
.sol-area-title{font-family:var(--sol-font-h);font-size:1.2rem;font-weight:700;color:var(--sol-navy);margin-bottom:.7rem}
.sol-area-desc{font-size:.88rem;line-height:1.75;color:var(--sol-charcoal);opacity:.8}

/* ── TEAM ─────────────────────────────────────────────────────────── */
.sol-team-grid{
  display:grid;grid-template-columns:repeat(4,1fr);gap:1.6rem;
  margin-top:clamp(36px,5vw,56px);
}
.sol-team-card{
  background:#fff;border:1px solid var(--sol-border-lt);
  box-shadow:var(--sol-shadow);
  transition:transform .28s;
}
.sol-team-card:hover{transform:translateY(-4px)}
/* CSS portrait */
.sol-portrait{
  height:180px;position:relative;overflow:hidden;
  display:flex;align-items:flex-end;justify-content:center;
}
.sol-portrait-navy{background:linear-gradient(145deg,#162040,#0C1428)}
.sol-portrait-dark{background:linear-gradient(145deg,#1E1810,#120E08)}
.sol-portrait-stone{background:linear-gradient(145deg,#2A3040,#1A2030)}
.sol-portrait-teal{background:linear-gradient(145deg,#143030,#0A2020)}
/* CSS barrister/solicitor figure */
.sol-lawyer{
  position:absolute;bottom:0;left:50%;transform:translateX(-50%);
  width:80px;height:170px;
}
.sol-l-head{position:absolute;top:0;left:50%;transform:translateX(-50%);width:34px;height:40px;background:linear-gradient(145deg,#D4A870,#B88050);border-radius:50%}
/* Wig on head */
.sol-l-wig{position:absolute;top:-10px;left:50%;transform:translateX(-50%);width:40px;height:18px;background:linear-gradient(145deg,#E8E4DC,#D8D4CC);border-radius:50% 50% 20% 20%}
.sol-l-wig::before{content:'';position:absolute;top:100%;left:2px;width:12px;height:20px;background:linear-gradient(180deg,#D8D4CC,#C8C4BC);border-radius:0 0 6px 6px}
.sol-l-wig::after{content:'';position:absolute;top:100%;right:2px;width:12px;height:20px;background:linear-gradient(180deg,#D8D4CC,#C8C4BC);border-radius:0 0 6px 6px}
/* Gown */
.sol-l-gown{position:absolute;top:40px;left:50%;transform:translateX(-50%);width:60px;height:96px;background:linear-gradient(145deg,#0A0A14,#101020);border-radius:4px 4px 8px 8px;clip-path:polygon(8% 0%,92% 0%,100% 100%,0% 100%)}
/* White collar / bands */
.sol-l-collar{position:absolute;top:44px;left:50%;transform:translateX(-50%);width:18px;height:14px;background:#F8F4EC}
.sol-l-collar::before{content:'';position:absolute;top:100%;left:50%;transform:translateX(-50%);width:10px;height:18px;background:#F8F4EC;clip-path:polygon(0% 0%,100% 0%,50% 100%)}
/* Arms */
.sol-l-arm-l,.sol-l-arm-r{position:absolute;top:48px;width:16px;height:60px;background:linear-gradient(145deg,#080812,#0C0C1C);border-radius:4px}
.sol-l-arm-l{left:2px;transform:rotate(8deg)}
.sol-l-arm-r{right:2px;transform:rotate(-8deg)}
/* Legs */
.sol-l-leg-l,.sol-l-leg-r{position:absolute;bottom:-32px;width:20px;height:36px;background:linear-gradient(180deg,#1A1A2A,#0A0A18);border-radius:0 0 3px 3px}
.sol-l-leg-l{left:8px}
.sol-l-leg-r{right:8px}

.sol-team-info{padding:1.2rem 1.4rem}
.sol-team-name{font-family:var(--sol-font-h);font-size:1rem;font-weight:700;color:var(--sol-navy);margin-bottom:.2rem}
.sol-team-title{font-size:.75rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--sol-gold);margin-bottom:.5rem}
.sol-team-spec{font-size:.8rem;color:var(--sol-charcoal);opacity:.75;margin-bottom:.3rem}
.sol-team-exp{font-size:.76rem;color:var(--sol-charcoal);opacity:.55;font-style:italic;font-family:var(--sol-font-h)}

/* ── ACHIEVEMENTS ─────────────────────────────────────────────────── */
.sol-achievements-list{
  display:flex;flex-direction:column;gap:1px;
  border:1px solid var(--sol-border-lt);
  margin-top:clamp(32px,4vw,48px);
}
.sol-achievement-row{
  display:flex;align-items:center;gap:1.4rem;
  padding:1.1rem 1.8rem;
  background:var(--sol-ivory);
  transition:background .22s,padding-left .22s;
}
.sol-achievement-row:hover{background:#fff;padding-left:2.4rem}
.sol-achievement-icon{width:28px;height:28px;background:var(--sol-gold);display:flex;align-items:center;justify-content:center;font-size:.75rem;color:#fff;flex-shrink:0;border-radius:50%}
.sol-achievement-text{font-family:var(--sol-font-h);font-size:.92rem;color:var(--sol-charcoal)}

/* ── TESTIMONIALS ─────────────────────────────────────────────────── */
.sol-testi-grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:1.6rem;
  margin-top:clamp(32px,5vw,56px);
}
.sol-testi-card{
  background:var(--sol-ivory);border:1px solid var(--sol-border-lt);
  padding:clamp(24px,3vw,36px);
  position:relative;
  transition:box-shadow .28s;
}
.sol-testi-card:hover{box-shadow:var(--sol-shadow)}
.sol-testi-card::before{
  content:'"';position:absolute;top:8px;left:16px;
  font-family:var(--sol-font-h);font-size:4rem;line-height:1;color:rgba(184,148,58,.2);
}
.sol-testi-stars{color:var(--sol-gold);font-size:.9rem;letter-spacing:.12em;margin-bottom:1rem}
.sol-testi-quote{font-family:var(--sol-font-h);font-size:1rem;font-style:italic;color:var(--sol-charcoal);line-height:1.78;margin-bottom:1.2rem}
.sol-testi-author{font-weight:700;font-size:.84rem;color:var(--sol-navy)}
.sol-testi-role{font-size:.77rem;color:var(--sol-gold);font-weight:600;text-transform:uppercase;letter-spacing:.08em}

/* ── FAQ ──────────────────────────────────────────────────────────── */
.sol-faq-list{max-width:760px;margin:clamp(32px,5vw,56px) auto 0;display:flex;flex-direction:column;gap:1px;border:1px solid var(--sol-border-lt)}
.sol-faq-item{background:#fff}
.sol-faq-q{
  width:100%;background:none;border:none;cursor:pointer;
  display:flex;justify-content:space-between;align-items:center;
  padding:1.1rem 1.6rem;text-align:left;
  font-family:var(--sol-font-h);font-size:1rem;font-weight:700;color:var(--sol-navy);
  border-bottom:1px solid transparent;
}
.sol-faq-q::after{content:'+';font-size:1.4rem;font-weight:300;color:var(--sol-gold);flex-shrink:0;margin-left:1rem;transition:transform .28s ease}
.sol-faq-item.open .sol-faq-q::after{transform:rotate(45deg)}
.sol-faq-item.open .sol-faq-q{border-bottom-color:var(--sol-border-lt)}
.sol-faq-a{max-height:0;overflow:hidden;transition:max-height .4s ease}
.sol-faq-a-inner{padding:.3rem 1.6rem 1.3rem;font-size:.88rem;color:var(--sol-charcoal);line-height:1.8}
.sol-faq-item.open .sol-faq-a{max-height:260px}

/* ── CONTACT FORM ─────────────────────────────────────────────────── */
.sol-contact-wrap{
  display:grid;grid-template-columns:1fr 1fr;gap:clamp(48px,6vw,80px);align-items:start;
}
.sol-contact-info .sol-h2-light{margin-bottom:.6rem}
.sol-contact-detail{display:flex;gap:1rem;margin-bottom:1.2rem;align-items:flex-start}
.sol-contact-icon{width:36px;height:36px;border:1px solid var(--sol-border);border-radius:50%;display:flex;align-items:center;justify-content:center;color:var(--sol-gold);flex-shrink:0;font-size:.9rem}
.sol-contact-text strong{display:block;font-size:.82rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--sol-cream);margin-bottom:.2rem}
.sol-contact-text span{font-size:.85rem;color:rgba(248,244,236,.6)}
.sol-sra-badge{
  display:inline-flex;align-items:center;gap:.8rem;
  border:1px solid var(--sol-border);padding:.7rem 1.2rem;
  font-size:.8rem;color:rgba(248,244,236,.6);
  margin-top:2rem;
}
.sol-sra-icon{width:32px;height:32px;background:var(--sol-gold);border-radius:4px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.7rem;color:var(--sol-navy)}
.sol-form-card{
  background:var(--sol-ivory);
  border:1px solid var(--sol-border-lt);
  padding:clamp(28px,4vw,48px);
}
.sol-form-group{display:flex;flex-direction:column;gap:.4rem;margin-bottom:.9rem}
.sol-form-group label{font-size:.75rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--sol-charcoal)}
.sol-form-group input,.sol-form-group select,.sol-form-group textarea{
  border:1px solid var(--sol-border-lt);border-radius:0;
  padding:.75em 1em;font-family:var(--sol-font-b);font-size:.9rem;
  color:var(--sol-charcoal);background:#fff;
  transition:border-color .22s;outline:none;
}
.sol-form-group input:focus,.sol-form-group select:focus,.sol-form-group textarea:focus{border-color:var(--sol-gold)}
.sol-form-group textarea{resize:vertical;min-height:110px}
.sol-form-row{display:grid;grid-template-columns:1fr 1fr;gap:1rem}

/* ── FOOTER ───────────────────────────────────────────────────────── */
.sol-footer{
  background:var(--sol-navy);border-top:1px solid var(--sol-border-lt);
  padding:clamp(48px,7vw,80px) 0 clamp(24px,3vw,40px);
}
.sol-footer-grid{
  display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:clamp(24px,4vw,56px);margin-bottom:3rem;
}
.sol-footer-desc{font-size:.84rem;line-height:1.8;margin-top:1rem;color:rgba(248,244,236,.45);max-width:280px}
.sol-footer-col h4{font-family:var(--sol-font-h);font-size:.92rem;font-weight:700;color:var(--sol-gold);margin-bottom:1rem;letter-spacing:.06em}
.sol-footer-col ul{list-style:none;display:flex;flex-direction:column;gap:.6rem}
.sol-footer-col ul li a{font-size:.82rem;color:rgba(248,244,236,.45);text-decoration:none;transition:color .2s}
.sol-footer-col ul li a:hover{color:var(--sol-gold)}
.sol-footer-bottom{border-top:1px solid var(--sol-border-lt);padding-top:1.5rem;display:flex;justify-content:space-between;font-size:.77rem;color:rgba(248,244,236,.3);flex-wrap:wrap;gap:.8rem}
.sol-footer-bottom a{color:rgba(248,244,236,.3);text-decoration:none}
.sol-footer-bottom a:hover{color:var(--sol-gold)}

/* ── RESPONSIVE ───────────────────────────────────────────────────── */
@media(max-width:1024px){
  .sol-areas-grid{grid-template-columns:repeat(2,1fr)}
  .sol-team-grid{grid-template-columns:repeat(2,1fr)}
  .sol-testi-grid{grid-template-columns:1fr}
  .sol-stats-grid{grid-template-columns:repeat(2,1fr)}
  .sol-footer-grid{grid-template-columns:1fr 1fr}
  .sol-hero-content{grid-template-columns:1fr}
  .sol-hero-visual{display:none}
  .sol-contact-wrap{grid-template-columns:1fr}
}
@media(max-width:640px){
  .sol-areas-grid,.sol-team-grid{grid-template-columns:1fr}
  .sol-stats-grid{grid-template-columns:repeat(2,1fr)}
  .sol-form-row{grid-template-columns:1fr}
  .sol-footer-grid{grid-template-columns:1fr}
  .sol-nav-links,.sol-nav-cta{display:none}
}
</style>
<?php get_header(); ?>
<div class="page-template-page-solicitor">
>

<!-- ══ NAVIGATION ══════════════════════════════════════════════════ -->
<nav class="sol-nav" role="navigation" aria-label="Main navigation">
  <div class="sol-nav-inner">
    <a href="<?php echo esc_url(home_url('/')); ?>" class="sol-logo">
      Ashworth <span>&amp;</span> Everton
    </a>
    <ul class="sol-nav-links">
      <li><a href="#practice-areas">Practice Areas</a></li>
      <li><a href="#team">Our Team</a></li>
      <li><a href="#testimonials">Testimonials</a></li>
      <li><a href="#faq">FAQ</a></li>
      <li><a href="#contact">Contact</a></li>
    </ul>
    <div class="sol-nav-cta">
      <a href="tel:02074008000" class="sol-btn sol-btn-outline-light" style="padding:.55em 1.2em;font-size:.76rem">020 7400 8000</a>
      <a href="#contact" class="sol-btn sol-btn-gold" style="padding:.55em 1.4em;font-size:.76rem">Enquire Now</a>
    </div>
  </div>
</nav>

<!-- ══ HERO ════════════════════════════════════════════════════════ -->
<section class="sol-hero" aria-label="Law firm hero">

  <!-- CSS Inns of Court scene -->
  <div class="sol-hero-scene" aria-hidden="true">
    <!-- Stars -->
    <?php for ($s = 0; $s < 40; $s++):
      $ss = rand(1, 3);
      $sx = rand(2, 98);
      $sy = rand(2, 55);
      $sd = rand(0, 60) / 10;
      $dur = rand(20, 50) / 10;
    ?>
    <div class="sol-star" style="left:<?php echo $sx; ?>%;top:<?php echo $sy; ?>%;width:<?php echo $ss; ?>px;height:<?php echo $ss; ?>px;animation:sol-twinkle <?php echo $dur; ?>s ease-in-out <?php echo $sd; ?>s infinite"></div>
    <?php endfor; ?>

    <!-- Georgian building -->
    <div class="sol-building">
      <!-- Columns -->
      <?php
      $col_positions = [80, 160, 240, 480, 560, 640];
      foreach ($col_positions as $cx):
      ?>
      <div class="sol-column" style="left:<?php echo $cx; ?>px;height:100%"></div>
      <?php endforeach; ?>

      <!-- Windows PHP loop: 3 rows × 8 cols -->
      <?php
      for ($row = 0; $row < 3; $row++):
        for ($col = 0; $col < 8; $col++):
          $wx = 60 + $col * 78;
          $wy = 20 + $row * 60;
          $lit = rand(0, 1);
          $fc  = $lit ? 'sol-win lit' : 'sol-win';
      ?>
      <div class="<?php echo $fc; ?>" style="left:<?php echo $wx; ?>px;top:<?php echo $wy; ?>px;width:28px;height:38px;<?php echo $lit ? 'animation:sol-glow '.(rand(30,80)/10).'s ease-in-out '.(rand(0,30)/10).'s infinite;' : ''; ?>"></div>
      <?php endfor; endfor; ?>

      <!-- Arched door -->
      <div class="sol-door">
        <div class="sol-fanlight"></div>
      </div>
    </div>

    <!-- Courtyard -->
    <div class="sol-courtyard"></div>

    <!-- Scales of Justice -->
    <div class="sol-scales" style="animation:sol-float 6s ease-in-out infinite">
      <div class="sol-scales-pole"></div>
      <div class="sol-scales-beam"></div>
      <div class="sol-scales-chain sol-scales-chain-l"></div>
      <div class="sol-scales-chain sol-scales-chain-r"></div>
      <div class="sol-scales-pan sol-scales-pan-l"></div>
      <div class="sol-scales-pan sol-scales-pan-r"></div>
    </div>

    <!-- Law book -->
    <div class="sol-book" style="animation:sol-float 8s ease-in-out 1s infinite">
      <div class="sol-book-spine"></div>
      <div class="sol-book-body">
        <div class="sol-book-lines">
          <?php for ($bl = 0; $bl < 8; $bl++): ?>
          <div class="sol-book-line"></div>
          <?php endfor; ?>
        </div>
      </div>
    </div>

    <!-- Barrister's Wig -->
    <div class="sol-wig">
      <div class="sol-wig-top"></div>
      <div class="sol-wig-curl sol-wig-curl-l"></div>
      <div class="sol-wig-curl sol-wig-curl-r"></div>
    </div>

    <!-- Floating legal particles -->
    <?php foreach ($legal_particles as $p):
      $chars = ['⚖','§','¶','©','®','⚑'];
      $char = $chars[$p['type'] % count($chars)];
    ?>
    <div class="sol-legal-particle" style="left:<?php echo $p['left']; ?>%;top:<?php echo $p['top']; ?>%;font-size:<?php echo $p['size']; ?>px;animation:sol-particle-drift <?php echo $p['dur']; ?>s ease-in-out <?php echo $p['delay']; ?>s infinite"><?php echo $char; ?></div>
    <?php endforeach; ?>
  </div>

  <!-- Content -->
  <div class="sol-hero-content">
    <div class="sol-hero-text">
      <div class="sol-badge">Lincoln's Inn, London · Est. 1888</div>
      <h1 class="sol-h1">Your interests,<br><em>expertly</em><br>defended</h1>
      <p class="sol-lead">Ashworth &amp; Everton is one of London's most distinguished law firms — providing exceptional legal counsel across commercial, property, family, and employment law from our Lincoln's Inn chambers since 1888.</p>
      <div class="sol-hero-actions">
        <a href="#contact" class="sol-btn sol-btn-gold">Free Initial Consultation</a>
        <a href="#practice-areas" class="sol-btn sol-btn-outline-light">Our Practice Areas</a>
      </div>
      <div class="sol-hero-credentials">
        <div class="sol-cred-item"><div class="sol-cred-dot"></div>Legal 500 Tier 1</div>
        <div class="sol-cred-item"><div class="sol-cred-dot"></div>Chambers UK Band 1</div>
        <div class="sol-cred-item"><div class="sol-cred-dot"></div>SRA Regulated</div>
      </div>
    </div>

    <!-- Scene card -->
    <div class="sol-hero-visual" aria-hidden="true">
      <div class="sol-scene-card">
        <!-- Stars -->
        <?php for ($ss2 = 0; $ss2 < 20; $ss2++):
          $s2 = rand(1,2);
          $sx2 = rand(2,98);
          $sy2 = rand(2,40);
        ?>
        <div class="sol-sc-star" style="left:<?php echo $sx2; ?>%;top:<?php echo $sy2; ?>%;width:<?php echo $s2; ?>px;height:<?php echo $s2; ?>px"></div>
        <?php endfor; ?>
        <!-- Building -->
        <div class="sol-sc-building">
          <!-- Windows 2×5 -->
          <?php
          for ($r2=0; $r2<2; $r2++):
            for ($c2=0; $c2<5; $c2++):
              $wx2 = 24 + $c2*56;
              $wy2 = 16 + $r2*44;
              $lit2 = rand(0,1);
          ?>
          <div class="sol-sc-win<?php echo $lit2?' lit':''; ?>" style="left:<?php echo $wx2; ?>px;top:<?php echo $wy2; ?>px"></div>
          <?php endfor; endfor; ?>
          <div class="sol-sc-door"></div>
        </div>
      </div>
      <div class="sol-float-badge">
        <div style="font-size:1.2rem">⚖</div>
        <div class="sol-float-badge-text">
          <strong>Legal 500 Tier 1</strong>
          <span>Commercial Property 2024</span>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ══ STATS BAR ════════════════════════════════════════════════════ -->
<section class="sol-stats-bar" aria-label="Firm statistics">
  <div class="sol-wrap">
    <div class="sol-stats-grid">
      <?php foreach ($stats as $s): ?>
      <div style="text-align:center">
        <div class="sol-stat-num sol-counter" data-target="<?php echo esc_attr($s['val']); ?>" data-suffix="<?php echo esc_attr($s['suffix']); ?>">0</div>
        <div class="sol-stat-label"><?php echo esc_html($s['label']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══ PRACTICE AREAS ════════════════════════════════════════════════ -->
<section class="sol-section" id="practice-areas" aria-label="Practice areas">
  <div class="sol-wrap">
    <div class="sol-center">
      <div class="sol-badge">Practice Areas</div>
      <h2 class="sol-h2">Comprehensive legal expertise<br>across every discipline</h2>
      <div class="sol-divider"></div>
      <p class="sol-lead" style="margin:0 auto">Our specialist teams provide clear, authoritative advice — combining technical mastery with a pragmatic, commercial approach to achieve the best outcome for every client.</p>
    </div>
    <div class="sol-areas-grid">
      <?php foreach ($practice_areas as $area): ?>
      <div class="sol-area-card">
        <div class="sol-area-icon"><?php echo $area['icon']; ?></div>
        <h3 class="sol-area-title"><?php echo esc_html($area['title']); ?></h3>
        <p class="sol-area-desc"><?php echo esc_html($area['desc']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══ TEAM ═════════════════════════════════════════════════════════ -->
<section class="sol-section sol-section-cream" id="team" aria-label="Legal team">
  <div class="sol-wrap">
    <div class="sol-center">
      <div class="sol-badge">Our Solicitors</div>
      <h2 class="sol-h2">Exceptional lawyers,<br>dedicated to your case</h2>
      <div class="sol-divider"></div>
    </div>
    <div class="sol-team-grid">
      <?php
      $portrait_cls = ['sol-portrait-navy','sol-portrait-dark','sol-portrait-stone','sol-portrait-teal'];
      foreach ($team as $ti => $m): ?>
      <div class="sol-team-card">
        <div class="sol-portrait <?php echo $portrait_cls[$ti]; ?>" aria-hidden="true">
          <div class="sol-lawyer">
            <div class="sol-l-wig"></div>
            <div class="sol-l-head"></div>
            <div class="sol-l-gown">
              <div class="sol-l-collar"></div>
            </div>
            <div class="sol-l-arm-l"></div>
            <div class="sol-l-arm-r"></div>
            <div class="sol-l-leg-l"></div>
            <div class="sol-l-leg-r"></div>
          </div>
        </div>
        <div class="sol-team-info">
          <div class="sol-team-name"><?php echo esc_html($m['name']); ?></div>
          <div class="sol-team-title"><?php echo esc_html($m['title']); ?></div>
          <div class="sol-team-spec"><?php echo esc_html($m['spec']); ?></div>
          <div class="sol-team-exp"><?php echo esc_html($m['ql']); ?> · <?php echo esc_html($m['exp']); ?> experience</div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══ ACHIEVEMENTS ══════════════════════════════════════════════════ -->
<section class="sol-section sol-section-dark" aria-label="Awards and recognition">
  <div class="sol-wrap">
    <div class="sol-center">
      <div class="sol-badge" style="color:var(--sol-gold-lt);border-bottom-color:rgba(184,148,58,.3)">Recognition</div>
      <h2 class="sol-h2 sol-h2-light">Recognised for excellence</h2>
      <div class="sol-divider" style="background:var(--sol-gold)"></div>
    </div>
    <div class="sol-achievements-list" style="background:var(--sol-navy-md);border-color:rgba(184,148,58,.12)">
      <?php foreach ($achievements as $ach): ?>
      <div class="sol-achievement-row" style="background:var(--sol-navy-md)">
        <div class="sol-achievement-icon">✦</div>
        <div class="sol-achievement-text" style="color:rgba(248,244,236,.75)"><?php echo esc_html($ach); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══ TESTIMONIALS ══════════════════════════════════════════════════ -->
<section class="sol-section" id="testimonials" aria-label="Client testimonials">
  <div class="sol-wrap">
    <div class="sol-center">
      <div class="sol-badge">Client Testimonials</div>
      <h2 class="sol-h2">What our clients say</h2>
      <div class="sol-divider"></div>
    </div>
    <div class="sol-testi-grid">
      <?php foreach ($testimonials as $t): ?>
      <div class="sol-testi-card">
        <div class="sol-testi-stars">★★★★★</div>
        <p class="sol-testi-quote">"<?php echo esc_html($t['quote']); ?>"</p>
        <div class="sol-testi-author"><?php echo esc_html($t['name']); ?></div>
        <div class="sol-testi-role"><?php echo esc_html($t['role']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══ FAQ ══════════════════════════════════════════════════════════ -->
<section class="sol-section sol-section-cream" id="faq" aria-label="Frequently asked questions">
  <div class="sol-wrap">
    <div class="sol-center">
      <div class="sol-badge">FAQ</div>
      <h2 class="sol-h2">Frequently asked questions</h2>
      <div class="sol-divider"></div>
    </div>
    <div class="sol-faq-list" role="list">
      <?php foreach ($faqs as $fi => $faq): ?>
      <div class="sol-faq-item" role="listitem">
        <button class="sol-faq-q" aria-expanded="false" aria-controls="sol-faq-a-<?php echo $fi; ?>">
          <?php echo esc_html($faq['q']); ?>
        </button>
        <div class="sol-faq-a" id="sol-faq-a-<?php echo $fi; ?>" role="region">
          <div class="sol-faq-a-inner"><?php echo esc_html($faq['a']); ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══ CONTACT ══════════════════════════════════════════════════════ -->
<section class="sol-section sol-section-dark" id="contact" aria-label="Contact the firm">
  <div class="sol-wrap">
    <div class="sol-contact-wrap">
      <!-- Info -->
      <div class="sol-contact-info">
        <div class="sol-badge" style="color:var(--sol-gold-lt);border-bottom-color:rgba(184,148,58,.3)">Contact Us</div>
        <h2 class="sol-h2 sol-h2-light">Speak with a specialist</h2>
        <div class="sol-divider" style="background:var(--sol-gold)"></div>
        <p class="sol-lead" style="color:rgba(248,244,236,.7)">Your initial 30-minute consultation is complimentary. We listen carefully, assess your situation, and provide clear, direct advice on your options — without jargon or unnecessary delay.</p>
        <br>
        <div>
          <div class="sol-contact-detail">
            <div class="sol-contact-icon">📍</div>
            <div class="sol-contact-text">
              <strong>Ashworth &amp; Everton LLP</strong>
              <span>4 Chancery Lane, Lincoln's Inn, London WC2A 1LG</span>
            </div>
          </div>
          <div class="sol-contact-detail">
            <div class="sol-contact-icon">🕐</div>
            <div class="sol-contact-text">
              <strong>Office Hours</strong>
              <span>Monday–Friday 8:00–18:30 · Saturday by appointment</span>
            </div>
          </div>
          <div class="sol-contact-detail">
            <div class="sol-contact-icon">📞</div>
            <div class="sol-contact-text">
              <strong>020 7400 8000</strong>
              <span>enquiries@ashwortheverton.co.uk</span>
            </div>
          </div>
        </div>
        <div class="sol-sra-badge">
          <div class="sol-sra-icon">SRA</div>
          <span>Authorised &amp; Regulated by the Solicitors Regulation Authority · SRA No. 12345678</span>
        </div>
      </div>

      <!-- Form -->
      <div class="sol-form-card">
        <h3 style="font-family:var(--sol-font-h);font-size:1.4rem;font-weight:700;color:var(--sol-navy);margin-bottom:1.4rem">Request a Consultation</h3>
        <?php if (isset($_GET['sol_sent']) && $_GET['sol_sent'] === '1'): ?>
        <div style="background:var(--sol-cream);border-left:3px solid var(--sol-gold);padding:1rem 1.2rem;margin-bottom:1.2rem;font-size:.88rem;color:var(--sol-navy)">
          Thank you. A member of our team will be in touch within two hours.
        </div>
        <?php endif; ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
          <?php wp_nonce_field('tf_sol_enquiry', 'tf_sol_nonce'); ?>
          <input type="hidden" name="action" value="tf_sol_enquiry">
          <div class="sol-form-row">
            <div class="sol-form-group">
              <label for="sol-fname">First Name *</label>
              <input type="text" id="sol-fname" name="first_name" required placeholder="First name">
            </div>
            <div class="sol-form-group">
              <label for="sol-lname">Last Name *</label>
              <input type="text" id="sol-lname" name="last_name" required placeholder="Last name">
            </div>
          </div>
          <div class="sol-form-group">
            <label for="sol-email">Email Address *</label>
            <input type="email" id="sol-email" name="email" required placeholder="your@email.com">
          </div>
          <div class="sol-form-group">
            <label for="sol-phone">Telephone</label>
            <input type="tel" id="sol-phone" name="phone" placeholder="020 7000 0000">
          </div>
          <div class="sol-form-group">
            <label for="sol-area">Practice Area *</label>
            <select id="sol-area" name="practice_area" required>
              <option value="">Select an area…</option>
              <option>Commercial Law</option>
              <option>Property &amp; Conveyancing</option>
              <option>Family Law</option>
              <option>Wills &amp; Probate</option>
              <option>Employment Law</option>
              <option>Dispute Resolution</option>
              <option>Other / Not sure</option>
            </select>
          </div>
          <div class="sol-form-group">
            <label for="sol-type">Client Type</label>
            <select id="sol-type" name="client_type">
              <option value="">Please select…</option>
              <option>Individual / Personal</option>
              <option>Business / Company</option>
              <option>Organisation / Charity</option>
            </select>
          </div>
          <div class="sol-form-group">
            <label for="sol-msg">Brief Description of Your Matter *</label>
            <textarea id="sol-msg" name="message" required placeholder="Please provide a brief summary of your legal matter. All information is treated as strictly confidential."></textarea>
          </div>
          <div style="display:flex;align-items:flex-start;gap:.6rem;margin-bottom:1.2rem">
            <input type="checkbox" id="sol-conf" name="confidential" value="1" required style="margin-top:.2rem;accent-color:var(--sol-gold)">
            <label for="sol-conf" style="font-size:.8rem;color:var(--sol-charcoal);line-height:1.5">I understand that submitting this enquiry does not create a solicitor-client relationship and that my information will be held in accordance with the firm's Privacy Policy. *</label>
          </div>
          <button type="submit" class="sol-btn sol-btn-gold" style="width:100%;text-align:center">
            Submit Enquiry
          </button>
          <p style="font-size:.74rem;color:var(--sol-charcoal);opacity:.55;text-align:center;margin-top:.8rem;line-height:1.6">All communications are strictly confidential. We aim to respond within two hours during business hours.</p>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- ══ FOOTER ════════════════════════════════════════════════════════ -->
<footer class="sol-footer" role="contentinfo">
  <div class="sol-wrap">
    <div class="sol-footer-grid">
      <div>
        <a href="<?php echo esc_url(home_url('/')); ?>" class="sol-logo">Ashworth <span style="color:var(--sol-gold)">&amp;</span> Everton</a>
        <p class="sol-footer-desc">Solicitors and barristers of the highest distinction, serving clients across the UK and internationally from Lincoln's Inn since 1888. Legal 500 and Chambers UK ranked.</p>
      </div>
      <div class="sol-footer-col">
        <h4>Practice Areas</h4>
        <ul>
          <li><a href="#practice-areas">Commercial Law</a></li>
          <li><a href="#practice-areas">Property &amp; Conveyancing</a></li>
          <li><a href="#practice-areas">Family Law</a></li>
          <li><a href="#practice-areas">Wills &amp; Probate</a></li>
          <li><a href="#practice-areas">Employment Law</a></li>
        </ul>
      </div>
      <div class="sol-footer-col">
        <h4>The Firm</h4>
        <ul>
          <li><a href="#team">Our Team</a></li>
          <li><a href="#testimonials">Client Reviews</a></li>
          <li><a href="#">Pro Bono Work</a></li>
          <li><a href="#">Careers</a></li>
          <li><a href="#">Publications</a></li>
        </ul>
      </div>
      <div class="sol-footer-col">
        <h4>Contact</h4>
        <ul>
          <li><a href="tel:02074008000">020 7400 8000</a></li>
          <li><a href="mailto:enquiries@ashwortheverton.co.uk">Send an Enquiry</a></li>
          <li><a href="#">4 Chancery Lane, WC2A 1LG</a></li>
          <li><a href="#contact">Free Consultation</a></li>
        </ul>
      </div>
    </div>
    <div class="sol-footer-bottom">
      <span>&copy; <?php echo date('Y'); ?> Ashworth &amp; Everton LLP. Registered in England &amp; Wales No. OC123456. SRA No. 12345678. VAT No. 987 6543 21. All rights reserved.</span>
      <div style="display:flex;gap:1.2rem">
        <a href="#">Privacy Policy</a>
        <a href="#">Complaints</a>
        <a href="#">Legal Notices</a>
      </div>
    </div>
  </div>
</footer>


<script>
(function(){
  'use strict';

  /* ── FAQ Accordion ─────────────────────────────────────────────── */
  document.querySelectorAll('.sol-faq-q').forEach(function(btn){
    btn.addEventListener('click',function(){
      var item = this.closest('.sol-faq-item');
      var isOpen = item.classList.contains('open');
      document.querySelectorAll('.sol-faq-item.open').forEach(function(o){
        o.classList.remove('open');
        o.querySelector('.sol-faq-q').setAttribute('aria-expanded','false');
      });
      if(!isOpen){
        item.classList.add('open');
        this.setAttribute('aria-expanded','true');
      }
    });
  });

  /* ── Animated Counters ─────────────────────────────────────────── */
  var counters = document.querySelectorAll('.sol-counter');
  var started  = false;
  function easeOut(t){return 1-Math.pow(1-t,3)}
  function runCounters(){
    if(started) return;
    started = true;
    counters.forEach(function(el){
      var target  = parseFloat(el.dataset.target);
      var suffix  = el.dataset.suffix || '';
      var isFloat = el.dataset.target.indexOf('.') !== -1;
      if(isNaN(target)) return;
      var duration = 2000;
      var start    = performance.now();
      function tick(now){
        var elapsed  = now - start;
        var progress = Math.min(elapsed / duration, 1);
        var val      = target * easeOut(progress);
        el.textContent = (isFloat ? val.toFixed(1) : Math.floor(val).toLocaleString()) + suffix;
        if(progress < 1) requestAnimationFrame(tick);
        else el.textContent = (isFloat ? target.toFixed(1) : target.toLocaleString()) + suffix;
      }
      requestAnimationFrame(tick);
    });
  }

  if('IntersectionObserver' in window){
    var obs = new IntersectionObserver(function(entries){
      entries.forEach(function(e){if(e.isIntersecting) runCounters();});
    },{threshold:.3});
    var sb = document.querySelector('.sol-stats-bar');
    if(sb) obs.observe(sb);
  } else {
    runCounters();
  }

  /* ── Smooth scroll ─────────────────────────────────────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(function(a){
    a.addEventListener('click',function(e){
      var t = document.querySelector(this.getAttribute('href'));
      if(t){e.preventDefault();window.scrollTo({top:t.getBoundingClientRect().top+window.pageYOffset-80,behavior:'smooth'});}
    });
  });

  /* ── Nav shadow on scroll ──────────────────────────────────────── */
  var nav = document.querySelector('.sol-nav');
  window.addEventListener('scroll',function(){
    if(nav) nav.style.boxShadow = window.scrollY>10 ? '0 4px 24px rgba(12,20,40,.5)' : '';
  },{passive:true});

})();
</script>
</body>
</html>
</div><!-- .page-template-page-solicitor -->
<?php get_footer(); ?>
