<?php
/**
 * Template Name: Spa — Luxury Spa & Wellness Centre
 *
 * Premium luxury spa page for ThemeFlex.
 * Concept : Candlelit thermal pool hall at dusk — arched stone ceiling,
 *           mosaic-tiled pool, steam wisps, orchids, flickering pillar candles,
 *           rose petals drifting across the water surface.
 * Palette : Deep teal / warm travertine / burnished gold.
 * Fonts   : Gilda Display (headings) + Jost (body).
 * Namespace: --sp-*
 *
 * @package ThemeFlex
 */

if ( ! defined( 'ABSPATH' ) ) exit;

srand( crc32( get_the_permalink() ) );

/* ── floating petals ────────────────────────── */
$sp_petals = [];
for($i=0;$i<28;$i++){
    $sp_petals[]=[
        'left'  => rand(2,98),
        'top'   => rand(5,90),
        'size'  => rand(6,16),
        'delay' => rand(0,8000),
        'dur'   => rand(6000,14000),
        'hue'   => rand(0,2), // 0=rose 1=blush 2=white
        'rot'   => rand(0,360),
    ];
}

/* ── candles ────────────────────────────────── */
$sp_candles = [
    ['left'=>'18%','h'=>90,'base'=>2],
    ['left'=>'24%','h'=>68,'base'=>1],
    ['left'=>'30%','h'=>80,'base'=>3],
    ['left'=>'68%','h'=>75,'base'=>1],
    ['left'=>'74%','h'=>95,'base'=>2],
    ['left'=>'79%','h'=>62,'base'=>1],
];

/* ── steam wisps ─────────────────────────────── */
$sp_steams = [];
for($i=0;$i<14;$i++){
    $sp_steams[]=[
        'left'  => rand(8,92),
        'delay' => rand(0,5000),
        'dur'   => rand(3000,7000),
        'size'  => rand(16,36),
    ];
}

/* ── orchid pots ─────────────────────────────── */
$sp_orchids = [
    ['left'=>'12%','stems'=>3],
    ['left'=>'86%','stems'=>2],
];

/* ── stats ───────────────────────────────────── */
$sp_stats=[
    ['val'=>24,  'suffix'=>'',   'label'=>'Treatment Rooms'],
    ['val'=>18,  'suffix'=>'yrs','label'=>'Years of Excellence'],
    ['val'=>4.9, 'suffix'=>'★',  'label'=>'Trustpilot Rating'],
    ['val'=>98,  'suffix'=>'%',  'label'=>'Would Recommend'],
];

/* ── treatments ──────────────────────────────── */
$sp_treatments=[
    ['icon'=>'💆','name'=>'Signature Massage',      'dur'=>'90 min','price'=>'£145','desc'=>'Our most requested treatment — a bespoke full-body massage combining Swedish, deep-tissue and aromatherapy techniques tailored to your needs.'],
    ['icon'=>'✨','name'=>'Gold Radiance Facial',   'dur'=>'75 min','price'=>'£165','desc'=>'A luxurious treatment using 24-carat gold leaf, hyaluronic boosters and LED therapy to achieve visibly luminous, lifted skin.'],
    ['icon'=>'🌿','name'=>'Himalayan Salt Journey', 'dur'=>'60 min','price'=>'£125','desc'=>'Warm Himalayan salt stones melt muscular tension while deeply mineralising the skin — restorative and profoundly calming.'],
    ['icon'=>'💧','name'=>'Thermal Pool Ritual',    'dur'=>'120 min','price'=>'£95','desc'=>'A self-guided thermal journey through our Roman pool, steam room, infrared sauna, cold plunge and relaxation lounge.'],
    ['icon'=>'🌸','name'=>'Rose & Resveratrol Body','dur'=>'75 min','price'=>'£135','desc'=>'An antioxidant-rich body wrap with Bulgarian rose oil, grape-seed exfoliation and a nourishing cocoon to soften and brighten.'],
    ['icon'=>'🧘','name'=>'Mindful Restore',        'dur'=>'90 min','price'=>'£115','desc'=>'Yin yoga, guided breathwork and a warm oil scalp treatment combined into a sequence designed to dissolve modern stress.'],
];

/* ── day packages ────────────────────────────── */
$sp_packages=[
    [
        'name'     => 'Serene',
        'includes' => 'Thermal Journey + 1 Treatment + Lunch',
        'price'    => '£195',
        'desc'     => 'The perfect introduction to Aqua Lumina. Arrive at your own pace and surrender the day.',
        'highlight'=> false,
    ],
    [
        'name'     => 'Lumina',
        'includes' => 'Thermal Journey + 2 Treatments + Afternoon Tea',
        'price'    => '£295',
        'desc'     => 'Our most popular package — half a day of uninterrupted wellbeing with two signature treatments and a beautifully curated afternoon tea.',
        'highlight'=> true,
    ],
    [
        'name'     => 'Celestial',
        'includes' => 'Full Day + 3 Treatments + 3-Course Dinner',
        'price'    => '£425',
        'desc'     => 'The ultimate escape. Arrive at dawn, depart after dinner — every detail handled, every hour considered.',
        'highlight'=> false,
    ],
];

/* ── team ────────────────────────────────────── */
$sp_team=[
    ['name'=>'Isabelle Moreau',  'role'=>'Head Therapist',        'spec'=>'Advanced Massage · Lymphatic Drainage', 'colour'=>'#3D8C8C'],
    ['name'=>'Yuki Tanaka',      'role'=>'Senior Facialist',      'spec'=>'Medical Aesthetics · LED Therapy',      'colour'=>'#8C6A3D'],
    ['name'=>'Amara Osei',       'role'=>'Wellness Director',     'spec'=>'Holistic Therapies · Sound Healing',    'colour'=>'#6A3D8C'],
    ['name'=>'Claudia Fontaine', 'role'=>'Thermal Suite Lead',    'spec'=>'Hydrotherapy · Infrared & Sauna',       'colour'=>'#3D5C8C'],
];

/* ── testimonials ────────────────────────────── */
$sp_testimonials=[
    ['name'=>'Sophie Alderton',   'role'=>'London',   'text'=>'The Gold Radiance Facial was transformative — I looked ten years younger. The therapists\' skill and the atmosphere make this completely unlike any spa I\'ve visited. Worth every penny.'],
    ['name'=>'David & Emma Ross', 'role'=>'Couples Retreat','text'=>'We treated ourselves to the Celestial package for our anniversary. From the moment we arrived to the final goodbye, not a single detail was out of place. Simply extraordinary.'],
    ['name'=>'Charlotte Vane',    'role'=>'Regular Member','text'=>'I\'ve been coming every month for two years. Isabelle understands exactly what my body needs every time. The thermal pool alone is worth the membership.'],
];

/* ── process ──────────────────────────────────── */
$sp_process=[
    ['n'=>'01','t'=>'Arrival & Welcome','d'=>'A chilled welcome drink and consultation with your therapist to personalise every element of your visit.'],
    ['n'=>'02','t'=>'Thermal Journey','d'=>'Begin in our Roman pool, progress through steam, sauna, and cold plunge — preparing body and mind.'],
    ['n'=>'03','t'=>'Your Treatments','d'=>'Expert therapists deliver your chosen treatments in our tranquil candlelit rooms.'],
    ['n'=>'04','t'=>'Rest & Restore','d'=>'The relaxation lounge, botanical tea selection and light refreshments — linger as long as you wish.'],
];

/* ── FAQs ─────────────────────────────────────── */
$sp_faqs=[
    ['q'=>'What should I bring?',
     'a'=>'We provide fluffy robes, slippers, towels and all products. Simply arrive. We recommend leaving valuables at home, though secure lockers are available.'],
    ['q'=>'Is the spa suitable for pregnant guests?',
     'a'=>'Yes, with care. We offer a dedicated Mama-to-Be treatment range from 12 weeks onwards. Please inform us when booking so we can adapt your experience safely.'],
    ['q'=>'How far in advance should I book?',
     'a'=>'Weekends typically book 3–4 weeks ahead, particularly for the Lumina and Celestial packages. Weekday appointments are usually available within 7–10 days.'],
    ['q'=>'Do you offer gift vouchers?',
     'a'=>'Yes — digital and physical vouchers are available for any value or specific treatment, beautifully packaged in our signature gift box on request.'],
    ['q'=>'What is your cancellation policy?',
     'a'=>'We ask for 48 hours\' notice for individual treatments and 72 hours for full-day packages. Late cancellations may incur a 50% charge.'],
];

get_header();
?>

<style>
/* ══════════════════════════════════════════
   SPA — CSS DESIGN SYSTEM
   Namespace: --sp-*
══════════════════════════════════════════ */
@import url('https://fonts.googleapis.com/css2?family=Gilda+Display&family=Jost:wght@300;400;500&display=swap');

:root{
    --sp-teal    : #1D5C5C;
    --sp-teal-l  : #2E8080;
    --sp-teal-d  : #0F3A3A;
    --sp-stone   : #F5F0E8;
    --sp-sand    : #EDE6D8;
    --sp-travert : #D4C9B0;
    --sp-gold    : #C0943A;
    --sp-gold-l  : #D4A848;
    --sp-mid     : #8A8070;
    --sp-dark    : #1A1510;
    --sp-white   : #FFFFFF;
    --sp-rose    : #C87878;
    --sp-blush   : #E8A8A0;
    --sp-r       : 0px;
    --sp-font-h  : 'Gilda Display', serif;
    --sp-font-b  : 'Jost', sans-serif;
    --sp-shadow  : 0 24px 80px rgba(0,0,0,.18);
}

.sp-wrap *{ box-sizing:border-box; margin:0; padding:0; }
.sp-wrap{ font-family:var(--sp-font-b); color:var(--sp-dark); background:var(--sp-stone); line-height:1.7; }
.sp-container{ max-width:1200px; margin:0 auto; padding:0 40px; }

/* ── Typography ─────────────────────────── */
.sp-h1{ font-family:var(--sp-font-h); font-size:clamp(3rem,7vw,6rem); font-weight:400; line-height:1.1; color:var(--sp-white); letter-spacing:.02em; }
.sp-h2{ font-family:var(--sp-font-h); font-size:clamp(1.8rem,4vw,3rem); font-weight:400; color:var(--sp-teal-d); }
.sp-h3{ font-family:var(--sp-font-h); font-size:1.4rem; color:var(--sp-teal-d); }
.sp-lead{ font-size:1rem; color:var(--sp-mid); font-weight:300; max-width:580px; line-height:1.85; }
.sp-overline{ font-family:var(--sp-font-b); font-size:.68rem; font-weight:500; letter-spacing:.24em; color:var(--sp-gold); text-transform:uppercase; display:block; margin-bottom:1rem; }
.sp-accent{ color:var(--sp-gold); }
.sp-teal-text{ color:var(--sp-teal); }

/* ── Buttons ─────────────────────────────── */
.sp-btn{
    display:inline-flex; align-items:center; gap:.5rem;
    font-family:var(--sp-font-b); font-size:.78rem; font-weight:500; letter-spacing:.18em;
    padding:.9rem 2.2rem; background:var(--sp-teal); color:var(--sp-white);
    border:none; cursor:pointer; text-decoration:none; text-transform:uppercase;
    transition:background .3s, transform .2s; border-radius:100px;
}
.sp-btn:hover{ background:var(--sp-teal-l); transform:translateY(-2px); }
.sp-btn-gold{
    background:var(--sp-gold); color:var(--sp-white);
}
.sp-btn-gold:hover{ background:var(--sp-gold-l); }
.sp-btn-outline{
    background:transparent; border:1.5px solid rgba(255,255,255,.6); color:var(--sp-white);
    border-radius:100px;
}
.sp-btn-outline:hover{ background:rgba(255,255,255,.15); }

/* ── Section ─────────────────────────────── */
.sp-section{ padding:100px 0; }
.sp-section-alt{ background:var(--sp-sand); }
.sp-section-teal{ background:var(--sp-teal-d); }
.sp-section-header{ text-align:center; margin-bottom:64px; }
.sp-divider{
    display:inline-block; width:40px; height:1.5px;
    background:var(--sp-gold); margin:20px 0;
}

/* ══════════════════════════════════════════
   HERO — Thermal pool hall at dusk
══════════════════════════════════════════ */
.sp-hero{
    position:relative; min-height:100vh;
    background:linear-gradient(180deg,#0A1F1F 0%,#0D2A2A 40%,#122E2E 100%);
    overflow:hidden; display:flex; align-items:center;
}

/* arched stone ceiling */
.sp-ceiling{
    position:absolute; top:0; left:0; right:0; height:28%;
    background:linear-gradient(180deg,#0D1C1C 0%,#162626 100%);
}
/* ceiling ribs (arches) */
.sp-ceiling::before{
    content:''; position:absolute; bottom:0; left:-5%; right:-5%;
    height:60px;
    background:
        radial-gradient(ellipse 15% 60px at 12% 100%, #1A3030 100%, transparent 100%),
        radial-gradient(ellipse 15% 60px at 37% 100%, #1A3030 100%, transparent 100%),
        radial-gradient(ellipse 15% 60px at 62% 100%, #1A3030 100%, transparent 100%),
        radial-gradient(ellipse 15% 60px at 87% 100%, #1A3030 100%, transparent 100%);
}
/* stone texture wash */
.sp-ceiling::after{
    content:''; position:absolute; inset:0;
    background:
        repeating-linear-gradient(90deg,transparent 0,transparent 59px,rgba(255,255,255,.03) 59px,rgba(255,255,255,.03) 60px),
        repeating-linear-gradient(0deg,transparent 0,transparent 29px,rgba(255,255,255,.02) 29px,rgba(255,255,255,.02) 30px);
}

/* pool */
.sp-pool{
    position:absolute; bottom:0; left:10%; right:10%; height:30%;
    background:linear-gradient(180deg, #1D6060 0%,#164848 60%, #0E3030 100%);
    border-top:3px solid rgba(100,200,200,.3);
}
/* pool mosaic tiles */
.sp-pool::before{
    content:''; position:absolute; inset:0;
    background:
        repeating-linear-gradient(90deg, rgba(255,255,255,.06) 0,rgba(255,255,255,.06) 1px,transparent 1px,transparent 18px),
        repeating-linear-gradient(0deg, rgba(255,255,255,.06) 0,rgba(255,255,255,.06) 1px,transparent 1px,transparent 18px);
}
/* pool water shimmer */
.sp-pool::after{
    content:''; position:absolute; inset:0;
    background:
        radial-gradient(ellipse 60% 30% at 50% 20%, rgba(100,220,220,.15) 0%, transparent 70%),
        radial-gradient(ellipse 30% 20% at 30% 60%, rgba(100,220,220,.1) 0%, transparent 70%);
    animation:sp-shimmer 4s ease-in-out infinite;
}

/* pool edge / surround */
.sp-pool-edge{
    position:absolute; bottom:30%; left:8%; right:8%;
    height:12px;
    background:linear-gradient(180deg,#D4C9A8,#B8AC88);
    border-radius:4px 4px 0 0;
}
/* pool surround floor */
.sp-pool-floor-l,.sp-pool-floor-r{
    position:absolute; bottom:0; height:30%;
    background:
        repeating-linear-gradient(90deg,rgba(255,255,255,.04) 0,rgba(255,255,255,.04) 1px,transparent 1px,transparent 24px),
        #1C1810;
}
.sp-pool-floor-l{ left:0; width:10%; }
.sp-pool-floor-r{ right:0; width:10%; }

/* back wall with stone columns */
.sp-wall{
    position:absolute; top:28%; bottom:30%; left:0; right:0;
    background:
        repeating-linear-gradient(90deg,transparent 0,transparent 59px,rgba(255,255,255,.025) 59px,rgba(255,255,255,.025) 60px),
        linear-gradient(180deg,#1A2828,#142020);
}

/* columns */
.sp-col{
    position:absolute; top:0; width:24px;
    bottom:-12px;
    background:linear-gradient(90deg,#243030,#3A4848,#243030);
    border-radius:2px 2px 0 0;
}
.sp-col::before{
    content:''; position:absolute; top:-16px; left:-8px; right:-8px; height:16px;
    background:linear-gradient(180deg,#3A4848,#243030);
    border-radius:3px 3px 0 0;
}
.sp-col::after{
    content:''; position:absolute; bottom:0; left:-6px; right:-6px; height:12px;
    background:#2E3C3C;
    border-radius:0 0 2px 2px;
}

/* ambient glow on water */
.sp-pool-glow{
    position:absolute; bottom:24%; left:10%; right:10%; height:80px;
    background:radial-gradient(ellipse at 50% 100%, rgba(29,96,96,.5) 0%, transparent 70%);
    pointer-events:none;
}

/* steam wisps */
.sp-steam{
    position:absolute; bottom:28%;
    width:var(--sw); opacity:0;
    border-radius:50%;
    background:radial-gradient(ellipse at 50% 100%, rgba(200,230,230,.25), transparent 70%);
    animation:sp-steam-rise var(--sd) ease-in var(--sde) infinite;
    pointer-events:none;
}

/* floating petals */
.sp-petal{
    position:absolute; border-radius:50% 0 50% 0;
    width:var(--pw); height:calc(var(--pw) * .6);
    animation:sp-petal-drift var(--pd) ease-in-out var(--pde) infinite alternate;
    pointer-events:none; transform:rotate(var(--pr));
}
.sp-petal.rose  { background:rgba(200,120,120,.6); }
.sp-petal.blush { background:rgba(232,168,160,.5); }
.sp-petal.white { background:rgba(255,255,255,.35); }

/* candle */
.sp-candle{
    position:absolute; bottom:30%;
}
.sp-candle-body{
    width:10px; height:var(--ch);
    background:linear-gradient(90deg,#F0E8D8,#E8DCC8,#F0E8D8);
    border-radius:2px 2px 0 0;
    position:relative;
}
.sp-candle-body::before{
    content:''; position:absolute; top:0; left:50%; transform:translateX(-50%);
    width:1px; height:6px; background:#333;
}
.sp-candle-flame{
    position:absolute; bottom:100%; left:50%; transform:translateX(-50%);
    width:8px; height:14px;
    background:radial-gradient(ellipse at 50% 80%,#FFF8C0,#F5A820 50%,rgba(255,100,0,.4) 80%,transparent);
    border-radius:50% 50% 30% 30%;
    animation:sp-flame-flicker 1.2s ease-in-out infinite;
}
.sp-candle-base{
    width:calc(10px + var(--cb) * 4px); height:8px;
    background:#D4C9A8;
    margin-left:calc((var(--cb) * -2px));
    border-radius:0 0 2px 2px;
}
/* candle glow */
.sp-candle-glow{
    position:absolute; bottom:0; left:50%; transform:translateX(-50%);
    width:60px; height:40px;
    background:radial-gradient(ellipse at 50% 100%, rgba(245,168,32,.2), transparent 70%);
    pointer-events:none;
}

/* orchid pot */
.sp-orchid{
    position:absolute; bottom:30%;
}
.sp-orchid-pot{
    width:28px; height:24px;
    background:linear-gradient(180deg,#8C6030,#6A4820);
    clip-path:polygon(10% 0,90% 0,100% 100%,0% 100%);
}
.sp-orchid-soil{
    width:32px; height:6px; background:#4A3220;
    margin-left:-2px; border-radius:0 0 2px 2px;
}
.sp-orchid-stem{
    position:absolute; bottom:100%; left:50%; transform:translateX(-50%);
    width:2px; height:var(--osh); background:#5A8050;
    transform-origin:bottom center;
}
.sp-orchid-bloom{
    position:absolute; top:-10px; left:50%; transform:translateX(-50%);
    width:16px; height:16px;
    background:radial-gradient(circle at 40% 40%,#F0C0D0,#D880A0);
    border-radius:50% 30% 50% 30%;
}
.sp-orchid-bloom::before{
    content:''; position:absolute; top:50%; left:50%; transform:translate(-50%,-50%);
    width:5px; height:5px; border-radius:50%; background:#F8E8A0;
}

/* hero inner layout */
.sp-hero-inner{
    position:relative; z-index:10;
    display:grid; grid-template-columns:1fr 1fr; gap:80px;
    align-items:center; max-width:1200px; margin:0 auto;
    padding:120px 40px 80px; width:100%;
}
.sp-hero-tag{
    display:inline-flex; align-items:center; gap:12px;
    background:rgba(192,148,58,.2); border:1px solid rgba(192,148,58,.4);
    padding:6px 16px; border-radius:100px; margin-bottom:28px;
}
.sp-hero-tag-dot{ width:6px; height:6px; border-radius:50%; background:var(--sp-gold); }
.sp-hero-tag-text{ font-size:.72rem; letter-spacing:.18em; color:var(--sp-gold); text-transform:uppercase; }
.sp-hero-actions{ display:flex; gap:16px; flex-wrap:wrap; margin-top:36px; }
.sp-hero-badges{ display:flex; gap:12px; flex-wrap:wrap; margin-top:24px; }
.sp-badge{
    font-size:.72rem; letter-spacing:.1em; color:rgba(255,255,255,.6);
    text-transform:uppercase; display:flex; align-items:center; gap:6px;
}
.sp-badge::before{ content:'✦'; color:var(--sp-gold); }

/* scene card */
.sp-scene-card{
    position:relative; aspect-ratio:2/3; overflow:hidden;
    background:var(--sp-teal-d);
    border:1px solid rgba(192,148,58,.3);
    box-shadow:0 0 80px rgba(192,148,58,.12), var(--sp-shadow);
}
.sc-ceiling{ position:absolute; top:0; left:0; right:0; height:22%; background:#0D1C1C; }
.sc-pool{
    position:absolute; bottom:0; left:0; right:0; height:28%;
    background:linear-gradient(180deg,#1D6060,#0E3030);
    border-top:2px solid rgba(100,200,200,.3);
}
.sc-pool::before{
    content:''; position:absolute; inset:0;
    background:
        repeating-linear-gradient(90deg,rgba(255,255,255,.08) 0,rgba(255,255,255,.08) 1px,transparent 1px,transparent 12px),
        repeating-linear-gradient(0deg,rgba(255,255,255,.08) 0,rgba(255,255,255,.08) 1px,transparent 1px,transparent 12px);
}
.sc-wall{ position:absolute; top:22%; bottom:28%; left:0; right:0; background:#142020; }
.sc-candle{
    position:absolute; bottom:28%;
    display:flex; flex-direction:column; align-items:center;
}
.sc-candle-body{
    width:6px; height:var(--sch); background:#F0E8D8; border-radius:1px 1px 0 0;
}
.sc-candle-flame{
    width:5px; height:9px;
    background:radial-gradient(ellipse at 50% 80%,#FFF8C0,#F5A820 50%,transparent 80%);
    border-radius:50% 50% 30% 30%;
    animation:sp-flame-flicker 1.2s ease-in-out infinite;
}
.sp-float-badge{
    position:absolute; bottom:16px; left:16px; right:16px;
    background:rgba(10,20,20,.85); border:1px solid rgba(192,148,58,.4);
    color:var(--sp-white);
    font-family:var(--sp-font-b); font-size:.7rem; letter-spacing:.14em; text-transform:uppercase;
    padding:12px 16px; text-align:center;
    border-radius:4px;
    animation:sp-float 3.5s ease-in-out infinite;
}

/* ══════════════════════════════════════════
   STATS BAR
══════════════════════════════════════════ */
.sp-stats-bar{ background:var(--sp-teal-d); padding:56px 0; }
.sp-stats-grid{ display:grid; grid-template-columns:repeat(4,1fr); gap:0; }
.sp-stat-cell{ text-align:center; padding:0 32px; border-right:1px solid rgba(255,255,255,.1); }
.sp-stat-cell:last-child{ border-right:none; }
.sp-stat-val{
    font-family:var(--sp-font-h); font-size:3rem; color:var(--sp-white); display:block; letter-spacing:.02em;
}
.sp-stat-label{ font-size:.68rem; letter-spacing:.2em; text-transform:uppercase; color:rgba(255,255,255,.45); margin-top:6px; }

/* ══════════════════════════════════════════
   TREATMENTS
══════════════════════════════════════════ */
.sp-treat-grid{ display:grid; grid-template-columns:repeat(3,1fr); gap:1px; background:var(--sp-travert); }
.sp-treat-card{
    background:var(--sp-stone); padding:40px 32px;
    border-bottom:3px solid transparent; transition:border-color .3s, background .3s;
}
.sp-treat-card:hover{ background:var(--sp-white); border-bottom-color:var(--sp-gold); }
.sp-treat-icon{ font-size:1.8rem; display:block; margin-bottom:16px; }
.sp-treat-name{ font-family:var(--sp-font-h); font-size:1.2rem; color:var(--sp-teal-d); margin-bottom:4px; }
.sp-treat-meta{ font-size:.75rem; letter-spacing:.12em; text-transform:uppercase; color:var(--sp-gold); margin-bottom:14px; }
.sp-treat-desc{ font-size:.88rem; color:var(--sp-mid); line-height:1.75; }

/* ══════════════════════════════════════════
   PACKAGES
══════════════════════════════════════════ */
.sp-pkg-grid{ display:grid; grid-template-columns:repeat(3,1fr); gap:24px; }
.sp-pkg-card{
    background:var(--sp-white); border:1px solid var(--sp-travert);
    padding:48px 36px; text-align:center; position:relative;
    transition:box-shadow .3s, border-color .3s;
    border-radius:4px;
}
.sp-pkg-card:hover{ box-shadow:0 16px 48px rgba(0,0,0,.1); border-color:var(--sp-gold); }
.sp-pkg-card.highlight{ background:var(--sp-teal-d); border-color:var(--sp-teal-d); }
.sp-pkg-badge{
    position:absolute; top:-14px; left:50%; transform:translateX(-50%);
    background:var(--sp-gold); color:var(--sp-white);
    font-family:var(--sp-font-b); font-size:.68rem; letter-spacing:.16em; padding:4px 16px;
    white-space:nowrap; text-transform:uppercase; border-radius:100px;
}
.sp-pkg-name{ font-family:var(--sp-font-h); font-size:1.8rem; margin-bottom:8px; }
.sp-pkg-name.light{ color:var(--sp-teal-d); }
.sp-pkg-name.dark{ color:var(--sp-white); }
.sp-pkg-includes{ font-size:.78rem; letter-spacing:.1em; color:var(--sp-mid); text-transform:uppercase; margin-bottom:24px; }
.sp-pkg-includes.light{ color:rgba(255,255,255,.6); }
.sp-pkg-price{ font-family:var(--sp-font-h); font-size:3rem; margin-bottom:16px; }
.sp-pkg-price.light{ color:var(--sp-teal-d); }
.sp-pkg-price.dark{ color:var(--sp-white); }
.sp-pkg-desc{ font-size:.88rem; color:var(--sp-mid); line-height:1.75; margin-bottom:32px; }
.sp-pkg-desc.dark{ color:rgba(255,255,255,.6); }

/* ══════════════════════════════════════════
   EXPERIENCE PROCESS
══════════════════════════════════════════ */
.sp-exp-grid{ display:grid; grid-template-columns:repeat(4,1fr); gap:40px; }
.sp-exp-step{ text-align:center; }
.sp-exp-num{
    width:72px; height:72px; border-radius:50%;
    border:1.5px solid var(--sp-gold);
    display:flex; align-items:center; justify-content:center;
    font-family:var(--sp-font-h); font-size:1.4rem; color:var(--sp-gold);
    margin:0 auto 20px; background:transparent;
    transition:background .3s;
}
.sp-exp-step:hover .sp-exp-num{ background:var(--sp-gold); color:var(--sp-white); }
.sp-exp-title{ font-family:var(--sp-font-h); font-size:1.1rem; color:var(--sp-teal-d); margin-bottom:10px; }
.sp-exp-desc{ font-size:.85rem; color:var(--sp-mid); }

/* ══════════════════════════════════════════
   TEAM
══════════════════════════════════════════ */
.sp-team-grid{ display:grid; grid-template-columns:repeat(4,1fr); gap:24px; }
.sp-team-card{
    background:var(--sp-white); border:1px solid var(--sp-travert); overflow:hidden;
    border-radius:4px; transition:box-shadow .3s;
}
.sp-team-card:hover{ box-shadow:0 12px 40px rgba(0,0,0,.1); }
.sp-team-avatar{
    height:200px; background:var(--sp-sand);
    display:flex; align-items:flex-end; justify-content:center;
    overflow:hidden; position:relative;
}
.sp-team-accent{ position:absolute; bottom:0; left:0; right:0; height:4px; background:var(--accent); }
/* CSS therapist figure */
.sp-figure{
    position:relative; width:80px; height:170px;
}
.sp-fig-head{
    position:absolute; top:10px; left:50%; transform:translateX(-50%);
    width:32px; height:32px; border-radius:50%;
    background:linear-gradient(180deg,#D4A878,#C09060);
}
/* hair */
.sp-fig-head::before{
    content:''; position:absolute; top:0; left:0; right:0; height:14px;
    background:#3C2810; border-radius:50% 50% 0 0;
}
.sp-fig-body{
    position:absolute; top:46px; left:50%; transform:translateX(-50%);
    width:42px; height:52px;
    background:#FFFFFF; /* white therapist tunic */
    border-radius:2px;
}
/* tunic collar */
.sp-fig-body::before{
    content:''; position:absolute; top:0; left:50%; transform:translateX(-50%);
    width:12px; height:10px;
    background:var(--accent);
    clip-path:polygon(20% 0,80% 0,100% 100%,0 100%);
}
.sp-fig-arm-l,.sp-fig-arm-r{
    position:absolute; width:10px; height:42px;
    background:#FFFFFF; border-radius:5px;
}
.sp-fig-arm-l{ top:46px; left:calc(50% - 30px); transform:rotate(8deg); transform-origin:top; }
.sp-fig-arm-r{ top:46px; right:calc(50% - 30px); transform:rotate(-8deg); transform-origin:top; }
.sp-fig-leg-l,.sp-fig-leg-r{
    position:absolute; width:14px; height:50px;
    background:#C8C0B0; border-radius:3px 3px 6px 6px;
}
.sp-fig-leg-l{ top:96px; left:calc(50% - 16px); }
.sp-fig-leg-r{ top:96px; right:calc(50% - 16px); }
.sp-team-info{ padding:20px; }
.sp-team-name{ font-family:var(--sp-font-h); font-size:1.1rem; color:var(--sp-teal-d); margin-bottom:4px; }
.sp-team-role{ font-size:.72rem; letter-spacing:.14em; text-transform:uppercase; color:var(--sp-gold); font-weight:500; margin-bottom:6px; }
.sp-team-spec{ font-size:.82rem; color:var(--sp-mid); }

/* ══════════════════════════════════════════
   TESTIMONIALS
══════════════════════════════════════════ */
.sp-testi-grid{ display:grid; grid-template-columns:repeat(3,1fr); gap:24px; }
.sp-testi-card{
    background:var(--sp-white); border:1px solid var(--sp-travert);
    padding:36px; border-radius:4px;
    border-top:3px solid var(--sp-gold);
}
.sp-stars{ color:var(--sp-gold); font-size:.9rem; letter-spacing:.2em; margin-bottom:16px; }
.sp-testi-text{ font-family:var(--sp-font-h); font-size:1rem; font-style:italic; color:var(--sp-dark); line-height:1.8; margin-bottom:20px; }
.sp-testi-name{ font-family:var(--sp-font-h); font-size:.95rem; color:var(--sp-teal-d); margin-bottom:2px; }
.sp-testi-role{ font-size:.72rem; letter-spacing:.12em; text-transform:uppercase; color:var(--sp-mid); }

/* ══════════════════════════════════════════
   FAQ
══════════════════════════════════════════ */
.sp-faq-list{ max-width:760px; margin:0 auto; display:flex; flex-direction:column; gap:1px; }
.sp-faq-item{ background:var(--sp-white); }
.sp-faq-btn{
    width:100%; text-align:left; padding:22px 28px;
    font-family:var(--sp-font-h); font-size:1.05rem; color:var(--sp-teal-d);
    background:none; border:none; cursor:pointer;
    display:flex; justify-content:space-between; align-items:center; gap:16px;
}
.sp-faq-icon{ font-size:1.2rem; color:var(--sp-gold); flex-shrink:0; transition:transform .3s; }
.sp-faq-item.open .sp-faq-icon{ transform:rotate(45deg); }
.sp-faq-body{ max-height:0; overflow:hidden; transition:max-height .4s ease; }
.sp-faq-body-inner{ padding:0 28px 24px; font-size:.92rem; color:var(--sp-mid); line-height:1.8; }

/* ══════════════════════════════════════════
   BOOKING FORM
══════════════════════════════════════════ */
.sp-book-grid{ display:grid; grid-template-columns:1fr 1fr; gap:80px; align-items:start; }
.sp-book-info-items{ display:flex; flex-direction:column; gap:24px; margin-top:32px; }
.sp-book-item{ display:flex; gap:16px; }
.sp-book-icon{
    width:44px; height:44px; border-radius:50%;
    border:1px solid var(--sp-gold); color:var(--sp-gold);
    display:flex; align-items:center; justify-content:center;
    font-size:1.1rem; flex-shrink:0;
}
.sp-book-label{ font-size:.7rem; letter-spacing:.16em; text-transform:uppercase; color:var(--sp-mid); margin-bottom:4px; }
.sp-book-val{ font-size:.9rem; color:var(--sp-dark); }

.sp-form{ display:flex; flex-direction:column; gap:20px; }
.sp-form-row{ display:grid; grid-template-columns:1fr 1fr; gap:20px; }
.sp-field label{
    display:block; font-size:.7rem; font-weight:500; letter-spacing:.16em;
    color:var(--sp-mid); text-transform:uppercase; margin-bottom:8px;
}
.sp-field input,.sp-field select,.sp-field textarea{
    width:100%; padding:13px 16px;
    background:var(--sp-white); border:1px solid var(--sp-travert);
    color:var(--sp-dark); font-family:var(--sp-font-b); font-size:.92rem;
    border-radius:2px; transition:border-color .25s;
}
.sp-field input:focus,.sp-field select:focus,.sp-field textarea:focus{
    outline:none; border-color:var(--sp-gold);
}
.sp-field select{
    appearance:none;
    background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath d='M1 1l4 4 4-4' stroke='%23C0943A' fill='none' stroke-width='1.5'/%3E%3C/svg%3E");
    background-repeat:no-repeat; background-position:calc(100% - 14px) 50%; padding-right:36px;
}
.sp-field textarea{ resize:vertical; min-height:110px; }
.sp-form-note{ font-size:.78rem; color:var(--sp-mid); }
.sp-form-note a{ color:var(--sp-gold); }

/* ══════════════════════════════════════════
   FOOTER CTA
══════════════════════════════════════════ */
.sp-cta{
    background:linear-gradient(135deg,var(--sp-teal-d) 0%,#0A2424 100%);
    padding:80px 0; text-align:center;
    position:relative; overflow:hidden;
}
.sp-cta::before{
    content:''; position:absolute; top:-80px; left:-80px;
    width:400px; height:400px; border-radius:50%;
    border:1px solid rgba(192,148,58,.15);
}
.sp-cta::after{
    content:''; position:absolute; bottom:-80px; right:-80px;
    width:300px; height:300px; border-radius:50%;
    border:1px solid rgba(192,148,58,.1);
}
.sp-cta-inner{ position:relative; z-index:1; }
.sp-cta-title{ font-family:var(--sp-font-h); font-size:clamp(1.8rem,4vw,3rem); color:var(--sp-white); margin-bottom:16px; }
.sp-cta-sub{ font-size:.9rem; color:rgba(255,255,255,.5); margin-bottom:40px; letter-spacing:.08em; }
.sp-cta-divider{ width:40px; height:1px; background:var(--sp-gold); margin:16px auto; }

/* ══════════════════════════════════════════
   KEYFRAMES
══════════════════════════════════════════ */
@keyframes sp-shimmer{
    0%,100%{ opacity:1; }
    50%{ opacity:.6; }
}
@keyframes sp-flame-flicker{
    0%,100%{ transform:scaleX(1) scaleY(1); opacity:1; }
    25%{ transform:scaleX(.8) scaleY(1.1); opacity:.9; }
    50%{ transform:scaleX(1.1) scaleY(.95); opacity:1; }
    75%{ transform:scaleX(.9) scaleY(1.05); opacity:.85; }
}
@keyframes sp-steam-rise{
    0%   { transform:translateY(0) scale(1); opacity:0; }
    15%  { opacity:.5; }
    100% { transform:translateY(-120px) scale(3); opacity:0; }
}
@keyframes sp-petal-drift{
    0%  { transform:rotate(var(--pr)) translateY(0) translateX(0); opacity:.8; }
    100%{ transform:rotate(calc(var(--pr) + 20deg)) translateY(30px) translateX(15px); opacity:0; }
}
@keyframes sp-float{
    0%,100%{ transform:translateY(0); }
    50%    { transform:translateY(-6px); }
}

/* ══════════════════════════════════════════
   RESPONSIVE
══════════════════════════════════════════ */
@media(max-width:1024px){
    .sp-hero-inner{ grid-template-columns:1fr; gap:48px; }
    .sp-stats-grid{ grid-template-columns:repeat(2,1fr); }
    .sp-stat-cell:nth-child(2){ border-right:none; }
    .sp-stat-cell:nth-child(3){ border-right:1px solid rgba(255,255,255,.1); }
    .sp-treat-grid{ grid-template-columns:repeat(2,1fr); }
    .sp-pkg-grid{ grid-template-columns:1fr; max-width:420px; margin:0 auto; }
    .sp-exp-grid{ grid-template-columns:repeat(2,1fr); }
    .sp-team-grid{ grid-template-columns:repeat(2,1fr); }
    .sp-testi-grid{ grid-template-columns:1fr; }
    .sp-book-grid{ grid-template-columns:1fr; }
}
@media(max-width:640px){
    .sp-treat-grid,.sp-team-grid{ grid-template-columns:1fr; }
    .sp-form-row{ grid-template-columns:1fr; }
    .sp-stats-grid{ grid-template-columns:1fr; }
    .sp-exp-grid{ grid-template-columns:1fr; }
    .sp-stat-cell{ border-right:none; border-bottom:1px solid rgba(255,255,255,.1); }
}
</style>

<div class="sp-wrap">

<!-- ══════════════════════════════════════
     HERO
══════════════════════════════════════ -->
<section class="sp-hero">

    <div class="sp-ceiling"></div>
    <div class="sp-wall">
        <?php for($c=0;$c<5;$c++): $cl = (15 + $c*18).'%'; ?>
        <div class="sp-col" style="left:<?php echo $cl; ?>;"></div>
        <?php endfor; ?>
    </div>
    <div class="sp-pool"></div>
    <div class="sp-pool-edge"></div>
    <div class="sp-pool-floor-l"></div>
    <div class="sp-pool-floor-r"></div>
    <div class="sp-pool-glow"></div>

    <!-- candles -->
    <?php foreach($sp_candles as $can): ?>
    <div class="sp-candle" style="left:<?php echo $can['left']; ?>;">
        <div class="sp-candle-flame"></div>
        <div class="sp-candle-body" style="--ch:<?php echo $can['h']; ?>px;"></div>
        <div class="sp-candle-base" style="--cb:<?php echo $can['base']; ?>;"></div>
        <div class="sp-candle-glow"></div>
    </div>
    <?php endforeach; ?>

    <!-- steam -->
    <?php foreach($sp_steams as $st): ?>
    <div class="sp-steam"
         style="left:<?php echo $st['left']; ?>%;--sw:<?php echo $st['size']; ?>px;height:<?php echo $st['size']; ?>px;--sd:<?php echo $st['dur']; ?>ms;--sde:<?php echo $st['delay']; ?>ms;">
    </div>
    <?php endforeach; ?>

    <!-- orchids -->
    <?php foreach($sp_orchids as $orch): ?>
    <div class="sp-orchid" style="left:<?php echo $orch['left']; ?>;">
        <?php for($s=0;$s<$orch['stems'];$s++):
            $sh = 50 + rand(10,30);
            $sl = -8 + $s*16;
        ?>
        <div class="sp-orchid-stem" style="--osh:<?php echo $sh; ?>px;margin-left:<?php echo $sl; ?>px;">
            <div class="sp-orchid-bloom"></div>
        </div>
        <?php endfor; ?>
        <div class="sp-orchid-soil"></div>
        <div class="sp-orchid-pot"></div>
    </div>
    <?php endforeach; ?>

    <!-- petals -->
    <?php foreach($sp_petals as $p):
        $pcls = ['rose','blush','white'][$p['hue']]; ?>
    <div class="sp-petal <?php echo $pcls; ?>"
         style="left:<?php echo $p['left']; ?>%;top:<?php echo $p['top']; ?>%;--pw:<?php echo $p['size']; ?>px;--pd:<?php echo $p['dur']; ?>ms;--pde:<?php echo $p['delay']; ?>ms;--pr:<?php echo $p['rot']; ?>deg;">
    </div>
    <?php endforeach; ?>

    <!-- hero content -->
    <div class="sp-hero-inner">
        <div>
            <div class="sp-hero-tag">
                <div class="sp-hero-tag-dot"></div>
                <div class="sp-hero-tag-text">Luxury Spa · London · Mayfair</div>
            </div>
            <h1 class="sp-h1">
                Surrender to<br>
                <span class="sp-accent">pure</span><br>
                restoration.
            </h1>
            <p class="sp-lead" style="margin-top:24px; color:rgba(245,240,232,.7);">
                Aqua Lumina is a world-class thermal spa and treatment centre in the
                heart of Mayfair — a sanctuary designed to restore harmony between
                mind, body and spirit.
            </p>
            <div class="sp-hero-badges">
                <span class="sp-badge">Tripadvisor Certificate of Excellence 2024</span>
                <span class="sp-badge">Tatler Spa of the Year</span>
                <span class="sp-badge">4.9 ★ Trustpilot</span>
            </div>
            <div class="sp-hero-actions">
                <a href="#book" class="sp-btn sp-btn-gold">Book a Treatment</a>
                <a href="#packages" class="sp-btn sp-btn-outline">Day Packages</a>
            </div>
        </div>

        <!-- scene card -->
        <div>
            <div class="sp-scene-card">
                <div class="sc-ceiling"></div>
                <div class="sc-wall"></div>
                <div class="sc-pool"></div>
                <!-- mini candles on card -->
                <?php foreach([['30%',30],['50%',22],['70%',28]] as $sc): ?>
                <div class="sc-candle" style="left:<?php echo $sc[0]; ?>;">
                    <div class="sc-candle-flame"></div>
                    <div class="sc-candle-body" style="--sch:<?php echo $sc[1]; ?>px;"></div>
                </div>
                <?php endforeach; ?>
                <div class="sp-float-badge">✦ Aqua Lumina · Mayfair · Est. 2006</div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     STATS BAR
══════════════════════════════════════ -->
<div class="sp-stats-bar">
    <div class="sp-container">
        <div class="sp-stats-grid">
            <?php foreach($sp_stats as $st):
                $isf = floor($st['val']) !== (float)$st['val']; ?>
            <div class="sp-stat-cell">
                <span class="sp-stat-val"
                      data-target="<?php echo $st['val']; ?>"
                      data-suffix="<?php echo esc_attr($st['suffix']); ?>"
                      data-float="<?php echo $isf?'1':'0'; ?>">
                    0<?php echo esc_html($st['suffix']); ?>
                </span>
                <div class="sp-stat-label"><?php echo esc_html($st['label']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ══════════════════════════════════════
     TREATMENTS
══════════════════════════════════════ -->
<section class="sp-section">
    <div class="sp-container">
        <div class="sp-section-header">
            <span class="sp-overline">Menu of Treatments</span>
            <h2 class="sp-h2">Crafted for <span class="sp-accent">Transformation</span></h2>
            <div class="sp-divider"></div>
            <p class="sp-lead" style="margin:0 auto; text-align:center;">
                Every treatment is performed by our award-winning therapists using the world's finest skincare and wellness brands.
            </p>
        </div>
        <div class="sp-treat-grid">
            <?php foreach($sp_treatments as $tr): ?>
            <div class="sp-treat-card">
                <span class="sp-treat-icon"><?php echo $tr['icon']; ?></span>
                <div class="sp-treat-name"><?php echo esc_html($tr['name']); ?></div>
                <div class="sp-treat-meta"><?php echo esc_html($tr['dur']); ?> · from <?php echo esc_html($tr['price']); ?></div>
                <p class="sp-treat-desc"><?php echo esc_html($tr['desc']); ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     EXPERIENCE PROCESS
══════════════════════════════════════ -->
<section class="sp-section sp-section-alt">
    <div class="sp-container">
        <div class="sp-section-header">
            <span class="sp-overline">Your Journey</span>
            <h2 class="sp-h2">The Aqua Lumina <span class="sp-accent">Experience</span></h2>
            <div class="sp-divider"></div>
        </div>
        <div class="sp-exp-grid">
            <?php foreach($sp_process as $p): ?>
            <div class="sp-exp-step">
                <div class="sp-exp-num"><?php echo esc_html($p['n']); ?></div>
                <div class="sp-exp-title"><?php echo esc_html($p['t']); ?></div>
                <p class="sp-exp-desc"><?php echo esc_html($p['d']); ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     PACKAGES
══════════════════════════════════════ -->
<section class="sp-section" id="packages">
    <div class="sp-container">
        <div class="sp-section-header">
            <span class="sp-overline">Spa Days</span>
            <h2 class="sp-h2">Curated <span class="sp-accent">Day Packages</span></h2>
            <div class="sp-divider"></div>
            <p class="sp-lead" style="margin:0 auto; text-align:center;">
                From a peaceful afternoon to a full day of indulgence — each package is designed with care.
            </p>
        </div>
        <div class="sp-pkg-grid">
            <?php foreach($sp_packages as $pkg): ?>
            <div class="sp-pkg-card <?php echo $pkg['highlight']?'highlight':''; ?>">
                <?php if($pkg['highlight']): ?>
                <div class="sp-pkg-badge">Most Popular</div>
                <?php endif; ?>
                <?php $c = $pkg['highlight']?'dark':'light'; ?>
                <div class="sp-pkg-name <?php echo $c; ?>"><?php echo esc_html($pkg['name']); ?></div>
                <div class="sp-pkg-includes <?php echo $c; ?>"><?php echo esc_html($pkg['includes']); ?></div>
                <div class="sp-pkg-price <?php echo $c; ?>"><?php echo esc_html($pkg['price']); ?></div>
                <p class="sp-pkg-desc <?php echo $c; ?>"><?php echo esc_html($pkg['desc']); ?></p>
                <a href="#book" class="sp-btn <?php echo $pkg['highlight']?'sp-btn-gold':''; ?>" style="width:100%;justify-content:center;">Reserve Now</a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     TEAM
══════════════════════════════════════ -->
<section class="sp-section sp-section-alt">
    <div class="sp-container">
        <div class="sp-section-header">
            <span class="sp-overline">Our Therapists</span>
            <h2 class="sp-h2">In Expert <span class="sp-accent">Hands</span></h2>
            <div class="sp-divider"></div>
        </div>
        <div class="sp-team-grid">
            <?php foreach($sp_team as $m): ?>
            <div class="sp-team-card" style="--accent:<?php echo esc_attr($m['colour']); ?>;">
                <div class="sp-team-avatar">
                    <div class="sp-team-accent"></div>
                    <div class="sp-figure">
                        <div class="sp-fig-head"></div>
                        <div class="sp-fig-body"></div>
                        <div class="sp-fig-arm-l"></div>
                        <div class="sp-fig-arm-r"></div>
                        <div class="sp-fig-leg-l"></div>
                        <div class="sp-fig-leg-r"></div>
                    </div>
                </div>
                <div class="sp-team-info">
                    <div class="sp-team-name"><?php echo esc_html($m['name']); ?></div>
                    <div class="sp-team-role"><?php echo esc_html($m['role']); ?></div>
                    <div class="sp-team-spec"><?php echo esc_html($m['spec']); ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     TESTIMONIALS
══════════════════════════════════════ -->
<section class="sp-section">
    <div class="sp-container">
        <div class="sp-section-header">
            <span class="sp-overline">Guest Experiences</span>
            <h2 class="sp-h2">What Our <span class="sp-accent">Guests Say</span></h2>
            <div class="sp-divider"></div>
        </div>
        <div class="sp-testi-grid">
            <?php foreach($sp_testimonials as $t): ?>
            <div class="sp-testi-card">
                <div class="sp-stars">★★★★★</div>
                <p class="sp-testi-text">"<?php echo esc_html($t['text']); ?>"</p>
                <div class="sp-testi-name"><?php echo esc_html($t['name']); ?></div>
                <div class="sp-testi-role"><?php echo esc_html($t['role']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     FAQ
══════════════════════════════════════ -->
<section class="sp-section sp-section-alt">
    <div class="sp-container">
        <div class="sp-section-header">
            <span class="sp-overline">Your Questions</span>
            <h2 class="sp-h2">Everything You Need to <span class="sp-accent">Know</span></h2>
            <div class="sp-divider"></div>
        </div>
        <div class="sp-faq-list">
            <?php foreach($sp_faqs as $i=>$faq): ?>
            <div class="sp-faq-item" id="sp-faq-<?php echo $i; ?>">
                <button class="sp-faq-btn"
                        aria-expanded="false"
                        aria-controls="sp-faq-body-<?php echo $i; ?>">
                    <?php echo esc_html($faq['q']); ?>
                    <span class="sp-faq-icon">+</span>
                </button>
                <div class="sp-faq-body" id="sp-faq-body-<?php echo $i; ?>" role="region">
                    <div class="sp-faq-body-inner"><?php echo esc_html($faq['a']); ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     BOOKING FORM
══════════════════════════════════════ -->
<section class="sp-section" id="book">
    <div class="sp-container">
        <div class="sp-book-grid">

            <div>
                <span class="sp-overline">Reservations</span>
                <h2 class="sp-h2" style="margin-bottom:16px;">
                    Book Your <span class="sp-accent">Sanctuary</span>
                </h2>
                <div class="sp-divider"></div>
                <p class="sp-lead">
                    Reserve online or contact our reservations team — we're delighted to
                    help you design your perfect spa day.
                </p>
                <div class="sp-book-info-items">
                    <div class="sp-book-item">
                        <div class="sp-book-icon">📍</div>
                        <div>
                            <div class="sp-book-label">Location</div>
                            <div class="sp-book-val">12 Grosvenor Square, Mayfair, London W1K 6JP</div>
                        </div>
                    </div>
                    <div class="sp-book-item">
                        <div class="sp-book-icon">📞</div>
                        <div>
                            <div class="sp-book-label">Reservations</div>
                            <div class="sp-book-val">+44 (0)20 7900 1234</div>
                        </div>
                    </div>
                    <div class="sp-book-item">
                        <div class="sp-book-icon">⏰</div>
                        <div>
                            <div class="sp-book-label">Opening Hours</div>
                            <div class="sp-book-val">Daily 07:00 – 21:00</div>
                        </div>
                    </div>
                    <div class="sp-book-item">
                        <div class="sp-book-icon">🎁</div>
                        <div>
                            <div class="sp-book-label">Gift Vouchers</div>
                            <div class="sp-book-val">Available in any value · Beautifully packaged</div>
                        </div>
                    </div>
                </div>
            </div>

            <form class="sp-form"
                  method="post"
                  action="<?php echo esc_url(admin_url('admin-post.php')); ?>">

                <?php wp_nonce_field('tf_sp_enquiry','tf_sp_nonce'); ?>
                <input type="hidden" name="action" value="tf_sp_enquiry">

                <div class="sp-form-row">
                    <div class="sp-field">
                        <label for="sp-fname">First Name <span style="color:var(--sp-gold)">*</span></label>
                        <input type="text" id="sp-fname" name="sp_fname" required placeholder="Isabelle">
                    </div>
                    <div class="sp-field">
                        <label for="sp-lname">Last Name <span style="color:var(--sp-gold)">*</span></label>
                        <input type="text" id="sp-lname" name="sp_lname" required placeholder="Moreau">
                    </div>
                </div>

                <div class="sp-form-row">
                    <div class="sp-field">
                        <label for="sp-email">Email Address <span style="color:var(--sp-gold)">*</span></label>
                        <input type="email" id="sp-email" name="sp_email" required placeholder="isabelle@email.com">
                    </div>
                    <div class="sp-field">
                        <label for="sp-phone">Telephone</label>
                        <input type="tel" id="sp-phone" name="sp_phone" placeholder="+44 7700 900 000">
                    </div>
                </div>

                <div class="sp-field">
                    <label for="sp-treatment">Treatment or Package <span style="color:var(--sp-gold)">*</span></label>
                    <select id="sp-treatment" name="sp_treatment" required>
                        <option value="" disabled selected>Select your preference…</option>
                        <optgroup label="Treatments">
                            <option>Signature Massage — 90 min · £145</option>
                            <option>Gold Radiance Facial — 75 min · £165</option>
                            <option>Himalayan Salt Journey — 60 min · £125</option>
                            <option>Thermal Pool Ritual — 120 min · £95</option>
                            <option>Rose & Resveratrol Body — 75 min · £135</option>
                            <option>Mindful Restore — 90 min · £115</option>
                        </optgroup>
                        <optgroup label="Day Packages">
                            <option>Serene Package — £195</option>
                            <option>Lumina Package — £295</option>
                            <option>Celestial Package — £425</option>
                        </optgroup>
                    </select>
                </div>

                <div class="sp-form-row">
                    <div class="sp-field">
                        <label for="sp-date">Preferred Date <span style="color:var(--sp-gold)">*</span></label>
                        <input type="date" id="sp-date" name="sp_date" required
                               min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>">
                    </div>
                    <div class="sp-field">
                        <label for="sp-guests">Number of Guests</label>
                        <select id="sp-guests" name="sp_guests">
                            <option value="1" selected>1 Guest</option>
                            <option value="2">2 Guests (Couples)</option>
                            <option value="3">3 Guests</option>
                            <option value="4">4 Guests</option>
                            <option value="5+">5+ Guests (Group)</option>
                        </select>
                    </div>
                </div>

                <div class="sp-field">
                    <label for="sp-notes">Special Requests or Health Information</label>
                    <textarea id="sp-notes" name="sp_notes"
                              placeholder="Allergies, pregnancy, injuries, celebrations — please share anything we should know so we can personalise your visit…"></textarea>
                </div>

                <p class="sp-form-note">
                    All health information is held in strict confidence. By submitting you agree to our
                    <a href="#">Privacy Policy</a> and <a href="#">Cancellation Policy</a>.
                </p>

                <button type="submit" class="sp-btn sp-btn-gold" style="width:100%;justify-content:center;">
                    Request Reservation ✦
                </button>
            </form>

        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     FOOTER CTA
══════════════════════════════════════ -->
<div class="sp-cta">
    <div class="sp-container sp-cta-inner">
        <p class="sp-overline" style="color:var(--sp-gold);text-align:center;">A Gift of Wellbeing</p>
        <div class="sp-cta-title">Give the gift of <em>restoration.</em></div>
        <div class="sp-cta-divider"></div>
        <p class="sp-cta-sub">Aqua Lumina gift vouchers — available in any value, beautifully presented.</p>
        <a href="#book" class="sp-btn sp-btn-gold">Purchase a Gift Voucher</a>
    </div>
</div>

</div><!-- /.sp-wrap -->

<script>
(function(){
    /* ── Animated counters ─────────────────────── */
    const easeOut = t => 1 - Math.pow(1 - t, 3);
    const counterEls = document.querySelectorAll('.sp-stat-val[data-target]');
    const seen = new Set();
    const obs = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if(!entry.isIntersecting || seen.has(entry.target)) return;
            seen.add(entry.target);
            const el     = entry.target;
            const target = parseFloat(el.dataset.target);
            const suffix = el.dataset.suffix || '';
            const isFloat= el.dataset.float === '1';
            if(isNaN(target)) return;
            const dur = 1800, start = performance.now();
            const tick = now => {
                const t = Math.min((now - start) / dur, 1);
                const v = easeOut(t) * target;
                el.textContent = (isFloat ? v.toFixed(1) : Math.round(v)) + suffix;
                if(t < 1) requestAnimationFrame(tick);
            };
            requestAnimationFrame(tick);
        });
    }, { threshold: 0.4 });
    counterEls.forEach(el => obs.observe(el));

    /* ── FAQ accordion ─────────────────────────── */
    document.querySelectorAll('.sp-faq-btn').forEach(btn => {
        btn.addEventListener('click', function(){
            const item = this.closest('.sp-faq-item');
            const body = item.querySelector('.sp-faq-body');
            const open = item.classList.contains('open');
            document.querySelectorAll('.sp-faq-item.open').forEach(i => {
                i.classList.remove('open');
                i.querySelector('.sp-faq-body').style.maxHeight = '0';
                i.querySelector('.sp-faq-btn').setAttribute('aria-expanded','false');
            });
            if(!open){
                item.classList.add('open');
                body.style.maxHeight = body.scrollHeight + 'px';
                this.setAttribute('aria-expanded','true');
            }
        });
    });
})();
</script>

<?php get_footer(); ?>
