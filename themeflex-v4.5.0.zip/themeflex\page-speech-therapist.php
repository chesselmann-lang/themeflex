<?php
/**
 * Template Name: Speech Therapist
 * Description: Premium speech & language therapist homepage template
 *
 * @package ThemeFlex
 */

// ── Deterministic randomness ────────────────────────────────────────────────
srand( crc32( get_the_permalink() ) );

// ── Therapist data ──────────────────────────────────────────────────────────
$therapist = [
    'name'     => 'Dr. Natalie Harper',
    'title'    => 'MRCSLT Registered Speech & Language Therapist',
    'location' => 'Edinburgh & Lothians · Telehealth UK-wide',
    'tagline'  => 'Every Voice Deserves to Be Heard',
    'bio'      => 'Dr. Natalie Harper is a registered speech and language therapist with 16 years of clinical experience across NHS and private practice. Holding a doctorate in Communication Sciences from the University of Edinburgh, she provides evidence-based therapy for children and adults across a wide range of communication and swallowing difficulties.',
    'bio2'     => 'Her warm, person-centred approach ensures every client feels understood and empowered. Natalie believes passionately that communication is connection — and that with the right support, every person can find their clearest, most confident voice.',
    'years'    => 16,
    'clients'  => 1800,
    'rating'   => 4.9,
    'success'  => 95,
];

// ── Services ─────────────────────────────────────────────────────────────────
$services = [
    [ 'icon' => '🗣️', 'title' => 'Stuttering & Fluency',    'desc' => 'Specialist therapy for stammering in children and adults, including cognitive-behavioural approaches and fluency shaping.' ],
    [ 'icon' => '🧒', 'title' => 'Child Speech Delay',      'desc' => 'Assessment and therapy for late talkers, phonological difficulties and developmental speech sound disorders.' ],
    [ 'icon' => '📚', 'title' => 'Language Development',    'desc' => 'Vocabulary, grammar, narrative and comprehension therapy for children with DLD and language delay.' ],
    [ 'icon' => '🧠', 'title' => 'Acquired Aphasia',        'desc' => 'Post-stroke and acquired brain injury communication rehabilitation using evidence-based approaches.' ],
    [ 'icon' => '🎤', 'title' => 'Voice Therapy',           'desc' => 'For vocal nodules, muscle tension dysphonia, voice fatigue and professional voice users including singers and teachers.' ],
    [ 'icon' => '🍽️', 'title' => 'Dysphagia (Swallowing)', 'desc' => 'Assessment and management of swallowing difficulties in adults across a range of neurological conditions.' ],
    [ 'icon' => '🌟', 'title' => 'Selective Mutism',        'desc' => 'Gradual exposure and anxiety-reduction programmes for children and young people with selective mutism.' ],
    [ 'icon' => '💼', 'title' => 'Executive Coaching',      'desc' => 'Accent modification, presentation confidence and professional communication skills for business clients.' ],
];

// ── Age groups served ─────────────────────────────────────────────────────────
$age_groups = [
    [ 'label' => 'Infants & Toddlers', 'age' => '0–3 yrs',  'icon' => '👶', 'colour' => '#FFD6E0' ],
    [ 'label' => 'Pre-School',         'age' => '3–5 yrs',  'icon' => '🎨', 'colour' => '#FFE4C4' ],
    [ 'label' => 'School Age',         'age' => '5–16 yrs', 'icon' => '📖', 'colour' => '#C8E6C9' ],
    [ 'label' => 'Adults',             'age' => '16–64 yrs','icon' => '🧑', 'colour' => '#BBDEFB' ],
    [ 'label' => 'Older Adults',       'age' => '65+ yrs',  'icon' => '👴', 'colour' => '#E1BEE7' ],
];

// ── Packages ─────────────────────────────────────────────────────────────────
$packages = [
    [
        'name'     => 'Initial Assessment',
        'price'    => '£175',
        'period'   => 'one-off session',
        'colour'   => 'sky',
        'features' => [
            'Comprehensive 75-min assessment',
            'Standardised assessment tools',
            'Written diagnostic report',
            'Therapy recommendations',
            'Parent / carer debrief',
        ],
        'featured' => false,
    ],
    [
        'name'     => 'Therapy Block',
        'price'    => '£540',
        'period'   => '6 × 50-min sessions',
        'colour'   => 'teal',
        'features' => [
            'Full assessment included',
            '6 therapy sessions',
            'Home practice materials',
            'Parent coaching included',
            'Progress report at end',
            'Email support between sessions',
            'Telehealth or in-person',
        ],
        'featured' => true,
    ],
    [
        'name'     => 'Intensive Programme',
        'price'    => '£980',
        'period'   => '12-session block',
        'colour'   => 'deep',
        'features' => [
            'Assessment + 12 sessions',
            'Bi-weekly therapy schedule',
            'School / nursery liaison',
            'Written SMART goals plan',
            'Mid-block review meeting',
            'Full outcome report',
            'Priority booking access',
        ],
        'featured' => false,
    ],
];

// ── Process ───────────────────────────────────────────────────────────────────
$steps = [
    [ 'num' => '01', 'title' => 'Free 15-Min Call',        'desc' => 'Discuss your concerns, ask questions and find out if Natalie is the right fit.' ],
    [ 'num' => '02', 'title' => 'Comprehensive Assessment', 'desc' => 'Standardised and informal assessments to build a full picture of communication strengths and needs.' ],
    [ 'num' => '03', 'title' => 'Goal Setting',             'desc' => 'Together, we create personalised SMART goals that are meaningful to you and your family.' ],
    [ 'num' => '04', 'title' => 'Evidence-Based Therapy',   'desc' => 'Regular sessions with practice activities to consolidate gains between appointments.' ],
    [ 'num' => '05', 'title' => 'Review & Celebrate',       'desc' => 'Track progress with objective measures and celebrate every milestone along the journey.' ],
];

// ── FAQs ─────────────────────────────────────────────────────────────────────
$faqs = [
    [ 'q' => 'At what age should I seek a speech assessment for my child?', 'a' => 'If you have any concerns about your child\'s speech or language development, it\'s never too early to seek advice. Early intervention typically leads to the best outcomes. Natalie works with children from 12 months.' ],
    [ 'q' => 'Do you accept NHS referrals?', 'a' => 'Natalie\'s private practice operates independently of the NHS. However, she is registered with all major private health insurers including Bupa, AXA and Vitality, and can provide invoices for insurance claims.' ],
    [ 'q' => 'How many sessions will my child need?', 'a' => 'This varies widely depending on the nature and severity of the difficulty. After assessment, Natalie will give an honest recommendation. Most children with mild-to-moderate delays show meaningful progress within 6–12 sessions.' ],
    [ 'q' => 'Are telehealth sessions as effective as face-to-face?', 'a' => 'Research supports the effectiveness of telehealth speech therapy, particularly for language, fluency and voice work. Natalie has delivered telehealth sessions since 2019 and has adapted all her materials for the online format.' ],
    [ 'q' => 'Do you work with autism and ADHD?', 'a' => 'Yes. Natalie has significant experience working with autistic children and adults, as well as those with ADHD. Her neurodiversity-affirming approach respects each person\'s unique communication style while building skills they identify as priorities.' ],
    [ 'q' => 'Can you provide reports for EHCP or school applications?', 'a' => 'Yes. Natalie provides comprehensive written reports suitable for EHCP applications, tribunal proceedings, school placements and legal purposes. Report writing is charged separately to therapy sessions.' ],
];

// ── Soundwave bars (for hero) ─────────────────────────────────────────────────
$wave_bars = 36;

// ── Speech bubble positions ───────────────────────────────────────────────────
$bubbles = [
    [ 'text' => 'Tell me more…',      'top' => 12, 'left' => 62, 'delay' => 0,   'size' => .95 ],
    [ 'text' => 'I can do this!',     'top' => 28, 'left' => 72, 'delay' => 1.2, 'size' => .85 ],
    [ 'text' => 'Let\'s try again',   'top' => 55, 'left' => 58, 'delay' => 2.4, 'size' => .8  ],
    [ 'text' => 'Great work! 🌟',     'top' => 70, 'left' => 68, 'delay' => 3.6, 'size' => .9  ],
    [ 'text' => 'One step at a time', 'top' => 42, 'left' => 78, 'delay' => 1.8, 'size' => .75 ],
];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500;600;700&family=Open+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════════════════════════
   SPEECH THERAPIST TEMPLATE  —  namespace: --st-*
   ═══════════════════════════════════════════════════════════════════════════ */
:root {
  --st-teal:   #00796B;
  --st-sky:    #29B6F6;
  --st-deep:   #1A3A4A;
  --st-amber:  #F5A623;
  --st-cream:  #F5FBFB;
  --st-light:  #EAF6F5;
  --st-mid:    #4E6A72;
  --st-shadow: rgba(0,121,107,.13);
  --st-r:      14px;
  --st-ff:     'Quicksand', sans-serif;
  --st-ff2:    'Open Sans', sans-serif;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body.st-page{font-family:var(--st-ff2);color:var(--st-deep);background:var(--st-cream);line-height:1.75}
img{max-width:100%;display:block}
a{color:inherit;text-decoration:none}
.st-page h1,.st-page h2,.st-page h3,.st-page h4{font-family:var(--st-ff);font-weight:700;line-height:1.25}

/* ── LAYOUT ── */
.st-wrap{max-width:1160px;margin:0 auto;padding:0 24px}
.st-section{padding:96px 0}
.st-section--alt{background:#fff}
.st-section--light{background:var(--st-light)}
.st-tag{display:inline-block;font-family:var(--st-ff);font-size:.74rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--st-teal);background:rgba(0,121,107,.1);padding:6px 18px;border-radius:99px;margin-bottom:18px}

/* ── HERO ── */
.st-hero{position:relative;min-height:100vh;display:flex;align-items:center;overflow:hidden;background:linear-gradient(145deg,#0D2B38 0%,#1A3A4A 45%,#0D4A42 100%)}
.st-hero::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse 65% 55% at 30% 55%,rgba(0,121,107,.18) 0%,transparent 65%)}

/* soundwave */
.st-wave{position:absolute;bottom:0;left:0;right:0;height:55%;display:flex;align-items:flex-end;justify-content:center;gap:4px;padding-bottom:60px;z-index:2;opacity:.35}
.st-bar{border-radius:99px 99px 0 0;background:linear-gradient(180deg,var(--st-sky) 0%,var(--st-teal) 100%);animation:st-wave-bounce var(--wb-dur,.6s) ease-in-out var(--wb-d,0s) infinite alternate}
@keyframes st-wave-bounce{0%{height:var(--wb-min,20px)}100%{height:var(--wb-max,80px)}}

/* speech bubbles */
.st-bubble{position:absolute;background:#fff;border-radius:16px 16px 16px 4px;padding:8px 14px;font-family:var(--st-ff);font-size:.78rem;font-weight:600;color:var(--st-deep);box-shadow:0 4px 16px rgba(0,0,0,.18);z-index:5;animation:st-bubble-float var(--bb-dur,4s) ease-in-out var(--bb-d,0s) infinite alternate;white-space:nowrap;transform:scale(var(--bb-sc,1))}
.st-bubble::after{content:'';position:absolute;bottom:-8px;left:12px;width:16px;height:8px;background:#fff;clip-path:polygon(0 0,100% 0,0 100%)}
@keyframes st-bubble-float{0%{transform:scale(var(--bb-sc,1)) translateY(0)}100%{transform:scale(var(--bb-sc,1)) translateY(-10px)}}

/* therapist figure */
.st-figure{position:absolute;bottom:0;right:8%;z-index:6;width:140px}
.st-fig-head{width:52px;height:56px;background:linear-gradient(160deg,#F5D5B0,#EEC298);border-radius:50%;margin:0 auto;position:relative;border:2px solid rgba(255,255,255,.1)}
.st-fig-hair{position:absolute;top:0;left:0;right:0;height:26px;background:#5C3A1A;border-radius:50% 50% 0 0}
.st-fig-face-eyes{position:absolute;top:24px;left:50%;transform:translateX(-50%);width:30px;display:flex;justify-content:space-between}
.st-fig-eye{width:7px;height:5px;background:var(--st-deep);border-radius:50%;border-bottom:2px solid var(--st-sky)}
.st-fig-smile{position:absolute;bottom:12px;left:50%;transform:translateX(-50%);width:18px;height:8px;border-radius:0 0 50% 50%;border:2px solid #C07840;border-top:none}
.st-fig-body{width:58px;height:70px;background:linear-gradient(180deg,#00796B,#00574B);border-radius:8px 8px 4px 4px;margin:0 auto;position:relative;border:2px solid rgba(255,255,255,.08)}
.st-fig-lanyard{position:absolute;top:8px;left:50%;transform:translateX(-50%);width:22px;height:30px;background:var(--st-amber);border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:900;color:var(--st-deep)}
.st-fig-arm-l{position:absolute;top:6px;left:-14px;width:14px;height:40px;background:#00796B;border-radius:99px;border:2px solid rgba(255,255,255,.08)}
.st-fig-arm-r{position:absolute;top:6px;right:-14px;width:14px;height:40px;background:#00796B;border-radius:99px;border:2px solid rgba(255,255,255,.08);animation:st-arm-wave 2s ease-in-out infinite alternate}
@keyframes st-arm-wave{0%{transform:rotate(0deg)}100%{transform:rotate(-30deg)}}
.st-fig-hand{position:absolute;bottom:-6px;left:50%;transform:translateX(-50%);width:13px;height:13px;background:#F5D5B0;border-radius:50%}
.st-fig-legs{display:flex;justify-content:center;gap:4px;margin-top:2px}
.st-fig-leg{width:16px;height:44px;background:#2D4A5A;border-radius:4px;border:2px solid rgba(255,255,255,.05)}
.st-fig-shoe{width:20px;height:10px;background:#1A2A35;border-radius:99px 99px 50% 50%;margin-top:-2px}
.st-fig-clipboard{position:absolute;top:8px;right:-26px;width:22px;height:28px;background:#FFF9E6;border-radius:3px;border:2px solid #DDD;box-shadow:2px 2px 6px rgba(0,0,0,.2)}
.st-fig-clipboard::before{content:'';position:absolute;top:3px;left:3px;right:3px;height:2px;background:rgba(0,0,0,.15);border-radius:1px;box-shadow:0 4px 0 rgba(0,0,0,.1),0 8px 0 rgba(0,0,0,.1),0 12px 0 rgba(0,0,0,.1)}

/* hero content */
.st-hero__content{position:relative;z-index:10;max-width:580px;padding:40px 0 220px}
.st-hero__eyebrow{font-family:var(--st-ff);font-size:.78rem;font-weight:700;letter-spacing:.16em;text-transform:uppercase;color:var(--st-sky);margin-bottom:18px}
.st-hero__title{font-family:var(--st-ff);font-size:clamp(2.2rem,5vw,3.8rem);font-weight:700;color:#fff;line-height:1.12;margin-bottom:22px}
.st-hero__title span{color:var(--st-sky)}
.st-hero__sub{font-size:1.08rem;color:rgba(255,255,255,.78);max-width:450px;margin-bottom:40px}
.st-hero__ctas{display:flex;gap:16px;flex-wrap:wrap}
.st-btn{display:inline-flex;align-items:center;gap:8px;font-family:var(--st-ff);font-weight:700;font-size:.93rem;padding:14px 30px;border-radius:99px;cursor:pointer;border:none;transition:transform .2s,box-shadow .2s}
.st-btn--primary{background:var(--st-teal);color:#fff}
.st-btn--primary:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,121,107,.45)}
.st-btn--ghost{background:transparent;color:#fff;border:1.5px solid rgba(255,255,255,.4)}
.st-btn--ghost:hover{background:rgba(255,255,255,.08)}

/* trust badges */
.st-trust{display:flex;gap:24px;flex-wrap:wrap;padding-top:32px;margin-top:28px;border-top:1px solid rgba(255,255,255,.12)}
.st-trust-badge{display:flex;align-items:center;gap:10px;color:rgba(255,255,255,.85)}
.st-trust-badge__icon{font-size:1.4rem}
.st-trust-badge__text{font-size:.78rem;line-height:1.3}
.st-trust-badge__text strong{display:block;font-size:.88rem;color:#fff}

/* ── COUNTERS ── */
.st-counters{display:grid;grid-template-columns:repeat(4,1fr);gap:28px}
.st-counter{text-align:center;padding:36px 18px;background:#fff;border-radius:var(--st-r);box-shadow:0 4px 20px var(--st-shadow);border-top:3px solid var(--st-teal)}
.st-counter__num{font-family:var(--st-ff);font-size:2.6rem;font-weight:700;color:var(--st-teal);line-height:1}
.st-counter__label{font-size:.86rem;color:var(--st-mid);margin-top:10px}

/* ── SERVICES ── */
.st-services-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(255px,1fr));gap:24px;margin-top:52px}
.st-service-card{background:#fff;border-radius:var(--st-r);padding:30px 26px;box-shadow:0 4px 20px var(--st-shadow);transition:transform .25s,box-shadow .25s;border-left:4px solid var(--st-teal)}
.st-service-card:hover{transform:translateY(-4px);box-shadow:0 12px 32px var(--st-shadow)}
.st-service-card__icon{font-size:2rem;margin-bottom:14px}
.st-service-card__title{font-family:var(--st-ff);font-size:1.02rem;color:var(--st-deep);margin-bottom:10px}
.st-service-card__desc{font-size:.88rem;color:var(--st-mid);line-height:1.7}

/* ── AGE GROUPS ── */
.st-age-groups{display:flex;flex-wrap:wrap;gap:16px;margin-top:36px}
.st-age-card{display:flex;align-items:center;gap:12px;padding:16px 22px;border-radius:var(--st-r);font-family:var(--st-ff);font-weight:600;font-size:.9rem;color:var(--st-deep);box-shadow:0 3px 12px var(--st-shadow);flex:1;min-width:160px}
.st-age-card__label{font-weight:700;font-size:.88rem;display:block}
.st-age-card__age{font-size:.78rem;color:var(--st-mid);font-family:var(--st-ff2);font-weight:400}
.st-age-card__icon{font-size:1.6rem}

/* ── ABOUT ── */
.st-about{display:grid;grid-template-columns:1fr 1fr;gap:72px;align-items:center}
.st-about__figure{display:flex;justify-content:center}
.st-about__scene{width:300px;height:360px;border-radius:var(--st-r);background:linear-gradient(145deg,var(--st-light),#fff);box-shadow:0 8px 32px var(--st-shadow);position:relative;overflow:hidden;border:2px solid rgba(0,121,107,.12)}
.st-room-wall{position:absolute;top:0;left:0;right:0;height:55%;background:linear-gradient(180deg,#E8F5F3 0%,#D0EDE8 100%)}
.st-room-floor{position:absolute;bottom:0;left:0;right:0;height:47%;background:linear-gradient(180deg,#F5E6D0 0%,#E8D5B8 100%)}
.st-room-desk{position:absolute;bottom:35%;left:10%;right:10%;height:20px;background:#8D6E63;border-radius:4px;box-shadow:0 4px 8px rgba(0,0,0,.2)}
.st-room-screen{position:absolute;bottom:43%;left:50%;transform:translateX(-50%);width:50px;height:36px;background:#1A3A4A;border-radius:4px;border:3px solid #5C3A1A}
.st-room-screen-glow{width:100%;height:100%;background:linear-gradient(145deg,#29B6F6 0%,#00796B 100%);opacity:.7;border-radius:2px}
.st-room-therapist{position:absolute;bottom:52%;left:28%;display:flex;flex-direction:column;align-items:center}
.st-room-t-head{width:24px;height:26px;background:linear-gradient(160deg,#F5D5B0,#EEC298);border-radius:50%}
.st-room-t-body{width:28px;height:32px;background:var(--st-teal);border-radius:6px}
.st-room-t-legs{display:flex;gap:2px;margin-top:1px}
.st-room-t-leg{width:10px;height:18px;background:#2D4A5A;border-radius:3px}
.st-about__creds{margin-top:28px;display:flex;flex-direction:column;gap:12px}
.st-cred{display:flex;align-items:center;gap:12px;padding:13px 18px;border-radius:10px;background:var(--st-light);border-left:3px solid var(--st-teal)}
.st-cred__icon{font-size:1.2rem}
.st-cred__text{font-size:.88rem;font-weight:600;color:var(--st-deep)}

/* ── PROCESS ── */
.st-process{display:flex;flex-direction:column;gap:0}
.st-step{display:flex;gap:24px;padding:24px 0;border-bottom:1px solid rgba(0,121,107,.12)}
.st-step:last-child{border-bottom:none}
.st-step__num{flex-shrink:0;width:48px;height:48px;border-radius:50%;background:var(--st-teal);display:flex;align-items:center;justify-content:center;font-family:var(--st-ff);font-weight:700;font-size:.9rem;color:#fff}
.st-step__title{font-family:var(--st-ff);font-size:1rem;color:var(--st-deep);margin-bottom:5px}
.st-step__desc{font-size:.9rem;color:var(--st-mid)}

/* ── PACKAGES ── */
.st-packages{display:grid;grid-template-columns:repeat(3,1fr);gap:28px;margin-top:52px;align-items:start}
.st-pkg{border-radius:var(--st-r);padding:38px 28px;background:#fff;box-shadow:0 4px 20px var(--st-shadow);position:relative;transition:transform .25s}
.st-pkg:hover{transform:translateY(-4px)}
.st-pkg--sky{border-top:4px solid var(--st-sky)}
.st-pkg--teal{border-top:4px solid var(--st-teal)}
.st-pkg--deep{border-top:4px solid var(--st-deep)}
.st-pkg--featured{background:var(--st-teal);color:#fff;box-shadow:0 12px 40px rgba(0,121,107,.4);transform:scale(1.04)}
.st-pkg--featured:hover{transform:scale(1.04) translateY(-4px)}
.st-pkg--featured .st-pkg__name{color:#fff}
.st-pkg--featured .st-pkg__price{color:var(--st-amber)}
.st-pkg--featured .st-pkg__period,.st-pkg--featured .st-pkg__feature{color:rgba(255,255,255,.85)}
.st-pkg--featured .st-pkg__feature::before{color:var(--st-amber)}
.st-pkg__ribbon{position:absolute;top:-1px;right:22px;background:var(--st-amber);color:var(--st-deep);font-family:var(--st-ff);font-size:.7rem;font-weight:700;padding:5px 14px;border-radius:0 0 8px 8px}
.st-pkg__name{font-family:var(--st-ff);font-size:1.1rem;font-weight:700;color:var(--st-deep);margin-bottom:8px}
.st-pkg__price{font-family:var(--st-ff);font-size:2.4rem;font-weight:700;color:var(--st-teal);line-height:1}
.st-pkg__period{font-size:.82rem;color:var(--st-mid);margin-bottom:24px}
.st-pkg__features{list-style:none;display:flex;flex-direction:column;gap:9px;margin-bottom:28px}
.st-pkg__feature{font-size:.88rem;padding-left:20px;position:relative}
.st-pkg__feature::before{content:'✓';position:absolute;left:0;color:var(--st-teal);font-weight:700}
.st-pkg__btn{display:block;text-align:center;padding:13px;border-radius:99px;font-family:var(--st-ff);font-weight:700;font-size:.88rem;transition:opacity .2s;cursor:pointer;border:none}
.st-pkg--sky .st-pkg__btn{background:var(--st-sky);color:#fff}
.st-pkg--teal .st-pkg__btn{background:var(--st-amber);color:var(--st-deep)}
.st-pkg--deep .st-pkg__btn{background:var(--st-deep);color:#fff}
.st-pkg__btn:hover{opacity:.85}

/* ── INSURERS ── */
.st-insurers{display:flex;flex-wrap:wrap;gap:10px;margin-top:28px}
.st-insurer{padding:9px 18px;background:#fff;border-radius:8px;font-family:var(--st-ff);font-weight:700;font-size:.83rem;color:var(--st-teal);box-shadow:0 2px 8px var(--st-shadow);border:1px solid rgba(0,121,107,.12)}

/* ── TESTIMONIALS ── */
.st-testimonials{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:52px}
.st-testimonial{background:#fff;border-radius:var(--st-r);padding:28px;box-shadow:0 4px 16px var(--st-shadow);border-bottom:3px solid var(--st-teal)}
.st-testimonial__text{font-size:.9rem;line-height:1.72;color:var(--st-mid);margin-bottom:18px;font-style:italic}
.st-testimonial__name{font-family:var(--st-ff);font-weight:700;font-size:.9rem;color:var(--st-deep)}
.st-testimonial__context{font-size:.78rem;color:var(--st-mid)}
.st-stars{color:var(--st-amber);letter-spacing:2px;font-size:.85rem;margin-top:4px}

/* ── FAQs ── */
.st-faq-list{display:flex;flex-direction:column;gap:10px;margin-top:44px}
.st-faq{border:1px solid rgba(0,121,107,.18);border-radius:10px;overflow:hidden;background:#fff}
.st-faq__q{padding:18px 24px;font-family:var(--st-ff);font-size:.96rem;color:var(--st-deep);cursor:pointer;display:flex;justify-content:space-between;align-items:center;gap:16px}
.st-faq__q::after{content:'＋';font-size:1.2rem;color:var(--st-teal);flex-shrink:0;transition:transform .25s}
.st-faq.open .st-faq__q::after{transform:rotate(45deg)}
.st-faq__a{max-height:0;overflow:hidden;transition:max-height .35s ease}
.st-faq.open .st-faq__a{max-height:280px}
.st-faq__a-inner{padding:0 24px 18px;font-size:.9rem;color:var(--st-mid);line-height:1.72}

/* ── BOOKING ── */
.st-form-wrap{background:var(--st-deep);border-radius:var(--st-r);padding:52px 48px;box-shadow:0 12px 48px rgba(0,0,0,.25)}
.st-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}
.st-form-grid .st-fg--full{grid-column:1/-1}
.st-field label{display:block;font-size:.78rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:rgba(255,255,255,.6);margin-bottom:8px}
.st-field input,.st-field select,.st-field textarea{width:100%;padding:12px 16px;background:rgba(255,255,255,.08);border:1.5px solid rgba(255,255,255,.15);border-radius:8px;color:#fff;font-size:.93rem;font-family:var(--st-ff2);transition:border-color .2s}
.st-field input::placeholder,.st-field textarea::placeholder{color:rgba(255,255,255,.33)}
.st-field input:focus,.st-field select:focus,.st-field textarea:focus{outline:none;border-color:var(--st-sky)}
.st-field select option{background:var(--st-deep);color:#fff}
.st-field textarea{resize:vertical;min-height:90px}
.st-form-note{font-size:.78rem;color:rgba(255,255,255,.4);margin-top:10px}

/* ── CTA STRIP ── */
.st-cta-strip{background:var(--st-teal);padding:64px 0;text-align:center}
.st-cta-strip h2{font-family:var(--st-ff);font-size:2.2rem;color:#fff;margin-bottom:14px}
.st-cta-strip p{color:rgba(255,255,255,.82);margin-bottom:32px}

/* ── FOOTER ── */
.st-footer-strip{background:var(--st-deep);padding:26px 0;text-align:center}
.st-footer-strip p{color:rgba(255,255,255,.4);font-size:.83rem}

/* ── SECTION TITLES ── */
.st-section-title{font-family:var(--st-ff);font-size:clamp(1.8rem,3.5vw,2.5rem);color:var(--st-deep);margin-bottom:16px}
.st-section-sub{font-size:1.02rem;color:var(--st-mid);max-width:560px}

/* ── SCROLL REVEAL ── */
.st-reveal{opacity:0;transform:translateY(26px);transition:opacity .62s,transform .62s}
.st-reveal.visible{opacity:1;transform:none}

/* ── RESPONSIVE ── */
@media(max-width:900px){
  .st-counters{grid-template-columns:repeat(2,1fr)}
  .st-packages{grid-template-columns:1fr}
  .st-pkg--featured{transform:none}
  .st-about{grid-template-columns:1fr}
  .st-testimonials{grid-template-columns:1fr}
  .st-form-grid{grid-template-columns:1fr}
}
@media(max-width:600px){
  .st-section{padding:60px 0}
  .st-form-wrap{padding:32px 20px}
  .st-bubble{display:none}
}
</style>
<?php get_header(); ?>
<div class="st-page">
>
<?php wp_body_open(); ?>

<!-- ═══════════ HERO ═══════════ -->
<section class="st-hero" id="home">

  <!-- Soundwave bars -->
  <div class="st-wave">
    <?php
    for ( $i = 0; $i < $wave_bars; $i++ ) :
      $min  = rand( 12, 35 );
      $max  = rand( 40, 110 );
      $dur  = round( rand( 4, 10 ) / 10, 1 );
      $del  = round( $i * 0.06, 2 );
    ?>
    <div class="st-bar" style="width:7px;--wb-min:<?php echo $min; ?>px;--wb-max:<?php echo $max; ?>px;--wb-dur:<?php echo $dur; ?>s;--wb-d:<?php echo $del; ?>s"></div>
    <?php endfor; ?>
  </div>

  <!-- Speech bubbles -->
  <?php foreach ( $bubbles as $bb ) : ?>
  <div class="st-bubble" style="top:<?php echo $bb['top']; ?>%;left:<?php echo $bb['left']; ?>%;--bb-dur:<?php echo (3 + $bb['delay']); ?>s;--bb-d:<?php echo $bb['delay']; ?>s;--bb-sc:<?php echo $bb['size']; ?>"><?php echo esc_html( $bb['text'] ); ?></div>
  <?php endforeach; ?>

  <!-- Therapist figure -->
  <div class="st-figure">
    <div class="st-fig-head">
      <div class="st-fig-hair"></div>
      <div class="st-fig-face-eyes">
        <div class="st-fig-eye"></div>
        <div class="st-fig-eye"></div>
      </div>
      <div class="st-fig-smile"></div>
    </div>
    <div class="st-fig-body">
      <div class="st-fig-lanyard">ID</div>
      <div class="st-fig-arm-l"><div class="st-fig-hand"></div></div>
      <div class="st-fig-arm-r">
        <div class="st-fig-clipboard"></div>
        <div class="st-fig-hand"></div>
      </div>
    </div>
    <div class="st-fig-legs">
      <div>
        <div class="st-fig-leg"></div>
        <div class="st-fig-shoe"></div>
      </div>
      <div>
        <div class="st-fig-leg"></div>
        <div class="st-fig-shoe"></div>
      </div>
    </div>
  </div>

  <div class="st-wrap">
    <div class="st-hero__content">
      <p class="st-hero__eyebrow">MRCSLT Registered · Edinburgh & UK Telehealth</p>
      <h1 class="st-hero__title">
        <?php echo esc_html( $therapist['tagline'] ); ?><br>
        <span>Find Your Voice</span>
      </h1>
      <p class="st-hero__sub">
        Evidence-based speech and language therapy for children and adults — compassionate, person-centred and built around <em>your</em> goals.
      </p>
      <div class="st-hero__ctas">
        <a href="#booking" class="st-btn st-btn--primary">🗣 Book Free Consultation</a>
        <a href="#services" class="st-btn st-btn--ghost">Explore Services</a>
      </div>
      <div class="st-trust">
        <div class="st-trust-badge">
          <span class="st-trust-badge__icon">🏥</span>
          <div class="st-trust-badge__text"><strong>MRCSLT</strong>HCPC Registered</div>
        </div>
        <div class="st-trust-badge">
          <span class="st-trust-badge__icon">💻</span>
          <div class="st-trust-badge__text"><strong>Telehealth</strong>UK-Wide Sessions</div>
        </div>
        <div class="st-trust-badge">
          <span class="st-trust-badge__icon">🔬</span>
          <div class="st-trust-badge__text"><strong>Evidence-Based</strong>RCSLT Standards</div>
        </div>
        <div class="st-trust-badge">
          <span class="st-trust-badge__icon">💳</span>
          <div class="st-trust-badge__text"><strong>Insurance</strong>Bupa · AXA · Vitality</div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ COUNTERS ═══════════ -->
<section class="st-section st-section--alt">
  <div class="st-wrap">
    <div class="st-counters">
      <div class="st-counter st-reveal">
        <div class="st-counter__num" data-target="<?php echo $therapist['years']; ?>">0</div>
        <div class="st-counter__label">Years Clinical Experience</div>
      </div>
      <div class="st-counter st-reveal">
        <div class="st-counter__num" data-target="<?php echo $therapist['clients']; ?>" data-suffix="+">0</div>
        <div class="st-counter__label">Clients Supported</div>
      </div>
      <div class="st-counter st-reveal">
        <div class="st-counter__num" data-target="<?php echo $therapist['rating']; ?>" data-float="1" data-suffix="★">0</div>
        <div class="st-counter__label">Average Rating</div>
      </div>
      <div class="st-counter st-reveal">
        <div class="st-counter__num" data-target="<?php echo $therapist['success']; ?>" data-suffix="%">0</div>
        <div class="st-counter__label">Goal Achievement Rate</div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ SERVICES ═══════════ -->
<section class="st-section st-section--light" id="services">
  <div class="st-wrap">
    <div class="st-tag">Specialist Areas</div>
    <h2 class="st-section-title">Comprehensive Communication Support</h2>
    <p class="st-section-sub">Natalie provides specialist assessment and therapy across a wide range of speech, language, voice and swallowing difficulties.</p>
    <div class="st-services-grid">
      <?php foreach ( $services as $svc ) : ?>
      <div class="st-service-card st-reveal">
        <div class="st-service-card__icon"><?php echo $svc['icon']; ?></div>
        <h3 class="st-service-card__title"><?php echo esc_html( $svc['title'] ); ?></h3>
        <p class="st-service-card__desc"><?php echo esc_html( $svc['desc'] ); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════ AGE GROUPS ═══════════ -->
<section class="st-section st-section--alt">
  <div class="st-wrap">
    <div class="st-tag">Who I Work With</div>
    <h2 class="st-section-title">All Ages, All Stages</h2>
    <p class="st-section-sub">From infants showing early signs of delay to older adults managing communication after neurological illness.</p>
    <div class="st-age-groups">
      <?php foreach ( $age_groups as $ag ) : ?>
      <div class="st-age-card st-reveal" style="background:<?php echo $ag['colour']; ?>22;border:1.5px solid <?php echo $ag['colour']; ?>55">
        <div class="st-age-card__icon"><?php echo $ag['icon']; ?></div>
        <div>
          <span class="st-age-card__label"><?php echo esc_html( $ag['label'] ); ?></span>
          <span class="st-age-card__age"><?php echo esc_html( $ag['age'] ); ?></span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════ ABOUT ═══════════ -->
<section class="st-section st-section--light" id="about">
  <div class="st-wrap">
    <div class="st-about">
      <div class="st-about__figure">
        <div class="st-about__scene">
          <div class="st-room-wall"></div>
          <div class="st-room-floor"></div>
          <div class="st-room-desk"></div>
          <div class="st-room-screen"><div class="st-room-screen-glow"></div></div>
          <div class="st-room-therapist">
            <div class="st-room-t-head"></div>
            <div class="st-room-t-body"></div>
            <div class="st-room-t-legs">
              <div class="st-room-t-leg"></div>
              <div class="st-room-t-leg"></div>
            </div>
          </div>
          <div style="position:absolute;bottom:18px;left:0;right:0;text-align:center">
            <p style="font-family:var(--st-ff);font-size:.82rem;font-weight:700;color:var(--st-deep)"><?php echo esc_html( $therapist['name'] ); ?></p>
            <p style="font-size:.7rem;color:var(--st-mid)">MRCSLT · HCPC Registered</p>
          </div>
        </div>
      </div>
      <div>
        <div class="st-tag">Meet Your Therapist</div>
        <h2 class="st-section-title"><?php echo esc_html( $therapist['name'] ); ?></h2>
        <p style="font-size:.88rem;font-weight:700;color:var(--st-teal);margin-bottom:20px"><?php echo esc_html( $therapist['title'] ); ?></p>
        <p style="color:var(--st-mid);line-height:1.82;margin-bottom:18px"><?php echo esc_html( $therapist['bio'] ); ?></p>
        <p style="color:var(--st-mid);line-height:1.82;margin-bottom:28px"><?php echo esc_html( $therapist['bio2'] ); ?></p>
        <div class="st-about__creds">
          <div class="st-cred"><span class="st-cred__icon">🎓</span><span class="st-cred__text">PhD Communication Sciences, University of Edinburgh</span></div>
          <div class="st-cred"><span class="st-cred__icon">🏥</span><span class="st-cred__text">MRCSLT · HCPC Registered Practitioner (SL17256)</span></div>
          <div class="st-cred"><span class="st-cred__icon">🔬</span><span class="st-cred__text">Trained in PROMPT, Lidcombe, LSVT LOUD & Nuffield</span></div>
          <div class="st-cred"><span class="st-cred__icon">💳</span><span class="st-cred__text">Bupa · AXA · Vitality · WPA Recognised Provider</span></div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ PROCESS ═══════════ -->
<section class="st-section st-section--alt" id="process">
  <div class="st-wrap">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:72px;align-items:start">
      <div>
        <div class="st-tag">Your Journey</div>
        <h2 class="st-section-title">How Therapy Works</h2>
        <p class="st-section-sub" style="margin-bottom:36px">A structured, evidence-based pathway from initial concern to confident communication.</p>
        <div class="st-process">
          <?php foreach ( $steps as $s ) : ?>
          <div class="st-step st-reveal">
            <div class="st-step__num"><?php echo $s['num']; ?></div>
            <div>
              <div class="st-step__title"><?php echo esc_html( $s['title'] ); ?></div>
              <div class="st-step__desc"><?php echo esc_html( $s['desc'] ); ?></div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <div>
        <div class="st-tag">Insurance & Funding</div>
        <h2 class="st-section-title" style="font-size:1.7rem">Private Health Insurance Welcome</h2>
        <p style="color:var(--st-mid);margin-bottom:24px">Natalie is recognised by all major UK private health insurers. She provides full receipts and reports for reimbursement claims. EHCP-funded therapy also considered.</p>
        <div class="st-insurers">
          <?php
          $insurers = ['Bupa','AXA Health','Vitality','WPA','Aviva','Simply Health','Freedom Health','EHCP Funded','Self-Pay'];
          foreach ( $insurers as $ins ) : ?>
          <span class="st-insurer"><?php echo esc_html( $ins ); ?></span>
          <?php endforeach; ?>
        </div>
        <div style="margin-top:32px;padding:20px 24px;background:rgba(0,121,107,.08);border-radius:12px;border-left:4px solid var(--st-teal)">
          <p style="font-family:var(--st-ff);font-weight:700;color:var(--st-teal);margin-bottom:6px">Free 15-Minute Consultation</p>
          <p style="font-size:.88rem;color:var(--st-mid)">Natalie offers a complimentary 15-minute phone or video call before any assessment — so you can ask questions and decide if she's the right fit, with no obligation.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ PACKAGES ═══════════ -->
<section class="st-section st-section--light" id="packages">
  <div class="st-wrap">
    <div style="text-align:center;max-width:620px;margin:0 auto 8px">
      <div class="st-tag">Fees & Packages</div>
      <h2 class="st-section-title">Transparent, Inclusive Pricing</h2>
      <p class="st-section-sub" style="margin:0 auto">No hidden fees. All sessions include written notes and home practice activities.</p>
    </div>
    <div class="st-packages">
      <?php foreach ( $packages as $pkg ) : ?>
      <div class="st-pkg st-pkg--<?php echo $pkg['colour']; ?><?php echo $pkg['featured'] ? ' st-pkg--featured' : ''; ?> st-reveal">
        <?php if ( $pkg['featured'] ) : ?><div class="st-pkg__ribbon">⭐ Best Value</div><?php endif; ?>
        <div class="st-pkg__name"><?php echo esc_html( $pkg['name'] ); ?></div>
        <div class="st-pkg__price"><?php echo esc_html( $pkg['price'] ); ?></div>
        <div class="st-pkg__period"><?php echo esc_html( $pkg['period'] ); ?></div>
        <ul class="st-pkg__features">
          <?php foreach ( $pkg['features'] as $feat ) : ?>
          <li class="st-pkg__feature"><?php echo esc_html( $feat ); ?></li>
          <?php endforeach; ?>
        </ul>
        <a href="#booking" class="st-pkg__btn">Book <?php echo esc_html( $pkg['name'] ); ?></a>
      </div>
      <?php endforeach; ?>
    </div>
    <p style="text-align:center;margin-top:24px;font-size:.86rem;color:var(--st-mid)">Concessions available for NHS staff, students and families on low income. Please enquire.</p>
  </div>
</section>

<!-- ═══════════ TESTIMONIALS ═══════════ -->
<section class="st-section st-section--alt">
  <div class="st-wrap">
    <div class="st-tag">Testimonials</div>
    <h2 class="st-section-title">What Families & Clients Say</h2>
    <div class="st-testimonials">
      <?php
      $testimonials = [
        [ 'text' => '"After years of struggling with a stammer, I finally feel like I have tools that actually work. Natalie\'s approach was never about \'fixing\' me — she helped me redefine my relationship with my voice. I can\'t recommend her highly enough."', 'name' => 'Thomas A., 34', 'context' => 'Fluency Therapy Client' ],
        [ 'text' => '"Our daughter was nearly 3 and barely speaking. Within 8 sessions with Natalie, she was putting words together and her confidence had completely transformed. The home programme was so easy to follow — it fitted around family life perfectly."', 'name' => 'Sarah & Mark B.', 'context' => 'Parents of child client, age 2.5' ],
        [ 'text' => '"Following my stroke, Natalie was recommended by my consultant. Her aphasia therapy was patient, creative and genuinely fun at times. Six months later I\'m back presenting at work. The progress felt impossible at the start — she believed when I couldn\'t."', 'name' => 'Dr. Janet P., 58', 'context' => 'Post-Stroke Aphasia Therapy' ],
      ];
      foreach ( $testimonials as $t ) : ?>
      <div class="st-testimonial st-reveal">
        <p class="st-testimonial__text"><?php echo esc_html( $t['text'] ); ?></p>
        <div class="st-testimonial__name"><?php echo esc_html( $t['name'] ); ?></div>
        <div class="st-testimonial__context"><?php echo esc_html( $t['context'] ); ?></div>
        <div class="st-stars">★★★★★</div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════ FAQs ═══════════ -->
<section class="st-section st-section--light" id="faq">
  <div class="st-wrap">
    <div style="max-width:760px;margin:0 auto">
      <div class="st-tag">FAQs</div>
      <h2 class="st-section-title">Common Questions</h2>
      <div class="st-faq-list">
        <?php foreach ( $faqs as $faq ) : ?>
        <div class="st-faq">
          <div class="st-faq__q"><?php echo esc_html( $faq['q'] ); ?></div>
          <div class="st-faq__a"><div class="st-faq__a-inner"><?php echo esc_html( $faq['a'] ); ?></div></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ CTA STRIP ═══════════ -->
<div class="st-cta-strip">
  <div class="st-wrap">
    <h2>Take the First Step Today</h2>
    <p>A free 15-minute call costs nothing and could change everything.</p>
    <a href="#booking" class="st-btn st-btn--primary" style="background:#fff;color:var(--st-teal)">🗣 Book Free 15-Min Call</a>
  </div>
</div>

<!-- ═══════════ BOOKING ═══════════ -->
<section class="st-section st-section--alt" id="booking">
  <div class="st-wrap">
    <div style="max-width:800px;margin:0 auto">
      <div class="st-tag">Book Now</div>
      <h2 class="st-section-title">Start Your Journey</h2>
      <p style="color:var(--st-mid);margin-bottom:40px">Fill in the form and Natalie will respond within 24 hours to arrange your free discovery call or book your initial assessment.</p>
      <div class="st-form-wrap">
        <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
          <?php wp_nonce_field( 'tf_st_booking', 'tf_st_nonce' ); ?>
          <input type="hidden" name="action" value="tf_st_booking">
          <div class="st-form-grid">
            <div class="st-field">
              <label for="st-name">Your Name *</label>
              <input type="text" id="st-name" name="name" placeholder="Your full name" required>
            </div>
            <div class="st-field">
              <label for="st-email">Email Address *</label>
              <input type="email" id="st-email" name="email" placeholder="you@example.com" required>
            </div>
            <div class="st-field">
              <label for="st-phone">Phone Number</label>
              <input type="tel" id="st-phone" name="phone" placeholder="+44 7700 000000">
            </div>
            <div class="st-field">
              <label for="st-client-type">Booking For *</label>
              <select id="st-client-type" name="client_type" required>
                <option value="" disabled selected>Who needs support?</option>
                <option>Myself (adult)</option>
                <option>My child</option>
                <option>A family member</option>
                <option>A patient (professional referral)</option>
              </select>
            </div>
            <div class="st-field">
              <label for="st-client-age">Client's Age Group</label>
              <select id="st-client-age" name="client_age">
                <option value="" disabled selected>Age group</option>
                <option>Infant / Toddler (0–3)</option>
                <option>Pre-School (3–5)</option>
                <option>School Age (5–16)</option>
                <option>Young Adult (16–25)</option>
                <option>Adult (25–64)</option>
                <option>Older Adult (65+)</option>
              </select>
            </div>
            <div class="st-field">
              <label for="st-concern">Primary Concern *</label>
              <select id="st-concern" name="concern" required>
                <option value="" disabled selected>Main area of concern</option>
                <option>Speech Delay / Difficulty</option>
                <option>Language Development</option>
                <option>Stuttering / Stammering</option>
                <option>Voice Problems</option>
                <option>Aphasia (post-stroke/ABI)</option>
                <option>Swallowing Difficulty</option>
                <option>Selective Mutism</option>
                <option>Autism / Social Communication</option>
                <option>Professional Communication</option>
                <option>Other / Not Sure</option>
              </select>
            </div>
            <div class="st-field">
              <label for="st-format">Preferred Format</label>
              <select id="st-format" name="format">
                <option value="" disabled selected>How would you like to meet?</option>
                <option>In-person (Edinburgh clinic)</option>
                <option>Home visit (Lothians)</option>
                <option>Online / Telehealth</option>
                <option>Either works for me</option>
              </select>
            </div>
            <div class="st-field">
              <label for="st-funding">Funding Type</label>
              <select id="st-funding" name="funding">
                <option value="" disabled selected>How will you fund therapy?</option>
                <option>Self-funding</option>
                <option>Bupa</option>
                <option>AXA Health</option>
                <option>Vitality</option>
                <option>WPA</option>
                <option>Other insurer</option>
                <option>EHCP / Local Authority</option>
                <option>Not sure yet</option>
              </select>
            </div>
            <div class="st-field st-fg--full">
              <label for="st-notes">Tell Me About Your Concerns</label>
              <textarea id="st-notes" name="notes" placeholder="Please share any relevant background — when you first noticed concerns, any previous assessments or therapy, current goals and anything else that would help me prepare..."></textarea>
            </div>
          </div>
          <div style="margin-top:24px">
            <button type="submit" class="st-btn st-btn--primary" style="width:100%;justify-content:center;font-size:1rem;padding:16px">🗣 Send Enquiry</button>
          </div>
          <p class="st-form-note">Natalie responds within 24 hours. All information is held securely in accordance with GDPR and RCSLT professional guidelines.</p>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════ FOOTER ═══════════ -->
<div class="st-footer-strip">
  <div class="st-wrap">
    <p>🗣 <?php echo esc_html( $therapist['name'] ); ?> · <?php echo esc_html( $therapist['title'] ); ?> · <?php echo esc_html( $therapist['location'] ); ?> · <?php echo date('Y'); ?></p>
  </div>
</div>

<script>
(function () {
  'use strict';

  /* ── Counters ──────────────────────────────────────────────────── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  const DURATION = 1800;
  function animateCounter(el) {
    const raw     = parseFloat(el.dataset.target);
    if (isNaN(raw)) return;
    const isFloat = el.dataset.float === '1';
    const suffix  = el.dataset.suffix || '';
    const start   = performance.now();
    (function tick(now) {
      const p   = Math.min((now - start) / DURATION, 1);
      const val = raw * easeOut(p);
      el.textContent = (isFloat ? val.toFixed(1) : Math.floor(val)) + suffix;
      if (p < 1) requestAnimationFrame(tick);
    })(start);
  }
  const cObs = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) { animateCounter(e.target); cObs.unobserve(e.target); } });
  }, { threshold: 0.5 });
  document.querySelectorAll('.st-counter__num[data-target]').forEach(el => cObs.observe(el));

  /* ── FAQ ─────────────────────────────────────────────────────── */
  document.querySelectorAll('.st-faq__q').forEach(q => {
    q.addEventListener('click', () => {
      const faq  = q.closest('.st-faq');
      const open = faq.classList.contains('open');
      document.querySelectorAll('.st-faq.open').forEach(f => f.classList.remove('open'));
      if (!open) faq.classList.add('open');
    });
  });

  /* ── Reveal ───────────────────────────────────────────────────── */
  const rObs = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); rObs.unobserve(e.target); } });
  }, { threshold: 0.12 });
  document.querySelectorAll('.st-reveal').forEach(el => rObs.observe(el));

  /* ── Smooth scroll ─────────────────────────────────────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const t = document.querySelector(a.getAttribute('href'));
      if (t) { e.preventDefault(); t.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    });
  });
})();
</script>

</body>
</html>
</div><!-- .st-page -->
<?php get_footer(); ?>
