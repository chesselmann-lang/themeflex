<?php
/**
 * Template Name: Sports Club Homepage
 * Template Post Type: page
 *
 * ThemeFlex – ThemeFlex: Athletic / Football Club
 * Namespace : --sp-*
 * Fonts     : Barlow Condensed (display) + Barlow (body)
 * Palette   : Pitch #0A1A0A / Scarlet #E8001D / Gold #FFD700 / Steel #334155 / Snow #F8FAFC
 */
defined('ABSPATH') || exit;
get_header();

/* ── Palette ─────────────────────────────────────────────── */
$sp_pitch  = '#0A1A0A';
$sp_scarlet= '#E8001D';
$sp_gold   = '#FFD700';
$sp_steel  = '#334155';
$sp_snow   = '#F8FAFC';
$sp_mid    = '#1E2E1E';
$sp_slate  = '#64748B';

/* ── Deterministic randomness ─────────────────────────────── */
srand(crc32('sp-sports-club'));

/* ── Match fixtures ─────────────────────────────────────── */
$sp_matches = [
  ['date'=>'4 May 2026','time'=>'15:00','home'=>'Ravenswood FC','away'=>'Thornton City','venue'=>'Ravenswood Arena','comp'=>'League','result'=>null,'status'=>'upcoming'],
  ['date'=>'10 May 2026','time'=>'17:30','home'=>'Blackmere Utd','away'=>'Ravenswood FC','venue'=>'Blackmere Ground','comp'=>'Cup SF','result'=>null,'status'=>'upcoming'],
  ['date'=>'26 Apr 2026','time'=>'15:00','home'=>'Ravenswood FC','away'=>'Millport Athletic','venue'=>'Ravenswood Arena','comp'=>'League','result'=>'3–1','status'=>'win'],
  ['date'=>'19 Apr 2026','time'=>'14:00','home'=>'Cresthill FC','away'=>'Ravenswood FC','venue'=>'Cresthill Park','comp'=>'League','result'=>'2–2','status'=>'draw'],
  ['date'=>'12 Apr 2026','time'=>'15:00','home'=>'Ravenswood FC','away'=>'Dunford Vale','venue'=>'Ravenswood Arena','comp'=>'League','result'=>'1–0','status'=>'win'],
];

/* ── League table (top 5) ────────────────────────────────── */
$sp_table = [
  ['pos'=>1,'team'=>'Ravenswood FC','p'=>34,'w'=>22,'d'=>7,'l'=>5,'gd'=>'+38','pts'=>73,'us'=>true],
  ['pos'=>2,'team'=>'Blackmere Utd','p'=>34,'w'=>20,'d'=>8,'l'=>6,'gd'=>'+29','pts'=>68,'us'=>false],
  ['pos'=>3,'team'=>'Cresthill FC','p'=>34,'w'=>19,'d'=>6,'l'=>9,'gd'=>'+18','pts'=>63,'us'=>false],
  ['pos'=>4,'team'=>'Thornton City','p'=>34,'w'=>16,'d'=>9,'l'=>9,'gd'=>'+11','pts'=>57,'us'=>false],
  ['pos'=>5,'team'=>'Dunford Vale','p'=>34,'w'=>15,'d'=>8,'l'=>11,'gd'=>'+5','pts'=>53,'us'=>false],
];

/* ── Squad ───────────────────────────────────────────────── */
$sp_players = [
  ['name'=>'Kai Osei','pos'=>'GK','no'=>1,'caps'=>28,'goals'=>0,'skin'=>'#8B6040','hair'=>'#0A0404'],
  ['name'=>'Luca Ferretti','pos'=>'RB','no'=>2,'caps'=>42,'goals'=>3,'skin'=>'#C8906A','hair'=>'#2C1A0A'],
  ['name'=>'Aleksei Voronov','pos'=>'CB','no'=>5,'caps'=>56,'goals'=>8,'skin'=>'#D4B090','hair'=>'#3A2010'],
  ['name'=>'Thomas Adeyemi','pos'=>'CB','no'=>6,'caps'=>31,'goals'=>4,'skin'=>'#9B7055','hair'=>'#0E0808'],
  ['name'=>'Javier Reyes','pos'=>'LB','no'=>3,'caps'=>44,'goals'=>5,'skin'=>'#C09060','hair'=>'#1A0C08'],
  ['name'=>'Mikael Strand','pos'=>'CM','no'=>8,'caps'=>62,'goals'=>12,'skin'=>'#D4A882','hair'=>'#382010'],
  ['name'=>'Deon Clarke','pos'=>'CM','no'=>14,'caps'=>38,'goals'=>9,'skin'=>'#A07050','hair'=>'#0A0808'],
  ['name'=>'Hiroshi Tanaka','pos'=>'CAM','no'=>10,'caps'=>71,'goals'=>24,'skin'=>'#C4966A','hair'=>'#1A0C08'],
  ['name'=>'Marcus Webb','pos'=>'RW','no'=>7,'caps'=>33,'goals'=>18,'skin'=>'#C8906A','hair'=>'#2A1408'],
  ['name'=>'Oumar Diallo','pos'=>'LW','no'=>11,'caps'=>29,'goals'=>14,'skin'=>'#7A5035','hair'=>'#060404'],
  ['name'=>'Finley Hart','pos'=>'ST','no'=>9,'caps'=>88,'goals'=>54,'skin'=>'#C0845A','hair'=>'#281408'],
];

/* ── Season stats ────────────────────────────────────────── */
$sp_stats = [
  ['n'=>'1st','l'=>'League Position'],
  ['n'=>'54','l'=>'Goals Scored'],
  ['n'=>'73','l'=>'Points'],
  ['n'=>'22','l'=>'Wins'],
];
?>
<!-- GLOBAL CSS ──────────────────────────────────────────── -->
<style>
@import url('https://fonts.googleapis.com/css2?family=Barlow+Condensed:ital,wght@0,400;0,600;0,700;0,800;1,700&family=Barlow:wght@300;400;500;600&display=swap');
:root{
  --sp-pitch:<?php echo $sp_pitch; ?>;
  --sp-scarlet:<?php echo $sp_scarlet; ?>;
  --sp-gold:<?php echo $sp_gold; ?>;
  --sp-steel:<?php echo $sp_steel; ?>;
  --sp-snow:<?php echo $sp_snow; ?>;
}
.sp-page{font-family:'Barlow',system-ui,sans-serif;background:var(--sp-pitch);color:var(--sp-snow);line-height:1.6;margin:0;}
.sp-container{max-width:1200px;margin:0 auto;padding:0 2rem;}
.sp-section{padding:5.5rem 0;}
.sp-reveal{opacity:0;transform:translateY(20px);transition:opacity .6s ease,transform .6s ease;}
.sp-reveal.sp-visible{opacity:1;transform:none;}
.sp-eyebrow{font-family:'Barlow Condensed',sans-serif;font-size:.75rem;font-weight:600;letter-spacing:.28em;text-transform:uppercase;color:var(--sp-gold);margin-bottom:.6rem;}
/* Match result dots */
.sp-result--win{background:var(--sp-gold);color:var(--sp-pitch);}
.sp-result--draw{background:var(--sp-steel);color:#fff;}
.sp-result--loss{background:var(--sp-scarlet);color:#fff;}
/* Player card */
.sp-player{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:4px;overflow:hidden;transition:border-color .3s,transform .3s ease;}
.sp-player:hover{border-color:rgba(232,0,29,.3);transform:translateY(-3px);}
/* Kit strip colours */
.sp-kit-top{background:linear-gradient(180deg,var(--sp-scarlet) 0%,var(--sp-scarlet) 50%,#900010 100%);}
</style>

<div class="sp-page">

  <!-- HERO ─────────────────────────────────────────────────── -->
  <section style="min-height:100vh;position:relative;display:flex;flex-direction:column;justify-content:flex-end;overflow:hidden;background:var(--sp-pitch);" aria-labelledby="sp-hero-title">

    <!-- Stadium crowd atmosphere -->
    <div aria-hidden="true" style="position:absolute;inset:0;background:radial-gradient(ellipse at 50% 30%,rgba(232,0,29,.06) 0%,transparent 60%);"></div>

    <!-- CSS Stadium / Pitch Scene ───────────────────────── -->
    <div aria-hidden="true" style="position:absolute;top:0;left:0;right:0;height:72%;overflow:hidden;">

      <!-- Night sky -->
      <div style="position:absolute;inset:0;background:linear-gradient(180deg,#020A02 0%,#041204 60%,#0A1A0A 100%);"></div>

      <!-- Stars -->
      <?php for($s=0;$s<40;$s++) echo '<div style="position:absolute;left:'.rand(0,100).'%;top:'.rand(0,40).'%;width:'.rand(1,2).'px;height:'.rand(1,2).'px;background:#fff;border-radius:50%;opacity:'.rand(2,6)/10.';"></div>'; ?>

      <!-- Pitch markings -->
      <!-- Main pitch -->
      <div style="position:absolute;bottom:0;left:10%;right:10%;height:50%;background:#1A4A1A;border:2px solid rgba(255,255,255,.2);"></div>
      <!-- Centre circle -->
      <div style="position:absolute;bottom:25%;left:50%;transform:translateX(-50%);width:14%;aspect-ratio:1;border-radius:50%;border:2px solid rgba(255,255,255,.2);background:transparent;"></div>
      <!-- Centre spot -->
      <div style="position:absolute;bottom:25%;left:50%;transform:translate(-50%,-50%) translateY(50%);width:6px;height:6px;border-radius:50%;background:rgba(255,255,255,.3);"></div>
      <!-- Halfway line -->
      <div style="position:absolute;bottom:0;left:10%;right:10%;height:50%;border-right:2px solid rgba(255,255,255,.15);"></div>
      <!-- Penalty areas (simplified) -->
      <div style="position:absolute;bottom:0;left:28%;width:22%;height:22%;border:2px solid rgba(255,255,255,.2);border-bottom:none;background:transparent;"></div>
      <div style="position:absolute;bottom:0;right:28%;width:22%;height:22%;border:2px solid rgba(255,255,255,.2);border-bottom:none;background:transparent;"></div>

      <!-- Floodlights -->
      <?php foreach([-42,-14,14,42] as $fl): ?>
      <div style="position:absolute;bottom:50%;left:calc(50% + <?php echo $fl; ?>%);width:4px;height:100px;background:#2A2A2A;transform-origin:bottom center;"></div>
      <div style="position:absolute;bottom:calc(50% + 100px);left:calc(50% + <?php echo $fl; ?>% - 15px);width:34px;height:8px;background:#333;border-radius:2px;box-shadow:0 0 30px rgba(255,230,150,.6),0 0 80px rgba(255,230,150,.2);"></div>
      <?php endforeach; ?>

      <!-- Stadium stand silhouette (left) -->
      <div style="position:absolute;bottom:50%;left:0;width:12%;height:60%;background:linear-gradient(180deg,#111 0%,#0A0A0A 100%);clip-path:polygon(0 100%,100% 100%,100% 40%,80% 20%,60% 10%,40% 5%,20% 3%,0 4%);"></div>
      <!-- Stadium stand silhouette (right) -->
      <div style="position:absolute;bottom:50%;right:0;width:12%;height:60%;background:linear-gradient(180deg,#111 0%,#0A0A0A 100%);clip-path:polygon(100% 100%,0 100%,0 40%,20% 20%,40% 10%,60% 5%,80% 3%,100% 4%);"></div>

      <!-- Crowd lights (phone torches effect) -->
      <div style="position:absolute;bottom:50%;left:0;right:0;height:60%;background:repeating-linear-gradient(90deg,transparent,transparent 14px,rgba(255,255,200,.01) 14px,rgba(255,255,200,.01) 15px);opacity:.6;"></div>

      <!-- Pitch floodlight glow on grass -->
      <div style="position:absolute;bottom:0;left:10%;right:10%;height:50%;background:radial-gradient(ellipse at 50% 0%,rgba(255,230,150,.08) 0%,transparent 70%);pointer-events:none;"></div>
    </div>

    <!-- Hero Content -->
    <div class="sp-container" style="position:relative;z-index:2;padding-bottom:5rem;">
      <div style="max-width:700px;">
        <div style="display:inline-flex;align-items:center;gap:.6rem;background:rgba(232,0,29,.15);border:1px solid rgba(232,0,29,.3);border-radius:2px;padding:.3rem .85rem;margin-bottom:1.5rem;">
          <span style="font-family:'Barlow Condensed',sans-serif;font-size:.72rem;font-weight:600;letter-spacing:.18em;text-transform:uppercase;color:var(--sp-scarlet);">Season 2025/26</span>
        </div>
        <h1 id="sp-hero-title" style="font-family:'Barlow Condensed',sans-serif;font-size:clamp(4rem,10vw,9rem);font-weight:800;color:#ffffff;line-height:.9;letter-spacing:-.02em;margin:0 0 1rem;text-transform:uppercase;">Ravenswood<br><span style="color:var(--sp-scarlet);">FC</span></h1>
        <p style="font-family:'Barlow',sans-serif;font-size:1rem;color:rgba(248,250,252,.55);max-width:480px;line-height:1.75;margin:0 0 2.5rem;">Founded 1887. Playing beautiful football in front of the best supporters in the division. This is Ravenswood.</p>
        <div style="display:flex;gap:1rem;flex-wrap:wrap;">
          <a href="<?php echo esc_url(home_url('/tickets')); ?>" style="display:inline-block;padding:.9rem 2.25rem;background:var(--sp-scarlet);color:#ffffff;font-family:'Barlow Condensed',sans-serif;font-size:.85rem;font-weight:700;letter-spacing:.18em;text-transform:uppercase;text-decoration:none;border-radius:2px;">Buy Tickets</a>
          <a href="<?php echo esc_url(home_url('/fixtures')); ?>" style="display:inline-block;padding:.9rem 2.25rem;border:1px solid rgba(255,255,255,.15);color:rgba(248,250,252,.75);font-family:'Barlow Condensed',sans-serif;font-size:.85rem;font-weight:600;letter-spacing:.18em;text-transform:uppercase;text-decoration:none;border-radius:2px;">Fixtures</a>
        </div>
      </div>
    </div>

    <!-- Bottom gradient -->
    <div aria-hidden="true" style="position:absolute;bottom:0;left:0;right:0;height:180px;background:linear-gradient(0deg,var(--sp-pitch) 0%,transparent 100%);pointer-events:none;"></div>
  </section>

  <!-- SEASON STATS BAR ────────────────────────────────────── -->
  <div style="background:var(--sp-scarlet);padding:0;">
    <div class="sp-container">
      <div style="display:grid;grid-template-columns:repeat(4,1fr);">
        <?php foreach($sp_stats as $si=>$st): ?>
        <div class="sp-reveal" style="transition-delay:<?php echo $si*60; ?>ms;text-align:center;padding:2rem 1rem;border-left:<?php echo $si===0?'none':'1px solid rgba(255,255,255,.15)'; ?>;">
          <p style="font-family:'Barlow Condensed',sans-serif;font-size:2.5rem;font-weight:800;color:#ffffff;margin:0 0 .15rem;line-height:1;"><?php echo esc_html($st['n']); ?></p>
          <p style="font-family:'Barlow',sans-serif;font-size:.7rem;letter-spacing:.16em;text-transform:uppercase;color:rgba(255,255,255,.7);margin:0;"><?php echo esc_html($st['l']); ?></p>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- FIXTURES & RESULTS ──────────────────────────────────── -->
  <section class="sp-section" style="background:var(--sp-mid);" aria-labelledby="sp-fixtures-title">
    <div class="sp-container">
      <div style="display:grid;grid-template-columns:1.5fr 1fr;gap:4rem;align-items:start;">
        <!-- Fixtures -->
        <div>
          <div class="sp-reveal" style="margin-bottom:2.5rem;">
            <p class="sp-eyebrow">Schedule</p>
            <h2 id="sp-fixtures-title" style="font-family:'Barlow Condensed',sans-serif;font-size:clamp(2.5rem,4vw,3.5rem);font-weight:800;color:#ffffff;margin:0;text-transform:uppercase;letter-spacing:-.01em;">Fixtures &amp; Results</h2>
          </div>
          <?php foreach($sp_matches as $mi=>$m): ?>
          <div class="sp-reveal" style="transition-delay:<?php echo $mi*60; ?>ms;display:grid;grid-template-columns:90px 1fr auto;gap:1rem;align-items:center;padding:1.25rem 0;border-bottom:1px solid rgba(255,255,255,.07);">
            <div>
              <p style="font-family:'Barlow Condensed',sans-serif;font-size:.85rem;font-weight:600;color:#ffffff;margin:0;"><?php echo esc_html($m['date']); ?></p>
              <p style="font-family:'Barlow',sans-serif;font-size:.7rem;color:var(--sp-slate);margin:0;"><?php echo esc_html($m['time']); ?></p>
            </div>
            <div>
              <div style="display:flex;align-items:center;gap:.5rem;margin-bottom:.25rem;">
                <span style="font-family:'Barlow Condensed',sans-serif;font-size:1rem;font-weight:700;color:#ffffff;"><?php echo esc_html($m['home']); ?></span>
                <span style="font-size:.72rem;color:var(--sp-slate);">vs</span>
                <span style="font-family:'Barlow Condensed',sans-serif;font-size:1rem;font-weight:700;color:#ffffff;"><?php echo esc_html($m['away']); ?></span>
              </div>
              <div style="display:flex;align-items:center;gap:.6rem;">
                <span style="font-family:'Barlow',sans-serif;font-size:.7rem;color:var(--sp-slate);"><?php echo esc_html($m['venue']); ?></span>
                <span style="font-size:.62rem;border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.4);padding:.1rem .4rem;border-radius:2px;font-family:'Barlow Condensed',sans-serif;letter-spacing:.08em;"><?php echo esc_html($m['comp']); ?></span>
              </div>
            </div>
            <div style="text-align:right;">
              <?php if($m['result']): ?>
              <span style="font-family:'Barlow Condensed',sans-serif;font-size:1.1rem;font-weight:700;color:#ffffff;"><?php echo esc_html($m['result']); ?></span>
              <span class="sp-result--<?php echo esc_attr($m['status']); ?>" style="display:block;font-family:'Barlow Condensed',sans-serif;font-size:.6rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;padding:.15rem .5rem;border-radius:2px;margin-top:.2rem;"><?php echo strtoupper($m['status']); ?></span>
              <?php else: ?>
              <a href="<?php echo esc_url(home_url('/tickets')); ?>" style="display:inline-block;padding:.5rem 1rem;background:var(--sp-gold);color:var(--sp-pitch);font-family:'Barlow Condensed',sans-serif;font-size:.7rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;text-decoration:none;border-radius:2px;">Tickets</a>
              <?php endif; ?>
            </div>
          </div>
          <?php endforeach; ?>
          <div class="sp-reveal" style="margin-top:1.5rem;">
            <a href="<?php echo esc_url(home_url('/fixtures')); ?>" style="font-family:'Barlow Condensed',sans-serif;font-size:.8rem;font-weight:600;letter-spacing:.15em;text-transform:uppercase;color:var(--sp-gold);text-decoration:none;border-bottom:1px solid rgba(255,215,0,.3);padding-bottom:2px;">Full Fixture List &#8594;</a>
          </div>
        </div>

        <!-- League table -->
        <div class="sp-reveal" style="transition-delay:150ms;">
          <p class="sp-eyebrow">Standing</p>
          <h3 style="font-family:'Barlow Condensed',sans-serif;font-size:2rem;font-weight:800;color:#ffffff;margin:0 0 2rem;text-transform:uppercase;">League Table</h3>
          <table style="width:100%;border-collapse:collapse;" role="table" aria-label="League table top 5">
            <thead>
              <tr style="border-bottom:1px solid rgba(255,255,255,.12);">
                <th style="font-family:'Barlow',sans-serif;font-size:.65rem;letter-spacing:.16em;text-transform:uppercase;color:var(--sp-slate);text-align:left;padding-bottom:.75rem;font-weight:500;">#</th>
                <th style="font-family:'Barlow',sans-serif;font-size:.65rem;letter-spacing:.16em;text-transform:uppercase;color:var(--sp-slate);text-align:left;padding-bottom:.75rem;font-weight:500;">Club</th>
                <th style="font-family:'Barlow',sans-serif;font-size:.65rem;letter-spacing:.16em;text-transform:uppercase;color:var(--sp-slate);text-align:center;padding-bottom:.75rem;font-weight:500;">P</th>
                <th style="font-family:'Barlow',sans-serif;font-size:.65rem;letter-spacing:.16em;text-transform:uppercase;color:var(--sp-slate);text-align:center;padding-bottom:.75rem;font-weight:500;">GD</th>
                <th style="font-family:'Barlow',sans-serif;font-size:.65rem;letter-spacing:.16em;text-transform:uppercase;color:var(--sp-slate);text-align:center;padding-bottom:.75rem;font-weight:500;">Pts</th>
              </tr>
            </thead>
            <tbody>
            <?php foreach($sp_table as $row): ?>
            <tr style="border-bottom:1px solid rgba(255,255,255,.05);<?php echo $row['us']?'background:rgba(232,0,29,.08);':''; ?>">
              <td style="padding:.9rem 0;font-family:'Barlow Condensed',sans-serif;font-size:.9rem;color:<?php echo $row['us']?'var(--sp-gold)':'var(--sp-slate)'; ?>;font-weight:<?php echo $row['us']?'700':'400'; ?>;"><?php echo esc_html($row['pos']); ?></td>
              <td style="padding:.9rem .5rem;font-family:'Barlow Condensed',sans-serif;font-size:.95rem;font-weight:<?php echo $row['us']?'700':'400'; ?>;color:#ffffff;"><?php echo esc_html($row['team']); ?><?php if($row['us']) echo ' <span style="color:var(--sp-scarlet);font-size:.65rem;">●</span>'; ?></td>
              <td style="padding:.9rem 0;text-align:center;font-size:.85rem;color:var(--sp-slate);"><?php echo esc_html($row['p']); ?></td>
              <td style="padding:.9rem 0;text-align:center;font-size:.85rem;color:<?php echo strpos($row['gd'],'+')?'#4ADE80':'var(--sp-slate)'; ?>;"><?php echo esc_html($row['gd']); ?></td>
              <td style="padding:.9rem 0;text-align:center;font-family:'Barlow Condensed',sans-serif;font-size:1rem;font-weight:700;color:<?php echo $row['us']?'var(--sp-gold)':'#ffffff'; ?>;"><?php echo esc_html($row['pts']); ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
          <div style="margin-top:1.5rem;padding-top:1.25rem;border-top:1px solid rgba(255,255,255,.07);display:flex;align-items:center;gap:.5rem;">
            <span style="width:10px;height:10px;border-radius:50%;background:var(--sp-scarlet);flex-shrink:0;"></span>
            <span style="font-size:.72rem;color:var(--sp-slate);">Ravenswood FC</span>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- SQUAD ───────────────────────────────────────────────── -->
  <section class="sp-section" style="background:var(--sp-pitch);" aria-labelledby="sp-squad-title">
    <div class="sp-container">
      <div class="sp-reveal" style="margin-bottom:3.5rem;display:flex;align-items:flex-end;justify-content:space-between;flex-wrap:wrap;gap:1.5rem;">
        <div>
          <p class="sp-eyebrow">2025/26 Season</p>
          <h2 id="sp-squad-title" style="font-family:'Barlow Condensed',sans-serif;font-size:clamp(3rem,5vw,4.5rem);font-weight:800;color:#ffffff;margin:0;text-transform:uppercase;letter-spacing:-.01em;">The Squad</h2>
        </div>
        <a href="<?php echo esc_url(home_url('/squad')); ?>" style="padding:.75rem 1.75rem;border:1px solid rgba(255,255,255,.12);color:rgba(248,250,252,.6);font-family:'Barlow Condensed',sans-serif;font-size:.8rem;font-weight:600;letter-spacing:.16em;text-transform:uppercase;text-decoration:none;border-radius:2px;">Full Squad</a>
      </div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;">
        <?php foreach($sp_players as $pli=>$pl): if($pli>=8) break; ?>
        <article class="sp-player sp-reveal" style="transition-delay:<?php echo $pli*60; ?>ms;">
          <!-- Kit / figure -->
          <div style="aspect-ratio:.75;background:linear-gradient(180deg,var(--sp-mid) 0%,var(--sp-pitch) 100%);position:relative;overflow:hidden;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;padding-bottom:1rem;">
            <!-- Kit top -->
            <div style="position:absolute;top:30%;left:50%;transform:translateX(-50%);width:54px;height:58px;background:linear-gradient(180deg,#E8001D 0%,#900010 100%);border-radius:4px 4px 0 0;"></div>
            <!-- Shirt number -->
            <div aria-hidden="true" style="position:absolute;top:38%;left:calc(50% - 8px);width:16px;font-family:'Barlow Condensed',sans-serif;font-size:.75rem;font-weight:800;color:rgba(255,255,255,.5);text-align:center;"><?php echo esc_html($pl['no']); ?></div>
            <!-- Shorts -->
            <div style="position:absolute;top:calc(30% + 58px);left:calc(50% - 28px);width:56px;height:28px;background:var(--sp-pitch);"></div>
            <!-- Socks and legs -->
            <div style="position:absolute;top:calc(30% + 86px);left:calc(50% - 24px);width:12px;height:36px;background:#E8001D;border-radius:0 0 2px 2px;"></div>
            <div style="position:absolute;top:calc(30% + 86px);left:calc(50% + 12px);width:12px;height:36px;background:#E8001D;border-radius:0 0 2px 2px;"></div>
            <!-- Head -->
            <div style="position:absolute;top:calc(30% - 44px);left:calc(50% - 18px);width:36px;height:36px;border-radius:50%;background:<?php echo esc_attr($pl['skin']); ?>;"></div>
            <!-- Hair -->
            <div style="position:absolute;top:calc(30% - 44px);left:calc(50% - 18px);width:36px;height:16px;background:<?php echo esc_attr($pl['hair']); ?>;border-radius:50% 50% 0 0;"></div>
            <!-- Arms -->
            <div style="position:absolute;top:calc(30% + 6px);left:calc(50% - 38px);width:12px;height:36px;background:#E8001D;border-radius:4px;transform:rotate(-8deg);"></div>
            <div style="position:absolute;top:calc(30% + 6px);left:calc(50% + 26px);width:12px;height:36px;background:#E8001D;border-radius:4px;transform:rotate(8deg);"></div>
            <!-- Position badge -->
            <div style="position:absolute;top:1rem;left:1rem;background:<?php echo $pl['pos']==='GK'?'var(--sp-gold)':'var(--sp-scarlet)'; ?>;color:<?php echo $pl['pos']==='GK'?'var(--sp-pitch)':'#fff'; ?>;font-family:'Barlow Condensed',sans-serif;font-size:.6rem;font-weight:700;letter-spacing:.1em;padding:.2rem .5rem;border-radius:2px;"><?php echo esc_html($pl['pos']); ?></div>
            <!-- Kit number large bg -->
            <div aria-hidden="true" style="position:absolute;bottom:.5rem;right:.75rem;font-family:'Barlow Condensed',sans-serif;font-size:4rem;font-weight:800;color:rgba(255,255,255,.04);line-height:1;"><?php echo esc_html($pl['no']); ?></div>
          </div>
          <div style="padding:1rem;">
            <h3 style="font-family:'Barlow Condensed',sans-serif;font-size:1.1rem;font-weight:700;color:#ffffff;margin:0 0 .3rem;text-transform:uppercase;"><?php echo esc_html($pl['name']); ?></h3>
            <div style="display:flex;justify-content:space-between;">
              <span style="font-size:.72rem;color:var(--sp-slate);"><?php echo esc_html($pl['caps']); ?> appearances</span>
              <?php if($pl['goals']>0): ?>
              <span style="font-size:.72rem;color:var(--sp-gold);font-weight:600;"><?php echo esc_html($pl['goals']); ?> goals</span>
              <?php endif; ?>
            </div>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- TICKETS / SEASON PASS ──────────────────────────────── -->
  <section class="sp-section" style="background:var(--sp-scarlet);position:relative;overflow:hidden;" aria-labelledby="sp-tickets-title">
    <div aria-hidden="true" style="position:absolute;top:-100px;right:-100px;width:500px;height:500px;border-radius:50%;background:rgba(255,255,255,.04);"></div>
    <div aria-hidden="true" style="position:absolute;bottom:-100px;left:-100px;width:400px;height:400px;border-radius:50%;background:rgba(0,0,0,.06);"></div>
    <div class="sp-container" style="position:relative;z-index:1;">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:5rem;align-items:center;">
        <div class="sp-reveal">
          <p style="font-family:'Barlow Condensed',sans-serif;font-size:.75rem;font-weight:600;letter-spacing:.28em;text-transform:uppercase;color:rgba(255,255,255,.65);margin-bottom:.6rem;">Home Matches</p>
          <h2 id="sp-tickets-title" style="font-family:'Barlow Condensed',sans-serif;font-size:clamp(3rem,5vw,5rem);font-weight:800;color:#ffffff;text-transform:uppercase;letter-spacing:-.02em;margin:0 0 1rem;line-height:.95;">Get Your<br>Season Ticket</h2>
          <p style="font-family:'Barlow',sans-serif;font-size:.95rem;color:rgba(255,255,255,.75);line-height:1.75;margin:0 0 2.5rem;max-width:440px;">Be part of every home game this season. Season tickets from £299. Members receive priority cup ticket access and 20% off the club store.</p>
          <a href="<?php echo esc_url(home_url('/season-tickets')); ?>" style="display:inline-block;padding:1rem 2.5rem;background:#ffffff;color:var(--sp-scarlet);font-family:'Barlow Condensed',sans-serif;font-size:.9rem;font-weight:800;letter-spacing:.18em;text-transform:uppercase;text-decoration:none;border-radius:2px;">Buy Season Ticket</a>
        </div>
        <!-- Ticket price tiers -->
        <div class="sp-reveal" style="transition-delay:100ms;display:flex;flex-direction:column;gap:1rem;">
          <?php
          $sp_tiers=[
            ['cat'=>'Adult','stand'=>'North Stand','price'=>'£299','note'=>'Full season, all home league games'],
            ['cat'=>'Concession','stand'=>'All Stands','price'=>'£179','note'=>'Over 65 / Under 18 / Student'],
            ['cat'=>'Family','stand'=>'Family Zone','price'=>'£449','note'=>'2 adults + 2 U-16s. Best value'],
          ];
          foreach($sp_tiers as $t):?>
          <div style="background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);border-radius:4px;padding:1.5rem;display:flex;align-items:center;justify-content:space-between;gap:1rem;">
            <div>
              <p style="font-family:'Barlow Condensed',sans-serif;font-size:1.1rem;font-weight:700;color:#ffffff;margin:0;"><?php echo esc_html($t['cat']); ?> · <?php echo esc_html($t['stand']); ?></p>
              <p style="font-size:.78rem;color:rgba(255,255,255,.6);margin:0;"><?php echo esc_html($t['note']); ?></p>
            </div>
            <p style="font-family:'Barlow Condensed',sans-serif;font-size:1.5rem;font-weight:800;color:var(--sp-gold);margin:0;white-space:nowrap;"><?php echo esc_html($t['price']); ?></p>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </section>

  <!-- CLUB SHOP PREVIEW ───────────────────────────────────── -->
  <section class="sp-section" style="background:var(--sp-mid);" aria-labelledby="sp-shop-title">
    <div class="sp-container">
      <div class="sp-reveal" style="display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:3.5rem;flex-wrap:wrap;gap:1.5rem;">
        <div>
          <p class="sp-eyebrow">Official Store</p>
          <h2 id="sp-shop-title" style="font-family:'Barlow Condensed',sans-serif;font-size:clamp(3rem,5vw,4rem);font-weight:800;color:#ffffff;margin:0;text-transform:uppercase;">Club Shop</h2>
        </div>
        <a href="<?php echo esc_url(home_url('/shop')); ?>" style="padding:.75rem 1.75rem;background:var(--sp-gold);color:var(--sp-pitch);font-family:'Barlow Condensed',sans-serif;font-size:.82rem;font-weight:700;letter-spacing:.18em;text-transform:uppercase;text-decoration:none;border-radius:2px;">View All Products</a>
      </div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:1.25rem;">
        <?php
        $sp_products=[
          ['name'=>'Home Kit 2025/26','price'=>'£74.99','badge'=>'New','bg'=>'#1A0810'],
          ['name'=>'Away Kit 2025/26','price'=>'£74.99','badge'=>'New','bg'=>'#0A1020'],
          ['name'=>'Training Jacket','price'=>'£54.99','badge'=>'','bg'=>'#101810'],
          ['name'=>'Scarf — Home Colours','price'=>'£22.99','badge'=>'','bg'=>'#180A0A'],
        ];
        foreach($sp_products as $pi=>$prod):?>
        <article style="background:var(--sp-pitch);border:1px solid rgba(255,255,255,.06);border-radius:4px;overflow:hidden;cursor:pointer;transition:border-color .3s;" onmouseenter="this.style.borderColor='rgba(232,0,29,.25)'" onmouseleave="this.style.borderColor='rgba(255,255,255,.06)'" class="sp-reveal" style="transition-delay:<?php echo $pi*70; ?>ms;">
          <div style="aspect-ratio:1;background:<?php echo esc_attr($prod['bg']); ?>;display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden;">
            <!-- Kit shape -->
            <div style="width:50px;height:56px;background:linear-gradient(180deg,#E8001D 0%,#900010 100%);border-radius:4px 4px 0 0;position:relative;border:2px solid rgba(255,255,255,.08);">
              <div style="position:absolute;top:6px;left:50%;transform:translateX(-50%);width:20px;height:8px;background:rgba(255,255,255,.08);border-radius:2px;"></div>
            </div>
            <?php if($prod['badge']): ?>
            <div style="position:absolute;top:.75rem;right:.75rem;background:var(--sp-gold);color:var(--sp-pitch);font-family:'Barlow Condensed',sans-serif;font-size:.6rem;font-weight:800;letter-spacing:.12em;text-transform:uppercase;padding:.2rem .5rem;border-radius:2px;"><?php echo esc_html($prod['badge']); ?></div>
            <?php endif; ?>
          </div>
          <div style="padding:1rem;">
            <h3 style="font-family:'Barlow Condensed',sans-serif;font-size:1rem;font-weight:700;color:#ffffff;margin:0 0 .4rem;text-transform:uppercase;"><?php echo esc_html($prod['name']); ?></h3>
            <div style="display:flex;align-items:center;justify-content:space-between;">
              <span style="font-family:'Barlow Condensed',sans-serif;font-size:1.1rem;font-weight:700;color:var(--sp-gold);"><?php echo esc_html($prod['price']); ?></span>
              <button style="padding:.4rem .85rem;background:rgba(232,0,29,.15);border:1px solid rgba(232,0,29,.25);color:var(--sp-scarlet);font-family:'Barlow Condensed',sans-serif;font-size:.65rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;border-radius:2px;cursor:pointer;">Add to bag</button>
            </div>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- SPONSORS ────────────────────────────────────────────── -->
  <section style="background:var(--sp-pitch);padding:4rem 0;border-top:1px solid rgba(255,255,255,.05);border-bottom:1px solid rgba(255,255,255,.05);" aria-labelledby="sp-sponsors-title">
    <div class="sp-container">
      <p class="sp-reveal" id="sp-sponsors-title" style="font-family:'Barlow',sans-serif;font-size:.65rem;letter-spacing:.25em;text-transform:uppercase;color:var(--sp-slate);text-align:center;margin-bottom:2.5rem;">Club Partners &amp; Sponsors</p>
      <div style="display:flex;gap:0;justify-content:space-around;align-items:center;flex-wrap:wrap;">
        <?php
        $sp_sponsors=['Apex Insurance','CoreFit Nutrition','Millward & Sons','TechPoint UK','Premier Fleet','Greystone Bank'];
        foreach($sp_sponsors as $si=>$sn):?>
        <div class="sp-reveal" style="transition-delay:<?php echo $si*50; ?>ms;padding:1rem 2rem;">
          <p style="font-family:'Barlow Condensed',sans-serif;font-size:1.1rem;font-weight:700;letter-spacing:.05em;color:rgba(255,255,255,.2);text-transform:uppercase;margin:0;"><?php echo esc_html($sn); ?></p>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- NEWS / LATEST ───────────────────────────────────────── -->
  <section class="sp-section" style="background:var(--sp-mid);" aria-labelledby="sp-news-title">
    <div class="sp-container">
      <div class="sp-reveal" style="display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:3.5rem;flex-wrap:wrap;gap:1.5rem;">
        <div>
          <p class="sp-eyebrow">From the Club</p>
          <h2 id="sp-news-title" style="font-family:'Barlow Condensed',sans-serif;font-size:clamp(3rem,5vw,4rem);font-weight:800;color:#ffffff;margin:0;text-transform:uppercase;">Latest News</h2>
        </div>
        <a href="<?php echo esc_url(home_url('/news')); ?>" style="font-family:'Barlow Condensed',sans-serif;font-size:.8rem;font-weight:600;letter-spacing:.16em;text-transform:uppercase;color:var(--sp-gold);text-decoration:none;border-bottom:1px solid rgba(255,215,0,.3);padding-bottom:2px;">All News &#8594;</a>
      </div>
      <div style="display:grid;grid-template-columns:2fr 1fr 1fr;gap:1.25rem;">
        <?php
        $sp_news=[
          ['cat'=>'Match Report','title'=>'Three Goals, Full Control: A Statement Win Over Millport','date'=>'26 Apr 2026','color'=>'#0A1A0A'],
          ['cat'=>'Squad News','title'=>'Strand Fitness Update Ahead of Thornton Fixture','date'=>'24 Apr 2026','color'=>'#180A0A'],
          ['cat'=>'Academy','title'=>'Six Scholars Sign First Professional Contracts','date'=>'22 Apr 2026','color'=>'#0A1018'],
        ];
        foreach($sp_news as $ni=>$nw):?>
        <article class="sp-reveal" style="transition-delay:<?php echo $ni*80; ?>ms;background:<?php echo esc_attr($nw['color']); ?>;border:1px solid rgba(255,255,255,.07);border-radius:4px;overflow:hidden;display:flex;flex-direction:column;">
          <div style="<?php echo $ni===0?'height:160px;':'height:100px;'; ?>background:linear-gradient(135deg,rgba(255,255,255,.02),transparent);position:relative;overflow:hidden;">
            <div style="position:absolute;top:1rem;left:1rem;background:var(--sp-scarlet);color:#fff;font-family:'Barlow Condensed',sans-serif;font-size:.6rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;padding:.2rem .55rem;border-radius:2px;"><?php echo esc_html($nw['cat']); ?></div>
          </div>
          <div style="padding:1.25rem;flex:1;display:flex;flex-direction:column;justify-content:space-between;">
            <h3 style="font-family:'Barlow Condensed',sans-serif;font-size:<?php echo $ni===0?'1.25rem':'1rem'; ?>;font-weight:700;color:#ffffff;margin:0 0 .75rem;text-transform:uppercase;line-height:1.2;"><?php echo esc_html($nw['title']); ?></h3>
            <div style="display:flex;align-items:center;justify-content:space-between;">
              <span style="font-size:.7rem;color:var(--sp-slate);"><?php echo esc_html($nw['date']); ?></span>
              <a href="<?php echo esc_url(home_url('/news/'.sanitize_title($nw['title']))); ?>" style="font-family:'Barlow Condensed',sans-serif;font-size:.7rem;font-weight:600;letter-spacing:.12em;text-transform:uppercase;color:var(--sp-gold);text-decoration:none;">Read &#8594;</a>
            </div>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

</div><!-- /.sp-page -->

<script>
(function(){
  'use strict';
  var obs=new IntersectionObserver(function(e){e.forEach(function(el){if(el.isIntersecting){el.target.classList.add('sp-visible');obs.unobserve(el.target);}});},{threshold:.08});
  document.querySelectorAll('.sp-reveal').forEach(function(el){obs.observe(el);});
})();
</script>


<?php
/* ─────────────────────────────────────────────────────────────
   CLUB HISTORY / HONOURS
   ───────────────────────────────────────────────────────────── */
$sp_trophies = [
  ['n'=>'14','l'=>'League Titles','ic'=>'&#127942;'],
  ['n'=>'6','l'=>'National Cups','ic'=>'&#127944;'],
  ['n'=>'3','l'=>'European Titles','ic'=>'&#9971;'],
  ['n'=>'137','l'=>'Years of History','ic'=>'&#128336;'],
];
$sp_history = [
  ['year'=>'1887','event'=>'Club founded by mill workers in the Ravenswood valley. First competitive match played at Meadow End.'],
  ['year'=>'1921','event'=>'First league title. The "Golden Era" squad featuring 11 internationals.'],
  ['year'=>'1968','event'=>'European Cup quarter-finalists. The furthest any club from the division had gone.'],
  ['year'=>'1994','event'=>'Ravenswood Arena inaugurated. 28,500 capacity. Home ever since.'],
  ['year'=>'2012','event'=>'Back-to-back league titles under manager Paul Warwick. Club\'s most successful modern era begins.'],
  ['year'=>'2026','event'=>'League leaders by 5 points with 4 games remaining. Title is within reach.'],
];
?>
<!-- HISTORY ──────────────────────────────────────────────── -->
<section class="sp-section" style="background:var(--sp-pitch);border-top:1px solid rgba(255,255,255,.05);" aria-labelledby="sp-history-title">
  <div class="sp-container">
    <div class="sp-reveal" style="text-align:center;margin-bottom:4rem;">
      <p class="sp-eyebrow">Est. 1887</p>
      <h2 id="sp-history-title" style="font-family:'Barlow Condensed',sans-serif;font-size:clamp(3rem,5vw,5rem);font-weight:800;color:#ffffff;text-transform:uppercase;margin:0;letter-spacing:-.02em;">Club History<br>&amp; Honours</h2>
    </div>
    <!-- Trophies -->
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:1px;background:rgba(255,255,255,.06);margin-bottom:5rem;" class="sp-reveal">
      <?php foreach($sp_trophies as $ti=>$tr): ?>
      <div style="background:var(--sp-pitch);padding:2.5rem 2rem;text-align:center;">
        <p style="font-size:2rem;margin:0 0 .75rem;" aria-hidden="true"><?php echo $tr['ic']; ?></p>
        <p style="font-family:'Barlow Condensed',sans-serif;font-size:3rem;font-weight:800;color:var(--sp-gold);margin:0 0 .25rem;line-height:1;"><?php echo esc_html($tr['n']); ?></p>
        <p style="font-family:'Barlow',sans-serif;font-size:.72rem;letter-spacing:.16em;text-transform:uppercase;color:var(--sp-slate);margin:0;"><?php echo esc_html($tr['l']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
    <!-- Timeline -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:4rem;">
      <div class="sp-reveal">
        <p style="font-family:'Barlow Condensed',sans-serif;font-size:.75rem;font-weight:600;letter-spacing:.28em;text-transform:uppercase;color:var(--sp-slate);margin-bottom:2rem;">Key Moments</p>
        <div style="position:relative;padding-left:2rem;">
          <div aria-hidden="true" style="position:absolute;left:5px;top:0;bottom:0;width:2px;background:linear-gradient(180deg,var(--sp-scarlet) 0%,rgba(232,0,29,.1) 100%);"></div>
          <?php foreach($sp_history as $hi=>$h): ?>
          <div style="position:relative;margin-bottom:2rem;<?php echo $hi===count($sp_history)-1?'margin-bottom:0;':''; ?>">
            <div style="position:absolute;left:-2rem;top:4px;width:12px;height:12px;border-radius:50%;background:<?php echo $hi===count($sp_history)-1?'var(--sp-gold)':'rgba(232,0,29,.4)'; ?>;border:2px solid <?php echo $hi===count($sp_history)-1?'var(--sp-gold)':'rgba(232,0,29,.2)'; ?>;"></div>
            <p style="font-family:'Barlow Condensed',sans-serif;font-size:.8rem;font-weight:700;letter-spacing:.08em;color:var(--sp-gold);margin:0 0 .3rem;"><?php echo esc_html($h['year']); ?></p>
            <p style="font-family:'Barlow',sans-serif;font-size:.85rem;color:var(--sp-slate);line-height:1.6;margin:0;"><?php echo esc_html($h['event']); ?></p>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <!-- Club values -->
      <div class="sp-reveal" style="transition-delay:120ms;">
        <p style="font-family:'Barlow Condensed',sans-serif;font-size:.75rem;font-weight:600;letter-spacing:.28em;text-transform:uppercase;color:var(--sp-slate);margin-bottom:2rem;">Our Values</p>
        <?php
        $sp_vals=[
          ['h'=>'Community First','t'=>'Ravenswood FC belongs to this town and its people. We reinvest 12% of turnover in grassroots football and youth development programmes across the region.'],
          ['h'=>'Fearless Football','t'=>'We play to win, but we play with imagination. We\'re not interested in parking the bus. Beautiful football moves people — and we\'re here to move people.'],
          ['h'=>'Respect','t'=>'On and off the pitch. For opponents, referees, supporters, and the staff who keep this club running every single day.'],
        ];
        foreach($sp_vals as $v):?>
        <div style="padding:1.5rem;background:rgba(255,255,255,.03);border-left:3px solid var(--sp-scarlet);margin-bottom:1rem;border-radius:0 4px 4px 0;">
          <h3 style="font-family:'Barlow Condensed',sans-serif;font-size:1.1rem;font-weight:700;color:#ffffff;text-transform:uppercase;margin:0 0 .5rem;"><?php echo esc_html($v['h']); ?></h3>
          <p style="font-family:'Barlow',sans-serif;font-size:.85rem;color:var(--sp-slate);line-height:1.65;margin:0;"><?php echo esc_html($v['t']); ?></p>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<?php
/* ─────────────────────────────────────────────────────────────
   MEMBERSHIP TIERS
   ───────────────────────────────────────────────────────────── */
$sp_memberships = [
  ['name'=>'Supporter','price'=>'£49/yr','perks'=>['Digital membership card','Priority ticket booking','Club newsletter','Member discounts in shop'],'color'=>'rgba(255,255,255,.03)','featured'=>false],
  ['name'=>'Fanatic','price'=>'£99/yr','perks'=>['All Supporter perks','Matchday programme collection','Stadium tour access','Behind-the-scenes access','Signed squad photo'],'color'=>'rgba(232,0,29,.08)','featured'=>true],
  ['name'=>'Legend','price'=>'£249/yr','perks'=>['All Fanatic perks','Pitch-side experience (2/yr)','Meet a first-team player','VIP hospitality invitation','Personalised player shirt'],'color'=>'rgba(255,215,0,.04)','featured'=>false],
];
?>
<!-- MEMBERSHIPS ──────────────────────────────────────────── -->
<section class="sp-section" style="background:var(--sp-mid);" aria-labelledby="sp-membership-title">
  <div class="sp-container">
    <div class="sp-reveal" style="text-align:center;margin-bottom:4rem;">
      <p class="sp-eyebrow">Join the Family</p>
      <h2 id="sp-membership-title" style="font-family:'Barlow Condensed',sans-serif;font-size:clamp(3rem,5vw,4.5rem);font-weight:800;color:#ffffff;text-transform:uppercase;margin:0;letter-spacing:-.01em;">Club Membership</h2>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:1.25rem;align-items:start;">
      <?php foreach($sp_memberships as $mi=>$mem): ?>
      <div class="sp-reveal" style="transition-delay:<?php echo $mi*90; ?>ms;background:<?php echo $mem['color']; ?>;border:1px solid <?php echo $mem['featured']?'rgba(232,0,29,.35)':'rgba(255,255,255,.07)'; ?>;border-radius:4px;padding:2.25rem 2rem;position:relative;<?php echo $mem['featured']?'transform:scale(1.03);':''; ?>">
        <?php if($mem['featured']): ?>
        <div style="position:absolute;top:-12px;left:50%;transform:translateX(-50%);background:var(--sp-scarlet);color:#ffffff;font-family:'Barlow Condensed',sans-serif;font-size:.65rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;padding:.25rem .85rem;border-radius:2px;">Most Popular</div>
        <?php endif; ?>
        <h3 style="font-family:'Barlow Condensed',sans-serif;font-size:1.75rem;font-weight:800;color:#ffffff;text-transform:uppercase;margin:0 0 .4rem;"><?php echo esc_html($mem['name']); ?></h3>
        <p style="font-family:'Barlow Condensed',sans-serif;font-size:1.5rem;font-weight:700;color:var(--sp-gold);margin:0 0 1.75rem;"><?php echo esc_html($mem['price']); ?></p>
        <ul style="list-style:none;padding:0;margin:0 0 2rem;display:flex;flex-direction:column;gap:.75rem;">
          <?php foreach($mem['perks'] as $perk): ?>
          <li style="display:flex;align-items:flex-start;gap:.6rem;font-family:'Barlow',sans-serif;font-size:.85rem;color:rgba(248,250,252,.7);line-height:1.4;">
            <span style="color:var(--sp-scarlet);margin-top:2px;flex-shrink:0;">&#10003;</span>
            <?php echo esc_html($perk); ?>
          </li>
          <?php endforeach; ?>
        </ul>
        <a href="<?php echo esc_url(home_url('/membership/'.sanitize_title($mem['name']))); ?>" style="display:block;text-align:center;padding:.85rem;background:<?php echo $mem['featured']?'var(--sp-scarlet)':'rgba(255,255,255,.06)'; ?>;color:#ffffff;font-family:'Barlow Condensed',sans-serif;font-size:.82rem;font-weight:700;letter-spacing:.16em;text-transform:uppercase;text-decoration:none;border-radius:2px;border:1px solid <?php echo $mem['featured']?'var(--sp-scarlet)':'rgba(255,255,255,.1)'; ?>;">Join <?php echo esc_html($mem['name']); ?></a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php
/* ─────────────────────────────────────────────────────────────
   NEWSLETTER / FAN SIGN-UP
   ───────────────────────────────────────────────────────────── */
?>
<!-- NEWSLETTER ───────────────────────────────────────────── -->
<section style="background:var(--sp-pitch);padding:5rem 0;border-top:1px solid rgba(255,255,255,.05);" aria-labelledby="sp-newsletter-title">
  <div class="sp-container">
    <div class="sp-reveal" style="max-width:620px;margin:0 auto;text-align:center;">
      <p class="sp-eyebrow">Stay Connected</p>
      <h2 id="sp-newsletter-title" style="font-family:'Barlow Condensed',sans-serif;font-size:clamp(2.5rem,4vw,4rem);font-weight:800;color:#ffffff;text-transform:uppercase;margin:0 0 1rem;letter-spacing:-.01em;">Never Miss<br>a Kick-Off</h2>
      <p style="font-family:'Barlow',sans-serif;font-size:.95rem;color:var(--sp-slate);line-height:1.75;margin:0 0 2.5rem;">Team news, fixture updates, exclusive member offers, and behind-the-scenes content — delivered before every matchday.</p>
      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:flex;gap:.75rem;max-width:480px;margin:0 auto 1rem;" novalidate>
        <input type="hidden" name="action" value="tf_sp_newsletter">
        <?php wp_nonce_field('tf_sp_newsletter','tf_sp_nonce'); ?>
        <label for="sp-email" class="screen-reader-text"><?php esc_html_e('Email address','themeflex'); ?></label>
        <input type="email" id="sp-email" name="email" placeholder="your@email.com" required style="flex:1;padding:.9rem 1rem;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:2px;color:#ffffff;font-family:'Barlow',sans-serif;font-size:.875rem;outline:none;" aria-required="true">
        <button type="submit" style="padding:.9rem 1.5rem;background:var(--sp-scarlet);color:#ffffff;font-family:'Barlow Condensed',sans-serif;font-size:.82rem;font-weight:700;letter-spacing:.16em;text-transform:uppercase;border:none;border-radius:2px;cursor:pointer;white-space:nowrap;">Sign Up</button>
      </form>
      <p style="font-family:'Barlow',sans-serif;font-size:.75rem;color:rgba(255,255,255,.3);">18,000+ fans already subscribed. No spam. Unsubscribe anytime.</p>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     ACADEMY & YOUTH DEVELOPMENT — RAVENSWOOD FC
     ═══════════════════════════════════════════════ -->
<section class="sp-academy" style="background:var(--sp-pitch);padding:96px 0;border-top:1px solid rgba(232,0,29,.18);">
  <div class="sp-container">
    <p class="sp-eyebrow" style="color:var(--sp-scarlet);">Youth Development</p>
    <h2 style="font-family:'Barlow Condensed',sans-serif;font-size:clamp(2rem,5vw,3.2rem);font-weight:800;text-transform:uppercase;color:#ffffff;margin:0 0 16px;">The Ravenswood <span style="color:var(--sp-scarlet);">Academy</span></h2>
    <p style="color:#64748b;max-width:600px;line-height:1.7;margin:0 0 56px;font-family:'Barlow',sans-serif;">Developing the stars of tomorrow. Our Elite Performance Academy provides a world-class pathway for players aged 8–21, with fully qualified coaches and state-of-the-art facilities at Ravenswood Training Ground.</p>
    <?php
    $sp_agegroups=[
      ['age'=>'U9–U11','label'=>'Foundation Phase','colour'=>'#FFD700','count'=>'42 players','coach'=>'Director: James Hollis','detail'=>'Fundamentals, fun, and individual skill. Sessions 3× weekly at Ravenswood Park.'],
      ['age'=>'U12–U14','label'=>'Youth Development','colour'=>'#E8001D','count'=>'54 players','coach'=>'Lead Coach: Priya Chadha','detail'=>'Technical formation work and positional play in the Regional Youth League.'],
      ['age'=>'U15–U18','label'=>'Professional Dev.','colour'=>'#94a3b8','count'=>'36 players','coach'=>'Head of Youth: Marcus Feld','detail'=>'Elite training, sports science, and direct pathway to Reserve and First Teams.'],
      ['age'=>'U19–U21','label'=>'Reserve & Transition','colour'=>'#FFD700','count'=>'22 players','coach'=>'Reserve Mgr: Danielle Cross','detail'=>'First team shadow squad in competitive reserve league fixtures.'],
    ];
    ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:24px;margin-bottom:48px;">
      <?php foreach($sp_agegroups as $i=>$ag): ?>
      <div style="background:#0f1f0f;border:1px solid rgba(255,255,255,.07);border-top:3px solid <?php echo esc_attr($ag['colour']); ?>;border-radius:8px;padding:28px;position:relative;overflow:hidden;">
        <div style="position:absolute;right:20px;top:12px;font-family:'Barlow Condensed',sans-serif;font-size:3rem;font-weight:900;color:rgba(255,255,255,.04);">0<?php echo $i+1; ?></div>
        <span style="display:inline-block;background:<?php echo esc_attr($ag['colour']); ?>;color:#0a1a0a;font-size:.65rem;font-weight:700;text-transform:uppercase;letter-spacing:.12em;padding:3px 10px;border-radius:4px;margin-bottom:14px;"><?php echo esc_html($ag['label']); ?></span>
        <h3 style="font-family:'Barlow Condensed',sans-serif;font-size:1.5rem;font-weight:800;text-transform:uppercase;color:#ffffff;margin:0 0 6px;"><?php echo esc_html($ag['age']); ?></h3>
        <p style="color:var(--sp-gold);font-size:.78rem;font-weight:600;margin:0 0 8px;"><?php echo esc_html($ag['count']); ?></p>
        <p style="color:#475569;font-size:.72rem;margin:0 0 10px;font-family:'Barlow',sans-serif;"><?php echo esc_html($ag['coach']); ?></p>
        <p style="color:#64748b;font-size:.83rem;line-height:1.6;margin:0;font-family:'Barlow',sans-serif;"><?php echo esc_html($ag['detail']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="background:var(--sp-scarlet);border-radius:10px;padding:36px 48px;display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:24px;text-align:center;margin-bottom:36px;">
      <?php $sp_ac_stats=[['v'=>'154','l'=>'Academy Players'],['v'=>'23','l'=>'First Team Graduates'],['v'=>'6','l'=>'International Caps'],['v'=>'2','l'=>'Academy Trophies']]; ?>
      <?php foreach($sp_ac_stats as $s): ?><div><div style="font-family:'Barlow Condensed',sans-serif;font-size:2.8rem;font-weight:900;color:#ffffff;line-height:1;"><?php echo esc_html($s['v']); ?></div><div style="color:rgba(255,255,255,.75);font-size:.72rem;text-transform:uppercase;letter-spacing:.1em;margin-top:4px;font-family:'Barlow',sans-serif;"><?php echo esc_html($s['l']); ?></div></div><?php endforeach; ?>
    </div>
    <div style="background:#0f1f0f;border:1px solid rgba(255,215,0,.18);border-radius:10px;padding:36px;display:grid;grid-template-columns:1fr auto;gap:24px;align-items:center;">
      <div><h3 style="font-family:'Barlow Condensed',sans-serif;font-size:1.6rem;font-weight:800;text-transform:uppercase;color:#ffffff;margin:0 0 8px;">Trials &amp; Open Days</h3><p style="color:#64748b;margin:0;line-height:1.65;font-family:'Barlow',sans-serif;">Applications for the 2026–27 academy intake are now open. Trials run throughout June at Ravenswood Training Ground. Players must be registered by a parent or guardian.</p></div>
      <div style="display:flex;gap:12px;flex-wrap:wrap;"><a href="#" style="display:inline-block;background:var(--sp-gold);color:#0a1a0a;font-family:'Barlow Condensed',sans-serif;font-weight:700;font-size:.82rem;text-transform:uppercase;letter-spacing:.08em;padding:14px 28px;border-radius:6px;text-decoration:none;white-space:nowrap;">Apply Now</a><a href="#" style="display:inline-block;border:2px solid rgba(255,255,255,.18);color:#ffffff;font-family:'Barlow Condensed',sans-serif;font-weight:600;font-size:.82rem;text-transform:uppercase;letter-spacing:.08em;padding:14px 28px;border-radius:6px;text-decoration:none;white-space:nowrap;">Prospectus</a></div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     MEDIA CENTRE — RAVENSWOOD FC
     ═══════════════════════════════════════════════ -->
<section class="sp-media" style="background:#07120a;padding:96px 0;border-top:1px solid rgba(255,255,255,.05);">
  <div class="sp-container">
    <p class="sp-eyebrow" style="color:var(--sp-scarlet);">Latest from the Club</p>
    <h2 style="font-family:'Barlow Condensed',sans-serif;font-size:clamp(2rem,5vw,3.2rem);font-weight:800;text-transform:uppercase;color:#ffffff;margin:0 0 48px;">Media <span style="color:var(--sp-scarlet);">Centre</span></h2>
    <?php
    $sp_media=[
      ['cat'=>'Match Report','title'=>'Ravenswood 3–1 Elthorpe City: Dominant Display Secures Top Spot','date'=>'28 Apr 2026','tag'=>'#E8001D'],
      ['cat'=>'Transfer News','title'=>'Club Confirms Signing of Midfielder Lucía Vargas on Three-Year Deal','date'=>'25 Apr 2026','tag'=>'#FFD700'],
      ['cat'=>'Club News','title'=>'New Training Ground Expansion Set to Begin Construction This Summer','date'=>'22 Apr 2026','tag'=>'#334155'],
      ['cat'=>'Match Report','title'=>'Penalty Shootout Heartbreak as Ravenswood Exit Cup at Semi-Final Stage','date'=>'18 Apr 2026','tag'=>'#E8001D'],
      ['cat'=>'Academy','title'=>'Four Academy Graduates Named in First Team Squad for Season Run-In','date'=>'15 Apr 2026','tag'=>'#FFD700'],
    ];
    ?>
    <div style="display:grid;grid-template-columns:2fr 1fr;gap:24px;margin-bottom:24px;">
      <div style="background:#0f1f0f;border:1px solid rgba(255,255,255,.07);border-radius:12px;overflow:hidden;">
        <div style="height:200px;background:linear-gradient(135deg,#0a2a0a 0%,#1a3a1a 100%);position:relative;">
          <div style="position:absolute;bottom:0;left:50%;transform:translateX(-50%);width:70%;height:55%;border:2px solid rgba(255,255,255,.15);border-bottom:none;border-radius:4px 4px 0 0;"></div>
          <div style="position:absolute;top:16px;left:16px;background:var(--sp-scarlet);color:#fff;font-size:.65rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;padding:4px 10px;border-radius:4px;">Match Report</div>
          <div style="position:absolute;inset:0;background:linear-gradient(to top,rgba(15,31,15,.9) 0%,transparent 55%);"></div>
        </div>
        <div style="padding:24px;"><h3 style="font-family:'Barlow Condensed',sans-serif;font-size:1.4rem;font-weight:700;color:#ffffff;margin:0 0 10px;line-height:1.25;">Ravenswood 3–1 Elthorpe City: Dominant Display Secures Top Spot</h3><p style="color:#475569;font-size:.78rem;margin:0;font-family:'Barlow',sans-serif;">28 Apr 2026</p></div>
      </div>
      <div style="display:flex;flex-direction:column;gap:14px;">
        <?php foreach(array_slice($sp_media,1) as $m): ?>
        <div style="background:#0f1f0f;border:1px solid rgba(255,255,255,.07);border-radius:8px;padding:16px;display:flex;gap:12px;align-items:flex-start;">
          <div style="width:40px;height:40px;background:rgba(255,255,255,.04);border-radius:6px;flex-shrink:0;border:1px solid rgba(255,255,255,.07);"></div>
          <div style="flex:1;min-width:0;"><span style="background:<?php echo esc_attr($m['tag']); ?>;color:#0a1a0a;font-size:.6rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;padding:2px 7px;border-radius:3px;"><?php echo esc_html($m['cat']); ?></span><p style="font-family:'Barlow Condensed',sans-serif;font-size:.95rem;font-weight:700;color:#ffffff;margin:5px 0 3px;line-height:1.25;"><?php echo esc_html($m['title']); ?></p><p style="color:#475569;font-size:.7rem;margin:0;font-family:'Barlow',sans-serif;"><?php echo esc_html($m['date']); ?></p></div>
        </div>
        <?php endforeach; ?>
        <a href="#" style="display:block;text-align:center;border:2px solid rgba(255,255,255,.12);color:#ffffff;font-family:'Barlow Condensed',sans-serif;font-weight:600;font-size:.8rem;text-transform:uppercase;letter-spacing:.1em;padding:13px;border-radius:8px;text-decoration:none;">All News →</a>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════
     COMMUNITY FOUNDATION — RAVENSWOOD FC
     ═══════════════════════════════════════════════ -->
<section class="sp-community" style="background:var(--sp-pitch);padding:96px 0;border-top:1px solid rgba(232,0,29,.1);">
  <div class="sp-container" style="display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:start;">
    <div>
      <p class="sp-eyebrow" style="color:var(--sp-scarlet);">More Than a Club</p>
      <h2 style="font-family:'Barlow Condensed',sans-serif;font-size:clamp(2rem,5vw,3.2rem);font-weight:800;text-transform:uppercase;color:#ffffff;margin:0 0 18px;line-height:1.05;">Ravenswood <span style="color:var(--sp-scarlet);">Foundation</span></h2>
      <p style="color:#64748b;line-height:1.8;margin:0 0 28px;font-family:'Barlow',sans-serif;">Established in 2003, the Ravenswood FC Foundation uses the power of football to create positive change. From disability sport to educational programmes, we believe every young person deserves a chance to shine.</p>
      <?php $sp_progs=[['⚽','Kicks for Kids','Free after-school sessions for 8–16s across 12 local schools.'],['📚','Goals in the Classroom','Mentoring and literacy support from first-team ambassadors.'],['♿','Ability FC','Para-football programme open to all ages throughout the year.'],['🌍','Global Goalkeepers','Exchange programme with partner clubs in Nigeria and Colombia.']]; ?>
      <ul style="list-style:none;padding:0;margin:0 0 36px;display:flex;flex-direction:column;gap:16px;">
        <?php foreach($sp_progs as $p): ?><li style="display:flex;gap:14px;align-items:flex-start;"><span style="font-size:1.3rem;line-height:1;margin-top:2px;"><?php echo $p[0]; ?></span><div><strong style="color:#ffffff;font-size:.93rem;display:block;margin-bottom:3px;font-family:'Barlow Condensed',sans-serif;font-size:1rem;"><?php echo esc_html($p[1]); ?></strong><span style="color:#64748b;font-size:.83rem;font-family:'Barlow',sans-serif;"><?php echo esc_html($p[2]); ?></span></div></li><?php endforeach; ?>
      </ul>
      <div style="display:flex;gap:16px;flex-wrap:wrap;">
        <a href="#" style="display:inline-block;background:var(--sp-scarlet);color:#ffffff;font-family:'Barlow Condensed',sans-serif;font-weight:700;font-size:.82rem;text-transform:uppercase;letter-spacing:.1em;padding:15px 30px;border-radius:6px;text-decoration:none;">Support the Foundation</a>
        <a href="#" style="display:inline-block;border:2px solid rgba(255,255,255,.15);color:#ffffff;font-family:'Barlow Condensed',sans-serif;font-weight:600;font-size:.82rem;text-transform:uppercase;letter-spacing:.1em;padding:15px 30px;border-radius:6px;text-decoration:none;">Volunteer</a>
      </div>
    </div>
    <!-- Foundation impact stats -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
      <?php $sp_impact=[['12,400+','Lives Touched Annually'],['23','Years Serving Community'],['48','Volunteer Staff'],['£2.1M','Annual Foundation Budget'],['4','Active Programmes'],['12','Partner Schools']]; ?>
      <?php foreach($sp_impact as $imp): ?>
      <div style="background:#0f1f0f;border:1px solid rgba(255,255,255,.07);border-radius:10px;padding:24px;text-align:center;">
        <div style="font-family:'Barlow Condensed',sans-serif;font-size:2.2rem;font-weight:900;color:var(--sp-gold);line-height:1;margin-bottom:6px;"><?php echo esc_html($imp[0]); ?></div>
        <div style="color:#64748b;font-size:.75rem;text-transform:uppercase;letter-spacing:.08em;font-family:'Barlow',sans-serif;"><?php echo esc_html($imp[1]); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php get_footer(); ?>
