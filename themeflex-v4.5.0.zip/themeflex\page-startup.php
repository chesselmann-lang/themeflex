<?php
/**
 * Template Name: Tech Startup / SaaS Homepage
 *
 * Premium SaaS/startup page template for ThemeFlex.
 * Namespace : --su-*
 * Fonts     : Space Grotesk (headings) + Manrope (body)
 * Palette   : Void #080B14 / Violet #6D28D9 / Cyan #06B6D4 / Lime #84CC16 / Smoke #94A3B8
 */
defined('ABSPATH') || exit;
get_header();
?>

<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Manrope:wght@300;400;500;600;700&display=swap');

/* ── Tokens ── */
:root{
  --su-void:#080B14;
  --su-deep:#0D1526;
  --su-violet:#6D28D9;
  --su-violet-light:#8B5CF6;
  --su-violet-pale:#EDE9FE;
  --su-cyan:#06B6D4;
  --su-cyan-dim:rgba(6,182,212,.15);
  --su-lime:#84CC16;
  --su-smoke:#94A3B8;
  --su-surface:#111827;
  --su-border:rgba(255,255,255,.08);
  --su-white:#FFFFFF;
  --su-platinum:#F1F5F9;
  --su-serif:'Space Grotesk',system-ui,sans-serif;
  --su-sans:'Manrope',system-ui,sans-serif;
  --su-radius:8px;
  --su-shadow:0 4px 24px rgba(0,0,0,.4);
  --su-shadow-glow:0 0 40px rgba(109,40,217,.3);
}

/* ── Reset ── */
.su-page *,
.su-page *::before,
.su-page *::after{box-sizing:border-box;margin:0;padding:0}
.su-page{font-family:var(--su-sans);color:var(--su-white);background:var(--su-void);line-height:1.6;overflow-x:hidden}
.su-page a{color:inherit;text-decoration:none}

/* ── Layout ── */
.su-wrap{max-width:1160px;margin:0 auto;padding:0 24px}
.su-section{padding:88px 0}
.su-section--light{background:var(--su-platinum);color:var(--su-void)}
.su-section--surface{background:var(--su-surface)}

/* ── Typography ── */
.su-eyebrow{font-family:var(--su-sans);font-size:.72rem;font-weight:700;letter-spacing:.2em;text-transform:uppercase;color:var(--su-cyan);margin-bottom:12px}
.su-section--light .su-eyebrow{color:var(--su-violet)}
.su-h1{font-family:var(--su-serif);font-size:clamp(2.4rem,5.5vw,4rem);line-height:1.1;font-weight:700}
.su-h2{font-family:var(--su-serif);font-size:clamp(1.8rem,3.5vw,2.8rem);line-height:1.2;font-weight:700}
.su-section--light .su-h2{color:var(--su-void)}
.su-lead{font-size:1.1rem;color:var(--su-smoke);max-width:680px;margin:0 auto;line-height:1.75}
.su-section--light .su-lead{color:#475569}
.su-center{text-align:center}
.su-hgroup{margin-bottom:56px}

/* ── Gradient text ── */
.su-grad{background:linear-gradient(135deg,var(--su-violet-light),var(--su-cyan));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}

/* ── Buttons ── */
.su-btn{display:inline-flex;align-items:center;gap:8px;padding:14px 32px;border-radius:var(--su-radius);font-family:var(--su-sans);font-size:.95rem;font-weight:600;cursor:pointer;border:none;transition:all .25s;text-decoration:none}
.su-btn--primary{background:linear-gradient(135deg,var(--su-violet),#5B21B6);color:var(--su-white);box-shadow:0 4px 20px rgba(109,40,217,.4)}
.su-btn--primary:hover{transform:translateY(-2px);box-shadow:0 8px 32px rgba(109,40,217,.55)}
.su-btn--ghost{background:transparent;color:var(--su-white);border:1px solid var(--su-border)}
.su-btn--ghost:hover{border-color:rgba(255,255,255,.3);background:rgba(255,255,255,.05)}
.su-btn--cyan{background:linear-gradient(135deg,var(--su-cyan),#0891B2);color:var(--su-void)}
.su-btn--cyan:hover{transform:translateY(-2px);box-shadow:0 8px 32px rgba(6,182,212,.45)}

/* ═══════════════════════════════════════════
   HERO
═══════════════════════════════════════════ */
.su-hero{
  position:relative;min-height:100vh;
  background:var(--su-void);
  display:flex;flex-direction:column;justify-content:center;
  overflow:hidden;padding:100px 0 60px;
}

/* Starfield */
.su-stars{position:absolute;inset:0;pointer-events:none}
.su-star{
  position:absolute;
  width:2px;height:2px;border-radius:50%;
  background:var(--su-white);
  animation:su-twinkle var(--su-sd,3s) ease-in-out infinite alternate;
  opacity:var(--su-so,.4);
}
@keyframes su-twinkle{from{opacity:var(--su-so,.4);transform:scale(1)}to{opacity:.05;transform:scale(.5)}}

/* Aurora */
.su-aurora{
  position:absolute;
  pointer-events:none;
}
.su-aurora--1{
  top:-200px;left:-100px;
  width:700px;height:500px;
  background:radial-gradient(ellipse,rgba(109,40,217,.2) 0%,transparent 65%);
  animation:su-aurora-drift 12s ease-in-out infinite alternate;
}
.su-aurora--2{
  top:-100px;right:-150px;
  width:500px;height:400px;
  background:radial-gradient(ellipse,rgba(6,182,212,.15) 0%,transparent 65%);
  animation:su-aurora-drift 9s ease-in-out infinite alternate-reverse;
}
@keyframes su-aurora-drift{from{transform:translate(0,0) scale(1)}to{transform:translate(40px,30px) scale(1.1)}}

.su-hero__inner{
  position:relative;z-index:2;
  display:grid;grid-template-columns:1fr 520px;
  gap:60px;align-items:center;
  max-width:1160px;margin:0 auto;padding:0 24px;
}

/* Copy */
.su-hero__pill{
  display:inline-flex;align-items:center;gap:8px;
  background:rgba(109,40,217,.18);border:1px solid rgba(139,92,246,.35);
  border-radius:20px;padding:6px 16px;
  font-size:.78rem;font-weight:600;color:var(--su-violet-light);
  margin-bottom:24px;
}
.su-hero__pill::before{content:'🚀';font-size:.85rem}
.su-h1 .su-grad{display:block}
.su-hero__desc{
  font-size:1.05rem;color:var(--su-smoke);line-height:1.8;
  margin:24px 0 36px;max-width:540px;
}
.su-hero__ctas{display:flex;gap:14px;flex-wrap:wrap}
.su-hero__social-proof{
  margin-top:28px;
  display:flex;align-items:center;gap:12px;
  font-size:.82rem;color:var(--su-smoke);
}
.su-avatar-stack{display:flex}
.su-avatar-stack .su-av{
  width:30px;height:30px;border-radius:50%;
  border:2px solid var(--su-void);
  font-size:.7rem;font-weight:700;
  display:flex;align-items:center;justify-content:center;
  margin-left:-8px;
}
.su-avatar-stack .su-av:first-child{margin-left:0}
.su-social-stars{color:#FBBF24;font-size:.85rem}

/* ── Hero Scene: SaaS Dashboard ── */
.su-hero__scene{
  position:relative;
  width:520px;height:420px;flex-shrink:0;
}

/* Browser chrome */
.su-browser{
  position:absolute;
  top:0;left:0;right:0;
  height:380px;
  background:linear-gradient(160deg,#1E293B,#0F172A);
  border-radius:12px;
  border:1px solid rgba(255,255,255,.08);
  box-shadow:var(--su-shadow),var(--su-shadow-glow);
  overflow:hidden;
}
/* Browser toolbar */
.su-browser::before{
  content:'';position:absolute;
  top:0;left:0;right:0;height:36px;
  background:#1E293B;
  border-bottom:1px solid rgba(255,255,255,.06);
}
/* Traffic lights */
.su-browser::after{
  content:'';position:absolute;
  top:11px;left:12px;
  width:10px;height:10px;border-radius:50%;
  background:#FF5F57;
  box-shadow:18px 0 0 #FEBC2E,36px 0 0 #28C840;
}
/* URL bar */
.su-urlbar{
  position:absolute;
  top:8px;left:66px;right:16px;height:20px;
  background:rgba(255,255,255,.06);
  border-radius:4px;
}

/* Dashboard layout inside browser */
.su-dash{
  position:absolute;
  top:36px;left:0;right:0;bottom:0;
  display:grid;
  grid-template-columns:140px 1fr;
}
/* Sidebar */
.su-dash__sidebar{
  background:rgba(255,255,255,.03);
  border-right:1px solid rgba(255,255,255,.05);
  padding:16px 10px;
}
.su-dash__logo{
  width:80px;height:10px;
  background:linear-gradient(90deg,var(--su-violet-light),var(--su-cyan));
  border-radius:5px;margin-bottom:20px;
}
.su-dash__nav-item{
  height:8px;border-radius:4px;margin-bottom:10px;
  background:rgba(255,255,255,.08);
}
.su-dash__nav-item.su-active{
  background:linear-gradient(90deg,rgba(109,40,217,.5),rgba(6,182,212,.3));
  width:85%;
}
/* Main panel */
.su-dash__main{padding:14px}
/* KPI row */
.su-kpi-row{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px}
.su-kpi{
  background:rgba(255,255,255,.04);
  border:1px solid rgba(255,255,255,.06);
  border-radius:6px;padding:10px;
}
.su-kpi__val{font-family:var(--su-serif);font-size:.9rem;font-weight:700;color:var(--su-white)}
.su-kpi__lbl{font-size:.55rem;color:var(--su-smoke);margin-top:2px}
.su-kpi__delta{font-size:.55rem;font-weight:600;margin-top:4px}
.su-kpi__delta.su-up{color:var(--su-lime)}
.su-kpi__delta.su-down{color:#F87171}
/* Chart area */
.su-chart-area{
  background:rgba(255,255,255,.03);
  border:1px solid rgba(255,255,255,.06);
  border-radius:6px;padding:10px;
  height:110px;position:relative;overflow:hidden;
}
.su-chart-title{font-size:.55rem;color:var(--su-smoke);margin-bottom:8px}
/* Area chart */
.su-chart-area svg{width:100%;height:80px}
/* Activity feed */
.su-activity{margin-top:10px}
.su-activity-row{
  height:6px;border-radius:3px;
  background:rgba(255,255,255,.06);margin-bottom:6px;
}
.su-activity-row:nth-child(1){width:90%;background:rgba(109,40,217,.25)}
.su-activity-row:nth-child(2){width:70%}
.su-activity-row:nth-child(3){width:55%;background:rgba(6,182,212,.2)}

/* Floating notification */
.su-notif{
  position:absolute;
  bottom:20px;right:-10px;
  background:linear-gradient(135deg,#1E293B,#0F172A);
  border:1px solid rgba(109,40,217,.4);
  border-radius:10px;padding:12px 16px;
  font-size:.72rem;
  box-shadow:0 8px 24px rgba(0,0,0,.5);
  animation:su-notif-in .6s ease-out forwards,su-float 4s ease-in-out 1s infinite;
  min-width:170px;
}
@keyframes su-notif-in{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:none}}
@keyframes su-float{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}
.su-notif__header{color:var(--su-lime);font-weight:700;margin-bottom:4px}
.su-notif__body{color:var(--su-smoke)}

/* Cursor blink */
.su-cursor{
  position:absolute;
  width:16px;height:16px;
  background:rgba(255,255,255,.7);
  border-radius:50%;
  pointer-events:none;
  animation:su-cursor-move 5s ease-in-out infinite;
}
@keyframes su-cursor-move{
  0%{transform:translate(200px,100px)}
  25%{transform:translate(300px,60px)}
  50%{transform:translate(250px,160px)}
  75%{transform:translate(180px,120px)}
  100%{transform:translate(200px,100px)}
}

/* ── Hero Metrics below ── */
.su-hero__metrics{
  position:relative;z-index:2;
  max-width:1160px;margin:48px auto 0;padding:0 24px;
  display:grid;grid-template-columns:repeat(4,1fr);
  border-top:1px solid var(--su-border);
}
.su-hero__metric{
  padding:24px 20px;border-right:1px solid var(--su-border);text-align:center;
}
.su-hero__metric:last-child{border-right:none}
.su-hero__metric-val{
  font-family:var(--su-serif);font-size:1.9rem;font-weight:700;
  background:linear-gradient(135deg,var(--su-white),var(--su-cyan));
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
}
.su-hero__metric-lbl{font-size:.78rem;color:var(--su-smoke);margin-top:4px}

/* ═══════════════════════════════════════════
   LOGOS
═══════════════════════════════════════════ */
.su-logos{
  background:var(--su-deep);
  border-top:1px solid var(--su-border);
  border-bottom:1px solid var(--su-border);
  padding:32px 0;
}
.su-logos__label{
  font-size:.72rem;font-weight:600;letter-spacing:.15em;text-transform:uppercase;
  color:rgba(255,255,255,.3);text-align:center;margin-bottom:24px;
}
.su-logos__track{
  display:flex;align-items:center;justify-content:center;
  gap:48px;flex-wrap:wrap;
}
.su-logo-pill{
  background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);
  border-radius:6px;padding:10px 24px;
  font-family:var(--su-serif);font-size:.85rem;font-weight:700;
  color:rgba(255,255,255,.35);letter-spacing:.04em;
}

/* ═══════════════════════════════════════════
   FEATURES
═══════════════════════════════════════════ */
.su-features{}
.su-features__grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:56px;
}
.su-feat{
  background:var(--su-surface);
  border:1px solid var(--su-border);
  border-radius:10px;padding:32px;
  position:relative;overflow:hidden;
  transition:all .3s;
}
.su-feat::before{
  content:'';position:absolute;
  inset:0;
  background:linear-gradient(135deg,rgba(109,40,217,.08),transparent);
  opacity:0;transition:opacity .3s;
}
.su-feat:hover{border-color:rgba(139,92,246,.3);transform:translateY(-4px);box-shadow:0 8px 32px rgba(0,0,0,.4)}
.su-feat:hover::before{opacity:1}
.su-feat__icon{
  width:48px;height:48px;
  background:linear-gradient(135deg,rgba(109,40,217,.25),rgba(6,182,212,.15));
  border:1px solid rgba(139,92,246,.3);
  border-radius:10px;display:flex;align-items:center;justify-content:center;
  font-size:1.4rem;margin-bottom:20px;
}
.su-feat h3{font-family:var(--su-serif);font-size:1.1rem;margin-bottom:10px}
.su-feat p{font-size:.875rem;color:var(--su-smoke);line-height:1.65}
.su-feat__tag{
  display:inline-block;
  background:rgba(132,204,22,.12);border:1px solid rgba(132,204,22,.25);
  color:var(--su-lime);font-size:.68rem;font-weight:700;letter-spacing:.08em;
  padding:3px 10px;border-radius:12px;margin-top:16px;text-transform:uppercase;
}

/* ═══════════════════════════════════════════
   HOW IT WORKS
═══════════════════════════════════════════ */
.su-how{background:var(--su-surface)}
.su-how__steps{
  display:grid;grid-template-columns:repeat(4,1fr);gap:24px;margin-top:56px;
  position:relative;
}
.su-how__steps::before{
  content:'';position:absolute;
  top:28px;left:12.5%;right:12.5%;height:1px;
  background:linear-gradient(90deg,transparent,var(--su-violet),var(--su-cyan),transparent);
}
.su-how-step{text-align:center;position:relative}
.su-how-step__num{
  width:56px;height:56px;border-radius:50%;
  background:linear-gradient(135deg,var(--su-violet),#5B21B6);
  display:flex;align-items:center;justify-content:center;
  font-family:var(--su-serif);font-size:1.2rem;font-weight:700;
  margin:0 auto 20px;position:relative;z-index:1;
  box-shadow:0 0 0 8px rgba(109,40,217,.12);
}
.su-how-step h3{font-family:var(--su-serif);font-size:1rem;margin-bottom:8px}
.su-how-step p{font-size:.85rem;color:var(--su-smoke);line-height:1.65}

/* ═══════════════════════════════════════════
   PRICING
═══════════════════════════════════════════ */
.su-pricing{}
.su-pricing__grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:56px;align-items:start;
}
.su-plan{
  background:var(--su-surface);border:1px solid var(--su-border);
  border-radius:12px;padding:36px 28px;
  transition:all .3s;position:relative;overflow:hidden;
}
.su-plan:hover{box-shadow:var(--su-shadow)}
.su-plan--featured{
  border-color:rgba(109,40,217,.6);
  background:linear-gradient(160deg,rgba(109,40,217,.12),rgba(6,182,212,.06));
  transform:scale(1.04);
  box-shadow:0 0 60px rgba(109,40,217,.2);
}
.su-plan__badge{
  position:absolute;top:-1px;right:24px;
  background:linear-gradient(135deg,var(--su-violet),var(--su-cyan));
  color:var(--su-white);font-size:.68rem;font-weight:700;letter-spacing:.08em;
  padding:4px 14px;border-radius:0 0 8px 8px;text-transform:uppercase;
}
.su-plan__tier{font-size:.72rem;font-weight:700;letter-spacing:.15em;text-transform:uppercase;color:var(--su-smoke);margin-bottom:8px}
.su-plan--featured .su-plan__tier{color:var(--su-cyan)}
.su-plan__name{font-family:var(--su-serif);font-size:1.3rem;margin-bottom:16px}
.su-plan__price{
  font-family:var(--su-serif);font-size:2.8rem;font-weight:700;
  margin-bottom:4px;
}
.su-plan__price sup{font-size:1.2rem;vertical-align:top;margin-top:8px;color:var(--su-smoke)}
.su-plan__price span{font-size:.9rem;color:var(--su-smoke);font-family:var(--su-sans);font-weight:400}
.su-plan__desc{font-size:.85rem;color:var(--su-smoke);margin:12px 0 24px;line-height:1.6}
.su-plan__divider{height:1px;background:var(--su-border);margin:24px 0}
.su-plan__features{list-style:none}
.su-plan__features li{
  font-size:.875rem;color:var(--su-smoke);padding:8px 0;
  display:flex;align-items:flex-start;gap:10px;
  border-bottom:1px solid var(--su-border);
}
.su-plan__features li:last-child{border-bottom:none}
.su-plan__features li::before{content:'✓';color:var(--su-lime);font-weight:700;flex-shrink:0}
.su-plan__features li.su-muted{color:rgba(148,163,184,.4)}
.su-plan__features li.su-muted::before{content:'—';color:rgba(148,163,184,.3)}
.su-plan__cta{margin-top:28px;width:100%;justify-content:center}

/* ═══════════════════════════════════════════
   TESTIMONIALS
═══════════════════════════════════════════ */
.su-testi-section{background:var(--su-deep)}
.su-testi-grid{
  display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-top:56px;
}
.su-testi{
  background:rgba(255,255,255,.03);border:1px solid var(--su-border);
  border-radius:10px;padding:28px;transition:all .3s;
}
.su-testi:hover{border-color:rgba(139,92,246,.3);box-shadow:0 8px 24px rgba(0,0,0,.4)}
.su-testi__stars{color:#FBBF24;font-size:.85rem;margin-bottom:14px}
.su-testi__text{font-size:.9rem;color:rgba(255,255,255,.7);line-height:1.75;margin-bottom:20px}
.su-testi__author{display:flex;align-items:center;gap:12px}
.su-testi__av{
  width:38px;height:38px;border-radius:50%;
  display:flex;align-items:center;justify-content:center;
  font-weight:700;font-size:.85rem;flex-shrink:0;
}
.su-testi__name{font-weight:600;font-size:.875rem}
.su-testi__role{font-size:.75rem;color:var(--su-smoke);margin-top:1px}

/* ═══════════════════════════════════════════
   INTEGRATION GRID
═══════════════════════════════════════════ */
.su-integrations{background:var(--su-void)}
.su-int-grid{
  display:grid;grid-template-columns:repeat(6,1fr);gap:16px;margin-top:48px;
}
.su-int-tile{
  background:var(--su-surface);border:1px solid var(--su-border);
  border-radius:10px;padding:20px 12px;
  text-align:center;transition:all .3s;
  display:flex;flex-direction:column;align-items:center;gap:8px;
}
.su-int-tile:hover{border-color:rgba(139,92,246,.3);transform:translateY(-3px);box-shadow:0 8px 20px rgba(0,0,0,.4)}
.su-int-tile__icon{font-size:1.6rem}
.su-int-tile__name{font-size:.72rem;font-weight:600;color:var(--su-smoke)}

/* ═══════════════════════════════════════════
   FAQ
═══════════════════════════════════════════ */
.su-faq{background:var(--su-surface)}
.su-faq__list{max-width:720px;margin:48px auto 0}
.su-faq-item{border-bottom:1px solid var(--su-border)}
.su-faq-q{
  width:100%;background:none;border:none;
  display:flex;justify-content:space-between;align-items:center;
  padding:20px 0;cursor:pointer;text-align:left;
  font-family:var(--su-sans);font-size:.975rem;font-weight:600;color:var(--su-white);
  gap:16px;transition:color .2s;
}
.su-faq-q:hover{color:var(--su-cyan)}
.su-faq-icon{
  width:26px;height:26px;border-radius:50%;
  background:rgba(109,40,217,.25);border:1px solid rgba(139,92,246,.3);
  color:var(--su-violet-light);
  display:flex;align-items:center;justify-content:center;
  font-size:1rem;flex-shrink:0;transition:transform .3s,background .2s;
}
.su-faq-item.su-open .su-faq-icon{transform:rotate(45deg);background:rgba(6,182,212,.2);color:var(--su-cyan)}
.su-faq-a{max-height:0;overflow:hidden;transition:max-height .4s ease}
.su-faq-a p{padding:0 0 20px;font-size:.9rem;color:var(--su-smoke);line-height:1.7}

/* ═══════════════════════════════════════════
   FINAL CTA
═══════════════════════════════════════════ */
.su-cta-banner{
  position:relative;overflow:hidden;
  background:linear-gradient(135deg,rgba(109,40,217,.3),rgba(6,182,212,.2));
  border-top:1px solid rgba(109,40,217,.3);
  border-bottom:1px solid rgba(6,182,212,.2);
  padding:88px 0;text-align:center;
}
.su-cta-banner::before{
  content:'';position:absolute;inset:0;
  background:var(--su-void);z-index:0;
}
.su-cta-banner__inner{position:relative;z-index:1}
.su-cta-banner__glow{
  position:absolute;
  top:50%;left:50%;transform:translate(-50%,-50%);
  width:600px;height:300px;
  background:radial-gradient(ellipse,rgba(109,40,217,.25) 0%,transparent 65%);
  pointer-events:none;
}
.su-cta-banner h2{
  font-family:var(--su-serif);font-size:clamp(1.8rem,3.5vw,2.8rem);
  margin-bottom:16px;
}
.su-cta-banner p{color:var(--su-smoke);font-size:1.05rem;margin-bottom:36px}
.su-cta-banner__btns{display:flex;justify-content:center;gap:16px;flex-wrap:wrap}
.su-cta-banner .su-btn--primary{font-size:1.05rem;padding:16px 40px}
.su-guarantee{
  font-size:.8rem;color:rgba(148,163,184,.6);margin-top:20px;
}
.su-guarantee span{color:var(--su-lime);font-weight:600}

/* ── Reveal ── */
.su-reveal{opacity:0;transform:translateY(24px);transition:opacity .6s ease,transform .6s ease}
.su-reveal.su-visible{opacity:1;transform:none}

/* ── Responsive ── */
@media(max-width:960px){
  .su-hero__inner{grid-template-columns:1fr}
  .su-hero__scene{display:none}
  .su-hero__metrics{grid-template-columns:repeat(2,1fr)}
  .su-features__grid{grid-template-columns:1fr 1fr}
  .su-how__steps{grid-template-columns:1fr 1fr}
  .su-how__steps::before{display:none}
  .su-pricing__grid{grid-template-columns:1fr}
  .su-plan--featured{transform:none}
  .su-testi-grid{grid-template-columns:1fr}
  .su-int-grid{grid-template-columns:repeat(3,1fr)}
}
@media(max-width:600px){
  .su-section{padding:60px 0}
  .su-features__grid{grid-template-columns:1fr}
  .su-int-grid{grid-template-columns:repeat(2,1fr)}
  .su-hero__metrics{grid-template-columns:1fr 1fr}
}
</style>

<div class="su-page">

<!-- ════════════════════════════════════════
     HERO
════════════════════════════════════════ -->
<section class="su-hero">
  <!-- Stars -->
  <div class="su-stars" aria-hidden="true">
    <?php
    srand(crc32('su-stars'));
    for($i=0;$i<80;$i++){
      $top=rand(0,100);$left=rand(0,100);
      $delay=round(rand(0,40)/10,1);$dur=round(rand(20,50)/10,1);$op=round(rand(2,7)/10,1);
      echo "<div class='su-star' style='top:{$top}%;left:{$left}%;--su-sd:{$dur}s;--su-so:{$op};animation-delay:{$delay}s'></div>";
    }
    ?>
  </div>
  <div class="su-aurora su-aurora--1" aria-hidden="true"></div>
  <div class="su-aurora su-aurora--2" aria-hidden="true"></div>

  <div class="su-hero__inner">
    <!-- Copy -->
    <div class="su-hero__copy">
      <div class="su-hero__pill">Trusted by 12,000+ teams worldwide</div>
      <h1 class="su-h1">
        Ship Faster,<br>
        <span class="su-grad">Scale Smarter.</span>
      </h1>
      <p class="su-hero__desc">Launchpad gives your team one unified platform to plan, build, track, and deploy — with AI-powered insights that turn data into decisions before your competition even notices the trend.</p>
      <div class="su-hero__ctas">
        <a href="#pricing" class="su-btn su-btn--primary">Start Free — No Card Needed</a>
        <a href="#features" class="su-btn su-btn--ghost">See How It Works →</a>
      </div>
      <div class="su-hero__social-proof">
        <div class="su-avatar-stack">
          <div class="su-av" style="background:#6D28D9">M</div>
          <div class="su-av" style="background:#0891B2">S</div>
          <div class="su-av" style="background:#059669">A</div>
          <div class="su-av" style="background:#D97706">T</div>
          <div class="su-av" style="background:#DC2626">L</div>
        </div>
        <div class="su-social-stars">★★★★★</div>
        <span>4.9/5 from 3,200+ reviews</span>
      </div>
    </div>

    <!-- Scene: SaaS Dashboard -->
    <div class="su-hero__scene" aria-hidden="true">
      <div class="su-browser">
        <div class="su-urlbar"></div>
        <div class="su-dash">
          <div class="su-dash__sidebar">
            <div class="su-dash__logo"></div>
            <?php for($i=0;$i<7;$i++): ?>
            <div class="su-dash__nav-item<?php echo $i===1?' su-active':''; ?>"></div>
            <?php endfor; ?>
          </div>
          <div class="su-dash__main">
            <div class="su-kpi-row">
              <div class="su-kpi"><div class="su-kpi__val">$48.2K</div><div class="su-kpi__lbl">MRR</div><div class="su-kpi__delta su-up">↑ 12.4%</div></div>
              <div class="su-kpi"><div class="su-kpi__val">1,284</div><div class="su-kpi__lbl">Active Users</div><div class="su-kpi__delta su-up">↑ 8.1%</div></div>
              <div class="su-kpi"><div class="su-kpi__val">94.2%</div><div class="su-kpi__lbl">Retention</div><div class="su-kpi__delta su-down">↓ 0.3%</div></div>
            </div>
            <div class="su-chart-area">
              <div class="su-chart-title">Revenue (last 30 days)</div>
              <svg viewBox="0 0 340 70" preserveAspectRatio="none" aria-hidden="true">
                <defs>
                  <linearGradient id="su-grad-fill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stop-color="#6D28D9" stop-opacity=".4"/>
                    <stop offset="100%" stop-color="#6D28D9" stop-opacity="0"/>
                  </linearGradient>
                </defs>
                <path d="M0,60 L20,55 L45,48 L70,50 L95,38 L120,35 L145,28 L170,30 L195,18 L220,15 L245,20 L270,10 L295,8 L320,4 L340,6 L340,70 L0,70 Z" fill="url(#su-grad-fill)"/>
                <path d="M0,60 L20,55 L45,48 L70,50 L95,38 L120,35 L145,28 L170,30 L195,18 L220,15 L245,20 L270,10 L295,8 L320,4 L340,6" fill="none" stroke="#8B5CF6" stroke-width="2"/>
              </svg>
            </div>
            <div class="su-activity">
              <div class="su-activity-row"></div>
              <div class="su-activity-row"></div>
              <div class="su-activity-row"></div>
            </div>
          </div>
        </div>
      </div>
      <!-- Notification -->
      <div class="su-notif">
        <div class="su-notif__header">🎉 New milestone!</div>
        <div class="su-notif__body">MRR crossed $50K target</div>
      </div>
      <!-- Cursor -->
      <div class="su-cursor"></div>
    </div>
  </div>

  <!-- Metrics bar -->
  <div class="su-hero__metrics">
    <div class="su-hero__metric">
      <div class="su-hero__metric-val su-counter" data-target="12" data-suffix="K+">0</div>
      <div class="su-hero__metric-lbl">Active Teams</div>
    </div>
    <div class="su-hero__metric">
      <div class="su-hero__metric-val su-counter" data-prefix="$" data-target="2.4" data-suffix="B">0</div>
      <div class="su-hero__metric-lbl">Revenue Tracked</div>
    </div>
    <div class="su-hero__metric">
      <div class="su-hero__metric-val su-counter" data-target="99.98" data-suffix="%">0</div>
      <div class="su-hero__metric-lbl">Uptime SLA</div>
    </div>
    <div class="su-hero__metric">
      <div class="su-hero__metric-val su-counter" data-target="4" data-suffix=" min">0</div>
      <div class="su-hero__metric-lbl">Avg. Onboarding</div>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     LOGOS
════════════════════════════════════════ -->
<div class="su-logos">
  <p class="su-logos__label">Powering teams at</p>
  <div class="su-logos__track">
    <?php
    $su_logos = ['Acme Corp','NovaBridge','Stackfire','Orbita','Zenloop','PulseHQ','Meridian','Quantix'];
    foreach($su_logos as $l): ?>
    <div class="su-logo-pill"><?php echo $l; ?></div>
    <?php endforeach; ?>
  </div>
</div>

<!-- ════════════════════════════════════════
     FEATURES
════════════════════════════════════════ -->
<section class="su-section su-features" id="features">
  <div class="su-wrap">
    <div class="su-hgroup su-center">
      <p class="su-eyebrow">Features</p>
      <h2 class="su-h2">Everything your team needs.<br><span class="su-grad">Nothing it doesn't.</span></h2>
      <p class="su-lead">Purpose-built for high-growth SaaS teams. From solo founders to 500-person engineering orgs — Launchpad adapts to how you actually work.</p>
    </div>
    <div class="su-features__grid">
      <?php
      $su_feats = [
        ['icon'=>'🧠','title'=>'AI-Powered Insights','desc'=>'Surface trends, anomalies, and opportunities automatically. Your AI analyst never sleeps, never misses a pattern.','tag'=>'Powered by GPT-4'],
        ['icon'=>'📊','title'=>'Unified Analytics','desc'=>'Every metric your team cares about — revenue, engagement, churn — in one real-time dashboard you can trust.','tag'=>'Real-time'],
        ['icon'=>'🔁','title'=>'Workflow Automation','desc'=>'Build no-code automation flows that eliminate the repetitive work draining your team\'s best hours.','tag'=>'No-code'],
        ['icon'=>'🚀','title'=>'One-Click Deploys','desc'=>'Push to production from anywhere. Rollback in seconds. Keep shipping at startup speed, at any scale.','tag'=>'CI/CD ready'],
        ['icon'=>'🔗','title'=>'120+ Integrations','desc'=>'Connect Slack, Salesforce, HubSpot, Stripe, GitHub, Notion, and 115+ more. Your stack, fully unified.','tag'=>'Zapier compatible'],
        ['icon'=>'🔒','title'=>'Enterprise Security','desc'=>'SOC 2 Type II certified. SSO, RBAC, audit logs, and GDPR compliance baked in — not bolted on.','tag'=>'SOC 2 certified'],
      ];
      foreach($su_feats as $f): ?>
      <div class="su-feat su-reveal">
        <div class="su-feat__icon"><?php echo $f['icon']; ?></div>
        <h3><?php echo $f['title']; ?></h3>
        <p><?php echo $f['desc']; ?></p>
        <span class="su-feat__tag"><?php echo $f['tag']; ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     HOW IT WORKS
════════════════════════════════════════ -->
<section class="su-section su-how" id="how-it-works">
  <div class="su-wrap">
    <div class="su-hgroup su-center">
      <p class="su-eyebrow">How It Works</p>
      <h2 class="su-h2">Up and running in minutes, not months.</h2>
      <p class="su-lead">We designed Launchpad so your team gets value on day one — not after a six-week implementation project.</p>
    </div>
    <div class="su-how__steps">
      <?php
      $su_steps = [
        ['num'=>'1','title'=>'Connect Your Stack','desc'=>'Link your existing tools in a few clicks. 120+ native integrations, zero custom code required.'],
        ['num'=>'2','title'=>'Configure Your Workspace','desc'=>'Choose your metrics, invite your team, and set up dashboards tailored to your business model.'],
        ['num'=>'3','title'=>'Let AI Do the Heavy Lifting','desc'=>'Launchpad\'s AI engine starts learning your patterns immediately and surfaces alerts and insights automatically.'],
        ['num'=>'4','title'=>'Scale With Confidence','desc'=>'As your team grows, Launchpad grows with you — from startup to enterprise without the migration headache.'],
      ];
      foreach($su_steps as $s): ?>
      <div class="su-how-step su-reveal">
        <div class="su-how-step__num"><?php echo $s['num']; ?></div>
        <h3><?php echo $s['title']; ?></h3>
        <p><?php echo $s['desc']; ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     INTEGRATIONS
════════════════════════════════════════ -->
<section class="su-section su-integrations" id="integrations">
  <div class="su-wrap">
    <div class="su-hgroup su-center">
      <p class="su-eyebrow">Integrations</p>
      <h2 class="su-h2">Plays well with your entire stack.</h2>
      <p class="su-lead">Native connections to the tools your team already loves — no middleware, no workarounds, no duct tape.</p>
    </div>
    <div class="su-int-grid">
      <?php
      $su_ints = [
        ['icon'=>'📧','name'=>'Slack'],['icon'=>'💳','name'=>'Stripe'],['icon'=>'🐙','name'=>'GitHub'],
        ['icon'=>'📦','name'=>'Notion'],['icon'=>'☁️','name'=>'Salesforce'],['icon'=>'🧲','name'=>'HubSpot'],
        ['icon'=>'📊','name'=>'Amplitude'],['icon'=>'🔴','name'=>'Segment'],['icon'=>'📬','name'=>'SendGrid'],
        ['icon'=>'🟡','name'=>'Jira'],['icon'=>'🔵','name'=>'Linear'],['icon'=>'🟢','name'=>'Vercel'],
      ];
      foreach($su_ints as $int): ?>
      <div class="su-int-tile su-reveal">
        <div class="su-int-tile__icon"><?php echo $int['icon']; ?></div>
        <div class="su-int-tile__name"><?php echo $int['name']; ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <p style="text-align:center;margin-top:28px;font-size:.875rem;color:var(--su-smoke)">+ 108 more integrations available in the app. Can't find yours? We build on request.</p>
  </div>
</section>

<!-- ════════════════════════════════════════
     PRICING
════════════════════════════════════════ -->
<section class="su-section su-pricing su-section--surface" id="pricing">
  <div class="su-wrap">
    <div class="su-hgroup su-center">
      <p class="su-eyebrow">Pricing</p>
      <h2 class="su-h2">Transparent pricing. No surprises.</h2>
      <p class="su-lead">Start free, upgrade when you're ready. Every plan includes a 14-day trial of all Pro features.</p>
    </div>
    <div class="su-pricing__grid">

      <div class="su-plan su-reveal">
        <div class="su-plan__tier">Starter</div>
        <div class="su-plan__name">For small teams</div>
        <div class="su-plan__price"><sup>$</sup>0 <span>/ month</span></div>
        <p class="su-plan__desc">Everything you need to get started — no credit card, no time limit.</p>
        <hr class="su-plan__divider">
        <ul class="su-plan__features">
          <li>Up to 3 users</li>
          <li>5 connected integrations</li>
          <li>Core analytics dashboard</li>
          <li>7-day data history</li>
          <li class="su-muted">AI insights engine</li>
          <li class="su-muted">Workflow automation</li>
          <li class="su-muted">Priority support</li>
        </ul>
        <a href="#contact" class="su-btn su-btn--ghost su-plan__cta">Get Started Free</a>
      </div>

      <div class="su-plan su-plan--featured su-reveal">
        <div class="su-plan__badge">Most Popular</div>
        <div class="su-plan__tier">Pro</div>
        <div class="su-plan__name">For growing teams</div>
        <div class="su-plan__price"><sup>$</sup>79 <span>/ month</span></div>
        <p class="su-plan__desc">Unlock AI, automation, and unlimited history. The plan most teams never leave.</p>
        <hr class="su-plan__divider">
        <ul class="su-plan__features">
          <li>Up to 25 users</li>
          <li>Unlimited integrations</li>
          <li>Advanced analytics + custom dashboards</li>
          <li>Unlimited data history</li>
          <li>AI insights engine</li>
          <li>Workflow automation (unlimited flows)</li>
          <li>Priority chat &amp; email support</li>
          <li>API access</li>
        </ul>
        <a href="#contact" class="su-btn su-btn--primary su-plan__cta">Start 14-Day Free Trial</a>
      </div>

      <div class="su-plan su-reveal">
        <div class="su-plan__tier">Enterprise</div>
        <div class="su-plan__name">For large organisations</div>
        <div class="su-plan__price"><span style="font-size:1.1rem">Custom pricing</span></div>
        <p class="su-plan__desc">Tailored contracts, SLAs, and dedicated support for teams of 50+.</p>
        <hr class="su-plan__divider">
        <ul class="su-plan__features">
          <li>Unlimited users</li>
          <li>Everything in Pro</li>
          <li>SSO &amp; SAML authentication</li>
          <li>Custom data retention policies</li>
          <li>RBAC &amp; advanced permissions</li>
          <li>Dedicated Customer Success Manager</li>
          <li>SLA-backed 99.99% uptime</li>
          <li>On-premise deployment option</li>
        </ul>
        <a href="#contact" class="su-btn su-btn--cyan su-plan__cta">Talk to Sales</a>
      </div>

    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     TESTIMONIALS
════════════════════════════════════════ -->
<section class="su-section su-testi-section" id="reviews">
  <div class="su-wrap">
    <div class="su-hgroup su-center">
      <p class="su-eyebrow">Customer Stories</p>
      <h2 class="su-h2">Loved by teams who ship.</h2>
    </div>
    <div class="su-testi-grid">
      <?php
      $su_testis = [
        ['text'=>'We replaced four separate tools with Launchpad and cut our analytics stack cost by 60%. The AI insights surface problems we wouldn\'t have caught for weeks.','name'=>'Petra Vann','role'=>'Head of Product, Orbita','av'=>'P','col'=>'#6D28D9'],
        ['text'=>'Onboarding took 20 minutes. Seriously. We connected Stripe, GitHub and Slack, built a dashboard, and had our first insight notification before lunch. It\'s obscenely easy to use.','name'=>'James Okafor','role'=>'CTO, Stackfire','av'=>'J','col'=>'#0891B2'],
        ['text'=>'We evaluated six platforms. Launchpad was the only one that didn\'t require a 3-month implementation and a dedicated ops hire. That was the decision.','name'=>'Simone Brandt','role'=>'CEO, NovaBridge','av'=>'S','col'=>'#059669'],
      ];
      foreach($su_testis as $t): ?>
      <div class="su-testi su-reveal">
        <div class="su-testi__stars">★★★★★</div>
        <p class="su-testi__text"><?php echo $t['text']; ?></p>
        <div class="su-testi__author">
          <div class="su-testi__av" style="background:<?php echo $t['col']; ?>"><?php echo $t['av']; ?></div>
          <div>
            <div class="su-testi__name"><?php echo $t['name']; ?></div>
            <div class="su-testi__role"><?php echo $t['role']; ?></div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     FAQ
════════════════════════════════════════ -->
<section class="su-section su-faq" id="faq">
  <div class="su-wrap">
    <div class="su-hgroup su-center">
      <p class="su-eyebrow">FAQ</p>
      <h2 class="su-h2">Questions? We've got answers.</h2>
    </div>
    <div class="su-faq__list">
      <?php
      $su_faqs = [
        ['q'=>'Is there really no credit card required for the free plan?','a'=>'Correct — the Starter plan is permanently free with no credit card required. You can upgrade to Pro at any time if you need AI insights, automation, or more than 3 users. We\'ll never auto-charge you without your explicit consent.'],
        ['q'=>'Can I migrate from another platform?','a'=>'Yes. Our migration team will import your historical data, dashboards, and automation flows from most major platforms (Mixpanel, Amplitude, Mode, Looker) at no extra cost for Pro and Enterprise customers. The process typically takes 24–48 hours.'],
        ['q'=>'How does the AI insights engine work?','a'=>'Launchpad\'s AI continuously monitors your connected data streams for anomalies, trend changes, and correlation patterns. It learns your business model over time and delivers proactive alerts and recommendations via Slack, email, or in-app notifications.'],
        ['q'=>'What does your 99.98% uptime SLA actually mean?','a'=>'That\'s less than 90 minutes of downtime per year. We publish a real-time status page, offer automatic credit for any SLA breach, and maintain redundant infrastructure across three geographic regions. Enterprise plans include a 99.99% SLA.'],
        ['q'=>'Is Launchpad SOC 2 compliant?','a'=>'Yes. We are SOC 2 Type II certified. We also comply with GDPR, CCPA, and offer DPA agreements for all paid plans. Enterprise customers can request our full security documentation and penetration testing reports.'],
        ['q'=>'Can I cancel at any time?','a'=>'Absolutely. There are no lock-in contracts on monthly plans. Cancel any time from your account settings and you won\'t be charged again. Annual plan cancellations receive a pro-rated refund for unused months.'],
      ];
      foreach($su_faqs as $faq): ?>
      <div class="su-faq-item">
        <button class="su-faq-q" aria-expanded="false">
          <?php echo $faq['q']; ?>
          <span class="su-faq-icon" aria-hidden="true">+</span>
        </button>
        <div class="su-faq-a">
          <p><?php echo $faq['a']; ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     CTA BANNER
════════════════════════════════════════ -->
<div class="su-cta-banner">
  <div class="su-cta-banner__glow" aria-hidden="true"></div>
  <div class="su-cta-banner__inner su-wrap">
    <h2>Ready to launch smarter?</h2>
    <p>Join 12,000+ teams shipping faster with Launchpad. Free forever — upgrade when you need to.</p>
    <div class="su-cta-banner__btns">
      <a href="#pricing" class="su-btn su-btn--primary">Start Free Today →</a>
      <a href="#contact" class="su-btn su-btn--ghost">Book a Demo</a>
    </div>
    <p class="su-guarantee">✓ <span>No credit card</span> &nbsp;·&nbsp; ✓ <span>Setup in 4 minutes</span> &nbsp;·&nbsp; ✓ <span>Cancel anytime</span></p>
  </div>
</div>

</div><!-- .su-page -->

<!-- ════════════════════════════════════════
     SECURITY & COMPLIANCE SECTION
════════════════════════════════════════ -->
<style>
.su-security{background:var(--su-deep);border-top:1px solid var(--su-border);border-bottom:1px solid var(--su-border)}
.su-security__grid{display:grid;grid-template-columns:repeat(4,1fr);gap:24px;margin-top:48px}
.su-sec-card{
  background:rgba(255,255,255,.03);border:1px solid var(--su-border);
  border-radius:10px;padding:28px 24px;text-align:center;transition:all .3s;
}
.su-sec-card:hover{border-color:rgba(139,92,246,.3);transform:translateY(-3px)}
.su-sec-card__icon{font-size:2rem;margin-bottom:14px}
.su-sec-card h3{font-family:var(--su-serif);font-size:1rem;margin-bottom:8px}
.su-sec-card p{font-size:.8rem;color:var(--su-smoke);line-height:1.6}
.su-sec-badges{
  display:flex;justify-content:center;gap:16px;flex-wrap:wrap;margin-top:40px;
}
.su-sec-badge{
  background:rgba(132,204,22,.08);border:1px solid rgba(132,204,22,.2);
  border-radius:8px;padding:12px 20px;
  font-size:.78rem;font-weight:700;color:var(--su-lime);
  display:flex;align-items:center;gap:8px;
}
.su-sec-badge::before{content:'✓';font-weight:900}

/* Demo form */
.su-demo{background:var(--su-void)}
.su-demo__inner{
  display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:start;
}
.su-demo__copy h2{font-size:clamp(1.6rem,3vw,2.4rem);margin-bottom:16px}
.su-demo__copy p{color:var(--su-smoke);line-height:1.75;margin-bottom:28px}
.su-demo__perk{display:flex;align-items:flex-start;gap:12px;margin-bottom:18px}
.su-demo__perk-icon{
  width:36px;height:36px;border-radius:8px;flex-shrink:0;
  background:rgba(109,40,217,.2);border:1px solid rgba(139,92,246,.3);
  display:flex;align-items:center;justify-content:center;font-size:1rem;
}
.su-demo__perk-text strong{display:block;font-size:.9rem;margin-bottom:3px}
.su-demo__perk-text span{font-size:.82rem;color:var(--su-smoke)}

.su-demo__form{
  background:rgba(255,255,255,.03);border:1px solid var(--su-border);
  border-radius:12px;padding:36px;
}
.su-df-row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.su-df{margin-bottom:18px}
.su-df label{display:block;font-size:.78rem;font-weight:600;color:rgba(255,255,255,.5);margin-bottom:7px;letter-spacing:.04em}
.su-df input,
.su-df select,
.su-df textarea{
  width:100%;background:rgba(255,255,255,.05);border:1px solid var(--su-border);
  border-radius:6px;padding:11px 14px;
  font-family:var(--su-sans);font-size:.875rem;color:var(--su-white);outline:none;
  transition:border-color .2s;
}
.su-df input::placeholder,.su-df textarea::placeholder{color:rgba(255,255,255,.25)}
.su-df input:focus,.su-df select:focus,.su-df textarea:focus{border-color:var(--su-violet-light)}
.su-df select option{background:var(--su-deep)}
.su-df textarea{resize:vertical;min-height:90px}
@media(max-width:960px){
  .su-security__grid{grid-template-columns:1fr 1fr}
  .su-demo__inner{grid-template-columns:1fr}
}
@media(max-width:600px){
  .su-security__grid{grid-template-columns:1fr 1fr}
  .su-df-row{grid-template-columns:1fr}
}
</style>

<section class="su-section su-security" id="security">
  <div class="su-wrap">
    <div class="su-hgroup su-center">
      <p class="su-eyebrow">Security &amp; Compliance</p>
      <h2 class="su-h2">Enterprise-grade security.<br><span class="su-grad">Startup-friendly pricing.</span></h2>
      <p class="su-lead">We treat your data the way you treat your most important asset — with rigorous controls, zero compromises, and full transparency.</p>
    </div>
    <div class="su-security__grid">
      <?php
      $su_secs = [
        ['icon'=>'🔒','title'=>'SOC 2 Type II','desc'=>'Independently audited annual certification covering security, availability, and confidentiality controls.'],
        ['icon'=>'🛡️','title'=>'End-to-End Encryption','desc'=>'AES-256 encryption at rest, TLS 1.3 in transit. Your data is encrypted at every layer, always.'],
        ['icon'=>'🌍','title'=>'GDPR &amp; CCPA Ready','desc'=>'Full data residency controls, automated DSAR handling, and DPA agreements included on all paid plans.'],
        ['icon'=>'👁️','title'=>'Full Audit Trail','desc'=>'Every action logged with user, timestamp, and context. Immutable audit logs retained for 24 months.'],
      ];
      foreach($su_secs as $s): ?>
      <div class="su-sec-card su-reveal">
        <div class="su-sec-card__icon"><?php echo $s['icon']; ?></div>
        <h3><?php echo $s['title']; ?></h3>
        <p><?php echo $s['desc']; ?></p>
      </div>
      <?php endforeach; ?>
    </div>
    <div class="su-sec-badges">
      <?php
      $su_badges = ['SOC 2 Type II Certified','GDPR Compliant','CCPA Compliant','HIPAA Ready','ISO 27001 Aligned','Pen-tested quarterly'];
      foreach($su_badges as $b): ?>
      <span class="su-sec-badge"><?php echo $b; ?></span>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ════════════════════════════════════════
     DEMO / CONTACT FORM
════════════════════════════════════════ -->
<section class="su-section su-demo" id="contact">
  <div class="su-wrap">
    <div class="su-demo__inner">
      <div class="su-demo__copy">
        <p class="su-eyebrow">Book a Demo</p>
        <h2 class="su-demo__copy su-h2">See Launchpad live in 30 minutes.</h2>
        <p>Our product team will walk you through a personalised demo tailored to your stack, your metrics, and your growth goals. No generic slide decks.</p>
        <?php
        $su_perks = [
          ['icon'=>'⚡','title'=>'Same-day scheduling','desc'=>'Slots available 8am–8pm in your timezone, Monday to Friday.'],
          ['icon'=>'🎯','title'=>'Personalised to your use case','desc'=>'We\'ll look at your current stack before the call and tailor the demo accordingly.'],
          ['icon'=>'🤝','title'=>'Zero pressure','desc'=>'If Launchpad isn\'t right for you, we\'ll say so and point you somewhere better.'],
        ];
        foreach($su_perks as $p): ?>
        <div class="su-demo__perk">
          <div class="su-demo__perk-icon"><?php echo $p['icon']; ?></div>
          <div class="su-demo__perk-text">
            <strong><?php echo $p['title']; ?></strong>
            <span><?php echo $p['desc']; ?></span>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <div class="su-demo__form">
        <form method="post" action="">
          <?php wp_nonce_field('tf_su_booking','tf_su_nonce'); ?>
          <div class="su-df-row">
            <div class="su-df">
              <label for="su-fname">First Name *</label>
              <input type="text" id="su-fname" name="su_fname" placeholder="Sam" required>
            </div>
            <div class="su-df">
              <label for="su-lname">Last Name *</label>
              <input type="text" id="su-lname" name="su_lname" placeholder="Rivera" required>
            </div>
          </div>
          <div class="su-df">
            <label for="su-email">Work Email *</label>
            <input type="email" id="su-email" name="su_email" placeholder="sam@company.com" required>
          </div>
          <div class="su-df-row">
            <div class="su-df">
              <label for="su-company">Company *</label>
              <input type="text" id="su-company" name="su_company" placeholder="Acme Inc" required>
            </div>
            <div class="su-df">
              <label for="su-size">Team Size</label>
              <select id="su-size" name="su_size">
                <option>1–10</option>
                <option>11–50</option>
                <option>51–200</option>
                <option>200+</option>
              </select>
            </div>
          </div>
          <div class="su-df">
            <label for="su-use">Primary Use Case</label>
            <select id="su-use" name="su_use">
              <option value="">Select…</option>
              <option>Revenue &amp; Growth Analytics</option>
              <option>Product &amp; Engagement Tracking</option>
              <option>Engineering Performance</option>
              <option>Customer Success</option>
              <option>Unified company dashboard</option>
              <option>Other</option>
            </select>
          </div>
          <div class="su-df">
            <label for="su-message">Anything else we should know?</label>
            <textarea id="su-message" name="su_message" placeholder="Tell us about your current setup, biggest pain point, or anything that would help us tailor the demo…"></textarea>
          </div>
          <button type="submit" class="su-btn su-btn--primary" style="width:100%;justify-content:center;margin-top:4px">Book My Demo →</button>
          <p style="text-align:center;font-size:.75rem;color:rgba(148,163,184,.5);margin-top:12px">No spam. Unsubscribe at any time. We respect your privacy.</p>
        </form>
      </div>
    </div>
  </div>
</section>

<script>
(function(){
  'use strict';
  /* ── Counters ── */
  function suEase(t){return 1-Math.pow(1-t,3)}
  document.querySelectorAll('.su-counter').forEach(function(el){
    var target=parseFloat(el.dataset.target);
    if(isNaN(target))return;
    var prefix=el.dataset.prefix||'';var suffix=el.dataset.suffix||'';
    var isFloat=target%1!==0;var started=false;
    var obs=new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(entry.isIntersecting&&!started){
          started=true;var start=performance.now();var dur=1600;
          function tick(now){
            var t=Math.min((now-start)/dur,1);
            var val=suEase(t)*target;
            el.textContent=prefix+(isFloat?val.toFixed(2):Math.round(val))+suffix;
            if(t<1)requestAnimationFrame(tick);
          }
          requestAnimationFrame(tick);obs.disconnect();
        }
      });
    },{threshold:.3});
    obs.observe(el);
  });
  /* ── Reveal ── */
  var reveals=document.querySelectorAll('.su-reveal');
  if(reveals.length){
    var ro=new IntersectionObserver(function(entries){
      entries.forEach(function(entry,i){
        if(entry.isIntersecting){
          setTimeout(function(){entry.target.classList.add('su-visible');},i*70);
          ro.unobserve(entry.target);
        }
      });
    },{threshold:.12});
    reveals.forEach(function(el){ro.observe(el);});
  }
  /* ── FAQ ── */
  document.querySelectorAll('.su-faq-q').forEach(function(btn){
    btn.addEventListener('click',function(){
      var item=btn.closest('.su-faq-item');
      var ans=item.querySelector('.su-faq-a');
      var isOpen=item.classList.contains('su-open');
      document.querySelectorAll('.su-faq-item.su-open').forEach(function(oi){
        oi.classList.remove('su-open');
        oi.querySelector('.su-faq-a').style.maxHeight='0';
        oi.querySelector('.su-faq-q').setAttribute('aria-expanded','false');
      });
      if(!isOpen){
        item.classList.add('su-open');
        ans.style.maxHeight=ans.scrollHeight+'px';
        btn.setAttribute('aria-expanded','true');
      }
    });
  });
  /* ── Smooth scroll ── */
  document.querySelectorAll('a[href^="#"]').forEach(function(a){
    a.addEventListener('click',function(e){
      var t=document.querySelector(a.getAttribute('href'));
      if(t){e.preventDefault();t.scrollIntoView({behavior:'smooth',block:'start'});}
    });
  });
})();
</script>

<?php get_footer(); ?>
