<?php
/**
 * Template Name: Building Surveyor
 *
 * Premium building surveyor / RICS chartered surveyor homepage.
 * Fonts  : Playfair Display + DM Sans (Google Fonts)
 * Palette: blueprint navy #0C2340 / brick terracotta #B85C38 / slate grey #4A5568 / chalk white #F8F7F4 / steel teal #2E7D8C
 * Tokens : --sv-* (zero cross-template contamination)
 */
defined('ABSPATH') || exit;
srand(crc32(get_the_permalink()));

/* ── Hero floating particles ────────────────────────────── */
$arch_chars = ['⊞','⊟','□','▦','▤','▪','◼','◻','✦','◈','∙','·'];
$particles = [];
for ($i = 0; $i < 16; $i++) {
    $particles[] = [
        'sym'  => $arch_chars[array_rand($arch_chars)],
        'top'  => rand(5,92),
        'left' => rand(3,95),
        'size' => rand(10,20),
        'dur'  => rand(7,15),
        'del'  => rand(0,9),
        'col'  => (rand(0,2) < 2 ? 'rgba(184,92,56,.45)' : 'rgba(46,125,140,.4)'),
    ];
}

/* ── Blueprint house (hero scene) ────────────────────────── */
// House sections drawn in CSS only

/* ── Services ───────────────────────────────────────────── */
$services = [
    ['icon'=>'🏠','title'=>'RICS Level 2 HomeBuyer','desc'=>'A structured survey and valuation for conventional properties in reasonable condition. Includes a market valuation and rebuild cost assessment.'],
    ['icon'=>'🔍','title'=>'RICS Level 3 Building Survey','desc'=>'The most comprehensive survey, ideal for older, unusual or extended properties. Covers all accessible areas with detailed advice on defects and remedial work.'],
    ['icon'=>'🏗️','title'=>'Structural Survey','desc'=>'Engineer-backed structural assessment of foundations, load-bearing elements, subsidence indicators and major structural defects.'],
    ['icon'=>'📋','title'=>'Schedule of Condition','desc'=>'An impartial, photographic record of a property\'s condition at a specific date — essential for lease agreements and dilapidations disputes.'],
    ['icon'=>'💧','title'=>'Damp & Timber Survey','desc'=>'Specialist assessment of damp ingress, rising damp, condensation, woodworm and dry/wet rot using calibrated moisture equipment.'],
    ['icon'=>'⚖️','title'=>'Party Wall Award','desc'=>'Independent surveyor appointments, notices, schedule of condition and award preparation under the Party Wall etc. Act 1996.'],
    ['icon'=>'🏢','title'=>'Commercial Survey','desc'=>'Acquisition surveys, schedules of dilapidation, planned maintenance programmes and condition surveys for commercial property.'],
    ['icon'=>'📐','title'=>'Measured Survey','desc'=>'Precision floor plan, elevation and section drawings for planning, conversion, extension or sale — CAD output as standard.'],
];

/* ── Property types cloud ───────────────────────────────── */
$prop_types = [
    'Victorian Terrace','Edwardian Semi','Post-War Detached','1960s–80s Build',
    'New-Build Snagging','Listed Building','Stone Cottage','Converted Barn',
    'Flat / Apartment','Ex-Council','Thatched Property','Steel-Frame House',
    'Timber Frame','Timber Clad','Concrete Panel','Wimpey No-Fines',
    'Airey House','PRC Property','Mundic Block','Cornish Unit',
    'Commercial Premises','Industrial Unit',
];

/* ── Steps ──────────────────────────────────────────────── */
$steps = [
    ['num'=>'01','title'=>'Enquiry','desc'=>'Tell us the property address and type. We provide a fixed, transparent fee within the hour — no obligation.'],
    ['num'=>'02','title'=>'Instruction','desc'=>'You instruct us online or by phone. We liaise directly with the estate agent or vendor to book access.'],
    ['num'=>'03','title'=>'Inspection','desc'=>'Our MRICS surveyor carries out a thorough, methodical inspection typically lasting 2–4 hours.'],
    ['num'=>'04','title'=>'Report Delivered','desc'=>'A detailed, clear report in your inbox within 5 working days — often sooner for standard properties.'],
    ['num'=>'05','title'=>'Follow-Up Call','desc'=>'We talk you through the findings, answer your questions and help you decide whether to proceed or renegotiate.'],
];

/* ── Gallery ────────────────────────────────────────────── */
$gallery = [
    ['label'=>'Site Inspection','color'=>'linear-gradient(135deg,#0c2340,#1a4a7a)','icon'=>'🔍'],
    ['label'=>'Report Writing','color'=>'linear-gradient(135deg,#2a0e0e,#B85C38)','icon'=>'📋'],
    ['label'=>'Structural Analysis','color'=>'linear-gradient(135deg,#1a2a3a,#4A5568)','icon'=>'🏗️'],
    ['label'=>'Damp Assessment','color'=>'linear-gradient(135deg,#0a2028,#2E7D8C)','icon'=>'💧'],
    ['label'=>'Measured Survey','color'=>'linear-gradient(135deg,#0c2340,#1a3a6a)','icon'=>'📐'],
    ['label'=>'Client Consultation','color'=>'linear-gradient(135deg,#1a0e0e,#4a1a0e)','icon'=>'🤝'],
];

/* ── Counters ───────────────────────────────────────────── */
$counters = [
    ['val'=>22,'suffix'=>' yrs','label'=>'In Practice','float'=>0],
    ['val'=>8400,'suffix'=>'+','label'=>'Surveys Completed','float'=>0],
    ['val'=>4.9,'suffix'=>'★','label'=>'Client Rating','float'=>1],
    ['val'=>97,'suffix'=>'%','label'=>'Recommend Us','float'=>0],
];

/* ── Packages ───────────────────────────────────────────── */
$packages = [
    ['name'=>'Level 2 HomeBuyer','price'=>'£450','per'=>'from (inc. valuation)','featured'=>false,
     'features'=>['RICS HomeBuyer Report','Market valuation','Rebuild cost assessment','Traffic-light condition ratings','Follow-up call included','Delivered within 5 days']],
    ['name'=>'Level 3 Building Survey','price'=>'£700','per'=>'from (property size dependent)','featured'=>true,
     'features'=>['Comprehensive RICS survey','All accessible areas inspected','Detailed defect analysis','Repair priority list','Cost guidance','Follow-up call included','Priority 3-day turnaround']],
    ['name'=>'Specialist Reports','price'=>'£295','per'=>'from (per report)','featured'=>false,
     'features'=>['Damp & timber survey','Party wall award','Structural only report','Schedule of condition','Snagging (new build)','Measured survey / CAD']],
];

/* ── Testimonials ───────────────────────────────────────── */
$testimonials = [
    ['name'=>'James & Fiona H.','role'=>'House Purchasers, Oxford','rating'=>5,
     'text'=>'The Level 3 survey identified a significant structural issue we\'d completely missed during viewings. On the strength of the report we renegotiated £28,000 off the asking price. An absolute bargain at £750.'],
    ['name'=>'Michelle T.','role'=>'Landlord — 6 Properties','rating'=>5,
     'text'=>'I use Meridian Surveyors for every acquisition. The reports are thorough, clearly written and always highlight the things that matter to an investor. The follow-up call is invaluable for interpreting the detail.'],
    ['name'=>'Robert O.','role'=>'First-Time Buyer, London','rating'=>5,
     'text'=>'As a first-time buyer I was anxious about the whole process. The surveyor explained everything patiently during the inspection and called to walk me through the report the same day it was issued. Excellent service.'],
];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=DM+Sans:ital,wght@0,300;0,400;0,600;0,700;1,300&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════════
   BUILDING SURVEYOR — CSS TOKENS  (--sv-*)
   ═══════════════════════════════════════════════════════════ */
:root {
  --sv-navy:     #0C2340;
  --sv-navy-lt:  #163560;
  --sv-brick:    #B85C38;
  --sv-brick-d:  #8f4526;
  --sv-slate:    #4A5568;
  --sv-slate-lt: #6b7a8f;
  --sv-chalk:    #F8F7F4;
  --sv-chalk-d:  #eeecea;
  --sv-teal:     #2E7D8C;
  --sv-teal-d:   #225f6b;
  --sv-font-head:'Playfair Display', serif;
  --sv-font-body:'DM Sans', sans-serif;
  --sv-radius:   10px;
  --sv-shadow:   0 6px 28px rgba(0,0,0,.09);
}

/* ── Reset & Base ───────────────────────────────────────── */
.sv-wrap *, .sv-wrap *::before, .sv-wrap *::after { box-sizing:border-box; margin:0; padding:0; }
.sv-wrap { font-family:var(--sv-font-body); color:var(--sv-navy); background:var(--sv-chalk); line-height:1.7; }
.sv-container { max-width:1200px; margin:0 auto; padding:0 24px; }
.sv-section { padding:96px 0; }
.sv-section--navy  { background:var(--sv-navy); color:rgba(255,255,255,.9); }
.sv-section--chalk { background:var(--sv-chalk-d); }
.sv-tag { display:inline-block; background:rgba(184,92,56,.12); color:var(--sv-brick-d); font-size:.7rem; font-weight:700; letter-spacing:.12em; text-transform:uppercase; padding:4px 14px; border-radius:4px; margin-bottom:16px; }
.sv-tag--light { background:rgba(184,92,56,.18); color:rgba(255,220,200,.9); }
.sv-h2 { font-family:var(--sv-font-head); font-size:clamp(1.5rem,3.2vw,2.4rem); line-height:1.25; font-weight:700; margin-bottom:12px; }
.sv-lead { font-size:1.05rem; opacity:.8; max-width:640px; }
.sv-btn { display:inline-block; padding:14px 36px; border-radius:var(--sv-radius); font-family:var(--sv-font-body); font-size:.95rem; font-weight:700; text-decoration:none; cursor:pointer; border:none; transition:transform .2s,box-shadow .2s; }
.sv-btn--brick { background:var(--sv-brick); color:#fff; box-shadow:0 4px 18px rgba(184,92,56,.4); }
.sv-btn--brick:hover { transform:translateY(-2px); box-shadow:0 8px 28px rgba(184,92,56,.55); }
.sv-btn--navy  { background:var(--sv-navy); color:#fff; box-shadow:0 4px 18px rgba(12,35,64,.3); }
.sv-btn--navy:hover  { transform:translateY(-2px); box-shadow:0 8px 28px rgba(12,35,64,.45); }
.sv-btn--ghost { background:transparent; color:var(--sv-brick); border:2px solid var(--sv-brick); }
.sv-btn--ghost:hover { background:rgba(184,92,56,.08); transform:translateY(-2px); }

/* ═══════════════════════════════════════════════════════════
   HERO
   ═══════════════════════════════════════════════════════════ */
.sv-hero {
  position:relative; min-height:100vh;
  background:linear-gradient(145deg,#060e1c 0%,#0C2340 45%,#112d50 70%,#0a1e36 100%);
  overflow:hidden; display:flex; align-items:center;
}
/* Blueprint grid */
.sv-hero::before {
  content:''; position:absolute; inset:0; pointer-events:none;
  background-image:
    linear-gradient(rgba(46,125,140,.12) 1px,transparent 1px),
    linear-gradient(90deg,rgba(46,125,140,.12) 1px,transparent 1px);
  background-size:40px 40px;
}
/* Blueprint cross-hatch at 20px */
.sv-hero::after {
  content:''; position:absolute; inset:0; pointer-events:none;
  background-image:
    linear-gradient(rgba(46,125,140,.05) 1px,transparent 1px),
    linear-gradient(90deg,rgba(46,125,140,.05) 1px,transparent 1px);
  background-size:20px 20px;
}

/* ── Particles ───────────────────────────────────────────── */
.sv-particle { position:absolute; pointer-events:none; animation:sv-drift var(--dur,10s) var(--del,0s) ease-in-out infinite alternate; }
@keyframes sv-drift {
  from { transform:translateY(0) rotate(0deg); opacity:.35; }
  to   { transform:translateY(-24px) rotate(12deg); opacity:.75; }
}

.sv-hero__inner { position:relative; z-index:2; display:grid; grid-template-columns:1fr 1fr; gap:60px; align-items:center; padding:120px 0 80px; }

/* ═══════════════════════════════════════════════════════════
   BLUEPRINT HOUSE SCENE
   ═══════════════════════════════════════════════════════════ */
.sv-scene { display:flex; justify-content:center; align-items:center; }
.sv-blueprint {
  position:relative; width:400px; height:400px;
  background:rgba(12,35,64,.6); border:1px solid rgba(46,125,140,.4);
  border-radius:8px; overflow:hidden;
  box-shadow:0 0 40px rgba(46,125,140,.2), inset 0 0 60px rgba(0,0,0,.3);
}

/* Fine grid inside blueprint */
.sv-blueprint::before {
  content:''; position:absolute; inset:0;
  background-image:
    linear-gradient(rgba(46,125,140,.15) 1px,transparent 1px),
    linear-gradient(90deg,rgba(46,125,140,.15) 1px,transparent 1px);
  background-size:20px 20px;
}

/* Blueprint label */
.sv-blueprint__label {
  position:absolute; top:12px; left:50%; transform:translateX(-50%);
  font-family:var(--sv-font-body); font-size:.55rem; font-weight:700;
  color:rgba(46,125,140,.8); letter-spacing:.2em; text-transform:uppercase;
  white-space:nowrap;
}

/* House outline — drawn with CSS borders */
.sv-house-outline {
  position:absolute; bottom:60px; left:50%; transform:translateX(-50%);
  width:240px;
}
/* Walls */
.sv-house-outline__walls {
  width:240px; height:120px;
  border:2px solid var(--sv-teal); background:transparent;
  position:relative;
}
/* Door */
.sv-house-outline__walls::before {
  content:''; position:absolute; bottom:0; left:50%; transform:translateX(-50%);
  width:34px; height:54px; border:2px solid var(--sv-teal); border-bottom:none;
  border-radius:2px 2px 0 0;
}
/* Windows */
.sv-house-outline__walls::after {
  content:''; position:absolute; top:24px; left:28px;
  width:28px; height:24px; border:2px solid var(--sv-teal); border-radius:2px;
  box-shadow:132px 0 0 0 rgba(46,125,140,1); /* second window via box-shadow */
}
/* Roof */
.sv-house-outline__roof {
  width:0; height:0;
  border-left:126px solid transparent;
  border-right:126px solid transparent;
  border-bottom:60px solid transparent;
  position:relative;
}
.sv-house-outline__roof::after {
  content:''; position:absolute; top:5px; left:-120px;
  width:0; height:0;
  border-left:120px solid transparent;
  border-right:120px solid transparent;
  border-bottom:55px solid var(--sv-teal);
}
/* Chimney */
.sv-house-outline__chimney {
  position:absolute; top:-80px; right:52px;
  width:18px; height:36px; border:2px solid var(--sv-teal); border-bottom:none;
}

/* Dimension lines */
.sv-dim {
  position:absolute; border-color:rgba(184,92,56,.6);
  font-family:var(--sv-font-body); font-size:.5rem; color:rgba(184,92,56,.8); font-weight:700;
}
.sv-dim--h {
  border-top:1px solid; width:240px;
  bottom:40px; left:50%; transform:translateX(-50%);
}
.sv-dim--h::before,
.sv-dim--h::after {
  content:''; position:absolute; top:-4px;
  border-top:4px solid transparent; border-bottom:4px solid transparent;
}
.sv-dim--h::before { left:0;  border-right:6px solid rgba(184,92,56,.6); }
.sv-dim--h::after  { right:0; border-left:6px solid rgba(184,92,56,.6); }
.sv-dim--h span { position:absolute; top:-10px; left:50%; transform:translateX(-50%); white-space:nowrap; }

.sv-dim--v {
  border-left:1px solid; height:120px;
  right:55px; bottom:60px;
}
.sv-dim--v::before,
.sv-dim--v::after {
  content:''; position:absolute; left:-4px;
  border-left:4px solid transparent; border-right:4px solid transparent;
}
.sv-dim--v::before { top:0;  border-bottom:6px solid rgba(184,92,56,.6); }
.sv-dim--v::after  { bottom:0; border-top:6px solid rgba(184,92,56,.6); }
.sv-dim--v span { position:absolute; right:-36px; top:50%; transform:translateY(-50%); white-space:nowrap; }

/* Corner marker */
.sv-corner {
  position:absolute; width:8px; height:8px; border-radius:50%;
  background:var(--sv-brick); opacity:.8;
  animation:sv-corner-pulse 2s ease-in-out infinite alternate;
}
@keyframes sv-corner-pulse {
  from { opacity:.5; transform:scale(.8); }
  to   { opacity:1;  transform:scale(1.2); }
}

/* RICS stamp in corner */
.sv-stamp {
  position:absolute; bottom:10px; right:12px;
  border:1px solid rgba(46,125,140,.5); border-radius:4px;
  padding:4px 8px; font-size:.45rem; font-family:var(--sv-font-body);
  font-weight:700; color:rgba(46,125,140,.8); letter-spacing:.1em; text-transform:uppercase;
}

/* ── Hero content ─────────────────────────────────────────── */
.sv-hero__badge { display:inline-flex; align-items:center; gap:8px; background:rgba(184,92,56,.12); border:1px solid rgba(184,92,56,.3); color:rgba(255,200,180,.9); padding:6px 18px; border-radius:6px; font-size:.75rem; font-weight:700; letter-spacing:.08em; text-transform:uppercase; margin-bottom:24px; }
.sv-hero__title { font-family:var(--sv-font-head); font-size:clamp(1.8rem,4.5vw,3.2rem); line-height:1.2; color:#fff; margin-bottom:16px; }
.sv-hero__title span { color:var(--sv-brick); }
.sv-hero__sub { font-size:1.05rem; color:rgba(255,255,255,.72); margin-bottom:32px; line-height:1.8; }
.sv-hero__ctas { display:flex; gap:14px; flex-wrap:wrap; margin-bottom:36px; }
.sv-hero__trust { display:flex; gap:24px; flex-wrap:wrap; }
.sv-hero__trust-item { display:flex; align-items:center; gap:8px; color:rgba(255,255,255,.7); font-size:.85rem; }

/* ═══════════════════════════════════════════════════════════
   TRUST BAR
   ═══════════════════════════════════════════════════════════ */
.sv-trust-bar { background:var(--sv-brick); padding:18px 0; }
.sv-trust-bar__inner { display:flex; justify-content:space-around; flex-wrap:wrap; gap:16px; }
.sv-trust-bar__item { display:flex; align-items:center; gap:10px; color:rgba(255,255,255,.9); font-size:.9rem; font-weight:600; }
.sv-trust-bar__item span:first-child { font-size:1.2rem; }
.sv-trust-bar__item strong { color:#fff; }

/* ═══════════════════════════════════════════════════════════
   SERVICES
   ═══════════════════════════════════════════════════════════ */
.sv-services { text-align:center; }
.sv-services__intro { max-width:640px; margin:0 auto 56px; }
.sv-services__grid { display:grid; grid-template-columns:repeat(4,1fr); gap:20px; }
.sv-svc {
  background:#fff; border-radius:var(--sv-radius); padding:28px 18px; text-align:left;
  box-shadow:var(--sv-shadow); border:1px solid rgba(0,0,0,.05);
  border-left:3px solid var(--sv-brick);
  transition:transform .25s,box-shadow .25s;
}
.sv-svc:hover { transform:translateY(-6px); box-shadow:0 12px 36px rgba(12,35,64,.14); }
.sv-svc__icon { font-size:2rem; margin-bottom:12px; display:block; }
.sv-svc__title { font-family:var(--sv-font-head); font-size:.9rem; margin-bottom:8px; color:var(--sv-navy); }
.sv-svc__desc  { font-size:.85rem; line-height:1.65; color:#555; }

/* ═══════════════════════════════════════════════════════════
   PROPERTY TYPES
   ═══════════════════════════════════════════════════════════ */
.sv-proptypes { text-align:center; }
.sv-proptypes__intro { max-width:600px; margin:0 auto 48px; }
.sv-proptypes__cloud { display:flex; flex-wrap:wrap; justify-content:center; gap:10px; }
.sv-prop-tag {
  display:inline-block; padding:8px 18px; border-radius:6px;
  background:rgba(46,125,140,.08); color:var(--sv-teal-d); font-size:.85rem; font-weight:600;
  border:1px solid rgba(46,125,140,.18); cursor:default;
  transition:background .2s,color .2s;
}
.sv-prop-tag:hover { background:var(--sv-teal); color:#fff; }

/* ═══════════════════════════════════════════════════════════
   ABOUT
   ═══════════════════════════════════════════════════════════ */
.sv-about { }
.sv-about__grid { display:grid; grid-template-columns:1fr 1fr; gap:80px; align-items:center; }
.sv-about__visual { display:flex; flex-direction:column; gap:20px; align-items:center; }

/* Surveyor credential card */
.sv-credential-card {
  width:300px; background:var(--sv-navy); border-radius:12px; overflow:hidden;
  box-shadow:0 12px 48px rgba(0,0,0,.2); border:1px solid rgba(184,92,56,.2);
}
.sv-credential-card__header {
  background:linear-gradient(135deg,var(--sv-navy-lt),var(--sv-navy));
  padding:24px 20px 18px; text-align:center;
  border-bottom:2px solid var(--sv-brick);
}
/* CSS surveyor figure */
.sv-surv-fig { display:flex; flex-direction:column; align-items:center; margin-bottom:10px; }
.sv-surv-fig__head { width:50px; height:50px; border-radius:50%; background:radial-gradient(circle at 40% 35%,#c8a878,#a07850); border:3px solid rgba(184,92,56,.4); position:relative; }
.sv-surv-fig__head::before { content:''; position:absolute; top:-8px; left:4px; right:4px; height:12px; background:linear-gradient(180deg,#1a1a1a,#333); border-radius:50% 50% 0 0; }
/* Hard hat */
.sv-surv-fig__head::after { content:''; position:absolute; top:-14px; left:-4px; right:-4px; height:14px; background:var(--sv-brick); border-radius:50% 50% 0 0; }
.sv-surv-fig__body { width:64px; height:54px; background:linear-gradient(180deg,#1e3a5a,#0c2340); border-radius:4px 4px 0 0; position:relative; }
.sv-surv-fig__body::before { content:'📋'; position:absolute; top:8px; left:50%; transform:translateX(-50%); font-size:.85rem; }
.sv-credential-card__header h3 { color:#fff; font-family:var(--sv-font-head); font-size:.95rem; margin-bottom:2px; }
.sv-credential-card__header p  { color:rgba(255,255,255,.6); font-size:.75rem; }
.sv-credential-card__body { padding:16px 20px; }
.sv-credential-card__row { display:flex; justify-content:space-between; padding:7px 0; border-bottom:1px solid rgba(255,255,255,.05); font-size:.82rem; }
.sv-credential-card__row:last-child { border-bottom:none; }
.sv-credential-card__row span:first-child { color:rgba(255,255,255,.5); }
.sv-credential-card__row span:last-child  { color:var(--sv-brick); font-weight:700; }

.sv-accreds { display:flex; flex-wrap:wrap; gap:10px; justify-content:center; }
.sv-accred { background:rgba(46,125,140,.1); border:1px solid rgba(46,125,140,.25); color:var(--sv-teal-d); border-radius:6px; padding:6px 12px; font-size:.72rem; font-weight:700; letter-spacing:.04em; }

.sv-about__text .sv-h2 { color:var(--sv-navy); }
.sv-about__text p { color:#444; margin-bottom:16px; line-height:1.8; }
.sv-about__feats { list-style:none; margin:20px 0 32px; display:flex; flex-direction:column; gap:10px; }
.sv-about__feats li { display:flex; align-items:center; gap:10px; font-size:.9rem; color:#333; }
.sv-about__feats li::before { content:'✦'; color:var(--sv-brick); flex-shrink:0; }

/* ═══════════════════════════════════════════════════════════
   APPROACH
   ═══════════════════════════════════════════════════════════ */
.sv-approach { background:var(--sv-navy); }
.sv-approach__intro { text-align:center; max-width:640px; margin:0 auto 56px; }
.sv-approach__grid { display:grid; grid-template-columns:repeat(5,1fr); gap:0; position:relative; }
.sv-approach__grid::before {
  content:''; position:absolute; top:38px; left:10%; right:10%; height:2px;
  background:linear-gradient(90deg,var(--sv-brick),var(--sv-teal),var(--sv-brick));
  z-index:0;
}
.sv-step { text-align:center; padding:0 10px; position:relative; z-index:1; }
.sv-step__num { width:44px; height:44px; border-radius:4px; background:var(--sv-brick); color:#fff; font-family:var(--sv-font-head); font-size:.85rem; display:inline-flex; align-items:center; justify-content:center; margin-bottom:18px; box-shadow:0 4px 14px rgba(184,92,56,.4); }
.sv-step__title { font-family:var(--sv-font-head); font-size:.85rem; color:#fff; margin-bottom:8px; }
.sv-step__desc  { font-size:.82rem; color:rgba(255,255,255,.65); line-height:1.6; }

/* ═══════════════════════════════════════════════════════════
   GALLERY
   ═══════════════════════════════════════════════════════════ */
.sv-gallery__grid { display:grid; grid-template-columns:repeat(3,1fr); grid-template-rows:220px 220px; gap:12px; }
.sv-gallery__item { border-radius:var(--sv-radius); overflow:hidden; position:relative; cursor:pointer; }
.sv-gallery__item:nth-child(1) { grid-column:span 2; }
.sv-gallery__item:nth-child(5) { grid-column:span 2; }
.sv-gallery__panel { width:100%; height:100%; display:flex; align-items:center; justify-content:center; font-size:3rem; transition:transform .4s; }
.sv-gallery__item:hover .sv-gallery__panel { transform:scale(1.04); }
.sv-gallery__overlay { position:absolute; inset:0; display:flex; align-items:flex-end; background:linear-gradient(to top,rgba(0,0,0,.65) 0%,transparent 50%); padding:20px; opacity:0; transition:opacity .3s; }
.sv-gallery__item:hover .sv-gallery__overlay { opacity:1; }
.sv-gallery__overlay span { color:#fff; font-size:.9rem; font-weight:600; font-family:var(--sv-font-head); font-style:italic; }

/* ═══════════════════════════════════════════════════════════
   COUNTERS
   ═══════════════════════════════════════════════════════════ */
.sv-counters { background:linear-gradient(135deg,var(--sv-navy-lt),var(--sv-navy)); text-align:center; }
.sv-counters__grid { display:grid; grid-template-columns:repeat(4,1fr); gap:40px; }
.sv-counter__val { font-family:var(--sv-font-head); font-size:clamp(2rem,4vw,3.2rem); color:var(--sv-brick); display:block; line-height:1; }
.sv-counter__label { font-size:.85rem; color:rgba(255,255,255,.7); margin-top:8px; }

/* ═══════════════════════════════════════════════════════════
   PACKAGES
   ═══════════════════════════════════════════════════════════ */
.sv-packages { text-align:center; background:var(--sv-chalk-d); }
.sv-packages__intro { max-width:600px; margin:0 auto 56px; }
.sv-packages__grid { display:grid; grid-template-columns:repeat(3,1fr); gap:24px; align-items:start; }
.sv-pkg { border-radius:var(--sv-radius); padding:36px 28px; text-align:left; background:#fff; box-shadow:var(--sv-shadow); border:2px solid transparent; transition:transform .25s,box-shadow .25s; }
.sv-pkg:hover { transform:translateY(-6px); box-shadow:0 14px 48px rgba(12,35,64,.14); }
.sv-pkg--featured { border-color:var(--sv-brick); box-shadow:0 8px 40px rgba(184,92,56,.18); background:var(--sv-navy); color:rgba(255,255,255,.9); transform:translateY(-8px); }
.sv-pkg--featured:hover { transform:translateY(-14px); }
.sv-pkg__badge { display:inline-block; background:var(--sv-brick); color:#fff; font-size:.7rem; font-weight:700; letter-spacing:.1em; text-transform:uppercase; padding:3px 12px; border-radius:4px; margin-bottom:12px; }
.sv-pkg__name { font-family:var(--sv-font-head); font-size:1rem; margin-bottom:4px; }
.sv-pkg--featured .sv-pkg__name { color:#fff; }
.sv-pkg__price { font-size:2rem; font-weight:700; font-family:var(--sv-font-head); margin:14px 0 4px; color:var(--sv-navy); }
.sv-pkg--featured .sv-pkg__price { color:var(--sv-brick); }
.sv-pkg__per { font-size:.8rem; opacity:.65; margin-bottom:24px; }
.sv-pkg__features { list-style:none; margin-bottom:28px; display:flex; flex-direction:column; gap:10px; }
.sv-pkg__features li { display:flex; align-items:center; gap:8px; font-size:.88rem; }
.sv-pkg__features li::before { content:'✦'; color:var(--sv-brick); flex-shrink:0; }
.sv-pkg--featured .sv-pkg__features li { color:rgba(255,255,255,.85); }
.sv-pkg .sv-btn { width:100%; text-align:center; }

/* ═══════════════════════════════════════════════════════════
   TESTIMONIALS
   ═══════════════════════════════════════════════════════════ */
.sv-testimonials { }
.sv-testimonials__intro { text-align:center; max-width:600px; margin:0 auto 56px; }
.sv-testimonials__grid { display:grid; grid-template-columns:repeat(3,1fr); gap:24px; }
.sv-testi { background:#fff; border-radius:var(--sv-radius); padding:28px 24px; box-shadow:var(--sv-shadow); border-top:4px solid var(--sv-brick); position:relative; }
.sv-testi::before { content:'❝'; position:absolute; top:16px; right:20px; font-size:3rem; color:rgba(12,35,64,.07); font-family:serif; line-height:1; }
.sv-testi__stars { color:#f5a623; margin-bottom:14px; }
.sv-testi__text { font-size:.9rem; line-height:1.75; color:#444; margin-bottom:18px; font-style:italic; }
.sv-testi__name { font-weight:700; color:var(--sv-navy); font-family:var(--sv-font-head); font-size:.9rem; }
.sv-testi__role { font-size:.8rem; color:#888; }

/* ═══════════════════════════════════════════════════════════
   BOOKING FORM
   ═══════════════════════════════════════════════════════════ */
.sv-booking { background:var(--sv-navy); }
.sv-booking__inner { display:grid; grid-template-columns:1fr 1fr; gap:80px; align-items:start; }
.sv-booking__info h2 { color:#fff; margin-bottom:16px; }
.sv-booking__info p  { color:rgba(255,255,255,.7); margin-bottom:28px; line-height:1.8; }
.sv-booking__list { list-style:none; display:flex; flex-direction:column; gap:12px; }
.sv-booking__list li { display:flex; align-items:center; gap:10px; color:rgba(255,255,255,.8); font-size:.9rem; }
.sv-booking__list li span:first-child { width:30px; height:30px; background:rgba(184,92,56,.15); border:1px solid rgba(184,92,56,.3); border-radius:4px; display:inline-flex; align-items:center; justify-content:center; flex-shrink:0; }
.sv-form { background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08); border-radius:10px; padding:36px; }
.sv-form__row { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
.sv-form__group { margin-bottom:14px; }
.sv-form__group label { display:block; font-size:.8rem; font-weight:700; color:rgba(255,255,255,.65); margin-bottom:6px; letter-spacing:.06em; text-transform:uppercase; }
.sv-form__group input,
.sv-form__group select,
.sv-form__group textarea {
  width:100%; padding:11px 14px; border-radius:6px;
  border:1px solid rgba(255,255,255,.1); background:rgba(255,255,255,.05);
  color:#fff; font-family:var(--sv-font-body); font-size:.9rem;
  transition:border-color .2s;
}
.sv-form__group input::placeholder,
.sv-form__group textarea::placeholder { color:rgba(255,255,255,.3); }
.sv-form__group input:focus,
.sv-form__group select:focus,
.sv-form__group textarea:focus { outline:none; border-color:var(--sv-brick); }
.sv-form__group select option { background:#0c2340; }
.sv-form__group textarea { resize:vertical; min-height:90px; }
.sv-form__submit { width:100%; padding:15px; background:linear-gradient(135deg,var(--sv-brick),var(--sv-brick-d)); color:#fff; font-family:var(--sv-font-body); font-size:1rem; font-weight:700; border:none; border-radius:8px; cursor:pointer; transition:transform .2s,box-shadow .2s; margin-top:8px; }
.sv-form__submit:hover { transform:translateY(-2px); box-shadow:0 8px 24px rgba(184,92,56,.45); }

/* ═══════════════════════════════════════════════════════════
   FOOTER
   ═══════════════════════════════════════════════════════════ */
.sv-footer { background:var(--sv-navy-lt); padding:28px 0; text-align:center; border-top:1px solid rgba(255,255,255,.05); }
.sv-footer p { color:rgba(255,255,255,.5); font-size:.85rem; }

/* ═══════════════════════════════════════════════════════════
   RESPONSIVE
   ═══════════════════════════════════════════════════════════ */
@media(max-width:1024px){
  .sv-hero__inner { grid-template-columns:1fr; gap:40px; padding:100px 0 60px; }
  .sv-blueprint { width:320px; height:320px; }
  .sv-services__grid { grid-template-columns:repeat(2,1fr); }
  .sv-about__grid { grid-template-columns:1fr; }
  .sv-approach__grid { grid-template-columns:repeat(3,1fr); }
  .sv-approach__grid::before { display:none; }
  .sv-counters__grid { grid-template-columns:repeat(2,1fr); }
  .sv-packages__grid { grid-template-columns:1fr; }
  .sv-testimonials__grid { grid-template-columns:1fr; }
  .sv-booking__inner { grid-template-columns:1fr; }
}
@media(max-width:640px){
  .sv-section { padding:64px 0; }
  .sv-services__grid { grid-template-columns:1fr; }
  .sv-approach__grid { grid-template-columns:1fr 1fr; }
  .sv-gallery__grid { grid-template-columns:1fr 1fr; grid-template-rows:auto; }
  .sv-gallery__item:nth-child(1),
  .sv-gallery__item:nth-child(5) { grid-column:span 1; }
  .sv-counters__grid { grid-template-columns:1fr 1fr; }
  .sv-form__row { grid-template-columns:1fr; }
  .sv-hero__ctas { flex-direction:column; }
}
</style>
<?php get_header(); ?>
<div class="sv-page">
>
<?php wp_body_open(); ?>
<div class="sv-wrap">

<!-- ═══════════════ HERO ═══════════════ -->
<section class="sv-hero" aria-label="Building surveyor hero">

  <!-- Floating particles -->
  <?php foreach ($particles as $p): ?>
  <div class="sv-particle" aria-hidden="true" style="
    top:<?= $p['top'] ?>%; left:<?= $p['left'] ?>%;
    font-size:<?= $p['size'] ?>px; color:<?= esc_attr($p['col']) ?>;
    --dur:<?= $p['dur'] ?>s; --del:<?= $p['del'] ?>s;
  "><?= esc_html($p['sym']) ?></div>
  <?php endforeach; ?>

  <div class="sv-container">
    <div class="sv-hero__inner">

      <!-- Content -->
      <div class="sv-hero__content">
        <div class="sv-hero__badge"><span>🏅</span> RICS Chartered Surveyors</div>
        <h1 class="sv-hero__title">
          Know Exactly<br>
          <span>What You're Buying.</span>
        </h1>
        <p class="sv-hero__sub">
          RICS-accredited building surveys, HomeBuyer reports and structural assessments delivered with clarity and precision. Fixed fees. Reports within 5 days. Follow-up call included as standard.
        </p>
        <div class="sv-hero__ctas">
          <a href="#booking" class="sv-btn sv-btn--brick">Get an Instant Quote</a>
          <a href="#services" class="sv-btn sv-btn--ghost">Our Survey Types</a>
        </div>
        <div class="sv-hero__trust">
          <div class="sv-hero__trust-item"><span>🏅</span><span>MRICS Qualified</span></div>
          <div class="sv-hero__trust-item"><span>📋</span><span>Fixed Fees</span></div>
          <div class="sv-hero__trust-item"><span>📞</span><span>Free Follow-Up Call</span></div>
        </div>
      </div>

      <!-- Blueprint house scene -->
      <div class="sv-scene" aria-hidden="true">
        <div class="sv-blueprint" role="img" aria-label="Architectural blueprint of a house">
          <div class="sv-blueprint__label">Meridian Surveyors — Elevation A — Scale 1:100</div>

          <div class="sv-house-outline">
            <div class="sv-house-outline__roof">
              <div class="sv-house-outline__chimney"></div>
            </div>
            <div class="sv-house-outline__walls"></div>
          </div>

          <!-- Dimension lines -->
          <div class="sv-dim sv-dim--h"><span>12.4 m</span></div>
          <div class="sv-dim sv-dim--v"><span>5.2 m</span></div>

          <!-- Corner markers -->
          <div class="sv-corner" style="bottom:58px;left:calc(50% - 120px);"></div>
          <div class="sv-corner" style="bottom:58px;right:calc(50% - 120px);animation-delay:.5s;"></div>
          <div class="sv-corner" style="bottom:178px;left:calc(50% - 120px);animation-delay:1s;"></div>
          <div class="sv-corner" style="bottom:178px;right:calc(50% - 120px);animation-delay:1.5s;"></div>

          <!-- RICS stamp -->
          <div class="sv-stamp">RICS Compliant Survey</div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- ═══════════════ TRUST BAR ═══════════════ -->
<div class="sv-trust-bar" aria-label="Credentials">
  <div class="sv-container">
    <div class="sv-trust-bar__inner">
      <div class="sv-trust-bar__item"><span>🏅</span><span><strong>MRICS</strong> Chartered Surveyors</span></div>
      <div class="sv-trust-bar__item"><span>🏗️</span><span>RICS <strong>Level 2 &amp; Level 3</strong> Reports</span></div>
      <div class="sv-trust-bar__item"><span>⭐</span><span>Rated <strong>4.9/5</strong> on Google Reviews</span></div>
      <div class="sv-trust-bar__item"><span>🔒</span><span><strong>£5M</strong> Professional Indemnity Insurance</span></div>
    </div>
  </div>
</div>

<!-- ═══════════════ SERVICES ═══════════════ -->
<section class="sv-section sv-services" id="services" aria-labelledby="sv-svc-heading">
  <div class="sv-container">
    <div class="sv-services__intro">
      <span class="sv-tag">Survey Types</span>
      <h2 class="sv-h2" id="sv-svc-heading">Comprehensive Surveying Services</h2>
      <p class="sv-lead" style="margin:0 auto;">From the standard HomeBuyer report to complex structural assessments and specialist damp surveys — we cover the full spectrum.</p>
    </div>
    <div class="sv-services__grid">
      <?php foreach ($services as $svc): ?>
      <article class="sv-svc" role="listitem">
        <span class="sv-svc__icon" aria-hidden="true"><?= $svc['icon'] ?></span>
        <h3 class="sv-svc__title"><?= esc_html($svc['title']) ?></h3>
        <p class="sv-svc__desc"><?= esc_html($svc['desc']) ?></p>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ PROPERTY TYPES ═══════════════ -->
<section class="sv-section sv-section--chalk sv-proptypes" aria-labelledby="sv-prop-heading">
  <div class="sv-container">
    <div class="sv-proptypes__intro">
      <span class="sv-tag">We Survey All Property Types</span>
      <h2 class="sv-h2" id="sv-prop-heading">From Victorian Terraces to Modern Flats</h2>
      <p class="sv-lead" style="margin:0 auto;">Our chartered surveyors have experience across every construction type — including non-standard and defective dwellings.</p>
    </div>
    <div class="sv-proptypes__cloud" role="list">
      <?php foreach ($prop_types as $pt): ?>
      <span class="sv-prop-tag" role="listitem"><?= esc_html($pt) ?></span>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ ABOUT ═══════════════ -->
<section class="sv-section sv-about" id="about" aria-labelledby="sv-about-heading">
  <div class="sv-container">
    <div class="sv-about__grid">
      <div class="sv-about__visual">
        <div class="sv-credential-card" role="img" aria-label="Surveyor credential card for Dr. Richard Meridian MRICS">
          <div class="sv-credential-card__header">
            <div class="sv-surv-fig" aria-hidden="true">
              <div class="sv-surv-fig__head"></div>
              <div class="sv-surv-fig__body"></div>
            </div>
            <h3>Richard Meridian MRICS</h3>
            <p>Chartered Building Surveyor &amp; Director</p>
          </div>
          <div class="sv-credential-card__body">
            <div class="sv-credential-card__row"><span>Qualification</span><span>MRICS (RICS)</span></div>
            <div class="sv-credential-card__row"><span>Specialism</span><span>Residential &amp; Structural</span></div>
            <div class="sv-credential-card__row"><span>PI Insurance</span><span>£5M</span></div>
            <div class="sv-credential-card__row"><span>RICS Member</span><span>Since 2004</span></div>
            <div class="sv-credential-card__row"><span>Experience</span><span>22 Years</span></div>
          </div>
        </div>
        <div class="sv-accreds">
          <div class="sv-accred">MRICS Chartered</div>
          <div class="sv-accred">RICS Regulated</div>
          <div class="sv-accred">4.9★ Rated</div>
          <div class="sv-accred">22 Years Experience</div>
        </div>
      </div>

      <div class="sv-about__text">
        <span class="sv-tag">About Meridian Surveyors</span>
        <h2 class="sv-h2" id="sv-about-heading">Independent Expertise You Can Rely On</h2>
        <p>Meridian Surveyors was established in 2002 with the conviction that homebuyers deserve impartial, expert advice — not a cursory report generated at high volume. All of our surveys are carried out personally by RICS-chartered surveyors with a minimum of 15 years' post-qualification experience.</p>
        <p>We are fully regulated by the Royal Institution of Chartered Surveyors (RICS), carry £5 million professional indemnity insurance and provide a follow-up telephone consultation with every report as standard — because a survey should explain the property to you, not just document it.</p>
        <ul class="sv-about__feats" aria-label="Practice highlights">
          <li>All surveys conducted by MRICS-qualified chartered surveyors</li>
          <li>Regulated by RICS — the gold standard in property surveying</li>
          <li>8,400+ surveys completed since 2002</li>
          <li>Reports delivered within 5 working days (3 on priority)</li>
          <li>Free follow-up call with every survey</li>
          <li>£5M professional indemnity insurance as standard</li>
        </ul>
        <a href="#booking" class="sv-btn sv-btn--brick">Request a Quote</a>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════ APPROACH ═══════════════ -->
<section class="sv-section sv-approach" aria-labelledby="sv-approach-heading">
  <div class="sv-container">
    <div class="sv-approach__intro">
      <span class="sv-tag sv-tag--light">The Process</span>
      <h2 class="sv-h2" id="sv-approach-heading" style="color:#fff;">From Quote to Report</h2>
      <p class="sv-lead" style="color:rgba(255,255,255,.7);margin:0 auto;">A straightforward, transparent process that keeps you informed at every stage — from initial enquiry to post-report conversation.</p>
    </div>
    <div class="sv-approach__grid" role="list">
      <?php foreach ($steps as $step): ?>
      <div class="sv-step" role="listitem">
        <div class="sv-step__num" aria-hidden="true"><?= esc_html($step['num']) ?></div>
        <h3 class="sv-step__title"><?= esc_html($step['title']) ?></h3>
        <p class="sv-step__desc"><?= esc_html($step['desc']) ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ GALLERY ═══════════════ -->
<section class="sv-section" aria-labelledby="sv-gallery-heading">
  <div class="sv-container">
    <div style="text-align:center;margin-bottom:48px;">
      <span class="sv-tag">Our Work</span>
      <h2 class="sv-h2" id="sv-gallery-heading">Survey in Action</h2>
    </div>
    <div class="sv-gallery__grid" role="list">
      <?php foreach ($gallery as $panel): ?>
      <div class="sv-gallery__item" role="listitem">
        <div class="sv-gallery__panel" style="background:<?= esc_attr($panel['color']) ?>;" aria-label="<?= esc_attr($panel['label']) ?>">
          <span aria-hidden="true" style="font-size:3.5rem;"><?= $panel['icon'] ?></span>
        </div>
        <div class="sv-gallery__overlay" aria-hidden="true">
          <span><?= esc_html($panel['label']) ?></span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ COUNTERS ═══════════════ -->
<section class="sv-section sv-counters" aria-labelledby="sv-counters-heading">
  <div class="sv-container">
    <h2 class="sr-only" id="sv-counters-heading">Practice statistics</h2>
    <div class="sv-counters__grid">
      <?php foreach ($counters as $c): ?>
      <div>
        <span class="sv-counter__val"
              data-target="<?= esc_attr($c['val']) ?>"
              data-suffix="<?= esc_attr($c['suffix']) ?>"
              <?= $c['float'] ? 'data-float="1"' : '' ?>
              aria-label="<?= esc_attr($c['val'] . $c['suffix'] . ' — ' . $c['label']) ?>">0</span>
        <p class="sv-counter__label"><?= esc_html($c['label']) ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ PACKAGES ═══════════════ -->
<section class="sv-section sv-packages" id="packages" aria-labelledby="sv-pkg-heading">
  <div class="sv-container">
    <div class="sv-packages__intro">
      <span class="sv-tag">Pricing</span>
      <h2 class="sv-h2" id="sv-pkg-heading">Transparent, Fixed Survey Fees</h2>
      <p class="sv-lead" style="margin:0 auto;">All prices are fixed by property type and size — no surprises. Instant quotes available online or by phone.</p>
    </div>
    <div class="sv-packages__grid">
      <?php foreach ($packages as $pkg): ?>
      <div class="sv-pkg <?= $pkg['featured'] ? 'sv-pkg--featured' : '' ?>">
        <?php if ($pkg['featured']): ?><div class="sv-pkg__badge">Most Recommended</div><?php endif; ?>
        <h3 class="sv-pkg__name"><?= esc_html($pkg['name']) ?></h3>
        <div class="sv-pkg__price"><?= esc_html($pkg['price']) ?></div>
        <div class="sv-pkg__per"><?= esc_html($pkg['per']) ?></div>
        <ul class="sv-pkg__features" aria-label="<?= esc_attr($pkg['name']) ?> features">
          <?php foreach ($pkg['features'] as $f): ?>
          <li><?= esc_html($f) ?></li>
          <?php endforeach; ?>
        </ul>
        <a href="#booking" class="sv-btn <?= $pkg['featured'] ? 'sv-btn--brick' : 'sv-btn--ghost' ?>">
          Get a Quote
        </a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ TESTIMONIALS ═══════════════ -->
<section class="sv-section sv-testimonials" aria-labelledby="sv-testi-heading">
  <div class="sv-container">
    <div class="sv-testimonials__intro">
      <span class="sv-tag">Client Feedback</span>
      <h2 class="sv-h2" id="sv-testi-heading">What Our Clients Say</h2>
      <p class="sv-lead" style="margin:0 auto;">Rated 4.9/5 on Google Reviews. Read how our surveys have helped buyers make informed decisions and save money.</p>
    </div>
    <div class="sv-testimonials__grid">
      <?php foreach ($testimonials as $t): ?>
      <blockquote class="sv-testi">
        <div class="sv-testi__stars" aria-label="<?= esc_attr($t['rating']) ?> stars"><?= str_repeat('★',$t['rating']) ?></div>
        <p class="sv-testi__text"><?= esc_html($t['text']) ?></p>
        <footer>
          <div class="sv-testi__name"><?= esc_html($t['name']) ?></div>
          <div class="sv-testi__role"><?= esc_html($t['role']) ?></div>
        </footer>
      </blockquote>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ BOOKING ═══════════════ -->
<section class="sv-section sv-booking" id="booking" aria-labelledby="sv-booking-heading">
  <div class="sv-container">
    <div class="sv-booking__inner">
      <div class="sv-booking__info">
        <span class="sv-tag sv-tag--light">Get a Quote</span>
        <h2 class="sv-h2" id="sv-booking-heading">Request Your Survey Quote</h2>
        <p>Complete the form and we will provide a fixed, no-obligation quote within the hour during business hours. We will then liaise directly with the estate agent to arrange access — all you need to do is instruct us.</p>
        <ul class="sv-booking__list" aria-label="Service promises">
          <li><span>⏱️</span><span>Quote provided within one hour</span></li>
          <li><span>📋</span><span>Report delivered within 5 working days</span></li>
          <li><span>📞</span><span>Free follow-up call with every survey</span></li>
          <li><span>🔒</span><span>£5M professional indemnity insurance</span></li>
          <li><span>🏅</span><span>RICS regulated — the highest professional standard</span></li>
        </ul>
      </div>
      <div class="sv-form">
        <?php
          if (!empty($_POST['tf_sv_nonce']) && wp_verify_nonce($_POST['tf_sv_nonce'],'tf_sv_booking')) {
            echo '<p style="color:var(--sv-brick);font-weight:700;margin-bottom:16px;">✦ Quote request received — we\'ll be in touch within the hour!</p>';
          }
        ?>
        <form method="post" action="<?php echo esc_url(get_permalink()); ?>#booking" novalidate>
          <?php wp_nonce_field('tf_sv_booking','tf_sv_nonce'); ?>
          <div class="sv-form__row">
            <div class="sv-form__group">
              <label for="sv_name">Your Name <span style="color:var(--sv-brick)">*</span></label>
              <input type="text" id="sv_name" name="sv_name" placeholder="Full name" required autocomplete="name">
            </div>
            <div class="sv-form__group">
              <label for="sv_email">Email <span style="color:var(--sv-brick)">*</span></label>
              <input type="email" id="sv_email" name="sv_email" placeholder="you@example.com" required autocomplete="email">
            </div>
          </div>
          <div class="sv-form__row">
            <div class="sv-form__group">
              <label for="sv_phone">Phone</label>
              <input type="tel" id="sv_phone" name="sv_phone" placeholder="+44 7700 900000" autocomplete="tel">
            </div>
            <div class="sv-form__group">
              <label for="sv_survey_type">Survey Type <span style="color:var(--sv-brick)">*</span></label>
              <select id="sv_survey_type" name="sv_survey_type" required>
                <option value="">Select type…</option>
                <option value="level2">RICS Level 2 HomeBuyer</option>
                <option value="level3">RICS Level 3 Building Survey</option>
                <option value="structural">Structural Survey</option>
                <option value="damp">Damp &amp; Timber Report</option>
                <option value="schedule">Schedule of Condition</option>
                <option value="party-wall">Party Wall Award</option>
                <option value="measured">Measured Survey</option>
                <option value="snagging">New-Build Snagging</option>
              </select>
            </div>
          </div>
          <div class="sv-form__group">
            <label for="sv_property">Property Address <span style="color:var(--sv-brick)">*</span></label>
            <input type="text" id="sv_property" name="sv_property" placeholder="Full property address including postcode" required autocomplete="street-address">
          </div>
          <div class="sv-form__row">
            <div class="sv-form__group">
              <label for="sv_price">Purchase Price (approx.)</label>
              <select id="sv_price" name="sv_price">
                <option value="">Prefer not to say</option>
                <option value="under-150k">Under £150,000</option>
                <option value="150-250k">£150,000 – £250,000</option>
                <option value="250-400k">£250,000 – £400,000</option>
                <option value="400-600k">£400,000 – £600,000</option>
                <option value="over-600k">Over £600,000</option>
              </select>
            </div>
            <div class="sv-form__group">
              <label for="sv_property_type">Property Type</label>
              <select id="sv_property_type" name="sv_property_type">
                <option value="">Select type…</option>
                <option value="victorian">Victorian / Edwardian</option>
                <option value="inter-war">Inter-War (1920s–1940s)</option>
                <option value="post-war">Post-War (1950s–1980s)</option>
                <option value="modern">Modern (1990s+)</option>
                <option value="new-build">New Build</option>
                <option value="listed">Listed Building</option>
                <option value="non-standard">Non-Standard Construction</option>
              </select>
            </div>
          </div>
          <div class="sv-form__group">
            <label for="sv_notes">Additional Notes</label>
            <textarea id="sv_notes" name="sv_notes" placeholder="Describe any specific concerns — damp, subsidence, roof condition, extensions, etc."></textarea>
          </div>
          <button type="submit" class="sv-form__submit">✦ Request My Survey Quote</button>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════ FOOTER ═══════════════ -->
<footer class="sv-footer">
  <div class="sv-container">
    <p>&copy; <?php echo esc_html(date('Y')); ?> <?php bloginfo('name'); ?> &mdash; Meridian Surveyors. RICS Regulated. All rights reserved.</p>
  </div>
</footer>

</div><!-- /.sv-wrap -->

<script>
(function(){
  'use strict';

  /* ── Animated counters ─────────────────────────────── */
  var easeOut = function(t){ return 1 - Math.pow(1 - t, 3); };
  var counters = document.querySelectorAll('.sv-counter__val[data-target]');

  if ('IntersectionObserver' in window) {
    var obs = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if (!entry.isIntersecting) return;
        obs.unobserve(entry.target);
        var el     = entry.target;
        var target = parseFloat(el.dataset.target);
        var suffix = el.dataset.suffix || '';
        var isFloat= el.dataset.float === '1';
        if (isNaN(target)) return;
        var duration = 1800, start = null;
        function tick(ts){
          if (!start) start = ts;
          var p = Math.min((ts - start) / duration, 1);
          var v = target * easeOut(p);
          el.textContent = (isFloat ? v.toFixed(1) : Math.floor(v)) + suffix;
          if (p < 1) requestAnimationFrame(tick);
          else el.textContent = (isFloat ? target.toFixed(1) : target) + suffix;
        }
        requestAnimationFrame(tick);
      });
    }, { threshold: 0.4 });
    counters.forEach(function(el){ obs.observe(el); });
  } else {
    counters.forEach(function(el){
      el.textContent = el.dataset.target + (el.dataset.suffix || '');
    });
  }

  /* ── Mouse parallax on particles ──────────────────── */
  var particles = document.querySelectorAll('.sv-particle');
  var hero = document.querySelector('.sv-hero');
  if (hero) {
    hero.addEventListener('mousemove', function(e){
      var rect = hero.getBoundingClientRect();
      var dx = (e.clientX - rect.left - rect.width / 2) / rect.width;
      var dy = (e.clientY - rect.top - rect.height / 2) / rect.height;
      particles.forEach(function(p, i){
        var depth = (i % 4 + 1) * 5;
        p.style.transform = 'translate(' + (dx * depth) + 'px, ' + (dy * depth) + 'px)';
      });
    });
  }

})();
</script>

</body>
</html>
</div><!-- .sv-page -->
<?php get_footer(); ?>
