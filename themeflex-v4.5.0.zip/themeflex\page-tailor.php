<?php
/**
 * Template Name: Tailor – Bespoke Savile Row Tailoring
 *
 * Premium bespoke tailor homepage template.
 * Libre Baskerville + Montserrat · --tl-* namespace · charcoal/ivory/navy palette
 * CSS art-directed atelier hero · WCAG 2.1 AA · vanilla JS
 *
 * @package ThemeFlex
 */

defined( 'ABSPATH' ) || exit;

srand( crc32( get_the_permalink() ) );

/* ── palette ────────────────────────────────────────────────────────── */
$tl_charcoal = '#2A2A2A';
$tl_navy     = '#1A2A4A';
$tl_ivory    = '#F8F5EE';
$tl_stone    = '#E8E2D4';
$tl_gold     = '#B8922A';
$tl_mid      = '#6A6058';
$tl_text     = '#3A3530';

/* ── fabric swatches ─────────────────────────────────────────────────*/
$fabrics = [
    [ 'name' => 'Charcoal Herringbone',  'color' => '#3A3A3A', 'pattern' => 'herringbone', 'origin' => 'Scabal, England'   ],
    [ 'name' => 'Navy Hopsack',          'color' => '#1A2A4A', 'pattern' => 'plain',       'origin' => 'Holland & Sherry'  ],
    [ 'name' => 'Mid-Grey Flannel',      'color' => '#5A5A5A', 'pattern' => 'plain',       'origin' => 'Dormeuil, France'  ],
    [ 'name' => 'Chalk Stripe',          'color' => '#3A3A4A', 'pattern' => 'stripe',      'origin' => 'Dugdale Bros'      ],
    [ 'name' => 'Camel Overcoat',        'color' => '#B08040', 'pattern' => 'plain',       'origin' => 'Loro Piana, Italy' ],
    [ 'name' => 'Prince of Wales Check', 'color' => '#4A4A3A', 'pattern' => 'check',       'origin' => 'W. Bill, London'   ],
];

/* ── floating needle & thread decorations ────────────────────────────*/
$needles = [];
for ( $i = 0; $i < 12; $i++ ) {
    $needles[] = [
        'x'     => rand( 3, 96 ),
        'y'     => rand( 5, 88 ),
        'rot'   => rand( -80, 80 ),
        'sz'    => rand( 18, 32 ),
        'op'    => rand( 4, 14 ),
        'delay' => rand( 0, 80 ) / 10,
        'dur'   => rand( 40, 70 ) / 10,
    ];
}

/* ── garment types offered ───────────────────────────────────────────*/
$garments = [
    [ 'icon' => '👔', 'name' => 'Bespoke Suits',          'desc' => 'Two and three-piece suits cut from scratch to your measurements and posture — never from a block.' ],
    [ 'icon' => '🎩', 'name' => 'Morning & Dress Wear',   'desc' => 'Morning coats, white tie, black tie, and evening dress tailored for ceremonies and occasions of distinction.' ],
    [ 'icon' => '🧥', 'name' => 'Overcoats & Topcoats',   'desc' => 'Single and double-breasted overcoats in the finest English and Italian heavy-weight wools.' ],
    [ 'icon' => '👞', 'name' => 'Trousers & Waistcoats',  'desc' => 'Individual trouser and waistcoat orders to complement existing wardrobes or complete a new commission.' ],
    [ 'icon' => '👕', 'name' => 'Dress Shirts',           'desc' => 'Made-to-measure shirts in Sea Island cotton, poplin, and twill — individual collar, cuff, and placket.' ],
    [ 'icon' => '💍', 'name' => 'Wedding Commissions',    'desc' => 'Groom and groomsmen packages with dedicated appointments and complimentary post-wedding alterations.' ],
];

/* ── process steps ───────────────────────────────────────────────────*/
$process = [
    [ 'num' => 'I',   'title' => 'First Consultation',   'desc' => 'We discuss your requirements, lifestyle, and aesthetic — fabric selection, lining, and all details that define a truly personal garment.' ],
    [ 'num' => 'II',  'title' => 'Measurement & Pattern', 'desc' => 'Thirty-two measurements taken by hand. A unique paper pattern is cut for your body alone — never used again for another client.' ],
    [ 'num' => 'III', 'title' => 'Baste Fitting',         'desc' => 'The garment is tacked together in its unlined form. We fit, mark, and correct all structural elements at this stage.' ],
    [ 'num' => 'IV',  'title' => 'Forward Fitting',       'desc' => 'Lining, canvas, and finishing underway. A second fitting confirms shape, comfort, and final adjustments.' ],
    [ 'num' => 'V',   'title' => 'Final Delivery',        'desc' => 'Your completed garment is pressed, inspected, and presented in our signature garment bag — ready for a lifetime of wear.' ],
];

/* ── packages ────────────────────────────────────────────────────────*/
$packages = [
    [
        'name'     => 'Bespoke Two-Piece',
        'price'    => 'From £3,400',
        'period'   => '',
        'featured' => false,
        'items'    => [ 'Full bespoke cut pattern', 'Fabric selection from 1,200+ bunches', '4 fittings included', 'Hand-sewn buttonholes', 'Signature taffeta lining', 'Complimentary alterations (1 year)' ],
    ],
    [
        'name'     => 'Bespoke Three-Piece',
        'price'    => 'From £4,200',
        'period'   => '',
        'featured' => true,
        'items'    => [ 'All Two-Piece inclusions', 'Matching bespoke waistcoat', 'Luxury choice of lining', 'Surgeon\'s cuff (working buttons)', 'Personalised inside pocket label', 'Priority appointment booking' ],
    ],
    [
        'name'     => 'Wedding Commission',
        'price'    => 'POA',
        'period'   => '',
        'featured' => false,
        'items'    => [ 'Dedicated wedding consultant', 'Groom + up to 4 groomsmen', 'Morning coat, lounge or black tie', 'Colour-matched accessories', 'Pressing day before ceremony', 'Post-wedding alterations included' ],
    ],
];

/* ── counters ────────────────────────────────────────────────────────*/
$counters = [
    [ 'value' => 94,   'suffix' => 'yrs',  'label' => 'Est. Savile Row',     'float' => false ],
    [ 'value' => 8400, 'suffix' => '+',    'label' => 'Suits Commissioned',  'float' => false ],
    [ 'value' => 4.9,  'suffix' => '★',   'label' => 'Client Rating',       'float' => true  ],
    [ 'value' => 6,    'suffix' => 'gen.',  'label' => 'Family Cutters',     'float' => false ],
];

/* ── testimonials ────────────────────────────────────────────────────*/
$testimonials = [
    [ 'text' => 'I have had suits made on Savile Row for thirty years. Pemberton & Sons produce the finest garments of any house I have visited — the precision of the cut and the quality of the make is simply unmatched.', 'name' => 'Lord A. C.', 'occasion' => 'Board Member' ],
    [ 'text' => 'My wedding suit was extraordinary. The consultation process made me feel entirely involved and the final result was everything I had imagined and more. The compliments on the day were endless.', 'name' => 'James H.', 'occasion' => 'Wedding Commission' ],
    [ 'text' => 'The attention to my particular posture — a high right shoulder from an old injury — was handled with such skill that the completed jacket sits perfectly straight for the first time in my adult life.', 'name' => 'Dr Michael F.', 'occasion' => 'Bespoke Three-Piece' ],
];

/* ── PHP CSS suit silhouettes for hero ───────────────────────────────*/
$suit_positions = [
    [ 'x' => 62, 'scale' => 1.1, 'opacity' => .9, 'color' => '#1A2A4A' ],
    [ 'x' => 75, 'scale' => .85, 'opacity' => .5, 'color' => '#2A2A2A' ],
    [ 'x' => 52, 'scale' => .7,  'opacity' => .3, 'color' => '#3A3A3A' ],
];

get_header();
?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&family=Montserrat:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<style>
/* ═══════════════════════════════════════════════════════════════════════
   BESPOKE TAILOR — CSS CUSTOM PROPERTIES
═══════════════════════════════════════════════════════════════════════ */
:root {
    --tl-charcoal: <?= $tl_charcoal ?>;
    --tl-navy:     <?= $tl_navy ?>;
    --tl-ivory:    <?= $tl_ivory ?>;
    --tl-stone:    <?= $tl_stone ?>;
    --tl-gold:     <?= $tl_gold ?>;
    --tl-mid:      <?= $tl_mid ?>;
    --tl-text:     <?= $tl_text ?>;

    --tl-ff-head: 'Libre Baskerville', serif;
    --tl-ff-body: 'Montserrat', sans-serif;

    --tl-radius: 0px;
    --tl-shadow: 0 4px 32px rgba(26,42,74,.12);
    --tl-trans:  .3s cubic-bezier(.4,0,.2,1);
}

/* ── reset ──────────────────────────────────────────────────────────── */
.tl-wrap *, .tl-wrap *::before, .tl-wrap *::after { box-sizing: border-box; margin: 0; padding: 0; }
.tl-wrap { font-family: var(--tl-ff-body); color: var(--tl-text); background: var(--tl-ivory); overflow-x: hidden; }
.tl-container { max-width: 1160px; margin: 0 auto; padding: 0 24px; }

/* ── typography ─────────────────────────────────────────────────────── */
.tl-section-label { font-family: var(--tl-ff-body); font-size: .65rem; font-weight: 600; letter-spacing: .25em; text-transform: uppercase; color: var(--tl-gold); display: block; margin-bottom: 14px; }
.tl-section-title { font-family: var(--tl-ff-head); font-size: clamp(1.8rem, 3.5vw, 2.8rem); font-weight: 700; line-height: 1.25; color: var(--tl-charcoal); }
.tl-section-title em { font-style: italic; color: var(--tl-navy); }
.tl-section-body  { font-size: .9rem; line-height: 1.9; color: var(--tl-mid); margin-top: 18px; font-weight: 300; letter-spacing: .01em; }

/* ── rule ───────────────────────────────────────────────────────────── */
.tl-rule { width: 48px; height: 1px; background: var(--tl-gold); margin: 20px 0; }

/* ── buttons ────────────────────────────────────────────────────────── */
.tl-btn { display: inline-flex; align-items: center; gap: 8px; font-family: var(--tl-ff-body); font-size: .72rem; font-weight: 700; letter-spacing: .18em; text-transform: uppercase; padding: 14px 32px; cursor: pointer; border: 1px solid transparent; text-decoration: none; transition: var(--tl-trans); }
.tl-btn--primary { background: var(--tl-navy); color: var(--tl-ivory); border-color: var(--tl-navy); }
.tl-btn--primary:hover { background: #0E1A30; transform: translateY(-2px); box-shadow: 0 8px 24px rgba(26,42,74,.3); }
.tl-btn--ghost { background: transparent; color: rgba(248,245,238,.9); border-color: rgba(248,245,238,.4); }
.tl-btn--ghost:hover { background: rgba(248,245,238,.1); }
.tl-btn--outline { background: transparent; color: var(--tl-navy); border-color: var(--tl-navy); }
.tl-btn--outline:hover { background: var(--tl-navy); color: var(--tl-ivory); }

/* ════════════════════════════════════════════════════════════════════
   HERO
════════════════════════════════════════════════════════════════════ */
.tl-hero { position: relative; min-height: 95vh; display: flex; align-items: center; overflow: hidden;
    background: linear-gradient(150deg, #181818 0%, #222232 45%, #0E1828 100%); }

/* ── atelier scene ────────────────────────────────────────────────── */
.tl-scene { position: absolute; inset: 0; overflow: hidden; }

/* panelled walls */
.tl-scene__wall { position: absolute; top: 0; left: 0; right: 0; bottom: 22%; background: linear-gradient(180deg, #1C1C1C 0%, #181818 100%); }
/* wall panelling */
.tl-scene__wall::after { content: ''; position: absolute; inset: 0; background: repeating-linear-gradient(90deg, rgba(255,255,255,.025) 0px, rgba(255,255,255,.025) 1px, transparent 1px, transparent 160px), repeating-linear-gradient(0deg, rgba(255,255,255,.025) 0px, rgba(255,255,255,.025) 1px, transparent 1px, transparent 120px); }
/* dado rail */
.tl-scene__dado { position: absolute; top: 60%; left: 0; right: 0; height: 6px; background: linear-gradient(180deg, #3A3020 0%, #2A2010 100%); }
.tl-scene__dado::before { content: ''; position: absolute; top: -2px; left: 0; right: 0; height: 2px; background: rgba(184,146,42,.2); }
/* lower panelling */
.tl-scene__lower { position: absolute; top: calc(60% + 6px); left: 0; right: 0; bottom: 22%; background: linear-gradient(180deg, #141414 0%, #101010 100%); }
/* floor — dark herringbone */
.tl-scene__floor { position: absolute; bottom: 0; left: 0; right: 0; height: 22%; background: linear-gradient(180deg, #282218 0%, #1E1A10 100%); }
.tl-scene__floor-line { position: absolute; top: 0; left: 0; right: 0; height: 2px; background: #3A3020; }
.tl-scene__floor::before { content: ''; position: absolute; inset: 0; background: repeating-linear-gradient(45deg, rgba(255,255,255,.03) 0px, rgba(255,255,255,.03) 1px, transparent 1px, transparent 20px), repeating-linear-gradient(-45deg, rgba(255,255,255,.03) 0px, rgba(255,255,255,.03) 1px, transparent 1px, transparent 20px); }

/* tailor's table */
.tl-scene__table { position: absolute; bottom: 22%; left: 10%; width: 52%; }
.tl-scene__table-top { height: 10px; background: linear-gradient(180deg, #C8B888 0%, #A89868 100%); box-shadow: 0 -2px 6px rgba(0,0,0,.4); }
.tl-scene__table-body { height: 40px; background: linear-gradient(180deg, #785830 0%, #584018 100%); position: relative; }
.tl-scene__table-body::before { content: ''; position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); width: 80px; height: 18px; background: rgba(255,255,255,.04); }
.tl-scene__table-leg { position: absolute; bottom: -28px; width: 8px; height: 28px; background: #483828; }

/* fabric bolt on table */
.tl-scene__bolt { position: absolute; top: -22px; left: 6%; }
.tl-scene__bolt-roll { width: 20px; height: 34px; border-radius: 2px; position: relative; }
.tl-scene__bolt-roll::before { content: ''; position: absolute; inset: 0; border-radius: 2px; background: repeating-linear-gradient(0deg, rgba(255,255,255,.06) 0px, rgba(255,255,255,.06) 2px, transparent 2px, transparent 8px); }

/* tailor's dummy / dress form */
.tl-scene__dummy { position: absolute; right: 6%; bottom: 22%; }
.tl-scene__dummy-stand { width: 4px; height: 48px; background: #6A5A3A; margin: 0 auto; }
.tl-scene__dummy-base { width: 30px; height: 6px; background: linear-gradient(180deg, #8A7040 0%, #6A5020 100%); margin: 0 auto; border-radius: 1px; }
.tl-scene__dummy-pole { width: 2px; height: 16px; background: #6A5A3A; margin: 0 auto; }
.tl-scene__dummy-body { width: 40px; height: 52px; background: radial-gradient(ellipse at 50% 50%, #2A3A5A 0%, #1A2A4A 100%); clip-path: polygon(20% 0%, 80% 0%, 90% 100%, 10% 100%); margin: 0 auto; position: relative; }
.tl-scene__dummy-body::before { content: ''; position: absolute; top: 20%; left: 10%; right: 10%; height: 1px; background: rgba(184,146,42,.3); box-shadow: 0 10px 0 rgba(184,146,42,.2); }
.tl-scene__dummy-shoulder { width: 56px; height: 12px; background: radial-gradient(ellipse at 50% 50%, #344868 0%, #1A2A4A 100%); clip-path: ellipse(50% 50% at 50% 50%); margin: 0 auto; }

/* wardrobe / suits hanging */
.tl-scene__rail { position: absolute; top: 14%; right: 14%; width: 24%; height: 4px; background: linear-gradient(180deg, #5A4A2A 0%, #3A3018 100%); }
.tl-scene__rail::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 2px; background: rgba(184,146,42,.3); }
/* hanging suits */
.tl-scene__hanger { position: absolute; top: 18%; }
.tl-hanger { position: relative; }
.tl-hanger__hook { width: 6px; height: 10px; border-top: 2px solid #7A6A4A; border-radius: 50% 50% 0 0; margin: 0 auto; }
.tl-hanger__bar { width: 24px; height: 2px; background: #7A6A4A; margin: 0 auto; }
.tl-hanger__bar::before, .tl-hanger__bar::after { content: ''; position: absolute; top: 2px; width: 2px; height: 8px; background: #7A6A4A; }
.tl-hanger__bar::before { left: 0; transform: rotate(8deg); transform-origin: top; }
.tl-hanger__bar::after { right: 0; transform: rotate(-8deg); transform-origin: top; }
.tl-hanger__jacket { position: relative; margin-top: 2px; width: 28px; }
.tl-hanger__jacket-body { height: 38px; border-radius: 0 0 2px 2px; position: relative; }
.tl-hanger__jacket-body::before { content: ''; position: absolute; top: 0; left: 8px; width: 5px; height: 20px; background: rgba(255,255,255,.06); clip-path: polygon(0 0, 100% 0, 70% 100%, 0 100%); }
.tl-hanger__jacket-body::after { content: ''; position: absolute; top: 0; right: 8px; width: 5px; height: 20px; background: rgba(255,255,255,.06); clip-path: polygon(0 0, 100% 0, 100% 100%, 30% 100%); }
.tl-hanger__jacket-shoulder { height: 8px; border-radius: 4px 4px 0 0; }

/* sewing tools on table */
.tl-scene__scissors { position: absolute; top: -14px; left: 36%; width: 28px; height: 10px; background: rgba(160,160,176,.6); border-radius: 1px; transform: rotate(-20deg); }
.tl-scene__tape { position: absolute; top: -12px; left: 52%; width: 16px; height: 16px; background: rgba(160,100,50,.5); border-radius: 50%; }
.tl-scene__tape::before { content: ''; position: absolute; inset: 3px; background: rgba(184,146,42,.2); border-radius: 50%; }

/* tailor figure at table */
.tl-scene__tailor { position: absolute; bottom: 22%; left: 28%; }
.tl-tailor-fig__head { width: 24px; height: 28px; background: #C89870; border-radius: 50% 50% 40% 40%; margin: 0 auto; position: relative; }
.tl-tailor-fig__hair { position: absolute; top: 0; left: 0; right: 0; height: 14px; background: #4A3020; clip-path: ellipse(50% 55% at 50% 0%); }
.tl-tailor-fig__neck { width: 10px; height: 6px; background: #C89870; margin: 0 auto; }
.tl-tailor-fig__body { width: 30px; height: 44px; background: linear-gradient(180deg, #F0E8D8 0%, #E0D8C8 100%); border-radius: 2px 2px 0 0; margin: 0 auto; position: relative; }
/* waistcoat overlay */
.tl-tailor-fig__body::before { content: ''; position: absolute; inset: 0; background: linear-gradient(180deg, #2A3A5A 0%, #1A2A4A 100%); clip-path: polygon(12% 0%, 88% 0%, 80% 100%, 20% 100%); }
/* measuring tape draped over shoulder */
.tl-tailor-fig__tape { position: absolute; top: 2px; left: -6px; width: 14px; height: 3px; background: rgba(184,146,42,.6); transform: rotate(-5deg); }
.tl-tailor-fig__arm-l { position: absolute; left: -9px; top: 8px; width: 9px; height: 24px; background: #F0E8D8; border-radius: 3px 0 0 3px; }
.tl-tailor-fig__arm-r { position: absolute; right: -9px; top: 8px; width: 9px; height: 24px; background: #F0E8D8; border-radius: 0 3px 3px 0; }

/* floating needles */
.tl-needle { position: absolute; pointer-events: none; }
.tl-needle__body { width: 2px; background: linear-gradient(180deg, #D0C8B8 0%, #A09880 100%); border-radius: 1px; position: relative; }
.tl-needle__eye { position: absolute; top: 0; left: 50%; transform: translateX(-50%); width: 4px; height: 4px; border: 1px solid #A09880; border-radius: 50%; }
.tl-needle__point { position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); width: 0; height: 0; border-left: 1px solid transparent; border-right: 1px solid transparent; border-top: 4px solid #A09880; }

/* warm spot lights */
.tl-spot { position: absolute; top: 0; pointer-events: none; }
.tl-spot__cone { clip-path: polygon(25% 0%, 75% 0%, 100% 100%, 0% 100%); }

/* hero content */
.tl-hero__content { position: relative; z-index: 10; max-width: 560px; padding: 80px 0; }
.tl-hero__eyebrow { font-family: var(--tl-ff-body); font-size: .65rem; font-weight: 700; letter-spacing: .28em; text-transform: uppercase; color: var(--tl-gold); margin-bottom: 18px; }
.tl-hero__title { font-family: var(--tl-ff-head); font-size: clamp(2.6rem, 5.5vw, 4.4rem); font-weight: 700; line-height: 1.1; color: var(--tl-ivory); }
.tl-hero__title em { font-style: italic; color: var(--tl-gold); }
.tl-hero__rule { width: 56px; height: 1px; background: var(--tl-gold); margin: 22px 0; }
.tl-hero__sub { font-size: .9rem; line-height: 1.9; color: rgba(248,245,238,.65); font-weight: 300; letter-spacing: .02em; margin-bottom: 36px; }
.tl-hero__ctas { display: flex; gap: 14px; flex-wrap: wrap; }
.tl-hero__since { margin-top: 32px; font-family: var(--tl-ff-body); font-size: .65rem; font-weight: 600; letter-spacing: .25em; text-transform: uppercase; color: rgba(248,245,238,.35); }

/* ════════════════════════════════════════════════════════════════════
   TRUST BAR
════════════════════════════════════════════════════════════════════ */
.tl-trust { background: var(--tl-charcoal); border-bottom: 1px solid #3A3028; }
.tl-trust__inner { display: flex; align-items: center; justify-content: center; flex-wrap: wrap; }
.tl-trust__item { display: flex; align-items: center; gap: 12px; padding: 20px 32px; border-right: 1px solid #3A3028; }
.tl-trust__item:last-child { border-right: none; }
.tl-trust__icon { font-size: 1.3rem; }
.tl-trust__label { font-family: var(--tl-ff-body); font-size: .72rem; font-weight: 700; color: var(--tl-ivory); letter-spacing: .1em; text-transform: uppercase; }
.tl-trust__sub { font-size: .68rem; color: #8A7A68; letter-spacing: .05em; }

/* ════════════════════════════════════════════════════════════════════
   GARMENTS
════════════════════════════════════════════════════════════════════ */
.tl-garments { padding: 100px 0; background: var(--tl-ivory); }
.tl-garments__header { text-align: center; max-width: 560px; margin: 0 auto 60px; }
.tl-garments__header .tl-rule { margin: 20px auto; }
.tl-garments__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 2px; }
.tl-garment-card { background: #fff; padding: 36px 32px; border: 1px solid var(--tl-stone); transition: var(--tl-trans); position: relative; }
.tl-garment-card::after { content: ''; position: absolute; bottom: 0; left: 0; width: 100%; height: 2px; background: var(--tl-gold); transform: scaleX(0); transform-origin: left; transition: var(--tl-trans); }
.tl-garment-card:hover { box-shadow: var(--tl-shadow); }
.tl-garment-card:hover::after { transform: scaleX(1); }
.tl-garment-card__icon { font-size: 2.2rem; margin-bottom: 16px; display: block; }
.tl-garment-card__name { font-family: var(--tl-ff-head); font-size: 1.05rem; font-weight: 700; color: var(--tl-charcoal); margin-bottom: 10px; }
.tl-garment-card__desc { font-size: .88rem; line-height: 1.8; color: var(--tl-mid); font-weight: 300; }

/* ════════════════════════════════════════════════════════════════════
   FABRICS
════════════════════════════════════════════════════════════════════ */
.tl-fabrics { padding: 80px 0; background: var(--tl-stone); }
.tl-fabrics__header { text-align: center; max-width: 560px; margin: 0 auto 48px; }
.tl-fabrics__header .tl-rule { margin: 20px auto; }
.tl-fabrics__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 16px; }
.tl-fabric-card { background: #fff; padding: 0; border: 1px solid #D0C8B8; overflow: hidden; transition: var(--tl-trans); }
.tl-fabric-card:hover { box-shadow: var(--tl-shadow); transform: translateY(-2px); }
.tl-fabric-card__swatch { height: 80px; position: relative; overflow: hidden; }
.tl-fabric-card__info { padding: 14px 16px 18px; }
.tl-fabric-card__name { font-family: var(--tl-ff-head); font-size: .82rem; font-weight: 700; color: var(--tl-charcoal); margin-bottom: 4px; }
.tl-fabric-card__origin { font-family: var(--tl-ff-body); font-size: .7rem; color: var(--tl-mid); font-weight: 300; letter-spacing: .05em; }

/* ════════════════════════════════════════════════════════════════════
   COUNTERS
════════════════════════════════════════════════════════════════════ */
.tl-counters { background: linear-gradient(135deg, var(--tl-navy) 0%, #0A1020 100%); padding: 80px 0; }
.tl-counters__grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 40px; text-align: center; }
.tl-counter__value { font-family: var(--tl-ff-head); font-size: clamp(2.4rem, 4vw, 3.4rem); font-weight: 700; color: var(--tl-ivory); line-height: 1; }
.tl-counter__value span { color: var(--tl-gold); }
.tl-counter__label { font-family: var(--tl-ff-body); font-size: .68rem; font-weight: 600; color: rgba(248,245,238,.45); text-transform: uppercase; letter-spacing: .18em; margin-top: 12px; }

/* ════════════════════════════════════════════════════════════════════
   PROCESS
════════════════════════════════════════════════════════════════════ */
.tl-process { padding: 100px 0; background: var(--tl-ivory); }
.tl-process__header { text-align: center; max-width: 560px; margin: 0 auto 60px; }
.tl-process__header .tl-rule { margin: 20px auto; }
.tl-process__timeline { display: flex; flex-direction: column; gap: 0; max-width: 800px; margin: 0 auto; }
.tl-process-step { display: grid; grid-template-columns: 64px 1fr; gap: 32px; padding: 36px 0; border-bottom: 1px solid var(--tl-stone); }
.tl-process-step:last-child { border-bottom: none; }
.tl-process-step__num { font-family: var(--tl-ff-head); font-size: 2.4rem; font-weight: 700; color: var(--tl-stone); line-height: 1; }
.tl-process-step__title { font-family: var(--tl-ff-head); font-size: 1.12rem; font-weight: 700; color: var(--tl-charcoal); margin-bottom: 8px; }
.tl-process-step__desc { font-size: .9rem; line-height: 1.8; color: var(--tl-mid); font-weight: 300; }

/* ════════════════════════════════════════════════════════════════════
   PACKAGES
════════════════════════════════════════════════════════════════════ */
.tl-packages { padding: 100px 0; background: var(--tl-stone); }
.tl-packages__header { text-align: center; max-width: 580px; margin: 0 auto 60px; }
.tl-packages__header .tl-rule { margin: 20px auto; }
.tl-packages__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 2px; align-items: start; }
.tl-package-card { background: var(--tl-ivory); padding: 44px 40px; border: 1px solid #D0C8B8; position: relative; transition: var(--tl-trans); }
.tl-package-card:hover { box-shadow: var(--tl-shadow); }
.tl-package-card--featured { background: var(--tl-navy); border-color: var(--tl-navy); }
.tl-package-card--featured .tl-package-card__name,
.tl-package-card--featured .tl-package-card__price,
.tl-package-card--featured .tl-package-card__item { color: rgba(248,245,238,.95); }
.tl-package-card--featured .tl-package-card__item::before { background: var(--tl-gold); }
.tl-package-card--featured .tl-rule { background: var(--tl-gold); }
.tl-package-card__badge { position: absolute; top: 0; right: 0; background: var(--tl-gold); color: var(--tl-charcoal); font-family: var(--tl-ff-body); font-size: .62rem; font-weight: 800; letter-spacing: .15em; text-transform: uppercase; padding: 5px 16px; }
.tl-package-card__name { font-family: var(--tl-ff-head); font-size: 1.2rem; font-weight: 700; color: var(--tl-charcoal); margin-bottom: 8px; }
.tl-package-card__price { font-family: var(--tl-ff-head); font-size: 1.6rem; font-weight: 700; color: var(--tl-charcoal); margin-bottom: 4px; }
.tl-package-card__list { list-style: none; display: flex; flex-direction: column; gap: 10px; margin-bottom: 32px; }
.tl-package-card__item { font-family: var(--tl-ff-body); font-size: .85rem; color: var(--tl-mid); padding-left: 18px; position: relative; font-weight: 300; }
.tl-package-card__item::before { content: ''; position: absolute; left: 0; top: 50%; transform: translateY(-50%); width: 6px; height: 1px; background: var(--tl-gold); }

/* ════════════════════════════════════════════════════════════════════
   TESTIMONIALS
════════════════════════════════════════════════════════════════════ */
.tl-testimonials { padding: 100px 0; background: var(--tl-ivory); }
.tl-testimonials__header { text-align: center; max-width: 560px; margin: 0 auto 56px; }
.tl-testimonials__header .tl-rule { margin: 20px auto; }
.tl-testimonials__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 32px; }
.tl-testimonial { padding: 40px; border: 1px solid var(--tl-stone); background: #fff; }
.tl-testimonial__quote { font-family: var(--tl-ff-head); font-size: 4rem; color: var(--tl-stone); line-height: 1; margin-bottom: 8px; }
.tl-testimonial__text { font-family: var(--tl-ff-head); font-size: .92rem; line-height: 1.9; color: var(--tl-text); font-style: italic; font-weight: 400; }
.tl-testimonial__author { margin-top: 24px; padding-top: 20px; border-top: 1px solid var(--tl-stone); }
.tl-testimonial__name { font-family: var(--tl-ff-body); font-size: .82rem; font-weight: 700; color: var(--tl-charcoal); letter-spacing: .08em; text-transform: uppercase; }
.tl-testimonial__occasion { font-size: .75rem; color: var(--tl-gold); font-weight: 300; margin-top: 3px; letter-spacing: .06em; }

/* ════════════════════════════════════════════════════════════════════
   BOOKING
════════════════════════════════════════════════════════════════════ */
.tl-booking { padding: 100px 0; background: var(--tl-charcoal); }
.tl-booking__inner { display: grid; grid-template-columns: 1fr 1fr; gap: 72px; align-items: start; }
.tl-booking__info { }
.tl-form { background: rgba(255,255,255,.04); padding: 44px; border: 1px solid rgba(255,255,255,.08); }
.tl-form__title { font-family: var(--tl-ff-head); font-size: 1.4rem; font-weight: 700; color: var(--tl-ivory); margin-bottom: 28px; }
.tl-form__row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.tl-form__group { display: flex; flex-direction: column; gap: 6px; margin-bottom: 18px; }
.tl-form__group--full { grid-column: 1 / -1; }
.tl-form__label { font-family: var(--tl-ff-body); font-size: .66rem; font-weight: 700; color: #8A7A68; letter-spacing: .18em; text-transform: uppercase; }
.tl-form__input, .tl-form__select, .tl-form__textarea { width: 100%; padding: 12px 16px; border: 1px solid rgba(255,255,255,.1); background: rgba(255,255,255,.05); font-family: var(--tl-ff-body); font-size: .88rem; color: var(--tl-ivory); transition: var(--tl-trans); outline: none; font-weight: 300; }
.tl-form__input::placeholder { color: rgba(248,245,238,.25); }
.tl-form__input:focus, .tl-form__select:focus, .tl-form__textarea:focus { border-color: var(--tl-gold); box-shadow: 0 0 0 3px rgba(184,146,42,.12); }
.tl-form__select option { background: var(--tl-charcoal); }
.tl-form__textarea { resize: vertical; min-height: 100px; }
.tl-form__submit { width: 100%; padding: 15px; font-family: var(--tl-ff-body); font-size: .72rem; font-weight: 800; color: var(--tl-charcoal); background: var(--tl-gold); border: none; cursor: pointer; transition: var(--tl-trans); text-transform: uppercase; letter-spacing: .18em; }
.tl-form__submit:hover { background: #C8A232; transform: translateY(-2px); box-shadow: 0 8px 24px rgba(184,146,42,.3); }
.tl-form__note { font-size: .7rem; color: rgba(248,245,238,.3); text-align: center; margin-top: 14px; font-weight: 300; letter-spacing: .08em; }

/* ════════════════════════════════════════════════════════════════════
   FOOTER CTA
════════════════════════════════════════════════════════════════════ */
.tl-footer-cta { background: #0E1020; padding: 80px 0; text-align: center; border-top: 1px solid #1E1A10; }
.tl-footer-cta__title { font-family: var(--tl-ff-head); font-size: clamp(2rem, 4vw, 3.2rem); font-weight: 700; color: var(--tl-ivory); line-height: 1.2; margin-bottom: 14px; }
.tl-footer-cta__title em { font-style: italic; color: var(--tl-gold); }
.tl-footer-cta__rule { width: 48px; height: 1px; background: var(--tl-gold); margin: 18px auto 24px; }
.tl-footer-cta__sub { font-size: .82rem; color: rgba(248,245,238,.45); font-weight: 300; letter-spacing: .12em; text-transform: uppercase; margin-bottom: 36px; }
.tl-footer-cta__actions { display: flex; gap: 14px; justify-content: center; flex-wrap: wrap; }

/* ════════════════════════════════════════════════════════════════════
   RESPONSIVE
════════════════════════════════════════════════════════════════════ */
@media (max-width: 900px) {
    .tl-booking__inner { grid-template-columns: 1fr; gap: 48px; }
    .tl-counters__grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 600px) {
    .tl-hero { min-height: 85vh; }
    .tl-counters__grid { grid-template-columns: repeat(2, 1fr); }
    .tl-form__row { grid-template-columns: 1fr; }
    .tl-trust__item { border-right: none; border-bottom: 1px solid #3A3028; }
    .tl-process-step { grid-template-columns: 44px 1fr; gap: 20px; }
}
</style>

<div class="tl-wrap">

    <!-- ═══════════════════════════════════ HERO ═══════════════════════════════════ -->
    <section class="tl-hero">
        <div class="tl-scene" aria-hidden="true">

            <!-- room structure -->
            <div class="tl-scene__wall"></div>
            <div class="tl-scene__dado"></div>
            <div class="tl-scene__lower"></div>
            <div class="tl-scene__floor">
                <div class="tl-scene__floor-line"></div>
            </div>

            <!-- suit rail -->
            <div class="tl-scene__rail"></div>
            <?php
            $hangers_data = [
                [ 'right' => '14%', 'color' => '#1A2A4A' ],
                [ 'right' => '20%', 'color' => '#2A2A2A' ],
                [ 'right' => '26%', 'color' => '#4A4A3A' ],
            ];
            foreach ( $hangers_data as $hd ) : ?>
            <div class="tl-scene__hanger" style="right:<?= $hd['right'] ?>;">
                <div class="tl-hanger">
                    <div class="tl-hanger__hook"></div>
                    <div class="tl-hanger__bar"></div>
                    <div class="tl-hanger__jacket">
                        <div class="tl-hanger__jacket-shoulder" style="background:<?= $hd['color'] ?>;"></div>
                        <div class="tl-hanger__jacket-body" style="background:<?= $hd['color'] ?>;"></div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>

            <!-- tailor's table -->
            <div class="tl-scene__table">
                <div class="tl-scene__bolt" style="left:5%;">
                    <?php foreach ( [ '#1A2A4A', '#3A3A3A', '#4A4A3A' ] as $bi => $bc ) : ?>
                    <div class="tl-scene__bolt-roll" style="background:<?= $bc ?>;width:<?= 16+$bi*4 ?>px;height:<?= 28+$bi*6 ?>px;position:absolute;left:<?= $bi*20 ?>px;top:<?= -28-$bi*6 ?>px;"></div>
                    <?php endforeach; ?>
                </div>
                <div class="tl-scene__scissors"></div>
                <div class="tl-scene__tape"></div>
                <div class="tl-scene__table-top"></div>
                <div class="tl-scene__table-body">
                    <div class="tl-scene__table-leg" style="left:6%;"></div>
                    <div class="tl-scene__table-leg" style="right:6%;"></div>
                </div>
            </div>

            <!-- tailor figure -->
            <div class="tl-scene__tailor">
                <div class="tl-tailor-fig__head">
                    <div class="tl-tailor-fig__hair"></div>
                </div>
                <div class="tl-tailor-fig__neck"></div>
                <div style="position:relative;display:inline-block;">
                    <div class="tl-tailor-fig__body">
                        <div class="tl-tailor-fig__tape"></div>
                        <div class="tl-tailor-fig__arm-l"></div>
                        <div class="tl-tailor-fig__arm-r"></div>
                    </div>
                </div>
            </div>

            <!-- dress dummy -->
            <div class="tl-scene__dummy">
                <div class="tl-scene__dummy-body"></div>
                <div class="tl-scene__dummy-shoulder"></div>
                <div class="tl-scene__dummy-pole"></div>
                <div class="tl-scene__dummy-stand"></div>
                <div class="tl-scene__dummy-base"></div>
            </div>

            <!-- floating needles -->
            <?php foreach ( $needles as $n ) : ?>
            <div class="tl-needle" style="left:<?=$n['x']?>%;top:<?=$n['y']?>%;transform:rotate(<?=$n['rot']?>deg);opacity:<?=$n['op']/100?>;animation:vt-paw-float <?=$n['delay']+4?>s <?=$n['delay']?>s ease-in-out infinite;">
                <div class="tl-needle__eye"></div>
                <div class="tl-needle__body" style="height:<?=$n['sz']?>px;"></div>
                <div class="tl-needle__point"></div>
            </div>
            <?php endforeach; ?>

        </div><!-- /.tl-scene -->

        <div class="tl-container">
            <div class="tl-hero__content">
                <p class="tl-hero__eyebrow">◆ Savile Row · Est. 1931 · By Appointment</p>
                <h1 class="tl-hero__title">
                    The Art of<br>
                    <em>Bespoke</em><br>
                    Tailoring
                </h1>
                <div class="tl-hero__rule"></div>
                <p class="tl-hero__sub">For over ninety years, Pemberton & Sons has cut garments of exceptional quality for discerning gentlemen who understand that true distinction lies in the details. Every suit is a unique creation — measured, cut, and sewn entirely by hand.</p>
                <div class="tl-hero__ctas">
                    <a href="#booking" class="tl-btn tl-btn--primary">Request a Consultation</a>
                    <a href="#garments" class="tl-btn tl-btn--ghost">Our Garments</a>
                </div>
                <p class="tl-hero__since">Savile Row, Mayfair, London W1S · By Appointment</p>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ TRUST BAR ═════════════════════════════ -->
    <div class="tl-trust">
        <div class="tl-container">
            <div class="tl-trust__inner">
                <?php
                $trust_items = [
                    [ 'icon' => '🧵', 'label' => 'Full Bespoke Cut',       'sub' => 'Individual paper pattern' ],
                    [ 'icon' => '✂️', 'label' => 'Hand-Sewn Throughout',   'sub' => 'Zero machine stitching' ],
                    [ 'icon' => '🏅', 'label' => 'Royal Warrant Holders',  'sub' => 'By appointment' ],
                    [ 'icon' => '🌍', 'label' => 'World-Wide Travel',      'sub' => 'Trunk show appointments' ],
                    [ 'icon' => '♾️', 'label' => 'Lifetime Alterations',   'sub' => 'As your body changes' ],
                ];
                foreach ( $trust_items as $ti ) : ?>
                <div class="tl-trust__item">
                    <span class="tl-trust__icon"><?= $ti['icon'] ?></span>
                    <div>
                        <div class="tl-trust__label"><?= esc_html( $ti['label'] ) ?></div>
                        <div class="tl-trust__sub"><?= esc_html( $ti['sub'] ) ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- ═══════════════════════════════════ GARMENTS ══════════════════════════════ -->
    <section class="tl-garments" id="garments">
        <div class="tl-container">
            <div class="tl-garments__header">
                <span class="tl-section-label">What We Make</span>
                <div class="tl-rule"></div>
                <h2 class="tl-section-title">Garments of <em>Distinction</em></h2>
                <p class="tl-section-body">Every piece is made from scratch in our Savile Row workrooms by craftsmen who have spent decades perfecting their technique. No shortcuts. No compromise.</p>
            </div>
            <div class="tl-garments__grid">
                <?php foreach ( $garments as $g ) : ?>
                <div class="tl-garment-card">
                    <span class="tl-garment-card__icon"><?= $g['icon'] ?></span>
                    <h3 class="tl-garment-card__name"><?= esc_html( $g['name'] ) ?></h3>
                    <p class="tl-garment-card__desc"><?= esc_html( $g['desc'] ) ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ FABRICS ───────────────────────────────  -->
    <section class="tl-fabrics">
        <div class="tl-container">
            <div class="tl-fabrics__header">
                <span class="tl-section-label">The Cloth</span>
                <div class="tl-rule"></div>
                <h2 class="tl-section-title">Over 1,200 <em>Fabric Bunches</em></h2>
                <p class="tl-section-body">We stock the finest cloths from the world's great mills — Scabal, Dormeuil, Loro Piana, Holland & Sherry, Dugdale Bros, and W. Bill — all available to inspect in person.</p>
            </div>
            <div class="tl-fabrics__grid">
                <?php foreach ( $fabrics as $fab ) :
                    $pat = $fab['pattern'];
                    if ( $pat === 'herringbone' ) {
                        $bg = "background:repeating-linear-gradient(45deg,{$fab['color']} 0px,{$fab['color']} 3px,rgba(255,255,255,.06) 3px,rgba(255,255,255,.06) 6px),repeating-linear-gradient(-45deg,{$fab['color']} 0px,{$fab['color']} 3px,rgba(255,255,255,.06) 3px,rgba(255,255,255,.06) 6px);";
                    } elseif ( $pat === 'stripe' ) {
                        $bg = "background:repeating-linear-gradient(90deg,{$fab['color']} 0px,{$fab['color']} 18px,rgba(255,255,255,.12) 18px,rgba(255,255,255,.12) 20px);";
                    } elseif ( $pat === 'check' ) {
                        $bg = "background:repeating-linear-gradient(90deg,rgba(255,255,255,.06) 0px,rgba(255,255,255,.06) 1px,transparent 1px,transparent 14px),repeating-linear-gradient(0deg,rgba(255,255,255,.06) 0px,rgba(255,255,255,.06) 1px,transparent 1px,transparent 14px),{$fab['color']};";
                    } else {
                        $bg = "background:radial-gradient(ellipse at 30% 30%,rgba(255,255,255,.05) 0%,transparent 60%),{$fab['color']};";
                    }
                ?>
                <div class="tl-fabric-card">
                    <div class="tl-fabric-card__swatch" style="<?= $bg ?>"></div>
                    <div class="tl-fabric-card__info">
                        <div class="tl-fabric-card__name"><?= esc_html( $fab['name'] ) ?></div>
                        <div class="tl-fabric-card__origin"><?= esc_html( $fab['origin'] ) ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ COUNTERS ═════════════════════════════ -->
    <section class="tl-counters" aria-label="House statistics">
        <div class="tl-container">
            <div class="tl-counters__grid">
                <?php foreach ( $counters as $c ) : ?>
                <div>
                    <div class="tl-counter__value"
                         data-target="<?= $c['value'] ?>"
                         <?= $c['float'] ? 'data-float="1"' : '' ?>>
                        <span>0</span><?= esc_html( $c['suffix'] ) ?>
                    </div>
                    <div class="tl-counter__label"><?= esc_html( $c['label'] ) ?></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ PROCESS ══════════════════════════════ -->
    <section class="tl-process">
        <div class="tl-container">
            <div class="tl-process__header">
                <span class="tl-section-label">The Journey</span>
                <div class="tl-rule"></div>
                <h2 class="tl-section-title">From First Meeting to <em>Finished Garment</em></h2>
            </div>
            <div class="tl-process__timeline">
                <?php foreach ( $process as $step ) : ?>
                <div class="tl-process-step">
                    <div class="tl-process-step__num"><?= esc_html( $step['num'] ) ?></div>
                    <div>
                        <div class="tl-process-step__title"><?= esc_html( $step['title'] ) ?></div>
                        <p class="tl-process-step__desc"><?= esc_html( $step['desc'] ) ?></p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ PACKAGES ═════════════════════════════ -->
    <section class="tl-packages" id="commission">
        <div class="tl-container">
            <div class="tl-packages__header">
                <span class="tl-section-label">Commissions</span>
                <div class="tl-rule"></div>
                <h2 class="tl-section-title">Your <em>Commission</em></h2>
                <p class="tl-section-body">All prices are guide figures — the final investment is discussed at consultation and reflects fabric selection, garment complexity, and any special requirements.</p>
            </div>
            <div class="tl-packages__grid">
                <?php foreach ( $packages as $pkg ) : ?>
                <div class="tl-package-card <?= $pkg['featured'] ? 'tl-package-card--featured' : '' ?>">
                    <?php if ( $pkg['featured'] ) : ?>
                    <div class="tl-package-card__badge">Most Popular</div>
                    <?php endif; ?>
                    <div class="tl-package-card__name"><?= esc_html( $pkg['name'] ) ?></div>
                    <div class="tl-package-card__price"><?= esc_html( $pkg['price'] ) ?></div>
                    <div class="tl-rule" style="margin:16px 0 24px;<?= $pkg['featured'] ? 'background:rgba(184,146,42,.5);' : '' ?>"></div>
                    <ul class="tl-package-card__list">
                        <?php foreach ( $pkg['items'] as $item ) : ?>
                        <li class="tl-package-card__item"><?= esc_html( $item ) ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <a href="#booking" class="tl-btn <?= $pkg['featured'] ? 'tl-btn--ghost' : 'tl-btn--outline' ?>" style="width:100%;justify-content:center;">
                        Enquire Now
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ TESTIMONIALS ═════════════════════════ -->
    <section class="tl-testimonials">
        <div class="tl-container">
            <div class="tl-testimonials__header">
                <span class="tl-section-label">Client Testimonials</span>
                <div class="tl-rule"></div>
                <h2 class="tl-section-title">Words of Our <em>Clients</em></h2>
            </div>
            <div class="tl-testimonials__grid">
                <?php foreach ( $testimonials as $t ) : ?>
                <div class="tl-testimonial">
                    <div class="tl-testimonial__quote">"</div>
                    <p class="tl-testimonial__text"><?= esc_html( $t['text'] ) ?></p>
                    <div class="tl-testimonial__author">
                        <div class="tl-testimonial__name"><?= esc_html( $t['name'] ) ?></div>
                        <div class="tl-testimonial__occasion"><?= esc_html( $t['occasion'] ) ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ BOOKING ══════════════════════════════ -->
    <section class="tl-booking" id="booking">
        <div class="tl-container">
            <div class="tl-booking__inner">
                <div class="tl-booking__info">
                    <span class="tl-section-label">Appointments</span>
                    <div class="tl-rule" style="background:var(--tl-gold);"></div>
                    <h2 style="font-family:var(--tl-ff-head);font-size:clamp(1.8rem,3.5vw,2.6rem);font-weight:700;line-height:1.2;color:var(--tl-ivory);margin-bottom:20px;">Request a <em style='font-style:italic;color:var(--tl-gold);'>Consultation</em></h2>
                    <p style="font-size:.9rem;line-height:1.9;color:rgba(248,245,238,.55);font-weight:300;letter-spacing:.01em;margin-bottom:32px;">We receive clients by appointment Monday to Friday. Consultations typically last 60–90 minutes and are complimentary and entirely without obligation.</p>
                    <?php
                    $address_items = [
                        [ 'icon' => '📍', 'val' => '4 Savile Row, Mayfair, London W1S 3PE' ],
                        [ 'icon' => '📞', 'val' => '020 7946 0400' ],
                        [ 'icon' => '✉️', 'val' => 'appointments@pembertonandson.co.uk' ],
                        [ 'icon' => '⏰', 'val' => 'Monday–Friday 9:30am–5:30pm · Saturday by arrangement' ],
                    ];
                    foreach ( $address_items as $ai ) : ?>
                    <div style="display:flex;gap:14px;margin-bottom:16px;align-items:flex-start;">
                        <span style="font-size:1.1rem;"><?= $ai['icon'] ?></span>
                        <span style="font-size:.85rem;color:rgba(248,245,238,.55);font-weight:300;letter-spacing:.02em;"><?= esc_html( $ai['val'] ) ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div>
                    <form class="tl-form" method="post" action="">
                        <?php wp_nonce_field( 'tf_tl_booking', 'tf_tl_nonce' ); ?>
                        <div class="tl-form__title">Request an Appointment</div>
                        <div class="tl-form__row">
                            <div class="tl-form__group">
                                <label class="tl-form__label" for="tl-name">Full Name *</label>
                                <input class="tl-form__input" type="text" id="tl-name" name="name" placeholder="The Hon. James Smith" required>
                            </div>
                            <div class="tl-form__group">
                                <label class="tl-form__label" for="tl-email">Email Address *</label>
                                <input class="tl-form__input" type="email" id="tl-email" name="email" placeholder="james@example.com" required>
                            </div>
                        </div>
                        <div class="tl-form__row">
                            <div class="tl-form__group">
                                <label class="tl-form__label" for="tl-phone">Telephone</label>
                                <input class="tl-form__input" type="tel" id="tl-phone" name="phone" placeholder="020 7946 0000">
                            </div>
                            <div class="tl-form__group">
                                <label class="tl-form__label" for="tl-garment">Commission *</label>
                                <select class="tl-form__select" id="tl-garment" name="garment">
                                    <option value="">Select garment…</option>
                                    <option>Bespoke Two-Piece Suit</option>
                                    <option>Bespoke Three-Piece Suit</option>
                                    <option>Morning Coat</option>
                                    <option>Black or White Tie</option>
                                    <option>Overcoat</option>
                                    <option>Wedding Commission</option>
                                    <option>Trousers / Waistcoat Only</option>
                                    <option>Dress Shirts</option>
                                    <option>Other / Unsure</option>
                                </select>
                            </div>
                        </div>
                        <div class="tl-form__group tl-form__group--full">
                            <label class="tl-form__label" for="tl-occasion">Occasion & Requirements</label>
                            <textarea class="tl-form__textarea" id="tl-occasion" name="occasion" placeholder="Please tell us about the occasion, any specific requirements, preferred timeline, and how you came to hear about us…"></textarea>
                        </div>
                        <button type="submit" class="tl-form__submit">Request Consultation →</button>
                        <p class="tl-form__note">All consultations are complimentary and without obligation</p>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ FOOTER CTA ═══════════════════════════ -->
    <section class="tl-footer-cta">
        <div class="tl-container">
            <h2 class="tl-footer-cta__title">Dressed for <em>Every Occasion</em></h2>
            <div class="tl-footer-cta__rule"></div>
            <p class="tl-footer-cta__sub">Pemberton & Sons · 4 Savile Row, Mayfair · Est. 1931</p>
            <div class="tl-footer-cta__actions">
                <a href="#booking" class="tl-btn tl-btn--primary">Request Consultation</a>
                <a href="#garments" class="tl-btn tl-btn--ghost">Our Garments</a>
            </div>
        </div>
    </section>

</div><!-- /.tl-wrap -->

<script>
/* ── IntersectionObserver animated counters ───────────────────────── */
(function () {
    'use strict';
    var easeOut = function (t) { return 1 - Math.pow(1 - t, 3); };
    var els = document.querySelectorAll('.tl-counter__value[data-target]');
    if (!els.length) return;
    var obs = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (!entry.isIntersecting) return;
            obs.unobserve(entry.target);
            var el      = entry.target;
            var target  = parseFloat(el.dataset.target);
            var isFloat = !!el.dataset.float;
            var span    = el.querySelector('span');
            if (!span || isNaN(target)) return;
            var dur = 1800, start = null;
            function tick(ts) {
                if (!start) start = ts;
                var p = Math.min((ts - start) / dur, 1);
                var v = easeOut(p) * target;
                span.textContent = isFloat ? v.toFixed(1) : Math.round(v).toLocaleString();
                if (p < 1) requestAnimationFrame(tick);
                else span.textContent = isFloat ? target.toFixed(1) : target.toLocaleString();
            }
            requestAnimationFrame(tick);
        });
    }, { threshold: 0.4 });
    els.forEach(function (el) { obs.observe(el); });
})();
</script>

<?php get_footer(); ?>
