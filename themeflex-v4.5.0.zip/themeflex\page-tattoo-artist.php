<?php
/**
 * Template Name: Tattoo Artist
 *
 * Premium landing page for tattoo artists and tattoo studios.
 * Palette: deep ink #0D0D12 / electric violet #7B2FBE / neon teal #00D4AA / silver #B8C0CC / warm white #F0EDE8
 * Fonts: Bebas Neue + DM Sans
 * Namespace: --ta-*
 *
 * @package ThemeFlex
 */

if ( ! defined( 'ABSPATH' ) ) exit;

srand( crc32( get_the_permalink() ) );

$ta_styles = [
    [ 'icon' => '🌸', 'name' => 'Fine Line',       'desc' => 'Delicate, precise linework creating elegant and intricate designs with incredible detail. Perfect for minimalist and botanical themes.' ],
    [ 'icon' => '🎨', 'name' => 'Neo Traditional', 'desc' => 'Bold, illustrative designs with rich colour palettes and stylised shading that reimagine classic American Traditional motifs.' ],
    [ 'icon' => '◼',  'name' => 'Blackwork',        'desc' => 'Striking geometric and organic designs using solid black ink — from bold tribal patterns to intricate mandalas.' ],
    [ 'icon' => '🌊', 'name' => 'Japanese',         'desc' => 'Timeless irezumi-inspired imagery including koi, dragons, peonies and waves rendered with traditional shading techniques.' ],
    [ 'icon' => '💧', 'name' => 'Watercolour',      'desc' => 'Painterly, fluid designs that mimic the spontaneous splashes and bleeds of watercolour painting on skin.' ],
    [ 'icon' => '🔮', 'name' => 'Geometric',        'desc' => 'Precise symmetrical and sacred geometry patterns, mandalas and dot-work that create mesmerising visual impact.' ],
];

$ta_process = [
    [ 'num' => '01', 'title' => 'Consultation',      'desc' => 'Book a free 30-minute consultation in the studio or via video call. We discuss your vision, placement, size and style — no commitment required.' ],
    [ 'num' => '02', 'title' => 'Custom Design',     'desc' => 'Your artist creates a bespoke design based on your brief. You\'ll see the artwork before your appointment and can request amendments.' ],
    [ 'num' => '03', 'title' => 'Your Session',      'desc' => 'Arrive rested and fed. Your artist talks you through the stencil placement before the needle touches skin — you\'re in control.' ],
    [ 'num' => '04', 'title' => 'Aftercare & Heal',  'desc' => 'Leave with full written aftercare instructions and a healing kit. We\'re available via WhatsApp for any questions during healing.' ],
    [ 'num' => '05', 'title' => 'Touch-Up Free',     'desc' => 'Once fully healed (6–8 weeks), we offer one complimentary touch-up session to ensure your tattoo looks flawless long-term.' ],
];

$ta_gallery = [
    [ 'label' => 'Fine Line Botanical', 'c1' => '#7B2FBE', 'c2' => '#4a1880' ],
    [ 'label' => 'Japanese Sleeve',     'c1' => '#0D0D12', 'c2' => '#1a1a2e' ],
    [ 'label' => 'Geometric Mandala',   'c1' => '#00D4AA', 'c2' => '#009980' ],
    [ 'label' => 'Neo-Traditional',     'c1' => '#E63946', 'c2' => '#a02030' ],
    [ 'label' => 'Blackwork',           'c1' => '#2d3748', 'c2' => '#1a2030' ],
    [ 'label' => 'Watercolour',         'c1' => '#F59E0B', 'c2' => '#d48709' ],
];

$ta_packages = [
    [
        'name'     => 'Small Piece',
        'price'    => 'From £80',
        'sub'      => 'Up to 3 hrs',
        'featured' => false,
        'items'    => [ 'Up to hand-size work', 'Custom design included', 'All ink colours', 'Aftercare kit', '1 free touch-up' ],
    ],
    [
        'name'     => 'Half Day',
        'price'    => 'From £250',
        'sub'      => '4–5 hrs · Most popular',
        'featured' => true,
        'items'    => [ 'Half-sleeve or back panel', 'Full custom design', 'Priority scheduling', 'Aftercare kit + guide', '1 free touch-up', 'Photo session included' ],
    ],
    [
        'name'     => 'Full Day',
        'price'    => 'From £450',
        'sub'      => '7–8 hrs · Large projects',
        'featured' => false,
        'items'    => [ 'Full sleeve or large back', 'Full custom design', 'Priority + extended slot', 'Aftercare premium kit', 'Unlimited touch-ups', 'Professional photography' ],
    ],
];

$ta_testimonials = [
    [ 'name' => 'Zara M.', 'loc' => 'Manchester', 'stars' => 5, 'text' => 'I came in with a vague idea and left with the most stunning fine line piece I\'ve ever seen. The attention to detail is mind-blowing. Already planning my next one.' ],
    [ 'name' => 'Tom C.',  'loc' => 'Liverpool',  'stars' => 5, 'text' => 'Covered up an old tattoo I\'d been embarrassed about for 10 years. The transformation is unreal — I honestly can\'t believe it\'s the same spot on my arm.' ],
    [ 'name' => 'Aisha R.','loc' => 'Manchester', 'stars' => 5, 'text' => 'My first ever tattoo and I couldn\'t have asked for a better experience. Nervous at first but the whole team made me feel completely at ease. Absolutely love it.' ],
];

// Floating ink particles
$ta_particles = [];
$ink_chars = ['✦','✧','⬡','◈','◇','◆','★','⟡','∗','⊹','✺','✹'];
for ($i = 0; $i < 16; $i++) {
    $ta_particles[] = [
        'char'  => $ink_chars[array_rand($ink_chars)],
        'x'     => rand(3,97),
        'y'     => rand(3,95),
        'size'  => rand(10,26),
        'op'    => rand(8,30)/100,
        'dur'   => rand(50,120)/10,
        'delay' => rand(0,80)/10,
        'depth' => rand(12,50)/10,
        'color' => (rand(0,1)) ? 'rgba(123,47,190,.8)' : 'rgba(0,212,170,.8)',
    ];
}
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,700;1,9..40,300;1,9..40,400&display=swap" rel="stylesheet">
<style>
/* =========================================================
   TATTOO ARTIST — CSS Custom Properties  (--ta-* namespace)
   ========================================================= */
:root {
    --ta-ink:     #0D0D12;
    --ta-violet:  #7B2FBE;
    --ta-violet-d:#5a1f90;
    --ta-teal:    #00D4AA;
    --ta-teal-d:  #009980;
    --ta-silver:  #B8C0CC;
    --ta-warm:    #F0EDE8;
    --ta-grey:    #2d3748;
    --ta-muted:   #6b7280;
    --ta-text:    #1a1a2a;
    --ta-ff-head: 'Bebas Neue', 'Impact', sans-serif;
    --ta-ff-body: 'DM Sans', system-ui, sans-serif;
    --ta-radius:  6px;
    --ta-shadow:  0 8px 32px rgba(13,13,18,.25);
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{font-family:var(--ta-ff-body);color:var(--ta-text);background:var(--ta-warm);-webkit-font-smoothing:antialiased}
img{max-width:100%;height:auto;display:block}
a{color:inherit;text-decoration:none}
ul{list-style:none}

/* ── Utility ── */
.ta-container{max-width:1160px;margin:0 auto;padding:0 24px}
.ta-section{padding:90px 0}
.ta-eyebrow{font-family:var(--ta-ff-body);font-size:.72rem;font-weight:700;letter-spacing:.18em;text-transform:uppercase;color:var(--ta-teal);margin-bottom:12px;display:block}
.ta-heading{font-family:var(--ta-ff-head);font-size:clamp(3rem,6vw,5rem);line-height:1;color:var(--ta-ink);margin-bottom:20px;letter-spacing:.04em}
.ta-heading--light{color:#fff}
.ta-heading span{color:var(--ta-violet)}
.ta-lead{font-size:1rem;line-height:1.75;color:var(--ta-muted);max-width:640px}
.ta-btn{display:inline-flex;align-items:center;gap:8px;padding:14px 32px;border-radius:3px;font-family:var(--ta-ff-body);font-size:.88rem;font-weight:700;letter-spacing:.08em;cursor:pointer;transition:all .25s;border:2px solid transparent;text-transform:uppercase}
.ta-btn--primary{background:var(--ta-violet);color:#fff;border-color:var(--ta-violet)}
.ta-btn--primary:hover{background:var(--ta-violet-d);transform:translateY(-2px)}
.ta-btn--teal{background:var(--ta-teal);color:var(--ta-ink);border-color:var(--ta-teal)}
.ta-btn--teal:hover{background:var(--ta-teal-d);transform:translateY(-2px)}
.ta-btn--outline{background:transparent;color:#fff;border-color:rgba(255,255,255,.5)}
.ta-btn--outline:hover{background:rgba(255,255,255,.08);border-color:#fff}
.ta-btn--dark{background:var(--ta-ink);color:#fff;border-color:var(--ta-ink)}
.ta-btn--dark:hover{background:#1a1a2e;transform:translateY(-2px)}
.ta-center{text-align:center}
.ta-center .ta-lead{margin-inline:auto}

/* =========================================================
   HERO — tattoo studio scene
   ========================================================= */
.ta-hero{position:relative;min-height:100vh;overflow:hidden;background:var(--ta-ink);display:flex;align-items:center}

/* Studio walls */
.ta-studio{position:absolute;inset:0}

/* Dark brick wall texture */
.ta-studio__wall{position:absolute;inset:0;background:#0D0D12}
.ta-studio__wall::before{content:'';position:absolute;inset:0;background-image:repeating-linear-gradient(0deg,rgba(255,255,255,.03) 0,rgba(255,255,255,.03) 1px,transparent 1px,transparent 40px),repeating-linear-gradient(90deg,rgba(255,255,255,.02) 0,rgba(255,255,255,.02) 1px,transparent 1px,transparent 80px);background-size:80px 40px}
.ta-studio__wall::after{content:'';position:absolute;inset:0;background:radial-gradient(ellipse at 70% 40%,rgba(123,47,190,.06) 0%,transparent 60%)}

/* Neon sign */
.ta-neon{position:absolute;top:10%;right:8%;font-family:var(--ta-ff-head);font-size:2.2rem;letter-spacing:.08em;color:rgba(0,212,170,.9);text-shadow:0 0 10px var(--ta-teal),0 0 30px rgba(0,212,170,.5),0 0 60px rgba(0,212,170,.2);animation:ta-neon-flicker 4s ease-in-out infinite;pointer-events:none}
@keyframes ta-neon-flicker{0%,90%,100%{opacity:1}93%{opacity:.7}95%{opacity:.9}97%{opacity:.6}}
.ta-neon::before{content:'';position:absolute;inset:-8px;border:1px solid rgba(0,212,170,.15);border-radius:4px}

/* Floor */
.ta-studio__floor{position:absolute;bottom:0;left:0;right:0;height:22%;background:linear-gradient(180deg,#1a1a24,#0d0d12)}
.ta-studio__floor::before{content:'';position:absolute;inset:0;background-image:repeating-linear-gradient(90deg,rgba(255,255,255,.04) 0,rgba(255,255,255,.04) 1px,transparent 1px,transparent 80px)}
.ta-studio__floor::after{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,transparent,rgba(123,47,190,.4),rgba(0,212,170,.3),transparent)}

/* Tattoo chair */
.ta-chair{position:absolute;bottom:22%;right:30%;pointer-events:none}
.ta-chair__base{width:80px;height:8px;background:linear-gradient(90deg,#555,#3a3a3a);border-radius:4px}
.ta-chair__stem{width:12px;height:40px;background:linear-gradient(90deg,#555,#3a3a3a);margin:0 auto}
.ta-chair__seat{width:90px;height:18px;background:linear-gradient(180deg,#8B1A1A,#6a1010);border-radius:4px;margin-top:0}
.ta-chair__back{width:70px;height:64px;background:linear-gradient(180deg,#8B1A1A,#6a1010);border-radius:6px 6px 0 0;margin:0 auto;position:relative}
.ta-chair__headrest{width:50px;height:16px;background:linear-gradient(180deg,#6a1010,#5a0808);border-radius:4px;margin:0 auto;position:absolute;top:-14px;left:10px}
.ta-chair__arm{position:absolute;width:50px;height:8px;background:linear-gradient(180deg,#8B1A1A,#6a1010);border-radius:3px;top:20px}
.ta-chair__arm--l{left:-48px;transform:rotate(-8deg)}
.ta-chair__arm--r{right:-48px;transform:rotate(8deg)}

/* Artist figure */
.ta-artist{position:absolute;bottom:22%;right:18%;display:flex;flex-direction:column;align-items:center;pointer-events:none}
.ta-artist__head{width:28px;height:30px;background:radial-gradient(circle at 40% 35%,#ffe0b2,#d4a060);border-radius:50%;position:relative}
.ta-artist__head::before{content:'';position:absolute;top:-10px;left:-2px;right:-2px;height:14px;background:#1a1a1a;border-radius:50% 50% 0 0}
.ta-artist__body{width:44px;height:60px;background:linear-gradient(180deg,#111,#1a1a1a);border-radius:4px 4px 0 0;position:relative}
.ta-artist__body::before{content:'';position:absolute;top:4px;left:8px;right:8px;height:52px;background:linear-gradient(180deg,#1a1a2e,#0d0d12);border-radius:2px}
.ta-artist__tool{position:absolute;bottom:10px;right:-30px;width:30px;height:6px;background:linear-gradient(90deg,#333,#555);border-radius:3px;transform:rotate(-20deg)}
.ta-artist__tool::after{content:'';position:absolute;right:-4px;top:50%;transform:translateY(-50%);width:6px;height:8px;background:#888;border-radius:1px}

/* Wall art frames */
.ta-frame{position:absolute;background:#1a1a24;border:3px solid #2a2a3a;box-shadow:inset 0 0 12px rgba(0,0,0,.5)}
.ta-frame__inner{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:1.4rem;opacity:.6}

/* Shelf with ink bottles */
.ta-ink-shelf{position:absolute;left:5%;top:30%;width:140px}
.ta-ink-shelf__board{height:8px;background:linear-gradient(180deg,#333,#222);border-radius:1px}
.ta-ink-shelf__bottles{display:flex;gap:6px;height:50px;align-items:flex-end;padding:0 4px}
.ta-ink-bottle{border-radius:3px 3px 6px 6px;position:relative;flex-shrink:0}
.ta-ink-bottle::before{content:'';position:absolute;top:-8px;left:50%;transform:translateX(-50%);width:6px;height:10px;background:#1a1a1a;border-radius:2px}

/* Particles */
.ta-particle{position:absolute;font-size:var(--sz);opacity:var(--op);color:var(--col);animation:ta-drift var(--dur)s ease-in-out var(--delay)s infinite alternate;pointer-events:none;will-change:transform}
@keyframes ta-drift{0%{transform:translateY(0) rotate(0deg) scale(1)}100%{transform:translateY(-16px) rotate(20deg) scale(1.1)}}

/* Dark gradient for text */
.ta-hero__overlay{position:absolute;inset:0;background:linear-gradient(90deg,rgba(13,13,18,.95) 0%,rgba(13,13,18,.8) 45%,rgba(13,13,18,.2) 72%,transparent 100%)}

/* Hero content */
.ta-hero__content{position:relative;z-index:10;padding:0 5%;max-width:580px}
.ta-hero__eyebrow{display:inline-block;background:rgba(123,47,190,.15);border:1px solid rgba(123,47,190,.4);color:var(--ta-violet);font-size:.68rem;font-weight:700;letter-spacing:.18em;text-transform:uppercase;padding:6px 16px;border-radius:2px;margin-bottom:24px;backdrop-filter:blur(4px)}
.ta-hero__title{font-family:var(--ta-ff-head);font-size:clamp(3.5rem,8vw,6.5rem);font-weight:400;line-height:.95;color:#fff;margin-bottom:12px;letter-spacing:.04em}
.ta-hero__title em{color:var(--ta-teal);font-style:normal}
.ta-hero__sub{font-family:var(--ta-ff-body);font-size:.85rem;font-weight:500;letter-spacing:.18em;text-transform:uppercase;color:var(--ta-silver);margin-bottom:24px}
.ta-hero__body{font-size:.95rem;line-height:1.75;color:rgba(255,255,255,.72);margin-bottom:36px;max-width:460px}
.ta-hero__ctas{display:flex;flex-wrap:wrap;gap:12px}
.ta-hero__badges{display:flex;flex-wrap:wrap;gap:10px;margin-top:28px}
.ta-hero__badge{font-size:.76rem;color:rgba(255,255,255,.65);background:rgba(255,255,255,.05);padding:7px 14px;border-radius:2px;border:1px solid rgba(255,255,255,.1);backdrop-filter:blur(4px)}

/* Trust bar */
.ta-trust{background:#111118;padding:18px 0;border-top:1px solid rgba(255,255,255,.05);border-bottom:1px solid rgba(255,255,255,.05)}
.ta-trust__inner{display:flex;flex-wrap:wrap;justify-content:center;gap:6px 30px}
.ta-trust__item{font-size:.8rem;color:rgba(255,255,255,.55);display:flex;align-items:center;gap:8px}
.ta-trust__item::before{content:'◈';color:var(--ta-teal);font-size:.7rem}

/* =========================================================
   STYLES / SPECIALISMS
   ========================================================= */
.ta-styles{background:#fff}
.ta-styles__grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:24px;margin-top:52px}
.ta-style-card{border-radius:var(--ta-radius);padding:30px 24px;border:1px solid rgba(13,13,18,.08);transition:all .3s;background:var(--ta-warm);position:relative;overflow:hidden}
.ta-style-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--ta-violet),var(--ta-teal));transform:scaleX(0);transition:transform .3s;transform-origin:left}
.ta-style-card:hover{box-shadow:var(--ta-shadow);transform:translateY(-4px)}
.ta-style-card:hover::before{transform:scaleX(1)}
.ta-style-card__icon{font-size:1.8rem;margin-bottom:14px;display:block}
.ta-style-card__name{font-family:var(--ta-ff-head);font-size:1.6rem;letter-spacing:.04em;color:var(--ta-ink);margin-bottom:8px}
.ta-style-card__desc{font-size:.87rem;line-height:1.7;color:var(--ta-muted)}

/* =========================================================
   PROCESS
   ========================================================= */
.ta-process{background:var(--ta-ink);padding:90px 0}
.ta-process .ta-eyebrow{color:var(--ta-violet)}
.ta-process__grid{display:grid;grid-template-columns:repeat(5,1fr);gap:16px;margin-top:52px;position:relative}
.ta-process__grid::before{content:'';position:absolute;top:30px;left:10%;right:10%;height:1px;background:linear-gradient(90deg,transparent,rgba(123,47,190,.4),rgba(0,212,170,.4),transparent)}
.ta-pstep{text-align:center;padding:28px 14px;position:relative}
.ta-pstep__num{font-family:var(--ta-ff-head);font-size:4rem;letter-spacing:.04em;color:rgba(123,47,190,.2);line-height:1;margin-bottom:-16px}
.ta-pstep__title{font-family:var(--ta-ff-head);font-size:1.2rem;letter-spacing:.04em;color:#fff;margin-bottom:10px;position:relative;z-index:1}
.ta-pstep__desc{font-size:.82rem;line-height:1.65;color:rgba(255,255,255,.55)}

/* =========================================================
   GALLERY
   ========================================================= */
.ta-gallery{background:var(--ta-grey)}
.ta-gallery .ta-eyebrow{color:var(--ta-teal)}
.ta-gallery__grid{display:grid;grid-template-columns:repeat(3,1fr);grid-template-rows:230px 230px;gap:8px;margin-top:52px}
.ta-gallery__item{border-radius:3px;overflow:hidden;position:relative;cursor:pointer}
.ta-gallery__item:first-child{grid-column:span 2}
.ta-gallery__item:nth-child(5){grid-column:span 2}
.ta-gallery__art{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-family:var(--ta-ff-head);font-size:.9rem;letter-spacing:.12em;color:rgba(255,255,255,.6);position:relative;overflow:hidden}
.ta-gallery__art::before{content:'';position:absolute;inset:0;background:inherit;filter:brightness(.65);transition:filter .4s}
.ta-gallery__item:hover .ta-gallery__art::before{filter:brightness(.45)}
.ta-gallery__label{position:relative;z-index:1;background:rgba(0,0,0,.5);padding:7px 16px;border-radius:2px;letter-spacing:.1em}

/* =========================================================
   COUNTERS
   ========================================================= */
.ta-counters{background:linear-gradient(135deg,var(--ta-violet),var(--ta-violet-d));padding:80px 0}
.ta-counters__grid{display:grid;grid-template-columns:repeat(4,1fr);gap:40px;text-align:center}
.ta-counter__val{font-family:var(--ta-ff-head);font-size:clamp(3rem,5vw,5rem);letter-spacing:.04em;color:#fff;line-height:1}
.ta-counter__label{font-size:.75rem;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.7);margin-top:8px}

/* =========================================================
   ABOUT
   ========================================================= */
.ta-about{background:#fff}
.ta-about__grid{display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:center}
.ta-about__visual{position:relative}
.ta-portfolio-preview{width:100%;max-width:380px;background:var(--ta-ink);border-radius:var(--ta-radius);overflow:hidden;box-shadow:var(--ta-shadow)}
.ta-portfolio-preview__header{background:#111118;padding:14px 18px;display:flex;align-items:center;gap:10px;border-bottom:1px solid rgba(255,255,255,.05)}
.ta-portfolio-preview__dot{width:10px;height:10px;border-radius:50%}
.ta-portfolio-preview__grid{display:grid;grid-template-columns:1fr 1fr;gap:4px;padding:4px}
.ta-portfolio-preview__cell{aspect-ratio:1;border-radius:3px;display:flex;align-items:center;justify-content:center;font-size:1.6rem}
.ta-artist-badge{position:absolute;bottom:-16px;right:-16px;background:var(--ta-ink);border-radius:var(--ta-radius);padding:16px 20px;box-shadow:var(--ta-shadow);border:2px solid rgba(123,47,190,.3);min-width:150px;text-align:center}
.ta-artist-badge__val{font-family:var(--ta-ff-head);font-size:2rem;letter-spacing:.04em;color:var(--ta-teal);line-height:1}
.ta-artist-badge__label{font-size:.7rem;letter-spacing:.08em;text-transform:uppercase;color:var(--ta-silver);margin-top:4px}
.ta-about__quote{font-family:var(--ta-ff-head);font-size:1.8rem;letter-spacing:.04em;color:var(--ta-ink);line-height:1.2;margin:20px 0;position:relative}
.ta-about__quote::before{content:'"';font-size:5rem;color:var(--ta-violet);opacity:.15;position:absolute;top:-20px;left:-16px;font-family:Georgia,serif;line-height:1}
.ta-about__bio{font-size:.93rem;line-height:1.8;color:var(--ta-muted);margin-bottom:20px}
.ta-about__tags{display:flex;flex-wrap:wrap;gap:8px;margin:20px 0}
.ta-about__tag{background:rgba(123,47,190,.1);border:1px solid rgba(123,47,190,.25);color:var(--ta-violet);font-size:.75rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;padding:5px 12px;border-radius:2px}

/* =========================================================
   PACKAGES
   ========================================================= */
.ta-packages{background:var(--ta-warm)}
.ta-packages__grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:52px}
.ta-pkg{background:#fff;border-radius:var(--ta-radius);padding:36px 28px;border:2px solid rgba(13,13,18,.08);transition:all .3s;position:relative}
.ta-pkg:hover{box-shadow:var(--ta-shadow)}
.ta-pkg--featured{border-color:var(--ta-violet);background:linear-gradient(180deg,rgba(123,47,190,.04),#fff)}
.ta-pkg--featured::before{content:'Most Popular';position:absolute;top:-14px;left:50%;transform:translateX(-50%);background:var(--ta-violet);color:#fff;font-size:.65rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;padding:4px 16px;border-radius:20px;white-space:nowrap}
.ta-pkg__name{font-family:var(--ta-ff-head);font-size:1.8rem;letter-spacing:.04em;color:var(--ta-ink);margin-bottom:4px}
.ta-pkg__sub{font-size:.8rem;color:var(--ta-muted);margin-bottom:20px}
.ta-pkg__price{font-family:var(--ta-ff-head);font-size:2rem;letter-spacing:.04em;color:var(--ta-violet);margin-bottom:24px;line-height:1}
.ta-pkg__list{display:flex;flex-direction:column;gap:10px;margin-bottom:28px}
.ta-pkg__list li{display:flex;align-items:flex-start;gap:8px;font-size:.87rem;color:var(--ta-text);line-height:1.5}
.ta-pkg__list li::before{content:'✦';color:var(--ta-teal);flex-shrink:0;font-size:.7rem;margin-top:3px}

/* =========================================================
   TESTIMONIALS
   ========================================================= */
.ta-testimonials{background:var(--ta-ink)}
.ta-testimonials .ta-eyebrow{color:var(--ta-violet)}
.ta-testi-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:52px}
.ta-testi{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:var(--ta-radius);padding:30px 26px;border-top:2px solid var(--ta-teal)}
.ta-testi__stars{color:var(--ta-teal);font-size:.9rem;letter-spacing:2px;margin-bottom:14px}
.ta-testi__text{font-size:.93rem;line-height:1.72;color:rgba(255,255,255,.7);font-style:italic;margin-bottom:18px}
.ta-testi__author{font-size:.8rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#fff}
.ta-testi__loc{font-size:.76rem;color:rgba(255,255,255,.4)}

/* =========================================================
   BOOKING
   ========================================================= */
.ta-booking{background:linear-gradient(135deg,#0d0d1a,#1a1a2e);padding:90px 0}
.ta-booking .ta-eyebrow{color:var(--ta-teal)}
.ta-booking__grid{display:grid;grid-template-columns:1fr 1.6fr;gap:60px;align-items:start;margin-top:52px}
.ta-booking__callout{background:rgba(123,47,190,.12);border:1px solid rgba(123,47,190,.3);border-radius:var(--ta-radius);padding:24px;margin-bottom:24px}
.ta-booking__callout-title{font-family:var(--ta-ff-head);font-size:1.3rem;letter-spacing:.04em;color:var(--ta-teal);margin-bottom:8px}
.ta-booking__callout-text{font-size:.85rem;line-height:1.65;color:rgba(255,255,255,.65)}
.ta-booking__info-item{display:flex;align-items:flex-start;gap:14px;margin-bottom:22px}
.ta-booking__info-icon{font-size:1.3rem;flex-shrink:0;margin-top:2px}
.ta-booking__info-title{font-size:.78rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#fff;margin-bottom:4px}
.ta-booking__info-text{font-size:.83rem;line-height:1.6;color:rgba(255,255,255,.55)}
.ta-form{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--ta-radius);padding:38px 34px;backdrop-filter:blur(8px)}
.ta-form__row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.ta-form__group{margin-bottom:16px;display:flex;flex-direction:column;gap:6px}
.ta-form__group label{font-size:.72rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.65)}
.ta-form__group input,
.ta-form__group select,
.ta-form__group textarea{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.14);border-radius:3px;padding:11px 14px;font-family:var(--ta-ff-body);font-size:.9rem;color:#fff;outline:none;transition:border-color .25s;width:100%}
.ta-form__group input::placeholder,
.ta-form__group textarea::placeholder{color:rgba(255,255,255,.3)}
.ta-form__group input:focus,
.ta-form__group select:focus,
.ta-form__group textarea:focus{border-color:var(--ta-teal);background:rgba(255,255,255,.1)}
.ta-form__group select option{background:#1a1a2e;color:#fff}
.ta-form__group textarea{resize:vertical;min-height:100px}
.ta-form__submit{width:100%;padding:15px;background:linear-gradient(90deg,var(--ta-violet),var(--ta-teal-d));border:none;border-radius:3px;font-family:var(--ta-ff-body);font-size:1rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#fff;cursor:pointer;transition:all .25s;margin-top:6px}
.ta-form__submit:hover{opacity:.9;transform:translateY(-2px)}
.ta-form__consent{font-size:.72rem;color:rgba(255,255,255,.4);margin-top:10px;line-height:1.6;text-align:center}

/* =========================================================
   FOOTER
   ========================================================= */
.ta-footer{background:#06060a;padding:26px 0}
.ta-footer__inner{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:16px}
.ta-footer__copy{font-size:.78rem;color:rgba(255,255,255,.35)}
.ta-footer__links{display:flex;gap:20px}
.ta-footer__links a{font-size:.78rem;color:rgba(255,255,255,.35);transition:color .2s}
.ta-footer__links a:hover{color:var(--ta-teal)}

/* =========================================================
   RESPONSIVE
   ========================================================= */
@media(max-width:960px){
    .ta-about__grid,.ta-booking__grid{grid-template-columns:1fr}
    .ta-packages__grid,.ta-testi-grid{grid-template-columns:1fr}
    .ta-counters__grid{grid-template-columns:repeat(2,1fr)}
    .ta-process__grid{grid-template-columns:repeat(3,1fr)}
    .ta-gallery__grid{grid-template-columns:1fr 1fr}
    .ta-gallery__item:first-child,.ta-gallery__item:nth-child(5){grid-column:span 1}
    .ta-process__grid::before{display:none}
}
@media(max-width:600px){
    .ta-section{padding:60px 0}
    .ta-form__row{grid-template-columns:1fr}
    .ta-counters__grid{grid-template-columns:repeat(2,1fr)}
    .ta-process__grid{grid-template-columns:repeat(2,1fr)}
}
</style>
<?php get_header(); ?>
<div class="ta-page">
>

<!-- ═══════════════════════════════════════════════
     HERO
═══════════════════════════════════════════════ -->
<section class="ta-hero" id="ta-hero">
    <div class="ta-studio" aria-hidden="true">
        <div class="ta-studio__wall"></div>

        <!-- Neon sign -->
        <div class="ta-neon">INK CULTURE</div>

        <!-- Wall art frames -->
        <?php
        $frames = [
            ['top'=>'8%', 'left'=>'30%', 'w'=>'80px','h'=>'100px','content'=>'🐉'],
            ['top'=>'8%', 'left'=>'42%', 'w'=>'70px','h'=>'90px', 'content'=>'🌸'],
            ['top'=>'8%', 'left'=>'52%', 'w'=>'80px','h'=>'80px', 'content'=>'⚓'],
        ];
        foreach ($frames as $fr): ?>
        <div class="ta-frame" style="top:<?php echo $fr['top']; ?>;left:<?php echo $fr['left']; ?>;width:<?php echo $fr['w']; ?>;height:<?php echo $fr['h']; ?>">
            <div class="ta-frame__inner"><?php echo $fr['content']; ?></div>
        </div>
        <?php endforeach; ?>

        <!-- Ink bottle shelf -->
        <div class="ta-ink-shelf">
            <div class="ta-ink-shelf__bottles">
                <?php
                $ink_colors = ['#7B2FBE','#00D4AA','#E63946','#F59E0B','#1a1a2e','#2E8B7A','#c85a40','#4a8fba'];
                $ink_widths = [14,12,14,12,16,12,14,12];
                $ink_heights = [42,36,44,38,40,36,42,34];
                for ($b=0; $b<8; $b++): ?>
                <div class="ta-ink-bottle" style="background:<?php echo $ink_colors[$b]; ?>;width:<?php echo $ink_widths[$b]; ?>px;height:<?php echo $ink_heights[$b]; ?>px"></div>
                <?php endfor; ?>
            </div>
            <div class="ta-ink-shelf__board"></div>
        </div>

        <!-- Artist chair -->
        <div class="ta-chair">
            <div class="ta-chair__back">
                <div class="ta-chair__headrest"></div>
                <div class="ta-chair__arm ta-chair__arm--l"></div>
                <div class="ta-chair__arm ta-chair__arm--r"></div>
            </div>
            <div class="ta-chair__seat"></div>
            <div class="ta-chair__stem"></div>
            <div class="ta-chair__base"></div>
        </div>

        <!-- Artist figure -->
        <div class="ta-artist">
            <div class="ta-artist__head"></div>
            <div class="ta-artist__body">
                <div class="ta-artist__tool"></div>
            </div>
        </div>

        <!-- Floor -->
        <div class="ta-studio__floor"></div>

        <!-- Floating particles -->
        <?php foreach ($ta_particles as $p): ?>
        <div class="ta-particle"
             style="left:<?php echo $p['x']; ?>%;top:<?php echo $p['y']; ?>%;--sz:<?php echo $p['size']; ?>px;--op:<?php echo $p['op']; ?>;--col:<?php echo $p['color']; ?>;--dur:<?php echo $p['dur']; ?>;--delay:<?php echo $p['delay']; ?>s"
             data-depth="<?php echo $p['depth']; ?>"><?php echo $p['char']; ?></div>
        <?php endforeach; ?>
    </div>

    <!-- Overlay -->
    <div class="ta-hero__overlay" aria-hidden="true"></div>

    <!-- Hero content -->
    <div class="ta-container">
        <div class="ta-hero__content">
            <span class="ta-hero__eyebrow">Custom Tattoo Studio · Manchester</span>
            <h1 class="ta-hero__title">Your Skin.<br><em>Our Canvas.</em></h1>
            <p class="ta-hero__sub">Fine Line · Neo-Traditional · Japanese · Geometric</p>
            <p class="ta-hero__body">
                Bespoke tattoo artistry crafted with precision and passion. Every piece is designed exclusively for you — your story, your style, your skin. Consultations always free. No walk-ins; quality takes time.
            </p>
            <div class="ta-hero__ctas">
                <a href="#ta-booking" class="ta-btn ta-btn--teal">Book a Consultation</a>
                <a href="#ta-gallery" class="ta-btn ta-btn--outline">View Portfolio</a>
            </div>
            <div class="ta-hero__badges">
                <span class="ta-hero__badge">✦ Custom Designs Only</span>
                <span class="ta-hero__badge">✦ Free Consultation</span>
                <span class="ta-hero__badge">✦ 10+ Years Experience</span>
                <span class="ta-hero__badge">✦ 1 Free Touch-Up</span>
            </div>
        </div>
    </div>
</section>

<!-- Trust bar -->
<div class="ta-trust">
    <div class="ta-container">
        <div class="ta-trust__inner">
            <?php
            $ta_trust = ['100% Custom Bespoke Designs','Vegan-Friendly Inks Available','Licensed & Insured Studio','Aftercare Kit Included','Sterile Single-Use Equipment','Free Touch-Up Guarantee'];
            foreach ($ta_trust as $ti): ?>
            <span class="ta-trust__item"><?php echo esc_html($ti); ?></span>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ═══════════════════════════════════════════════
     STYLES
═══════════════════════════════════════════════ -->
<section class="ta-section ta-styles" id="ta-styles">
    <div class="ta-container">
        <div class="ta-center">
            <span class="ta-eyebrow">Specialisms</span>
            <h2 class="ta-heading">Tattoo <span>Styles</span></h2>
            <p class="ta-lead">Six distinctive disciplines mastered over a decade of tattooing. Not sure which style suits you? That's what consultations are for.</p>
        </div>
        <div class="ta-styles__grid">
            <?php foreach ($ta_styles as $style): ?>
            <article class="ta-style-card">
                <span class="ta-style-card__icon"><?php echo esc_html($style['icon']); ?></span>
                <h3 class="ta-style-card__name"><?php echo esc_html($style['name']); ?></h3>
                <p class="ta-style-card__desc"><?php echo esc_html($style['desc']); ?></p>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     PROCESS
═══════════════════════════════════════════════ -->
<section class="ta-process" id="ta-process">
    <div class="ta-container">
        <div class="ta-center">
            <span class="ta-eyebrow">The Journey</span>
            <h2 class="ta-heading ta-heading--light">From Idea to <span style="color:var(--ta-teal)">Ink</span></h2>
            <p class="ta-lead" style="color:rgba(255,255,255,.6);margin-inline:auto">Every tattoo begins long before the needle. Here's our five-step process that ensures you leave with exactly what you envisioned.</p>
        </div>
        <div class="ta-process__grid">
            <?php foreach ($ta_process as $step): ?>
            <div class="ta-pstep">
                <div class="ta-pstep__num"><?php echo esc_html($step['num']); ?></div>
                <h3 class="ta-pstep__title"><?php echo esc_html($step['title']); ?></h3>
                <p class="ta-pstep__desc"><?php echo esc_html($step['desc']); ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     GALLERY
═══════════════════════════════════════════════ -->
<section class="ta-section ta-gallery" id="ta-gallery">
    <div class="ta-container">
        <div class="ta-center">
            <span class="ta-eyebrow">Portfolio</span>
            <h2 class="ta-heading ta-heading--light">Recent Work</h2>
        </div>
        <div class="ta-gallery__grid">
            <?php foreach ($ta_gallery as $gitem): ?>
            <div class="ta-gallery__item">
                <div class="ta-gallery__art" style="background:linear-gradient(135deg,<?php echo esc_attr($gitem['c1']); ?>,<?php echo esc_attr($gitem['c2']); ?>)">
                    <span class="ta-gallery__label"><?php echo esc_html($gitem['label']); ?></span>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     COUNTERS
═══════════════════════════════════════════════ -->
<section class="ta-counters" aria-label="Studio statistics">
    <div class="ta-container">
        <div class="ta-counters__grid">
            <div class="ta-counter">
                <div class="ta-counter__val" data-target="10" data-suffix="yrs">0</div>
                <div class="ta-counter__label">Years Tattooing</div>
            </div>
            <div class="ta-counter">
                <div class="ta-counter__val" data-target="2400" data-suffix="+">0</div>
                <div class="ta-counter__label">Pieces Created</div>
            </div>
            <div class="ta-counter">
                <div class="ta-counter__val" data-target="4.9" data-suffix="★" data-float="1">0</div>
                <div class="ta-counter__label">Google Rating</div>
            </div>
            <div class="ta-counter">
                <div class="ta-counter__val" data-target="100" data-suffix="%">0</div>
                <div class="ta-counter__label">Custom Designs</div>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     ABOUT
═══════════════════════════════════════════════ -->
<section class="ta-section ta-about" id="ta-about">
    <div class="ta-container">
        <div class="ta-about__grid">
            <div class="ta-about__visual">
                <div class="ta-portfolio-preview">
                    <div class="ta-portfolio-preview__header">
                        <div class="ta-portfolio-preview__dot" style="background:#E63946"></div>
                        <div class="ta-portfolio-preview__dot" style="background:#F59E0B"></div>
                        <div class="ta-portfolio-preview__dot" style="background:#22c55e"></div>
                        <span style="font-size:.72rem;color:rgba(255,255,255,.4);margin-left:8px;font-family:var(--ta-ff-body)">Portfolio Preview</span>
                    </div>
                    <div class="ta-portfolio-preview__grid">
                        <?php
                        $preview_cells = [
                            ['bg'=>'linear-gradient(135deg,#7B2FBE,#4a1880)','ico'=>'🌸'],
                            ['bg'=>'linear-gradient(135deg,#00D4AA,#009980)','ico'=>'⬡'],
                            ['bg'=>'linear-gradient(135deg,#1a1a2e,#2d3748)','ico'=>'🐉'],
                            ['bg'=>'linear-gradient(135deg,#E63946,#a02030)','ico'=>'✺'],
                        ];
                        foreach ($preview_cells as $cell): ?>
                        <div class="ta-portfolio-preview__cell" style="background:<?php echo esc_attr($cell['bg']); ?>"><?php echo $cell['ico']; ?></div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="ta-artist-badge">
                    <div class="ta-artist-badge__val">2,400+</div>
                    <div class="ta-artist-badge__label">Pieces Created</div>
                </div>
            </div>
            <div class="ta-about__content">
                <span class="ta-eyebrow">The Artist</span>
                <h2 class="ta-heading" style="font-size:clamp(2.5rem,4vw,3.5rem)">Alex Chen</h2>
                <div class="ta-about__quote">Art that lives<br>on your skin forever.</div>
                <p class="ta-about__bio">
                    With over a decade dedicated to the craft of tattooing, Alex has built a reputation for exceptional precision, innovative design and a genuine connection with every client. Trained in Tokyo and London, Alex's work bridges Eastern and Western tattoo traditions with a distinctly contemporary vision.
                </p>
                <p class="ta-about__bio">
                    Every piece begins with a conversation. Alex listens carefully to your ideas, references and the meaning behind your tattoo before putting a single mark on paper — let alone skin.
                </p>
                <div class="ta-about__tags">
                    <span class="ta-about__tag">Tokyo Trained</span>
                    <span class="ta-about__tag">10+ Years</span>
                    <span class="ta-about__tag">Guest Artist · London, Berlin</span>
                    <span class="ta-about__tag">Vegan Inks</span>
                </div>
                <a href="#ta-booking" class="ta-btn ta-btn--primary">Book with Alex →</a>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     PACKAGES
═══════════════════════════════════════════════ -->
<section class="ta-section ta-packages" id="ta-packages">
    <div class="ta-container">
        <div class="ta-center">
            <span class="ta-eyebrow">Session Pricing</span>
            <h2 class="ta-heading">Choose Your Session</h2>
            <p class="ta-lead">All sessions include custom design, stencil application, all inks and a healing kit. Deposits required to secure your appointment.</p>
        </div>
        <div class="ta-packages__grid">
            <?php foreach ($ta_packages as $pkg): ?>
            <div class="ta-pkg<?php echo $pkg['featured'] ? ' ta-pkg--featured' : ''; ?>">
                <div class="ta-pkg__name"><?php echo esc_html($pkg['name']); ?></div>
                <div class="ta-pkg__sub"><?php echo esc_html($pkg['sub']); ?></div>
                <div class="ta-pkg__price"><?php echo esc_html($pkg['price']); ?></div>
                <ul class="ta-pkg__list">
                    <?php foreach ($pkg['items'] as $item): ?>
                    <li><?php echo esc_html($item); ?></li>
                    <?php endforeach; ?>
                </ul>
                <a href="#ta-booking" class="ta-btn ta-btn--<?php echo $pkg['featured'] ? 'primary' : 'dark'; ?>" style="width:100%;justify-content:center">Book This Session</a>
            </div>
            <?php endforeach; ?>
        </div>
        <p style="text-align:center;color:var(--ta-muted);font-size:.82rem;margin-top:24px">All prices are indicative. Final quotes given after consultation based on complexity, size and placement. 30% deposit required.</p>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     TESTIMONIALS
═══════════════════════════════════════════════ -->
<section class="ta-section ta-testimonials" id="ta-testimonials">
    <div class="ta-container">
        <div class="ta-center">
            <span class="ta-eyebrow">Client Stories</span>
            <h2 class="ta-heading ta-heading--light">Worn with <span style="color:var(--ta-teal)">Pride</span></h2>
        </div>
        <div class="ta-testi-grid">
            <?php foreach ($ta_testimonials as $testi): ?>
            <div class="ta-testi">
                <div class="ta-testi__stars"><?php echo str_repeat('★',$testi['stars']); ?></div>
                <p class="ta-testi__text">"<?php echo esc_html($testi['text']); ?>"</p>
                <div class="ta-testi__author"><?php echo esc_html($testi['name']); ?></div>
                <div class="ta-testi__loc"><?php echo esc_html($testi['loc']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     BOOKING
═══════════════════════════════════════════════ -->
<section class="ta-booking" id="ta-booking">
    <div class="ta-container">
        <div class="ta-center">
            <span class="ta-eyebrow">Get Booked In</span>
            <h2 class="ta-heading ta-heading--light">Start Your <span style="color:var(--ta-teal)">Journey</span></h2>
            <p class="ta-lead" style="color:rgba(255,255,255,.6);margin-inline:auto">Fill in the form below and we'll be in touch within 24 hours to arrange your free consultation — no commitment, no pressure.</p>
        </div>
        <div class="ta-booking__grid">
            <div>
                <div class="ta-booking__callout">
                    <div class="ta-booking__callout-title">✦ Free Consultation</div>
                    <div class="ta-booking__callout-text">Every booking starts with a free 30-minute consultation — in studio or via video. We discuss your design, size, placement and any questions before you commit to anything.</div>
                </div>
                <div class="ta-booking__info-item">
                    <span class="ta-booking__info-icon">📍</span>
                    <div>
                        <div class="ta-booking__info-title">Studio Location</div>
                        <div class="ta-booking__info-text">12 Northern Quarter,<br>Manchester M4 1AJ</div>
                    </div>
                </div>
                <div class="ta-booking__info-item">
                    <span class="ta-booking__info-icon">🕐</span>
                    <div>
                        <div class="ta-booking__info-title">Studio Hours</div>
                        <div class="ta-booking__info-text">Tue–Sat: 10am – 7pm<br>Appointments only — no walk-ins</div>
                    </div>
                </div>
                <div class="ta-booking__info-item">
                    <span class="ta-booking__info-icon">📱</span>
                    <div>
                        <div class="ta-booking__info-title">Instagram / DM</div>
                        <div class="ta-booking__info-text">@alexchen.ink<br>DMs open for quick questions</div>
                    </div>
                </div>
            </div>
            <div>
                <form class="ta-form" method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
                    <?php wp_nonce_field('tf_ta_booking','tf_ta_nonce'); ?>
                    <input type="hidden" name="action" value="tf_ta_booking">
                    <div class="ta-form__row">
                        <div class="ta-form__group">
                            <label for="ta-name">Full Name *</label>
                            <input type="text" id="ta-name" name="ta_name" required placeholder="Your full name">
                        </div>
                        <div class="ta-form__group">
                            <label for="ta-email">Email *</label>
                            <input type="email" id="ta-email" name="ta_email" required placeholder="your@email.com">
                        </div>
                    </div>
                    <div class="ta-form__row">
                        <div class="ta-form__group">
                            <label for="ta-phone">Phone / Instagram</label>
                            <input type="text" id="ta-phone" name="ta_phone" placeholder="Phone or @handle">
                        </div>
                        <div class="ta-form__group">
                            <label for="ta-style">Preferred Style *</label>
                            <select id="ta-style" name="ta_style" required>
                                <option value="">Select style…</option>
                                <option>Fine Line</option>
                                <option>Neo Traditional</option>
                                <option>Blackwork</option>
                                <option>Japanese</option>
                                <option>Watercolour</option>
                                <option>Geometric</option>
                                <option>Not Sure — Need Advice</option>
                            </select>
                        </div>
                    </div>
                    <div class="ta-form__row">
                        <div class="ta-form__group">
                            <label for="ta-placement">Body Placement *</label>
                            <input type="text" id="ta-placement" name="ta_placement" required placeholder="e.g. forearm, ribcage…">
                        </div>
                        <div class="ta-form__group">
                            <label for="ta-size">Approximate Size</label>
                            <select id="ta-size" name="ta_size">
                                <option value="">Select size…</option>
                                <option>Small (credit-card size)</option>
                                <option>Medium (hand-size)</option>
                                <option>Large (A5 and above)</option>
                                <option>Full/Half Sleeve</option>
                                <option>Back Piece</option>
                                <option>Not Sure</option>
                            </select>
                        </div>
                    </div>
                    <div class="ta-form__group">
                        <label for="ta-existing">Cover-Up / Existing Tattoo?</label>
                        <select id="ta-existing" name="ta_existing">
                            <option value="">Select…</option>
                            <option>No — fresh skin</option>
                            <option>Yes — covering existing tattoo</option>
                            <option>Yes — adding to existing piece</option>
                        </select>
                    </div>
                    <div class="ta-form__group">
                        <label for="ta-desc">Describe Your Idea *</label>
                        <textarea id="ta-desc" name="ta_desc" required placeholder="Tell us about your design idea — themes, references, specific elements, the meaning behind it. The more detail the better!"></textarea>
                    </div>
                    <button type="submit" class="ta-form__submit">Request Free Consultation →</button>
                    <p class="ta-form__consent">You must be 18+ to book. A deposit will be required to confirm your appointment. We do not share your details with third parties.</p>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════
     FOOTER
═══════════════════════════════════════════════ -->
<footer class="ta-footer">
    <div class="ta-container">
        <div class="ta-footer__inner">
            <p class="ta-footer__copy">&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All rights reserved. Licensed Tattoo Studio.</p>
            <nav class="ta-footer__links" aria-label="Footer navigation">
                <a href="<?php echo esc_url(home_url('/privacy-policy')); ?>">Privacy Policy</a>
                <a href="<?php echo esc_url(home_url('/terms')); ?>">Terms</a>
                <a href="<?php echo esc_url(home_url('/aftercare')); ?>">Aftercare</a>
            </nav>
        </div>
    </div>
</footer>


<script>
(function(){
    /* ── Animated Counters ── */
    const counters = document.querySelectorAll('.ta-counter__val[data-target]');
    const easeOut = t => 1 - Math.pow(1 - t, 3);
    const io = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (!entry.isIntersecting) return;
            const el = entry.target;
            const target = parseFloat(el.dataset.target);
            const suffix = el.dataset.suffix || '';
            const isFloat = el.dataset.float === '1';
            if (isNaN(target)) return;
            const dur = 1800;
            let start = null;
            function tick(ts) {
                if (!start) start = ts;
                const prog = Math.min((ts - start) / dur, 1);
                const val = target * easeOut(prog);
                el.textContent = (isFloat ? val.toFixed(1) : Math.round(val)) + suffix;
                if (prog < 1) requestAnimationFrame(tick);
            }
            requestAnimationFrame(tick);
            io.unobserve(el);
        });
    }, { threshold: 0.4 });
    counters.forEach(c => io.observe(c));

    /* ── Mouse parallax on particles ── */
    const particles = document.querySelectorAll('.ta-particle');
    document.getElementById('ta-hero')?.addEventListener('mousemove', e => {
        const rect = e.currentTarget.getBoundingClientRect();
        const dx = (e.clientX - rect.width / 2) / rect.width;
        const dy = (e.clientY - rect.height / 2) / rect.height;
        particles.forEach(p => {
            const d = parseFloat(p.dataset.depth) || 20;
            p.style.transform = `translate(${dx * d}px, ${dy * d}px)`;
        });
    });
})();
</script>
</body>
</html>
</div><!-- .ta-page -->
<?php get_footer(); ?>
