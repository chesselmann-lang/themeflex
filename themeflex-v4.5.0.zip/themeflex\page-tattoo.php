<?php
/**
 * Template Name: Tattoo – Tattoo & Body Art Studio
 *
 * Premium tattoo studio homepage template.
 * Bebas Neue + Inter · --tt-* namespace · near-black/crimson/gold palette
 * CSS art-directed dark studio hero · WCAG 2.1 AA · vanilla JS
 *
 * @package ThemeFlex
 */

defined( 'ABSPATH' ) || exit;

srand( crc32( get_the_permalink() ) );

/* ── palette ────────────────────────────────────────────────────────── */
$tt_black  = '#0A0A0A';
$tt_dark   = '#141414';
$tt_grey   = '#1E1E1E';
$tt_mid    = '#2A2A2A';
$tt_red    = '#C03020';
$tt_gold   = '#C8A040';
$tt_cream  = '#F0EAE0';
$tt_text   = '#D0C8BC';

/* ── flash art designs on wall (CSS shapes) ──────────────────────────*/
$flash_pieces = [
    [ 'x' => 5,  'y' => 12, 'type' => 'skull',   'color' => '#D0C8BC', 'border' => '#9A9288' ],
    [ 'x' => 12, 'y' => 10, 'type' => 'rose',    'color' => '#C03020', 'border' => '#8A1810' ],
    [ 'x' => 20, 'y' => 12, 'type' => 'anchor',  'color' => '#4A8AB0', 'border' => '#2A6890' ],
    [ 'x' => 28, 'y' => 10, 'type' => 'eagle',   'color' => '#C8A040', 'border' => '#A07820' ],
    [ 'x' => 36, 'y' => 12, 'type' => 'snake',   'color' => '#3A7040', 'border' => '#1A5020' ],
    [ 'x' => 44, 'y' => 10, 'type' => 'dagger',  'color' => '#A0A0B0', 'border' => '#6A6A7A' ],
    [ 'x' => 52, 'y' => 12, 'type' => 'rose',    'color' => '#D04060', 'border' => '#A02040' ],
    [ 'x' => 60, 'y' => 10, 'type' => 'skull',   'color' => '#E0D8CC', 'border' => '#A09888' ],
    [ 'x' => 68, 'y' => 12, 'type' => 'anchor',  'color' => '#5090C0', 'border' => '#3070A0' ],
    [ 'x' => 76, 'y' => 10, 'type' => 'eagle',   'color' => '#D0A040', 'border' => '#A07828' ],
    [ 'x' => 84, 'y' => 12, 'type' => 'snake',   'color' => '#4A8040', 'border' => '#2A5828' ],
    [ 'x' => 92, 'y' => 10, 'type' => 'dagger',  'color' => '#B0B0C0', 'border' => '#707080' ],
];

/* ── tattoo machine parts count ─────────────────────────────────────*/
// machines displayed on workstation
$machines = [
    [ 'body_color' => '#3A3A3A', 'coil_color' => '#505060', 'x' => 62, 'label' => 'Liner'  ],
    [ 'body_color' => '#2A2A3A', 'coil_color' => '#484858', 'x' => 72, 'label' => 'Shader' ],
];

/* ── ink bottles ─────────────────────────────────────────────────────*/
$inks = [
    [ 'color' => '#0A0A0A', 'x' => 56 ],
    [ 'color' => '#C03020', 'x' => 59 ],
    [ 'color' => '#C8A040', 'x' => 62 ],
    [ 'color' => '#3A6890', 'x' => 65 ],
    [ 'color' => '#3A7040', 'x' => 68 ],
    [ 'color' => '#8A3A80', 'x' => 71 ],
    [ 'color' => '#C8A050', 'x' => 74 ],
    [ 'color' => '#1A1A6A', 'x' => 77 ],
];

/* ── floating ink splatters ─────────────────────────────────────────*/
$splatters = [];
for ( $i = 0; $i < 14; $i++ ) {
    $splatters[] = [
        'x'  => rand( 2, 97 ),
        'y'  => rand( 5, 88 ),
        'sz' => rand( 6, 18 ),
        'op' => rand( 3, 12 ),
        'delay' => rand( 0, 80 ) / 10,
    ];
}

/* ── artists ──────────────────────────────────────────────────────── */
$artists = [
    [ 'name' => 'Marcus Vane',   'specialty' => 'Japanese Traditional',    'style' => 'Irezumi, Koi, Hannya, Chrysanthemum',        'yrs' => 18, 'color' => '#C03020' ],
    [ 'name' => 'Elara Solis',   'specialty' => 'Blackwork & Geometric',   'style' => 'Dotwork, Sacred geometry, Mandala',           'yrs' => 11, 'color' => '#C8A040' ],
    [ 'name' => 'Dmitri Cross',  'specialty' => 'Neo-Traditional',         'style' => 'Bold lines, Rich colour, Illustrative',       'yrs' =>  9, 'color' => '#3A6890' ],
    [ 'name' => 'Yuki Tanaka',   'specialty' => 'Fine Line & Realism',     'style' => 'Portrait, Botanical, Micro-realism',          'yrs' =>  7, 'color' => '#3A7040' ],
];

/* ── styles grid ──────────────────────────────────────────────────── */
$styles = [
    [ 'icon' => '⛩️', 'name' => 'Japanese',      'desc' => 'Irezumi, koi, dragons, peonies, Hannya masks — bold lines and rich colour harmony.' ],
    [ 'icon' => '⬛', 'name' => 'Blackwork',      'desc' => 'Geometric precision, dotwork textures, and solid black fill with architectural impact.' ],
    [ 'icon' => '🌹', 'name' => 'Neo-Traditional', 'desc' => 'Classic motifs reinterpreted with modern illustration techniques and vivid palettes.' ],
    [ 'icon' => '📸', 'name' => 'Realism',        'desc' => 'Photo-realistic portraiture, wildlife, and botanical subjects rendered with incredible detail.' ],
    [ 'icon' => '✍️', 'name' => 'Fine Line',       'desc' => 'Delicate single-needle work — script, minimal florals, and intricate micro-detailing.' ],
    [ 'icon' => '🔱', 'name' => 'Old School',      'desc' => 'American traditional — bold black outlines, limited palette, and timeless iconography.' ],
];

/* ── process ──────────────────────────────────────────────────────── */
$process = [
    [ 'num' => '01', 'title' => 'Consultation',    'desc' => 'Book a free 30-minute consultation to discuss your concept, placement, size, and style.' ],
    [ 'num' => '02', 'title' => 'Custom Design',   'desc' => 'Your artist creates a bespoke design for approval before any needles touch skin.' ],
    [ 'num' => '03', 'title' => 'The Session',     'desc' => 'Work in our private, sterile booths with premium inks and single-use equipment.' ],
    [ 'num' => '04', 'title' => 'Aftercare',       'desc' => 'Full aftercare kit and follow-up instructions to protect your investment for life.' ],
];

/* ── pricing tiers ────────────────────────────────────────────────── */
$packages = [
    [
        'name'     => 'Small Piece',
        'price'    => 'From £150',
        'period'   => '/ sitting',
        'featured' => false,
        'items'    => [ 'Up to 2 hours', 'Line work or simple shading', 'Single placement', 'Aftercare kit included', 'Touch-up within 3 months', 'Digital design proof' ],
    ],
    [
        'name'     => 'Medium Piece',
        'price'    => 'From £400',
        'period'   => '/ sitting',
        'featured' => true,
        'items'    => [ '3–6 hours', 'Full colour or complex blackwork', 'Multiple elements', 'Priority booking', 'Aftercare kit + consultation', 'Pre-session drawing review', 'Touch-up guarantee' ],
    ],
    [
        'name'     => 'Large / Sleeve',
        'price'    => 'POA',
        'period'   => '/ project',
        'featured' => false,
        'items'    => [ 'Multi-session planning', 'Full sleeve, back or chest piece', 'Cover-up assessment', 'Dedicated artist assignment', 'Progress photography', 'VIP booking access', 'Lifetime touch-up policy' ],
    ],
];

/* ── counters ─────────────────────────────────────────────────────── */
$counters = [
    [ 'value' => 22,    'suffix' => 'yrs',  'label' => 'Est. in London',    'float' => false ],
    [ 'value' => 28000, 'suffix' => '+',    'label' => 'Tattoos Completed', 'float' => false ],
    [ 'value' => 4.9,   'suffix' => '★',   'label' => 'Google Rating',     'float' => true  ],
    [ 'value' => 100,   'suffix' => '%',    'label' => 'Custom Designs',    'float' => false ],
];

/* ── testimonials ─────────────────────────────────────────────────── */
$testimonials = [
    [ 'text' => 'Marcus is an absolute master. My Japanese sleeve took four sessions and every one was a revelation. The detail in the koi and the way he balanced the composition across my arm is extraordinary.', 'name' => 'Daniel F.', 'piece' => 'Full Japanese Sleeve' ],
    [ 'text' => "Elara's geometric blackwork is unlike anything I've seen. She understood exactly what I wanted from a rough sketch and elevated it into something genuinely breathtaking. The precision is insane.", 'name' => 'Priya N.', 'piece' => 'Geometric Backpiece' ],
    [ 'text' => 'First tattoo experience and Yuki made it completely comfortable. The fine line botanical on my forearm is perfect — delicate, precise, and healed flawlessly. I was back within the month for another.', 'name' => 'Sophie M.', 'piece' => 'Fine Line Botanical' ],
];

get_header();
?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
/* ═══════════════════════════════════════════════════════════════════════
   TATTOO STUDIO — CSS CUSTOM PROPERTIES
═══════════════════════════════════════════════════════════════════════ */
:root {
    --tt-black:  <?= $tt_black ?>;
    --tt-dark:   <?= $tt_dark ?>;
    --tt-grey:   <?= $tt_grey ?>;
    --tt-mid:    <?= $tt_mid ?>;
    --tt-red:    <?= $tt_red ?>;
    --tt-gold:   <?= $tt_gold ?>;
    --tt-cream:  <?= $tt_cream ?>;
    --tt-text:   <?= $tt_text ?>;

    --tt-ff-head: 'Bebas Neue', sans-serif;
    --tt-ff-body: 'Inter', sans-serif;

    --tt-radius: 4px;
    --tt-shadow: 0 4px 32px rgba(0,0,0,.5);
    --tt-trans:  .3s cubic-bezier(.4,0,.2,1);
}

/* ── reset ──────────────────────────────────────────────────────────── */
.tt-wrap *, .tt-wrap *::before, .tt-wrap *::after { box-sizing: border-box; margin: 0; padding: 0; }
.tt-wrap { font-family: var(--tt-ff-body); color: var(--tt-text); background: var(--tt-black); overflow-x: hidden; }
.tt-container { max-width: 1160px; margin: 0 auto; padding: 0 24px; }

/* ── typography ─────────────────────────────────────────────────────── */
.tt-section-label { font-family: var(--tt-ff-body); font-size: .72rem; font-weight: 600; letter-spacing: .2em; text-transform: uppercase; color: var(--tt-gold); display: block; margin-bottom: 12px; }
.tt-section-title { font-family: var(--tt-ff-head); font-size: clamp(2.4rem, 4.5vw, 4.2rem); line-height: 1; color: var(--tt-cream); letter-spacing: .03em; }
.tt-section-title em { font-style: normal; color: var(--tt-red); }
.tt-section-body  { font-size: .92rem; line-height: 1.8; color: #9A9288; margin-top: 16px; font-weight: 300; }

/* ── buttons ────────────────────────────────────────────────────────── */
.tt-btn { display: inline-flex; align-items: center; gap: 8px; font-family: var(--tt-ff-body); font-size: .82rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; padding: 13px 28px; border-radius: 2px; cursor: pointer; border: 1px solid transparent; text-decoration: none; transition: var(--tt-trans); }
.tt-btn--primary { background: var(--tt-red); color: #fff; border-color: var(--tt-red); }
.tt-btn--primary:hover { background: #A02018; transform: translateY(-2px); box-shadow: 0 8px 24px rgba(192,48,32,.4); }
.tt-btn--gold { background: transparent; color: var(--tt-gold); border-color: var(--tt-gold); }
.tt-btn--gold:hover { background: var(--tt-gold); color: var(--tt-black); }
.tt-btn--outline { background: transparent; color: var(--tt-cream); border-color: rgba(240,234,224,.3); }
.tt-btn--outline:hover { border-color: var(--tt-cream); }

/* ════════════════════════════════════════════════════════════════════
   HERO
════════════════════════════════════════════════════════════════════ */
.tt-hero { position: relative; min-height: 95vh; display: flex; align-items: center; overflow: hidden; background: var(--tt-black); }

/* ── studio scene ─────────────────────────────────────────────────── */
.tt-scene { position: absolute; inset: 0; overflow: hidden; }

/* ceiling */
.tt-scene__ceiling { position: absolute; top: 0; left: 0; right: 0; height: 10%; background: linear-gradient(180deg, #0E0E0E 0%, #161616 100%); }
/* industrial ceiling pipes */
.tt-scene__pipe { position: absolute; top: 6%; left: 0; right: 0; height: 8px; background: linear-gradient(180deg, #3A3A3A 0%, #282828 100%); }
.tt-scene__pipe::before { content: ''; position: absolute; left: 20%; top: 100%; width: 4px; height: 28px; background: #303030; }
.tt-scene__pipe::after  { content: ''; position: absolute; right: 25%; top: 100%; width: 4px; height: 20px; background: #303030; }
/* warm spotlights */
.tt-scene__spot { position: absolute; top: 10%; border-radius: 0; }
.tt-scene__spot-cone { clip-path: polygon(20% 0%, 80% 0%, 100% 100%, 0% 100%); }

/* walls */
.tt-scene__wall { position: absolute; top: 10%; left: 0; right: 0; bottom: 24%; background: linear-gradient(180deg, #161616 0%, #121212 100%); }
/* dark wood panelling */
.tt-scene__wall::after { content: ''; position: absolute; inset: 0; background: repeating-linear-gradient(90deg, rgba(255,255,255,.02) 0px, rgba(255,255,255,.02) 1px, transparent 1px, transparent 120px); }

/* brick accent wall section */
.tt-scene__brick { position: absolute; top: 10%; right: 0; width: 38%; bottom: 24%; background: #1A1010; }
.tt-scene__brick::after { content: ''; position: absolute; inset: 0; background: repeating-linear-gradient(0deg, rgba(80,40,30,.15) 0px, rgba(80,40,30,.15) 1px, transparent 1px, transparent 24px), repeating-linear-gradient(180deg, transparent 0px, transparent 12px, rgba(60,30,20,.1) 12px, rgba(60,30,20,.1) 13px); }

/* floor */
.tt-scene__floor { position: absolute; bottom: 0; left: 0; right: 0; height: 24%; background: linear-gradient(180deg, #181818 0%, #141414 100%); }
.tt-scene__floor-line { position: absolute; top: 0; left: 0; right: 0; height: 2px; background: #282828; }
/* concrete floor texture */
.tt-scene__floor::before { content: ''; position: absolute; inset: 0; background: repeating-linear-gradient(90deg, rgba(255,255,255,.02) 0px, rgba(255,255,255,.02) 1px, transparent 1px, transparent 80px), repeating-linear-gradient(0deg, rgba(255,255,255,.02) 0px, rgba(255,255,255,.02) 1px, transparent 1px, transparent 80px); }

/* flash wall (left section) */
.tt-scene__flash-wall { position: absolute; top: 10%; left: 0; width: 50%; bottom: 24%; }

/* flash art frames */
.tt-flash-frame { position: absolute; border: 1px solid #2A2A2A; background: #181818; display: flex; align-items: center; justify-content: center; }

/* workstation / tattoo chair area */
.tt-scene__workstation { position: absolute; right: 4%; bottom: 24%; width: 28%; }
/* client chair */
.tt-scene__chair { position: absolute; bottom: 0; left: 0; }
.tt-scene__chair-back { width: 36px; height: 52px; background: linear-gradient(180deg, #303030 0%, #222222 100%); border-radius: 2px 2px 0 0; position: relative; }
.tt-scene__chair-back::before { content: ''; position: absolute; top: 8px; left: 50%; transform: translateX(-50%); width: 20px; height: 1px; background: rgba(255,255,255,.08); box-shadow: 0 8px 0 rgba(255,255,255,.08), 0 16px 0 rgba(255,255,255,.08), 0 24px 0 rgba(255,255,255,.08); }
.tt-scene__chair-seat { width: 44px; height: 14px; background: linear-gradient(180deg, #282828 0%, #1E1E1E 100%); margin-top: 4px; border-radius: 1px; }
.tt-scene__chair-leg { position: absolute; bottom: -20px; width: 4px; height: 20px; background: #383838; }
.tt-scene__chair-base { position: absolute; bottom: -24px; left: 50%; transform: translateX(-50%); width: 36px; height: 4px; background: #404040; border-radius: 50%; }

/* artist figure at work */
.tt-scene__artist { position: absolute; right: 38%; bottom: 0; }
.tt-artist-fig__head { width: 24px; height: 28px; background: #C89070; border-radius: 50% 50% 40% 40%; margin: 0 auto; position: relative; }
.tt-artist-fig__hair { position: absolute; top: 0; left: -2px; right: -2px; height: 14px; background: #0A0A0A; clip-path: ellipse(52% 58% at 50% 0%); }
/* beanie hat */
.tt-artist-fig__hat { position: absolute; top: -4px; left: -3px; right: -3px; height: 12px; background: #303030; border-radius: 2px 2px 0 0; }
.tt-artist-fig__neck { width: 10px; height: 6px; background: #C89070; margin: 0 auto; }
.tt-artist-fig__body { width: 30px; height: 44px; background: linear-gradient(180deg, #1E1E1E 0%, #161616 100%); border-radius: 2px 2px 0 0; margin: 0 auto; position: relative; }
/* black t-shirt sleeve with tattoo sleeve visible */
.tt-artist-fig__body::before { content: ''; position: absolute; top: 4px; left: 2px; width: 6px; height: 24px; background: #2A1A1A; border-radius: 1px; }
.tt-artist-fig__arm-l { position: absolute; left: -8px; top: 6px; width: 8px; height: 26px; background: #C89070; border-radius: 3px 0 0 3px; }
/* tattoo visible on arm */
.tt-artist-fig__arm-l::before { content: ''; position: absolute; top: 4px; left: 1px; width: 5px; height: 10px; background: rgba(30,50,80,.6); border-radius: 1px; }
.tt-artist-fig__arm-r { position: absolute; right: -8px; top: 6px; width: 8px; height: 26px; background: #1E1E1E; border-radius: 0 3px 3px 0; }
/* tattoo machine in hand */
.tt-artist-fig__machine { position: absolute; right: -18px; top: 16px; width: 14px; height: 20px; background: #383838; border-radius: 1px; border: 1px solid #484848; }
.tt-artist-fig__cord { position: absolute; right: -22px; bottom: 0; width: 2px; height: 14px; background: #282828; border-radius: 1px; }

/* ink shelf */
.tt-scene__ink-shelf { position: absolute; right: 0; top: 18%; width: 20%; }
.tt-scene__shelf-board { height: 6px; background: #282828; margin-bottom: 2px; }
.tt-scene__ink-bottles { display: flex; gap: 3px; padding: 4px 4px 0; }
.tt-ink-bottle { width: 8px; border-radius: 1px 1px 0 0; position: relative; }
.tt-ink-bottle::before { content: ''; position: absolute; top: -4px; left: 50%; transform: translateX(-50%); width: 5px; height: 4px; background: #3A3A3A; border-radius: 1px 1px 0 0; }

/* neon sign on brick wall */
.tt-scene__neon { position: absolute; top: 18%; right: 5%; font-family: 'Bebas Neue', sans-serif; font-size: clamp(1rem, 2.5vw, 1.8rem); color: transparent; letter-spacing: .1em; text-shadow: 0 0 8px <?= $tt_red ?>, 0 0 20px <?= $tt_red ?>, 0 0 40px rgba(192,48,32,.5); -webkit-text-stroke: 1px <?= $tt_red ?>; animation: tt-neon-flicker 8s infinite; }
@keyframes tt-neon-flicker { 0%,96%,100%{ opacity:1; } 97%{ opacity:.6; } 98%{ opacity:1; } 99%{ opacity:.5; } }

/* floating ink splatters */
.tt-splatter { position: absolute; border-radius: 50%; background: var(--tt-red); pointer-events: none; }

/* spotlight cones */
.tt-spot { position: absolute; top: 10%; pointer-events: none; }
.tt-spot__fixture { width: 16px; height: 10px; background: linear-gradient(180deg, #3A3A3A 0%, #282828 100%); border-radius: 2px 2px 0 0; margin: 0 auto; }
.tt-spot__cone { width: 60px; height: 80px; background: radial-gradient(ellipse at 50% 0%, rgba(255,180,80,.08) 0%, transparent 80%); clip-path: polygon(30% 0%, 70% 0%, 100% 100%, 0% 100%); margin-left: -22px; }

/* hero content */
.tt-hero__content { position: relative; z-index: 10; max-width: 560px; padding: 80px 0; }
.tt-hero__eyebrow { font-family: var(--tt-ff-body); font-size: .7rem; font-weight: 700; letter-spacing: .3em; text-transform: uppercase; color: var(--tt-red); margin-bottom: 14px; }
.tt-hero__title { font-family: var(--tt-ff-head); font-size: clamp(3rem, 7vw, 6rem); line-height: .95; color: var(--tt-cream); letter-spacing: .02em; }
.tt-hero__title em { display: block; font-style: normal; color: var(--tt-gold); }
.tt-hero__sub { font-size: .92rem; line-height: 1.8; color: #8A8278; margin: 20px 0 32px; font-weight: 300; }
.tt-hero__ctas { display: flex; gap: 12px; flex-wrap: wrap; }
.tt-hero__since { display: inline-flex; align-items: center; gap: 10px; margin-top: 28px; font-family: var(--tt-ff-body); font-size: .72rem; font-weight: 700; letter-spacing: .15em; text-transform: uppercase; color: #5A5450; }
.tt-hero__since::before, .tt-hero__since::after { content: ''; flex: 1; height: 1px; background: #2A2A2A; }

/* ════════════════════════════════════════════════════════════════════
   TRUST BAR
════════════════════════════════════════════════════════════════════ */
.tt-trust { background: var(--tt-dark); border-top: 1px solid #202020; border-bottom: 1px solid #202020; }
.tt-trust__inner { display: flex; align-items: center; justify-content: center; flex-wrap: wrap; }
.tt-trust__item { display: flex; align-items: center; gap: 12px; padding: 20px 28px; border-right: 1px solid #202020; }
.tt-trust__item:last-child { border-right: none; }
.tt-trust__icon { font-size: 1.3rem; }
.tt-trust__label { font-family: var(--tt-ff-body); font-size: .78rem; font-weight: 700; color: var(--tt-cream); text-transform: uppercase; letter-spacing: .06em; }
.tt-trust__sub { font-size: .7rem; color: #5A5450; }

/* ════════════════════════════════════════════════════════════════════
   STYLES
════════════════════════════════════════════════════════════════════ */
.tt-styles { padding: 100px 0; background: var(--tt-black); }
.tt-styles__header { max-width: 560px; margin-bottom: 60px; }
.tt-styles__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 2px; }
.tt-style-card { background: var(--tt-dark); padding: 36px 32px; position: relative; overflow: hidden; transition: var(--tt-trans); cursor: default; }
.tt-style-card::before { content: ''; position: absolute; top: 0; left: 0; width: 3px; height: 100%; background: var(--tt-red); transform: scaleY(0); transform-origin: top; transition: var(--tt-trans); }
.tt-style-card:hover { background: var(--tt-grey); }
.tt-style-card:hover::before { transform: scaleY(1); }
.tt-style-card__icon { font-size: 2rem; margin-bottom: 16px; display: block; }
.tt-style-card__name { font-family: var(--tt-ff-head); font-size: 1.6rem; color: var(--tt-cream); letter-spacing: .04em; margin-bottom: 10px; }
.tt-style-card__desc { font-size: .88rem; line-height: 1.7; color: #6A6460; font-weight: 300; }

/* ════════════════════════════════════════════════════════════════════
   ARTISTS
════════════════════════════════════════════════════════════════════ */
.tt-artists { padding: 100px 0; background: var(--tt-dark); }
.tt-artists__header { text-align: center; max-width: 560px; margin: 0 auto 60px; }
.tt-artists__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 2px; }
.tt-artist-card { background: var(--tt-grey); position: relative; overflow: hidden; transition: var(--tt-trans); }
.tt-artist-card:hover { transform: translateY(-4px); }
.tt-artist-card__figure { height: 220px; display: flex; align-items: flex-end; justify-content: center; padding-bottom: 0; position: relative; overflow: hidden; }
.tt-artist-card__info { padding: 24px 24px 28px; position: relative; }
.tt-artist-card__accent { position: absolute; top: 0; left: 0; right: 0; height: 3px; }
.tt-artist-card__name { font-family: var(--tt-ff-head); font-size: 1.6rem; color: var(--tt-cream); letter-spacing: .04em; margin-bottom: 4px; }
.tt-artist-card__specialty { font-family: var(--tt-ff-body); font-size: .78rem; font-weight: 700; letter-spacing: .12em; text-transform: uppercase; margin-bottom: 8px; }
.tt-artist-card__style { font-size: .82rem; color: #5A5450; font-weight: 300; line-height: 1.5; margin-bottom: 12px; }
.tt-artist-card__yrs { font-family: var(--tt-ff-body); font-size: .72rem; font-weight: 700; color: #4A4440; text-transform: uppercase; letter-spacing: .1em; }

/* CSS tattoo artist figure */
.tt-art-figure { position: relative; width: 80px; }
.tt-art-figure__bg { position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); width: 120px; height: 180px; background: radial-gradient(ellipse at 50% 100%, rgba(255,255,255,.03) 0%, transparent 70%); border-radius: 50%; }
.tt-art-figure__head { width: 30px; height: 34px; margin: 0 auto; border-radius: 50% 50% 40% 40%; position: relative; }
.tt-art-figure__hair { position: absolute; top: 0; left: 0; right: 0; height: 18px; clip-path: var(--art-hair-clip, ellipse(50% 55% at 50% 0%)); }
.tt-art-figure__body { width: 42px; height: 60px; background: #0A0A0A; border-radius: 2px 2px 0 0; margin: 4px auto 0; position: relative; }
.tt-art-figure__arm { position: absolute; top: 8px; width: 10px; height: 32px; border-radius: 3px; }
.tt-art-figure__arm--l { left: -10px; border-radius: 3px 0 0 3px; }
.tt-art-figure__arm--r { right: -10px; border-radius: 0 3px 3px 0; }

/* ════════════════════════════════════════════════════════════════════
   COUNTERS
════════════════════════════════════════════════════════════════════ */
.tt-counters { background: var(--tt-red); padding: 72px 0; }
.tt-counters__grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 40px; text-align: center; }
.tt-counter__value { font-family: var(--tt-ff-head); font-size: clamp(2.4rem, 4.5vw, 3.6rem); color: #fff; line-height: 1; letter-spacing: .02em; }
.tt-counter__value span { color: rgba(255,255,255,.9); }
.tt-counter__label { font-family: var(--tt-ff-body); font-size: .72rem; font-weight: 700; color: rgba(255,255,255,.6); text-transform: uppercase; letter-spacing: .15em; margin-top: 10px; }

/* ════════════════════════════════════════════════════════════════════
   PROCESS
════════════════════════════════════════════════════════════════════ */
.tt-process { padding: 100px 0; background: var(--tt-black); }
.tt-process__header { text-align: center; max-width: 560px; margin: 0 auto 60px; }
.tt-process__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 2px; }
.tt-process-card { background: var(--tt-dark); padding: 40px 32px; }
.tt-process-card__num { font-family: var(--tt-ff-head); font-size: 4rem; color: #1E1E1E; line-height: 1; margin-bottom: 16px; }
.tt-process-card__title { font-family: var(--tt-ff-head); font-size: 1.8rem; color: var(--tt-cream); letter-spacing: .04em; margin-bottom: 12px; }
.tt-process-card__desc { font-size: .88rem; line-height: 1.7; color: #5A5450; font-weight: 300; }

/* ════════════════════════════════════════════════════════════════════
   PACKAGES
════════════════════════════════════════════════════════════════════ */
.tt-packages { padding: 100px 0; background: var(--tt-dark); }
.tt-packages__header { text-align: center; max-width: 560px; margin: 0 auto 60px; }
.tt-packages__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 2px; align-items: start; }
.tt-package-card { background: var(--tt-grey); padding: 40px 36px; position: relative; transition: var(--tt-trans); }
.tt-package-card:hover { background: #242424; }
.tt-package-card--featured { background: var(--tt-red); }
.tt-package-card--featured .tt-package-card__name,
.tt-package-card--featured .tt-package-card__price,
.tt-package-card--featured .tt-package-card__period,
.tt-package-card--featured .tt-package-card__item { color: rgba(255,255,255,.95); }
.tt-package-card--featured .tt-package-card__item::before { background: rgba(255,255,255,.8); }
.tt-package-card__badge { position: absolute; top: 0; right: 0; background: var(--tt-gold); color: var(--tt-black); font-family: var(--tt-ff-body); font-size: .65rem; font-weight: 800; letter-spacing: .12em; text-transform: uppercase; padding: 4px 14px; }
.tt-package-card__name { font-family: var(--tt-ff-head); font-size: 1.8rem; color: var(--tt-cream); letter-spacing: .04em; margin-bottom: 16px; }
.tt-package-card__price-row { display: flex; align-items: baseline; gap: 6px; margin-bottom: 28px; border-bottom: 1px solid rgba(255,255,255,.06); padding-bottom: 20px; }
.tt-package-card__price { font-family: var(--tt-ff-head); font-size: 1.8rem; color: var(--tt-cream); letter-spacing: .04em; }
.tt-package-card__period { font-size: .82rem; color: #5A5450; font-weight: 300; }
.tt-package-card__list { list-style: none; display: flex; flex-direction: column; gap: 10px; margin-bottom: 30px; }
.tt-package-card__item { font-size: .85rem; color: #8A8278; padding-left: 16px; position: relative; font-weight: 300; }
.tt-package-card__item::before { content: ''; position: absolute; left: 0; top: 50%; transform: translateY(-50%); width: 5px; height: 5px; background: var(--tt-gold); }

/* ════════════════════════════════════════════════════════════════════
   TESTIMONIALS
════════════════════════════════════════════════════════════════════ */
.tt-testimonials { padding: 100px 0; background: var(--tt-black); }
.tt-testimonials__header { text-align: center; max-width: 560px; margin: 0 auto 56px; }
.tt-testimonials__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 2px; }
.tt-testimonial { background: var(--tt-dark); padding: 40px; position: relative; }
.tt-testimonial__quote { font-family: var(--tt-ff-head); font-size: 5rem; color: #1E1E1E; line-height: 1; position: absolute; top: 12px; left: 24px; }
.tt-testimonial__stars { color: var(--tt-gold); font-size: .9rem; letter-spacing: 2px; margin-bottom: 16px; }
.tt-testimonial__text { font-size: .9rem; line-height: 1.8; color: #7A7268; font-style: italic; font-weight: 300; margin-top: 16px; }
.tt-testimonial__author { margin-top: 24px; }
.tt-testimonial__name { font-family: var(--tt-ff-body); font-size: .88rem; font-weight: 700; color: var(--tt-cream); text-transform: uppercase; letter-spacing: .1em; }
.tt-testimonial__piece { font-size: .78rem; color: var(--tt-red); margin-top: 3px; }

/* ════════════════════════════════════════════════════════════════════
   BOOKING
════════════════════════════════════════════════════════════════════ */
.tt-booking { padding: 100px 0; background: var(--tt-dark); }
.tt-booking__inner { display: grid; grid-template-columns: 1fr 1fr; gap: 72px; align-items: start; }
.tt-form { background: var(--tt-grey); padding: 44px; }
.tt-form__title { font-family: var(--tt-ff-head); font-size: 2.4rem; color: var(--tt-cream); letter-spacing: .04em; margin-bottom: 28px; line-height: 1; }
.tt-form__row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.tt-form__group { display: flex; flex-direction: column; gap: 6px; margin-bottom: 16px; }
.tt-form__group--full { grid-column: 1 / -1; }
.tt-form__label { font-family: var(--tt-ff-body); font-size: .72rem; font-weight: 700; color: #5A5450; letter-spacing: .12em; text-transform: uppercase; }
.tt-form__input, .tt-form__select, .tt-form__textarea { width: 100%; padding: 11px 14px; border: 1px solid #2A2A2A; background: var(--tt-mid); font-family: var(--tt-ff-body); font-size: .88rem; color: var(--tt-cream); transition: var(--tt-trans); outline: none; border-radius: 2px; }
.tt-form__input::placeholder { color: #3A3A3A; }
.tt-form__input:focus, .tt-form__select:focus, .tt-form__textarea:focus { border-color: var(--tt-red); box-shadow: 0 0 0 3px rgba(192,48,32,.15); }
.tt-form__select option { background: var(--tt-grey); }
.tt-form__textarea { resize: vertical; min-height: 100px; }
.tt-form__submit { width: 100%; padding: 15px; font-family: var(--tt-ff-body); font-size: .82rem; font-weight: 800; color: #fff; background: var(--tt-red); border: none; cursor: pointer; transition: var(--tt-trans); text-transform: uppercase; letter-spacing: .12em; }
.tt-form__submit:hover { background: #A02018; transform: translateY(-2px); box-shadow: 0 8px 24px rgba(192,48,32,.4); }
.tt-form__note { font-size: .72rem; color: #3A3A3A; text-align: center; margin-top: 12px; font-weight: 300; }

.tt-booking__info { }
.tt-booking__rule { width: 48px; height: 2px; background: var(--tt-red); margin: 20px 0; }
.tt-booking__detail { margin-top: 28px; }
.tt-booking__detail-row { display: flex; gap: 16px; align-items: flex-start; padding: 14px 0; border-bottom: 1px solid #1E1E1E; }
.tt-booking__detail-row:last-child { border-bottom: none; }
.tt-booking__detail-icon { font-size: 1.2rem; flex-shrink: 0; margin-top: 2px; }
.tt-booking__detail-title { font-family: var(--tt-ff-body); font-size: .82rem; font-weight: 700; color: var(--tt-cream); text-transform: uppercase; letter-spacing: .08em; margin-bottom: 3px; }
.tt-booking__detail-text { font-size: .82rem; color: #5A5450; font-weight: 300; }

/* ════════════════════════════════════════════════════════════════════
   FOOTER CTA
════════════════════════════════════════════════════════════════════ */
.tt-footer-cta { background: var(--tt-black); padding: 80px 0; text-align: center; border-top: 1px solid #1A1A1A; }
.tt-footer-cta__title { font-family: var(--tt-ff-head); font-size: clamp(2.4rem, 5vw, 5rem); color: var(--tt-cream); letter-spacing: .02em; line-height: 1; margin-bottom: 24px; }
.tt-footer-cta__title em { font-style: normal; color: var(--tt-red); }
.tt-footer-cta__sub { font-size: .88rem; color: #4A4440; margin-bottom: 36px; text-transform: uppercase; letter-spacing: .2em; font-weight: 700; }
.tt-footer-cta__actions { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }

/* ════════════════════════════════════════════════════════════════════
   RESPONSIVE
════════════════════════════════════════════════════════════════════ */
@media (max-width: 900px) {
    .tt-booking__inner { grid-template-columns: 1fr; gap: 48px; }
    .tt-counters__grid { grid-template-columns: repeat(2, 1fr); }
    .tt-trust__item { padding: 16px 18px; }
}
@media (max-width: 600px) {
    .tt-hero { min-height: 80vh; }
    .tt-counters__grid { grid-template-columns: repeat(2, 1fr); }
    .tt-form__row { grid-template-columns: 1fr; }
    .tt-trust__inner { flex-direction: column; }
    .tt-trust__item { border-right: none; border-bottom: 1px solid #202020; }
}
</style>

<div class="tt-wrap">

    <!-- ═══════════════════════════════════ HERO ═══════════════════════════════════ -->
    <section class="tt-hero">
        <div class="tt-scene" aria-hidden="true">

            <!-- structure -->
            <div class="tt-scene__ceiling"></div>
            <div class="tt-scene__pipe"></div>
            <div class="tt-scene__wall"></div>
            <div class="tt-scene__brick"></div>
            <div class="tt-scene__floor">
                <div class="tt-scene__floor-line"></div>
            </div>

            <!-- spotlights -->
            <?php foreach ( [ 25, 55, 78 ] as $sx ) : ?>
            <div class="tt-spot" style="left:<?= $sx ?>%;">
                <div class="tt-spot__fixture"></div>
                <div class="tt-spot__cone"></div>
            </div>
            <?php endforeach; ?>

            <!-- flash art on wall -->
            <?php foreach ( $flash_pieces as $fi ) :
                $fw = 48; $fh = 56;
            ?>
            <div class="tt-flash-frame" style="left:<?= $fi['x'] ?>%;top:<?= $fi['y'] ?>%;width:<?= $fw ?>px;height:<?= $fh ?>px;padding:4px;">
                <?php if ( $fi['type'] === 'rose' ) : ?>
                <svg viewBox="0 0 40 50" width="<?= $fw-8 ?>" height="<?= $fh-8 ?>" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="20" cy="18" r="12" fill="<?= $fi['color'] ?>" stroke="<?= $fi['border'] ?>" stroke-width="1.5"/>
                    <circle cx="20" cy="14" r="8" fill="<?= $fi['color'] ?>" opacity=".6"/>
                    <ellipse cx="20" cy="10" rx="6" ry="5" fill="<?= $fi['color'] ?>" opacity=".4"/>
                    <line x1="20" y1="30" x2="20" y2="48" stroke="#3A7040" stroke-width="2"/>
                    <ellipse cx="14" cy="38" rx="5" ry="3" fill="#3A7040" transform="rotate(-30 14 38)"/>
                </svg>
                <?php elseif ( $fi['type'] === 'skull' ) : ?>
                <svg viewBox="0 0 40 50" width="<?= $fw-8 ?>" height="<?= $fh-8 ?>" xmlns="http://www.w3.org/2000/svg">
                    <ellipse cx="20" cy="20" rx="14" ry="16" fill="<?= $fi['color'] ?>" stroke="<?= $fi['border'] ?>" stroke-width="1.5"/>
                    <circle cx="14" cy="18" r="5" fill="<?= $tt_black ?>"/>
                    <circle cx="26" cy="18" r="5" fill="<?= $tt_black ?>"/>
                    <rect x="13" y="32" width="5" height="6" rx="1" fill="<?= $fi['border'] ?>"/>
                    <rect x="22" y="32" width="5" height="6" rx="1" fill="<?= $fi['border'] ?>"/>
                </svg>
                <?php elseif ( $fi['type'] === 'anchor' ) : ?>
                <svg viewBox="0 0 40 50" width="<?= $fw-8 ?>" height="<?= $fh-8 ?>" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="20" cy="10" r="6" fill="none" stroke="<?= $fi['color'] ?>" stroke-width="2.5"/>
                    <line x1="20" y1="16" x2="20" y2="44" stroke="<?= $fi['color'] ?>" stroke-width="2.5"/>
                    <line x1="8" y1="28" x2="32" y2="28" stroke="<?= $fi['color'] ?>" stroke-width="2.5"/>
                    <path d="M8 28 Q4 40 12 42" fill="none" stroke="<?= $fi['color'] ?>" stroke-width="2"/>
                    <path d="M32 28 Q36 40 28 42" fill="none" stroke="<?= $fi['color'] ?>" stroke-width="2"/>
                </svg>
                <?php elseif ( $fi['type'] === 'dagger' ) : ?>
                <svg viewBox="0 0 40 50" width="<?= $fw-8 ?>" height="<?= $fh-8 ?>" xmlns="http://www.w3.org/2000/svg">
                    <polygon points="20,4 17,32 20,38 23,32" fill="<?= $fi['color'] ?>" stroke="<?= $fi['border'] ?>" stroke-width="1"/>
                    <rect x="12" y="32" width="16" height="4" rx="1" fill="<?= $fi['border'] ?>"/>
                    <rect x="17" y="36" width="6" height="10" rx="1" fill="<?= $fi['border'] ?>"/>
                </svg>
                <?php elseif ( $fi['type'] === 'eagle' ) : ?>
                <svg viewBox="0 0 40 50" width="<?= $fw-8 ?>" height="<?= $fh-8 ?>" xmlns="http://www.w3.org/2000/svg">
                    <ellipse cx="20" cy="20" rx="8" ry="10" fill="<?= $fi['color'] ?>"/>
                    <path d="M4 18 Q12 10 20 18" fill="<?= $fi['color'] ?>" stroke="<?= $fi['border'] ?>" stroke-width="1"/>
                    <path d="M36 18 Q28 10 20 18" fill="<?= $fi['color'] ?>" stroke="<?= $fi['border'] ?>" stroke-width="1"/>
                    <circle cx="20" cy="14" r="4" fill="<?= $fi['color'] ?>"/>
                    <polygon points="18,12 22,12 20,10" fill="<?= $fi['border'] ?>"/>
                </svg>
                <?php else : /* snake */ ?>
                <svg viewBox="0 0 40 50" width="<?= $fw-8 ?>" height="<?= $fh-8 ?>" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20 8 Q30 16 20 24 Q10 32 20 40 Q24 44 22 48" fill="none" stroke="<?= $fi['color'] ?>" stroke-width="5" stroke-linecap="round"/>
                    <circle cx="20" cy="8" r="4" fill="<?= $fi['color'] ?>"/>
                    <line x1="18" y1="5" x2="16" y2="3" stroke="<?= $fi['border'] ?>" stroke-width="1.5"/>
                    <line x1="22" y1="5" x2="24" y2="3" stroke="<?= $fi['border'] ?>" stroke-width="1.5"/>
                </svg>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>

            <!-- neon sign -->
            <div class="tt-scene__neon" style="top:16%;right:6%;">SACRED INK</div>

            <!-- workstation with artist + chair -->
            <div class="tt-scene__workstation">
                <div class="tt-scene__artist">
                    <div style="position:relative;">
                        <div class="tt-artist-fig__head">
                            <div class="tt-artist-fig__hair"></div>
                            <div class="tt-artist-fig__hat"></div>
                        </div>
                        <div class="tt-artist-fig__neck"></div>
                        <div style="position:relative;display:inline-block;">
                            <div class="tt-artist-fig__body">
                                <div class="tt-artist-fig__arm-l"></div>
                                <div class="tt-artist-fig__arm-r">
                                    <div class="tt-artist-fig__machine"></div>
                                    <div class="tt-artist-fig__cord"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- client chair -->
                <div class="tt-scene__chair" style="right:10%;bottom:0;">
                    <div style="position:relative;">
                        <div class="tt-scene__chair-back">
                            <div class="tt-scene__chair-leg" style="left:4px;bottom:-20px;"></div>
                            <div class="tt-scene__chair-leg" style="right:4px;bottom:-20px;"></div>
                        </div>
                        <div class="tt-scene__chair-seat"></div>
                    </div>
                    <div class="tt-scene__chair-base"></div>
                </div>
                <!-- ink shelf -->
                <div class="tt-scene__ink-shelf" style="position:absolute;top:-60px;right:0;width:60px;">
                    <div class="tt-scene__shelf-board"></div>
                    <div class="tt-scene__ink-bottles">
                        <?php foreach ( array_slice($inks, 0, 6) as $ink ) : ?>
                        <div class="tt-ink-bottle" style="height:<?= rand(16,24) ?>px;background:<?= $ink['color'] ?>;"></div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- floating splatters -->
            <?php foreach ( $splatters as $sp ) : ?>
            <div class="tt-splatter" style="left:<?= $sp['x'] ?>%;top:<?= $sp['y'] ?>%;width:<?= $sp['sz'] ?>px;height:<?= $sp['sz'] ?>px;opacity:<?= $sp['op'] / 100 ?>;animation:vt-paw-float <?= $sp['delay'] + 4 ?>s <?= $sp['delay'] ?>s ease-in-out infinite;"></div>
            <?php endforeach; ?>

        </div><!-- /.tt-scene -->

        <div class="tt-container">
            <div class="tt-hero__content">
                <p class="tt-hero__eyebrow">◆ Est. London 2003 ◆ Custom Tattooing</p>
                <h1 class="tt-hero__title">
                    Sacred
                    <em>Ink</em>
                    Studio
                </h1>
                <p class="tt-hero__sub">Bespoke tattooing by award-winning artists. Japanese, blackwork, realism, fine line, and neo-traditional — every piece custom-designed for your skin, your story.</p>
                <div class="tt-hero__ctas">
                    <a href="#booking" class="tt-btn tt-btn--primary">Book a Consultation</a>
                    <a href="#artists" class="tt-btn tt-btn--gold">Meet the Artists</a>
                </div>
                <div class="tt-hero__since">Shoreditch, London · Open Tue–Sun 11am–8pm</div>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ TRUST BAR ═════════════════════════════ -->
    <div class="tt-trust">
        <div class="tt-container">
            <div class="tt-trust__inner">
                <?php
                $trust_items = [
                    [ 'icon' => '🏆', 'label' => 'Award-Winning Artists',    'sub' => 'Multiple convention winners' ],
                    [ 'icon' => '🔒', 'label' => 'Fully Sterilised',         'sub' => 'Autoclave sterilisation onsite' ],
                    [ 'icon' => '🎨', 'label' => '100% Custom Designs',      'sub' => 'No flash off the wall' ],
                    [ 'icon' => '⭐', 'label' => '4.9 Google Rating',        'sub' => '1,800+ verified reviews' ],
                    [ 'icon' => '🩹', 'label' => 'Aftercare Guaranteed',     'sub' => 'Free touch-up within 3 months' ],
                ];
                foreach ( $trust_items as $ti ) : ?>
                <div class="tt-trust__item">
                    <span class="tt-trust__icon"><?= $ti['icon'] ?></span>
                    <div>
                        <div class="tt-trust__label"><?= esc_html( $ti['label'] ) ?></div>
                        <div class="tt-trust__sub"><?= esc_html( $ti['sub'] ) ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- ═══════════════════════════════════ STYLES ════════════════════════════════ -->
    <section class="tt-styles" id="styles">
        <div class="tt-container">
            <div class="tt-styles__header">
                <span class="tt-section-label">Our Specialisms</span>
                <h2 class="tt-section-title">Every Style, <em>Mastered</em></h2>
                <p class="tt-section-body">Each artist brings a distinct voice and deep specialism. Whatever style resonates with you, we have a master practitioner to bring it to life.</p>
            </div>
            <div class="tt-styles__grid">
                <?php foreach ( $styles as $s ) : ?>
                <div class="tt-style-card">
                    <span class="tt-style-card__icon"><?= $s['icon'] ?></span>
                    <div class="tt-style-card__name"><?= esc_html( $s['name'] ) ?></div>
                    <p class="tt-style-card__desc"><?= esc_html( $s['desc'] ) ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ COUNTERS ═════════════════════════════ -->
    <section class="tt-counters" aria-label="Studio statistics">
        <div class="tt-container">
            <div class="tt-counters__grid">
                <?php foreach ( $counters as $c ) : ?>
                <div>
                    <div class="tt-counter__value"
                         data-target="<?= $c['value'] ?>"
                         <?= $c['float'] ? 'data-float="1"' : '' ?>>
                        <span>0</span><?= esc_html( $c['suffix'] ) ?>
                    </div>
                    <div class="tt-counter__label"><?= esc_html( $c['label'] ) ?></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ ARTISTS ══════════════════════════════ -->
    <section class="tt-artists" id="artists">
        <div class="tt-container">
            <div class="tt-artists__header">
                <span class="tt-section-label">The Artists</span>
                <h2 class="tt-section-title">Meet the <em>Masters</em></h2>
                <p class="tt-section-body">Our artists are carefully selected for exceptional skill, distinctive style, and a relentless commitment to their craft.</p>
            </div>
            <div class="tt-artists__grid">
                <?php
                $skin_tones = [ '#C89070', '#9A6840', '#7A4820', '#D4A880' ];
                $hair_clips = [ 'ellipse(50% 55% at 50% 0%)', 'ellipse(55% 60% at 50% 0%)', 'ellipse(48% 52% at 50% 0%)', 'ellipse(52% 58% at 50% 0%)' ];
                $hair_cols  = [ '#0A0A0A', '#2C1810', '#0A0A0A', '#8B4513' ];
                foreach ( $artists as $i => $art ) : ?>
                <div class="tt-artist-card">
                    <div class="tt-artist-card__figure" style="background:linear-gradient(180deg,#1A1A1A 0%,#141414 100%);">
                        <div class="tt-art-figure"
                             style="--art-hair-clip:<?= $hair_clips[$i] ?>;">
                            <div class="tt-art-figure__bg"></div>
                            <div class="tt-art-figure__head" style="background:<?= $skin_tones[$i] ?>;">
                                <div class="tt-art-figure__hair" style="background:<?= $hair_cols[$i] ?>;height:18px;"></div>
                            </div>
                            <div class="tt-art-figure__body">
                                <div class="tt-art-figure__arm tt-art-figure__arm--l" style="background:<?= $skin_tones[$i] ?>;"></div>
                                <div class="tt-art-figure__arm tt-art-figure__arm--r" style="background:#0A0A0A;"></div>
                            </div>
                        </div>
                    </div>
                    <div class="tt-artist-card__accent" style="background:<?= $art['color'] ?>;"></div>
                    <div class="tt-artist-card__info">
                        <div class="tt-artist-card__name"><?= esc_html( $art['name'] ) ?></div>
                        <div class="tt-artist-card__specialty" style="color:<?= $art['color'] ?>;"><?= esc_html( $art['specialty'] ) ?></div>
                        <div class="tt-artist-card__style"><?= esc_html( $art['style'] ) ?></div>
                        <div class="tt-artist-card__yrs"><?= $art['yrs'] ?> years tattooing</div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ PROCESS ══════════════════════════════ -->
    <section class="tt-process">
        <div class="tt-container">
            <div class="tt-process__header">
                <span class="tt-section-label">The Process</span>
                <h2 class="tt-section-title">From Concept <em>to Skin</em></h2>
            </div>
            <div class="tt-process__grid">
                <?php foreach ( $process as $step ) : ?>
                <div class="tt-process-card">
                    <div class="tt-process-card__num"><?= esc_html( $step['num'] ) ?></div>
                    <div class="tt-process-card__title"><?= esc_html( $step['title'] ) ?></div>
                    <p class="tt-process-card__desc"><?= esc_html( $step['desc'] ) ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ PACKAGES ═════════════════════════════ -->
    <section class="tt-packages" id="pricing">
        <div class="tt-container">
            <div class="tt-packages__header">
                <span class="tt-section-label">Pricing</span>
                <h2 class="tt-section-title">Invest in <em>Permanent Art</em></h2>
                <p class="tt-section-body">We quote every piece individually after your consultation. Below are starting-from guides — final pricing reflects complexity, size, and placement.</p>
            </div>
            <div class="tt-packages__grid">
                <?php foreach ( $packages as $pkg ) : ?>
                <div class="tt-package-card <?= $pkg['featured'] ? 'tt-package-card--featured' : '' ?>">
                    <?php if ( $pkg['featured'] ) : ?>
                    <div class="tt-package-card__badge">Most Booked</div>
                    <?php endif; ?>
                    <div class="tt-package-card__name"><?= esc_html( $pkg['name'] ) ?></div>
                    <div class="tt-package-card__price-row">
                        <div class="tt-package-card__price"><?= esc_html( $pkg['price'] ) ?></div>
                        <div class="tt-package-card__period"><?= esc_html( $pkg['period'] ) ?></div>
                    </div>
                    <ul class="tt-package-card__list">
                        <?php foreach ( $pkg['items'] as $item ) : ?>
                        <li class="tt-package-card__item"><?= esc_html( $item ) ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <a href="#booking" class="tt-btn <?= $pkg['featured'] ? 'tt-btn--outline' : 'tt-btn--gold' ?>" style="width:100%;justify-content:center;text-align:center;">
                        Book Consultation
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ TESTIMONIALS ═════════════════════════ -->
    <section class="tt-testimonials">
        <div class="tt-container">
            <div class="tt-testimonials__header">
                <span class="tt-section-label">Client Words</span>
                <h2 class="tt-section-title">Worn With <em>Pride</em></h2>
            </div>
            <div class="tt-testimonials__grid">
                <?php foreach ( $testimonials as $t ) : ?>
                <div class="tt-testimonial">
                    <div class="tt-testimonial__quote">"</div>
                    <div class="tt-testimonial__stars">★★★★★</div>
                    <p class="tt-testimonial__text"><?= esc_html( $t['text'] ) ?></p>
                    <div class="tt-testimonial__author">
                        <div class="tt-testimonial__name"><?= esc_html( $t['name'] ) ?></div>
                        <div class="tt-testimonial__piece"><?= esc_html( $t['piece'] ) ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ BOOKING ══════════════════════════════ -->
    <section class="tt-booking" id="booking">
        <div class="tt-container">
            <div class="tt-booking__inner">
                <div class="tt-booking__info">
                    <span class="tt-section-label">Book a Consultation</span>
                    <h2 class="tt-section-title">Start Your <em>Story</em></h2>
                    <div class="tt-booking__rule"></div>
                    <p class="tt-section-body">Every tattoo begins with a conversation. Book a free 30-minute consultation in studio or by video — no deposit required at this stage.</p>
                    <div class="tt-booking__detail">
                        <?php
                        $details = [
                            [ 'icon' => '📍', 'title' => 'Location',       'text' => '14 Redchurch Street, Shoreditch, London E2 7DJ' ],
                            [ 'icon' => '⏰', 'title' => 'Opening Hours',   'text' => 'Tuesday–Sunday, 11am–8pm · Closed Monday' ],
                            [ 'icon' => '💳', 'title' => 'Deposit',         'text' => '20% deposit required to secure your tattoo appointment' ],
                            [ 'icon' => '🚇', 'title' => 'Getting Here',    'text' => '5 min walk from Shoreditch High Street Overground' ],
                        ];
                        foreach ( $details as $d ) : ?>
                        <div class="tt-booking__detail-row">
                            <span class="tt-booking__detail-icon"><?= $d['icon'] ?></span>
                            <div>
                                <div class="tt-booking__detail-title"><?= esc_html( $d['title'] ) ?></div>
                                <div class="tt-booking__detail-text"><?= esc_html( $d['text'] ) ?></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div>
                    <form class="tt-form" method="post" action="">
                        <?php wp_nonce_field( 'tf_tt_booking', 'tf_tt_nonce' ); ?>
                        <div class="tt-form__title">Book Free Consult</div>
                        <div class="tt-form__row">
                            <div class="tt-form__group">
                                <label class="tt-form__label" for="tt-name">Your Name *</label>
                                <input class="tt-form__input" type="text" id="tt-name" name="name" placeholder="First Last" required>
                            </div>
                            <div class="tt-form__group">
                                <label class="tt-form__label" for="tt-email">Email *</label>
                                <input class="tt-form__input" type="email" id="tt-email" name="email" placeholder="you@example.com" required>
                            </div>
                        </div>
                        <div class="tt-form__row">
                            <div class="tt-form__group">
                                <label class="tt-form__label" for="tt-phone">Phone</label>
                                <input class="tt-form__input" type="tel" id="tt-phone" name="phone" placeholder="07700 900 000">
                            </div>
                            <div class="tt-form__group">
                                <label class="tt-form__label" for="tt-style">Style *</label>
                                <select class="tt-form__select" id="tt-style" name="style">
                                    <option value="">Select style…</option>
                                    <option>Japanese</option>
                                    <option>Blackwork / Geometric</option>
                                    <option>Neo-Traditional</option>
                                    <option>Realism</option>
                                    <option>Fine Line</option>
                                    <option>Old School</option>
                                    <option>Other / Unsure</option>
                                </select>
                            </div>
                        </div>
                        <div class="tt-form__group tt-form__group--full">
                            <label class="tt-form__label" for="tt-concept">Your Concept *</label>
                            <textarea class="tt-form__textarea" id="tt-concept" name="concept" placeholder="Describe your tattoo idea — subject matter, size, placement, any reference images you have in mind…" required></textarea>
                        </div>
                        <div class="tt-form__group tt-form__group--full">
                            <label class="tt-form__label" for="tt-format">Consultation Format</label>
                            <select class="tt-form__select" id="tt-format" name="format">
                                <option value="in-studio">In-Studio (Shoreditch)</option>
                                <option value="video">Video Call</option>
                            </select>
                        </div>
                        <button type="submit" class="tt-form__submit">Request Consultation →</button>
                        <p class="tt-form__note">Free 30-minute consultation · No obligation · Responds within 24 hours</p>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ FOOTER CTA ═══════════════════════════ -->
    <section class="tt-footer-cta">
        <div class="tt-container">
            <h2 class="tt-footer-cta__title">Ready to Wear Your <em>Story?</em></h2>
            <p class="tt-footer-cta__sub">Sacred Ink Studio · Shoreditch, London · Open Tue–Sun</p>
            <div class="tt-footer-cta__actions">
                <a href="#booking" class="tt-btn tt-btn--primary">Book Consultation</a>
                <a href="#styles" class="tt-btn tt-btn--outline">Explore Styles</a>
            </div>
        </div>
    </section>

</div><!-- /.tt-wrap -->

<script>
/* ── IntersectionObserver animated counters ───────────────────────── */
(function () {
    'use strict';
    var easeOut = function (t) { return 1 - Math.pow(1 - t, 3); };
    var els = document.querySelectorAll('.tt-counter__value[data-target]');
    if (!els.length) return;
    var obs = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (!entry.isIntersecting) return;
            obs.unobserve(entry.target);
            var el      = entry.target;
            var target  = parseFloat(el.dataset.target);
            var isFloat = !!el.dataset.float;
            var span    = el.querySelector('span');
            if (!span || isNaN(target)) return;
            var dur = 1800, start = null;
            function tick(ts) {
                if (!start) start = ts;
                var p = Math.min((ts - start) / dur, 1);
                var v = easeOut(p) * target;
                span.textContent = isFloat ? v.toFixed(1) : Math.round(v).toLocaleString();
                if (p < 1) requestAnimationFrame(tick);
                else span.textContent = isFloat ? target.toFixed(1) : target.toLocaleString();
            }
            requestAnimationFrame(tick);
        });
    }, { threshold: 0.4 });
    els.forEach(function (el) { obs.observe(el); });
})();
</script>

<?php get_footer(); ?>
