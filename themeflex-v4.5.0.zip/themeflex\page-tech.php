<?php
/**
 * Template Name: Tech Agency Homepage
 * Template Post Type: page
 *
 * Premium Tech Agency / Software Studio template — Nexus Labs
 * Namespace: --te-*  |  Fonts: DM Mono + DM Sans
 * Palette: Midnight #0A0E1A / Electric #00D4FF / Violet #7C3AED / Lime #A3E635 / Slate #475569
 */
defined('ABSPATH') || exit;
get_header();

/* ── Deterministic randomness ──────────────────────────── */
srand(crc32('nexus-labs-tech'));
$te_nodes = [];
for ($i = 0; $i < 24; $i++) {
    $te_nodes[] = [
        'x'  => rand(5, 92),
        'y'  => rand(8, 88),
        'r'  => rand(2, 5),
        'c'  => (['#00D4FF','#7C3AED','#A3E635','#FFFFFF20'])[rand(0,3)],
        'sd' => rand(0, 3000),
        'dur'=> rand(2000, 5000),
    ];
}
$te_services = [
    ['⚙️','Platform Engineering','We architect cloud-native platforms that scale from 1 to 100 million users — Kubernetes, Terraform, multi-region, zero-downtime.'],
    ['🧠','AI & Machine Learning','From LLM integrations to custom model training, we build AI that ships to production and keeps performing.','New'],
    ['📱','Product Design & Dev','End-to-end product development: discovery, UX, React/React Native build, QA, and launch — all under one roof.'],
    ['🔐','Security & Compliance','SOC 2, ISO 27001, GDPR, and penetration testing. We harden your stack so you can sell to enterprise with confidence.'],
    ['📊','Data Engineering','Data lakes, real-time pipelines, dbt transformations, and BI tooling that turns raw events into boardroom insights.'],
    ['🚀','DevOps & SRE','CI/CD, observability, incident response playbooks, and on-call runbooks so you can deploy ten times a day without fear.'],
];
$te_stats = [['500+','Products Shipped'],['12yr','In Production'],['99.98','% Uptime SLA'],['$2B+','Client GMV Processed']];
?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Mono:ital,wght@0,300;0,400;0,500;1,300&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,700;1,9..40,300&display=swap" rel="stylesheet">

<style>
/* ════════════════════════════════════════════════════════
   CSS CUSTOM PROPERTIES — --te-* namespace
════════════════════════════════════════════════════════ */
:root {
  --te-midnight: #0A0E1A;
  --te-dark:     #111827;
  --te-panel:    #161D2E;
  --te-border:   rgba(255,255,255,.08);
  --te-electric: #00D4FF;
  --te-violet:   #7C3AED;
  --te-lime:     #A3E635;
  --te-slate:    #475569;
  --te-muted:    #94A3B8;
  --te-white:    #F0F4FF;
  --te-mono:     'DM Mono', 'Fira Code', monospace;
  --te-sans:     'DM Sans', system-ui, sans-serif;
  --te-r:        6px;
  --te-glow-e:   0 0 24px rgba(0,212,255,.35);
  --te-glow-v:   0 0 24px rgba(124,58,237,.35);
  --te-trans:    all .3s cubic-bezier(.4,0,.2,1);
}
.te-page *, .te-page *::before, .te-page *::after { box-sizing:border-box; margin:0; padding:0; }
.te-page { font-family:var(--te-sans); background:var(--te-midnight); color:var(--te-white); overflow-x:hidden; }
.te-page a { color:inherit; text-decoration:none; }
.te-page button { cursor:pointer; border:none; background:none; font-family:inherit; }

/* ════════════════════════════════════════════════════════
   LAYOUT
════════════════════════════════════════════════════════ */
.te-wrap { max-width:1200px; margin:0 auto; padding:0 2rem; }
.te-wrap--wide { max-width:1400px; margin:0 auto; padding:0 2rem; }
.te-section { padding:6rem 0; }
.te-section--alt  { background:var(--te-dark); }
.te-section--panel { background:var(--te-panel); }

.te-eyebrow {
  font-family:var(--te-mono); font-size:.72rem; letter-spacing:.2em;
  text-transform:uppercase; color:var(--te-electric); margin-bottom:.75rem;
  display:flex; align-items:center; gap:.5rem;
}
.te-eyebrow::before { content:'//'; opacity:.5; }
.te-h1 { font-family:var(--te-sans); font-size:clamp(2.6rem,5.5vw,4.8rem); font-weight:700; line-height:1.08; letter-spacing:-.02em; }
.te-h2 { font-family:var(--te-sans); font-size:clamp(1.8rem,3.5vw,3rem); font-weight:700; line-height:1.15; letter-spacing:-.015em; }
.te-h3 { font-family:var(--te-sans); font-size:1.25rem; font-weight:600; }
.te-lead { font-size:1.1rem; font-weight:300; line-height:1.75; color:var(--te-muted); max-width:60ch; }

.te-btn {
  display:inline-flex; align-items:center; gap:.5rem;
  padding:.8rem 1.8rem; border-radius:var(--te-r);
  font-family:var(--te-sans); font-size:.85rem; font-weight:600; letter-spacing:.02em;
  transition:var(--te-trans);
}
.te-btn--primary { background:var(--te-electric); color:var(--te-midnight); }
.te-btn--primary:hover { background:#00F0FF; box-shadow:var(--te-glow-e); }
.te-btn--violet { background:var(--te-violet); color:#fff; }
.te-btn--violet:hover { background:#8B44F5; box-shadow:var(--te-glow-v); }
.te-btn--outline { border:1px solid var(--te-border); color:var(--te-muted); }
.te-btn--outline:hover { border-color:var(--te-electric); color:var(--te-electric); }

/* reveal */
.te-reveal { opacity:0; transform:translateY(20px); transition:opacity .6s ease, transform .6s ease; }
.te-reveal.te-visible { opacity:1; transform:none; }

/* ════════════════════════════════════════════════════════
   NAV
════════════════════════════════════════════════════════ */
.te-nav {
  position:fixed; top:0; left:0; right:0; z-index:100;
  display:flex; align-items:center; justify-content:space-between;
  padding:1.1rem 3rem;
  background:rgba(10,14,26,.9);
  backdrop-filter:blur(16px);
  border-bottom:1px solid var(--te-border);
}
.te-nav__logo {
  font-family:var(--te-mono); font-size:1.1rem; font-weight:500;
  color:var(--te-white); letter-spacing:.02em;
}
.te-nav__logo span { color:var(--te-electric); }
.te-nav__links { display:flex; gap:2rem; list-style:none; }
.te-nav__links a { font-size:.82rem; font-weight:500; color:var(--te-muted); transition:color .25s; }
.te-nav__links a:hover { color:var(--te-electric); }
.te-nav__badge {
  font-family:var(--te-mono); font-size:.65rem; letter-spacing:.1em;
  padding:.2rem .6rem; border-radius:3px;
  background:rgba(0,212,255,.12); color:var(--te-electric);
  border:1px solid rgba(0,212,255,.25);
}
.te-nav__actions { display:flex; gap:.75rem; align-items:center; }

/* ════════════════════════════════════════════════════════
   HERO
════════════════════════════════════════════════════════ */
.te-hero {
  min-height:100vh; padding-top:80px;
  display:flex; flex-direction:column; justify-content:center;
  position:relative; overflow:hidden;
  background:radial-gradient(ellipse at 25% 60%, rgba(124,58,237,.18) 0%, transparent 55%),
             radial-gradient(ellipse at 75% 30%, rgba(0,212,255,.12) 0%, transparent 50%),
             var(--te-midnight);
}

/* network graph background */
.te-hero__graph {
  position:absolute; inset:0; overflow:hidden; pointer-events:none;
}
.te-graph-svg { width:100%; height:100%; }

/* hero grid */
.te-hero__inner {
  display:grid; grid-template-columns:1fr 1fr;
  align-items:center; gap:4rem;
  position:relative; z-index:2;
  padding:4rem 0;
}
.te-hero__left {}
.te-hero__prompt {
  font-family:var(--te-mono); font-size:.8rem; color:var(--te-electric);
  margin-bottom:1.5rem; display:flex; align-items:center; gap:.5rem;
}
.te-hero__prompt::before { content:'> '; }
.te-hero__prompt .te-cursor {
  display:inline-block; width:9px; height:1.1em;
  background:var(--te-electric); animation:te-blink .8s step-end infinite;
  vertical-align:middle;
}
@keyframes te-blink { 0%,100%{opacity:1} 50%{opacity:0} }
.te-hero__left .te-h1 { margin-bottom:1.5rem; }
.te-hero__left .te-lead { margin-bottom:2.5rem; }
.te-hero__actions { display:flex; gap:1rem; flex-wrap:wrap; margin-bottom:2.5rem; }
.te-hero__metrics {
  display:flex; gap:2rem;
  padding-top:2rem; border-top:1px solid var(--te-border);
}
.te-hero__metric {}
.te-hero__metric-val {
  font-family:var(--te-mono); font-size:1.5rem; font-weight:500;
  color:var(--te-electric); line-height:1; display:block; margin-bottom:.2rem;
}
.te-hero__metric-label { font-size:.7rem; letter-spacing:.12em; text-transform:uppercase; color:var(--te-slate); }

/* CSS terminal / dashboard panel (right) */
.te-hero__right { position:relative; }
.te-terminal {
  background:rgba(22,29,46,.9);
  border:1px solid var(--te-border);
  border-radius:10px;
  overflow:hidden;
  box-shadow:0 0 0 1px rgba(0,212,255,.08), 0 32px 80px rgba(0,0,0,.6);
}
.te-terminal__bar {
  background:rgba(255,255,255,.04);
  padding:.7rem 1rem;
  display:flex; align-items:center; gap:.5rem;
  border-bottom:1px solid var(--te-border);
}
.te-terminal__dot {
  width:10px; height:10px; border-radius:50%;
}
.te-terminal__dot--r { background:#FF5F57; }
.te-terminal__dot--y { background:#FFBD2E; }
.te-terminal__dot--g { background:#28C840; }
.te-terminal__title {
  font-family:var(--te-mono); font-size:.72rem; color:var(--te-slate);
  margin-left:auto; margin-right:auto;
}
.te-terminal__body { padding:1.5rem; font-family:var(--te-mono); font-size:.78rem; line-height:1.7; }
.te-t-line { display:flex; gap:.75rem; }
.te-t-prompt { color:var(--te-electric); flex-shrink:0; }
.te-t-cmd { color:#E2E8F0; }
.te-t-comment { color:var(--te-slate); }
.te-t-output { color:var(--te-lime); padding-left:1.5rem; }
.te-t-output--muted { color:var(--te-muted); padding-left:1.5rem; }
.te-t-output--err { color:#F87171; padding-left:1.5rem; }
.te-t-spacer { height:.5rem; }
/* metrics inside terminal */
.te-term-metrics {
  margin-top:1rem; padding-top:1rem;
  border-top:1px solid var(--te-border);
  display:grid; grid-template-columns:1fr 1fr; gap:.75rem;
}
.te-term-kpi {
  background:rgba(0,212,255,.06);
  border:1px solid rgba(0,212,255,.15);
  border-radius:4px; padding:.5rem .75rem;
}
.te-term-kpi__val { font-size:1.1rem; font-weight:500; color:var(--te-electric); display:block; }
.te-term-kpi__label { font-size:.65rem; color:var(--te-slate); text-transform:uppercase; letter-spacing:.1em; }
/* mini chart in terminal */
.te-term-chart { margin-top:.75rem; }
.te-term-chart-label { font-size:.65rem; color:var(--te-slate); margin-bottom:.3rem; }
.te-term-bars { display:flex; align-items:flex-end; gap:3px; height:36px; }
.te-term-bar {
  flex:1; border-radius:2px 2px 0 0;
  background:linear-gradient(180deg, var(--te-electric) 0%, rgba(0,212,255,.3) 100%);
  transition:opacity .25s;
}

/* floating badges */
.te-hero__badge {
  position:absolute;
  background:rgba(22,29,46,.95);
  border:1px solid var(--te-border);
  border-radius:8px; padding:.6rem 1rem;
  font-family:var(--te-mono); font-size:.7rem;
  box-shadow:0 8px 24px rgba(0,0,0,.4);
  white-space:nowrap;
  animation:te-float 3.5s ease-in-out infinite;
}
.te-hero__badge--a { top:-24px; right:20px; animation-delay:0s; }
.te-hero__badge--b { bottom:30px; left:-20px; animation-delay:.8s; }
.te-hero__badge .te-dot {
  display:inline-block; width:7px; height:7px; border-radius:50%;
  background:var(--te-lime); margin-right:.4rem;
  animation:te-pulse 1.5s ease infinite;
}
@keyframes te-float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-6px)} }
@keyframes te-pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:.6;transform:scale(.85)} }

/* ════════════════════════════════════════════════════════
   LOGO STRIP
════════════════════════════════════════════════════════ */
.te-logos {
  padding:2.5rem 0; border-top:1px solid var(--te-border); border-bottom:1px solid var(--te-border);
  background:var(--te-dark);
}
.te-logos__label { text-align:center; font-family:var(--te-mono); font-size:.65rem; letter-spacing:.15em; text-transform:uppercase; color:var(--te-slate); margin-bottom:1.5rem; }
.te-logos__row { display:flex; justify-content:center; align-items:center; gap:3rem; flex-wrap:wrap; }
.te-logo-pill {
  font-family:var(--te-mono); font-size:.78rem; color:var(--te-slate);
  padding:.4rem 1rem; border:1px solid var(--te-border); border-radius:20px;
  transition:var(--te-trans);
}
.te-logo-pill:hover { border-color:var(--te-electric); color:var(--te-electric); }

/* ════════════════════════════════════════════════════════
   STATS
════════════════════════════════════════════════════════ */
.te-stats { display:grid; grid-template-columns:repeat(4,1fr); }
.te-stat {
  padding:3rem 2rem; text-align:center;
  border-right:1px solid var(--te-border);
  position:relative; overflow:hidden;
}
.te-stat:last-child { border-right:none; }
.te-stat::before {
  content:''; position:absolute; top:0; left:0; right:0; height:2px;
  background:linear-gradient(90deg, var(--te-violet), var(--te-electric));
  transform:scaleX(0); transition:transform .4s; transform-origin:left;
}
.te-stat:hover::before { transform:scaleX(1); }
.te-stat__num {
  font-family:var(--te-mono); font-size:2.8rem; font-weight:500;
  color:var(--te-white); line-height:1; display:block; margin-bottom:.35rem;
}
.te-stat__num .te-accent { color:var(--te-electric); }
.te-stat__label { font-size:.7rem; letter-spacing:.15em; text-transform:uppercase; color:var(--te-slate); }

/* ════════════════════════════════════════════════════════
   SERVICES
════════════════════════════════════════════════════════ */
.te-services { display:grid; grid-template-columns:repeat(3,1fr); gap:1px; background:var(--te-border); }
.te-service {
  background:var(--te-panel); padding:2.5rem;
  position:relative; overflow:hidden;
  transition:background .3s;
}
.te-service:hover { background:rgba(22,29,46,.8); }
.te-service::after {
  content:''; position:absolute; bottom:0; left:0;
  width:0; height:2px;
  background:linear-gradient(90deg, var(--te-electric), var(--te-violet));
  transition:width .4s;
}
.te-service:hover::after { width:100%; }
.te-service__tag {
  font-family:var(--te-mono); font-size:.6rem; letter-spacing:.1em; text-transform:uppercase;
  padding:.2rem .55rem; border-radius:3px;
  background:rgba(163,230,53,.12); color:var(--te-lime);
  border:1px solid rgba(163,230,53,.25);
  display:inline-block; margin-bottom:1rem;
}
.te-service__icon { font-size:1.6rem; margin-bottom:1rem; display:block; }
.te-service__title { color:var(--te-white); margin-bottom:.75rem; }
.te-service__text { font-size:.88rem; line-height:1.7; color:var(--te-muted); }

/* ════════════════════════════════════════════════════════
   STACK / TECH
════════════════════════════════════════════════════════ */
.te-stack { display:grid; grid-template-columns:1fr 1fr; gap:4rem; align-items:start; }
.te-stack__left .te-h2 { margin-bottom:1rem; }
.te-stack__left .te-lead { margin-bottom:2rem; }
.te-stack__cats { display:flex; flex-direction:column; gap:1.5rem; }
.te-stack-cat__label {
  font-family:var(--te-mono); font-size:.68rem; letter-spacing:.12em; text-transform:uppercase;
  color:var(--te-slate); margin-bottom:.6rem;
}
.te-stack-cat__pills { display:flex; flex-wrap:wrap; gap:.4rem; }
.te-pill {
  font-family:var(--te-mono); font-size:.72rem;
  padding:.3rem .7rem; border-radius:4px;
  background:rgba(255,255,255,.05); border:1px solid var(--te-border);
  color:var(--te-muted); transition:var(--te-trans);
}
.te-pill:hover { border-color:var(--te-electric); color:var(--te-electric); background:rgba(0,212,255,.06); }
/* code snippet panel */
.te-code-panel {
  background:var(--te-panel); border:1px solid var(--te-border);
  border-radius:8px; overflow:hidden;
}
.te-code-panel__bar {
  background:rgba(255,255,255,.03); border-bottom:1px solid var(--te-border);
  padding:.6rem 1rem; display:flex; align-items:center; gap:.5rem;
}
.te-code-panel__lang {
  font-family:var(--te-mono); font-size:.65rem; letter-spacing:.1em; text-transform:uppercase;
  color:var(--te-electric); margin-left:auto;
}
.te-code-panel__body { padding:1.5rem; font-family:var(--te-mono); font-size:.77rem; line-height:1.8; }
.te-kw  { color:#C084FC; }  /* keyword */
.te-fn  { color:#60A5FA; }  /* function */
.te-str { color:var(--te-lime); }
.te-num { color:#FB923C; }
.te-cmt { color:var(--te-slate); font-style:italic; }
.te-var { color:var(--te-electric); }
.te-op  { color:var(--te-muted); }

/* ════════════════════════════════════════════════════════
   CASE STUDIES
════════════════════════════════════════════════════════ */
.te-cases { display:grid; grid-template-columns:repeat(3,1fr); gap:1.5rem; }
.te-case {
  background:var(--te-panel); border:1px solid var(--te-border);
  border-radius:8px; padding:2rem;
  transition:var(--te-trans); position:relative; overflow:hidden;
}
.te-case::before {
  content:''; position:absolute; inset:0;
  background:linear-gradient(135deg, rgba(0,212,255,.04) 0%, transparent 50%);
  opacity:0; transition:opacity .3s;
}
.te-case:hover::before { opacity:1; }
.te-case:hover { border-color:rgba(0,212,255,.3); transform:translateY(-3px); }
.te-case__sector {
  font-family:var(--te-mono); font-size:.62rem; letter-spacing:.12em; text-transform:uppercase;
  color:var(--te-slate); margin-bottom:1rem;
}
.te-case__title { color:var(--te-white); margin-bottom:.75rem; font-size:1.15rem; }
.te-case__text { font-size:.85rem; line-height:1.7; color:var(--te-muted); margin-bottom:1.5rem; }
.te-case__metrics { display:flex; gap:1.5rem; padding-top:1rem; border-top:1px solid var(--te-border); }
.te-case__metric-val { font-family:var(--te-mono); font-size:1.3rem; color:var(--te-electric); display:block; }
.te-case__metric-label { font-size:.65rem; color:var(--te-slate); letter-spacing:.08em; text-transform:uppercase; }

/* ════════════════════════════════════════════════════════
   PROCESS (timeline)
════════════════════════════════════════════════════════ */
.te-process { display:grid; grid-template-columns:repeat(4,1fr); gap:2rem; position:relative; }
.te-process::before {
  content:''; position:absolute; top:28px; left:0; right:0; height:1px;
  background:linear-gradient(90deg, var(--te-electric), var(--te-violet), transparent);
}
.te-proc-step { position:relative; }
.te-proc-step__num {
  width:56px; height:56px; border-radius:50%;
  display:flex; align-items:center; justify-content:center;
  font-family:var(--te-mono); font-size:.85rem; font-weight:500;
  background:var(--te-panel); border:1px solid var(--te-electric);
  color:var(--te-electric); margin-bottom:1.2rem; position:relative; z-index:1;
}
.te-proc-step__title { color:var(--te-white); margin-bottom:.5rem; font-size:.95rem; }
.te-proc-step__text { font-size:.82rem; line-height:1.6; color:var(--te-muted); }

/* ════════════════════════════════════════════════════════
   PACKAGES
════════════════════════════════════════════════════════ */
.te-packages { display:grid; grid-template-columns:repeat(3,1fr); gap:1.5rem; }
.te-pkg {
  background:var(--te-panel); border:1px solid var(--te-border);
  border-radius:10px; padding:2.5rem;
  position:relative; transition:var(--te-trans);
}
.te-pkg:hover { border-color:rgba(0,212,255,.3); box-shadow:0 0 40px rgba(0,212,255,.08); }
.te-pkg--featured {
  border-color:var(--te-electric);
  background:linear-gradient(135deg, rgba(0,212,255,.06) 0%, rgba(124,58,237,.06) 100%);
  transform:scale(1.04);
}
.te-pkg__badge {
  position:absolute; top:-1px; left:50%; transform:translateX(-50%);
  background:var(--te-electric); color:var(--te-midnight);
  font-family:var(--te-mono); font-size:.62rem; font-weight:700; letter-spacing:.12em; text-transform:uppercase;
  padding:.25rem 1rem; border-radius:0 0 6px 6px;
}
.te-pkg__tier { font-family:var(--te-mono); font-size:.7rem; color:var(--te-electric); letter-spacing:.15em; text-transform:uppercase; margin-bottom:.75rem; }
.te-pkg__name { font-size:1.4rem; font-weight:700; color:var(--te-white); margin-bottom:.5rem; }
.te-pkg__desc { font-size:.82rem; color:var(--te-muted); line-height:1.6; margin-bottom:1.5rem; }
.te-pkg__price { font-family:var(--te-mono); font-size:2.5rem; font-weight:500; color:var(--te-white); line-height:1; }
.te-pkg__price sup { font-size:1.1rem; vertical-align:super; }
.te-pkg__price sub { font-size:.85rem; color:var(--te-muted); }
.te-pkg__sep { height:1px; background:var(--te-border); margin:1.5rem 0; }
.te-pkg__features { list-style:none; display:flex; flex-direction:column; gap:.55rem; margin-bottom:2rem; }
.te-pkg__feature { font-size:.83rem; color:var(--te-muted); display:flex; gap:.6rem; align-items:flex-start; }
.te-pkg__feature::before { content:'→'; color:var(--te-electric); flex-shrink:0; }

/* ════════════════════════════════════════════════════════
   TESTIMONIALS
════════════════════════════════════════════════════════ */
.te-testis { display:grid; grid-template-columns:repeat(3,1fr); gap:1.5rem; }
.te-testi {
  background:var(--te-panel); border:1px solid var(--te-border);
  border-radius:8px; padding:2rem; position:relative;
}
.te-testi__quote {
  font-family:var(--te-mono); font-size:2.5rem; color:var(--te-electric);
  opacity:.25; line-height:1; margin-bottom:.5rem;
}
.te-testi__text { font-size:.88rem; line-height:1.8; color:var(--te-muted); margin-bottom:1.5rem; }
.te-testi__author { display:flex; align-items:center; gap:.75rem; }
.te-testi__avatar {
  width:36px; height:36px; border-radius:6px;
  display:flex; align-items:center; justify-content:center;
  font-family:var(--te-mono); font-size:.85rem; font-weight:500;
  flex-shrink:0; color:var(--te-midnight);
}
.te-testi__name { font-size:.9rem; font-weight:600; color:var(--te-white); display:block; }
.te-testi__role { font-family:var(--te-mono); font-size:.65rem; color:var(--te-slate); }

/* ════════════════════════════════════════════════════════
   FAQ
════════════════════════════════════════════════════════ */
.te-faq-list { max-width:820px; margin:0 auto; }
.te-faq { border-bottom:1px solid var(--te-border); }
.te-faq__q {
  width:100%; display:flex; justify-content:space-between; align-items:center;
  padding:1.3rem 0;
  font-size:1rem; font-weight:500; color:var(--te-white);
  text-align:left; transition:color .25s;
  background:none; border:none;
}
.te-faq__q:hover { color:var(--te-electric); }
.te-faq__icon {
  font-family:var(--te-mono); font-size:1rem; color:var(--te-electric);
  flex-shrink:0; transition:transform .3s;
}
.te-faq.te-open .te-faq__icon { transform:rotate(45deg); }
.te-faq__a { max-height:0; overflow:hidden; transition:max-height .4s ease; }
.te-faq__a-inner { padding-bottom:1.2rem; font-size:.88rem; line-height:1.75; color:var(--te-muted); }

/* ════════════════════════════════════════════════════════
   CTA BANNER
════════════════════════════════════════════════════════ */
.te-cta {
  text-align:center; padding:7rem 0;
  background:radial-gradient(ellipse at center, rgba(124,58,237,.18) 0%, transparent 70%),
             var(--te-dark);
  border-top:1px solid var(--te-border);
}
.te-cta .te-h2 { margin-bottom:1.2rem; }
.te-cta .te-lead { margin:0 auto 2.5rem; }
.te-cta__actions { display:flex; gap:1rem; justify-content:center; }

/* ════════════════════════════════════════════════════════
   CONTACT FORM
════════════════════════════════════════════════════════ */
.te-contact-grid { display:grid; grid-template-columns:1fr 1fr; gap:5rem; align-items:start; }
.te-contact__info .te-h2 { margin-bottom:1rem; }
.te-contact__info .te-lead { margin-bottom:2rem; }
.te-contact__links { display:flex; flex-direction:column; gap:1rem; }
.te-contact__link {
  display:flex; gap:1rem; align-items:center;
  padding:1rem 1.25rem;
  background:var(--te-panel); border:1px solid var(--te-border); border-radius:6px;
  transition:var(--te-trans);
}
.te-contact__link:hover { border-color:var(--te-electric); }
.te-contact__link-icon { font-size:1.1rem; }
.te-contact__link-label { font-family:var(--te-mono); font-size:.65rem; color:var(--te-slate); text-transform:uppercase; letter-spacing:.1em; display:block; }
.te-contact__link-val { font-size:.9rem; color:var(--te-white); }

.te-form { display:flex; flex-direction:column; gap:1.1rem; }
.te-form-row { display:grid; grid-template-columns:1fr 1fr; gap:1.1rem; }
.te-field { display:flex; flex-direction:column; gap:.35rem; }
.te-label { font-family:var(--te-mono); font-size:.65rem; letter-spacing:.1em; text-transform:uppercase; color:var(--te-slate); }
.te-input, .te-select, .te-textarea {
  width:100%; padding:.8rem 1rem;
  background:var(--te-panel); border:1px solid var(--te-border);
  border-radius:var(--te-r); color:var(--te-white);
  font-family:var(--te-sans); font-size:.9rem;
  transition:border-color .25s; appearance:none;
}
.te-input::placeholder { color:var(--te-slate); }
.te-input:focus, .te-select:focus, .te-textarea:focus {
  outline:none; border-color:var(--te-electric);
  box-shadow:0 0 0 3px rgba(0,212,255,.1);
}
.te-select option { background:var(--te-dark); }
.te-textarea { resize:vertical; min-height:110px; }

/* ════════════════════════════════════════════════════════
   FOOTER
════════════════════════════════════════════════════════ */
.te-footer {
  background:var(--te-midnight);
  border-top:1px solid var(--te-border);
  padding:4rem 0 2rem;
}
.te-footer__top { display:grid; grid-template-columns:2fr 1fr 1fr 1fr; gap:3rem; margin-bottom:3rem; }
.te-footer__brand p { font-size:.83rem; line-height:1.7; color:var(--te-slate); max-width:32ch; margin-top:1rem; }
.te-footer__col-title { font-family:var(--te-mono); font-size:.65rem; letter-spacing:.15em; text-transform:uppercase; color:var(--te-electric); margin-bottom:.75rem; }
.te-footer__links { list-style:none; display:flex; flex-direction:column; gap:.45rem; }
.te-footer__links a { font-size:.83rem; color:var(--te-slate); transition:color .25s; }
.te-footer__links a:hover { color:var(--te-electric); }
.te-footer__bottom {
  padding-top:2rem; border-top:1px solid var(--te-border);
  display:flex; justify-content:space-between; align-items:center;
  font-family:var(--te-mono); font-size:.7rem; color:var(--te-slate);
}

/* ════════════════════════════════════════════════════════
   RESPONSIVE
════════════════════════════════════════════════════════ */
@media(max-width:1024px){
  .te-hero__inner { grid-template-columns:1fr; gap:3rem; }
  .te-services { grid-template-columns:repeat(2,1fr); }
  .te-stack { grid-template-columns:1fr; }
  .te-cases { grid-template-columns:1fr 1fr; }
  .te-packages { grid-template-columns:1fr; }
  .te-pkg--featured { transform:none; }
  .te-testis { grid-template-columns:1fr; }
  .te-contact-grid { grid-template-columns:1fr; }
  .te-footer__top { grid-template-columns:1fr 1fr; }
}
@media(max-width:768px){
  .te-nav__links, .te-nav__badge { display:none; }
  .te-stats { grid-template-columns:repeat(2,1fr); }
  .te-services { grid-template-columns:1fr; }
  .te-cases { grid-template-columns:1fr; }
  .te-process { grid-template-columns:repeat(2,1fr); }
  .te-process::before { display:none; }
  .te-form-row { grid-template-columns:1fr; }
  .te-footer__top { grid-template-columns:1fr; }
  .te-footer__bottom { flex-direction:column; gap:.5rem; }
}
</style>

<div class="te-page">

<!-- NAV ────────────────────────────────────────────────── -->
<nav class="te-nav" role="navigation" aria-label="<?php esc_attr_e('Main navigation','themeflex'); ?>">
  <a href="<?php echo esc_url(home_url('/')); ?>" class="te-nav__logo">nexus<span>.</span>labs</a>
  <ul class="te-nav__links">
    <li><a href="#services"><?php esc_html_e('Services','themeflex'); ?></a></li>
    <li><a href="#stack"><?php esc_html_e('Stack','themeflex'); ?></a></li>
    <li><a href="#cases"><?php esc_html_e('Work','themeflex'); ?></a></li>
    <li><a href="#packages"><?php esc_html_e('Pricing','themeflex'); ?></a></li>
    <li><a href="#contact"><?php esc_html_e('Contact','themeflex'); ?></a></li>
  </ul>
  <div class="te-nav__actions">
    <span class="te-nav__badge"><?php esc_html_e('Now hiring SRE →','themeflex'); ?></span>
    <a href="#contact" class="te-btn te-btn--primary"><?php esc_html_e('Start a Project','themeflex'); ?></a>
  </div>
</nav>

<!-- HERO ────────────────────────────────────────────────── -->
<section class="te-hero" aria-label="<?php esc_attr_e('Hero','themeflex'); ?>">
  <!-- network graph background -->
  <div class="te-hero__graph" aria-hidden="true">
    <svg class="te-graph-svg" viewBox="0 0 100 100" preserveAspectRatio="none">
      <?php
      // draw edges between nearby nodes
      for ($i = 0; $i < count($te_nodes); $i++) {
          for ($j = $i + 1; $j < count($te_nodes); $j++) {
              $dx = $te_nodes[$i]['x'] - $te_nodes[$j]['x'];
              $dy = $te_nodes[$i]['y'] - $te_nodes[$j]['y'];
              $d  = sqrt($dx*$dx + $dy*$dy);
              if ($d < 22) {
                  printf('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="rgba(0,212,255,%.2f)" stroke-width="0.15"/>',
                      $te_nodes[$i]['x'], $te_nodes[$i]['y'],
                      $te_nodes[$j]['x'], $te_nodes[$j]['y'],
                      max(0.04, 0.18 - $d/120)
                  );
              }
          }
      }
      foreach ($te_nodes as $n) {
          printf('<circle cx="%.1f" cy="%.1f" r="%d" fill="%s" opacity="0.55"/>',
              $n['x'], $n['y'], $n['r'], esc_attr($n['c'])
          );
      }
      ?>
    </svg>
  </div>

  <div class="te-wrap">
    <div class="te-hero__inner">
      <!-- left copy -->
      <div class="te-hero__left">
        <p class="te-eyebrow"><?php esc_html_e('Full-Stack Product Engineering','themeflex'); ?></p>
        <p class="te-hero__prompt"><?php esc_html_e('ship faster. scale smarter. break nothing.','themeflex'); ?><span class="te-cursor" aria-hidden="true"></span></p>
        <h1 class="te-h1"><?php esc_html_e('We Build Tech That','themeflex'); ?><br><span style="color:var(--te-electric)"><?php esc_html_e('Doesn\'t Break','themeflex'); ?></span><br><?php esc_html_e('Under Pressure','themeflex'); ?></h1>
        <p class="te-lead" style="margin:1.5rem 0 2rem;"><?php esc_html_e('Nexus Labs is a product engineering studio specialising in high-throughput platforms, AI integrations, and the kind of DevOps culture that lets teams deploy on a Friday without fear.','themeflex'); ?></p>
        <div class="te-hero__actions">
          <a href="#contact" class="te-btn te-btn--primary"><?php esc_html_e('Discuss Your Stack','themeflex'); ?></a>
          <a href="#cases"   class="te-btn te-btn--outline"><?php esc_html_e('See Case Studies','themeflex'); ?></a>
        </div>
        <div class="te-hero__metrics">
          <?php foreach ([['99.98%','Uptime SLA'],['<50ms','P99 Latency'],['10×/day','Deploy Frequency']] as [$v,$l]): ?>
          <div class="te-hero__metric">
            <span class="te-hero__metric-val"><?php echo esc_html($v); ?></span>
            <span class="te-hero__metric-label"><?php echo esc_html($l); ?></span>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- CSS terminal panel (right) -->
      <div class="te-hero__right" aria-hidden="true">
        <div class="te-hero__badge te-hero__badge--a">
          <span class="te-dot"></span><?php esc_html_e('Deployment successful — 14s ago','themeflex'); ?>
        </div>
        <div class="te-terminal">
          <div class="te-terminal__bar">
            <span class="te-terminal__dot te-terminal__dot--r"></span>
            <span class="te-terminal__dot te-terminal__dot--y"></span>
            <span class="te-terminal__dot te-terminal__dot--g"></span>
            <span class="te-terminal__title">nexus@prod ~ deploy.sh</span>
          </div>
          <div class="te-terminal__body">
            <div class="te-t-line"><span class="te-t-prompt">$</span><span class="te-t-cmd">git push origin main</span></div>
            <div class="te-t-line"><span class="te-t-output--muted">Enumerating objects: 24, done.</span></div>
            <div class="te-t-line"><span class="te-t-output--muted">Writing objects: 100% (24/24) ✓</span></div>
            <div class="te-t-spacer"></div>
            <div class="te-t-line"><span class="te-t-prompt">$</span><span class="te-t-cmd">kubectl rollout status deploy/api</span></div>
            <div class="te-t-line"><span class="te-t-output">✓ Waiting for rollout to finish…</span></div>
            <div class="te-t-line"><span class="te-t-output">✓ 3/3 replicas available</span></div>
            <div class="te-t-line"><span class="te-t-output">✓ deployment "api" successfully rolled out</span></div>
            <div class="te-t-spacer"></div>
            <div class="te-t-line"><span class="te-t-prompt">$</span><span class="te-t-cmd">./run-tests.sh --smoke</span></div>
            <div class="te-t-line"><span class="te-t-output">✓ 142/142 tests passed in 4.2s</span></div>
            <div class="te-t-line"><span class="te-t-output">✓ Zero regressions detected</span></div>
            <div class="te-t-spacer"></div>
            <div class="te-term-metrics">
              <div class="te-term-kpi"><span class="te-term-kpi__val">12.4k</span><span class="te-term-kpi__label">req/s</span></div>
              <div class="te-term-kpi"><span class="te-term-kpi__val">47ms</span><span class="te-term-kpi__label">p99</span></div>
            </div>
            <div class="te-term-chart">
              <div class="te-term-chart-label"><?php esc_html_e('API latency — last 7 days','themeflex'); ?></div>
              <div class="te-term-bars" aria-hidden="true">
                <?php foreach ([45,60,38,72,55,42,47] as $h): ?>
                <div class="te-term-bar" style="height:<?php echo esc_attr($h); ?>%;"></div>
                <?php endforeach; ?>
              </div>
            </div>
          </div>
        </div>
        <div class="te-hero__badge te-hero__badge--b">
          <span class="te-dot" style="background:var(--te-lime)"></span><?php esc_html_e('AI pipeline — 24k tokens/s','themeflex'); ?>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- LOGO STRIP ────────────────────────────────────────── -->
<div class="te-logos" aria-label="<?php esc_attr_e('Client companies','themeflex'); ?>">
  <div class="te-wrap">
    <p class="te-logos__label"><?php esc_html_e('Trusted by engineering teams at','themeflex'); ?></p>
    <div class="te-logos__row">
      <?php foreach (['Arcalo','Vantex','Stratum','Luma Health','Gridpoint','PaperTrail','Vault AI','Orbis'] as $l): ?>
      <span class="te-logo-pill"><?php echo esc_html($l); ?></span>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- STATS ────────────────────────────────────────────── -->
<section class="te-section te-section--panel" aria-label="<?php esc_attr_e('Key metrics','themeflex'); ?>">
  <div class="te-wrap">
    <div class="te-stats">
      <?php foreach ($te_stats as $i => [$num, $label]): ?>
      <div class="te-stat te-reveal" style="transition-delay:<?php echo $i * 0.08; ?>s">
        <span class="te-stat__num" data-target="<?php echo esc_attr(preg_replace('/[^0-9.]/','',$num)); ?>">0<span class="te-accent"><?php echo preg_replace('/[0-9.]+/','',$num); ?></span></span>
        <span class="te-stat__label"><?php echo esc_html($label); ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- SERVICES ────────────────────────────────────────── -->
<section id="services" class="te-section" aria-labelledby="te-svc-title">
  <div class="te-wrap">
    <header style="margin-bottom:3rem;" class="te-reveal">
      <p class="te-eyebrow"><?php esc_html_e('Capabilities','themeflex'); ?></p>
      <h2 class="te-h2" id="te-svc-title"><?php esc_html_e('What We Build','themeflex'); ?></h2>
      <p class="te-lead" style="margin-top:.75rem;"><?php esc_html_e('Deep expertise across the full product engineering stack — infrastructure, application, AI, and everything in between.','themeflex'); ?></p>
    </header>
    <div class="te-services">
      <?php foreach ($te_services as $i => [$icon, $title, $text, $tag]): ?>
      <div class="te-service te-reveal" style="transition-delay:<?php echo $i * 0.07; ?>s">
        <?php if (!empty($tag)): ?>
        <span class="te-service__tag"><?php echo esc_html($tag); ?></span>
        <?php else: ?>
        <div style="height:1.6rem;margin-bottom:1rem;"></div>
        <?php endif; ?>
        <span class="te-service__icon" aria-hidden="true"><?php echo $icon; ?></span>
        <h3 class="te-service__title"><?php echo esc_html($title); ?></h3>
        <p class="te-service__text"><?php echo esc_html($text); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- TECH STACK ────────────────────────────────────────── -->
<section id="stack" class="te-section te-section--alt" aria-labelledby="te-stack-title">
  <div class="te-wrap">
    <div class="te-stack">
      <div class="te-stack__left te-reveal">
        <p class="te-eyebrow"><?php esc_html_e('Technology','themeflex'); ?></p>
        <h2 class="te-h2" id="te-stack-title"><?php esc_html_e('Our Default Stack','themeflex'); ?></h2>
        <p class="te-lead"><?php esc_html_e('We\'re opinionated but not dogmatic. We default to battle-tested open tools and swap in the right choice for your constraints.','themeflex'); ?></p>
        <div class="te-stack__cats" style="margin-top:2rem;">
          <?php
          $te_cats = [
            'Infrastructure'    => ['AWS','GCP','Azure','Terraform','Pulumi','K8s','Helm','ArgoCD'],
            'Backend'           => ['Go','Python','Node.js','Rust','gRPC','GraphQL','PostgreSQL','Redis'],
            'Frontend'          => ['React','Next.js','TypeScript','Tailwind','Vite','Remix','Storybook'],
            'Data & AI'         => ['dbt','Airflow','Spark','Snowflake','OpenAI','LangChain','Pinecone'],
            'Observability'     => ['Datadog','Grafana','Prometheus','Jaeger','PagerDuty','OpenTelemetry'],
          ];
          foreach ($te_cats as $cat => $pills):
          ?>
          <div>
            <p class="te-stack-cat__label"><?php echo esc_html($cat); ?></p>
            <div class="te-stack-cat__pills">
              <?php foreach ($pills as $p): ?>
              <span class="te-pill"><?php echo esc_html($p); ?></span>
              <?php endforeach; ?>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <!-- code panel -->
      <div class="te-reveal" style="transition-delay:.12s">
        <div class="te-code-panel">
          <div class="te-code-panel__bar">
            <span class="te-terminal__dot te-terminal__dot--r"></span>
            <span class="te-terminal__dot te-terminal__dot--y"></span>
            <span class="te-terminal__dot te-terminal__dot--g"></span>
            <span class="te-code-panel__lang">TypeScript · api/routes/infer.ts</span>
          </div>
          <div class="te-code-panel__body">
<pre><span class="te-kw">import</span> <span class="te-op">{</span> <span class="te-var">OpenAI</span> <span class="te-op">}</span> <span class="te-kw">from</span> <span class="te-str">'openai'</span>
<span class="te-kw">import</span> <span class="te-op">{</span> <span class="te-var">RateLimiter</span> <span class="te-op">}</span> <span class="te-kw">from</span> <span class="te-str">'./middleware'</span>

<span class="te-kw">const</span> <span class="te-var">client</span> <span class="te-op">=</span> <span class="te-kw">new</span> <span class="te-fn">OpenAI</span><span class="te-op">({</span>
  <span class="te-var">apiKey</span><span class="te-op">:</span> <span class="te-var">process</span><span class="te-op">.</span><span class="te-var">env</span><span class="te-op">.</span><span class="te-var">OPENAI_KEY</span><span class="te-op">,</span>
  <span class="te-var">maxRetries</span><span class="te-op">:</span> <span class="te-num">3</span><span class="te-op">,</span>
<span class="te-op">})</span>

<span class="te-kw">export async function</span> <span class="te-fn">POST</span><span class="te-op">(</span><span class="te-var">req</span><span class="te-op">:</span> <span class="te-var">Request</span><span class="te-op">) {</span>
  <span class="te-kw">await</span> <span class="te-fn">RateLimiter</span><span class="te-op">.</span><span class="te-fn">check</span><span class="te-op">(</span><span class="te-var">req</span><span class="te-op">)</span>
  <span class="te-kw">const</span> <span class="te-op">{</span> <span class="te-var">prompt</span><span class="te-op">,</span> <span class="te-var">model</span> <span class="te-op">}</span> <span class="te-op">=</span> <span class="te-kw">await</span> <span class="te-var">req</span><span class="te-op">.</span><span class="te-fn">json</span><span class="te-op">()</span>

  <span class="te-kw">const</span> <span class="te-var">stream</span> <span class="te-op">=</span> <span class="te-kw">await</span> <span class="te-var">client</span><span class="te-op">.</span><span class="te-var">chat</span><span class="te-op">.</span>
    <span class="te-var">completions</span><span class="te-op">.</span><span class="te-fn">create</span><span class="te-op">({</span>
      <span class="te-var">model</span><span class="te-op">,</span> <span class="te-var">stream</span><span class="te-op">:</span> <span class="te-kw">true</span><span class="te-op">,</span>
      <span class="te-var">messages</span><span class="te-op">: [{</span> <span class="te-var">role</span><span class="te-op">:</span> <span class="te-str">'user'</span><span class="te-op">,</span> <span class="te-var">content</span><span class="te-op">:</span> <span class="te-var">prompt</span> <span class="te-op">}],</span>
    <span class="te-op">})</span>

  <span class="te-cmt">// stream SSE back to client</span>
  <span class="te-kw">return</span> <span class="te-fn">streamText</span><span class="te-op">(</span><span class="te-var">stream</span><span class="te-op">)</span>
<span class="te-op">}</span></pre>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- CASE STUDIES ────────────────────────────────────── -->
<section id="cases" class="te-section" aria-labelledby="te-cases-title">
  <div class="te-wrap">
    <header style="margin-bottom:3rem;" class="te-reveal">
      <p class="te-eyebrow"><?php esc_html_e('Case Studies','themeflex'); ?></p>
      <h2 class="te-h2" id="te-cases-title"><?php esc_html_e('Problems We\'ve Solved','themeflex'); ?></h2>
    </header>
    <div class="te-cases">
      <?php
      $te_cases = [
        ['FinTech','Zero-Downtime Core Banking Migration','Migrated a £3B/month payment processor off a legacy Oracle stack to Postgres + Go microservices without a single hour of downtime.','99.99%','Uptime','3.2×','Throughput'],
        ['Healthcare','HIPAA-Compliant AI Triage Platform','Built an LLM-powered clinical triage assistant that reduced nurse intake time by 68% while meeting full HIPAA and NHS DSPT standards.','68%','Time Saved','0','HIPAA breaches'],
        ['E-commerce','10M-SKU Real-Time Search Engine','Replaced Elasticsearch with a custom Rust + OpenSearch hybrid that cut p99 search latency from 420ms to 38ms at 30k req/s.','11×','Faster P99','£2.4M','Annual saving'],
      ];
      foreach ($te_cases as $i => [$sector, $title, $text, $v1, $l1, $v2, $l2]):
      ?>
      <div class="te-case te-reveal" style="transition-delay:<?php echo $i * 0.1; ?>s">
        <p class="te-case__sector"><?php echo esc_html($sector); ?></p>
        <h3 class="te-case__title"><?php echo esc_html($title); ?></h3>
        <p class="te-case__text"><?php echo esc_html($text); ?></p>
        <div class="te-case__metrics">
          <div>
            <span class="te-case__metric-val"><?php echo esc_html($v1); ?></span>
            <span class="te-case__metric-label"><?php echo esc_html($l1); ?></span>
          </div>
          <div>
            <span class="te-case__metric-val"><?php echo esc_html($v2); ?></span>
            <span class="te-case__metric-label"><?php echo esc_html($l2); ?></span>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- PROCESS ────────────────────────────────────────── -->
<section class="te-section te-section--panel" aria-labelledby="te-proc-title">
  <div class="te-wrap">
    <header style="text-align:center;margin-bottom:4rem;" class="te-reveal">
      <p class="te-eyebrow"><?php esc_html_e('Engagement','themeflex'); ?></p>
      <h2 class="te-h2" id="te-proc-title"><?php esc_html_e('How We Engage','themeflex'); ?></h2>
    </header>
    <div class="te-process">
      <?php
      $te_steps = [
        ['01','Discovery Sprint','A focused two-week engagement to map your architecture, constraints, and quick wins before any long-term commitment.'],
        ['02','RFC & Roadmap','We produce a detailed Request For Comments document covering architecture decisions, risk analysis, and a phased delivery roadmap.'],
        ['03','Build & Iterate','Embedded Nexus engineers join your team — two-week sprints, daily standups, live metrics dashboards, and weekly stakeholder updates.'],
        ['04','Handoff & Docs','Every engagement ends with full runbooks, architecture diagrams, post-mortems, and a knowledge-transfer sprint for your team.'],
      ];
      foreach ($te_steps as $i => [$num, $title, $text]):
      ?>
      <div class="te-proc-step te-reveal" style="transition-delay:<?php echo $i * 0.1; ?>s">
        <div class="te-proc-step__num"><?php echo esc_html($num); ?></div>
        <h3 class="te-proc-step__title"><?php echo esc_html($title); ?></h3>
        <p class="te-proc-step__text"><?php echo esc_html($text); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- PACKAGES ────────────────────────────────────────── -->
<section id="packages" class="te-section" aria-labelledby="te-pkg-title">
  <div class="te-wrap">
    <header style="text-align:center;margin-bottom:4rem;" class="te-reveal">
      <p class="te-eyebrow"><?php esc_html_e('Pricing','themeflex'); ?></p>
      <h2 class="te-h2" id="te-pkg-title"><?php esc_html_e('Transparent Engagement Models','themeflex'); ?></h2>
      <p class="te-lead" style="margin:1rem auto 0;"><?php esc_html_e('No surprise invoices. Pick the model that fits your stage and how you like to work.','themeflex'); ?></p>
    </header>
    <div class="te-packages">
      <?php
      $te_pkgs = [
        ['STARTER','Discovery Sprint','£12,000','one-time',
         'For teams that need architectural clarity before committing to a build.',
         false, null,
         ['2-week embedded engagement','Architecture review','RFC document','Risk register','30-day async follow-up']],
        ['SCALE','Embedded Team','£28,000','/ month',
         'Our most popular model — two senior engineers embedded in your team, full sprint cadence.',
         true,'Most Popular',
         ['2 senior engineers + 1 SRE','Two-week sprints','Weekly stakeholder demos','Architecture ownership','Security review included','Priority incident support']],
        ['ENTERPRISE','Dedicated Studio','Custom','pricing',
         'Full Nexus team dedicated to your product — ideal for scale-ups building platform infrastructure.',
         false, null,
         ['Full team allocation','Dedicated Slack channel','CTO-level advisory','SLA-backed delivery','Quarterly architecture summit','IP ownership options']],
      ];
      foreach ($te_pkgs as [$tier, $name, $price, $unit, $desc, $feat, $badge, $features]):
      ?>
      <div class="te-pkg te-reveal<?php echo $feat ? ' te-pkg--featured' : ''; ?>">
        <?php if ($badge): ?>
        <div class="te-pkg__badge"><?php echo esc_html($badge); ?></div>
        <?php endif; ?>
        <div class="te-pkg__tier"><?php echo esc_html($tier); ?></div>
        <div class="te-pkg__name"><?php echo esc_html($name); ?></div>
        <div class="te-pkg__desc"><?php echo esc_html($desc); ?></div>
        <div class="te-pkg__price"><?php if ($price !== 'Custom'): ?><sup>£</sup><?php echo esc_html(ltrim($price,'£')); ?><sub> / <?php echo esc_html($unit); ?></sub><?php else: echo esc_html($price); ?><?php endif; ?></div>
        <div class="te-pkg__sep"></div>
        <ul class="te-pkg__features">
          <?php foreach ($features as $f): ?>
          <li class="te-pkg__feature"><?php echo esc_html($f); ?></li>
          <?php endforeach; ?>
        </ul>
        <a href="#contact" class="te-btn <?php echo $feat ? 'te-btn--primary' : 'te-btn--outline'; ?>" style="width:100%;justify-content:center;"><?php esc_html_e('Enquire','themeflex'); ?></a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- TESTIMONIALS ──────────────────────────────────── -->
<section class="te-section te-section--alt" aria-labelledby="te-testi-title">
  <div class="te-wrap">
    <header style="margin-bottom:3rem;" class="te-reveal">
      <p class="te-eyebrow"><?php esc_html_e('Social Proof','themeflex'); ?></p>
      <h2 class="te-h2" id="te-testi-title"><?php esc_html_e('What CTOs Are Saying','themeflex'); ?></h2>
    </header>
    <div class="te-testis">
      <?php
      $te_testis = [
        ['#00D4FF','R','Ryan K.','CTO, Arcalo','Nexus shipped our entire data platform in eight weeks. It would have taken us six months to hire the equivalent. The code quality and docs they left behind are genuinely exceptional.'],
        ['#7C3AED','P','Priya S.','VP Engineering, Vantex','We had a critical latency issue killing conversion. Nexus diagnosed it in day one, had a fix in review by day three, and we\'ve never seen it again. Their SRE instincts are on another level.'],
        ['#A3E635','T','Tom W.','Founder, Luma Health','The AI triage system Nexus built for us went through NHS clinical safety review on first submission. That\'s unheard of for a third-party build. These engineers actually care about getting it right.'],
      ];
      foreach ($te_testis as $i => [$bg, $init, $name, $role, $text]):
      ?>
      <div class="te-testi te-reveal" style="transition-delay:<?php echo $i * 0.1; ?>s">
        <div class="te-testi__quote">"</div>
        <p class="te-testi__text"><?php echo esc_html($text); ?></p>
        <div class="te-testi__author">
          <div class="te-testi__avatar" style="background:<?php echo esc_attr($bg); ?>"><?php echo esc_html($init); ?></div>
          <div>
            <span class="te-testi__name"><?php echo esc_html($name); ?></span>
            <span class="te-testi__role"><?php echo esc_html($role); ?></span>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- FAQ ────────────────────────────────────────────── -->
<section class="te-section" aria-labelledby="te-faq-title">
  <div class="te-wrap">
    <header style="text-align:center;margin-bottom:3rem;" class="te-reveal">
      <p class="te-eyebrow"><?php esc_html_e('Questions','themeflex'); ?></p>
      <h2 class="te-h2" id="te-faq-title"><?php esc_html_e('Common Questions','themeflex'); ?></h2>
    </header>
    <div class="te-faq-list">
      <?php
      $te_faqs = [
        ['Do you work with early-stage startups or only scale-ups?','Both. For early-stage we typically start with a Discovery Sprint to establish architecture fundamentals — which prevents expensive rewrites at Series A. We\'ve worked with teams from pre-seed through to post-IPO.'],
        ['How embedded is "embedded"?','Very. Our engineers join your Slack, attend your standups, use your tooling, and sit in your sprint reviews. We operate as a member of your team, not a vendor on the other side of a ticket queue.'],
        ['Do you provide ongoing support after the engagement ends?','All engagements include 30 days of async support at no extra cost. For production systems we offer SLA-backed retainers covering incident response, on-call rotation, and quarterly architecture reviews.'],
        ['What happens if we exceed scope?','We operate on a change control process — any work outside the agreed RFC is priced and approved before it begins. No surprise invoices. We\'ve had clients for five years who\'ve never had a billing dispute.'],
        ['Can you help us hire and upskill our internal team?','Yes. Many engagements include embedded pair-programming and explicit knowledge transfer goals. We want your team to be self-sufficient, not dependent on us forever.'],
        ['Do you sign NDAs and work under our security policies?','Absolutely. We sign mutual NDAs before any scoping calls, hold Cyber Essentials Plus certification, and our engineers are DBS-checked for regulated industries.'],
      ];
      foreach ($te_faqs as $k => [$q, $a]):
        $faq_id = 'te-faq-'.$k;
      ?>
      <div class="te-faq" id="<?php echo esc_attr($faq_id); ?>">
        <button class="te-faq__q" aria-expanded="false" aria-controls="<?php echo esc_attr($faq_id.'-a'); ?>">
          <?php echo esc_html($q); ?>
          <span class="te-faq__icon" aria-hidden="true">+</span>
        </button>
        <div class="te-faq__a" id="<?php echo esc_attr($faq_id.'-a'); ?>" role="region">
          <p class="te-faq__a-inner"><?php echo esc_html($a); ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- CTA ────────────────────────────────────────────── -->
<section class="te-cta te-reveal" aria-labelledby="te-cta-title">
  <div class="te-wrap">
    <p class="te-eyebrow" style="justify-content:center;"><?php esc_html_e('Ship Something Great','themeflex'); ?></p>
    <h2 class="te-h2" id="te-cta-title"><?php esc_html_e('Ready to Talk Architecture?','themeflex'); ?></h2>
    <p class="te-lead"><?php esc_html_e('Drop us a message with your stack and your biggest pain point. Our CTO will respond within 24 hours — no SDRs, no call scheduling theatre.','themeflex'); ?></p>
    <div class="te-cta__actions">
      <a href="#contact" class="te-btn te-btn--primary"><?php esc_html_e('Get in Touch','themeflex'); ?></a>
      <a href="#cases"   class="te-btn te-btn--outline"><?php esc_html_e('More Case Studies','themeflex'); ?></a>
    </div>
  </div>
</section>

<!-- CONTACT ────────────────────────────────────────── -->
<section id="contact" class="te-section te-section--panel" aria-labelledby="te-contact-title">
  <div class="te-wrap">
    <div class="te-contact-grid">
      <div class="te-reveal">
        <p class="te-eyebrow"><?php esc_html_e('Contact','themeflex'); ?></p>
        <h2 class="te-h2" id="te-contact-title"><?php esc_html_e('Start a Conversation','themeflex'); ?></h2>
        <p class="te-lead"><?php esc_html_e('Describe your challenge and we\'ll match you with the right engagement. No commitments required.','themeflex'); ?></p>
        <div class="te-contact__links" style="margin-top:2rem;">
          <div class="te-contact__link">
            <span class="te-contact__link-icon">✉️</span>
            <div>
              <span class="te-contact__link-label"><?php esc_html_e('Email','themeflex'); ?></span>
              <span class="te-contact__link-val">hello@nexuslabs.io</span>
            </div>
          </div>
          <div class="te-contact__link">
            <span class="te-contact__link-icon">💬</span>
            <div>
              <span class="te-contact__link-label"><?php esc_html_e('Calendly','themeflex'); ?></span>
              <span class="te-contact__link-val"><?php esc_html_e('30-min architecture call — book instantly','themeflex'); ?></span>
            </div>
          </div>
          <div class="te-contact__link">
            <span class="te-contact__link-icon">📍</span>
            <div>
              <span class="te-contact__link-label"><?php esc_html_e('HQ','themeflex'); ?></span>
              <span class="te-contact__link-val"><?php esc_html_e('20 Ropemaker St, London EC2Y 9AR','themeflex'); ?></span>
            </div>
          </div>
        </div>
      </div>
      <div class="te-reveal" style="transition-delay:.12s">
        <form class="te-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" novalidate>
          <?php wp_nonce_field('tf_te_booking','tf_te_nonce'); ?>
          <input type="hidden" name="action" value="tf_te_enquiry">
          <div class="te-form-row">
            <div class="te-field">
              <label class="te-label" for="te-name"><?php esc_html_e('Your Name *','themeflex'); ?></label>
              <input class="te-input" id="te-name" name="name" type="text" required placeholder="<?php esc_attr_e('Alex Chen','themeflex'); ?>">
            </div>
            <div class="te-field">
              <label class="te-label" for="te-role"><?php esc_html_e('Your Role *','themeflex'); ?></label>
              <input class="te-input" id="te-role" name="role" type="text" required placeholder="<?php esc_attr_e('CTO / VP Eng','themeflex'); ?>">
            </div>
          </div>
          <div class="te-form-row">
            <div class="te-field">
              <label class="te-label" for="te-email"><?php esc_html_e('Work Email *','themeflex'); ?></label>
              <input class="te-input" id="te-email" name="email" type="email" required placeholder="<?php esc_attr_e('alex@company.io','themeflex'); ?>">
            </div>
            <div class="te-field">
              <label class="te-label" for="te-company"><?php esc_html_e('Company','themeflex'); ?></label>
              <input class="te-input" id="te-company" name="company" type="text" placeholder="<?php esc_attr_e('Acme Corp','themeflex'); ?>">
            </div>
          </div>
          <div class="te-field">
            <label class="te-label" for="te-interest"><?php esc_html_e('Primary Interest *','themeflex'); ?></label>
            <select class="te-select" id="te-interest" name="interest" required>
              <option value=""><?php esc_html_e('Select a service area…','themeflex'); ?></option>
              <option><?php esc_html_e('Platform Engineering','themeflex'); ?></option>
              <option><?php esc_html_e('AI / ML Integration','themeflex'); ?></option>
              <option><?php esc_html_e('Product Design & Development','themeflex'); ?></option>
              <option><?php esc_html_e('Security & Compliance','themeflex'); ?></option>
              <option><?php esc_html_e('Data Engineering','themeflex'); ?></option>
              <option><?php esc_html_e('DevOps & SRE','themeflex'); ?></option>
              <option><?php esc_html_e('Not sure — need a chat','themeflex'); ?></option>
            </select>
          </div>
          <div class="te-field">
            <label class="te-label" for="te-budget"><?php esc_html_e('Approximate Budget','themeflex'); ?></label>
            <select class="te-select" id="te-budget" name="budget">
              <option value=""><?php esc_html_e('Select range…','themeflex'); ?></option>
              <option><?php esc_html_e('Under £20,000','themeflex'); ?></option>
              <option><?php esc_html_e('£20,000 – £50,000','themeflex'); ?></option>
              <option><?php esc_html_e('£50,000 – £150,000','themeflex'); ?></option>
              <option><?php esc_html_e('£150,000+','themeflex'); ?></option>
            </select>
          </div>
          <div class="te-field">
            <label class="te-label" for="te-msg"><?php esc_html_e('Describe Your Challenge *','themeflex'); ?></label>
            <textarea class="te-textarea" id="te-msg" name="message" required rows="5" placeholder="<?php esc_attr_e('Tell us about your stack, the problem, and any constraints…','themeflex'); ?>"></textarea>
          </div>
          <button type="submit" class="te-btn te-btn--primary"><?php esc_html_e('Send Message','themeflex'); ?></button>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- FOOTER ────────────────────────────────────────── -->
<footer class="te-footer" role="contentinfo">
  <div class="te-wrap">
    <div class="te-footer__top">
      <div class="te-footer__brand">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="te-nav__logo">nexus<span>.</span>labs</a>
        <p><?php esc_html_e('Product engineering studio building high-throughput platforms, AI products, and the DevOps culture to support them.','themeflex'); ?></p>
      </div>
      <div>
        <p class="te-footer__col-title"><?php esc_html_e('Services','themeflex'); ?></p>
        <ul class="te-footer__links">
          <li><a href="#services"><?php esc_html_e('Platform Engineering','themeflex'); ?></a></li>
          <li><a href="#services"><?php esc_html_e('AI & Machine Learning','themeflex'); ?></a></li>
          <li><a href="#services"><?php esc_html_e('Product Design','themeflex'); ?></a></li>
          <li><a href="#services"><?php esc_html_e('Data Engineering','themeflex'); ?></a></li>
          <li><a href="#services"><?php esc_html_e('DevOps & SRE','themeflex'); ?></a></li>
        </ul>
      </div>
      <div>
        <p class="te-footer__col-title"><?php esc_html_e('Company','themeflex'); ?></p>
        <ul class="te-footer__links">
          <li><a href="#stack"><?php esc_html_e('Our Stack','themeflex'); ?></a></li>
          <li><a href="#cases"><?php esc_html_e('Case Studies','themeflex'); ?></a></li>
          <li><a href="<?php echo esc_url(home_url('/blog')); ?>"><?php esc_html_e('Engineering Blog','themeflex'); ?></a></li>
          <li><a href="<?php echo esc_url(home_url('/careers')); ?>"><?php esc_html_e('Careers','themeflex'); ?></a></li>
          <li><a href="#contact"><?php esc_html_e('Contact','themeflex'); ?></a></li>
        </ul>
      </div>
      <div>
        <p class="te-footer__col-title"><?php esc_html_e('Open Source','themeflex'); ?></p>
        <ul class="te-footer__links">
          <li><a href="#" rel="noopener noreferrer">GitHub</a></li>
          <li><a href="#" rel="noopener noreferrer">npm</a></li>
          <li><a href="#" rel="noopener noreferrer">Docker Hub</a></li>
          <li><a href="#" rel="noopener noreferrer">LinkedIn</a></li>
        </ul>
      </div>
    </div>
    <div class="te-footer__bottom">
      <span>&copy; <?php echo esc_html(date('Y')); ?> Nexus Labs Ltd. <?php esc_html_e('All rights reserved.','themeflex'); ?></span>
      <span><?php esc_html_e('Cyber Essentials Plus · SOC 2 Type II · GDPR Compliant','themeflex'); ?></span>
    </div>
  </div>
</footer>

</div><!-- /.te-page -->

<script>
(function(){
  'use strict';

  /* scroll reveal */
  var teObs = new IntersectionObserver(function(entries){
    entries.forEach(function(e){
      if(e.isIntersecting){ e.target.classList.add('te-visible'); teObs.unobserve(e.target); }
    });
  }, { threshold:0.12 });
  document.querySelectorAll('.te-reveal').forEach(function(el){ teObs.observe(el); });

  /* animated counters */
  var teEase = function(t){ return 1 - Math.pow(1-t,3); };
  var cntObs = new IntersectionObserver(function(entries){
    entries.forEach(function(e){
      if(!e.isIntersecting) return;
      var el  = e.target;
      var tgt = parseFloat(el.dataset.target);
      if(isNaN(tgt)) return;
      var acc = el.querySelector('.te-accent');
      var sfx = acc ? acc.textContent : '';
      var dur = 1400; var start;
      (function tick(ts){
        if(!start) start = ts;
        var p = Math.min((ts-start)/dur,1);
        var v = Math.round(teEase(p)*tgt * 100) / 100;
        el.textContent = v;
        if(sfx){ var sp=document.createElement('span'); sp.className='te-accent'; sp.textContent=sfx; el.appendChild(sp); }
        if(p<1) requestAnimationFrame(tick);
      })(performance.now());
      cntObs.unobserve(el);
    });
  }, { threshold:0.5 });
  document.querySelectorAll('.te-stat__num[data-target]').forEach(function(el){ cntObs.observe(el); });

  /* FAQ accordion */
  document.querySelectorAll('.te-faq__q').forEach(function(btn){
    btn.addEventListener('click', function(){
      var faq  = btn.closest('.te-faq');
      var ans  = faq.querySelector('.te-faq__a');
      var inn  = faq.querySelector('.te-faq__a-inner');
      var open = faq.classList.contains('te-open');
      document.querySelectorAll('.te-faq.te-open').forEach(function(f){
        f.querySelector('.te-faq__a').style.maxHeight='0';
        f.classList.remove('te-open');
        f.querySelector('.te-faq__q').setAttribute('aria-expanded','false');
      });
      if(!open){
        ans.style.maxHeight = inn.scrollHeight+'px';
        faq.classList.add('te-open');
        btn.setAttribute('aria-expanded','true');
      }
    });
  });

  /* sticky nav */
  var teNav = document.querySelector('.te-nav');
  window.addEventListener('scroll', function(){
    teNav.style.boxShadow = window.scrollY > 10 ? '0 4px 32px rgba(0,0,0,.5)' : '';
  }, { passive:true });

})();
</script>

<?php get_footer(); ?>
