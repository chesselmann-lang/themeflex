<?php
/**
 * Template Name: Travel — Luxury Travel Agency & Tour Operator
 *
 * Premium luxury travel agency page template.
 * Namespace : --trv-*
 * Fonts     : Freight Display Pro fallback → Libre Baskerville + Nunito Sans
 * Palette   : deep ocean #0b2545 · sand #e8d5b0 · coral #e07b5a · jade #2e7d6e · warm white #faf8f4
 *
 * @package ThemeFlex
 */

/* ── PHP seed data ─────────────────────────────────── */
srand( 77 );

// Star field for hero night sky
$stars = [];
for ( $i = 0; $i < 80; $i++ ) {
    $stars[] = [
        'x'    => rand( 0, 100 ),
        'y'    => rand( 0, 55 ),
        'r'    => rand( 1, 5 ) / 10,
        'op'   => rand( 20, 90 ) / 100,
        'dur'  => rand( 15, 50 ) / 10,
        'del'  => rand( 0, 80 ) / 10,
    ];
}

// Destinations
$destinations = [
    [
        'name'    => 'Kyoto, Japan',
        'tag'     => 'Culture & Tradition',
        'nights'  => '8 nights',
        'from'    => '3.480',
        'badge'   => 'Editor\'s Pick',
        'sky'     => '#1a0a2a',
        'land'    => '#2d1a3a',
        'acc'     => '#d4a8c8',
        'icon'    => '⛩',
    ],
    [
        'name'    => 'Amalfi Coast, Italy',
        'tag'     => 'Coastal Luxury',
        'nights'  => '10 nights',
        'from'    => '4.950',
        'badge'   => '',
        'sky'     => '#0b1f3a',
        'land'    => '#1a3050',
        'acc'     => '#4a90b8',
        'icon'    => '⛵',
    ],
    [
        'name'    => 'Marrakech, Morocco',
        'tag'     => 'Souks & Sahara',
        'nights'  => '7 nights',
        'from'    => '2.290',
        'badge'   => 'Bestseller',
        'sky'     => '#1a0f00',
        'land'    => '#3a2000',
        'acc'     => '#e07b5a',
        'icon'    => '🌴',
    ],
    [
        'name'    => 'Patagonia, Chile',
        'tag'     => 'Adventure & Wilderness',
        'nights'  => '12 nights',
        'from'    => '5.690',
        'badge'   => '',
        'sky'     => '#061525',
        'land'    => '#0d2535',
        'acc'     => '#5aaab0',
        'icon'    => '▲',
    ],
    [
        'name'    => 'Maldives',
        'tag'     => 'Overwater Paradise',
        'nights'  => '9 nights',
        'from'    => '6.200',
        'badge'   => 'Luxury',
        'sky'     => '#051520',
        'land'    => '#082030',
        'acc'     => '#40c8b0',
        'icon'    => '🐠',
    ],
    [
        'name'    => 'Santorini, Greece',
        'tag'     => 'Aegean Sunsets',
        'nights'  => '7 nights',
        'from'    => '3.100',
        'badge'   => '',
        'sky'     => '#10090a',
        'land'    => '#28121a',
        'acc'     => '#e88060',
        'icon'    => '◑',
    ],
];

// Tour packages
$tours = [
    [
        'cat'    => 'luxury',
        'title'  => 'Golden Triangle',
        'sub'    => 'India — 14 Days',
        'desc'   => 'Delhi, Agra, Jaipur — private guides, palace hotels, Taj Mahal at sunrise.',
        'price'  => '5.890',
        'dur'    => '14 days',
        'group'  => 'Max 8',
        'diff'   => '★★☆',
        'col'    => '#3a2010',
        'acc'    => '#e0a050',
    ],
    [
        'cat'    => 'adventure',
        'title'  => 'Inca Trail Express',
        'sub'    => 'Peru — 9 Days',
        'desc'   => 'Trek the classic Inca Trail to Machu Picchu with expert mountain guides.',
        'price'  => '3.290',
        'dur'    => '9 days',
        'group'  => 'Max 12',
        'diff'   => '★★★',
        'col'    => '#103020',
        'acc'    => '#50a870',
    ],
    [
        'cat'    => 'cultural',
        'title'  => 'Silk Road Journey',
        'sub'    => 'Uzbekistan — 12 Days',
        'desc'   => 'Samarkand, Bukhara, Khiva — caravanserais, mosaics and desert caravans.',
        'price'  => '4.100',
        'dur'    => '12 days',
        'group'  => 'Max 10',
        'diff'   => '★★☆',
        'col'    => '#1a0a20',
        'acc'    => '#8060c0',
    ],
    [
        'cat'    => 'luxury',
        'title'  => 'Japan in Full Bloom',
        'sub'    => 'Japan — 16 Days',
        'desc'   => 'Sakura season through Tokyo, Nikko, Hakone, Kyoto and Osaka in private style.',
        'price'  => '7.400',
        'dur'    => '16 days',
        'group'  => 'Max 6',
        'diff'   => '★☆☆',
        'col'    => '#1a0520',
        'acc'    => '#d070c0',
    ],
    [
        'cat'    => 'adventure',
        'title'  => 'Safari & Summit',
        'sub'    => 'Tanzania — 11 Days',
        'desc'   => 'Serengeti Big Five safari then a 6-day Kilimanjaro summit attempt.',
        'price'  => '5.600',
        'dur'    => '11 days',
        'group'  => 'Max 8',
        'diff'   => '★★★',
        'col'    => '#101a05',
        'acc'    => '#80b840',
    ],
    [
        'cat'    => 'cultural',
        'title'  => 'Ancient Kingdoms',
        'sub'    => 'Cambodia & Myanmar — 13 Days',
        'desc'   => 'Angkor Wat at dawn, Bagan by hot-air balloon, Inle Lake by long-tail boat.',
        'price'  => '3.950',
        'dur'    => '13 days',
        'group'  => 'Max 10',
        'diff'   => '★★☆',
        'col'    => '#1a1205',
        'acc'    => '#d4a040',
    ],
];

// Why us
$whys = [
    [ 'icon' => '◆', 'title' => 'Tailor-Made Only',     'desc' => 'No group tours, no fixed itineraries. Every journey is built from scratch around you.' ],
    [ 'icon' => '◉', 'title' => '24/7 On-Trip Support', 'desc' => 'A dedicated travel manager is reachable around the clock during every trip, wherever you are.' ],
    [ 'icon' => '▲', 'title' => 'Expert Local Guides',  'desc' => 'Our on-the-ground partners are vetted insiders — not off-the-shelf tour operators.' ],
    [ 'icon' => '◐', 'title' => 'B Corp Certified',     'desc' => 'We offset all flights, support local economies and partner only with ethical accommodation.' ],
];

// Testimonials
$testimonials = [
    [
        'name'   => 'Familie Schreiber',
        'route'  => 'Japan 16-Day Private Tour',
        'stars'  => 5,
        'quote'  => 'The cherry blossom timing was perfect — they somehow arranged access to a private temple garden for our family at dawn. An absolute dream that we will talk about forever.',
        'avatar' => 'FS',
        'col'    => '#d4a8c8',
    ],
    [
        'name'   => 'Andreas Koch',
        'route'  => 'Patagonia Expedition',
        'stars'  => 5,
        'quote'  => 'Torres del Paine in perfect conditions — the team had planned five alternative days in case of weather. That level of foresight is what separates a great operator from the rest.',
        'avatar' => 'AK',
        'col'    => '#5aaab0',
    ],
    [
        'name'   => 'Julia & Max Bauer',
        'route'  => 'Maldives Honeymoon',
        'stars'  => 5,
        'quote'  => 'Every single detail exceeded our expectations. The seaplane at sunset, the private sandbank dinner, the bioluminescent beach at midnight — magic.',
        'avatar' => 'JM',
        'col'    => '#e07b5a',
    ],
];

// Stats
$stats = [
    [ 'val' => 4800,  'suffix' => '+',  'label' => 'Travellers Served' ],
    [ 'val' => 68,    'suffix' => '',   'label' => 'Countries Covered' ],
    [ 'val' => 99,    'suffix' => '%',  'label' => 'Would Rebook' ],
    [ 'val' => 12,    'suffix' => '',   'label' => 'Years of Expertise' ],
];

// Press / awards marquee
$press = [
    'Condé Nast Traveller',
    'National Geographic Traveler',
    'Travel + Leisure',
    'Lonely Planet',
    'The Guardian Travel',
    'FVWR Award 2024',
    'Sustainable Travel Certified',
    'ATTA Member',
    'B Corp Certified',
    'World Travel Awards',
];
$press_double = array_merge( $press, $press );
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&family=Nunito+Sans:wght@300;400;600;700;800&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════════
   TRAVEL — CSS CUSTOM PROPERTIES
═══════════════════════════════════════════════════════════ */
:root {
    --trv-ocean    : #0b2545;
    --trv-ocean-d  : #071830;
    --trv-ocean-m  : #143560;
    --trv-sand     : #e8d5b0;
    --trv-sand-l   : #f5edd8;
    --trv-coral    : #e07b5a;
    --trv-coral-l  : #f09070;
    --trv-jade     : #2e7d6e;
    --trv-warm     : #faf8f4;
    --trv-ash      : #7a7a7a;
    --trv-white    : #ffffff;
    --trv-ff-head  : 'Libre Baskerville', Georgia, serif;
    --trv-ff-body  : 'Nunito Sans', system-ui, sans-serif;
    --trv-radius   : 4px;
    --trv-trans    : .4s cubic-bezier(.4,0,.2,1);
}

/* ── Reset ── */
.trv-page *, .trv-page *::before, .trv-page *::after { box-sizing: border-box; margin: 0; padding: 0; }
.trv-page { font-family: var(--trv-ff-body); color: var(--trv-ocean); background: var(--trv-warm); line-height: 1.6; }
.trv-page a { color: inherit; text-decoration: none; }
.trv-page ul { list-style: none; }

/* ── Layout ── */
.trv-wrap      { max-width: 1280px; margin: 0 auto; padding: 0 28px; }
.trv-wrap--wide{ max-width: 1440px; margin: 0 auto; padding: 0 20px; }

/* ── Headings ── */
.trv-eyebrow {
    font-family: var(--trv-ff-body);
    font-size: .7rem;
    font-weight: 800;
    letter-spacing: .24em;
    text-transform: uppercase;
    color: var(--trv-coral);
    display: block;
    margin-bottom: .9rem;
}
.trv-h2 {
    font-family: var(--trv-ff-head);
    font-size: clamp(2rem, 4vw, 3.2rem);
    font-weight: 700;
    color: var(--trv-ocean);
    line-height: 1.18;
}
.trv-h2.light { color: var(--trv-white); }
.trv-h2 em { font-style: italic; color: var(--trv-coral); }
.trv-lead {
    font-size: 1.05rem;
    color: var(--trv-ash);
    line-height: 1.8;
    margin-top: 1rem;
    max-width: 52ch;
}
.trv-lead.light { color: rgba(232,213,176,.8); }

/* ── Buttons ── */
.trv-btn {
    display: inline-flex;
    align-items: center;
    gap: .5rem;
    padding: .9rem 2.2rem;
    font-family: var(--trv-ff-body);
    font-size: .8rem;
    font-weight: 800;
    letter-spacing: .12em;
    text-transform: uppercase;
    border: none;
    cursor: pointer;
    transition: var(--trv-trans);
    border-radius: 60px;
}
.trv-btn--coral { background: var(--trv-coral); color: var(--trv-white); }
.trv-btn--coral:hover { background: var(--trv-coral-l); transform: translateY(-2px); box-shadow: 0 8px 28px rgba(224,123,90,.38); }
.trv-btn--outline-light {
    background: transparent;
    color: var(--trv-sand);
    border: 1.5px solid rgba(232,213,176,.5);
    border-radius: 60px;
}
.trv-btn--outline-light:hover { border-color: var(--trv-coral); color: var(--trv-coral-l); }
.trv-btn--outline-ocean {
    background: transparent;
    color: var(--trv-ocean);
    border: 1.5px solid rgba(11,37,69,.3);
    border-radius: 60px;
}
.trv-btn--outline-ocean:hover { background: var(--trv-ocean); color: var(--trv-white); }

/* ═══════════════════════════════════════════════════════════
   HERO — NIGHT SKY + GLOBE ART
═══════════════════════════════════════════════════════════ */
.trv-hero {
    position: relative;
    min-height: 100vh;
    background: linear-gradient(180deg, var(--trv-ocean-d) 0%, var(--trv-ocean) 50%, #1a4060 80%, #2e5a4a 100%);
    display: flex;
    align-items: center;
    overflow: hidden;
}

/* Stars */
.trv-stars { position: absolute; inset: 0; pointer-events: none; }
<?php foreach ( $stars as $i => $s ) : ?>
.trv-star-<?php echo $i; ?> {
    position: absolute;
    left: <?php echo $s['x']; ?>%;
    top:  <?php echo $s['y']; ?>%;
    width:  <?php echo $s['r']; ?>px;
    height: <?php echo $s['r']; ?>px;
    border-radius: 50%;
    background: #fff;
    opacity: <?php echo $s['op']; ?>;
    animation: trv-twinkle <?php echo $s['dur']; ?>s ease-in-out <?php echo $s['del']; ?>s infinite alternate;
}
<?php endforeach; ?>
@keyframes trv-twinkle { from { opacity: .15; } to { opacity: .9; } }

/* Moon */
.trv-moon {
    position: absolute;
    top: 8%;
    right: 20%;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: radial-gradient(circle at 40% 35%, #fffbe0, #f0d870);
    box-shadow: 0 0 40px rgba(240,220,100,.4), 0 0 80px rgba(240,220,100,.15);
}
/* Moon shadow crescent */
.trv-moon::after {
    content: '';
    position: absolute;
    top: 5px;
    right: 2px;
    width: 44px;
    height: 44px;
    border-radius: 50%;
    background: var(--trv-ocean-d);
    opacity: .55;
}

/* Aurora borealis hint */
.trv-aurora {
    position: absolute;
    top: 15%;
    left: 0;
    right: 0;
    height: 200px;
    background: linear-gradient(90deg,
        transparent 0%,
        rgba(46,125,110,.12) 20%,
        rgba(100,200,180,.18) 40%,
        rgba(46,125,110,.08) 60%,
        rgba(80,160,200,.12) 80%,
        transparent 100%);
    filter: blur(30px);
    pointer-events: none;
    animation: trv-aurora-wave 18s ease-in-out infinite alternate;
}
@keyframes trv-aurora-wave {
    from { transform: translateX(-5%) scaleY(.8); opacity: .6; }
    to   { transform: translateX(5%) scaleY(1.2); opacity: 1; }
}

/* Ocean horizon glow */
.trv-horizon {
    position: absolute;
    bottom: 30%;
    left: 0;
    right: 0;
    height: 80px;
    background: linear-gradient(180deg, transparent, rgba(46,90,74,.5), rgba(46,90,74,.3), transparent);
    pointer-events: none;
}

/* ── CSS Globe art ── */
.trv-globe-wrap {
    position: absolute;
    right: 4%;
    top: 50%;
    transform: translateY(-50%);
    width: 420px;
    height: 420px;
}
@media (max-width: 1100px) { .trv-globe-wrap { display: none; } }

.trv-globe {
    position: absolute;
    inset: 30px;
    border-radius: 50%;
    background: radial-gradient(circle at 35% 30%, #1a4060 0%, #0b2545 50%, #071830 100%);
    box-shadow:
        0 0 0 1px rgba(74,144,200,.2),
        0 0 60px rgba(46,125,110,.25),
        0 20px 80px rgba(0,0,0,.6),
        inset 0 0 60px rgba(74,144,200,.1);
    overflow: hidden;
}

/* Globe grid lines (latitude/longitude) */
.trv-globe-grid {
    position: absolute;
    inset: 0;
    border-radius: 50%;
    background:
        repeating-conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 29deg, rgba(74,144,200,.08) 30deg, transparent 31deg),
        repeating-linear-gradient(0deg, transparent 0, transparent 11%, rgba(74,144,200,.06) 12%, transparent 13%);
}

/* Continent shapes via clip-path */
.trv-continent {
    position: absolute;
    background: rgba(46,125,110,.4);
    border-radius: 2px;
}
/* Europe-ish */
.trv-continent-1 { left: 48%; top: 28%; width: 10%; height: 8%; clip-path: polygon(20% 0%,80% 0%,100% 60%,60% 100%,0% 80%); }
/* Africa */
.trv-continent-2 { left: 46%; top: 42%; width: 9%; height: 18%; clip-path: polygon(30% 0%,70% 0%,90% 30%,80% 70%,50% 100%,20% 70%,10% 30%); }
/* Asia */
.trv-continent-3 { left: 55%; top: 22%; width: 18%; height: 16%; clip-path: polygon(0% 30%,15% 0%,60% 0%,100% 20%,90% 60%,50% 70%,20% 60%); }
/* Americas */
.trv-continent-4 { left: 20%; top: 28%; width: 10%; height: 22%; clip-path: polygon(40% 0%,80% 10%,70% 40%,90% 60%,60% 100%,20% 80%,10% 50%,30% 20%); }
/* Oceania */
.trv-continent-5 { left: 68%; top: 58%; width: 9%; height: 6%; clip-path: polygon(0% 50%,30% 0%,70% 10%,100% 40%,80% 100%,20% 90%); }

/* Globe glow / atmosphere */
.trv-globe-atmo {
    position: absolute;
    inset: -15px;
    border-radius: 50%;
    background: radial-gradient(circle at 30% 25%, rgba(100,180,255,.08) 0%, transparent 60%);
    pointer-events: none;
}
.trv-globe-shine {
    position: absolute;
    top: 10%;
    left: 15%;
    width: 30%;
    height: 25%;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(255,255,255,.12) 0%, transparent 70%);
}

/* Flight path arcs on globe */
.trv-globe-paths {
    position: absolute;
    inset: 0;
    border-radius: 50%;
}

/* Location pins */
<?php
$pins = [
    ['top' => '38%', 'left' => '50%', 'col' => '#e07b5a'],  // Europe
    ['top' => '60%', 'left' => '47%', 'col' => '#40c8b0'],  // Africa
    ['top' => '32%', 'left' => '66%', 'col' => '#f0d870'],  // Asia
    ['top' => '45%', 'left' => '22%', 'col' => '#80c040'],  // Americas
    ['top' => '65%', 'left' => '72%', 'col' => '#8080f0'],  // Oceania
];
?>
<?php foreach ( $pins as $pi => $pin ) : ?>
.trv-globe-pin-<?php echo $pi; ?> {
    position: absolute;
    top: <?php echo $pin['top']; ?>;
    left: <?php echo $pin['left']; ?>;
    width: 8px;
    height: 8px;
    margin: -4px;
    background: <?php echo $pin['col']; ?>;
    border-radius: 50% 50% 50% 0;
    transform: rotate(-45deg);
    box-shadow: 0 0 10px <?php echo $pin['col']; ?>;
    animation: trv-pin-pulse 3s ease-in-out <?php echo $pi * .6; ?>s infinite;
}
.trv-globe-pin-<?php echo $pi; ?>::after {
    content: '';
    position: absolute;
    inset: 2px;
    border-radius: 50%;
    background: rgba(255,255,255,.5);
}
<?php endforeach; ?>
@keyframes trv-pin-pulse { 0%,100%{box-shadow:0 0 6px currentColor} 50%{box-shadow:0 0 18px currentColor, 0 0 30px currentColor} }

/* Globe stand */
.trv-globe-stand {
    position: absolute;
    bottom: 10px;
    left: 50%;
    transform: translateX(-50%);
    width: 6px;
    height: 40px;
    background: linear-gradient(180deg, rgba(232,213,176,.4), rgba(232,213,176,.1));
}
.trv-globe-base {
    position: absolute;
    bottom: 5px;
    left: 50%;
    transform: translateX(-50%);
    width: 80px;
    height: 12px;
    background: rgba(232,213,176,.15);
    border-radius: 6px;
    border: 1px solid rgba(232,213,176,.2);
}

/* Orbit ring */
.trv-orbit-ring {
    position: absolute;
    inset: 18px;
    border-radius: 50%;
    border: 1px solid rgba(74,144,200,.2);
    transform: rotateX(70deg);
}

/* Hero content */
.trv-hero-content {
    position: relative;
    z-index: 2;
    padding: 130px 0 90px;
    max-width: 640px;
}
.trv-hero-badge {
    display: inline-flex;
    align-items: center;
    gap: .6rem;
    padding: .45rem 1.1rem;
    background: rgba(232,213,176,.1);
    border: 1px solid rgba(232,213,176,.25);
    border-radius: 60px;
    color: var(--trv-sand);
    font-size: .72rem;
    font-weight: 700;
    letter-spacing: .18em;
    text-transform: uppercase;
    margin-bottom: 2rem;
}
.trv-hero-badge::before { content: '◆'; color: var(--trv-coral); font-size: .5rem; }
.trv-hero-h1 {
    font-family: var(--trv-ff-head);
    font-size: clamp(3rem, 7vw, 5.5rem);
    font-weight: 700;
    color: var(--trv-white);
    line-height: 1.08;
    margin-bottom: 1.6rem;
}
.trv-hero-h1 em { color: var(--trv-coral); font-style: italic; display: block; }
.trv-hero-sub {
    font-size: 1.05rem;
    color: rgba(232,213,176,.8);
    line-height: 1.8;
    margin-bottom: 2.5rem;
    font-weight: 400;
    max-width: 46ch;
}
.trv-hero-ctas { display: flex; gap: 1rem; flex-wrap: wrap; }

/* Search bar */
.trv-search-bar {
    display: flex;
    gap: 0;
    margin-top: 3rem;
    background: rgba(255,255,255,.08);
    border: 1px solid rgba(232,213,176,.2);
    border-radius: 60px;
    overflow: hidden;
    backdrop-filter: blur(10px);
    max-width: 540px;
}
.trv-search-input {
    flex: 1;
    background: transparent;
    border: none;
    outline: none;
    padding: 1rem 1.5rem;
    color: var(--trv-white);
    font-family: var(--trv-ff-body);
    font-size: .95rem;
}
.trv-search-input::placeholder { color: rgba(232,213,176,.45); }
.trv-search-btn {
    padding: .9rem 1.8rem;
    background: var(--trv-coral);
    border: none;
    color: var(--trv-white);
    font-family: var(--trv-ff-body);
    font-size: .8rem;
    font-weight: 800;
    letter-spacing: .1em;
    text-transform: uppercase;
    cursor: pointer;
    border-radius: 60px;
    margin: 4px;
    transition: background .25s ease;
}
.trv-search-btn:hover { background: var(--trv-coral-l); }

/* Scroll indicator */
.trv-scroll { position: absolute; bottom: 28px; left: 50%; transform: translateX(-50%); z-index: 2; text-align: center; }
.trv-scroll-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: rgba(232,213,176,.5);
    margin: 0 auto 8px;
    animation: trv-bounce 2s ease-in-out infinite;
}
@keyframes trv-bounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
.trv-scroll span { font-size: .65rem; letter-spacing: .18em; text-transform: uppercase; color: rgba(232,213,176,.4); }

/* ═══════════════════════════════════════════════════════════
   MARQUEE — PRESS
═══════════════════════════════════════════════════════════ */
.trv-marquee-bar {
    background: var(--trv-ocean);
    padding: 1rem 0;
    overflow: hidden;
}
.trv-marquee-track {
    display: flex;
    width: max-content;
    animation: trv-scroll-left 42s linear infinite;
}
.trv-marquee-track:hover { animation-play-state: paused; }
@keyframes trv-scroll-left { from{transform:translateX(0)} to{transform:translateX(-50%)} }
.trv-marquee-item {
    padding: 0 2.5rem;
    font-size: .75rem;
    font-weight: 800;
    letter-spacing: .16em;
    text-transform: uppercase;
    color: rgba(232,213,176,.5);
    white-space: nowrap;
    display: flex;
    align-items: center;
    gap: 2.5rem;
}
.trv-marquee-item::after { content: '◆'; font-size: .45rem; color: var(--trv-coral); }

/* ═══════════════════════════════════════════════════════════
   FEATURED DESTINATIONS
═══════════════════════════════════════════════════════════ */
.trv-destinations { padding: 110px 0; background: var(--trv-warm); }
.trv-dest-header { text-align: center; margin-bottom: 3.5rem; }
.trv-dest-header .trv-lead { margin: 1rem auto 0; }
.trv-dest-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1.5rem;
}
@media (max-width: 960px) { .trv-dest-grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 560px) { .trv-dest-grid { grid-template-columns: 1fr; } }

.trv-dest-card {
    border-radius: var(--trv-radius);
    overflow: hidden;
    position: relative;
    cursor: pointer;
    transition: var(--trv-trans);
    box-shadow: 0 4px 20px rgba(0,0,0,.08);
}
.trv-dest-card:hover { transform: translateY(-6px); box-shadow: 0 20px 60px rgba(0,0,0,.2); }

/* CSS destination landscape art */
.trv-dest-art {
    aspect-ratio: 4/3;
    position: relative;
    overflow: hidden;
}
.trv-dest-art-inner { width: 100%; height: 100%; }

/* Overlay gradient */
.trv-dest-overlay {
    position: absolute;
    inset: 0;
    background: linear-gradient(to top, rgba(0,0,0,.8) 0%, rgba(0,0,0,.2) 50%, transparent 100%);
}

/* Badge */
.trv-dest-badge {
    position: absolute;
    top: 14px;
    right: 14px;
    padding: .3rem .85rem;
    background: var(--trv-coral);
    color: var(--trv-white);
    font-size: .68rem;
    font-weight: 800;
    letter-spacing: .12em;
    text-transform: uppercase;
    border-radius: 60px;
}

.trv-dest-body {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    padding: 1.5rem;
}
.trv-dest-tag {
    font-size: .7rem;
    font-weight: 700;
    letter-spacing: .12em;
    text-transform: uppercase;
    color: var(--trv-coral-l);
    margin-bottom: .4rem;
}
.trv-dest-name {
    font-family: var(--trv-ff-head);
    font-size: 1.3rem;
    font-weight: 700;
    color: var(--trv-white);
    margin-bottom: .6rem;
}
.trv-dest-meta {
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.trv-dest-nights { font-size: .8rem; color: rgba(232,213,176,.7); }
.trv-dest-from { font-size: .82rem; color: var(--trv-white); font-weight: 700; }
.trv-dest-from strong { color: var(--trv-coral-l); }

/* ═══════════════════════════════════════════════════════════
   TOUR PACKAGES
═══════════════════════════════════════════════════════════ */
.trv-tours { padding: 110px 0; background: var(--trv-ocean); }
.trv-tours-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    flex-wrap: wrap;
    gap: 1.5rem;
    margin-bottom: 3rem;
}
.trv-tour-filters {
    display: flex;
    gap: .5rem;
    flex-wrap: wrap;
}
.trv-filter-btn {
    padding: .5rem 1.2rem;
    font-size: .73rem;
    font-weight: 700;
    letter-spacing: .1em;
    text-transform: uppercase;
    background: transparent;
    border: 1px solid rgba(232,213,176,.2);
    color: rgba(232,213,176,.6);
    border-radius: 60px;
    cursor: pointer;
    transition: var(--trv-trans);
}
.trv-filter-btn:hover, .trv-filter-btn.active {
    background: var(--trv-coral);
    border-color: var(--trv-coral);
    color: var(--trv-white);
}

.trv-tours-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1.5rem;
}
@media (max-width: 960px) { .trv-tours-grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 560px) { .trv-tours-grid { grid-template-columns: 1fr; } }

.trv-tour-card {
    background: rgba(255,255,255,.04);
    border: 1px solid rgba(255,255,255,.06);
    border-radius: var(--trv-radius);
    overflow: hidden;
    transition: var(--trv-trans);
}
.trv-tour-card.hidden { display: none; }
.trv-tour-card:hover { background: rgba(255,255,255,.08); transform: translateY(-4px); }

/* CSS mini landscape for tour */
.trv-tour-art {
    height: 140px;
    position: relative;
    overflow: hidden;
}
.trv-tour-art-inner { width: 100%; height: 100%; }

.trv-tour-body { padding: 1.5rem; }
.trv-tour-title {
    font-family: var(--trv-ff-head);
    font-size: 1.15rem;
    font-weight: 700;
    color: var(--trv-white);
    margin-bottom: .25rem;
}
.trv-tour-sub {
    font-size: .78rem;
    color: var(--trv-coral-l);
    font-weight: 600;
    letter-spacing: .06em;
    margin-bottom: .8rem;
}
.trv-tour-desc { font-size: .88rem; color: rgba(232,213,176,.65); line-height: 1.65; margin-bottom: 1.2rem; }
.trv-tour-chips {
    display: flex;
    gap: .5rem;
    flex-wrap: wrap;
    margin-bottom: 1.2rem;
}
.trv-chip {
    padding: .25rem .75rem;
    background: rgba(232,213,176,.06);
    border: 1px solid rgba(232,213,176,.12);
    border-radius: 60px;
    font-size: .7rem;
    color: rgba(232,213,176,.7);
    white-space: nowrap;
}
.trv-tour-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-top: 1px solid rgba(232,213,176,.07);
    padding-top: 1rem;
    margin-top: .5rem;
}
.trv-tour-price { font-size: .82rem; color: rgba(232,213,176,.5); }
.trv-tour-price strong { font-size: 1.1rem; color: var(--trv-coral-l); }
.trv-tour-cta {
    padding: .5rem 1.1rem;
    font-size: .75rem;
    font-weight: 700;
    letter-spacing: .1em;
    text-transform: uppercase;
    background: var(--trv-coral);
    color: var(--trv-white);
    border-radius: 60px;
    border: none;
    cursor: pointer;
    transition: var(--trv-trans);
}
.trv-tour-cta:hover { background: var(--trv-coral-l); }

/* ═══════════════════════════════════════════════════════════
   WHY US
═══════════════════════════════════════════════════════════ */
.trv-why { padding: 110px 0; background: var(--trv-sand-l); }
.trv-why-header { text-align: center; margin-bottom: 4rem; }
.trv-why-header .trv-lead { margin: 1rem auto 0; }
.trv-why-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 2rem;
}
@media (max-width: 860px) { .trv-why-grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 480px) { .trv-why-grid { grid-template-columns: 1fr; } }

.trv-why-card {
    text-align: center;
    padding: 2.5rem 1.5rem;
    background: var(--trv-warm);
    border-radius: 8px;
    border: 1px solid rgba(0,0,0,.04);
    transition: var(--trv-trans);
}
.trv-why-card:hover { transform: translateY(-4px); box-shadow: 0 16px 40px rgba(0,0,0,.08); }
.trv-why-icon {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: rgba(11,37,69,.08);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.4rem;
    color: var(--trv-ocean);
    margin: 0 auto 1.2rem;
}
.trv-why-title {
    font-family: var(--trv-ff-head);
    font-size: 1.05rem;
    font-weight: 700;
    color: var(--trv-ocean);
    margin-bottom: .7rem;
}
.trv-why-desc { font-size: .9rem; color: var(--trv-ash); line-height: 1.65; }

/* ═══════════════════════════════════════════════════════════
   STATS
═══════════════════════════════════════════════════════════ */
.trv-stats {
    padding: 70px 0;
    background: var(--trv-jade);
}
.trv-stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 2rem;
    text-align: center;
}
@media (max-width: 700px) { .trv-stats-grid { grid-template-columns: repeat(2, 1fr); } }

.trv-stat-val {
    font-family: var(--trv-ff-head);
    font-size: clamp(2.5rem, 5vw, 3.8rem);
    font-weight: 700;
    color: var(--trv-white);
    line-height: 1;
    display: block;
}
.trv-stat-label {
    font-size: .75rem;
    letter-spacing: .16em;
    text-transform: uppercase;
    color: rgba(255,255,255,.55);
    margin-top: .6rem;
    display: block;
}

/* ═══════════════════════════════════════════════════════════
   TESTIMONIALS
═══════════════════════════════════════════════════════════ */
.trv-testimonials { padding: 110px 0; background: var(--trv-warm); }
.trv-test-header { text-align: center; margin-bottom: 4rem; }
.trv-test-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 2rem;
}
@media (max-width: 900px) { .trv-test-grid { grid-template-columns: 1fr; max-width: 600px; margin: 0 auto; } }

.trv-test-card {
    background: var(--trv-white);
    border-radius: 8px;
    padding: 2.5rem;
    border: 1px solid rgba(0,0,0,.05);
    box-shadow: 0 4px 20px rgba(0,0,0,.04);
    transition: var(--trv-trans);
    position: relative;
}
.trv-test-card:hover { transform: translateY(-4px); box-shadow: 0 20px 50px rgba(0,0,0,.1); }
.trv-test-flag {
    position: absolute;
    top: -1px;
    left: 2rem;
    width: 4px;
    height: 40px;
    background: var(--trv-coral);
    border-radius: 0 0 4px 4px;
}
.trv-test-stars { color: var(--trv-coral); margin-bottom: 1.2rem; letter-spacing: .1em; font-size: .9rem; }
.trv-test-quote {
    font-family: var(--trv-ff-head);
    font-style: italic;
    font-size: 1rem;
    color: var(--trv-ocean);
    line-height: 1.75;
    margin-bottom: 1.8rem;
}
.trv-test-route {
    font-size: .72rem;
    font-weight: 700;
    letter-spacing: .12em;
    text-transform: uppercase;
    color: var(--trv-coral);
    margin-bottom: 1rem;
}
.trv-test-author {
    display: flex;
    align-items: center;
    gap: .8rem;
}
.trv-test-avatar {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: .78rem;
    font-weight: 800;
    color: var(--trv-white);
    flex-shrink: 0;
}
.trv-test-name { font-size: .9rem; font-weight: 700; color: var(--trv-ocean); }

/* ═══════════════════════════════════════════════════════════
   BOOKING / ENQUIRY FORM
═══════════════════════════════════════════════════════════ */
.trv-booking { padding: 110px 0; background: var(--trv-ocean); }
.trv-booking-inner {
    display: grid;
    grid-template-columns: 1fr 1.2fr;
    gap: 5rem;
    align-items: start;
}
@media (max-width: 860px) { .trv-booking-inner { grid-template-columns: 1fr; gap: 3rem; } }

.trv-booking-info { }
.trv-booking-steps { margin-top: 2.5rem; counter-reset: step; }
.trv-booking-step {
    display: flex;
    gap: 1rem;
    margin-bottom: 1.8rem;
    counter-increment: step;
}
.trv-step-num {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background: rgba(224,123,90,.15);
    border: 1px solid rgba(224,123,90,.35);
    color: var(--trv-coral-l);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: .82rem;
    font-weight: 800;
    flex-shrink: 0;
}
.trv-step-text strong { display: block; font-size: .9rem; font-weight: 700; color: var(--trv-white); margin-bottom: .2rem; }
.trv-step-text span { font-size: .85rem; color: rgba(232,213,176,.55); }

/* Form card */
.trv-form-card {
    background: rgba(255,255,255,.04);
    border: 1px solid rgba(232,213,176,.1);
    border-radius: 8px;
    padding: 3rem;
    backdrop-filter: blur(8px);
}
.trv-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
@media (max-width: 560px) { .trv-form-row { grid-template-columns: 1fr; } }
.trv-field {
    display: flex;
    flex-direction: column;
    gap: .4rem;
    margin-bottom: 1.2rem;
}
.trv-field label {
    font-size: .72rem;
    font-weight: 700;
    letter-spacing: .12em;
    text-transform: uppercase;
    color: rgba(232,213,176,.45);
}
.trv-field input,
.trv-field select,
.trv-field textarea {
    background: rgba(255,255,255,.05);
    border: 1px solid rgba(232,213,176,.12);
    border-radius: 4px;
    padding: .85rem 1rem;
    color: var(--trv-sand);
    font-family: var(--trv-ff-body);
    font-size: .95rem;
    transition: border-color .25s;
    width: 100%;
}
.trv-field input:focus,
.trv-field select:focus,
.trv-field textarea:focus {
    outline: none;
    border-color: var(--trv-coral);
    background: rgba(224,123,90,.05);
}
.trv-field input::placeholder { color: rgba(232,213,176,.25); }
.trv-field select option { background: var(--trv-ocean); color: var(--trv-sand); }
.trv-field textarea { resize: vertical; min-height: 110px; }
.trv-form-submit { width: 100%; justify-content: center; margin-top: .5rem; }
.trv-form-note {
    font-size: .78rem;
    color: rgba(232,213,176,.3);
    text-align: center;
    margin-top: 1rem;
    line-height: 1.5;
}

/* ═══════════════════════════════════════════════════════════
   SCROLL REVEAL
═══════════════════════════════════════════════════════════ */
.trv-reveal {
    opacity: 0;
    transform: translateY(26px);
    transition: opacity .7s ease, transform .7s ease;
}
.trv-reveal.visible { opacity: 1; transform: none; }

@media (max-width: 640px) {
    .trv-hero-ctas { flex-direction: column; }
    .trv-tours-header { flex-direction: column; align-items: flex-start; }
}
</style>
<?php get_header(); ?>
<div class="trv-page">
>
<div class="trv-page">

<!-- ═══════════════════════════════════════════════════
     HERO
═══════════════════════════════════════════════════ -->
<section class="trv-hero" aria-label="Hero">

    <!-- Stars -->
    <div class="trv-stars" aria-hidden="true">
        <?php foreach ( $stars as $i => $s ) : ?>
            <div class="trv-star-<?php echo $i; ?>"></div>
        <?php endforeach; ?>
    </div>

    <div class="trv-moon" aria-hidden="true"></div>
    <div class="trv-aurora" aria-hidden="true"></div>
    <div class="trv-horizon" aria-hidden="true"></div>

    <!-- Globe CSS art -->
    <div class="trv-globe-wrap" aria-hidden="true">
        <div class="trv-orbit-ring"></div>
        <div class="trv-globe">
            <div class="trv-globe-grid"></div>
            <!-- Continents -->
            <div class="trv-continent trv-continent-1"></div>
            <div class="trv-continent trv-continent-2"></div>
            <div class="trv-continent trv-continent-3"></div>
            <div class="trv-continent trv-continent-4"></div>
            <div class="trv-continent trv-continent-5"></div>
            <!-- Paths SVG -->
            <svg class="trv-globe-paths" viewBox="0 0 360 360" xmlns="http://www.w3.org/2000/svg">
                <path d="M80 130 Q 180 80 280 145" fill="none" stroke="rgba(224,123,90,.4)" stroke-width="1.5" stroke-dasharray="5 4"/>
                <path d="M180 145 Q 240 100 290 110" fill="none" stroke="rgba(64,200,176,.35)" stroke-width="1.5" stroke-dasharray="5 4"/>
                <path d="M80 130 Q 130 200 175 220" fill="none" stroke="rgba(232,213,176,.25)" stroke-width="1.5" stroke-dasharray="4 5"/>
            </svg>
            <!-- Location pins -->
            <?php foreach ( $pins as $pi => $pin ) : ?>
                <div class="trv-globe-pin-<?php echo $pi; ?>"></div>
            <?php endforeach; ?>
            <!-- Shine -->
            <div class="trv-globe-shine"></div>
        </div>
        <div class="trv-globe-atmo"></div>
        <div class="trv-globe-stand"></div>
        <div class="trv-globe-base"></div>
    </div>

    <div class="trv-wrap">
        <div class="trv-hero-content">
            <div class="trv-hero-badge">Bespoke travel since 2012</div>
            <h1 class="trv-hero-h1">
                The world is
                <em>yours to explore</em>
            </h1>
            <p class="trv-hero-sub">Tailor-made journeys crafted for the curious and the adventurous. Every detail handled with care — all you need to do is arrive.</p>
            <div class="trv-hero-ctas">
                <a href="#tours" class="trv-btn trv-btn--coral">Explore Tours</a>
                <a href="#booking" class="trv-btn trv-btn--outline-light">Plan My Trip</a>
            </div>
            <div class="trv-search-bar">
                <input type="text" class="trv-search-input" placeholder="Where do you dream of going?">
                <button class="trv-search-btn" aria-label="Search destinations">Search</button>
            </div>
        </div>
    </div>

    <div class="trv-scroll" aria-hidden="true">
        <div class="trv-scroll-dot"></div>
        <span>scroll</span>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════
     MARQUEE
═══════════════════════════════════════════════════ -->
<div class="trv-marquee-bar" aria-label="Press and awards">
    <div class="trv-marquee-track" role="marquee">
        <?php foreach ( $press_double as $p ) : ?>
            <span class="trv-marquee-item"><?php echo esc_html($p); ?></span>
        <?php endforeach; ?>
    </div>
</div>

<!-- ═══════════════════════════════════════════════════
     DESTINATIONS
═══════════════════════════════════════════════════ -->
<section class="trv-destinations" aria-labelledby="trv-dest-title">
<div class="trv-wrap">

    <div class="trv-dest-header trv-reveal">
        <span class="trv-eyebrow">Where to go</span>
        <h2 class="trv-h2" id="trv-dest-title">Featured <em>destinations</em></h2>
        <p class="trv-lead">Handpicked by our travel specialists — places that reward the curious traveller with beauty, culture and unforgettable moments.</p>
    </div>

    <div class="trv-dest-grid">
        <?php foreach ( $destinations as $di => $dest ) : ?>
        <article class="trv-dest-card trv-reveal" style="transition-delay:<?php echo $di*.09;?>s" aria-label="<?php echo esc_attr($dest['name']); ?>">
            <div class="trv-dest-art">
                <!-- CSS landscape for destination -->
                <svg class="trv-dest-art-inner" viewBox="0 0 400 300" xmlns="http://www.w3.org/2000/svg">
                    <!-- Sky -->
                    <defs>
                        <linearGradient id="trv-sky-<?php echo $di;?>" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stop-color="<?php echo $dest['sky'];?>"/>
                            <stop offset="100%" stop-color="<?php echo $dest['land'];?>"/>
                        </linearGradient>
                        <radialGradient id="trv-glow-<?php echo $di;?>" cx="50%" cy="40%" r="40%">
                            <stop offset="0%" stop-color="<?php echo $dest['acc'];?>" stop-opacity="0.2"/>
                            <stop offset="100%" stop-color="transparent" stop-opacity="0"/>
                        </radialGradient>
                    </defs>
                    <rect width="400" height="300" fill="url(#trv-sky-<?php echo $di;?>)"/>
                    <rect width="400" height="300" fill="url(#trv-glow-<?php echo $di;?>)"/>

                    <!-- Stars -->
                    <?php
                    srand( $di * 23 + 5 );
                    for ( $si = 0; $si < 20; $si++ ) :
                        $sx = rand(0,400); $sy = rand(0,120);
                        $sr = rand(1,4)/10;
                        $sop = rand(20,80)/100;
                    ?>
                    <circle cx="<?php echo $sx;?>" cy="<?php echo $sy;?>" r="<?php echo $sr;?>" fill="white" opacity="<?php echo $sop;?>"/>
                    <?php endfor; ?>

                    <!-- Moon or sun for destination -->
                    <circle cx="320" cy="55" r="18" fill="<?php echo $dest['acc'];?>" opacity="0.6"/>

                    <!-- Landscape silhouette unique per dest -->
                    <?php
                    $landscapes = [
                        // Kyoto — pagoda + hills
                        '<polygon points="50,200 80,160 100,170 120,140 140,150 160,200" fill="rgba(0,0,0,0.6)"/><rect x="185" y="130" width="6" height="70" fill="rgba(0,0,0,0.7)"/><polygon points="165,145 188,125 211,145" fill="rgba(0,0,0,0.7)"/><polygon points="170,165 188,150 206,165" fill="rgba(0,0,0,0.7)"/><polygon points="175,183 188,170 201,183" fill="rgba(0,0,0,0.7)"/>',
                        // Amalfi — sea cliffs + houses
                        '<polygon points="0,200 60,160 120,175 200,150 280,165 400,180 400,300 0,300" fill="rgba(0,0,0,0.5)"/><rect x="60" y="160" width="15" height="20" fill="rgba(255,255,255,0.15)" rx="2"/><rect x="100" y="148" width="18" height="25" fill="rgba(255,255,255,0.12)" rx="2"/><rect x="130" y="155" width="12" height="18" fill="rgba(255,255,255,0.1)" rx="2"/>',
                        // Marrakech — domes + minarets
                        '<polygon points="0,210 400,210 400,300 0,300" fill="rgba(0,0,0,0.6)"/><rect x="150" y="120" width="10" height="90" fill="rgba(0,0,0,0.7)"/><polygon points="145,125 155,108 165,125" fill="rgba(0,0,0,0.7)"/><ellipse cx="220" cy="195" rx="35" ry="25" fill="rgba(0,0,0,0.5)"/><ellipse cx="290" cy="190" rx="28" ry="20" fill="rgba(0,0,0,0.45)"/><ellipse cx="100" cy="200" rx="22" ry="16" fill="rgba(0,0,0,0.4)"/>',
                        // Patagonia — mountain spires
                        '<polygon points="0,280 50,200 80,220 120,160 160,190 200,130 240,170 280,150 320,180 360,160 400,200 400,280" fill="rgba(0,0,0,0.7)"/><polygon points="185,128 200,100 215,128" fill="rgba(255,255,255,0.15)"/>',
                        // Maldives — flat + water huts
                        '<rect x="0" y="220" width="400" height="80" fill="rgba(0,30,50,0.7)"/><rect x="50" y="205" width="40" height="20" fill="rgba(0,0,0,0.5)" rx="2"/><polygon points="50,205 70,190 90,205" fill="rgba(0,0,0,0.4)"/><rect x="160" y="200" width="50" height="22" fill="rgba(0,0,0,0.5)" rx="2"/><polygon points="160,200 185,183 210,200" fill="rgba(0,0,0,0.4)"/><rect x="280" y="208" width="42" height="18" fill="rgba(0,0,0,0.45)" rx="2"/>',
                        // Santorini — cliff white houses
                        '<polygon points="0,240 80,180 160,200 240,170 320,190 400,165 400,280 0,280" fill="rgba(0,0,0,0.55)"/><rect x="70" y="170" width="20" height="16" fill="rgba(255,255,255,0.2)" rx="2"/><ellipse cx="80" cy="170" rx="10" ry="6" fill="rgba(100,150,200,0.4)"/><rect x="130" y="180" width="18" height="15" fill="rgba(255,255,255,0.18)" rx="2"/><ellipse cx="139" cy="180" rx="9" ry="5.5" fill="rgba(100,150,200,0.35)"/>',
                    ];
                    echo $landscapes[$di % count($landscapes)];
                    ?>

                    <!-- Water / horizon -->
                    <rect x="0" y="245" width="400" height="55" fill="rgba(0,0,0,0.3)" opacity="0.5"/>

                    <!-- Destination icon centered -->
                    <text x="200" y="130" font-size="28" text-anchor="middle" opacity="0.5" fill="<?php echo $dest['acc'];?>"><?php echo $dest['icon']; ?></text>
                </svg>
                <div class="trv-dest-overlay"></div>
                <?php if ( $dest['badge'] ) : ?>
                <div class="trv-dest-badge"><?php echo esc_html($dest['badge']); ?></div>
                <?php endif; ?>
            </div>
            <div class="trv-dest-body">
                <div class="trv-dest-tag"><?php echo esc_html($dest['tag']); ?></div>
                <div class="trv-dest-name"><?php echo esc_html($dest['name']); ?></div>
                <div class="trv-dest-meta">
                    <span class="trv-dest-nights"><?php echo esc_html($dest['nights']); ?></span>
                    <span class="trv-dest-from">ab <strong><?php echo esc_html($dest['from']); ?> €</strong></span>
                </div>
            </div>
        </article>
        <?php endforeach; ?>
    </div>

</div>
</section>

<!-- ═══════════════════════════════════════════════════
     TOUR PACKAGES
═══════════════════════════════════════════════════ -->
<section id="tours" class="trv-tours" aria-labelledby="trv-tours-title">
<div class="trv-wrap">

    <div class="trv-tours-header">
        <div class="trv-reveal">
            <span class="trv-eyebrow">All departures</span>
            <h2 class="trv-h2 light" id="trv-tours-title">Tour <em>packages</em></h2>
        </div>
        <div class="trv-tour-filters trv-reveal" role="group" aria-label="Filter tours">
            <button class="trv-filter-btn active" data-filter="all" aria-pressed="true">All</button>
            <button class="trv-filter-btn" data-filter="luxury" aria-pressed="false">Luxury</button>
            <button class="trv-filter-btn" data-filter="adventure" aria-pressed="false">Adventure</button>
            <button class="trv-filter-btn" data-filter="cultural" aria-pressed="false">Cultural</button>
        </div>
    </div>

    <div class="trv-tours-grid" id="trv-tours-grid">
        <?php foreach ( $tours as $ti => $tour ) : ?>
        <article class="trv-tour-card trv-reveal" data-cat="<?php echo esc_attr($tour['cat']); ?>" style="transition-delay:<?php echo $ti*.08;?>s">
            <!-- CSS mini landscape -->
            <div class="trv-tour-art">
                <svg class="trv-tour-art-inner" viewBox="0 0 400 140" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                        <linearGradient id="trv-tg-<?php echo $ti;?>" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stop-color="<?php echo $tour['col'];?>"/>
                            <stop offset="100%" stop-color="#0a0a0a"/>
                        </linearGradient>
                    </defs>
                    <rect width="400" height="140" fill="url(#trv-tg-<?php echo $ti;?>)"/>
                    <!-- Stars -->
                    <?php
                    srand($ti * 31 + 9);
                    for($tsi=0;$tsi<12;$tsi++):
                        $tsx=rand(0,400); $tsy=rand(0,60);
                    ?>
                    <circle cx="<?php echo $tsx;?>" cy="<?php echo $tsy;?>" r="<?php echo rand(1,3)/10;?>" fill="white" opacity="<?php echo rand(30,80)/100;?>"/>
                    <?php endfor; ?>
                    <!-- Horizon glow -->
                    <ellipse cx="200" cy="120" rx="200" ry="40" fill="<?php echo $tour['acc'];?>" opacity="0.12"/>
                    <!-- Mountain silhouette -->
                    <polygon points="0,140 60,90 120,110 180,70 240,95 300,80 360,100 400,85 400,140" fill="rgba(0,0,0,0.5)"/>
                    <!-- Moon -->
                    <circle cx="<?php srand($ti*7);echo rand(280,360);?>" cy="<?php echo rand(15,40);?>" r="8" fill="<?php echo $tour['acc'];?>" opacity="0.5"/>
                </svg>
            </div>
            <div class="trv-tour-body">
                <div class="trv-tour-sub"><?php echo esc_html($tour['sub']); ?></div>
                <h3 class="trv-tour-title"><?php echo esc_html($tour['title']); ?></h3>
                <p class="trv-tour-desc"><?php echo esc_html($tour['desc']); ?></p>
                <div class="trv-tour-chips">
                    <span class="trv-chip">⏱ <?php echo esc_html($tour['dur']); ?></span>
                    <span class="trv-chip">👥 <?php echo esc_html($tour['group']); ?></span>
                    <span class="trv-chip"><?php echo esc_html($tour['diff']); ?></span>
                </div>
                <div class="trv-tour-footer">
                    <div class="trv-tour-price">Ab <strong><?php echo esc_html($tour['price']); ?> €</strong> /P.</div>
                    <button class="trv-tour-cta">Details →</button>
                </div>
            </div>
        </article>
        <?php endforeach; ?>
    </div>

</div>
</section>

<!-- ═══════════════════════════════════════════════════
     WHY US
═══════════════════════════════════════════════════ -->
<section class="trv-why" aria-labelledby="trv-why-title">
<div class="trv-wrap">

    <div class="trv-why-header trv-reveal">
        <span class="trv-eyebrow">Why choose us</span>
        <h2 class="trv-h2" id="trv-why-title">Travel <em>differently</em></h2>
        <p class="trv-lead">We are a small, passionate team — not a package holiday factory. Here is what that means for you.</p>
    </div>

    <div class="trv-why-grid">
        <?php foreach ( $whys as $i => $why ) : ?>
        <div class="trv-why-card trv-reveal" style="transition-delay:<?php echo $i*.1;?>s">
            <div class="trv-why-icon" aria-hidden="true"><?php echo $why['icon']; ?></div>
            <h3 class="trv-why-title"><?php echo esc_html($why['title']); ?></h3>
            <p class="trv-why-desc"><?php echo esc_html($why['desc']); ?></p>
        </div>
        <?php endforeach; ?>
    </div>

</div>
</section>

<!-- ═══════════════════════════════════════════════════
     STATS
═══════════════════════════════════════════════════ -->
<section class="trv-stats" aria-label="Travel statistics">
<div class="trv-wrap">
    <div class="trv-stats-grid">
        <?php foreach ( $stats as $i => $st ) : ?>
        <div class="trv-reveal" style="transition-delay:<?php echo $i*.1;?>s;text-align:center">
            <span class="trv-stat-val" data-target="<?php echo esc_attr($st['val']); ?>" data-suffix="<?php echo esc_attr($st['suffix']); ?>">0</span>
            <span class="trv-stat-label"><?php echo esc_html($st['label']); ?></span>
        </div>
        <?php endforeach; ?>
    </div>
</div>
</section>

<!-- ═══════════════════════════════════════════════════
     TESTIMONIALS
═══════════════════════════════════════════════════ -->
<section class="trv-testimonials" aria-labelledby="trv-test-title">
<div class="trv-wrap">

    <div class="trv-test-header trv-reveal">
        <span class="trv-eyebrow">Traveller stories</span>
        <h2 class="trv-h2" id="trv-test-title">What our <em>travellers</em> say</h2>
    </div>

    <div class="trv-test-grid">
        <?php foreach ( $testimonials as $i => $t ) : ?>
        <blockquote class="trv-test-card trv-reveal" style="transition-delay:<?php echo $i*.12;?>s">
            <div class="trv-test-flag" aria-hidden="true"></div>
            <div class="trv-test-stars" aria-label="<?php echo $t['stars']; ?> stars"><?php echo str_repeat('★', $t['stars']); ?></div>
            <div class="trv-test-route"><?php echo esc_html($t['route']); ?></div>
            <p class="trv-test-quote">"<?php echo esc_html($t['quote']); ?>"</p>
            <footer class="trv-test-author">
                <div class="trv-test-avatar" style="background:<?php echo esc_attr($t['col']); ?>"><?php echo esc_html($t['avatar']); ?></div>
                <div class="trv-test-name"><?php echo esc_html($t['name']); ?></div>
            </footer>
        </blockquote>
        <?php endforeach; ?>
    </div>

</div>
</section>

<!-- ═══════════════════════════════════════════════════
     BOOKING / ENQUIRY
═══════════════════════════════════════════════════ -->
<section id="booking" class="trv-booking" aria-labelledby="trv-booking-title">
<div class="trv-wrap">
<div class="trv-booking-inner">

    <!-- Info -->
    <div class="trv-reveal">
        <span class="trv-eyebrow">Plan your trip</span>
        <h2 class="trv-h2 light" id="trv-booking-title">Ready to <em>start exploring?</em></h2>
        <p class="trv-lead light">Tell us about your dream trip. Our specialists will craft a personalised itinerary and quote within 48 hours.</p>
        <div class="trv-booking-steps">
            <div class="trv-booking-step">
                <div class="trv-step-num">1</div>
                <div class="trv-step-text">
                    <strong>Send your enquiry</strong>
                    <span>Tell us where, when and how you like to travel</span>
                </div>
            </div>
            <div class="trv-booking-step">
                <div class="trv-step-num">2</div>
                <div class="trv-step-text">
                    <strong>Consultation call</strong>
                    <span>We dive deep into your dream trip in a 30-min call</span>
                </div>
            </div>
            <div class="trv-booking-step">
                <div class="trv-step-num">3</div>
                <div class="trv-step-text">
                    <strong>Bespoke proposal</strong>
                    <span>Receive a detailed, costed itinerary — no obligation</span>
                </div>
            </div>
            <div class="trv-booking-step">
                <div class="trv-step-num">4</div>
                <div class="trv-step-text">
                    <strong>Travel &amp; enjoy</strong>
                    <span>We handle everything — you focus on the adventure</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Form -->
    <div class="trv-form-card trv-reveal">
        <form method="post" action="" novalidate>
            <?php wp_nonce_field( 'tf_trv_enquiry', 'tf_trv_nonce' ); ?>

            <div class="trv-form-row">
                <div class="trv-field">
                    <label for="trv-name">Full Name *</label>
                    <input type="text" id="trv-name" name="trv_name" required placeholder="Anna Müller" autocomplete="name">
                </div>
                <div class="trv-field">
                    <label for="trv-email">Email *</label>
                    <input type="email" id="trv-email" name="trv_email" required placeholder="anna@example.de" autocomplete="email">
                </div>
            </div>

            <div class="trv-form-row">
                <div class="trv-field">
                    <label for="trv-phone">Phone</label>
                    <input type="tel" id="trv-phone" name="trv_phone" placeholder="+49 40 123 456" autocomplete="tel">
                </div>
                <div class="trv-field">
                    <label for="trv-travellers">No. of Travellers *</label>
                    <select id="trv-travellers" name="trv_travellers" required>
                        <option value="">Please select…</option>
                        <option value="solo">Solo (1)</option>
                        <option value="couple">Couple (2)</option>
                        <option value="small">Small Group (3–5)</option>
                        <option value="family">Family (with children)</option>
                        <option value="large">Larger Group (6+)</option>
                    </select>
                </div>
            </div>

            <div class="trv-form-row">
                <div class="trv-field">
                    <label for="trv-destination">Destination(s)</label>
                    <input type="text" id="trv-destination" name="trv_destination" placeholder="e.g. Japan, Peru, Maldives…">
                </div>
                <div class="trv-field">
                    <label for="trv-budget">Budget per person</label>
                    <select id="trv-budget" name="trv_budget">
                        <option value="">Prefer not to say</option>
                        <option value="u2000">Under € 2,000</option>
                        <option value="2000-4000">€ 2,000 – 4,000</option>
                        <option value="4000-8000">€ 4,000 – 8,000</option>
                        <option value="8000+">Over € 8,000</option>
                    </select>
                </div>
            </div>

            <div class="trv-form-row">
                <div class="trv-field">
                    <label for="trv-depart">Departure From</label>
                    <input type="text" id="trv-depart" name="trv_depart" placeholder="e.g. Frankfurt, Hamburg">
                </div>
                <div class="trv-field">
                    <label for="trv-when">Preferred Travel Period</label>
                    <input type="text" id="trv-when" name="trv_when" placeholder="e.g. April 2026, flexible">
                </div>
            </div>

            <div class="trv-field">
                <label for="trv-message">Tell us about your dream trip *</label>
                <textarea id="trv-message" name="trv_message" required rows="4" placeholder="What kind of experience are you looking for? Any special occasions, interests, pace preferences or must-haves?"></textarea>
            </div>

            <button type="submit" class="trv-btn trv-btn--coral trv-form-submit">Send Enquiry ✈</button>
            <p class="trv-form-note">We respond within 48 hours. Your details are held securely and never shared.</p>
        </form>
    </div>

</div>
</div>
</section>

</div><!-- /.trv-page -->

<script>
(function(){
'use strict';

/* ── Tour filter ─── */
const filterBtns = document.querySelectorAll('.trv-filter-btn');
const tourCards  = document.querySelectorAll('.trv-tour-card');

filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        const filter = btn.dataset.filter;
        filterBtns.forEach(b => { b.classList.remove('active'); b.setAttribute('aria-pressed','false'); });
        btn.classList.add('active');
        btn.setAttribute('aria-pressed','true');
        tourCards.forEach(card => {
            const match = filter === 'all' || card.dataset.cat === filter;
            card.classList.toggle('hidden', !match);
        });
    });
});

/* ── Scroll reveal ─── */
const reveals = document.querySelectorAll('.trv-reveal');
const revealObs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
        if (!e.isIntersecting) return;
        const delay = (parseFloat(e.target.style.transitionDelay) || 0) * 1000;
        setTimeout(() => e.target.classList.add('visible'), delay);
        revealObs.unobserve(e.target);
    });
}, { threshold: 0.08 });
reveals.forEach(el => revealObs.observe(el));

/* ── Animated counters ─── */
const counters = document.querySelectorAll('.trv-stat-val[data-target]');
const easeOut  = t => 1 - Math.pow(1 - t, 3);
const cObs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
        if (!e.isIntersecting) return;
        cObs.unobserve(e.target);
        const el = e.target;
        const target = parseInt(el.dataset.target, 10);
        const suffix = el.dataset.suffix || '';
        const duration = 1800;
        let start = null;
        const tick = (ts) => {
            if (!start) start = ts;
            const progress = Math.min((ts - start) / duration, 1);
            el.textContent = Math.round(easeOut(progress) * target) + suffix;
            if (progress < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
    });
}, { threshold: 0.4 });
counters.forEach(el => cObs.observe(el));

})();
</script>
</div><!-- .trv-page -->
<?php get_footer(); ?>
</div>
</html>
