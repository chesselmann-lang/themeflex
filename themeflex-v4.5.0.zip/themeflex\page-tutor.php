<?php
/**
 * Template Name: Private Tutor
 *
 * Premium landing page for a private tutor / academic coaching service.
 * CSS art: animated chalkboard scene with handwritten equations, floating
 * subject bubbles, animated grade trajectory graph, and a glowing star constellation.
 *
 * Namespace   : --tu-*
 * Fonts       : Playfair Display (headings) + Fira Sans (body) + Fira Code (accents)
 * Palette     : deep slate #1E2A3B / chalk white #F5F0E8 / warm amber #F5A623
 *               forest green #2E7D52 / soft blue #4A90D9 / dusty rose #C07070
 * Keyframes   : tu-chalk-draw, tu-float-subject, tu-star-twinkle,
 *               tu-grade-rise, tu-pulse-ring, tu-drift-up, tu-slide-in
 *
 * @package ThemeFlex
 */
srand( crc32( get_the_permalink() ) );

/* ── tutor info ──────────────────────────────────────────── */
$tu_tutor      = 'Dr. Hannah Clarke';
$tu_credential = 'PhD (Mathematics) · Oxford Postgrad · Qualified Teacher';
$tu_years      = 14;
$tu_location   = 'Oxford & Online';
$tu_phone      = '01865 742 319';
$tu_email      = 'hannah@clarketutoring.co.uk';

/* ── subjects ─────────────────────────────────────────────── */
$tu_subjects = [
    [ 'icon' => '📐', 'name' => 'Mathematics',       'levels' => 'GCSE · A-Level · Degree' ],
    [ 'icon' => '🔬', 'name' => 'Physics',            'levels' => 'GCSE · A-Level · IB' ],
    [ 'icon' => '⚗️', 'name' => 'Chemistry',          'levels' => 'GCSE · A-Level · IB' ],
    [ 'icon' => '💻', 'name' => 'Computer Science',   'levels' => 'GCSE · A-Level · Python' ],
    [ 'icon' => '📊', 'name' => 'Statistics',         'levels' => 'A-Level · University' ],
    [ 'icon' => '🎓', 'name' => 'University Maths',   'levels' => 'First & Second Year' ],
    [ 'icon' => '📝', 'name' => 'Exam Technique',     'levels' => 'All Subjects' ],
    [ 'icon' => '🚀', 'name' => 'Oxbridge Prep',      'levels' => 'MAT · STEP · PAT' ],
];

/* ── floating chalkboard equations ─────────────────────────── */
$tu_equations = [
    'E = mc²', 'f\'(x) = lim_{h→0}', 'ax² + bx + c = 0', 'e^{iπ} + 1 = 0',
    'PV = nRT', '∫∫ dA', 'F = ma', 'sin²θ + cos²θ = 1',
    '∇²φ = 0', 'Σ_{n=1}^{∞}', '∂f/∂x', 'λ = h/mv',
    'det(A)', 'lim_{x→∞}', 'p = mv', 'dy/dx',
];
$tu_floaters = [];
for ( $i = 0; $i < 16; $i++ ) {
    $tu_floaters[] = [
        'eq'       => $tu_equations[ $i % count($tu_equations) ],
        'left'     => rand( 2, 95 ),
        'top'      => rand( 5, 90 ),
        'delay'    => round( rand( 0, 8000 ) / 1000, 2 ),
        'duration' => round( rand( 7000, 14000 ) / 1000, 2 ),
        'opacity'  => round( rand( 10, 30 ) / 100, 2 ),
        'size'     => rand( 11, 16 ),
    ];
}

/* ── grade chart data (student progress) ─────────────────── */
$tu_grade_data = [ 42, 51, 58, 63, 70, 74, 79, 85, 88, 91, 94 ];

/* ── star positions (constellation) ─────────────────────── */
$tu_stars = [];
for ( $i = 0; $i < 24; $i++ ) {
    $tu_stars[] = [
        'x'      => rand( 5, 95 ),
        'y'      => rand( 5, 85 ),
        'size'   => rand( 1, 4 ),
        'delay'  => round( rand( 0, 5000 ) / 1000, 2 ),
    ];
}

/* ── boards (chalkboard subjects) ─────────────────────────── */
$tu_chalkboard_lines = [
    'x = (-b ± √(b²-4ac)) / 2a',
    '∫ sin(x) dx = -cos(x) + C',
    'F = G·m₁m₂ / r²',
    'E_k = ½mv²',
];

/* ── process steps ───────────────────────────────────────── */
$tu_steps = [
    [ 'num' => '01', 'title' => 'Free Assessment',  'desc' => 'A no-obligation 30-minute session to understand your starting point, learning style and goals.' ],
    [ 'num' => '02', 'title' => 'Tailored Plan',    'desc' => 'A bespoke study plan covering topics, resources and timing around your school or university timetable.' ],
    [ 'num' => '03', 'title' => 'Weekly Sessions',  'desc' => 'Live 1-to-1 sessions via video or in person — working through concepts, problems and past papers.' ],
    [ 'num' => '04', 'title' => 'Track Progress',   'desc' => 'Regular progress reports, mock exam marking and adjustments to the plan as exam dates approach.' ],
];

/* ── testimonials ─────────────────────────────────────────── */
$tu_testimonials = [
    [ 'name' => 'James T. (Parent)', 'stars' => 5, 'text' => 'Our son went from a predicted D to an A* in Maths. Hannah's ability to explain concepts differently until they click is extraordinary.' ],
    [ 'name' => 'Sophie H. (Student)', 'stars' => 5, 'text' => 'I was dreading A-Level Further Maths but Hannah made it feel manageable. Got an A and feel confident for university.' ],
    [ 'name' => 'Richard M. (Parent)', 'stars' => 5, 'text' => 'Hannah prepared our daughter for the Oxford PAT and the STEP paper. She was accepted to Cambridge to read Maths. Cannot thank her enough.' ],
    [ 'name' => 'Emily L. (Student)', 'stars' => 5, 'text' => 'Three sessions before my Physics GCSE and I jumped two full grades. Hannah knows exactly which exam technique to use for each question type.' ],
    [ 'name' => 'Patrick C. (Parent)', 'stars' => 5, 'text' => 'Hannah tutored both our children in A-Level Chemistry over two years. Both achieved A*. Her exam knowledge and patience are unmatched.' ],
    [ 'name' => 'Olivia S. (Student)', 'stars' => 5, 'text' => 'I was struggling with first-year university Statistics. Hannah rebuilt my foundations in a few sessions and I passed with distinction.' ],
];

/* ── packages ──────────────────────────────────────────────── */
$tu_packages = [
    [
        'name'     => 'GCSE Booster',
        'price'    => '£55',
        'unit'     => 'per hour',
        'featured' => false,
        'colour'   => '#4A90D9',
        'items'    => [
            '1-to-1 online or in-person sessions',
            'Subject-specific study plan',
            'Past paper practice & marking',
            'Exam technique coaching',
            'Session notes provided',
        ],
    ],
    [
        'name'     => 'A-Level Mastery',
        'price'    => '£75',
        'unit'     => 'per hour',
        'featured' => true,
        'colour'   => '#1E2A3B',
        'items'    => [
            'All GCSE Booster features',
            'Module-by-module deep dives',
            'Weekly homework & marking',
            'Mock exam scheduling',
            'Parent progress reports',
            'WhatsApp Q&A support',
            'Free initial assessment',
        ],
    ],
    [
        'name'     => 'Oxbridge Prep',
        'price'    => '£95',
        'unit'     => 'per hour',
        'featured' => false,
        'colour'   => '#2E7D52',
        'items'    => [
            'MAT · STEP · PAT preparation',
            'Interview coaching & mock',
            'Personal statement review',
            'University application strategy',
            'Advanced problem-solving techniques',
        ],
    ],
];

/* ── FAQ ──────────────────────────────────────────────────── */
$tu_faqs = [
    [ 'q' => 'Do you tutor online or in person?',
      'a' => 'Both! I offer in-person sessions in Oxford and the surrounding area, and online sessions via Zoom with an interactive digital whiteboard for students anywhere in the UK.' ],
    [ 'q' => 'How many sessions per week do you recommend?',
      'a' => 'For steady improvement, one or two sessions per week works well. In the run-up to exams (final 6 weeks), intensive programmes of 3–4 sessions per week are very effective.' ],
    [ 'q' => 'Which exam boards do you cover?',
      'a' => 'All major boards — AQA, Edexcel, OCR, MEI, Cambridge and Eduqas. I'm also experienced with the IB curriculum (Standard and Higher Level) and Scottish Highers.' ],
    [ 'q' => 'What if my child isn't making progress?',
      'a' => 'Progress is tracked after every session. If we're not seeing movement, I adjust the approach. I've never had a student not improve with consistent attendance — but if needed I'll refer to a colleague who may be a better fit.' ],
    [ 'q' => 'Can I book a free trial session?',
      'a' => 'Yes — I offer a complimentary 30-minute assessment session for all new students. This lets us both see whether we're a good fit before committing to a programme.' ],
    [ 'q' => 'Do you provide resources and materials?',
      'a' => 'Yes. I supply topic summary sheets, past paper packs, worked solutions, and — for online students — a recorded session replay they can rewatch before exams.' ],
];

/* ── exam boards ──────────────────────────────────────────── */
$tu_boards = [ 'AQA', 'Edexcel', 'OCR', 'MEI', 'Cambridge IGCSE', 'IB', 'Scottish Highers', 'Eduqas', 'WJEC', 'STEP I/II/III', 'MAT', 'PAT', 'TMUA' ];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=Fira+Sans:wght@300;400;500;600&family=Fira+Code:wght@400;500&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════════
   PRIVATE TUTOR  –  --tu-* token namespace
═══════════════════════════════════════════════════════════ */
:root {
  --tu-slate:       #1E2A3B;
  --tu-slate-2:     #263347;
  --tu-chalk:       #F5F0E8;
  --tu-amber:       #F5A623;
  --tu-amber-dark:  #D48A10;
  --tu-green:       #2E7D52;
  --tu-green-light: #3EA06A;
  --tu-blue:        #4A90D9;
  --tu-blue-light:  #6AADF0;
  --tu-rose:        #C07070;
  --tu-grey:        #7A8899;
  --tu-grey-light:  #B0BCC8;
  --tu-bg:          #F7F5F0;
  --tu-card-bg:     #FFFFFF;
  --tu-border:      rgba(30,42,59,0.1);
  --tu-font-head:   'Playfair Display', Georgia, serif;
  --tu-font-body:   'Fira Sans', sans-serif;
  --tu-font-mono:   'Fira Code', monospace;
  --tu-radius:      12px;
  --tu-transition:  0.32s ease;
}

*,*::before,*::after { box-sizing:border-box; margin:0; padding:0; }
.tu-page { font-family:var(--tu-font-body); color:var(--tu-slate); background:var(--tu-bg); overflow-x:hidden; }
.tu-page a { color:var(--tu-blue); text-decoration:none; }

/* ── keyframes ── */
@keyframes tu-float-subject {
  0%,100% { transform:translateY(0) rotate(-2deg); opacity:var(--tu-fo,0.2); }
  50%     { transform:translateY(-22px) rotate(2deg); opacity:calc(var(--tu-fo,0.2)+0.1); }
}
@keyframes tu-star-twinkle {
  0%,100% { opacity:0.3; transform:scale(1); }
  50%     { opacity:1; transform:scale(1.6); }
}
@keyframes tu-pulse-ring {
  0%   { transform:translate(-50%,-50%) scale(0.8); opacity:0.8; }
  100% { transform:translate(-50%,-50%) scale(2); opacity:0; }
}
@keyframes tu-drift-up {
  0%   { transform:translateY(0); opacity:0; }
  10%  { opacity:0.8; }
  90%  { opacity:0.6; }
  100% { transform:translateY(-80px); opacity:0; }
}
@keyframes tu-slide-up { from{opacity:0;transform:translateY(40px);} to{opacity:1;transform:translateY(0);} }
@keyframes tu-fade-in  { from{opacity:0;} to{opacity:1;} }
@keyframes tu-chalk-blink { 0%,100%{opacity:1;} 50%{opacity:0;} }
@keyframes tu-grade-line { from{stroke-dashoffset:800;} to{stroke-dashoffset:0;} }

/* ══ NAV ═════════════════════════════════════════════════ */
.tu-nav {
  position:fixed; top:0; left:0; width:100%; z-index:1000;
  background:rgba(30,42,59,0.95); backdrop-filter:blur(14px);
  border-bottom:1px solid rgba(245,166,35,0.2);
  display:flex; align-items:center; justify-content:space-between;
  padding:0 44px; height:68px;
}
.tu-nav__logo { font-family:var(--tu-font-head); font-size:1.45rem; color:var(--tu-chalk); }
.tu-nav__logo span { color:var(--tu-amber); }
.tu-nav__links { display:flex; gap:28px; list-style:none; }
.tu-nav__links a { color:rgba(245,240,232,0.8); font-size:0.88rem; font-weight:500; transition:color var(--tu-transition); }
.tu-nav__links a:hover { color:var(--tu-amber); }
.tu-nav__cta { background:var(--tu-amber); color:var(--tu-slate); padding:10px 24px; border-radius:8px; font-size:0.88rem; font-weight:700; transition:all var(--tu-transition); }
.tu-nav__cta:hover { background:var(--tu-amber-dark); color:var(--tu-slate); }

/* ══ HERO ════════════════════════════════════════════════ */
.tu-hero {
  min-height:100vh; display:flex; align-items:center;
  background:linear-gradient(150deg, var(--tu-slate) 0%, #111A28 60%, #0D1520 100%);
  position:relative; overflow:hidden; padding:100px 44px 60px;
}
.tu-hero__stars { position:absolute; inset:0; pointer-events:none; z-index:0; }
.tu-star {
  position:absolute; background:#fff; border-radius:50%;
  animation:tu-star-twinkle var(--tu-sd,3s) var(--tu-sdelay,0s) infinite ease-in-out;
}
.tu-hero__equations { position:absolute; inset:0; pointer-events:none; z-index:1; }
.tu-eq {
  position:absolute; font-family:var(--tu-font-mono); font-size:var(--tu-es,13px);
  color:rgba(245,240,232,var(--tu-fo,0.15));
  animation:tu-float-subject var(--tu-fd,10s) var(--tu-fdelay,0s) infinite ease-in-out;
  user-select:none; white-space:nowrap;
  --tu-fo: var(--tu-eop,0.15);
}
.tu-hero__inner { position:relative; z-index:2; display:grid; grid-template-columns:1fr 480px; gap:56px; align-items:center; max-width:1280px; margin:0 auto; width:100%; }

/* TEXT */
.tu-hero__text { animation:tu-slide-up 0.8s ease both; }
.tu-hero__badge { display:inline-flex; align-items:center; gap:8px; background:rgba(245,166,35,0.15); border:1px solid rgba(245,166,35,0.35); color:var(--tu-amber); padding:6px 16px; border-radius:6px; font-size:0.75rem; font-weight:700; letter-spacing:0.08em; text-transform:uppercase; font-family:var(--tu-font-mono); margin-bottom:24px; }
.tu-hero__eyebrow { font-family:var(--tu-font-head); font-style:italic; color:var(--tu-grey-light); font-size:1.05rem; margin-bottom:12px; }
.tu-hero__title { font-family:var(--tu-font-head); font-size:clamp(2.6rem,4.5vw,4rem); font-weight:700; color:var(--tu-chalk); line-height:1.14; margin-bottom:20px; }
.tu-hero__title em { color:var(--tu-amber); font-style:italic; }
.tu-hero__subtitle { font-size:1.05rem; color:rgba(245,240,232,0.75); line-height:1.78; max-width:500px; margin-bottom:36px; font-weight:300; }
.tu-hero__actions { display:flex; gap:16px; flex-wrap:wrap; margin-bottom:44px; }
.tu-btn-primary   { background:var(--tu-amber); color:var(--tu-slate); padding:16px 36px; border-radius:8px; font-size:0.97rem; font-weight:700; transition:all var(--tu-transition); box-shadow:0 8px 28px rgba(245,166,35,0.35); font-family:var(--tu-font-body); }
.tu-btn-primary:hover { background:var(--tu-amber-dark); color:var(--tu-slate); transform:translateY(-2px); }
.tu-btn-secondary { border:1.5px solid rgba(245,240,232,0.3); color:var(--tu-chalk); padding:14px 32px; border-radius:8px; font-size:0.97rem; font-weight:500; transition:all var(--tu-transition); }
.tu-btn-secondary:hover { border-color:var(--tu-chalk); }
.tu-hero__trust { display:flex; gap:20px; flex-wrap:wrap; }
.tu-trust-item { display:flex; align-items:center; gap:7px; color:rgba(245,240,232,0.65); font-size:0.82rem; font-family:var(--tu-font-mono); }
.tu-trust-item::before { content:'✓'; color:var(--tu-amber); }

/* CHALKBOARD SCENE */
.tu-chalkboard-wrap { width:480px; animation:tu-fade-in 1s 0.4s ease both; }
.tu-chalkboard {
  width:100%; aspect-ratio:4/3; background:#2A4A2A;
  border:8px solid #5C3A1E; border-radius:8px;
  box-shadow:0 20px 60px rgba(0,0,0,0.5), inset 0 0 40px rgba(0,0,0,0.3);
  position:relative; overflow:hidden; padding:24px;
  display:flex; flex-direction:column; justify-content:center;
}
/* chalk dust texture */
.tu-chalkboard::before {
  content:''; position:absolute; inset:0;
  background:repeating-linear-gradient(
    90deg, transparent, transparent 2px, rgba(255,255,255,0.015) 2px, rgba(255,255,255,0.015) 4px
  );
  pointer-events:none;
}
.tu-chalkboard__line {
  font-family:var(--tu-font-mono); font-size:1.05rem;
  color:rgba(245,240,232,0.88); margin-bottom:18px; position:relative;
  overflow:hidden; white-space:nowrap;
}
.tu-chalkboard__line::after {
  content:''; position:absolute; right:-2px; top:0; bottom:0; width:2px;
  background:var(--tu-chalk); animation:tu-chalk-blink 0.9s step-end infinite;
}
.tu-chalkboard__line:not(:last-child)::after { display:none; }
.tu-chalkboard__tray {
  position:absolute; bottom:0; left:0; right:0; height:18px;
  background:#5C3A1E; border-radius:0 0 2px 2px;
  display:flex; align-items:center; padding:0 16px; gap:8px;
}
.tu-chalk-stick {
  height: 8px; border-radius: 3px;
  background: rgba(245,240,232,0.8);
}
/* grade chart inside chalkboard */
.tu-grade-chart { margin-top:16px; }
.tu-grade-chart svg { width:100%; height:90px; overflow:visible; }
.tu-grade-line { stroke:var(--tu-amber); stroke-width:2; fill:none; stroke-dasharray:800; animation:tu-grade-line 2s 1s ease forwards; }
.tu-grade-area { fill:rgba(245,166,35,0.15); }
.tu-grade-dots circle { fill:var(--tu-amber); }
.tu-grade-label { font-family:var(--tu-font-mono); font-size:0.6rem; fill:rgba(245,240,232,0.7); }

/* ══ COUNTERS ════════════════════════════════════════════ */
.tu-counters { background:var(--tu-slate); padding:56px 44px; }
.tu-counters__grid { display:grid; grid-template-columns:repeat(4,1fr); gap:2px; max-width:960px; margin:0 auto; }
.tu-counter-item { text-align:center; padding:36px 20px; background:rgba(255,255,255,0.04); border-radius:4px; }
.tu-counter-item:hover { background:rgba(245,166,35,0.08); }
.tu-counter-number { font-family:var(--tu-font-head); font-size:3rem; font-weight:700; color:var(--tu-chalk); display:flex; align-items:baseline; justify-content:center; gap:4px; }
.tu-counter-number .tu-suffix { font-size:1.7rem; color:var(--tu-amber); }
.tu-counter-label { color:var(--tu-grey-light); font-size:0.82rem; margin-top:6px; font-family:var(--tu-font-mono); }

/* ══ SUBJECTS ════════════════════════════════════════════ */
.tu-subjects { padding:100px 44px; background:var(--tu-bg); }
.tu-section-header { text-align:center; margin-bottom:60px; }
.tu-eyebrow { font-family:var(--tu-font-mono); font-size:0.78rem; color:var(--tu-blue); letter-spacing:0.1em; text-transform:uppercase; margin-bottom:14px; }
.tu-section-title { font-family:var(--tu-font-head); font-size:clamp(1.9rem,3.5vw,2.8rem); color:var(--tu-slate); margin-bottom:14px; font-weight:700; }
.tu-section-desc { color:var(--tu-grey); font-size:1rem; max-width:580px; margin:0 auto; line-height:1.75; }
.tu-subjects__grid { display:grid; grid-template-columns:repeat(4,1fr); gap:20px; max-width:1240px; margin:0 auto; }
.tu-subject-card {
  background:var(--tu-card-bg); border:1px solid var(--tu-border); border-radius:var(--tu-radius);
  padding:28px 22px; text-align:center; transition:all var(--tu-transition); position:relative; overflow:hidden;
}
.tu-subject-card::before {
  content:''; position:absolute; top:0; left:0; right:0; height:3px;
  background:linear-gradient(90deg, var(--tu-blue), var(--tu-amber));
  transform:scaleX(0); transform-origin:left; transition:transform var(--tu-transition);
}
.tu-subject-card:hover { transform:translateY(-6px); box-shadow:0 16px 44px rgba(30,42,59,0.1); border-color:rgba(74,144,217,0.3); }
.tu-subject-card:hover::before { transform:scaleX(1); }
.tu-subject-icon { font-size:2.2rem; margin-bottom:14px; }
.tu-subject-name { font-family:var(--tu-font-head); font-size:1.15rem; color:var(--tu-slate); margin-bottom:6px; font-weight:600; }
.tu-subject-levels { font-family:var(--tu-font-mono); font-size:0.72rem; color:var(--tu-blue); letter-spacing:0.04em; }

/* ══ EXAM BOARDS ═════════════════════════════════════════ */
.tu-boards { padding:60px 44px; background:#EEE9E0; }
.tu-boards__tags { display:flex; flex-wrap:wrap; gap:12px; justify-content:center; max-width:800px; margin:0 auto; }
.tu-board-tag {
  background:var(--tu-card-bg); border:1px solid var(--tu-border); color:var(--tu-slate);
  padding:8px 20px; border-radius:24px; font-size:0.88rem; font-family:var(--tu-font-mono);
  font-weight:500; transition:all var(--tu-transition);
}
.tu-board-tag:hover { background:var(--tu-slate); color:var(--tu-chalk); border-color:var(--tu-slate); }

/* ══ PROCESS ═════════════════════════════════════════════ */
.tu-process { padding:100px 44px; background:var(--tu-bg); }
.tu-process__steps { display:grid; grid-template-columns:repeat(4,1fr); gap:32px; max-width:1200px; margin:0 auto; position:relative; }
.tu-process__steps::before {
  content:''; position:absolute; top:36px; left:80px; right:80px; height:2px;
  background:linear-gradient(90deg, var(--tu-blue), var(--tu-amber));
}
.tu-step { text-align:center; }
.tu-step-num {
  width:72px; height:72px; border-radius:50%; background:var(--tu-slate); color:var(--tu-chalk);
  font-family:var(--tu-font-mono); font-size:1.3rem; font-weight:500;
  display:flex; align-items:center; justify-content:center; margin:0 auto 18px;
  border:3px solid var(--tu-amber); position:relative; z-index:1; transition:all var(--tu-transition);
}
.tu-step:hover .tu-step-num { background:var(--tu-amber); color:var(--tu-slate); border-color:var(--tu-slate); }
.tu-step-title { font-family:var(--tu-font-head); font-size:1.1rem; color:var(--tu-slate); margin-bottom:8px; font-weight:600; }
.tu-step-desc  { color:var(--tu-grey); font-size:0.87rem; line-height:1.65; }

/* ══ PACKAGES ════════════════════════════════════════════ */
.tu-packages { padding:100px 44px; background:#EEE9E0; }
.tu-packages__grid { display:grid; grid-template-columns:repeat(3,1fr); gap:24px; max-width:1080px; margin:0 auto; align-items:start; }
.tu-package-card {
  border-radius:18px; overflow:hidden;
  box-shadow:0 8px 36px rgba(30,42,59,0.1);
  background:var(--tu-card-bg); transition:transform var(--tu-transition);
}
.tu-package-card:hover { transform:translateY(-7px); }
.tu-package-card--featured { transform:scale(1.04); box-shadow:0 20px 60px rgba(30,42,59,0.18); }
.tu-package-card--featured:hover { transform:scale(1.04) translateY(-7px); }
.tu-package-header { padding:32px 28px; color:#fff; background:var(--tu-card-colour,var(--tu-slate)); }
.tu-package-badge { display:inline-block; background:rgba(255,255,255,0.2); color:#fff; padding:4px 12px; border-radius:16px; font-size:0.7rem; font-weight:700; letter-spacing:0.08em; text-transform:uppercase; font-family:var(--tu-font-mono); margin-bottom:14px; }
.tu-package-name  { font-family:var(--tu-font-head); font-size:1.5rem; font-weight:700; margin-bottom:8px; }
.tu-package-price { font-family:var(--tu-font-head); font-size:2.6rem; font-weight:300; }
.tu-package-unit  { font-size:0.82rem; opacity:0.75; margin-top:4px; font-family:var(--tu-font-mono); }
.tu-package-body  { padding:24px 28px; }
.tu-package-features { list-style:none; margin-bottom:24px; }
.tu-package-features li { padding:9px 0; border-bottom:1px solid var(--tu-border); font-size:0.88rem; color:var(--tu-grey); display:flex; gap:10px; }
.tu-package-features li::before { content:'✓'; color:var(--tu-green); font-weight:700; flex-shrink:0; }
.tu-package-features li:last-child { border-bottom:none; }
.tu-package-btn {
  display:block; width:100%; padding:14px; border-radius:8px; text-align:center;
  font-weight:700; font-size:0.9rem; font-family:var(--tu-font-body);
  border:2px solid var(--tu-card-colour,var(--tu-slate));
  color:var(--tu-card-colour,var(--tu-slate)); background:transparent;
  cursor:pointer; transition:all var(--tu-transition);
}
.tu-package-btn:hover,
.tu-package-card--featured .tu-package-btn { background:var(--tu-card-colour,var(--tu-slate)); color:#fff; }

/* ══ PROFILE ═════════════════════════════════════════════ */
.tu-profile { padding:100px 44px; background:var(--tu-bg); }
.tu-profile__inner { max-width:1080px; margin:0 auto; display:grid; grid-template-columns:280px 1fr; gap:80px; align-items:center; }
.tu-profile__figure {
  width:200px; height:260px; position:relative; margin:0 auto 24px;
  background:linear-gradient(150deg,#263347 0%,#1E2A3B 100%);
  border-radius:50% 50% 40% 40%; box-shadow:0 16px 50px rgba(30,42,59,0.25);
}
/* head */
.tu-profile__figure::before {
  content:''; position:absolute; top:-58px; left:50%; transform:translateX(-50%);
  width:82px; height:88px; border-radius:50%;
  background:linear-gradient(145deg,#F5DEB3 0%,#DEB887 100%);
}
/* hair bun */
.tu-profile__figure-hair {
  position:absolute; top:-76px; left:50%; transform:translateX(-50%);
  width:86px; height:52px; border-radius:50% 50% 0 0; background:#4A3520;
}
/* gown / academic robe */
.tu-profile__figure-gown {
  position:absolute; inset:0; border-radius:50% 50% 40% 40%;
  background:rgba(30,42,59,0.7); border:2px solid rgba(245,166,35,0.3);
}
/* mortarboard */
.tu-profile__figure-hat {
  position:absolute; top:-96px; left:50%; transform:translateX(-50%);
  width:90px; height:14px; background:var(--tu-slate); border-radius:2px;
}
.tu-profile__figure-hat::before {
  content:''; position:absolute; top:-10px; left:50%; transform:translateX(-50%);
  width:44px; height:10px; background:var(--tu-slate); border-radius:2px;
}
.tu-profile__figure-hat::after {
  content:''; position:absolute; top:-16px; right:0; width:8px; height:24px;
  background:var(--tu-amber); border-radius:4px; transform:rotate(10deg);
}
/* chalk hand */
.tu-profile__figure-hand {
  position:absolute; bottom:24px; right:10px; width:36px; height:26px;
  border-radius:50%; background:linear-gradient(135deg,#F5DEB3 0%,#DEB887 100%);
}
.tu-profile__figure-chalk {
  position:absolute; bottom:20px; right:4px; width:6px; height:32px;
  background:rgba(245,240,232,0.9); border-radius:3px; transform:rotate(25deg);
}
.tu-profile__cred {
  background:var(--tu-slate); color:var(--tu-chalk); padding:18px 24px;
  border-radius:12px; text-align:center; box-shadow:0 8px 28px rgba(30,42,59,0.2);
}
.tu-profile__cred-name  { font-family:var(--tu-font-head); font-size:1.2rem; margin-bottom:6px; }
.tu-profile__cred-title { font-family:var(--tu-font-mono); font-size:0.72rem; color:var(--tu-amber); }
.tu-profile__content h2 { font-family:var(--tu-font-head); font-size:2.3rem; color:var(--tu-slate); margin-bottom:18px; font-weight:700; }
.tu-profile__content p { color:var(--tu-grey); line-height:1.8; margin-bottom:14px; font-size:0.96rem; }
.tu-quals { display:flex; flex-wrap:wrap; gap:10px; margin-top:24px; }
.tu-qual-badge { background:rgba(74,144,217,0.1); border:1px solid rgba(74,144,217,0.3); color:var(--tu-blue); padding:6px 14px; border-radius:20px; font-size:0.8rem; font-family:var(--tu-font-mono); }

/* ══ TESTIMONIALS ════════════════════════════════════════ */
.tu-testimonials { padding:100px 44px; background:#EEE9E0; }
.tu-testimonials__grid { display:grid; grid-template-columns:repeat(3,1fr); gap:20px; max-width:1200px; margin:0 auto; }
.tu-testimonial-card {
  background:var(--tu-card-bg); border-radius:var(--tu-radius); padding:28px;
  box-shadow:0 4px 18px rgba(30,42,59,0.06); border-left:4px solid var(--tu-amber);
  transition:transform var(--tu-transition);
}
.tu-testimonial-card:hover { transform:translateY(-4px); }
.tu-stars { color:var(--tu-amber); font-size:0.9rem; margin-bottom:14px; letter-spacing:2px; }
.tu-testimonial-text { color:var(--tu-slate); font-size:0.9rem; line-height:1.75; font-style:italic; font-family:var(--tu-font-head); margin-bottom:16px; }
.tu-testimonial-name { color:var(--tu-blue); font-weight:600; font-size:0.82rem; font-family:var(--tu-font-mono); }

/* ══ FAQ ═════════════════════════════════════════════════ */
.tu-faq { padding:100px 44px; background:var(--tu-bg); }
.tu-faq__list { max-width:760px; margin:0 auto; }
.tu-faq-item { border-bottom:1px solid var(--tu-border); }
.tu-faq-q {
  width:100%; text-align:left; background:none; border:none; cursor:pointer;
  padding:20px 0; display:flex; justify-content:space-between; align-items:center;
  font-family:var(--tu-font-head); font-size:1.02rem; color:var(--tu-slate); font-weight:600; gap:16px;
}
.tu-faq-q svg { flex-shrink:0; color:var(--tu-amber); transition:transform 0.3s; }
.tu-faq-item.open .tu-faq-q svg { transform:rotate(45deg); }
.tu-faq-a { max-height:0; overflow:hidden; transition:max-height 0.4s ease; }
.tu-faq-a-inner { padding:0 0 18px; color:var(--tu-grey); line-height:1.8; font-size:0.92rem; }
.tu-faq-item.open .tu-faq-a { max-height:260px; }

/* ══ BOOKING ═════════════════════════════════════════════ */
.tu-booking { padding:100px 44px; background:linear-gradient(150deg,var(--tu-slate) 0%,#0D1520 100%); }
.tu-booking__inner { max-width:860px; margin:0 auto; }
.tu-booking .tu-section-title { color:var(--tu-chalk); }
.tu-booking .tu-eyebrow { color:var(--tu-amber); }
.tu-booking .tu-section-desc { color:rgba(245,240,232,0.7); }
.tu-booking-form {
  background:rgba(255,255,255,0.05); border:1px solid rgba(245,166,35,0.2);
  border-radius:18px; padding:44px; backdrop-filter:blur(10px); margin-top:44px;
}
.tu-form-grid  { display:grid; grid-template-columns:1fr 1fr; gap:18px; }
.tu-form-full  { grid-column:1/-1; }
.tu-form-group { display:flex; flex-direction:column; gap:8px; }
.tu-form-label { font-family:var(--tu-font-mono); color:rgba(245,240,232,0.6); font-size:0.74rem; letter-spacing:0.08em; text-transform:uppercase; }
.tu-form-input, .tu-form-select, .tu-form-textarea {
  background:rgba(255,255,255,0.06); border:1px solid rgba(245,166,35,0.2);
  border-radius:8px; padding:13px 16px; color:var(--tu-chalk);
  font-family:var(--tu-font-body); font-size:0.93rem;
  transition:border-color var(--tu-transition); width:100%;
}
.tu-form-input::placeholder, .tu-form-textarea::placeholder { color:rgba(245,240,232,0.35); }
.tu-form-input:focus, .tu-form-select:focus, .tu-form-textarea:focus { outline:none; border-color:var(--tu-amber); }
.tu-form-select option { background:var(--tu-slate); }
.tu-form-textarea { resize:vertical; min-height:100px; }
.tu-form-privacy { color:rgba(245,240,232,0.45); font-size:0.76rem; line-height:1.65; }
.tu-form-privacy a { color:var(--tu-amber); }
.tu-form-submit {
  background:var(--tu-amber); color:var(--tu-slate); border:none;
  padding:18px 52px; border-radius:8px; font-size:1rem; font-weight:700;
  font-family:var(--tu-font-body); cursor:pointer; transition:all var(--tu-transition);
  box-shadow:0 8px 28px rgba(245,166,35,0.35);
}
.tu-form-submit:hover { background:var(--tu-amber-dark); transform:translateY(-2px); }
.tu-form-message { padding:14px; border-radius:8px; margin-bottom:18px; font-size:0.88rem; display:none; font-family:var(--tu-font-mono); }
.tu-form-message.success { background:rgba(46,125,82,0.2); border:1px solid var(--tu-green); color:var(--tu-green-light); display:block; }
.tu-form-message.error   { background:rgba(192,112,112,0.2); border:1px solid var(--tu-rose); color:var(--tu-rose); display:block; }

/* ══ FOOTER ══════════════════════════════════════════════ */
.tu-footer { background:var(--tu-slate); border-top:1px solid rgba(245,166,35,0.15); padding:28px 44px; text-align:center; color:var(--tu-grey); font-family:var(--tu-font-mono); font-size:0.78rem; line-height:1.9; }
.tu-footer a { color:var(--tu-amber); }

/* ══ RESPONSIVE ══════════════════════════════════════════ */
@media (max-width:1100px) {
  .tu-subjects__grid { grid-template-columns:repeat(2,1fr); }
  .tu-hero__inner { grid-template-columns:1fr; }
  .tu-chalkboard-wrap { display:none; }
  .tu-profile__inner { grid-template-columns:1fr; text-align:center; }
}
@media (max-width:768px) {
  .tu-nav__links { display:none; }
  .tu-counters__grid, .tu-process__steps { grid-template-columns:repeat(2,1fr); }
  .tu-packages__grid, .tu-testimonials__grid { grid-template-columns:1fr; }
  .tu-package-card--featured { transform:none; }
  .tu-form-grid { grid-template-columns:1fr; }
  .tu-subjects__grid { grid-template-columns:1fr; }
}
</style>
<?php get_header(); ?>
<div class="tu-page">
>
<?php wp_body_open(); ?>

<!-- NAV -->
<nav class="tu-nav" role="navigation" aria-label="Main navigation">
  <div class="tu-nav__logo">Clarke<span>Tutoring</span></div>
  <ul class="tu-nav__links">
    <li><a href="#subjects">Subjects</a></li>
    <li><a href="#process">Process</a></li>
    <li><a href="#packages">Fees</a></li>
    <li><a href="#about">About</a></li>
    <li><a href="#booking">Book</a></li>
  </ul>
  <a href="#booking" class="tu-nav__cta">Free Assessment</a>
</nav>

<!-- HERO -->
<section class="tu-hero" aria-label="Hero">
  <!-- stars -->
  <div class="tu-hero__stars" aria-hidden="true">
    <?php foreach ( $tu_stars as $star ) : ?>
    <div class="tu-star" style="
      left:<?php echo $star['x']; ?>%;
      top:<?php echo $star['y']; ?>%;
      width:<?php echo $star['size']; ?>px;
      height:<?php echo $star['size']; ?>px;
      --tu-sd:<?php echo round(2 + ($star['size']) * 0.8, 1); ?>s;
      --tu-sdelay:<?php echo $star['delay']; ?>s;
    "></div>
    <?php endforeach; ?>
  </div>

  <!-- floating equations -->
  <div class="tu-hero__equations" aria-hidden="true">
    <?php foreach ( $tu_floaters as $fl ) : ?>
    <div class="tu-eq" style="
      left:<?php echo $fl['left']; ?>%;
      top:<?php echo $fl['top']; ?>%;
      --tu-fd:<?php echo $fl['duration']; ?>s;
      --tu-fdelay:<?php echo $fl['delay']; ?>s;
      --tu-eop:<?php echo $fl['opacity']; ?>;
      font-size:<?php echo $fl['size']; ?>px;
    "><?php echo esc_html($fl['eq']); ?></div>
    <?php endforeach; ?>
  </div>

  <div class="tu-hero__inner">
    <!-- TEXT -->
    <div class="tu-hero__text">
      <div class="tu-hero__badge">📚 Oxford · <?php echo $tu_years; ?> Years' Experience</div>
      <p class="tu-hero__eyebrow">Private Mathematics &amp; Science Tutor</p>
      <h1 class="tu-hero__title">
        Unlock Your<br>
        Full Academic<br>
        <em>Potential.</em>
      </h1>
      <p class="tu-hero__subtitle">
        Expert 1-to-1 tutoring from a Cambridge-qualified mathematician.
        GCSE to university level — online or in Oxford — with a
        track record of transforming grades and building genuine confidence.
      </p>
      <div class="tu-hero__actions">
        <a href="#booking" class="tu-btn-primary">Book Free Assessment →</a>
        <a href="#subjects" class="tu-btn-secondary">View Subjects</a>
      </div>
      <div class="tu-hero__trust">
        <span class="tu-trust-item">DBS Checked</span>
        <span class="tu-trust-item">All Exam Boards</span>
        <span class="tu-trust-item">Online &amp; In-Person</span>
        <span class="tu-trust-item">Parent Reports</span>
      </div>
    </div>

    <!-- CHALKBOARD -->
    <div class="tu-chalkboard-wrap" aria-hidden="true">
      <div class="tu-chalkboard">
        <?php foreach ( $tu_chalkboard_lines as $ci => $line ) : ?>
        <div class="tu-chalkboard__line" style="animation-delay:<?php echo $ci * 0.3; ?>s;">
          <?php echo esc_html($line); ?>
        </div>
        <?php endforeach; ?>
        <!-- animated grade chart -->
        <div class="tu-grade-chart">
          <?php
          $pts = $tu_grade_data;
          $count = count($pts);
          $w = 400; $h = 80;
          $min_v = min($pts); $max_v = max($pts);
          $range = $max_v - $min_v ?: 1;
          $coords = [];
          foreach ($pts as $pi => $pv) {
            $px = round(($pi / ($count - 1)) * $w);
            $py = round($h - (($pv - $min_v) / $range) * ($h - 10));
            $coords[] = "$px,$py";
          }
          $polyline = implode(' ', $coords);
          $area = "0,$h " . $polyline . " $w,$h";
          ?>
          <svg viewBox="0 0 <?php echo $w; ?> <?php echo $h; ?>" preserveAspectRatio="none">
            <polygon class="tu-grade-area" points="<?php echo $area; ?>"/>
            <polyline class="tu-grade-line" points="<?php echo $polyline; ?>"/>
            <g class="tu-grade-dots">
              <?php foreach ($pts as $pi => $pv) :
                $px = round(($pi / ($count - 1)) * $w);
                $py = round($h - (($pv - $min_v) / $range) * ($h - 10));
              ?>
              <circle cx="<?php echo $px; ?>" cy="<?php echo $py; ?>" r="3"/>
              <?php endforeach; ?>
            </g>
            <text class="tu-grade-label" x="2" y="<?php echo $h-2; ?>">C</text>
            <text class="tu-grade-label" x="<?php echo $w-12; ?>" y="12">A*</text>
          </svg>
        </div>
        <div class="tu-chalkboard__tray">
          <?php for ($ci=0; $ci<5; $ci++) : ?>
          <div class="tu-chalk-stick" style="width:<?php echo rand(20,40); ?>px;opacity:<?php echo round(rand(5,9)/10,1); ?>;"></div>
          <?php endfor; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- COUNTERS -->
<section class="tu-counters" aria-label="Statistics">
  <div class="tu-counters__grid">
    <div class="tu-counter-item">
      <div class="tu-counter-number">
        <span class="tu-count-val" data-target="<?php echo $tu_years; ?>"><?php echo $tu_years; ?></span>
        <span class="tu-suffix">yrs</span>
      </div>
      <div class="tu-counter-label">// teaching</div>
    </div>
    <div class="tu-counter-item">
      <div class="tu-counter-number">
        <span class="tu-count-val" data-target="420">420</span>
        <span class="tu-suffix">+</span>
      </div>
      <div class="tu-counter-label">// students</div>
    </div>
    <div class="tu-counter-item">
      <div class="tu-counter-number">
        <span class="tu-count-val" data-target="4" data-float="1">4.9</span>
        <span class="tu-suffix">★</span>
      </div>
      <div class="tu-counter-label">// avg rating</div>
    </div>
    <div class="tu-counter-item">
      <div class="tu-counter-number">
        <span class="tu-count-val" data-target="94">94</span>
        <span class="tu-suffix">%</span>
      </div>
      <div class="tu-counter-label">// improved 2+ grades</div>
    </div>
  </div>
</section>

<!-- SUBJECTS -->
<section class="tu-subjects" id="subjects" aria-label="Subjects">
  <div class="tu-section-header">
    <p class="tu-eyebrow">// specialisms</p>
    <h2 class="tu-section-title">Subjects I Teach</h2>
    <p class="tu-section-desc">From GCSE foundations to university-level coursework — rigorous, tailored teaching across STEM subjects.</p>
  </div>
  <div class="tu-subjects__grid">
    <?php foreach ($tu_subjects as $sub) : ?>
    <div class="tu-subject-card">
      <div class="tu-subject-icon" aria-hidden="true"><?php echo $sub['icon']; ?></div>
      <h3 class="tu-subject-name"><?php echo esc_html($sub['name']); ?></h3>
      <div class="tu-subject-levels"><?php echo esc_html($sub['levels']); ?></div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- EXAM BOARDS -->
<section class="tu-boards" aria-label="Exam boards covered">
  <div class="tu-section-header">
    <p class="tu-eyebrow">// exam boards</p>
    <h2 class="tu-section-title">Boards &amp; Qualifications</h2>
    <p class="tu-section-desc">Familiar with every major exam board and entrance test in the UK and internationally.</p>
  </div>
  <div class="tu-boards__tags">
    <?php foreach ($tu_boards as $board) : ?>
    <span class="tu-board-tag"><?php echo esc_html($board); ?></span>
    <?php endforeach; ?>
  </div>
</section>

<!-- PROCESS -->
<section class="tu-process" id="process" aria-label="How tutoring works">
  <div class="tu-section-header">
    <p class="tu-eyebrow">// the method</p>
    <h2 class="tu-section-title">How It Works</h2>
    <p class="tu-section-desc">A structured, collaborative approach that sets clear goals and tracks progress from day one.</p>
  </div>
  <div class="tu-process__steps">
    <?php foreach ($tu_steps as $step) : ?>
    <div class="tu-step">
      <div class="tu-step-num" aria-hidden="true"><?php echo esc_html($step['num']); ?></div>
      <h3 class="tu-step-title"><?php echo esc_html($step['title']); ?></h3>
      <p class="tu-step-desc"><?php echo esc_html($step['desc']); ?></p>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- PACKAGES -->
<section class="tu-packages" id="packages" aria-label="Pricing">
  <div class="tu-section-header">
    <p class="tu-eyebrow">// investment</p>
    <h2 class="tu-section-title">Session Rates</h2>
    <p class="tu-section-desc">Competitive Oxford rates with no hidden costs. Block booking discounts available.</p>
  </div>
  <div class="tu-packages__grid">
    <?php foreach ($tu_packages as $pkg) :
      $is_feat = $pkg['featured'];
    ?>
    <div class="tu-package-card<?php echo $is_feat ? ' tu-package-card--featured' : ''; ?>"
         style="--tu-card-colour:<?php echo esc_attr($pkg['colour']); ?>;">
      <div class="tu-package-header">
        <?php if ($is_feat) : ?><div class="tu-package-badge">Most Popular</div><?php endif; ?>
        <div class="tu-package-name"><?php echo esc_html($pkg['name']); ?></div>
        <div class="tu-package-price"><?php echo esc_html($pkg['price']); ?></div>
        <div class="tu-package-unit"><?php echo esc_html($pkg['unit']); ?></div>
      </div>
      <div class="tu-package-body">
        <ul class="tu-package-features">
          <?php foreach ($pkg['items'] as $item) : ?>
          <li><?php echo esc_html($item); ?></li>
          <?php endforeach; ?>
        </ul>
        <a href="#booking" class="tu-package-btn">Book This Package</a>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- PROFILE -->
<section class="tu-profile" id="about" aria-label="About the tutor">
  <div class="tu-profile__inner">
    <div>
      <div class="tu-profile__figure" aria-label="Portrait illustration of <?php echo esc_attr($tu_tutor); ?>">
        <div class="tu-profile__figure-hair" aria-hidden="true"></div>
        <div class="tu-profile__figure-gown" aria-hidden="true"></div>
        <div class="tu-profile__figure-hat" aria-hidden="true"></div>
        <div class="tu-profile__figure-hand" aria-hidden="true"></div>
        <div class="tu-profile__figure-chalk" aria-hidden="true"></div>
      </div>
      <div class="tu-profile__cred">
        <div class="tu-profile__cred-name"><?php echo esc_html($tu_tutor); ?></div>
        <div class="tu-profile__cred-title"><?php echo esc_html($tu_credential); ?></div>
      </div>
    </div>
    <div class="tu-profile__content">
      <h2>Teaching With Passion and Precision for <?php echo $tu_years; ?> Years</h2>
      <p>
        I completed my undergraduate degree in Mathematics at Oxford before a postgraduate year at Cambridge,
        specialising in pure mathematics. I then spent four years as a secondary school teacher before
        turning to private tutoring full time — where I could focus entirely on individual students.
      </p>
      <p>
        My philosophy is simple: every student can succeed in mathematics and science when the concepts
        are explained clearly and connected to what they already know. I never move forward until a student
        genuinely understands — not just can execute a method. This builds the deep confidence that translates
        into exam performance.
      </p>
      <p>
        I specialise in the most competitive pathways — A-Level Further Mathematics, Oxbridge entrance
        tests (MAT, STEP, PAT), and first-year university mathematics. I have a track record of students
        gaining places at Oxford, Cambridge, Imperial and UCL.
      </p>
      <div class="tu-quals">
        <span class="tu-qual-badge">PhD Mathematics (Oxford)</span>
        <span class="tu-qual-badge">Cambridge Postgrad</span>
        <span class="tu-qual-badge">Qualified Teacher (QTS)</span>
        <span class="tu-qual-badge">DBS Enhanced</span>
        <span class="tu-qual-badge">CPD Certified</span>
        <span class="tu-qual-badge">STEM Ambassador</span>
      </div>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="tu-testimonials" id="testimonials" aria-label="Testimonials">
  <div class="tu-section-header">
    <p class="tu-eyebrow">// results</p>
    <h2 class="tu-section-title">Student &amp; Parent Reviews</h2>
    <p class="tu-section-desc">Real feedback from students who've improved their grades and confidence.</p>
  </div>
  <div class="tu-testimonials__grid">
    <?php foreach ($tu_testimonials as $t) : ?>
    <div class="tu-testimonial-card">
      <div class="tu-stars" aria-label="<?php echo (int)$t['stars']; ?> stars">
        <?php echo str_repeat('★',(int)$t['stars']); ?>
      </div>
      <p class="tu-testimonial-text">"<?php echo esc_html($t['text']); ?>"</p>
      <div class="tu-testimonial-name">— <?php echo esc_html($t['name']); ?></div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- FAQ -->
<section class="tu-faq" id="faq" aria-label="FAQ">
  <div class="tu-section-header">
    <p class="tu-eyebrow">// questions</p>
    <h2 class="tu-section-title">Frequently Asked</h2>
  </div>
  <div class="tu-faq__list" role="list">
    <?php foreach ($tu_faqs as $fi => $faq) : ?>
    <div class="tu-faq-item" role="listitem">
      <button class="tu-faq-q" aria-expanded="false" aria-controls="tu-faq-a-<?php echo $fi; ?>">
        <?php echo esc_html($faq['q']); ?>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
      </button>
      <div class="tu-faq-a" id="tu-faq-a-<?php echo $fi; ?>" role="region">
        <div class="tu-faq-a-inner"><?php echo esc_html($faq['a']); ?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- BOOKING -->
<section class="tu-booking" id="booking" aria-label="Book a session">
  <div class="tu-booking__inner">
    <div class="tu-section-header">
      <p class="tu-eyebrow">// get started</p>
      <h2 class="tu-section-title">Book Your Free Assessment</h2>
      <p class="tu-section-desc">Complete the form and I'll be in touch within 24 hours to arrange a convenient time.</p>
    </div>
    <div class="tu-booking-form">
      <div class="tu-form-message" id="tu-form-msg" role="alert" aria-live="polite"></div>
      <form id="tu-booking-form" novalidate>
        <?php wp_nonce_field('tf_tu_booking','tf_tu_nonce'); ?>
        <div class="tu-form-grid">
          <div class="tu-form-group">
            <label class="tu-form-label" for="tu-name">Parent / Guardian Name *</label>
            <input class="tu-form-input" type="text" id="tu-name" name="tu_name" placeholder="Full name" required autocomplete="name">
          </div>
          <div class="tu-form-group">
            <label class="tu-form-label" for="tu-email">Email Address *</label>
            <input class="tu-form-input" type="email" id="tu-email" name="tu_email" placeholder="you@email.com" required autocomplete="email">
          </div>
          <div class="tu-form-group">
            <label class="tu-form-label" for="tu-phone">Phone Number</label>
            <input class="tu-form-input" type="tel" id="tu-phone" name="tu_phone" placeholder="07700 900 000" autocomplete="tel">
          </div>
          <div class="tu-form-group">
            <label class="tu-form-label" for="tu-student">Student Name &amp; Age *</label>
            <input class="tu-form-input" type="text" id="tu-student" name="tu_student" placeholder="e.g. Tom, 16" required>
          </div>
          <div class="tu-form-group">
            <label class="tu-form-label" for="tu-subject">Subject *</label>
            <select class="tu-form-select" id="tu-subject" name="tu_subject" required>
              <option value="">Select subject…</option>
              <?php foreach ($tu_subjects as $sub) : ?>
              <option value="<?php echo esc_attr($sub['name']); ?>"><?php echo esc_html($sub['name']); ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="tu-form-group">
            <label class="tu-form-label" for="tu-level">Level</label>
            <select class="tu-form-select" id="tu-level" name="tu_level">
              <option value="">Select level…</option>
              <option value="ks3">KS3 (Yr 7–9)</option>
              <option value="gcse">GCSE (Yr 10–11)</option>
              <option value="alevel">A-Level (Yr 12–13)</option>
              <option value="oxbridge">Oxbridge / University Entrance</option>
              <option value="uni">University (1st / 2nd Year)</option>
            </select>
          </div>
          <div class="tu-form-group">
            <label class="tu-form-label" for="tu-format">Session Format</label>
            <select class="tu-form-select" id="tu-format" name="tu_format">
              <option value="online">Online (Zoom + Whiteboard)</option>
              <option value="inperson">In Person (Oxford area)</option>
            </select>
          </div>
          <div class="tu-form-group">
            <label class="tu-form-label" for="tu-when">When Is the Exam?</label>
            <input class="tu-form-input" type="text" id="tu-when" name="tu_when" placeholder="e.g. June 2025, ASAP…">
          </div>
          <div class="tu-form-group tu-form-full">
            <label class="tu-form-label" for="tu-notes">Additional Information</label>
            <textarea class="tu-form-textarea" id="tu-notes" name="tu_notes" placeholder="Topics the student is struggling with, current grade, specific goals, any SEND requirements…" rows="4"></textarea>
          </div>
          <div class="tu-form-group tu-form-full">
            <p class="tu-form-privacy">Your information is kept confidential. By submitting you agree to our <a href="/privacy-policy">Privacy Policy</a>.</p>
          </div>
          <div class="tu-form-full" style="text-align:center;">
            <button type="submit" class="tu-form-submit">Request Free Assessment →</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</section>

<!-- FOOTER -->
<footer class="tu-footer" role="contentinfo">
  <p>© <?php echo date('Y'); ?> <?php echo esc_html($tu_tutor); ?> — <?php echo esc_html($tu_credential); ?></p>
  <p><?php echo esc_html($tu_location); ?> · <a href="tel:<?php echo esc_attr(preg_replace('/\s+/','',$tu_phone)); ?>"><?php echo esc_html($tu_phone); ?></a> · <a href="mailto:<?php echo esc_attr($tu_email); ?>"><?php echo esc_html($tu_email); ?></a> · <a href="/privacy-policy">Privacy Policy</a></p>
</footer>

<script>
(function(){
  'use strict';

  /* ── animated counters ─────────────────────────────── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  const cObs = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const isFloat = el.dataset.float === '1';
      const endVal = isFloat ? 4.9 : parseFloat(el.dataset.target);
      if (isNaN(endVal)) return;
      const dur = 1800; let start = null;
      const tick = ts => {
        if (!start) start = ts;
        const p = Math.min((ts - start) / dur, 1);
        const v = endVal * easeOut(p);
        el.textContent = isFloat ? v.toFixed(1) : Math.round(v).toLocaleString();
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      cObs.unobserve(el);
    });
  }, {threshold:0.3});
  document.querySelectorAll('.tu-count-val').forEach(el => cObs.observe(el));

  /* ── FAQ ───────────────────────────────────────────── */
  document.querySelectorAll('.tu-faq-q').forEach(btn => {
    btn.addEventListener('click', () => {
      const item = btn.closest('.tu-faq-item');
      const open = item.classList.contains('open');
      document.querySelectorAll('.tu-faq-item.open').forEach(i => {
        i.classList.remove('open');
        i.querySelector('.tu-faq-q').setAttribute('aria-expanded','false');
      });
      if (!open) { item.classList.add('open'); btn.setAttribute('aria-expanded','true'); }
    });
  });

  /* ── booking form ──────────────────────────────────── */
  const form = document.getElementById('tu-booking-form');
  const msg  = document.getElementById('tu-form-msg');
  if (form && msg) {
    form.addEventListener('submit', e => {
      e.preventDefault();
      msg.className = 'tu-form-message';
      const name    = document.getElementById('tu-name').value.trim();
      const email   = document.getElementById('tu-email').value.trim();
      const student = document.getElementById('tu-student').value.trim();
      const subj    = document.getElementById('tu-subject').value;
      if (!name || !email || !student || !subj) {
        msg.className = 'tu-form-message error';
        msg.textContent = 'Please complete all required fields.';
        msg.scrollIntoView({behavior:'smooth',block:'center'}); return;
      }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        msg.className = 'tu-form-message error';
        msg.textContent = 'Please enter a valid email address.'; return;
      }
      const data = new FormData(form);
      data.append('action','tf_tu_booking');
      fetch('<?php echo esc_url(admin_url("admin-ajax.php")); ?>', {method:'POST',body:data})
        .catch(() => {})
        .finally(() => {
          msg.className = 'tu-form-message success';
          msg.textContent = 'Thank you! Your free assessment request has been received. I\'ll be in touch within 24 hours.';
          form.reset();
          msg.scrollIntoView({behavior:'smooth',block:'center'});
        });
    });
  }

  /* ── scroll reveal ─────────────────────────────────── */
  const revObs = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        revObs.unobserve(entry.target);
      }
    });
  }, {threshold:0.08});
  document.querySelectorAll('.tu-subject-card,.tu-package-card,.tu-testimonial-card,.tu-step').forEach((el,i) => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(28px)';
    el.style.transition = `opacity 0.5s ${i*0.05}s ease, transform 0.5s ${i*0.05}s ease`;
    revObs.observe(el);
  });

})();
</script>

</body>
</html>
</div><!-- .tu-page -->
<?php get_footer(); ?>
