<?php
/**
 * Template Name: Vet – Veterinary Practice
 *
 * Premium veterinary practice homepage template.
 * Poppins + Merriweather · --vt-* namespace · teal/warm-white/amber palette
 * CSS art-directed clinic reception hero · WCAG 2.1 AA · vanilla JS
 *
 * @package ThemeFlex
 */

defined( 'ABSPATH' ) || exit;

srand( crc32( get_the_permalink() ) );

/* ── palette seeds ─────────────────────────────────────────────────────── */
$vt_teal      = '#1A7A78';
$vt_teal_dark = '#115553';
$vt_teal_lt   = '#E8F5F4';
$vt_amber     = '#D4822A';
$vt_warm      = '#FBF7F2';
$vt_navy      = '#0D2B3E';
$vt_text      = '#2C3E35';

/* ── pets for reception area ────────────────────────────────────────────── */
$pets = [
    [ 'type' => 'dog',  'color' => '#C49A6C', 'spot' => '#8B6340', 'x' => 12, 'y' => 64 ],
    [ 'type' => 'cat',  'color' => '#7A6E65', 'spot' => '#4A403A', 'x' => 68, 'y' => 66 ],
    [ 'type' => 'dog',  'color' => '#E8D5B8', 'spot' => '#B8A080', 'x' => 38, 'y' => 65 ],
    [ 'type' => 'cat',  'color' => '#D4913A', 'spot' => '#8B5E20', 'x' => 82, 'y' => 67 ],
];

/* ── waiting room chairs ────────────────────────────────────────────────── */
$chairs = [
    [ 'x' => 5,  'color' => '#2A8A88' ],
    [ 'x' => 16, 'color' => '#1A7A78' ],
    [ 'x' => 27, 'color' => '#2A8A88' ],
    [ 'x' => 58, 'color' => '#1A7A78' ],
    [ 'x' => 69, 'color' => '#2A8A88' ],
    [ 'x' => 80, 'color' => '#1A7A78' ],
];

/* ── floating paw prints ─────────────────────────────────────────────────*/
$paws = [];
for ( $i = 0; $i < 16; $i++ ) {
    $paws[] = [
        'x'  => rand( 2, 97 ),
        'y'  => rand( 5, 90 ),
        'sz' => rand( 10, 22 ),
        'op' => rand( 5, 20 ),
        'r'  => rand( -30, 30 ),
        'delay' => rand( 0, 60 ) / 10,
        'dur'   => rand( 30, 70 ) / 10,
    ];
}

/* ── plant pots ──────────────────────────────────────────────────────────*/
$plants = [
    [ 'x' => 2,  'h' => 38, 'leaves' => 4, 'pot' => '#8B6340' ],
    [ 'x' => 91, 'h' => 32, 'leaves' => 3, 'pot' => '#6B4E30' ],
];

/* ── services ────────────────────────────────────────────────────────────*/
$services = [
    [ 'icon' => '🩺', 'title' => 'Wellness Exams',         'desc' => 'Comprehensive health checks for pets of all ages, tailored to their life stage and breed.' ],
    [ 'icon' => '💉', 'title' => 'Vaccinations',           'desc' => 'Core and lifestyle vaccines administered on evidence-based schedules to protect your pet.' ],
    [ 'icon' => '🔬', 'title' => 'In-House Diagnostics',   'desc' => 'Same-day blood panels, urinalysis, and digital X-ray with rapid results.' ],
    [ 'icon' => '🔪', 'title' => 'Surgery',                'desc' => 'Routine to complex soft-tissue procedures performed in our purpose-built theatre.' ],
    [ 'icon' => '🦷', 'title' => 'Dental Care',            'desc' => 'Professional dental scaling, polishing, and extractions under full anaesthesia.' ],
    [ 'icon' => '🐾', 'title' => 'Physiotherapy',          'desc' => 'Post-surgical rehabilitation and hydrotherapy to restore strength and mobility.' ],
];

/* ── team ─────────────────────────────────────────────────────────────── */
$team = [
    [ 'name' => 'Dr Sarah Whitfield', 'role' => 'Clinical Director & Surgeon',    'qual' => 'BVSc MRCVS RCVS Advanced Practitioner', 'yrs' => 16 ],
    [ 'name' => 'Dr James Okafor',    'role' => 'Internal Medicine Specialist',   'qual' => 'BVetMed PhD MRCVS',                      'yrs' => 11 ],
    [ 'name' => 'Dr Priya Mehta',     'role' => 'Emergency & Critical Care',      'qual' => 'BVM&S MRCVS DECVECC',                    'yrs' =>  8 ],
    [ 'name' => 'Dr Tom Beckett',     'role' => 'Exotic Animal Clinician',        'qual' => 'BVSc MRCVS CertAVP(ZM)',                 'yrs' =>  7 ],
];

$hair_styles = [ 'ellipse(48% 52% at 50% 0%)', 'ellipse(52% 55% at 50% 0%)', 'ellipse(45% 50% at 50% 0%)', 'ellipse(50% 52% at 50% 0%)' ];
$hair_colors = [ '#2C1810', '#1A1008', '#8B4513', '#4A3728' ];
$coat_colors = [ '#FFFFFF', '#F0F8FF', '#FAFAF0', '#F5F5F5' ];

/* ── packages ────────────────────────────────────────────────────────────*/
$packages = [
    [
        'name'     => 'Puppy & Kitten',
        'price'    => '£68',
        'period'   => '/ first visit',
        'featured' => false,
        'items'    => [ 'Full health examination', 'Microchipping', 'Parasite screening', 'Vaccination schedule', 'Nutrition advice', 'Nurse follow-up call' ],
    ],
    [
        'name'     => 'HealthCare Plan',
        'price'    => '£29',
        'period'   => '/ month',
        'featured' => true,
        'items'    => [ 'Unlimited consultations', '2 annual health checks', 'All core vaccinations', 'Monthly flea & worm treatment', 'Dental check & scale', '10% off surgery & diagnostics' ],
    ],
    [
        'name'     => 'Senior Wellness',
        'price'    => '£95',
        'period'   => '/ visit',
        'featured' => false,
        'items'    => [ 'Extended 45-min consult', 'Full blood & urine panel', 'Blood pressure check', 'Joint & mobility screen', 'Cognitive function assessment', 'Personalised care plan' ],
    ],
];

/* ── counters ────────────────────────────────────────────────────────────*/
$counters = [
    [ 'value' => 24,     'suffix' => 'yrs',    'label' => 'Established',      'float' => false ],
    [ 'value' => 18400,  'suffix' => '+',       'label' => 'Patients Treated', 'float' => false ],
    [ 'value' => 4.9,    'suffix' => '★',      'label' => 'Google Rating',    'float' => true  ],
    [ 'value' => 100,    'suffix' => '%',       'label' => 'RCVS Accredited',  'float' => false ],
];

/* ── testimonials ────────────────────────────────────────────────────────*/
$testimonials = [
    [ 'text' => 'The care our golden retriever received after his cruciate surgery was exceptional. The team kept us informed at every step and his recovery has been remarkable.', 'name' => 'Rebecca & Max', 'pet' => 'Golden Retriever' ],
    [ 'text' => 'We have been bringing our cats here for over ten years. The vets genuinely love animals and it shows — our anxious rescue cat actually walks in calmly now.', 'name' => 'David & Noodle', 'pet' => 'Rescue Cat' ],
    [ 'text' => 'Our rabbit needed emergency surgery and they fitted us in same day. The exotic specialist was incredible and the aftercare was faultless. Truly outstanding practice.', 'name' => 'Imogen & Biscuit', 'pet' => 'Holland Lop Rabbit' ],
];

get_header();
?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&family=Merriweather:ital,wght@0,300;0,400;0,700;1,300;1,400&display=swap" rel="stylesheet">

<style>
/* ═══════════════════════════════════════════════════════════════════════
   VET PRACTICE — CSS CUSTOM PROPERTIES
═══════════════════════════════════════════════════════════════════════ */
:root {
    --vt-teal:      <?= $vt_teal ?>;
    --vt-teal-dark: <?= $vt_teal_dark ?>;
    --vt-teal-lt:   <?= $vt_teal_lt ?>;
    --vt-amber:     <?= $vt_amber ?>;
    --vt-warm:      <?= $vt_warm ?>;
    --vt-navy:      <?= $vt_navy ?>;
    --vt-text:      <?= $vt_text ?>;

    --vt-ff-head: 'Poppins', sans-serif;
    --vt-ff-body: 'Merriweather', serif;

    --vt-radius:  6px;
    --vt-shadow:  0 4px 24px rgba(0,43,30,.10);
    --vt-trans:   .3s cubic-bezier(.4,0,.2,1);
}

/* ── reset ──────────────────────────────────────────────────────────── */
.vt-wrap *, .vt-wrap *::before, .vt-wrap *::after { box-sizing: border-box; margin: 0; padding: 0; }
.vt-wrap { font-family: var(--vt-ff-body); color: var(--vt-text); background: var(--vt-warm); overflow-x: hidden; }
.vt-wrap img { max-width: 100%; display: block; }
.vt-container { max-width: 1160px; margin: 0 auto; padding: 0 24px; }

/* ── typography ─────────────────────────────────────────────────────── */
.vt-section-label { font-family: var(--vt-ff-head); font-size: .72rem; font-weight: 600; letter-spacing: .18em; text-transform: uppercase; color: var(--vt-teal); display: block; margin-bottom: 12px; }
.vt-section-title { font-family: var(--vt-ff-head); font-size: clamp(1.8rem, 3.5vw, 2.8rem); font-weight: 700; line-height: 1.18; color: var(--vt-navy); }
.vt-section-title span { color: var(--vt-teal); }
.vt-section-body  { font-size: .98rem; line-height: 1.85; color: #4A5A52; margin-top: 18px; }

/* ── buttons ────────────────────────────────────────────────────────── */
.vt-btn { display: inline-flex; align-items: center; gap: 8px; font-family: var(--vt-ff-head); font-size: .88rem; font-weight: 600; padding: 13px 28px; border-radius: var(--vt-radius); cursor: pointer; border: 2px solid transparent; text-decoration: none; transition: var(--vt-trans); }
.vt-btn--primary { background: var(--vt-teal); color: #fff; }
.vt-btn--primary:hover { background: var(--vt-teal-dark); transform: translateY(-2px); box-shadow: 0 8px 24px rgba(26,122,120,.35); }
.vt-btn--ghost { background: transparent; color: #fff; border-color: rgba(255,255,255,.6); }
.vt-btn--ghost:hover { background: rgba(255,255,255,.12); }
.vt-btn--outline { background: transparent; color: var(--vt-teal); border-color: var(--vt-teal); }
.vt-btn--outline:hover { background: var(--vt-teal); color: #fff; }

/* ════════════════════════════════════════════════════════════════════
   HERO
════════════════════════════════════════════════════════════════════ */
.vt-hero { position: relative; min-height: 94vh; display: flex; align-items: center; overflow: hidden; background: linear-gradient(160deg, #0D3830 0%, #1A5E5C 45%, #0D2B3E 100%); }

/* ── clinic scene ─────────────────────────────────────────────────── */
.vt-scene { position: absolute; inset: 0; overflow: hidden; }

/* ceiling */
.vt-scene__ceiling { position: absolute; top: 0; left: 0; right: 0; height: 14%; background: linear-gradient(180deg, #EAEFED 0%, #D8E4E0 100%); }
/* ceiling strip lights */
.vt-scene__light-strip { position: absolute; top: 8%; left: 50%; transform: translateX(-50%); width: 55%; height: 4px; background: linear-gradient(90deg, transparent, #E8F8F6 20%, #FFFFFF 50%, #E8F8F6 80%, transparent); border-radius: 2px; box-shadow: 0 0 18px 6px rgba(255,255,255,.5), 0 0 40px 14px rgba(200,240,235,.3); }
.vt-scene__light-strip::before { content: ''; position: absolute; left: 20%; top: 100%; width: 60%; height: 80px; background: radial-gradient(ellipse 60% 100% at 50% 0%, rgba(200,240,235,.25) 0%, transparent 100%); }

/* walls */
.vt-scene__wall { position: absolute; top: 14%; left: 0; right: 0; bottom: 28%; background: linear-gradient(180deg, #EDF4F2 0%, #E0EDEA 100%); }
.vt-scene__wall-stripe { position: absolute; top: 14%; left: 0; right: 0; height: 4px; background: linear-gradient(90deg, transparent, var(--vt-teal) 20%, var(--vt-teal) 80%, transparent); opacity: .3; }
/* wall dado */
.vt-scene__dado { position: absolute; top: 45%; left: 0; right: 0; height: 4px; background: #C8D8D4; }
.vt-scene__dado-wall { position: absolute; top: 45%; left: 0; right: 0; bottom: 28%; background: linear-gradient(180deg, #D8E8E4 0%, #C8D8D4 100%); }
/* tile pattern on dado wall */
.vt-scene__dado-wall::after { content: ''; position: absolute; inset: 0; background: repeating-linear-gradient(90deg, rgba(255,255,255,.15) 0px, rgba(255,255,255,.15) 1px, transparent 1px, transparent 48px), repeating-linear-gradient(180deg, rgba(255,255,255,.15) 0px, rgba(255,255,255,.15) 1px, transparent 1px, transparent 32px); }

/* floor */
.vt-scene__floor { position: absolute; bottom: 0; left: 0; right: 0; height: 28%; background: linear-gradient(180deg, #C8D8D0 0%, #A8BCB4 100%); }
.vt-scene__floor-line { position: absolute; top: 0; left: 0; right: 0; height: 3px; background: #8AA89E; }
/* floor tiles */
.vt-scene__floor::before { content: ''; position: absolute; inset: 0; background: repeating-linear-gradient(90deg, rgba(255,255,255,.08) 0px, rgba(255,255,255,.08) 1px, transparent 1px, transparent 60px), repeating-linear-gradient(180deg, rgba(255,255,255,.08) 0px, rgba(255,255,255,.08) 1px, transparent 1px, transparent 60px); }

/* reception desk */
.vt-scene__desk { position: absolute; bottom: 28%; left: 50%; transform: translateX(-50%); width: 44%; }
.vt-scene__desk-top { height: 12px; background: linear-gradient(180deg, #FFFFFF 0%, #E8F0EE 100%); border-radius: 2px 2px 0 0; box-shadow: 0 -2px 8px rgba(0,0,0,.15); }
.vt-scene__desk-front { height: 56px; background: linear-gradient(180deg, var(--vt-teal) 0%, var(--vt-teal-dark) 100%); position: relative; }
.vt-scene__desk-front::before { content: ''; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 120px; height: 28px; background: rgba(255,255,255,.08); border-radius: 2px; border: 1px solid rgba(255,255,255,.15); }
.vt-scene__desk-panel { height: 18px; background: linear-gradient(180deg, #0E4A48 0%, #0A3A38 100%); }
/* computer monitor on desk */
.vt-scene__monitor { position: absolute; top: -52px; right: 14%; width: 52px; }
.vt-scene__monitor-screen { height: 36px; background: linear-gradient(135deg, #1A3A38 0%, #0D2B3E 100%); border: 2px solid #6A8880; border-radius: 3px; position: relative; overflow: hidden; }
.vt-scene__monitor-screen::before { content: ''; position: absolute; inset: 3px; background: repeating-linear-gradient(0deg, rgba(26,122,120,.2) 0px, rgba(26,122,120,.2) 1px, transparent 1px, transparent 6px); }
.vt-scene__monitor-stand { width: 4px; height: 12px; background: #8A9890; margin: 0 auto; }
.vt-scene__monitor-base { height: 4px; width: 20px; background: #6A7870; margin: 0 auto; border-radius: 1px; }
/* receptionist figure */
.vt-scene__receptionist { position: absolute; top: -88px; left: 18%; }
.vt-scene__receptionist-head { width: 22px; height: 24px; background: #DEB887; border-radius: 50% 50% 40% 40%; position: relative; margin: 0 auto; }
.vt-scene__receptionist-hair { position: absolute; top: 0; left: 0; right: 0; height: 12px; background: #3D1C02; clip-path: ellipse(52% 55% at 50% 0%); }
.vt-scene__receptionist-body { width: 28px; height: 36px; background: var(--vt-teal); border-radius: 2px 2px 0 0; margin: 2px auto 0; position: relative; }
.vt-scene__receptionist-body::before { content: ''; position: absolute; top: 4px; left: 50%; transform: translateX(-50%); width: 12px; height: 1px; background: rgba(255,255,255,.4); box-shadow: 0 4px 0 rgba(255,255,255,.4), 0 8px 0 rgba(255,255,255,.4); }

/* paw prints */
.vt-paw { position: absolute; pointer-events: none; animation: vt-paw-float linear infinite; }
.vt-paw svg { fill: rgba(255,255,255,.12); }
@keyframes vt-paw-float { 0%,100%{ transform: translateY(0) rotate(var(--vt-rot)); } 50%{ transform: translateY(-8px) rotate(var(--vt-rot)); } }

/* ── plant ───────────────────────────────────────────────────────────*/
.vt-plant { position: absolute; bottom: 28%; }
.vt-plant__pot { width: 28px; height: 20px; background: linear-gradient(180deg, var(--pot-top,#8B6340) 0%, var(--pot-bot,#6B4E30) 100%); clip-path: polygon(8% 0%, 92% 0%, 100% 100%, 0% 100%); margin: 0 auto; }
.vt-plant__soil { width: 30px; height: 5px; background: #4A3020; border-radius: 0 0 2px 2px; margin: 0 auto; }
.vt-plant__stem { width: 3px; background: linear-gradient(180deg, #3A6030 0%, #2A5020 100%); margin: 0 auto; border-radius: 2px; }
.vt-plant__leaf { position: absolute; border-radius: 0 80% 0 80%; background: radial-gradient(ellipse at 30% 40%, #4A8040 0%, #2A6020 100%); }

/* ── pets in waiting room ────────────────────────────────────────── */
.vt-pet { position: absolute; }
.vt-pet__body { border-radius: 50% 50% 40% 40%; position: relative; }
.vt-pet__head { border-radius: 50%; position: relative; }
.vt-pet__ear-l, .vt-pet__ear-r { position: absolute; top: 0; border-radius: 50% 50% 0 0; }
.vt-pet__tail { position: absolute; right: -10px; border-radius: 0 8px 8px 0; }

/* dog specific */
.vt-pet--dog .vt-pet__ear-l { left: -3px; transform: rotate(-15deg); }
.vt-pet--dog .vt-pet__ear-r { right: -3px; transform: rotate(15deg); }
/* cat specific */
.vt-pet--cat .vt-pet__ear-l { left: 1px; clip-path: polygon(50% 0%, 0% 100%, 100% 100%); border-radius: 0; }
.vt-pet--cat .vt-pet__ear-r { right: 1px; clip-path: polygon(50% 0%, 0% 100%, 100% 100%); border-radius: 0; }

/* ── chair ──────────────────────────────────────────────────────── */
.vt-chair { position: absolute; bottom: 28%; }
.vt-chair__seat { height: 10px; border-radius: 1px 1px 0 0; position: relative; }
.vt-chair__back { height: 16px; border-radius: 1px 1px 0 0; position: relative; top: -26px; }
.vt-chair__leg { position: absolute; bottom: -12px; width: 3px; height: 12px; background: #8A9890; }

/* hero content */
.vt-hero__content { position: relative; z-index: 10; max-width: 560px; padding: 60px 0; }
.vt-hero__eyebrow { font-family: var(--vt-ff-head); font-size: .72rem; font-weight: 600; letter-spacing: .2em; text-transform: uppercase; color: rgba(232,245,244,.8); margin-bottom: 14px; }
.vt-hero__title { font-family: var(--vt-ff-head); font-size: clamp(2.4rem, 5vw, 4rem); font-weight: 800; line-height: 1.1; color: #fff; }
.vt-hero__title em { font-style: normal; color: #7ECFCC; }
.vt-hero__sub { font-size: .98rem; line-height: 1.85; color: rgba(255,255,255,.78); margin: 20px 0 32px; }
.vt-hero__ctas { display: flex; gap: 14px; flex-wrap: wrap; }
.vt-hero__badge { display: inline-flex; align-items: center; gap: 8px; background: rgba(255,255,255,.1); backdrop-filter: blur(8px); border: 1px solid rgba(255,255,255,.2); border-radius: 50px; padding: 8px 18px; margin-top: 28px; font-family: var(--vt-ff-head); font-size: .78rem; font-weight: 500; color: rgba(255,255,255,.9); }
.vt-hero__badge span { display: flex; align-items: center; justify-content: center; width: 22px; height: 22px; background: var(--vt-teal); border-radius: 50%; font-size: .7rem; }

/* ════════════════════════════════════════════════════════════════════
   TRUST BAR
════════════════════════════════════════════════════════════════════ */
.vt-trust { background: #fff; border-bottom: 1px solid #E0EDEA; }
.vt-trust__inner { display: flex; align-items: center; justify-content: center; flex-wrap: wrap; gap: 0; }
.vt-trust__item { display: flex; align-items: center; gap: 12px; padding: 20px 32px; border-right: 1px solid #E8F2F0; }
.vt-trust__item:last-child { border-right: none; }
.vt-trust__icon { font-size: 1.4rem; }
.vt-trust__label { font-family: var(--vt-ff-head); font-size: .78rem; font-weight: 600; color: var(--vt-navy); line-height: 1.2; }
.vt-trust__sub { font-size: .7rem; color: #7A8E88; }

/* ════════════════════════════════════════════════════════════════════
   SERVICES
════════════════════════════════════════════════════════════════════ */
.vt-services { padding: 100px 0; background: var(--vt-warm); }
.vt-services__header { text-align: center; max-width: 580px; margin: 0 auto 60px; }
.vt-services__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 24px; }
.vt-service-card { background: #fff; border-radius: var(--vt-radius); padding: 36px 32px; border: 1px solid #E0EDEA; transition: var(--vt-trans); position: relative; overflow: hidden; }
.vt-service-card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px; background: linear-gradient(90deg, var(--vt-teal), var(--vt-teal-dark)); transform: scaleX(0); transform-origin: left; transition: var(--vt-trans); }
.vt-service-card:hover { transform: translateY(-4px); box-shadow: var(--vt-shadow); }
.vt-service-card:hover::before { transform: scaleX(1); }
.vt-service-card__icon { font-size: 2.2rem; margin-bottom: 18px; display: block; }
.vt-service-card__title { font-family: var(--vt-ff-head); font-size: 1.08rem; font-weight: 700; color: var(--vt-navy); margin-bottom: 10px; }
.vt-service-card__desc { font-size: .9rem; line-height: 1.75; color: #5A6E68; }

/* ════════════════════════════════════════════════════════════════════
   COUNTERS
════════════════════════════════════════════════════════════════════ */
.vt-counters { background: linear-gradient(135deg, var(--vt-teal-dark) 0%, var(--vt-navy) 100%); padding: 80px 0; }
.vt-counters__grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 40px; text-align: center; }
.vt-counter__value { font-family: var(--vt-ff-head); font-size: clamp(2.2rem, 4vw, 3.2rem); font-weight: 800; color: #fff; line-height: 1; }
.vt-counter__value span { color: #7ECFCC; }
.vt-counter__label { font-family: var(--vt-ff-head); font-size: .78rem; font-weight: 500; color: rgba(255,255,255,.6); text-transform: uppercase; letter-spacing: .12em; margin-top: 10px; }

/* ════════════════════════════════════════════════════════════════════
   TEAM
════════════════════════════════════════════════════════════════════ */
.vt-team { padding: 100px 0; background: #F2F8F6; }
.vt-team__header { text-align: center; max-width: 560px; margin: 0 auto 60px; }
.vt-team__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 28px; }

.vt-team-card { background: #fff; border-radius: var(--vt-radius); overflow: hidden; border: 1px solid #D8EDEA; transition: var(--vt-trans); }
.vt-team-card:hover { transform: translateY(-4px); box-shadow: var(--vt-shadow); }

/* CSS vet figure */
.vt-team-card__figure { height: 200px; background: linear-gradient(180deg, var(--vt-teal-lt) 0%, #C8DDD8 100%); display: flex; align-items: flex-end; justify-content: center; position: relative; overflow: hidden; }
.vt-figure { position: relative; width: 80px; margin-bottom: 0; }
.vt-figure__head { width: 36px; height: 40px; background: var(--fig-skin, #DEB887); border-radius: 50% 50% 40% 40%; margin: 0 auto; position: relative; }
.vt-figure__hair { position: absolute; top: 0; left: 0; right: 0; height: 18px; background: var(--fig-hair, #2C1810); clip-path: var(--fig-clip, ellipse(50% 55% at 50% 0%)); }
.vt-figure__neck { width: 14px; height: 8px; background: var(--fig-skin, #DEB887); margin: 0 auto; }
.vt-figure__body { width: 52px; height: 64px; background: var(--fig-coat, #FFFFFF); border-radius: 2px 2px 0 0; margin: 0 auto; position: relative; }
/* coat lapels */
.vt-figure__body::before { content: ''; position: absolute; top: 0; left: 10px; width: 12px; height: 30px; background: var(--fig-scrub, #1A7A78); clip-path: polygon(0 0, 100% 0, 60% 100%, 0 100%); }
.vt-figure__body::after { content: ''; position: absolute; top: 0; right: 10px; width: 12px; height: 30px; background: var(--fig-scrub, #1A7A78); clip-path: polygon(0 0, 100% 0, 100% 100%, 40% 100%); }
/* stethoscope */
.vt-figure__steth { position: absolute; top: 8px; left: 50%; transform: translateX(-50%); width: 20px; height: 14px; border: 2px solid #8A9890; border-radius: 50% 50% 0 0; border-bottom: none; }
.vt-figure__steth::after { content: ''; position: absolute; bottom: -8px; left: 50%; transform: translateX(-50%); width: 6px; height: 6px; background: #6A7870; border-radius: 50%; }
.vt-figure__arm-l { position: absolute; left: -12px; top: 8px; width: 12px; height: 32px; background: var(--fig-coat, #FFFFFF); border-radius: 4px 0 0 4px; }
.vt-figure__arm-r { position: absolute; right: -12px; top: 8px; width: 12px; height: 32px; background: var(--fig-coat, #FFFFFF); border-radius: 0 4px 4px 0; }

.vt-team-card__info { padding: 20px 22px 24px; }
.vt-team-card__name { font-family: var(--vt-ff-head); font-size: 1rem; font-weight: 700; color: var(--vt-navy); }
.vt-team-card__role { font-size: .82rem; color: var(--vt-teal); font-weight: 600; margin: 4px 0 8px; font-family: var(--vt-ff-head); }
.vt-team-card__qual { font-size: .78rem; color: #6A7E78; line-height: 1.4; }
.vt-team-card__yrs { display: inline-flex; align-items: center; gap: 4px; font-family: var(--vt-ff-head); font-size: .72rem; font-weight: 600; color: var(--vt-teal); background: var(--vt-teal-lt); padding: 3px 10px; border-radius: 50px; margin-top: 10px; }

/* ════════════════════════════════════════════════════════════════════
   PACKAGES
════════════════════════════════════════════════════════════════════ */
.vt-packages { padding: 100px 0; background: var(--vt-warm); }
.vt-packages__header { text-align: center; max-width: 580px; margin: 0 auto 60px; }
.vt-packages__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 24px; align-items: start; }
.vt-package-card { background: #fff; border-radius: var(--vt-radius); padding: 40px 36px; border: 1px solid #D8EDEA; position: relative; transition: var(--vt-trans); }
.vt-package-card:hover { transform: translateY(-4px); box-shadow: var(--vt-shadow); }
.vt-package-card--featured { background: linear-gradient(160deg, var(--vt-teal) 0%, var(--vt-teal-dark) 100%); border-color: transparent; }
.vt-package-card--featured .vt-package-card__name,
.vt-package-card--featured .vt-package-card__price,
.vt-package-card--featured .vt-package-card__period,
.vt-package-card--featured .vt-package-card__item { color: rgba(255,255,255,.95); }
.vt-package-card--featured .vt-package-card__item::before { background: rgba(255,255,255,.7); }
.vt-package-card__badge { position: absolute; top: -1px; right: 24px; background: var(--vt-amber); color: #fff; font-family: var(--vt-ff-head); font-size: .68rem; font-weight: 700; letter-spacing: .1em; text-transform: uppercase; padding: 4px 14px 5px; border-radius: 0 0 6px 6px; }
.vt-package-card__name { font-family: var(--vt-ff-head); font-size: 1.1rem; font-weight: 700; color: var(--vt-navy); margin-bottom: 20px; }
.vt-package-card__price-row { display: flex; align-items: baseline; gap: 4px; margin-bottom: 28px; }
.vt-package-card__price { font-family: var(--vt-ff-head); font-size: 2.4rem; font-weight: 800; color: var(--vt-navy); }
.vt-package-card__period { font-size: .85rem; color: #6A7E78; }
.vt-package-card__list { list-style: none; display: flex; flex-direction: column; gap: 10px; margin-bottom: 30px; }
.vt-package-card__item { font-size: .88rem; color: #4A5A52; padding-left: 20px; position: relative; }
.vt-package-card__item::before { content: ''; position: absolute; left: 0; top: 50%; transform: translateY(-50%); width: 8px; height: 8px; border-radius: 50%; background: var(--vt-teal); }

/* ════════════════════════════════════════════════════════════════════
   ABOUT
════════════════════════════════════════════════════════════════════ */
.vt-about { padding: 100px 0; background: #fff; }
.vt-about__inner { display: grid; grid-template-columns: 1fr 1fr; gap: 72px; align-items: center; }
.vt-about__visual { border-radius: var(--vt-radius); overflow: hidden; }

/* CSS clinic corridor scene */
.vt-corridor { height: 360px; background: linear-gradient(180deg, #EDF4F2 0%, #D8EDEA 100%); position: relative; overflow: hidden; border-radius: var(--vt-radius); }
/* floor */
.vt-corridor::before { content: ''; position: absolute; bottom: 0; left: 0; right: 0; height: 32%; background: linear-gradient(180deg, #C0D4CE 0%, #A8BCB4 100%); }
/* tiled wall pattern */
.vt-corridor::after { content: ''; position: absolute; inset: 0 0 32% 0; background: repeating-linear-gradient(90deg, rgba(26,122,120,.06) 0px, rgba(26,122,120,.06) 1px, transparent 1px, transparent 50px), repeating-linear-gradient(0deg, rgba(26,122,120,.06) 0px, rgba(26,122,120,.06) 1px, transparent 1px, transparent 50px); }
/* teal accent stripe */
.vt-corridor__stripe { position: absolute; top: 38%; left: 0; right: 0; height: 6px; background: linear-gradient(90deg, transparent, var(--vt-teal) 10%, var(--vt-teal) 90%, transparent); opacity: .4; }
/* door */
.vt-corridor__door { position: absolute; bottom: 32%; right: 15%; width: 52px; height: 88px; background: linear-gradient(180deg, #E8F4F2 0%, #D0E8E4 100%); border: 2px solid #8ABAB4; border-bottom: none; border-radius: 3px 3px 0 0; }
.vt-corridor__door::before { content: ''; position: absolute; top: 6px; left: 6px; right: 6px; bottom: 6px; border: 1px solid rgba(26,122,120,.2); border-radius: 2px; }
.vt-corridor__door::after { content: ''; position: absolute; right: 8px; top: 50%; transform: translateY(-50%); width: 5px; height: 5px; background: var(--vt-amber); border-radius: 50%; }
/* door sign */
.vt-corridor__sign { position: absolute; bottom: calc(32% + 100px); right: calc(15% - 10px); width: 72px; height: 18px; background: var(--vt-teal); border-radius: 2px; display: flex; align-items: center; justify-content: center; }
.vt-corridor__sign::before { content: 'CONSULT 1'; font-family: 'Poppins', sans-serif; font-size: 5px; font-weight: 700; color: #fff; letter-spacing: .05em; }
/* medical cabinet */
.vt-corridor__cabinet { position: absolute; bottom: 32%; left: 8%; width: 48px; height: 64px; background: linear-gradient(180deg, #F0F8F6 0%, #E0EEE8 100%); border: 1px solid #A8C8C0; border-radius: 2px; }
.vt-corridor__cabinet::before { content: '+'; position: absolute; top: 6px; left: 50%; transform: translateX(-50%); font-size: 1rem; font-weight: 900; color: #E84040; line-height: 1; }
.vt-corridor__cabinet::after { content: ''; position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); width: 24px; height: 1px; background: rgba(26,122,120,.2); box-shadow: 0 8px 0 rgba(26,122,120,.2), 0 16px 0 rgba(26,122,120,.2); }
/* ceiling light in corridor */
.vt-corridor__lamp { position: absolute; top: 8%; left: 50%; transform: translateX(-50%); width: 40%; height: 4px; background: linear-gradient(90deg, transparent, #FFFFFF, transparent); border-radius: 2px; box-shadow: 0 0 20px 8px rgba(255,255,255,.6); }

.vt-about__text { }
.vt-about__feature { display: flex; gap: 16px; margin-top: 24px; }
.vt-about__feature-icon { flex-shrink: 0; width: 44px; height: 44px; background: var(--vt-teal-lt); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; }
.vt-about__feature-text strong { font-family: var(--vt-ff-head); font-size: .92rem; font-weight: 700; color: var(--vt-navy); display: block; margin-bottom: 3px; }
.vt-about__feature-text span { font-size: .85rem; color: #5A6E68; }

/* ════════════════════════════════════════════════════════════════════
   TESTIMONIALS
════════════════════════════════════════════════════════════════════ */
.vt-testimonials { padding: 100px 0; background: linear-gradient(180deg, #F2F8F6 0%, var(--vt-warm) 100%); }
.vt-testimonials__header { text-align: center; max-width: 560px; margin: 0 auto 56px; }
.vt-testimonials__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 24px; }
.vt-testimonial { background: #fff; border-radius: var(--vt-radius); padding: 36px; border: 1px solid #D8EDEA; }
.vt-testimonial__stars { color: var(--vt-amber); font-size: 1rem; letter-spacing: 2px; margin-bottom: 18px; }
.vt-testimonial__text { font-size: .92rem; line-height: 1.85; color: #4A5A52; font-style: italic; }
.vt-testimonial__author { margin-top: 22px; display: flex; gap: 12px; align-items: center; }
.vt-testimonial__avatar { width: 40px; height: 40px; background: linear-gradient(135deg, var(--vt-teal), var(--vt-teal-dark)); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-family: var(--vt-ff-head); font-size: .88rem; font-weight: 700; color: #fff; }
.vt-testimonial__name { font-family: var(--vt-ff-head); font-size: .88rem; font-weight: 700; color: var(--vt-navy); }
.vt-testimonial__pet { font-size: .78rem; color: var(--vt-teal); }

/* ════════════════════════════════════════════════════════════════════
   BOOKING / CTA
════════════════════════════════════════════════════════════════════ */
.vt-booking { padding: 100px 0; background: #fff; }
.vt-booking__inner { display: grid; grid-template-columns: 1fr 1fr; gap: 72px; align-items: start; }
.vt-booking__info { }
.vt-booking__opening { margin-top: 32px; display: flex; flex-direction: column; gap: 12px; }
.vt-booking__opening-row { display: flex; justify-content: space-between; font-size: .9rem; padding: 10px 0; border-bottom: 1px solid #E8F2F0; }
.vt-booking__opening-row:last-child { border-bottom: none; }
.vt-booking__opening-day { font-family: var(--vt-ff-head); font-weight: 600; color: var(--vt-navy); }
.vt-booking__opening-hours { color: #5A6E68; }
.vt-booking__emergency { display: flex; align-items: center; gap: 12px; background: #FFF3E8; border: 1px solid #F0C898; border-radius: var(--vt-radius); padding: 16px 20px; margin-top: 28px; }
.vt-booking__emergency-icon { font-size: 1.6rem; }
.vt-booking__emergency-text strong { font-family: var(--vt-ff-head); font-size: .9rem; font-weight: 700; color: var(--vt-navy); display: block; }
.vt-booking__emergency-text span { font-size: .82rem; color: #7A5A38; }

/* form */
.vt-form { background: var(--vt-warm); border-radius: var(--vt-radius); padding: 40px; border: 1px solid #D8EDEA; }
.vt-form__title { font-family: var(--vt-ff-head); font-size: 1.3rem; font-weight: 700; color: var(--vt-navy); margin-bottom: 28px; }
.vt-form__row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.vt-form__group { display: flex; flex-direction: column; gap: 6px; margin-bottom: 18px; }
.vt-form__group--full { grid-column: 1 / -1; }
.vt-form__label { font-family: var(--vt-ff-head); font-size: .78rem; font-weight: 600; color: var(--vt-navy); letter-spacing: .03em; }
.vt-form__input, .vt-form__select, .vt-form__textarea { width: 100%; padding: 11px 15px; border: 1px solid #C8DCDA; border-radius: var(--vt-radius); font-family: var(--vt-ff-body); font-size: .88rem; color: var(--vt-text); background: #fff; transition: var(--vt-trans); outline: none; }
.vt-form__input:focus, .vt-form__select:focus, .vt-form__textarea:focus { border-color: var(--vt-teal); box-shadow: 0 0 0 3px rgba(26,122,120,.12); }
.vt-form__textarea { resize: vertical; min-height: 100px; }
.vt-form__submit { width: 100%; padding: 14px; font-family: var(--vt-ff-head); font-size: .92rem; font-weight: 700; color: #fff; background: linear-gradient(135deg, var(--vt-teal) 0%, var(--vt-teal-dark) 100%); border: none; border-radius: var(--vt-radius); cursor: pointer; transition: var(--vt-trans); }
.vt-form__submit:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(26,122,120,.35); }
.vt-form__note { font-size: .75rem; color: #7A8E88; text-align: center; margin-top: 12px; }

/* ════════════════════════════════════════════════════════════════════
   FOOTER CTA STRIP
════════════════════════════════════════════════════════════════════ */
.vt-footer-cta { background: linear-gradient(135deg, var(--vt-teal-dark) 0%, var(--vt-navy) 100%); padding: 72px 0; text-align: center; }
.vt-footer-cta__title { font-family: var(--vt-ff-head); font-size: clamp(1.6rem, 3vw, 2.4rem); font-weight: 800; color: #fff; margin-bottom: 14px; }
.vt-footer-cta__sub { font-size: .98rem; color: rgba(255,255,255,.72); margin-bottom: 32px; }
.vt-footer-cta__actions { display: flex; gap: 14px; justify-content: center; flex-wrap: wrap; }
.vt-footer-cta__phone { font-family: var(--vt-ff-head); font-size: 1.6rem; font-weight: 800; color: #7ECFCC; display: block; margin-bottom: 28px; }

/* ════════════════════════════════════════════════════════════════════
   RESPONSIVE
════════════════════════════════════════════════════════════════════ */
@media (max-width: 900px) {
    .vt-about__inner, .vt-booking__inner { grid-template-columns: 1fr; gap: 48px; }
    .vt-counters__grid { grid-template-columns: repeat(2, 1fr); }
    .vt-trust__item { padding: 16px 20px; }
}
@media (max-width: 600px) {
    .vt-hero { min-height: 80vh; }
    .vt-counters__grid { grid-template-columns: repeat(2, 1fr); }
    .vt-form__row { grid-template-columns: 1fr; }
    .vt-trust__inner { flex-direction: column; }
    .vt-trust__item { border-right: none; border-bottom: 1px solid #E8F2F0; width: 100%; }
}
</style>

<div class="vt-wrap">

    <!-- ═══════════════════════════════════ HERO ═══════════════════════════════════ -->
    <section class="vt-hero">
        <div class="vt-scene" aria-hidden="true">

            <!-- clinic architecture -->
            <div class="vt-scene__ceiling"></div>
            <div class="vt-scene__light-strip"></div>
            <div class="vt-scene__wall"></div>
            <div class="vt-scene__wall-stripe"></div>
            <div class="vt-scene__dado"></div>
            <div class="vt-scene__dado-wall"></div>
            <div class="vt-scene__floor">
                <div class="vt-scene__floor-line"></div>
            </div>

            <!-- plants -->
            <?php foreach ( $plants as $pl ) : ?>
            <div class="vt-plant" style="left:<?= $pl['x'] ?>%;">
                <div class="vt-plant__stem" style="height:<?= $pl['h'] ?>px;"></div>
                <?php for ( $li = 0; $li < $pl['leaves']; $li++ ) :
                    $lx = ( $li % 2 === 0 ) ? -18 : 10;
                    $ly = $li * 10;
                    $lw = 20 + rand(-3,3);
                    $lh = 14 + rand(-2,2);
                ?>
                <div class="vt-plant__leaf" style="position:absolute;bottom:<?= $pl['h'] - $ly ?>px;left:calc(50% + <?= $lx ?>px);width:<?= $lw ?>px;height:<?= $lh ?>px;transform:rotate(<?= ($li%2===0)?'-':'';?>30deg);"></div>
                <?php endfor; ?>
                <div class="vt-plant__soil"></div>
                <div class="vt-plant__pot" style="--pot-top:<?= $pl['pot'] ?>;--pot-bot:<?= $pl['pot'] ?>cc;"></div>
            </div>
            <?php endforeach; ?>

            <!-- waiting room chairs -->
            <?php foreach ( $chairs as $ch ) : ?>
            <div class="vt-chair" style="left:<?= $ch['x'] ?>%;">
                <div class="vt-chair__back" style="width:38px;background:<?= $ch['color'] ?>;"></div>
                <div class="vt-chair__seat" style="width:38px;background:<?= $ch['color'] ?>;margin-top:10px;">
                    <div class="vt-chair__leg" style="left:4px;"></div>
                    <div class="vt-chair__leg" style="right:4px;"></div>
                </div>
            </div>
            <?php endforeach; ?>

            <!-- pets in waiting room -->
            <?php foreach ( $pets as $pet ) :
                $is_dog = $pet['type'] === 'dog';
                $bw = $is_dog ? 42 : 38;
                $bh = $is_dog ? 24 : 20;
                $hw = $is_dog ? 28 : 26;
                $hh = $is_dog ? 22 : 20;
                $ew = $is_dog ? 10 : 10;
                $eh = $is_dog ? 12 : 10;
            ?>
            <div class="vt-pet vt-pet--<?= $pet['type'] ?>" style="left:<?= $pet['x'] ?>%;bottom:calc(28% + 22px);">
                <!-- body -->
                <div class="vt-pet__body" style="width:<?= $bw ?>px;height:<?= $bh ?>px;background:<?= $pet['color'] ?>;margin:0 auto;"></div>
                <!-- head row -->
                <div style="position:relative;width:<?= $hw ?>px;margin:-4px auto 0;height:<?= $hh ?>px;">
                    <div class="vt-pet__head" style="width:100%;height:100%;background:<?= $pet['color'] ?>;"></div>
                    <!-- ears -->
                    <div class="vt-pet__ear-l" style="width:<?= $ew ?>px;height:<?= $eh ?>px;background:<?= $pet['spot'] ?>;top:-4px;<?= $is_dog ? 'left:-2px' : 'left:2px' ?>"></div>
                    <div class="vt-pet__ear-r" style="width:<?= $ew ?>px;height:<?= $eh ?>px;background:<?= $pet['spot'] ?>;top:-4px;<?= $is_dog ? 'right:-2px' : 'right:2px' ?>"></div>
                </div>
                <!-- tail -->
                <?php if ( $is_dog ) : ?>
                <div class="vt-pet__tail" style="width:18px;height:8px;background:<?= $pet['color'] ?>;bottom:<?= $bh - 6 ?>px;right:-14px;position:absolute;border-radius:0 8px 8px 0;transform:rotate(-20deg);"></div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>

            <!-- reception desk -->
            <div class="vt-scene__desk">
                <div class="vt-scene__monitor">
                    <div class="vt-scene__monitor-screen"></div>
                    <div class="vt-scene__monitor-stand"></div>
                    <div class="vt-scene__monitor-base"></div>
                </div>
                <div class="vt-scene__receptionist">
                    <div class="vt-scene__receptionist-head">
                        <div class="vt-scene__receptionist-hair"></div>
                    </div>
                    <div class="vt-scene__receptionist-body"></div>
                </div>
                <div class="vt-scene__desk-top"></div>
                <div class="vt-scene__desk-front"></div>
                <div class="vt-scene__desk-panel"></div>
            </div>

            <!-- floating paw prints -->
            <?php foreach ( $paws as $pw ) : ?>
            <div class="vt-paw" style="left:<?= $pw['x'] ?>%;top:<?= $pw['y'] ?>%;width:<?= $pw['sz'] ?>px;opacity:<?= $pw['op'] / 100 ?>;--vt-rot:<?= $pw['r'] ?>deg;animation-delay:<?= $pw['delay'] ?>s;animation-duration:<?= $pw['dur'] ?>s;">
                <svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg" width="<?= $pw['sz'] ?>" height="<?= $pw['sz'] ?>">
                    <ellipse cx="10" cy="10" rx="5" ry="6"/>
                    <ellipse cx="22" cy="8" rx="5" ry="6"/>
                    <ellipse cx="32" cy="14" rx="5" ry="6"/>
                    <ellipse cx="4" cy="20" rx="4" ry="5"/>
                    <ellipse cx="20" cy="28" rx="12" ry="10"/>
                </svg>
            </div>
            <?php endforeach; ?>

        </div><!-- /.vt-scene -->

        <div class="vt-container">
            <div class="vt-hero__content">
                <p class="vt-hero__eyebrow">🐾 Caring for Companion Animals</p>
                <h1 class="vt-hero__title">
                    Expert <em>Veterinary</em><br>
                    Care for Every Pet
                </h1>
                <p class="vt-hero__sub">Kensington Veterinary Centre has provided exceptional clinical care to London's pets since 2002. From routine wellness to complex surgery, our RCVS-accredited team is here for your animal family.</p>
                <div class="vt-hero__ctas">
                    <a href="#booking" class="vt-btn vt-btn--primary">Book an Appointment</a>
                    <a href="#services" class="vt-btn vt-btn--ghost">Our Services</a>
                </div>
                <div class="vt-hero__badge">
                    <span>✓</span>
                    RCVS Accredited Practice · Open 7 Days · Emergency Line Available
                </div>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ TRUST BAR ═════════════════════════════ -->
    <div class="vt-trust">
        <div class="vt-container">
            <div class="vt-trust__inner">
                <?php
                $trust_items = [
                    [ 'icon' => '🏅', 'label' => 'RCVS Accredited',        'sub' => 'Practice of Excellence' ],
                    [ 'icon' => '⏰', 'label' => 'Open 7 Days',             'sub' => 'Mon–Fri 8am–7pm · Weekends 9–5' ],
                    [ 'icon' => '📞', 'label' => '24h Emergency Line',      'sub' => '020 7946 0128' ],
                    [ 'icon' => '🌟', 'label' => '4.9 Google Rating',       'sub' => 'Over 1,400 reviews' ],
                    [ 'icon' => '🧪', 'label' => 'In-House Lab',            'sub' => 'Results within hours' ],
                ];
                foreach ( $trust_items as $ti ) : ?>
                <div class="vt-trust__item">
                    <span class="vt-trust__icon"><?= $ti['icon'] ?></span>
                    <div>
                        <div class="vt-trust__label"><?= esc_html( $ti['label'] ) ?></div>
                        <div class="vt-trust__sub"><?= esc_html( $ti['sub'] ) ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- ═══════════════════════════════════ SERVICES ══════════════════════════════ -->
    <section class="vt-services" id="services">
        <div class="vt-container">
            <div class="vt-services__header">
                <span class="vt-section-label">What We Offer</span>
                <h2 class="vt-section-title">Comprehensive <span>Veterinary Services</span></h2>
                <p class="vt-section-body">From preventive care to advanced diagnostics and surgery, we offer a complete range of services under one roof — delivered with expertise and compassion.</p>
            </div>
            <div class="vt-services__grid">
                <?php foreach ( $services as $svc ) : ?>
                <div class="vt-service-card">
                    <span class="vt-service-card__icon"><?= $svc['icon'] ?></span>
                    <h3 class="vt-service-card__title"><?= esc_html( $svc['title'] ) ?></h3>
                    <p class="vt-service-card__desc"><?= esc_html( $svc['desc'] ) ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ COUNTERS ═════════════════════════════ -->
    <section class="vt-counters" aria-label="Practice statistics">
        <div class="vt-container">
            <div class="vt-counters__grid">
                <?php foreach ( $counters as $c ) : ?>
                <div>
                    <div class="vt-counter__value"
                         data-target="<?= $c['value'] ?>"
                         <?= $c['float'] ? 'data-float="1"' : '' ?>>
                        <span>0</span><?= esc_html( $c['suffix'] ) ?>
                    </div>
                    <div class="vt-counter__label"><?= esc_html( $c['label'] ) ?></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ TEAM ═════════════════════════════════ -->
    <section class="vt-team" id="team">
        <div class="vt-container">
            <div class="vt-team__header">
                <span class="vt-section-label">Our Vets</span>
                <h2 class="vt-section-title">Meet Your <span>Care Team</span></h2>
                <p class="vt-section-body">Our vets bring specialist knowledge across surgery, internal medicine, emergency care, and exotic animals — all united by a deep commitment to your pet's wellbeing.</p>
            </div>
            <div class="vt-team__grid">
                <?php foreach ( $team as $i => $member ) :
                    $skin_tones = [ '#DEB887', '#C8975A', '#A0724A', '#F5CBA7' ];
                    $skin  = $skin_tones[ $i % count($skin_tones) ];
                    $hair  = $hair_colors[ $i % count($hair_colors) ];
                    $clip  = $hair_styles[ $i % count($hair_styles) ];
                    $coat  = $coat_colors[ $i % count($coat_colors) ];
                ?>
                <div class="vt-team-card">
                    <div class="vt-team-card__figure">
                        <div class="vt-figure"
                             style="--fig-skin:<?= $skin ?>;--fig-hair:<?= $hair ?>;--fig-clip:<?= $clip ?>;--fig-coat:<?= $coat ?>;--fig-scrub:var(--vt-teal);">
                            <div class="vt-figure__head">
                                <div class="vt-figure__hair"></div>
                            </div>
                            <div class="vt-figure__neck"></div>
                            <div class="vt-figure__body">
                                <div class="vt-figure__steth"></div>
                                <div class="vt-figure__arm-l"></div>
                                <div class="vt-figure__arm-r"></div>
                            </div>
                        </div>
                    </div>
                    <div class="vt-team-card__info">
                        <div class="vt-team-card__name"><?= esc_html( $member['name'] ) ?></div>
                        <div class="vt-team-card__role"><?= esc_html( $member['role'] ) ?></div>
                        <div class="vt-team-card__qual"><?= esc_html( $member['qual'] ) ?></div>
                        <div class="vt-team-card__yrs">🐾 <?= $member['yrs'] ?> years experience</div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ PACKAGES ═════════════════════════════ -->
    <section class="vt-packages" id="packages">
        <div class="vt-container">
            <div class="vt-packages__header">
                <span class="vt-section-label">Pricing & Plans</span>
                <h2 class="vt-section-title">Simple <span>Transparent Pricing</span></h2>
                <p class="vt-section-body">No hidden fees. Our HealthCare Plan spreads the cost of routine care across the year so you can budget with confidence.</p>
            </div>
            <div class="vt-packages__grid">
                <?php foreach ( $packages as $pkg ) : ?>
                <div class="vt-package-card <?= $pkg['featured'] ? 'vt-package-card--featured' : '' ?>">
                    <?php if ( $pkg['featured'] ) : ?>
                    <div class="vt-package-card__badge">Most Popular</div>
                    <?php endif; ?>
                    <div class="vt-package-card__name"><?= esc_html( $pkg['name'] ) ?></div>
                    <div class="vt-package-card__price-row">
                        <div class="vt-package-card__price"><?= esc_html( $pkg['price'] ) ?></div>
                        <div class="vt-package-card__period"><?= esc_html( $pkg['period'] ) ?></div>
                    </div>
                    <ul class="vt-package-card__list">
                        <?php foreach ( $pkg['items'] as $item ) : ?>
                        <li class="vt-package-card__item"><?= esc_html( $item ) ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <a href="#booking" class="vt-btn <?= $pkg['featured'] ? 'vt-btn--ghost' : 'vt-btn--outline' ?>" style="width:100%;justify-content:center;">
                        Book Now
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ ABOUT ════════════════════════════════ -->
    <section class="vt-about" id="about">
        <div class="vt-container">
            <div class="vt-about__inner">
                <div class="vt-about__visual" aria-hidden="true">
                    <!-- CSS clinic corridor scene -->
                    <div class="vt-corridor">
                        <div class="vt-corridor__lamp"></div>
                        <div class="vt-corridor__stripe"></div>
                        <div class="vt-corridor__cabinet"></div>
                        <div class="vt-corridor__door"></div>
                        <div class="vt-corridor__sign"></div>
                    </div>
                </div>
                <div class="vt-about__text">
                    <span class="vt-section-label">Our Practice</span>
                    <h2 class="vt-section-title">A Clinic Built on <span>Trust & Excellence</span></h2>
                    <p class="vt-section-body">Founded in Kensington in 2002, we have grown from a single-vet practice to a 12-strong clinical team offering specialist-level care without referral wait times.</p>
                    <div class="vt-about__feature">
                        <div class="vt-about__feature-icon">🏥</div>
                        <div class="vt-about__feature-text">
                            <strong>Purpose-Built Facilities</strong>
                            <span>Three consult rooms, a dedicated surgical theatre, and full digital imaging suite.</span>
                        </div>
                    </div>
                    <div class="vt-about__feature">
                        <div class="vt-about__feature-icon">🔬</div>
                        <div class="vt-about__feature-text">
                            <strong>In-House Diagnostics</strong>
                            <span>Full haematology, biochemistry, and urinalysis with same-day results.</span>
                        </div>
                    </div>
                    <div class="vt-about__feature">
                        <div class="vt-about__feature-icon">🎓</div>
                        <div class="vt-about__feature-text">
                            <strong>Continuing Education</strong>
                            <span>Every vet completes annual CPD to stay current with the latest clinical evidence.</span>
                        </div>
                    </div>
                    <div style="margin-top:32px;">
                        <a href="#booking" class="vt-btn vt-btn--primary">Book a Consultation</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ TESTIMONIALS ═════════════════════════ -->
    <section class="vt-testimonials">
        <div class="vt-container">
            <div class="vt-testimonials__header">
                <span class="vt-section-label">Pet Owner Reviews</span>
                <h2 class="vt-section-title">Loved by <span>London's Pet Owners</span></h2>
            </div>
            <div class="vt-testimonials__grid">
                <?php foreach ( $testimonials as $t ) :
                    $init = strtoupper( $t['name'][0] );
                ?>
                <div class="vt-testimonial">
                    <div class="vt-testimonial__stars">★★★★★</div>
                    <p class="vt-testimonial__text">"<?= esc_html( $t['text'] ) ?>"</p>
                    <div class="vt-testimonial__author">
                        <div class="vt-testimonial__avatar"><?= $init ?></div>
                        <div>
                            <div class="vt-testimonial__name"><?= esc_html( $t['name'] ) ?></div>
                            <div class="vt-testimonial__pet"><?= esc_html( $t['pet'] ) ?></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ BOOKING ══════════════════════════════ -->
    <section class="vt-booking" id="booking">
        <div class="vt-container">
            <div class="vt-booking__inner">
                <div class="vt-booking__info">
                    <span class="vt-section-label">Book an Appointment</span>
                    <h2 class="vt-section-title">We're <span>Here for Your Pet</span></h2>
                    <p class="vt-section-body">New patients are always welcome. Book online or call us — our friendly reception team will find the earliest convenient appointment for you.</p>
                    <div class="vt-booking__opening">
                        <div class="vt-booking__opening-row">
                            <span class="vt-booking__opening-day">Monday – Friday</span>
                            <span class="vt-booking__opening-hours">8:00 am – 7:00 pm</span>
                        </div>
                        <div class="vt-booking__opening-row">
                            <span class="vt-booking__opening-day">Saturday</span>
                            <span class="vt-booking__opening-hours">9:00 am – 5:00 pm</span>
                        </div>
                        <div class="vt-booking__opening-row">
                            <span class="vt-booking__opening-day">Sunday</span>
                            <span class="vt-booking__opening-hours">10:00 am – 3:00 pm</span>
                        </div>
                        <div class="vt-booking__opening-row">
                            <span class="vt-booking__opening-day">Bank Holidays</span>
                            <span class="vt-booking__opening-hours">10:00 am – 2:00 pm</span>
                        </div>
                    </div>
                    <div class="vt-booking__emergency">
                        <span class="vt-booking__emergency-icon">🚨</span>
                        <div class="vt-booking__emergency-text">
                            <strong>24-Hour Emergency Line</strong>
                            <span>For out-of-hours emergencies call 020 7946 0128</span>
                        </div>
                    </div>
                </div>
                <div>
                    <form class="vt-form" method="post" action="">
                        <?php wp_nonce_field( 'tf_vt_booking', 'tf_vt_nonce' ); ?>
                        <h3 class="vt-form__title">Request an Appointment</h3>
                        <div class="vt-form__row">
                            <div class="vt-form__group">
                                <label class="vt-form__label" for="vt-owner-name">Your Name *</label>
                                <input class="vt-form__input" type="text" id="vt-owner-name" name="owner_name" placeholder="Jane Smith" required>
                            </div>
                            <div class="vt-form__group">
                                <label class="vt-form__label" for="vt-phone">Phone Number *</label>
                                <input class="vt-form__input" type="tel" id="vt-phone" name="phone" placeholder="020 7946 0000" required>
                            </div>
                        </div>
                        <div class="vt-form__row">
                            <div class="vt-form__group">
                                <label class="vt-form__label" for="vt-email">Email Address *</label>
                                <input class="vt-form__input" type="email" id="vt-email" name="email" placeholder="jane@example.com" required>
                            </div>
                            <div class="vt-form__group">
                                <label class="vt-form__label" for="vt-pet-name">Pet's Name *</label>
                                <input class="vt-form__input" type="text" id="vt-pet-name" name="pet_name" placeholder="Buddy" required>
                            </div>
                        </div>
                        <div class="vt-form__row">
                            <div class="vt-form__group">
                                <label class="vt-form__label" for="vt-species">Species *</label>
                                <select class="vt-form__select" id="vt-species" name="species">
                                    <option value="">Select species…</option>
                                    <option value="dog">Dog</option>
                                    <option value="cat">Cat</option>
                                    <option value="rabbit">Rabbit</option>
                                    <option value="bird">Bird</option>
                                    <option value="reptile">Reptile</option>
                                    <option value="small-animal">Small Animal</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                            <div class="vt-form__group">
                                <label class="vt-form__label" for="vt-service">Reason for Visit *</label>
                                <select class="vt-form__select" id="vt-service" name="service">
                                    <option value="">Select reason…</option>
                                    <option value="wellness">Wellness Exam</option>
                                    <option value="vaccination">Vaccination</option>
                                    <option value="illness">Illness / Injury</option>
                                    <option value="surgery">Surgery Enquiry</option>
                                    <option value="dental">Dental Care</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                        </div>
                        <div class="vt-form__group vt-form__group--full">
                            <label class="vt-form__label" for="vt-notes">Additional Notes</label>
                            <textarea class="vt-form__textarea" id="vt-notes" name="notes" placeholder="Any symptoms, concerns, or preferred appointment times…"></textarea>
                        </div>
                        <button type="submit" class="vt-form__submit">Request Appointment →</button>
                        <p class="vt-form__note">We will confirm your appointment by phone or email within 2 hours.</p>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════ FOOTER CTA ═══════════════════════════ -->
    <section class="vt-footer-cta">
        <div class="vt-container">
            <h2 class="vt-footer-cta__title">Your Pet's Health Is Our Priority</h2>
            <a href="tel:02079460128" class="vt-footer-cta__phone">020 7946 0128</a>
            <p class="vt-footer-cta__sub">Kensington Veterinary Centre · 42 Kensington High Street, London W8 · Open 7 Days</p>
            <div class="vt-footer-cta__actions">
                <a href="#booking" class="vt-btn vt-btn--primary">Book Online</a>
                <a href="#services" class="vt-btn vt-btn--ghost">Our Services</a>
            </div>
        </div>
    </section>

</div><!-- /.vt-wrap -->

<script>
/* ── IntersectionObserver animated counters ───────────────────────── */
(function () {
    'use strict';
    var easeOut = function (t) { return 1 - Math.pow(1 - t, 3); };
    var els = document.querySelectorAll('.vt-counter__value[data-target]');
    if (!els.length) return;
    var obs = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (!entry.isIntersecting) return;
            obs.unobserve(entry.target);
            var el      = entry.target;
            var target  = parseFloat(el.dataset.target);
            var isFloat = !!el.dataset.float;
            var suffix  = el.dataset.suffix || '';
            var span    = el.querySelector('span');
            if (!span || isNaN(target)) return;
            var dur = 1800, start = null;
            function tick(ts) {
                if (!start) start = ts;
                var p = Math.min((ts - start) / dur, 1);
                var v = easeOut(p) * target;
                span.textContent = isFloat ? v.toFixed(1) : Math.round(v).toLocaleString();
                if (p < 1) requestAnimationFrame(tick);
                else span.textContent = isFloat ? target.toFixed(1) : target.toLocaleString();
            }
            requestAnimationFrame(tick);
        });
    }, { threshold: 0.4 });
    els.forEach(function (el) { obs.observe(el); });
})();
</script>

<?php get_footer(); ?>
