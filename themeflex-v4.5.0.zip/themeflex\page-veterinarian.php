<?php
/**
 * Template Name: Veterinarian
 *
 * Premium veterinary clinic homepage.
 * Fonts  : Nunito + Open Sans (Google Fonts)
 * Palette: clinic white #FAFCFF / sky teal #0D9DA8 / warm amber #E8A435 / soft grass #4CAF7A / slate #2C3A4A
 * Tokens : --vt-* (zero cross-template contamination)
 */
defined('ABSPATH') || exit;
srand(crc32(get_the_permalink()));

/* ── Hero paw-print particles ─────────────────────────── */
$paw_chars = ['🐾','·','∙','•','○','◦'];
$particles = [];
for ($i = 0; $i < 18; $i++) {
    $particles[] = [
        'sym'  => $paw_chars[array_rand($paw_chars)],
        'top'  => rand(5,92),
        'left' => rand(2,96),
        'size' => rand(12,22),
        'dur'  => rand(7,16),
        'del'  => rand(0,9),
        'col'  => (rand(0,1) ? 'rgba(13,157,168,.5)' : 'rgba(232,164,53,.4)'),
    ];
}

/* ── Waiting room furniture: chairs ─────────────────────── */
$chairs = [];
for ($i = 0; $i < 4; $i++) {
    $chairs[] = [
        'col' => ['#e67e22','#2980b9','#27ae60','#8e44ad'][$i],
        'left'=> 8 + $i * 23,
    ];
}

/* ── PHP window: fish in aquarium ───────────────────────── */
$fish = [];
for ($i = 0; $i < 6; $i++) {
    $fish[] = [
        'top'  => rand(20,70),
        'size' => rand(16,28),
        'col'  => ['#e74c3c','#f39c12','#2ecc71','#3498db','#9b59b6','#e67e22'][$i],
        'dur'  => rand(4,9),
        'del'  => rand(0,6),
        'dir'  => rand(0,1),
    ];
}

/* ── Pet icons beside services ─────────────────────────── */
$services = [
    ['icon'=>'🐕','title'=>'Dogs','desc'=>'Comprehensive canine healthcare from wellness checks and vaccinations to orthopaedic surgery and oncology.'],
    ['icon'=>'🐈','title'=>'Cats','desc'=>'Feline-friendly consultations, dental care, neutering and specialist medical management.'],
    ['icon'=>'🐇','title'=>'Rabbits & Exotics','desc'=>'Specialist care for rabbits, guinea pigs, chinchillas, ferrets and other small mammals.'],
    ['icon'=>'🦜','title'=>'Birds & Reptiles','desc'=>'Avian health checks, feather and beak assessments, plus reptile nutrition and parasite control.'],
    ['icon'=>'🔬','title'=>'Diagnostics','desc'=>'In-house laboratory, digital X-ray, ultrasound and endoscopy for rapid, accurate diagnosis.'],
    ['icon'=>'🏥','title'=>'Surgery','desc'=>'Soft tissue, orthopaedic and dental surgery by RCVS-recognised surgical specialists.'],
    ['icon'=>'💊','title'=>'Preventive Care','desc'=>'Vaccination programmes, parasite prevention, microchipping and tailored nutrition plans.'],
    ['icon'=>'🚑','title'=>'24/7 Emergencies','desc'=>'Round-the-clock emergency and critical care for when every minute counts.'],
];

$conditions = [
    'Annual Vaccinations','Microchipping','Neutering','Flea & Worm Treatment',
    'Dental Disease','Arthritis','Diabetes','Skin Allergies','Ear Infections',
    'Digestive Problems','Kennel Cough','Cat Flu','Rabbit Dental',
    'Weight Management','Senior Pet Care','End-of-Life Care','Puppy Health Checks',
    'Kitten Starter Plans','Pre-op Blood Tests','Post-op Recovery',
];

$steps = [
    ['num'=>'01','title'=>'Register','desc'=>'Join us online in minutes. Bring your pet\'s vaccination and medication history to your first visit.'],
    ['num'=>'02','title'=>'Book','desc'=>'Same-day and next-day appointments available. Nurse-led triage calls at no extra charge.'],
    ['num'=>'03','title'=>'Consult','desc'=>'A calm, unhurried consultation in our purpose-designed, low-stress consulting rooms.'],
    ['num'=>'04','title'=>'Diagnose','desc'=>'Results from our in-house lab and imaging suite often available the same day.'],
    ['num'=>'05','title'=>'Care Plan','desc'=>'A personalised care plan with clear costs, follow-up schedule and home-care advice.'],
];

$gallery = [
    ['label'=>'Consulting Room','color'=>'linear-gradient(135deg,#0a4a50,#0D9DA8)','icon'=>'🩺'],
    ['label'=>'Surgical Suite','color'=>'linear-gradient(135deg,#1a2a3a,#4CAF7A)','icon'=>'⚕️'],
    ['label'=>'Recovery Ward','color'=>'linear-gradient(135deg,#2a1a0a,#E8A435)','icon'=>'🛏️'],
    ['label'=>'Dental Suite','color'=>'linear-gradient(135deg,#0a2a1a,#4CAF7A)','icon'=>'🦷'],
    ['label'=>'Diagnostic Lab','color'=>'linear-gradient(135deg,#0a1a2a,#0D9DA8)','icon'=>'🔬'],
    ['label'=>'Reception','color'=>'linear-gradient(135deg,#1a2a1a,#4CAF7A)','icon'=>'🏥'],
];

$counters = [
    ['val'=>32,'suffix'=>' yrs','label'=>'Serving Our Community','float'=>0],
    ['val'=>12000,'suffix'=>'+','label'=>'Registered Patients','float'=>0],
    ['val'=>4.9,'suffix'=>'★','label'=>'Average Rating','float'=>1],
    ['val'=>24,'suffix'=>'/7','label'=>'Emergency Care','float'=>0],
];

$packages = [
    ['name'=>'Puppy/Kitten Start','price'=>'£79','per'=>'first year bundle','featured'=>false,
     'features'=>['3 vaccinations','2 health checks','Microchip registration','Flea & worm starter pack','15% off neutering']],
    ['name'=>'Pet Health Plan','price'=>'£18','per'=>'per month','featured'=>true,
     'features'=>['Annual vaccinations','6-monthly health checks','Monthly flea & worm','Dental check','Priority appointments','10% off all services']],
    ['name'=>'Senior Care Plan','price'=>'£24','per'=>'per month','featured'=>false,
     'features'=>['Twice-yearly senior checks','6-monthly blood panels','Joint supplement discount','Nutrition consultation','Priority booking','Grief & end-of-life support']],
];

$testimonials = [
    ['name'=>'Charlotte B.','role'=>'Dog Owner — Labrador Charlie','rating'=>5,
     'text'=>'When Charlie collapsed on a Sunday evening I was terrified. The team saw him within the hour, diagnosed a splenic mass, operated the following morning and he came home three days later. The care and communication throughout were simply outstanding.'],
    ['name'=>'David L.','role'=>'Cat Owner — Mia & Jasper','rating'=>5,
     'text'=>'Both cats have been patients here for six years. The Health Plan means I never worry about costs and the team always remember who they are. Gentle, knowledgeable and genuinely passionate about animals.'],
    ['name'=>'Anika S.','role'=>'Rabbit Owner — Biscuit','rating'=>5,
     'text'=>'My rabbit needed a complex dental procedure that most vets were reluctant to take on. The exotic team here handled it brilliantly and gave me detailed home-care guidance. Biscuit recovered perfectly.'],
];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&family=Open+Sans:ital,wght@0,300;0,400;0,600;1,300&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════════
   VETERINARIAN — CSS TOKENS  (--vt-*)
   ═══════════════════════════════════════════════════════════ */
:root {
  --vt-white:     #FAFCFF;
  --vt-teal:      #0D9DA8;
  --vt-teal-lt:   #17b8c5;
  --vt-teal-d:    #0a7882;
  --vt-amber:     #E8A435;
  --vt-amber-d:   #c4881a;
  --vt-grass:     #4CAF7A;
  --vt-grass-d:   #39895c;
  --vt-slate:     #2C3A4A;
  --vt-slate-lt:  #445567;
  --vt-bg:        #F0F7F8;
  --vt-font-head: 'Nunito', sans-serif;
  --vt-font-body: 'Open Sans', sans-serif;
  --vt-radius:    14px;
  --vt-shadow:    0 6px 28px rgba(0,0,0,.09);
}

/* ── Reset & Base ───────────────────────────────────────── */
.vt-wrap *, .vt-wrap *::before, .vt-wrap *::after { box-sizing:border-box; margin:0; padding:0; }
.vt-wrap { font-family:var(--vt-font-body); color:var(--vt-slate); background:var(--vt-white); line-height:1.7; }
.vt-container { max-width:1200px; margin:0 auto; padding:0 24px; }
.vt-section { padding:96px 0; }
.vt-section--bg     { background:var(--vt-bg); }
.vt-section--teal   { background:linear-gradient(135deg,var(--vt-teal-d),var(--vt-teal)); color:#fff; }
.vt-section--slate  { background:var(--vt-slate); color:#fff; }
.vt-tag { display:inline-block; background:rgba(13,157,168,.12); color:var(--vt-teal-d); font-size:.7rem; font-weight:800; letter-spacing:.12em; text-transform:uppercase; padding:4px 14px; border-radius:20px; margin-bottom:16px; }
.vt-tag--light { background:rgba(255,255,255,.18); color:#fff; }
.vt-h2 { font-family:var(--vt-font-head); font-size:clamp(1.6rem,3.5vw,2.6rem); line-height:1.2; font-weight:800; margin-bottom:12px; }
.vt-lead { font-size:1.05rem; opacity:.8; max-width:640px; }
.vt-btn { display:inline-block; padding:14px 36px; border-radius:40px; font-family:var(--vt-font-head); font-size:.95rem; font-weight:800; letter-spacing:.04em; text-decoration:none; cursor:pointer; border:none; transition:transform .2s,box-shadow .2s; }
.vt-btn--primary { background:var(--vt-amber); color:#fff; box-shadow:0 4px 20px rgba(232,164,53,.4); }
.vt-btn--primary:hover { transform:translateY(-2px); box-shadow:0 8px 28px rgba(232,164,53,.5); }
.vt-btn--teal { background:var(--vt-teal); color:#fff; box-shadow:0 4px 20px rgba(13,157,168,.35); }
.vt-btn--teal:hover { transform:translateY(-2px); box-shadow:0 8px 28px rgba(13,157,168,.5); }
.vt-btn--ghost { background:transparent; color:#fff; border:2px solid rgba(255,255,255,.7); }
.vt-btn--ghost:hover { background:rgba(255,255,255,.12); transform:translateY(-2px); }

/* ═══════════════════════════════════════════════════════════
   HERO
   ═══════════════════════════════════════════════════════════ */
.vt-hero {
  position:relative; min-height:100vh;
  background:linear-gradient(145deg,#e8f6f7 0%,#c5eaec 35%,#a8e2e5 60%,#d4f4e4 100%);
  overflow:hidden; display:flex; align-items:center;
}
/* Subtle cloud shapes */
.vt-hero::before {
  content:''; position:absolute; inset:0; pointer-events:none;
  background:
    radial-gradient(ellipse 300px 180px at 10% 20%,rgba(255,255,255,.5) 0%,transparent 70%),
    radial-gradient(ellipse 400px 200px at 85% 15%,rgba(255,255,255,.4) 0%,transparent 70%),
    radial-gradient(ellipse 250px 150px at 55% 75%,rgba(255,255,255,.35) 0%,transparent 70%);
}

/* ── Floating paw particles ──────────────────────────────── */
.vt-particle { position:absolute; pointer-events:none; animation:vt-drift var(--dur,10s) var(--del,0s) ease-in-out infinite alternate; }
@keyframes vt-drift {
  from { transform:translateY(0) rotate(0deg); opacity:.4; }
  to   { transform:translateY(-30px) rotate(20deg); opacity:.8; }
}

.vt-hero__inner { position:relative; z-index:2; display:grid; grid-template-columns:1fr 1fr; gap:60px; align-items:center; padding:120px 0 80px; }

/* ── Clinic scene ─────────────────────────────────────────── */
.vt-scene {
  position:relative; width:100%; height:480px;
}

/* Clinic exterior wall */
.vt-clinic {
  position:absolute; bottom:0; left:5%; right:5%;
  height:380px;
  background:linear-gradient(180deg,#fafcff 0%,#f0f7f8 100%);
  border-radius:12px 12px 0 0;
  border:2px solid #d0e8ec;
  box-shadow:0 8px 32px rgba(0,0,0,.1);
}

/* Clinic roof */
.vt-clinic__roof {
  position:absolute; top:-36px; left:-4px; right:-4px; height:40px;
  background:linear-gradient(180deg,var(--vt-teal) 0%,var(--vt-teal-d) 100%);
  border-radius:14px 14px 0 0;
}
.vt-clinic__roof::before {
  content:'🏥 Greenfield Veterinary Clinic';
  position:absolute; bottom:8px; left:0; right:0;
  text-align:center; font-size:.65rem; font-family:var(--vt-font-head);
  font-weight:800; color:#fff; letter-spacing:.08em; white-space:nowrap;
}

/* Reception windows */
.vt-clinic__window {
  position:absolute; top:30px;
  background:linear-gradient(135deg,#dff5f7,#b8eaec);
  border:2px solid #0D9DA8; border-radius:6px;
}

/* Aquarium window (animated fish) */
.vt-aquarium {
  position:absolute; top:28px; right:20px;
  width:120px; height:90px;
  background:linear-gradient(180deg,#1a5a8a,#0a3a6a);
  border:3px solid #1a6a9a; border-radius:6px;
  overflow:hidden;
}
.vt-aquarium::before {
  content:''; position:absolute; bottom:0; left:0; right:0; height:12px;
  background:linear-gradient(to top,#2a6a3a,#3a8a4a);
}
.vt-aquarium::after {
  content:'Aquarium'; position:absolute; bottom:-20px; left:0; right:0;
  text-align:center; font-size:.55rem; color:#666; font-family:var(--vt-font-head); font-weight:700;
}
.vt-fish {
  position:absolute; font-size:18px;
  animation:vt-swim var(--fd,6s) var(--fd2,0s) ease-in-out infinite;
}
@keyframes vt-swim {
  0%   { left:5%;  transform:scaleX(1); }
  49%  { left:70%; transform:scaleX(1); }
  50%  { left:70%; transform:scaleX(-1); }
  100% { left:5%;  transform:scaleX(-1); }
}

/* Waiting room chairs */
.vt-chair {
  position:absolute; bottom:30px;
  width:44px;
}
.vt-chair__seat {
  height:16px; border-radius:4px 4px 0 0;
  box-shadow:inset 0 -3px rgba(0,0,0,.15);
}
.vt-chair__back {
  position:absolute; top:-22px; left:2px; right:2px; height:20px;
  border-radius:4px 4px 6px 6px;
  border-bottom:none;
}
.vt-chair__legs {
  display:flex; justify-content:space-between; padding:0 4px;
}
.vt-chair__leg { width:4px; height:10px; background:rgba(0,0,0,.25); border-radius:0 0 2px 2px; }

/* Pet on chair */
.vt-pet-on-chair {
  position:absolute; bottom:58px; font-size:22px;
  animation:vt-pet-bob 3s ease-in-out infinite alternate;
}
@keyframes vt-pet-bob {
  from { transform:translateY(0); }
  to   { transform:translateY(-5px); }
}

/* Vet reception desk */
.vt-desk {
  position:absolute; bottom:0; left:50%; transform:translateX(-50%);
  width:180px; height:60px;
  background:linear-gradient(180deg,var(--vt-teal),var(--vt-teal-d));
  border-radius:8px 8px 0 0;
}
.vt-desk::before {
  content:'Reception'; position:absolute; top:50%; left:50%; transform:translate(-50%,-50%);
  font-size:.55rem; color:rgba(255,255,255,.9); font-family:var(--vt-font-head); font-weight:800; letter-spacing:.08em;
}
/* Computer on desk */
.vt-computer {
  position:absolute; top:-46px; left:50%; transform:translateX(-50%);
  width:50px;
}
.vt-computer__screen {
  width:50px; height:36px;
  background:linear-gradient(135deg,#1a2a4a,#2a3a5a);
  border:2px solid #4a6a9a; border-radius:4px;
  display:flex; align-items:center; justify-content:center;
  font-size:.7rem;
}
.vt-computer__stand { width:16px; height:6px; background:#5a7a9a; margin:0 auto; border-radius:0 0 3px 3px; }
.vt-computer__base  { width:30px; height:4px; background:#4a6a8a; margin:0 auto; border-radius:2px; }

/* Vet nurse figure */
.vt-nurse { position:absolute; bottom:60px; left:50%; transform:translateX(-20px); }
.vt-nurse__head { width:22px; height:22px; border-radius:50%; background:radial-gradient(circle at 40% 35%,#d4b896,#c19a6b); margin:0 auto 0; position:relative; }
.vt-nurse__head::before { content:''; position:absolute; top:-6px; left:2px; right:2px; height:10px; background:var(--vt-teal); border-radius:50% 50% 0 0; } /* nurse cap */
.vt-nurse__neck { width:8px; height:6px; background:#c19a6b; margin:0 auto; }
.vt-nurse__body { width:28px; height:36px; background:linear-gradient(180deg,#fff,#f0f0f0); border-radius:4px 4px 0 0; margin:0 auto; position:relative; }
.vt-nurse__body::before { content:'✚'; position:absolute; top:6px; left:50%; transform:translateX(-50%); font-size:.7rem; color:var(--vt-teal); }

/* Paw logo above clinic */
.vt-paw-sign {
  position:absolute; top:-64px; left:50%; transform:translateX(-50%);
  width:48px; height:48px; background:var(--vt-amber); border-radius:50%;
  display:flex; align-items:center; justify-content:center; font-size:1.6rem;
  box-shadow:0 4px 16px rgba(232,164,53,.5);
  animation:vt-sign-glow 3s ease-in-out infinite alternate;
}
@keyframes vt-sign-glow {
  from { box-shadow:0 4px 16px rgba(232,164,53,.4); }
  to   { box-shadow:0 4px 32px rgba(232,164,53,.7); }
}

/* ── Hero content ─────────────────────────────────────────── */
.vt-hero__badge { display:inline-flex; align-items:center; gap:8px; background:rgba(13,157,168,.15); border:1px solid rgba(13,157,168,.3); color:var(--vt-teal-d); padding:6px 18px; border-radius:20px; font-size:.75rem; font-weight:800; letter-spacing:.1em; text-transform:uppercase; margin-bottom:24px; }
.vt-hero__title { font-family:var(--vt-font-head); font-size:clamp(2rem,5vw,3.4rem); line-height:1.15; font-weight:800; color:var(--vt-slate); margin-bottom:20px; }
.vt-hero__sub { font-size:1.1rem; color:var(--vt-slate); opacity:.75; margin-bottom:36px; line-height:1.7; }
.vt-hero__ctas { display:flex; gap:16px; flex-wrap:wrap; margin-bottom:40px; }
.vt-hero__trust { display:flex; gap:28px; flex-wrap:wrap; }
.vt-hero__trust-item { display:flex; align-items:center; gap:8px; color:var(--vt-slate); font-size:.85rem; opacity:.8; }

/* ═══════════════════════════════════════════════════════════
   TRUST BAR
   ═══════════════════════════════════════════════════════════ */
.vt-trust-bar { background:var(--vt-slate); padding:20px 0; }
.vt-trust-bar__inner { display:flex; justify-content:space-around; flex-wrap:wrap; gap:20px; }
.vt-trust-bar__item { display:flex; align-items:center; gap:10px; color:rgba(255,255,255,.85); font-size:.9rem; }
.vt-trust-bar__item span:first-child { font-size:1.3rem; }
.vt-trust-bar__item strong { color:#fff; }

/* ═══════════════════════════════════════════════════════════
   SERVICES
   ═══════════════════════════════════════════════════════════ */
.vt-services { text-align:center; }
.vt-services__intro { max-width:640px; margin:0 auto 56px; }
.vt-services__grid { display:grid; grid-template-columns:repeat(4,1fr); gap:20px; }
.vt-svc {
  background:#fff; border-radius:var(--vt-radius); padding:28px 18px; text-align:center;
  box-shadow:var(--vt-shadow); border:1px solid rgba(13,157,168,.08);
  transition:transform .25s,box-shadow .25s,border-color .25s;
}
.vt-svc:hover { transform:translateY(-6px); box-shadow:0 14px 40px rgba(13,157,168,.16); border-color:rgba(13,157,168,.25); }
.vt-svc__icon { font-size:2.2rem; margin-bottom:14px; }
.vt-svc__title { font-family:var(--vt-font-head); font-size:.95rem; font-weight:800; margin-bottom:8px; color:var(--vt-teal-d); }
.vt-svc__desc  { font-size:.85rem; line-height:1.65; color:#555; }

/* ═══════════════════════════════════════════════════════════
   CONDITIONS
   ═══════════════════════════════════════════════════════════ */
.vt-conditions { text-align:center; }
.vt-conditions__intro { max-width:600px; margin:0 auto 48px; }
.vt-conditions__cloud { display:flex; flex-wrap:wrap; justify-content:center; gap:10px; }
.vt-cond-tag {
  display:inline-block; padding:8px 18px; border-radius:24px;
  background:rgba(76,175,122,.1); color:var(--vt-grass-d); font-size:.85rem; font-weight:600;
  border:1px solid rgba(76,175,122,.2); cursor:default;
  transition:background .2s,color .2s;
}
.vt-cond-tag:hover { background:var(--vt-grass); color:#fff; border-color:var(--vt-grass); }

/* ═══════════════════════════════════════════════════════════
   ABOUT / TEAM
   ═══════════════════════════════════════════════════════════ */
.vt-about { }
.vt-about__grid { display:grid; grid-template-columns:1fr 1fr; gap:80px; align-items:center; }
.vt-about__visual { display:flex; flex-direction:column; gap:16px; align-items:center; }

/* Vet ID badge card */
.vt-vet-card {
  width:300px; background:#fff; border-radius:16px; overflow:hidden;
  box-shadow:0 12px 48px rgba(0,0,0,.12); border:2px solid rgba(13,157,168,.2);
}
.vt-vet-card__header {
  background:linear-gradient(135deg,var(--vt-teal),var(--vt-teal-d));
  padding:28px 20px 20px; text-align:center;
}
/* CSS vet figure */
.vt-vet-fig { display:flex; flex-direction:column; align-items:center; margin-bottom:10px; }
.vt-vet-fig__head { width:56px; height:56px; border-radius:50%; background:radial-gradient(circle at 40% 35%,#d4b896,#c19a6b); border:3px solid rgba(255,255,255,.5); position:relative; }
.vt-vet-fig__head::before { content:''; position:absolute; top:-8px; left:6px; right:6px; height:12px; background:#5a3a1a; border-radius:50% 50% 0 0; }
.vt-vet-fig__body { width:70px; height:60px; background:linear-gradient(180deg,#fff,#f0f0f0); border-radius:6px 6px 0 0; margin-top:0; position:relative; }
.vt-vet-fig__body::before { content:'🐾'; position:absolute; top:10px; left:50%; transform:translateX(-50%); font-size:.8rem; }
.vt-vet-fig__body::after  { content:''; position:absolute; bottom:0; left:50%; transform:translateX(-50%); width:2px; height:30px; background:rgba(0,0,0,.1); }
.vt-vet-card__header h3 { color:#fff; font-family:var(--vt-font-head); font-weight:800; font-size:1rem; margin-bottom:2px; }
.vt-vet-card__header p  { color:rgba(255,255,255,.8); font-size:.78rem; }
.vt-vet-card__body { padding:16px 20px; }
.vt-vet-card__row { display:flex; justify-content:space-between; padding:7px 0; border-bottom:1px solid rgba(0,0,0,.05); font-size:.82rem; }
.vt-vet-card__row:last-child { border-bottom:none; }
.vt-vet-card__row span:first-child { color:#777; }
.vt-vet-card__row span:last-child  { color:var(--vt-teal-d); font-weight:700; }

/* Awards beneath card */
.vt-awards { display:flex; gap:12px; flex-wrap:wrap; justify-content:center; }
.vt-award { background:var(--vt-bg); border:1px solid rgba(13,157,168,.2); border-radius:10px; padding:8px 14px; font-size:.75rem; font-weight:700; color:var(--vt-teal-d); text-align:center; }

.vt-about__text p { color:#444; margin-bottom:16px; line-height:1.8; }
.vt-about__text .vt-h2 { color:var(--vt-slate); }
.vt-about__feats { list-style:none; margin:20px 0 32px; display:flex; flex-direction:column; gap:10px; }
.vt-about__feats li { display:flex; align-items:center; gap:10px; font-size:.9rem; color:#333; }
.vt-about__feats li::before { content:'🐾'; flex-shrink:0; }

/* ═══════════════════════════════════════════════════════════
   APPROACH
   ═══════════════════════════════════════════════════════════ */
.vt-approach { background:var(--vt-slate); }
.vt-approach__intro { text-align:center; max-width:640px; margin:0 auto 56px; }
.vt-approach__grid {
  display:grid; grid-template-columns:repeat(5,1fr); gap:0;
  position:relative;
}
.vt-approach__grid::before {
  content:''; position:absolute; top:40px; left:10%; right:10%; height:2px;
  background:linear-gradient(90deg,var(--vt-teal),var(--vt-amber),var(--vt-grass));
  z-index:0;
}
.vt-step { text-align:center; padding:0 12px; position:relative; z-index:1; }
.vt-step__num { width:44px; height:44px; border-radius:50%; background:linear-gradient(135deg,var(--vt-teal),var(--vt-teal-d)); color:#fff; font-family:var(--vt-font-head); font-size:.75rem; font-weight:800; display:inline-flex; align-items:center; justify-content:center; margin-bottom:18px; box-shadow:0 0 18px rgba(13,157,168,.4); }
.vt-step__title { font-family:var(--vt-font-head); font-size:.9rem; font-weight:800; color:#fff; margin-bottom:8px; }
.vt-step__desc  { font-size:.82rem; color:rgba(255,255,255,.7); line-height:1.6; }

/* ═══════════════════════════════════════════════════════════
   GALLERY
   ═══════════════════════════════════════════════════════════ */
.vt-gallery__grid {
  display:grid; grid-template-columns:repeat(3,1fr);
  grid-template-rows:220px 220px; gap:12px;
}
.vt-gallery__item { border-radius:var(--vt-radius); overflow:hidden; position:relative; cursor:pointer; }
.vt-gallery__item:nth-child(1) { grid-column:span 2; }
.vt-gallery__item:nth-child(4) { grid-column:span 2; }
.vt-gallery__panel { width:100%; height:100%; display:flex; align-items:center; justify-content:center; font-size:3rem; transition:transform .4s; }
.vt-gallery__item:hover .vt-gallery__panel { transform:scale(1.04); }
.vt-gallery__overlay { position:absolute; inset:0; display:flex; align-items:flex-end; background:linear-gradient(to top,rgba(0,0,0,.65) 0%,transparent 50%); padding:20px; opacity:0; transition:opacity .3s; }
.vt-gallery__item:hover .vt-gallery__overlay { opacity:1; }
.vt-gallery__overlay span { color:#fff; font-size:.9rem; font-weight:700; }

/* ═══════════════════════════════════════════════════════════
   COUNTERS
   ═══════════════════════════════════════════════════════════ */
.vt-counters { background:linear-gradient(135deg,var(--vt-teal-d),var(--vt-teal)); text-align:center; }
.vt-counters__grid { display:grid; grid-template-columns:repeat(4,1fr); gap:40px; }
.vt-counter__val { font-family:var(--vt-font-head); font-size:clamp(2rem,4vw,3.2rem); font-weight:800; color:#fff; display:block; line-height:1; }
.vt-counter__label { font-size:.85rem; color:rgba(255,255,255,.8); margin-top:8px; }

/* ═══════════════════════════════════════════════════════════
   PACKAGES
   ═══════════════════════════════════════════════════════════ */
.vt-packages { text-align:center; background:var(--vt-bg); }
.vt-packages__intro { max-width:600px; margin:0 auto 56px; }
.vt-packages__grid { display:grid; grid-template-columns:repeat(3,1fr); gap:24px; align-items:start; }
.vt-pkg {
  border-radius:var(--vt-radius); padding:36px 28px; text-align:center;
  background:#fff; box-shadow:var(--vt-shadow); border:2px solid transparent;
  transition:transform .25s,box-shadow .25s;
}
.vt-pkg:hover { transform:translateY(-6px); box-shadow:0 16px 48px rgba(13,157,168,.16); }
.vt-pkg--featured { border-color:var(--vt-teal); box-shadow:0 8px 40px rgba(13,157,168,.25); background:var(--vt-slate); color:rgba(255,255,255,.9); transform:translateY(-8px); }
.vt-pkg--featured:hover { transform:translateY(-14px); }
.vt-pkg__badge { display:inline-block; background:var(--vt-amber); color:#fff; font-size:.7rem; font-weight:800; letter-spacing:.1em; text-transform:uppercase; padding:3px 12px; border-radius:12px; margin-bottom:12px; }
.vt-pkg__icon { font-size:2rem; margin-bottom:10px; display:block; }
.vt-pkg__name { font-family:var(--vt-font-head); font-size:1.05rem; font-weight:800; margin-bottom:4px; }
.vt-pkg--featured .vt-pkg__name { color:#fff; }
.vt-pkg__price { font-size:2.2rem; font-weight:800; margin:14px 0 4px; font-family:var(--vt-font-head); }
.vt-pkg--featured .vt-pkg__price { color:var(--vt-amber); }
.vt-pkg__per { font-size:.8rem; opacity:.65; margin-bottom:24px; }
.vt-pkg__features { list-style:none; text-align:left; margin-bottom:28px; display:flex; flex-direction:column; gap:10px; }
.vt-pkg__features li { display:flex; align-items:center; gap:8px; font-size:.88rem; }
.vt-pkg__features li::before { content:'🐾'; flex-shrink:0; font-size:.7rem; }
.vt-pkg--featured .vt-pkg__features li { color:rgba(255,255,255,.85); }
.vt-pkg .vt-btn { width:100%; text-align:center; }

/* ═══════════════════════════════════════════════════════════
   TESTIMONIALS
   ═══════════════════════════════════════════════════════════ */
.vt-testimonials { text-align:center; }
.vt-testimonials__intro { max-width:600px; margin:0 auto 56px; }
.vt-testimonials__grid { display:grid; grid-template-columns:repeat(3,1fr); gap:24px; }
.vt-testi {
  background:#fff; border-radius:var(--vt-radius); padding:28px 24px;
  box-shadow:var(--vt-shadow); border-top:4px solid var(--vt-teal);
  text-align:left; position:relative;
}
.vt-testi__pet { position:absolute; top:16px; right:16px; font-size:1.4rem; }
.vt-testi__stars { color:#f5a623; margin-bottom:14px; font-size:.95rem; }
.vt-testi__text { font-size:.9rem; line-height:1.75; color:#444; margin-bottom:18px; font-style:italic; }
.vt-testi__name { font-weight:700; color:var(--vt-teal-d); font-size:.9rem; font-family:var(--vt-font-head); }
.vt-testi__role { font-size:.8rem; color:#888; }

/* ═══════════════════════════════════════════════════════════
   BOOKING FORM
   ═══════════════════════════════════════════════════════════ */
.vt-booking { background:var(--vt-slate); }
.vt-booking__inner { display:grid; grid-template-columns:1fr 1fr; gap:80px; align-items:start; }
.vt-booking__info h2 { color:#fff; margin-bottom:16px; }
.vt-booking__info p  { color:rgba(255,255,255,.75); margin-bottom:28px; line-height:1.8; }
.vt-booking__list { list-style:none; display:flex; flex-direction:column; gap:12px; }
.vt-booking__list li { display:flex; align-items:center; gap:10px; color:rgba(255,255,255,.8); font-size:.9rem; }
.vt-booking__list li span:first-child { width:30px; height:30px; background:rgba(13,157,168,.2); border:1px solid rgba(13,157,168,.4); border-radius:50%; display:inline-flex; align-items:center; justify-content:center; flex-shrink:0; }
.vt-form { background:rgba(255,255,255,.05); border:1px solid rgba(255,255,255,.1); border-radius:16px; padding:36px; }
.vt-form__row { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
.vt-form__group { margin-bottom:14px; }
.vt-form__group label { display:block; font-size:.82rem; font-weight:700; color:rgba(255,255,255,.75); margin-bottom:6px; letter-spacing:.04em; }
.vt-form__group input,
.vt-form__group select,
.vt-form__group textarea {
  width:100%; padding:11px 14px; border-radius:8px;
  border:1px solid rgba(255,255,255,.12); background:rgba(255,255,255,.06);
  color:#fff; font-family:var(--vt-font-body); font-size:.9rem;
  transition:border-color .2s;
}
.vt-form__group input::placeholder,
.vt-form__group textarea::placeholder { color:rgba(255,255,255,.3); }
.vt-form__group input:focus,
.vt-form__group select:focus,
.vt-form__group textarea:focus { outline:none; border-color:var(--vt-teal); }
.vt-form__group select option { background:#2C3A4A; }
.vt-form__group textarea { resize:vertical; min-height:90px; }
.vt-form__submit { width:100%; padding:15px; background:linear-gradient(135deg,var(--vt-amber),var(--vt-amber-d)); color:#fff; font-family:var(--vt-font-head); font-size:1rem; font-weight:800; letter-spacing:.04em; border:none; border-radius:10px; cursor:pointer; transition:transform .2s,box-shadow .2s; margin-top:6px; }
.vt-form__submit:hover { transform:translateY(-2px); box-shadow:0 8px 24px rgba(232,164,53,.45); }

/* ═══════════════════════════════════════════════════════════
   FOOTER
   ═══════════════════════════════════════════════════════════ */
.vt-footer { background:var(--vt-slate-lt); padding:28px 0; text-align:center; }
.vt-footer p { color:rgba(255,255,255,.55); font-size:.85rem; }

/* ═══════════════════════════════════════════════════════════
   RESPONSIVE
   ═══════════════════════════════════════════════════════════ */
@media(max-width:1024px){
  .vt-hero__inner { grid-template-columns:1fr; gap:40px; padding:100px 0 60px; }
  .vt-scene { height:360px; }
  .vt-services__grid { grid-template-columns:repeat(2,1fr); }
  .vt-about__grid { grid-template-columns:1fr; }
  .vt-approach__grid { grid-template-columns:repeat(3,1fr); }
  .vt-approach__grid::before { display:none; }
  .vt-counters__grid { grid-template-columns:repeat(2,1fr); }
  .vt-packages__grid { grid-template-columns:1fr; }
  .vt-testimonials__grid { grid-template-columns:1fr; }
  .vt-booking__inner { grid-template-columns:1fr; }
}
@media(max-width:640px){
  .vt-section { padding:64px 0; }
  .vt-services__grid { grid-template-columns:1fr; }
  .vt-approach__grid { grid-template-columns:1fr 1fr; }
  .vt-gallery__grid { grid-template-columns:1fr 1fr; grid-template-rows:auto; }
  .vt-gallery__item:nth-child(1),
  .vt-gallery__item:nth-child(4) { grid-column:span 1; }
  .vt-counters__grid { grid-template-columns:1fr 1fr; }
  .vt-form__row { grid-template-columns:1fr; }
  .vt-hero__ctas { flex-direction:column; }
}
</style>
<?php get_header(); ?>
<div class="vt-page">
>
<?php wp_body_open(); ?>
<div class="vt-wrap">

<!-- ═══════════════ HERO ═══════════════ -->
<section class="vt-hero" aria-label="Veterinary clinic hero">

  <!-- Floating paw particles -->
  <?php foreach ($particles as $p): ?>
  <div class="vt-particle" aria-hidden="true" style="
    top:<?= $p['top'] ?>%; left:<?= $p['left'] ?>%;
    font-size:<?= $p['size'] ?>px; color:<?= esc_attr($p['col']) ?>;
    --dur:<?= $p['dur'] ?>s; --del:<?= $p['del'] ?>s;
  "><?= esc_html($p['sym']) ?></div>
  <?php endforeach; ?>

  <div class="vt-container">
    <div class="vt-hero__inner">

      <!-- Content -->
      <div class="vt-hero__content">
        <div class="vt-hero__badge"><span>🐾</span> RCVS Accredited Practice</div>
        <h1 class="vt-hero__title">Expert Veterinary<br>Care for Every Pet.</h1>
        <p class="vt-hero__sub">
          Compassionate, cutting-edge veterinary medicine for dogs, cats, rabbits, birds and exotic pets. Serving our community with round-the-clock emergency care since 1992.
        </p>
        <div class="vt-hero__ctas">
          <a href="#booking" class="vt-btn vt-btn--primary">Book an Appointment</a>
          <a href="tel:01234567890" class="vt-btn vt-btn--teal">📞 24/7 Emergency Line</a>
        </div>
        <div class="vt-hero__trust">
          <div class="vt-hero__trust-item"><span>🏅</span><span>RCVS Accredited</span></div>
          <div class="vt-hero__trust-item"><span>🚑</span><span>24/7 Emergencies</span></div>
          <div class="vt-hero__trust-item"><span>💊</span><span>In-House Lab</span></div>
        </div>
      </div>

      <!-- Scene -->
      <div class="vt-hero__scene" aria-hidden="true">
        <div class="vt-scene">

          <!-- Paw logo sign -->
          <div class="vt-paw-sign">🐾</div>

          <!-- Clinic building -->
          <div class="vt-clinic">
            <div class="vt-clinic__roof"></div>

            <!-- Aquarium window -->
            <div class="vt-aquarium">
              <?php foreach ($fish as $f): ?>
              <div class="vt-fish" style="
                top:<?= $f['top'] ?>%;
                color:<?= esc_attr($f['col']) ?>;
                font-size:<?= $f['size'] ?>px;
                --fd:<?= $f['dur'] ?>s;
                --fd2:-<?= $f['del'] ?>s;
              "><?= $f['dir'] ? '🐟' : '🐠' ?></div>
              <?php endforeach; ?>
            </div>

            <!-- Waiting chairs -->
            <?php foreach ($chairs as $i => $ch): ?>
            <div class="vt-chair" style="left:<?= $ch['left'] ?>%;" aria-hidden="true">
              <div class="vt-chair__back" style="background:<?= esc_attr($ch['col']) ?>;border-radius:4px;position:absolute;top:-22px;left:2px;right:2px;height:20px;"></div>
              <div class="vt-chair__seat" style="background:<?= esc_attr($ch['col']) ?>;"></div>
              <div class="vt-chair__legs">
                <div class="vt-chair__leg"></div>
                <div class="vt-chair__leg"></div>
              </div>
            </div>
            <!-- Pets waiting -->
            <div class="vt-pet-on-chair" style="left:<?= $ch['left'] + 1 ?>%;" aria-hidden="true">
              <?= ['🐕','🐈','🐇','🦜'][$i] ?>
            </div>
            <?php endforeach; ?>

            <!-- Reception desk -->
            <div class="vt-desk">
              <div class="vt-computer">
                <div class="vt-computer__screen">💻</div>
                <div class="vt-computer__stand"></div>
                <div class="vt-computer__base"></div>
              </div>
            </div>

            <!-- Nurse -->
            <div class="vt-nurse" aria-hidden="true">
              <div class="vt-nurse__head"></div>
              <div class="vt-nurse__neck"></div>
              <div class="vt-nurse__body"></div>
            </div>

          </div><!-- /.vt-clinic -->

        </div>
      </div>

    </div>
  </div>
</section>

<!-- ═══════════════ TRUST BAR ═══════════════ -->
<div class="vt-trust-bar">
  <div class="vt-container">
    <div class="vt-trust-bar__inner">
      <div class="vt-trust-bar__item"><span>⚕️</span><span><strong>RCVS</strong> Accredited Practice of Excellence</span></div>
      <div class="vt-trust-bar__item"><span>🏆</span><span>Winner — <strong>Best Veterinary Practice</strong> 2024</span></div>
      <div class="vt-trust-bar__item"><span>🏥</span><span>Veterinary <strong>Specialist</strong> Centre</span></div>
      <div class="vt-trust-bar__item"><span>🐾</span><span>Caring for Pets <strong>Since 1992</strong></span></div>
    </div>
  </div>
</div>

<!-- ═══════════════ SERVICES ═══════════════ -->
<section class="vt-section vt-services" id="services" aria-labelledby="vt-svc-heading">
  <div class="vt-container">
    <div class="vt-services__intro">
      <span class="vt-tag">Our Expertise</span>
      <h2 class="vt-h2" id="vt-svc-heading">Comprehensive Veterinary Services</h2>
      <p class="vt-lead">From routine wellness checks to complex specialist surgery — all under one roof, with warmth and expertise.</p>
    </div>
    <div class="vt-services__grid">
      <?php foreach ($services as $svc): ?>
      <article class="vt-svc" role="listitem">
        <div class="vt-svc__icon" aria-hidden="true"><?= $svc['icon'] ?></div>
        <h3 class="vt-svc__title"><?= esc_html($svc['title']) ?></h3>
        <p class="vt-svc__desc"><?= esc_html($svc['desc']) ?></p>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ CONDITIONS ═══════════════ -->
<section class="vt-section vt-section--bg vt-conditions" aria-labelledby="vt-cond-heading">
  <div class="vt-container">
    <div class="vt-conditions__intro">
      <span class="vt-tag">What We Treat</span>
      <h2 class="vt-h2" id="vt-cond-heading">Conditions We Treat Every Day</h2>
      <p class="vt-lead" style="margin:0 auto;">From the routine to the complex — our clinical team is equipped to diagnose and treat a full spectrum of conditions.</p>
    </div>
    <div class="vt-conditions__cloud" role="list">
      <?php foreach ($conditions as $cond): ?>
      <span class="vt-cond-tag" role="listitem"><?= esc_html($cond) ?></span>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ ABOUT ═══════════════ -->
<section class="vt-section vt-about" id="about" aria-labelledby="vt-about-heading">
  <div class="vt-container">
    <div class="vt-about__grid">
      <div class="vt-about__visual">
        <div class="vt-vet-card" role="img" aria-label="Veterinarian credential card for Dr. Olivia Chen">
          <div class="vt-vet-card__header">
            <div class="vt-vet-fig" aria-hidden="true">
              <div class="vt-vet-fig__head"></div>
              <div class="vt-vet-fig__body"></div>
            </div>
            <h3>Dr. Olivia Chen BVSc MRCVS</h3>
            <p>Clinical Director &amp; Specialist Surgeon</p>
          </div>
          <div class="vt-vet-card__body">
            <div class="vt-vet-card__row"><span>Qualification</span><span>BVSc — Royal Vet College</span></div>
            <div class="vt-vet-card__row"><span>Registration</span><span>MRCVS</span></div>
            <div class="vt-vet-card__row"><span>Specialism</span><span>Surgery &amp; Oncology</span></div>
            <div class="vt-vet-card__row"><span>Certificate</span><span>RCVS CertVA</span></div>
            <div class="vt-vet-card__row"><span>Experience</span><span>18 Years</span></div>
          </div>
        </div>
        <div class="vt-awards">
          <div class="vt-award">🏆 Best Practice 2024</div>
          <div class="vt-award">⭐ Cat Friendly Silver</div>
          <div class="vt-award">🐾 RCVS Accredited</div>
        </div>
      </div>

      <div class="vt-about__text">
        <span class="vt-tag">Meet the Team</span>
        <h2 class="vt-h2" id="vt-about-heading">Passionate About Animal Welfare</h2>
        <p>Greenfield Veterinary Clinic was founded in 1992 with a simple belief: every pet deserves the same standard of care as a person. More than three decades later, our team of 14 vets and 22 nurses continues to put that principle at the heart of everything we do.</p>
        <p>We invest heavily in the latest diagnostic technology — including a new 3T MRI suite, digital radiography and a fully equipped in-house laboratory — so your pet receives a rapid, accurate diagnosis and the most appropriate treatment with minimal delay.</p>
        <ul class="vt-about__feats" aria-label="Practice highlights">
          <li>14 vets including 4 RCVS-recognised specialists</li>
          <li>24-hour emergency and intensive care unit</li>
          <li>State-of-the-art in-house MRI, CT and digital X-ray</li>
          <li>Purpose-built feline and rabbit waiting areas</li>
          <li>Pet Health Plan — straightforward monthly payment</li>
          <li>End-of-life and bereavement support service</li>
        </ul>
        <a href="#booking" class="vt-btn vt-btn--primary">Register Your Pet Today</a>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════ APPROACH ═══════════════ -->
<section class="vt-section vt-approach" aria-labelledby="vt-approach-heading">
  <div class="vt-container">
    <div class="vt-approach__intro">
      <span class="vt-tag vt-tag--light">How We Work</span>
      <h2 class="vt-h2" id="vt-approach-heading" style="color:#fff;">Your Pet's Journey With Us</h2>
      <p class="vt-lead" style="color:rgba(255,255,255,.7);margin:0 auto;">A seamless, stress-free experience from first contact to follow-up care — designed around your pet's wellbeing.</p>
    </div>
    <div class="vt-approach__grid" role="list">
      <?php foreach ($steps as $step): ?>
      <div class="vt-step" role="listitem">
        <div class="vt-step__num" aria-hidden="true"><?= esc_html($step['num']) ?></div>
        <h3 class="vt-step__title"><?= esc_html($step['title']) ?></h3>
        <p class="vt-step__desc"><?= esc_html($step['desc']) ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ GALLERY ═══════════════ -->
<section class="vt-section" aria-labelledby="vt-gallery-heading">
  <div class="vt-container">
    <div style="text-align:center;margin-bottom:48px;">
      <span class="vt-tag">Our Facilities</span>
      <h2 class="vt-h2" id="vt-gallery-heading">Purpose-Built for Pets</h2>
    </div>
    <div class="vt-gallery__grid" role="list">
      <?php foreach ($gallery as $panel): ?>
      <div class="vt-gallery__item" role="listitem">
        <div class="vt-gallery__panel" style="background:<?= esc_attr($panel['color']) ?>;" aria-label="<?= esc_attr($panel['label']) ?>">
          <span aria-hidden="true" style="font-size:3.5rem;"><?= $panel['icon'] ?></span>
        </div>
        <div class="vt-gallery__overlay" aria-hidden="true">
          <span><?= esc_html($panel['label']) ?></span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ COUNTERS ═══════════════ -->
<section class="vt-section vt-counters" aria-labelledby="vt-counters-heading">
  <div class="vt-container">
    <h2 class="sr-only" id="vt-counters-heading">Practice statistics</h2>
    <div class="vt-counters__grid">
      <?php foreach ($counters as $c): ?>
      <div>
        <span class="vt-counter__val"
              data-target="<?= esc_attr($c['val']) ?>"
              data-suffix="<?= esc_attr($c['suffix']) ?>"
              <?= $c['float'] ? 'data-float="1"' : '' ?>
              aria-label="<?= esc_attr($c['val'] . $c['suffix'] . ' — ' . $c['label']) ?>">0</span>
        <p class="vt-counter__label"><?= esc_html($c['label']) ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ PACKAGES ═══════════════ -->
<section class="vt-section vt-packages" id="plans" aria-labelledby="vt-pkg-heading">
  <div class="vt-container">
    <div class="vt-packages__intro">
      <span class="vt-tag">Health Plans</span>
      <h2 class="vt-h2" id="vt-pkg-heading">Protect Your Pet, Budget Monthly</h2>
      <p class="vt-lead" style="margin:0 auto;">Our pet health plans spread the cost of essential preventive care so you can focus on your pet, not the bill.</p>
    </div>
    <div class="vt-packages__grid">
      <?php foreach ($packages as $pkg): ?>
      <div class="vt-pkg <?= $pkg['featured'] ? 'vt-pkg--featured' : '' ?>">
        <?php if ($pkg['featured']): ?><div class="vt-pkg__badge">Best Value</div><?php endif; ?>
        <h3 class="vt-pkg__name"><?= esc_html($pkg['name']) ?></h3>
        <div class="vt-pkg__price"><?= esc_html($pkg['price']) ?></div>
        <div class="vt-pkg__per"><?= esc_html($pkg['per']) ?></div>
        <ul class="vt-pkg__features" aria-label="<?= esc_attr($pkg['name']) ?> features">
          <?php foreach ($pkg['features'] as $f): ?>
          <li><?= esc_html($f) ?></li>
          <?php endforeach; ?>
        </ul>
        <a href="#booking" class="vt-btn <?= $pkg['featured'] ? 'vt-btn--primary' : 'vt-btn--teal' ?>">
          Join Plan
        </a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ TESTIMONIALS ═══════════════ -->
<section class="vt-section vt-testimonials" aria-labelledby="vt-testi-heading">
  <div class="vt-container">
    <div class="vt-testimonials__intro">
      <span class="vt-tag">Happy Patients</span>
      <h2 class="vt-h2" id="vt-testi-heading">What Pet Owners Say</h2>
      <p class="vt-lead" style="margin:0 auto;">The trust of our clients and patients is everything. Here are just a few of the thousands of kind words we receive every year.</p>
    </div>
    <div class="vt-testimonials__grid">
      <?php foreach ($testimonials as $t): ?>
      <blockquote class="vt-testi">
        <div class="vt-testi__pet" aria-hidden="true"><?= ['🐕','🐈','🐇'][$t === $testimonials[0] ? 0 : ($t === $testimonials[1] ? 1 : 2)] ?></div>
        <div class="vt-testi__stars" aria-label="<?= esc_attr($t['rating']) ?> stars"><?= str_repeat('★',$t['rating']) ?></div>
        <p class="vt-testi__text"><?= esc_html($t['text']) ?></p>
        <footer>
          <div class="vt-testi__name"><?= esc_html($t['name']) ?></div>
          <div class="vt-testi__role"><?= esc_html($t['role']) ?></div>
        </footer>
      </blockquote>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ BOOKING ═══════════════ -->
<section class="vt-section vt-booking" id="booking" aria-labelledby="vt-booking-heading">
  <div class="vt-container">
    <div class="vt-booking__inner">
      <div class="vt-booking__info">
        <span class="vt-tag vt-tag--light">Book an Appointment</span>
        <h2 class="vt-h2" id="vt-booking-heading">Register Your Pet Today</h2>
        <p>New patients are always welcome at Greenfield. Register online and we will confirm your first appointment within two hours during clinic hours. Emergency? Call our 24-hour line immediately.</p>
        <ul class="vt-booking__list" aria-label="Booking benefits">
          <li><span>📅</span><span>Same-day and next-day appointments available</span></li>
          <li><span>💻</span><span>Video consultations for follow-up and advice</span></li>
          <li><span>🚑</span><span>24/7 emergency line — always a vet on call</span></li>
          <li><span>🏥</span><span>In-house lab results often within the hour</span></li>
          <li><span>🐾</span><span>Separate dog and cat waiting areas</span></li>
        </ul>
      </div>
      <div class="vt-form">
        <?php
          if (!empty($_POST['tf_vt_nonce']) && wp_verify_nonce($_POST['tf_vt_nonce'],'tf_vt_booking')) {
            echo '<p style="color:var(--vt-teal);font-weight:700;margin-bottom:16px;">🐾 Appointment request received — we will confirm shortly!</p>';
          }
        ?>
        <form method="post" action="<?php echo esc_url(get_permalink()); ?>#booking" novalidate>
          <?php wp_nonce_field('tf_vt_booking','tf_vt_nonce'); ?>
          <div class="vt-form__row">
            <div class="vt-form__group">
              <label for="vt_name">Your Name <span style="color:var(--vt-amber)">*</span></label>
              <input type="text" id="vt_name" name="vt_name" placeholder="Full name" required autocomplete="name">
            </div>
            <div class="vt-form__group">
              <label for="vt_email">Email <span style="color:var(--vt-amber)">*</span></label>
              <input type="email" id="vt_email" name="vt_email" placeholder="you@example.com" required autocomplete="email">
            </div>
          </div>
          <div class="vt-form__row">
            <div class="vt-form__group">
              <label for="vt_phone">Phone</label>
              <input type="tel" id="vt_phone" name="vt_phone" placeholder="+44 7700 900000" autocomplete="tel">
            </div>
            <div class="vt-form__group">
              <label for="vt_pet_name">Pet's Name <span style="color:var(--vt-amber)">*</span></label>
              <input type="text" id="vt_pet_name" name="vt_pet_name" placeholder="e.g. Charlie" required>
            </div>
          </div>
          <div class="vt-form__row">
            <div class="vt-form__group">
              <label for="vt_species">Species <span style="color:var(--vt-amber)">*</span></label>
              <select id="vt_species" name="vt_species" required>
                <option value="">Select species…</option>
                <option value="dog">Dog</option>
                <option value="cat">Cat</option>
                <option value="rabbit">Rabbit</option>
                <option value="bird">Bird</option>
                <option value="reptile">Reptile</option>
                <option value="small-mammal">Small Mammal</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div class="vt-form__group">
              <label for="vt_reason">Reason for Visit <span style="color:var(--vt-amber)">*</span></label>
              <select id="vt_reason" name="vt_reason" required>
                <option value="">Select reason…</option>
                <option value="annual-check">Annual Health Check</option>
                <option value="vaccination">Vaccination</option>
                <option value="illness">Illness / Concern</option>
                <option value="surgery">Surgery Enquiry</option>
                <option value="dental">Dental</option>
                <option value="new-patient">New Patient Registration</option>
                <option value="emergency">Emergency</option>
              </select>
            </div>
          </div>
          <div class="vt-form__group">
            <label for="vt_notes">Additional Notes</label>
            <textarea id="vt_notes" name="vt_notes" placeholder="Any symptoms, existing conditions or medications you would like us to know about…"></textarea>
          </div>
          <button type="submit" class="vt-form__submit">🐾 Request Appointment</button>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════ FOOTER ═══════════════ -->
<footer class="vt-footer">
  <div class="vt-container">
    <p>&copy; <?php echo esc_html(date('Y')); ?> <?php bloginfo('name'); ?> &mdash; Greenfield Veterinary Clinic. RCVS Accredited. All rights reserved.</p>
  </div>
</footer>

</div><!-- /.vt-wrap -->

<script>
(function(){
  'use strict';

  /* ── Animated counters ─────────────────────────────── */
  var easeOut = function(t){ return 1 - Math.pow(1 - t, 3); };
  var counters = document.querySelectorAll('.vt-counter__val[data-target]');

  if ('IntersectionObserver' in window) {
    var obs = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if (!entry.isIntersecting) return;
        obs.unobserve(entry.target);
        var el     = entry.target;
        var target = parseFloat(el.dataset.target);
        var suffix = el.dataset.suffix || '';
        var isFloat= el.dataset.float === '1';
        if (isNaN(target)) return;
        var duration = 1800, start = null;
        function tick(ts){
          if (!start) start = ts;
          var p = Math.min((ts - start) / duration, 1);
          var v = target * easeOut(p);
          el.textContent = (isFloat ? v.toFixed(1) : Math.floor(v)) + suffix;
          if (p < 1) requestAnimationFrame(tick);
          else el.textContent = (isFloat ? target.toFixed(1) : target) + suffix;
        }
        requestAnimationFrame(tick);
      });
    }, { threshold: 0.4 });
    counters.forEach(function(el){ obs.observe(el); });
  } else {
    counters.forEach(function(el){
      el.textContent = el.dataset.target + (el.dataset.suffix || '');
    });
  }

  /* ── Mouse parallax on particles ──────────────────── */
  var particles = document.querySelectorAll('.vt-particle');
  var hero = document.querySelector('.vt-hero');
  if (hero) {
    hero.addEventListener('mousemove', function(e){
      var rect = hero.getBoundingClientRect();
      var dx = (e.clientX - rect.left - rect.width / 2) / rect.width;
      var dy = (e.clientY - rect.top - rect.height / 2) / rect.height;
      particles.forEach(function(p, i){
        var depth = (i % 4 + 1) * 7;
        p.style.transform = 'translate(' + (dx * depth) + 'px, ' + (dy * depth) + 'px)';
      });
    });
  }

})();
</script>

</body>
</html>
</div><!-- .vt-page -->
<?php get_footer(); ?>
