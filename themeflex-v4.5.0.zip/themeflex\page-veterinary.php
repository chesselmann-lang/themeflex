<?php
/**
 * Template Name: Veterinary – Veterinary Practice & Animal Clinic
 *
 * Premium page template for a Veterinary Practice & Animal Clinic.
 * CSS art hero: countryside veterinary scene at dawn — rolling hills, clinic building,
 * CSS animal silhouettes, warm sunrise gradient.
 * Namespace: --vet-*
 * Fonts: Merriweather (headings) + Mulish (body)
 *
 * @package ThemeFlex
 */
/* ── Seeded randomness ───────────────────────────────────────────── */
srand( crc32( get_the_permalink() ) );

/* ── Business data ───────────────────────────────────────────────── */
$business = [
    'name'     => 'Meadowbrook Veterinary Practice',
    'tagline'  => 'Caring for Pets & Farm Animals Since 1992',
    'location' => 'Meadow Lane, Stratford-upon-Avon, Warwickshire CV37 8NJ',
    'phone'    => '01789 204 880',
    'email'    => 'hello@meadowbrookvet.co.uk',
    'emergency'=> '01789 204 881',
    'hours'    => 'Mon–Fri 8:30–18:30 · Sat 9:00–17:00 · Sun 10:00–14:00',
];

/* ── Stats ───────────────────────────────────────────────────────── */
$stats = [
    [ 'value' => 32,    'suffix' => '',   'label' => 'Years Est.' ],
    [ 'value' => 6200,  'suffix' => '+',  'label' => 'Registered Pets' ],
    [ 'value' => 4.9,   'suffix' => '★',  'label' => 'Client Rating' ],
    [ 'value' => 8,     'suffix' => '',   'label' => 'Vets on Team' ],
];

/* ── Services ────────────────────────────────────────────────────── */
$services = [
    [
        'icon'  => '🩺',
        'title' => 'Consultations & Check-ups',
        'desc'  => 'Comprehensive health examinations for pets of all sizes, with same-day appointments available for urgent cases.',
        'tag'   => 'Same-day available',
    ],
    [
        'icon'  => '💉',
        'title' => 'Vaccinations & Prevention',
        'desc'  => 'Full vaccination programmes for dogs, cats, rabbits and small animals, plus preventative parasite treatments.',
        'tag'   => 'Puppies & kittens welcome',
    ],
    [
        'icon'  => '🔬',
        'title' => 'In-House Diagnostics',
        'desc'  => 'On-site digital X-ray, ultrasound, laboratory blood testing and endoscopy — results within the same visit.',
        'tag'   => 'Results same day',
    ],
    [
        'icon'  => '🏥',
        'title' => 'Surgery & Anaesthesia',
        'desc'  => 'Routine and specialist surgical procedures carried out by our RCVS Certificate holders in our purpose-built theatre.',
        'tag'   => 'RCVS accredited',
    ],
    [
        'icon'  => '🦷',
        'title' => 'Dental Care',
        'desc'  => 'Full dental examination, scaling, polishing and extractions under general anaesthetic with digital dental X-ray.',
        'tag'   => 'Digital X-ray',
    ],
    [
        'icon'  => '🐄',
        'title' => 'Farm Animal Services',
        'desc'  => 'Large animal and farm visits across Warwickshire — cattle, sheep, pigs and equine care from our specialist farm vet.',
        'tag'   => 'Farm visits available',
    ],
];

/* ── PHP star/dawn particles ─────────────────────────────────────── */
$stars = [];
for($i=0;$i<30;$i++) {
    $stars[] = [
        'left' => rand(2,92),
        'top'  => rand(2,42),
        'size' => rand(1,3),
        'op'   => rand(3,8)/10,
        'dur'  => rand(25,60)/10,
        'del'  => rand(0,40)/10,
    ];
}

/* ── PHP birds in dawn sky ───────────────────────────────────────── */
$birds = [];
for($i=0;$i<8;$i++) {
    $birds[] = [
        'left'  => rand(5,80),
        'top'   => rand(12,36),
        'size'  => rand(8,16),
        'delay' => rand(0,50)/10,
        'dur'   => rand(80,160)/10,
    ];
}

/* ── PHP rolling hills (3 layers) ────────────────────────────────── */
$hill_colors = [
    ['bg'=>'#5a8840','top'=>'50%'],
    ['bg'=>'#7aaa60','top'=>'62%'],
    ['bg'=>'#9aca80','top'=>'72%'],
];

/* ── PHP flower meadow dots ──────────────────────────────────────── */
$flowers = [];
for($i=0;$i<24;$i++) {
    $flowers[] = [
        'left' => rand(0,100),
        'top'  => rand(70,95),
        'col'  => ['#f8d060','#f0a0b0','#e0c0f0','#80d080','#f8a060'][ rand(0,4) ],
        'size' => rand(4,9),
    ];
}

/* ── PHP fence posts ─────────────────────────────────────────────── */
$fence_posts = range(0, 14);

/* ── Species treated ─────────────────────────────────────────────── */
$species = [
    [ 'emoji' => '🐕', 'name' => 'Dogs' ],
    [ 'emoji' => '🐈', 'name' => 'Cats' ],
    [ 'emoji' => '🐇', 'name' => 'Rabbits' ],
    [ 'emoji' => '🐹', 'name' => 'Small Animals' ],
    [ 'emoji' => '🐦', 'name' => 'Birds & Exotics' ],
    [ 'emoji' => '🐠', 'name' => 'Reptiles' ],
    [ 'emoji' => '🐄', 'name' => 'Cattle' ],
    [ 'emoji' => '🐑', 'name' => 'Sheep & Goats' ],
    [ 'emoji' => '🐎', 'name' => 'Equine' ],
];

/* ── Team ────────────────────────────────────────────────────────── */
$team = [
    [
        'name'  => 'Dr Sarah Holbrook BVSc MRCVS',
        'role'  => 'Senior Partner & Clinical Director',
        'spec'  => 'Soft tissue surgery & oncology',
        'cert'  => 'RCVS Cert. Soft Tissue Surgery',
        'since' => 'Practice founder, 1992',
        'col'   => '#2a5a7a',
    ],
    [
        'name'  => 'Dr Marcus Obi BVetMed MRCVS',
        'role'  => 'Small Animal Veterinarian',
        'spec'  => 'Orthopaedics & emergency medicine',
        'cert'  => 'MRCVS',
        'since' => 'Joined 2016',
        'col'   => '#2a7a5a',
    ],
    [
        'name'  => 'Dr Fiona Harte MVB MRCVS',
        'role'  => 'Farm Animal Specialist',
        'spec'  => 'Bovine medicine & reproduction',
        'cert'  => 'RCVS Cert. Cattle Health & Production',
        'since' => 'Joined 2019',
        'col'   => '#5a5a2a',
    ],
];

/* ── Testimonials ────────────────────────────────────────────────── */
$testimonials = [
    [
        'name'  => 'Emma & Archie Sutton',
        'loc'   => 'Stratford-upon-Avon',
        'stars' => 5,
        'pet'   => 'Labrador, aged 9',
        'quote' => 'Dr Holbrook performed a complex knee surgery on our Lab — the aftercare and follow-up were exceptional. He\'s running around like a puppy again.',
    ],
    [
        'name'  => 'James Whitfield',
        'loc'   => 'Bidford-on-Avon',
        'stars' => 5,
        'pet'   => 'Mixed farm, 280 cattle',
        'quote' => 'Dr Harte has transformed how we manage our herd health. Her knowledge of bovine reproduction is second to none, and she\'s always available.',
    ],
    [
        'name'  => 'Priya Sandhu',
        'loc'   => 'Henley-in-Arden',
        'stars' => 5,
        'pet'   => 'Two cats & a rabbit',
        'quote' => 'The team genuinely care about the animals. We\'ve brought three pets here for years and always feel completely reassured after every visit.',
    ],
];

/* ── Pet healthcare plans ────────────────────────────────────────── */
$plans = [
    [
        'name'    => 'Puppy & Kitten Plan',
        'price'   => '£18',
        'period'  => '/month',
        'includes'=> ['Primary vaccination course', 'Microchipping', '3 health checks', '25% off neutering', 'Monthly flea & worm treatment'],
        'highlight'=> false,
    ],
    [
        'name'    => 'Adult Pet Plan',
        'price'   => '£22',
        'period'  => '/month',
        'includes'=> ['Annual booster vaccinations', 'Annual health MOT', 'Monthly flea & worm treatment', '10% off dental treatment', 'Free nurse consultations'],
        'highlight'=> true,
        'badge'   => 'Most Popular',
    ],
    [
        'name'    => 'Senior Wellness Plan',
        'price'   => '£28',
        'period'  => '/month',
        'includes'=> ['Bi-annual senior health screen', 'Annual booster vaccinations', 'Monthly preventative care', 'Priority appointments', '15% off all diagnostics'],
        'highlight'=> false,
    ],
];

/* ── FAQ ─────────────────────────────────────────────────────────── */
$faqs = [
    [
        'q' => 'Do you offer emergency out-of-hours care?',
        'a' => 'Yes — we provide 24/7 emergency cover for our registered clients. Our out-of-hours service is staffed by our own vets (not a third-party service) on a rotating basis. Call our emergency line on ' . $business['emergency'] . ' at any hour.',
    ],
    [
        'q' => 'How do I register my pet?',
        'a' => 'Registration is free and takes just a few minutes. You can register online, by phone, or in person at the practice. We\'ll need your details, your pet\'s details and your previous vet\'s information if applicable.',
    ],
    [
        'q' => 'Do you accept pet insurance?',
        'a' => 'Yes — we work with all major UK pet insurance providers. We can process claims directly with your insurer for treatment over £200. Please bring your policy details and claim form to your appointment.',
    ],
    [
        'q' => 'What should I do if my pet has swallowed something?',
        'a' => 'Call us immediately on our main number. Do not induce vomiting unless specifically advised by a vet — some substances are more dangerous when brought back up. Bring any packaging or information about the substance with you.',
    ],
    [
        'q' => 'Can I choose which vet I see?',
        'a' => 'Yes — we try to accommodate requests for specific vets wherever possible, particularly for ongoing cases or pets with anxiety. Please mention your preference when booking. Continuity of care is something we actively work to maintain.',
    ],
];

/* ── Appointment form ────────────────────────────────────────────── */
$appt_types = [
    'General consultation',
    'Vaccination appointment',
    'Post-operative check',
    'Dental assessment',
    'New patient registration',
    'Farm / large animal visit',
    'Nurse consultation',
    'Other / Not sure',
];
$species_opts = ['Dog','Cat','Rabbit','Guinea pig / Small animal','Bird','Reptile','Cattle / Sheep','Horse','Other'];
?>
?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,300;0,400;0,700;1,300;1,400&family=Mulish:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
/* ══════════════════════════════════════════════════════════════════
   VETERINARY TEMPLATE — CSS CUSTOM PROPERTIES
   ══════════════════════════════════════════════════════════════════ */
:root {
    --vet-teal:        #1a5c5a;
    --vet-teal-mid:    #2a7a78;
    --vet-teal-light:  #4a9a98;
    --vet-teal-pale:   #c8e8e8;
    --vet-green:       #3a6a38;
    --vet-green-light: #6aaa68;
    --vet-green-pale:  #d0e8d0;
    --vet-amber:       #d4894a;
    --vet-amber-light: #f0b070;
    --vet-cream:       #f8f6f0;
    --vet-warm-white:  #fefcf8;
    --vet-dawn-sky:    #fde8d0;
    --vet-slate:       #4a5a68;

    --vet-font-head: 'Merriweather', Georgia, serif;
    --vet-font-body: 'Mulish', 'Helvetica Neue', sans-serif;

    --vet-section: clamp(64px,8vw,120px);
    --vet-radius:  10px;
    --vet-shadow:  0 8px 40px rgba(26,92,90,0.12);
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body.vet-page {
    font-family: var(--vet-font-body);
    font-size: 17px;
    line-height: 1.7;
    color: #1e2a28;
    background: var(--vet-warm-white);
    overflow-x: hidden;
}

/* ── EMERGENCY BANNER ──────────────────────────────────────────── */
.vet-emergency-bar {
    background: #c0392b;
    padding: 10px 24px;
    text-align: center;
    font-size: 0.88rem;
    font-weight: 700;
    color: #fff;
    letter-spacing: 0.02em;
}
.vet-emergency-bar a {
    color: #ffd0c8;
    text-decoration: none;
    font-weight: 800;
    margin-left: 8px;
    border-bottom: 1px solid rgba(255,200,190,0.6);
}

/* ── HERO ──────────────────────────────────────────────────────── */
.vet-hero {
    position: relative;
    min-height: 100vh;
    overflow: hidden;
    display: flex;
    align-items: center;
}

/* Dawn sky gradient */
.vet-sky {
    position: absolute;
    inset: 0;
    background: linear-gradient(
        170deg,
        #1a2848 0%,
        #3a4a78 15%,
        #7060a8 28%,
        #c08080 42%,
        #e8b870 55%,
        #f8d890 65%,
        #e8f0d8 80%,
        #c8e8c0 100%
    );
}

/* Sun rising on horizon */
.vet-sun {
    position: absolute;
    bottom: 38%;
    left: 30%;
    width: 90px;
    height: 90px;
    border-radius: 50%;
    background: radial-gradient(circle, #fff8e0 0%, #fce060 40%, #f8a030 75%, rgba(248,160,48,0) 100%);
    box-shadow: 0 0 80px 40px rgba(252,220,60,0.4), 0 0 160px 80px rgba(248,160,48,0.2);
    animation: vet-sun-rise 1.5s ease-out both;
}
@keyframes vet-sun-rise {
    from { transform: translateY(40px); opacity: 0; }
    to   { transform: translateY(0);    opacity: 1; }
}

/* Sun glow rays */
.vet-sun-rays {
    position: absolute;
    bottom: 38%;
    left: 30%;
    width: 90px;
    height: 90px;
    animation: vet-ray-spin 60s linear infinite;
    transform-origin: center;
}
.vet-sun-rays::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 300px;
    height: 1px;
    background: linear-gradient(90deg, rgba(255,240,160,0.5), transparent);
    transform-origin: 0 50%;
    box-shadow:
        0 60px 0 rgba(255,240,160,0.3),
        0 -60px 0 rgba(255,240,160,0.3),
        120px 0 0 rgba(255,240,160,0.3),
        -60px 100px 0 rgba(255,240,160,0.25),
        -60px -100px 0 rgba(255,240,160,0.25);
}
@keyframes vet-ray-spin {
    from { transform: rotate(0deg); }
    to   { transform: rotate(360deg); }
}

/* Stars (fade out as dawn brightens) */
.vet-star {
    position: absolute;
    border-radius: 50%;
    background: #fff;
    animation: vet-star-twinkle ease-in-out infinite;
}
@keyframes vet-star-twinkle {
    0%,100%{opacity:0.5;} 50%{opacity:1;}
}

/* Birds */
.vet-bird {
    position: absolute;
    animation: vet-bird-fly linear infinite;
}
.vet-bird::before, .vet-bird::after {
    content: '';
    position: absolute;
    background: #2a1a0a;
    border-radius: 50% 50% 0 0;
    top: 0;
    width: 50%;
    height: 60%;
    animation: vet-wing-flap 0.6s ease-in-out infinite alternate;
}
.vet-bird::before { left: 0;   transform-origin: right center; }
.vet-bird::after  { right: 0;  transform-origin: left center; transform: scaleX(-1); }
@keyframes vet-bird-fly  { from{left:-5%} to{left:110%} }
@keyframes vet-wing-flap { from{transform:rotateX(0)}   to{transform:rotateX(60deg)} }

/* Rolling hills */
.vet-hill {
    position: absolute;
    left: -5%;
    right: -5%;
    bottom: 0;
    border-radius: 50% 50% 0 0 / 30% 30% 0 0;
    background: var(--vet-green);
}

/* Clinic building */
.vet-clinic {
    position: absolute;
    bottom: 28%;
    left: 8%;
    width: min(220px,26vw);
}
.vet-clinic-roof {
    width: 100%;
    height: 0;
    border-left: 15px solid transparent;
    border-right: 15px solid transparent;
    border-bottom: 60px solid #3a5050;
    position: relative;
}
.vet-clinic-roof::before {
    content: '';
    position: absolute;
    top: 60px;
    left: -15px;
    right: -15px;
    height: 8px;
    background: #2a4040;
    border-radius: 0;
}
.vet-clinic-chimney {
    position: absolute;
    top: -30px;
    right: 30%;
    width: 16px;
    height: 30px;
    background: #4a5060;
    border-radius: 2px 2px 0 0;
}
.vet-clinic-chimney::after {
    content: '';
    position: absolute;
    top: -4px;
    left: -3px;
    right: -3px;
    height: 6px;
    background: #5a6070;
    border-radius: 2px;
}
.vet-clinic-body {
    width: 100%;
    background: #e8e0d0;
    border: 2px solid #c8c0b0;
    position: relative;
    padding: 12px 12px 0;
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    gap: 8px;
}
.vet-clinic-sign {
    position: absolute;
    top: 8px;
    left: 50%;
    transform: translateX(-50%);
    background: #2a7a78;
    color: #fff;
    font-size: 0.6rem;
    font-weight: 700;
    padding: 3px 8px;
    border-radius: 3px;
    white-space: nowrap;
    grid-column: 1 / -1;
    width: max-content;
    letter-spacing: 0.05em;
    z-index: 2;
}
.vet-clinic-window {
    width: 100%;
    padding-bottom: 85%;
    background: linear-gradient(135deg, #b8e0f8 0%, #80c0e8 100%);
    border: 2px solid #9090a0;
    border-radius: 4px 4px 0 0;
    position: relative;
    overflow: hidden;
}
.vet-clinic-window::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 40%;
    height: 100%;
    background: rgba(255,255,255,0.3);
}
.vet-clinic-window.lit {
    background: linear-gradient(135deg, #f8f0a0 0%, #f0d060 100%);
    box-shadow: 0 0 12px rgba(240,210,80,0.6);
}
.vet-clinic-door {
    width: 55%;
    margin: 0 auto;
    padding-bottom: 80%;
    background: #5a3a28;
    border: 2px solid #3a2818;
    border-radius: 30px 30px 0 0;
    position: relative;
    grid-column: 2;
}
.vet-clinic-door::after {
    content: '';
    position: absolute;
    top: 40%;
    right: 15%;
    width: 8px;
    height: 8px;
    background: var(--vet-amber-light);
    border-radius: 50%;
}
.vet-clinic-step {
    grid-column: 1 / -1;
    height: 12px;
    background: #c8c0b0;
    border-top: 2px solid #b0a898;
    margin: 0 -12px;
}
.vet-cross {
    position: absolute;
    top: 24px;
    right: 12px;
    width: 22px;
    height: 22px;
}
.vet-cross::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    height: 6px;
    background: #e84040;
    border-radius: 2px;
    transform: translateY(-50%);
}
.vet-cross::after {
    content: '';
    position: absolute;
    left: 50%;
    top: 0;
    bottom: 0;
    width: 6px;
    background: #e84040;
    border-radius: 2px;
    transform: translateX(-50%);
}

/* Fence */
.vet-fence {
    position: absolute;
    bottom: 26%;
    left: 0;
    right: 0;
    height: 30px;
    display: flex;
    align-items: flex-end;
    gap: 0;
    pointer-events: none;
}
.vet-fence-post {
    width: 8px;
    height: 30px;
    background: #c8b090;
    border-radius: 3px 3px 0 0;
    flex-shrink: 0;
    margin: 0 calc((100%/16) - 4px);
}
.vet-fence-rail {
    position: absolute;
    top: 8px;
    left: 0;
    right: 0;
    height: 4px;
    background: #c8b090;
    border-radius: 2px;
}
.vet-fence-rail-2 {
    position: absolute;
    top: 20px;
    left: 0;
    right: 0;
    height: 3px;
    background: #c8b090;
    border-radius: 2px;
}

/* Meadow flowers */
.vet-flower {
    position: absolute;
    border-radius: 50%;
    pointer-events: none;
}

/* CSS dog silhouette */
.vet-dog {
    position: absolute;
    bottom: 27%;
    right: 12%;
    width: 80px;
    height: 55px;
}
.vet-dog-body {
    position: absolute;
    bottom: 8px;
    left: 16px;
    width: 48px;
    height: 28px;
    background: #3a2820;
    border-radius: 12px 16px 8px 8px;
}
.vet-dog-head {
    position: absolute;
    bottom: 28px;
    right: 4px;
    width: 24px;
    height: 20px;
    background: #3a2820;
    border-radius: 10px 10px 8px 8px;
}
.vet-dog-ear {
    position: absolute;
    top: -6px;
    right: 3px;
    width: 10px;
    height: 12px;
    background: #2a1810;
    border-radius: 50%;
}
.vet-dog-snout {
    position: absolute;
    bottom: 2px;
    left: 2px;
    width: 10px;
    height: 8px;
    background: #4a3030;
    border-radius: 4px;
}
.vet-dog-tail {
    position: absolute;
    bottom: 20px;
    left: 0;
    width: 18px;
    height: 8px;
    background: #3a2820;
    border-radius: 0 8px 8px 0;
    transform: rotate(-30deg);
    transform-origin: right center;
    animation: vet-wag 0.8s ease-in-out infinite alternate;
}
@keyframes vet-wag {
    from { transform: rotate(-30deg); }
    to   { transform: rotate(10deg); }
}
.vet-dog-leg {
    position: absolute;
    bottom: 0;
    width: 8px;
    height: 16px;
    background: #3a2820;
    border-radius: 4px;
}

/* CSS cat silhouette */
.vet-cat {
    position: absolute;
    bottom: 27%;
    right: 4%;
    width: 50px;
    height: 60px;
}
.vet-cat-body {
    position: absolute;
    bottom: 12px;
    left: 8px;
    width: 34px;
    height: 24px;
    background: #6a6060;
    border-radius: 10px 12px 8px 8px;
}
.vet-cat-head {
    position: absolute;
    bottom: 30px;
    left: 12px;
    width: 22px;
    height: 18px;
    background: #6a6060;
    border-radius: 50%;
}
.vet-cat-ear-l {
    position: absolute;
    top: -7px;
    left: 3px;
    width: 0;
    height: 0;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-bottom: 9px solid #6a6060;
}
.vet-cat-ear-r {
    position: absolute;
    top: -7px;
    right: 3px;
    width: 0;
    height: 0;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-bottom: 9px solid #6a6060;
}
.vet-cat-tail {
    position: absolute;
    bottom: 8px;
    left: 0;
    width: 6px;
    height: 30px;
    background: #6a6060;
    border-radius: 3px;
    transform: rotate(-15deg);
    transform-origin: bottom center;
}

/* Hero content */
.vet-hero-content {
    position: relative;
    z-index: 10;
    max-width: 1200px;
    margin: 0 auto;
    padding: 130px 48px 240px;
    display: grid;
    grid-template-columns: 1fr 380px;
    gap: 48px;
    align-items: center;
    width: 100%;
}
.vet-eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    font-size: 0.72rem;
    font-weight: 800;
    letter-spacing: 0.15em;
    text-transform: uppercase;
    color: var(--vet-teal);
    background: rgba(200,232,232,0.9);
    border: 1px solid rgba(42,122,120,0.3);
    padding: 6px 16px;
    border-radius: 20px;
    margin-bottom: 20px;
    backdrop-filter: blur(4px);
}
.vet-hero-h1 {
    font-family: var(--vet-font-head);
    font-size: clamp(2.4rem,4.5vw,3.8rem);
    font-weight: 700;
    line-height: 1.15;
    color: #1a2a28;
    margin-bottom: 10px;
    letter-spacing: -0.02em;
}
.vet-hero-h1 em {
    font-style: italic;
    font-weight: 300;
    color: var(--vet-teal);
}
.vet-hero-sub {
    font-family: var(--vet-font-head);
    font-size: 1rem;
    font-style: italic;
    font-weight: 300;
    color: #444;
    margin-bottom: 24px;
}
.vet-hero-desc {
    font-size: 1.02rem;
    color: #3a4a48;
    max-width: 460px;
    margin-bottom: 36px;
    background: rgba(255,255,250,0.8);
    padding: 16px 20px;
    border-radius: 8px;
    border-left: 3px solid var(--vet-teal-mid);
    backdrop-filter: blur(4px);
}
.vet-hero-btns {
    display: flex;
    gap: 14px;
    flex-wrap: wrap;
}
.vet-btn-primary {
    display: inline-block;
    padding: 14px 30px;
    background: var(--vet-teal);
    color: #fff;
    font-family: var(--vet-font-body);
    font-size: 0.9rem;
    font-weight: 800;
    letter-spacing: 0.05em;
    text-transform: uppercase;
    text-decoration: none;
    border-radius: var(--vet-radius);
    border: none;
    cursor: pointer;
    transition: background 0.25s, transform 0.2s, box-shadow 0.25s;
    box-shadow: 0 4px 16px rgba(26,92,90,0.3);
}
.vet-btn-primary:hover {
    background: var(--vet-teal-mid);
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(26,92,90,0.35);
}
.vet-btn-emergency {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 13px 24px;
    background: #c0392b;
    color: #fff;
    font-family: var(--vet-font-body);
    font-size: 0.9rem;
    font-weight: 800;
    text-decoration: none;
    border-radius: var(--vet-radius);
    border: none;
    cursor: pointer;
    transition: background 0.25s, transform 0.2s;
    box-shadow: 0 4px 16px rgba(192,57,43,0.3);
}
.vet-btn-emergency:hover {
    background: #a93226;
    transform: translateY(-2px);
}
.vet-btn-outline {
    display: inline-block;
    padding: 13px 24px;
    background: rgba(255,255,250,0.85);
    color: var(--vet-teal);
    font-family: var(--vet-font-body);
    font-size: 0.9rem;
    font-weight: 700;
    text-decoration: none;
    border-radius: var(--vet-radius);
    border: 2px solid var(--vet-teal);
    cursor: pointer;
    transition: all 0.25s;
    backdrop-filter: blur(4px);
}
.vet-btn-outline:hover {
    background: var(--vet-teal);
    color: #fff;
}

/* Hero info panel */
.vet-hero-panel {
    background: rgba(255,255,250,0.92);
    border-radius: 16px;
    padding: 32px;
    border: 1px solid rgba(42,122,120,0.2);
    box-shadow: 0 16px 50px rgba(26,92,90,0.14);
    backdrop-filter: blur(8px);
}
.vet-panel-title {
    font-family: var(--vet-font-head);
    font-size: 1.2rem;
    font-weight: 700;
    color: var(--vet-teal);
    margin-bottom: 18px;
    padding-bottom: 12px;
    border-bottom: 2px solid var(--vet-teal-pale);
}
.vet-hours-grid {
    display: grid;
    grid-template-columns: auto 1fr;
    gap: 4px 12px;
    font-size: 0.87rem;
    margin-bottom: 18px;
}
.vet-hours-day  { font-weight: 700; color: var(--vet-teal); }
.vet-hours-time { color: #555; }
.vet-emergency-cta {
    background: #fde8e8;
    border: 1px solid #f0b0b0;
    border-radius: 8px;
    padding: 14px 16px;
    margin-top: 16px;
    text-align: center;
}
.vet-emergency-label {
    font-size: 0.72rem;
    font-weight: 800;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    color: #c0392b;
    margin-bottom: 6px;
}
.vet-emergency-num {
    font-size: 1.3rem;
    font-weight: 800;
    color: #a0201a;
}
.vet-emergency-sub {
    font-size: 0.75rem;
    color: #888;
    margin-top: 3px;
}
.vet-rcvs-badge {
    margin-top: 16px;
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}
.vet-badge-pill {
    background: var(--vet-teal-pale);
    color: var(--vet-teal);
    font-size: 0.72rem;
    font-weight: 700;
    padding: 4px 12px;
    border-radius: 10px;
    letter-spacing: 0.04em;
}

/* ── STATS ─────────────────────────────────────────────────────── */
.vet-stats {
    background: var(--vet-teal);
    padding: 48px 48px;
}
.vet-stats-inner {
    max-width: 1200px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: repeat(4,1fr);
    gap: 32px;
    text-align: center;
}
.vet-stat-num {
    font-family: var(--vet-font-head);
    font-size: clamp(2.2rem,3.5vw,3rem);
    font-weight: 300;
    color: #fff;
    line-height: 1;
    letter-spacing: -0.02em;
}
.vet-stat-label {
    font-size: 0.8rem;
    font-weight: 700;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    color: rgba(255,255,255,0.7);
    margin-top: 6px;
}

/* ── SECTION SHELL ─────────────────────────────────────────────── */
.vet-section {
    padding: var(--vet-section) 48px;
    max-width: 1200px;
    margin: 0 auto;
}
.vet-section-alt {
    background: var(--vet-cream);
    padding: var(--vet-section) 0;
}
.vet-section-alt .vet-section {
    padding-top: 0; padding-bottom: 0;
}
.vet-section-dark {
    background: var(--vet-teal);
    padding: var(--vet-section) 0;
}
.vet-section-dark .vet-section {
    padding-top: 0; padding-bottom: 0;
}
.vet-label {
    display: inline-block;
    font-size: 0.7rem;
    font-weight: 800;
    letter-spacing: 0.18em;
    text-transform: uppercase;
    color: var(--vet-teal-mid);
    margin-bottom: 14px;
}
.vet-label-light { color: rgba(255,255,255,0.65); }
.vet-h2 {
    font-family: var(--vet-font-head);
    font-size: clamp(1.9rem,3.2vw,2.8rem);
    font-weight: 700;
    color: var(--vet-teal);
    line-height: 1.2;
    margin-bottom: 18px;
    letter-spacing: -0.01em;
}
.vet-h2 em { font-style: italic; font-weight: 300; color: var(--vet-amber); }
.vet-h2-light { color: #fff; }
.vet-h2-light em { color: var(--vet-amber-light); }
.vet-lead {
    font-size: 1.02rem;
    color: var(--vet-slate);
    max-width: 580px;
    margin-bottom: 48px;
}
.vet-lead-light { color: rgba(255,255,255,0.75); }

/* ── SERVICES ──────────────────────────────────────────────────── */
.vet-svc-grid {
    display: grid;
    grid-template-columns: repeat(3,1fr);
    gap: 24px;
    margin-top: 48px;
}
.vet-svc-card {
    background: #fff;
    border: 1px solid #d8ecec;
    border-radius: var(--vet-radius);
    padding: 30px 26px;
    transition: transform 0.25s, box-shadow 0.25s, border-color 0.25s;
    position: relative;
}
.vet-svc-card:hover {
    transform: translateY(-4px);
    box-shadow: var(--vet-shadow);
    border-color: var(--vet-teal-light);
}
.vet-svc-icon { font-size: 2.1rem; margin-bottom: 14px; display: block; }
.vet-svc-tag {
    position: absolute;
    top: 14px;
    right: 14px;
    background: var(--vet-teal-pale);
    color: var(--vet-teal);
    font-size: 0.68rem;
    font-weight: 700;
    padding: 4px 10px;
    border-radius: 10px;
    letter-spacing: 0.04em;
}
.vet-svc-title {
    font-family: var(--vet-font-head);
    font-size: 1.15rem;
    font-weight: 700;
    color: var(--vet-teal);
    margin-bottom: 10px;
}
.vet-svc-desc {
    font-size: 0.9rem;
    color: var(--vet-slate);
    line-height: 1.6;
}

/* ── SPECIES ───────────────────────────────────────────────────── */
.vet-species-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 14px;
    margin-top: 36px;
}
.vet-species-pill {
    display: flex;
    align-items: center;
    gap: 8px;
    background: #fff;
    border: 1px solid #d8ecec;
    border-radius: 30px;
    padding: 10px 20px;
    font-size: 0.92rem;
    font-weight: 600;
    color: var(--vet-teal);
    transition: all 0.2s;
}
.vet-species-pill:hover {
    background: var(--vet-teal-pale);
    border-color: var(--vet-teal-mid);
}
.vet-species-emoji { font-size: 1.2rem; }

/* ── PLANS ─────────────────────────────────────────────────────── */
.vet-plans-grid {
    display: grid;
    grid-template-columns: repeat(3,1fr);
    gap: 24px;
    margin-top: 48px;
    align-items: start;
}
.vet-plan-card {
    background: #fff;
    border: 2px solid #d8ecec;
    border-radius: 14px;
    padding: 32px 28px;
    position: relative;
    transition: transform 0.25s, box-shadow 0.25s;
}
.vet-plan-card:hover { transform: translateY(-4px); box-shadow: var(--vet-shadow); }
.vet-plan-card.highlight {
    border-color: var(--vet-teal);
    box-shadow: 0 0 0 1px var(--vet-teal), var(--vet-shadow);
}
.vet-plan-badge {
    position: absolute;
    top: -14px;
    left: 50%;
    transform: translateX(-50%);
    background: var(--vet-teal);
    color: #fff;
    font-size: 0.72rem;
    font-weight: 800;
    padding: 5px 18px;
    border-radius: 12px;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    white-space: nowrap;
}
.vet-plan-name {
    font-family: var(--vet-font-head);
    font-size: 1.2rem;
    font-weight: 700;
    color: var(--vet-teal);
    margin-bottom: 14px;
}
.vet-plan-price-row {
    display: flex;
    align-items: baseline;
    gap: 4px;
    margin-bottom: 20px;
}
.vet-plan-price {
    font-family: var(--vet-font-head);
    font-size: 2.4rem;
    font-weight: 700;
    color: var(--vet-teal);
    line-height: 1;
}
.vet-plan-period {
    font-size: 0.9rem;
    color: #aaa;
}
.vet-plan-list {
    list-style: none;
    display: flex;
    flex-direction: column;
    gap: 8px;
    margin-bottom: 24px;
}
.vet-plan-list li {
    font-size: 0.88rem;
    color: #444;
    display: flex;
    align-items: flex-start;
    gap: 8px;
}
.vet-plan-list li::before {
    content: '✓';
    color: var(--vet-teal);
    font-weight: 800;
    flex-shrink: 0;
    margin-top: 1px;
}
.vet-plan-cta {
    display: block;
    width: 100%;
    padding: 12px;
    text-align: center;
    background: var(--vet-teal-pale);
    color: var(--vet-teal);
    font-family: var(--vet-font-body);
    font-size: 0.9rem;
    font-weight: 800;
    text-decoration: none;
    border-radius: 8px;
    border: none;
    cursor: pointer;
    transition: all 0.2s;
    letter-spacing: 0.04em;
}
.vet-plan-cta:hover,
.vet-plan-card.highlight .vet-plan-cta {
    background: var(--vet-teal);
    color: #fff;
}

/* ── TEAM ──────────────────────────────────────────────────────── */
.vet-team-grid {
    display: grid;
    grid-template-columns: repeat(3,1fr);
    gap: 28px;
    margin-top: 48px;
}
.vet-team-card {
    background: #fff;
    border: 1px solid #d8ecec;
    border-radius: var(--vet-radius);
    overflow: hidden;
    transition: transform 0.25s, box-shadow 0.25s;
}
.vet-team-card:hover { transform: translateY(-4px); box-shadow: var(--vet-shadow); }
.vet-team-art {
    height: 180px;
    position: relative;
    overflow: hidden;
    display: flex;
    align-items: flex-end;
    justify-content: center;
}

/* CSS vet figure */
.vet-figure {
    position: relative;
    width: 80px;
    height: 150px;
}
.vet-fig-scrub {
    position: absolute;
    top: 38px;
    left: 50%;
    transform: translateX(-50%);
    width: 52px;
    height: 68px;
    border-radius: 4px 4px 2px 2px;
}
.vet-fig-head {
    position: absolute;
    top: 6px;
    left: 50%;
    transform: translateX(-50%);
    width: 32px;
    height: 36px;
    border-radius: 50% 50% 46% 46%;
}
.vet-fig-hair {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 16px;
    border-radius: 50% 50% 0 0;
}
.vet-fig-steth-neck {
    position: absolute;
    top: 42px;
    left: 50%;
    transform: translateX(-50%);
    width: 30px;
    height: 28px;
    border: 3px solid rgba(0,0,0,0.3);
    border-bottom: none;
    border-radius: 15px 15px 0 0;
}
.vet-fig-steth-disc {
    position: absolute;
    top: 68px;
    left: 50%;
    transform: translateX(-50%);
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: rgba(0,0,0,0.25);
    border: 2px solid rgba(0,0,0,0.35);
}
.vet-fig-arm-l {
    position: absolute;
    top: 40px;
    left: 10px;
    width: 14px;
    height: 44px;
    border-radius: 7px;
    transform: rotate(8deg);
    transform-origin: top center;
}
.vet-fig-arm-r {
    position: absolute;
    top: 40px;
    right: 10px;
    width: 14px;
    height: 44px;
    border-radius: 7px;
    transform: rotate(-8deg);
    transform-origin: top center;
}
.vet-fig-pet {
    position: absolute;
    bottom: 18px;
    left: 8px;
    width: 24px;
    height: 18px;
    background: #c08868;
    border-radius: 8px 10px 6px 6px;
}
.vet-fig-pet::before {
    content: '';
    position: absolute;
    top: -6px;
    left: 4px;
    width: 8px;
    height: 8px;
    background: #c08868;
    border-radius: 50%;
}
.vet-fig-pet::after {
    content: '';
    position: absolute;
    top: -10px;
    right: 2px;
    width: 0;
    height: 0;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-bottom: 8px solid #b07858;
}

.vet-team-info {
    padding: 20px 22px;
}
.vet-team-name {
    font-family: var(--vet-font-head);
    font-size: 1rem;
    font-weight: 700;
    color: var(--vet-teal);
    margin-bottom: 4px;
}
.vet-team-role {
    font-size: 0.78rem;
    font-weight: 800;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: var(--vet-amber);
    margin-bottom: 6px;
}
.vet-team-spec {
    font-size: 0.88rem;
    color: var(--vet-slate);
    margin-bottom: 8px;
}
.vet-team-cert {
    display: inline-block;
    background: var(--vet-teal-pale);
    color: var(--vet-teal);
    font-size: 0.7rem;
    font-weight: 700;
    padding: 3px 10px;
    border-radius: 8px;
    margin-bottom: 4px;
    display: block;
}
.vet-team-since { font-size: 0.75rem; color: #aaa; margin-top: 4px; }

/* ── TESTIMONIALS ──────────────────────────────────────────────── */
.vet-testi-grid {
    display: grid;
    grid-template-columns: repeat(3,1fr);
    gap: 24px;
    margin-top: 48px;
}
.vet-testi-card {
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.12);
    border-radius: var(--vet-radius);
    padding: 30px 26px;
    backdrop-filter: blur(6px);
}
.vet-testi-stars { color: var(--vet-amber-light); font-size: 1rem; margin-bottom: 12px; letter-spacing: 2px; }
.vet-testi-pet {
    display: inline-block;
    background: rgba(255,255,255,0.12);
    color: rgba(255,255,255,0.8);
    font-size: 0.72rem;
    font-weight: 700;
    padding: 3px 10px;
    border-radius: 8px;
    margin-bottom: 12px;
    letter-spacing: 0.04em;
}
.vet-testi-quote {
    font-family: var(--vet-font-head);
    font-size: 1rem;
    font-style: italic;
    font-weight: 300;
    color: rgba(255,255,255,0.9);
    line-height: 1.7;
    margin-bottom: 18px;
}
.vet-testi-name { font-size: 0.9rem; font-weight: 700; color: #fff; }
.vet-testi-loc  { font-size: 0.78rem; color: rgba(255,255,255,0.55); margin-top: 3px; }

/* ── FAQ ───────────────────────────────────────────────────────── */
.vet-faq-list { margin-top: 40px; display: flex; flex-direction: column; gap: 10px; }
.vet-faq-item { background: #fff; border: 1px solid #d8ecec; border-radius: var(--vet-radius); overflow: hidden; }
.vet-faq-q {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 18px 22px;
    cursor: pointer;
    font-size: 0.97rem;
    font-weight: 700;
    color: var(--vet-teal);
    gap: 14px;
    user-select: none;
}
.vet-faq-q:hover { background: var(--vet-cream); }
.vet-faq-icon {
    width: 26px;
    height: 26px;
    border-radius: 50%;
    background: var(--vet-teal-pale);
    color: var(--vet-teal);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1rem;
    flex-shrink: 0;
    transition: transform 0.3s, background 0.2s, color 0.2s;
}
.vet-faq-item.open .vet-faq-icon { transform: rotate(45deg); background: var(--vet-teal); color: #fff; }
.vet-faq-a { max-height: 0; overflow: hidden; transition: max-height 0.4s ease; }
.vet-faq-a-inner {
    padding: 0 22px 18px;
    font-size: 0.93rem;
    color: var(--vet-slate);
    line-height: 1.7;
    border-top: 1px solid #d8ecec;
    padding-top: 14px;
}

/* ── FORM ──────────────────────────────────────────────────────── */
.vet-form-section {
    background: var(--vet-teal);
    padding: var(--vet-section) 48px;
}
.vet-form-inner {
    max-width: 1200px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: 1fr 1.5fr;
    gap: 64px;
    align-items: start;
}
.vet-form-intro .vet-lead { color: rgba(255,255,255,0.72); margin-bottom: 28px; }
.vet-form-detail {
    display: flex;
    gap: 12px;
    margin-bottom: 14px;
    color: rgba(255,255,255,0.78);
    font-size: 0.9rem;
    align-items: flex-start;
}
.vet-form-detail-icon { font-size: 1rem; flex-shrink: 0; }
.vet-form-detail a { color: var(--vet-amber-light); text-decoration: none; }
.vet-form {
    background: rgba(255,255,255,0.06);
    border: 1px solid rgba(255,255,255,0.14);
    border-radius: 16px;
    padding: 36px;
    backdrop-filter: blur(10px);
}
.vet-form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px; }
.vet-form-group { display: flex; flex-direction: column; gap: 6px; }
.vet-form-group.full { grid-column: 1 / -1; }
.vet-form-label {
    font-size: 0.75rem;
    font-weight: 800;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: rgba(255,255,255,0.72);
}
.vet-form-input,
.vet-form-select,
.vet-form-textarea {
    padding: 12px 14px;
    background: rgba(255,255,255,0.09);
    border: 1px solid rgba(255,255,255,0.16);
    border-radius: 8px;
    color: #fff;
    font-family: var(--vet-font-body);
    font-size: 0.93rem;
    outline: none;
    transition: border-color 0.2s, background 0.2s;
}
.vet-form-input::placeholder, .vet-form-textarea::placeholder { color: rgba(255,255,255,0.35); }
.vet-form-input:focus, .vet-form-select:focus, .vet-form-textarea:focus {
    border-color: var(--vet-amber-light);
    background: rgba(255,255,255,0.13);
}
.vet-form-select option { background: var(--vet-teal); color: #fff; }
.vet-form-textarea { resize: vertical; min-height: 90px; }
.vet-form-submit {
    width: 100%;
    padding: 15px;
    background: var(--vet-amber);
    color: #fff;
    font-family: var(--vet-font-body);
    font-size: 0.97rem;
    font-weight: 800;
    letter-spacing: 0.05em;
    text-transform: uppercase;
    border: none;
    border-radius: var(--vet-radius);
    cursor: pointer;
    margin-top: 8px;
    transition: background 0.25s, transform 0.2s;
    box-shadow: 0 4px 16px rgba(0,0,0,0.2);
}
.vet-form-submit:hover { background: var(--vet-amber-light); transform: translateY(-2px); }
.vet-form-note {
    text-align: center;
    font-size: 0.78rem;
    color: rgba(255,255,255,0.45);
    margin-top: 12px;
}

/* ── ANIMATIONS ────────────────────────────────────────────────── */
.vet-fade-up {
    opacity: 0;
    transform: translateY(28px);
    transition: opacity 0.6s ease, transform 0.6s ease;
}
.vet-fade-up.visible { opacity: 1; transform: none; }

/* ── RESPONSIVE ────────────────────────────────────────────────── */
@media (max-width:1100px) {
    .vet-hero-content { grid-template-columns: 1fr; padding: 110px 32px 250px; }
    .vet-svc-grid     { grid-template-columns: repeat(2,1fr); }
    .vet-plans-grid   { grid-template-columns: 1fr; max-width: 480px; margin-left: auto; margin-right: auto; }
    .vet-team-grid    { grid-template-columns: repeat(2,1fr); }
    .vet-testi-grid   { grid-template-columns: repeat(2,1fr); }
    .vet-form-inner   { grid-template-columns: 1fr; }
    .vet-stats-inner  { grid-template-columns: repeat(2,1fr); }
}
@media (max-width:680px) {
    .vet-section      { padding: 60px 20px; }
    .vet-svc-grid     { grid-template-columns: 1fr; }
    .vet-team-grid    { grid-template-columns: 1fr; }
    .vet-testi-grid   { grid-template-columns: 1fr; }
    .vet-form-grid    { grid-template-columns: 1fr; }
    .vet-form-section { padding: 60px 20px; }
    .vet-stats        { padding: 48px 20px; }
    .vet-clinic       { display: none; }
    .vet-dog          { display: none; }
}
</style>
<?php get_header(); ?>

<div class="">

>
<?php wp_body_open(); ?>

<!-- Emergency bar -->
<div class="vet-emergency-bar" role="alert">
    🚨 Emergency? Our vets are available 24/7 —
    <a href="tel:<?php echo esc_attr(preg_replace('/\s+/','',$business['emergency'])); ?>">
        Call <?php echo esc_html($business['emergency']); ?>
    </a>
</div>

<!-- ═══════════════════════════════════════════════════════════════
     HERO — COUNTRYSIDE AT DAWN
     ═══════════════════════════════════════════════════════════════ -->
<section class="vet-hero" aria-label="Hero">

    <!-- Sky -->
    <div class="vet-sky" aria-hidden="true"></div>

    <!-- Sun & rays -->
    <div class="vet-sun" aria-hidden="true"></div>
    <div class="vet-sun-rays" aria-hidden="true"></div>

    <!-- Stars -->
    <?php foreach($stars as $s): ?>
    <div class="vet-star" aria-hidden="true"
         style="left:<?php echo $s['left']; ?>%;top:<?php echo $s['top']; ?>%;
                width:<?php echo $s['size']; ?>px;height:<?php echo $s['size']; ?>px;
                opacity:<?php echo $s['op']; ?>;
                animation-duration:<?php echo $s['dur']; ?>s;
                animation-delay:-<?php echo $s['del']; ?>s;"></div>
    <?php endforeach; ?>

    <!-- Birds -->
    <?php foreach($birds as $b): ?>
    <div class="vet-bird" aria-hidden="true"
         style="top:<?php echo $b['top']; ?>%;
                width:<?php echo $b['size']; ?>px;height:<?php echo $b['size']/2; ?>px;
                animation-duration:<?php echo $b['dur']; ?>s;
                animation-delay:-<?php echo $b['delay']; ?>s;
                opacity:0.7;"></div>
    <?php endforeach; ?>

    <!-- Rolling hills (3 layers) -->
    <?php foreach($hill_colors as $hc): ?>
    <div class="vet-hill" aria-hidden="true"
         style="background:<?php echo esc_attr($hc['bg']); ?>;
                top:<?php echo esc_attr($hc['top']); ?>;
                bottom:0;"></div>
    <?php endforeach; ?>

    <!-- Meadow flowers -->
    <?php foreach($flowers as $fl): ?>
    <div class="vet-flower" aria-hidden="true"
         style="left:<?php echo $fl['left']; ?>%;top:<?php echo $fl['top']; ?>%;
                width:<?php echo $fl['size']; ?>px;height:<?php echo $fl['size']; ?>px;
                background:<?php echo esc_attr($fl['col']); ?>;
                opacity:0.85;"></div>
    <?php endforeach; ?>

    <!-- Clinic building -->
    <div class="vet-clinic" aria-hidden="true">
        <div class="vet-clinic-roof">
            <div class="vet-clinic-chimney"></div>
            <div class="vet-cross"></div>
        </div>
        <div class="vet-clinic-body">
            <span class="vet-clinic-sign" aria-label="Meadowbrook Veterinary">🐾 MEADOWBROOK VET</span>
            <div style="margin-top:28px;"><div class="vet-clinic-window lit"></div></div>
            <div style="margin-top:28px;"><div class="vet-clinic-door"></div></div>
            <div style="margin-top:28px;"><div class="vet-clinic-window"></div></div>
            <div class="vet-clinic-step"></div>
        </div>
    </div>

    <!-- Fence -->
    <div class="vet-fence" aria-hidden="true">
        <div class="vet-fence-rail"></div>
        <div class="vet-fence-rail-2"></div>
        <?php foreach($fence_posts as $fp): ?>
        <div class="vet-fence-post"></div>
        <?php endforeach; ?>
    </div>

    <!-- CSS dog -->
    <div class="vet-dog" aria-hidden="true">
        <div class="vet-dog-tail"></div>
        <div class="vet-dog-body"></div>
        <div class="vet-dog-head">
            <div class="vet-dog-ear"></div>
            <div class="vet-dog-snout"></div>
        </div>
        <div class="vet-dog-leg" style="left:18px;"></div>
        <div class="vet-dog-leg" style="left:30px;"></div>
        <div class="vet-dog-leg" style="right:14px;"></div>
        <div class="vet-dog-leg" style="right:26px;"></div>
    </div>

    <!-- CSS cat -->
    <div class="vet-cat" aria-hidden="true">
        <div class="vet-cat-tail"></div>
        <div class="vet-cat-body"></div>
        <div class="vet-cat-head">
            <div class="vet-cat-ear-l"></div>
            <div class="vet-cat-ear-r"></div>
        </div>
    </div>

    <!-- Hero content -->
    <div class="vet-hero-content">
        <div class="vet-hero-text">
            <span class="vet-eyebrow">
                🐾 Stratford-upon-Avon, Warwickshire
            </span>
            <h1 class="vet-hero-h1">
                Expert care for<br>
                <em>every animal,</em><br>
                every day
            </h1>
            <p class="vet-hero-sub"><?php echo esc_html($business['name']); ?> · <?php echo esc_html($business['tagline']); ?></p>
            <p class="vet-hero-desc">
                From puppies and kittens to farm herds and horses — our team of RCVS-qualified
                vets provides compassionate, expert care across Warwickshire and surrounding counties.
            </p>
            <div class="vet-hero-btns">
                <a href="#contact"  class="vet-btn-primary">Book an Appointment</a>
                <a href="tel:<?php echo esc_attr(preg_replace('/\s+/','',$business['emergency'])); ?>"
                   class="vet-btn-emergency">🚨 Emergency</a>
                <a href="#services" class="vet-btn-outline">Our Services</a>
            </div>
        </div>

        <div class="vet-hero-panel">
            <div class="vet-panel-title">🕐 Opening Hours</div>
            <div class="vet-hours-grid">
                <span class="vet-hours-day">Mon – Fri</span>
                <span class="vet-hours-time">8:30am – 6:30pm</span>
                <span class="vet-hours-day">Saturday</span>
                <span class="vet-hours-time">9:00am – 5:00pm</span>
                <span class="vet-hours-day">Sunday</span>
                <span class="vet-hours-time">10:00am – 2:00pm</span>
            </div>
            <div class="vet-emergency-cta">
                <div class="vet-emergency-label">24/7 Emergency Line</div>
                <div class="vet-emergency-num">
                    <a href="tel:<?php echo esc_attr(preg_replace('/\s+/','',$business['emergency'])); ?>"
                       style="color:inherit;text-decoration:none;">
                        <?php echo esc_html($business['emergency']); ?>
                    </a>
                </div>
                <div class="vet-emergency-sub">Our own vets — not a third-party service</div>
            </div>
            <div class="vet-rcvs-badge">
                <span class="vet-badge-pill">✓ RCVS Accredited</span>
                <span class="vet-badge-pill">✓ Xero Gold Partner</span>
                <span class="vet-badge-pill">✓ PDSA Supporting</span>
            </div>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     STATS
     ═══════════════════════════════════════════════════════════════ -->
<section class="vet-stats" aria-label="Key figures">
    <div class="vet-stats-inner">
        <?php foreach($stats as $st): ?>
        <div>
            <div class="vet-stat-num"
                 data-target="<?php echo esc_attr($st['value']); ?>"
                 data-suffix="<?php echo esc_attr($st['suffix']); ?>">
                <?php echo esc_html($st['value'].$st['suffix']); ?>
            </div>
            <div class="vet-stat-label"><?php echo esc_html($st['label']); ?></div>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     SERVICES
     ═══════════════════════════════════════════════════════════════ -->
<div id="services">
<section class="vet-section" aria-label="Our services">
    <div class="vet-fade-up">
        <span class="vet-label">What we provide</span>
        <h2 class="vet-h2">Comprehensive <em>veterinary care</em></h2>
        <p class="vet-lead">
            Our purpose-built practice offers the full spectrum of veterinary services —
            from routine wellness appointments to complex surgical procedures.
        </p>
    </div>
    <div class="vet-svc-grid">
        <?php foreach($services as $svc): ?>
        <article class="vet-svc-card vet-fade-up">
            <span class="vet-svc-icon" aria-hidden="true"><?php echo $svc['icon']; ?></span>
            <span class="vet-svc-tag"><?php echo esc_html($svc['tag']); ?></span>
            <h3 class="vet-svc-title"><?php echo esc_html($svc['title']); ?></h3>
            <p class="vet-svc-desc"><?php echo esc_html($svc['desc']); ?></p>
        </article>
        <?php endforeach; ?>
    </div>
</section>
</div>

<!-- ═══════════════════════════════════════════════════════════════
     SPECIES
     ═══════════════════════════════════════════════════════════════ -->
<div class="vet-section-alt">
<section class="vet-section" style="padding-top:var(--vet-section);padding-bottom:var(--vet-section);" aria-label="Animals we treat">
    <div class="vet-fade-up">
        <span class="vet-label">Animals we treat</span>
        <h2 class="vet-h2">Small animals to <em>large livestock</em></h2>
        <p class="vet-lead">
            Our team includes both small animal specialists and farm animal vets —
            giving us the range to care for pets, poultry, cattle and horses alike.
        </p>
    </div>
    <div class="vet-species-grid">
        <?php foreach($species as $sp): ?>
        <div class="vet-species-pill vet-fade-up">
            <span class="vet-species-emoji" aria-hidden="true"><?php echo $sp['emoji']; ?></span>
            <span><?php echo esc_html($sp['name']); ?></span>
        </div>
        <?php endforeach; ?>
    </div>
</section>
</div>

<!-- ═══════════════════════════════════════════════════════════════
     HEALTHCARE PLANS
     ═══════════════════════════════════════════════════════════════ -->
<section class="vet-section" aria-label="Healthcare plans">
    <div class="vet-fade-up">
        <span class="vet-label">Pet healthcare plans</span>
        <h2 class="vet-h2">Spread the cost of <em>routine care</em></h2>
        <p class="vet-lead">
            Our monthly pet health plans make it easier to keep up with essential preventative
            care — and save you money compared to paying per appointment.
        </p>
    </div>
    <div class="vet-plans-grid">
        <?php foreach($plans as $plan): ?>
        <article class="vet-plan-card vet-fade-up <?php echo $plan['highlight'] ? 'highlight' : ''; ?>">
            <?php if(!empty($plan['badge'])): ?>
            <div class="vet-plan-badge"><?php echo esc_html($plan['badge']); ?></div>
            <?php endif; ?>
            <div class="vet-plan-name"><?php echo esc_html($plan['name']); ?></div>
            <div class="vet-plan-price-row">
                <span class="vet-plan-price"><?php echo esc_html($plan['price']); ?></span>
                <span class="vet-plan-period"><?php echo esc_html($plan['period']); ?></span>
            </div>
            <ul class="vet-plan-list" aria-label="Plan includes">
                <?php foreach($plan['includes'] as $inc): ?>
                <li><?php echo esc_html($inc); ?></li>
                <?php endforeach; ?>
            </ul>
            <a href="#contact" class="vet-plan-cta">Join this plan</a>
        </article>
        <?php endforeach; ?>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     TEAM
     ═══════════════════════════════════════════════════════════════ -->
<div class="vet-section-alt">
<section class="vet-section" style="padding-top:var(--vet-section);padding-bottom:var(--vet-section);" aria-label="Our team">
    <div class="vet-fade-up">
        <span class="vet-label">Meet the vets</span>
        <h2 class="vet-h2">Qualified, <em>compassionate</em> care</h2>
        <p class="vet-lead">
            Every vet in our practice is MRCVS-qualified and committed to ongoing professional
            development. You'll always see a vet — not a nurse — for clinical decisions.
        </p>
    </div>
    <div class="vet-team-grid">
        <?php foreach($team as $idx => $tm): ?>
        <?php
        $skin_colors = ['#f0c8a0','#c89870','#e8c0a0'];
        $hair_colors = ['#2a1808','#1a1a0a','#4a3818'];
        $scrub_colors= ['var(--vet-teal)','#2a5a7a','#5a7a2a'];
        $sc = $scrub_colors[$idx%3];
        ?>
        <article class="vet-team-card vet-fade-up">
            <div class="vet-team-art"
                 style="background:linear-gradient(180deg,<?php echo esc_attr($tm['col']); ?> 0%,<?php echo esc_attr($tm['col']); ?>cc 100%);">
                <div class="vet-figure">
                    <div class="vet-fig-head" style="background:<?php echo esc_attr($skin_colors[$idx%3]); ?>;"></div>
                    <div class="vet-fig-hair" style="background:<?php echo esc_attr($hair_colors[$idx%3]); ?>;"></div>
                    <div class="vet-fig-scrub" style="background:<?php echo esc_attr($sc); ?>;"></div>
                    <div class="vet-fig-steth-neck" style="border-color:<?php echo esc_attr($sc==='var(--vet-teal)'?'rgba(255,255,255,0.5)':'rgba(255,255,255,0.4)'); ?>;"></div>
                    <div class="vet-fig-steth-disc" style="background:rgba(255,255,255,0.3);border-color:rgba(255,255,255,0.5);"></div>
                    <div class="vet-fig-arm-l" style="background:<?php echo esc_attr($sc); ?>;"></div>
                    <div class="vet-fig-arm-r" style="background:<?php echo esc_attr($sc); ?>;"></div>
                    <div class="vet-fig-pet"></div>
                </div>
            </div>
            <div class="vet-team-info">
                <div class="vet-team-name"><?php echo esc_html($tm['name']); ?></div>
                <div class="vet-team-role"><?php echo esc_html($tm['role']); ?></div>
                <div class="vet-team-spec"><?php echo esc_html($tm['spec']); ?></div>
                <span class="vet-team-cert"><?php echo esc_html($tm['cert']); ?></span>
                <div class="vet-team-since"><?php echo esc_html($tm['since']); ?></div>
            </div>
        </article>
        <?php endforeach; ?>
    </div>
</section>
</div>

<!-- ═══════════════════════════════════════════════════════════════
     TESTIMONIALS
     ═══════════════════════════════════════════════════════════════ -->
<div class="vet-section-dark">
<section class="vet-section" style="padding-top:var(--vet-section);padding-bottom:var(--vet-section);" aria-label="Client reviews">
    <div class="vet-fade-up">
        <span class="vet-label vet-label-light">What clients say</span>
        <h2 class="vet-h2 vet-h2-light">Trusted by <em>families & farmers</em></h2>
    </div>
    <div class="vet-testi-grid">
        <?php foreach($testimonials as $t): ?>
        <article class="vet-testi-card vet-fade-up">
            <div class="vet-testi-stars" aria-label="<?php echo esc_attr($t['stars']); ?> stars">
                <?php echo str_repeat('★',$t['stars']); ?>
            </div>
            <div class="vet-testi-pet"><?php echo esc_html($t['pet']); ?></div>
            <blockquote class="vet-testi-quote">"<?php echo esc_html($t['quote']); ?>"</blockquote>
            <div class="vet-testi-name"><?php echo esc_html($t['name']); ?></div>
            <div class="vet-testi-loc"><?php echo esc_html($t['loc']); ?></div>
        </article>
        <?php endforeach; ?>
    </div>
</section>
</div>

<!-- ═══════════════════════════════════════════════════════════════
     FAQ
     ═══════════════════════════════════════════════════════════════ -->
<section class="vet-section" aria-label="Frequently asked questions">
    <div class="vet-fade-up">
        <span class="vet-label">Common questions</span>
        <h2 class="vet-h2">We're here to <em>help</em></h2>
    </div>
    <div class="vet-faq-list" role="list">
        <?php foreach($faqs as $i => $faq): ?>
        <div class="vet-faq-item" role="listitem">
            <button class="vet-faq-q"
                    aria-expanded="false"
                    aria-controls="vet-faq-a-<?php echo $i; ?>">
                <span><?php echo esc_html($faq['q']); ?></span>
                <span class="vet-faq-icon" aria-hidden="true">+</span>
            </button>
            <div class="vet-faq-a"
                 id="vet-faq-a-<?php echo $i; ?>"
                 role="region">
                <div class="vet-faq-a-inner">
                    <?php echo esc_html($faq['a']); ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     BOOKING FORM
     ═══════════════════════════════════════════════════════════════ -->
<div class="vet-form-section" id="contact" aria-label="Book an appointment">
    <div class="vet-form-inner">

        <div class="vet-form-intro vet-fade-up">
            <span class="vet-label vet-label-light">Book an appointment</span>
            <h2 class="vet-h2 vet-h2-light">Let's care for <em>your animal</em></h2>
            <p class="vet-lead vet-lead-light">
                Use the form to request a routine appointment. For emergencies,
                please call our emergency line directly — don't wait for a form response.
            </p>
            <div class="vet-form-detail">
                <span class="vet-form-detail-icon">☎️</span>
                <span>
                    <a href="tel:<?php echo esc_attr(preg_replace('/\s+/','',$business['phone'])); ?>">
                        <?php echo esc_html($business['phone']); ?>
                    </a> (main)
                </span>
            </div>
            <div class="vet-form-detail">
                <span class="vet-form-detail-icon">🚨</span>
                <span>
                    <a href="tel:<?php echo esc_attr(preg_replace('/\s+/','',$business['emergency'])); ?>"
                       style="font-weight:800;">
                        <?php echo esc_html($business['emergency']); ?>
                    </a> (24/7 emergency)
                </span>
            </div>
            <div class="vet-form-detail">
                <span class="vet-form-detail-icon">📍</span>
                <span><?php echo esc_html($business['location']); ?></span>
            </div>
            <div class="vet-form-detail">
                <span class="vet-form-detail-icon">✉️</span>
                <span>
                    <a href="mailto:<?php echo esc_attr($business['email']); ?>">
                        <?php echo esc_html($business['email']); ?>
                    </a>
                </span>
            </div>
        </div>

        <div class="vet-form vet-fade-up">
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" novalidate>
                <?php wp_nonce_field('tf_vet_appointment','tf_vet_nonce'); ?>
                <input type="hidden" name="action" value="tf_vet_appointment">

                <div class="vet-form-grid">
                    <div class="vet-form-group">
                        <label class="vet-form-label" for="vet-first">Owner First Name *</label>
                        <input class="vet-form-input" type="text" id="vet-first"
                               name="first_name" placeholder="Emma" required autocomplete="given-name">
                    </div>
                    <div class="vet-form-group">
                        <label class="vet-form-label" for="vet-last">Owner Last Name *</label>
                        <input class="vet-form-input" type="text" id="vet-last"
                               name="last_name" placeholder="Sutton" required autocomplete="family-name">
                    </div>
                    <div class="vet-form-group">
                        <label class="vet-form-label" for="vet-phone">Phone Number *</label>
                        <input class="vet-form-input" type="tel" id="vet-phone"
                               name="phone" placeholder="01789 000 000" required autocomplete="tel">
                    </div>
                    <div class="vet-form-group">
                        <label class="vet-form-label" for="vet-email">Email Address *</label>
                        <input class="vet-form-input" type="email" id="vet-email"
                               name="email" placeholder="you@example.co.uk" required autocomplete="email">
                    </div>
                    <div class="vet-form-group">
                        <label class="vet-form-label" for="vet-pet-name">Pet / Animal Name *</label>
                        <input class="vet-form-input" type="text" id="vet-pet-name"
                               name="pet_name" placeholder="Archie" required>
                    </div>
                    <div class="vet-form-group">
                        <label class="vet-form-label" for="vet-species">Species *</label>
                        <select class="vet-form-select" id="vet-species" name="species" required>
                            <option value="">— Select species —</option>
                            <?php foreach($species_opts as $sp): ?>
                            <option value="<?php echo esc_attr(sanitize_title($sp)); ?>">
                                <?php echo esc_html($sp); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="vet-form-group">
                        <label class="vet-form-label" for="vet-age">Pet Age</label>
                        <input class="vet-form-input" type="text" id="vet-age"
                               name="pet_age" placeholder="e.g. 9 years">
                    </div>
                    <div class="vet-form-group">
                        <label class="vet-form-label" for="vet-appt-type">Appointment Type *</label>
                        <select class="vet-form-select" id="vet-appt-type" name="appointment_type" required>
                            <option value="">— Select type —</option>
                            <?php foreach($appt_types as $at): ?>
                            <option value="<?php echo esc_attr(sanitize_title($at)); ?>">
                                <?php echo esc_html($at); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="vet-form-group">
                        <label class="vet-form-label" for="vet-pref-date">Preferred Date</label>
                        <input class="vet-form-input" type="date" id="vet-pref-date"
                               name="preferred_date"
                               min="<?php echo esc_attr(date('Y-m-d', strtotime('+1 day'))); ?>">
                    </div>
                    <div class="vet-form-group">
                        <label class="vet-form-label" for="vet-pref-time">Preferred Time</label>
                        <select class="vet-form-select" id="vet-pref-time" name="preferred_time">
                            <option value="">— Any time —</option>
                            <option>Morning (8:30–12:00)</option>
                            <option>Afternoon (12:00–17:00)</option>
                            <option>Evening (17:00–18:30)</option>
                        </select>
                    </div>
                    <div class="vet-form-group full">
                        <label class="vet-form-label" for="vet-symptoms">Reason for Visit / Symptoms</label>
                        <textarea class="vet-form-textarea" id="vet-symptoms" name="symptoms"
                                  placeholder="Describe any symptoms, concerns or reason for the appointment…"></textarea>
                    </div>
                </div>

                <button type="submit" class="vet-form-submit">
                    🐾 Request Appointment
                </button>
                <p class="vet-form-note">
                    We'll confirm your appointment within 2 working hours (Mon–Sat).
                    For urgent matters, please call directly.
                </p>
            </form>
        </div>

    </div>
</div>

<!-- ═══════════════════════════════════════════════════════════════
     JAVASCRIPT
     ═══════════════════════════════════════════════════════════════ -->
<script>
(function(){
    'use strict';
    var fades = document.querySelectorAll('.vet-fade-up');
    if('IntersectionObserver' in window){
        var io=new IntersectionObserver(function(e){e.forEach(function(x){if(x.isIntersecting){x.target.classList.add('visible');io.unobserve(x.target);}});},{threshold:0.12});
        fades.forEach(function(el){io.observe(el);});
    } else { fades.forEach(function(el){el.classList.add('visible');}); }

    var easeOut=function(t){return 1-Math.pow(1-t,3);};
    function animCounter(el){
        var raw=parseFloat(el.dataset.target),suf=el.dataset.suffix||'';
        if(isNaN(raw))return;
        var isFloat=el.dataset.target.indexOf('.')!==-1,start=null,dur=1800;
        function tick(ts){
            if(!start)start=ts;
            var prog=Math.min((ts-start)/dur,1),val=raw*easeOut(prog);
            el.textContent=(isFloat?val.toFixed(1):Math.round(val).toLocaleString())+suf;
            if(prog<1)requestAnimationFrame(tick);
            else el.textContent=(isFloat?raw.toFixed(1):raw.toLocaleString())+suf;
        }
        requestAnimationFrame(tick);
    }
    if('IntersectionObserver' in window){
        var cio=new IntersectionObserver(function(e){e.forEach(function(x){if(x.isIntersecting){animCounter(x.target);cio.unobserve(x.target);}});},{threshold:0.5});
        document.querySelectorAll('[data-target]').forEach(function(c){cio.observe(c);});
    } else { document.querySelectorAll('[data-target]').forEach(animCounter); }

    document.querySelectorAll('.vet-faq-q').forEach(function(btn){
        btn.addEventListener('click',function(){
            var item=btn.closest('.vet-faq-item'),ans=item.querySelector('.vet-faq-a');
            var open=item.classList.toggle('open');
            btn.setAttribute('aria-expanded',open?'true':'false');
            ans.style.maxHeight=open?ans.scrollHeight+'px':'0';
        });
    });

    document.querySelectorAll('a[href^="#"]').forEach(function(a){
        a.addEventListener('click',function(e){
            var tgt=document.getElementById(a.getAttribute('href').slice(1));
            if(tgt){e.preventDefault();tgt.scrollIntoView({behavior:'smooth',block:'start'});}
        });
    });
})();
</script>

</div><!-- . -->

<?php get_footer(); ?>
