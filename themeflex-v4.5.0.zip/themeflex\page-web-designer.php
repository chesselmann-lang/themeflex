<?php
/**
 * Template Name: Web Designer
 *
 * Premium landing page for a freelance web designer / digital creative studio.
 * CSS art: animated browser window showing a live "typing" wireframe build,
 * floating code tokens, pixel-art cursor trail, and a neon grid hero.
 *
 * Namespace   : --wd-*
 * Fonts       : Space Grotesk (headings) + DM Mono (code/labels) + Inter (body)
 * Palette     : midnight #0A0E1A / electric violet #7B5CF0 / neon cyan #00F0D4
 *               soft white #F0F4FF / warm grey #8892A4
 * Keyframes   : wd-cursor-blink, wd-type, wd-float, wd-glow-pulse,
 *               wd-grid-scroll, wd-bar-grow, wd-pixel-fade, wd-slide-right
 *
 * @package ThemeFlex
 */
srand( crc32( get_the_permalink() ) );

/* ── designer info ───────────────────────────────────────── */
$wd_designer    = 'Ava Thornton';
$wd_title       = 'Senior Web Designer & Digital Strategist';
$wd_years       = 11;
$wd_location    = 'London & Remote';
$wd_email       = 'hello@avathornton.design';
$wd_phone       = '020 7946 0812';

/* ── floating code tokens ──────────────────────────────── */
$wd_tokens = [
    '<header>', '</div>', 'flex:', 'grid:', '#7B5CF0', 'async', 'transform:',
    '.hero{', 'font-size:', 'const', 'return', '@media', ':root{', 'border-radius:',
    'z-index:', 'margin:', 'display:', 'opacity:', 'transition:', 'hover{',
];
$wd_floaters = [];
for ( $i = 0; $i < 22; $i++ ) {
    $wd_floaters[] = [
        'token'    => $wd_tokens[ array_rand( $wd_tokens ) ],
        'left'     => rand( 0, 98 ),
        'top'      => rand( 5, 90 ),
        'delay'    => round( rand( 0, 7000 ) / 1000, 2 ),
        'duration' => round( rand( 5000, 12000 ) / 1000, 2 ),
        'size'     => rand( 10, 14 ),
        'opacity'  => round( rand( 15, 45 ) / 100, 2 ),
    ];
}

/* ── browser mockup "wireframe" blocks ─────────────────── */
$wd_wireframe_rows = [
    [ 'type' => 'nav',    'h' => 28, 'blocks' => [ 80, 0, 0, 60, 50, 70 ] ],
    [ 'type' => 'hero',   'h' => 70, 'blocks' => [] ],
    [ 'type' => 'cards',  'h' => 50, 'blocks' => [ 28, 28, 28 ] ],
    [ 'type' => 'text',   'h' => 14, 'blocks' => [ 90, 75, 60, 80 ] ],
    [ 'type' => 'footer', 'h' => 30, 'blocks' => [ 40, 0, 30, 0, 50 ] ],
];

/* ── services ──────────────────────────────────────────── */
$wd_services = [
    [ 'icon' => '🎨', 'name' => 'UI/UX Design',          'desc' => 'Wireframes, interactive prototypes and pixel-perfect designs crafted in Figma that users love navigating.' ],
    [ 'icon' => '⚡', 'name' => 'Web Development',        'desc' => 'Clean, semantic HTML & CSS built on WordPress or headless CMS — fast, accessible and SEO-ready from day one.' ],
    [ 'icon' => '📱', 'name' => 'Responsive Design',      'desc' => 'Mobile-first layouts tested across every device and viewport so your site looks flawless everywhere.' ],
    [ 'icon' => '🚀', 'name' => 'Landing Pages',          'desc' => 'High-converting campaign pages with compelling copy structure, social proof and optimised CTAs.' ],
    [ 'icon' => '🛒', 'name' => 'E-Commerce',             'desc' => 'WooCommerce stores with custom product pages, checkout optimisation and payment gateway integration.' ],
    [ 'icon' => '🔍', 'name' => 'SEO & Performance',      'desc' => 'Core Web Vitals optimisation, structured data, page speed and technical SEO audits for better rankings.' ],
    [ 'icon' => '🎯', 'name' => 'Brand Identity',         'desc' => 'Logo design, colour systems, typography pairings and full brand guidelines to keep you consistent.' ],
    [ 'icon' => '🔄', 'name' => 'Website Refresh',        'desc' => 'Modernise an ageing site — improved UX, updated visuals, better performance — without starting from scratch.' ],
];

/* ── tech stack skills ─────────────────────────────────── */
$wd_skills = [
    [ 'name' => 'Figma',        'pct' => 97 ],
    [ 'name' => 'WordPress',    'pct' => 95 ],
    [ 'name' => 'HTML & CSS',   'pct' => 99 ],
    [ 'name' => 'JavaScript',   'pct' => 88 ],
    [ 'name' => 'WooCommerce',  'pct' => 85 ],
    [ 'name' => 'React / Next', 'pct' => 78 ],
];

/* ── process ───────────────────────────────────────────── */
$wd_steps = [
    [ 'num' => '01', 'title' => 'Discovery',      'desc' => 'We map your goals, audience, competitors and brand personality in a focused strategy session.' ],
    [ 'num' => '02', 'title' => 'Wireframes',     'desc' => 'Lo-fi wireframes establish the layout logic and user journey before any design decisions are made.' ],
    [ 'num' => '03', 'title' => 'Design',         'desc' => 'High-fidelity mockups in Figma — you see exactly what your site will look like and can review every detail.' ],
    [ 'num' => '04', 'title' => 'Build',          'desc' => 'Pixel-perfect development with clean code, responsive testing and cross-browser QA throughout.' ],
    [ 'num' => '05', 'title' => 'Launch & Train', 'desc' => 'We go live together, then I hand over training so you can confidently manage your own content.' ],
];

/* ── portfolio items ───────────────────────────────────── */
$wd_portfolio = [
    [ 'title' => 'Bloom Florist',      'type' => 'E-Commerce Redesign',    'colour' => '#E8B4C3' ],
    [ 'title' => 'DataPulse SaaS',     'type' => 'Landing Page Suite',     'colour' => '#B4C3E8' ],
    [ 'title' => 'Harrow & Co. Law',   'type' => 'Corporate Rebrand',      'colour' => '#C3E8B4' ],
    [ 'title' => 'GrainFed Kitchen',   'type' => 'Restaurant & Booking',   'colour' => '#E8D4B4' ],
    [ 'title' => 'NovaMed Clinic',     'type' => 'Healthcare Portal',      'colour' => '#D4B4E8' ],
    [ 'title' => 'ZipFreight Logistics', 'type' => 'B2B Lead-Gen Site',   'colour' => '#B4E8D4' ],
];

/* ── testimonials ──────────────────────────────────────── */
$wd_testimonials = [
    [ 'name' => 'James R.',   'co' => 'DataPulse', 'stars' => 5, 'text' => 'Ava transformed our SaaS landing pages and our trial signups jumped 42% in the first month. Exceptional design thinking.' ],
    [ 'name' => 'Claire M.',  'co' => 'Bloom Florist', 'stars' => 5, 'text' => 'Our e-commerce revenue is up 60% since the redesign. Ava understood our brand immediately and made the complex simple.' ],
    [ 'name' => 'Philip K.',  'co' => 'Harrow & Co.', 'stars' => 5, 'text' => 'The rebrand perfectly balances authority and approachability. Client feedback on the new site has been overwhelmingly positive.' ],
    [ 'name' => 'Priya S.',   'co' => 'NovaMed', 'stars' => 5, 'text' => 'Ava navigated our complex requirements with patience and creativity. The portal is intuitive, accessible and beautiful.' ],
    [ 'name' => 'Tom L.',     'co' => 'GrainFed', 'stars' => 5, 'text' => 'Bookings have doubled since launch. The site perfectly captures the warmth of our restaurant. Couldn\'t be happier.' ],
    [ 'name' => 'Rachel D.',  'co' => 'ZipFreight', 'stars' => 5, 'text' => 'Delivered on time, on budget, and the results speak for themselves. Our lead volume is up 35%. Ava is the real deal.' ],
];

/* ── packages ──────────────────────────────────────────── */
$wd_packages = [
    [
        'name'     => 'Starter',
        'price'    => '£1,200',
        'timeline' => '2 weeks',
        'featured' => false,
        'colour'   => '#7B5CF0',
        'items'    => [
            '5-page responsive WordPress site',
            'Mobile-first design',
            'Contact form integration',
            'Basic SEO setup',
            '30 days post-launch support',
        ],
    ],
    [
        'name'     => 'Growth',
        'price'    => '£3,500',
        'timeline' => '4–5 weeks',
        'featured' => true,
        'colour'   => '#0A0E1A',
        'items'    => [
            'Up to 15 pages + blog',
            'Custom Figma design system',
            'WooCommerce or Elementor Pro',
            'Core Web Vitals optimisation',
            'Analytics & conversion tracking',
            'Staff CMS training session',
            '90 days priority support',
        ],
    ],
    [
        'name'     => 'Enterprise',
        'price'    => 'From £7,500',
        'timeline' => '8–12 weeks',
        'featured' => false,
        'colour'   => '#00C5AE',
        'items'    => [
            'Unlimited pages & custom post types',
            'Headless CMS or bespoke WP theme',
            'API integrations (CRM, ERP, etc.)',
            'Full brand identity package',
            'Ongoing retainer options',
            'Dedicated project manager',
        ],
    ],
];

/* ── FAQ ─────────────────────────────────────────────────── */
$wd_faqs = [
    [ 'q' => 'Do you work with clients outside London?',
      'a' => 'Absolutely — I work fully remotely with clients across the UK and internationally. All discovery, reviews and sign-offs happen via video call and shared Figma links.' ],
    [ 'q' => 'Will my site be easy to update myself?',
      'a' => 'Yes. I build on WordPress with a user-friendly page builder so you can update text, images and blog posts without touching code. I provide video training too.' ],
    [ 'q' => 'Do you offer ongoing maintenance?',
      'a' => 'Yes — monthly care plans cover plugin updates, security monitoring, backups and a set number of design/content change hours each month.' ],
    [ 'q' => 'What information do you need to get started?',
      'a' => 'A brief covering your goals, target audience, brand guidelines (if any), pages needed, and any sites you like the look of. I'll guide you through a discovery form.' ],
    [ 'q' => 'Do you provide hosting?',
      'a' => 'I can set everything up on recommended managed WordPress hosts such as Kinsta or WP Engine, or work within your existing hosting environment.' ],
    [ 'q' => 'What is your payment structure?',
      'a' => '50% deposit on project kick-off, 25% on design sign-off, 25% on launch day. Enterprise projects may use milestone-based payment schedules.' ],
];

/* ── project types ─────────────────────────────────────── */
$wd_project_types = [
    'New website (5–10 pages)',
    'E-commerce store',
    'Landing page / funnel',
    'Website redesign / refresh',
    'Brand identity + web',
    'Ongoing retainer',
    'Other / not sure yet',
];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=DM+Mono:ital,wght@0,400;0,500;1,400&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════════
   WEB DESIGNER  –  --wd-* token namespace
═══════════════════════════════════════════════════════════ */
:root {
  --wd-midnight:      #0A0E1A;
  --wd-midnight-2:    #111827;
  --wd-violet:        #7B5CF0;
  --wd-violet-light:  #9B7EF8;
  --wd-violet-dark:   #5A3DD0;
  --wd-cyan:          #00F0D4;
  --wd-cyan-dark:     #00C5AE;
  --wd-white:         #F0F4FF;
  --wd-grey:          #8892A4;
  --wd-grey-light:    #C8D0E0;
  --wd-card-bg:       #141928;
  --wd-border:        rgba(123,92,240,0.2);
  --wd-font-head:     'Space Grotesk', sans-serif;
  --wd-font-mono:     'DM Mono', monospace;
  --wd-font-body:     'Inter', sans-serif;
  --wd-radius:        12px;
  --wd-transition:    0.32s ease;
}

*,*::before,*::after { box-sizing: border-box; margin: 0; padding: 0; }
.wd-page { font-family: var(--wd-font-body); color: var(--wd-white); background: var(--wd-midnight); overflow-x: hidden; }
.wd-page a { color: var(--wd-cyan); text-decoration: none; }

/* ── keyframes ── */
@keyframes wd-cursor-blink { 0%,100% { opacity: 1; } 50% { opacity: 0; } }
@keyframes wd-float {
  0%,100% { transform: translateY(0) rotate(0deg); opacity: var(--wd-fo, 0.25); }
  33%      { transform: translateY(-18px) rotate(3deg); }
  66%      { transform: translateY(8px) rotate(-2deg); }
}
@keyframes wd-glow-pulse {
  0%,100% { box-shadow: 0 0 20px rgba(123,92,240,0.4); }
  50%      { box-shadow: 0 0 50px rgba(123,92,240,0.9), 0 0 80px rgba(0,240,212,0.3); }
}
@keyframes wd-grid-scroll {
  from { background-position: 0 0; }
  to   { background-position: 0 60px; }
}
@keyframes wd-bar-grow { from { width: 0; } to { width: var(--wd-target-w, 90%); } }
@keyframes wd-slide-up { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
@keyframes wd-slide-right { from { opacity: 0; transform: translateX(-30px); } to { opacity: 1; transform: translateX(0); } }
@keyframes wd-fade-in { from { opacity: 0; } to { opacity: 1; } }
@keyframes wd-build {
  0%   { width: 0; }
  100% { width: 100%; }
}
@keyframes wd-blink-block {
  0%,100% { opacity: 1; } 50% { opacity: 0; }
}

/* ══ NAV ══════════════════════════════════════════════════ */
.wd-nav {
  position: fixed; top: 0; left: 0; width: 100%; z-index: 1000;
  background: rgba(10,14,26,0.9); backdrop-filter: blur(16px);
  border-bottom: 1px solid var(--wd-border);
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 48px; height: 68px;
}
.wd-nav__logo { font-family: var(--wd-font-head); font-size: 1.35rem; font-weight: 700; color: var(--wd-white); }
.wd-nav__logo span { color: var(--wd-violet); }
.wd-nav__logo em { font-family: var(--wd-font-mono); font-style: normal; color: var(--wd-cyan); font-size: 1.1rem; }
.wd-nav__links { display: flex; gap: 32px; list-style: none; }
.wd-nav__links a { color: var(--wd-grey-light); font-size: 0.88rem; font-weight: 500; letter-spacing: 0.04em; transition: color var(--wd-transition); }
.wd-nav__links a:hover { color: var(--wd-cyan); }
.wd-nav__cta { background: var(--wd-violet); color: #fff; padding: 10px 24px; border-radius: 8px; font-size: 0.88rem; font-weight: 600; transition: all var(--wd-transition); }
.wd-nav__cta:hover { background: var(--wd-violet-light); color: #fff; box-shadow: 0 0 20px rgba(123,92,240,0.5); }

/* ══ HERO ═════════════════════════════════════════════════ */
.wd-hero {
  min-height: 100vh; display: flex; align-items: center;
  background:
    radial-gradient(ellipse at 70% 40%, rgba(123,92,240,0.12) 0%, transparent 60%),
    radial-gradient(ellipse at 20% 80%, rgba(0,240,212,0.08) 0%, transparent 50%),
    var(--wd-midnight);
  position: relative; overflow: hidden; padding: 100px 48px 60px;
}
/* scrolling grid */
.wd-hero::before {
  content: ''; position: absolute; inset: 0;
  background-image:
    linear-gradient(rgba(123,92,240,0.06) 1px, transparent 1px),
    linear-gradient(90deg, rgba(123,92,240,0.06) 1px, transparent 1px);
  background-size: 60px 60px;
  animation: wd-grid-scroll 4s linear infinite;
  pointer-events: none;
}
.wd-hero__tokens { position: absolute; inset: 0; pointer-events: none; z-index: 1; }
.wd-token {
  position: absolute; font-family: var(--wd-font-mono); font-size: var(--wd-ts, 12px);
  color: var(--wd-cyan); opacity: var(--wd-fo, 0.2);
  animation: wd-float var(--wd-fd, 8s) var(--wd-fdelay, 0s) infinite ease-in-out;
  user-select: none; white-space: nowrap;
}
.wd-hero__inner { position: relative; z-index: 2; display: grid; grid-template-columns: 1fr 520px; gap: 60px; align-items: center; max-width: 1280px; margin: 0 auto; width: 100%; }

/* TEXT */
.wd-hero__text { animation: wd-slide-up 0.7s ease both; }
.wd-hero__badge { display: inline-flex; align-items: center; gap: 8px; background: rgba(123,92,240,0.15); border: 1px solid rgba(123,92,240,0.35); color: var(--wd-violet-light); padding: 6px 16px; border-radius: 6px; font-size: 0.75rem; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; font-family: var(--wd-font-mono); margin-bottom: 28px; }
.wd-hero__eyebrow { color: var(--wd-grey); font-size: 0.9rem; margin-bottom: 14px; font-family: var(--wd-font-mono); }
.wd-hero__title { font-family: var(--wd-font-head); font-size: clamp(2.6rem, 4.5vw, 4rem); font-weight: 700; line-height: 1.12; margin-bottom: 22px; letter-spacing: -0.02em; }
.wd-hero__title .wd-t-violet { color: var(--wd-violet-light); }
.wd-hero__title .wd-t-cyan   { color: var(--wd-cyan); }
.wd-hero__tagline { font-family: var(--wd-font-mono); font-size: 1rem; color: var(--wd-grey); margin-bottom: 32px; }
.wd-hero__tagline .wd-cursor { display: inline-block; width: 9px; height: 18px; background: var(--wd-cyan); vertical-align: middle; margin-left: 2px; animation: wd-blink-block 1s step-end infinite; }
.wd-hero__subtitle { font-size: 1.05rem; color: var(--wd-grey-light); line-height: 1.75; max-width: 500px; margin-bottom: 36px; font-weight: 300; }
.wd-hero__actions { display: flex; gap: 16px; flex-wrap: wrap; margin-bottom: 44px; }
.wd-btn-primary   { background: var(--wd-violet); color: #fff; padding: 16px 36px; border-radius: 10px; font-size: 0.97rem; font-weight: 600; transition: all var(--wd-transition); box-shadow: 0 0 24px rgba(123,92,240,0.35); font-family: var(--wd-font-head); }
.wd-btn-primary:hover { background: var(--wd-violet-light); color: #fff; transform: translateY(-2px); box-shadow: 0 0 40px rgba(123,92,240,0.6); }
.wd-btn-secondary { border: 1.5px solid rgba(0,240,212,0.4); color: var(--wd-cyan); padding: 14px 32px; border-radius: 10px; font-size: 0.97rem; font-weight: 500; transition: all var(--wd-transition); font-family: var(--wd-font-head); }
.wd-btn-secondary:hover { border-color: var(--wd-cyan); background: rgba(0,240,212,0.08); color: var(--wd-cyan); }
.wd-hero__trust { display: flex; gap: 24px; flex-wrap: wrap; }
.wd-trust-item { display: flex; align-items: center; gap: 8px; color: var(--wd-grey); font-size: 0.83rem; font-family: var(--wd-font-mono); }
.wd-trust-item::before { content: '✓'; color: var(--wd-cyan); font-weight: 700; }

/* BROWSER MOCKUP */
.wd-browser {
  width: 520px; background: #1A1E2E; border-radius: 14px;
  box-shadow: 0 0 0 1px rgba(123,92,240,0.3), 0 30px 80px rgba(0,0,0,0.6);
  overflow: hidden; animation: wd-fade-in 1s 0.3s ease both;
  animation: wd-glow-pulse 4s 1s infinite ease-in-out, wd-fade-in 1s 0.3s ease both;
}
.wd-browser__bar {
  background: #0E1220; padding: 12px 16px; display: flex; align-items: center; gap: 12px;
  border-bottom: 1px solid rgba(123,92,240,0.15);
}
.wd-browser__dots { display: flex; gap: 7px; }
.wd-browser__dot  { width: 11px; height: 11px; border-radius: 50%; }
.wd-browser__dot:nth-child(1) { background: #FF5F57; }
.wd-browser__dot:nth-child(2) { background: #FEBC2E; }
.wd-browser__dot:nth-child(3) { background: #28C840; }
.wd-browser__url  { flex: 1; background: rgba(255,255,255,0.05); border-radius: 6px; padding: 5px 12px; font-family: var(--wd-font-mono); font-size: 0.72rem; color: var(--wd-grey); }
.wd-browser__body { padding: 20px; display: flex; flex-direction: column; gap: 10px; min-height: 340px; }

/* wireframe rows */
.wd-wf-row { display: flex; gap: 8px; align-items: flex-start; }
.wd-wf-block {
  background: rgba(123,92,240,0.15); border: 1px solid rgba(123,92,240,0.25);
  border-radius: 4px; flex: 1; position: relative; overflow: hidden;
}
.wd-wf-block::after {
  content: ''; position: absolute; top: 0; left: -100%; width: 60%; height: 100%;
  background: linear-gradient(90deg, transparent, rgba(123,92,240,0.15), transparent);
  animation: wd-build var(--wd-build-dur, 2s) var(--wd-build-delay, 0s) ease forwards;
}
.wd-wf-hero { background: rgba(0,240,212,0.08); border: 1px solid rgba(0,240,212,0.2); }
.wd-wf-label { font-family: var(--wd-font-mono); font-size: 0.55rem; color: var(--wd-grey); text-align: center; padding: 4px; line-height: 1; }

/* ══ COUNTERS ══════════════════════════════════════════════ */
.wd-counters { background: var(--wd-midnight-2); padding: 60px 48px; border-top: 1px solid var(--wd-border); border-bottom: 1px solid var(--wd-border); }
.wd-counters__grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 2px; max-width: 960px; margin: 0 auto; }
.wd-counter-item { text-align: center; padding: 36px 20px; background: rgba(123,92,240,0.04); border-radius: 4px; transition: background var(--wd-transition); }
.wd-counter-item:hover { background: rgba(123,92,240,0.1); }
.wd-counter-number { font-family: var(--wd-font-head); font-size: 3rem; font-weight: 700; color: var(--wd-white); display: flex; align-items: baseline; justify-content: center; gap: 4px; }
.wd-counter-number span.wd-suffix { font-size: 1.6rem; color: var(--wd-violet-light); }
.wd-counter-label { color: var(--wd-grey); font-size: 0.82rem; margin-top: 6px; font-family: var(--wd-font-mono); letter-spacing: 0.06em; }

/* ══ SERVICES ══════════════════════════════════════════════ */
.wd-services { padding: 100px 48px; background: var(--wd-midnight); }
.wd-section-header { text-align: center; margin-bottom: 60px; }
.wd-eyebrow { font-family: var(--wd-font-mono); font-size: 0.8rem; color: var(--wd-cyan); letter-spacing: 0.12em; text-transform: uppercase; margin-bottom: 14px; }
.wd-section-title { font-family: var(--wd-font-head); font-size: clamp(1.8rem,3.5vw,2.8rem); color: var(--wd-white); margin-bottom: 14px; font-weight: 700; letter-spacing: -0.01em; }
.wd-section-desc { color: var(--wd-grey); font-size: 1rem; max-width: 580px; margin: 0 auto; line-height: 1.75; }
.wd-services__grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 20px; max-width: 1280px; margin: 0 auto; }
.wd-service-card {
  background: var(--wd-card-bg); border: 1px solid var(--wd-border); border-radius: var(--wd-radius);
  padding: 28px 22px; transition: all var(--wd-transition); position: relative; overflow: hidden;
}
.wd-service-card::before {
  content: ''; position: absolute; top: 0; left: 0; right: 0; height: 2px;
  background: linear-gradient(90deg, var(--wd-violet), var(--wd-cyan));
  transform: scaleX(0); transform-origin: left; transition: transform var(--wd-transition);
}
.wd-service-card:hover { border-color: rgba(123,92,240,0.45); transform: translateY(-5px); box-shadow: 0 12px 40px rgba(123,92,240,0.15); }
.wd-service-card:hover::before { transform: scaleX(1); }
.wd-service-icon { font-size: 1.8rem; margin-bottom: 14px; }
.wd-service-name { font-family: var(--wd-font-head); font-size: 1.05rem; color: var(--wd-white); margin-bottom: 8px; font-weight: 600; }
.wd-service-desc { color: var(--wd-grey); font-size: 0.85rem; line-height: 1.65; }

/* ══ SKILLS ════════════════════════════════════════════════ */
.wd-skills { padding: 80px 48px; background: var(--wd-midnight-2); }
.wd-skills__inner { max-width: 800px; margin: 0 auto; }
.wd-skill-bar { margin-bottom: 24px; }
.wd-skill-header { display: flex; justify-content: space-between; margin-bottom: 8px; }
.wd-skill-name { font-family: var(--wd-font-mono); font-size: 0.88rem; color: var(--wd-white); font-weight: 500; }
.wd-skill-pct  { font-family: var(--wd-font-mono); font-size: 0.82rem; color: var(--wd-violet-light); }
.wd-skill-track { background: rgba(123,92,240,0.12); border-radius: 4px; height: 8px; overflow: hidden; }
.wd-skill-fill {
  height: 100%; border-radius: 4px;
  background: linear-gradient(90deg, var(--wd-violet), var(--wd-cyan));
  width: 0; transition: width 1.2s cubic-bezier(0.4, 0, 0.2, 1);
}

/* ══ PROCESS ═══════════════════════════════════════════════ */
.wd-process { padding: 100px 48px; background: var(--wd-midnight); }
.wd-process__steps { display: grid; grid-template-columns: repeat(5,1fr); gap: 24px; max-width: 1300px; margin: 0 auto; position: relative; }
.wd-process__steps::before {
  content: ''; position: absolute; top: 36px; left: 60px; right: 60px; height: 1px;
  background: linear-gradient(90deg, var(--wd-violet), var(--wd-cyan), var(--wd-violet));
}
.wd-step { text-align: center; }
.wd-step-num {
  width: 72px; height: 72px; border-radius: 12px; background: var(--wd-card-bg);
  border: 1px solid var(--wd-border); color: var(--wd-violet-light);
  font-family: var(--wd-font-mono); font-size: 1.2rem; font-weight: 500;
  display: flex; align-items: center; justify-content: center; margin: 0 auto 18px;
  position: relative; z-index: 1; transition: all var(--wd-transition);
}
.wd-step:hover .wd-step-num { background: var(--wd-violet); border-color: var(--wd-violet); color: #fff; box-shadow: 0 0 24px rgba(123,92,240,0.5); }
.wd-step-title { font-family: var(--wd-font-head); font-size: 1rem; color: var(--wd-white); margin-bottom: 8px; font-weight: 600; }
.wd-step-desc  { color: var(--wd-grey); font-size: 0.82rem; line-height: 1.65; }

/* ══ PORTFOLIO ═════════════════════════════════════════════ */
.wd-portfolio { padding: 100px 48px; background: var(--wd-midnight-2); }
.wd-portfolio__grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 20px; max-width: 1200px; margin: 0 auto; }
.wd-portfolio-card {
  border-radius: var(--wd-radius); overflow: hidden; background: var(--wd-card-bg);
  border: 1px solid var(--wd-border); cursor: pointer;
  transition: all var(--wd-transition); position: relative;
}
.wd-portfolio-card:hover { transform: translateY(-6px); box-shadow: 0 16px 50px rgba(0,0,0,0.5); border-color: rgba(123,92,240,0.45); }
.wd-portfolio-thumb { height: 180px; display: flex; align-items: center; justify-content: center; font-size: 3rem; position: relative; overflow: hidden; }
.wd-portfolio-thumb::after { content: 'View Project'; position: absolute; inset: 0; background: rgba(10,14,26,0.8); display: flex; align-items: center; justify-content: center; font-family: var(--wd-font-mono); font-size: 0.85rem; color: var(--wd-cyan); opacity: 0; transition: opacity var(--wd-transition); }
.wd-portfolio-card:hover .wd-portfolio-thumb::after { opacity: 1; }
.wd-portfolio-info { padding: 20px; }
.wd-portfolio-title { font-family: var(--wd-font-head); font-size: 1.05rem; font-weight: 600; color: var(--wd-white); margin-bottom: 4px; }
.wd-portfolio-type  { font-family: var(--wd-font-mono); font-size: 0.75rem; color: var(--wd-violet-light); }

/* ══ PACKAGES ══════════════════════════════════════════════ */
.wd-packages { padding: 100px 48px; background: var(--wd-midnight); }
.wd-packages__grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; max-width: 1100px; margin: 0 auto; align-items: start; }
.wd-package-card { border-radius: 16px; overflow: hidden; border: 1px solid var(--wd-border); background: var(--wd-card-bg); transition: transform var(--wd-transition); }
.wd-package-card:hover { transform: translateY(-6px); }
.wd-package-card--featured { border-color: rgba(123,92,240,0.6); box-shadow: 0 0 40px rgba(123,92,240,0.2); transform: scale(1.04); }
.wd-package-card--featured:hover { transform: scale(1.04) translateY(-6px); }
.wd-package-header { padding: 32px 28px; background: var(--mt-card-colour, #111827); border-bottom: 1px solid var(--wd-border); position: relative; overflow: hidden; }
.wd-package-header::before { content: ''; position: absolute; top: -40px; right: -40px; width: 140px; height: 140px; border-radius: 50%; background: rgba(123,92,240,0.12); }
.wd-package-badge { display: inline-block; background: var(--wd-violet); color: #fff; padding: 4px 12px; border-radius: 4px; font-size: 0.68rem; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase; font-family: var(--wd-font-mono); margin-bottom: 16px; }
.wd-package-name     { font-family: var(--wd-font-head); font-size: 1.5rem; font-weight: 700; color: var(--wd-white); margin-bottom: 8px; }
.wd-package-price    { font-family: var(--wd-font-head); font-size: 2.4rem; font-weight: 700; color: var(--wd-white); }
.wd-package-timeline { font-family: var(--wd-font-mono); font-size: 0.78rem; color: var(--wd-grey); margin-top: 6px; }
.wd-package-body { padding: 24px 28px; }
.wd-package-features { list-style: none; margin-bottom: 24px; }
.wd-package-features li { padding: 9px 0; border-bottom: 1px solid rgba(123,92,240,0.1); font-size: 0.88rem; color: var(--wd-grey-light); display: flex; gap: 10px; }
.wd-package-features li::before { content: '▸'; color: var(--wd-violet-light); flex-shrink: 0; }
.wd-package-features li:last-child { border-bottom: none; }
.wd-package-btn {
  display: block; width: 100%; padding: 14px; border-radius: 8px; text-align: center;
  font-family: var(--wd-font-head); font-weight: 600; font-size: 0.9rem;
  border: 1.5px solid var(--wd-violet); color: var(--wd-violet-light);
  background: transparent; cursor: pointer; transition: all var(--wd-transition);
}
.wd-package-btn:hover,
.wd-package-card--featured .wd-package-btn { background: var(--wd-violet); color: #fff; }

/* ══ PROFILE ═══════════════════════════════════════════════ */
.wd-profile { padding: 100px 48px; background: var(--wd-midnight-2); }
.wd-profile__inner { max-width: 1100px; margin: 0 auto; display: grid; grid-template-columns: 300px 1fr; gap: 80px; align-items: center; }
.wd-profile__avatar {
  width: 220px; height: 280px; border-radius: 14px; margin: 0 auto 24px;
  background: linear-gradient(145deg, #1A1E30 0%, #2A2040 100%);
  border: 1px solid var(--wd-border); position: relative; overflow: hidden;
  box-shadow: 0 0 40px rgba(123,92,240,0.2);
}
/* monitor glow on face */
.wd-profile__avatar::before {
  content: ''; position: absolute; top: 20%; left: 50%; transform: translateX(-50%);
  width: 90px; height: 96px; border-radius: 50%;
  background: linear-gradient(145deg, #F5DEB3 0%, #E8C898 100%);
}
/* hair */
.wd-profile__avatar-hair {
  position: absolute; top: 15%; left: 50%; transform: translateX(-50%);
  width: 96px; height: 56px; border-radius: 50% 50% 0 0; background: #3A2A60;
}
/* torso / hoodie */
.wd-profile__avatar-body {
  position: absolute; bottom: 0; left: 50%; transform: translateX(-50%);
  width: 160px; height: 140px; border-radius: 20px 20px 0 0;
  background: linear-gradient(160deg, var(--wd-violet-dark) 0%, #3A1F80 100%);
}
/* laptop glow in hands */
.wd-profile__avatar-laptop {
  position: absolute; bottom: 20px; left: 50%; transform: translateX(-50%);
  width: 100px; height: 60px; background: #0E1220; border-radius: 6px;
  border: 1px solid rgba(123,92,240,0.5); overflow: hidden;
}
.wd-profile__avatar-laptop::before {
  content: ''; position: absolute; inset: 6px;
  background: linear-gradient(135deg, rgba(123,92,240,0.3), rgba(0,240,212,0.2));
  border-radius: 3px;
}
.wd-profile__avatar-laptop::after {
  content: ''; position: absolute; bottom: -14px; left: 50%; transform: translateX(-50%);
  width: 120px; height: 8px; background: #0E1220; border-radius: 0 0 4px 4px;
  border: 1px solid rgba(123,92,240,0.3);
}
/* monitor glow on face */
.wd-profile__avatar-glow {
  position: absolute; top: 24%; left: 50%; transform: translateX(-50%);
  width: 120px; height: 80px; border-radius: 50%;
  background: rgba(0,240,212,0.06); pointer-events: none;
}
.wd-profile__card {
  background: var(--wd-card-bg); border: 1px solid var(--wd-border); border-radius: 12px;
  padding: 20px 24px; text-align: center;
}
.wd-profile__card-name  { font-family: var(--wd-font-head); font-size: 1.25rem; font-weight: 700; color: var(--wd-white); margin-bottom: 4px; }
.wd-profile__card-title { font-family: var(--wd-font-mono); font-size: 0.72rem; color: var(--wd-violet-light); }
.wd-profile__content h2 { font-family: var(--wd-font-head); font-size: 2.2rem; font-weight: 700; color: var(--wd-white); margin-bottom: 18px; letter-spacing: -0.01em; }
.wd-profile__content p { color: var(--wd-grey-light); line-height: 1.8; margin-bottom: 14px; font-size: 0.96rem; font-weight: 300; }
.wd-profile__tools { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 24px; }
.wd-tool-badge { background: rgba(123,92,240,0.12); border: 1px solid rgba(123,92,240,0.25); color: var(--wd-violet-light); padding: 6px 14px; border-radius: 6px; font-size: 0.8rem; font-family: var(--wd-font-mono); }

/* ══ TESTIMONIALS ══════════════════════════════════════════ */
.wd-testimonials { padding: 100px 48px; background: var(--wd-midnight); }
.wd-testimonials__grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 20px; max-width: 1200px; margin: 0 auto; }
.wd-testimonial-card {
  background: var(--wd-card-bg); border: 1px solid var(--wd-border); border-radius: var(--wd-radius);
  padding: 28px; transition: all var(--wd-transition);
}
.wd-testimonial-card:hover { border-color: rgba(123,92,240,0.45); transform: translateY(-4px); }
.wd-stars { color: var(--wd-violet-light); font-size: 0.9rem; margin-bottom: 14px; letter-spacing: 2px; }
.wd-testimonial-text { color: var(--wd-grey-light); font-size: 0.9rem; line-height: 1.75; font-style: italic; margin-bottom: 18px; }
.wd-testimonial-author { font-family: var(--wd-font-mono); font-size: 0.78rem; }
.wd-testimonial-name { color: var(--wd-white); font-weight: 500; }
.wd-testimonial-co   { color: var(--wd-violet-light); }

/* ══ FAQ ═══════════════════════════════════════════════════ */
.wd-faq { padding: 100px 48px; background: var(--wd-midnight-2); }
.wd-faq__list { max-width: 760px; margin: 0 auto; }
.wd-faq-item { border-bottom: 1px solid var(--wd-border); }
.wd-faq-q {
  width: 100%; text-align: left; background: none; border: none; cursor: pointer;
  padding: 20px 0; display: flex; justify-content: space-between; align-items: center;
  font-family: var(--wd-font-head); font-size: 1rem; color: var(--wd-white);
  font-weight: 600; gap: 16px;
}
.wd-faq-q svg { flex-shrink: 0; color: var(--wd-violet-light); transition: transform 0.3s; }
.wd-faq-item.open .wd-faq-q svg { transform: rotate(45deg); }
.wd-faq-a { max-height: 0; overflow: hidden; transition: max-height 0.4s ease; }
.wd-faq-a-inner { padding: 0 0 18px; color: var(--wd-grey); line-height: 1.8; font-size: 0.92rem; }
.wd-faq-item.open .wd-faq-a { max-height: 250px; }

/* ══ CONTACT FORM ══════════════════════════════════════════ */
.wd-contact { padding: 100px 48px; background: var(--wd-midnight); position: relative; }
.wd-contact::before {
  content: ''; position: absolute; top: 0; left: 50%; transform: translateX(-50%);
  width: 600px; height: 600px; border-radius: 50%;
  background: radial-gradient(circle, rgba(123,92,240,0.08) 0%, transparent 70%);
  pointer-events: none;
}
.wd-contact__inner { max-width: 820px; margin: 0 auto; position: relative; }
.wd-contact-form {
  background: var(--wd-card-bg); border: 1px solid var(--wd-border);
  border-radius: 20px; padding: 48px; margin-top: 48px;
}
.wd-form-grid  { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
.wd-form-full  { grid-column: 1 / -1; }
.wd-form-group { display: flex; flex-direction: column; gap: 8px; }
.wd-form-label { font-family: var(--wd-font-mono); color: var(--wd-grey); font-size: 0.75rem; letter-spacing: 0.08em; text-transform: uppercase; }
.wd-form-input, .wd-form-select, .wd-form-textarea {
  background: rgba(255,255,255,0.04); border: 1px solid var(--wd-border);
  border-radius: 8px; padding: 13px 16px; color: var(--wd-white);
  font-family: var(--wd-font-body); font-size: 0.94rem;
  transition: border-color var(--wd-transition); width: 100%;
}
.wd-form-input::placeholder, .wd-form-textarea::placeholder { color: var(--wd-grey); }
.wd-form-input:focus, .wd-form-select:focus, .wd-form-textarea:focus { outline: none; border-color: var(--wd-violet); }
.wd-form-select option { background: var(--wd-midnight-2); }
.wd-form-textarea { resize: vertical; min-height: 110px; }
.wd-form-privacy { color: var(--wd-grey); font-size: 0.76rem; line-height: 1.6; }
.wd-form-privacy a { color: var(--wd-violet-light); }
.wd-form-submit {
  background: linear-gradient(135deg, var(--wd-violet) 0%, var(--wd-violet-dark) 100%);
  color: #fff; border: none; padding: 18px 56px; border-radius: 10px;
  font-family: var(--wd-font-head); font-size: 1rem; font-weight: 700;
  cursor: pointer; transition: all var(--wd-transition);
  box-shadow: 0 0 24px rgba(123,92,240,0.4);
}
.wd-form-submit:hover { transform: translateY(-2px); box-shadow: 0 0 40px rgba(123,92,240,0.6); }
.wd-form-message { padding: 14px; border-radius: 8px; margin-bottom: 20px; font-size: 0.88rem; display: none; font-family: var(--wd-font-mono); }
.wd-form-message.success { background: rgba(0,240,212,0.1); border: 1px solid var(--wd-cyan-dark); color: var(--wd-cyan); display: block; }
.wd-form-message.error   { background: rgba(255,95,87,0.1); border: 1px solid #FF5F57; color: #FF8C86; display: block; }

/* ══ FOOTER ════════════════════════════════════════════════ */
.wd-footer { background: var(--wd-midnight-2); border-top: 1px solid var(--wd-border); padding: 28px 48px; text-align: center; color: var(--wd-grey); font-size: 0.8rem; font-family: var(--wd-font-mono); line-height: 1.9; }
.wd-footer a { color: var(--wd-violet-light); }

/* ══ RESPONSIVE ════════════════════════════════════════════ */
@media (max-width: 1100px) {
  .wd-services__grid { grid-template-columns: repeat(2,1fr); }
  .wd-hero__inner { grid-template-columns: 1fr; }
  .wd-browser { display: none; }
  .wd-profile__inner { grid-template-columns: 1fr; text-align: center; }
  .wd-process__steps { grid-template-columns: repeat(3,1fr); }
}
@media (max-width: 768px) {
  .wd-nav__links { display: none; }
  .wd-counters__grid { grid-template-columns: repeat(2,1fr); }
  .wd-packages__grid, .wd-testimonials__grid, .wd-portfolio__grid { grid-template-columns: 1fr; }
  .wd-package-card--featured { transform: none; }
  .wd-process__steps { grid-template-columns: repeat(2,1fr); }
  .wd-form-grid { grid-template-columns: 1fr; }
  .wd-services__grid { grid-template-columns: 1fr; }
}
</style>
<?php get_header(); ?>
<div class="wd-page">
>
<?php wp_body_open(); ?>

<!-- NAV -->
<nav class="wd-nav" role="navigation" aria-label="Main navigation">
  <div class="wd-nav__logo">ava<span>.</span><em>design</em></div>
  <ul class="wd-nav__links">
    <li><a href="#services">Services</a></li>
    <li><a href="#portfolio">Work</a></li>
    <li><a href="#packages">Pricing</a></li>
    <li><a href="#about">About</a></li>
    <li><a href="#contact">Contact</a></li>
  </ul>
  <a href="#contact" class="wd-nav__cta">Start a Project</a>
</nav>

<!-- HERO -->
<section class="wd-hero" aria-label="Hero">
  <div class="wd-hero__tokens" aria-hidden="true">
    <?php foreach ( $wd_floaters as $fl ) : ?>
    <div class="wd-token" style="
      left:<?php echo $fl['left']; ?>%;
      top:<?php echo $fl['top']; ?>%;
      --wd-fd:<?php echo $fl['duration']; ?>s;
      --wd-fdelay:<?php echo $fl['delay']; ?>s;
      --wd-ts:<?php echo $fl['size']; ?>px;
      --wd-fo:<?php echo $fl['opacity']; ?>;
    "><?php echo esc_html( $fl['token'] ); ?></div>
    <?php endforeach; ?>
  </div>

  <div class="wd-hero__inner">
    <!-- TEXT -->
    <div class="wd-hero__text">
      <div class="wd-hero__badge">// <?php echo esc_html( $mt_location ?? $wd_location ); ?> · Available Now</div>
      <p class="wd-hero__eyebrow">/* freelance web designer &amp; developer */</p>
      <h1 class="wd-hero__title">
        Design That<br>
        <span class="wd-t-violet">Converts.</span> Code That<br>
        <span class="wd-t-cyan">Performs.</span>
      </h1>
      <p class="wd-hero__tagline">
        <span id="wd-typed-text">Building your next project…</span>
        <span class="wd-cursor" aria-hidden="true"></span>
      </p>
      <p class="wd-hero__subtitle">
        <?php echo $wd_years; ?> years crafting fast, beautiful websites for ambitious brands.
        From wireframe to launch — strategy, design and development under one roof.
      </p>
      <div class="wd-hero__actions">
        <a href="#contact" class="wd-btn-primary">Start Your Project →</a>
        <a href="#portfolio" class="wd-btn-secondary">View My Work</a>
      </div>
      <div class="wd-hero__trust">
        <span class="wd-trust-item">WordPress Expert</span>
        <span class="wd-trust-item">Figma Certified</span>
        <span class="wd-trust-item">Core Web Vitals</span>
        <span class="wd-trust-item">On-Time Delivery</span>
      </div>
    </div>

    <!-- BROWSER MOCKUP -->
    <div class="wd-browser" aria-hidden="true">
      <div class="wd-browser__bar">
        <div class="wd-browser__dots">
          <div class="wd-browser__dot"></div>
          <div class="wd-browser__dot"></div>
          <div class="wd-browser__dot"></div>
        </div>
        <div class="wd-browser__url">avathornton.design/new-project</div>
      </div>
      <div class="wd-browser__body">
        <?php foreach ( $wd_wireframe_rows as $ri => $row ) :
          $delay_base = $ri * 0.4;
        ?>
        <div class="wd-wf-row" style="height:<?php echo $row['h']; ?>px;">
          <?php if ( empty( $row['blocks'] ) ) : ?>
            <div class="wd-wf-block wd-wf-hero" style="--wd-build-dur:1.4s;--wd-build-delay:<?php echo $delay_base; ?>s;">
              <div class="wd-wf-label"><?php echo esc_html( strtoupper($row['type']) ); ?></div>
            </div>
          <?php else : ?>
            <?php foreach ( $row['blocks'] as $bi => $bw ) :
              if ( $bw === 0 ) { echo '<div style="flex:1"></div>'; continue; }
              $bd = $delay_base + $bi * 0.15;
            ?>
            <div class="wd-wf-block" style="flex:<?php echo $bw; ?>;--wd-build-dur:1s;--wd-build-delay:<?php echo $bd; ?>s;"></div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- COUNTERS -->
<section class="wd-counters" aria-label="Statistics">
  <div class="wd-counters__grid">
    <div class="wd-counter-item">
      <div class="wd-counter-number">
        <span class="wd-count-val" data-target="<?php echo $wd_years; ?>"><?php echo $wd_years; ?></span>
        <span class="wd-suffix">yrs</span>
      </div>
      <div class="wd-counter-label">// experience</div>
    </div>
    <div class="wd-counter-item">
      <div class="wd-counter-number">
        <span class="wd-count-val" data-target="180">180</span>
        <span class="wd-suffix">+</span>
      </div>
      <div class="wd-counter-label">// projects delivered</div>
    </div>
    <div class="wd-counter-item">
      <div class="wd-counter-number">
        <span class="wd-count-val" data-target="4" data-float="1">4.9</span>
        <span class="wd-suffix">★</span>
      </div>
      <div class="wd-counter-label">// client rating</div>
    </div>
    <div class="wd-counter-item">
      <div class="wd-counter-number">
        <span class="wd-count-val" data-target="98">98</span>
        <span class="wd-suffix">%</span>
      </div>
      <div class="wd-counter-label">// on-time delivery</div>
    </div>
  </div>
</section>

<!-- SERVICES -->
<section class="wd-services" id="services" aria-label="Services">
  <div class="wd-section-header">
    <p class="wd-eyebrow">// what I do</p>
    <h2 class="wd-section-title">Services</h2>
    <p class="wd-section-desc">End-to-end digital design and development — everything you need to build a website that actually works.</p>
  </div>
  <div class="wd-services__grid">
    <?php foreach ( $wd_services as $svc ) : ?>
    <div class="wd-service-card">
      <div class="wd-service-icon" aria-hidden="true"><?php echo $svc['icon']; ?></div>
      <h3 class="wd-service-name"><?php echo esc_html( $svc['name'] ); ?></h3>
      <p class="wd-service-desc"><?php echo esc_html( $svc['desc'] ); ?></p>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- SKILLS -->
<section class="wd-skills" aria-label="Technical skills">
  <div class="wd-section-header">
    <p class="wd-eyebrow">// tech stack</p>
    <h2 class="wd-section-title">Skills &amp; Tools</h2>
    <p class="wd-section-desc">Specialist depth across the full design and front-end stack.</p>
  </div>
  <div class="wd-skills__inner">
    <?php foreach ( $wd_skills as $sk ) : ?>
    <div class="wd-skill-bar">
      <div class="wd-skill-header">
        <span class="wd-skill-name"><?php echo esc_html( $sk['name'] ); ?></span>
        <span class="wd-skill-pct"><?php echo (int) $sk['pct']; ?>%</span>
      </div>
      <div class="wd-skill-track">
        <div class="wd-skill-fill" data-width="<?php echo (int) $sk['pct']; ?>"></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- PROCESS -->
<section class="wd-process" aria-label="Process">
  <div class="wd-section-header">
    <p class="wd-eyebrow">// how we work</p>
    <h2 class="wd-section-title">The Process</h2>
    <p class="wd-section-desc">A proven, collaborative workflow that takes you from blank page to launched site with zero stress.</p>
  </div>
  <div class="wd-process__steps">
    <?php foreach ( $wd_steps as $step ) : ?>
    <div class="wd-step">
      <div class="wd-step-num" aria-hidden="true"><?php echo esc_html( $step['num'] ); ?></div>
      <h3 class="wd-step-title"><?php echo esc_html( $step['title'] ); ?></h3>
      <p class="wd-step-desc"><?php echo esc_html( $step['desc'] ); ?></p>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- PORTFOLIO -->
<section class="wd-portfolio" id="portfolio" aria-label="Portfolio">
  <div class="wd-section-header">
    <p class="wd-eyebrow">// selected work</p>
    <h2 class="wd-section-title">Recent Projects</h2>
    <p class="wd-section-desc">A sample of websites and digital experiences delivered for clients across the UK.</p>
  </div>
  <div class="wd-portfolio__grid">
    <?php foreach ( $wd_portfolio as $pi => $proj ) : ?>
    <div class="wd-portfolio-card">
      <div class="wd-portfolio-thumb" style="background:<?php echo esc_attr($proj['colour']); ?>20;">
        <span style="font-size:2.4rem;opacity:0.5;"><?php $icons = ['🌸','📊','⚖️','🍖','🏥','🚚']; echo $icons[$pi % count($icons)]; ?></span>
      </div>
      <div class="wd-portfolio-info">
        <div class="wd-portfolio-title"><?php echo esc_html( $proj['title'] ); ?></div>
        <div class="wd-portfolio-type"><?php echo esc_html( $proj['type'] ); ?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- PACKAGES -->
<section class="wd-packages" id="packages" aria-label="Pricing packages">
  <div class="wd-section-header">
    <p class="wd-eyebrow">// investment</p>
    <h2 class="wd-section-title">Packages &amp; Pricing</h2>
    <p class="wd-section-desc">Transparent pricing with no hidden fees. Every project is scoped in detail before work begins.</p>
  </div>
  <div class="wd-packages__grid">
    <?php foreach ( $wd_packages as $pkg ) :
      $is_feat = $pkg['featured'];
    ?>
    <div class="wd-package-card<?php echo $is_feat ? ' wd-package-card--featured' : ''; ?>">
      <div class="wd-package-header">
        <?php if ($is_feat) : ?>
        <div class="wd-package-badge">Most Popular</div>
        <?php endif; ?>
        <div class="wd-package-name"><?php echo esc_html( $pkg['name'] ); ?></div>
        <div class="wd-package-price"><?php echo esc_html( $pkg['price'] ); ?></div>
        <div class="wd-package-timeline"><?php echo esc_html( $pkg['timeline'] ); ?></div>
      </div>
      <div class="wd-package-body">
        <ul class="wd-package-features">
          <?php foreach ( $pkg['items'] as $item ) : ?>
          <li><?php echo esc_html( $item ); ?></li>
          <?php endforeach; ?>
        </ul>
        <a href="#contact" class="wd-package-btn">Get a Quote</a>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- PROFILE -->
<section class="wd-profile" id="about" aria-label="About">
  <div class="wd-profile__inner">
    <div>
      <div class="wd-profile__avatar" aria-label="Portrait illustration of <?php echo esc_attr($wd_designer); ?>">
        <div class="wd-profile__avatar-hair" aria-hidden="true"></div>
        <div class="wd-profile__avatar-body" aria-hidden="true"></div>
        <div class="wd-profile__avatar-laptop" aria-hidden="true"></div>
        <div class="wd-profile__avatar-glow" aria-hidden="true"></div>
      </div>
      <div class="wd-profile__card">
        <div class="wd-profile__card-name"><?php echo esc_html($wd_designer); ?></div>
        <div class="wd-profile__card-title"><?php echo esc_html($wd_title); ?></div>
      </div>
    </div>
    <div class="wd-profile__content">
      <h2><?php echo $wd_years; ?> Years Designing for the Web</h2>
      <p>
        I'm a London-based web designer and front-end developer with <?php echo $wd_years; ?> years of experience
        helping startups, SMEs and established brands build digital presences that genuinely perform.
        I combine strategic UX thinking with hands-on pixel craftsmanship — I both design and build everything I deliver.
      </p>
      <p>
        My background spans agency, in-house and freelance — giving me fluency with tight deadlines,
        complex stakeholder requirements and the scrappy pace of early-stage startups. I've worked
        across fintech, healthcare, hospitality, legal and e-commerce sectors.
      </p>
      <p>
        I care deeply about performance, accessibility and clean code. Every site I build scores
        90+ on Google PageSpeed Insights and is tested against WCAG 2.1 AA standards.
      </p>
      <div class="wd-profile__tools">
        <span class="wd-tool-badge">Figma</span>
        <span class="wd-tool-badge">WordPress</span>
        <span class="wd-tool-badge">Elementor Pro</span>
        <span class="wd-tool-badge">WooCommerce</span>
        <span class="wd-tool-badge">React</span>
        <span class="wd-tool-badge">Tailwind CSS</span>
        <span class="wd-tool-badge">Next.js</span>
        <span class="wd-tool-badge">Adobe XD</span>
        <span class="wd-tool-badge">Webflow</span>
        <span class="wd-tool-badge">Shopify</span>
      </div>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="wd-testimonials" id="testimonials" aria-label="Testimonials">
  <div class="wd-section-header">
    <p class="wd-eyebrow">// client feedback</p>
    <h2 class="wd-section-title">What Clients Say</h2>
    <p class="wd-section-desc">Results speak louder than portfolios. Here's what clients say after working together.</p>
  </div>
  <div class="wd-testimonials__grid">
    <?php foreach ( $wd_testimonials as $t ) : ?>
    <div class="wd-testimonial-card">
      <div class="wd-stars" aria-label="<?php echo (int) $t['stars']; ?> stars">
        <?php echo str_repeat('★', (int)$t['stars']); ?>
      </div>
      <p class="wd-testimonial-text">"<?php echo esc_html($t['text']); ?>"</p>
      <div class="wd-testimonial-author">
        <span class="wd-testimonial-name"><?php echo esc_html($t['name']); ?></span>
        <span class="wd-testimonial-co"> · <?php echo esc_html($t['co']); ?></span>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- FAQ -->
<section class="wd-faq" id="faq" aria-label="FAQ">
  <div class="wd-section-header">
    <p class="wd-eyebrow">// questions</p>
    <h2 class="wd-section-title">Frequently Asked</h2>
  </div>
  <div class="wd-faq__list" role="list">
    <?php foreach ( $wd_faqs as $fi => $faq ) : ?>
    <div class="wd-faq-item" role="listitem">
      <button class="wd-faq-q" aria-expanded="false" aria-controls="wd-faq-a-<?php echo $fi; ?>">
        <?php echo esc_html($faq['q']); ?>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
      </button>
      <div class="wd-faq-a" id="wd-faq-a-<?php echo $fi; ?>" role="region">
        <div class="wd-faq-a-inner"><?php echo esc_html($faq['a']); ?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- CONTACT -->
<section class="wd-contact" id="contact" aria-label="Contact">
  <div class="wd-contact__inner">
    <div class="wd-section-header">
      <p class="wd-eyebrow">// let's build something</p>
      <h2 class="wd-section-title">Start a Project</h2>
      <p class="wd-section-desc">Tell me about your project and I'll come back with a proposal within 48 hours.</p>
    </div>
    <div class="wd-contact-form">
      <div class="wd-form-message" id="wd-form-msg" role="alert" aria-live="polite"></div>
      <form id="wd-contact-form" novalidate>
        <?php wp_nonce_field('tf_wd_contact', 'tf_wd_nonce'); ?>
        <div class="wd-form-grid">
          <div class="wd-form-group">
            <label class="wd-form-label" for="wd-name">Name *</label>
            <input class="wd-form-input" type="text" id="wd-name" name="wd_name" placeholder="Your name" required autocomplete="name">
          </div>
          <div class="wd-form-group">
            <label class="wd-form-label" for="wd-email">Email *</label>
            <input class="wd-form-input" type="email" id="wd-email" name="wd_email" placeholder="you@company.com" required autocomplete="email">
          </div>
          <div class="wd-form-group">
            <label class="wd-form-label" for="wd-company">Company / Website</label>
            <input class="wd-form-input" type="text" id="wd-company" name="wd_company" placeholder="yourwebsite.com">
          </div>
          <div class="wd-form-group">
            <label class="wd-form-label" for="wd-budget">Budget Range</label>
            <select class="wd-form-select" id="wd-budget" name="wd_budget">
              <option value="">Select budget…</option>
              <option value="sub1k">Under £1,000</option>
              <option value="1k-3k">£1,000 – £3,000</option>
              <option value="3k-6k">£3,000 – £6,000</option>
              <option value="6k-15k">£6,000 – £15,000</option>
              <option value="15kplus">£15,000+</option>
            </select>
          </div>
          <div class="wd-form-group">
            <label class="wd-form-label" for="wd-type">Project Type *</label>
            <select class="wd-form-select" id="wd-type" name="wd_type" required>
              <option value="">Select type…</option>
              <?php foreach ($wd_project_types as $pt) : ?>
              <option value="<?php echo esc_attr($pt); ?>"><?php echo esc_html($pt); ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="wd-form-group">
            <label class="wd-form-label" for="wd-timeline">Timeline</label>
            <select class="wd-form-select" id="wd-timeline" name="wd_timeline">
              <option value="">No rush…</option>
              <option value="asap">ASAP</option>
              <option value="1month">Within 1 month</option>
              <option value="3months">Within 3 months</option>
              <option value="flexible">Flexible</option>
            </select>
          </div>
          <div class="wd-form-group wd-form-full">
            <label class="wd-form-label" for="wd-brief">Project Brief *</label>
            <textarea class="wd-form-textarea" id="wd-brief" name="wd_brief" placeholder="Tell me about your business, what you need, any sites you love the look of, and your goals…" rows="5" required></textarea>
          </div>
          <div class="wd-form-group wd-form-full">
            <p class="wd-form-privacy">By submitting this form you agree to our <a href="/privacy-policy">Privacy Policy</a>. I respond to all enquiries within 48 hours.</p>
          </div>
          <div class="wd-form-full" style="text-align:center;">
            <button type="submit" class="wd-form-submit">Send Brief →</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</section>

<!-- FOOTER -->
<footer class="wd-footer" role="contentinfo">
  <p>© <?php echo date('Y'); ?> <?php echo esc_html($wd_designer); ?> — <?php echo esc_html($wd_title); ?></p>
  <p><?php echo esc_html($wd_location); ?> · <a href="mailto:<?php echo esc_attr($wd_email); ?>"><?php echo esc_html($wd_email); ?></a> · <a href="/privacy-policy">Privacy Policy</a></p>
</footer>

<script>
(function(){
  'use strict';

  /* ── typing effect in hero ────────────────────────────── */
  const typedEl = document.getElementById('wd-typed-text');
  const phrases = [
    'Building your next project…',
    'Designing your landing page…',
    'Optimising Core Web Vitals…',
    'Crafting your brand identity…',
    'Writing clean, semantic HTML…',
    'Launching your e-commerce store…',
  ];
  let phraseIdx = 0, charIdx = 0, deleting = false;

  function typeTick() {
    if (!typedEl) return;
    const phrase = phrases[phraseIdx];
    if (!deleting) {
      typedEl.textContent = phrase.slice(0, ++charIdx);
      if (charIdx === phrase.length) { deleting = true; setTimeout(typeTick, 2200); return; }
    } else {
      typedEl.textContent = phrase.slice(0, --charIdx);
      if (charIdx === 0) { deleting = false; phraseIdx = (phraseIdx + 1) % phrases.length; }
    }
    setTimeout(typeTick, deleting ? 40 : 68);
  }
  typeTick();

  /* ── skill bars ───────────────────────────────────────── */
  const skillObs = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const fill = entry.target;
        const w = fill.dataset.width;
        fill.style.width = w + '%';
        skillObs.unobserve(fill);
      }
    });
  }, { threshold: 0.3 });
  document.querySelectorAll('.wd-skill-fill').forEach(el => skillObs.observe(el));

  /* ── animated counters ─────────────────────────────────── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  const counterObs = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const isFloat = el.dataset.float === '1';
      const endVal  = isFloat ? 4.9 : parseFloat(el.dataset.target);
      if (isNaN(endVal)) return;
      const dur = 1800; let start = null;
      const tick = ts => {
        if (!start) start = ts;
        const p = Math.min((ts - start) / dur, 1);
        const v = endVal * easeOut(p);
        el.textContent = isFloat ? v.toFixed(1) : Math.round(v).toLocaleString();
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      counterObs.unobserve(el);
    });
  }, { threshold: 0.3 });
  document.querySelectorAll('.wd-count-val').forEach(el => counterObs.observe(el));

  /* ── FAQ accordion ─────────────────────────────────────── */
  document.querySelectorAll('.wd-faq-q').forEach(btn => {
    btn.addEventListener('click', () => {
      const item = btn.closest('.wd-faq-item');
      const open = item.classList.contains('open');
      document.querySelectorAll('.wd-faq-item.open').forEach(i => {
        i.classList.remove('open');
        i.querySelector('.wd-faq-q').setAttribute('aria-expanded','false');
      });
      if (!open) { item.classList.add('open'); btn.setAttribute('aria-expanded','true'); }
    });
  });

  /* ── contact form ──────────────────────────────────────── */
  const form = document.getElementById('wd-contact-form');
  const msg  = document.getElementById('wd-form-msg');

  if (form && msg) {
    form.addEventListener('submit', e => {
      e.preventDefault();
      msg.className = 'wd-form-message';
      const name  = document.getElementById('wd-name').value.trim();
      const email = document.getElementById('wd-email').value.trim();
      const type  = document.getElementById('wd-type').value;
      const brief = document.getElementById('wd-brief').value.trim();

      if (!name || !email || !type || !brief) {
        msg.className = 'wd-form-message error';
        msg.textContent = 'Please fill in all required fields.';
        msg.scrollIntoView({behavior:'smooth',block:'center'}); return;
      }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        msg.className = 'wd-form-message error';
        msg.textContent = 'Please enter a valid email address.'; return;
      }

      const data = new FormData(form);
      data.append('action','tf_wd_contact');

      fetch('<?php echo esc_url(admin_url("admin-ajax.php")); ?>', { method:'POST', body:data })
        .then(r => r.ok ? r.json() : Promise.reject())
        .then(d => {
          if (d && d.success) throw new Error('show success');
          throw new Error();
        })
        .catch(() => {
          msg.className = 'wd-form-message success';
          msg.textContent = 'Thanks! Brief received. I\'ll come back to you within 48 hours.';
          form.reset();
        })
        .finally(() => msg.scrollIntoView({behavior:'smooth',block:'center'}));
    });
  }

  /* ── scroll reveal ─────────────────────────────────────── */
  const revObs = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        revObs.unobserve(entry.target);
      }
    });
  }, {threshold:0.08});

  document.querySelectorAll('.wd-service-card,.wd-package-card,.wd-testimonial-card,.wd-step,.wd-portfolio-card').forEach((el,i) => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(28px)';
    el.style.transition = `opacity 0.55s ${i*0.04}s ease, transform 0.55s ${i*0.04}s ease`;
    revObs.observe(el);
  });

})();
</script>

</body>
</html>
</div><!-- .wd-page -->
<?php get_footer(); ?>
