<?php
/**
 * Template Name: Wedding Photographer
 * Description: Premium Wedding Photography page template — full CSS art-directed hero
 */
get_header(); ?>

<!-- GOOGLE FONTS: Cormorant Garamond + Montserrat -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400;1,600&family=Montserrat:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
/* ============================================================
   WEDDING PHOTOGRAPHER TEMPLATE — --wph-* namespace
   Palette: champagne #C8A96E / blush #E8C4C0 / charcoal #2A2A35 / ivory #FAF8F5
   ============================================================ */
:root {
  --wph-gold:      #C8A96E;
  --wph-gold-lt:   #E8D4A8;
  --wph-gold-dk:   #9A7A3E;
  --wph-blush:     #E8C4C0;
  --wph-blush-lt:  #F5E6E4;
  --wph-blush-dk:  #C49490;
  --wph-charcoal:  #2A2A35;
  --wph-charcoal-lt: #3D3D4E;
  --wph-ivory:     #FAF8F5;
  --wph-ivory-dk:  #F0EDE8;
  --wph-white:     #FFFFFF;
  --wph-grey:      #7A7A8A;
  --wph-radius:    12px;
  --wph-shadow:    0 8px 40px rgba(200,169,110,0.18);
  --wph-font-head: 'Cormorant Garamond', Georgia, serif;
  --wph-font-body: 'Montserrat', system-ui, sans-serif;
}

.wph-wrap * { box-sizing: border-box; margin: 0; padding: 0; }
.wph-wrap { font-family: var(--wph-font-body); color: var(--wph-charcoal); background: var(--wph-white); }

/* ── HERO ── */
.wph-hero {
  position: relative;
  min-height: 100vh;
  background: linear-gradient(150deg, var(--wph-charcoal) 0%, var(--wph-charcoal-lt) 40%, #4A3A4A 75%, #6B4C5A 100%);
  overflow: hidden;
  display: flex;
  align-items: center;
}

/* Bokeh circles */
.wph-bokeh {
  position: absolute;
  border-radius: 50%;
  filter: blur(40px);
  opacity: 0.18;
  animation: wph-bokeh-pulse 6s ease-in-out infinite alternate;
}
.wph-bokeh-1 { width: 300px; height: 300px; background: var(--wph-gold);  top: -80px; right: 10%; animation-delay: 0s; }
.wph-bokeh-2 { width: 200px; height: 200px; background: var(--wph-blush); bottom: 5%; left: 5%; animation-delay: 2s; }
.wph-bokeh-3 { width: 150px; height: 150px; background: var(--wph-gold-lt); top: 40%; left: 30%; animation-delay: 4s; }
@keyframes wph-bokeh-pulse {
  from { opacity: 0.15; transform: scale(1); }
  to   { opacity: 0.25; transform: scale(1.1); }
}

/* Floating light particles */
.wph-particle {
  position: absolute;
  border-radius: 50%;
  background: rgba(200,169,110,0.4);
  animation: wph-particle-drift 10s ease-in-out infinite alternate;
}
@keyframes wph-particle-drift {
  from { transform: translateY(0) translateX(0); opacity: 0.3; }
  to   { transform: translateY(-30px) translateX(15px); opacity: 0.7; }
}

/* CSS CAMERA + WEDDING SCENE */
.wph-scene {
  position: absolute;
  right: 4%;
  top: 50%;
  transform: translateY(-50%);
  width: 460px;
  height: 560px;
}

/* Camera body */
.wph-camera {
  position: absolute;
  top: 60px;
  left: 50%;
  transform: translateX(-50%);
}
.wph-cam-body {
  width: 200px;
  height: 140px;
  background: linear-gradient(180deg, #2A2A2A 0%, #1A1A1A 100%);
  border-radius: 12px;
  position: relative;
  box-shadow: 0 8px 32px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.05);
}
/* Camera top grip */
.wph-cam-grip {
  position: absolute;
  top: -20px;
  right: 20px;
  width: 60px;
  height: 24px;
  background: linear-gradient(180deg, #333 0%, #222 100%);
  border-radius: 6px 6px 0 0;
}
/* Camera dial */
.wph-cam-dial {
  position: absolute;
  top: -8px;
  right: 26px;
  width: 28px;
  height: 16px;
  background: linear-gradient(135deg, #555 0%, #333 100%);
  border-radius: 4px;
}
/* Lens */
.wph-cam-lens-outer {
  position: absolute;
  width: 100px;
  height: 100px;
  background: linear-gradient(135deg, #3A3A3A 0%, #1A1A1A 100%);
  border-radius: 50%;
  top: 20px;
  left: 12px;
  border: 3px solid #444;
  box-shadow: inset 0 0 20px rgba(0,0,0,0.8), 0 4px 16px rgba(0,0,0,0.4);
}
.wph-cam-lens-inner {
  position: absolute;
  width: 72px;
  height: 72px;
  background: radial-gradient(circle, #1A3A5C 0%, #0A1A2C 40%, #050F1A 100%);
  border-radius: 50%;
  top: 11px;
  left: 11px;
  border: 2px solid #2A2A2A;
}
/* Lens glint */
.wph-cam-lens-inner::before {
  content: '';
  position: absolute;
  width: 20px;
  height: 20px;
  background: rgba(255,255,255,0.15);
  border-radius: 50%;
  top: 10px;
  left: 10px;
}
.wph-cam-lens-inner::after {
  content: '';
  position: absolute;
  width: 8px;
  height: 8px;
  background: rgba(255,255,255,0.25);
  border-radius: 50%;
  bottom: 12px;
  right: 14px;
}
/* Flash */
.wph-cam-flash {
  position: absolute;
  top: 16px;
  right: 16px;
  width: 30px;
  height: 20px;
  background: linear-gradient(135deg, #E0E0E0 0%, #C0C0C0 100%);
  border-radius: 4px;
  animation: wph-flash 4s ease-in-out infinite;
}
@keyframes wph-flash {
  0%, 85%, 100% { background: linear-gradient(135deg, #E0E0E0 0%, #C0C0C0 100%); box-shadow: none; }
  90%   { background: #FFFFF0; box-shadow: 0 0 30px 10px rgba(255,255,200,0.5); }
}
/* Shutter button */
.wph-cam-shutter {
  position: absolute;
  top: -6px;
  left: 60px;
  width: 20px;
  height: 12px;
  background: linear-gradient(180deg, #C8A96E 0%, #9A7A3E 100%);
  border-radius: 50% 50% 40% 40%;
}
/* Camera strap anchors */
.wph-cam-body::before {
  content: '';
  position: absolute;
  width: 8px; height: 14px;
  background: #444;
  border-radius: 2px;
  top: 16px;
  left: -4px;
}
.wph-cam-body::after {
  content: '';
  position: absolute;
  width: 8px; height: 14px;
  background: #444;
  border-radius: 2px;
  top: 16px;
  right: -4px;
}

/* Photographer figure behind camera */
.wph-photographer {
  position: absolute;
  top: 180px;
  left: 50%;
  transform: translateX(-50%);
}
.wph-ph-head {
  width: 50px;
  height: 50px;
  background: linear-gradient(180deg, #FFCCBC 0%, #FFAB91 100%);
  border-radius: 50%;
  margin: 0 auto 2px;
  position: relative;
}
.wph-ph-hair {
  position: absolute;
  top: -4px;
  left: 4px;
  right: 4px;
  height: 20px;
  background: #212121;
  border-radius: 50% 50% 5% 5%;
}
.wph-ph-body {
  width: 70px;
  height: 90px;
  background: linear-gradient(180deg, #37474F 0%, #263238 100%);
  border-radius: 12px 12px 6px 6px;
  margin: 0 auto;
  position: relative;
}
/* Camera to eye arm */
.wph-ph-arm {
  position: absolute;
  top: 10px;
  left: -28px;
  width: 36px;
  height: 12px;
  background: #37474F;
  border-radius: 6px;
  transform: rotate(-20deg);
}

/* Wedding couple silhouettes below */
.wph-couple {
  position: absolute;
  bottom: 30px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  align-items: flex-end;
  gap: 6px;
}
/* Groom */
.wph-groom-body {
  width: 44px;
  height: 90px;
  background: linear-gradient(180deg, #2A2A35 0%, #1A1A22 100%);
  border-radius: 8px 8px 4px 4px;
  position: relative;
}
.wph-groom-body::before {
  content: '';
  position: absolute;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 14px;
  height: 30px;
  background: var(--wph-white);
  border-radius: 0 0 4px 4px;
}
.wph-groom-head {
  width: 36px;
  height: 36px;
  background: linear-gradient(180deg, #FFCCBC 0%, #FFAB91 100%);
  border-radius: 50%;
  margin: 0 auto 2px;
}
/* Bride */
.wph-bride-body {
  width: 54px;
  height: 100px;
  background: linear-gradient(180deg, #FAFAFA 0%, #F5F5F5 100%);
  border-radius: 8px 8px 20px 20px / 8px 8px 40px 40px;
  border: 2px solid #E0E0E0;
  position: relative;
}
.wph-bride-body::before {
  content: '';
  position: absolute;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 20px;
  height: 28px;
  background: linear-gradient(180deg, #FAFAFA 0%, #F0F0F0 100%);
  border-radius: 0 0 8px 8px;
  border: 1px solid #E8D4A8;
}
.wph-bride-head {
  width: 38px;
  height: 38px;
  background: linear-gradient(180deg, #FFCCBC 0%, #FFAB91 100%);
  border-radius: 50%;
  margin: 0 auto 2px;
  position: relative;
}
/* Veil */
.wph-veil {
  position: absolute;
  top: -12px;
  left: -4px;
  width: 46px;
  height: 30px;
  background: rgba(255,255,255,0.6);
  border-radius: 50% 50% 30% 30%;
  border: 1px solid rgba(200,169,110,0.4);
}
/* Bouquet */
.wph-bouquet {
  position: absolute;
  bottom: -10px;
  right: -16px;
  width: 30px;
  height: 30px;
}
.wph-bouquet::before {
  content: '💐';
  font-size: 1.4rem;
  position: absolute;
}

/* Connecting hands */
.wph-hands {
  position: absolute;
  bottom: 95px;
  left: 50%;
  transform: translateX(-50%);
  width: 16px;
  height: 10px;
  background: linear-gradient(90deg, #FFAB91 0%, #FFCCBC 100%);
  border-radius: 5px;
}

/* Floating golden hearts */
.wph-heart {
  position: absolute;
  color: rgba(200,169,110,0.5);
  font-size: 1.2rem;
  animation: wph-heart-rise 6s ease-in-out infinite;
}
@keyframes wph-heart-rise {
  0%   { transform: translateY(0) scale(1);   opacity: 0.4; }
  50%  { transform: translateY(-40px) scale(1.1); opacity: 0.7; }
  100% { transform: translateY(-80px) scale(0.8); opacity: 0; }
}

/* Floating gold tags */
.wph-tag {
  position: absolute;
  background: rgba(200,169,110,0.18);
  border: 1px solid rgba(200,169,110,0.4);
  border-radius: 50px;
  padding: 8px 16px;
  color: var(--wph-gold-lt);
  font-family: var(--wph-font-body);
  font-size: 0.78rem;
  font-weight: 600;
  letter-spacing: 0.04em;
  animation: wph-tag-float 6s ease-in-out infinite alternate;
}
.wph-tag-1 { left: 10px; top: 80px;  animation-delay: 0s; }
.wph-tag-2 { left: 20px; top: 160px; animation-delay: 2s; }
.wph-tag-3 { left: 5px;  top: 240px; animation-delay: 4s; }
@keyframes wph-tag-float {
  from { transform: translateY(0); }
  to   { transform: translateY(-12px); }
}

/* Hero content */
.wph-hero-inner {
  position: relative;
  z-index: 2;
  max-width: 1280px;
  margin: 0 auto;
  padding: 120px 5% 80px;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 60px;
  align-items: center;
  width: 100%;
}
.wph-hero-text { color: var(--wph-white); }
.wph-hero-eyebrow {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 20px;
}
.wph-hero-line {
  width: 48px;
  height: 1px;
  background: var(--wph-gold);
}
.wph-hero-eyebrow-text {
  font-size: 0.72rem;
  font-weight: 600;
  letter-spacing: 0.18em;
  text-transform: uppercase;
  color: var(--wph-gold);
}
.wph-hero h1 {
  font-family: var(--wph-font-head);
  font-size: clamp(2.6rem, 5.5vw, 4.2rem);
  font-weight: 300;
  line-height: 1.1;
  margin-bottom: 24px;
}
.wph-hero h1 em { font-style: italic; color: var(--wph-gold-lt); }
.wph-hero-sub {
  font-size: 0.95rem;
  opacity: 0.82;
  line-height: 1.8;
  margin-bottom: 36px;
  max-width: 500px;
  font-weight: 300;
}
.wph-hero-ctas { display: flex; gap: 14px; flex-wrap: wrap; }
.wph-btn-primary {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: var(--wph-gold);
  color: var(--wph-charcoal);
  padding: 16px 32px;
  border-radius: 50px;
  font-weight: 600;
  font-size: 0.88rem;
  letter-spacing: 0.04em;
  text-decoration: none;
  transition: all 0.3s;
  box-shadow: 0 4px 20px rgba(200,169,110,0.4);
}
.wph-btn-primary:hover { background: var(--wph-gold-lt); transform: translateY(-2px); box-shadow: 0 8px 30px rgba(200,169,110,0.5); }
.wph-btn-secondary {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: transparent;
  border: 1px solid rgba(200,169,110,0.5);
  color: var(--wph-gold-lt);
  padding: 15px 28px;
  border-radius: 50px;
  font-weight: 500;
  font-size: 0.88rem;
  letter-spacing: 0.04em;
  text-decoration: none;
  transition: all 0.3s;
}
.wph-btn-secondary:hover { border-color: var(--wph-gold); color: var(--wph-white); background: rgba(200,169,110,0.1); }

.wph-hero-stats {
  display: flex;
  gap: 40px;
  margin-top: 48px;
  padding-top: 28px;
  border-top: 1px solid rgba(200,169,110,0.25);
}
.wph-hero-stat { color: var(--wph-white); }
.wph-hero-stat-num {
  font-family: var(--wph-font-head);
  font-size: 2.2rem;
  font-weight: 300;
  display: block;
  color: var(--wph-gold-lt);
}
.wph-hero-stat-lbl { font-size: 0.72rem; opacity: 0.65; text-transform: uppercase; letter-spacing: 0.1em; }

/* ── GOLD DIVIDER ── */
.wph-divider {
  background: var(--wph-charcoal);
  padding: 18px 5%;
  text-align: center;
}
.wph-divider-inner {
  max-width: 1280px;
  margin: 0 auto;
  display: flex;
  align-items: center;
  gap: 32px;
  flex-wrap: wrap;
  justify-content: center;
}
.wph-divider-item {
  color: rgba(200,169,110,0.7);
  font-size: 0.78rem;
  font-weight: 500;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  display: flex;
  align-items: center;
  gap: 8px;
}

/* ── SECTIONS ── */
.wph-section { padding: 90px 5%; }
.wph-section-inner { max-width: 1280px; margin: 0 auto; }
.wph-section-eyebrow {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 10px;
}
.wph-section-line { width: 36px; height: 1px; background: var(--wph-gold); }
.wph-section-label {
  font-size: 0.68rem;
  font-weight: 600;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: var(--wph-gold-dk);
}
.wph-section-title {
  font-family: var(--wph-font-head);
  font-size: clamp(2rem, 4vw, 3rem);
  font-weight: 300;
  color: var(--wph-charcoal);
  margin-bottom: 16px;
  line-height: 1.15;
}
.wph-section-title em { font-style: italic; color: var(--wph-gold-dk); }
.wph-section-sub { color: var(--wph-grey); font-size: 0.93rem; line-height: 1.8; max-width: 580px; font-weight: 300; }

/* ── SERVICES / PACKAGES ── */
.wph-services { background: var(--wph-ivory); }
.wph-services-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 28px;
  margin-top: 52px;
}
.wph-service {
  background: var(--wph-white);
  border-radius: var(--wph-radius);
  overflow: hidden;
  box-shadow: 0 4px 20px rgba(0,0,0,0.06);
  transition: all 0.3s;
  position: relative;
}
.wph-service:hover { transform: translateY(-8px); box-shadow: var(--wph-shadow); }
.wph-service-featured {
  background: linear-gradient(150deg, var(--wph-charcoal) 0%, var(--wph-charcoal-lt) 100%);
  transform: scale(1.02);
}
.wph-service-featured:hover { transform: scale(1.05); }
.wph-service-top {
  height: 4px;
  background: linear-gradient(90deg, var(--wph-gold-dk) 0%, var(--wph-gold) 50%, var(--wph-gold-lt) 100%);
}
.wph-service-badge {
  position: absolute;
  top: 20px;
  right: 20px;
  background: var(--wph-gold);
  color: var(--wph-charcoal);
  font-size: 0.65rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  padding: 4px 12px;
  border-radius: 50px;
}
.wph-service-body { padding: 32px 28px; }
.wph-service h3 {
  font-family: var(--wph-font-head);
  font-size: 1.3rem;
  font-weight: 400;
  margin-bottom: 6px;
  color: var(--wph-charcoal);
}
.wph-service-featured h3 { color: var(--wph-white); }
.wph-service-price {
  font-family: var(--wph-font-head);
  font-size: 2.4rem;
  font-weight: 300;
  color: var(--wph-gold-dk);
  margin: 14px 0 4px;
  line-height: 1;
}
.wph-service-featured .wph-service-price { color: var(--wph-gold-lt); }
.wph-service-from { font-size: 0.8rem; color: var(--wph-grey); margin-bottom: 18px; }
.wph-service-featured .wph-service-from { color: rgba(255,255,255,0.55); }
.wph-service-includes { list-style: none; margin-bottom: 28px; }
.wph-service-includes li {
  padding: 7px 0;
  border-bottom: 1px solid var(--wph-ivory-dk);
  font-size: 0.84rem;
  display: flex;
  align-items: center;
  gap: 8px;
  color: var(--wph-charcoal);
}
.wph-service-featured .wph-service-includes li { border-bottom-color: rgba(255,255,255,0.1); color: rgba(255,255,255,0.85); }
.wph-service-includes li::before { content: '—'; color: var(--wph-gold); font-weight: 700; }
.wph-service-featured .wph-service-includes li::before { color: var(--wph-gold-lt); }
.wph-service-btn {
  display: block;
  text-align: center;
  padding: 13px;
  border-radius: 50px;
  font-weight: 600;
  font-size: 0.82rem;
  letter-spacing: 0.06em;
  text-decoration: none;
  transition: all 0.3s;
  border: 1px solid var(--wph-gold);
  color: var(--wph-gold-dk);
  background: transparent;
}
.wph-service-btn:hover { background: var(--wph-gold); color: var(--wph-charcoal); }
.wph-service-featured .wph-service-btn { background: var(--wph-gold); color: var(--wph-charcoal); border-color: var(--wph-gold); }
.wph-service-featured .wph-service-btn:hover { background: var(--wph-gold-lt); }

/* ── ABOUT ── */
.wph-about-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center; }
.wph-about-visual { position: relative; height: 460px; }
.wph-about-bg {
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, var(--wph-blush-lt) 0%, var(--wph-ivory-dk) 100%);
  border-radius: 20px;
}
/* Big camera lens circle */
.wph-lens-display {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -55%);
  width: 180px;
  height: 180px;
  background: radial-gradient(circle, #1A3A5C 0%, #0A1A2C 40%, #050F1A 100%);
  border-radius: 50%;
  border: 8px solid #2A2A2A;
  box-shadow: 0 0 0 4px #444, 0 8px 32px rgba(0,0,0,0.4);
}
.wph-lens-display::before {
  content: '';
  position: absolute;
  width: 60px; height: 60px;
  background: rgba(255,255,255,0.1);
  border-radius: 50%;
  top: 30px; left: 30px;
}
.wph-lens-display::after {
  content: '📷';
  position: absolute;
  font-size: 3rem;
  top: 50%; left: 50%;
  transform: translate(-50%, -50%);
}
/* Credential cards */
.wph-cred {
  position: absolute;
  background: var(--wph-white);
  border-radius: 10px;
  padding: 10px 14px;
  font-size: 0.75rem;
  font-weight: 600;
  box-shadow: 0 4px 16px rgba(0,0,0,0.1);
  animation: wph-cred-bob 5s ease-in-out infinite alternate;
  border-left: 3px solid var(--wph-gold);
  color: var(--wph-charcoal);
}
.wph-cred-1 { top: 30px; left: 20px;   animation-delay: 0s; }
.wph-cred-2 { top: 100px; right: 20px; animation-delay: 1.5s; }
.wph-cred-3 { bottom: 90px; left: 20px; animation-delay: 3s; }
@keyframes wph-cred-bob { from { transform: translateY(0); } to { transform: translateY(-10px); } }
/* Awards strip */
.wph-awards {
  position: absolute;
  bottom: 20px;
  right: 20px;
  background: var(--wph-charcoal);
  border-radius: 10px;
  padding: 12px 16px;
}
.wph-awards span { display: block; font-size: 0.7rem; color: var(--wph-gold-lt); font-weight: 700; text-align: center; }
.wph-awards em { display: block; font-size: 0.65rem; color: rgba(255,255,255,0.5); font-style: normal; }

.wph-about-text .wph-section-sub { max-width: 100%; }
.wph-about-quals { display: flex; flex-direction: column; gap: 10px; margin: 22px 0; }
.wph-qual-row {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 0.88rem;
  color: var(--wph-charcoal);
  font-weight: 300;
}
.wph-qual-row::before { content: '—'; color: var(--wph-gold); font-weight: 700; flex-shrink: 0; }
.wph-about-quote {
  background: var(--wph-charcoal);
  color: var(--wph-white);
  padding: 24px 28px;
  border-radius: var(--wph-radius);
  font-family: var(--wph-font-head);
  font-size: 1rem;
  font-style: italic;
  font-weight: 300;
  line-height: 1.7;
  margin-top: 18px;
  border-left: 3px solid var(--wph-gold);
}

/* ── WHAT'S INCLUDED ── */
.wph-included { background: var(--wph-ivory); }
.wph-included-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 24px;
  margin-top: 48px;
}
.wph-include-card {
  background: var(--wph-white);
  border-radius: var(--wph-radius);
  padding: 28px 24px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.05);
  transition: all 0.3s;
  border-bottom: 3px solid var(--wph-gold);
}
.wph-include-card:hover { transform: translateY(-4px); box-shadow: var(--wph-shadow); }
.wph-include-icon { font-size: 2rem; display: block; margin-bottom: 14px; }
.wph-include-card h3 { font-family: var(--wph-font-head); font-size: 1.1rem; font-weight: 400; margin-bottom: 8px; }
.wph-include-card p { font-size: 0.84rem; color: var(--wph-grey); line-height: 1.7; font-weight: 300; }

/* ── PROCESS ── */
.wph-process-section {
  background: linear-gradient(150deg, var(--wph-charcoal) 0%, var(--wph-charcoal-lt) 100%);
}
.wph-process-section .wph-section-label { color: var(--wph-gold); }
.wph-process-section .wph-section-line  { background: var(--wph-gold); }
.wph-process-section .wph-section-title { color: var(--wph-white); }
.wph-process-section .wph-section-sub   { color: rgba(255,255,255,0.6); }
.wph-process-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 32px;
  margin-top: 52px;
}
.wph-process-step { text-align: center; }
.wph-process-icon {
  width: 60px; height: 60px;
  border-radius: 50%;
  background: rgba(200,169,110,0.12);
  border: 1px solid rgba(200,169,110,0.3);
  color: var(--wph-gold);
  font-size: 1.4rem;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 16px;
}
.wph-process-step h3 { font-family: var(--wph-font-head); font-weight: 400; font-size: 1.05rem; color: var(--wph-white); margin-bottom: 8px; }
.wph-process-step p { font-size: 0.83rem; color: rgba(255,255,255,0.6); line-height: 1.65; font-weight: 300; }

/* ── TESTIMONIALS ── */
.wph-testimonials { background: var(--wph-charcoal); }
.wph-testimonials .wph-section-label { color: var(--wph-gold); }
.wph-testimonials .wph-section-line  { background: var(--wph-gold); }
.wph-testimonials .wph-section-title { color: var(--wph-white); }
.wph-testimonials-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
  margin-top: 48px;
}
.wph-testimonial {
  background: rgba(255,255,255,0.04);
  border: 1px solid rgba(200,169,110,0.2);
  border-radius: var(--wph-radius);
  padding: 32px 24px;
  transition: all 0.3s;
}
.wph-testimonial:hover { background: rgba(200,169,110,0.06); border-color: rgba(200,169,110,0.4); }
.wph-stars { color: var(--wph-gold); font-size: 0.9rem; letter-spacing: 2px; margin-bottom: 16px; }
.wph-testimonial p { font-size: 0.88rem; color: rgba(255,255,255,0.75); line-height: 1.8; margin-bottom: 20px; font-style: italic; font-weight: 300; }
.wph-testi-author { display: flex; align-items: center; gap: 12px; }
.wph-testi-avatar {
  width: 42px; height: 42px;
  border-radius: 50%;
  background: rgba(200,169,110,0.2);
  border: 1px solid rgba(200,169,110,0.4);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--wph-gold-lt);
  font-size: 1rem;
}
.wph-testi-name { font-weight: 600; font-size: 0.88rem; color: var(--wph-white); }
.wph-testi-detail { font-size: 0.75rem; color: rgba(200,169,110,0.65); }

/* ── FAQ ── */
.wph-faqs { max-width: 760px; margin: 48px auto 0; }
.wph-faq-item { border-bottom: 1px solid var(--wph-ivory-dk); }
.wph-faq-q {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 18px 0;
  cursor: pointer;
  font-weight: 500;
  font-size: 0.9rem;
  user-select: none;
  font-family: var(--wph-font-head);
  font-size: 1rem;
}
.wph-faq-q::after { content: '+'; font-size: 1.4rem; color: var(--wph-gold-dk); transition: transform 0.3s; flex-shrink: 0; font-family: var(--wph-font-body); }
.wph-faq-item.wph-open .wph-faq-q::after { transform: rotate(45deg); }
.wph-faq-a { max-height: 0; overflow: hidden; transition: max-height 0.4s ease; }
.wph-faq-a-inner { padding: 0 0 18px; color: var(--wph-grey); font-size: 0.88rem; line-height: 1.8; font-weight: 300; }

/* ── BOOKING ── */
.wph-booking-section { background: var(--wph-ivory); }
.wph-booking-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 70px;
  margin-top: 52px;
  align-items: start;
}
.wph-booking-info h3 { font-family: var(--wph-font-head); font-size: 1.4rem; font-weight: 400; margin-bottom: 16px; }
.wph-booking-info ul { list-style: none; display: flex; flex-direction: column; gap: 10px; }
.wph-booking-info li { display: flex; align-items: flex-start; gap: 10px; font-size: 0.88rem; color: var(--wph-charcoal); font-weight: 300; }
.wph-booking-info li::before { content: '—'; color: var(--wph-gold); font-weight: 700; flex-shrink: 0; }
.wph-contact-box {
  background: var(--wph-charcoal);
  border-radius: var(--wph-radius);
  padding: 22px 26px;
  margin-top: 28px;
}
.wph-contact-box h4 { font-size: 0.7rem; font-weight: 600; color: rgba(200,169,110,0.6); text-transform: uppercase; letter-spacing: 0.12em; margin-bottom: 14px; }
.wph-contact-item { display: flex; align-items: center; gap: 10px; font-size: 0.88rem; color: rgba(255,255,255,0.8); margin-bottom: 10px; font-weight: 300; }
.wph-contact-item strong { color: var(--wph-gold-lt); }

.wph-form {
  background: var(--wph-white);
  border-radius: 16px;
  padding: 36px 32px;
  box-shadow: 0 8px 40px rgba(0,0,0,0.1);
  border: 1px solid var(--wph-ivory-dk);
}
.wph-form-eyebrow { display: flex; align-items: center; gap: 10px; margin-bottom: 6px; }
.wph-form-line { width: 28px; height: 1px; background: var(--wph-gold); }
.wph-form-label { font-size: 0.65rem; letter-spacing: 0.12em; text-transform: uppercase; color: var(--wph-gold-dk); font-weight: 600; }
.wph-form h3 { font-family: var(--wph-font-head); font-size: 1.5rem; font-weight: 300; color: var(--wph-charcoal); margin-bottom: 24px; }
.wph-form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.wph-form-group { display: flex; flex-direction: column; gap: 6px; }
.wph-form-group.wph-full { grid-column: 1/-1; }
.wph-form-group label { font-size: 0.72rem; font-weight: 600; color: var(--wph-charcoal); letter-spacing: 0.04em; text-transform: uppercase; }
.wph-form-group input,
.wph-form-group select,
.wph-form-group textarea {
  padding: 12px 16px;
  border: 1px solid var(--wph-ivory-dk);
  border-radius: 8px;
  font-family: var(--wph-font-body);
  font-size: 0.88rem;
  color: var(--wph-charcoal);
  transition: border-color 0.3s;
  background: var(--wph-ivory);
  font-weight: 300;
}
.wph-form-group input:focus,
.wph-form-group select:focus,
.wph-form-group textarea:focus { outline: none; border-color: var(--wph-gold); background: var(--wph-white); }
.wph-form-group textarea { resize: vertical; min-height: 90px; }
.wph-form-submit {
  width: 100%;
  padding: 15px;
  background: linear-gradient(135deg, var(--wph-gold-dk) 0%, var(--wph-gold) 50%, var(--wph-gold-lt) 100%);
  color: var(--wph-charcoal);
  border: none;
  border-radius: 50px;
  font-family: var(--wph-font-body);
  font-size: 0.88rem;
  font-weight: 600;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  cursor: pointer;
  transition: all 0.3s;
  margin-top: 8px;
  box-shadow: 0 4px 20px rgba(200,169,110,0.4);
}
.wph-form-submit:hover { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(200,169,110,0.5); }
.wph-form-note { font-size: 0.74rem; color: var(--wph-grey); text-align: center; margin-top: 12px; font-weight: 300; }

/* ── RESPONSIVE ── */
@media (max-width: 1024px) {
  .wph-hero-inner { grid-template-columns: 1fr; }
  .wph-scene { display: none; }
  .wph-services-grid { grid-template-columns: 1fr; }
  .wph-service-featured { transform: none; }
  .wph-about-grid { grid-template-columns: 1fr; }
  .wph-about-visual { height: 280px; }
  .wph-testimonials-grid { grid-template-columns: 1fr; }
  .wph-booking-grid { grid-template-columns: 1fr; }
}
@media (max-width: 640px) {
  .wph-section { padding: 60px 5%; }
  .wph-hero h1 { font-size: 2.4rem; }
  .wph-included-grid { grid-template-columns: 1fr; }
  .wph-process-grid { grid-template-columns: 1fr 1fr; }
  .wph-form-grid { grid-template-columns: 1fr; }
  .wph-hero-stats { gap: 20px; }
}
</style>

<div class="wph-wrap">

<!-- ═══════════════════════════════
     HERO
════════════════════════════════ -->
<section class="wph-hero">

  <!-- Bokeh -->
  <div class="wph-bokeh wph-bokeh-1"></div>
  <div class="wph-bokeh wph-bokeh-2"></div>
  <div class="wph-bokeh wph-bokeh-3"></div>

  <!-- Light particles -->
  <?php
  srand(crc32('wph-particles'));
  for ($i = 0; $i < 12; $i++) {
    $left  = rand(3, 90);
    $top   = rand(5, 90);
    $sz    = rand(4, 14);
    $delay = rand(0, 8000) / 1000;
    echo "<div class='wph-particle' style='left:{$left}%;top:{$top}%;width:{$sz}px;height:{$sz}px;animation-delay:{$delay}s;'></div>";
  }
  ?>

  <div class="wph-hero-inner">
    <div class="wph-hero-text">
      <div class="wph-hero-eyebrow">
        <div class="wph-hero-line"></div>
        <div class="wph-hero-eyebrow-text">Award-Winning Wedding Photographer</div>
      </div>
      <h1>Where Every<br><em>Love Story</em><br>Becomes Art</h1>
      <p class="wph-hero-sub">Documentary and fine-art wedding photography across the UK &amp; Europe. Capturing authentic, timeless moments with a storyteller's eye and a photographer's soul.</p>
      <div class="wph-hero-ctas">
        <a href="#booking" class="wph-btn-primary">✉ Enquire About Your Date</a>
        <a href="#services" class="wph-btn-secondary">View Collections →</a>
      </div>
      <div class="wph-hero-stats">
        <div class="wph-hero-stat">
          <span class="wph-hero-stat-num" data-target="14" data-suffix="yrs">0yrs</span>
          <span class="wph-hero-stat-lbl">Shooting Weddings</span>
        </div>
        <div class="wph-hero-stat">
          <span class="wph-hero-stat-num" data-target="650" data-suffix="+">0+</span>
          <span class="wph-hero-stat-lbl">Weddings Shot</span>
        </div>
        <div class="wph-hero-stat">
          <span class="wph-hero-stat-num" data-target="5.0" data-float="1" data-suffix="★">0★</span>
          <span class="wph-hero-stat-lbl">Couples' Rating</span>
        </div>
        <div class="wph-hero-stat">
          <span class="wph-hero-stat-num" data-target="12" data-suffix=" awards">0</span>
          <span class="wph-hero-stat-lbl">Industry Awards</span>
        </div>
      </div>
    </div>
  </div>

  <!-- CSS Scene -->
  <div class="wph-scene">
    <!-- Floating hearts -->
    <?php
    srand(crc32('wph-hearts'));
    $heart_positions = [[20,70],[40,60],[60,75],[75,55],[55,80]];
    foreach ($heart_positions as $k => $pos) {
      $delay = $k * 1.2;
      echo "<div class='wph-heart' style='left:{$pos[0]}%;top:{$pos[1]}%;animation-delay:{$delay}s;'>♥</div>";
    }
    ?>

    <!-- Camera -->
    <div class="wph-camera">
      <div class="wph-cam-grip"></div>
      <div class="wph-cam-dial"></div>
      <div class="wph-cam-body">
        <div class="wph-cam-lens-outer">
          <div class="wph-cam-lens-inner"></div>
        </div>
        <div class="wph-cam-flash"></div>
        <div class="wph-cam-shutter"></div>
      </div>
    </div>

    <!-- Photographer -->
    <div class="wph-photographer">
      <div class="wph-ph-head"><div class="wph-ph-hair"></div></div>
      <div class="wph-ph-body"><div class="wph-ph-arm"></div></div>
    </div>

    <!-- Couple -->
    <div class="wph-couple">
      <div>
        <div class="wph-groom-head"></div>
        <div class="wph-groom-body"></div>
      </div>
      <div>
        <div class="wph-bride-head">
          <div class="wph-veil"></div>
        </div>
        <div class="wph-bride-body">
          <div class="wph-bouquet"></div>
        </div>
      </div>
    </div>
    <div class="wph-hands"></div>

    <!-- Floating tags -->
    <div class="wph-tag wph-tag-1">📷 Sony A7R V</div>
    <div class="wph-tag wph-tag-2">🏆 WPJA Award Winner</div>
    <div class="wph-tag wph-tag-3">🌍 Destination Weddings</div>
  </div>

</section>

<!-- DIVIDER -->
<div class="wph-divider">
  <div class="wph-divider-inner">
    <div class="wph-divider-item">📸 Documentary Style</div>
    <div class="wph-divider-item">✨ Fine Art Editing</div>
    <div class="wph-divider-item">🎞️ Full Gallery Delivery</div>
    <div class="wph-divider-item">🌍 UK &amp; Destination</div>
    <div class="wph-divider-item">💿 Online Gallery &amp; USB</div>
  </div>
</div>

<!-- ═══════════════════════════════
     COLLECTIONS
════════════════════════════════ -->
<section class="wph-section wph-services" id="services">
  <div class="wph-section-inner">
    <div class="wph-section-eyebrow"><div class="wph-section-line"></div><div class="wph-section-label">Wedding Collections</div></div>
    <h2 class="wph-section-title">Choose Your <em>Perfect Collection</em></h2>
    <p class="wph-section-sub">Every collection includes professional editing, an online gallery, and my full creative commitment to your day.</p>

    <div class="wph-services-grid">
      <div class="wph-service">
        <div class="wph-service-top"></div>
        <div class="wph-service-body">
          <h3>The Elopement</h3>
          <div class="wph-service-price">£1,200</div>
          <div class="wph-service-from">Intimate ceremonies up to 30 guests</div>
          <ul class="wph-service-includes">
            <li>6 hours photography coverage</li>
            <li>300+ professionally edited images</li>
            <li>Online gallery (12 months access)</li>
            <li>Print release included</li>
            <li>USB delivered by post</li>
          </ul>
          <a href="#booking" class="wph-service-btn">Enquire Now</a>
        </div>
      </div>
      <div class="wph-service wph-service-featured">
        <div class="wph-service-top"></div>
        <div class="wph-service-badge">Most Popular</div>
        <div class="wph-service-body">
          <h3>The Story</h3>
          <div class="wph-service-price">£2,450</div>
          <div class="wph-service-from">Full-day coverage · any guest count</div>
          <ul class="wph-service-includes">
            <li>10 hours photography coverage</li>
            <li>600+ professionally edited images</li>
            <li>Engagement shoot included</li>
            <li>Online gallery (lifetime access)</li>
            <li>Premium USB &amp; print release</li>
            <li>Second photographer option (+£350)</li>
          </ul>
          <a href="#booking" class="wph-service-btn">Enquire Now</a>
        </div>
      </div>
      <div class="wph-service">
        <div class="wph-service-top"></div>
        <div class="wph-service-body">
          <h3>The Legacy</h3>
          <div class="wph-service-price">£3,800</div>
          <div class="wph-service-from">Ultimate experience + fine art album</div>
          <ul class="wph-service-includes">
            <li>Full day + evening coverage</li>
            <li>900+ professionally edited images</li>
            <li>Second photographer included</li>
            <li>Fine art wedding album (30 pages)</li>
            <li>Engagement shoot + print session</li>
            <li>Lifetime online gallery</li>
          </ul>
          <a href="#booking" class="wph-service-btn">Enquire Now</a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     ABOUT
════════════════════════════════ -->
<section class="wph-section">
  <div class="wph-section-inner">
    <div class="wph-about-grid">
      <div class="wph-about-visual">
        <div class="wph-about-bg"></div>
        <div class="wph-lens-display"></div>
        <div class="wph-cred wph-cred-1">WPJA Accredited Member</div>
        <div class="wph-cred wph-cred-2">BIPP Fellow (FBIPP)</div>
        <div class="wph-cred wph-cred-3">Sony Alpha Ambassador</div>
        <div class="wph-awards">
          <span>🏆 12 Awards</span>
          <em>WPJA · DIPA · The Guild</em>
        </div>
      </div>
      <div class="wph-about-text">
        <div class="wph-section-eyebrow"><div class="wph-section-line"></div><div class="wph-section-label">Your Photographer</div></div>
        <h2 class="wph-section-title">Oliver <em>Hartfield</em></h2>
        <p class="wph-section-sub">A Fellow of the British Institute of Professional Photography with 14 years specialising in weddings, Oliver's documentary approach captures the raw emotion and fleeting moments that make your story uniquely yours. Based in the Cotswolds, he photographs weddings across the UK, Europe, and internationally.</p>

        <div class="wph-about-quals">
          <div class="wph-qual-row">FBIPP — Fellow, British Institute of Professional Photography</div>
          <div class="wph-qual-row">WPJA — Wedding Photojournalist Association Accredited</div>
          <div class="wph-qual-row">Sony Alpha Ambassador — professional partnership</div>
          <div class="wph-qual-row">12 international wedding photography awards (2018–2025)</div>
          <div class="wph-qual-row">Published in Vogue Weddings, Brides, and Rock My Wedding</div>
        </div>
        <div class="wph-about-quote">
          "I don't pose your wedding — I witness it. My job is to be invisible enough that you forget I'm there, and skilled enough that I never miss the moment you'll treasure forever."
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     WHAT'S INCLUDED
════════════════════════════════ -->
<section class="wph-section wph-included">
  <div class="wph-section-inner">
    <div class="wph-section-eyebrow"><div class="wph-section-line"></div><div class="wph-section-label">The Experience</div></div>
    <h2 class="wph-section-title">More Than <em>Just Photography</em></h2>
    <p class="wph-section-sub">Every collection comes with the same care, craft, and commitment — because your day deserves nothing less.</p>

    <div class="wph-included-grid">
      <div class="wph-include-card">
        <span class="wph-include-icon">💌</span>
        <h3>Planning Call Included</h3>
        <p>A dedicated 60-minute planning call to walk through your day's timeline, must-have shots, and any creative ideas you have in mind.</p>
      </div>
      <div class="wph-include-card">
        <span class="wph-include-icon">🎨</span>
        <h3>Signature Editing Style</h3>
        <p>Every image hand-edited in a timeless, elegant style — no heavy filters, just beautifully balanced light, colour, and emotion.</p>
      </div>
      <div class="wph-include-card">
        <span class="wph-include-icon">☁️</span>
        <h3>Online Gallery</h3>
        <p>Your complete gallery delivered via a private, password-protected online gallery within 6–8 weeks of your wedding date.</p>
      </div>
      <div class="wph-include-card">
        <span class="wph-include-icon">🖨️</span>
        <h3>Full Print Rights</h3>
        <p>Complete, unrestricted print release included with every collection — print your images wherever and however you like, forever.</p>
      </div>
      <div class="wph-include-card">
        <span class="wph-include-icon">🌍</span>
        <h3>Destination Coverage</h3>
        <p>Oliver photographs weddings throughout the UK and abroad — Italy, France, Greece, Portugal, and beyond. Travel fees apply.</p>
      </div>
      <div class="wph-include-card">
        <span class="wph-include-icon">🎞️</span>
        <h3>Backup &amp; Security</h3>
        <p>All images backed up across multiple redundant systems immediately after shooting. Your memories are completely safe.</p>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     PROCESS
════════════════════════════════ -->
<section class="wph-section wph-process-section">
  <div class="wph-section-inner">
    <div class="wph-section-eyebrow"><div class="wph-section-line"></div><div class="wph-section-label">How It Works</div></div>
    <h2 class="wph-section-title">From First Enquiry to Forever</h2>
    <p class="wph-section-sub">A considered process designed around you — at every step.</p>

    <div class="wph-process-grid">
      <div class="wph-process-step">
        <div class="wph-process-icon">✉</div>
        <h3>Enquire</h3>
        <p>Send your date and a brief message. I'll reply within 24 hours to check availability and share my collections.</p>
      </div>
      <div class="wph-process-step">
        <div class="wph-process-icon">☕</div>
        <h3>Let's Meet</h3>
        <p>A relaxed video or in-person meeting to get to know each other, discuss your vision, and answer all your questions.</p>
      </div>
      <div class="wph-process-step">
        <div class="wph-process-icon">✍</div>
        <h3>Secure Your Date</h3>
        <p>A signed contract and 25% deposit to reserve your date. Simple, transparent terms — no hidden clauses.</p>
      </div>
      <div class="wph-process-step">
        <div class="wph-process-icon">📷</div>
        <h3>Your Wedding Day</h3>
        <p>I arrive early, stay late, and document your entire day with calm, unobtrusive, beautiful photography.</p>
      </div>
      <div class="wph-process-step">
        <div class="wph-process-icon">✨</div>
        <h3>Gallery Delivery</h3>
        <p>Your hand-edited gallery delivered within 6–8 weeks — ready to relive, share, print, and keep forever.</p>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     TESTIMONIALS
════════════════════════════════ -->
<section class="wph-section wph-testimonials">
  <div class="wph-section-inner">
    <div class="wph-section-eyebrow"><div class="wph-section-line"></div><div class="wph-section-label">Couples' Words</div></div>
    <h2 class="wph-section-title">What They Say</h2>

    <div class="wph-testimonials-grid">
      <div class="wph-testimonial">
        <div class="wph-stars">★ ★ ★ ★ ★</div>
        <p>We've been married three years and still look through our gallery every anniversary. Oliver captured moments we didn't even know were happening — our guests laughing, our grandparents holding hands. Pure magic.</p>
        <div class="wph-testi-author">
          <div class="wph-testi-avatar">💍</div>
          <div>
            <div class="wph-testi-name">Sophie &amp; James</div>
            <div class="wph-testi-detail">Married at Babington House, Somerset</div>
          </div>
        </div>
      </div>
      <div class="wph-testimonial">
        <div class="wph-stars">★ ★ ★ ★ ★</div>
        <p>Oliver made us feel completely at ease from the first meeting. He understood our vision perfectly — relaxed, romantic, no cheesy poses. Our photos look like they belong in a magazine, and they're entirely, genuinely us.</p>
        <div class="wph-testi-author">
          <div class="wph-testi-avatar">💐</div>
          <div>
            <div class="wph-testi-name">Elena &amp; Marco</div>
            <div class="wph-testi-detail">Destination Wedding, Lake Como, Italy</div>
          </div>
        </div>
      </div>
      <div class="wph-testimonial">
        <div class="wph-stars">★ ★ ★ ★ ★</div>
        <p>We almost didn't book a photographer because of the cost — a decision I'm so glad we reconsidered. Our photos are the most precious thing we have from our day. Oliver is worth every single penny and more.</p>
        <div class="wph-testi-author">
          <div class="wph-testi-avatar">🌸</div>
          <div>
            <div class="wph-testi-name">Charlotte &amp; Tom</div>
            <div class="wph-testi-detail">The Old Rectory, Gloucestershire</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     FAQ
════════════════════════════════ -->
<section class="wph-section">
  <div class="wph-section-inner">
    <div style="text-align:center; margin-bottom:8px;">
      <div class="wph-section-eyebrow" style="justify-content:center;"><div class="wph-section-line"></div><div class="wph-section-label">Questions &amp; Answers</div><div class="wph-section-line"></div></div>
      <h2 class="wph-section-title">Frequently Asked</h2>
    </div>
    <div class="wph-faqs">
      <div class="wph-faq-item">
        <div class="wph-faq-q">How far in advance should we book?</div>
        <div class="wph-faq-a"><div class="wph-faq-a-inner">Popular dates (particularly June–September and Fridays/Saturdays) are often reserved 12–18 months in advance. I recommend enquiring as soon as you have a date in mind to avoid disappointment. I accept a limited number of weddings per year to maintain quality.</div></div>
      </div>
      <div class="wph-faq-item">
        <div class="wph-faq-q">Do you photograph same-sex weddings?</div>
        <div class="wph-faq-a"><div class="wph-faq-a-inner">Absolutely and wholeheartedly. Love is love, and I photograph every couple with equal passion and dedication. Some of my favourite galleries are from same-sex celebrations.</div></div>
      </div>
      <div class="wph-faq-item">
        <div class="wph-faq-q">What if the weather is terrible?</div>
        <div class="wph-faq-a"><div class="wph-faq-a-inner">British weather is part of the adventure! I come prepared for all conditions and genuinely love the drama that overcast skies and rain can create. Some of my most striking images have been in challenging weather. I'll work with whatever the day brings.</div></div>
      </div>
      <div class="wph-faq-item">
        <div class="wph-faq-q">How long until we receive our photos?</div>
        <div class="wph-faq-a"><div class="wph-faq-a-inner">Galleries are delivered within 6–8 weeks of your wedding date. You'll receive a sneak preview of 20–30 images within one week of your wedding so you have something to share while you wait for the full gallery.</div></div>
      </div>
      <div class="wph-faq-item">
        <div class="wph-faq-q">Do you travel for destination weddings?</div>
        <div class="wph-faq-a"><div class="wph-faq-a-inner">Yes — destination weddings are one of my great passions. I've photographed weddings in Italy, France, Greece, Portugal, Croatia, Sri Lanka, and beyond. Travel and accommodation costs are quoted separately and kept as reasonable as possible.</div></div>
      </div>
      <div class="wph-faq-item">
        <div class="wph-faq-q">What is your booking deposit?</div>
        <div class="wph-faq-a"><div class="wph-faq-a-inner">A 25% non-refundable booking fee is required to secure your date, with the remaining balance due 4 weeks before your wedding. Payment plans are available on request for larger collections.</div></div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════
     BOOKING FORM
════════════════════════════════ -->
<section class="wph-section wph-booking-section" id="booking">
  <div class="wph-section-inner">
    <div class="wph-section-eyebrow"><div class="wph-section-line"></div><div class="wph-section-label">Begin Your Story</div></div>
    <h2 class="wph-section-title">Check Your Date &amp; <em>Enquire</em></h2>
    <p class="wph-section-sub">Every love story is unique. Tell me about yours and I'll be in touch within 24 hours.</p>

    <div class="wph-booking-grid">
      <div class="wph-booking-info">
        <h3>What to Expect After Enquiring</h3>
        <ul>
          <li>A personal reply within 24 hours to confirm availability</li>
          <li>Full collection and pricing guide sent straight to your inbox</li>
          <li>An invitation to a relaxed discovery call — no pressure</li>
          <li>Sneak peek galleries to browse my most recent work</li>
          <li>Transparent, all-inclusive pricing — no surprise add-ons</li>
          <li>A 14-day cooling-off period after any contract is signed</li>
        </ul>
        <div class="wph-contact-box">
          <h4>Direct Contact</h4>
          <div class="wph-contact-item"><strong>📧</strong> oliver@hartfieldphoto.co.uk</div>
          <div class="wph-contact-item"><strong>📞</strong> 07920 456 789</div>
          <div class="wph-contact-item"><strong>📍</strong> Based in the Cotswolds · UK &amp; Worldwide</div>
          <div class="wph-contact-item"><strong>📸</strong> @oliverhartfieldphoto on Instagram</div>
        </div>
      </div>

      <div class="wph-form">
        <div class="wph-form-eyebrow"><div class="wph-form-line"></div><div class="wph-form-label">Enquiry Form</div></div>
        <h3>Tell Me About Your Wedding</h3>
        <?php if ( function_exists( 'get_the_permalink' ) ) : ?>
        <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
          <?php wp_nonce_field( 'tf_wph_booking', 'tf_wph_nonce' ); ?>
          <input type="hidden" name="action" value="tf_wph_booking">
          <div class="wph-form-grid">
            <div class="wph-form-group">
              <label for="wph_name1">Partner 1 Name *</label>
              <input type="text" id="wph_name1" name="partner1" required placeholder="Sophie">
            </div>
            <div class="wph-form-group">
              <label for="wph_name2">Partner 2 Name *</label>
              <input type="text" id="wph_name2" name="partner2" required placeholder="James">
            </div>
            <div class="wph-form-group">
              <label for="wph_email">Email Address *</label>
              <input type="email" id="wph_email" name="email" required placeholder="sophie@email.com">
            </div>
            <div class="wph-form-group">
              <label for="wph_phone">Phone Number</label>
              <input type="tel" id="wph_phone" name="phone" placeholder="07900 000 000">
            </div>
            <div class="wph-form-group">
              <label for="wph_date">Wedding Date *</label>
              <input type="date" id="wph_date" name="wedding_date" required>
            </div>
            <div class="wph-form-group">
              <label for="wph_guests">Guest Count</label>
              <select id="wph_guests" name="guest_count">
                <option value="">— Approx. guests —</option>
                <option>Under 30 (intimate)</option>
                <option>30–60 guests</option>
                <option>60–100 guests</option>
                <option>100–150 guests</option>
                <option>150+ guests</option>
              </select>
            </div>
            <div class="wph-form-group wph-full">
              <label for="wph_venue">Venue / Location</label>
              <input type="text" id="wph_venue" name="venue" placeholder="The Old Barn, Chipping Campden, Gloucestershire">
            </div>
            <div class="wph-form-group wph-full">
              <label for="wph_msg">Tell Me About Your Day *</label>
              <textarea id="wph_msg" name="message" required placeholder="What's the feel you're going for? Any particular moments, traditions, or details that matter most to you?"></textarea>
            </div>
          </div>
          <button type="submit" class="wph-form-submit">✉ Send My Enquiry</button>
          <p class="wph-form-note">Your privacy is important. Details shared here are used only to respond to your enquiry and are never shared with third parties.</p>
        </form>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

</div><!-- .wph-wrap -->

<script>
(function(){
  /* ── ANIMATED COUNTERS ── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  const counters = document.querySelectorAll('[data-target]');
  if (!counters.length) return;
  const obs = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const target = parseFloat(el.dataset.target);
      if (isNaN(target)) return;
      const suffix  = el.dataset.suffix || '';
      const isFloat = el.dataset.float === '1';
      const dur = 1800; let start = null;
      function tick(ts) {
        if (!start) start = ts;
        const prog = Math.min((ts - start) / dur, 1);
        const val  = easeOut(prog) * target;
        el.textContent = (isFloat ? val.toFixed(1) : Math.floor(val).toLocaleString()) + suffix;
        if (prog < 1) requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
      obs.unobserve(el);
    });
  }, { threshold: 0.5 });
  counters.forEach(c => obs.observe(c));

  /* ── FAQ ACCORDION ── */
  document.querySelectorAll('.wph-faq-q').forEach(q => {
    q.addEventListener('click', () => {
      const item = q.parentElement;
      const ans  = item.querySelector('.wph-faq-a');
      const open = item.classList.contains('wph-open');
      document.querySelectorAll('.wph-faq-item.wph-open').forEach(o => {
        o.classList.remove('wph-open');
        o.querySelector('.wph-faq-a').style.maxHeight = '0';
      });
      if (!open) { item.classList.add('wph-open'); ans.style.maxHeight = ans.scrollHeight + 'px'; }
    });
  });

  /* ── SCROLL REVEAL ── */
  const reveals = document.querySelectorAll('.wph-service,.wph-include-card,.wph-process-step,.wph-testimonial');
  const revObs  = new IntersectionObserver(entries => {
    entries.forEach((e, i) => {
      if (e.isIntersecting) {
        setTimeout(() => {
          e.target.style.opacity   = '1';
          e.target.style.transform = e.target.classList.contains('wph-service-featured') ? 'scale(1.02)' : 'translateY(0)';
        }, (i % 4) * 90);
        revObs.unobserve(e.target);
      }
    });
  }, { threshold: 0.1 });
  reveals.forEach(r => {
    r.style.opacity   = '0';
    r.style.transform = r.classList.contains('wph-service-featured') ? 'scale(0.98)' : 'translateY(24px)';
    r.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    revObs.observe(r);
  });

  /* ── SMOOTH SCROLL ── */
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const target = document.querySelector(a.getAttribute('href'));
      if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    });
  });
})();
</script>

<?php get_footer(); ?>
